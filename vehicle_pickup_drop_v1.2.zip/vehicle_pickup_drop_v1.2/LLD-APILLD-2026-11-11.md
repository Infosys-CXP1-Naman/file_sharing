MSIL CHAUFFEUR PICKUP AND DROP SERVICE
APPOINTMENT BOOKING SYSTEM API
LOW-LEVEL DESIGN DOCUMENT

Document Version: 1.0.0
Last Updated: 2025-07-15
Prepared For: MSIL Internal Engineering and Architecture Review


=============================================================
SECTION 1: DOCUMENT PURPOSE AND SCOPE
=============================================================

This Low-Level Design document describes the internal technical design of the MSIL Chauffeur Pickup and Drop Service Appointment Booking System API. It covers the full lifecycle of the chauffeur-driven vehicle pickup and drop service, from appointment booking and orchestration through chauffeur recommendation and assignment, real-time trip tracking, vehicle condition capture, OTP verification, drop scheduling and execution, outbound notification dispatch, CRM and DBP integration, and immutable audit trail management.

This document is intended for use by backend engineers, frontend integration teams, QA engineers, DevOps, and solution architects. It provides sufficient detail to implement, test, integrate, and operate every API endpoint defined in the system.

The document is structured as follows:
- Section 1: Document Purpose and Scope
- Section 2: System Architecture Overview
- Section 3: Technology Stack and Infrastructure Assumptions
- Section 4: Cross-Cutting Concerns
- Section 5: Data Models and Domain Entities
- Section 6: Security Architecture
- Section 7: Error Handling Strategy
- Section 8: Notification Architecture
- Section 9: Integration Architecture
- Section 10: Audit Trail Architecture
- Section 11: Requirement Traceability Matrix
- Section 12: Endpoint Index
- Section 13: Per-Endpoint Detailed Design (appended separately)


=============================================================
SECTION 2: SYSTEM ARCHITECTURE OVERVIEW
=============================================================

2.1 System Context

The MSIL Chauffeur Pickup and Drop Service API is a backend REST API that acts as the central orchestration layer for the chauffeur service. It sits between the following consumer systems and downstream integration targets.

Consumer Systems:
- Pickup Coordinator Dashboard (web application used by dealership coordinators)
- Chauffeur Mobile Application (Android/iOS app used by chauffeurs in the field)
- Internal Orchestration Services (scheduled jobs, delay detection engine, recommendation engine)
- Customer-facing notification recipients (passive consumers via push/SMS/WhatsApp)

Downstream Integration Targets:
- CRM System (Customer Relationship Management; source of appointment and JC data)
- DBP System (Dealer Business Platform; Smart Eye integration for vehicle images and JC updates)
- Map API (third-party mapping service for ETA, route, geofence, and suggested start time)
- ICP Channel (Internal Communication Platform for push notifications)
- WhatsApp Channel (WhatsApp Business API for customer messaging)
- SMS Channel (SMS gateway for OTP and status messages)
- NotificationService (internal abstraction layer over all outbound channels)

2.2 Logical Architecture Layers

Layer 1 - API Gateway Layer:
Handles TLS termination, JWT validation, rate limiting, and request routing. All inbound traffic passes through this layer before reaching the application layer.

Layer 2 - Application Service Layer:
Contains the domain-specific service modules. Each module corresponds to a bounded context:
- AppointmentOrchestrationService
- ChauffeurAssignmentRecommendationService
- ChauffeurAssignmentOrchestrationService
- TripManagementService
- DropTripService
- DropRequestService
- VehicleConditionReportService
- OTPService
- NotificationDispatchService
- MapIntegrationService
- CRMIntegrationService
- DBPIntegrationService
- AuditService
- DelayDetectionService

Layer 3 - Domain Model Layer:
Contains the core domain entities, value objects, aggregates, and business rules. This layer has no dependency on infrastructure.

Layer 4 - Infrastructure Layer:
Contains repository implementations, external HTTP clients, message queue producers and consumers, cache adapters, and database access objects.

Layer 5 - External Systems:
CRM, DBP, Map API, ICP, WhatsApp, SMS gateway.

2.3 Deployment Model

The API is deployed as a containerised microservice on a Kubernetes cluster. Each bounded context module may be deployed as a separate service or as a modular monolith depending on operational requirements. The document assumes a single deployable unit for simplicity but the design supports decomposition.

2.4 Communication Patterns

Synchronous: REST over HTTPS for all client-facing endpoints and most downstream integrations.
Asynchronous: Internal domain events published to a message broker (e.g. Kafka or RabbitMQ) for notification dispatch, audit event emission, and delay detection triggers.
Webhook: Inbound CRM callbacks received at /api/v1/crm/webhooks/inbound.


=============================================================
SECTION 3: TECHNOLOGY STACK AND INFRASTRUCTURE ASSUMPTIONS
=============================================================

3.1 Runtime and Framework

Programming Language: Java 17 or Node.js 18 LTS (implementation team choice; this document is language-agnostic at the design level)
API Style: REST, OpenAPI 3.0 compliant
HTTP Framework: Spring Boot 3.x (Java) or Express/Fastify (Node.js)
Authentication: JWT Bearer tokens issued by an OAuth 2.0 / OIDC-compliant identity provider
Authorization: Role-Based Access Control (RBAC) enforced at the service layer

3.2 Data Storage

Primary Database: PostgreSQL 15 (relational, ACID-compliant)
Cache: Redis 7 (OTP storage, ETA cache, session state, rate limit counters)
Object Storage: AWS S3 or equivalent (vehicle condition images, voice recording references, QR summary cards)
Message Broker: Apache Kafka 3.x or RabbitMQ 3.x (domain event bus)

3.3 Infrastructure

API Gateway: Kong or AWS API Gateway
Service Mesh: Optional Istio for inter-service mTLS
Secrets Management: HashiCorp Vault or AWS Secrets Manager
Logging: Structured JSON logs shipped to ELK stack or equivalent
Metrics: Prometheus + Grafana
Tracing: OpenTelemetry with Jaeger or Zipkin

3.4 External API Assumptions

Map API: Assumed to be Google Maps Platform (Directions API, Distance Matrix API, Geocoding API) or HERE Maps. Exact provider is abstracted behind MapIntegrationService.
CRM: MSIL internal CRM system exposing REST endpoints. Webhook delivery is guaranteed at-least-once.
DBP: MSIL Dealer Business Platform exposing REST endpoints for Smart Eye image upload and JC status updates.
Notification Channels: Each channel (ICP, WhatsApp, SMS) has its own HTTP API abstracted behind NotificationDispatchService.


=============================================================
SECTION 4: CROSS-CUTTING CONCERNS
=============================================================

4.1 Authentication

All endpoints require a valid Bearer JWT token in the Authorization header. The token is issued by the MSIL Identity Provider (IdP) upon successful login. The API Gateway validates the token signature, expiry, and issuer before forwarding the request to the application layer.

Token claims used by the application:
- sub: User identifier (chauffeurId, coordinatorId, or system service account)
- roles: Array of role strings (e.g. COORDINATOR, CHAUFFEUR, SYSTEM, ADMIN)
- dealershipCode: Dealership identifier for data scoping
- exp: Token expiry timestamp
- iat: Token issued-at timestamp

4.2 Authorization

Role definitions:
- COORDINATOR: Pickup Coordinator; can manage appointments, view dashboards, log contact attempts, trigger reassignments, and manage drop requests.
- CHAUFFEUR: Field chauffeur; can update own schedule, record arrivals, submit vehicle condition data, and manage own trips.
- SYSTEM: Internal service account used by orchestration services, delay detection, and scheduled jobs.
- ADMIN: System administrator; full read access to all resources and audit trails.
- CRM_WEBHOOK: Special role for inbound CRM webhook calls; restricted to the webhook endpoint only.

Data scoping rules:
- COORDINATOR role is scoped to their assigned dealershipCode. They cannot access data from other dealerships.
- CHAUFFEUR role is scoped to their own chauffeurId. They cannot access other chauffeurs' data.
- SYSTEM role has cross-dealership access for orchestration purposes.
- ADMIN role has read-only cross-dealership access.

4.3 Rate Limiting

Default rate limits applied at the API Gateway level:
- Standard endpoints: 100 requests per minute per authenticated user
- OTP generation: 5 requests per 10 minutes per appointmentReference (to prevent OTP flooding)
- Map API proxy endpoints: 60 requests per minute per user (to manage upstream Map API quota)
- Webhook inbound: 500 requests per minute per source IP (CRM system IP whitelisted)
- Health check endpoints: 300 requests per minute (unauthenticated or service-account only)

Rate limit response: HTTP 429 Too Many Requests with Retry-After header.

4.4 Request Correlation and Tracing

Every inbound request must include or will be assigned a correlation ID:
- Header name: X-Correlation-ID
- If not provided by the caller, the API Gateway generates a UUID v4 and injects it.
- The correlation ID is propagated to all downstream service calls and included in all log entries and audit events.
- The correlation ID is returned in the response header X-Correlation-ID.

4.5 Idempotency

Endpoints that create or mutate resources support idempotency via the Idempotency-Key header:
- Header name: Idempotency-Key
- Value: UUID v4 provided by the caller
- The server stores the response for idempotent requests for 24 hours.
- If the same Idempotency-Key is received within 24 hours, the stored response is returned without re-executing the operation.
- Applicable to: POST endpoints for appointment creation, OTP generation, assignment dispatch, drop request creation, trip status transitions, and notification dispatch.

4.6 Pagination

All list endpoints support cursor-based or offset-based pagination:
- Query parameters: page (integer, default 1), pageSize (integer, default 20, max 100)
- Response envelope includes: data (array), pagination object with totalCount, page, pageSize, totalPages, hasNextPage, hasPreviousPage.

4.7 Versioning

API version is embedded in the URL path as /api/v1/. Breaking changes will increment the version to /api/v2/. Non-breaking additions (new optional fields, new endpoints) do not require a version increment.

4.8 Content Type

All request and response bodies use application/json unless otherwise specified (e.g. multipart/form-data for image uploads).

4.9 Timezone Handling

All datetime fields are in ISO 8601 format with UTC timezone (e.g. 2025-07-15T10:30:00Z). The API does not accept or return local time without timezone offset. Conversion to local time is the responsibility of the consuming client.

4.10 Soft Deletes

Resources are not hard-deleted from the database. Deletion operations set a deletedAt timestamp and a status of CANCELLED or DELETED. Soft-deleted records are excluded from list queries by default but can be included with the includeDeleted=true query parameter where applicable.


=============================================================
SECTION 5: DATA MODELS AND DOMAIN ENTITIES
=============================================================

5.1 Appointment

Fields:
- appointmentId (UUID, primary key)
- appointmentNumber (string, unique, human-readable reference, e.g. APT-2025-001234)
- crmAppointmentId (string, CRM system reference)
- jcNumber (string, Job Card number from CRM)
- customerId (string, CRM customer reference)
- customerName (string)
- customerPhone (string, E.164 format)
- customerEmail (string, optional)
- vehicleRegistration (string)
- vehicleVIN (string)
- vehicleMake (string)
- vehicleModel (string)
- vehicleYear (integer)
- pickupAddress (Address object)
- dealershipCode (string)
- dealershipName (string)
- dealershipAddress (Address object)
- scheduledPickupDateTime (ISO 8601 datetime)
- promisedDeliveryDateTime (ISO 8601 datetime, optional)
- status (enum: PENDING, ALLOCATED, IN_PROGRESS, COMPLETED, CANCELLED, RESCHEDULED)
- allocationStatus (enum: UNALLOCATED, RECOMMENDATION_PENDING, DISPATCHED, ACCEPTED, REJECTED, TIMED_OUT, REASSIGNING)
- assignedChauffeurId (UUID, nullable)
- assignedChauffeurName (string, nullable)
- eta (ISO 8601 datetime, nullable)
- exceptionFlag (boolean, default false)
- exceptionReason (string, nullable)
- linkedDropRequestId (UUID, nullable)
- cancellationReason (string, nullable)
- cancellationSource (enum: COORDINATOR, CUSTOMER, SYSTEM, nullable)
- rescheduleCount (integer, default 0)
- createdAt (ISO 8601 datetime)
- updatedAt (ISO 8601 datetime)
- deletedAt (ISO 8601 datetime, nullable)
- createdBy (string, user reference)
- updatedBy (string, user reference)

5.2 Address (Value Object)

Fields:
- line1 (string)
- line2 (string, optional)
- city (string)
- state (string)
- pincode (string, 6-digit Indian postal code)
- latitude (decimal, -90 to 90)
- longitude (decimal, -180 to 180)

5.3 Chauffeur

Fields:
- chauffeurId (UUID, primary key)
- employeeId (string, HR system reference)
- name (string)
- phone (string, E.164 format)
- dealershipCode (string)
- licenseNumber (string)
- licenseExpiry (date)
- status (enum: AVAILABLE, ON_TRIP, OFF_DUTY, SUSPENDED)
- currentLatitude (decimal, nullable)
- currentLongitude (decimal, nullable)
- lastLocationUpdate (ISO 8601 datetime, nullable)
- operatingDays (array of enum: MON, TUE, WED, THU, FRI, SAT, SUN)
- operatingHoursStart (time, HH:MM format)
- operatingHoursEnd (time, HH:MM format)
- startingLocationLatitude (decimal)
- startingLocationLongitude (decimal)
- startingLocationAddress (string)
- createdAt (ISO 8601 datetime)
- updatedAt (ISO 8601 datetime)

5.4 AssignmentRecommendation

Fields:
- recommendationId (UUID, primary key)
- appointmentId (UUID, foreign key)
- roundNumber (integer, starts at 1)
- recommendedChauffeurId (UUID)
- recommendedChauffeurName (string)
- recommendationScore (decimal)
- estimatedETA (ISO 8601 datetime)
- suggestedStartTime (ISO 8601 datetime)
- distanceKm (decimal)
- status (enum: PENDING, DISPATCHED, ACCEPTED, REJECTED, TIMED_OUT, SUPERSEDED)
- rejectionReason (string, nullable)
- dispatchedAt (ISO 8601 datetime, nullable)
- respondedAt (ISO 8601 datetime, nullable)
- timeoutAt (ISO 8601 datetime, nullable)
- createdAt (ISO 8601 datetime)
- updatedAt (ISO 8601 datetime)

5.5 Trip

Fields:
- tripId (UUID, primary key)
- appointmentId (UUID, foreign key)
- tripType (enum: PICKUP, DROP)
- chauffeurId (UUID)
- vehicleRegistration (string)
- status (enum: SCHEDULED, IN_PROGRESS, COMPLETED, CANCELLED, DELAYED)
- delayFlag (boolean, default false)
- delayReason (string, nullable)
- delayDetectedAt (ISO 8601 datetime, nullable)
- delayDurationMinutes (integer, nullable)
- currentLatitude (decimal, nullable)
- currentLongitude (decimal, nullable)
- suggestedStartTime (ISO 8601 datetime, nullable)
- actualStartTime (ISO 8601 datetime, nullable)
- estimatedArrivalTime (ISO 8601 datetime, nullable

ENDPOINT: POST /api/v1/assignment-recommendations/rerun

Source Requirement IDs: SER-010-020-014, SER-010-020-102


------------------------------------------------------------------------
SECTION 1 - ENDPOINT OVERVIEW
------------------------------------------------------------------------

Path            : /api/v1/assignment-recommendations/rerun
HTTP Method     : POST
Summary         : Re-run recommendation after rejection or timeout; increments round number and returns next candidate
Description     : Triggers a new recommendation evaluation cycle for an appointment or Job Card (JC) reference that is in a failed-assignment or no-match state. Each invocation increments the round number, excludes the previously recommended or assigned chauffeur from the candidate pool, re-evaluates all remaining eligible chauffeurs against availability, workload, dealership mapping, and travel time criteria, and returns either a recommended replacement chauffeur (read-only) or a no-match indicator. The operation is not idempotent by design; each successful invocation creates a new recommendation attempt record.


------------------------------------------------------------------------
SECTION 2 - REQUEST SPECIFICATION
------------------------------------------------------------------------

2.1 Request Headers

Header Name       : Authorization
Required          : Yes
Format            : Bearer <JWT token>
Description       : OAuth2 / OIDC Bearer JWT. Must be valid, unexpired, and issued by the trusted identity provider. Token must carry the PICKUP_COORDINATOR role claim.

Header Name       : Content-Type
Required          : Yes
Allowed Value     : application/json
Description       : Request body must be JSON-encoded.

Header Name       : Accept
Required          : No (recommended)
Allowed Value     : application/json
Description       : Indicates the caller expects a JSON response.

Header Name       : X-Correlation-ID
Required          : No (recommended)
Format            : UUID v4
Description       : Caller-supplied correlation identifier for distributed tracing. If absent, the system generates one and includes it in the response.


2.2 Path Parameters

None.


2.3 Query Parameters

None.


2.4 Request Body Schema

Content-Type: application/json

Field Name            Type      Required   Constraints / Validation Rules
--------------------  --------  ---------  -------------------------------------------------------
appointmentReference  string    Conditional  Required if jcReference is absent. Min length 1, max length 100. Alphanumeric with hyphens allowed. Must reference an existing appointment record in failed-assignment state.
jcReference           string    Conditional  Required if appointmentReference is absent. Min length 1, max length 100. Alphanumeric with hyphens allowed. Must reference an existing JC record in failed-assignment state. At least one of appointmentReference or jcReference must be present; both may be supplied if they refer to the same linked record.
failureType           string    Yes          Enumerated value. Accepted values: CHAUFFEUR_DECLINED, CHAUFFEUR_UNAVAILABLE, NO_MATCH, TIMEOUT. Any value outside this set is rejected with 422.
previousChauffeurId   string    Yes          Min length 1, max length 100. Identifier of the chauffeur from the prior recommendation round who is to be excluded. Must correspond to a known chauffeur record.

Example Request Body:

appointmentReference : APT-2024-00891
jcReference          : JC-2024-00345
failureType          : CHAUFFEUR_DECLINED
previousChauffeurId  : CHF-00712


------------------------------------------------------------------------
SECTION 3 - RESPONSE SPECIFICATION
------------------------------------------------------------------------

3.1 HTTP 200 - Successful Rerun (Match Found)

Description: The recommendation engine found at least one eligible candidate. The top-ranked replacement chauffeur is returned as a read-only result.

Response Body Fields:

Field Name                    Type      Description
----------------------------  --------  -------------------------------------------------------
status                        string    Fixed value: SUCCESS
recommendationResult          string    Fixed value: MATCH
appointmentReference          string    Echo of the appointment reference from the request.
jcReference                   string    Echo of the JC reference from the request (if supplied).
roundNumber                   integer   The newly created round number for this rerun attempt.
recommendedChauffeurId        string    Read-only. Identifier of the top-ranked replacement chauffeur selected by the engine.
rerunTimestamp                string    ISO 8601 UTC timestamp at which the engine completed evaluation.
correlationId                 string    Correlation identifier for tracing.

Example Response (Match):

status                 : SUCCESS
recommendationResult   : MATCH
appointmentReference   : APT-2024-00891
jcReference            : JC-2024-00345
roundNumber            : 2
recommendedChauffeurId : CHF-00834
rerunTimestamp         : 2024-11-15T09:42:17Z
correlationId          : 3fa85f64-5717-4562-b3fc-2c963f66afa6


3.2 HTTP 200 - Successful Rerun (No Match Found)

Description: The recommendation engine completed evaluation but found zero eligible candidates after applying all filters. The appointment is set to pending-manual-assignment and the Pickup Coordinator is notified.

Response Body Fields:

Field Name                    Type      Description
----------------------------  --------  -------------------------------------------------------
status                        string    Fixed value: SUCCESS
recommendationResult          string    Fixed value: NO_MATCH
appointmentReference          string    Echo of the appointment reference.
jcReference                   string    Echo of the JC reference (if supplied).
roundNumber                   integer   The newly created round number for this rerun attempt.
recommendedChauffeurId        string    Null or absent. No candidate was selected.
appointmentStatus             string    Fixed value: PENDING_MANUAL_ASSIGNMENT
rerunTimestamp                string    ISO 8601 UTC timestamp.
correlationId                 string    Correlation identifier for tracing.

Example Response (No Match):

status                 : SUCCESS
recommendationResult   : NO_MATCH
appointmentReference   : APT-2024-00891
jcReference            : JC-2024-00345
roundNumber            : 2
recommendedChauffeurId : null
appointmentStatus      : PENDING_MANUAL_ASSIGNMENT
rerunTimestamp         : 2024-11-15T09:42:19Z
correlationId          : 3fa85f64-5717-4562-b3fc-2c963f66afa6


3.3 HTTP 400 - Bad Request

Description: The request body is malformed, missing required fields, or fails structural validation before business rule evaluation.

Response Body Fields:

Field Name   Type      Description
-----------  --------  -------------------------------------------------------
status       string    Fixed value: ERROR
errorCode    string    Machine-readable error code.
message      string    Human-readable description of the validation failure.
details      array     List of field-level validation errors (field name, issue description).
correlationId string   Correlation identifier.

Example Response:

status        : ERROR
errorCode     : VALIDATION_ERROR
message       : Request body failed schema validation.
details       :
  - field: failureType, issue: Field is required and must not be blank.
  - field: previousChauffeurId, issue: Field is required and must not be blank.
correlationId : 3fa85f64-5717-4562-b3fc-2c963f66afa6


3.4 HTTP 401 - Unauthorised

Description: The Bearer JWT is absent, expired, malformed, or issued by an untrusted provider.

Example Response:

status        : ERROR
errorCode     : UNAUTHORISED
message       : Authentication token is missing, expired, or invalid.
correlationId : 3fa85f64-5717-4562-b3fc-2c963f66afa6


3.5 HTTP 403 - Forbidden

Description: The authenticated caller does not hold the PICKUP_COORDINATOR role.

Example Response:

status        : ERROR
errorCode     : ACCESS_DENIED
message       : Access denied. Only Pickup Coordinators may trigger a recommendation rerun.
correlationId : 3fa85f64-5717-4562-b3fc-2c963f66afa6


3.6 HTTP 404 - Not Found

Description: The referenced appointment or JC record does not exist, or exists but is not in a failed-assignment state.

Example Response:

status        : ERROR
errorCode     : RECORD_NOT_FOUND
message       : Referenced appointment or JC record not found or is not in a failed-assignment state.
correlationId : 3fa85f64-5717-4562-b3fc-2c963f66afa6


3.7 HTTP 409 - Conflict

Description: A concurrent rerun request for the same appointment or JC reference is already in progress. The optimistic lock on the recommendation attempt sequence could not be acquired.

Example Response:

status        : ERROR
errorCode     : CONCURRENT_RERUN_CONFLICT
message       : A rerun is already in progress for this appointment or JC reference. Please wait for the current rerun to complete before retrying.
correlationId : 3fa85f64-5717-4562-b3fc-2c963f66afa6


3.8 HTTP 422 - Unprocessable Entity

Description: The request is structurally valid but fails business rule validation. Covers unrecognised failure type or inactive/unmapped dealership.

Example Response (Invalid Failure Type):

status        : ERROR
errorCode     : INVALID_FAILURE_TYPE
message       : Invalid or missing failure type. Provide a recognised failure category.
correlationId : 3fa85f64-5717-4562-b3fc-2c963f66afa6

Example Response (Dealership Mapping Invalid):

status        : ERROR
errorCode     : INVALID_DEALERSHIP_MAPPING
message       : Dealership mapping is invalid or inactive. Cannot execute recommendation rerun.
correlationId : 3fa85f64-5717-4562-b3fc-2c963f66afa6


3.9 HTTP 500 - Internal Server Error

Description: An unexpected server-side error occurred that is not attributable to a specific downstream dependency failure.

Example Response:

status        : ERROR
errorCode     : INTERNAL_SERVER_ERROR
message       : An unexpected error occurred. Please contact support with the correlation ID.
correlationId : 3fa85f64-5717-4562-b3fc-2c963f66afa6


3.10 HTTP 503 - Service Unavailable

Description: A mandatory downstream service (Chauffeur Availability Service, Map API, or Audit Trail Service) is unavailable after exhausting retry attempts. The rerun is aborted and no recommendation attempt record is persisted (or the transaction is rolled back if the audit service failed after persistence).

Example Response (Map API Unavailable):

status        : ERROR
errorCode     : DOWNSTREAM_UNAVAILABLE
message       : Travel time computation unavailable. Recommendation rerun could not be completed. Please retry.
failedService : MAP_API
correlationId : 3fa85f64-5717-4562-b3fc-2c963f66afa6

Example Response (Audit Service Unavailable):

status        : ERROR
errorCode     : DOWNSTREAM_UNAVAILABLE
message       : Audit trail service is unavailable. The rerun transaction has been rolled back to preserve audit integrity.
failedService : AUDIT_TRAIL_SERVICE
correlationId : 3fa85f64-5717-4562-b3fc-2c963f66afa6


------------------------------------------------------------------------
SECTION 4 - BUSINESS RULES
------------------------------------------------------------------------

BR-1  Category: Pre-condition
      Trigger : POST /api/v1/assignment-recommendations/rerun is invoked.
      Rule    : A valid failed assignment or request reference must exist before a recommendation rerun can be triggered. The system validates that the referenced appointment or JC reference exists and is in a failed-assignment state before proceeding.
      Error   : Referenced appointment or JC record not found or is not in a failed-assignment state.
      Code    : 404

BR-2  Category: Validation
      Trigger : Rerun request payload contains a failure type field.
      Rule    : The failure type supplied in the rerun request must correspond to a recognised failure category (CHAUFFEUR_DECLINED, CHAUFFEUR_UNAVAILABLE, NO_MATCH, TIMEOUT). The system rejects the request if the failure type is unrecognised or absent.
      Error   : Invalid or missing failure type. Provide a recognised failure category.
      Code    : 422

BR-3  Category: Business
      Trigger : Previous chauffeur reference is present in the rerun context.
      Rule    : The recommendation engine must exclude the previously assigned or recommended chauffeur from the candidate pool during a rerun to avoid re-recommending a chauffeur who already failed or declined. The previous chauffeur is added to the exclusion list for this rerun round; the engine selects from remaining eligible candidates only.
      Error   : None (internal enforcement; no caller-facing error unless previousChauffeurId is missing, which is caught by schema validation).

BR-4  Category: Business
      Trigger : Recommendation engine executes a rerun for a failed assignment.
      Rule    : Candidate chauffeurs are evaluated against declared availability, blocked slots, current workload, dealership mapping, location proximity, and estimated travel time. Only chauffeurs who pass all eligibility criteria are included in the ranked candidate list.
      Error   : None (internal filtering logic; no-match result is returned if all candidates are filtered out).

BR-5  Category: Business
      Trigger : A rerun is triggered for an appointment or JC reference that already has one or more prior recommendation rounds.
      Rule    : The rerun round number must be incremented by 1 relative to the previous round number recorded against the appointment or JC reference. The system reads the current round number from existing recommendation history and persists the new attempt with round number equal to previous round number plus

ENDPOINT DESIGN DOCUMENT
=========================

Endpoint: GET /api/v1/otp-verifications
Source Requirements: SER-010-020-036, SER-010-020-047


---------------------------------------------------------------------------
SECTION 1: ENDPOINT IDENTIFICATION
---------------------------------------------------------------------------

Path            : /api/v1/otp-verifications
HTTP Method     : GET
Summary         : List OTP verification records with filtering by appointment
                  reference, action type, status, and date range; supports
                  pagination.
Description     : Retrieves and verifies an OTP record associated with a given
                  appointment or session reference. Although implemented as a
                  GET operation, this endpoint carries state-mutating side
                  effects: on a successful match the OTP record is transitioned
                  to VERIFIED status, the appointment workflow is advanced to
                  the next configured step, and an immutable audit entry is
                  written. On a failed match the failed-attempt counter is
                  incremented. The endpoint serves two workflow contexts:
                  (a) standard appointment booking gate at step
                  SER-010-020-036, which advances the workflow to
                  SER-010-020-037; and (b) controlled override gate at step
                  SER-010-020-047, which advances the workflow to
                  SER-010-020-048 or SER-010-020-134 depending on the override
                  branch. Access is restricted to users holding the
                  PICKUP_COORDINATOR, ADMIN, or INTEGRATION_SERVICE role.


---------------------------------------------------------------------------
SECTION 2: REQUEST SPECIFICATION
---------------------------------------------------------------------------

2.1 Request Headers
-------------------

Header Name       : Authorization
Required          : Yes
Format            : Bearer <JWT token>
Description       : OAuth2 / OIDC Bearer token. Must be a valid, non-expired
                    JWT signed by the trusted issuer. The token must carry
                    role claims that include at least one of
                    PICKUP_COORDINATOR, ADMIN, or INTEGRATION_SERVICE.
                    The sub claim is extracted as the acting user identity
                    for audit purposes.

Header Name       : Content-Type
Required          : No (GET request; no body)
Accepted Value    : Not applicable.

Header Name       : Accept
Required          : No
Accepted Value    : application/json (default assumed if omitted)

Header Name       : X-Correlation-ID
Required          : No
Format            : UUID v4 string
Description       : Optional caller-supplied correlation identifier for
                    distributed tracing. If supplied, it is echoed back in
                    the response header and included in audit log entries.


2.2 Path Parameters
-------------------

None. This endpoint does not use path parameters.


2.3 Query Parameters
--------------------

Parameter Name  : appointmentId
Type            : string
Required        : Yes (mutually exclusive with sessionReference; at least one
                  must be supplied; if both are supplied, appointmentId takes
                  precedence)
Format          : Alphanumeric string, maximum 64 characters
Regex           : ^[A-Za-z0-9_-]{1,64}$
Description     : The unique identifier of the appointment for which OTP
                  verification is being requested. Used to locate the
                  corresponding OTP record in the OTP store.
Validation      : Must not be null or empty. Must conform to the regex above.
                  Leading and trailing whitespace is stripped before lookup.

Parameter Name  : sessionReference
Type            : string
Required        : Conditionally required if appointmentId is not supplied
Format          : Alphanumeric string, maximum 128 characters
Regex           : ^[A-Za-z0-9_-]{1,128}$
Description     : Alternative session-scoped reference token that maps to an
                  appointment. Used in integration flows where the appointment
                  ID is not directly available to the caller.
Validation      : Must not be null or empty when used. Must conform to the
                  regex above.

Parameter Name  : otpValue
Type            : string
Required        : Yes
Format          : Numeric string, exactly 6 digits
Regex           : ^\d{6}$
Description     : The OTP value supplied by the end user or integration
                  service for verification against the stored OTP record.
Validation      : Must be exactly 6 numeric characters. Must not contain
                  spaces, letters, or special characters. Submitted value is
                  compared in constant-time against the stored value to
                  prevent timing-based enumeration.

Parameter Name  : overrideReason
Type            : string
Required        : Conditionally required when the verification is being
                  performed in a controlled override context
                  (i.e., workflow step SER-010-020-047)
Format          : Free text string, minimum 10 characters, maximum 500
                  characters
Description     : Human-readable justification for the controlled override
                  action. Must be supplied when the caller intends to branch
                  the workflow to SER-010-020-048 or SER-010-020-134. If the
                  OTP record context indicates an override scenario and this
                  field is absent, the request is rejected with 422.
Validation      : When present, must be between 10 and 500 characters
                  inclusive. HTML tags and script injection patterns are
                  sanitised server-side. Must not consist solely of whitespace.

Parameter Name  : status
Type            : string (enum)
Required        : No
Allowed Values  : PENDING, VERIFIED, INVALIDATED
Description     : Optional filter to restrict the returned list to OTP records
                  in a specific status. When omitted, records in all statuses
                  are eligible for return subject to other filters.

Parameter Name  : fromDate
Type            : string
Required        : No
Format          : ISO 8601 date-time (UTC), e.g. 2024-06-01T00:00:00Z
Description     : Lower bound (inclusive) for filtering OTP records by
                  creation or event timestamp. Must be earlier than or equal
                  to toDate when both are supplied.

Parameter Name  : toDate
Type            : string
Required        : No
Format          : ISO 8601 date-time (UTC), e.g. 2024-06-30T23:59:59Z
Description     : Upper bound (inclusive) for filtering OTP records by
                  creation or event timestamp. Must be later than or equal
                  to fromDate when both are supplied.

Parameter Name  : page
Type            : integer
Required        : No
Default         : 1
Minimum         : 1
Description     : 1-based page number for paginated result sets.

Parameter Name  : pageSize
Type            : integer
Required        : No
Default         : 20
Minimum         : 1
Maximum         : 100
Description     : Number of records to return per page. Values outside the
                  allowed range are rejected with 400.


2.4 Request Body
----------------

Not applicable. This is a GET endpoint and does not accept a request body.
Any body content supplied by the caller is ignored.


---------------------------------------------------------------------------
SECTION 3: RESPONSE SPECIFICATION
---------------------------------------------------------------------------

3.1 HTTP 200 - Successful Verification / Record Retrieval
----------------------------------------------------------

Returned when the OTP value matches the stored record and all pre-conditions
are satisfied, or when a filtered list query returns results successfully.

Response Body Schema:

Field                        : verificationId
Type                         : string (UUID)
Description                  : System-generated unique identifier for this
                               verification event.

Field                        : appointmentReference
Type                         : string
Description                  : The appointment or session reference that was
                               verified.

Field                        : status
Type                         : string (enum)
Possible Values              : VERIFIED
Description                  : Resulting status of the OTP record after
                               successful verification.

Field                        : workflowStepAdvancedTo
Type                         : string
Description                  : The workflow step identifier to which the
                               appointment has been advanced.
                               Example values: SER-010-020-037,
                               SER-010-020-048, SER-010-020-134.

Field                        : verifiedAt
Type                         : string (ISO 8601 UTC date-time)
Description                  : Server timestamp at which verification was
                               completed.

Field                        : actorId
Type                         : string
Description                  : The sub claim from the JWT of the user who
                               performed the verification.

Field                        : overrideReasonRecorded
Type                         : boolean
Description                  : True if an override reason was captured and
                               persisted against the appointment record;
                               false otherwise.

Field                        : auditEntryId
Type                         : string (UUID)
Description                  : Reference identifier of the audit log entry
                               created for this verification event.

Field                        : pagination (present only for list queries)
Type                         : object
Sub-fields                   :
    page         integer     Current page number
    pageSize     integer     Records per page
    totalRecords integer     Total matching records across all pages
    totalPages   integer     Total number of pages

Example Payload (single verification success):

verificationId          : "a3f7c821-0b4e-4d2a-9c1f-3e8b5d6a7f90"
appointmentReference    : "APT-20240601-00123"
status                  : "VERIFIED"
workflowStepAdvancedTo  : "SER-010-020-037"
verifiedAt              : "2024-06-01T10:32:45Z"
actorId                 : "usr-pickup-coord-0042"
overrideReasonRecorded  : false
auditEntryId            : "b9e2d104-5f3c-4a8e-bc7d-1a2f3e4d5c6b"


3.2 HTTP 400 - Bad Request
--------------------------

Returned when required query parameters are missing, fail format validation,
or when the supplied OTP value does not match the stored value (BR-3).

Response Body Schema:

Field           : errorCode
Type            : string
Description     : Machine-readable error code.

Field           : errorMessage
Type            : string
Description     : Human-readable description of the error.

Field           : fieldErrors
Type            : array of objects
Description     : Present when the error relates to specific field-level
                  validation failures. Each object contains:
    field       : string  - Name of the failing query parameter
    message     : string  - Specific validation failure description
    rejectedValue : string - The value that was rejected (masked for OTP)

Field           : timestamp
Type            : string (ISO 8601 UTC)
Description     : Server timestamp of the error response.

Field           : correlationId
Type            : string
Description     : Echoed X-Correlation-ID if supplied; system-generated
                  otherwise.

Example Payload (OTP mismatch - BR-3):

errorCode       : "OTP_MISMATCH"
errorMessage    : "OTP mismatch. Verification failed."
fieldErrors     : []
timestamp       : "2024-06-01T10:33:10Z"
correlationId   : "c1d2e3f4-a5b6-7890-abcd-ef1234567890"

Example Payload (missing required parameter):

errorCode       : "VALIDATION_ERROR"
errorMessage    : "One or more request parameters failed validation."
fieldErrors     :
    - field         : "otpValue"
      message       : "otpValue is required and must be a 6-digit numeric string."
      rejectedValue : null
timestamp       : "2024-06-01T10:33:12Z

ENDPOINT DESIGN: GET /api/v1/vehicle-condition-reports
==============================================================


SECTION 1: ENDPOINT IDENTIFICATION
------------------------------------

Path            : /api/v1/vehicle-condition-reports
HTTP Method     : GET
Summary         : List Vehicle Condition Reports with filtering and pagination
Description     : Retrieves a paginated list of vehicle condition reports that were captured and persisted during the appointment booking stage (SER-010-020). Each report contains the vehicle number, pickup time, captured concerns, condition images served via secure time-limited URLs, and a secure read-only record link. Results are scoped to the caller's authorised access level. Customer-scoped callers receive only reports linked to their own appointments. Pickup Coordinators, Admins, and Integration Services receive reports within their operational scope. No mutation of any report record occurs as a result of this operation.

Source Requirement IDs : SER-010-020-080
Source Activity IDs    : SER-010-020-080


SECTION 2: REQUEST SPECIFICATION
-----------------------------------

2.1 Request Headers

Header Name       : Authorization
Required          : Yes
Format            : Bearer <JWT token>
Description       : OAuth2 / OIDC Bearer JWT issued by the authorised identity provider. Token must be non-expired, have a valid signature, and carry a recognised issuer and audience claim.

Header Name       : Accept
Required          : No (defaults to application/json)
Allowed Values    : application/json
Description       : Specifies the expected response media type.

Header Name       : X-Correlation-ID
Required          : No
Format            : UUID v4 string
Description       : Optional caller-supplied correlation identifier for distributed tracing. If absent, the system generates one internally and includes it in the response.


2.2 Query Parameters

Parameter Name    : appointmentId
Location          : Query string
Required          : No
Type              : String
Format            : Alphanumeric, max length 64 characters
Validation        : Must match pattern ^[A-Za-z0-9_-]{1,64}$. Malformed values result in HTTP 400.
Description       : Filters results to reports associated with the specified appointment identifier.

Parameter Name    : vehicleRegistration
Location          : Query string
Required          : No
Type              : String
Format            : Alphanumeric with optional hyphens, max length 20 characters
Validation        : Must match pattern ^[A-Za-z0-9\-]{1,20}$. Malformed values result in HTTP 400.
Description       : Filters results to reports for the specified vehicle registration number.

Parameter Name    : tripReference
Location          : Query string
Required          : No
Type              : String
Format            : Alphanumeric, max length 64 characters
Validation        : Must match pattern ^[A-Za-z0-9_-]{1,64}$. Malformed values result in HTTP 400.
Description       : Filters results to reports associated with the specified trip reference.

Parameter Name    : jcNumber
Location          : Query string
Required          : No
Type              : String
Format            : Alphanumeric, max length 32 characters
Validation        : Must match pattern ^[A-Za-z0-9_-]{1,32}$. Malformed values result in HTTP 400.
Description       : Filters results to reports associated with the specified job card number.

Parameter Name    : fromDate
Location          : Query string
Required          : No
Type              : String
Format            : ISO 8601 date, YYYY-MM-DD
Validation        : Must be a valid calendar date. Must not be later than toDate if both are supplied. Malformed values result in HTTP 400.
Description       : Inclusive lower bound of the pickup time date range filter.

Parameter Name    : toDate
Location          : Query string
Required          : No
Type              : String
Format            : ISO 8601 date, YYYY-MM-DD
Validation        : Must be a valid calendar date. Must not be earlier than fromDate if both are supplied. Maximum range span between fromDate and toDate is 365 days. Malformed values result in HTTP 400.
Description       : Inclusive upper bound of the pickup time date range filter.

Parameter Name    : pageSize
Location          : Query string
Required          : No
Type              : Integer
Default           : 20
Minimum           : 1
Maximum           : 100
Validation        : Must be a positive integer within the stated range. Non-integer or out-of-range values result in HTTP 400.
Description       : Number of report records to return per page.

Parameter Name    : pageToken
Location          : Query string
Required          : No
Type              : String
Format            : Opaque cursor string returned by a prior response
Validation        : Must be a non-empty string if supplied. Invalid or tampered tokens result in HTTP 400.
Description       : Pagination cursor for retrieving the next page of results. Omit for the first page.


2.3 Request Body

Not applicable. This is a GET operation and carries no request body.


SECTION 3: RESPONSE SPECIFICATION
------------------------------------

3.1 HTTP 200 - Success

Description : The query executed successfully. A paginated list of vehicle condition reports matching the caller's scope and applied filters is returned. An empty data array is returned when no records match; this is not an error condition.

Response Body Schema:

Field                          : data
Type                           : Array of VehicleConditionReport objects
Required                       : Yes
Description                    : Ordered list of vehicle condition report records. May be empty.

Field                          : data[].reportId
Type                           : String (UUID)
Required                       : Yes
Description                    : Unique identifier for the vehicle condition report record.

Field                          : data[].appointmentId
Type                           : String
Required                       : Yes
Description                    : Identifier of the appointment with which this report is associated.

Field                          : data[].customerId
Type                           : String
Required                       : Yes
Description                    : Identifier of the customer who owns the appointment.

Field                          : data[].vehicleNumber
Type                           : String
Required                       : Yes
Description                    : Vehicle registration or fleet number as captured at the time of the condition session.

Field                          : data[].pickupTime
Type                           : String (ISO 8601 datetime, UTC)
Required                       : Yes
Description                    : Timestamp of the vehicle pickup as recorded in the condition report.

Field                          : data[].capturedConcerns
Type                           : Array of String
Required                       : Yes
Description                    : List of concern descriptions recorded during the vehicle condition session. May be an empty array if no concerns were noted.

Field                          : data[].conditionImages
Type                           : Array of String (URL)
Required                       : Yes
Description                    : List of secure, time-limited pre-signed URLs pointing to condition image assets in object storage. May be an empty array if no images were captured. If URL generation fails for one or more images, the affected entries are returned as empty strings and the remainder of the record is still returned.

Field                          : data[].secureRecordLink
Type                           : String (URL)
Required                       : Yes
Description                    : A secure, read-only, access-controlled URL providing access to the full immutable condition report record. Write operations via this link are not permitted.

Field                          : data[].createdAt
Type                           : String (ISO 8601 datetime, UTC)
Required                       : Yes
Description                    : Timestamp at which the condition report record was persisted.

Field                          : pagination
Type                           : Object
Required                       : Yes
Description                    : Pagination metadata for the result set.

Field                          : pagination.pageSize
Type                           : Integer
Required                       : Yes
Description                    : Number of records returned in this page.

Field                          : pagination.nextPageToken
Type                           : String or null
Required                       : Yes
Description                    : Opaque cursor for retrieving the next page. Null when no further pages exist.

Field                          : pagination.totalCount
Type                           : Integer
Required                       : Yes
Description                    : Total number of records matching the query across all pages.

Field                          : meta
Type                           : Object
Required                       : Yes
Description                    : Response metadata.

Field                          : meta.correlationId
Type                           : String (UUID)
Required                       : Yes
Description                    : Correlation identifier echoed from the request header or system-generated if not supplied.

Field                          : meta.timestamp
Type                           : String (ISO 8601 datetime, UTC)
Required                       : Yes
Description                    : Server-side timestamp at which the response was composed.

Example HTTP 200 Payload (non-empty result):

  data:
    - reportId: "rpt-00a1b2c3-d4e5-6789-abcd-ef0123456789"
      appointmentId: "appt-1234567890"
      customerId: "cust-9876543210"
      vehicleNumber: "AB12 CDE"
      pickupTime: "2025-06-15T08:30:00Z"
      capturedConcerns:
        - "Scratch on rear bumper"
        - "Minor dent on driver door"
      conditionImages:
        - "https://storage.example.com/vcr/img001.jpg?token=xyz&expires=1750000000"
        - "https://storage.example.com/vcr/img002.jpg?token=abc&expires=1750000000"
      secureRecordLink: "https://records.example.com/vcr/rpt-00a1b2c3?token=readonly-token"
      createdAt: "2025-06-15T08:35:00Z"
  pagination:
    pageSize: 20
    nextPageToken: null
    totalCount: 1
  meta:
    correlationId: "corr-11112222-3333-4444-5555-666677778888"
    timestamp: "2025-06-15T09:00:00Z"

Example HTTP 200 Payload (empty result):

  data: []
  pagination:
    pageSize: 20
    nextPageToken: null
    totalCount: 0
  meta:
    correlationId: "corr-aaaabbbb-cccc-dddd-eeee-ffffgggghhhh"
    timestamp: "2025-06-15T09:01:00Z"


3.2 HTTP 400 - Bad Request

Description : One or more query parameters are malformed, out of range, or logically inconsistent (e.g. fromDate is later than toDate).

Response Body Schema:

Field          : error.code
Type           : String
Value          : BAD_REQUEST

Field          : error.message
Type           : String
Description    : Human-readable description of the validation failure.

Field          : error.details
Type           : Array of objects
Description    : Per-parameter validation error details.

Field          : error.details[].field
Type           : String
Description    : Name of the offending query parameter.

Field          : error.details[].issue
Type           : String
Description    : Description of the specific validation failure for that parameter.

Field          : meta.correlationId
Type           : String (UUID)

Example HTTP 400 Payload:

  error:
    code: "BAD_REQUEST"
    message: "Bad Request: one or more filter parameters are invalid or malformed."
    details

ENDPOINT: POST /api/v1/appointments/{appointmentId}/dispatch-assignment

Source Requirement IDs: SER-010-020-007
Source Activity IDs: SER-010-020-007


------------------------------------------------------------------------
SECTION 1: ENDPOINT OVERVIEW
------------------------------------------------------------------------

Path            : /api/v1/appointments/{appointmentId}/dispatch-assignment
HTTP Method     : POST
Summary         : Dispatch chauffeur assignment request to Chauffeur app via CRM integration
Description     : Triggers the dispatch assignment workflow for a confirmed/scheduled appointment
                  that has a resolved chauffeur assignment. The operation forwards the chauffeur
                  assignment request from the CRM integration layer to the Chauffeur mobile app,
                  transitions the appointment status to dispatched, and appends an immutable audit
                  trail entry. This endpoint is invoked by the Pickup Coordinator stage
                  (SER-010-020) and must not be called more than once per appointment in a
                  non-dispatched state. It is the authoritative trigger for the downstream
                  notification chain that informs the assigned chauffeur of their pickup
                  responsibilities.


------------------------------------------------------------------------
SECTION 2: REQUEST SPECIFICATION
------------------------------------------------------------------------

2.1 Request Headers

Header Name       Required   Type     Description
Authorization     Yes        String   Bearer JWT token issued by the OAuth2/OIDC provider.
                                      Format: "Bearer <token>"
                                      The token must be valid, non-expired, and carry a
                                      principal with one of the permitted roles.
Content-Type      No         String   Not required for this endpoint as there is no request
                                      body. If supplied, must be "application/json".
X-Correlation-ID  No         String   Optional caller-supplied correlation identifier for
                                      distributed tracing. If absent, the system generates
                                      one internally and includes it in the response.
Accept            No         String   Defaults to "application/json" if not supplied.


2.2 Path Parameters

Parameter Name   Required   Type     Format    Description
appointmentId    Yes        String   UUID v4   The unique identifier of the appointment for
                                               which the dispatch assignment is being
                                               triggered. Must be a valid UUID. Non-UUID
                                               values result in a 400 Bad Request.

Validation Rules for appointmentId:
  - Must be present; absence results in a 404 at the routing layer.
  - Must conform to UUID v4 format (8-4-4-4-12 hexadecimal pattern).
  - Must reference an existing appointment record; non-existent values result in 404.
  - Must not be empty or whitespace.


2.3 Query Parameters

None. This endpoint does not accept query parameters.


2.4 Request Body

None. This is a POST operation that acts as a command trigger. All necessary data is
resolved server-side from the appointment record and the authenticated principal. No
request body is expected or processed. If a body is supplied, it is silently ignored.


------------------------------------------------------------------------
SECTION 3: RESPONSE SPECIFICATION
------------------------------------------------------------------------

3.1 HTTP 200 OK — Successful Dispatch Assignment

Returned when the dispatch assignment has been successfully created, the appointment
status has been transitioned to dispatched, the CRM integration call has completed,
the Chauffeur app notification has been delivered, and the audit trail entry has been
enqueued.

Response Body Schema:

Field                        Type      Required   Description
status                       String    Yes        Fixed value: "success"
data                         Object    Yes        Container for dispatch assignment details
data.dispatchAssignmentId    String    Yes        UUID of the newly created dispatch
                                                  assignment record
data.appointmentId           String    Yes        UUID of the appointment that was dispatched
data.chauffeurId             String    Yes        UUID of the chauffeur assigned and notified
data.dispatchedAt            String    Yes        ISO 8601 UTC timestamp of when the dispatch
                                                  was recorded (e.g., "2025-06-15T10:30:00Z")
data.appointmentStatus       String    Yes        Updated appointment status; value: "dispatched"
data.crmForwardStatus        String    Yes        Outcome of the CRM integration call;
                                                  value: "forwarded"
data.chauffeurNotified       Boolean   Yes        True if the Chauffeur app notification was
                                                  successfully delivered
meta                         Object    Yes        Metadata container
meta.correlationId           String    Yes        Correlation ID for tracing (caller-supplied
                                                  or system-generated)
meta.requestTimestamp        String    Yes        ISO 8601 UTC timestamp of when the request
                                                  was received

Example Payload (200 OK):

status: "success"
data:
  dispatchAssignmentId: "d4e5f6a7-b8c9-4d0e-a1f2-3b4c5d6e7f8a"
  appointmentId: "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
  chauffeurId: "c9d8e7f6-a5b4-3c2d-1e0f-9a8b7c6d5e4f"
  dispatchedAt: "2025-06-15T10:30:00Z"
  appointmentStatus: "dispatched"
  crmForwardStatus: "forwarded"
  chauffeurNotified: true
meta:
  correlationId: "corr-xyz-001"
  requestTimestamp: "2025-06-15T10:29:58Z"


3.2 HTTP 400 Bad Request — Invalid Request Format

Returned when the appointmentId path parameter does not conform to the expected UUID v4
format or the request is otherwise malformed.

Response Body Schema:

Field              Type      Description
status             String    Fixed value: "error"
error              Object    Error detail container
error.code         String    Machine-readable error code
error.message      String    Human-readable description of the error
error.field        String    The field or parameter that failed validation (if applicable)
meta.correlationId String    Correlation ID for tracing

Example Payload (400 Bad Request):

status: "error"
error:
  code: "INVALID_REQUEST"
  message: "The appointmentId path parameter must be a valid UUID v4."
  field: "appointmentId"
meta:
  correlationId: "corr-xyz-002"


3.3 HTTP 401 Unauthorized — Missing or Invalid Authentication

Returned when the Authorization header is absent, the Bearer token is malformed,
expired, or cannot be validated by the identity provider.

Response Body Schema:

Field              Type      Description
status             String    Fixed value: "error"
error.code         String    "UNAUTHORIZED"
error.message      String    Human-readable authentication failure description
meta.correlationId String    Correlation ID for tracing

Example Payload (401 Unauthorized):

status: "error"
error:
  code: "UNAUTHORIZED"
  message: "Authentication token is missing, expired, or invalid."
meta:
  correlationId: "corr-xyz-003"


3.4 HTTP 403 Forbidden — Insufficient Authorization

Returned when the authenticated principal does not hold the PICKUP_COORDINATOR or
INTEGRATION_SERVICE role, or does not have dispatch authority over the specific
appointment (ownership/assignment context validation fails).

Response Body Schema:

Field              Type      Description
status             String    Fixed value: "error"
error.code         String    "FORBIDDEN"
error.message      String    Human-readable authorization failure description
meta.correlationId String    Correlation ID for tracing

Example Payload (403 Forbidden):

status: "error"
error:
  code: "FORBIDDEN"
  message: "You do not have the required role or permissions to dispatch this appointment."
meta:
  correlationId: "corr-xyz-004"


3.5 HTTP 404 Not Found — Appointment Does Not Exist

Returned when no appointment record can be located for the supplied appointmentId.
Corresponds to Business Rule BR-1.

Response Body Schema:

Field              Type      Description
status             String    Fixed value: "error"
error.code         String    "APPOINTMENT_NOT_FOUND"
error.message      String    Human-readable description
meta.correlationId String    Correlation ID for tracing

Example Payload (404 Not Found):

status: "error"
error:
  code: "APPOINTMENT_NOT_FOUND"
  message: "Appointment not found for the provided appointmentId."
meta:
  correlationId: "corr-xyz-005"


3.6 HTTP 409 Conflict — Duplicate Dispatch Assignment

Returned when the appointment has already been dispatched (i.e., its status is
"dispatched" or "in-progress"), preventing a duplicate dispatch assignment.
Corresponds to Business Rule BR-6 and the idempotency policy.

Response Body Schema:

Field                        Type      Description
status                       String    Fixed value: "error"
error.code                   String    "DISPATCH_ALREADY_EXISTS"
error.message                String    Human-readable conflict description
error.existingDispatch       Object    Summary of the existing dispatch record
error.existingDispatch.dispatchAssignmentId  String  UUID of the existing dispatch record
error.existingDispatch.dispatchedAt          String  ISO 8601 timestamp of original dispatch
error.existingDispatch.chauffeurId           String  UUID of the already-assigned chauffeur
meta.correlationId           String    Correlation ID for tracing

Example Payload (409 Conflict):

status: "error"
error:
  code: "DISPATCH_ALREADY_EXISTS"
  message: "Dispatch assignment already exists for this appointment."
  existingDispatch:
    dispatchAssignmentId: "d4e5f6a7-b8c9-4d0e-a1f2-3b4c5d6e7f8a"
    dispatchedAt: "2025-06-15T09:00:00Z"
    chauffeurId: "c9d8e7f6-a5b4-3c2d-1e0f-9a8b7c6d5e4f"
meta:
  correlationId: "corr-xyz-006"


3.7 HTTP 422 Unprocessable Entity — Business Validation Failure

Returned in two distinct scenarios:
  (a) The appointment exists but is in a state that does not permit dispatch
      (e.g., cancelled, completed, or any state other than confirmed/scheduled).
  (b) The appointment exists and is in a valid state but has no chauffeur assigned.
Corresponds to Business Rules BR-1 (state variant) and BR-2.

Response Body Schema:

Field              Type      Description
status             String    Fixed value: "error"
error.code         String    "UNPROCESSABLE_APPOINTMENT" or "NO_CHAUFFEUR_ASSIGNED"
error.message      String    Human-readable description of the specific validation failure
error.currentState String    The current state of the appointment (for state-related errors)
meta.correlationId String    Correlation ID for tracing

Example Payload (422 — Invalid State):

status: "error"
error:
  code: "UNPROCESSABLE_APPOINTMENT"
  message: "The appointment is in a state that does not permit dispatch assignment."
  currentState: "cancelled"

ENDPOINT: GET /api/v1/assignment-recommendations/{appointmentId}/history

Source Requirement IDs: SER-010-020-014, SER-010-020-102
Source Activity IDs: SER-010-020-014, SER-010-020-102

--------------------------------------------------------------------------------
SECTION 1: ENDPOINT IDENTIFICATION
--------------------------------------------------------------------------------

Path            : /api/v1/assignment-recommendations/{appointmentId}/history
HTTP Method     : GET
Summary         : Retrieve all recommendation rounds for a given appointment or
                  JC reference for coordinator audit and dashboard display.
Description     : Returns an ordered, immutable list of all recommendation
                  history entries recorded for the specified appointment. Each
                  entry captures the full state of one recommendation round,
                  including the failed assignment reference, previous chauffeur,
                  failure type, candidate evaluation data, and the recommended
                  replacement chauffeur produced by the automated engine. The
                  endpoint is read-only; no data is mutated. An audit log entry
                  is written asynchronously on every successful access.

--------------------------------------------------------------------------------
SECTION 2: REQUEST SPECIFICATION
--------------------------------------------------------------------------------

2.1 Request Headers

Header Name       : Authorization
Required          : Yes
Format            : Bearer <JWT token>
Description       : OAuth2 / OIDC Bearer token. Must be a valid, non-expired JWT
                    signed by the trusted issuer. The token must carry role and
                    dealership-mapping claims used for authorization.

Header Name       : Accept
Required          : No (defaults to application/json)
Allowed Values    : application/json
Description       : Specifies the expected response media type.

Header Name       : X-Correlation-ID
Required          : No
Format            : UUID v4 string
Description       : Optional caller-supplied correlation identifier for
                    distributed tracing. If provided, it is echoed in the
                    response header and included in audit log entries.

2.2 Path Parameters

Parameter Name    : appointmentId
Location          : Path
Required          : Yes
Type              : String
Format            : Non-empty string; must conform to the system appointment
                    identifier format (alphanumeric, hyphens permitted,
                    maximum 64 characters).
Validation Rules  :
  - Must not be null or empty.
  - Must not exceed 64 characters.
  - Must match pattern: ^[a-zA-Z0-9\-]{1,64}$
  - Must correspond to an existing appointment record (validated at runtime
    against the Appointment Repository).
Description       : The unique identifier of the appointment for which
                    recommendation history is being retrieved.

2.3 Query Parameters

None defined for this endpoint.

2.4 Request Body

Not applicable. This is a GET operation; no request body is accepted.

--------------------------------------------------------------------------------
SECTION 3: RESPONSE SPECIFICATION
--------------------------------------------------------------------------------

3.1 HTTP 200 - Success

Description       : The request was processed successfully. The response body
                    contains an ordered array of recommendation history entries
                    for the specified appointment. If no recommendation rounds
                    have been executed, the history array is empty.

Response Body Schema (top-level object):

  Field Name      : appointmentId
  Type            : String
  Required        : Yes
  Description     : The appointment identifier echoed from the path parameter.

  Field Name      : history
  Type            : Array of RecommendationHistoryEntry objects
  Required        : Yes
  Description     : Ordered list of history entries, sorted ascending by
                    rerunTimestamp (earliest round first). May be an empty
                    array if no rounds have been executed.

RecommendationHistoryEntry object fields:

  Field Name                      : failedAssignmentReference
  Type                            : String
  Required                        : Yes
  Description                     : Reference identifier of the failed
                                    assignment or request that triggered this
                                    recommendation round.

  Field Name                      : appointmentOrJcReference
  Type                            : String
  Required                        : Yes
  Description                     : The appointment or Job Card (JC) reference
                                    associated with this history entry.

  Field Name                      : previousChauffeur
  Type                            : String
  Required                        : Yes
  Description                     : Identifier of the chauffeur who held the
                                    assignment prior to the failure event.

  Field Name                      : failureType
  Type                            : String
  Required                        : Yes
  Allowed Values                  : CHAUFFEUR_UNAVAILABLE, BLOCKED_SLOT,
                                    WORKLOAD_EXCEEDED, LOCATION_CONSTRAINT,
                                    TRAVEL_TIME_CONSTRAINT, NO_CANDIDATE_MATCH,
                                    OTHER
  Description                     : The specific reason the prior assignment or
                                    recommendation round failed. Captured at the
                                    time of the failure event and returned
                                    verbatim.

  Field Name                      : roundNumber
  Type                            : Integer
  Required                        : Yes
  Minimum                         : 1
  Description                     : Sequential round number, unique per
                                    appointment. Increments by 1 with each
                                    re-run of the recommendation engine for
                                    this appointment.

  Field Name                      : candidateChauffeur
  Type                            : String
  Required                        : Yes
  Description                     : Identifier of the chauffeur evaluated as a
                                    candidate during this recommendation round.

  Field Name                      : declaredAvailability
  Type                            : String
  Required                        : Yes
  Description                     : The declared availability status of the
                                    candidate chauffeur at the time of
                                    evaluation.

  Field Name                      : dealershipMapping
  Type                            : String
  Required                        : Yes
  Description                     : The dealership identifier to which this
                                    history entry is scoped.

  Field Name                      : blockedSlots
  Type                            : Array of String
  Required                        : Yes
  Description                     : List of time slot identifiers that were
                                    blocked for the candidate chauffeur at the
                                    time of evaluation. May be an empty array.

  Field Name                      : workload
  Type                            : String or Numeric (as stored)
  Required                        : Yes
  Description                     : The workload metric recorded for the
                                    candidate chauffeur at the time of
                                    evaluation.

  Field Name                      : location
  Type                            : String
  Required                        : Yes
  Description                     : The location of the candidate chauffeur
                                    recorded at the time of evaluation.

  Field Name                      : travelTime
  Type                            : String or Numeric (as stored)
  Required                        : Yes
  Description                     : The estimated travel time recorded for the
                                    candidate chauffeur to reach the appointment
                                    location.

  Field Name                      : recommendationOrNoMatchResult
  Type                            : String
  Required                        : Yes
  Allowed Values                  : RECOMMENDED, NO_MATCH
  Description                     : The outcome of the recommendation engine
                                    for this round. Indicates whether a
                                    suitable replacement was found or no match
                                    was available.

  Field Name                      : rerunTimestamp
  Type                            : String
  Format                          : ISO 8601 datetime (UTC), e.g.
                                    2024-06-15T10:30:00Z
  Required                        : Yes
  Description                     : The UTC timestamp at which this
                                    recommendation round was executed or
                                    re-executed. Used as the primary sort key
                                    for ordering history entries.

  Field Name                      : recommendedReplacementChauffeur
  Type                            : String or null
  Required                        : Yes
  Read-Only                       : Yes
  Description                     : The identifier of the chauffeur recommended
                                    as a replacement by the automated engine for
                                    this round. Null if the result was NO_MATCH.
                                    This field is read-only and cannot be
                                    modified via any endpoint.

Example 200 Response Payload (non-empty history):

  appointmentId: "APPT-2024-00123"
  history:
    - failedAssignmentReference: "ASGN-9901"
      appointmentOrJcReference: "JC-4421"
      previousChauffeur: "CHF-0055"
      failureType: "CHAUFFEUR_UNAVAILABLE"
      roundNumber: 1
      candidateChauffeur: "CHF-0078"
      declaredAvailability: "AVAILABLE"
      dealershipMapping: "DLR-007"
      blockedSlots: []
      workload: "3"
      location: "North Depot"
      travelTime: "25"
      recommendationOrNoMatchResult: "RECOMMENDED"
      rerunTimestamp: "2024-06-15T08:00:00Z"
      recommendedReplacementChauffeur: "CHF-0078"
    - failedAssignmentReference: "ASGN-9901"
      appointmentOrJcReference: "JC-4421"
      previousChauffeur: "CHF-0055"
      failureType: "WORKLOAD_EXCEEDED"
      roundNumber: 2
      candidateChauffeur: "CHF-0091"
      declaredAvailability: "AVAILABLE"
      dealershipMapping: "DLR-007"
      blockedSlots: ["SLOT-AM-02"]
      workload: "5"
      location: "South Depot"
      travelTime: "40"
      recommendationOrNoMatchResult: "NO_MATCH"
      rerunTimestamp: "2024-06-15T09:15:00Z"
      recommendedReplacementChauffeur: null

Example 200 Response Payload (empty history):

  appointmentId: "APPT-2024-00456"
  history: []

3.2 HTTP 400 - Bad Request

Description       : The request is malformed or the appointmentId path parameter
                    fails format validation.

Response Body Schema:

  Field Name      : errorCode
  Type            : String
  Description     : Machine-readable error code.

  Field Name      : message
  Type            : String
  Description     : Human-readable description of the validation failure.

  Field Name      : details
  Type            : Array of String
  Description     : List of specific field-level validation errors.

Example 400 Response Payload:

  errorCode: "VALIDATION_ERROR"
  message: "The appointmentId path parameter is invalid."
  details:
    - "appointmentId must not be empty."
    - "appointmentId must match pattern ^[a-zA-Z0-9\\-]{1,64}$."

3.3 HTTP 401 - Unauthorized

Description       : The request does not include a valid Bearer JWT token, the
                    token has expired, or the token signature cannot be verified.

Example 401 Response Payload:

  errorCode: "UNAUTHORIZED"
  message: "Authentication is required. Provide a valid Bearer JWT token."
  details: []

3.4 HTTP 403 - Forbidden

Description       : The caller is authenticated but is not authorized to access
                    history for the specified appointment. This occurs when a
                    Pickup Coordinator requests history for an appointment that
                    does not belong to their dealership mapping, or when the
                    caller's role is not in the permitted set.

Example 403 Response Payload:

  errorCode: "FORBIDDEN"
  message: "Access denied. You are not authorized to view history for this appointment."
  details: []

3.5 HTTP 404 - Not Found

Description       : The appointmentId path parameter is well-formed but does not
                    correspond to any existing appointment record in the system.

Example 404 Response Payload:

  errorCode: "NOT_FOUND"
  message: "Appointment not found for the provided appointmentId."
  details:
    - "appointmentId: APPT-2024-99999 does not exist."

3.6 HTTP 500 - Internal Server Error

Description       : An unexpected error occurred within the service

ENDPOINT DESIGN: POST /api/v1/assignment-recommendations/drop

Source Requirement ID: SER-010-020-095
Source Activity ID: SER-010-020-095

================================================================================
SECTION 1: ENDPOINT IDENTIFICATION
================================================================================

Path            : /api/v1/assignment-recommendations/drop
HTTP Method     : POST
Summary         : Trigger recommendation engine for a drop assignment; returns ranked
                  chauffeur recommendation with ETA and suggested start time.
Description     : Invokes the internal recommendation engine to compute and return a
                  suggested chauffeur for the drop leg of a given appointment. The
                  engine evaluates chauffeur availability, proximity, and scheduling
                  constraints, then calls the Map API to derive a system-computed ETA.
                  The result is a non-binding suggestion surfaced to the Pickup
                  Coordinator for review. No chauffeur assignment is committed by this
                  operation. The recommendation is persisted or cached to support the
                  subsequent assignment confirmation step (SER-010-020-096).

================================================================================
SECTION 2: REQUEST SPECIFICATION
================================================================================

2.1 Request Headers
--------------------------------------------------------------------------------
Header Name       : Authorization
Required          : Yes
Format            : Bearer <JWT>
Description       : OAuth2 / OIDC Bearer token issued by the authorised identity
                    provider. Must be valid, unexpired, and carry the required role
                    claim. Absence, malformation, or expiry causes immediate rejection
                    with HTTP 401 before any downstream service is contacted.

Header Name       : Content-Type
Required          : Yes
Accepted Value    : application/json
Description       : Request body must be JSON-encoded.

Header Name       : Accept
Required          : No (recommended)
Accepted Value    : application/json
Description       : Signals that the caller expects a JSON response.

Header Name       : X-Correlation-ID
Required          : No (recommended)
Format            : UUID v4
Description       : Caller-supplied correlation identifier for distributed tracing.
                    If absent, the gateway generates one. Echoed in the response
                    header of the same name.

2.2 Path Parameters
--------------------------------------------------------------------------------
None.

2.3 Query Parameters
--------------------------------------------------------------------------------
None.

2.4 Request Body Schema
--------------------------------------------------------------------------------
Content-Type : application/json
Root Object  : DropRecommendationRequest

Field Name           : appointmentReference
JSON Type            : string
Required             : Yes
Format               : Alphanumeric with hyphens; must conform to the internal
                       appointment reference format (e.g., APT-YYYYMMDD-XXXXXXXX).
Minimum Length       : 10 characters
Maximum Length       : 64 characters
Pattern (regex)      : ^[A-Za-z0-9\-]{10,64}$
Description          : The unique reference identifier of the drop appointment for
                       which a chauffeur recommendation is being requested. Must
                       correspond to an existing, active drop appointment record in
                       the appointment store. Caller-supplied ETA values are not
                       accepted and will be ignored if present; ETA is exclusively
                       system-computed (BR-3).

2.5 Request Body Example
--------------------------------------------------------------------------------
{
  "appointmentReference": "APT-20240815-DR004821"
}

================================================================================
SECTION 3: RESPONSE SPECIFICATION
================================================================================

3.1 HTTP 200 - Recommendation Successfully Generated
--------------------------------------------------------------------------------
Description : The recommendation engine successfully computed a chauffeur suggestion
              and ETA for the drop leg. No assignment has been committed.

Response Body Schema (DropRecommendationResponse):

Field Name                    : appointmentReference
JSON Type                     : string
Description                   : Echo of the appointment reference supplied in the
                                 request.

Field Name                    : recommendedChauffeurId
JSON Type                     : string
Description                   : System-generated unique identifier of the recommended
                                 chauffeur for the drop leg.

Field Name                    : recommendedChauffeurName
JSON Type                     : string
Description                   : Display name of the recommended chauffeur.

Field Name                    : eta
JSON Type                     : string
Format                        : ISO 8601 datetime (UTC), e.g., 2024-08-15T14:30:00Z
Description                   : System-computed estimated time of arrival for the
                                 recommended chauffeur at the drop pickup location.
                                 This field is read-only; callers cannot supply or
                                 override it (BR-3).

Field Name                    : generatedAt
JSON Type                     : string
Format                        : ISO 8601 datetime (UTC)
Description                   : Timestamp at which the recommendation was generated
                                 by the system.

Field Name                    : status
JSON Type                     : string
Allowed Value                 : RECOMMENDATION_GENERATED
Description                   : Indicates the outcome of the recommendation operation.

Example Response Body (HTTP 200):

{
  "appointmentReference": "APT-20240815-DR004821",
  "recommendedChauffeurId": "CHF-00293",
  "recommendedChauffeurName": "James Hartley",
  "eta": "2024-08-15T14:30:00Z",
  "generatedAt": "2024-08-15T13:45:22Z",
  "status": "RECOMMENDATION_GENERATED"
}

3.2 HTTP 400 - Bad Request
--------------------------------------------------------------------------------
Description : The request payload is malformed, missing required fields, or field
              values fail validation rules.

Response Body Schema (ErrorResponse):

Field Name    : errorCode
JSON Type     : string
Description   : Machine-readable error code.

Field Name    : message
JSON Type     : string
Description   : Human-readable description of the validation failure.

Field Name    : details
JSON Type     : array of strings
Description   : List of specific field-level validation errors.

Field Name    : timestamp
JSON Type     : string (ISO 8601 UTC)
Description   : Time at which the error was generated.

Example Response Body (HTTP 400):

{
  "errorCode": "VALIDATION_ERROR",
  "message": "Request validation failed.",
  "details": [
    "appointmentReference is required and must not be blank.",
    "appointmentReference must match pattern ^[A-Za-z0-9\\-]{10,64}$."
  ],
  "timestamp": "2024-08-15T13:44:00Z"
}

3.3 HTTP 401 - Unauthorised
--------------------------------------------------------------------------------
Description : The Bearer JWT is absent, malformed, expired, or issued by an
              unrecognised identity provider. No downstream services are contacted
              (BR-6).

Example Response Body (HTTP 401):

{
  "errorCode": "AUTHENTICATION_FAILED",
  "message": "Authentication failed. A valid Bearer JWT is required.",
  "details": [],
  "timestamp": "2024-08-15T13:44:05Z"
}

3.4 HTTP 403 - Forbidden
--------------------------------------------------------------------------------
Description : The authenticated principal does not hold the PICKUP_COORDINATOR or
              ADMIN role required to invoke this endpoint (BR-5).

Example Response Body (HTTP 403):

{
  "errorCode": "ACCESS_DENIED",
  "message": "Access denied. Insufficient role to request drop chauffeur recommendations.",
  "details": [],
  "timestamp": "2024-08-15T13:44:10Z"
}

3.5 HTTP 404 - Not Found
--------------------------------------------------------------------------------
Description : No active drop appointment record exists for the supplied appointment
              reference, or the appointment is not in an eligible state for
              recommendation (BR-1).

Example Response Body (HTTP 404):

{
  "errorCode": "APPOINTMENT_NOT_FOUND",
  "message": "No active drop appointment found for the provided reference.",
  "details": [
    "appointmentReference: APT-20240815-DR004821"
  ],
  "timestamp": "2024-08-15T13:44:15Z"
}

3.6 HTTP 422 - Unprocessable Entity
--------------------------------------------------------------------------------
Description : The appointment reference is valid and the appointment is in an
              eligible state, but the recommendation engine found zero eligible
              chauffeurs available for the drop leg time window (BR-7).

Example Response Body (HTTP 422):

{
  "errorCode": "NO_CHAUFFEUR_AVAILABLE",
  "message": "No eligible chauffeur available for the requested drop appointment slot.",
  "details": [
    "appointmentReference: APT-20240815-DR004821",
    "No chauffeurs matched availability and proximity constraints for the drop window."
  ],
  "timestamp": "2024-08-15T13:44:20Z"
}

3.7 HTTP 503 - Service Unavailable
--------------------------------------------------------------------------------
Description : A required downstream dependency (Chauffeur Scheduling Service or
              Map API) is unavailable after exhausting the configured retry policy
              and circuit-breaker thresholds (BR-8).

Example Response Body (HTTP 503):

{
  "errorCode": "DOWNSTREAM_UNAVAILABLE",
  "message": "ETA computation unavailable due to Map API failure. Please retry.",
  "details": [
    "Map API did not respond after 2 retries.",
    "Please retry the request after a short interval."
  ],
  "timestamp": "2024-08-15T13:44:30Z"
}

3.8 HTTP 500 - Internal Server Error
--------------------------------------------------------------------------------
Description : An unexpected internal error occurred that is not attributable to a
              known downstream failure or validation issue.

Example Response Body (HTTP 500):

{
  "errorCode": "INTERNAL_SERVER_ERROR",
  "message": "An unexpected error occurred. Please contact support if the issue persists.",
  "details": [],
  "timestamp": "2024-08-15T13:44:35Z"
}

================================================================================
SECTION 4: BUSINESS RULES
================================================================================

Rule ID  : BR-1
Category : Pre-condition
Trigger  : POST /api/v1/assignment-recommendations/drop is invoked.
Rule     : A valid, active drop appointment must exist in the appointment store and
           must be in an eligible state (not completed, cancelled, or already
           assigned) before the recommendation engine is invoked.
Behaviour: System queries the appointment store. If no matching active record is
           found, processing halts and HTTP 404 is returned.
Error    : 404 - "No active drop appointment found for the provided reference."

Rule ID  : BR-2
Category : Business
Trigger  : A valid drop appointment reference is supplied and the appointment is in
           an eligible state.
Rule     : The system must automatically compute and return a recommended chauffeur
           for the drop leg based on availability, proximity, and scheduling
           constraints at the time of the request.
Behaviour: The recommendation algorithm executes and returns the top-ranked available
           chauffeur along with the system-computed ETA.
Error    : None (success path).

Rule ID  : BR-3
Category : Business
Trigger  : Recommendation response is generated for the drop leg.
Rule     : The ETA field is read-only and exclusively system-computed. Callers must
           not supply or override the ETA value. Any caller-supplied ETA in the
           request body is silently ignored.
Behaviour: ETA is derived from the Map API and internal scheduling data only.
Error    : None (caller-supplied ETA is discarded without error).

Rule ID  : BR-4
Category : Business
Trigger  : Recommendation is successfully computed for the drop leg.
Rule     : The recommended chauffeur is a suggestion only. The Pickup Coordinator

ENDPOINT DESIGN: POST /api/v1/map/geofence/check

================================================================================
SECTION 1: ENDPOINT IDENTIFICATION
================================================================================

Path            : /api/v1/map/geofence/check
HTTP Method     : POST
Summary         : Check whether a chauffeur's current GPS coordinates are within
                  the geofence radius of a target location; returns arrival flag
                  used to trigger arrival notifications.
Description     : This endpoint accepts a chauffeur's live GPS coordinates,
                  resolves the active in-progress appointment assigned to that
                  chauffeur, retrieves the registered customer pickup location,
                  and delegates geofence boundary evaluation to the external Map
                  API. Based on the result, the system either dispatches arrival
                  notifications to the customer across ICP, WhatsApp, and SMS
                  channels or returns a non-arrival status. Every evaluation is
                  recorded in an immutable audit trail regardless of outcome.
Source Requirements : SER-010-020-038, SER-010-020-115, SER-010-020-116
Source Activity IDs : SER-010-020-038, SER-010-020-115, SER-010-020-116


================================================================================
SECTION 2: REQUEST SPECIFICATION
================================================================================

2.1 REQUEST HEADERS
--------------------------------------------------------------------------------

Header Name       : Authorization
Required          : Yes
Format            : Bearer <JWT token>
Description       : OAuth2/OIDC Bearer JWT token. Must be valid, non-expired,
                    and contain chauffeur identity claims including role and
                    assigned trip reference.

Header Name       : Content-Type
Required          : Yes
Expected Value    : application/json
Description       : Request body must be submitted as JSON.

Header Name       : Accept
Required          : No
Expected Value    : application/json
Description       : Caller should indicate JSON response preference.

Header Name       : X-Request-ID
Required          : No
Format            : UUID v4
Description       : Optional idempotency/correlation identifier supplied by the
                    caller for tracing purposes. Logged in audit trail if present.

Header Name       : X-Chauffeur-Device-ID
Required          : No
Format            : String, max 64 characters
Description       : Optional device identifier for diagnostic and audit
                    enrichment purposes.


2.2 PATH PARAMETERS
--------------------------------------------------------------------------------

None. This endpoint does not accept path parameters.


2.3 QUERY PARAMETERS
--------------------------------------------------------------------------------

None. This endpoint does not accept query parameters.


2.4 REQUEST BODY SCHEMA
--------------------------------------------------------------------------------

Root Object       : GeofenceCheckRequest

Field Path                              : chauffeurLiveLocation
Type                                    : Object
Required                                : Yes
Description                             : Wrapper object containing the
                                          chauffeur's current GPS coordinates
                                          as reported by the device at the time
                                          of the request.

Field Path                              : chauffeurLiveLocation.latitude
Type                                    : Number (double precision float)
Required                                : Yes
Minimum Value                           : -90.0
Maximum Value                           : 90.0
Must Not Be                             : null, 0.0 (zero is rejected as
                                          indicative of an uninitialised
                                          coordinate)
Format                                  : WGS-84 decimal degrees
Validation Rule                         : Must be a finite numeric value within
                                          the range -90.0 to 90.0 inclusive.
                                          Null, absent, non-numeric, and zero
                                          values are all rejected.
Error Triggered                         : BR-2, HTTP 400

Field Path                              : chauffeurLiveLocation.longitude
Type                                    : Number (double precision float)
Required                                : Yes
Minimum Value                           : -180.0
Maximum Value                           : 180.0
Must Not Be                             : null, 0.0 (zero is rejected as
                                          indicative of an uninitialised
                                          coordinate)
Format                                  : WGS-84 decimal degrees
Validation Rule                         : Must be a finite numeric value within
                                          the range -180.0 to 180.0 inclusive.
                                          Null, absent, non-numeric, and zero
                                          values are all rejected.
Error Triggered                         : BR-2, HTTP 400

Field Path                              : chauffeurLiveLocation.accuracy
Type                                    : Number (float)
Required                                : No
Minimum Value                           : 0.0
Unit                                    : Metres
Description                             : Optional GPS accuracy radius reported
                                          by the device. Logged in audit trail
                                          if present but does not affect
                                          geofence evaluation logic.

Field Path                              : chauffeurLiveLocation.capturedAt
Type                                    : String
Required                                : No
Format                                  : ISO 8601 UTC datetime
                                          (e.g. 2025-06-15T10:30:00Z)
Description                             : Optional timestamp indicating when the
                                          device captured the GPS fix. Logged in
                                          audit trail if present.


2.5 EXAMPLE REQUEST BODY
--------------------------------------------------------------------------------

{
  "chauffeurLiveLocation": {
    "latitude": 25.197197,
    "longitude": 55.274376,
    "accuracy": 8.5,
    "capturedAt": "2025-06-15T10:30:00Z"
  }
}


================================================================================
SECTION 3: RESPONSE SPECIFICATION
================================================================================

3.1 HTTP 200 - SUCCESSFUL GEOFENCE EVALUATION
--------------------------------------------------------------------------------

Condition         : The geofence check was successfully evaluated by the Map API.
                    This response is returned for both inside and outside results.
                    The caller must inspect the geofenceResult field to determine
                    the outcome.

Response Body Schema:

Field                         : requestId
Type                          : String (UUID)
Description                   : Echoes the X-Request-ID if supplied by the
                                 caller; system-generated UUID otherwise.

Field                         : geofenceResult
Type                          : String (Enum)
Allowed Values                : INSIDE, OUTSIDE
Description                   : Indicates whether the chauffeur's submitted
                                 coordinates fall within the geofence boundary
                                 around the customer pickup location.

Field                         : appointmentId
Type                          : String (UUID)
Description                   : The appointment ID resolved from the chauffeur's
                                 active trip assignment against which the
                                 geofence was evaluated.

Field                         : notificationDispatched
Type                          : Boolean
Description                   : True if an arrival notification was dispatched
                                 to the customer as a result of this evaluation.
                                 False if the result was OUTSIDE, if the
                                 notification was already sent for this
                                 appointment (deduplication), or if dispatch
                                 was skipped for any reason.

Field                         : evaluatedAt
Type                          : String (ISO 8601 UTC datetime)
Description                   : Server-side timestamp at which the geofence
                                 evaluation was completed.

Field                         : message
Type                          : String
Description                   : Human-readable summary of the evaluation outcome.

Example Response Body (INSIDE result, notification dispatched):

{
  "requestId": "a3f1c2d4-8b7e-4f2a-9c1d-0e5f6a7b8c9d",
  "geofenceResult": "INSIDE",
  "appointmentId": "b2e4d6f8-1a3c-4e5f-8b9d-2c4e6f8a0b1c",
  "notificationDispatched": true,
  "evaluatedAt": "2025-06-15T10:30:05Z",
  "message": "Chauffeur is within the geofence boundary. Arrival notification dispatched to customer."
}

Example Response Body (OUTSIDE result):

{
  "requestId": "c4d5e6f7-2b3c-4d5e-9f0a-1b2c3d4e5f6a",
  "geofenceResult": "OUTSIDE",
  "appointmentId": "b2e4d6f8-1a3c-4e5f-8b9d-2c4e6f8a0b1c",
  "notificationDispatched": false,
  "evaluatedAt": "2025-06-15T10:30:05Z",
  "message": "Chauffeur is outside the geofence boundary. No notification dispatched."
}

Example Response Body (INSIDE result, notification already sent - deduplicated):

{
  "requestId": "d5e6f7a8-3c4d-5e6f-0a1b-2c3d4e5f6a7b",
  "geofenceResult": "INSIDE",
  "appointmentId": "b2e4d6f8-1a3c-4e5f-8b9d-2c4e6f8a0b1c",
  "notificationDispatched": false,
  "evaluatedAt": "2025-06-15T10:31:10Z",
  "message": "Chauffeur is within the geofence boundary. Arrival notification was already dispatched for this appointment."
}


3.2 HTTP 400 - BAD REQUEST
--------------------------------------------------------------------------------

Condition         : Request payload is malformed, missing required fields, or
                    contains coordinate values that fail WGS-84 validation.
                    Triggered by BR-2.

Field                         : errorCode
Type                          : String
Value                         : INVALID_COORDINATES

Field                         : errorMessage
Type                          : String
Value                         : Invalid or missing live location coordinates.

Field                         : details
Type                          : Array of objects
Description                   : Field-level validation failure details.

Field                         : details[].field
Type                          : String
Description                   : The request field that failed validation.

Field                         : details[].reason
Type                          : String
Description                   : Human-readable explanation of the failure.

Field                         : timestamp
Type                          : String (ISO 8601 UTC)

Example Response Body:

{
  "errorCode": "INVALID_COORDINATES",
  "errorMessage": "Invalid or missing live location coordinates.",
  "details": [
    {
      "field": "chauffeurLiveLocation.latitude",
      "reason": "Latitude must be a non-zero numeric value between -90.0 and 90.0."
    }
  ],
  "timestamp": "2025-06-15T10:30:01Z"
}


3.3 HTTP 401 - UNAUTHORISED
--------------------------------------------------------------------------------

Condition         : Bearer JWT is absent, expired, malformed, or fails signature
                    verification.

Example Response Body:

{
  "errorCode": "UNAUTHORISED",
  "errorMessage": "Authentication token is missing, expired, or invalid.",
  "timestamp": "2025-06-15T10:30:01Z"
}


3.4 HTTP 403 - FORBIDDEN
--------------------------------------------------------------------------------

Condition         : The authenticated principal does not hold the CHAUFFEUR role,
                    or the chauffeur is not the one assigned to the active trip
                    for which the geofence check is being requested. RBAC
                    enforcement prevents cross-chauffeur geofence checks.

Example Response Body:

{
  "errorCode": "FORBIDDEN",
  "errorMessage": "You are not authorised to perform a geofence check for this assignment.",
  "timestamp": "2025-06-15T10:30:01Z"
}


3.5 HTTP 404 - NOT FOUND
--------------------------------------------------------------------------------

Condition         : No active trip assignment can be resolved for the
                    authenticated chauffeur. Triggered by BR-1.

Note              : BR-1 specifies HTTP 422 for this condition. The system

ENDPOINT DESIGN DOCUMENT
=========================

Source Requirement ID : SER-010-020-134
Source Activity ID    : SER-010-020-134


---------------------------------------------------------------------------
1. ENDPOINT IDENTIFICATION
---------------------------------------------------------------------------

Path            : /api/v1/appointments/{appointmentId}/cancel
HTTP Method     : POST
Summary         : Cancel appointment with reason and confirmation source;
                  create CancellationRecord and update status.
Description     : Cancels an existing appointment that is in a non-terminal,
                  cancellable state. The caller must supply a cancellation
                  reason. The system derives the confirmation source from the
                  authenticated JWT principal. On success the appointment
                  status is transitioned to CANCELLED, the assigned chauffeur
                  (if any) is released, an immutable audit entry is written,
                  and downstream notification and integration events are
                  dispatched asynchronously to CRM, DBP, and notification
                  channels (ICP / WhatsApp / SMS).


---------------------------------------------------------------------------
2. REQUEST SPECIFICATION
---------------------------------------------------------------------------

2.1 Request Headers
-------------------

Header Name      : Authorization
Required         : Yes
Format           : Bearer <JWT>
Description      : OAuth2 / OIDC Bearer token. Must be a valid, non-expired
                   JWT issued by the authorised identity provider. The token
                   must carry the principal identity, assigned roles, and
                   any ownership claims required for authorisation checks.

Header Name      : Content-Type
Required         : Yes
Allowed Value    : application/json
Description      : Request body must be JSON-encoded.

Header Name      : Accept
Required         : No
Recommended Value: application/json
Description      : Indicates the client expects a JSON response.

Header Name      : X-Correlation-ID
Required         : No
Format           : UUID v4 string
Description      : Optional caller-supplied correlation identifier for
                   distributed tracing. If absent the system generates one
                   internally and echoes it in the response.

Header Name      : X-Request-ID
Required         : No
Format           : UUID v4 string
Description      : Optional idempotency / deduplication key supplied by the
                   client. Callers are encouraged to supply this on retries
                   to assist server-side duplicate detection.


2.2 Path Parameters
-------------------

Parameter Name   : appointmentId
Location         : Path
Type             : String
Format           : UUID v4
Required         : Yes
Constraints      : Must be a well-formed UUID v4. Must correspond to an
                   existing appointment record in the system.
Example Value    : 3fa85f64-5717-4562-b3fc-2c963f66afa6
Validation Error : If the value is not a valid UUID format, return 400.
                   If no appointment record exists for the value, return 404.


2.3 Query Parameters
--------------------

None defined for this endpoint.


2.4 Request Body Schema
-----------------------

Content-Type : application/json
Required     : Yes

Field Name         : cancellationReason
Type               : String
Required           : Yes
Min Length         : 1 character (must not be blank or whitespace-only)
Max Length         : 1000 characters
Format             : Free-form text; no special character restrictions beyond
                     standard UTF-8 printable characters.
Regex              : Must match pattern ^\s*\S[\s\S]{0,999}$ (i.e. at least
                     one non-whitespace character present).
Description        : Human-readable reason for cancelling the appointment.
                     This value is persisted against the appointment record
                     and included in the audit trail entry.
Validation Error   : If absent, null, empty, or whitespace-only, return 400
                     with error code VALIDATION_ERROR and message
                     "Cancellation reason is mandatory and must not be blank."

Example Request Body:

  {
    "cancellationReason": "Customer requested cancellation due to change in travel plans."
  }


---------------------------------------------------------------------------
3. RESPONSE SPECIFICATION
---------------------------------------------------------------------------

3.1 HTTP 200 OK - Successful Cancellation
------------------------------------------

Returned when the appointment has been successfully transitioned to
CANCELLED state and all synchronous post-conditions have been satisfied.

Response Body Schema:

Field Name              : appointmentId
Type                    : String (UUID v4)
Description             : The unique identifier of the cancelled appointment.

Field Name              : status
Type                    : String (Enum)
Allowed Value           : CANCELLED
Description             : The updated status of the appointment.

Field Name              : cancellationReason
Type                    : String
Description             : The cancellation reason as supplied in the request
                          and persisted against the appointment record.

Field Name              : confirmationSource
Type                    : String
Description             : The identity of the principal who confirmed the
                          cancellation, derived from the JWT token. Represents
                          the Chauffeur, Pickup Coordinator, or Admin actor.

Field Name              : cancellationTimestamp
Type                    : String (ISO 8601 UTC datetime)
Format                  : yyyy-MM-ddTHH:mm:ss.SSSZ
Description             : The system-generated UTC timestamp at which the
                          cancellation was recorded.

Field Name              : chauffeurReleased
Type                    : Boolean
Description             : Indicates whether a previously assigned chauffeur
                          was released and their availability reset to
                          AVAILABLE as part of this cancellation. True if a
                          chauffeur was assigned and has been released; false
                          if no chauffeur was assigned.

Field Name              : correlationId
Type                    : String (UUID v4)
Description             : The correlation identifier for this request, either
                          echoed from the X-Correlation-ID request header or
                          system-generated if not supplied.

Example 200 Response Body:

  {
    "appointmentId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
    "status": "CANCELLED",
    "cancellationReason": "Customer requested cancellation due to change in travel plans.",
    "confirmationSource": "CHAUFFEUR:usr-9821",
    "cancellationTimestamp": "2025-07-14T10:35:22.000Z",
    "chauffeurReleased": true,
    "correlationId": "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
  }


3.2 HTTP 400 Bad Request - Validation Failure
----------------------------------------------

Returned when the request payload fails validation (e.g. missing or blank
cancellationReason, malformed appointmentId UUID, or unresolvable
confirmation source).

Response Body Schema:

Field Name              : errorCode
Type                    : String
Description             : Machine-readable error code.

Field Name              : errorMessage
Type                    : String
Description             : Human-readable description of the validation failure.

Field Name              : fieldErrors
Type                    : Array of objects
Description             : List of field-level validation errors. Each entry
                          contains the field name and the specific violation.

  Sub-field: field
  Type      : String
  Description: The name of the request field that failed validation.

  Sub-field: message
  Type      : String
  Description: Description of the specific validation violation for that field.

Field Name              : correlationId
Type                    : String (UUID v4)
Description             : Correlation identifier for tracing.

Example 400 Response Body (missing cancellationReason):

  {
    "errorCode": "VALIDATION_ERROR",
    "errorMessage": "One or more request fields failed validation.",
    "fieldErrors": [
      {
        "field": "cancellationReason",
        "message": "Cancellation reason is mandatory and must not be blank."
      }
    ],
    "correlationId": "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
  }

Example 400 Response Body (unresolvable confirmation source):

  {
    "errorCode": "VALIDATION_ERROR",
    "errorMessage": "Confirmation source could not be determined. Ensure the request is authenticated with a valid Chauffeur identity.",
    "fieldErrors": [],
    "correlationId": "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
  }


3.3 HTTP 401 Unauthorized - Authentication Failure
---------------------------------------------------

Returned when the Authorization header is absent, the Bearer token is
missing, expired, malformed, or fails signature validation.

Response Body Schema:

Field Name              : errorCode
Type                    : String
Allowed Value           : UNAUTHORIZED
Description             : Machine-readable error code.

Field Name              : errorMessage
Type                    : String
Description             : Human-readable description of the authentication
                          failure.

Field Name              : correlationId
Type                    : String (UUID v4)
Description             : Correlation identifier for tracing.

Example 401 Response Body:

  {
    "errorCode": "UNAUTHORIZED",
    "errorMessage": "Authentication failed. A valid Bearer JWT token is required.",
    "correlationId": "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
  }


3.4 HTTP 403 Forbidden - Authorisation Failure
-----------------------------------------------

Returned when the authenticated principal does not hold a required role
(CHAUFFEUR, PICKUP_COORDINATOR, or ADMIN) or does not have ownership /
assignment rights over the specified appointment.

Response Body Schema:

Field Name              : errorCode
Type                    : String
Allowed Value           : FORBIDDEN
Description             : Machine-readable error code.

Field Name              : errorMessage
Type                    : String
Description             : Human-readable description of the authorisation
                          failure.

Field Name              : correlationId
Type                    : String (UUID v4)
Description             : Correlation identifier for tracing.

Example 403 Response Body:

  {
    "errorCode": "FORBIDDEN",
    "errorMessage": "You do not have permission to cancel this appointment.",
    "correlationId": "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
  }


3.5 HTTP 404 Not Found - Appointment Not Found
-----------------------------------------------

Returned when no appointment record exists for the supplied appointmentId.

Response Body Schema:

Field Name              : errorCode
Type                    : String
Allowed Value           : NOT_FOUND
Description             : Machine-readable error code.

Field Name              : errorMessage
Type                    : String
Description             : Human-readable description of the not-found
                          condition.

Field Name              : correlationId
Type                    : String (UUID v4)
Description             : Correlation identifier for tracing.

Example 404 Response Body:

  {
    "errorCode": "NOT_FOUND",
    "errorMessage": "Appointment not found for the provided appointmentId.",
    "correlationId": "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
  }


3.6 HTTP 409 Conflict - Non-Cancellable State
----------------------------------------------

Returned when the appointment is already in a terminal state (CANCELLED or
COMPLETED) and cannot be cancelled again. Also returned on idempotent
duplicate cancellation attempts where the appointment is already CANCELLED.

Response Body Schema:

Field Name              : errorCode
Type                    : String
Allowed Value           : CONFLICT
Description             : Machine-readable error code.

Field Name              : errorMessage
Type                    : String
Description             : Human-readable description of the conflict.

Field Name              : currentStatus
Type                    : String
Description             : The current status of the appointment at the time
                          the conflict was detected.

Field Name              : correlationId
Type                    : String (UUID v4)
Description             : Correlation identifier for tracing.

Example 409 Response Body:

  {
    "errorCode": "CONFLICT",
    "errorMessage": "Appointment cannot be cancelled because it is already in a terminal state.",
    "currentStatus": "CANCELLED",
    "correlationId": "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
  }


3.7 HTTP 500 Internal Server Error - Unexpected Failure
--------------------------------------------------------

Returned when an unhandled exception or infrastructure failure occurs during
processing. The appointment state must not be left in an inconsistent
condition; transactional rollback must be applied where the commit has not
yet occurred.

Response Body Schema:

Field Name              : errorCode
Type                    : String
Allowed Value           : INTERNAL_SERVER_ERROR
Description             : Machine-readable error code.

Field Name              : errorMessage
Type                    : String
Description             : Generic human-readable error message. Internal
                          exception details must not be exposed to the caller.

Field Name              : correlationId
Type                    : String (UUID v4)
Description             : Correlation identifier for tracing and incident
                          investigation.

Example

ENDPOINT DESIGN: GET /api/v1/crm/appointments

Source Requirement IDs: SER-010-020-001, SER-010-020-003


------------------------------------------------------------------------
SECTION 1: ENDPOINT IDENTIFICATION
------------------------------------------------------------------------

Path            : /api/v1/crm/appointments
HTTP Method     : GET
Summary         : List CRM appointments with filters (date range, status,
                  dealership) for dashboard population
Description     : Returns a paginated, filtered list of CRM appointment
                  records scoped to the authenticated caller's authorised
                  view. Each record contains the full set of dashboard
                  fields defined in SER-010-020-003, including customer
                  details (PII-masked), vehicle information, pickup and
                  drop logistics, appointment and allocation status,
                  chauffeur identity, real-time ETA, exception flags, and
                  linked Job Card (JC) and promised delivery time where
                  available. This is a read-only operation; no state
                  mutations or audit entries are produced.


------------------------------------------------------------------------
SECTION 2: REQUEST SPECIFICATION
------------------------------------------------------------------------

2.1 Request Headers

Header Name       Required   Format / Validation
Authorization     Yes        Must be "Bearer <token>". Token must be a
                             valid, non-expired JWT issued by the
                             authorised identity provider. Absence or
                             invalidity results in HTTP 401.
Accept            No         Should be "application/json". Defaults to
                             application/json if omitted.
X-Correlation-ID  No         UUID v4 string. If supplied, echoed back in
                             the response header for distributed tracing.
                             If absent, the service generates one
                             internally.
Content-Type      N/A        Not applicable for GET requests; must not
                             carry a request body.


2.2 Query Parameters

Parameter Name    Required   Type      Format / Validation
fromDate          No         string    ISO 8601 date: YYYY-MM-DD.
                                       Represents the start of the pickup
                                       date range filter (inclusive).
                                       Must not be after toDate if both
                                       are supplied.
toDate            No         string    ISO 8601 date: YYYY-MM-DD.
                                       Represents the end of the pickup
                                       date range filter (inclusive).
                                       Must not be before fromDate if
                                       both are supplied.
status            No         string    Enumerated value. Permitted values:
                                       PENDING, ALLOCATED, ASSIGNED,
                                       DECLINED, REASSIGNED, COMPLETED,
                                       EXCEPTION. Multiple values may be
                                       supplied as comma-separated list.
                                       Invalid values result in HTTP 400.
dealershipId      No         string    Alphanumeric identifier for the
                                       dealership scope. Max length 50
                                       characters. If omitted, defaults
                                       to the caller's authorised
                                       dealership scope derived from the
                                       JWT claims.
page              No         integer   Minimum: 1. Defaults to 1 if
                                       omitted. Must be a positive
                                       integer.
pageSize          No         integer   Minimum: 1. Maximum: 100. Defaults
                                       to 20 if omitted. Controls the
                                       number of records per page.
sortBy            No         string    Permitted values: pickupDate,
                                       appointmentStatus, customerName,
                                       allocationStatus. Defaults to
                                       pickupDate if omitted.
sortOrder         No         string    Permitted values: ASC, DESC.
                                       Defaults to ASC if omitted.

2.3 Path Parameters

None. This endpoint does not use path-level variable segments.

2.4 Request Body

None. GET requests must not include a request body. Any body supplied
will be ignored.


------------------------------------------------------------------------
SECTION 3: RESPONSE SPECIFICATION
------------------------------------------------------------------------

3.1 HTTP 200 - Success

Description: The appointment list was successfully retrieved. The
response contains a paginated array of appointment records matching the
caller's scope and any applied filters.

Response Headers:
  Content-Type     : application/json
  X-Correlation-ID : Echoed or generated UUID v4 for tracing.

Response Body Schema (top-level object):

Field Name          Type      Required   Description
success             boolean   Yes        Always true for a 200 response.
data                object    Yes        Wrapper object containing the
                                         list and pagination metadata.
data.appointments   array     Yes        Array of Appointment objects.
                                         May be an empty array if no
                                         records match the filters.
data.pagination     object    Yes        Pagination metadata object.
data.pagination
  .totalRecords     integer   Yes        Total number of records matching
                                         the query across all pages.
data.pagination
  .page             integer   Yes        Current page number returned.
data.pagination
  .pageSize         integer   Yes        Number of records per page.
data.pagination
  .totalPages       integer   Yes        Total number of pages available.

Appointment Object Fields:

Field Name               Type      Required   Description
appointmentNumber        string    Yes        Unique appointment
                                              identifier.
customerName             string    Yes        Full name of the customer.
maskedContactReference   string    Yes        Customer contact number in
                                              PII-masked form (e.g. only
                                              last four digits visible,
                                              remainder replaced with
                                              asterisks).
vehicleRegistration      string    Yes        Vehicle registration plate.
vehicleModel             string    Yes        Vehicle make and model
                                              description.
pickupDate               string    Yes        ISO 8601 date: YYYY-MM-DD.
pickupTime               string    Yes        ISO 8601 time: HH:MM:SS.
pickupAddress            string    Cond.      Full pickup address string.
                                              Required when
                                              permittedPickupArea is not
                                              applicable.
permittedPickupArea      string    Cond.      Designated pickup zone or
                                              area identifier. Returned
                                              when a specific address is
                                              not applicable.
dropServiceSelected      boolean   Yes        Indicates whether the
                                              customer has opted for a
                                              drop/return service.
dropAddress              string    Cond.      Drop-off address. Present
                                              only when dropServiceSelected
                                              is true.
dropDate                 string    Cond.      ISO 8601 date: YYYY-MM-DD.
                                              Present only when
                                              dropServiceSelected is true.
dropTime                 string    Cond.      ISO 8601 time: HH:MM:SS.
                                              Present only when
                                              dropServiceSelected is true.
appointmentStatus        string    Yes        Current lifecycle status of
                                              the appointment. Enumerated:
                                              PENDING, ALLOCATED, ASSIGNED,
                                              DECLINED, REASSIGNED,
                                              COMPLETED, EXCEPTION.
allocationStatus         string    Yes        Current chauffeur allocation
                                              state. Enumerated:
                                              UNALLOCATED, RECOMMENDED,
                                              ASSIGNED, DECLINED,
                                              REASSIGNED. Returns last-known
                                              cached value or empty string
                                              if assignment subsystem is
                                              unavailable.
chauffeurName            string    Cond.      Full name of the assigned
                                              chauffeur. Empty string if
                                              no chauffeur is assigned or
                                              subsystem is unavailable.
requestResponseStatus    string    Yes        Status of the chauffeur
                                              request-response cycle.
requestResponseTime      string    Cond.      ISO 8601 datetime of the
                                              last request-response
                                              interaction. Null if not
                                              yet applicable.
currentEta               string    Cond.      ISO 8601 datetime
                                              representing the chauffeur's
                                              current estimated time of
                                              arrival. Empty string if
                                              Map API is unavailable or
                                              chauffeur is not en route.
exceptionFlag            boolean   Yes        True if the appointment has
                                              an active exception condition
                                              (SLA breach, unresolved
                                              allocation issue, or upstream
                                              flag). False otherwise.
linkedJcNumber           string    Cond.      Linked Job Card number from
                                              CRM/DMS. Empty string if not
                                              yet available or CRM/DMS is
                                              unreachable.
promisedDeliveryTime     string    Cond.      ISO 8601 datetime of the
                                              promised vehicle delivery
                                              time from CRM/DMS. Empty
                                              string if not yet available
                                              or CRM/DMS is unreachable.

Example 200 Response Payload:

success: true
data:
  appointments:
    - appointmentNumber: "APT-2024-00451"
      customerName: "Rajesh Kumar"
      maskedContactReference: "******7890"
      vehicleRegistration: "MH12AB3456"
      vehicleModel: "Toyota Camry 2.5 Hybrid"
      pickupDate: "2024-07-15"
      pickupTime: "09:30:00"
      pickupAddress: "42 Marine Drive, Mumbai, 400002"
      permittedPickupArea: ""
      dropServiceSelected: true
      dropAddress: "Andheri Service Centre, Mumbai, 400053"
      dropDate: "2024-07-15"
      dropTime: "18:00:00"
      appointmentStatus: "ASSIGNED"
      allocationStatus: "ASSIGNED"
      chauffeurName: "Suresh Patil"
      requestResponseStatus: "ACCEPTED"
      requestResponseTime: "2024-07-14T16:45:00Z"
      currentEta: "2024-07-15T09:15:00Z"
      exceptionFlag: false
      linkedJcNumber: "JC-2024-88321"
      promisedDeliveryTime: "2024-07-15T17:30:00Z"
    - appointmentNumber: "APT-2024-00452"
      customerName: "Priya Sharma"
      maskedContactReference: "******4321"
      vehicleRegistration: "DL01CD7890"
      vehicleModel: "Honda City 1.5 VX"
      pickupDate: "2024-07-15"
      pickupTime: "11:00:00"
      pickupAddress: "7 Connaught Place, New Delhi, 110001"
      permittedPickupArea: ""
      dropServiceSelected: false
      dropAddress: ""
      dropDate: ""
      dropTime: ""
      appointmentStatus: "EXCEPTION"
      allocationStatus: "UNALLOCATED"
      chauffeurName: ""
      requestResponseStatus: "PENDING"
      requestResponseTime: ""
      currentEta: ""
      exceptionFlag: true
      linkedJcNumber: ""
      promisedDeliveryTime: ""
  pagination:
    totalRecords: 47
    page: 1
    pageSize: 20
    totalPages: 3


3.2 HTTP 400 - Bad Request

Description: One or more query parameters failed validation.

Response Body Schema:

Field Name   Type     Description
success      boolean  Always false.
error        object   Error detail wrapper.
error.code   string   Machine-readable error code.
error.message string  Human-readable description of the validation
                      failure.
error.details array   Array of field-level validation error objects,
                      each containing fieldName and reason.

Example 400 Response Payload:

success: false
error:
  code: "VALIDATION_ERROR"
  message: "One or more query parameters are invalid."
  details:
    - fieldName: "fromDate"
      reason: "fromDate must not be after toDate."
    - fieldName: "status"
      reason: "Value 'UNKNOWN_STATUS' is not a permitted status value."


3.3 HTTP 401 -

ENDPOINT DESIGN: POST /api/v1/chauffeurs/{chauffeurId}/contact-attempt-logs

================================================================================
SECTION 1: ENDPOINT IDENTIFICATION
================================================================================

Path            : /api/v1/chauffeurs/{chauffeurId}/contact-attempt-logs
HTTP Method     : POST
Summary         : Log a coordinator contact attempt against a chauffeur capturing
                  outcome, rejection/delay reason, revised ETA, and remarks
Source Requirement IDs : SER-010-020-103, SER-010-020-125
Source Activity IDs    : SER-010-020-103, SER-010-020-125


================================================================================
SECTION 2: REQUEST SPECIFICATION
================================================================================

2.1 REQUEST HEADERS
--------------------------------------------------------------------------------

Header Name       : Authorization
Required          : Yes
Format            : Bearer <JWT token>
Description       : OAuth2/OIDC-issued JWT. Must be valid, unexpired, and contain
                    role and identity claims. Requests without this header or with
                    an invalid/expired token are rejected with 401.

Header Name       : Content-Type
Required          : Yes
Expected Value    : application/json
Description       : Request body must be JSON-encoded. Any other content type
                    results in a 415 Unsupported Media Type response.

Header Name       : Accept
Required          : No
Expected Value    : application/json
Description       : Clients should indicate they accept JSON responses.


2.2 PATH PARAMETERS
--------------------------------------------------------------------------------

Parameter Name  : chauffeurId
Location        : Path
Type            : String (UUID format)
Required        : Yes
Format          : UUID v4 (xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx)
Validation      : Must be a well-formed UUID. Must reference an existing, active
                  chauffeur record in the Chauffeur Profile Service / Master Data
                  Store. Non-existent or inactive chauffeur IDs are rejected.
Error if absent : 400 Bad Request (malformed path)
Error if invalid: 404 Not Found (chauffeur not found or inactive)


2.3 QUERY PARAMETERS
--------------------------------------------------------------------------------

None defined for this endpoint.


2.4 REQUEST BODY SCHEMA
--------------------------------------------------------------------------------

Content-Type    : application/json
Root Type       : Object

Field: appointmentOrJCReference
  Type          : String
  Required      : Yes
  Min Length    : 1
  Max Length    : 100
  Format        : Alphanumeric with hyphens/underscores permitted; no whitespace
  Description   : The appointment/trip or Job Card reference identifier that this
                  contact attempt is being logged against. Must correspond to an
                  existing, open appointment or job card associated with the
                  specified chauffeur.
  Validation    : Non-empty, non-null. Cross-validated against the Appointment /
                  Job Card Service to confirm existence, open/active state, and
                  association with the given chauffeurId.

Field: contactAttemptTimestamp
  Type          : String
  Required      : Yes
  Format        : ISO-8601 datetime with timezone offset
                  (e.g. 2025-07-15T10:30:00+05:30)
  Description   : The date and time at which the Pickup Coordinator made the
                  contact attempt with the chauffeur.
  Validation    : Must be a valid ISO-8601 datetime string. Must not represent a
                  future datetime beyond the current server time at the moment of
                  request processing. Malformed values or future timestamps are
                  rejected with 400.

Field: contactOutcome
  Type          : String (Enumeration)
  Required      : Yes
  Permitted Values:
    - Reached
    - Not Reachable
    - Rejected
    - Delayed
    - Confirmed
  Description   : The outcome of the contact attempt made by the Pickup
                  Coordinator. Drives conditional validation of other fields.
  Validation    : Must be present and must exactly match one of the permitted
                  enumeration values (case-sensitive). Absent or unrecognised
                  values are rejected with 400.

Field: rejectionDelayReason
  Type          : String
  Required      : Conditionally required
  Condition     : Required when contactOutcome is "Rejected" or "Delayed"
  Min Length    : 1 (when provided)
  Max Length    : 500
  Description   : The reason provided by the chauffeur for rejecting the
                  assignment or indicating a delay. Must be non-blank when the
                  outcome is Rejected or Delayed.
  Validation    : When contactOutcome is Rejected or Delayed, this field must be
                  present and non-empty. Absent or blank value under those
                  conditions results in 422. When contactOutcome is any other
                  value, this field is optional and ignored if supplied.

Field: revisedETAOrStartTime
  Type          : String
  Required      : Conditionally required
  Condition     : Required when contactOutcome is "Confirmed" and a revised
                  schedule is being indicated
  Format        : ISO-8601 datetime with timezone offset
  Description   : The revised estimated time of arrival or revised start time
                  agreed upon or communicated during the contact attempt.
  Validation    : When applicable, must be a valid ISO-8601 datetime and must
                  represent a future datetime relative to the current server time.
                  A past or malformed value under this condition results in 422.
                  Optional and ignored when contactOutcome does not indicate a
                  confirmed revised schedule.

Field: otherRemarks
  Type          : String
  Required      : No
  Min Length    : 0
  Max Length    : 1000
  Description   : Free-text remarks or additional notes recorded by the Pickup
                  Coordinator regarding the contact attempt. Optional field.
  Validation    : When provided, must not exceed 1000 characters. Exceeding the
                  limit results in 400. Null or absent is acceptable.


2.5 EXAMPLE REQUEST
--------------------------------------------------------------------------------

POST /api/v1/chauffeurs/f47ac10b-58cc-4372-a567-0e02b2c3d479/contact-attempt-logs
Authorization: Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9...
Content-Type: application/json

Body:
  appointmentOrJCReference  : "APT-2025-007834"
  contactAttemptTimestamp   : "2025-07-15T10:28:00+05:30"
  contactOutcome            : "Delayed"
  rejectionDelayReason      : "Chauffeur reported heavy traffic on the expressway;
                               estimated 20-minute delay."
  revisedETAOrStartTime     : (not provided, outcome is Delayed not Confirmed)
  otherRemarks              : "Coordinator advised chauffeur to take alternate
                               route via Ring Road."


================================================================================
SECTION 3: RESPONSE SPECIFICATION
================================================================================

3.1 HTTP 201 CREATED
--------------------------------------------------------------------------------

Condition       : The contact-attempt log was successfully validated and persisted.
Description     : Returns the newly created log entry with its system-assigned
                  identifier and server-side creation timestamp.

Response Body Fields:

  logId
    Type        : String (UUID)
    Description : System-generated unique identifier for the newly created
                  contact-attempt log entry.
    Example     : "9b1deb4d-3b7d-4bad-9bdd-2b0d7b3dcb6d"

  chauffeurId
    Type        : String (UUID)
    Description : The chauffeur identifier from the path parameter, echoed back
                  for confirmation.
    Example     : "f47ac10b-58cc-4372-a567-0e02b2c3d479"

  appointmentOrJCReference
    Type        : String
    Description : The appointment/trip or JC reference as submitted.
    Example     : "APT-2025-007834"

  contactAttemptTimestamp
    Type        : String (ISO-8601)
    Description : The contact attempt timestamp as submitted and persisted.
    Example     : "2025-07-15T10:28:00+05:30"

  contactOutcome
    Type        : String
    Description : The contact outcome as submitted and persisted.
    Example     : "Delayed"

  rejectionDelayReason
    Type        : String or null
    Description : The rejection/delay reason if applicable; null otherwise.
    Example     : "Chauffeur reported heavy traffic on the expressway."

  revisedETAOrStartTime
    Type        : String (ISO-8601) or null
    Description : The revised ETA or start time if applicable; null otherwise.
    Example     : null

  pickupCoordinatorUser
    Type        : String
    Description : The identity of the authenticated Pickup Coordinator as derived
                  from the JWT token (not caller-supplied).
    Example     : "coord-user-00421"

  otherRemarks
    Type        : String or null
    Description : Free-text remarks if provided; null otherwise.
    Example     : "Coordinator advised chauffeur to take alternate route."

  createdAt
    Type        : String (ISO-8601)
    Description : Server-side timestamp at which the log entry was persisted.
    Example     : "2025-07-15T10:28:45.123+05:30"

Example 201 Response Payload:
  logId                    : "9b1deb4d-3b7d-4bad-9bdd-2b0d7b3dcb6d"
  chauffeurId              : "f47ac10b-58cc-4372-a567-0e02b2c3d479"
  appointmentOrJCReference : "APT-2025-007834"
  contactAttemptTimestamp  : "2025-07-15T10:28:00+05:30"
  contactOutcome           : "Delayed"
  rejectionDelayReason     : "Chauffeur reported heavy traffic on the expressway."
  revisedETAOrStartTime    : null
  pickupCoordinatorUser    : "coord-user-00421"
  otherRemarks             : "Coordinator advised chauffeur to take alternate route."
  createdAt                : "2025-07-15T10:28:45.123+05:30"


3.2 HTTP 400 BAD REQUEST
--------------------------------------------------------------------------------

Condition       : One or more request fields fail basic format or validation rules.
                  Covers: malformed contactAttemptTimestamp, future timestamp,
                  missing or unrecognised contactOutcome, otherRemarks exceeding
                  maximum length, or malformed chauffeurId path parameter.

Response Body Fields:
  status        : 400
  errorCode     : String (e.g. "VALIDATION_ERROR")
  message       : Human-readable description of the validation failure.
  fieldErrors   : Array of objects, each containing:
                    field   : The name of the failing field
                    message : Specific reason for the failure

Example 400 Response Payload:
  status      : 400
  errorCode   : "VALIDATION_ERROR"
  message     : "Request validation failed. See fieldErrors for details."
  fieldErrors :
    - field   : "contactAttemptTimestamp"
      message : "Contact attempt timestamp is invalid or represents a future
                 date/time."
    - field   : "contactOutcome"
      message : "Contact outcome is required and must be a valid outcome value."


3.3 HTTP 401 UNAUTHORIZED
--------------------------------------------------------------------------------

Condition       : The Authorization header is absent, the JWT token is missing,
                  expired, or cannot be validated.

Response Body Fields:
  status        : 401
  errorCode     : "UNAUTHORIZED"
  message       : "Authentication is required. Provide a valid Bearer JWT token."

Example 401 Response Payload:
  status    : 401
  errorCode : "UNAUTHORIZED"
  message   : "Authentication is required. Provide a valid Bearer JWT token."


3.4 HTTP 403 FORBIDDEN
--------------------------------------------------------------------------------

Condition       : The authenticated user does not hold the PICKUP_COORDINATOR
                  role, or the request falls outside the coordinator's operational
                  scope.

Response Body Fields:
  status        : 403
  errorCode     : "FORBIDDEN"
  message       : "Access denied. Only Pickup Coordinators are authorised to
                   create contact-attempt logs."

Example 403 Response Payload:
  status    : 403
  errorCode : "FORBIDDEN"
  message   : "Access denied. Only Pickup Coordinators are authorised to create
               contact-attempt logs."

ENDPOINT DESIGN: GET /api/v1/chauffeurs/{chauffeurId}/contact-attempt-logs

================================================================================
SECTION 1: ENDPOINT IDENTIFICATION
================================================================================

Path            : /api/v1/chauffeurs/{chauffeurId}/contact-attempt-logs
HTTP Method     : GET
Summary         : Retrieve contact attempt logs for a chauffeur across appointments
                  and trips for coordinator review
Description     : Returns the full, immutable, chronologically ordered history of
                  all contact attempt log entries recorded against a specified
                  chauffeur. Log entries span both the initial appointment booking
                  contact phase (SER-010-020-103) and subsequent re-contact or
                  follow-up phases (SER-010-020-125). The operation is read-only
                  and does not mutate any data. An access audit entry is written
                  asynchronously upon every successful retrieval.
Source Activity IDs : SER-010-020-103, SER-010-020-125


================================================================================
SECTION 2: REQUEST SPECIFICATION
================================================================================

2.1 Request Headers
--------------------------------------------------------------------------------
Header Name       Required   Format / Constraints
Authorization     Yes        Must be "Bearer <token>". Token must be a valid,
                             non-expired JWT issued by the authorised OAuth2/OIDC
                             provider. Missing or malformed header results in 401.
Content-Type      No         Not required for GET requests; ignored if present.
Accept            No         Recommended value: application/json. If omitted,
                             application/json is assumed.
X-Request-ID      No         UUID v4 format. If provided, echoed back in the
                             response header for correlation. If not provided,
                             the system generates one internally.
X-Correlation-ID  No         UUID v4 format. Used for distributed tracing across
                             downstream service calls.

2.2 Path Parameters
--------------------------------------------------------------------------------
Parameter Name   Type     Required   Constraints / Validation
chauffeurId      string   Yes        Must be a non-empty string. Must correspond
                                     to an existing chauffeur record in the
                                     Chauffeur Registry. Whitespace-only values
                                     are rejected. No maximum length constraint
                                     is imposed at the API layer; the registry
                                     lookup enforces existence. Invalid or
                                     non-existent values result in 404.

2.3 Query Parameters
--------------------------------------------------------------------------------
None defined for this endpoint. The endpoint returns the full unfiltered log
history for the specified chauffeur. No pagination, date-range filtering, or
field projection parameters are supported in this version.

2.4 Request Body
--------------------------------------------------------------------------------
Not applicable. GET requests carry no request body. Any body present in the
request is ignored.


================================================================================
SECTION 3: RESPONSE SPECIFICATION
================================================================================

3.1 HTTP 200 - Success
--------------------------------------------------------------------------------
Description : The request was processed successfully. The response body contains
              an array of contact attempt log entries for the specified chauffeur,
              ordered by contactAttemptTimestamp in ascending chronological order.
              If no log entries exist for the chauffeur, an empty array is returned
              (not an error condition per BR-6).

Response Body Schema (top-level object):

Field Name         Type     Required   Description
data               array    Yes        Ordered list of ContactAttemptLog objects.
                                       May be an empty array.
meta               object   Yes        Metadata about the response.
meta.chauffeurId   string   Yes        The chauffeurId used in the request.
meta.totalCount    integer  Yes        Total number of log entries returned.
                                       Zero when data array is empty.
meta.retrievedAt   string   Yes        ISO 8601 UTC timestamp of when the
                                       retrieval was executed by the server.
                                       Format: yyyy-MM-ddTHH:mm:ssZ

ContactAttemptLog Object Schema:

Field Name                  Type             Required   Description / Constraints
chauffeurId                 string           Yes        Identifier of the chauffeur
                                                        to whom this log entry
                                                        belongs. Matches the path
                                                        parameter.
appointmentReference        string           Yes        Appointment, trip, or JC
                                                        reference associated with
                                                        this contact attempt.
                                                        Non-null, non-empty.
contactAttemptTimestamp     string           Yes        ISO 8601 UTC timestamp of
                                                        when the contact attempt
                                                        was made. Format:
                                                        yyyy-MM-ddTHH:mm:ssZ.
                                                        Used as the sort key.
contactOutcome              string           Yes        Outcome of the contact
                                                        attempt. Enumerated values
                                                        defined by the domain
                                                        (e.g., REACHED, NOT_REACHED,
                                                        REJECTED, CONFIRMED_DELAY).
rejectionOrDelayReason      string or null   No         Reason for rejection or
                                                        delay where applicable.
                                                        Null or empty string when
                                                        not applicable to the
                                                        contact outcome.
revisedEtaOrStartTime       string or null   No         ISO 8601 UTC timestamp
                                                        representing the revised
                                                        ETA or start time where
                                                        confirmed. Null when not
                                                        applicable.
pickupCoordinatorUser       string           Yes        Identity of the Pickup
                                                        Coordinator who recorded
                                                        the contact attempt.
                                                        Non-null, non-empty.
otherRemarks                string or null   No         Free-text remarks recorded
                                                        at the time of the contact
                                                        attempt. Null or empty when
                                                        not provided.
bookingSubStage             string           Yes        Identifies the booking
                                                        sub-stage under which this
                                                        log entry was created.
                                                        Maps to SER-010-020-103
                                                        (initial booking contact)
                                                        or SER-010-020-125
                                                        (re-contact / follow-up).

Example 200 Response Payload (non-empty):

{
  "data": [
    {
      "chauffeurId": "CHF-00123",
      "appointmentReference": "APT-2024-00456",
      "contactAttemptTimestamp": "2024-06-10T08:15:00Z",
      "contactOutcome": "NOT_REACHED",
      "rejectionOrDelayReason": null,
      "revisedEtaOrStartTime": null,
      "pickupCoordinatorUser": "coordinator.jane@example.com",
      "otherRemarks": "No answer after three rings.",
      "bookingSubStage": "SER-010-020-103"
    },
    {
      "chauffeurId": "CHF-00123",
      "appointmentReference": "APT-2024-00456",
      "contactAttemptTimestamp": "2024-06-10T08:30:00Z",
      "contactOutcome": "CONFIRMED_DELAY",
      "rejectionOrDelayReason": "Traffic congestion on main route.",
      "revisedEtaOrStartTime": "2024-06-10T09:00:00Z",
      "pickupCoordinatorUser": "coordinator.jane@example.com",
      "otherRemarks": null,
      "bookingSubStage": "SER-010-020-125"
    }
  ],
  "meta": {
    "chauffeurId": "CHF-00123",
    "totalCount": 2,
    "retrievedAt": "2024-06-10T09:45:00Z"
  }
}

Example 200 Response Payload (empty log history):

{
  "data": [],
  "meta": {
    "chauffeurId": "CHF-00123",
    "totalCount": 0,
    "retrievedAt": "2024-06-10T09:45:00Z"
  }
}

3.2 HTTP 400 - Bad Request
--------------------------------------------------------------------------------
Description : The request is malformed. For this endpoint the most likely cause
              is a chauffeurId path parameter that is empty or contains only
              whitespace after URL decoding.

Response Body Schema:

Field Name   Type     Description
error        object   Container for error details.
error.code   string   Machine-readable error code. Value: INVALID_REQUEST
error.message string  Human-readable description of the validation failure.
error.field  string   Name of the offending field or parameter.

Example 400 Response Payload:

{
  "error": {
    "code": "INVALID_REQUEST",
    "message": "chauffeurId path parameter must not be blank.",
    "field": "chauffeurId"
  }
}

3.3 HTTP 401 - Unauthorised
--------------------------------------------------------------------------------
Description : The caller did not present a valid Bearer JWT token, the token is
              expired, the signature is invalid, or the issuer is not recognised.
              Corresponds to BR-8.

Response Body Schema:

Field Name    Type     Description
error         object   Container for error details.
error.code    string   Machine-readable error code. Value: UNAUTHORISED
error.message string   Human-readable description. Value: "Unauthorised. A valid
                        Bearer JWT token is required."

Example 401 Response Payload:

{
  "error": {
    "code": "UNAUTHORISED",
    "message": "Unauthorised. A valid Bearer JWT token is required."
  }
}

3.4 HTTP 403 - Forbidden
--------------------------------------------------------------------------------
Description : The caller is authenticated but does not hold a permitted role, or
              the caller is a Pickup Coordinator attempting to access logs for a
              chauffeur outside their assigned operational scope. Corresponds to
              BR-5.

Response Body Schema:

Field Name    Type     Description
error         object   Container for error details.
error.code    string   Machine-readable error

ENDPOINT: POST /api/v1/drop-trips/{tripId}/contact-attempts

Source Requirement IDs: SER-010-020-125
Source Activity IDs: SER-010-020-125

--------------------------------------------------------------------------------
1. ENDPOINT OVERVIEW
--------------------------------------------------------------------------------

Path            : /api/v1/drop-trips/{tripId}/contact-attempts
HTTP Method     : POST
Summary         : Log a coordinator contact attempt against a chauffeur during
                  reassignment exception handling; records outcome, reason,
                  revised ETA, and coordinator user.
Description     : Allows an authenticated Pickup Coordinator to record a contact
                  attempt made toward a chauffeur assigned to a drop trip. The
                  operation captures the outcome of the contact (e.g. Connected,
                  No Answer, Rejected, Delayed, Confirmed), an optional or
                  conditionally required rejection or delay reason, a conditionally
                  required revised ETA or start time, and free-text remarks. Each
                  invocation appends a new immutable record to the contact attempt
                  history for the trip. If a revised ETA or start time is provided,
                  the parent drop trip record is updated accordingly. Downstream
                  notification and CRM services are triggered asynchronously where
                  the outcome warrants it.

--------------------------------------------------------------------------------
2. REQUEST SPECIFICATION
--------------------------------------------------------------------------------

2a. Request Headers

Header Name       Required   Description
Authorization     Yes        Bearer JWT token issued by the OAuth2/OIDC provider.
                             Format: "Bearer <token>"
Content-Type      Yes        Must be "application/json"
Accept            No         Should be "application/json". Defaults to JSON if
                             omitted.
X-Correlation-ID  No         Optional caller-supplied correlation identifier for
                             distributed tracing. If absent, the system generates
                             one internally and returns it in the response header.

2b. Path Parameters

Parameter   Type     Required   Description
tripId      string   Yes        The unique identifier of the drop trip against
                                which the contact attempt is being logged.
                                Must correspond to an existing drop trip record
                                in the system.
                                Format: UUID (e.g. "550e8400-e29b-41d4-a716-446655440000")
                                Validation: Must be a valid UUID. Non-UUID values
                                are rejected with 400. Non-existent UUIDs are
                                rejected with 404.

2c. Query Parameters

None applicable for this endpoint.

2d. Request Body Schema

Content-Type: application/json

The request body is a JSON object with the following fields:

Field Name                  Type      Required   Description and Validation Rules
--------------------------  --------  ---------  -----------------------------------------------
contactAttemptTimestamp     string    Yes        ISO 8601 datetime string representing when the
                                                 contact attempt was made.
                                                 Format: "YYYY-MM-DDTHH:mm:ssZ" or with offset.
                                                 Validation:
                                                   - Must be present (BR-3).
                                                   - Must not be a future timestamp relative to
                                                     server time at the moment of request
                                                     processing (BR-3).
                                                   - Must be a valid ISO 8601 datetime.
                                                 Example: "2025-06-15T09:30:00Z"

contactOutcome              string    Yes        The result of the contact attempt.
                                                 Validation:
                                                   - Must be present (BR-4).
                                                   - Must be one of the following enumerated
                                                     values (BR-4):
                                                       Connected
                                                       No Answer
                                                       Busy
                                                       Rejected
                                                       Delayed
                                                       Confirmed
                                                   - Values are case-sensitive.
                                                 Example: "Confirmed"

rejectionDelayReason        string    Conditional  A reason explaining why the chauffeur rejected
                                                   the trip or why a delay occurred.
                                                   Validation:
                                                     - Required when contactOutcome is "Rejected"
                                                       or "Delayed" (BR-5).
                                                     - Optional for all other outcome values.
                                                     - Maximum length: 500 characters.
                                                     - Must not be blank if provided.
                                                   Example: "Chauffeur cited vehicle breakdown."

revisedEtaOrStartTime       string    Conditional  ISO 8601 datetime string representing the
                                                   revised ETA or revised start time agreed upon
                                                   or communicated during the contact attempt.
                                                   Validation:
                                                     - Required when contactOutcome is "Confirmed"
                                                       or "Delayed" (BR-6).
                                                     - Optional for all other outcome values.
                                                     - Must be a valid ISO 8601 datetime if
                                                       provided.
                                                     - Must be a future timestamp relative to
                                                       server time (a revised schedule cannot be
                                                       set in the past).
                                                   Example: "2025-06-15T11:00:00Z"

otherRemarks                string    No           Free-text remarks or notes recorded by the
                                                   Pickup Coordinator about the contact attempt.
                                                   Validation:
                                                     - Optional.
                                                     - Maximum length: 1000 characters.
                                                     - No special format required.
                                                   Example: "Chauffeur confirmed arrival by 11:00.
                                                             Customer has been informed."

2e. Request Body Example

{
  "contactAttemptTimestamp": "2025-06-15T09:30:00Z",
  "contactOutcome": "Confirmed",
  "rejectionDelayReason": null,
  "revisedEtaOrStartTime": "2025-06-15T11:00:00Z",
  "otherRemarks": "Chauffeur confirmed arrival by 11:00. Customer has been informed."
}

Example for Rejected outcome:

{
  "contactAttemptTimestamp": "2025-06-15T09:15:00Z",
  "contactOutcome": "Rejected",
  "rejectionDelayReason": "Chauffeur cited personal emergency and cannot complete the trip.",
  "revisedEtaOrStartTime": null,
  "otherRemarks": "Escalation to supervisor initiated."
}

--------------------------------------------------------------------------------
3. RESPONSE SPECIFICATION
--------------------------------------------------------------------------------

3a. HTTP 201 Created

Description: The contact attempt was successfully persisted. A new contact
             attempt record has been created and linked to the drop trip.

Response Headers:
  Content-Type    : application/json
  Location        : /api/v1/drop-trips/{tripId}/contact-attempts/{contactAttemptId}
  X-Correlation-ID: The correlation ID used for this request (echoed or generated).

Response Body Schema:

Field Name                   Type      Description
---------------------------  --------  -----------------------------------------------
contactAttemptId             string    System-generated unique identifier for the
                                       newly created contact attempt record.
                                       Format: UUID.
tripId                       string    The drop trip identifier this attempt is
                                       linked to.
appointmentOrJcReference     string    The appointment or JC reference resolved from
                                       the parent trip record.
chauffeurId                  string    The chauffeur identifier resolved from the
                                       trip's current assignment.
pickupCoordinatorUserId      string    The authenticated user's identifier, stamped
                                       from the JWT principal.
contactAttemptTimestamp      string    ISO 8601 datetime of the contact attempt as
                                       submitted.
contactOutcome               string    The outcome value as persisted.
rejectionDelayReason         string    The rejection or delay reason if provided,
                                       otherwise null.
revisedEtaOrStartTime        string    The revised ETA or start time if provided,
                                       otherwise null.
otherRemarks                 string    The remarks as submitted, otherwise null.
createdAt                    string    ISO 8601 datetime of when the record was
                                       created by the system (server-generated).

Response Body Example (201):

{
  "contactAttemptId": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
  "tripId": "550e8400-e29b-41d4-a716-446655440000",
  "appointmentOrJcReference": "JC-2025-00987",
  "chauffeurId": "drv-0042",
  "pickupCoordinatorUserId": "usr-pc-0019",
  "contactAttemptTimestamp": "2025-06-15T09:30:00Z",
  "contactOutcome": "Confirmed",
  "rejectionDelayReason": null,
  "revisedEtaOrStartTime": "2025-06-15T11:00:00Z",
  "otherRemarks": "Chauffeur confirmed arrival by 11:00. Customer has been informed.",
  "createdAt": "2025-06-15T09:30:45Z"
}

--------------------------------------------------------------------------------

3b. HTTP 400 Bad Request

Description: The request is malformed. This includes invalid UUID format for
             tripId, unparseable JSON body, or missing Content-Type header.

Response Body Schema:

Field Name   Type      Description
-----------  --------  -----------------------------------------------
status       integer   HTTP status code. Value: 400.
errorCode    string    Application-level error code.
message      string    Human-readable description of the error.
details      array     List of individual field-level error descriptors
                       (may be empty for structural errors).

Response Body Example (400):

{
  "status": 400,
  "errorCode": "INVALID_REQUEST",
  "message": "The request could not be parsed. Ensure the body is valid JSON and Content-Type is application/json.",
  "details": []
}

--------------------------------------------------------------------------------

3c. HTTP 401 Unauthorized

Description: The request does not include a valid Bearer JWT token, or the
             token has expired, is malformed, or has an invalid signature.

Response Body Example (401):

{
  "status": 401,
  "errorCode": "UNAUTHORIZED",
  "message": "Authentication is required. Provide a valid Bearer JWT token.",
  "details": []
}

--------------------------------------------------------------------------------

3d. HTTP 403 Forbidden

Description: The authenticated user does not hold the PICKUP_COORDINATOR role
             and is therefore not authorized to log contact attempts. (BR-13)

Response Body Example (403):

{
  "status": 403,
  "errorCode": "ACCESS_DENIED",
  "message": "Access denied. Only Pickup Coordinators are authorized to log contact attempts.",
  "details": []
}

--------------------------------------------------------------------------------

3e. HTTP 404 Not Found

Description: The tripId provided in the path does not correspond to any
             existing drop trip record in the system. (BR-1)

Response Body Example (404):

{
  "status": 404,
  "errorCode": "TRIP_NOT_FOUND",
  "message": "Drop trip not found for the provided tripId.",
  "details": [
    {
      "field": "tripId",
      "issue": "No drop trip record exists for the identifier: 550e8400-e29b-41d4-a716-446655440000"
    }
  ]
}

--------------------------------------------------------------------------------

3f. HTTP 409 Conflict

Description: The drop trip exists but is in a terminal state (completed,
             cancelled, or closed) and cannot accept new contact attempt
             records. (BR-2)

Response Body Example (409):

{
  "status": 409,
  "errorCode": "TRIP_IN_TERMINAL_STATE",
  "message": "Contact attempts cannot be logged against a trip that is in a terminal state.",
  "details": [
    {
      "field": "tripId",
      "issue": "The drop trip with identifier 550e8400-e29b-41d4-a716-446655440000 is in a terminal state and does not accept further contact attempts."
    }
  ]
}

--------------------------------------------------------------------------------

3g. HTTP 422 Unprocessable Entity

Description: The request body is syntactically valid JSON but fails business
             validation rules. This covers BR-3, BR-4, BR-5, and BR-6.

Response Body Schema:

Field Name   Type      Description
-----------  --------  -----------------------------------------------
status       integer   HTTP status code. Value: 422.
errorCode    string    Application-level error code.
message      string    Summary of the validation failure.
details      array     List of individual field-level validation errors.
  field      string    The name of the field that failed validation.
  ruleId

ENDPOINT DESIGN: GET /api/v1/audit-events/chauffeurs/{chauffeurId}

================================================================================
SECTION 1: ENDPOINT IDENTIFICATION
================================================================================

Path            : /api/v1/audit-events/chauffeurs/{chauffeurId}
HTTP Method     : GET
Summary         : Retrieve audit events associated with a specific chauffeur
                  across all assignment rounds, acceptance or rejection actions,
                  and schedule changes.
Description     : Returns the complete, immutable, chronologically ordered audit
                  trail for a given chauffeur. Records are sourced from an
                  append-only audit event store and cover all booking
                  orchestration events (SER-010-020-010), rejection and timeout
                  events (SER-010-020-012), and operational profile change events
                  (SER-010-020-133). The operation is read-only and produces no
                  side effects on any data store.

Source Requirement IDs : SER-010-020-010, SER-010-020-012, SER-010-020-133
Source Activity IDs    : SER-010-020-010, SER-010-020-012, SER-010-020-133


================================================================================
SECTION 2: REQUEST SPECIFICATION
================================================================================

2.1 REQUEST HEADERS
--------------------------------------------------------------------------------

Header Name      : Authorization
Required         : Yes
Format           : Bearer <JWT token>
Description      : OAuth2 / OIDC Bearer JWT. Must be signed, non-expired, and
                   carry valid issuer and audience claims. Absence, malformation,
                   or expiry causes immediate 401 rejection before any further
                   processing.

Header Name      : Accept
Required         : No (recommended)
Expected Value   : application/json
Description      : Indicates the client expects a JSON response body.

Header Name      : X-Correlation-ID
Required         : No (recommended)
Format           : UUID v4 string
Description      : Optional caller-supplied correlation identifier for
                   distributed tracing. If provided, it is echoed back in the
                   response header of the same name.


2.2 PATH PARAMETERS
--------------------------------------------------------------------------------

Parameter Name   : chauffeurId
Location         : Path
Required         : Yes
Type             : String
Format           : Non-empty string; expected to conform to the chauffeur
                   identifier format defined in the chauffeur registry
                   (e.g., alphanumeric, no whitespace, maximum 64 characters).
Validation Rules :
    - Must be non-empty.
    - Must not contain whitespace characters.
    - Must not exceed 64 characters in length.
    - Must match the pattern: ^[a-zA-Z0-9_-]{1,64}$
    - Syntactic validation is performed before any downstream call.
    - A syntactically invalid value results in a 400 response.
Description      : The unique identifier of the chauffeur whose audit events
                   are to be retrieved. Maps to audit_events.chauffeur_id in
                   the audit event store.


2.3 QUERY PARAMETERS
--------------------------------------------------------------------------------

No query parameters are defined for this endpoint. Filtering, pagination, and
sorting are not exposed in this version. All audit records for the specified
chauffeurId are returned in a single response ordered by event timestamp
ascending.


2.4 REQUEST BODY
--------------------------------------------------------------------------------

Not applicable. This is a GET operation and carries no request body.


================================================================================
SECTION 3: RESPONSE SPECIFICATION
================================================================================

3.1 HTTP 200 - SUCCESS
--------------------------------------------------------------------------------

Description : The request was authenticated, authorized, and processed
              successfully. All audit event records for the specified
              chauffeurId are returned in chronological order.

Response Body Schema (top-level object):

Field Name       : chauffeurId
Type             : String
Required         : Yes
Description      : The chauffeur identifier for which audit events are returned.
                   Echoes the path parameter value.

Field Name       : auditEvents
Type             : Array of AuditEvent objects
Required         : Yes
Description      : Ordered list of audit event records, sorted by
                   eventTimestamp ascending. May be an empty array if no
                   audit events exist for the chauffeur.

AuditEvent Object Fields:

Field Name       : activityId
Type             : String
Required         : No (present when recorded)
Description      : Identifier of the source activity that generated this audit
                   event (e.g., SER-010-020-010).
DB Column        : audit_events.activity_id

Field Name       : stage
Type             : String
Required         : No (present when recorded)
Description      : Processing stage within the activity at which the event
                   was captured.
DB Column        : audit_events.stage

Field Name       : eventTimestamp
Type             : String
Format           : ISO 8601 date-time (UTC), e.g., 2024-06-15T09:30:00Z
Required         : Yes
Description      : The timestamp at which the audit event was recorded.
                   Records are ordered by this field ascending.
DB Column        : audit_events.event_timestamp

Field Name       : requestStatus
Type             : String
Required         : Yes
Description      : The status of the chauffeur request at the time the event
                   was recorded (e.g., PENDING, ACCEPTED, REJECTED, TIMEOUT).
DB Column        : audit_events.request_status

Field Name       : rejectionReason
Type             : String
Required         : No (present only for rejection events)
Description      : Human-readable reason for rejection, captured during
                   appointment booking rejection scenarios (SER-010-020-012).
                   Null or absent when the event is not a rejection event.
DB Column        : audit_events.rejection_reason

Field Name       : timeoutFlag
Type             : Boolean
Required         : No (present only when a timeout occurred)
Description      : Indicates whether the event was triggered by a timeout
                   condition during appointment booking (SER-010-020-012).
                   Null or absent when not applicable.
DB Column        : audit_events.timeout_flag

Field Name       : operatingDays
Type             : Array of String
Required         : No (present for profile/operational events)
Description      : Days of the week on which the chauffeur is scheduled to
                   operate, as recorded during onboarding or profile update
                   (SER-010-020-133). Example values: MON, TUE, WED, THU,
                   FRI, SAT, SUN.
DB Column        : audit_events.operating_days

Field Name       : operatingHours
Type             : String
Required         : No (present for profile/operational events)
Description      : Operating hours range for the chauffeur as recorded during
                   onboarding or profile update (SER-010-020-133).
                   Example format: 08:00-20:00
DB Column        : audit_events.operating_hours

Field Name       : startingLocation
Type             : String
Required         : No (present for profile/operational events)
Description      : The chauffeur's designated starting location as recorded
                   during onboarding or profile update (SER-010-020-133).
DB Column        : audit_events.starting_location


Example 200 Response Payload:

chauffeurId: CHF-00123
auditEvents:
  - activityId: SER-010-020-010
    stage: ASSIGNMENT_ROUND_1
    eventTimestamp: 2024-06-15T08:00:00Z
    requestStatus: PENDING
    rejectionReason: null
    timeoutFlag: false
    operatingDays: null
    operatingHours: null
    startingLocation: null

  - activityId: SER-010-020-012
    stage: REJECTION_PROCESSING
    eventTimestamp: 2024-06-15T08:05:30Z
    requestStatus: REJECTED
    rejectionReason: Chauffeur unavailable during requested time window
    timeoutFlag: false
    operatingDays: null
    operatingHours: null
    startingLocation: null

  - activityId: SER-010-020-133
    stage: PROFILE_UPDATE
    eventTimestamp: 2024-06-16T10:00:00Z
    requestStatus: PROFILE_UPDATED
    rejectionReason: null
    timeoutFlag: false
    operatingDays: [MON, TUE, WED, THU, FRI]
    operatingHours: 07:00-19:00
    startingLocation: Terminal 2, Heathrow Airport


3.2 HTTP 400 - BAD REQUEST
--------------------------------------------------------------------------------

Description : The chauffeurId path parameter failed syntactic validation.

Response Body Schema:

Field Name       : errorCode
Type             : String
Value            : INVALID_PATH_PARAMETER

Field Name       : message
Type             : String
Value            : The chauffeurId path parameter is malformed or invalid.

Field Name       : details
Type             : String
Description      : Additional context describing the specific validation
                   failure (e.g., exceeds maximum length, contains invalid
                   characters).

Field Name       : timestamp
Type             : String
Format           : ISO 8601 date-time (UTC)

Field Name       : correlationId
Type             : String
Description      : Echoed from X-Correlation-ID request header if provided.

Example 400 Response Payload:

errorCode: INVALID_PATH_PARAMETER
message: The chauffeurId path parameter is malformed or invalid.
details: chauffeurId must match pattern ^[a-zA-Z0-9_-]{1,64}$ and must not be empty.
timestamp: 2024-06-15T09:00:00Z
correlationId: 3f6a1b2c-4d5e-6f7a-8b9c-0d1e2f3a4b5c


3.3 HTTP 401 - UNAUTHORIZED
--------------------------------------------------------------------------------

Description : The Authorization header is absent, malformed, or contains an
              expired or invalid JWT. Triggered by business rule BR-7.

Response Body Schema:

Field Name       : errorCode
Type             : String
Value            : AUTHENTICATION_REQUIRED

Field Name       : message
Type             : String
Value            : Authentication required. A valid Bearer JWT token must

ENDPOINT: POST /api/v1/chauffeurs/{chauffeurId}/handover-refusals

Source Requirement IDs: SER-010-020-041, SER-010-020-042


------------------------------------------------------------------------
SECTION 1: ENDPOINT OVERVIEW
------------------------------------------------------------------------

Path            : /api/v1/chauffeurs/{chauffeurId}/handover-refusals
HTTP Method     : POST
Summary         : Log customer handover refusal with registration number,
                  vehicle name, live location, and refusal reason, and
                  notify the Pickup Coordinator.
Description     : Allows an authenticated chauffeur to record a formal
                  refusal to hand over a vehicle to a customer during an
                  active appointment. The endpoint captures the vehicle
                  registration number, vehicle name, the chauffeur's live
                  geographic coordinates at the time of refusal, and a
                  structured refusal reason selected from a predefined
                  list. On successful persistence the appointment status
                  is transitioned to Handover Refused, an immutable audit
                  entry is written, and a notification is dispatched to
                  the assigned Pickup Coordinator to enable corrective
                  action. Duplicate submissions for the same
                  chauffeur-appointment combination are detected and
                  deduplicated.


------------------------------------------------------------------------
SECTION 2: REQUEST SPECIFICATION
------------------------------------------------------------------------

2.1 Request Headers

Header Name          Required   Format / Constraints
Authorization        Yes        Bearer <JWT>. Must be a valid, non-expired
                                JWT issued by the platform OAuth2/OIDC
                                provider. Signature must be verifiable
                                against the provider's JWKS endpoint.
Content-Type         Yes        Must be application/json.
X-Idempotency-Key    Recommended  UUID v4 string. Client-generated key used
                                to safely replay responses for
                                network-retry scenarios without creating
                                duplicate records. If omitted, server-side
                                deduplication still applies based on
                                chauffeurId and appointmentId, but
                                response replay is not guaranteed.
Accept               No         application/json (default assumed).
X-Request-ID         No         UUID v4. Caller-supplied correlation ID
                                for distributed tracing. Echoed back in
                                the response header.

2.2 Path Parameters

Parameter     Type     Required   Constraints
chauffeurId   string   Yes        Non-empty UUID v4 identifying the
                                  chauffeur. Must match the subject (sub)
                                  claim in the Bearer JWT. Maximum length
                                  36 characters.

2.3 Query Parameters

None defined for this endpoint.

2.4 Request Body Schema

Content-Type: application/json

All four top-level fields are mandatory. The body must not be null or
empty.

Field                        Type     Required   Constraints
registrationNumber           string   Yes        Non-null, non-empty.
                                                 Minimum length: 2
                                                 characters.
                                                 Maximum length: 20
                                                 characters.
                                                 Pattern: alphanumeric
                                                 with optional hyphens
                                                 and spaces,
                                                 regex: ^[A-Za-z0-9
                                                 \-]{2,20}$
                                                 Must represent the
                                                 vehicle currently
                                                 assigned to the
                                                 chauffeur's active
                                                 appointment.

vehicleName                  string   Yes        Non-null, non-empty.
                                                 Minimum length: 2
                                                 characters.
                                                 Maximum length: 100
                                                 characters.
                                                 Free text describing
                                                 the vehicle make/model.
                                                 No special character
                                                 injection patterns
                                                 permitted.

liveLocation                 object   Yes        Non-null object
                                                 containing latitude
                                                 and longitude. Both
                                                 child fields are
                                                 required.

liveLocation.latitude        number   Yes        IEEE 754 double.
                                                 Minimum: -90.0
                                                 Maximum: +90.0
                                                 Must not be null.
                                                 Must not be 0.0 when
                                                 longitude is also 0.0
                                                 (zero-zero coordinate
                                                 pair is rejected as
                                                 invalid per BR-4).
                                                 Must not be NaN or
                                                 Infinity.

liveLocation.longitude       number   Yes        IEEE 754 double.
                                                 Minimum: -180.0
                                                 Maximum: +180.0
                                                 Must not be null.
                                                 Must not be 0.0 when
                                                 latitude is also 0.0.
                                                 Must not be NaN or
                                                 Infinity.

refusalReason                string   Yes        Non-null, non-empty.
                                                 Must exactly match one
                                                 of the valid refusal
                                                 reason codes loaded
                                                 from the system's
                                                 configured reason list.
                                                 Free-text values not
                                                 matching a known code
                                                 are rejected (BR-3).
                                                 Maximum length: 100
                                                 characters.

2.5 Example Request

POST /api/v1/chauffeurs/f47ac10b-58cc-4372-a567-0e02b2c3d479/handover-refusals
Authorization: Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9...
Content-Type: application/json
X-Idempotency-Key: 3fa85f64-5717-4562-b3fc-2c963f66afa6
X-Request-ID: 9b1deb4d-3b7d-4bad-9bdd-2b0d7b3dcb6d

{
  "registrationNumber": "AB-1234-CD",
  "vehicleName": "Toyota Camry 2023",
  "liveLocation": {
    "latitude": 25.204849,
    "longitude": 55.270782
  },
  "refusalReason": "CUSTOMER_ABSENT"
}


------------------------------------------------------------------------
SECTION 3: RESPONSE SPECIFICATION
------------------------------------------------------------------------

3.1 HTTP 201 Created — Handover Refusal Successfully Recorded

Returned when the refusal record is newly created and persisted.

Response Headers:
  Content-Type: application/json
  X-Request-ID: <echoed from request or server-generated>
  Location: /api/v1/chauffeurs/{chauffeurId}/handover-refusals/{refusalId}

Response Body Schema:

Field                        Type      Description
refusalId                    string    Server-generated UUID v4 uniquely
                                       identifying this refusal record.
chauffeurId                  string    UUID of the chauffeur who submitted
                                       the refusal.
appointmentId                string    UUID of the appointment derived from
                                       the chauffeur's active assignment.
vehicleRegistrationNumber    string    Echoed registration number from the
                                       request.
vehicleName                  string    Echoed vehicle name from the request.
liveLocation                 object    Echoed coordinates.
liveLocation.latitude        number    Latitude at time of refusal.
liveLocation.longitude       number    Longitude at time of refusal.
refusalReasonCode            string    The validated reason code persisted.
refusalTimestamp             string    ISO 8601 UTC timestamp of when the
                                       refusal was recorded server-side.
                                       Format: yyyy-MM-ddTHH:mm:ss.SSSZ
appointmentStatus            string    Updated appointment status value,
                                       e.g., HANDOVER_REFUSED.
notificationDispatched       boolean   Indicates whether the notification
                                       to the Pickup Coordinator was
                                       successfully enqueued.

Example 201 Response Body:

{
  "refusalId": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
  "chauffeurId": "f47ac10b-58cc-4372-a567-0e02b2c3d479",
  "appointmentId": "c9d8e7f6-a5b4-3210-fedc-ba9876543210",
  "vehicleRegistrationNumber": "AB-1234-CD",
  "vehicleName": "Toyota Camry 2023",
  "liveLocation": {
    "latitude": 25.204849,
    "longitude": 55.270782
  },
  "refusalReasonCode": "CUSTOMER_ABSENT",
  "refusalTimestamp": "2025-07-15T09:32:11.452Z",
  "appointmentStatus": "HANDOVER_REFUSED",
  "notificationDispatched": true
}

------------------------------------------------------------------------

3.2 HTTP 200 OK — Duplicate Submission Detected (Idempotent Response)

Returned when a non-terminal refusal record already exists for the same
chauffeurId and appointmentId combination (BR-10). No new record is
created and no additional notification is dispatched.

Response Body Schema: Same structure as 201 above, populated with the
existing record's data.

Additional field:
  duplicate   boolean   Always true in this response to signal the
                        caller that an existing record was returned.

Example 200 Response Body:

{
  "refusalId": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
  "chauffeurId": "f47ac10b-58cc-4372-a567-0e02b2c3d479",
  "appointmentId": "c9d8e7f6-a5b4-3210-fedc-ba9876543210",
  "vehicleRegistrationNumber": "AB-1234-CD",
  "vehicleName": "Toyota Camry 2023",
  "liveLocation": {
    "latitude": 25.204849,
    "longitude": 55.270782
  },
  "refusalReasonCode": "CUSTOMER_ABSENT",
  "refusalTimestamp": "2025-07-15T09:32:11.452Z",
  "appointmentStatus": "HANDOVER_REFUSED",
  "notificationDispatched": false,
  "duplicate": true
}

------------------------------------------------------------------------

3.3 HTTP 400 Bad Request — Invalid Refusal Reason

Returned when the submitted refusalReason does not match any entry in
the system's configured valid reason code list (BR-3).

Response Body Schema:

Field       Type      Description
errorCode   string    Machine-readable error code.
message     string    Human-readable error message.
field       string    Name of the offending field.
value       string    The submitted value that failed validation.

Example 400 Response Body:

{
  "errorCode": "INVALID_REFUSAL_REASON",
  "message": "The selected refusal reason is not valid. Please select a reason from the available options.",
  "field": "refusalReason",
  "value": "UNKNOWN_REASON_XYZ"
}

------------------------------------------------------------------------

3.4 HTTP 401 Unauthorized — Authentication Failure

Returned when the Bearer JWT is absent, expired, malformed, or fails
signature verification.

Example 401 Response Body:

{
  "errorCode": "UNAUTHORIZED",
  "message": "Authentication token is missing, expired, or invalid."
}

------------------------------------------------------------------------

3.5 HTTP 403 Forbidden — Authorization Failure

Returned when the authenticated principal does not hold the CHAUFFEUR
role, or when the chauffeurId in the path does not match the JWT subject
claim (BR-1).

Example 403 Response Body:

{
  "errorCode": "FORBIDDEN",
  "message": "Chauffeur is not authorized to submit a handover refusal for this appointment."
}

------------------------------------------------------------------------

3.6 HTTP 404 Not Found — Chauffeur Not Found

Returned when the chauffeurId does not exist in the chauffeur registry
or the chauffeur is not in an active status.

Example 404 Response Body:

{
  "errorCode": "CHAUFFEUR_NOT_FOUND",
  "message": "The specified chauffeur does not exist or is not active."
}

------------------------------------------------------------------------

3.7 HTTP 409 Conflict — Business State Conflict

Returned in two scenarios:

Scenario A (BR-7): The appointment linked to the chauffeur is not in an
active or in-progress state.

{
  "errorCode": "APPOINTMENT_NOT_ACTIVE",
  "message": "Handover refusal cannot be submitted. The associated appointment is not in an active state."
}

Scenario B (BR-10): A non-terminal refusal already exists and the server
cannot confirm idempotency via X-Idempotency-Key (fallback conflict
response when idempotency key is absent and duplicate is detected).

{
  "errorCode": "DUPLICATE_REFUSAL",
  "message": "A handover refusal for this appointment has already been recorded."
}

------------------------------------------------------------------------

3.8 HTTP 422 Unprocessable Entity — Payload Validation Failure

Returned when mandatory fields are missing, empty, or contain
out-

ENDPOINT: PUT /api/v1/vehicle-condition-reports/sessions/{sessionId}/remarks

Source Requirement IDs: SER-010-020-073
Source Activity IDs: SER-010-020-073


------------------------------------------------------------------------
1. ENDPOINT OVERVIEW
------------------------------------------------------------------------

Path            : /api/v1/vehicle-condition-reports/sessions/{sessionId}/remarks
HTTP Method     : PUT
Summary         : Submit final remarks in voice recording reference or text format
Description     : Allows the authenticated chauffeur assigned to a vehicle condition
                  report session to submit final remarks in voice (audio reference)
                  or text format, or both concurrently. This endpoint represents
                  workflow activity SER-010-020-073 and, upon successful completion,
                  marks the remarks step as complete to enable progression to the
                  next workflow step SER-010-020-074. The operation follows PUT
                  (replace) semantics; any previously stored remarks for the session
                  are fully overwritten by the new submission.


------------------------------------------------------------------------
2. REQUEST SPECIFICATION
------------------------------------------------------------------------

2a. Request Headers

Header Name       Required   Description
Authorization     Yes        Bearer JWT token issued via OAuth2/OIDC. Must be a
                             valid, non-expired token. Format: "Bearer <token>"
Content-Type      Yes        Must be "application/json"
Accept            No         Should be "application/json". Defaults to
                             "application/json" if omitted.
X-Request-ID      No         Optional caller-supplied correlation identifier for
                             distributed tracing. String, max 64 characters.


2b. Path Parameters

Parameter   Type     Required   Description
sessionId   string   Yes        Unique identifier of the vehicle condition report
                                session for which remarks are being submitted.
                                Must be a non-empty string. Must correspond to an
                                existing session record in the data store.
                                Format: UUID v4 (e.g. "550e8400-e29b-41d4-a716-
                                446655440000"). Regex: ^[0-9a-fA-F]{8}-[0-9a-fA-F]
                                {4}-4[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-
                                [0-9a-fA-F]{12}$


2c. Query Parameters

None applicable for this endpoint.


2d. Request Body Schema

Content-Type: application/json

The request body must contain a "remarks" object. At least one of the fields
within the remarks object (text or voiceReference) must be present and non-null.

Top-level structure:

  Field      Type     Required   Description
  remarks    object   Yes        Container object for the remark payload. Must
                                 not be null or empty. Must contain at least one
                                 of the child fields below.

Fields within remarks object:

  Field           Type     Required   Description
  text            string   Cond.      Free-text remark entered by the chauffeur.
                                      Required if voiceReference is absent or null.
                                      Min length: 1 character.
                                      Max length: 2000 characters.
                                      Must not be blank (whitespace-only values
                                      are treated as absent).
                                      No special format constraint beyond being a
                                      valid UTF-8 string.

  voiceReference  string   Cond.      Reference identifier or URL pointing to a
                                      pre-uploaded audio resource in the
                                      Voice/Audio Storage Service. Required if
                                      text is absent or null.
                                      Min length: 1 character.
                                      Max length: 500 characters.
                                      Must be a non-blank string.
                                      Must resolve to a valid, accessible audio
                                      resource when validated against the
                                      Voice/Audio Storage Service.
                                      Format: URI or opaque blob identifier as
                                      issued by the Voice/Audio Storage Service.

Conditional requirement rule: At least one of "text" or "voiceReference" must
be present, non-null, and non-blank. Both may be provided simultaneously; if
both are present, both are persisted with equal precedence.


2e. Example Request

PUT /api/v1/vehicle-condition-reports/sessions/550e8400-e29b-41d4-a716-446655440000/remarks
Authorization: Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9...
Content-Type: application/json
X-Request-ID: req-abc-12345

{
  "remarks": {
    "text": "Minor scratch observed on the rear left bumper. No structural damage.",
    "voiceReference": "audio-store://recordings/session-550e8400/remark-001.m4a"
  }
}

Text-only example:

{
  "remarks": {
    "text": "Vehicle interior is clean. No damage noted."
  }
}

Voice-only example:

{
  "remarks": {
    "voiceReference": "audio-store://recordings/session-550e8400/remark-002.m4a"
  }
}


------------------------------------------------------------------------
3. RESPONSE SPECIFICATION
------------------------------------------------------------------------

3a. HTTP 200 OK - Remarks Successfully Submitted

Returned when the remarks have been successfully validated, persisted, and the
session's remarks workflow step has been marked as complete.

Response Body Schema:

  Field              Type      Description
  sessionId          string    The session identifier for which remarks were saved.
  remarksStepStatus  string    Status of the remarks workflow step. Value will be
                               "COMPLETE" upon successful submission.
  lastModifiedAt     string    ISO 8601 UTC timestamp of when the session record
                               was last updated. Format: yyyy-MM-ddTHH:mm:ss.SSSZ
  message            string    Human-readable confirmation message.

Example Response Body:

  {
    "sessionId": "550e8400-e29b-41d4-a716-446655440000",
    "remarksStepStatus": "COMPLETE",
    "lastModifiedAt": "2025-06-15T10:45:32.000Z",
    "message": "Remarks submitted successfully."
  }


3b. HTTP 400 Bad Request - Missing or Invalid Remark Content

Returned when the request body is present but contains neither a valid text
remark nor a valid voice reference (BR-3).

Response Body Schema:

  Field    Type      Description
  code     string    Application-level error code.
  message  string    Human-readable error description.
  details  array     List of field-level validation error objects.
    - field    string   The field path that failed validation.
    - issue    string   Description of the validation failure.

Example Response Body:

  {
    "code": "VALIDATION_ERROR",
    "message": "At least one remark (voice or text) must be provided.",
    "details": [
      {
        "field": "remarks",
        "issue": "The remarks object must contain at least one non-blank value
                  for 'text' or 'voiceReference'."
      }
    ]
  }


3c. HTTP 401 Unauthorized - Missing or Invalid Authentication

Returned when the Bearer JWT token is absent, expired, or invalid.

Response Body Schema:

  Field    Type      Description
  code     string    Application-level error code.
  message  string    Human-readable error description.

Example Response Body:

  {
    "code": "UNAUTHORIZED",
    "message": "Authentication is required. Provide a valid Bearer token."
  }


3d. HTTP 403 Forbidden - Authorization Failure

Returned when the authenticated user is not the chauffeur assigned to the
appointment linked to the session (BR-5).

Response Body Schema:

  Field    Type      Description
  code     string    Application-level error code.
  message  string    Human-readable error description.

Example Response Body:

  {
    "code": "FORBIDDEN",
    "message": "You are not authorized to submit remarks for this vehicle
                condition report session."
  }


3e. HTTP 404 Not Found - Session Not Found

Returned when no vehicle condition report session exists for the provided
sessionId (BR-1).

Response Body Schema:

  Field    Type      Description
  code     string    Application-level error code.
  message  string    Human-readable error description.

Example Response Body:

  {
    "code": "SESSION_NOT_FOUND",
    "message": "Vehicle condition report session not found for the provided
                sessionId."
  }


3f. HTTP 409 Conflict - Session Not Active

Returned when the session identified by sessionId is closed, submitted, or
completed and can no longer be modified (BR-2).

Response Body Schema:

  Field    Type      Description
  code     string    Application-level error code.
  message  string    Human-readable error description.

Example Response Body:

  {
    "code": "SESSION_NOT_ACTIVE",
    "message": "Vehicle condition report session is no longer active and
                cannot be updated."
  }


3g. HTTP 422 Unprocessable Entity - Invalid Voice Reference

Returned when a voiceReference is provided but cannot be resolved or validated
against the Voice/Audio Storage Service (BR-4).

Response Body Schema:

  Field    Type      Description
  code     string    Application-level error code.
  message  string    Human-readable error description.
  details  array     List of field-level validation error objects.
    - field    string   The field path that failed validation.
    - issue    string   Description of the validation failure.

Example Response Body:

  {
    "code": "INVALID_VOICE_REFERENCE",
    "message": "The provided voice remark reference is invalid or inaccessible.",
    "details": [
      {
        "field": "remarks.voiceReference",
        "issue": "The audio resource referenced could not be resolved in the
                  Voice/Audio Storage Service."
      }
    ]
  }


3h. HTTP 500 Internal Server Error - Persistence Failure

Returned when a database or storage error occurs during the write operation
and the transaction has been rolled back (BR-10).

Response Body Schema:

  Field    Type      Description
  code     string    Application-level error code.
  message  string    Human-readable error description.

Example Response Body:

  {
    "code": "INTERNAL_SERVER_ERROR",
    "message": "An internal error occurred while saving the remarks. Please
                retry."
  }


------------------------------------------------------------------------
4. BUSINESS RULES
------------------------------------------------------------------------

BR-1
  Category          : Pre-condition
  Trigger Condition : PUT request received for a sessionId that does not exist
                      in the data store.
  Description       : A valid vehicle condition report session must exist for
                      the provided sessionId before remarks can be submitted.
  Expected Behaviour: System validates that the sessionId corresponds to an
                      existing, active vehicle condition report session before
                      processing the remarks update.
  Error Code        : 404
  Error Message     : Vehicle condition report session not found for the
                      provided sessionId.

BR-2
  Category          : Pre-condition
  Trigger Condition : The session identified by sessionId has already been
                      closed,

ENDPOINT DESIGN DOCUMENT
=========================

Source Requirement ID : SER-010-020-133
Endpoint Path         : /api/v1/chauffeurs/{chauffeurId}/schedule
HTTP Method           : PATCH
Summary               : Chauffeur self-manages operating days, operating hours, and starting location
Security Scope        : chauffeur:schedule:write


---------------------------------------------------------------------------
SECTION 1 — ENDPOINT IDENTIFICATION
---------------------------------------------------------------------------

Path        : /api/v1/chauffeurs/{chauffeurId}/schedule
Method      : PATCH
Summary     : Update a chauffeur's schedule including operating days, operating
              hours, and starting location.
Description : Allows an authenticated and authorised principal to partially or
              fully replace the schedule of a specified chauffeur. The schedule
              governs which days and hours the chauffeur is available and from
              which geographic location they begin their shift. Updates take
              effect immediately for future appointment matching by the automated
              chauffeur recommendation engine. Existing confirmed appointments
              are not affected. Optimistic locking is enforced via an ETag or
              version field to prevent lost updates under concurrent requests.
              Every successful update produces an immutable audit log entry.


---------------------------------------------------------------------------
SECTION 2 — REQUEST SPECIFICATION
---------------------------------------------------------------------------

2.1 Request Headers
-------------------

Header Name       : Authorization
Required          : Yes
Format            : Bearer <JWT>
Description       : OAuth2 / OIDC Bearer token. Must be a valid, non-expired
                    JWT signed by the trusted issuer. The token must carry the
                    scope chauffeur:schedule:write and a role claim of one of
                    CHAUFFEUR, PICKUP_COORDINATOR, or ADMIN.

Header Name       : Content-Type
Required          : Yes
Allowed Value     : application/json
Description       : Request body must be JSON-encoded.

Header Name       : If-Match
Required          : Yes
Format            : ETag string, e.g. "v7" or a quoted opaque hash
Description       : The current version/ETag of the chauffeur schedule resource
                    as previously retrieved by the caller. Used for optimistic
                    locking. If the submitted value does not match the persisted
                    version a 409 Conflict is returned.

Header Name       : Accept
Required          : No
Recommended Value : application/json
Description       : Indicates the caller expects a JSON response body.


2.2 Path Parameters
-------------------

Parameter Name : chauffeurId
Location       : Path
Type           : String (UUID v4)
Required       : Yes
Format         : UUID, e.g. 123e4567-e89b-12d3-a456-426614174000
Validation     : Must be a well-formed UUID. Must correspond to an existing,
                 active chauffeur record. Non-existent or inactive chauffeur
                 IDs result in a 404 response.


2.3 Query Parameters
--------------------

None defined for this endpoint.


2.4 Request Body Schema
-----------------------

The request body is a JSON object. All top-level fields are optional in the
sense that PATCH allows partial updates; however, business rules require that
any field present must be valid, and at least one field must be supplied.
Submitting a complete schedule payload is recommended for idempotency.

Field Path                        : operatingDays
Type                              : Array of String
Required                          : Conditional (required if included; must not
                                    be empty if the field is present)
Allowed Values                    : MON, TUE, WED, THU, FRI, SAT, SUN
Min Items                         : 1
Max Items                         : 7
Uniqueness                        : Each day identifier must appear at most once
Validation                        : Non-null, non-empty array; each element must
                                    be one of the seven recognised day
                                    identifiers. Unrecognised values or an empty
                                    array trigger a 422 response (BR-2).
Example Value                     : ["MON","TUE","WED","THU","FRI"]

Field Path                        : operatingHours
Type                              : Object
Required                          : Conditional (required if included)
Description                       : Defines the daily start and end time of the
                                    chauffeur's availability window.

Field Path                        : operatingHours.startTime
Type                              : String
Required                          : Yes (when operatingHours object is present)
Format                            : HH:mm (24-hour clock)
Regex                             : ^([01]\d|2[0-3]):[0-5]\d$
Validation                        : Must be a valid 24-hour time. Must be
                                    strictly before operatingHours.endTime.
                                    Must fall within the system-configured
                                    service operating window (BR-7).
Example Value                     : "07:00"

Field Path                        : operatingHours.endTime
Type                              : String
Required                          : Yes (when operatingHours object is present)
Format                            : HH:mm (24-hour clock)
Regex                             : ^([01]\d|2[0-3]):[0-5]\d$
Validation                        : Must be a valid 24-hour time. Must be
                                    strictly after operatingHours.startTime.
                                    Must fall within the system-configured
                                    service operating window (BR-7).
Example Value                     : "19:00"

Field Path                        : startingLocation
Type                              : Object
Required                          : Conditional (required if included; must not
                                    be null or empty)
Description                       : The geographic origin from which the
                                    chauffeur begins their shift.

Field Path                        : startingLocation.latitude
Type                              : Number (double)
Required                          : Yes (when startingLocation object is present)
Minimum                           : -90.0
Maximum                           : 90.0
Validation                        : Must be a valid WGS-84 latitude value.
Example Value                     : 51.5074

Field Path                        : startingLocation.longitude
Type                              : Number (double)
Required                          : Yes (when startingLocation object is present)
Minimum                           : -180.0
Maximum                           : 180.0
Validation                        : Must be a valid WGS-84 longitude value.
Example Value                     : -0.1278

Field Path                        : startingLocation.address
Type                              : String
Required                          : No (recommended for human-readable audit
                                    records and display purposes)
Max Length                        : 500 characters
Validation                        : If provided, must be a non-blank string.
                                    The system does not perform live geocoding
                                    validation on this field but stores it as
                                    supplied.
Example Value                     : "10 Downing Street, London, SW1A 2AA, UK"

Field Path                        : version
Type                              : Integer or String (implementation-dependent)
Required                          : No in body (conveyed via If-Match header;
                                    included here for clients that prefer body-
                                    based versioning)
Description                       : Current resource version. If supplied in
                                    the body it must match the If-Match header
                                    value. Mismatch results in 409.


2.5 Example Request
-------------------

PATCH /api/v1/chauffeurs/123e4567-e89b-12d3-a456-426614174000/schedule
Authorization: Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9...
Content-Type: application/json
If-Match: "v7"
Accept: application/json

{
  "operatingDays": ["MON","TUE","WED","THU","FRI"],
  "operatingHours": {
    "startTime": "07:00",
    "endTime": "19:00"
  },
  "startingLocation": {
    "latitude": 51.5074,
    "longitude": -0.1278,
    "address": "10 Downing Street, London, SW1A 2AA, UK"
  }
}


---------------------------------------------------------------------------
SECTION 3 — RESPONSE SPECIFICATION
---------------------------------------------------------------------------

3.1 HTTP 200 OK — Successful Schedule Update
--------------------------------------------

Returned when the schedule has been successfully validated, persisted, and the
audit log entry has been written.

Response Headers:
  Content-Type : application/json
  ETag         : New version identifier of the updated resource, e.g. "v8"
  Last-Modified: UTC timestamp of the update in RFC 7231 format

Response Body Schema:

Field                          : chauffeurId
Type                           : String (UUID)
Description                    : The identifier of the chauffeur whose schedule
                                 was updated.

Field                          : operatingDays
Type                           : Array of String
Description                    : The persisted list of operating day identifiers.

Field                          : operatingHours
Type                           : Object
Description                    : The persisted operating hours window.

Field                          : operatingHours.startTime
Type                           : String (HH:mm)
Description                    : Persisted start time.

Field                          : operatingHours.endTime
Type                           : String (HH:mm)
Description                    : Persisted end time.

Field                          : startingLocation
Type                           : Object
Description                    : The persisted starting location.

Field                          : startingLocation.latitude
Type                           : Number
Description                    : Persisted latitude.

Field                          : startingLocation.longitude
Type                           : Number
Description                    : Persisted longitude.

Field                          : startingLocation.address
Type                           : String
Description                    : Persisted human-readable address (if supplied).

Field                          : version
Type                           : String or Integer
Description                    : New resource version / ETag value.

Field                          : updatedAt
Type                           : String (ISO 8601 UTC datetime)
Description                    : UTC timestamp at which the update was persisted.

Example 200 Response Body:

{
  "chauffeurId": "123e4567-e89b-12d3-a456-426614174000",
  "operatingDays": ["MON","TUE","WED","THU","FRI"],
  "operatingHours": {
    "startTime": "07:00",
    "endTime": "19:00"
  },
  "startingLocation": {
    "latitude": 51.5074,
    "longitude": -0.1278,
    "address": "10 Downing Street, London, SW1A 2AA, UK"
  },
  "version": "v8",
  "updatedAt": "2025-06-15T10:32:00Z"
}


3.2 HTTP 400 Bad Request — Malformed Request
--------------------------------------------

Returned when the request cannot be parsed (e.g. invalid JSON syntax, missing
Content-Type header, or a path parameter that is not a valid UUID format).

Response Body Schema:

Field          : status
Type           : Integer
Value          : 400

Field          : errorCode
Type           : String
Description    : Machine-readable error code.

Field          : message
Type           : String
Description    : Human-readable description of the parse or format error.

Field          : traceId
Type           : String
Description    : Correlation identifier for log tracing.

Example 400 Response Body:

{
  "status": 400,
  "errorCode": "MALFORMED_REQUEST",
  "message": "Request body could not be

ENDPOINT: PUT /api/v1/vehicle-condition-reports/sessions/{sessionId}/odometer

Source Requirement IDs: SER-010-020-062, SER-010-020-063


---------------------------------------------------------------------------
SECTION 1: ENDPOINT OVERVIEW
---------------------------------------------------------------------------

Path            : /api/v1/vehicle-condition-reports/sessions/{sessionId}/odometer
HTTP Method     : PUT
Summary         : Submit odometer reading for a vehicle condition report session.
Description     : Allows an authenticated chauffeur to submit the current odometer
                  reading for the vehicle associated with an active vehicle condition
                  report session. The submitted value is validated for non-negativity
                  and monotonicity against the last recorded reading for the vehicle.
                  On success, the reading is persisted with a server-side timestamp,
                  the odometer workflow step is marked complete, the session is
                  advanced to the next workflow stage (SER-010-020-070), and an
                  immutable audit trail entry is appended. The endpoint supports
                  idempotent re-submission of the same value and returns an anomaly
                  flag when the submitted reading deviates from expected patterns.


---------------------------------------------------------------------------
SECTION 2: REQUEST SPECIFICATION
---------------------------------------------------------------------------

2.1 Request Headers

Header Name       Required   Description
Authorization     Yes        Bearer JWT token issued by the OAuth2/OIDC provider.
                             Format: "Bearer <token>"
                             The token must contain the authenticated chauffeur
                             identity claim and the CHAUFFEUR role claim.
Content-Type      Yes        Must be "application/json".
Accept            No         Should be "application/json". Defaults to
                             "application/json" if omitted.
X-Request-ID      No         Client-generated UUID for request tracing and
                             idempotency correlation. Recommended for all
                             production callers. Format: UUID v4.
                             Example: "f47ac10b-58cc-4372-a567-0e02b2c3d479"


2.2 Path Parameters

Parameter Name   Type     Required   Description
sessionId        string   Yes        The unique identifier of the vehicle condition
                                     report session for which the odometer reading
                                     is being submitted.
                                     Format: UUID v4.
                                     Example: "3fa85f64-5717-4562-b3fc-2c963f66afa6"
                                     Validation: Must be a valid UUID. Non-UUID
                                     values result in a 400 Bad Request response.


2.3 Query Parameters

None defined for this endpoint.


2.4 Request Body Schema

Content-Type: application/json

The request body must be a JSON object containing the following fields.

Field Name       Type     Required   Description and Validation Rules
odometerReading  number   Yes        The current odometer reading of the vehicle
                                     at the time of pickup, expressed as a numeric
                                     value representing total distance units
                                     (kilometres or miles, consistent with the
                                     vehicle record's configured unit).

                                     Type        : number (integer or decimal)
                                     Required    : Yes
                                     Minimum     : 0 (zero is permitted for first-
                                                   time capture on a new vehicle)
                                     Maximum     : 9999999 (seven digits; values
                                                   exceeding this are rejected as
                                                   implausible)
                                     Negative    : Not permitted. Any value below
                                                   zero is rejected with 422.
                                     Null        : Not permitted. A null value is
                                                   treated as missing and rejected
                                                   with 422.
                                     Non-numeric : Not permitted. String or boolean
                                                   values are rejected with 400.
                                     Decimal     : Permitted up to 1 decimal place.
                                                   Values with more than 1 decimal
                                                   place are rejected with 422.
                                     Example     : 24531.7

unit             string   No         The unit of measurement for the odometer
                                     reading. If omitted, the system defaults to
                                     the unit configured on the vehicle record.
                                     Permitted values: "km", "mi"
                                     If provided, must match the unit configured
                                     on the vehicle record; a mismatch results in
                                     a 422 response.
                                     Example: "km"


2.5 Example Request

PUT /api/v1/vehicle-condition-reports/sessions/3fa85f64-5717-4562-b3fc-2c963f66afa6/odometer
Authorization: Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9...
Content-Type: application/json
X-Request-ID: f47ac10b-58cc-4372-a567-0e02b2c3d479

{
  "odometerReading": 24531.7,
  "unit": "km"
}


---------------------------------------------------------------------------
SECTION 3: RESPONSE SPECIFICATION
---------------------------------------------------------------------------

3.1 HTTP 200 OK

Returned when the odometer reading is successfully persisted, or when an
identical odometer value has already been recorded for this session
(idempotent re-submission).

Response Body Schema:

Field Name              Type      Description
sessionId               string    The session identifier. UUID v4.
odometerReading         number    The persisted odometer reading value.
unit                    string    The unit of the odometer reading ("km" or "mi").
odometerSubmittedAt     string    ISO 8601 UTC timestamp of when the reading was
                                  persisted server-side.
                                  Format: "YYYY-MM-DDTHH:MM:SS.sssZ"
submittedByChauffeurId  string    The chauffeur identity extracted from the JWT
                                  claim at the time of submission. UUID v4.
odometerStepStatus      string    Status of the odometer workflow step.
                                  Value: "COMPLETE"
nextWorkflowStage       string    The workflow stage now enabled for progression.
                                  Value: "SER-010-020-070"
anomalyFlag             boolean   Indicates whether the submitted reading triggered
                                  an anomaly condition (e.g., unusually large jump
                                  from the prior reading). True if anomaly detected,
                                  false otherwise. An anomaly does not block
                                  submission; it is informational.
anomalyDetail           string    Human-readable description of the anomaly
                                  condition if anomalyFlag is true. Null if
                                  anomalyFlag is false.
idempotent              boolean   True if this response reflects a previously
                                  persisted value (duplicate submission detected).
                                  False if this is a new or updated write.

Example Response Body (new submission, no anomaly):

{
  "sessionId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
  "odometerReading": 24531.7,
  "unit": "km",
  "odometerSubmittedAt": "2025-06-15T08:42:11.304Z",
  "submittedByChauffeurId": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
  "odometerStepStatus": "COMPLETE",
  "nextWorkflowStage": "SER-010-020-070",
  "anomalyFlag": false,
  "anomalyDetail": null,
  "idempotent": false
}

Example Response Body (idempotent re-submission):

{
  "sessionId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
  "odometerReading": 24531.7,
  "unit": "km",
  "odometerSubmittedAt": "2025-06-15T08:42:11.304Z",
  "submittedByChauffeurId": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
  "odometerStepStatus": "COMPLETE",
  "nextWorkflowStage": "SER-010-020-070",
  "anomalyFlag": false,
  "anomalyDetail": null,
  "idempotent": true
}

Example Response Body (anomaly detected):

{
  "sessionId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
  "odometerReading": 98750.0,
  "unit": "km",
  "odometerSubmittedAt": "2025-06-15T09:10:05.812Z",
  "submittedByChauffeurId": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
  "odometerStepStatus": "COMPLETE",
  "nextWorkflowStage": "SER-010-020-070",
  "anomalyFlag": true,
  "anomalyDetail": "Submitted reading is 74218.3 km higher than the last recorded value of 24531.7 km, which exceeds the expected threshold.",
  "idempotent": false
}


3.2 HTTP 400 Bad Request

Returned when the request is structurally malformed, the sessionId path
parameter is not a valid UUID, or the request body contains a non-numeric
value for odometerReading.

Response Body Schema:

Field Name   Type     Description
status       integer  HTTP status code. Value: 400
errorCode    string   Machine-readable error code.
message      string   Human-readable description of the error.
details      array    List of field-level error objects (may be empty).
  field      string   The field or parameter that caused the error.
  issue      string   Description of the specific issue with that field.
traceId      string   Correlation ID for log tracing. Matches X-Request-ID
                      if provided by the caller, otherwise server-generated.

Example Response Body:

{
  "status": 400,
  "errorCode": "INVALID_REQUEST",
  "message": "The request could not be parsed. One or more fields contain invalid data types.",
  "details": [
    {
      "field": "odometerReading",
      "issue": "Value must be a numeric type. Received: string."
    }
  ],
  "traceId": "f47ac10b-58cc-4372-a567-0e02b2c3d479"
}


3.3 HTTP 401 Unauthorized

Returned when the Authorization header is absent, the Bearer token is
missing, expired, or fails signature validation.

Response Body Schema: Same structure as 400.

Example Response Body:

{
  "status": 401,
  "errorCode": "UNAUTHORIZED",
  "message": "Authentication is required. Provide a valid Bearer JWT token.",
  "details": [],
  "traceId": "c9d8e7f6-a5b4-3210-fedc-ba9876543210"
}


3.4 HTTP 403 Forbidden

Returned when the authenticated chauffeur does not hold the CHAUFFEUR role,
or when the authenticated chauffeur is not the assigned chauffeur for the
appointment linked to the session (ownership check failure, BR-4).

Response Body Schema: Same structure as 400.

Example Response Body:

{
  "status": 403,
  "errorCode": "FORBIDDEN",
  "message": "You are not authorised to update the odometer reading for this session.",
  "details": [],
  "traceId": "11223344-5566-7788-99aa-bbccddeeff00"
}


3.5 HTTP 404 Not Found

Returned when the vehicle condition report session identified by sessionId
does not exist in the system (BR-1).

Response Body Schema: Same structure

ENDPOINT: POST /api/v1/delay-detection/trigger

Source Requirement IDs: SER-010-020-027, SER-010-020-085

================================================================================
SECTION 1: ENDPOINT IDENTIFICATION
================================================================================

Path            : /api/v1/delay-detection/trigger
HTTP Method     : POST
Summary         : Manually triggers an immediate delay-detection scan cycle for
                  all active trips; intended for coordinator or ops use when an
                  ad-hoc check is required.
Description     : This endpoint initiates a delay-detection evaluation for a
                  specific active appointment and its assigned chauffeur. When
                  invoked, the system retrieves real-time location and ETA data
                  from the Map API, compares the revised ETA against the
                  scheduled pick-up time, and — if the configurable delay
                  threshold is exceeded — flags the appointment as delayed,
                  persists the revised ETA, dispatches an alert to the Pickup
                  Coordinator dashboard, and appends an immutable audit trail
                  entry. The endpoint is exclusively available to internal
                  orchestration service identities and is not exposed to
                  end-user roles. The trigger is also invoked autonomously by
                  the system when upstream real-time tracking data signals a
                  route or schedule deviation (BR-7).


================================================================================
SECTION 2: SECURITY REQUIREMENTS
================================================================================

2.1 Authentication
    Mechanism   : Bearer JWT (OAuth2 / OIDC)
    Requirement : Every request must carry a valid, unexpired Bearer JWT in the
                  Authorization header. The token signature, expiry (exp claim),
                  and issuer (iss claim) are validated on every call before any
                  business logic is executed.

2.2 Authorisation
    Model       : Role-Based Access Control (RBAC)
    Permitted Roles:
        - INTEGRATION_SERVICE
        - SYSTEM_ORCHESTRATOR
    Required OAuth2 Scope:
        - delay-detection:trigger
    Restriction : This endpoint is not exposed to end-user roles. Only internal
                  orchestration services and system-level identities may invoke
                  it. Any JWT that does not carry one of the permitted roles AND
                  the required scope must be rejected with HTTP 403.

2.3 Rate Limiting
    Limit       : 30 requests per minute per service identity
    Burst       : Up to 10 requests per second
    Enforcement : Rate-limit counters are keyed on the service identity claim
                  extracted from the JWT (e.g., sub or client_id). Requests
                  exceeding the limit receive HTTP 429 with a Retry-After header
                  indicating when the caller may next attempt the request.


================================================================================
SECTION 3: REQUEST SPECIFICATION
================================================================================

3.1 Request Headers

    Header Name       Required   Description
    ---------------   --------   -----------------------------------------------
    Authorization     Yes        Bearer <JWT token>. Must be a valid, unexpired
                                 OAuth2/OIDC JWT carrying the permitted role and
                                 scope.
    Content-Type      Yes        Must be application/json.
    X-Correlation-ID  No         Optional caller-supplied UUID for end-to-end
                                 request tracing. If absent, the system generates
                                 one and echoes it in the response.
    X-Idempotency-Key No         Optional explicit idempotency key supplied by
                                 the caller. If absent, the system derives the
                                 deduplication key from appointmentId +
                                 chauffeurId + triggeredAt truncated to the
                                 nearest minute.

3.2 Path Parameters
    None.

3.3 Query Parameters
    None.

3.4 Request Body Schema

    Content-Type: application/json

    Field Name      Type      Required   Description and Validation Rules
    -------------   -------   --------   ----------------------------------------
    appointmentId   string    Yes        Unique identifier of the appointment for
                                         which delay detection is being triggered.
                                         Format: UUID v4 (pattern:
                                         ^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-4
                                         [0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-
                                         [0-9a-fA-F]{12}$).
                                         Must not be null or empty.
                                         Must resolve to an existing, active
                                         appointment record (BR-1, BR-5).

    chauffeurId     string    Yes        Unique identifier of the chauffeur/driver
                                         currently assigned to the appointment.
                                         Format: UUID v4 (same pattern as above).
                                         Must not be null or empty.
                                         Must resolve to a chauffeur currently
                                         assigned to the referenced appointment
                                         and in an active trip state (BR-5).

    triggeredAt     string    No         ISO 8601 UTC timestamp indicating when
                                         the trigger was initiated by the caller
                                         or upstream orchestrator.
                                         Format: date-time (e.g.,
                                         2025-06-15T10:30:00Z).
                                         If absent, the server assigns the current
                                         UTC timestamp at the moment of receipt.
                                         Used as part of the idempotency key
                                         computation (truncated to the nearest
                                         minute).

    triggerSource   string    No         Identifies the origin of the trigger.
                                         Allowed values: SYSTEM_AUTOMATED,
                                         COORDINATOR_MANUAL, ORCHESTRATOR.
                                         Defaults to SYSTEM_AUTOMATED if absent.
                                         Max length: 50 characters.

3.5 Request Body Example

    {
      "appointmentId": "a3f1c2d4-5e6b-4f7a-8c9d-0e1f2a3b4c5d",
      "chauffeurId":   "b7e2d3f5-6a7c-4e8b-9d0e-1f2a3b4c5d6e",
      "triggeredAt":   "2025-06-15T10:30:00Z",
      "triggerSource": "SYSTEM_AUTOMATED"
    }


================================================================================
SECTION 4: RESPONSE SPECIFICATION
================================================================================

4.1 HTTP 200 OK — Idempotent Duplicate Detected

    Condition   : The system detected that an identical trigger (same
                  appointmentId + chauffeurId + truncated triggeredAt) was
                  already processed within the deduplication window. The
                  previously recorded result is returned without re-dispatching
                  notifications or creating duplicate audit entries.

    Response Body Schema:

    Field Name          Type      Description
    -----------------   -------   -----------------------------------------------
    status              string    Always "DUPLICATE_DETECTED" for this case.
    appointmentId       string    UUID of the appointment.
    chauffeurId         string    UUID of the chauffeur.
    revisedEta          string    ISO 8601 UTC timestamp of the previously
                                  computed revised ETA.
    delayDetected       boolean   true if delay was confirmed in the original
                                  trigger.
    originalTriggeredAt string    ISO 8601 UTC timestamp of the original trigger.
    correlationId       string    Correlation ID for tracing.
    message             string    Human-readable explanation.

    Example:
    {
      "status": "DUPLICATE_DETECTED",
      "appointmentId": "a3f1c2d4-5e6b-4f7a-8c9d-0e1f2a3b4c5d",
      "chauffeurId":   "b7e2d3f5-6a7c-4e8b-9d0e-1f2a3b4c5d6e",
      "revisedEta":    "2025-06-15T11:05:00Z",
      "delayDetected": true,
      "originalTriggeredAt": "2025-06-15T10:30:00Z",
      "correlationId": "c1d2e3f4-0001-4abc-8def-000000000001",
      "message": "Duplicate trigger detected within deduplication window.
                  Previously recorded result returned."
    }

4.2 HTTP 201 Created — Delay Detection Trigger Successfully Processed

    Condition   : The trigger was processed for the first time (or outside the
                  deduplication window), the delay evaluation completed, the
                  appointment record was updated, the audit entry was persisted,
                  and the coordinator notification was dispatched or queued.

    Response Body Schema:

    Field Name              Type      Description
    ---------------------   -------   -------------------------------------------
    status                  string    "DELAY_DETECTED" if delay threshold was
                                      exceeded; "NO_DELAY_DETECTED" if ETA is
                                      within threshold.
    appointmentId           string    UUID of the appointment.
    chauffeurId             string    UUID of the chauffeur.
    originalEta             string    ISO 8601 UTC timestamp of the original
                                      scheduled pick-up ETA from the appointment
                                      record.
    revisedEta              string    ISO 8601 UTC timestamp of the newly computed
                                      ETA from the Map API.
    delayDetected           boolean   true if the revised ETA exceeds the
                                      scheduled pick-up time by the configured
                                      threshold.
    delayThresholdMinutes   integer   The configured threshold (in minutes) used
                                      for the evaluation.
    detectionTimestamp      string    ISO 8601 UTC timestamp at which the delay
                                      was detected (server-generated).
    workflowState           string    New workflow state set on the appointment
                                      (e.g., "SER-010-020-085").
    notificationStatus      string    "DISPATCHED" if the coordinator alert was
                                      sent synchronously; "QUEUED" if it was
                                      placed on the retry queue.
    correlationId           string    Correlation ID for end-to-end tracing.
    auditEntryId            string    UUID of the immutable audit trail entry
                                      created for this event.
    message                 string    Human-readable summary.

    Example (delay detected):
    {
      "status":                "DELAY_DETECTED",
      "appointmentId":         "a3f1c2d4-5e6b-4f7a-8c9d-0e1f2a3b4c5d",
      "chauffeurId":           "b7e2d3f5-6a7c-4e8b-9d0e-1f2a3b4c5d6e",
      "originalEta":           "2025-06-15T10:45:00Z",
      "revisedEta":            "2025-06-15T11:05:00Z",
      "delayDetected":         true,
      "delayThresholdMinutes": 10,
      "detectionTimestamp":    "2025-06-15T10:30:05Z",
      "workflowState":         "SER-010-020-085",
      "notificationStatus":    "DISPATCHED",
      "correlationId":         "c1d2e3f4-0001-4abc-8def-000000000002",
      "auditEntryId":          "d4e5f6a7-0002-4bcd-9ef0-000000000003",
      "message": "Delay detected. Coordinator notified. Workflow transitioned
                  to SER-010-020-085."
    }

    Example (no delay detected):
    {
      "status":                "NO_DELAY_DETECTED",
      "appointmentId":         "a3f1c2d4-5e6b-4f7a-8c9d-0e1f2a3b4c5d",
      "chauffeurId":           "b7e2d3f5-6a7c-4e8b-9d0e-1f2a3b4c5d6e",
      "originalEta":           "2025-06-15T10:45:00Z",
      "revisedEta":            "2025-06-15T10:47:00Z",
      "delayDetected":         false,
      "delayThresholdMinutes": 10,
      "detectionTimestamp":    "2025-06-15T10:30:05Z",
      "workflowState":         "SER-010-020-085",
      "notificationStatus":    "NOT_REQUIRED",
      "correlationId":         "c1d2e3f4-0001-4abc-8def-000000000004",
      "auditEntryId":          "d4e5f6a7-0002-4bcd-9ef0-000000000005",
      "message": "No delay detected. ETA within acceptable

ENDPOINT DESIGN DOCUMENT

Path: /api/v1/chauffeurs/{chauffeurId}/arrivals
HTTP Method: POST
Summary: Record chauffeur arrival at customer or drop location and trigger arrival notification
Source Requirement IDs: SER-010-020-039, SER-010-020-116


---------------------------------------------------------------------------
SECTION 1: ENDPOINT OVERVIEW
---------------------------------------------------------------------------

This endpoint records the arrival of a chauffeur at a customer or drop location. When invoked, the system persists an immutable arrival event, advances the appointment workflow state to the post-arrival step (SER-010-020-040), and asynchronously dispatches arrival notifications to the customer across three channels: ICP, WhatsApp, and SMS. The notification payload includes the chauffeur's live location and the customer's name. Notification dispatch failures do not affect the arrival record. The endpoint enforces idempotency to prevent duplicate arrival events for the same chauffeur and appointment pair.


---------------------------------------------------------------------------
SECTION 2: REQUEST SPECIFICATION
---------------------------------------------------------------------------

2.1 HTTP Method and Path

    POST /api/v1/chauffeurs/{chauffeurId}/arrivals

2.2 Request Headers

    Header Name         : Authorization
    Required            : Yes
    Format              : Bearer <JWT token>
    Description         : OAuth2/OIDC Bearer token. Must be a valid, non-expired JWT issued by the authorised identity provider. Used for authentication and role extraction.

    Header Name         : Content-Type
    Required            : Yes
    Allowed Value       : application/json
    Description         : Request body must be JSON-encoded.

    Header Name         : Accept
    Required            : No
    Recommended Value   : application/json
    Description         : Indicates the client expects a JSON response.

    Header Name         : X-Idempotency-Key
    Required            : No (recommended for safe retries)
    Format              : UUID v4 string
    Description         : Optional client-supplied idempotency key to support safe retry semantics. If provided, the system may use this key in conjunction with the natural idempotency key (chauffeurId + appointmentId) to detect and deduplicate concurrent or repeated submissions.

    Header Name         : X-Request-ID
    Required            : No
    Format              : UUID v4 string
    Description         : Optional correlation identifier for distributed tracing and log correlation across services.

2.3 Path Parameters

    Parameter Name      : chauffeurId
    Location            : Path
    Type                : String
    Required            : Yes
    Format              : Non-empty string; expected to be a UUID v4 or system-defined identifier
    Validation Rules    :
        - Must not be null or empty
        - Must match the pattern of a registered chauffeur identifier in the chauffeur registry
        - Must correspond to an existing, active chauffeur record
    Error if invalid    : 404 with error code CHAUFFEUR_NOT_FOUND

2.4 Query Parameters

    None defined for this endpoint.

2.5 Request Body Schema

    Content-Type: application/json

    Field Name          : liveLocation
    Type                : Object
    Required            : Yes
    Description         : The chauffeur's current geolocation at the time of arrival. Must be a valid geolocation payload.
    Validation Rules    :
        - Must not be null or absent
        - Must contain both latitude and longitude sub-fields
        - Must be a well-formed geolocation value

    Field Name          : liveLocation.latitude
    Type                : Number (double)
    Required            : Yes
    Description         : Latitude coordinate of the chauffeur's current position.
    Validation Rules    :
        - Must be a numeric value
        - Valid range: -90.0 to 90.0 inclusive
        - Must not be null

    Field Name          : liveLocation.longitude
    Type                : Number (double)
    Required            : Yes
    Description         : Longitude coordinate of the chauffeur's current position.
    Validation Rules    :
        - Must be a numeric value
        - Valid range: -180.0 to 180.0 inclusive
        - Must not be null

    Field Name          : liveLocation.accuracy
    Type                : Number (float)
    Required            : No
    Description         : Accuracy of the geolocation reading in metres. Optional but recommended.
    Validation Rules    :
        - If present, must be a non-negative number

    Field Name          : liveLocation.timestamp
    Type                : String
    Required            : No
    Format              : ISO 8601 UTC datetime (e.g., 2024-06-15T10:30:00Z)
    Description         : The timestamp at which the location reading was captured by the device. Optional.
    Validation Rules    :
        - If present, must be a valid ISO 8601 datetime string
        - Must not be a future timestamp

    Example Request Body:

        {
          "liveLocation": {
            "latitude": 51.507351,
            "longitude": -0.127758,
            "accuracy": 10.5,
            "timestamp": "2024-06-15T10:29:45Z"
          }
        }


---------------------------------------------------------------------------
SECTION 3: RESPONSE SPECIFICATION
---------------------------------------------------------------------------

3.1 HTTP 201 Created — Successful Arrival Recording

    Description: The arrival event has been successfully persisted, the appointment state has been advanced, and notification dispatch has been initiated asynchronously.

    Response Body Schema:

        Field Name              : arrivalEventId
        Type                    : String (UUID)
        Description             : System-generated unique identifier for the created arrival event record.

        Field Name              : chauffeurId
        Type                    : String
        Description             : The chauffeur identifier from the path parameter, echoed back for confirmation.

        Field Name              : appointmentId
        Type                    : String
        Description             : The appointment identifier resolved from the chauffeur-appointment mapping.

        Field Name              : customerName
        Type                    : String
        Description             : The customer name resolved from the appointment record at the time of arrival.

        Field Name              : liveLocation
        Type                    : Object
        Description             : The live location payload as submitted in the request, echoed back.

        Field Name              : arrivedAt
        Type                    : String (ISO 8601 UTC)
        Description             : System-generated UTC timestamp at which the arrival was recorded.

        Field Name              : notificationStatus
        Type                    : Object
        Description             : Summary of notification dispatch initiation status per channel.

        Field Name              : notificationStatus.icp
        Type                    : String
        Allowed Values          : DISPATCHED, QUEUED, FAILED
        Description             : Dispatch status for the ICP notification channel.

        Field Name              : notificationStatus.whatsapp
        Type                    : String
        Allowed Values          : DISPATCHED, QUEUED, FAILED
        Description             : Dispatch status for the WhatsApp notification channel.

        Field Name              : notificationStatus.sms
        Type                    : String
        Allowed Values          : DISPATCHED, QUEUED, FAILED
        Description             : Dispatch status for the SMS notification channel.

        Field Name              : workflowStep
        Type                    : String
        Description             : The workflow step identifier to which the appointment has been advanced (SER-010-020-040).

    Example 201 Response Body:

        {
          "arrivalEventId": "a3f7c2d1-84b0-4e2a-9c3f-1d2e3f4a5b6c",
          "chauffeurId": "c1d2e3f4-0001-4abc-8def-123456789abc",
          "appointmentId": "appt-9988-7766-5544",
          "customerName": "Jane Doe",
          "liveLocation": {
            "latitude": 51.507351,
            "longitude": -0.127758,
            "accuracy": 10.5,
            "timestamp": "2024-06-15T10:29:45Z"
          },
          "arrivedAt": "2024-06-15T10:30:02Z",
          "notificationStatus": {
            "icp": "DISPATCHED",
            "whatsapp": "DISPATCHED",
            "sms": "QUEUED"
          },
          "workflowStep": "SER-010-020-040"
        }

3.2 HTTP 400 Bad Request — Malformed Request

    Description: The request body is syntactically invalid, missing required fields, or contains values that fail schema-level validation.

    Response Body Schema:

        Field Name              : errorCode
        Type                    : String
        Description             : Machine-readable error code.

        Field Name              : errorMessage
        Type                    : String
        Description             : Human-readable description of the error.

        Field Name              : fieldErrors
        Type                    : Array of Objects
        Description             : List of field-level validation failures, if applicable.

        Field Name              : fieldErrors[].field
        Type                    : String
        Description             : The name of the field that failed validation.

        Field Name              : fieldErrors[].message
        Type                    : String
        Description             : Description of the validation failure for that field.

    Example 400 Response Body:

        {
          "errorCode": "INVALID_REQUEST",
          "errorMessage": "Request body contains invalid or missing fields.",
          "fieldErrors": [
            {
              "field": "liveLocation.latitude",
              "message": "Latitude must be between -90.0 and 90.0."
            }
          ]
        }

3.3 HTTP 401 Unauthorized — Authentication Failure

    Description: The Bearer JWT is absent, expired, malformed, or cannot be validated by the identity provider.

    Example 401 Response Body:

        {
          "errorCode": "UNAUTHORIZED",
          "errorMessage": "Authentication token is missing or invalid."
        }

3.4 HTTP 403 Forbidden — Authorisation Failure

    Description: The authenticated caller does not hold a role or scope that permits recording an arrival for the specified chauffeurId.

    Example 403 Response Body:

        {
          "errorCode": "FORBIDDEN",
          "errorMessage": "Caller does not have permission to record an arrival for this chauffeur."
        }

3.5 HTTP 404 Not Found — Chauffeur or Appointment Not Found

    Description: The chauffeurId does not correspond to any registered chauffeur, or no active appointment is found for the chauffeur.

    Scenario A — Chauffeur not found (BR-8):

        {
          "errorCode": "CHAUFFEUR_NOT_FOUND",
          "errorMessage": "Chauffeur not found."
        }

    Scenario B — No active appointment found (BR-1):

        {
          "errorCode": "APPOINTMENT_NOT_FOUND",
          "errorMessage": "No active appointment found for the specified chauffeur."
        }

3.6 HTTP 409 Conflict — Duplicate Arrival or Data Conflict

    Description: An arrival record already exists for this chauffeurId and active appointment (idempotency violation), or the appointment record is missing required data (customer name unresolvable).

    Scenario A — Duplicate arrival (BR-9):

        {
          "errorCode": "ARRIVAL_ALREADY_RECORDED",
          "errorMessage": "Arrival already recorded for this chauffeur and appointment."
        }

    Scenario B — Customer name unresolvable (BR-3):

        {
          "errorCode": "APPOINTMENT_DATA_INCOMPLETE",
          "errorMessage": "Appointment record is missing customer name; arrival cannot be recorded."
        }

3.7 HTTP 422 Unprocessable Entity — Semantic Validation Failure

    Description: The request is syntactically valid but fails business-level semantic validation, specifically the live location is absent or invalid (BR-2).

    Example 422 Response Body:

        {
          "errorCode": "INVALID_LIVE

ENDPOINT DESIGN DOCUMENT
=========================

Source Requirement ID : SER-010-020-093
Endpoint Path         : /api/v1/crm/webhooks/inbound
HTTP Method           : POST
Summary               : Receive inbound CRM event callbacks (e.g. JC completion) and translate to internal domain events
Security Scope        : crm:webhook:inbound
Security Roles        : INTEGRATION_SERVICE, CRM_WEBHOOK_PUBLISHER


---------------------------------------------------------------------------
SECTION 1 - ENDPOINT IDENTIFICATION
---------------------------------------------------------------------------

Path        : /api/v1/crm/webhooks/inbound
Method      : POST
Summary     : Receive inbound CRM event callbacks and translate to internal domain events
Description :
  This endpoint acts as the inbound webhook receiver for the CRM peripheral
  system. When a service appointment is completed in CRM and the customer has
  opted in for drop service, CRM delivers a POST payload to this endpoint.
  The system validates the payload, enforces idempotency, persists a drop
  request record, propagates it to the DBP Pickup and Drop scheduling
  dashboard, and appends an immutable audit trail entry. The endpoint is
  designed to be safe for re-delivery; duplicate webhook events for the same
  service appointment number are acknowledged without creating duplicate
  records.


---------------------------------------------------------------------------
SECTION 2 - REQUEST SPECIFICATION
---------------------------------------------------------------------------

2.1 Request Headers
-------------------

Header Name              Required   Description
X-CRM-Signature          Yes        HMAC-SHA256 signature of the raw request
                                    body computed using the pre-shared secret.
                                    Format: sha256=<hex-digest>
                                    The gateway validates this header before
                                    forwarding the request to the handler.
                                    Absence or mismatch results in HTTP 401.

Content-Type             Yes        Must be application/json.
                                    Any other value results in HTTP 415.

X-Request-ID             No         Optional idempotency / correlation ID
                                    supplied by the caller for tracing.
                                    Stored in the audit trail if present.

Authorization            Conditional  Bearer JWT token may be required for
                                    internal API gateway routing depending on
                                    deployment topology. Validated by the
                                    gateway before the HMAC check.


2.2 Path Parameters
-------------------

None.


2.3 Query Parameters
--------------------

None.


2.4 Request Body Schema
-----------------------

Content-Type : application/json

All eight fields listed below are mandatory. The payload must be a single
JSON object at the root level.

Field Name                  Type      Required  Constraints
--------------------------  --------  --------  ------------------------------------------
serviceAppointmentNumber    string    Yes       Non-empty. Unique identifier issued by CRM.
                                                Acts as the idempotency key.
                                                Max length: 100 characters.
                                                Regex: ^[A-Za-z0-9\-_]+$

dropServiceSelection        boolean   Yes       Must be present and must be true for a drop
                                                request to be created. If false or absent,
                                                the event is acknowledged with no action
                                                (BR-3). No other value type is accepted.

customerName                string    Yes       Non-empty. Full name of the customer.
                                                Max length: 255 characters.

customerContact             string    Yes       Non-empty. Customer phone number or email.
                                                Max length: 100 characters.
                                                Phone regex (if numeric):
                                                ^\+?[0-9]{7,15}$
                                                Email format validated per RFC 5321 if
                                                value contains @.

vehicleRegistrationNumber   string    Yes       Non-empty. Must conform to the vehicle
                                                registration format recognised by the
                                                system. Must resolve to an existing vehicle
                                                record in the vehicle master store.
                                                Max length: 20 characters.
                                                Regex: ^[A-Z0-9\-]{2,20}$

dropAddress                 string    Yes       Non-empty. Full delivery address for the
                                                drop service.
                                                Max length: 500 characters.

requestedDropDatetime       string    Yes       ISO 8601 datetime string in UTC.
                                                Format: yyyy-MM-ddTHH:mm:ssZ
                                                Must represent a future datetime relative
                                                to the server clock at time of processing.

linkedJcNumber              string    Yes       Non-empty. Job Card number linking this
                                                service appointment to the workshop job
                                                card in DBP.
                                                Max length: 100 characters.
                                                Regex: ^[A-Za-z0-9\-_]+$


2.5 Example Request
-------------------

POST /api/v1/crm/webhooks/inbound
Content-Type: application/json
X-CRM-Signature: sha256=3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c
Authorization: Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9...
X-Request-ID: req-20240601-001

{
  "serviceAppointmentNumber": "SA-2024-00123",
  "dropServiceSelection": true,
  "customerName": "Rajesh Kumar",
  "customerContact": "+919876543210",
  "vehicleRegistrationNumber": "MH12AB1234",
  "dropAddress": "42, Park Street, Pune, Maharashtra 411001",
  "requestedDropDatetime": "2024-06-15T10:30:00Z",
  "linkedJcNumber": "JC-2024-00456"
}


---------------------------------------------------------------------------
SECTION 3 - RESPONSE SPECIFICATION
---------------------------------------------------------------------------

3.1 HTTP 200 - Accepted / Already Processed / No Action Required
-----------------------------------------------------------------

Returned in three distinct scenarios:
  a) Payload is valid, drop request is successfully created and persisted,
     and DBP notification is dispatched (or queued for retry).
  b) Duplicate delivery: a drop request for the same serviceAppointmentNumber
     already exists. No new record is created.
  c) dropServiceSelection is false or absent. No drop request is created.

Response Body Schema:

Field Name              Type     Description
----------------------  -------  -----------------------------------------------
status                  string   Processing outcome code.
                                 Values: CREATED, ALREADY_PROCESSED, NO_ACTION
message                 string   Human-readable description of the outcome.
dropRequestId           string   Internal drop request ID assigned by the system.
                                 Present only when status is CREATED.
                                 Null or absent for other statuses.
serviceAppointmentNumber string  Echo of the received service appointment number.
dbpSyncStatus           string   DBP propagation status.
                                 Values: SYNCED, PENDING_DBP_SYNC
                                 Present only when status is CREATED.

Example - Scenario (a) Drop request created and synced to DBP:

{
  "status": "CREATED",
  "message": "Drop request created and submitted to DBP scheduling dashboard.",
  "dropRequestId": "DR-2024-00789",
  "serviceAppointmentNumber": "SA-2024-00123",
  "dbpSyncStatus": "SYNCED"
}

Example - Scenario (a) Drop request created but DBP sync pending:

{
  "status": "CREATED",
  "message": "Drop request created. DBP sync pending; retry scheduled.",
  "dropRequestId": "DR-2024-00789",
  "serviceAppointmentNumber": "SA-2024-00123",
  "dbpSyncStatus": "PENDING_DBP_SYNC"
}

Example - Scenario (b) Duplicate delivery:

{
  "status": "ALREADY_PROCESSED",
  "message": "A drop request for this service appointment number has already been processed.",
  "dropRequestId": null,
  "serviceAppointmentNumber": "SA-2024-00123",
  "dbpSyncStatus": null
}

Example - Scenario (c) Drop service not opted in:

{
  "status": "NO_ACTION",
  "message": "Drop service selection is not opted in. No drop request created.",
  "dropRequestId": null,
  "serviceAppointmentNumber": "SA-2024-00123",
  "dbpSyncStatus": null
}


3.2 HTTP 400 - Bad Request
--------------------------

Returned when the service appointment number is absent or the payload
structure is fundamentally malformed (BR-1).

Response Body Schema:

Field Name   Type     Description
-----------  -------  -----------------------------------------------
status       string   Always BAD_REQUEST
errorCode    string   Application-level error code
message      string   Human-readable error description
field        string   Name of the offending field, if applicable

Example:

{
  "status": "BAD_REQUEST",
  "errorCode": "INVALID_SERVICE_APPOINTMENT_NUMBER",
  "message": "Invalid or missing service appointment number in webhook payload.",
  "field": "serviceAppointmentNumber"
}


3.3 HTTP 401 - Unauthorised
---------------------------

Returned when HMAC signature validation fails or the shared secret is
missing (BR-11).

Response Body Schema:

Field Name   Type     Description
-----------  -------  -----------------------------------------------
status       string   Always UNAUTHORISED
errorCode    string   Application-level error code
message      string   Human-readable error description

Example:

{
  "status": "UNAUTHORISED",
  "errorCode": "WEBHOOK_AUTH_FAILED",
  "message": "Webhook authentication failed: invalid or missing signature."
}


3.4 HTTP 403 - Forbidden
------------------------

Returned when the caller identity is authenticated but is not on the
source-system allowlist (i.e. not the authorised CRM system).

Response Body Schema:

Field Name   Type     Description
-----------  -------  -----------------------------------------------
status       string   Always FORBIDDEN
errorCode    string   Application-level error code
message      string   Human-readable error description

Example:

{
  "status": "FORBIDDEN",
  "errorCode": "SOURCE_NOT_PERMITTED",
  "message": "The requesting system is not authorised to publish to this webhook endpoint."
}


3.5 HTTP 415 - Unsupported Media Type
--------------------------------------

Returned when Content-Type is not application/json.

Response Body Schema:

Field Name   Type     Description
-----------  -------  -----------------------------------------------
status       string   Always UNSUPPORTED_MEDIA_TYPE
errorCode    string   Application-level error code
message      string   Human-readable error description

Example:

{
  "status": "UNSUPPORTED_MEDIA_TYPE",
  "errorCode": "INVALID_CONTENT_TYPE",
  "message": "Content-Type must be application/json."
}


3.6 HTTP 422 - Unprocessable Entity
-------------------------------------

Returned when field-level validation fails: missing mandatory fields,
invalid datetime, invalid vehicle registration number (BR-2, BR-4, BR-5).

Response Body Schema:

Field Name      Type     Description
--------------  -------  -----------------------------------------------
status          string   Always VALIDATION_ERROR
errorCode       string   Application-level error code
message         string   Human-readable summary
validationErrors array   List of individual field-level error objects

Each element in validationErrors:

Field Name   Type     Description
-----------  -------  -----------------------------------------------
field        string   Name of the failing field
message      string   Specific validation failure message

Example - Missing mandatory fields:

{
  "status": "VALIDATION_ERROR",
  "errorCode": "MANDATORY_FIELD_MISSING",
  "message": "One or more mandatory fields are missing from the CRM webhook payload.",
  "validationErrors": [
    {
      "field": "dropAddress",
      "message": "dropAddress is required and must not be empty."
    },
    {
      "field": "linkedJcNumber",
      "message": "linkedJcNumber is required and must not be empty."
    }
  ]
}

Example - Invalid drop datetime:

{
  "status": "VALIDATION_ERROR",
  "errorCode": "INVALID_DROP_DATETIME",
  "message": "Requested drop date and time must be a future datetime.",
  "validationErrors": [
    {
      "field": "requestedDropDatetime",

ENDPOINT DESIGN: GET /api/v1/audit-events/notifications

================================================================================
SECTION 1: ENDPOINT IDENTIFICATION
================================================================================

Path            : /api/v1/audit-events/notifications
HTTP Method     : GET
Summary         : List all outbound notification dispatch audit records filtered
                  by channel, recipient type, appointment reference, or date range
Source Activity IDs : SER-010-020-019, SER-010-020-026, SER-010-020-037

Description:
This endpoint retrieves an immutable, append-only list of audit records
representing outbound notification dispatch events generated during the
appointment lifecycle. Notifications may have been dispatched across any
supported channel (ICP, WhatsApp, SMS, DBP, CRM). The endpoint supports
filtering by notification channel, recipient role, appointment reference,
event type, and date range. All contact number fields are masked before
transmission to protect personally identifiable information. The endpoint
is read-only and produces no side-effects on the audit data store.


================================================================================
SECTION 2: REQUEST SPECIFICATION
================================================================================

2.1 Request Headers
--------------------------------------------------------------------------------

Header Name       : Authorization
Required          : Yes
Format            : Bearer <JWT token>
Description       : OAuth2/OIDC Bearer JWT issued by the authorised identity
                    provider. Must be non-expired, correctly signed, and issued
                    by the recognised issuer. Absence or invalidity results in
                    a 401 response.

Header Name       : Accept
Required          : No (defaults to application/json)
Allowed Values    : application/json
Description       : Specifies the desired response media type.

Header Name       : X-Correlation-ID
Required          : No
Format            : UUID v4 string
Description       : Optional caller-supplied correlation identifier for
                    distributed tracing. If supplied, echoed back in the
                    response header. If not supplied, the gateway generates one.

Header Name       : X-Request-ID
Required          : No
Format            : UUID v4 string
Description       : Optional idempotency/tracing identifier for the individual
                    request. Logged in the access audit entry.


2.2 Query Parameters
--------------------------------------------------------------------------------

Parameter Name    : appointmentId
Location          : Query string
Type              : String
Required          : No
Format            : Alphanumeric, max length 64 characters
Regex             : ^[A-Za-z0-9_-]{1,64}$
Description       : Filters results to audit records associated with the
                    specified appointment. If supplied, the Appointment Service
                    is called to verify existence and caller access before the
                    audit store is queried. If the appointment does not exist or
                    the caller lacks access, a 404 is returned for authorised
                    callers; unauthorised callers receive an empty result set to
                    prevent information leakage.
Business Rule Ref : BR-8

Parameter Name    : eventType
Location          : Query string
Type              : String (enumerated)
Required          : No
Allowed Values    : CHAUFFEUR_ASSIGNMENT_NOTIFICATION,
                    LIVE_TRIP_STATUS_NOTIFICATION,
                    REVISED_APPOINTMENT_NOTIFICATION
Description       : Filters results to audit records of the specified event
                    type. Values map directly to the originating activity IDs:
                    CHAUFFEUR_ASSIGNMENT_NOTIFICATION -> SER-010-020-019,
                    LIVE_TRIP_STATUS_NOTIFICATION     -> SER-010-020-026,
                    REVISED_APPOINTMENT_NOTIFICATION  -> SER-010-020-037.
                    Any value outside the allowed set results in a 400 response.

Parameter Name    : channel
Location          : Query string
Type              : String (enumerated)
Required          : No
Allowed Values    : ICP, WHATSAPP, SMS, DBP, CRM
Description       : Filters results to audit records for the specified
                    notification channel. Any value outside the allowed set
                    results in a 400 response.
Business Rule Ref : BR-3

Parameter Name    : recipientRole
Location          : Query string
Type              : String (enumerated)
Required          : No
Allowed Values    : CUSTOMER, PICKUP_COORDINATOR, CHAUFFEUR
Description       : Filters results to audit records where the notification
                    was addressed to the specified recipient role. Any value
                    outside the allowed set results in a 400 response.

Parameter Name    : fromDate
Location          : Query string
Type              : String
Required          : No
Format            : ISO 8601 date-time, UTC, e.g. 2024-06-01T00:00:00Z
Regex             : ^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$
Description       : Inclusive lower bound on the notification dispatch
                    timestamp. Must be a valid ISO 8601 UTC date-time. Must
                    not be a future date-time. Must be earlier than or equal
                    to toDate if both are supplied.

Parameter Name    : toDate
Location          : Query string
Type              : String
Required          : No
Format            : ISO 8601 date-time, UTC, e.g. 2024-06-30T23:59:59Z
Regex             : ^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$
Description       : Inclusive upper bound on the notification dispatch
                    timestamp. Must be a valid ISO 8601 UTC date-time. Must
                    be greater than or equal to fromDate if both are supplied.
                    Maximum allowed range between fromDate and toDate is 90
                    calendar days; requests exceeding this range are rejected
                    with a 400 response.

Parameter Name    : page
Location          : Query string
Type              : Integer
Required          : No
Default           : 1
Minimum           : 1
Description       : 1-based page number for paginated results. Non-integer
                    or values less than 1 result in a 400 response.

Parameter Name    : pageSize
Location          : Query string
Type              : Integer
Required          : No
Default           : 20
Minimum           : 1
Maximum           : 100
Description       : Number of records to return per page. Values outside the
                    range 1-100 result in a 400 response.

Parameter Name    : sortOrder
Location          : Query string
Type              : String (enumerated)
Required          : No
Default           : DESC
Allowed Values    : ASC, DESC
Description       : Sort direction applied to the notification dispatch
                    timestamp (dispatchedAt). Any value outside the allowed
                    set results in a 400 response.


2.3 Request Body
--------------------------------------------------------------------------------

Not applicable. This is a GET endpoint; no request body is accepted.
If a request body is supplied, it is silently ignored.


================================================================================
SECTION 3: RESPONSE SPECIFICATION
================================================================================

3.1 HTTP 200 - Success
--------------------------------------------------------------------------------

Description : The request was processed successfully. A paginated list of
              notification audit-event records matching the supplied filters
              is returned. The list may be empty if no records match.

Response Body Schema:

Field                          : data
Type                           : Array of AuditEventNotification objects
Description                    : The list of matching audit-event notification
                                 records. Empty array if no records match.

Field                          : pagination
Type                           : Object
Description                    : Pagination metadata for the result set.

Field                          : pagination.page
Type                           : Integer
Description                    : Current page number returned.

Field                          : pagination.pageSize
Type                           : Integer
Description                    : Number of records per page as applied.

Field                          : pagination.totalRecords
Type                           : Integer
Description                    : Total number of records matching the filters
                                 across all pages.

Field                          : pagination.totalPages
Type                           : Integer
Description                    : Total number of pages available.

Field                          : pagination.hasNextPage
Type                           : Boolean
Description                    : True if a subsequent page exists.

Field                          : pagination.hasPreviousPage
Type                           : Boolean
Description                    : True if a prior page exists.

AuditEventNotification Object Fields:

Field                          : auditEventId
Type                           : String
Description                    : Unique identifier of the audit event record.
DB Column                      : audit_events.event_id

Field                          : eventType
Type                           : String (enumerated)
Description                    : Type of notification event. One of:
                                 CHAUFFEUR_ASSIGNMENT_NOTIFICATION,
                                 LIVE_TRIP_STATUS_NOTIFICATION,
                                 REVISED_APPOINTMENT_NOTIFICATION.
DB Column                      : audit_events.event_type

Field                          : notificationChannel
Type                           : String (enumerated)
Description                    : Channel through which the notification was
                                 dispatched. One of: ICP, WHATSAPP, SMS,
                                 DBP, CRM.
DB Column                      : audit_events.notification_channel

Field                          : recipientRole
Type                           : String (enumerated)
Description                    : Role of the notification recipient. One of:
                                 CUSTOMER, PICKUP_COORDINATOR, CHAUFFEUR.
DB Column                      : audit_events.recipient_role

Field                          : recipientId
Type                           : String
Description                    : Identifier of the specific recipient.
DB Column                      : audit_events.recipient_id

Field                          : dispatchTimestamp
Type                           : String (ISO 8601 UTC date-time)
Description                    : Timestamp at which the notification was
                                 dispatched.
DB Column                      : audit_events.dispatched_at

Field                          : deliveryStatus
Type                           : String (enumerated)
Description                    : Delivery outcome of the notification. One of:
                                 SENT, DELIVERED, FAILED, PENDING.
DB Column                      : audit_events.delivery_status

Field                          : originatingActivityId
Type                           : String
Description                    : Reference to the business activity that
                                 triggered the notification (e.g.
                                 SER-010-020-019, SER-010-020-026,
                                 SER-010-020-037).
DB Column                      : audit_events.activity_id

Field                          : appointmentId
Type                           : String
Description                    : Identifier of the appointment to which this
                                 notification relates.
DB Column                      : audit_events.appointment_id

Field                          : notificationPayload
Type                           : Object (conditional; structure varies by
                                 eventType — see sub-fields below)
Description                    : The payload content of the notification as
                                 recorded at dispatch time. Structure depends
                                 on eventType.

notificationPayload sub-fields for CHAUFFEUR_ASSIGNMENT_NOTIFICATION
(Business Rule BR-4, Activity SER-010-020-019):

Field                          : notificationPayload.chauffeurName
Type                           : String
Description                    : Full name of the assigned chauffeur.
DB Column                      : audit_event_payloads.chauffeur_name

Field                          : notificationPayload.chauffeurContactNumberMasked
Type                           : String
Description                    : Chauffeur contact number with masking applied
                                 (only last 4 digits visible, remainder
                                 replaced with asterisks, e.g. ******1234).
                                 Full unmasked number is never returned.
DB Column                      : audit_event_payloads.chauffeur_contact_masked

Field                          : notificationPayload.chauffeurPhotoReference
Type                           : String
Description                    : Reference identifier or URL for the
                                 chauffeur's photo asset.
DB Column                      : audit_event_payloads.chauffeur_photo_ref

notificationPayload sub-fields for LIVE_TRIP_STATUS_NOTIFICATION
(Business Rule BR-5, Activity SER-010-020-026):

Field                          : notificationPayload.tripStatus
Type                           : String
Description                    : Live status of the trip at the time of
                                 notification dispatch.
DB Column                      : audit_event_payloads.trip_status

Field                          : notificationPayload.eta
Type                           : String (ISO 8

ENDPOINT: GET /api/v1/otp-verifications/{appointmentRef}/latest

Source Requirement IDs: SER-010-020-036, SER-010-020-048
Source Activity IDs: SER-010-020-036, SER-010-020-048

--------------------------------------------------------------------------------
1. ENDPOINT OVERVIEW
--------------------------------------------------------------------------------

Path            : /api/v1/otp-verifications/{appointmentRef}/latest
HTTP Method     : GET
Summary         : Retrieve the latest OTP verification record for an appointment
                  reference, including status, action type, expiry, and
                  verification timestamp.
Description     : Returns the single most-recent OTP verification record
                  associated with the given appointmentRef. The record includes
                  the current OTP status (PENDING, VERIFIED, or EXPIRED), the
                  masked OTP value, revised slot date and time if the appointment
                  was rescheduled during the booking sub-flow, and all relevant
                  timestamps. This endpoint is a pure read operation; it does not
                  mutate any OTP or appointment state. It is used primarily by
                  Pickup Coordinators during the appointment booking workflow
                  stage SER-010-020 to monitor OTP state and determine whether
                  a new OTP generation flow must be triggered.

--------------------------------------------------------------------------------
2. REQUEST SPECIFICATION
--------------------------------------------------------------------------------

2a. Request Headers

Header Name       Required   Description
Authorization     Yes        Bearer JWT token issued by the OAuth2/OIDC provider.
                             Format: "Bearer <token>"
                             The token must be valid, unexpired, and signed by
                             the trusted issuer. It must carry the required role
                             claim and the scope "otp-verification:read".
Content-Type      No         Not required for GET requests. If supplied it is
                             ignored.
Accept            No         Recommended value: application/json. If omitted,
                             application/json is assumed.
X-Correlation-ID  No         Optional caller-supplied correlation identifier for
                             distributed tracing. If present it is propagated to
                             downstream services and echoed in the response
                             header. If absent the system generates one
                             internally.

2b. Path Parameters

Parameter Name  : appointmentRef
Location        : Path
Type            : String
Required        : Yes
Description     : The unique reference identifier of the appointment for which
                  the latest OTP verification record is to be retrieved.
Validation Rules:
  - Must be non-null and non-empty.
  - Must not consist solely of whitespace characters.
  - Must conform to the system appointment reference format:
    alphanumeric characters, hyphens, and underscores only.
    Suggested regex: ^[A-Za-z0-9_-]{1,100}$
  - Maximum length: 100 characters.
  - Minimum length: 1 character.
  - If the value is blank, null, or does not match the expected format,
    the request is rejected immediately with HTTP 400 before any data
    access occurs (see BR-6).

2c. Query Parameters

None. This endpoint does not accept query parameters.

2d. Request Body

None. This is a GET operation; no request body is accepted or processed.

--------------------------------------------------------------------------------
3. RESPONSE SPECIFICATION
--------------------------------------------------------------------------------

3a. HTTP 200 - Success

Description: The latest OTP verification record for the given appointmentRef
             was found and is returned successfully.

Response Body Schema (all fields are at the top level of a JSON object):

Field Name          Type      Required   Description
otpVerificationId   String    Yes        Unique identifier of the OTP
                                         verification record.
                                         Source: otp_verifications.id
appointmentRef      String    Yes        The appointment reference as supplied
                                         in the path parameter.
                                         Source: otp_verifications.appointment_ref
status              String    Yes        Current status of the OTP verification.
                                         Allowed values: PENDING, VERIFIED,
                                         EXPIRED.
                                         Source: otp_verifications.otp_status
otp                 String    Yes        The OTP value, masked for security.
                                         Only a partial representation is
                                         returned (e.g., last 2 digits visible,
                                         remainder replaced with asterisks).
                                         Source: otp_verifications.otp_value
                                         (masked at application layer before
                                         serialisation)
revisedSlotDate     String    No         Revised appointment slot date if the
                                         appointment was rescheduled during the
                                         booking sub-flow (activity
                                         SER-010-020-036). Format: YYYY-MM-DD.
                                         Null if no revision was made.
                                         Source: otp_verifications.revised_slot_date
revisedSlotTime     String    No         Revised appointment slot time if the
                                         appointment was rescheduled. Format:
                                         HH:mm:ss (24-hour UTC).
                                         Null if no revision was made.
                                         Source: otp_verifications.revised_slot_time
createdAt           String    Yes        UTC timestamp when the OTP record was
                                         created. Format: ISO 8601
                                         (YYYY-MM-DDTHH:mm:ssZ).
                                         Source: otp_verifications.created_at
expiresAt           String    Yes        UTC timestamp when the OTP record
                                         expires or expired. Format: ISO 8601.
                                         Source: otp_verifications.expires_at
verifiedAt          String    No         UTC timestamp when the OTP was
                                         successfully verified. Null if not yet
                                         verified.
                                         Format: ISO 8601.
                                         Source: otp_verifications.verified_at

Example 200 Response Payload:

  otpVerificationId : "otp-7f3a1c29-4e8b-4d12-a3f1-0c9e2b5d6f78"
  appointmentRef    : "APT-2024-00123"
  status            : "VERIFIED"
  otp               : "****56"
  revisedSlotDate   : "2024-08-15"
  revisedSlotTime   : "10:30:00"
  createdAt         : "2024-08-14T09:00:00Z"
  expiresAt         : "2024-08-14T09:10:00Z"
  verifiedAt        : "2024-08-14T09:04:32Z"

Example 200 Response Payload (EXPIRED, no revised slot):

  otpVerificationId : "otp-2a9c4d11-7b3e-4f01-b8c2-1d0e3a7f9c45"
  appointmentRef    : "APT-2024-00456"
  status            : "EXPIRED"
  otp               : "****89"
  revisedSlotDate   : null
  revisedSlotTime   : null
  createdAt         : "2024-08-14T11:00:00Z"
  expiresAt         : "2024-08-14T11:10:00Z"
  verifiedAt        : null

--------------------------------------------------------------------------------

3b. HTTP 400 - Bad Request

Description: The appointmentRef path parameter is missing, blank, or does not
             conform to the expected format (BR-6).

Response Body Schema:

Field Name  Type    Description
errorCode   String  Machine-readable error code.
message     String  Human-readable description of the validation failure.
field       String  The name of the parameter that failed validation.
timestamp   String  UTC timestamp of the error. ISO 8601 format.

Example 400 Response Payload:

  errorCode : "INVALID_APPOINTMENT_REF"
  message   : "Invalid or malformed appointmentRef provided."
  field     : "appointmentRef"
  timestamp : "2024-08-14T09:05:00Z"

--------------------------------------------------------------------------------

3c. HTTP 401 - Unauthorized

Description: The Bearer JWT token is absent, expired, malformed, or has an
             invalid signature. Authentication could not be established.

Response Body Schema:

Field Name  Type    Description
errorCode   String  Machine-readable error code.
message     String  Human-readable description.
timestamp   String  UTC timestamp of the error. ISO 8601 format.

Example 401 Response Payload:

  errorCode : "UNAUTHORIZED"
  message   : "Authentication failed. A valid Bearer token is required."
  timestamp : "2024-08-14T09:05:01Z"

--------------------------------------------------------------------------------

3d. HTTP 403 - Forbidden

Description: The authenticated principal does not hold a permitted role or does
             not have ownership/scope access to OTP data for the specified
             appointment (BR-8).

Response Body Schema:

Field Name  Type    Description
errorCode   String  Machine-readable error code.
message     String  Human-readable description.
timestamp   String  UTC timestamp of the error. ISO 8601 format.

Example 403 Response Payload:

  errorCode : "ACCESS_DENIED"
  message   : "Access denied. You are not authorized to view OTP verification
               data for this appointment."
  timestamp : "2024-08-14T09:05:02Z"

--------------------------------------------------------------------------------

3e. HTTP 404 - Not Found

Description: Either no appointment exists for the given appointmentRef (BR-1),
             or the appointment exists but no OTP verification record has been
             generated for it (BR-2).

Response Body Schema:

Field Name  Type    Description
errorCode   String  Machine-readable error code.
message     String  Human-readable description.
timestamp   String  UTC timestamp of the error. ISO 8601 format.

Example 404 Response Payload (appointment not found):

  errorCode : "APPOINTMENT_NOT_FOUND"
  message   : "Appointment not found for the provided appointmentRef."
  timestamp : "2024-08-14T09:05:03Z"

Example 404 Response Payload (no OTP record found):

  errorCode : "OTP_RECORD_NOT_FOUND"
  message   : "No OTP verification record found for the provided appointmentRef."
  timestamp : "2024-08-14T09:05:04Z"

--------------------------------------------------------------------------------

3f. HTTP 500 - Internal Server Error

Description: An unexpected error occurred in the application layer or a
             downstream dependency (appointment repository or OTP verification
             store) returned an error or was unreachable (BR-9).

Response Body Schema:

Field Name  Type    Description
errorCode   String  Machine-readable error code.
message     String  Human-readable description.
timestamp   String  UTC timestamp of the error. ISO 8601 format.

Example 500 Response Payload:

  errorCode : "INTERNAL_SERVER_ERROR"
  message   : "An internal error occurred while retrieving the OTP verification
               record. Please try again later."
  timestamp : "2024-08-14T09:05:05Z"

--------------------------------------------------------------------------------

3g. HTTP 503 - Service Unavailable

Description: The circuit breaker for the appointment repository has opened
             following a configurable threshold of consecutive failures.
             Subsequent requests receive an immediate

ENDPOINT: GET /api/v1/dbp/integration/health

--------------------------------------------------------------------------------
SECTION 1 - ENDPOINT OVERVIEW
--------------------------------------------------------------------------------

Path            : /api/v1/dbp/integration/health
HTTP Method     : GET
Summary         : Health check endpoint confirming DBP connectivity and circuit-breaker state
Description     : Returns the current operational health of the DBP integration layer,
                  including the circuit-breaker state (CLOSED, OPEN, or HALF_OPEN), a live
                  or cached DBP reachability flag, last probe latency, consecutive failure
                  count, relevant timestamps, pending operation queue depths, and a derived
                  overall status indicator. This endpoint is consumed by the operations
                  monitoring stack, the Pickup Coordinator dashboard, and Kubernetes readiness
                  probes to determine whether DBP-dependent workflows (drop request publishing,
                  JC opening, Smart Eye image forwarding) are currently serviceable.
                  This is a read-only, fully idempotent, side-effect-free operation.

--------------------------------------------------------------------------------
SECTION 2 - REQUEST SPECIFICATION
--------------------------------------------------------------------------------

2.1 Request Headers

Header Name     : Authorization
Required        : Yes (for external callers); No (for internal cluster liveness probes)
Format          : Bearer <JWT token>
Description     : OAuth2 / OIDC Bearer JWT. External callers must supply a valid,
                  non-expired token. Internal cluster probes (originating from within the
                  cluster network boundary) may omit this header.

Header Name     : Accept
Required        : No
Allowed Values  : application/json
Default         : application/json

Header Name     : X-Request-ID
Required        : No
Format          : UUID v4 string
Description     : Optional correlation identifier for distributed tracing. If supplied,
                  it is echoed back in the response header of the same name.

2.2 Path Parameters

None.

2.3 Query Parameters

None.

2.4 Request Body

None. This is a GET endpoint and carries no request body.

--------------------------------------------------------------------------------
SECTION 3 - RESPONSE SPECIFICATION
--------------------------------------------------------------------------------

3.1 HTTP 200 - Successful Health Response (circuit breaker CLOSED or HALF_OPEN)

Description : The DBP integration layer is either fully operational (CLOSED) or in a
              single-probe recovery attempt (HALF_OPEN). The overall status will be
              UP or DEGRADED respectively.

Response Body Schema:

Field                                    Type        Required   Description
overall                                  string      Yes        Derived health indicator.
                                                                Allowed values: UP, DEGRADED, DOWN.
                                                                UP = CLOSED and DBP reachable.
                                                                DEGRADED = HALF_OPEN.
                                                                DOWN = OPEN.
checkedAt                                string      Yes        ISO-8601 UTC timestamp at which
                                                                the health response was generated
                                                                by the server. Format: date-time.
circuitBreakerState                      string      Yes        Current circuit-breaker state.
                                                                Allowed values: CLOSED, OPEN,
                                                                HALF_OPEN.
dbpReachable                             boolean     Yes        True if the most recent probe to
                                                                the DBP REST API succeeded; false
                                                                otherwise. When circuit breaker is
                                                                OPEN, no live probe is attempted
                                                                and this reflects the last known
                                                                state (false).
lastProbeLatencyMs                       integer     Yes        Round-trip latency in milliseconds
                                                                of the most recent DBP connectivity
                                                                probe. Null when circuit breaker is
                                                                OPEN and no probe was attempted.
                                                                Minimum: 0.
consecutiveFailureCount                  integer     Yes        Number of consecutive DBP probe
                                                                failures recorded in the current
                                                                measurement window. Minimum: 0.
lastSuccessfulProbeAt                    string      Yes        ISO-8601 UTC timestamp of the last
                                                                successful DBP probe. Null if no
                                                                successful probe has been recorded.
lastFailureAt                            string      No         ISO-8601 UTC timestamp of the last
                                                                DBP probe failure. Absent or null
                                                                when no failure has been recorded
                                                                in the current measurement window
                                                                (BR-7).
resetWindowExpiresAt                     string      No         ISO-8601 UTC timestamp indicating
                                                                when the HALF_OPEN probe will be
                                                                attempted. Present only when
                                                                circuitBreakerState is OPEN (BR-6).
                                                                Absent or null otherwise.
pendingOperations                        object      Yes        Counts of DBP-bound operations
                                                                currently queued due to circuit-
                                                                breaker OPEN state.
pendingOperations.dropRequestsPending    integer     Yes        Count of drop requests queued for
                                                                retry. Minimum: 0.
pendingOperations.conditionReportsPending integer    Yes        Count of condition reports queued
                                                                for retry. Minimum: 0.
pendingOperations.smartEyeImagesPending  integer     Yes        Count of Smart Eye images queued
                                                                for retry. Minimum: 0.

Example Payload (overall = UP, circuitBreakerState = CLOSED):

overall                          : UP
checkedAt                        : 2025-07-14T10:32:00.000Z
circuitBreakerState              : CLOSED
dbpReachable                     : true
lastProbeLatencyMs               : 47
consecutiveFailureCount          : 0
lastSuccessfulProbeAt            : 2025-07-14T10:32:00.000Z
lastFailureAt                    : null
resetWindowExpiresAt             : null
pendingOperations
  dropRequestsPending            : 0
  conditionReportsPending        : 0
  smartEyeImagesPending          : 0

Example Payload (overall = DEGRADED, circuitBreakerState = HALF_OPEN):

overall                          : DEGRADED
checkedAt                        : 2025-07-14T10:45:00.000Z
circuitBreakerState              : HALF_OPEN
dbpReachable                     : false
lastProbeLatencyMs               : null
consecutiveFailureCount          : 3
lastSuccessfulProbeAt            : 2025-07-14T09:58:00.000Z
lastFailureAt                    : 2025-07-14T10:40:00.000Z
resetWindowExpiresAt             : null
pendingOperations
  dropRequestsPending            : 4
  conditionReportsPending        : 2
  smartEyeImagesPending          : 1

3.2 HTTP 503 - Service Unavailable (circuit breaker OPEN / DBP unreachable)

Description : The circuit breaker is in OPEN state. DBP is unreachable. No live probe
              is attempted. The response body carries full circuit-breaker detail and
              pending operation counts so that monitoring systems can distinguish a DBP
              connectivity failure from an internal service error.

Response Body Schema: Same schema as HTTP 200 above.

Example Payload:

overall                          : DOWN
checkedAt                        : 2025-07-14T11:00:00.000Z
circuitBreakerState              : OPEN
dbpReachable                     : false
lastProbeLatencyMs               : null
consecutiveFailureCount          : 3
lastSuccessfulProbeAt            : 2025-07-14T10:55:00.000Z
lastFailureAt                    : 2025-07-14T10:59:45.000Z
resetWindowExpiresAt             : 2025-07-14T11:04:45.000Z
pendingOperations
  dropRequestsPending            : 7
  conditionReportsPending        : 3
  smartEyeImagesPending          : 5

3.3 HTTP 401 - Unauthorized

Description : The request originated from outside the cluster network boundary and did
              not carry a valid Bearer JWT, or the token has expired.

Response Body Schema:

Field       Type    Required   Description
status      integer Yes        HTTP status code. Value: 401.
error       string  Yes        Short error label. Value: Unauthorized.
message     string  Yes        Human-readable description of the error.
timestamp   string  Yes        ISO-8601 UTC timestamp of the error.
path        string  Yes        Request path that produced the error.

Example Payload:

status    : 401
error     : Unauthorized
message   : The request does not carry a valid Bearer JWT or the token has expired.
timestamp : 2025-07-14T11:01:00.000Z
path      : /api/v1/dbp/integration/health

3.4 HTTP 403 - Forbidden

Description : The caller presented a valid JWT but does not hold a role that is
              authorised to invoke this endpoint (pickup_coordinator or system).

Response Body Schema:

Field       Type    Required   Description
status      integer Yes        HTTP status code. Value: 403.
error       string  Yes        Short error label. Value: Forbidden.
message     string  Yes        Human-readable description of the error.
timestamp   string  Yes        ISO-8601 UTC timestamp of the error.
path        string  Yes        Request path that produced the error.

Example Payload:

status    : 403
error     : Forbidden
message   : The authenticated principal does not hold a role authorised to access
            this endpoint.
timestamp : 2025-07-14T11:01:05.000Z
path      : /api/v1/dbp/integration/health

3.5 HTTP 500 - Internal Server Error

Description : An unhandled exception occurred within the DBP integration service layer
              itself, not caused by DBP being unreachable. This is distinct from a DBP
              connectivity failure, which returns 503.

Response Body Schema:

Field       Type    Required   Description
status      integer Yes        HTTP status code. Value: 500.
error       string  Yes        Short error label. Value: Internal Server Error.

ENDPOINT: GET /api/v1/trips/{tripId}/suggested-start-time

Source Requirement IDs: SER-010-020-130


------------------------------------------------------------------------
SECTION 1: ENDPOINT OVERVIEW
------------------------------------------------------------------------

Path            : /api/v1/trips/{tripId}/suggested-start-time
HTTP Method     : GET
Summary         : Return the Map API-derived suggested start time for the
                  chauffeur for a pickup or drop activity.
Description     : This endpoint computes and returns a real-time,
                  Map API-derived suggested start time for a chauffeur
                  assigned to a pickup or drop trip activity. For pickup
                  trips, only the suggested pickup start time and a revised
                  ETA are returned. For drop trips, a suggested vehicle
                  departure time is additionally computed and returned
                  alongside the drop activity start time and revised ETA.
                  This is a read-only, point-in-time computation. No trip
                  state is mutated. Each invocation triggers a live Map API
                  call; results may differ between calls if traffic
                  conditions have changed.


------------------------------------------------------------------------
SECTION 2: REQUEST SPECIFICATION
------------------------------------------------------------------------

2.1 Request Headers

Header Name       : Authorization
Required          : Yes
Format            : Bearer <JWT token>
Description       : OAuth2 / OIDC Bearer JWT. Must be a valid, non-expired
                    token issued by the authorised identity provider. The
                    token must carry role claims and, for CHAUFFEUR callers,
                    a subject claim that maps to the assigned chauffeur of
                    the specified trip.

Header Name       : Accept
Required          : No (defaults to application/json)
Format            : application/json
Description       : Indicates the expected response media type.

Header Name       : X-Correlation-ID
Required          : No
Format            : UUID v4 string
Description       : Optional caller-supplied correlation identifier for
                    distributed tracing. If provided, it is echoed back in
                    the response header and recorded in the audit trail.


2.2 Path Parameters

Parameter Name    : tripId
Location          : Path
Required          : Yes
Type              : String
Format            : Non-empty string; must conform to the system's internal
                    trip identifier format (alphanumeric, hyphens permitted,
                    maximum 64 characters).
Validation Rules  :
  - Must not be null or empty.
  - Must not exceed 64 characters.
  - Must match pattern: ^[a-zA-Z0-9\-]{1,64}$
  - Must correspond to an existing trip record in the Trip Data Store.
Description       : The unique identifier of the trip for which the
                    suggested start time is being requested.


2.3 Query Parameters

None. This endpoint does not accept query parameters.


2.4 Request Body

None. This is a GET operation; no request body is accepted or processed.


------------------------------------------------------------------------
SECTION 3: RESPONSE SPECIFICATION
------------------------------------------------------------------------

3.1 HTTP 200 - Success

Description       : The suggested start time (and, for drop trips, the
                    suggested vehicle departure time) has been successfully
                    computed using live Map API data and is returned to the
                    caller.

Response Headers  :
  Content-Type      : application/json
  X-Correlation-ID  : Echoed from request if supplied; otherwise
                      system-generated UUID.

Response Body Schema:

  Field                    : tripId
  Type                     : String
  Required in Response     : Yes
  Description              : The trip identifier echoed from the request
                             path parameter.
  Example                  : "TRIP-20240601-00123"

  Field                    : tripType
  Type                     : String (enum)
  Required in Response     : Yes
  Allowed Values           : "pickup", "drop"
  Description              : Indicates whether this is a pickup or drop
                             trip, which governs which computed fields are
                             populated.
  Example                  : "drop"

  Field                    : suggestedStartTime
  Type                     : String (ISO 8601 datetime with timezone offset)
  Required in Response     : Yes
  Format                   : YYYY-MM-DDTHH:mm:ssZ
  Description              : The system-calculated suggested start time for
                             the chauffeur. For pickup trips this is the
                             suggested pickup start time. For drop trips
                             this is the suggested drop activity start time.
                             This field is read-only and cannot be overridden
                             by any caller.
  Example                  : "2024-06-01T07:45:00+05:30"

  Field                    : suggestedDepartureTime
  Type                     : String (ISO 8601 datetime with timezone offset)
                             or null
  Required in Response     : Populated for drop trips only; null or absent
                             for pickup trips.
  Format                   : YYYY-MM-DDTHH:mm:ssZ
  Description              : For drop trips only: the system-calculated
                             suggested time at which the vehicle should
                             depart in order to reach the drop location by
                             the required activity start time, accounting
                             for real-time traffic. Null or absent for
                             pickup trips.
  Example (drop trip)      : "2024-06-01T07:15:00+05:30"
  Example (pickup trip)    : null

  Field                    : revisedEta
  Type                     : String (ISO 8601 datetime with timezone offset)
  Required in Response     : Yes
  Format                   : YYYY-MM-DDTHH:mm:ssZ
  Description              : The system-calculated revised estimated time of
                             arrival, derived from live Map API route and
                             traffic data. This is a read-only value and
                             cannot be edited by any caller.
  Example                  : "2024-06-01T08:10:00+05:30"

  Field                    : computedAt
  Type                     : String (ISO 8601 datetime with timezone offset)
  Required in Response     : Yes
  Format                   : YYYY-MM-DDTHH:mm:ssZ
  Description              : The server-side timestamp at which this
                             computation was performed. Callers should treat
                             the response as valid only at this point in
                             time; repeated calls may yield different values
                             as traffic conditions evolve.
  Example                  : "2024-06-01T07:30:00+05:30"

Example 200 Response Payload (drop trip):

  tripId                   : "TRIP-20240601-00123"
  tripType                 : "drop"
  suggestedStartTime       : "2024-06-01T07:45:00+05:30"
  suggestedDepartureTime   : "2024-06-01T07:15:00+05:30"
  revisedEta               : "2024-06-01T08:10:00+05:30"
  computedAt               : "2024-06-01T07:30:00+05:30"

Example 200 Response Payload (pickup trip):

  tripId                   : "TRIP-20240601-00456"
  tripType                 : "pickup"
  suggestedStartTime       : "2024-06-01T08:00:00+05:30"
  suggestedDepartureTime   : null
  revisedEta               : "2024-06-01T08:35:00+05:30"
  computedAt               : "2024-06-01T07:30:00+05:30"


3.2 HTTP 400 - Bad Request

Description       : The request is malformed. The tripId path parameter
                    fails format validation.

Response Body Schema:

  Field                    : errorCode
  Type                     : String
  Example                  : "INVALID_REQUEST"

  Field                    : message
  Type                     : String
  Example                  : "The tripId path parameter is invalid or
                             malformed."

  Field                    : details
  Type                     : Array of Strings
  Example                  : ["tripId must match pattern ^[a-zA-Z0-9\\-]{1,64}$"]

  Field                    : timestamp
  Type                     : String (ISO 8601)
  Example                  : "2024-06-01T07:30:00+05:30"


3.3 HTTP 401 - Unauthorized

Description       : The request does not carry a valid Bearer JWT, the
                    token is expired, or the token signature cannot be
                    verified.

Response Body Schema:

  Field                    : errorCode
  Type                     : String
  Example                  : "UNAUTHORIZED"

  Field                    : message
  Type                     : String
  Example                  : "Authentication failed: missing or invalid
                             Bearer token."

  Field                    : timestamp
  Type                     : String (ISO 8601)
  Example                  : "2024-06-01T07:30:00+05:30"


3.4 HTTP 403 - Forbidden

Description       : The caller is authenticated but does not hold a
                    permitted role, or the caller holds the CHAUFFEUR role
                    but is not the chauffeur assigned to the specified trip.

Response Body Schema:

  Field                    : errorCode
  Type                     : String
  Example                  : "FORBIDDEN"

  Field                    : message
  Type                     : String
  Example                  : "Access denied: you are not authorised to
                             retrieve the suggested start time for this
                             trip."

  Field                    : timestamp
  Type                     : String (ISO 8601)
  Example                  : "2024-06-01T07:30:00+05:30"


3.5 HTTP 404 - Not Found

Description       : No trip record exists in the system for the supplied
                    tripId.

Response Body Schema:

  Field                    : errorCode
  Type                     : String
  Example                  : "TRIP_NOT_FOUND"

  Field                    : message
  Type                     : String
  Example                  : "Trip not found for the provided tripId."

  Field                    : tripId
  Type                     : String
  Example                  : "TRIP-20240601-99999"

ENDPOINT: POST /api/v1/drop-trips/{tripId}/pre-departure-images

Source Requirement: SER-010-020-112
Source Activity: SER-010-020-112


------------------------------------------------------------------------
SECTION 1: ENDPOINT OVERVIEW
------------------------------------------------------------------------

Path            : /api/v1/drop-trips/{tripId}/pre-departure-images
HTTP Method     : POST
Summary         : Upload pre-departure exterior and interior vehicle images for a drop trip.
Description     : Allows the chauffeur assigned to a specific drop trip to upload mandatory
                  pre-departure vehicle condition images (both exterior and interior) before
                  the trip commences. Submitted image files are forwarded to the downstream
                  Image Storage Service, and resulting media references are persisted to the
                  Vehicle Condition Capture Store linked immutably to the drop trip record.
                  Successful completion unblocks the trip workflow and allows progression to
                  the next stage (SER-010-020-113). An audit trail entry is appended
                  asynchronously upon success.


------------------------------------------------------------------------
SECTION 2: REQUEST SPECIFICATION
------------------------------------------------------------------------

2.1 Request Headers

Header Name       : Authorization
Required          : Yes
Format            : Bearer <JWT token>
Description       : OAuth2 / OIDC Bearer JWT. Must be valid, unexpired, and carry the
                    scope drop-trip:image:write. Used to authenticate the caller and
                    extract the chauffeur identity claim (sub).

Header Name       : Content-Type
Required          : Yes
Accepted Value    : multipart/form-data
Description       : The request body must be submitted as a multipart form upload to
                    carry binary image files alongside their metadata tags.

Header Name       : Accept
Required          : No (recommended)
Accepted Value    : application/json
Description       : Indicates the client expects a JSON response body.


2.2 Path Parameters

Parameter Name    : tripId
Location          : Path
Type              : String (UUID format)
Required          : Yes
Format            : UUID v4 (e.g. 550e8400-e29b-41d4-a716-446655440000)
Description       : Unique identifier of the drop trip for which pre-departure images
                    are being uploaded. Must correspond to an existing drop trip record
                    in the system.
Validation Rules  :
  - Must be a non-null, non-empty string.
  - Must conform to UUID v4 format.
  - Must resolve to an existing drop trip record (enforced at business rule level BR-1).


2.3 Query Parameters

None applicable for this endpoint.


2.4 Request Body Schema (multipart/form-data)

The request body is a multipart/form-data payload. Each image is submitted as a
separate file part accompanied by a corresponding image type tag part. The payload
must contain at least one EXTERIOR image and at least one INTERIOR image.

Part Name         : images
Part Type         : File (binary)
Required          : Yes
Multiplicity      : One or more file parts; both EXTERIOR and INTERIOR types must be
                    represented in the submission.
Accepted MIME     : image/jpeg, image/png
Max File Size     : Refer to system-level configuration (e.g. 10 MB per file; exact
                    threshold defined in COMMON_FILE_LIMITS).
Description       : Binary image file representing a vehicle condition photograph taken
                    prior to departure.
Validation Rules  :
  - MIME type must be image/jpeg or image/png (BR-5).
  - File size must not exceed the configured maximum (BR-5).
  - File must not be empty or zero-byte.

Part Name         : imageType
Part Type         : String (enum)
Required          : Yes (one per image file submitted)
Allowed Values    : EXTERIOR, INTERIOR
Description       : Classification tag identifying whether the associated image depicts
                    the exterior or interior of the vehicle. Must be provided for each
                    image file in the submission.
Validation Rules  :
  - Must be present for every image file part submitted (BR-6).
  - Value must be exactly EXTERIOR or INTERIOR (case-sensitive); any other value is
    rejected (BR-6).
  - The set of submitted imageType values across all parts must include at least one
    EXTERIOR and at least one INTERIOR entry (BR-3).


------------------------------------------------------------------------
SECTION 3: RESPONSE SPECIFICATION
------------------------------------------------------------------------

3.1 HTTP 201 Created — Success

Description : All submitted images have been validated, persisted to the Image Storage
              Service, and their metadata records written to the Vehicle Condition
              Capture Store. The drop trip's capture status has been updated. An audit
              trail entry has been queued asynchronously.

Response Body Schema:

  Field                  : status
  Type                   : String
  Description            : Outcome indicator. Value is always "SUCCESS" on 201.

  Field                  : message
  Type                   : String
  Description            : Human-readable confirmation message.

  Field                  : tripId
  Type                   : String (UUID)
  Description            : Echo of the tripId from the path parameter.

  Field                  : uploadedImageCount
  Type                   : Integer
  Description            : Total number of image records successfully persisted in this
                           submission.

  Field                  : images
  Type                   : Array of objects
  Description            : List of persisted image records, one entry per uploaded file.

    Sub-field            : imageId
    Type                 : String (UUID)
    Description          : System-generated unique identifier for the persisted image record.

    Sub-field            : imageType
    Type                 : String (enum: EXTERIOR / INTERIOR)
    Description          : Classification of the image as submitted.

    Sub-field            : imageUrl
    Type                 : String (URL)
    Description          : Reference URL or storage path returned by the Image Storage
                           Service for the persisted image.

    Sub-field            : uploadedAt
    Type                 : String (ISO 8601 datetime, UTC)
    Description          : System timestamp at which the image was persisted.

  Field                  : captureStatus
  Type                   : String
  Description            : Updated vehicle condition capture status of the drop trip
                           following successful image upload (e.g. PRE_DEPARTURE_IMAGES_RECORDED).

  Field                  : nextStage
  Type                   : String
  Description            : Identifier of the next workflow stage now unblocked
                           (e.g. SER-010-020-113).

Example 201 Response Payload:

  status              : SUCCESS
  message             : Pre-departure images have been successfully recorded for the trip.
  tripId              : 550e8400-e29b-41d4-a716-446655440000
  uploadedImageCount  : 3
  images              :
    [0]
      imageId         : a1b2c3d4-0001-41d4-a716-000000000001
      imageType       : EXTERIOR
      imageUrl        : https://storage.example.com/trips/550e8400/pre-departure/ext-001.jpg
      uploadedAt      : 2025-07-15T08:30:00Z
    [1]
      imageId         : a1b2c3d4-0002-41d4-a716-000000000002
      imageType       : EXTERIOR
      imageUrl        : https://storage.example.com/trips/550e8400/pre-departure/ext-002.jpg
      uploadedAt      : 2025-07-15T08:30:01Z
    [2]
      imageId         : a1b2c3d4-0003-41d4-a716-000000000003
      imageType       : INTERIOR
      imageUrl        : https://storage.example.com/trips/550e8400/pre-departure/int-001.jpg
      uploadedAt      : 2025-07-15T08:30:02Z
  captureStatus       : PRE_DEPARTURE_IMAGES_RECORDED
  nextStage           : SER-010-020-113


3.2 HTTP 400 Bad Request — Validation Failure

Description : One or more submitted image files or image type tags failed validation.
              Covers invalid MIME type, file size exceeded, missing or invalid imageType
              tag, or malformed request structure.

Response Body Schema:

  Field                  : status
  Type                   : String
  Value                  : ERROR

  Field                  : errorCode
  Type                   : String
  Description            : Machine-readable error code.

  Field                  : message
  Type                   : String
  Description            : Human-readable description of the validation failure.

  Field                  : violations
  Type                   : Array of objects
  Description            : List of individual field-level or file-level violations.

    Sub-field            : field
    Type                 : String
    Description          : Name of the part or field that failed validation.

    Sub-field            : reason
    Type                 : String
    Description          : Specific reason for the validation failure.

Example 400 Response Payload (invalid MIME type — BR-5):

  status      : ERROR
  errorCode   : INVALID_IMAGE_FORMAT
  message     : One or more image files are invalid. Accepted formats are JPEG and PNG;
                maximum file size must not be exceeded.
  violations  :
    [0]
      field   : images[2]
      reason  : Unsupported MIME type image/gif. Accepted types are image/jpeg and image/png.

Example 400 Response Payload (missing imageType tag — BR-6):

  status      : ERROR
  errorCode   : MISSING_IMAGE_TYPE
  message     : Each image must be tagged with a valid type: EXTERIOR or INTERIOR.
  violations  :
    [0]
      field   : imageType[1]
      reason  : imageType tag is missing for the submitted image at index 1.


3.3 HTTP 401 Unauthorized — Authentication Failure

Description : The Bearer JWT is absent, malformed, expired, or its signature cannot
              be verified.

Example 401 Response Payload:

  status      : ERROR
  errorCode   : UNAUTHORIZED
  message     : Authentication failed. A valid Bearer token is required to access this
                resource.


3.4 HTTP 403 Forbidden — Authorization Failure

Description : The authenticated chauffeur is not the chauffeur assigned to the drop
              trip identified by tripId. Ownership-based access control check failed
              (BR-4).

Example 403 Response Payload:

  status      : ERROR
  errorCode   : FORBIDDEN_NOT_ASSIGNED_CHAUFFEUR
  message     : You are not authorized to upload images for this trip. Only the assigned
                chauffeur may perform this action.


3.5 HTTP 404 Not Found — Trip Not Found

Description : No drop trip record exists for the provided tripId (BR-1).

Example 404 Response Payload:

  status      : ERROR
  errorCode   : TRIP_NOT_FOUND
  message     : Drop trip not found for the provided tripId.
  tripId      : 550e8400-e29b-41d4-a716-446655440000


3.6 HTTP 409 Conflict — Invalid Trip State

Description : The drop trip exists but is not in a valid pre-departure state. The trip
              may already be IN_PROGRESS, COMPLETED, CANCELLED, or pre-departure images
              may have already been finalised/locked for this trip (BR-2, BR-9).

Example 409 Response Payload:

  status         : ERROR
  errorCode      : INVALID_TRIP_STATE
  message        : Pre-departure images can only be uploaded when the trip is in a
                   pre-departure state.
  tripId         : 550e8400-e29b-41d4-a716-446655440000
  currentStatus  : COMPLETED


3

ENDPOINT: POST /api/v1/crm/assignments

Source Requirement IDs: SER-010-020-007
Source Activity IDs: SER-010-020-007

--------------------------------------------------------------------------------
SECTION 1: ENDPOINT OVERVIEW
--------------------------------------------------------------------------------

Path            : /api/v1/crm/assignments
HTTP Method     : POST
Summary         : Push chauffeur assignment request from internal system to CRM and onward to Chauffeur app
Description     : Creates a new chauffeur assignment record linked to an existing appointment. The request
                  originates from the CRM system as part of the appointment booking workflow stage
                  SER-010-020. Upon successful persistence, the assignment is dispatched downstream to the
                  Chauffeur mobile application and an immutable audit trail entry is recorded. This endpoint
                  is not idempotent by default; duplicate submissions for the same appointment will be
                  rejected with a 409 Conflict unless a supported idempotency key is supplied.

--------------------------------------------------------------------------------
SECTION 2: REQUEST SPECIFICATION
--------------------------------------------------------------------------------

2.1 Request Headers

Header Name            Required    Description
Authorization          Yes         Bearer JWT token issued by the authorised OAuth2/OIDC provider.
                                   Format: "Bearer <token>"
                                   The JWT must contain a valid role claim including at least one of:
                                   PICKUP_COORDINATOR, ADMIN, INTEGRATION_SERVICE.
                                   The sub claim is used to derive the actorId for audit and assignment
                                   attribution.
Content-Type           Yes         Must be "application/json"
Accept                 No          Should be "application/json"
Idempotency-Key        No          Optional client-supplied UUID string. If provided, the system will
                                   return the original 201 response for duplicate requests bearing the
                                   same key within the deduplication window without creating a second
                                   assignment record. Format: UUID v4. Deduplication window: defined
                                   by system configuration (recommended 24 hours).
X-Correlation-ID       No          Optional caller-supplied correlation identifier for distributed
                                   tracing. If not supplied, the system generates one internally.
                                   Format: UUID v4.

2.2 Path Parameters

None.

2.3 Query Parameters

None.

2.4 Request Body Schema

Content-Type: application/json

Field Name       Type      Required    Description and Validation Rules
appointmentId    string    Yes         Unique identifier of the appointment to which the chauffeur is
                                       being assigned.
                                       Type: string
                                       Format: UUID v4
                                       Regex: ^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-4[0-9a-fA-F]{3}-[89abAB]
                                               [0-9a-fA-F]{3}-[0-9a-fA-F]{12}$
                                       Must not be null or empty.
                                       Must reference an existing appointment in an assignable state.

chauffeurId      string    Yes         Unique identifier of the chauffeur being assigned.
                                       Type: string
                                       Format: UUID v4
                                       Regex: ^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-4[0-9a-fA-F]{3}-[89abAB]
                                               [0-9a-fA-F]{3}-[0-9a-fA-F]{12}$
                                       Must not be null or empty.
                                       Must reference an active, registered chauffeur.

notes            string    No          Optional free-text notes associated with the assignment.
                                       Type: string
                                       Max length: 500 characters
                                       No special format required.
                                       Must not contain executable script content (XSS sanitisation
                                       applied server-side).

2.5 Example Request Body

{
  "appointmentId": "a3f1c2d4-1234-4abc-89ef-000000000001",
  "chauffeurId":   "b7e2d3f5-5678-4def-90ab-000000000002",
  "notes":         "Customer requires assistance with luggage."
}

--------------------------------------------------------------------------------
SECTION 3: RESPONSE SPECIFICATION
--------------------------------------------------------------------------------

3.1 HTTP 201 Created

Description: The chauffeur assignment was successfully created and persisted. The downstream
             notification to the Chauffeur mobile application has been dispatched or queued.

Response Body Schema:

Field Name              Type      Description
assignmentId            string    System-generated unique identifier for the new assignment record.
                                  Format: UUID v4.
appointmentId           string    The appointment identifier supplied in the request.
chauffeurId             string    The chauffeur identifier supplied in the request.
assignedBy              string    The actorId derived from the JWT sub claim of the requesting user.
status                  string    The status of the assignment at creation time.
                                  Value: "ACTIVE"
createdAt               string    ISO-8601 UTC timestamp of when the assignment was persisted.
                                  Format: YYYY-MM-DDTHH:MM:SS.sssZ
notificationStatus      string    Indicates the dispatch state of the downstream Chauffeur app
                                  notification.
                                  Possible values: "DISPATCHED", "QUEUED_FOR_RETRY"
correlationId           string    The correlation identifier for this request, either caller-supplied
                                  or system-generated.

Example 201 Response Body:

{
  "assignmentId":       "c9d4e5f6-9012-4ghi-bcde-000000000003",
  "appointmentId":      "a3f1c2d4-1234-4abc-89ef-000000000001",
  "chauffeurId":        "b7e2d3f5-5678-4def-90ab-000000000002",
  "assignedBy":         "user-sub-claim-identifier-001",
  "status":             "ACTIVE",
  "createdAt":          "2025-06-15T10:30:00.000Z",
  "notificationStatus": "DISPATCHED",
  "correlationId":      "d1e2f3a4-3456-4jkl-cdef-000000000004"
}

3.2 HTTP 400 Bad Request

Description: The request payload is malformed, missing required fields, or contains values that
             fail format or type validation.

Response Body Schema:

Field Name    Type      Description
status        integer   HTTP status code. Value: 400
errorCode     string    Application-level error code.
message       string    Human-readable description of the validation failure.
details       array     List of field-level validation errors.
  field       string    The name of the field that failed validation.
  issue       string    Description of the specific validation failure for that field.
correlationId string    Correlation identifier for tracing.

Example 400 Response Body:

{
  "status":        400,
  "errorCode":     "VALIDATION_ERROR",
  "message":       "Request payload validation failed.",
  "details": [
    {
      "field": "appointmentId",
      "issue": "Field is required and must be a valid UUID v4."
    },
    {
      "field": "chauffeurId",
      "issue": "Field is required and must be a valid UUID v4."
    }
  ],
  "correlationId": "d1e2f3a4-3456-4jkl-cdef-000000000004"
}

3.3 HTTP 401 Unauthorized

Description: The request does not carry a valid Bearer JWT, the token has expired, the signature
             is invalid, or the role claim does not include an authorised role. Triggered by BR-9.

Response Body Schema:

Field Name    Type      Description
status        integer   HTTP status code. Value: 401
errorCode     string    Application-level error code.
message       string    Human-readable description of the authentication or authorisation failure.
correlationId string    Correlation identifier for tracing.

Example 401 Response Body:

{
  "status":        401,
  "errorCode":     "AUTHENTICATION_FAILED",
  "message":       "Authentication required or insufficient privileges to create a chauffeur assignment.",
  "correlationId": "d1e2f3a4-3456-4jkl-cdef-000000000004"
}

3.4 HTTP 403 Forbidden

Description: The caller is authenticated but the JWT role claim does not include any of the
             permitted roles (PICKUP_COORDINATOR, ADMIN, INTEGRATION_SERVICE).

Response Body Schema:

Field Name    Type      Description
status        integer   HTTP status code. Value: 403
errorCode     string    Application-level error code.
message       string    Human-readable description of the authorisation failure.
correlationId string    Correlation identifier for tracing.

Example 403 Response Body:

{
  "status":        403,
  "errorCode":     "AUTHORISATION_DENIED",
  "message":       "The authenticated user does not hold a role permitted to create chauffeur assignments.",
  "correlationId": "d1e2f3a4-3456-4jkl-cdef-000000000004"
}

3.5 HTTP 404 Not Found

Description: The referenced appointment does not exist in the system or is not in a state that
             permits chauffeur assignment (e.g. completed, cancelled, in-progress). Triggered by BR-1.

Response Body Schema:

Field Name    Type      Description
status        integer   HTTP status code. Value: 404
errorCode     string    Application-level error code.
message       string    Human-readable description of the not-found condition.
correlationId string    Correlation identifier for tracing.

Example 404 Response Body:

{
  "status":        404,
  "errorCode":     "APPOINTMENT_NOT_FOUND_OR_NOT_ASSIGNABLE",
  "message":       "Referenced appointment not found or is not in an assignable state.",
  "correlationId": "d1e2f3a4-3456-4jkl-cdef-000000000004"
}

3.6 HTTP 409 Conflict

Description: Returned in two distinct scenarios:
             Scenario A (BR-10): An active chauffeur assignment already exists for the referenced
             appointment. The caller should use the update endpoint to modify the existing assignment.
             Scenario B (BR-3): The selected chauffeur already has an active assignment whose time
             window overlaps with the new appointment's time window.

Response Body Schema:

Field Name      Type      Description
status          integer   HTTP status code. Value: 409
errorCode       string    Application-level error code distinguishing the conflict type.
message         string    Human-readable description of the conflict.
conflictingId   string    The ID of the conflicting assignment or appointment (where applicable).
correlationId   string    Correlation identifier for tracing.

Example 409 Response Body (Scenario A - Duplicate Assignment):

{
  "status":        409,
  "errorCode":     "ASSIGNMENT_ALREADY_EXISTS",
  "message":       "An active chauffeur assignment already exists for this appointment. Use the update endpoint to modify the existing assignment.",
  "conflictingId": "existing-assignment-uuid-here",
  "correlationId": "d1e2f3a4-3456-4jkl-cdef-000000000004"
}

Example 409 Response Body (Scenario B - Chauffeur Scheduling Conflict):

{
  "status":

ENDPOINT DESIGN DOCUMENT

Source Requirement IDs: SER-010-020-114, SER-010-020-115


---------------------------------------------------------------------------
SECTION 1 - ENDPOINT IDENTIFICATION
---------------------------------------------------------------------------

Path            : /api/v1/drop-trips/{tripId}/eta
HTTP Method     : GET
Summary         : Retrieve current live ETA and delay status for the drop trip.
Description     : Computes and returns the real-time estimated time of arrival
                  for a drop trip that is currently active or in-progress. The
                  ETA is derived by invoking the external Map API using the
                  chauffeur's most recent GPS coordinates and the trip's drop
                  destination coordinates. The response also includes the live
                  trip status (e.g., en-route, delayed). This endpoint is used
                  by the coordinator dashboard and customer-facing views. The
                  operation is strictly read-only; no domain entity is mutated.
                  An audit record is written for every successful invocation.


---------------------------------------------------------------------------
SECTION 2 - REQUEST SPECIFICATION
---------------------------------------------------------------------------

2.1 Request Headers

Header Name       Required   Type     Description
Authorization     Yes        String   Bearer JWT token issued by the OAuth2/OIDC
                                      provider. Format: "Bearer <token>".
                                      Token must be valid, non-expired, and
                                      signed by the trusted issuer.
Content-Type      No         String   Not required for GET requests. Ignored if
                                      supplied.
Accept            No         String   Recommended value: application/json.
                                      Defaults to application/json if omitted.
X-Correlation-ID  No         String   Optional caller-supplied correlation
                                      identifier for distributed tracing.
                                      Passed through to downstream services.
                                      Max length: 64 characters.

2.2 Path Parameters

Parameter   Required   Type     Format / Validation
tripId      Yes        String   Non-empty string. Must conform to the internal
                                trip identifier format (UUID v4 recommended;
                                regex: ^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-4[0-9a-
                                fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]
                                {12}$). Rejected with 400 if malformed.

2.3 Query Parameters

None defined for this endpoint.

2.4 Request Body

None. This is a GET operation; no request body is accepted.


---------------------------------------------------------------------------
SECTION 3 - RESPONSE SPECIFICATION
---------------------------------------------------------------------------

3.1 HTTP 200 - Success

Description: ETA successfully computed and returned.

Response Body Schema:

Field                  Type      Required   Description
tripId                 String    Yes        The unique identifier of the drop
                                            trip. Mirrors the path parameter.
liveTripStatus         String    Yes        Current operational status of the
                                            trip. Enumerated values: EN_ROUTE,
                                            DELAYED, APPROACHING, ON_TIME.
                                            Sourced from DropTrip.status.
revisedEta             String    Yes        ISO 8601 datetime string representing
                                            the computed estimated arrival time.
                                            Example: 2025-06-15T14:32:00Z.
                                            Sourced from Map API response field
                                            estimatedArrivalTime.
distanceMetres         Integer   Yes        Remaining distance to the drop
                                            destination in metres. Must be >= 0.
                                            Sourced from Map API response field
                                            estimatedDistanceMetres.
etaComputedAt          String    Yes        ISO 8601 datetime string indicating
                                            when this ETA was computed by the
                                            system. Set to server time at
                                            computation.
correlationId          String    No         Echo of the X-Correlation-ID header
                                            if supplied by the caller.

Example 200 Response Payload:

  tripId          : "a3f1c2d4-89ab-4def-b012-3456789abcde"
  liveTripStatus  : "EN_ROUTE"
  revisedEta      : "2025-06-15T14:32:00Z"
  distanceMetres  : 4200
  etaComputedAt   : "2025-06-15T14:18:45Z"
  correlationId   : "corr-20250615-00123"


3.2 HTTP 400 - Bad Request

Description: The request is malformed. Typically caused by an invalid or
             missing tripId format.

Response Body Schema:

Field      Type     Description
errorCode  String   Machine-readable error code. Example: INVALID_REQUEST.
message    String   Human-readable description of the validation failure.
field      String   The specific field or parameter that failed validation.
timestamp  String   ISO 8601 datetime of the error.

Example 400 Response Payload:

  errorCode  : "INVALID_REQUEST"
  message    : "The tripId path parameter is not a valid UUID."
  field      : "tripId"
  timestamp  : "2025-06-15T14:18:00Z"


3.3 HTTP 401 - Unauthorized

Description: The caller did not supply a valid Bearer JWT token, or the token
             has expired or cannot be verified.

Response Body Schema:

Field      Type     Description
errorCode  String   Machine-readable error code. Example: UNAUTHORIZED.
message    String   Human-readable description.
timestamp  String   ISO 8601 datetime of the error.

Example 401 Response Payload:

  errorCode  : "UNAUTHORIZED"
  message    : "Authentication token is missing, expired, or invalid."
  timestamp  : "2025-06-15T14:18:00Z"


3.4 HTTP 403 - Forbidden

Description: The caller is authenticated but is not authorized to retrieve ETA
             for the specified trip. Applies when a CHAUFFEUR attempts to access
             a trip not assigned to them, or when the caller's role is not in
             the permitted set.

Response Body Schema:

Field      Type     Description
errorCode  String   Machine-readable error code. Example: FORBIDDEN.
message    String   Human-readable description.
timestamp  String   ISO 8601 datetime of the error.

Example 403 Response Payload:

  errorCode  : "FORBIDDEN"
  message    : "Access denied. You are not authorized to view ETA for this trip."
  timestamp  : "2025-06-15T14:18:00Z"


3.5 HTTP 404 - Not Found

Description: No drop trip record exists for the supplied tripId.

Response Body Schema:

Field      Type     Description
errorCode  String   Machine-readable error code. Example: TRIP_NOT_FOUND.
message    String   Human-readable description.
tripId     String   The tripId value that was not found.
timestamp  String   ISO 8601 datetime of the error.

Example 404 Response Payload:

  errorCode  : "TRIP_NOT_FOUND"
  message    : "Drop trip not found for the provided tripId."
  tripId     : "a3f1c2d4-89ab-4def-b012-3456789abcde"
  timestamp  : "2025-06-15T14:18:00Z"


3.6 HTTP 409 - Conflict

Description: The trip exists but is not in an active or in-progress state.
             ETA cannot be computed for completed, cancelled, or not-yet-started
             trips.

Response Body Schema:

Field           Type     Description
errorCode       String   Machine-readable error code. Example: INVALID_TRIP_STATE.
message         String   Human-readable description.
tripId          String   The tripId in question.
currentStatus   String   The actual current status of the trip.
timestamp       String   ISO 8601 datetime of the error.

Example 409 Response Payload:

  errorCode      : "INVALID_TRIP_STATE"
  message        : "ETA is not available for a trip that is not currently in progress."
  tripId         : "a3f1c2d4-89ab-4def-b012-3456789abcde"
  currentStatus  : "COMPLETED"
  timestamp      : "2025-06-15T14:18:00Z"


3.7 HTTP 422 - Unprocessable Entity

Description: The trip is active and the caller is authorized, but the
             chauffeur's GPS location is missing or has exceeded the acceptable
             staleness threshold. ETA cannot be computed without a valid
             current location.

Response Body Schema:

Field      Type     Description
errorCode  String   Machine-readable error code. Example: LOCATION_UNAVAILABLE.
message    String   Human-readable description.
tripId     String   The tripId in question.
timestamp  String   ISO 8601 datetime of the error.

Example 422 Response Payload:

  errorCode  : "LOCATION_UNAVAILABLE"
  message    : "Chauffeur location data is unavailable or stale. ETA cannot be computed at this time."
  tripId     : "a3f1c2d4-89ab-4def-b012-3456789abcde"
  timestamp  : "2025-06-15T14:18:00Z"


3.8 HTTP 500 - Internal Server Error

Description: An unexpected server-side error occurred that is not covered by
             a more specific error code.

Response Body Schema:

Field      Type     Description
errorCode  String   Machine-readable error code. Example: INTERNAL_ERROR.
message    String   Human-readable description.
timestamp  String   ISO 8601 datetime of the error.

Example 500 Response Payload:

  errorCode  : "INTERNAL_ERROR"
  message    : "An unexpected error occurred. Please contact support if the problem persists."
  timestamp  : "2025-06-15T14:18:00Z"


3.9 HTTP 503 - Service Unavailable

Description: The external Map API is unreachable or returned an error after all
             retry attempts have been exhausted and the circuit-breaker has
             opened. No stale or fabricated ETA is returned.

Response Body Schema:

Field            Type     Description
errorCode        String   Machine-readable error code. Example: ETA_SERVICE_UNAVAILABLE.
message          String   Human-readable description.
retryAfterSeconds Integer Suggested number of seconds the caller should wait
                          before retrying. Derived from circuit-breaker
                          configuration.
timestamp        String   ISO 8601 datetime of the error.

Example 503 Response Payload:

  errorCode         : "ETA_SERVICE_UNAVAILABLE"
  message           : "ETA service is temporarily unavailable. Please try again shortly."
  retryAfterSeconds : 30
  timestamp         : "2025-06-15T14:18:00Z"


---------------------------------------------------------------------------
SECTION 4 - BUSINESS RULES
---------------------------------------------------------------------------

BR-1  Category: Pre-condition
      Trigger : Any GET request to /api/v1/drop-

ENDPOINT: POST /api/v1/appointments/{appointmentId}/handover-refusal

Source Requirement ID: SER-010-020-041
Activity ID: SER-010-020-041


------------------------------------------------------------------------
SECTION 1: ENDPOINT OVERVIEW
------------------------------------------------------------------------

Path            : /api/v1/appointments/{appointmentId}/handover-refusal
HTTP Method     : POST
Summary         : Log customer handover refusal from Chauffeur app with refusal reason and live location
Description     : Allows an authenticated chauffeur to record a formal refusal of vehicle handover for a
                  specific appointment. The operation captures the refusal reason (from a predefined
                  enumeration), the vehicle registration number, the vehicle name, and the chauffeur's
                  live GPS coordinates at the time of refusal. Upon successful recording, the appointment
                  status is transitioned to HANDOVER_REFUSED, an immutable audit trail entry is created,
                  asynchronous notifications are dispatched to the Pickup Coordinator and customer
                  channels, and the next workflow step (SER-010-020-042) is triggered for coordinator
                  review and remediation. This is a one-time operation per appointment; duplicate
                  submissions are rejected.


------------------------------------------------------------------------
SECTION 2: REQUEST SPECIFICATION
------------------------------------------------------------------------

2.1 Request Headers
--------------------

Header Name       : Authorization
Required          : Yes
Format            : Bearer <JWT token>
Description       : OAuth2/OIDC Bearer JWT token. Must be valid, unexpired, and issued to a principal
                    holding the CHAUFFEUR role. Token is validated on every request.

Header Name       : Content-Type
Required          : Yes
Allowed Value     : application/json
Description       : Request body must be submitted as JSON.

Header Name       : Accept
Required          : No
Recommended Value : application/json
Description       : Indicates the client expects a JSON response.

Header Name       : X-Request-ID
Required          : No
Format            : UUID v4
Description       : Optional client-supplied correlation identifier for distributed tracing and
                    idempotency tracking. If provided, it is echoed in the response and included in
                    audit and log entries.


2.2 Path Parameters
--------------------

Parameter Name : appointmentId
Location       : Path
Type           : String
Required       : Yes
Format         : Non-empty string; expected to conform to the system's appointment identifier format
                 (e.g. UUID v4 or alphanumeric identifier as defined by the appointment store schema)
Description    : Unique identifier of the appointment for which the handover refusal is being recorded.
Validation     : Must be present and non-empty. If absent or malformed, the routing layer returns 400.
                 If well-formed but not found in the system, the service returns 404.


2.3 Query Parameters
--------------------

None defined for this endpoint.


2.4 Request Body Schema
------------------------

Content-Type : application/json
Required     : Yes

The request body must be a JSON object containing the following fields:

Field Name         : refusalReason
Type               : String (Enumerated)
Required           : Yes
Allowed Values     : One of the system-defined refusal reason codes. Examples of valid enumeration
                     members (exact values governed by the RefusalReason enumeration maintained in the
                     domain model):
                       VEHICLE_CONDITION_UNACCEPTABLE
                       CUSTOMER_NOT_PRESENT
                       CUSTOMER_REFUSED_IDENTITY_CHECK
                       INCORRECT_VEHICLE_PRESENTED
                       SAFETY_CONCERN
                       OTHER_COORDINATOR_REVIEW_REQUIRED
                     Free-text values are not permitted. The value must exactly match one of the
                     enumeration members (case-sensitive).
Validation         : Required, non-null, non-empty, must be a member of the RefusalReason enumeration.
                     Violation triggers BR-4; returns 422.
DB Column          : handover_refusal.refusal_reason
Domain Field       : HandoverRefusal.refusalReason

Field Name         : registrationNumber
Type               : String
Required           : Yes
Min Length         : 1
Max Length         : 20
Format             : Alphanumeric, may include hyphens. Must match the vehicle registration number
                     associated with the appointment record in the system.
Description        : The vehicle registration number of the vehicle involved in the handover attempt.
                     This value is cross-validated against the appointment record.
Validation         : Required, non-null, non-empty, max 20 characters, must match the registration
                     number on the appointment. Mismatch triggers BR-5; returns 422.
DB Column          : handover_refusal.vehicle_registration_no
Domain Field       : HandoverRefusal.vehicleRegistrationNumber

Field Name         : vehicleName
Type               : String
Required           : Yes
Min Length         : 1
Max Length         : 100
Format             : Free text; printable characters only; no control characters.
Description        : The display name or model description of the vehicle involved in the handover
                     attempt. Required for traceability and coordinator review.
Validation         : Required, non-null, non-empty, max 100 characters. Absence triggers BR-11;
                     returns 422.
DB Column          : handover_refusal.vehicle_name
Domain Field       : HandoverRefusal.vehicleName

Field Name         : liveLocation
Type               : Object
Required           : Yes
Description        : The chauffeur's GPS coordinates at the time of submitting the refusal. Mandatory
                     to establish proximity context.
Validation         : Required, non-null object. Absence or malformed structure triggers BR-6;
                     returns 422.
DB Column          : handover_refusal.live_location (stored as structured JSON or separate lat/lng
                     columns depending on schema implementation)
Domain Field       : HandoverRefusal.chauffeurLiveLocation

  Nested Field     : liveLocation.latitude
  Type             : Number (Double / Decimal)
  Required         : Yes
  Min Value        : -90.0
  Max Value        : 90.0
  Format           : Decimal degrees, up to 8 decimal places of precision
  Validation       : Required, must be a valid latitude value within [-90.0, 90.0]. Absence or
                     out-of-range value triggers BR-6; returns 422.

  Nested Field     : liveLocation.longitude
  Type             : Number (Double / Decimal)
  Required         : Yes
  Min Value        : -180.0
  Max Value        : 180.0
  Format           : Decimal degrees, up to 8 decimal places of precision
  Validation       : Required, must be a valid longitude value within [-180.0, 180.0]. Absence or
                     out-of-range value triggers BR-6; returns 422.

  Nested Field     : liveLocation.accuracy
  Type             : Number (Double)
  Required         : No
  Min Value        : 0.0
  Description      : GPS accuracy radius in metres. Optional but recommended for proximity assessment.
  Validation       : If provided, must be a non-negative number.

  Nested Field     : liveLocation.capturedAt
  Type             : String
  Required         : No
  Format           : ISO 8601 UTC datetime (e.g. 2025-06-15T10:30:00Z)
  Description      : Timestamp at which the GPS coordinates were captured on the device. Optional;
                     used for staleness detection if business rules require it.
  Validation       : If provided, must be a valid ISO 8601 datetime string.


2.5 Example Request
--------------------

POST /api/v1/appointments/appt-7f3a2c91-4b1e-4d8f-a3c2-1e9b0d6f5a72/handover-refusal
Authorization: Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9...
Content-Type: application/json
X-Request-ID: req-a1b2c3d4-e5f6-7890-abcd-ef1234567890

{
  "refusalReason": "CUSTOMER_NOT_PRESENT",
  "registrationNumber": "AB-1234-CD",
  "vehicleName": "Mercedes-Benz S-Class 2024",
  "liveLocation": {
    "latitude": 25.204849,
    "longitude": 55.270782,
    "accuracy": 12.5,
    "capturedAt": "2025-06-15T10:28:45Z"
  }
}


------------------------------------------------------------------------
SECTION 3: RESPONSE SPECIFICATION
------------------------------------------------------------------------

3.1 HTTP 201 Created - Successful Handover Refusal
----------------------------------------------------

Condition   : The handover refusal has been successfully validated, persisted, the appointment status
              has been updated to HANDOVER_REFUSED, the audit trail entry has been appended, and
              asynchronous downstream events have been emitted.

Response Body Schema:

Field Name              : status
Type                    : String
Description             : High-level outcome indicator. Value: "SUCCESS"

Field Name              : code
Type                    : String
Description             : Application-level response code. Value: "HANDOVER_REFUSAL_RECORDED"

Field Name              : message
Type                    : String
Description             : Human-readable confirmation message.

Field Name              : data
Type                    : Object
Description             : Contains the persisted refusal record summary.

  Nested Field          : data.refusalId
  Type                  : String
  Description           : System-generated unique identifier for the handover refusal record.

  Nested Field          : data.appointmentId
  Type                  : String
  Description           : The appointment identifier against which the refusal was recorded.

  Nested Field          : data.appointmentStatus
  Type                  : String
  Description           : Updated appointment status. Value: "HANDOVER_REFUSED"

  Nested Field          : data.refusalReason
  Type                  : String
  Description           : The refusal reason as submitted and persisted.

  Nested Field          : data.vehicleRegistrationNumber
  Type                  : String
  Description           : The vehicle registration number as submitted and persisted.

  Nested Field          : data.vehicleName
  Type                  : String
  Description           : The vehicle name as submitted and persisted.

  Nested Field          : data.chauffeurId
  Type                  : String
  Description           : The authenticated chauffeur's identifier, derived from the JWT principal.

  Nested Field          : data.refusalTimestamp
  Type                  : String (ISO 8601 UTC)
  Description           : System-generated timestamp at which the refusal was recorded.

  Nested Field          : data.liveLocation
  Type                  : Object
  Description           : Echo of the submitted live location coordinates.

    Nested Field        : data.liveLocation.latitude
    Type                : Number

    Nested Field        : data.liveLocation.longitude
    Type                : Number

  Nested Field          : data.nextWorkflowStep
  Type                  : String
  Description           : Identifier of the next workflow step triggered. Value: "SER-010-020-042"

Field Name              : requestId
Type                    : String
Description             : Echo of the X-Request-ID header if provided; otherwise system-generated
                          correlation ID.

Field Name              : timestamp
Type                    : String (ISO 8601 UTC)
Description             : Server-side timestamp of the response.

Example 201 Response:

HTTP/1.1 201 Created
Content-Type: application/json
X-Request-ID: req-a1b2c3d4-e5f6-7890-abcd-ef1234567890

{
  "status": "SUCCESS",
  "code": "HANDOVER_REFUSAL_RECORDED",
  "message": "Handover refusal has been successfully recorded. The appointment status has been updated and the Pickup Coordinator has been notified.",
  "data": {
    "refusalId": "ref-9c4e1a72-3f8b-4d2e-b1a0-7c5d9e2f6b83",
    "appointmentId": "appt-7f3a2c91-4b1e-4d8f-a3c2-1e9b0d6f5a72",
    "appointmentStatus": "HANDOVER_REFUSED",
    "refusalReason": "CUSTOMER_NOT_PRESENT",
    "vehicleRegistrationNumber": "AB-1234-CD",
    "vehicleName": "Mercedes-Benz S-Class 2024",
    "chauffeurId": "chf-00123",
    "refusalTimestamp": "2025-06

ENDPOINT DESIGN: GET /api/v1/map/live-eta/{tripId}

================================================================================
SECTION 1: ENDPOINT IDENTIFICATION
================================================================================

Path                : /api/v1/map/live-eta/{tripId}
HTTP Method         : GET
Summary             : Return the current live ETA for an active trip refreshed
                      against real-time traffic; used for delay detection and
                      customer-facing trip tracking.
Description         : Retrieves the chauffeur's real-time location from the
                      external Map API, computes the current ETA to the
                      destination, performs delay detection by comparing the
                      computed ETA against the scheduled pickup time, and
                      returns a composed payload containing live location,
                      route, ETA, trip status, customer name, and any delay
                      indicators. Each successful invocation also triggers
                      asynchronous outbound notifications to the customer and
                      Pickup Coordinator across ICP, WhatsApp, SMS, and CRM
                      channels, and appends an immutable audit record. The
                      operation is purely read-oriented with respect to trip
                      data; no trip fields are mutated.

Source Requirement IDs:
  SER-010-020-025
  SER-010-020-026
  SER-010-020-027
  SER-010-020-028
  SER-010-020-083
  SER-010-020-113
  SER-010-020-114
  SER-010-020-115


================================================================================
SECTION 2: REQUEST SPECIFICATION
================================================================================

2.1 Request Headers
--------------------------------------------------------------------------------

Header Name       : Authorization
Required          : Yes
Format            : Bearer <JWT>
Description       : OAuth2/OIDC-issued Bearer JWT. Must be signed, unexpired,
                    and issued by the authorised identity provider. The JWT
                    must carry a role claim of CHAUFFEUR, PICKUP_COORDINATOR,
                    or INTEGRATION_SERVICE and a subject claim identifying the
                    caller.

Header Name       : Accept
Required          : No (defaults to application/json)
Format            : application/json
Description       : Declares the expected response media type.

Header Name       : X-Correlation-ID
Required          : No (recommended)
Format            : UUID v4 string
Description       : Caller-supplied correlation identifier propagated through
                    all downstream service calls and included in audit records
                    and log entries for distributed tracing.

Header Name       : X-Request-ID
Required          : No
Format            : UUID v4 string
Description       : Unique identifier for the individual HTTP request, used
                    for idempotency tracking at the notification layer.


2.2 Path Parameters
--------------------------------------------------------------------------------

Parameter Name    : tripId
Location          : Path
Required          : Yes
Type              : String
Format            : UUID v4 (e.g., 550e8400-e29b-41d4-a716-446655440000)
Min Length        : 36 characters
Max Length        : 36 characters
Pattern           : ^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-4[0-9a-fA-F]{3}-
                    [89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$
Description       : The unique identifier of the trip for which live ETA is
                    being requested. Must resolve to an existing, active trip
                    record in the Trip Repository.
Validation Rules  :
  - Must be a well-formed UUID v4; reject with 400 if format is invalid.
  - Must resolve to an existing trip record; return 404 if not found.
  - Resolved trip must be in an active/in-progress state; return 409 if the
    trip is completed, cancelled, or not yet started.


2.3 Query Parameters
--------------------------------------------------------------------------------

None defined for this endpoint. All input is supplied via the path parameter
and request headers.


2.4 Request Body
--------------------------------------------------------------------------------

Not applicable. This is a GET operation; no request body is accepted.
If a request body is supplied, it must be silently ignored or rejected with
400 depending on gateway configuration.


================================================================================
SECTION 3: RESPONSE SPECIFICATION
================================================================================

3.1 HTTP 200 - Success
--------------------------------------------------------------------------------

Description       : Live ETA data successfully retrieved and composed.
Content-Type      : application/json

Response Schema:

  Field                 Type        Required   Description
  --------------------  ----------  ---------  --------------------------------
  tripId                string      Yes        UUID of the trip. Echoed from
                                               the path parameter.
  customerName          string      Yes        Full name of the customer
                                               associated with the trip,
                                               resolved from the trip record.
  tripStatus            string      Yes        Current status of the trip.
                                               Enumerated values:
                                               IN_PROGRESS, EN_ROUTE_TO_PICKUP,
                                               EN_ROUTE_TO_DROP,
                                               RETURNING_TO_DEALERSHIP.
  liveLocation          object      Yes        Chauffeur's current real-time
                                               geographic position as returned
                                               by the Map API.
    liveLocation.latitude   number  Yes        Decimal degrees. Range: -90 to
                                               +90.
    liveLocation.longitude  number  Yes        Decimal degrees. Range: -180 to
                                               +180.
    liveLocation.heading    number  No         Direction of travel in degrees
                                               (0-359). Optional; included when
                                               available from Map API.
    liveLocation.speedKmh   number  No         Current speed in km/h. Optional.
    liveLocation.capturedAt string  Yes        ISO 8601 UTC timestamp of when
                                               the location was captured by the
                                               Map API.
  eta                   string      Yes        ISO 8601 UTC timestamp
                                               representing the computed
                                               arrival time at the destination,
                                               as returned by the Map API.
  route                 object      Yes        Route details returned by the
                                               Map API.
    route.polyline      string      Yes        Encoded polyline string
                                               representing the current route.
    route.distanceKm    number      Yes        Remaining distance to destination
                                               in kilometres.
    route.durationMins  number      Yes        Estimated remaining travel time
                                               in minutes.
  delayDetected         boolean     Yes        True if the computed ETA exceeds
                                               the scheduled pickup/drop time
                                               threshold; false otherwise.
  delayDuration         string      No         ISO 8601 duration string (e.g.,
                                               PT15M) representing the computed
                                               delay. Present only when
                                               delayDetected is true.
  revisedEta            string      No         ISO 8601 UTC timestamp of the
                                               revised arrival time. Present
                                               only when delayDetected is true.
  retrievedAt           string      Yes        ISO 8601 UTC timestamp of when
                                               this ETA response was composed
                                               by the system.

Example Payload (no delay):

  tripId          : "550e8400-e29b-41d4-a716-446655440000"
  customerName    : "James Harrington"
  tripStatus      : "EN_ROUTE_TO_PICKUP"
  liveLocation    :
    latitude      : 51.507351
    longitude     : -0.127758
    heading       : 270
    speedKmh      : 42.5
    capturedAt    : "2025-07-14T09:22:10Z"
  eta             : "2025-07-14T09:35:00Z"
  route           :
    polyline      : "gcvnHpqiP_@bB..."
    distanceKm    : 5.3
    durationMins  : 12
  delayDetected   : false
  retrievedAt     : "2025-07-14T09:22:12Z"

Example Payload (delay detected):

  tripId          : "550e8400-e29b-41d4-a716-446655440000"
  customerName    : "James Harrington"
  tripStatus      : "EN_ROUTE_TO_PICKUP"
  liveLocation    :
    latitude      : 51.507351
    longitude     : -0.127758
    heading       : 270
    speedKmh      : 12.0
    capturedAt    : "2025-07-14T09:22:10Z"
  eta             : "2025-07-14T09:50:00Z"
  route           :
    polyline      : "gcvnHpqiP_@bB..."
    distanceKm    : 5.3
    durationMins  : 27
  delayDetected   : true
  delayDuration   : "PT15M"
  revisedEta      : "2025-07-14T09:50:00Z"
  retrievedAt     : "2025-07-14T09:22:12Z"


3.2 HTTP 400 - Bad Request
--------------------------------------------------------------------------------

Description       : The request is malformed. The tripId path parameter does
                    not conform to the expected UUID v4 format.

Response Schema:

  Field       Type    Required   Description
  ----------  ------  ---------  ----------------------------------------------
  errorCode   string  Yes        Machine-readable error code.
  message     string  Yes        Human-readable description of the error.
  field       string  No         The specific field that failed validation.
  traceId     string  Yes        Correlation/trace identifier for support.

Example Payload:

  errorCode   : "INVALID_PATH_PARAMETER"
  message     : "The tripId path parameter must be a valid UUID v4."
  field       : "tripId"
  traceId     : "a1b2c3d4-e5f6-7890-abcd-ef1234567890"


3.3 HTTP 401 - Unauthorized
--------------------------------------------------------------------------------

Description       : The request does not carry a valid Bearer JWT, the JWT is
                    expired, the signature is invalid, or the issuer is not
                    recognised. Corresponds to BR-11.

Response Schema:

  Field       Type    Required   Description
  ----------  ------  ---------  ----------------------------------------------
  errorCode   string  Yes        Machine-readable error code.
  message     string  Yes        Human-readable description of the error.
  traceId     string  Yes        Correlation/trace identifier for support.

Example Payload:

  errorCode   : "UNAUTHORIZED"
  message     : "Unauthorized: valid Bearer JWT required."
  traceId     : "a1b2c3d4-e5f6-7890-abcd-ef1234567890"


3.4 HTTP 403 - Forbidden
--------------------------------------------------------------------------------

Description       : The caller is authenticated but is not associated with the
                    requested trip. The JWT role is valid but the caller is
                    neither the assigned chauffeur, the managing Pickup
                    Coordinator, nor an authorised internal service for this
                    specific tripId. Corresponds to BR-12.

Response Schema:

  Field       Type    Required   Description
  ----------  ------  ---------  ----------------------------------------------
  errorCode   string  Yes        Machine-readable error code.
  message     string  Yes        Human-readable description of the error.
  traceId     string  Yes        Correlation/trace identifier for support.

Example Payload:

  errorCode   : "FORBIDDEN"
  message     : "Forbidden: you do not have access to this trip's live ETA."
  traceId     : "a1b2c3d4-e5f6-7890-abcd-ef1234567890"


3.5 HTTP 404 - Not Found
--------------------------------------------------------------------------------

Description       : The tripId does not resolve to any existing trip record,
                    or the resolved trip is not in an active/in-progress state.
                    Corresponds to BR-1.

Response Schema:

  Field       Type    Required   Description
  ----------  ------  ---------  ----------------------------------------------
  errorCode   string  Yes        Machine-readable error code.
  message     string  Yes        Human-readable description of the error.
  traceId     string  Yes        Correlation/trace identifier for support.

Example Payload:

  errorCode   : "TRIP_NOT_FOUND_OR_INACTIVE"
  message     : "Trip not found or is not in an active state."
  traceId     : "a1b2c3d4-e5f6-7890-abcd-ef1234567890"


3.6 HTTP 409 - Conflict
--------------------------------------------------------------------------------

Description       : The tripId resolves to an existing trip record but the
                    trip is not in an active/in-progress state (e.g., it is
                    completed, cancelled, or not yet started). This is
                    distinguished from 404 to allow callers to differentiate
                    between a missing trip and a state mismatch.

Response Schema:

  Field       Type    Required   Description
  ----------  ------  ---------  ----------------------------------------------
  errorCode   string  Yes        Machine-readable error code.
  message     string  Yes        Human-readable description of the error.
  currentStatus string No        The actual current status of the trip.

ENDPOINT DESIGN DOCUMENT
========================================================================================

Endpoint Reference: POST /api/v1/drop-trips/{tripId}/reassign
Source Requirements: SER-010-020-126, SER-010-020-128


----------------------------------------------------------------------------------------
SECTION 1 — ENDPOINT IDENTIFICATION
----------------------------------------------------------------------------------------

Path            : /api/v1/drop-trips/{tripId}/reassign
HTTP Method     : POST
Summary         : Reassign a drop trip to a replacement chauffeur.
Description     : Allows an authenticated Pickup Coordinator to reassign an active,
                  assigned, or in-progress drop trip to a different chauffeur. The
                  coordinator supplies the replacement chauffeur identifier and a
                  mandatory reassignment reason. On acceptance the system releases the
                  original chauffeur, persists the new assignment, triggers a revised
                  ETA calculation, appends an immutable audit entry, and dispatches
                  outbound notifications to the customer and the replacement chauffeur
                  via all configured channels. CRM and DBP downstream systems are also
                  updated asynchronously.


----------------------------------------------------------------------------------------
SECTION 2 — REQUEST SPECIFICATION
----------------------------------------------------------------------------------------

2.1 Request Headers
-------------------

Header Name          Required   Format / Constraints
--------------------  ---------  -------------------------------------------------------
Authorization         Yes        Bearer <JWT>. Must be a valid, non-expired JWT issued
                                 by the configured OAuth2/OIDC provider. Token must
                                 carry the PICKUP_COORDINATOR role claim and the
                                 drop-trip:reassign scope.
Content-Type          Yes        Must be application/json.
Accept                No         application/json (default if omitted).
X-Idempotency-Key     Recommended Client-generated UUID v4. Used for deduplication within
                                 the configured deduplication window. If the same key is
                                 received within the window, the cached response is
                                 returned without reprocessing. Maximum length: 64
                                 characters. Format: UUID v4 (8-4-4-4-12 hex groups).
X-Request-ID          No         Caller-supplied correlation identifier for distributed
                                 tracing. Echoed back in the response header. Maximum
                                 length: 64 characters.
X-Correlation-ID      No         Upstream correlation identifier for end-to-end trace
                                 propagation. Maximum length: 128 characters.


2.2 Path Parameters
-------------------

Parameter   Type     Required   Constraints
----------  -------  ---------  --------------------------------------------------------
tripId      string   Yes        Non-empty string. Must match the internal trip identifier
                                format (UUID v4 or system-defined alphanumeric key).
                                Maximum length: 64 characters. The referenced trip must
                                exist, be of type DROP, and be in a reassignable state
                                (active, assigned, or in-progress). Trips in completed,
                                cancelled, or any terminal state are not eligible.


2.3 Query Parameters
--------------------

None defined for this endpoint.


2.4 Request Body Schema
-----------------------

Content-Type: application/json

The request body is required. All fields listed below must be present unless explicitly
marked optional.

Field Name                Type     Required   Constraints
------------------------  -------  ---------  ------------------------------------------
replacementChauffeurId    string   Yes        Non-null, non-blank. Identifier of the
                                              replacement chauffeur. Must correspond to a
                                              registered chauffeur in the system. Must not
                                              be the same as the currently assigned
                                              chauffeur. Maximum length: 64 characters.
                                              Allowed characters: alphanumeric, hyphens,
                                              underscores.
reassignmentReason        string   Yes        Non-null, non-blank. Human-readable reason
                                              for the reassignment provided by the Pickup
                                              Coordinator. Minimum length: 5 characters.
                                              Maximum length: 500 characters. Must not
                                              contain only whitespace.
notifyCustomer            boolean  No         Indicates whether the customer notification
                                              should be suppressed. Defaults to true if
                                              omitted. When false, outbound customer
                                              notifications are not dispatched. Chauffeur
                                              and downstream system notifications are
                                              unaffected by this flag.
additionalNotes           string   No         Free-text supplementary notes for internal
                                              reference. Maximum length: 1000 characters.
                                              Not persisted to the audit trail. Stored
                                              against the trip record only.

Example Request Body:

{
  "replacementChauffeurId": "CHF-00482",
  "reassignmentReason": "Original chauffeur reported vehicle breakdown en route.",
  "notifyCustomer": true,
  "additionalNotes": "Replacement chauffeur confirmed available and en route."
}


----------------------------------------------------------------------------------------
SECTION 3 — RESPONSE SPECIFICATION
----------------------------------------------------------------------------------------

3.1 HTTP 200 — Successful Reassignment
---------------------------------------

Returned when the reassignment is successfully persisted and all synchronous steps
(audit write, ETA calculation attempt) complete without error.

Response Body Schema:

Field Name                  Type     Nullable   Description
--------------------------  -------  ---------  ----------------------------------------
tripId                      string   No         Identifier of the reassigned drop trip.
status                      string   No         Updated trip status after reassignment.
                                                Possible values: ASSIGNED, IN_PROGRESS.
assignedChauffeurId         string   No         Identifier of the newly assigned
                                                replacement chauffeur.
previousChauffeurId         string   No         Identifier of the original chauffeur who
                                                was released.
reassignmentReason          string   No         The reason as submitted by the coordinator.
revisedEta                  string   Yes        ISO 8601 datetime string representing the
                                                system-calculated revised ETA. Null if ETA
                                                calculation is pending (see etaStatus).
etaStatus                   string   No         Indicates ETA calculation outcome.
                                                Values: CALCULATED, PENDING_RECALCULATION.
auditEntryId                string   No         Identifier of the immutable audit log entry
                                                created for this reassignment event.
reassignedAt                string   No         ISO 8601 datetime of the reassignment
                                                event as recorded by the system.
notificationsDispatched     boolean  No         True if customer notification events were
                                                queued for dispatch; false if suppressed
                                                via the notifyCustomer flag.

Example 200 Response Body:

{
  "tripId": "TRP-20948",
  "status": "ASSIGNED",
  "assignedChauffeurId": "CHF-00482",
  "previousChauffeurId": "CHF-00317",
  "reassignmentReason": "Original chauffeur reported vehicle breakdown en route.",
  "revisedEta": "2025-07-15T14:35:00Z",
  "etaStatus": "CALCULATED",
  "auditEntryId": "AUD-88321",
  "reassignedAt": "2025-07-15T13:58:42Z",
  "notificationsDispatched": true
}

Example 200 Response Body (ETA pending):

{
  "tripId": "TRP-20948",
  "status": "ASSIGNED",
  "assignedChauffeurId": "CHF-00482",
  "previousChauffeurId": "CHF-00317",
  "reassignmentReason": "Original chauffeur reported vehicle breakdown en route.",
  "revisedEta": null,
  "etaStatus": "PENDING_RECALCULATION",
  "auditEntryId": "AUD-88322",
  "reassignedAt": "2025-07-15T13:58:42Z",
  "notificationsDispatched": true
}


3.2 HTTP 400 — Bad Request / Validation Failure
------------------------------------------------

Returned when the request body fails field-level validation (missing required fields,
blank values, format violations).

Response Body Schema:

Field Name   Type     Description
-----------  -------  -----------------------------------------------------------------
errorCode    string   Machine-readable error code.
message      string   Human-readable summary of the validation failure.
details      array    List of individual field-level validation errors.
  field      string   Name of the field that failed validation.
  issue      string   Description of the specific validation failure.
traceId      string   Correlation identifier for support and log tracing.

Example 400 Response Body (missing reassignmentReason):

{
  "errorCode": "VALIDATION_ERROR",
  "message": "One or more request fields failed validation.",
  "details": [
    {
      "field": "reassignmentReason",
      "issue": "Reassignment reason is required and must not be blank."
    }
  ],
  "traceId": "abc-123-def-456"
}

Example 400 Response Body (missing replacementChauffeurId):

{
  "errorCode": "VALIDATION_ERROR",
  "message": "One or more request fields failed validation.",
  "details": [
    {
      "field": "replacementChauffeurId",
      "issue": "Replacement chauffeur identifier is required for reassignment."
    }
  ],
  "traceId": "abc-123-def-457"
}


3.3 HTTP 401 — Unauthorised
----------------------------

Returned when the Bearer JWT is absent, expired, malformed, or fails signature
validation.

Example 401 Response Body:

{
  "errorCode": "UNAUTHORIZED",
  "message": "Authentication is required. Provide a valid Bearer JWT token.",
  "traceId": "abc-123-def-458"
}


3.4 HTTP 403 — Forbidden
-------------------------

Returned when the authenticated caller does not hold the PICKUP_COORDINATOR role or
does not carry the drop-trip:reassign scope, or when the coordinator's assigned scope
does not cover the trip context.

Example 403 Response Body:

{
  "errorCode": "ACCESS_DENIED",
  "message": "Access denied. Only Pickup Coordinators are permitted to reassign drop trips.",
  "traceId": "abc-123-def-459"
}


3.5 HTTP 404 — Not Found
-------------------------

Returned when the tripId does not correspond to any existing trip record, or when the
trip exists but is in a terminal state (completed, cancelled) that makes it
non-reassignable.

Example 404 Response Body:

{
  "errorCode": "TRIP_NOT_FOUND_OR_NOT_REASSIGNABLE",
  "message": "Trip not found or is not in a reassignable state.",
  "traceId": "abc-123-def-460"
}


3.6 HTTP 409 — Conflict
------------------------

Returned when the specified replacement chauffeur is currently assigned to another
active trip and is therefore unavailable, or when a concurrent reassignment request
for the same trip is detected.

Example 409 Response Body (chauffeur unavailable):

{
  "errorCode": "CHAUFFEUR_UNAVAILABLE",
  "message": "The selected replacement chauffeur is currently assigned to another active trip and is unavailable.",
  "traceId": "abc-123-def-461"
}

Example 409 Response Body (concurrent reassignment conflict):

{
  "errorCode": "CONCURRENT_REASSIGNMENT_CONFLICT",
  "message": "A concurrent reassignment is already in progress for this trip. Please retry.",
  "traceId": "abc-123-def-462"
}


3.7 HTTP 422 — Unprocessable Entity
-------------------------------------

Returned when the tripId resolves to a trip that exists but is not of type DROP (for
example, it is a pickup trip), making this endpoint inapplicable.

Example 422 Response Body:

{
  "errorCode": "INVALID_TRIP_TYPE",
  "message": "The specified trip is not a drop trip. Use the appropriate endpoint for pickup trip reassignment.",
  "traceId": "abc-123-def-463"
}


3.8 HTTP 500 — Internal Server Error
--------------------------------------

Returned when an unexpected server-side error occurs that prevents the reassignment
from completing. If the audit trail write fails, the transaction is rolled back and
this code is returned to ensure no unaudited state change is persisted.

Example 500 Response Body:

{
  "errorCode": "INTERNAL_SERVER_ERROR",
  "message": "An unexpected error occurred while processing the reassignment. Please retry or contact support.",
  "traceId": "abc-123-def-464"
}


----------------------------------------------------------------------------------------
SECTION 4 — BUSINESS RULES
----------------------------------------------------------------------------------------

Rule ID   Category       Trigger Condition
--------  -------------  ---------------------------------------------------------------
BR-1      Pre-condition  POST is invoked. The trip identified by tripId must exist and
                         be in an active, in-progress, or assigned state. Trips in
                         completed or cancelled states are rejected. Returns 404 if the
                         trip is not found or not in a reassignable state.

BR-2      Validation     Request is submitted without a reassignmentReason field or with
                         a blank or null value. The field is mandatory. Returns 400 with
                         a field-level validation error.

BR-3      Validation     Request is submitted without a valid replacementCha

ENDPOINT DESIGN: POST /api/v1/vehicle-condition-reports/sessions/{sessionId}/verify-vehicle

================================================================================
SECTION 1: ENDPOINT OVERVIEW
================================================================================

Path            : /api/v1/vehicle-condition-reports/sessions/{sessionId}/verify-vehicle
HTTP Method     : POST
Summary         : Validate QR scan result or manually entered registration number and VIN
                  against appointment record; returns matched vehicle details or validation error.
Description     : This endpoint allows an authenticated chauffeur to verify the vehicle
                  associated with an active vehicle condition report (VCR) session. The
                  chauffeur submits a QR code value (scanned from the appointment booking)
                  along with a vehicle registration number (captured via OCR or entered
                  manually) and a VIN. The system resolves the appointment booking details
                  from a downstream service, validates the submitted registration number and
                  VIN, cross-checks the VIN against the appointment record, and on success
                  auto-populates all vehicle details against the session record, advancing
                  the session status to VEHICLE_VERIFIED.

Source Requirements : SER-010-020-053, SER-010-020-055, SER-010-020-057,
                      SER-010-020-058, SER-010-020-059, SER-010-020-061


================================================================================
SECTION 2: REQUEST SPECIFICATION
================================================================================

2.1 Request Headers
--------------------------------------------------------------------------------

Header Name       : Authorization
Required          : Yes
Format            : Bearer <JWT token>
Description       : OAuth2 / OIDC Bearer JWT. Must be a valid, non-expired token issued
                    by the authorised identity provider. The token must contain the sub
                    claim (chauffeur identity) and a roles claim that includes CHAUFFEUR.

Header Name       : Content-Type
Required          : Yes
Expected Value    : application/json
Description       : Request body must be JSON-encoded.

Header Name       : Accept
Required          : No (recommended)
Expected Value    : application/json
Description       : Indicates the client expects a JSON response.

Header Name       : X-Request-ID
Required          : No (recommended)
Format            : UUID v4
Description       : Client-generated correlation identifier for distributed tracing and
                    support diagnostics. If provided, it is echoed back in the response
                    header X-Request-ID.


2.2 Path Parameters
--------------------------------------------------------------------------------

Parameter Name    : sessionId
Location          : Path
Type              : String
Format            : UUID v4
Required          : Yes
Description       : The unique identifier of the active vehicle condition report session
                    against which vehicle verification is to be performed.
Validation Rules  :
  - Must be a valid UUID v4 format (8-4-4-4-12 hexadecimal pattern).
  - Must correspond to an existing, non-terminal VCR session in the system.
  - If not found or in a terminal state, the system returns HTTP 404.
Example           : 3fa85f64-5717-4562-b3fc-2c963f66afa6


2.3 Request Body Schema
--------------------------------------------------------------------------------

Content-Type      : application/json
Root Object       : VerifyVehicleRequest

Field: qrCode
  Type            : String
  Required        : Yes
  Min Length      : 1
  Max Length      : 512
  Format          : Opaque string encoded in the appointment QR code. May be a URL,
                    a UUID, or a structured token depending on the QR generation scheme.
  Description     : The raw value decoded from the QR code scanned by the chauffeur.
                    This value is passed to the Appointment Booking Service to resolve
                    the linked appointment record and retrieve vehicle details.
  Validation      : Must be non-empty. Must not contain null bytes or control characters.
  Example         : "APT-20240615-7A3F9C"

Field: vehicleRegistrationNumber
  Type            : String
  Required        : Yes
  Min Length      : 2
  Max Length      : 15
  Format          : Alphanumeric, may include hyphens. Must conform to the registration
                    number format applicable to the operating jurisdiction.
  Regex Pattern   : ^[A-Z0-9][A-Z0-9\- ]{1,13}[A-Z0-9]$  (case-insensitive match
                    applied after normalisation to uppercase)
  Description     : The vehicle registration number as captured by OCR from the vehicle
                    plate or entered manually by the chauffeur after OCR correction.
                    Both paths must produce a non-empty, correctly formatted value before
                    submission. The system rejects blank or format-invalid values.
  Validation      : Must be non-empty. Must match the regex pattern after trimming
                    whitespace and converting to uppercase. Must not be all whitespace.
  Example         : "AB12 CDE"

Field: vin
  Type            : String
  Required        : Yes
  Length          : Exactly 17 characters
  Format          : ISO 3779 VIN format. 17 alphanumeric characters. Characters I, O,
                    and Q are not permitted in positions 1-17 per ISO standard.
  Regex Pattern   : ^[A-HJ-NPR-Z0-9]{17}$
  Description     : The Vehicle Identification Number as read from the vehicle or
                    provided by the chauffeur. This value is cross-checked against the
                    VIN on record in the appointment booking. A mismatch causes the
                    request to be rejected.
  Validation      : Must be exactly 17 characters. Must match the regex pattern.
                    Must not contain the letters I, O, or Q.
  Example         : "1HGBH41JXMN109186"

Full Request Body Example:

  {
    "qrCode": "APT-20240615-7A3F9C",
    "vehicleRegistrationNumber": "AB12 CDE",
    "vin": "1HGBH41JXMN109186"
  }


================================================================================
SECTION 3: RESPONSE SPECIFICATION
================================================================================

3.1 HTTP 200 OK — Vehicle Already Verified (Idempotency Path)
--------------------------------------------------------------------------------

Condition         : The session status is already VEHICLE_VERIFIED. The system returns
                    the existing verified vehicle details without re-processing.
                    Note: Per business rule BR-10, this scenario returns HTTP 409.
                    See Section 3.5 for the 409 response definition.


3.2 HTTP 201 Created — Vehicle Successfully Verified
--------------------------------------------------------------------------------

Condition         : All validations pass, VIN cross-check succeeds, vehicle details are
                    persisted, and session status is updated to VEHICLE_VERIFIED.

Response Body Schema (VerifyVehicleResponse):

Field: sessionId
  Type            : String (UUID v4)
  Description     : The session identifier echoed back from the path parameter.

Field: status
  Type            : String (Enum)
  Value           : "VEHICLE_VERIFIED"
  Description     : The updated status of the VCR session.

Field: vehicleVerifiedAt
  Type            : String (ISO 8601 datetime with timezone)
  Format          : yyyy-MM-ddTHH:mm:ssZ
  Description     : The UTC timestamp at which vehicle verification was completed.

Field: appointmentReference
  Type            : String
  Description     : The appointment booking reference resolved from the QR code.

Field: vehicleDetails
  Type            : Object
  Description     : The auto-populated vehicle details retrieved from the appointment
                    booking record.

  Field: vehicleRegistrationNumber
    Type          : String
    Description   : The registration number of the verified vehicle.

  Field: vin
    Type          : String
    Description   : The VIN of the verified vehicle.

  Field: vehicleModel
    Type          : String
    Description   : The vehicle model as recorded in the appointment booking.

  Field: customerName
    Type          : String
    Description   : The name of the customer associated with the appointment.

  Field: pickUpTime
    Type          : String (ISO 8601 datetime with timezone)
    Description   : The scheduled pick-up time from the appointment record.

  Field: odometerReading
    Type          : Number (integer or decimal)
    Unit          : Kilometres or miles as per system configuration
    Description   : The odometer reading recorded at the time of appointment booking.

  Field: fuelLevel
    Type          : String (Enum)
    Allowed Values: EMPTY, QUARTER, HALF, THREE_QUARTER, FULL
    Description   : The fuel level recorded at the time of appointment booking.

Field: links
  Type            : Object
  Description     : HATEOAS-style navigation links for the next steps in the workflow.

  Field: self
    Type          : String (URI)
    Description   : URI of the current session resource.

  Field: nextStep
    Type          : String (URI)
    Description   : URI for the next step in the VCR workflow (e.g., photo capture).

Example Response Body (HTTP 201):

  {
    "sessionId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
    "status": "VEHICLE_VERIFIED",
    "vehicleVerifiedAt": "2024-06-15T09:32:00Z",
    "appointmentReference": "APT-20240615-7A3F9C",
    "vehicleDetails": {
      "vehicleRegistrationNumber": "AB12 CDE",
      "vin": "1HGBH41JXMN109186",
      "vehicleModel": "Mercedes-Benz S-Class",
      "customerName": "Jane Doe",
      "pickUpTime": "2024-06-15T10:00:00Z",
      "odometerReading": 24500,
      "fuelLevel": "THREE_QUARTER"
    },
    "links": {
      "self": "/api/v1/vehicle-condition-reports/sessions/3fa85f64-5717-4562-b3fc-2c963f66afa6",
      "nextStep": "/api/v1/vehicle-condition-reports/sessions/3fa85f64-5717-4562-b3fc-2c963f66afa6/capture-photos"
    }
  }


3.3 HTTP 400 Bad Request — Validation Failure
--------------------------------------------------------------------------------

Condition         : One or more request fields fail format or constraint validation.
                    Triggered by: invalid registration number format (BR-3), invalid VIN
                    format (BR-4 format check), missing required fields.

Response Body Schema (ErrorResponse):

Field: errorCode
  Type            : String
  Description     : Machine-readable error code.

Field: errorMessage
  Type            : String
  Description     : Human-readable description of the error.

Field: fieldErrors
  Type            : Array of FieldError objects
  Description     : List of individual field-level validation failures.

  FieldError fields:
    field         : String — the request field name that failed validation.
    message       : String — description of the specific validation failure.
    rejectedValue : String — the value that was submitted and rejected.

Example Response Body (HTTP 400):

  {
    "errorCode": "VALIDATION_FAILED",
    "errorMessage": "Vehicle registration number is missing or has an invalid format.",
    "fieldErrors": [
      {
        "field": "vehicleRegistrationNumber",
        "message": "Registration number does not match the required format.",
        "rejectedValue": "AB!12--"
      }
    ]
  }


3.4 HTTP 401 Unauthorized — Authentication Failure
--------------------------------------------------------------------------------

Condition         : The Bearer JWT is absent, expired, malformed, or fails signature
                    validation.

Example Response Body (HTTP 401):

  {
    "errorCode": "UNAUTHORIZED",
    "errorMessage": "Authentication is required. Provide a valid Bearer token."
  }


3.5 HTTP 403 Forbidden — Authorisation Failure
--------------------------------------------------------------------------------

Condition         : The authenticated chauffeur does not hold the CHAUFFEUR role, or
                    the chauffeur is not the one assigned to the appointment linked to
                    the session (BR-9).

Example Response Body (HTTP 403):

  {
    "errorCode": "FORBIDDEN",
    "errorMessage": "You are not authorised to verify the vehicle for this session."
  }


3.6 HTTP 404 Not Found — Session or Vehicle Record Not Found
--------------------------------------------------------------------------------

Condition A (BR-1): The sessionId does not correspond to any existing VCR session, or
                    the session is in a terminal/closed state.

Example Response Body (HTTP 404 — Session Not Found):

  {
    "errorCode": "SESSION_NOT_FOUND",
    "errorMessage": "Vehicle condition report session not found or is no longer active."
  }

Condition B (BR-7): The registration number cannot be resolved to a VIN in the vehicle
                    master or appointment record.

Example Response Body (HTTP 404 — Vehicle Not Found):

  {
    "errorCode": "VEHICLE_NOT_FOUND",
    "errorMessage": "No vehicle record found for the provided registration number."
  }


3.7 HTTP 409 Conflict — Business Rule Conflict
--------------------------------------------------------------------------------

Condition A (BR-10): The session is already in VEHICLE_VERIFIED state. Returns existing
                     verified vehicle details without re-processing.

Example Response Body (HTTP 409 — Already Verified):

  {
    "errorCode": "ALREADY_VERIFIED",
    "errorMessage": "Vehicle has already been verified for this session.",
    "existingVerification": {
      "sessionId": "3fa85f64-5717-4562-b

ENDPOINT DESIGN: GET /api/v1/drop-trips/{tripId}

================================================================================
SECTION 1: ENDPOINT IDENTIFICATION
================================================================================

Path            : /api/v1/drop-trips/{tripId}
HTTP Method     : GET
Summary         : Retrieve full drop trip orchestration state including status,
                  live ETA, assignment, image references, contact log, and
                  exception flags for coordinator dashboard.
Description     : Returns the complete detail record for a single drop trip
                  identified by tripId. The response merges static trip data
                  persisted in the Drop Trip Data Store with real-time tracking
                  data (live location, current route, ETA, revised ETA) sourced
                  synchronously from the Map API integration. This is a pure
                  read operation; no state changes are applied to any domain
                  entity. If the Map API is unavailable, the endpoint returns
                  available static data with a degraded-mode indicator rather
                  than failing the entire request.

Source Requirement IDs : SER-010-020-113, SER-010-020-114
Source Activity IDs    : SER-010-020-113, SER-010-020-114


================================================================================
SECTION 2: REQUEST SPECIFICATION
================================================================================

2.1 REQUEST HEADERS
--------------------------------------------------------------------------------

Header Name       : Authorization
Required          : Yes
Format            : Bearer <JWT token>
Description       : OAuth2 / OIDC Bearer token. Must be a valid, non-expired JWT
                    signed by the trusted issuer. Token must carry role claim
                    (CHAUFFEUR, PICKUP_COORDINATOR, or INTEGRATION_SERVICE) and,
                    for CHAUFFEUR role, a subject claim identifying the caller.
Validation        : Signature verified against JWKS endpoint; expiry (exp) and
                    issuer (iss) claims validated server-side. Missing or
                    malformed token results in 401.

Header Name       : Accept
Required          : No (defaults to application/json)
Format            : application/json
Description       : Indicates the expected response media type.

Header Name       : X-Correlation-ID
Required          : No
Format            : UUID v4 string
Description       : Optional caller-supplied correlation identifier for
                    distributed tracing. If provided, echoed back in the
                    response header. If absent, the system generates one
                    internally.

Header Name       : X-Request-ID
Required          : No
Format            : UUID v4 string
Description       : Optional idempotency / tracing token for the individual
                    request. Logged alongside the audit entry.


2.2 PATH PARAMETERS
--------------------------------------------------------------------------------

Parameter Name    : tripId
Location          : Path
Required          : Yes
Type              : String
Format            : Non-empty alphanumeric identifier; expected pattern is a
                    UUID v4 (8-4-4-4-12 hexadecimal characters separated by
                    hyphens) or a system-defined opaque string of 1 to 128
                    characters containing only alphanumeric characters and
                    hyphens.
Regex             : ^[a-zA-Z0-9\-]{1,128}$
Min Length        : 1
Max Length        : 128
Description       : Unique identifier of the drop trip record to retrieve.
Validation Rules  : Must be non-empty. Must conform to the regex pattern above.
                    A blank, null, or pattern-violating value results in a 400
                    Bad Request before any downstream calls are made (BR-7).


2.3 QUERY PARAMETERS
--------------------------------------------------------------------------------

None defined for this endpoint.


2.4 REQUEST BODY
--------------------------------------------------------------------------------

Not applicable. GET requests carry no request body. Any body present in the
request must be ignored by the server.


================================================================================
SECTION 3: RESPONSE SPECIFICATION
================================================================================

3.1 HTTP 200 - SUCCESS (FULL DATA)
--------------------------------------------------------------------------------

Description       : The drop trip record was found and all real-time data was
                    successfully retrieved from the Map API. The response
                    contains the complete merged trip detail.

Response Headers  :
  Content-Type      : application/json
  X-Correlation-ID  : Echoed or system-generated correlation identifier.

Response Body Schema:

  Field                   Type        Required   Description
  ----------------------- ----------- ---------- --------------------------------
  tripId                  string      Yes        Unique identifier of the trip.
  tripStatus              string      Yes        Current lifecycle status of the
                                                 trip (e.g., SCHEDULED, IN_PROGRESS,
                                                 COMPLETED, CANCELLED).
  chauffeurId             string      Yes        Identifier of the chauffeur
                                                 assigned to this trip.
  appointmentId           string      Yes        Identifier of the associated
                                                 appointment record.
  liveLocation            object      Yes        Real-time GPS coordinates of the
                                                 chauffeur sourced from Map API.
    liveLocation.latitude   number    Yes        Decimal latitude (-90 to 90).
    liveLocation.longitude  number    Yes        Decimal longitude (-180 to 180).
    liveLocation.heading    number    No         Direction of travel in degrees
                                                 (0-360).
    liveLocation.speed      number    No         Current speed in km/h.
    liveLocation.timestamp  string    Yes        ISO 8601 UTC timestamp of the
                                                 location reading.
  route                   object      Yes        Current computed route from Map
                                                 API.
    route.origin            object    Yes        Origin waypoint.
      route.origin.lat      number    Yes        Latitude of origin.
      route.origin.lng      number    Yes        Longitude of origin.
      route.origin.label    string    No         Human-readable label.
    route.destination       object    Yes        Destination waypoint.
      route.destination.lat number    Yes        Latitude of destination.
      route.destination.lng number    Yes        Longitude of destination.
      route.destination.label string No          Human-readable label.
    route.waypoints         array     No         Ordered list of intermediate
                                                 waypoints; each element has lat,
                                                 lng, and optional label fields.
    route.distanceKm        number    Yes        Total remaining route distance
                                                 in kilometres.
    route.polyline          string    No         Encoded polyline string for
                                                 rendering on a map.
  eta                     string      Yes        Original estimated time of
                                                 arrival in ISO 8601 UTC format.
  revisedEta              string      No         Most recently recomputed ETA
                                                 reflecting current traffic and
                                                 route changes; ISO 8601 UTC.
                                                 Null if no revision has occurred.
  createdAt               string      Yes        ISO 8601 UTC timestamp of record
                                                 creation.
  updatedAt               string      Yes        ISO 8601 UTC timestamp of last
                                                 record update.
  trackingDataAvailable   boolean     Yes        Indicates whether real-time
                                                 tracking data was successfully
                                                 retrieved. True in the 200 full
                                                 data scenario.

Example Payload (200 Full Data):

  {
    "tripId": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    "tripStatus": "IN_PROGRESS",
    "chauffeurId": "ch-00123",
    "appointmentId": "appt-00456",
    "liveLocation": {
      "latitude": 25.2048,
      "longitude": 55.2708,
      "heading": 270,
      "speed": 60,
      "timestamp": "2025-06-15T10:32:00Z"
    },
    "route": {
      "origin": {
        "lat": 25.1972,
        "lng": 55.2744,
        "label": "Dubai International Airport"
      },
      "destination": {
        "lat": 25.2285,
        "lng": 55.3273,
        "label": "Downtown Dubai Hotel"
      },
      "waypoints": [],
      "distanceKm": 12.4,
      "polyline": "encoded_polyline_string_here"
    },
    "eta": "2025-06-15T10:45:00Z",
    "revisedEta": "2025-06-15T10:50:00Z",
    "createdAt": "2025-06-15T09:00:00Z",
    "updatedAt": "2025-06-15T10:30:00Z",
    "trackingDataAvailable": true
  }


3.2 HTTP 200 - SUCCESS (DEGRADED MODE)
--------------------------------------------------------------------------------

Description       : The drop trip record was found in the data store but the
                    Map API was unavailable after retries. Static trip data is
                    returned. Real-time fields are null or absent. A degraded

ENDPOINT: POST /api/v1/map/suggested-start-time

Source Requirement ID: SER-010-020-130
Source Activity ID: SER-010-020-130


------------------------------------------------------------------------
SECTION 1: ENDPOINT OVERVIEW
------------------------------------------------------------------------

Path            : /api/v1/map/suggested-start-time
HTTP Method     : POST
Summary         : Calculate the suggested start time for a chauffeur to begin
                  a pickup or drop trip given the appointment/delivery time,
                  origin location, and destination address.
Description     : This endpoint computes the suggested time at which a chauffeur
                  should begin a pickup or drop activity. It invokes the external
                  Map API in real time to obtain route duration and live traffic
                  data, derives the suggested start time from those values and
                  the appointment's scheduled time, and returns the result to the
                  caller. For drop appointments, a suggested vehicle departure
                  time is additionally computed and returned. A revised ETA is
                  always system-derived and returned as a read-only field. All
                  computed values are persisted against the appointment record
                  and the downstream orchestration step SER-010-020-020 is
                  signalled asynchronously. The endpoint is intended for
                  consumption by the Chauffeur stakeholder and internal
                  orchestration services.


------------------------------------------------------------------------
SECTION 2: SECURITY REQUIREMENTS
------------------------------------------------------------------------

Authentication
  Mechanism     : Bearer JWT (OAuth2 / OIDC)
  Header        : Authorization: Bearer <token>
  Validation    : Token signature, expiry (exp claim), and issuer (iss claim)
                  must all be verified on every request. Expired or malformed
                  tokens are rejected with HTTP 401.

Authorization
  Model         : Role-Based Access Control (RBAC)
  Permitted Roles: CHAUFFEUR, ORCHESTRATION_SERVICE
  Enforcement   : The JWT must carry a role claim matching one of the permitted
                  roles. Any other role, or absence of the role claim, results
                  in HTTP 403.
  OAuth2 Scope  : appointment:map:read

Rate Limiting
  Policy        : Standard service-level rate limit (see COMMON_RATE_LIMITS).
  Breach Response: HTTP 429 Too Many Requests with Retry-After header.

Transport Security
  All traffic must be over TLS 1.2 or higher. Plain HTTP requests must be
  rejected.


------------------------------------------------------------------------
SECTION 3: REQUEST SPECIFICATION
------------------------------------------------------------------------

3.1 Request Headers

  Header Name       Required   Description
  ----------------  ---------  -------------------------------------------
  Authorization     Yes        Bearer JWT token. Format: "Bearer <token>"
  Content-Type      Yes        Must be "application/json"
  Accept            No         Should be "application/json" (default assumed)
  X-Correlation-ID  No         Caller-supplied trace identifier for log
                               correlation. If absent, the service generates
                               one internally and includes it in the response.
  X-Request-ID      No         Idempotency hint from caller. Not enforced by
                               the service but logged for traceability.


3.2 Path Parameters

  None.


3.3 Query Parameters

  None.


3.4 Request Body Schema

  Content-Type: application/json

  The request body is a JSON object. All fields are described below.

  Field: appointmentId
    Type        : string
    Required    : Yes
    Format      : UUID (RFC 4122), e.g. "550e8400-e29b-41d4-a716-446655440000"
    Constraints : Must be a non-empty, well-formed UUID. Must reference an
                  appointment that exists in the data store and is in an
                  active or schedulable state.
    Description : Unique identifier of the appointment for which the suggested
                  start time is being requested.

  Field: appointmentType
    Type        : string (enum)
    Required    : Yes
    Allowed Values: "pickup", "drop"
    Constraints : Case-sensitive. Any value other than "pickup" or "drop" is
                  rejected with HTTP 400 (BR-6).
    Description : Discriminator that determines whether the computation is for
                  a pickup activity or a drop activity. Drives conditional
                  logic for vehicle departure time calculation (BR-3, BR-4).

  Field: origin
    Type        : object
    Required    : Yes
    Description : The starting location from which the chauffeur or vehicle
                  will depart.

    Field: origin.latitude
      Type        : number (double)
      Required    : Yes
      Min         : -90.0
      Max         : 90.0
      Description : WGS-84 latitude of the origin point.

    Field: origin.longitude
      Type        : number (double)
      Required    : Yes
      Min         : -180.0
      Max         : 180.0
      Description : WGS-84 longitude of the origin point.

    Field: origin.addressLine
      Type        : string
      Required    : No
      Max Length  : 255 characters
      Description : Human-readable address of the origin. Used for audit
                    logging and display purposes; not used in Map API call
                    directly if coordinates are provided.

  Field: destination
    Type        : object
    Required    : Yes
    Description : The target location to which the chauffeur or vehicle
                  must travel.

    Field: destination.latitude
      Type        : number (double)
      Required    : Yes
      Min         : -90.0
      Max         : 90.0
      Description : WGS-84 latitude of the destination point.

    Field: destination.longitude
      Type        : number (double)
      Required    : Yes
      Min         : -180.0
      Max         : 180.0
      Description : WGS-84 longitude of the destination point.

    Field: destination.addressLine
      Type        : string
      Required    : No
      Max Length  : 255 characters
      Description : Human-readable address of the destination. Used for audit
                    logging and display purposes.

  Field: scheduledAppointmentTime
    Type        : string
    Required    : Yes
    Format      : ISO 8601 date-time with timezone offset,
                  e.g. "2025-08-15T14:30:00+05:30"
    Constraints : Must be a valid, parseable ISO 8601 datetime. Must not be
                  in the past at the time of the request (validated against
                  server clock with a 60-second tolerance for clock skew).
    Description : The confirmed scheduled time of the appointment (pickup or
                  drop). The suggested start time is back-calculated from this
                  value using the Map API route duration and traffic delay.

  Field: revisedEta
    Type        : (ignored if supplied)
    Required    : No
    Constraints : If present in the request body, this field is silently
                  ignored. The revised ETA is always system-derived (BR-5).
    Description : Callers must not supply this field. It is documented here
                  only to clarify that any caller-supplied value will be
                  discarded.


3.5 Example Request

  POST /api/v1/map/suggested-start-time
  Authorization: Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9...
  Content-Type: application/json
  X-Correlation-ID: corr-20250815-001

  {
    "appointmentId": "550e8400-e29b-41d4-a716-446655440000",
    "appointmentType": "drop",
    "origin": {
      "latitude": 25.2048,
      "longitude": 55.2708,
      "addressLine": "Dubai International Airport, Terminal 3, Dubai, UAE"
    },
    "destination": {
      "latitude": 25.1972,
      "longitude": 55.2744,
      "addressLine": "Burj Khalifa, Downtown Dubai, UAE"
    },
    "scheduledAppointmentTime": "2025-08-15T14:30:00+04:00"
  }


------------------------------------------------------------------------
SECTION 4: RESPONSE SPECIFICATION
------------------------------------------------------------------------

4.1 HTTP 200 OK — Successful Computation

  Description : Suggested start time (and vehicle departure time for drop
                appointments) and revised ETA have been successfully computed
                and persisted.

  Response Body Schema:

  Field: appointmentId
    Type        : string (UUID)
    Description : Echo of the appointment ID from the request.

  Field: appointmentType
    Type        : string (enum: "pickup", "drop")
    Description : Echo of the appointment type from the request.

  Field: suggestedStartTime
    Type        : string (ISO 8601 date-time with timezone)
    Description : The computed time at which the chauffeur should begin the
                  pickup or drop activity. Derived by subtracting the Map API
                  route duration and traffic delay from the scheduled
                  appointment time.
    Read-Only   : Yes (system-computed)

  Field: suggestedDepartureTime
    Type        : string (ISO 8601 date-time with timezone) or null
    Description : The computed time at which the vehicle should depart to
                  reach the destination on time. Populated only when
                  appointmentType is "drop". Null or absent for "pickup"
                  appointments (BR-3, BR-4).
    Read-Only   : Yes (system-computed)

  Field: revisedEta
    Type        : string (ISO 8601 date-time with timezone)
    Description : System-derived revised estimated time of arrival based on
                  current Map API traffic data. Always present. Read-only;
                  never accepted as caller input (BR-5).
    Read-Only   : Yes (system-computed)

  Field: routeDurationSeconds
    Type        : integer
    Description : Raw route duration in seconds as returned by the Map API,
                  before traffic adjustment. Included for transparency and
                  downstream use.

  Field: trafficDelaySeconds
    Type        : integer
    Description : Additional delay in seconds due to live traffic conditions
                  as returned by the Map API.

  Field: computedAt
    Type        : string (ISO 8601 date-time with timezone)
    Description : Server timestamp at which the computation was performed.

  Field: correlationId
    Type        : string
    Description : Correlation ID used for this request, either caller-supplied
                  or system-generated.

  Example Response (drop appointment):

    {
      "appointmentId": "550e8400-e29b-41d4-a716-446655440000",
      "appointmentType": "drop",
      "suggestedStart

ENDPOINT: POST /api/v1/drop-trips/{tripId}/arrival-images

Source Requirement ID: SER-010-020-117
Source Activity ID: SER-010-020-117

--------------------------------------------------------------------------------
1. ENDPOINT OVERVIEW
--------------------------------------------------------------------------------

Path            : /api/v1/drop-trips/{tripId}/arrival-images
HTTP Method     : POST
Summary         : Upload post-arrival exterior and interior vehicle images at the drop location; persists to VehicleConditionReport for drop leg.
Description     : Allows the chauffeur assigned to a specific drop trip to upload exterior and interior vehicle images upon arrival at the drop destination. The uploaded images are persisted immutably in the image storage service, linked to the drop trip record, and recorded in the audit trail. Successful upload unblocks the downstream workflow step SER-010-020-118 (e.g. OTP generation or trip completion).

--------------------------------------------------------------------------------
2. REQUEST SPECIFICATION
--------------------------------------------------------------------------------

2a. Request Headers

Header Name         : Authorization
Required            : Yes
Format              : Bearer <JWT token>
Description         : OAuth2 / OIDC Bearer JWT. Must be a valid, non-expired token issued by the authorised identity provider. The token sub claim is used to identify the chauffeur.

Header Name         : Content-Type
Required            : Yes
Allowed Value       : multipart/form-data
Description         : The request body must be submitted as multipart form data to support binary image file uploads.

Header Name         : X-Correlation-ID
Required            : Recommended
Format              : UUID v4 string
Description         : Client-supplied unique identifier for the request. Used by the server to detect retries within the deduplication window and to correlate log entries across services. If omitted, the server generates one internally.

Header Name         : X-Request-ID
Required            : No
Format              : String, max 64 characters
Description         : Optional client-generated request identifier for tracing purposes.

--------------------------------------------------------------------------------

2b. Path Parameters

Parameter Name  : tripId
Location        : Path
Type            : String
Required        : Yes
Format          : UUID v4
Description     : The unique identifier of the drop trip for which arrival images are being uploaded.
Validation      : Must be a valid UUID v4 format. Must correspond to an existing drop trip record in the system.
Example         : 7f3e2a1b-4c5d-4e6f-8a9b-0c1d2e3f4a5b

--------------------------------------------------------------------------------

2c. Query Parameters

None defined for this endpoint.

--------------------------------------------------------------------------------

2d. Request Body Schema

Content-Type    : multipart/form-data

Field Name      : exteriorImages
Type            : Array of binary file parts (multipart file upload)
Required        : Yes
Min Items       : 1
Max Items       : 10 (configurable per deployment policy)
Permitted Formats : JPEG (image/jpeg), PNG (image/png)
Max File Size   : 10 MB per individual image file
Description     : One or more exterior vehicle images captured at the drop destination. Each part must be a valid image file conforming to the permitted format and size constraints.
Validation Rules:
  - At least one exterior image must be present (BR-3).
  - Each file must be of type image/jpeg or image/png (BR-4).
  - Each file must not exceed 10 MB (BR-4).
  - File content must be a valid, non-corrupt image binary.

Field Name      : interiorImages
Type            : Array of binary file parts (multipart file upload)
Required        : Yes
Min Items       : 1
Max Items       : 10 (configurable per deployment policy)
Permitted Formats : JPEG (image/jpeg), PNG (image/png)
Max File Size   : 10 MB per individual image file
Description     : One or more interior vehicle images captured at the drop destination. Each part must be a valid image file conforming to the permitted format and size constraints.
Validation Rules:
  - At least one interior image must be present (BR-3).
  - Each file must be of type image/jpeg or image/png (BR-4).
  - Each file must not exceed 10 MB (BR-4).
  - File content must be a valid, non-corrupt image binary.

--------------------------------------------------------------------------------
3. RESPONSE SPECIFICATION
--------------------------------------------------------------------------------

3a. HTTP 201 Created — Successful Upload

Description     : All images have been validated, persisted, the trip record updated, and the audit trail entry created. The downstream workflow step SER-010-020-118 is unblocked.

Response Body Schema:

Field Name                  : tripId
Type                        : String (UUID v4)
Description                 : The identifier of the drop trip for which images were uploaded.

Field Name                  : arrivalImagesCaptured
Type                        : Boolean
Description                 : Confirms that the arrival images have been successfully captured and linked to the trip record. Always true on a 201 response.

Field Name                  : exteriorImageUrls
Type                        : Array of String (URL)
Description                 : Storage URLs or keys for each persisted exterior image.

Field Name                  : interiorImageUrls
Type                        : Array of String (URL)
Description                 : Storage URLs or keys for each persisted interior image.

Field Name                  : uploadedAt
Type                        : String (ISO 8601 datetime, UTC)
Description                 : Server-side timestamp at which the images were persisted.

Field Name                  : uploadedByChauffeurId
Type                        : String (UUID v4)
Description                 : The identity of the chauffeur who performed the upload, extracted from the JWT sub claim.

Field Name                  : correlationId
Type                        : String (UUID v4)
Description                 : The correlation ID associated with this request, either supplied by the client or generated by the server.

Example Response Payload:

tripId                  : 7f3e2a1b-4c5d-4e6f-8a9b-0c1d2e3f4a5b
arrivalImagesCaptured   : true
exteriorImageUrls       :
  - https://storage.example.com/drop-trips/7f3e2a1b/arrival/exterior/img_001.jpg
  - https://storage.example.com/drop-trips/7f3e2a1b/arrival/exterior/img_002.jpg
interiorImageUrls       :
  - https://storage.example.com/drop-trips/7f3e2a1b/arrival/interior/img_001.jpg
uploadedAt              : 2025-06-15T14:32:00Z
uploadedByChauffeurId   : a1b2c3d4-e5f6-7890-abcd-ef1234567890
correlationId           : c9d8e7f6-a5b4-3c2d-1e0f-9a8b7c6d5e4f

--------------------------------------------------------------------------------

3b. HTTP 400 Bad Request — Malformed Request

Description     : The request is syntactically malformed, missing required headers, or the path parameter is not a valid UUID.

Response Body Schema:

Field Name      : errorCode
Type            : String
Value           : INVALID_REQUEST

Field Name      : message
Type            : String
Description     : Human-readable description of the malformed request.

Field Name      : correlationId
Type            : String (UUID v4)

Example Response Payload:

errorCode       : INVALID_REQUEST
message         : The tripId path parameter must be a valid UUID v4.
correlationId   : c9d8e7f6-a5b4-3c2d-1e0f-9a8b7c6d5e4f

--------------------------------------------------------------------------------

3c. HTTP 401 Unauthorized — Authentication Failure

Description     : The Bearer JWT token is absent, expired, or invalid.

Response Body Schema:

Field Name      : errorCode
Type            : String
Value           : UNAUTHORIZED

Field Name      : message
Type            : String
Description     : Human-readable description of the authentication failure.

Field Name      : correlationId
Type            : String (UUID v4)

Example Response Payload:

errorCode       : UNAUTHORIZED
message         : Authentication token is missing or invalid.
correlationId   : c9d8e7f6-a5b4-3c2d-1e0f-9a8b7c6d5e4f

--------------------------------------------------------------------------------

3d. HTTP 403 Forbidden — Authorization Failure

Description     : The authenticated user does not hold the CHAUFFEUR role, or is not the chauffeur assigned to the specified tripId (BR-5).

Response Body Schema:

Field Name      : errorCode
Type            : String
Value           : FORBIDDEN

Field Name      : message
Type            : String
Value           : You are not authorized to upload arrival images for this trip.

Field Name      : correlationId
Type            : String (UUID v4)

Example Response Payload:

errorCode       : FORBIDDEN
message         : You are not authorized to upload arrival images for this trip.
correlationId   : c9d8e7f6-a5b4-3c2d-1e0f-9a8b7c6d5e4f

--------------------------------------------------------------------------------

3e. HTTP 404 Not Found — Trip Not Found

Description     : No drop trip record exists for the provided tripId (BR-1).

Response Body Schema:

Field Name      : errorCode
Type            : String
Value           : TRIP_NOT_FOUND

Field Name      : message
Type            : String
Value           : Drop trip not found for the provided tripId.

Field Name      : correlationId
Type            : String (UUID v4)

Example Response Payload:

errorCode       : TRIP_NOT_FOUND
message         : Drop trip not found for the provided tripId.
correlationId   : c9d8e7f6-a5b4-3c2d-1e0f-9a8b7c6d5e4f

--------------------------------------------------------------------------------

3f. HTTP 409 Conflict — State Conflict or Duplicate Submission

Description     : Returned in two scenarios:
  Scenario A (BR-2): The trip is not in an arrival-eligible status (e.g. already completed, cancelled, or not yet started).
  Scenario B (BR-8): Arrival images have already been uploaded for this tripId and the configured policy is to reject duplicates.

Response Body Schema:

Field Name      : errorCode
Type            : String
Values          : INVALID_TRIP_STATUS (Scenario A) or DUPLICATE_ARRIVAL_IMAGES (Scenario B)

Field Name      : message
Type            : String
Description     : Human-readable description of the conflict.

Field Name      : correlationId
Type            : String (UUID v4)

Example Response Payload (Scenario A):

errorCode       : INVALID_TRIP_STATUS
message         : Arrival images cannot be uploaded for a trip in its current status.
correlationId   : c9d8e7f6-a5b4-3c2d-1e0f-9a8b7c6d5e4f

Example Response Payload (

ENDPOINT DESIGN DOCUMENT
=========================

Endpoint: Record Trip Delay Reason
-----------------------------------------------------------------------------


1. ENDPOINT IDENTIFICATION
---------------------------------------------------------------------------

Path            : /api/v1/trips/{tripId}/delay
HTTP Method     : PATCH
Summary         : Record a delay reason captured by the Pickup Coordinator
                  after a system-detected delay alert; updates delay flag and
                  delay reason on the Trip record.
Description     : This endpoint allows an authenticated Pickup Coordinator to
                  record a delay reason against an existing, active trip. The
                  operation persists the delay reason and delay status flag on
                  the trip record, appends an immutable audit log entry, and
                  asynchronously dispatches delay notifications to configured
                  downstream channels (ICP, WhatsApp, SMS, DBP, CRM). The
                  workflow is then advanced to the next activity step as
                  defined by the SER-010-020 process sequence. This endpoint
                  covers both the pre-chauffeur-assignment delay scenario
                  (SER-010-020-029) and the post-assignment delay scenario
                  (SER-010-020-086).
Source Activity IDs : SER-010-020-029, SER-010-020-086


2. REQUEST SPECIFICATION
---------------------------------------------------------------------------

2a. Request Headers
-------------------

Header Name       : Authorization
Required          : Yes
Format            : Bearer <JWT token>
Description       : OAuth2 / OIDC Bearer token issued by the authorised
                    identity provider. Must contain a valid role claim
                    identifying the caller as PICKUP_COORDINATOR. Token must
                    not be expired and must pass signature and issuer
                    validation.

Header Name       : Content-Type
Required          : Yes
Expected Value    : application/json
Description       : Request body must be submitted as JSON.

Header Name       : Accept
Required          : No
Expected Value    : application/json
Description       : Indicates the client expects a JSON response.

Header Name       : X-Correlation-ID
Required          : No
Format            : UUID v4 string
Description       : Optional caller-supplied correlation identifier for
                    distributed tracing. If not supplied, the system generates
                    one internally and includes it in the response.


2b. Path Parameters
-------------------

Parameter Name    : tripId
Location          : Path
Type              : String
Required          : Yes
Format            : Well-formed trip identifier (system-defined format,
                    e.g. UUID v4 or alphanumeric reference)
Description       : Unique identifier of the trip against which the delay
                    reason is to be recorded. Must correspond to an existing
                    trip record in the data store.
Validation Rules  :
  - Must not be null or empty.
  - Must conform to the system-defined trip identifier format.
  - Malformed values (wrong format, illegal characters) result in a 400
    Bad Request response before any data store lookup is attempted.


2c. Query Parameters
--------------------

None defined for this endpoint.


2d. Request Body Schema
-----------------------

Content-Type      : application/json
Required          : Yes

Field Name        : delayReason
Type              : String
Required          : Yes
Min Length        : 1 character (must not be blank or null)
Max Length        : 1000 characters (system-defined maximum to ensure data
                    integrity in downstream CRM and DBP systems)
Format            : Free-form text; no special character restrictions beyond
                    standard UTF-8 printable characters.
Description       : Human-readable explanation of the reason for the trip
                    delay, as captured by the Pickup Coordinator. This value
                    is persisted on the trip record, included in the audit
                    log, and propagated to CRM and DBP systems.
Validation Rules  :
  - Must be present in the request body.
  - Must not be null.
  - Must not be an empty string or a string containing only whitespace.
  - Must not exceed 1000 characters in length.
  - Violations of any of the above result in a 422 Unprocessable Entity
    response.

Example Request Body:
  {
    "delayReason": "Vehicle inspection overran due to unexpected mechanical
                    check requirement. Estimated additional delay of 30
                    minutes."
  }


3. RESPONSE SPECIFICATION
---------------------------------------------------------------------------

3a. HTTP 200 - Success (Delay Recorded)
----------------------------------------

Condition         : The delay reason was successfully persisted against the
                    trip record, the audit log entry was written, and
                    downstream notifications and integrations were triggered.
                    Also returned when an idempotency duplicate is detected
                    (same delay reason within the idempotency window) to
                    avoid re-processing.

Response Body Schema:

Field Name              : tripId
Type                    : String
Description             : The unique identifier of the trip.

Field Name              : delayReason
Type                    : String
Description             : The delay reason as persisted against the trip.

Field Name              : delayStatus
Type                    : Boolean / Enum
Description             : Updated delay status flag on the trip record,
                          indicating a delay has been recorded.

Field Name              : delayRecordedAt
Type                    : String (ISO 8601 datetime)
Description             : System timestamp at which the delay was recorded.

Field Name              : correlationId
Type                    : String (UUID)
Description             : Correlation identifier for tracing the request
                          through distributed systems.

Field Name              : message
Type                    : String
Description             : Human-readable confirmation message.

Example Response Payload (200):
  {
    "tripId": "a3f7c291-84b2-4e10-9c3d-1f2e3a4b5c6d",
    "delayReason": "Vehicle inspection overran due to unexpected mechanical
                    check requirement. Estimated additional delay of 30
                    minutes.",
    "delayStatus": "DELAYED",
    "delayRecordedAt": "2025-07-14T10:35:22Z",
    "correlationId": "d1e2f3a4-b5c6-7890-abcd-ef1234567890",
    "message": "Delay reason recorded successfully."
  }


3b. HTTP 400 - Bad Request
---------------------------

Condition         : The tripId path parameter is malformed or the request
                    structure is syntactically invalid (e.g. unparseable JSON
                    body, illegal characters in path parameter).

Response Body Schema:

Field Name              : errorCode
Type                    : String
Description             : Machine-readable error code.

Field Name              : errorMessage
Type                    : String
Description             : Human-readable description of the error.

Field Name              : correlationId
Type                    : String (UUID)
Description             : Correlation identifier for tracing.

Field Name              : timestamp
Type                    : String (ISO 8601 datetime)
Description             : Time at which the error was generated.

Example Response Payload (400):
  {
    "errorCode": "INVALID_REQUEST",
    "errorMessage": "The tripId path parameter is malformed or the request
                     body could not be parsed.",
    "correlationId": "d1e2f3a4-b5c6-7890-abcd-ef1234567890",
    "timestamp": "2025-07-14T10:35:22Z"
  }


3c. HTTP 401 - Unauthorised
----------------------------

Condition         : No Bearer token is present, the token has expired, the
                    token signature is invalid, or the issuer is not
                    recognised.

Response Body Schema:

Field Name              : errorCode
Type                    : String
Description             : Machine-readable error code.

Field Name              : errorMessage
Type                    : String
Description             : Human-readable description of the authentication
                          failure.

Field Name              : correlationId
Type                    : String (UUID)
Description             : Correlation identifier for tracing.

Field Name              : timestamp
Type                    : String (ISO 8601 datetime)
Description             : Time at which the error was generated.

Example Response Payload (401):
  {
    "errorCode": "UNAUTHORISED",
    "errorMessage": "Authentication failed. A valid Bearer token is required.",
    "correlationId": "d1e2f3a4-b5c6-7890-abcd-ef1234567890",
    "timestamp": "2025-07-14T10:35:22Z"
  }


3d. HTTP 403 - Forbidden
-------------------------

Condition         : The caller is authenticated but does not hold the
                    PICKUP_COORDINATOR role as required by BR-5. The JWT is
                    valid but the role claim does not match the permitted
                    roles list for this operation.

Response Body Schema:

Field Name              : errorCode
Type                    : String
Description             : Machine-readable error code.

Field Name              : errorMessage
Type                    : String
Description             : Human-readable description of the authorisation
                          failure.

Field Name              : correlationId
Type                    : String (UUID)
Description             : Correlation identifier for tracing.

Field Name              : timestamp
Type                    : String (ISO 8601 datetime)
Description             : Time at which the error was generated.

Example Response Payload (403):
  {
    "errorCode": "FORBIDDEN",
    "errorMessage": "Access denied. Only Pickup Coordinators are permitted
                     to record a delay reason.",
    "correlationId": "d1e2f3a4-b5c6-7890-abcd-ef1234567890",
    "timestamp": "2025-07-14T10:35:22Z"
  }


3e. HTTP 404 - Not Found
-------------------------

Condition         : The tripId path parameter is well-formed but does not
                    correspond to any existing trip record in the data store
                    (BR-1).

Response Body Schema:

Field Name              : errorCode
Type                    : String
Description             : Machine-readable error code.

Field Name              : errorMessage
Type                    : String
Description             : Human-readable description of the not-found
                          condition.

Field Name              : correlationId
Type                    : String (UUID)
Description             : Correlation identifier for tracing.

Field Name              : timestamp
Type                    : String (ISO 8601 datetime)
Description             : Time at which the error was generated.

Example Response Payload (404):
  {
    "errorCode": "TRIP_NOT_FOUND",
    "errorMessage": "Trip not found for the provided tripId.",
    "correlationId": "d1e2f3a4-b5c6-7890-abcd-ef1234567890",
    "timestamp": "2025-07-14T10:35:22Z"
  }


3f. HTTP 409 - Conflict
------------------------

Condition         : The trip identified by tripId exists but is in a
                    COMPLETED or CANCELLED state and is therefore ineligible
                    to receive a delay update (BR-2).

Response Body Schema:

Field Name              : errorCode
Type                    : String
Description             : Machine-readable error code.

Field Name              : errorMessage
Type                    : String
Description             : Human-readable description of the conflict.

Field Name              : tripStatus
Type                    : String
Description             : The current status of the trip at the time of the
                          request, to assist the caller in understanding the
                          conflict.

Field Name              : correlationId
Type                    : String (UUID)
Description             : Correlation identifier for tracing.

Field Name              : timestamp
Type                    : String (ISO 8601 datetime)
Description             : Time at which the error was generated.

Example Response Payload (409):
  {
    "errorCode": "TRIP_INELIGIBLE_FOR_DELAY",
    "errorMessage": "Delay cannot be recorded for a trip that is already
                     completed or cancelled.",
    "

ENDPOINT DESIGN DOCUMENT
=========================

Endpoint: POST /api/v1/map/route
Source Requirements: SER-010-020-083, SER-010-020-113


------------------------------------------------------------------------
SECTION 1 - ENDPOINT OVERVIEW
------------------------------------------------------------------------

Path            : /api/v1/map/route
HTTP Method     : POST
Summary         : Compute and return a full route between a chauffeur's live
                  location and a destination (dealership or customer location).
Description     : This endpoint accepts an origin coordinate pair (chauffeur
                  live location), a destination coordinate pair, and an
                  appointment identifier. It invokes an external mapping
                  provider to compute the route polyline, waypoints, step-by-
                  step directions, and estimated time of arrival (ETA). The
                  computed route is returned to the Chauffeur mobile application
                  for display during an active trip. The ETA is persisted
                  against the appointment tracking record and pushed
                  asynchronously to the Pickup Coordinator dashboard. This
                  endpoint is used during two appointment stages:
                  SER-010-020-083 (chauffeur en route to dealership) and
                  SER-010-020-113 (chauffeur en route with customer).


------------------------------------------------------------------------
SECTION 2 - REQUEST SPECIFICATION
------------------------------------------------------------------------

2.1 Request Headers
-------------------

Header Name       : Authorization
Required          : Yes
Format            : Bearer <JWT token>
Description       : OAuth2 / OIDC Bearer token. Must be a valid, non-expired
                    JWT signed by the authorised issuer. Token must carry the
                    CHAUFFEUR or INTEGRATION_SERVICE role claim and the
                    chauffeur subject identifier (sub).

Header Name       : Content-Type
Required          : Yes
Allowed Value     : application/json
Description       : Request body must be JSON-encoded.

Header Name       : Accept
Required          : No (defaults to application/json)
Allowed Value     : application/json
Description       : Indicates the expected response media type.

Header Name       : X-Correlation-ID
Required          : No (recommended)
Format            : UUID v4 string
Description       : Caller-supplied correlation identifier for distributed
                    tracing. If absent, the system generates one internally
                    and includes it in the response.

Header Name       : X-Request-ID
Required          : No
Format            : UUID v4 string
Description       : Caller-supplied request identifier for deduplication
                    logging. Not used for idempotency enforcement.


2.2 Path Parameters
-------------------

None.


2.3 Query Parameters
--------------------

None.


2.4 Request Body Schema
-----------------------

Content-Type: application/json

Root Object Fields:

Field Name      : appointmentId
Type            : string
Required        : Yes
Format          : UUID v4
Min Length      : 36 characters
Max Length      : 36 characters
Regex           : ^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-4[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$
Description     : Unique identifier of the active appointment for which the
                  route is being computed. Must reference an existing,
                  non-cancelled, non-completed appointment assigned to the
                  requesting chauffeur.
Validation Rule : Must be a valid UUID v4. Must not be null or empty.

Field Name      : appointmentStage
Type            : string
Required        : Yes
Allowed Values  : SER-010-020-083, SER-010-020-113
Description     : The current stage of the appointment. Determines which route
                  segment is computed. SER-010-020-083 represents the chauffeur
                  en route to the dealership; SER-010-020-113 represents the
                  chauffeur en route with the customer. Any other value is
                  rejected.
Validation Rule : Must be one of the two enumerated values. Must not be null
                  or empty.

Field Name      : origin
Type            : object
Required        : Yes
Description     : Represents the chauffeur's current live location (origin
                  of the route).

  Nested Field  : origin.latitude
  Type          : number (double)
  Required      : Yes
  Minimum       : -90.0 (inclusive)
  Maximum       : 90.0 (inclusive)
  Description   : Latitude of the chauffeur's current position.
  Validation    : Must be a finite numeric value within [-90, 90]. Null,
                  absent, NaN, or out-of-range values are rejected.

  Nested Field  : origin.longitude
  Type          : number (double)
  Required      : Yes
  Minimum       : -180.0 (inclusive)
  Maximum       : 180.0 (inclusive)
  Description   : Longitude of the chauffeur's current position.
  Validation    : Must be a finite numeric value within [-180, 180]. Null,
                  absent, NaN, or out-of-range values are rejected.

Field Name      : destination
Type            : object
Required        : Yes
Description     : Represents the target location (dealership or customer
                  address) to which the route is computed.

  Nested Field  : destination.latitude
  Type          : number (double)
  Required      : Yes
  Minimum       : -90.0 (inclusive)
  Maximum       : 90.0 (inclusive)
  Description   : Latitude of the destination.
  Validation    : Must be a finite numeric value within [-90, 90]. Null,
                  absent, NaN, or out-of-range values are rejected.

  Nested Field  : destination.longitude
  Type          : number (double)
  Required      : Yes
  Minimum       : -180.0 (inclusive)
  Maximum       : 180.0 (inclusive)
  Description   : Longitude of the destination.
  Validation    : Must be a finite numeric value within [-180, 180]. Null,
                  absent, NaN, or out-of-range values are rejected.

Note on ETA in Request: Any caller-supplied ETA value included in the request
payload is silently ignored. ETA is a read-only derived value computed
exclusively by the mapping provider (BR-5).


2.5 Example Request Body
------------------------

{
  "appointmentId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
  "appointmentStage": "SER-010-020-083",
  "origin": {
    "latitude": 51.507351,
    "longitude": -0.127758
  },
  "destination": {
    "latitude": 51.515419,
    "longitude": -0.141099
  }
}


------------------------------------------------------------------------
SECTION 3 - RESPONSE SPECIFICATION
------------------------------------------------------------------------

3.1 HTTP 200 - Success
----------------------

Description: Route computation succeeded. The route polyline, waypoints,
step-by-step directions, and ETA are returned. The route and ETA have been
persisted against the appointment tracking record.

Response Body Schema:

Field Name          : requestId
Type                : string (UUID v4)
Description         : Correlation identifier for this request/response cycle.

Field Name          : appointmentId
Type                : string (UUID v4)
Description         : Echo of the appointment ID from the request.

Field Name          : appointmentStage
Type                : string
Description         : Echo of the appointment stage from the request.

Field Name          : route
Type                : object
Description         : Container for all computed route data.

  Nested Field      : route.polyline
  Type              : string
  Description       : Encoded polyline string representing the full route
                      geometry (Google Encoded Polyline Algorithm or provider
                      equivalent). Used for map rendering on the chauffeur app.

  Nested Field      : route.distanceMetres
  Type              : integer
  Description       : Total route distance in metres.

  Nested Field      : route.durationSeconds
  Type              : integer
  Description       : Estimated travel duration in seconds under current
                      traffic conditions. This is the raw duration value from
                      the mapping provider.

  Nested Field      : route.waypoints
  Type              : array of objects
  Description       : Ordered list of waypoints along the route. May be empty
                      if the route is a direct origin-to-destination path.

    Waypoint Field  : sequence
    Type            : integer
    Description     : 1-based ordering index of the waypoint.

    Waypoint Field  : latitude
    Type            : number (double)
    Description     : Latitude of the waypoint.

    Waypoint Field  : longitude
    Type            : number (double)
    Description     : Longitude of the waypoint.

    Waypoint Field  : label
    Type            : string
    Description     : Human-readable label for the waypoint (e.g. "Via A40").
                      May be null if no label is available.

  Nested Field      : route.steps
  Type              : array of objects
  Description       : Ordered list of step-by-step navigation instructions.

    Step Field      : sequence
    Type            : integer
    Description     : 1-based ordering index of the step.

    Step Field      : instruction
    Type            : string
    Description     : Human-readable navigation instruction (e.g. "Turn left
                      onto Baker Street").

    Step Field      : distanceMetres
    Type            : integer
    Description     : Distance covered in this step, in metres.

    Step Field      : durationSeconds
    Type            : integer
    Description     : Estimated duration for this step, in seconds.

    Step Field      : startLatitude
    Type            : number (double)
    Description     : Latitude at the start of this step.

    Step Field      : startLongitude
    Type            : number (double)
    Description     : Longitude at the start of this step.

Field Name          : eta
Type                : object
Description         : Read-only ETA information derived from the mapping
                      provider. This object must not be modified by the caller.

  Nested Field      : eta.etaSeconds
  Type              : integer
  Description       : Estimated time of arrival expressed as seconds from the
                      time of computation.

  Nested Field      : eta.etaTimestamp
  Type              : string (ISO 8601 UTC datetime)
  Format            : yyyy-MM-ddTHH:mm:ssZ
  Description       : Absolute UTC datetime at which the chauffeur is expected
                      to arrive at the destination.

  Nested Field      : eta.computationTimestamp
  Type              : string (ISO 8601 UTC datetime)
  Format            : yyyy-MM-ddTHH:mm:ssZ
  Description       : UTC datetime at which the route and ETA were computed
                      by the system.

Field Name          : origin
Type                : object
Description         : Echo of the origin coordinates used for computation.

  Nested Field      : origin.latitude
  Type              : number (double)

  Nested Field      : origin.longitude
  Type              : number (double)

Field Name          : destination
Type                : object
Description         : Echo of the destination coordinates used for computation.

  Nested Field      : destination.latitude
  Type              : number (double)

  Nested Field      : destination.longitude
  Type              : number (double)

Example 200 Response Body:

{
  "requestId": "a1b2c3d4-e5f6-4789-abcd-ef0123456789",
  "appointmentId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
  "appointmentStage": "SER-010-020-083

ENDPOINT: POST /api/v1/otp-verifications/generate

SOURCE REQUIREMENT IDs: SER-010-020-034, SER-010-020-047

================================================================================
SECTION 1 — ENDPOINT OVERVIEW
================================================================================

Path            : /api/v1/otp-verifications/generate
HTTP Method     : POST
Summary         : Generate a new OTP for a given appointment reference and action type; returns OTP record ID and dispatches OTP to customer via NotificationService.
Description     : This endpoint generates a cryptographically random One-Time Password (OTP) tied to a specific appointment record. It is invoked as part of the appointment booking and rescheduling workflow (stage SER-010-020). Upon successful generation, the OTP is persisted against the appointment, any previously active OTP for the same appointment is invalidated, and the OTP is dispatched asynchronously to the customer via all configured peripheral channels (ICP, WhatsApp, SMS). A controlled override mechanism is supported whereby a coordinator may supply an override reason to force OTP regeneration outside the standard automated flow. An immutable audit trail entry is created for every invocation. OTP generation is not idempotent by design; each invocation issues a fresh OTP.

================================================================================
SECTION 2 — REQUEST SPECIFICATION
================================================================================

2.1 Request Headers
--------------------
Header Name       : Authorization
Required          : Yes
Format            : Bearer <JWT token>
Description       : OAuth2 / OIDC Bearer token. Must be a valid, non-expired JWT signed by the trusted issuer. The sub claim is used as the actorId for audit and OTP record attribution.

Header Name       : Content-Type
Required          : Yes
Allowed Value     : application/json
Description       : Request body must be JSON-encoded.

Header Name       : X-Correlation-ID
Required          : No (Recommended)
Format            : UUID v4
Description       : Caller-supplied correlation identifier for distributed tracing. If absent, the system generates one internally and includes it in the response.

Header Name       : X-Idempotency-Key
Required          : No
Format            : UUID v4
Description       : Optional idempotency hint. Because OTP generation is not idempotent by design, this key is used only to detect in-flight duplicate requests within the same generation window and return the existing active OTP rather than creating a second one. It does not guarantee full idempotency across separate invocations.

2.2 Path Parameters
--------------------
None.

2.3 Query Parameters
--------------------
None.

2.4 Request Body Schema
------------------------
Content-Type: application/json

Field Name      : appointmentId
Type            : string
Required        : Yes
Format          : UUID v4
Min Length      : 36
Max Length      : 36
Pattern         : ^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-4[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$
Description     : The unique identifier of the appointment for which the OTP is being generated. Must reference an existing appointment record in an OTP-eligible state.
Validation Rule : Must be a well-formed UUID v4. Must not be null or empty. Must correspond to an existing appointment record.

Field Name      : actionType
Type            : string
Required        : Yes
Allowed Values  : BOOKING_CONFIRMATION, RESCHEDULING_CONFIRMATION
Description     : Indicates the workflow action that is triggering OTP generation. Drives the downstream workflow state transition target (SER-010-020-035 for coordinator flow, SER-010-020-048 or SER-010-020-134 for automated flow).
Validation Rule : Must be one of the enumerated values. Case-sensitive. Must not be null or empty.

Field Name      : overrideReason
Type            : string
Required        : Conditionally Required — mandatory when isControlledOverride is true; must be omitted or null when isControlledOverride is false.
Min Length      : 10
Max Length      : 500
Description     : Human-readable justification for invoking a controlled override OTP generation outside the standard automated flow. Persisted in both the OTP record and the audit trail.
Validation Rule : When isControlledOverride is true, this field must be present and contain between 10 and 500 non-whitespace characters. Must not contain script injection characters (angle brackets, script tags). Sanitised before persistence.

Field Name      : isControlledOverride
Type            : boolean
Required        : No
Default         : false
Description     : Flag indicating whether this invocation is a controlled override (e.g. coordinator manually triggering OTP regeneration outside the automated flow). When set to true, overrideReason becomes mandatory.
Validation Rule : Must be a boolean (true or false). If absent, defaults to false.

Example Request Body — Standard Automated Flow:

appointmentId     : "a3f1c2d4-5678-4abc-89de-f01234567890"
actionType        : "BOOKING_CONFIRMATION"
isControlledOverride : false

Example Request Body — Controlled Override Flow:

appointmentId        : "a3f1c2d4-5678-4abc-89de-f01234567890"
actionType           : "RESCHEDULING_CONFIRMATION"
isControlledOverride : true
overrideReason       : "Customer reported non-receipt of OTP after two automated attempts. Coordinator manually triggering regeneration."

================================================================================
SECTION 3 — RESPONSE SPECIFICATION
================================================================================

3.1 HTTP 201 — Created (OTP Generated Successfully, All Notifications Dispatched)
-----------------------------------------------------------------------------------
Condition : OTP generated, persisted, audit entry written, and all three notification channels accepted the dispatch request.

Response Body Fields:

Field Name                    : otpRecordId
Type                          : string (UUID v4)
Description                   : Unique identifier of the newly created OTP record in the otp_verifications table.

Field Name                    : appointmentId
Type                          : string (UUID v4)
Description                   : Echo of the appointment identifier from the request.

Field Name                    : status
Type                          : string
Value                         : ACTIVE
Description                   : Current status of the generated OTP.

Field Name                    : expiresAt
Type                          : string (ISO 8601 datetime with timezone)
Description                   : Timestamp at which the OTP will expire. Computed as generationTimestamp plus the configured OTP TTL.

Field Name                    : generatedAt
Type                          : string (ISO 8601 datetime with timezone)
Description                   : Timestamp at which the OTP was generated (system clock).

Field Name                    : workflowStepAdvancedTo
Type                          : string
Description                   : The BRD activity step identifier to which the appointment workflow has been advanced (e.g. SER-010-020-035, SER-010-020-048, or SER-010-020-134).

Field Name                    : notificationDispatchStatus
Type                          : object
Description                   : Per-channel dispatch status summary.

  Sub-field: icp
  Type      : string
  Values    : DISPATCHED, FAILED, QUEUED_FOR_RETRY
  Description: Dispatch outcome for the ICP channel.

  Sub-field: whatsApp
  Type      : string
  Values    : DISPATCHED, FAILED, QUEUED_FOR_RETRY
  Description: Dispatch outcome for the WhatsApp channel.

  Sub-field: sms
  Type      : string
  Values    : DISPATCHED, FAILED, QUEUED_FOR_RETRY
  Description: Dispatch outcome for the SMS channel.

Field Name                    : correlationId
Type                          : string (UUID v4)
Description                   : Correlation identifier for distributed tracing. Either echoed from X-Correlation-ID header or system-generated.

Example 201 Response:

otpRecordId            : "b7e2d1f3-9012-4def-a345-678901234567"
appointmentId          : "a3f1c2d4-5678-4abc-89de-f01234567890"
status                 : "ACTIVE"
expiresAt              : "2025-07-15T10:45:00Z"
generatedAt            : "2025-07-15T10:30:00Z"
workflowStepAdvancedTo : "SER-010-020-035"
notificationDispatchStatus:
  icp       : "DISPATCHED"
  whatsApp  : "DISPATCHED"
  sms       : "DISPATCHED"
correlationId          : "c9f3e2a1-1234-4bcd-8ef0-123456789abc"


3.2 HTTP 207 — Multi-Status (OTP Generated, Partial Notification Failure)
---------------------------------------------------------------------------
Condition : OTP generated and persisted successfully, audit entry written, but one or more notification channels failed to dispatch and have been enqueued for retry.
Business Rule Reference: BR-8.

Response Body Fields: Same structure as 201 with the following differences:

Field Name                    : status
Value                         : ACTIVE

Field Name                    : notificationDispatchStatus
Description                   : At least one channel will show FAILED or QUEUED_FOR_RETRY.

Field Name                    : warnings
Type                          : array of objects
Description                   : List of per-channel warning entries describing the failure and retry schedule.

  Sub-field: channel
  Type      : string
  Description: The channel that failed (ICP, WHATSAPP, SMS).

  Sub-field: errorCode
  Type      : string
  Description: Internal error code for the channel failure.

  Sub-field: retryScheduled
  Type      : boolean
  Description: Whether a retry has been enqueued.

  Sub-field: nextRetryAt
  Type      : string (ISO 8601)
  Description: Estimated timestamp of the first retry attempt.

Example 207 Response:

otpRecordId            : "b7e2d1f3-9012-4def-a345-678901234567"
appointmentId          : "a3f1c2d4-5678-4abc-89de-f01234567890"
status                 : "ACTIVE"
expiresAt              : "2025-07-15T10:45:00Z"
generatedAt            : "2025-07-15T10:30:00Z"
workflowStepAdvancedTo : "SER-010-020-035"
notificationDispatchStatus:
  icp       : "DISPATCHED"
  whatsApp  : "QUEUED_FOR_RETRY"
  sms       : "DISPATCHED"
warnings:
  - channel       : "WHATSAPP"
    errorCode     : "NOTIF-503"
    retryScheduled: true
    nextRetryAt   : "2025-07-15T10:31:30Z"
correlationId          : "c9f3e2a1-1234-4bcd-8ef0-123456789abc"


3.3 HTTP 400 — Bad Request
---------------------------
Condition : Request payload fails structural or semantic validation (missing required fields, malformed UUID, invalid enum value, missing overrideReason when isControlledOverride is true).
Business Rule Reference: BR-4.

Response Body Fields:

Field Name    : errorCode
Type          : string
Value         : VALIDATION_ERROR

Field Name    : message
Type          : string
Description   : Human-readable description of the validation failure.

Field Name    : fieldErrors
Type          : array of objects
Description   : Per-field validation error details.

  Sub-field: field
  Type      : string
  Description: The request field that failed validation.

  Sub-field: rejectedValue
  Type      : any
  Description: The value that was submitted and rejected.

  Sub-field: reason
  Type      : string
  Description: Explanation of why the value was rejected.

Field Name    : correlationId
Type          : string (UUID v4)

Example 400 Response — Missing overrideReason:

errorCode   : "VALIDATION_ERROR"
message     : "Override reason must be provided when invoking a controlled override OTP generation."
fieldErrors :
  - field         : "overrideReason"
    rejectedValue : null
    reason        : "Field is required when isControlledOverride is true. Minimum length is 10 characters."
correlationId : "c9f3e2a1-1234-4bcd-8ef0-123456789abc"

Example 400 Response — Malformed appointmentId:

errorCode   : "VALIDATION_ERROR"
message     : "Request payload contains invalid field values."
fieldErrors :
  - field         : "appointmentId"
    rejectedValue : "not-a-uuid"
    reason        : "Must be a valid UUID v4 format."
correlationId : "c9f3e2a1-1234-4bcd-8ef0-123456789abc"


3.4 HTTP 401 —

ENDPOINT DESIGN: POST /api/v1/otp-verifications/validate

================================================================================
SECTION 1: ENDPOINT IDENTIFICATION
================================================================================

Path            : /api/v1/otp-verifications/validate
HTTP Method     : POST
Summary         : Validate a submitted OTP value against the stored record for the
                  given appointment reference and action type; returns verification
                  status.
Description     : This endpoint accepts a caller-submitted OTP code alongside an
                  appointment or session reference and an action type context. It
                  verifies the submitted code against the stored OTP record, enforces
                  expiry and attempt-limit rules, advances the appointment or session
                  workflow state machine on success, emits a domain event for
                  downstream orchestration, and appends an immutable audit trail
                  entry for every invocation regardless of outcome.

                  The endpoint serves two distinct workflow contexts:
                  (a) Appointment booking confirmation gate (SER-010-020-035 /
                      SER-010-020-036): invoked by a Pickup Coordinator to confirm
                      the customer's identity before advancing to the revised slot
                      confirmation step.
                  (b) Vehicle handover confirmation gate (SER-010-020-121): invoked
                      by a Chauffeur who additionally captures the customer's
                      signature alongside the OTP to jointly record the handover
                      event.

Source Requirement IDs : SER-010-020-035, SER-010-020-036, SER-010-020-048,
                         SER-010-020-121
Source Activity IDs    : SER-010-020-035, SER-010-020-036, SER-010-020-048,
                         SER-010-020-121


================================================================================
SECTION 2: SECURITY REQUIREMENTS
================================================================================

2.1 Authentication
    Mechanism   : Bearer JWT (OAuth2 / OIDC)
    Header      : Authorization: Bearer <token>
    Validation  : The JWT signature, expiry (exp claim), issuer (iss claim), and
                  audience (aud claim) must all be verified by the API gateway or
                  the service's authentication middleware before the request reaches
                  business logic. Requests with missing, malformed, expired, or
                  invalid tokens must be rejected with HTTP 401.

2.2 Authorization
    Model       : Role-Based Access Control (RBAC) with ownership check.
    Permitted Roles:
        PICKUP_COORDINATOR  — valid for the booking confirmation context.
        CHAUFFEUR           — valid for the vehicle handover context.
    Ownership Check:
        The actor identified by the JWT sub claim must be associated with the
        referenced appointment or session in the system of record. A valid role
        alone is insufficient; the actor must be the assigned coordinator or
        chauffeur for that specific appointment. Requests where the actor is not
        associated with the referenced appointment must be rejected with HTTP 403.
    OAuth2 Scope Required: otp:validate

2.3 Rate Limiting
    Limit       : 10 requests per minute per appointment or session reference.
    Scope       : The rate limit key is the appointment/session reference value,
                  not the caller identity, to prevent brute-force OTP guessing
                  regardless of which authenticated actor submits the attempts.
    Enforcement : Enforced at the API gateway layer. Requests exceeding the limit
                  receive HTTP 429 with a Retry-After header indicating when the
                  window resets.
    Relationship to BR-4:
        The per-session failed-attempt counter (BR-4) is an application-level lock
        that persists across rate-limit windows. The rate limit provides an
        additional time-based throttle layer. Both controls operate independently.

2.4 Transport Security
    All traffic must be over TLS 1.2 or higher. Plain HTTP requests must be
    rejected or redirected.

2.5 OTP Comparison Security
    The submitted OTP value must be compared against the stored hash using a
    constant-time comparison function to prevent timing-based side-channel attacks.
    The raw OTP value must never be logged or stored in plaintext; only its hash
    is persisted.


================================================================================
SECTION 3: REQUEST SPECIFICATION
================================================================================

3.1 Request Headers

    Header Name       Required   Description
    ---------------   --------   ------------------------------------------------
    Authorization     Yes        Bearer JWT token. Format: "Bearer <token>".
                                 Missing or invalid token returns 401.
    Content-Type      Yes        Must be "application/json". Other values return
                                 400.
    X-Request-ID      No         Caller-supplied idempotency/correlation UUID.
                                 Logged in audit trail and included in response
                                 headers for tracing. If not supplied, the system
                                 generates one internally.
    X-Correlation-ID  No         Distributed tracing correlation identifier.
                                 Propagated to all downstream service calls.

3.2 Path Parameters
    None.

3.3 Query Parameters
    None.

3.4 Request Body Schema

    Content-Type: application/json

    The request body is a JSON object with the following fields:

    Field Name          Type     Required   Constraints / Validation Rules
    -----------------   ------   --------   -------------------------------------------
    appointmentId       string   Yes        Non-empty string. Represents the unique
                                            identifier of the appointment or session
                                            for which OTP validation is being
                                            requested. Must match a known appointment
                                            or session record in the system.
                                            Max length: 64 characters.
                                            Pattern: alphanumeric with hyphens,
                                            regex: ^[a-zA-Z0-9\-]{1,64}$
                                            Validation failure returns 400.

    otpValue            string   Yes        The OTP code submitted by the caller on
                                            behalf of the customer. Must be a numeric
                                            string of exactly 6 digits.
                                            Type: string (not integer, to preserve
                                            leading zeros).
                                            Pattern regex: ^\d{6}$
                                            Min length: 6, Max length: 6.
                                            Validation failure returns 400.

    actionType          string   Yes        Identifies the workflow context for this
                                            OTP validation. Permitted enum values:
                                            BOOKING_CONFIRMATION — booking gate
                                            (SER-010-020-035/036).
                                            VEHICLE_HANDOVER — handover gate
                                            (SER-010-020-121).
                                            Any other value returns 400.

    customerSignature   string   Conditional  Base64-encoded representation of the
                                            customer's signature image or signature
                                            token. Required when actionType is
                                            VEHICLE_HANDOVER (BR-6). Must be omitted
                                            or null when actionType is
                                            BOOKING_CONFIRMATION.
                                            Max length: 65536 characters (64 KB
                                            base64-encoded).
                                            Validation failure (missing when required,
                                            or present when not applicable) returns
                                            400.

3.5 Request Body Example — Booking Confirmation Context

    {
      "appointmentId": "APT-2024-00123456",
      "otpValue": "847291",
      "actionType": "BOOKING_CONFIRMATION"
    }

3.6 Request Body Example — Vehicle Handover Context

    {
      "appointmentId": "APT-2024-00123456",
      "otpValue": "391047",
      "actionType": "VEHICLE_HANDOVER",
      "customerSignature": "iVBORw0KGgoAAAANSUhEUgAA..."
    }


================================================================================
SECTION 4: RESPONSE SPECIFICATION
================================================================================

4.1 HTTP 200 — OTP Validated Successfully

    Returned when the submitted OTP matches the stored record, is within its
    validity window, the session is not locked, and the OTP has not been
    previously consumed. The OTP record is marked VERIFIED, the workflow state
    machine is advanced, and the domain event is emitted.

    Response Body Schema:

    Field Name          Type      Description
    -----------------   -------   -----------------------------------------------
    status              string    Always "SUCCESS" on a 200 response.
    message             string    Human-readable confirmation message.
    appointmentId       string    Echo of the appointment/session reference.
    otpReferenceId      string    Internal identifier of the OTP session record.
    verifiedAt          string    ISO 8601 UTC timestamp of verification.
                                  Format: yyyy-MM-ddTHH:mm:ss.SSSZ
    nextWorkflowStep    string    Identifier of the next workflow step the state
                                  machine has advanced to. Values:
                                  SER-010-020-036 for BOOKING_CONFIRMATION context.
                                  SER-010-020-122 for VEHICLE_HANDOVER context.
    handoverRecorded    boolean   Present and true only when actionType is
                                  VEHICLE_HANDOVER and the handover event has been
                                  jointly recorded. Omitted for BOOKING_CONFIRMATION.
    requestId           string    Echo of X-Request-ID (caller-supplied or
                                  system-generated).

    Example Response Body:

    {
      "status": "SUCCESS",
      "message": "OTP verified successfully. Workflow advanced.",
      "appointmentId": "APT-2024-00123456",
      "otpReferenceId": "OTP-SESSION-78901234",
      "verifiedAt": "2024-07-15T09:32:11.452Z",
      "nextWorkflowStep": "SER-010-020-036",
      "requestId": "req-a1b2c3d4-e5f6-7890-abcd-ef1234567890"
    }

    Response Headers:
    X-Request-ID    : Echo of the request correlation identifier.
    Content-Type    : application/json


4.2 HTTP 400 — Bad Request

    Returned when the request body fails structural or field-level validation
    before any business logic is executed.

    Causes:
    - Missing required fields (appointmentId, otpValue, actionType).
    - otpValue does not match ^\d{6}$.
    - appointmentId does not match the permitted pattern or exceeds max length.
    - actionType is not one of the permitted enum values.
    - customerSignature is missing when actionType is VEHICLE_HANDOVER.
    - customerSignature is present when actionType is BOOKING_CONFIRMATION.
    - Content-Type header is not application/json.
    - Request body is not valid JSON.

    Response Body Schema:

    Field Name    Type      Description
    -----------   -------   -----------------------------------------------
    status        string    Always "ERROR".
    errorCode     string    Machine-readable error code.
    message       string    Human-readable description of the validation error.
    fieldErrors   array     List of field-level validation failures. Each entry
                            contains:
                            field   (string) — name of the failing field.
                            reason  (string) — description of the failure.
    requestId     string    Correlation identifier.

    Example Response Body:

    {
      "status": "ERROR",
      "errorCode": "VALIDATION_FAILED",
      "message": "Request validation failed. Please correct the indicated fields.",
      "fieldErrors": [
        {
          "field": "otpValue",
          "reason": "Must be a 6-digit numeric string."
        }
      ],
      "requestId": "req-a1b2c3d4-e5f6-7890-abcd-ef1234567890"
    }


4.3 HTTP 401 — Unauthorized

    Returned when the Bearer JWT is absent, malformed, expired, or fails
    signature/issuer/audience validation.

    Example Response Body:

    {
      "status": "ERROR",
      "errorCode": "UNAUTHORIZED",
      "message": "Authentication required. Provide a valid Bearer token.",
      "requestId": "req-a1b2c3d4-e5f6-7890-abcd-ef1234567890"
    }


4.4 HTTP 403 — Forbidden

    Returned when the caller is authenticated but does not hold a permitted role
    (PICKUP_COORDINATOR or

ENDPOINT DESIGN: POST /api/v1/appointment-orchestration/initiate

================================================================================
SECTION 1: ENDPOINT IDENTIFICATION
================================================================================

Path                : /api/v1/appointment-orchestration/initiate
HTTP Method         : POST
Summary             : Initiate the appointment booking orchestration: accept appointment
                      payload from CRM and trigger chauffeur recommendation engine.
Description         : This endpoint accepts a structured appointment payload from an
                      authorised caller (e.g. Pickup Coordinator or Integration Service),
                      validates all mandatory and conditional fields, persists a new
                      appointment record, invokes the chauffeur recommendation engine
                      (SER-010-020-005) to assign a recommended chauffeur, appends an
                      immutable audit trail entry, and triggers downstream notification
                      and CRM integration services asynchronously. The endpoint returns
                      the created appointment reference along with allocation status and
                      recommendation outcome.

Source Requirement IDs : SER-010-020-003, SER-010-020-005


================================================================================
SECTION 2: SECURITY REQUIREMENTS
================================================================================

Authentication
    Mechanism       : Bearer JWT (OAuth2 / OIDC)
    Header          : Authorization: Bearer <token>
    Token must be a valid, non-expired JWT issued by the authorised identity provider.
    The token must carry verifiable role claims.

Authorisation
    Model           : Role-Based Access Control (RBAC)
    Permitted Roles : PICKUP_COORDINATOR, INTEGRATION_SERVICE, ADMIN
    Scope Required  : appointment:write
    Any caller whose role is not in the permitted roles list is rejected with HTTP 403.
    Role claims are extracted from the JWT payload; no caller-supplied role override
    is accepted.

Rate Limiting
    Policy          : Standard service-level rate limit (see COMMON_RATE_LIMITS).
    Exceeding the rate limit results in HTTP 429 Too Many Requests.

Transport Security
    All communication must occur over TLS 1.2 or higher.
    Plain HTTP requests must be rejected.

PII / Data Masking
    Contact reference fields must be supplied in authorised/masked or tokenised form.
    The system applies an additional masking/tokenisation pass before persisting or
    forwarding to any downstream service. Raw PII contact details must never be
    persisted or transmitted in plain form.


================================================================================
SECTION 3: REQUEST SPECIFICATION
================================================================================

3.1 Request Headers
--------------------------------------------------------------------------------

Header Name         : Authorization
Required            : Yes
Format              : Bearer <JWT token>
Description         : OAuth2/OIDC Bearer token for authentication and role extraction.

Header Name         : Content-Type
Required            : Yes
Allowed Value       : application/json
Description         : Request body must be JSON-encoded.

Header Name         : Accept
Required            : No (defaults to application/json)
Allowed Value       : application/json
Description         : Expected response content type.

Header Name         : X-Correlation-ID
Required            : No (recommended)
Format              : UUID v4 string
Description         : Caller-supplied correlation identifier for distributed tracing.
                      If not supplied, the system generates one and returns it in the
                      response header.

Header Name         : X-Request-Timestamp
Required            : No (recommended)
Format              : ISO 8601 UTC datetime string (e.g. 2025-07-15T10:30:00Z)
Description         : Caller-supplied request timestamp for audit and tracing purposes.


3.2 Path Parameters
--------------------------------------------------------------------------------

None. This endpoint does not accept path parameters.


3.3 Query Parameters
--------------------------------------------------------------------------------

None. This endpoint does not accept query parameters.


3.4 Request Body Schema
--------------------------------------------------------------------------------

Content-Type        : application/json
Root Object         : AppointmentInitiationRequest

All field-level validations are described below. Fields marked REQUIRED must be
present and non-null. Fields marked CONDITIONAL are required only when a specific
condition is met (noted inline).

--------------------------------------------------------------------------------
Field               : appointmentNumber
Type                : string
Required            : Yes
Min Length          : 1
Max Length          : 50
Format              : Alphanumeric, hyphens permitted; no special characters
Regex               : ^[A-Za-z0-9\-]{1,50}$
Description         : Unique appointment reference number supplied by the caller or
                      CRM system. Used as the primary idempotency key for duplicate
                      detection in conjunction with vehicle registration and pickup
                      datetime.
Business Rule Ref   : BR-1, BR-12, BR-15

--------------------------------------------------------------------------------
Field               : customerName
Type                : string
Required            : Yes
Min Length          : 1
Max Length          : 150
Format              : Free text; printable Unicode characters permitted
Description         : Full name of the customer associated with the appointment.
Business Rule Ref   : BR-1

--------------------------------------------------------------------------------
Field               : contactReference
Type                : string
Required            : Yes
Min Length          : 1
Max Length          : 100
Format              : Authorised/masked or tokenised contact reference; raw phone
                      numbers or email addresses in plain form are not permitted.
Regex               : Must not match a plain 10-digit phone pattern or a plain email
                      pattern; system enforces masking validation.
Description         : Masked or tokenised reference to the customer contact detail.
                      Raw PII must not be supplied. The system applies an additional
                      masking pass before persistence.
Business Rule Ref   : BR-1, BR-2

--------------------------------------------------------------------------------
Field               : vehicleRegistration
Type                : string
Required            : Yes
Min Length          : 1
Max Length          : 20
Format              : Alphanumeric, hyphens permitted
Regex               : ^[A-Za-z0-9\-]{1,20}$
Description         : Vehicle registration number. Must correspond to an active vehicle
                      record in the vehicle master data service.
Business Rule Ref   : BR-1, BR-5

--------------------------------------------------------------------------------
Field               : vehicleModel
Type                : string
Required            : Yes
Min Length          : 1
Max Length          : 100
Format              : Free text
Description         : Model name or identifier of the vehicle.
Business Rule Ref   : BR-1, BR-5

--------------------------------------------------------------------------------
Field               : pickupDateTime
Type                : string
Required            : Yes
Format              : ISO 8601 UTC datetime (e.g. 2025-08-01T09:00:00Z)
Constraint          : Must be a future timestamp relative to the time of request
                      submission. Timestamps equal to or earlier than the current
                      server time are rejected.
Description         : Scheduled pickup date and time.
Business Rule Ref   : BR-1, BR-3

--------------------------------------------------------------------------------
Field               : pickupAddress
Type                : object
Required            : Conditional — required if permittedArea is not provided.
                      At least one of pickupAddress or permittedArea must be present.
Description         : Structured address object for the pickup location.

    Sub-field       : line1
    Type            : string
    Required        : Yes (within pickupAddress if object is present)
    Max Length      : 200
    Description     : Primary address line.

    Sub-field       : line2
    Type            : string
    Required        : No
    Max Length      : 200
    Description     : Secondary address line (apartment, suite, etc.).

    Sub-field       : city
    Type            : string
    Required        : Yes (within pickupAddress if object is present)
    Max Length      : 100
    Description     : City name.

    Sub-field       : state
    Type            : string
    Required        : Yes (within pickupAddress if object is present)
    Max Length      : 100
    Description     : State or province.

    Sub-field       : postalCode
    Type            : string
    Required        : Yes (within pickupAddress if object is present)
    Max Length      : 20
    Regex           : ^[A-Za-z0-9\s\-]{3,20}$
    Description     : Postal or ZIP code.

    Sub-field       : country
    Type            : string
    Required        : Yes (within pickupAddress if object is present)
    Max Length      : 100
    Description     : Country name or ISO 3166-1 alpha-2 code.

Business Rule Ref   : BR-1, BR-4

--------------------------------------------------------------------------------
Field               : permittedArea
Type                : string
Required            : Conditional — required if pickupAddress is not provided.
Max Length          : 200
Description         : Named permitted area or zone for pickup when a full structured
                      address is not available.
Business Rule Ref   : BR-1

--------------------------------------------------------------------------------
Field               : dropServiceEnabled
Type                : boolean
Required            : Yes
Allowed Values      : true, false
Description         : Flag indicating whether a drop service is requested in addition
                      to pickup. When set to true, dropAddress, dropDate, and dropTime
                      become mandatory.
Business Rule Ref   : BR-4

--------------------------------------------------------------------------------
Field               : dropAddress
Type                : object
Required            : Conditional — required when dropServiceEnabled is true.
Description         : Structured address object for the drop-off location.
                      Sub-fields mirror the pickupAddress structure (line1, line2,
                      city, state, postalCode, country) with the same validations.
Business Rule Ref   : BR-4

--------------------------------------------------------------------------------
Field               : dropDate
Type                : string
Required            : Conditional — required when dropServiceEnabled is true.
Format              : ISO 8601 date (e.g. 2025-08-01)
Constraint          : Must be on or after the pickupDateTime date.
Description         : Scheduled drop-off date.
Business Rule Ref   : BR-4

--------------------------------------------------------------------------------
Field               : dropTime
Type                : string
Required            : Conditional — required when dropServiceEnabled is true.
Format              : ISO 8601 time (e.g. 14:30:00) or full ISO 8601 datetime
Constraint          : When combined with dropDate, the resulting datetime must be
                      after pickupDateTime.
Description         : Scheduled drop-off time.
Business Rule Ref   : BR-4

--------------------------------------------------------------------------------
Field               : jcNumber
Type                : string
Required            : No
Max Length          : 50
Format              : Alphanumeric, hyphens permitted
Regex               : ^[A-Za-z0-9\-]{0,50}$
Description         : Linked Job Card number, if available. Persisted against the
                      appointment record for downstream reference.
Business Rule Ref   : BR-9

--------------------------------------------------------------------------------
Field               : promisedDeliveryTime
Type                : string
Required            : No
Format              : ISO 8601 UTC datetime (e.g. 2025-08-01T17:00:00Z)
Description         : Promised vehicle delivery time, if available. Persisted against
                      the appointment record for downstream reference.
Business Rule Ref   : BR-9

--------------------------------------------------------------------------------
Field               : appointmentStatus
Type                : string
Required            : Yes
Allowed Values      : INITIATED
Description         : Initial status of the appointment as supplied by the caller.
                      The system will override internal allocation status independently.
Business Rule Ref   : BR-1, BR-8

--------------------------------------------------------------------------------
Field               : dealershipTag
Type                : string
Required            : No
Max Length          : 100
Description         : Dealership identifier tag used as an input to the chauffeur
                      recommendation engine scoring.
Business Rule Ref   : BR-6

--------------------------------------------------------------------------------

3.5 Request Body Example
--------------------------------------------------------------------------------

{
  "appointmentNumber": "APT-2025-00123",
  "customerName": "Rajesh Kumar",
  "contactReference": "MASKED-REF-7A3F9C",
  "vehicleRegistration": "MH12AB1234",
  "vehicleModel": "Toyota Camry",
  "pickupDateTime": "2025-08-15T09:00:00Z",
  "pickupAddress": {
    "line1": "45 Marine Drive",
    "line2": "Flat 3B",
    "city": "Mumbai",
    "state": "Maharashtra",
    "postalCode": "400002",
    "country": "IN"
  },
  "permittedArea": null,
  "dropServiceEnabled": true,
  "dropAddress": {
    "line1": "Dealership Service Centre, Plot 7",
    "line2": null,
    "city": "Mumbai",
    "state": "Maharashtra",
    "postalCode": "400070",
    "country": "IN"
  },
  "dropDate": "2025-08-15",
  "dropTime": "17:00:00",
  "jcNumber": "JC-2025-00456",
  "promisedDeliveryTime": "2025-08-15T17:00:00Z",
  "appointmentStatus": "INITIATED",
  "dealershipTag": "DEALERSHIP-MUM-001"
}


================================================================================
SECTION 4: RESPONSE SPECIFICATION
================================================================================

4.1 HTTP 201 Created — Appointment Successfully Initiated with Recommendation
--------------------------------------------------------------------------------

Condition           : The appointment record was persisted successfully and the
                      chauffeur recommendation engine returned a valid recommendation.

Response Headers
    Content-Type    : application/json
    X-Correlation-ID: Echo of the request correlation ID (or system-generated UUID).
    Location        : /api/v1/appointments/{appointmentNumber}

Response Body Schema

    Field           : appointmentNumber
    Type            : string
    Description     : Unique appointment number generated and returned by the system.

    Field           : appointmentStatus
    Type            : string
    Description     : Current appointment status (e.g. INITIATED).

    Field           : allocationStatus
    Type            : string
    Possible Values : RECOMMENDED
    Description     : Allocation status after successful chauffeur recommendation.

    Field           : recommendedChauffeur
    Type            : object
    Description     : Read-only system-assigned chauffeur details.

        Sub-field   : chauffeurId
        Type        : string
        Description : Unique identifier of the recommended chauffeur.

        Sub-field   : chauffeurName
        Type        : string
        Description :

ENDPOINT DESIGN: POST /api/v1/trips/{tripId}/images

================================================================================
SECTION 1: ENDPOINT IDENTIFICATION
================================================================================

Path            : /api/v1/trips/{tripId}/images
HTTP Method     : POST
Summary         : Upload and associate exterior or interior vehicle images captured
                  at drop-trip start or drop delivery; forwards references to DBP
                  Smart Eye integration.
Description     : Allows the chauffeur assigned to a trip to upload one or more
                  vehicle condition images (exterior or interior) as part of the
                  appointment booking stage vehicle condition capture workflow. The
                  endpoint persists each image to durable object storage, records
                  image metadata against the trip record, advances the relevant
                  workflow step, and appends an immutable audit trail entry. This
                  endpoint serves workflow activities SER-010-020-089,
                  SER-010-020-112, and SER-010-020-117.

Source Activity IDs : SER-010-020-089, SER-010-020-112, SER-010-020-117


================================================================================
SECTION 2: REQUEST SPECIFICATION
================================================================================

2.1 Request Headers
--------------------------------------------------------------------------------

Header Name            Required   Format / Constraints
---------------------------------------------------------------------------------------
Authorization          Yes        Must be "Bearer <token>". JWT issued by the
                                  authorised identity provider. Token must be
                                  unexpired, correctly signed, and carry the
                                  CHAUFFEUR role claim.

Content-Type           Yes        Must be "multipart/form-data". Any other value
                                  results in HTTP 415 Unsupported Media Type.

Idempotency-Key        No         Client-generated UUID v4 string. Maximum length
                                  128 characters. If supplied, the service checks
                                  the deduplication store within a 24-hour window
                                  and returns the cached success response if a
                                  matching key is found, without re-processing.
                                  If not supplied, no deduplication check is
                                  performed and re-submission may create duplicate
                                  records.

X-Request-ID           No         UUID v4. Used for distributed tracing and
                                  correlation across service logs. If not supplied,
                                  the service generates one internally.

Accept                 No         Defaults to "application/json". Only
                                  "application/json" is supported.


2.2 Path Parameters
--------------------------------------------------------------------------------

Parameter   Type     Required   Constraints
---------------------------------------------------------------------------
tripId      string   Yes        Non-empty string. Must correspond to an existing
                                trip record in the trip repository. Must be a
                                valid UUID v4 format. Validated against the trip
                                repository before any file processing begins.


2.3 Query Parameters
--------------------------------------------------------------------------------

None defined for this endpoint.


2.4 Request Body Schema (multipart/form-data)
--------------------------------------------------------------------------------

The request body is a multipart/form-data payload containing one or more image
file parts and a required metadata part.

Field Name   Part Type       Required   Type / Format / Constraints
---------------------------------------------------------------------------
images       file (binary)   Yes        One or more image files submitted as
                                        individual multipart file parts under
                                        the field name "images".

                                        Minimum count  : 1 file per request.
                                        Maximum count  : System-defined batch
                                                         limit (e.g., 10 files
                                                         per request). Exceeding
                                                         this limit triggers
                                                         BR-12 and returns
                                                         HTTP 422.

                                        Accepted MIME  : image/jpeg, image/png.
                                        types            Any other MIME type
                                                         triggers BR-4 and
                                                         returns HTTP 422.

                                        Maximum file   : System-defined per-file
                                        size             size limit (e.g., 10 MB
                                                         per file). Exceeding
                                                         this limit triggers
                                                         BR-5 and returns
                                                         HTTP 422.

                                        MIME type is   : Derived server-side
                                        derived          from file content
                                                         (magic bytes) and
                                                         cross-checked against
                                                         the declared Content-
                                                         Type of the part.

category     text (string)   Yes        Enum value indicating the image category.
                                        Accepted values: "exterior", "interior".
                                        Case-insensitive on receipt; normalised
                                        to lowercase before persistence.
                                        Absence or an invalid value triggers
                                        BR-6 and returns HTTP 422.
                                        All images in a single request must
                                        belong to the same category. Mixed-
                                        category batches within a single request
                                        are not permitted.


2.5 Field-Level Validation Summary
--------------------------------------------------------------------------------

Field          Rule                                    Error Triggered
---------------------------------------------------------------------------
tripId         Must be a valid UUID v4, non-empty.     HTTP 400 if malformed.
               Must exist in trip repository.          BR-1 / HTTP 404 if not
                                                       found.
               Trip must be in valid state.            BR-2 / HTTP 409 if wrong
                                                       state.

images         At least 1 file required.               HTTP 422 if absent.
               Count must not exceed batch limit.      BR-12 / HTTP 422.
               Each file MIME type must be             BR-4 / HTTP 422.
               image/jpeg or image/png.
               Each file size must not exceed          BR-5 / HTTP 422.
               the maximum permitted size.

category       Required. Must be "exterior" or         BR-6 / HTTP 422.
               "interior".


================================================================================
SECTION 3: RESPONSE SPECIFICATION
================================================================================

3.1 HTTP 201 Created — Successful Upload
--------------------------------------------------------------------------------

Returned when all images are successfully validated, persisted to object storage,
metadata is recorded, and the workflow step is advanced.

Response Body Schema:

Field                  Type      Description
---------------------------------------------------------------------------
status                 string    Always "success".
tripId                 string    The tripId from the path parameter.
uploadedImages         array     Array of image metadata objects, one per
                                 successfully persisted image.
  imageId              string    System-generated unique identifier for the
                                 image record (UUID v4).
  storageUrl           string    Durable URL of the persisted image in object
                                 storage. Immutable once written.
  category             string    Normalised image category: "exterior" or
                                 "interior".
  mimeType             string    Detected MIME type of the persisted file.
  fileSizeBytes        integer   Size of the persisted file in bytes.
  uploadedAt           string    ISO 8601 UTC timestamp of when the image was
                                 persisted (server-generated).
  uploadedBy           string    The JWT sub claim of the authenticated
                                 chauffeur who performed the upload.
  workflowStepId       string    The workflow step reference associated with
                                 this upload (e.g., SER-010-020-089,
                                 SER-010-020-112, or SER-010-020-117).
workflowAdvanced       boolean   True if the workflow step was successfully
                                 marked complete and the next step triggered.
nextWorkflowStepIds    array     List of workflow step IDs that were triggered
                                 or made available as a result of this upload.
idempotencyKeyUsed     boolean   True if the response was served from the
                                 deduplication cache (i.e., a duplicate
                                 idempotency key was detected).

Example Payload (HTTP 201):

status: "success"
tripId: "f47ac10b-58cc-4372-a567-0e02b2c3d479"
uploadedImages:
  - imageId: "3fa85f64-5717-4562-b3fc-2c963f66afa6"
    storageUrl: "https://storage.example.com/trips/f47ac10b/images/img_001.jpg"
    category: "exterior"
    mimeType: "image/jpeg"
    fileSizeBytes: 2048576
    uploadedAt: "2025-07-14T09:30:00Z"
    uploadedBy: "chauffeur-sub-abc123"
    workflowStepId: "SER-010-020-112"
workflowAdvanced: true
nextWorkflowStepIds:
  - "SER-010-020-113"
idempotencyKeyUsed: false


3.2 HTTP 400 Bad Request — Malformed Request
--------------------------------------------------------------------------------

Returned when the request is syntactically invalid (e.g., malformed tripId UUID,
missing required multipart parts, invalid Content-Type).

Response Body Schema:

Field       Type     Description
---------------------------------------------------------------------------
status      string   Always "error".
errorCode   string   Machine-readable error code.
message     string   Human-readable description of the error.
details     array    Optional. List of field-level error descriptors.
  field     string   The field or parameter that failed validation.
  issue     string   Description of the specific validation failure.

Example Payload (HTTP 400):

status: "error"
errorCode: "INVALID_REQUEST"
message: "The request is malformed or missing required fields."
details:
  - field: "tripId"
    issue: "tripId must be a valid UUID v4."


3.3 HTTP 401 Unauthorized — Authentication Failure
--------------------------------------------------------------------------------

Returned when the Bearer JWT token is absent, expired, malformed, or has an
invalid signature.

Response Body Schema:

Field       Type     Description
---------------------------------------------------------------------------
status      string   Always "error".
errorCode   string   "AUTHENTICATION_FAILED"
message     string   Human-readable description.

Example Payload (HTTP 401):

status: "error"
errorCode: "AUTHENTICATION_FAILED"
message: "Authentication token is missing, expired, or invalid."


3.4 HTTP 403 Forbidden — Authorization Failure
--------------------------------------------------------------------------------

Returned when the authenticated principal does not hold the CHAUFFEUR role, or
when the authenticated chauffeur is not the one assigned to the specified trip
(BR-3).

Response Body Schema:

Field       Type     Description
---------------------------------------------------------------------------
status      string   Always "error".
errorCode   string   "AUTHORIZATION_DENIED"
message     string   Human-readable description.

Example Payload (HTTP 403):

status: "error"
errorCode: "AUTHORIZATION_DENIED"
message: "You are not authorized to upload images for this trip."


3.5 HTTP 404 Not Found — Trip Not Found
--------------------------------------------------------------------------------

Returned when the tripId does not correspond to any existing trip record (BR-1).

Response Body Schema:

Field       Type     Description
---------------------------------------------------------------------------
status      string   Always "error".
errorCode   string   "TRIP_NOT_FOUND"
message     string   Human-readable description.

Example Payload (HTTP 404):

status: "error"
errorCode: "TRIP_NOT_FOUND"
message: "Trip not found for the provided tripId."


3.6 HTTP 409 Conflict — Invalid Trip State
--------------------------------------------------------------------------------

Returned when the trip exists but is not in a valid state for image upload (e.g.,
trip is completed, cancelled, or has not yet reached the vehicle condition capture
stage) (BR-2).

Response Body Schema:

Field       Type     Description
---------------------------------------------------------------------------
status      string   Always "error".
errorCode   string   "INVALID_TRIP_STATE"
message     string   Human-readable description.
currentState string  The current state of the trip as recorded in the system.

Example Payload (HTTP 409):

status: "error"
errorCode: "INVALID_TRIP_STATE"
message: "Image upload is not permitted for a trip in its current state."
currentState: "COMPLETED"


3.7 HTTP 422 Unprocessable Entity — Validation Failure
--------------------------------------------------------------------------------

Returned when the request is syntactically valid but fails business validation
rules (BR-4, BR-5, BR-6, BR-12).

Response Body Schema:

Field       Type     Description
---------------------------------------------------------------------------
status      string   Always "error".
errorCode   string   Machine-readable error code identifying the specific rule.
message     string   Human-readable description.
details     array    List of per-file or per-field validation failures.
  field     string   The field or file that failed validation.
  issue     string   Description of the specific failure.

Example Payload (HTTP 422 — unsupported MIME type, BR-4):

status: "error"
errorCode: "UNSUPPORTED_FILE_TYPE"
message: "One or more

ENDPOINT DESIGN: GET /api/v1/trips/{tripId}/images

================================================================================
SECTION 1: ENDPOINT IDENTIFICATION
================================================================================

Path            : /api/v1/trips/{tripId}/images
HTTP Method     : GET
Summary         : Retrieve all vehicle images associated with a trip for audit
                  and coordinator review
Source Activity IDs : SER-010-020-089, SER-010-020-112

Description:
This endpoint returns the complete set of active vehicle condition images
(both exterior and interior) that have been captured and persisted against a
specific trip. Images are produced during the vehicle condition capture session
initiated as part of the automated appointment booking process. The endpoint is
read-only and is used by chauffeurs, pickup coordinators, and authorised
integration services to review the current image state of a trip. Only active,
non-superseded image records are returned. If no images have yet been uploaded
for the trip, an empty collection is returned rather than an error.


================================================================================
SECTION 2: REQUEST SPECIFICATION
================================================================================

2.1 Request Headers
--------------------------------------------------------------------------------

Header Name       : Authorization
Required          : Yes
Format            : Bearer <JWT token>
Description       : OAuth2 / OIDC Bearer token. Must be a valid, non-expired
                    JWT signed by the recognised issuer. The token must carry
                    the scope trip:images:read and a role claim matching one of
                    CHAUFFEUR, PICKUP_COORDINATOR, ADMIN, or
                    INTEGRATION_SERVICE.

Header Name       : Accept
Required          : No (defaults to application/json)
Format            : application/json
Description       : Indicates the expected response media type.

Header Name       : X-Correlation-ID
Required          : No (recommended)
Format            : UUID v4 string
Description       : Caller-supplied correlation identifier for distributed
                    tracing. If provided, the value is echoed in the response
                    header and included in audit and operational log entries.


2.2 Path Parameters
--------------------------------------------------------------------------------

Parameter Name    : tripId
Location          : Path
Required          : Yes
Type              : String
Format            : Non-empty string conforming to the system trip identifier
                    format. Expected pattern: alphanumeric characters, hyphens
                    permitted, no whitespace, length between 1 and 64
                    characters inclusive. Regex: ^[A-Za-z0-9\-]{1,64}$
Validation Rules  :
  - Must not be null or empty.
  - Must match the regex pattern defined above.
  - Must not contain special characters outside the permitted set.
  - Validated before any downstream data access occurs (BR-5).
DB Mapping        : trips.trip_id


2.3 Query Parameters
--------------------------------------------------------------------------------

None defined for this endpoint. All filtering is implicit (only active records
are returned) and is applied server-side.


2.4 Request Body
--------------------------------------------------------------------------------

Not applicable. This is a GET operation; no request body is accepted or
processed.


================================================================================
SECTION 3: RESPONSE SPECIFICATION
================================================================================

3.1 HTTP 200 - Success
--------------------------------------------------------------------------------

Description:
The request was processed successfully. The response body contains the
collection of active vehicle images associated with the specified trip. If no
images have been uploaded yet, the images array is empty (BR-6).

Response Body Schema:

  Field: tripId
    Type     : String
    Required : Yes
    Description: The trip identifier for which images are returned. Mirrors
                 the tripId path parameter.
    DB Column: trips.trip_id

  Field: imageCount
    Type     : Integer
    Required : Yes
    Minimum  : 0
    Description: Total number of active image records included in the response.

  Field: images
    Type     : Array of TripImage objects
    Required : Yes
    Description: Ordered collection of active vehicle image records. May be
                 empty if no images have been captured yet.

  TripImage Object Fields:

    Field: imageId
      Type     : String
      Required : Yes
      Description: Unique identifier for the image record.
      DB Column: trip_images.image_id

    Field: tripId
      Type     : String
      Required : Yes
      Description: The trip identifier this image is associated with.
      DB Column: trip_images.trip_id

    Field: imageType
      Type     : String
      Required : Yes
      Allowed Values: EXTERIOR, INTERIOR
      Description: Categorises the image as an exterior or interior vehicle
                   condition photograph.
      DB Column: trip_images.image_type

    Field: imageUrl
      Type     : String
      Required : Yes
      Format   : URI (https)
      Description: Pre-authorised or signed URL providing access to the image
                   resource in the vehicle image storage service. URL validity
                   period is governed by the storage service configuration.
      DB Column: trip_images.image_url

    Field: capturedBy
      Type     : String
      Required : Yes
      Description: Identity of the principal (chauffeur user ID or service
                   account identifier) who uploaded or triggered the capture
                   of this image.
      DB Column: trip_images.captured_by

    Field: capturedAt
      Type     : String
      Required : Yes
      Format   : ISO 8601 date-time (UTC), e.g. 2025-06-15T09:30:00Z
      Description: Timestamp at which the image was captured and persisted.
      DB Column: trip_images.captured_at

    Field: status
      Type     : String
      Required : Yes
      Allowed Values: ACTIVE
      Description: Lifecycle status of the image record. Only ACTIVE records
                   are returned; superseded or logically deleted records are
                   excluded server-side (BR-7).
      DB Column: trip_images.status

Example 200 Response Payload (with images):

  tripId: "TRIP-20250615-00123"
  imageCount: 3
  images:
    - imageId: "IMG-001-TRIP-20250615-00123"
      tripId: "TRIP-20250615-00123"
      imageType: "EXTERIOR"
      imageUrl: "https://storage.example.com/images/IMG-001-TRIP-20250615-00123?sig=abc123&expires=1750000000"
      capturedBy: "CHAUFFEUR-USER-4521"
      capturedAt: "2025-06-15T09:28:00Z"
      status: "ACTIVE"
    - imageId: "IMG-002-TRIP-20250615-00123"
      tripId: "TRIP-20250615-00123"
      imageType: "EXTERIOR"
      imageUrl: "https://storage.example.com/images/IMG-002-TRIP-20250615-00123?sig=def456&expires=1750000000"
      capturedBy: "CHAUFFEUR-USER-4521"
      capturedAt: "2025-06-15T09:28:45Z"
      status: "ACTIVE"
    - imageId: "IMG-003-TRIP-20250615-00123"
      tripId: "TRIP-20250615-00123"
      imageType: "INTERIOR"
      imageUrl: "https://storage.example.com/images/IMG-003-TRIP-20250615-00123?sig=ghi789&expires=1750000000"
      capturedBy: "CHAUFFEUR-USER-4521"
      capturedAt: "2025-06-15T09:29:10Z"
      status: "ACTIVE"

Example 200 Response Payload (no images yet uploaded):

  tripId: "TRIP-20250615-00456"
  imageCount: 0
  images: []


3.2 HTTP 400 - Bad Request
--------------------------------------------------------------------------------

Description:
The request was rejected due to a malformed, empty, or format-invalid tripId
path parameter. No downstream data access is performed (BR-5).

Response Body Schema:

  Field: errorCode
    Type     : String
    Value    : INVALID_TRIP_ID_FORMAT

  Field: message
    Type     : String
    Value    : Invalid tripId format. Please provide a valid trip identifier.

  Field: tripId
    Type     : String
    Description: The value supplied by the caller that failed validation.

  Field: timestamp
    Type     : String
    Format   : ISO 8601 date-time (UTC)

Example 400 Response Payload:

  errorCode: "INVALID_TRIP_ID_FORMAT"
  message: "Invalid tripId format. Please provide a valid trip identifier."
  tripId: "TRIP###INVALID!!"
  timestamp: "2025-06-15T09:30:00Z"


3.3 HTTP 401 - Unauthorised
--------------------------------------------------------------------------------

Description:
The request did not include a valid Bearer JWT token, the token has expired,
the signature is invalid, or the issuer is not recognised.

Response Body Schema:

  Field: errorCode
    Type     : String
    Value    : AUTHENTICATION_FAILED

  Field: message
    Type     : String
    Value    : Authentication failed. A valid Bearer token is required.

  Field: timestamp
    Type     : String
    Format   : ISO 8601 date-time (UTC)

Example 401 Response Payload:

  errorCode: "AUTHENTICATION_FAILED"
  message: "Authentication failed. A valid Bearer token is required."
  timestamp: "2025-06-15T09:30:00Z"


3.4 HTTP 403 - Forbidden
--------------------------------------------------------------------------------

Description:
The caller is authenticated but is not associated with the specified trip as
a chauffeur, pickup coordinator, or authorised integration service. No image
data is disclosed (BR-2).

Response Body Schema:

  Field: errorCode
    Type     : String
    Value    : ACCESS_DENIED

  Field: message
    Type     : String
    Value    : Access denied. Caller is not authorised to view images for
               this trip.

  Field: tripId
    Type     : String
    Description: The tripId for which access was denied.

  Field: timestamp
    Type     : String
    Format   : ISO 8601 date-time (UTC)

Example 403 Response Payload:

  errorCode: "ACCESS_DENIED"
  message: "Access denied. Caller is not authorised to view images for this trip."
  tripId: "TRIP-20250615-00123"
  timestamp: "2025-06-15T09:30:00Z"


3.5 HTTP 404 - Not Found
--------------------------------------------------------------------------------

Description:

ENDPOINT DETAILED DESIGN
========================

Source Requirement IDs: SER-010-020-080


1. ENDPOINT IDENTIFICATION
--------------------------

Path        : /api/v1/vehicle-condition-reports/{reportId}
HTTP Method : GET
Summary     : Retrieve a completed VehicleConditionReport by its ID including all fields, media references, and signature
Description : Returns the full vehicle condition report for a given reportId. The response includes vehicle number, pickup time, captured concerns, condition images served as secure pre-signed URLs, and a read-only secure record link. This endpoint is consumed by authorised human principals (Pickup Coordinator, Chauffeur, Customer) and by the Notification Dispatch Service acting as an Integration Service to compose and dispatch customer-facing notifications via ICP, WhatsApp, SMS, DBP, and CRM channels. The report is immutable; this operation produces no state change.


2. REQUEST SPECIFICATION
------------------------

2.1 Request Headers

Header Name       : Authorization
Required          : Yes
Format            : Bearer <JWT token>
Description       : OAuth2 / OIDC Bearer JWT. Must be signed, non-expired, and contain valid issuer and audience claims. The token must carry role and identity claims used for RBAC and ownership verification.

Header Name       : Accept
Required          : No (recommended)
Allowed Value     : application/json
Description       : Indicates the client expects a JSON response body.

Header Name       : X-Correlation-ID
Required          : No (recommended)
Format            : UUID v4
Description       : Caller-supplied correlation identifier for distributed tracing. If absent, the system generates one internally and includes it in the response.

Header Name       : X-Request-ID
Required          : No
Format            : UUID v4
Description       : Idempotency and tracing aid. Logged in the audit trail alongside the request.


2.2 Path Parameters

Parameter Name : reportId
Location       : Path
Type           : String
Required       : Yes
Format         : Non-empty string conforming to the system-defined report identifier format (alphanumeric, hyphens permitted, no whitespace, expected length 1 to 128 characters)
Regex          : ^[a-zA-Z0-9\-]{1,128}$
Validation     : Must be non-empty. Must match the defined identifier format. Validated before any data store lookup is attempted. Malformed values are rejected with HTTP 400 before any downstream call is made.
Example        : vcr-20240601-00123


2.3 Query Parameters

None defined for this endpoint.


2.4 Request Body

None. This is a GET operation; no request body is accepted or processed.


3. RESPONSE SPECIFICATION
--------------------------

3.1 HTTP 200 - Success

Condition : The reportId exists, the caller is authenticated and authorised, the ownership or association check passes, and all downstream services respond successfully.

Response Body Fields:

Field Name       : reportId
Type             : String
Description      : The unique identifier of the vehicle condition report.
Source           : vehicle_condition_reports.report_id
Example          : vcr-20240601-00123

Field Name       : appointmentId
Type             : String
Description      : The identifier of the appointment to which this report is linked.
Source           : vehicle_condition_reports.appointment_id
Example          : appt-20240601-00456

Field Name       : vehicleNumber
Type             : String
Description      : The registration or fleet number of the vehicle inspected.
Source           : vehicle_condition_reports.vehicle_number
Example          : DXB-A-12345

Field Name       : pickupTime
Type             : String (ISO 8601 datetime, UTC)
Description      : The scheduled or actual pickup time recorded at the time of report creation.
Source           : vehicle_condition_reports.pickup_time
Example          : 2024-06-01T08:30:00Z

Field Name       : capturedConcerns
Type             : Array of String
Description      : List of condition concerns captured during the inspection session. May be empty if no concerns were recorded.
Source           : vehicle_condition_reports.captured_concerns
Example          : ["Minor scratch on rear bumper", "Low tyre pressure front-left"]

Field Name       : conditionImages
Type             : Array of Object
Description      : List of condition image objects. Each object contains a secure pre-signed URL and associated metadata. Pre-signed URLs are time-limited; callers must not cache responses beyond the URL expiry window.
Source           : vehicle_condition_reports.condition_image_refs (resolved via Image Storage Service)

  Sub-field      : imageId
  Type           : String
  Description    : Unique identifier of the image asset.
  Example        : img-00789

  Sub-field      : url
  Type           : String (HTTPS URL)
  Description    : Secure, time-limited pre-signed URL for accessing the image. Not a plain public URL.
  Example        : https://storage.example.com/vcr-images/img-00789?token=abc123&expires=1717228800

  Sub-field      : expiresAt
  Type           : String (ISO 8601 datetime, UTC)
  Description    : The UTC datetime at which the pre-signed URL expires.
  Example        : 2024-06-01T09:30:00Z

  Sub-field      : contentType
  Type           : String
  Description    : MIME type of the image.
  Example        : image/jpeg

Field Name       : secureRecordLink
Type             : String (HTTPS URL)
Description      : A read-only secure link to the full vehicle condition report record. This link grants read access only; any attempt to use it for mutation operations will be denied. Scoped to read-only access.
Source           : vehicle_condition_reports.secure_record_link
Example          : https://records.example.com/vcr/vcr-20240601-00123?access=readonly&token=xyz789

Field Name       : createdAt
Type             : String (ISO 8601 datetime, UTC)
Description      : The UTC timestamp at which the vehicle condition report was originally created and persisted.
Source           : vehicle_condition_reports.created_at
Example          : 2024-06-01T08:15:00Z

Example 200 Response Payload:

reportId          : vcr-20240601-00123
appointmentId     : appt-20240601-00456
vehicleNumber     : DXB-A-12345
pickupTime        : 2024-06-01T08:30:00Z
capturedConcerns  : ["Minor scratch on rear bumper", "Low tyre pressure front-left"]
conditionImages   :
  - imageId       : img-00789
    url           : https://storage.example.com/vcr-images/img-00789?token=abc123&expires=1717228800
    expiresAt     : 2024-06-01T09:30:00Z
    contentType   : image/jpeg
  - imageId       : img-00790
    url           : https://storage.example.com/vcr-images/img-00790?token=def456&expires=1717228800
    expiresAt     : 2024-06-01T09:30:00Z
    contentType   : image/jpeg
secureRecordLink  : https://records.example.com/vcr/vcr-20240601-00123?access=readonly&token=xyz789
createdAt         : 2024-06-01T08:15:00Z


3.2 HTTP 400 - Bad Request

Condition : The reportId path parameter is malformed, empty, or does not conform to the expected identifier format. Triggered before any data store lookup.
Business Rule : BR-2

Response Body Fields:

Field Name    : errorCode
Type          : String
Value         : INVALID_REPORT_ID

Field Name    : message
Type          : String
Value         : Invalid reportId format. A valid report identifier must be provided.

Field Name    : correlationId
Type          : String
Description   : Correlation ID for tracing.

Example 400 Response Payload:

errorCode     : INVALID_REPORT_ID
message       : Invalid reportId format. A valid report identifier must be provided.
correlationId : 550e8400-e29b-41d4-a716-446655440000


3.3 HTTP 401 - Unauthorised

Condition : The Bearer JWT token is absent, expired, has an invalid signature, or fails issuer or audience validation.

Response Body Fields:

Field Name    : errorCode
Type          : String
Value         : UNAUTHORISED

Field Name    : message
Type          : String
Value         : Authentication failed. A valid Bearer token is required.

Field Name    : correlationId
Type          : String
Description   : Correlation ID for tracing.

Example 401 Response Payload:

errorCode     : UNAUTHORISED
message       : Authentication failed. A valid Bearer token is required.
correlationId : 550e8400-e29b-41d4-a716-446655440001


3.4 HTTP 403 - Forbidden

Condition A : The caller's role is not in the permitted set (PICKUP_COORDINATOR, CHAUFFEUR, CUSTOMER, INTEGRATION_SERVICE).
Condition B : The caller's role is valid but the ownership or association check against the linked appointment fails (BR-5).
Condition C : The secure record link is used in an attempt to perform a mutation operation (BR-4).

Response Body Fields:

Field Name    : errorCode
Type          : String
Value         : ACCESS_DENIED

Field Name    : message
Type          : String
Value         : Access denied. You are not authorised to view this vehicle condition report.

Field Name    : correlationId
Type          : String
Description   : Correlation ID for tracing.

Example 403 Response Payload:

errorCode     : ACCESS_DENIED
message       : Access denied. You are not authorised to view this vehicle condition report.
correlationId : 550e8400-e29b-41d4-a716-446655440002


3.5 HTTP 404 - Not Found

Condition : The reportId is well-formed but does not correspond to any existing vehicle condition report in the data store. Triggered after format validation passes but the data store lookup returns no record.
Business Rule : BR-1

Response Body Fields:

Field Name    : errorCode
Type          : String
Value         : REPORT_NOT_FOUND

Field Name    : message
Type          : String
Value         : Vehicle condition report not found for the provided reportId.

Field Name    : correlationId
Type          : String
Description   : Correlation ID for tracing.

Example 404 Response Payload:

errorCode     : REPORT_NOT_FOUND
message       : Vehicle condition report not found for the provided reportId.
correlationId : 550e8400-e29b-41d4-a716-446655440003


3.6 HTTP 500 - Internal Server Error

Condition : An unexpected internal error occurs that is not attributable to a known downstream dependency failure or input validation failure.

Response Body Fields:

Field Name    : errorCode
Type          : String
Value         : INTERNAL_ERROR

Field Name    : message
Type          : String
Value         : An unexpected error occurred. Please contact support if the problem persists.

Field Name    : correlationId
Type          : String
Description   : Correlation ID for tracing.

Example 500 Response Payload:

errorCode     : INTERNAL_ERROR
message       : An unexpected error occurred. Please contact support if the problem persists.
correlationId : 550e8400-e29b-41d4-a716-446655440004


3.7 HTTP 503 - Service Unavailable

Condition : The Vehicle Condition Report Data Store, Image Storage Service, or Appointment Service is unreachable or returns an error during processing. No partial data is returned. Triggered by BR-10.
Business Rule : BR-10

Response Body Fields:

Field Name    : errorCode
Type          : String
Value         : SERVICE_UNAVAILABLE

Field Name    : message
Type          : String
Value         : Vehicle condition report service is temporarily unavailable. Please retry after some time.

Field Name    : correlationId
Type          : String
Description   : Correlation ID for tracing.

Example 503 Response Payload:

errorCode     : SERVICE_UNAVAILABLE
message       : Vehicle condition report service is temporarily unavailable. Please retry after some time.
correlationId : 550e8400-e29b

ENDPOINT DESIGN: POST /api/v1/notifications/trip-status

================================================================================
SECTION 1: ENDPOINT IDENTIFICATION
================================================================================

Path            : /api/v1/notifications/trip-status
HTTP Method     : POST
Summary         : Send live trip status and ETA update to customer and Pickup
                  Coordinator during transit
Source Requirement IDs : SER-010-020-026, SER-010-020-084, SER-010-020-114

Description:
This endpoint accepts a trip-status notification request from an authorised
internal caller and fans out a live trip status and ETA update to all
configured notification channels (ICP, WhatsApp, SMS, DBP, CRM) for the
referenced appointment. The notification is targeted at three stakeholder
groups: the Customer, the Pickup Coordinator, and the Chauffeur. Live
positional and ETA data are sourced in real time from the Map API integration
before notification payloads are composed and dispatched. The endpoint
supports idempotent processing via a deduplication hash and returns a
per-channel dispatch outcome in the response.


================================================================================
SECTION 2: REQUEST SPECIFICATION
================================================================================

2.1 Request Headers
--------------------------------------------------------------------------------

Header Name       : Authorization
Required          : Yes
Format            : Bearer <JWT token>
Description       : OAuth2/OIDC Bearer token. Must be a valid, non-expired JWT
                    signed by the authorised issuer. Token must carry the role
                    claim (INTEGRATION_SERVICE, CCE, or ADMIN) and the OAuth
                    scope notifications:write.

Header Name       : Content-Type
Required          : Yes
Expected Value    : application/json
Description       : Request body must be JSON-encoded.

Header Name       : Accept
Required          : No
Expected Value    : application/json
Description       : Indicates the client expects a JSON response.

Header Name       : X-Idempotency-Key
Required          : Recommended
Format            : String, UUID v4 or composite key
Description       : Client-supplied idempotency key. If not provided, the
                    system computes an internal deduplication hash from
                    appointmentId + tripStatus + eta. If a matching key or
                    hash is found within the deduplication window, the cached
                    response is returned without re-dispatching notifications.

Header Name       : X-Correlation-ID
Required          : No
Format            : UUID v4
Description       : Optional correlation identifier for distributed tracing.
                    Propagated to all downstream service calls and included in
                    the audit record.

Header Name       : X-Request-ID
Required          : No
Format            : UUID v4
Description       : Optional unique request identifier for logging and
                    debugging purposes.


2.2 Path Parameters
--------------------------------------------------------------------------------

None. This endpoint does not accept path parameters.


2.3 Query Parameters
--------------------------------------------------------------------------------

None. This endpoint does not accept query parameters.


2.4 Request Body Schema
--------------------------------------------------------------------------------

Content-Type : application/json

The request body must be a JSON object containing the following fields.

Field Name    : appointmentId
Type          : string
Required      : Yes
Format        : Non-empty string; alphanumeric with hyphens permitted
Min Length    : 1
Max Length    : 64
Description   : Unique identifier of the appointment for which the trip-status
                notification is being triggered. Must reference an existing,
                active appointment record.
Validation    : Must be present and non-null. Must not be blank. Must match
                the pattern [A-Za-z0-9\-]{1,64}.

Field Name    : tripStatus
Type          : string (enumeration)
Required      : Yes
Allowed Values: IN_PROGRESS, APPROACHING, ARRIVED, DELAYED, EN_ROUTE
Description   : Current status of the trip at the time of notification
                dispatch. Must be a recognised value from the system-defined
                trip-status enumeration.
Validation    : Must be present and non-null. Must be one of the defined
                enumeration values. Unrecognised or null values are rejected
                with a 422 response (BR-7).

Field Name    : eta
Type          : string
Required      : Yes
Format        : ISO-8601 datetime with timezone offset (e.g.
                2025-08-15T14:30:00+05:30)
Description   : Estimated time of arrival at the dealership. Must be a future
                datetime at the time the request is processed.
Validation    : Must be present and non-null. Must conform to ISO-8601 format.
                Must represent a future timestamp relative to the server clock
                at time of processing. Past or malformed values are rejected
                with a 422 response (BR-8).

Field Name    : revisedEta
Type          : string
Required      : No
Format        : ISO-8601 datetime with timezone offset
Description   : Revised ETA if the original ETA has changed due to route
                changes, traffic, or delays. When present, this value is
                included in the chauffeur-facing notification as a read-only
                field and propagated to downstream channels.
Validation    : If provided, must conform to ISO-8601 format and must
                represent a future timestamp. Null or absent means no revision
                has occurred.

Field Name    : chauffeurId
Type          : string
Required      : Yes
Format        : Non-empty string; alphanumeric with hyphens permitted
Min Length    : 1
Max Length    : 64
Description   : Unique identifier of the chauffeur assigned to the trip.
                Used to route the chauffeur-facing notification.
Validation    : Must be present and non-null. Must not be blank.

Field Name    : channels
Type          : array of strings
Required      : No
Allowed Values: ICP, WHATSAPP, SMS, DBP, CRM
Description   : Optional explicit list of channels to target for this
                notification. If omitted, the system uses the channel
                configuration provisioned for the appointment. If provided,
                only the listed channels are targeted.
Validation    : Each element must be one of the allowed channel values.
                Duplicate entries are ignored. An empty array is treated as
                equivalent to omitting the field (all configured channels
                are used).

Example Request Body:

{
  "appointmentId": "APPT-20250815-00123",
  "tripStatus": "EN_ROUTE",
  "eta": "2025-08-15T14:30:00+05:30",
  "revisedEta": "2025-08-15T14:45:00+05:30",
  "chauffeurId": "CHFR-00456",
  "channels": ["ICP", "WHATSAPP", "SMS", "DBP", "CRM"]
}


================================================================================
SECTION 3: RESPONSE SPECIFICATION
================================================================================

3.1 HTTP 200 - All Channels Dispatched Successfully
--------------------------------------------------------------------------------

Condition : All targeted notification channels accepted the dispatch without
            error. Idempotent replay of a previously processed request also
            returns 200 with the cached result.

Response Body Schema:

Field Name          : status
Type                : string
Description         : High-level outcome. Value is "SUCCESS".

Field Name          : notificationId
Type                : string
Description         : System-generated unique identifier for this notification
                      dispatch event.

Field Name          : appointmentId
Type                : string
Description         : Echo of the appointment ID from the request.

Field Name          : tripStatus
Type                : string
Description         : Echo of the trip status from the request.

Field Name          : eta
Type                : string (ISO-8601)
Description         : ETA used in the dispatched notifications.

Field Name          : revisedEta
Type                : string (ISO-8601) or null
Description         : Revised ETA if present; null otherwise.

Field Name          : dispatchTimestamp
Type                : string (ISO-8601)
Description         : Server-side timestamp at which dispatch was initiated.

Field Name          : idempotent
Type                : boolean
Description         : True if this response was served from the deduplication
                      cache (i.e. the request was a duplicate within the
                      deduplication window). False for a fresh dispatch.

Field Name          : channelResults
Type                : array of objects
Description         : Per-channel dispatch outcome. Each element contains:
                        channel       - string, channel name
                        status        - string, "DISPATCHED" or "CACHED"
                        dispatchedAt  - string (ISO-8601) or null

Example 200 Response Body:

{
  "status": "SUCCESS",
  "notificationId": "NOTIF-20250815-78901",
  "appointmentId": "APPT-20250815-00123",
  "tripStatus": "EN_ROUTE",
  "eta": "2025-08-15T14:30:00+05:30",
  "revisedEta": "2025-08-15T14:45:00+05:30",
  "dispatchTimestamp": "2025-08-15T13:55:00+05:30",
  "idempotent": false,
  "channelResults": [
    { "channel": "ICP",      "status": "DISPATCHED", "dispatchedAt": "2025-08-15T13:55:01+05:30" },
    { "channel": "WHATSAPP", "status": "DISPATCHED", "dispatchedAt": "2025-08-15T13:55:02+05:30" },
    { "channel": "SMS",      "status": "DISPATCHED", "dispatchedAt": "2025-08-15T13:55:02+05:30" },
    { "channel": "DBP",      "status": "DISPATCHED", "dispatchedAt": "2025-08-15T13:55:03+05:30" },
    { "channel": "CRM",      "status": "DISPATCHED", "dispatchedAt": "2025-08-15T13:55:03+05:30" }
  ]
}


3.2 HTTP 207 - Partial Channel Dispatch (Multi-Status)
--------------------------------------------------------------------------------

Condition : One or more downstream notification channels failed to accept the
            dispatch. Successful channels are confirmed; failed channels have
            been enqueued for retry. The overall operation is not considered a
            total failure (BR-9).

Response Body Schema:

Field Name          : status
Type                : string
Description         : High-level outcome. Value is "PARTIAL_SUCCESS".

Field Name          : notificationId
Type                : string
Description         : System-generated unique identifier for this notification
                      dispatch event.

Field Name          : appointmentId
Type                : string
Description         : Echo of the appointment ID from the request.

Field Name          : tripStatus
Type                : string
Description         : Echo of the trip status from the request.

Field Name          : eta
Type                : string (ISO-8601)
Description         : ETA used in the dispatched notifications.

Field Name          : revisedEta
Type                : string (ISO-8601) or null
Description         : Revised ETA if present; null otherwise.

Field Name          : dispatchTimestamp
Type                : string (ISO-8601)
Description         : Server-side timestamp at which dispatch was initiated.

Field Name          : idempotent
Type                : boolean
Description         : Indicates whether this was a deduplicated replay.

Field Name          : channelResults
Type                : array of objects
Description         : Per-channel dispatch outcome. Each element contains:
                        channel       - string, channel name
                        status        - string, one of "DISPATCHED",
                                        "FAILED", "QUEUED_FOR_RETRY"
                        dispatchedAt  - string (ISO-8601) or null
                        errorCode     - string or null, channel-level error
                        errorMessage  - string or null, human-readable detail

Field Name          : message
Type                : string
Description         : Human-readable summary of the partial outcome.

Example 207 Response Body:

{
  "status": "PARTIAL_SUCCESS",
  "notificationId": "NOTIF-20250815-78902",
  "appointmentId": "APPT-20250815-00123",
  "tripStatus": "EN_ROUTE",
  "eta": "2025-08-15T14:30:00+05:30",
  "revisedEta": null,
  "dispatchTimestamp": "2025-08-15T13:55:00+05:30",
  "idempotent": false,
  "message": "Notification dispatched with partial channel failures. See channel status details.",
  "channelResults": [
    { "channel": "ICP",      "status": "DISPATCHED",       "dispatchedAt": "2025-08-15T13:55:01+05:30", "errorCode": null,          "errorMessage": null },
    { "channel": "WHATSAPP", "status": "QUEUED_FOR_RETRY", "dispatchedAt": null,                        "errorCode": "GW_TIMEOUT",  "errorMessage": "WhatsApp gateway did not respond within the timeout window." },
    { "channel": "SMS",      "status": "DISPATCHED",       "dispatchedAt": "2025-08-15T13:55:02+05:30", "errorCode": null,          "errorMessage": null },
    { "channel": "DBP",      "status": "DISPATCHED",       "dispatchedAt": "2025-08-15T13:55:03+05:30", "errorCode": null,          "errorMessage": null

ENDPOINT: POST /api/v1/chauffeurs/{chauffeurId}/vehicle-verification

Source Requirement IDs: SER-010-020-052, SER-010-020-053, SER-010-020-055, SER-010-020-057, SER-010-020-058, SER-010-020-061

--------------------------------------------------------------------------------
SECTION 1: ENDPOINT OVERVIEW
--------------------------------------------------------------------------------

Path            : /api/v1/chauffeurs/{chauffeurId}/vehicle-verification
HTTP Method     : POST
Summary         : Initiate vehicle verification at pickup via QR code scan or manual registration/VIN entry and return pre-populated vehicle details
Description     : This endpoint allows an authenticated chauffeur, pickup coordinator, or admin to initiate a vehicle verification session at the point of pickup. The session can be started via QR code scan (primary path) or manual registration number and VIN entry (fallback path). On success, a verification session record is persisted, the associated appointment status is advanced to VEHICLE_VERIFIED, an immutable audit trail entry is appended, and a domain event is emitted for downstream orchestration.

--------------------------------------------------------------------------------
SECTION 2: REQUEST SPECIFICATION
--------------------------------------------------------------------------------

2.1 Request Headers

Header Name       : Authorization
Required          : Yes
Format            : Bearer <JWT token> (OAuth2/OIDC)
Description       : Must contain a valid, non-expired JWT. The token subject must match the chauffeurId path parameter unless the caller holds ADMIN or PICKUP_COORDINATOR role.

Header Name       : Content-Type
Required          : Yes
Expected Value    : application/json
Description       : Request body must be JSON-encoded.

Header Name       : Accept
Required          : No
Expected Value    : application/json
Description       : Indicates the client expects a JSON response.

Header Name       : X-Request-ID
Required          : No
Format            : UUID v4
Description       : Optional idempotency/correlation identifier supplied by the caller for tracing purposes. Logged and echoed in the response.

--------------------------------------------------------------------------------

2.2 Path Parameters

Parameter Name  : chauffeurId
Location        : Path
Type            : String
Required        : Yes
Format          : UUID v4
Description     : Unique identifier of the chauffeur initiating the vehicle verification. Must resolve to an existing, active chauffeur record in the system.
Validation      : Must be a valid UUID. Non-UUID values result in a 400 Bad Request. If the UUID is valid but does not resolve to a known chauffeur, a 404 Not Found is returned.

--------------------------------------------------------------------------------

2.3 Query Parameters

None defined for this endpoint.

--------------------------------------------------------------------------------

2.4 Request Body Schema

Content-Type: application/json

All fields are described below. Fields marked Required=Yes must be present and non-null in the request body. Fields marked Required=Conditional are mandatory only when the stated condition applies.

Field Name          : verificationMode
Type                : String (Enum)
Required            : Yes
Allowed Values      : QR_CODE, MANUAL
Description         : Indicates the method used to initiate vehicle verification. QR_CODE triggers automatic appointment detail resolution from the QR payload. MANUAL requires the chauffeur to supply registrationNumber explicitly.
Validation          : Must be one of the two enumerated values. Any other value results in a 400 Bad Request.

Field Name          : qrCodePayload
Type                : String
Required            : Conditional (Required when verificationMode is QR_CODE)
Max Length          : 2048 characters
Description         : The raw QR code payload captured by the chauffeur's device. Passed to the QR Code / OCR Resolution Service for decoding and appointment resolution.
Validation          : Must be present and non-blank when verificationMode is QR_CODE. If absent when mode is QR_CODE, a 400 Bad Request is returned. If present but unresolvable, a 422 Unprocessable Entity is returned.

Field Name          : registrationNumber
Type                : String
Required            : Conditional (Required when verificationMode is MANUAL; also required when verificationMode is QR_CODE and OCR-derived value is confirmed or overridden by the chauffeur)
Min Length          : 2 characters
Max Length          : 20 characters
Pattern             : Alphanumeric characters and hyphens only. Regex: ^[A-Z0-9\-]{2,20}$
Description         : Vehicle registration plate number. In QR_CODE mode this value is pre-populated from OCR resolution and may be overridden by the chauffeur. In MANUAL mode it must be explicitly supplied.
Validation          : Must not be blank. Must match the defined regex pattern. Failure results in 400 Bad Request with rule BR-4.

Field Name          : vin
Type                : String
Required            : Yes
Min Length          : 17 characters
Max Length          : 17 characters
Pattern             : Standard VIN format. Regex: ^[A-HJ-NPR-Z0-9]{17}$
Description         : Vehicle Identification Number. Mandatory for all verification sessions regardless of mode.
Validation          : Must be exactly 17 characters. Must match the VIN regex. Must not be blank. Failure results in 400 Bad Request with rule BR-5.

Field Name          : vehicleModel
Type                : String
Required            : No (loaded from appointment record; may be supplied to override)
Max Length          : 100 characters
Description         : Make and model of the vehicle. Typically pre-populated from the appointment record. May be supplied in the request body to override the appointment-sourced value.
Validation          : If supplied, must not exceed 100 characters.

Field Name          : odometerReading
Type                : Number (Integer or Decimal)
Required            : Yes
Minimum Value       : 0
Maximum Value       : 9999999
Description         : Current odometer reading of the vehicle at the time of verification. Must be a non-negative numeric value.
Validation          : Must be present. Must be a numeric type. Must be greater than or equal to 0. Negative values or non-numeric values result in 400 Bad Request with rule BR-7.

Field Name          : fuelLevel
Type                : String or Number
Required            : Yes
Allowed Values (Enum): EMPTY, QUARTER, HALF, THREE_QUARTER, FULL
Allowed Values (Numeric): Integer or decimal between 0 and 100 inclusive
Description         : Current fuel level of the vehicle. Accepted as either a recognised enumerated string label or a numeric percentage between 0 and 100.
Validation          : Must be present. If a string, must be one of the five enumerated values. If a number, must be between 0 and 100 inclusive. Any other value results in 400 Bad Request with rule BR-8.

Field Name          : customerName
Type                : String
Required            : No (loaded from appointment record)
Max Length          : 150 characters
Description         : Name of the customer associated with the appointment. Loaded from the appointment record. May be supplied in the request body if not resolvable from the appointment.
Validation          : If supplied, must not exceed 150 characters.

Field Name          : pickupTime
Type                : String (DateTime)
Required            : No (loaded from appointment record)
Format              : ISO 8601 UTC datetime. Example: 2025-06-15T09:30:00Z
Description         : Scheduled pickup time for the appointment. Loaded from the appointment record. May be supplied in the request body if not resolvable from the appointment.
Validation          : If supplied, must be a valid ISO 8601 datetime string.

--------------------------------------------------------------------------------

2.5 Example Request Body - QR_CODE Mode

verificationMode: QR_CODE
qrCodePayload: eyJhcHBvaW50bWVudElkIjoiYXBwdC0wMDEyMyIsInJlZ2lzdHJhdGlvbk51bWJlciI6IkFCMTIzQ0QifQ==
registrationNumber: AB123CD
vin: 1HGBH41JXMN109186
odometerReading: 45230
fuelLevel: THREE_QUARTER

--------------------------------------------------------------------------------

2.6 Example Request Body - MANUAL Mode

verificationMode: MANUAL
registrationNumber: XY456EF
vin: 2T1BURHE0JC043821
odometerReading: 12050
fuelLevel: 75
vehicleModel: Toyota Camry
customerName: Jane Smith
pickupTime: 2025-06-15T09:30:00Z

--------------------------------------------------------------------------------
SECTION 3: RESPONSE SPECIFICATION
--------------------------------------------------------------------------------

3.1 HTTP 201 Created

Condition: Vehicle verification session was successfully created, appointment status advanced to VEHICLE_VERIFIED, audit entry appended, and domain event emitted.

Response Body Fields:

Field Name              : verificationSessionId
Type                    : String (UUID)
Description             : Unique identifier of the newly created vehicle verification session.

Field Name              : appointmentId
Type                    : String (UUID)
Description             : Identifier of the appointment associated with this verification session.

Field Name              : chauffeurId
Type                    : String (UUID)
Description             : Identifier of the chauffeur who performed the verification.

Field Name              : verificationMode
Type                    : String (Enum)
Description             : The mode used for verification. Either QR_CODE or MANUAL.

Field Name              : registrationNumber
Type                    : String
Description             : Vehicle registration number captured during verification.

Field Name              : vin
Type                    : String
Description             : Vehicle Identification Number captured during verification.

Field Name              : vehicleModel
Type                    : String
Description             : Vehicle make and model associated with the appointment.

Field Name              : customerName
Type                    : String
Description             : Name of the customer associated with the appointment.

Field Name              : pickupTime
Type                    : String (ISO 8601 DateTime)
Description             : Scheduled pickup time from the appointment record.

Field Name              : odometerReading
Type                    : Number
Description             : Odometer reading captured at the time of verification.

Field Name              : fuelLevel
Type                    : String or Number
Description             : Fuel level captured at the time of verification.

Field Name              : appointmentStatus
Type                    : String
Description             : Updated appointment status. Value will be VEHICLE_VERIFIED.

Field Name              : createdAt
Type                    : String (ISO 8601 DateTime)
Description             : Timestamp at which the verification session was persisted.

Example 201 Response:

verificationSessionId: vsess-7f3a1b2c-4d5e-6f7a-8b9c-0d1e2f3a4b5c
appointmentId: appt-00123
chauffeurId: chfr-99887766-5544-3322-1100-aabbccddeeff
verificationMode: QR_CODE
registrationNumber: AB123CD
vin: 1HGBH41JXMN109186
vehicleModel: Mercedes-Benz E-Class
customerName: John Doe
pickupTime: 2025-06-15T09:30:00Z
odometerReading: 45230
fuelLevel: THREE_QUARTER
appointmentStatus: VEHICLE_VERIFIED
createdAt: 2025-06-15T08:47:12Z

--------------------------------------------------------------------------------

3.2 HTTP 400 Bad Request

Condition: One or more request fields fail validation. Covers missing mandatory fields, invalid formats, out-of-range values, or unrecognised enum values.

Response Body Fields:

Field Name      : status
Type            : Integer
Value           : 400

Field Name      : errorCode
Type            : String
Description     : Machine-readable error code identifying the specific validation failure.

Field Name      : message
Type            : String
Description     : Human-readable description of the validation error.

Field Name      : fieldErrors
Type            : Array of objects
Description     : List of individual field-level validation failures. Each entry contains fieldName, rejectedValue, and message.

Example 400 Response (missing VIN):

status: 400
errorCode: VALIDATION_ERROR
message: Request validation failed. See fieldErrors for details.
fieldErrors:
  - fieldName: vin
    rejectedValue: null
    message: VIN is required and must not be blank.

Example 400 Response (invalid odometerReading):

status: 400
errorCode: VALIDATION_ERROR
message: Request validation failed. See fieldErrors for details.
fieldErrors:
  - fieldName: odometerReading
    rejectedValue: -500
    message: Odometer reading must be a non-negative numeric value.

Example 400 Response (invalid fuelLevel):

status: 400
errorCode: VALIDATION_ERROR
message: Request validation failed. See fieldErrors for details.
fieldErrors:
  - fieldName: fuelLevel
    rejectedValue: 150
    message: Fuel level must be a value between 0 and 100 or a recognised fuel level indicator.

--------------------------------------------------------------------------------

3.3 HTTP 401 Unauthorized

Condition: The Authorization header is absent, the JWT is expired, the JWT signature is invalid, or the token cannot be parsed.

Response Body Fields:

Field Name      : status
Type            : Integer
Value           : 401

Field Name      : errorCode
Type            : String
Value           : UNAUTHORIZED

Field Name      : message
Type            : String
Description     : Human-readable explanation of the authentication failure.

Example 401 Response:

status: 401
errorCode: UNAUTHORIZED
message: Authentication token is missing or invalid. Please provide a valid Bearer JWT.

--------------------------------------------------------------------------------

3.4 HTTP 403 Forbidden

Condition: The caller is authenticated but

ENDPOINT DESIGN: PUT /api/v1/vehicle-condition-reports/sessions/{sessionId}/inventory

Source Requirement ID: SER-010-020-071
Source Activity ID: SER-010-020-071

================================================================================
SECTION 1: ENDPOINT IDENTIFICATION
================================================================================

Path            : /api/v1/vehicle-condition-reports/sessions/{sessionId}/inventory
HTTP Method     : PUT
Summary         : Submit the inventory checklist with item presence flags and optional
                  manually added item descriptions
Description     : Allows the chauffeur assigned to a vehicle condition report session to
                  submit or replace the full inventory checklist for that session. The
                  checklist captures the presence and condition status of all mandatory
                  standard vehicle accessories (AC charging cable, battery, booklet,
                  cigarette lighter, flat tyre repair kit) and optionally records any
                  additional non-standard items via free-text description. This endpoint
                  must be called during the pre-pickup phase of the appointment booking
                  stage (SER-010-020) to establish a baseline accessory record before
                  vehicle handover. PUT semantics apply: the full inventory is replaced
                  on each successful call.

================================================================================
SECTION 2: REQUEST SPECIFICATION
================================================================================

2.1 REQUEST HEADERS
--------------------
Header Name       : Authorization
Required          : Yes
Format            : Bearer <JWT token>
Description       : OAuth2/OIDC Bearer JWT. Must be a valid, non-expired token issued
                    by the authorised identity provider. The token sub claim is used to
                    identify the calling chauffeur.

Header Name       : Content-Type
Required          : Yes
Expected Value    : application/json
Description       : Request body must be JSON-encoded.

Header Name       : Accept
Required          : No
Expected Value    : application/json
Description       : Indicates the client expects a JSON response.

Header Name       : If-Match
Required          : Recommended (for optimistic concurrency control)
Format            : ETag value string (e.g. "v3" or a hash string)
Description       : If provided, the server will reject the request with HTTP 412 if the
                    current session version does not match the supplied ETag. Callers
                    should retrieve the current ETag from a prior GET response and supply
                    it here to prevent lost-update conflicts. If omitted, the server falls
                    back to pessimistic locking behaviour.

Header Name       : X-Request-ID
Required          : No
Format            : UUID v4
Description       : Optional client-supplied idempotency/correlation identifier for
                    tracing and deduplication across retries.

2.2 PATH PARAMETERS
--------------------
Parameter Name    : sessionId
Location          : Path
Type              : String
Format            : UUID v4
Required          : Yes
Description       : The unique identifier of the vehicle condition report session for
                    which the inventory checklist is being submitted. Must correspond to
                    an existing, active session record in the system.
Validation Rules  :
  - Must be a valid UUID v4 format.
  - Must not be null or empty.
  - Must resolve to an existing session record (enforced at business logic layer).

2.3 QUERY PARAMETERS
--------------------
None defined for this endpoint.

2.4 REQUEST BODY SCHEMA
------------------------
Content-Type: application/json

Top-level object fields:

Field Name        : inventoryItems
Type              : Array of InventoryItem objects
Required          : Yes
Min Items         : 5 (at minimum all five standard items must be present)
Max Items         : No hard system maximum defined; practical limit governed by payload
                    size constraints (see note below)
Description       : The complete list of inventory items being recorded for this session.
                    Must include all five standard items. May additionally include
                    optional manually added items.

Note on payload size: The total request body must not exceed the gateway-enforced payload
limit (typically 1 MB). Callers submitting large numbers of manually added items should
be aware of this constraint.

InventoryItem object fields:

Field Name        : itemCode
Type              : String
Required          : Yes
Min Length        : 1
Max Length        : 50
Pattern           : Alphanumeric and underscore characters only (^[A-Za-z0-9_]+$)
Description       : A system-defined code uniquely identifying the inventory item. For
                    standard items the codes are fixed and system-defined. For manually
                    added items the caller must supply a unique code within the payload.
Validation Rules  :
  - Must not be null or empty.
  - Must match the pattern ^[A-Za-z0-9_]+$ (no spaces or special characters).
  - For standard items, must match one of the five system-defined codes exactly.
  - Must be unique within the inventoryItems array (no duplicate itemCode values).

Field Name        : itemName
Type              : String
Required          : Yes
Min Length        : 1
Max Length        : 100
Description       : Human-readable name of the inventory item. For standard items this
                    value is fixed and must match the system-defined name. For manually
                    added items this is the caller-supplied name.
Validation Rules  :
  - Must not be null or empty.
  - Must not be whitespace-only.
  - Max 100 characters.

Field Name        : status
Type              : String (Enum)
Required          : Yes
Allowed Values    : PRESENT, ABSENT, DAMAGED
Description       : The recorded presence or condition status of the item at the time of
                    the inspection.
Validation Rules  :
  - Must not be null or empty.
  - Must be one of the three allowed enum values exactly (case-sensitive).

Field Name        : isStandard
Type              : Boolean
Required          : Yes
Description       : Indicates whether this item is a system-defined standard item (true)
                    or a manually added non-standard item (false).
Validation Rules  :
  - Must not be null.
  - Must be a boolean true or false.
  - For the five mandatory standard items this field must be true.
  - For manually added items this field must be false.

Field Name        : manualDescription
Type              : String
Required          : No (optional; applicable only when isStandard is false)
Min Length        : 1 (if provided)
Max Length        : 500
Description       : Free-text description for a manually added non-standard item. Must
                    not be blank or whitespace-only if supplied. Not applicable to
                    standard items; if supplied for a standard item it is ignored.
Validation Rules  :
  - Optional field; may be omitted entirely.
  - If present, must not be an empty string or whitespace-only string.
  - Max 500 characters.
  - Only meaningful when isStandard is false.

Standard Item Reference Table (system-defined fixed values):

  Item Code              Item Name
  ---------------------- --------------------------
  AC_CHARGING_CABLE      AC Charging Cable
  BATTERY                Battery
  BOOKLET                Booklet
  CIGARETTE_LIGHTER      Cigarette Lighter
  FLAT_TYRE_REPAIR_KIT   Flat Tyre Repair Kit

All five of the above itemCode values must appear in the inventoryItems array. Their
itemName values must match the system-defined names exactly. Their isStandard value must
be true.

Example Request Body:

  {
    "inventoryItems": [
      {
        "itemCode": "AC_CHARGING_CABLE",
        "itemName": "AC Charging Cable",
        "status": "PRESENT",
        "isStandard": true
      },
      {
        "itemCode": "BATTERY",
        "itemName": "Battery",
        "status": "PRESENT",
        "isStandard": true
      },
      {
        "itemCode": "BOOKLET",
        "itemName": "Booklet",
        "status": "ABSENT",
        "isStandard": true
      },
      {
        "itemCode": "CIGARETTE_LIGHTER",
        "itemName": "Cigarette Lighter",
        "status": "PRESENT",
        "isStandard": true
      },
      {
        "itemCode": "FLAT_TYRE_REPAIR_KIT",
        "itemName": "Flat Tyre Repair Kit",
        "status": "DAMAGED",
        "isStandard": true
      },
      {
        "itemCode": "CUSTOM_ITEM_001",
        "itemName": "Umbrella",
        "status": "PRESENT",
        "isStandard": false,
        "manualDescription": "Black compact umbrella found in rear seat pocket"
      }
    ]
  }

================================================================================
SECTION 3: RESPONSE SPECIFICATION
================================================================================

3.1 HTTP 200 OK - Successful Inventory Submission
--------------------------------------------------
Condition         : The inventory checklist was successfully validated and persisted
                    (or was identical to the existing record and idempotency was applied).
Content-Type      : application/json

Response Body Schema:

Field Name        : sessionId
Type              : String (UUID v4)
Description       : The session identifier for which the inventory was recorded.

Field Name        : inventoryUpdatedAt
Type              : String (ISO 8601 datetime with timezone)
Description       : The server-side timestamp at which the inventory was last written.
                    For idempotent re-submissions with no change, this reflects the
                    timestamp of the original write.

Field Name        : lastUpdatedByChauffeurId
Type              : String (UUID v4)
Description       : The identity of the chauffeur who last updated the inventory,
                    extracted from the JWT sub claim.

Field Name        : inventoryItems
Type              : Array of InventoryItem objects
Description       : The full inventory checklist as persisted, echoing back all items
                    including standard and manually added items.

Field Name        : etag
Type              : String
Description       : The current ETag / version identifier for the session record after
                    this write. Callers should store this value and supply it in the
                    If-Match header on subsequent PUT requests.

Field Name        : idempotent
Type              : Boolean
Description       : True if the request was detected as a duplicate of an existing
                    identical submission and no new write was performed. False if a new
                    write or overwrite occurred.

Example 200 Response:

  {
    "sessionId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
    "inventoryUpdatedAt": "2025-07-14T09:32:00Z",
    "lastUpdatedByChauffeurId": "c1a2b3d4-e5f6-7890-abcd-ef1234567890",
    "etag": "v4",
    "idempotent": false,
    "inventoryItems": [
      {
        "itemCode": "AC_CHARGING_CABLE",
        "itemName": "AC Charging Cable",
        "status": "PRESENT",
        "isStandard": true,
        "manualDescription": null
      },
      {
        "itemCode": "BATTERY",
        "itemName": "Battery",
        "status": "PRESENT",
        "isStandard": true,
        "manualDescription": null
      },
      {
        "itemCode": "BOOKLET",
        "itemName": "Booklet",
        "status": "ABSENT",
        "isStandard": true,
        "manualDescription": null
      },
      {
        "itemCode": "CIGARETTE_LIGHTER

ENDPOINT DESIGN: POST /api/v1/drop-requests

================================================================================
SECTION 1: ENDPOINT IDENTIFICATION
================================================================================

Path            : /api/v1/drop-requests
HTTP Method     : POST
Summary         : Create a new drop request by fetching and persisting CRM drop-service
                  details for a completed JC; auto-populates JC number and promised
                  delivery date/time.
Description     : This endpoint allows an authenticated Pickup Coordinator to create a
                  new drop request for a vehicle associated with a CRM service appointment
                  that has drop-service selection enabled. The system validates the
                  appointment and linked Job Card (JC) in CRM, auto-populates the JC
                  number and promised delivery date/time, persists the drop request record,
                  appends an immutable audit trail entry, and asynchronously notifies the
                  DBP pickup and drop scheduling dashboard.
Source Activity IDs : SER-010-020-093, SER-010-020-094


================================================================================
SECTION 2: REQUEST SPECIFICATION
================================================================================

2.1 REQUEST HEADERS
--------------------------------------------------------------------------------
Header Name       : Authorization
Required          : Yes
Format            : Bearer <JWT token>
Description       : OAuth2/OIDC Bearer JWT. Must contain role claim PICKUP_COORDINATOR
                    and dealership/service-centre claim. Token must not be expired.

Header Name       : Content-Type
Required          : Yes
Allowed Value     : application/json
Description       : Request body must be JSON-encoded.

Header Name       : Accept
Required          : No
Recommended Value : application/json
Description       : Indicates the client expects a JSON response.

Header Name       : X-Request-ID
Required          : No
Format            : UUID v4 string
Description       : Optional caller-supplied correlation ID for distributed tracing and
                    idempotency tracking. If supplied, echoed back in the response header.


2.2 PATH PARAMETERS
--------------------------------------------------------------------------------
None.


2.3 QUERY PARAMETERS
--------------------------------------------------------------------------------
None.


2.4 REQUEST BODY SCHEMA
--------------------------------------------------------------------------------
Content-Type : application/json

The request body is a JSON object. All fields listed below are at the top level
of the object unless otherwise noted.

Field Name                : serviceAppointmentNumber
Type                      : string
Required                  : Yes
Min Length                : 1
Max Length                : 100
Format                    : Alphanumeric, hyphens permitted. No leading or trailing
                            whitespace.
Regex                     : ^[A-Za-z0-9\-]{1,100}$
Description               : The unique identifier of the CRM service appointment for
                            which the drop request is being created. Used as the natural
                            idempotency key.
Validation Behaviour      : Rejected with 400 if absent or blank. Validated against CRM
                            for existence and active status (BR-2).

Field Name                : customerName
Type                      : string
Required                  : Yes
Min Length                : 1
Max Length                : 255
Format                    : Free text. Must not be blank or whitespace-only.
Description               : Full name of the customer associated with the service
                            appointment.
Validation Behaviour      : Rejected with 400 if absent or blank (BR-5).

Field Name                : customerContact
Type                      : string
Required                  : Yes
Min Length                : 7
Max Length                : 20
Format                    : Digits only, optionally prefixed with a plus sign for
                            international format.
Regex                     : ^\+?[0-9]{7,19}$
Description               : Primary contact number of the customer.
Validation Behaviour      : Rejected with 400 if absent, blank, or not matching the
                            expected format (BR-5).

Field Name                : vehicleRegistrationNumber
Type                      : string
Required                  : Yes
Min Length                : 1
Max Length                : 20
Format                    : Alphanumeric, spaces permitted between segments.
Regex                     : ^[A-Za-z0-9 ]{1,20}$
Description               : The vehicle registration (licence plate) number. Must match
                            the vehicle associated with the CRM service appointment.
Validation Behaviour      : Rejected with 400 if absent or blank (BR-5). Cross-validated
                            against CRM appointment record.

Field Name                : dropAddress
Type                      : object
Required                  : Yes
Description               : Structured address object representing the location to which
                            the vehicle is to be dropped.
Validation Behaviour      : Rejected with 400 if the object is absent or all sub-fields
                            are blank (BR-5).

  Sub-field               : dropAddress.line1
  Type                    : string
  Required                : Yes
  Min Length              : 1
  Max Length              : 255
  Description             : Street address line 1.

  Sub-field               : dropAddress.line2
  Type                    : string
  Required                : No
  Max Length              : 255
  Description             : Street address line 2 (apartment, suite, etc.).

  Sub-field               : dropAddress.city
  Type                    : string
  Required                : Yes
  Min Length              : 1
  Max Length              : 100
  Description             : City or locality name.

  Sub-field               : dropAddress.state
  Type                    : string
  Required                : Yes
  Min Length              : 1
  Max Length              : 100
  Description             : State or province.

  Sub-field               : dropAddress.postalCode
  Type                    : string
  Required                : Yes
  Min Length              : 4
  Max Length              : 10
  Regex                   : ^[A-Za-z0-9 \-]{4,10}$
  Description             : Postal or ZIP code.

  Sub-field               : dropAddress.country
  Type                    : string
  Required                : Yes
  Min Length              : 2
  Max Length              : 2
  Format                  : ISO 3166-1 alpha-2 country code (uppercase).
  Regex                   : ^[A-Z]{2}$
  Description             : Two-letter country code.

Field Name                : requestedDropDateTime
Type                      : string
Required                  : Yes
Format                    : ISO 8601 date-time with timezone offset.
                            Example: 2025-09-15T14:30:00+05:30
Regex                     : ^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}:\d{2})$
Description               : The date and time at which the customer requests the vehicle
                            to be dropped. Must be a future date-time and must not be
                            earlier than the JC promised delivery date-time (BR-6).
Validation Behaviour      : Rejected with 400 if absent or malformed. Rejected with 422
                            if in the past or earlier than promisedDeliveryDateTime (BR-6).

AUTO-POPULATED FIELDS (not supplied by caller; derived from CRM):
--------------------------------------------------------------------------------
The following fields are NOT accepted in the request body. They are fetched from
CRM and populated internally by the system before persistence.

Field Name                : jcNumber
Source                    : CRM Job Card linked to the service appointment.
DB Column                 : jc_number
Description               : The Job Card number associated with the service appointment.
                            Auto-populated from CRM (BR-8).

Field Name                : promisedDeliveryDateTime
Source                    : CRM Job Card promised delivery date and time field.
DB Column                 : promised_delivery_date_time
Description               : The date and time by which the vehicle is promised to be
                            delivered, as recorded on the JC in CRM. Auto-populated
                            from CRM (BR-8).

Field Name                : dropServiceSelected
Source                    : CRM service appointment drop-service selection flag.
DB Column                 : drop_service_selected
Description               : Boolean flag confirming drop service is enabled on the CRM
                            appointment. Auto-populated from CRM (BR-1, BR-3).


2.5 EXAMPLE REQUEST
--------------------------------------------------------------------------------
POST /api/v1/drop-requests
Authorization: Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9...
Content-Type: application/json
Accept: application/json
X-Request-ID: 7f3e1c2a-4b5d-4e6f-9a0b-1c2d3e4f5a6b

{
  "serviceAppointmentNumber": "SA-2025-00847",
  "customerName": "Rajesh Kumar",
  "customerContact": "+919876543210",
  "vehicleRegistrationNumber": "MH 12 AB 3456",
  "dropAddress": {
    "line1": "42 Shivaji Nagar",
    "line2": "Near Central Park",
    "city": "Pune",
    "state": "Maharashtra",
    "postalCode": "411005",
    "country": "IN"
  },
  "requestedDropDateTime": "2025-09-15T14:30:00+05:30"
}


================================================================================
SECTION 3: RESPONSE SPECIFICATION
================================================================================

3.1 HTTP 201 CREATED
--------------------------------------------------------------------------------
Condition   : Drop request successfully created, persisted, audit trail appended,
              and DBP notification enqueued.

Response Headers:
  Content-Type  : application/json
  Location      : /api/v1/drop-requests/{dropRequestId}
  X-Request-ID  : Echoed from request if supplied; system-generated UUID otherwise.

Response Body Schema:

  Field Name              : dropRequestId
  Type                    : string (UUID v4)
  Description             : System-generated unique identifier for the newly created
                            drop request.

  Field Name              : serviceAppointmentNumber
  Type                    : string
  Description             : The service appointment number from the request, confirmed.

  Field Name              : jcNumber
  Type                    : string
  Description             : Auto-populated Job Card number from CRM.

  Field Name              : promisedDeliveryDateTime
  Type                    : string (ISO 8601)
  Description             : Auto-populated promised delivery date-time from the JC.

  Field Name              : requestedDropDateTime
  Type                    : string (ISO 8601)
  Description             : The requested drop date-time as submitted and accepted.

  Field Name              : status
  Type                    : string
  Allowed Value           : CREATED
  Description             : Current status of the drop request immediately after creation.

  Field Name              : createdAt
  Type                    : string (ISO 8601)
  Description             : Server-side timestamp of record creation (UTC).

  Field Name              : dbpNotificationStatus
  Type                    : string
  Allowed Values          : QUEUED, SENT
  Description             : Indicates whether the DBP dashboard notification was
                            immediately sent or placed on the retry queue.

Example 201 Response Body:
{
  "dropRequestId": "d4e5f6a7-b8c9-4d0e-a1f2-b3c4d5e6f7a8",
  "serviceAppointmentNumber": "SA-2025-00847",
  "jcNumber": "JC-2025-003921",
  "promisedDeliveryDateTime": "2025-09-15T11:00:00+05:30",
  "requestedDropDateTime": "2025-09-15T14:30:00+05:30",
  "status": "CREATED",
  "createdAt": "2025-08-20T09:15:42Z",
  "dbpNotificationStatus": "QUEUED"
}

ENDPOINT DESIGN: GET /api/v1/drop-requests

Source Requirement ID: SER-010-020-093
Source Activity ID: SER-010-020-093


------------------------------------------------------------------------
SECTION 1: ENDPOINT IDENTIFICATION
------------------------------------------------------------------------

Path            : /api/v1/drop-requests
HTTP Method     : GET
Summary         : List drop requests with filtering by status, JC number,
                  vehicle registration, drop date range, and coordinator;
                  supports pagination.
Description     : Retrieves a paginated list of drop requests scoped to the
                  authenticated Pickup Coordinator's dealership or location.
                  Drop request data originates from CRM service appointments
                  that carry a confirmed drop-service selection. The response
                  is consumed by the DBP Pickup and Drop scheduling dashboard
                  to enable scheduling actions. Only non-terminal (active or
                  open) drop requests are returned by default unless an
                  explicit status filter overrides this behaviour. Each
                  returned record carries eight mandatory fields sourced from
                  the CRM service appointment. Every successful retrieval is
                  recorded in the audit trail.


------------------------------------------------------------------------
SECTION 2: REQUEST SPECIFICATION
------------------------------------------------------------------------

2.1 Request Headers

Header Name       : Authorization
Required          : Yes
Format            : Bearer <JWT token>
Description       : OAuth2 / OIDC Bearer JWT. Must carry a valid role claim
                    of PICKUP_COORDINATOR or ADMIN. Must not be expired.
                    Signature and issuer are validated server-side.

Header Name       : Accept
Required          : No (defaults to application/json)
Allowed Values    : application/json
Description       : Specifies the expected response media type.

Header Name       : X-Correlation-ID
Required          : No
Format            : UUID v4 string
Description       : Optional caller-supplied correlation identifier for
                    distributed tracing. If absent, the server generates one
                    and echoes it in the response header.

Header Name       : X-Request-ID
Required          : No
Format            : UUID v4 string
Description       : Optional idempotency / tracing identifier supplied by
                    the client. Echoed in the response for log correlation.


2.2 Path Parameters

None. This endpoint does not use path parameters.


2.3 Query Parameters

Parameter Name    : status
Type              : string (enum)
Required          : No
Default           : OPEN
Allowed Values    : OPEN, IN_PROGRESS, COMPLETED, CANCELLED, ALL
Description       : Filters drop requests by their current status. When
                    omitted, the system defaults to OPEN, which returns only
                    non-terminal records. Supplying ALL overrides the default
                    and returns records in every state. Supplying COMPLETED
                    or CANCELLED explicitly returns terminal-state records.
Validation        : Value must be one of the enumerated strings above.
                    Case-insensitive. Invalid values return HTTP 400.

Parameter Name    : jcNumber
Type              : string
Required          : No
Format            : Alphanumeric, 1 to 50 characters
Description       : Filters results to drop requests linked to the specified
                    Job Card (JC) number.
Validation        : Pattern: ^[A-Za-z0-9\-]{1,50}$
                    If supplied and no matching record exists, an empty list
                    is returned (not a 404).

Parameter Name    : vehicleRegistrationNumber
Type              : string
Required          : No
Format            : Alphanumeric with optional hyphens, 1 to 20 characters
Description       : Filters results to drop requests associated with the
                    specified vehicle registration number.
Validation        : Pattern: ^[A-Za-z0-9\-]{1,20}$
                    Case-insensitive match applied at the data store level.

Parameter Name    : dropDateFrom
Type              : string (date)
Required          : No
Format            : ISO 8601 date — YYYY-MM-DD
Description       : Lower bound (inclusive) of the requested drop date range
                    filter. Must be used in conjunction with dropDateTo when
                    a range is intended; may be supplied alone to filter from
                    a start date with no upper bound.
Validation        : Must be a valid calendar date. Must not be after
                    dropDateTo when both are supplied. Returns HTTP 400 if
                    the format is invalid or the range is logically inverted.

Parameter Name    : dropDateTo
Type              : string (date)
Required          : No
Format            : ISO 8601 date — YYYY-MM-DD
Description       : Upper bound (inclusive) of the requested drop date range
                    filter. Must be used in conjunction with dropDateFrom
                    when a range is intended; may be supplied alone to filter
                    up to an end date with no lower bound.
Validation        : Must be a valid calendar date. Must not be before
                    dropDateFrom when both are supplied. Returns HTTP 400 if
                    the format is invalid or the range is logically inverted.

Parameter Name    : coordinatorId
Type              : string
Required          : No
Format            : UUID v4 or system-assigned coordinator identifier string,
                    1 to 100 characters
Description       : Allows an ADMIN role caller to retrieve drop requests
                    scoped to a specific coordinator. For PICKUP_COORDINATOR
                    role callers, this parameter is ignored; the scope is
                    always derived from the JWT claims of the authenticated
                    user. ADMIN callers who omit this parameter receive all
                    drop requests within their authorised scope.
Validation        : Pattern: ^[A-Za-z0-9\-_]{1,100}$
                    If supplied by a PICKUP_COORDINATOR role caller, the
                    parameter is silently ignored (not an error).

Parameter Name    : page
Type              : integer
Required          : No
Default           : 1
Minimum           : 1
Description       : 1-based page number for paginated results.
Validation        : Must be a positive integer. Non-integer or zero/negative
                    values return HTTP 400.

Parameter Name    : pageSize
Type              : integer
Required          : No
Default           : 20
Minimum           : 1
Maximum           : 100
Description       : Number of drop request records to return per page.
Validation        : Must be an integer between 1 and 100 inclusive. Values
                    outside this range return HTTP 400.

Parameter Name    : sortBy
Type              : string (enum)
Required          : No
Default           : requestedDropDateTime
Allowed Values    : requestedDropDateTime, customerName,
                    vehicleRegistrationNumber, serviceAppointmentNumber
Description       : Field by which the result set is sorted.
Validation        : Must be one of the enumerated values. Invalid values
                    return HTTP 400.

Parameter Name    : sortOrder
Type              : string (enum)
Required          : No
Default           : ASC
Allowed Values    : ASC, DESC
Description       : Sort direction applied to the sortBy field.
Validation        : Must be ASC or DESC (case-insensitive). Invalid values
                    return HTTP 400.


2.4 Request Body

Not applicable. GET requests do not carry a request body.


------------------------------------------------------------------------
SECTION 3: RESPONSE SPECIFICATION
------------------------------------------------------------------------

3.1 HTTP 200 — Success

Description       : The request was processed successfully. A paginated list
                    of drop requests matching the applied filters and scoped
                    to the coordinator's dealership/location is returned.

Response Headers  :
  Content-Type        : application/json
  X-Correlation-ID    : Echo of the correlation ID (caller-supplied or
                        server-generated UUID).
  X-Request-ID        : Echo of the request ID if supplied by the caller.

Response Body Schema:

  Field: success
  Type: boolean
  Description: Always true for a 200 response.
  Example: true

  Field: data
  Type: object
  Description: Wrapper object containing the result list and pagination
               metadata.

    Field: data.dropRequests
    Type: array of DropRequest objects
    Description: List of drop request records matching the query. May be
                 an empty array if no records match the filters.

      Each DropRequest object contains:

      Field: serviceAppointmentNumber
      Type: string
      Required in response: Yes
      Description: Unique identifier of the CRM service appointment linked
                   to this drop request.
      Example: "SA-2024-00123"

      Field: dropServiceSelection
      Type: string
      Required in response: Yes
      Description: The drop-service type selected on the CRM service
                   appointment (e.g., HOME_DROP, OFFICE_DROP).
      Example: "HOME_DROP"

      Field: customerName
      Type: string
      Required in response: Yes
      Description: Full name of the customer associated with the service
                   appointment.
      Example: "Rajesh Kumar"

      Field: customerContact
      Type: string
      Required in response: Yes
      Description: Primary contact number or email of the customer.
      Example: "+91-9876543210"

      Field: vehicleRegistrationNumber
      Type: string
      Required in response: Yes
      Description: Registration number of the vehicle associated with the
                   service appointment.
      Example: "MH12AB1234"

      Field: dropAddress
      Type: string
      Required in response: Yes
      Description: Full address to which the vehicle is to be dropped.
      Example: "42, Park Street, Pune, Maharashtra 411001"

      Field: requestedDropDateTime
      Type: string (ISO 8601 datetime)
      Required in response: Yes
      Description: The date and time requested by the customer for the
                   vehicle drop.
      Example: "2025-07-15T10:30:00+05:30"

      Field: linkedJcNumber
      Type: string
      Required in response: Yes
      Description: Job Card number linked to this drop request in the CRM.
      Example: "JC-2024-00456"

      Field: status
      Type: string
      Required in response: Yes
      Description: Current status of the drop request.
      Example: "OPEN"

      Field: crmSyncTimestamp
      Type: string (ISO 8601 datetime)
      Required in response: Yes
      Description: Timestamp of the last successful synchronisation of this
                   record from CRM.
      Example: "2025-07-14T08:00:00+05:30"

      Field: isDataStale
      Type: boolean
      Required in response: Yes
      Description: Indicates whether the record's CRM sync timestamp exceeds
                   the acceptable staleness threshold. True means the data
                   may not reflect the latest CRM state.
      Example: false

ENDPOINT DESIGN DOCUMENT
=========================

Endpoint: PATCH /api/v1/trips/{tripId}/status


------------------------------------------------------------------------
SECTION 1 - ENDPOINT OVERVIEW
------------------------------------------------------------------------

Path            : /api/v1/trips/{tripId}/status
HTTP Method     : PATCH
Summary         : Transition the trip to a new lifecycle status and emit corresponding domain events
Source Activity IDs : SER-010-020-078, SER-010-020-082, SER-010-020-088, SER-010-020-122

Description:
This endpoint allows an authenticated and authorised chauffeur to advance a trip through its
defined lifecycle state machine. A single status field is supplied in the request body. The
system validates the caller's identity, verifies the requested transition is permitted from the
trip's current state, persists the new status with a transition timestamp, writes an immutable
audit trail entry, and conditionally triggers downstream actions depending on the target status
(OTP dispatch for ARRIVED_AT_PICKUP, real-time tracking initiation for EN_ROUTE_TO_PICKUP,
trip detail surfacing for ASSIGNED). CRM and DBP systems are notified asynchronously. Relevant
stakeholders receive notifications via ICP, WhatsApp, SMS, DBP, and CRM channels as applicable.


------------------------------------------------------------------------
SECTION 2 - REQUEST SPECIFICATION
------------------------------------------------------------------------

2.1 Request Headers
-------------------

Header Name       : Authorization
Required          : Yes
Format            : Bearer <JWT token>
Description       : OAuth2 / OIDC Bearer token. Must be a valid, non-expired JWT issued by the
                    configured identity provider. The token must carry the authenticated user's
                    subject claim (sub) and role claims. Absence or invalidity results in 401.

Header Name       : Content-Type
Required          : Yes
Expected Value    : application/json
Description       : Request body must be JSON-encoded. Any other content type results in 415.

Header Name       : X-Request-ID
Required          : No (Recommended)
Format            : UUID v4
Description       : Client-supplied correlation identifier for distributed tracing and log
                    correlation. If absent, the system generates one internally.

Header Name       : Accept
Required          : No
Expected Value    : application/json
Description       : Indicates the client expects a JSON response.


2.2 Path Parameters
-------------------

Parameter Name : tripId
Location       : Path
Type           : String
Required       : Yes
Format         : Non-empty string conforming to the system's internal trip identifier format
                 (UUID v4 recommended; exact regex: ^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$)
Min Length     : 36 characters (UUID canonical form)
Max Length     : 36 characters (UUID canonical form)
Description    : Unique identifier of the trip whose status is to be updated.
Validation     : Must be present, non-empty, and match the expected identifier format.
                 Missing, empty, or malformed values trigger BR-11 and return 400.


2.3 Query Parameters
--------------------

None defined for this endpoint.


2.4 Request Body Schema
-----------------------

Content-Type : application/json
Required     : Yes

Field Name : status
Type       : String (Enum)
Required   : Yes
Allowed Values:
    ASSIGNED
    EN_ROUTE_TO_PICKUP
    ARRIVED_AT_PICKUP
    IN_PROGRESS
    COMPLETED
    CANCELLED
Description : The target lifecycle status to which the trip should be transitioned.
              Must be one of the recognised enum values listed above.
              Unrecognised values trigger BR-2 and return 422.
              Values that represent an invalid transition from the current state trigger BR-3
              and return 409.

Request Body Example:

    {
        "status": "EN_ROUTE_TO_PICKUP"
    }

Full Request Body Validation Rules:

    - The body must be a valid JSON object.
    - The "status" field must be present; absence returns 400.
    - The "status" field must be a non-null, non-empty string.
    - The "status" value must match one of the defined enum values (case-sensitive).
    - No additional fields are required; unrecognised fields are ignored.


------------------------------------------------------------------------
SECTION 3 - RESPONSE SPECIFICATION
------------------------------------------------------------------------

3.1 HTTP 200 - Success (Status Updated or Idempotent No-Op)
------------------------------------------------------------

Returned when the status transition is successfully applied, or when the trip is already in the
requested status (idempotent no-op).

Response Body Schema:

    Field: tripId
    Type: String
    Description: The unique identifier of the trip.

    Field: previousStatus
    Type: String
    Description: The status of the trip before this update was applied.
                 On idempotent no-op, this equals the current (unchanged) status.

    Field: currentStatus
    Type: String
    Description: The status of the trip after this update.

    Field: statusUpdatedAt
    Type: String (ISO 8601 datetime, UTC)
    Description: The timestamp at which the status transition was recorded.

    Field: tripDetails
    Type: Object (conditionally populated)
    Description: Populated when the new status is ASSIGNED. Contains trip detail fields
                 surfaced to the chauffeur per BR-5.

        Sub-field: registrationNumber
        Type: String
        Description: Vehicle registration number.

        Sub-field: vehicleName
        Type: String
        Description: Name or model of the assigned vehicle.

        Sub-field: pickupDate
        Type: String (ISO 8601 date, YYYY-MM-DD)
        Description: Scheduled pickup date.

        Sub-field: pickupTime
        Type: String (HH:MM, 24-hour)
        Description: Scheduled pickup time.

        Sub-field: dropLocation
        Type: String
        Description: Drop-off location description or address.

    Field: message
    Type: String
    Description: Human-readable confirmation message.

Response Example (status transition applied):

    {
        "tripId": "a3f1c2d4-1234-4abc-8def-0987654321ab",
        "previousStatus": "ASSIGNED",
        "currentStatus": "EN_ROUTE_TO_PICKUP",
        "statusUpdatedAt": "2025-06-15T09:32:00Z",
        "tripDetails": null,
        "message": "Trip status successfully updated to EN_ROUTE_TO_PICKUP."
    }

Response Example (ASSIGNED transition with trip details):

    {
        "tripId": "a3f1c2d4-1234-4abc-8def-0987654321ab",
        "previousStatus": "PENDING_ASSIGNMENT",
        "currentStatus": "ASSIGNED",
        "statusUpdatedAt": "2025-06-15T08:00:00Z",
        "tripDetails": {
            "registrationNumber": "AB-1234-CD",
            "vehicleName": "Mercedes-Benz S-Class",
            "pickupDate": "2025-06-15",
            "pickupTime": "10:30",
            "dropLocation": "Dubai International Airport, Terminal 3"
        },
        "message": "Trip status successfully updated to ASSIGNED."
    }

Response Example (idempotent no-op):

    {
        "tripId": "a3f1c2d4-1234-4abc-8def-0987654321ab",
        "previousStatus": "EN_ROUTE_TO_PICKUP",
        "currentStatus": "EN_ROUTE_TO_PICKUP",
        "statusUpdatedAt": "2025-06-15T09:32:00Z",
        "tripDetails": null,
        "message": "Trip is already in the requested status. No changes applied."
    }


3.2 HTTP 400 - Bad Request
--------------------------

Returned when the request is structurally invalid, the tripId path parameter is missing or
malformed, or the request body is missing required fields.

Applicable Business Rules: BR-11

Response Body Schema:

    Field: errorCode
    Type: String
    Description: Machine-readable error code.

    Field: errorMessage
    Type: String
    Description: Human-readable description of the error.

    Field: details
    Type: Array of Objects
    Description: Field-level validation errors.

        Sub-field: field
        Type: String
        Description: The name of the field that failed validation.

        Sub-field: issue
        Type: String
        Description: Description of the specific validation failure.

Response Example:

    {
        "errorCode": "INVALID_REQUEST",
        "errorMessage": "Invalid or missing tripId.",
        "details": [
            {
                "field": "tripId",
                "issue": "tripId must be a valid UUID v4 identifier."
            }
        ]
    }


3.3 HTTP 401 - Unauthorised
---------------------------

Returned when the Bearer JWT token is absent, expired, or invalid.

Response Body Schema:

    Field: errorCode
    Type: String

    Field: errorMessage
    Type: String

Response Example:

    {
        "errorCode": "UNAUTHORISED",
        "errorMessage": "Authentication token is missing or invalid."
    }


3.4 HTTP 403 - Forbidden
------------------------

Returned when the authenticated caller is not the chauffeur assigned to the trip.

Applicable Business Rules: BR-4

Response Body Schema:

    Field: errorCode
    Type: String

    Field: errorMessage
    Type: String

Response Example:

    {
        "errorCode": "FORBIDDEN",
        "errorMessage": "Caller is not authorised to update the status of this trip."
    }


3.5 HTTP 404 - Not Found
------------------------

Returned when no trip record exists for the supplied tripId.

Applicable Business Rules: BR-1

Response Body Schema:

    Field: errorCode
    Type: String

    Field: errorMessage
    Type: String

Response Example:

    {
        "errorCode": "TRIP_NOT_FOUND",
        "errorMessage": "Trip not found for the provided tripId."
    }


3.6 HTTP 409 - Conflict
-----------------------

Returned in two scenarios:
    (a) The trip is already in a terminal state (COMPLETED or CANCELLED) - BR-10.
    (b) The requested status transition is not permitted from the current state - BR-3.

Response Body Schema:

    Field: errorCode
    Type: String

    Field: errorMessage
    Type: String

    Field: currentStatus
    Type: String
    Description: The trip's current status at the time of the conflict.

    Field: requestedStatus
    Type: String
    Description: The status value that was requested.

Response Example (terminal state):

    {
        "errorCode": "TERMINAL_STATE_CONFLICT",
        "errorMessage": "Trip is in a terminal state and cannot be updated.",
        "currentStatus": "COMPLETED",
        "requestedStatus": "IN_PROGRESS"
    }

Response Example (invalid transition):

    {
        "errorCode": "INVALID_STATUS_TRANSITION",
        "errorMessage": "Invalid status transition from current trip state.",
        "currentStatus": "ARRIVED_AT_PICKUP",
        "requestedStatus": "EN_ROUTE_TO_PICKUP"
    }


3.7 HTTP 422 - Unprocessable Entity
------------------------------------

Returned when the status value in the request body is not a recognised enum value.

Applicable Business Rules: BR-2

Response Body Schema:

    Field: errorCode
    Type: String

    Field: errorMessage
    Type: String

    Field: details
    Type: Array of Objects

        Sub-field: field
        Type: String

        Sub-field: issue
        Type: String

Response Example:

    {
        "errorCode": "VALIDATION_ERROR",
        "errorMessage": "Invalid trip status value provided.",
        "details": [
            {
                "field": "status",
                "issue": "Value 'DEPARTED' is not a recognised trip status. Allowed values: ASSIGNED, EN_ROUTE_TO_PICKUP, ARRIVED_AT_PICKUP, IN_PROGRESS, COMPLETED, CANCELLED."
            }
        ]
    }


3.8 HTTP 500 - Internal Server Error
--------------------------------------

Returned when an unexpected server-side error occurs, including unrecoverable failures in
critical synchronous downstream calls (e.g. audit trail write failure after retries, OTP
generation failure after retries).

Response Body Schema:

    Field: errorCode
    Type: String

    Field: errorMessage
    Type: String

    Field: correlationId
    Type: String
    Description: The request correlation identifier for support and tracing purposes.

Response Example:

    {
        "errorCode": "INTERNAL_SERVER_ERROR",
        "errorMessage": "An unexpected error occurred while processing the request. Please contact support.",

ENDPOINT: GET /api/v1/notifications/health

--------------------------------------------------------------------------------
SECTION 1: ENDPOINT IDENTIFICATION
--------------------------------------------------------------------------------

Path            : /api/v1/notifications/health
HTTP Method     : GET
Summary         : Health check endpoint returning connectivity status for each
                  downstream notification channel.
Description     : Performs a lightweight, synchronous connectivity probe against
                  each of the five downstream notification channels (ICP,
                  WhatsApp, SMS, DBP, CRM) and returns an individual UP or DOWN
                  status per channel together with an aggregated overall health
                  roll-up (UP, DEGRADED, or DOWN). This endpoint is intended for
                  consumption by the monitoring stack, API gateway health probes,
                  and the Pickup Coordinator dashboard to surface degraded
                  notification capability before dispatching time-sensitive
                  messages such as OTPs, chauffeur assignment confirmations, and
                  delay alerts. The endpoint is fully read-only; no domain state
                  is mutated by any invocation.

--------------------------------------------------------------------------------
SECTION 2: REQUEST SPECIFICATION
--------------------------------------------------------------------------------

2.1 Request Headers

Header Name     : Authorization
Required        : Yes
Format          : Bearer <JWT>
Description     : A valid, non-expired Bearer JWT token issued by the platform
                  OAuth2/OIDC provider. The token must carry a recognised role
                  claim of pickup_coordinator or system. Token TTL is 30 minutes.
                  The service validates the JWT signature, expiry (exp claim),
                  and role claim before executing any health check logic.

Header Name     : Content-Type
Required        : No (GET request; no request body)
Notes           : Not applicable for this endpoint.

2.2 Path Parameters

None.

2.3 Query Parameters

None.

2.4 Request Body

None. This is a GET endpoint with no request body.

2.5 JWT Token Structure (expected claims)

Claim           : sub
Type            : string
Description     : User identifier (user_id).

Claim           : role
Type            : string
Description     : Role of the authenticated principal. Must be one of
                  pickup_coordinator or system for this endpoint.

Claim           : dealership_id
Type            : string
Description     : Identifier of the dealership associated with the principal.

Claim           : iat
Type            : integer (Unix epoch)
Description     : Issued-at time.

Claim           : exp
Type            : integer (Unix epoch)
Description     : Expiry time. Token must not be expired at time of request.

Claim           : jti
Type            : string
Description     : JWT unique identifier.

--------------------------------------------------------------------------------
SECTION 3: RESPONSE SPECIFICATION
--------------------------------------------------------------------------------

3.1 HTTP 200 - Success (health check executed; channels may be UP or DOWN)

Description     : The health check executed successfully. A 200 status indicates
                  the health check itself ran to completion, not that all channels
                  are healthy. Per-channel and overall status must be inspected
                  by the caller to determine notification readiness.

Response Body Schema (NotificationHealthResponse):

Field           : overall
Type            : string
Required        : Yes
Allowed Values  : UP, DEGRADED, DOWN
Description     : Aggregated roll-up of all channel statuses.
                  UP       - all five channels are UP.
                  DEGRADED - at least one channel is DOWN and at least one is UP.
                  DOWN     - all five channels are DOWN.

Field           : checkedAt
Type            : string (ISO 8601 date-time with UTC offset)
Format          : yyyy-MM-ddTHH:mm:ssZ
Required        : Yes
Description     : Server-side timestamp at which the health check was evaluated.
                  This is never a cached value; it reflects the actual evaluation
                  time of the current invocation.

Field           : channels
Type            : object
Required        : Yes
Description     : Map of individual channel probe results.

Field           : channels.ICP
Type            : string
Required        : Yes
Allowed Values  : UP, DOWN
Description     : Connectivity probe result for the ICP Notification Gateway.

Field           : channels.WhatsApp
Type            : string
Required        : Yes
Allowed Values  : UP, DOWN
Description     : Connectivity probe result for the WhatsApp Notification Gateway.

Field           : channels.SMS
Type            : string
Required        : Yes
Allowed Values  : UP, DOWN
Description     : Connectivity probe result for the SMS Notification Gateway.

Field           : channels.DBP
Type            : string
Required        : Yes
Allowed Values  : UP, DOWN
Description     : Connectivity probe result for the DBP Integration Layer.

Field           : channels.CRM
Type            : string
Required        : Yes
Allowed Values  : UP, DOWN
Description     : Connectivity probe result for the CRM Integration Layer.

Example Payload - All channels UP:

overall: UP
checkedAt: 2025-07-14T10:30:00Z
channels:
  ICP: UP
  WhatsApp: UP
  SMS: UP
  DBP: UP
  CRM: UP

Example Payload - Degraded (one channel DOWN):

overall: DEGRADED
checkedAt: 2025-07-14T10:30:05Z
channels:
  ICP: UP
  WhatsApp: DOWN
  SMS: UP
  DBP: UP
  CRM: UP

Example Payload - All channels DOWN:

overall: DOWN
checkedAt: 2025-07-14T10:30:10Z
channels:
  ICP: DOWN
  WhatsApp: DOWN
  SMS: DOWN
  DBP: DOWN
  CRM: DOWN

--------------------------------------------------------------------------------

3.2 HTTP 401 - Unauthorized

Description     : The request did not include a valid Bearer JWT token, the token
                  is expired, or the token signature could not be verified.

Response Body Schema:

Field           : errorCode
Type            : string
Value           : UNAUTHORIZED

Field           : message
Type            : string
Value           : Missing or invalid Bearer JWT token.

Example Payload:

errorCode: UNAUTHORIZED
message: Missing or invalid Bearer JWT token.

--------------------------------------------------------------------------------

3.3 HTTP 403 - Forbidden

Description     : A valid JWT was presented but the role claim does not include
                  pickup_coordinator or system. Callers with chauffeur or
                  customer roles are denied. The channel probes are not executed.

Response Body Schema:

Field           : errorCode
Type            : string
Value           : FORBIDDEN

Field           : message
Type            : string
Value           : Authenticated principal does not have the required role to
                  invoke this endpoint.

Example Payload:

errorCode: FORBIDDEN
message: Authenticated principal does not have the required role to invoke
         this endpoint.

--------------------------------------------------------------------------------

3.4 HTTP 400 - Bad Request

Description     : Not expected under normal operation for this endpoint given
                  there are no request parameters or body. May be returned by
                  the API gateway if the request is structurally malformed (e.g.
                  invalid header syntax).

Response Body Schema:

Field           : errorCode
Type            : string
Value           : BAD_REQUEST

Field           : message
Type            : string
Value           : The request is malformed or contains invalid syntax.

--------------------------------------------------------------------------------

3.5 HTTP 404 - Not Found

Description     : Returned if the endpoint path is incorrect or the route is not
                  registered. Not expected under normal operation.

Response Body Schema:

Field           : errorCode
Type            : string
Value           : NOT_FOUND

Field           : message
Type            : string
Value           : The requested resource could not be found.

--------------------------------------------------------------------------------

3.6 HTTP 500 - Internal Server Error

Description     : An unhandled exception occurred within the health check
                  execution path, or the NotificationDispatchService itself is
                  unavailable and unable to initiate the channel probes. This is
                  distinct from individual channel probe failures, which are
                  reported as DOWN within a 200 response.

Response Body Schema:

Field           : errorCode
Type            : string
Value           : INTERNAL_SERVER_ERROR

Field           : message
Type            : string
Value           : Unexpected server error prevented the health check from
                  executing.

Example Payload:

errorCode: INTERNAL_SERVER_ERROR
message: Unexpected server error prevented the health check from executing.

--------------------------------------------------------------------------------
SECTION 4: BUSINESS RULES
--------------------------------------------------------------------------------

Rule ID         : BR-1
Category        : Pre-condition
Trigger         : Any request is received at this endpoint.
Description     : The caller must present a valid Bearer JWT token issued by the
                  platform OAuth2/OIDC provider. The token must not be expired
                  and must carry a recognised role claim.
Expected Behaviour: The service validates the JWT signature, expiry, and role
                  claim before executing the health check logic.
Error Code      : 401
Error Message   : Missing or invalid Bearer JWT token.

Rule ID         : BR-2
Category        : Validation
Trigger         : A valid JWT is present but the role claim does not include
                  pickup_coordinator or system.
Description     : The authenticated principal must hold a role that is permitted
                  to invoke this endpoint. Callers with chauffeur or customer
                  roles are denied.
Expected Behaviour: The service returns 403 Forbidden without executing the
                  channel connectivity probes.
Error Code      : 403
Error Message   : Authenticated principal does not have the required role to
                  invoke this endpoint.

Rule ID         : BR-3
Category        : Business
Trigger         : A valid, authorised GET request is received.
Description     : The health check must probe all five downstream notification
                  channels (ICP, WhatsApp, SMS, DBP, CRM) and report an
                  individual UP or DOWN status for each.
Expected Behaviour: The service performs a lightweight connectivity probe against
                  each channel and populates the channels map

ENDPOINT: GET /api/v1/delay-detection/health

--------------------------------------------------------------------------------
SECTION 1: ENDPOINT OVERVIEW
--------------------------------------------------------------------------------

Path            : /api/v1/delay-detection/health
HTTP Method     : GET
Summary         : Liveness and readiness health-check endpoint confirming the
                  scheduler service and its Map API dependency are reachable
                  and the job thread is alive.
Description     : Returns a structured health snapshot of the
                  DelayDetectionSchedulerService. The response includes the
                  overall system status (UP, DEGRADED, or DOWN), the state of
                  the background scheduler job thread, the last and next
                  execution timestamps, the count of active trips currently
                  being monitored, and the Map API integration layer circuit-
                  breaker state with its most recent probe latency. This
                  endpoint is purely read-only; no state is mutated and no
                  audit event is emitted. HTTP 200 is always returned when the
                  handler itself executes successfully, even when individual
                  components are degraded or down, so that monitoring systems
                  can parse the structured body rather than treating a non-200
                  as a network failure.

--------------------------------------------------------------------------------
SECTION 2: REQUEST SPECIFICATION
--------------------------------------------------------------------------------

2.1 Request Headers

Header Name       : Authorization
Required          : Conditional (required for external callers; exempt for
                    in-cluster Kubernetes liveness and readiness probes)
Format            : Bearer <JWT>
Description       : OAuth2 / OIDC-issued JWT. Must be a valid, non-expired
                    token signed by the trusted identity provider. The token
                    payload must contain a roles claim that includes at least
                    one of: pickup_coordinator, system.

Header Name       : Content-Type
Required          : Not applicable (GET request; no request body)

Header Name       : Accept
Required          : Optional
Allowed Values    : application/json
Default           : application/json

2.2 Path Parameters

None.

2.3 Query Parameters

None.

2.4 Request Body

None. This is a GET endpoint and carries no request body.

--------------------------------------------------------------------------------
SECTION 3: RESPONSE SPECIFICATION
--------------------------------------------------------------------------------

3.1 HTTP 200 - Health Snapshot Returned Successfully

Returned whenever the health-check handler itself executes without a fatal
internal error, regardless of whether the scheduler or Map API is healthy.
Monitoring systems must inspect the overallStatus field in the body to
determine the true health state.

Response Body Schema:

Field                          : overallStatus
Type                           : string
Required                       : true
Allowed Values                 : UP, DEGRADED, DOWN
Description                    : Worst-case composite status derived from the
                                 scheduler thread state and the Map API circuit-
                                 breaker state. UP when scheduler thread is alive
                                 and Map API circuit breaker is CLOSED. DEGRADED
                                 when Map API circuit breaker is HALF_OPEN or the
                                 scheduler has been idle beyond its expected
                                 interval. DOWN when the scheduler thread is
                                 stopped or the Map API circuit breaker is OPEN.

Field                          : checkedAt
Type                           : string (ISO 8601 UTC datetime)
Required                       : true
Format                         : yyyy-MM-ddTHH:mm:ssZ
Description                    : Timestamp at which this health snapshot was
                                 assembled, expressed in UTC.

Field                          : scheduler (object)
Required                       : true
Description                    : Contains the state of the background delay-
                                 detection job thread.

  Sub-field                    : scheduler.jobThreadAlive
  Type                         : boolean
  Required                     : true
  Description                  : True if the background scheduler job thread is
                                 running and responsive; false if the thread has
                                 stopped or cannot be introspected.

  Sub-field                    : scheduler.lastExecutedAt
  Type                         : string (ISO 8601 UTC datetime) or null
  Required                     : true
  Format                       : yyyy-MM-ddTHH:mm:ssZ
  Description                  : Timestamp of the most recent successful
                                 execution of the delay-detection job. Null if
                                 the job has never executed since service start.

  Sub-field                    : scheduler.nextScheduledAt
  Type                         : string (ISO 8601 UTC datetime) or null
  Required                     : true
  Format                       : yyyy-MM-ddTHH:mm:ssZ
  Description                  : Timestamp of the next scheduled execution of
                                 the delay-detection job. Null if the scheduler
                                 thread is not alive.

  Sub-field                    : scheduler.activeTripsMonitored
  Type                         : integer
  Required                     : true
  Minimum                      : 0
  Description                  : Count of active trips currently being monitored
                                 by the delay-detection scheduler at the time of
                                 the health check.

Field                          : mapApi (object)
Required                       : true
Description                    : Contains the state of the Map API integration
                                 layer as observed through the circuit breaker.

  Sub-field                    : mapApi.circuitBreakerState
  Type                         : string
  Required                     : true
  Allowed Values                : CLOSED, OPEN, HALF_OPEN
  Description                  : Current state of the Map API circuit breaker.
                                 CLOSED indicates normal operation. OPEN
                                 indicates the Map API is considered unavailable
                                 and no live probes are being attempted. HALF_OPEN
                                 indicates the circuit breaker is testing
                                 recovery.

  Sub-field                    : mapApi.latencyMs
  Type                         : integer or null
  Required                     : true
  Minimum                      : 0
  Description                  : Round-trip latency in milliseconds of the most
                                 recent Map API probe. Null if no probe has been
                                 attempted or the circuit breaker is OPEN and no
                                 cached value is available.

  Sub-field                    : mapApi.status
  Type                         : string
  Required                     : true
  Allowed Values                : UP, DOWN
  Description                  : Simplified connectivity status of the Map API.
                                 UP when circuit breaker is CLOSED. DOWN when
                                 circuit breaker is OPEN or HALF_OPEN with a
                                 failed probe.

Example Response Body (HTTP 200, overallStatus UP):

  overallStatus       : UP
  checkedAt           : 2025-06-15T10:32:00Z
  scheduler
    jobThreadAlive    : true
    lastExecutedAt    : 2025-06-15T10:31:45Z
    nextScheduledAt   : 2025-06-15T10:32:45Z
    activeTripsMonitored : 42
  mapApi
    circuitBreakerState : CLOSED
    latencyMs           : 87
    status              : UP

Example Response Body (HTTP 200, overallStatus DEGRADED):

  overallStatus       : DEGRADED
  checkedAt           : 2025-06-15T10:35:00Z
  scheduler
    jobThreadAlive    : true
    lastExecutedAt    : 2025-06-15T10:31:45Z
    nextScheduledAt   : 2025-06-15T10:35:45Z
    activeTripsMonitored : 38
  mapApi
    circuitBreakerState : HALF_OPEN
    latencyMs           : 1240
    status              : DOWN

Example Response Body (HTTP 200, overallStatus DOWN):

  overallStatus       : DOWN
  checkedAt           : 2025-06-15T10:40:00Z
  scheduler
    jobThreadAlive    : false
    lastExecutedAt    : 2025-06-15T10:31:45Z
    nextScheduledAt   : null
    activeTripsMonitored : 0
  mapApi
    circuitBreakerState : OPEN
    latencyMs           : null
    status              : DOWN

3.2 HTTP 401 - Authentication Failure

Returned when an external caller presents a missing, malformed, or expired
Bearer JWT token.

Response Body Schema:

Field         : errorCode
Type          : string
Value         : AUTH_TOKEN_INVALID

Field         : message
Type          : string
Value         : Missing or invalid Bearer JWT token.

Field         : timestamp
Type          : string (ISO 8601 UTC datetime)

Example Response Body:

  errorCode   : AUTH_TOKEN_INVALID
  message     : Missing or invalid Bearer JWT token.
  timestamp   : 2025-06-15T10:32:00Z

3.3 HTTP 403 - Authorisation Failure

Returned when the authenticated principal does not hold the pickup_coordinator
or system role.

Response Body Schema:

Field         : errorCode
Type          : string
Value         : ACCESS_DENIED

Field         : message
Type          : string
Value         : Authenticated principal does not have the required role to
                invoke this endpoint.

Field         : timestamp
Type          : string (ISO 8601 UTC datetime)

Example Response Body:

  errorCode   : ACCESS_DENIED
  message     : Authenticated principal does not have the required role to
                invoke this endpoint.
  timestamp   : 2025-06-15T10:32:00Z

3.4 HTTP 500 - Internal Server Error

Returned only when an unhandled exception or fatal error prevents the health-
check handler itself from executing. This is distinct from a DOWN status in
the response body; a 500 means the handler could not produce any structured
response at all.

Response Body Schema:

Field         : errorCode
Type          : string
Value         : HEALTH_CHECK_EXECUTION_FAILED

Field         : message
Type          : string
Value         : Unexpected server error prevented the health check from
                executing.

Field         : timestamp
Type          : string (ISO 8601 UTC datetime)

Example Response Body:

  errorCode   : HEALTH_CHECK_

ENDPOINT DESIGN: GET /api/v1/appointment-orchestration/{appointmentId}/status

================================================================================
SECTION 1: ENDPOINT IDENTIFICATION
================================================================================

Path            : /api/v1/appointment-orchestration/{appointmentId}/status
HTTP Method     : GET
Summary         : Retrieve current orchestration state, allocation status, active
                  chauffeur, ETA, exception flag, and linked JC for the Pickup
                  Coordinator dashboard
Source Requirements : SER-010-020-003, SER-010-020-010
Source Activity IDs : SER-010-020-003, SER-010-020-010


================================================================================
SECTION 2: REQUEST SPECIFICATION
================================================================================

2.1 REQUEST HEADERS
--------------------------------------------------------------------------------

Header Name       : Authorization
Required          : Yes
Format            : Bearer <token>
Description       : OAuth2 / OIDC JWT access token. Must be non-expired, correctly
                    signed by the trusted issuer, and carry a role claim mapping to
                    one of the permitted roles. Absence or invalidity causes 401.

Header Name       : Content-Type
Required          : No (GET request; no body)
Expected Value    : Not applicable

Header Name       : Accept
Required          : No
Expected Value    : application/json (default assumed if omitted)

Header Name       : X-Correlation-ID
Required          : No (recommended)
Format            : UUID v4 string
Description       : Caller-supplied correlation identifier for distributed tracing.
                    If provided, the service echoes it in the response header and
                    includes it in the audit log entry.

Header Name       : X-Request-ID
Required          : No
Format            : UUID v4 string
Description       : Unique identifier for this individual request instance, used
                    for idempotency tracking in logs. Does not affect response.


2.2 PATH PARAMETERS
--------------------------------------------------------------------------------

Parameter Name    : appointmentId
Location          : Path
Required          : Yes
Type              : String
Format            : Non-empty alphanumeric string; expected pattern is a system-
                    assigned appointment identifier (e.g. UUID v4 or structured
                    reference such as APT-YYYYMMDD-NNNNNN)
Min Length        : 1 character
Max Length        : 64 characters
Regex Constraint  : ^[A-Za-z0-9\-_]{1,64}$
Description       : Unique identifier of the appointment whose status is being
                    requested. Must correspond to an existing appointment record
                    in the appointment data store.
Validation Errors : Empty or missing value returns 400.
                    Value not matching format pattern returns 400.
                    Value not found in data store returns 404.


2.3 QUERY PARAMETERS
--------------------------------------------------------------------------------

No query parameters are defined for this endpoint. Any unrecognised query
parameters supplied by the caller are silently ignored and do not affect
processing.


2.4 REQUEST BODY
--------------------------------------------------------------------------------

Not applicable. This is a GET operation and carries no request body.


================================================================================
SECTION 3: RESPONSE SPECIFICATION
================================================================================

3.1 SUCCESS RESPONSE - HTTP 200 OK
--------------------------------------------------------------------------------

Description : The appointment status snapshot was successfully assembled and
              returned. All available fields are populated. Fields that are not
              yet applicable (e.g. drop address when drop service was not
              requested, or ETA when the trip is not active) are returned as
              null.

Content-Type : application/json

Response Body Schema:

Field Name                    : appointmentId
Type                          : String
Nullable                      : No
Description                   : Echo of the appointmentId path parameter.
Source                        : appointment.appointment_id

Field Name                    : appointmentNumber
Type                          : String
Nullable                      : No
Description                   : Human-readable appointment reference number used
                                 in the Pickup Coordinator dashboard.
Source                        : appointment.appointment_number

Field Name                    : customerName
Type                          : String
Nullable                      : No
Description                   : Full name of the customer associated with the
                                 appointment.
Source                        : appointment.customer_name

Field Name                    : maskedContactReference
Type                          : String
Nullable                      : Yes
Description                   : Customer contact reference (e.g. phone number)
                                 returned in masked form unless the caller role
                                 is explicitly authorised for unmasked PII.
                                 Example masked form: +91-XXXXXX-7890
Source                        : appointment.customer_contact_reference (masked)

Field Name                    : vehicleRegistration
Type                          : String
Nullable                      : Yes
Description                   : Vehicle registration plate number associated with
                                 the appointment.
Source                        : appointment.vehicle_registration

Field Name                    : vehicleModel
Type                          : String
Nullable                      : Yes
Description                   : Model descriptor of the vehicle (e.g. make, model,
                                 variant).
Source                        : appointment.vehicle_model

Field Name                    : pickupDateTime
Type                          : String (ISO 8601 datetime)
Nullable                      : Yes
Format                        : YYYY-MM-DDTHH:mm:ssZ
Description                   : Scheduled pickup date and time in UTC.
Source                        : appointment.pickup_date_time

Field Name                    : pickupAddress
Type                          : String
Nullable                      : Yes
Description                   : Full pickup address as provided at appointment
                                 creation. Mutually contextual with
                                 permittedPickupArea.
Source                        : appointment.pickup_address

Field Name                    : permittedPickupArea
Type                          : String
Nullable                      : Yes
Description                   : Designated permitted pickup zone or area code
                                 where the pickup is authorised to occur.
Source                        : appointment.permitted_pickup_area

Field Name                    : dropServiceSelected
Type                          : Boolean
Nullable                      : No
Description                   : Indicates whether the customer requested a drop
                                 service as part of this appointment.
Source                        : appointment.drop_service_selected

Field Name                    : dropAddress
Type                          : String
Nullable                      : Yes
Description                   : Drop-off address. Null if drop service was not
                                 selected or address has not been provided.
Source                        : appointment.drop_address

Field Name                    : dropDateTime
Type                          : String (ISO 8601 datetime)
Nullable                      : Yes
Format                        : YYYY-MM-DDTHH:mm:ssZ
Description                   : Scheduled drop-off date and time in UTC. Null if
                                 drop service not selected.
Source                        : appointment.drop_date_time

Field Name                    : appointmentStatus
Type                          : String (Enum)
Nullable                      : No
Allowed Values                : SCHEDULED, IN_PROGRESS, COMPLETED, CANCELLED,
                                 ON_HOLD, EXCEPTION
Description                   : Current lifecycle status of the appointment.
Source                        : appointment.appointment_status

Field Name                    : allocationStatus
Type                          : String (Enum)
Nullable                      : No
Allowed Values                : UNALLOCATED, PENDING_ASSIGNMENT, ASSIGNED,
                                 REASSIGNMENT_REQUIRED, ALLOCATION_FAILED
Description                   : Current chauffeur allocation status for the
                                 appointment.
Source                        : appointment.allocation_status

Field Name                    : chauffeurName
Type                          : String
Nullable                      : Yes
Description                   : Full name of the assigned chauffeur. Null if no
                                 chauffeur has been assigned.
Source                        : chauffeur_assignment.chauffeur_name

Field Name                    : chauffeurRequestStatus
Type                          : String (Enum)
Nullable                      : Yes
Allowed Values                : REQUEST_SENT, ACCEPTED, DECLINED, TIMED_OUT,
                                 COMPLETED
Description                   : Current status of the chauffeur assignment
                                 request. Null if no request has been made.
Source                        : chauffeur_assignment.request_status

Field Name                    : chauffeurAssignmentTimestamp
Type                          : String (ISO 8601 datetime)
Nullable                      : Yes
Format                        : YYYY-MM-DDTHH:mm:ssZ
Description                   : Timestamp at which the chauffeur was assigned or
                                 the assignment status was last updated.
Source                        : chauffeur_assignment.assignment_timestamp

Field Name                    : currentETA
Type                          : String (ISO 8601 datetime)
Nullable                      : Yes
Format                        : YYYY-MM-DDTHH:mm:ssZ
Description                   : Real-time or last-known estimated time of arrival
                                 derived from the Map API integration layer. Null
                                 if the appointment is not in an active trip state
                                 or if the Map API is unavailable.
Source                        : Map API Integration Layer (live or cached)

Field Name                    : exceptionFlag
Type                          : Boolean
Nullable                      : No
Description                   : Set to true if any exception condition is active
                                 for this appointment (e.g. SLA breach, ETA
                                 overrun, vehicle condition issue, downstream
                                 service failure affecting data completeness).
Source                        : Derived at response assembly time

Field Name                    : exceptionDetails
Type                          : String
Nullable                      : Yes
Description                   : Human-readable description of the active exception
                                 condition. Null if exceptionFlag is false.
Source                        : Derived at response assembly time

Field Name                    : jcNumber
Type                          : String
Nullable                      : Yes
Description                   : Linked Job Card number from the CRM/DMS system.
                                 Null if no Job Card is linked or CRM/DMS is
                                 unavailable.
Source                        : CRM/DMS Integration

Field Name                    : promisedDeliveryTime
Type                          : String (ISO 8601 datetime)
Nullable                      : Yes
Format                        : YYYY-MM-DDTHH:mm:ssZ
Description                   : Promised vehicle delivery time as recorded in the
                                 CRM/DMS system. Null if not available.
Source                        : CRM/DMS Integration

Field Name                    : retrievedAt
Type                          : String (ISO 8601 datetime)
Nullable                      : No
Format                        : YYYY-MM-DDTHH:mm:ssZ
Description                   : Server-side UTC timestamp at which this status
                                 snapshot was assembled and returned.
Source                        : System clock at response assembly time


Example 200 Response Payload:

{
  "appointmentId": "APT-20240615-000123",
  "appointmentNumber": "APPT-2024-000123",
  "customerName": "Rajesh Kumar",
  "maskedContactReference": "+91-XXXXXX-7890",
  "vehicleRegistration": "MH12AB1234",
  "vehicleModel": "Mercedes-Benz GLE 300d",
  "pickupDateTime": "2024-06-15T09:00:00Z",
  "pickupAddress": "12 Marine Drive, Mumbai, Maharashtra 400002",
  "permittedPickupArea": "ZONE-MUM-SOUTH",
  "dropServiceSelected": true,
  "dropAddress": "Dealership Service Centre, Worli, Mumbai",
  "dropDateTime": "2024-06-15T11:00:00Z",
  "appointmentStatus": "IN_PROGRESS",
  "allocationStatus": "ASSIGNED",
  "chauffeurName": "Suresh Patil",
  "chauffeurRequestStatus": "ACCEPTED",
  "chauffeurAssignmentTimestamp": "2024-06-15T08:15:00Z",
  "currentETA": "2024-06-15T08:52:00Z",
  "exceptionFlag": false,
  "exceptionDetails": null,
  "jcNumber": "JC-2024-MUM-00456",
  "promisedDeliveryTime": "2024-06-15T17:00:00Z",
  "retrievedAt": "2024-06-15T08:45:00Z"
}


Example 200 Response Payload (partial - ETA unavailable, CRM unavailable):

{
  "appointmentId": "APT-20240615-000124",
  "appointmentNumber": "APPT-2024-000124",
  "customerName": "Priya Sharma",
  "maskedContactReference": "+91-XXXXXX-4321",
  "vehicleRegistration": "DL01CD5678",
  "vehicleModel": "BMW 5 Series 530d",
  "pickupDateTime": "2024-06-15T10:30:00Z",
  "pickupAddress": "45 Connaught Place, New Delhi 110001",
  "permittedPickupArea": "ZONE-DEL-CENTRAL",
  "dropServiceSelected": false,
  "dropAddress": null,
  "dropDateTime": null,
  "appointmentStatus": "IN_PROGRESS",
  "allocationStatus": "ASSIGNED",
  "chauffeurName": "Amit Verma",
  "chauffeurRequestStatus": "ACCEPTED",
  "chauffeurAssignmentTimestamp": "2024-06-15T09:45:00Z",
  "currentETA": null,
  "exceptionFlag": true,

ENDPOINT DESIGN: POST /api/v1/appointments/{appointmentId}/delay-alert

Source Requirement IDs: SER-010-020-028, SER-010-020-029


---------------------------------------------------------------------------
SECTION 1: ENDPOINT OVERVIEW
---------------------------------------------------------------------------

Path            : /api/v1/appointments/{appointmentId}/delay-alert
HTTP Method     : POST
Summary         : Record pre-pickup delay detection: capture ETA, delay duration,
                  and coordinator-entered delay reason
Description     : Allows an authenticated Pickup Coordinator to submit a delay
                  alert against an active appointment. The operation persists a
                  delay alert record, updates the appointment with the revised ETA
                  and delay duration, advances the appointment workflow to the next
                  orchestration step (SER-010-020-030), and asynchronously dispatches
                  outbound notifications to the customer across all configured
                  channels (ICP, WhatsApp, SMS, DBP, CRM). An immutable audit trail
                  entry is appended on every successful submission.


---------------------------------------------------------------------------
SECTION 2: REQUEST SPECIFICATION
---------------------------------------------------------------------------

2.1 Request Headers

Header Name        Required    Description
Authorization      Yes         Bearer JWT token issued by the authorised identity
                               provider. Format: "Bearer <token>". Requests without
                               a valid token are rejected with 401.
Content-Type       Yes         Must be "application/json". Requests with any other
                               content type are rejected with 415.
Accept             No          Should be "application/json". Defaults to
                               application/json if omitted.
Idempotency-Key    No          Client-generated UUID v4 string. Recommended to assist
                               server-side deduplication. If provided, the server
                               records this key alongside the composite idempotency
                               key (appointmentId + ETA + delayDuration) to detect
                               duplicate submissions. Format: UUID v4.
X-Tenant-ID        Yes         Identifies the tenant context for the request. Used
                               for tenant-level rate limiting and data isolation.
                               Must be a non-blank string matching the tenant
                               identifier encoded in the JWT claims.
X-Correlation-ID   No          Optional caller-supplied correlation identifier for
                               distributed tracing. Propagated to all downstream
                               service calls. If absent, the gateway generates one.


2.2 Path Parameters

Parameter Name   Type     Required   Description
appointmentId    string   Yes        Unique identifier of the appointment against
                                     which the delay alert is being raised. Must
                                     correspond to an existing appointment record.
                                     Format: UUID v4 or system-defined alphanumeric
                                     identifier. Must not be blank or null.
                                     Validation: non-blank, matches persisted record.


2.3 Query Parameters

None defined for this endpoint.


2.4 Request Body Schema

Content-Type: application/json

Field Name      Type      Required   Description and Validation Rules
eta             string    Yes        Revised estimated time of arrival for the
                                     appointment. Must be a valid ISO 8601 datetime
                                     string with timezone offset (e.g.
                                     "2025-08-15T14:30:00+05:30"). Must represent a
                                     future timestamp strictly greater than the
                                     current system time at the moment of request
                                     processing. Past or present timestamps are
                                     rejected (BR-3). Format: ISO 8601 datetime.
                                     Min length: 20 characters. Must include timezone.

delayDuration   integer   Yes        Duration of the delay expressed in whole minutes.
                                     Must be a positive integer greater than zero.
                                     Must be consistent with the arithmetic difference
                                     between the original scheduled pickup time and
                                     the revised ETA (tolerance: plus or minus 1
                                     minute to account for rounding). Zero, negative,
                                     or inconsistent values are rejected (BR-4).
                                     Type: integer. Minimum value: 1. Maximum value:
                                     1440 (24 hours). Unit: minutes.

delayReason     string    Yes        Human-readable explanation for the delay as
                                     entered by the Pickup Coordinator. Must not be
                                     blank, null, or whitespace-only (BR-5). Must
                                     contain at least 5 characters and no more than
                                     1000 characters. No special encoding required;
                                     standard UTF-8 text accepted. HTML and script
                                     tags are stripped server-side.
                                     Type: string. Min length: 5. Max length: 1000.


2.5 Request Body Example

{
  "eta": "2025-08-15T14:30:00+05:30",
  "delayDuration": 25,
  "delayReason": "Heavy traffic on the main arterial route due to road works near sector 12."
}


---------------------------------------------------------------------------
SECTION 3: RESPONSE SPECIFICATION
---------------------------------------------------------------------------

3.1 HTTP 200 OK — Duplicate Detected (Idempotent Response)

Condition: A delay alert with the same appointmentId, ETA, and delayDuration
           already exists within the deduplication window. No new record is
           created and no notifications are re-dispatched.

Response Body Schema:

Field Name          Type      Description
status              string    Fixed value: "DUPLICATE_ACKNOWLEDGED"
message             string    Human-readable message confirming duplicate detection
appointmentId       string    The appointment identifier from the path parameter
delayAlertId        string    Identifier of the previously persisted delay alert
                              record that matched the deduplication key
revisedEta          string    ISO 8601 datetime of the previously recorded ETA
delayDurationMinutes integer  Previously recorded delay duration in minutes
createdAt           string    ISO 8601 datetime when the original alert was created

Response Body Example:

{
  "status": "DUPLICATE_ACKNOWLEDGED",
  "message": "A delay alert with identical parameters was already recorded for this appointment.",
  "appointmentId": "appt-00123456",
  "delayAlertId": "alert-00987654",
  "revisedEta": "2025-08-15T14:30:00+05:30",
  "delayDurationMinutes": 25,
  "createdAt": "2025-08-15T13:45:00+05:30"
}


3.2 HTTP 201 Created — Delay Alert Successfully Recorded

Condition: All validations pass, the delay alert is persisted, the appointment
           is updated, the workflow is advanced, and notification events are
           queued.

Response Body Schema:

Field Name           Type      Description
status               string    Fixed value: "CREATED"
message              string    Human-readable confirmation message
delayAlertId         string    System-generated unique identifier for the new
                               delay alert record
appointmentId        string    The appointment identifier from the path parameter
revisedEta           string    ISO 8601 datetime of the accepted revised ETA
delayDurationMinutes integer   Accepted delay duration in minutes
delayReason          string    The delay reason as persisted
workflowStep         string    The workflow step to which the appointment has been
                               advanced (value: "SER-010-020-030")
notificationStatus   string    Indicates notification dispatch status. Value:
                               "QUEUED" — events have been published to the
                               outbound notification queue
createdAt            string    ISO 8601 datetime when the delay alert was created
createdByUserId      string    Identifier of the authenticated user (Pickup
                               Coordinator) who submitted the alert, derived from
                               the JWT sub claim

Response Body Example:

{
  "status": "CREATED",
  "message": "Delay alert recorded successfully. Customer notifications have been queued.",
  "delayAlertId": "alert-00987655",
  "appointmentId": "appt-00123456",
  "revisedEta": "2025-08-15T14:30:00+05:30",
  "delayDurationMinutes": 25,
  "delayReason": "Heavy traffic on the main arterial route due to road works near sector 12.",
  "workflowStep": "SER-010-020-030",
  "notificationStatus": "QUEUED",
  "createdAt": "2025-08-15T13:45:00+05:30",
  "createdByUserId": "user-00456789"
}


3.3 HTTP 400 Bad Request — Malformed Request

Condition: The request body is syntactically invalid (e.g. malformed JSON,
           missing Content-Type, unparseable field values).

Response Body Schema:

Field Name   Type      Description
status       integer   HTTP status code: 400
error        string    Fixed value: "BAD_REQUEST"
message      string    Human-readable description of the parse or format error
correlationId string   Correlation identifier for tracing

Response Body Example:

{
  "status": 400,
  "error": "BAD_REQUEST",
  "message": "Request body could not be parsed. Ensure the payload is valid JSON and Content-Type is application/json.",
  "correlationId": "corr-abc123"
}


3.4 HTTP 401 Unauthorized — Authentication Failure

Condition: The Bearer JWT token is absent, expired, malformed, or issued by
           an untrusted identity provider.

Response Body Schema:

Field Name    Type      Description
status        integer   HTTP status code: 401
error         string    Fixed value: "UNAUTHORIZED"
message       string    Human-readable description of the authentication failure
correlationId string    Correlation identifier for tracing

Response Body Example:

{
  "status": 401,
  "error": "UNAUTHORIZED",
  "message": "Authentication failed. A valid Bearer token is required.",
  "correlationId": "corr-abc124"
}


3.5 HTTP 403 Forbidden — Authorisation Failure

Condition: The authenticated user does not hold the PICKUP_COORDINATOR role
           (BR-7).

Response Body Schema:

Field Name    Type      Description
status        integer   HTTP status code: 403
error         string    Fixed value: "FORBIDDEN"
message       string    Human-readable description of the authorisation failure
correlationId string    Correlation identifier for tracing

Response Body Example:

{
  "status": 403,
  "error": "FORBIDDEN",
  "message": "Access denied. Only Pickup Coordinators are authorised to issue delay alerts.",
  "correlationId": "corr-abc125"
}


3.6 HTTP 404 Not Found — Appointment Not Found

Condition: The appointmentId path parameter does not correspond to any
           persisted appointment record (BR-1).

Response Body Schema:

Field Name    Type      Description
status        integer   HTTP status code: 404
error         string    Fixed value: "NOT_FOUND"
message       string    Human-readable description of the not-found condition
appointmentId string    The appointmentId value that was not resolved
correlationId string    Correlation identifier for tracing

Response Body Example:

{
  "status": 404,
  "error": "NOT_FOUND",
  "message": "Appointment not found for the provided appointmentId.",
  "appointmentId": "appt-00123456",
  "correlationId": "corr-abc126"
}


3.7 HTTP 409 Conflict — Invalid Appointment State

Condition: The appointment exists but is in a terminal or pre-active state
           (COMPLETED, CANCELLED, or DRAFT) that does not permit delay alerts
           (BR-2).

Response Body Schema:

Field Name         Type      Description
status             integer   HTTP status code: 409
error              string    Fixed value: "CONFLICT"
message            string    Human-readable description of the state conflict
appointmentId      string    The appointment identifier
currentState       string    The current state of the appointment
permittedStates    array     List of states in which delay alerts are permitted
correlationId      string    Correlation identifier for tracing

Response Body Example:

{
  "status": 409,
  "error": "CONFLICT",
  "message": "Delay alert cannot be issued for an appointment in its current state.",
  "appointmentId": "appt-00123456",
  "currentState": "COMPLETED",
  "permittedStates": ["ACTIVE", "IN_PROGRESS", "EN_ROUTE"],
  "correlationId": "corr-abc127"
}


3.8 HTTP 422 Unprocessable Entity — Validation Failure

Condition: The request is syntactically valid but fails one or more business
           validation rules (BR-3, BR-4, BR-5).

Response Body Schema:

Field Name    Type      Description
status        integer   HTTP status code: 422
error         string    Fixed value: "UNPROCESSABLE_ENTITY"
message       string    Human-readable summary of validation failures
violations    array     List of individual field-level violation objects
correlationId string    Correlation identifier for tracing

Violation Object Schema:

Field Name   Type      Description
field        string    Name of the request field that failed validation
ruleId       string    Identifier of the business rule that was violated
message      string    Human-readable description of the specific violation

Response Body Example

ENDPOINT DESIGN: GET /api/v1/vehicle-condition-reports/{reportId}/secure-link

================================================================================
SECTION 1: ENDPOINT IDENTIFICATION
================================================================================

Path            : /api/v1/vehicle-condition-reports/{reportId}/secure-link
HTTP Method     : GET
Summary         : Generate or retrieve the secure read-only shareable link for a
                  completed condition report for inclusion in customer notifications
Source Activity : SER-010-020-080
Version         : v1


================================================================================
SECTION 2: DESCRIPTION
================================================================================

This endpoint generates or retrieves a time-limited, read-only secure URL that
encapsulates the content of a finalized vehicle condition report. The returned
link is intended for embedding in outbound customer notifications dispatched
across ICP, WhatsApp, SMS, DBP, and CRM channels as part of the appointment
booking stage SER-010-020.

The endpoint is callable only by authorized internal roles (Pickup Coordinator
or Integration Service). Customers are never expected to call this endpoint
directly; they receive the link as a payload within a notification message.

The operation is read-only and non-mutating. No changes are made to the vehicle
condition report or any related domain entity. Each successful retrieval is
recorded in an immutable audit trail.

If a valid unexpired secure link already exists for the given reportId, the
same link may be returned to avoid unnecessary token proliferation. If no
unexpired link exists, a new one is generated.


================================================================================
SECTION 3: REQUEST SPECIFICATION
================================================================================

3.1 Request Headers
--------------------------------------------------------------------------------

Header Name       Required   Type     Description
Authorization     Yes        String   Bearer JWT token issued by the OAuth2/OIDC
                                      provider. Format: "Bearer <token>".
                                      Token must contain valid role claims
                                      (PICKUP_COORDINATOR or INTEGRATION_SERVICE).
Content-Type      No         String   Not required for GET requests.
Accept            No         String   Recommended: application/json


3.2 Path Parameters
--------------------------------------------------------------------------------

Parameter Name   Required   Type     Format / Validation
reportId         Yes        String   Non-empty string. Must conform to the
                                     system's report identifier format.
                                     Must not contain whitespace-only characters.
                                     Must not be null or empty.
                                     Regex pattern: ^[a-zA-Z0-9_-]{1,64}$
                                     Minimum length: 1 character
                                     Maximum length: 64 characters
                                     Malformed or empty values result in HTTP 400.


3.3 Query Parameters
--------------------------------------------------------------------------------

None defined for this endpoint.


3.4 Request Body
--------------------------------------------------------------------------------

Not applicable. This is a GET operation; no request body is accepted.


================================================================================
SECTION 4: RESPONSE SPECIFICATION
================================================================================

4.1 HTTP 200 - Success
--------------------------------------------------------------------------------

Description:
The secure link was successfully generated or retrieved. The response contains
the time-limited read-only URL and its expiry timestamp.

Response Body Schema:

Field Name        Type      Required   Description
secureRecordLink  String    Yes        The time-limited, read-only URL granting
                                       view-only access to the vehicle condition
                                       report content (vehicle number, pick-up
                                       time, captured concerns, condition images).
                                       Format: URI (https scheme required).
expiresAt         String    Yes        UTC timestamp indicating when the secure
                                       link will expire and become inaccessible.
                                       Format: ISO 8601 (yyyy-MM-ddTHH:mm:ssZ).
reportId          String    Yes        Echo of the reportId for which the link
                                       was generated, for caller confirmation.

Example Response Payload:

  secureRecordLink : https://secure.example.com/vcr/links/eyJhbGciOiJIUzI1NiJ9.abc123
  expiresAt        : 2025-07-15T14:30:00Z
  reportId         : RPT-2025-00471


4.2 HTTP 400 - Bad Request
--------------------------------------------------------------------------------

Description:
The request was rejected due to a malformed or invalid reportId path parameter.
No downstream processing was attempted.

Triggered by: BR-4

Response Body Schema:

Field Name   Type     Description
errorCode    String   Machine-readable error code.
message      String   Human-readable description of the validation failure.
field        String   The name of the field that failed validation.
reportId     String   The value supplied by the caller (may be empty or masked).

Example Response Payload:

  errorCode : INVALID_REPORT_ID_FORMAT
  message   : Invalid reportId format. A valid report identifier must be provided.
  field     : reportId
  reportId  : !!invalid##


4.3 HTTP 401 - Unauthorized
--------------------------------------------------------------------------------

Description:
The request did not include a valid Bearer JWT token, or the token has expired,
is malformed, or cannot be verified by the authorization server.

Response Body Schema:

Field Name   Type     Description
errorCode    String   Machine-readable error code.
message      String   Human-readable description of the authentication failure.

Example Response Payload:

  errorCode : AUTHENTICATION_REQUIRED
  message   : A valid Bearer JWT token is required to access this resource.


4.4 HTTP 403 - Forbidden
--------------------------------------------------------------------------------

Description:
The caller's JWT token is valid but the caller's role is not in the permitted
set (PICKUP_COORDINATOR, INTEGRATION_SERVICE). Access is denied.

Triggered by: BR-6

Response Body Schema:

Field Name   Type     Description
errorCode    String   Machine-readable error code.
message      String   Human-readable description of the authorization failure.
reportId     String   The reportId that was requested.

Example Response Payload:

  errorCode : ACCESS_DENIED
  message   : Access denied. Insufficient permissions to retrieve the secure
              link for this report.
  reportId  : RPT-2025-00471


4.5 HTTP 404 - Not Found
--------------------------------------------------------------------------------

Description:
No vehicle condition report exists in the system for the supplied reportId.

Triggered by: BR-1

Response Body Schema:

Field Name   Type     Description
errorCode    String   Machine-readable error code.
message      String   Human-readable description of the not-found condition.
reportId     String   The reportId that was not found.

Example Response Payload:

  errorCode : REPORT_NOT_FOUND
  message   : Vehicle condition report not found for the provided reportId.
  reportId  : RPT-2025-99999


4.6 HTTP 409 - Conflict
--------------------------------------------------------------------------------

Description:
The vehicle condition report exists but is not in a finalized state. The
condition capture session is still in draft or in-progress, so a secure link
cannot be issued.

Triggered by: BR-9

Response Body Schema:

Field Name    Type     Description
errorCode     String   Machine-readable error code.
message       String   Human-readable description of the state conflict.
reportId      String   The reportId in the non-finalized state.
reportStatus  String   The current status of the report (e.g., DRAFT,
                       IN_PROGRESS).

Example Response Payload:

  errorCode    : REPORT_NOT_FINALIZED
  message      : Vehicle condition report is not finalized. Secure link cannot
                 be generated until the condition capture session is complete.
  reportId     : RPT-2025-00471
  reportStatus : IN_PROGRESS


4.7 HTTP 410 - Gone (Link Expiry - resolved at link layer)
--------------------------------------------------------------------------------

Description:
This status is not returned by this endpoint directly. It is returned by the
secure link resolution layer when a previously issued link is accessed after
its expiry window has elapsed. Documented here for completeness per BR-5.

Triggered by: BR-5

Message at link resolution layer:

  errorCode : SECURE_LINK_EXPIRED
  message   : Secure link has expired and is no longer accessible.


4.8 HTTP 500 - Internal Server Error
--------------------------------------------------------------------------------

Description:
An unexpected internal error occurred that is not attributable to caller input
or a known downstream failure mode.

Response Body Schema:

Field Name     Type     Description
errorCode      String   Machine-readable error code.
message        String   Human-readable description.
correlationId  String   Unique identifier for tracing the request in logs.

Example Response Payload:

  errorCode     : INTERNAL_SERVER_ERROR
  message       : An unexpected error occurred. Please retry or contact support.
  correlationId : corr-7f3a2b91-4e12-4c88-a001-d9f3c2e10abc


4.9 HTTP 502 - Bad Gateway
--------------------------------------------------------------------------------

Description:
The Secure Link Generation Service failed to produce a link after one retry
attempt. The circuit breaker pattern is applied to prevent cascading failures.

Response Body Schema:

Field Name     Type     Description
errorCode      String   Machine-readable error code.
message        String   Human-readable description.
correlationId  String   Unique identifier for tracing the request in logs.

Example Response Payload:

  errorCode     : SECURE_LINK_SERVICE_UNAVAILABLE
  message       : The secure link generation service is currently unavailable.
                  Please retry after a short delay.
  correlationId : corr-9a1b3c72-5f44-4d99-b002-e8a4d3f21bcd


4.10 HTTP 503 - Service Unavailable
--------------------------------------------------------------------------------

Description:
The Vehicle Condition Report Store (database) is unreachable after up to 3
retry attempts with exponential backoff.

Response Body Schema:

Field Name     Type     Description
errorCode      String   Machine-readable error code.
message        String   Human-readable description.
correlationId  String   Unique identifier for tracing the request in logs.

Example Response Payload:

  errorCode     : REPORT_STORE_UNAVAILABLE
  message       : The vehicle condition report store is currently unavailable.
                  Please retry after a short delay.
  correlationId : corr-2c5e8f14-7b33-4a11-c003-f1b5e4g32cde


================================================================================
SECTION 5: BUSINESS RULES
================================================================================

BR-1
  Category          : Pre-condition
  Trigger           : A GET request is made with a reportId that does not
                      correspond to any persisted vehicle condition report.
  Description       : The report identified by reportId must exist in the system
                      before a secure link can be generated or retrieved.
  Expected Behaviour: The system rejects the request and returns a not-found
                      error.
  Error Code        : 404
  Error Message     : Vehicle condition report not found for the provided
                      reportId.

BR-2
  Category          : Business
  Trigger           : A valid secure link is requested for a vehicle condition
                      report.
  Description       : The secure link generated must be read-only, granting the
                      recipient (Customer) view-only access to the vehicle
                      condition report including vehicle number, pick-up time,
                      captured concerns, and condition images.
  Expected Behaviour: The system returns a time-

ENDPOINT DESIGN DOCUMENT
=========================

Endpoint Path       : /api/v1/delay-detection/timeouts
HTTP Method         : GET
Summary             : Returns a list of assignment requests that have timed out and are pending coordinator action, including appointment reference, chauffeur, dispatch timestamp, and timeout duration.
Description         : This endpoint retrieves all chauffeur assignment requests that have entered a timed-out or rejected state during the SER-010-020 booking stage. Each record is enriched with the full failure context required by the Pickup Coordinator and the automated re-assignment orchestration service (SER-010-020-014) to initiate the next assignment round. Upon successful retrieval, the system signals the re-assignment orchestration service for each unresolved record and appends an immutable audit log entry.
Source Requirement IDs : SER-010-020-013, SER-010-020-014


---------------------------------------------------------------------------
SECTION 1 : REQUEST SPECIFICATION
---------------------------------------------------------------------------

1.1 Request Headers

Header Name       : Authorization
Required          : Yes
Format            : Bearer <JWT token>
Description       : OAuth2 / OIDC Bearer JWT. Must be signed, non-expired, and issued by the authorised identity provider. The JWT must carry at least one of the following role claims: PICKUP_COORDINATOR, INTEGRATION_SERVICE, ADMIN.

Header Name       : Accept
Required          : No (defaults to application/json)
Allowed Values    : application/json
Description       : Specifies the expected response media type.

Header Name       : X-Correlation-ID
Required          : No (recommended)
Format            : UUID v4
Description       : Caller-supplied correlation identifier for distributed tracing. If not supplied, the system generates one and includes it in the response headers.

Header Name       : X-Request-ID
Required          : No
Format            : UUID v4
Description       : Idempotency / deduplication identifier for the request. Logged in the audit trail.


1.2 Query Parameters

Parameter Name    : appointmentReference
Location          : Query string
Type              : String
Required          : No
Format            : Alphanumeric, 1–64 characters, pattern [A-Za-z0-9\-_]{1,64}
Description       : Filters the result set to timeout records associated with a specific appointment reference. If omitted, records for all active appointments are returned.
Validation        : Must match the pattern above. Rejected with 400 if the value contains special characters outside the allowed set.

Parameter Name    : jcReference
Location          : Query string
Type              : String
Required          : No
Format            : Alphanumeric, 1–64 characters, pattern [A-Za-z0-9\-_]{1,64}
Description       : Filters the result set to timeout records associated with a specific Job Card (JC) reference.
Validation        : Same pattern as appointmentReference.

Parameter Name    : failureType
Location          : Query string
Type              : String (enum)
Required          : No
Allowed Values    : TIMEOUT, REJECTED
Description       : Filters records by the type of assignment failure. TIMEOUT indicates the chauffeur did not respond within the acceptance window. REJECTED indicates the chauffeur explicitly declined the request.
Validation        : Value must be one of the two allowed enum values. Any other value returns 400.

Parameter Name    : roundNumber
Location          : Query string
Type              : Integer
Required          : No
Minimum           : 1
Maximum           : Configurable system maximum (default 10)
Description       : Filters records to a specific re-assignment round number.
Validation        : Must be a positive integer. Non-integer or out-of-range values return 400.

Parameter Name    : stage
Location          : Query string
Type              : String
Required          : No
Allowed Values    : SER-010-020
Description       : Filters records by booking stage. Currently only SER-010-020 is supported. If omitted, the system defaults to SER-010-020.
Validation        : Any value other than SER-010-020 returns 400.

Parameter Name    : page
Location          : Query string
Type              : Integer
Required          : No
Minimum           : 1
Default           : 1
Description       : Page number for paginated results.
Validation        : Must be a positive integer.

Parameter Name    : pageSize
Location          : Query string
Type              : Integer
Required          : No
Minimum           : 1
Maximum           : 100
Default           : 20
Description       : Number of records per page.
Validation        : Must be between 1 and 100 inclusive.


1.3 Request Body

This endpoint does not accept a request body. Any request body supplied will be ignored.


---------------------------------------------------------------------------
SECTION 2 : RESPONSE SPECIFICATION
---------------------------------------------------------------------------

2.1 HTTP 200 OK — Successful Retrieval

Description : The request was processed successfully. A list of timed-out or rejected chauffeur assignment records is returned, each enriched with the full failure context.

Response Body Schema (top-level object):

Field Name        : correlationId
Type              : String (UUID v4)
Required          : Yes
Description       : Correlation identifier echoed from the request header, or system-generated if not supplied.

Field Name        : timestamp
Type              : String (ISO 8601 datetime, UTC)
Required          : Yes
Description       : Server-side timestamp at which the response was generated.

Field Name        : totalRecords
Type              : Integer
Required          : Yes
Description       : Total number of timeout records matching the applied filters (before pagination).

Field Name        : page
Type              : Integer
Required          : Yes
Description       : Current page number returned.

Field Name        : pageSize
Type              : Integer
Required          : Yes
Description       : Number of records included in this page.

Field Name        : timeoutRecords
Type              : Array of TimeoutRecord objects
Required          : Yes
Description       : The list of enriched timeout records. May be an empty array if no matching records exist.

TimeoutRecord Object Fields:

Field Name        : assignmentRequestId
Type              : String
Required          : Yes
Description       : Unique identifier of the failed chauffeur assignment request.

Field Name        : appointmentReference
Type              : String
Required          : Yes
Description       : Reference identifier of the parent appointment.

Field Name        : jcReference
Type              : String
Required          : No
Description       : Job Card reference associated with the appointment, if applicable.

Field Name        : previousChauffeurId
Type              : String
Required          : No
Description       : Identifier of the chauffeur who was previously assigned before the timeout or rejection event.

Field Name        : failureType
Type              : String (enum: TIMEOUT, REJECTED)
Required          : Yes
Description       : Indicates whether the failure was due to non-response within the acceptance window (TIMEOUT) or an explicit rejection (REJECTED).

Field Name        : roundNumber
Type              : Integer
Required          : Yes
Description       : The current re-assignment round number for this record. Reflects how many assignment attempts have been made.

Field Name        : maxRoundReached
Type              : Boolean
Required          : Yes
Description       : True if the record has reached the configured maximum re-assignment round limit. When true, manual intervention is required.

Field Name        : candidateChauffeurId
Type              : String
Required          : No
Description       : Identifier of the candidate chauffeur who was offered the assignment in this round.

Field Name        : declaredAvailability
Type              : String (ISO 8601 datetime range or structured object)
Required          : No
Description       : The declared availability window of the candidate chauffeur at the time of the assignment offer.

Field Name        : dealershipMapping
Type              : String
Required          : No
Description       : Identifier or name of the dealership to which the chauffeur is mapped.

Field Name        : blockedSlots
Type              : Array of String (ISO 8601 datetime ranges)
Required          : No
Description       : List of time slots during which the candidate chauffeur is unavailable.

Field Name        : workload
Type              : Object or String
Required          : No
Description       : Current workload indicator for the candidate chauffeur at the time of the assignment offer (e.g., number of active assignments, utilisation percentage).

Field Name        : location
Type              : Object
Required          : No
Description       : Geographic location of the candidate chauffeur at the time of the assignment offer.

Sub-fields of location:
  latitude        : Number (decimal degrees, -90 to 90)
  longitude       : Number (decimal degrees, -180 to 180)
  addressLabel    : String (optional human-readable label)

Field Name        : travelTime
Type              : Integer (minutes)
Required          : No
Description       : Estimated travel time in minutes from the candidate chauffeur's location to the pickup point.

Field Name        : recommendationResult
Type              : String (enum: RECOMMENDED, NO_MATCH)
Required          : No
Description       : Outcome of the chauffeur recommendation engine for this round. RECOMMENDED indicates a candidate was identified; NO_MATCH indicates no suitable candidate was found.

Field Name        : rerunTimestamp
Type              : String (ISO 8601 datetime, UTC)
Required          : No
Description       : Timestamp at which the re-assignment process was last triggered or is scheduled to be triggered for this record.

Field Name        : pendingRerun
Type              : Boolean
Required          : Yes
Description       : True if the downstream re-assignment signal (SER-010-020-014) could not be delivered and the record is awaiting retry via the durable queue.

Field Name        : stage
Type              : String
Required          : Yes
Description       : Booking stage identifier. Always SER-010-020 for records returned by this endpoint.

Field Name        : status
Type              : String (enum: TIMED_OUT, REJECTED)
Required          : Yes
Description       : Current status of the assignment request record.

Example 200 Response Payload:

correlationId: "f47ac10b-58cc-4372-a567-0e02b2c3d479"
timestamp: "2025-06-15T09:32:00Z"
totalRecords: 2
page: 1
pageSize: 20
timeoutRecords:
  [0]
    assignmentRequestId: "ARQ-20250615-001"
    appointmentReference: "APT-2025-88421"
    jcReference: "JC-2025-44210"
    previousChauffeurId: "CHF-00192"
    failureType: "TIMEOUT"
    roundNumber: 2
    maxRoundReached: false
    candidateChauffeurId: "CHF-00345"
    declaredAvailability: "2025-06-15T10:00:00Z/2025-06-15T18:00:00Z"
    dealershipMapping: "DLR-NORTH-07"
    blockedSlots: ["2025-06-15T12:00:00Z/2025-06-15T13:00:00Z"]
    workload: { activeAssignments: 2, utilisationPct: 40 }
    location: { latitude: 25.2048, longitude: 55.2708, addressLabel: "Dubai Marina" }
    travelTime: 18
    recommendationResult: "RECOMMENDED"
    rerunTimestamp: "2025-06-15T09:30:00Z"
    pendingRerun: false
    stage: "SER-010-020"
    status: "TIMED_OUT"
  [1]
    assignmentRequestId: "ARQ-20250615-002"
    appointmentReference: "APT-2025-88430"
    jcReference: "JC-2025-44215"
    previousChauffeurId: "CHF-00210"
    failureType: "REJECTED"
    roundNumber: 1
    maxRoundReached: false
    candidateChauffeurId: "CHF-00410"
    declaredAvailability: "2025-06-15T08:00:00Z/2025-06-15T16:00:00Z"
    dealershipMapping: "DLR-SOUTH-03"
    blockedSlots: []
    workload: { activeAssignments: 1, utilisationPct: 20 }
    location: { latitude: 25.1972, longitude: 55.2796, addressLabel: "Business Bay" }
    travelTime: 12
    recommendationResult: "RECOMMENDED"
    rerunTimestamp: "2025-06-15T09:28:00Z"
    pendingRerun: false
    stage: "SER-010-020"
    status: "REJECTED"


2.2 HTTP 400 Bad Request — Invalid Query Parameters

Description : One or more query parameters failed validation.

Response Body Schema:

Field Name        : correlationId
Type              : String (UUID v4)

Field Name        : timestamp
Type              : String (ISO

ENDPOINT DESIGN DOCUMENT
========================

Endpoint: POST /api/v1/map/eta
Service Context: Chauffeur Dispatch and Pickup Coordination Platform
Source Requirements: SER-010-020-005, SER-010-020-025, SER-010-020-083, SER-010-020-113


------------------------------------------------------------------------
SECTION 1: ENDPOINT IDENTIFICATION
------------------------------------------------------------------------

Path               : /api/v1/map/eta
HTTP Method        : POST
Summary            : Calculate ETA and distance between an origin (chauffeur
                     location) and a destination (pickup or drop address)
                     using real-time traffic.
Description        : This endpoint computes an estimated time of arrival (ETA)
                     and route distance between a chauffeur origin coordinate
                     and a target destination coordinate. The computation
                     incorporates real-time traffic data via an external
                     mapping/routing service. The result is used across four
                     operational contexts: chauffeur recommendation scoring
                     during appointment booking (SER-010-020-005), chauffeur
                     approach to customer pickup point (SER-010-020-025),
                     chauffeur navigation to dealership during vehicle drop-off
                     (SER-010-020-083), and full route computation during the
                     drop leg (SER-010-020-113). ETA values are read-only
                     estimates and must not be treated as contractual
                     commitments. The endpoint is a query operation and does
                     not mutate any domain entity.


------------------------------------------------------------------------
SECTION 2: REQUEST SPECIFICATION
------------------------------------------------------------------------

2.1 Request Headers
-------------------

Header Name        : Authorization
Required           : Yes
Format             : Bearer <JWT token>
Description        : OAuth2/OIDC Bearer token. Must be a valid, non-expired
                     JWT issued by the platform identity provider. The token
                     must carry the caller's subject claim (sub), role claims,
                     and the required OAuth2 scope (map:eta:read).

Header Name        : Content-Type
Required           : Yes
Expected Value     : application/json
Description        : Request body must be JSON-encoded.

Header Name        : Accept
Required           : No (defaults to application/json)
Expected Value     : application/json
Description        : Caller may explicitly request JSON response format.

Header Name        : X-Correlation-ID
Required           : No (recommended)
Format             : UUID v4 string
Description        : Optional caller-supplied correlation identifier for
                     distributed tracing. If provided, it is echoed back in
                     the response header and included in the audit log entry.
                     If not provided, the system generates one internally.

Header Name        : X-Request-Timestamp
Required           : No
Format             : ISO 8601 UTC datetime string (e.g. 2025-01-15T10:30:00Z)
Description        : Optional caller-supplied request timestamp for
                     reconciliation purposes. The system always uses its own
                     server-side UTC clock for audit purposes regardless of
                     this value.


2.2 Path Parameters
-------------------

None. This endpoint does not use path parameters.


2.3 Query Parameters
--------------------

None. All input is supplied in the request body.


2.4 Request Body Schema
-----------------------

Content-Type: application/json

The request body is a single JSON object with the following fields.

Field Name         : appointmentId
Type               : string
Required           : Conditionally required. Either appointmentId or tripId
                     must be present; both may not be absent simultaneously.
Format             : UUID v4
Min Length         : 36 characters
Max Length         : 36 characters
Regex Pattern      : ^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-4[0-9a-fA-F]{3}-
                     [89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$
Description        : Unique identifier of the appointment for which ETA is
                     being computed. Used to resolve the domain record,
                     validate active state, and perform ownership check.
                     Mutually exclusive with tripId in terms of which one
                     drives the domain lookup, but both may be provided if
                     the appointment and trip are linked.

Field Name         : tripId
Type               : string
Required           : Conditionally required. Either appointmentId or tripId
                     must be present.
Format             : UUID v4
Min Length         : 36 characters
Max Length         : 36 characters
Regex Pattern      : ^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-4[0-9a-fA-F]{3}-
                     [89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$
Description        : Unique identifier of the active trip for which ETA is
                     being computed. Used when the request originates during
                     an in-progress trip rather than at the appointment
                     booking stage.

Field Name         : originLatitude
Type               : number (double precision floating point)
Required           : Yes
Minimum Value      : -90.0 (inclusive)
Maximum Value      : 90.0 (inclusive)
Decimal Precision  : Up to 7 decimal places recommended for street-level
                     accuracy.
Description        : Latitude of the origin point (typically the chauffeur's
                     static or last-known location). If the chauffeur is
                     en route and a live location fix is available in the
                     location tracking store, the system will override this
                     value with the live coordinate (see BR-2). This field
                     is still required as a fallback in case the live
                     location store is unavailable.

Field Name         : originLongitude
Type               : number (double precision floating point)
Required           : Yes
Minimum Value      : -180.0 (inclusive)
Maximum Value      : 180.0 (inclusive)
Decimal Precision  : Up to 7 decimal places recommended.
Description        : Longitude of the origin point. Subject to the same
                     live-location override logic as originLatitude.

Field Name         : destinationLatitude
Type               : number (double precision floating point)
Required           : Yes
Minimum Value      : -90.0 (inclusive)
Maximum Value      : 90.0 (inclusive)
Decimal Precision  : Up to 7 decimal places recommended.
Description        : Latitude of the destination point (customer pickup
                     location, dealership address, or drop destination
                     depending on context).

Field Name         : destinationLongitude
Type               : number (double precision floating point)
Required           : Yes
Minimum Value      : -180.0 (inclusive)
Maximum Value      : 180.0 (inclusive)
Decimal Precision  : Up to 7 decimal places recommended.
Description        : Longitude of the destination point.

Field Name         : context
Type               : string (enumeration)
Required           : Yes
Allowed Values     : APPOINTMENT_BOOKING_RECOMMENDATION
                     CHAUFFEUR_TO_CUSTOMER_PICKUP
                     CHAUFFEUR_TO_DEALERSHIP
                     DROP_LEG
Description        : Identifies the operational context of the ETA request.
                     This drives downstream behaviour:
                     - APPOINTMENT_BOOKING_RECOMMENDATION triggers the
                       chauffeur recommendation engine feed (BR-5,
                       SER-010-020-005).
                     - CHAUFFEUR_TO_CUSTOMER_PICKUP returns customer name
                       and live location alongside ETA (BR-4,
                       SER-010-020-025).
                     - CHAUFFEUR_TO_DEALERSHIP returns dealership ETA as
                       a read-only value (BR-3, SER-010-020-083).
                     - DROP_LEG returns full route details and ETA as
                       read-only values (BR-6, SER-010-020-113).

Field Name         : requestedAt
Type               : string
Required           : No
Format             : ISO 8601 UTC datetime (e.g. 2025-01-15T10:30:00Z)
Description        : Optional caller-supplied timestamp indicating when the
                     request was initiated on the client side. Used for
                     latency diagnostics only. The system's own UTC clock
                     is authoritative for audit purposes.


2.5 Request Body Example
------------------------

{
  "appointmentId": "a3f1c2d4-5e6b-4a7c-8d9e-0f1a2b3c4d5e",
  "tripId": null,
  "originLatitude": 51.507351,
  "originLongitude": -0.127758,
  "destinationLatitude": 51.523772,
  "destinationLongitude": -0.158539,
  "context": "CHAUFFEUR_TO_CUSTOMER_PICKUP",
  "requestedAt": "2025-01-15T10:30:00Z"
}


------------------------------------------------------------------------
SECTION 3: RESPONSE SPECIFICATION
------------------------------------------------------------------------

3.1 HTTP 200 OK - Successful ETA Computation
---------------------------------------------

Returned when the ETA has been successfully computed and all downstream
service calls have completed (or gracefully degraded where permitted).

Response Headers:
  Content-Type     : application/json
  X-Correlation-ID : Echoed from request or system-generated UUID v4.
  X-ETA-Computed-At: UTC timestamp at which the mapping service returned
                     its result (ISO 8601).

Response Body Schema:

Field Name              : etaSeconds
Type                    : integer (non-negative)
Description             : Estimated travel time in seconds from the resolved
                          origin to the destination. This is a read-only
                          computed estimate. Minimum value is 0; a value of
                          0 is only valid if origin and destination are
                          effectively co-located (within mapping service
                          tolerance). Flagged as an estimate per BR-9.

Field Name              : distanceMetres
Type                    : integer (non-negative)
Description             : Computed route distance in metres between the
                          resolved origin and the destination.

Field Name              : etaIsEstimate
Type                    : boolean
Fixed Value             : true
Description             : Always true. Signals to all consumers that the ETA
                          is a non-contractual estimate (BR-9). No downstream
                          process may treat this value as a commitment.

Field Name              : resolvedOriginLatitude
Type                    : number (double precision)
Description             : The actual latitude used as the origin for ETA
                          computation. This may differ from the request's
                          originLatitude if the live location store provided
                          a more recent chauffeur position (BR-2).

Field Name              : resolvedOriginLongitude
Type                    : number (double precision)
Description             : The actual longitude used as the origin for ETA
                          computation. Same override logic as
                          resolvedOriginLatitude.

Field Name              : liveLocationUsed
Type                    : boolean
Description             : True if the resolved origin was sourced from the
                          live location tracking store. False if the static
                          request coordinate was used as fallback.

Field Name              : route
Type                    : object (nullable)
Description             : Full route detail returned by the mapping service.
                          Present and populated only when context is DROP_LEG
                          or CHAUFFEUR_TO_CUSTOMER_PICKUP. Null for other
                          contexts. This is a read-only value; callers may
                          not modify or override it (BR-6).
                          Sub-fields:
                            polyline (string): Encoded polyline string
                              representing the route geometry.
                            steps (array of objects): Turn-by-turn
                              navigation steps. Each step contains:
                                instruction (string): Human-readable
                                  navigation instruction.
                                distanceMetres (integer): Distance of
                                  this step in metres.
                                durationSeconds (integer): Duration of
                                  this step in seconds.
                            waypointOrder (array of integers): Order of
                              any intermediate waypoints if applicable.

Field Name              : customerContext
Type                    : object (nullable)
Description             : Present only when context is
                          CHAUFFEUR_TO_CUSTOMER_PICKUP (BR-4,
                          SER-010-020-025). Null for all other contexts.
                          Sub-fields:
                            customerName (string): Full display name of
                              the customer at the pickup point.
                            customerLiveLatitude (number): Customer's
                              current or last-known latitude.
                            customerLiveLongitude (number): Customer's
                              current or last-known longitude.

Field Name              : recommendationFed
Type                    : boolean (nullable)
Description             : Present only when context is
                          APPOINTMENT_BOOKING_RECOMMENDATION. True if the
                          ETA value was successfully forwarded to the
                          chauffeur recommendation engine. False if the
                          recommendation engine was unavailable and the
                          scoring step was skipped (BR-5). Null for all
                          other contexts.

Field Name              : auditEntryId
Type                    : string (UUID v4)
Description             : Identifier of the audit log entry created for
                          this ETA computation. Useful for operational
                          tracing and support queries.

Field Name              : computedAt
Type                    : string (ISO 8601 UTC datetime)
Description             : UTC timestamp at which the ETA was computed by
                          the

ENDPOINT: POST /api/v1/appointment-orchestration/{appointmentId}/reassign

SOURCE REQUIREMENT IDs: SER-010-020-014, SER-010-020-015, SER-010-020-016


------------------------------------------------------------------------
SECTION 1: ENDPOINT OVERVIEW
------------------------------------------------------------------------

Path            : /api/v1/appointment-orchestration/{appointmentId}/reassign
HTTP Method     : POST
Summary         : Trigger iterative reassignment loop after rejection or timeout: log failure record, re-run recommendation, and dispatch new assignment request.
Description     : This endpoint initiates a structured reassignment cycle for an appointment that has previously failed assignment, been rejected by a chauffeur, or timed out awaiting acceptance. The operation logs the failure context from the prior attempt, increments the reassignment round counter, re-invokes the chauffeur recommendation engine with all current eligibility inputs, and either assigns the newly recommended chauffeur or records a no-match outcome requiring manual intervention. The endpoint is restricted to authenticated users holding the PICKUP_COORDINATOR role and is NOT idempotent by design.


------------------------------------------------------------------------
SECTION 2: REQUEST SPECIFICATION
------------------------------------------------------------------------

2.1 Request Headers

Header Name       : Authorization
Required          : Yes
Format            : Bearer <JWT token> (OAuth2 / OIDC)
Description       : Must contain a valid, non-expired JWT. The token must carry role claim PICKUP_COORDINATOR and identity claims (user ID, dealership/zone scope).

Header Name       : Content-Type
Required          : Yes
Allowed Value     : application/json
Description       : Request body must be JSON-encoded.

Header Name       : X-Request-ID
Required          : Recommended
Format            : UUID v4
Description       : Caller-supplied correlation identifier for distributed tracing and log correlation. If absent, the system generates one internally.

Header Name       : X-Idempotency-Key
Required          : No
Description       : Not applicable. This endpoint is not idempotent. Callers must not rely on idempotency key semantics. Each invocation creates a new reassignment record and increments the round number.


2.2 Path Parameters

Parameter Name  : appointmentId
Location        : Path
Type            : String
Required        : Yes
Format          : Non-empty string; expected to conform to the system's appointment identifier format (e.g. UUID v4 or alphanumeric reference)
Validation      : Must be present and non-blank. Must correspond to an existing appointment record. Returns 404 if no matching record is found.
Example         : a3f7c821-4d2e-4b1a-9c3f-0e8d7b6a5c12


2.3 Query Parameters

None defined for this endpoint.


2.4 Request Body Schema

Content-Type    : application/json
Required        : Yes

Field: failedAssignmentReference
  Type          : String
  Required      : Yes
  Description   : The reference identifier of the prior assignment attempt that failed, was rejected, or timed out. Used to link the new reassignment record to the originating failure event.
  Validation    : Non-empty string. Must not exceed 255 characters.
  Example       : "ASSIGN-REF-20240601-00123"

Field: previousChauffeurId
  Type          : String
  Required      : Yes
  Description   : The identifier of the chauffeur from the previous assignment attempt (the one who rejected, timed out, or whose assignment failed).
  Validation    : Non-empty string. Must not exceed 100 characters.
  Example       : "CHFR-00456"

Field: failureType
  Type          : String (Enum)
  Required      : Yes
  Description   : Categorises the reason the prior assignment attempt did not succeed.
  Allowed Values: CHAUFFEUR_REJECTED, ASSIGNMENT_TIMEOUT, ASSIGNMENT_FAILED
  Validation    : Must be one of the enumerated values. Case-sensitive.
  Example       : "CHAUFFEUR_REJECTED"

Field: rejectionOrTimeoutReason
  Type          : String
  Required      : Conditionally required
  Condition     : Required when failureType is CHAUFFEUR_REJECTED or ASSIGNMENT_TIMEOUT (BR-6).
  Description   : The reason captured from the chauffeur rejection event or the timeout event (activity SER-010-020-015). Must be persisted for audit and root-cause analysis.
  Validation    : Non-empty string when required. Must not exceed 1000 characters.
  Example       : "Chauffeur cited personal emergency"

Field: selectedChauffeurId
  Type          : String
  Required      : No
  Description   : If the Pickup Coordinator wishes to manually select a specific chauffeur rather than accept the system recommendation, this field carries that chauffeur's identifier. If omitted, the system assigns the top-ranked recommendation from the engine.
  Validation    : Non-empty string when provided. Must not exceed 100 characters.
  Example       : "CHFR-00789"

Field: overrideReason
  Type          : String
  Required      : Conditionally required
  Condition     : Required when selectedChauffeurId is provided and differs from the chauffeur returned by the recommendation engine (BR-5).
  Description   : The coordinator's stated justification for overriding the system recommendation. Must be non-empty and meaningful.
  Validation    : Non-empty string when required. Must not exceed 2000 characters.
  Example       : "Recommended chauffeur is unfamiliar with this dealership location; selecting experienced alternate."

Field: notes
  Type          : String
  Required      : No
  Description   : Optional free-text notes from the Pickup Coordinator to be stored against the reassignment record.
  Validation    : Must not exceed 2000 characters.
  Example       : "Customer has requested earliest possible pickup."


------------------------------------------------------------------------
SECTION 3: RESPONSE SPECIFICATION
------------------------------------------------------------------------

3.1 HTTP 200 OK — Reassignment Successful (Chauffeur Assigned)

Description: A chauffeur was successfully identified (via recommendation or coordinator override) and assigned to the appointment. The appointment status has transitioned to the assigned state and the downstream workflow has been queued for resumption.

Response Body Fields:

Field: appointmentId
  Type    : String
  Description: The appointment identifier from the path parameter.
  Example : "a3f7c821-4d2e-4b1a-9c3f-0e8d7b6a5c12"

Field: reassignmentId
  Type    : String
  Description: System-generated unique identifier for this reassignment record.
  Example : "REASSIGN-20240601-00078"

Field: roundNumber
  Type    : Integer
  Description: The reassignment round number after increment. Reflects how many reassignment cycles have occurred for this appointment.
  Example : 2

Field: assignedChauffeurId
  Type    : String
  Description: The identifier of the chauffeur now assigned to the appointment.
  Example : "CHFR-00789"

Field: recommendedChauffeurId
  Type    : String
  Description: The chauffeur identifier returned by the recommendation engine. May differ from assignedChauffeurId if the coordinator overrode the recommendation.
  Example : "CHFR-00456"

Field: overrideApplied
  Type    : Boolean
  Description: True if the coordinator selected a chauffeur other than the system recommendation.
  Example : true

Field: overrideReason
  Type    : String (nullable)
  Description: The override reason provided by the coordinator. Null if no override was applied.
  Example : "Recommended chauffeur is unfamiliar with this dealership location."

Field: appointmentStatus
  Type    : String
  Description: The updated appointment status following successful reassignment.
  Example : "ASSIGNED"

Field: rerunTimestamp
  Type    : String (ISO 8601 datetime)
  Description: The UTC timestamp at which the recommendation engine was re-invoked for this reassignment cycle.
  Example : "2024-06-01T09:45:00Z"

Field: workflowResumptionQueued
  Type    : Boolean
  Description: Indicates whether the downstream workflow resumption from SER-010-020-007 has been successfully queued.
  Example : true

Field: notificationsDispatched
  Type    : Boolean
  Description: Indicates whether outbound notifications to the newly assigned chauffeur have been dispatched (or queued for dispatch).
  Example : true

Example Response Payload (200):

appointmentId              : "a3f7c821-4d2e-4b1a-9c3f-0e8d7b6a5c12"
reassignmentId             : "REASSIGN-20240601-00078"
roundNumber                : 2
assignedChauffeurId        : "CHFR-00789"
recommendedChauffeurId     : "CHFR-00456"
overrideApplied            : true
overrideReason             : "Recommended chauffeur is unfamiliar with this dealership location."
appointmentStatus          : "ASSIGNED"
rerunTimestamp             : "2024-06-01T09:45:00Z"
workflowResumptionQueued   : true
notificationsDispatched    : true


3.2 HTTP 200 OK — Reassignment Processed, No Eligible Chauffeur Found (No-Match)

Description: The recommendation engine evaluated all available candidates and returned a no-match result. The appointment has been flagged for manual intervention and the Pickup Coordinator has been notified.

Response Body Fields:

Field: appointmentId
  Type    : String
  Example : "a3f7c821-4d2e-4b1a-9c3f-0e8d7b6a5c12"

Field: reassignmentId
  Type    : String
  Example : "REASSIGN-20240601-00079"

Field: roundNumber
  Type    : Integer
  Example : 2

Field: recommendationResult
  Type    : String (Enum)
  Value   : "NO_MATCH"
  Description: Indicates the recommendation engine found no eligible chauffeur.

Field: appointmentStatus
  Type    : String
  Example : "PENDING_MANUAL_INTERVENTION"

Field: rerunTimestamp
  Type    : String (ISO 8601 datetime)
  Example : "2024-06-01T09:45:30Z"

Field: coordinatorNotified
  Type    : Boolean
  Description: Indicates whether the Pickup Coordinator notification for manual intervention has been dispatched.
  Example : true

Example Response Payload (200 No-Match):

appointmentId              : "a3f7c821-4d2e-4b1a-9c3f-0e8d7b6a5c12"
reassignmentId             : "REASSIGN-20240601-00079"
roundNumber                : 2
recommendationResult       : "NO_MATCH"
appointmentStatus          : "PENDING_MANUAL_INTERVENTION"
rerunTimestamp             : "2024-06-01T09:45:30Z"
coordinatorNotified        : true


3.3 HTTP 400 Bad Request

Description: The request body is malformed, missing required fields, or contains values that fail schema-level validation.

Response Body Fields:

Field: errorCode
  Type    : String
  Example : "VALIDATION_ERROR"

Field: message
  Type    : String
  Example : "Request body validation failed."

Field: details
  Type    : Array of objects
  Description: One entry per validation failure.
  Sub-fields: field (String), issue (String)

Example Response Payload (400):

errorCode : "VALIDATION_ERROR"
message   : "Request body validation failed."
details   :
  - field : "failedAssignmentReference"
    issue : "Field is required and must not be blank."
  - field : "failureType"
    issue : "Value 'UNKNOWN_TYPE' is not a valid failureType. Allowed values: CHAUFFEUR_REJECTED, ASSIGNMENT_TIMEOUT, ASSIGNMENT_FAILED."


3.4 HTTP 401 Unauthorized

Description: The Bearer JWT is absent, expired, or invalid.

Example Response Payload (401):

errorCode : "UNAUTHORIZED"
message   : "Authentication token is missing or invalid."


3.5 HTTP 403 Forbidden

Description: The caller is authenticated but does not hold the PICKUP_COORDINATOR role, or does not have dealership/zone-level access to the referenced appointment.

Example Response Payload (403):

errorCode : "FORBIDDEN"
message   : "You do not have permission to perform reassignment on this appointment."


3.6 HTTP 404 Not Found

Description: No appointment record exists for the provided appointmentId. (BR-1)

Example Response Payload (404):

errorCode : "APPOINTMENT_NOT_FOUND"
message   : "Appointment not found for the provided appointmentId."
appointmentId : "a3f7c821-4d2e-4b1a-9c3f-0e8d7b6a5c12"


3.7 HTTP 409 Conflict

Description: Returned in two scenarios:
  (a) The appointment is not in a reassignable state (BR-2).
  (b) A concurrent reassignment operation is already in progress for the same appointmentId (BR-12).

Example Response Payload (409 — State Conflict):

errorCode         : "INVALID_APPOINTMENT_STATE"
message           : "Appointment is not in a reassignable state. Current state does not permit reassignment."
appointmentId     : "a3f7c821-4d2e-4b1a-9c3f-0e8d7b6a5c12"
currentState      : "COMPLETED"

Example Response Payload (409 — Concurrency Conflict):

errorCode         : "REASSIGNMENT_IN_PROGRESS"
message           : "A reassignment is already in progress for this appointment. Please retry after the current operation completes."
appointmentId     : "a3f7c821-4d2e-4b1a-9c3f-0e8d7b6a5c12"


3.8 HTTP 422 Unprocessable Entity

Description: The request is syntactically valid but fails business rule validation

ENDPOINT DESIGN DOCUMENT

Path: /api/v1/appointments/{appointmentId}/reassign
HTTP Method: POST
Summary: Trigger reassignment loop: log failed attempt, re-run recommendation, accept coordinator revised selection
Source Activity IDs: SER-010-020-014, SER-010-020-015, SER-010-020-016


------------------------------------------------------------------------
SECTION 1: ENDPOINT IDENTIFICATION
------------------------------------------------------------------------

Path               : /api/v1/appointments/{appointmentId}/reassign
HTTP Method        : POST
Summary            : Trigger reassignment loop: log failed attempt, re-run recommendation, accept coordinator revised selection
Description        : This endpoint initiates a chauffeur reassignment cycle for an existing appointment. It is invoked either automatically by the system orchestration layer following a chauffeur rejection or acceptance timeout, or manually by a Pickup Coordinator who wishes to override the current assignment. The endpoint records the failure context from the prior assignment cycle, invokes the recommendation engine to produce a new ranked candidate list, resolves the final chauffeur selection (system-recommended or coordinator-overridden), persists the updated assignment, appends an immutable audit entry, and dispatches downstream notifications and integration updates. Each invocation increments the round counter on the appointment record.


------------------------------------------------------------------------
SECTION 2: SECURITY REQUIREMENTS
------------------------------------------------------------------------

Authentication Mechanism:
  Bearer JWT (OAuth2 / OIDC)
  The Authorization header must carry a valid, non-expired JWT signed by the trusted issuer.
  Token signature, expiry (exp claim), issuer (iss claim), and audience (aud claim) are validated on every request.

Authorization Model:
  Role-Based Access Control (RBAC)
  Permitted roles: PICKUP_COORDINATOR, INTEGRATION_SERVICE
  Dealership-scoped access is enforced: the caller's dealership scope embedded in the JWT must match the dealership associated with the target appointment. Cross-dealership reassignment is rejected with 403.

Required OAuth2 Scope:
  appointment:write

Rate Limiting:
  30 requests per minute per authenticated user.
  Burst allowance: up to 10 requests per 10-second window.
  Requests exceeding the rate limit receive HTTP 429 Too Many Requests.

Idempotency Note:
  This endpoint is NOT idempotent. Each successful invocation triggers a new recommendation round and increments the round counter. Callers must not retry on receipt of a 2xx response. On network failure before a response is received, callers must query the current appointment state before retrying to avoid double-incrementing the round counter. A concurrency lock on appointmentId is held for the duration of the reassignment transaction to prevent concurrent reassignment races.


------------------------------------------------------------------------
SECTION 3: REQUEST SPECIFICATION
------------------------------------------------------------------------

3.1 Request Headers

Header Name       : Authorization
Required          : Yes
Format            : Bearer <JWT token>
Description       : OAuth2 / OIDC Bearer token. Must be valid, non-expired, and issued by the trusted identity provider.

Header Name       : Content-Type
Required          : Yes
Allowed Value     : application/json
Description       : Request body must be JSON-encoded.

Header Name       : Accept
Required          : No
Recommended Value : application/json
Description       : Indicates the client expects a JSON response.

Header Name       : X-Correlation-ID
Required          : No
Format            : UUID v4 string
Description       : Optional caller-supplied correlation identifier for distributed tracing. If not provided, the system generates one and includes it in the response.

Header Name       : X-Request-ID
Required          : No
Format            : UUID v4 string
Description       : Optional idempotency hint for logging purposes. Does not confer idempotency behaviour on this endpoint.


3.2 Path Parameters

Parameter Name    : appointmentId
Location          : Path
Type              : String (UUID v4)
Required          : Yes
Format            : UUID v4 (xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx)
Description       : Unique identifier of the appointment to be reassigned. Must correspond to an existing appointment record in the system.
Validation Rules  :
  - Must be a valid UUID v4 format; malformed values return 400.
  - Must resolve to an existing appointment record; non-existent values return 404.
  - The appointment must be in a reassignable lifecycle state; invalid state returns 409.


3.3 Query Parameters

None defined for this endpoint.


3.4 Request Body Schema

Content-Type: application/json

The request body carries the reassignment context including the failure type from the prior cycle, optional coordinator chauffeur selection, and supporting justification fields.

Field: failureType
  Type              : String (enum)
  Required          : Yes
  Allowed Values    : CHAUFFEUR_REJECTED, ACCEPTANCE_TIMEOUT, COORDINATOR_INITIATED
  Description       : Indicates the reason the prior assignment cycle failed and this reassignment is being triggered.
  Validation        : Must be one of the three enumerated values. Missing or unrecognised value returns 400.

Field: rejectionOrTimeoutReason
  Type              : String
  Required          : Conditionally required
  Condition         : Required when failureType is CHAUFFEUR_REJECTED or ACCEPTANCE_TIMEOUT (BR-7).
  Max Length        : 1000 characters
  Description       : Human-readable description of why the prior chauffeur rejected the assignment or why the acceptance window timed out. Must be non-empty when required.
  Validation        : If failureType is CHAUFFEUR_REJECTED or ACCEPTANCE_TIMEOUT and this field is absent or blank, the request is rejected with 422.

Field: selectedChauffeurId
  Type              : String (UUID v4)
  Required          : No
  Format            : UUID v4
  Description       : Coordinator-supplied chauffeur identifier when the Pickup Coordinator wishes to override the system recommendation. If omitted, the system assigns the top-ranked recommended chauffeur.
  Validation        :
    - If provided, must be a valid UUID v4 format.
    - The referenced chauffeur must exist in the system; non-existent value returns 422.
    - If selectedChauffeurId differs from the recommendedChauffeurId produced by the recommendation engine, overrideReason must also be provided (BR-6).
    - The selected chauffeur must be eligible (available, no slot conflict, mapped to the appointment's dealership); ineligible selection returns 422 (BR-12).

Field: overrideReason
  Type              : String
  Required          : Conditionally required
  Condition         : Required when selectedChauffeurId is provided and differs from the system-recommended chauffeur (BR-6).
  Max Length        : 1000 characters
  Description       : Justification provided by the Pickup Coordinator for selecting a chauffeur other than the system recommendation.
  Validation        : If the override condition is met and this field is absent or blank, the request is rejected with 422.

Field: notes
  Type              : String
  Required          : No
  Max Length        : 2000 characters
  Description       : Optional free-text notes from the coordinator providing additional context for the reassignment. Persisted to the audit record.

Example Request Body (Coordinator Override):

  {
    "failureType": "CHAUFFEUR_REJECTED",
    "rejectionOrTimeoutReason": "Chauffeur declined due to personal emergency.",
    "selectedChauffeurId": "b3f1c2d4-5e6f-4a7b-8c9d-0e1f2a3b4c5d",
    "overrideReason": "Only available chauffeur with required vehicle class in the area.",
    "notes": "Coordinator manually reviewed availability before selection."
  }

Example Request Body (System-Triggered Timeout, No Override):

  {
    "failureType": "ACCEPTANCE_TIMEOUT",
    "rejectionOrTimeoutReason": "Chauffeur did not respond within the 10-minute acceptance window.",
    "selectedChauffeurId": null,
    "overrideReason": null,
    "notes": null
  }


------------------------------------------------------------------------
SECTION 4: RESPONSE SPECIFICATION
------------------------------------------------------------------------

4.1 HTTP 200 OK — Reassignment Successful

Description: The appointment has been successfully reassigned to a new chauffeur. The round counter has been incremented, the audit entry has been written, and downstream notifications and integration updates have been dispatched.

Response Body Schema:

Field: appointmentId
  Type    : String (UUID v4)
  Description: Identifier of the reassigned appointment.

Field: status
  Type    : String (enum)
  Description: Updated lifecycle status of the appointment. Typically ASSIGNED following a successful reassignment.

Field: assignedChauffeurId
  Type    : String (UUID v4)
  Description: Identifier of the newly assigned chauffeur.

Field: recommendedChauffeurId
  Type    : String (UUID v4)
  Description: Identifier of the chauffeur recommended by the recommendation engine. May equal assignedChauffeurId if no override was applied.

Field: roundNumber
  Type    : Integer
  Description: The incremented round counter reflecting how many assignment cycles have been executed for this appointment.

Field: overrideApplied
  Type    : Boolean
  Description: True if the coordinator selected a chauffeur other than the system recommendation; false otherwise.

Field: overrideReason
  Type    : String or null
  Description: The override justification if overrideApplied is true; null otherwise.

Field: failureType
  Type    : String (enum)
  Description: The failure type recorded for the prior cycle that triggered this reassignment.

Field: auditEntryId
  Type    : String (UUID v4)
  Description: Identifier of the immutable audit record created for this reassignment event.

Field: rerunTimestamp
  Type    : String (ISO 8601 datetime)
  Description: Timestamp at which the reassignment cycle was executed.

Field: correlationId
  Type    : String (UUID v4)
  Description: Correlation identifier for distributed tracing.

Example 200 Response:

  {
    "appointmentId": "a1b2c3d4-e5f6-4a7b-8c9d-0e1f2a3b4c5d",
    "status": "ASSIGNED",
    "assignedChauffeurId": "b3f1c2d4-5e6f-4a7b-8c9d-0e1f2a3b4c5d",
    "recommendedChauffeurId": "c4d5e6f7-7a8b-4c9d-0e1f-2a3b4c5d6e7f",
    "roundNumber": 3,
    "overrideApplied": true,
    "overrideReason": "Only available chauffeur with required vehicle class in the area.",
    "failureType": "CHAUFFEUR_REJECTED",
    "auditEntryId": "f7e6d5c4-b3a2-4f1e-9d8c-7b6a5f4e3d2c",
    "rerunTimestamp": "2025-07-14T10:35:22Z",
    "correlationId": "9a8b7c6d-5e4f-4a3b-2c1d-0e9f8a7b6c5d"
  }


4.2 HTTP 200 OK — No Eligible Chauffeur Found (No-Match Result)

Description: The recommendation engine completed its evaluation but found no eligible chauffeur. The appointment has been placed in PENDING_MANUAL_ASSIGNMENT status and the Pickup Coordinator has been notified.

Response Body Schema: Same structure as the success response with the following differences:

Field: status
  Value   : PENDING_MANUAL_ASSIGNMENT

Field: assignedChauffeurId
  Value   : null

Field: recommendedChauffeurId
  Value   : null

Field: noMatchReason
  Type    : String
  Description: Human-readable explanation of why no eligible chauffeur was found (e.g. no available chauffeurs mapped to the dealership within the required time window).

Example No-Match Response:

  {
    "appointmentId": "a1b2c3d4-e5f6-4a7b-8c9d-0e1f2a3b4c5d",
    "status": "PENDING_MANUAL_ASSIGNMENT",
    "assignedChauffeurId": null,
    "recommendedChauffeurId": null,
    "roundNumber": 3,
    "overrideApplied": false,
    "overrideReason": null,
    "failureType": "ACCEPTANCE_TIMEOUT",
    "noMatchReason": "No chauffeurs available and mapped to the dealership within the required pickup window.",
    "auditEntryId": "e6d5c4b3-a2f1-4e9d-8c7b-6a5f4e3d2c1b",
    "rerunTimestamp": "2025-07-14T10:35:22Z",
    "correlationId": "9a8b7c6d-5e4f-4a3b-2c1d-0e9f8a7b6c5d"
  }


4.3 HTTP 400 Bad Request

Description: The request is syntactically malformed or contains an invalid field value (e.g. malformed UUID, unrecognised failureType enum value, missing required header).

Response Body Schema:

Field: errorCode     : String — machine-readable error code (e.g. INVALID_REQUEST)
Field: errorMessage  : String — human-readable description of the validation failure
Field: fieldErrors   : Array of objects, each containing:
  - field            : String — name

ENDPOINT DESIGN: GET /api/v1/drop-requests/by-jc/{jcNumber}

================================================================================
SECTION 1: ENDPOINT IDENTIFICATION
================================================================================

Path            : /api/v1/drop-requests/by-jc/{jcNumber}
HTTP Method     : GET
Summary         : Retrieve the drop request linked to a specific Job Card number
Description     : Fetches all drop request records associated with the supplied
                  Job Card (JC) number. The response includes auto-populated
                  promised delivery date and time sourced directly from the Job
                  Card record. This endpoint is consumed by the DBP scheduling
                  dashboard and the ChauffeurAssignmentOrchestrationService
                  during the Appointment Booking workflow stage (SER-010-020).
                  The operation is strictly read-only; no state mutations occur.
Source Activity : SER-010-020-094
Operation Type  : Read-only (inherently idempotent)


================================================================================
SECTION 2: REQUEST SPECIFICATION
================================================================================

2.1 REQUEST HEADERS
--------------------------------------------------------------------------------

Header Name       Required   Type     Description
Authorization     Yes        String   Bearer JWT token. Format: "Bearer <token>".
                                      Token must be valid, unexpired, and issued
                                      by the authorised OAuth2/OIDC provider.
Content-Type      No         String   Not required for GET requests.
Accept            No         String   Recommended: application/json.
                                      Defaults to application/json if omitted.
X-Correlation-ID  No         String   Optional caller-supplied correlation
                                      identifier for distributed tracing and
                                      log correlation. UUID format recommended.
                                      If not supplied, the system generates one
                                      internally for trace propagation.


2.2 PATH PARAMETERS
--------------------------------------------------------------------------------

Parameter   Required   Type     Location   Description
jcNumber    Yes        String   Path       The Job Card number used to look up
                                           associated drop request records.

Validation Rules for jcNumber:
  - Must be non-null and non-empty.
  - Must conform to the expected JC number format (alphanumeric string;
    exact regex pattern to be confirmed against the JC number standard
    defined in the system's domain model, e.g., pattern: ^[A-Z]{2,3}-\d{6,10}$
    or equivalent as per the JC numbering scheme in use).
  - Maximum length: 50 characters (recommended upper bound; confirm with
    domain model).
  - Whitespace-only values are treated as invalid.
  - Validation is performed before any downstream service call is made.
  - Failure to meet format requirements results in HTTP 400 (see BR-4).


2.3 QUERY PARAMETERS
--------------------------------------------------------------------------------

None. This endpoint does not accept query parameters.


2.4 REQUEST BODY
--------------------------------------------------------------------------------

None. This is a GET endpoint; no request body is accepted or processed.


================================================================================
SECTION 3: RESPONSE SPECIFICATION
================================================================================

3.1 HTTP 200 - SUCCESS
--------------------------------------------------------------------------------

Description:
  One or more drop request records associated with the supplied JC number were
  found and are returned. Promised delivery date and time are auto-populated
  from the Job Card record.

Response Body Schema (top-level object):

  Field                  Type      Required   Description
  status                 String    Yes        Fixed value: "success"
  data                   Object    Yes        Wrapper object containing the
                                              drop request payload.
  data.jcNumber          String    Yes        The Job Card number supplied in
                                              the request path.
  data.dropRequests      Array     Yes        List of drop request records
                                              linked to the JC number. Contains
                                              one or more DropRequest objects.

  DropRequest Object Fields:

  Field                       Type      Required   Description
  dropRequestId               String    Yes        Unique identifier of the
                                                   drop request record.
  jcNumber                    String    Yes        Job Card number associated
                                                   with this drop request.
  promisedDeliveryDate        String    Yes        Auto-populated from the Job
                                                   Card. Format: ISO 8601 date
                                                   (YYYY-MM-DD).
  promisedDeliveryTime        String    Yes        Auto-populated from the Job
                                                   Card. Format: HH:mm (24-hour)
                                                   or ISO 8601 time string.
  dropRequestStatus           String    Yes        Current status of the drop
                                                   request (e.g., PENDING,
                                                   CONFIRMED, COMPLETED).
  createdAt                   String    Yes        Timestamp of record creation.
                                                   ISO 8601 datetime with
                                                   timezone offset.
  updatedAt                   String    Yes        Timestamp of last update.
                                                   ISO 8601 datetime with
                                                   timezone offset.

Example Response Payload (HTTP 200):

  status: success
  data:
    jcNumber: JC-000123456
    dropRequests:
      - dropRequestId: DR-78901
        jcNumber: JC-000123456
        promisedDeliveryDate: 2025-08-15
        promisedDeliveryTime: 14:30
        dropRequestStatus: PENDING
        createdAt: 2025-07-01T09:00:00+05:30
        updatedAt: 2025-07-10T11:45:00+05:30


3.2 HTTP 400 - BAD REQUEST
--------------------------------------------------------------------------------

Description:
  The jcNumber path parameter is missing, blank, null, or does not conform to
  the expected JC number format. No downstream lookup is attempted.
  Triggered by: BR-4.

Response Body Schema:

  Field       Type     Required   Description
  status      String   Yes        Fixed value: "error"
  errorCode   String   Yes        Application-level error code.
  message     String   Yes        Human-readable error description.
  details     Array    No         List of field-level validation error objects.

  Validation Error Object:
  Field       Type     Description
  field       String   Name of the invalid field (e.g., "jcNumber").
  issue       String   Description of the specific validation failure.

Example Response Payload (HTTP 400):

  status: error
  errorCode: INVALID_JC_NUMBER_FORMAT
  message: Invalid or missing JC number format.
  details:
    - field: jcNumber
      issue: jcNumber must be non-empty and conform to the expected JC number
             format.


3.3 HTTP 401 - UNAUTHORIZED
--------------------------------------------------------------------------------

Description:
  The request does not include a valid Bearer JWT token, the token is expired,
  the token signature is invalid, or the issuer is not recognised.
  Triggered by: BR-6.

Response Body Schema:

  Field       Type     Required   Description
  status      String   Yes        Fixed value: "error"
  errorCode   String   Yes        Application-level error code.
  message     String   Yes        Human-readable error description.

Example Response Payload (HTTP 401):

  status: error
  errorCode: UNAUTHORIZED
  message: Unauthorized: valid Bearer JWT token is required.


3.4 HTTP 403 - FORBIDDEN
--------------------------------------------------------------------------------

Description:
  The caller is authenticated (valid JWT) but does not hold a role that is
  permitted to access drop request data. Permitted roles are:
  PICKUP_COORDINATOR, ADMIN, INTEGRATION_SERVICE.

Response Body Schema:

  Field       Type     Required   Description
  status      String   Yes        Fixed value: "error"
  errorCode   String   Yes        Application-level error code.
  message     String   Yes        Human-readable error description.

Example Response Payload (HTTP 403):

  status: error
  errorCode: FORBIDDEN
  message: Access denied: caller does not hold a role authorised to read
           drop request data.


3.5 HTTP 404 - NOT FOUND (Job Card not found)
--------------------------------------------------------------------------------

Description:
  The supplied jcNumber does not correspond to any existing Job Card record
  in the system. Triggered by: BR-1.

Response Body Schema:

  Field       Type     Required   Description
  status      String   Yes        Fixed value: "error"
  errorCode   String   Yes        Application-level error code.
  message     String   Yes        Human-readable error description.

Example Response Payload (HTTP 404 - JC not found):

  status: error
  errorCode: JOB_CARD_NOT_FOUND
  message: Job Card not found for the supplied JC number.


3.6 HTTP 404 - NOT FOUND (Drop request not found)
--------------------------------------------------------------------------------

Description:
  The Job Card exists but no drop request record is associated with the
  supplied JC number. Triggered by: BR-7.

Example Response Payload (HTTP 404 - Drop request not found):

  status: error
  errorCode: DROP_REQUEST_NOT_FOUND
  message: No drop request found for the supplied JC number.


3.7 HTTP 500 - INTERNAL SERVER ERROR
--------------------------------------------------------------------------------

Description:
  An unexpected server-side error occurred during processing

ENDPOINT DESIGN: POST /api/v1/trips/{tripId}/qr-summary

================================================================================
SECTION 1: ENDPOINT IDENTIFICATION
================================================================================

Path            : /api/v1/trips/{tripId}/qr-summary
HTTP Method     : POST
Summary         : Generate and persist the QR-coded trip summary card after pickup handover is complete
Source Activity IDs : SER-010-020-078, SER-010-020-081
Workflow Stage  : SER-010-020 (Confirmed Appointment Booking)
Next Workflow Step  : SER-010-020-082 (post-generation transition)

Description:
This endpoint generates a QR-coded trip summary card for a confirmed appointment
booking trip. It encodes the trip's registration number, vehicle name, pick-up
date, pick-up time, and drop location into a unique QR code, assembles a summary
payload, persists it against the trip record, advances the trip workflow state,
dispatches the summary to the assigned Chauffeur via the configured notification
channel, and appends an immutable audit trail entry. The operation is fully
automated and requires no manual intervention once triggered.


================================================================================
SECTION 2: REQUEST SPECIFICATION
================================================================================

2.1 Request Headers
--------------------------------------------------------------------------------

Header Name         : Authorization
Required            : Yes
Format              : Bearer <JWT token>
Description         : OAuth2/OIDC Bearer JWT. Must be a valid, non-expired token
                      signed by the trusted issuer. The JWT sub claim is used as
                      the acting principal for audit and authorization purposes.

Header Name         : Content-Type
Required            : No (no request body for this endpoint)
Accepted Value      : application/json
Description         : Should be set to application/json if any future extension
                      adds a request body. Currently no body is expected.

Header Name         : X-Correlation-ID
Required            : No (strongly recommended)
Format              : UUID v4 string, e.g. 550e8400-e29b-41d4-a716-446655440000
Description         : Caller-supplied correlation identifier for distributed
                      tracing, deduplication in retry scenarios, and log
                      correlation across services. If not supplied, the system
                      generates one internally and includes it in the response.

Header Name         : X-Request-ID
Required            : No (recommended)
Format              : UUID v4 string
Description         : Idempotency key for the request. If a prior successful
                      response was returned for the same tripId, the system
                      returns the existing QR summary without regenerating.

Header Name         : Accept
Required            : No
Accepted Value      : application/json
Description         : Indicates the caller expects a JSON response body.


2.2 Path Parameters
--------------------------------------------------------------------------------

Parameter Name  : tripId
Location        : Path
Type            : String
Required        : Yes
Format          : Non-empty string; expected to be a UUID v4 or system-defined
                  trip identifier. Example: "TRP-20240601-00123"
Min Length      : 1 character
Max Length      : 64 characters
Regex           : ^[A-Za-z0-9\-_]{1,64}$
Description     : The unique identifier of the trip for which the QR summary is
                  to be generated. Must correspond to a persisted trip record in
                  a confirmed appointment booking state.
Validation Errors:
  - If absent or empty: 400 Bad Request, field-level error on tripId.
  - If no matching trip record found: 404 Not Found.


2.3 Query Parameters
--------------------------------------------------------------------------------

None defined for this endpoint.


2.4 Request Body
--------------------------------------------------------------------------------

No request body is required or accepted for this endpoint. All input is derived
from the path parameter (tripId) and the authenticated principal's JWT claims.
The system resolves all trip data fields internally from the persisted trip record.


================================================================================
SECTION 3: RESPONSE SPECIFICATION
================================================================================

3.1 HTTP 200 OK — QR Summary Already Exists (Idempotent Return)
--------------------------------------------------------------------------------

Condition       : A QR summary has already been generated and persisted for the
                  given tripId. The existing summary is returned without
                  regenerating the QR code.

Response Headers:
  Content-Type        : application/json
  X-Correlation-ID    : Echo of the request correlation ID or system-generated.
  X-Idempotent-Result : true

Response Body Schema:

  Field               : status
  Type                : String
  Description         : Outcome indicator. Value: "success"

  Field               : message
  Type                : String
  Description         : Human-readable outcome message.
  Example Value       : "QR summary already exists for this trip. Returning existing record."

  Field               : data
  Type                : Object
  Description         : The QR summary payload.

    Field             : tripId
    Type              : String
    Description       : The trip identifier.
    Example Value     : "TRP-20240601-00123"

    Field             : qrCode
    Type              : String
    Format            : Base64-encoded PNG image data or a data URI
                        (data:image/png;base64,<encoded>)
    Description       : The generated QR code image encoding the trip details.
    Example Value     : "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAA..."

    Field             : vehicleName
    Type              : String
    Description       : Name or model of the vehicle assigned to the trip.
    Example Value     : "Mercedes-Benz S-Class"

    Field             : registrationNumber
    Type              : String
    Description       : Vehicle registration/license plate number.
    Example Value     : "DXB-A-12345"

    Field             : pickUpDate
    Type              : String
    Format            : ISO 8601 date, YYYY-MM-DD
    Description       : Scheduled pick-up date.
    Example Value     : "2024-06-15"

    Field             : pickUpTime
    Type              : String
    Format            : HH:mm (24-hour) or ISO 8601 time
    Description       : Scheduled pick-up time.
    Example Value     : "09:30"

    Field             : dropLocation
    Type              : String
    Description       : Destination drop-off location.
    Example Value     : "Dubai International Airport, Terminal 3"

    Field             : generatedAt
    Type              : String
    Format            : ISO 8601 datetime with timezone, e.g. 2024-06-01T07:22:10Z
    Description       : Timestamp when the QR summary was originally generated.
    Example Value     : "2024-06-01T07:22:10Z"

    Field             : generatedBy
    Type              : String
    Description       : JWT sub claim of the principal who originally triggered
                        the generation.
    Example Value     : "usr-00456"

  Field               : correlationId
  Type                : String
  Description         : Correlation ID for tracing.
  Example Value       : "550e8400-e29b-41d4-a716-446655440000"

Example Response Payload (200):

  status: "success"
  message: "QR summary already exists for this trip. Returning existing record."
  data:
    tripId: "TRP-20240601-00123"
    qrCode: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAA..."
    vehicleName: "Mercedes-Benz S-Class"
    registrationNumber: "DXB-A-12345"
    pickUpDate: "2024-06-15"
    pickUpTime: "09:30"
    dropLocation: "Dubai International Airport, Terminal 3"
    generatedAt: "2024-06-01T07:22:10Z"
    generatedBy: "usr-00456"
  correlationId: "550e8400-e29b-41d4-a716-446655440000"


3.2 HTTP 201 Created — QR Summary Successfully Generated
--------------------------------------------------------------------------------

Condition       : A new QR summary has been generated, persisted, and the
                  workflow state has been advanced to SER-010-020-082.

Response Headers:
  Content-Type        : application/json
  Location            : /api/v1/trips/{tripId}/qr-summary
  X-Correlation-ID    : Echo of the request correlation ID or system-generated.
  X-Idempotent-Result : false

Response Body Schema: (identical structure to 200 above)

  Field               : status
  Type                : String
  Value               : "success"

  Field               : message
  Type                : String
  Example Value       : "QR summary generated successfully."

  Field               : data
  Type                : Object
  Description         : Same schema as described under 200 above.

  Field               : correlationId
  Type                : String

Example Response Payload (201):

  status: "success"
  message: "QR summary generated successfully."
  data:
    tripId: "TRP-20240601-00123"
    qrCode: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAA..."
    vehicleName: "Mercedes-Benz S-Class"
    registrationNumber: "DXB-A-12345"
    pickUpDate: "2024-06-15"
    pickUpTime: "09:30"
    dropLocation: "Dubai International Airport, Terminal 3"
    generatedAt: "2024-06-15T06:45:00Z"
    generatedBy: "usr-00789"
  correlationId: "660e9500-f30c-52e5-b827-557766551111"


3.3 HTTP 400 Bad Request — Validation Failure
--------------------------------------------------------------------------------

Condition       : One or more mandatory trip fields (registration number, vehicle
                  name, pick-up date, pick-up time, drop location) are missing or
                  null on the trip record, or the tripId path parameter fails
                  format validation.

Response Body Schema:

  Field               : status
  Type                : String
  Value               : "error"

  Field               : errorCode
  Type                : String
  Value               : "VALIDATION_ERROR"

  Field               : message
  Type                : String
  Example Value       : "One or more required fields for QR summary generation
                         are missing: registration number, vehicle name, pick-up
                         date, pick-up time, drop location."

  Field               : errors
  Type                : Array of objects
  Description         : List of individual field-level validation failures.

    Sub-field         : field
    Type              : String
    Description       : Name of the failing field.

    Sub-field         : issue
    Type              : String
    Description       : Description of the validation failure.

  Field               : correlationId
  Type                : String

Example Response Payload (400):

  status: "error"
  errorCode: "VALIDATION_ERROR"
  message: "One or more required fields for QR summary generation are missing."
  errors:
    - field: "registrationNumber"
      issue: "Field is null or missing on the trip record."
    - field: "pickUpTime"
      issue: "Field is null or missing on the trip record."
  correlationId: "770fa600-g41d-63f6-c938-668877662222"


3.4 HTTP 401 Unauthorized — Authentication Failure
--------------------------------------------------------------------------------

Condition       : The Bearer JWT is absent, expired, malformed, or fails
                  signature verification.

Response Body Schema:

  Field               : status
  Type                : String
  Value               : "error"

  Field               : errorCode
  Type                : String
  Value               : "UNAUTHORIZED"

  Field               : message
  Type                : String
  Example Value       : "Authentication required. A valid Bearer JWT must be
                         provided."

  Field               : correlationId
  Type                : String

Example Response Payload (401):

  status: "error"
  errorCode: "UNAUTHORIZED"
  message: "Authentication required. A valid Bearer JWT must be provided."
  correlationId: "880gb711-h52e-74g7-d049-779988773333"


3.5 HTTP 403 Forbidden — Authorization Failure
--------------------------------------------------------------------------------

Condition       : The caller is authenticated but does not hold a permitted role,
                  or the caller holds the CHAUFFEUR role but the tripId is not
                  assigned to them.

Response Body Schema:

  Field               : status
  Type                : String
  Value               : "error"

  Field               : errorCode
  Type                : String
  Value               : "FORBIDDEN"

ENDPOINT DESIGN DOCUMENT
=========================

Endpoint: GET /api/v1/trips/{tripId}/qr-summary
Source Requirement: SER-010-020-081


---------------------------------------------------------------------------
SECTION 1 - ENDPOINT OVERVIEW
---------------------------------------------------------------------------

Path            : /api/v1/trips/{tripId}/qr-summary
HTTP Method     : GET
Summary         : Retrieve the QR-coded trip summary card for display on the Chauffeur app
Description     : Returns a structured QR summary payload for a specified trip. The summary
                  includes the QR code artifact, vehicle name, vehicle registration number,
                  confirmed pickup date, confirmed pickup time, and confirmed drop location.
                  This endpoint is consumed primarily by the Chauffeur stakeholder during the
                  appointment booking stage (SER-010-020) to verify trip details at the point
                  of pickup. The operation is read-only and produces no mutations to trip data.


---------------------------------------------------------------------------
SECTION 2 - REQUEST SPECIFICATION
---------------------------------------------------------------------------

2.1 Request Headers
-------------------

Header Name       : Authorization
Required          : Yes
Format            : Bearer <JWT token>
Description       : OAuth2 / OIDC Bearer token. Must be a valid, non-expired JWT signed by
                    the trusted issuer. The token must carry the principal identity and role
                    claims used for RBAC and trip-ownership evaluation.

Header Name       : Accept
Required          : No (defaults to application/json)
Allowed Values    : application/json
Description       : Specifies the expected response media type.

Header Name       : X-Request-ID
Required          : No
Format            : UUID v4
Description       : Optional caller-supplied correlation identifier for distributed tracing
                    and log correlation. If absent, the system generates one internally.


2.2 Path Parameters
-------------------

Parameter Name    : tripId
Location          : Path
Required          : Yes
Type              : String
Format            : Non-empty string; must conform to the system's trip identifier format
                    (alphanumeric, hyphens permitted, no whitespace)
Min Length        : 1
Max Length        : 64
Validation Rules  : Must be a well-formed identifier. Requests with a blank, null, or
                    malformed tripId are rejected with HTTP 400 before any downstream
                    lookup is attempted.
Example           : trip-00a1b2c3-d4e5-4f67-89ab-cdef01234567


2.3 Query Parameters
--------------------

None defined for this endpoint.


2.4 Request Body
----------------

Not applicable. This is a GET operation and carries no request body.


---------------------------------------------------------------------------
SECTION 3 - RESPONSE SPECIFICATION
---------------------------------------------------------------------------

3.1 HTTP 200 - Success
-----------------------

Description : The QR summary was successfully assembled and returned. All six mandatory
              fields are present and resolved from the live trip state.

Response Body Schema:

  Field Name          : status
  Type                : String
  Description         : Fixed value indicating success.
  Example             : "success"

  Field Name          : data
  Type                : Object
  Description         : Container for the QR summary payload.

    Field Name        : qrCode
    Type              : String
    Format            : Base64-encoded image data or a URL pointing to the QR code artifact
    Required          : Yes
    Description       : The QR code artifact associated with the trip. Represents the
                        scannable code used at pickup for identity and trip verification.
    Example           : "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAA..."

    Field Name        : vehicleName
    Type              : String
    Required          : Yes
    Description       : The display name of the vehicle currently assigned to the trip.
    Max Length        : 255
    Example           : "Mercedes-Benz S-Class"

    Field Name        : registrationNumber
    Type              : String
    Required          : Yes
    Description       : The registration plate number of the vehicle currently assigned to
                        the trip. Reflects the live assignment at the time of the request,
                        not the assignment at the time of QR generation.
    Max Length        : 20
    Example           : "DL 01 AB 1234"

    Field Name        : pickupDate
    Type              : String
    Format            : ISO 8601 date (YYYY-MM-DD)
    Required          : Yes
    Description       : The confirmed scheduled pickup date for the trip. Only confirmed
                        values are returned; draft or tentative dates are excluded.
    Example           : "2025-08-15"

    Field Name        : pickupTime
    Type              : String
    Format            : ISO 8601 time (HH:MM:SS or HH:MM) in 24-hour notation
    Required          : Yes
    Description       : The confirmed scheduled pickup time for the trip. Only confirmed
                        values are returned; draft or tentative times are excluded.
    Example           : "09:30:00"

    Field Name        : dropLocation
    Type              : String
    Required          : Yes
    Description       : The most recently confirmed drop location associated with the trip.
                        If the drop location was updated prior to this request, the latest
                        confirmed value is returned.
    Max Length        : 500
    Example           : "Terminal 3, Indira Gandhi International Airport, New Delhi"

Example 200 Response Payload:

  status: "success"
  data:
    qrCode: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAA..."
    vehicleName: "Mercedes-Benz S-Class"
    registrationNumber: "DL 01 AB 1234"
    pickupDate: "2025-08-15"
    pickupTime: "09:30:00"
    dropLocation: "Terminal 3, Indira Gandhi International Airport, New Delhi"


3.2 HTTP 400 - Bad Request
---------------------------

Description : The request is malformed. The tripId path parameter is missing, blank,
              or does not conform to the expected identifier format.

Response Body Schema:

  Field Name          : status
  Type                : String
  Example             : "error"

  Field Name          : errorCode
  Type                : String
  Example             : "INVALID_REQUEST"

  Field Name          : message
  Type                : String
  Example             : "The tripId path parameter is missing or malformed."

  Field Name          : timestamp
  Type                : String (ISO 8601 datetime)
  Example             : "2025-08-15T09:00:00Z"

  Field Name          : requestId
  Type                : String
  Example             : "req-abc123"


3.3 HTTP 401 - Unauthorized
----------------------------

Description : The Bearer JWT is absent, expired, or fails signature or issuer validation.
              The caller must re-authenticate and present a valid token.

Response Body Schema:

  Field Name          : status
  Type                : String
  Example             : "error"

  Field Name          : errorCode
  Type                : String
  Example             : "UNAUTHORIZED"

  Field Name          : message
  Type                : String
  Example             : "Authentication token is missing, expired, or invalid."

  Field Name          : timestamp
  Type                : String (ISO 8601 datetime)
  Example             : "2025-08-15T09:00:01Z"

  Field Name          : requestId
  Type                : String
  Example             : "req-abc124"


3.4 HTTP 403 - Forbidden
-------------------------

Description : The principal is authenticated but is not authorized to access the QR summary
              for the specified trip. The principal does not hold an authorized role or, in
              the case of a CHAUFFEUR role, is not the chauffeur assigned to this trip.
              Triggered by Business Rule BR-5.

Response Body Schema:

  Field Name          : status
  Type                : String
  Example             : "error"

  Field Name          : errorCode
  Type                : String
  Example             : "FORBIDDEN"

  Field Name          : message
  Type                : String
  Example             : "Access denied. You are not authorized to view the QR summary for this trip."

  Field Name          : timestamp
  Type                : String (ISO 8601 datetime)
  Example             : "2025-08-15T09:00:02Z"

  Field Name          : requestId
  Type                : String
  Example             : "req-abc125"


3.5 HTTP 404 - Not Found
-------------------------

Description : No trip record exists in the system for the provided tripId.
              Triggered by Business Rule BR-1.

Response Body Schema:

  Field Name          : status
  Type                : String
  Example             : "error"

  Field Name          : errorCode
  Type                : String
  Example             : "TRIP_NOT_FOUND"

  Field Name          : message
  Type                : String
  Example             : "Trip not found for the provided tripId."

  Field Name          : timestamp
  Type                : String (ISO 8601 datetime)
  Example             : "2025-08-15T09:00:03Z"

  Field Name          : requestId
  Type                : String
  Example             : "req-abc126"


3.6 HTTP 409 - Conflict
------------------------

Description : The trip record exists but no QR code has been generated or linked to it yet.
              The QR summary cannot be assembled without a QR code artifact.
              Triggered by Business Rule BR-2.

Response Body Schema:

  Field Name          : status
  Type                : String
  Example             : "error"

  Field Name          : errorCode
  Type                : String
  Example             : "QR_CODE_NOT_GENERATED"

  Field Name          : message
  Type                : String
  Example             : "QR code has not been generated for this trip yet. Summary is unavailable."

  Field Name          : timestamp
  Type                : String (ISO 8601 datetime)
  Example             : "2025-08-15T09:00:04Z"

  Field Name          : requestId
  Type                : String
  Example             : "req-abc127"


3.7 HTTP 500 - Internal Server Error
--------------------------------------

Description : One or more of the six mandatory QR summary fields could not be resolved from
              the trip record, or the QR code artifact could

ENDPOINT DESIGN: POST /api/v1/appointments/{appointmentId}/contact-outcome

Source Requirement IDs: SER-010-020-043, SER-010-020-103, SER-010-020-125


------------------------------------------------------------------------
SECTION 1: ENDPOINT IDENTIFICATION
------------------------------------------------------------------------

Path            : /api/v1/appointments/{appointmentId}/contact-outcome
HTTP Method     : POST
Summary         : Pickup Coordinator records contact attempt outcome after
                  handover refusal or drop exception
Description     : Allows an authenticated Pickup Coordinator to record the
                  outcome of a contact attempt made during the SER-010-020
                  Appointment Booking stage. This covers customer contact
                  outcomes (SER-010-020-043), chauffeur contact outcomes
                  following a handover refusal (SER-010-020-103), and
                  chauffeur contact outcomes following a drop exception
                  (SER-010-020-125). Each invocation appends a new,
                  independent contact outcome record to the appointment
                  history. The endpoint is intentionally non-idempotent.


------------------------------------------------------------------------
SECTION 2: SECURITY REQUIREMENTS
------------------------------------------------------------------------

Authentication
  Mechanism     : Bearer JWT token (OAuth2 / OIDC)
  Header        : Authorization: Bearer <token>
  Validation    : Token signature, expiry (exp claim), and issuer (iss
                  claim) must all be verified against the authorised
                  identity provider before any business logic executes.

Authorization
  Model         : Role-Based Access Control (RBAC)
  Required Role : PICKUP_COORDINATOR
  Enforcement   : The authenticated user's role claims within the JWT
                  must include PICKUP_COORDINATOR. Any request from a
                  user without this role is rejected with HTTP 403.
  Ownership     : Implicitly enforced; the coordinator's identity is
                  recorded against the contact outcome and must correspond
                  to a coordinator associated with the appointment.

OAuth2 Scope
  Required Scope: appointment:contact-outcome:write

Rate Limiting
  Policy        : Aligned to the service-wide rate limit policy. No
                  distinct per-endpoint override is defined. Requests
                  exceeding the service-wide threshold receive HTTP 429.


------------------------------------------------------------------------
SECTION 3: REQUEST SPECIFICATION
------------------------------------------------------------------------

3.1 Request Headers

  Header Name       Required   Description
  ----------------  ---------  -----------------------------------------
  Authorization     Yes        Bearer JWT token. Format:
                               "Bearer <token>"
  Content-Type      Yes        Must be "application/json"
  Accept            No         Should be "application/json"
  X-Correlation-ID  No         Optional caller-supplied correlation
                               identifier for distributed tracing.
                               Passed through to downstream services.

3.2 Path Parameters

  Parameter Name  Type    Required  Description
  --------------  ------  --------  ------------------------------------
  appointmentId   string  Yes       Unique identifier of the appointment
                                    for which the contact outcome is
                                    being recorded. Must correspond to
                                    an existing appointment in the
                                    system. No specific format enforced
                                    at the transport layer; validated
                                    against the appointment repository
                                    at the business logic layer.

3.3 Query Parameters

  None defined for this endpoint.

3.4 Request Body Schema

  Content-Type: application/json

  The request body is a JSON object. All fields are described below with
  their types, constraints, and conditionality.

  Field: contactOutcome
    Type        : string
    Required    : Yes (BR-3)
    Description : Classifies the result of the contact attempt.
    Allowed Values:
      contacted           - Customer or chauffeur was successfully reached
      no_answer           - Contact attempt made; no response received
      refused             - Customer or chauffeur refused
      rescheduled         - Customer requested rescheduling
      cancelled           - Customer requested cancellation
      rejected            - Chauffeur rejected the assignment or handover
      delayed             - Chauffeur confirmed a delay
    Validation  : Must be one of the enumerated values above. Absence or
                  an unrecognised value triggers a 422 error.

  Field: contactAttemptTimestamp
    Type        : string (ISO 8601 datetime with timezone offset)
    Required    : Yes (BR-6)
    Format      : YYYY-MM-DDTHH:mm:ssZ or YYYY-MM-DDTHH:mm:ss+HH:MM
    Description : The actual date and time at which the coordinator
                  attempted to contact the customer or chauffeur.
    Validation  : Must be present. Must not be a future datetime relative
                  to the server's current time at the moment of request
                  processing. Future values are rejected with 422.

  Field: refusalReason
    Type        : string
    Required    : Conditionally required when contactOutcome is "refused"
                  (BR-4)
    Max Length  : 500 characters
    Description : The reason provided by the customer or chauffeur for
                  refusing. Must be supplied when outcome is "refused".
    Validation  : Mandatory if contactOutcome equals "refused". Ignored
                  for other outcome values. Exceeding 500 characters
                  triggers a 422 error.

  Field: customerChoice
    Type        : string
    Required    : Conditionally required when contactOutcome is
                  "cancelled" or "rescheduled" (BR-5)
    Allowed Values:
      cancel      - Customer has chosen to cancel
      reschedule  - Customer has chosen to reschedule
    Description : Explicitly captures the customer's stated preference
                  when the outcome involves cancellation or rescheduling.
    Validation  : Mandatory if contactOutcome is "cancelled" or
                  "rescheduled". Must be one of the allowed values.
                  Absence or invalid value triggers 422.

  Field: rejectionDelayReason
    Type        : string
    Required    : Conditionally required when contactOutcome is
                  "rejected" or "delayed" (BR-9)
    Max Length  : 500 characters
    Description : The reason for the chauffeur's rejection or delay.
                  Applicable to chauffeur contact outcomes per
                  SER-010-020-103 and SER-010-020-125.
    Validation  : Mandatory if contactOutcome is "rejected" or "delayed".
                  Exceeding 500 characters triggers a 422 error.

  Field: chauffeurReference
    Type        : string
    Required    : Conditionally required when the contact outcome
                  pertains to a chauffeur (SER-010-020-103,
                  SER-010-020-125) (BR-8)
    Description : Identifier of the chauffeur involved in the contact
                  attempt. Must match a chauffeur assigned to the
                  referenced appointment or trip.
    Validation  : When present, the referenced chauffeur must be
                  assigned to the appointment or trip. A mismatch
                  triggers a 422 error.

  Field: revisedEtaOrStartTime
    Type        : string (ISO 8601 datetime with timezone offset)
    Required    : No (optional)
    Format      : YYYY-MM-DDTHH:mm:ssZ or YYYY-MM-DDTHH:mm:ss+HH:MM
    Description : The revised estimated time of arrival or revised
                  appointment start time confirmed during the contact
                  attempt. Applicable per SER-010-020-103 and
                  SER-010-020-125.
    Validation  : When provided, must be a valid future datetime relative
                  to the server's current time at the moment of request
                  processing. A non-future value triggers a 422 error
                  (BR-10).

  Field: otherRemarks
    Type        : string
    Required    : No (optional) (BR-12)
    Max Length  : 1000 characters
    Description : Free-text field for additional context or remarks
                  captured by the coordinator alongside the contact
                  outcome. No further semantic validation is applied
                  beyond the length constraint.
    Validation  : Exceeding 1000 characters triggers a 422 error.

  Field: tripReference
    Type        : string
    Required    : No (optional)
    Description : Reference to the trip associated with the appointment,
                  if applicable. Used to contextualise chauffeur contact
                  outcomes per SER-010-020-103 and SER-010-020-125.
    Validation  : No format constraint enforced at transport layer.
                  Validated for existence at the business logic layer
                  when chauffeurReference is also present.

  Field: jcReference
    Type        : string
    Required    : No (optional)
    Description : Job Card reference associated with the appointment,
                  if applicable. Captured per BR-11 for activities
                  SER-010-020-043, SER-010-020-103, SER-010-020-125.
    Validation  : No format constraint enforced at transport layer.

3.5 Conditional Field Summary

  contactOutcome = "refused"
    refusalReason           REQUIRED

  contactOutcome = "cancelled" or "rescheduled"
    customerChoice          REQUIRED

  contactOutcome = "rejected" or "delayed"
    rejectionDelayReason    REQUIRED
    chauffeurReference      REQUIRED (chauffeur-context outcomes)

  revisedEtaOrStartTime present
    Must be a future datetime

  chauffeurReference present
    Must match an assigned chauffeur on the appointment or trip


------------------------------------------------------------------------
SECTION 4: RESPONSE SPECIFICATION
------------------------------------------------------------------------

4.1 HTTP 201 Created — Success

  Description: The contact outcome record was successfully created and
               appended to the appointment's history. Any conditional
               state transitions (cancellation, rescheduling, ETA update)
               have been applied. Downstream notifications have been
               queued asynchronously.

  Response Body Schema:

    Field: contactOutcomeId
      Type        : string
      Description : System-generated unique identifier for the newly
                    created contact outcome record.

    Field: appointmentId
      Type        : string
      Description : The appointment identifier to which this outcome
                    is linked. Echoes the path parameter.

    Field: contactOutcome
      Type        : string
      Description : The outcome value as persisted.

    Field: contactAttemptTimestamp
      Type        : string (ISO 8601)
      Description : The contact attempt timestamp as persisted.

    Field: appointmentStatus
      Type        : string
      Description : The current status of the appointment after
                    processing. Reflects any state transition applied
                    (e.g. "cancelled", "pending_reschedule", "active").

    Field: recordedAt
      Type        : string (ISO 8601)
      Description : Server-side timestamp at which the record was
                    persisted.

    Field: coordinatorUserId
      Type        : string
      Description : The identity of the authenticated Pickup Coordinator
                    as extracted from the JWT and recorded against the
                    outcome.

  Example Payload (contacted outcome, no state transition):

    contactOutcomeId        : "co-00291847"
    appointmentId           : "appt-10039284"
    contactOutcome          : "contacted"
    contactAttemptTimestamp : "2025-06-15T09:32:00+05:30"
    appointmentStatus       : "active"
    recordedAt              : "2025-06-15T09:33:01+05:30"
    coordinatorUserId       : "usr-coord-00482"

  Example Payload (cancelled outcome, state transition applied):

    contactOutcomeId        : "co-00291848"
    appointmentId           : "appt-10039284"
    contactOutcome          : "cancelled"
    contactAttemptTimestamp : "2025-06-15T10:05:00+05:30"
    appointmentStatus       : "cancelled"
    recordedAt              : "2025-06-15T10:06:12+05:30"
    coordinatorUserId       : "usr-coord-00482"


4.2 HTTP 400 Bad Request

  Description: The request is malformed. This includes syntactically
               invalid JSON, missing Content-Type header, or a
               structurally unparseable request body.

  Response Body Schema:

    Field: errorCode
      Type        : string
      Value       : "BAD_REQUEST"

    Field: message
      Type        : string
      Description : Human-readable description of the malformation.

    Field: correlationId
      Type        : string
      Description : Echoes the X-Correlation-ID header if supplied.

  Example Payload:

    errorCode     : "BAD_REQUEST"
    message       : "Request body could not be parsed as valid JSON."
    correlationId : "corr-abc-001"


4.3 HTTP 401 Unauthorized

  Description: The request does not include a valid Bearer JWT token,
               the token has expired, the signature is invalid, or the
               issuer is not recognised.

  Response Body Schema:

    Field: errorCode
      Type        : string
      Value       : "UNAUTHORIZED"

    Field: message
      Type        : string
      Description : Human-readable description of the authentication
                    failure.

    Field: correlationId
      Type        : string

  Example Payload:

    errorCode     : "UNAUTHORIZED"
    message       : "Bearer token is missing, expired, or invalid."
    correlationId : "corr-abc-002"


4.4 HTTP 403 Forbidden

  Description: The authenticated user does not hold the
               PICKUP_COORDINATOR role or does not have the required
               OAuth

ENDPOINT: PUT /api/v1/drop-requests/{dropRequestId}/status

Source Requirement IDs: SER-010-020-097, SER-010-020-122
Source Activity IDs: SER-010-020-097, SER-010-020-122

--------------------------------------------------------------------------------
1. ENDPOINT OVERVIEW
--------------------------------------------------------------------------------

Path            : /api/v1/drop-requests/{dropRequestId}/status
HTTP Method     : PUT
Summary         : Update the lifecycle status of a drop request.
Description     : Updates the status of an existing drop request through its
                  defined lifecycle transitions. Permitted transitions are:
                  PENDING to SCHEDULED, SCHEDULED to IN_PROGRESS, IN_PROGRESS
                  to COMPLETED, and IN_PROGRESS to CANCELLED. This endpoint is
                  invoked as part of the appointment booking orchestration stage
                  SER-010-020 and, upon successful persistence, triggers the
                  next orchestration workflow step SER-010-020-132. Only callers
                  holding the PICKUP_COORDINATOR role or an authorised internal
                  ORCHESTRATION_SERVICE identity may invoke this operation.

--------------------------------------------------------------------------------
2. REQUEST SPECIFICATION
--------------------------------------------------------------------------------

2a. Request Headers

Header Name       Required   Description
Authorization     Yes        Bearer JWT token issued by the authorised OAuth2/
                             OIDC identity provider. Format: "Bearer <token>".
                             Token must be valid, non-expired, and signed by the
                             trusted issuer. The sub claim is extracted as the
                             actor identity for audit purposes.
Content-Type      Yes        Must be "application/json".
X-Correlation-ID  Recommended  Caller-supplied idempotency or correlation key
                             (UUID v4 format recommended). Used to detect and
                             safely replay duplicate PUT calls without side
                             effects. If omitted, the service generates an
                             internal correlation ID for tracing but idempotency
                             guarantees are reduced.
X-Request-ID      Optional   Unique request identifier for distributed tracing.

2b. Path Parameters

Parameter Name   Type     Required   Description and Validation
dropRequestId    string   Yes        Unique identifier of the drop request to
                                     update. Must be non-empty and conform to
                                     the system identifier format (UUID v4:
                                     pattern [0-9a-fA-F]{8}-[0-9a-fA-F]{4}-
                                     4[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-
                                     [0-9a-fA-F]{12}). A null, empty, or
                                     malformed value triggers a 400 error
                                     (BR-8).

2c. Query Parameters

None.

2d. Request Body Schema

Content-Type: application/json

Field Name   Type     Required   Validation Rules
status       string   Yes        Must be one of the following recognised
                                 lifecycle state values (case-sensitive):
                                 SCHEDULED, IN_PROGRESS, COMPLETED, CANCELLED.
                                 Any value outside this enumeration triggers a
                                 422 error (BR-2). The value must also represent
                                 a permitted forward transition from the current
                                 persisted status; an illegal transition triggers
                                 a 409 error (BR-3).

Request Body Example:

{
  "status": "SCHEDULED"
}

--------------------------------------------------------------------------------
3. RESPONSE SPECIFICATION
--------------------------------------------------------------------------------

3a. HTTP 200 OK — Status Successfully Updated

Returned when the drop request status has been successfully updated, the audit
log entry has been persisted, and the orchestration event has been emitted.

Response Body Schema:

Field Name          Type     Description
dropRequestId       string   The unique identifier of the updated drop request.
previousStatus      string   The status value before this update was applied.
currentStatus       string   The new status value now persisted.
updatedAt           string   UTC ISO-8601 timestamp of when the update was
                             persisted (format: YYYY-MM-DDTHH:mm:ss.sssZ).
correlationId       string   The correlation/idempotency key echoed back from
                             the request header, or the system-generated value
                             if none was supplied.

Response Body Example:

{
  "dropRequestId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
  "previousStatus": "PENDING",
  "currentStatus": "SCHEDULED",
  "updatedAt": "2025-07-14T09:32:11.000Z",
  "correlationId": "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
}

3b. HTTP 400 Bad Request — Invalid Path Parameter

Returned when dropRequestId is null, empty, or does not conform to the expected
identifier format (BR-8).

Response Body Schema:

Field Name   Type     Description
errorCode    string   Machine-readable error code.
message      string   Human-readable description of the error.
field        string   The field or parameter that failed validation.
correlationId string  Correlation ID for tracing.

Response Body Example:

{
  "errorCode": "INVALID_DROP_REQUEST_ID",
  "message": "Invalid dropRequestId format. A valid drop request identifier must be provided.",
  "field": "dropRequestId",
  "correlationId": "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
}

3c. HTTP 401 Unauthorized — Authentication Failure

Returned when the Bearer JWT is absent, expired, malformed, or fails signature
validation.

Response Body Example:

{
  "errorCode": "UNAUTHORIZED",
  "message": "Authentication failed. A valid Bearer JWT token is required.",
  "correlationId": "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
}

3d. HTTP 403 Forbidden — Authorisation Failure

Returned when the authenticated caller does not hold the PICKUP_COORDINATOR
role or an authorised ORCHESTRATION_SERVICE identity (BR-4).

Response Body Example:

{
  "errorCode": "ACCESS_DENIED",
  "message": "Access denied. Caller does not have permission to update drop-request status.",
  "correlationId": "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
}

3e. HTTP 404 Not Found — Drop Request Does Not Exist

Returned when no drop request record exists for the supplied dropRequestId
(BR-1).

Response Body Example:

{
  "errorCode": "DROP_REQUEST_NOT_FOUND",
  "message": "Drop request not found for the provided dropRequestId.",
  "field": "dropRequestId",
  "correlationId": "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
}

3f. HTTP 409 Conflict — Invalid State Transition

Returned when the requested status represents a backward or otherwise
non-permitted transition from the current persisted status (BR-3).

Response Body Example:

{
  "errorCode": "INVALID_STATE_TRANSITION",
  "message": "Invalid state transition. The requested status change is not permitted from the current drop-request status.",
  "currentStatus": "COMPLETED",
  "requestedStatus": "IN_PROGRESS",
  "correlationId": "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
}

3g. HTTP 422 Unprocessable Entity — Unrecognised Status Value

Returned when the status value in the request body is not a recognised lifecycle
state (BR-2).

Response Body Example:

{
  "errorCode": "INVALID_STATUS_VALUE",
  "message": "Invalid status value. Supplied status is not a recognised drop-request lifecycle state.",
  "field": "status",
  "correlationId": "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
}

3h. HTTP 500 Internal Server Error — Orchestration Event or Audit Failure

Returned when the orchestration event emission fails after status persistence
(BR-9), or when the audit trail write fails within the transaction, causing a
full rollback.

Response Body Example:

{
  "errorCode": "INTERNAL_SERVER_ERROR",
  "message": "Status update could not be completed due to an orchestration event failure. Please retry.",
  "correlationId": "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
}

--------------------------------------------------------------------------------
4. BUSINESS RULES
--------------------------------------------------------------------------------

Rule ID   Category       Trigger Condition
BR-1      Pre-condition  PUT request received for a dropRequestId that does not
                         exist in the data store.
          Description    The drop request identified by dropRequestId must exist
                         in the system before a status update can be applied.
          Expected       System rejects the request and returns 404 without
          Behaviour      performing any state transition.
          Error Code     404
          Error Message  "Drop request not found for the provided dropRequestId."

Rule ID   Category       Trigger Condition
BR-2      Validation     The status value in the request body does not match any
                         permitted lifecycle state (SCHEDULED, IN_PROGRESS,
                         COMPLETED, CANCELLED).
          Description    The new status value must be a valid, recognised status
                         within the drop-request lifecycle state machine.
          Expected       System rejects the request with a validation error and
          Behaviour      does not persist any change.
          Error Code     422
          Error Message  "Invalid status value. Supplied status is not a
                         recognised drop-request lifecycle state."

Rule ID   Category       Trigger Condition
BR-3      Business       The requested new status represents a backward or
                         non-permitted transition from the current persisted
                         status.
          Description    Status transitions must follow the defined lifecycle
                         order. Backward or illegal transitions (e.g. COMPLETED
                         back to IN_PROGRESS) are prohibited.
          Expected       System rejects the transition and returns 409,
          Behaviour      preserving the existing status.
          Error Code     409
          Error Message  "Invalid state transition. The requested status change
                         is not permitted from the current drop-request status."

Rule ID   Category       Trigger Condition
BR-4      Business       A caller without the PICKUP_COORDINATOR role or
                         equivalent ORCHESTRATION_SERVICE identity attempts to
                         invoke this endpoint.
          Description    Only the Pickup Coordinator or an authorised automated
                         orchestration process (SER-010-020-097) may update the
                         status of a drop request.
          Expected       System rejects the request with a 403 authorisation
          Behaviour      error.
          Error Code     403
          Error Message  "Access denied. Caller does not have permission to
                         update drop-request status."

Rule ID   Category       Trigger Condition
BR-5      Business       Status is successfully updated and persisted.
          Description    This status update is part of orchestration stage
                         SER-010-020 and must trigger next orchestration step
                         SER-010-020-132 upon successful persistence.
          Expected       System emits an internal orchestration event or message
          Behaviour      to advance the workflow to step SER-010-020-132.
          Error Code     N/A (success path)

Rule ID   Category       Trigger Condition
BR-6      Post-condition Any successful status update is persisted.
          Description    An immutable audit trail entry must be appended
                         recording the old status, new status, actor identity,
                         and UTC timestamp of the transition.
          Expected       System appends an audit record to the append-only audit
          Behaviour      log before returning a success response.
          Error Code     N/A (success path)

Rule ID

ENDPOINT DESIGN DOCUMENT
=========================

Endpoint: POST /api/v1/appointments/{appointmentId}/reschedule
Source Requirement IDs: SER-010-020-032, SER-010-020-033, SER-010-020-034, SER-010-020-035, SER-010-020-036, SER-010-020-037


------------------------------------------------------------------------
SECTION 1: ENDPOINT IDENTIFICATION
------------------------------------------------------------------------

Path            : /api/v1/appointments/{appointmentId}/reschedule
HTTP Method     : POST
Summary         : Initiate OTP-verified rescheduling: accept revised pickup date/time, trigger OTP generation, validate OTP, and update appointment slot
Description     : Allows an authenticated Pickup Coordinator to reschedule an existing appointment by supplying a revised pickup date and time. The system validates the appointment state, persists the revised slot, generates a new OTP bound to the appointment and the revised slot, dispatches the OTP and revised appointment details to the customer via ICP, WhatsApp, and SMS channels, appends an immutable audit trail entry, and returns a rescheduled appointment summary to the caller.


------------------------------------------------------------------------
SECTION 2: REQUEST SPECIFICATION
------------------------------------------------------------------------

2.1 Request Headers
-------------------

Header Name       : Authorization
Required          : Yes
Format            : Bearer <JWT token>
Description       : OAuth2/OIDC Bearer JWT. Must be a valid, non-expired token issued by the authorised identity provider. The token must contain role claims identifying the caller as PICKUP_COORDINATOR.

Header Name       : Content-Type
Required          : Yes
Expected Value    : application/json
Description       : Request body must be JSON-encoded.

Header Name       : Accept
Required          : No
Expected Value    : application/json
Description       : Caller should indicate acceptance of JSON responses.

Header Name       : X-Correlation-ID
Required          : No
Format            : UUID v4 string
Description       : Optional caller-supplied correlation identifier for distributed tracing. If not provided, the system generates one internally and includes it in the response.

Header Name       : X-Idempotency-Key
Required          : No
Format            : String, max 128 characters
Description       : Optional idempotency key supplied by the caller. If not supplied, the system derives an internal idempotency key from the composite of appointmentId and revisedPickupDateTime.


2.2 Path Parameters
-------------------

Parameter Name    : appointmentId
Location          : Path
Type              : String
Required          : Yes
Format            : UUID v4 (e.g., 550e8400-e29b-41d4-a716-446655440000)
Validation Rules  :
  - Must be a non-null, non-empty string.
  - Must conform to UUID v4 format.
  - Must reference an existing appointment record in the data store.
Description       : Unique identifier of the appointment to be rescheduled.


2.3 Query Parameters
--------------------

None defined for this endpoint.


2.4 Request Body Schema
-----------------------

Content-Type      : application/json
Required          : Yes

Field Name              : revisedPickupDateTime
Type                    : String
Format                  : ISO 8601 datetime with timezone offset (e.g., 2025-09-15T14:30:00+05:30)
Required                : Yes
Validation Rules        :
  - Must not be null or empty.
  - Must be a valid ISO 8601 datetime string including timezone offset.
  - Must represent a future datetime relative to the time of request receipt (server-side evaluation).
  - Must fall within the permitted scheduling window as defined by business configuration (e.g., not more than N days in advance, not within a minimum lead-time buffer before the current time).
  - Must not be identical to the current pickup datetime already stored on the appointment (a reschedule to the same slot is a no-op and should be rejected with 422).
Description             : The revised pickup date and time proposed by the Pickup Coordinator for the appointment.

Example Request Body:
  revisedPickupDateTime : 2025-09-15T14:30:00+05:30


------------------------------------------------------------------------
SECTION 3: RESPONSE SPECIFICATION
------------------------------------------------------------------------

3.1 HTTP 200 OK — Successful Reschedule
----------------------------------------

Condition         : The appointment was already in OTP_PENDING_RESCHEDULE state with the same revised slot (idempotent repeat of an in-flight reschedule). The system returns the existing pending state without re-generating OTP or re-dispatching notifications.

Note              : This 200 path applies only to the idempotent repeat scenario where the system suppresses duplicate processing and returns the current state. See also HTTP 409 for the conflict variant of duplicate detection.

Response Body Fields:

  appointmentId             : String (UUID v4) — Unique identifier of the appointment.
  status                    : String — Current appointment status. Value: OTP_PENDING_RESCHEDULE.
  originalPickupDateTime    : String (ISO 8601) — The pickup date and time prior to the reschedule.
  revisedPickupDateTime     : String (ISO 8601) — The newly accepted pickup date and time.
  otpDispatched             : Boolean — Indicates whether OTP was dispatched in this request cycle. Value: false (suppressed for duplicate).
  notificationChannels      : Array of String — Channels through which OTP and appointment details were originally dispatched (ICP, WHATSAPP, SMS).
  correlationId             : String (UUID v4) — Correlation identifier for tracing.
  message                   : String — Human-readable status message.

Example Response (200):
  appointmentId             : 550e8400-e29b-41d4-a716-446655440000
  status                    : OTP_PENDING_RESCHEDULE
  originalPickupDateTime    : 2025-09-10T10:00:00+05:30
  revisedPickupDateTime     : 2025-09-15T14:30:00+05:30
  otpDispatched             : false
  notificationChannels      : [ICP, WHATSAPP, SMS]
  correlationId             : 7f3e1c2a-0001-4b5d-9f8e-aabbccddeeff
  message                   : Reschedule already pending OTP verification for the requested slot. No duplicate OTP generated.


3.2 HTTP 202 Accepted — Reschedule Accepted and Processing
-----------------------------------------------------------

Condition         : The reschedule request passed all validations, the appointment record was updated, OTP was generated, and notifications were dispatched asynchronously. This is the primary success response.

Response Body Fields:

  appointmentId             : String (UUID v4) — Unique identifier of the rescheduled appointment.
  status                    : String — Updated appointment status. Value: RESCHEDULED or OTP_PENDING_RESCHEDULE.
  originalPickupDateTime    : String (ISO 8601) — The pickup date and time prior to the reschedule.
  revisedPickupDateTime     : String (ISO 8601) — The newly accepted pickup date and time.
  otpDispatched             : Boolean — Indicates whether OTP dispatch was triggered. Value: true.
  notificationChannels      : Array of String — Channels to which OTP and appointment details were dispatched (ICP, WHATSAPP, SMS).
  notificationWarnings      : Array of String — Optional. Populated if one or more notification channels reported a delivery failure at dispatch time; retry has been enqueued. Empty array if all channels accepted the message.
  auditTrailId              : String (UUID v4) — Identifier of the audit trail entry created for this reschedule action.
  correlationId             : String (UUID v4) — Correlation identifier for tracing.
  message                   : String — Human-readable confirmation message.

Example Response (202):
  appointmentId             : 550e8400-e29b-41d4-a716-446655440000
  status                    : OTP_PENDING_RESCHEDULE
  originalPickupDateTime    : 2025-09-10T10:00:00+05:30
  revisedPickupDateTime     : 2025-09-15T14:30:00+05:30
  otpDispatched             : true
  notificationChannels      : [ICP, WHATSAPP, SMS]
  notificationWarnings      : []
  auditTrailId              : a1b2c3d4-e5f6-7890-abcd-ef1234567890
  correlationId             : 7f3e1c2a-0001-4b5d-9f8e-aabbccddeeff
  message                   : Appointment rescheduled successfully. OTP and revised appointment details dispatched to customer.

Example Response (202) with notification warning:
  appointmentId             : 550e8400-e29b-41d4-a716-446655440000
  status                    : OTP_PENDING_RESCHEDULE
  originalPickupDateTime    : 2025-09-10T10:00:00+05:30
  revisedPickupDateTime     : 2025-09-15T14:30:00+05:30
  otpDispatched             : true
  notificationChannels      : [ICP, WHATSAPP, SMS]
  notificationWarnings      : [SMS channel delivery failed; retry enqueued.]
  auditTrailId              : a1b2c3d4-e5f6-7890-abcd-ef1234567890
  correlationId             : 7f3e1c2a-0001-4b5d-9f8e-aabbccddeeff
  message                   : Appointment rescheduled successfully. One or more notification channels reported delivery issues; retries have been scheduled.


3.3 HTTP 400 Bad Request — Malformed Request
---------------------------------------------

Condition         : The request body is syntactically invalid, the Content-Type header is missing or incorrect, or a required field is absent or of the wrong type.

Response Body Fields:

  errorCode                 : String — Machine-readable error code. Value: INVALID_REQUEST.
  errorMessage              : String — Human-readable description of the validation failure.
  fieldErrors               : Array of objects — List of field-level validation failures. Each object contains:
      field                 : String — Name of the offending field.
      issue                 : String — Description of the validation failure for that field.
  correlationId             : String (UUID v4) — Correlation identifier for tracing.
  timestamp                 : String (ISO 8601) — Server timestamp at time of error.

Example Response (400):
  errorCode                 : INVALID_REQUEST
  errorMessage              : Request body contains invalid or missing fields.
  fieldErrors               :
      field                 : revisedPickupDateTime
      issue                 : Field is required and must be a valid ISO 8601 datetime string with timezone offset.
  correlationId             : 7f3e1c2a-0001-4b5d-9f8e-aabbccddeeff
  timestamp                 : 2025-08-01T09:00:00+05:30


3.4 HTTP 401 Unauthorized — Authentication Failure
---------------------------------------------------

Condition         : The Authorization header is absent, the Bearer token is missing, the token is expired, or the token signature is invalid.

Response Body Fields:

  errorCode                 : String — Value: UNAUTHORIZED.
  errorMessage              : String — Human-readable description.
  correlationId             : String (UUID v4).
  timestamp                 : String (ISO 8601).

Example Response (401):
  errorCode                 : UNAUTHORIZED
  errorMessage              : Authentication failed. A valid Bearer JWT token is required.
  correlationId             : 7f3e1c2a-0001-4b5d-9f8e-aabbccddeeff
  timestamp                 : 2025-08-01T09:00:00+05:30


3.5 HTTP 403 Forbidden — Authorisation Failure
-----------------------------------------------

Condition         : The caller is authenticated but does not hold the PICKUP_COORDINATOR role in their JWT claims.

Response Body Fields:

  errorCode                 : String — Value: FORBIDDEN.
  errorMessage              : String — Value: Access denied. Only Pickup Coordinators are permitted to reschedule appointments.
  correlationId             : String (UUID v4).
  timestamp                 : String (ISO 8601).

Example Response (403):
  errorCode                 : FORBIDDEN
  errorMessage              : Access denied. Only Pickup Coordinators are permitted to reschedule appointments.
  correlationId             : 7f3e1c2a-0001-4b5d-9f8e-aabbccddeeff
  timestamp                 : 2025-08-01T09:00:00+05:30


3.6 HTTP 404 Not Found — Appointment Not Found
-----------------------------------------------

Condition         : The appointmentId path parameter does not correspond to any persisted appointment record.

Response Body Fields:

  errorCode                 : String — Value: APPOINTMENT_NOT_FOUND.
  errorMessage              : String — Value: Appointment not found for the provided appointmentId.
  appointmentId             : String — The appointmentId value supplied in the request.

ENDPOINT DESIGN: GET /api/v1/drop-requests/by-appointment/{appointmentNumber}

Source Requirement ID: SER-010-020-093


------------------------------------------------------------------------
SECTION 1: ENDPOINT OVERVIEW
------------------------------------------------------------------------

Path            : /api/v1/drop-requests/by-appointment/{appointmentNumber}
HTTP Method     : GET
Summary         : Retrieve the drop request associated with a given service
                  appointment number; used during pickup completion to surface
                  the linked drop request.
Description     : This endpoint fetches the drop request record linked to a
                  specific service appointment from the CRM system. It is
                  invoked by a Pickup Coordinator or an authorised internal
                  service to obtain all drop-request details (customer name,
                  contact, vehicle registration, drop address, requested drop
                  date and time, and linked job card number) so that the DBP
                  pickup and drop scheduling dashboard can display and act on
                  the request. The operation is read-only and inherently
                  idempotent.


------------------------------------------------------------------------
SECTION 2: REQUEST SPECIFICATION
------------------------------------------------------------------------

2.1 Request Headers

Header Name       Required   Format / Allowed Values         Notes
Authorization     Yes        Bearer <JWT>                    OAuth2/OIDC token;
                                                             must be non-expired,
                                                             issued by the
                                                             authorised OIDC
                                                             provider, and contain
                                                             valid audience claim.
Content-Type      No         Not applicable for GET          No request body.
Accept            No         application/json                Defaults to
                                                             application/json if
                                                             omitted.
X-Correlation-ID  No         UUID v4 string                  Caller-supplied
                                                             correlation ID for
                                                             distributed tracing;
                                                             generated by gateway
                                                             if absent.


2.2 Path Parameters

Parameter Name    : appointmentNumber
Location          : Path
Required          : Yes
Type              : String
Format            : Alphanumeric service appointment number; must conform to the
                    expected CRM service appointment number format (non-empty,
                    no whitespace-only value).
Min Length        : 1 character
Max Length        : 50 characters
Regex Constraint  : ^[A-Za-z0-9\-_]+$  (alphanumeric with hyphens and
                    underscores; no spaces or special characters)
Validation Rule   : Must be non-null, non-blank, and match the regex above.
                    Rejected with HTTP 400 if invalid or blank.
Example Value     : SA-2024-00123


2.3 Query Parameters

None defined for this endpoint.


2.4 Request Body

None. This is a GET operation; no request body is accepted.


------------------------------------------------------------------------
SECTION 3: RESPONSE SPECIFICATION
------------------------------------------------------------------------

3.1 HTTP 200 - Success

Condition : Drop request record successfully retrieved from CRM for the
            given appointmentNumber.

Response Body Fields:

Field Name               Type      Required   Description
appointmentNumber        String    Yes        Service appointment number
                                              matching the path parameter.
dropServiceSelected      Boolean   Yes        Indicates whether drop service
                                              was opted in on the appointment.
                                              Will always be true in a 200
                                              response (BR-3 ensures 404 if
                                              false).
customerName             String    Yes        Full name of the customer
                                              associated with the appointment.
customerContact          String    Yes        Customer contact number or email
                                              as stored in CRM.
vehicleRegistrationNumber String   Yes        Vehicle registration number
                                              linked to the service appointment.
dropAddress              String    Yes        Full drop-off address for the
                                              vehicle after service completion.
requestedDropDateTime    String    Yes        ISO 8601 date-time string
                                              representing the customer-
                                              requested drop date and time.
                                              Format: YYYY-MM-DDTHH:mm:ssZ
linkedJcNumber           String    Yes        Job card number linked to the
                                              service appointment in CRM.

Example 200 Response Payload:

{
  "appointmentNumber": "SA-2024-00123",
  "dropServiceSelected": true,
  "customerName": "Rajesh Kumar",
  "customerContact": "+91-9876543210",
  "vehicleRegistrationNumber": "MH12AB1234",
  "dropAddress": "42, Park Street, Pune, Maharashtra - 411001",
  "requestedDropDateTime": "2024-08-15T10:30:00+05:30",
  "linkedJcNumber": "JC-2024-00456"
}


3.2 HTTP 400 - Bad Request

Condition : appointmentNumber path parameter is blank, null, or does not
            match the expected format (BR-5).

Response Body Fields:

Field Name   Type     Description
status       Integer  HTTP status code (400).
errorCode    String   Application-level error code.
message      String   Human-readable error description.
timestamp    String   ISO 8601 timestamp of the error.
correlationId String  Correlation ID for tracing.

Example 400 Response Payload:

{
  "status": 400,
  "errorCode": "INVALID_APPOINTMENT_NUMBER",
  "message": "Invalid or missing appointment number.",
  "timestamp": "2024-08-15T05:00:00Z",
  "correlationId": "c1a2b3d4-e5f6-7890-abcd-ef1234567890"
}


3.3 HTTP 401 - Unauthorised

Condition : Request is received without a valid Bearer JWT, with an expired
            token, or with a token that fails issuer/audience validation
            (BR-6).

Example 401 Response Payload:

{
  "status": 401,
  "errorCode": "UNAUTHORISED",
  "message": "Unauthorised — valid Bearer JWT with required role is mandatory.",
  "timestamp": "2024-08-15T05:00:00Z",
  "correlationId": "c1a2b3d4-e5f6-7890-abcd-ef1234567890"
}


3.4 HTTP 403 - Forbidden

Condition : Bearer JWT is valid and authenticated, but the caller does not
            hold the PICKUP_COORDINATOR or INTEGRATION_SERVICE role required
            to access drop-request data.

Example 403 Response Payload:

{
  "status": 403,
  "errorCode": "FORBIDDEN",
  "message": "Access denied — caller does not hold the required role to access drop-request data.",
  "timestamp": "2024-08-15T05:00:00Z",
  "correlationId": "c1a2b3d4-e5f6-7890-abcd-ef1234567890"
}


3.5 HTTP 404 - Not Found

Condition A (BR-1): No service appointment exists in CRM for the supplied
                    appointmentNumber.
Condition B (BR-3): Service appointment exists but drop-service selection
                    flag is false or absent, meaning no drop request record
                    is linked.

Example 404 Response Payload (Condition A):

{
  "status": 404,
  "errorCode": "APPOINTMENT_NOT_FOUND",
  "message": "No service appointment found for the provided appointment number.",
  "timestamp": "2024-08-15T05:00:00Z",
  "correlationId": "c1a2b3d4-e5f6-7890-abcd-ef1234567890"
}

Example 404 Response Payload (Condition B):

{
  "status": 404,
  "errorCode": "DROP_REQUEST_NOT_FOUND",
  "message": "No drop request linked to this appointment — drop service was not selected.",
  "timestamp": "2024-08-15T05:00:00Z",
  "correlationId": "c1a2b3d4-e5f6-7890-abcd-ef1234567890"
}


3.6 HTTP 500 - Internal Server Error

Condition : An unexpected internal error occurs within the API service
            itself (not a CRM failure; that is covered by 503).

Example 500 Response Payload:

{
  "status": 500,
  "errorCode": "INTERNAL_SERVER_ERROR",
  "message": "An unexpected error occurred. Please contact support.",
  "timestamp": "2024-08-15T05:00:00Z",
  "correlationId": "c1a2b3d4-e5f6-7890-abcd-ef1234567890"
}


3.7 HTTP 503 - Service Unavailable

Condition : CRM integration call fails after all retry attempts are
            exhausted (timeout, connectivity issue, or CRM-side 5xx error),
            or the circuit breaker is open due to sustained CRM
            unavailability (BR-7).

Example 503 Response Payload:

{
  "status": 503,
  "errorCode": "CRM_UNAVAILABLE",
  "message": "Upstream CRM service is currently unavailable. Please retry later.",
  "timestamp": "2024-08-15T05:00:00Z",
  "correlationId": "c1a2b3d4-e5f6-7890-abcd-ef1234567890"
}


------------------------------------------------------------------------
SECTION 4: BUSINESS RULES
------------------------------------------------------------------------

BR-1
  Category          : Pre-condition
  Trigger Condition : A GET request is received for a given appointmentNumber.
  Description       : The appointment number supplied in the path must
                      correspond to an existing service appointment record in
                      CRM before a drop request can be retrieved.
  Expected Behaviour: System validates the appointmentNumber against CRM
                      records before returning any data.
  Error Code        : 404
  Error Message     : No service appointment found for the provided
                      appointment number.

BR-2

ENDPOINT: POST /api/v1/drop-trips/{tripId}/start

Source Requirement IDs: SER-010-020-110, SER-010-020-111

--------------------------------------------------------------------------------
SECTION 1: ENDPOINT IDENTIFICATION
--------------------------------------------------------------------------------

Path            : /api/v1/drop-trips/{tripId}/start
HTTP Method     : POST
Summary         : Chauffeur initiates the drop trip at the system-suggested start
                  time; validates suggested start time window and transitions Trip
                  status to IN_PROGRESS (internally represented as STARTED).
Description     : This endpoint is invoked by the assigned chauffeur to formally
                  start a drop trip. The system validates the caller identity,
                  trip state eligibility, and vehicle registration number before
                  committing the state transition. On success, the trip status is
                  set to STARTED, actual and suggested start timestamps are
                  recorded immutably, an audit trail entry is appended, and
                  downstream systems (notifications, Map API, CRM, DBP) are
                  updated asynchronously.

--------------------------------------------------------------------------------
SECTION 2: SECURITY REQUIREMENTS
--------------------------------------------------------------------------------

Authentication
  Mechanism     : Bearer JWT (OAuth2 / OIDC)
  Header        : Authorization: Bearer <token>
  Token claims required:
    sub         : Chauffeur unique identifier (used for ownership check)
    roles       : Must contain CHAUFFEUR
    exp         : Token must not be expired
    iss / aud   : Must match configured issuer and audience values

Authorization
  Model         : RBAC with ownership-based access control
  Required Role : CHAUFFEUR
  Ownership Rule: The authenticated principal (JWT sub) must equal the
                  chauffeur assigned to the trip record identified by tripId.
                  No other role or chauffeur may start the trip on behalf of
                  the assigned chauffeur.
  OAuth2 Scope  : drop-trip:start

Rate Limiting
  Scope         : Per-chauffeur (keyed on JWT sub)
  Policy        : Excessive concurrent start attempts on the same tripId are
                  throttled to prevent race conditions. Specific thresholds are
                  governed by the API gateway configuration. Requests exceeding
                  the limit receive HTTP 429 Too Many Requests.

Concurrency Control
  A pessimistic or optimistic lock is acquired on the trip record (keyed on
  tripId) during the state transition window (steps 6 through 10 of the
  sequence) to serialise concurrent start requests and prevent double-start
  race conditions.

--------------------------------------------------------------------------------
SECTION 3: REQUEST SPECIFICATION
--------------------------------------------------------------------------------

3.1 Request Headers

  Header Name       Required   Description
  ----------------  ---------  -------------------------------------------------
  Authorization     Yes        Bearer JWT token. Format: "Bearer <token>"
  Content-Type      Yes        Must be "application/json"
  Accept            No         Recommended: "application/json"
  X-Request-ID      No         Caller-supplied idempotency / correlation UUID.
                               Logged to audit trail for traceability.
  X-Correlation-ID  No         Distributed tracing correlation identifier.

3.2 Path Parameters

  Parameter   Type     Required   Description
  ----------  -------  ---------  -----------------------------------------------
  tripId      string   Yes        Unique identifier of the drop trip to be started.
                                  Must be a non-empty string. Format: UUID v4.
                                  Validation: must match pattern
                                  ^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-4[0-9a-fA-F]{3}
                                  -[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$
                                  Reject with 400 if format is invalid.
                                  Reject with 404 if no matching trip record exists.

3.3 Query Parameters

  None defined for this endpoint.

3.4 Request Body Schema

  Content-Type: application/json
  Required: Yes

  Field                     Type     Required   Constraints / Validation
  ------------------------  -------  ---------  ----------------------------------
  vehicleRegistrationNumber string   Yes        The registration number of the
                                               vehicle being used for the trip.
                                               Must be a non-empty string.
                                               Min length: 2 characters.
                                               Max length: 20 characters.
                                               Format: alphanumeric, may include
                                               hyphens and spaces.
                                               Regex: ^[A-Za-z0-9 \-]{2,20}$
                                               Must match the registration number
                                               on the vehicle record linked to the
                                               trip (BR-3, BR-9).
                                               Scan-based submission preferred;
                                               manual entry permitted as fallback.

  submissionMethod          string   No         Indicates how the registration
                                               number was captured.
                                               Allowed values: SCAN, MANUAL
                                               Default: MANUAL if omitted.
                                               Used for audit trail enrichment.

  chauffeurLocation         object   No         Current GPS coordinates of the
                                               chauffeur at the time of trip start.
                                               Used to seed the Map API tracking
                                               session.

  chauffeurLocation.lat     number   No         Latitude in decimal degrees.
                                               Range: -90.0 to 90.0
                                               Format: up to 8 decimal places.

  chauffeurLocation.lng     number   No         Longitude in decimal degrees.
                                               Range: -180.0 to 180.0
                                               Format: up to 8 decimal places.

  Example Request Body:
    {
      "vehicleRegistrationNumber": "AB-1234-CD",
      "submissionMethod": "SCAN",
      "chauffeurLocation": {
        "lat": 25.204849,
        "lng": 55.270782
      }
    }

--------------------------------------------------------------------------------
SECTION 4: RESPONSE SPECIFICATION
--------------------------------------------------------------------------------

4.1 HTTP 200 OK - Trip Successfully Started

  Returned when the trip start is successfully committed.

  Response Body Schema:

  Field                       Type     Description
  --------------------------  -------  ------------------------------------------
  tripId                      string   UUID of the drop trip that was started.
  status                      string   New trip status. Value: "STARTED"
  actualStartTimestamp        string   ISO 8601 UTC timestamp at which the trip
                                       start was committed by the system.
                                       Format: yyyy-MM-ddTHH:mm:ss.SSSZ
  suggestedDropStartTime      string   System-calculated suggested drop start time
                                       persisted per SER-010-020-110.
                                       Format: yyyy-MM-ddTHH:mm:ss.SSSZ
  vehicleRegistrationNumber   string   The validated vehicle registration number
                                       recorded against the trip start event.
  chauffeurId                 string   UUID of the chauffeur who started the trip
                                       (derived from JWT sub).
  auditTrailEntryId           string   UUID of the immutable audit trail entry
                                       created for this start event.
  trackingSessionId           string   Identifier of the Map API real-time
                                       tracking session initiated. May be null if
                                       the tracking session initiation is still
                                       pending asynchronously.
  notificationDispatched      boolean  Indicates whether the asynchronous
                                       notification dispatch was triggered.
                                       true = dispatch triggered; does not
                                       guarantee delivery.
  message                     string   Human-readable confirmation message.

  Example 200 Response Body:
    {
      "tripId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
      "status": "STARTED",
      "actualStartTimestamp": "2025-07-15T08:30:00.000Z",
      "suggestedDropStartTime": "2025-07-15T08:25:00.000Z",
      "vehicleRegistrationNumber": "AB-1234-CD",
      "chauffeurId": "7cb91a23-1234-4abc-9def-000000000001",
      "auditTrailEntryId": "a1b2c3d4-0000-4000-8000-ffffffffffff",
      "trackingSessionId": "track-session-98765",
      "notificationDispatched": true,
      "message": "Drop trip started successfully."
    }

4.2 HTTP 400 Bad Request - Invalid Request Format

  Returned when the request is malformed, required fields are missing, or
  field-level format validations fail (e.g., invalid tripId UUID format,
  vehicleRegistrationNumber fails regex).

  Response Body Schema:

  Field      Type     Description
  ---------  -------  ----------------------------------------------------------
  errorCode  string   Machine-readable error code. Example: "INVALID_REQUEST"
  message    string   Human-readable description of the validation failure.
  details    array    List of field-level validation error objects.
  details[].field    string   The request field that failed validation.
  details[].issue    string   Description of the specific validation failure.
  timestamp  string   ISO 8601 UTC timestamp of the error.
  requestId  string   Echo of X-Request-ID if supplied; otherwise system-generated.

  Example 400 Response Body:
    {
      "errorCode": "INVALID_REQUEST",
      "message": "Request validation failed.",
      "details": [
        {
          "field": "vehicleRegistrationNumber",
          "issue": "Field is required and must not be blank."
        },
        {
          "field": "tripId",
          "issue": "Path parameter tripId must be a valid UUID v4."
        }
      ],
      "timestamp": "2025-07-15T08:29:00.000Z",
      "requestId": "req-abc-001"
    }

4.3 HTTP 401 Unauthorized - Authentication Failure

  Returned when the Bearer JWT is absent, expired, malformed, or fails
  signature verification.

  Response Body Schema:

  Field      Type     Description
  ---------  -------  ----------------------------------------------------------
  errorCode  string   "UNAUTHORIZED"
  message    string   Human-readable authentication failure description.
  timestamp  string   ISO 8601 UTC timestamp of the error.

  Example 401 Response Body:
    {
      "errorCode": "UNAUTHORIZED",
      "message": "Bearer token is missing, expired, or invalid.",
      "timestamp": "2025-07-15T08:29:00.000Z"
    }

4.4 HTTP 403 Forbidden - Authorization Failure

  Returned when the authenticated caller does not hold the CHAUFFEUR role, or
  when the authenticated chauffeur is not the chauffeur assigned to the
  specified trip (BR-2).

  Response Body Schema:

  Field      Type     Description
  ---------  -------  ----------------------------------------------------------
  errorCode  string   "FORBIDDEN"
  message    string   "Forbidden: only the assigned chauffeur may start this
                       drop trip."
  timestamp  string   ISO 8601 UTC timestamp of the error.
  requestId  string   Echo of X-Request-ID if supplied.

  Example 403 Response Body:
    {
      "errorCode": "FORBIDDEN",
      "message": "Forbidden: only the assigned chauffeur may start this drop trip.",
      "timestamp": "2025-07-15T08:29:00.000Z",
      "requestId": "req-abc-002"
    }

4.5 HTTP 404 Not Found - Trip Not Found

  Returned when the tripId path parameter does not correspond to any existing
  drop trip record in the system (BR-8).

  Response Body Schema:

  Field      Type     Description
  ---------  -------  ----------------------------------------------------------
  errorCode  string   "TRIP_NOT_FOUND"
  message    string   "Drop trip not found for the provided tripId."
  tripId     string   The tripId value that was not found.
  timestamp  string   ISO 8601 UTC timestamp of the error.
  requestId  string

ENDPOINT: POST /api/v1/drop-trips/{tripId}/complete

Source Requirement IDs: SER-010-020-121, SER-010-020-122

--------------------------------------------------------------------------------
SECTION 1: ENDPOINT OVERVIEW
--------------------------------------------------------------------------------

Path            : /api/v1/drop-trips/{tripId}/complete
HTTP Method     : POST
Summary         : Submit OTP and customer signature to finalise drop handover; validates OTP,
                  persists signature, marks Trip and Appointment as COMPLETED, and updates
                  linked JC.
Description     : This endpoint is invoked by an authenticated Chauffeur to formally complete
                  a drop trip. The Chauffeur submits the customer-provided OTP and the
                  captured customer signature as proof of drop acknowledgement. The system
                  verifies the OTP against the one dispatched to the customer, validates the
                  signature artifact, transitions the trip status to COMPLETED, closes the
                  parent appointment lifecycle, appends an immutable audit trail entry, and
                  triggers asynchronous downstream notifications and CRM/DBP updates.
                  This endpoint is exclusively applicable to trips of type DROP.

--------------------------------------------------------------------------------
SECTION 2: SECURITY REQUIREMENTS
--------------------------------------------------------------------------------

Authentication  : Bearer JWT (OAuth2 / OIDC). The Authorization header must carry a valid,
                  non-expired JWT issued by the platform identity provider.

Authorization   : Role-Based Access Control (RBAC) combined with ownership-based access
                  control. The authenticated principal must hold the CHAUFFEUR role AND must
                  be the chauffeur assigned to the specific drop trip identified by tripId.
                  A CHAUFFEUR who is authenticated but not assigned to the trip is rejected
                  with HTTP 403.

Required Role   : CHAUFFEUR

Required Scope  : drop-trip:complete

Rate Limiting   : 30 requests per minute per authenticated Chauffeur identity. Requests
                  exceeding this threshold are rejected with HTTP 429 Too Many Requests.
                  Rate limit counters are keyed on the chauffeurId extracted from the JWT.

Token Validation Steps:
  - Verify JWT signature against the platform JWKS endpoint.
  - Verify token expiry (exp claim).
  - Verify issuer (iss claim) matches the configured identity provider.
  - Extract chauffeurId and role claims for downstream authorization checks.

--------------------------------------------------------------------------------
SECTION 3: REQUEST SPECIFICATION
--------------------------------------------------------------------------------

3.1 Request Headers

Header Name       Required   Description
Authorization     Yes        Bearer <JWT token>. Must be a valid, non-expired JWT.
Content-Type      Yes        Must be application/json.
X-Request-ID      No         Client-generated UUID for request tracing and idempotency
                             correlation. Recommended for retry scenarios.
X-Correlation-ID  No         Correlation identifier for distributed tracing across services.
Accept            No         application/json (default assumed if absent).

3.2 Path Parameters

Parameter   Type     Required   Description
tripId      string   Yes        Unique identifier of the drop trip to be completed.
                                Must correspond to an existing drop trip record in the system.
                                Format: UUID v4 (xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx).
                                Validation: Must be a non-empty, valid UUID v4 string.
                                Error if absent or malformed: 400 Bad Request.

3.3 Query Parameters

None applicable for this endpoint.

3.4 Request Body Schema

Content-Type: application/json

The request body is mandatory. All fields listed as required must be present.

Field: otp
  Type          : string
  Required      : Yes
  Description   : The One-Time Password provided by the customer to the Chauffeur at the
                  drop location. This OTP was previously generated and dispatched to the
                  customer by the platform.
  Format        : Numeric string.
  Length        : Minimum 4 characters, maximum 8 characters.
  Pattern       : ^[0-9]{4,8}$
  Validation    : Must be non-null, non-empty, match the numeric pattern, and fall within
                  the configured length bounds. Must not be expired at time of verification.
  Business Rule : BR-3, BR-4

Field: customerSignature
  Type          : object
  Required      : Yes
  Description   : Encapsulates the customer signature artifact captured on the Chauffeur
                  mobile application at the drop location.
  Business Rule : BR-5

  Nested Field: customerSignature.artifactType
    Type        : string
    Required    : Yes
    Description : Describes the type/format of the signature artifact.
    Allowed     : BASE64_IMAGE, ARTIFACT_REFERENCE_ID
    Validation  : Must be one of the enumerated values.

  Nested Field: customerSignature.artifactValue
    Type        : string
    Required    : Yes
    Description : The actual signature artifact. If artifactType is BASE64_IMAGE, this
                  contains the Base64-encoded image string of the signature. If artifactType
                  is ARTIFACT_REFERENCE_ID, this contains the pre-uploaded artifact
                  reference identifier.
    Format      : Non-empty string.
    Max Length  : 2,097,152 characters (approximately 2 MB Base64 payload limit).
    Validation  : Must be non-null and non-empty. If BASE64_IMAGE, must be a valid Base64
                  string. If ARTIFACT_REFERENCE_ID, must be a valid UUID v4 reference.

  Nested Field: customerSignature.capturedAt
    Type        : string
    Required    : Yes
    Description : ISO 8601 UTC timestamp indicating when the customer signature was captured
                  on the mobile device.
    Format      : date-time (ISO 8601, e.g. 2025-07-15T10:30:00Z)
    Validation  : Must be a valid ISO 8601 datetime. Must not be a future timestamp.
                  Must not be older than the trip start time.

Field: completionNotes
  Type          : string
  Required      : No
  Description   : Optional free-text notes from the Chauffeur regarding the drop completion
                  (e.g. special circumstances at the drop location).
  Max Length    : 1000 characters.
  Validation    : If present, must not exceed 1000 characters.

3.5 Example Request

POST /api/v1/drop-trips/f47ac10b-58cc-4372-a567-0e02b2c3d479/complete
Authorization: Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9...
Content-Type: application/json
X-Request-ID: 3fa85f64-5717-4562-b3fc-2c963f66afa6

{
  "otp": "482917",
  "customerSignature": {
    "artifactType": "BASE64_IMAGE",
    "artifactValue": "iVBORw0KGgoAAAANSUhEUgAA...",
    "capturedAt": "2025-07-15T10:29:45Z"
  },
  "completionNotes": "Customer received at lobby entrance. No issues."
}

--------------------------------------------------------------------------------
SECTION 4: RESPONSE SPECIFICATION
--------------------------------------------------------------------------------

4.1 HTTP 200 OK - Successful Trip Completion

Description: The drop trip has been successfully completed. OTP verified, signature
             persisted, trip status transitioned to COMPLETED, appointment lifecycle closed,
             audit trail appended, and downstream notifications queued.

Response Body Schema:

Field: status
  Type        : string
  Description : Outcome status of the operation.
  Value       : SUCCESS

Field: tripId
  Type        : string
  Description : The unique identifier of the completed drop trip.
  Format      : UUID v4

Field: tripStatus
  Type        : string
  Description : The new status of the drop trip post-completion.
  Value       : COMPLETED

Field: completedAt
  Type        : string
  Description : ISO 8601 UTC timestamp at which the trip was marked COMPLETED in the system.
  Format      : date-time

Field: appointmentId
  Type        : string
  Description : The unique identifier of the parent appointment whose lifecycle has been
                closed as a result of this trip completion.
  Format      : UUID v4

Field: appointmentStatus
  Type        : string
  Description : The updated status of the parent appointment.
  Value       : COMPLETED

Field: signatureArtifactReference
  Type        : string
  Description : The system-assigned reference identifier for the persisted customer
                signature artifact.
  Format      : UUID v4

Field: otpVerificationStatus
  Type        : string
  Description : Outcome of the OTP verification step.
  Value       : VERIFIED

Field: auditTrailEntryId
  Type        : string
  Description : The identifier of the immutable audit trail entry appended for this
                completion event.
  Format      : UUID v4

Field: message
  Type        : string
  Description : Human-readable confirmation message.

Example 200 Response:

{
  "status": "SUCCESS",
  "tripId": "f47ac10b-58cc-4372-a567-0e02b2c3d479",
  "tripStatus": "COMPLETED",
  "completedAt": "2025-07-15T10:30:02Z",
  "appointmentId": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
  "appointmentStatus": "COMPLETED",
  "signatureArtifactReference": "9c8b7a65-4321-4fed-cba9-876543210fed",
  "otpVerificationStatus": "VERIFIED",
  "auditTrailEntryId": "1d2e3f4a-5b6c-7d8e-9f0a-1b2c3d4e5f6a",
  "message": "Drop trip completed successfully. Customer has been notified."
}

--------------------------------------------------------------------------------

4.2 HTTP 400 Bad Request - Malformed Request

Description: The request is syntactically invalid. This includes malformed JSON body,
             invalid UUID format for tripId, missing mandatory headers, or field-level
             type/format violations.

Response Body Schema:

Field: status       : string - Value: ERROR
Field: errorCode    : string - Platform error code.
Field: message      : string - Human-readable description of the validation failure.
Field: details      : array  - List of individual field-level validation errors.
  details[].field   : string - The field that failed validation.
  details[].issue   : string - Description of the specific validation failure.

Example 400 Response:

{
  "status": "ERROR",
  "errorCode": "INVALID_REQUEST",
  "message": "Request validation failed. One or more fields are invalid.",
  "details": [
    {
      "field": "tripId",
      "issue": "tripId must be a valid UUID v4 format."
    },
    {
      "field": "otp",
      "issue": "otp must be a numeric string between 4 and 8 digits."
    }
  ]
}

--------------------------------------------------------------------------------

4.3 HTTP 401 Unauthorized - Authentication Failure

Description: The request does not carry a valid Bearer JWT token, the token is expired,
             or the token signature cannot be verified.

Example 401 Response:

{
  "status": "ERROR",
  "errorCode": "UNAUTHORIZED",
  "message": "Authentication failed. A valid Bearer JWT token is required."
}

--------------------------------------------------------------------------------

4.4 HTTP 403 Forbidden - Authorization Failure

Description: The authenticated principal does not hold the CHAUFFEUR role, or the
             authenticated Chauffeur is not the assigned chauffeur for the specified
             drop trip (ownership check failure). Corresponds to BR-6.

Example 403 Response:

{
  "status": "ERROR",
  "errorCode": "FORBIDDEN",
  "message": "Forbidden. You are not the assigned chauffeur for this drop trip."
}

--------------------------------------------------------------------------------

4.5 HTTP 404 Not Found - Trip Not Found

Description: No drop trip record exists for the provided tripId. Corresponds to BR-1.

Example 404 Response:

{
  "status": "ERROR",
  "errorCode": "TRIP_NOT_FOUND",
  "message": "Drop trip not found for the provided tripId."
}

--------------------------------------------------------------------------------

4.6 HTTP 409 Conflict - Trip Already in Terminal State or Concurrent Request

Description: Returned in two scenarios:
             (a) The trip is already in a terminal state (COMPLETED, CANCELLED, FAILED)
                 and cannot be completed again. Corresponds to BR-2 and idempotency handling.
             (b) A distributed lock could not be acquired because a concurrent completion
                 request for the same tripId is already in progress.

Example 409 Response - Terminal State:

{
  "status": "ERROR",
  "errorCode": "TRIP_ALREADY_FINALISED",
  "message": "Drop trip is already in a terminal state and cannot be completed again."
}

Example 409 Response - Concurrent Lock Conflict:

{
  "status": "ERROR",
  "errorCode": "CONCURRENT_COMPLETION_CONFLICT",
  "message": "A completion request for this trip is already being processed. Please retry after a short delay."
}

--------------------------------------------------------------------------------

4.7 HTTP 422 Unprocessable Entity - Business Validation Failure

Description: The request is syntact

ENDPOINT DESIGN DOCUMENT
=========================

Endpoint: PUT /api/v1/crm/assignments/{assignmentId}/status
Source Requirements: SER-010-020-010, SER-010-020-012


------------------------------------------------------------------------
SECTION 1: ENDPOINT IDENTIFICATION
------------------------------------------------------------------------

Path            : /api/v1/crm/assignments/{assignmentId}/status
HTTP Method     : PUT
Summary         : Update assignment status in CRM on chauffeur acceptance, rejection, or timeout
Description     : This endpoint allows an authorised Pickup Coordinator, Admin, or Integration
                  Service caller to update the status of an existing CRM assignment record to
                  reflect a chauffeur's response (ACCEPTED, REJECTED, or TIMEOUT). On acceptance,
                  the downstream appointment booking orchestration workflow is advanced to step
                  SER-010-020-011. On rejection or timeout, the Pickup Coordinator is notified
                  via the configured notification channel to initiate reassignment or escalation.
                  All status transitions are recorded in an immutable audit trail.


------------------------------------------------------------------------
SECTION 2: REQUEST SPECIFICATION
------------------------------------------------------------------------

2.1 Request Headers
-------------------

Header Name       : Authorization
Required          : Yes
Format            : Bearer <JWT token>
Description       : OAuth2/OIDC Bearer token. Must be a valid, non-expired JWT signed by the
                    trusted issuer. The token must carry the scope crm:assignment:write and a
                    role claim containing at least one of PICKUP_COORDINATOR, ADMIN, or
                    INTEGRATION_SERVICE.

Header Name       : Content-Type
Required          : Yes
Expected Value    : application/json
Description       : Request body must be JSON-encoded.

Header Name       : Accept
Required          : No (recommended)
Expected Value    : application/json
Description       : Indicates the client expects a JSON response.

Header Name       : X-Correlation-ID
Required          : No (recommended)
Format            : UUID v4 string
Description       : Caller-supplied correlation identifier for distributed tracing. If absent,
                    the system generates one internally and includes it in the response.

Header Name       : X-Request-ID
Required          : No
Format            : UUID v4 string
Description       : Idempotency hint. Used in conjunction with duplicate detection logic.


2.2 Path Parameters
-------------------

Parameter Name    : assignmentId
Location          : Path
Required          : Yes
Type              : String
Format            : Non-empty string; expected to conform to the CRM assignment identifier
                    format (alphanumeric, hyphens permitted, maximum 64 characters)
Validation Rules  :
  - Must be present and non-blank.
  - Must not exceed 64 characters.
  - Must match pattern: ^[a-zA-Z0-9\-]{1,64}$
  - Must resolve to an existing assignment record in the CRM data store.
Error if invalid  : 400 Bad Request with message "assignmentId is malformed or missing."
Error if not found: 404 Not Found with message "Assignment not found for the provided assignmentId."


2.3 Query Parameters
--------------------

None defined for this endpoint.


2.4 Request Body Schema
-----------------------

Content-Type: application/json

The request body is a JSON object with the following fields:

Field Name        : status
Type              : String (enumeration)
Required          : Yes
Permitted Values  : ACCEPTED, REJECTED, TIMEOUT
Description       : The new status to apply to the CRM assignment record.
Validation Rules  :
  - Must be present and non-null.
  - Must be one of the three permitted enumeration values exactly (case-sensitive).
  - Any other value results in a 422 Unprocessable Entity error.

Field Name        : chauffeurId
Type              : String
Required          : Yes
Format            : Non-empty string, maximum 64 characters, pattern ^[a-zA-Z0-9\-]{1,64}$
Description       : Identifier of the chauffeur whose response is being recorded.
Validation Rules  :
  - Must be present and non-blank for all status values.
  - Must not exceed 64 characters.

Field Name        : rejectionReason
Type              : String
Required          : Conditionally required when status is REJECTED
Format            : Non-empty string, maximum 500 characters
Description       : Human-readable reason provided by the chauffeur or coordinator for
                    rejecting the assignment.
Validation Rules  :
  - Must be present and non-blank when status is REJECTED (BR-5).
  - Must be absent or null when status is ACCEPTED or TIMEOUT.
  - Maximum length: 500 characters.
  - If status is REJECTED and this field is absent or blank, return 400 Bad Request.

Field Name        : timeoutFlag
Type              : Boolean
Required          : Conditionally required when status is TIMEOUT
Description       : Explicit flag indicating that the assignment response timed out.
Validation Rules  :
  - Must be true when status is TIMEOUT (BR-6).
  - Must be false or absent when status is ACCEPTED or REJECTED.
  - If status is TIMEOUT and timeoutFlag is absent or false, return 422.
  - If timeoutFlag is true and status is not TIMEOUT, return 422.

Example Request Body (ACCEPTED):

  {
    "status": "ACCEPTED",
    "chauffeurId": "CHF-00123"
  }

Example Request Body (REJECTED):

  {
    "status": "REJECTED",
    "chauffeurId": "CHF-00123",
    "rejectionReason": "Chauffeur unavailable due to prior commitment."
  }

Example Request Body (TIMEOUT):

  {
    "status": "TIMEOUT",
    "chauffeurId": "CHF-00123",
    "timeoutFlag": true
  }


------------------------------------------------------------------------
SECTION 3: RESPONSE SPECIFICATION
------------------------------------------------------------------------

3.1 HTTP 200 OK — Successful Status Update
------------------------------------------

Returned when the assignment status has been successfully updated (including the idempotent
case where the assignment is already in the requested status).

Response Body Schema:

Field Name        : assignmentId
Type              : String
Description       : The identifier of the updated assignment record.

Field Name        : status
Type              : String
Description       : The current (newly applied) status of the assignment.

Field Name        : chauffeurId
Type              : String
Description       : The chauffeur identifier recorded against the assignment.

Field Name        : statusUpdatedAt
Type              : String (ISO 8601 UTC datetime)
Description       : The UTC timestamp at which the status was recorded.

Field Name        : rejectionReason
Type              : String or null
Description       : The rejection reason if status is REJECTED; null otherwise.

Field Name        : timeoutFlag
Type              : Boolean or null
Description       : True if status is TIMEOUT; null or false otherwise.

Field Name        : auditEntryId
Type              : String
Description       : Identifier of the audit trail entry created for this update.

Field Name        : correlationId
Type              : String
Description       : The correlation identifier for this request, for tracing purposes.

Example Response (ACCEPTED):

  {
    "assignmentId": "ASGN-20240501-0042",
    "status": "ACCEPTED",
    "chauffeurId": "CHF-00123",
    "statusUpdatedAt": "2024-05-01T09:15:30Z",
    "rejectionReason": null,
    "timeoutFlag": null,
    "auditEntryId": "AUD-00987654",
    "correlationId": "c3d4e5f6-1234-5678-abcd-ef0123456789"
  }

Example Response (REJECTED):

  {
    "assignmentId": "ASGN-20240501-0042",
    "status": "REJECTED",
    "chauffeurId": "CHF-00123",
    "statusUpdatedAt": "2024-05-01T09:20:10Z",
    "rejectionReason": "Chauffeur unavailable due to prior commitment.",
    "timeoutFlag": null,
    "auditEntryId": "AUD-00987655",
    "correlationId": "d4e5f6a7-2345-6789-bcde-f01234567890"
  }

Example Response (TIMEOUT):

  {
    "assignmentId": "ASGN-20240501-0042",
    "status": "TIMEOUT",
    "chauffeurId": "CHF-00123",
    "statusUpdatedAt": "2024-05-01T09:25:00Z",
    "rejectionReason": null,
    "timeoutFlag": true,
    "auditEntryId": "AUD-00987656",
    "correlationId": "e5f6a7b8-3456-789a-cdef-012345678901"
  }


3.2 HTTP 400 Bad Request — Client Validation Error
---------------------------------------------------

Returned when the request payload fails field-level validation that is not an enumeration
mismatch (e.g. rejectionReason missing for REJECTED status, malformed assignmentId).

Response Body Schema:

Field Name        : errorCode
Type              : String
Description       : Machine-readable error code.

Field Name        : errorMessage
Type              : String
Description       : Human-readable description of the validation failure.

Field Name        : fieldErrors
Type              : Array of objects
Description       : List of individual field-level validation failures.

  fieldErrors[].field
    Type          : String
    Description   : The name of the field that failed validation.

  fieldErrors[].message
    Type          : String
    Description   : Specific validation message for that field.

Example Response:

  {
    "errorCode": "VALIDATION_ERROR",
    "errorMessage": "Request validation failed.",
    "fieldErrors": [
      {
        "field": "rejectionReason",
        "message": "rejectionReason is required when status is REJECTED."
      }
    ]
  }


3.3 HTTP 401 Unauthorized — Authentication Failure
---------------------------------------------------

Returned when the Bearer JWT is absent, expired, malformed, or fails signature validation.

Example Response:

  {
    "errorCode": "UNAUTHORIZED",
    "errorMessage": "Authentication failed. A valid Bearer token is required."
  }


3.4 HTTP 403 Forbidden — Authorisation Failure
-----------------------------------------------

Returned when the caller is authenticated but does not hold a permitted role
(PICKUP_COORDINATOR, ADMIN, or INTEGRATION_SERVICE) or lacks the required scope
(crm:assignment:write).

Example Response:

  {
    "errorCode": "FORBIDDEN",
    "errorMessage": "Caller does not have the required role to update assignment status."
  }


3.5 HTTP 404 Not Found — Assignment Not Found
---------------------------------------------

Returned when the assignmentId path parameter does not resolve to an existing CRM
assignment record.

Example Response:

  {
    "errorCode": "ASSIGNMENT_NOT_FOUND",
    "errorMessage": "Assignment not found for the provided assignmentId.",
    "assignmentId": "ASGN-99999999"
  }


3.6 HTTP 409 Conflict — Terminal State Conflict
------------------------------------------------

Returned when the assignment is already in a terminal state (COMPLETED or CANCELLED)
and cannot be updated.

Example Response:

  {
    "errorCode": "ASSIGNMENT_TERMINAL_STATE",
    "errorMessage": "Assignment is already in a terminal state and cannot be updated.",
    "assignmentId": "ASGN-20240501-0042",
    "currentStatus": "COMPLETED"
  }


3.7 HTTP 422 Unprocessable Entity — Business Rule Validation Failure
---------------------------------------------------------------------

Returned when the request is syntactically valid but violates a business rule, such as
an invalid status enumeration value or an inconsistent timeoutFlag.

Example Response (invalid status):

  {
    "errorCode": "INVALID_STATUS_VALUE",
    "errorMessage": "Invalid status value. Permitted values are ACCEPTED, REJECTED, TIMEOUT.",
    "fieldErrors": [
      {
        "field": "status",
        "message": "Value 'PENDING' is not a permitted status transition."
      }
    ]
  }

Example Response (timeoutFlag mismatch):

  {
    "errorCode": "TIMEOUT_FLAG_MISMATCH",
    "errorMessage": "timeoutFlag must be true if and only if status is TIMEOUT.",
    "fieldErrors": [
      {
        "field": "timeoutFlag",
        "message": "timeoutFlag is true but status is ACCEPTED. These values are inconsistent."
      }
    ]
  }


3.8 HTTP 429 Too Many Requests — Rate Limit Exceeded
-----------------------------------------------------

Returned when the caller exceeds the configured rate limit.

Response Headers:
  Retry-After: <seconds

ENDPOINT DETAILED DESIGN
=========================

Source Requirement ID : SER-010-020-093
Endpoint Path         : /api/v1/crm/drop-requests/{appointmentNumber}
HTTP Method           : GET
Summary               : Fetch drop-service selection and drop details from CRM service appointment after dealership delivery
Description           : Retrieves the drop request details associated with a CRM service appointment. The operation fetches the service appointment record from the upstream CRM system, validates that a drop-service selection is present, and returns the full drop request payload to the caller. The primary consumers are the Pickup Coordinator dashboard and the DBP Pickup and Drop Scheduling Dashboard. This is a read-only operation; no state mutation occurs in any system.


---------------------------------------------------------------------------
SECTION 1 : REQUEST SPECIFICATION
---------------------------------------------------------------------------

1.1 HTTP Method and Path
    Method : GET
    Path   : /api/v1/crm/drop-requests/{appointmentNumber}

1.2 Request Headers

    Header Name      : Authorization
    Required         : Yes
    Format           : Bearer <JWT token>
    Description      : OAuth2 / OIDC Bearer JWT. Must be signed, non-expired, and issued by the authorised identity provider. Must carry one of the permitted roles: PICKUP_COORDINATOR, INTEGRATION_SERVICE, or ADMIN.

    Header Name      : Accept
    Required         : No (recommended)
    Format           : application/json
    Description      : Indicates the caller expects a JSON response. Defaults to application/json if omitted.

    Header Name      : X-Correlation-ID
    Required         : No (recommended)
    Format           : UUID v4 string
    Description      : Caller-supplied correlation identifier for distributed tracing and audit log correlation. If not supplied, the system generates one internally.

    Header Name      : X-Request-ID
    Required         : No
    Format           : UUID v4 string
    Description      : Caller-supplied unique request identifier for idempotency tracking and log correlation.

1.3 Path Parameters

    Parameter Name   : appointmentNumber
    Location         : Path
    Type             : String
    Required         : Yes
    Description      : The unique CRM service appointment identifier for which drop request details are to be retrieved.
    Validation Rules :
        - Must be non-null and non-empty.
        - Must conform to the CRM appointment numbering convention.
        - Recommended regex pattern: ^[A-Z]{2,4}-[0-9]{6,12}$ (exact pattern to be confirmed against CRM appointment number format specification; the system must reject any value that does not match the agreed pattern).
        - Maximum length: 20 characters.
        - Minimum length: 8 characters.
        - No whitespace, special characters outside the defined pattern, or URL-encoded spaces are permitted.
    Business Rule    : BR-5

1.4 Query Parameters
    None defined for this endpoint.

1.5 Request Body
    Not applicable. This is a GET operation; no request body is accepted.


---------------------------------------------------------------------------
SECTION 2 : RESPONSE SPECIFICATION
---------------------------------------------------------------------------

2.1 HTTP 200 OK — Successful Retrieval

    Description : The drop request record was successfully retrieved from CRM. All mandatory fields are present and populated.

    Response Body Schema:

    Field                    Type       Required   Description
    appointmentNumber        String     Yes        CRM service appointment number. Matches the path parameter supplied in the request.
    dropServiceSelected      Boolean    Yes        Flag indicating that drop-service has been explicitly selected on this appointment. Will always be true in a 200 response (appointments without drop-service selected return 404).
    customerName             String     Yes        Full name of the customer associated with the service appointment.
    customerContact          String     Yes        Customer contact number or email address as recorded in CRM.
    vehicleRegistrationNumber String    Yes        Vehicle registration number associated with the service appointment.
    dropAddress              String     Yes        The address to which the vehicle is to be dropped after service.
    requestedDropDateTime    String     Yes        ISO 8601 date-time string representing the customer-requested drop date and time. Format: YYYY-MM-DDTHH:mm:ssZ.
    linkedJCNumber           String     Yes        The Job Card (JC) number linked to this service appointment in CRM.

    Example 200 Response Payload:

    {
      "appointmentNumber": "SA-20240815001",
      "dropServiceSelected": true,
      "customerName": "Rajesh Kumar",
      "customerContact": "+919876543210",
      "vehicleRegistrationNumber": "MH12AB1234",
      "dropAddress": "42, Shivaji Nagar, Pune, Maharashtra 411005",
      "requestedDropDateTime": "2024-08-16T10:30:00+05:30",
      "linkedJCNumber": "JC-2024-00456"
    }

2.2 HTTP 400 Bad Request — Invalid or Missing Appointment Number

    Description : The appointmentNumber path parameter is null, empty, or does not conform to the expected CRM appointment number format. No downstream CRM call is made.
    Business Rule : BR-5

    Response Body Schema:

    Field     Type     Description
    errorCode String   Machine-readable error code.
    message   String   Human-readable error description.
    details   String   Additional context about the validation failure.

    Example 400 Response Payload:

    {
      "errorCode": "INVALID_APPOINTMENT_NUMBER",
      "message": "Invalid or missing appointment number.",
      "details": "The appointmentNumber path parameter must be a non-empty, well-formed service appointment identifier conforming to the CRM appointment numbering convention."
    }

2.3 HTTP 401 Unauthorized — Authentication or Authorisation Failure

    Description : The request does not carry a valid Bearer JWT, the JWT is expired or has an invalid signature, or the JWT does not contain a permitted role.
    Business Rule : BR-8

    Example 401 Response Payload:

    {
      "errorCode": "UNAUTHORIZED",
      "message": "Unauthorised. Valid Bearer JWT with required role is mandatory.",
      "details": "The caller must present a valid Bearer JWT issued by the authorised identity provider and must hold one of the following roles: PICKUP_COORDINATOR, INTEGRATION_SERVICE, ADMIN."
    }

2.4 HTTP 403 Forbidden — Insufficient Permissions

    Description : The caller is authenticated but does not hold a role that permits access to drop request data, or dealership-scoping rules prevent access to the requested appointment.

    Example 403 Response Payload:

    {
      "errorCode": "FORBIDDEN",
      "message": "Access denied. You do not have permission to access this drop request.",
      "details": "The authenticated caller does not hold a permitted role or the requested appointment belongs to a dealership outside the caller's authorised scope."
    }

2.5 HTTP 404 Not Found — Appointment Not Found or No Drop-Service Selection

    Description : Either no CRM service appointment exists for the supplied appointmentNumber, or the appointment exists but does not have drop-service explicitly selected.
    Business Rules : BR-1, BR-6

    Example 404 Response Payload (appointment not found):

    {
      "errorCode": "DROP_REQUEST_NOT_FOUND",
      "message": "No drop request found for the specified appointment number.",
      "details": "No CRM service appointment record exists for appointmentNumber SA-20240815999."
    }

    Example 404 Response Payload (drop-service not selected):

    {
      "errorCode": "DROP_SERVICE_NOT_SELECTED",
      "message": "No drop-service selection found for the specified appointment number.",
      "details": "The CRM service appointment SA-20240815001 exists but does not have drop-service explicitly selected. Only appointments with an active drop-service selection yield a valid drop request."
    }

2.6 HTTP 500 Internal Server Error — Unexpected Application Error

    Description : An unhandled exception or unexpected internal error occurred within the API service layer.

    Example 500 Response Payload:

    {
      "errorCode": "INTERNAL_SERVER_ERROR",
      "message": "An unexpected error occurred. Please contact support if the problem persists.",
      "details": "Correlation ID: 3f7a1c2d-8e4b-4f9a-b2c1-1a2b3c4d5e6f"
    }

2.7 HTTP 502 Bad Gateway — CRM Integration Failure or Incomplete Data

    Description : The CRM system is unreachable, returned a timeout, returned a 4xx or 5xx error, or returned a response in which one or more mandatory fields are missing.
    Business Rules : BR-3, BR-7

    Example 502 Response Payload (CRM unreachable):

    {
      "errorCode": "CRM_INTEGRATION_FAILURE",
      "message": "Unable to retrieve drop request from CRM. Please try again later.",
      "details": "CRM service did not respond after 2 retry attempts. The failure has been logged for operational monitoring."
    }

    Example 502 Response Payload (incomplete CRM data):

    {
      "errorCode": "CRM_DATA_INTEGRITY_ERROR",
      "message": "Incomplete drop request data received from CRM. One or more mandatory fields are missing.",
      "details": "The CRM response for appointmentNumber SA-20240815001 is missing the following mandatory fields: linkedJCNumber, dropAddress."
    }


---------------------------------------------------------------------------
SECTION 3 : BUSINESS RULES
---------------------------------------------------------------------------

Rule ID  : BR-1
Category : Pre-condition
Trigger  : A GET request is received for a given appointmentNumber.
Description : The appointment number supplied in the path must correspond to an existing service appointment record in CRM that has a drop-service selection associated with it.
Expected Behaviour : System validates that the CRM service appointment exists and carries a drop-service selection before returning any data.
Error Code : 404
Error Message : No drop request found for the specified appointment number.

Rule ID  : BR-2
Category : Business
Trigger  : Endpoint is invoked for any valid appointmentNumber.
Description : Drop request details must be fetched from the upstream C

ENDPOINT DESIGN: GET /api/v1/appointments/{appointmentId}

Source Requirement: SER-010-020-003


------------------------------------------------------------------------
SECTION 1: ENDPOINT IDENTIFICATION
------------------------------------------------------------------------

Path            : /api/v1/appointments/{appointmentId}
HTTP Method     : GET
Summary         : Retrieve full appointment detail including allocation
                  status, ETA, exception flag, linked JC, and assignment
                  history
Description     : Returns the complete appointment detail record for a
                  given appointmentId. The response includes all mandatory
                  fields required by the Pickup Coordinator dashboard,
                  including vehicle and customer information, pickup and
                  drop details, current chauffeur allocation status, real-
                  time ETA sourced from the Map API integration layer,
                  exception flag, and linked Job Card reference where
                  applicable. Customer contact reference is masked before
                  transmission. This is a read-only operation and causes
                  no state mutation in the appointment domain.


------------------------------------------------------------------------
SECTION 2: REQUEST SPECIFICATION
------------------------------------------------------------------------

2.1 Request Headers

Header Name       : Authorization
Required          : Yes
Format            : Bearer <JWT token>
Description       : OAuth2/OIDC Bearer token issued by the authorised
                    identity provider. Must be a valid, non-expired JWT
                    with correct signature and issuer claim.

Header Name       : Accept
Required          : No (defaults to application/json)
Format            : application/json
Description       : Specifies the expected response media type.

Header Name       : X-Correlation-ID
Required          : No (recommended)
Format            : UUID v4 string
Description       : Caller-supplied correlation identifier for distributed
                    tracing and log correlation. If not supplied, the
                    system generates one internally.

Header Name       : X-Request-ID
Required          : No
Format            : UUID v4 string
Description       : Caller-supplied unique request identifier for
                    idempotency tracking and support diagnostics.


2.2 Path Parameters

Parameter Name    : appointmentId
Location          : Path
Required          : Yes
Type              : String
Format            : Non-empty alphanumeric identifier. Must not contain
                    whitespace or special characters beyond hyphens and
                    underscores.
Min Length        : 1
Max Length        : 64
Validation Rules  :
  - Must be non-null and non-empty.
  - Must match pattern: ^[a-zA-Z0-9_-]{1,64}$
  - Must correspond to an existing appointment record in the data store.
Error if invalid  : 400 Bad Request with error code INVALID_PATH_PARAM.
Error if not found: 404 Not Found with error code APPOINTMENT_NOT_FOUND.


2.3 Query Parameters

None defined for this endpoint.


2.4 Request Body

Not applicable. This is a GET operation and carries no request body.


------------------------------------------------------------------------
SECTION 3: RESPONSE SPECIFICATION
------------------------------------------------------------------------

3.1 HTTP 200 OK - Successful Retrieval

Description: The appointment record was found, the caller is authorised,
all downstream data was assembled, and the full appointment detail is
returned.

Response Body Fields:

Field Name                  Type        Required   Description
appointmentId               String      Yes        Unique identifier of
                                                   the appointment.
appointmentNumber           String      Yes        Human-readable
                                                   appointment reference
                                                   number.
customerName                String      Yes        Full name of the
                                                   customer associated
                                                   with the appointment.
maskedContactReference      String      Yes        Customer contact
                                                   reference with PII
                                                   masking applied (e.g.
                                                   phone number partially
                                                   obscured).
vehicleRegistration         String      Yes        Registration plate of
                                                   the vehicle.
vehicleModel                String      Yes        Model description of
                                                   the vehicle.
pickupDateTime              String      Yes        ISO 8601 datetime of
                                                   the scheduled pickup.
                                                   Format:
                                                   yyyy-MM-ddTHH:mm:ssZ
pickupAddress               String      Conditional Full pickup address.
                                                   Present when a
                                                   specific address is
                                                   defined.
permittedPickupArea         String      Conditional Permitted pickup zone
                                                   or area. Present when
                                                   no specific address is
                                                   defined.
dropServiceSelected         Boolean     Yes        Indicates whether a
                                                   drop service was
                                                   requested for this
                                                   appointment.
dropAddress                 String      Conditional Drop-off address.
                                                   Present only when
                                                   dropServiceSelected is
                                                   true.
dropDateTime                String      Conditional ISO 8601 datetime of
                                                   the scheduled drop.
                                                   Present only when
                                                   dropServiceSelected is
                                                   true.
appointmentStatus           String      Yes        Current lifecycle
                                                   status of the
                                                   appointment. Permitted
                                                   values: Scheduled,
                                                   Chauffeur En Route,
                                                   Vehicle Picked Up,
                                                   Drop Scheduled,
                                                   Completed, Cancelled.
allocationStatus            String      Yes        Current chauffeur
                                                   allocation state.
                                                   Permitted values:
                                                   Unallocated,
                                                   Recommended,
                                                   Allocated, Reassigned.
chauffeurName               String      Conditional Name of the assigned
                                                   chauffeur. Null or
                                                   absent when no
                                                   chauffeur is assigned.
requestResponseStatus       String      Yes        Status of the
                                                   chauffeur request-
                                                   response cycle.
requestResponseTime         String      Conditional ISO 8601 datetime
                                                   when the chauffeur
                                                   responded. Null or
                                                   absent when not yet
                                                   responded.
currentEta                  String      Conditional ISO 8601 datetime
                                                   representing the
                                                   current estimated
                                                   arrival time. Sourced
                                                   from Map API. Null
                                                   when no active trip.
etaStaleness                Object      Conditional Present when the ETA
                                                   value is sourced from
                                                   cache due to Map API
                                                   unavailability.
etaStaleness.isStale        Boolean     Conditional True when ETA is from
                                                   cache, false or absent
                                                   when live.
etaStaleness.cachedAt       String      Conditional ISO 8601 datetime
                                                   when the cached ETA
                                                   was last recorded.
exceptionFlag               Boolean     Yes        True if any active
                                                   exception condition
                                                   exists against this
                                                   appointment (e.g.
                                                   no-show, delay,
                                                   vehicle unavailable).
linkedJcReference           String      Conditional Linked Job Card
                                                   reference number.
                                                   Null or absent when no
                                                   JC is linked.
promisedDeliveryTime        String      Conditional ISO 8601 datetime of
                                                   the promised delivery
                                                   time associated with
                                                   the linked JC. Null or
                                                   absent when no JC is
                                                   linked.

Example 200 Response Payload:

  appointmentId             : APT-20240801-00123
  appointmentNumber         : APPT-2024-00123
  customerName              : John Doe
  maskedContactReference    : +44 7*** ***789
  vehicleRegistration       : AB12 CDE
  vehicleModel              : BMW 5 Series
  pickupDateTime            : 2024-08-01T09:00:00Z
  pickupAddress             : 12 High Street, London, EC1A 1BB
  permittedPickupArea       : null
  dropServiceSelected       : true
  dropAddress               : 45 Park Lane, London, W1K 1PN
  dropDateTime              : 2024-08-01T11:00:00Z
  appointmentStatus         : Chauffeur En Route
  allocationStatus          : Allocated
  chauffeurName             : James Carter
  requestResponseStatus     : Accepted
  requestResponseTime       : 2024-08-01T08:30:00Z
  currentEta                : 2024-08-01T08:55:00Z
  etaStaleness              :
    isStale                 : false
    cachedAt                : null
  exceptionFlag             : false
  linkedJcReference         : JC-2024-00456
  promisedDeliveryTime      : 2024-08-01T12:00:00Z


3.2 HTTP 400 Bad Request

Description: The request is syntactically invalid. The appointmentId
path parameter fails format validation.

Response Body Fields:

Field Name    Type     Description
status        Integer  HTTP status code. Value: 400
errorCode     String   Machine-readable error code.
message       String   Human-readable error description.
field         String   The field that failed validation.
timestamp     String   ISO 8601 datetime of the error.
correlationId String   Correlation ID for tracing.

Example 400 Response Payload:

  status        : 400
  errorCode     : INVALID_PATH_PARAM
  message       : The appointmentId path parameter is invalid. It must
                  be a non-empty alphanumeric string of 1 to 64
                  characters.
  field         : appointmentId
  timestamp     : 2024-08-01T08:00:00Z
  correlationId : 3f6a1b2c-4d5e-6789-abcd-ef0123456789


3.3 HTTP 401 Unauthorized

Description: The caller did not supply a valid Bearer JWT token, the
token has expired, the signature is invalid, or the issuer is not
recognised.

Response Body Fields:

Field Name    Type     Description
status        Integer  HTTP status code. Value: 401
errorCode     String   Machine-readable error code.
message       String   Human-readable error description.
timestamp     String   ISO 8601 datetime of the error.
correlationId String   Correlation ID for tracing.

Example 401 Response Payload:

  status        : 401
  errorCode     : UNAUTHORIZED
  message       : Authentication failed. A valid Bearer token is
                  required to access this resource.
  timestamp     : 2024-08-01T08:00:00Z
  correlationId : 3f6a1b2c-4d5e-6789-abcd-ef0123456789


3.4 HTTP 403 Forbidden

Description: The caller is authenticated but is not authorised to access
the requested appointment. This occurs when a PICKUP_COORDINATOR role
attempts to retrieve an appointment outside their assigned
dealership/area scope, or when the appointment:read OAuth scope is
absent from the token.

Response Body Fields:

Field Name    Type     Description
status        Integer  HTTP status code. Value: 403
errorCode     String   Machine-readable error code.
message       String   Human-readable error description.
timestamp     String   ISO 8601 datetime of the error.
correlationId String   Correlation ID for tracing.

Example 403 Response Payload:

  status        : 403
  errorCode     : ACCESS_DENIED
  message       : Access denied. You are not authorised to view this
                  appointment.
  timestamp     : 2024-08-01T08:00:00Z
  correlationId : 3f6a1b2c-4d5e-6789-abcd-ef0123456789


3.5 HTTP 404 Not Found

Description: No appointment record exists in the data store for the
provided appointmentId.

Response Body Fields:

Field Name    Type     Description
status        Integer  HTTP status code. Value: 404
errorCode     String   Machine-readable error code.
message       String   Human-readable error description.
timestamp     String   ISO 8601 datetime of the error.
correlationId String   Correlation ID for tracing.

Example 404 Response Payload:

  status        : 404
  errorCode     : APPOINTMENT_NOT_FOUND
  message       : Appointment not found for the provided appointmentId.
  timestamp     : 2024-08-01T08:00:00Z
  correlationId : 3f6a1b2c-4d5e-6789-abcd-ef0123456789


3.6 HTTP 500 Internal Server Error

Description: An unexpected error occurred within the service

ENDPOINT DESIGN DOCUMENT
=========================

Source Requirement ID : SER-010-020-134
Endpoint Path         : /api/v1/appointments/{appointmentId}
HTTP Method           : DELETE
Summary               : Soft-delete or cancel an appointment record by setting status to Cancelled
Security Auth         : Bearer JWT (OAuth2 / OIDC)
Security Scope        : appointment:delete
Permitted Roles       : PICKUP_COORDINATOR, ADMIN, INTEGRATION_SERVICE


---------------------------------------------------------------------------
SECTION 1 — ENDPOINT IDENTIFICATION
---------------------------------------------------------------------------

Path        : /api/v1/appointments/{appointmentId}
Method      : DELETE
Summary     : Cancel an existing appointment by transitioning its status to
              Cancelled. The record is soft-deleted; it is never physically
              removed from the data store.
Description : Accepts a cancellation reason and a confirmation source in the
              request body. Validates the appointment exists and is in a
              cancellable state, persists the cancellation, de-assigns any
              assigned chauffeur, appends an immutable audit entry, and
              asynchronously dispatches cancellation notifications to the
              customer and chauffeur and propagates the status change to CRM
              and DBP.


---------------------------------------------------------------------------
SECTION 2 — REQUEST SPECIFICATION
---------------------------------------------------------------------------

2.1 Request Headers
-------------------

Header Name      : Authorization
Required         : Yes
Format           : Bearer <JWT token>
Description      : OAuth2 / OIDC Bearer token. Must contain a valid,
                   non-expired JWT signed by the trusted identity provider.
                   The token must carry the appointment:delete scope and a
                   role claim matching one of the permitted roles.

Header Name      : Content-Type
Required         : Yes
Allowed Value    : application/json
Description      : Request body must be JSON-encoded.

Header Name      : Accept
Required         : No
Recommended Value: application/json
Description      : Indicates the caller expects a JSON response.

Header Name      : X-Correlation-ID
Required         : No (strongly recommended)
Format           : UUID v4
Description      : Caller-supplied correlation identifier for distributed
                   tracing. If absent, the system generates one internally
                   and returns it in the response header.

Header Name      : X-Request-ID
Required         : No
Format           : UUID v4
Description      : Caller-supplied request identifier for idempotency
                   tracking and log correlation.


2.2 Path Parameters
-------------------

Parameter Name : appointmentId
Location       : Path
Type           : String
Required       : Yes
Format         : UUID v4 (xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx)
Constraints    : Must be a well-formed UUID. Must correspond to an existing
                 appointment record. Non-UUID values are rejected with 400
                 before any data-store lookup is attempted.
Example        : a3f1c2d4-89ab-4cde-b012-3456789abcde


2.3 Request Body Schema
-----------------------

Content-Type : application/json
Required     : Yes

Field Name         : cancellationReason
Type               : String
Required           : Yes
Min Length         : 1 character (non-empty, non-whitespace)
Max Length         : 500 characters
Format             : Free text; no special character restrictions beyond
                     standard UTF-8 printable characters.
Regex              : Must not be blank or consist solely of whitespace.
                     Pattern: ^\S.*$ (must start with a non-whitespace char)
Description        : Human-readable reason for cancelling the appointment.
                     Stored verbatim in the appointment record and audit log.
Validation Error   : 400 Bad Request if absent, null, empty, or whitespace-
                     only.
Example Value      : "Customer requested cancellation due to schedule change."

Field Name         : confirmationSource
Type               : String (Enumerated)
Required           : Yes
Allowed Values     : PICKUP_COORDINATOR_DASHBOARD, CHAUFFEUR_MOBILE_APP,
                     CRM_WEBHOOK, DBP_PORTAL, ADMIN_CONSOLE,
                     INTEGRATION_SERVICE, ICP_PORTAL
Min Length         : 1 character
Max Length         : 100 characters
Description        : Identifies the actor or channel that initiated the
                     cancellation. Used for audit traceability and downstream
                     routing decisions.
Validation Error   : 400 Bad Request if absent, null, empty, or not one of
                     the allowed enumerated values.
Example Value      : "PICKUP_COORDINATOR_DASHBOARD"

Example Request Body:
{
  "cancellationReason": "Customer requested cancellation due to schedule change.",
  "confirmationSource": "PICKUP_COORDINATOR_DASHBOARD"
}


---------------------------------------------------------------------------
SECTION 3 — RESPONSE SPECIFICATION
---------------------------------------------------------------------------

3.1 HTTP 200 OK — Successful Cancellation
------------------------------------------

Returned when the appointment has been successfully cancelled and all
synchronous post-conditions have been satisfied.

Response Body Fields:

Field Name            : status
Type                  : String
Description           : Outcome of the operation.
Example Value         : "SUCCESS"

Field Name            : message
Type                  : String
Description           : Human-readable confirmation message.
Example Value         : "Appointment has been successfully cancelled."

Field Name            : appointmentId
Type                  : String (UUID)
Description           : The identifier of the cancelled appointment.
Example Value         : "a3f1c2d4-89ab-4cde-b012-3456789abcde"

Field Name            : appointmentStatus
Type                  : String
Description           : The new status of the appointment record.
Example Value         : "CANCELLED"

Field Name            : cancelledAt
Type                  : String (ISO 8601 UTC datetime)
Description           : Timestamp at which the cancellation was persisted.
Example Value         : "2025-07-14T10:35:00Z"

Field Name            : cancelledBy
Type                  : String
Description           : Identity of the authenticated principal who performed
                        the cancellation (derived from JWT).
Example Value         : "coordinator-user-id-7821"

Field Name            : correlationId
Type                  : String (UUID)
Description           : Correlation identifier for tracing; echoed from the
                        request header or system-generated if not supplied.
Example Value         : "f7a2b3c4-1234-4abc-9def-0123456789ab"

Example 200 Response Body:
{
  "status": "SUCCESS",
  "message": "Appointment has been successfully cancelled.",
  "appointmentId": "a3f1c2d4-89ab-4cde-b012-3456789abcde",
  "appointmentStatus": "CANCELLED",
  "cancelledAt": "2025-07-14T10:35:00Z",
  "cancelledBy": "coordinator-user-id-7821",
  "correlationId": "f7a2b3c4-1234-4abc-9def-0123456789ab"
}


3.2 HTTP 400 Bad Request — Validation Failure
----------------------------------------------

Returned when the request body fails field-level validation or the path
parameter is malformed.

Response Body Fields:

Field Name   : status
Type         : String
Example      : "ERROR"

Field Name   : errorCode
Type         : String
Example      : "VALIDATION_ERROR"

Field Name   : message
Type         : String
Example      : "One or more request fields failed validation."

Field Name   : errors
Type         : Array of error objects
Sub-fields   :
  field      : Name of the failing field.
  message    : Specific validation failure description.

Example 400 Response Body (missing cancellationReason):
{
  "status": "ERROR",
  "errorCode": "VALIDATION_ERROR",
  "message": "One or more request fields failed validation.",
  "errors": [
    {
      "field": "cancellationReason",
      "message": "Cancellation reason is mandatory and must be provided."
    }
  ],
  "correlationId": "f7a2b3c4-1234-4abc-9def-0123456789ab"
}

Example 400 Response Body (missing confirmationSource):
{
  "status": "ERROR",
  "errorCode": "VALIDATION_ERROR",
  "message": "One or more request fields failed validation.",
  "errors": [
    {
      "field": "confirmationSource",
      "message": "Confirmation source is mandatory and must be provided."
    }
  ],
  "correlationId": "f7a2b3c4-1234-4abc-9def-0123456789ab"
}

Example 400 Response Body (malformed appointmentId):
{
  "status": "ERROR",
  "errorCode": "INVALID_PATH_PARAMETER",
  "message": "The appointmentId path parameter is not a valid UUID.",
  "correlationId": "f7a2b3c4-1234-4abc-9def-0123456789ab"
}


3.3 HTTP 401 Unauthorized — Authentication Failure
---------------------------------------------------

Returned when the Bearer JWT is absent, expired, malformed, or fails
signature verification.

Example 401 Response Body:
{
  "status": "ERROR",
  "errorCode": "UNAUTHORIZED",
  "message": "Authentication failed. A valid Bearer token is required.",
  "correlationId": "f7a2b3c4-1234-4abc-9def-0123456789ab"
}


3.4 HTTP 403 Forbidden — Authorisation Failure
-----------------------------------------------

Returned when the authenticated principal does not hold a permitted role
or the required scope (appointment:delete) is absent from the token.

Example 403 Response Body:
{
  "status": "ERROR",
  "errorCode": "FORBIDDEN",
  "message": "Insufficient permissions to cancel this appointment.",
  "correlationId": "f7a2b3c4-1234-4abc-9def-0123456789ab"
}


3.5 HTTP 404 Not Found — Appointment Not Found
-----------------------------------------------

Returned when no appointment record exists for the supplied appointmentId.

Example 404 Response Body:
{
  "status": "ERROR",
  "errorCode": "APPOINTMENT_NOT_FOUND",
  "message": "Appointment not found for the provided appointmentId.",
  "appointmentId": "a3f1c2d4-89ab-4cde-b012-3456789abcde",
  "correlationId": "f7a2b3c4-1234-4abc-9def-0123456789ab"
}


3.6 HTTP 409 Conflict — Invalid State Transition
-------------------------------------------------

Returned when the appointment exists but is not in a cancellable state
(In-Progress, Completed, or already Cancelled), or when a concurrent
duplicate DELETE request is received for an appointment already being
cancelled.

Example 409 Response Body (non-cancellable state):
{
  "status": "ERROR",
  "errorCode": "INVALID_STATE_TRANSITION",
  "message": "Appointment cannot be cancelled in its current state.",
  "appointmentId": "a3f1c2d4-89ab-4cde-b012-3456789abcde",
  "currentStatus": "COMPLETED",
  "correlationId": "f7a2b3c4-1234-4abc-9def-0123456789ab"
}

Example 409 Response Body (already cancelled — idempotency guard):
{
  "status": "ERROR",
  "errorCode": "ALREADY_CANCELLED",
  "message": "Appointment is already in Cancelled status. No further action taken.",
  "appointmentId": "a3f1c2d4-89ab-4cde-b012-3456789abcde",
  "currentStatus": "CANCELLED",
  "correlationId": "f7a2b3c4-1234-4abc-9def-0123456789ab"
}


3.7 HTTP 500 Internal Server Error — Unexpected Failure
--------------------------------------------------------

Returned when an unhandled exception or critical infrastructure failure
occurs (e.g., audit write cannot be confirmed after exhausting retries).

Example 500 Response Body:
{
  "status": "ERROR",
  "errorCode": "INTERNAL_SERVER_ERROR",
  "message": "An unexpected error occurred while processing the cancellation. Please retry or contact support.",
  "correlationId": "f7a2b3c4-1234-4abc-9def-0123456789ab"
}


---------------------------------------------------------------------------
SECTION 4 — BUSINESS RULES
---------------------------------------------------------------------------

Rule ID  : BR-1
Category : Pre-condition
Trigger  : DELETE request received for a given appointmentId.
Rule     : The appointment identified by appointmentId must exist in the
           system before a cancellation can be processed.
Behaviour: System looks up the appointment record. If not found, the request
           is rejected immediately.
Error    : 404 — "Appointment not found for the provided appointmentId."

ENDPOINT DESIGN DOCUMENT
=========================

Endpoint Reference: PUT /api/v1/appointments/{appointmentId}
Source Requirements: SER-010-020-003, SER-010-020-010, SER-010-020-012


------------------------------------------------------------------------
SECTION 1: ENDPOINT IDENTIFICATION
------------------------------------------------------------------------

Path            : /api/v1/appointments/{appointmentId}
HTTP Method     : PUT
Summary         : Update appointment fields such as status, allocation status, ETA, exception flag, linked JC, and promised delivery time
Description     : Performs a full replacement update on an existing appointment record identified by the appointmentId path parameter. The caller must supply all mandatory appointment fields in the request body. The operation re-evaluates chauffeur allocation and ETA when relevant fields change, records chauffeur assignment actions and rejection or timeout events, sets exception flags on anomalous states, appends an immutable audit log entry, and asynchronously notifies downstream systems and outbound channels of material changes. The endpoint is semantically idempotent with respect to final appointment state but appends a new audit record on every successful invocation.


------------------------------------------------------------------------
SECTION 2: REQUEST SPECIFICATION
------------------------------------------------------------------------

2.1 Request Headers
-------------------

Header Name       : Authorization
Required          : Yes
Format            : Bearer <JWT token>
Description       : OAuth2 / OIDC Bearer token. Must be a valid, non-expired, correctly signed JWT issued by the authorised identity provider. Token must carry one of the permitted role claims.

Header Name       : Content-Type
Required          : Yes
Allowed Value     : application/json
Description       : Request body must be JSON-encoded.

Header Name       : Accept
Required          : No
Recommended Value : application/json
Description       : Indicates the caller expects a JSON response.

Header Name       : If-Match
Required          : Recommended (for concurrency control)
Format            : ETag value string, e.g. "v5" or a version integer as a quoted string
Description       : Optimistic concurrency control header. The caller supplies the ETag or version value obtained from a prior GET or PUT response. If the persisted version does not match this value at the time of the update, the system returns 409 Conflict. Callers that omit this header accept the risk of a lost-update race when multiple coordinators modify the same appointment concurrently.

Header Name       : X-Request-ID
Required          : No
Format            : UUID v4
Description       : Optional idempotency and tracing identifier supplied by the caller. Logged in the audit trail and propagated to downstream services for correlation.


2.2 Path Parameters
-------------------

Parameter Name : appointmentId
Location       : Path
Type           : String
Required       : Yes
Format         : Non-empty string conforming to the system appointment ID format (alphanumeric, hyphens permitted, maximum 64 characters, pattern: ^[A-Za-z0-9\-]{1,64}$)
Description    : Unique identifier of the appointment to be updated. Must be non-null, non-empty, and match the expected format. Validated before any database lookup is attempted.
Validation     : If null, empty, or format mismatch, the system returns 400 Bad Request with error code BR-17 before any persistence operation.


2.3 Query Parameters
--------------------

None defined for this endpoint.


2.4 Request Body Schema
-----------------------

Content-Type: application/json

The request body represents the full updated state of the appointment. All mandatory fields must be present. Omitting a mandatory field is treated as a validation failure (BR-3).

Field Name                  : appointmentNumber
Type                        : String
Required                    : Yes
Max Length                  : 50
Pattern                     : ^[A-Za-z0-9\-]{1,50}$
Description                 : Human-readable appointment reference number. Must be non-empty and match the system appointment numbering format.

Field Name                  : customerName
Type                        : String
Required                    : Yes
Min Length                  : 1
Max Length                  : 150
Description                 : Full name of the customer associated with the appointment. Must be non-empty.

Field Name                  : contactReference
Type                        : String
Required                    : Yes
Max Length                  : 100
Description                 : Authorised and masked customer contact reference (e.g. masked mobile number or masked email). Raw PII must never be submitted or stored. The system validates that the value conforms to the masked format and will not persist unmasked contact data (BR-12).

Field Name                  : vehicleRegistration
Type                        : String
Required                    : Yes
Max Length                  : 20
Pattern                     : ^[A-Za-z0-9\- ]{1,20}$
Description                 : Vehicle registration plate number. Must be non-empty.

Field Name                  : vehicleModel
Type                        : String
Required                    : Yes
Max Length                  : 100
Description                 : Vehicle model description. Must be non-empty.

Field Name                  : pickupDate
Type                        : String
Required                    : Yes
Format                      : ISO 8601 date, YYYY-MM-DD
Description                 : Date of the scheduled pickup. Combined with pickupTime, the resulting timestamp must be in the future relative to server time at the moment of the request (BR-5).

Field Name                  : pickupTime
Type                        : String
Required                    : Yes
Format                      : HH:mm (24-hour)
Description                 : Time of the scheduled pickup. Combined with pickupDate, must produce a future timestamp.

Field Name                  : pickupAddress
Type                        : Object
Required                    : Conditionally required (required unless permittedArea is provided)
Description                 : Structured pickup location. At least one of pickupAddress or permittedArea must be present.

Field Name                  : pickupAddress.line1
Type                        : String
Required                    : Yes (when pickupAddress object is present)
Max Length                  : 200
Description                 : First line of the pickup address.

Field Name                  : pickupAddress.line2
Type                        : String
Required                    : No
Max Length                  : 200
Description                 : Second line of the pickup address.

Field Name                  : pickupAddress.city
Type                        : String
Required                    : Yes (when pickupAddress object is present)
Max Length                  : 100
Description                 : City of the pickup address.

Field Name                  : pickupAddress.postalCode
Type                        : String
Required                    : Yes (when pickupAddress object is present)
Max Length                  : 20
Description                 : Postal or ZIP code of the pickup address.

Field Name                  : pickupAddress.country
Type                        : String
Required                    : Yes (when pickupAddress object is present)
Max Length                  : 100
Description                 : Country of the pickup address.

Field Name                  : permittedArea
Type                        : String
Required                    : Conditionally required (required when pickupAddress is absent)
Max Length                  : 200
Description                 : Permitted geographic area designation used as an alternative to a full structured address.

Field Name                  : appointmentStatus
Type                        : String
Required                    : Yes
Allowed Values              : PENDING, CONFIRMED, ALLOCATED, IN_PROGRESS, EXCEPTION (terminal values COMPLETED and CANCELLED are not accepted in an update payload for a mutable appointment)
Description                 : Current status of the appointment. Must be a recognised non-terminal status value.

Field Name                  : dropServiceSelected
Type                        : Boolean
Required                    : Yes
Description                 : Indicates whether a drop-off service has been selected. When true, dropAddress, dropDate, and dropTime are all mandatory (BR-4).

Field Name                  : dropAddress
Type                        : Object
Required                    : Conditionally required (required when dropServiceSelected is true)
Description                 : Structured drop-off location. Required when dropServiceSelected is true.

Field Name                  : dropAddress.line1
Type                        : String
Required                    : Yes (when dropAddress object is present)
Max Length                  : 200
Description                 : First line of the drop-off address.

Field Name                  : dropAddress.line2
Type                        : String
Required                    : No
Max Length                  : 200
Description                 : Second line of the drop-off address.

Field Name                  : dropAddress.city
Type                        : String
Required                    : Yes (when dropAddress object is present)
Max Length                  : 100
Description                 : City of the drop-off address.

Field Name                  : dropAddress.postalCode
Type                        : String
Required                    : Yes (when dropAddress object is present)
Max Length                  : 20
Description                 : Postal or ZIP code of the drop-off address.

Field Name                  : dropAddress.country
Type                        : String
Required                    : Yes (when dropAddress object is present)
Max Length                  : 100
Description                 : Country of the drop-off address.

Field Name                  : dropDate
Type                        : String
Required                    : Conditionally required (required when dropServiceSelected is true)
Format                      : ISO 8601 date, YYYY-MM-DD
Description                 : Date of the scheduled drop-off. Must be on or after pickupDate. Combined with dropTime, the resulting timestamp must be strictly after the pickup date/time (BR-6).

Field Name                  : dropTime
Type                        : String
Required                    : Conditionally required (required when dropServiceSelected is true)
Format                      : HH:mm (24-hour)
Description                 : Time of the scheduled drop-off. Combined with dropDate, must produce a timestamp strictly after the pickup date/time (BR-6).

Field Name                  : allocationStatus
Type                        : String
Required                    : No
Allowed Values              : UNALLOCATED, PENDING_ALLOCATION, ALLOCATED, REJECTED, TIMED_OUT
Description                 : Current chauffeur allocation status. May be provided by the caller or will be recomputed by the system if pickup details change (BR-7).

Field Name                  : chauffeurId
Type                        : String
Required                    : No
Max Length                  : 64
Description                 : Identifier of the assigned chauffeur. When changed, triggers recording of chauffeur assignment action per SER-010-020-010 (BR-8).

Field Name                  : chauffeurName
Type                        : String
Required                    : No
Max Length                  : 150
Description                 : Display name of the assigned chauffeur. When changed alongside chauffeurId, triggers re-evaluation per BR-7 and BR-8.

Field Name                  : chauffeurRequestStatus
Type                        : String
Required                    : No
Allowed Values              : SENT, ACCEPTED, REJECTED, TIMED_OUT
Description                 : Status of the chauffeur assignment request. Required when chauffeurId is provided. Persisted per SER-010-020-010.

Field Name                  : rejectionReason
Type                        : String
Required                    : Conditionally required (required when chauffeurRequestStatus is REJECTED)
Max Length                  : 500
Description                 : Reason provided by the chauffeur for rejecting the assignment. Persisted per SER-010-020-012 (BR-9).

Field Name                  : timeoutFlag
Type                        : Boolean
Required                    : No
Description                 : Set to true when the chauffeur assignment request has timed out. Persisted per SER-010-020-012 (BR-9). When true, triggers exception flag logic (BR-10).

Field Name                  : exceptionFlag
Type                        : Boolean
Required                    : No
Description                 : Indicates the appointment is in an exceptional state. The system will set this to true automatically on chauffeur rejection, timeout, or ETA anomaly (BR-10). Callers may also explicitly set this field.

Field Name                  : linkedJobCardNumber
Type                        : String
Required                    : No
Max Length                  : 50
Description                 : Reference to the linked Job Card (JC) number. If present on the existing record and not supplied in the update payload, the system preserves the existing value rather than overwriting with null (BR-11).

Field Name                  : promisedDeliveryTime
Type                        : String
Required                    : No
Format                      : ISO 8601 datetime, YYYY-MM-DDTHH:mm:ssZ
Description                 : Promised delivery time associated with the linked Job Card. Preserved if already on record and not explicitly provided in the update (BR-11).

Field Name                  : currentEta
Type                        : String
Required                    : No
Format                      : ISO 8601 datetime, YYYY-MM-DDTHH:mm:ssZ
Description                 : Caller-supplied ETA. The system will recompute and overwrite this value if pickupDate, pickupTime, or pickupAddress is changed (BR-13). Caller-supplied value is accepted only when pickup details are unchanged.

Field Name                  : version
Type                        : Integer
Required                    : Recommended
Minimum                     : 1
Description                 : Optimistic concurrency version number of the appointment record as known to the caller. Must match the persisted version at the time of the update. If mismatched, the system returns 409 Conflict. Mirrors the If-Match header mechanism; either or both may be used.

Field Name                  : notes
Type                        : String
Required                    : No
Max Length                  : 1000
Description                 : Free-text notes or remarks associated with the appointment.


------------------------------------------------------------------------
SECTION 3: RESPONSE SPECIFICATION
------------------------------------------------------------------------

3.1 HTTP 200 OK - Successful Update
------------------------------------

Returned when the appointment has been successfully updated and persisted.

Response Body Fields:

Field Name                  : appointmentId
Type                        : String
Description
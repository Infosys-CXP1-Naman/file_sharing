sql
-- =============================================================================
-- MSIL CHAUFFEUR PICKUP AND DROP SERVICE – APPOINTMENT BOOKING SYSTEM
-- RDBMS SCRIPTS (PostgreSQL)
-- =============================================================================

-- =============================================================================
-- SCHEMA CREATION
-- =============================================================================

CREATE SCHEMA IF NOT EXISTS msil_pickup;
SET search_path TO msil_pickup, public;

-- =============================================================================
-- EXTENSIONS
-- =============================================================================

CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "postgis";

-- =============================================================================
-- UTILITY FUNCTION: AUTO-UPDATE updated_at AND version
-- =============================================================================

CREATE OR REPLACE FUNCTION set_updated_at_and_version()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at := NOW();
  NEW.version    := OLD.version + 1;
  RETURN NEW;
END;
$$;

-- =============================================================================
-- TABLE: vehicles
-- =============================================================================

CREATE TABLE vehicles (
  id                    UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
  registration_number   VARCHAR(20)     NOT NULL,
  vin                   VARCHAR(17)     NOT NULL,
  model                 VARCHAR(100)    NOT NULL,
  customer_name         VARCHAR(200)    NOT NULL,
  odometer_reading      NUMERIC(10,2)   NOT NULL DEFAULT 0,
  fuel_level_pct        NUMERIC(5,2)    CHECK (fuel_level_pct BETWEEN 0 AND 100),
  soc_pct               NUMERIC(5,2)    CHECK (soc_pct BETWEEN 0 AND 100),
  cng_level_pct         NUMERIC(5,2)    CHECK (cng_level_pct BETWEEN 0 AND 100),
  petrol_level_pct      NUMERIC(5,2)    CHECK (petrol_level_pct BETWEEN 0 AND 100),
  fuel_type             VARCHAR(20)     NOT NULL CHECK (fuel_type IN ('PETROL','DIESEL','CNG','EV','HYBRID')),
  inventory_checklist   JSONB           NOT NULL DEFAULT '{}',
  is_deleted            BOOLEAN         NOT NULL DEFAULT FALSE,
  version               INTEGER         NOT NULL DEFAULT 1,
  created_at            TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
  updated_at            TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
  CONSTRAINT uq_vehicles_registration_number UNIQUE (registration_number),
  CONSTRAINT uq_vehicles_vin                 UNIQUE (vin)
);

COMMENT ON TABLE  vehicles                    IS 'Vehicle master record identified by registration number and VIN, holding model, customer name, odometer, fuel/SOC/CNG levels, and inventory checklist items.';
COMMENT ON COLUMN vehicles.registration_number IS 'Vehicle registration plate number - unique identifier used for QR scan and manual entry during pickup/drop.';
COMMENT ON COLUMN vehicles.vin                 IS '17-character Vehicle Identification Number.';
COMMENT ON COLUMN vehicles.soc_pct             IS 'State of Charge percentage - applicable for EV fuel type; NULL for non-EV vehicles.';
COMMENT ON COLUMN vehicles.cng_level_pct       IS 'CNG tank level percentage - applicable for CNG fuel type; NULL for non-CNG vehicles.';
COMMENT ON COLUMN vehicles.petrol_level_pct    IS 'Petrol level percentage - applicable for CNG bi-fuel vehicles carrying a petrol reserve tank.';
COMMENT ON COLUMN vehicles.inventory_checklist IS 'JSONB map of checklist item keys to boolean present/absent values captured at pickup handover.';
COMMENT ON COLUMN vehicles.version             IS 'Optimistic-lock version counter incremented on every UPDATE.';

CREATE INDEX idx_vehicles_registration ON vehicles (registration_number) WHERE is_deleted = FALSE;
CREATE INDEX idx_vehicles_vin          ON vehicles (vin)                 WHERE is_deleted = FALSE;
CREATE INDEX idx_vehicles_fuel_type    ON vehicles (fuel_type)           WHERE is_deleted = FALSE;
CREATE INDEX idx_vehicles_updated_at   ON vehicles (updated_at DESC);

CREATE TRIGGER trg_vehicles_updated_at
  BEFORE UPDATE ON vehicles
  FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();

-- =============================================================================
-- TABLE: chauffeurs
-- =============================================================================

CREATE TABLE chauffeurs (
  id                  UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
  chauffeur_code      VARCHAR(50)   NOT NULL,
  full_name           VARCHAR(150)  NOT NULL,
  masked_contact      VARCHAR(20)   NOT NULL,
  photo_url           TEXT,
  dealership_tag      VARCHAR(100),
  starting_location   JSONB,
  current_location    JSONB,
  availability_status VARCHAR(30)   NOT NULL DEFAULT 'AVAILABLE'
                        CHECK (availability_status IN ('AVAILABLE','BUSY','OFF_DUTY','BLOCKED')),
  operating_days      JSONB         NOT NULL DEFAULT '[]',
  operating_hours     JSONB         NOT NULL DEFAULT '{}',
  blocked_slots       JSONB         NOT NULL DEFAULT '[]',
  current_workload    SMALLINT      NOT NULL DEFAULT 0,
  acceptance_history  JSONB         NOT NULL DEFAULT '{}',
  is_deleted          BOOLEAN       NOT NULL DEFAULT FALSE,
  version             INTEGER       NOT NULL DEFAULT 1,
  created_at          TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  updated_at          TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  CONSTRAINT uq_chauffeurs_chauffeur_code UNIQUE (chauffeur_code)
);

COMMENT ON TABLE  chauffeurs                  IS 'Driver profiles used by the chauffeur recommendation and assignment engine for MSIL pickup and drop service.';
COMMENT ON COLUMN chauffeurs.chauffeur_code   IS 'Human-readable unique identifier for the chauffeur (e.g. CHF-0042).';
COMMENT ON COLUMN chauffeurs.masked_contact   IS 'Masked mobile number shown in UI; full number stored in a separate secrets vault.';
COMMENT ON COLUMN chauffeurs.photo_url        IS 'CDN URL of the chauffeur profile photograph.';
COMMENT ON COLUMN chauffeurs.dealership_tag   IS 'Dealership code the chauffeur is primarily mapped to; NULL means floating/untagged.';
COMMENT ON COLUMN chauffeurs.starting_location IS 'GeoJSON Point {"type":"Point","coordinates":[lng,lat]} representing the chauffeur declared start location.';
COMMENT ON COLUMN chauffeurs.current_location  IS 'Last known GeoJSON Point updated by the Chauffeur app during an active trip.';
COMMENT ON COLUMN chauffeurs.availability_status IS 'Real-time availability state: AVAILABLE, BUSY, OFF_DUTY, or BLOCKED.';
COMMENT ON COLUMN chauffeurs.operating_days   IS 'JSON array of ISO weekday numbers (1=Mon...7=Sun) on which the chauffeur operates.';
COMMENT ON COLUMN chauffeurs.operating_hours  IS 'JSON object {"start":"HH:MM","end":"HH:MM"} representing daily operating window.';
COMMENT ON COLUMN chauffeurs.blocked_slots    IS 'JSON array of {"from":"ISO8601","to":"ISO8601","reason":"string"} objects for leave or unavailability windows.';
COMMENT ON COLUMN chauffeurs.current_workload IS 'Count of active or pending assignments currently held by this chauffeur.';
COMMENT ON COLUMN chauffeurs.acceptance_history IS 'JSON object {"total_offered":n,"accepted":n,"rejected":n,"timed_out":n} used by the recommendation engine scoring.';
COMMENT ON COLUMN chauffeurs.version          IS 'Optimistic-locking version counter incremented on every UPDATE.';

CREATE INDEX idx_chauffeurs_dealership_tag      ON chauffeurs (dealership_tag);
CREATE INDEX idx_chauffeurs_availability_status ON chauffeurs (availability_status);
CREATE INDEX idx_chauffeurs_is_deleted          ON chauffeurs (is_deleted);
CREATE INDEX idx_chauffeurs_current_location    ON chauffeurs USING GIN (current_location);
CREATE INDEX idx_chauffeurs_starting_location   ON chauffeurs USING GIN (starting_location);
CREATE INDEX idx_chauffeurs_blocked_slots       ON chauffeurs USING GIN (blocked_slots);

CREATE TRIGGER trg_chauffeurs_updated_at
  BEFORE UPDATE ON chauffeurs
  FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();

-- =============================================================================
-- TABLE: appointments
-- =============================================================================

CREATE TABLE appointments (
  id                        UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
  appointment_number        VARCHAR(50)     NOT NULL,
  customer_id               UUID            NOT NULL,
  vehicle_id                UUID            NOT NULL REFERENCES vehicles(id),
  pickup_date_time          TIMESTAMPTZ     NOT NULL,
  pickup_address            TEXT,
  pickup_permitted_area     TEXT,
  drop_service_selected     BOOLEAN         NOT NULL DEFAULT FALSE,
  drop_address              TEXT,
  drop_date_time            TIMESTAMPTZ,
  appointment_status        VARCHAR(30)     NOT NULL DEFAULT 'SCHEDULED'
                              CHECK (appointment_status IN (
                                'SCHEDULED','ASSIGNED','IN_PROGRESS','PICKED_UP',
                                'IN_TRANSIT','DELIVERED','RESCHEDULED','CANCELLED','EXCEPTION'
                              )),
  allocation_status         VARCHAR(30)     NOT NULL DEFAULT 'PENDING'
                              CHECK (allocation_status IN (
                                'PENDING','RECOMMENDED','ASSIGNED','REASSIGNING','FAILED'
                              )),
  chauffeur_id              UUID            REFERENCES chauffeurs(id),
  chauffeur_name            VARCHAR(150),
  request_sent_at           TIMESTAMPTZ,
  response_received_at      TIMESTAMPTZ,
  request_response_status   VARCHAR(20)
                              CHECK (request_response_status IN ('PENDING','ACCEPTED','REJECTED','TIMEOUT')),
  current_eta               TIMESTAMPTZ,
  exception_flag            BOOLEAN         NOT NULL DEFAULT FALSE,
  exception_reason          TEXT,
  jc_number                 VARCHAR(50),
  promised_delivery_time    TIMESTAMPTZ,
  crm_appointment_ref       VARCHAR(100),
  assignment_round          SMALLINT        NOT NULL DEFAULT 0,
  otp_verified              BOOLEAN         NOT NULL DEFAULT FALSE,
  customer_signature_ref    TEXT,
  is_deleted                BOOLEAN         NOT NULL DEFAULT FALSE,
  version                   INTEGER         NOT NULL DEFAULT 1,
  created_at                TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
  updated_at                TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
  CONSTRAINT uq_appointments_appointment_number UNIQUE (appointment_number)
);

COMMENT ON TABLE  appointments                         IS 'Core booking record for chauffeur-driven vehicle pickup and drop service appointments.';
COMMENT ON COLUMN appointments.appointment_number      IS 'Human-readable unique appointment identifier shared with CRM and customer communications.';
COMMENT ON COLUMN appointments.appointment_status      IS 'Lifecycle status of the appointment from scheduling through delivery or cancellation.';
COMMENT ON COLUMN appointments.allocation_status       IS 'Tracks the chauffeur recommendation and assignment sub-process state.';
COMMENT ON COLUMN appointments.request_response_status IS 'Outcome of the assignment dispatch request sent to the chauffeur app.';
COMMENT ON COLUMN appointments.exception_flag          IS 'Set TRUE when a delay, refusal, or other exception event is active on this appointment.';
COMMENT ON COLUMN appointments.assignment_round        IS 'Incremented each time the chauffeur recommendation engine is rerun for this appointment.';
COMMENT ON COLUMN appointments.otp_verified            IS 'TRUE once a valid OTP has been verified for handover or rescheduling on this appointment.';
COMMENT ON COLUMN appointments.version                 IS 'Optimistic-locking version counter incremented on every UPDATE.';

CREATE INDEX idx_appointments_appointment_number ON appointments (appointment_number);
CREATE INDEX idx_appointments_customer_id        ON appointments (customer_id);
CREATE INDEX idx_appointments_vehicle_id         ON appointments (vehicle_id);
CREATE INDEX idx_appointments_chauffeur_id       ON appointments (chauffeur_id);
CREATE INDEX idx_appointments_pickup_date_time   ON appointments (pickup_date_time);
CREATE INDEX idx_appointments_appointment_status ON appointments (appointment_status);
CREATE INDEX idx_appointments_allocation_status  ON appointments (allocation_status);
CREATE INDEX idx_appointments_jc_number          ON appointments (jc_number) WHERE jc_number IS NOT NULL;
CREATE INDEX idx_appointments_exception_flag     ON appointments (exception_flag) WHERE exception_flag = TRUE;
CREATE INDEX idx_appointments_is_deleted         ON appointments (is_deleted);

CREATE TRIGGER trg_appointments_updated_at
  BEFORE UPDATE ON appointments
  FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();

-- =============================================================================
-- TABLE: trips
-- =============================================================================

CREATE TABLE trips (
  id                    UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
  appointment_id        UUID            NOT NULL REFERENCES appointments(id),
  chauffeur_id          UUID            NOT NULL REFERENCES chauffeurs(id),
  trip_type             VARCHAR(10)     NOT NULL CHECK (trip_type IN ('PICKUP','DROP')),
  trip_status           VARCHAR(40)     NOT NULL DEFAULT 'SCHEDULED'
                          CHECK (trip_status IN (
                            'SCHEDULED','PENDING','EN_ROUTE_TO_CUSTOMER','ARRIVED_AT_CUSTOMER',
                            'PICKUP_COMPLETE','IN_TRANSIT_TO_DEALERSHIP','DELIVERED_TO_DEALERSHIP',
                            'DROP_TRIP_STARTED','EN_ROUTE_TO_DROP_ADDRESS','ARRIVED_AT_DROP',
                            'DROP_COMPLETE','IN_PROGRESS','DELAYED','COMPLETED','CANCELLED'
                          )),
  start_location_lat    NUMERIC(10,7),
  start_location_lng    NUMERIC(10,7),
  current_location_lat  NUMERIC(10,7),
  current_location_lng  NUMERIC(10,7),
  destination_lat       NUMERIC(10,7),
  destination_lng       NUMERIC(10,7),
  suggested_start_time  TIMESTAMPTZ,
  actual_start_time     TIMESTAMPTZ,
  estimated_arrival     TIMESTAMPTZ,
  actual_arrival        TIMESTAMPTZ,
  dealership_eta        TIMESTAMPTZ,
  delay_flag            BOOLEAN         NOT NULL DEFAULT FALSE,
  delay_duration_mins   INTEGER,
  delay_reason          TEXT,
  qr_code_ref           VARCHAR(255),
  handover_completed    BOOLEAN         NOT NULL DEFAULT FALSE,
  handover_timestamp    TIMESTAMPTZ,
  jc_number             VARCHAR(100),
  version               INTEGER         NOT NULL DEFAULT 1,
  is_deleted            BOOLEAN         NOT NULL DEFAULT FALSE,
  created_at            TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
  updated_at            TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE  trips                     IS 'Active journey record for each pickup or drop leg of a chauffeur-driven service appointment.';
COMMENT ON COLUMN trips.trip_type           IS 'PICKUP = vehicle collected from customer; DROP = vehicle returned to customer.';
COMMENT ON COLUMN trips.trip_status         IS 'Lifecycle state covering all phases from scheduling through completion or cancellation.';
COMMENT ON COLUMN trips.qr_code_ref         IS 'Reference key to the QR-coded trip summary generated after pickup completion.';
COMMENT ON COLUMN trips.delay_flag          IS 'Set TRUE by the ETA monitoring job when live ETA exceeds the scheduled window.';
COMMENT ON COLUMN trips.delay_duration_mins IS 'Computed delay in minutes at the time the delay was first detected.';
COMMENT ON COLUMN trips.jc_number           IS 'Linked Job Card number populated for DROP trips after JC completion in DBP.';
COMMENT ON COLUMN trips.version             IS 'Optimistic-lock counter incremented on every UPDATE.';

CREATE INDEX idx_trips_appointment_id ON trips (appointment_id);
CREATE INDEX idx_trips_chauffeur_id   ON trips (chauffeur_id);
CREATE INDEX idx_trips_trip_status    ON trips (trip_status);
CREATE INDEX idx_trips_trip_type      ON trips (trip_type);
CREATE INDEX idx_trips_delay_flag     ON trips (delay_flag) WHERE delay_flag = TRUE;
CREATE INDEX idx_trips_created_at     ON trips (created_at DESC);

CREATE TRIGGER trg_trips_updated_at
  BEFORE UPDATE ON trips
  FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();

-- =============================================================================
-- TABLE: assignments
-- =============================================================================

CREATE TABLE assignments (
  id                     UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
  appointment_id         UUID          NOT NULL REFERENCES appointments(id),
  trip_id                UUID          REFERENCES trips(id),
  jc_number              VARCHAR(50),
  round_number           SMALLINT      NOT NULL DEFAULT 1,
  previous_chauffeur_id  UUID          REFERENCES chauffeurs(id),
  candidate_chauffeur_id UUID          NOT NULL REFERENCES chauffeurs(id),
  failure_type           VARCHAR(50),
  declared_availability  BOOLEAN       NOT NULL DEFAULT TRUE,
  dealership_mapping     VARCHAR(100),
  blocked_slots          JSONB         NOT NULL DEFAULT '[]',
  workload_score         NUMERIC(5,2),
  chauffeur_location     JSONB,
  travel_time_minutes    INTEGER,
  recommendation_result  VARCHAR(20)   NOT NULL
                           CHECK (recommendation_result IN (
                             'RECOMMENDED','OVERRIDE','REJECTED','TIMEOUT','ACCEPTED','NO_MATCH'
                           )),
  recommendation_reason  TEXT,
  request_sent_at        TIMESTAMPTZ,
  response_received_at   TIMESTAMPTZ,
  rerun_timestamp        TIMESTAMPTZ,
  trip_type              VARCHAR(10)   NOT NULL CHECK (trip_type IN ('PICKUP','DROP')),
  status                 VARCHAR(30)   NOT NULL DEFAULT 'PENDING'
                           CHECK (status IN (
                             'PENDING','ACCEPTED','REJECTED','TIMEOUT','REASSIGNED','CANCELLED'
                           )),
  override_reason        TEXT,
  coordinator_user_id    UUID,
  version                INTEGER       NOT NULL DEFAULT 1,
  is_deleted             BOOLEAN       NOT NULL DEFAULT FALSE,
  created_at             TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  updated_at             TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE  assignments                       IS 'Chauffeur assignment attempt records for both pickup and drop trips, capturing each recommendation round, candidate evaluation, and final outcome.';
COMMENT ON COLUMN assignments.round_number          IS 'Iteration counter incremented on each reassignment loop for the same appointment.';
COMMENT ON COLUMN assignments.failure_type          IS 'Reason the previous assignment failed: REJECTED, TIMEOUT, UNAVAILABLE, COORDINATOR_OVERRIDE, etc.';
COMMENT ON COLUMN assignments.blocked_slots         IS 'JSON array of blocked time windows for the candidate chauffeur at the time of recommendation.';
COMMENT ON COLUMN assignments.chauffeur_location    IS 'GeoJSON point snapshot of the candidate chauffeur location at recommendation time.';
COMMENT ON COLUMN assignments.recommendation_result IS 'Outcome of this assignment attempt: RECOMMENDED by engine, OVERRIDE by coordinator, ACCEPTED/REJECTED/TIMEOUT by chauffeur, or NO_MATCH.';
COMMENT ON COLUMN assignments.rerun_timestamp       IS 'Timestamp when the recommendation engine was re-triggered for a new round.';
COMMENT ON COLUMN assignments.version               IS 'Optimistic-locking version counter.';

CREATE INDEX idx_assignments_appointment_id        ON assignments (appointment_id);
CREATE INDEX idx_assignments_candidate_chauffeur   ON assignments (candidate_chauffeur_id);
CREATE INDEX idx_assignments_status                ON assignments (status);
CREATE INDEX idx_assignments_trip_type             ON assignments (trip_type);
CREATE INDEX idx_assignments_round_number          ON assignments (appointment_id, round_number);
CREATE INDEX idx_assignments_created_at            ON assignments (created_at DESC);
CREATE INDEX idx_assignments_recommendation_result ON assignments (recommendation_result);
CREATE INDEX idx_assignments_trip_id               ON assignments (trip_id);

CREATE TRIGGER trg_assignments_updated_at
  BEFORE UPDATE ON assignments
  FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();

-- =============================================================================
-- TABLE: otp_verifications
-- =============================================================================

CREATE TABLE otp_verifications (
  id                UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
  appointment_ref   VARCHAR(50)     NOT NULL,
  trip_ref          VARCHAR(50),
  jc_ref            VARCHAR(50),
  otp_hash          VARCHAR(128)    NOT NULL,
  otp_salt          VARCHAR(64)     NOT NULL,
  otp_purpose       VARCHAR(30)     NOT NULL
                      CHECK (otp_purpose IN (
                        'PICKUP_HANDOVER','RESCHEDULING','DROP_DELIVERY',
                        'CANCELLATION','CONTROLLED_OVERRIDE'
                      )),
  revised_slot_date DATE,
  revised_slot_time TIME,
  expiry_at         TIMESTAMPTZ     NOT NULL,
  is_used           BOOLEAN         NOT NULL DEFAULT FALSE,
  override_reason   TEXT,
  verified_at       TIMESTAMPTZ,
  verified_by_role  VARCHAR(30)
                      CHECK (verified_by_role IN ('CUSTOMER','COORDINATOR','CHAUFFEUR')),
  verified_by_user  VARCHAR(100),
  delivery_channel  VARCHAR(20)     NOT NULL
                      CHECK (delivery_channel IN ('ICP','WHATSAPP','SMS','DBP','CRM')),
  attempt_count     SMALLINT        NOT NULL DEFAULT 0,
  max_attempts      SMALLINT        NOT NULL DEFAULT 3,
  verification_status VARCHAR(20)   NOT NULL DEFAULT 'PENDING'
                      CHECK (verification_status IN (
                        'PENDING','VERIFIED','EXPIRED','OVERRIDDEN','FAILED','LOCKED'
                      )),
  is_deleted        BOOLEAN         NOT NULL DEFAULT FALSE,
  version           INTEGER         NOT NULL DEFAULT 1,
  created_at        TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
  CONSTRAINT fk_otp_appointment FOREIGN KEY (appointment_ref)
    REFERENCES appointments(appointment_number) ON DELETE RESTRICT
);

COMMENT ON TABLE  otp_verifications                IS 'OTP issuance and validation records for pickup handover, rescheduling, drop delivery, cancellation, and controlled override flows.';
COMMENT ON COLUMN otp_verifications.otp_hash       IS 'SHA-256 hash of the OTP value with per-record salt; plain-text OTP is never stored.';
COMMENT ON COLUMN otp_verifications.otp_salt       IS 'Per-record random salt used when hashing the OTP value.';
COMMENT ON COLUMN otp_verifications.otp_purpose    IS 'Business context for which the OTP was generated.';
COMMENT ON COLUMN otp_verifications.override_reason IS 'Populated only when otp_purpose = CONTROLLED_OVERRIDE; captures coordinator-supplied justification.';
COMMENT ON COLUMN otp_verifications.attempt_count  IS 'Number of failed verification attempts; locked out when attempt_count >= max_attempts.';
COMMENT ON COLUMN otp_verifications.verification_status IS 'Current state of the OTP record: PENDING, VERIFIED, EXPIRED, OVERRIDDEN, FAILED, or LOCKED.';

CREATE INDEX idx_otp_appointment_ref ON otp_verifications (appointment_ref);
CREATE INDEX idx_otp_expiry_unused   ON otp_verifications (expiry_at) WHERE is_used = FALSE AND is_deleted = FALSE;
CREATE INDEX idx_otp_jc_ref          ON otp_verifications (jc_ref)   WHERE jc_ref IS NOT NULL;
CREATE INDEX idx_otp_trip_ref        ON otp_verifications (trip_ref) WHERE trip_ref IS NOT NULL;
CREATE INDEX idx_otp_purpose         ON otp_verifications (otp_purpose);
CREATE INDEX idx_otp_status          ON otp_verifications (verification_status);

CREATE TRIGGER trg_otp_verifications_updated_at
  BEFORE UPDATE ON otp_verifications
  FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();

-- =============================================================================
-- TABLE: cancellation_records
-- =============================================================================

CREATE TABLE cancellation_records (
  id                          UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
  appointment_id              UUID            NOT NULL REFERENCES appointments(id),
  trip_id                     UUID            REFERENCES trips(id),
  cancellation_reason         TEXT            NOT NULL,
  cancellation_source         VARCHAR(50)     NOT NULL
                                CHECK (cancellation_source IN (
                                  'CUSTOMER','COORDINATOR','SYSTEM','CHAUFFEUR'
                                )),
  confirmation_source         VARCHAR(50)     NOT NULL
                                CHECK (confirmation_source IN (
                                  'OTP_VERIFIED','CONTROLLED_OVERRIDE',
                                  'CUSTOMER_CONSENT','COORDINATOR_DECISION'
                                )),
  otp_verification_id         UUID            REFERENCES otp_verifications(id),
  override_reason             TEXT,
  cancelled_by_user_id        VARCHAR(100),
  cancelled_by_role           VARCHAR(50)
                                CHECK (cancelled_by_role IN (
                                  'PICKUP_COORDINATOR','CHAUFFEUR','CUSTOMER','SYSTEM'
                                )),
  cancellation_stage          VARCHAR(50)     NOT NULL
                                CHECK (cancellation_stage IN (
                                  'PRE_ASSIGNMENT','POST_ASSIGNMENT','EN_ROUTE',
                                  'AT_LOCATION','POST_REFUSAL','DROP_STAGE'
                                )),
  previous_appointment_status VARCHAR(50),
  remarks                     TEXT,
  cancelled_at                TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
  is_deleted                  BOOLEAN         NOT NULL DEFAULT FALSE,
  version                     INTEGER         NOT NULL DEFAULT 1,
  created_at                  TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
  updated_at                  TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE  cancellation_records                  IS 'Immutable audit log of every appointment or drop-trip cancellation event, capturing reason, confirmation method, stage, and actor.';
COMMENT ON COLUMN cancellation_records.cancellation_source IS 'Who originated the cancellation: CUSTOMER, COORDINATOR, SYSTEM, or CHAUFFEUR.';
COMMENT ON COLUMN cancellation_records.confirmation_source IS 'How the cancellation was confirmed: OTP_VERIFIED, CONTROLLED_OVERRIDE, CUSTOMER_CONSENT, or COORDINATOR_DECISION.';
COMMENT ON COLUMN cancellation_records.cancellation_stage  IS 'Lifecycle stage at which cancellation occurred.';
COMMENT ON COLUMN cancellation_records.override_reason     IS 'Mandatory free-text reason when confirmation_source is CONTROLLED_OVERRIDE.';

CREATE INDEX idx_cancellation_records_appointment_id      ON cancellation_records (appointment_id);
CREATE INDEX idx_cancellation_records_trip_id             ON cancellation_records (trip_id);
CREATE INDEX idx_cancellation_records_cancelled_at        ON cancellation_records (cancelled_at DESC);
CREATE INDEX idx_cancellation_records_cancellation_stage  ON cancellation_records (cancellation_stage);
CREATE INDEX idx_cancellation_records_confirmation_source ON cancellation_records (confirmation_source);

CREATE TRIGGER trg_cancellation_records_updated_at
  BEFORE UPDATE ON cancellation_records
  FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();

-- =============================================================================
-- TABLE: contact_attempt_logs
-- =============================================================================

CREATE TABLE contact_attempt_logs (
  id                    UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
  appointment_id        UUID            REFERENCES appointments(id),
  trip_id               UUID            REFERENCES trips(id),
  jc_number             VARCHAR(50),
  chauffeur_id          UUID            REFERENCES chauffeurs(id),
  contact_target        VARCHAR(20)     NOT NULL
                          CHECK (contact_target IN ('CHAUFFEUR','CUSTOMER')),
  contact_attempt_at    TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
  contact_outcome       VARCHAR(50)     NOT NULL
                          CHECK (contact_outcome IN (
                            'REACHED','NOT_REACHED','VOICEMAIL','CALLBACK_REQUESTED',
                            'REFUSED','AGREED_RESCHEDULE','AGREED_CANCEL','NO_RESPONSE'
                          )),
  rejection_reason      TEXT,
  delay_reason          TEXT,
  revised_eta           TIMESTAMPTZ,
  revised_start_time    TIMESTAMPTZ,
  coordinator_user_id   VARCHAR(100)    NOT NULL,
  remarks               TEXT,
  is_deleted            BOOLEAN         NOT NULL DEFAULT FALSE,
  version               INTEGER         NOT NULL DEFAULT 1,
  created_at            TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
  updated_at            TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE  contact_attempt_logs                IS 'Coordinator contact log holding appointment/trip/JC reference, chauffeur, contact attempt timestamp, contact outcome, rejection/delay reason, revised ETA/start time, coordinator user, and other remarks.';
COMMENT ON COLUMN contact_attempt_logs.contact_target IS 'Whether the coordinator attempted to contact the CHAUFFEUR or CUSTOMER.';
COMMENT ON COLUMN contact_attempt_logs.contact_outcome IS 'Result of the contact attempt.';
COMMENT ON COLUMN contact_attempt_logs.revised_eta    IS 'Revised ETA communicated or agreed during the contact attempt.';
COMMENT ON COLUMN contact_attempt_logs.revised_start_time IS 'Revised trip start time agreed during the contact attempt.';

CREATE INDEX idx_contact_attempt_logs_appointment_id ON contact_attempt_logs (appointment_id);
CREATE INDEX idx_contact_attempt_logs_trip_id        ON contact_attempt_logs (trip_id);
CREATE INDEX idx_contact_attempt_logs_chauffeur_id   ON contact_attempt_logs (chauffeur_id);
CREATE INDEX idx_contact_attempt_logs_jc_number      ON contact_attempt_logs (jc_number) WHERE jc_number IS NOT NULL;
CREATE INDEX idx_contact_attempt_logs_attempt_at     ON contact_attempt_logs (contact_attempt_at DESC);
CREATE INDEX idx_contact_attempt_logs_coordinator    ON contact_attempt_logs (coordinator_user_id);

CREATE TRIGGER trg_contact_attempt_logs_updated_at
  BEFORE UPDATE ON contact_attempt_logs
  FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();

-- =============================================================================
-- TABLE: rescheduling_records
-- =============================================================================

CREATE TABLE rescheduling_records (
  id                        UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
  appointment_id            UUID            NOT NULL REFERENCES appointments(id),
  original_pickup_date_time TIMESTAMPTZ     NOT NULL,
  revised_pickup_date_time  TIMESTAMPTZ     NOT NULL,
  reschedule_reason         TEXT,
  reschedule_trigger        VARCHAR(50)     NOT NULL
                              CHECK (reschedule_trigger IN (
                                'PRE_PICKUP_DELAY','HANDOVER_REFUSAL',
                                'COORDINATOR_INITIATED','CUSTOMER_REQUEST','SYSTEM'
                              )),
  otp_verification_id       UUID            REFERENCES otp_verifications(id),
  override_reason           TEXT,
  coordinator_user_id       VARCHAR(100)    NOT NULL,
  customer_consent          BOOLEAN         NOT NULL DEFAULT FALSE,
  contact_attempt_log_id    UUID            REFERENCES contact_attempt_logs(id),
  is_deleted                BOOLEAN         NOT NULL DEFAULT FALSE,
  version                   INTEGER         NOT NULL DEFAULT 1,
  created_at                TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
  updated_at                TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE  rescheduling_records                    IS 'Rescheduling event record holding appointment number, original and revised pickup date/time, OTP reference, coordinator user, and customer consent confirmation.';
COMMENT ON COLUMN rescheduling_records.reschedule_trigger IS 'Business event that triggered the rescheduling.';
COMMENT ON COLUMN rescheduling_records.customer_consent   IS 'TRUE when customer provided OTP or verbal consent for the rescheduling.';
COMMENT ON COLUMN rescheduling_records.override_reason    IS 'Populated when OTP was bypassed via controlled override.';

CREATE INDEX idx_rescheduling_records_appointment_id ON rescheduling_records (appointment_id);
CREATE INDEX idx_rescheduling_records_created_at     ON rescheduling_records (created_at DESC);
CREATE INDEX idx_rescheduling_records_trigger        ON rescheduling_records (reschedule_trigger);

CREATE TRIGGER trg_rescheduling_records_updated_at
  BEFORE UPDATE ON rescheduling_records
  FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();

-- =============================================================================
-- TABLE: drop_requests
-- =============================================================================

CREATE TABLE drop_requests (
  id                          UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
  appointment_id              UUID          NOT NULL REFERENCES appointments(id),
  jc_number                   VARCHAR(50)   NOT NULL,
  service_appointment_number  VARCHAR(50)   NOT NULL,
  drop_service_selection      VARCHAR(100)  NOT NULL,
  customer_name               VARCHAR(150)  NOT NULL,
  customer_contact            VARCHAR(20)   NOT NULL,
  vehicle_registration        VARCHAR(30)   NOT NULL REFERENCES vehicles(registration_number),
  drop_address_line1          VARCHAR(255)  NOT NULL,
  drop_address_line2          VARCHAR(255),
  drop_city                   VARCHAR(100),
  drop_state                  VARCHAR(100),
  drop_pincode                VARCHAR(10),
  drop_latitude               NUMERIC(10,7),
  drop_longitude              NUMERIC(10,7),
  requested_drop_date         DATE          NOT NULL,
  requested_drop_time         TIME          NOT NULL,
  promised_delivery_datetime  TIMESTAMPTZ,
  crm_fetch_timestamp         TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  crm_source_reference        VARCHAR(100),
  status                      VARCHAR(30)   NOT NULL DEFAULT 'PENDING'
                                CHECK (status IN (
                                  'PENDING','SCHEDULED','ASSIGNED','IN_TRANSIT',
                                  'DELIVERED','CANCELLED','EXCEPTION'
                                )),
  assigned_chauffeur_id       UUID          REFERENCES chauffeurs(id),
  assignment_id               UUID          REFERENCES assignments(id),
  dbp_dashboard_visible       BOOLEAN       NOT NULL DEFAULT FALSE,
  dbp_published_at            TIMESTAMPTZ,
  exception_flag              BOOLEAN       NOT NULL DEFAULT FALSE,
  exception_reason            TEXT,
  cancellation_record_id      UUID          REFERENCES cancellation_records(id),
  is_deleted                  BOOLEAN       NOT NULL DEFAULT FALSE,
  version                     INTEGER       NOT NULL DEFAULT 1,
  created_at                  TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  updated_at                  TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE  drop_requests                             IS 'Drop-service records fetched from CRM after JC completion, driving the drop scheduling and chauffeur assignment workflow.';
COMMENT ON COLUMN drop_requests.jc_number                  IS 'Job Card number linked to this drop request, auto-populated from CRM.';
COMMENT ON COLUMN drop_requests.service_appointment_number IS 'CRM service appointment number associated with the drop service.';
COMMENT ON COLUMN drop_requests.drop_service_selection     IS 'Type of drop service selected by the customer in CRM (e.g. HOME_DROP, DEALER_PICKUP).';
COMMENT ON COLUMN drop_requests.promised_delivery_datetime IS 'Promised delivery date and time auto-populated from JC data in CRM.';
COMMENT ON COLUMN drop_requests.crm_fetch_timestamp        IS 'Timestamp when this record was fetched or last synced from CRM.';
COMMENT ON COLUMN drop_requests.dbp_dashboard_visible      IS 'Flag indicating whether this drop request has been published to the DBP scheduling dashboard.';
COMMENT ON COLUMN drop_requests.exception_flag             IS 'Set to TRUE when a drop-trip exception (rejection, delay, reassignment) is active.';
COMMENT ON COLUMN drop_requests.version                    IS 'Optimistic-locking version counter incremented on every update.';

CREATE INDEX idx_drop_requests_appointment_id       ON drop_requests (appointment_id);
CREATE INDEX idx_drop_requests_jc_number            ON drop_requests (jc_number);
CREATE INDEX idx_drop_requests_service_appt_number  ON drop_requests (service_appointment_number);
CREATE INDEX idx_drop_requests_vehicle_registration ON drop_requests (vehicle_registration);
CREATE INDEX idx_drop_requests_status               ON drop_requests (status);
CREATE INDEX idx_drop_requests_assigned_chauffeur   ON drop_requests (assigned_chauffeur_id);
CREATE INDEX idx_drop_requests_requested_drop_date  ON drop_requests (requested_drop_date);
CREATE INDEX idx_drop_requests_is_deleted           ON drop_requests (is_deleted);

CREATE TRIGGER trg_drop_requests_updated_at
  BEFORE UPDATE ON drop_requests
  FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();

-- =============================================================================
-- TABLE: vehicle_condition_reports
-- =============================================================================

CREATE TABLE vehicle_condition_reports (
  id                        UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
  appointment_id            UUID            NOT NULL REFERENCES appointments(id),
  trip_id                   UUID            NOT NULL REFERENCES trips(id),
  chauffeur_id              UUID            NOT NULL REFERENCES chauffeurs(id),
  vehicle_id                UUID            NOT NULL REFERENCES vehicles(id),
  jc_number                 VARCHAR(50),
  report_type               VARCHAR(20)     NOT NULL
                              CHECK (report_type IN ('PICKUP','DROP_PRE_DEPARTURE','DROP_DELIVERY')),
  session_id                UUID            NOT NULL,
  registration_number       VARCHAR(20)     NOT NULL,
  vehicle_name              VARCHAR(150),
  odometer_reading          NUMERIC(10,2)   NOT NULL,
  odometer_anomaly_flag     BOOLEAN         NOT NULL DEFAULT FALSE,
  odometer_confirmed_by     VARCHAR(100),
  fuel_level_pct            NUMERIC(5,2)    CHECK (fuel_level_pct BETWEEN 0 AND 100),
  soc_pct                   NUMERIC(5,2)    CHECK (soc_pct BETWEEN 0 AND 100),
  cng_level_pct             NUMERIC(5,2)    CHECK (cng_level_pct BETWEEN 0 AND 100),
  petrol_level_pct          NUMERIC(5,2)    CHECK (petrol_level_pct BETWEEN 0 AND 100),
  vehicle_issues_text       TEXT,
  voice_recording_ref       TEXT,
  inventory_checklist       JSONB           NOT NULL DEFAULT '{}',
  inventory_custom_items    JSONB           NOT NULL DEFAULT '[]',
  final_remarks_text        TEXT,
  final_remarks_voice_ref   TEXT,
  customer_signature_ref    TEXT,
  signature_captured_at     TIMESTAMPTZ,
  signature_gps_lat         NUMERIC(10,7),
  signature_gps_lng         NUMERIC(10,7),
  customer_acceptance       BOOLEAN,
  discrepancy_details       TEXT,
  contact_outcome           VARCHAR(50),
  otp_verification_id       UUID            REFERENCES otp_verifications(id),
  secure_link_token         VARCHAR(255),
  secure_link_expires_at    TIMESTAMPTZ,
  dbp_push_status           VARCHAR(20)     NOT NULL DEFAULT 'PENDING'
                              CHECK (dbp_push_status IN ('PENDING','PUSHED','FAILED','SKIPPED')),
  dbp_pushed_at             TIMESTAMPTZ,
  smart_eye_push_status     VARCHAR(20)     NOT NULL DEFAULT 'PENDING'
                              CHECK (smart_eye_push_status IN ('PENDING','PUSHED','FAILED','SKIPPED')),
  smart_eye_pushed_at       TIMESTAMPTZ,
  is_finalised              BOOLEAN         NOT NULL DEFAULT FALSE,
  finalised_at              TIMESTAMPTZ,
  parent_report_id          UUID            REFERENCES vehicle_condition_reports(id),
  amendment_reason          TEXT,
  amended_by_user           VARCHAR(100),
  is_deleted                BOOLEAN         NOT NULL DEFAULT FALSE,
  version                   INTEGER         NOT NULL DEFAULT 1,
  created_at                TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
  updated_at                TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE  vehicle_condition_reports                   IS 'Pickup or drop condition capture record holding registration number, vehicle name, odometer reading, fuel/SOC levels, inventory checklist, vehicle issues, voice recording reference, supporting images/videos, final remarks, and customer signature.';
COMMENT ON COLUMN vehicle_condition_reports.report_type       IS 'PICKUP = initial pickup handover; DROP_PRE_DEPARTURE = images before drop trip starts; DROP_DELIVERY = delivery condition at drop address.';
COMMENT ON COLUMN vehicle_condition_reports.session_id        IS 'Unique session identifier for the condition capture workflow session.';
COMMENT ON COLUMN vehicle_condition_reports.odometer_anomaly_flag IS 'Set TRUE when submitted odometer reading is lower than last recorded value.';
COMMENT ON COLUMN vehicle_condition_reports.inventory_checklist   IS 'JSONB map of standard checklist items to boolean present/absent values.';
COMMENT ON COLUMN vehicle_condition_reports.inventory_custom_items IS 'JSON array of manually added custom item descriptions.';
COMMENT ON COLUMN vehicle_condition_reports.secure_link_token IS 'Token used to generate the time-limited secure read-only link shared with the customer.';
COMMENT ON COLUMN vehicle_condition_reports.parent_report_id  IS 'References the original report when this record is a post-signature amendment version.';
COMMENT ON COLUMN vehicle_condition_reports.is_finalised      IS 'Set TRUE once customer signature is captured; record becomes immutable after this point.';

CREATE INDEX idx_vcr_appointment_id    ON vehicle_condition_reports (appointment_id);
CREATE INDEX idx_vcr_trip_id           ON vehicle_condition_reports (trip_id);
CREATE INDEX idx_vcr_chauffeur_id      ON vehicle_condition_reports (chauffeur_id);
CREATE INDEX idx_vcr_vehicle_id        ON vehicle_condition_reports (vehicle_id);
CREATE INDEX idx_vcr_jc_number         ON vehicle_condition_reports (jc_number) WHERE jc_number IS NOT NULL;
CREATE INDEX idx_vcr_registration      ON vehicle_condition_reports (registration_number);
CREATE INDEX idx_vcr_report_type       ON vehicle_condition_reports (report_type);
CREATE INDEX idx_vcr_is_finalised      ON vehicle_condition_reports (is_finalised);
CREATE INDEX idx_vcr_session_id        ON vehicle_condition_reports (session_id);
CREATE INDEX idx_vcr_created_at        ON vehicle_condition_reports (created_at DESC);

CREATE TRIGGER trg_vcr_updated_at
  BEFORE UPDATE ON vehicle_condition_reports
  FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();

-- =============================================================================
-- TABLE: vehicle_condition_issues
-- =============================================================================

CREATE TABLE vehicle_condition_issues (
  id                  UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
  report_id           UUID            NOT NULL REFERENCES vehicle_condition_reports(id),
  issue_sequence      SMALLINT        NOT NULL DEFAULT 1,
  issue_text          TEXT,
  voice_recording_ref TEXT,
  is_deleted          BOOLEAN         NOT NULL DEFAULT FALSE,
  version             INTEGER         NOT NULL DEFAULT 1,
  created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
  updated_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE  vehicle_condition_issues               IS 'Individual vehicle issue entries captured iteratively during the condition report session; each row represents one concern raised by the customer.';
COMMENT ON COLUMN vehicle_condition_issues.issue_sequence IS 'Order in which the issue was captured within the session.';
COMMENT ON COLUMN vehicle_condition_issues.voice_recording_ref IS 'Reference to the voice recording stored in the media object store.';

CREATE INDEX idx_vci_report_id ON vehicle_condition_issues (report_id);

CREATE TRIGGER trg_vehicle_condition_issues_updated_at
  BEFORE UPDATE ON vehicle_condition_issues
  FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();

-- =============================================================================
-- TABLE: vehicle_media_assets (PostgreSQL reference table)
-- =============================================================================

CREATE TABLE vehicle_media_assets (
  id                  UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
  report_id           UUID            REFERENCES vehicle_condition_reports(id),
  trip_id             UUID            REFERENCES trips(id),
  appointment_id      UUID            REFERENCES appointments(id),
  asset_type          VARCHAR(30)     NOT NULL
                        CHECK (asset_type IN (
                          'EXTERIOR_IMAGE','INTERIOR_IMAGE','ADDITIONAL_IMAGE',
                          'VIDEO','VOICE_RECORDING','SIGNATURE'
                        )),
  capture_phase       VARCHAR(30)     NOT NULL
                        CHECK (capture_phase IN (
                          'PICKUP_HANDOVER','DROP_PRE_DEPARTURE','DROP_DELIVERY'
                        )),
  storage_url         TEXT            NOT NULL,
  storage_bucket      VARCHAR(100),
  file_name           VARCHAR(255),
  mime_type           VARCHAR(100),
  file_size_bytes     BIGINT,
  checksum_sha256     VARCHAR(64),
  is_mandatory        BOOLEAN         NOT NULL DEFAULT FALSE,
  dbp_forwarded       BOOLEAN         NOT NULL DEFAULT FALSE,
  dbp_forwarded_at    TIMESTAMPTZ,
  smart_eye_forwarded BOOLEAN         NOT NULL DEFAULT FALSE,
  smart_eye_forwarded_at TIMESTAMPTZ,
  captured_at         TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
  captured_gps_lat    NUMERIC(10,7),
  captured_gps_lng    NUMERIC(10,7),
  is_deleted          BOOLEAN         NOT NULL DEFAULT FALSE,
  version             INTEGER         NOT NULL DEFAULT 1,
  created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
  updated_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE  vehicle_media_assets              IS 'Reference table for vehicle images, videos, and voice recordings captured during pickup and drop condition capture sessions.';
COMMENT ON COLUMN vehicle_media_assets.asset_type   IS 'Classification of the media asset.';
COMMENT ON COLUMN vehicle_media_assets.capture_phase IS 'Phase of the service workflow during which the asset was captured.';
COMMENT ON COLUMN vehicle_media_assets.storage_url  IS 'Encrypted object store URL; pre-signed time-limited URLs are generated at access time.';
COMMENT ON COLUMN vehicle_media_assets.checksum_sha256 IS 'SHA-256 checksum of the file for tamper-evidence verification.';

CREATE INDEX idx_vma_report_id    ON vehicle_media_assets (report_id);
CREATE INDEX idx_vma_trip_id      ON vehicle_media_assets (trip_id);
CREATE INDEX idx_vma_appointment_id ON vehicle_media_assets (appointment_id);
CREATE INDEX idx_vma_asset_type   ON vehicle_media_assets (asset_type);
CREATE INDEX idx_vma_capture_phase ON vehicle_media_assets (capture_phase);

CREATE TRIGGER trg_vehicle_media_assets_updated_at
  BEFORE UPDATE ON vehicle_media_assets
  FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();

-- =============================================================================
-- TABLE: notifications
-- =============================================================================

CREATE TABLE notifications (
  id                  UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
  appointment_id      UUID            REFERENCES appointments(id) ON DELETE SET NULL,
  trip_id             UUID            REFERENCES trips(id) ON DELETE SET NULL,
  jc_number           VARCHAR(50),
  recipient_type      VARCHAR(20)     NOT NULL
                        CHECK (recipient_type IN ('customer','chauffeur','coordinator')),
  recipient_ref       VARCHAR(100)    NOT NULL,
  channel             VARCHAR(20)     NOT NULL
                        CHECK (channel IN ('ICP','WhatsApp','SMS','DBP','CRM')),
  message_type        VARCHAR(80)     NOT NULL,
  message_body        TEXT,
  delivery_status     VARCHAR(20)     NOT NULL DEFAULT 'pending'
                        CHECK (delivery_status IN (
                          'pending','sent','delivered','failed','retrying'
                        )),
  sent_at             TIMESTAMPTZ,
  delivered_at        TIMESTAMPTZ,
  retry_count         SMALLINT        NOT NULL DEFAULT 0,
  last_retry_at       TIMESTAMPTZ,
  failure_reason      TEXT,
  external_message_id VARCHAR(200),
  is_deleted          BOOLEAN         NOT NULL DEFAULT FALSE,
  version             INTEGER         NOT NULL DEFAULT 1,
  created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
  updated_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE  notifications                     IS 'Outbound communication records for all channels (ICP, WhatsApp, SMS, DBP, CRM) sent to customers, chauffeurs, and coordinators.';
COMMENT ON COLUMN notifications.recipient_type      IS 'Target audience: customer, chauffeur, or coordinator.';
COMMENT ON COLUMN notifications.recipient_ref       IS 'Masked phone number, user ID, or system identifier of the recipient.';
COMMENT ON COLUMN notifications.channel             IS 'Delivery channel: ICP, WhatsApp, SMS, DBP, or CRM.';
COMMENT ON COLUMN notifications.message_type        IS 'Logical event label, e.g. CHAUFFEUR_ASSIGNED, ARRIVAL_ALERT, PICKUP_COMPLETE, DROP_SCHEDULED.';
COMMENT ON COLUMN notifications.delivery_status     IS 'Lifecycle state of the outbound message.';
COMMENT ON COLUMN notifications.external_message_id IS 'Message ID returned by the downstream channel provider for correlation and delivery tracking.';
COMMENT ON COLUMN notifications.retry_count         IS 'Number of send attempts made after the initial attempt.';

CREATE INDEX idx_notifications_appointment_id  ON notifications (appointment_id);
CREATE INDEX idx_notifications_trip_id         ON notifications (trip_id);
CREATE INDEX idx_notifications_recipient_type  ON notifications (recipient_type);
CREATE INDEX idx_notifications_channel         ON notifications (channel);
CREATE INDEX idx_notifications_delivery_status ON notifications (delivery_status);
CREATE INDEX idx_notifications_sent_at         ON notifications (sent_at DESC);
CREATE INDEX idx_notifications_jc_number       ON notifications (jc_number) WHERE jc_number IS NOT NULL;

CREATE TRIGGER trg_notifications_updated_at
  BEFORE UPDATE ON notifications
  FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();

-- =============================================================================
-- TABLE: chauffeur_availability
-- =============================================================================

CREATE TABLE chauffeur_availability (
  id                  UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
  chauffeur_id        UUID            NOT NULL REFERENCES chauffeurs(id),
  availability_date   DATE            NOT NULL,
  is_available        BOOLEAN         NOT NULL DEFAULT TRUE,
  available_from      TIME,
  available_to        TIME,
  unavailability_reason VARCHAR(100),
  source              VARCHAR(30)     NOT NULL DEFAULT 'SELF_MANAGED'
                        CHECK (source IN ('SELF_MANAGED','SYSTEM','COORDINATOR_OVERRIDE')),
  is_deleted          BOOLEAN         NOT NULL DEFAULT FALSE,
  version             INTEGER         NOT NULL DEFAULT 1,
  created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
  updated_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
  CONSTRAINT uq_chauffeur_availability UNIQUE (chauffeur_id, availability_date)
);

COMMENT ON TABLE  chauffeur_availability                  IS 'Daily availability records for each chauffeur, supporting the recommendation engine and schedule management.';
COMMENT ON COLUMN chauffeur_availability.source           IS 'Whether availability was set by the chauffeur, system, or coordinator override.';
COMMENT ON COLUMN chauffeur_availability.unavailability_reason IS 'Reason for unavailability when is_available is FALSE.';

CREATE INDEX idx_chauffeur_availability_chauffeur_id    ON chauffeur_availability (chauffeur_id);
CREATE INDEX idx_chauffeur_availability_date            ON chauffeur_availability (availability_date);
CREATE INDEX idx_chauffeur_availability_is_available    ON chauffeur_availability (is_available);

CREATE TRIGGER trg_chauffeur_availability_updated_at
  BEFORE UPDATE ON chauffeur_availability
  FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();

-- =============================================================================
-- TABLE: delay_alerts
-- =============================================================================

CREATE TABLE delay_alerts (
  id                    UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
  trip_id               UUID            NOT NULL REFERENCES trips(id),
  appointment_id        UUID            NOT NULL REFERENCES appointments(id),
  alert_type            VARCHAR(30)     NOT NULL
                          CHECK (alert_type IN (
                            'PRE_PICKUP_DELAY','TRANSIT_DELAY','DROP_TRIP_DELAY'
                          )),
  detected_at           TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
  delay_duration_mins   INTEGER         NOT NULL,
  original_eta          TIMESTAMPTZ     NOT NULL,
  revised_eta           TIMESTAMPTZ     NOT NULL,
  delay_reason          TEXT,
  coordinator_alerted   BOOLEAN         NOT NULL DEFAULT FALSE,
  coordinator_alerted_at TIMESTAMPTZ,
  resolution_status     VARCHAR(20)     NOT NULL DEFAULT 'OPEN'
                          CHECK (resolution_status IN (
                            'OPEN','ACKNOWLEDGED','RESOLVED','ESCALATED'
                          )),
  resolved_by_user      VARCHAR(100),
  resolved_at           TIMESTAMPTZ,
  is_deleted            BOOLEAN         NOT NULL DEFAULT FALSE,
  version               INTEGER         NOT NULL DEFAULT 1,
  created_at            TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
  updated_at            TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE  delay_alerts                      IS 'Records of delay detection events raised by the DelayDetectionSchedulerService for pickup, transit, and drop trips.';
COMMENT ON COLUMN delay_alerts.alert_type           IS 'Phase of the journey during which the delay was detected.';
COMMENT ON COLUMN delay_alerts.delay_duration_mins  IS 'Computed delay in minutes at the time of detection.';
COMMENT ON COLUMN delay_alerts.resolution_status    IS 'Current state of the alert: OPEN, ACKNOWLEDGED, RESOLVED, or ESCALATED.';

CREATE INDEX idx_delay_alerts_trip_id        ON delay_alerts (trip_id);
CREATE INDEX idx_delay_alerts_appointment_id ON delay_alerts (appointment_id);
CREATE INDEX idx_delay_alerts_alert_type     ON delay_alerts (alert_type);
CREATE INDEX idx_delay_alerts_resolution     ON delay_alerts (resolution_status);
CREATE INDEX idx_delay_alerts_detected_at    ON delay_alerts (detected_at DESC);

CREATE TRIGGER trg_delay_alerts_updated_at
  BEFORE UPDATE ON delay_alerts
  FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();

-- =============================================================================
-- TABLE: crm_integration_log
-- =============================================================================

CREATE TABLE crm_integration_log (
  id                  UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
  correlation_id      VARCHAR(100)    NOT NULL,
  operation_type      VARCHAR(50)     NOT NULL
                        CHECK (operation_type IN (
                          'FETCH_APPOINTMENT','PUSH_ASSIGNMENT','UPDATE_ASSIGNMENT_STATUS',
                          'FETCH_DROP_REQUEST','FETCH_JC','PUSH_RESCHEDULE',
                          'PUSH_CANCELLATION','PUSH_TRIP_STATUS','INBOUND_WEBHOOK'
                        )),
  appointment_number  VARCHAR(50),
  jc_number           VARCHAR(50),
  http_method         VARCHAR(10),
  endpoint_url        TEXT,
  request_payload_hash VARCHAR(64),
  response_status_code INTEGER,
  response_payload_hash VARCHAR(64),
  latency_ms          INTEGER,
  is_success          BOOLEAN         NOT NULL DEFAULT FALSE,
  error_message       TEXT,
  retry_attempt       SMALLINT        NOT NULL DEFAULT 0,
  circuit_breaker_state VARCHAR(20)
                        CHECK (circuit_breaker_state IN ('CLOSED','OPEN','HALF_OPEN')),
  is_deleted          BOOLEAN         NOT NULL DEFAULT FALSE,
  created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE  crm_integration_log                IS 'Audit log of all CRM API request/response pairs with timestamps, correlation IDs, HTTP status codes, and payload hashes.';
COMMENT ON COLUMN crm_integration_log.correlation_id IS 'Distributed trace correlation ID linking this log entry to the originating service call.';
COMMENT ON COLUMN crm_integration_log.request_payload_hash  IS 'SHA-256 hash of the outbound request payload for tamper-evidence; full payload not stored.';
COMMENT ON COLUMN crm_integration_log.response_payload_hash IS 'SHA-256 hash of the inbound response payload.';
COMMENT ON COLUMN crm_integration_log.circuit_breaker_state IS 'State of the CRM circuit breaker at the time of this call.';

CREATE INDEX idx_crm_log_correlation_id    ON crm_integration_log (correlation_id);
CREATE INDEX idx_crm_log_appointment_number ON crm_integration_log (appointment_number) WHERE appointment_number IS NOT NULL;
CREATE INDEX idx_crm_log_operation_type    ON crm_integration_log (operation_type);
CREATE INDEX idx_crm_log_created_at        ON crm_integration_log (created_at DESC);
CREATE INDEX idx_crm_log_is_success        ON crm_integration_log (is_success);

-- =============================================================================
-- TABLE: dbp_integration_log
-- =============================================================================

CREATE TABLE dbp_integration_log (
  id                  UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
  correlation_id      VARCHAR(100)    NOT NULL,
  operation_type      VARCHAR(50)     NOT NULL
                        CHECK (operation_type IN (
                          'PUSH_CONDITION_REPORT','PUSH_SMART_EYE_IMAGES',
                          'FETCH_JC_DETAILS','PUSH_DROP_REQUEST',
                          'FETCH_DROP_REQUEST_STATUS','INBOUND_JC_STATUS_WEBHOOK'
                        )),
  appointment_number  VARCHAR(50),
  jc_number           VARCHAR(50),
  http_method         VARCHAR(10),
  endpoint_url        TEXT,
  request_payload_hash VARCHAR(64),
  response_status_code INTEGER,
  response_payload_hash VARCHAR(64),
  latency_ms          INTEGER,
  is_success          BOOLEAN         NOT NULL DEFAULT FALSE,
  error_message       TEXT,
  retry_attempt       SMALLINT        NOT NULL DEFAULT 0,
  circuit_breaker_state VARCHAR(20)
                        CHECK (circuit_breaker_state IN ('CLOSED','OPEN','HALF_OPEN')),
  is_deleted          BOOLEAN         NOT NULL DEFAULT FALSE,
  created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE  dbp_integration_log                IS 'Audit log of all DBP API request/response pairs with timestamps, correlation IDs, HTTP status codes, and payload hashes.';
COMMENT ON COLUMN dbp_integration_log.correlation_id IS 'Distributed trace correlation ID linking this log entry to the originating service call.';

CREATE INDEX idx_dbp_log_correlation_id    ON dbp_integration_log (correlation_id);
CREATE INDEX idx_dbp_log_jc_number         ON dbp_integration_log (jc_number) WHERE jc_number IS NOT NULL;
CREATE INDEX idx_dbp_log_operation_type    ON dbp_integration_log (operation_type);
CREATE INDEX idx_dbp_log_created_at        ON dbp_integration_log (created_at DESC);
CREATE INDEX idx_dbp_log_is_success        ON dbp_integration_log (is_success);

-- =============================================================================
-- TABLE: map_api_log
-- =============================================================================

CREATE TABLE map_api_log (
  id                      UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
  correlation_id          VARCHAR(100)    NOT NULL,
  operation_type          VARCHAR(50)     NOT NULL
                            CHECK (operation_type IN (
                              'ETA_CALCULATION','BULK_ETA','SUGGESTED_START_TIME',
                              'LIVE_ETA','GEOFENCE_CHECK','ROUTE_FETCH','DEALERSHIP_ETA'
                            )),
  trip_id                 UUID            REFERENCES trips(id),
  appointment_id          UUID            REFERENCES appointments(id),
  origin_lat              NUMERIC(10,7),
  origin_lng              NUMERIC(10,7),
  destination_lat         NUMERIC(10,7),
  destination_lng         NUMERIC(10,7),
  travel_time_minutes     INTEGER,
  distance_km             NUMERIC(8,3),
  suggested_start_time    TIMESTAMPTZ,
  response_status_code    INTEGER,
  latency_ms              INTEGER,
  is_cache_hit            BOOLEAN         NOT NULL DEFAULT FALSE,
  is_success              BOOLEAN         NOT NULL DEFAULT FALSE,
  error_message           TEXT,
  circuit_breaker_state   VARCHAR(20)
                            CHECK (circuit_breaker_state IN ('CLOSED','OPEN','HALF_OPEN')),
  is_deleted              BOOLEAN         NOT NULL DEFAULT FALSE,
  created_at              TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE  map_api_log                  IS 'Log of all Map API requests and responses, including latency, status codes, and error details for operational monitoring and SLA tracking.';
COMMENT ON COLUMN map_api_log.is_cache_hit     IS 'TRUE when the result was served from the Redis ETA cache rather than a live Map API call.';
COMMENT ON COLUMN map_api_log.operation_type   IS 'Type of Map API operation performed.';

CREATE INDEX idx_map_api_log_trip_id        ON map_api_log (trip_id) WHERE trip_id IS NOT NULL;
CREATE INDEX idx_map_api_log_appointment_id ON map_api_log (appointment_id) WHERE appointment_id IS NOT NULL;
CREATE INDEX idx_map_api_log_operation_type ON map_api_log (operation_type);
CREATE INDEX idx_map_api_log_created_at     ON map_api_log (created_at DESC);

-- =============================================================================
-- TABLE: audit_events
-- =============================================================================

CREATE TABLE audit_events (
  id                  UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
  sequence_number     BIGSERIAL       NOT NULL,
  entity_type         VARCHAR(60)     NOT NULL
                        CHECK (entity_type IN (
                          'APPOINTMENT','ASSIGNMENT','TRIP','VEHICLE_CONDITION_REPORT',
                          'OTP_VERIFICATION','RESCHEDULING_RECORD','CANCELLATION_RECORD',
                          'DROP_REQUEST','CONTACT_ATTEMPT_LOG','CHAUFFEUR','VEHICLE',
                          'NOTIFICATION','DELAY_ALERT'
                        )),
  entity_id           VARCHAR(100)    NOT NULL,
  appointment_number  VARCHAR(50),
  jc_number           VARCHAR(50),
  trip_id             VARCHAR(100),
  chauffeur_id        VARCHAR(100),
  actor_type          VARCHAR(30)     NOT NULL
                        CHECK (actor_type IN (
                          'PICKUP_COORDINATOR','CHAUFFEUR','CUSTOMER','SYSTEM'
                        )),
  actor_id            VARCHAR(100)    NOT NULL,
  action_type         VARCHAR(80)     NOT NULL,
  previous_state      JSONB,
  new_state           JSONB,
  changed_fields      JSONB,
  activity_ref        VARCHAR(50),
  override_flag       BOOLEAN         NOT NULL DEFAULT FALSE,
  override_reason     TEXT,
  event_timestamp     TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
  previous_hash       VARCHAR(64),
  event_hash          VARCHAR(64)     NOT NULL,
  is_deleted          BOOLEAN         NOT NULL DEFAULT FALSE,
  created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE  audit_events                    IS 'Immutable append-only audit log for all entity state transitions, override events, OTP events, and system actions across the MSIL pickup and drop service.';
COMMENT ON COLUMN audit_events.sequence_number    IS 'Monotonically increasing sequence number for tamper-evidence ordering.';
COMMENT ON COLUMN audit_events.entity_type        IS 'Type of domain entity that was modified.';
COMMENT ON COLUMN audit_events.entity_id          IS 'UUID or natural key of the entity that was modified.';
COMMENT ON COLUMN audit_events.actor_type         IS 'Role of the actor who performed the action.';
COMMENT ON COLUMN audit_events.action_type        IS 'Descriptive label of the action performed, e.g. APPOINTMENT_CREATED, CHAUFFEUR_ACCEPTED, OTP_VERIFIED.';
COMMENT ON COLUMN audit_events.override_flag      IS 'Set TRUE when the event represents a controlled override action.';
COMMENT ON COLUMN audit_events.previous_hash      IS 'SHA-256 hash of the previous audit event record to form a tamper-evident hash chain.';
COMMENT ON COLUMN audit_events.event_hash         IS 'SHA-256 hash of this event record content for tamper-evidence verification.';
COMMENT ON COLUMN audit_events.activity_ref       IS 'Reference to the business activity ID (e.g. SER-010-020-007) that triggered this event.';

CREATE UNIQUE INDEX idx_audit_events_sequence_number ON audit_events (sequence_number);
CREATE INDEX idx_audit_events_entity_type            ON audit_events (entity_type);
CREATE INDEX idx_audit_events_entity_id              ON audit_events (entity_id);
CREATE INDEX idx_audit_events_appointment_number     ON audit_events (appointment_number) WHERE appointment_number IS NOT NULL;
CREATE INDEX idx_audit_events_jc_number              ON audit_events (jc_number) WHERE jc_number IS NOT NULL;
CREATE INDEX idx_audit_events_trip_id                ON audit_events (trip_id) WHERE trip_id IS NOT NULL;
CREATE INDEX idx_audit_events_chauffeur_id           ON audit_events (chauffeur_id) WHERE chauffeur_id IS NOT NULL;
CREATE INDEX idx_audit_events_actor_id               ON audit_events (actor_id);
CREATE INDEX idx_audit_events_action_type            ON audit_events (action_type);
CREATE INDEX idx_audit_events_event_timestamp        ON audit_events (event_timestamp DESC);
CREATE INDEX idx_audit_events_override_flag          ON audit_events (override_flag) WHERE override_flag = TRUE;

-- =============================================================================
-- TABLE: trip_qr_summaries
-- =============================================================================

CREATE TABLE trip_qr_summaries (
  id                    UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
  trip_id               UUID            NOT NULL REFERENCES trips(id),
  appointment_id        UUID            NOT NULL REFERENCES appointments(id),
  registration_number   VARCHAR(20)     NOT NULL,
  vehicle_name          VARCHAR(150),
  chauffeur_id          UUID            REFERENCES chauffeurs(id),
  pickup_date_time      TIMESTAMPTZ     NOT NULL,
  drop_location         TEXT,
  qr_code_data          TEXT            NOT NULL,
  qr_code_image_ref     TEXT,
  generated_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
  is_deleted            BOOLEAN         NOT NULL DEFAULT FALSE,
  version               INTEGER         NOT NULL DEFAULT 1,
  created_at            TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
  updated_at            TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE  trip_qr_summaries              IS 'QR-coded trip summary cards generated after pickup handover completion, embedding appointment number, vehicle registration, chauffeur identity, and pickup timestamp.';
COMMENT ON COLUMN trip_qr_summaries.qr_code_data IS 'Encoded payload embedded in the QR code (appointment number, vehicle registration, chauffeur identity, pickup timestamp).';
COMMENT ON COLUMN trip_qr_summaries.qr_code_image_ref IS 'Reference to the generated QR code image stored in the media object store.';

CREATE INDEX idx_trip_qr_summaries_trip_id        ON trip_qr_summaries (trip_id);
CREATE INDEX idx_trip_qr_summaries_appointment_id ON trip_qr_summaries (appointment_id);

CREATE TRIGGER trg_trip_qr_summaries_updated_at
  BEFORE UPDATE ON trip_qr_summaries
  FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();

-- =============================================================================
-- TABLE: assignment_timeout_events
-- =============================================================================

CREATE TABLE assignment_timeout_events (
  id                  UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
  assignment_id       UUID            NOT NULL REFERENCES assignments(id),
  appointment_id      UUID            NOT NULL REFERENCES appointments(id),
  chauffeur_id        UUID            NOT NULL REFERENCES chauffeurs(id),
  dispatched_at       TIMESTAMPTZ     NOT NULL,
  timeout_detected_at TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
  timeout_duration_secs INTEGER       NOT NULL,
  coordinator_notified BOOLEAN        NOT NULL DEFAULT FALSE,
  coordinator_notified_at TIMESTAMPTZ,
  reassignment_triggered BOOLEAN      NOT NULL DEFAULT FALSE,
  is_deleted          BOOLEAN         NOT NULL DEFAULT FALSE,
  version             INTEGER         NOT NULL DEFAULT 1,
  created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
  updated_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE  assignment_timeout_events                    IS 'Records of assignment request timeout events detected by the DelayDetectionSchedulerService when a chauffeur does not respond within the configured SLA window.';
COMMENT ON COLUMN assignment_timeout_events.timeout_duration_secs IS 'Duration in seconds between dispatch and timeout detection.';

CREATE INDEX idx_assignment_timeout_assignment_id  ON assignment_timeout_events (assignment_id);
CREATE INDEX idx_assignment_timeout_appointment_id ON assignment_timeout_events (appointment_id);
CREATE INDEX idx_assignment_timeout_chauffeur_id   ON assignment_timeout_events (chauffeur_id);
CREATE INDEX idx_assignment_timeout_detected_at    ON assignment_timeout_events (timeout_detected_at DESC);

CREATE TRIGGER trg_assignment_timeout_events_updated_at
  BEFORE UPDATE ON assignment_timeout_events
  FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();

-- =============================================================================
-- TABLE: handover_refusal_events
-- =============================================================================

CREATE TABLE handover_refusal_events (
  id                    UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
  appointment_id        UUID            NOT NULL REFERENCES appointments(id),
  trip_id               UUID            NOT NULL REFERENCES trips(id),
  chauffeur_id          UUID            NOT NULL REFERENCES chauffeurs(id),
  registration_number   VARCHAR(20)     NOT NULL,
  vehicle_name          VARCHAR(150),
  refusal_reason        TEXT            NOT NULL,
  refusal_gps_lat       NUMERIC(10,7),
  refusal_gps_lng       NUMERIC(10,7),
  refusal_recorded_at   TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
  coordinator_notified  BOOLEAN         NOT NULL DEFAULT FALSE,
  coordinator_notified_at TIMESTAMPTZ,
  resolution_action     VARCHAR(20)
                          CHECK (resolution_action IN ('RESCHEDULE','CANCEL','PENDING')),
  contact_attempt_log_id UUID           REFERENCES contact_attempt_logs(id),
  cancellation_record_id UUID           REFERENCES cancellation_records(id),
  rescheduling_record_id UUID           REFERENCES rescheduling_records(id),
  is_deleted            BOOLEAN         NOT NULL DEFAULT FALSE,
  version               INTEGER         NOT NULL DEFAULT 1,
  created_at            TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
  updated_at            TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE  handover_refusal_events                  IS 'Records of customer handover refusal events logged by the Chauffeur app at the pickup location.';
COMMENT ON COLUMN handover_refusal_events.refusal_reason   IS 'Reason provided by the customer for refusing vehicle handover.';
COMMENT ON COLUMN handover_refusal_events.resolution_action IS 'Coordinator decision following the refusal: RESCHEDULE, CANCEL, or PENDING.';

CREATE INDEX idx_handover_refusal_appointment_id ON handover_refusal_events (appointment_id);
CREATE INDEX idx_handover_refusal_trip_id        ON handover_refusal_events (trip_id);
CREATE INDEX idx_handover_refusal_chauffeur_id   ON handover_refusal_events (chauffeur_id);
CREATE INDEX idx_handover_refusal_recorded_at    ON handover_refusal_events (refusal_recorded_at DESC);

CREATE TRIGGER trg_handover_refusal_events_updated_at
  BEFORE UPDATE ON handover_refusal_events
  FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();

-- =============================================================================
-- TABLE: drop_delivery_events
-- =============================================================================

CREATE TABLE drop_delivery_events (
  id                      UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
  trip_id                 UUID            NOT NULL REFERENCES trips(id),
  appointment_id          UUID            NOT NULL REFERENCES appointments(id),
  drop_request_id         UUID            NOT NULL REFERENCES drop_requests(id),
  chauffeur_id            UUID            NOT NULL REFERENCES chauffeurs(id),
  arrived_at_drop_at      TIMESTAMPTZ,
  contact_outcome         VARCHAR(50),
  customer_acceptance     BOOLEAN,
  discrepancy_details     TEXT,
  otp_verification_id     UUID            REFERENCES otp_verifications(id),
  customer_signature_ref  TEXT,
  signature_captured_at   TIMESTAMPTZ,
  delivery_completed_at   TIMESTAMPTZ,
  delivery_gps_lat        NUMERIC(10,7),
  delivery_gps_lng        NUMERIC(10,7),
  is_deleted              BOOLEAN         NOT NULL DEFAULT FALSE,
  version                 INTEGER         NOT NULL DEFAULT 1,
  created_at              TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
  updated_at              TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE  drop_delivery_events                      IS 'Records of drop delivery completion events including customer acceptance, discrepancy details, OTP verification, and customer signature.';
COMMENT ON COLUMN drop_delivery_events.customer_acceptance  IS 'TRUE when the customer accepted the vehicle at the drop address without dispute.';
COMMENT ON COLUMN drop_delivery_events.discrepancy_details  IS 'Details of any discrepancy reported by the customer at the time of drop delivery.';

CREATE INDEX idx_drop_delivery_trip_id        ON drop_delivery_events (trip_id);
CREATE INDEX idx_drop_delivery_appointment_id ON drop_delivery_events (appointment_id);
CREATE INDEX idx_drop_delivery_drop_request_id ON drop_delivery_events (drop_request_id);
CREATE INDEX idx_drop_delivery_chauffeur_id   ON drop_delivery_events (chauffeur_id);

CREATE TRIGGER trg_drop_delivery_events_updated_at
  BEFORE UPDATE ON drop_delivery_events
  FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();

-- =============================================================================
-- TABLE: scheduler_run_log
-- =============================================================================

CREATE TABLE scheduler_run_log (
  id                      UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
  job_name                VARCHAR(100)    NOT NULL,
  run_started_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
  run_completed_at        TIMESTAMPTZ,
  run_status              VARCHAR(20)     NOT NULL DEFAULT 'RUNNING'
                            CHECK (run_status IN ('RUNNING','COMPLETED','FAILED','PARTIAL')),
  trips_evaluated         INTEGER         NOT NULL DEFAULT 0,
  delay_alerts_raised     INTEGER         NOT NULL DEFAULT 0,
  timeouts_detected       INTEGER         NOT NULL DEFAULT 0,
  start_times_pushed      INTEGER         NOT NULL DEFAULT 0,
  error_message           TEXT,
  is_deleted              BOOLEAN         NOT NULL DEFAULT FALSE,
  created_at              TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE  scheduler_run_log                IS 'Heartbeat and execution log for the DelayDetectionSchedulerService batch job runs.';
COMMENT ON COLUMN scheduler_run_log.job_name       IS 'Name of the scheduler job that was executed.';
COMMENT ON COLUMN scheduler_run_log.run_status     IS 'Outcome of the scheduler run: RUNNING, COMPLETED, FAILED, or PARTIAL.';
COMMENT ON COLUMN scheduler_run_log.trips_evaluated IS 'Number of active trips evaluated during this run.';

CREATE INDEX idx_scheduler_run_log_job_name    ON scheduler_run_log (job_name);
CREATE INDEX idx_scheduler_run_log_started_at  ON scheduler_run_log (run_started_at DESC);
CREATE INDEX idx_scheduler_run_log_run_status  ON scheduler_run_log (run_status);

-- =============================================================================
-- TABLE: outbox_events (Transactional Outbox for Domain Events)
-- =============================================================================

CREATE TABLE outbox_events (
  id                  UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
  aggregate_type      VARCHAR(60)     NOT NULL,
  aggregate_id        VARCHAR(100)    NOT NULL,
  event_type          VARCHAR(100)    NOT NULL,
  payload             JSONB           NOT NULL,
  correlation_id      VARCHAR(100),
  published           BOOLEAN         NOT NULL DEFAULT FALSE,
  published_at        TIMESTAMPTZ,
  retry_count         SMALLINT        NOT NULL DEFAULT 0,
  last_error          TEXT,
  created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE  outbox_events              IS 'Transactional outbox table for reliable domain event publishing; events are written in the same transaction as the entity change and polled by the event relay process.';
COMMENT ON COLUMN outbox_events.aggregate_type IS 'Domain aggregate type that produced the event, e.g. Appointment, Trip, Assignment.';
COMMENT ON COLUMN outbox_events.event_type   IS 'Domain event name, e.g. AppointmentCreated, PickupCompleted, DropCompleted.';
COMMENT ON COLUMN outbox_events.published    IS 'Set TRUE once the event has been successfully published to the event bus.';

CREATE INDEX idx_outbox_events_unpublished   ON outbox_events (created_at ASC) WHERE published = FALSE;
CREATE INDEX idx_outbox_events_aggregate_id  ON outbox_events (aggregate_id);
CREATE INDEX idx_outbox_events_event_type    ON outbox_events (event_type);

-- =============================================================================
-- TABLE: idempotency_keys (Exactly-Once Delivery for CRM/DBP Writes)
-- =============================================================================

CREATE TABLE idempotency_keys (
  id                  UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
  idempotency_key     VARCHAR(200)    NOT NULL,
  service_name        VARCHAR(100)    NOT NULL,
  operation_type      VARCHAR(100)    NOT NULL,
  entity_id           VARCHAR(100),
  response_status     INTEGER,
  response_body_hash  VARCHAR(64),
  created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
  expires_at          TIMESTAMPTZ     NOT NULL,
  CONSTRAINT uq_idempotency_key UNIQUE (idempotency_key, service_name)
);

COMMENT ON TABLE  idempotency_keys                IS 'Idempotency log for all CRM and DBP write operations to guarantee exactly-once delivery and support replay on transient failures.';
COMMENT ON COLUMN idempotency_keys.idempotency_key IS 'Client-generated unique key for the operation, typically a UUID derived from the entity ID and operation type.';
COMMENT ON COLUMN idempotency_keys.expires_at      IS 'Timestamp after which the idempotency record may be purged.';

CREATE INDEX idx_idempotency_keys_key         ON idempotency_keys (idempotency_key);
CREATE INDEX idx_idempotency_keys_expires_at  ON idempotency_keys (expires_at);

-- =============================================================================
-- FOREIGN KEY: drop_requests -> cancellation_records (deferred to avoid circular)
-- =============================================================================

ALTER TABLE drop_requests
  ADD CONSTRAINT fk_drop_requests_cancellation_record
  FOREIGN KEY (cancellation_record_id) REFERENCES cancellation_records(id);

-- =============================================================================
-- FOREIGN KEY: cancellation_records -> contact_attempt_logs (deferred to avoid circular)
-- =============================================================================

ALTER TABLE cancellation_records
  ADD CONSTRAINT fk_cancellation_records_contact_attempt_log
  FOREIGN KEY (contact_attempt_log_id) REFERENCES contact_attempt_logs(id);

-- =============================================================================
-- END OF SCRIPT
-- =============================================================================
# BUSINESS REQUIREMENTS DOCUMENT

## Table of Contents

- 1. Document Control
  - 1.1 Document Information
  - 1.2 Revision History
- 2. Executive Summary
  - Key Stakeholders
- 3. System Context
- 4. Functional Requirements
  - 4.1 Business Requirements
    - Requirement ID: BR-001
    - Requirement ID: BR-002
    - Requirement ID: BR-003
    - Requirement ID: BR-004
    - Requirement ID: BR-005
    - Requirement ID: BR-006
    - Requirement ID: BR-007
    - Requirement ID: BR-008
    - Requirement ID: BR-009
    - Requirement ID: BR-010
    - Requirement ID: BR-011
    - Requirement ID: BR-012
    - Requirement ID: BR-013
    - Requirement ID: BR-014
    - Requirement ID: BR-015
    - Requirement ID: BR-016
    - Requirement ID: BR-017
    - Requirement ID: BR-018
    - Requirement ID: BR-019
    - Requirement ID: BR-020
    - Requirement ID: BR-021
    - Requirement ID: BR-022
    - Requirement ID: BR-023
    - Requirement ID: BR-024
    - Requirement ID: BR-025
    - Requirement ID: BR-026
    - Requirement ID: BR-027
    - Requirement ID: BR-028
    - Requirement ID: BR-029
    - Requirement ID: BR-030
    - Requirement ID: BR-031
    - Requirement ID: BR-032
    - Requirement ID: BR-033
    - Requirement ID: BR-034
    - Requirement ID: BR-035
    - Requirement ID: BR-036
    - Requirement ID: BR-037
    - Requirement ID: BR-038
    - Requirement ID: BR-039
    - Requirement ID: BR-040
    - Requirement ID: BR-041
    - Requirement ID: BR-042
    - Requirement ID: BR-043
    - Requirement ID: BR-044
    - Requirement ID: BR-045
- 5. Business Rules Catalogue
- 6. Data Requirements
  - 6.1 Business Entities and Relationships
    - Physical Inventory Count Header - PH_INVENTORY
    - Physical Inventory Count Detail - PD_INVENTORY
    - Stock Adjustment Header - PH_STKADJ
    - Stock Adjustment Detail - PD_STKADJ
    - Entity Relationships
  - 6.2 Data Capture Requirements
    - Count Session Header (Stock Controller - new or existing count)
    - Part Detail Count Lines (Stock Controller - per part during counting)
    - Session and Control Parameters (System - set at form open and reset)
  - 6.3 Reference Data
  - 6.4 Data Lifecycle
  - 6.5 Excel Output Columns
- 7. Glossary
- 8. Technical Inventory
  - 8.1 Form Architecture
    - 8.1.1 Global Variables
    - 8.1.2 Form Parameters
  - 8.2 Blocks
    - 8.2.1 Block WhereClause and OrderByClause
  - 8.3 Items Summary
  - 8.4 List of Values
  - 8.5 Alerts
  - 8.6 Program Units
  - 8.7 Triggers
    - 8.7.1 Inactive / Commented-Out Trigger Register
  - 8.8 Canvas and Window Inventory
  - 8.9 Editors
  - 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups
    - 8.10.1 Visual Attributes (form-defined)
    - 8.10.2 Property Classes (form-defined)
    - 8.10.3 Object Groups
  - 8.11 DataSourceColumn Inventory
    - PH_INVENTORY (15 columns)
    - PD_INVENTORY (17 columns)
- 9. Object Library
- 10. Record Groups
- 11. Referenced Database Objects
- 12. Backend Procedures and Packages
  - 12.1 Main Flow Backend Procedure/Package Index
  - 12.2 Procedure and Package Catalogue
- 13. Package Procedure Specifications
- 14. Database Package Catalogue
- 15. PLD Procedure Call Sites
  - DPL.pld (`general`)
  - DPL.pld (`pkg_param_variables`)
  - webutil.pld (`WEBUTIL_C_API`)
  - webutil.pld (`WEBUTIL_FILE`)
- 16. Microservice API Candidates
  - 16.1 Microservices with APIs
- 17. Workflows
- 18. PLD-Backed Logic
  - webutil.pld (`CLIENT_IMAGE`)
  - DPL.pld (`general`)
  - D2kwutil.pld (`Win_API`)
- 19. PCK-Backed Logic
- 20. System Interfaces
  - 20.1 Database Integrations
  - 20.2 External System Integrations
  - 20.3 Report Integrations
    - 20.3.1 Parameters Passed to the Report
- 21. Procedure and Function Business Rule Catalogue
  - 21.1 Catalogue Index
  - 21.2 Detailed Specifications
    - SP-001 - CALC_DIFF_QTY
    - SP-002 - CALL_REPORT_PR_INVENTORY
    - SP-003 - CALL_REPORT_PR_PHY
    - SP-004 - CHK_DUP
    - SP-005 - ENABLE_HEADER
    - SP-006 - ENABLE_POP_BTN
    - SP-007 - STOCK_UPDATE_EXCEPTION
    - SP-008 - D2KWUTIL.ATTEMPT_DLL_LOAD
    - SP-009 - D2KWUTIL.CHOOSEFILE
    - SP-010 - D2KWUTIL.D2KWUTIL_ACTIVEWIN
    - SP-011 - D2KWUTIL.D2KWUTIL_CHOOSEFILE
    - SP-012 - D2KWUTIL.D2KWUTIL_DEBUGSTRING
    - SP-013 - D2KWUTIL.D2KWUTIL_WINDIR
    - SP-014 - D2KWUTIL.GET_ACTIVE_WINDOW
    - SP-015 - D2KWUTIL.SAVE_FILE
    - SP-016 - D2KWUTIL.TRANSLATETYPE
    - SP-017 - GENERAL.ASK_CONFIRM
    - SP-018 - GENERAL.ASK_PRINT
    - SP-019 - GENERAL.CHECK_FORM_FAILURE
    - SP-020 - GENERAL.CHECK_NULL
    - SP-021 - GENERAL.DISP_TEXT
    - SP-022 - GENERAL.L_POP_LIST_ITEM
    - SP-023 - GENERAL.PROC_REPORT_CALL
    - SP-024 - GENERAL.PROC_TIMER
    - SP-025 - GENERAL.PROC_TIMER_EXPIRED
    - SP-026 - GENERAL.RAISE_ERROR
    - SP-027 - PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM
    - SP-028 - PK_VALIDATE_BACK_DATE.GET_LAST_DOC_DATE
    - SP-029 - WEBUTIL.BLOCKING
    - SP-030 - WEBUTIL.CLEARCALLBACKTRIGGER
    - SP-031 - WEBUTIL.DOWNLOADFROMURL
    - SP-032 - WEBUTIL.DOWNLOADFROMURLINT
    - SP-033 - WEBUTIL.ERROR
    - SP-034 - WEBUTIL.ERRORALERT
    - SP-035 - WEBUTIL.EXECUTE
    - SP-036 - WEBUTIL.FCLOSE
    - SP-037 - WEBUTIL.FILE_SELECTION_DIALOG_INT
    - SP-038 - WEBUTIL.FOPEN
    - SP-039 - WEBUTIL.GETIMPLCLASS
    - SP-040 - WEBUTIL.GETPROPERTY
    - SP-041 - WEBUTIL.GET_LINE
    - SP-042 - WEBUTIL.GET_RETURN_CODE
    - SP-043 - WEBUTIL.HOST
    - SP-044 - WEBUTIL.ID_NULL
    - SP-045 - WEBUTIL.LENGTH
    - SP-046 - WEBUTIL.PUTF
    - SP-047 - WEBUTIL.PUT_LINE
    - SP-048 - WEBUTIL.REGISTER_FUNCTION
    - SP-049 - WEBUTIL.RELEASE_PROCESS
    - SP-050 - WEBUTIL.SETPROPERTY
    - SP-051 - WEBUTIL.URL_TO_CLIENT
    - SP-052 - WEBUTIL.WAIT
    - SP-053 - WEBUTIL_FILE.FILE_SAVE_DIALOG
    - SP-054 - ADD_ERROR
    - SP-055 - ADD_EXTERNAL_ERRORS
    - SP-056 - BOOLTOCHAR
    - SP-057 - CLEAN_ERROR_STACK
    - SP-058 - DEBUGLOG
    - SP-059 - GET_TEMP_DIRECTORY
    - SP-060 - GET_WINDOWS_DIRECTORY
    - SP-061 - REGISTER_FUNCTION_CALL
    - SP-062 - RUN_REPORT
    - SP-063 - SETDEBUG
    - SP-064 - SF_COPYRIGHT_DECLARATION
    - SP-065 - SF_GET_ALLOW_DECIMAL
    - SP-066 - SF_GET_BIN_FLAG
    - SP-067 - SF_GET_DEFAULT_STORE_BIN
    - SP-068 - SF_GET_PRICE
    - SP-069 - SF_GET_STORE_BIN_LOC
    - SP-070 - SF_GET_STORE_NAME
    - SP-071 - SP_ADJUST_LANDED
    - SP-072 - SP_GET_PART_DESC
    - SP-073 - SP_GET_PART_SELL_PRICE_ONE
    - SP-074 - SP_GET_PHY_PART_DETAILS
    - SP-075 - STRIPDIRSEP
    - SP-076 - VIEW_EXCEL_REPORT_NEW
    - SP-077 - WINDEBUG

## 1. Document Control

### 1.1 Document Information

| Field | Value |
| ----- | ----- |
| Document Title | PT_PHY - Business Requirements Document |
| Form Module Name | PT_PHY |
| Document Version | 1.0 |
| Date Created | August 07, 2026 |
| Author/Prepared By | BRD Agent |

### 1.2 Revision History

| Version | Date | Author | Description |
| --- | --- | --- | --- |
| 1.0 | August 07, 2026 | BRD Agent | Initial draft |

---

## 2. Executive Summary

*High-level overview of the pt_phy Physical Inventory form, its purpose, and roles referenced in the module.*

The **pt_phy** Oracle Forms module is the dealership **Physical Inventory** screen. It enables store personnel to record and manage a physical stock count for a selected store and financial period. The user opens the screen, enters or looks up an existing inventory session by document number, specifies the store and count criteria (such as part range, bin location range, part classifications, and stock filters), and either auto-populates the list of parts to be counted or enters them manually. For each part the user records the physical quantity found, the count date, and the bin location. The screen computes the difference between the counted quantity and the system stock, and when discrepancies exist the user selects the applicable tax type and enters supporting remarks. Once counting is complete, an authorised signatory is identified and an adjustment document is generated - receiving a system-assigned sequential number - to record the stock correction. Physical inventory and adjustment reports can be generated from the screen for View or Print delivery.

### Key Stakeholders

*Who uses pt_phy*

| Stakeholder | Role |
| :--- | :--- |
| **Store / Inventory Supervisor** | Primary interactive user. Opens or resumes physical inventory sessions, sets count criteria, triggers part-list population, reviews system and physical quantities, enters count data, and initiates adjustment generation. |
| **Authorised Signatory (Employee)** | Selected on the adjustment confirmation dialog; their employee code and name are recorded on the adjustment as the person accountable for the count. |
| **Dealer / Parts Management** | Organisational owner; the session is scoped to a specific dealer, location, company code, and financial year, ensuring adjustments are traceable to the correct business entity. |

---

---

## 3. System Context

*Describes the pt_phy module's role within the DMS ecosystem, scope, process flow, and key integrations.*

The **pt_phy** module is the dealership **Physical Inventory** screen within the Dealer Management System (DMS). It is the entry point for conducting, recording, and reconciling periodic stock counts, and connects store operations with parts master data, bin location management, stock adjustment processing, and report generation.

**System purpose:** Open or create a physical inventory session, specify the store and part-selection criteria, populate and record physical count quantities for each part, calculate stock variances, generate a stock adjustment document with a sequential number, and produce inventory and adjustment reports - as implemented in the pt_phy Oracle Forms module.

**In scope:**

- Open or resume a physical inventory session by document number for a given dealer, location, company, and financial year
- Select the target store and specify count date with back-date validation against the last inventory date
- Choose entry mode: auto-populate parts from system stock using category, classification, price range, stock, and bin location filters; or enter parts manually
- Populate the list of parts to be counted from the parts and bin-location master data, with system stock and allocated quantity displayed per line
- Record physical count quantities, count dates, and physical bin locations for each part line
- Calculate the quantity difference (physical versus system or current stock) per part line
- Validate bin locations for lines with discrepancies when bin-location tracking is enabled
- Capture tax type and remarks for each line with a discrepancy
- Identify the authorised signatory (employee) and the reason for adjustment
- Generate a sequential stock adjustment document number via back-date-controlled numbering
- Produce physical inventory reports (pr_inventory) and physical count reports (pr_phy_pdf) in View (browser PDF) or Print (printer queue) format

**Process Name:** Physical Inventory

**Process Owner:** Parts / Store Manager

**Process Objective:** Open or create a physical inventory session, specify the store and count criteria, populate and record part quantities, calculate variances, and generate a stock adjustment document with supporting reports before closing the count.

**Process Trigger:** Periodic physical stock count initiated by the Parts or Store Manager for a dealer location

**Process Flow:**

The complete physical inventory process follows this sequence. Each step corresponds to Functional Requirements in Section 4.

```
STEP 1 ── SCREEN OPENS
         Store Supervisor opens the pt_phy Physical Inventory screen.
         Session context (dealer, location, company, parent group, financial year) is
         loaded from the calling environment. The inventory number field is empty.

STEP 2 ── NEW OR EXISTING SESSION?
         ├── EXISTING: Enter or look up the inventory document number.
         │            System counts matching inventory records; if found, the session
         │            is loaded and further editing is enabled based on adjustment status.
         └── NEW: Leave the document number blank;
                  count date defaults to today's date; back-date rules apply.

STEP 3 ── BACK-DATE VALIDATION
         System validates the count date is not earlier than the last recorded
         inventory date for the same document context.
         If back-dated, an error showing the minimum permitted date is displayed.

STEP 4 ── STORE SELECTION
         User selects the store (warehouse) to be counted.
         Store selection is mandatory before proceeding to part population.

STEP 5 ── ENTRY MODE SELECTION
         User selects entry mode:
         ├── AUTO: Parts are populated from system stock using filter criteria.
         └── MANUAL: User enters individual part numbers on the count lines.

STEP 6 ── FILTER CRITERIA (AUTO MODE ONLY)
         User sets part-selection filters:
         category, ABC/FSN/XYZ classification, margin category, price type and range,
         stock filter (all / with stock / zero stock), part number range,
         bin location range, and sort order.
         The populate button is enabled when the required range endpoints are present.

STEP 7 ── PART LIST POPULATION (AUTO MODE)
         User presses the Fetch/Populate button.
         System queries parts and bin-location stock data matching the selected filters
         and populates the detail count lines with part number, bin location,
         system stock quantity, allocated quantity, and part description.
         Header criteria fields are locked after successful population.

STEP 8 ── MANUAL PART ENTRY (MANUAL MODE ONLY)
         User enters part numbers directly on each count line.
         System validates each part number against the parts master and fetches
         the description, landed cost, and decimal-quantity flag.

STEP 9 ── PHYSICAL COUNT ENTRY
         For each part line, user enters the physical count quantity and count date.
         Count date must be between the inventory date and today; it is mandatory when
         a physical quantity is recorded.

STEP 10 ── QUANTITY DIFFERENCE CALCULATION
          System automatically calculates the quantity difference:
          physical count minus system stock (or current stock depending on the basis setting).
          Lines with no discrepancy require no further action.

STEP 11 ── BIN LOCATION ENTRY (WHEN BIN TRACKING ENABLED)
          For lines with a quantity difference, user enters or confirms the physical bin location.
          System validates the bin location against the bin master.
          If the bin is new and a difference exists, the user is warned about new-bin creation.

STEP 12 ── TAX TYPE SELECTION (LINES WITH DISCREPANCY)
          User selects the applicable tax type for each line with a quantity difference.
          Tax type is mandatory when a discrepancy exists.

STEP 13 ── REMARKS ENTRY
          User may enter remarks for individual count lines via a remarks popup editor.
          Remarks are stored per part-count line.

STEP 14 ── STOCK-ADJUSTMENT BASIS SELECTION
          User selects whether the quantity difference is calculated against current stock
          or system stock.
          Changing the basis recalculates all difference quantities on the detail lines.

STEP 15 ── PART SEARCH (OPTIONAL)
          User may enter a part number in the search filter and press Search to navigate
          to matching lines within the count list.

STEP 16 ── ADJUSTMENT CONFIRMATION - STOCK TAKEN BY AND REASON
          User opens the adjustment confirmation dialog (CN_ADJ canvas).
          User selects the employee who took stock and the reason for adjustment.
          Both fields are mandatory.

STEP 17 ── SEQUENTIAL ADJUSTMENT DOCUMENT NUMBER GENERATION
          System calls the document-numbering routine with the session context
          (dealer, principal, location, company, document type, financial year).
          A unique, sequentially formatted adjustment number is generated atomically
          and stored on the inventory header.

STEP 18 ── ADJUSTMENT RECORDS CREATED
          Stock adjustment header and detail records are written to the adjustment tables.
          Action buttons (report, export) are updated to reflect the generated adjustment.

STEP 19 ── AUTHORISED SIGNATORY SELECTION (OPTIONAL)
          User may open the employee lookup (CN_AUTH canvas) to record an authorised
          signatory employee code and name for the inventory session.

STEP 20 ── PHYSICAL INVENTORY REPORT GENERATION
          User requests the physical inventory report (pr_inventory).
          ├── VIEW: Report is rendered as a PDF and opened in the browser.
          └── PRINT: Report is submitted to the printer queue; a timer polls for completion
                     and opens the output file in the browser when done.
          User is asked whether to include stock quantities in the printed report.

STEP 21 ── PHYSICAL COUNT REPORT GENERATION
          User requests the physical count report (pr_phy_pdf).
          Same View / Print delivery options as Step 20.

STEP 22 ── FORM CLEAR
          User clears the form to begin a new session.
          All session flags, filter values, and block states are reset.
          Bin-flag and default parameters are re-read from the system.
```

**Major process interactions:**

- **Parts master data** - validates part numbers, fetches descriptions, landed costs, and decimal-quantity flags during part entry and auto-population
- **Bin location master** - provides available bin locations for LOV selection and validates physical bin locations entered for count lines with discrepancies
- **Stock and allocation data** - supplies current system stock and allocated quantities per part per bin for difference calculation
- **Document numbering master** - provides atomic sequential document-number generation and enforces back-date rules via the back-date validation package
- **Employee master** - supplies the list of authorised employees for signatory selection
- **Store master** - lists available stores for the selected dealer and location
- **Application lookup lists** - provides list-item values for categories, classifications, price types, tax types, and other selection fields
- **Adjustment transaction tables** - physical stock adjustment header and detail records are written on adjustment generation
- **Report server** - delivers physical inventory and physical count reports to the browser (View) or printer queue (Print)

---

---

## 4. Functional Requirements

### 4.1 Business Requirements

#### Requirement ID: BR-001

**Requirement Title:** Form Session Registration

**Business Description:**
When the Physical Inventory form is opened, the system registers the current session under the PT_PHY module so that database administrators and monitoring tools can identify which application module is active for the connected user's session.

**Actors:** Stock Controller (system-initiated on form open)

**Preconditions:**
- The user has opened the Physical Inventory form and a database session has been established.

**Main Flow:**

**Step 1 - Session is tagged with the Physical Inventory module identity**
As soon as the form opens, the system automatically records the module name and session identity for the active database connection. This tagging supports session-level monitoring and auditing of which application is in use.

*Business outcomes (errors, warnings, success, and status):*
- **BR-001-IC-01** - `pt_phy` - session client information is set to identify the Physical Inventory module for the duration of the user's session.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Module Name (`module_name`) | Auto-populated | Alphanumeric | 48 | N/A | `pt_phy` (fixed system value) | Database session active | System-set; not user-editable | N/A |

---

---

---

---

#### Requirement ID: BR-002

**Requirement Title:** Form Initialisation and Reset

**Business Description:**
Before the Physical Inventory form is displayed, the system registers the form's identity with the Oracle application session so that monitoring and audit tools can identify the active module. When the form is then opened for the first time, the system maximises the main window, initialises all session control flags to their default values, populates five dropdown lists from reference data (Stores, Category, margin category, Reason, and Employee), sets up default field values, retrieves the bin-location flag for the current dealer, and pre-loads the current user as the adjusted-by name. When the user subsequently clears the Physical Inventory form to start a new session or reset the current work, the system resets all working flags, restores header and detail entry permissions, disables action buttons that are not yet valid, retrieves the bin-location control setting for the current dealership, sets the default part entry mode, and displays the current copyright notice. This ensures the form is in a clean, correctly configured state before any new physical count is started.

**Actors:** Stock Controller

**Preconditions:**
- The Physical Inventory form is open and a user session is active.

**Main Flow:**

**Step 1 - Application session identity is registered before the form displays**
Before the Physical Inventory form is shown to the user, the system registers the form's identity with the Oracle application information service. The client-info slot is set to `'pt_phy'` and the module name is set to `'pt_phy'` (with a blank action name) using `DBMS_APPLICATION_INFO.SET_CLIENT_INFO` and `DBMS_APPLICATION_INFO.SET_MODULE`. This ensures that session-level monitoring tools, audit logs, and performance diagnostic views can identify which form is in use for the duration of this session.

**Step 2 - Main window maximised and session control flags initialised on form open**
When the form first opens, the system maximises the main application window (`WN_MAIN`) and sets all in-session tracking flags to their starting values: adjustment-click flag (`global.adj_click`) is set to `N`, generate-click flag (`global.gen_click`) is set to `N`, and stock-adjustment flag (`global.stk_adj`) is set to `N`. The tax-flag parameter (`parameter.p_tax_flag`) is set to `Y` and the commit-form parameter (`parameter.p_commit_form`) is set to `N` to prevent inadvertent commits before data entry.

**Step 3 - Dropdown lists are populated from reference data on form open**
The system populates five dropdown lists that appear throughout the form, using `GENERAL.L_POP_LIST_ITEM` and `POPULATE_LIST` for each:

- **Stores** dropdown (`ph_inventory.stores_cd`): loaded with store descriptions and codes from the dealer's store master for the current location and financial area (record group `Stores`).
- **Category** dropdown (`ph_inventory.catg_cd`): loaded with category descriptions and codes from the principal's parts category master (record group `Category`).
- **Margin Category** dropdown (`ph_inventory.mcat_cd`): loaded with margin category codes from the principal's margin category master (record group `margin_Category`).
- **Reason** dropdown (`b_adj.reason`): loaded with stock adjustment reason descriptions and codes for the principal (reason type `S`) (record group `reason`).
- **Employee** dropdown (`b_adj.stock_taken_by`): loaded with employee names and codes for the current dealer (record group `emp`).

**Step 4 - Adjusted-by name and button states are initialised on form open**
The current user name is pre-loaded into the `b_adj.adjusted_by` field. The Report, Generate Adjustment, Export to Excel, Export PDF, Generate, Print, and Export buttons are all disabled so that they are not available before a count has been loaded or created.

**Step 5 - Default header field values and form-level parameters are set on form open**
The system sets the stock-quantity filter (`ph_inventory.stock_qty`) to `A` (all stock), the active-indicator (`ph_inventory.ACTIVE_YN`) to `B`, the order-by field (`ph_inventory.order_by`) to `1` (by part number), the stock-adjustment-on field (`ph_inventory.STKADJ_ON`) to `C`, and the bin-order field (`ph_inventory.BIN_ORDER`) to `1`. The bin-location control flag is retrieved for the current dealer and stored in `parameter.p_bin_flag`. The part entry mode (`PH_INVENTORY.ENTRY_MODE`) defaults to `A` (all parts). The Delete and Insert toolbar buttons are enabled and navigable; the Fetch button is disabled and non-navigable.

*Procedures called:*
- **SF_GET_BIN_FLAG** ([SP-026](#sp-026)) - SF_GET_BIN_FLAG - retrieves the bin-location control flag for the current dealership and location.
    * **Step 1** - Accept the parent group, dealer, and location identifiers.
    * **Step 2** - Look up the bin-location management setting for the given dealer configuration.
    * **Step 3** - Return the bin-location control flag value.

**Step 6 - Dealer category and consignee code are fetched on form open**
The system retrieves the dealer category code from the dealer location table and stores it in `parameter.P_DEALER_CATEGORY`. It then retrieves the consignee code (`parameter.p_consg_cd`) for the current dealer location. If the consignee code query fails, the user sees *"Execution failed while fetching Consignee Code"* and the form stops loading.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Consignee code retrieval succeeds | Consignee fetch - WHEN-NEW-FORM-INSTANCE condition (SELECT consg_cd INTO parameter.p_consg_cd) | When the form first opens. | The consignee code is required for SAN limit calculations and dealer-category-specific processing later in the session. | *"Execution failed while fetching Consignee Code"* - form trigger failure; form does not open successfully. |

**Step 7 - Monthly adjustment value and SAN limit are fetched on form open for applicable dealers**
For dealers in the `MAS` (mass) category, the system retrieves the total monetary value of stock adjustments for the current calendar month across all locations sharing the same consignee code (`parameter.p_month_adjust`) and the current approved SAN limit amount for the month (`parameter.p_san_limit_amt`). For all other dealer categories, the same values are retrieved but scoped to the individual consignee location only. If either fetch fails unexpectedly, the error is silently suppressed (null handling) and the form continues to open. If the SAN limit query fails in any other way than NO_DATA_FOUND, the system displays *"Execution failed while fetching defined SAN Limit"* (suppressed as null in current code).

*Business outcomes (errors, warnings, success, and status):*
- **BR-002-IC-01** - Form opened successfully - all dropdowns populated, flags initialised, and monthly adjustment values loaded; the user can begin entering a new physical inventory count.

**Step 8 - Working flags and default values are reset (form clear/reset path)**
When the user subsequently clears the form, the system clears all in-session tracking flags so that the form behaves as if freshly opened. Default values for stock-quantity filter, bin-location filtering indicator, and the adjustment-tracking flag are applied.

**Step 9 - Header and detail entry permissions are restored**
The system re-enables data entry on both the physical inventory header and the part detail sections of the screen, allowing the user to enter a new count. Entry permissions that may have been locked during a previous populate or save operation are lifted.

**Step 10 - Action buttons are set to their initial state**
Buttons that require a completed count before they are usable (Print, Report, Generate Adjustment, Export to Excel, Export PDF, Generate) are disabled. The Save button is enabled. The Populate button is disabled and non-navigable, as no filters have been set yet.

**Step 11 - Bin-location management flag is retrieved**
The system looks up the bin-location control setting applicable to the current dealer and location.

*Procedures called:*
- **SF_GET_BIN_FLAG** ([SP-026](#sp-026)) - SF_GET_BIN_FLAG - retrieves the bin-location control flag for the current dealership and location, which governs whether bin-location fields are enabled and validated throughout the form session.
    * **Step 1** - Accept the parent group, dealer, and location identifiers for the current session.
    * **Step 2** - Look up the bin-location management setting in the dealer configuration data for the given identifiers.
    * **Step 3** - Return the bin-location control flag value to the caller.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Bin-location control flag retrieved | Bin-location setting - SF_GET_BIN_FLAG [SP-026] | When the user triggers a form clear/reset. | Determines whether bin-location fields are active and validated for the current dealer, ensuring the form is configured correctly from the start. | N/A - the flag is used to govern downstream field behaviour; no explicit failure message is shown at this step. |

**Step 12 - Default part entry mode is applied**
The system sets the part entry mode to "All parts" as the default, so the detail grid will show all inventory parts unless the user changes the mode. The order-by setting is initialised to sort by part number.

**Step 13 - Copyright notice is displayed**
The system retrieves and displays the current copyright declaration text.

*Procedures called:*
- **SF_COPYRIGHT_DECLARATION** ([SP-024](#sp-024)) - SF_COPYRIGHT_DECLARATION - retrieves the current software copyright notice text and returns it for display on screen.
    * **Step 1** - Retrieve the current copyright declaration text from the function's internal definition.
    * **Step 2** - Return the copyright text to the calling form for display.

**Step 14 - Header filter fields are enabled for entry**
The form calls the header-enable routine, which makes all filter fields on the inventory header (category, ABC indicator, FSN/FMS indicator, XYZ indicator, margin category, price type, stock quantity filter, bin-location status, part number range, bin-location range, order-by, and sort order) navigable and editable so the user can set up the count criteria for a new run.

*Procedures called:*
- **ENABLE_HEADER** ([SP-002](#sp-002)) - ENABLE_HEADER - enables and makes navigable all physical inventory header filter fields, putting the form in the fully editable state ready for a new count session.
    * **Step 1** - Enable and make navigable each header filter field (category, ABC, FMS, XYZ, margin category, price type, stock quantity filter, bin-location status, part number from/to, bin-location from/to, order-by, and Populate button).
    * **Step 2** - Confirm that all enabled header fields are ready for user input.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| All header filter fields made navigable | Header-enable - ENABLE_HEADER [SP-002] | When the user triggers a form clear/reset. | Ensures the user can set count filters before initiating a new physical inventory run. | N/A - this step enables fields; there is no failure condition. |

**Alternative Flows:**
- **BR-002-AF-01** - (from Cancel button) When the user clicks the Cancel button and the form contains unsaved changes (form status is CHANGED), the system prompts with a confirmation alert: *"Entered data will not be Saved"*. If the user confirms, the form is cleared using the standard clear-form operation and stock-quantity and active-indicator fields are reset to their default values. If the user does not confirm, no action is taken and the user may continue editing. If the form has no unsaved changes, the clear-form operation runs directly without prompting.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Part Entry Mode (`ENTRY_MODE`) | Auto-populated | Character list | 1 | N/A | `A` = All parts (default on reset) | Form clear/reset triggered | System-set to `A` on reset; user may change before populating | N/A |
| Order By (`ORDER_BY`) | Auto-populated | Character list | N/A | N/A | `1` = Part Number (default on reset) | Form clear/reset triggered | System-set to `1` on reset | N/A |
| Stock Adjustment On (`STKADJ_ON`) | Auto-populated | Character list | N/A | N/A | `C` = Current stock (default on reset) | Form clear/reset triggered | System-set to `C` on reset | N/A |
| Copyright Notice (`COPY_RIGHT`) | Read-only display | Character | 100 | N/A | Copyright text returned by system function | Form clear/reset triggered | Read-only; populated by system function | N/A |

---

---

---

---

#### Requirement ID: BR-003

**Requirement Title:** Physical Inventory Count Number Entry and Existing-Count Lookup

**Business Description:**
When a stock controller enters a physical inventory count number to look up an existing count, the system checks whether that count number exists in the current dealer's records. If the count exists, the system automatically loads the matching count header and all its associated part detail lines. If no count is found for the entered number, the user is informed and must correct the entry. If the field is left blank, the system defaults the count date to today and the user proceeds to create a new count.

**Actors:** Stock Controller

**Preconditions:**
- The Physical Inventory form is open and in a clean state (no previously loaded count).

**Main Flow:**

**Step 1 - User enters a count number or leaves the field blank and moves to the next field**
The user either types an existing count number to retrieve a previously started count, or leaves the field empty to begin a new count. When the user moves to the next field, the system acts on the entry.

**Step 2 - New count path: count date defaulted to today**
If the count number field is left blank, the system automatically sets today's date as the count date and the user proceeds directly to enter count header filter criteria.

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-IC-01** - Count date set to current date - when no count number is entered, the system populates the count date with today's date and the user may continue entering header details.

**Step 3 - Existing count path: record lookup performed**
If a count number is entered, the system searches the physical inventory records for a matching document number belonging to the current dealer, location, company financial area, and parent group. The system counts how many matching records exist to determine whether to proceed.

**Step 4 - Count found: header and detail records loaded**
When the matching count is found, the system records the count in memory, navigates to the inventory header block, and immediately executes a query to load the count header record. It then navigates to the part detail block and executes a query there too, loading all the individual part lines that belong to the count. The Export button (`PB_EXP`) is enabled to allow data export once a count has been retrieved.

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-IC-02** - Count record found - header and all part detail lines are retrieved and displayed for the user; the Export button is enabled.

**Alternative Flows:**
- **BR-003-AF-01** - (from Step 3) The entered count number does not exist in the current dealer's records: the system displays *"Physical Inventory Number not found"* and raises a trigger failure, keeping the cursor on the count number field. The user must re-enter a valid number or clear the field.
- **BR-003-AF-02** - (from Step 3) A data-width or compatibility error occurs while retrieving the count record: the system displays *"Width problem/Incompatible data while retrieving count"* and the trigger fails; the user must re-enter the field.
- **BR-003-AF-03** - (from Step 3) Any other unexpected error occurs while querying the count record: the system displays *"Execution failed while retrieving count"* (with the database error text appended) and the trigger fails; the user must re-enter the field.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Count number existence check | Count existence - KEY-NEXT-ITEM on B_DUMMY.NB_INV_NO's own condition (SELECT COUNT from PH_INVENTORY) | When the user moves off the count number field after entering a value. | Confirms the entered count number belongs to an existing physical inventory document for the current dealer, preventing the user from accidentally creating a duplicate or working on a non-existent document. | *"Physical Inventory Number not found"* - trigger failure; cursor remains on count number field. |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Count Number (`NB_INV_NO`) | Optional | Character | 12 | Physical inventory count list (LV_INV_NO / RG_INV_NO) | Count document number | Form is in clean state | If entered, must match an existing count document for the current dealer/location | *"Physical Inventory Number not found"* |
| Count Date (`INV_DATE`) | Auto-populated | Date | DD-MM-YYYY | N/A | Today's date (when no count number entered) or date from retrieved record | Count number field confirmed | System-defaulted when blank; read from retrieved record when count loaded | N/A |

---

---

---

---

#### Requirement ID: BR-004

**Requirement Title:** System Error and Data-Validation Message Handling

**Business Description:**
When any operation in the Physical Inventory form produces an error, the system intercepts the error before Oracle's standard error dialog appears and displays a clear, business-appropriate message to the user. Different categories of error are handled distinctly: invalid date formats, non-numeric input in numeric fields, record-locking conflicts caused by another user, referential-integrity violations, and all other database errors each produce a specific guided message. For record-locking and non-date-format errors the system also rolls back the pending transaction to leave the data in a consistent state.

**Actors:** Stock Controller (system-triggered; no direct user action required)

**Preconditions:**
- An error condition has been raised by any form trigger or database operation within the Physical Inventory form.

**Main Flow:**

**Step 1 - Error type is identified and the appropriate message is displayed**
The system inspects the error code to determine which category of error occurred and handles it as follows, in sequence:

- If the error indicates an **invalid date value** (error code 50004), the user sees *"Entered Date is not valid Date"* and the current operation is stopped.
- If the error indicates a **date format problem** (error codes 50025 or 50026), the user sees *"Enter the Date in the proper format (DD-MM-YYYY)"* and the current operation is stopped.
- If the error indicates **non-numeric input in a numeric field** (error codes 40209 or 50016), the user sees *"Characters/Special Characters are not allowed here, enter the numeric value"* and the current operation is stopped.
- If the error indicates a **required-field constraint violation** (error code 40207), the standard error text is displayed and the current operation is stopped.
- If the database error code indicates a **referential-integrity constraint violation** (DBMS error -02292), the system raises a pre-defined constraint error message via the error-message library.
- If the error indicates a **record-locking conflict** (error codes 40654, 40655, 40656, 40657, or 40659), the user sees *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*, the pending transaction is rolled back, and the current operation is stopped.
- For **all other database errors** (any non-zero SQL error code), the system displays the database's own error text and rolls back the pending transaction.
- Informational form errors (codes 40401 and 40405) are silently suppressed (no message shown to the user).

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-008](#sp-008)) - GENERAL.DISP_TEXT - presents a formatted error, warning, or informational message to the user in a consistent dialog style.
    * **Step 1** - Receive the message text and severity level from the caller.
    * **Step 2** - Format and display the message to the user in the standard application dialog.
- **GENERAL.RAISE_ERROR** ([SP-012](#sp-012)) - GENERAL.RAISE_ERROR - looks up a pre-defined error message by its code and raises it to the user.
    * **Step 1** - Accept the error code identifier from the caller.
    * **Step 2** - Retrieve the corresponding pre-defined message text from the error-message catalogue.
    * **Step 3** - Display the message and raise a trigger failure to stop the current operation.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Date value validity | Date validity - ON-ERROR form trigger condition (errnum = 50004) | When any form operation produces error code 50004. | Prevents invalid date values from being silently stored in date fields. | *"Entered Date is not valid Date"* - operation stopped. |
| Date format compliance | Date format - ON-ERROR form trigger condition (errnum IN 50025, 50026) | When any form operation produces a date format error. | Guides the user to enter dates in the required DD-MM-YYYY format. | *"Enter the Date in the proper format (DD-MM-YYYY)"* - operation stopped. |
| Numeric field input | Numeric input - ON-ERROR form trigger condition (errnum IN 40209, 50016) | When any form operation detects a non-numeric value in a numeric field. | Prevents non-numeric or special characters from being entered in numeric fields. | *"Characters/Special Characters are not allowed here, enter the numeric value"* - operation stopped. |
| Required-field constraint | Field constraint - ON-ERROR form trigger condition (errnum = 40207) | When a required-field constraint is violated. | Notifies the user of constraint violations on mandatory fields. | Standard error text displayed - operation stopped. |
| Referential-integrity constraint | Referential integrity - GENERAL.RAISE_ERROR [SP-012] (DBMS error -02292) | When a database referential-integrity constraint is violated. | Prevents orphaned records by enforcing parent-child data consistency. | Pre-defined constraint error message raised - operation stopped. |
| Record-locking conflict | Concurrent update - ON-ERROR form trigger condition (errnum IN 40654, 40655, 40656, 40657, 40659) | When a save or update detects that another user has already modified the record. | Prevents data loss from concurrent edits by warning the user to re-query before saving. | *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"* - rollback executed, operation stopped. |
| Other database errors | General SQL error - ON-ERROR form trigger (sqlcode <> 0) | When any other database error occurs. | Exposes the underlying database error message so users and support staff can diagnose the problem. | Database's own error text displayed - rollback executed, operation stopped. |

---

---

---

---

#### Requirement ID: BR-005

**Requirement Title:** Form Message Suppression

**Business Description:**
When the Physical Inventory form would ordinarily display a standard Oracle Forms informational or status message (such as record-navigation banners), the system suppresses those standard messages and, only when the message relates to the form's own restricted-input or field-constraint rules, shows a cleaner guided error instead. This prevents cluttered, technical Oracle Forms status text from being seen by the user.

**Actors:** Stock Controller (system-triggered; no direct user action required)

**Preconditions:**
- A form message event (not a full error) has been raised within the Physical Inventory form.

**Main Flow:**

**Step 1 - Message type is checked and unwanted messages are suppressed**
When a form message fires, the system checks its message code. If the message code corresponds to a numeric-field or required-field constraint notification (codes 40209 or 40207), the system displays the underlying message text as an error dialog. All other standard Oracle Forms messages are silently suppressed and do not appear to the user.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-008](#sp-008)) - GENERAL.DISP_TEXT - presents the constraint message as a formatted error to the user when the message code matches a controlled category.
    * **Step 1** - Receive the message text and severity level from the caller.
    * **Step 2** - Format and display the message to the user in the standard application dialog.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Message code filter | Message suppression - ON-MESSAGE form trigger condition (errnum IN 40209, 40207) | When any Oracle Forms message fires during form operation. | Prevents unwanted Oracle Forms technical messages from confusing users while still surfacing relevant constraint-related errors. | For codes 40209/40207: error text displayed and operation stopped. All other messages: silently suppressed. |

---

---

---

---

#### Requirement ID: BR-006

**Requirement Title:** Close Physical Inventory Form

**Business Description:**
When the user requests to close or exit the Physical Inventory form, the system clears the current session's module registration information and closes the form immediately without validating or saving any unsaved changes. This ensures a clean session end and prevents partial data from being inadvertently committed during exit.

**Actors:** Stock Controller

**Preconditions:**
- The Physical Inventory form is open.

**Main Flow:**

**Step 1 - Session identity is cleared and the form closes**
The system removes the module name and client session information that was registered when the form was opened (`DBMS_APPLICATION_INFO.SET_CLIENT_INFO` and `DBMS_APPLICATION_INFO.SET_MODULE` are cleared), then closes the form without saving any pending changes (`EXIT_FORM(NO_VALIDATE)`).

---

---

---

---

#### Requirement ID: BR-007

**Requirement Title:** Bin Location Value Selection and Difference Quantity Recalculation

**Business Description:**
When the user presses the list-of-values key while positioned on the Bin Location or Physical Bin Location fields in the part detail section, the system applies business rules before showing a selection list. For the current bin location field, the list is shown only when the dealer has bin-location management enabled and the count is in manual entry mode. For the physical bin location field, the list is shown only when there is a positive difference quantity for the current part. In both cases, the difference quantity is recalculated after the user's selection so the screen immediately reflects the updated count variance. For all other fields that have a configured value list, the system shows the list and advances to the next field on selection.

**Actors:** Stock Controller

**Preconditions:**
- The Physical Inventory form is open and the detail part list has been populated.
- The user has positioned the cursor on a field that has an associated value list.

**Main Flow:**

**Step 1 - Difference quantity is recalculated for the current part row (bin location fields)**
When the list key is pressed on either the bin location or physical bin location fields, the system first recalculates the difference quantity for the current part row before deciding whether to display a selection list.

*Procedures called:*
- **CALC_DIFF_QTY** ([SP-001](#sp-001)) - CALC_DIFF_QTY - recalculates the difference between the physical quantity counted and the system stock quantity for the current part row, based on the active stock-adjustment basis (current stock or stock at generation), and updates the on-screen difference quantity field.
    * **Step 1** - Determine whether the active stock-adjustment basis uses stock quantity at generation or current stock quantity.
    * **Step 2** - Compute the difference as the physical quantity entered minus the relevant stock quantity.
    * **Step 3** - Update the difference quantity field for the current part row.
    * **Step 4** - If a positive difference exists and bin-location management is enabled for the dealer, enable the physical bin location field for the current row so the user may specify where the excess stock resides; otherwise lock the physical bin location field.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Bin-location LOV restricted to manual entry mode when bin management is enabled | LOV display condition - KEY-LISTVAL form trigger condition (cursor_item = PD_INVENTORY.BIN_LOC AND p_bin_flag = 'Y' AND entry_mode = 'M') | When the user presses the list key while positioned on the Store Bin Location field. | Ensures the bin location selection list is only available when bin-location management is active for the dealer and the count is in manual entry mode, preventing accidental selection in auto-populate mode. | LOV not shown; no message; user remains on the field. |
| Physical bin location LOV restricted to rows with positive difference | LOV display condition - KEY-LISTVAL form trigger condition (cursor_item = PD_INVENTORY.PHY_BIN_LOC AND diff_qty > 0) | When the user presses the list key while positioned on the Physical Bin Location field. | Ensures the physical bin location selection list is only available when there is a positive stock difference, as a physical bin location is only meaningful when there is stock to account for. | LOV not shown; no message; user remains on the field. |

**Step 2 - Value list is displayed and next field is activated on selection**
If the applicable business condition is met, the system displays the relevant list to the user. When the user selects a value, the system automatically advances to the next field.

**Step 3 - Standard field value lists displayed for all other fields**
For fields other than the bin location fields, when the user presses the list key on a field that has an associated value list, the system displays that list and advances to the next field when a value is selected.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Store Bin Location (`BIN_LOC`) | Conditional - when bin management enabled and manual mode | Character | 10 | Bin Location list (LV_BIN_LOC / RG_BIN_LOC) | Bin location code | Bin flag = Y and entry mode = M | LOV shown only in manual entry mode when bin management is enabled | N/A - LOV simply not shown when conditions not met |
| Physical Bin Location (`PHY_BIN_LOC`) | Conditional - when difference quantity is positive | Character | 10 | Physical bin location list (LOV_TO_BIN_LOC_CD / RG_TO_BIN_LOC_CD) | Bin location code | Positive difference quantity exists for the part row | LOV shown only when difference quantity is greater than zero | N/A - LOV simply not shown when condition not met |
| Difference Quantity (`DIFF_QTY`) | Auto-populated | Numeric | 9,99,99,999.000 | N/A | Calculated: physical quantity minus stock quantity | Physical quantity entered | Read-only; recalculated by system on each relevant change | N/A |

---

---

---

---

#### Requirement ID: BR-008

**Requirement Title:** Save Physical Inventory Count Record

**Business Description:**
When the user clicks the Save button on the Physical Inventory form, the system validates all entered part detail rows, checks for duplicate part-number and bin-location combinations, generates a physical inventory document number for new count records, commits the transaction to the database, updates landed cost adjustments for any reduction rows, and - for a newly created count - displays the generated document number and triggers the inventory report. If validation errors exist (missing part details, tax type omissions for positive-difference rows, or duplicate part/bin combinations), the errors are listed on an error panel and the save is stopped until the user corrects them.

**Actors:** Stock Controller

**Preconditions:**
- The Physical Inventory form is open with at least one part detail row entered.
- The Save button (`PB_SAVE`) is enabled.

**Main Flow:**

**Step 1 - Save button enabled state is checked and form is prepared**
When the Save button is clicked, the system first confirms the Save button is enabled. The save flag (`parameter.p_commit_form`) is set to `N` to prevent double-commit. Any blank part detail rows (with no part number) are automatically deleted. The error collection table is cleared so that any previously collected errors do not carry over.

**Step 2 - All part detail rows are scanned for tax-type completeness**
The system iterates through every part detail row. For each row that has a part number entered, the part-found flag (`parameter.p_part_found`) is set to `Y`. For any row where the difference quantity is greater than zero and no tax type has been assigned, the system collects an error entry of the form *"Tax Type cannot be null for Part Number"* (concatenated with the part number and line number) into the error list. The detail rows are then scanned for a part-found result.

**Step 3 - At least one part detail row must be present**
After scanning all rows, if no row with a part number was found, the system displays *"Transcation cannot be saved without entering Part details"* and stops the save.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| At least one part detail row required | Part presence - FT_SAVE condition (parameter.p_part_found = 'N') | When the Save button is clicked and all detail rows are blank. | Prevents creating an empty physical inventory count document with no counted parts. | *"Transcation cannot be saved without entering Part details"* - trigger failure; save stopped. |

**Step 4 - Duplicate part-number and bin-location combinations are checked**
The system calls the duplicate-check utility (`CHK_DUP`) with the label *"Part Number or Bin Location"* to identify any rows in the part detail block that share the same part number and bin location. Any duplicates found are added to the error collection list.

*Procedures called:*
- **CHK_DUP** - checks all rows in the specified block for duplicate values in two nominated fields and collects any duplicate pairs into the error collection list.
    * **Step 1** - Accept the label ("Part Number or Bin Location"), the first key field (`PD_INVENTORY.part_num`), and the second key field (`PD_INVENTORY.bin_loc`).
    * **Step 2** - Iterate through all detail rows and compare each pair of field values against all other rows.
    * **Step 3** - For any duplicate combination found, add an error message entry to the error collection list identifying the duplicate fields and their line numbers.

**Step 5 - Collected errors are displayed on the error panel if any exist**
If the error collection list contains any entries after the tax-type scan and duplicate check, the system disables form validation, navigates to the error display block (`CB_ERR`), clears it, and populates it with all collected error lines. The error canvas (`CN_ERR`) is displayed and focus moves to the Continue button. The save flag is set to reflect errors (`parameter.p_tax_flag := 'Y'`). The save is stopped and the user must correct the errors and retry.

**Step 6 - Document number is generated for new count records**
If no errors exist, the system checks whether a physical inventory record with the current document reference already exists in the database. If no existing record is found (this is a new count), the system generates the next sequential physical inventory document number using `PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM` with document type `PHY`. The generated document number is stored on the count header.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Document number generation succeeds | Number generation - PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM (doc type 'PHY') | When saving a new count record. | Assigns a unique, sequential document number to the physical inventory count before committing. | Database error text displayed via GENERAL.DISP_TEXT - trigger failure. |

**Step 7 - Stock-taken-by is copied from adjustment panel and record is committed**
If an adjustment number exists on the header (the count has been adjusted), the stock-taken-by value is copied from the adjustment panel to the count header. The commit flag (`parameter.p_commit_form`) is set to `Y`. The system calls ENTER to validate all pending changes, then calls COMMIT_FORM to write the record to the database.

**Step 8 - Landed cost adjustments are applied for stock-reduction rows**
After the commit, the system iterates through all part detail rows. For any row where the direction is a decrease (`nb_inc_yn = 'D'`), the system calls `SP_ADJUST_LANDED` to apply the corresponding landed cost adjustment.

*Procedures called:*
- **SP_ADJUST_LANDED** - adjusts the landed cost records for a stock reduction line following a committed physical inventory adjustment.
    * **Step 1** - Accept the parent group, dealer, location, financial area, adjustment number, and part number.
    * **Step 2** - Apply the landed cost adjustment for the reduction in the inventory records.

**Step 9 - For new counts, the document number is announced, the user confirms stock inclusion, and the report is triggered**
If the count was a new record (no prior document number in the reference field), the system displays *"Physical Inventory number generated is"* (concatenated with the generated count number). Before submitting the report, the system asks the user *"Do you want to print with Stock?"*. If the user confirms, the stock-inclusion flag (`GLOBAL.p_type`) is set to `Y`; if the user declines, it is set to `N`. The system then calls `CALL_REPORT_PR_INVENTORY` to submit the physical inventory report for the new count with the selected stock-inclusion setting.

*Procedures called:*
- **CALL_REPORT_PR_INVENTORY** - submits the physical inventory print report to the report server with the session parameters and the stock-inclusion flag.
    * **Step 1** - Accept the principal, parent group, dealer, location, financial area, document number, and stock-inclusion flag (`GLOBAL.p_type`; `Y` = with stock, `N` = without stock).
    * **Step 2** - Build the report parameter list including the destination format (`MODE=CHARACTER BLANKPAGES=NO`).
    * **Step 3** - Submit the report job to the report server.

*Business outcomes (errors, warnings, success, and status):*
- **BR-008-SM-01** - Physical inventory count saved - *"Physical Inventory number generated is"* (followed by the new count number) - displayed when a new count is committed; the report is submitted automatically.
- **BR-008-IC-01** - Existing count updated - the count record is updated and committed; no number-generated message is shown for updates.

**Alternative Flows:**
- **BR-008-AF-01** - (from Step 1) The Save button is not enabled: the trigger exits immediately without any processing or messages.
- **BR-008-AF-02** - (from Step 5) One or more errors collected: the error panel (`CN_ERR`) is shown with all error messages listed; save is blocked until the user resolves the errors and clicks Save again.
- **BR-008-AF-03** - (from Step 7) The print step is the active path for the FT_PRINT trigger, which passes the stock-inclusion flag (`GLOBAL.p_type`) to the report call.

---

---

---

---

#### Requirement ID: BR-009

**Requirement Title:** Report Print-Queue Timer Monitoring

**Business Description:**
After a report print job is submitted, the system uses a background timer to periodically check whether the job has completed. When the timer fires, the system hands off to the standard timer-expiry handler which manages the report queue status polling and, when the job finishes, delivers the printed output to the user's browser. A more detailed polling loop that was previously implemented inline is commented out and no longer active; all active polling is now delegated to the common timer-expiry library routine.

**Actors:** Stock Controller (system-triggered)

**Preconditions:**
- A report print job has been submitted and a timer named PRINTER_QUEUE has been started.

**Main Flow:**

**Step 1 - Timer expiry event is delegated to the common timer handler**
When the timer fires, the system calls the standard timer-expiry routine from the attached library, which handles report-queue status checking and output delivery.

*Procedures called:*
- **GENERAL.PROC_TIMER_EXPIRED** ([SP-011](#sp-011)) - GENERAL.PROC_TIMER_EXPIRED - checks the status of a running report job and, when the job has completed, delivers the output document to the user's browser session.
    * **Step 1** - Accept the timer name from the application context.
    * **Step 2** - Retrieve the current status of the submitted report job.
    * **Step 3** - If the report job is still running or queued, take no action and allow the timer to fire again.
    * **Step 4** - When the report job status indicates completion, deliver the output file to the user's browser and cancel the timer.
    * **Step 5** - Return the result to the calling form.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Report job status check | Timer handling - GENERAL.PROC_TIMER_EXPIRED [SP-011] | When the PRINTER_QUEUE timer expires. | Monitors the report print queue so the user receives their printed output as soon as the job completes, without manual polling. | If the job has failed, the common handler manages the failure response; details are governed by GENERAL.PROC_TIMER_EXPIRED's own logic. |

> **Note (commented-out block - INACTIVE - does not execute):** An earlier implementation of the timer body directly called `REPORT_OBJECT_STATUS`, checked for RUNNING / FINISHED / FAILED states, and used `web.show_document` to deliver output and `delete_timer` to cancel the timer. This entire block is commented out. The active code delegates entirely to `GENERAL.PROC_TIMER_EXPIRED`.

---

---

---

---

#### Requirement ID: BR-010

**Requirement Title:** Inventory Header Block Entry - Action Button State Control

**Business Description:**
When focus moves to the inventory header section of the form, the system determines which action buttons should be available based on whether an existing count has been loaded or a new count is being created. If an existing count has been loaded that has no pending adjustment and was not retrieved purely by count number lookup, the Report, Generate Adjustment, Export to Excel, Generate, and Save buttons are enabled so the user can act on the count. In all other situations - a new count in progress, or one that already has an adjustment - those action buttons are disabled and the Save button is also disabled to prevent accidental commits.

**Actors:** Stock Controller (system-triggered on block navigation)

**Preconditions:**
- The Physical Inventory form is open.
- The user has navigated to or the system has moved focus to the inventory header section.

**Main Flow:**

**Step 1 - If an existing count record was previously loaded, its data is re-queried**
When an existing count is in memory (a count number was entered and found), the system re-executes the query for the header record and then for the part detail records, refreshing the displayed data without re-validating the form. The count-number entry section is locked to prevent modification.

**Step 2 - Action button availability is determined**
The system checks whether an adjustment number has already been generated for the current count, whether the count was loaded by entering its count number directly, and whether the stock-taken-by field is blank. When all three conditions confirm the count is open and unprocessed, the Report, Generate Adjustment, Export to Excel, and Generate buttons are enabled and made navigable, the detail part section is opened for editing, and the Save button is enabled. In any other case (new count, already adjusted, or loaded via direct count-number entry), all those action buttons are disabled and non-navigable, the detail section is locked for data entry, and the Save button is disabled.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Count adjustment and load-state check | Button state - WHEN-NEW-BLOCK-INSTANCE on PH_INVENTORY's own condition (adj_num IS NULL AND nb_inv_no IS NOT NULL AND stock_taken_by IS NULL) | When focus enters the inventory header block. | Ensures action buttons (report, generate adjustment, export) are only available when the count is in the correct state for those actions, and prevents saving or editing when inappropriate. | Action buttons disabled and detail section locked when the count is already adjusted or in an inappropriate state. |

**Step 3 - Navigation boundaries are enforced within the inventory header record list**
When the user presses the Down arrow key on the inventory header, the system checks whether the current record is a newly inserted (last) row. If so, the user is informed that no further records exist below and navigation stops. If not, the cursor moves to the next record. When the user presses the Up arrow key, the system checks whether the cursor is on the first record. If so, the user is informed that no further records exist above and navigation stops. If not, the cursor moves to the previous record.

*Business outcomes (errors, warnings, success, and status):*
- **BR-010-WS-01** - Down navigation at boundary - *"This is the Last Row"* - displayed when the user attempts to navigate down past the last record in the inventory header list; navigation stops.
- **BR-010-WS-02** - Up navigation at boundary - *"This is the first Row"* - displayed when the user attempts to navigate up from the first record in the inventory header list; navigation stops.

---

---

---

---

#### Requirement ID: BR-011

**Requirement Title:** Physical Inventory Header Record - Audit and System Field Population on Save

**Business Description:**
When a new physical inventory count header record is saved for the first time, the system automatically populates all system-maintained fields before the record is written to the database. This includes the dealer, location, financial area, parent group, creation timestamp, the user who created the record, the name of the employee who took the stock count, and the composite bin-location range codes assembled from the individual bin-segment fields entered by the user.

**Actors:** Stock Controller (system-triggered on first save)

**Preconditions:**
- The user has entered count criteria and initiated a save of a new physical inventory count header.

**Main Flow:**

**Step 1 - System-maintained header fields are populated from session context**
Immediately before the header record is inserted into the database, the system copies the current session's dealer, location, financial area, and parent group identifiers into the header record, sets the creation timestamp to the current date and time, records the current user's name as the creator, copies the name of the employee who took the stock from the adjustment details panel, and sets the count date to today's date.

**Step 2 - Composite bin-location range codes are assembled**
The system assembles the bin-location range codes by concatenating the individual bin-segment fields entered by the user: the "from" bin-location code is built from bin segments 1-5 (each padded to two characters), and the "to" bin-location code is built from bin segments 21-25 in the same way. The assembled codes are stored in the header record.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Created By (`CREATED_BY`) | Auto-populated | Character | 8 | N/A | Current session user name | New header record being saved | System-set; not user-editable | N/A |
| Created Date (`CREATED_DATE`) | Auto-populated | Datetime | DD-MM-YYYY HH24:MI | N/A | Current system timestamp | New header record being saved | System-set; not user-editable | N/A |
| Bin Location From (`BIN_LOC_CD`) | Auto-populated | Character | 10 | N/A | Concatenation of 5 two-character bin segment fields (1-5) | Bin segment fields entered by user | System-assembled from individual bin segment entries | N/A |
| Bin Location To (`BIN_LOC_CD_TO`) | Auto-populated | Character | 10 | N/A | Concatenation of 5 two-character bin segment fields (21-25) | Bin segment fields entered by user | System-assembled from individual bin segment entries | N/A |
| Count Date (`INV_DATE`) | Auto-populated | Datetime | DD-MM-YYYY | N/A | Current system date | New header record being saved | System-set to today's date; not user-editable at insert | N/A |

---

---

---

---

#### Requirement ID: BR-012

**Requirement Title:** Physical Inventory Header Record - Modification Audit Stamp

**Business Description:**
When a previously saved physical inventory count header record is modified and saved again, the system automatically records who made the change and when, providing a complete audit trail of modifications to count header records.

**Actors:** Stock Controller (system-triggered on header record update)

**Preconditions:**
- A physical inventory count header record already exists and has been queried into the form.
- The user has made at least one change to the header record and initiated a save.

**Main Flow:**

**Step 1 - Modification audit fields are populated before the update is written**
Immediately before the updated header record is saved to the database, the system records the current user's name in the modified-by field and sets the modification timestamp to the current date and time.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Modified By (`MODIFIED_BY`) | Auto-populated | Character | 8 | N/A | Current session user name | Existing header record being updated | System-set; not user-editable | N/A |
| Modified Date (`MODIFIED_DATE`) | Auto-populated | Datetime | DD-MM-YYYY HH24:MI | N/A | Current system timestamp | Existing header record being updated | System-set; not user-editable | N/A |

---

---

---

---

#### Requirement ID: BR-013

**Requirement Title:** Physical Inventory Header Record - Post-Query Display Setup

**Business Description:**
After a physical inventory count header record is loaded from the database, the system prepares the screen display by splitting the stored composite bin-location range codes back into their individual segment fields, setting a default stock-adjustment basis if none was saved, and controlling which action buttons are available based on whether an adjustment has already been generated for the count.

**Actors:** Stock Controller (system-triggered after header record query)

**Preconditions:**
- A physical inventory count header record has been retrieved from the database into the form.

**Main Flow:**

**Step 1 - Bin-location range segments are populated from the stored composite code**
The system reads the composite bin-location "from" code and extracts each of its five two-character segments into the individual "Bin Location From" segment fields displayed on screen. It performs the same split for the bin-location "to" code into its five corresponding segments.

**Step 2 - Default stock-adjustment basis is applied if none is stored**
If the retrieved header record does not have a stock-adjustment basis value, the system defaults it to "Current stock" so that difference quantity calculations use the current stock level.

**Step 3 - Action button state is set based on adjustment completion**
If the retrieved header record already has a stock-taken-by value - indicating the count has been through the adjustment process - the Generate Adjustment, Export to Excel, Print, and Generate buttons are all disabled, preventing the user from re-processing a completed count. If the record does not have a stock-taken-by value, the Print button is enabled and navigable.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Bin Location 1 From (`BIN_LOC_CD_11`) | Auto-populated | Character | 2 | N/A | Characters 1-2 of stored bin-location-from code | Header record queried | System-derived from stored composite code | N/A |
| Bin Location 2 From (`BIN_LOC_CD_12`) | Auto-populated | Character | 2 | N/A | Characters 3-4 of stored bin-location-from code | Header record queried | System-derived from stored composite code | N/A |
| Bin Location 3 From (`BIN_LOC_CD_13`) | Auto-populated | Character | 2 | N/A | Characters 5-6 of stored bin-location-from code | Header record queried | System-derived from stored composite code | N/A |
| Bin Location 4 From (`BIN_LOC_CD_14`) | Auto-populated | Character | 2 | N/A | Characters 7-8 of stored bin-location-from code | Header record queried | System-derived from stored composite code | N/A |
| Bin Location 5 From (`BIN_LOC_CD_15`) | Auto-populated | Character | 2 | N/A | Characters 9-10 of stored bin-location-from code | Header record queried | System-derived from stored composite code | N/A |
| Bin Location 1 To (`BIN_LOC_CD_21`) | Auto-populated | Character | 2 | N/A | Characters 1-2 of stored bin-location-to code | Header record queried | System-derived from stored composite code | N/A |
| Bin Location 2 To (`BIN_LOC_CD_22`) | Auto-populated | Character | 2 | N/A | Characters 3-4 of stored bin-location-to code | Header record queried | System-derived from stored composite code | N/A |
| Bin Location 3 To (`BIN_LOC_CD_23`) | Auto-populated | Character | 2 | N/A | Characters 5-6 of stored bin-location-to code | Header record queried | System-derived from stored composite code | N/A |
| Bin Location 4 To (`BIN_LOC_CD_24`) | Auto-populated | Character | 2 | N/A | Characters 7-8 of stored bin-location-to code | Header record queried | System-derived from stored composite code | N/A |
| Bin Location 5 To (`BIN_LOC_CD_25`) | Auto-populated | Character | 2 | N/A | Characters 9-10 of stored bin-location-to code | Header record queried | System-derived from stored composite code | N/A |
| Stock Adjustment On (`STKADJ_ON`) | Auto-populated | Character list | N/A | N/A | `C` = Current stock (defaulted when null) | Header record queried | Defaulted to `C` when not stored; governs difference quantity calculation | N/A |

---

---

---

---

#### Requirement ID: BR-014

**Requirement Title:** Stock Taken By - Null Check Validation

**Business Description:**
When the stock-taken-by field on the inventory header section is validated, the system checks whether the name of the person who took the stock count is required at that point. The check is only enforced when the user has initiated an adjustment action; in all other situations the field is not required. This prevents an adjustment from being submitted without identifying the responsible stock counter.

**Actors:** Stock Controller

**Preconditions:**
- The user is validating the inventory header section after initiating a stock adjustment action.

**Main Flow:**

**Step 1 - Name of stock counter checked when adjustment is in progress**
When the stock-taken-by field is validated and the adjustment action has been triggered, the system confirms the field is not blank. If it is blank, the system prevents the user from proceeding.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-007](#sp-007)) - GENERAL.CHECK_NULL - checks that a required field has been entered; if the field is blank, it displays a standard mandatory-field error and stops the current operation.
    * **Step 1** - Receive the field value and the business label for the field.
    * **Step 2** - Check whether the field value is null.
    * **Step 3** - If null, display a mandatory-field error message citing the field label and raise a trigger failure; otherwise allow the operation to continue.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Stock counter name required when adjustment is in progress | Mandatory-field check - GENERAL.CHECK_NULL [SP-007] on B_ADJ.STOCK_TAKEN_BY | When the user validates the stock-taken-by field during an adjustment action. | Ensures every stock adjustment identifies the person responsible for the physical count, providing accountability and an audit trail. | Mandatory-field error shown for "Name" - operation stopped. |

**Alternative Flows:**
- **BR-014-AF-01** - (from Step 1) No adjustment action is in progress when the field is validated: the null check is skipped entirely and no error is raised regardless of whether the field is blank.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Stock Taken By (`STOCK_TAKEN_BY`) | Conditional - when adjustment action is in progress | Character | 8 | N/A | Employee code | Adjustment action triggered | Must not be blank when adjustment is in progress | Mandatory-field error for "Name" |

---

---

---

---

#### Requirement ID: BR-015

**Requirement Title:** Count Date - Back-Date Validation

**Business Description:**
When the user enters or changes the count date for a new physical inventory count, the system verifies that the date does not violate back-dating rules. If the entered date falls outside the permitted period - for example, before the last document date already recorded for the physical inventory document type in the current financial year - the system blocks the entry and displays an explanation. The back-date check is performed only for new counts; when opening an existing count (loaded by count number), the date is already committed and is not re-validated.

**Actors:** Stock Controller

**Preconditions:**
- A new physical inventory count is being created (no existing count number has been entered).
- The user has entered a value in the count date field and is moving to the next field.

**Main Flow:**

**Step 1 - Count date is validated against the back-dating policy**
For new counts, the system calls the back-date validation routine, passing the current dealer, principal, location, financial area, document type (physical inventory), financial year, and the date entered. If the routine returns an error message, the user is shown that message and the operation is stopped.

*Procedures called:*
- **PK_VALIDATE_BACK_DATE.GET_LAST_DOC_DATE** ([SP-014](#sp-014)) - PK_VALIDATE_BACK_DATE.GET_LAST_DOC_DATE - checks whether the proposed count date complies with the back-dating policy for physical inventory documents in the current financial year; returns an error message when the date is out of compliance.
    * **Step 1** - Accept the dealer, principal, location, financial area, document type, financial year, and proposed date.
    * **Step 2** - Retrieve the most recent document date for physical inventory documents in the current financial year for the given dealer and location.
    * **Step 3** - Apply the back-dating business rule to check whether the proposed date is within the allowed range relative to the last document date.
    * **Step 4** - If the proposed date violates the policy, return the relevant error message text; otherwise return no message.
    * **Step 5** - Return the result to the caller.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Count date back-date compliance | Back-date validation - PK_VALIDATE_BACK_DATE.GET_LAST_DOC_DATE [SP-014] | When the user moves off the count date field during new count creation. | Ensures physical inventory counts are not dated earlier than the back-dating policy allows, maintaining the integrity of the sequential document history. | Error message returned by the validation routine is displayed; trigger failure raised and cursor remains on the count date field. |

**Alternative Flows:**
- **BR-015-AF-01** - (from Step 1) An existing count number has already been entered, meaning the count is being retrieved rather than created: the date validation is skipped entirely.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Count Date (`INV_DATE`) | Mandatory | Date | DD-MM-YYYY | N/A | Date entered by user | New count being created (no count number entered) | Must comply with back-dating policy for physical inventory document type in the current financial year | Error message from back-date validation routine |

---

---

---

---

#### Requirement ID: BR-016

**Requirement Title:** Store Selection - Mandatory Validation

**Business Description:**
When the user moves off the Store field on the physical inventory header section, the system checks that a store has been selected. The store is a required field because the physical inventory count is always performed for a specific store; without a store selection it is not possible to identify which inventory to count.

**Actors:** Stock Controller

**Preconditions:**
- The user is working on the physical inventory header section.

**Main Flow:**

**Step 1 - Store field is confirmed as not blank**
When the user leaves the Store field, the system checks that a store code has been selected. If the field is blank, the user is shown a mandatory-field error and must select a store before proceeding.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-007](#sp-007)) - GENERAL.CHECK_NULL - checks that the Store field has been filled; if blank, shows a mandatory-field error and stops the operation.
    * **Step 1** - Receive the field value and the business label for the field.
    * **Step 2** - Check whether the field value is null.
    * **Step 3** - If null, display a mandatory-field error message for "Stores Code" and raise a trigger failure; otherwise allow the operation to continue.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Store selection required | Mandatory-field check - GENERAL.CHECK_NULL [SP-007] on PH_INVENTORY.STORES_CD | When the user moves off the Store field. | A store must be selected before any count filter or population step can proceed. | Mandatory-field error for "Stores Code" - operation stopped. |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Store (`STORES_CD`) | Mandatory | Character list | 7 | Store list (populated from GM_STORE) | Store code and description | Physical inventory header section being filled | Must not be blank | Mandatory-field error for "Stores Code" |

---

---

---

---

#### Requirement ID: BR-017

**Requirement Title:** Part Entry Mode - Mandatory Validation and Header Filter State Control

**Business Description:**
When the user selects the part entry mode and moves to the next field, the system first confirms that a mode has been selected, then configures which header filter fields are available based on the chosen mode. When "All parts" mode is selected, all inventory filter fields on the header - such as category, ABC, FMS, and XYZ indicators, and the rest of the filter criteria - are enabled for use. When a mode other than "All parts" is selected, those filter fields are disabled, restricting the count population to the mode-specific logic rather than a filtered subset.

**Actors:** Stock Controller

**Preconditions:**
- The user is working on the physical inventory header section and has moved focus to the part entry mode field.

**Main Flow:**

**Step 1 - Part entry mode is confirmed as not blank**
When the user validates the part entry mode field, the system checks that a mode has been selected. If no mode is selected, a mandatory-field error is displayed.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-007](#sp-007)) - GENERAL.CHECK_NULL - checks that the Part Entry Mode field has been filled; if blank, shows a mandatory-field error and stops the operation.
    * **Step 1** - Receive the field value and the business label for the field.
    * **Step 2** - Check whether the field value is null.
    * **Step 3** - If null, display a mandatory-field error message for "Part Entry Mode" and raise a trigger failure; otherwise allow the operation to continue.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Part entry mode required | Mandatory-field check - GENERAL.CHECK_NULL [SP-007] on PH_INVENTORY.ENTRY_MODE (WHEN-VALIDATE-ITEM) | When the user moves off the Part Entry Mode field. | Ensures the count population method is explicitly chosen before any filters are set or the count is populated. | Mandatory-field error for "Part Entry Mode" - operation stopped. |

**Step 2 - Header filter fields enabled or disabled based on chosen mode**
After the user moves off the part entry mode field with a valid selection, the system calls the header-enable or header-disable routine depending on the chosen mode. For "All parts" mode, all filter fields are enabled and the cursor moves to the category filter. For any other mode, filter fields are disabled and the cursor moves to the category filter.

*Procedures called:*
- **ENABLE_HEADER** ([SP-002](#sp-002)) - ENABLE_HEADER - enables or disables all physical inventory header filter fields based on the flag passed; when called with enabled mode, all filters become navigable and editable; when called with disabled mode, all filters are locked.
    * **Step 1** - Enable and make navigable each header filter field (category, ABC, FMS, XYZ, margin category, price type, stock quantity filter, bin-location status, part number from/to, bin-location from/to, order-by, and Populate button) when the enable flag is true; otherwise disable and lock all those fields.
    * **Step 2** - Confirm that all header filter fields are in the correct state for the chosen mode.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Header filter availability depends on entry mode | Header state - ENABLE_HEADER [SP-002] called from KEY-NEXT-ITEM on PH_INVENTORY.ENTRY_MODE | When the user moves off the Part Entry Mode field with a valid selection. | Ensures the available filter criteria match the chosen entry mode, preventing the user from applying filters that are not relevant to the selected population method. | N/A - this step configures field state; no failure condition. |

**Alternative Flows:**
- **BR-017-AF-01** - (from Step 2) "All parts" mode (`A`) is selected: `ENABLE_HEADER` is called with the enable flag, all filter fields are activated, and the cursor moves to the category filter.
- **BR-017-AF-02** - (from Step 2) Any mode other than "All parts" is selected: `ENABLE_HEADER` is called with the disable flag, all filter fields are locked, and the cursor moves to the category filter.
- **BR-017-AF-03** - (KEY-NEXT-ITEM on count number field - see also BR-003) The same KEY-NEXT-ITEM trigger object also governs navigation from the physical inventory count number entry field. When the user moves off that field with a value entered, the system queries whether the count exists for the current dealer; if not found it displays *"Physical Inventory Number not found"* and stops navigation. If a data-width or compatibility error occurs during the lookup, the system displays *"Width problem/Incompatible data while retrieving count"* and stops navigation. If any other unexpected error occurs, the system displays *"Execution failed while retrieving count"* (with the database error appended) and stops navigation. Full process detail is documented in BR-003.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Part Entry Mode (`ENTRY_MODE`) | Mandatory | Character list | 1 | N/A | `A` = All parts; other modes as configured | Physical inventory header section being filled | Must not be blank | Mandatory-field error for "Part Entry Mode" |

---

---

---

---

#### Requirement ID: BR-018

**Requirement Title:** Price Range Filter - Validity Validation

**Business Description:**
When the user enters price range filter values on the physical inventory header, the system enforces two rules: a price type must be selected before a price range value is entered, and no price range boundary may be a negative number. The "greater than or equal to" boundary must satisfy both rules independently, and additionally the "less than or equal to" boundary must not be lower than the "greater than or equal to" boundary. Together these rules ensure the price range filter is meaningful before the count list is populated.

**Actors:** Stock Controller

**Preconditions:**
- The user is setting up filter criteria on the physical inventory header and is in the price range fields.

**Main Flow:**

**Step 1 - Price type is required before a minimum price value is entered**
When the user enters a value in the "greater than or equal to" price field, the system checks that a price type has already been selected. If no price type is selected, the user sees an error and must first select a price type.

**Step 2 - Minimum price boundary must not be negative**
The system also checks that the value entered in the "greater than or equal to" field is not less than zero. A negative price range boundary is not a valid business value.

**Step 3 - Price type is required before a maximum price value is entered**
When the user enters a value in the "less than or equal to" price field, the same price-type check is applied.

**Step 4 - Maximum price boundary must not be negative and must not be below the minimum**
The system checks that the "less than or equal to" value is not negative, and also that it is not lower than the already-entered "greater than or equal to" value. An upper boundary below the lower boundary produces no valid range.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Price type required before minimum boundary | Price type prerequisite - WHEN-VALIDATE-ITEM on PH_INVENTORY.GREATER_THAN own condition (PRICE IS NULL AND GREATER_THAN IS NOT NULL) | When the user moves off the minimum price field after entering a value. | Ensures a valid price type is chosen before the system can apply a price filter, making the filter meaningful. | *"Please Select the Price first"* - trigger failure; cursor remains on minimum price field. |
| Minimum price not negative | Non-negative check - WHEN-VALIDATE-ITEM on PH_INVENTORY.GREATER_THAN own condition (GREATER_THAN < 0) | When the user moves off the minimum price field. | Prevents a negative number from being used as a price boundary, which has no business meaning. | *"Part price cannot be less than zero"* - trigger failure. |
| Price type required before maximum boundary | Price type prerequisite - WHEN-VALIDATE-ITEM on PH_INVENTORY.LESS_THAN own condition (PRICE IS NULL AND LESS_THAN IS NOT NULL) | When the user moves off the maximum price field after entering a value. | Same as for the minimum boundary. | *"Please Select the Price first"* - trigger failure. |
| Maximum price not negative | Non-negative check - WHEN-VALIDATE-ITEM on PH_INVENTORY.LESS_THAN own condition (LESS_THAN < 0) | When the user moves off the maximum price field. | Prevents a negative upper boundary. | *"Price Cannot be less than zero"* - trigger failure. |
| Maximum price must not be below minimum | Range validity - WHEN-VALIDATE-ITEM on PH_INVENTORY.LESS_THAN own condition (LESS_THAN < GREATER_THAN) | When the user moves off the maximum price field and a minimum boundary is already set. | Ensures the price range contains at least one valid price point; a reversed range would return no parts. | *"Enter a Valid Price Range"* - trigger failure. |

*Business outcomes (errors, warnings, success, and status):*
- **BR-018-ES-01** - Price type not selected before price boundary entered - *"Please Select the Price first"*; user must select a price type first.
- **BR-018-ES-02** - Negative minimum price entered - *"Part price cannot be less than zero"*; user must enter a non-negative value.
- **BR-018-ES-03** - Maximum price not negative but is below minimum - *"Enter a Valid Price Range"*; user must correct the range.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Price Type (`PRICE`) | Conditional - required when price range is entered | Character list | 3 | N/A | Price type options (e.g. Purchase, Local Sell, Outside Sell, MRP, Landed Cost) | N/A | Must be selected before a price boundary is entered | *"Please Select the Price first"* |
| Greater Than or Equal To (`GREATER_THAN`) | Optional | Numeric | 23 | N/A | N/A | Price type selected (when value entered) | Must be ≥ 0 when entered | *"Part price cannot be less than zero"* |
| Less Than or Equal To (`LESS_THAN`) | Optional | Numeric | 23 | N/A | N/A | Price type selected (when value entered) | Must be ≥ 0 and ≥ GREATER_THAN when entered | *"Price Cannot be less than zero"* / *"Enter a Valid Price Range"* |

---

---

---

---

#### Requirement ID: BR-019

**Requirement Title:** Part Number Range Filter - Validation and Populate Button State

**Business Description:**
When the user enters part number range filter values on the physical inventory header, the system validates that the range is logically consistent: if a starting part number is entered, the ending part number becomes required; if an ending part number is entered without a starting number, an error is shown. Additionally, for the principal dealer account, the entered part numbers are verified to exist in the parts master. After each part-number field is validated, the system rechecks whether both ends of the range have been provided and enables the Populate button when they have, or disables it otherwise.

**Actors:** Stock Controller

**Preconditions:**
- The user is setting up filter criteria on the physical inventory header and is entering part number range values.

**Main Flow:**

**Step 1 - Starting part number is validated and Populate button state is refreshed**
When the user moves off the starting part number field, the system checks whether the entered part number exists in the parts master (applicable only for the principal dealer account). If the part number is not found, the user is informed. After the validation, the system rechecks whether both a starting and ending part number are present (or both bin-location range fields are present) and enables or disables the Populate button accordingly.

*Procedures called:*
- **ENABLE_POP_BTN** ([SP-003](#sp-003)) - ENABLE_POP_BTN - checks whether both the part number range fields (from and to) or both the bin-location range fields (from and to) are filled, and enables the Populate button if so; otherwise disables it.
    * **Step 1** - Check whether both the starting and ending part number fields are filled, or both the starting and ending bin-location fields are filled.
    * **Step 2** - If either complete pair is present, enable and make navigable the Populate button.
    * **Step 3** - If neither complete pair is present, disable the Populate button.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Starting part number existence (principal account only) | Part existence - WHEN-VALIDATE-ITEM on PH_INVENTORY.PART_NUMBER own condition (principal = 1, SELECT from PM_PART) | When the user moves off the starting part number field. | Ensures the starting part number filter references a real part in the parts catalogue (for the principal dealer). | *"Invalid Part Number"* - trigger failure; cursor remains on the part number field. |
| Populate button availability | Button state - ENABLE_POP_BTN [SP-003] called from WHEN-VALIDATE-ITEM on PH_INVENTORY.PART_NUMBER | After starting part number is validated. | The Populate button should only be available when a complete range has been specified, preventing a partial-range population attempt. | N/A - button is enabled or disabled; no error message for this step. |

**Step 2 - Ending part number is validated and Populate button state is refreshed**
When the user moves off the ending part number field, the system first checks whether the starting part number is present: if it is, the ending part number is required; if no starting number was entered but an ending number was entered, an error is shown. When both are present, the part existence check is applied for the principal dealer account. The Populate button state is then rechecked.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-007](#sp-007)) - GENERAL.CHECK_NULL - checks that the ending part number field is not blank when a starting part number has been entered; if blank, shows a mandatory-field error and stops the operation.
    * **Step 1** - Receive the field value and the business label for the field.
    * **Step 2** - Check whether the field value is null.
    * **Step 3** - If null, display a mandatory-field error message for "To Part Number" and raise a trigger failure; otherwise allow the operation to continue.
- **ENABLE_POP_BTN** ([SP-003](#sp-003)) - ENABLE_POP_BTN - rechecks Populate button availability after the ending part number is validated (same logic as Step 1 above).
    * **Step 1** - Check whether both the starting and ending part number fields are filled, or both the starting and ending bin-location fields are filled.
    * **Step 2** - If either complete pair is present, enable and make navigable the Populate button.
    * **Step 3** - If neither complete pair is present, disable the Populate button.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Ending part number required when starting part number is entered | Mandatory pair - GENERAL.CHECK_NULL [SP-007] on PH_INVENTORY.TO_PART_NUM | When the user moves off the ending part number field and a starting part number is present. | Ensures the part number range filter is complete; a starting number without an ending number is an ambiguous filter. | Mandatory-field error for "To Part Number" - trigger failure. |
| Ending part number not allowed without starting part number | Range prerequisite - WHEN-VALIDATE-ITEM on PH_INVENTORY.TO_PART_NUM own condition (PART_NUMBER IS NULL AND TO_PART_NUM IS NOT NULL) | When the user moves off the ending part number field without having entered a starting part number. | Prevents an upward-range-only filter which is not a supported configuration. | *"Valid From Part Number is required for entering To Part Number"* - trigger failure. |

**Alternative Flows:**
- **BR-019-AF-01** - (from Step 1) Starting part number is blank: no existence check is run; the Populate button state is still refreshed.
- **BR-019-AF-02** - (from Step 1) The current dealer is not the principal account: no part-existence check is run; only the Populate button state is refreshed.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Part Number From (`PART_NUMBER`) | Optional | Character | 15 | N/A | Part number | N/A | If entered, must exist in parts master for principal account | *"Invalid Part Number"* |
| Part Number To (`TO_PART_NUM`) | Conditional - required when Part Number From is entered | Character | 15 | N/A | Part number | Part Number From must be entered first | Required when starting part number is present; must exist in parts master for principal account | *"Valid From Part Number is required for entering To Part Number"* / Mandatory-field error |

---

---

---

---

#### Requirement ID: BR-020

**Requirement Title:** Bin Location Range Filter - Validation and Populate Button State

**Business Description:**
When the user enters bin location range filter values on the physical inventory header, the system validates that the range is complete and logically consistent: if a starting bin location is entered, the ending bin location becomes required; if an ending bin location is entered without a starting bin location, an error is shown. After each bin-location field is validated, the system rechecks whether both ends of the range are present and enables or disables the Populate button accordingly.

**Actors:** Stock Controller

**Preconditions:**
- The user is setting up filter criteria on the physical inventory header and is entering bin location range values.

**Main Flow:**

**Step 1 - Starting bin location validated and Populate button state is refreshed**
When the user moves off the starting bin location field, the system refreshes the Populate button state based on whether a complete part number range or a complete bin location range is now present.

*Procedures called:*
- **ENABLE_POP_BTN** ([SP-003](#sp-003)) - ENABLE_POP_BTN - checks whether both part number range fields or both bin-location range fields are filled, and enables the Populate button if so; otherwise disables it.
    * **Step 1** - Check whether both the starting and ending part number fields are filled, or both the starting and ending bin-location fields are filled.
    * **Step 2** - If either complete pair is present, enable and make navigable the Populate button.
    * **Step 3** - If neither complete pair is present, disable the Populate button.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Populate button availability | Button state - ENABLE_POP_BTN [SP-003] called from WHEN-VALIDATE-ITEM on PH_INVENTORY.BIN_LOC_FROM | When the user moves off the starting bin location field. | The Populate button should only be available when a complete bin location range or part number range is specified. | N/A - button is enabled or disabled; no error message. |

**Step 2 - Ending bin location validated, Populate button state refreshed, and cursor advanced**
When the user moves off the ending bin location field (via KEY-NEXT-ITEM or WHEN-VALIDATE-ITEM), the system validates the field and then refreshes the Populate button state, and advances focus to the Order By field.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-007](#sp-007)) - GENERAL.CHECK_NULL - checks that the ending bin location is not blank when a starting bin location has been entered; if blank, shows a mandatory-field error and stops the operation.
    * **Step 1** - Receive the field value and the business label for the field.
    * **Step 2** - Check whether the field value is null.
    * **Step 3** - If null, display a mandatory-field error message for "To Bin Location" and raise a trigger failure; otherwise allow the operation to continue.
- **ENABLE_POP_BTN** ([SP-003](#sp-003)) - ENABLE_POP_BTN - rechecks Populate button availability after the ending bin location is validated.
    * **Step 1** - Check whether both part number range fields or both bin-location range fields are filled.
    * **Step 2** - Enable the Populate button if either complete pair is present; otherwise disable it.
    * **Step 3** - Return the button state to the correct setting.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Ending bin location required when starting bin location is entered | Mandatory pair - GENERAL.CHECK_NULL [SP-007] on PH_INVENTORY.BIN_LOC_TO | When the user moves off the ending bin location field and a starting bin location is present. | Ensures the bin location range is complete; a starting location without an ending location is an ambiguous filter. | Mandatory-field error for "To Bin Location" - trigger failure. |
| Ending bin location not allowed without starting bin location | Range prerequisite - WHEN-VALIDATE-ITEM on PH_INVENTORY.BIN_LOC_TO own condition (BIN_LOC_FROM IS NULL AND BIN_LOC_TO IS NOT NULL) | When the user moves off the ending bin location field without having entered a starting bin location. | Prevents an upward-range-only bin location filter. | *"Valid From Bin Location is required for entering To Bin Location"* - trigger failure. |

*Business outcomes (errors, warnings, success, and status):*
- **BR-020-ES-01** - Ending bin location entered without starting bin location - *"Valid From Bin Location is required for entering To Bin Location"*; user must enter a starting bin location first.

**Alternative Flows:**
- **BR-020-AF-01** - (from Step 2) No starting bin location is present and the ending bin location field is also blank: neither error fires; Populate button state is refreshed and focus moves to Order By.
- **BR-020-AF-02** - (KEY-NEXT-ITEM on count number field - see also BR-003) The same KEY-NEXT-ITEM trigger object also governs navigation from the physical inventory count number entry field. When the user moves off that field with a value entered, the system queries whether the count exists for the current dealer; if not found it displays *"Physical Inventory Number not found"* and stops navigation. If a data-width or compatibility error occurs during the lookup, the system displays *"Width problem/Incompatible data while retrieving count"* and stops navigation. If any other unexpected error occurs, the system displays *"Execution failed while retrieving count"* (with the database error appended) and stops navigation. Full process detail is documented in BR-003.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Store Bin Location From (`BIN_LOC_FROM`) | Optional | Character | 10 | N/A | Bin location code | N/A | No existence check; range pair must be complete if either end is entered | N/A |
| Store Bin Location To (`BIN_LOC_TO`) | Conditional - required when Bin Location From is entered | Character | 10 | N/A | Bin location code | Bin Location From must be entered first | Required when starting bin location is present; cannot be entered without a starting value | *"Valid From Bin Location is required for entering To Bin Location"* / Mandatory-field error |

---

---

---

---

#### Requirement ID: BR-021

**Requirement Title:** Bin Location Segment Label Update on Bin Order Change

**Business Description:**
When the user changes the bin location ordering scheme on the physical inventory header, the system immediately relabels the bin location segment display fields on both the header filter and the part detail section to reflect the new ordering terminology. This keeps the on-screen labels aligned with the chosen bin order so the user is never confused about which physical location segments the fields correspond to.

**Actors:** Stock Controller

**Preconditions:**
- The Physical Inventory form is open and the user has changed the Bin Location ordering selection.

**Main Flow:**

**Step 1 - Bin location segment field labels are updated to match the new bin order**
When the bin order selection changes, the system reads the label text for the newly selected order option and applies it as a label prefix to the bin-segment-from fields on the header and to the bin-location column on the part detail section, appending " From" and " To" as appropriate.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Bin Location Order (`BIN_ORDER`) | Optional | Character list | 8 | N/A | Bin order options (e.g. Bin Location level 1, 2, 3...) | N/A | No validation; selection only governs display labels | N/A |

---

---

---

---

#### Requirement ID: BR-022

**Requirement Title:** Order By Field - Navigation to Populate or Part Detail

**Business Description:**
When the user moves off the Order By field on the physical inventory header, the system directs the cursor to the most logical next target: if the Populate button is currently enabled (meaning a complete part or bin location range has been entered), the cursor moves to the Populate button so the user can proceed immediately. If the Populate button is disabled, the cursor advances directly to the part number field in the part detail section.

**Actors:** Stock Controller

**Preconditions:**
- The user has completed entry in the Order By field and is moving to the next field.

**Main Flow:**

**Step 1 - Cursor is directed to Populate button or part detail based on button state**
The system checks whether the Populate button is currently enabled. If it is, focus moves to the Populate button. If not, focus moves to the part number field in the part detail section.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Order By (`ORDER_BY`) | Optional | Character list | N/A | N/A | `1` = Part Number; `2` = Bin Location | N/A | No validation; governs the sort order of the populated part list | N/A |

---

---

---

---

#### Requirement ID: BR-023

**Requirement Title:** Stock Adjustment Basis Change - Difference Quantity Recalculation for All Parts

**Business Description:**
When the user changes the stock adjustment basis (between counting against the stock quantity at the time of generation or against the current stock quantity), the system immediately recalculates the difference quantity for every part row in the detail list to reflect the new basis. This ensures the difference quantities shown on screen are always consistent with the basis the user has selected, without requiring the user to manually trigger a recalculation.

**Actors:** Stock Controller

**Preconditions:**
- The Physical Inventory form is open and part detail records have been populated.
- The user has changed the Stock Adjustment On selection on the inventory header.

**Main Flow:**

**Step 1 - Difference quantity is recalculated for every part row using the new basis**
The system navigates to the part detail block, moves to the first record, and loops through every row recalculating the difference quantity for each part. For each row, the difference is computed as the physical quantity entered minus the relevant stock quantity (stock at generation or current stock, depending on the new selection).

*Procedures called:*
- **CALC_DIFF_QTY** ([SP-001](#sp-001)) - CALC_DIFF_QTY - recalculates the difference between the physical quantity counted and the system stock quantity for the current part row, using the active stock-adjustment basis.
    * **Step 1** - Determine whether the active stock-adjustment basis uses stock quantity at generation or current stock quantity.
    * **Step 2** - Compute the difference as the physical quantity entered minus the relevant stock quantity.
    * **Step 3** - Update the difference quantity field for the current part row.
    * **Step 4** - If a positive difference exists and bin-location management is enabled, enable the physical bin location field for the current row; otherwise lock it.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Difference quantity recalculated for every row | Recalculation - CALC_DIFF_QTY [SP-001] called from WHEN-LIST-CHANGED on PH_INVENTORY.STKADJ_ON for each row | When the user changes the Stock Adjustment On selection. | Ensures the displayed variance figures are always current and match the chosen adjustment basis, so the user can confidently review and act on the count results. | N/A - calculation only; no user-visible failure at this step. |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Stock Adjustment On (`STKADJ_ON`) | Optional | Character list | N/A | N/A | `C` = Current stock; `S` = Stock at generation | Part detail records populated | Selection governs the stock quantity baseline for difference calculation | N/A |
| Difference Quantity (`DIFF_QTY`) | Auto-populated | Numeric | 9,99,99,999.000 | N/A | Physical quantity minus selected stock quantity, per row | Physical quantity and stock quantity present for the row | Read-only; recalculated by system | N/A |

---

---

---

---

#### Requirement ID: BR-024

**Requirement Title:** Bin Location Segment Range - Pair Completeness Validation

**Business Description:**
When the user enters individual bin location segment values (Area, Row, Rack, Shelf, Bin) for the "to" end of the bin location range filter on the physical inventory header, the system ensures that each "to" segment is paired with a corresponding "from" segment. If a "from" segment has been entered, the matching "to" segment is required. If a "to" segment is entered without its "from" counterpart, an error is shown. This prevents a partial-segment range that would produce an undefined filter.

**Actors:** Stock Controller

**Preconditions:**
- The user is entering bin location segment values for the "to" range on the physical inventory header.

**Main Flow:**

**Step 1 - Area (To) segment is validated against Area (From)**
When the user moves off the Area "to" segment field: if the Area "from" segment is filled, the Area "to" segment is required; if Area "from" is blank but Area "to" has a value, an error is shown.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-007](#sp-007)) - GENERAL.CHECK_NULL - checks that the Area "to" segment is not blank when the Area "from" segment has been entered; if blank, shows a mandatory-field error and stops the operation.
    * **Step 1** - Receive the field value and the business label for the field.
    * **Step 2** - Check whether the field value is null.
    * **Step 3** - If null, display a mandatory-field error message for "To Area" and raise a trigger failure; otherwise allow the operation to continue.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Area "to" required when Area "from" is entered | Mandatory pair - GENERAL.CHECK_NULL [SP-007] on PH_INVENTORY.BIN_LOC_CD_21 | When user moves off Area "to" segment field. | Prevents an incomplete area range filter. | Mandatory-field error for "To Area" - trigger failure. |
| Area "to" not allowed without Area "from" | Range prerequisite - WHEN-VALIDATE-ITEM on PH_INVENTORY.BIN_LOC_CD_21 own condition | When user moves off Area "to" field with no Area "from". | Prevents a "to only" area segment entry that has no valid lower bound. | *"Valid From Area is required for entering To Area"* - trigger failure. |

**Step 2 - Row (To) segment is validated against Row (From)**
Same pair-completeness check as Step 1 applied to the Row bin location segment.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-007](#sp-007)) - GENERAL.CHECK_NULL - checks that the Row "to" segment is not blank when the Row "from" segment has been entered.
    * **Step 1** - Receive the field value and label.
    * **Step 2** - Check whether null.
    * **Step 3** - Show mandatory-field error for "To Row" and raise failure if null; otherwise continue.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Row "to" required when Row "from" is entered | Mandatory pair - GENERAL.CHECK_NULL [SP-007] on PH_INVENTORY.BIN_LOC_CD_22 | When user moves off Row "to" segment field. | Prevents an incomplete row range filter. | Mandatory-field error for "To Row" - trigger failure. |
| Row "to" not allowed without Row "from" | Range prerequisite - WHEN-VALIDATE-ITEM on PH_INVENTORY.BIN_LOC_CD_22 own condition | When user moves off Row "to" field with no Row "from". | Prevents a "to only" row segment entry. | *"Valid From Row is required for entering To Row"* - trigger failure. |

**Step 3 - Rack (To) segment is validated against Rack (From)**
Same pair-completeness check applied to the Rack bin location segment.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-007](#sp-007)) - GENERAL.CHECK_NULL - checks that the Rack "to" segment is not blank when the Rack "from" segment has been entered.
    * **Step 1** - Receive the field value and label.
    * **Step 2** - Check whether null.
    * **Step 3** - Show mandatory-field error for "To Rack" and raise failure if null; otherwise continue.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Rack "to" required when Rack "from" is entered | Mandatory pair - GENERAL.CHECK_NULL [SP-007] on PH_INVENTORY.BIN_LOC_CD_23 | When user moves off Rack "to" segment field. | Prevents an incomplete rack range filter. | Mandatory-field error for "To Rack" - trigger failure. |
| Rack "to" not allowed without Rack "from" | Range prerequisite - WHEN-VALIDATE-ITEM on PH_INVENTORY.BIN_LOC_CD_23 own condition | When user moves off Rack "to" field with no Rack "from". | Prevents a "to only" rack segment entry. | *"Valid From Rack is required for entering To Rack"* - trigger failure. |

**Step 4 - Shelf (To) segment is validated against Shelf (From)**
Same pair-completeness check applied to the Shelf bin location segment.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-007](#sp-007)) - GENERAL.CHECK_NULL - checks that the Shelf "to" segment is not blank when the Shelf "from" segment has been entered.
    * **Step 1** - Receive the field value and label.
    * **Step 2** - Check whether null.
    * **Step 3** - Show mandatory-field error for "To Shelf" and raise failure if null; otherwise continue.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Shelf "to" required when Shelf "from" is entered | Mandatory pair - GENERAL.CHECK_NULL [SP-007] on PH_INVENTORY.BIN_LOC_CD_24 | When user moves off Shelf "to" segment field. | Prevents an incomplete shelf range filter. | Mandatory-field error for "To Shelf" - trigger failure. |
| Shelf "to" not allowed without Shelf "from" | Range prerequisite - WHEN-VALIDATE-ITEM on PH_INVENTORY.BIN_LOC_CD_24 own condition | When user moves off Shelf "to" field with no Shelf "from". | Prevents a "to only" shelf segment entry. | *"Valid From Shelf is required for entering To Shelf"* - trigger failure. |

**Step 5 - Bin (To) segment is validated against Bin (From)**
Same pair-completeness check applied to the Bin bin location segment.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-007](#sp-007)) - GENERAL.CHECK_NULL - checks that the Bin "to" segment is not blank when the Bin "from" segment has been entered.
    * **Step 1** - Receive the field value and label.
    * **Step 2** - Check whether null.
    * **Step 3** - Show mandatory-field error for "To Bin" and raise failure if null; otherwise continue.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Bin "to" required when Bin "from" is entered | Mandatory pair - GENERAL.CHECK_NULL [SP-007] on PH_INVENTORY.BIN_LOC_CD_25 | When user moves off Bin "to" segment field. | Prevents an incomplete bin segment range filter. | Mandatory-field error for "To Bin" - trigger failure. |
| Bin "to" not allowed without Bin "from" | Range prerequisite - WHEN-VALIDATE-ITEM on PH_INVENTORY.BIN_LOC_CD_25 own condition | When user moves off Bin "to" field with no Bin "from". | Prevents a "to only" bin segment entry. | *"Valid From Bin is required for entering To Bin"* - trigger failure. |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Bin Location Area To (`BIN_LOC_CD_21`) | Conditional - required when Area From is entered | Character | 2 | N/A | Area code | Area From segment entered | Required when "from" pair is present; cannot be entered alone | *"Valid From Area is required for entering To Area"* |
| Bin Location Row To (`BIN_LOC_CD_22`) | Conditional - required when Row From is entered | Character | 2 | N/A | Row code | Row From segment entered | Required when "from" pair is present; cannot be entered alone | *"Valid From Row is required for entering To Row"* |
| Bin Location Rack To (`BIN_LOC_CD_23`) | Conditional - required when Rack From is entered | Character | 2 | N/A | Rack code | Rack From segment entered | Required when "from" pair is present; cannot be entered alone | *"Valid From Rack is required for entering To Rack"* |
| Bin Location Shelf To (`BIN_LOC_CD_24`) | Conditional - required when Shelf From is entered | Character | 2 | N/A | Shelf code | Shelf From segment entered | Required when "from" pair is present; cannot be entered alone | *"Valid From Shelf is required for entering To Shelf"* |
| Bin Location Bin To (`BIN_LOC_CD_25`) | Conditional - required when Bin From is entered | Character | 2 | N/A | Bin code | Bin From segment entered | Required when "from" pair is present; cannot be entered alone | *"Valid From Bin is required for entering To Bin"* |

---

---

---

---

#### Requirement ID: BR-025

**Requirement Title:** Populate Part Detail List for Physical Count

**Business Description:**
When the user clicks the Populate button after setting the inventory count filter criteria, the system retrieves the matching parts from the inventory and loads them into the part detail grid for counting. The system validates that a store has been selected and that at least one filter criterion - either a part number range or a bin location range - has been provided. Parts are retrieved according to the selected stock quantity filter (all stock, positive stock only, or zero-stock parts), and the list is sorted in the order chosen by the user. For each part retrieved, the system loads the part description, stock quantities, bin location, landed cost, and allocated quantities onto the detail screen. Once the part list is loaded, the header filter section is locked to prevent changes until the form is cleared, and the Populate button is disabled.

The Populate action is only available once the form has been initialised: on form open, the system sets all session control flags (`global.adj_click = N`, `global.gen_click = N`, `global.stk_adj = N`, `parameter.p_tax_flag = Y`, `parameter.p_commit_form = N`) and populates the Store dropdown from record group `Stores`, the Category dropdown from record group `Category`, the Margin Category dropdown from record group `margin_Category`, the Reason dropdown from record group `reason`, and the Employee dropdown from record group `emp`. If the consignee code cannot be retrieved at form open, the user sees *"Execution failed while fetching Consignee Code"* and the form does not complete loading. For dealers in the MAS category, the defined SAN limit is also fetched; if that fetch fails the system records *"Execution failed while fetching defined SAN Limit"* (suppressed as null in current code). These initialisation steps are documented in full in BR-002.

**Actors:** Stock Controller

**Preconditions:**
- The inventory header filter section has been filled with at least a store selection and either a part number range or a bin location range.
- The count has not already been populated (Populate button has not already been used for this session).

**Main Flow:**

**Step 1 - Store selection and range filter are validated before retrieval**
When the Populate button is clicked, the system checks that a store code has been entered. If not, the user is directed back to the store field and the operation stops. The system then checks whether both the part number range fields are blank and both the bin location range fields are also blank. If both pairs are empty, the user is informed that at least one filter criterion must be provided and the operation stops.

*Business outcomes (errors, warnings, success, and status):*
- **BR-025-ES-01** - Store not selected - *"Enter a valid Stores Code"*; user is directed to the store field.
- **BR-025-ES-02** - No part number or bin location filter entered - *"Either Part Number or Bin Location has to be entered."*; user must enter at least one filter.

**Step 2 - Part details are retrieved and loaded into the count grid**
If the population has not already been performed for this session, the system retrieves matching parts. When the part entry mode is "All parts" (automatic), the system calls the part-retrieval stored procedure to get the relevant parts with their stock, bin location, landed cost, and allocation details. Otherwise, when the mode is manual, the system executes an inline query that joins the parts master, part variant, and stock bin-location tables, applying all filter criteria (part number range, bin location range, category, ABC/FMS/XYZ indicators, margin category, price type and range, stock quantity filter, and bin-location active status), and orders results by part number or bin location according to the user's choice.

*Procedures called:*
- **SP_GET_PHY_PART_DETAILS** ([SP-033](#sp-033)) - SP_GET_PHY_PART_DETAILS - retrieves the full list of qualifying parts with their stock quantities, bin locations, landed costs, and allocated quantities for the physical count, based on all the filter criteria entered on the header.
    * **Step 1** - Accept all filter parameters from the header (principal, parent group, dealer, location, financial area, store, part number range, bin location range, category, ABC/FMS/XYZ indicators, margin category, price type and range, stock quantity filter, order by, bin-location active status).
    * **Step 2** - Query the parts master, part variant, and stock bin-location tables to identify all parts matching the given filter criteria.
    * **Step 3** - For each matching part, retrieve the part description, total stock quantity, current stock quantity, allocated quantity, float stock quantity, bin location, landed cost, and all-bin-location summary.
    * **Step 4** - Return the complete result set to the calling form for display in the count grid.
- **SF_GET_ALLOW_DECIMAL** ([SP-025](#sp-025)) - SF_GET_ALLOW_DECIMAL - retrieves the decimal quantity flag for each part, determining whether the physical count quantity for that part may include decimal values.
    * **Step 1** - Accept the principal, dealer, and part number identifiers.
    * **Step 2** - Look up the decimal-quantity permission setting for the specified part at the given dealer and principal.
    * **Step 3** - Return the decimal-allowed flag to the caller.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Store selection required | Mandatory store - WHEN-BUTTON-PRESSED on PH_INVENTORY.BT_FETCH own condition (stores_cd IS NULL) | When the Populate button is clicked. | A physical inventory count must be linked to a specific store; without a store, the part list cannot be scoped. | *"Enter a valid Stores Code"* - trigger failure; cursor directed to store field. |
| Part number or bin location filter required | Minimum filter - WHEN-BUTTON-PRESSED on PH_INVENTORY.BT_FETCH own condition (both range pairs blank) | When the Populate button is clicked after store validation passes. | Prevents an unrestricted full-catalogue fetch, which would be too broad for meaningful physical counting. | *"Either Part Number or Bin Location has to be entered."* - trigger failure. |
| Part details retrieval | Part retrieval - SP_GET_PHY_PART_DETAILS [SP-033] | When automatic entry mode is selected and population is triggered. | Retrieves only the parts that match the count criteria, ensuring the counter sees exactly the right scope of inventory. | SQLERRM is displayed if retrieval fails - trigger failure. |
| Decimal quantity setting per part | Decimal flag - SF_GET_ALLOW_DECIMAL [SP-025] for each part row | When each part row is being loaded into the count grid. | Ensures that when a counter enters a physical quantity, the system either accepts or truncates decimal values appropriately for that specific part type. | N/A - flag is stored per row; no user-visible error at this step. |

**Step 3 - Count grid is populated and entry fields are set for each part row**
For every retrieved part, the system loads the part number, description, stock quantities (current, allocated, float), bin location, physical bin location, landed cost, and entry mode into the detail grid. The part number and bin location fields for each populated row are set to read-only (not editable), since they came from the system's own retrieval. If the difference quantity for a row is positive, the physical bin location field for that row is made editable so the user can specify where the counted excess stock belongs; otherwise it is locked.

**Step 4 - Header is locked and Populate button is disabled**
Once any parts have been successfully loaded, the header filter section is locked against further changes. The Populate button is disabled and non-navigable. The cursor moves to the first physical quantity field in the count grid so the user can begin entering counts.

**Alternative Flows:**
- **BR-025-AF-01** - (from Step 2) No parts are found matching the filter criteria: no rows are loaded into the count grid. The header remains editable. No error is shown, but the count grid remains empty.
- **BR-025-AF-02** - (from Step 2) The count has already been populated in this session (population flag is set): the retrieval is skipped entirely and the header is immediately locked without re-populating the grid.
- **BR-025-AF-03** - (from Step 2) Part entry mode is not "All parts" (manual mode): the inline cursor-based query is used instead of the stored procedure.
- **BR-025-AF-04** - (from Step 2) An unexpected error occurs during the stored procedure call or cursor loop: the system displays the database error text (SQLERRM) and raises a trigger failure.

**Note on Save process:** After the part detail list is populated and the user has entered physical counts, the Save button triggers the save process (see BR-008). During save: if no part detail row has a part number, the system displays *"Transcation cannot be saved without entering Part details"* and stops. For rows with a positive difference quantity and no tax type, the error *"Tax Type cannot be null for Part Number"* (concatenated with the part number and line number) is collected. The duplicate-check label *"Part Number or Bin Location"* is used to identify duplicate part/bin combinations across all rows. If a new count is saved successfully, the system displays *"Physical Inventory number generated is"* (followed by the generated number). The commit-form parameter (`parameter.p_commit_form`) is set to `N` at the start of save and `Y` once all validations pass; the part-found parameter (`parameter.p_part_found`) is set to `N` at start and `Y` when a valid part row is found; the tax-flag parameter (`parameter.p_tax_flag`) is set to `N` at start and `Y` if errors are found. The stock-inclusion flag (`GLOBAL.p_type`) is set to `Y` or `N` before the report call. The report is submitted with destination parameters `MODE=CHARACTER BLANKPAGES=NO`. These are documented in full in BR-008.

**Business Scenarios - How the part population differs by stock quantity filter**

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **All stock (A)** | Parts with any stock quantity, whether positive, zero, or negative, are retrieved and included in the count grid. |
| **Positive stock only (G)** | Only parts with a net positive stock quantity (after deducting allocated, float, and reserved quantities) are retrieved. |
| **Zero or negative stock (E)** | Only parts with zero or negative net stock quantity are retrieved. |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Store (`STORES_CD`) | Mandatory | Character list | 7 | Store list (GM_STORE) | Store code | N/A | Must be selected before Populate is clicked | *"Enter a valid Stores Code"* |
| Part Number (`PART_NUMBER`) | Conditional - required when Bin Location range is not entered | Character | 15 | N/A | Part number filter value | N/A | At least one of part number range or bin location range must be entered | *"Either Part Number or Bin Location has to be entered."* |
| Part Number (`PART_NUM`) - detail row | Read-only display | Character | 15 | N/A | From retrieval | Part list populated | Read-only after population; set by system | N/A |
| Part Description (`NB_PART_DESC`) | Read-only display | Character | 4000 | N/A | From parts master | Part number loaded | Read-only | N/A |
| Stock Quantity at Generation (`STOCK_QTY`) | Read-only display | Numeric | 99,99,99,999.000 | N/A | From stock bin location | Part number loaded | Read-only; set by retrieval | N/A |
| Current Stock (`NB_CURRENT_STOCK`) | Read-only display | Numeric | 99,99,99,999.000 | N/A | Computed stock quantity | Part number loaded | Read-only | N/A |
| Float Stock (`NB_FLOAT_STOCK`) | Read-only display | Numeric | 99,99,99,999.000 | N/A | From stock bin location | Part number loaded | Read-only | N/A |
| Allocated Quantity (`ALLOC_QTY`) | Read-only display | Numeric | 99,99,99,999.000 | N/A | From stock bin location | Part number loaded | Read-only | N/A |
| Store Bin Location (`BIN_LOC`) | Read-only display after auto-populate | Character | 10 | N/A | From retrieval | Part number loaded | Read-only after population | N/A |
| Physical Bin Location (`PHY_BIN_LOC`) | Conditional - editable when difference quantity > 0 | Character | 10 | Physical bin location list (LOV_TO_BIN_LOC_CD) | Bin location code | Part row loaded | Editable only when positive difference exists | N/A |
| Landed Cost (`LANDED_COST`) | Auto-populated | Numeric | 24 | N/A | From part variant master | Part number loaded | System-set; not user-editable after population | N/A |
| Allow Decimal Quantity (`ALLOW_DECIMAL_QTY`) | Auto-populated | Character | 1 | N/A | `Y`/`N`/`E` flag | Part number loaded | System-set per part; governs physical quantity entry | N/A |

---

---

---

---

#### Requirement ID: BR-026

**Requirement Title:** Part Detail Block Entry - Store Presence Check

**Business Description:**
When the user or the system navigates to the part detail section of the Physical Inventory form, the system confirms that a store has already been selected on the header. Without a store, the part detail section cannot be meaningfully used, so the system redirects the user back to the store field if it is blank.

**Actors:** Stock Controller (system-triggered on block navigation)

**Preconditions:**
- The user or system has navigated focus to the part detail section.

**Main Flow:**

**Step 1 - Store presence checked before detail block entry is allowed**
When focus moves to the part detail block, the system checks whether a store has been selected on the header. If no store has been selected, the user sees an error and is directed back to the store field on the header. If a store is present, focus proceeds normally into the part detail section.

*Business outcomes (errors, warnings, success, and status):*
- **BR-026-ES-01** - No store selected when attempting to navigate to part detail - *"Enter a valid Stores Code"*; user is directed back to the store selection field on the header.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Store selection required before accessing part detail | Store presence - WHEN-NEW-BLOCK-INSTANCE on PD_INVENTORY own condition (stores_cd IS NULL) | When focus moves to the part detail block. | Prevents entry of part counts without a valid store context, which would result in counts that cannot be meaningfully saved or attributed to a store. | *"Enter a valid Stores Code"* - trigger failure; cursor directed to the store field on header. |

---

---

---

---

#### Requirement ID: BR-027

**Requirement Title:** Part Detail Record - Audit and Reference Field Population on Save

**Business Description:**
When a new part detail count row is saved for the first time, the system automatically populates all system-maintained reference and audit fields before the record is written to the database. This includes linking the detail row to its parent count document, the dealer, location, financial area, parent group, and store; and recording the creation timestamp and the creating user.

**Actors:** Stock Controller (system-triggered on first detail row save)

**Preconditions:**
- A part detail row has been entered with physical count data and the user has initiated a save.

**Main Flow:**

**Step 1 - System-maintained detail fields are populated from session context and header values**
Immediately before the detail row is inserted into the database, the system copies the parent inventory document number, dealer, location, financial area, parent group, and store code from the current session and header into the detail row. The creation timestamp is set to the current date and time, the creation user is set to the current session user, and the count date is set to today.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Count Document Number (`INV_NUM`) | Auto-populated | Character | 12 | N/A | From header record | New detail row being saved | System-set from header; not user-editable | N/A |
| Created By (`CREATED_BY`) | Auto-populated | Character | 8 | N/A | Current session user name | New detail row being saved | System-set; not user-editable | N/A |
| Created Date (`CREATED_DATE`) | Auto-populated | Datetime | DD-MM-YYYY HH24:MI | N/A | Current system timestamp | New detail row being saved | System-set; not user-editable | N/A |
| Store (`STORES_CD`) | Auto-populated | Character | 3 | N/A | From header store selection | New detail row being saved | System-set from header; not user-editable | N/A |

---

---

---

---

#### Requirement ID: BR-028

**Requirement Title:** Part Detail Record - Modification Audit Stamp and Adjustment Reference

**Business Description:**
When a previously saved part detail count row is modified and saved again, the system records who made the change and when, and also updates the adjustment document reference on the row if an adjustment number has been generated since the row was first saved.

**Actors:** Stock Controller (system-triggered on detail row update)

**Preconditions:**
- A part detail row already exists and the user has made a change and initiated a save.

**Main Flow:**

**Step 1 - Modification audit fields and adjustment reference are updated before the record is saved**
The system records the current user's name as the modifier, sets the modification timestamp to now, and copies the current adjustment number from the header to the detail row.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Modified By (`MODIFIED_BY`) | Auto-populated | Character | 8 | N/A | Current session user name | Existing detail row being updated | System-set; not user-editable | N/A |
| Modified Date (`MODIFIED_DATE`) | Auto-populated | Datetime | DD-MM-YYYY HH24:MI | N/A | Current system timestamp | Existing detail row being updated | System-set; not user-editable | N/A |
| Adjustment Number (`ADJ_NUM`) | Auto-populated | Character | 12 | N/A | From header adjustment number | Existing detail row being updated | System-set from header; not user-editable | N/A |

---

---

---

---

#### Requirement ID: BR-029

**Requirement Title:** Part Detail Record - Post-Query Data Enrichment

**Business Description:**
After each part detail record is retrieved from the database for display, the system automatically enriches the record with additional data that is not stored directly in the detail table but is needed for the counting process. This includes the decimal-quantity permission for the part, the current live stock quantities (when an unprocessed count is loaded from a saved count number), a summary of all bin locations for the part in the store, the landed cost, the part description, and the direction indicator (increase or decrease). The difference quantity is also recalculated if the count has not yet been adjusted. This ensures the user always sees complete and up-to-date count information without manual lookups.

**Actors:** Stock Controller (system-triggered after each detail row query)

**Preconditions:**
- One or more part detail rows have been retrieved from the database into the part detail section.

**Main Flow:**

**Step 1 - Decimal quantity permission is retrieved for the part**
For each queried detail row, the system retrieves the flag that governs whether the physical count quantity for that part may include decimal values.

*Procedures called:*
- **SF_GET_ALLOW_DECIMAL** ([SP-025](#sp-025)) - SF_GET_ALLOW_DECIMAL - retrieves the decimal quantity flag for the specified part at the current dealer and principal.
    * **Step 1** - Accept the principal, dealer, and part number identifiers.
    * **Step 2** - Look up the decimal-quantity permission for the specified part.
    * **Step 3** - Return the decimal-allowed flag to the caller.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Decimal quantity flag retrieved | Decimal permission - SF_GET_ALLOW_DECIMAL [SP-025] | When each detail row is queried. | Ensures the physical count entry for the part accepts or truncates decimal values appropriately. | N/A - flag stored per row; no error displayed. |

**Step 2 - Current live stock quantities are refreshed (for unprocessed counts loaded via count number)**
If the count has no adjustment number and a count number has been entered to load an existing count, the system re-queries the stock bin-location table for the current stock, allocated quantity, and float stock for the part and bin-location combination. If no stock record is found, all stock quantities default to zero silently. Any other error is also handled by defaulting to zero without raising an error to the user.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Current stock quantities refreshed | Stock query - POST-QUERY on PD_INVENTORY own condition (adj_num IS NULL AND nb_inv_no IS NOT NULL, SELECT from PM_STOCK_BIN_LOC) | When each detail row is queried and the count is unprocessed and loaded via count number. | Ensures the counter is comparing their physical count against the most current system stock figure, not the stock quantity that was saved when the count document was first created. | NO_DATA_FOUND, TOO_MANY_ROWS, WHEN OTHERS: stock quantities silently defaulted to zero; no error displayed to user. |

**Step 3 - All bin locations summary is loaded**
The system retrieves a summary of all bin locations in the current store where the part has stock, and displays this as a reference beside the part row.

*Procedures called:*
- **SF_GET_STORE_BIN_LOC** ([SP-029](#sp-029)) - SF_GET_STORE_BIN_LOC - retrieves a summary of all bin locations within the current store where the specified part holds stock.
    * **Step 1** - Accept the parent group, dealer, location, part number, and store code.
    * **Step 2** - Query the stock bin-location data to identify all bin locations for the part within the store.
    * **Step 3** - Return a combined bin-location summary string to the caller.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| All bin locations summary loaded | Bin location summary - SF_GET_STORE_BIN_LOC [SP-029] | When each detail row is queried. | Provides the counter with a reference view of all locations where the part's stock is distributed across the store. | N/A - summary displayed as reference; no error. |

**Step 4 - Adjustment number is propagated to the header**
The detail row's adjustment number (if set) is copied to the header record so the header reflects the latest adjustment state.

**Step 5 - Difference quantity is recalculated for unprocessed counts**
If no adjustment number has been generated for the header, the system recalculates the difference quantity for the current row.

*Procedures called:*
- **CALC_DIFF_QTY** ([SP-001](#sp-001)) - CALC_DIFF_QTY - recalculates the difference between the physical quantity and the system stock quantity for the current row, using the active adjustment basis.
    * **Step 1** - Determine whether the active stock-adjustment basis uses stock quantity at generation or current stock.
    * **Step 2** - Compute the difference as physical quantity minus the relevant stock quantity.
    * **Step 3** - Update the difference quantity field for the current row.
    * **Step 4** - Enable or lock the physical bin location field based on whether a positive difference exists and bin-location management is active.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Difference quantity recalculated | Difference calculation - CALC_DIFF_QTY [SP-001] (when adj_num IS NULL) | When each detail row is queried. | Provides the counter with a current variance figure without requiring manual recalculation. | N/A - calculation only. |

**Step 6 - Increase or decrease direction is set**
Based on the recalculated difference quantity, the system sets the direction indicator: positive difference means an increase (more counted than in the system), negative difference means a decrease.

**Step 7 - Landed cost is loaded from the price master**
The system retrieves the landed cost for the part from the price master for use in subsequent adjustment value calculations.

*Procedures called:*
- **SF_GET_PRICE** ([SP-028](#sp-028)) - SF_GET_PRICE - retrieves the landed cost price for the specified part from the price master at the current dealer and principal.
    * **Step 1** - Accept the parent group, dealer, location, principal, price type, and part number.
    * **Step 2** - Look up the price value for the specified price type for the part.
    * **Step 3** - Return the price value to the caller.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Landed cost loaded | Price retrieval - SF_GET_PRICE [SP-028] | When each detail row is queried. | The landed cost is required for computing the monetary value of any stock adjustment when the count is processed. | N/A - if not found, the field will be null; subsequent adjustment step validates it. |

**Step 8 - Physical bin location defaults to store bin location if blank**
If the physical bin location field is blank, it is defaulted to the same value as the store bin location, so the counter's default assumption is that the physical location matches the recorded location.

**Step 9 - Part description is loaded**
The system retrieves and displays the part description for each row.

*Procedures called:*
- **SP_GET_PART_DESC** ([SP-031](#sp-031)) - SP_GET_PART_DESC - retrieves the part description for the specified part number and displays it on the detail row.
    * **Step 1** - Accept the dealer, principal, and part number.
    * **Step 2** - Retrieve the part description from the parts master.
    * **Step 3** - Return the description and any error indicator to the caller.
    * **Step 4** - If an error indicator is returned, display the error message (without stopping the query).

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Part description loaded | Description retrieval - SP_GET_PART_DESC [SP-031] | When each detail row is queried. | Provides the counter with a readable part name so they can identify parts during the physical count. | Error message displayed if retrieval fails; query continues (trigger failure is not raised). |

**Step 10 - Part number and bin location fields locked for auto-populated rows**
If the detail row was populated by the system (entry mode "A"), the part number and bin location fields for that row are set to read-only, preventing the user from altering system-assigned identifiers.

**Step 11 - Action buttons enabled for unprocessed counts loaded via count number**
If the count has an adjustment number that is null, a count number was entered, and the stock-taken-by field is blank, the Generate Adjustment, Generate, and related action buttons are enabled and navigable.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Allow Decimal Quantity (`ALLOW_DECIMAL_QTY`) | Auto-populated | Character | 1 | N/A | `Y`/`N`/`E` flag | Detail row queried | System-set per part | N/A |
| Current Stock (`CURRENT_STOCK`) | Read-only display | Numeric | 99,99,99,999.000 | N/A | Computed from stock bin location | Unprocessed count loaded via count number | Read-only; refreshed from live stock | N/A |
| Current Stock Net (`NB_CURRENT_STOCK`) | Read-only display | Numeric | 99,99,99,999.000 | N/A | Computed net stock | Detail row queried | Read-only | N/A |
| Allocated Quantity (`ALLOC_QTY`) | Read-only display | Numeric | 99,99,99,999.000 | N/A | From stock bin location | Detail row queried | Read-only | N/A |
| Float Stock (`NB_FLOAT_STOCK`) | Read-only display | Numeric | 99,99,99,999.000 | N/A | From stock bin location | Detail row queried | Read-only | N/A |
| All Bin Locations (`NB_BIN_LOC`) | Read-only display | Character | N/A | N/A | Summary from SF_GET_STORE_BIN_LOC | Detail row queried | Read-only | N/A |
| Difference Quantity (`DIFF_QTY`) | Auto-populated | Numeric | 9,99,99,999.000 | N/A | Physical quantity minus selected stock quantity | Physical quantity entered | Read-only; system-calculated | N/A |
| Landed Cost (`LANDED_COST`) | Auto-populated | Numeric | 24 | N/A | Landed cost price for the part | Detail row queried | System-set from price master | N/A |
| Physical Bin Location (`PHY_BIN_LOC`) | Auto-populated (editable when diff > 0 and bin flag Y) | Character | 10 | Physical bin location list | Defaults to Store Bin Location | Detail row queried | Defaults to bin location if blank | N/A |
| Part Description (`NB_PART_DESC`) | Read-only display | Character | 4000 | N/A | From parts master | Detail row queried | Read-only | Error message displayed if retrieval fails |
| Part Number (`PART_NUM`) | Read-only display (for auto rows) | Character | 15 | N/A | From retrieval | Entry mode = A | Read-only after auto-population | N/A |
| Store Bin Location (`BIN_LOC`) | Read-only display (for auto rows) | Character | 10 | N/A | From retrieval | Entry mode = A | Read-only after auto-population | N/A |

---

---

---

---

#### Requirement ID: BR-030

**Requirement Title:** New Part Detail Row - Serial Number and Entry Mode Initialisation

**Business Description:**
When a new blank part detail row is added to the count grid, the system automatically assigns the correct sequential row number and sets the default data entry mode for that row if one has not already been set. This ensures each row is uniquely numbered within the count document and that the entry mode is always defined before the user enters data.

**Actors:** Stock Controller (system-triggered on new row creation)

**Preconditions:**
- The part detail section is open and the user or system is adding a new row.

**Main Flow:**

**Step 1 - Row serial number is set to the current cursor row position**
The system assigns the current row position number from the form as the serial number for the new detail row, giving each row a unique sequence within the count document.

**Step 2 - Entry mode defaulted to manual if not already set**
If the new row does not yet have an entry mode assigned (for example, a manually added row), the system defaults the entry mode to "Manual" so the user can enter part numbers and quantities directly.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Serial Number (`SRL_NUM`) | Auto-populated | Character | 10 | N/A | Current cursor row position number | New row being created | System-set from row position; not user-editable | N/A |
| Entry Mode (`ENTRY_MODE`) | Auto-populated | Character | 1 | N/A | `M` = Manual (default for new rows) | New row being created | Defaulted to Manual if not already set | N/A |

**Alternative Flows:**
- **BR-030-AF-01** - (Delete button: from PD_INVENTORY block) When the user clicks the Delete button and the Delete button is enabled, and the cursor is in the part detail block, the system checks whether the difference quantity for the current row is zero. If it is zero, the row is deleted from the count grid, the row is also removed from the working stock data, and all remaining rows are renumbered sequentially. If the difference quantity is not zero, the system displays *"Difference Quantity is not 0"* (with the message "Record cannot be deleted." on a new line) and the deletion is stopped; the row remains in the grid until the user adjusts the physical count quantity so that the difference becomes zero.
- **BR-030-AF-02** - (Insert button) When the user clicks the Insert button and the Insert button is enabled, the system navigates to the part detail block, moves to the last existing row, and then creates a new blank row immediately after it for the user to enter a new part number and count quantity.

---

---

---

---

#### Requirement ID: BR-031

**Requirement Title:** Manual Part Number Entry - Part Validation, Stock Lookup, and Default Bin Assignment

**Business Description:**
When the user manually enters a part number on a detail row in the physical inventory count grid, the system validates the part number, retrieves the part's description, landed cost, decimal-quantity permission, default bin location, and current stock quantities. If the landed cost is zero, the user is blocked from proceeding with that part, since a zero landed cost makes adjustment calculations meaningless. The system also recalculates the difference quantity for the row based on the retrieved stock data. This process applies only in manual entry mode; in automatic mode (when parts were populated by the system), the part number is already locked and this validation does not run.

**Actors:** Stock Controller

**Preconditions:**
- The part detail section is in manual entry mode.
- The user has entered a part number on a new or existing detail row.

**Main Flow:**

**Step 1 - Part number existence is confirmed for the principal dealer account**
If the current dealer is the principal account, the system checks that the entered part number exists in the parts master. If not found, an error is shown.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Part number exists in parts master (principal only) | Part existence - WHEN-VALIDATE-ITEM on PD_INVENTORY.PART_NUM own condition (principal = 1, SELECT from PM_PART) | When the user moves off the part number field in manual mode. | Ensures the part number being counted actually exists in the principal's parts catalogue. | *"Invalid Part Number"* - trigger failure. |

**Step 2 - Part details are retrieved (manual mode only)**
In manual entry mode, the system confirms the part number is not blank, then retrieves the landed cost, part description, and decimal-quantity permission by looking up the part in the parts master and part variant table. If the part is found in the part variant (which includes the landed cost), all three values are loaded. If only found in the parts master (no variant), the landed cost defaults to zero and the description and decimal flag are retrieved from the parts master instead.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-007](#sp-007)) - GENERAL.CHECK_NULL - confirms the part number is not blank before proceeding with the lookup.
    * **Step 1** - Receive the field value and label "Part Number".
    * **Step 2** - Check whether the field value is null.
    * **Step 3** - If null, display a mandatory-field error for "Part Number" and raise a trigger failure; otherwise allow the operation to continue.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Part number required in manual mode | Mandatory check - GENERAL.CHECK_NULL [SP-007] on PD_INVENTORY.PART_NUM | When the user moves off the part number field in manual mode. | Ensures a part number is entered before the system attempts a lookup. | Mandatory-field error for "Part Number" - trigger failure. |
| Part details retrieved from parts master | Part lookup - WHEN-VALIDATE-ITEM on PD_INVENTORY.PART_NUM own condition (SELECT from PM_PART, PM_PART_VAR) | When the user moves off the part number field in manual mode. | Loads the description, cost, and entry settings for the part so the counter has the context they need and the system has the cost data for any subsequent adjustment. | *"Part Number [entered number] not found"* (NO_DATA_FOUND inner query), *"More than one part found"* (TOO_MANY_ROWS), *"Width problem/Incompatible data while retrieving part details"* (VALUE_ERROR), *"Execution failed while retrieving part details [SQLERRM]"* (WHEN OTHERS) - trigger failure. For TOO_MANY_ROWS and inner NO_DATA_FOUND on part-only query: trigger failure. For primary TOO_MANY_ROWS on landed cost: *"More than one Landed cost found for [part number]"* - trigger failure. For primary VALUE_ERROR: *"Width problem/Incompatible data while retrieving Landed cost"* - trigger failure. For primary OTHERS: *"Execution failed while retrieving Landed cost [SQLERRM]"* - trigger failure. |

**Step 3 - Decimal quantity permission is retrieved for the part**
The system retrieves the decimal-quantity flag for the part at the current dealer and principal, overriding the value obtained from the parts master lookup.

*Procedures called:*
- **SF_GET_ALLOW_DECIMAL** ([SP-025](#sp-025)) - SF_GET_ALLOW_DECIMAL - retrieves the decimal quantity permission flag for the part.
    * **Step 1** - Accept the principal, dealer, and part number identifiers.
    * **Step 2** - Look up the decimal-quantity permission for the specified part.
    * **Step 3** - Return the decimal-allowed flag to the caller.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Decimal quantity permission retrieved | Decimal flag - SF_GET_ALLOW_DECIMAL [SP-025] | After part details are successfully loaded. | Ensures the physical count field for this part enforces or permits decimal values according to the part's own configuration. | N/A - flag stored per row. |

**Step 4 - Default bin location is assigned for the part in the current store**
The system retrieves the default bin location for the part in the current store and assigns it to both the bin location and physical bin location fields. If no bin location is found and the dealer does not use bin-location management, a system placeholder value is assigned and both fields are locked against editing. If bin-location management is active, the fields remain editable.

*Procedures called:*
- **SF_GET_DEFAULT_STORE_BIN** ([SP-027](#sp-027)) - SF_GET_DEFAULT_STORE_BIN - retrieves the default bin location for the specified part within the current store.
    * **Step 1** - Accept the parent group, dealer, location, financial area, store code, and part number.
    * **Step 2** - Look up the default bin location for the part in the given store.
    * **Step 3** - Return the default bin location code to the caller.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Default bin location assigned | Bin default - SF_GET_DEFAULT_STORE_BIN [SP-027] | After decimal flag is retrieved. | Provides the counter with the part's default storage location so they know where to look first when performing the physical count. | N/A - if no bin found, system assigns a placeholder and locks the field. |

**Step 5 - Current stock quantities are loaded for the part at its default bin location**
If a bin location was found, the system retrieves the current allocated quantity, net current stock, total stock, and float stock for the part at that bin location from the stock bin-location table. If no stock record exists, all values default to zero silently. Errors (multiple records found, data-width problem, or other failure) are displayed to the user and the trigger fails.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Stock quantities retrieved from stock bin-location table | Stock lookup - WHEN-VALIDATE-ITEM on PD_INVENTORY.PART_NUM own condition (SELECT from PM_STOCK_BIN_LOC) | After default bin location is set. | Provides the current system stock figures so the counter can compare them against their physical count. | *"More than one stock detail found for the part - [part number]"* (TOO_MANY_ROWS), *"Width problem/Incompatible Data for the part - [part number]"* (VALUE_ERROR), *"Execution failed while stock fetching for the part - [part number]-[SQLERRM]"* (WHEN OTHERS) - trigger failure for each. NO_DATA_FOUND: zero quantities defaulted silently. |

**Step 6 - Landed cost validated as non-zero**
If the landed cost retrieved for the part is zero or less, the system blocks the user from proceeding with an error, since a zero landed cost means no meaningful adjustment value can be calculated.

*Business outcomes (errors, warnings, success, and status):*
- **BR-031-ES-01** - Landed cost is zero or negative - *"Adjustment for the part [part number] is not possible! landed cost fetched is 0."* - trigger failure.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Landed cost must be positive | Landed cost check - WHEN-VALIDATE-ITEM on PD_INVENTORY.PART_NUM own condition (landed_cost <= 0) | After stock quantities are loaded. | A part with zero landed cost cannot have a meaningful monetary adjustment calculated; blocking it prevents zero-value adjustments from being committed. | *"Adjustment for the part [part number] is not possible! landed cost fetched is 0."* - trigger failure. |

**Step 7 - Difference quantity is recalculated**
After all part data has been loaded, the system recalculates the difference quantity for the row.

*Procedures called:*
- **CALC_DIFF_QTY** ([SP-001](#sp-001)) - CALC_DIFF_QTY - recalculates the difference between the physical quantity and the stock quantity for the current part row.
    * **Step 1** - Determine the active stock-adjustment basis (generation stock or current stock).
    * **Step 2** - Compute the difference as physical quantity minus the relevant stock quantity.
    * **Step 3** - Update the difference quantity field for the current row.
    * **Step 4** - Enable or lock the physical bin location field based on whether a positive difference exists and bin management is active.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Difference quantity recalculated | Recalculation - CALC_DIFF_QTY [SP-001] | After landed cost validation passes. | Immediately shows the counter the current variance so they can check whether any discrepancy exists before proceeding. | N/A - calculation only. |

**Alternative Flows:**
- **BR-031-AF-01** - (from Step 1) Entry mode is not manual ("A" or other): none of the part validation steps run; the trigger exits immediately.
- **BR-031-AF-02** - (from Step 4) Bin location is null and bin-location management is not enabled: the system assigns "NO BIN" as a placeholder and locks both bin location and physical bin location fields.
- **BR-031-AF-03** - (from Step 5) No stock record found for the part at the default bin location: all stock quantities default to zero silently and the flow continues.
- **BR-031-AF-04** - (List button: cursor on Part Number field) When the user clicks the List button and the cursor is on the part number field in the part detail block, the system opens the Part Search form (`pe_part`) as a read-only call form. When the user selects a part and returns, the system writes the selected part number into the part number field and the selected part description into the description field, then erases the temporary global values used for the transfer. For any other field context when the List button is clicked, the standard list-of-values behaviour is invoked instead.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Part Number (`PART_NUM`) | Mandatory (manual mode) | Character | 15 | N/A | Part number entered by user | Manual entry mode active | Must exist in parts master for principal account; mandatory | *"Invalid Part Number"* / mandatory-field error |
| Part Description (`NB_PART_DESC`) | Auto-populated | Character | 4000 | N/A | From parts master | Part number validated | Read-only; system-loaded | N/A |
| Landed Cost (`LANDED_COST`) | Auto-populated | Numeric | 24 | N/A | From part variant (or 0 if not found in variant) | Part number validated | System-set; must be > 0 to proceed | *"Adjustment for the part [part number] is not possible! landed cost fetched is 0."* |
| Allow Decimal Quantity (`ALLOW_DECIMAL_QTY`) | Auto-populated | Character | 1 | N/A | From SF_GET_ALLOW_DECIMAL | Part number validated | System-set per part | N/A |
| Store Bin Location (`BIN_LOC`) | Auto-populated | Character | 10 | Bin location list (LV_BIN_LOC) | Default bin location for the part | Part number validated | System-defaulted; locked when bin management disabled | N/A |
| Physical Bin Location (`PHY_BIN_LOC`) | Auto-populated | Character | 10 | Physical bin location list (LOV_TO_BIN_LOC_CD) | Same as bin location on entry | Part number validated | Defaulted to bin location; may be editable based on bin flag | N/A |
| Stock Quantity at Generation (`STOCK_QTY`) | Auto-populated | Numeric | 99,99,99,999.000 | N/A | Total stock from stock bin-location table | Part and bin location loaded | Read-only | N/A |
| Current Stock Net (`NB_CURRENT_STOCK`) | Read-only display | Numeric | 99,99,99,999.000 | N/A | Net stock from stock bin-location table | Part and bin location loaded | Read-only | N/A |
| Allocated Quantity (`ALLOC_QTY`) | Read-only display | Numeric | 99,99,99,999.000 | N/A | From stock bin-location table | Part and bin location loaded | Read-only | N/A |
| Float Stock (`NB_FLOAT_STOCK`) | Read-only display | Numeric | 99,99,99,999.000 | N/A | From stock bin-location table | Part and bin location loaded | Read-only | N/A |
| Difference Quantity (`DIFF_QTY`) | Auto-populated | Numeric | 9,99,99,999.000 | N/A | Physical qty minus stock qty | Physical quantity entered | Read-only; recalculated | N/A |

---

---

---

---

#### Requirement ID: BR-032

**Requirement Title:** Store Bin Location Validation and Stock Refresh

**Business Description:**
When the user enters or changes the bin location for a part row in the physical inventory count grid, the system validates the entered bin location and refreshes the stock quantities for the part at that location. This validation only applies when bin-location management is enabled for the dealer. The system confirms the bin location is not blank and either exists in the stock records or prompts the user to select a valid one. It also prevents the reserved system placeholder "NO BIN" from being entered as a user-defined location name. After validation, the difference quantity is recalculated for the row.

**Actors:** Stock Controller

**Preconditions:**
- Bin-location management is enabled for the current dealer.
- The user is on a part detail row and has entered or changed the bin location value.

**Main Flow:**

**Step 1 - Bin location is confirmed as not blank**
The system checks the bin location field is not empty.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-007](#sp-007)) - GENERAL.CHECK_NULL - checks that the bin location field is not blank.
    * **Step 1** - Receive the field value and the label "Bin Location".
    * **Step 2** - Check whether the field value is null.
    * **Step 3** - If null, display a mandatory-field error for "Bin Location" and raise a trigger failure; otherwise continue.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Bin location required when bin management is enabled | Mandatory check - GENERAL.CHECK_NULL [SP-007] on PD_INVENTORY.BIN_LOC | When the user moves off the bin location field. | A bin location is required for every counted part when the dealer uses bin-location management. | Mandatory-field error for "Bin Location" - trigger failure. |

**Step 2 - Bin location existence is checked in the stock records**
The system counts whether a stock record exists for the part at the entered bin location. If the bin location does not exist: if it is the reserved system name "NO BIN", an error is shown and the user must choose a different name. Otherwise, the user is informed that the bin location was not found and a bin location selection list is displayed so they can pick a valid one. If the bin location exists, current stock, allocated, and float quantities are loaded for that location.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| "NO BIN" cannot be used as a user-defined bin location | Reserved name - WHEN-VALIDATE-ITEM on PD_INVENTORY.BIN_LOC own condition (UPPER(bin_loc) = 'NO BIN') | When bin location is not found in stock records. | "NO BIN" is a system-generated placeholder; it must not be stored as a real user-defined bin location. | *"NO BIN is system generated Bin Location. Please choose another name."* - trigger failure. |
| Bin location stock quantities refreshed | Stock refresh - WHEN-VALIDATE-ITEM on PD_INVENTORY.BIN_LOC own condition (SELECT from PM_STOCK_BIN_LOC) | When the bin location exists in stock records. | Ensures the stock quantities shown are for the actual bin location the user has selected, not the previously default bin. | *"Bin Location [bin location] not found."* (not in stock records, bin LOV shown); WHEN OTHERS: stock zeroed silently. |

**Step 3 - Physical bin location defaults to the validated bin location**
If the physical bin location field is blank, it is set to the same value as the validated bin location.

**Step 4 - Difference quantity is recalculated**
After bin location and stock are confirmed, the difference quantity is recalculated for the current row.

*Procedures called:*
- **CALC_DIFF_QTY** ([SP-001](#sp-001)) - CALC_DIFF_QTY - recalculates the difference quantity for the current row using the active adjustment basis.
    * **Step 1** - Determine the active stock-adjustment basis.
    * **Step 2** - Compute the difference as physical quantity minus the relevant stock quantity.
    * **Step 3** - Update the difference quantity field.
    * **Step 4** - Enable or lock the physical bin location field based on positive difference and bin flag.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Difference quantity recalculated after bin location change | Recalculation - CALC_DIFF_QTY [SP-001] | After bin location validation and stock refresh. | Keeps the variance figure current after a bin location change. | N/A. |

**Alternative Flows:**
- **BR-032-AF-01** - (from Step 1) Bin-location management is not enabled for the dealer: the entire validation is skipped.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Store Bin Location (`BIN_LOC`) | Mandatory (when bin management enabled) | Character | 10 | Bin location list (LV_BIN_LOC) | Bin location code | Bin management enabled | Must not be blank; must exist in stock records (or allow LOV selection); cannot be "NO BIN" | *"NO BIN is system generated Bin Location. Please choose another name."* / *"Bin Location [loc] not found."* |
| Physical Bin Location (`PHY_BIN_LOC`) | Auto-populated | Character | 10 | Physical bin location list | Defaults to bin location | Bin location validated | Defaulted if blank | N/A |
| Current Stock (`CURRENT_STOCK`) | Read-only display | Numeric | 99,99,99,999.000 | N/A | From stock bin-location | Bin location validated | Read-only | N/A |
| Allocated Quantity (`ALLOC_QTY`) | Read-only display | Numeric | 99,99,99,999.000 | N/A | From stock bin-location | Bin location validated | Read-only | N/A |
| Difference Quantity (`DIFF_QTY`) | Auto-populated | Numeric | 9,99,99,999.000 | N/A | Physical qty minus stock qty | Physical and stock qty present | Read-only; recalculated | N/A |

---

---

---

---

#### Requirement ID: BR-033

**Requirement Title:** Physical Count Quantity Entry - Validation, Tax Type Default, and Difference Calculation

**Business Description:**
When the user enters a physical quantity for a part in the count grid, the system validates that the quantity is valid (non-negative and consistent with whether the part allows decimal quantities), automatically defaults the tax type when the count has not yet been adjusted, recalculates the difference between the counted quantity and the system stock, refreshes the landed cost from the part master, and updates the counted date. These steps ensure that the moment a quantity is entered, the row is fully enriched with the data needed for a subsequent stock adjustment.

**Actors:** Stock Controller

**Preconditions:**
- A part row is present in the count detail grid.
- The user has entered a physical count quantity.

**Main Flow:**

**Step 1 - Decimal compliance is enforced**
If the part does not allow decimal quantities, the entered value is truncated to a whole number. If the part's decimal setting is in an error state, the system shows an error and stops.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Decimal quantity compliance | Decimal check - WHEN-VALIDATE-ITEM on PD_INVENTORY.PHYSICAL_QTY own condition (allow_decimal_qty = 'N' truncates; 'E' errors) | When the user moves off the physical quantity field. | Ensures parts that cannot be counted in partial units have whole-number counts only. | *"Error executed for judging decimal for Physical Qty"* (for error state) - trigger failure. Decimal truncated silently for non-decimal parts. |

**Step 2 - Physical quantity must not be negative**
The system checks that the entered quantity is not less than zero.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Physical quantity non-negative | Non-negative check - WHEN-VALIDATE-ITEM on PD_INVENTORY.PHYSICAL_QTY own condition (physical_qty < 0) | When the user moves off the physical quantity field. | A negative physical count is not a valid business value. | *"Physical Quantity Cannot be less than zero"* - trigger failure. |

**Step 3 - Tax type is defaulted from dealer parameters when not yet set**
If no adjustment number has been generated and the tax type is not yet set for the row, the system retrieves the default tax type from the dealer's location parameter configuration and applies it to the row.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Default tax type retrieved from dealer configuration | Tax type default - WHEN-VALIDATE-ITEM on PD_INVENTORY.PHYSICAL_QTY own condition (adj_num IS NULL AND tax_type IS NULL, SELECT from AM_DEALER_LOC_PARAM) | After quantity validation passes, before difference calculation. | Automatically populates the tax type required for adjustment value calculation, reducing manual data entry. | *"More than one Tax type found for [dealer]"* (TOO_MANY_ROWS), *"Width problem/Incompatible data while retrieving Tax type"* (VALUE_ERROR), *"Execution failed while retrieving Tax type [SQLERRM]"* (WHEN OTHERS) - trigger failure. NO_DATA_FOUND: silently no default set. |

**Step 4 - Physical count date is set to today**
If a physical quantity has been entered (non-null), the system sets today's date as the physical count date for the row.

**Step 5 - Difference quantity is recalculated**
The system recalculates the difference quantity for the row using the current stock-adjustment basis.

*Procedures called:*
- **CALC_DIFF_QTY** ([SP-001](#sp-001)) - CALC_DIFF_QTY - recalculates the difference between the physical quantity and the system stock quantity.
    * **Step 1** - Determine the active stock-adjustment basis.
    * **Step 2** - Compute the difference as physical quantity minus the relevant stock quantity.
    * **Step 3** - Update the difference quantity field.
    * **Step 4** - Enable or lock the physical bin location field based on difference and bin flag.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Difference quantity recalculated | Recalculation - CALC_DIFF_QTY [SP-001] | After physical count date is set. | Immediately shows the variance for the part, informing the counter of whether a stock adjustment will be needed. | N/A. |

**Step 6 - Tax type is cleared for negative or null difference**
If the difference quantity is negative (counted less than system stock) or the physical quantity is null, the tax type is cleared from the row. Tax type is only relevant for stock increases.

**Step 7 - Increase or decrease direction is set**
Based on the recalculated difference, the system marks the row as an increase (positive or zero difference) or decrease (negative difference).

**Step 8 - Landed cost is refreshed from the part variant master**
If a part number is present on the row, the system re-queries the part variant table to obtain the current landed cost and updates the row.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Landed cost re-fetched from part variant | Landed cost refresh - WHEN-VALIDATE-ITEM on PD_INVENTORY.PHYSICAL_QTY own condition (SELECT from PM_PART_VAR) | After direction is set. | Ensures the landed cost used for adjustment calculation is the most current value, not a value that may have been set earlier in the session. | *"Landed cost  not found"* (NO_DATA_FOUND), *"More than one Landed cost found for [part number]"* (TOO_MANY_ROWS), *"Width problem/Incompatible data while retrieving Landed cost"* (VALUE_ERROR), *"Execution failed while retrieving Landed cost [SQLERRM]"* (WHEN OTHERS) - trigger failure for each. |

**Step 9 - Generate Adjustment button is enabled for loaded counts that are unprocessed**
If the count was loaded via count number and no adjustment has been generated and no stock-taken-by is set, the Generate Adjustment and Generate buttons are enabled.

**Step 10 - Counted date is updated when quantity changes**
If the entered physical quantity differs from the previously saved value (or transitions between null and non-null), the counted date is updated to today.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Physical Quantity (`PHYSICAL_QTY`) | Mandatory | Numeric | 99,99,999.000 | N/A | Count quantity entered by user | Part number and bin location loaded | Must be ≥ 0; decimal compliance enforced per part | *"Physical Quantity Cannot be less than zero"* / decimal error |
| Physical Count Date (`PHY_COUNT_DATE`) | Auto-populated | Datetime | DD-MM-YYYY HH24:MI | N/A | Today's date | Physical quantity entered | System-set when quantity entered | N/A |
| Tax Type (`TAX_TYPE`) | Auto-populated | Character list | 3 | N/A | Default tax type from dealer parameters (when difference ≥ 0); cleared when difference < 0 | Physical quantity entered | System-defaulted from dealer config; cleared for decreases | N/A |
| Difference Quantity (`DIFF_QTY`) | Auto-populated | Numeric | 9,99,99,999.000 | N/A | Physical qty minus stock qty | Physical quantity entered | Read-only; recalculated | N/A |
| Landed Cost (`LANDED_COST`) | Auto-populated | Numeric | 24 | N/A | From part variant master | Part number present | System-refreshed; must be > 0 | *"Landed cost  not found"* / *"More than one Landed cost found"* etc. |

---

---

---

---

#### Requirement ID: BR-034

**Requirement Title:** Physical Count Date - Date Range Validation

**Business Description:**
When the user enters or changes the physical count date for a part row, the system validates that the date is consistent with the physical count. The count date must not be in the future (since a physical count cannot be recorded for a future date) and must not be earlier than the count document's own inventory date. If a physical count date is entered but no physical quantity is present, an error is also shown and the date is cleared. Conversely, if a physical quantity is present but the count date field is blank, the date is required.

**Actors:** Stock Controller

**Preconditions:**
- A part detail row is present with a part number and physical quantity.
- The user has entered a value in the physical count date field.

**Main Flow:**

**Step 1 - Physical count date is required when physical quantity is entered**
If a physical quantity is present on the row, the system confirms the physical count date is not blank.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-007](#sp-007)) - GENERAL.CHECK_NULL - confirms the physical count date is not blank when a physical quantity is entered.
    * **Step 1** - Receive the field value and label "Physical Count Date".
    * **Step 2** - Check whether the field value is null.
    * **Step 3** - If null, display a mandatory-field error for "Physical Count Date" and raise a trigger failure; otherwise continue.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Physical count date required when quantity is entered | Mandatory check - GENERAL.CHECK_NULL [SP-007] on PD_INVENTORY.PHY_COUNT_DATE | When the user moves off the physical count date field and a quantity is present. | Ensures every counted part has a recorded count date for audit and traceability. | Mandatory-field error for "Physical Count Date" - trigger failure. |

**Step 2 - Count date must not be in the future**
The system checks that the entered count date does not exceed today's date.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Count date not in the future | Future date - WHEN-VALIDATE-ITEM on PD_INVENTORY.PHY_COUNT_DATE own condition (phy_count_date > sysdate) | When the user moves off the physical count date field. | A physical count cannot be recorded for a date that has not yet occurred. | *"Physical count date should not exceed the current date : [sysdate]"* - trigger failure. |

**Step 3 - Count date must not be before the document's inventory date**
The system checks that the count date is not earlier than the inventory document date.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Count date not before document date | Minimum date - WHEN-VALIDATE-ITEM on PD_INVENTORY.PHY_COUNT_DATE own condition (phy_count_date < inv_date) | When the user moves off the physical count date field. | Ensures the count date falls within the valid period for the inventory document. | *"Physical count date cannot be lesser than document date : [inv_date]"* - trigger failure. |

**Alternative Flows:**
- **BR-034-AF-01** - (from Step 1) No physical quantity is entered but a count date is present: the system shows *"Physical qty cannot be null"*, clears the physical count date field, and moves focus to the physical quantity field.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Physical Count Date (`PHY_COUNT_DATE`) | Conditional - mandatory when physical quantity is entered | Datetime | DD-MM-YYYY HH24:MI | N/A | Date entered by user or system-defaulted to today | Physical quantity entered | Must not be > today; must not be < document date | *"Physical count date should not exceed the current date : [date]"* / *"Physical count date cannot be lesser than document date : [date]"* / *"Physical qty cannot be null"* |

---

---

---

---

#### Requirement ID: BR-035

**Requirement Title:** Physical Bin Location Validation

**Business Description:**
When the user enters a physical bin location for a part row, the system validates it only when bin-location management is enabled. The difference quantity is first recalculated to ensure the current state of the row is known. The physical bin location must not be blank, and the system checks whether the entered bin location already exists in the store's stock records. When the bin location does not exist and the difference quantity is negative or zero, the entry is rejected with an error. When the bin location does not exist but the difference is positive (meaning there is a quantity to place somewhere), the system informs the user that a new bin location will be created at the named location in the store - unless the name is the reserved "NO BIN" placeholder, in which case an error is shown instead.

**Actors:** Stock Controller

**Preconditions:**
- Bin-location management is enabled for the current dealer.
- The user has entered a value in the physical bin location field.

**Main Flow:**

**Step 1 - Difference quantity is recalculated before physical bin location is validated**
The system refreshes the difference quantity so the bin-location creation logic has an accurate current value.

*Procedures called:*
- **CALC_DIFF_QTY** ([SP-001](#sp-001)) - CALC_DIFF_QTY - recalculates the difference quantity for the current row.
    * **Step 1** - Determine the active stock-adjustment basis.
    * **Step 2** - Compute the difference as physical quantity minus the relevant stock quantity.
    * **Step 3** - Update the difference quantity field.
    * **Step 4** - Enable or lock the physical bin location field based on difference and bin flag.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Difference quantity refreshed before bin location check | Recalculation - CALC_DIFF_QTY [SP-001] | When the user moves off the physical bin location field. | Ensures the bin-location validation uses the most current difference figure. | N/A. |

**Step 2 - Physical bin location is confirmed as not blank**
The system checks the physical bin location field is not empty.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-007](#sp-007)) - GENERAL.CHECK_NULL - confirms the physical bin location is not blank.
    * **Step 1** - Receive the field value and label "Bin Location".
    * **Step 2** - Check whether the field value is null.
    * **Step 3** - If null, display a mandatory-field error for "Bin Location" and raise a trigger failure; otherwise continue.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Physical bin location required | Mandatory check - GENERAL.CHECK_NULL [SP-007] on PD_INVENTORY.PHY_BIN_LOC | When the user moves off the physical bin location field. | The physical bin location identifies where the surplus stock is actually located; it is required when bin management is active. | Mandatory-field error for "Bin Location" - trigger failure. |

**Step 3 - Bin location existence is checked and new-location rules are applied**
The system checks whether the entered physical bin location exists in the stock records. If not found and the difference quantity is zero or negative, the entry is rejected. If not found and there is a positive difference, the system uses the store name to inform the user that a new bin location will be created - unless the name is the reserved "NO BIN" placeholder.

*Procedures called:*
- **SF_GET_STORE_NAME** ([SP-030](#sp-030)) - SF_GET_STORE_NAME - retrieves the human-readable store name for the current dealer, location, and store code, for use in the new-bin-location informational message.
    * **Step 1** - Accept the dealer, location, and store code identifiers.
    * **Step 2** - Look up the store name in the store master.
    * **Step 3** - Return the store name to the caller.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Bin location not found with no positive difference | Not-found check - WHEN-VALIDATE-ITEM on PD_INVENTORY.PHY_BIN_LOC own condition (lv_count = 0 AND diff_qty <= 0) | When bin location is not found in stock records and no increase is expected. | Prevents a new bin location from being created for a part row that does not have a positive variance to place there. | *"Bin Location [bin location] not found."* - trigger failure. |
| "NO BIN" cannot be a new physical bin location | Reserved name - WHEN-VALIDATE-ITEM on PD_INVENTORY.PHY_BIN_LOC own condition (UPPER(phy_bin_loc) = 'NO BIN' and diff_qty > 0) | When bin location is not found and difference is positive. | "NO BIN" is a system placeholder and must not be used as a user-defined bin location. | *"NO BIN is system generated Bin Location. Please choose another name."* - trigger failure. |
| New bin location informational notice | Store name - SF_GET_STORE_NAME [SP-030] (called when bin not found and diff_qty > 0 and not 'NO BIN') | When a new bin location is being created for a positive-difference row. | Informs the user that a new bin location will be created in the identified store so they are aware of the system action. | *"New Bin Location [bin location] in [store name] will be created."* - informational message, no failure. |

**Alternative Flows:**
- **BR-035-AF-01** - (from Step 1) Bin-location management is not enabled for the dealer: the entire validation is skipped.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Physical Bin Location (`PHY_BIN_LOC`) | Mandatory (when bin management enabled and difference > 0) | Character | 10 | Physical bin location list (LOV_TO_BIN_LOC_CD) | Bin location code | Bin management enabled; physical quantity entered | Must not be blank; must not be "NO BIN" as a new name; must exist when difference ≤ 0 | *"Bin Location [loc] not found."* / *"NO BIN is system generated Bin Location. Please choose another name."* |
| Difference Quantity (`DIFF_QTY`) | Auto-populated | Numeric | 9,99,99,999.000 | N/A | Physical qty minus stock qty | Physical quantity entered | Read-only; recalculated | N/A |

---

---

---

---

#### Requirement ID: BR-036

**Requirement Title:** Tax Type - Conditional Mandatory Validation

**Business Description:**
When the user moves off the tax type field for a part row, the system checks whether the tax type is required. The tax type is required only when the difference quantity is positive (meaning stock is being increased) and the tax flag is enabled for the form session. When the difference is zero or negative, the tax type field is cleared automatically as it is not applicable for stock decreases. This ensures tax type is captured for every stock increase while preventing its incorrect application to decreases.

**Actors:** Stock Controller

**Preconditions:**
- The user is on a part detail row and has moved off the tax type field.

**Main Flow:**

**Step 1 - Tax type required for positive difference when tax flag is enabled**
If the tax control flag is set and the difference quantity is positive, the system confirms the tax type field is not blank.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-007](#sp-007)) - GENERAL.CHECK_NULL - checks that the tax type is not blank when required.
    * **Step 1** - Receive the field value and label "Tax Type".
    * **Step 2** - Check whether the field value is null.
    * **Step 3** - If null, display a mandatory-field error for "Tax Type" and raise a trigger failure; otherwise continue.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Tax type required for positive-difference rows when tax flag is enabled | Mandatory check - GENERAL.CHECK_NULL [SP-007] on PD_INVENTORY.TAX_TYPE when (p_tax_flag = 'Y' AND diff_qty > 0) | When the user moves off the tax type field. | Tax type is required for positive stock adjustments so the correct tax treatment can be applied during the adjustment process. | Mandatory-field error for "Tax Type" - trigger failure. |

**Step 2 - Tax type cleared for zero or negative difference**
When the difference quantity is zero or negative, the tax type field is cleared, as tax is not applicable to stock decreases.

**Alternative Flows:**
- **BR-036-AF-01** - (from Step 1) Tax control flag is not set (disabled): neither the mandatory check nor the clearing runs; the tax type field state is left unchanged.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Tax Type (`TAX_TYPE`) | Conditional - mandatory when difference > 0 and tax flag enabled | Character list | 3 | N/A | Tax type options | Positive difference quantity and tax flag enabled | Required when difference > 0 and tax flag active; cleared when difference ≤ 0 | Mandatory-field error for "Tax Type" |
| Difference Quantity (`DIFF_QTY`) | Read-only display | Numeric | 9,99,99,999.000 | N/A | Calculated value | Physical quantity entered | Read-only | N/A |

---

---

---

---

#### Requirement ID: BR-037

**Requirement Title:** Part Detail Remarks Entry and Row Navigation

**Business Description:**
The Remarks field on each part detail row allows the stock controller to note any relevant observation about that part's count. The user can click a dedicated button to open an expanded text editing area for the remarks field when the standard field size is insufficient. When navigating past the remarks field using the keyboard, the cursor advances to the next detail row rather than to the next field, supporting a quick row-by-row counting workflow.

**Actors:** Stock Controller

**Preconditions:**
- The part detail section is open with at least one populated row.

**Main Flow:**

**Step 1 - Remarks text editor opened when user clicks the edit button**
The user clicks the remarks expansion button, and the system moves focus to the remarks field and opens a text-editing dialog sized 100 by 100 pixels so the user can enter a longer comment.

**Step 2 - Keyboard navigation from remarks advances to the next row**
When the user moves off the remarks field using the keyboard, the cursor advances to the next detail row, bypassing individual field navigation to support efficient row-by-row data entry.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Remarks (`REMARKS`) | Optional | Character | 100 | N/A | Free text entered by user | Part detail row active | No validation; optional free text | N/A |

---

---

---

---

#### Requirement ID: BR-038

**Requirement Title:** Adjustment Panel - Stock Taken By and Reason Mandatory Validation

**Business Description:**
When the user confirms the adjustment details on the stock adjustment confirmation panel, the system validates that the name of the person who took the stock count and the reason for adjustment have both been provided. These fields are required to ensure every stock adjustment has a responsible person identified and a documented justification.

**Actors:** Stock Controller

**Preconditions:**
- The adjustment confirmation panel is visible.
- The user is confirming the adjustment details before submitting.

**Main Flow:**

**Step 1 - Stock counter name is required when the adjustment action is in progress**
If the adjustment process has been initiated, the system confirms the stock-taken-by field is not blank.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-007](#sp-007)) - GENERAL.CHECK_NULL - checks that the stock-taken-by field is not blank.
    * **Step 1** - Receive the field value and label "Name".
    * **Step 2** - Check whether null.
    * **Step 3** - If null, display mandatory-field error for "Name" and raise failure; otherwise continue.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Stock counter name required during adjustment | Mandatory check - GENERAL.CHECK_NULL [SP-007] on B_ADJ.STOCK_TAKEN_BY when (gen_click = 'Y') | When the user validates the stock-taken-by field during an adjustment. | Identifies the responsible stock counter for audit purposes. | Mandatory-field error for "Name". |

**Step 2 - Adjustment reason is required when the adjustment action is in progress**
The system confirms the reason field is not blank.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-007](#sp-007)) - GENERAL.CHECK_NULL - checks that the reason field is not blank.
    * **Step 1** - Receive the field value and label "Reason".
    * **Step 2** - Check whether null.
    * **Step 3** - If null, display mandatory-field error for "Reason" and raise failure; otherwise continue.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Adjustment reason required during adjustment | Mandatory check - GENERAL.CHECK_NULL [SP-007] on B_ADJ.REASON when (gen_click = 'Y') | When the user validates the reason field during an adjustment. | Provides a documented justification for the stock adjustment. | Mandatory-field error for "Reason". |

*Screen: ADJUSTMENT DETAILS (`CN_ADJ`).*

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Stock Taken By (`STOCK_TAKEN_BY`) | Conditional - mandatory when adjustment is in progress | Character list | 8 | N/A | Employee name/code | Adjustment action initiated | Required when adjustment is being processed | Mandatory-field error for "Name" |
| Reason (`REASON`) | Conditional - mandatory when adjustment is in progress | Character list | 50 | N/A | Adjustment reason | Adjustment action initiated | Required when adjustment is being processed | Mandatory-field error for "Reason" |

---

---

---

---

#### Requirement ID: BR-039

**Requirement Title:** Stock Adjustment Generation from Physical Inventory Count

**Business Description:**
When the stock controller confirms the adjustment details and submits the OK button on the adjustment panel, the system validates all part rows in the count for completeness and consistency, checks the monthly SAN limit for applicable dealer categories, generates a unique adjustment document number, creates the stock adjustment header record, inserts individual adjustment detail lines for every part with a non-zero difference, and saves the full transaction. If all physical counts match the system quantities, the user is informed that no adjustment is needed. This is the key transaction that commits the physical inventory count results into the stock adjustment records, making the count permanent.

The adjustment process is only available once the form has initialised. On form open, the system sets session control flags (`global.adj_click = N`, `global.gen_click = N`, `global.stk_adj = N`, `parameter.p_tax_flag = Y`, `parameter.p_commit_form = N`) and populates the Reason dropdown from record group `reason` and the Employee (stock-taken-by) dropdown from record group `emp`, as well as the Store dropdown from record group `Stores`, the Category dropdown from record group `Category`, and the Margin Category dropdown from record group `margin_Category`. If the consignee code cannot be fetched at form open, the user sees *"Execution failed while fetching Consignee Code"* and the form does not load. For dealers in the MAS category, the SAN limit is also pre-fetched; if that fetch fails in an unexpected way the system records *"Execution failed while fetching defined SAN Limit"* (suppressed as null in current code). These initialisation steps are documented in full in BR-002.

**Actors:** Stock Controller

**Preconditions:**
- The adjustment confirmation panel is visible with the stock-taken-by and reason fields completed.
- Physical count quantities have been entered and validated for at least one part detail row.

**Main Flow:**

**Step 1 - Validation errors are checked across all part detail rows**
The system iterates through every part detail row and collects errors: rows with a positive difference but no tax type assigned, and rows with a negative difference exceeding the current available stock (net of allocated and float quantities). All collected errors are shown on an error display panel before any adjustment is created. If errors exist, the adjustment process stops and the user must correct the issues before resubmitting.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Tax type required for positive difference rows | Tax type pre-check - WHEN-BUTTON-PRESSED on B_ADJ.OK own condition (diff_qty > 0 AND tax_type IS NULL) per row | When the OK button is clicked; checked for each detail row. | Every stock increase must have a tax type assigned before the adjustment can be created. | Error collected: "Invalid Tax Type for Part No. [part number] at line no. [row]" - adjustment stops; errors displayed. |
| Sufficient stock available for negative adjustments | Insufficient stock - WHEN-BUTTON-PRESSED on B_ADJ.OK own condition (diff_qty < 0 AND ABS(diff_qty) > nb_current_stock) per row | When the OK button is clicked; checked for each detail row. | A stock reduction cannot exceed the net current stock available; reducing below zero would create an invalid inventory position. | Error collected: "Insufficient stock to reduce difference quantity for Part No. [part number] at line no. [row]" (with allocated and float stock details appended where applicable) - adjustment stops; errors displayed. |

**Step 2 - At least one part has a non-zero difference**
If no part row has a non-zero difference quantity, the system informs the user that no adjustment is required and the process ends.

*Business outcomes (errors, warnings, success, and status):*
- **BR-039-WS-01** - No differences found - *"Physical quantity and DMS quantity are matching. No Adjustment Required"* - shown when all physical quantities match the system quantities.

**Step 3 - Monthly SAN limit is checked for applicable dealer categories**
For dealers in specific categories, the system calculates the total monetary value of all stock increases and decreases in the adjustment. If the cumulative monthly adjustment value (including any pre-existing adjustment value for the month) meets or exceeds the allowed sanction limit plus any additional approved amount, the form closes without saving and the user is shown an error.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Monthly SAN limit not exceeded | SAN limit - WHEN-BUTTON-PRESSED on B_ADJ.OK own condition (dealer category IN applicable set AND month_adjust + values >= san_limit + san_limit_defined) | When differences are present and dealer is in an applicable category. | Ensures stock adjustments do not exceed the monthly value limit approved for the dealer, preventing unauthorised large-scale inventory changes. | *"Monthly SAN Limit exceeds [san_limit_defined] + [san_limit_amt]  (additional limit defined)."* - form closed without saving, trigger failure. |

**Step 4 - Adjustment document number is generated**
The system generates a unique adjustment document number using the sequential number generation routine.

*Procedures called:*
- **PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM** ([SP-013](#sp-013)) - PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM - generates the next sequential document number for the adjustment document type in the current financial year.
    * **Step 1** - Accept the dealer, principal, location, financial area, document type ("ADJ"), financial year, and current date.
    * **Step 2** - Retrieve the last used sequence number for the adjustment document type in the current financial year.
    * **Step 3** - Apply the business rules to generate the next valid document number.
    * **Step 4** - Return the generated document number and any error indicator to the caller.
    * **Step 5** - If an error is returned, display the error message and stop.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Adjustment document number generated | Number generation - PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM [SP-013] | After SAN limit check passes. | Assigns a unique, sequential adjustment document number to identify this stock adjustment in the system. | Error message from routine displayed - trigger failure. |

**Step 5 - Stock adjustment header record is inserted**
The system creates the stock adjustment header record with the generated document number, dealer, location, financial area, parent group, today's date as the adjustment date, the selected store, and the current user as creator.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Stock adjustment header insert succeeds | Header insert - WHEN-BUTTON-PRESSED on B_ADJ.OK own condition (INSERT INTO PH_STKADJ) | After document number is generated. | Creates the parent adjustment document that all detail lines will be linked to. | *"Width problem/Incompatible data while inserting in Stock adjustment header"* (VALUE_ERROR), *"Trying to create duplicate data"* (DUP_VAL_ON_INDEX), *"Execution failed while inserting in Stock adjustment header [newline][SQLERRM]"* (WHEN OTHERS) - trigger failure. |

**Step 6 - Stock adjustment detail lines are inserted for every part with a non-zero difference**
For each part row with a non-zero difference quantity, the system inserts a detail line into the stock adjustment detail table. The line includes the part number, the direction (increase or decrease), tax type, adjusted quantity (always stored as an absolute positive number), landed cost, currency, and the calculated increase or decrease monetary value based on the landed cost. The physical bin location is recorded.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Stock adjustment detail insert succeeds | Detail insert - WHEN-BUTTON-PRESSED on B_ADJ.OK own condition (INSERT INTO PD_STKADJ) | For each part row with non-zero difference. | Records the individual part-level adjustment lines that will be processed to update the stock quantities. | *"Width problem/Incompatible data while inserting in Stock adjustment detail"* (VALUE_ERROR), *"Trying to create duplicate data"* (DUP_VAL_ON_INDEX), WHEN OTHERS: STOCK_UPDATE_EXCEPTION called - trigger failure. |

*Procedures called:*
- **STOCK_UPDATE_EXCEPTION** ([SP-004](#sp-004)) - STOCK_UPDATE_EXCEPTION - handles stock update error codes returned by the backend procedure and displays the appropriate specific error message based on the error code received.
    * **Step 1** - Accept the SQL error code and part number from the caller.
    * **Step 2** - Identify which specific error condition the code represents (width error, execution failure, duplicate, locking conflict, etc.).
    * **Step 3** - Display the corresponding specific error message to the user.
    * **Step 4** - Raise a trigger failure to stop the current operation.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Stock update error handling | Stock exception - STOCK_UPDATE_EXCEPTION [SP-004] (WHEN OTHERS on detail insert) | When an unexpected error occurs during detail line insertion. | Translates internal stock update error codes into specific, actionable messages so the user knows exactly what went wrong and which part caused the failure. | Specific error message based on error code - trigger failure. |

**Step 7 - Adjustment number is confirmed and transaction is saved**
After all detail lines are inserted, the system displays a success message with the generated adjustment number. The stock-taken-by name is copied from the adjustment panel to the header. The session is flagged as having gone through the adjustment process. The save trigger is fired to commit the transaction.

*Business outcomes (errors, warnings, success, and status):*
- **BR-039-SM-01** - Adjustment successfully created - *"Adjustment Number generated is [adjustment number]"*; all rows inserted and save triggered.

**Step 8 - Adjustment panel is hidden and session state is updated**
After the save, the adjustment panel is hidden and the stock-taken-by session flag is set, preventing the adjustment from being re-generated.

**Alternative Flows:**
- **BR-039-AF-01** - (from Step 1) Stock-taken-by or reason is blank: the system calls the mandatory-field check for each and stops before any processing begins.
- **BR-039-AF-02** - (from Step 3) Dealer category is not in the applicable SAN-limit set: the SAN limit check is skipped and processing continues to number generation.
- **BR-039-AF-03** - (from the overall flow) An unexpected error occurs: the adjustment number on the header and all detail rows is cleared, a rollback is performed, and the cursor returns to the current detail row.
- **BR-039-AF-04** - (from Step 1) Validation errors are collected: the error display panel is shown; the cursor moves to the error display area and the process stops until the user corrects the errors.

**Business Scenarios - How the adjustment value differs by dealer category**

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **SAN-limit applicable dealer** | For dealers in applicable categories, the total increase and decrease monetary values (landed cost × quantity) are accumulated across all parts with differences in the specific categories; the cumulative monthly value is checked against the sanction limit. |
| **Other dealers** | The SAN limit check is skipped; the adjustment proceeds directly to document number generation. |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Stock Taken By (`STOCK_TAKEN_BY`) - adjustment panel | Mandatory | Character list | 8 | N/A | Employee name/code | Adjustment OK clicked | Must not be blank | Mandatory-field error for "Name" |
| Reason (`REASON`) - adjustment panel | Mandatory | Character list | 50 | N/A | Adjustment reason | Adjustment OK clicked | Must not be blank | Mandatory-field error for "Reason" |
| Adjustment Number (`ADJ_NUM`) | Auto-populated | Character | 12 | N/A | Generated by system | All validations passed | System-generated; not user-editable | Error from number generation routine |
| Tax Type (`TAX_TYPE`) - per detail row | Conditional - mandatory for positive difference rows | Character list | 3 | N/A | Tax type | Positive difference exists for row | Required for stock increases | "Invalid Tax Type for Part No. [part] at line no. [row]" |

---

---

---

---

#### Requirement ID: BR-040

**Requirement Title:** Part Number Quick Search in Count Grid

**Business Description:**
When the user enters a part number in the search panel and clicks the Search button, the system scans all loaded part detail rows and navigates the cursor directly to the row that matches the entered part number. If no matching row is found, the cursor returns to the first row and the user is informed that no match exists. This allows the stock controller to quickly locate a specific part in a long count list without manually scrolling.

**Actors:** Stock Controller

**Preconditions:**
- The part detail section has been populated with count rows.
- The user has entered a part number in the search field on the search panel.

**Main Flow:**

**Step 1 - Part detail rows are scanned for a matching part number**
The system iterates through all loaded part rows to find one whose part number matches the entered search value. The first matching row is selected and focus moves to the part number field on that row.

**Step 2 - If no match is found, user is informed and returned to the first row**
If no row matches the entered part number, the cursor moves to the first row and a notice is displayed.

*Business outcomes (errors, warnings, success, and status):*
- **BR-040-WS-01** - No matching part found - *"No matching Record"* - user is redirected to the search field to re-enter or correct the part number.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Part Number Search (`PART_NUM1`) | Optional | Character | 15 | N/A | Part number to search for | Count detail rows populated | No validation on input; match is case-sensitive as entered | N/A |

---

---

---

---

#### Requirement ID: BR-041

**Requirement Title:** Print Physical Inventory Report

**Business Description:**
When the user initiates a print action for the physical inventory count, the system prompts them to choose a print destination (view on screen or send to a printer) and then submits the report job to the report server. The report is built with the current count document number, dealer, location, financial area, user name, principal, and a report identifier as parameters.

**Actors:** Stock Controller

**Preconditions:**
- A physical inventory count document is loaded and the Print button is available.

**Main Flow:**

**Step 1 - User selects a print destination**
The system displays a print destination selection prompt. The user may choose to view the report on screen or print it directly to a physical printer.

*Procedures called:*
- **GENERAL.ASK_PRINT** ([SP-006](#sp-006)) - GENERAL.ASK_PRINT - displays a "Select Destination" prompt to the user and returns their selection (screen/cache or printer).
    * **Step 1** - Display the print destination selection dialog with the label "Select Destination".
    * **Step 2** - Wait for the user to select a destination option.
    * **Step 3** - Return the selected option identifier to the caller.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Print destination selected | Destination prompt - GENERAL.ASK_PRINT [SP-006] | When the user initiates the print action. | Gives the user control over how the report is delivered before committing the report server request. | If neither screen nor printer is selected (user cancels), the report job is not submitted. |

**Step 2 - Report is submitted to the report server**
If a valid destination was chosen, the system builds the report parameter string (with the count document number and session identifiers) and submits the report job to the report server.

*Procedures called:*
- **RUN_REPORT** ([SP-023](#sp-023)) - RUN_REPORT - submits the physical inventory report to the configured report server with the given parameters and output destination.
    * **Step 1** - Accept the form name, destination type, parameter list, and report server name.
    * **Step 2** - Submit the report job to the report server.
    * **Step 3** - Return the job handle or any error to the caller.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Report submitted successfully | Report submission - RUN_REPORT [SP-023] | After print destination is confirmed. | Triggers the report server to generate and deliver the physical inventory count report to the selected destination. | SQLERRM displayed if submission fails. |

> **Note (PRINT_REPORT program unit - COMMENTED OUT / INACTIVE - does not execute):** A prior implementation of this report call exists as `PRINT_REPORT`, with the entire body commented out. It is replaced by `PRINT_AS`.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Count Document Number (`INV_NUM`) - parameter | Auto-populated | Character | 12 | N/A | Current count document number | Count document loaded | System-set as report parameter | N/A |
| Report ID (`P_REP_ID`) - parameter | Auto-populated | Character | N/A | N/A | Report identifier from session parameter | Report initiated | System-set as report parameter | N/A |

---

---

---

---

#### Requirement ID: BR-042

**Requirement Title:** Print Physical Inventory Count with Stock Report

**Business Description:**
When the print action for the inventory count with stock report is triggered, the system first asks whether the report should include stock quantities, then confirms the output format (view on screen as PDF or send to printer), and submits the report job to the report server with all the relevant session and document parameters. The report file used is `pr_inventory`.

**Actors:** Stock Controller

**Preconditions:**
- A physical inventory count document is loaded and the print action for the inventory report has been initiated.

**Main Flow:**

**Step 1 - User selects whether to include stock quantities in the report**
The system displays an alert to ask whether the report should be printed with stock quantities. The user selects one of the alert options.

**Step 2 - If the user accepts, they confirm whether to print with stock**
If the user chose to proceed (alert button 1 or 2), the system asks the question *"Do you want to print with Stock?"* and records the user's yes/no answer as a session flag.

*Procedures called:*
- **GENERAL.ASK_CONFIRM** ([SP-005](#sp-005)) - GENERAL.ASK_CONFIRM - displays a confirmation dialog with the question "Do you want to print with Stock?" and returns the user's choice (confirmed or declined).
    * **Step 1** - Display the confirmation question to the user.
    * **Step 2** - Wait for the user to select Yes or No.
    * **Step 3** - Return the choice identifier to the caller.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Stock inclusion confirmed | Confirmation - GENERAL.ASK_CONFIRM [SP-005] | After user accepts the initial report alert. | Allows the user to decide whether the printed inventory report should show current stock quantities alongside the counted quantities. | If user declines, the report is still submitted but with the stock-exclusion flag set. |

**Step 3 - Report is submitted in the selected format and to the selected destination**
For alert button 1 (PDF on screen): the report is set to PDF format and submitted to the report server. The report job result is obtained and the PDF is displayed in the browser. For alert button 2 (printer): the report is submitted for direct printing. Parameters passed include the principal, parent group, dealer, location, financial area, document number, and the stock-inclusion flag (`GLOBAL.p_type`; `Y` = with stock, `N` = without stock). The report destination parameters include `MODE=CHARACTER BLANKPAGES=NO`.

*Procedures called:*
- **GENERAL.PROC_REPORT_CALL** ([SP-009](#sp-009)) - GENERAL.PROC_REPORT_CALL - submits the report job to the report server and manages the report handle for status polling.
    * **Step 1** - Accept the report object, server, and parameter configuration including the destination string `MODE=CHARACTER BLANKPAGES=NO`.
    * **Step 2** - Submit the report job to the report server.
    * **Step 3** - Return the report job handle to the caller for status monitoring.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Report job submitted | Report call - GENERAL.PROC_REPORT_CALL [SP-009] | After destination and format are confirmed. | Triggers the report server to generate the inventory report with the selected parameters and deliver it to the user. | Report server errors are handled by the report object status polling mechanism. |

---

---

---

---

#### Requirement ID: BR-043

**Requirement Title:** Print Physical Inventory Counting Sheet Report

**Business Description:**
When the print action for the physical inventory counting sheet is triggered, the system presents an output format choice to the user and submits the report job to the report server with the count document number, date, and session parameters. The report file used is `pr_phy_pdf`.

**Actors:** Stock Controller

**Preconditions:**
- A physical inventory count document is loaded and the print action for the counting sheet has been initiated.

**Main Flow:**

**Step 1 - User selects report output format**
An alert is displayed for the user to choose between viewing the report as a PDF on screen or printing it directly.

**Step 2 - Report is submitted in the selected format**
Based on the user's choice, the system configures the report object for PDF output and submits the job to the report server. Parameters include parent group, financial area, dealer, location, count document number, and count date.

*Procedures called:*
- **GENERAL.PROC_REPORT_CALL** ([SP-009](#sp-009)) - GENERAL.PROC_REPORT_CALL - submits the report job to the report server and manages the report handle for status polling.
    * **Step 1** - Accept the report object, server, and parameter configuration.
    * **Step 2** - Submit the report job to the report server.
    * **Step 3** - Return the report job handle to the caller for status monitoring.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Report job submitted | Report call - GENERAL.PROC_REPORT_CALL [SP-009] | After output format is confirmed. | Generates the physical inventory counting sheet report and delivers it to the selected destination. | Report server errors handled via the report status monitoring mechanism. |

> **Note (debug messages - COMMENTED OUT / INACTIVE - do not execute):** Two debug display messages (*"INSIDE  PROC 1"* and *"INSIDE  PROC 2"*) that were added during development are commented out and do not appear to the user.

---

---

---

---

#### Requirement ID: BR-044

**Requirement Title:** Form Utility Program Units - List Population and Duplicate Check Helpers (not invoked by current triggers)

**Business Description:**
The Physical Inventory form contains three utility program units for dynamically populating list items from a database query and one utility for checking duplicate records within a data block. These utilities are defined in the form and are active (not commented out), but no active trigger or other program unit within the current form calls them. They appear to be general-purpose helpers retained from an earlier development phase. Their functions are: loading record-group data into a named list field, populating list items from the catalogue list table, and populating a stores list from the store master. The prototype-time store population query contains a hardcoded dealer and location (7001 and '01') that would need updating for production use. A duplicate-record check utility is also defined but not currently invoked.

**Actors:** N/A (no active call site in the current form)

**Preconditions:** N/A

**Main Flow:**

**Step 1 - Utility program units are defined in the form; CHK_DUP is invoked by the Save process**
`L_POP_LIST_ITEM`, `L_POPULATE`, and `POPULATE_STORES` are present as active program units that are not directly invoked by current triggers in the main form flow. `CHK_DUP` is also present and is actively called during the Save process (see BR-008): it is invoked as `CHK_DUP('Part Number or Bin Location', 'PD_INVENTORY.part_num', 'PD_INVENTORY.bin_loc')` to detect duplicate part-number and bin-location entries across all count detail rows before saving. `L_POP_LIST_ITEM`, `L_POPULATE`, and `POPULATE_STORES` have no trigger call sites in the current form operation flow.

---

---

---

---

#### Requirement ID: BR-045

**Requirement Title:** Inactive Triggers - Non-Executing Code Register (COMMENTED OUT / INACTIVE - does not execute)

**Business Description:**
The following triggers are defined in the Physical Inventory form but are entirely inactive - their code bodies are either commented out and replaced with a `null;` placeholder or are equivalent no-operations. They do not execute at run time and have no effect on the current form behaviour. They are documented here to provide a complete record of all form triggers.

**Actors:** N/A (inactive)

**Preconditions:** N/A

**Main Flow:**

**Step 1 - Inactive triggers (COMMENTED OUT / INACTIVE - does not execute)**

The following triggers do not execute:

- **KEY-COMMIT (Form level)** - The save-shortcut-key implementation (commit, print, and clear-form sequence) is entirely commented out, replaced by `null;`.
- **WHEN-VALIDATE-ITEM on B_DUMMY.NB_INV_NO** - Inventory number existence validation was commented out and replaced by `null;`. The equivalent active logic is in the KEY-NEXT-ITEM trigger on the same item (BR-003).
- **KEY-PREV-ITEM on B_DUMMY.NB_INV_NO** - `NULL;` only.
- **KEY-DOWN on PH_INVENTORY** - Active: when the Down key is pressed on the inventory header and the current record's status is NEW (i.e. the user is already at the last row), the system displays *"This is the Last Row"* and stops further navigation; otherwise `NEXT_RECORD` is called. (Note: an older prototype comment precedes the active code block; the code itself executes.)
- **KEY-UP on PH_INVENTORY** - Active: when the Up key is pressed on the inventory header and the system is on the first record (`SYSTEM.TRIGGER_RECORD = '1'`), the system displays *"This is the first Row"* and stops further upward navigation; otherwise `PREVIOUS_RECORD` is called. (Note: an older prototype comment precedes the active code block; the code itself executes.)
- **WHEN-LIST-CHANGED on PH_INVENTORY.ENTRY_MODE** - A list-change handler for bin-location visual attribute switching is entirely commented out and replaced by `null;`.
- **POST-TEXT-ITEM on PD_INVENTORY.PHYSICAL_QTY** - A landed-cost check, adjustment button enable, and difference calculation that ran after the user typed a physical quantity is entirely commented out and replaced by `null;`. The equivalent active logic is in WHEN-VALIDATE-ITEM on the same item (BR-033).
- **WHEN-NEW-ITEM-INSTANCE on PD_INVENTORY.REMARKS** - A comment explains the intent (validating that a null tax type is not stored for positive differences), but the code body is `NULL;`.
- **WHEN-VALIDATE-ITEM on B_EMP.NB_AUTH_EMP** - Authorised signatory validation was commented out with a note "Commented by Pankaj on 07-05-2004", replaced by `null;`.

---

---

## 5. Business Rules Catalogue

| Rule ID | Rule Name | Rule Type | Business Requirement ID | Condition | Action | Business Impact |
| ------- | --------- | --------- | ----------------------- | --------- | ------ | --------------- |
| BRC-001 | Count Number Existence Check | Validation | BR-003 | A count number is entered in the count number field. | The system checks whether that count number exists for the current dealer, location, and financial area. If not found, it displays *"Physical Inventory Number not found"* and keeps the cursor on the field. | Prevents the user from inadvertently working with a non-existent count document. |
| BRC-002 | Date Value Validity | Validation | BR-004 | A date-format error is raised for a field (error code 50004). | The system intercepts the error and shows *"Entered Date is not valid Date"*, stopping the current operation. | Ensures only valid date values are accepted in date fields. |
| BRC-003 | Date Format Compliance | Validation | BR-004 | A date-format error is raised (error codes 50025 or 50026). | The system shows *"Enter the Date in the proper format (DD-MM-YYYY)"* and stops the operation. | Guides users to enter dates in the required format. |
| BRC-004 | Numeric Field Input Only | Validation | BR-004 | Non-numeric input is detected in a numeric field (error codes 40209 or 50016). | The system shows *"Characters/Special Characters are not allowed here, enter the numeric value"* and stops the operation. | Prevents invalid characters from being stored in numeric fields. |
| BRC-005 | Referential Integrity Constraint | Constraint | BR-004 | A database referential-integrity violation occurs (DBMS error -02292). | The system raises the pre-defined constraint error message via the error-message library and stops the operation. | Protects parent-child data consistency in the database. |
| BRC-006 | Concurrent Record Update Protection | Constraint | BR-004 | A save or update detects that another user has already modified the record (error codes 40654-40659). | The system shows *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*, rolls back the transaction, and stops the operation. | Prevents data loss from concurrent updates by two users to the same record. |
| BRC-007 | Bin-Location Control Flag Governs Field Availability | Derivation | BR-002, BR-025, BR-031, BR-032, BR-035, BR-036 | The form is initialised or reset. | The system retrieves the bin-location control setting from the dealer configuration. When the setting is disabled, bin location fields throughout the form are locked and bin-location validations are skipped; when enabled, bin location fields are active and validations apply. | Ensures the form is correctly configured for the dealer's bin-location management setup. |
| BRC-008 | Store Mandatory Before Count Activities | Validation | BR-016, BR-026 | The user attempts to move to the part detail section or clicks Populate without a store selected. | The system shows *"Enter a valid Stores Code"* and redirects the cursor to the store field. | A physical inventory count must always be scoped to a specific store. |
| BRC-009 | Count Date Back-Date Compliance | Validation | BR-015 | A new count is being created and the user enters a count date. | The system validates the date against the back-dating policy for physical inventory documents. If non-compliant, the validation routine's error message is displayed and the user must correct the date. | Maintains the integrity of the sequential physical inventory document history. |
| BRC-010 | Price Type Required Before Price Range | Validation | BR-018 | The user enters a price boundary value without having first selected a price type. | The system shows *"Please Select the Price first"* and stops the operation. | A price filter without a price type is meaningless; the price type determines which price column is compared. |
| BRC-011 | Price Boundary Non-Negative | Validation | BR-018 | A price boundary value entered is less than zero. | The system shows *"Part price cannot be less than zero"* (for the minimum) or *"Price Cannot be less than zero"* (for the maximum) and stops the operation. | Negative price boundaries have no business meaning for inventory filtering. |
| BRC-012 | Price Range Validity (Max ≥ Min) | Validation | BR-018 | The maximum price boundary is less than the minimum price boundary. | The system shows *"Enter a Valid Price Range"* and stops the operation. | Prevents a reversed range that would return no results. |
| BRC-013 | Part Number Range Must Be Paired | Validation | BR-019 | A starting part number is entered but no ending part number, or an ending part number is entered without a starting one. | The system either requires the ending part number or shows *"Valid From Part Number is required for entering To Part Number"* and stops. | A part number range filter must have both ends defined to be meaningful. |
| BRC-014 | Part Number Existence for Principal Account | Validation | BR-019, BR-031 | A part number is entered and the current dealer is the principal account. | The system checks that the part number exists in the parts master. If not found, it shows *"Invalid Part Number"* and stops. | Ensures only valid part numbers are used as filter or count identifiers for the principal dealer. |
| BRC-015 | Bin Location Range Must Be Paired | Validation | BR-020 | A starting bin location is entered but no ending one, or vice versa. | The system either requires the ending bin location or shows *"Valid From Bin Location is required for entering To Bin Location"* and stops. | A bin location range filter must have both ends to be valid. |
| BRC-016 | Bin Location Segment Ranges Must Be Paired | Validation | BR-024 | A "to" bin segment is entered without a corresponding "from" segment (for Area, Row, Rack, Shelf, or Bin levels). | The system shows *"Valid From [segment] is required for entering To [segment]"* and stops. | Each bin location segment range must have a complete from-to pair. |
| BRC-017 | Populate Requires Part Number or Bin Location Range | Validation | BR-025 | The Populate button is clicked with neither a part number range nor a bin location range entered. | The system shows *"Either Part Number or Bin Location has to be entered."* and stops. | Prevents an unrestricted full-catalogue population that would be too large for a meaningful physical count. |
| BRC-018 | Populate Button Enabled Only When Range Is Complete | Derivation | BR-019, BR-020 | The user finishes entering either the part number range or the bin location range. | The system enables the Populate button when both fields of a range pair are filled; otherwise it remains disabled. | Ensures the Populate action is available only when a valid range filter has been provided. |
| BRC-019 | Part Mandatory in Manual Entry Mode | Validation | BR-031 | A part detail row is being validated in manual entry mode and the part number field is blank. | The system shows a mandatory-field error for "Part Number" and stops. | A manual count row must have a part number to be meaningful. |
| BRC-020 | Landed Cost Must Be Positive to Allow Adjustment | Validation | BR-031 | A part is validated in manual entry mode and its retrieved landed cost is zero or less. | The system shows *"Adjustment for the part [part number] is not possible! landed cost fetched is 0."* and stops. | A zero landed cost makes stock adjustment value calculations meaningless; parts with no cost cannot be adjusted. |
| BRC-021 | Bin Location "NO BIN" Is a Reserved System Name | Constraint | BR-032, BR-035 | The user enters "NO BIN" as a bin location or physical bin location name when the value does not already exist in the stock records. | The system shows *"NO BIN is system generated Bin Location. Please choose another name."* and stops. | "NO BIN" is a system-assigned placeholder; users must not create a real bin location with that name. |
| BRC-022 | Physical Quantity Must Not Be Negative | Validation | BR-033 | The user enters a negative value in the physical count quantity field. | The system shows *"Physical Quantity Cannot be less than zero"* and stops. | A negative physical count is not a valid business value. |
| BRC-023 | Decimal Quantity Compliance | Validation | BR-033 | A physical quantity is entered for a part that does not permit decimal quantities. | The system silently truncates the value to a whole number. If the decimal flag is in an error state, it shows *"Error executed for judging decimal for Physical Qty"* and stops. | Ensures count quantities are consistent with the part's unit definition. |
| BRC-024 | Tax Type Required for Positive Difference | Validation | BR-036, BR-039 | The difference quantity for a part row is positive and the tax flag is enabled, and the tax type field is blank. | The system shows a mandatory-field error for "Tax Type" and stops. | Every stock increase must have a tax type assigned for correct tax treatment in the adjustment. |
| BRC-025 | Tax Type Cleared for Non-Increasing Rows | Derivation | BR-033, BR-036 | The difference quantity for a row is zero, negative, or the physical quantity is blank. | The system automatically clears the tax type field for that row, as tax is only applicable to stock increases. | Prevents incorrect tax types being stored on rows that do not represent a stock increase. |
| BRC-026 | Physical Count Date Must Be Current or Past | Validation | BR-034 | The user enters a physical count date that is in the future. | The system shows *"Physical count date should not exceed the current date : [date]"* and stops. | A physical count cannot be recorded for a date that has not yet occurred. |
| BRC-027 | Physical Count Date Must Not Pre-date Document Date | Validation | BR-034 | The physical count date entered is earlier than the count document's inventory date. | The system shows *"Physical count date cannot be lesser than document date : [date]"* and stops. | The count date must fall within the valid period for the physical inventory document. |
| BRC-028 | Physical Count Date Required When Quantity Entered | Validation | BR-034 | A physical quantity is present on the row but the physical count date is blank. | The system shows a mandatory-field error for "Physical Count Date" and stops. | Every counted part must have a recorded count date for audit and traceability. |
| BRC-029 | Physical Count Date Only Valid When Quantity Is Present | Validation | BR-034 | A physical count date is entered but no physical quantity is on the row. | The system shows *"Physical qty cannot be null"*, clears the date field, and moves focus to the physical quantity field. | A count date without a quantity is inconsistent; the quantity must be entered first. |
| BRC-030 | Insufficient Stock Prevents Decrease Adjustment | Validation | BR-039 | A part row has a negative difference quantity and the absolute value of the difference exceeds the net current stock available. | The system collects an error: *"Insufficient stock to reduce difference quantity for Part No. [part number] at line no. [row]"* and prevents adjustment generation until corrected. | Prevents adjustments that would reduce stock below zero. |
| BRC-031 | Monthly SAN Limit Enforcement | Authorization | BR-039 | The total monetary value of the adjustment (increases and decreases) would exceed the dealer's monthly sanction limit for applicable dealer categories. | The system shows *"Monthly SAN Limit exceeds [limit] + [additional amount]  (additional limit defined)."*, closes the form without saving, and stops. | Enforces the authorised monthly limit on stock adjustment values for applicable dealer categories. |
| BRC-032 | Adjustment Requires Stock Counter and Reason | Validation | BR-038, BR-039 | The adjustment OK button is clicked without a stock counter name or adjustment reason provided. | The system shows mandatory-field errors for "Name" and "Reason" and stops. | Every stock adjustment must identify the responsible person and document the reason for audit and accountability. |
| BRC-033 | Default Tax Type from Dealer Configuration | Derivation | BR-033 | A physical quantity is entered for a part row where no adjustment exists and no tax type is set. | The system retrieves the default tax type from the dealer's location parameter table and applies it to the row. | Reduces manual data entry by automatically applying the dealer's standard tax type. |
| BRC-034 | Header Locked After Populate | Constraint | BR-025 | Parts have been successfully populated into the count grid. | The header filter section is locked against changes, the Populate button is disabled, and the population-complete flag is set, preventing re-population. | Prevents filter criteria from being changed after the count grid has been loaded. |
| BRC-035 | Difference Quantity Recalculated on Basis Change | Derivation | BR-023, BR-033, BR-032, BR-035, BR-001 | The stock adjustment basis is changed (between current stock and stock at generation), or a bin location or physical quantity change triggers a recalculation. | The system recalculates the difference quantity for the affected row(s) using the new basis. | Ensures the on-screen variance figures always reflect the currently selected adjustment basis. |

**Total Business Rules Identified: 35**

---

## 6. Data Requirements

*This section covers the business entities persisted and referenced by the Physical Inventory form (PT_PHY), the data captured during a physical count, the reference data used for lookups and validation, and the lifecycle of count and adjustment records.*

### 6.1 Business Entities and Relationships

*The Physical Inventory form centres on two core tables: the inventory count header (PH_INVENTORY) and the inventory count detail lines (PD_INVENTORY). When differences are found and an adjustment is generated, two further tables are written: the stock adjustment header (PH_STKADJ) and the stock adjustment detail lines (PD_STKADJ). Multiple reference and stock tables are also queried during the counting process.*

#### Physical Inventory Count Header - PH_INVENTORY

The inventory count header stores the controlling record for each physical stock count session. It records the dealer, location, financial area, parent group, count date, store, and the entry-mode and filter criteria used to define the scope of the count. It also carries the audit stamp (created and modified user and timestamp) and, after adjustment, the stock-taken-by and adjustment number. One header record is created per count session per store.

#### Physical Inventory Count Detail - PD_INVENTORY

Each part-level count line belongs to a parent count header and records the part number, bin location, physical bin location, the physical quantity counted, the system stock quantity at the time of count generation, the difference quantity, landed cost, tax type, direction (increase/decrease), remarks, physical count date, and audit stamp. The detail lines are the source data for the stock adjustment.

#### Stock Adjustment Header - PH_STKADJ

The stock adjustment header is created when a physical inventory count produces at least one part with a non-zero difference and the stock controller confirms the adjustment. It carries the adjustment document number, dealer, location, financial area, parent group, adjustment date, store, and the creating user.

#### Stock Adjustment Detail - PD_STKADJ

Each line of the stock adjustment records the part number, direction (increase or decrease), tax type, adjusted quantity, landed cost, currency, increase and decrease monetary values, bin location, remarks, and the creating user. Each detail line is linked to a parent adjustment header.

#### Entity Relationships

The Physical Inventory form maintains a header-detail relationship between the count header and its part detail lines, and writes to a corresponding header-detail structure in the stock adjustment tables when an adjustment is generated.

```
PH_INVENTORY (Count Header)
        └── PD_INVENTORY (Count Detail Lines)   <- linked by DOC_NUM + dealer + loc_cd + comp_fa + parent_group

PH_STKADJ (Adjustment Header)
        └── PD_STKADJ (Adjustment Detail Lines) <- linked by ADJ_NUM + dealer + loc_cd + comp_fa + parent_group
```

### 6.2 Data Capture Requirements

*The form captures physical count data in two groups: a header that defines the scope and metadata of the count session, and a set of detail lines - one per part and bin location - where the actual counted quantities are recorded.*

#### Count Session Header (Stock Controller - new or existing count)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Count Number (`NB_INV_NO`) | No | Identifier of an existing physical inventory count to load. When blank, a new count is started. | If entered, must match an existing count document for the current dealer, location, and financial area. |
| Count Date (`INV_DATE`) | Auto-Populated | Date of the physical count session. Defaulted to today for new counts. | For new counts: must comply with the back-dating policy for physical inventory documents. Not validated when loading an existing count. |
| Store (`STORES_CD`) | Yes | The store for which the physical inventory count is being performed. | Must not be blank. Must be a valid store for the current dealer. |
| Part Entry Mode (`ENTRY_MODE`) | Yes | Controls whether part detail rows are auto-populated by the system or entered manually. | Must not be blank. Governs whether header filter fields are enabled. |
| Category (`CATG_CD`) | No | Filter to restrict the count to parts of a specific category. | Optional. Applied as a filter during population. |
| ABC Indicator (`ABC_IND`) | No | Filter to restrict the count to parts with a specific ABC classification. | Optional. Applied as a filter during population. |
| FMS Indicator (`FSN_IND`) | No | Filter to restrict the count to parts with a specific FMS classification. | Optional. Applied as a filter during population. |
| XYZ (`XYZ_IND`) | No | Filter to restrict the count to parts with a specific XYZ classification. | Optional; format 99,99,999.000. |
| Margin Category (`MCAT_CD`) | No | Filter to restrict the count to parts of a specific margin category. | Optional. Applied as a filter during population. |
| Price Type (`PRICE`) | Conditional | Type of price (purchase, local sell, outside sell, MRP, or landed cost) used for price-range filtering. | Required when a price boundary filter is entered. |
| Price From (`GREATER_THAN`) | No | Minimum price boundary for filtering parts by price value. | Must be ≥ 0 when entered; price type must be selected first. |
| Price To (`LESS_THAN`) | No | Maximum price boundary for filtering parts by price value. | Must be ≥ 0 and ≥ Price From when entered; price type must be selected first. |
| Stock Quantity Filter (`STOCK_QTY`) | No | Filter to include all parts, only positive-stock parts, or only zero/negative-stock parts in the count. | Optional. Governs which stock quantity subset is returned during population. |
| Bin Location Status (`ACTIVE_YN`) | No | Filter to restrict the count to bin locations by their active/inactive status. | Optional. Applied as a filter during population. |
| Part Number From (`PART_NUMBER`) | Conditional | Starting part number for a part-range filter. | Must exist in parts master for principal account when entered. Required as a pair with Part Number To if either end is entered. |
| Part Number To (`TO_PART_NUM`) | Conditional | Ending part number for the part-range filter. | Required when Part Number From is entered; cannot be entered alone. Must exist in parts master for principal account. |
| Bin Location Area From (`BIN_LOC_CD_11`) | No | First two-character segment (Area) of the bin location "from" range. | Paired with Area To; if entered, Area To is required. |
| Bin Location Row From (`BIN_LOC_CD_12`) | No | Second two-character segment (Row) of the bin location "from" range. | Paired with Row To. |
| Bin Location Rack From (`BIN_LOC_CD_13`) | No | Third two-character segment (Rack) of the bin location "from" range. | Paired with Rack To. |
| Bin Location Shelf From (`BIN_LOC_CD_14`) | No | Fourth two-character segment (Shelf) of the bin location "from" range. | Paired with Shelf To. |
| Bin Location Bin From (`BIN_LOC_CD_15`) | No | Fifth two-character segment (Bin) of the bin location "from" range. | Paired with Bin To. |
| Bin Location Area To (`BIN_LOC_CD_21`) | Conditional | First segment of the bin location "to" range. | Required when Area From is entered; cannot be entered alone. |
| Bin Location Row To (`BIN_LOC_CD_22`) | Conditional | Second segment of the bin location "to" range. | Required when Row From is entered; cannot be entered alone. |
| Bin Location Rack To (`BIN_LOC_CD_23`) | Conditional | Third segment of the bin location "to" range. | Required when Rack From is entered; cannot be entered alone. |
| Bin Location Shelf To (`BIN_LOC_CD_24`) | Conditional | Fourth segment of the bin location "to" range. | Required when Shelf From is entered; cannot be entered alone. |
| Bin Location Bin To (`BIN_LOC_CD_25`) | Conditional | Fifth segment of the bin location "to" range. | Required when Bin From is entered; cannot be entered alone. |
| Bin Location Order (`BIN_ORDER`) | No | Controls the terminology used for the bin location segment labels on screen. | Optional. Governs display labels only. |
| Order By (`ORDER_BY`) | No | Sort order for the populated part list (by part number or bin location). | Optional. Governs the sequence of the count grid. |
| Stock Adjustment On (`STKADJ_ON`) | No | Determines whether the difference quantity is calculated against the stock at generation or the current stock quantity. | Optional. Defaults to current stock. |

#### Part Detail Count Lines (Stock Controller - per part during counting)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Part Number (`PART_NUM`) | Yes (manual mode) | Part number being counted. Auto-populated by the system in automatic mode; user-entered in manual mode. | In manual mode: must not be blank; must exist in parts master for principal account; landed cost must be > 0. |
| Store Bin Location (`BIN_LOC`) | Conditional | Bin location where the part is stored. Auto-populated or user-entered depending on mode and bin-location management setting. | When bin management enabled and entered by user: must not be "NO BIN" as a new name; must exist in stock records or LOV shown. |
| Physical Bin Location (`PHY_BIN_LOC`) | Conditional | Physical location where the surplus stock was found. Required for rows with a positive difference when bin management is enabled. | Must not be blank when required; "NO BIN" cannot be a new user-defined name; new location may be created when difference is positive. |
| Physical Quantity (`PHYSICAL_QTY`) | Yes | The quantity of the part actually counted during the physical stock take. | Must be ≥ 0; decimal compliance enforced per part's setting; triggers all downstream calculations. |
| Physical Count Date (`PHY_COUNT_DATE`) | Conditional | Date on which the physical count for this part was performed. | Required when physical quantity is entered; must not be in the future; must not be earlier than the count document date. |
| Tax Type (`TAX_TYPE`) | Conditional | Tax type applicable to the stock increase for this part. | Required when difference quantity is positive and tax flag is enabled. Cleared automatically for decreases or null quantities. |
| Remarks (`REMARKS`) | No | Free-text note about the physical count observation for this part. | Optional. Up to 100 characters. |

#### Session and Control Parameters (System - set at form open and reset)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Bin Flag (`P_BIN_FLAG`) | Auto-Populated | Controls whether bin-location fields and validations are active for the current dealer session. | System-retrieved from dealer configuration; governs field availability throughout the form. |
| Tax Flag (`P_TAX_FLAG`) | Auto-Populated | Controls whether tax type is required for positive stock adjustments in this session. | System-set; governs tax type mandatory validation. |
| Records Populated Flag (`P_REC_POP`) | Auto-Populated | Indicates whether the count grid has already been populated in this session, preventing re-population. | System-set on successful populate; prevents duplicate population. |
| Commit Form Flag (`P_COMMIT_FORM`) | Auto-Populated | Controls whether the save shortcut key is active (inactive in current implementation). | System-set; no active effect in current form. |
| Inventory Number Parameter (`INV_NUM`) | Auto-Populated | Count document number passed to the form, used as a report parameter. | System-set from count document. |

### 6.3 Reference Data

*Lists the master and configuration data referenced by the Physical Inventory form.*

| Reference Data | Business Purpose | Used When |
| :--- | :--- | :--- |
| Physical Inventory Count List (RG_INV_NO / LV_INV_NO - PH_INVENTORY) | Provides a pick-list of existing physical inventory count document numbers and dates for the current dealer, location, and financial area, ordered most recent first. | When the user is selecting an existing count to load. |
| Bin Location with Stock (RG_BIN_LOC / LV_BIN_LOC - PM_STOCK_BIN_LOC) | Lists all bin locations in the current store for the part, including stock, float, and allocated quantities. | When the user is selecting or validating a part's bin location. |
| All Bin Locations (RG_BIN_LOC_ALL / LV_BIN_LOC_ALL - PM_STOCK_BIN_LOC) | Lists all bin locations in the current store without stock filtering. | When the user is selecting a physical bin location for a surplus part. |
| Employee Signatories (RG_EMP / LV_EMP - GM_EMP) | Lists employees who are designated as signatories (signatory flag = Y, category = P, current) for the current dealer. | When the user is selecting the stock-taken-by person on the adjustment panel. |
| Bin Location From (RG_FROM_BIN_LOC_CD / LOV_FROM_BIN_LOC_CD - PM_STOCK_BIN_LOC) | Lists bin locations available as the starting point for a bin location range filter. | When the user is selecting the bin location range start on the header filter. |
| Bin Location To (RG_TO_BIN_LOC_CD / LOV_TO_BIN_LOC_CD - PM_STOCK_BIN_LOC) | Lists active bin locations for the part in the current store (excluding the current bin location) as options for the physical bin location "to" range. | When the user is selecting the ending bin location for a range, or selecting a physical bin location for a surplus row. |
| Parts Master (PM_PART) | Provides part descriptions, category, ABC/FMS/XYZ classifications, margin category, allow-decimal flag, and principal mapping for part validation and description display. | When validating part numbers entered manually, or when retrieving part details during population. |
| Part Variant Master (PM_PART_VAR) | Provides price values (purchase, local sell, outside sell, MRP, landed cost), ABC/FMS/XYZ indicators, and other variant-level attributes for each part and dealer. | When filtering parts by price range, retrieving landed cost for adjustment calculations, or populating part details. |
| Stock Bin Location (PM_STOCK_BIN_LOC) | Provides stock quantities (local sell, outside sell, allocated, float, reserved) per part and bin location for the current dealer and store. | When loading current stock quantities during count detail population and validation. |
| Dealer Location Parameters (AM_DEALER_LOC_PARAM) | Provides the default tax type and bin-location management flag for the current dealer and location. | When defaulting the tax type on a new count row, and when retrieving the bin-location control flag at form initialisation. |
| Catalogue List (AM_LIST) | Provides list item codes and descriptions for drop-down fields populated from the catalogue. | When populating list items on the header filter fields. |
| Store Master (GM_STORE) | Provides store codes and descriptions for the current dealer. | When populating the store selection list and when retrieving the store name for bin-location messages. |

### 6.4 Data Lifecycle

*Describes how physical inventory count records and stock adjustment records are created, updated, and saved through the form's evidenced behaviour.*

**Creation**

- A new physical inventory count header record (PH_INVENTORY) is created when the user populates the count grid for the first time in a new session and saves the transaction. System fields (dealer, location, financial area, parent group, count date, created-by, created-date, stock-taken-by, and composite bin-location codes) are populated automatically by the system immediately before the record is written to the database (PRE-INSERT trigger).
- New part detail count rows (PD_INVENTORY) are created as the user enters physical quantities and saves. System fields (count document number, dealer, location, financial area, parent group, store, created-by, created-date, counted-date) are auto-populated before each row is written (PRE-INSERT trigger).
- When an adjustment is generated, a stock adjustment header (PH_STKADJ) and one stock adjustment detail line (PD_STKADJ) per part with a non-zero difference are created within the same committed transaction. The adjustment document number is generated by the sequential number generation routine before the header is inserted.

**Updates**

- Existing count header records (PH_INVENTORY) may be modified before an adjustment is generated. The modified-by user and modification timestamp are updated automatically when the record is saved (PRE-UPDATE trigger).
- Existing count detail rows (PD_INVENTORY) may be updated with revised physical quantities and bin locations before an adjustment is generated. The modified-by, modification timestamp, and adjustment number reference are updated automatically on save (PRE-UPDATE trigger).
- Once an adjustment is generated and the save trigger fires, the stock-taken-by field on the header is set from the adjustment panel, and subsequent form access to the loaded count shows action buttons as disabled, preventing re-adjustment.

**Save and Commit**

- The adjustment generation process (OK button on the adjustment panel) triggers a save via `EXECUTE_TRIGGER('FT_SAVE')` after all adjustment header and detail lines have been inserted. This commits the entire count and adjustment transaction in one operation.
- The form does not use the standard save shortcut key (it is inactive); saves are triggered through the adjustment process only.

**Retention and Audit**

- Every count header and detail row carries created-by, created-date, modified-by, and modified-date fields populated automatically by the form triggers, providing a full modification audit trail.
- Each part detail row also carries a counted-date that is updated whenever the physical quantity is changed, recording when the count for that specific part was last performed.
- No archival or purge logic is implemented in the form; retention is governed by database-level policy outside the scope of this document.

---

### 6.5 Excel Output Columns

This form does not use Excel download. No Excel export columns were identified in the form sources.

## 7. Glossary

*Definitions of terms, abbreviations, and acronyms used throughout this document.*

The following table defines key terms, acronyms, and abbreviations used throughout this Business Requirements Document.

| Term | Definition | Aliases | Related Terms |
| :--- | :--- | :--- | :--- |
| ABC Classification | Part classification scheme grouping parts into A (high-value), B (medium-value), and C (low-value) categories based on consumption and cost | ABC Indicator | FSN Classification, XYZ Classification |
| Adjustment Document | A stock correction record generated from a physical inventory to reconcile differences between counted and system stock quantities | Stock Adjustment | Physical Inventory, PH_STKADJ, PD_STKADJ |
| Allocated Quantity | The quantity of a part currently reserved or committed against open orders, not available for free use | ALLOC_QTY | Stock Quantity, Bin Location |
| AM_DOCS | Document master table that holds sequential document number counters and last document dates per dealer, location, and document type | Document Master | Generate_Next_Num, Back-Date Validation |
| Auto Mode | Entry mode in which the system automatically populates the count list with parts from system stock using the specified filter criteria | Entry Mode A | Manual Mode, BT_FETCH |
| Back-Date Validation | A business rule preventing users from recording a transaction date earlier than the last recorded document date for the same context | Date Validation | get_last_doc_date, INV_DATE |
| Bin Location | A physical storage slot or rack identifier within a store, used to locate and manage part stock at a granular level | BIN_LOC | Store, Stock Quantity, PM_STOCK_BIN_LOC |
| BRD | Business Requirements Document - the document in which this glossary appears | Business Requirements Document | - |
| BT_FETCH | The Fetch/Populate button on the physical inventory header that triggers population of the part count lines | Fetch Button | Auto Mode, PD_INVENTORY |
| CN_ADJ | The stock adjustment confirmation canvas (stacked panel) displayed when generating a stock adjustment; captures stock-taken-by and reason | Adjustment Dialog | Stock Taken By, Reason Code |
| CN_AUTH | The authorised signatory canvas (stacked panel) used to record the employee who authorises the inventory count | Auth Canvas | Authorised Signatory, B_EMP |
| Company / FA | Company and financial-accounts code; identifies the business entity and accounts dimension for all transactions in the session | COMP_FA | Dealer, Location |
| Counted Date | The date and time when a specific part was physically counted; must fall between the inventory date and today | PHY_COUNT_DATE | Physical Quantity, INV_DATE |
| Dealer | The dealership entity identified by a numeric dealer map code; the primary session context for all inventory transactions | DEALER_MAP_CD | Location, Company |
| Diff Quantity | The calculated difference between the physical count quantity and the system (or current) stock quantity for a given part and bin | DIFF_QTY | Physical Quantity, Stock Quantity |
| DMS | Dealer Management System - the integrated software platform for dealership operations within which pt_phy operates | Dealer Management System | pt_phy |
| DPL | The shared PL/SQL program library (DPL.pld) providing common utility routines such as DISP_TEXT, CHECK_NULL, RUN_REPORT, and alert-display functions | DPL Library | PLD |
| Entry Mode | The method used to populate the count list: 'A' for auto-populate from system stock, 'M' for manual part entry | ENTRY_MODE | Auto Mode, Manual Mode |
| Financial Year | The fiscal year period used to scope document numbering and back-date validation | FIN_YR, P_FIN_YR | Document Numbering |
| FSN Classification | Part classification scheme grouping parts as Fast-moving (F), Slow-moving (S), or Non-moving (N) | FSN Indicator | ABC Classification, XYZ Classification |
| Inventory Date | The date of the physical count session recorded on the inventory header; validated against back-date rules | INV_DATE, DOC_DATE | Back-Date Validation, Counted Date |
| Landed Cost | The total cost of a part including purchase price and import/freight costs; stored per part variant and displayed on count lines | - | Part Variant, PM_PART_VAR |
| Location | The dealership branch or branch code used to scope all inventory records and queries | LOC_CD | Dealer, Company |
| LOV | List of Values - a popup selection list presented to the user within Oracle Forms to choose valid values for a field | Dropdown, Lookup List | Record Group |
| Manual Mode | Entry mode in which the user enters individual part numbers directly on count lines | Entry Mode M | Auto Mode, Part Number |
| Margin Category | Part classification code (MCAT_CD) used as an additional filter criterion during auto-population of count lines | MCAT_CD | ABC Classification |
| Part Number | The unique identifier for a stock-keeping part in the parts master | PART_NUM, PART_NUMBER | Parts Master, Bin Location |
| Parts Master | The database table (PM_PART) storing part number, description, and classification details for all stocked parts | PM_PART | Part Variant, Stock |
| PCK | A PL/SQL database package source file (.pck) containing one or more procedure or function routines called from the Oracle Form | Package | PK_VALIDATE_BACK_DATE |
| PD_INVENTORY | The physical inventory detail table and corresponding Oracle Forms data block; stores individual part count lines per inventory session | Physical Inventory Detail | PH_INVENTORY |
| PH_INVENTORY | The physical inventory header table and corresponding Oracle Forms data block; stores one record per count session with document number, date, store, and criteria | Physical Inventory Header | PD_INVENTORY |
| Physical Quantity | The quantity of a part actually counted and recorded by the user during the physical stock count | PHYSICAL_QTY | Diff Quantity, Stock Quantity |
| PK_VALIDATE_BACK_DATE | The database package providing back-date validation (get_last_doc_date) and sequential document numbering (Generate_Next_Num) for physical inventory transactions | Back-Date Package | Back-Date Validation, Document Numbering |
| PLD | A shared PL/SQL program library file (.pld) attached to the Oracle Form; provides reusable routines shared across multiple forms | Program Library | DPL, WEBUTIL |
| Principal | The manufacturer or brand entity (principal map code) used to scope parts and stock queries to specific product lines | PRINCIPAL | Dealer, Parts Master |
| pt_phy | The Oracle Forms module identifier for the Physical Inventory screen | PT_PHY | Physical Inventory, DMS |
| Record Group | A named data set within Oracle Forms used to populate List of Values (LOV) popup lists with query results | RG_ | LOV |
| Report Server | The Oracle Reports server infrastructure used to generate and deliver inventory and adjustment reports in PDF or printer format | Oracle Reports | RUN_REPORT, PROC_REPORT_CALL |
| Stock Adjustment | The corrective transaction document (PH_STKADJ header, PD_STKADJ detail) created when physical count quantities differ from system stock | Adjustment, Stock Correction | Diff Quantity, Adjustment Document |
| Stock Quantity | The system-recorded quantity of a part currently in stock at a given location and bin; used as the baseline for difference calculation | STOCK_QTY | Physical Quantity, Diff Quantity |
| Store | A warehouse or storage location within a dealership, identified by a store code (STORES_CD) | Warehouse, STORES_CD | Bin Location, Location |
| Tax Type | The applicable tax classification code required on count lines with a quantity discrepancy; affects how the stock adjustment is taxed | TAX_TYPE | Adjustment Document |
| WEBUTIL | The Oracle Forms WebUtil library (webutil.pld) providing client-side file-system and Java bean interop utilities | webutil.pld | PLD |
| XYZ Classification | Part classification scheme grouping parts by inventory value: X (high value), Y (medium value), Z (low value) | XYZ Indicator | ABC Classification, FSN Classification |

---

---

## 8. Technical Inventory

*Complete inventory of Oracle Forms components including blocks, items, triggers, canvases, and global variables.*

### 8.1 Form Architecture

**Form Module Details:**

- Form Name: pt_phy (PT_PHY)
- Form Module XML Title: MODULE2
- Oracle Forms Version: 12c (Module version 122010400)
- Parent Object Library: DPL.olb (PC_FORM property class)
- Attached Libraries: WEBUTIL (webutil.olb), DPL (DPL.pld program library), D2KWUTIL
- First Navigation Block: -
- Console Window: WN_MAIN (inherited via DPL object group)
- Compile Dependencies: Requires DPL.olb, DPL.pld, WEBUTIL.olb, database packages PK_VALIDATE_BACK_DATE
- Source artifacts: `pt_phy_fmb.xml`; OLB `DPL.olb`; WEBUTIL (webutil.olb); DPL (DPL.pld program library); D2KWUTIL; PCK `PK_PART_SEARCH_NEW.pck`; PCK `PK_VALIDATE_BACK_DATE.pck`

### 8.1.1 Global Variables

| Global Variable | Data Type | Set Location | Purpose |
| :--- | :--- | :--- | :--- |
| ADJ_CLICK | Char | Trigger | Stock-adjustment click flag ('Y'/'N'); reset to 'N' on form clear |
| COMP_FA | Char | ProgramUnit / RecordGroup / Trigger | Company/financial-accounts code; stamped on every DML record and used in all block WHERE clauses |
| CURRENCY | Char | Trigger | Currency code passed in from calling context; available for display and reporting |
| DEALER | Char | ProgramUnit / RecordGroup / Trigger | Dealer map code; primary context key for all block queries and DB operations |
| GEN_CLICK | Char | Trigger | Generate-button state flag ('Y'/'N'); reset to 'N' on form clear |
| LOC_CD | Char | ProgramUnit / RecordGroup / Trigger | Location code; context filter used in all block WHERE clauses |
| LV_REC_COUNT | Char | Trigger | Count of existing header records for the entered document number; drives re-query vs. new-entry mode |
| PARENT_GROUP | Char | RecordGroup / Trigger | Parent organisation/group code; used in all block WHERE clauses |
| PART_DESC | Char | Trigger | Part description retrieved during part-number validation; used for display in detail lines |
| PART_NUM | Char | Trigger | Part number context variable; set during part lookup and passed between triggers |
| PRINCIPAL | Char | ProgramUnit / Trigger | Principal map code; used for multi-company part and stock filtering |
| PRINTOUTPUT | Char | ProgramUnit / Trigger | Spool filename returned by report call; used to open the report in the browser |
| P_FIN_YR | Char | Trigger | Financial year; passed to back-date validation and document numbering |
| P_TYPE | Char | ProgramUnit / Trigger | Print-with-stock flag ('Y'/'N'); set during report call and passed to report parameters |
| REPORTHANDLE | Char | ProgramUnit / Trigger | Report job handle returned by run-report; polled to check completion status |
| REPORT_SERVER | Char | ProgramUnit | Oracle Reports server name (alternative variable; not used in active code in this form) |
| REP_SERVER | Char | ProgramUnit | Oracle Reports server name used by inventory and physical report calls |
| STK_ADJ | Char | Trigger | Stock-adjustment state flag ('N' default); reset to 'N' on form clear |
| USERID | Char | Trigger | Oracle database user ID of the current session; used for session context stamping and audit purposes |
| USER_NAME | Char | ProgramUnit / Trigger | Logged-in Oracle Forms username; stamped as CREATED_BY on insert and as ADJUSTED_BY |

### 8.1.2 Form Parameters

*All 14 ModuleParameter entries from pt_phy_fmb.xml.*

| Parameter | Data Type | Default | Description |
| :--- | :--- | :--- | :--- |
| P_COMMIT_FORM | Char | N | Guards whether save/commit is permitted; when 'Y', enables commit; KEY-COMMIT logic is currently inactive |
| P_PART_FOUND | Char | N | Indicates whether matching parts were located during detail-line population |
| P_TAX_FLAG | Char | Y | Controls tax applicability; reset to 'Y' on KEY-CLRFRM; referenced in detail-line processing |
| P_BIN_FLAG | Char | N | Indicates whether bin-location tracking is enabled for this dealer/location; read from SF_GET_BIN_FLAG on form clear |
| P_REC_POP | Char | N | Tracks whether PD_INVENTORY detail lines have been populated; prevents re-population on BT_FETCH |
| INV_NUM | Char | - | Physical inventory document number passed in from the calling form for query mode |
| P_REP_ID | Char | PT_PHY | Report ID passed to the report engine; defaults to 'PT_PHY' |
| AD_YN | Char | N | Adjustment yes/no flag passed from the calling context |
| P | Char | NEW | Generic state parameter; 'NEW' indicates new-entry mode vs. existing-record mode |
| P_CONSG_CD | Char | - | Consignment code passed from the calling context; reserved for multi-consignment scenarios |
| P_MONTH_ADJUST | Number | - | Month adjustment value passed from the calling context; Number type |
| P_SAN_LIMIT_AMT | Number | - | Sanctioned limit amount passed from the calling context; Number type |
| P_SAN_LIMIT_DEFINED | Number | - | Flag (Number) indicating whether a sanction limit has been defined in the calling context |
| P_DEALER_CATEGORY | Char | - | Dealer category code passed from the calling context |

**Total Parameters:** 14

### 8.2 Blocks

| Block Name | Query Data Source | Records | Q/I/U/D | Key Mode | Master-Detail Relationship |
| :--- | :--- | :--- | :--- | :--- | :--- |
| B_DUMMY | - | 1 | Y/N/N/N | Default | Control - entry point for the physical inventory document number |
| PH_INVENTORY | PH_INVENTORY | 1 | Y/Y/Y/N | Delayed | Detail of B_DUMMY via NB_INV_NO (doc number context) |
| PD_INVENTORY | PD_INVENTORY | 10 | Y/Y/Y/N | Delayed | Detail of PH_INVENTORY via DOC_NUM / DEALER_MAP_CD / COMP_FA / LOC_CD |
| B_EMP | - | 1 | Y/N/N/N | Default | Control - display-only employee lookup for authorised signatory |
| B_ADJ | - | 1 | Y/N/N/N | Default | Control - captures stock-adjustment reason and signatory before generating adjustment |
| CB_SEARCH | - | 1 | Y/N/N/N | Default | Control - part-number search filter for detail-line navigation |

**Total Blocks:** 6 business blocks

### 8.2.1 Block WhereClause and OrderByClause

*Block query scope from pt_phy_fmb.xml. **Description** explains filter and sort in business terms; **Order By** and **Where Clause** columns retain verbatim XML text for migration.*

| Block | Description | Order By (XML) | Where Clause (XML) |
| :--- | :--- | :--- | :--- |
| PH_INVENTORY | Retrieves the physical inventory header record for the current session's dealer, company/FA, location, and parent group, scoped to the document number entered in the inventory number field | - | DEALER_MAP_CD = :GLOBAL.DEALER  AND COMP_FA = :GLOBAL.COMP_FA  AND LOC_CD = :GLOBAL.LOC_CD  AND DOC_NUM = :B_DUMMY.NB_INV_NO AND PARENT_GROUP = :GLOBAL.PARENT_GROUP |
| PD_INVENTORY | Retrieves all part-count detail lines belonging to the same dealer, company/FA, location, parent group, and document number as the current inventory header - the full list of parts to be physically counted in this session | - | DEALER_MAP_CD = :GLOBAL.DEALER  AND COMP_FA = :GLOBAL.COMP_FA  AND  LOC_CD = :GLOBAL.LOC_CD AND  DOC_NUM = :B_DUMMY.NB_INV_NO AND PARENT_GROUP =:GLOBAL.PARENT_GROUP |

### 8.3 Items Summary

*Complete item inventory from `pt_phy_fmb.xml`.*

**Block counts:**

*Database / non-database counts derived from XML.*

| Block | Total Items | Database Items | Non-Database Items |
| :--- | ---: | ---: | ---: |
| B_DUMMY | 2 | 0 | 2 |
| PH_INVENTORY | 46 | 29 | 17 |
| PD_INVENTORY | 38 | 1 | 37 |
| B_EMP | 2 | 0 | 2 |
| B_ADJ | 4 | 0 | 4 |
| CB_SEARCH | 2 | 0 | 2 |
| PB_BLK | 21 | 0 | 21 |
| CB_ERR | 1 | 0 | 1 |
| **Total** | **116** | **30** | **86** |

**Item detail (all 116 items):**

| Block | Item Name | DatabaseItem | Description |
| :--- | :--- | :--- | :--- |
| B_DUMMY | NB_INV_NO | false | Inventory document number entry field; drives query filters for both data blocks |
| B_DUMMY | COPY_RIGHT | false | Read-only copyright declaration text populated from the copyright function |
| PH_INVENTORY | PARENT_GROUP | true | Hidden parent organisation/group code; used as a query filter |
| PH_INVENTORY | STOCK_TAKEN_BY | true | Employee code of the person who performed the physical stock count |
| PH_INVENTORY | DEALER_MAP_CD | true | Hidden dealer code; stamped from session context on insert |
| PH_INVENTORY | COMP_FA | true | Hidden company/financial-accounts code; stamped from session context on insert |
| PH_INVENTORY | LOC_CD | true | Hidden location code; stamped from session context on insert |
| PH_INVENTORY | INV_NUM | true | Physical inventory document number (maps to DOC_NUM column) |
| PH_INVENTORY | CREATED_BY | true | Audit: username who created the inventory header record |
| PH_INVENTORY | CREATED_DATE | true | Audit: datetime the inventory header record was created |
| PH_INVENTORY | MODIFIED_BY | true | Audit: username who last modified the inventory header record |
| PH_INVENTORY | MODIFIED_DATE | true | Audit: datetime of the last modification to the header record |
| PH_INVENTORY | INV_DATE | true | Inventory/count date (maps to DOC_DATE); validated against back-date rules |
| PH_INVENTORY | STORES_CD | true | Mandatory store/warehouse code for the count session |
| PH_INVENTORY | ENTRY_MODE | true | List: 'A' = auto-populate parts from stock, 'M' = manual part entry |
| PH_INVENTORY | CATG_CD | true | List: part category filter for auto-population of detail lines |
| PH_INVENTORY | ABC_IND | true | List: ABC classification filter (A/B/C) for part selection |
| PH_INVENTORY | FSN_IND | true | List: FSN classification filter (F/S/N) for part selection |
| PH_INVENTORY | XYZ_IND | true | List: XYZ classification filter for part selection |
| PH_INVENTORY | MCAT_CD | true | List: margin-category filter for part selection |
| PH_INVENTORY | PRICE | true | List: price type for value-range filter (Purchase, Sell, MRP, Landed Cost) |
| PH_INVENTORY | GREATER_THAN | true | Lower bound of price range filter for part selection |
| PH_INVENTORY | LESS_THAN | true | Upper bound of price range filter for part selection (maps to HIGH_RANGE) |
| PH_INVENTORY | STOCK_QTY | true | List: stock filter - All, With Stock (>0), or Zero Stock |
| PH_INVENTORY | ACTIVE_YN | true | List: bin location status filter (Active/Inactive) |
| PH_INVENTORY | PART_NUMBER | true | From part number for range-based part selection filter |
| PH_INVENTORY | TO_PART_NUM | true | To part number for range-based part selection filter |
| PH_INVENTORY | BIN_LOC_FROM | true | Starting bin location code for range filter (maps to BIN_LOC_CD) |
| PH_INVENTORY | BIN_LOC_TO | true | Ending bin location code for range filter (maps to BIN_LOC_CD_TO) |
| PH_INVENTORY | BT_FETCH | false | Push button: triggers population of PD_INVENTORY detail lines |
| PH_INVENTORY | BIN_ORDER | false | List: sort order for detail lines (Part Number or Bin Location) |
| PH_INVENTORY | ORDER_BY | true | Stored sort-order value (1=Part Number, 2=Bin Location) |
| PH_INVENTORY | STKADJ_ON | true | List: basis for quantity difference - 'C'=current stock, 'S'=system stock |
| PH_INVENTORY | BIN_LOC_CD_11 | false | Segment 1 of the FROM bin location code (2-char component) |
| PH_INVENTORY | BIN_LOC_CD_12 | false | Segment 2 of the FROM bin location code (2-char component) |
| PH_INVENTORY | BIN_LOC_CD_13 | false | Segment 3 of the FROM bin location code (2-char component) |
| PH_INVENTORY | BIN_LOC_CD | false | Hidden concatenated FROM bin location code (10 chars; stored to DB column BIN_LOC_CD) |
| PH_INVENTORY | BIN_LOC_CD_14 | false | Segment 4 of the FROM bin location code (2-char component) |
| PH_INVENTORY | BIN_LOC_CD_15 | false | Segment 5 of the FROM bin location code (2-char component) |
| PH_INVENTORY | BIN_LOC_CD_21 | false | Segment 1 of the TO bin location code (2-char component) |
| PH_INVENTORY | BIN_LOC_CD_22 | false | Segment 2 of the TO bin location code (2-char component) |
| PH_INVENTORY | BIN_LOC_CD_23 | false | Segment 3 of the TO bin location code (2-char component) |
| PH_INVENTORY | BIN_LOC_CD_24 | false | Segment 4 of the TO bin location code (2-char component) |
| PH_INVENTORY | BIN_LOC_CD_25 | false | Segment 5 of the TO bin location code (2-char component) |
| PH_INVENTORY | BIN_LOC_CD_TO | false | Hidden concatenated TO bin location code (10 chars; stored to DB column BIN_LOC_CD_TO) |
| PH_INVENTORY | ADJ_NUM | false | Adjustment document number; if populated, indicates stock adjustment is already generated |
| PH_INVENTORY | RADIO_GROUP91 | false | Radio group for report/generate mode selection |
| PH_INVENTORY | CURRENT_STOCK_DATE | false | Reference date for current-stock snapshot; defaults to SYSDATE if null |
| PD_INVENTORY | NB_INC_YN | false | Include/exclude flag for this line in adjustment processing |
| PD_INVENTORY | ADJ_NUM | false | Adjustment document number reference for this detail line |
| PD_INVENTORY | LANDED_COST | false | Landed cost of the part; fetched from part master on validation |
| PD_INVENTORY | PARENT_GROUP | false | Hidden parent organisation/group code for this detail line |
| PD_INVENTORY | DEALER_MAP_CD | false | Hidden dealer code; stamped from session context on insert |
| PD_INVENTORY | COMP_FA | false | Hidden company/FA code; stamped from session context on insert |
| PD_INVENTORY | LOC_CD | false | Hidden location code; stamped from session context on insert |
| PD_INVENTORY | INV_NUM | false | Hidden inventory document number; stamped from session context on insert |
| PD_INVENTORY | STORES_CD | false | Store code for this part-count line (maps to STORES_CD column) |
| PD_INVENTORY | NB_LANDED_COST | false | Non-DB display of landed cost value |
| PD_INVENTORY | COUNTED_DATE | false | Date when this specific part was counted (maps to COUNTED_DATE column) |
| PD_INVENTORY | CREATED_BY | false | Audit: username who created this detail line |
| PD_INVENTORY | CREATED_DATE | false | Audit: datetime this detail line was created |
| PD_INVENTORY | MODIFIED_BY | false | Audit: username who last modified this detail line |
| PD_INVENTORY | MODIFIED_DATE | false | Audit: datetime of the last modification to this detail line |
| PD_INVENTORY | SRL_NUM | false | Serial/line number; auto-set from cursor record position on populate |
| PD_INVENTORY | PART_NUM | false | Part number; read-only in auto mode, user-entered in manual mode |
| PD_INVENTORY | BIN_LOC | false | System bin location of the part; read-only in auto mode |
| PD_INVENTORY | ALLOW_DECIMAL_QTY | false | Flag indicating whether decimal physical quantities are permitted for this part |
| PD_INVENTORY | PHYSICAL_QTY | false | User-entered physical count quantity for this part line |
| PD_INVENTORY | PHY_COUNT_DATE | true | Date/time the physical count was performed; mandatory when PHYSICAL_QTY is entered |
| PD_INVENTORY | PHY_BIN_LOC | false | Physical bin location entered by user; editable when difference exists and bin tracking is enabled |
| PD_INVENTORY | TAX_TYPE | false | List: tax type for the stock adjustment line; mandatory when quantity difference exists |
| PD_INVENTORY | REMARKS | false | Free-text remarks for this count line |
| PD_INVENTORY | STOCK_QTY | false | System stock quantity at the time of inventory generation |
| PD_INVENTORY | DIFF_QTY | false | Calculated difference: physical count minus system/current stock |
| PD_INVENTORY | CHECK_BIN | false | Checkbox: bin transfer indicator for this line |
| PD_INVENTORY | NB_BIN_LOC | false | Non-DB display of all bin locations for this part |
| PD_INVENTORY | NB_PART_DESC | false | Non-DB display of part description; populated during auto-population |
| PD_INVENTORY | PB_REM | false | Button/popup for entering multi-line remarks |
| PD_INVENTORY | NB_BIN_LOC_CD1 | false | Display of primary bin location code for this line |
| PD_INVENTORY | CURRENT_STOCK | false | Total system stock at the time of count (maps to CURRENT_STOCK column) |
| PD_INVENTORY | ALLOC_QTY | false | Currently allocated quantity for this part (maps to ALLOC_QTY column) |
| PD_INVENTORY | BIN_LOC1 | false | Display-only alternate bin location field |
| PD_INVENTORY | NB_PART_DESC1 | false | Editable part description field for manual entry mode |
| PD_INVENTORY | ENTRY_MODE | false | Hidden entry mode indicator for this line ('A'=auto, 'M'=manual) |
| PD_INVENTORY | NB_CURRENT_STOCK | false | Non-DB display of current stock at the specific bin location |
| PD_INVENTORY | NB_FLOAT_STOCK | false | Non-DB display of float/in-transit stock quantity |
| B_EMP | NB_AUTH_EMP | false | Authorised signatory employee code input field |
| B_EMP | NB_EMP_NAME | false | Display of authorised signatory employee name |
| B_ADJ | STOCK_TAKEN_BY | false | Employee code of the person who performed the physical stock count (validated before adjustment) |
| B_ADJ | REASON | false | Reason code selected for the stock adjustment (mandatory for adjustment generation) |
| B_ADJ | ADJUSTED_BY | false | Username of the person performing the adjustment; populated from session username |
| B_ADJ | OK | false | Confirm/OK button to proceed with stock adjustment document generation |
| CB_SEARCH | PART_NUM1 | false | Part number input for quick-search within physical count detail lines |
| CB_SEARCH | SEARCH | false | Button to execute the part-number search filter on detail lines |
| PB_BLK | PB_EXIT | false | Inherited toolbar button: exits the form (inherited from DPL object group) |
| PB_BLK | PB_LIST | false | Inherited toolbar button: shows list of values for the current item (inherited) |
| PB_BLK | PB_INSERT | false | Inherited toolbar button: inserts a new record in the current block (inherited) |
| PB_BLK | PM_CONT | false | Inherited toolbar button: continues or resumes the current operation (inherited) |
| PB_BLK | PB_DEL | false | Inherited toolbar button: deletes the current record (inherited) |
| PB_BLK | PB_CANCEL | false | Inherited toolbar button: cancels the current operation without saving (inherited) |
| PB_BLK | PB_SAVE | false | Inherited toolbar button: saves/commits the current form data (inherited) |
| PB_BLK | PB_PRINT | false | Inherited toolbar button: launches the print/report action for the current form (inherited) |
| PB_BLK | PB_CUT | false | Inherited toolbar button: cuts the current field value to clipboard (inherited) |
| PB_BLK | PB_COPY | false | Inherited toolbar button: copies the current field value to clipboard (inherited) |
| PB_BLK | PB_PASTE | false | Inherited toolbar button: pastes clipboard content into the current field (inherited) |
| PB_BLK | PB_ERR_EXIT | false | Inherited toolbar button: exits the error display canvas (inherited) |
| PB_BLK | PB_ADJUST | false | Inherited toolbar button: initiates the stock adjustment workflow (inherited) |
| PB_BLK | PB_OK | false | Inherited toolbar button: confirms the current dialog or operation (inherited) |
| PB_BLK | PB_CANCEL1 | false | Inherited toolbar button: secondary cancel button for dialog dismissal (inherited) |
| PB_BLK | PB_QRY | false | Inherited toolbar button: executes a query on the current block (inherited; currently inactive/commented out) |
| PB_BLK | GEN_ADJ | false | Inherited toolbar button: generates the stock adjustment document (inherited) |
| PB_BLK | BT_EXCEL | false | Inherited toolbar button: exports the current data to Excel (inherited) |
| PB_BLK | BT_REPORT | false | Inherited toolbar button: launches the report for the current form (inherited) |
| PB_BLK | PB_GEN | false | Inherited toolbar button: triggers the generate action for inventory processing (inherited) |
| PB_BLK | PB_EXP | false | Inherited toolbar button: exports data or expands the current view (inherited) |
| CB_ERR | TXT_ERR | false | Inherited error-display block text item; shows error messages on the CN_ERR error canvas (inherited from DPL object group) |

### 8.4 List of Values

| LOV Name | Title | Record Group | Attached Block.Item |
| :--- | :--- | :--- | :--- |
| LV_BIN_LOC | Store Bin Location(s) | RG_BIN_LOC | PD_INVENTORY.STOCK_QTY, PD_INVENTORY.ALLOC_QTY |
| LV_BIN_LOC_ALL | Store Bin Location(s) | RG_BIN_LOC_ALL | - |
| LV_EMP | Employee List | RG_EMP | B_EMP.NB_AUTH_EMP, B_EMP.NB_EMP_NAME |
| LV_INV_NO | Inventory No List | RG_INV_NO | - |
| LOV_FROM_BIN_LOC_CD | Store Bin Location(s) | RG_FROM_BIN_LOC_CD | PD_INVENTORY.BIN_LOC |
| LOV_TO_BIN_LOC_CD | Store Bin Location(s) | RG_TO_BIN_LOC_CD | PD_INVENTORY.PHY_BIN_LOC |

**Total LOVs:** 6

### 8.5 Alerts

| Alert Name | Title | Message Text | Calling Context |
| :--- | :--- | :--- | :--- |
| AL_REPORT | Physical Inventory | Do you want to? | ProgramUnit: CALL_REPORT_PR_INVENTORY, ProgramUnit: CALL_REPORT_PR_PHY |
| AL_PRINT | Print | (set at runtime) | Inherited from DPL object group; used by toolbar print button and report launch paths |
| AL_PRINT1 | - | Do you want to print with Stock? | ProgramUnit: CALL_REPORT_PR_INVENTORY (via ASK_CONFIRM) |
| AL_ERRINFO | Error | (set at runtime) | Inherited from DPL object group; displayed by GENERAL.DISP_TEXT for error-class messages via ON-ERROR and program units |
| AL_NOTE | Note | (set at runtime) | Inherited from DPL object group; displayed by GENERAL.DISP_TEXT for informational messages |
| AL_CONFIRM | Caution | (set at runtime) | Inherited from DPL object group; displayed by GENERAL.ASK_CONFIRM for user confirmation prompts |

**Total Alerts:** 6

### 8.6 Program Units

*Authoritative catalogue of **14 form-local program units**. Database packages and standalone procedures are in **Section 15.2**; PLD shared-library routines are in **Section 18**.*

| Program Unit | Type | Calls | Description |
| :--- | :--- | :--- | :--- |
| L_POP_LIST_ITEM | Procedure | FIND_GROUP, CREATE_GROUP_FROM_QUERY, POPULATE_GROUP, ID_NULL (WEBUTIL) | Creates a record group from a dynamic SQL query if it does not exist, then populates the corresponding list item |
| L_POPULATE | Procedure | FIND_GROUP, DELETE_GROUP, CREATE_GROUP_FROM_QUERY, POPULATE_GROUP, POPULATE_LIST, AM_LIST | Builds a list item from the AM_LIST application lookup table for the current principal; drops and recreates the group on each call |
| PRINT_REPORT | Inactive | GENERAL.ASK_PRINT, RUN_REPORT (DPL) | **COMMENTED OUT / INACTIVE** - was the original PT_PHY report launcher; logic superseded by PRINT_AS |
| PRINT_AS | Procedure | GENERAL.ASK_PRINT (DPL), RUN_REPORT (DPL) | Prompts for View or Print destination, then runs the PT_PHY report with full session context parameters |
| VALIDATE_HDR | Unknown | GENERAL.CHECK_NULL, SP_VALIDATE_INVENTORY_UPDATE | **COMMENTED OUT / INACTIVE** - was header validation that checked required fields and called SP_VALIDATE_INVENTORY_UPDATE; replaced by null |
| POPULATE_STORES | Procedure | FIND_GROUP, DELETE_GROUP, CREATE_GROUP_FROM_QUERY, POPULATE_GROUP, POPULATE_LIST, GM_STORE | Populates the stores list item from the GM_STORE table; currently uses hardcoded dealer/location values |
| CALL_REPORT_PR_INVENTORY | Procedure | FIND_REPORT_OBJECT, SHOW_ALERT (AL_REPORT), GENERAL.ASK_CONFIRM, SET_REPORT_OBJECT_PROPERTY, RUN_REPORT_OBJECT, WEB.SHOW_DOCUMENT, GENERAL.PROC_REPORT_CALL, GENERAL.PROC_TIMER | Launches the pr_inventory report with View (PDF to browser) or Print (to printer queue via timer polling) option |
| CALL_REPORT_PR_PHY | Procedure | FIND_REPORT_OBJECT, SHOW_ALERT (AL_REPORT), SET_REPORT_OBJECT_PROPERTY, RUN_REPORT_OBJECT, WEB.SHOW_DOCUMENT, GENERAL.PROC_REPORT_CALL, GENERAL.PROC_TIMER | Launches the pr_phy_pdf physical inventory report with the same View/Print destination pattern |
| CALC_DIFF_QTY | Procedure | SET_ITEM_INSTANCE_PROPERTY | Computes DIFF_QTY as PHYSICAL_QTY minus current or system stock (based on STKADJ_ON); enables PHY_BIN_LOC editing and marks TAX_TYPE mandatory when a difference exists |
| ENABLE_HEADER | Procedure | SET_ITEM_PROPERTY | Enables or disables all PH_INVENTORY filter fields based on a boolean flag (true=enabled for auto mode, false=disabled for manual mode) |
| CHK_DUP | Procedure | GO_ITEM, FIRST_RECORD, NEXT_RECORD, POPULATE_ERRORS.V_TAB | Scans all records in a block for duplicate composite key values; appends duplicate messages to the POPULATE_ERRORS error table |
| POPULATE_ERRORS | Package spec | PK_PLSQL_TABLE.CODE_TAB | Declares two PL/SQL table variables (VTAB, V_TAB) used as error-message collectors by CHK_DUP |
| ENABLE_POP_BTN | Procedure | SET_ITEM_PROPERTY | Enables the BT_FETCH populate button when both from/to part numbers or from/to bin locations are entered; disables it otherwise |
| STOCK_UPDATE_EXCEPTION | Procedure | GENERAL.DISP_TEXT (DPL) | Maps stock-update error codes (-20020 through -20072) to user-readable messages; raises FORM_TRIGGER_FAILURE after display |

**Total Program Units:** 14

### 8.7 Triggers

**Item-Level Trigger Types (reference):**

| Trigger Name | Purpose |
| :--- | :--- |
| WHEN-VALIDATE-ITEM | Validates field when user leaves item |
| KEY-* | Keyboard actions - commit, exit, LOV, navigation |
| WHEN-NEW-BLOCK-INSTANCE | Initializes block on entry |
| WHEN-BUTTON-PRESSED | Executes button action |
| PRE-INSERT / POST-INSERT | Before/after record creation |
| WHEN-LIST-CHANGED | Dropdown selection changed |
| PRE-QUERY / POST-QUERY | Before/after query execution |
| WHEN-CHECKBOX-CHANGED | Checkbox toggled |
| WHEN-VALIDATE-RECORD | Validates entire record before leaving row |

**DPL library routines invoked from triggers and program units:**

| Routine | Type | Called From | Purpose |
| :--- | :--- | :--- | :--- |
| GENERAL.ASK_CONFIRM | Library routine | Form level, PB_BLK.PB_EXIT (inherited), PB_BLK.PB_PRINT (inherited), ProgramUnit: CALL_REPORT_PR_INVENTORY | Displays a confirmation alert to the user; returns the button choice (OK/Cancel) to the caller |
| GENERAL.ASK_PRINT | Library routine | ProgramUnit: PRINT_AS, ProgramUnit: PRINT_REPORT | Displays the print-destination alert; returns 1=View/Screen, 2=Print/Printer, 3=Cancel |
| GENERAL.CHECK_NULL | Library routine | B_ADJ.OK, B_ADJ.REASON, B_ADJ.STOCK_TAKEN_BY, B_EMP.NB_AUTH_EMP, Form level, PB_BLK.GEN_ADJ (inherited), PD_INVENTORY.BIN_LOC, PD_INVENTORY.PART_NUM, PD_INVENTORY.PHYSICAL_QTY, PD_INVENTORY.PHY_BIN_LOC, PD_INVENTORY.PHY_COUNT_DATE, PD_INVENTORY.TAX_TYPE, PH_INVENTORY.BIN_LOC_CD_21, PH_INVENTORY.BIN_LOC_CD_22, PH_INVENTORY.BIN_LOC_CD_23, PH_INVENTORY.BIN_LOC_CD_24, PH_INVENTORY.BIN_LOC_CD_25, PH_INVENTORY.BIN_LOC_TO, PH_INVENTORY.ENTRY_MODE, PH_INVENTORY.STOCK_TAKEN_BY, PH_INVENTORY.STORES_CD, PH_INVENTORY.TO_PART_NUM, ProgramUnit: VALIDATE_HDR | Raises FORM_TRIGGER_FAILURE with 'Enter a valid {field}' message if the supplied value is null |
| GENERAL.DELETE_RECGRP_ROW | Library routine | Form level | Deletes a specific row from a named record group; used during error-table cleanup |
| GENERAL.DISP_TEXT | Library routine | B_ADJ.OK, B_ADJ.STOCK_TAKEN_BY, B_DUMMY.NB_INV_NO, B_EMP.NB_AUTH_EMP, CB_SEARCH.SEARCH, Form level, PB_BLK.GEN_ADJ (inherited), PB_BLK.PB_ADJUST (inherited), PB_BLK.PB_GEN (inherited), PB_BLK.PB_OK (inherited), PB_BLK.PB_SAVE (inherited), PD_INVENTORY, PD_INVENTORY.BIN_LOC, PD_INVENTORY.PART_NUM, PD_INVENTORY.PHYSICAL_QTY, PD_INVENTORY.PHY_BIN_LOC, PD_INVENTORY.PHY_COUNT_DATE, PH_INVENTORY.BIN_LOC_CD_21, PH_INVENTORY.BIN_LOC_CD_22, PH_INVENTORY.BIN_LOC_CD_23, PH_INVENTORY.BIN_LOC_CD_24, PH_INVENTORY.BIN_LOC_CD_25, PH_INVENTORY.BIN_LOC_TO, PH_INVENTORY.BT_FETCH, PH_INVENTORY.GREATER_THAN, PH_INVENTORY.INV_DATE, PH_INVENTORY.LESS_THAN, PH_INVENTORY.PART_NUMBER, PH_INVENTORY.STOCK_TAKEN_BY, PH_INVENTORY.TO_PART_NUM, ProgramUnit: CALL_REPORT_PR_PHY, ProgramUnit: PRINT_AS, ProgramUnit: PRINT_REPORT, ProgramUnit: STOCK_UPDATE_EXCEPTION | Displays a message via an alert (Error title -> AL_ERRINFO; other titles -> AL_NOTE); primary form-wide user notification mechanism |
| GENERAL.L_POP_LIST_ITEM | Library routine | Form level | Shared library variant of L_POP_LIST_ITEM; creates a record group from a dynamic SQL query and populates the target list item |
| GENERAL.PROC_REPORT_CALL | Library routine | ProgramUnit: CALL_REPORT_PR_INVENTORY, ProgramUnit: CALL_REPORT_PR_PHY | Configures a report object for BATCH/FILE execution to the printer spool path, runs it, and returns the job handle and spool filename |
| GENERAL.RAISE_ERROR | Library routine | B_EMP.NB_AUTH_EMP, Form level | Looks up the error code in the application message table; displays via DISP_TEXT; raises FORM_TRIGGER_FAILURE for Error-class messages |

### 8.7.1 Inactive / Commented-Out Trigger Register

*Triggers and field validations where XML source is `null;`, fully block-commented, or legacy code preserved but not executed. Do **not** migrate these as active business requirements.*

| Status | Block | Item | Trigger | Former behaviour (preserved in comments) | Disabled since / note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Commented out** | Form | - | ON-ERROR | Handled FRM-40209 and FRM-40207 by displaying error type, code, and text, and raising FORM_TRIGGER_FAILURE; an extended version also handled ORA-02292 FK violations, concurrent-update errors 40654-40659 with rollback, and generic SQLCODE≠0 cases; superseded by the current active version | Replaced by a third, more comprehensive error-handler version; legacy code preserved in block comments |
| **Commented out** | Form | - | KEY-COMMIT | Guarded save: if P_COMMIT_FORM='Y', performed ENTER + COMMIT_FORM, displayed the generated inventory number, asked about stock-print preference, called CALL_REPORT_PR_INVENTORY, then cleared the form | P_COMMIT_FORM feature not in use; commit trigger body replaced with null; superseded by active save logic |
| **Commented out** | Form | - | FT_DEL | Contained logic to delete the current record from the active block with confirmation; superseded by the inherited DPL toolbar delete behaviour | Replaced by inherited FT_DEL trigger from DPL object group |
| **Commented out** | Form | - | FT_PRINT | Contained inline report-launch logic for the physical inventory print action; superseded by CALL_REPORT_PR_PHY and CALL_REPORT_PR_INVENTORY program units | Replaced by dedicated report-launch program units; inherited FT_PRINT from DPL object group handles toolbar button |
| **Commented out** | Form | - | WHEN-TIMER-EXPIRED | Contained a full inline timer-polling loop that checked PRINTER_QUEUE timer status and REPORT_OBJECT_STATUS, then served the report URL via WEB.SHOW_DOCUMENT | Replaced by delegation to GENERAL.PROC_TIMER_EXPIRED (DPL library) |
| **Inactive stub** | B_DUMMY | NB_INV_NO | WHEN-VALIDATE-ITEM | Counted PH_INVENTORY rows for the entered document number and raised an error if none were found; also set INV_DATE=SYSDATE when NB_INV_NO was null | Body replaced with null; logic moved to KEY-NEXT-ITEM on NB_INV_NO |
| **Inactive stub** | B_DUMMY | NB_INV_NO | KEY-PREV-ITEM | Prevented backward navigation from the first field in the form | Body replaced with null; inherited DPL navigation key handles standard behaviour |
| **Inactive stub** | PH_INVENTORY | - | KEY-DOWN | Advanced cursor to the next record in the PH_INVENTORY block | Body replaced with null; inherited from DPL object group (KEY-DOWN) |
| **Inactive stub** | PH_INVENTORY | - | KEY-UP | Moved cursor to the previous record in the PH_INVENTORY block | Body replaced with null; inherited from DPL object group (KEY-UP) |
| **Commented out** | PH_INVENTORY | ENTRY_MODE | WHEN-LIST-CHANGED | Toggled the BIN_LOC visual attribute between VA_DISP (auto mode) and VA_MAND (manual mode) to indicate mandatory status | Superseded; bin-location mandatory state now controlled inline in WHEN-VALIDATE-ITEM on ENTRY_MODE |
| **Commented out** | PH_INVENTORY | GREATER_THAN | WHEN-VALIDATE-ITEM | Validated the lower price-range bound against the upper bound and raised an error if out of range | Commented out pending review; active validation not present |
| **Commented out** | PH_INVENTORY | LESS_THAN | WHEN-VALIDATE-ITEM | Validated the upper price-range bound against the lower bound | Commented out pending review; active validation not present |
| **Commented out** | PD_INVENTORY | - | WHEN-NEW-RECORD-INSTANCE | Controlled row-level display properties (item enable/disable, visual attributes) on navigation to a new record | Commented out; per-row state managed elsewhere |
| **Commented out** | PD_INVENTORY | PHYSICAL_QTY | POST-TEXT-ITEM | Triggered CALC_DIFF_QTY after the physical quantity field was exited, keeping DIFF_QTY in sync | Commented out; CALC_DIFF_QTY now called from WHEN-VALIDATE-ITEM on PHYSICAL_QTY |
| **Commented out** | B_EMP | NB_AUTH_EMP | WHEN-VALIDATE-ITEM | Validated the employee code against GM_EMP and displayed the employee name in NB_EMP_NAME | Commented out; validation logic not currently active |
| **Commented out** | PB_BLK | PB_QRY | WHEN-BUTTON-PRESSED | Executed a query on the current block when the query toolbar button was pressed | Commented out; inherited toolbar query behaviour not active in this form context |

*Additional null-only or partially commented triggers exist on estimation and legacy blocks - see XML `TriggerText` starting with `null;` or `/*`.*

**Complete trigger inventory (94 business triggers):**
*pt_phy_fmb.xml contains Trigger elements.*

| Trigger Name | Block | Item | Called From / Context | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| ON-ERROR | Form | - | Form level | Translates Oracle Forms and Oracle DB errors into user-friendly messages; handles date-format errors, numeric-field errors, concurrent-update conflicts, FK violations, and generic SQL errors |
| ON-MESSAGE | Form | - | Form level | Suppresses or reformats informational messages for field-format codes 40209 and 40207 |
| KEY-EXIT | Form | - | Form level | Clears the DBMS_APPLICATION_INFO module name then exits the form without validation |
| KEY-LISTVAL | Form | - | Form level | Shows bin-location LOV when bin tracking is enabled and entry mode is manual; calls CALC_DIFF_QTY after bin selection; shows standard item LOV otherwise |
| KEY-COMMIT | Form | - | Form level | **COMMENTED OUT / INACTIVE** - executes null; was a guarded save that committed the form and launched the inventory report |
| KEY-CLRFRM | Form | - | Form level | Clears the form; resets all session flags, restores default filter values, re-reads the bin-flag parameter, and re-enables all block fields |
| KEY-OTHERS | Form | - | Form level | Inherited form-level key handler; suppresses or delegates unrecognised key events (inherited from DPL object group) |
| KEY-NEXT-ITEM | Form | - | Form level | Inherited form-level next-item navigation handler (inherited from DPL object group) |
| KEY-PREV-ITEM | Form | - | Form level | Inherited form-level previous-item navigation handler (inherited from DPL object group) |
| KEY-NXTBLK | Form | - | Form level | Inherited form-level next-block navigation handler (inherited from DPL object group) |
| KEY-PRVBLK | Form | - | Form level | Inherited form-level previous-block navigation handler (inherited from DPL object group) |
| KEY-DOWN | Form | - | Form level | Inherited form-level down-navigation handler (inherited from DPL object group) |
| KEY-UP | Form | - | Form level | Inherited form-level up-navigation handler (inherited from DPL object group) |
| FT_SAVE | Form | - | Form level | Inherited toolbar save trigger; commits the current form data (inherited from DPL object group) |
| FT_CANCEL | Form | - | Form level | Inherited toolbar cancel trigger; rolls back uncommitted changes (inherited from DPL object group) |
| FT_INSERT | Form | - | Form level | Inherited toolbar insert trigger; inserts a new record in the current block (inherited from DPL object group) |
| FT_DEL | Form | - | Form level | **COMMENTED OUT / INACTIVE** - was: deleted the current record with confirmation; replaced by inherited DPL toolbar delete behaviour |
| FT_LIST | Form | - | Form level | Inherited toolbar list trigger; shows the LOV for the current item (inherited from DPL object group) |
| FT_PRINT | Form | - | Form level | **COMMENTED OUT / INACTIVE** - was: inline report-launch logic; replaced by CALL_REPORT_PR_PHY / CALL_REPORT_PR_INVENTORY program units |
| WHEN-NEW-FORM-INSTANCE | Form | - | Form level | Inherited form startup trigger; initialises session context globals, populates list items, and sets initial form state (inherited from DPL object group) |
| WHEN-TIMER-EXPIRED | Form | - | Form level | Delegates to PROC_TIMER_EXPIRED to poll the running report job status and open the browser on completion |
| PRE-FORM | Form | - | Form level | Registers the form module name in DBMS_APPLICATION_INFO for DBA session identification |
| WHEN-VALIDATE-ITEM | B_DUMMY | NB_INV_NO | B_DUMMY.NB_INV_NO | **INACTIVE (null)** - was: counted PH_INVENTORY rows for the entered document number and raised an error if none were found |
| KEY-PREV-ITEM | B_DUMMY | NB_INV_NO | B_DUMMY.NB_INV_NO | **INACTIVE (null)** - prevented backward navigation from the inventory number field |
| KEY-NEXT-ITEM | B_DUMMY | NB_INV_NO | B_DUMMY.NB_INV_NO | On tab-out: queries PH_INVENTORY to count matching records for the entered document number; sets LV_REC_COUNT; enables the export button; sets INV_DATE to SYSDATE if document number is null |
| WHEN-NEW-BLOCK-INSTANCE | PH_INVENTORY | - | PH_INVENTORY | In query mode (LV_REC_COUNT ≠ 0): executes the query on both header and detail blocks; enables or disables action buttons based on whether adjustment is already generated |
| PRE-INSERT | PH_INVENTORY | - | PH_INVENTORY | Stamps dealer, company/FA, location, created-by, created-date, parent-group, stock-taken-by, and inventory date (SYSDATE); assembles the FROM and TO bin location codes from segment fields |
| KEY-DOWN | PH_INVENTORY | - | PH_INVENTORY | **INACTIVE (null)** - advances cursor to next record (inherited from DPL object group) |
| PRE-UPDATE | PH_INVENTORY | - | PH_INVENTORY | Stamps modified-by and modified-date audit fields before updating the header record |
| KEY-UP | PH_INVENTORY | - | PH_INVENTORY | **INACTIVE (null)** - moves cursor to previous record (inherited from DPL object group) |
| POST-QUERY | PH_INVENTORY | - | PH_INVENTORY | Enables the print button after query; decomposes the 10-char bin location codes into five 2-char segment display fields; defaults STKADJ_ON to 'C' if null; disables action buttons if stock is already taken |
| WHEN-VALIDATE-ITEM | PH_INVENTORY | STOCK_TAKEN_BY | PH_INVENTORY.STOCK_TAKEN_BY | Calls CHECK_NULL on the adjustment-block stock-taken-by field when the adjustment click flag is active |
| WHEN-VALIDATE-ITEM | PH_INVENTORY | INV_DATE | PH_INVENTORY.INV_DATE | For new sessions: calls get_last_doc_date to prevent back-dating below the last recorded inventory date |
| WHEN-VALIDATE-ITEM | PH_INVENTORY | STORES_CD | PH_INVENTORY.STORES_CD | Validates that a store code has been selected (mandatory) |
| WHEN-VALIDATE-ITEM | PH_INVENTORY | ENTRY_MODE | PH_INVENTORY.ENTRY_MODE | Validates that an entry mode has been selected; sets mandatory/display properties on bin location fields based on the selected mode |
| KEY-NEXT-ITEM | PH_INVENTORY | ENTRY_MODE | PH_INVENTORY.ENTRY_MODE | If auto mode: enables header filter fields and navigates to part category; if manual mode: disables header filters and navigates directly to part number in the detail block |
| WHEN-LIST-CHANGED | PH_INVENTORY | ENTRY_MODE | PH_INVENTORY.ENTRY_MODE | **COMMENTED OUT / INACTIVE** - was: toggled BIN_LOC visual attribute between display and mandatory based on entry mode |
| WHEN-VALIDATE-ITEM | PH_INVENTORY | GREATER_THAN | PH_INVENTORY.GREATER_THAN | **COMMENTED OUT / INACTIVE** - was: validated the lower price-range bound against the upper bound |
| WHEN-VALIDATE-ITEM | PH_INVENTORY | LESS_THAN | PH_INVENTORY.LESS_THAN | **COMMENTED OUT / INACTIVE** - was: validated the upper price-range bound against the lower bound |
| WHEN-VALIDATE-ITEM | PH_INVENTORY | PART_NUMBER | PH_INVENTORY.PART_NUMBER | Validates the from part number and enables the populate button when both from/to values are present |
| WHEN-VALIDATE-ITEM | PH_INVENTORY | TO_PART_NUM | PH_INVENTORY.TO_PART_NUM | Validates the to part number and calls CHECK_NULL; enables BT_FETCH when both range endpoints are entered |
| WHEN-VALIDATE-ITEM | PH_INVENTORY | BIN_LOC_FROM | PH_INVENTORY.BIN_LOC_FROM | Validates the from bin location range input and calls ENABLE_POP_BTN |
| WHEN-VALIDATE-ITEM | PH_INVENTORY | BIN_LOC_TO | PH_INVENTORY.BIN_LOC_TO | Calls CHECK_NULL for the to bin location code and calls ENABLE_POP_BTN |
| KEY-NEXT-ITEM | PH_INVENTORY | BIN_LOC_TO | PH_INVENTORY.BIN_LOC_TO | Calls CHECK_NULL for bin location to, then navigates to the next item |
| WHEN-BUTTON-PRESSED | PH_INVENTORY | BT_FETCH | PH_INVENTORY.BT_FETCH | Validates mandatory header fields; if auto mode and first population, calls the stored procedure or inline cursors to populate PD_INVENTORY detail lines filtered by part/bin range and stock criteria; locks header insert/update after successful population |
| WBP | PH_INVENTORY | BT_FETCH | PH_INVENTORY.BT_FETCH | Alternative population trigger using inline cursors directly; same business logic as WHEN-BUTTON-PRESSED on BT_FETCH |
| WHEN-LIST-CHANGED | PH_INVENTORY | BIN_ORDER | PH_INVENTORY.BIN_ORDER | Updates the ORDER_BY value when the sort-order list selection changes |
| KEY-NEXT-ITEM | PH_INVENTORY | ORDER_BY | PH_INVENTORY.ORDER_BY | Navigates to the next item after the sort-order selection |
| WHEN-LIST-CHANGED | PH_INVENTORY | STKADJ_ON | PH_INVENTORY.STKADJ_ON | Updates DIFF_QTY for all detail lines when the stock-adjustment basis selection changes |
| WHEN-VALIDATE-ITEM | PH_INVENTORY | BIN_LOC_CD_21 | PH_INVENTORY.BIN_LOC_CD_21 | Validates the first segment of the TO bin location and calls CHECK_NULL |
| WHEN-VALIDATE-ITEM | PH_INVENTORY | BIN_LOC_CD_22 | PH_INVENTORY.BIN_LOC_CD_22 | Validates the second segment of the TO bin location and calls CHECK_NULL |
| WHEN-VALIDATE-ITEM | PH_INVENTORY | BIN_LOC_CD_23 | PH_INVENTORY.BIN_LOC_CD_23 | Validates the third segment of the TO bin location and calls CHECK_NULL |
| WHEN-VALIDATE-ITEM | PH_INVENTORY | BIN_LOC_CD_24 | PH_INVENTORY.BIN_LOC_CD_24 | Validates the fourth segment of the TO bin location and calls CHECK_NULL |
| WHEN-VALIDATE-ITEM | PH_INVENTORY | BIN_LOC_CD_25 | PH_INVENTORY.BIN_LOC_CD_25 | Validates the fifth segment of the TO bin location and calls CHECK_NULL |
| PRE-INSERT | PD_INVENTORY | - | PD_INVENTORY | Stamps context keys (dealer, company/FA, location, inventory number); sets serial line number from cursor record position; includes part/stock validation logic before inserting |
| POST-QUERY | PD_INVENTORY | - | PD_INVENTORY | After querying existing records: restores row-level display state, shows landed cost, calls CALC_DIFF_QTY to recompute difference, and displays part and bin location descriptions |
| WHEN-NEW-BLOCK-INSTANCE | PD_INVENTORY | - | PD_INVENTORY | Sets row-level display defaults and entry mode properties when the detail block is first entered |
| PRE-UPDATE | PD_INVENTORY | - | PD_INVENTORY | Stamps MODIFIED_BY and MODIFIED_DATE audit fields on update |
| WHEN-NEW-RECORD-INSTANCE | PD_INVENTORY | - | PD_INVENTORY | **COMMENTED OUT / INACTIVE** - was: controlled row-level item properties (enable/disable, visual attributes) on navigation to a new record |
| WHEN-VALIDATE-ITEM | PD_INVENTORY | PART_NUM | PD_INVENTORY.PART_NUM | For principal=1: validates the part number exists in the part master; in manual mode: fetches part description, landed cost, and decimal quantity flag; raises an error if the part is not found |
| WHEN-VALIDATE-ITEM | PD_INVENTORY | BIN_LOC | PD_INVENTORY.BIN_LOC | Calls CHECK_NULL to enforce that a bin location is entered for each detail line |
| POST-TEXT-ITEM | PD_INVENTORY | PHYSICAL_QTY | PD_INVENTORY.PHYSICAL_QTY | **COMMENTED OUT / INACTIVE** - was: called CALC_DIFF_QTY after exiting the physical quantity field |
| WHEN-VALIDATE-ITEM | PD_INVENTORY | PHYSICAL_QTY | PD_INVENTORY.PHYSICAL_QTY | Calls CALC_DIFF_QTY to recompute DIFF_QTY; validates decimal quantity is not entered when the part flag disallows it |
| WHEN-VALIDATE-ITEM | PD_INVENTORY | PHY_COUNT_DATE | PD_INVENTORY.PHY_COUNT_DATE | Mandatory when PHYSICAL_QTY is entered; validates count date is not in the future and not earlier than the inventory date |
| WHEN-VALIDATE-ITEM | PD_INVENTORY | PHY_BIN_LOC | PD_INVENTORY.PHY_BIN_LOC | If bin tracking is enabled: calls CALC_DIFF_QTY; validates bin location exists in the bin master; warns if the bin is new and a quantity difference exists |
| WHEN-VALIDATE-ITEM | PD_INVENTORY | TAX_TYPE | PD_INVENTORY.TAX_TYPE | Calls CHECK_NULL to enforce that a tax type is selected |
| WHEN-NEW-ITEM-INSTANCE | PD_INVENTORY | REMARKS | PD_INVENTORY.REMARKS | Initialises display properties for the remarks field on navigation |
| KEY-NEXT-ITEM | PD_INVENTORY | REMARKS | PD_INVENTORY.REMARKS | Navigates to the next item after exiting the remarks field |
| WHEN-BUTTON-PRESSED | PD_INVENTORY | PB_REM | PD_INVENTORY.PB_REM | Opens the multi-line remarks editor popup for the current detail line |
| WHEN-VALIDATE-ITEM | B_EMP | NB_AUTH_EMP | B_EMP.NB_AUTH_EMP | **COMMENTED OUT / INACTIVE** - was: validated the employee code against GM_EMP and displayed the employee name |
| WHEN-VALIDATE-ITEM | B_ADJ | STOCK_TAKEN_BY | B_ADJ.STOCK_TAKEN_BY | Validates that the stock-taken-by employee code is not null before allowing adjustment |
| WHEN-VALIDATE-ITEM | B_ADJ | REASON | B_ADJ.REASON | Calls CHECK_NULL to enforce that an adjustment reason code is selected |
| WHEN-BUTTON-PRESSED | B_ADJ | OK | B_ADJ.OK | Validates stock-taken-by and reason fields; calls Generate_Next_Num to generate the adjustment document number; updates PH_INVENTORY.ADJ_NUM and PD_INVENTORY adjustment references |
| WHEN-BUTTON-PRESSED | CB_SEARCH | SEARCH | CB_SEARCH.SEARCH | Filters PD_INVENTORY detail lines to show only the part matching the entered part number |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EXIT | PB_BLK.PB_EXIT (inherited) | Inherited toolbar button: exits the form after optional save confirmation (inherited from DPL object group) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_LIST | PB_BLK.PB_LIST (inherited) | Inherited toolbar button: shows the LOV for the current item (inherited from DPL object group) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_INSERT | PB_BLK.PB_INSERT (inherited) | Inherited toolbar button: inserts a new record in the current block (inherited from DPL object group) |
| WHEN-BUTTON-PRESSED | PB_BLK | PM_CONT | PB_BLK.PM_CONT (inherited) | Inherited toolbar button: continues or resumes the current pending operation (inherited from DPL object group) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_DEL | PB_BLK.PB_DEL (inherited) | Inherited toolbar button: deletes the current record with confirmation (inherited from DPL object group) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CANCEL | PB_BLK.PB_CANCEL (inherited) | Inherited toolbar button: cancels the current operation and rolls back uncommitted changes (inherited from DPL object group) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SAVE | PB_BLK.PB_SAVE (inherited) | Inherited toolbar button: saves/commits the current form data; calls GENERAL.DISP_TEXT on failure (inherited from DPL object group) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PRINT | PB_BLK.PB_PRINT (inherited) | Inherited toolbar button: launches the print/report action; calls GENERAL.ASK_CONFIRM before proceeding (inherited from DPL object group) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CUT | PB_BLK.PB_CUT (inherited) | Inherited toolbar button: cuts the current field value to clipboard (inherited from DPL object group) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_COPY | PB_BLK.PB_COPY (inherited) | Inherited toolbar button: copies the current field value to clipboard (inherited from DPL object group) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PASTE | PB_BLK.PB_PASTE (inherited) | Inherited toolbar button: pastes clipboard content into the current field (inherited from DPL object group) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_ADJUST | PB_BLK.PB_ADJUST (inherited) | Inherited toolbar button: initiates the stock adjustment workflow; calls GENERAL.DISP_TEXT for validation messages (inherited from DPL object group) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_OK | PB_BLK.PB_OK (inherited) | Inherited toolbar button: confirms the current dialog or operation; calls GENERAL.DISP_TEXT on error (inherited from DPL object group) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CANCEL1 | PB_BLK.PB_CANCEL1 (inherited) | Inherited toolbar button: secondary cancel button for dialog dismissal (inherited from DPL object group) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_QRY | PB_BLK.PB_QRY (inherited) | **COMMENTED OUT / INACTIVE** - was: executed a query on the current block; body commented out (inherited from DPL object group) |
| WHEN-BUTTON-PRESSED | PB_BLK | GEN_ADJ | PB_BLK.GEN_ADJ (inherited) | Inherited toolbar button: generates the stock adjustment document; calls GENERAL.CHECK_NULL and GENERAL.DISP_TEXT (inherited from DPL object group) |
| WHEN-BUTTON-PRESSED | PB_BLK | BT_EXCEL | PB_BLK.BT_EXCEL (inherited) | Inherited toolbar button: exports the current data to Excel (inherited from DPL object group) |
| WHEN-BUTTON-PRESSED | PB_BLK | BT_REPORT | PB_BLK.BT_REPORT (inherited) | Inherited toolbar button: launches the report for the current form (inherited from DPL object group) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_GEN | PB_BLK.PB_GEN (inherited) | Inherited toolbar button: triggers the generate action for inventory processing; calls GENERAL.DISP_TEXT on error (inherited from DPL object group) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EXP | PB_BLK.PB_EXP (inherited) | Inherited toolbar button: exports data or expands the current view (inherited from DPL object group) |

### 8.8 Canvas and Window Inventory

**Windows:**

| Window | Title | Primary Canvas |
| :--- | :--- | :--- |
| WIN_ERR | - | CN_ERR |
| WN_MAIN | Physical Inventory (Rel : 2.7.12) | CN_MAIN |

**Canvases:**

| Canvas | Type | Window |
| :--- | :--- | :--- |
| CN_ADJ | Stacked | - |
| CN_AUTH | Stacked | - |
| CN_MAIN | Content | - |
| CN_TOOL | Content | - |
| CN_ERR | Content | - |

---

### 8.9 Editors

*Popup multi-line editors defined in pt_phy_fmb.xml; items reference editors via Item.EditName.*

| Editor | Title | Item Count | Attached Items (Block.Item) |
| :--- | :--- | ---: | :--- |
| REMARKS | Remarks | 1 | PD_INVENTORY.REMARKS |

**Total Editors:** 1

### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

#### 8.10.1 Visual Attributes (form-defined)

*0 VisualAttribute elements defined at form level (not inherited from DPL.olb).*

*No form-local visual attributes found in pt_phy_fmb.xml.*

#### 8.10.2 Property Classes (form-defined)

*Form-local PropertyClass elements.*

*No form-local property classes found in pt_phy_fmb.xml.*

#### 8.10.3 Object Groups

*Object groups bundle inherited triggers and visual objects applied form-wide at runtime.*

| Object Group Child | Type |
| :--- | :--- |
| KEY-OTHERS | Inherited trigger |
| KEY-NEXT-ITEM | Inherited trigger |
| KEY-PREV-ITEM | Inherited trigger |
| KEY-NXTBLK | Inherited trigger |
| KEY-PRVBLK | Inherited trigger |
| KEY-DOWN | Inherited trigger |
| KEY-UP | Inherited trigger |
| CN_ERR | Inherited canvas |
| VA_DISP | Inherited visualattribute |
| CB_ERR | Inherited block |
| VA_LOV | Inherited visualattribute |
| VA_TRNI_DT | Inherited visualattribute |
| VA_TITLE | Inherited visualattribute |
| VA_ALERT | Inherited visualattribute |
| VA_BUTN | Inherited visualattribute |
| VA_TEXT | Inherited visualattribute |
| VA_MPROMPT | Inherited visualattribute |
| VA_OPROMPT | Inherited visualattribute |
| VA_MAND | Inherited visualattribute |
| VA_NUM | Inherited visualattribute |
| VA_DESC | Inherited visualattribute |
| VA_ICONIC_BUTN | Inherited visualattribute |
| VA_RB | Inherited visualattribute |
| VA_CB | Inherited visualattribute |
| WN_MAIN | Inherited window |
| POP_MAIN | Inherited trigger |
| CN_MAIN | Inherited canvas |
| CN_TOOL | Inherited canvas |
| PB_BLK | Inherited block |
| AL_ERRINFO | Inherited alert |
| AL_NOTE | Inherited alert |
| AL_CONFIRM | Inherited alert |
| WIN_ERR | Inherited window |
| AL_PRINT | Inherited alert |
| FT_SAVE | Inherited trigger |
| FT_CANCEL | Inherited trigger |
| FT_INSERT | Inherited trigger |
| FT_DEL | Inherited trigger |
| FT_LIST | Inherited trigger |
| FT_PRINT | Inherited trigger |
| WHEN-NEW-FORM-INSTANCE | Inherited trigger |

### 8.11 DataSourceColumn Inventory

*32 DataSourceColumn elements across 2 blocks - formal query column-to-block mapping from pt_phy_fmb.xml.*

#### PH_INVENTORY (15 columns)

| Column (DSCName) | Data Type |
| :--- | :--- |
| DEALER_MAP_CD | NUMBER |
| COMP_FA | VARCHAR2 |
| LOC_CD | VARCHAR2 |
| DOC_NUM | VARCHAR2 |
| DOC_DATE | DATE |
| STORES_CD | VARCHAR2 |
| PART_CLASS | VARCHAR2 |
| FSN_IND | VARCHAR2 |
| ABC_IND | VARCHAR2 |
| FROM_PART_NUM | VARCHAR2 |
| TO_PART_NUM | VARCHAR2 |
| CREATED_BY | VARCHAR2 |
| CREATED_DATE | DATE |
| MODIFIED_BY | VARCHAR2 |
| MODIFIED_DATE | DATE |

#### PD_INVENTORY (17 columns)

| Column (DSCName) | Data Type |
| :--- | :--- |
| DEALER_MAP_CD | NUMBER |
| COMP_FA | VARCHAR2 |
| LOC_CD | VARCHAR2 |
| DOC_NUM | VARCHAR2 |
| SRL_NUM | NUMBER |
| STORES_CD | VARCHAR2 |
| PART_NUM | VARCHAR2 |
| STOCK_QTY | NUMBER |
| PHYSICAL_QTY | NUMBER |
| DIFF_QTY | NUMBER |
| REMARKS | VARCHAR2 |
| ADJ_NUM | VARCHAR2 |
| COUNTED_DATE | DATE |
| CREATED_BY | VARCHAR2 |
| CREATED_DATE | DATE |
| MODIFIED_BY | VARCHAR2 |
| MODIFIED_DATE | DATE |

**Total DataSourceColumns:** 32 across 2 blocks

## 9. Object Library

*The Physical Inventory form (PT_PHY) uses the DPL shared object library, which provides a standard set of Visual Attributes and Property Classes applied across all form items. The form itself carries one Object Group reference (OG_GROUP) but no form-level Visual Attributes or Property Classes of its own - all styling and property inheritance comes from the DPL library.*

Source OLB file(s): DPL_olb.xml

| Name | Type | Description | Used By (count) | Sample Items |
| ---- | ---- | ----------- | --------------- | ------------ |
| VA_CB | VisualAttribute | Visual attribute for check-box items (gray background, Arial 8pt) | 1 | VA_CB (DPL internal reference) |
| VA_RB | VisualAttribute | Visual attribute for radio-button items (gray background, Arial 8pt) | 1 | VA_RB (DPL internal reference) |
| VA_ICONIC_BUTN | VisualAttribute | Visual attribute for iconic push-button items (white background) | 1 | VA_ICONIC_BUTN (DPL internal reference) |
| VA_DESC | VisualAttribute | Visual attribute for description/display-item labels (gray background, blue foreground, Small Fonts 7pt) | 1 | VA_DESC (DPL internal reference) |
| VA_NUM | VisualAttribute | Visual attribute for numeric text items (white background, Arial 8pt bold) | 1 | VA_NUM (DPL internal reference) |
| VA_MAND | VisualAttribute | Visual attribute for mandatory (required) input fields (cyan background, Arial 9pt bold) | 1 | VA_MAND (DPL internal reference) |
| VA_OPROMPT | VisualAttribute | Visual attribute for optional field prompt labels (white background, black prompt foreground, Arial 9pt) | 1 | VA_OPROMPT (DPL internal reference) |
| VA_MPROMPT | VisualAttribute | Visual attribute for mandatory field prompt labels (white background, red prompt foreground, Arial 9pt) | 1 | VA_MPROMPT (DPL internal reference) |
| VA_TEXT | VisualAttribute | Visual attribute for standard text input items (white background, Arial 9pt) | 1 | PHY_COUNT_DATE (via PC_DTTIME) |
| VA_BUTN | VisualAttribute | Visual attribute for push-button items (gray background, Arial 10pt bold) | 1 | VA_BUTN (DPL internal reference) |
| VA_ALERT | VisualAttribute | Visual attribute for alert dialog items (gray background, MT Extra 11pt) | 1 | AL_REPORT, AL_PRINT1 (via PC_ALERT) |
| VA_TITLE | VisualAttribute | Visual attribute for title/heading items (gray background, blue foreground, Arial 10pt bold) | 1 | VA_TITLE (DPL internal reference) |
| VA_TRNI_DT | VisualAttribute | Visual attribute for transaction date display items (white background, Courier bold) | 1 | VA_TRNI_DT (DPL internal reference) |
| VA_LOV | VisualAttribute | Visual attribute for LOV fields (gray background, dark-blue foreground, Arial 9pt) | 1 | LV_EMP, LV_INV_NO (via PC_LOV) |
| VA_DISP | VisualAttribute | Visual attribute for display-only (locked) items (RGB r25g75b75 background, Arial 8pt bold) | 1 | VA_DISP (DPL internal reference) |
| PC_DESC | PropertyClass | Display item property class: left-justified, blue text, Arial 9pt, no bevel | 3 | NB_BIN_LOC, NB_PART_DESC, NB_EMP_NAME |
| PC_SC_DATE | PropertyClass | Date display item property class: gray background, Arial 8pt bold, DD-MM-RRRR format mask | referenced | N/A |
| PC_TITLE | PropertyClass | Title text item property class: centred, Arial 10pt bold, upper-case | referenced | N/A |
| PC_FORMAT | PropertyClass | Centred text item property class: white background, Arial 9pt, upper-case | referenced | N/A |
| PC_MR_BLK | PropertyClass | Multi-record block navigation property class: vertical orientation, change-record navigation, next block PB_BLK | 1 | PD_INVENTORY |
| PC_DISP | PropertyClass | Display-only text item property class: disabled, lowered bevel, gray8 background, Arial 9pt | 4 | ADJ_NUM, STORES_CD, ENTRY_MODE, PART_NUM |
| PC_LOV | PropertyClass | List-of-values (LOV) property class: auto-position, gray background, dark-blue foreground | 2 | LV_EMP, LV_INV_NO |
| PC_FORM | PropertyClass | Form-level property class: item-level validation, no savepoint, WN_MAIN console, menu module; includes ON-ERROR and ON-MESSAGE trigger templates | 1 | PT_PHY (form module) |
| PC_DISP_DATE | PropertyClass | Date display item property class: disabled, gray8 background, DD-MM-RRRR format mask | referenced | N/A |
| PC_DISP_NUM | PropertyClass | Numeric display item property class: disabled, lowered bevel, right-justified, gray8 background | 3 | SRL_NUM, STOCK_QTY, DIFF_QTY |
| PC_DATE | PropertyClass | Date text item property class: white background, DD-MM-RRRR format mask, popup menu POP_MAIN | referenced | N/A |
| PC_DTTIME | PropertyClass | Date-time text item property class: DD-MM-RRRR HH24:MI format mask, initialise to current db date-time | 3 | INV_DATE, CURRENT_STOCK_DATE, COUNTED_DATE |
| PC_CB | PropertyClass | Check-box item property class: white background, Arial 9pt | referenced | N/A |
| PC_ALERT | PropertyClass | Alert item property class: gray background, MT Extra 11pt | 2 | AL_REPORT, AL_PRINT1 |
| PC_MDATE | PropertyClass | Mandatory date text item property class: white background, red prompt, DD-MM-RRRR format, popup menu; includes WHEN-VALIDATE-ITEM mandatory check | referenced | N/A |
| PC_RB | PropertyClass | Radio-button item property class: gray background, Arial 9pt | 1 | RADIO_GROUP91 |
| PC_WIND | PropertyClass | Window property class: resizable, movable, WN_MAIN console, Arial 10pt bold, blue title | referenced | N/A |
| PC_CANV | PropertyClass | Canvas property class: white background, Arial, linked to WN_MAIN window | 2 | CN_ADJ, CN_AUTH |
| PC_BUTN | PropertyClass | Push-button property class: Arial 9pt bold, no mouse navigation | 3 | PB_REM, OK, SEARCH |
| PC_TEXT | PropertyClass | Standard text item property class: left-justified, white background, Arial 9pt, popup menu POP_MAIN | 17 | CATG_CD, ABC_IND, FSN_IND, XYZ_IND, MCAT_CD, PRICE, PART_NUMBER, TO_PART_NUM, BIN_LOC_FROM, BIN_LOC_TO, PART_NUM (PD), BIN_LOC1, NB_PART_DESC1, PHY_COUNT_DATE, REMARKS, PART_NUM1 and others |
| PC_MTEXT | PropertyClass | Mandatory text item property class (derived from PC_TEXT with mandatory styling) | 2 | STOCK_TAKEN_BY, REASON |
| PC_UTEXT | PropertyClass | Upper-case text item property class | 1 | NB_INV_NO |
| PC_MUTEXT | PropertyClass | Mandatory upper-case text item property class | 4 | STORES_CD (PD), ENTRY_MODE (PD), PART_NUM (PD), STORES_CD |
| PC_NUM | PropertyClass | Numeric text item property class | 4 | GREATER_THAN, LESS_THAN, NB_LANDED_COST, LANDED_COST |
| PC_MNUM | PropertyClass | Mandatory numeric text item property class | referenced | N/A |
| PC_ICONIC_BUTN | PropertyClass | Iconic push-button property class | referenced | N/A |
| PC_SCROLL | PropertyClass | Scroll-bar property class | referenced | N/A |
| OG_GROUP | ObjectGroup | General-purpose object group defined in the form module (no further sub-objects visible in the form XML) | referenced | N/A |

---

## 10. Record Groups

*Lists all record groups, their LOV bindings, query logic, dynamic bindings, business purpose, and form usage.*

| Record Group | Type | Used By LOV | Display Column | Return Column | Dynamic Bindings | Purpose | Where Used |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| RG_BIN_LOC | Query | LV_BIN_LOC | BIN_LOC | TOTAL_STOCK | No | Lists all bin locations with their total stock quantities for the selected store; used when selecting a bin location for a part count line | LV_BIN_LOC -> PD_INVENTORY.STOCK_QTY, PD_INVENTORY.ALLOC_QTY |
| RG_BIN_LOC_ALL | Query | LV_BIN_LOC_ALL | BIN_LOC | TOTAL_STOCK | No | Lists all bin locations regardless of part; used for full bin location selection without stock filtering | LV_BIN_LOC_ALL |
| RG_INV_NO | Query | LV_INV_NO | DOC_NUM | DOC_DATE | No | Lists existing physical inventory document numbers for the current dealer/location context; allows user to look up and select a prior inventory session | LV_INV_NO |
| RG_EMP | Query | LV_EMP | EMP_NAME | EMP_CD | No | Lists authorised employees available for selection as the stock-count signatory | LV_EMP -> B_EMP.NB_AUTH_EMP, B_EMP.NB_EMP_NAME |
| RG_FROM_BIN_LOC_CD | Query | LOV_FROM_BIN_LOC_CD | SRL | BIN_LOC_CD | No | Lists bin location codes for selecting the starting bin location of the count range | LOV_FROM_BIN_LOC_CD -> PD_INVENTORY.BIN_LOC |
| RG_TO_BIN_LOC_CD | Query | LOV_TO_BIN_LOC_CD | SRL | BIN_LOC_CD | No | Lists bin location codes for selecting the ending bin location of the count range | LOV_TO_BIN_LOC_CD -> PD_INVENTORY.PHY_BIN_LOC |

**Total Record Groups:** 6

## 11. Referenced Database Objects

*Database tables, views, and objects accessed by the form.*

| Block | Base Table | Primary Key Item | Database Item |
| :--- | :--- | :--- | :--- |
| B_DUMMY | - | - | No |
| PH_INVENTORY | PH_INVENTORY | - | Yes |
| PD_INVENTORY | PD_INVENTORY | - | Yes |
| B_EMP | - | - | No |
| B_ADJ | - | - | No |
| CB_SEARCH | - | - | No |

| Object | Schema | Used In | Description |
| :--- | :--- | :--- | :--- |
| `AM_DEALER_LOC` | - | Trigger WHEN-NEW-FORM-INSTANCE | Dealer location master - provides dealer and location context used during form initialisation to scope the session to the correct dealer/location combination |
| `AM_DEALER_LOC_PARAM` | - | Trigger WHEN-VALIDATE-ITEM | Dealer location parameters - holds configuration settings (such as bin-flag) per dealer and location |
| `AM_LIST` | - | L_POPULATE, Trigger WHEN-NEW-FORM-INSTANCE | Application lookup list - master table for list-item values keyed by principal and list type; queried both at form startup and during dynamic list population |
| `DUAL` | - | Trigger WHEN-BUTTON-PRESSED | Oracle pseudo-table used to generate or evaluate scalar expressions (e.g. sequence values or sysdate) at the point a button action is executed |
| `GLOBAL_TEMP_CS_RET` | - | Trigger FT_DEL | Global temporary table used to stage or capture return values during the delete (FT_DEL) transactional trigger processing |
| `GM_EMP` | - | RG_EMP, Trigger WHEN-NEW-FORM-INSTANCE | Employee master - stores employee code, name, and role for authentication and signatory selection; also queried at form startup to validate the current user |
| `GM_STORE` | - | POPULATE_STORES, Trigger WHEN-NEW-FORM-INSTANCE | Store/warehouse master - lists available stores with their dealer and location assignments; referenced both during form initialisation and when populating the store list of values |
| `PD_INVENTORY` | - | PD_INVENTORY | Physical inventory detail - stores individual part-count lines (part number, bin location, physical and system quantities, adjustments) per inventory session |
| `PD_STKADJ` | - | Trigger WHEN-BUTTON-PRESSED | Parts stock adjustment detail - records individual part-line adjustments generated from physical inventory discrepancies |
| `PH_INVENTORY` | - | PH_INVENTORY, RG_INV_NO, Trigger FT_SAVE, Trigger KEY-NEXT-ITEM | Physical inventory header - master record for each physical count session containing document number, date, store, and filter criteria; also written during the FT_SAVE transactional trigger |
| `PH_STKADJ` | - | Trigger WHEN-BUTTON-PRESSED, Trigger WHEN-NEW-FORM-INSTANCE | Physical stock adjustment header - stores the adjustment document number and summary information created from a physical inventory session; also referenced at form startup to check for existing adjustment records |
| `PM_CATEGORY` | - | Trigger WHEN-NEW-FORM-INSTANCE | Parts category master - queried at form initialisation to populate the category filter list of values used when scoping a physical inventory count |
| `PM_MCAT` | - | Trigger WHEN-NEW-FORM-INSTANCE | Parts main-category (major category) master - queried at form initialisation to populate the main-category filter list of values for inventory scoping |
| `PM_PART` | - | Trigger KEY-NEXT-ITEM, Trigger WHEN-BUTTON-PRESSED, Trigger WHEN-VALIDATE-ITEM | Parts master - contains part number, description, and classification details used for validation and population across key-navigation, button actions, and item-validation contexts |
| `PM_PART_VAR` | - | Trigger WHEN-BUTTON-PRESSED, Trigger WHEN-VALIDATE-ITEM | Parts variant/pricing - stores landed cost, decimal quantity flag, and pricing details per part for the dealer/principal; referenced during both button-driven processing and item validation |
| `PM_REASON` | - | Trigger WHEN-NEW-FORM-INSTANCE | Parts adjustment reason code master - queried at form startup to populate the reason-code list of values used when recording stock adjustment justifications |
| `PM_REP_CTRL` | - | Trigger WHEN-BUTTON-PRESSED | Parts report control table - consulted when a print/report button is pressed to retrieve report parameters or control settings governing physical inventory report generation |
| `PM_STOCK_BIN_LOC` | - | RG_BIN_LOC, RG_BIN_LOC_ALL, RG_FROM_BIN_LOC_CD, RG_TO_BIN_LOC_CD, Trigger POST-QUERY, Trigger WHEN-VALIDATE-ITEM | Parts stock by bin location - records stock quantities allocated and available per part per bin location for the dealer/store; drives all bin-location record groups and is also read during post-query population and item validation |
| `PT_BIN_CARD` | - | Trigger WHEN-BUTTON-PRESSED | Parts bin-card transaction table - written or queried when the bin-card button is pressed to record or display the movement history associated with a bin location during physical inventory processing |
| `PT_SAN_LIMIT` | - | Trigger WHEN-NEW-FORM-INSTANCE | Parts sanction limit table - queried at form initialisation to load authorisation or tolerance thresholds that govern allowable adjustment quantities during the physical inventory session |

**Total Referenced Objects:** 20

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure/Package Index

| Requirement ID | Procedure/Package | Purpose |
| -------------- | ----------------- | ------- |
| BR-002 | SF_GET_BIN_FLAG | Retrieves the bin-location management flag for the current dealer and location to configure bin field availability. |
| BR-002 | SF_COPYRIGHT_DECLARATION | Retrieves the current software copyright notice text for display. |
| BR-002 | ENABLE_HEADER (form ProgramUnit) | Enables or disables all header filter fields for data entry. |
| BR-003 | PH_INVENTORY (table) | Queried during count number lookup to confirm existence of an existing count document. |
| BR-004, BR-005 | GENERAL.DISP_TEXT | Displays error, warning, or informational messages to the user. |
| BR-004 | GENERAL.RAISE_ERROR | Raises a pre-defined error message from the error-message catalogue by error code. |
| BR-009 | GENERAL.PROC_TIMER_EXPIRED | Handles timer expiry for report print queue status monitoring and output delivery. |
| BR-009 | GENERAL.PROC_TIMER | Sets up the repeating PRINTER_QUEUE timer that drives report-completion polling. |
| BR-014, BR-016, BR-017, BR-019, BR-020, BR-024, BR-031, BR-032, BR-034, BR-035, BR-036, BR-038 | GENERAL.CHECK_NULL | Validates that a required field is not blank; shows a mandatory-field error if blank. |
| BR-015 | PK_VALIDATE_BACK_DATE.GET_LAST_DOC_DATE | Validates that a proposed count date complies with the back-dating policy for physical inventory documents. |
| BR-017 | ENABLE_HEADER (form ProgramUnit) | Enables or disables header filter fields based on the selected part entry mode. |
| BR-019, BR-020 | ENABLE_POP_BTN (form ProgramUnit) | Checks whether a complete part-number or bin-location range is entered and enables/disables the Populate button accordingly. |
| BR-023, BR-029, BR-031, BR-032, BR-033, BR-035 | CALC_DIFF_QTY (form ProgramUnit) | Calculates the difference between physical count quantity and system stock quantity for a part row. |
| BR-025 | SP_GET_PHY_PART_DETAILS | Retrieves the list of qualifying parts with stock, bin location, and cost data for the physical count based on header filter criteria. |
| BR-025, BR-031 | SF_GET_ALLOW_DECIMAL | Retrieves the decimal-quantity permission flag for a part at the current dealer and principal. |
| BR-029 | SF_GET_STORE_BIN_LOC | Retrieves a summary of all bin locations within the current store where a part holds stock. |
| BR-029 | SP_GET_PART_DESC | Retrieves the part description for a given part number. |
| BR-029 | SF_GET_PRICE | Retrieves the landed-cost price for a part from the price master. |
| BR-031 | SF_GET_DEFAULT_STORE_BIN | Retrieves the default bin location for a part in the current store. |
| BR-035 | SF_GET_STORE_NAME | Retrieves the store name for use in new-bin-location informational messages. |
| BR-039 | PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM | Generates the next sequential adjustment document number for the current financial year. |
| BR-039 | PH_STKADJ (table) | Receives the stock adjustment header record INSERT during adjustment generation. |
| BR-039 | PD_STKADJ (table) | Receives the stock adjustment detail line INSERTs during adjustment generation. |
| BR-039 | STOCK_UPDATE_EXCEPTION (form ProgramUnit) | Translates stock update error codes into specific error messages for the user. |
| BR-041 | GENERAL.ASK_PRINT | Prompts the user to select a print destination (screen or printer). |
| BR-041 | RUN_REPORT | Submits a report job to the report server with the specified parameters and destination. |
| BR-042 | GENERAL.ASK_CONFIRM | Displays a Yes/No confirmation dialog and returns the user's choice. |
| BR-042, BR-043 | GENERAL.PROC_REPORT_CALL | Submits a report object to the report server and manages the job handle for status tracking. |
| BR-004 | GENERAL.CHECK_FORM_FAILURE | Guards delete and save operations by checking FORM_SUCCESS after a built-in Forms operation; displays error text and raises FORM_TRIGGER_FAILURE on failure. |
| BR-002 | GENERAL.L_POP_LIST_ITEM | Creates or re-queries a record group from a SELECT statement and populates the associated list item; used at form startup to initialise all filter list items. |
| BR-002 | GENERAL.L_POPULATE | Populates a named list item from a record group; delegates to L_POP_LIST_ITEM; called from the L_POPULATE program unit during list initialisation. |
| BR-039 | SP_ADJUST_LANDED | Applies landed-cost adjustments to stock records as part of physical inventory adjustment generation. |
| BR-039 | CHK_DUP (form ProgramUnit) | Checks for duplicate part-line entries within the physical inventory detail block before adjustment generation. |
| BR-041 | CALL_REPORT_PR_INVENTORY (form ProgramUnit) | Orchestrates the print flow for the physical inventory report, including confirmation prompt and report submission. |
| BR-041 | CALL_REPORT_PR_PHY (form ProgramUnit) | Orchestrates the print flow for the physical count report and manages report submission and timer setup. |
| BR-041 | PRINT_AS (form ProgramUnit) | Determines the report output destination (screen/printer) and invokes RUN_REPORT accordingly. |
| BR-002 | VIEW_EXCEL_REPORT_NEW (form ProgramUnit) | Generates and opens the physical inventory data as an Excel-format report for the user. |
| BR-002 | POPULATE_STORES (form ProgramUnit) | Populates the store list of values from GM_STORE at form startup and on demand. |
| BR-002 | POPULATE_ERRORS (form package / ProgramUnit) | Holds the in-session error list (VTAB collection) used to accumulate validation errors before displaying them during adjustment generation. |
| BR-002 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Registers the current module name in the Oracle session for monitoring and auditing. |
| BR-002 | DBMS_APPLICATION_INFO.SET_MODULE | Registers the module and action name in the Oracle session. |
| BR-041 | WEBUTIL_FILE.FILE_SAVE_DIALOG | Presents the client-side OS Save dialog to obtain the target path before writing the Excel export file. |
| BR-002 | WEBUTIL_C_API.ID_NULL | Tests whether a WebUtil handle is null before use in list-population program units. |
| BR-041 | WEBUTIL_C_API.ADD_PARAMETER | Adds a typed parameter to a WebUtil ParameterList handle when building inter-process parameter lists for the PRINT_AS report launcher. |
| BR-004 | GENERAL.DELETE_RECGRP_ROW | Removes the specified row from the named block's underlying record group; called from FT_DEL to synchronise record group state after a row deletion. |
| BR-039 | SP_GET_PART_SELL_PRICE_ONE | Retrieves the selling price for a single part. (Referenced in source bundle; not called from any active trigger in the current form.) |
| BR-039 | GENERATE_NEXT_NUM (standalone .prc) | Sequential number generation - active invocation is via the PK_VALIDATE_BACK_DATE package wrapper, not the standalone procedure. |
| BR-002 | ADD_ERROR | Appends a structured error entry to the in-session error collection during validation processing. |
| BR-002 | ADD_EXTERNAL_ERRORS | Merges externally sourced error entries into the in-session error collection. |
| BR-002 | BOOLTOCHAR | Converts a PL/SQL BOOLEAN value to its VARCHAR2 equivalent ('TRUE'/'FALSE') for display or logging. |
| BR-002 | CLEAN_ERROR_STACK | Clears all accumulated entries from the in-session error collection. |
| BR-002 | DEBUGLOG | Writes a diagnostic message to the application debug log during development or troubleshooting. |
| BR-002 | GET_TEMP_DIRECTORY | Returns the path of the client-side temporary directory for use in file-write operations. |
| BR-002 | GET_WINDOWS_DIRECTORY | Returns the Windows system directory path on the client machine. |
| BR-002 | READ_REGISTRY | Reads a value from the Windows registry on the client machine via WebUtil. |
| BR-002 | REGISTER_FUNCTION_CALL | Registers a client-side function call handle within the WebUtil invocation framework. |
| BR-002 | STRIPDIRSEP | Strips trailing directory-separator characters from a file path string. |
| BR-002 | GET_ENVIRONMENT_STRING | Retrieves a named environment or configuration string from the client or session context. |
| BR-002 | D2KWUTIL.CHOOSEFILE | Presents a client-side file-chooser dialog; part of the D2KWUTIL library used for client-file interaction. |
| BR-002 | D2KWUTIL.D2KWUTIL_ACTIVEWIN | Returns the handle of the currently active window in the D2KWUTIL client environment. |
| BR-002 | D2KWUTIL.D2KWUTIL_CHOOSEFILE | Alternative entry point in D2KWUTIL for client-side file selection. |
| BR-002 | D2KWUTIL.GET_ACTIVE_WINDOW | Retrieves the active window handle for use in D2KWUTIL file-dialog calls. |
| BR-002 | D2KWUTIL.SAVE_FILE | Invokes the D2KWUTIL client-side save-file dialog to obtain a target path for file output. |
| BR-002 | D2KWUTIL.ATTEMPT_DLL_LOAD | Attempts to load a named DLL on the client machine via the D2KWUTIL library; used during client-side initialisation. |
| BR-002 | D2KWUTIL.D2KWUTIL_DEBUGSTRING | Returns a diagnostic string from the D2KWUTIL library for debug logging purposes. |
| BR-002 | D2KWUTIL.D2KWUTIL_WINDIR | Returns the Windows directory path via the D2KWUTIL library; used during client-side path resolution. |
| BR-002 | D2KWUTIL.TRANSLATETYPE | Translates an internal D2KWUTIL type code to its string representation; used during file-dialog invocation. |
| BR-002 | SETDEBUG | Enables or disables the application debug-logging mode at runtime. |
| BR-002 | WINDEBUG | Writes a debug message to a client-side window or log target during development or troubleshooting. |
| BR-002 | WEBUTIL.BLOCKING | Controls whether WebUtil Java bean calls block the Forms runtime thread until completion. |
| BR-002 | WEBUTIL.CLEARCALLBACKTRIGGER | Clears any registered WebUtil callback trigger from the current session. |
| BR-002 | WEBUTIL.CREATE_PARAMETER_LIST | Creates a new WebUtil ParameterList handle for passing parameters to Java bean invocations. |
| BR-002 | WEBUTIL.DESTROY_PARAMETER_LIST | Destroys a previously created WebUtil ParameterList handle and frees associated resources. |
| BR-002 | WEBUTIL.DOWNLOADFROMURL | Downloads a file from a specified URL to the client machine via WebUtil. |
| BR-002 | WEBUTIL.DOWNLOADFROMURLINT | Internal WebUtil routine that performs the low-level URL-to-client file transfer. |
| BR-002 | WEBUTIL.ERROR | Returns the last error string recorded by the WebUtil Java bean. |
| BR-002 | WEBUTIL.ERRORALERT | Displays a WebUtil-generated error in a Forms alert dialog. |
| BR-002 | WEBUTIL.EXECUTE | Executes a registered WebUtil Java bean function call. |
| BR-002 | WEBUTIL.FCLOSE | Closes a file handle opened via WEBUTIL.FOPEN. |
| BR-002 | WEBUTIL.FILE_SELECTION_DIALOG_INT | Internal WebUtil routine that drives the client-side file-selection dialog. |
| BR-002 | WEBUTIL.FOPEN | Opens a file on the client machine for reading or writing via WebUtil. |
| BR-002 | WEBUTIL.GETCLIENTOSFAMILY | Returns the operating-system family (e.g. Windows, Unix) of the client machine. |
| BR-002 | WEBUTIL.GETIMPLCLASS | Returns the Java implementation class name for a registered WebUtil bean. |
| BR-002 | WEBUTIL.GETOUTPUT | Retrieves the standard output string produced by a WebUtil host command execution. |
| BR-002 | WEBUTIL.GETPROPERTY | Retrieves a named property value from the WebUtil Java bean. |
| BR-002 | WEBUTIL.GETVAR | Retrieves a named variable value from the WebUtil session context. |
| BR-002 | WEBUTIL.GET_LINE | Reads the next line from a file opened via WEBUTIL.FOPEN. |
| BR-002 | WEBUTIL.GET_PARAMETER_STRING | Retrieves the string value of a named parameter from a WebUtil ParameterList. |
| BR-002 | WEBUTIL.GET_RETURN_CODE | Returns the numeric return code from the most recent WebUtil host command execution. |
| BR-002 | WEBUTIL.GET_STANDARD_OUTPUT | Retrieves the full standard output buffer from a WebUtil host command execution. |
| BR-002 | WEBUTIL.HOST | Executes an operating-system command on the client machine via WebUtil. |
| BR-002 | WEBUTIL.ID_NULL | Tests whether a WebUtil handle is null; alias entry point within the WEBUTIL package. |
| BR-002 | WEBUTIL.INIT | Initialises the WebUtil Java bean and establishes the client-side communication channel. |
| BR-002 | WEBUTIL.INITWEBUTIL | Performs extended WebUtil initialisation including property-bundle loading. |
| BR-002 | WEBUTIL.INVOKE_INT | Internal WebUtil routine that dispatches a Java bean method call by integer type code. |
| BR-002 | WEBUTIL.INVOKE_INTEGRAL | Internal WebUtil routine that dispatches a Java bean method call returning an integral value. |
| BR-002 | WEBUTIL.INVOKE_WU | Core WebUtil dispatch routine that invokes a named Java bean method with a ParameterList. |
| BR-002 | WEBUTIL.ISERROR | Returns TRUE if the most recent WebUtil operation produced an error condition. |
| BR-002 | WEBUTIL.IS_OPEN | Returns TRUE if the specified WebUtil file handle is currently open. |
| BR-002 | WEBUTIL.LENGTH | Returns the byte length of a WebUtil file or buffer. |
| BR-002 | WEBUTIL.LOG | Writes a message to the WebUtil diagnostic log on the client machine. |
| BR-002 | WEBUTIL.POPULATEPROPERTYBUNDLE | Loads a property bundle into the WebUtil Java bean from the specified resource. |
| BR-002 | WEBUTIL.PUTF | Writes a formatted string to a file opened via WEBUTIL.FOPEN. |
| BR-002 | WEBUTIL.PUT_LINE | Writes a line of text to a file opened via WEBUTIL.FOPEN. |
| BR-002 | WEBUTIL.READFROMPROPERTYBUNDLE | Reads a named property value from a previously loaded WebUtil property bundle. |
| BR-002 | WEBUTIL.REGISTER_FUNCTION | Registers a Java bean method as a callable WebUtil function within the current session. |
| BR-002 | WEBUTIL.RELEASE_PROCESS | Releases a WebUtil host-process handle and frees associated client-side resources. |
| BR-002 | WEBUTIL.SETPROPERTY | Sets a named property value on the WebUtil Java bean. |
| BR-002 | WEBUTIL.SHOWBEANS | Displays diagnostic information about all registered WebUtil beans in the current session. |
| BR-002 | WEBUTIL.URL_TO_CLIENT | Transfers a file from a server URL to the client machine using the WebUtil download mechanism. |
| BR-002 | WEBUTIL.WAIT | Pauses WebUtil execution for a specified interval, used to throttle asynchronous operations. |

---

### 12.2 Procedure and Package Catalogue

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| GENERAL.DISP_TEXT | Package procedure (DPL.pld - `general`) | ON-ERROR, ON-MESSAGE, KEY-DOWN, KEY-UP, KEY-NEXT-ITEM in B_DUMMY.NB_INV_NO, KEY-NEXT-ITEM in PH_INVENTORY.BIN_LOC_TO, POST-QUERY in PD_INVENTORY, WBP in PH_INVENTORY.BT_FETCH, WHEN-BUTTON-PRESSED in B_ADJ.OK, WHEN-BUTTON-PRESSED in CB_SEARCH.SEARCH, WHEN-BUTTON-PRESSED in PB_BLK.GEN_ADJ, WHEN-BUTTON-PRESSED in PB_BLK.PB_ADJUST / PB_CANCEL / PB_COPY / PB_CUT / PB_DEL / PB_GEN / PB_INSERT / PB_LIST / PB_OK / PB_PASTE / PB_SAVE, WHEN-BUTTON-PRESSED in PH_INVENTORY.BT_FETCH, WHEN-NEW-BLOCK-INSTANCE in PD_INVENTORY, WHEN-NEW-FORM-INSTANCE, WHEN-VALIDATE-ITEM in PD_INVENTORY.BIN_LOC / PART_NUM / PHYSICAL_QTY / PHY_BIN_LOC / PHY_COUNT_DATE, WHEN-VALIDATE-ITEM in PH_INVENTORY.BIN_LOC_CD_21 / BIN_LOC_CD_22 / BIN_LOC_CD_23 / BIN_LOC_CD_24 / BIN_LOC_CD_25 / BIN_LOC_TO / GREATER_THAN / INV_DATE / LESS_THAN / PART_NUMBER / TO_PART_NUM, ProgramUnit: CALL_REPORT_PR_PHY, ProgramUnit: PRINT_AS, ProgramUnit: STOCK_UPDATE_EXCEPTION, Trigger: FT_DEL, Trigger: FT_SAVE | Displays any message string through an Oracle Forms alert; uses AL_ERRINFO when the title is 'Error', AL_NOTE for all other titles; the sole form-wide user notification mechanism covering error messages, validation feedback, operational messages, and report status notifications; call sites include all PB_BLK canvas button triggers, the WHEN-NEW-FORM-INSTANCE initialisation trigger, and the KEY-DOWN/KEY-UP navigation triggers. |
| GENERAL.RAISE_ERROR | Package procedure (DPL.pld - `general`) | ON-ERROR | Looks up a pre-defined error message by code and raises it to the user; displays the retrieved message text via DISP_TEXT with the appropriate title (Error/Note/Caution); raises FORM_TRIGGER_FAILURE for Error-class messages; used in ON-ERROR for ORA-02292 FK violation handling. |
| GENERAL.CHECK_NULL | Package procedure (DPL.pld - `general`) | KEY-NEXT-ITEM in PH_INVENTORY.BIN_LOC_TO; WHEN-BUTTON-PRESSED in B_ADJ.OK, PB_BLK.GEN_ADJ; WHEN-VALIDATE-ITEM in B_ADJ.REASON, B_ADJ.STOCK_TAKEN_BY, PD_INVENTORY.BIN_LOC, PD_INVENTORY.PART_NUM, PD_INVENTORY.PHY_BIN_LOC, PD_INVENTORY.PHY_COUNT_DATE, PD_INVENTORY.TAX_TYPE, PH_INVENTORY.BIN_LOC_CD_21, PH_INVENTORY.BIN_LOC_CD_22, PH_INVENTORY.BIN_LOC_CD_23, PH_INVENTORY.BIN_LOC_CD_24, PH_INVENTORY.BIN_LOC_CD_25, PH_INVENTORY.BIN_LOC_TO, PH_INVENTORY.ENTRY_MODE, PH_INVENTORY.STOCK_TAKEN_BY, PH_INVENTORY.STORES_CD, PH_INVENTORY.TO_PART_NUM | Validates that a mandatory field value is not null; if null, displays an 'Enter a valid {column_title}' error message via DISP_TEXT and raises FORM_TRIGGER_FAILURE to prevent navigation away from the field; covers all mandatory header and detail fields and the GEN_ADJ pre-generation validation. |
| GENERAL.CHECK_FORM_FAILURE | Package procedure (DPL.pld - `general`) | Trigger: FT_DEL, Trigger: FT_SAVE | Checks FORM_SUCCESS after a built-in Forms operation; displays the ORA SQLERRM or FRM error text via DISP_TEXT and raises FORM_TRIGGER_FAILURE if the operation failed; guards delete and save transactional triggers. |
| GENERAL.DELETE_RECGRP_ROW | Package procedure (DPL.pld - `general`) | Trigger: FT_DEL | Removes the specified row number from the named block's underlying record group; called from the FT_DEL form-level trigger to synchronise the record group state after a row deletion. |
| GENERAL.ASK_CONFIRM | Package function (DPL.pld - `general`) | ProgramUnit: CALL_REPORT_PR_INVENTORY, Trigger: FT_CANCEL | Displays the AL_CONFIRM alert with the supplied message text; returns 1 if the user confirms (Yes/Button1), 0 otherwise; used to ask whether to print with stock quantities before launching the pr_inventory report, and to confirm cancellation of pending changes. |
| GENERAL.ASK_PRINT | Package function (DPL.pld - `general`) | ProgramUnit: PRINT_AS | Displays the AL_PRINT alert for print-destination selection; returns 1 = View/Screen, 2 = Print/Printer, 3 = Cancel; used by PRINT_AS to determine whether to generate the report as a browser PDF or send it to the printer queue. |
| GENERAL.PROC_REPORT_CALL | Package procedure (DPL.pld - `general`) | ProgramUnit: CALL_REPORT_PR_INVENTORY, ProgramUnit: CALL_REPORT_PR_PHY | Configures the supplied report object for BATCH/FILE execution targeting the IAS printer spool path; runs the report via RUN_REPORT_OBJECT; returns the job handle in lv_report and the spool filename in lv_print for subsequent timer-based status polling. |
| GENERAL.PROC_TIMER | Package procedure (DPL.pld - `general`) | ProgramUnit: CALL_REPORT_PR_INVENTORY, ProgramUnit: CALL_REPORT_PR_PHY | Creates a repeating timer named 'PRINTER_QUEUE' with a 5-second interval; enables the report-completion polling loop managed by PROC_TIMER_EXPIRED. |
| GENERAL.PROC_TIMER_EXPIRED | Package procedure (DPL.pld - `general`) | Trigger: WHEN-TIMER-EXPIRED | On each timer tick checks REPORT_OBJECT_STATUS on the stored report job handle in GLOBAL.REPORTHANDLE; when status is FINISHED opens the spool file URL in the browser via WEB.SHOW_DOCUMENT; on failure displays an error; in both terminal states deletes the PRINTER_QUEUE timer. |
| GENERAL.L_POP_LIST_ITEM | Package procedure (DPL.pld - `general`) | ProgramUnit: L_POP_LIST_ITEM, Trigger: WHEN-NEW-FORM-INSTANCE | Creates or re-queries a record group using the supplied SELECT statement and populates the associated list item; called from the L_POP_LIST_ITEM program unit and directly from WHEN-NEW-FORM-INSTANCE to initialise list items at form startup. |
| GENERAL.L_POPULATE | Package procedure (DPL.pld - `general`) | ProgramUnit: L_POPULATE | Populates a named list item from a record group; delegates to L_POP_LIST_ITEM to build the record group via a SELECT and then synchronises the list item contents; called from the L_POPULATE program unit. |
| RUN_REPORT | Procedure (DPL.pld - `pkg_param_variables`) | ProgramUnit: PRINT_AS | Generic report launcher: locates the report object by name, sets destination type (CACHE = HTML to browser, FILE = PDF spool to disk, PRINTER = direct print queue); runs it via RUN_REPORT_OBJECT; opens the browser link for CACHE or displays a file-spool notification for other destinations. |
| PK_VALIDATE_BACK_DATE.GET_LAST_DOC_DATE | Package procedure (PK_VALIDATE_BACK_DATE.pck) | Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.INV_DATE | Queries AM_DOCS for the last_doc_date of the given document context (dealer/principal/location/company/doc-type/fin-year); if last_doc_date is not null and the supplied transaction date is earlier, returns an error message stating the minimum acceptable date in DD-MM-RRRR HH24:MI:SS format; otherwise returns NULL, permitting the transaction to proceed. |
| PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM | Package procedure (PK_VALIDATE_BACK_DATE.pck) | Trigger: FT_SAVE, Trigger: WHEN-BUTTON-PRESSED in B_ADJ.OK | Atomically locks the AM_DOCS row for the current dealer/principal/location/company/document-type/financial-year combination; increments the running document counter; formats the result as prefix ‖ suffix ‖ zero-padded number (6 digits); updates AM_DOCS.doc_num and last_doc_date; returns the formatted document number via OUT parameter; handles row-lock timeout (-54), missing document type (NO_DATA_FOUND), and duplicate master rows (TOO_MANY_ROWS) with structured OUT-parameter error messages. |
| SF_GET_BIN_FLAG | Standalone function (SF_GET_BIN_FLAG.fnc) | Trigger: KEY-CLRFRM | Retrieves the bin-location management flag for the current dealer and location; result governs whether bin-location fields are enabled on the form. |
| SF_COPYRIGHT_DECLARATION | Standalone function (SF_COPYRIGHT_DECLARATION.fnc) | Trigger: KEY-CLRFRM | Retrieves the current software copyright notice text for display during form clear/reset. |
| SF_GET_ALLOW_DECIMAL | Standalone function (SF_GET_ALLOW_DECIMAL.fnc) | Trigger: POST-QUERY in PD_INVENTORY, Trigger: WHEN-VALIDATE-ITEM in PD_INVENTORY.PART_NUM, Trigger: WHEN-BUTTON-PRESSED in PH_INVENTORY.BT_FETCH | Retrieves the decimal-quantity permission flag for a part at the current dealer and principal; controls whether fractional quantities are accepted in the physical count quantity field. |
| SF_GET_DEFAULT_STORE_BIN | Standalone function (SF_GET_DEFAULT_STORE_BIN.fnc) | Trigger: WHEN-VALIDATE-ITEM in PD_INVENTORY.PART_NUM | Retrieves the default bin location for a part in the current store; used to pre-populate the bin location field when a part number is entered. |
| SF_GET_PRICE | Standalone function (SF_GET_PRICE.fnc) | Trigger: POST-QUERY in PD_INVENTORY | Retrieves the landed-cost price for a part from the price master; used to populate the unit cost field on each detail row after query. |
| SF_GET_STORE_BIN_LOC | Standalone function (SF_GET_STORE_BIN_LOC.fnc) | Trigger: POST-QUERY in PD_INVENTORY, Trigger: WHEN-BUTTON-PRESSED in PH_INVENTORY.BT_FETCH | Retrieves a summary of all bin locations within the current store where a part holds stock; used to build the bin-location list of values for a part row. |
| SF_GET_STORE_NAME | Standalone function (SF_GET_STORE_NAME.fnc) | Trigger: WHEN-VALIDATE-ITEM in PD_INVENTORY.PHY_BIN_LOC | Retrieves the store name for use in informational messages when a user enters a new bin location not currently associated with the part. |
| SP_GET_PART_DESC | Standalone procedure (SP_GET_PART_DESC.prc) | Trigger: POST-QUERY in PD_INVENTORY | Retrieves the part description for a given part number; populates the description display field on each detail row after query. |
| SP_GET_PHY_PART_DETAILS | Standalone procedure (SP_GET_PHY_PART_DETAILS.prc) | Trigger: WHEN-BUTTON-PRESSED in PH_INVENTORY.BT_FETCH | Retrieves the qualifying part list with stock, bin location, and cost data for the physical count based on all header filter criteria; populates the PD_INVENTORY detail block. |
| SP_ADJUST_LANDED | Standalone procedure | Trigger: WHEN-BUTTON-PRESSED in B_ADJ.OK (adjustment generation flow) | Applies landed-cost adjustments to stock records as part of physical inventory adjustment generation; called during the stock update sequence after PH_STKADJ and PD_STKADJ are written. |
| SP_GET_PART_SELL_PRICE_ONE | Standalone procedure (SP_GET_PART_SELL_PRICE_ONE.prc) | Referenced in source bundle; not called from any active trigger in the current form | Retrieves the selling price for a single part. (EXTERNAL / NOT CALLED from active triggers in current form.) |
| GENERATE_NEXT_NUM (standalone .prc) | Standalone procedure (GENERATE_NEXT_NUM.prc) | Referenced in source bundle; active call is through PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM | Sequential number generation - active invocation is via the package wrapper, not the standalone .prc. |
| CALC_DIFF_QTY | Form ProgramUnit | Trigger: WHEN-VALIDATE-ITEM in PD_INVENTORY.PHYSICAL_QTY and related quantity items | Calculates the difference between physical count quantity and system stock quantity for a part row; result is written to the difference quantity display field and used in adjustment generation. |
| ENABLE_HEADER | Form ProgramUnit | Trigger: KEY-CLRFRM, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.ENTRY_MODE | Enables or disables all header filter fields for data entry based on form state or selected part entry mode. |
| ENABLE_POP_BTN | Form ProgramUnit | Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.PART_NUMBER, PH_INVENTORY.TO_PART_NUM, PH_INVENTORY.BIN_LOC_CD_21, PH_INVENTORY.BIN_LOC_CD_22, PH_INVENTORY.BIN_LOC_CD_23, PH_INVENTORY.BIN_LOC_CD_24, PH_INVENTORY.BIN_LOC_CD_25, PH_INVENTORY.BIN_LOC_TO | Checks whether a complete part-number or bin-location range is entered and enables or disables the Populate (BT_FETCH) button accordingly. |
| STOCK_UPDATE_EXCEPTION | Form ProgramUnit | Trigger: WHEN-BUTTON-PRESSED in B_ADJ.OK (adjustment generation flow) | Translates stock update error codes returned during adjustment generation into specific user-facing error messages via GENERAL.DISP_TEXT. |
| CHK_DUP | Form ProgramUnit | Trigger: WHEN-BUTTON-PRESSED in PB_BLK.GEN_ADJ, Trigger: WHEN-BUTTON-PRESSED in B_ADJ.OK | Checks for duplicate part-line entries within the physical inventory detail block before proceeding with adjustment generation; raises FORM_TRIGGER_FAILURE if a duplicate is detected. |
| CALL_REPORT_PR_INVENTORY | Form ProgramUnit | Trigger: WHEN-BUTTON-PRESSED (print inventory report button) | Orchestrates the full print flow for the physical inventory report: invokes GENERAL.ASK_CONFIRM to prompt for stock-quantity inclusion, configures the report object, calls GENERAL.PROC_REPORT_CALL, and starts the polling timer via GENERAL.PROC_TIMER. |
| CALL_REPORT_PR_PHY | Form ProgramUnit | Trigger: WHEN-BUTTON-PRESSED (print physical count report button) | Orchestrates the full print flow for the physical count report: configures the report object, calls GENERAL.PROC_REPORT_CALL, and starts the polling timer via GENERAL.PROC_TIMER; displays status messages via GENERAL.DISP_TEXT. |
| PRINT_AS | Form ProgramUnit | Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_GEN or equivalent print-action trigger | Determines the report output destination by calling GENERAL.ASK_PRINT; invokes RUN_REPORT with the appropriate destination type (CACHE, FILE, or PRINTER). |
| VIEW_EXCEL_REPORT_NEW | Form ProgramUnit | Trigger: WHEN-BUTTON-PRESSED in PB_BLK.BT_EXCEL | Generates and opens the physical inventory data as an Excel-format report; uses WEBUTIL_FILE.FILE_SAVE_DIALOG to obtain the client-side save path before writing the export file. |
| POPULATE_STORES | Form ProgramUnit | Trigger: WHEN-NEW-FORM-INSTANCE, on-demand list refresh | Populates the store list of values from GM_STORE filtered by the current dealer and location; called at form startup and whenever the store list requires refreshing. |
| POPULATE_ERRORS | Form package (ProgramUnit) | Trigger: WHEN-BUTTON-PRESSED in B_ADJ.OK | Holds the in-session error list (VTAB collection) used to accumulate validation errors before displaying them to the user during adjustment generation. |
| ADD_ERROR | Form ProgramUnit | Trigger: WHEN-BUTTON-PRESSED in B_ADJ.OK (validation accumulation flow) | Appends a structured error entry to the in-session VTAB error collection managed by POPULATE_ERRORS during validation processing prior to adjustment generation. |
| ADD_EXTERNAL_ERRORS | Form ProgramUnit | Trigger: WHEN-BUTTON-PRESSED in B_ADJ.OK (validation accumulation flow) | Merges externally sourced error entries into the in-session VTAB error collection managed by POPULATE_ERRORS. |
| BOOLTOCHAR | Form ProgramUnit | Internal utility calls within form ProgramUnits | Converts a PL/SQL BOOLEAN value to its VARCHAR2 equivalent ('TRUE' / 'FALSE') for display or logging purposes within the form. |
| CLEAN_ERROR_STACK | Form ProgramUnit | Trigger: WHEN-BUTTON-PRESSED in B_ADJ.OK (pre-validation reset) | Clears all accumulated entries from the in-session VTAB error collection before a new round of validation is performed. |
| DEBUGLOG | Form ProgramUnit | Internal diagnostic calls within form ProgramUnits | Writes a diagnostic message to the application debug log during development or troubleshooting; has no effect in production builds. |
| GET_ENVIRONMENT_STRING | Form ProgramUnit | ProgramUnit: VIEW_EXCEL_REPORT_NEW, ProgramUnit: PRINT_AS | Retrieves a named environment or configuration string from the client or session context; used to resolve runtime paths and server addresses for report and export operations. |
| GET_TEMP_DIRECTORY | Form ProgramUnit | ProgramUnit: VIEW_EXCEL_REPORT_NEW | Returns the path of the client-side temporary directory for use in file-write operations during Excel export. |
| GET_WINDOWS_DIRECTORY | Form ProgramUnit | ProgramUnit: VIEW_EXCEL_REPORT_NEW | Returns the Windows system directory path on the client machine; used to resolve client-side paths during file export. |
| READ_REGISTRY | Form ProgramUnit | ProgramUnit: VIEW_EXCEL_REPORT_NEW | Reads a value from the Windows registry on the client machine via WebUtil; used to locate application installation paths needed for Excel export. |
| REGISTER_FUNCTION_CALL | Form ProgramUnit | Internal WebUtil invocation framework within form ProgramUnits | Registers a client-side function call handle within the WebUtil invocation framework before executing a Java bean method. |
| SETDEBUG | Form ProgramUnit | Internal diagnostic calls within form ProgramUnits | Enables or disables the application debug-logging mode at runtime; controls whether DEBUGLOG and WINDEBUG produce output. |
| WINDEBUG | Form ProgramUnit | Internal diagnostic calls within form ProgramUnits | Writes a debug message to a client-side window or log target during development or troubleshooting; companion to DEBUGLOG for windowed debug output. |
| STRIPDIRSEP | Form ProgramUnit | ProgramUnit: VIEW_EXCEL_REPORT_NEW, ProgramUnit: GET_TEMP_DIRECTORY | Strips trailing directory-separator characters from a file path string to ensure consistent path construction across client operating systems. |
| D2KWUTIL.CHOOSEFILE | Library function (D2KWUTIL) | ProgramUnit: VIEW_EXCEL_REPORT_NEW | Presents a client-side file-chooser dialog via the D2KWUTIL library; used as an alternative file-selection mechanism for client-file interaction during export. |
| D2KWUTIL.D2KWUTIL_ACTIVEWIN | Library function (D2KWUTIL) | ProgramUnit: VIEW_EXCEL_REPORT_NEW | Returns the handle of the currently active window in the D2KWUTIL client environment; used to parent file-dialog windows correctly. |
| D2KWUTIL.D2KWUTIL_CHOOSEFILE | Library function (D2KWUTIL) | ProgramUnit: VIEW_EXCEL_REPORT_NEW | Alternative entry point in D2KWUTIL for client-side file selection; delegates to the underlying choosefile implementation. |
| D2KWUTIL.GET_ACTIVE_WINDOW | Library function (D2KWUTIL) | ProgramUnit: VIEW_EXCEL_REPORT_NEW | Retrieves the active window handle for use in D2KWUTIL file-dialog calls; ensures dialogs are displayed in the correct window context. |
| D2KWUTIL.SAVE_FILE | Library function (D2KWUTIL) | ProgramUnit: VIEW_EXCEL_REPORT_NEW | Invokes the D2KWUTIL client-side save-file dialog to obtain a target path for file output during Excel export. |
| D2KWUTIL.ATTEMPT_DLL_LOAD | Library function (D2KWUTIL) | ProgramUnit: VIEW_EXCEL_REPORT_NEW (client-side initialisation) | Attempts to load a named DLL on the client machine via the D2KWUTIL library; used during client-side initialisation to ensure required native libraries are available before file-dialog or file-write operations proceed. |
| D2KWUTIL.D2KWUTIL_DEBUGSTRING | Library function (D2KWUTIL) | Internal diagnostic calls within D2KWUTIL-dependent ProgramUnits | Returns a diagnostic string from the D2KWUTIL library for debug logging; used to capture D2KWUTIL internal state during troubleshooting. |
| D2KWUTIL.D2KWUTIL_WINDIR | Library function (D2KWUTIL) | ProgramUnit: VIEW_EXCEL_REPORT_NEW | Returns the Windows directory path via the D2KWUTIL library; used during client-side path resolution as an alternative to GET_WINDOWS_DIRECTORY. |
| D2KWUTIL.TRANSLATETYPE | Library function (D2KWUTIL) | ProgramUnit: VIEW_EXCEL_REPORT_NEW | Translates an internal D2KWUTIL type code to its string representation; used during file-dialog invocation to map file-filter type identifiers. |
| WEBUTIL_FILE.FILE_SAVE_DIALOG | WebUtil library function (webutil.pld - `WEBUTIL_FILE`) | Trigger: WHEN-BUTTON-PRESSED in PB_BLK.BT_EXCEL | Presents the client-side operating-system Save dialog, allowing the user to choose a directory, filename, and file filter for the output file; returns the fully qualified path chosen by the user, or NULL if cancelled; used by VIEW_EXCEL_REPORT_NEW to obtain the target path before writing the Excel export file. |
| WEBUTIL_C_API.ID_NULL | WebUtil library function (webutil.pld - `WEBUTIL_C_API`) | ProgramUnit: L_POPULATE, ProgramUnit: L_POP_LIST_ITEM, ProgramUnit: POPULATE_STORES | Tests whether any WebUtil handle (Pointer, FunctionHandle, ParameterHandle, or ParameterList) is null/uninitialised; returns BOOLEAN; used in list-population program units to check whether a record group handle is valid before attempting to use it. |
| WEBUTIL_C_API.ADD_PARAMETER | WebUtil library function (webutil.pld - `WEBUTIL_C_API`) | ProgramUnit: PRINT_AS | Adds a typed parameter (numeric, string, or pointer) to a WebUtil ParameterList handle and returns a ParameterHandle; used when building inter-process parameter lists for Java bean calls invoked from the PRINT_AS report launcher. |
| WEBUTIL.BLOCKING | WebUtil library procedure (webutil.pld) | Internal WebUtil invocation framework | Controls whether WebUtil Java bean calls block the Forms runtime thread until completion; configured during WebUtil initialisation. |
| WEBUTIL.CLEARCALLBACKTRIGGER | WebUtil library procedure (webutil.pld) | Internal WebUtil invocation framework | Clears any registered WebUtil callback trigger from the current session after a Java bean invocation completes. |
| WEBUTIL.CREATE_PARAMETER_LIST | WebUtil library function (webutil.pld) | ProgramUnit: PRINT_AS, ProgramUnit: VIEW_EXCEL_REPORT_NEW | Creates a new WebUtil ParameterList handle for passing parameters to Java bean invocations. |
| WEBUTIL.DESTROY_PARAMETER_LIST | WebUtil library procedure (webutil.pld) | ProgramUnit: PRINT_AS, ProgramUnit: VIEW_EXCEL_REPORT_NEW | Destroys a previously created WebUtil ParameterList handle and frees associated resources after the Java bean call completes. |
| WEBUTIL.DOWNLOADFROMURL | WebUtil library function (webutil.pld) | ProgramUnit: VIEW_EXCEL_REPORT_NEW | Downloads a file from a specified URL to the client machine via WebUtil; used to deliver the generated Excel export file to the client. |
| WEBUTIL.DOWNLOADFROMURLINT | WebUtil library function (webutil.pld) | Internal WebUtil download implementation | Internal WebUtil routine that performs the low-level URL-to-client file transfer underpinning WEBUTIL.DOWNLOADFROMURL. |
| WEBUTIL.ERROR | WebUtil library function (webutil.pld) | Internal WebUtil error-handling flow | Returns the last error string recorded by the WebUtil Java bean; used to retrieve diagnostic detail when WEBUTIL.ISERROR returns TRUE. |
| WEBUTIL.ERRORALERT | WebUtil library procedure (webutil.pld) | Internal WebUtil error-handling flow | Displays a WebUtil-generated error in a Forms alert dialog; called when a WebUtil operation fails and an immediate user notification is required. |
| WEBUTIL.EXECUTE | WebUtil library function (webutil.pld) | Internal WebUtil invocation framework | Executes a registered WebUtil Java bean function call after parameters have been assembled via WEBUTIL.CREATE_PARAMETER_LIST and WEBUTIL_C_API.ADD_PARAMETER. |
| WEBUTIL.FCLOSE | WebUtil library procedure (webutil.pld) | ProgramUnit: VIEW_EXCEL_REPORT_NEW | Closes a file handle opened via WEBUTIL.FOPEN after the export file has been written. |
| WEBUTIL.FILE_SELECTION_DIALOG_INT | WebUtil library function (webutil.pld) | Internal WEBUTIL_FILE implementation | Internal WebUtil routine that drives the client-side file-selection dialog underlying WEBUTIL_FILE.FILE_SAVE_DIALOG. |
| WEBUTIL.FOPEN | WebUtil library function (webutil.pld) | ProgramUnit: VIEW_EXCEL_REPORT_NEW | Opens a file on the client machine for reading or writing via WebUtil; used to create the Excel export output file at the path returned by WEBUTIL_FILE.FILE_SAVE_DIALOG. |
| WEBUTIL.GETCLIENTOSFAMILY | WebUtil library function (webutil.pld) | ProgramUnit: VIEW_EXCEL_REPORT_NEW, ProgramUnit: STRIPDIRSEP | Returns the operating-system family (e.g. Windows, Unix) of the client machine; used to select the correct directory-separator character for path construction. |
| WEBUTIL.GETIMPLCLASS | WebUtil library function (webutil.pld) | Internal WebUtil invocation framework | Returns the Java implementation class name for a registered WebUtil bean; used during bean registration and diagnostics. |
| WEBUTIL.GETOUTPUT | WebUtil library function (webutil.pld) | Internal WebUtil host-command flow | Retrieves the standard output string produced by a WEBUTIL.HOST command execution. |
| WEBUTIL.GETPROPERTY | WebUtil library function (webutil.pld) | Internal WebUtil property management | Retrieves a named property value from the WebUtil Java bean; used during initialisation and configuration. |
| WEBUTIL.GETVAR | WebUtil library function (webutil.pld) | Internal WebUtil session management | Retrieves a named variable value from the WebUtil session context. |
| WEBUTIL.GET_LINE | WebUtil library function (webutil.pld) | ProgramUnit: VIEW_EXCEL_REPORT_NEW | Reads the next line from a file opened via WEBUTIL.FOPEN; used when reading back written export content for verification. |
| WEBUTIL.GET_PARAMETER_STRING | WebUtil library function (webutil.pld) | Internal WebUtil parameter handling | Retrieves the string value of a named parameter from a WebUtil ParameterList. |
| WEBUTIL.GET_RETURN_CODE | WebUtil library function (webutil.pld) | Internal WebUtil host-command flow | Returns the numeric return code from the most recent WEBUTIL.HOST command execution. |
| WEBUTIL.GET_STANDARD_OUTPUT | WebUtil library function (webutil.pld) | Internal WebUtil host-command flow | Retrieves the full standard output buffer from a WEBUTIL.HOST command execution. |
| WEBUTIL.HOST | WebUtil library procedure (webutil.pld) | ProgramUnit: VIEW_EXCEL_REPORT_NEW | Executes an operating-system command on the client machine via WebUtil; used to invoke client-side utilities during the Excel export process. |
| WEBUTIL.ID_NULL | WebUtil library function (webutil.pld) | Internal WebUtil handle validation | Tests whether a WebUtil handle is null; alias entry point within the WEBUTIL package complementing WEBUTIL_C_API.ID_NULL. |
| WEBUTIL.INIT | WebUtil library procedure (webutil.pld) | Trigger: WHEN-NEW-FORM-INSTANCE | Initialises the WebUtil Java bean and establishes the client-side communication channel at form startup. |
| WEBUTIL.INITWEBUTIL | WebUtil library procedure (webutil.pld) | Trigger: WHEN-NEW-FORM-INSTANCE | Performs extended WebUtil initialisation including property-bundle loading; called after WEBUTIL.INIT to complete the client-side setup. |
| WEBUTIL.INVOKE_INT | WebUtil library function (webutil.pld) | Internal WebUtil invocation framework | Internal WebUtil routine that dispatches a Java bean method call by integer type code; underpins WEBUTIL.EXECUTE. |
| WEBUTIL.INVOKE_INTEGRAL | WebUtil library function (webutil.pld) | Internal WebUtil invocation framework | Internal WebUtil routine that dispatches a Java bean method call returning an integral value. |
| WEBUTIL.INVOKE_WU | WebUtil library function (webutil.pld) | Internal WebUtil invocation framework | Core WebUtil dispatch routine that invokes a named Java bean method with a ParameterList; the primary execution mechanism used by WEBUTIL.EXECUTE. |
| WEBUTIL.ISERROR | WebUtil library function (webutil.pld) | Internal WebUtil error-handling flow | Returns TRUE if the most recent WebUtil operation produced an error condition; used to gate calls to WEBUTIL.ERROR and WEBUTIL.ERRORALERT. |
| WEBUTIL.IS_OPEN | WebUtil library function (webutil.pld) | ProgramUnit: VIEW_EXCEL_REPORT_NEW | Returns TRUE if the specified WebUtil file handle is currently open; used to guard WEBUTIL.FCLOSE and write operations. |
| WEBUTIL.LENGTH | WebUtil library function (webutil.pld) | ProgramUnit: VIEW_EXCEL_REPORT_NEW | Returns the byte length of a WebUtil file or buffer; used to verify that the export file has been written successfully. |
| WEBUTIL.LOG | WebUtil library procedure (webutil.pld) | Internal diagnostic calls | Writes a message to the WebUtil diagnostic log on the client machine; used for tracing WebUtil operations during development. |
| WEBUTIL.POPULATEPROPERTYBUNDLE | WebUtil library procedure (webutil.pld) | Trigger: WHEN-NEW-FORM-INSTANCE | Loads a property bundle into the WebUtil Java bean from the specified resource during form initialisation. |
| WEBUTIL.PUTF | WebUtil library procedure (webutil.pld) | ProgramUnit: VIEW_EXCEL_REPORT_NEW | Writes a formatted string to a file opened via WEBUTIL.FOPEN; used to write Excel export data rows with format substitution. |
| WEBUTIL.PUT_LINE | WebUtil library procedure (webutil.pld) | ProgramUnit: VIEW_EXCEL_REPORT_NEW | Writes a line of text to a file opened via WEBUTIL.FOPEN; used to write individual data lines to the Excel export file. |
| WEBUTIL.READFROMPROPERTYBUNDLE | WebUtil library function (webutil.pld) | Internal WebUtil property management | Reads a named property value from a previously loaded WebUtil property bundle. |
| WEBUTIL.REGISTER_FUNCTION | WebUtil library procedure (webutil.pld) | Internal WebUtil invocation framework | Registers a Java bean method as a callable WebUtil function within the current session before it can be invoked via WEBUTIL.EXECUTE. |
| WEBUTIL.RELEASE_PROCESS | WebUtil library procedure (webutil.pld) | Internal WebUtil host-command flow | Releases a WebUtil host-process handle and frees associated client-side resources after a WEBUTIL.HOST command completes. |
| WEBUTIL.SETPROPERTY | WebUtil library procedure (webutil.pld) | Internal WebUtil property management | Sets a named property value on the WebUtil Java bean; used during initialisation and runtime configuration. |
| WEBUTIL.SHOWBEANS | WebUtil library procedure (webutil.pld) | Internal diagnostic calls | Displays diagnostic information about all registered WebUtil beans in the current session; used for troubleshooting bean registration issues. |
| WEBUTIL.URL_TO_CLIENT | WebUtil library function (webutil.pld) | ProgramUnit: VIEW_EXCEL_REPORT_NEW | Transfers a file from a server URL to the client machine using the WebUtil download mechanism; used as an alternative to WEBUTIL.DOWNLOADFROMURL for server-generated export files. |
| WEBUTIL.WAIT | WebUtil library procedure (webutil.pld) | Internal WebUtil asynchronous flow | Pauses WebUtil execution for a specified interval; used to throttle asynchronous operations and avoid race conditions in Java bean invocations. |
| DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Oracle built-in package procedure | Trigger: PRE-FORM, Trigger: KEY-EXIT | Registers the current module name in the Oracle session for monitoring and auditing purposes. |
| DBMS_APPLICATION_INFO.SET_MODULE | Oracle built-in package procedure | Trigger: PRE-FORM, Trigger: KEY-EXIT | Registers the module and action name in the Oracle session for monitoring and auditing purposes. |

## 13. Package Procedure Specifications

*Behavioural requirements for each database package invoked from the form. Only packages referenced in the form XML that have a matching source ``.pck`` file in the input directory are listed. Descriptions are derived from the package bodies in the uploaded PCK sources.*

| ID | Package | Description | Business Requirement | Acceptance Criteria |
| :--- | :--- | :--- | :--- | :--- |
| BR-T-PK-VALIDATE-BACK-DATE | Pk_Validate_Back_Date | Back-date control and sequential document-number generation package for physical inventory and other transaction types; exposes Generate_Next_Num for atomic document numbering and get_last_doc_date for transaction-date validation | The form must prevent users from recording a physical inventory date earlier than the last recorded date for the same context, and must generate a unique sequential document number upon adjustment creation | get_last_doc_date returns an error message when the entered date precedes the last document date; Generate_Next_Num produces a correctly formatted, incremented document number; both routines surface structured error responses for lock timeouts, missing type definitions, and duplicate entries |

**Total Matched Packages:** 1

## 14. Database Package Catalogue

*Detailed specifications for each database package routine called from the form, including signatures and business rules.*
**Source PCK file(s):** PK_VALIDATE_BACK_DATE.pck

| Source File (.pck) | Package | Routine Name | Type | Definition (signature / excerpt) | Called From | Purpose |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| PK_VALIDATE_BACK_DATE.pck | Pk_Validate_Back_Date | Generate_Next_Num | Procedure | PROCEDURE Generate_Next_Num ( pi_dealer_map_cd IN NUMBER, pi_principal_map_cd IN NUMBER, pi_loc_cd IN VARCHAR2, pi_comp_fa IN VARCHAR2, pi_doc_type IN VARCHAR2, po_doc_num OUT V... | FT_SAVE in Form, Trigger: WHEN-BUTTON-PRESSED in B_ADJ.OK | Atomically locks the AM_DOCS row for the current dealer/principal/location/company/document-type/financial-year combination; increments the running document counter; formats the result as prefix \|\| suffix \|\| zero-padded number (6 digits); updates AM_DOCS.doc_num and last_doc_date; returns the formatted document number via OUT parameter. Handles row-lock timeout (-54), missing document type definition (NO_DATA_FOUND), and duplicate master rows (TOO_MANY_ROWS) with structured OUT-parameter error messages. |
| PK_VALIDATE_BACK_DATE.pck | Pk_Validate_Back_Date | get_last_doc_date | Procedure | PROCEDURE get_last_doc_date ( pi_dealer_map_cd IN NUMBER, pi_principal_map_cd IN NUMBER, pi_loc_cd IN VARCHAR2, pi_comp_fa IN VARCHAR2, pi_doc_type IN VARCHAR2, pi_fin_yr IN NUM... | Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.INV_DATE | Queries AM_DOCS for the last_doc_date of the given document context (dealer/principal/location/company/doc-type/fin-year). If last_doc_date is not null and the supplied transaction date is earlier, returns an error message stating the minimum acceptable date in DD-MM-RRRR HH24:MI:SS format; otherwise returns NULL (no error), permitting the transaction to proceed. |

**Total Matched Package Routines (called from form XML):** 2

---

**Function return values:**

| Function | Returns | Values | Description |
| :--- | :--- | :--- | :--- |
| - | - | - | *No matched package functions with documented return values in the available PCK sources.* |

## 15. PLD Procedure Call Sites

*Maps each program-library routine to its call sites within triggers and program units. Behaviour descriptions are derived from the uploaded ``.pld`` sources.*

### DPL.pld (`general`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ASK_CONFIRM | Function | Function(confirm_msg VARCHAR2) RETURN NUMBER | ProgramUnit: CALL_REPORT_PR_INVENTORY, Trigger: FT_CANCEL in Form | Displays the AL_CONFIRM alert with the supplied message text; returns 1 if the user confirms (Yes/Button1), 0 otherwise; used in CALL_REPORT_PR_INVENTORY to ask whether to print with stock quantities before launching the pr_inventory report, and in the FT_CANCEL form-level trigger to confirm cancellation of pending changes |
| ASK_PRINT | Function | Function(confirm_msg VARCHAR2) RETURN NUMBER | ProgramUnit: PRINT_AS | Displays the AL_PRINT alert for print-destination selection; returns 1=View/Screen, 2=Print/Printer, 3=Cancel; used by PRINT_AS to determine whether to generate the report as a browser PDF or send it to the printer queue |
| CHECK_FORM_FAILURE | Procedure | Procedure() | Trigger: FT_DEL in Form, Trigger: FT_SAVE in Form | Checks FORM_SUCCESS after a built-in Forms operation; displays the ORA SQLERRM or FRM error text via DISP_TEXT and raises FORM_TRIGGER_FAILURE if the operation failed; called from the FT_DEL and FT_SAVE form-level triggers to guard delete and save operations |
| CHECK_NULL | Procedure | Procedure(p_value IN VARCHAR2, column_title IN VARCHAR2) | Trigger: KEY-NEXT-ITEM in PH_INVENTORY.BIN_LOC_TO, Trigger: WHEN-BUTTON-PRESSED in B_ADJ.OK, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.GEN_ADJ, Trigger: WHEN-VALIDATE-ITEM in B_ADJ.REASON, Trigger: WHEN-VALIDATE-ITEM in B_ADJ.STOCK_TAKEN_BY, Trigger: WHEN-VALIDATE-ITEM in PD_INVENTORY.BIN_LOC, Trigger: WHEN-VALIDATE-ITEM in PD_INVENTORY.PART_NUM, Trigger: WHEN-VALIDATE-ITEM in PD_INVENTORY.PHY_BIN_LOC, Trigger: WHEN-VALIDATE-ITEM in PD_INVENTORY.PHY_COUNT_DATE, Trigger: WHEN-VALIDATE-ITEM in PD_INVENTORY.TAX_TYPE, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.BIN_LOC_CD_21, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.BIN_LOC_CD_22, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.BIN_LOC_CD_23, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.BIN_LOC_CD_24, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.BIN_LOC_CD_25, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.BIN_LOC_TO, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.ENTRY_MODE, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.STOCK_TAKEN_BY, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.STORES_CD, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.TO_PART_NUM | Validates that a mandatory field value is not null; if null, displays an 'Enter a valid {column_title}' error message via DISP_TEXT and raises FORM_TRIGGER_FAILURE to prevent navigation away from the field; used across all mandatory header and detail fields, and also from the PB_BLK.GEN_ADJ button trigger to validate required adjustment fields before generation |
| DELETE_RECGRP_ROW | Procedure | Procedure(p_block_name in varchar2, p_rec_num in number) | Trigger: FT_DEL in Form | Removes the specified row number from the named block's underlying record group; called from the FT_DEL form-level trigger to synchronise the record group state after a row deletion |
| DISP_TEXT | Procedure | Procedure(text_string VARCHAR2, title_string VARCHAR2) | ProgramUnit: CALL_REPORT_PR_PHY, ProgramUnit: PRINT_AS, ProgramUnit: STOCK_UPDATE_EXCEPTION, Trigger: FT_DEL in Form, Trigger: FT_SAVE in Form, Trigger: KEY-DOWN in Form, Trigger: KEY-NEXT-ITEM in B_DUMMY.NB_INV_NO, Trigger: KEY-NEXT-ITEM in PH_INVENTORY.BIN_LOC_TO, Trigger: KEY-UP in Form, Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: POST-QUERY in PD_INVENTORY, Trigger: WBP in PH_INVENTORY.BT_FETCH, Trigger: WHEN-BUTTON-PRESSED in B_ADJ.OK, Trigger: WHEN-BUTTON-PRESSED in CB_SEARCH.SEARCH, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.GEN_ADJ, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_ADJUST, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_CANCEL, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_COPY, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_CUT, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_DEL, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_GEN, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_INSERT, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_LIST, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_OK, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_PASTE, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_SAVE, Trigger: WHEN-BUTTON-PRESSED in PH_INVENTORY.BT_FETCH, Trigger: WHEN-NEW-BLOCK-INSTANCE in PD_INVENTORY, Trigger: WHEN-NEW-FORM-INSTANCE in Form, Trigger: WHEN-VALIDATE-ITEM in PD_INVENTORY.BIN_LOC, Trigger: WHEN-VALIDATE-ITEM in PD_INVENTORY.PART_NUM, Trigger: WHEN-VALIDATE-ITEM in PD_INVENTORY.PHYSICAL_QTY, Trigger: WHEN-VALIDATE-ITEM in PD_INVENTORY.PHY_BIN_LOC, Trigger: WHEN-VALIDATE-ITEM in PD_INVENTORY.PHY_COUNT_DATE, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.BIN_LOC_CD_21, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.BIN_LOC_CD_22, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.BIN_LOC_CD_23, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.BIN_LOC_CD_24, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.BIN_LOC_CD_25, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.BIN_LOC_TO, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.GREATER_THAN, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.INV_DATE, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.LESS_THAN, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.PART_NUMBER, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.TO_PART_NUM | Displays any message string through an Oracle Forms alert; uses AL_ERRINFO when title is 'Error', AL_NOTE for all other titles; the sole form-wide user notification mechanism covering error messages, validation feedback, operational messages, and report status notifications; call sites expanded in the richer extraction to include all OG_GROUP canvas button triggers (PB_BLK.*), the WHEN-NEW-FORM-INSTANCE initialisation trigger, and the KEY-DOWN/KEY-UP navigation triggers |
| L_POPULATE | Procedure | Procedure(P_LIST_NAME VARCHAR2,P_LIST_FIELD VARCHAR2) | ProgramUnit: L_POPULATE | Populates a named list item from a record group; delegates to l_pop_list_item to build the record group via a SELECT and then synchronises the list item contents; called recursively from the L_POPULATE program unit |
| l_pop_list_item | Procedure | Procedure(p_rg_name VARCHAR2,p_select VARCHAR2) | ProgramUnit: L_POP_LIST_ITEM, Trigger: WHEN-NEW-FORM-INSTANCE in Form | Creates or re-queries a record group using the supplied SELECT statement and populates the associated list item; called from the L_POP_LIST_ITEM program unit and directly from WHEN-NEW-FORM-INSTANCE to initialise list items at form startup |
| PROC_REPORT_CALL | Procedure | Procedure(REPID report_object, lv_report OUT varchar2, lv_print OUT varchar2) | ProgramUnit: CALL_REPORT_PR_INVENTORY, ProgramUnit: CALL_REPORT_PR_PHY | Configures the supplied report object for BATCH/FILE execution targeting the IAS printer spool path (/iashome/ias/reports/printer/); runs the report via RUN_REPORT_OBJECT; returns the job handle in lv_report and the spool filename in lv_print for subsequent timer-based status polling |
| PROC_TIMER | Procedure | Procedure() | ProgramUnit: CALL_REPORT_PR_INVENTORY, ProgramUnit: CALL_REPORT_PR_PHY | Creates a repeating timer named 'PRINTER_QUEUE' with a 5-second interval; enables the report-completion polling loop managed by PROC_TIMER_EXPIRED |
| PROC_TIMER_EXPIRED | Procedure | Procedure() | Trigger: WHEN-TIMER-EXPIRED in Form | On each timer tick checks REPORT_OBJECT_STATUS on the stored report job handle in GLOBAL.REPORTHANDLE; when status is FINISHED opens the spool file URL in the browser via WEB.SHOW_DOCUMENT; on failure displays an error; in both terminal states deletes the PRINTER_QUEUE timer |
| RAISE_ERROR | Procedure | Procedure(mesg_code IN VARCHAR2) | Trigger: ON-ERROR in Form | Looks up the given message code in the application message table; displays the retrieved message text via DISP_TEXT using the title appropriate to the message type (Error/Note/Caution); raises FORM_TRIGGER_FAILURE for Error-class messages; used in ON-ERROR for ORA-02292 FK violation handling |

**Total Active Routines:** 12 of 24 in DPL.pld source

---

### DPL.pld (`pkg_param_variables`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| run_report | Procedure | Procedure(p_report_name in varchar2, p_dest_type in varchar2, p_dest_name in varchar, P_parameter in varchar2, p_report_server in varchar2) | ProgramUnit: PRINT_AS | Generic report launcher: locates the report object by name, sets destination type (CACHE=HTML to browser, FILE=PDF spool to disk, PRINTER=direct print queue); runs it via RUN_REPORT_OBJECT; opens the browser link for CACHE or displays a file-spool notification for other destinations |

**Total Active Routines:** 1 of 3 in DPL.pld source

---

### webutil.pld (`WEBUTIL_C_API`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ADD_PARAMETER | Function | Function(paramList IN ParameterList, /* numeric */ parameterType IN PLS_INTEGER, inOut IN PLS_INTEGER := PARAM_OUT) RETURN ParameterHandle | ProgramUnit: PRINT_AS | Adds a typed parameter (numeric, string, or pointer) to a WebUtil ParameterList handle and returns a ParameterHandle; used when building inter-process parameter lists for Java bean calls invoked from the PRINT_AS report launcher |
| ID_NULL | Function | Function(handle IN Pointer) RETURN BOOLEAN | ProgramUnit: L_POPULATE, ProgramUnit: L_POP_LIST_ITEM, ProgramUnit: POPULATE_STORES | Tests whether any WebUtil handle (Pointer, FunctionHandle, ParameterHandle, or ParameterList) is null/uninitialised; returns BOOLEAN; used in list-population program units to check whether a record group handle is valid before attempting to use it |

**Total Active Routines:** 2 of 28 in webutil.pld source

---

### webutil.pld (`WEBUTIL_FILE`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| FILE_SAVE_DIALOG | Function | Function(directory_name Varchar2 := NULL, file_name Varchar2 := NULL, file_filter Varchar2 := NULL, title Varchar2 := NULL) RETURN Varchar2 | Trigger: WHEN-BUTTON-PRESSED in PB_BLK.BT_EXCEL | Presents the client-side operating-system Save dialog, allowing the user to choose a directory, filename, and file filter for the output file; returns the fully qualified path chosen by the user, or NULL if cancelled; called from the PB_BLK.BT_EXCEL button trigger to obtain the target path before writing the Excel export file to the client machine |

**Total Active Routines:** 1 of 25 in webutil.pld source

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| ID | Service Name | Database Object | Input Parameters | Output | Business Function | API Endpoint Suggestion |
| -- | ------------ | --------------- | ---------------- | ------ | ----------------- | ----------------------- |
| MS-001 | Physical Inventory Count Query | PH_INVENTORY | dealerMapCd, locCd, compFa, parentGroup | List of count documents (docNum, docDate) | Retrieves the list of existing physical inventory count documents for the current dealer and location for count selection | GET /physical-inventory/counts |
| MS-002 | Physical Inventory Count Header | PH_INVENTORY | dealerMapCd, locCd, compFa, parentGroup, docNum | Count header record (invDate, storesCd, entryMode, filterCriteria, auditFields) | Reads or writes the physical inventory count header record (create new count or retrieve existing) | GET/POST /physical-inventory/counts/{docNum} |
| MS-003 | Physical Inventory Count Detail | PD_INVENTORY | dealerMapCd, locCd, compFa, parentGroup, docNum | List of count detail lines (partNum, binLoc, physicalQty, stockQty, diffQty, etc.) | Reads or writes the part-level count lines for a physical inventory count document | GET/PUT /physical-inventory/counts/{docNum}/lines |
| MS-004 | Physical Inventory Part Fetch | SP_GET_PHY_PART_DETAILS | principal, parentGroup, dealerMapCd, locCd, compFa, storesCd, partNumFrom, partNumTo, binLocFrom, binLocTo, catgCd, mcatCd, abcInd, fsnInd, xyzInd, priceLow, priceHigh, priceType, stockQtyFilter, orderBy, activeYn | List of parts with stock quantities, bin location, landed cost, decimal flag, allocated quantity | Retrieves the filtered list of parts for population into the physical count grid, with all supporting stock and cost data | GET /physical-inventory/parts?storesCd=&partNumFrom=&partNumTo=&binLocFrom=&binLocTo=&... |
| MS-005 | Part Details Lookup | PM_PART, PM_PART_VAR | dealerMapCd, principal, parentGroup, locCd, partNum | Part description, landed cost, decimal-quantity flag | Retrieves part description, landed cost, and decimal-quantity permission for a given part number | GET /parts/{partNum}/details?dealerMapCd=&locCd= |
| MS-006 | Bin Location Stock Query | PM_STOCK_BIN_LOC | parentGroup, dealerMapCd, locCd, compFa, storesCd, partNum, binLoc | Current stock, net stock, allocated quantity, float stock | Retrieves current stock quantities for a part at a specific bin location | GET /inventory/stock?storesCd=&partNum=&binLoc= |
| MS-007 | Default Bin Location | SF_GET_DEFAULT_STORE_BIN | parentGroup, dealerMapCd, locCd, compFa, storesCd, partNum | Default bin location code | Retrieves the default bin location for a part within the current store | GET /inventory/default-bin?storesCd=&partNum= |
| MS-008 | Landed Cost Price | SF_GET_PRICE | parentGroup, dealerMapCd, locCd, principal, priceType, partNum | Price value | Retrieves the price for a part for a specified price type (e.g. landed cost) | GET /parts/{partNum}/price?priceType=LC&dealerMapCd=&locCd= |
| MS-009 | Store Bin Locations Summary | SF_GET_STORE_BIN_LOC | parentGroup, dealerMapCd, locCd, partNum, storesCd | All bin locations for the part in the store (combined string) | Retrieves a summary of all bin locations in the store where the part has stock | GET /inventory/bin-locations?storesCd=&partNum= |
| MS-010 | Part Description | SP_GET_PART_DESC | dealerMapCd, principal, partNum | Part description, error indicator | Retrieves the part description for display on count detail rows | GET /parts/{partNum}/description?dealerMapCd= |
| MS-011 | Decimal Quantity Permission | SF_GET_ALLOW_DECIMAL | principal, dealerMapCd, partNum | Decimal-quantity flag (Y/N/E) | Retrieves whether a part may be counted in decimal quantities | GET /parts/{partNum}/decimal-allowed?dealerMapCd= |
| MS-012 | Bin Flag (Bin Management Setting) | SF_GET_BIN_FLAG | parentGroup, dealerMapCd, locCd | Bin management flag | Retrieves whether bin-location management is enabled for the dealer and location | GET /dealer/bin-flag?dealerMapCd=&locCd= |
| MS-013 | Store Name Lookup | SF_GET_STORE_NAME | dealerMapCd, locCd, storesCd | Store name | Retrieves the human-readable store name for a given store code | GET /stores/{storesCd}/name?dealerMapCd=&locCd= |
| MS-014 | Count Date Back-Date Validation | PK_VALIDATE_BACK_DATE.GET_LAST_DOC_DATE | dealerMapCd, principal, locCd, compFa, docType, finYr, proposedDate | Error message (empty if valid) | Validates that a proposed count date complies with the back-dating policy for physical inventory documents | POST /physical-inventory/validate-date |
| MS-015 | Adjustment Document Number Generation | PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM | dealerMapCd, principal, locCd, compFa, docType, finYr, adjDate | Generated document number, error indicator | Generates the next sequential stock adjustment document number for the current financial year | POST /stock-adjustments/generate-number |
| MS-016 | Stock Adjustment Header | PH_STKADJ | dealerMapCd, locCd, compFa, parentGroup, adjNum, adjDate, storesCd, createdBy | Created adjustment header record | Creates the stock adjustment header record when an adjustment is generated from a physical count | POST /stock-adjustments |
| MS-017 | Stock Adjustment Detail Lines | PD_STKADJ | dealerMapCd, locCd, compFa, parentGroup, adjNum, partNum, increaseYn, taxType, adjQty, landedCost, lcCcy, incItemValue, decItemValue, binLoc, remarks, createdBy | Created adjustment detail records | Creates the individual part-level stock adjustment lines for the adjustment document | POST /stock-adjustments/{adjNum}/lines |
| MS-018 | Stock Update Exception Handler | STOCK_UPDATE_EXCEPTION (form ProgramUnit) | sqlCode, partNum | Error message text | Translates stock update procedure error codes into specific, actionable error messages for the user | N/A (form-side error translation; no REST endpoint required) |
| MS-019 | Dealer Location Parameter (Default Tax Type) | AM_DEALER_LOC_PARAM | dealerMapCd, locCd, parentGroup | Default tax type | Retrieves the default tax type for the dealer and location to pre-populate tax type on new count rows | GET /dealer/parameters?dealerMapCd=&locCd= |
| MS-020 | Copyright Declaration | SF_COPYRIGHT_DECLARATION | (none) | Copyright notice text | Retrieves the current software copyright notice text for display | GET /system/copyright |

**Total Microservices Identified: 20**

---

## 17. Workflows

| ID | Workflow Name | Trigger Event | Steps | Decision Points | End State |
| -- | ------------- | ------------- | ----- | --------------- | --------- |
| WF-001 | Form Session Initialisation | Form is opened (PRE-FORM trigger) | 1. Session registered with PT_PHY module identity in the database. | None. | Database session is tagged with the Physical Inventory module for monitoring. |
| WF-002 | Form Reset and Default Configuration | User triggers a form clear/reset (KEY-CLRFRM trigger) | 1. Working flags and session tracking values cleared. 2. Header and detail data-entry permissions restored. 3. Action buttons reset to initial state (Print disabled, Save enabled, Populate disabled). 4. Bin-location flag retrieved from dealer configuration. 5. Default part entry mode set to All parts; order-by set to Part Number; stock-adjustment-on set to Current stock. 6. Copyright notice loaded and displayed. 7. All header filter fields enabled for entry. | None (all steps are unconditional). | Form is in a clean, fully configured state ready for a new physical count session. |
| WF-003 | Existing Count Load | User enters an existing count number and navigates off the field (KEY-NEXT-ITEM on NB_INV_NO) | 1. System checks count number exists in the current dealer's inventory. 2. If found: count record count stored; header block query executed; part detail block query executed. 3. If not found: error shown; user corrected. | Count number exists? Yes -> load records; No -> error and stay on field. | Existing count header and all part detail rows are displayed on screen. |
| WF-004 | New Count Initialisation | User leaves the count number field blank and navigates off | 1. System defaults count date to today. 2. User proceeds to fill header filter criteria. | None. | Count date set to today; user ready to enter count criteria. |
| WF-005 | Header Block Navigation and Button State | Focus moves to the inventory header block (WHEN-NEW-BLOCK-INSTANCE on PH_INVENTORY) | 1. Form validation disabled. 2. If an existing count is loaded: header and detail queries re-executed; count number entry section locked. 3. Button state determined: if count is open (no adjustment, count number present, no stock-taken-by) -> Report, Generate Adjustment, Export, Generate, Save enabled, detail editable; otherwise -> all action buttons disabled, detail locked, Save disabled. 4. Form validation re-enabled. | Is a count loaded AND is it unprocessed (no adjustment, no stock-taken-by)? Yes -> enable action buttons; No -> disable. | Action buttons are in the correct state for the current count's processing stage. |
| WF-006 | Physical Count Part Population | User completes header filter criteria and clicks the Populate button | 1. Store presence validated. 2. At least one range filter (part number or bin location) validated. 3. If already populated this session: skip retrieval, lock header, disable Populate. 4. If auto mode (All parts): SP_GET_PHY_PART_DETAILS called to retrieve qualified parts. 5. If manual mode: inline cursor query executed based on stock quantity filter (all / positive / zero). 6. For each retrieved part: part and bin location fields loaded and locked; physical bin location set; landed cost, stock quantities, description loaded; physical bin location editability set based on difference. 7. Header locked; Populate button disabled; cursor moved to first physical quantity field. | Already populated? Yes -> lock and skip. Auto or manual mode? Governs retrieval method. Stock quantity filter (A/G/E)? Governs which parts are included. | Part detail grid populated with qualifying parts; user ready to enter physical quantities. |
| WF-007 | Physical Count Quantity Entry and Validation | User enters a physical quantity for a part row and navigates off (WHEN-VALIDATE-ITEM on PHYSICAL_QTY) | 1. Decimal compliance checked and enforced. 2. Non-negative check applied. 3. Default tax type fetched from dealer parameters (if no adjustment exists and tax type not yet set). 4. Physical count date set to today. 5. Difference quantity recalculated. 6. Tax type cleared if difference ≤ 0 or quantity null. 7. Direction (increase/decrease) set. 8. Landed cost refreshed from part variant master. 9. Generate Adjustment button enabled if count is open. 10. Counted date updated if quantity changed. | Allow decimal? Yes -> no truncation; No -> truncate. Physical qty < 0? -> error. Difference > 0 and no adj -> enable Generate Adjustment. | Part row updated with validated physical quantity, current difference quantity, refreshed landed cost, and appropriate direction indicator. |
| WF-008 | Stock Adjustment Generation | User completes the adjustment panel (stock-taken-by and reason) and clicks OK (WHEN-BUTTON-PRESSED on B_ADJ.OK) | 1. Stock-taken-by and reason validated as not blank. 2. All detail rows scanned for: (a) positive difference with no tax type; (b) negative difference exceeding available stock. Errors collected. 3. If errors: error panel displayed; workflow stops. 4. If any part has a non-zero difference: proceed; otherwise inform user no adjustment needed and stop. 5. SAN limit checked for applicable dealer categories. 6. Adjustment document number generated (PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM). 7. Stock adjustment header inserted into PH_STKADJ. 8. Stock adjustment detail lines inserted into PD_STKADJ for each part with non-zero difference. 9. Success message shown with adjustment number. 10. Stock-taken-by copied to header; session flagged as adjusted. 11. Save trigger fired; transaction committed. 12. Adjustment panel hidden. | Validation errors? Yes -> show and stop. Differences exist? No -> inform no adjustment needed. SAN limit exceeded? Yes -> error and exit form. Header insert fails? -> rollback and stop. Detail insert fails? -> STOCK_UPDATE_EXCEPTION -> rollback. | Stock adjustment document created and committed; count marked as processed; adjustment panel closed. |
| WF-009 | Part Search in Count Grid | User enters a part number in the search field and clicks Search (WHEN-BUTTON-PRESSED on CB_SEARCH.SEARCH) | 1. Form validation disabled. 2. Detail block navigated to first record. 3. All loaded rows scanned for a match on the entered part number. 4. If found: cursor moves to matching row. 5. If not found: cursor returned to first row; "No matching Record" notice displayed; cursor returned to search field. 6. Form validation re-enabled. | Match found? Yes -> navigate to matching row; No -> inform and return to search field. | Cursor positioned at the matching part row, or returned to the search field if no match. |
| WF-010 | Report Print - Inventory Count with Stock | Print action for inventory count with stock report triggered | 1. Alert shown to select report output. 2. If user accepts: confirmation asked "Do you want to print with Stock?" 3. Stock flag set based on user's answer. 4. If PDF: report submitted to server; output delivered to browser. 5. If printer: report submitted to print queue. | User accepts or cancels? Cancel -> no submission. Print with stock? Yes/No -> flag set accordingly. PDF or printer? Determines delivery path. | Inventory count report generated and delivered to the selected destination. |
| WF-011 | Report Print - Physical Counting Sheet | Print action for physical counting sheet triggered | 1. Alert shown to select output format. 2. If PDF: report (pr_phy_pdf) configured and submitted to report server; output delivered to browser. 3. If printer: report submitted to print queue. | User accepts or cancels? Cancel -> no submission. PDF or printer? Determines delivery path. | Physical inventory counting sheet report generated and delivered. |
| WF-012 | Report Timer Queue Monitoring | PRINTER_QUEUE timer fires (WHEN-TIMER-EXPIRED) | 1. GENERAL.PROC_TIMER_EXPIRED called. 2. If report running/queued: timer allowed to fire again. 3. If report completed: output delivered to browser; timer cancelled. | Report status? Running -> wait; Finished -> deliver; Failed -> error handling in common library. | Report output delivered to user's browser, or error surfaced via common library. |

**Total Workflows Identified: 12**

---

## 18. PLD-Backed Logic

*Maps shared library routines to their business function and suggested API contracts.*

### webutil.pld (`CLIENT_IMAGE`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | ADD_PARAMETER | Business Logic | ProgramUnit: PRINT_AS | /api/v1/pld/add_parameter | When building a report parameter list, then typed parameters are appended to the ParameterList handle for inter-process communication |
| PLD-002 | ID_NULL | Validation | ProgramUnit: L_POPULATE, ProgramUnit: L_POP_LIST_ITEM, ProgramUnit: POPULATE_STORES | /api/v1/pld/id_null | When a WebUtil handle is tested, then returns true if the handle is uninitialised to prevent invalid handle operations |


---

### DPL.pld (`general`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | ASK_CONFIRM | Business Logic | ProgramUnit: CALL_REPORT_PR_INVENTORY | /api/v1/pld/ask_confirm | When the user is asked to confirm printing with stock, then the confirmation result determines the print-with-stock flag for the report |
| PLD-002 | ASK_PRINT | Business Logic | ProgramUnit: PRINT_AS | /api/v1/pld/ask_print | When the user triggers report generation, then the selected print destination (View or Print) controls how the report output is delivered |
| PLD-003 | CHECK_FORM_FAILURE | Validation | Trigger: KEY-COMMIT in Form | /api/v1/pld/check_form_failure | **COMMENTED OUT / INACTIVE** - when a Forms operation completes, then failure status causes the error message to be displayed and the trigger to fail |
| PLD-004 | CHECK_NULL | Validation | Trigger: KEY-NEXT-ITEM in PH_INVENTORY.BIN_LOC_TO, Trigger: WHEN-BUTTON-PRESSED in B_ADJ.OK, Trigger: WHEN-VALIDATE-ITEM in B_ADJ.REASON, Trigger: WHEN-VALIDATE-ITEM in B_ADJ.STOCK_TAKEN_BY, Trigger: WHEN-VALIDATE-ITEM in PD_INVENTORY.BIN_LOC, Trigger: WHEN-VALIDATE-ITEM in PD_INVENTORY.PART_NUM, Trigger: WHEN-VALIDATE-ITEM in PD_INVENTORY.PHY_BIN_LOC, Trigger: WHEN-VALIDATE-ITEM in PD_INVENTORY.PHY_COUNT_DATE, Trigger: WHEN-VALIDATE-ITEM in PD_INVENTORY.TAX_TYPE, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.BIN_LOC_CD_21, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.BIN_LOC_CD_22, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.BIN_LOC_CD_23, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.BIN_LOC_CD_24, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.BIN_LOC_CD_25, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.BIN_LOC_TO, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.ENTRY_MODE, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.STOCK_TAKEN_BY, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.STORES_CD, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.TO_PART_NUM | /api/v1/pld/check_null | When a mandatory field is empty, then navigation away is blocked and a descriptive error message is displayed |
| PLD-005 | DISP_TEXT | Business Logic | ProgramUnit: CALL_REPORT_PR_PHY, ProgramUnit: PRINT_AS, ProgramUnit: STOCK_UPDATE_EXCEPTION, Trigger: KEY-NEXT-ITEM in B_DUMMY.NB_INV_NO, Trigger: KEY-NEXT-ITEM in PH_INVENTORY.BIN_LOC_TO, Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: POST-QUERY in PD_INVENTORY, Trigger: WBP in PH_INVENTORY.BT_FETCH, Trigger: WHEN-BUTTON-PRESSED in B_ADJ.OK, Trigger: WHEN-BUTTON-PRESSED in CB_SEARCH.SEARCH, Trigger: WHEN-BUTTON-PRESSED in PH_INVENTORY.BT_FETCH, Trigger: WHEN-NEW-BLOCK-INSTANCE in PD_INVENTORY, Trigger: WHEN-VALIDATE-ITEM in PD_INVENTORY.BIN_LOC, Trigger: WHEN-VALIDATE-ITEM in PD_INVENTORY.PART_NUM, Trigger: WHEN-VALIDATE-ITEM in PD_INVENTORY.PHYSICAL_QTY, Trigger: WHEN-VALIDATE-ITEM in PD_INVENTORY.PHY_BIN_LOC, Trigger: WHEN-VALIDATE-ITEM in PD_INVENTORY.PHY_COUNT_DATE, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.BIN_LOC_CD_21, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.BIN_LOC_CD_22, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.BIN_LOC_CD_23, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.BIN_LOC_CD_24, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.BIN_LOC_CD_25, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.BIN_LOC_TO, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.GREATER_THAN, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.INV_DATE, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.LESS_THAN, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.PART_NUMBER, Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.TO_PART_NUM | /api/v1/pld/disp_text | When any message must be shown to the user, then the text is displayed in the appropriate alert dialog based on the title |
| PLD-006 | PROC_REPORT_CALL | Business Logic | ProgramUnit: CALL_REPORT_PR_INVENTORY, ProgramUnit: CALL_REPORT_PR_PHY | /api/v1/pld/proc_report_call | When a report is printed, then the report is configured for batch file output and submitted, returning the job handle and spool filename for status monitoring |
| PLD-007 | PROC_TIMER | Business Logic | ProgramUnit: CALL_REPORT_PR_INVENTORY, ProgramUnit: CALL_REPORT_PR_PHY | /api/v1/pld/proc_timer | When a report is submitted for printing, then a repeating timer is created to enable asynchronous polling of the print job status |
| PLD-008 | PROC_TIMER_EXPIRED | Business Logic | Trigger: WHEN-TIMER-EXPIRED in Form | /api/v1/pld/proc_timer_expired | When the print timer fires, then the report job status is checked and the output file is opened in the browser when printing is complete |
| PLD-009 | RAISE_ERROR | Validation | Trigger: ON-ERROR in Form | /api/v1/pld/raise_error | When a specific application error code is raised, then the corresponding message is retrieved, displayed, and the trigger is failed if the message is error-class |
| PLD-010 | run_report | Business Logic | ProgramUnit: PRINT_AS | /api/v1/pld/run_report | When the user selects View or Print, then the report is submitted to the appropriate destination (browser, file spool, or printer) via the report server |


---

### D2kwutil.pld (`Win_API`)

*No routines from ``D2kwutil.pld`` are referenced in ``pt_phy_fmb.xml``.*

---

---

## 19. PCK-Backed Logic

*Maps database package routines to their business rules and suggested API contracts.*

| ID | Package.Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ------------- | ---- | ---------- | ------------- | --------------------- |
| PCK-001 | Pk_Validate_Back_Date.Generate_Next_Num | Business Logic | Trigger: WHEN-BUTTON-PRESSED in B_ADJ.OK | /api/v1/packages/pk_validate_back_date/generate_next_num | When the adjustment OK button is pressed, then a unique sequential document number is generated and the document master is updated atomically |
| PCK-002 | Pk_Validate_Back_Date.get_last_doc_date | Validation | Trigger: WHEN-VALIDATE-ITEM in PH_INVENTORY.INV_DATE | /api/v1/packages/pk_validate_back_date/get_last_doc_date | When the inventory date is entered, then the date is rejected with a minimum-date message if it precedes the last recorded document date for the same context |

---

---

## 20. System Interfaces

### 20.1 Database Integrations

| Interface Name | Type | Purpose | Data Flow | Error Handling |
| -------------- | ---- | ------- | --------- | -------------- |
| Physical Inventory Count Header (PH_INVENTORY) | Oracle database table | Stores and retrieves the physical inventory count header record (filters, dates, store, audit stamp). | Read (SELECT) during count load and post-query; Write (INSERT on new count, UPDATE on existing count save). | PRE-INSERT/PRE-UPDATE triggers auto-populate audit fields. ON-ERROR trigger handles Oracle error codes; concurrent update detected and reported. |
| Physical Inventory Count Detail (PD_INVENTORY) | Oracle database table | Stores and retrieves part-level count rows (part number, bin location, quantities, landed cost, tax type, timestamps). | Read (SELECT/POST-QUERY) during count load; Write (INSERT on new rows, UPDATE on existing rows). | PRE-INSERT/PRE-UPDATE auto-populate audit fields. ON-ERROR handles error codes including concurrent-update detection. |
| Stock Adjustment Header (PH_STKADJ) | Oracle database table | Receives the adjustment header record created when a physical count produces differences. | Write (INSERT) during adjustment generation (WHEN-BUTTON-PRESSED B_ADJ.OK). | VALUE_ERROR, DUP_VAL_ON_INDEX, and WHEN OTHERS exception handlers in adjustment trigger; rollback on failure. |
| Stock Adjustment Detail (PD_STKADJ) | Oracle database table | Receives one adjustment detail line per part with a non-zero difference during adjustment generation. | Write (INSERT) for each qualifying part row during adjustment (WHEN-BUTTON-PRESSED B_ADJ.OK). | VALUE_ERROR, DUP_VAL_ON_INDEX handled explicitly; WHEN OTHERS routed through STOCK_UPDATE_EXCEPTION for specific error messaging; rollback on failure. |
| Parts Master (PM_PART) | Oracle database table | Queried to validate part number existence and retrieve part description, category, ABC/FMS/XYZ indicators, and decimal-quantity flag. | Read (SELECT) during manual part entry validation (WVI PD_INVENTORY.PART_NUM, WVI PH_INVENTORY.PART_NUMBER, WVI PH_INVENTORY.TO_PART_NUM, WBP BT_FETCH). | NO_DATA_FOUND, TOO_MANY_ROWS, VALUE_ERROR, WHEN OTHERS handled with specific messages in WVI triggers. |
| Part Variant Master (PM_PART_VAR) | Oracle database table | Queried for landed cost, sell prices, and ABC/FMS/XYZ indicators for filter and adjustment calculation. | Read (SELECT) during manual part entry validation (WVI PD_INVENTORY.PART_NUM), physical quantity validation (WVI PD_INVENTORY.PHYSICAL_QTY), and post-query enrichment. | NO_DATA_FOUND, TOO_MANY_ROWS, VALUE_ERROR, WHEN OTHERS each produce specific error messages; trigger failure raised. |
| Stock Bin Location (PM_STOCK_BIN_LOC) | Oracle database table | Queried for stock quantities (current, allocated, float) per part and bin location; supports bin location validation. | Read (SELECT) in WVI triggers on PART_NUM, BIN_LOC, PHY_BIN_LOC; in POST-QUERY PD_INVENTORY; and in the Populate (WBP/BT_FETCH) cursor. | NO_DATA_FOUND: quantities defaulted to zero; TOO_MANY_ROWS, VALUE_ERROR, WHEN OTHERS produce specific error messages. |
| Dealer Location Parameters (AM_DEALER_LOC_PARAM) | Oracle database table | Queried for default tax type (on physical quantity entry) and bin-location management flag (via SF_GET_BIN_FLAG). | Read (SELECT) in WVI PD_INVENTORY.PHYSICAL_QTY and by SF_GET_BIN_FLAG. | NO_DATA_FOUND: silent no-default; TOO_MANY_ROWS, VALUE_ERROR, WHEN OTHERS produce error messages; trigger failure raised on errors. |
| Catalogue List (AM_LIST) | Oracle database table | Queried by L_POPULATE to populate list drop-down items on the header filter (active program unit but not currently invoked by active triggers). | Read (SELECT) via L_POPULATE form program unit. | Standard Forms record-group error handling. |
| Store Master (GM_STORE) | Oracle database table | Queried by POPULATE_STORES to populate the store list (active program unit but not currently invoked by active triggers) and by SF_GET_STORE_NAME for bin-location informational messages. | Read (SELECT) via POPULATE_STORES and SF_GET_STORE_NAME. | N/A (POPULATE_STORES not invoked; SF_GET_STORE_NAME display-only). |
| Employee Master (GM_EMP) | Oracle database table | Queried via RG_EMP record group to populate the stock-taken-by employee selection list (signatory employees, currently active). | Read (SELECT) via LV_EMP LOV backed by RG_EMP. | Standard record-group query error handling. |
| Oracle Session Info (DBMS_APPLICATION_INFO) | Oracle built-in package | Registers and clears the PT_PHY module name and session client information at form open (PRE-FORM) and close (KEY-EXIT). | Write (SET_CLIENT_INFO, SET_MODULE) on form open; cleared on exit. | No explicit error handling; Oracle built-in. |
| Back-Date Validation and Number Generation (PK_VALIDATE_BACK_DATE) | Database package (PK_VALIDATE_BACK_DATE.pck) | Validates proposed count date and generates sequential adjustment document numbers. | Read and Write via package calls in WVI PH_INVENTORY.INV_DATE and WHEN-BUTTON-PRESSED B_ADJ.OK. | Error indicator returned by routines; GENERAL.DISP_TEXT used to surface errors; trigger failure raised. |

### 20.2 External System Integrations

The Physical Inventory form integrates with the Oracle Reports Server to generate and deliver inventory and counting-sheet reports. Beyond this, no additional external system integrations are exercised by the form.

| System Name | Integration Type | Purpose | Protocol | Endpoint | Data Exchange | Success / Error Codes |
| ----------- | ---------------- | ------- | -------- | -------- | ------------- | --------------------- |
| Oracle Reports Server | Report server (RUN_REPORT_OBJECT / GENERAL.PROC_REPORT_CALL / RUN_REPORT) | Generates physical inventory count reports (pr_inventory.rdf, pr_inventory, pr_phy_pdf) and delivers them to the user's browser or a printer. | Oracle Reports internal API (RUN_REPORT_OBJECT); Oracle WebUtil for browser delivery (web.show_document to `/reports/rwservlet/getjobid...`); RUN_REPORT for the PRINT_AS path | `/reports/rwservlet/getjobid{jobId}?server={repServer}` (PDF screen delivery); printer queue via GENERAL.PROC_REPORT_CALL | Report parameters passed: P_PARENT, P_PRINCIPAL, P_COMP_FA, P_DEALER, P_LOC, P_DOC_NUM / P_INV_NUM / P_INV_DATE, P_TYPE, USER_NAME, REPORT_ID, REPORT_DESTYPE, MODE, BLANKPAGES | Report job handle returned by RUN_REPORT_OBJECT; status polled via WHEN-TIMER-EXPIRED / GENERAL.PROC_TIMER_EXPIRED; failure surfaced via GENERAL.DISP_TEXT (SQLERRM). |

### 20.3 Report Integrations

| Report Name | Report Server | Parameters | Output Format | Trigger |
| ----------- | ------------- | ---------- | ------------- | ------- |
| C:\OraHome1\reports\samples\demo\pr_inventory.rdf | `:GLOBAL.rep_server` (runtime server name) | P_PARENT, P_PRINCIPAL, P_COMP_FA, P_DEALER, P_LOC, P_DOC_NUM, P_TYPE (stock inclusion flag) | PDF (screen / Alert Button 1) or wided/character (printer / Alert Button 2) | CALL_REPORT_PR_INVENTORY program unit (declarative XML report object REPORT_CALL; FIND_REPORT_OBJECT('REPORT_CALL') retrieves this object whose filename is set at runtime) |
| pr_inventory | `:GLOBAL.rep_server` (runtime server name) | P_PARENT, P_PRINCIPAL, P_COMP_FA, P_DEALER, P_LOC, P_DOC_NUM, P_TYPE (stock inclusion flag) | PDF (screen / Alert Button 1) or wided/character (printer / Alert Button 2) | CALL_REPORT_PR_INVENTORY program unit, called from print button action (BR-042) |
| pr_phy_pdf | `:GLOBAL.rep_server` (runtime server name) | P_PARENT, P_COMP_FA, P_DEALER, P_LOC, P_INV_NUM, P_INV_DATE | PDF (screen / Alert Button 1) or wided/character (printer / Alert Button 2) | CALL_REPORT_PR_PHY program unit, called from print button action (BR-043) |

---

### 20.3.1 Parameters Passed to the Report

Values this form sends when running an Oracle Report. When the selected format is Excel, the form may take an Excel export path instead of building the full report parameter string; lexical SQL fragments (type L/C via lv_default_value) can still apply. The rows below are evidenced submit parameters for this form.

| # | What the user selects on screen | Parameter passed to the report | What is passed |
| --- | --- | --- | --- |
| 1 | Parent | P_PARENT | Passes the Type value from GLOBAL (GLOBAL.P_TYPE). |

## 21. Procedure and Function Business Rule Catalogue

End-to-end business requirement specification for every stored procedure and function referenced by the PT_PHY form.

### 21.1 Catalogue Index

77 procedures/functions - each SP ID links to its detailed specification in Section 21.2.

| SP Index | Routine Name |
| :--- | :--- |
| [SP-001](#SP-001--CALC_DIFF_QTY) | CALC_DIFF_QTY |
| [SP-002](#SP-002--CALL_REPORT_PR_INVENTORY) | CALL_REPORT_PR_INVENTORY |
| [SP-003](#SP-003--CALL_REPORT_PR_PHY) | CALL_REPORT_PR_PHY |
| [SP-004](#SP-004--CHK_DUP) | CHK_DUP |
| [SP-005](#SP-005--ENABLE_HEADER) | ENABLE_HEADER |
| [SP-006](#SP-006--ENABLE_POP_BTN) | ENABLE_POP_BTN |
| [SP-007](#SP-007--STOCK_UPDATE_EXCEPTION) | STOCK_UPDATE_EXCEPTION |
| [SP-008](#SP-008--D2KWUTIL.ATTEMPT_DLL_LOAD) | D2KWUTIL.ATTEMPT_DLL_LOAD |
| [SP-009](#SP-009--D2KWUTIL.CHOOSEFILE) | D2KWUTIL.CHOOSEFILE |
| [SP-010](#SP-010--D2KWUTIL.D2KWUTIL_ACTIVEWIN) | D2KWUTIL.D2KWUTIL_ACTIVEWIN |
| [SP-011](#SP-011--D2KWUTIL.D2KWUTIL_CHOOSEFILE) | D2KWUTIL.D2KWUTIL_CHOOSEFILE |
| [SP-012](#SP-012--D2KWUTIL.D2KWUTIL_DEBUGSTRING) | D2KWUTIL.D2KWUTIL_DEBUGSTRING |
| [SP-013](#SP-013--D2KWUTIL.D2KWUTIL_WINDIR) | D2KWUTIL.D2KWUTIL_WINDIR |
| [SP-014](#SP-014--D2KWUTIL.GET_ACTIVE_WINDOW) | D2KWUTIL.GET_ACTIVE_WINDOW |
| [SP-015](#SP-015--D2KWUTIL.SAVE_FILE) | D2KWUTIL.SAVE_FILE |
| [SP-016](#SP-016--D2KWUTIL.TRANSLATETYPE) | D2KWUTIL.TRANSLATETYPE |
| [SP-017](#SP-017--GENERAL.ASK_CONFIRM) | GENERAL.ASK_CONFIRM |
| [SP-018](#SP-018--GENERAL.ASK_PRINT) | GENERAL.ASK_PRINT |
| [SP-019](#SP-019--GENERAL.CHECK_FORM_FAILURE) | GENERAL.CHECK_FORM_FAILURE |
| [SP-020](#SP-020--GENERAL.CHECK_NULL) | GENERAL.CHECK_NULL |
| [SP-021](#SP-021--GENERAL.DISP_TEXT) | GENERAL.DISP_TEXT |
| [SP-022](#SP-022--GENERAL.L_POP_LIST_ITEM) | GENERAL.L_POP_LIST_ITEM |
| [SP-023](#SP-023--GENERAL.PROC_REPORT_CALL) | GENERAL.PROC_REPORT_CALL |
| [SP-024](#SP-024--GENERAL.PROC_TIMER) | GENERAL.PROC_TIMER |
| [SP-025](#SP-025--GENERAL.PROC_TIMER_EXPIRED) | GENERAL.PROC_TIMER_EXPIRED |
| [SP-026](#SP-026--GENERAL.RAISE_ERROR) | GENERAL.RAISE_ERROR |
| [SP-027](#SP-027--PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM) | PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM |
| [SP-028](#SP-028--PK_VALIDATE_BACK_DATE.GET_LAST_DOC_DATE) | PK_VALIDATE_BACK_DATE.GET_LAST_DOC_DATE |
| [SP-029](#SP-029--WEBUTIL.BLOCKING) | WEBUTIL.BLOCKING |
| [SP-030](#SP-030--WEBUTIL.CLEARCALLBACKTRIGGER) | WEBUTIL.CLEARCALLBACKTRIGGER |
| [SP-031](#SP-031--WEBUTIL.DOWNLOADFROMURL) | WEBUTIL.DOWNLOADFROMURL |
| [SP-032](#SP-032--WEBUTIL.DOWNLOADFROMURLINT) | WEBUTIL.DOWNLOADFROMURLINT |
| [SP-033](#SP-033--WEBUTIL.ERROR) | WEBUTIL.ERROR |
| [SP-034](#SP-034--WEBUTIL.ERRORALERT) | WEBUTIL.ERRORALERT |
| [SP-035](#SP-035--WEBUTIL.EXECUTE) | WEBUTIL.EXECUTE |
| [SP-036](#SP-036--WEBUTIL.FCLOSE) | WEBUTIL.FCLOSE |
| [SP-037](#SP-037--WEBUTIL.FILE_SELECTION_DIALOG_INT) | WEBUTIL.FILE_SELECTION_DIALOG_INT |
| [SP-038](#SP-038--WEBUTIL.FOPEN) | WEBUTIL.FOPEN |
| [SP-039](#SP-039--WEBUTIL.GETIMPLCLASS) | WEBUTIL.GETIMPLCLASS |
| [SP-040](#SP-040--WEBUTIL.GETPROPERTY) | WEBUTIL.GETPROPERTY |
| [SP-041](#SP-041--WEBUTIL.GET_LINE) | WEBUTIL.GET_LINE |
| [SP-042](#SP-042--WEBUTIL.GET_RETURN_CODE) | WEBUTIL.GET_RETURN_CODE |
| [SP-043](#SP-043--WEBUTIL.HOST) | WEBUTIL.HOST |
| [SP-044](#SP-044--WEBUTIL.ID_NULL) | WEBUTIL.ID_NULL |
| [SP-045](#SP-045--WEBUTIL.LENGTH) | WEBUTIL.LENGTH |
| [SP-046](#SP-046--WEBUTIL.PUTF) | WEBUTIL.PUTF |
| [SP-047](#SP-047--WEBUTIL.PUT_LINE) | WEBUTIL.PUT_LINE |
| [SP-048](#SP-048--WEBUTIL.REGISTER_FUNCTION) | WEBUTIL.REGISTER_FUNCTION |
| [SP-049](#SP-049--WEBUTIL.RELEASE_PROCESS) | WEBUTIL.RELEASE_PROCESS |
| [SP-050](#SP-050--WEBUTIL.SETPROPERTY) | WEBUTIL.SETPROPERTY |
| [SP-051](#SP-051--WEBUTIL.URL_TO_CLIENT) | WEBUTIL.URL_TO_CLIENT |
| [SP-052](#SP-052--WEBUTIL.WAIT) | WEBUTIL.WAIT |
| [SP-053](#SP-053--WEBUTIL_FILE.FILE_SAVE_DIALOG) | WEBUTIL_FILE.FILE_SAVE_DIALOG |
| [SP-054](#SP-054--ADD_ERROR) | ADD_ERROR |
| [SP-055](#SP-055--ADD_EXTERNAL_ERRORS) | ADD_EXTERNAL_ERRORS |
| [SP-056](#SP-056--BOOLTOCHAR) | BOOLTOCHAR |
| [SP-057](#SP-057--CLEAN_ERROR_STACK) | CLEAN_ERROR_STACK |
| [SP-058](#SP-058--DEBUGLOG) | DEBUGLOG |
| [SP-059](#SP-059--GET_TEMP_DIRECTORY) | GET_TEMP_DIRECTORY |
| [SP-060](#SP-060--GET_WINDOWS_DIRECTORY) | GET_WINDOWS_DIRECTORY |
| [SP-061](#SP-061--REGISTER_FUNCTION_CALL) | REGISTER_FUNCTION_CALL |
| [SP-062](#SP-062--RUN_REPORT) | RUN_REPORT |
| [SP-063](#SP-063--SETDEBUG) | SETDEBUG |
| [SP-064](#SP-064--SF_COPYRIGHT_DECLARATION) | SF_COPYRIGHT_DECLARATION |
| [SP-065](#SP-065--SF_GET_ALLOW_DECIMAL) | SF_GET_ALLOW_DECIMAL |
| [SP-066](#SP-066--SF_GET_BIN_FLAG) | SF_GET_BIN_FLAG |
| [SP-067](#SP-067--SF_GET_DEFAULT_STORE_BIN) | SF_GET_DEFAULT_STORE_BIN |
| [SP-068](#SP-068--SF_GET_PRICE) | SF_GET_PRICE |
| [SP-069](#SP-069--SF_GET_STORE_BIN_LOC) | SF_GET_STORE_BIN_LOC |
| [SP-070](#SP-070--SF_GET_STORE_NAME) | SF_GET_STORE_NAME |
| [SP-071](#SP-071--SP_ADJUST_LANDED) | SP_ADJUST_LANDED |
| [SP-072](#SP-072--SP_GET_PART_DESC) | SP_GET_PART_DESC |
| [SP-073](#SP-073--SP_GET_PART_SELL_PRICE_ONE) | SP_GET_PART_SELL_PRICE_ONE |
| [SP-074](#SP-074--SP_GET_PHY_PART_DETAILS) | SP_GET_PHY_PART_DETAILS |
| [SP-075](#SP-075--STRIPDIRSEP) | STRIPDIRSEP |
| [SP-076](#SP-076--VIEW_EXCEL_REPORT_NEW) | VIEW_EXCEL_REPORT_NEW |
| [SP-077](#SP-077--WINDEBUG) | WINDEBUG |

---

### 21.2 Detailed Specifications

#### SP-001 - CALC_DIFF_QTY

**Invoked From:**

- pt_phy_fmb.xml [Trigger: KEY-LISTVAL]
- pt_phy_fmb.xml [Trigger: POST-QUERY]
- pt_phy_fmb.xml [Trigger: WHEN-LIST-CHANGED]
- pt_phy_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

PART DETAILS (N/A / CN_MAIN)

---

**Purpose**

Calculates the difference quantity between the physical count and the system stock quantity for a part detail line, then conditionally controls the editability of the physical bin location field and the visual styling of the tax type field based on whether a surplus exists and whether bin tracking is active.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Determine the stock adjustment basis by reading the header-level indicator PH_INVENTORY.stkadj_on (defaulting to 'C' if null).
- Step 2 - If the adjustment basis is 'S' (stock quantity), compute diff_qty as PD_INVENTORY.physical_qty minus PD_INVENTORY.stock_qty (treating null stock_qty as zero).
- Step 3 - If the adjustment basis is 'C' (current stock), compute diff_qty as PD_INVENTORY.physical_qty minus PD_INVENTORY.current_stock (treating null current_stock as zero).
- Step 4 - Evaluate whether the resulting diff_qty is greater than zero (treating null diff_qty as zero).
- Step 5 - If diff_qty is positive and the bin tracking parameter p_bin_flag is 'Y', enable insert and update access on the pd_inventory.phy_bin_loc field for the current record.
- Step 6 - If diff_qty is positive, apply the mandatory visual attribute 'VA_MAND' to the pd_inventory.tax_type field for the current record, signalling that tax type entry is required.
- Step 7 - If diff_qty is zero or negative, reset pd_inventory.phy_bin_loc to the default bin location (PD_INVENTORY.bin_loc), disable insert and update access on phy_bin_loc, and apply the standard visual attribute 'VA_TEXT' to pd_inventory.tax_type.

---
**Decision Points**

DP-001

Condition:
NVL(PH_INVENTORY.stkadj_on, 'C') = 'S'

TRUE:
diff_qty is calculated as physical_qty minus stock_qty (stock-quantity basis).

FALSE:
Proceed to DP-002 to check for the 'C' basis.

---

DP-002

Condition:
NVL(PH_INVENTORY.stkadj_on, 'C') = 'C'

TRUE:
diff_qty is calculated as physical_qty minus current_stock (current-stock basis).

FALSE:
diff_qty is not computed (neither 'S' nor 'C' matched); the field retains its prior value.

---

DP-003

Condition:
NVL(PD_INVENTORY.diff_qty, 0) > 0

TRUE:
A surplus exists; proceed to DP-004 to assess bin tracking, and mark tax_type as mandatory (VA_MAND).

FALSE:
No surplus; reset phy_bin_loc to the default bin_loc, lock the phy_bin_loc field against insert and update, and apply standard styling (VA_TEXT) to tax_type.

---

DP-004

Condition:
NVL(parameter.p_bin_flag, 'N') = 'Y' (evaluated only when diff_qty > 0)

TRUE:
Enable insert and update access on pd_inventory.phy_bin_loc for the current record, allowing the user to specify a physical bin location for the surplus adjustment.

FALSE:
phy_bin_loc insert/update access is not enabled; the field remains read-only.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The stock adjustment comparison basis is determined at the header level (PH_INVENTORY.stkadj_on); a null value defaults to 'C' (current stock), ensuring a comparison is always performed.
- BR-002 - When the adjustment basis is 'S', the difference quantity is derived by subtracting the frozen stock quantity (stock_qty) from the physical count; a null stock_qty is treated as zero.
- BR-003 - When the adjustment basis is 'C', the difference quantity is derived by subtracting the current system stock (current_stock) from the physical count; a null current_stock is treated as zero.
- BR-004 - A null diff_qty is treated as zero when determining whether a surplus exists, preventing null-related logic bypass.
- BR-005 - The physical bin location field (phy_bin_loc) is editable only when a positive difference quantity exists and bin tracking is enabled (p_bin_flag = 'Y'); in all other cases the field is locked against user entry.
- BR-006 - When no surplus is present, the physical bin location is automatically defaulted to the part's standard bin location (bin_loc), ensuring data consistency without user intervention.
- BR-007 - The tax type field is rendered with the mandatory visual attribute (VA_MAND) whenever a surplus quantity exists, indicating that tax type selection is required before the record can be saved; it reverts to standard styling (VA_TEXT) when no surplus is present.

---
**Implementation Logic**

```plsql
PROCEDURE calc_diff_qty
IS
BEGIN
      IF NVL ( :PH_INVENTORY.stkadj_on, 'C') = 'S' THEN
            :PD_INVENTORY.diff_qty := :PD_INVENTORY.physical_qty - NVL (:PD_INVENTORY.stock_qty, 0);
      ELSIF NVL (:PH_INVENTORY.stkadj_on, 'C') = 'C' THEN
            :PD_INVENTORY.diff_qty := :PD_INVENTORY.physical_qty - NVL (:PD_INVENTORY.current_stock, 0);
      END IF;

      IF NVL ( :PD_INVENTORY.diff_qty, 0) > 0 THEN
            IF NVL ( :parameter.p_bin_flag, 'N') = 'Y' THEN
                  SET_ITEM_INSTANCE_PROPERTY ('pd_inventory.phy_bin_loc', current_record, insert_allowed, property_true);
                  SET_ITEM_INSTANCE_PROPERTY ('pd_inventory.phy_bin_loc', current_record, update_allowed, property_true);
            END IF;

            SET_ITEM_INSTANCE_PROPERTY ('pd_inventory.tax_type', current_record, visual_attribute, 'VA_MAND');
      ELSE
            :PD_INVENTORY.phy_bin_loc := :PD_INVENTORY.bin_loc;
            SET_ITEM_INSTANCE_PROPERTY ('pd_inventory.phy_bin_loc', current_record, insert_allowed, property_false);
            SET_ITEM_INSTANCE_PROPERTY ('pd_inventory.phy_bin_loc', current_record, update_allowed, property_false);
            SET_ITEM_INSTANCE_PROPERTY ('pd_inventory.tax_type', current_record, visual_attribute, 'VA_TEXT');
      END IF;
END;
```

#### SP-002 - CALL_REPORT_PR_INVENTORY

**Invoked From:**

- pt_phy_fmb.xml [Trigger: FT_PRINT]
- pt_phy_fmb.xml [Trigger: FT_SAVE]

---

**Screen:**

ADJUSTMENT DETAILS (N/A / CN_ADJ); COUNT DETAILS (N/A / CN_MAIN); PART DETAILS (N/A / CN_MAIN)

---

**Purpose**

Generates the PR Inventory report (pr_inventory) for a given principal, parent, dealer, location, company FA, document number, and type. The procedure presents the user with an output-format alert and a stock-inclusion prompt, then dispatches the report either as a PDF viewed in the browser or as a character-mode printout routed through the report server, passing all contextual filter parameters to the report engine.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_principal | varchar2 | IN |
| p_parent | varchar2 | IN |
| p_dealer | varchar2 | IN |
| p_loc | varchar2 | IN |
| p_comp_fa | varchar2 | IN |
| p_doc_num | varchar2 | IN |
| p_type | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.ASK_CONFIRM ([SP-017](#SP-017--GENERAL.ASK_CONFIRM)) - matched by member name (package unresolved)
- GENERAL.PROC_REPORT_CALL ([SP-023](#SP-023--GENERAL.PROC_REPORT_CALL)) - matched by member name (package unresolved)
- GENERAL.PROC_TIMER ([SP-024](#SP-024--GENERAL.PROC_TIMER)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Locate the pre-defined report object 'REPORT_CALL' using Find_Report_Object and set the target report filename to 'pr_inventory'.
- Step 2 - Display the 'AL_REPORT' alert to the user to capture the desired output action (Button 1 = PDF/View, Button 2 = Print, Button 3 = Cancel).
- Step 3 - If the user selects Button 1 or Button 2 (i.e., any non-cancel choice), invoke GENERAL.ASK_CONFIRM with the prompt 'Do you want to print with Stock?' to determine whether stock data should be included in the report.
- Step 4 - Based on the confirmation response, set the global variable :GLOBAL.p_type to 'Y' (include stock) if the user confirmed (choice = 1), or 'N' (exclude stock) otherwise.
- Step 5 - If the user selected Button 1 (PDF/View): configure the report object with format PDF, pass all filter parameters (P_PARENT, P_PRINCIPAL, P_COMP_FA, P_DEALER, P_LOC, P_DOC_NUM, P_TYPE from :GLOBAL.p_type) along with REPORT_DESTYPE=FILE, MODE=BITMAP, and BLANKPAGES=NO, set the report server from :global.rep_server, execute the report via RUN_REPORT_OBJECT, and open the generated PDF in a new browser window using web.show_document.
- Step 6 - If the user selected Button 2 (Print): configure the report object with format 'wided' (character mode), pass all filter parameters with REPORT_DESTYPE=PRINTER, MODE=CHARACTER, and BLANKPAGES=NO, set the report server, then delegate execution and output handling to GENERAL.PROC_REPORT_CALL, storing the resulting report handle and print output in :global.reporthandle and :global.printoutput respectively, and finally invoke GENERAL.PROC_TIMER to manage the print queue timer.
- Step 7 - If the user selected Button 3 (Cancel): call Clear_Message and exit without generating any report.

---
**Decision Points**

DP-001

Condition: The value returned by Show_Alert('AL_REPORT') equals Alert_Button1 OR Alert_Button2.

TRUE: Proceed to ask the stock-inclusion confirmation (GENERAL.ASK_CONFIRM) and set :GLOBAL.p_type accordingly before continuing to report generation.

FALSE: The user chose Button 3 (Cancel); call Clear_Message and exit the procedure without generating a report.

---

DP-002

Condition: The value returned by GENERAL.ASK_CONFIRM('Do you want to print with Stock?') equals 1.

TRUE: Set :GLOBAL.p_type to 'Y', indicating the report should include stock data.

FALSE: Set :GLOBAL.p_type to 'N', indicating the report should exclude stock data.

---

DP-003

Condition: The alert response equals Alert_Button1 (PDF/View output selected).

TRUE: Configure the report object for PDF format (BITMAP mode, FILE destination), run the report via RUN_REPORT_OBJECT, and display the output in a new browser window via web.show_document.

FALSE: Evaluate DP-004 to determine whether the print path applies.

---

DP-004

Condition: The alert response equals Alert_Button2 (Print output selected).

TRUE: Configure the report object for character-mode format ('wided', PRINTER destination), delegate report execution to GENERAL.PROC_REPORT_CALL, store the report handle and print output in global variables, and invoke GENERAL.PROC_TIMER to handle the print queue.

FALSE: No further action (Button 3 / Cancel path already handled by DP-001).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The report object named 'REPORT_CALL' must exist in the form; it is located via Find_Report_Object and reused for all output paths.
- BR-002 - The target report is always 'pr_inventory'; the report filename is hardcoded and not derived from input parameters.
- BR-003 - The report server used for all executions is sourced exclusively from the global variable :global.rep_server; no alternative server may be specified at call time.
- BR-004 - The stock-inclusion flag (:GLOBAL.p_type) is determined interactively at runtime via GENERAL.ASK_CONFIRM and overrides the p_type input parameter for the actual report execution; the resolved value is stored in :GLOBAL.p_type before parameters are passed to the report engine.
- BR-005 - P_PRINCIPAL and P_DEALER are converted to numeric values (TO_NUMBER) before being passed as report parameters, ensuring type consistency regardless of the VARCHAR2 input format.
- BR-006 - PDF output (Button 1) is rendered in BITMAP mode with blank pages suppressed (BLANKPAGES=NO) and opened in a new browser window; it is not saved to a named file destination visible to the user.
- BR-007 - Print output (Button 2) is rendered in CHARACTER mode using the 'wided' format with blank pages suppressed; execution and spooling are fully delegated to GENERAL.PROC_REPORT_CALL, and the resulting handles are stored in :global.reporthandle and :global.printoutput for downstream timer processing by GENERAL.PROC_TIMER.
- BR-008 - Selecting the cancel option (Button 3) results in no report being generated and no parameters being modified; Clear_Message is called to suppress any residual form messages.

---
**Implementation Logic**

```plsql
PROCEDURE call_report_pr_inventory(p_principal varchar2,p_parent varchar2,p_dealer varchar2,
                                  p_loc varchar2, p_comp_fa varchar2, p_doc_num varchar2,
                                  p_type varchar2
                                 )IS

	repid  					REPORT_OBJECT;
	lv_rep  				VARCHAR2(100);
	lv_report_name 	VARCHAR2(50);
	lv_server 			VARCHAR2(20) := :global.rep_server;
	lv_alert 				VARCHAR2(20);
	l_v_Param				VARCHAR2(50);
	l_AlertId				ALERT;
	lv_param				VARCHAR2(100);
	lv_report       varchar2(2000);
	lv_print        varchar2(2000);
	lv_choice number;

Begin
	--Checking The Alert Button
	repid := Find_Report_Object('REPORT_CALL');
	lv_report_name := 'pr_inventory';
	l_AlertId := Find_Alert('AL_REPORT');
	lv_alert := Show_Alert(l_AlertId);
	
	If lv_alert = Alert_Button1 or lv_alert = Alert_Button2 then
	--Added by Anjiv on 14/09/2006 to dispaly after print dialog
	lv_choice := general.ask_confirm('Do you want to print with Stock?');
				IF LV_CHOICE = 1 THEN 
				
					:GLOBAL.p_type := 'Y';
				ELSE 
				
					:GLOBAL.p_type := 'N';
				END IF;
	
	end if;
	
	If lv_alert = Alert_Button1 Then
	--	Clear_Message;
	Set_Report_Object_Property(repid,Report_Desformat,'PDF');
		--Set_Report_Object_Property(repid,Report_Destype,'FILE');
		SET_REPORT_OBJECT_PROPERTY(repid,report_other,'P_PARENT='||p_parent||
                                                   ' P_PRINCIPAL='||to_number(p_principal)||
                                                 ' P_COMP_FA='||p_comp_fa||
                                                 ' P_DEALER='||to_number(p_dealer)||
                                                 ' P_LOC='||p_loc||
                                                 ' P_DOC_NUM='||p_doc_num||
                                                 ' P_TYPE='||:GLOBAL.p_type||
                                                 ' REPORT_DESTYPE =FILE'||
                                                 ' MODE=BITMAP BLANKPAGES=NO');
		Set_Report_Object_Property(repid,Report_Server,lv_server);
		Set_Report_Object_Property(repid,REPORT_FILENAME,lv_report_name);
    lv_rep := RUN_REPORT_OBJECT(repid);
    web.show_document('/reports/rwservlet/getjobid'||substr(lv_rep,instr(lv_rep,'_',-1)+1)||'?'||'server='||lv_server,'_blank');
	Elsif lv_alert = Alert_Button2 Then
		SET_REPORT_OBJECT_PROPERTY(repid,REPORT_FILENAME,lv_report_name);
		--set_report_object_property(repid,REPORT_DESTYPE,PRINTER);
    /* code for character begin */
		SET_REPORT_OBJECT_PROPERTY(repid,REPORT_DESFORMAT,'wided');
		SET_REPORT_OBJECT_PROPERTY(repid,report_other,'P_PARENT='||p_parent||
                                                   ' P_PRINCIPAL='||to_number(p_principal)||
                                                 ' P_COMP_FA='||p_comp_fa||
                                                 ' P_DEALER='||to_number(p_dealer)||
                                                 ' P_LOC='||p_loc||
                                                 ' P_DOC_NUM='||p_doc_num||
                                                 ' P_TYPE='||:GLOBAL.p_type||
                                                 ' REPORT_DESTYPE =PRINTER'||
                                                 '  MODE=CHARACTER BLANKPAGES=NO');
	 	SET_REPORT_OBJECT_PROPERTY(repid,REPORT_SERVER,lv_server);
	 	general.PROC_REPORT_CALL (REPID,lv_report,lv_print);
	 	:global.reporthandle := lv_report;
		:global.printoutput  := lv_print;
        general.PROC_TIMER;	
		

		/*Declare
      hTimer    TIMER;
      vcFile    VARCHAR2(225) := 'test';
      vcResult  VARCHAR2(30);
    Begin
        vcFile:= Get_Application_Property(UserName)||To_Char(Sysdate,'YYYYMMDDHHMISS');
        vcFile := vcFile||'.rrpp';
         Set_Report_Object_Property(repid,REPORT_EXECUTION_MODE,BATCH);
        Set_Report_Object_Property(repid,REPORT_DESTYPE,FILE);
      	--Set_Report_Object_Property(repid,REPORT_DESNAME,'D:\OraHome1\forms90\'||l_v_File);
     		set_report_object_property(repid,REPORT_DESNAME,'/iashome/ias/reports/printer/'||vcFile);
				Set_Report_Object_Property(repid,REPORT_SERVER,:global.rep_server); -- 'mulreports
				:global.reporthandle := RUN_REPORT_OBJECT(repid);
				:global.printoutput :=vcFile;
			  hTimer := CREATE_TIMER('PRINTER_QUEUE','15000',REPEAT);
    End;*/
	Else
		--Message('Alert Button3');
		Clear_Message;
	End If;
End;
   /*repid  REPORT_OBJECT;
   lv_rep  varchar2(100);
   lv_report_name varchar2(50);
   lv_server varchar2(20) := :global.rep_server;
   lv_alert varchar2(20);
begin   
   lv_alert := show_alert('AL_REPORT');
   if lv_alert != ALERT_BUTTON2 then	 
      repid := find_report_object('REPORT_CALL');
      lv_report_name := 'pr_inventory';
      SET_REPORT_OBJECT_PROPERTY(repid,REPORT_DESFORMAT,'PDF');
      if lv_alert = ALERT_BUTTON1 then
         set_report_object_property(repid,REPORT_DESTYPE,CACHE);
      --elsif lv_alert = ALERT_BUTTON2 then
        -- set_report_object_property(repid,REPORT_DESTYPE,PRINTER);
      end if;
      
      SET_REPORT_OBJECT_PROPERTY(repid,report_other,'P_PARENT='||p_parent||
                                                   ' P_PRINCIPAL='||to_number(p_principal)||
                                                 ' P_COMP_FA='||p_comp_fa||
                                                 ' P_DEALER='||to_number(p_dealer)||
                                                 ' P_LOC='||p_loc||
                                                 ' P_DOC_NUM='||p_doc_num||
                                                 ' P_TYPE='||p_type);

      SET_REPORT_OBJECT_PROPERTY(repid,REPORT_SERVER,lv_server);
--SET_REPORT_OBJECT_PROPERTY(repid,REPORT_FILENAME,'d:\'||lv_report_name);
      SET_REPORT_OBJECT_PROPERTY(repid,REPORT_FILENAME,lv_report_name);
      lv_rep := RUN_REPORT_OBJECT(repid);
      if get_report_object_property(repid,REPORT_DESTYPE) != 'PRINTER' then
         web.show_document('/reports/rwservlet/getjobid'||substr(lv_rep,instr(lv_rep,'_',-1)+1)||'?'||'server='||lv_server,'_blank');
      end if;   
   end if;  
END;*/
```

#### SP-003 - CALL_REPORT_PR_PHY

**Invoked From:**

- pt_phy_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

PART DETAILS (N/A / CN_MAIN)

---

**Purpose**

Generates and delivers the Physical Parts Report (pr_phy_pdf) from the Part Details screen. When triggered by a button press, the procedure prompts the user to choose between PDF viewing and character-mode printing. It configures the Oracle Reports object with the supplied invoice and dealer context parameters, submits the report to the configured report server, and either streams the output to the browser as a PDF or routes it to a printer via GENERAL.PROC_REPORT_CALL, storing the resulting report handle and print output in global variables for downstream timer-based processing via GENERAL.PROC_TIMER.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_parent | VARCHAR2 | IN |
| p_dealer | VARCHAR2 | IN |
| p_loc | VARCHAR2 | IN |
| p_comp_fa | VARCHAR2 | IN |
| p_inv_num | VARCHAR2 | IN |
| p_inv_date | DATE | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.PROC_REPORT_CALL ([SP-023](#SP-023--GENERAL.PROC_REPORT_CALL)) - matched by member name (package unresolved)
- GENERAL.PROC_TIMER ([SP-024](#SP-024--GENERAL.PROC_TIMER)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Locate the Oracle Forms report object named 'REPORT_CALL' using FIND_REPORT_OBJECT and initialise the target report filename to 'pr_phy_pdf'.
- Step 2 - Retrieve the alert object 'AL_REPORT' using FIND_ALERT and display it to the user via SHOW_ALERT to capture the user's delivery-mode selection.
- Step 3 - Evaluate the alert response to determine the requested output mode (PDF browser view, character-mode print, or cancel).
- Step 4 (PDF path) - If the user selects Button 1 (PDF): set the report destination format to 'PDF'; build the report parameter string from p_parent, p_comp_fa, p_dealer (cast to NUMBER), p_loc, p_inv_num, and p_inv_date, appending REPORT_DESTYPE=FILE, MODE=BITMAP, and BLANKPAGES=NO; assign the global report server (GLOBAL.rep_server) and the report filename to the report object; execute the report via RUN_REPORT_OBJECT; and open the generated PDF in a new browser window using WEB.SHOW_DOCUMENT, constructing the URL from the rwservlet getjobid endpoint and the returned job identifier.
- Step 5 (Print path) - If the user selects Button 2 (Print): reset the report filename to 'pr_phy_pdf'; set the destination format to 'wided'; build the parameter string with the same context values, appending REPORT_DESTYPE=PRINTER, MODE=CHARACTER, and BLANKPAGES=NO; assign the report server; invoke GENERAL.PROC_REPORT_CALL passing the report object and output variables lv_report and lv_print; store the returned values in GLOBAL.reporthandle and GLOBAL.printoutput respectively; then call GENERAL.PROC_TIMER to initiate timer-based monitoring of the print job.
- Step 6 (Cancel path) - If the user selects any other alert button, clear any pending form messages via CLEAR_MESSAGE and exit without generating a report.

---
**Decision Points**

DP-001

Condition: The alert response equals ALERT_BUTTON1 (user selects PDF / browser view).

TRUE: Configure the report object for PDF bitmap output, pass all invoice and dealer parameters, run the report on the server, and display the resulting document in a new browser tab via WEB.SHOW_DOCUMENT.

FALSE: Proceed to evaluate DP-002.

DP-002

Condition: The alert response equals ALERT_BUTTON2 (user selects character-mode print).

TRUE: Configure the report object for character-mode printer output, pass all invoice and dealer parameters, delegate execution to GENERAL.PROC_REPORT_CALL, persist the report handle and print output in global variables, and start the print-job timer via GENERAL.PROC_TIMER.

FALSE: The user cancelled the action; CLEAR_MESSAGE is called and no report is generated.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The report server must be pre-populated in the global variable GLOBAL.rep_server before this procedure is invoked; the value is read at declaration time and applied to the report object for both output modes.
- BR-002 - The dealer identifier (p_dealer) must be convertible to a NUMBER; it is explicitly cast via TO_NUMBER when building the report parameter string for both PDF and print paths.
- BR-003 - Blank pages are suppressed in all output modes; BLANKPAGES=NO is appended to the report parameter string regardless of the selected delivery format.
- BR-004 - PDF output is rendered in BITMAP mode and delivered as a FILE destination, while print output is rendered in CHARACTER mode and directed to a PRINTER destination; the two modes are mutually exclusive and determined solely by the user's alert selection.
- BR-005 - For print-mode execution, the report handle and print output returned by GENERAL.PROC_REPORT_CALL are stored in GLOBAL.reporthandle and GLOBAL.printoutput respectively, making them available to subsequent form-level processing.
- BR-006 - Following a successful print submission, GENERAL.PROC_TIMER is invoked to manage asynchronous monitoring of the print job; this call is mandatory for the print path and does not apply to the PDF path.
- BR-007 - If the user dismisses the alert without selecting PDF or Print, the procedure takes no reporting action and clears any outstanding form messages, ensuring the screen is left in a clean state.

---
**Implementation Logic**

```plsql
PROCEDURE call_report_pr_phy (
      p_parent                         VARCHAR2,
      p_dealer                         VARCHAR2,
      p_loc                            VARCHAR2,
      p_comp_fa                        VARCHAR2,
      p_inv_num                        VARCHAR2,
      p_inv_date                       DATE)
IS
      repid            report_object;
      lv_rep           VARCHAR2 (100);
      lv_report_name   VARCHAR2 (50);
      lv_server        VARCHAR2 (20)   := :GLOBAL.rep_server;
      lv_alert         VARCHAR2 (20);
      l_v_param        VARCHAR2 (50);
      l_alertid        alert;
      lv_param         VARCHAR2 (100);
      lv_report        VARCHAR2 (2000);
      lv_print         VARCHAR2 (2000);
BEGIN
      --Checking The Alert Button
      repid := FIND_REPORT_OBJECT ('REPORT_CALL');
      lv_report_name := 'pr_phy_pdf';
      l_alertid := FIND_ALERT ('AL_REPORT');
      lv_alert := SHOW_ALERT (l_alertid);
-- general.disp_text('INSIDE  PROC 1 ','NOTE');
      IF lv_alert = alert_button1 THEN
            -- Clear_Message;
            SET_REPORT_OBJECT_PROPERTY (repid, report_desformat, 'PDF');
            SET_REPORT_OBJECT_PROPERTY (repid,
                                        report_other,
                                        'P_PARENT=' || p_parent || ' P_COMP_FA=' || p_comp_fa || ' P_DEALER='
                                        || TO_NUMBER (p_dealer) || ' P_LOC=' || p_loc || ' P_INV_NUM=' || p_inv_num
                                        || ' P_INV_DATE=' || p_inv_date || ' REPORT_DESTYPE =FILE' || ' MODE=BITMAP BLANKPAGES=NO');
--general.disp_text('INSIDE  PROC 2 ','NOTE');
            SET_REPORT_OBJECT_PROPERTY (repid, report_server, lv_server);
            SET_REPORT_OBJECT_PROPERTY (repid, report_filename, lv_report_name);
            lv_rep := RUN_REPORT_OBJECT (repid);
            web.show_document ('/reports/rwservlet/getjobid' || SUBSTR (lv_rep, INSTR (lv_rep, '_', -1) + 1) || '?' || 'server='
                               || lv_server,
                               '_blank');
      ELSIF lv_alert = alert_button2 THEN
            lv_report_name := 'pr_phy_pdf';
            SET_REPORT_OBJECT_PROPERTY (repid, report_filename, lv_report_name);
            /* code for character begin */
            SET_REPORT_OBJECT_PROPERTY (repid, report_desformat, 'wided');
            SET_REPORT_OBJECT_PROPERTY (repid,
                                        report_other,
                                        'P_PARENT=' || p_parent || ' P_COMP_FA=' || p_comp_fa || ' P_DEALER='
                                        || TO_NUMBER (p_dealer) || ' P_LOC=' || p_loc || ' P_INV_NUM=' || p_inv_num
                                        || ' P_INV_DATE=' || p_inv_date || ' REPORT_DESTYPE =PRINTER'
                                        || '  MODE=CHARACTER BLANKPAGES=NO');
            SET_REPORT_OBJECT_PROPERTY (repid, report_server, lv_server);
            general.proc_report_call (repid, lv_report, lv_print);
            :GLOBAL.reporthandle := lv_report;
            :GLOBAL.printoutput := lv_print;
            general.proc_timer;
      ELSE
            CLEAR_MESSAGE;
      END IF;
END;
```

#### SP-004 - CHK_DUP

**Invoked From:**

- pt_phy_fmb.xml [Trigger: FT_SAVE]

---

**Screen:**

ADJUSTMENT DETAILS (N/A / CN_ADJ); COUNT DETAILS (N/A / CN_MAIN); PART DETAILS (N/A / CN_MAIN)

---

**Purpose**

CHK_DUP validates that no two rows in a given Oracle Forms block contain identical values across a specified set of one to six item (column) names. When a duplicate combination is detected, an error message identifying the duplicate label and the offending line number is appended to the populate_errors.v_tab collection for later display. The procedure is invoked during the FT_SAVE trigger on the Adjustment Details, Count Details, and Part Details screens to prevent duplicate entries from being committed.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| v_dup_str | VARCHAR2 | IN |
| v_col1 | VARCHAR2 | IN |
| v_col2 | VARCHAR2 | IN |
| v_col3 | VARCHAR2 | IN |
| v_col4 | VARCHAR2 | IN |
| v_col5 | VARCHAR2 | IN |
| v_col6 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Navigate to the first form item supplied in v_col1 and move to the first record in the block, establishing the starting position for the outer traversal loop.
- Step 2 - Capture the current record number (l_rec_no) and read the value of v_col1 into l_val1 for the anchor record.
- Step 3 - For each optional column parameter (v_col2 through v_col6) that is not NULL, read the corresponding form item value into the matching local variable (l_val2 through l_val6).
- Step 4 - Enter an inner loop that iterates over every other record in the block. For each inner record whose record number differs from l_rec_no, compare the anchor record's captured values against the current inner record's live item values using NVL-padded equality, applying only the columns that were supplied (determined by which of v_col2 through v_col6 are not NULL).
- Step 5 - If all compared column values match, append a duplicate error message in the format 'Duplicate <v_dup_str> on Line No. <current record number>' to the populate_errors.v_tab collection.
- Step 6 - Advance the inner loop to the next record; exit the inner loop when SYSTEM.LAST_RECORD is TRUE.
- Step 7 - Return navigation to the anchor record (l_rec_no), then advance the outer loop to the next record; exit the outer loop when SYSTEM.LAST_RECORD is TRUE, completing the full pairwise comparison.

---
**Decision Points**

DP-001

Condition: The current inner-loop record number is different from the anchor record number (NAME_IN('SYSTEM.CURSOR_RECORD') <> l_rec_no).

TRUE: Proceed to compare the column values of the two records for a potential duplicate.

FALSE: Skip comparison; a record is never compared against itself.

---

DP-002

Condition: v_col6 IS NOT NULL.

TRUE: Perform a six-column equality comparison (v_col1 through v_col6) between the anchor and inner records.

FALSE: Fall through to evaluate v_col5.

---

DP-003

Condition: v_col5 IS NOT NULL (evaluated only when v_col6 IS NULL).

TRUE: Perform a five-column equality comparison (v_col1 through v_col5).

FALSE: Fall through to evaluate v_col4.

---

DP-004

Condition: v_col4 IS NOT NULL (evaluated only when v_col5 and v_col6 are NULL).

TRUE: Perform a four-column equality comparison (v_col1 through v_col4).

FALSE: Fall through to evaluate v_col3.

---

DP-005

Condition: v_col3 IS NOT NULL (evaluated only when v_col4, v_col5, and v_col6 are NULL).

TRUE: Perform a three-column equality comparison (v_col1 through v_col3).

FALSE: Fall through to evaluate v_col2.

---

DP-006

Condition: v_col2 IS NOT NULL (evaluated only when v_col3 through v_col6 are NULL).

TRUE: Perform a two-column equality comparison (v_col1 and v_col2).

FALSE: Perform a single-column equality comparison on v_col1 alone.

---

DP-007

Condition: The NVL-padded values of all active comparison columns are equal between the anchor record and the inner record.

TRUE: Append a duplicate error entry to populate_errors.v_tab identifying the duplicate label (v_dup_str) and the offending line number.

FALSE: No error is recorded; processing continues to the next inner record.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Duplicate detection is performed in-form, across all records currently loaded in the block, before any save operation is committed; the procedure is triggered by FT_SAVE.
- BR-002 - The key used for duplicate comparison is defined dynamically by the caller: a minimum of one (v_col1) and a maximum of six (v_col1 through v_col6) Oracle Forms block item names may be supplied; only non-NULL column parameters participate in the comparison.
- BR-003 - Column value comparison is performed using NVL substitution (defaulting NULL to a single space), ensuring that two records where all active key columns are NULL are treated as duplicates of each other.
- BR-004 - A record is never compared against itself; only pairs where the record numbers differ are evaluated.
- BR-005 - When a duplicate is found, the error message must follow the format 'Duplicate <v_dup_str> on Line No. <line number>', where v_dup_str is the caller-supplied label identifying the duplicated entity and the line number is the current SYSTEM.CURSOR_RECORD value of the offending record.
- BR-006 - All duplicate error messages are accumulated in the populate_errors.v_tab collection rather than raised immediately, allowing all duplicates across the block to be reported in a single pass.

---
**Implementation Logic**

```plsql
/* ------------ It Checks For Duplicate Records in a given Block.item_name ------------------ */

--FUNCTION 

PROCEDURE chk_dup (
      v_dup_str   VARCHAR2,
      v_col1      VARCHAR2,
      v_col2      VARCHAR2 DEFAULT NULL,
      v_col3      VARCHAR2 DEFAULT NULL,
      v_col4      VARCHAR2 DEFAULT NULL,
      v_col5      VARCHAR2 DEFAULT NULL,
      v_col6      VARCHAR2 DEFAULT NULL
)

IS
      l_val1      VARCHAR2 (100);
      l_val2      VARCHAR2 (100);
      l_val3      VARCHAR2 (100);
      l_val4      VARCHAR2 (100);
      l_val5      VARCHAR2 (100);
      l_val6      VARCHAR2 (100);
      l_cur_itm   VARCHAR2 (70)  := NAME_IN ('SYSTEM.CURSOR_ITEM');
      l_rec_no    NUMBER;
      l_counter   NUMBER         := 1;
BEGIN
      GO_ITEM (v_col1);
      FIRST_RECORD;

      LOOP
            l_rec_no := NAME_IN ('SYSTEM.CURSOR_RECORD');
            l_val1 := NAME_IN (v_col1);

           
            IF v_col2 IS NOT NULL THEN
                  l_val2 := NAME_IN (v_col2);
            END IF;

            IF v_col3 IS NOT NULL THEN
                  l_val3 := NAME_IN (v_col3);
            END IF;

            IF v_col4 IS NOT NULL THEN
                  l_val4 := NAME_IN (v_col4);
            END IF;

            IF v_col5 IS NOT NULL THEN
                  l_val5 := NAME_IN (v_col5);
            END IF;

            IF v_col6 IS NOT NULL THEN
                  l_val6 := NAME_IN (v_col6);
            END IF;

          
            LOOP
                  IF NAME_IN ('SYSTEM.CURSOR_RECORD') <> l_rec_no THEN
                        IF v_col6 IS NOT NULL THEN
                              IF     NVL ( l_val1, ' ') = NVL (NAME_IN (v_col1), ' ')
                                 AND NVL ( l_val2, ' ') = NVL (NAME_IN (v_col2), ' ')
                                 AND NVL ( l_val3, ' ') = NVL (NAME_IN (v_col3), ' ')
                                 AND NVL ( l_val4, ' ') = NVL (NAME_IN (v_col4), ' ')
                                 AND NVL ( l_val5, ' ') = NVL (NAME_IN (v_col5), ' ')
                                 AND NVL ( l_val6, ' ') = NVL (NAME_IN (v_col6), ' ') THEN
                                   
                                    populate_errors.v_tab (populate_errors.v_tab.COUNT + 1) :=
                                             'Duplicate '
                                          || v_dup_str
                                          || ' '
                                          --|| sf_get_store_name (:GLOBAL.dealer, :GLOBAL.loc_cd, :SYSTEM.cursor_value)
                                          || ' on Line No. '
                                          || :SYSTEM.cursor_record;
                              END IF;
                        ELSIF v_col5 IS NOT NULL THEN
                              IF     NVL ( l_val1, ' ') = NVL (NAME_IN (v_col1), ' ')
                                 AND NVL ( l_val2, ' ') = NVL (NAME_IN (v_col2), ' ')
                                 AND NVL ( l_val3, ' ') = NVL (NAME_IN (v_col3), ' ')
                                 AND NVL ( l_val4, ' ') = NVL (NAME_IN (v_col4), ' ')
                                 AND NVL ( l_val5, ' ') = NVL (NAME_IN (v_col5), ' ') THEN
                                   
                                    populate_errors.v_tab (populate_errors.v_tab.COUNT + 1) :=
                                             'Duplicate '
                                          || v_dup_str
                                          || ' '
                                          --|| sf_get_store_name (:GLOBAL.dealer, :GLOBAL.loc_cd, :SYSTEM.cursor_value)
                                          || ' on Line No. '
                                          || :SYSTEM.cursor_record;
                              END IF;
                        ELSIF v_col4 IS NOT NULL THEN
                              IF     NVL ( l_val1, ' ') = NVL (NAME_IN (v_col1), ' ')
                                 AND NVL ( l_val2, ' ') = NVL (NAME_IN (v_col2), ' ')
                                 AND NVL ( l_val3, ' ') = NVL (NAME_IN (v_col3), ' ')
                                 AND NVL ( l_val4, ' ') = NVL (NAME_IN (v_col4), ' ') THEN
                                    
                                    populate_errors.v_tab (populate_errors.v_tab.COUNT + 1) :=
                                             'Duplicate '
                                          || v_dup_str
                                          || ' '
                                          --|| sf_get_store_name (:GLOBAL.dealer, :GLOBAL.loc_cd, :SYSTEM.cursor_value)
                                          || ' on Line No. '
                                          || :SYSTEM.cursor_record;
                              END IF;
                        ELSIF v_col3 IS NOT NULL THEN
                              IF     NVL ( l_val1, ' ') = NVL (NAME_IN (v_col1), ' ')
                                 AND NVL ( l_val2, ' ') = NVL (NAME_IN (v_col2), ' ')
                                 AND NVL ( l_val3, ' ') = NVL (NAME_IN (v_col3), ' ') THEN
                                    
                                    populate_errors.v_tab (populate_errors.v_tab.COUNT + 1) :=
                                             'Duplicate '
                                          || v_dup_str
                                          || ' '
                                          --|| sf_get_store_name (:GLOBAL.dealer, :GLOBAL.loc_cd, :SYSTEM.cursor_value)
                                          || ' on Line No. '
                                          || :SYSTEM.cursor_record;
                              END IF;
                        ELSIF v_col2 IS NOT NULL THEN
                              IF NVL ( l_val1, ' ') = NVL (NAME_IN (v_col1), ' ')
                                 AND NVL (l_val2, ' ') = NVL (NAME_IN (v_col2), ' ') THEN
                                    
                                    populate_errors.v_tab (populate_errors.v_tab.COUNT + 1) :=
                                             'Duplicate '
                                          || v_dup_str
                                          || ' '
                                          --|| sf_get_store_name (:GLOBAL.dealer, :GLOBAL.loc_cd, :SYSTEM.cursor_value)
                                          || ' on Line No. '
                                          || :SYSTEM.cursor_record;
                              END IF;
                        ELSE
                              IF NVL ( l_val1, ' ') = NVL (NAME_IN (v_col1), ' ') THEN
                                    
                                    populate_errors.v_tab (populate_errors.v_tab.COUNT + 1) :=
                                        
                                          'Duplicate '
                                          || v_dup_str
                                          || ' '
                                          --|| sf_get_store_name (:GLOBAL.dealer, :GLOBAL.loc_cd, :SYSTEM.cursor_value)
                                          || ' on Line No. '
                                          || :SYSTEM.cursor_record;
                              END IF;
                        END IF;
                  END IF;

                  EXIT WHEN NAME_IN ('SYSTEM.LAST_RECORD') = 'TRUE';
                  NEXT_RECORD;
            END LOOP;

            l_counter := l_counter + 1;
            GO_RECORD (l_rec_no);
            EXIT WHEN NAME_IN ('SYSTEM.LAST_RECORD') = 'TRUE';
            NEXT_RECORD;
      END LOOP;

END chk_dup;
```

#### SP-005 - ENABLE_HEADER

**Invoked From:**

- pt_phy_fmb.xml [Trigger: KEY-CLRFRM]
- pt_phy_fmb.xml [Trigger: KEY-NEXT-ITEM]

---

**Screen:**

ADJUSTMENT DETAILS (N/A / CN_ADJ); COUNT DETAILS (N/A / CN_MAIN)

---

**Purpose**

Controls the interactive state of all filter and search criteria fields in the PH_INVENTORY block. When called with p_flag = TRUE (the default), the procedure enables and makes navigable all thirteen header filter items so the user can enter query criteria; when called with p_flag = FALSE it disables and removes those same items from tab-order navigation, preventing user input. The procedure is triggered on form-clear (KEY-CLRFRM) and next-item (KEY-NEXT-ITEM) events to keep the header field states consistent with the current operational context.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_flag | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the boolean flag p_flag (defaults to TRUE if not supplied by the caller).
- Step 2 - Evaluate p_flag to determine the target enabled/navigable state for all PH_INVENTORY header items.
- Step 3 - If p_flag is TRUE, set the ENABLED and NAVIGABLE properties of each of the following PH_INVENTORY items to PROPERTY_TRUE: catg_cd, abc_ind, fsn_ind, xyz_ind, mcat_cd, price, greater_than, less_than, part_number, to_part_number, bin_loc_from, bin_loc_to, and order_by - making all thirteen fields interactive and reachable via keyboard navigation.
- Step 4 - If p_flag is FALSE, set the ENABLED and NAVIGABLE properties of the same thirteen items to PROPERTY_FALSE - locking all fields against user input and removing them from the tab-order.
- Step 5 - Procedure completes; no return value is produced.

---
**Decision Points**

DP-001

Condition:
p_flag IS TRUE (boolean input parameter evaluates to TRUE)

TRUE:
All thirteen PH_INVENTORY header filter items (catg_cd, abc_ind, fsn_ind, xyz_ind, mcat_cd, price, greater_than, less_than, part_number, to_part_number, bin_loc_from, bin_loc_to, order_by) are set to ENABLED = PROPERTY_TRUE and NAVIGABLE = PROPERTY_TRUE, allowing user interaction and keyboard navigation.

FALSE:
All thirteen PH_INVENTORY header filter items are set to ENABLED = PROPERTY_FALSE and NAVIGABLE = PROPERTY_FALSE, preventing user interaction and excluding the fields from keyboard navigation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - All thirteen PH_INVENTORY header filter fields (catg_cd, abc_ind, fsn_ind, xyz_ind, mcat_cd, price, greater_than, less_than, part_number, to_part_number, bin_loc_from, bin_loc_to, order_by) must be enabled and navigable together as a unit; the procedure does not permit selective activation of individual fields.
- BR-002 - The enabled state and the navigable state of each header field must always be set in tandem; a field must not be enabled without also being navigable, and vice versa.
- BR-003 - The default state for p_flag is TRUE, meaning that unless explicitly disabled by the caller, the header fields are activated upon invocation.
- BR-004 - On a form-clear event (KEY-CLRFRM) and on a next-item event (KEY-NEXT-ITEM), the header field states must be explicitly re-applied to ensure consistency with the current screen context.

---
**Implementation Logic**

```plsql
Procedure enable_header (p_flag BOOLEAN DEFAULT TRUE)
IS
BEGIN
      IF p_flag THEN
            SET_ITEM_PROPERTY ('PH_INVENTORY.catg_cd', enabled, property_true);
            SET_ITEM_PROPERTY ('PH_INVENTORY.catg_cd', navigable, property_true);
            SET_ITEM_PROPERTY ('PH_INVENTORY.abc_ind', enabled, property_true);
            SET_ITEM_PROPERTY ('PH_INVENTORY.abc_ind', navigable, property_true);
            SET_ITEM_PROPERTY ('PH_INVENTORY.fsn_ind', enabled, property_true);
            SET_ITEM_PROPERTY ('PH_INVENTORY.fsn_ind', navigable, property_true);
            SET_ITEM_PROPERTY ('PH_INVENTORY.xyz_ind', enabled, property_true);
            SET_ITEM_PROPERTY ('PH_INVENTORY.xyz_ind', navigable, property_true);
            SET_ITEM_PROPERTY ('PH_INVENTORY.mcat_cd', enabled, property_true);
            SET_ITEM_PROPERTY ('PH_INVENTORY.mcat_cd', navigable, property_true);
            SET_ITEM_PROPERTY ('PH_INVENTORY.price', enabled, property_true);
            SET_ITEM_PROPERTY ('PH_INVENTORY.price', navigable, property_true);
            SET_ITEM_PROPERTY ('PH_INVENTORY.greater_than', enabled, property_true);
            SET_ITEM_PROPERTY ('PH_INVENTORY.greater_than', navigable, property_true);
            SET_ITEM_PROPERTY ('PH_INVENTORY.less_than', enabled, property_true);
            SET_ITEM_PROPERTY ('PH_INVENTORY.less_than', navigable, property_true);
            SET_ITEM_PROPERTY ('PH_INVENTORY.part_number', enabled, property_true);
            SET_ITEM_PROPERTY ('PH_INVENTORY.part_number', navigable, property_true);
            SET_ITEM_PROPERTY ('PH_INVENTORY.to_part_number', enabled, property_true);
            SET_ITEM_PROPERTY ('PH_INVENTORY.to_part_number', navigable, property_true);
            SET_ITEM_PROPERTY ('PH_INVENTORY.bin_loc_from', enabled, property_true);
            SET_ITEM_PROPERTY ('PH_INVENTORY.bin_loc_from', navigable, property_true);
            SET_ITEM_PROPERTY ('PH_INVENTORY.bin_loc_to', enabled, property_true);
            SET_ITEM_PROPERTY ('PH_INVENTORY.bin_loc_to', navigable, property_true);
            SET_ITEM_PROPERTY ('PH_INVENTORY.order_by', enabled, property_true);
            SET_ITEM_PROPERTY ('PH_INVENTORY.order_by', navigable, property_true);
      ELSE
            SET_ITEM_PROPERTY ('PH_INVENTORY.catg_cd', enabled, property_false);
            SET_ITEM_PROPERTY ('PH_INVENTORY.catg_cd', navigable, property_false);
            SET_ITEM_PROPERTY ('PH_INVENTORY.abc_ind', enabled, property_false);
            SET_ITEM_PROPERTY ('PH_INVENTORY.abc_ind', navigable, property_false);
            SET_ITEM_PROPERTY ('PH_INVENTORY.fsn_ind', enabled, property_false);
            SET_ITEM_PROPERTY ('PH_INVENTORY.fsn_ind', navigable, property_false);
            SET_ITEM_PROPERTY ('PH_INVENTORY.xyz_ind', enabled, property_false);
            SET_ITEM_PROPERTY ('PH_INVENTORY.xyz_ind', navigable, property_false);
            SET_ITEM_PROPERTY ('PH_INVENTORY.mcat_cd', enabled, property_false);
            SET_ITEM_PROPERTY ('PH_INVENTORY.mcat_cd', navigable, property_false);
            SET_ITEM_PROPERTY ('PH_INVENTORY.price', enabled, property_false);
            SET_ITEM_PROPERTY ('PH_INVENTORY.price', navigable, property_false);
            SET_ITEM_PROPERTY ('PH_INVENTORY.greater_than', enabled, property_false);
            SET_ITEM_PROPERTY ('PH_INVENTORY.greater_than', navigable, property_false);
            SET_ITEM_PROPERTY ('PH_INVENTORY.less_than', enabled, property_false);
            SET_ITEM_PROPERTY ('PH_INVENTORY.less_than', navigable, property_false);
            SET_ITEM_PROPERTY ('PH_INVENTORY.part_number', enabled, property_false);
            SET_ITEM_PROPERTY ('PH_INVENTORY.part_number', navigable, property_false);
            SET_ITEM_PROPERTY ('PH_INVENTORY.to_part_number', enabled, property_false);
            SET_ITEM_PROPERTY ('PH_INVENTORY.to_part_number', navigable, property_false);
            SET_ITEM_PROPERTY ('PH_INVENTORY.bin_loc_from', enabled, property_false);
            SET_ITEM_PROPERTY ('PH_INVENTORY.bin_loc_from', navigable, property_false);
            SET_ITEM_PROPERTY ('PH_INVENTORY.bin_loc_to', enabled, property_false);
            SET_ITEM_PROPERTY ('PH_INVENTORY.bin_loc_to', navigable, property_false);
            SET_ITEM_PROPERTY ('PH_INVENTORY.order_by', enabled, property_false);
            SET_ITEM_PROPERTY ('PH_INVENTORY.order_by', navigable, property_false);
      END IF;
END;
```

#### SP-006 - ENABLE_POP_BTN

**Invoked From:**

- pt_phy_fmb.xml [Trigger: KEY-NEXT-ITEM]
- pt_phy_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

COUNT DETAILS (N/A / CN_MAIN)

---

**Purpose**

Controls the enabled and navigable state of the Fetch button (BT_FETCH) on the COUNT DETAILS screen. The button is activated only when the operator has supplied a complete part-number range or a complete bin-location range, ensuring that a population query cannot be launched without valid search boundaries.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate whether both PART_NUMBER and TO_PART_NUM are populated in the PH_INVENTORY block, OR whether both BIN_LOC_FROM and BIN_LOC_TO are populated in the same block.
- Step 2 - If either range pair is fully populated (TRUE branch), set the BT_FETCH button property ENABLED to TRUE and NAVIGABLE to TRUE, making the button interactive and reachable via keyboard navigation.
- Step 3 - If neither range pair is fully populated (FALSE branch), set the BT_FETCH button property ENABLED to FALSE, preventing the operator from invoking the fetch action.

---
**Decision Points**

DP-001

Condition:
(:PH_INVENTORY.PART_NUMBER IS NOT NULL AND :PH_INVENTORY.TO_PART_NUM IS NOT NULL) OR (:PH_INVENTORY.BIN_LOC_FROM IS NOT NULL AND :PH_INVENTORY.BIN_LOC_TO IS NOT NULL)

TRUE:
Set PH_INVENTORY.BT_FETCH ENABLED = TRUE and NAVIGABLE = TRUE, activating the Fetch button for operator use.

FALSE:
Set PH_INVENTORY.BT_FETCH ENABLED = FALSE and leave NAVIGABLE unchanged, preventing the operator from triggering a fetch until a valid range is entered.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A complete part-number range requires both PART_NUMBER (from) and TO_PART_NUM (to) to be non-null; a partial entry is insufficient to enable the Fetch button.
- BR-002 - A complete bin-location range requires both BIN_LOC_FROM and BIN_LOC_TO to be non-null; a partial entry is insufficient to enable the Fetch button.
- BR-003 - Satisfying either the part-number range condition or the bin-location range condition is sufficient to enable the Fetch button; both conditions do not need to be met simultaneously.
- BR-004 - When the Fetch button is enabled it must also be set to navigable, ensuring keyboard-only operators can reach and invoke it.
- BR-005 - This procedure is evaluated on every KEY-NEXT-ITEM and WHEN-VALIDATE-ITEM trigger firing, guaranteeing the button state is kept current as the operator moves between fields.

---
**Implementation Logic**

```plsql
PROCEDURE enable_pop_btn IS
BEGIN
  if (:PH_INVENTORY.part_number is not null and :PH_INVENTORY.to_part_num is not null) or 
  	(:PH_INVENTORY.bin_loc_from is not null and :PH_INVENTORY.bin_loc_to is not null) then
  	set_item_property('PH_INVENTORY.bt_fetch',enabled, property_true);
  	set_item_property('PH_INVENTORY.bt_fetch',navigable, property_true);
  else
  	set_item_property('PH_INVENTORY.bt_fetch',enabled, property_false);
  	end if;
END;
```

#### SP-007 - STOCK_UPDATE_EXCEPTION

**Invoked From:**

- pt_phy_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

ADJUSTMENT DETAILS (N/A / CN_ADJ)

---

**Purpose**

Centralises error-handling for all stock-update operations on the Adjustment Details screen (CN_ADJ). When a back-end stock-update routine raises a user-defined Oracle exception, this procedure receives the SQLCODE and the affected part number, maps the code to a precise, human-readable message, and displays it to the operator via GENERAL.DISP_TEXT before re-raising FORM_TRIGGER_FAILURE to halt the calling trigger.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| SQLCODE | NUMBER | IN |
| part_num | pm_part.part_num%TYPE | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-021](#SP-021--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Oracle SQLCODE and the affected part number (part_num) as input parameters from the calling WHEN-BUTTON-PRESSED trigger in pt_phy_fmb.xml.
- Step 2 - Evaluate SQLCODE against a prioritised chain of ELSIF conditions covering user-defined error codes -20020 through -20072 and -20051 through -20064 (see Decision Points).
- Step 3 - For the matched SQLCODE, compose a descriptive error message that identifies the failed operation category (e.g., inserting part details, fetching stock, updating receipt, updating kit) and appends the part number and, where available, SQLERRM for additional Oracle context.
- Step 4 - Invoke GENERAL.DISP_TEXT (SP-021) with the composed message and severity label 'Error' to present the error to the operator on screen.
- Step 5 - If no specific SQLCODE matches, invoke GENERAL.DISP_TEXT with the generic message 'Stock update failed-' concatenated with the part number.
- Step 6 - After the GENERAL.DISP_TEXT call (regardless of which branch executed), raise FORM_TRIGGER_FAILURE to abort the current form trigger.
- Step 7 - The EXCEPTION block catches FORM_TRIGGER_FAILURE and immediately re-raises it, ensuring the failure propagates cleanly to the calling trigger without performing a rollback.

---
**Decision Points**

DP-001

Condition:
SQLCODE = -20020

TRUE:
Display 'Width problem/Incompatible Data while inserting Part details-<part_num>' as an Error via GENERAL.DISP_TEXT.

FALSE:
Evaluate next condition (DP-002).

---

DP-002

Condition:
SQLCODE = -20021

TRUE:
Display 'Execution failed while inserting Part details-<part_num>' as an Error.

FALSE:
Evaluate next condition (DP-003).

---

DP-003

Condition:
SQLCODE = -20022

TRUE:
Display 'Record is being used by another user.try again later-<part_num>' as an Error.

FALSE:
Evaluate next condition (DP-004).

---

DP-004

Condition:
SQLCODE = -20023

TRUE:
Display 'More than one part details found-<part_num>' as an Error.

FALSE:
Evaluate next condition (DP-005).

---

DP-005

Condition:
SQLCODE = -20024

TRUE:
Display 'Width problem/Incompatible Data while fetching Part detail-<SQLERRM>-<part_num>' as an Error.

FALSE:
Evaluate next condition (DP-006).

---

DP-006

Condition:
SQLCODE = -20025

TRUE:
Display 'Execution failed while fetching Part detail-<SQLERRM>-<part_num>' as an Error.

FALSE:
Evaluate next condition (DP-007).

---

DP-007

Condition:
SQLCODE = -20026

TRUE:
Display 'Width problem/Incompatible Data while inserting Stock details-<part_num>' as an Error.

FALSE:
Evaluate next condition (DP-008).

---

DP-008

Condition:
SQLCODE = -20027

TRUE:
Display 'Execution failed while inserting Stock details-<SQLERRM>-<part_num>' as an Error.

FALSE:
Evaluate next condition (DP-009).

---

DP-009

Condition:
SQLCODE = -20028

TRUE:
Display 'Stock Record is being used by another user.try again later-<part_num>' as an Error.

FALSE:
Evaluate next condition (DP-010).

---

DP-010

Condition:
SQLCODE = -20029

TRUE:
Display 'More than one stock details found for part-<part_num>' as an Error.

FALSE:
Evaluate next condition (DP-011).

---

DP-011

Condition:
SQLCODE = -20030

TRUE:
Display 'Width problem/Incompatible Data while fetching stock detail-<part_num>' as an Error.

FALSE:
Evaluate next condition (DP-012).

---

DP-012

Condition:
SQLCODE = -20031

TRUE:
Display 'Execution failed while fetching stock detail<SQLERRM>-<part_num>' as an Error.

FALSE:
Evaluate next condition (DP-013).

---

DP-013

Condition:
SQLCODE = -20032

TRUE:
Display 'Width problem/Incompatible Data while updating stock detail-<part_num>' as an Error.

FALSE:
Evaluate next condition (DP-014).

---

DP-014

Condition:
SQLCODE = -20033

TRUE:
Display 'Execution failed while updating stock detail-<part_num>' as an Error.

FALSE:
Evaluate next condition (DP-015).

---

DP-015

Condition:
SQLCODE = -20034

TRUE:
Display 'Width problem/Incompatible Data while updating float on hand quantity detail-<part_num>' as an Error.

FALSE:
Evaluate next condition (DP-016).

---

DP-016

Condition:
SQLCODE = -20035

TRUE:
Display 'Execution failed while updating float on hand quantity detail-<part_num>' as an Error.

FALSE:
Evaluate next condition (DP-017).

---

DP-017

Condition:
SQLCODE = -20036

TRUE:
Display 'Width problem/Incompatible Data while updating part on hand quantity detail-<part_num>' as an Error.

FALSE:
Evaluate next condition (DP-018).

---

DP-018

Condition:
SQLCODE = -20037

TRUE:
Display 'Execution failed while updating part on hand quantity detail-<part_num>' as an Error.

FALSE:
Evaluate next condition (DP-019).

---

DP-019

Condition:
SQLCODE = -20051

TRUE:
Display 'Part number not found--<part_num>' as an Error.

FALSE:
Evaluate next condition (DP-020).

---

DP-020

Condition:
SQLCODE = -20052

TRUE:
Display 'More than one Part detail found for-<part_num>' as an Error.

FALSE:
Evaluate next condition (DP-021).

---

DP-021

Condition:
SQLCODE = -20053

TRUE:
Display 'Width problem/Incompatible data while retrieving Part details-<part_num>' as an Error.

FALSE:
Evaluate next condition (DP-022).

---

DP-022

Condition:
SQLCODE = -20054

TRUE:
Display 'Execution failed while retrieving Part details-<part_num>-<SQLERRM>' as an Error.

FALSE:
Evaluate next condition (DP-023).

---

DP-023

Condition:
SQLCODE = -20055

TRUE:
Display 'Width problem/Incompatible data while updating Receipt details-<SQLERRM>-<part_num>' as an Error.

FALSE:
Evaluate next condition (DP-024).

---

DP-024

Condition:
SQLCODE = -20056

TRUE:
Display 'Trying to create duplicate data-<part_num>' as an Error (Receipt context).

FALSE:
Evaluate next condition (DP-025).

---

DP-025

Condition:
SQLCODE = -20057

TRUE:
Display 'Record is being used by another user, try again later-<part_num>' as an Error (Receipt context).

FALSE:
Evaluate next condition (DP-026).

---

DP-026

Condition:
SQLCODE = -20058

TRUE:
Display 'Execution failed while updating Receipt details-<SQLERRM><part_num>' as an Error.

FALSE:
Evaluate next condition (DP-027).

---

DP-027

Condition:
SQLCODE = -20065

TRUE:
Display 'Width problem/Incompatible data while updating Stock adjustment details-<part_num>' as an Error.

FALSE:
Evaluate next condition (DP-028).

---

DP-028

Condition:
SQLCODE = -20066

TRUE:
Display 'Trying to create duplicate data-<part_num>' as an Error (Stock adjustment context).

FALSE:
Evaluate next condition (DP-029).

---

DP-029

Condition:
SQLCODE = -20067

TRUE:
Display 'Record is being used by another user, try again later-<part_num>' as an Error (Stock adjustment context).

FALSE:
Evaluate next condition (DP-030).

---

DP-030

Condition:
SQLCODE = -20068

TRUE:
Display 'Execution failed while updating Stock adjustment details-<SQLERRM><part_num>' as an Error.

FALSE:
Evaluate next condition (DP-031).

---

DP-031

Condition:
SQLCODE = -20069

TRUE:
Display 'Width problem/Incompatible data while updating Kit details-<part_num>' as an Error.

FALSE:
Evaluate next condition (DP-032).

---

DP-032

Condition:
SQLCODE = -20070

TRUE:
Display 'Trying to create duplicate data-<part_num>' as an Error (Kit context).

FALSE:
Evaluate next condition (DP-033).

---

DP-033

Condition:
SQLCODE = -20071

TRUE:
Display 'Record is being used by another user, try again later-<part_num>' as an Error (Kit context).

FALSE:
Evaluate next condition (DP-034).

---

DP-034

Condition:
SQLCODE = -20072

TRUE:
Display 'Execution failed while updating Kit details-<SQLERRM><part_num>' as an Error.

FALSE:
Evaluate next condition (DP-035).

---

DP-035

Condition:
SQLCODE = -20059

TRUE:
Display 'Width problem/Incompatible data while inserting in PD_ALL_ISSUE table-<part_num>' as an Error.

FALSE:
Evaluate next condition (DP-036).

---

DP-036

Condition:
SQLCODE = -20060

TRUE:
Display 'Trying to create duplicate data-<part_num>' as an Error (PD_ALL_ISSUE context).

FALSE:
Evaluate next condition (DP-037).

---

DP-037

Condition:
SQLCODE = -20061

TRUE:
Display 'Record is being used by another user, try again later-<part_num>' as an Error (PD_ALL_ISSUE context).

FALSE:
Evaluate next condition (DP-038).

---

DP-038

Condition:
SQLCODE = -20062

TRUE:
Display 'Execution failed while inserting in PD_ALL_ISSUE table-<SQLERRM><part_num>' as an Error.

FALSE:
Evaluate next condition (DP-039).

---

DP-039

Condition:
SQLCODE = -20063

TRUE:
Display 'Stock not available as on date for the part-<part_num>' as an Error.

FALSE:
Evaluate next condition (DP-040).

---

DP-040

Condition:
SQLCODE = -20064

TRUE:
Display 'Receipts not available to issue for the part-<part_num>' as an Error.

FALSE:
No specific code matched; display generic 'Stock update failed-<part_num>' as an Error (ELSE branch).

---
**Database Interactions**

- DB-001 - Update FAILED - Updates existing rows in FAILED.
**Business Rules**

- BR-001 - Every user-defined exception code in the range -20020 to -20037 maps to a specific part-detail or stock-detail operation failure; the error message must identify the exact operation (insert, fetch, or update) and the affected part number.
- BR-002 - Exception codes -20024, -20025, -20027, -20031, -20054, -20055, -20058, -20062, -20068, and -20072 require SQLERRM to be appended to the error message to provide additional Oracle diagnostic context.
- BR-003 - Exception codes -20051 to -20054 cover part-retrieval failures (part not found, duplicate part, data-type mismatch, execution failure); the part number must always be included in the displayed message.
- BR-004 - Exception codes -20055 to -20058 cover receipt-update failures; duplicate-data (-20056) and record-lock (-20057) conditions must be reported distinctly from data-width (-20055) and execution (-20058) failures.
- BR-005 - Exception codes -20065 to -20068 cover stock-adjustment update failures; duplicate-data (-20066) and record-lock (-20067) conditions must be reported distinctly from data-width (-20065) and execution (-20068) failures.
- BR-006 - Exception codes -20069 to -20072 cover kit-detail update failures; duplicate-data (-20070) and record-lock (-20071) conditions must be reported distinctly from data-width (-20069) and execution (-20072) failures.
- BR-007 - Exception codes -20059 to -20062 cover PD_ALL_ISSUE insert failures; duplicate-data (-20060) and record-lock (-20061) conditions must be reported distinctly from data-width (-20059) and execution (-20062) failures.
- BR-008 - Exception code -20063 indicates that stock is not available as of the transaction date for the part; this must be reported as a distinct business condition, not a technical failure.
- BR-009 - Exception code -20064 indicates that no receipts are available to fulfil an issue for the part; this must be reported as a distinct business condition, not a technical failure.
- BR-010 - If the received SQLCODE does not match any defined user exception code, a generic 'Stock update failed' message concatenated with the part number must be displayed, ensuring no exception goes silently unhandled.
- BR-011 - After displaying the error message, FORM_TRIGGER_FAILURE must always be raised to abort the current form trigger, preventing any partial stock update from being committed.
- BR-012 - The EXCEPTION block must re-raise FORM_TRIGGER_FAILURE without performing a rollback, delegating transaction control to the calling trigger.

---
**Implementation Logic**

```plsql
PROCEDURE stock_update_exception (SQLCODE IN NUMBER, part_num IN pm_part.part_num%TYPE)
IS
BEGIN
      IF SQLCODE = -20020 THEN
            general.disp_text ('Width problem/Incompatible Data while inserting Part details-' || part_num, 'Error');
      ELSIF SQLCODE = -20021 THEN
            general.disp_text ('Execution failed while inserting Part details-' || part_num, 'Error');
      ELSIF SQLCODE = -20022 THEN
            general.disp_text ('Record is being used by another user.try again later-' || part_num, 'Error');
      ELSIF SQLCODE = -20023 THEN
            general.disp_text ('More than one part details found-' || part_num, 'Error');
      ELSIF SQLCODE = -20024 THEN
            general.disp_text ('Width problem/Incompatible Data while fetching Part detail-' || SQLERRM || '-' || part_num,
                               'Error'
                              );
      ELSIF SQLCODE = -20025 THEN
            general.disp_text ('Execution failed while  fetching Part detail-' || SQLERRM || '-' || part_num, 'Error');
      ELSIF SQLCODE = -20026 THEN
            general.disp_text ('Width problem/Incompatible Data while inserting Stock details-' || part_num, 'Error');
      ELSIF SQLCODE = -20027 THEN
            general.disp_text ('Execution failed while inserting Stock details-' || SQLERRM || '-' || part_num, 'Error');
      ELSIF SQLCODE = -20028 THEN
            general.disp_text ('Stock Record is being used by another user.try again later-' || part_num, 'Error');
      ELSIF SQLCODE = -20029 THEN
            general.disp_text ('More than one stock details found for part-' || part_num, 'Error');
      ELSIF SQLCODE = -20030 THEN
            general.disp_text ('Width problem/Incompatible Data while fetching stock detail-' || part_num, 'Error');
      ELSIF SQLCODE = -20031 THEN
            general.disp_text ('Execution failed while  fetching stock detail' || SQLERRM || '-' || part_num, 'Error');
      ELSIF SQLCODE = -20032 THEN
            general.disp_text ('Width problem/Incompatible Data while updating stock detail-' || part_num, 'Error');
      ELSIF SQLCODE = -20033 THEN
            general.disp_text ('Execution failed while  updating stock detail-' || part_num, 'Error');
      ELSIF SQLCODE = -20034 THEN
            general.disp_text ('Width problem/Incompatible Data while updating float on hand quantity detail-' || part_num,
                               'Error'
                              );
      ELSIF SQLCODE = -20035 THEN
            general.disp_text ('Execution failed while  updating float on hand quantity detail-' || part_num, 'Error');
      ELSIF SQLCODE = -20036 THEN
            general.disp_text ('Width problem/Incompatible Data while updating part on hand quantity detail-' || part_num,
                               'Error'
                              );
      ELSIF SQLCODE = -20037 THEN
            general.disp_text ('Execution failed while updating part on hand quantity detail-' || part_num, 'Error');
      ELSIF SQLCODE = -20051 THEN
            general.disp_text ('Part number not found-'|| '-' || part_num, 'Error');
      ELSIF SQLCODE = -20052 THEN
            general.disp_text ('More than one Part detail found for-' || part_num, 'Error');
      ELSIF SQLCODE = -20053 THEN
            general.disp_text ('Width problem/Incompatible data while retrieving Part details-' || part_num, 'Error');
      ELSIF SQLCODE = -20054 THEN
            general.disp_text ('Execution failed while retrieving Part details- ' || part_num ||'-'|| SQLERRM  , 'Error');
      ELSIF SQLCODE = -20055 THEN
            general.disp_text ('Width problem/Incompatible data while updating Receipt details-' || SQLERRM || '-' || part_num, 'Error');
      ELSIF SQLCODE = -20056 THEN
            general.disp_text ('Trying to create duplicate data-' || part_num, 'Error');
      ELSIF SQLCODE = -20057 THEN
            general.disp_text ('Record is being used by another user, try again later-' || part_num, 'Error');
      ELSIF SQLCODE = -20058 THEN
            general.disp_text ('Execution failed while updating Receipt details- ' || SQLERRM || part_num, 'Error');
      ELSIF SQLCODE = -20065 THEN
            general.disp_text ('Width problem/Incompatible data while updating Stock adjustment details-' || part_num, 'Error');
      ELSIF SQLCODE = -20066 THEN
            general.disp_text ('Trying to create duplicate data-' || part_num, 'Error');
      ELSIF SQLCODE = -20067 THEN
            general.disp_text ('Record is being used by another user, try again later-' || part_num, 'Error');
      ELSIF SQLCODE = -20068 THEN
            general.disp_text ('Execution failed while updating Stock adjustment details- ' || SQLERRM || part_num, 'Error');
      ELSIF SQLCODE = -20069 THEN
            general.disp_text ('Width problem/Incompatible data while updating Kit details-' || part_num, 'Error');
      ELSIF SQLCODE = -20070 THEN
            general.disp_text ('Trying to create duplicate data-' || part_num, 'Error');
      ELSIF SQLCODE = -20071 THEN
            general.disp_text ('Record is being used by another user, try again later-' || part_num, 'Error');
      ELSIF SQLCODE = -20072 THEN
            general.disp_text ('Execution failed while updating Kit details -' || SQLERRM || part_num, 'Error');
      ELSIF SQLCODE = -20059 THEN
            general.disp_text ('Width problem/Incompatible data while inserting in PD_ALL_ISSUE table-' || part_num, 'Error');
      ELSIF SQLCODE = -20060 THEN
            general.disp_text ('Trying to create duplicate data-' || part_num, 'Error');
      ELSIF SQLCODE = -20061 THEN
            general.disp_text ('Record is being used by another user, try again later-' || part_num, 'Error');
      ELSIF SQLCODE = -20062 THEN
            general.disp_text ('Execution failed while inserting in PD_ALL_ISSUE table- ' || SQLERRM || part_num, 'Error');
      ELSIF SQLCODE = -20063 THEN
            general.disp_text ('Stock not available as on date for the part- ' || part_num, 'Error');
      ELSIF SQLCODE = -20064 THEN
            general.disp_text ('Receipts not available to issue for the part- ' || part_num, 'Error');
      ELSE
            general.disp_text ('Stock update failed-' || part_num, 'Error');
      END IF;
	    --:parameter.p_err_flg:='Y';
      RAISE form_trigger_failure;
EXCEPTION
      WHEN form_trigger_failure THEN
            --ROLLBACK;
            RAISE form_trigger_failure;
END;
```

#### SP-008 - D2KWUTIL.ATTEMPT_DLL_LOAD

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Attempts to load a specified DLL into memory via ORA_FFI, optionally verifying the file's physical existence at a given path before loading. If a target path is supplied, the procedure normalises it and confirms the DLL file is accessible; it then loads the library and, when instructed, increments the module-level DLL load counter and marks the API as enabled. On any failure the API is flagged as disabled and a null library handle is returned, allowing the caller (REGISTER_FUNCTION_CALL) to handle the unavailable library gracefully.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |
| TargetDLL | VARCHAR2 | IN |
| LoadCount | BOOLEAN | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |

---

**Dependencies**

- DEBUGLOG ([SP-058](#SP-058--DEBUGLOG)) - matched by member name
- STRIPDIRSEP ([SP-075](#SP-075--STRIPDIRSEP)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Receive the target directory path (TargetPath, IN OUT), the DLL filename (TargetDLL), and a flag indicating whether the load counter should be incremented (LoadCount).
- Step 2 - If TargetPath is not null, normalise it by calling STRIPDIRSEP to remove any existing trailing directory separator, then append a single backslash ('\') to produce a clean, consistent path. This guards against callers supplying multiple or malformed path entries.
- Step 3 - Attempt to open the file at the constructed path (TargetPath || TargetDLL) in read mode using TEXT_IO.FOPEN to confirm the DLL physically exists at that location.
- Step 4 - If the file is opened successfully, close it immediately with TEXT_IO.FCLOSE; the open was purely a pre-load existence check.
- Step 5 - If the file cannot be opened, call DEBUGLOG (severity 99, context 'Attempt_DLL_LOAD') to record that the DLL was not found at the specified location, then raise the BadLocation exception to abort further processing.
- Step 6 - Call ORA_FFI.LOAD_LIBRARY with TargetPath and TargetDLL to load the DLL and obtain a library handle (hDLL).
- Step 7 - If LoadCount is TRUE, increment the module-level DLL_LOAD_COUNT counter by 1 and set API_ENABLED to TRUE, signalling that the API is now available.
- Step 8 - Return the populated library handle to the caller.
- Step 9 - If any unhandled exception occurs at any stage, set API_ENABLED to FALSE and return the null library handle, allowing the caller to detect the failed load.

---
**Decision Points**

DP-001

Condition: TargetPath IS NOT NULL

TRUE: Normalise TargetPath via STRIPDIRSEP and append a backslash; perform a physical file-existence check before attempting the DLL load.

FALSE: Skip path normalisation and file-existence check; proceed directly to ORA_FFI.LOAD_LIBRARY using a null path.

---

DP-002

Condition: TEXT_IO.FOPEN succeeds for TargetPath || TargetDLL in read mode

TRUE: Close the file handle and continue to the ORA_FFI.LOAD_LIBRARY call.

FALSE: Log the missing-file condition via DEBUGLOG and raise the BadLocation exception, aborting the load attempt.

---

DP-003

Condition: LoadCount IS TRUE (after a successful ORA_FFI.LOAD_LIBRARY call)

TRUE: Increment DLL_LOAD_COUNT by 1 and set API_ENABLED to TRUE.

FALSE: Leave DLL_LOAD_COUNT and API_ENABLED unchanged.

---

DP-004

Condition: An unhandled exception is raised anywhere within the procedure

TRUE: Set API_ENABLED to FALSE and return a null library handle to the caller.

FALSE: Normal execution path; return the populated library handle.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - TargetPath must contain exactly one directory path; if multiple paths are present only the first (as normalised by STRIPDIRSEP) is used and any remainder is discarded.
- BR-002 - A trailing backslash separator must always be appended to TargetPath after normalisation before it is used in file or library operations; STRIPDIRSEP is called to remove any pre-existing trailing separator prior to appending.
- BR-003 - When TargetPath is provided, the DLL file must be physically accessible at that location before a load is attempted; failure to open the file is treated as a hard error (BadLocation), logged via DEBUGLOG at severity 99, and prevents the ORA_FFI.LOAD_LIBRARY call.
- BR-004 - The module-level DLL_LOAD_COUNT counter and API_ENABLED flag are updated only when the LoadCount parameter is TRUE and the library load succeeds; a successful load with LoadCount FALSE leaves these module-level values unchanged.
- BR-005 - On any exception during the load process, API_ENABLED must be set to FALSE and a null library handle returned; the procedure must not propagate the exception to the caller, ensuring the caller can detect and handle an unavailable library.

---
**Implementation Logic**

```plsql

FUNCTION  Attempt_DLL_Load  (TargetPath in out VARCHAR2, TargetDLL in VARCHAR2, LoadCount in BOOLEAN DEFAULT TRUE) return ORA_FFI.LibHandleType is
  hDLL  ORA_FFI.LibHandleType;
  hFile TEXT_IO.FILE_TYPE;
begin 
    	
  if TargetPath is not null then 
    -- Watch out for folks who put multiple Paths in here 
    -- Oh yes it's happened! Just use the first & throw the rest away
    -- Add trailing Directory Sep if required
    TargetPath := StripDirSep(TargetPath)||'\';
    
    -- Check that there is actually a file there.
    begin 
  	  hFile := TEXT_IO.FOPEN(TargetPath||TargetDLL,'R');
  	  TEXT_IO.FCLOSE(hFile);
    exception
  	  when others then
  	    Win_API_Debug.DebugLog(99,'Attempt_DLL_LOAD',TargetDLL||' not found in the specified location of "'||TargetPath||'"'); 
  		  raise BadLocation;
    end;
  end if;
  
  hDLL := ORA_FFI.LOAD_LIBRARY(TargetPath, TargetDLL);
  if LoadCount then 
    DLL_LOAD_COUNT  := DLL_LOAD_COUNT + 1;
    API_ENABLED  := TRUE;
  end if;
  return hDLL;
exception
  when others then 
    API_ENABLED := FALSE;
    return hDLL; /* Will be null */
end Attempt_DLL_Load;
```

#### SP-009 - D2KWUTIL.CHOOSEFILE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.SAVE_FILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Presents a native Windows file-chooser dialog (Open or Save) to the end user and returns the selected file path(s) in the IN OUT buffer parameter. The procedure resolves special directory tokens, normalises the initial directory path, registers the underlying Windows API call via D2KWUTIL.D2KWUTIL_CHOOSEFILE, and propagates any API or unexpected errors back to the calling routine (D2KWUTIL.SAVE_FILE).

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| CalledBy | VARCHAR2 | IN |
| Modal | BOOLEAN | IN |
| szTitle | VARCHAR2 | IN |
| szInitDir | VARCHAR2 | IN |
| szFileFilter | VARCHAR2 | IN |
| Flags | PLS_INTEGER | IN |
| SepChar | VARCHAR2 | IN |
| szBuffer | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| szBuffer | VARCHAR2 | IN OUT |

---

**Dependencies**

- ADD_ERROR ([SP-054](#SP-054--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-055](#SP-055--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-056](#SP-056--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-057](#SP-057--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_CHOOSEFILE ([SP-011](#SP-011--D2KWUTIL.D2KWUTIL_CHOOSEFILE)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- D2KWUTIL.GET_ACTIVE_WINDOW ([SP-014](#SP-014--D2KWUTIL.GET_ACTIVE_WINDOW)) - D2KWUTIL.pck (or .pld)
- DEBUGLOG ([SP-058](#SP-058--DEBUGLOG)) - matched by member name
- GET_TEMP_DIRECTORY ([SP-059](#SP-059--GET_TEMP_DIRECTORY)) - matched by member name
- GET_WINDOWS_DIRECTORY ([SP-060](#SP-060--GET_WINDOWS_DIRECTORY)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-061](#SP-061--REGISTER_FUNCTION_CALL)) - matched by member name
- WEBUTIL.LENGTH ([SP-045](#SP-045--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Log all input arguments (CalledBy, Modal flag, title, initial directory, file filter, flags, separator character, and current buffer value) via DEBUGLOG for diagnostic traceability.
- Step 2 - Clear any previously stacked error messages by calling CLEAN_ERROR_STACK, and initialise the return code (iRC) to 0.
- Step 3 - Determine the owner window handle: if the Modal flag is TRUE, retrieve the currently active window handle via D2KWUTIL.GET_ACTIVE_WINDOW; otherwise set the owner handle to 0 (modeless).
- Step 4 - Check whether the Windows API layer is available (WIN_API.API_ENABLED). If not available, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 5 - Register the external DLL function 'd2kwutil_ChooseFile' with its parameter signature using REGISTER_FUNCTION_CALL, binding it to the internal handle iChooseFile.
- Step 6 - Set the dialog mode integer (iBuff1): assign 1 if CalledBy equals 'Open_File', or 2 for any other caller value (Save mode).
- Step 7 - Resolve the initial directory (szInitDir): if the value is the token '$WINDIR$', substitute the actual Windows directory via GET_WINDOWS_DIRECTORY; if the token is '$TEMP$', substitute the temporary directory via GET_TEMP_DIRECTORY; otherwise use the supplied value as-is.
- Step 8 - Ensure the resolved directory path ends with a backslash ('\'); append one if it is absent.
- Step 9 - Resolve the file filter: if szFileFilter is NULL or empty, default to 'All files(*.*)|*.*|'; otherwise use the supplied filter string.
- Step 10 - Take only the first character of SepChar as the effective separator character.
- Step 11 - Pad the szBuffer value to 4096 characters with null characters (CHR(0)) to create the correctly sized output buffer (vcBuff5) required by the Windows API.
- Step 12 - Invoke D2KWUTIL.D2KWUTIL_CHOOSEFILE with the resolved window handle, dialog mode, title, directory, file filter, flags, separator character, and padded buffer; capture the integer return code.
- Step 13 - Log the result (return code and returned buffer content) via DEBUGLOG.
- Step 14 - Write the populated buffer back to the IN OUT parameter szBuffer and return the integer return code to the caller.
- Step 15 - On WIN_API.NOT_AVAILABLE exception, record the error against the CalledBy context using ADD_ERROR with the NoAPI error constant, then re-raise.
- Step 16 - On any other exception, record the error using ADD_ERROR combined with ADD_EXTERNAL_ERRORS to capture external error details, then re-raise.

---
**Decision Points**

DP-001

Condition: Modal IN parameter is TRUE.

TRUE: Retrieve the active window handle via D2KWUTIL.GET_ACTIVE_WINDOW and assign it as hwndOwner, making the dialog modal to the current window.

FALSE: Set hwndOwner to 0, allowing the dialog to be displayed as modeless with no owning window.

---

DP-002

Condition: WIN_API.API_ENABLED evaluates to TRUE.

TRUE: Proceed with registering the external function, resolving parameters, and invoking D2KWUTIL.D2KWUTIL_CHOOSEFILE.

FALSE: Raise the WIN_API.NOT_AVAILABLE exception, bypassing all dialog logic.

---

DP-003

Condition: CalledBy equals the literal string 'Open_File'.

TRUE: Set the dialog mode integer (iBuff1) to 1, indicating an Open File dialog.

FALSE: Set the dialog mode integer (iBuff1) to 2, indicating a Save File dialog.

---

DP-004

Condition: UPPER(szInitDir) equals the token '$WINDIR$'.

TRUE: Resolve the initial directory to the Windows system directory via GET_WINDOWS_DIRECTORY.

FALSE: Evaluate DP-005.

---

DP-005

Condition: UPPER(szInitDir) equals the token '$TEMP$'.

TRUE: Resolve the initial directory to the system temporary directory via GET_TEMP_DIRECTORY.

FALSE: Use the szInitDir value as supplied without substitution.

---

DP-006

Condition: The last character of the resolved initial directory is not a backslash ('\').

TRUE: Append a backslash to the resolved directory path to ensure a valid directory reference.

FALSE: Use the resolved directory path unchanged.

---

DP-007

Condition: szFileFilter is NULL or an empty string.

TRUE: Default the file filter to 'All files(*.*)|*.*|'.

FALSE: Use the caller-supplied szFileFilter value.

---

DP-008

Condition: WIN_API.NOT_AVAILABLE exception is raised.

TRUE: Call ADD_ERROR with the CalledBy context and the WIN_API.NoAPI error constant, then re-raise the exception to the caller.

FALSE: Not applicable (handled by the OTHERS exception branch).

---

DP-009

Condition: An exception other than WIN_API.NOT_AVAILABLE is raised.

TRUE: Call ADD_ERROR with the CalledBy context, concatenating WIN_API.UError with the output of ADD_EXTERNAL_ERRORS, then re-raise the exception to the caller.

FALSE: Normal execution completes; return code and updated buffer are returned to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file-chooser dialog must only be invoked when the Windows API layer is available (WIN_API.API_ENABLED is TRUE); if the API is unavailable the procedure must raise WIN_API.NOT_AVAILABLE and must not attempt to display a dialog.
- BR-002 - When the caller supplies Modal = TRUE, the dialog must be bound to the currently active window (obtained via D2KWUTIL.GET_ACTIVE_WINDOW) to prevent user interaction with the parent form while the dialog is open.
- BR-003 - The dialog mode (Open = 1, Save = 2) is determined exclusively by whether CalledBy equals the literal 'Open_File'; any other CalledBy value results in Save mode.
- BR-004 - The special directory tokens '$WINDIR$' and '$TEMP$' (case-insensitive) must be resolved to their runtime system paths via GET_WINDOWS_DIRECTORY and GET_TEMP_DIRECTORY respectively before the dialog is invoked; no other tokens are recognised.
- BR-005 - The resolved initial directory path must always terminate with a backslash ('\') before being passed to the underlying API; the procedure appends one automatically if absent.
- BR-006 - If no file filter is provided (NULL or empty string), the dialog must default to displaying all files using the filter 'All files(*.*)|*.*|'.
- BR-007 - Only the first character of the SepChar parameter is used as the file separator; any additional characters are silently discarded.
- BR-008 - The output buffer passed to D2KWUTIL.D2KWUTIL_CHOOSEFILE must be exactly 4096 characters, padded with null characters (CHR(0)), to satisfy the Windows API buffer size requirement.
- BR-009 - All invocations must be logged at debug level 99 (entry with full arguments and exit with return code and buffer) via DEBUGLOG to support diagnostic tracing.
- BR-010 - All errors must be recorded against the CalledBy context identifier using ADD_ERROR before the exception is re-raised, ensuring the error stack is attributable to the originating caller; external error details must be appended via ADD_EXTERNAL_ERRORS for non-API errors.

---
**Implementation Logic**

```plsql
    
FUNCTION ChooseFile(  CalledBy      IN      VARCHAR2,
                      Modal         IN      BOOLEAN,
                      szTitle       IN      VARCHAR2,
                      szInitDir     IN      VARCHAR2,
                      szFileFilter  IN      VARCHAR2,
                      Flags         IN      PLS_INTEGER,
                      SepChar       IN      VARCHAR2,
                      szBuffer      IN OUT  VARCHAR2 ) RETURN PLS_INTEGER is
  hwndOwner  PLS_INTEGER;
  iBuff1     PLS_INTEGER;
  iBuff2     PLS_INTEGER;
  iRC        PLS_INTEGER;
  vcBuff1    VARCHAR2(255);
  vcBuff2    VARCHAR2(2000);
  vcBuff3    VARCHAR2(100);
  vcBuff4    VARCHAR2(1);
  vcBuff5    VARCHAR2(4096);
begin 
  Win_API_Debug.DebugLog(99,'ChooseFile','Args: CalledBy="'||CalledBy||', Modal='||win_api_debug.BoolToChar(Modal)||', szTitle="'||szTitle||'", szInitDir="'||szInitDir||'", szFileFilter="'||szFileFilter||'", Flags='||to_char(flags)||', SepChar="'||SepChar||'", szBuffer="'||szBuffer||'"');	
  Win_API.Clean_Error_Stack;
  iRC  := 0;
  if Modal then 
    hwndOwner := win_api_utility.get_active_window;
  else
    hwndOwner := 0;
  end if;

  if Win_API.API_ENABLED then 
      win_api.Register_function_call(iChooseFile,'d2kwutil_ChooseFile','INT','INT,SHORT,*CHAR,*CHAR,*CHAR,LONG,CHAR,*CHAR');

      if CalledBy = 'Open_File' then
        iBuff1     := 1;
      else
        iBuff1    := 2;
      end if;
      iBuff2    := Flags;
      vcBuff1    := szTitle;
      
      if upper(szInitDir) = '$WINDIR$' then 
        vcBuff2 := win_api_environment.get_windows_directory;
      elsif  upper(szInitDir) = '$TEMP$' then 
        vcBuff2 := win_api_environment.get_temp_directory;
      else 
        vcBuff2 := szInitDir;
      end if;
      
      if substr(vcBuff2,length(vcBuff2),1) <> '\' then 
        vcBuff2 := vcBuff2||'\';
      end if;
      
      if szFileFilter = NULL or szFileFilter = '' then 
        vcBuff3 := 'All files(*.*)|*.*|';
      else
        vcBuff3 := szFileFilter;
      end if;
      vcBuff4 := substr(SepChar,1,1);
      vcBuff5 := RPAD(szBuffer,4096,CHR(0)); 
      
      iRC := d2kwutil_choosefile (win_api.FunctionHandle(iChoosefile),iBuff1,hwndOwner,vcBuff1,vcBuff2,vcBuff3,iBuff2,vcBuff4,vcBuff5);
      Win_API_Debug.DebugLog(99,'ChooseFile','Result: RC='||to_char(iRC)||', szBuffer="'||vcBuff5||'"');
      szBuffer := vcBuff5;
      return iRC;
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
exception
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error(CalledBy,Win_API.NoAPI);
    raise;
  when others then
    Win_API.Add_error(CalledBy, Win_API.UError||WIN_API.Add_External_errors); 
    raise;  
end Choosefile;
```

#### SP-010 - D2KWUTIL.D2KWUTIL_ACTIVEWIN

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level foreign-function interface (FFI) binding that retrieves the currently active window handle as a PLS_INTEGER value. It is declared as a callable specification within the D2KWUTIL package and is invoked by D2KWUTIL.GET_ACTIVE_WINDOW to obtain the active window reference from the underlying runtime environment.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that references the external routine responsible for identifying the active window.
- Step 2 - Delegate execution to the external function referenced by hFunc via the ORA_FFI mechanism.
- Step 3 - Return the active window identifier as a PLS_INTEGER value to the calling routine (D2KWUTIL.GET_ACTIVE_WINDOW).

---
**Decision Points**

No decision points are present. The function contains no conditional branching; it accepts the FFI function handle and returns the active window identifier unconditionally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must receive a valid ORA_FFI.funcHandleType handle (hFunc); the handle is the sole input and determines which external function is invoked to resolve the active window.
- BR-002 - The active window identifier is returned as a PLS_INTEGER; callers must treat this value as an opaque window reference supplied by the underlying runtime.
- BR-003 - This function operates exclusively as an FFI specification binding; it performs no database reads or writes and maintains no internal state.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.
FUNCTION d2kwutil_ActiveWin(  hFunc          IN      ORA_FFI.funcHandleType) return PLS_INTEGER;
```

#### SP-011 - D2KWUTIL.D2KWUTIL_CHOOSEFILE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a wrapper interface to a native Windows file-chooser dialog by invoking an external function handle registered through ORA_FFI. The procedure accepts dialog configuration parameters (dialog type, owner window handle, title, initial directory, file filter, advanced flags, and separator character) and returns the user-selected file path(s) in the output buffer, along with an integer result code indicating the outcome of the dialog interaction.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| dialog_type | PLS_INTEGER | IN |
| hwndOwner | PLS_INTEGER | IN |
| szTitle | VARCHAR2 | IN OUT |
| szInitDir | VARCHAR2 | IN OUT |
| szFileFilter | VARCHAR2 | IN OUT |
| AdvancedFlags | PLS_INTEGER | IN |
| SepChar | VARCHAR2 | IN |
| szBuffer | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| szTitle | VARCHAR2 | IN OUT |
| szInitDir | VARCHAR2 | IN OUT |
| szFileFilter | VARCHAR2 | IN OUT |
| szBuffer | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the pre-registered ORA_FFI function handle (hFunc) that references the underlying native file-chooser routine, together with all dialog configuration parameters.
- Step 2 - Pass the dialog type indicator (dialog_type) to determine whether the native dialog is opened in Open-file or Save-file mode.
- Step 3 - Supply the owner window handle (hwndOwner) so the native dialog is correctly parented to the calling Oracle Forms window.
- Step 4 - Forward the mutable string parameters (szTitle, szInitDir, szFileFilter, szBuffer) to the native function; these may be populated or modified by the native layer during execution.
- Step 5 - Apply the AdvancedFlags bitmask and SepChar separator character to control advanced dialog behaviour (e.g., multi-select support and the character used to delimit multiple selected file paths).
- Step 6 - Invoke the external function via the supplied hFunc handle and capture the returned PLS_INTEGER result code.
- Step 7 - Return the result code to the caller; the IN OUT parameters (szTitle, szInitDir, szFileFilter, szBuffer) are updated in place with any values written back by the native dialog.

---
**Decision Points**

DP-001

Condition: The value of dialog_type parameter determines the mode of the native file-chooser dialog.

TRUE (Open mode): The native dialog is presented as a file-open chooser, allowing the user to select an existing file.

FALSE (Save mode): The native dialog is presented as a file-save chooser, allowing the user to specify a target file path.

DP-002

Condition: The AdvancedFlags bitmask may enable multi-file selection.

TRUE (multi-select flag set): Multiple file paths may be returned in szBuffer, delimited by the SepChar character.

FALSE (multi-select flag not set): A single file path is returned in szBuffer.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The caller is responsible for registering the native file-chooser function with ORA_FFI and supplying a valid hFunc handle before invoking this procedure; no internal dependency resolution is performed.
- BR-002 - The dialog_type parameter must be set by the caller to the appropriate integer constant that distinguishes Open-file from Save-file dialog behaviour, as defined by the native Windows API convention.
- BR-003 - When multiple file selections are permitted via AdvancedFlags, the SepChar parameter defines the delimiter character used to separate individual file paths within the szBuffer return value; the caller must parse szBuffer accordingly.
- BR-004 - The IN OUT parameters (szTitle, szInitDir, szFileFilter, szBuffer) must be allocated with sufficient length by the caller prior to invocation, as the native layer may write values back into these buffers.
- BR-005 - The integer return value indicates the success or cancellation of the dialog interaction; the caller must evaluate this return code to determine whether a valid file selection was made before consuming the szBuffer value.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

 FUNCTION d2kwutil_ChooseFile (   hFunc         IN      ORA_FFI.funcHandleType,
                                  dialog_type   IN      PLS_INTEGER,
                                  hwndOwner     IN      PLS_INTEGER,
                                  szTitle       IN OUT  VARCHAR2,
                                  szInitDir     IN OUT  VARCHAR2,
                                  szFileFilter  IN OUT  VARCHAR2,
                                  AdvancedFlags IN      PLS_INTEGER,
                                  SepChar       IN      VARCHAR2,
                                  szBuffer      IN OUT  VARCHAR2) return PLS_INTEGER;
```

#### SP-012 - D2KWUTIL.D2KWUTIL_DEBUGSTRING

**Invoked From:**

- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level foreign-function interface (FFI) bridge that passes a debug text string to the underlying C implementation of the D2KWUTIL library. It is invoked by the WINDEBUG stored procedure within D2kwutil.pld to emit diagnostic or debug messages at runtime via the native C routine identified by pragma interface code 11265.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that references the target C routine within the D2KWUTIL shared library.
- Step 2 - Receive the debug text string (Text) to be passed to the native C layer.
- Step 3 - Delegate execution to the C implementation bound under PRAGMA INTERFACE code 11265, forwarding both the function handle and the text string as arguments.
- Step 4 - Return control to the calling procedure (WINDEBUG) upon completion of the C routine; no output value is produced.

---
**Decision Points**

No decision points are present in this procedure. The routine unconditionally delegates to the C foreign function via the declared PRAGMA INTERFACE binding without conditional branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must be called with a valid ORA_FFI.funcHandleType handle; the handle identifies the specific C entry point within the D2KWUTIL library and must be initialised by the caller (WINDEBUG) before invocation.
- BR-002 - The Text parameter carries the debug string to be surfaced at the C layer; no transformation or validation of the string content is performed within this procedure.
- BR-003 - The procedure produces no formal output parameters; any result or side-effect is entirely managed by the bound C routine (PRAGMA INTERFACE code 11265).
- BR-004 - This procedure is exclusively intended for debug/diagnostic output purposes and must not be used to convey business-critical data or drive application state.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.
   
 PROCEDURE d2kwutil_DebugString (    hFunc       IN      ORA_FFI.funcHandleType,
                                     Text        IN      VARCHAR2);
 -- Pragmas
 PRAGMA INTERFACE(C,d2kwutil_DebugString,      11265);
```

#### SP-013 - D2KWUTIL.D2KWUTIL_WINDIR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level Foreign Function Interface (FFI) wrapper that delegates to the underlying Windows API to retrieve a Windows directory path (either the Windows system directory or the temporary directory, depending on the function handle supplied by the caller). The function accepts a pre-registered FFI function handle, a buffer to receive the directory path, and the buffer length, returning a PLS_INTEGER status code. It is invoked exclusively by GET_TEMP_DIRECTORY and GET_WINDOWS_DIRECTORY within D2kwutil.pld.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| WindowsDir | VARCHAR2 | IN OUT |
| InBuffLen | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| WindowsDir | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that identifies which Windows API entry point to invoke (e.g., GetWindowsDirectory or GetTempPath), the output buffer (WindowsDir), and the declared buffer length (InBuffLen).
- Step 2 - Delegate the call through ORA_FFI to the external Windows API function referenced by hFunc, passing WindowsDir as the receiving buffer and InBuffLen as its maximum capacity.
- Step 3 - Allow the external API to populate the WindowsDir IN OUT parameter with the resolved directory path string.
- Step 4 - Return the PLS_INTEGER result code produced by the external API call to the invoking procedure (GET_TEMP_DIRECTORY or GET_WINDOWS_DIRECTORY) for further handling.

---
**Decision Points**

No conditional decision points are present in the available implementation. The function signature is a direct FFI pass-through; all branching logic resides in the calling procedures GET_TEMP_DIRECTORY and GET_WINDOWS_DIRECTORY.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function operates solely as an FFI wrapper; it must be supplied with a valid, pre-registered ORA_FFI.funcHandleType handle (hFunc) that corresponds to the target Windows API function, as no internal handle resolution is performed.
- BR-002 - The caller is responsible for declaring WindowsDir with sufficient length and passing the correct InBuffLen value; the function does not perform buffer-size validation internally.
- BR-003 - The function returns a PLS_INTEGER status code whose interpretation (success or failure) is the responsibility of the invoking procedures GET_TEMP_DIRECTORY and GET_WINDOWS_DIRECTORY.
- BR-004 - This function must not be called directly by application screens; it is an internal utility invoked only through GET_TEMP_DIRECTORY and GET_WINDOWS_DIRECTORY within D2kwutil.pld.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_WinDir (      hFunc          IN      ORA_FFI.funcHandleType,
                                WindowsDir     IN OUT  VARCHAR2,
                                InBuffLen      IN      PLS_INTEGER
                                ) RETURN PLS_INTEGER;
```

#### SP-014 - D2KWUTIL.GET_ACTIVE_WINDOW

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the Windows handle of the currently active window by invoking the external D2KWUtil library function D2KWUTIL_ACTIVEWIN. The function returns the active window handle as a PLS_INTEGER and, optionally, raises an exception if the handle cannot be obtained. It is called by D2KWUTIL.CHOOSEFILE to identify the active window context before presenting a file-chooser dialog.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-054](#SP-054--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-055](#SP-055--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-056](#SP-056--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-057](#SP-057--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_ACTIVEWIN ([SP-010](#SP-010--D2KWUTIL.D2KWUTIL_ACTIVEWIN)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-058](#SP-058--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-061](#SP-061--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log entry diagnostics by calling DEBUGLOG, recording the value of the RaiseExceptions input parameter converted to a character string via BOOLTOCHAR.
- Step 2 - Clear any previously accumulated error state by calling CLEAN_ERROR_STACK.
- Step 3 - Check whether the underlying Windows API integration layer is enabled (WIN_API.API_ENABLED).
- Step 4 - If the API is enabled, register the external function call for D2KWUTIL_ACTIVEWIN by calling REGISTER_FUNCTION_CALL, supplying the function slot identifier, the function name, its return type ('INT'), and a NULL parameter list.
- Step 5 - Invoke D2KWUTIL.D2KWUTIL_ACTIVEWIN via its registered function handle to obtain the active window handle, storing the result in the local return variable iRC.
- Step 6 - Log the result code returned by D2KWUTIL_ACTIVEWIN via DEBUGLOG.
- Step 7 - If the API is not enabled, raise the WIN_API.NOT_AVAILABLE exception.
- Step 8 - Evaluate the returned handle value: if iRC equals 0 (indicating failure to obtain a valid handle), call ADD_ERROR to record the failure message.
- Step 9 - If iRC equals 0 and RaiseExceptions is TRUE, raise NO_DATA_FOUND to signal the failure to the caller.
- Step 10 - Return iRC (the active window handle) to the caller.
- Step 11 - In the exception block, handle NO_DATA_FOUND by re-raising it; handle WIN_API.NOT_AVAILABLE by logging the error via ADD_ERROR and re-raising; handle all other exceptions by logging a generic error message combined with any external error details via ADD_EXTERNAL_ERRORS, then re-raising.

---
**Decision Points**

DP-001

Condition: WIN_API.API_ENABLED evaluates to TRUE.

TRUE: Register the external function call via REGISTER_FUNCTION_CALL and invoke D2KWUTIL.D2KWUTIL_ACTIVEWIN to retrieve the active window handle.

FALSE: Raise the WIN_API.NOT_AVAILABLE exception, bypassing the external call entirely.

---

DP-002

Condition: The value returned by D2KWUTIL.D2KWUTIL_ACTIVEWIN (iRC) equals 0.

TRUE: Record an error via ADD_ERROR indicating that the active window handle could not be obtained, then evaluate DP-003.

FALSE: Proceed to return the valid window handle to the caller.

---

DP-003

Condition: iRC equals 0 AND the RaiseExceptions input parameter is TRUE.

TRUE: Raise NO_DATA_FOUND to propagate the failure to the calling routine.

FALSE: Return iRC (0) to the caller without raising an exception, allowing the caller to handle the zero-handle condition silently.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function may only invoke the Windows API integration layer when WIN_API.API_ENABLED is TRUE; if the API is unavailable, execution must halt immediately with a WIN_API.NOT_AVAILABLE exception.
- BR-002 - A return value of 0 from D2KWUTIL.D2KWUTIL_ACTIVEWIN is treated as a failure condition; the error must always be recorded via ADD_ERROR regardless of the RaiseExceptions flag.
- BR-003 - Exception propagation on a zero-handle result is controlled by the RaiseExceptions input parameter; callers that require strict failure handling must pass RaiseExceptions => TRUE.
- BR-004 - All exceptions (NO_DATA_FOUND, WIN_API.NOT_AVAILABLE, and unhandled others) must be re-raised after error logging, ensuring that no failure is silently swallowed within this function.
- BR-005 - Unhandled exceptions must be logged using both ADD_ERROR and ADD_EXTERNAL_ERRORS to capture any additional error detail surfaced by the external API layer before re-raising.
- BR-006 - Entry and exit diagnostic information (input parameters and result code) must be written to the debug log via DEBUGLOG at verbosity level 99 for traceability.

---
**Implementation Logic**

```plsql

FUNCTION Get_Active_Window (RaiseExceptions IN  BOOLEAN DEFAULT FALSE) RETURN PLS_INTEGER is
  iRC    PLS_INTEGER := 0;
begin
  Win_API_Debug.DebugLog(99,'Get_Active_Window','Args: RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	  			
  WIN_API.Clean_Error_Stack;
  if WIN_API.API_ENABLED then 
    win_api.Register_function_call(iActiveWin,'d2kwutil_ActiveWin','INT',NULL);
    iRC   := d2kwutil_ActiveWin(win_api.FunctionHandle(iActiveWin));
    Win_API_Debug.DebugLog(99,'Get_Active_Window','Result: RC='||to_char(iRC));        
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0 then 
    Win_API.Add_error('Get_Active_Window','Unable to obtain active window handle');
    if RaiseExceptions then 
      raise NO_DATA_FOUND;
    end if;
  end if;
  return iRC;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Active_Window',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Active_Window',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Active_window;
```

#### SP-015 - D2KWUTIL.SAVE_FILE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FILE_SELECTION_DIALOG_INT]
- webutil.pld [StoredProcedure: WEBUTIL_FILE.FILE_SAVE_DIALOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Presents a 'Save File As' dialog to the user and returns the file path selected for saving. The function delegates the dialog rendering to D2KWUTIL.CHOOSEFILE and enforces a no-selection error condition, optionally raising a formal exception when no file is chosen.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| SampleName | VARCHAR2 | IN |
| Title | VARCHAR2 | IN |
| StartDirectory | VARCHAR2 | IN |
| FileFilter | VARCHAR2 | IN |
| Modal | BOOLEAN | IN |
| AdvancedFlags | PLS_INTEGER | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-054](#SP-054--ADD_ERROR)) - matched by member name
- D2KWUTIL.CHOOSEFILE ([SP-009](#SP-009--D2KWUTIL.CHOOSEFILE)) - D2KWUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Initialise the candidate file path (vcReturnedFile) with the value supplied in SampleName, pre-populating the dialog with a suggested file name.
- Step 2 - Invoke D2KWUTIL.CHOOSEFILE, passing the context label 'Save_File', together with Modal, Title, StartDirectory, FileFilter, AdvancedFlags, a blank separator, and the initialised vcReturnedFile (passed by reference to receive the user's selection).
- Step 3 - Evaluate the integer return code (iLRC) produced by D2KWUTIL.CHOOSEFILE.
- Step 4 - If iLRC equals 1 (no file was selected), call ADD_ERROR to register the message 'No file was selected' against the 'Save_File' context.
- Step 5 - If RaiseExceptions is TRUE and no file was selected, raise the NO_DATA_FOUND exception to signal the failure to the calling routine.
- Step 6 - If iLRC does not equal 1 (a valid file path was returned), return vcReturnedFile to the caller as the chosen save-file path.

---
**Decision Points**

DP-001

Condition: iLRC (return code from D2KWUTIL.CHOOSEFILE) equals 1.

TRUE: No file was selected by the user. ADD_ERROR is called to record the error message 'No file was selected', and processing continues to DP-002.

FALSE: A valid file path was returned; the function returns vcReturnedFile to the caller and exits normally.

---

DP-002

Condition: RaiseExceptions is TRUE (evaluated only when iLRC = 1).

TRUE: The NO_DATA_FOUND exception is raised, propagating the no-selection failure to the calling routine.

FALSE: The function exits without raising an exception; the error is recorded via ADD_ERROR but execution returns silently.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The dialog must be pre-populated with the value supplied in SampleName as the suggested file name; this value is used as the initial contents of the file-name field presented to the user.
- BR-002 - The default dialog title is 'Save File As', the default start directory is '$WINDIR$', and the default file filter is 'All files(*.*)|*.*|'; callers may override each of these defaults.
- BR-003 - A return code of 1 from D2KWUTIL.CHOOSEFILE is treated as a no-selection condition and must always result in an error being registered via ADD_ERROR with the message 'No file was selected'.
- BR-004 - Exception propagation is opt-in: the NO_DATA_FOUND exception is raised on a no-selection outcome only when the caller explicitly passes RaiseExceptions as TRUE; otherwise the error is logged silently and the function exits without a return value.
- BR-005 - The function returns a file path string of up to 4 096 characters; no database interactions are performed at any point during execution.

---
**Implementation Logic**

```plsql
                    

FUNCTION Save_File (  SampleName       IN  VARCHAR2,
                      Title            IN  VARCHAR2     DEFAULT 'Save File As',
                      StartDirectory   IN  VARCHAR2     DEFAULT '$WINDIR$',
                      FileFilter       IN  VARCHAR2     DEFAULT 'All files(*.*)|*.*|',
                      Modal            IN  BOOLEAN      DEFAULT TRUE,
                      AdvancedFlags    IN  PLS_INTEGER  DEFAULT WIN_API.OFN_FLAG_DEFAULT,
                      RaiseExceptions  IN  BOOLEAN      DEFAULT FALSE
                    ) RETURN VARCHAR2 is
  vcReturnedFile  varchar2(4096);
  iLRC    pls_integer := 0;
begin 
  vcReturnedFile  := SampleName;
  iLRC := choosefile('Save_File',Modal,Title,StartDirectory,FileFilter,AdvancedFlags,' ',vcReturnedFile);
  
  if iLRC = 1 then 
    Win_API.Add_error('Save_File','No file was selected');
    if RaiseExceptions then 
      Raise NO_DATA_FOUND;
    end if;
  else
    return vcReturnedFile;
  end if;
end Save_File;
```

#### SP-016 - D2KWUTIL.TRANSLATETYPE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

TranslateType is a lookup function that converts a string-based C data type name (e.g., 'INT', '*CHAR', 'DOUBLE') into its corresponding ORA_FFI integer constant. It is used internally by REGISTER_FUNCTION_CALL to resolve parameter and return-value type codes required when registering external C library functions via the Oracle Foreign Function Interface (ORA_FFI).

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DataType | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input string DataType and convert it to uppercase, storing the result in the local variable vcType.
- Step 2 - Evaluate vcType against each recognised C data type string in sequence using an IF-ELSIF chain.
- Step 3 - For each matched type string, assign the corresponding ORA_FFI integer constant to the local return variable iRC (e.g., '*CHAR' maps to ORA_FFI.C_CHAR_PTR, 'CHAR' maps to ORA_FFI.C_CHAR, '*INT' maps to ORA_FFI.C_INT_PTR, 'INT' maps to ORA_FFI.C_INT, '*LONG' maps to ORA_FFI.C_LONG_PTR, 'LONG' maps to ORA_FFI.C_LONG, '*SHORT' or '*BYTE' maps to ORA_FFI.C_SHORT_PTR, 'SHORT' or 'BYTE' maps to ORA_FFI.C_SHORT, '*DOUBLE' maps to ORA_FFI.C_DOUBLE_PTR, 'DOUBLE' maps to ORA_FFI.C_DOUBLE, '*VOID' maps to ORA_FFI.C_VOID_PTR).
- Step 4 - Return the resolved ORA_FFI integer constant iRC to the caller.

---
**Decision Points**

DP-001
Condition: vcType = '*CHAR'
TRUE: Assign ORA_FFI.C_CHAR_PTR to iRC.
FALSE: Proceed to DP-002.

DP-002
Condition: vcType = 'CHAR'
TRUE: Assign ORA_FFI.C_CHAR to iRC.
FALSE: Proceed to DP-003.

DP-003
Condition: vcType = '*INT'
TRUE: Assign ORA_FFI.C_INT_PTR to iRC.
FALSE: Proceed to DP-004.

DP-004
Condition: vcType = 'INT'
TRUE: Assign ORA_FFI.C_INT to iRC.
FALSE: Proceed to DP-005.

DP-005
Condition: vcType = '*LONG'
TRUE: Assign ORA_FFI.C_LONG_PTR to iRC.
FALSE: Proceed to DP-006.

DP-006
Condition: vcType = 'LONG'
TRUE: Assign ORA_FFI.C_LONG to iRC.
FALSE: Proceed to DP-007.

DP-007
Condition: vcType = '*SHORT' OR vcType = '*BYTE'
TRUE: Assign ORA_FFI.C_SHORT_PTR to iRC.
FALSE: Proceed to DP-008.

DP-008
Condition: vcType = 'SHORT' OR vcType = 'BYTE'
TRUE: Assign ORA_FFI.C_SHORT to iRC.
FALSE: Proceed to DP-009.

DP-009
Condition: vcType = '*DOUBLE'
TRUE: Assign ORA_FFI.C_DOUBLE_PTR to iRC.
FALSE: Proceed to DP-010.

DP-010
Condition: vcType = 'DOUBLE'
TRUE: Assign ORA_FFI.C_DOUBLE to iRC.
FALSE: Proceed to DP-011.

DP-011
Condition: vcType = '*VOID'
TRUE: Assign ORA_FFI.C_VOID_PTR to iRC.
FALSE: No assignment is made; iRC remains NULL and is returned as-is.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The input DataType string is treated as case-insensitive; it is uppercased before evaluation, so callers may supply mixed-case type names without affecting the lookup result.
- BR-002 - The type strings '*SHORT' and '*BYTE' are treated as equivalent and both resolve to ORA_FFI.C_SHORT_PTR.
- BR-003 - The type strings 'SHORT' and 'BYTE' are treated as equivalent and both resolve to ORA_FFI.C_SHORT.
- BR-004 - If the supplied DataType does not match any recognised type string, no ORA_FFI constant is assigned and the function returns NULL; callers must handle a NULL return value appropriately.
- BR-005 - The function supports exactly eleven recognised type identifiers: '*CHAR', 'CHAR', '*INT', 'INT', '*LONG', 'LONG', '*SHORT' / '*BYTE', 'SHORT' / 'BYTE', '*DOUBLE', 'DOUBLE', and '*VOID'; no other type strings are mapped.

---
**Implementation Logic**

```plsql
 
FUNCTION TranslateType(DataType in VARCHAR2) return PLS_INTEGER is
   -- Just a simple lookup of the types.
   vcType VARCHAR2(10) := UPPER(DataType);
   iRC    PLS_INTEGER;
begin 
  if vcType = '*CHAR' then 
    iRC := ORA_FFI.C_CHAR_PTR;
  elsif vcType = 'CHAR' then 
    iRC := ORA_FFI.C_CHAR;
  elsif vcType = '*INT' then 
    iRC := ORA_FFI.C_INT_PTR;
  elsif vcType = 'INT' then 
    iRC := ORA_FFI.C_INT;
  elsif vcType = '*LONG' then 
    iRC := ORA_FFI.C_LONG_PTR;
  elsif vcType = 'LONG' then 
    iRC := ORA_FFI.C_LONG;
  elsif vcType = '*SHORT' or vcType = '*BYTE'  then 
    iRC := ORA_FFI.C_SHORT_PTR;
  elsif vcType = 'SHORT' or vcType = 'BYTE' then 
    iRC := ORA_FFI.C_SHORT;
  elsif vcType = '*DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE_PTR;
  elsif vcType = 'DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE;  
  elsif vcType = '*VOID' then 
    iRC := ORA_FFI.C_VOID_PTR;      
  end if;
return iRC;
end TranslateType;
```

#### SP-017 - GENERAL.ASK_CONFIRM

**Invoked From:**

- pt_phy_fmb.xml [ProgramUnit: CALL_REPORT_PR_INVENTORY]
- pt_phy_fmb.xml [StoredProcedure: CALL_REPORT_PR_INVENTORY]
- pt_phy_fmb.xml [Trigger: FT_CANCEL]

---

**Screen:**

COUNT DETAILS (N/A / CN_MAIN)

---

**Purpose**

Presents a named confirmation alert (AL_CONFIRM) to the user with a caller-supplied message and returns a numeric flag indicating which button the user pressed. The function acts as a reusable confirmation gateway, allowing calling routines to branch their processing based on the user's yes/no response without duplicating alert-handling code.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| confirm_msg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the confirmation message text via the input parameter confirm_msg.
- Step 2 - Set the message text of the predefined alert AL_CONFIRM to the value of confirm_msg using set_alert_property.
- Step 3 - Display the AL_CONFIRM alert to the user by calling show_alert and capture the button pressed in the local variable p_albtn_pressed.
- Step 4 - Evaluate p_albtn_pressed against the constant ALERT_BUTTON1.
- Step 5 - Return 1 if the user pressed the first button (affirmative/confirm), or 0 if any other button was pressed (negative/cancel).

---
**Decision Points**

DP-001

Condition:
The value of p_albtn_pressed equals ALERT_BUTTON1 (the first/affirmative button on the AL_CONFIRM alert).

TRUE:
The function returns 1, signalling to the caller that the user confirmed the action.

FALSE:
The function returns 0, signalling to the caller that the user did not confirm the action (cancelled or dismissed).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The alert used for confirmation must be the predefined alert named AL_CONFIRM; no other alert name is permitted within this function.
- BR-002 - The confirmation message displayed to the user is entirely determined by the caller via the confirm_msg parameter; the function does not supply or modify the message text beyond passing it to the alert.
- BR-003 - Only a press of ALERT_BUTTON1 is treated as an affirmative confirmation; all other button responses (including dismissal) are treated as a negative response and return 0.
- BR-004 - The function must return a numeric value of 1 (confirmed) or 0 (not confirmed) to the caller; no other return values are valid for business processing purposes.

---
**Implementation Logic**

```plsql
FUNCTION ASK_CONFIRM( confirm_msg VARCHAR2)
                                      RETURN  NUMBER IS

    p_alert_name varchar2(10) := 'AL_CONFIRM' ;
    p_albtn_pressed number;
BEGIN
   set_alert_property(p_alert_name,alert_message_text,confirm_msg); 
   p_albtn_pressed := show_alert(p_alert_name);

   IF ( p_albtn_pressed = ALERT_BUTTON1 ) THEN
      return (1);
   ELSE
      return(0);
   END IF;
RETURN NULL; END;
```

#### SP-018 - GENERAL.ASK_PRINT

**Invoked From:**

- pt_phy_fmb.xml [ProgramUnit: PRINT_AS]

---

**Screen:**

N/A

---

**Purpose**

Presents a named confirmation alert ('AL_PRINT') to the user with a caller-supplied message and returns a numeric code (1, 2, or 3) that indicates which alert button the user pressed. The result is used by the invoking routine (PRINT_AS in pt_phy_fmb.xml) to determine whether and how to proceed with a print action.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| confirm_msg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the confirmation message text via the input parameter `confirm_msg`.
- Step 2 - Set the message text of the predefined alert 'AL_PRINT' to the supplied `confirm_msg` using `SET_ALERT_PROPERTY`.
- Step 3 - Display the alert to the user by calling `SHOW_ALERT` and capture the button pressed in the local variable `p_albtn_pressed`.
- Step 4 - Evaluate the button pressed: if `ALERT_BUTTON1` was pressed, return 1; if `ALERT_BUTTON2` was pressed, return 2; for any other button (including a duplicate `ALERT_BUTTON2` branch and the ELSE fallback), return 3.
- Step 5 - Return the numeric result to the calling routine so it can act on the user's choice.

---
**Decision Points**

DP-001

Condition:
`p_albtn_pressed = ALERT_BUTTON1`

TRUE:
Return 1 to the caller, indicating the user confirmed with the first button.

FALSE:
Proceed to DP-002.

---

DP-002

Condition:
`p_albtn_pressed = ALERT_BUTTON2`

TRUE:
Return 2 to the caller, indicating the user selected the second button.

FALSE:
Proceed to DP-003.

---

DP-003

Condition:
All remaining cases (ELSIF duplicate of ALERT_BUTTON2 or ELSE branch).

TRUE:
Return 3 to the caller, indicating the user selected a third button or dismissed the alert by any other means.

FALSE:
N/A - this is the final catch-all branch.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The alert name used for print confirmation is fixed as 'AL_PRINT'; the alert must exist in the form at design time for the procedure to execute successfully.
- BR-002 - The confirmation message displayed to the user is entirely determined by the caller via `confirm_msg`; this procedure does not impose or default any message text.
- BR-003 - A return value of 1 represents user acceptance (ALERT_BUTTON1), 2 represents the second-button response (ALERT_BUTTON2), and 3 represents any other outcome, including the third button or an unrecognised button state.
- BR-004 - Due to a duplicate ELSIF condition on ALERT_BUTTON2 in the source code, the third-button path (return 3) is reachable only via the ELSE branch; the second ELSIF is logically unreachable and is treated as equivalent to the ELSE fallback.

---
**Implementation Logic**

```plsql
FUNCTION ASK_PRINT(confirm_msg VARCHAR2)
                                      RETURN  NUMBER IS

    p_alert_name varchar2(10) := 'AL_PRINT' ;
    p_albtn_pressed number;
BEGIN
   set_alert_property(p_alert_name,alert_message_text,confirm_msg); 
   p_albtn_pressed := show_alert(p_alert_name);

   IF ( p_albtn_pressed = ALERT_BUTTON1 ) THEN
      return (1);
   ELSIF ( p_albtn_pressed = ALERT_BUTTON2 ) THEN
      return(2);
   ELSIF ( p_albtn_pressed = ALERT_BUTTON2 ) THEN
      return(3);
   ELSE         
   		return(3);
   END IF;
RETURN NULL; END;
```

#### SP-019 - GENERAL.CHECK_FORM_FAILURE

**Invoked From:**

- pt_phy_fmb.xml [Trigger: FT_DEL]
- pt_phy_fmb.xml [Trigger: FT_SAVE]

---

**Screen:**

ADJUSTMENT DETAILS (N/A / CN_ADJ); COUNT DETAILS (N/A / CN_MAIN); PART DETAILS (N/A / CN_MAIN)

---

**Purpose**

Checks whether the most recent Oracle Forms operation succeeded and, if not, surfaces the appropriate error message to the user before halting further trigger processing. The procedure distinguishes between Oracle database errors (ORA) and Oracle Forms runtime errors (FRM), routing each to the shared display utility GENERAL.DISP_TEXT before raising a form trigger failure to abort the calling trigger.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-021](#SP-021--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate the built-in FORM_SUCCESS function to determine whether the preceding Forms operation completed without error.
- Step 2 - If FORM_SUCCESS returns FALSE (i.e., a failure condition exists), inspect the ERROR_TYPE built-in to classify the error.
- Step 3 - If ERROR_TYPE is 'ORA' (an Oracle database-level error), call GENERAL.DISP_TEXT passing SQLERRM as the message text and 'Error' as the message type to display the database error to the user.
- Step 4 - If ERROR_TYPE is 'FRM' (an Oracle Forms runtime error), call GENERAL.DISP_TEXT passing ERROR_TEXT as the message text and 'Error' as the message type to display the Forms error to the user.
- Step 5 - After displaying the error message, raise FORM_TRIGGER_FAILURE to halt execution of the calling trigger (FT_DEL or FT_SAVE) and prevent any further processing.
- Step 6 - If FORM_SUCCESS returns TRUE, no action is taken and the calling trigger continues normally.

---
**Decision Points**

DP-001

Condition: FORM_SUCCESS evaluates to FALSE (the preceding Forms operation did not succeed).

TRUE: Proceed to classify the error type and display an error message, then raise FORM_TRIGGER_FAILURE.

FALSE: No action is taken; control returns to the calling trigger and processing continues normally.

DP-002

Condition: ERROR_TYPE = 'ORA' (the failure originated at the Oracle database layer).

TRUE: Call GENERAL.DISP_TEXT with SQLERRM (the Oracle database error message) and severity label 'Error'.

FALSE: Evaluate whether ERROR_TYPE = 'FRM' (see DP-003).

DP-003

Condition: ERROR_TYPE = 'FRM' (the failure originated within the Oracle Forms runtime layer).

TRUE: Call GENERAL.DISP_TEXT with ERROR_TEXT (the Forms runtime error message) and severity label 'Error'.

FALSE: No error message is displayed; execution still proceeds to raise FORM_TRIGGER_FAILURE as the outer failure condition (DP-001 TRUE branch) remains in effect.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Any unsuccessful Forms operation detected via FORM_SUCCESS must be communicated to the user before the triggering action is aborted; silent failures are not permitted.
- BR-002 - Oracle database errors (ERROR_TYPE = 'ORA') must be presented using the Oracle-supplied SQLERRM message text to ensure accurate, system-generated error descriptions are shown.
- BR-003 - Oracle Forms runtime errors (ERROR_TYPE = 'FRM') must be presented using the Forms-supplied ERROR_TEXT to ensure the correct runtime error description is shown.
- BR-004 - All error messages must be displayed with severity classification 'Error' via GENERAL.DISP_TEXT, ensuring consistent error presentation across the application.
- BR-005 - Upon detecting any form failure, FORM_TRIGGER_FAILURE must always be raised after error display to prevent the FT_DEL or FT_SAVE trigger from completing its action (e.g., deletion or save) in an error state.

---
**Implementation Logic**

```plsql
PROCEDURE CHECK_FORM_FAILURE IS
BEGIN
 IF (NOT form_success) THEN
     IF ERROR_TYPE = 'ORA' THEN
        GENERAL.disp_text(SQLERRM,'Error');
     ELSIF ERROR_TYPE = 'FRM' THEN
        GENERAL.disp_text(ERROR_TEXT,'Error');
     END IF;
     raise form_trigger_failure;
  END IF; 

END;
```

#### SP-020 - GENERAL.CHECK_NULL

**Invoked From:**

- pt_phy_fmb.xml [Trigger: KEY-NEXT-ITEM]
- pt_phy_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]
- pt_phy_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

ADJUSTMENT DETAILS (N/A / CN_ADJ); COUNT DETAILS (N/A / CN_MAIN); PART DETAILS (N/A / CN_MAIN)

---

**Purpose**

Validates that a required field value has been supplied by the user. If the incoming value is NULL, the procedure displays a contextual error message identifying the offending field and halts further form processing by raising a trigger failure. It is used across the Adjustment Details, Count Details, and Part Details screens to enforce mandatory-field entry before navigation or save actions proceed.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_value | VARCHAR2 | IN |
| column_title | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-021](#SP-021--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the field value (P_value) and the human-readable column title (column_title) as input parameters.
- Step 2 - Construct an error message string in the format 'Enter a valid <column_title>' using the supplied column title.
- Step 3 - Evaluate whether P_value is NULL.
- Step 4 - If P_value IS NULL, invoke GENERAL.DISP_TEXT (SP-021) passing the constructed message text and the severity indicator 'Error' to present the error to the user.
- Step 5 - After displaying the error, raise FORM_TRIGGER_FAILURE to abort the triggering event (KEY-NEXT-ITEM, WHEN-BUTTON-PRESSED, or WHEN-VALIDATE-ITEM) and return focus to the offending field.
- Step 6 - If P_value is NOT NULL, the procedure exits silently and form processing continues normally.

---
**Decision Points**

DP-001

Condition:
P_value IS NULL

TRUE:
Call GENERAL.DISP_TEXT with the message 'Enter a valid <column_title>' and severity 'Error', then raise FORM_TRIGGER_FAILURE to halt the triggering form event.

FALSE:
No action is taken; the procedure ends normally and the calling trigger continues execution.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A field value passed to this procedure is considered mandatory; a NULL value is never acceptable and must be rejected before the form event completes.
- BR-002 - The error message presented to the user must identify the specific field in error by incorporating the column_title parameter, formatted as 'Enter a valid <column_title>' (maximum 80 characters).
- BR-003 - Error notification must be delivered through GENERAL.DISP_TEXT (SP-021) with severity level 'Error', ensuring consistent error presentation across all screens that invoke this procedure.
- BR-004 - Upon detecting a NULL value, FORM_TRIGGER_FAILURE must be raised to prevent navigation away from, or processing of, the incomplete field, regardless of which trigger (KEY-NEXT-ITEM, WHEN-BUTTON-PRESSED, or WHEN-VALIDATE-ITEM) initiated the call.

---
**Implementation Logic**

```plsql
PROCEDURE CHECK_NULL( P_value IN VARCHAR2, column_title  IN VARCHAR2) IS
mesg_text        varchar2(80) := 'Enter a valid '||column_title ;
BEGIN
   IF p_value IS null  THEN
      GENERAL.DISP_TEXT(mesg_text,'Error');
      raise form_trigger_failure;
   END IF;
END;
```

#### SP-021 - GENERAL.DISP_TEXT

**Invoked From:**

- pt_phy_fmb.xml [ProgramUnit: PRINT_AS]
- pt_phy_fmb.xml [ProgramUnit: STOCK_UPDATE_EXCEPTION]
- DPL.pld [StoredProcedure: GENERAL.CHECK_FORM_FAILURE]
- DPL.pld [StoredProcedure: GENERAL.CHECK_NULL]
- DPL.pld [StoredProcedure: GENERAL.PROC_TIMER_EXPIRED]
- DPL.pld [StoredProcedure: GENERAL.RAISE_ERROR]
- DPL.pld [StoredProcedure: RUN_REPORT]
- pt_phy_fmb.xml [StoredProcedure: STOCK_UPDATE_EXCEPTION]
- pt_phy_fmb.xml [Trigger: FT_DEL]
- pt_phy_fmb.xml [Trigger: FT_SAVE]
- pt_phy_fmb.xml [Trigger: KEY-DOWN]
- pt_phy_fmb.xml [Trigger: KEY-NEXT-ITEM]
- pt_phy_fmb.xml [Trigger: KEY-UP]
- pt_phy_fmb.xml [Trigger: ON-ERROR]
- pt_phy_fmb.xml [Trigger: ON-MESSAGE]
- pt_phy_fmb.xml [Trigger: POST-QUERY]
- pt_phy_fmb.xml [Trigger: WBP]
- pt_phy_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]
- pt_phy_fmb.xml [Trigger: WHEN-NEW-BLOCK-INSTANCE]
- pt_phy_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]
- pt_phy_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

ADJUSTMENT DETAILS (N/A / CN_ADJ); COUNT DETAILS (N/A / CN_MAIN); PART DETAILS (N/A / CN_MAIN)

---

**Purpose**

Displays a modal alert dialog to the user containing a caller-supplied message and title. The procedure selects the appropriate Oracle Forms alert template based on whether the title indicates an error condition, then presents the alert so that the user must acknowledge the message before continuing. It is used across triggers, program units, and stored procedures throughout the physical inventory form and the DPL library as the single, consistent mechanism for surfacing informational and error text.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| text_string | VARCHAR2 | IN |
| title_string | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message body (`text_string`) and the dialog title (`title_string`) as input parameters.
- Step 2 - Evaluate the title to determine alert severity: if `title_string` (case-insensitive) equals `'ERROR'`, assign alert template name `AL_ERRINFO`; otherwise assign alert template name `AL_NOTE`.
- Step 3 - Set the TITLE property of the selected alert template to `title_string` using `SET_ALERT_PROPERTY`.
- Step 4 - Set the ALERT_MESSAGE_TEXT property of the selected alert template to `text_string` using `SET_ALERT_PROPERTY`.
- Step 5 - Display the configured alert to the user via `SHOW_ALERT` and capture the user's button response in the local variable `p_alert_id` (response is not evaluated further; the call is used solely to render the modal dialog).

---
**Decision Points**

DP-001

Condition:
`UPPER(title_string) = 'ERROR'`

TRUE:
The alert template `AL_ERRINFO` is used, indicating an error-severity dialog.

FALSE:
The alert template `AL_NOTE` is used, indicating an informational or non-error dialog.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The title string `'ERROR'` (case-insensitive) is the sole criterion that distinguishes an error alert (`AL_ERRINFO`) from an informational alert (`AL_NOTE`); any other title value, regardless of content, is treated as informational.
- BR-002 - Alert properties (title and message text) must be set dynamically on the chosen template before display, ensuring the correct caller-supplied content is shown rather than any previously cached alert text.
- BR-003 - The user's button response from `SHOW_ALERT` is captured but intentionally ignored; the procedure's sole responsibility is to present the message, not to branch on the user's acknowledgement.
- BR-004 - All callers across the form and DPL library must route user-facing text through this procedure to ensure a consistent alert presentation standard.

---
**Implementation Logic**

```plsql
PROCEDURE DISP_TEXT (text_string VARCHAR2,
                     title_string VARCHAR2 ) IS 
   p_alert_name varchar2(10) := 'AL_ERRINFO' ; 
   p_alert_id number;
BEGIN
   if upper(title_string)='ERROR' then
      p_alert_name := 'AL_ERRINFO' ; 
   else
      p_alert_name := 'AL_NOTE' ; 
   end if;
   set_alert_property(p_alert_name,TITLE,title_string);  
   set_alert_property(p_alert_name,alert_message_text,text_string);  
   p_alert_id := show_alert(p_alert_name); 
END;
```

#### SP-022 - GENERAL.L_POP_LIST_ITEM

**Invoked From:**

- pt_phy_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

ADJUSTMENT DETAILS (N/A / CN_ADJ); COUNT DETAILS (N/A / CN_MAIN)

---

**Purpose**

Populates a named Oracle Forms record group from a dynamic SQL query, ensuring any pre-existing group of the same name is removed before recreation. This procedure is called during form initialisation (WHEN-NEW-FORM-INSTANCE) to load list-of-values data for the ADJUSTMENT DETAILS and COUNT DETAILS screens.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_rg_name | VARCHAR2 | IN |
| p_select | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-044](#SP-044--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the record group name (p_rg_name) and the SQL select statement (p_select) as input parameters, and assign the group name to a local variable.
- Step 2 - Search for an existing Oracle Forms record group with the supplied name using Find_Group.
- Step 3 - If a matching record group is found (i.e. its ID is not null as evaluated via WEBUTIL.ID_NULL), delete it using Delete_Group to prevent duplicate group conflicts.
- Step 4 - Create a new record group from the supplied SQL query using Create_Group_From_Query, binding it to the same group name.
- Step 5 - Populate the newly created record group by executing the query via Populate_Group, loading the result set into the group for use by list items on the form.

---
**Decision Points**

DP-001

Condition: The record group identified by p_rg_name already exists in the current form session (Find_Group returns a non-null ID, verified via WEBUTIL.ID_NULL).

TRUE: The existing record group is deleted using Delete_Group before a new one is created, preventing name collisions.

FALSE: No deletion is performed; processing continues directly to Create_Group_From_Query.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A record group with the specified name must not persist from a prior execution; if one exists it is unconditionally removed before the new group is created, ensuring the list item always reflects the current query definition.
- BR-002 - The record group is always built dynamically from the SQL statement supplied in p_select; no hard-coded query is used, allowing the caller to control the data set loaded into the list item.
- BR-003 - Group population is performed immediately after creation within the same procedure call, so the record group is ready for binding to form list items upon return.

---
**Implementation Logic**

```plsql

PROCEDURE l_pop_list_item (p_rg_name VARCHAR2,p_select VARCHAR2 )IS

	 rg_name VARCHAR2(40) := p_rg_name;
	 rg_id RecordGroup;
	 errcode NUMBER; 
BEGIN 
	/* ** Make sure group doesn't already exist */ 
	rg_id := Find_Group( rg_name ); 

	IF NOT Id_Null(rg_id) THEN 
		delete_group(rg_id);
	END IF;
	/* ** If it does not exist, create it and add the two ** necessary columns to it. */ 
		rg_id := Create_Group_From_Query( rg_name, p_select); 
	 
	/* ** Populate the record group */ 
	errcode := Populate_Group( rg_id );
END;
```

#### SP-023 - GENERAL.PROC_REPORT_CALL

**Invoked From:**

- pt_phy_fmb.xml [ProgramUnit: CALL_REPORT_PR_INVENTORY]
- pt_phy_fmb.xml [ProgramUnit: CALL_REPORT_PR_PHY]
- pt_phy_fmb.xml [StoredProcedure: CALL_REPORT_PR_INVENTORY]
- pt_phy_fmb.xml [StoredProcedure: CALL_REPORT_PR_PHY]

---

**Screen:**

N/A

---

**Purpose**

Configures and submits an Oracle Reports object for batch execution, writing the output to a server-side file. The procedure sets all required report properties (execution mode, destination type, output file name, and report server), runs the report, and returns the asynchronous job handle and the generated output file name to the caller for subsequent print or status-tracking operations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| REPID | report_object | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| lv_report | varchar2 | OUT |
| lv_print | varchar2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Retrieve the report server name from the global variable ':global.rep_server' using NAME_IN and store it in a local variable.
- Step 2 - Construct a unique output file name by concatenating the current Oracle Forms username (GET_APPLICATION_PROPERTY(UserName)) with the current system date/time formatted as 'YYYYMMDDHHMISS', then append the '.rrpp' file extension.
- Step 3 - Set the report execution mode to BATCH on the supplied report object (REPID) using SET_REPORT_OBJECT_PROPERTY.
- Step 4 - Set the report destination type to FILE so that output is directed to the file system rather than a printer or screen.
- Step 5 - Set the report destination name to the fully qualified server-side path '/iashome/ias/reports/printer/' concatenated with the generated file name from Step 2.
- Step 6 - Set the report server property on the report object to the server name resolved in Step 1.
- Step 7 - Execute the report asynchronously by calling RUN_REPORT_OBJECT(REPID) and capture the returned job handle in the OUT parameter LV_REPORT.
- Step 8 - Assign the generated file name to the OUT parameter LV_PRINT so the caller can reference the output file for printing or further processing.

---
**Decision Points**

No conditional decision points are present in this procedure. All steps execute unconditionally in sequence.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The report server must be pre-populated in the global variable ':global.rep_server' before this procedure is invoked; the procedure reads this value directly and does not validate or default it.
- BR-002 - All reports submitted through this procedure are executed in BATCH mode with FILE as the destination type; interactive or printer-direct execution is not supported by this procedure.
- BR-003 - The output file name is guaranteed to be unique per invocation by combining the authenticated username with a date/time stamp (YYYYMMDDHHMISS), preventing file name collisions for concurrent report runs by the same or different users.
- BR-004 - All report output files are written to the fixed server-side directory '/iashome/ias/reports/printer/'; no alternative output path is permitted.
- BR-005 - The '.rrpp' file extension is always appended to the output file name, identifying the file as a Reports runtime output artifact.
- BR-006 - The procedure returns both the RUN_REPORT_OBJECT job handle (LV_REPORT) and the output file name (LV_PRINT) to the caller, enabling the invoking program units (CALL_REPORT_PR_INVENTORY and CALL_REPORT_PR_PHY) to monitor job status and locate the output file independently.

---
**Implementation Logic**

```plsql

PROCEDURE PROC_REPORT_CALL (REPID report_object, lv_report OUT varchar2, lv_print OUT varchar2) IS
      vcFile    VARCHAR2(225) := 'test';
      vcResult  VARCHAR2(30);
      lv_server VARCHAR2(1000);
    Begin
    	  lv_server := name_in(':global.rep_server');
        vcFile:= Get_Application_Property(UserName)||To_Char(Sysdate,'YYYYMMDDHHMISS');
        vcFile := vcFile||'.rrpp';
         Set_Report_Object_Property(repid,REPORT_EXECUTION_MODE,BATCH);
        Set_Report_Object_Property(repid,REPORT_DESTYPE,FILE);
      	set_report_object_property(repid,REPORT_DESNAME,'/iashome/ias/reports/printer/'||vcFile);
				Set_Report_Object_Property(repid,REPORT_SERVER,lv_server); --'mulreports
			  lv_report:= RUN_REPORT_OBJECT(repid);
			  lv_print := vcFile;			  
End;
```

#### SP-024 - GENERAL.PROC_TIMER

**Invoked From:**

- pt_phy_fmb.xml [ProgramUnit: CALL_REPORT_PR_INVENTORY]
- pt_phy_fmb.xml [ProgramUnit: CALL_REPORT_PR_PHY]
- pt_phy_fmb.xml [StoredProcedure: CALL_REPORT_PR_INVENTORY]
- pt_phy_fmb.xml [StoredProcedure: CALL_REPORT_PR_PHY]

---

**Screen:**

N/A

---

**Purpose**

Creates a repeating Oracle Forms timer named PRINTER_QUEUE with a 5000-millisecond (5-second) interval. This timer is used to support deferred or polled processing for physical inventory report print jobs, as invoked from the inventory and physical report print routines in pt_phy_fmb.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Declare a local TIMER handle variable (hTimer) to hold the reference to the newly created timer.
- Step 2 - Invoke the Oracle Forms built-in CREATE_TIMER to instantiate a timer named 'PRINTER_QUEUE' with a firing interval of 5000 milliseconds (5 seconds) and a repeat mode of REPEAT, meaning the timer will fire continuously at each 5-second interval until explicitly deleted.
- Step 3 - Assign the returned timer handle to hTimer (handle is local and not returned to the caller; the timer is managed by the Forms runtime).

---
**Decision Points**

No conditional decision points exist in this procedure. The CREATE_TIMER call is executed unconditionally each time the procedure is invoked.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The printer queue timer must be named exactly 'PRINTER_QUEUE' to ensure that the corresponding WHEN-TIMER-EXPIRED trigger in the calling form can identify and respond to it correctly.
- BR-002 - The timer interval must be set to 5000 milliseconds (5 seconds), establishing the polling frequency for print queue processing.
- BR-003 - The timer must be created in REPEAT mode so that it continues to fire at each 5-second interval without requiring manual re-creation after each expiry.
- BR-004 - This procedure must be called prior to initiating a print report action (CALL_REPORT_PR_INVENTORY or CALL_REPORT_PR_PHY) so that the timer is active during the print queue monitoring period.

---
**Implementation Logic**

```plsql
PROCEDURE PROC_TIMER IS
  hTimer    TIMER;
 begin
  hTimer := CREATE_TIMER('PRINTER_QUEUE','5000',REPEAT);
 end;
```

#### SP-025 - GENERAL.PROC_TIMER_EXPIRED

**Invoked From:**

- pt_phy_fmb.xml [Trigger: WHEN-TIMER-EXPIRED]

---

**Screen:**

N/A

---

**Purpose**

Handles the WHEN-TIMER-EXPIRED trigger for the physical therapy screen by monitoring the status of an asynchronous report job submitted to the Oracle Reports server. When the timer named PRINTER_QUEUE fires, the procedure checks the current run-time status of the report identified by the global report handle. If the report has finished successfully, it opens the generated print output document in a new browser window and cancels the timer. If the report has encountered an error, it notifies the user and cancels the timer. If the report is still in progress, the timer is left active to fire again.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-021](#SP-021--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Retrieve the name of the expired timer using GET_APPLICATION_PROPERTY(TIMER_NAME) and store it in vcTimerName.
- Step 2 - Read the global report handle from :GLOBAL.REPORTHANDLE and the print output path from :GLOBAL.PRINTOUTPUT into local variables.
- Step 3 - Evaluate whether the expired timer is named PRINTER_QUEUE; all processing is conditional on this match.
- Step 4 - Call REPORT_OBJECT_STATUS with the global report handle to obtain the current execution status of the submitted report job.
- Step 5 - If the status is RUNNING, OPENING_REPORT, or ENQUEUED, take no action (NULL), allowing the timer to continue firing on its next interval.
- Step 6 - If the status is FINISHED, invoke WEB.SHOW_DOCUMENT to open the print output URL ('/printer/' concatenated with the PRINTOUTPUT global) in a new browser window (_blank), then delete the PRINTER_QUEUE timer.
- Step 7 - For any other status (indicating a report failure), call GENERAL.DISP_TEXT to display the message 'Unable to generate the report' with severity 'Error', then delete the PRINTER_QUEUE timer.

---
**Decision Points**

DP-001

Condition:
vcTimerName = 'PRINTER_QUEUE'

TRUE:
Proceed to check the report object status and take the appropriate action.

FALSE:
No action is taken; the procedure exits without processing.

---

DP-002

Condition:
vcStatus IN ('RUNNING', 'OPENING_REPORT', 'ENQUEUED')

TRUE:
The report is still in progress; no action is taken (NULL) and the timer remains active.

FALSE:
Evaluate further whether the report has finished or failed (see DP-003).

---

DP-003

Condition:
vcStatus = 'FINISHED'

TRUE:
Open the print output document in a new browser window via WEB.SHOW_DOCUMENT using the path '/printer/' || lv_printout, then delete the PRINTER_QUEUE timer.

FALSE:
The report ended in an error state; call GENERAL.DISP_TEXT to display 'Unable to generate the report' with severity 'Error', then delete the PRINTER_QUEUE timer.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only the timer named PRINTER_QUEUE is handled by this procedure; any other expired timer is silently ignored.
- BR-002 - The report handle used to query job status must be stored in the global variable :GLOBAL.REPORTHANDLE prior to the timer firing; the procedure reads it directly without validation.
- BR-003 - While the report status is RUNNING, OPENING_REPORT, or ENQUEUED, the timer is intentionally left alive so that subsequent timer expirations will re-check the status until a terminal state is reached.
- BR-004 - A successfully finished report is rendered by opening the URL '/printer/' concatenated with the value of :GLOBAL.PRINTOUTPUT in a new browser window; the timer is then deleted to stop further polling.
- BR-005 - Any report status other than the three in-progress states and FINISHED is treated as a failure; the user is informed via GENERAL.DISP_TEXT with the message 'Unable to generate the report' and severity 'Error', and the timer is deleted.
- BR-006 - The PRINTER_QUEUE timer must be explicitly deleted (DELETE_TIMER) upon reaching any terminal report state (FINISHED or error) to prevent continued polling after processing is complete.

---
**Implementation Logic**

```plsql
PROCEDURE PROC_TIMER_EXPIRED IS
	vcStatus varchar2(50);
	vcTimerName varchar2(30);
	hTimer timer;
	report_id report_object;
  lv_report_handle varchar2(4000);
  lv_printout      varchar2(4000);
begin
	vcTimerName := get_application_property(timer_name);
   			lv_report_handle := name_in(':global.reporthandle');
        lv_printout      := name_in(':GLOBAL.PRINTOUTPUT');
 
	if vcTimerName = 'PRINTER_QUEUE' then
		 vcStatus := REPORT_OBJECT_STATUS(lv_report_handle);
	   if vcStatus in ('RUNNING','OPENING_REPORT','ENQUEUED') THEN
	   	  NULL;
	   ELSIF VCsTATUS = 'FINISHED' THEN
        web.show_document('/printer/'||lv_printout ,'_blank');
--        web.show_document('/reports/rwservlet/getjobid'||substr(:global.reporthandle,instr(:global.reporthandle,'_',-1)+1)||'?'||'server=mulreports'||:GLOBAL.PRINTOUTPUT,'_blank');
--        web.show_document('/reports/rwservlet/getjobid'||substr(lv_rep,instr(lv_rep,'_',-1)+1)||'?'||'server='||lv_server,'_blank');
        delete_timer(vcTimerName);
	   ELSE
--	   	  general.disp_text('Unable to generate the report'||vcStatus,'Error');
        general.disp_text('Unable to generate the report','Error');
	   	  delete_timer(vcTimerName);
	   end if;
	end if;   
end;
```

#### SP-026 - GENERAL.RAISE_ERROR

**Invoked From:**

- pt_phy_fmb.xml [Trigger: ON-ERROR]

---

**Screen:**

N/A

---

**Purpose**

Centralises Oracle Forms error-handling by classifying an incoming message code, constructing a display-ready message string, and presenting it to the user via GENERAL.DISP_TEXT with an appropriate severity title. For Error-class messages the procedure also halts further form processing by raising FORM_TRIGGER_FAILURE. The procedure is invoked from the ON-ERROR trigger of pt_phy_fmb.xml.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| mesg_code | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-021](#SP-021--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message code (mesg_code) passed in by the ON-ERROR trigger.
- Step 2 - Concatenate mesg_code with the (currently unresolved) mesg_text to form the full display string in the format 'mesg_code : mesg_text'.
- Step 3 - Evaluate the mesg_type value to determine message severity (see Decision Points).
- Step 4 - For Error type ('E'): set the title to 'Error', call GENERAL.DISP_TEXT to present the message, then raise FORM_TRIGGER_FAILURE to abort the current form trigger chain.
- Step 5 - For Note type ('N'): set the title to 'Note' and call GENERAL.DISP_TEXT to present the message; processing continues normally.
- Step 6 - For Caution type ('C'): set the title to 'Caution' and call GENERAL.DISP_TEXT to present the message; processing continues normally.
- Step 7 - If mesg_type does not match 'E', 'N', or 'C', no display action is taken and the procedure exits silently.

---
**Decision Points**

DP-001

Condition:
mesg_type = 'E' (Error severity)

TRUE:
Set mesg_title to 'Error', invoke GENERAL.DISP_TEXT(mesg_text, mesg_title) to display the error message, then raise FORM_TRIGGER_FAILURE to halt the current trigger execution.

FALSE:
Proceed to DP-002.

---

DP-002

Condition:
mesg_type = 'N' (Note severity)

TRUE:
Set mesg_title to 'Note' and invoke GENERAL.DISP_TEXT(mesg_text, mesg_title) to display the informational message; form processing continues.

FALSE:
Proceed to DP-003.

---

DP-003

Condition:
mesg_type = 'C' (Caution severity)

TRUE:
Set mesg_title to 'Caution' and invoke GENERAL.DISP_TEXT(mesg_text, mesg_title) to display the caution message; form processing continues.

FALSE:
No matching severity type; the procedure exits without displaying a message or raising an exception.

---
**Database Interactions**

- DB-001 - Read AM_PERMISSIONS - Reads data from AM_PERMISSIONS for lookup or validation.
**Business Rules**

- BR-001 - The full message presented to the user must be composed by concatenating the message code and the message text in the format 'mesg_code : mesg_text', ensuring the originating code is always visible to the user.
- BR-002 - A message classified as Error type ('E') must unconditionally raise FORM_TRIGGER_FAILURE after display, preventing any further processing in the invoking trigger.
- BR-003 - A message classified as Note type ('N') or Caution type ('C') must be displayed to the user via GENERAL.DISP_TEXT but must not interrupt form processing.
- BR-004 - Only the three recognised severity types ('E', 'N', 'C') produce a user-visible response; unrecognised or null severity values result in silent exit with no message displayed and no exception raised.
- BR-005 - All user-facing message display must be delegated exclusively to GENERAL.DISP_TEXT (SP-021); no direct Oracle Forms alert or message calls are permitted within this procedure.

---
**Implementation Logic**

```plsql
PROCEDURE RAISE_ERROR ( mesg_code IN VARCHAR2 )IS
  mesg_type  varchar2(7); 
  mesg_text  varchar2(200) ;
  mesg_title varchar2(7);
  BEGIN
     -- murali 17.05.04 GENERAL.get_message(mesg_code,mesg_text,mesg_type );
     mesg_text:=mesg_code||' : '||mesg_text;		
     IF ( mesg_type = 'E' ) THEN
        mesg_title := 'Error' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
        raise FORM_TRIGGER_FAILURE;
     ELSIF ( mesg_type = 'N' ) THEN
        mesg_title := 'Note' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     ELSIF ( mesg_type = 'C' ) THEN
        mesg_title := 'Caution' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     END IF;
  END;     

/* PROCEDURE check_rights( 
pi_form_name in varchar2,
pi_user_id in number) IS
lv_x varchar2(1);
BEGIN
	
	begin
	SELECT substr(access_string, pi_user_id,1) 
	INTO   lv_x
	FROM   	am_permissions
	WHERE  form_name = pi_form_name
	AND SUBSTR(access_string,pi_user_id,1)='Y';
	exception 
		when no_data_found then
		  general.disp_text('You do not have the Permission to access this.','Error rr');
		  raise form_trigger_failure; 
		when too_many_rows then
		  general.disp_text('Many rows in USER_PERMISSIONS','Error ss');
		  raise form_trigger_failure;
		when others then
		       general.disp_text(sqlerrm,'Error mm');
		       raise form_trigger_failure;
	end;

	open_form(pi_form_name,activate,session);
END;
*/
```

#### SP-027 - PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM

**Invoked From:**

- pt_phy_fmb.xml [Trigger: FT_SAVE]
- pt_phy_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

ADJUSTMENT DETAILS (N/A / CN_ADJ); COUNT DETAILS (N/A / CN_MAIN); PART DETAILS (N/A / CN_MAIN)

---

**Purpose**

Generates and reserves the next sequential document number for a given dealer, principal, location, company, document type, and financial year. The procedure locks the relevant row in AM_DOCS to prevent concurrent number assignment, increments the stored sequence counter, formats the output document number, and persists the updated counter and document date back to AM_DOCS.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| pi_dealer_map_cd | NUMBER | IN |
| pi_principal_map_cd | NUMBER | IN |
| pi_loc_cd | VARCHAR2 | IN |
| pi_comp_fa | VARCHAR2 | IN |
| pi_doc_type | VARCHAR2 | IN |
| pi_fin_yr | NUMBER | IN |
| pi_last_doc_date | DATE | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| po_doc_num | VARCHAR2 | OUT |
| po_err_msg | VARCHAR2 | OUT |
| po_error | NUMBER | OUT |

---

**Dependencies**

- WEBUTIL.PUT_LINE ([SP-047](#SP-047--WEBUTIL.PUT_LINE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.WAIT ([SP-052](#SP-052--WEBUTIL.WAIT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept all input parameters: dealer map code, principal map code, location code, company/FA indicator, document type, financial year, and last document date (defaulting to SYSDATE if not supplied).
- Step 2 - Attempt to lock the matching AM_DOCS row using SELECT ... FOR UPDATE WAIT 5, retrieving the document prefix, current document number, document suffix, and ROWID.
- Step 3 - Handle exceptions from the lock/select attempt: if no row is found, set po_error = 1 with message 'Type not defined in the document master'; if multiple rows are found, set po_error = 1 with message 'Duplicate rows in the document master'; if Oracle error -54 (resource busy) is raised, set po_error = 1 with message 'Record is used by another user. Please Re-try'; for any other error, set po_error = 1 with the SQLERRM detail.
- Step 4 - If no error was recorded (NVL(po_error, 0) <> 1), increment the retrieved document number by 1.
- Step 5 - Format the output document number by concatenating the document prefix, document suffix, and the incremented number left-padded to six digits with zeros (e.g. PREFIX || SUFFIX || '000001').
- Step 6 - Update AM_DOCS using the captured ROWID, writing the new document number and the supplied pi_last_doc_date.
- Step 7 - Return po_doc_num (formatted document number), po_error (0 = success, 1 = failure), and po_err_msg (error description if applicable) to the caller.

---
**Decision Points**

DP-001

Condition:
The SELECT ... FOR UPDATE WAIT 5 against AM_DOCS returns exactly one row within 5 seconds.

TRUE:
The document prefix, current number, suffix, and ROWID are captured; processing continues to DP-002.

FALSE:
An exception is raised - NO_DATA_FOUND sets po_error = 1 ('Type not defined in the document master'); TOO_MANY_ROWS sets po_error = 1 ('Duplicate rows in the document master'); SQLCODE -54 (lock timeout) sets po_error = 1 ('Record is used by another user. Please Re-try'); any other error sets po_error = 1 with SQLERRM detail. Processing stops and error outputs are returned.

---

DP-002

Condition:
NVL(po_error, 0) <> 1 (i.e., the lock/select step completed without error).

TRUE:
The document number is incremented, the formatted po_doc_num is constructed, and AM_DOCS is updated with the new number and last document date.

FALSE:
The increment and update steps are skipped; the previously set error code and message are returned to the caller as-is.

---
**Database Interactions**

- DB-001 - Read AM_DOCS - Reads data from AM_DOCS (columns: doc num, last doc date) for lookup or validation.
- DB-002 - Update WAIT - Updates existing rows in WAIT.
- DB-003 - Update AM_DOCS - Updates existing rows in AM_DOCS (columns: doc num, last doc date).
**Business Rules**

- BR-001 - Each combination of dealer map code, principal map code, location code, company/FA indicator, document type, and financial year must have exactly one row in AM_DOCS; the absence of a matching row is treated as a configuration error ('Type not defined in the document master').
- BR-002 - Duplicate rows in AM_DOCS for the same key combination are not permitted; if detected, the procedure raises an error ('Duplicate rows in the document master') and does not generate a number.
- BR-003 - The AM_DOCS row must be exclusively locked before the number is incremented to prevent duplicate document numbers being issued to concurrent users; the procedure waits up to 5 seconds for the lock before reporting 'Record is used by another user. Please Re-try'.
- BR-004 - The formatted document number is composed as: document prefix + document suffix + numeric counter left-padded to six digits with zeros, ensuring a consistent and fixed-length document number format.
- BR-005 - The document sequence counter in AM_DOCS is always incremented by exactly 1 per successful call, guaranteeing gapless sequential numbering within a financial year for the given key.
- BR-006 - The last document date recorded in AM_DOCS is updated to the value supplied in pi_last_doc_date (defaulting to SYSDATE), maintaining an audit trail of when the most recent document number was issued.
- BR-007 - A number is generated and AM_DOCS is updated only when no error condition exists; any failure during the lock or validation phase suppresses the update entirely, preserving data integrity.

---
**Implementation Logic**

```plsql
      PROCEDURE Generate_Next_Num (
            pi_dealer_map_cd      IN       NUMBER,
            pi_principal_map_cd   IN       NUMBER,
            pi_loc_cd             IN       VARCHAR2,
            pi_comp_fa            IN       VARCHAR2,
            pi_doc_type           IN       VARCHAR2,
            po_doc_num            OUT      VARCHAR2,
            po_err_msg            OUT      VARCHAR2,
            po_error              OUT      NUMBER,
            pi_fin_yr             IN       NUMBER,
            pi_last_doc_date      IN       DATE DEFAULT SYSDATE
      )
      IS
            lv_doc_prefix   VARCHAR2 (4);
            lv_doc_num      NUMBER (6);
            lv_doc_suffix   VARCHAR2 (2);
            lock_found      EXCEPTION;
            lv_year         VARCHAR2 (1);
            lv_rowid        ROWID;
            PRAGMA EXCEPTION_INIT (lock_found, -54);
            v_sql           VARCHAR2 (2000);
      BEGIN

            BEGIN

                  SELECT     doc_prefix,
                             doc_num,
                             doc_suffix,
                             ROWID
                        INTO lv_doc_prefix,
                             lv_doc_num,
                             lv_doc_suffix,
                             lv_rowid
                        FROM AM_DOCS
                       WHERE dealer_map_cd = pi_dealer_map_cd
                         AND principal_map_cd = pi_principal_map_cd
                         AND loc_cd = pi_loc_cd
                         AND comp_fa = pi_comp_fa
                         AND doc_type = pi_doc_type
                         AND Fin_Year = pi_fin_yr
                  FOR UPDATE WAIT 5;
            EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                        po_error := 1;
                        po_err_msg := po_err_msg || ' Type not defined in the document master';
                  WHEN TOO_MANY_ROWS THEN
                        po_error := 1;
                        po_err_msg := po_err_msg || ' Duplicate rows in the document master';
                  WHEN OTHERS THEN
                        po_error := 1;

                        IF SQLCODE = -54 THEN                                                             ---IN (-30006,-54) THEN
                              po_err_msg := 'Record is used by another user.Please Re-try';
                        ---RAISE_APPLICATION_ERROR(-54,'Record is used by another user.Please Re-try');
                        ELSE
                              po_err_msg := 'Execution failed while trying to access the record ' || SQLERRM;
                        END IF;
            END;

            /*EXECUTE IMMEDIATE v_sql
                         INTO lv_doc_prefix,
                              lv_doc_num,
                              lv_doc_suffix,
                              lv_rowid
                        USING pi_dealer_map_cd, pi_principal_map_cd, pi_loc_cd, pi_comp_fa, pi_doc_type, pi_fin_yr;*/
            IF NVL ( po_error, 0) <> 1 THEN
                  lv_doc_num := lv_doc_num + 1;
                  po_doc_num := lv_doc_prefix || lv_doc_suffix || LPAD (lv_doc_num, 6, '0');

                  UPDATE AM_DOCS
                     SET doc_num = lv_doc_num,
                         last_doc_date = pi_last_doc_date
                   WHERE ROWID = lv_rowid;
            END IF;
      EXCEPTION
            WHEN NO_DATA_FOUND THEN
                  po_error := 1;
                  po_err_msg := po_err_msg || ' Type not defined in the document master';
            WHEN TOO_MANY_ROWS THEN
                  po_error := 1;
                  po_err_msg := po_err_msg || ' Duplicate rows in the document master';
            WHEN OTHERS THEN
                  po_error := 1;
                  po_err_msg := po_err_msg || SQLERRM;
                  DBMS_OUTPUT.put_line ('ERRORCD' || po_error);
      END Generate_Next_Num;
```

#### SP-028 - PK_VALIDATE_BACK_DATE.GET_LAST_DOC_DATE

**Invoked From:**

- pt_phy_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

COUNT DETAILS (N/A / CN_MAIN)

---

**Purpose**

Retrieves the last recorded document date for a specific dealer, principal, location, company, document type, and financial year from the AM_DOCS master table, then validates that the incoming transaction date is not earlier than that last document date. The result is communicated to the caller exclusively through an output error message parameter; a NULL value indicates the date is acceptable.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| pi_dealer_map_cd | NUMBER | IN |
| pi_principal_map_cd | NUMBER | IN |
| pi_loc_cd | VARCHAR2 | IN |
| pi_comp_fa | VARCHAR2 | IN |
| pi_doc_type | VARCHAR2 | IN |
| pi_fin_yr | NUMBER | IN |
| pi_doc_date | DATE | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| po_err_msg | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Initialise the output parameter po_err_msg to NULL, indicating no error at the start of processing.
- Step 2 - Query AM_DOCS to retrieve the last_doc_date for the exact combination of pi_dealer_map_cd, pi_principal_map_cd, pi_loc_cd, pi_comp_fa, pi_doc_type, and pi_fin_yr.
- Step 3 - If the retrieved lv_last_doc_date is NOT NULL, compare it against the incoming pi_doc_date.
- Step 4 - If pi_doc_date is earlier than lv_last_doc_date, populate po_err_msg with a message stating the current transaction date cannot be less than the last document date (formatted as DD-MM-RRRR HH24:MI:SS).
- Step 5 - If pi_doc_date is greater than or equal to lv_last_doc_date, or if lv_last_doc_date is NULL, leave po_err_msg as NULL, signalling that the date is valid.
- Step 6 - Handle exceptions: set po_err_msg to a descriptive message for NO_DATA_FOUND (document type not defined in master), TOO_MANY_ROWS (duplicate rows in master), or any other unexpected error (SQLERRM), and write the error to DBMS_OUTPUT for the OTHERS case.

---
**Decision Points**

DP-001

Condition:
Does the SELECT against AM_DOCS return exactly one matching row?

TRUE:
Processing continues; lv_last_doc_date is populated and the date comparison logic (DP-002) is evaluated.

FALSE:
An exception is raised - NO_DATA_FOUND sets po_err_msg to 'Doc Type not defined in the document master'; TOO_MANY_ROWS sets po_err_msg to 'Duplicate rows in the document master'; any other exception sets po_err_msg to SQLERRM.

---

DP-002

Condition:
Is lv_last_doc_date NOT NULL?

TRUE:
The back-date comparison is performed (DP-003).

FALSE:
No date comparison is made; po_err_msg remains NULL and the procedure exits without error.

---

DP-003

Condition:
Is pi_doc_date less than lv_last_doc_date?

TRUE:
po_err_msg is set to 'Current Transcation date cannot be Less than <lv_last_doc_date formatted as DD-MM-RRRR HH24:MI:SS>', indicating a back-date violation.

FALSE:
po_err_msg remains NULL; the transaction date is acceptable.

---
**Database Interactions**

- DB-001 - Read AM_DOCS - Reads data from AM_DOCS for lookup or validation.
**Business Rules**

- BR-001 - A document type must exist in the AM_DOCS master for the given combination of dealer, principal, location, company, and financial year; if no matching record is found, the transaction is rejected with the message 'Doc Type not defined in the document master'.
- BR-002 - The AM_DOCS master must not contain duplicate rows for the same dealer, principal, location, company, document type, and financial year combination; if duplicates exist, the transaction is rejected with the message 'Duplicate rows in the document master'.
- BR-003 - A transaction date (pi_doc_date) must not be earlier than the last recorded document date (last_doc_date) held in AM_DOCS for the matching record; back-dating below this threshold is prohibited.
- BR-004 - If the last_doc_date stored in AM_DOCS is NULL, no back-date restriction is enforced and the transaction date is unconditionally accepted.
- BR-005 - The error message for a back-date violation must include the last document date formatted as DD-MM-RRRR HH24:MI:SS to provide the user with the precise lower-bound date they may not breach.

---
**Implementation Logic**

```plsql

      PROCEDURE get_last_doc_date (
            pi_dealer_map_cd      IN       NUMBER,
            pi_principal_map_cd   IN       NUMBER,
            pi_loc_cd             IN       VARCHAR2,
            pi_comp_fa            IN       VARCHAR2,
            pi_doc_type           IN       VARCHAR2,
            pi_fin_yr             IN       NUMBER,
            pi_doc_date           IN       DATE,
            po_err_msg            OUT      VARCHAR2
      )
      IS
            lv_last_doc_date   DATE;
      BEGIN
            po_err_msg := NULL;

            SELECT last_doc_date
              INTO lv_last_doc_date
              FROM AM_DOCS
             WHERE dealer_map_cd = pi_dealer_map_cd
               AND principal_map_cd = pi_principal_map_cd
               AND loc_cd = pi_loc_cd
               AND comp_fa = pi_comp_fa
               AND doc_type = pi_doc_type
               AND Fin_Year = pi_fin_yr;

            IF lv_last_doc_date IS NOT NULL THEN
                  IF pi_doc_date < lv_last_doc_date THEN
                        po_err_msg :=
                                 'Current Transcation date cannot be Less than '
                              || TO_CHAR (lv_last_doc_date, 'DD-MM-RRRR HH24:MI:SS');
                        NULL;
                  END IF;
            END IF;
      EXCEPTION
            WHEN NO_DATA_FOUND THEN
                  po_err_msg := 'Doc Type not defined in the document master';
            WHEN TOO_MANY_ROWS THEN
                  po_err_msg := 'Duplicate rows in the document master';
            WHEN OTHERS THEN
                  po_err_msg := SQLERRM;
                  DBMS_OUTPUT.put_line ('ERRORMSG' || po_err_msg);
      END get_last_doc_date;
```

#### SP-029 - WEBUTIL.BLOCKING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.HOST]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Executes a host operating-system command in blocking mode, meaning the calling process waits for the command to complete before control is returned. The procedure delegates execution to WEBUTIL.EXECUTE (SP-035), passing the supplied command string together with the BLOCKING_MODE constant to enforce synchronous behaviour.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.EXECUTE ([SP-035](#SP-035--WEBUTIL.EXECUTE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the operating-system command string (cmd) as input.
- Step 2 - Invoke WEBUTIL.EXECUTE (SP-035) with the provided cmd value and the predefined BLOCKING_MODE constant.
- Step 3 - Return the PROCESS_ID value produced by WEBUTIL.EXECUTE to the caller, representing the completed process handle.

---
**Decision Points**

No conditional decision points exist within this procedure. Execution follows a single, unconditional path: delegate to WEBUTIL.EXECUTE with BLOCKING_MODE and return the resulting PROCESS_ID.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The command must be executed synchronously; BLOCKING_MODE is always passed to WEBUTIL.EXECUTE, ensuring the caller waits for process completion before proceeding.
- BR-002 - Command execution is fully delegated to WEBUTIL.EXECUTE (SP-035); WEBUTIL.BLOCKING does not perform any direct host interaction itself.
- BR-003 - The function returns a PROCESS_ID, which represents the identifier of the completed blocking process and must be propagated back to the invoking context (WEBUTIL.HOST).

---
**Implementation Logic**

```plsql
  
  FUNCTION  Blocking(cmd in VARCHAR2) return PROCESS_ID is
  begin
    return Execute(cmd,BLOCKING_MODE);
  end Blocking;
```

#### SP-030 - WEBUTIL.CLEARCALLBACKTRIGGER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.RELEASE_PROCESS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Removes a registered callback entry from the internal callbacks collection using the provided key. This procedure ensures that a previously registered callback trigger is cleanly de-registered, preventing stale or orphaned callback references from persisting in the session state after a process has been released.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| callbackKey | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the integer key identifying the callback entry to be removed.
- Step 2 - Check whether an entry with the supplied key currently exists in the internal callbacks collection (m_callbacks).
- Step 3 - If the entry exists, delete it from the collection, effectively de-registering the callback trigger.
- Step 4 - If the entry does not exist, take no action and exit silently.

---
**Decision Points**

DP-001

Condition: The key supplied in callbackKey exists in the m_callbacks collection (m_callbacks.exists(callbackKey) evaluates to TRUE).

TRUE: The corresponding entry is deleted from m_callbacks, removing the callback registration.

FALSE: No action is taken; the procedure exits without modifying the collection.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must only attempt to delete a callback entry if it is confirmed to exist in the collection; deletion of a non-existent key is not performed, preventing runtime errors.
- BR-002 - The callbackKey parameter uniquely identifies a single callback entry within the m_callbacks collection; only the entry matching that exact key is removed.
- BR-003 - The procedure produces no output and raises no exception when the specified key is absent, ensuring safe invocation regardless of prior collection state.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ClearCallbackTrigger(callbackKey in PLS_INTEGER) is
  begin
    if m_callbacks.exists(callbackKey) then 
      m_callbacks.delete(callbackKey);  
    end if;
  end ClearCallbackTrigger;
```

#### SP-031 - WEBUTIL.DOWNLOADFROMURL

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.URL_TO_CLIENT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Initiates a file download from a specified URL to a client-side destination path. The procedure acts as a simplified public entry point that delegates to the internal implementation WEBUTIL.DOWNLOADFROMURLINT, supplying fixed default values for advanced options (byte offset, overwrite flag, and credential parameters) so that callers need only provide the source URL, destination path, and optional file size.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| fileSize | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.DOWNLOADFROMURLINT ([SP-032](#SP-032--WEBUTIL.DOWNLOADFROMURLINT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the source URL, client destination path, and optional file size (defaulting to 0 if not supplied) as input parameters.
- Step 2 - Invoke WEBUTIL.DOWNLOADFROMURLINT, passing the source URL and client destination path directly from the caller's inputs.
- Step 3 - Pass a hard-coded byte offset of 0 to WEBUTIL.DOWNLOADFROMURLINT, indicating that the download should begin from the start of the file.
- Step 4 - Pass the received file size value to WEBUTIL.DOWNLOADFROMURLINT to allow the internal routine to manage transfer size expectations.
- Step 5 - Pass a hard-coded overwrite flag of FALSE to WEBUTIL.DOWNLOADFROMURLINT, suppressing any overwrite behaviour by default.
- Step 6 - Pass NULL values for all credential-related parameters (three NULL arguments) to WEBUTIL.DOWNLOADFROMURLINT, indicating that no authentication context is provided.
- Step 7 - Return the BOOLEAN result produced by WEBUTIL.DOWNLOADFROMURLINT directly to the caller, indicating whether the download succeeded.

---
**Decision Points**

DP-001

Condition: Whether a fileSize value is explicitly supplied by the caller.

TRUE: The provided fileSize value is forwarded to WEBUTIL.DOWNLOADFROMURLINT to inform the download operation of the expected file size.

FALSE: fileSize defaults to 0, and this default value is forwarded to WEBUTIL.DOWNLOADFROMURLINT, leaving file size management to the internal routine's own handling of a zero value.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The download always begins at byte offset 0; partial or resumable downloads are not supported through this public entry point.
- BR-002 - Overwrite behaviour is disabled by default; the overwrite flag is hard-coded to FALSE when delegating to WEBUTIL.DOWNLOADFROMURLINT.
- BR-003 - No authentication credentials are accepted or forwarded by this entry point; all credential parameters passed to WEBUTIL.DOWNLOADFROMURLINT are fixed as NULL.
- BR-004 - The fileSize parameter defaults to 0 if not provided by the caller, signalling to WEBUTIL.DOWNLOADFROMURLINT that the file size is unspecified.
- BR-005 - The success or failure of the download operation is determined solely by the BOOLEAN value returned by WEBUTIL.DOWNLOADFROMURLINT and is passed back unchanged to the caller.

---
**Implementation Logic**

```plsql
  
  FUNCTION DownLoadFromURL(sourceURL         in VARCHAR2, 
                           clientDestination in VARCHAR2, 
                           fileSize          in PLS_INTEGER default 0) return BOOLEAN is
  BEGIN
    return DownLoadFromURLInt(sourceURL,
                              ClientDestination,
                              0,
                              fileSize,
                              false,
                              null,
                              null,
                              null);
  END DownLoadFromURL;
```

#### SP-032 - WEBUTIL.DOWNLOADFROMURLINT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.DOWNLOADFROMURL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Constructs and submits a download request to the WebUtil client-side bean, instructing it to retrieve a file from a given URL and save it to a specified client destination. The function assembles a pipe-delimited parameter string that encodes destination type, expected file size, progress-display preferences, and path information, then dispatches the request through the WebUtil Core property mechanism and returns a BOOLEAN indicating whether the download succeeded.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| specialDestination | PLS_INTEGER | IN |
| fileSize | PLS_INTEGER | IN |
| withProgress | BOOLEAN | IN |
| progressTitle | VARCHAR2 | IN |
| progressSubTitle | VARCHAR2 | IN |
| progressMessage | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERROR ([SP-033](#SP-033--WEBUTIL.ERROR)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Validate that sourceURL is not null; if null, raise the URL_NULL exception.
- Step 2 - Validate that clientDestination is not null; if null, raise the CLIENT_FILE_NULL exception.
- Step 3 - Evaluate specialDestination: if null, negative, or greater than 2, default the value to '0'; otherwise convert the supplied integer to a character. Append the result followed by a pipe separator to the submitString.
- Step 4 - Evaluate fileSize: if null, append '0' followed by a pipe separator; otherwise convert the supplied integer to a character and append it with a pipe separator.
- Step 5 - Evaluate withProgress: if null or FALSE, append 'N' followed by a pipe separator; if TRUE, append 'Y' followed by a pipe separator.
- Step 6 - Concatenate the remaining fields to submitString in order: sourceURL, clientDestination, progressTitle (defaulting to a single space if null), progressSubTitle (defaulting to a single space if null), and progressMessage (defaulting to a single space if null), each separated by the pipe delimiter.
- Step 7 - Submit the assembled string to the WebUtil Core bean by calling WebUtil_Core.setProperty with the WUC_PACKAGE package identifier and the 'WUC_URL_DOWNLOAD' property key.
- Step 8 - Retrieve the result of the download operation by calling WebUtil_Core.getProperty with the same package identifier and property key.
- Step 9 - Return TRUE if the retrieved result string equals 'TRUE'; otherwise return FALSE.

---
**Decision Points**

DP-001

Condition: sourceURL IS NULL

TRUE: Raise the URL_NULL exception, which is caught in the exception block; WebUtil_Core.Error is called with error code 25 and the calling context 'WEBUTIL_CORE.DownloadFromURLInt', and the function returns FALSE.

FALSE: Continue processing to the next validation step.

---

DP-002

Condition: clientDestination IS NULL

TRUE: Raise the CLIENT_FILE_NULL exception, which is caught in the exception block; WebUtil_Core.Error is called with error code 130 and the calling context 'WEBUTIL_CORE.DownloadFromURLInt', and the function returns FALSE.

FALSE: Continue processing to build the submitString.

---

DP-003

Condition: specialDestination IS NULL OR specialDestination < 0 OR specialDestination > 2

TRUE: Use the default value '0' for the specialDestination segment of submitString.

FALSE: Convert specialDestination to its character representation and use it in submitString.

---

DP-004

Condition: fileSize IS NULL

TRUE: Use '0' for the fileSize segment of submitString.

FALSE: Convert fileSize to its character representation and use it in submitString.

---

DP-005

Condition: withProgress IS NULL OR withProgress = FALSE

TRUE: Append 'N' to the progress segment of submitString.

FALSE (withProgress = TRUE): Append 'Y' to the progress segment of submitString.

---

DP-006

Condition: WebUtil_Core.BEAN_NOT_REGISTERED exception raised during property set/get

TRUE: Display an alert identifying the missing bean class and the failing routine, then raise FORM_TRIGGER_FAILURE to halt form processing.

FALSE: Continue normal execution path.

---

DP-007

Condition: WebUtil_Core.PROPERTY_ERROR exception raised during property set/get

TRUE: Raise FORM_TRIGGER_FAILURE to halt form processing.

FALSE: Continue normal execution path.

---

DP-008

Condition: The result string returned by WebUtil_Core.getProperty equals 'TRUE'

TRUE: Return TRUE, indicating the download completed successfully.

FALSE: Return FALSE, indicating the download did not complete successfully.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A source URL must be provided; a null sourceURL is not permitted and will cause the function to return FALSE after logging error code 25.
- BR-002 - A client destination path must be provided; a null clientDestination is not permitted and will cause the function to return FALSE after logging error code 130.
- BR-003 - The specialDestination value must be in the range 0-2 inclusive; any null, negative, or out-of-range value is silently coerced to 0 before submission.
- BR-004 - A null fileSize is treated as 0 (unknown or unspecified size) for the purpose of the download request.
- BR-005 - Progress display is opt-in; withProgress defaults to FALSE ('N'), and a null value is treated identically to FALSE.
- BR-006 - Null progress label fields (progressTitle, progressSubTitle, progressMessage) are substituted with a single space character to preserve the integrity of the pipe-delimited submitString structure.
- BR-007 - If the WebUtil bean is not registered on the client, the function raises FORM_TRIGGER_FAILURE after alerting the user, preventing silent failure.
- BR-008 - A PROPERTY_ERROR during the WebUtil Core interaction causes immediate termination of form processing via FORM_TRIGGER_FAILURE.
- BR-009 - The function returns a strict BOOLEAN derived from comparing the WebUtil Core response to the literal string 'TRUE'; any other response value evaluates to FALSE.

---
**Implementation Logic**

```plsql
  
  FUNCTION DownLoadFromURLInt(sourceURL          in VARCHAR2, 
                              clientDestination  in VARCHAR2, 
                              specialDestination in PLS_INTEGER default 0,                             
                              fileSize           in PLS_INTEGER default 0, 
                              withProgress       in BOOLEAN default false,
                              progressTitle      in VARCHAR2 default null,
                              progressSubTitle   in VARCHAR2 default null,
                              progressMessage    in VARCHAR2 default null) return BOOLEAN is
    result       VARCHAR2(6) := 'FALSE';
    submitString VARCHAR2(4000 char);
    sep          VARCHAR2(1) := '|';
  BEGIN
    if sourceURL is null then
      raise URL_NULL;
    end if;
    if clientDestination is null then
      raise CLIENT_FILE_NULL;
    end if;

    if specialDestination is null or specialDestination < 0 or specialDestination > 2 then 
      submitString := '0'||sep;
    else
      submitString := to_char(specialDestination)||sep;
    end if;
    if fileSize is null then 
      submitString := submitString||'0'||sep;
    else
      submitString := submitString||to_char(fileSize)||sep;
    end if;
    if withProgress is null or not withProgress then 
      submitString := submitString||'N'||sep;
    else
      submitString := submitString||'Y'||sep;
    end if;    

    submitString := submitString||sourceURL
                    ||sep||clientDestination
                    ||sep||nvl(progressTitle,' ')
                    ||sep||nvl(progressSubTitle,' ')
                    ||sep||nvl(progressMessage,' ');                         
  WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_URL_DOWNLOAD',submitString,true);
  result := WebUtil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_URL_DOWNLOAD');
  return (result='TRUE');
  EXCEPTION  
    when CLIENT_FILE_NULL then
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE, 130, 'WEBUTIL_CORE.DownloadFromURLInt');
      return false;
    when URL_NULL then
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE,25, 'WEBUTIL_CORE.DownloadFromURLInt');
      return false;

    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                              ||' bean not found. WEBUTIL_CORE.DownloadFromURLInt will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;
  END DownLoadFromURLInt;
```

#### SP-033 - WEBUTIL.ERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.DOWNLOADFROMURLINT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Constructs a structured error message string from a numeric error code, a package/unit name, and up to three optional argument values, then records that message as a property on the WebUtil core context identified by the supplied package ID. This provides a standardised mechanism for reporting errors within WebUtil operations (such as WEBUTIL.DOWNLOADFROMURLINT) by persisting a formatted, pipe-delimited error descriptor for downstream consumption.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |
| code | PLS_INTEGER | IN |
| pu_name | VARCHAR2 | IN |
| arg1 | VARCHAR2 | IN |
| arg2 | VARCHAR2 | IN |
| arg3 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the package context identifier (packageID), a numeric error code (code), the name of the calling package or unit (pu_name), and up to three optional supplementary argument strings (arg1, arg2, arg3).
- Step 2 - Initialise the error text string by concatenating the literal prefix 'ERROR' with the error code left-padded to three digits and separated from pu_name by a pipe delimiter, producing the base format: ERROR<NNN>|<pu_name>.
- Step 3 - Evaluate whether arg1 is non-null; if so, append a pipe delimiter followed by arg1 to the error text string.
- Step 4 - Evaluate whether arg2 is non-null; if so, append a pipe delimiter followed by arg2 to the error text string.
- Step 5 - Evaluate whether arg3 is non-null; if so, append a pipe delimiter followed by arg3 to the error text string.
- Step 6 - Invoke Webutil_Core.setProperty to store the fully assembled error text string against the property key 'WUC_ERROR_MSG' within the package context identified by packageID.

---
**Decision Points**

DP-001

Condition: arg1 IS NOT NULL

TRUE: Append a pipe delimiter and the value of arg1 to the error text string.

FALSE: arg1 is omitted from the error text string; processing continues to DP-002.

---

DP-002

Condition: arg2 IS NOT NULL

TRUE: Append a pipe delimiter and the value of arg2 to the error text string.

FALSE: arg2 is omitted from the error text string; processing continues to DP-003.

---

DP-003

Condition: arg3 IS NOT NULL

TRUE: Append a pipe delimiter and the value of arg3 to the error text string.

FALSE: arg3 is omitted from the error text string; processing continues to property storage.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The error code must be formatted as a zero-padded, three-digit numeric string (e.g., code 5 becomes '005') to ensure a consistent, fixed-width error identifier within the message.
- BR-002 - The error message must always begin with the literal prefix 'ERROR' followed immediately by the zero-padded code and a pipe-delimited pu_name, establishing the mandatory base structure of every error record.
- BR-003 - Optional arguments (arg1, arg2, arg3) are included in the error text only when they carry a non-null value; null arguments are silently excluded, keeping the message compact.
- BR-004 - The fully assembled error message must be persisted to the WebUtil core context under the reserved property key 'WUC_ERROR_MSG' via Webutil_Core.setProperty, ensuring the error is available to the calling context (e.g., WEBUTIL.DOWNLOADFROMURLINT) for further handling.
- BR-005 - The error text string is constrained to a maximum of 1 024 characters, limiting the combined length of the error code, unit name, and any appended arguments.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Error(packageID in PLS_INTEGER,
                  code      in PLS_INTEGER,
                  pu_name   in VARCHAR2,
                  arg1      in VARCHAR2 :=null,
                  arg2      in VARCHAR2 := null,
                  arg3      in VARCHAR2 := null
                 ) is
    errText varchar2(1024);
  begin 
    errText := 'ERROR'||lpad(to_char(code),3,'0') || '|' || pu_name;
    if arg1 is not null then
      errText := errText || '|' || arg1;
    end if;
    if arg2 is not null then
      errText := errText || '|' || arg2;
    end if;
    if arg3 is not null then
      errText := errText || '|' || arg3;
    end if;
    Webutil_Core.setProperty(packageID, 'WUC_ERROR_MSG', errText);
  end Error;
```

#### SP-034 - WEBUTIL.ERRORALERT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.PUT_LINE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Displays a WebUtil error message to the user, typically raised when a bean is not registered or cannot be found. If a pre-configured alert object (m_errorAlert) is available, the error text is presented via a modal alert dialog; otherwise, the message is surfaced through the standard Forms MESSAGE built-in.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| errText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-044](#SP-044--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the error description text (errText) as input.
- Step 2 - Call WEBUTIL.ID_NULL (SP-044) to determine whether the module-level alert handle m_errorAlert references a valid, registered alert object.
- Step 3 - If m_errorAlert is valid (not null/unregistered), set the alert's message text property to errText using SET_ALERT_PROPERTY with the ALERT_MESSAGE_TEXT attribute.
- Step 4 - Display the configured alert dialog to the user by invoking SHOW_ALERT(m_errorAlert); the return value is captured in the local variable 'ignore' and discarded.
- Step 5 - If m_errorAlert is not valid, fall back to the Forms MESSAGE built-in, concatenating the literal prefix 'WebUtil Error: ' with errText to form the displayed message.

---
**Decision Points**

DP-001

Condition:
WEBUTIL.ID_NULL(m_errorAlert) returns FALSE - i.e., the alert handle m_errorAlert is a valid, registered Forms alert object.

TRUE:
Set the alert message text to errText via SET_ALERT_PROPERTY and display the alert dialog via SHOW_ALERT. The dialog return value is discarded.

FALSE:
Bypass the alert mechanism and display the error using the Forms MESSAGE built-in with the prefix 'WebUtil Error: ' prepended to errText.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This procedure is reserved for reporting WebUtil-specific errors, specifically bean-not-registered and bean-not-found conditions; it must not be used as a general-purpose alert utility.
- BR-002 - The alert title is not set at runtime because it is assumed to be pre-configured in the alert's design-time property; only the message text is overwritten dynamically.
- BR-003 - The return value of SHOW_ALERT is intentionally ignored; no branching logic is applied based on the user's alert button selection.
- BR-004 - WEBUTIL.ID_NULL (SP-044) is the sole mechanism for validating the alert handle; the procedure must not assume m_errorAlert is always initialised.
- BR-005 - When the alert object is unavailable, the fallback message must include the 'WebUtil Error: ' prefix to preserve consistent error identification for end users.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ErrorAlert(errText in VARCHAR2) is
    -- currently used for throwing a BEAN_NOT_REGISTERED or bean not found error.
    ignore integer;
  begin
    if not ID_NULL(m_errorAlert) then 
      --SET_ALERT_PROPERTY(m_errorAlert,TITLE,'WebUtil Error'); -- title already set in alert property
      SET_ALERT_PROPERTY(m_errorAlert,ALERT_MESSAGE_TEXT,errText);
      ignore := SHOW_ALERT(m_errorAlert);
    else
      message('WebUtil Error'||': '||errText);
    end if;
  end ErrorAlert;
```

#### SP-035 - WEBUTIL.EXECUTE

**Invoked From:**

- SP_GET_PART_DESC.prc [StoredProcedure: SP_GET_PART_DESC]
- webutil.pld [StoredProcedure: WEBUTIL.BLOCKING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Submits a host operating-system command for execution on the client machine via the WebUtil framework. The procedure sets the execution mode and the command string as properties on the WebUtil Host (WUH) package bean, then retrieves the resulting process handle. It is called by SP_GET_PART_DESC and WEBUTIL.BLOCKING to launch client-side processes and obtain a process identifier that callers can use to monitor or interact with the spawned process.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |
| exemode | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETPROPERTY ([SP-040](#SP-040--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the command string (cmd) and the execution mode flag (exemode) as input parameters.
- Step 2 - Check whether cmd is non-null; if null, skip all processing and return an uninitialised PROCESS_ID record.
- Step 3 - Set the WUH_EXECUTION_MODE property on the WUH_PACKAGE bean to the supplied exemode value, controlling how the host command will be launched (e.g. synchronous vs. asynchronous).
- Step 4 - Set the WUH_EXECUTE property on the WUH_PACKAGE bean to the supplied cmd string, triggering the WebUtil framework to execute the command on the client.
- Step 5 - Retrieve the WUH_EXECUTE property from the WUH_PACKAGE bean using WEBUTIL.GETPROPERTY (WebUtil_Core.getProperty); the framework returns the numeric process handle for the spawned process.
- Step 6 - Convert the returned string handle to a number and store it in the procId.handle field of the PROCESS_ID record.
- Step 7 - Return the populated PROCESS_ID record to the caller.
- Step 8 - If a BEAN_NOT_REGISTERED exception is raised at any point, display an error alert identifying the missing implementation class and indicating that WEBUTIL_HOST.Execute will not function, then exit without returning a valid process handle.

---
**Decision Points**

DP-001

Condition:
cmd IS NOT NULL

TRUE:
Set WUH_EXECUTION_MODE and WUH_EXECUTE properties on the WUH_PACKAGE bean, retrieve the resulting process handle via WEBUTIL.GETPROPERTY, populate procId.handle, and return the PROCESS_ID record.

FALSE:
Skip all property-setting and handle-retrieval logic; return an uninitialised PROCESS_ID record to the caller.

---

DP-002

Condition:
WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during property set or get operations

TRUE:
Display an error alert that includes the implementation class name and states that WEBUTIL_HOST.Execute will not work; procedure exits without returning a valid process handle.

FALSE:
Normal execution continues; a populated PROCESS_ID record is returned to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A null cmd value is treated as a no-operation; no properties are written to the WebUtil bean and no process is launched, preventing unintended execution of empty commands.
- BR-002 - The execution mode (exemode) must be set on the WUH_PACKAGE bean before the command property is set, ensuring the WebUtil framework applies the correct launch behaviour to the command.
- BR-003 - The process handle returned by the WebUtil framework is expected to be numeric; it is converted via TO_NUMBER before being stored in the PROCESS_ID record, enforcing type integrity for downstream callers.
- BR-004 - If the required WebUtil Host bean is not registered on the client, the procedure must raise a user-visible error alert identifying the missing bean class rather than failing silently, ensuring operators are informed of the configuration deficiency.
- BR-005 - The function relies on WEBUTIL.GETPROPERTY (SP-040) to read the process handle back from the WebUtil framework; this dependency must be available at runtime for the function to return a valid PROCESS_ID.

---
**Implementation Logic**

```plsql
  FUNCTION Execute (cmd in VARCHAR2, exemode in PLS_INTEGER) return PROCESS_ID is
    procId PROCESS_ID;
  begin 
    if cmd is not null then 
      WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTION_MODE',exemode);            
      WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTE',cmd);      
      procId.handle := to_number(WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTE'));
    end if;
    return procId;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.Execute will not work');
  end Execute;
```

#### SP-036 - WEBUTIL.FCLOSE

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open client-side text file that was previously opened through the WebUtil file I/O framework. The procedure releases the file handle on the client by instructing the WebUtil bean to perform the close operation, then nullifies the handle reference to prevent further use. It is invoked as part of Excel report generation in VIEW_EXCEL_REPORT_NEW.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the file handle (file_type) passed IN OUT by the calling routine VIEW_EXCEL_REPORT_NEW.
- Step 2 - Check whether the file handle (file.handle) is not NULL, indicating an active open file reference exists on the client.
- Step 3 - If the handle is active, invoke WebUtil_Core.setProperty with the WUF_PACKAGE identifier and the WUF_TEXTIO_CLOSE command, passing the current handle value to instruct the WebUtil client bean to physically close the file.
- Step 4 - Set file.handle to NULL to invalidate the handle reference and prevent any subsequent file operations against the now-closed file.
- Step 5 - If a BEAN_NOT_REGISTERED exception is raised (the WebUtil bean is unavailable on the client), display an error alert identifying the missing implementation class and raise TOOL_ERR.TOOL_ERROR to abort processing.
- Step 6 - If a PROPERTY_ERROR exception is raised (the close property command failed), raise TOOL_ERR.TOOL_ERROR to abort processing.

---
**Decision Points**

DP-001

Condition: file.handle IS NOT NULL

TRUE: The file is considered open on the client; WebUtil_Core.setProperty is called to close it and the handle is set to NULL.

FALSE: The file handle is already NULL (file is not open or was never opened); no close operation is performed and the procedure exits silently.

DP-002

Condition: WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during the setProperty call

TRUE: The WebUtil client bean is not registered; an error alert is displayed identifying the missing bean class and TOOL_ERR.TOOL_ERROR is raised to halt execution.

FALSE: Exception is not raised; processing continues normally.

DP-003

Condition: WebUtil_Core.PROPERTY_ERROR exception is raised during the setProperty call

TRUE: The close property command failed on the client; TOOL_ERR.TOOL_ERROR is raised to halt execution.

FALSE: Exception is not raised; processing continues normally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A file close operation is only attempted when the file handle is not NULL; a NULL handle is treated as an already-closed or uninitialised file and requires no action.
- BR-002 - After a successful close, the file handle must be set to NULL to ensure the file reference is invalidated and cannot be reused by the calling context.
- BR-003 - The WebUtil client bean must be registered and available on the client at the time of invocation; if it is not, the procedure raises TOOL_ERR.TOOL_ERROR and the close operation is not completed.
- BR-004 - Any property-level error returned by the WebUtil framework during the close command must cause the procedure to raise TOOL_ERR.TOOL_ERROR, ensuring the calling routine is notified of the failure.
- BR-005 - The file parameter is passed IN OUT, meaning the nullification of the handle is visible to the caller (VIEW_EXCEL_REPORT_NEW) after the procedure returns, preventing stale handle references in the parent routine.

---
**Implementation Logic**

```plsql
 
  PROCEDURE fclose (file IN OUT file_type) is 
  BEGIN 
    if (file.handle IS NOT NULL) then 
      WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CLOSE',file.handle);        
      file.handle := NULL;
    end if;
 
 EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.fclose will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;
  END fclose;
```

#### SP-037 - WEBUTIL.FILE_SELECTION_DIALOG_INT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_FILE.FILE_SAVE_DIALOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Presents a client-side file-selection dialog (save, open-file, or open-directory) to the user by configuring the WebUtil file-chooser bean with the supplied parameters and returning the user's selection as a string. It is the internal implementation function called by WEBUTIL_FILE.FILE_SAVE_DIALOG to interact with the underlying WebUtil Core bean.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| directory_name | Varchar2 | IN |
| file_name | Varchar2 | IN |
| file_filter | Varchar2 | IN |
| title | Varchar2 | IN |
| dialog_type | Number | IN |
| select_file | Boolean | IN |
| multiselect | Boolean | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- D2KWUTIL.SAVE_FILE ([SP-015](#SP-015--D2KWUTIL.SAVE_FILE)) - D2KWUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Set the initial directory on the WebUtil file-chooser bean by passing directory_name to WebUtil_Core.setProperty using the WUF_GFN_DIRNAME property key.
- Step 2 - Set the default file name on the bean by passing file_name to WebUtil_Core.setProperty using the WUF_FILENAME property key.
- Step 3 - Set the file-type filter on the bean by passing file_filter to WebUtil_Core.setProperty using the WUF_FILTER property key.
- Step 4 - Set the dialog title on the bean by passing title to WebUtil_Core.setProperty using the WUF_GFN_MESSAGE property key.
- Step 5 - Set the multi-select flag on the bean by passing multiselect to WebUtil_Core.setProperty using the WUF_GFN_MULTISELECT property key.
- Step 6 - Determine the dialog mode from dialog_type and select_file, then invoke the appropriate WebUtil_Core.getProperty call to display the dialog and capture the user's selection into the local result variable (WUF_GFN_SAVEFILE for save, WUF_GFN_OPENDIR for directory selection, or WUF_GFN_OPENFILE for file open).
- Step 7 - Inspect the returned result string for a leading double-backslash (\\) sequence using INSTR; if the string starts at position 1 with '\\', prepend an additional '\\' to the result to prevent loss of the UNC path prefix during subsequent replacement.
- Step 8 - Normalise all remaining escaped backslash sequences by replacing every occurrence of '\\' with a single '\' in the result string.
- Step 9 - Return the normalised result string to the caller.
- Step 10 - If the WebUtil bean is not registered, raise an error alert identifying the missing implementation class and raise FORM_TRIGGER_FAILURE to halt processing.
- Step 11 - If a property error occurs during bean interaction, raise FORM_TRIGGER_FAILURE to halt processing.

---
**Decision Points**

DP-001

Condition: dialog_type equals the SAVE_FILE constant.

TRUE: Invoke WebUtil_Core.getProperty with WUF_GFN_SAVEFILE to display a save-file dialog and capture the selected file path.

FALSE: Proceed to DP-002 to determine whether an open-directory or open-file dialog is required.

---

DP-002

Condition: select_file is FALSE (evaluated only when dialog_type is not SAVE_FILE).

TRUE: Invoke WebUtil_Core.getProperty with WUF_GFN_OPENDIR to display a directory-selection dialog and capture the selected directory path.

FALSE: Invoke WebUtil_Core.getProperty with WUF_GFN_OPENFILE to display an open-file dialog and capture the selected file path.

---

DP-003

Condition: The position of the first occurrence of '\\\\' in the result string (via INSTR) equals 1, indicating the path begins with a UNC prefix.

TRUE: Prepend '\\\\' to the result string before executing the backslash normalisation replace, preserving the UNC prefix.

FALSE: Proceed directly to backslash normalisation without modifying the leading characters.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - All five dialog configuration properties (directory, file name, file filter, title, and multi-select flag) must be set on the WebUtil bean before the dialog is invoked; no dialog is displayed until all properties have been applied.
- BR-002 - The dialog mode is determined exclusively by the combination of dialog_type and select_file: a dialog_type equal to SAVE_FILE always produces a save dialog regardless of select_file; otherwise, select_file = FALSE produces a directory-selection dialog and select_file = TRUE produces an open-file dialog.
- BR-003 - Paths returned by the JFileChooser bean that begin with a double-backslash (UNC paths) must have an additional double-backslash prepended prior to normalisation to ensure the UNC prefix survives the subsequent replace operation intact.
- BR-004 - All escaped backslash sequences ('\\\\') in the returned path must be normalised to single backslashes ('\') before the result is returned to the caller.
- BR-005 - If the required WebUtil bean is not registered on the client, the function must display an error alert identifying the missing implementation class and terminate form processing via FORM_TRIGGER_FAILURE; silent failure is not permitted.
- BR-006 - Any property error raised during bean interaction must terminate form processing via FORM_TRIGGER_FAILURE.

---
**Implementation Logic**

```plsql
  FUNCTION FILE_SELECTION_DIALOG_INT(   directory_name Varchar2,
                                        file_name      Varchar2,
                                        file_filter    Varchar2,
                                        title          Varchar2,
                                        dialog_type    Number,
                                        select_file    Boolean,
                                        multiselect    Boolean) return Varchar2 is
    result varchar2(4000);     
    pos Number;
  BEGIN  
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_DIRNAME', directory_name);
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILENAME',file_name, true);     
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILTER',  file_filter); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_MESSAGE', title); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_MULTISELECT', multiselect,true);     
  
    if (dialog_type = SAVE_FILE) then 
        result := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_SAVEFILE');
    elsif (not select_file) then
        result := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_OPENDIR');
    else
        result := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_OPENFILE');
    end if;
  
    -- handle the situation which we can get with JFileChooser with escaped "\"

    -- if string starts with '\\', replace it with '\\\\', 
    -- before running the original replace statement.
    pos := instr(result, '\\');

    -- concat '\\' in the begining of the string before calling the replace.
    if (pos = 1) then
        result := concat('\\', result);
    end if;

    result := replace(result,'\\','\');
    return result;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. WEBUTIL_FILE.FILE_SELECTION_DIALOG_INT will not work');
      RAISE FORM_TRIGGER_FAILURE;  
   when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;  
  END FILE_SELECTION_DIALOG_INT;
```

#### SP-038 - WEBUTIL.FOPEN

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Opens a file on the client machine for text-based reading, writing, or appending by delegating to the WebUtil Java bean layer. The function validates the requested file mode and file path, instructs the WebUtil core component to open the file, and returns a file handle (file_type) that the calling routine (VIEW_EXCEL_REPORT_NEW) can use for subsequent client-side file I/O operations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| spec | VARCHAR2 | IN |
| filemode | VARCHAR2 | IN |
| charSet | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Validate the file mode: confirm that the supplied 'filemode' parameter (case-insensitive) is one of the three permitted values: 'r' (read), 'w' (write), or 'a' (append). Raise TOOL_ERR.TOOL_ERROR immediately if the value is outside this set.
- Step 2 - Validate the file specification: confirm that the 'spec' parameter is neither NULL nor an empty string. Raise TOOL_ERR.TOOL_ERROR immediately if the file path is absent.
- Step 3 - Transmit the file path to the WebUtil bean: call WebUtil_Core.setProperty to set the WUF_FILENAME property on the WUF_PACKAGE with the value of 'spec'.
- Step 4 - Transmit the file mode to the WebUtil bean: call WebUtil_Core.setProperty to set the WUF_TEXTIO_FILEMODE property with the value of 'filemode'.
- Step 5 - Transmit the character set to the WebUtil bean: if 'charSet' is NULL, set the WUF_TEXTIO_CHARSET property to the literal string '(null)'; otherwise set it to the supplied 'charSet' value.
- Step 6 - Request the file open operation: call WebUtil_Core.getProperty for the WUF_TEXTIO_OPEN property, which triggers the Java bean to open the file and returns a string handle ('javaHandle').
- Step 7 - Validate the returned handle: if 'javaHandle' is NULL, empty, or equal to '-1', the file was not successfully opened; raise TOOL_ERR.TOOL_ERROR.
- Step 8 - Construct and return the file handle: convert 'javaHandle' to a number, assign it to the handle field of a file_type record, and return that record to the caller.

---
**Decision Points**

DP-001

Condition: The value of 'filemode' (converted to lower case) is NOT one of 'r', 'w', or 'a'.

TRUE: Raise TOOL_ERR.TOOL_ERROR; processing stops and no file is opened.

FALSE: Proceed to validate the file specification (DP-002).

---

DP-002

Condition: The 'spec' parameter is NULL or an empty string.

TRUE: Raise TOOL_ERR.TOOL_ERROR; processing stops and no file is opened.

FALSE: Proceed to set WebUtil properties and attempt to open the file.

---

DP-003

Condition: The 'charSet' parameter is NULL.

TRUE: Set the WUF_TEXTIO_CHARSET property to the literal string '(null)', indicating no explicit character set to the Java bean.

FALSE: Set the WUF_TEXTIO_CHARSET property to the caller-supplied character set value.

---

DP-004

Condition: The Java bean returns a 'javaHandle' that is NULL, empty, or equal to '-1'.

TRUE: The file was not opened successfully; raise TOOL_ERR.TOOL_ERROR.

FALSE: Convert the handle to a number, populate the file_type record, and return it to the caller.

---

DP-005

Condition: An exception of type WebUtil_Core.BEAN_NOT_REGISTERED is raised during processing.

TRUE: Display an error alert identifying the missing bean class, then raise TOOL_ERR.TOOL_ERROR and return NULL.

FALSE: Not applicable; other exception types (PROPERTY_ERROR, VALUE_ERROR, TOOL_ERROR) are re-raised directly without an alert.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file mode must be exactly one of 'r' (read), 'w' (write), or 'a' (append), evaluated case-insensitively. Any other value is rejected as invalid before any file system interaction occurs.
- BR-002 - A non-null, non-empty file path ('spec') is mandatory. The function will not attempt to open a file if no path is provided.
- BR-003 - When no character set is specified by the caller, the value '(null)' is explicitly passed to the WebUtil bean, signalling that the bean should apply its default encoding rather than leaving the property unset.
- BR-004 - A Java bean handle value of NULL, empty string, or '-1' is treated as a failed open attempt; the function does not return a partially constructed handle under any such condition.
- BR-005 - The numeric file handle stored in the returned file_type record is derived exclusively from the string handle provided by the WebUtil Java bean; no alternative handle source is used.
- BR-006 - If the WebUtil bean is not registered in the Forms runtime environment, an informational alert is displayed identifying the missing bean class before the error is propagated, ensuring the caller receives a meaningful diagnostic.
- BR-007 - All error conditions ultimately surface to the caller as TOOL_ERR.TOOL_ERROR, providing a uniform error contract for upstream routines such as VIEW_EXCEL_REPORT_NEW.

---
**Implementation Logic**

```plsql
  FUNCTION fopen(spec VARCHAR2, filemode VARCHAR2, charSet VARCHAR2 := null) RETURN file_type is
    clientFile file_type;
    javaHandle VARCHAR2(6);
  BEGIN
    -- check the mode is valid
    if (lower(filemode) not in ('r','w','a')) then 
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- make sure a file name has been specified      
    if (spec is null) or (spec='') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;
      
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILENAME',spec, true);
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_FILEMODE',filemode, true);        
    if (charSet is null) then
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET','(null)', true);
    else
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET',charSet, true);
    end if;
    javaHandle := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_OPEN');

    -- If the return is null then the file was not opened      
    if (javaHandle is null) or (javaHandle='') or (javaHandle='-1') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- if we are this far convert the handle to the correct format and return it.      
    clientFile.handle := to_number(javaHandle);
    return clientFile;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.fopen will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                 
      return null;
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE;
    when VALUE_ERROR then
      RAISE TOOL_ERR.TOOL_ERROR; 
    when TOOL_ERR.TOOL_ERROR then 
      RAISE;
  END fopen;
```

#### SP-039 - WEBUTIL.GETIMPLCLASS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.PUT_LINE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the fully-qualified Java implementation class name for a given WebUtil package by concatenating the standard WebUtil Java root path with the registered implementation class entry for the supplied package identifier.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the numeric package identifier (packageID) as input.
- Step 2 - Look up the implementation class string associated with packageID in the m_implClasses collection.
- Step 3 - Prefix the retrieved class string with the WEBUTIL_JAVA_ROOT constant to form the fully-qualified class name.
- Step 4 - Return the concatenated fully-qualified Java implementation class name to the caller.

---
**Decision Points**

No conditional decision points exist in this function. The logic is a single unconditional return of the concatenated value; no branching occurs.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The packageID supplied must correspond to a valid, pre-populated entry in the m_implClasses collection; no bounds or existence check is performed within this function, so an invalid packageID will raise a runtime error.
- BR-002 - The fully-qualified Java implementation class name is always constructed by prepending WEBUTIL_JAVA_ROOT to the m_implClasses entry; neither component may be substituted or overridden at call time.
- BR-003 - This function has no database interactions and no external dependencies; it operates exclusively on in-memory package-level structures (WEBUTIL_JAVA_ROOT and m_implClasses).

---
**Implementation Logic**

```plsql

  FUNCTION getImplClass(packageID PLS_INTEGER) return VARCHAR2 is
  BEGIN 
    return WEBUTIL_JAVA_ROOT||m_implClasses(packageID);    
  END;
```

#### SP-040 - WEBUTIL.GETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.EXECUTE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a named Java system property at runtime by delegating to the Java Native Interface (JNI) layer. Given a property key (e.g., 'file.separator', 'os.name'), the function calls the standard Java method java.lang.System.getProperty and returns the corresponding string value to the Oracle Forms session. This allows Oracle Forms to interrogate the client or server JVM environment without direct PL/SQL access to system resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the property key string (a0) identifying the Java system property to be retrieved.
- Step 2 - Create a JNI argument list sized for one argument by calling JNI.CREATE_ARG_LIST(1), storing the handle in the shared 'args' variable.
- Step 3 - Append the property key string (a0) to the argument list as a String argument via JNI.ADD_STRING_ARG.
- Step 4 - Invoke the static Java method java.lang.System.getProperty(String) through JNI.CALL_STRING_METHOD, passing the class path 'java/lang/System', the method name 'getProperty', the JNI method signature '(Ljava/lang/String;)Ljava/lang/String;', and the prepared argument list.
- Step 5 - Return the VARCHAR2 string value produced by the JNI call directly to the caller (WEBUTIL.EXECUTE).

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a linear sequence of JNI calls and returns the result unconditionally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The property key supplied in parameter a0 must be a valid Java system property name recognised by java.lang.System.getProperty; if the property does not exist the JNI layer returns NULL, which is propagated as the function result.
- BR-002 - The function accepts exactly one input argument; the JNI argument list is explicitly created with a capacity of 1, and no additional arguments may be appended.
- BR-003 - The JNI call is made as a static method invocation (instance flag TRUE, object reference NULL), meaning no Java object instantiation is required and the call targets the class-level System.getProperty method directly.
- BR-004 - This function has no database interactions; all processing is delegated entirely to the JNI/JVM layer, making the result dependent on the JVM environment available to the Oracle Forms runtime at the time of invocation.

---
**Implementation Logic**

```plsql
  FUNCTION getProperty(
    a0    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'getProperty', '(Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-041 - WEBUTIL.GET_LINE

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Reads a single line of text from an open client-side text file and returns it to the caller. The procedure delegates the actual read operation to the WebUtil PJC (Pluggable Java Component) layer via WebUtil_Core property calls, and signals end-of-file by raising NO_DATA_FOUND when the PJC returns a newline sentinel character.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| item | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the file handle (file_type) that identifies the open client-side text file to be read.
- Step 2 - Set the active file handle on the WebUtil PJC by writing the handle value to the WUF_TEXTIO_HANDLE property of the WUF_PACKAGE component via WebUtil_Core.setProperty.
- Step 3 - Instruct the PJC to read the next line by retrieving the WUF_TEXTIO_GETLINE property via WebUtil_Core.getProperty; the returned value is stored in a local VARCHAR2 buffer (up to 4 000 characters).
- Step 4 - Inspect the buffer: if it equals CHR(10) (a lone newline), interpret this as the PJC's end-of-file sentinel and raise NO_DATA_FOUND to signal the caller that no further data is available.
- Step 5 - If the buffer does not equal CHR(10), assign the buffer content to the OUT parameter item and return normally.
- Step 6 - On BEAN_NOT_REGISTERED exception, display an error alert identifying the missing PJC implementation class and raise TOOL_ERROR to halt processing.
- Step 7 - On PROPERTY_ERROR exception, raise TOOL_ERROR to halt processing without an additional alert.

---
**Decision Points**

DP-001

Condition: The value returned by WebUtil_Core.getProperty for WUF_TEXTIO_GETLINE equals CHR(10) (lone newline character).

TRUE: The end-of-file sentinel has been detected; NO_DATA_FOUND is raised to inform the caller that there are no more lines to read.

FALSE: The buffer contains a valid line of text; the buffer value is assigned to the OUT parameter item and the procedure returns successfully.

---

DP-002

Condition: A BEAN_NOT_REGISTERED exception is raised during execution (the required WebUtil PJC bean is not available on the client).

TRUE: An error alert is displayed identifying the missing implementation class, and TOOL_ERROR is raised to terminate processing.

FALSE: No BEAN_NOT_REGISTERED exception occurs; normal processing continues.

---

DP-003

Condition: A PROPERTY_ERROR exception is raised during execution (the PJC property interaction fails).

TRUE: TOOL_ERROR is raised immediately to terminate processing.

FALSE: No PROPERTY_ERROR exception occurs; normal processing continues.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A lone newline character (CHR(10)) returned by the PJC is reserved exclusively as the end-of-file sentinel; it is never treated as a valid line of data. This convention exists because the PJC uses the newline as a line delimiter during normal reads and would never return it as line content under ordinary circumstances.
- BR-002 - The maximum length of a single line that can be returned is 4 000 characters, as constrained by the internal buffer declaration (VARCHAR2(4 000 CHAR)).
- BR-003 - If the WebUtil PJC bean is not registered on the client, the procedure must surface a descriptive error alert before raising TOOL_ERROR, ensuring the user receives actionable information about the missing component.
- BR-004 - Any PROPERTY_ERROR raised by the PJC interaction must cause immediate termination via TOOL_ERROR; no partial or default result is returned to the caller.
- BR-005 - The file handle passed in must already be open and valid; this procedure performs no file-open or file-existence validation itself.

---
**Implementation Logic**

```plsql
  PROCEDURE get_line (file file_type, item OUT VARCHAR2) is
    buffer VARCHAR2(4000 char);
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);        
    buffer := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_GETLINE');
    -- We can't easily tell the difference between an empty line and a line beyond then 
    -- end of the file so to get around this, the exception handling code in the PJC 
    -- places a newline into the buffer when the end of file is passed.
    -- The rational being that get_line would never normally return a newline because 
    -- it normally uses that to tell it where to read up *to*.
    if buffer = chr(10) then 
      raise NO_DATA_FOUND;
    else
      item := buffer;
    end if;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.get_line will not work');
      RAISE TOOL_ERR.TOOL_ERROR;                                                                 
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE TOOL_ERR.TOOL_ERROR;  
  END get_line;
  
  /**
   * File writing functions
   */
```

#### SP-042 - WEBUTIL.GET_RETURN_CODE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.HOST]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the integer return code produced by a previously executed host process. Given a PROCESS_ID handle, the function communicates the process identifier to the WebUtil core layer and reads back the numeric return code that the host process recorded, allowing the caller to determine the outcome of the host execution.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the PROCESS_ID of a previously executed host process as input.
- Step 2 - Pass the process handle to the WebUtil core layer by setting the WUH_PROC_ID property on the WUH_PACKAGE component via WebUtil_Core.setProperty.
- Step 3 - Retrieve the WUH_RC (return code) property from the WUH_PACKAGE component via WebUtil_Core.getProperty.
- Step 4 - Convert the retrieved return-code string to a PLS_INTEGER using TO_NUMBER and return it to the caller.
- Step 5 - If the WebUtil bean is not registered, raise an error alert identifying the missing implementation class and exit without returning a value.

---
**Decision Points**

DP-001

Condition: The WebUtil bean for WUH_PACKAGE is registered and available at runtime.

TRUE: The function sets the process handle property, reads the WUH_RC property, converts it to a PLS_INTEGER, and returns it to the caller.

FALSE: The BEAN_NOT_REGISTERED exception is caught; an error alert is displayed stating that the implementation class bean was not found and that WEBUTIL_HOST.Get_Return_Code will not work, and no return code value is returned.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A valid PROCESS_ID handle must be supplied; the function uses the handle attribute directly to identify the target process within the WebUtil core layer.
- BR-002 - The WebUtil bean associated with WUH_PACKAGE must be registered in the runtime environment before this function is called; if it is not registered, the function cannot retrieve a return code and will instead surface an error alert.
- BR-003 - The return code is stored and retrieved as a string property (WUH_RC) and must be convertible to a PLS_INTEGER; the function applies TO_NUMBER to perform this conversion before returning the result.

---
**Implementation Logic**

```plsql
  
  
  FUNCTION Get_Return_Code(process in PROCESS_ID) return PLS_INTEGER is
  begin 
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_PROC_ID',process.handle);
    return to_number(WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,'WUH_RC'));
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
       WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                               ||' bean not found. WEBUTIL_HOST.Get_Return_Code will not work');
  end Get_Return_Code;
```

#### SP-043 - WEBUTIL.HOST

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Executes a host operating-system command on the client machine in a blocking (synchronous) manner and returns the process exit/return code to the caller. It is invoked by the Excel report viewer logic to launch external processes (e.g., opening a generated Excel file) and confirm whether execution succeeded before proceeding.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.BLOCKING ([SP-029](#SP-029--WEBUTIL.BLOCKING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_RETURN_CODE ([SP-042](#SP-042--WEBUTIL.GET_RETURN_CODE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ID_NULL ([SP-044](#SP-044--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.RELEASE_PROCESS ([SP-049](#SP-049--WEBUTIL.RELEASE_PROCESS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the OS command string (cmd) to be executed on the client.
- Step 2 - Invoke WEBUTIL.BLOCKING, passing the command string, to launch the command as a blocking client-side process and obtain a process identifier (procId).
- Step 3 - Evaluate whether a valid process identifier was returned by testing procId with WEBUTIL.ID_NULL.
- Step 4 - If the process identifier is valid (not null), call WEBUTIL.GET_RETURN_CODE with procId to retrieve the integer exit/return code produced by the completed process and store it in RC.
- Step 5 - Release the client-side process object by calling WEBUTIL.RELEASE_PROCESS with procId, freeing associated resources.
- Step 6 - Return RC to the caller; RC remains -1 if no valid process was launched.

---
**Decision Points**

DP-001

Condition: WEBUTIL.ID_NULL(procId) evaluates to FALSE - i.e., WEBUTIL.BLOCKING successfully launched the process and returned a valid (non-null) process identifier.

TRUE (ID_NULL returns FALSE - process ID is valid): Retrieve the process return code via WEBUTIL.GET_RETURN_CODE and release the process handle via WEBUTIL.RELEASE_PROCESS; return the retrieved return code to the caller.

FALSE (ID_NULL returns TRUE - process ID is null/invalid): Skip return-code retrieval and resource release; return the default value of -1 to the caller, signalling that the process was not successfully launched.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The host command must be executed synchronously (blocking); the procedure does not return until the client-side process has completed, ensuring the caller receives a definitive exit code before continuing.
- BR-002 - A default return code of -1 is used as a sentinel value indicating that the process was not successfully initiated; callers must treat -1 as a failure condition distinct from any valid OS exit code.
- BR-003 - Client-side process resources (the process handle) must always be released via WEBUTIL.RELEASE_PROCESS after the return code has been collected, preventing resource leaks on the client machine.
- BR-004 - Return-code retrieval and resource release are conditional on obtaining a valid process identifier; if the process identifier is null, neither WEBUTIL.GET_RETURN_CODE nor WEBUTIL.RELEASE_PROCESS is called.

---
**Implementation Logic**

```plsql
  FUNCTION  Host(cmd in VARCHAR2) return PLS_INTEGER is
    procId PROCESS_ID;
    RC     PLS_INTEGER := -1;
  begin
    procId := Blocking(cmd);
    if not ID_NULL(procId) then
      RC := Get_Return_Code(procId);
      -- release the client side object
      Release_Process(procId);
    end if;
    return RC;
  end Host;
```

#### SP-044 - WEBUTIL.ID_NULL

**Invoked From:**

- DPL.pld [StoredProcedure: GENERAL.L_POP_LIST_ITEM]
- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]
- webutil.pld [StoredProcedure: WEBUTIL.ERRORALERT]
- webutil.pld [StoredProcedure: WEBUTIL.HOST]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTER_FUNCTION]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines whether a given handle object is uninitialised (null) by inspecting its internal `hnd` attribute. Returns TRUE if the handle carries no value, FALSE otherwise. This utility function is used by multiple calling routines to guard against operating on invalid or uninitialised handles before performing further processing.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| handle | Pointer | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the `handle` Pointer passed in by the calling routine.
- Step 2 - Inspect the `hnd` attribute of the supplied `handle` object.
- Step 3 - If `handle.hnd` is NULL, return TRUE to indicate the handle is uninitialised.
- Step 4 - If `handle.hnd` is NOT NULL, return FALSE to indicate the handle holds a valid reference.

---
**Decision Points**

DP-001

Condition:
`handle.hnd IS NULL`

TRUE:
Return TRUE - the handle is considered uninitialised (null); the caller should treat the handle as absent or invalid.

FALSE:
Return FALSE - the handle contains a value and is considered valid for further use by the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A handle is considered null solely on the basis of its internal `hnd` attribute being NULL; no other attribute or external state is evaluated.
- BR-002 - The function is read-only and produces no side effects; it does not modify the handle or any application state.
- BR-003 - The function must return a BOOLEAN result in all code paths: TRUE for a null handle and FALSE for a non-null handle, with no possibility of an indeterminate return.

---
**Implementation Logic**

```plsql

  FUNCTION ID_NULL(handle IN Pointer)        RETURN BOOLEAN is
  BEGIN
    if handle.hnd is null then 
      return TRUE;
    else
      return FALSE;
    end if;
  END ID_NULL;
```

#### SP-045 - WEBUTIL.LENGTH

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: DEBUGLOG]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: STRIPDIRSEP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the byte length of a file represented by a Java File object. The function delegates to the native Java method java.io.File.length() via the JNI bridge, providing Oracle Forms with the physical size of a file on the host file system without requiring a database interaction.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java File object (obj) that represents the target file on the host file system.
- Step 2 - Clear the JNI argument list by setting args to NULL, ensuring no stale arguments are passed to the Java method.
- Step 3 - Invoke the Java instance method java.io.File.length() on the supplied object via JNI.CALL_LONG_METHOD, specifying the class path 'java/io/File', method name 'length', and signature '()J' (no parameters, returns a long integer).
- Step 4 - Return the numeric value produced by JNI.CALL_LONG_METHOD to the caller, representing the file size in bytes.

---
**Decision Points**

No conditional decision points exist in this function. Execution follows a single, unconditional path: clear arguments, call the Java method, and return the result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The input parameter obj must be a valid ORA_JAVA.JOBJECT reference to a java.io.File instance; the function does not perform null or type validation before invoking the JNI call.
- BR-002 - The file size is returned as a NUMBER derived from a Java long value, representing the file length in bytes as reported by the host operating system.
- BR-003 - The JNI argument list (args) must be reset to NULL before each call to prevent argument contamination from prior JNI invocations within the same session context.
- BR-004 - No database read or write operations are performed; the file size is obtained entirely from the host file system via the JNI bridge.

---
**Implementation Logic**

```plsql
  FUNCTION length(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_LONG_METHOD(FALSE, obj, 'java/io/File', 'length', '()J', args); 
  END;
```

#### SP-046 - WEBUTIL.PUTF

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a formatted text string to an open client-side file by delegating to the WebUtil client bean. It sets the target file handle and the text argument as bean properties, enabling the Oracle Forms WebUtil framework to perform the actual text output operation on the client machine. This procedure is used within the Excel report generation flow invoked by VIEW_EXCEL_REPORT_NEW.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |
| arg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the target file handle (file.handle extracted from the file_type parameter) and the text string (arg) to be written.
- Step 2 - Set the WUF_TEXTIO_HANDLE property on the WebUtil bean (WUF_PACKAGE) via WebUtil_Core.setProperty, associating the operation with the correct open file.
- Step 3 - Set the WUF_TEXTIO_PUTF property on the same WebUtil bean via WebUtil_Core.setProperty, passing the text string (arg) to be written to the file.
- Step 4 - If the WebUtil bean is not registered on the client (BEAN_NOT_REGISTERED exception), display an error alert identifying the missing implementation class and raise TOOL_ERR.TOOL_ERROR to halt processing.
- Step 5 - If a property-setting error occurs (PROPERTY_ERROR exception), raise TOOL_ERR.TOOL_ERROR to halt processing without an additional alert.

---
**Decision Points**

DP-001

Condition: The WebUtil bean corresponding to WUF_PACKAGE is registered and available on the client at the time WebUtil_Core.setProperty is called.

TRUE: Both bean properties (WUF_TEXTIO_HANDLE and WUF_TEXTIO_PUTF) are set successfully and the text write operation proceeds normally.

FALSE: A BEAN_NOT_REGISTERED exception is raised; an error alert is displayed identifying the missing bean class, and TOOL_ERR.TOOL_ERROR is raised to terminate execution.

DP-002

Condition: The bean property assignment completes without a PROPERTY_ERROR exception.

TRUE: The procedure completes normally with both properties set.

FALSE: A PROPERTY_ERROR exception is raised; TOOL_ERR.TOOL_ERROR is raised silently (no alert) to terminate execution.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Both the file handle and the text argument must be supplied; the procedure accepts no optional parameters and passes both directly to the WebUtil bean without conditional logic.
- BR-002 - The WebUtil client bean for WUF_PACKAGE must be registered on the client before this procedure is called; absence of the bean is treated as a fatal error and processing is halted via TOOL_ERR.TOOL_ERROR.
- BR-003 - Any failure to set a bean property (PROPERTY_ERROR) is treated as a fatal error; TOOL_ERR.TOOL_ERROR is raised immediately, ensuring that a partial or silent write failure cannot go undetected by the calling context.
- BR-004 - The procedure does not perform any database interactions; all file output is handled exclusively through the WebUtil client-side bean mechanism.

---
**Implementation Logic**

```plsql
   
  
  
  procedure putf (file   file_type, 
                  arg    VARCHAR2) is 
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);              
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_PUTF',arg); 
  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.putf will not work');
      RAISE TOOL_ERR.TOOL_ERROR;                                                                 
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE TOOL_ERR.TOOL_ERROR;  
  END putf;
```

#### SP-047 - WEBUTIL.PUT_LINE

**Invoked From:**

- PK_VALIDATE_BACK_DATE.pck [StoredProcedure: PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a single line of text to a client-side file by transmitting the file handle, the text content, and a newline instruction to the WebUtil client-side bean via property-setting calls. If the required bean is not registered or a property operation fails, the procedure raises a terminal error to abort the calling operation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |
| item | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-034](#SP-034--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETIMPLCLASS ([SP-039](#SP-039--WEBUTIL.GETIMPLCLASS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETPROPERTY ([SP-050](#SP-050--WEBUTIL.SETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the target file handle (file.handle) and the text string (item) as inputs.
- Step 2 - Invoke WEBUTIL.SETPROPERTY (via WebUtil_Core.setProperty) to transmit the file handle to the WUF_PACKAGE bean under the property key WUF_TEXTIO_HANDLE.
- Step 3 - Invoke WEBUTIL.SETPROPERTY a second time to transmit the text content to the WUF_PACKAGE bean under the property key WUF_TEXTIO_PUT.
- Step 4 - Invoke WEBUTIL.SETPROPERTY a third time to signal a newline to the WUF_PACKAGE bean by setting the property key WUF_TEXTIO_NEWLINE to the value 1.
- Step 5 - If a BEAN_NOT_REGISTERED exception is raised during any property-set call, invoke WEBUTIL.ERRORALERT (via WebUtil_Core.ErrorAlert) to display a descriptive message that includes the implementation class name retrieved by WEBUTIL.GETIMPLCLASS, then raise TOOL_ERR.TOOL_ERROR to terminate processing.
- Step 6 - If a PROPERTY_ERROR exception is raised during any property-set call, raise TOOL_ERR.TOOL_ERROR immediately to terminate processing without displaying an alert.

---
**Decision Points**

DP-001

Condition:
A BEAN_NOT_REGISTERED exception is raised when attempting to set any of the three WUF_PACKAGE properties.

TRUE:
WEBUTIL.ERRORALERT is called to display an error message identifying the missing bean implementation class (obtained via WEBUTIL.GETIMPLCLASS), informing the user that CLIENT_TEXT_IO.put_line will not work. TOOL_ERR.TOOL_ERROR is then raised to abort the calling procedure.

FALSE:
Processing continues to the next property-set call or completes normally.

---

DP-002

Condition:
A PROPERTY_ERROR exception is raised when attempting to set any of the three WUF_PACKAGE properties.

TRUE:
TOOL_ERR.TOOL_ERROR is raised immediately to abort the calling procedure. No alert is displayed.

FALSE:
Processing continues to the next property-set call or completes normally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file handle, the text content, and the newline signal must each be delivered to the WUF_PACKAGE bean as discrete, sequential property-set operations; they cannot be collapsed into a single call.
- BR-002 - A newline is always appended after the text content (WUF_TEXTIO_NEWLINE is always set to 1); this procedure unconditionally writes a full line, not a partial string.
- BR-003 - The WUF_PACKAGE client-side bean must be registered and available on the client before this procedure is invoked; absence of the bean is a fatal condition that prevents any file write operation.
- BR-004 - Both BEAN_NOT_REGISTERED and PROPERTY_ERROR conditions are treated as unrecoverable errors; in both cases TOOL_ERR.TOOL_ERROR is raised to propagate the failure to the caller.
- BR-005 - When a BEAN_NOT_REGISTERED error occurs, the error message presented to the user must include the implementation class name (retrieved via WEBUTIL.GETIMPLCLASS) to aid diagnosis.

---
**Implementation Logic**

```plsql
    

  PROCEDURE put_line (file file_type, item VARCHAR2) is
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);              
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_PUT',item); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_NEWLINE',1); 
  EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.put_line will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;  
  END put_line;
```

#### SP-048 - WEBUTIL.REGISTER_FUNCTION

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a named function from a specified library with the WebUtil bean layer and returns a FunctionHandle that uniquely identifies the registered function for subsequent calls. The procedure communicates the library and function specification to the WebUtil core component, retrieves the resulting handle token, and increments the internal function-handle counter when registration succeeds.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| libName | VARCHAR2 | IN |
| funcName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-044](#SP-044--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Concatenate the input library name (libName) and function name (funcName) into a pipe-delimited specification string and write it to the WebUtil core property WUL_FUNCTION_SPEC on the WUL_PACKAGE component.
- Step 2 - Request the registered function handle from the WebUtil core by reading the WUL_REGISTER_FUNCTION property on the WUL_PACKAGE component; the bean layer returns an 8-character string token representing the handle.
- Step 3 - Convert the returned string token to a numeric value and assign it to the hnd attribute of a local FunctionHandle variable.
- Step 4 - Evaluate the resulting FunctionHandle using WEBUTIL.ID_NULL (SP-044). If the handle is not null (i.e., registration produced a valid handle), increment the module-level function-handle counter (m_funcHandleCount) by 1.
- Step 5 - Return the populated FunctionHandle to the caller.
- Step 6 (Exception - BEAN_NOT_REGISTERED) - If the WebUtil bean is not registered, display an error alert identifying the missing implementation class and raise FORM_TRIGGER_FAILURE to halt processing.
- Step 7 (Exception - PROPERTY_ERROR) - If a property read/write error occurs within the WebUtil core, raise FORM_TRIGGER_FAILURE to halt processing.
- Step 8 (Exception - VALUE_ERROR) - If the string-to-number conversion of the handle token fails, raise TOOL_ERR.TOOL_ERROR.

---
**Decision Points**

DP-001

Condition: The FunctionHandle returned from the WebUtil core is evaluated by WEBUTIL.ID_NULL to determine whether it represents a valid (non-null) handle.

TRUE (handle is NOT null - registration succeeded): The module-level counter m_funcHandleCount is incremented by 1, recording that an additional function handle is active.

FALSE (handle IS null - registration did not produce a valid handle): The counter is not incremented; the null FunctionHandle is still returned to the caller.

---

DP-002

Condition: A BEAN_NOT_REGISTERED exception is raised by the WebUtil core during the property set or get operation, indicating the required WebUtil bean is absent.

TRUE: An error alert is displayed to the user identifying the missing bean class, and FORM_TRIGGER_FAILURE is raised to abort the current form trigger.

FALSE: Normal processing continues (no alert is shown for this condition).

---

DP-003

Condition: A PROPERTY_ERROR exception is raised by the WebUtil core during the property set or get operation.

TRUE: FORM_TRIGGER_FAILURE is raised immediately to abort the current form trigger; no additional messaging is performed.

FALSE: Normal processing continues.

---

DP-004

Condition: A VALUE_ERROR exception is raised when converting the returned string token to a number via TO_NUMBER.

TRUE: TOOL_ERR.TOOL_ERROR is raised, signalling a data-conversion failure to the calling environment.

FALSE: Normal processing continues and the numeric handle is assigned successfully.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The library name and function name must both be supplied as input; they are combined into a single pipe-delimited specification (libName || '|' || funcName) before being passed to the WebUtil core, meaning neither value may independently contain the pipe character in a way that would corrupt the specification.
- BR-002 - A FunctionHandle is considered valid only if WEBUTIL.ID_NULL returns FALSE for it; only valid handles cause the module-level registration counter (m_funcHandleCount) to be incremented.
- BR-003 - The WebUtil bean identified by the WUL_PACKAGE implementation class must be registered and available at the time of invocation; absence of the bean is a fatal condition that terminates form processing via FORM_TRIGGER_FAILURE.
- BR-004 - Any failure to read or write WebUtil core properties (PROPERTY_ERROR) is treated as a fatal condition and immediately terminates form processing via FORM_TRIGGER_FAILURE without additional user messaging.
- BR-005 - The handle token returned by the WebUtil core must be convertible to a numeric value; a conversion failure (VALUE_ERROR) escalates to TOOL_ERR.TOOL_ERROR, indicating an unrecoverable data integrity issue with the returned handle.

---
**Implementation Logic**

```plsql

  FUNCTION REGISTER_FUNCTION (libName IN VARCHAR2, funcName IN VARCHAR2) 
                              RETURN FunctionHandle IS
    strHnd  VARCHAR2(8);                            
    funcHnd FunctionHandle;
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUL_PACKAGE,'WUL_FUNCTION_SPEC', libName || '|' || funcName);
    strHnd := WebUtil_Core.getProperty(WebUtil_Core.WUL_PACKAGE,'WUL_REGISTER_FUNCTION');
    funcHnd.hnd := TO_NUMBER (strHnd);
    if NOT ID_NULL(funcHnd) then
      m_funcHandleCount := m_funcHandleCount + 1;
    end if;

    RETURN funcHnd;
    
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUL_PACKAGE)
                              ||' bean not found. WEBUTIL_C_API.REGISTER_FUNCTION will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;  
    when VALUE_ERROR then
        RAISE TOOL_ERR.TOOL_ERROR; 
  END REGISTER_FUNCTION;
```

#### SP-049 - WEBUTIL.RELEASE_PROCESS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.HOST]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Releases a previously acquired host process handle by clearing its associated callback trigger and nullifying the process identifier. This ensures that resources tied to a WebUtil host process are properly relinquished after use, preventing stale or orphaned process references within the WebUtil framework.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN OUT |

---

**Dependencies**

- WEBUTIL.CLEARCALLBACKTRIGGER ([SP-030](#SP-030--WEBUTIL.CLEARCALLBACKTRIGGER)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the process handle (PROCESS_ID) as an IN OUT parameter representing an active WebUtil host process to be released.
- Step 2 - Invoke WebUtil_Core.setProperty to register the WUH_CLEAR_PROC property against the WUH_PACKAGE, passing the current process handle value, signalling to the WebUtil core that this process is being cleared.
- Step 3 - Invoke WEBUTIL.CLEARCALLBACKTRIGGER (via WebUtil_Core.ClearCallbackTrigger) with the process handle to remove any callback trigger registered against that process, ensuring no residual trigger remains active.
- Step 4 - Set the process handle to NULL, formally releasing the caller's reference to the process.
- Step 5 - If a BEAN_NOT_REGISTERED exception is raised during any of the above steps, display an error alert identifying the missing WebUtil bean class and informing the user that WEBUTIL_HOST.Release_Process will not function, then exit without further processing.

---
**Decision Points**

DP-001

Condition: A BEAN_NOT_REGISTERED exception is raised when attempting to set the process property or clear the callback trigger (i.e., the WebUtil host bean has not been registered in the runtime environment).

TRUE: An error alert is displayed, incorporating the implementation class name of WUH_PACKAGE, notifying the user that the required bean was not found and that the release operation cannot complete. The process handle is not nullified.

FALSE: The callback trigger is successfully cleared and the process handle is set to NULL, completing the release normally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The process handle must be provided as an IN OUT parameter; the procedure will null the caller's reference upon successful completion, enforcing that a released process cannot be reused without re-acquisition.
- BR-002 - The WUH_CLEAR_PROC property must be set on the WUH_PACKAGE before the callback trigger is cleared, ensuring the WebUtil core is notified of the release intent prior to trigger removal.
- BR-003 - WEBUTIL.CLEARCALLBACKTRIGGER must be called with the process handle before the handle is nullified, guaranteeing that no orphaned callback trigger persists after the process is released.
- BR-004 - If the WebUtil host bean is not registered (BEAN_NOT_REGISTERED), the procedure must not silently fail; an error alert identifying the missing bean class must be presented to the user, and the release operation is aborted.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Release_Process(process in out PROCESS_ID) is  
  begin
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_CLEAR_PROC',process.handle);
    WebUtil_Core.ClearCallbackTrigger(process.handle);
    process.handle := null;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.Release_Process will not work');
  end Release_Process;
```

#### SP-050 - WEBUTIL.SETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.PUT_LINE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sets a named JVM system property to a specified value by delegating to the Java Native Interface (JNI) layer. The function wraps a direct call to java.lang.System.setProperty, allowing Oracle Forms runtime to read or influence JVM-level configuration properties. It returns the previous value of the property as a VARCHAR2 string.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |
| a1 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive two VARCHAR2 input parameters: a0 (the property name/key) and a1 (the new property value to assign).
- Step 2 - Initialise a JNI argument list sized for exactly two arguments by calling JNI.CREATE_ARG_LIST(2), storing the handle in the shared args variable.
- Step 3 - Append the property name (a0) to the argument list as a String argument via JNI.ADD_STRING_ARG.
- Step 4 - Append the property value (a1) to the argument list as a second String argument via JNI.ADD_STRING_ARG.
- Step 5 - Invoke the static Java method java.lang.System.setProperty(String, String) through JNI.CALL_STRING_METHOD, passing the fully-qualified class path, method name, JNI method signature, and the prepared argument list.
- Step 6 - Return the VARCHAR2 result from JNI.CALL_STRING_METHOD to the caller; this result represents the previous value of the named property as reported by the JVM, or NULL if the property was not previously set.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a fixed sequence of JNI calls unconditionally for all valid inputs.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Both the property name (a0) and the property value (a1) must be supplied as VARCHAR2 values; the function passes them directly to the JVM without null-guarding, so callers are responsible for providing non-null, well-formed property key/value pairs.
- BR-002 - The argument list must be constructed with exactly two positional String arguments in the order: property name first, property value second, matching the signature expected by java.lang.System.setProperty.
- BR-003 - The function targets the static Java method java.lang.System.setProperty via its fully-qualified JNI descriptor '(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;'; any change to the target class or method signature would require a corresponding update to this descriptor.
- BR-004 - The return value represents the JVM's previous value for the named property and must be handled by the caller; a NULL return indicates the property had no prior value in the JVM system properties map.

---
**Implementation Logic**

```plsql
  FUNCTION setProperty(
    a0    VARCHAR2,
    a1    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(2);
    JNI.ADD_STRING_ARG(args, a0);
    JNI.ADD_STRING_ARG(args, a1);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'setProperty', '(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-051 - WEBUTIL.URL_TO_CLIENT

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Transfers a file from a server-side URL to a specified destination path on the client machine. The procedure acts as a named wrapper that delegates the actual download operation to WEBUTIL.DOWNLOADFROMURL, providing a semantically descriptive entry point for callers such as VIEW_EXCEL_REPORT_NEW when delivering generated Excel report files to the end user's workstation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| fileSize | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.DOWNLOADFROMURL ([SP-031](#SP-031--WEBUTIL.DOWNLOADFROMURL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the source URL identifying the server-side file to be downloaded, the client destination path where the file is to be saved, and an optional file size hint (defaulting to 0 if not supplied).
- Step 2 - Delegate the download operation to WEBUTIL.DOWNLOADFROMURL (SP-031), passing through all three parameters (sourceURL, clientDestination, fileSize) unchanged.
- Step 3 - Return the BOOLEAN result produced by WEBUTIL.DOWNLOADFROMURL directly to the caller, indicating whether the file transfer completed successfully.

---
**Decision Points**

DP-001

Condition: Was a fileSize value explicitly supplied by the caller?

TRUE: The provided fileSize integer is passed to WEBUTIL.DOWNLOADFROMURL, allowing the download utility to use the known size for transfer management.

FALSE: fileSize defaults to 0, and WEBUTIL.DOWNLOADFROMURL is invoked with 0 as the size argument, indicating that the file size is unknown at the time of the call.

DP-002

Condition: Does WEBUTIL.DOWNLOADFROMURL return TRUE?

TRUE: The function returns TRUE to the caller, signalling that the file was successfully transferred to the client destination.

FALSE: The function returns FALSE to the caller, signalling that the file transfer failed.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The sourceURL parameter must identify a reachable server-side resource; no URL validation is performed within this function - responsibility for a valid URL rests with the caller.
- BR-002 - The clientDestination parameter must specify the full target path on the client machine; the function does not derive or modify the destination path.
- BR-003 - fileSize is optional; when omitted, a default value of 0 is used, meaning the download utility operates without a pre-declared file size.
- BR-004 - The function's success or failure is determined solely by the result returned from WEBUTIL.DOWNLOADFROMURL; no additional validation or error handling is applied within this wrapper.

---
**Implementation Logic**

```plsql
  FUNCTION URL_To_Client(sourceURL         in VARCHAR2, 
                         clientDestination in VARCHAR2, 
                         fileSize          in PLS_INTEGER default 0) return BOOLEAN is
  BEGIN
      return WebUtil_Core.DownLoadFromURL(sourceURL, 
                                        clientDestination, 
                                        fileSize);
  END URL_To_Client;
```

#### SP-052 - WEBUTIL.WAIT

**Invoked From:**

- PK_VALIDATE_BACK_DATE.pck [StoredProcedure: PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Invokes the Java-side `wait` method on an `AppServerFileWriter` object via the Oracle Forms WebUtil JNI bridge. The procedure suspends or coordinates execution of the file-transfer component on the application server for a specified duration, accepting a long timeout value and an integer qualifier to control the wait behaviour.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |
| a0 | NUMBER | IN |
| a1 | NUMBER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java object reference (`obj`) together with two numeric wait parameters (`a0` as a long value, `a1` as an integer value).
- Step 2 - Allocate a JNI argument list sized for exactly two arguments by calling `JNI.CREATE_ARG_LIST(2)`.
- Step 3 - Append the first parameter (`a0`) to the argument list as a LONG argument via `JNI.ADD_LONG_ARG`.
- Step 4 - Append the second parameter (`a1`) to the argument list as an INT argument via `JNI.ADD_INT_ARG`.
- Step 5 - Invoke the Java `wait(long, int)` method (JNI signature `(JI)V`) on the `oracle/forms/webutil/fileTransfer/AppServerFileWriter` class through `JNI.CALL_VOID_METHOD`, passing the populated argument list. No return value is captured.

---
**Decision Points**

No conditional decision points exist in this procedure. Execution follows a single, unconditional path: build the argument list and dispatch the JNI call.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The argument list must be constructed with exactly two entries; the first must be a LONG type (mapped from `a0`) and the second must be an INT type (mapped from `a1`), matching the Java method signature `(JI)V`.
- BR-002 - The JNI call targets the fully qualified Java class `oracle/forms/webutil/fileTransfer/AppServerFileWriter`; the procedure must not be used to invoke `wait` on any other class.
- BR-003 - The procedure produces no return value and performs no database interaction; its sole effect is the side-effect of the Java `wait` call on the supplied object reference.
- BR-004 - This procedure is called exclusively from `PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM`; it must not be invoked outside that controlled context without explicit authorisation.

---
**Implementation Logic**

```plsql
  PROCEDURE wait(
    obj   ORA_JAVA.JOBJECT,
    a0    NUMBER,
    a1    NUMBER) IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(2);
    JNI.ADD_LONG_ARG(args, a0);
    JNI.ADD_INT_ARG(args, a1);
    JNI.CALL_VOID_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileWriter', 'wait', '(JI)V', args); 
  END;
```

#### SP-053 - WEBUTIL_FILE.FILE_SAVE_DIALOG

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]
- pt_phy_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

PART DETAILS (N/A / CN_MAIN)

---

**Purpose**

Presents the user with a native OS Save File dialog, allowing them to specify a target directory, file name, and file type filter for saving a file. The function delegates to WEBUTIL.FILE_SELECTION_DIALOG_INT with save-mode flags, returning the fully qualified file path selected by the user.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| directory_name | Varchar2 | IN |
| file_name | Varchar2 | IN |
| file_filter | Varchar2 | IN |
| title | Varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- D2KWUTIL.SAVE_FILE ([SP-015](#SP-015--D2KWUTIL.SAVE_FILE)) - D2KWUTIL.pck (or .pld)
- WEBUTIL.FILE_SELECTION_DIALOG_INT ([SP-037](#SP-037--WEBUTIL.FILE_SELECTION_DIALOG_INT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the optional input parameters: directory_name (initial directory), file_name (default file name), file_filter (file type filter), and title (dialog window title).
- Step 2 - Invoke WEBUTIL.FILE_SELECTION_DIALOG_INT, passing the four caller-supplied parameters together with the D2KWUTIL.SAVE_FILE mode constant, TRUE for the save-mode flag, and FALSE for the multi-select flag.
- Step 3 - Return the Varchar2 result from WEBUTIL.FILE_SELECTION_DIALOG_INT to the caller, which represents the fully qualified file path chosen by the user in the Save dialog, or NULL if the user cancelled.

---
**Decision Points**

No conditional decision points exist within this function. All branching logic is encapsulated inside WEBUTIL.FILE_SELECTION_DIALOG_INT; FILE_SAVE_DIALOG unconditionally delegates to that routine with fixed save-mode arguments and returns its result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - All four input parameters (directory_name, file_name, file_filter, title) are optional; each defaults to NULL, allowing callers to invoke the dialog with partial or no pre-population.
- BR-002 - The dialog is always opened in save mode, enforced by passing the D2KWUTIL.SAVE_FILE constant as the dialog-mode argument to WEBUTIL.FILE_SELECTION_DIALOG_INT.
- BR-003 - Multi-file selection is explicitly disabled (FALSE), ensuring the dialog returns at most one file path.
- BR-004 - The function returns the file path string produced by WEBUTIL.FILE_SELECTION_DIALOG_INT directly to the caller without modification; a NULL return indicates the user dismissed or cancelled the dialog.

---
**Implementation Logic**

```plsql
                                        
  FUNCTION FILE_SAVE_DIALOG(            directory_name Varchar2 := NULL,
                                        file_name      Varchar2 := NULL,
                                        file_filter    Varchar2 := NULL,
                                        title          Varchar2 := NULL) return Varchar2 is
  BEGIN
    RETURN FILE_SELECTION_DIALOG_INT(   directory_name,
                                        file_name,
                                        file_filter,
                                        title,
                                        SAVE_FILE,
                                        TRUE,
                                        FALSE); 
  END FILE_SAVE_DIALOG;
```

#### SP-054 - ADD_ERROR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.SAVE_FILE]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Records a runtime error by setting a global error flag and composing a standardised error stack entry that combines the calling function name with the error description text. The procedure also writes the composed error message to the debug log via DEBUGLOG (SP-058), ensuring that error occurrences are both flagged for downstream conditional checks and traceable in the debug output.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| CallingFunction | VARCHAR2 | IN |
| SetErrorText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-058](#SP-058--DEBUGLOG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Accept the name of the calling function (CallingFunction) and the error description text (SetErrorText) as inputs.
- Step 2 - Set the global flag ERROR_ENCOUNTERED to TRUE to signal that an error condition has been raised.
- Step 3 - Compose the ERROR_STACK value by concatenating CallingFunction, a colon-space separator, and the first 1,968 characters of SetErrorText, enforcing a maximum length on the error message portion.
- Step 4 - Invoke DEBUGLOG (SP-058) via Win_API_Debug.DebugLog at debug level 99, identifying the source as 'Add_Error', and passing the composed ERROR_STACK value as the message to be logged.

---
**Decision Points**

No conditional decision points are present in this procedure. All steps execute unconditionally for every invocation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The ERROR_ENCOUNTERED flag must be set to TRUE whenever this procedure is called, unconditionally marking the session as having encountered an error.
- BR-002 - The error stack entry must be formatted as '<CallingFunction>: <SetErrorText>' to ensure consistent identification of the error source.
- BR-003 - The error description text (SetErrorText) must be truncated to a maximum of 1,968 characters when stored in ERROR_STACK, preventing overflow of the error stack variable.
- BR-004 - Every error recorded through this procedure must be written to the debug log at severity level 99 via DEBUGLOG (SP-058), guaranteeing an audit trail of all error occurrences.

---
**Implementation Logic**

```plsql

PROCEDURE Add_Error (CallingFunction in VARCHAR2, SetErrorText in VARCHAR2) is
begin 
  -- Just watch for value errors 
  ERROR_ENCOUNTERED  := TRUE;
  ERROR_STACK    := CallingFunction||': '||substr(SetErrorText,1,1968);
  Win_API_Debug.DebugLog(99,'Add_Error',ERROR_STACK);
end Add_Error;
```

#### SP-055 - ADD_EXTERNAL_ERRORS

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Collects and consolidates external error messages into a single string buffer for return to the caller. The function first drains the Oracle Forms tool_err error stack by iterating through all pending errors and concatenating their messages; if no tool_err errors are present but a SQL error exists, it captures the current SQLERRM instead. The resulting buffer is returned as a VARCHAR2 for upstream error reporting or display.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Initialise a PLS_INTEGER counter (iCounter) and a VARCHAR2 buffer (vcErrBuff, max 1968 characters) to hold accumulated error text.
- Step 2 - Check whether the tool_err error stack contains one or more errors (tool_err.nerrors > 0).
- Step 3 - If errors exist on the tool_err stack, iterate from 1 to tool_err.nerrors; for each iteration, append a newline character (CHR(10)) followed by the current top-of-stack message (tool_err.message) to vcErrBuff.
- Step 4 - After each successful append, pop the processed error from the tool_err stack (tool_err.pop) to advance to the next error.
- Step 5 - If appending a message would cause vcErrBuff to exceed its maximum length, a VALUE_ERROR exception is raised; the handler exits the loop immediately, preserving the messages already collected and discarding any remaining errors that would overflow the buffer.
- Step 6 - If the tool_err stack is empty but SQLERRM is not null, append a newline followed by the SQLERRM text to vcErrBuff as the sole error entry.
- Step 7 - Return vcErrBuff to the caller, containing all collected error messages separated by newline characters (or an empty/null string if no errors were present).

---
**Decision Points**

DP-001

Condition: tool_err.nerrors > 0

TRUE: Enter the FOR loop to iterate through and collect all messages from the tool_err error stack, appending each to vcErrBuff and popping it from the stack.

FALSE: Skip the tool_err loop and evaluate whether SQLERRM is not null (proceed to DP-002).

---

DP-002

Condition: SQLERRM is not null (evaluated only when tool_err.nerrors = 0)

TRUE: Append a newline and the SQLERRM text to vcErrBuff as the fallback error source.

FALSE: No error text is added; vcErrBuff remains empty/null and is returned as-is.

---

DP-003

Condition: Appending the next tool_err message to vcErrBuff raises a VALUE_ERROR exception (i.e., the buffer would exceed 1968 characters)

TRUE: Exit the iteration loop immediately, discarding any remaining unprocessed tool_err messages to prevent a buffer overflow.

FALSE: Continue appending and popping messages until the loop completes normally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The error message buffer is capped at 1968 characters (VARCHAR2(1968)); any tool_err messages that would cause the buffer to exceed this limit are silently discarded, ensuring the function always returns a value within the allowable size.
- BR-002 - Each error message appended to the buffer is prefixed with a newline character (CHR(10)), producing a line-separated list of error texts in the returned string.
- BR-003 - The tool_err stack takes precedence over SQLERRM; the SQL error message is only captured when the tool_err stack contains no errors, preventing duplication of error sources.
- BR-004 - Every tool_err entry that is successfully appended to the buffer must be popped from the stack (tool_err.pop), ensuring the stack is progressively consumed and no message is reported more than once.
- BR-005 - The function returns an empty or null string when neither tool_err errors nor a non-null SQLERRM are present, indicating a clean error state to the caller.

---
**Implementation Logic**

```plsql

FUNCTION Add_External_Errors return varchar2 is
  iCounter   pls_integer;
  vcErrBuff  varchar2(1968);
begin 
  if tool_err.nerrors > 0 then 
    for iCounter in 1..tool_err.nerrors LOOP
      begin 
        vcErrBuff := vcErrBuff||chr(10)||tool_err.message;
      exception
        when VALUE_ERROR then 
          exit; /* String exceeds allowable buffer */
      end;
      tool_err.pop;
    end loop;
  elsif SQLERRM is not null then 
    vcErrBuff := chr(10)||SQLERRM; 
  end if;
  return vcErrBuff;
end Add_External_Errors;
```

#### SP-056 - BOOLTOCHAR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

BOOLTOCHAR is a utility function that converts a PL/SQL BOOLEAN value into its VARCHAR2 string equivalent ('TRUE' or 'FALSE'). It is used internally within the D2KWUTIL package to allow boolean results to be returned or displayed as character strings in contexts where a VARCHAR2 representation is required, supporting CHOOSEFILE, GET_ACTIVE_WINDOW, GET_TEMP_DIRECTORY, and GET_WINDOWS_DIRECTORY.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| ThisBoolean | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input BOOLEAN value (ThisBoolean) passed by the calling routine.
- Step 2 - Evaluate the BOOLEAN value using a conditional check.
- Step 3 - If the value evaluates to TRUE, return the VARCHAR2 literal 'TRUE' to the caller.
- Step 4 - If the value does not evaluate to TRUE (i.e., FALSE or NULL resolves to the ELSE branch), return the VARCHAR2 literal 'FALSE' to the caller.

---
**Decision Points**

DP-001

Condition:
ThisBoolean evaluates to TRUE.

TRUE:
The function returns the VARCHAR2 string 'TRUE' to the calling routine.

FALSE:
The function returns the VARCHAR2 string 'FALSE' to the calling routine.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function accepts exactly one BOOLEAN input parameter and always returns a non-null VARCHAR2 value; no null or empty string is ever returned.
- BR-002 - The only permissible return values are the string literals 'TRUE' and 'FALSE'; no other representations are produced.
- BR-003 - A BOOLEAN value that does not satisfy the TRUE condition (including a FALSE or NULL value) is unconditionally mapped to the string 'FALSE'.
- BR-004 - The function has no internal or external dependencies; all logic is self-contained within the function body.
- BR-005 - The function is invoked by four callers within D2KWUTIL: CHOOSEFILE, GET_ACTIVE_WINDOW, GET_TEMP_DIRECTORY, and GET_WINDOWS_DIRECTORY; its contract must remain stable across all four invocation sites.

---
**Implementation Logic**

```plsql

  
  FUNCTION  BoolToChar(ThisBoolean IN BOOLEAN) return VARCHAR2 is
  begin
  	if ThisBoolean then 
  		RETURN 'TRUE';
  	else
  	    RETURN 'FALSE';
  	end if;
  end BoolToChar;

END;

PACKAGE WIN_API_DIALOG IS

/*-------------------------------------------------------------------------*\
 * WIN_API_DIALOG ->   This package is concerned with Displaying Common
 *      dialogs
 * Contents:
 *    Open_File    -> Open File Dialog
 *    Save_File    -> Save File Dialog
 *    Select_Printer    -> Printer Selection Dialog
 *    Choose_Font       -> Display the Font Selection Dialog
 *    Choose_Color      -> Display the Color Selection Dialog
 * Dependancies:
 *    WIN_API_ENVIRONMENT
 *    WIN_API
 *    WIN_API_DEBUG
\*-------------------------------------------------------------------------*/ 

/*-------------------------------------------------------------------------*\
 * Open_File        -> Displays the standard Open File dialog
 * Arguments: 
 *  Title           -> The Title for the Dialog Box
 *                     (Default -> 'Open File')
 *  StartDirectory  -> Where the dialog should start from
 *                     this should be in the format 'C:\TEMP'
 *                     (Default -> Windows Directory)
 *  FileFilter      ->  Restrict the list of files. The filter string 
 *                      should be in the format:
 *                      '<Description>|<filename>.<Extension>|'
 *                      typically this would be something like
 *                      'All files(*.*)|*.*|' or 'Text files(*.txt)|*.txt|'
 *                      "All Files" is the Default
 *  Modal           ->  Should the dialog be modal with respect to the 
 *                      application? 
 *                      default = TRUE
 *  AdvancedFlags   ->  (See list in WIN_API header) This option allows
 *                      you to change the attributes of the Open File 
 *                      dialog.  Here are some of the Flags that might
 *                      be of interest:
 *                      OFN_HIDEREADONLY  Hides the Read Only check box.
 *                      OFN_NONETWORKBUTTON  Hides the Network Button
 *                      OFN_EXPLORER    Display an Explorer style 
 *                        Dialog rather than the conventional one.
 *                      See your Microsoft docmentation for details on 
 *                      each flag.
 *                      To Set the Advanced_Flags varaible, just add the 
 *                      required flags together.  The default is:
 *                      WIN_API.OFN_PATHMUSTEXIST + WIN_API.OFN_FILEMUSTEXIST +
 *                      WIN_API.OFN_HIDEREADONLY + WIN_API.OFN_NOCHANGEDIR 
 *  RaiseExceptions ->  TRUE of FALSE(Default) If set to true, then if the 
 *                      command is not successful (e.g no filename is  
 *                      returned) then the explicit exception
 *                      NO_DATA_FOUND will be raised.
 *        
 * Returns:
 *  Path and name of the selected file
\*-------------------------------------------------------------------------*/
```

#### SP-057 - CLEAN_ERROR_STACK

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Resets the shared error-tracking state by clearing the error-encountered flag and nullifying the error stack. This procedure is called at the start of utility operations (such as file selection and directory retrieval) to ensure no residual error information from a previous execution influences the current operation.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Set the package-level boolean variable ERROR_ENCOUNTERED to FALSE, indicating that no error condition is currently active.
- Step 2 - Set the package-level variable ERROR_STACK to NULL, removing any previously accumulated error messages from the stack.
- Step 3 - Return control to the calling routine with both error-state variables in a clean, initialised state.

---
**Decision Points**

No decision points exist in this procedure. The reset of ERROR_ENCOUNTERED and ERROR_STACK is unconditional on every invocation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - ERROR_ENCOUNTERED must be set to FALSE on every invocation, regardless of its prior value, ensuring no stale error flag persists across utility calls.
- BR-002 - ERROR_STACK must be set to NULL on every invocation, ensuring no residual error message text is carried forward into a subsequent utility operation.
- BR-003 - The procedure accepts no input and produces no formal output; its sole effect is the unconditional reset of the two shared error-state variables.

---
**Implementation Logic**

```plsql

PROCEDURE Clean_Error_Stack is 
begin 
  -- just empty the variables
  ERROR_ENCOUNTERED  := FALSE;
  ERROR_STACK        := NULL;
end Clean_Error_Stack;
```

#### SP-058 - DEBUGLOG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: ADD_ERROR]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: SETDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

DEBUGLOG writes a formatted diagnostic message to one of two output channels - a Windows debug viewer (via WINDEBUG) or a flat-file log (via TEXT_IO) - depending on the current debug state and the availability of the Windows debug API. It is a shared utility called by multiple D2kwutil procedures to provide a consistent, centrally controlled trace facility across the library. When the Windows debug API is unavailable, DEBUGLOG delegates to SETDEBUG to transparently switch the active channel to file-based logging and retries the write, ensuring no diagnostic output is silently lost.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugLevel | PLS_INTEGER | IN |
| LoggingCall | VARCHAR2 | IN |
| LogString | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- SETDEBUG ([SP-063](#SP-063--SETDEBUG)) - matched by member name
- WEBUTIL.LENGTH ([SP-045](#SP-045--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)
- WINDEBUG ([SP-077](#SP-077--WINDEBUG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Guard checks: if the global debug state (iDebugState) is 0 (disabled), or if debugging is paused (bDebugPaused is TRUE), or if the caller's DebugLevel exceeds the configured threshold (iDebugLevel), the procedure exits immediately without writing anything.
- Step 2 - Timestamp construction: if the bDebugTimeStamp flag is TRUE, the current time is formatted as HH24:MI:SS and appended with '> ' to form vcDateStamp; otherwise vcDateStamp remains empty.
- Step 3 - Message prefix construction: vcDebugString is assembled by concatenating the zero-padded DebugLevel enclosed in angle brackets, the optional timestamp, and the LoggingCall suffixed with ':' and right-padded to 30 characters.
- Step 4 - Message body appended: LogString is appended to the prefix using SUBSTR, limiting LogString to (2000 minus the current prefix length) characters so that vcDebugString never exceeds 2,000 characters; the prefix length is obtained via WEBUTIL.LENGTH.
- Step 5 - Output channel selection: if iDebugState = 2 (Windows debug viewer mode) and DEBUG_API_ENABLED is TRUE, the assembled string is passed to WINDEBUG (win_api_debug.WinDebug) for output to the Windows debug viewer.
- Step 6 - API unavailable fallback: if iDebugState = 2 but DEBUG_API_ENABLED is FALSE, SETDEBUG is called to switch the debug channel to file logging (state 1) targeting vcDebugFile (defaulting to 'd2kwutil.log'), the flag bDebugType2Required is set to TRUE, and DEBUGLOG calls itself recursively to re-attempt the original message under the new channel.
- Step 7 - Deferred API restoration: if iDebugState is not 2 but bDebugType2Required is TRUE and DEBUG_API_ENABLED is now TRUE, SETDEBUG is called to restore the debug channel to state 2, bDebugType2Required is reset to FALSE, and DEBUGLOG calls itself recursively to write the original message to the Windows debug viewer.
- Step 8 - File logging: if neither the Windows viewer path nor the restoration path applies, the assembled string is written to the file identified by vcDebugFile by opening it in append mode with TEXT_IO.FOPEN, writing the line with TEXT_IO.PUT_LINE, and closing it with TEXT_IO.FCLOSE.
- Step 9 - Exception handling: if any unhandled exception occurs, iDebugState is set to 0 to disable the debug facility entirely, preventing diagnostic errors from propagating to the calling procedure.

---
**Decision Points**

DP-001
Condition: iDebugState = 0 (debug facility is globally disabled)
TRUE: Procedure exits immediately via NULL; no message is written.
FALSE: Evaluation continues to DP-002.

DP-002
Condition: bDebugPaused is TRUE (debug output is temporarily suspended)
TRUE: Procedure exits immediately via NULL; no message is written.
FALSE: Evaluation continues to DP-003.

DP-003
Condition: DebugLevel > iDebugLevel (caller's level exceeds the configured verbosity threshold)
TRUE: Procedure exits immediately via NULL; message is below the current verbosity threshold.
FALSE: Message qualifies for output; timestamp and prefix construction proceeds.

DP-004
Condition: bDebugTimeStamp is TRUE
TRUE: Current time (HH24:MI:SS) is formatted and appended with '> ' to form vcDateStamp, which is included in the message prefix.
FALSE: No timestamp is added; vcDateStamp remains empty.

DP-005
Condition: iDebugState = 2 (Windows debug viewer mode is active)
TRUE: Evaluation continues to DP-006 to determine API availability.
FALSE: Evaluation continues to DP-007 to determine whether to restore the Windows viewer or fall back to file logging.

DP-006
Condition: DEBUG_API_ENABLED is TRUE (Windows debug API functions are available)
TRUE: The assembled string is passed to WINDEBUG for output to the Windows debug viewer.
FALSE: SETDEBUG is called to switch the channel to file logging (state 1), bDebugType2Required is set to TRUE, and DEBUGLOG recurses to retry the message under the new channel.

DP-007
Condition: bDebugType2Required is TRUE AND DEBUG_API_ENABLED is TRUE (API has become available after a prior fallback)
TRUE: SETDEBUG is called to restore the channel to state 2, bDebugType2Required is reset to FALSE, and DEBUGLOG recurses to write the original message to the Windows debug viewer.
FALSE: The assembled string is written to the flat file identified by vcDebugFile using TEXT_IO (FOPEN / PUT_LINE / FCLOSE).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Debug output is suppressed entirely when iDebugState equals 0; no message may be written regardless of any other parameter value.
- BR-002 - Debug output is suppressed entirely when bDebugPaused is TRUE; the pause state takes precedence over all output logic.
- BR-003 - A message is only written when its DebugLevel is less than or equal to the configured threshold iDebugLevel; higher-level (more verbose) messages are silently discarded.
- BR-004 - The formatted debug string must not exceed 2,000 characters; LogString is truncated using SUBSTR to enforce this limit after the fixed prefix is constructed, with the prefix length determined via WEBUTIL.LENGTH.
- BR-005 - When iDebugState = 2, diagnostic messages must be routed to the Windows debug viewer via WINDEBUG; the flat-file channel is used only when the Windows debug API is unavailable.
- BR-006 - When iDebugState = 2 and DEBUG_API_ENABLED is FALSE, SETDEBUG must be called to switch the active channel to file logging (state 1) before any message is written, and bDebugType2Required must be set to TRUE to signal that the Windows viewer channel should be restored when the API becomes available again.
- BR-007 - When the Windows debug API becomes available again after a prior fallback (bDebugType2Required is TRUE and DEBUG_API_ENABLED is TRUE), SETDEBUG must be called to restore the channel to state 2 before the pending message is written, and bDebugType2Required must be reset to FALSE.
- BR-008 - If any unhandled exception occurs within DEBUGLOG, iDebugState must be set to 0 to disable the debug facility entirely, ensuring that a failure in diagnostic logging cannot propagate errors to calling procedures.

---
**Implementation Logic**

```plsql
   
PROCEDURE DebugLog (DebugLevel  IN PLS_INTEGER, 
                    LoggingCall IN VARCHAR2, 
                    LogString   IN VARCHAR2) is
 vcDateStamp   VARCHAR2(10);
 vcDebugString VARCHAR2(2000);
 hFile         TEXT_IO.FILE_TYPE;
begin
  if iDebugState = 0 then 
  	NULL;
  elsif bDebugPaused then 
  	NULL;
  elsif DebugLevel > iDebugLevel then 
  	NULL;
  else
  	-- Sort out the Datestamp	
  	if bDebugTimeStamp then 
  		vcDateStamp := to_char(SYSDATE,'HH24:MI:SS')||'> ';
  	end if;
  
  	-- Construct the final String
  	vcDebugString := '<'||lpad(to_char(DebugLevel),2,0)||'> '||vcDateStamp||rpad(LoggingCall||':',30);
    vcDebugString := vcDebugString||substr(LogString,1,(2000-length(vcDebugString)));
  
  	if iDebugState = 2 then
  		if DEBUG_API_ENABLED then 
  	   		win_api_debug.WinDebug(vcDebugString);
  		else
  			-- Can't use API calls if the API functions aren't there
	  		-- So Switch to File Logging to d2kwut$.log
	  		SetDebug(1,nvl(vcDebugFile,'d2kwutil.log'),iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Unable to Log to Debugger Switching to File');
			DebugLog(DebugLevel,LoggingCall,LogString);	  		
	  		bDebugType2Required := TRUE;
	  	end if;
  	else
     	if bDebugType2Required and DEBUG_API_ENABLED then
	     	-- API now Available - Reinstate Debugging to Debugger
	  		SetDebug(2,vcDebugFile,iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Restoring Logging to Debugger');
	  		bDebugType2Required := FALSE;
	  		DebugLog(Debuglevel,LoggingCall,LogString);
	
	  	else
		 	hFile := TEXT_IO.FOPEN(vcDebugFile,'A');
		 	TEXT_IO.PUT_LINE(hFile,vcDebugString);
		 	TEXT_IO.FCLOSE(hFile);
		end if;
  	end if;
  end if;
 exception
  	-- Don't let the debugging cause Problems of it's own
  	when others then 
  		iDebugState := 0;
 end DebugLog;
```

#### SP-059 - GET_TEMP_DIRECTORY

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the Windows temporary directory path for the current client session by invoking the native 'd2kwutil_TmpDir' function through the D2KWUTIL bridge (D2KWUTIL.D2KWUTIL_WINDIR). Before executing the lookup, the function logs entry diagnostics via DEBUGLOG and converts the RaiseExceptions flag to a loggable string via BOOLTOCHAR. It registers the external function call, initialises a 512-byte output buffer, invokes the native function directly, strips any trailing directory separator from the result via STRIPDIRSEP, and returns the clean path to the caller. Error handling is configurable via the RaiseExceptions flag, allowing callers to choose between a NULL return or a raised exception when no value is obtained.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-054](#SP-054--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-055](#SP-055--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-056](#SP-056--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-057](#SP-057--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_WINDIR ([SP-013](#SP-013--D2KWUTIL.D2KWUTIL_WINDIR)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-058](#SP-058--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-061](#SP-061--REGISTER_FUNCTION_CALL)) - matched by member name
- STRIPDIRSEP ([SP-075](#SP-075--STRIPDIRSEP)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log function entry diagnostics by calling DEBUGLOG at debug level 99, recording the function name 'Get_Temp_Directory' and the value of RaiseExceptions converted to a string via BOOLTOCHAR.
- Step 2 - Clear any pre-existing errors from the error stack by calling CLEAN_ERROR_STACK (WIN_API.Clean_Error_Stack).
- Step 3 - Initialise the return-code variable iRC to 0.
- Step 4 - Check whether the Windows API is available (WIN_API.API_ENABLED). If it is not available, raise the WIN_API.NOT_AVAILABLE exception immediately, bypassing all retrieval logic.
- Step 5 - Register the external function call for the Windows temporary-directory lookup using REGISTER_FUNCTION_CALL (WIN_API.Register_function_call), specifying the internal handle iTmpDir, the function name 'd2kwutil_TmpDir', and its calling signature ('INT', '*CHAR,INT').
- Step 6 - Initialise the output buffer vcBuff1 as a 512-character string padded with null characters (RPAD(' ', 512, CHR(0))).
- Step 7 - Invoke the native temporary-directory function by calling D2KWUTIL.D2KWUTIL_WINDIR (d2kwutil_WinDir) with the registered function handle (WIN_API.FunctionHandle(iTmpDir)), the output buffer vcBuff1, and the buffer size 512, capturing the integer return code in iRC.
- Step 8 - Log the result diagnostics by calling DEBUGLOG at debug level 99, recording the return code iRC and the populated buffer value vcBuff1.
- Step 9 - Evaluate the return code iRC. If iRC equals 0 (no value returned), record an error via ADD_ERROR and either raise NO_DATA_FOUND (if RaiseExceptions is TRUE) or return NULL (if RaiseExceptions is FALSE).
- Step 10 - If iRC is non-zero (success), pass the populated buffer vcBuff1 to STRIPDIRSEP (WIN_API.StripDirSep) to remove any trailing directory separator and return the resulting clean path to the caller.
- Step 11 - In the exception block: re-raise NO_DATA_FOUND as-is; for WIN_API.NOT_AVAILABLE, log the no-API error via ADD_ERROR and re-raise; for all other exceptions, log the unexpected error by combining the standard unexpected-error prefix with ADD_EXTERNAL_ERRORS via ADD_ERROR and re-raise.

---
**Decision Points**

DP-001

Condition: WIN_API.API_ENABLED is TRUE.

TRUE: Proceed to register the external function call, initialise the output buffer, and invoke D2KWUTIL.D2KWUTIL_WINDIR to retrieve the temporary directory path.

FALSE: Raise the WIN_API.NOT_AVAILABLE exception, bypassing all buffer initialisation and retrieval logic.

---

DP-002

Condition: The return code iRC returned by D2KWUTIL.D2KWUTIL_WINDIR equals 0.

TRUE: No directory value was returned; record an error via ADD_ERROR and branch on RaiseExceptions (see DP-003).

FALSE: A valid path was returned in vcBuff1; strip the trailing directory separator using STRIPDIRSEP and return the clean path to the caller.

---

DP-003

Condition: RaiseExceptions input parameter is TRUE (evaluated only when iRC = 0).

TRUE: Raise NO_DATA_FOUND to signal the absence of a temporary directory value to the caller.

FALSE: Return NULL silently to the caller without raising an exception.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must log its entry arguments before any processing occurs, using DEBUGLOG at debug level 99 with the RaiseExceptions value rendered as a string via BOOLTOCHAR, ensuring diagnostic traceability for every invocation.
- BR-002 - The function may only execute the temporary-directory lookup when the Windows API is available (WIN_API.API_ENABLED = TRUE); if the API is unavailable, execution is halted immediately and WIN_API.NOT_AVAILABLE is raised.
- BR-003 - The output buffer must be initialised as a 512-character null-padded string (RPAD(' ', 512, CHR(0))) before being passed to D2KWUTIL.D2KWUTIL_WINDIR, and the matching buffer-size argument must be passed as 512, ensuring the native function writes within the allocated boundary.
- BR-004 - The native temporary-directory lookup must be performed exclusively through D2KWUTIL.D2KWUTIL_WINDIR using the function handle obtained from WIN_API.FunctionHandle(iTmpDir); no WebUtil parameter-list construction is used in this implementation.
- BR-005 - A return code of 0 from D2KWUTIL.D2KWUTIL_WINDIR is treated as a failure condition (no value returned), not as a success indicator.
- BR-006 - The function must log the result of the native call (return code and buffer contents) via DEBUGLOG at debug level 99 immediately after D2KWUTIL.D2KWUTIL_WINDIR returns, before any branching on the return code.
- BR-007 - When the API call returns no value (iRC = 0), the caller's error-handling preference governs the outcome: RaiseExceptions = TRUE causes a NO_DATA_FOUND exception; RaiseExceptions = FALSE causes a NULL return, allowing the caller to handle the absence gracefully.
- BR-008 - The returned directory path must always have its trailing directory separator removed via STRIPDIRSEP before being returned to the caller, ensuring a consistent path format.
- BR-009 - All exceptions (WIN_API.NOT_AVAILABLE and unhandled others) must be logged via ADD_ERROR before being re-raised, ensuring the error stack is populated for upstream diagnostic use.
- BR-010 - Unexpected exceptions must include externally sourced error detail retrieved via ADD_EXTERNAL_ERRORS, appended to the standard unexpected-error prefix in the ADD_ERROR call, before the exception is re-raised.

---
**Implementation Logic**

```plsql

FUNCTION Get_Temp_Directory (RaiseExceptions IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  iRC        PLS_INTEGER;
begin 
  Win_API_Debug.DebugLog(99,'Get_Temp_Directory','Args: RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	 	
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then 
    win_api.Register_function_call(iTmpDir,'d2kwutil_TmpDir','INT','*CHAR,INT');
    vcBuff1    := RPAD(' ',512,CHR(0));
    iRC   := d2kwutil_WinDir(win_api.FunctionHandle(iTmpDir),vcBuff1,512);
    Win_API_Debug.DebugLog(99,'Get_Temp_Directory','Result:  RC='||to_char(iRC)||', vcBuff1="'||vcBuff1||'"');	      
  else
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0 then 
    Win_API.Add_error('Get_Temp_Directory','No Value Returned');
    if RaiseExceptions then
      raise NO_DATA_FOUND;
    else
      return NULL;
    end if;
  else
    return WIN_API.StripDirSep(vcBuff1);
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Temp_Directory',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Temp_Directory',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Temp_Directory;
```

#### SP-060 - GET_WINDOWS_DIRECTORY

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the Windows operating system directory path for the current client environment by invoking the external function D2KWUTIL.D2KWUTIL_WINDIR through the Win API layer. Before execution, diagnostic information is written via DEBUGLOG and BOOLTOCHAR to record the input arguments. The result is stripped of any trailing directory separator before being returned to the caller. The function supports optional exception raising, allowing callers to control whether a missing or unavailable result terminates processing or returns a NULL value silently.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-054](#SP-054--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-055](#SP-055--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-056](#SP-056--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-057](#SP-057--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_WINDIR ([SP-013](#SP-013--D2KWUTIL.D2KWUTIL_WINDIR)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-058](#SP-058--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-061](#SP-061--REGISTER_FUNCTION_CALL)) - matched by member name
- STRIPDIRSEP ([SP-075](#SP-075--STRIPDIRSEP)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Write a diagnostic entry via DEBUGLOG (Win_API_Debug.DebugLog at level 99), recording the procedure name and the value of RaiseExceptions converted to a readable string using BOOLTOCHAR (win_api_debug.booltochar).
- Step 2 - Clear any pre-existing errors from the error stack by calling CLEAN_ERROR_STACK (WIN_API.Clean_Error_Stack).
- Step 3 - Initialise the return code (iRC) to 0.
- Step 4 - Check whether the Win API layer is available (Win_API.API_ENABLED). If available, proceed to Step 5; otherwise raise the WIN_API.NOT_AVAILABLE exception.
- Step 5 - Register the external function call for 'd2kwutil_WinDir' with its signature ('INT', '*CHAR,INT') using REGISTER_FUNCTION_CALL (win_api.Register_function_call), storing the handle in iWinDir.
- Step 6 - Initialise the output buffer (vcBuff1) to a 512-character space-padded, null-terminated string using RPAD and CHR(0).
- Step 7 - Invoke D2KWUTIL.D2KWUTIL_WINDIR directly, passing the resolved function handle (win_api.FunctionHandle(iWinDir)), the output buffer vcBuff1, and the buffer length 512, capturing the integer return code in iRC.
- Step 8 - Write a second diagnostic entry via DEBUGLOG recording the return code and the populated buffer value.
- Step 9 - Evaluate iRC: if iRC equals 0, the external call returned no value; log an error via ADD_ERROR with the message 'No Value Returned' and branch on RaiseExceptions (see Decision Points).
- Step 10 - If iRC is non-zero, strip any trailing directory separator from vcBuff1 using STRIPDIRSEP (WIN_API.StripDirSep) and return the cleaned path to the caller.
- Step 11 - In the exception block: re-raise NO_DATA_FOUND as-is; for WIN_API.NOT_AVAILABLE, log the error via ADD_ERROR using the NoAPI message constant and re-raise; for all other exceptions, log the error via ADD_ERROR combining the UError message constant with external error detail obtained from ADD_EXTERNAL_ERRORS, then re-raise.

---
**Decision Points**

DP-001

Condition: Win_API.API_ENABLED is TRUE.

TRUE: Register the external function using REGISTER_FUNCTION_CALL, initialise the output buffer, invoke D2KWUTIL.D2KWUTIL_WINDIR to obtain the Windows directory path, write a diagnostic result entry via DEBUGLOG, and proceed to evaluate the return code.

FALSE: Raise the WIN_API.NOT_AVAILABLE exception, bypassing all external call and buffer logic.

---

DP-002

Condition: iRC (return code from D2KWUTIL.D2KWUTIL_WINDIR) equals 0.

TRUE: The external call returned no value. Log an error via ADD_ERROR with the message 'No Value Returned' and branch on RaiseExceptions (see DP-003).

FALSE: The external call succeeded. Strip the trailing directory separator from vcBuff1 using STRIPDIRSEP and return the resulting path to the caller.

---

DP-003

Condition: RaiseExceptions input parameter is TRUE (evaluated only when iRC = 0).

TRUE: Raise NO_DATA_FOUND to signal the absence of a Windows directory value to the caller.

FALSE: Return NULL silently, allowing the caller to handle the missing value without an exception.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - At the start of every execution, diagnostic information must be written via DEBUGLOG at level 99, including the procedure name and the RaiseExceptions argument value rendered as a character string using BOOLTOCHAR, to support runtime traceability.
- BR-002 - The Windows API layer must be available (Win_API.API_ENABLED) before any attempt is made to retrieve the Windows directory; if the API is unavailable, the function raises WIN_API.NOT_AVAILABLE and records the error via ADD_ERROR using the NoAPI message constant.
- BR-003 - The external Windows directory function is invoked through D2KWUTIL.D2KWUTIL_WINDIR after the function handle is resolved via REGISTER_FUNCTION_CALL; the output buffer must be initialised to 512 characters before the call and the same length value must be passed as the buffer-size argument.
- BR-004 - A return code of 0 from D2KWUTIL.D2KWUTIL_WINDIR is treated as a failure condition indicating no directory value was returned; this must be recorded as an error via ADD_ERROR with the message 'No Value Returned'.
- BR-005 - The caller controls failure-handling behaviour through the RaiseExceptions parameter: when TRUE, a missing result raises NO_DATA_FOUND; when FALSE, NULL is returned without raising an exception.
- BR-006 - The returned Windows directory path must have any trailing directory separator removed via STRIPDIRSEP before being passed back to the caller, ensuring a consistent path format.
- BR-007 - A second DEBUGLOG entry must be written after the external call returns, recording the return code and the buffer contents, to provide a complete diagnostic trail for the invocation.
- BR-008 - All exceptions (NO_DATA_FOUND, WIN_API.NOT_AVAILABLE, and unhandled others) are re-raised after error logging, ensuring that error state is propagated to the calling context.
- BR-009 - Unhandled exceptions are logged with both the internal UError message constant and any external error information obtained via ADD_EXTERNAL_ERRORS, providing a complete diagnostic record.

---
**Implementation Logic**

```plsql

FUNCTION Get_Windows_Directory (RaiseExceptions IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  iRC        PLS_INTEGER;
begin 
  Win_API_Debug.DebugLog(99,'Get_Windows_Directory','Args: RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	 	
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then 
    win_api.Register_function_call(iWinDir,'d2kwutil_WinDir','INT','*CHAR,INT');

    vcBuff1    := RPAD(' ',512,CHR(0));
    iRC   := d2kwutil_WinDir(win_api.FunctionHandle(iWinDir),vcBuff1,512);
    Win_API_Debug.DebugLog(99,'Get_Windows_Directory','Result:  RC='||to_char(iRC)||', vcBuff1="'||vcBuff1||'"');	      
  else
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0 then 
    Win_API.Add_error('Get_Windows_Directory','No Value Returned');
    if RaiseExceptions then
      raise NO_DATA_FOUND;
    else
      return NULL;
    end if;
  else
    return WIN_API.StripDirSep(vcBuff1);
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Windows_Directory',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Windows_Directory',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Windows_Directory;
```

#### SP-061 - REGISTER_FUNCTION_CALL

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Ensures that a Windows DLL function is fully registered with the Oracle FFI layer before it is invoked. The procedure first confirms the target DLL is loaded (attempting a reload via D2KWUTIL.ATTEMPT_DLL_LOAD if necessary), then checks whether the function has already been registered under the current DLL load cycle. When registration is required-either because it has never occurred or because the DLL has been reloaded since the last registration-the procedure registers the function handle, iterates through each argument type using D2KWUTIL.TRANSLATETYPE and WEBUTIL.LENGTH-assisted parsing, registers each parameter, and registers the return type if applicable. Diagnostic entries are written via DEBUGLOG. Errors encountered during FFI operations are surfaced through ADD_ERROR and ADD_EXTERNAL_ERRORS.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| FunctionID | PLS_INTEGER | IN |
| FunctionName | VARCHAR2 | IN |
| FunctionReturn | VARCHAR2 | IN |
| FunctionArgs | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-054](#SP-054--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-055](#SP-055--ADD_EXTERNAL_ERRORS)) - matched by member name
- D2KWUTIL.ATTEMPT_DLL_LOAD ([SP-008](#SP-008--D2KWUTIL.ATTEMPT_DLL_LOAD)) - D2KWUTIL.pck (or .pld)
- D2KWUTIL.TRANSLATETYPE ([SP-016](#SP-016--D2KWUTIL.TRANSLATETYPE)) - D2KWUTIL.pck (or .pld)
- DEBUGLOG ([SP-058](#SP-058--DEBUGLOG)) - matched by member name
- WEBUTIL.LENGTH ([SP-045](#SP-045--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)
- WEBUTIL.REGISTER_FUNCTION ([SP-048](#SP-048--WEBUTIL.REGISTER_FUNCTION)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Attempt to locate the DLL in the Oracle FFI layer by calling ORA_FFI.FIND_LIBRARY with DLL_NAME; store the resulting handle in DLL_HANDLE.
- Step 2 - If ORA_FFI.FIND_LIBRARY raises an FFI error, invoke D2KWUTIL.ATTEMPT_DLL_LOAD with DLL_Path and DLL_NAME to force a reload of the DLL and obtain a new DLL_HANDLE.
- Step 3 - If D2KWUTIL.ATTEMPT_DLL_LOAD also raises an FFI error, set API_ENABLED to FALSE, call ADD_ERROR to record that the DLL was not found, and raise NO_DATA_FOUND to abort further processing.
- Step 4 - Evaluate whether the function identified by FunctionID requires (re-)registration: check whether FunctionLoad does not contain an entry for FunctionID, or whether the stored load-count value for FunctionID differs from the current DLL_LOAD_COUNT.
- Step 5 - If registration is required, call ORA_FFI.REGISTER_FUNCTION with DLL_HANDLE, FunctionName, and the calling convention to obtain a function handle, and store it in FunctionHandle(FunctionID).
- Step 6 - If FunctionName is not the internal debug string function, call DEBUGLOG (via Win_API_Debug.DebugLog) to record whether this is an initial registration or a re-registration, including FunctionName and DLL_LOAD_COUNT.
- Step 7 - Append a comma delimiter to FunctionArgs and enter a loop to parse each comma-separated argument type fragment; for each fragment, call D2KWUTIL.TRANSLATETYPE to convert the type string to its FFI constant and pass the result to ORA_FFI.REGISTER_PARAMETER for FunctionHandle(FunctionID). Continue until the argument string is exhausted, is NULL, or equals 'VOID'.
- Step 8 - After parameter registration, if FunctionReturn is neither 'VOID' nor NULL, call D2KWUTIL.TRANSLATETYPE on FunctionReturn and pass the result to ORA_FFI.REGISTER_RETURN for FunctionHandle(FunctionID).
- Step 9 - Record the current DLL_LOAD_COUNT in FunctionLoad(FunctionID) to mark the function as registered under the current DLL load cycle, preventing unnecessary re-registration on subsequent calls.
- Step 10 - If Step 4 determined that the function was already registered under the current load cycle, skip Steps 5-9 and exit normally.
- Step 11 - If an FFI error is raised at any point during the registration process (Steps 5-9), call ADD_ERROR with FunctionName and the concatenation of UError and ADD_EXTERNAL_ERRORS to surface the error details, then raise NO_DATA_FOUND.

---
**Decision Points**

DP-001

Condition: ORA_FFI.FIND_LIBRARY raises ORA_FFI.FFI_ERROR.

TRUE: The DLL is not currently loaded; D2KWUTIL.ATTEMPT_DLL_LOAD is called to reload the DLL and obtain a new DLL_HANDLE.

FALSE: The DLL is already loaded; DLL_HANDLE is set from FIND_LIBRARY and processing continues to the registration check.

---

DP-002

Condition: D2KWUTIL.ATTEMPT_DLL_LOAD raises ORA_FFI.FFI_ERROR.

TRUE: The DLL cannot be loaded; API_ENABLED is set to FALSE, ADD_ERROR is called to log the failure, and NO_DATA_FOUND is raised to abort processing.

FALSE: The DLL reload succeeded; DLL_HANDLE is updated and processing continues to the registration check.

---

DP-003

Condition: FunctionLoad does not contain an entry for FunctionID (NOT FunctionLoad.EXISTS(FunctionID)) OR the stored load-count for FunctionID does not equal the current DLL_LOAD_COUNT.

TRUE: The function requires registration or re-registration; Steps 5-9 are executed to register the handle, parameters, and return type, and FunctionLoad(FunctionID) is updated.

FALSE: The function is already registered under the current DLL load cycle; no FFI registration calls are made and the procedure exits normally.

---

DP-004

Condition: FunctionName equals 'd2kwutil_DebugString'.

TRUE: DEBUGLOG is not called, suppressing diagnostic logging for the internal debug function to avoid recursion.

FALSE: DEBUGLOG is called to record initial registration or re-registration details including FunctionName and DLL_LOAD_COUNT.

---

DP-005

Condition: NOT FunctionLoad.EXISTS(FunctionID) (evaluated inside the DEBUGLOG branch).

TRUE: This is the first-time registration; DEBUGLOG records an 'Initial Reg' message.

FALSE: This is a re-registration; DEBUGLOG records a 'Re-Registration Count' message including the previously stored load-count value.

---

DP-006

Condition: The remaining FunctionArgs string is NOT NULL, is not equal to ',', and is not equal to 'VOID,'.

TRUE: A parameter type fragment remains to be processed; the fragment is extracted, D2KWUTIL.TRANSLATETYPE is called, and ORA_FFI.REGISTER_PARAMETER is invoked before the loop advances.

FALSE: All parameter type fragments have been processed; the loop exits.

---

DP-007

Condition: UPPER(FunctionReturn) <> 'VOID' AND FunctionReturn IS NOT NULL.

TRUE: The function has a non-void return type; D2KWUTIL.TRANSLATETYPE is called on FunctionReturn and the result is passed to ORA_FFI.REGISTER_RETURN.

FALSE: The function is void or the return type is unspecified; no return-type registration is performed.

---

DP-008

Condition: An ORA_FFI.FFI_ERROR is raised during the registration block (Steps 5-9).

TRUE: ADD_ERROR is called with FunctionName and the error detail string formed by concatenating UError and ADD_EXTERNAL_ERRORS, then NO_DATA_FOUND is raised.

FALSE: No FFI error occurred; the procedure completes normally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The DLL must be locatable via ORA_FFI.FIND_LIBRARY before any function registration is attempted; if it is not found, D2KWUTIL.ATTEMPT_DLL_LOAD must succeed before processing can continue.
- BR-002 - If the DLL cannot be loaded by either mechanism, API_ENABLED is set to FALSE and an error is recorded via ADD_ERROR before the procedure aborts with NO_DATA_FOUND; no partial registration is permitted.
- BR-003 - A function is registered or re-registered only when its FunctionID is absent from the FunctionLoad cache or when the cached load-count differs from the current DLL_LOAD_COUNT, ensuring that stale registrations from a previous DLL load cycle are always refreshed.
- BR-004 - Function handle registration is performed via ORA_FFI.REGISTER_FUNCTION using the current DLL_HANDLE, the caller-supplied FunctionName, and the C_STD calling convention.
- BR-005 - Each argument type in FunctionArgs is translated to its FFI constant by D2KWUTIL.TRANSLATETYPE before being passed to ORA_FFI.REGISTER_PARAMETER; the argument string is parsed sequentially using comma delimiters and processing stops when the string is exhausted, NULL, or equals 'VOID'.
- BR-006 - Return-type registration via ORA_FFI.REGISTER_RETURN is performed only when FunctionReturn is neither 'VOID' (case-insensitive) nor NULL; the type is translated by D2KWUTIL.TRANSLATETYPE before registration.
- BR-007 - Upon successful registration, FunctionLoad(FunctionID) is set to the current DLL_LOAD_COUNT, preventing redundant re-registration on subsequent calls within the same DLL load cycle.
- BR-008 - Diagnostic logging via DEBUGLOG is written for every registration or re-registration event, recording FunctionName, DLL_LOAD_COUNT, and whether the event is an initial registration or a re-registration; logging is suppressed specifically for the 'd2kwutil_DebugString' function to prevent recursive log calls.
- BR-009 - FFI errors raised during the registration block are handled by calling ADD_ERROR with FunctionName and the combined error detail from ADD_EXTERNAL_ERRORS, after which NO_DATA_FOUND is raised to signal failure to the caller.

---
**Implementation Logic**

```plsql

PROCEDURE Register_Function_Call ( FunctionID     in PLS_INTEGER, 
                                   FunctionName   in VARCHAR2,
                                   FunctionReturn in VARCHAR2, 
                                   FunctionArgs   in VARCHAR2) is
  vcArgs  VARCHAR2(200);
  vcFrag  VARCHAR2(10);
  iOffset PLS_INTEGER;   
begin 
   -- See if the DLL has been loaded at all.
   -- if this call to FIND_LIBRARY fails, we'll fall through to the Exception.
   begin
    DLL_HANDLE := ORA_FFI.find_library(DLL_NAME);
  exception
    when ora_ffi.ffi_error then 
      -- Attempt to load the DLL again in a subblock. If this fails
      -- then the API must be disabled and NOT_DATA_FOUND raised
      begin 
          DLL_HANDLE := Attempt_DLL_Load(DLL_Path, DLL_NAME);
      exception
          when ora_ffi.ffi_error then 
            API_ENABLED := FALSE;
              add_error('D2KWUTIL',DLL_NAME||' not found.');
            RAISE NO_DATA_FOUND;
      end;
  end;

  -- now compare the Cached value for this function's loadcount with 
  -- that for the DLL this tells us that the function has either not 
  -- been registered yet, or that the DLL has been reloaded in between 
  -- times.  This would not be healthy so we have to re-register in that case.
  if (not FunctionLoad.exists(FunctionId)) or (FunctionLoad(FunctionId)<> DLL_LOAD_COUNT) then
    -- We need to go through the registration process.      
    -- Register the function with the DLL
    FunctionHandle(FunctionId) := ora_ffi.register_function(Win_API.DLL_HANDLE,FunctionName,ORA_FFI.C_STD);
    if FunctionName <> 'd2kwutil_DebugString' then 
    	if not FunctionLoad.exists(FunctionId) then 
    		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Initial Reg');
    	else
       		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Re-Registration Count = '||to_char(FunctionLoad(FunctionId)));
       	end if;
    end if;
    
    -- Loop through and register the parameters
    vcArgs := FunctionArgs||',';
    while vcArgs is not null and vcArgs <> ',' and vcArgs <> 'VOID,' LOOP
      iOffset := instr(vcArgs,',');
      vcFrag := substr(vcArgs,1,iOffset-1);
      ora_ffi.register_parameter(FunctionHandle(FunctionId),TranslateType(vcFrag));
      if iOffset = length(vcArgs) then
        vcArgs := NULL;
      else
        vcArgs := substr(vcArgs,iOffset+1);
      end if;
    end LOOP;
    
    -- Register the return type IF this is a function
    if upper(FunctionReturn) <> 'VOID' and FunctionReturn is not NULL then 
      ora_ffi.register_return(FunctionHandle(FunctionId),TranslateType(FunctionReturn));
    end if;
    
    -- Now add this Function's Loadcount to the array to prevent un-nessary re-registration
    FunctionLoad(FunctionId) := DLL_LOAD_COUNT;
  end if;
exception
   when ora_ffi.ffi_error then
    Win_API.Add_error(FunctionName, Win_API.UError||WIN_API.Add_External_errors); 
    raise NO_DATA_FOUND;
end Register_Function_Call;
```

#### SP-062 - RUN_REPORT

**Invoked From:**

- pt_phy_fmb.xml [ProgramUnit: PRINT_AS]

---

**Screen:**

N/A

---

**Purpose**

Executes an Oracle Reports object with caller-supplied destination and parameter settings, then either opens the generated report in a browser window or notifies the user that the output has been spooled to a file. The procedure also handles unexpected runtime errors by displaying the error message and halting form processing.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_report_name | varchar2 | IN |
| p_dest_type | varchar2 | IN |
| p_dest_name | varchar | IN |
| P_parameter | varchar2 | IN |
| p_report_server | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-021](#SP-021--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Locate the report object in the current Forms session using the supplied report name (p_report_name) via FIND_REPORT_OBJECT.
- Step 2 - Set the report module property on the located report object to the report name.
- Step 3 - Assign the target report server (p_report_server) to the report object.
- Step 4 - Configure the destination type and format based on p_dest_type: for CACHE or SCREEN, set destination type to CACHE and format to HTML; for FILE, default the destination name to the report name if p_dest_name is null, then set destination type to FILE, format to PDF, and destination name accordingly; for PRINTER, set destination type to PRINTER only.
- Step 5 - Apply the caller-supplied parameter string (p_parameter) to the report object's REPORT_OTHER property.
- Step 6 - Submit the report for execution via RUN_REPORT_OBJECT and capture the job handle (v_rep).
- Step 7 - Retrieve the execution status of the submitted job via REPORT_OBJECT_STATUS.
- Step 8 - Call SYNCHRONIZE to align the Forms display with the current state.
- Step 9 - For destination types CACHE, SCREEN, or PRINTER, construct a URL using the job ID extracted from v_rep and the report server name, then open it in a new browser window via WEB.SHOW_DOCUMENT.
- Step 10 - For destination type FILE, call GENERAL.DISP_TEXT (SP-021) to display a success message confirming the report has been spooled to the specified file.
- Step 11 - In the event of any unhandled exception, call GENERAL.DISP_TEXT (SP-021) to display the Oracle error message (SQLERRM) with severity 'Error', then raise FORM_TRIGGER_FAILURE to halt further form processing.

---
**Decision Points**

DP-001

Condition:
p_dest_type is 'CACHE' or 'SCREEN'

TRUE:
Set report destination type to CACHE and output format to HTML.

FALSE:
Evaluate subsequent destination type conditions (DP-002, DP-003).

---

DP-002

Condition:
p_dest_type is 'FILE'

TRUE:
Check whether lv_dest_name is null (DP-004), set destination type to FILE, format to PDF, and assign the destination name.

FALSE:
Evaluate the PRINTER condition (DP-003).

---

DP-003

Condition:
p_dest_type is 'PRINTER'

TRUE:
Set report destination type to PRINTER (no format or destination name is set).

FALSE:
No destination-type property is configured; execution continues to parameter assignment and report submission.

---

DP-004

Condition:
lv_dest_name (derived from p_dest_name) is null, evaluated only when p_dest_type is 'FILE'

TRUE:
Default lv_dest_name to the value of p_report_name before setting the file destination name property.

FALSE:
Use the originally supplied p_dest_name as the file destination name.

---

DP-005

Condition:
After report submission, p_dest_type is 'CACHE', 'SCREEN', or 'PRINTER'

TRUE:
Construct the report viewer URL from the job ID and report server name, then open it in a new browser window via WEB.SHOW_DOCUMENT.

FALSE:
p_dest_type is 'FILE'; call GENERAL.DISP_TEXT (SP-021) to display a success notification confirming the report was spooled to the named file.

---

DP-006

Condition:
An unhandled exception occurs at any point within the procedure

TRUE:
Call GENERAL.DISP_TEXT (SP-021) with SQLERRM and severity 'Error', then raise FORM_TRIGGER_FAILURE to abort the triggering form action.

FALSE:
Procedure completes normally without exception handling intervention.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The report object identified by p_report_name must already exist within the current Oracle Forms session; the procedure does not create report objects dynamically.
- BR-002 - When p_dest_type is 'CACHE' or 'SCREEN', the report is always rendered in HTML format and routed through the CACHE destination type regardless of which of the two values is supplied.
- BR-003 - When p_dest_type is 'FILE', the output format is always PDF; no other format is permitted for file-based output.
- BR-004 - When p_dest_type is 'FILE' and no destination name is provided (p_dest_name is null), the report name (p_report_name) is used as the file destination name, ensuring a non-null destination is always set before the report runs.
- BR-005 - The caller-supplied parameter string (p_parameter) is applied to the REPORT_OTHER property after all destination properties are set, ensuring it is not overwritten by earlier property assignments.
- BR-006 - For CACHE, SCREEN, and PRINTER destination types, the generated report is surfaced to the end user by opening the Oracle Reports servlet URL (constructed from the job ID and server name) in a new browser window.
- BR-007 - For FILE destination type, no browser window is opened; instead, a textual success notification is displayed to the user via GENERAL.DISP_TEXT (SP-021).
- BR-008 - Any runtime exception causes an error message (SQLERRM) to be displayed to the user via GENERAL.DISP_TEXT (SP-021) and unconditionally raises FORM_TRIGGER_FAILURE, preventing the calling form trigger from continuing execution.

---
**Implementation Logic**

```plsql

PROCEDURE run_report(p_report_name in varchar2, 
										 p_dest_type in varchar2,
										 p_dest_name in varchar,
										 P_parameter  in varchar2,
										 p_report_server in varchar2) IS
	repid  report_object;
	v_rep varchar2(100);
	rep_status varchar2(20);
	v_str varchar2(500);
	lv_dest_name varchar2(50) := p_dest_name;
BEGIN
	repid := find_report_object(p_report_name);
	set_report_object_property(repid, REPORT_OTHER,'module='||p_report_name); 
	set_report_object_property(repid,REPORT_SERVER,p_report_server);
	if p_dest_type IN ('CACHE','SCREEN') then
		set_report_object_property(repid, report_destype, CACHE);
		set_report_object_property(repid, report_desformat, 'HTML');	 	   
	elsif p_dest_type = 'FILE' then
		If lv_dest_name is null then
			lv_dest_name := p_report_name;
		end if;
		set_report_object_property(repid, report_destype, FILE);
		set_report_object_property(repid, report_desformat, 'PDF');	 	   
		set_report_object_property(repid, report_desname, lv_dest_name);
	elsif p_dest_type = 'PRINTER' then
		set_report_object_property(repid, report_destype, PRINTER);
	end if;
	set_report_object_property(repid, REPORT_OTHER,p_parameter); 
	v_rep := run_report_object(repid);
	rep_status := report_object_status(v_rep);
	synchronize;
	IF P_DEST_TYPE IN ('CACHE','SCREEN','PRINTER') THEN
		web.show_document('/reports/rwservlet/getjobid'||substr(v_rep,instr(v_rep,'_',-1)+1)||'?'||'server='||p_report_server,'_blank');
	elsif P_DEST_TYPE IN ('FILE') THEN
		general.disp_text('Report has been spooled to file '||p_dest_name||' successfully','Note');
	End if;
	Exception
		When Others then
			General.disp_text(SQLERRM,'Error');
			Raise form_trigger_failure;
END;
```

#### SP-063 - SETDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Configures the debug logging environment by setting the debug output type (file, screen, or off), the target log file name, the logging verbosity level, and whether log entries should include a timestamp. Once configured, the procedure activates or deactivates the logging state and records an initial diagnostic entry via DEBUGLOG to confirm the new configuration.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugType | PLS_INTEGER | IN |
| DebugFile | VARCHAR2 | IN |
| DebugLevel | PLS_INTEGER | IN |
| TimeStamp | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-058](#SP-058--DEBUGLOG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Accept the four input parameters: DebugType (output destination selector), DebugFile (target file name, defaults to NULL), DebugLevel (verbosity threshold, defaults to 98), and TimeStamp (flag for timestamp inclusion, defaults to FALSE).
- Step 2 - Persist the TimeStamp flag to the package-level variable bDebugTimeStamp, making it available to subsequent logging calls.
- Step 3 - Persist the DebugFile value to the package-level variable vcDebugFile, identifying the target output file for file-based logging.
- Step 4 - Persist the DebugLevel value to the package-level variable iDebugLevel, controlling the verbosity threshold for all subsequent log entries.
- Step 5 - Evaluate DebugType to determine the logging mode: if DebugType = 1, set iDebugState to 1 (file logging) and call DEBUGLOG to record 'Logging to File' concatenated with the DebugFile name; if DebugType = 2, set iDebugState to 2 (screen/alternative logging) and call DEBUGLOG to record 'Logging Started'; otherwise, call DEBUGLOG to record 'Logging Stopped' and set iDebugState to 0 (logging disabled).
- Step 6 - Return control to the caller with the debug environment fully configured.

---
**Decision Points**

DP-001

Condition: DebugType = 1

TRUE: Set iDebugState to 1 (file-based logging mode) and invoke DEBUGLOG with message 'Logging to File ' || DebugFile to confirm file logging is active.

FALSE: Proceed to evaluate DebugType = 2 (DP-002).

---

DP-002

Condition: DebugType = 2

TRUE: Set iDebugState to 2 (screen/alternative logging mode) and invoke DEBUGLOG with message 'Logging Started' to confirm this mode is active.

FALSE: Invoke DEBUGLOG with message 'Logging Stopped' and set iDebugState to 0, disabling all subsequent debug logging.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - DebugType = 1 designates file-based logging; DebugFile must carry a meaningful file path value in this mode, as it is both stored and appended to the confirmation log message.
- BR-002 - DebugType = 2 designates screen (or alternative output) logging; DebugFile is stored but not referenced in the confirmation message for this mode.
- BR-003 - Any DebugType value other than 1 or 2 is treated as a request to stop logging; iDebugState is set to 0 and a 'Logging Stopped' entry is written before logging is disabled.
- BR-004 - The verbosity threshold (DebugLevel) defaults to 98 if not supplied, ensuring broad capture of log events unless the caller explicitly restricts it.
- BR-005 - The TimeStamp flag defaults to FALSE; callers must explicitly pass TRUE to enable timestamp decoration on log entries.
- BR-006 - DEBUGLOG is always invoked once during SETDEBUG execution, regardless of the selected mode, providing an audit trail of every debug configuration change.

---
**Implementation Logic**

```plsql

PROCEDURE SetDebug( DebugType   IN PLS_INTEGER, 
                    DebugFile   IN VARCHAR2 DEFAULT NULL, 
                    DebugLevel  IN PLS_INTEGER DEFAULT 98,                        
                    TimeStamp   IN BOOLEAN DEFAULT FALSE) is
begin 
    bDebugTimeStamp := TimeStamp;
    vcDebugFile     := DebugFile;
    iDebugLevel     := DebugLevel;
	if DebugType = 1 then 
		iDebugState := 1;
		DebugLog(0,'SetDebug','Logging to File '||DebugFile);
	elsif DebugType = 2 then
		iDebugState := 2;
		DebugLog(0,'SetDebug','Logging Started');
	else 
        DebugLog(0,'SetDebug','Logging Stopped');
        iDebugState := 0;
	end if;
end SetDebug;
```

#### SP-064 - SF_COPYRIGHT_DECLARATION

**Invoked From:**

- pt_phy_fmb.xml [Trigger: KEY-CLRFRM]
- pt_phy_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

ADJUSTMENT DETAILS (N/A / CN_ADJ); COUNT DETAILS (N/A / CN_MAIN)

---

**Purpose**

Returns a formatted copyright string displaying the current financial year and the company name 'Maruti Suzuki India Limited'. Because the Indian financial year runs April-March, the function adjusts the displayed year so that months January, February, and March show the previous calendar year as the copyright year, ensuring the copyright notice always reflects the correct financial year. The result is used in the ADJUSTMENT DETAILS and COUNT DETAILS screens, populated on form initialisation and form-clear events.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Capture the current system date using SYSDATE into a local date variable.
- Step 2 - Extract the abbreviated month name from the current date and check whether it falls in January, February, or March (the tail end of the Indian financial year).
- Step 3 - If the current month IS January, February, or March, derive the copyright year by subtracting 1 from the current calendar year (e.g., during March 2011 the copyright year displayed is 2010).
- Step 4 - If the current month is NOT January, February, or March (i.e., April through December), use the current calendar year as the copyright year.
- Step 5 - Construct the copyright string in the format '- <YYYY> Maruti Suzuki India Limited ' and return it to the caller.

---
**Decision Points**

DP-001

Condition:
The abbreviated month of the current system date (SYSDATE) is one of 'JAN', 'FEB', or 'MAR'.

TRUE:
The copyright year is set to the current calendar year minus 1, reflecting that these months belong to the previous financial year (e.g., February 2012 -> copyright year 2011).

FALSE:
The copyright year is set to the current calendar year, as the month falls within April-December of the same financial year.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The Indian financial year is treated as running from April to March; therefore months January, February, and March are considered part of the financial year that started in the previous calendar year.
- BR-002 - The copyright year displayed must always correspond to the start year of the current financial year, not necessarily the current calendar year.
- BR-003 - The copyright notice must always attribute ownership to 'Maruti Suzuki India Limited'.
- BR-004 - The returned string must follow the exact format '- <YYYY> Maruti Suzuki India Limited ' (leading dash, four-digit year, company name, trailing space) to ensure consistent display across all consuming screens.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
function sf_copyright_declaration return varchar is
a varchar2(50);
dt date;
begin
--Modified by Prerna on 16-May-11  to display current Financial Year Copyright
dt := sysdate;

    if( to_char(dt,'MON') in ('JAN','FEB','MAR')) then
        a := '- '||to_char(to_number(to_char(dt,'RRRR')) - 1)||' Maruti Suzuki India Limited ';
    else
        a := '- '||to_char(dt,'RRRR')||' Maruti Suzuki India Limited ';
    end if;
return(a);
end;

```

#### SP-065 - SF_GET_ALLOW_DECIMAL

**Invoked From:**

- pt_phy_fmb.xml [Trigger: POST-QUERY]
- pt_phy_fmb.xml [Trigger: WBP]
- pt_phy_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

COUNT DETAILS (N/A / CN_MAIN); PART DETAILS (N/A / CN_MAIN)

---

**Purpose**

Determines whether a given part number permits decimal quantities by querying the PM_PART table for the matching principal and dealer mapping. Returns the allow-decimal flag ('Y' or 'N') to the calling trigger in pt_phy_fmb so that downstream validation and display logic can enforce or permit fractional quantity entry for the part.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_principal | NUMBER | IN |
| p_dealer | NUMBER | IN |
| p_part_num | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept three input parameters: p_principal (principal company identifier), p_dealer (dealer identifier), and p_part_num (part number to evaluate).
- Step 2 - Query PM_PART for the row where part_num matches p_part_num, dealer_map_cd is either the principal or the dealer value, and principal_map_cd equals p_principal (multi-company filter).
- Step 3 - Apply NVL to the retrieved allow_decimal_qty column value; if the column is NULL, default to 'N' (decimal quantities not permitted).
- Step 4 - Assign the resolved value to the local variable lv_allow_decimal.
- Step 5 - Return lv_allow_decimal to the caller.
- Step 6 - If any exception is raised (NO_DATA_FOUND, TOO_MANY_ROWS, VALUE_ERROR, or any other unhandled error), return 'E' to signal that the flag could not be determined.

---
**Decision Points**

DP-001

Condition:
The SELECT against PM_PART returns exactly one row for the given p_part_num, dealer_map_cd IN (p_principal, p_dealer), and principal_map_cd = p_principal.

TRUE:
The allow_decimal_qty value (defaulted to 'N' via NVL if NULL) is returned to the caller.

FALSE:
An exception is raised (NO_DATA_FOUND or TOO_MANY_ROWS); the function returns 'E'.

---

DP-002

Condition:
The retrieved allow_decimal_qty column value is NULL.

TRUE:
NVL substitutes 'N', indicating decimal quantities are not permitted for the part.

FALSE:
The stored allow_decimal_qty value ('Y' or 'N') is used as-is.

---

DP-003

Condition:
A VALUE_ERROR or any other unhandled exception occurs during execution.

TRUE:
The function returns 'E' to signal an indeterminate result to the caller.

FALSE:
Normal processing continues and the resolved flag is returned.

---
**Database Interactions**

- DB-001 - Read PM_PART - Reads data from PM_PART for lookup or validation.
**Business Rules**

- BR-001 - The allow-decimal flag must be resolved per part number within the context of a specific principal and dealer combination; cross-company part records are scoped by both dealer_map_cd (matched against either the principal or dealer identifier) and principal_map_cd (matched exclusively to the principal).
- BR-002 - If the allow_decimal_qty attribute is not populated for a part in PM_PART, the system defaults to 'N', meaning decimal quantities are not permitted unless explicitly enabled.
- BR-003 - A return value of 'E' indicates that the flag could not be reliably determined (part not found, ambiguous records, or a data/runtime error); calling triggers must treat 'E' as an error condition and handle it accordingly.
- BR-004 - Exactly one PM_PART row must match the supplied part number and principal/dealer mapping; the presence of multiple matching rows is treated as a data integrity error and results in 'E' being returned.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
FUNCTION sf_get_allow_decimal(p_principal IN NUMBER,
                                                p_dealer    IN NUMBER,
                                                p_part_num  IN VARCHAR2)
  RETURN VARCHAR2 IS
  lv_allow_decimal pm_part.allow_decimal_qty%TYPE;
BEGIN
  SELECT NVL(allow_decimal_qty, 'N')
    INTO lv_allow_decimal
    FROM pm_part
   WHERE part_num = p_part_num
     AND dealer_map_cd IN (p_principal, p_dealer)
     AND principal_map_cd = p_principal; --Added by Rajeev for multi company changes
  RETURN lv_allow_decimal;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RETURN 'E';
  WHEN TOO_MANY_ROWS THEN
    RETURN 'E';
  WHEN VALUE_ERROR THEN
    RETURN 'E';
  WHEN OTHERS THEN
    RETURN 'E';
END;

```

#### SP-066 - SF_GET_BIN_FLAG

**Invoked From:**

- pt_phy_fmb.xml [Trigger: KEY-CLRFRM]
- pt_phy_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

ADJUSTMENT DETAILS (N/A / CN_ADJ); COUNT DETAILS (N/A / CN_MAIN)

---

**Purpose**

Retrieves the bin-wise stock indicator ('Y' or 'N') for a specific dealer location from the AM_DEALER_LOC_PARAM table. The function is used during form initialisation and form-clear events on the Adjustment Details and Count Details screens to determine whether bin-level stock tracking is active for the given parent group, dealer, and location combination.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| pi_parent | VARCHAR2 | IN |
| pi_dealer | NUMBER | IN |
| pi_loc_cd | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept three input parameters: parent group code (pi_parent), dealer mapping code (pi_dealer), and location code (pi_loc_cd).
- Step 2 - Query AM_DEALER_LOC_PARAM for the bin_wise_stock_yn value where parent_group, dealer_map_cd, and loc_cd match the supplied inputs.
- Step 3 - Apply NVL to the retrieved bin_wise_stock_yn value, defaulting it to 'N' if the column is NULL.
- Step 4 - Return the resolved bin flag value ('Y' or 'N') to the calling trigger.
- Step 5 - If no matching row is found (NO_DATA_FOUND) or any other exception occurs, default lv_bin_flag to 'N' and return it, ensuring the calling context always receives a safe, non-null result.

---
**Decision Points**

DP-001

Condition:
A row exists in AM_DEALER_LOC_PARAM matching the supplied pi_parent, pi_dealer, and pi_loc_cd values.

TRUE:
The bin_wise_stock_yn column value is retrieved; NVL converts any NULL to 'N', and the result is returned to the caller.

FALSE:
NO_DATA_FOUND exception is raised; lv_bin_flag is set to 'N' and returned.

DP-002

Condition:
The retrieved bin_wise_stock_yn value is non-NULL.

TRUE:
The actual column value (expected 'Y' or 'N') is returned as the bin flag.

FALSE:
NVL substitutes 'N' as the default bin flag value before returning.

DP-003

Condition:
An unexpected runtime exception (WHEN OTHERS) occurs during execution.

TRUE:
lv_bin_flag is set to 'N' and returned, preventing unhandled errors from propagating to the calling trigger.

FALSE:
Normal processing continues and the resolved bin flag is returned.

---
**Database Interactions**

- DB-001 - Read AM_DEALER_LOC_PARAM - Reads data from AM_DEALER_LOC_PARAM for lookup or validation.
**Business Rules**

- BR-001 - The bin-wise stock flag must always resolve to a non-null value; 'N' (bin tracking disabled) is the universal default when no configuration record exists or the stored value is NULL.
- BR-002 - A dealer location is uniquely identified by the combination of parent_group, dealer_map_cd, and loc_cd; all three parameters are mandatory for a valid lookup against AM_DEALER_LOC_PARAM.
- BR-003 - Any exception during the lookup, whether a missing configuration record or an unexpected database error, is silently handled by returning 'N', ensuring the calling form triggers on the Adjustment Details and Count Details screens are never interrupted by this function.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
FUNCTION Sf_Get_Bin_Flag (pi_parent VARCHAR2, pi_dealer NUMBER, pi_loc_cd VARCHAR2)
      RETURN VARCHAR2
IS
      lv_bin_flag   AM_DEALER_LOC_PARAM.bin_wise_stock_yn%TYPE;
BEGIN
      SELECT NVL ( bin_wise_stock_yn, 'N')
        INTO lv_bin_flag
        FROM AM_DEALER_LOC_PARAM
       WHERE parent_group = pi_parent AND dealer_map_cd = pi_dealer AND loc_cd = pi_loc_cd;

      RETURN lv_bin_flag;
EXCEPTION
      WHEN NO_DATA_FOUND THEN
            lv_bin_flag := 'N';
            RETURN lv_bin_flag;
      WHEN OTHERS THEN
            lv_bin_flag := 'N';
            RETURN lv_bin_flag;
END;

```

#### SP-067 - SF_GET_DEFAULT_STORE_BIN

**Invoked From:**

- pt_phy_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

PART DETAILS (N/A / CN_MAIN)

---

**Purpose**

Retrieves the default bin location for a specific part within a store, given a combination of parent group, dealer, location, company fixed asset, stores code, and part number. The function is called during item validation on the PART DETAILS screen to pre-populate or confirm the bin location field with the designated default bin for the matched stock record.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| pi_parent | VARCHAR2 | IN |
| pi_dealer | NUMBER | IN |
| pi_loc | VARCHAR2 | IN |
| pi_comp_fa | VARCHAR2 | IN |
| pi_stores_cd | VARCHAR2 | IN |
| pi_part_num | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept six input parameters: parent group (pi_parent), dealer map code (pi_dealer), location code (pi_loc), company fixed asset (pi_comp_fa), stores code (pi_stores_cd), and part number (pi_part_num).
- Step 2 - Query the PM_STOCK_BIN_LOC table for a row that matches all six input parameters and has the DEFAULT_YN flag set to 'Y'.
- Step 3 - If exactly one matching record is found, capture the BIN_LOC value into the local variable lv_bin_loc.
- Step 4 - If no matching record exists (NO_DATA_FOUND), a VALUE_ERROR occurs, or any other exception is raised, set lv_bin_loc to NULL.
- Step 5 - Return lv_bin_loc to the calling trigger, supplying either the resolved default bin location or NULL if none could be determined.

---
**Decision Points**

DP-001

Condition:
A row exists in PM_STOCK_BIN_LOC where parent_group = pi_parent, dealer_map_cd = pi_dealer, loc_cd = pi_loc, comp_fa = pi_comp_fa, stores_cd = pi_stores_cd, part_num = pi_part_num, AND default_yn = 'Y'.

TRUE:
The bin_loc value from the matching record is assigned to lv_bin_loc and returned to the caller.

FALSE:
A NO_DATA_FOUND exception is raised; lv_bin_loc is set to NULL and NULL is returned to the caller.

DP-002

Condition:
A VALUE_ERROR or any other unexpected exception is raised during the SELECT operation.

TRUE:
lv_bin_loc is set to NULL and NULL is returned to the caller, ensuring the function does not propagate an unhandled exception.

FALSE:
Normal processing continues and the resolved bin location is returned.

---
**Database Interactions**

- DB-001 - Read PM_STOCK_BIN_LOC - Reads data from PM_STOCK_BIN_LOC for lookup or validation.
**Business Rules**

- BR-001 - A bin location is considered the default only when the DEFAULT_YN column in PM_STOCK_BIN_LOC is explicitly set to 'Y'; records with any other value are excluded from the lookup.
- BR-002 - The default bin lookup must match all six key attributes simultaneously (parent group, dealer map code, location code, company fixed asset, stores code, and part number); a partial match is not sufficient.
- BR-003 - If no default bin location can be resolved for the given combination of inputs, the function returns NULL rather than raising an error, allowing the calling screen trigger to handle the absence of a default bin gracefully.
- BR-004 - Any exception encountered during the database lookup (including NO_DATA_FOUND, VALUE_ERROR, or unforeseen runtime errors) is silently handled by returning NULL, ensuring the function never propagates an exception to the invoking WHEN-VALIDATE-ITEM trigger.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
FUNCTION Sf_Get_Default_Store_Bin (
      pi_parent      VARCHAR2,
      pi_dealer      NUMBER,
      pi_loc         VARCHAR2,
      pi_comp_fa     VARCHAR2,
      pi_stores_cd   VARCHAR2,
      pi_part_num    VARCHAR2
)
      RETURN VARCHAR2
IS
      lv_bin_loc   PM_STOCK_BIN_LOC.bin_loc%TYPE;
BEGIN
      BEGIN
            SELECT bin_loc
              INTO lv_bin_loc
              FROM PM_STOCK_BIN_LOC
             WHERE parent_group = pi_parent
               AND dealer_map_cd = pi_dealer
               AND loc_cd = pi_loc
               AND comp_fa = pi_comp_fa
               AND stores_cd = pi_stores_cd
               AND part_num = pi_part_num
               AND default_yn='Y';
      EXCEPTION
            WHEN NO_DATA_FOUND THEN
                  lv_bin_loc := NULL;
            WHEN VALUE_ERROR THEN
                  lv_bin_loc := NULL;
            WHEN OTHERS THEN
                  lv_bin_loc := NULL;
      END;

      RETURN lv_bin_loc;
END;

```

#### SP-068 - SF_GET_PRICE

**Invoked From:**

- pt_phy_fmb.xml [Trigger: POST-QUERY]

---

**Screen:**

PART DETAILS (N/A / CN_MAIN)

---

**Purpose**

SF_GET_PRICE is a scalar function invoked during the POST-QUERY trigger on the Part Details screen. It returns the appropriate unit price for a given part by resolving the correct price field based on the supplied price-type code. The function first attempts to read the price from the part variant table (PM_PART_VAR) or, for sell-price types, delegates to SP_GET_PART_SELL_PRICE_ONE; if no variant-level record is found it falls back to the master part table (PM_PART). All exceptions are handled gracefully, returning zero rather than propagating an error to the calling form.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_parent_group | pm_part_var.parent_group%TYPE | IN |
| p_dealer_map_cd | pm_part_var.dealer_map_cd%TYPE | IN |
| p_loc_cd | pm_part_var.loc_cd%TYPE | IN |
| p_principal | pm_part_var.dealer_map_cd%TYPE | IN |
| p_price_type | VARCHAR2 | IN |
| p_part_num | pm_part_var.part_num%TYPE | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- SP_GET_PART_SELL_PRICE_ONE ([SP-073](#SP-073--SP_GET_PART_SELL_PRICE_ONE)) - standalone source file

---

**Step-by-Step Business Logic**

- Step 1 - Receive six input parameters: parent group, dealer map code, location code, principal, price type, and part number. Initialise the return variable v_price to 0.
- Step 2 - Convert p_price_type to upper case and evaluate it against the supported price-type codes (NA, P, O, L, M, LC).
- Step 3 - If price type is 'NA', query PM_PART for the sell_price where the dealer_map_cd matches either p_dealer_map_cd or p_principal, the part number matches, and the principal_map_cd equals p_principal.
- Step 4 - If price type is 'P', query PM_PART_VAR for the purchase_price (NVL to 0) filtered by parent_group, dealer_map_cd, loc_cd, and part_num.
- Step 5 - If price type is 'O' or 'L', first retrieve the GST state code (lv_gst_state_cd) by joining AM_DEALER_LOC and GM_STATE on the dealer location and state attributes. Then call SP_GET_PART_SELL_PRICE_ONE, passing principal, parent group, dealer map code, location code, part number, price-type flag 'O', and the resolved GST state code; the procedure populates v_price with the calculated sell price. Any exception within this block sets v_price to 0.
- Step 6 - If price type is 'M', query PM_PART_VAR for mrp_1 (NVL to 0) using the standard variant key.
- Step 7 - If price type is 'LC', query PM_PART_VAR for landed_cost (NVL to 0) using the standard variant key.
- Step 8 - Return v_price to the caller.
- Step 9 - If a NO_DATA_FOUND exception is raised during the primary query (Steps 3-7), execute a fallback query against PM_PART: for price type 'P' retrieve purchase_price; for 'L' or 'O' retrieve sell_price; for 'M' retrieve mrp_1; all filtered by part_num, dealer_map_cd IN (p_principal, p_dealer_map_cd), and principal_map_cd = p_principal. Return the fallback value.
- Step 10 - If the fallback query also raises NO_DATA_FOUND, TOO_MANY_ROWS, or any other exception, set v_price to 0 and return it. TOO_MANY_ROWS and OTHERS at the outer level likewise return 0.

---
**Decision Points**

DP-001

Condition:
UPPER(p_price_type) = 'NA'

TRUE:
Query PM_PART for sell_price using dealer_map_cd IN (p_dealer_map_cd, p_principal) and principal_map_cd = p_principal; return the result.

FALSE:
Proceed to evaluate the remaining price-type codes (P, O, L, M, LC).

---

DP-002

Condition:
UPPER(p_price_type) = 'P'

TRUE:
Query PM_PART_VAR for purchase_price (NVL to 0) using the full variant key (parent_group, dealer_map_cd, loc_cd, part_num).

FALSE:
Proceed to evaluate 'O' / 'L'.

---

DP-003

Condition:
UPPER(p_price_type) = 'O' OR UPPER(p_price_type) = 'L'

TRUE:
Retrieve lv_gst_state_cd from AM_DEALER_LOC / GM_STATE, then delegate to SP_GET_PART_SELL_PRICE_ONE to obtain the sell price; on any exception within this block set v_price to 0.

FALSE:
Proceed to evaluate 'M'.

---

DP-004

Condition:
UPPER(p_price_type) = 'M'

TRUE:
Query PM_PART_VAR for mrp_1 (NVL to 0) using the standard variant key.

FALSE:
Proceed to evaluate 'LC'.

---

DP-005

Condition:
UPPER(p_price_type) = 'LC'

TRUE:
Query PM_PART_VAR for landed_cost (NVL to 0) using the standard variant key.

FALSE:
No matching price type; v_price remains 0.

---

DP-006

Condition:
Outer NO_DATA_FOUND exception is raised (no variant-level record found in PM_PART_VAR or PM_PART for the 'NA' path)

TRUE:
Execute fallback query against PM_PART selecting the column appropriate to the price type (purchase_price for 'P'; sell_price for 'L' or 'O'; mrp_1 for 'M'), filtered by part_num, dealer_map_cd IN (p_principal, p_dealer_map_cd), and principal_map_cd = p_principal; return the result.

FALSE:
Normal execution path; return v_price as resolved in Steps 3-7.

---

DP-007

Condition:
Fallback query (DP-006 TRUE path) raises NO_DATA_FOUND, TOO_MANY_ROWS, or OTHERS

TRUE:
Set v_price to 0 and return 0.

FALSE:
Return the fallback price retrieved from PM_PART.

---
**Database Interactions**

- DB-001 - Read PM_PART - Reads data from PM_PART for lookup or validation.
- DB-002 - Read PM_PART_VAR - Reads data from PM_PART_VAR for lookup or validation.
- DB-003 - Read AM_DEALER_LOC - Reads data from AM_DEALER_LOC for lookup or validation.
**Business Rules**

- BR-001 - Price-type code matching is case-insensitive; all comparisons are made against the upper-cased value of p_price_type.
- BR-002 - For price type 'NA', the sell price is sourced directly from the master part record (PM_PART) and the dealer match is broadened to include either the dealer map code or the principal, ensuring multi-company scenarios are handled correctly.
- BR-003 - For price type 'P', the purchase price is sourced from the part variant record (PM_PART_VAR) scoped to the specific parent group, dealer, location, and part number combination.
- BR-004 - For price types 'O' and 'L', the sell price must be calculated via SP_GET_PART_SELL_PRICE_ONE using the GST state code resolved from the dealer location; direct reads of os_sell_price or ls_sell_price from PM_PART_VAR are no longer used (those queries are commented out).
- BR-005 - The GST state code required by SP_GET_PART_SELL_PRICE_ONE is derived by joining AM_DEALER_LOC to GM_STATE on principal_map_cd and state_cd for the given parent group, dealer map code, and location code.
- BR-006 - For price type 'M', the MRP (mrp_1) is sourced from PM_PART_VAR; for price type 'LC', the landed cost is sourced from PM_PART_VAR.
- BR-007 - When a variant-level record is not found (NO_DATA_FOUND), the function falls back to PM_PART to retrieve the equivalent price field, maintaining price availability even when variant data is absent.
- BR-008 - The fallback PM_PART query is not defined for price type 'LC'; if no variant record exists for 'LC', the function returns 0.
- BR-009 - All unhandled exceptions (NO_DATA_FOUND, TOO_MANY_ROWS, OTHERS) at every level of the function result in a return value of 0, ensuring the calling POST-QUERY trigger is never interrupted by a pricing data gap.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
FUNCTION Sf_Get_Price(p_parent_group  pm_part_var.parent_group%TYPE,
                                        p_dealer_map_cd pm_part_var.dealer_map_cd%TYPE,
                                        p_loc_cd        pm_part_var.loc_cd%TYPE,
                                        p_principal     pm_part_var.dealer_map_cd%TYPE,
                                        p_price_type    VARCHAR2,
                                        p_part_num      pm_part_var.part_num%TYPE)
  RETURN pm_part_var.purchase_price%TYPE IS
  v_price      pm_part_var.purchase_price%TYPE := 0;
  v_sql        VARCHAR2(2000);
  v_price_code VARCHAR2(100);
	lv_gst_state_cd gm_state.gst_state_cd%type;
	lv_ccy        VARCHAR2(10);
	lv_po_ccy     VARCHAR2(10);
	lv_tax_cd     pm_part_var.part_tax_cd%type;
BEGIN
  IF UPPER(p_price_type) = 'NA' THEN
    SELECT sell_price
      INTO v_price
      FROM pm_part
     WHERE dealer_map_cd IN (p_dealer_map_cd, p_principal)
       AND part_num = p_part_num
       AND principal_map_cd = p_principal;  --Added by Rajeev for multi company changes
  ELSE
    IF UPPER(p_price_type) = 'P' THEN
      SELECT NVL(purchase_price, 0)
        INTO v_price
        FROM pm_part_var
       WHERE parent_group = p_parent_group
         AND dealer_map_cd = p_dealer_map_cd
         AND loc_cd = p_loc_cd
         AND part_num = p_part_num;
 ELSIF UPPER(p_price_type) = 'O' or UPPER(p_price_type) = 'L' then
		   begin
   SELECT  gst_state_cd into   lv_gst_state_cd
    FROM am_dealer_loc l, gm_state g
   WHERE l.parent_group = p_parent_group
     AND l.dealer_map_cd = p_dealer_map_cd
     AND l.loc_cd = p_loc_cd
     AND g.principal_map_cd = l.principal_map_cd
     AND g.state_cd = l.state_cd;
    Sp_Get_Part_Sell_Price_One(--------------------v_1
                               p_principal,
                               p_parent_group,
                               p_dealer_map_cd,
                               p_loc_cd,
                               p_part_num,
                               'O',
                               lv_po_ccy,
                               v_price,
                               lv_tax_cd,
                               'Y',
                               lv_gst_state_cd
                               )
                               ;
       exception
         when others then
           v_price:=0;
      end;

    /*  SELECT NVL(os_sell_price, 0)
        INTO v_price
        FROM pm_part_var
       WHERE parent_group = p_parent_group
         AND dealer_map_cd = p_dealer_map_cd
         AND loc_cd = p_loc_cd
         AND part_num = p_part_num;
    ELSIF UPPER(p_price_type) = 'L' THEN
      SELECT NVL(ls_sell_price, 0)
        INTO v_price
        FROM pm_part_var
       WHERE parent_group = p_parent_group
         AND dealer_map_cd = p_dealer_map_cd
         AND loc_cd = p_loc_cd
         AND part_num = p_part_num;*/
    ELSIF UPPER(p_price_type) = 'M' THEN
      SELECT NVL(mrp_1, 0)
        INTO v_price
        FROM pm_part_var
       WHERE parent_group = p_parent_group
         AND dealer_map_cd = p_dealer_map_cd
         AND loc_cd = p_loc_cd
         AND part_num = p_part_num;
    ELSIF UPPER(p_price_type) = 'LC' THEN
      SELECT NVL(landed_cost, 0)
        INTO v_price
        FROM pm_part_var
       WHERE parent_group = p_parent_group
         AND dealer_map_cd = p_dealer_map_cd
         AND loc_cd = p_loc_cd
         AND part_num = p_part_num;
    END IF;
  END IF;

  RETURN v_price;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    BEGIN
      IF UPPER(p_price_type) = 'P' THEN
        SELECT purchase_price
          INTO v_price
          FROM pm_part
         WHERE part_num = p_part_num
           AND dealer_map_cd IN (p_principal, p_dealer_map_cd)
           AND principal_map_cd = p_principal;  --Added by Rajeev for multi company changes
      ELSIF UPPER(p_price_type) = 'L' OR UPPER(p_price_type) = 'O' THEN
        SELECT sell_price
          INTO v_price
          FROM pm_part
         WHERE part_num = p_part_num
           AND dealer_map_cd IN (p_principal, p_dealer_map_cd)
           AND principal_map_cd = p_principal;  --Added by Rajeev for multi company changes
      ELSIF UPPER(p_price_type) = 'M' THEN
        SELECT mrp_1
          INTO v_price
          FROM pm_part
         WHERE part_num = p_part_num
           AND dealer_map_cd IN (p_principal, p_dealer_map_cd)
           AND principal_map_cd = p_principal;  --Added by Rajeev for multi company changes
      END IF;

      RETURN v_price;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        v_price := 0;
        RETURN v_price;
      WHEN TOO_MANY_ROWS THEN
        v_price := 0;
        RETURN v_price;
      WHEN OTHERS THEN
        v_price := 0;
        RETURN v_price;
    END;
  WHEN TOO_MANY_ROWS THEN
    v_price := 0;
    RETURN v_price;
  WHEN OTHERS THEN
    v_price := 0;
    RETURN v_price;
END;

```

#### SP-069 - SF_GET_STORE_BIN_LOC

**Invoked From:**

- pt_phy_fmb.xml [Trigger: POST-QUERY]
- pt_phy_fmb.xml [Trigger: WBP]

---

**Screen:**

COUNT DETAILS (N/A / CN_MAIN); PART DETAILS (N/A / CN_MAIN)

---

**Purpose**

Returns a comma-separated list of active default bin locations for a given part number within a dealer/location context. When a store code is supplied the lookup is restricted to that store; when no store code is provided the function returns bin locations across all stores for the part. A company-FA code is resolved from AM_DEALER_LOC_COMPANY_MASTER and used to further filter results from PM_STOCK_BIN_LOC.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_parent | PM_PART_VAR.parent_group%TYPE | IN |
| p_dealer | PM_PART_VAR.dealer_map_cd%TYPE | IN |
| p_loc_cd | PM_PART_VAR.loc_cd%TYPE | IN |
| p_part_num | VARCHAR2 | IN |
| p_store_cd | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Initialise the return variable lv_bin_loc to NULL and declare lv_comp_fa to hold the resolved company-FA code.
- Step 2 - Attempt to retrieve the distinct comp_code from AM_DEALER_LOC_COMPANY_MASTER for the supplied parent_group, dealer_map_cd, and loc_cd combination; if the query raises any exception the variable remains NULL and processing continues.
- Step 3 - Execute cursor c1 against PM_STOCK_BIN_LOC filtering by parent_group, dealer_map_cd, loc_cd, stores_cd (= p_store_cd), part_num, comp_fa (using NVL to allow a NULL lv_comp_fa to match any comp_fa value), ACTIVE_YN = 'Y', and DEFAULT_YN = 'Y'.
- Step 4 - For each row returned by c1, append the bin_loc value to lv_bin_loc; the first value is assigned directly, subsequent values are concatenated with a comma-space delimiter.
- Step 5 - Evaluate whether p_store_cd is NULL; if so, execute cursor c2 against PM_STOCK_BIN_LOC using the same filters as c1 but without the stores_cd predicate, and with a DISTINCT qualifier and an index hint (IDX_PMS_BIN_LOC_PART) for performance.
- Step 6 - For each row returned by c2, append the bin_loc value to lv_bin_loc using the same concatenation logic as Step 4.
- Step 7 - Return lv_bin_loc (which may be NULL if no matching active default bin locations were found).

---
**Decision Points**

DP-001

Condition:
The SELECT against AM_DEALER_LOC_COMPANY_MASTER raises an exception (e.g., NO_DATA_FOUND or TOO_MANY_ROWS).

TRUE:
The exception is silently suppressed; lv_comp_fa remains NULL, and the NVL logic in the cursors causes comp_fa filtering to be bypassed (matches any comp_fa value).

FALSE:
lv_comp_fa is populated with the resolved comp_code and is used to restrict bin-location lookups to that specific company-FA value.

---

DP-002

Condition:
lv_bin_loc IS NULL when a bin_loc row is being appended (evaluated inside both cursor loops).

TRUE:
lv_bin_loc is set directly to the current bin_loc value (no leading delimiter).

FALSE:
The current bin_loc value is concatenated to lv_bin_loc with a comma-space separator.

---

DP-003

Condition:
p_store_cd IS NULL after the c1 loop completes.

TRUE:
Cursor c2 is executed to retrieve distinct active default bin locations for the part across all stores, and results are appended to lv_bin_loc.

FALSE:
Cursor c2 is not executed; the function relies solely on the store-specific results from c1.

---
**Database Interactions**

- DB-001 - Read PM_STOCK_BIN_LOC - Reads data from PM_STOCK_BIN_LOC for lookup or validation.
- DB-002 - Read AM_DEALER_LOC_COMPANY_MASTER - Reads data from AM_DEALER_LOC_COMPANY_MASTER for lookup or validation.
**Business Rules**

- BR-001 - Only bin locations flagged as both active (ACTIVE_YN = 'Y') and default (DEFAULT_YN = 'Y') are eligible for return; inactive or non-default bin locations are excluded.
- BR-002 - The company-FA code resolved from AM_DEALER_LOC_COMPANY_MASTER is used to scope bin-location results; if no company-FA code can be determined the filter is relaxed to include all comp_fa values via NVL.
- BR-003 - When a store code is provided (p_store_cd IS NOT NULL), bin location lookup is restricted to that specific store via the stores_cd predicate in PM_STOCK_BIN_LOC.
- BR-004 - When no store code is provided (p_store_cd IS NULL), the function performs a broader search across all stores using a DISTINCT query, preventing duplicate bin location values in the result.
- BR-005 - Multiple bin locations matching the criteria are returned as a single comma-space-delimited string; if no matching locations exist the function returns NULL.
- BR-006 - The bin-location query without a store code applies an index hint (IDX_PMS_BIN_LOC_PART) to optimise performance when scanning PM_STOCK_BIN_LOC by part number.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
FUNCTION Sf_Get_Store_Bin_Loc (
      p_parent     PM_PART_VAR.parent_group%TYPE,
      p_dealer     PM_PART_VAR.dealer_map_cd%TYPE,
      p_loc_cd     PM_PART_VAR.loc_cd%TYPE,
      p_part_num   VARCHAR2,
      p_store_cd   VARCHAR2
)
      RETURN VARCHAR2
IS
      lv_bin_loc   VARCHAR2 (4000)                               := NULL;
      lv_comp_fa   AM_DEALER_LOC_COMPANY_MASTER.comp_code%TYPE;

      CURSOR c1
      IS
            SELECT bin_loc
              FROM PM_STOCK_BIN_LOC
             WHERE parent_group = p_parent
               AND dealer_map_cd = p_dealer
               AND loc_cd = p_loc_cd
               AND stores_cd = p_store_cd
               AND part_num = p_part_num
               AND comp_fa = NVL (lv_comp_fa, comp_fa)
			   AND ACTIVE_YN ='Y'
			   AND DEFAULT_YN = 'Y';

      CURSOR c2
      IS
        SELECT /*+ index (pm IDX_PMS_BIN_LOC_PART)*/DISTINCT bin_loc --index hint added by Arpan on 08-oct-13
          FROM PM_STOCK_BIN_LOC pm
         WHERE pm.parent_group = p_parent
           AND pm.dealer_map_cd = p_dealer
           AND pm.loc_cd = p_loc_cd
           AND pm.part_num = p_part_num
           AND pm.comp_fa = NVL (lv_comp_fa, pm.comp_fa)
           AND pm.ACTIVE_YN ='Y'
           AND pm.DEFAULT_YN = 'Y';
BEGIN
      BEGIN
            SELECT DISTINCT comp_code
                       INTO lv_comp_fa
                       FROM AM_DEALER_LOC_COMPANY_MASTER
                      WHERE parent_group = p_parent AND dealer_map_cd = p_dealer AND loc_cd = p_loc_cd;
      EXCEPTION
            WHEN OTHERS THEN
                  NULL;
      END;

      /* With Stores Code */
      FOR i IN c1
      LOOP
            IF lv_bin_loc IS NULL THEN
                  lv_bin_loc := i.bin_loc;
            ELSE
                  lv_bin_loc := lv_bin_loc || ', ' || i.bin_loc;
            END IF;
      END LOOP;

      /* Without Stores Code */
      IF p_store_cd IS NULL THEN
            FOR i IN c2
            LOOP
                  IF lv_bin_loc IS NULL THEN
                        lv_bin_loc := i.bin_loc;
                  ELSE
                        lv_bin_loc := lv_bin_loc || ', ' || i.bin_loc;
                  END IF;
            END LOOP;
      END IF;

      RETURN lv_bin_loc;
END;

```

#### SP-070 - SF_GET_STORE_NAME

**Invoked From:**

- pt_phy_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]
- pt_phy_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

PART DETAILS (N/A / CN_MAIN)

---

**Purpose**

Retrieves the store description (display name) for a given combination of dealer map code, location code, and store code from the GM_STORE reference table. The function returns the matching store name as a VARCHAR2 value, or NULL if no matching record exists. It is used on the PART DETAILS screen to resolve and display a human-readable store name during button-press and item-validation events.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_dealer_map_cd | number | IN |
| p_loc_cd | varchar2 | IN |
| p_store_cd | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept three input parameters: dealer map code (p_dealer_map_cd), location code (p_loc_cd), and store code (p_store_cd).
- Step 2 - Query the GM_STORE table, filtering by the exact combination of DEALER_MAP_CD, LOC_CD, and STORES_CD that matches the supplied input parameters, and attempt to retrieve the STORES_DESC value into the local variable lv_name.
- Step 3 - If no matching row is found, handle the NO_DATA_FOUND exception by setting lv_name to NULL.
- Step 4 - Return lv_name (either the resolved store description or NULL) to the calling trigger.

---
**Decision Points**

DP-001

Condition:
A row exists in GM_STORE where DEALER_MAP_CD = p_dealer_map_cd AND LOC_CD = p_loc_cd AND STORES_CD = p_store_cd.

TRUE:
The STORES_DESC value is selected into lv_name and subsequently returned to the caller.

FALSE:
The NO_DATA_FOUND exception is caught; lv_name is set to NULL and NULL is returned to the caller.

---
**Database Interactions**

- DB-001 - Read GM_STORE - Reads data from GM_STORE for lookup or validation.
**Business Rules**

- BR-001 - The store lookup must be performed using all three key attributes (dealer map code, location code, and store code) in combination; a match on fewer attributes is not sufficient to identify a unique store.
- BR-002 - If no store record matches the supplied key combination, the function must return NULL rather than raising an unhandled exception, ensuring that calling triggers on the PART DETAILS screen can handle a missing store gracefully.
- BR-003 - The function is read-only with respect to GM_STORE; it performs no insert, update, or delete operations on any table.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
function sf_get_store_name(p_dealer_map_cd number, p_loc_cd varchar2, p_store_cd varchar2)
return varchar2 is
lv_name varchar2(100);
begin
begin
  select stores_desc into lv_name from gm_store where dealer_map_cd = p_dealer_map_cd and loc_cd = p_loc_cd and stores_cd = p_store_cd;
exception
    when no_data_found then
       lv_name := null;
end;

  return(lv_name);
end;

```

#### SP-071 - SP_ADJUST_LANDED

**Invoked From:**

- pt_phy_fmb.xml [Trigger: FT_SAVE]

---

**Screen:**

ADJUSTMENT DETAILS (N/A / CN_ADJ); COUNT DETAILS (N/A / CN_MAIN); PART DETAILS (N/A / CN_MAIN)

---

**Purpose**

Calculates the weighted-average landed cost for a specific part on a stock-adjustment document and writes the result-together with the derived item value-back to the stock-adjustment record. The procedure is triggered during the save event of the physical inventory / adjustment screen (pt_phy_fmb.xml, FT_SAVE) to ensure that PD_STKADJ always reflects an accurate landed cost and extended item value before the adjustment is committed.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| pi_parent_group | VARCHAR2 | IN |
| pi_dealer | NUMBER | IN |
| pi_loc_cd | VARCHAR2 | IN |
| pi_comp_fa | VARCHAR2 | IN |
| pi_adj_num | VARCHAR2 | IN |
| pi_part_num | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the six identifying parameters: parent group, dealer, location code, company/FA code, adjustment number, and part number.
- Step 2 - Query PT_BIN_CARD to compute the weighted-average landed cost for the matching part and adjustment document: SUM(landed_cost × iss_qty) ÷ SUM(iss_qty), filtered to document type 'ADJ' and the supplied adjustment number, dealer, location, company/FA, and part number. The result is stored in the local variable lv_landed.
- Step 3 - Update the corresponding row in PD_STKADJ, setting landed_cost to lv_landed and dec_item_value to lv_landed × adj_qty, matched on the same six key attributes (parent_group, dealer_map_cd, loc_cd, comp_fa, adj_num, part_num).

---
**Decision Points**

DP-001

Condition: PT_BIN_CARD contains one or more rows matching the supplied parent_group, dealer_map_cd, loc_cd, comp_fa, doc_type = 'ADJ', doc_num, and part_num with non-zero iss_qty values.

TRUE: The weighted-average landed cost (lv_landed) is calculated and used to update PD_STKADJ.

FALSE: The SELECT INTO returns NULL (no matching rows or all iss_qty values are zero), lv_landed remains 0 (its initialised default), and PD_STKADJ is updated with landed_cost = 0 and dec_item_value = 0.

---
**Database Interactions**

- DB-001 - Read PT_BIN_CARD - Reads data from PT_BIN_CARD for lookup or validation.
- DB-002 - Update PD_STKADJ - Updates existing rows in PD_STKADJ (columns: landed cost, dec item value).
**Business Rules**

- BR-001 - Landed cost must be computed as a weighted average using issue quantity (iss_qty) as the weight: SUM(landed_cost × iss_qty) ÷ SUM(iss_qty). A simple average is not permitted.
- BR-002 - Only bin-card transactions of document type 'ADJ' are eligible for the landed-cost calculation; other document types are excluded from the aggregation.
- BR-003 - The extended item value stored in PD_STKADJ (dec_item_value) must always equal the calculated weighted-average landed cost multiplied by the adjustment quantity (adj_qty); it is never entered independently.
- BR-004 - The update to PD_STKADJ must be keyed on all six identifying attributes (parent_group, dealer_map_cd, loc_cd, comp_fa, adj_num, part_num) to ensure only the correct adjustment line is modified.
- BR-005 - If no matching PT_BIN_CARD rows exist or the weighted-average resolves to NULL, the landed cost and derived item value default to zero, preventing NULL values from being stored in PD_STKADJ.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
PROCEDURE sp_adjust_landed (
      pi_parent_group   IN   VARCHAR2,
      pi_dealer         IN   NUMBER,
      pi_loc_cd         IN   VARCHAR2,
      pi_comp_fa        IN   VARCHAR2,
      pi_adj_num        IN   VARCHAR2,
      pi_part_num       IN   VARCHAR2
)
IS
      lv_landed   NUMBER := 0;
BEGIN
      SELECT SUM ( landed_cost * iss_qty) / SUM (iss_qty)
        INTO lv_landed
        FROM PT_BIN_CARD
       WHERE parent_group = pi_parent_group
         AND dealer_map_cd = pi_dealer
         AND loc_cd = pi_loc_cd
         AND comp_fa = pi_comp_fa
         AND doc_type = 'ADJ'
         AND doc_num = pi_adj_num
         AND part_num = pi_part_num;

      UPDATE PD_STKADJ
         SET landed_cost = lv_landed,
		 	 dec_item_value = lv_landed * adj_qty
       WHERE parent_group = pi_parent_group
         AND dealer_map_cd = pi_dealer
         AND loc_cd = pi_loc_cd
         AND comp_fa = pi_comp_fa
         AND adj_num = pi_adj_num
         AND part_num = pi_part_num;
END;

```

#### SP-072 - SP_GET_PART_DESC

**Invoked From:**

- pt_phy_fmb.xml [Trigger: POST-QUERY]

---

**Screen:**

PART DETAILS (N/A / CN_MAIN)

---

**Purpose**

Retrieves the description of a specified part number from the PM_PART table for display on the PART DETAILS screen. The procedure is invoked during the POST-QUERY trigger and returns the part description or a meaningful error message and error code to the calling form.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_dealer | NUMBER | IN |
| p_principal | NUMBER | IN |
| p_part_num | VARCHAR2 | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_part_desc | VARCHAR2 | OUT |
| p_errmsg | VARCHAR2 | OUT |
| p_error_cd | NUMBER | OUT |

---

**Dependencies**

- WEBUTIL.EXECUTE ([SP-035](#SP-035--WEBUTIL.EXECUTE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the dealer code, principal code, and part number as input parameters.
- Step 2 - Construct and execute a dynamic SQL query against PM_PART, filtering where dealer_map_cd matches either the dealer or the principal code and part_num matches the supplied part number.
- Step 3 - If exactly one row is returned, populate p_part_desc with the retrieved part description and set p_error_cd to 0 (success).
- Step 4 - If no row is found (NO_DATA_FOUND), set p_errmsg to 'Part Number not found' and p_error_cd to 1.
- Step 5 - If multiple rows are returned (TOO_MANY_ROWS), execute a second, narrower dynamic SQL query against PM_PART filtering exclusively on the principal code and part number to resolve the ambiguity.
- Step 6 - If the narrowed query returns exactly one row, populate p_part_desc and set p_error_cd to 0.
- Step 7 - If the narrowed query still finds no row, set p_errmsg to 'Part Number not found' and p_error_cd to 1.
- Step 8 - If a VALUE_ERROR occurs (data width or type incompatibility), set p_errmsg to 'Width problem/Incompatible Data while retrieving Part description' and p_error_cd to 1.
- Step 9 - For any other unexpected exception, set p_errmsg to 'Execution failed while retrieving Part description' appended with the SQLERRM detail, and set p_error_cd to 1.

---
**Decision Points**

DP-001

Condition:
The initial dynamic SQL query on PM_PART (filtering on dealer_map_cd IN (p_dealer, p_principal) and part_num = p_part_num) returns exactly one row.

TRUE:
p_part_desc is populated with the retrieved part description and p_error_cd is set to 0.

FALSE:
Exception handling is triggered; processing continues to DP-002, DP-003, DP-004, or DP-005 depending on the exception raised.

---

DP-002

Condition:
The initial query raises NO_DATA_FOUND (no matching part exists for either the dealer or principal code).

TRUE:
p_errmsg is set to 'Part Number not found' and p_error_cd is set to 1.

FALSE:
Processing continues to the next applicable exception handler.

---

DP-003

Condition:
The initial query raises TOO_MANY_ROWS (the part number exists under both the dealer and principal codes).

TRUE:
A second dynamic SQL query is executed against PM_PART, filtering exclusively on dealer_map_cd = p_principal and part_num = p_part_num to resolve the ambiguity; processing continues to DP-004.

FALSE:
Processing continues to the next applicable exception handler.

---

DP-004

Condition:
The narrowed (principal-only) fallback query returns exactly one row.

TRUE:
p_part_desc is populated with the retrieved part description and p_error_cd is set to 0.

FALSE:
NO_DATA_FOUND is raised by the fallback query; p_errmsg is set to 'Part Number not found' and p_error_cd is set to 1.

---

DP-005

Condition:
A VALUE_ERROR exception is raised during retrieval (e.g., data width or type incompatibility).

TRUE:
p_errmsg is set to 'Width problem/Incompatible Data while retrieving Part description' and p_error_cd is set to 1.

FALSE:
Any remaining unhandled exception falls through to the OTHERS handler, which sets p_errmsg to 'Execution failed while retrieving Part description' concatenated with SQLERRM, and p_error_cd to 1.

---
**Database Interactions**

- DB-001 - Read PM_PART - Reads data from PM_PART for lookup or validation.
**Business Rules**

- BR-001 - A part description lookup must match on both the part number and a dealer mapping code that corresponds to either the dealer or the principal; no cross-dealer retrieval outside these two identifiers is permitted.
- BR-002 - When a part number resolves to multiple rows (i.e., it exists under both the dealer and principal codes), the principal code takes precedence and the description associated with the principal is returned.
- BR-003 - If the part number cannot be found under any permissible dealer mapping code, the procedure must signal a business-level failure by returning error code 1 and the message 'Part Number not found' rather than raising an unhandled exception to the calling form.
- BR-004 - Data width or type incompatibilities encountered during description retrieval must be caught and surfaced as a controlled error (p_error_cd = 1) with a descriptive message, preventing unhandled exceptions from propagating to the POST-QUERY trigger.
- BR-005 - All unexpected runtime errors must be captured by a general exception handler that returns p_error_cd = 1 and appends the Oracle error message (SQLERRM) to the standard failure message, ensuring full traceability.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
PROCEDURE sp_get_part_desc
/***********************************************************************************************************************************************
  * Created/Modified By    Date        Change Indicator   SCR#              Description
  * Rohit                  21-02-18      v_1                          to many rows exception was not handled properly.

  ************************************************************************************************************************************************/
  /*
  $Log: SP_GET_PART_DESC.sql,v $
  Revision 1.3  2005/02/14 06:21:01  ponmuthurajaa
  In message part number display is removed

  */
(p_dealer    IN NUMBER,
 p_principal IN NUMBER,
 p_part_num  IN VARCHAR2,
 p_part_desc OUT VARCHAR2,
 p_errmsg    OUT VARCHAR2,
 p_error_cd  OUT NUMBER) IS
  v_sql VARCHAR2(2000);
BEGIN
  /* This procedure is used to get the description of a given part number */
  v_sql := 'select
        part_desc
    from
       pm_part
    where
       dealer_map_cd   in ( :p_dealer, :p_principal)
       and   part_num       = :p_part_num';
  EXECUTE IMMEDIATE v_sql
    INTO p_part_desc
    USING p_dealer, p_principal, p_part_num;
  p_error_cd := 0;
EXCEPTION
  WHEN no_data_found THEN
    p_errmsg   := 'Part Number not found';
    p_error_cd := 1;
  WHEN too_many_rows THEN
    -----------v_1 start
    BEGIN
      v_sql := 'select
        part_desc
    from
       pm_part
    where
       dealer_map_cd   = :p_principal
       and   part_num       = :p_part_num';
      EXECUTE IMMEDIATE v_sql
        INTO p_part_desc
        USING p_principal, p_part_num;
      p_error_cd := 0;
    EXCEPTION
      WHEN no_data_found THEN
        p_errmsg   := 'Part Number not found';
        p_error_cd := 1;
    END;
    -----------v_1 ends
  WHEN value_error THEN
    p_errmsg   := 'Width problem/Incompatible Data while retrieving Part description';
    p_error_cd := 1;

  WHEN OTHERS THEN
    p_errmsg   := 'Execution failed while retrieving Part description ' ||
                  SQLERRM;
    p_error_cd := 1;
END;

```

#### SP-073 - SP_GET_PART_SELL_PRICE_ONE

**Invoked From:**

- SF_GET_PRICE.fnc [StoredProcedure: SF_GET_PRICE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the selling price and associated tax code for a given part, supporting both GST and non-GST pricing scenarios. Given a principal, dealer/location context, part number, and pricing type, the procedure derives the applicable unit price by back-calculating from MRP using cumulative GST charge factors, and returns the price, currency, and part tax code to the calling function SF_GET_PRICE.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_PRINCIPAL | NUMBER | IN |
| P_PARENT_GROUP | VARCHAR2 | IN |
| P_DEALER_MAP_CD | NUMBER | IN |
| P_LOC_CD | VARCHAR2 | IN |
| P_PART_NUM | VARCHAR2 | IN |
| P_TAX_TYPE | VARCHAR2 | IN |
| pi_lst_yn | VARCHAR2 | IN |
| pi_cust_gst_state_cd | ph_issue.cust_gst_state_cd%type | IN |
| PI_CESS_FLAG | VARCHAR2 | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| PO_CCY | VARCHAR2 | OUT |
| PO_PRICE | NUMBER | OUT |
| PO_TAX_CD | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive input parameters identifying the principal (P_PRINCIPAL), parent group (P_PARENT_GROUP), dealer/location (P_DEALER_MAP_CD, P_LOC_CD), part number (P_PART_NUM), pricing type (P_TAX_TYPE), list-price flag (pi_lst_yn), customer GST state code (pi_cust_gst_state_cd), and CESS inclusion flag (PI_CESS_FLAG).
- Step 2 - Evaluate P_TAX_TYPE. If it equals 'NA' (case-insensitive), query PM_PART for the part's sell_price using the dealer map code (accepting either P_DEALER_MAP_CD or P_PRINCIPAL) and the principal map code, then skip all GST processing and proceed directly to Step 9.
- Step 3 - For all non-'NA' tax types, enter the GST pricing block. Query PM_PART_VAR to retrieve PART_TAX_CD for the matching parent group, dealer, location, and part number. Store the result in LN_PTAX. If no row is found, LN_PTAX remains NULL; if multiple rows are found, raise application error -20032; other exceptions raise errors -20033 or -20034 with descriptive messages.
- Step 4 - Query PM_PART_VAR for MRP_1 (defaulting to 0 via NVL) using the same parent group, dealer, location, and part number key. If no row is found in PM_PART_VAR, fall back to PM_PART using the principal/dealer map code and principal map code to obtain MRP_1; if that also fails, default MRP_1 to 0.
- Step 5 - Determine the tax applicability type (lv_taxtype): set to 'O' (outstation/list) if pi_lst_yn = 'Y', otherwise set to 'C' (common/customer).
- Step 6 - Iterate over matching rows from AM_CHARGE joined to PM_TAX for the dealer, location, sales tax type ('S'), the resolved lv_taxtype, the part tax code LN_PTAX, and the parent group. The GST state code is matched using DECODE: if pi_lst_yn = 'Y' the stored GST state is used; otherwise pi_cust_gst_state_cd is used. Charge types 'TCN', 'TCP', and 'TCT' are excluded from the cursor.
- Step 7 - Accumulate charge values into lv_os_factor: if the charge type is 'CES', include the charge value only when PI_CESS_FLAG = 'Y'; for all other charge types, always add the charge value.
- Step 8 - Back-calculate the sell price from MRP using the formula: TRUNC((MRP_1 × 100) / (100 + lv_os_factor), 2). Assign this result to both LN_OS_SELL_PRICE and LN_LS_SELL_PRICE.
- Step 9 - Select the final price (v_price) based on P_TAX_TYPE: 'P' -> LN_PURCHASE_PRICE; 'O' -> LN_OS_SELL_PRICE; 'L' -> LN_LS_SELL_PRICE; 'M' -> LN_MRP_1. (For 'NA', v_price was already set in Step 2.)
- Step 10 - Assign v_price to output parameter PO_PRICE and LN_PTAX to output parameter PO_TAX_CD. PO_CCY is declared as an OUT parameter but is not explicitly set within this procedure.

---
**Decision Points**

DP-001

Condition:
UPPER(P_TAX_TYPE) = 'NA'

TRUE:
Query PM_PART directly for sell_price using the dealer/principal map codes and principal map code. Skip GST charge accumulation entirely. Assign the retrieved sell_price to v_price.

FALSE:
Enter the GST pricing block: retrieve PART_TAX_CD from PM_PART_VAR, retrieve MRP_1 (with fallback to PM_PART), determine tax type, accumulate charge factors from AM_CHARGE/PM_TAX, and back-calculate the sell price from MRP.

---

DP-002

Condition:
PM_PART_VAR returns NO_DATA_FOUND when querying MRP_1

TRUE:
Fall back to PM_PART to retrieve MRP_1 using DEALER_MAP_CD IN (P_PRINCIPAL, P_DEALER_MAP_CD) and PRINCIPAL_MAP_CD = P_PRINCIPAL. If that also fails, default LN_MRP_1 to 0.

FALSE:
Use the MRP_1 value returned from PM_PART_VAR (NVL to 0 if the column is NULL).

---

DP-003

Condition:
pi_lst_yn = 'Y'

TRUE:
Set lv_taxtype to 'O' (outstation/list pricing). In the AM_CHARGE/PM_TAX cursor, match GST state code to the stored value on PM_TAX (b.gst_state_cd).

FALSE:
Set lv_taxtype to 'C' (customer/common pricing). In the AM_CHARGE/PM_TAX cursor, match GST state code to pi_cust_gst_state_cd.

---

DP-004

Condition:
Charge type from AM_CHARGE cursor (K.CHARGE_TYPE) = 'CES'

TRUE:
Include the charge value in lv_os_factor only if PI_CESS_FLAG = 'Y'; otherwise skip it.

FALSE:
Always add the charge value to lv_os_factor regardless of PI_CESS_FLAG.

---

DP-005

Condition:
UPPER(P_TAX_TYPE) value after GST block processing

TRUE ('P'):
Assign LN_PURCHASE_PRICE as the final price.

TRUE ('O'):
Assign LN_OS_SELL_PRICE (back-calculated from MRP) as the final price.

TRUE ('L'):
Assign LN_LS_SELL_PRICE (back-calculated from MRP) as the final price.

TRUE ('M'):
Assign LN_MRP_1 as the final price.

FALSE (none matched):
v_price retains its initialised value of 0.

---
**Database Interactions**

- DB-001 - Read PM_PART - Reads data from PM_PART for lookup or validation.
- DB-002 - Read PM_PART_VAR - Reads data from PM_PART_VAR for lookup or validation.
- DB-003 - Read AM_CHARGE - Reads data from AM_CHARGE for lookup or validation.
**Business Rules**

- BR-001 - When P_TAX_TYPE is 'NA', the part's sell price is retrieved directly from PM_PART without any tax or GST adjustment; the lookup accepts either the dealer map code or the principal as the dealer_map_cd, filtered by principal_map_cd.
- BR-002 - For all non-'NA' tax types, the part tax code (PART_TAX_CD) is sourced exclusively from PM_PART_VAR, matched on parent group, dealer map code, location code, and part number; the procedure does not fall back to PM_PART for the tax code.
- BR-003 - If exactly one PART_TAX_CD row is not found (NO_DATA_FOUND), LN_PTAX remains NULL and processing continues; if more than one row is found (TOO_MANY_ROWS), the procedure raises application error -20032 to prevent ambiguous tax code assignment.
- BR-004 - MRP_1 is sourced first from PM_PART_VAR; if absent, a fallback query to PM_PART is attempted using the principal/dealer map codes; if both queries fail, MRP_1 defaults to zero, ensuring the price calculation does not error out.
- BR-005 - The sell price under GST is derived by back-calculating from MRP using the formula: TRUNC((MRP_1 × 100) / (100 + total_charge_factor), 2). This applies equally to both outstation (LN_OS_SELL_PRICE) and local/list (LN_LS_SELL_PRICE) price fields.
- BR-006 - Only sales tax charges (PM_TAX.tax_type = 'S') matching the resolved common indicator ('O' for list pricing, 'C' for customer pricing) and the part's tax code are included in the charge factor accumulation.
- BR-007 - Charge types 'TCN', 'TCP', and 'TCT' are explicitly excluded from the GST charge factor accumulation loop, regardless of other matching criteria.
- BR-008 - The CESS charge type ('CES') is included in the accumulated charge factor only when PI_CESS_FLAG = 'Y'; if PI_CESS_FLAG is 'N' (the default), CESS charges are ignored in the price calculation.
- BR-009 - The GST state code matching in the AM_CHARGE/PM_TAX join is context-sensitive: for list/outstation pricing (pi_lst_yn = 'Y'), the stored GST state on the tax record is used; for customer pricing, the customer's GST state code (pi_cust_gst_state_cd) is used.
- BR-010 - The price type selector (P_TAX_TYPE) determines which computed price variable is returned: 'P' returns purchase price, 'O' returns outstation sell price, 'L' returns local sell price, and 'M' returns MRP. Any unrecognised type results in a returned price of zero.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
PROCEDURE        Sp_Get_Part_Sell_Price_One
/*
  $Log: SP_GET_PART_SELL_PRICE.sql,v $
  Revision 1.2  2005/02/22 10:00:28  vidyah
  exception handling
  */

   /***********************************************************************************************************************************************
  * Created/Modified By    Date        Change Indicator   SCR#              Description
  * Ravi                  05-06-17      v_1.3              GST      Gst changes

  ************************************************************************************************************************************************/

(P_PRINCIPAL     IN NUMBER,
 P_PARENT_GROUP  IN VARCHAR2,
 P_DEALER_MAP_CD IN NUMBER,
 P_LOC_CD        IN VARCHAR2,
 P_PART_NUM      IN VARCHAR2,
 P_TAX_TYPE      IN VARCHAR2,
 PO_CCY          OUT VARCHAR2,
 PO_PRICE        OUT NUMBER,
 PO_TAX_CD       OUT VARCHAR2,
 pi_lst_yn       IN VARCHAR2,----Added against v_1.3
 pi_cust_gst_state_cd in ph_issue.cust_gst_state_cd%type, ----Added against v_1.3
 PI_CESS_FLAG         IN VARCHAR2 DEFAULT 'N'   ---ADDED BY SUMIT ON 29052019
 ) IS
  LN_PTAX      PM_PART_VAR.PART_TAX_CD%TYPE;
  v_price      NUMBER := 0;
  v_sql        VARCHAR2(1000);
  v_price_code VARCHAR2(100);

  LN_PURCHASE_PRICE PM_PART_VAR.PURCHASE_PRICE%TYPE;
  LN_OS_SELL_PRICE  PM_PART_VAR.OS_SELL_PRICE%TYPE;
  LN_LS_SELL_PRICE  PM_PART_VAR.LS_SELL_PRICE%TYPE;
  LN_MRP_1          PM_PART_VAR.MRP_1%TYPE;
BEGIN
  -- PROCEDURE TO RETURN sell price and PART TAX CODE FOR A PART
  IF UPPER(p_TAX_type) = 'NA' THEN
    SELECT sell_price
      INTO v_price
      FROM PM_PART
     WHERE dealer_map_cd IN (p_dealer_map_cd, P_PRINCIPAL) --Added by prerna for multi-org
       AND part_num = p_part_num
       and PRINCIPAL_MAP_CD = P_PRINCIPAL; ---neha multi org changes
  ELSE
    /*  BEGIN
       SELECT nvl(PURCHASE_PRICE,0), nvl(OS_SELL_PRICE,0),
              nvl(LS_SELL_PRICE,0), nvl(MRP_1,0)
         INTO LN_PURCHASE_PRICE, LN_OS_SELL_PRICE, LN_LS_SELL_PRICE, LN_MRP_1
         FROM PM_PART_VAR
        WHERE PARENT_GROUP  = p_parent_group
          AND DEALER_MAP_CD = p_dealer_map_cd
          AND LOC_CD        = p_loc_cd
          AND PART_NUM = p_part_num ;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        BEGIN
           SELECT nvl(PURCHASE_PRICE,0), nvl(SELL_PRICE,0),
                  nvl(SELL_PRICE,0), nvl(MRP_1,0)
             INTO LN_PURCHASE_PRICE, LN_OS_SELL_PRICE, LN_LS_SELL_PRICE, LN_MRP_1
             FROM PM_PART
            WHERE DEALER_MAP_CD in (p_principal,p_dealer_map_cd )
              AND PART_NUM = p_part_num
              and PRINCIPAL_MAP_CD=P_PRINCIPAL;---neha multi org changes
         EXCEPTION WHEN OTHERS THEN
           LN_PURCHASE_PRICE := 0;
           LN_OS_SELL_PRICE  := 0;
           LN_LS_SELL_PRICE  := 0;
           LN_MRP_1          := 0;
         END;
      WHEN OTHERS THEN
           LN_PURCHASE_PRICE := 0;
           LN_OS_SELL_PRICE  := 0;
           LN_LS_SELL_PRICE  := 0;
           LN_MRP_1          := 0;
    END;*/ -----------------------------COMMENT BY RAVI 08062017
    -----------------------------ravi ---begin--against GST---
    DECLARE
      lv_ls_factor PM_TAX_HDR.ls_factor%TYPE;
      lv_os_factor PM_TAX_HDR.os_factor%TYPE;
      lv_taxtype   PM_TAX.COMMON_IND%TYPE;
      lv_taxcd     PM_TAX.PART_TAX_CD%TYPE;
    BEGIN
      BEGIN
        SELECT PART_TAX_CD
          INTO LN_PTAX
          FROM PM_PART_VAR
         WHERE PARENT_GROUP = P_PARENT_GROUP
           AND DEALER_MAP_CD = P_DEALER_MAP_CD
           AND LOC_CD = P_LOC_CD
           AND PART_NUM = P_PART_NUM; --ADDED TO GET THE DETAILS FOR THAT PARTICUALAR DEALER LOCATION
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          NULL;
        WHEN TOO_MANY_ROWS THEN
          RAISE_APPLICATION_ERROR(-20032,
                                  'More than one Part tax code found for ' ||
                                  P_PART_NUM);
        WHEN VALUE_ERROR THEN
          RAISE_APPLICATION_ERROR(-20033,
                                  'Width problem/Incompatible data while retrieving Part tax code');
        WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20034,
                                  'Execution failed while retrieving Part tax code ' ||
                                  SQLERRM);
      END;
      BEGIN
        SELECT nvl(MRP_1, 0)
          INTO LN_MRP_1
          FROM PM_PART_VAR
         WHERE PARENT_GROUP = p_parent_group
           AND DEALER_MAP_CD = p_dealer_map_cd
           AND LOC_CD = p_loc_cd
           AND PART_NUM = p_part_num;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          LN_MRP_1 := 0;
          BEGIN

            SELECT nvl(MRP_1, 0)
              INTO LN_MRP_1
              FROM PM_PART
             WHERE DEALER_MAP_CD in (p_principal, p_dealer_map_cd)
               AND PART_NUM = p_part_num
               and PRINCIPAL_MAP_CD = P_PRINCIPAL; ---neha multi org changes
          EXCEPTION
            WHEN OTHERS THEN
              LN_MRP_1 := 0;
          END;
      END;

      IF pi_lst_yn = 'Y' THEN
        lv_taxtype := 'O';
      ELSE
        lv_taxtype := 'C';
      END IF;
      BEGIN
        BEGIN
          FOR K IN (SELECT a.charge_type,
                           a.charge_ind,
                           a.charge_value,
                           a.charge_cd,
                           b.common_ind,
                           b.order_srl
                      FROM am_charge a, pm_tax b
                     WHERE b.dealer_map_cd = p_dealer_map_cd
                       AND a.dealer_map_cd = b.dealer_map_cd
                       AND a.loc_cd = p_loc_cd
                       AND b.loc_cd = p_loc_cd
                       AND a.charge_type = b.charge_type
                       AND a.charge_cd = b.charge_cd
                       AND b.tax_type = 'S'
                       AND gst_state_cd=decode(pi_lst_yn,'Y',b.gst_state_cd,pi_cust_gst_state_cd)------Added against v_1.3
                       AND (b.common_ind = lv_taxtype)
                       AND b.part_tax_cd = LN_PTAX
                       AND b.parent_group = p_parent_group
                       AND a.CHARGE_TYPE NOT IN ('TCN','TCP','TCT')  ---added by Saurav on 30Jun2021 DMSSPR-13396
                     ORDER BY charge_srl) LOOP

           /*** ADDED BY SUMIT ON 29052019 FOR CESS ***/
            IF K.CHARGE_TYPE = 'CES' AND PI_CESS_FLAG = 'Y' THEN

           lv_os_factor := NVL(lv_os_factor, 0) + K.charge_value;
           ELSIF K.CHARGE_TYPE <> 'CES' THEN
           lv_os_factor := NVL(lv_os_factor, 0) + K.charge_value;
           end if;
           /***  ADDED BY SUMIT ON 29055019 ***/

          END LOOP;
        END;

        ln_os_sell_price := TRUNC((NVL(LN_MRP_1, 0) * 100) /
                                  (100 + NVL(lv_os_factor, 0)),
                                  2);

        ln_ls_sell_price := TRUNC((NVL(LN_MRP_1, 0) * 100) /
                                  (100 + NVL(lv_os_factor, 0)),
                                  2);

      END;
    END;
    --------------- end ---------

    IF UPPER(p_TAX_type) = 'P' THEN
      v_price := LN_PURCHASE_PRICE;
    ELSIF UPPER(p_TAX_type) = 'O' THEN
      v_price := LN_OS_SELL_PRICE;
    ELSIF UPPER(p_TAX_type) = 'L' THEN
      v_price := LN_LS_SELL_PRICE;
    ELSIF UPPER(p_TAX_type) = 'M' THEN
      v_price := LN_MRP_1;
    END IF;
  END IF;

  PO_PRICE  := V_PRICE;
  PO_TAX_CD := LN_PTAX;
END;

```

#### SP-074 - SP_GET_PHY_PART_DETAILS

**Invoked From:**

- pt_phy_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

COUNT DETAILS (N/A / CN_MAIN)

---

**Purpose**

Retrieves physical stock part details for a given store location and applies a configurable set of filter criteria (part range, bin range, category, classification indicators, price range, stock status, and active status) to populate an output PL/SQL table used by the Physical Count screen. The query is constructed dynamically to accommodate the optional filters and branches on the principal type to control whether local dealer parts are included or excluded.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| pi_principal | NUMBER | IN |
| pi_parent | VARCHAR2 | IN |
| pi_dealer | NUMBER | IN |
| pi_loc_cd | VARCHAR2 | IN |
| pi_comp_fa | VARCHAR2 | IN |
| pi_stores_cd | VARCHAR2 | IN |
| pi_from_part | VARCHAR2 | IN |
| pi_to_part | VARCHAR2 | IN |
| pi_from_bin | VARCHAR2 | IN |
| pi_to_bin | VARCHAR2 | IN |
| pi_catg_cd | VARCHAR2 | IN |
| pi_mcat_cd | VARCHAR2 | IN |
| pi_abc_ind | VARCHAR2 | IN |
| pi_fsn_ind | VARCHAR2 | IN |
| pi_xyz_ind | VARCHAR2 | IN |
| pi_lowest_value | NUMBER | IN |
| pi_highest_value | NUMBER | IN |
| pi_price_type | VARCHAR2 | IN |
| pi_stock_flag | VARCHAR2 | IN |
| pi_order_by | VARCHAR2 | IN |
| pi_active_yn | VARCHAR2 | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| po_tab_phy_part | Pk_Plsql_Table.t_phy_part | OUT |
| po_err_cd | NUMBER | OUT |
| po_err_msg | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Open a dynamic SQL cursor using DBMS_SQL.
- Step 2 - Evaluate pi_principal: if it equals 1 (principal-only mode), build the base SELECT joining PM_STOCK_BIN_LOC, PM_PART_VAR, and PM_PART with a strict principal filter on PM_PART (dealer_map_cd = principal AND principal_map_cd = principal), thereby excluding local dealer parts. If pi_principal is any other value, build an equivalent base SELECT that allows PM_PART rows belonging to either the dealer (dealer_map_cd = pi_dealer) or the principal (dealer_map_cd = pi_principal), while still requiring principal_map_cd = pi_principal.
- Step 3 - For each row returned, compute the available stock quantity as (ls_stock_qty + os_stock_qty - alloc_qty - ls_float_qty - os_float_qty - ws_resrv_qty), total stock as (ls_stock_qty + os_stock_qty), and float stock as (ls_float_qty + os_float_qty). Also retrieve bin location, part description, landed cost, all bin locations via Sf_Get_Store_Bin_Loc, and the decimal quantity flag.
- Step 4 - If both pi_from_part and pi_to_part are supplied, append a WHERE clause filtering PM_STOCK_BIN_LOC.part_num between the two values or matching a LIKE pattern on pi_to_part.
- Step 5 - If both pi_from_bin and pi_to_bin are supplied, append a WHERE clause filtering bin_loc between the two values.
- Step 6 - If pi_mcat_cd is supplied, append a filter on PM_PART.mcat_cd.
- Step 7 - If pi_catg_cd is supplied, append a filter on PM_PART.catg_cd.
- Step 8 - If pi_fsn_ind is supplied, append a filter on PM_PART_VAR.fsn_ind.
- Step 9 - If pi_xyz_ind is supplied, append a filter on PM_PART_VAR.xyz_ind.
- Step 10 - If pi_price_type is supplied, append a BETWEEN filter on the corresponding price column in PM_PART_VAR (purchase_price for 'P', ls_sell_price for 'L', os_sell_price for 'O', mrp_1 for 'M', landed_cost for 'LC') using pi_lowest_value and pi_highest_value as bounds.
- Step 11 - If pi_stock_flag is supplied, append a stock quantity filter: 'E' restricts to rows where ls_stock_qty + os_stock_qty = 0; 'G' restricts to rows where ls_stock_qty + os_stock_qty > 0.
- Step 12 - If pi_active_yn is supplied, append an active status filter on PM_STOCK_BIN_LOC.active_yn: 'A' returns only active records (active_yn = 'Y'); 'I' returns only inactive records (active_yn = 'N', treating NULL as 'N').
- Step 13 - If pi_order_by equals 1, append ORDER BY part_num; if it equals 2, append ORDER BY bin_loc.
- Step 14 - Parse the fully assembled SQL string, bind all mandatory variables (principal, parent_group, dealer, loc_cd, stores_cd, comp_fa) and conditionally bind optional variables corresponding to each active filter clause. The dealer1 bind variable is only bound when pi_principal = 2.
- Step 15 - Define all ten output columns and execute the cursor.
- Step 16 - Fetch rows in a loop; for each row, populate the corresponding index of po_tab_phy_part with part_num, part_desc, bin_loc, stock_qty, total_stock, float_stock, alloc_qty, landed_cost, all_bin_loc, and decimal_flag, incrementing the row counter after each assignment. Exit the loop when no more rows are available.
- Step 17 - Close the cursor and set po_err_cd to 0 to signal success.
- Step 18 - In the OTHERS exception handler, set po_err_cd to 1 and populate po_err_msg with the SQLERRM message.

---
**Decision Points**

DP-001

Condition:
pi_principal = 1

TRUE:
Build the base SQL with a strict principal-only filter on PM_PART (dealer_map_cd = :principal AND principal_map_cd = :principal), preventing local dealer parts from being fetched.

FALSE:
Build the base SQL with a combined dealer/principal filter on PM_PART (dealer_map_cd = :dealer1 OR dealer_map_cd = :principal AND principal_map_cd = :principal), allowing local dealer parts to be included.

---

DP-002

Condition:
pi_from_part IS NOT NULL AND pi_to_part IS NOT NULL

TRUE:
Append a part number range filter (BETWEEN pi_from_part AND pi_to_part, or LIKE pi_to_part||'%') to the SQL and bind both variables.

FALSE:
No part number range restriction is applied.

---

DP-003

Condition:
pi_from_bin IS NOT NULL AND pi_to_bin IS NOT NULL

TRUE:
Append a bin location range filter (BETWEEN pi_from_bin AND pi_to_bin) to the SQL and bind both variables.

FALSE:
No bin location range restriction is applied.

---

DP-004

Condition:
pi_mcat_cd IS NOT NULL

TRUE:
Append a filter on PM_PART.mcat_cd and bind the variable.

FALSE:
No major category restriction is applied.

---

DP-005

Condition:
pi_catg_cd IS NOT NULL

TRUE:
Append a filter on PM_PART.catg_cd and bind the variable.

FALSE:
No category restriction is applied.

---

DP-006

Condition:
pi_fsn_ind IS NOT NULL

TRUE:
Append a filter on PM_PART_VAR.fsn_ind and bind the variable.

FALSE:
No FSN classification restriction is applied.

---

DP-007

Condition:
pi_xyz_ind IS NOT NULL

TRUE:
Append a filter on PM_PART_VAR.xyz_ind and bind the variable.

FALSE:
No XYZ classification restriction is applied.

---

DP-008

Condition:
pi_price_type IS NOT NULL

TRUE:
Determine the target price column based on pi_price_type ('P' -> purchase_price, 'L' -> ls_sell_price, 'O' -> os_sell_price, 'M' -> mrp_1, 'LC' -> landed_cost), append a BETWEEN filter using pi_lowest_value and pi_highest_value, and bind both value variables.

FALSE:
No price range restriction is applied.

---

DP-009

Condition:
pi_stock_flag = 'E'

TRUE:
Append a filter restricting results to parts where ls_stock_qty + os_stock_qty = 0 (zero stock).

FALSE:
Evaluate DP-010 for the 'G' (greater-than-zero stock) case; if neither, no stock quantity restriction is applied.

---

DP-010

Condition:
pi_stock_flag = 'G'

TRUE:
Append a filter restricting results to parts where ls_stock_qty + os_stock_qty > 0 (positive stock).

FALSE:
No stock quantity restriction is applied.

---

DP-011

Condition:
pi_active_yn = 'A'

TRUE:
Append a filter where NVL(c.active_yn, 'N') = 'Y', returning only active bin-location stock records.

FALSE:
Evaluate DP-012 for the inactive case.

---

DP-012

Condition:
pi_active_yn = 'I'

TRUE:
Append a filter where NVL(c.active_yn, 'N') = 'N', returning only inactive bin-location stock records (including those with a NULL active_yn).

FALSE:
No active/inactive restriction is applied.

---

DP-013

Condition:
pi_order_by = 1

TRUE:
Append ORDER BY part_num to the SQL.

FALSE:
Evaluate DP-014.

---

DP-014

Condition:
pi_order_by = 2

TRUE:
Append ORDER BY bin_loc to the SQL.

FALSE:
No explicit ORDER BY clause is appended.

---

DP-015

Condition:
pi_principal = 2 (at bind-variable stage)

TRUE:
Bind the dealer1 variable with pi_dealer in addition to the standard binds.

FALSE:
dealer1 is not bound (it is not present in the principal = 1 SQL branch).

---

DP-016

Condition:
DBMS_SQL.fetch_rows returns more than 0 rows

TRUE:
Extract all ten column values and write them into the next index of po_tab_phy_part; increment the row counter and continue the loop.

FALSE:
Exit the fetch loop.

---
**Database Interactions**

- DB-001 - Read PM_STOCK_BIN_LOC - Reads data from PM_STOCK_BIN_LOC for lookup or validation.
**Business Rules**

- BR-001 - When pi_principal equals 1, only parts whose PM_PART.dealer_map_cd and PM_PART.principal_map_cd both equal pi_principal are eligible; local dealer-specific part records are excluded from physical count retrieval.
- BR-002 - When pi_principal is not 1, parts belonging to either the dealer (dealer_map_cd = pi_dealer) or the principal (dealer_map_cd = pi_principal) are eligible, provided principal_map_cd matches pi_principal, supporting multi-organisation scenarios.
- BR-003 - Available (net) stock quantity is derived as: ls_stock_qty + os_stock_qty - alloc_qty - ls_float_qty - os_float_qty - ws_resrv_qty. Reserved, allocated, and float quantities are all deducted from gross stock to reflect true available inventory.
- BR-004 - Total stock is the sum of local stock (ls_stock_qty) and outside stock (os_stock_qty), without deductions.
- BR-005 - Float stock is the sum of local float quantity (ls_float_qty) and outside float quantity (os_float_qty).
- BR-006 - A part number range filter is applied only when both pi_from_part and pi_to_part are provided; supplying only one boundary has no effect.
- BR-007 - A bin location range filter is applied only when both pi_from_bin and pi_to_bin are provided; supplying only one boundary has no effect.
- BR-008 - Price range filtering requires pi_price_type to be non-null; the selected price column must fall between pi_lowest_value and pi_highest_value. Valid price type codes are: 'P' (purchase price), 'L' (local sell price), 'O' (outside sell price), 'M' (MRP), and 'LC' (landed cost).
- BR-009 - Stock flag 'E' returns only zero-stock parts (ls_stock_qty + os_stock_qty = 0); stock flag 'G' returns only positive-stock parts (ls_stock_qty + os_stock_qty > 0). No other values are handled.
- BR-010 - Active status filter 'A' returns only records where active_yn = 'Y'; filter 'I' returns records where active_yn = 'N' or is NULL (treated as inactive via NVL default 'N').
- BR-011 - The allow_decimal_qty flag defaults to 'N' when the PM_PART column is NULL, ensuring a non-null decimal indicator is always returned to the caller.
- BR-012 - Results may be sorted by part number (pi_order_by = 1) or by bin location (pi_order_by = 2); any other value produces an unsorted result set.
- BR-013 - All filter predicates are additive (AND logic); each supplied filter further restricts the result set.
- BR-014 - On any unhandled exception, the procedure sets po_err_cd to 1 and returns the Oracle error message in po_err_msg, ensuring the caller can detect and report failures without an unhandled exception propagating to the form.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
Procedure Sp_Get_Phy_Part_Details (
      pi_principal       IN       NUMBER,
      pi_parent          IN       VARCHAR2,
      pi_dealer          IN       NUMBER,
      pi_loc_cd          IN       VARCHAR2,
      pi_comp_fa         IN       VARCHAR2,
      pi_stores_cd       IN       VARCHAR2,
      pi_from_part       IN       VARCHAR2,
      pi_to_part         IN       VARCHAR2,
      pi_from_bin        IN       VARCHAR2,
      pi_to_bin          IN       VARCHAR2,
      pi_catg_cd         IN       VARCHAR2,
      pi_mcat_cd         IN       VARCHAR2,
      pi_abc_ind         IN       VARCHAR2,
      pi_fsn_ind         IN       VARCHAR2,
      pi_xyz_ind         IN       VARCHAR2,
      pi_lowest_value    IN       NUMBER,
      pi_highest_value   IN       NUMBER,
      pi_price_type      IN       VARCHAR2,
      pi_stock_flag      IN       VARCHAR2,
      pi_order_by        IN       VARCHAR2,
    pi_active_yn     IN      VARCHAR2,
      po_tab_phy_part    OUT      Pk_Plsql_Table.t_phy_part,
      po_err_cd          OUT      NUMBER,
      po_err_msg         OUT      VARCHAR2
)
IS
      lv_sql             VARCHAR2 (4000);
      lv_cur_handle      INT;
      lv_row_processed   INT;
      lv_part_num        PM_PART.part_num%TYPE;
      lv_bin_loc         PM_STOCK_BIN_LOC.bin_loc%TYPE;
      lv_part_desc       PM_PART.part_desc%TYPE;
      lv_stock           PM_STOCK_BIN_LOC.ls_stock_qty%TYPE;
      lv_tot_stock       PM_STOCK_BIN_LOC.ls_stock_qty%TYPE;
      lv_float_stock     PM_STOCK_BIN_LOC.ls_stock_qty%TYPE;
      lv_alloc_qty       PM_STOCK_BIN_LOC.ls_stock_qty%TYPE;
      lv_landed_cost     PM_PART_VAR.landed_cost%TYPE;
      lv_all_bin         VARCHAR2 (4000);
      lv_decimal_flag    PM_PART.allow_decimal_qty%TYPE;
      lv_count           NUMBER                               := 1;
BEGIN
      lv_cur_handle := DBMS_SQL.open_cursor;
      IF pi_principal = 1 THEN --Condition added by arpan on 10-feb-15. SCR: DMSSPR-13096. Purpose:Local part fetch avoided.
          lv_sql :=
               'SELECT /*+ordered*/ a.part_num,
                       c.bin_loc bin_loc,
                       a.part_desc,
                       (  NVL ( c.ls_stock_qty, 0)
                        + NVL ( c.os_stock_qty, 0)
                        - NVL ( c.alloc_qty, 0)
                        - NVL ( c.ls_float_qty, 0)
                        - NVL ( c.os_float_qty, 0)
                        - NVL ( c.ws_resrv_qty, 0)
                       ) stock_qty,
                       NVL ( c.ls_stock_qty, 0) + NVL ( c.os_stock_qty, 0) total_stock,
                       NVL ( c.ls_float_qty, 0) + NVL ( c.os_float_qty, 0) float_stock,
                       NVL ( c.alloc_qty, 0) alloc_qty,
                       b.landed_cost,
                       Sf_Get_Store_Bin_Loc (b.parent_group, b.dealer_map_cd, b.loc_cd, a.part_num, c.stores_cd) all_bin_loc,
                       NVL(a.ALLOW_DECIMAL_QTY,''N'')
                  FROM PM_STOCK_BIN_LOC c, PM_PART_VAR b,PM_PART a
                 WHERE c.parent_group = :parent_group
                   AND c.dealer_map_cd = :dealer2
                   AND c.loc_cd = :loc_cd
                   AND c.comp_fa = :comp_fa
                   AND c.stores_cd = :stores_cd
                   AND b.parent_group = c.parent_group
                   AND b.dealer_map_cd = c.dealer_map_cd
                   AND b.loc_cd = c.loc_cd
                   AND b.part_num = c.part_num
                   AND a.dealer_map_cd = :principal
                   AND a.principal_map_cd=:principal
                   AND a.part_num = b.part_num';
      ELSE
           lv_sql :=
               'SELECT /*+ordered*/ a.part_num,
                       c.bin_loc bin_loc,
                       a.part_desc,
                       (  NVL ( c.ls_stock_qty, 0)
                        + NVL ( c.os_stock_qty, 0)
                        - NVL ( c.alloc_qty, 0)
                        - NVL ( c.ls_float_qty, 0)
                        - NVL ( c.os_float_qty, 0)
                        - NVL ( c.ws_resrv_qty, 0)
                       ) stock_qty,
                       NVL ( c.ls_stock_qty, 0) + NVL ( c.os_stock_qty, 0) total_stock,
                       NVL ( c.ls_float_qty, 0) + NVL ( c.os_float_qty, 0) float_stock,
                       NVL ( c.alloc_qty, 0) alloc_qty,
                       b.landed_cost,
                       Sf_Get_Store_Bin_Loc (b.parent_group, b.dealer_map_cd, b.loc_cd, a.part_num, c.stores_cd) all_bin_loc,
                       NVL(a.ALLOW_DECIMAL_QTY,''N'')
                  FROM PM_STOCK_BIN_LOC c, PM_PART_VAR b,PM_PART a
                 WHERE c.parent_group = :parent_group
                   AND c.dealer_map_cd = :dealer2
                   AND c.loc_cd = :loc_cd
                   AND c.comp_fa = :comp_fa
                   AND c.stores_cd = :stores_cd
                   AND b.parent_group = c.parent_group
                   AND b.dealer_map_cd = c.dealer_map_cd
                   AND b.loc_cd = c.loc_cd
                   AND b.part_num = c.part_num
                   AND (a.dealer_map_cd = :dealer1 OR a.dealer_map_cd = :principal)
                   AND  a.principal_map_cd=:principal
                   AND a.part_num = b.part_num';
         END IF;
 /*Changed by Dp Swain for multi org*/
      IF pi_from_part IS NOT NULL AND pi_to_part IS NOT NULL THEN
            lv_sql := lv_sql || ' AND ((c.part_num BETWEEN :from_part AND :to_part) OR C.PART_NUM LIKE :to_part||''%'') ';
      END IF;

      IF pi_from_bin IS NOT NULL AND pi_to_bin IS NOT NULL THEN
            lv_sql := lv_sql || ' AND c.bin_loc BETWEEN :bin_loc_from AND :bin_loc_to ';
      END IF;

      IF pi_mcat_cd IS NOT NULL THEN
            lv_sql := lv_sql || ' AND a.mcat_cd = :mcat_cd ';
      END IF;

      IF pi_catg_cd IS NOT NULL THEN
            lv_sql := lv_sql || ' AND a.catg_cd = :catg_cd ';
      END IF;

      IF pi_fsn_ind IS NOT NULL THEN
            lv_sql := lv_sql || ' AND b.fsn_ind= :fsn_ind ';
      END IF;

      IF pi_xyz_ind IS NOT NULL THEN
            lv_sql := lv_sql || ' AND b.xyz_ind= :xyz_ind ';
      END IF;

      IF pi_xyz_ind IS NOT NULL THEN
            lv_sql := lv_sql || ' AND b.xyz_ind= :xyz_ind ';
      END IF;

      IF pi_price_type IS NOT NULL THEN
            IF pi_price_type = 'P' THEN
                  lv_sql := lv_sql || ' AND b.purchase_price ';
            ELSIF pi_price_type = 'L' THEN
                  lv_sql := lv_sql || ' AND b.ls_sell_price ';
            ELSIF pi_price_type = 'O' THEN
                  lv_sql := lv_sql || ' AND b.os_sell_price ';
            ELSIF pi_price_type = 'M' THEN
                  lv_sql := lv_sql || ' AND b.mrp_1 ';
            ELSIF pi_price_type = 'LC' THEN
                  lv_sql := lv_sql || ' AND b.landed_cost ';
            END IF;

            lv_sql := lv_sql || ' between :lowest_value and :highest_value ';
      END IF;

      IF pi_stock_flag IS NOT NULL THEN
            IF pi_stock_flag = 'E' THEN
                  /*
                          lv_sql :=
                           lv_sql
                        || 'AND (  NVL ( c.ls_stock_qty, 0)
                                + NVL ( c.os_stock_qty, 0)
                                - NVL ( c.alloc_qty, 0)
                                - NVL ( c.ls_float_qty, 0)
                                - NVL ( c.os_float_qty, 0)
                                - NVL ( c.ws_resrv_qty, 0)
                               )  = 0 ';
                  */
                  lv_sql := lv_sql || 'AND (  NVL ( c.ls_stock_qty, 0) + NVL ( c.os_stock_qty, 0) = 0 )';
            ELSIF pi_stock_flag = 'G' THEN
                  /*
                          lv_sql :=
                           lv_sql
                        || 'AND (  NVL ( c.ls_stock_qty, 0)
                                + NVL ( c.os_stock_qty, 0)
                                - NVL ( c.alloc_qty, 0)
                                - NVL ( c.ls_float_qty, 0)
                                - NVL ( c.os_float_qty, 0)
                                - NVL ( c.ws_resrv_qty, 0)
                               )  > 0 ';
                  */
                  lv_sql := lv_sql || 'AND (  NVL ( c.ls_stock_qty, 0) + NVL ( c.os_stock_qty, 0) > 0 )';
            END IF;
      END IF;

   IF pi_active_yn IS NOT NULL THEN ---GURU
            IF pi_active_yn = 'A' THEN

                  lv_sql := lv_sql || 'AND (  NVL (c.active_yn, ''N'') = ''Y'' )';
            ELSIF pi_active_yn = 'I' THEN

                  lv_sql := lv_sql || 'AND (  NVL (c.active_yn, ''N'') = ''N'' )';
            END IF;
      END IF;

      IF pi_order_by = 1 THEN
            lv_sql := lv_sql || ' order by a.part_num ';
      ELSIF pi_order_by = 2 THEN
            lv_sql := lv_sql || ' order by C.bin_loc ';
      END IF;

      --dbms_output.put_line(lv_sql);
      DBMS_SQL.parse (lv_cur_handle, lv_sql, DBMS_SQL.native);
      IF pi_principal = 2 THEN --Added by Arpan on 10-feb-15. SCR: DMSSPR-13096
         DBMS_SQL.bind_variable (lv_cur_handle, 'dealer1', pi_dealer);
      END IF;
      DBMS_SQL.bind_variable (lv_cur_handle, 'principal', pi_principal);
      DBMS_SQL.bind_variable (lv_cur_handle, 'parent_group', pi_parent);
      DBMS_SQL.bind_variable (lv_cur_handle, 'dealer2', pi_dealer);
      DBMS_SQL.bind_variable (lv_cur_handle, 'loc_cd', pi_loc_cd);
      DBMS_SQL.bind_variable (lv_cur_handle, 'stores_cd', pi_stores_cd);
      DBMS_SQL.bind_variable (lv_cur_handle, 'comp_fa', pi_comp_fa);

      IF pi_from_part IS NOT NULL AND pi_to_part IS NOT NULL THEN
            DBMS_SQL.bind_variable (lv_cur_handle, 'from_part', pi_from_part);
            DBMS_SQL.bind_variable (lv_cur_handle, 'to_part', pi_to_part);
      END IF;

      IF pi_from_bin IS NOT NULL AND pi_to_bin IS NOT NULL THEN
            DBMS_SQL.bind_variable (lv_cur_handle, 'bin_loc_from', pi_from_bin);
            DBMS_SQL.bind_variable (lv_cur_handle, 'bin_loc_to', pi_to_bin);
      END IF;

      IF pi_mcat_cd IS NOT NULL THEN
            DBMS_SQL.bind_variable (lv_cur_handle, 'mcat_cd', pi_mcat_cd);
      END IF;

      IF pi_catg_cd IS NOT NULL THEN
            DBMS_SQL.bind_variable (lv_cur_handle, 'catg_cd', pi_catg_cd);
      END IF;

      IF pi_abc_ind IS NOT NULL THEN
            DBMS_SQL.bind_variable (lv_cur_handle, 'abc_ind', pi_abc_ind);
      END IF;

      IF pi_fsn_ind IS NOT NULL THEN
            DBMS_SQL.bind_variable (lv_cur_handle, 'fsn_ind', pi_fsn_ind);
      END IF;

      IF pi_xyz_ind IS NOT NULL THEN
            DBMS_SQL.bind_variable (lv_cur_handle, 'xyz_ind', pi_xyz_ind);
      END IF;

      IF pi_price_type IS NOT NULL THEN
            DBMS_SQL.bind_variable (lv_cur_handle, 'lowest_value', pi_lowest_value);
            DBMS_SQL.bind_variable (lv_cur_handle, 'highest_value', pi_highest_value);
      END IF;

      --DBMS_SQL.bind_variable (lv_cur_handle, 'order_by', pi_order_by);
      DBMS_SQL.define_column (lv_cur_handle, 1, lv_part_num, 15);
      DBMS_SQL.define_column (lv_cur_handle, 2, lv_bin_loc, 10);
      DBMS_SQL.define_column (lv_cur_handle, 3, lv_part_desc, 200);
      DBMS_SQL.define_column (lv_cur_handle, 4, lv_stock);
      DBMS_SQL.define_column (lv_cur_handle, 5, lv_tot_stock);
      DBMS_SQL.define_column (lv_cur_handle, 6, lv_float_stock);
      DBMS_SQL.define_column (lv_cur_handle, 7, lv_alloc_qty);
      DBMS_SQL.define_column (lv_cur_handle, 8, lv_landed_cost);
      DBMS_SQL.define_column (lv_cur_handle, 9, lv_all_bin, 4000);
      DBMS_SQL.define_column (lv_cur_handle, 10, lv_decimal_flag, 1);
      lv_row_processed := DBMS_SQL.EXECUTE (lv_cur_handle);

      LOOP
            -- Fetch a row
            IF DBMS_SQL.fetch_rows (lv_cur_handle) > 0 THEN
                  -- Fetch columns from the row
                  DBMS_SQL.column_value (lv_cur_handle, 1, lv_part_num);
                  DBMS_SQL.column_value (lv_cur_handle, 2, lv_bin_loc);
                  DBMS_SQL.column_value (lv_cur_handle, 3, lv_part_desc);
                  DBMS_SQL.column_value (lv_cur_handle, 4, lv_stock);
                  DBMS_SQL.column_value (lv_cur_handle, 5, lv_tot_stock);
                  DBMS_SQL.column_value (lv_cur_handle, 6, lv_float_stock);
                  DBMS_SQL.column_value (lv_cur_handle, 7, lv_alloc_qty);
                  DBMS_SQL.column_value (lv_cur_handle, 8, lv_landed_cost);
                  DBMS_SQL.column_value (lv_cur_handle, 9, lv_all_bin);
                  DBMS_SQL.column_value (lv_cur_handle, 10, lv_decimal_flag);
                  po_tab_phy_part (lv_count).part_num := lv_part_num;
                  po_tab_phy_part (lv_count).part_desc := lv_part_desc;
                  po_tab_phy_part (lv_count).bin_loc := lv_bin_loc;
                  po_tab_phy_part (lv_count).stock_qty := lv_stock;
                  po_tab_phy_part (lv_count).total_stock := lv_tot_stock;
                  po_tab_phy_part (lv_count).float_stock := lv_float_stock;
                  po_tab_phy_part (lv_count).alloc_qty := lv_alloc_qty;
                  po_tab_phy_part (lv_count).landed_cost := lv_landed_cost;
                  po_tab_phy_part (lv_count).all_bin_loc := lv_all_bin;
                  po_tab_phy_part (lv_count).decimal_flag := lv_decimal_flag;
                  lv_count := lv_count + 1;
            ELSE
                  EXIT;
            END IF;
      END LOOP;

      DBMS_SQL.close_cursor (lv_cur_handle);
      po_err_cd := 0;
EXCEPTION
      WHEN OTHERS THEN
            po_err_cd := 1;
            po_err_msg := 'Error : ' || SQLERRM;
END;

```

#### SP-075 - STRIPDIRSEP

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sanitises a raw directory path string by removing any semicolon-delimited suffix (retaining only the segment before the first semicolon) and stripping a trailing backslash separator, returning a clean, normalised path value for use by callers such as ATTEMPT_DLL_LOAD, GET_TEMP_DIRECTORY, and GET_WINDOWS_DIRECTORY.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| InPath | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-045](#SP-045--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Initialise a local working variable (vcPath) with the value supplied in the InPath input parameter.
- Step 2 - Search the working path for the presence of a semicolon character using INSTR.
- Step 3 - If a semicolon is found, truncate the working path to retain only the substring preceding the first semicolon, discarding everything from the semicolon onward.
- Step 4 - Inspect the last character of the (potentially truncated) working path to determine whether it is a backslash ('\').
- Step 5 - If a trailing backslash is present, remove it by taking the substring from position 1 to one character less than the total length of the working path.
- Step 6 - Return the sanitised path string to the caller.

---
**Decision Points**

DP-001

Condition: INSTR(vcPath, ';') > 0 - the working path contains at least one semicolon character.

TRUE: Truncate vcPath to the substring from position 1 up to (but not including) the first semicolon, discarding all characters from the semicolon onward.

FALSE: Leave vcPath unchanged and proceed to the trailing-separator check.

---

DP-002

Condition: SUBSTR(vcPath, -1, 1) = '\' - the last character of the (possibly truncated) working path is a backslash directory separator.

TRUE: Remove the trailing backslash by reassigning vcPath to the substring from position 1 to LENGTH(vcPath) - 1.

FALSE: Leave vcPath unchanged and return it as-is.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only the portion of a path that precedes the first semicolon is considered a valid directory path; any semicolon and subsequent content are discarded.
- BR-002 - A valid normalised directory path must not end with a backslash ('\'); if one is present it must be stripped before the path is returned to the caller.
- BR-003 - Both sanitisation rules (semicolon truncation and trailing backslash removal) are applied sequentially to the same working value, meaning a path that contains both a semicolon and a trailing backslash will have both issues resolved in a single invocation.
- BR-004 - The function is non-destructive with respect to the original InPath argument; all modifications are applied to a local copy, preserving the caller's input value.

---
**Implementation Logic**

```plsql

  

Function StripDirSep ( InPath in varchar2) return varchar2 is 
  vcPath  varchar2(500) := InPath;
begin 
  -- Check and Strip SemiColons, we take everything
  -- Before the first Semicolon as our path
  if instr(vcPath,';') > 0 then
    vcPath := substr(vcPath,1,instr(vcPath,';') -1);
  end if;

  -- Check and Strip '\'
  if substr(vcPath,-1,1) = '\' then 
    vcPath := substr(vcPath,1,length(vcPath)-1);
  end if;

  return vcPath;
end StripDirSep;
```

#### SP-076 - VIEW_EXCEL_REPORT_NEW

**Invoked From:**

- pt_phy_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

N/A

---

**Purpose**

Generates and delivers a CSV/Excel report to the client workstation when a button is pressed on the physical screen (pt_phy_fmb). The procedure supports two execution paths: (1) a server-side CSV generation path, used when a report-server mapping exists in EH_REPORTS for the given principal and application, and (2) a client-side Oracle Forms RecordGroup path, used when no such mapping exists. In both cases the resulting file is transferred to the client via WebUtil and opened automatically on the user's desktop.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_principal | number | IN |
| p_file_name | VARCHAR2 | IN |
| p_query | VARCHAR2 | IN |
| p_column_name | VARCHAR2 | IN |
| p_app_id | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.FCLOSE ([SP-036](#SP-036--WEBUTIL.FCLOSE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.FOPEN ([SP-038](#SP-038--WEBUTIL.FOPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_LINE ([SP-041](#SP-041--WEBUTIL.GET_LINE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.HOST ([SP-043](#SP-043--WEBUTIL.HOST)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ID_NULL ([SP-044](#SP-044--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.PUTF ([SP-046](#SP-046--WEBUTIL.PUTF)) - WEBUTIL.pck (or .pld)
- WEBUTIL.URL_TO_CLIENT ([SP-051](#SP-051--WEBUTIL.URL_TO_CLIENT)) - WEBUTIL.pck (or .pld)
- WEBUTIL_FILE.FILE_SAVE_DIALOG ([SP-053](#SP-053--WEBUTIL_FILE.FILE_SAVE_DIALOG)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Look up the report server (rep_server) from EH_REPORTS where the row matches both p_principal and p_app_id; if no row is found, lv_rep_server is set to NULL and processing continues on the alternative path.
- Step 2 - Determine the output file name: if p_file_name is NULL, invoke WEBUTIL_FILE.FILE_SAVE_DIALOG to prompt the user for a save location; otherwise use p_file_name directly.
- Step 3 - Append the '.csv' extension to the resolved file name.
- Step 4 - Validate the file path for embedded spaces; if any folder in the path contains a space, redirect the file to 'C:\' using only the bare file name and display an informational message to the user.
- Step 5 (Server-path branch - lv_rep_server IS NOT NULL) - Call the remote procedure sp_csv_report_generate via the database link dms1_db3_lnk, passing the file name and query, to generate the CSV file on the server.
- Step 6 (Server-path branch) - Execute a Unix shell command via WEBUTIL.HOST to move the generated file from /utl_dir/ to /iashome/ias/reports/printer/.
- Step 7 (Both branches) - Read the base URL path from the configuration file /reports/DMS/excelpath.txt using WEBUTIL.FOPEN and WEBUTIL.GET_LINE, then close the file with WEBUTIL.FCLOSE; concatenate the URL with the bare file name to form the full server URL (formserverpath).
- Step 8 (Client-path branch - lv_rep_server IS NULL) - Check whether a RecordGroup named 'DataRecordSet' already exists using WEBUTIL.ID_NULL; if it does, delete it before creating a fresh group.
- Step 9 (Client-path branch) - Create a RecordGroup from p_query using Create_Group_From_Query, populate it with Populate_Group, and retrieve the row count with Get_Group_Row_Count.
- Step 10 (Client-path branch) - Open a server-side file at /iashome/ias/reports/printer/ for writing using WEBUTIL.FOPEN, locate the target column in the RecordGroup with Find_Column, iterate over all rows, write each cell value followed by a newline character using WEBUTIL.PUTF, then close the file with WEBUTIL.FCLOSE.
- Step 11 (Both branches) - Transfer the file from the form server to the client machine using WEBUTIL.URL_TO_CLIENT; if the transfer fails, display a 'File Transfer failed' message and pause.
- Step 12 (Both branches) - Open the transferred file on the client desktop by issuing a 'cmd /c <filename>' command via WEBUTIL.HOST.
- Step 13 - On any unhandled exception, display an error message combining ERROR_CODE and ERROR_TEXT, then raise Form_Trigger_Failure to halt form processing.

---
**Decision Points**

DP-001

Condition: lv_rep_server IS NOT NULL (a rep_server value was found in EH_REPORTS for the supplied p_principal and p_app_id).

TRUE: Use the server-side path - call sp_csv_report_generate via database link to produce the CSV, move the file with a Unix host command, read the URL base path, transfer the file to the client, and open it.

FALSE: Use the client-side RecordGroup path - build the CSV locally within Oracle Forms using a RecordGroup populated from p_query, write the output file to the server directory, transfer it to the client, and open it.

---

DP-002

Condition: p_file_name IS NULL.

TRUE: Invoke WEBUTIL_FILE.FILE_SAVE_DIALOG to prompt the user to choose a file save location and name.

FALSE: Use p_file_name as the output file name directly.

---

DP-003

Condition: INSTR(FILENAME, ' ') > 0 (the resolved file path contains at least one space character in a folder name).

TRUE: Override the file path to 'C:\' concatenated with the bare file name only, and display a warning message informing the user that the file will be stored on the C drive.

FALSE: Retain the original resolved file path without modification.

---

DP-004

Condition: NOT Id_Null(rg_id) - a RecordGroup named 'DataRecordSet' already exists in memory (client-path branch only).

TRUE: Delete the existing RecordGroup before creating a new one to avoid conflicts.

FALSE: Proceed directly to creating the RecordGroup from the query.

---

DP-005

Condition: file_transfer_bool is FALSE after calling WEBUTIL.URL_TO_CLIENT.

TRUE: Display a 'File Transfer failed' message and pause execution to alert the user.

FALSE: Continue to open the file on the client desktop via WEBUTIL.HOST.

---
**Database Interactions**

- DB-001 - Read EH_REPORTS - Reads data from EH_REPORTS for lookup or validation.
**Business Rules**

- BR-001 - The report-server execution path is only available when EH_REPORTS contains a row matching both the supplied principal (p_principal) and application identifier (p_app_id); absence of such a row unconditionally routes processing to the RecordGroup-based path.
- BR-002 - The output file name must always carry a '.csv' extension; the extension is appended programmatically regardless of the value provided in p_file_name or selected via the save dialog.
- BR-003 - File paths containing spaces in any folder name are not permitted; the procedure automatically redirects the output to the root of the C drive ('C:\') and notifies the user, ensuring the file can be processed without path-resolution errors.
- BR-004 - The base URL used to construct the server-to-client transfer path is not hard-coded; it is read at runtime from the configuration file /reports/DMS/excelpath.txt, allowing the server URL to be updated without a code change.
- BR-005 - In the client-path branch, only a single RecordGroup named 'DataRecordSet' may exist at one time; any pre-existing group with that name is deleted before a new one is created from p_query.
- BR-006 - Successful file transfer to the client is mandatory; if WEBUTIL.URL_TO_CLIENT returns FALSE, the user is explicitly notified and processing is paused rather than silently continuing.
- BR-007 - After a successful transfer, the file is automatically launched on the client desktop using a Windows shell command ('cmd /c'), removing the need for the user to manually locate and open the file.
- BR-008 - Any unhandled runtime exception must surface a descriptive error message (ERROR_CODE + ERROR_TEXT) to the user and terminate the current form trigger via Form_Trigger_Failure, preventing silent failures.

---
**Implementation Logic**

```plsql
PROCEDURE view_excel_report_new(p_principal number,p_file_name VARCHAR2, p_query VARCHAR2,p_column_name VARCHAR2,p_app_id VARCHAR2) IS
	rg_name 				 		VARCHAR2(40) := 'DataRecordSet'; 
	rg_id 					 		RecordGroup; 
	gc_id 					 		GroupColumn; 
	errcode 				 		NUMBER; 
	the_rowcount 		 		NUMBER; 
  FILENAME			   		VARCHAR2(4000);
  MYFILE 					 		TEXT_IO.FILE_TYPE;
  urlFile 					 	TEXT_IO.FILE_TYPE;
  urlPath							VARCHAR2(5000);
	V_STRING 				 		VARCHAR2(4000);
	l_alert 				 		NUMBER;
	server_file      		VARCHAR2(2000);
	file_transfer_bool	BOOLEAN;
	formserverpath   		VARCHAR2(2000);
	lv_err_reas			varchar2(2000);
	lv_cmd	varchar2(1000);
	lv_rep_server	varchar2(50);

begin
			begin
				select rep_server into lv_rep_server from eh_reports
				where principal_map_cd=p_principal
				and   app_id=p_app_id;
			exception
				when others then
				 lv_rep_server:=null;
			end;	

if lv_rep_server is not null then
		
			If p_file_name is null then
				FILENAME  := Webutil_file.FILE_SAVE_DIALOG;
			Else
			  FILENAME := p_file_name;
			End If;
  
  		FILENAME:=p_file_name||'.csv';
  
			 	If instr(FILENAME,' ') > 0 then
			 		FILENAME := 'C:\'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
			 		Message('File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default.');
			 		message('  ');
			 	end if;
 	
			sp_csv_report_generate@dms1_db3_lnk(FILENAME,p_query,errcode,lv_err_reas);
			
			host('/bin/mv /utl_dir/'||FILENAME||' /iashome/ias/reports/printer/'||FILENAME);
			
			server_file := '/iashome/ias/reports/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	
			urlFile := Text_Io.Fopen('/reports/DMS/excelpath.txt','R');
			Text_Io.Get_Line(urlFile,urlPath);
			Text_Io.Fclose(urlFile);
			formserverpath := urlPath||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);

 		file_transfer_bool := WebUtil_File_Transfer.Url_To_Client(formserverpath,FILENAME);
	 	
	 	if not file_transfer_bool  then 
	 		message('File Transfer failed');pause;
	 	end if;
	 	
	WebUtil_Host.HOST('cmd /c '||FILENAME);
	
else
  If p_file_name is null then
		FILENAME  := Webutil_file.FILE_SAVE_DIALOG;
  Else
    FILENAME := p_file_name;
  End If;
 	If instr(FILENAME,' ') > 0 then
 		FILENAME := 'C:\'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
 		Message('File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default.');
 		message('  ');
 	end if;
	rg_id := Find_Group( rg_name ); 
	IF NOT Id_Null(rg_id) THEN 
		Delete_Group( rg_id ); 
	END IF; 
	rg_id := Create_Group_From_Query( rg_name, p_query ); 
	errcode := Populate_Group( rg_id ); 
	the_rowcount := Get_Group_Row_Count( rg_id );
	server_file := '/iashome/ias/reports/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	urlFile := Text_Io.Fopen('/reports/DMS/excelpath.txt','R');
	Text_Io.Get_Line(urlFile,urlPath);
	Text_Io.Fclose(urlFile);
	formserverpath := urlPath||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	MYFILE := TEXT_IO.FOPEN(server_file, 'W');
	gc_id := Find_Column( rg_name||'.'||p_column_name); 	
	for total_loop IN 1..the_rowcount
		loop
	  	V_STRING :=  GET_GROUP_CHAR_CELL(gc_id  , total_loop )||CHR(10); 
	  	TEXT_IO.PUTF(MYFILE,V_STRING);  
		end loop;
	 	TEXT_IO.FCLOSE(MYFILE);
	 	file_transfer_bool := WebUtil_File_Transfer.Url_To_Client(formserverpath,FILENAME);
	 	if not file_transfer_bool  then 
	 		message('File Transfer failed');pause;
	 	end if;
	 	WebUtil_Host.HOST('cmd /c '||FILENAME);	 		
	 		
end if;

exception
	when others then
	Message('Error  - '||ERROR_CODE|| ERROR_TEXT);
	Raise Form_trigger_failure;
end;
```

#### SP-077 - WINDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WINDEBUG provides a debug string output facility by delegating to the external D2KWUTIL debug string function via the WIN_API framework. It accepts a text string, appends a newline character, registers the target external function call, and dispatches the formatted string to the D2KWUTIL debug output channel. If the WIN_API layer is unavailable or any other error occurs, the procedure captures and surfaces a structured error message before re-raising the exception.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-054](#SP-054--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-055](#SP-055--ADD_EXTERNAL_ERRORS)) - matched by member name
- D2KWUTIL.D2KWUTIL_DEBUGSTRING ([SP-012](#SP-012--D2KWUTIL.D2KWUTIL_DEBUGSTRING)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- REGISTER_FUNCTION_CALL ([SP-061](#SP-061--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input text string and initialise a local buffer (vcBuff1) by appending a newline character (CHR(10)) to the input value.
- Step 2 - Evaluate whether the WIN_API layer is currently enabled by checking WIN_API.API_ENABLED.
- Step 3 - If the API is enabled, register the external function call by invoking REGISTER_FUNCTION_CALL with the debug string handle (iDebugString), the function name 'd2kwutil_DebugString', NULL as the instance reference, and '*CHAR' as the parameter type descriptor.
- Step 4 - Invoke D2KWUTIL.D2KWUTIL_DEBUGSTRING, passing the resolved function handle (WIN_API.FunctionHandle(iDebugString)) and the formatted buffer (vcBuff1), to dispatch the debug string to the external debug output channel.
- Step 5 - If the API is not enabled, raise the WIN_API.NOT_AVAILABLE exception to signal that the debug facility cannot be used in the current environment.
- Step 6 - On a WIN_API.NOT_AVAILABLE exception, call ADD_ERROR with the procedure identifier 'WinDebug' and the WIN_API.NoAPI error code to record the unavailability error, then re-raise the exception.
- Step 7 - On any other exception, call ADD_ERROR with the procedure identifier 'WinDebug' and a concatenation of WIN_API.UError and the result of ADD_EXTERNAL_ERRORS to capture the full error detail, then re-raise the exception.

---
**Decision Points**

DP-001

Condition:
WIN_API.API_ENABLED evaluates to TRUE.

TRUE:
Register the external debug string function via REGISTER_FUNCTION_CALL and dispatch the formatted text buffer to the debug output channel via D2KWUTIL.D2KWUTIL_DEBUGSTRING.

FALSE:
Raise WIN_API.NOT_AVAILABLE to indicate that the WIN_API framework is not accessible in the current runtime environment.

---

DP-002

Condition:
The exception raised is WIN_API.NOT_AVAILABLE.

TRUE:
Call ADD_ERROR with the 'WinDebug' identifier and the WIN_API.NoAPI error code, then re-raise the exception.

FALSE (OTHERS):
Call ADD_ERROR with the 'WinDebug' identifier and a composite error message formed by concatenating WIN_API.UError with the output of ADD_EXTERNAL_ERRORS, then re-raise the exception.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The input text string must always be suffixed with a newline character (CHR(10)) before being passed to the external debug function; the raw input value is never dispatched directly.
- BR-002 - Debug string output is only permitted when the WIN_API framework is active (WIN_API.API_ENABLED = TRUE); any attempt to invoke the debug facility when the framework is unavailable is treated as an error condition.
- BR-003 - The external debug function must be formally registered via REGISTER_FUNCTION_CALL before it is invoked; the registration must specify the function name 'd2kwutil_DebugString' and the parameter type '*CHAR'.
- BR-004 - All exceptions must be re-raised after error recording, ensuring that callers are always notified of failures rather than silently suppressing them.
- BR-005 - API unavailability errors are recorded using ADD_ERROR with the WIN_API.NoAPI code, while all other runtime errors are recorded using ADD_ERROR with a composite message that includes ADD_EXTERNAL_ERRORS output to capture any externally accumulated error detail.

---
**Implementation Logic**

```plsql
  

  
PROCEDURE WinDebug  (  Text  IN   VARCHAR2) is
  vcBuff1 VARCHAR2(2000) := Text||chr(10);
begin 
  --WIN_API.Clean_Error_Stack;
  if Win_API.API_ENABLED then
    win_api.Register_function_call(iDebugString,'d2kwutil_DebugString',NULL,'*CHAR');
    d2kwutil_DebugString(win_api.FunctionHandle(iDebugString),vcBuff1);
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if; 
exception
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('WinDebug',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('WinDebug',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end WinDebug;
```

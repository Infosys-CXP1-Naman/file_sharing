# BUSINESS REQUIREMENTS DOCUMENT

## Table of Contents

- 1. Document Control
  - 1.1 Document Information
  - 1.2 Revision History
- 2. Executive Summary
  - Key Stakeholders
- 3. System Context
- 4. Functional Requirements
  - 4.1 Business Requirements
    - Requirement ID: BR-001
    - Requirement ID: BR-002
    - Requirement ID: BR-003
    - Requirement ID: BR-004
    - Requirement ID: BR-005
    - Requirement ID: BR-006
    - Requirement ID: BR-007
    - Requirement ID: BR-008
    - Requirement ID: BR-009
    - Business Scenarios - How dependent field availability differs by Report Type
    - Requirement ID: BR-010
    - Business Scenarios - How the report query differs by Report Type and Based On category
    - Requirement ID: BR-011
    - Requirement ID: BR-012
    - Requirement ID: BR-013
    - Requirement ID: BR-014
    - Requirement ID: BR-015
    - Requirement ID: BR-016
    - Requirement ID: BR-017
- 5. Business Rules Catalogue
- 6. Data Requirements
  - 6.1 Business Entities and Relationships
    - Dealer Location and Company - AM_DEALER_LOC / AM_DEALER_LOC_COMPANY_MASTER
    - Sales Order Header and Detail - PH_SO / PD_SO
    - Repair Order and Parts Requirement - VH_RO / VT_REQ
    - Parts Catalogue - PM_PART / PM_PART_VAR
    - Geographic and Reference Data - GM_CITY / GM_STATE / AM_LIST
    - Entity Relationships
  - 6.2 Data Capture Requirements
    - Report Filter Criteria (entered by the report user before generating a report)
    - Session and Internal Parameters
  - 6.3 Reference Data
  - 6.4 Data Lifecycle
  - 6.5 Excel Output Columns
- 7. Glossary
- 8. Technical Inventory
  - 8.1 Form Architecture
    - 8.1.1 Global Variables
    - 8.1.2 Form Parameters
  - 8.2 Blocks
    - 8.2.1 Block WhereClause and OrderByClause
  - 8.3 Items Summary
  - 8.4 List of Values
  - 8.5 Alerts
  - 8.6 Program Units
  - 8.7 Triggers
    - 8.7.1 Inactive / Commented-Out Trigger Register
  - 8.8 Canvas and Window Inventory
  - 8.9 Editors
  - 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups
    - 8.10.1 Visual Attributes (form-defined)
    - 8.10.2 Property Classes (form-defined)
    - 8.10.3 Object Groups
  - 8.11 DataSourceColumn Inventory
- 9. Object Library
- 10. Record Groups
- 11. Referenced Database Objects
  - 11.1 Block-Table Binding Summary
  - 11.2 Database Object References
- 12. Backend Procedures and Packages
  - 12.1 Main Flow Backend Procedure/Package Index
  - 12.2 Procedure and Package Catalogue
- 13. Package Procedure Specifications
- 14. Database Package Catalogue
- 15. PLD Procedure Call Sites
  - DPL.pld (`general`)
  - Inactive / commented-only PLD call sites
  - webutil.pld (`WEBUTIL_C_API`)
  - webutil.pld (`WEBUTIL_FILE`)
  - Inactive / commented-only PLD call sites
  - webutil.pld (`WEBUTIL_FILE_TRANSFER`)
  - Inactive / commented-only PLD call sites
  - webutil.pld (`WEBUTIL_HOST`)
  - Inactive / commented-only PLD call sites
- 16. Microservice API Candidates
  - 16.1 Microservices with APIs
- 17. Workflows
- 18. PLD-Backed Logic
  - webutil.pld (`CLIENT_IMAGE`)
  - DPL.pld (`general`)
  - D2kwutil.pld (`Win_API`)
- 19. PCK-Backed Logic
- 20. System Interfaces
  - 20.1 Database Integrations
  - 20.2 External System Integrations
  - 20.3 Report Integrations
    - 20.3.1 Parameters Passed to the Report
- 21. Procedure and Function Business Rule Catalogue
  - 21.1 Catalogue Index
  - 21.2 Detailed Specifications
    - SP-001 - VIEW_EXCEL_REP
    - SP-002 - GENERAL.ASK_CONFIRM
    - SP-003 - GENERAL.DISP_TEXT
    - SP-004 - WEBUTIL.ERRORALERT
    - SP-005 - WEBUTIL.FCLOSE
    - SP-006 - WEBUTIL.FOPEN
    - SP-007 - WEBUTIL.GETIMPLCLASS
    - SP-008 - WEBUTIL.GETPROPERTY
    - SP-009 - WEBUTIL.GET_LINE
    - SP-010 - WEBUTIL.ID_NULL
    - SP-011 - WEBUTIL.PUT_LINE
    - SP-012 - WEBUTIL.SETPROPERTY

## 1. Document Control

### 1.1 Document Information

| Field | Value |
| ----- | ----- |
| Document Title | PE_SRV_RATIO - Business Requirements Document |
| Form Module Name | PE_SRV_RATIO |
| Document Version | 1.0 |
| Date Created | August 13, 2026 |
| Author/Prepared By | BRD Agent |

### 1.2 Revision History

| Version | Date | Author | Description |
| --- | --- | --- | --- |
| 1.0 | August 13, 2026 | BRD Agent | Initial draft |

---

## 2. Executive Summary

*High-level overview of the pe_srv_ratio Service Ratio Report form, its purpose, and roles referenced in the module.*

The **pe_srv_ratio** Oracle Forms module is the **Service Ratio Report** parameter entry screen used within a Dealer Management System. A reporting user opens the screen, selects the reporting scope - choosing the consignee, dealer, location, and state from guided pick-lists, specifying the date range, report type, sale type, category, and ratio filter - and then triggers the export. The form validates that all mandatory filter fields are completed before constructing a dynamic service ratio query and generating a downloadable CSV file that opens directly in the browser for further analysis. Insert, update, delete, save, and print operations are not supported; the screen's sole purpose is to configure and launch the service ratio data export.

### Key Stakeholders

*Who uses pe_srv_ratio*

| Stakeholder | Role |
| :--- | :--- |
| **Reporting User / Parts Manager** | **Primary interactive user** of the pe_srv_ratio screen. Selects filter criteria, initiates the export, and reviews the resulting service ratio data. |
| **Dealer / Consignee Organisation** | Business entity whose parts service performance is measured; the organisation's location, state, and dealer name are selected as report filters. |

---

---

## 3. System Context

*Describes the pe_srv_ratio module's role within the DMS ecosystem, scope, process flow, and key integrations.*

The **pe_srv_ratio** module is the **Service Ratio Report** screen within the Dealer Management System. It acts as a self-contained reporting parameter entry point that allows authorised users to configure filters and export parts service fill-rate data as a CSV file for offline analysis. The form connects to dealer and location master data for LOV-driven filter selection and constructs a dynamic query that is exported directly to the browser.

**System purpose:** Configure service ratio report parameters - including consignee, dealer, location, state, date range, report type, sale type, category, and ratio filter - validate all mandatory inputs, and generate a downloadable CSV service ratio export as implemented in the pe_srv_ratio Oracle Forms module.

**In scope:**

- Open the Service Ratio Report parameter screen, pre-populated with the current date and default 'ALL' selections
- Select consignee, dealer name, location, and state using LOV-driven pick-lists sourced from dealer location master data
- Specify the reporting date range (from-date and to-date, both defaulted to today)
- Choose report type: Part-wise, Dealer/Summary, or Group/Customer-segment
- Choose sale type: Counter Sales, Workshop, or Both
- Choose report category: Lines fill rate, Quantity fill rate, or Value fill rate
- Choose ratio filter: Full (100%) or Less than 100%
- Optionally narrow results by root part number or individual part number
- Validate that all mandatory filter fields are completed before export
- Build a dynamic service ratio SQL query incorporating all selected filter criteria
- Export the query result as a CSV file opened directly in the browser
- Cancel entered criteria and reset the form
- Exit the form without saving

**Process Name:** Service Ratio Report

**Process Owner:** Parts Manager / Reporting User

**Process Objective:** Open the service ratio report screen, select and validate the required reporting scope and date range, choose the report type and category, optionally filter by part number, and generate a CSV export of the service fill-rate results.

**Process Trigger:** A reporting user requires a parts service fill-rate analysis for a specific dealer, consignee, location, or state within a chosen date range.

**Process Flow:**

The complete service ratio report process follows this sequence. Each step corresponds to Functional Requirements in Section 4.

```
STEP 1 ── SCREEN OPENS
         The Service Ratio Report screen opens and is maximised automatically.
         The date fields default to today's date; PARENT_GROUP, DEALER_NAME, and LOC_CD
         default to 'ALL'. The parameters carried from the calling form are cleared.

STEP 2 ── SELECT CONSIGNEE
         User opens the consignee pick-list and selects a consignee code.
         The available list shows all consignees for the active principal/dealer group.
         'ALL' is available as a catch-all option.
         System validates that a value is entered before allowing navigation.

STEP 3 ── SELECT STATE
         User opens the state pick-list and selects a geographic state.
         The state list is filtered to states associated with the chosen consignee.
         'ALL' is available.
         System validates that a value is entered before allowing navigation.

STEP 4 ── SELECT DEALER NAME
         User opens the dealer pick-list and selects a dealer name.
         The list is filtered by the selected consignee.
         'ALL' is available.
         System validates that a value is entered before allowing navigation.

STEP 5 ── SELECT LOCATION
         User opens the location pick-list and selects a dealer location code.
         The location list is filtered by the selected consignee.
         'ALL' is available.
         System validates that a value is entered before allowing navigation.

STEP 6 ── ENTER DATE RANGE
         User confirms or changes the from-date and to-date.
         Both fields default to today's date.
         System validates that from-date and to-date are not empty.

STEP 7 ── SELECT REPORT TYPE
         User selects the report type:
         ├── Part-wise (P): all part-level combinations remain enabled
         ├── Dealer/Summary (S): PART_NUM and ROOT_PART_NUM are disabled and hidden
         └── Group/Customer-segment (G): SALE_TYPE is forced to 'C' (Counter Sales) and disabled

STEP 8 ── SELECT SALE TYPE
         ├── Counter Sales (C): only counter sale transactions are included
         ├── Workshop (W): only workshop sale transactions are included
         └── Both (B): both transaction types are included
         (Disabled and fixed to 'C' when REPORT_TYPE = 'G')

STEP 9 ── SELECT REPORT CATEGORY
         User selects the fill-rate metric:
         ├── Lines (L): order-line fill rate
         ├── Quantity (Q): quantity fill rate
         └── Value (V): value fill rate

STEP 10 ── SELECT RATIO FILTER
          User selects the ratio threshold:
          ├── Full (F): include only records with 100% fill rate
          └── Less than 100% (L): include records below full fill rate

STEP 11 ── ENTER OPTIONAL ROOT PART NUMBER - when narrowing by root part
          User enters a root part number to restrict results to parts under that root.
          System appends the root part filter to the query.

STEP 12 ── ENTER OPTIONAL PART NUMBER - when narrowing by specific part (P/G report types only)
          User enters a specific part number to restrict results to that part.
          System appends part-number filters to both counter-sales and workshop branches.
          (Disabled when REPORT_TYPE = 'S')

STEP 13 ── EXPORT TO CSV
          User clicks the Export to Excel button.
          System resets all part-number filter parameters and rebuilds the dynamic
          service ratio SQL query incorporating all selected filter criteria, report type,
          sale type, category, and ratio HAVING clause.
          The constructed query is stored internally for reference.

STEP 14 ── GENERATE CSV FILE
          System executes the dynamic query and loads results into a record group
          (capped at 65,535 rows).
          A CSV file is written to the server reports printer directory with a unique
          name based on the user ID and timestamp.

STEP 15 ── OPEN FILE IN BROWSER
          System opens the generated CSV file in the browser using web.show_document.
          User can download and open the file for further analysis.

STEP 16 ── CANCEL / RESET - when user discards entries
          User clicks Cancel.
          If entries have been made, the system asks the user to confirm before clearing all
          filter criteria and resetting the form.

STEP 17 ── EXIT
          User clicks Exit or presses the exit key.
          The form closes immediately without saving.
          Application registration is cleared from the database session.
```

**Major process interactions:**

- **Dealer location master (AM_DEALER_LOC)** - provides consignee, dealer, location, and principal data for all LOV pick-lists and for filtering the dynamic service ratio query
- **State master (GM_STATE)** - provides state codes and descriptions joined with dealer location data for the state selection pick-list
- **Report server file system** - receives the generated CSV file written to the server-side reports printer directory
- **Browser / web client** - displays the generated CSV file to the user via web.show_document for download and review

---

---

## 4. Functional Requirements

### 4.1 Business Requirements

#### Requirement ID: BR-001

**Requirement Title:** Service Ratio Report Screen Initialisation

**Business Description:**
When the Service Ratio report screen opens, the system automatically maximises the screen to fill the display, pre-fills both the report date range fields with today's date, and sets the organisation filters (parent group, dealer name, and location) to the broadest available scope so the user can immediately run a report or narrow the scope as required.

**Actors:** Report User

**Preconditions:**
- The user has launched the Service Ratio report screen.

**Main Flow:**

**Step 1 - Screen maximised on open**
The Service Ratio report screen opens and is immediately expanded to fill the full display area, giving the user maximum visibility of the report criteria and filter fields.

**Step 2 - Date range defaulted to today**
The system automatically populates both the From Date and To Date fields with the current date so the user has a ready-to-use single-day range without manual entry.

*Screen: SERVICE RATIO (`WN_MAIN` / `CN_MAIN`).*

**Step 3 - Organisation scope defaulted to "All"**
The system sets the Parent Group, Dealer Name, and Location filter fields to the widest available scope, indicating that all dealers, parent groups, and locations will be included in a report unless the user narrows the filters.

*Screen: SERVICE RATIO (`WN_MAIN` / `CN_MAIN`).*

**Alternative Flows:**
- **BR-001-AF-01** - (from Step 1) Commented-out initialisation code (default global variables, list population) does not execute - those defaults are inactive and have no effect on the screen. (COMMENTED OUT / INACTIVE - does not execute)

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| From Date (`P_FROMDT`) | Auto-populated | Date | 10 / dd/mm/rrrr | N/A | Current date (SYSDATE) | N/A | Auto-populated at form open; no manual validation at this step | N/A |
| To Date (`P_TODT`) | Auto-populated | Date | 10 / dd/mm/rrrr | N/A | Current date (SYSDATE) | N/A | Auto-populated at form open; no manual validation at this step | N/A |
| Parent Group (`PARENT_GROUP`) | Auto-populated | Text | N/A | N/A | Fixed value: ALL | N/A | Auto-populated at form open | N/A |
| Dealer Name (`DEALER_NAME`) | Auto-populated | Text | 50 | N/A | Fixed value: ALL | N/A | Auto-populated at form open | N/A |
| Location (`LOC_CD`) | Auto-populated | Text | N/A | N/A | Fixed value: ALL | N/A | Auto-populated at form open | N/A |

---

---

#### Requirement ID: BR-002

**Requirement Title:** Application Session Registration Before Form Opens

**Business Description:**
Immediately before the Service Ratio report screen becomes visible to the user, the system registers the name of this screen module with the database's active session information. This registration allows database administrators and monitoring tools to identify which application screen is consuming database resources at any given moment.

**Actors:** System (automatic, no user interaction)

**Preconditions:**
- The user has initiated navigation to the Service Ratio report screen.

**Main Flow:**

**Step 1 - Session client information registered**
Before the screen is displayed, the system records the name of the application module ("pe_srv_ratio") as the client information for the current database session. This enables database-level monitoring to attribute any queries run by this session to this specific screen.

**Step 2 - Session module name registered**
The system also sets the session module name to "pe_srv_ratio" with an empty action label, completing the session identification information in the database. No visible change occurs on the screen; this step is entirely a system background action.

---

---

#### Requirement ID: BR-003

**Requirement Title:** Consignee Code Selection and Mandatory Validation

**Business Description:**
When the report user enters or changes the Consignee Code filter, the system validates that a value has been provided. The Consignee Code is a required filter that scopes the Service Ratio report to one or more specific consignees. If the user leaves the field blank, the system prevents the cursor from leaving the field and shows an error message to prompt entry.

**Actors:** Report User

**Preconditions:**
- The Service Ratio report screen is open.

**Main Flow:**

**Step 1 - Consignee Code entered and validated**
The user enters or selects a Consignee Code in the filter field. When the user attempts to move to another field, the system checks that the Consignee Code field is not empty.

*Screen: SERVICE RATIO (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-003](#SP-003--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays an error message on screen when the Consignee Code has been left blank, then stops processing so the cursor remains on the field.
    * **Step 1** - Receives the message text and severity level from the calling code.
    * **Step 2** - Displays the message to the user on screen with the specified severity.
    * **Step 3** - Returns control to the calling code after the message has been shown.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Consignee Code must be provided | Consignee Code null check - GENERAL.DISP_TEXT [SP-003], followed by RAISE FORM_TRIGGER_FAILURE in WHEN-VALIDATE-ITEM on CNTRL_BLK.CONSG_CD | When the user attempts to leave the Consignee Code field | The Consignee Code is required to scope the report to a specific consignee; without it the report cannot be generated correctly | *"consignee code cannot be null"* is shown; the cursor stays on the Consignee Code field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-ES-01** - Consignee Code left blank - *"consignee code cannot be null"*; the cursor remains on the Consignee Code field and the user must provide a value before proceeding.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Consignee Code (`CONSG_CD`) | Mandatory | Text | 15 | Consignee lookup (LV_CONSG / RG_CONSG) | Consignee code and category from dealer location master | N/A | Must not be blank | *"consignee code cannot be null"* - cursor remains on field |

---

---

#### Requirement ID: BR-004

**Requirement Title:** State Selection via Lookup and Mandatory Validation

**Business Description:**
When the report user moves to the State filter field, the system automatically opens a list of available states for the user to choose from. After the user selects or enters a value and moves on, the system verifies that the State field is not empty. State is a required filter field; leaving it blank prevents the user from advancing to other fields.

**Actors:** Report User

**Preconditions:**
- The Service Ratio report screen is open.

**Main Flow:**

**Step 1 - State lookup list opens automatically**
When the cursor enters the State field, the system immediately opens the State lookup list, displaying available states filtered to the current principal and consignee context for the user to choose from.

*Screen: SERVICE RATIO (`WN_MAIN` / `CN_MAIN`).*

**Step 2 - State value validated on departure**
After the user selects or types a value and attempts to leave the State field, the system checks that the field is not blank.

*Screen: SERVICE RATIO (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-003](#SP-003--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays an error message on screen when the State has been left blank, then stops processing so the cursor remains on the field.
    * **Step 1** - Receives the message text and severity level from the calling code.
    * **Step 2** - Displays the message to the user on screen with the specified severity.
    * **Step 3** - Returns control to the calling code after the message has been shown.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| State must be provided | State null check - GENERAL.DISP_TEXT [SP-003], followed by RAISE FORM_TRIGGER_FAILURE in WHEN-VALIDATE-ITEM on CNTRL_BLK.STATE_CD | When the user attempts to leave the State field | State is required to scope the report geographically; a blank State would produce an unfiltered or invalid report | *"State cannot be null"* is shown; the cursor stays on the State field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-004-ES-01** - State left blank - *"State cannot be null"*; the cursor remains on the State field and the user must provide a value before proceeding.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| State (`STATE_CD`) | Mandatory | Text | N/A | State lookup (LV_STATE / RG_STATE) | State description and code from geographic master | N/A | Must not be blank | *"State cannot be null"* - cursor remains on field |

---

---

#### Requirement ID: BR-005

**Requirement Title:** Dealer Name Selection via Lookup and Mandatory Validation

**Business Description:**
When the report user moves to the Dealer Name filter field, the system automatically opens a list of available dealers for selection, filtered to the currently chosen consignee and parent group context. After the user chooses or enters a value and moves on, the system confirms the field is not empty. Dealer Name is required; a blank entry prevents the user from advancing.

**Actors:** Report User

**Preconditions:**
- The Service Ratio report screen is open.
- A Consignee Code has been set in the filter area.

**Main Flow:**

**Step 1 - Dealer lookup list opens automatically**
When the cursor enters the Dealer Name field, the system immediately opens the Dealer Name lookup list. The list shows dealer names and their parent group, filtered to match the current principal, parent group, and consignee selections.

*Screen: SERVICE RATIO (`WN_MAIN` / `CN_MAIN`).*

**Step 2 - Dealer Name value validated on departure**
After the user selects or types a value and attempts to leave the Dealer Name field, the system checks that the field is not blank.

*Screen: SERVICE RATIO (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-003](#SP-003--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays an error message on screen when the Dealer Name has been left blank, then stops processing so the cursor remains on the field.
    * **Step 1** - Receives the message text and severity level from the calling code.
    * **Step 2** - Displays the message to the user on screen with the specified severity.
    * **Step 3** - Returns control to the calling code after the message has been shown.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Dealer Name must be provided | Dealer Name null check - GENERAL.DISP_TEXT [SP-003], followed by RAISE FORM_TRIGGER_FAILURE in WHEN-VALIDATE-ITEM on CNTRL_BLK.DEALER_NAME | When the user attempts to leave the Dealer Name field | Dealer Name is required to identify which dealer's service ratio data to include in the report | *"dealer_name cannot be null"* is shown; the cursor stays on the Dealer Name field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-ES-01** - Dealer Name left blank - *"dealer_name cannot be null"*; the cursor remains on the Dealer Name field and the user must provide a value before proceeding.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dealer Name (`DEALER_NAME`) | Mandatory | Text | 50 | Dealer lookup (LV_DEALER / RG_DEALER) | Dealer name and parent group from dealer location master | Consignee Code set | Must not be blank | *"dealer_name cannot be null"* - cursor remains on field |

---

---

#### Requirement ID: BR-006

**Requirement Title:** Location Selection via Lookup and Mandatory Validation

**Business Description:**
When the report user moves to the Location filter field, the system automatically opens a list of available locations for selection, filtered to match the current principal, parent group, and consignee context. After the user selects or types a value and moves on, the system verifies the field is not blank. Location is required; leaving it empty prevents the user from advancing.

**Actors:** Report User

**Preconditions:**
- The Service Ratio report screen is open.
- A Consignee Code has been set in the filter area.

**Main Flow:**

**Step 1 - Location lookup list opens automatically**
When the cursor enters the Location filter field, the system immediately opens the Location lookup list showing available location descriptions and codes, filtered to the current principal, parent group, and consignee.

*Screen: SERVICE RATIO (`WN_MAIN` / `CN_MAIN`).*

**Step 2 - Location value validated on departure**
After the user selects or types a value and attempts to leave the Location field, the system checks that the field is not blank.

*Screen: SERVICE RATIO (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-003](#SP-003--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays an error message on screen when the Location has been left blank, then stops processing so the cursor remains on the field.
    * **Step 1** - Receives the message text and severity level from the calling code.
    * **Step 2** - Displays the message to the user on screen with the specified severity.
    * **Step 3** - Returns control to the calling code after the message has been shown.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Location must be provided | Location null check - GENERAL.DISP_TEXT [SP-003], followed by RAISE FORM_TRIGGER_FAILURE in WHEN-VALIDATE-ITEM on CNTRL_BLK.LOC_CD | When the user attempts to leave the Location field | Location is required to scope the report to the correct dealer location; a blank value would produce an incorrectly scoped report | *"Location cannot be null"* is shown; the cursor stays on the Location field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-006-ES-01** - Location left blank - *"Location cannot be null"*; the cursor remains on the Location field and the user must provide a value before proceeding.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Location (`LOC_CD`) | Mandatory | Text | N/A | Location lookup (LV_LOC / RG_LOC) | Location description and code from dealer location master | Consignee Code set | Must not be blank | *"Location cannot be null"* - cursor remains on field |

---

---

#### Requirement ID: BR-007

**Requirement Title:** From Date Entry and Mandatory Validation

**Business Description:**
When the report user enters or changes the From Date field, the system validates that a date value has been provided before the user can move to another field. The From Date defines the start of the period for which the service ratio report will be generated. Leaving it blank prevents the report from running correctly.

**Actors:** Report User

**Preconditions:**
- The Service Ratio report screen is open.

**Main Flow:**

**Step 1 - From Date entered and validated**
The user types a date into the From Date field (formatted as day/month/year). When the user attempts to move to another field, the system checks that the From Date field is not blank.

*Screen: SERVICE RATIO (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-003](#SP-003--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays an error message on screen when the From Date has been left blank, then stops processing so the cursor remains on the field.
    * **Step 1** - Receives the message text and severity level from the calling code.
    * **Step 2** - Displays the message to the user on screen with the specified severity.
    * **Step 3** - Returns control to the calling code after the message has been shown.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| From Date must be provided | From Date null check - GENERAL.DISP_TEXT [SP-003], followed by RAISE FORM_TRIGGER_FAILURE in WHEN-VALIDATE-ITEM on CNTRL_BLK.P_FROMDT | When the user attempts to leave the From Date field | From Date is required to define the start of the reporting period; without it the report date range cannot be established | *"enter from date"* is shown; the cursor stays on the From Date field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-007-ES-01** - From Date left blank - *"enter from date"*; the cursor remains on the From Date field and the user must enter a date before proceeding.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| From Date (`P_FROMDT`) | Mandatory | Date | 10 / dd/mm/rrrr | N/A | N/A | N/A | Must not be blank | *"enter from date"* - cursor remains on field |

---

---

#### Requirement ID: BR-008

**Requirement Title:** To Date Entry and Mandatory Validation

**Business Description:**
When the report user enters or changes the To Date field, the system validates that a date value has been provided before the user can move to another field. The To Date defines the end of the period for which the service ratio report will be generated. Leaving it blank prevents the report from running correctly.

**Actors:** Report User

**Preconditions:**
- The Service Ratio report screen is open.

**Main Flow:**

**Step 1 - To Date entered and validated**
The user types a date into the To Date field (formatted as day/month/year). When the user attempts to move to another field, the system checks that the To Date field is not blank.

*Screen: SERVICE RATIO (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-003](#SP-003--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays an error message on screen when the To Date has been left blank, then stops processing so the cursor remains on the field.
    * **Step 1** - Receives the message text and severity level from the calling code.
    * **Step 2** - Displays the message to the user on screen with the specified severity.
    * **Step 3** - Returns control to the calling code after the message has been shown.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| To Date must be provided | To Date null check - GENERAL.DISP_TEXT [SP-003], followed by RAISE FORM_TRIGGER_FAILURE in WHEN-VALIDATE-ITEM on CNTRL_BLK.P_TODT | When the user attempts to leave the To Date field | To Date is required to define the end of the reporting period; without it the report date range cannot be established | *"enter to date"* is shown; the cursor stays on the To Date field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-008-ES-01** - To Date left blank - *"enter to date"*; the cursor remains on the To Date field and the user must enter a date before proceeding.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| To Date (`P_TODT`) | Mandatory | Date | 10 / dd/mm/rrrr | N/A | N/A | N/A | Must not be blank | *"enter to date"* - cursor remains on field |

---

---

#### Requirement ID: BR-009

**Requirement Title:** Report Type Selection and Dependent Field Control

**Business Description:**
When the report user selects a Report Type, the system automatically adjusts the availability of the Part Number and Root Part Number filter fields, and may also lock the Sale Type selection, based on the report type chosen. Summary-level report types do not allow part-level filtering; part-level report types enable both part filter fields. The Group report type automatically fixes the Sale Type and prevents the user from changing it.

**Actors:** Report User

**Preconditions:**
- The Service Ratio report screen is open.

**Main Flow:**

**Step 1 - Report Type selected**
The user selects a value from the Report Type drop-down list. The system immediately evaluates the chosen report type and adjusts the availability of related filter fields accordingly.

*Screen: SERVICE RATIO (`WN_MAIN` / `CN_MAIN`).*

**Step 2 - Part Number fields enabled or disabled based on Report Type**
If the user has chosen the Summary report type, the system disables and makes non-navigable both the Root Part Number and Part Number filter fields (since summary-level reports are not filtered by individual parts). For any other report type, both part filter fields are enabled and navigable.

*Screen: SERVICE RATIO (`WN_MAIN` / `CN_MAIN`).*

**Step 3 - Sale Type locked or released based on Report Type**
If the user has chosen the Group report type, the system automatically sets the Sale Type to a fixed value (Customer) and disables and makes non-navigable the Sale Type field, preventing the user from changing it. For any other report type, the Sale Type field remains enabled and navigable.

*Screen: SERVICE RATIO (`WN_MAIN` / `CN_MAIN`).*

#### Business Scenarios - How dependent field availability differs by Report Type

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Summary Report Type selected** | Root Part Number and Part Number fields are disabled and non-navigable; Sale Type field remains enabled and navigable |
| **Group Report Type selected** | Sale Type field is automatically set to Customer and locked (disabled, non-navigable); Root Part Number and Part Number fields are enabled and navigable |
| **Part-level Report Type selected (any other value)** | Root Part Number and Part Number fields are enabled and navigable; Sale Type field remains enabled and navigable |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Report Type (`REPORT_TYPE`) | Mandatory | List | N/A | N/A | Summary (S) / Part-level (P) / Group (G) | N/A | Must be selected before generating the report | N/A |
| Root Part Number (`ROOT_PART_NUM`) | Conditional - enabled only when Report Type is not Summary | Text | N/A | N/A | N/A | Report Type selected | Enabled only for part-level and group report types | N/A |
| Part Number (`PART_NUM`) | Conditional - enabled only when Report Type is not Summary | Text | N/A | N/A | N/A | Report Type selected | Enabled only for part-level and group report types | N/A |
| Sale Type (`SALE_TYPE`) | Mandatory (auto-set for Group type; user-selectable otherwise) | List | N/A | N/A | Customer (C) / Warranty (W) / Both (B) | Report Type selected | Auto-set to Customer when Group report type is selected; user-selectable otherwise | N/A |

---

---

#### Requirement ID: BR-010

**Requirement Title:** Excel Report Generation and Download

**Business Description:**
When the report user clicks the Excel Report button after setting the filter criteria, the system builds a service ratio report as a CSV-formatted file and opens it in the user's browser. The report data is constructed based on the selected Report Type, the Based On category (line count, quantity, or value), the Sale Type, the Ratio filter, and the optional part number filters. The output is a comma-separated file that can be opened in Excel. The system notifies the user if the number of rows exceeds the Excel limit and truncates accordingly, and reports an error if any unexpected problem occurs during file generation.

**Actors:** Report User

**Preconditions:**
- All mandatory filter fields are populated: Consignee Code, State, Dealer Name, Location, From Date, To Date, Report Type, Sale Type, Based On, and Ratio.

**Main Flow:**

**Step 1 - Report parameters cleared and filename generated**
When the user clicks the Excel Report button, the system first clears the three internal where-clause parameters. It then generates a unique output filename by combining the logged-in user's identifier with the current date and time, formatted as a CSV file.

*Screen: SERVICE RATIO (`WN_MAIN` / `CN_MAIN`).*

**Step 2 - Part Number filter appended if specified**
If the user has entered a Part Number, the system appends a filter for that part number to the customer-sales and workshop-parts where-clause parameters. If Root Part Number has been entered, the system appends a filter for that root part number to the general where-clause parameter.

*Screen: SERVICE RATIO (`WN_MAIN` / `CN_MAIN`).*

**Step 3 - Report query constructed based on Report Type and Based On category**
The system constructs a dynamic SQL query based on the combination of Report Type (Part-level, Summary, or Group) and the Based On category (Lines, Quantity, or Value). The constructed query joins dealer location data with parts and sales/workshop order data, filtered by the selected principal, date range, consignee, parent group, location, sale type, and ratio range. The data is grouped and filtered by the Ratio value selection (Full - 100% ratio, Low - below 100%, or all).

**Step 4 - File path resolved from server configuration**
The system reads the file download path from a configuration file stored on the application server. This path is used to determine where the generated CSV file will be written and from where the user's browser will retrieve it. If the generated filename contains spaces in the folder path, the system redirects output to the C drive root as a fallback and informs the user.

*Procedures called:*
- **VIEW_EXCEL_REP** ([SP-001](#SP-001--VIEW_EXCEL_REP)) - VIEW_EXCEL_REP - executes the constructed query against the database, writes the results to a CSV file on the server, and opens the file for the user in a browser tab.
    * **Step 1** - Determines the output filename by combining the current user's identifier with the current date and time as a CSV filename; if the path contains spaces, redirects to the C drive root and informs the user.
    * **Step 2** - Clears any previously existing in-memory record group with the same name.
    * **Step 3** - Creates a new in-memory record group by running the supplied query against the database.
    * **Step 4** - Counts the number of result rows; if the count exceeds 65,535, informs the user that the output will be truncated to that limit.
    * **Step 5** - Reads the report server download path from the application server's configuration file.
    * **Step 6** - Opens a new CSV file at the resolved server path and writes each row of the result set to it as a comma-separated line.
    * **Step 7** - Closes the output file and opens the generated file in the user's browser as a new document tab.
    * **Step 8** - If any unexpected error occurs during the above steps, displays an error message containing the system error code and description, then raises a trigger failure to halt processing.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Output path space check | VIEW_EXCEL_REP [SP-001] - inline path check: `INSTR(FILENAME,' ') > 0` | When the Excel Report button is clicked and the filename is being prepared | Prevents file-write failures caused by spaces in folder names by redirecting to a safe fallback path | *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."* - file is redirected to C drive root |
| Row count limit check | VIEW_EXCEL_REP [SP-001] - inline count check: `the_rowcount > 65536` | Immediately after the report query populates the in-memory data set | Prevents generating a file that exceeds Excel's maximum row limit, which would cause an unusable output | *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."* - output is truncated to 65,535 rows |
| Unexpected error during file generation | VIEW_EXCEL_REP [SP-001] - WHEN OTHERS exception handler | When any unexpected error occurs during query execution, file writing, or browser launch | Ensures the user is informed of any unexpected failures rather than silently failing | *"Error  -"* followed by the system error code and error text; trigger failure halts processing |

*Business outcomes (errors, warnings, success, and status):*
- **BR-010-IC-01** - *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."* - the file is saved to the C drive root instead of the original path; generation continues.
- **BR-010-IC-02** - *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."* - the report is truncated to 65,535 rows and the file is still generated.
- **BR-010-ES-01** - Unexpected error during report generation - *"Error  -"* followed by the system-provided error code and error description text; processing halts and no file is opened.

Note: The message text *"File Transfer failed"* exists in the VIEW_EXCEL_REP code but is within a commented-out section and does not execute. (COMMENTED OUT / INACTIVE - does not execute)

#### Business Scenarios - How the report query differs by Report Type and Based On category

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Part-level / Lines** | Query shows consignee category, code, dealer name, root part number, part number, requested lines, fully supplied lines, and ratio; covers both customer-sales and workshop orders combined |
| **Part-level / Quantity** | Query shows the same grouping but reports requested quantity, supplied quantity, and ratio instead of line counts |
| **Part-level / Value** | Query additionally joins to part pricing data and shows requested value, supplied value, and ratio |
| **Summary / Lines** | Query groups by consignee and dealer (not by part); shows code, dealer name, workshop, location, from date, to date, total lines, fully served, partially served, and ratio |
| **Summary / Quantity** | Same summary grouping but shows requested quantity, supplied quantity, and ratio |
| **Summary / Value** | Same summary grouping with value figures, additionally joining to part pricing |
| **Group / Lines** | Query groups by consignee, dealer, and customer segment (party type from a reference list); shows category, code, dealer name, customer segment, requested lines, fully supplied lines, and ratio |
| **Group / Quantity** | Same group grouping but shows requested and supplied quantity |
| **Group / Value** | Same group grouping with value amounts and pricing join |

**Alternative Flows:**
- **BR-010-AF-01** - (from Step 4) The generated filename contains spaces in one of the folder names: the system redirects the output file to the C drive root and informs the user with the information message before continuing to write the file.
- **BR-010-AF-02** - (from Step 4) The result set contains more than 65,535 rows: the system displays an information message and truncates the output to 65,535 rows before writing the file.
- **BR-010-AF-03** - (from Step 4) An unexpected error occurs during file generation: the system displays the error code and description (*"Error  -"* plus the system error text) and halts; no file is opened.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Consignee Code (`CONSG_CD`) | Mandatory | Text | 15 | Consignee lookup (LV_CONSG / RG_CONSG) | Consignee code | All filter fields must be set | Used as a filter in the report query; ALL means no filter | N/A |
| State (`STATE_CD`) | Mandatory | Text | N/A | State lookup (LV_STATE / RG_STATE) | State code | All filter fields must be set | Used as a geographic filter in the report query for Summary reports | N/A |
| Dealer Name (`DEALER_NAME`) | Mandatory | Text | 50 | Dealer lookup (LV_DEALER / RG_DEALER) | Dealer name | All filter fields must be set | Used as a filter in the report query | N/A |
| Location (`LOC_CD`) | Mandatory | Text | N/A | Location lookup (LV_LOC / RG_LOC) | Location code | All filter fields must be set | Used as a filter in the report query; ALL means no filter | N/A |
| From Date (`P_FROMDT`) | Mandatory | Date | 10 / dd/mm/rrrr | N/A | N/A | All filter fields must be set | Defines report period start date | N/A |
| To Date (`P_TODT`) | Mandatory | Date | 10 / dd/mm/rrrr | N/A | N/A | All filter fields must be set | Defines report period end date | N/A |
| Report Type (`REPORT_TYPE`) | Mandatory | List | N/A | N/A | Part-level (P) / Summary (S) / Group (G) | All filter fields must be set | Determines report grouping and query structure | N/A |
| Sale Type (`SALE_TYPE`) | Mandatory | List | N/A | N/A | Customer (C) / Warranty (W) / Both (B) | All filter fields must be set | Filters transactions by sale channel; auto-set to Customer for Group report type | N/A |
| Based On (`REP_CATG`) | Mandatory | List | N/A | N/A | Lines (L) / Quantity (Q) / Value (V) | All filter fields must be set | Determines the ratio calculation basis | N/A |
| Ratio (`RATIO`) | Mandatory | List | N/A | N/A | Full (F) / Low (L) | All filter fields must be set | Filters results to show only 100% ratio records, only below 100%, or all | N/A |
| Root Part Number (`ROOT_PART_NUM`) | Optional | Text | N/A | N/A | N/A | Report Type must not be Summary | Optional part-family filter appended to the query | N/A |
| Part Number (`PART_NUM`) | Optional | Text | N/A | N/A | N/A | Report Type must not be Summary | Optional individual part filter appended to the query | N/A |

---

---

#### Requirement ID: BR-011

**Requirement Title:** Cancel and Clear Form with Unsaved Data Warning

**Business Description:**
When the report user clicks the Cancel button, the system re-enables any filter fields that may have been locked (such as Part Number, Root Part Number, and Sale Type), then checks whether any filter values have been changed since the screen was last cleared. If changes exist, the system asks the user to confirm before discarding them. If there are no changes, the form is cleared immediately without prompting. This ensures the user does not accidentally lose filter selections without being warned.

**Actors:** Report User

**Preconditions:**
- The Service Ratio report screen is open and the Cancel button is enabled.

**Main Flow:**

**Step 1 - Filter fields re-enabled**
When the user clicks the Cancel button, the system first re-enables and makes navigable the Part Number, Root Part Number, and Sale Type filter fields, regardless of their current state. This restores the form to an open editing state before clearing it.

**Step 2 - Unsaved changes checked and confirmation requested if needed**
The system checks whether any filter values on the screen have been changed. If changes exist, the user is asked to confirm that the entered data will be discarded. If the user confirms, the form is cleared without saving. If the user declines, the form remains as-is with all entered values preserved.

*Procedures called:*
- **GENERAL.ASK_CONFIRM** ([SP-002](#SP-002--GENERAL.ASK_CONFIRM)) - GENERAL.ASK_CONFIRM - displays a confirmation dialog asking the user whether to discard unsaved data, and returns the user's choice to the calling logic.
    * **Step 1** - Receives the confirmation prompt text from the calling code.
    * **Step 2** - Displays the confirmation dialog to the user with the supplied prompt.
    * **Step 3** - Waits for the user to click a response button and returns the user's choice (confirmed or declined) to the calling code.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Unsaved changes confirmation | Unsaved data check - GENERAL.ASK_CONFIRM [SP-002] called when system.form_status = 'CHANGED', in FT_CANCEL trigger | When the Cancel button is clicked and filter values have been changed | Prevents the user from accidentally discarding filter criteria they have entered without being warned first | User clicks "No" in the confirmation dialog - the form is not cleared and all entered values are preserved |

*Business outcomes (errors, warnings, success, and status):*
- **BR-011-WS-01** - Filter values have been changed - *"Entered data will not be Saved"* - confirmation dialog is shown; user may choose to proceed with clearing or cancel the action.

**Step 3 - Form cleared**
If the user confirms discarding changes, or if there were no changes, the form is cleared without saving any data. All filter fields are reset.

**Alternative Flows:**
- **BR-011-AF-01** - (from Step 2) No changes have been made to the form: the system clears the form immediately without displaying a confirmation dialog.
- **BR-011-AF-02** - (from Step 2) The user declines the confirmation: the form is not cleared and the user may continue editing or generating reports.
- **BR-011-AF-03** - (from Step 1) The Cancel button is disabled: no action is taken and the form remains unchanged.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Part Number (`PART_NUM`) | Conditional - re-enabled on Cancel | Text | N/A | N/A | N/A | Cancel button enabled | Re-enabled and made navigable regardless of prior state when Cancel is clicked | N/A |
| Root Part Number (`ROOT_PART_NUM`) | Conditional - re-enabled on Cancel | Text | N/A | N/A | N/A | Cancel button enabled | Re-enabled and made navigable regardless of prior state when Cancel is clicked | N/A |
| Sale Type (`SALE_TYPE`) | Conditional - re-enabled on Cancel | List | N/A | N/A | N/A | Cancel button enabled | Re-enabled and made navigable regardless of prior state when Cancel is clicked | N/A |

---

---

#### Requirement ID: BR-012

**Requirement Title:** Insert Operation Not Permitted on This Screen

**Business Description:**
The Service Ratio report screen is a read-only enquiry and reporting screen; data insertion is not a supported operation. If the Insert button is enabled and the user attempts to insert a record, the system blocks the action and informs the user that this operation cannot be performed here.

**Actors:** Report User

**Preconditions:**
- The Service Ratio report screen is open and the Insert button is enabled.

**Main Flow:**

**Step 1 - Insert attempt blocked**
When the Insert button is enabled and the user activates it, the system does not perform any insertion. Instead, it immediately displays an error message to inform the user that inserting records is not possible on this screen.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-003](#SP-003--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the error message informing the user that the insert operation is not permitted on this screen.
    * **Step 1** - Receives the message text and severity level from the calling code.
    * **Step 2** - Displays the message to the user on screen with the specified severity.
    * **Step 3** - Returns control to the calling code after the message has been shown.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Insert operation is not permitted | Insert block check - GENERAL.DISP_TEXT [SP-003] called in FT_INSERT trigger when Insert button is enabled | When the user activates the Insert button while it is enabled | The screen is a reporting-only screen; prevents users from attempting unsupported data entry | *"This Operation Cannot be performed Here"* is shown; no record is inserted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-012-ES-01** - Insert button activated while enabled - *"This Operation Cannot be performed Here"*; no insertion takes place.

**Alternative Flows:**
- **BR-012-AF-01** - (from Step 1) The Insert button is disabled: no action is taken and no message is shown.

---

---

#### Requirement ID: BR-013

**Requirement Title:** Delete Operation Not Permitted on This Screen

**Business Description:**
The Service Ratio report screen does not support deleting records. If the Delete button is enabled and the user attempts a delete action, the system blocks the operation and informs the user that deletion cannot be performed on this screen. All previously written delete logic is commented out and does not execute; only the blocking message is active.

**Actors:** Report User

**Preconditions:**
- The Service Ratio report screen is open and the Delete button is enabled.

**Main Flow:**

**Step 1 - Delete attempt blocked**
When the Delete button is enabled and the user activates it, the system briefly disables form validation, then immediately displays an error message to inform the user that deleting records is not possible on this screen. The prior block of delete logic (including record group deletion and record commits) is commented out and does not execute.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-003](#SP-003--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the error message informing the user that the delete operation is not permitted on this screen.
    * **Step 1** - Receives the message text and severity level from the calling code.
    * **Step 2** - Displays the message to the user on screen with the specified severity.
    * **Step 3** - Returns control to the calling code after the message has been shown.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Delete operation is not permitted | Delete block check - GENERAL.DISP_TEXT [SP-003] called in FT_DEL trigger when Delete button is enabled | When the user activates the Delete button while it is enabled | The screen is a reporting-only screen; prevents users from attempting unsupported data deletion | *"This Operation Cannot be performed Here"* is shown; no record is deleted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-013-ES-01** - Delete button activated while enabled - *"This Operation Cannot be performed Here"*; no deletion takes place.

**Alternative Flows:**
- **BR-013-AF-01** - (from Step 1) The Delete button is disabled: no action is taken and no message is shown.
- **BR-013-AF-02** - (from Step 1) Commented-out delete logic (record group row removal, Delete_record, COMMIT_FORM) does not execute. (COMMENTED OUT / INACTIVE - does not execute)

---

---

#### Requirement ID: BR-014

**Requirement Title:** List of Values Display for Active Filter Fields

**Business Description:**
When the user clicks the List button (or its keyboard equivalent), the system displays the lookup list for whichever filter field currently has focus, provided the List button is enabled. This gives the user a browsable selection of valid values for the active field.

**Actors:** Report User

**Preconditions:**
- The Service Ratio report screen is open and the List button is enabled.
- An LOV-enabled filter field has focus.

**Main Flow:**

**Step 1 - Lookup list displayed for the current field**
When the List button is enabled and the user clicks it, the system invokes the standard list-of-values display for the filter field that currently has focus. The user can then browse and select a valid value from the list.

**Alternative Flows:**
- **BR-014-AF-01** - (from Step 1) The List button is disabled: no action is taken and no list is shown.

---

---

#### Requirement ID: BR-015

**Requirement Title:** Print Function (Inactive - Does Not Execute)

**Business Description:**
A Print button is present on the toolbar but is disabled and no print logic is active. The underlying print code body consists only of a check that the Print button is enabled, followed by a NULL placeholder. All print logic is commented out. Consequently, clicking the Print button produces no output and performs no action.

(COMMENTED OUT / INACTIVE - does not execute)

**Actors:** Report User

**Preconditions:**
- The Service Ratio report screen is open.

**Main Flow:**

**Step 1 - Print button checked but no action taken**
When the Print button is activated, the underlying code checks whether it is enabled. Because the button is disabled and all print logic is either a NULL statement or commented out, no print operation is performed.

**Alternative Flows:**
- **BR-015-AF-01** - (from Step 1) All GENERAL.PRINT_REPORT logic is commented out and does not execute. (COMMENTED OUT / INACTIVE - does not execute)

---

---

#### Requirement ID: BR-016

**Requirement Title:** Save Function (Inactive - Does Not Execute)

**Business Description:**
A Save button is present on the toolbar; however, its underlying code body contains only a NULL statement and no save logic is implemented. Clicking the Save button produces no result and does not persist any data.

(COMMENTED OUT / INACTIVE - does not execute)

**Actors:** Report User

**Preconditions:**
- The Service Ratio report screen is open.

**Main Flow:**

**Step 1 - Save triggered but no action taken**
When the Save button is clicked, the underlying code body executes - but its entire content is a NULL statement; no commit, no validation, and no data persistence takes place.

---

---

#### Requirement ID: BR-017

**Requirement Title:** Exit the Service Ratio Report Screen

**Business Description:**
When the report user clicks the Exit button or uses the exit keyboard shortcut, the system closes the Service Ratio report screen immediately without saving or validating any data. As part of the exit process, the system also clears the database session tracking information that was set when the screen was opened, so that the session is no longer attributed to this screen in database monitoring.

**Actors:** Report User

**Preconditions:**
- The Service Ratio report screen is open.

**Main Flow:**

**Step 1 - Form closed without validation**
The user clicks the Exit button or activates the exit shortcut. The system immediately closes the Service Ratio report screen without prompting to save or validating any entered data.

**Step 2 - Session tracking information cleared**
After closing the screen, the system clears the client information and module name that were registered in the database session when the screen opened, resetting them to null and empty values respectively. This ensures that database monitoring no longer attributes activity to the Service Ratio screen.

---

## 5. Business Rules Catalogue

Catalogue of the discrete business rules enforced by the form's code.

| Rule ID | Rule Name | Rule Type | Business Requirement ID | Condition | Action | Business Impact |
| ------- | --------- | --------- | ----------------------- | --------- | ------ | --------------- |
| BRC-001 | Consignee Code is required | Validation | BR-003 | Consignee Code field is left blank when the user moves to another field | Block the move, display *"consignee code cannot be null"*, and keep the cursor on the Consignee Code field | Prevents the report from being generated without the consignee scope that determines which dealers' data is included |
| BRC-002 | State is required | Validation | BR-004 | State field is left blank when the user moves to another field | Block the move, display *"State cannot be null"*, and keep the cursor on the State field | Prevents the report from running without a geographic filter; ensures results are scoped to a valid state |
| BRC-003 | Dealer Name is required | Validation | BR-005 | Dealer Name field is left blank when the user moves to another field | Block the move, display *"dealer_name cannot be null"*, and keep the cursor on the Dealer Name field | Prevents the report from running without a dealer scope; ensures results relate to identified dealers |
| BRC-004 | Location is required | Validation | BR-006 | Location field is left blank when the user moves to another field | Block the move, display *"Location cannot be null"*, and keep the cursor on the Location field | Prevents the report from running without a location filter; ensures results are scoped to the correct dealer site |
| BRC-005 | From Date is required | Validation | BR-007 | From Date field is left blank when the user moves to another field | Block the move, display *"enter from date"*, and keep the cursor on the From Date field | Prevents the report from running without a defined start date, which would make the reporting period undefined |
| BRC-006 | To Date is required | Validation | BR-008 | To Date field is left blank when the user moves to another field | Block the move, display *"enter to date"*, and keep the cursor on the To Date field | Prevents the report from running without a defined end date, which would make the reporting period undefined |
| BRC-007 | Summary Report Type disables part-level filters | Derivation | BR-009 | Report Type is set to Summary | Disable and make non-navigable both the Root Part Number and Part Number filter fields | Prevents users from entering part filters that are irrelevant to summary-level reports, reducing confusion and invalid filter combinations |
| BRC-008 | Non-Summary Report Type enables part-level filters | Derivation | BR-009 | Report Type is set to any value other than Summary | Enable and make navigable both the Root Part Number and Part Number filter fields | Allows users to optionally narrow the report to specific part families or individual parts when running part-level or group reports |
| BRC-009 | Group Report Type locks Sale Type to Customer | Derivation | BR-009 | Report Type is set to Group | Automatically set Sale Type to Customer and disable and make non-navigable the Sale Type field | Group reports apply only to customer sales; locking Sale Type prevents users from selecting an incompatible sale channel for this report type |
| BRC-010 | Non-Group Report Type releases Sale Type | Derivation | BR-009 | Report Type is set to any value other than Group | Enable and make navigable the Sale Type field | Allows users to freely choose the sale channel filter for part-level and summary reports |
| BRC-011 | Confirmation required before discarding unsaved filter changes | Validation | BR-011 | Cancel button is clicked while filter values have been changed | Display the confirmation prompt *"Entered data will not be Saved"*; clear the form only if the user confirms | Protects the user from accidentally discarding filter criteria they have already entered |
| BRC-012 | Insert operation not permitted | Constraint | BR-012 | Insert button is enabled and the user activates it | Display *"This Operation Cannot be performed Here"*; do not insert any record | Enforces that the Service Ratio screen is a reporting-only screen with no data entry capability |
| BRC-013 | Delete operation not permitted | Constraint | BR-013 | Delete button is enabled and the user activates it | Display *"This Operation Cannot be performed Here"*; do not delete any record | Enforces that the Service Ratio screen is a reporting-only screen with no data modification capability |
| BRC-014 | Excel output file path must not contain spaces | Constraint | BR-010 | The generated output filename path contains a space character in one of the folder names | Redirect the file to the C drive root, display *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."*, and continue generating the file | Prevents file-write failures caused by folder name spaces that the server-side file API cannot handle |
| BRC-015 | Excel output row count capped at 65,535 | Constraint | BR-010 | The number of rows returned by the report query exceeds 65,536 | Truncate the output to 65,535 rows, display *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."*, and continue writing the file | Prevents generating a file that exceeds the maximum number of rows supported by standard Excel spreadsheets |

**Total Business Rules Identified: 15**

---

## 6. Data Requirements

*This section covers the reference entities read by the Service Ratio report, the filter criteria captured on screen, the reference data used for lookups, and the lifecycle of the report parameters during a session.*

### 6.1 Business Entities and Relationships

*The Service Ratio report reads data from several business entities representing dealer locations, service orders, workshop repair orders, and parts catalogues. No data is written back to any of these entities by this form; all access is read-only for reporting purposes.*

#### Dealer Location and Company - AM_DEALER_LOC / AM_DEALER_LOC_COMPANY_MASTER

The Dealer Location entity holds information about each dealer site: its consignee code, dealer name, parent group, outlet code, location code, state, city, and company affiliation. The Company Master entity provides the company-to-dealer mapping used to scope data to the correct principal. This form reads from these tables to populate the consignee, dealer, and location lookup lists, and to join dealer context to sales and workshop order data in the report queries.

#### Sales Order Header and Detail - PH_SO / PD_SO

The Sales Order entities hold customer sales transactions. The header table (PH_SO) records the dealer, location, parent group, sales date, and party type of each order. The detail table (PD_SO) records the individual part lines within each order, including ordered quantity, billed quantity, and the associated part number. These entities are the primary source for customer-sales service ratio calculations.

#### Repair Order and Parts Requirement - VH_RO / VT_REQ

The Repair Order entities hold workshop service transactions. The header table (VH_RO) records the dealer, location, and repair order date. The detail table (VT_REQ) records each part requested within a repair order, including requested quantity, picked quantity, issued quantity, and the request date. These entities are the primary source for warranty/workshop service ratio calculations.

#### Parts Catalogue - PM_PART / PM_PART_VAR

The Parts Catalogue entity (PM_PART) holds the master list of parts for a given principal: part number, root part number, category code, and dealer mapping. Only parts with a main category classification are included in ratio calculations. The Part Variant entity (PM_PART_VAR) holds the pricing data (overseas and local sell price) used when calculating value-based service ratios.

#### Geographic and Reference Data - GM_CITY / GM_STATE / AM_LIST

The City master (GM_CITY) provides city descriptions matched to dealer locations for summary-level reports. The State master (GM_STATE) provides state descriptions and is used to populate the State filter lookup list. The Reference List entity (AM_LIST) provides categorised lookup values; in this form it is used to resolve party type codes to customer segment descriptions for group-level reports.

#### Entity Relationships

The Service Ratio report joins its source entities as follows: each sales or workshop order header is matched to a dealer location through shared dealer, location, and parent group keys. Parts in order detail lines are matched to the parts catalogue on part number and principal. City and geographic descriptions are joined to dealer locations on city and state codes. Pricing data in the part variant table is joined to part-level order data by part number and location keys.

```
AM_DEALER_LOC (dealer scope and filtering)
    ├── AM_DEALER_LOC_COMPANY_MASTER (company/principal mapping)
    ├── PH_SO (customer sales order header)
    │       └── PD_SO (customer sales order detail lines)
    ├── VH_RO (workshop repair order header)
    │       └── VT_REQ (workshop parts requirement lines)
    └── GM_CITY (city description for summary reports)
PM_PART (parts catalogue - joined via part number on PD_SO / VT_REQ)
    └── PM_PART_VAR (part pricing - joined for value-based reports)
GM_STATE (geographic master - joined for state lookup)
AM_LIST (party type reference - joined for group reports)
```

### 6.2 Data Capture Requirements

*The form captures filter and parameter values in the control block; no data is entered for persistence. Mandatory fields must be provided before the Excel report can be generated.*

#### Report Filter Criteria (entered by the report user before generating a report)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Consignee Code (`CONSG_CD`) | Yes | Identifies the consignee whose dealer network is to be reported on; defaults to ALL (all consignees) | Must not be blank; validated when the user moves off the field |
| State (`STATE_CD`) | Yes | Geographic state filter; used to scope summary-level reports by state | Must not be blank; validated when the user moves off the field |
| Dealer Name (`DEALER_NAME`) | Yes | Name of the dealer to include in the report; defaults to ALL (all dealers) | Must not be blank; validated when the user moves off the field |
| Location (`LOC_CD`) | Yes | Dealer location code filter; defaults to ALL (all locations) | Must not be blank; validated when the user moves off the field |
| From Date (`P_FROMDT`) | Yes | Start date of the reporting period; defaults to today's date on screen open | Must not be blank; format dd/mm/rrrr; validated when the user moves off the field |
| To Date (`P_TODT`) | Yes | End date of the reporting period; defaults to today's date on screen open | Must not be blank; format dd/mm/rrrr; validated when the user moves off the field |
| Report Type (`REPORT_TYPE`) | Yes | Determines the level of grouping in the report: Part-level (P), Summary (S), or Group (G) | Required list selection; controls whether part filters are available and whether Sale Type is locked |
| Sale Type (`SALE_TYPE`) | Yes | Filters transactions by sale channel: Customer (C), Warranty (W), or Both (B); auto-set to Customer when Report Type is Group | Required list selection; locked to Customer when Report Type = Group |
| Based On (`REP_CATG`) | Yes | Determines the calculation basis for the ratio: Lines (L), Quantity (Q), or Value (V) | Required list selection |
| Ratio (`RATIO`) | Yes | Filters ratio results: Full (F - 100% only), Low (L - below 100%) | Required list selection |
| Root Part Number (`ROOT_PART_NUM`) | No | Optional filter to restrict the report to parts within a specific root part family | Available only when Report Type is not Summary; optional |
| Part Number (`PART_NUM`) | No | Optional filter to restrict the report to a specific individual part number | Available only when Report Type is not Summary; optional |

#### Session and Internal Parameters

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Parent Group (`PARENT_GROUP`) | Auto-Populated | Internal filter representing the dealer's parent group; defaults to ALL on form open; injected into report queries | Set automatically at form open; used in report query filters |
| Where Clause - General (`P_WHERE_CLAUSE`) | Auto-Populated | Internal parameter holding the dynamically built root part number filter clause | Cleared before each report run; populated only if Root Part Number is entered |
| Where Clause - Customer Sales (`P_WHERE_CLAUSE_CS`) | Auto-Populated | Internal parameter holding the customer-sales part number filter clause | Cleared before each report run; populated only if Part Number is entered |
| Where Clause - Workshop (`P_WHERE_CLAUSE_WS`) | Auto-Populated | Internal parameter holding the workshop-orders part number filter clause | Cleared before each report run; populated only if Part Number is entered |

### 6.3 Reference Data

*Lists the master and configuration data referenced by this form (LOVs, record groups, master tables).*

| Reference Data | Business Purpose | Used When |
| :--- | :--- | :--- |
| Consignee Lookup (LV_CONSG / RG_CONSG) | Provides the list of valid consignees from the dealer location master, scoped to the current principal and parent group; includes an ALL option | When the user clicks into or uses the list on the Consignee Code filter field |
| Dealer Lookup (LV_DEALER / RG_DEALER) | Provides the list of valid dealer names and their parent groups, filtered to the current principal, parent group, and selected consignee; includes an ALL option for multi-dealer principals | When the user clicks into or uses the list on the Dealer Name filter field |
| Location Lookup (LV_LOC / RG_LOC) | Provides the list of valid location descriptions and codes from the dealer location master, filtered to the current principal, parent group, and consignee; includes an ALL option | When the user clicks into or uses the list on the Location filter field |
| State Lookup (LV_STATE / RG_STATE) | Provides the list of valid state descriptions and codes, derived by joining the geographic state master to the dealer location master filtered to the current principal and consignee; includes an ALL option | When the user clicks into or uses the list on the State filter field |
| Dealer Location Master (AM_DEALER_LOC) | Master dealer site data used to scope report results by consignee, parent group, location, and state | During all report query executions and when populating filter lookups |
| Dealer Location Company Master (AM_DEALER_LOC_COMPANY_MASTER) | Company-to-dealer mapping used to restrict data to the correct principal's dealers | During all report query executions and when populating filter lookups |
| Parts Catalogue (PM_PART) | Master parts list for a given principal; provides part number, root part number, and category; only main-category parts included | During all report query executions |
| Parts Variant / Pricing (PM_PART_VAR) | Provides overseas and local sell prices for individual parts | During Value-based (V) report query executions only |
| Sales Order Header (PH_SO) | Customer sales transaction header data; source of customer-channel ratio data | During Part-level and Group report query executions where Sale Type includes Customer sales |
| Sales Order Detail (PD_SO) | Customer sales line data with ordered and billed quantities | During Part-level and Group report query executions where Sale Type includes Customer sales |
| Workshop Repair Order Header (VH_RO) | Workshop service transaction header; source of warranty/workshop-channel ratio data | During Part-level and Group report query executions where Sale Type includes Warranty/Workshop |
| Workshop Parts Requirement (VT_REQ) | Workshop parts request lines with requested and issued quantities | During Part-level and Group report query executions where Sale Type includes Warranty/Workshop |
| City Master (GM_CITY) | Provides city descriptions for dealer locations | During Summary-level report query executions |
| State Master (GM_STATE) | Provides state descriptions; populates the State filter lookup | When populating the State lookup list (RG_STATE) |
| Party Type Reference List (AM_LIST) | Provides customer segment descriptions mapped from party type codes on sales orders | During Group-level report query executions |
| Report Server Path Configuration (`/reports/DMS/excelpath.txt`) | Holds the server-side URL base path used to deliver the generated CSV file to the user's browser | At the time the Excel Report button is clicked and the file download URL is being assembled - EXTERNAL / NOT IN BUNDLE |

### 6.4 Data Lifecycle

*Describes how records are created, updated, and saved within this form's evidenced behaviour.*

**Creation**

- No records are created by this form. The form is a read-only reporting screen. The only output is a CSV file written to a server path and opened in the user's browser.

**Updates**

- No database records are updated by this form. Filter field values in the control block are held in memory for the duration of the session and are discarded when the form is cleared or closed.

**Save and Commit**

- There is no save or commit operation. The FT_SAVE trigger contains only a NULL statement and performs no data persistence. The form does not commit any data to the database.

**Retention and Audit**

- No audit trail is created by this form. Session registration (via DBMS_APPLICATION_INFO) is set at form open and cleared at form close; this is a monitoring aid, not a business audit trail. The generated CSV file is written to the application server and opened in the browser; no file retention policy is implemented within the form.

---

### 6.5 Excel Output Columns

This form does not use Excel download. No Excel export columns were identified in the form sources.

## 7. Glossary

*Definitions of terms, abbreviations, and acronyms used throughout this document.*

The following table defines key terms, acronyms, and abbreviations used throughout this Business Requirements Document.

| Term | Definition | Aliases | Related Terms |
| :--- | :--- | :--- | :--- |
| ALL | Wildcard selection value indicating that no restriction is applied and all available records are included | - | Filter, Consignee, Dealer, Location |
| AM_DEALER_LOC | Dealer location master table - stores dealer, consignee, location, state, and principal map data used to populate LOVs and filter the service ratio query | Dealer Location Master | Consignee, Dealer, LOC_CD |
| APP_LOG | Application logging global flag ('Y'/'N'); controls whether form activity is recorded in the application log | - | Global Variable |
| B | Both - sale type selector value indicating that both Counter Sales and Workshop transactions are included in the report | Both | Sale Type, Counter Sales, Workshop |
| BRD | Business Requirements Document - formal document capturing functional and technical requirements for a system module | - | - |
| BTL | Example location code value (e.g. a specific dealer branch); used in global variable LOC_CD | - | LOC_CD, Location |
| C | Counter Sales - sale type selector value indicating that only counter-sale (PH_SO/PD_SO) transactions are included | Counter Sales | Sale Type, Workshop, Both |
| Consignee | Authorised dealer/distributor entity identified by a consignee code; used to scope the service ratio report | CONSG_CD | Dealer, Principal |
| CSV | Comma-Separated Values - file format used to export the service ratio query results for offline analysis | Excel Export | Service Ratio, Export |
| Currency | Global variable holding the currency symbol (e.g. 'Rs') used as a display/formatting reference for monetary values | - | Global Variable |
| Dealer | Dealer organisation in the DMS whose parts service fill-rate is being measured and reported | DEALER_NAME | Consignee, LOC_CD |
| DMS | Dealer Management System - integrated software platform for dealership operations within which pe_srv_ratio operates | - | Service Ratio, Parts |
| DPL | Shared PL/SQL program library (DPL.pld) providing common utility routines such as ASK_CONFIRM, DISP_TEXT, and l_pop_list_item | DPL.pld | PLD, Library |
| F | Full - ratio filter value indicating that only records with a 100% service fill rate are included | Full | Ratio, Fill Rate |
| Fill Rate | Measure of how completely parts orders are fulfilled; expressed as Lines, Quantity, or Value percentage | Service Ratio | REP_CATG, Ratio |
| FIN_BEG | Financial year begin date global variable; defines the start boundary of the fiscal period | - | Global Variable, FIN_END |
| FIN_END | Financial year end date global variable; defines the end boundary of the fiscal period | - | Global Variable, FIN_BEG |
| G | Group / Customer-segment - report type selector value; SALE_TYPE is fixed to 'C' when this type is chosen | Group | Report Type, REPORT_TYPE |
| GM_STATE | State master table - stores state codes and descriptions mapped to regions; joined with AM_DEALER_LOC for the state LOV | State Master | State, AM_DEALER_LOC |
| Global Variable | Form-session variable prefixed with ':GLOBAL.' used to pass context values (company, dealer, fiscal year, user) into the form from a parent calling form | - | PRINCIPAL, USERID, LOC_CD |
| L | (1) Lines - report category value measuring order-line fill rate; (2) Less than 100% - ratio filter value restricting results to records below full fill rate | Lines / Less than 100% | REP_CATG, Ratio, Fill Rate |
| LOC_CD | Location code - identifies the specific dealer branch or outlet used as a report scope filter | Location Code | Dealer, Consignee |
| LOV | List of Values - pop-up selection list in Oracle Forms used to look up and return valid values for filter fields | Pick-list, Dropdown | RG_CONSG, RG_DEALER, RG_LOC, RG_STATE |
| P | Part-wise - report type selector value generating a part-level service ratio breakdown | Part-wise | Report Type, REPORT_TYPE |
| P_FIN_YR | Financial year label global variable (e.g. '2012') used for fiscal year identification | - | Global Variable, FIN_BEG, FIN_END |
| PART_NUM | Optional individual part number filter field; narrows the service ratio report to a specific spare part | Part Number | ROOT_PART_NUM |
| PRINCIPAL | Principal (manufacturer) map code global variable; key multi-organisation discriminator applied to all LOV and data queries | Principal Map Code | Global Variable, Consignee |
| PLD | Program Library Definition - shared Oracle Forms PL/SQL library (*.pld) providing reusable procedures and functions | Program Library | DPL, Library |
| Q | Quantity - report category value measuring fill rate by quantity of items ordered versus supplied | Quantity | REP_CATG, Fill Rate, Lines |
| REP_CATG | Report category selector - controls the fill-rate metric: Lines (L), Quantity (Q), or Value (V) | Report Category | Fill Rate, Ratio |
| REP_SERVER | Report server global variable; holds the Oracle Reports server name used when launching server-side reports | - | Global Variable |
| REPORT_TYPE | Report scope selector: Part-wise (P), Dealer/Summary (S), or Group/Customer-segment (G) | - | REP_CATG, Sale Type |
| ROOT_PART_NUM | Optional root part number filter field; narrows results to all parts under the specified root part number | Root Part Number | PART_NUM |
| S | Dealer/Summary - report type selector value generating a dealer-level summary; PART_NUM and ROOT_PART_NUM are disabled when this type is selected | Summary | Report Type, REPORT_TYPE |
| Sale Type | Selector controlling which transaction source is included in the report: Counter Sales (C), Workshop (W), or Both (B) | SALE_TYPE | Report Type, Counter Sales, Workshop |
| Service Ratio | Parts service fill-rate metric measuring the proportion of parts orders fulfilled; the primary output of the pe_srv_ratio report | Fill Rate | REP_CATG, Ratio |
| TALLY_INTEGRATION | Tally accounting integration global flag ('Y'/'N'); indicates whether Tally integration is active for the current session | - | Global Variable |
| USERID | Logged-in user's login ID global variable; used to generate unique CSV file names during export | User ID | Global Variable, USER_NAME |
| USER_NAME | Logged-in user's display name global variable; referenced in report generation | - | Global Variable, USERID |
| V | Value - report category value measuring fill rate by monetary value of orders fulfilled | Value | REP_CATG, Fill Rate, Quantity |
| W | Workshop - sale type selector value indicating that only workshop-sale (VT_REQ/VH_RO) transactions are included | Workshop | Sale Type, Counter Sales, Both |

---

---

## 8. Technical Inventory

*Complete inventory of Oracle Forms components including blocks, items, triggers, canvases, and global variables.*

### 8.1 Form Architecture

**Form Module Details:**

- Form Name: pe_srv_ratio (PE_SRV_RATIO)
- Form Module XML Title: MODULE3
- Oracle Forms Version: 12c (Module version 122010400)
- Parent Object Library: -
- Attached Libraries: DPL (DPL.pld program library), WEBUTIL (webutil.olb), D2KWUTIL
- First Navigation Block: -
- Console Window: WINDOW1 (hidden infrastructure window; WN_MAIN is the primary user-facing window titled "Service Ratio Report (Rel : 2.3.1)")
- Compile Dependencies: Requires DPL.pld, WEBUTIL.olb, menu.mmx, database packages PK_PART_SEARCH_NEW
- Source artifacts: `pe_srv_ratio_fmb.xml`; DPL (DPL.pld program library); WEBUTIL (webutil.olb); D2KWUTIL

### 8.1.1 Global Variables

| Global Variable | Data Type | Set Location | Purpose |
| :--- | :--- | :--- | :--- |
| APP_LOG | Char | Trigger | Application logging flag ('Y'/'N'); controls whether form activity is written to the application log |
| COMP_FA | Char | Trigger | Company/financial-accounting code; identifies the company entity used in multi-organisation queries |
| CURRENCY | Char | Trigger | Currency symbol (e.g. 'Rs'); used as a display/formatting reference for monetary values |
| DEALER | Number | Trigger | Dealer numeric identifier; scopes dealer-level data and record group queries |
| FIN_BEG | Char | Trigger | Financial year begin date (e.g. '01-APR-2011'); defines the start boundary of the fiscal period |
| FIN_END | Char | Trigger | Financial year end date (e.g. '31-MAR-2012'); defines the end boundary of the fiscal period |
| LOC_CD | Char | Trigger | Location code (e.g. 'BTL'); filters reports and LOVs to a specific dealer location |
| PARENT_GROUP | Char | RecordGroup / Trigger | Parent dealer group code; '99999' means all groups; drives AM_DEALER_LOC filtering in record groups |
| PRINCIPAL | Char | RecordGroup / Trigger | Principal (manufacturer) map code; key multi-organisation discriminator used in all major queries |
| P_FIN_YR | Char | Trigger | Financial year label string (e.g. '2012'); used for fiscal year identification in reports |
| REP_SERVER | Char | Trigger | Oracle Reports server name (e.g. 'MULTEST'); passed to RUN_REPORT_OBJECT calls when launching reports |
| TALLY_INTEGRATION | Char | Trigger | Tally integration flag ('Y'/'N'); indicates whether Tally accounting integration is active |
| USERID | Char | ProgramUnit / Trigger | Logged-in user's login ID; used to generate unique CSV file names in the Excel export routine |
| USER_NAME | Char | Trigger | Logged-in user's display name; referenced in report generation for user identification |

### 8.1.2 Form Parameters

*All 3 ModuleParameter entries from pe_srv_ratio_fmb.xml.*

| Parameter | Data Type | Default | Description |
| :--- | :--- | :--- | :--- |
| P_WHERE_CLAUSE_CS | Char | - | Carries the counter-sales part-number filter clause (for PH_SO/PD_SO sale types); built and appended when a PART_NUM value is entered before exporting to Excel |
| P_WHERE_CLAUSE_WS | Char | - | Carries the workshop-sales part-number filter clause (for VT_REQ/VH_RO sale types); built and appended when a PART_NUM value is entered before exporting to Excel |
| P_WHERE_CLAUSE | Char | - | Carries the root part number filter clause; appended to both counter-sales and workshop-sales query branches when ROOT_PART_NUM is specified |

**Total Parameters:** 3

### 8.2 Blocks

| Block Name | Query Data Source | Records | Q/I/U/D | Key Mode | Master-Detail Relationship |
| :--- | :--- | :--- | :--- | :--- | :--- |
| CNTRL_BLK | - | 1 | N/N/N/N | Default | Control - report parameter entry block; no master-detail relationship |
| CB_ERR | - | 15 | N/N/N/N | Default | Control - error message display block; no master-detail relationship |
| PB_BLK | - | 1 | N/N/N/N | Default | Control - toolbar push-button block; no master-detail relationship |

**Total Blocks:** 3 business blocks

### 8.2.1 Block WhereClause and OrderByClause

*Block query scope from pe_srv_ratio_fmb.xml. **Description** explains filter and sort in business terms; **Order By** and **Where Clause** columns retain verbatim XML text for migration.*

| Block | Description | Order By (XML) | Where Clause (XML) |
| :--- | :--- | :--- | :--- |
| - | No blocks with WhereClause/OrderByClause in pe_srv_ratio_fmb.xml | - | - |

### 8.3 Items Summary

*Complete item inventory from `pe_srv_ratio_fmb.xml`.*

**Block counts:**

*Database / non-database counts derived from XML.*

| Block | Total Items | Database Items | Non-Database Items |
| :--- | ---: | ---: | ---: |
| CNTRL_BLK | 15 | 0 | 15 |
| CB_ERR | 1 | 0 | 1 |
| PB_BLK | 11 | 0 | 11 |
| **Total** | **27** | **0** | **27** |

**Item detail (all 27 items):**

| Block | Item Name | DatabaseItem | Description |
| :--- | :--- | :--- | :--- |
| CNTRL_BLK | PARENT_GROUP | false | Holds the parent dealer group code; pre-populated with 'ALL' at form startup; used in LOV query filtering |
| CNTRL_BLK | CONSG_CD | false | Consignee code filter; LOV-driven; user selects the consignee to scope the service ratio report |
| CNTRL_BLK | STATE_CD | false | State code filter; LOV-driven; user selects the geographic state for the report |
| CNTRL_BLK | DEALER_NAME | false | Dealer name filter; LOV-driven; user selects the dealer whose service ratio is being reported |
| CNTRL_BLK | LOC_CD | false | Location code filter; LOV-driven; user selects the dealer location to include in the report |
| CNTRL_BLK | P_FROMDT | false | Report from-date; defaulted to current date; defines the start of the reporting period |
| CNTRL_BLK | P_TODT | false | Report to-date; defaulted to current date; defines the end of the reporting period |
| CNTRL_BLK | REPORT_TYPE | false | Report scope selector: 'P' = Part-wise, 'S' = Dealer/Summary, 'G' = Group/Customer-segment |
| CNTRL_BLK | SALE_TYPE | false | Sale type selector: 'C' = Counter Sales, 'W' = Workshop, 'B' = Both |
| CNTRL_BLK | REP_CATG | false | Report category: 'L' = Lines fill rate, 'Q' = Quantity fill rate, 'V' = Value fill rate |
| CNTRL_BLK | RATIO | false | Ratio filter: 'F' = Full (100%), 'L' = Less than 100%; filters results by service fill rate |
| CNTRL_BLK | ROOT_PART_NUM | false | Optional root part number filter; narrows the report to parts under a specific root part |
| CNTRL_BLK | PART_NUM | false | Optional individual part number filter; narrows the report to a specific spare part |
| CNTRL_BLK | PB_EXCEL | false | Export to Excel button; triggers dynamic query construction and CSV file generation |
| CNTRL_BLK | QUERY | false | Internal display field storing the last dynamically constructed SQL query string |
| CB_ERR | TXT_ERR | false | Read-only display field showing error or informational messages in the error canvas |
| PB_BLK | PB_EXIT | false | Exit button; closes the form without saving |
| PB_BLK | PB_LIST | false | List of Values button; opens the LOV for the currently focused field |
| PB_BLK | PB_INSERT | false | Insert button; always displays "This Operation Cannot be performed Here" - insert is blocked |
| PB_BLK | PB_DEL | false | Delete button; always displays "This Operation Cannot be performed Here" - delete is blocked |
| PB_BLK | PB_CANCEL | false | Cancel button; prompts to confirm before discarding entered filter criteria |
| PB_BLK | PB_SAVE | false | Save button; executes no action - save is not applicable for this report parameter screen |
| PB_BLK | PB_PRINT | false | Print button; currently a stub - no print action is executed |
| PB_BLK | PB_CUT | false | Cut button; performs cut operation on the selected text region |
| PB_BLK | PB_COPY | false | Copy button; performs copy operation on the selected text region |
| PB_BLK | PB_PASTE | false | Paste button; performs paste operation into the currently focused field |
| PB_BLK | PB_ERR_EXIT | false | OK button (label); closes the error information window |

### 8.4 List of Values

| LOV Name | Title | Record Group | Attached Block.Item |
| :--- | :--- | :--- | :--- |
| LV_CONSG | Consignee codes | RG_CONSG | CNTRL_BLK.CONSG_CD |
| LV_DEALER | Dealer Name | RG_DEALER | CNTRL_BLK.DEALER_NAME |
| LV_LOC | Location | RG_LOC | CNTRL_BLK.LOC_CD |
| LV_STATE | State | RG_STATE | CNTRL_BLK.STATE_CD |

**Total LOVs:** 4

### 8.5 Alerts

| Alert Name | Title | Message Text | Calling Context |
| :--- | :--- | :--- | :--- |
| AL_ERRINFO | Error | (set at runtime) | ProgramUnit: DISP_TEXT (DPL.pld) when title = 'ERROR'; invoked from CHECK_NULL, CHECK_FORM_FAILURE, EXC_QUERY, and validation triggers |
| AL_NOTE | Note | (set at runtime) | ProgramUnit: DISP_TEXT (DPL.pld) when title ≠ 'ERROR'; invoked from RAISE_ERROR (type 'N'), RUN_REPORT, and informational message paths |
| AL_CONFIRM | Caution | (set at runtime) | ProgramUnit: ASK_CONFIRM (DPL.pld); called from Trigger: FT_CANCEL in Form (confirm discard), and PRINT_REPORT (confirm print and order-by) |
| AL_PRINT | Print | (set at runtime) | ProgramUnit: ASK_PRINT (DPL.pld); called from any routine requiring print destination selection (Screen / Printer / Cancel) |

**Total Alerts:** 4

### 8.6 Program Units

*Authoritative catalogue of **1 form-local program units**. Database packages and standalone procedures are in **Section 15.2**; PLD shared-library routines are in **Section 18**.*

| Program Unit | Type | Calls | Description |
| :--- | :--- | :--- | :--- |
| VIEW_EXCEL_REP | Procedure | Find_Group, Delete_Group, Create_Group_From_Query, Populate_Group, Get_Group_Row_Count, Find_Column, Get_Group_Char_Cell, Text_IO.Fopen, Text_IO.Put_Line, Text_IO.Fclose, web.show_document, Id_Null (webutil.pld), WEBUTIL_FILE_TRANSFER.URL_TO_CLIENT, WEBUTIL_HOST.HOST | Builds a CSV file from the dynamic service ratio SQL query; reads the query result into a record group, writes each row to a server-side file using Text_IO, then opens the file in the browser via web.show_document |

**Total Program Units:** 1

### 8.7 Triggers

**Item-Level Trigger Types (reference):**

| Trigger Name | Purpose |
| :--- | :--- |
| WHEN-VALIDATE-ITEM | Validates field when user leaves item |
| KEY-* | Keyboard actions - commit, exit, LOV, navigation |
| WHEN-NEW-BLOCK-INSTANCE | Initializes block on entry |
| WHEN-BUTTON-PRESSED | Executes button action |
| PRE-INSERT / POST-INSERT | Before/after record creation |
| WHEN-LIST-CHANGED | Dropdown selection changed |
| PRE-QUERY / POST-QUERY | Before/after query execution |
| WHEN-CHECKBOX-CHANGED | Checkbox toggled |
| WHEN-VALIDATE-RECORD | Validates entire record before leaving row |

**DPL library routines invoked from triggers and program units:**

| Routine | Type | Called From | Purpose |
| :--- | :--- | :--- | :--- |
| GENERAL.ASK_CONFIRM | Library routine | Form level, PB_BLK.PB_EXIT | Displays the AL_CONFIRM alert asking the user to confirm a discard or cancel action; returns the user's choice to the calling trigger |
| GENERAL.DISP_TEXT | Library routine | CNTRL_BLK.CONSG_CD, CNTRL_BLK.DEALER_NAME, CNTRL_BLK.LOC_CD, CNTRL_BLK.PB_EXCEL, CNTRL_BLK.P_FROMDT, CNTRL_BLK.P_TODT, CNTRL_BLK.STATE_CD, Form level | Routes message to AL_ERRINFO (when title = 'ERROR') or AL_NOTE (all other titles); sets alert message text and calls show_alert |
| GENERAL.L_POP_LIST_ITEM | Library routine | Form level | Populates a list item from a named record group; used at form startup and when filter criteria change to refresh LOV-backed list items |
| GENERAL.PRINT_REPORT | Library routine | Form level | Configures and runs an Oracle report; sets server, destination, and format parameters then calls RUN_REPORT_OBJECT; referenced in the commented-out FT_PRINT body |
| WEBUTIL_FILE_TRANSFER.URL_TO_CLIENT | Library routine | ProgramUnit: VIEW_EXCEL_REP | Transfers the generated CSV file from the server to the client machine as part of the Excel export flow |
| WEBUTIL_HOST.HOST | Library routine | ProgramUnit: VIEW_EXCEL_REP | Executes a host operating-system command on the server; used within VIEW_EXCEL_REP to perform file-system operations during CSV generation |

### 8.7.1 Inactive / Commented-Out Trigger Register

*Triggers and field validations where XML source is `null;`, fully block-commented, or legacy code preserved but not executed. Do **not** migrate these as active business requirements.*

| Status | Block | Item | Trigger | Former behaviour (preserved in comments) | Disabled since / note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Commented out** | Form | - | FT_PRINT | Would have called GENERAL.PRINT_REPORT to print the GM_ZONE (Zone Master) table with columns ZONE_CD and ZONE_DESC | Body replaced with NULL; print functionality removed; stub retained for compatibility |
| **Commented out** | Form | - | WHEN-NEW-FORM-INSTANCE | Would have set DEFAULT_VALUE for 14 global variables (PRINCIPAL, PARENT_GROUP, DEALER, LOC_CD, CURRENCY, COMP_FA, REP_SERVER, P_FIN_YR, USER_NAME, USERID, APP_LOG, FIN_BEG, FIN_END, TALLY_INTEGRATION) and called L_POP_LIST_ITEM for a TEST_DRIVE vehicle list | Global initialization removed; all globals are now expected to be set by a calling/parent form |
| **Inactive stub** | Form | - | FT_SAVE | Previously would have committed data; body is now NULL - save is not applicable for this report parameter screen | Replaced with NULL; form is a parameter entry screen only, no database records to save |
| **Commented out** | PB_BLK | PB_EXIT | WHEN-BUTTON-PRESSED | Previously checked form-changed state; if changed asked ASK_CONFIRM before calling do_key('exit_form'); also handled ENTER-QUERY mode check | Replaced with simple `exit_form(no_validate)`; confirm-before-exit logic removed |

*Additional null-only or partially commented triggers exist on estimation and legacy blocks - see XML `TriggerText` starting with `null;` or `/*`.*

**Complete trigger inventory (30 business triggers):**
*pe_srv_ratio_fmb.xml contains Trigger elements.*

| Trigger Name | Block | Item | Called From / Context | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| FT_CANCEL | Form | - | Form level | If PB_CANCEL is enabled: resets PART_NUM, ROOT_PART_NUM, and SALE_TYPE item properties; if form has unsaved changes asks confirmation before clearing; otherwise clears the form immediately |
| FT_INSERT | Form | - | Form level | If PB_INSERT is enabled: displays "This Operation Cannot be performed Here" - insert is not supported on this form |
| FT_DEL | Form | - | Form level | If PB_DEL is enabled: displays "This Operation Cannot be performed Here" - delete is not supported on this form |
| FT_LIST | Form | - | Form level | If PB_LIST is enabled: executes DO_KEY('LIST_VALUES') to open the LOV for the currently focused item |
| FT_PRINT | Form | - | Form level | **COMMENTED OUT / INACTIVE** - If PB_PRINT is enabled: body is NULL; print action is a stub placeholder (inherited) |
| WHEN-NEW-FORM-INSTANCE | Form | - | Form level | Maximizes WN_MAIN window; initialises P_FROMDT and P_TODT to SYSDATE; sets CNTRL_BLK.PARENT_GROUP, DEALER_NAME, and LOC_CD to 'ALL' (inherited) |
| FT_SAVE | Form | - | Form level | **INACTIVE** - If PB_SAVE is enabled: body is NULL; no save action is performed |
| PRE-FORM | Form | - | Form level | Registers application identity with the database: sets client_info and module name to 'pe_srv_ratio' via DBMS_APPLICATION_INFO |
| KEY-EXIT | Form | - | Form level | Calls EXIT_FORM(NO_VALIDATE) and clears DBMS_APPLICATION_INFO client and module registration |
| WHEN-VALIDATE-ITEM | CNTRL_BLK | CONSG_CD | CNTRL_BLK.CONSG_CD | Validates that CONSG_CD is not null; raises form_trigger_failure with error if empty |
| WHEN-VALIDATE-ITEM | CNTRL_BLK | STATE_CD | CNTRL_BLK.STATE_CD | Validates that STATE_CD is not null; raises form_trigger_failure with error if empty |
| WHEN-NEW-ITEM-INSTANCE | CNTRL_BLK | STATE_CD | CNTRL_BLK.STATE_CD | Fires when focus enters STATE_CD; initialises item-level state as needed |
| WHEN-VALIDATE-ITEM | CNTRL_BLK | DEALER_NAME | CNTRL_BLK.DEALER_NAME | Validates that DEALER_NAME is not null; raises form_trigger_failure with error if empty |
| WHEN-NEW-ITEM-INSTANCE | CNTRL_BLK | DEALER_NAME | CNTRL_BLK.DEALER_NAME | Fires when focus enters DEALER_NAME; initialises item-level state as needed |
| WHEN-VALIDATE-ITEM | CNTRL_BLK | LOC_CD | CNTRL_BLK.LOC_CD | Validates that LOC_CD is not null; raises form_trigger_failure with error if empty |
| WHEN-NEW-ITEM-INSTANCE | CNTRL_BLK | LOC_CD | CNTRL_BLK.LOC_CD | Fires when focus enters LOC_CD; initialises item-level state as needed |
| WHEN-VALIDATE-ITEM | CNTRL_BLK | P_FROMDT | CNTRL_BLK.P_FROMDT | Validates that P_FROMDT is not null; raises form_trigger_failure with error if empty |
| WHEN-VALIDATE-ITEM | CNTRL_BLK | P_TODT | CNTRL_BLK.P_TODT | Validates that P_TODT is not null; raises form_trigger_failure with error if empty |
| WHEN-VALIDATE-ITEM | CNTRL_BLK | REPORT_TYPE | CNTRL_BLK.REPORT_TYPE | When 'S': disables and hides PART_NUM and ROOT_PART_NUM; when 'G': forces SALE_TYPE to 'C' and disables it; otherwise re-enables all items |
| WHEN-BUTTON-PRESSED | CNTRL_BLK | PB_EXCEL | CNTRL_BLK.PB_EXCEL | Resets parameters, builds the dynamic service ratio SQL query based on selected REPORT_TYPE, SALE_TYPE, REP_CATG, and RATIO filters, stores it in CNTRL_BLK.QUERY, and calls VIEW_EXCEL_REP to export the result as a CSV file |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EXIT | PB_BLK.PB_EXIT | Calls exit_form(no_validate) to close the form immediately |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_LIST | PB_BLK.PB_LIST | Executes FT_LIST trigger: opens the LOV for the currently focused field |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_INSERT | PB_BLK.PB_INSERT | Executes FT_INSERT trigger: displays unsupported-operation message |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_DEL | PB_BLK.PB_DEL | Executes FT_DEL trigger: displays unsupported-operation message |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CANCEL | PB_BLK.PB_CANCEL | Executes FT_CANCEL trigger: prompts user to confirm before discarding entered filter criteria |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SAVE | PB_BLK.PB_SAVE | Executes FT_SAVE trigger: no action (stub) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PRINT | PB_BLK.PB_PRINT | Executes FT_PRINT trigger: no action (stub) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CUT | PB_BLK.PB_CUT | Performs cut_region operation on the selected text |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_COPY | PB_BLK.PB_COPY | Performs copy_region operation on the selected text |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PASTE | PB_BLK.PB_PASTE | Performs paste_region operation into the focused field |

### 8.8 Canvas and Window Inventory

**Windows:**

| Window | Title | Primary Canvas |
| :--- | :--- | :--- |
| WINDOW1 | - | - |
| WN_MAIN | Service Ratio Report (Rel : 2.3.1) | CN_MAIN |
| WIN_ERR | Errors | CN_ERR |

**Canvases:**

| Canvas | Type | Window |
| :--- | :--- | :--- |
| CN_ERR | Stacked | WIN_ERR |
| CN_MAIN | Content | WN_MAIN |
| CN_TOOL | Vertical Toolbar | WN_MAIN |

---

### 8.9 Editors

*No editors found in pe_srv_ratio_fmb.xml.*

### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

#### 8.10.1 Visual Attributes (form-defined)

*15 VisualAttribute elements defined at form level (not inherited from DPL.olb).*

| Visual Attribute |
| :--- |
| VA_DISP |
| VA_LOV |
| VA_TRNI_DT |
| VA_TITLE |
| VA_ALERT |
| VA_BUTN |
| VA_TEXT |
| VA_MPROMPT |
| VA_OPROMPT |
| VA_MAND |
| VA_NUM |
| VA_DESC |
| VA_ICONIC_BUTN |
| VA_RB |
| VA_CB |

#### 8.10.2 Property Classes (form-defined)

*Form-local PropertyClass elements.*

*No form-local property classes found in pe_srv_ratio_fmb.xml.*

#### 8.10.3 Object Groups

*Object groups bundle inherited triggers and visual objects applied form-wide at runtime.*

| Object Group Child | Type |
| :--- | :--- |
| CN_ERR | Inherited canvas |
| VA_DISP | Inherited visualattribute |
| CB_ERR | Inherited block |
| VA_LOV | Inherited visualattribute |
| VA_TRNI_DT | Inherited visualattribute |
| VA_TITLE | Inherited visualattribute |
| VA_ALERT | Inherited visualattribute |
| VA_BUTN | Inherited visualattribute |
| VA_TEXT | Inherited visualattribute |
| VA_MPROMPT | Inherited visualattribute |
| VA_OPROMPT | Inherited visualattribute |
| VA_MAND | Inherited visualattribute |
| VA_NUM | Inherited visualattribute |
| VA_DESC | Inherited visualattribute |
| VA_ICONIC_BUTN | Inherited visualattribute |
| VA_RB | Inherited visualattribute |
| VA_CB | Inherited visualattribute |
| WN_MAIN | Inherited window |
| POP_MAIN | Inherited trigger |
| CN_MAIN | Inherited canvas |
| CN_TOOL | Inherited canvas |
| PB_BLK | Inherited block |
| AL_ERRINFO | Inherited alert |
| AL_NOTE | Inherited alert |
| AL_CONFIRM | Inherited alert |
| WIN_ERR | Inherited window |
| AL_PRINT | Inherited alert |
| FT_CANCEL | Inherited trigger |
| FT_INSERT | Inherited trigger |
| FT_DEL | Inherited trigger |
| FT_LIST | Inherited trigger |
| FT_PRINT | Inherited trigger |
| WHEN-NEW-FORM-INSTANCE | Inherited trigger |

### 8.11 DataSourceColumn Inventory

*No DataSourceColumns found in pe_srv_ratio_fmb.xml.*

## 9. Object Library

*The PE_SRV_RATIO form defines its visual attributes and object group directly within its own form module. No external Object Library (.olb) file was supplied in the source directory; the entries below are sourced from the form's own XML.*

Source OLB file(s): none supplied

| Name | Type | Description | Used By (count) | Sample Items |
| ---- | ---- | ----------- | --------------- | ------------ |
| VA_DISP | VisualAttribute | Display-style text attribute - Arial, 8pt, Bold, black foreground | 0 items directly; member of OG_GROUP | referenced |
| VA_LOV | VisualAttribute | List-of-values field attribute - Arial, 9pt, dark blue foreground | 0 items directly; member of OG_GROUP | referenced |
| VA_TRNI_DT | VisualAttribute | Transaction date field attribute - Courier, Bold, black foreground | 0 items directly; member of OG_GROUP | referenced |
| VA_TITLE | VisualAttribute | Title/heading text attribute - Arial, 10pt, Bold, blue foreground | 0 items directly; member of OG_GROUP | referenced |
| VA_ALERT | VisualAttribute | Alert display attribute - MT Extra font, 11pt, Demilight, black foreground | 0 items directly; member of OG_GROUP | referenced |
| VA_BUTN | VisualAttribute | Button label attribute - Arial, 10pt, Bold, black foreground | 0 items directly; member of OG_GROUP | referenced |
| VA_TEXT | VisualAttribute | Standard text field attribute - Arial, 9pt, Medium, black foreground | 0 items directly; member of OG_GROUP | referenced |
| VA_MPROMPT | VisualAttribute | Mandatory field prompt attribute - ARIAL, 9pt, Medium, black foreground | 0 items directly; member of OG_GROUP | referenced |
| VA_OPROMPT | VisualAttribute | Optional field prompt attribute - ARIAL, 9pt, Medium, black foreground | 0 items directly; member of OG_GROUP | referenced |
| VA_MAND | VisualAttribute | Mandatory field value attribute - ARIAL, 9pt, Medium, black foreground | 0 items directly; member of OG_GROUP | referenced |
| VA_NUM | VisualAttribute | Numeric field attribute - ARIAL, 8pt, Medium, black foreground | 0 items directly; member of OG_GROUP | referenced |
| VA_DESC | VisualAttribute | Description field attribute - Small Fonts, 7pt, Medium, blue foreground | 0 items directly; member of OG_GROUP | referenced |
| VA_ICONIC_BUTN | VisualAttribute | Iconic button attribute - no explicit font/size specified, black foreground | 7 items (toolbar buttons in PB_BLK); member of OG_GROUP | PB_EXIT, PB_LIST, PB_INSERT, PB_DEL, PB_CANCEL, PB_SAVE, PB_PRINT |
| VA_RB | VisualAttribute | Radio button attribute - Arial, 8pt, black foreground | 0 items directly; member of OG_GROUP | referenced |
| VA_CB | VisualAttribute | Check box attribute - ARIAL, 8pt, black foreground | 0 items directly; member of OG_GROUP | referenced |
| OG_GROUP | ObjectGroup | Reusable form component group bundling the error canvas (CN_ERR), error block (CB_ERR), standard windows, menus, canvases, toolbar block (PB_BLK), alerts, common triggers, and all visual attributes for import into other forms | 1 group definition | CN_ERR, CB_ERR, WN_MAIN, CN_MAIN, CN_TOOL, PB_BLK, all VAs, standard alerts and triggers |

---

## 10. Record Groups

*Lists all record groups, their LOV bindings, query logic, dynamic bindings, business purpose, and form usage.*

| Record Group | Type | Used By LOV | Display Column | Return Column | Dynamic Bindings | Purpose | Where Used |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| RG_CONSG | Query | LV_CONSG | CONSG_CD | DEALER_CATEGORY | No | Lists available consignee codes for the user to scope the service ratio report by consignee | LV_CONSG -> CNTRL_BLK.CONSG_CD |
| RG_DEALER | Query | LV_DEALER | DEALER_NAME | PARENT_GROUP | No | Lists dealer names filtered by the selected consignee so the user can narrow the report to a specific dealer | LV_DEALER -> CNTRL_BLK.DEALER_NAME |
| RG_LOC | Query | LV_LOC | LOC_DESC | LOC_CD | No | Lists dealer location codes filtered by the selected consignee for report scope selection | LV_LOC -> CNTRL_BLK.LOC_CD |
| RG_STATE | Query | LV_STATE | STATE_DESC | STATE_CD | No | Lists geographic states associated with dealers filtered by consignee for report scope selection | LV_STATE -> CNTRL_BLK.STATE_CD |

**Total Record Groups:** 4

## 11. Referenced Database Objects

*Database tables, views, and objects accessed by the form.*

### 11.1 Block-Table Binding Summary

| Block | Base Table | Primary Key Item | Database Item |
| :--- | :--- | :--- | :--- |
| CNTRL_BLK | - | - | No |
| CB_ERR | - | - | No |
| PB_BLK | - | - | No |

### 11.2 Database Object References

| Object | Schema | Used In | Description |
| :--- | :--- | :--- | :--- |
| `AM_DEALER_LOC` | - | RG_CONSG, RG_DEALER, RG_LOC, Trigger WHEN-BUTTON-PRESSED | Dealer location master - stores dealer, consignee, location, state, and principal map information used to populate LOVs and filter the service ratio report |
| `DUAL` | - | RG_CONSG, RG_DEALER, RG_LOC, RG_STATE, Trigger WHEN-BUTTON-PRESSED, Trigger WHEN-NEW-FORM-INSTANCE | Oracle system pseudo-table - used in UNION ALL clauses to append the 'ALL' option to each LOV record group query |
| `GM_STATE` | - | RG_STATE | State master - stores state codes and descriptions mapped to regions; joined with AM_DEALER_LOC to populate the state selection LOV |

**Total Referenced Objects:** 3

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure/Package Index

| Requirement ID | Procedure/Package | Purpose |
| -------------- | ----------------- | ------- |
| BR-010 | VIEW_EXCEL_REP (form program unit) | Executes the dynamically constructed service ratio report query, writes the results to a CSV file on the server, and opens the file in the user's browser |
| BR-002, BR-017 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Registers or clears the form module name in the active database session client information slot |
| BR-002, BR-017 | DBMS_APPLICATION_INFO.SET_MODULE | Registers or clears the form module name and action label in the active database session module tracking slot |
| BR-003, BR-004, BR-005, BR-006, BR-007, BR-008, BR-012, BR-013 | GENERAL.DISP_TEXT | Displays error or informational messages to the user on screen (from the attached DPL library) |
| BR-011 | GENERAL.ASK_CONFIRM | Displays a confirmation dialog and returns the user's choice to the calling code (from the attached DPL library) |
| BR-010 | WEB.SHOW_DOCUMENT | Opens a URL in a new browser tab to deliver the generated CSV file to the user (from the attached WEBUTIL library) |
| BR-010 | WEBUTIL.ID_NULL | Tests whether a Forms internal handle is uninitialized; used inside VIEW_EXCEL_REP to validate Find_Group and Find_Column handles before operating on them (from the attached WEBUTIL library) |
| BR-010 | WEBUTIL.FOPEN | Opens a server-side file for reading or writing; used inside VIEW_EXCEL_REP to create the output CSV file (from the attached WEBUTIL library) |
| BR-010 | WEBUTIL.FCLOSE | Closes an open server-side file handle; used inside VIEW_EXCEL_REP after all CSV rows have been written (from the attached WEBUTIL library) |
| BR-010 | WEBUTIL.PUT_LINE | Writes a line of text to an open server-side file; used inside VIEW_EXCEL_REP to write each CSV data row (from the attached WEBUTIL library) |
| BR-010 | WEBUTIL.GET_LINE | Reads a line of text from an open server-side file; used inside VIEW_EXCEL_REP during file processing (from the attached WEBUTIL library) |
| BR-010 | WEBUTIL.ERRORALERT | Displays a WEBUTIL error alert to the user; used inside VIEW_EXCEL_REP to report file or report generation failures (from the attached WEBUTIL library) |
| BR-010 | WEBUTIL.GETPROPERTY | Retrieves a WEBUTIL runtime property value; used inside VIEW_EXCEL_REP to obtain environment or configuration details (from the attached WEBUTIL library) |
| BR-010 | WEBUTIL.SETPROPERTY | Sets a WEBUTIL runtime property value; used inside VIEW_EXCEL_REP to configure WEBUTIL behaviour before file operations (from the attached WEBUTIL library) |
| BR-010 | WEBUTIL.GETIMPLCLASS | Returns the WEBUTIL implementation class name; used inside VIEW_EXCEL_REP to verify the WEBUTIL deployment context (from the attached WEBUTIL library) |
| - | GENERAL.l_pop_list_item | Populates dynamic list items at form startup by refreshing record groups from SQL queries (from the attached DPL library) |

---

### 12.2 Procedure and Package Catalogue

| Procedure/Package | Type | Called From | Purpose | Classification |
| ----------------- | ---- | ----------- | ------- | -------------- |
| VIEW_EXCEL_REP | Form Program Unit (Procedure) | WHEN-BUTTON-PRESSED trigger on CNTRL_BLK.PB_EXCEL | Generates the service ratio report as a CSV file on the server and opens it in the user's browser; accepts the output filename, query text, and column name as parameters | Form Program Unit |
| GENERAL.ASK_CONFIRM | Package function (DPL attached library) | FT_CANCEL trigger | Displays a confirmation dialog (AL_CONFIRM caution alert) with a supplied message text; returns 1 if the user clicks the affirmative button, or 0 if they decline. Used in FT_CANCEL to confirm discarding unsaved filter criteria before clearing the form | DPL Library |
| GENERAL.DISP_TEXT | Package procedure (DPL attached library) | FT_INSERT trigger; FT_DEL trigger; WHEN-VALIDATE-ITEM on CNTRL_BLK.CONSG_CD; WHEN-VALIDATE-ITEM on CNTRL_BLK.STATE_CD; WHEN-VALIDATE-ITEM on CNTRL_BLK.DEALER_NAME; WHEN-VALIDATE-ITEM on CNTRL_BLK.LOC_CD; WHEN-VALIDATE-ITEM on CNTRL_BLK.P_FROMDT; WHEN-VALIDATE-ITEM on CNTRL_BLK.P_TODT | Routes a message to the appropriate alert: AL_ERRINFO when title_string = 'ERROR' (for validation failures and error conditions), or AL_NOTE for all other titles (informational and operational messages). Sets the alert title and message text at runtime, then calls show_alert; the return value is discarded | DPL Library |
| GENERAL.l_pop_list_item | Package procedure (DPL attached library) | WHEN-NEW-FORM-INSTANCE trigger | Finds and drops any existing record group named p_rg_name, then creates a new record group from the p_select query and populates it. Called at form startup to refresh dynamic list items (LOVs) from a SQL select | DPL Library |
| DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Oracle built-in package procedure | PRE-FORM trigger; KEY-EXIT trigger | Sets or clears the client information field in the active Oracle session - used for session monitoring and identification | Oracle Built-in Package |
| DBMS_APPLICATION_INFO.SET_MODULE | Oracle built-in package procedure | PRE-FORM trigger; KEY-EXIT trigger | Sets or clears the module name and action label in the active Oracle session - used for session monitoring and identification | Oracle Built-in Package |
| WEB.SHOW_DOCUMENT | Package procedure (WEBUTIL attached library) | VIEW_EXCEL_REP program unit | Opens a specified URL in a new browser tab; used to deliver the generated CSV file to the user's browser | WEBUTIL Library |
| WEBUTIL.ID_NULL | Package function (WEBUTIL attached library) | VIEW_EXCEL_REP program unit | Tests whether a Forms internal handle (such as a RecordGroup or GroupColumn handle) is uninitialized; returns TRUE if the handle is null, FALSE otherwise. Used in VIEW_EXCEL_REP to verify that Find_Group and Find_Column calls returned valid handles before operating on them | WEBUTIL Library |
| WEBUTIL.FOPEN | Package function (WEBUTIL attached library) | VIEW_EXCEL_REP program unit | Opens a server-side file for reading or writing and returns a file handle; used in VIEW_EXCEL_REP to create or open the output CSV file before writing report data | WEBUTIL Library |
| WEBUTIL.FCLOSE | Package procedure (WEBUTIL attached library) | VIEW_EXCEL_REP program unit | Closes an open server-side file handle; called in VIEW_EXCEL_REP after all CSV rows have been written to ensure the file is properly finalised and released | WEBUTIL Library |
| WEBUTIL.PUT_LINE | Package procedure (WEBUTIL attached library) | VIEW_EXCEL_REP program unit | Writes a line of text followed by a newline to an open server-side file; used in VIEW_EXCEL_REP to write each CSV header and data row to the output file | WEBUTIL Library |
| WEBUTIL.GET_LINE | Package function (WEBUTIL attached library) | VIEW_EXCEL_REP program unit | Reads a single line of text from an open server-side file and returns it as a VARCHAR2; used in VIEW_EXCEL_REP during file processing operations | WEBUTIL Library |
| WEBUTIL.ERRORALERT | Package procedure (WEBUTIL attached library) | VIEW_EXCEL_REP program unit | Displays a WEBUTIL error alert dialog to the user; used in VIEW_EXCEL_REP to report file-open, write, or report generation failures to the operator | WEBUTIL Library |
| WEBUTIL.GETPROPERTY | Package function (WEBUTIL attached library) | VIEW_EXCEL_REP program unit | Retrieves a named WEBUTIL runtime property value; used in VIEW_EXCEL_REP to obtain environment or configuration details required during file generation | WEBUTIL Library |
| WEBUTIL.SETPROPERTY | Package procedure (WEBUTIL attached library) | VIEW_EXCEL_REP program unit | Sets a named WEBUTIL runtime property value; used in VIEW_EXCEL_REP to configure WEBUTIL behaviour before initiating file operations | WEBUTIL Library |
| WEBUTIL.GETIMPLCLASS | Package function (WEBUTIL attached library) | VIEW_EXCEL_REP program unit | Returns the WEBUTIL implementation class name as a string; used in VIEW_EXCEL_REP to verify the WEBUTIL deployment context before performing file or browser operations | WEBUTIL Library |

## 13. Package Procedure Specifications

*NO PCK files found - no `*.pck` source files were discovered in the form sources input directory. Package specifications cannot be generated without uploaded PCK sources.*

## 14. Database Package Catalogue

*NO PCK files found - no `*.pck` source files were discovered in the form sources input directory. The database package catalogue cannot be generated without uploaded PCK sources.*

## 15. PLD Procedure Call Sites

*Maps each program-library routine to its call sites within triggers and program units. Behaviour descriptions are derived from the uploaded ``.pld`` sources.*

### DPL.pld (`general`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ASK_CONFIRM | Function | Function(confirm_msg VARCHAR2) RETURN NUMBER | Trigger: FT_CANCEL in Form | Displays the AL_CONFIRM caution alert with the supplied message text. Returns 1 if the user clicks the affirmative (Yes) button, or 0 if they decline. Used in FT_CANCEL to ask the user to confirm discarding unsaved filter criteria before clearing the form |
| DISP_TEXT | Procedure | Procedure(text_string VARCHAR2, title_string VARCHAR2) | Trigger: FT_DEL in Form, Trigger: FT_INSERT in Form, Trigger: WHEN-VALIDATE-ITEM in CNTRL_BLK.CONSG_CD, Trigger: WHEN-VALIDATE-ITEM in CNTRL_BLK.DEALER_NAME, Trigger: WHEN-VALIDATE-ITEM in CNTRL_BLK.LOC_CD, Trigger: WHEN-VALIDATE-ITEM in CNTRL_BLK.P_FROMDT, Trigger: WHEN-VALIDATE-ITEM in CNTRL_BLK.P_TODT, Trigger: WHEN-VALIDATE-ITEM in CNTRL_BLK.STATE_CD | Routes a message to the appropriate alert: AL_ERRINFO when title_string = 'ERROR' (for validation failures and error conditions), or AL_NOTE for all other titles (informational and operational messages). Sets the alert title and message text at runtime, then calls show_alert. The return value is discarded |
| l_pop_list_item | Procedure | Procedure(p_rg_name VARCHAR2,p_select VARCHAR2) | Trigger: WHEN-NEW-FORM-INSTANCE in Form | Finds and drops any existing record group named p_rg_name, then creates a new record group from the p_select query and populates it. Called at form startup to refresh dynamic list items from a SQL select |

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``pe_srv_ratio_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| DELETE_RECGRP_ROW | Procedure | Procedure(p_block_name in varchar2, p_rec_num in number) | Trigger: FT_DEL in Form | **COMMENTED OUT / INACTIVE** - Finds the named record group and deletes the specified row number from it. Was referenced in commented-out delete logic in FT_DEL to remove the current record group row corresponding to the deletion candidate; this code block is no longer active |
| PRINT_REPORT | Procedure | Procedure(TBNAME VARCHAR2, -- Table name C1NAME VARCHAR2, -- Column 1 C2NAME VARCHAR2, -- Column 2 C3NAME VARCHAR2, -- Column 3 LABEL1 VARCHAR2, -- Label for... | Trigger: FT_PRINT in Form | **COMMENTED OUT / INACTIVE** - Would have prompted the user to confirm printing, selected an order-by column, built a parameter string, and called RUN_REPORT to print the GM_ZONE (Zone Master) table. The call is block-commented in FT_PRINT; the trigger body is now NULL |

**Total Active Routines:** 3 of 24 in DPL.pld source
**Inactive / commented-only routines:** 2

---

### webutil.pld (`WEBUTIL_C_API`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ID_NULL | Function | Function(handle IN Pointer) RETURN BOOLEAN | ProgramUnit: VIEW_EXCEL_REP | Tests whether a Forms internal handle (such as a RecordGroup or GroupColumn handle) is uninitialized; returns TRUE if the handle is null, FALSE otherwise. Used in VIEW_EXCEL_REP to verify that Find_Group and Find_Column calls returned valid handles before operating on them |

**Total Active Routines:** 1 of 28 in webutil.pld source

---

### webutil.pld (`WEBUTIL_FILE`)

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``pe_srv_ratio_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| FILE_SAVE_DIALOG | Function | Function(directory_name Varchar2 := NULL, file_name Varchar2 := NULL, file_filter Varchar2 := NULL, title Varchar2 := NULL) RETURN Varchar2 | ProgramUnit: VIEW_EXCEL_REP | **COMMENTED OUT / INACTIVE** - Presents the client-side OS file-save dialog, allowing the user to choose a destination directory, file name, file filter, and dialog title. Returns the fully qualified path selected by the user, or NULL if the dialog is cancelled. Referenced in commented-out code within VIEW_EXCEL_REP that would have prompted the user for a save location before transferring the generated Excel file to the client |

**Total Active Routines:** 0 of 25 in webutil.pld source
**Inactive / commented-only routines:** 1

---

### webutil.pld (`WEBUTIL_FILE_TRANSFER`)

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``pe_srv_ratio_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| URL_To_Client | Function | Function(sourceURL in VARCHAR2, clientDestination in VARCHAR2, fileSize in PLS_INTEGER default 0) RETURN BOOLEAN | ProgramUnit: VIEW_EXCEL_REP | **COMMENTED OUT / INACTIVE** - Downloads a file from the specified server-side URL to the given client-side destination path. Accepts an optional expected file size in bytes. Returns TRUE on successful transfer, FALSE otherwise. Referenced in commented-out code within VIEW_EXCEL_REP that would have transferred the generated Excel report file from the application server to the end-user's local machine |

**Total Active Routines:** 0 of 21 in webutil.pld source
**Inactive / commented-only routines:** 1

---

### webutil.pld (`WEBUTIL_HOST`)

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``pe_srv_ratio_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| Host | Function | Function(cmd in VARCHAR2) RETURN PLS_INTEGER | ProgramUnit: VIEW_EXCEL_REP | **COMMENTED OUT / INACTIVE** - Executes the supplied operating-system command string on the client machine and returns a PLS_INTEGER status code indicating the outcome. Referenced in commented-out code within VIEW_EXCEL_REP that would have invoked a shell command on the client (for example, to open or process the downloaded Excel file) after the file transfer step |

**Total Active Routines:** 0 of 14 in webutil.pld source
**Inactive / commented-only routines:** 1

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| ID | Service Name | Database Object | Input Parameters | Output | Business Function | API Endpoint Suggestion |
| -- | ------------ | --------------- | ---------------- | ------ | ----------------- | ----------------------- |
| MS-001 | Service Ratio Report Generator | VIEW_EXCEL_REP / AM_DEALER_LOC, AM_DEALER_LOC_COMPANY_MASTER, PH_SO, PD_SO, VH_RO, VT_REQ, PM_PART, PM_PART_VAR, GM_CITY, AM_LIST | principal, consg_cd, parent_group, loc_cd, state_cd, p_fromdt, p_todt, report_type, sale_type, rep_catg, ratio, part_num (optional), root_part_num (optional) | CSV report file (download URL or stream) | Constructs and executes the appropriate service ratio report query based on all selected filter criteria and report dimensions, returning the results as a downloadable CSV | POST /api/service-ratio/reports/excel |
| MS-002 | Consignee Lookup Service | AM_DEALER_LOC | principal, parent_group | List of consignee codes, dealer categories, and dealer names | Returns the list of consignees available for the current principal and parent group, including an ALL option | GET /api/reference/consignees |
| MS-003 | Dealer Name Lookup Service | AM_DEALER_LOC | principal, parent_group, consg_cd | List of dealer names and parent groups | Returns the list of available dealer names filtered by principal, parent group, and consignee, including an ALL option for multi-dealer principals | GET /api/reference/dealers |
| MS-004 | Location Lookup Service | AM_DEALER_LOC | principal, parent_group, consg_cd | List of location descriptions and codes | Returns the list of available dealer locations filtered by principal, parent group, and consignee, including an ALL option | GET /api/reference/locations |
| MS-005 | State Lookup Service | GM_STATE, AM_DEALER_LOC | principal, parent_group, consg_cd | List of state descriptions and state codes | Returns the list of states where the current principal has dealers, filtered by consignee, including an ALL option | GET /api/reference/states |

**Total Microservices Identified: 5**

---

## 17. Workflows

| ID | Workflow Name | Trigger Event | Steps | Decision Points | End State |
| -- | ------------- | ------------- | ----- | --------------- | --------- |
| WF-001 | Form Startup and Session Registration | User navigates to the Service Ratio report screen - PRE-FORM trigger fires, then WHEN-NEW-FORM-INSTANCE fires | 1. PRE-FORM: Register "pe_srv_ratio" as the current database session's client information and module name. 2. WHEN-NEW-FORM-INSTANCE: Maximise the main window. 3. Set From Date and To Date to today's date. 4. Set Parent Group, Dealer Name, and Location to ALL. | None - all steps execute unconditionally on form open. (Commented-out code for global defaults and list population does not execute.) | Service Ratio report screen is visible, maximised, and pre-filled with default filter values ready for user input |
| WF-002 | Filter Criteria Entry and Validation | User enters values in filter fields and attempts to navigate between them - WHEN-NEW-ITEM-INSTANCE and WHEN-VALIDATE-ITEM triggers fire on individual fields | 1. User enters the Consignee Code field: State lookup opens automatically. 2. User moves off Consignee Code: null check validates the value. 3. User enters the State field: State lookup list opens automatically. 4. User moves off State: null check validates the value. 5. User enters the Dealer Name field: Dealer lookup list opens automatically. 6. User moves off Dealer Name: null check validates the value. 7. User enters the Location field: Location lookup list opens automatically. 8. User moves off Location: null check validates the value. 9. User enters From Date and moves off: null check validates the value. 10. User enters To Date and moves off: null check validates the value. 11. User selects Report Type: Part Number / Root Part Number fields enabled or disabled; Sale Type locked if Group type selected. | At each field exit: if the field is blank, processing is blocked and an error message shown; user must provide a value. When Report Type = Summary: Part Number and Root Part Number fields are disabled. When Report Type = Group: Sale Type is auto-set and locked. | All mandatory filter fields are populated and validated; the form is ready for report generation |
| WF-003 | Excel Service Ratio Report Generation | User clicks the Excel Report button - WHEN-BUTTON-PRESSED trigger on CNTRL_BLK.PB_EXCEL fires, calling VIEW_EXCEL_REP | 1. Internal where-clause parameters are cleared. 2. Optional part number and root part number filter clauses are appended if entered. 3. Report SQL query is constructed based on Report Type (P/S/G) and Based On category (L/Q/V), incorporating all active filter values. 4. The server file path is read from the application server configuration file. 5. VIEW_EXCEL_REP is called: query executes, results are written to a CSV file on the server. 6. The CSV file is opened in the user's browser as a download. | If the filename path contains spaces: redirect output to C drive root and inform user. If row count exceeds 65,535: truncate to 65,535 rows and inform user. If an unexpected error occurs: display error code and description and halt. Report Type + Based On combination determines which of nine query variants is built. | CSV report file is delivered to the user's browser; or an error or informational message is shown if a limit or failure condition is encountered |
| WF-004 | Cancel and Clear Form | User clicks the Cancel button - FT_CANCEL trigger fires | 1. Part Number, Root Part Number, and Sale Type fields are re-enabled and made navigable. 2. System checks whether filter values have been changed. 3. If changed: confirmation dialog is displayed asking the user to confirm discard. 4. If user confirms (or no changes): form is cleared without saving. | If filter values have been changed: confirmation dialog is shown; user may confirm or cancel the clear action. If no changes: form is cleared immediately without prompting. If Cancel button is disabled: no action. | Form is cleared and all filter fields are reset (confirmed path), or form remains unchanged (user declined) |
| WF-005 | Form Exit and Session Cleanup | User clicks the Exit button or activates the exit shortcut - KEY-EXIT trigger fires (PB_BLK.PB_EXIT WHEN-BUTTON-PRESSED delegates to EXIT_FORM directly) | 1. Form closes immediately without validation or saving (EXIT_FORM(NO_VALIDATE)). 2. Database session client information is cleared (set to null). 3. Database session module name and action label are cleared (set to empty values). | None - the form closes unconditionally; no save/validation prompt is shown. | Service Ratio report screen is closed and the database session tracking information for this screen is cleared |

**Total Workflows Identified: 5**

---

## 18. PLD-Backed Logic

*Maps shared library routines to their business function and suggested API contracts.*

### webutil.pld (`CLIENT_IMAGE`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | ID_NULL | Business Logic | ProgramUnit: VIEW_EXCEL_REP | /api/v1/pld/id_null | When a Forms internal handle is checked, return true if the handle is uninitialized so callers can avoid operating on an invalid reference |


---

### DPL.pld (`general`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | ASK_CONFIRM | Business Logic | Trigger: FT_CANCEL in Form | /api/v1/pld/ask_confirm | When a destructive action is requested, prompt the user to confirm before proceeding; proceed only if the user affirms |
| PLD-002 | DELETE_RECGRP_ROW | Business Logic | Trigger: FT_DEL in Form | /api/v1/pld/delete_recgrp_row | **COMMENTED OUT / INACTIVE** - When a record group row deletion is requested, find the group and remove the specified row; this logic is no longer active |
| PLD-003 | DISP_TEXT | Business Logic | Trigger: FT_DEL in Form, Trigger: FT_INSERT in Form, Trigger: WHEN-VALIDATE-ITEM in CNTRL_BLK.CONSG_CD, Trigger: WHEN-VALIDATE-ITEM in CNTRL_BLK.DEALER_NAME, Trigger: WHEN-VALIDATE-ITEM in CNTRL_BLK.LOC_CD, Trigger: WHEN-VALIDATE-ITEM in CNTRL_BLK.P_FROMDT, Trigger: WHEN-VALIDATE-ITEM in CNTRL_BLK.P_TODT, Trigger: WHEN-VALIDATE-ITEM in CNTRL_BLK.STATE_CD | /api/v1/pld/disp_text | When a message is raised, display it in the error alert for errors or the note alert for informational messages |
| PLD-004 | l_pop_list_item | Business Logic | Trigger: WHEN-NEW-FORM-INSTANCE in Form | /api/v1/pld/l_pop_list_item | When the form opens, refresh a named record group by dropping any existing instance and recreating it from the supplied SQL query |
| PLD-005 | PRINT_REPORT | Business Logic | Trigger: FT_PRINT in Form | /api/v1/pld/print_report | **COMMENTED OUT / INACTIVE** - When print is requested, confirm with the user and then send the specified table's data to the report engine for printing |


---

### D2kwutil.pld (`Win_API`)

*No routines from ``D2kwutil.pld`` are referenced in ``pe_srv_ratio_fmb.xml``.*

---

---

## 19. PCK-Backed Logic

*NO PCK files found - no ``*.pck`` source files were discovered in ``/app/workspace/pe_srv_ratio-6013e0fc5ddc/in``. PCK-backed logic cannot be generated without uploaded PCK sources.*

---

## 20. System Interfaces

### 20.1 Database Integrations

| Interface Name | Type | Purpose | Data Flow | Error Handling |
| -------------- | ---- | ------- | --------- | -------------- |
| Dealer Location Master (AM_DEALER_LOC) | Table - SELECT | Provides dealer site information (consignee code, dealer name, parent group, outlet code, location, state, city) for filter lookups and report query joins | Read-only - queried by RG_CONSG, RG_DEALER, RG_LOC record groups and the dynamic report query in VIEW_EXCEL_REP | No explicit error handling; errors in the dynamic query are caught by the WHEN OTHERS handler in VIEW_EXCEL_REP which displays *"Error  -"* plus error code and text |
| Dealer Location Company Master (AM_DEALER_LOC_COMPANY_MASTER) | Table - SELECT | Maps dealers to their company/principal for multi-org scoping | Read-only - joined to AM_DEALER_LOC in record group queries and report queries | Same as above |
| Sales Order Header (PH_SO) | Table - SELECT | Provides customer sales transaction data including dealer, date, party type, and company | Read-only - queried in Part-level and Group report query variants | Same as above |
| Sales Order Detail (PD_SO) | Table - SELECT | Provides part-level customer sales line data including ordered and billed quantities and part number | Read-only - queried in Part-level and Group report query variants | Same as above |
| Workshop Repair Order Header (VH_RO) | Table - SELECT | Provides workshop/warranty repair order data including dealer, location, and repair order date | Read-only - queried in Part-level and Group report query variants for warranty channel | Same as above |
| Workshop Parts Requirement (VT_REQ) | Table - SELECT | Provides part request line data for workshop orders including requested, picked, and issued quantities | Read-only - queried in Part-level and Group report query variants for warranty channel | Same as above |
| Parts Catalogue (PM_PART) | Table - SELECT | Provides master part information including part number, root part number, and category; only main-category (M) parts are included | Read-only - joined to sales/workshop order detail in all report query variants | Same as above |
| Part Variant / Pricing (PM_PART_VAR) | Table - SELECT | Provides overseas and local sell prices for parts used in value-based ratio calculations | Read-only - joined in Value-based (V) report query variants only | Same as above |
| City Master (GM_CITY) | Table - SELECT | Provides city descriptions for dealer locations used in Summary-level reports | Read-only - joined to AM_DEALER_LOC in Summary report query variants | Same as above |
| State Master (GM_STATE) | Table - SELECT | Provides state descriptions; used to populate the State filter lookup list | Read-only - queried by RG_STATE record group | Same as above |
| Party Type Reference List (AM_LIST) | Table - SELECT | Provides customer segment descriptions mapped from party type codes for Group-level reports | Read-only - joined in Group report query variants | Same as above |
| Oracle DUAL | Table - SELECT | Used to retrieve SYSDATE for default date population and to provide the ALL literal default for filter fields | Read-only - queried in WHEN-NEW-FORM-INSTANCE trigger | No explicit error handling at this step |
| DBMS_APPLICATION_INFO | Oracle Package - CALL | Registers and clears the form module name in the Oracle active session for database monitoring purposes | Called in PRE-FORM (register) and KEY-EXIT (clear) triggers | No explicit error handling; the call is unconditional |

### 20.2 External System Integrations

The PE_SRV_RATIO form has no integrations with external systems outside of the Oracle database. The only external dependency is the application server's file system, accessed to write the generated CSV report file and to read the report download URL path from a configuration file.

| System Name | Integration Type | Purpose | Protocol | Endpoint | Data Exchange | Success / Error Codes |
| ----------- | ---------------- | ------- | -------- | -------- | ------------- | --------------------- |
| Application Server File System | File I/O (server-side write via TEXT_IO) | Writes the generated service ratio CSV report to a server directory for browser download | Server-side file write (TEXT_IO in Oracle Forms) | `/iashome/ias/reports/printer/` (server path - INFERRED from VIEW_EXCEL_REP code) | CSV report data written to file; file URL assembled for browser delivery | File write success: file opened in user browser. File path contains spaces: fallback to C drive root with informational message. Any other error: WHEN OTHERS catches and displays *"Error  -"* plus error code and description |
| Report Path Configuration File | File I/O (server-side read via TEXT_IO) | Reads the base URL path for delivering the generated CSV to the user's browser | Server-side file read (TEXT_IO in Oracle Forms) | `/reports/DMS/excelpath.txt` (server path - EXTERNAL / NOT IN BUNDLE) | Single line of text containing the URL base path | Read success: path assembled for browser download URL. Any error: covered by WHEN OTHERS handler in VIEW_EXCEL_REP |

### 20.3 Report Integrations

No Oracle Reports files (.rdf / .rep) are called by this form. The form generates its own CSV output directly using the VIEW_EXCEL_REP program unit. There are no report integrations to document in this section.

---

### 20.3.1 Parameters Passed to the Report

This form does not pass parameters to an Oracle Report. No report parameters were identified in the form sources.

## 21. Procedure and Function Business Rule Catalogue

End-to-end business requirement specification for every stored procedure and function referenced by the PE_SRV_RATIO form.

### 21.1 Catalogue Index

12 procedures/functions - each SP ID links to its detailed specification in Section 21.2.

| SP Index | Routine Name |
| :--- | :--- |
| [SP-001](#SP-001--VIEW_EXCEL_REP) | VIEW_EXCEL_REP |
| [SP-002](#SP-002--GENERAL.ASK_CONFIRM) | GENERAL.ASK_CONFIRM |
| [SP-003](#SP-003--GENERAL.DISP_TEXT) | GENERAL.DISP_TEXT |
| [SP-004](#SP-004--WEBUTIL.ERRORALERT) | WEBUTIL.ERRORALERT |
| [SP-005](#SP-005--WEBUTIL.FCLOSE) | WEBUTIL.FCLOSE |
| [SP-006](#SP-006--WEBUTIL.FOPEN) | WEBUTIL.FOPEN |
| [SP-007](#SP-007--WEBUTIL.GETIMPLCLASS) | WEBUTIL.GETIMPLCLASS |
| [SP-008](#SP-008--WEBUTIL.GETPROPERTY) | WEBUTIL.GETPROPERTY |
| [SP-009](#SP-009--WEBUTIL.GET_LINE) | WEBUTIL.GET_LINE |
| [SP-010](#SP-010--WEBUTIL.ID_NULL) | WEBUTIL.ID_NULL |
| [SP-011](#SP-011--WEBUTIL.PUT_LINE) | WEBUTIL.PUT_LINE |
| [SP-012](#SP-012--WEBUTIL.SETPROPERTY) | WEBUTIL.SETPROPERTY |

---

### 21.2 Detailed Specifications

#### SP-001 - VIEW_EXCEL_REP

**Invoked From:**

- pe_srv_ratio_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

SERVICE RATIO (WN_MAIN / CN_MAIN)

---

**Purpose**

Executes the dynamically constructed service ratio SQL query, loads the results into an in-memory record group, and writes each row as a comma-separated line to a server-side file. Once the file is written, it is opened directly in the user's browser for download. Row count is capped at 65,535 to stay within Excel limits, and any error during the process is surfaced to the user with the system error code and description.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_file_name | VARCHAR2 | IN |
| p_query | long | IN |
| p_column_name | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.FCLOSE ([SP-005](#SP-005--WEBUTIL.FCLOSE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.FOPEN ([SP-006](#SP-006--WEBUTIL.FOPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_LINE ([SP-009](#SP-009--WEBUTIL.GET_LINE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ID_NULL ([SP-010](#SP-010--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.PUT_LINE ([SP-011](#SP-011--WEBUTIL.PUT_LINE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Retrieve the logged-in user's identifier and combine it with the current date and time to produce a unique CSV output filename.
- Step 2 - Check whether the filename path contains spaces; if it does, redirect the output to the C drive root and notify the user.
- Step 3 - Remove any previously cached in-memory record group with the same name, then create a new one by executing the supplied report query.
- Step 4 - Count the number of rows returned; if the count exceeds 65,536, notify the user that the output will be truncated and cap the row count at 65,535.
- Step 5 - Read the server-side file download path from the application server's configuration file.
- Step 6 - Open a new CSV file at the resolved server path and iterate through each result row, writing the row's data as a comma-separated line.
- Step 7 - Close the CSV file and open it in the user's browser as a new tab.
- Step 8 - If any unexpected error occurs during the above steps, display the system error code and description to the user and halt processing.

---
**Decision Points**

DP-001

Condition: The generated output filename path contains a space character in one of the folder names.

TRUE: Redirect the file output to the C drive root, display an informational message to the user, and continue with file generation.

FALSE: Use the original filename path as-is.

---

DP-002

Condition: The number of rows returned by the report query exceeds 65,536.

TRUE: Notify the user that the output will be truncated and set the row count to 65,535 before writing the file.

FALSE: Use the full row count returned by the query.

---

DP-003

Condition: An unexpected error occurs at any point during query execution, file writing, or browser launch.

TRUE: Display the system error code and error description to the user and raise a trigger failure to halt processing.

FALSE: Continue normally to open the file in the browser.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The output filename must be unique per user session; it is formed by combining the logged-in user's identifier with the current date and time, ensuring no two concurrent exports overwrite each other.
- BR-002 - If the output path contains spaces in any folder name, the file must be redirected to the C drive root to avoid file-write failures; the user must be informed of this redirection.
- BR-003 - The number of rows written to the CSV file must not exceed 65,535; any result set larger than this limit is truncated and the user must be notified before the file is written.
- BR-004 - The server-side download path used to deliver the file to the browser is read from a centralised configuration file on the application server and must not be hard-coded in the export logic.

---
**Implementation Logic**

```plsql
PROCEDURE view_excel_rep(p_file_name VARCHAR2 DEFAULT NULL, p_query long,p_column_name VARCHAR2) IS	
  rg_name 				 		VARCHAR2(40) := 'DataRecordSet'; 
	rg_id 					 		RecordGroup; 
	gc_id 					 		GroupColumn; 
	urlFile1        TEXT_IO.FILE_TYPE;
	the_rowcount 		 		NUMBER;
	po_tot_rec    NUMBER (6);
	--po_part_tab   pk_part_search_new.part_tab_10;
	po_part_tab   pk_part_search_new.part_tab_11;
	po_err_msg    VARCHAR2 (3000);
	po_err_cd     NUMBER (10);
	low           NUMBER (10);
	high          NUMBER (10);
	remainder     NUMBER (10);
	order_by      VARCHAR2 (300);
	vcfile varchar2(150);
	lv_user  varchar2(150);
	l_Old_URL varchar2(500);	
		l_new_URL varchar2(500);	
	v_string varchar2(5000);
	bin_str varchar2(250);
	errcode 				 		NUMBER; 
  FILENAME			   		VARCHAR2(4000);
  MYFILE 					 		TEXT_IO.FILE_TYPE;
  urlFile 					 	TEXT_IO.FILE_TYPE;
  urlPath							VARCHAR2(5000);
	l_alert 				 		NUMBER;
	server_file      		VARCHAR2(2000);
	file_transfer_bool	BOOLEAN;
	formserverpath   		VARCHAR2(2000);
begin
lv_user := name_in(':global.userid');  -- New line added after dpl change
vcFile:= lv_user||To_Char(Sysdate,'YYYYMMDDHHMISS');    -- New line added after dpl change
vcFile := vcFile||'.csv';
if vcFile is null then
	--FILENAME  := Webutil_file.FILE_SAVE_DIALOG;
	null;
else
	filename:=vcFile;
end if;
	If instr(FILENAME,' ') > 0 then
 		FILENAME := 'C:\'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
 		Message('File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default.');
 		message('  ');
	end if;
	
	rg_id := Find_Group( rg_name ); 
	IF NOT Id_Null(rg_id) THEN 
		Delete_Group( rg_id ); 
	END IF; 
	rg_id := Create_Group_From_Query( rg_name, p_query ); 
	errcode := Populate_Group( rg_id ); 
	the_rowcount := Get_Group_Row_Count( rg_id );
	IF the_rowcount > 65536 THEN  
		Message('Maximum number of rows in excel exceeded. It will truncate to 65535 rows.');
		Message('  ');
		CLEAR_MESSAGE;
		the_rowcount := 65535;
	END IF;

	server_file := '/iashome/ias/reports/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	--formserverpath := 'http://10.100.34.230:7778/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	urlFile := Text_Io.Fopen('/reports/DMS/excelpath.txt','R');
	Text_Io.Get_Line(urlFile,urlPath);
	Text_Io.Fclose(urlFile);
	formserverpath := urlPath||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	MYFILE := TEXT_IO.FOPEN(server_file, 'W');
	gc_id := Find_Column( rg_name||'.'||p_column_name); 	
	for total_loop IN 1..the_rowcount
		loop
	  	V_STRING :=  GET_GROUP_CHAR_CELL(gc_id  , total_loop ); 
	  	text_io.put_line(myfile,v_string);
	  	--TEXT_IO.PUTF(MYFILE,V_STRING);  
		end loop;
      text_io.fclose(myfile);
   
	 --	file_transfer_bool := WebUtil_File_Transfer.Url_To_Client(formserverpath,FILENAME);
	/* 	if not file_transfer_bool  then 
	 		message('File Transfer failed');pause;
	 	end if;
	 	WebUtil_Host.HOST('cmd /c '||FILENAME);*/
	 	
	 	web.show_document(formserverpath,'_blank');
	exception
		when others then
		Message('Error  - '||ERROR_CODE|| ERROR_TEXT);
		Raise Form_trigger_failure;
	end;

```

#### SP-002 - GENERAL.ASK_CONFIRM

**Invoked From:**

- pe_srv_ratio_fmb.xml [Trigger: FT_CANCEL]

---

**Screen:**

N/A

---

**Purpose**

Displays a confirmation dialog to the user with a caller-supplied prompt message. Returns 1 if the user clicks the affirmative button or 0 if the user declines, allowing calling code to proceed or abort a potentially destructive action based on the user's choice.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| confirm_msg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Set the confirmation alert's message text to the supplied prompt message.
- Step 2 - Display the confirmation alert to the user and wait for a button response.
- Step 3 - If the user clicked the affirmative button, return 1 to the caller; otherwise return 0.

---
**Decision Points**

DP-001

Condition: The user clicks the affirmative (Yes/OK) button on the confirmation dialog.

TRUE: Return 1 to the calling code, indicating the user confirmed the action.

FALSE: Return 0 to the calling code, indicating the user declined the action.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The confirmation dialog must display the exact message text supplied by the caller so that the prompt is contextually appropriate for the action being confirmed.
- BR-002 - The function must return a clear numeric indicator (1 for confirmed, 0 for declined) so that calling code can branch correctly without ambiguity.

---
**Implementation Logic**

```plsql
FUNCTION ASK_CONFIRM( confirm_msg VARCHAR2)
                                      RETURN  NUMBER IS

    p_alert_name varchar2(10) := 'AL_CONFIRM' ;
    p_albtn_pressed number;
BEGIN
   set_alert_property(p_alert_name,alert_message_text,confirm_msg); 
   p_albtn_pressed := show_alert(p_alert_name);

   IF ( p_albtn_pressed = ALERT_BUTTON1 ) THEN
      return (1);
   ELSE
      return(0);
   END IF;
RETURN NULL; END;
```

#### SP-003 - GENERAL.DISP_TEXT

**Invoked From:**

- pe_srv_ratio_fmb.xml [Trigger: FT_DEL]
- pe_srv_ratio_fmb.xml [Trigger: FT_INSERT]
- pe_srv_ratio_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

SERVICE RATIO (WN_MAIN / CN_MAIN)

---

**Purpose**

Displays a message alert to the user, routing it to the appropriate alert style based on the severity level supplied by the caller. Error-severity messages are shown in the error alert; all other messages (notes, informational, caution) are shown in the note alert. This provides a single, consistent mechanism for presenting both validation errors and informational messages across the form.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| text_string | VARCHAR2 | IN |
| title_string | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate the severity level: if the title is "ERROR", select the error alert style; otherwise select the note alert style.
- Step 2 - Set the chosen alert's title and message text to the values supplied by the caller.
- Step 3 - Display the alert to the user. The return value is discarded; control returns to the caller once the user dismisses the alert.

---
**Decision Points**

DP-001

Condition: The title supplied by the caller is "ERROR" (case-insensitive).

TRUE: Use the error information alert (AL_ERRINFO) to display the message.

FALSE: Use the note alert (AL_NOTE) to display the message.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Messages with a severity title of "ERROR" must be displayed using the error alert style to visually distinguish them from informational messages.
- BR-002 - All non-error messages, regardless of their specific title, must be displayed using the note alert style, ensuring a consistent user experience for informational and warning notifications.

---
**Implementation Logic**

```plsql
PROCEDURE DISP_TEXT (text_string VARCHAR2,
                     title_string VARCHAR2 ) IS 
   p_alert_name varchar2(10) := 'AL_ERRINFO' ; 
   p_alert_id number;
BEGIN
   if upper(title_string)='ERROR' then
      p_alert_name := 'AL_ERRINFO' ; 
   else
      p_alert_name := 'AL_NOTE' ; 
   end if;
   set_alert_property(p_alert_name,TITLE,title_string);  
   set_alert_property(p_alert_name,alert_message_text,text_string);  
   p_alert_id := show_alert(p_alert_name); 
END;
```

#### SP-004 - WEBUTIL.ERRORALERT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Surfaces a WebUtil error message to the user in the most appropriate way available. If the WebUtil error alert has been initialised, the message is shown in the standard alert dialog; otherwise it falls back to a plain screen message. This ensures that WebUtil component failures are always visible to the user regardless of the alert's initialisation state.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| errText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-010](#SP-010--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Check whether the WebUtil error alert handle has been initialised (i.e. it is not null).
- Step 2 - If the alert handle is valid, set the alert message text to the supplied error description and display the alert to the user.
- Step 3 - If the alert handle is not available, display the error description as a plain screen message prefixed with "WebUtil Error:".

---
**Decision Points**

DP-001

Condition: The WebUtil error alert handle is initialised (not null).

TRUE: Set the alert message text to the supplied error description and show the alert dialog.

FALSE: Display the error as a plain screen message prefixed with "WebUtil Error:".

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A WebUtil component error must always be communicated to the user; the procedure must never silently discard an error message.
- BR-002 - When the error alert is available, the error must be displayed via the alert dialog for visual consistency with other error notifications in the form.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ErrorAlert(errText in VARCHAR2) is
    -- currently used for throwing a BEAN_NOT_REGISTERED or bean not found error.
    ignore integer;
  begin
    if not ID_NULL(m_errorAlert) then 
      --SET_ALERT_PROPERTY(m_errorAlert,TITLE,'WebUtil Error'); -- title already set in alert property
      SET_ALERT_PROPERTY(m_errorAlert,ALERT_MESSAGE_TEXT,errText);
      ignore := SHOW_ALERT(m_errorAlert);
    else
      message('WebUtil Error'||': '||errText);
    end if;
  end ErrorAlert;
```

#### SP-005 - WEBUTIL.FCLOSE

**Invoked From:**

- pe_srv_ratio_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open client-side file handle by instructing the WebUtil component to release the underlying file resource, then clears the handle to null. If the file handle is already null the procedure takes no action. Failures raised by the WebUtil component-whether a missing bean or a property error-are surfaced via WEBUTIL.ERRORALERT or by re-raising a tool error, preventing silent resource leaks.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-004](#SP-004--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETIMPLCLASS ([SP-007](#SP-007--WEBUTIL.GETIMPLCLASS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETPROPERTY ([SP-012](#SP-012--WEBUTIL.SETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate whether the file handle is not null, indicating an open file that requires closing.
- Step 2 - If the handle is set, invoke WEBUTIL.SETPROPERTY to send the close instruction (WUF_TEXTIO_CLOSE) to the WebUtil file package component, passing the current file handle.
- Step 3 - After the close instruction is accepted, set the file handle to null to mark the file as closed.
- Step 4 - If the WebUtil bean is not registered (BEAN_NOT_REGISTERED exception), call WEBUTIL.ERRORALERT to display a descriptive message that identifies the missing bean class (resolved via WEBUTIL.GETIMPLCLASS), then raise a tool error to halt processing.
- Step 5 - If a WebUtil property error occurs (PROPERTY_ERROR exception), raise a tool error immediately without additional messaging.

---
**Decision Points**

DP-001

Condition: The file handle is not null (the file is currently open).

TRUE: Call WEBUTIL.SETPROPERTY to close the file on the WebUtil component and set the file handle to null.

FALSE: Take no action; the file is already closed or was never opened.

---

DP-002

Condition: A BEAN_NOT_REGISTERED exception is raised during the close operation.

TRUE: Call WEBUTIL.ERRORALERT with a message constructed using WEBUTIL.GETIMPLCLASS to identify the missing bean, then raise TOOL_ERROR.

FALSE: Continue normal exception handling; evaluate for PROPERTY_ERROR.

---

DP-003

Condition: A PROPERTY_ERROR exception is raised during the close operation.

TRUE: Raise TOOL_ERROR immediately to signal the failure to the caller.

FALSE: No further exception handling required; procedure completes normally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A file must only be closed if its handle is not null; a null handle must be silently ignored to prevent erroneous close attempts.
- BR-002 - After a successful close, the file handle must be set to null so that subsequent code can reliably detect that the file is no longer open.
- BR-003 - If the WebUtil bean required to perform the close is not registered, an error alert must be raised via WEBUTIL.ERRORALERT, incorporating the bean class name obtained from WEBUTIL.GETIMPLCLASS, before propagating a tool error.
- BR-004 - Any WebUtil property error encountered during the close operation must immediately raise a tool error to prevent silent failure and ensure the caller is notified of the incomplete operation.

---
**Implementation Logic**

```plsql
 
  PROCEDURE fclose (file IN OUT file_type) is 
  BEGIN 
    if (file.handle IS NOT NULL) then 
      WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CLOSE',file.handle);        
      file.handle := NULL;
    end if;
 
 EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.fclose will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;
  END fclose;
```

#### SP-006 - WEBUTIL.FOPEN

**Invoked From:**

- pe_srv_ratio_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Opens a client-side file for reading, writing, or appending via the WebUtil component, and returns a file handle record that subsequent operations can use to interact with the file. Input validation ensures the file mode is valid and a filename has been provided before any file system interaction is attempted. The procedure configures the WebUtil Core bean with the filename, file mode, and optional character set, then retrieves the resulting file handle using WEBUTIL.GETPROPERTY; any failure during validation or opening raises an error to the caller.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| spec | VARCHAR2 | IN |
| filemode | VARCHAR2 | IN |
| charSet | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETPROPERTY ([SP-008](#SP-008--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Validate that the file mode (case-insensitive) is one of the permitted values: read (r), write (w), or append (a). If not, raise a tool error immediately.
- Step 2 - Validate that a filename has been supplied (not null or empty). If not, raise a tool error immediately.
- Step 3 - Pass the filename to the WebUtil Core bean by setting the WUF_FILENAME property.
- Step 4 - Pass the file mode to the WebUtil Core bean by setting the WUF_TEXTIO_FILEMODE property.
- Step 5 - Evaluate the character set parameter: if it is null, set the WUF_TEXTIO_CHARSET property to the literal value '(null)'; otherwise set it to the supplied character set value.
- Step 6 - Invoke WEBUTIL.GETPROPERTY (via WebUtil_Core.getProperty) to request the WUF_TEXTIO_OPEN property, which triggers the file open operation on the client and returns a Java handle string.
- Step 7 - If the returned handle is null, empty, or equals '-1' (indicating the file could not be opened), raise a tool error.
- Step 8 - Convert the handle string to a number, assign it to the file record's handle field, and return the file record to the caller for use in subsequent read/write operations.
- Step 9 - In the exception block, handle BEAN_NOT_REGISTERED by displaying an error alert identifying the missing WebUtil bean before re-raising the tool error; propagate PROPERTY_ERROR, VALUE_ERROR (as a tool error), and TOOL_ERROR directly to the caller.

---
**Decision Points**

DP-001

Condition: The file mode supplied (evaluated case-insensitively) is not one of 'r' (read), 'w' (write), or 'a' (append).

TRUE: Raise a tool error immediately; do not attempt to open the file.

FALSE: Proceed to validate the filename.

---

DP-002

Condition: The filename (spec) supplied is null or empty.

TRUE: Raise a tool error immediately; do not attempt to open the file.

FALSE: Proceed to configure the WebUtil Core bean properties and open the file.

---

DP-003

Condition: The character set (charSet) parameter is null.

TRUE: Set the WUF_TEXTIO_CHARSET property to the literal string '(null)'.

FALSE: Set the WUF_TEXTIO_CHARSET property to the supplied character set value.

---

DP-004

Condition: The file handle string returned by WEBUTIL.GETPROPERTY (WUF_TEXTIO_OPEN) is null, empty, or equals '-1'.

TRUE: Raise a tool error; the file open operation failed on the client.

FALSE: Convert the handle to a number, populate the file record, and return it to the caller.

---

DP-005

Condition: An exception is raised during execution.

TRUE (BEAN_NOT_REGISTERED): Display an error alert identifying the missing WebUtil bean class, then raise a tool error.

TRUE (PROPERTY_ERROR): Re-raise the property error directly to the caller.

TRUE (VALUE_ERROR): Raise a tool error to the caller.

TRUE (TOOL_ERROR): Re-raise the tool error directly to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only the file modes 'r' (read), 'w' (write), and 'a' (append) are permitted, evaluated case-insensitively; any other mode value must be rejected before any file system access is attempted.
- BR-002 - A filename must always be provided; attempting to open a file without a name must be rejected immediately.
- BR-003 - The character set is optional; when not supplied, the WebUtil Core bean must be explicitly informed of its absence by setting the WUF_TEXTIO_CHARSET property to the literal value '(null)'.
- BR-004 - The file handle is obtained exclusively through WEBUTIL.GETPROPERTY (WUF_TEXTIO_OPEN); no file open result is valid unless retrieved via this mechanism.
- BR-005 - If the WebUtil component cannot open the file (handle is null, empty, or '-1'), a tool error must be raised so that the caller is aware the file is not available for use.
- BR-006 - If the WebUtil bean is not registered on the client, an informative error alert identifying the missing bean must be displayed before the tool error is propagated to the caller.

---
**Implementation Logic**

```plsql
  FUNCTION fopen(spec VARCHAR2, filemode VARCHAR2, charSet VARCHAR2 := null) RETURN file_type is
    clientFile file_type;
    javaHandle VARCHAR2(6);
  BEGIN
    -- check the mode is valid
    if (lower(filemode) not in ('r','w','a')) then 
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- make sure a file name has been specified      
    if (spec is null) or (spec='') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;
      
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILENAME',spec, true);
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_FILEMODE',filemode, true);        
    if (charSet is null) then
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET','(null)', true);
    else
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET',charSet, true);
    end if;
    javaHandle := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_OPEN');

    -- If the return is null then the file was not opened      
    if (javaHandle is null) or (javaHandle='') or (javaHandle='-1') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- if we are this far convert the handle to the correct format and return it.      
    clientFile.handle := to_number(javaHandle);
    return clientFile;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.fopen will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                 
      return null;
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE;
    when VALUE_ERROR then
      RAISE TOOL_ERR.TOOL_ERROR; 
    when TOOL_ERR.TOOL_ERROR then 
      RAISE;
  END fopen;
```

#### SP-007 - WEBUTIL.GETIMPLCLASS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the fully qualified Java class name for a given WebUtil package identifier by combining the WebUtil Java root namespace with the package-specific class name. This allows other WebUtil routines to resolve the correct Java implementation class when reporting errors or registering beans.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Concatenate the WebUtil Java root namespace prefix with the class name corresponding to the supplied package identifier.
- Step 2 - Return the resulting fully qualified Java class name to the caller.

---
**Decision Points**

No decision points - the logic executes unconditionally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

No distinct business rules - the procedure implements a single technical operation.

---
**Implementation Logic**

```plsql

  FUNCTION getImplClass(packageID PLS_INTEGER) return VARCHAR2 is
  BEGIN 
    return WEBUTIL_JAVA_ROOT||m_implClasses(packageID);    
  END;
```

#### SP-008 - WEBUTIL.GETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FOPEN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a named Java system property value by invoking the underlying Java runtime via the Java Native Interface (JNI). This provides a bridge between the Oracle Forms environment and the Java Virtual Machine, allowing the form to read runtime configuration values (such as server paths or environment settings) maintained by the Java system.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Create a JNI argument list of one item and add the property name as a string argument.
- Step 2 - Call the Java system's getProperty method via JNI, passing the property name.
- Step 3 - Return the string value of the property to the caller.

---
**Decision Points**

No decision points - the logic executes unconditionally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

No distinct business rules - the procedure implements a single technical operation.

---
**Implementation Logic**

```plsql
  FUNCTION getProperty(
    a0    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'getProperty', '(Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-009 - WEBUTIL.GET_LINE

**Invoked From:**

- pe_srv_ratio_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Reads the next line of text from an open server-side file and returns it to the caller. The procedure sets the WebUtil core file handle, retrieves the next line via the WebUtil core property interface, and uses a newline-only buffer as the end-of-file sentinel, raising a no-data-found exception when no more lines remain. WebUtil component registration failures and property errors are surfaced as tool errors.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| item | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Set the WebUtil core file handle property (WUF_TEXTIO_HANDLE) to the handle value carried by the incoming file parameter, identifying which open file to read from.
- Step 2 - Retrieve the next line of text from the file by calling WebUtil_Core.getProperty with the WUF_TEXTIO_GETLINE property key, storing the result in a local buffer.
- Step 3 - Inspect the buffer: if it equals a single newline character (CHR(10)), the WebUtil PJC end-of-file convention has been met; raise a no-data-found exception to signal to the caller that there are no more lines to read.
- Step 4 - If the buffer does not equal a single newline, assign the buffer contents to the output parameter and return it to the caller.
- Step 5 - If the WebUtil bean is not registered, display an error alert identifying the missing implementation class and raise a tool error. If a property error occurs, raise a tool error directly.

---
**Decision Points**

DP-001

Condition: The buffer returned by WebUtil_Core.getProperty equals a single newline character (CHR(10)).

TRUE: Raise a no-data-found exception to signal end of file to the caller.

FALSE: Assign the buffer value to the output item parameter and return it normally.

---

DP-002

Condition: A WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during execution.

TRUE: Display an error alert identifying the missing WebUtil implementation class and raise TOOL_ERR.TOOL_ERROR.

FALSE: Continue normal or alternative exception handling.

---

DP-003

Condition: A WebUtil_Core.PROPERTY_ERROR exception is raised during execution.

TRUE: Raise TOOL_ERR.TOOL_ERROR immediately.

FALSE: Continue normal processing.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A buffer value of a single newline character (CHR(10)) must be interpreted as an end-of-file signal rather than a valid line of data, because the WebUtil PJC uses this convention to indicate that the end of the file has been reached; get_line would not otherwise return a bare newline, as it uses that character as a read delimiter.
- BR-002 - If the WebUtil bean required to perform file I/O is not registered on the client, the procedure must alert the user with the name of the missing implementation class and terminate by raising TOOL_ERR.TOOL_ERROR, preventing silent data loss.
- BR-003 - Any WebUtil property error encountered during file handle assignment or line retrieval must cause the procedure to raise TOOL_ERR.TOOL_ERROR, ensuring that failures in the WebUtil layer are consistently propagated to the caller.

---
**Implementation Logic**

```plsql
  PROCEDURE get_line (file file_type, item OUT VARCHAR2) is
    buffer VARCHAR2(4000 char);
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);        
    buffer := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_GETLINE');
    -- We can't easily tell the difference between an empty line and a line beyond then 
    -- end of the file so to get around this, the exception handling code in the PJC 
    -- places a newline into the buffer when the end of file is passed.
    -- The rational being that get_line would never normally return a newline because 
    -- it normally uses that to tell it where to read up *to*.
    if buffer = chr(10) then 
      raise NO_DATA_FOUND;
    else
      item := buffer;
    end if;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.get_line will not work');
      RAISE TOOL_ERR.TOOL_ERROR;                                                                 
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE TOOL_ERR.TOOL_ERROR;  
  END get_line;
  
  /**
   * File writing functions
   */
```

#### SP-010 - WEBUTIL.ID_NULL

**Invoked From:**

- pe_srv_ratio_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]
- webutil.pld [StoredProcedure: WEBUTIL.ERRORALERT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Tests whether an internal handle (such as a record group or file handle) has been initialised. Returns true if the handle's internal reference is null (not set), or false if it holds a valid reference. This simple check allows calling code to safely determine whether a handle is usable before attempting to operate on it.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| handle | Pointer | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Inspect the internal reference field of the supplied handle.
- Step 2 - If the internal reference is null, return TRUE to indicate the handle is uninitialised; otherwise return FALSE to indicate the handle is valid and usable.

---
**Decision Points**

DP-001

Condition: The handle's internal reference field is null.

TRUE: Return TRUE - the handle is uninitialised (null).

FALSE: Return FALSE - the handle holds a valid reference.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

No distinct business rules - the procedure implements a single technical operation.

---
**Implementation Logic**

```plsql

  FUNCTION ID_NULL(handle IN Pointer)        RETURN BOOLEAN is
  BEGIN
    if handle.hnd is null then 
      return TRUE;
    else
      return FALSE;
    end if;
  END ID_NULL;
```

#### SP-011 - WEBUTIL.PUT_LINE

**Invoked From:**

- pe_srv_ratio_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a line of text to an open client-side file by setting three sequential WebUtil Core properties: the file handle, the text content, and a newline flag. If the WebUtil bean is not registered or a property error occurs, the procedure raises a fatal tool error to prevent silent data loss. This is the core routine used by the CSV export process to write each row of report data to the output file.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |
| item | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Set the WUF_TEXTIO_HANDLE property on the WebUtil Core package to identify which open file the write operation targets, using the handle value from the supplied file parameter.
- Step 2 - Set the WUF_TEXTIO_PUT property to pass the text content (item) to the WebUtil Core component for writing.
- Step 3 - Set the WUF_TEXTIO_NEWLINE property to 1, instructing the WebUtil Core component to append a newline character after the text and complete the line.
- Step 4 - If a BEAN_NOT_REGISTERED exception is raised, display an error alert identifying the missing implementation class and raise TOOL_ERR.TOOL_ERROR to halt processing.
- Step 5 - If a PROPERTY_ERROR exception is raised, raise TOOL_ERR.TOOL_ERROR to halt processing.

---
**Decision Points**

DP-001

Condition: A BEAN_NOT_REGISTERED exception is raised during property-setting operations.

TRUE: Display an error alert identifying the unregistered WebUtil bean class and raise TOOL_ERR.TOOL_ERROR to abort execution.

FALSE: Continue to the next property-setting step.

---

DP-002

Condition: A PROPERTY_ERROR exception is raised during property-setting operations.

TRUE: Raise TOOL_ERR.TOOL_ERROR to abort execution.

FALSE: Procedure completes normally after all three properties have been set.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Every line of text written to the file must be automatically terminated with a newline character (WUF_TEXTIO_NEWLINE = 1) so that CSV rows are correctly separated in the output file.
- BR-002 - If the required WebUtil bean is not registered on the client, the procedure must raise a fatal error (TOOL_ERR.TOOL_ERROR) rather than silently skipping the write, ensuring data integrity of the export file.
- BR-003 - If any WebUtil Core property-setting operation fails with a PROPERTY_ERROR, the procedure must raise TOOL_ERR.TOOL_ERROR immediately, preventing partial or corrupt line writes.

---
**Implementation Logic**

```plsql
    

  PROCEDURE put_line (file file_type, item VARCHAR2) is
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);              
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_PUT',item); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_NEWLINE',1); 
  EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.put_line will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;  
  END put_line;
```

#### SP-012 - WEBUTIL.SETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sets a named Java system property to the specified value by invoking the Java Native Interface (JNI) directly against the Java runtime. This allows the Oracle Forms environment to configure JVM-level state - such as file paths or environment parameters required by WebUtil - without relying on any intermediate helper routines.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |
| a1 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Create a JNI argument list sized for two entries using JNI.CREATE_ARG_LIST(2).
- Step 2 - Add the property name (a0) as a string argument to the argument list via JNI.ADD_STRING_ARG.
- Step 3 - Add the property value (a1) as a second string argument to the argument list via JNI.ADD_STRING_ARG.
- Step 4 - Invoke the static Java method java.lang.System.setProperty via JNI.CALL_STRING_METHOD, passing the assembled argument list.
- Step 5 - Return the string value previously held by the named property, as returned by the Java runtime, to the caller.

---
**Decision Points**

No decision points - the logic executes unconditionally for all provided input values.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Both the property name (a0) and the new property value (a1) must be supplied as VARCHAR2 inputs; the function signature does not enforce nullability, so callers are responsible for passing meaningful values.
- BR-002 - The function targets the static java.lang.System.setProperty method; the property namespace and any constraints on valid property names are governed by the JVM, not by this procedure.
- BR-003 - The return value represents the previous value of the property as held by the JVM at the time of invocation; callers that need to preserve or restore the original value must capture this return.

---
**Implementation Logic**

```plsql
  FUNCTION setProperty(
    a0    VARCHAR2,
    a1    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(2);
    JNI.ADD_STRING_ARG(args, a0);
    JNI.ADD_STRING_ARG(args, a1);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'setProperty', '(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

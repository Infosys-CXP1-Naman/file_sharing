# BUSINESS REQUIREMENTS DOCUMENT

## Table of Contents

- 1. Document Control
  - 1.1 Document Information
  - 1.2 Revision History
- 2. Executive Summary
  - Key Stakeholders
- 3. System Context
- 4. Functional Requirements
  - 4.1 Business Requirements
    - Requirement ID: BR-001
    - Requirement ID: BR-002
    - Business Scenarios - How the results layout differs by view type
    - Requirement ID: BR-003
    - Requirement ID: BR-004
    - Requirement ID: BR-005
    - Business Scenarios - How search results differ by view type
    - Requirement ID: BR-006
    - Business Scenarios - How the export differs by view type
    - Requirement ID: BR-007
    - Requirement ID: BR-008
    - Requirement ID: BR-009
- 5. Business Rules Catalogue
- 6. Data Requirements
  - 6.1 Business Entities and Relationships
    - RO Hold-Up Records - MULDMS.VH_RO_HOLD_UP
    - Repair Order Header - MULDMS.VH_RO
    - Dealer Location Master - MULDMS.AM_DEALER_LOC
    - Entity Relationships
  - 6.2 Data Capture Requirements
    - Search Filter Criteria - User-entered before executing a search
    - Session and Global Parameters - Non-database flags affecting behaviour
  - 6.3 Reference Data
  - 6.4 Data Lifecycle
  - 6.5 Excel Output Columns
- 7. Glossary
- 8. Technical Inventory
  - 8.1 Form Architecture
    - 8.1.1 Global Variables
    - 8.1.2 Form Parameters
  - 8.2 Blocks
    - 8.2.1 Block WhereClause and OrderByClause
  - 8.3 Items Summary
  - 8.4 List of Values
  - 8.5 Alerts
  - 8.6 Program Units
  - 8.7 Triggers
    - 8.7.1 Inactive / Commented-Out Trigger Register
  - 8.8 Canvas and Window Inventory
  - 8.9 Editors
  - 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups
    - 8.10.1 Visual Attributes (form-defined)
    - 8.10.2 Property Classes (form-defined)
    - 8.10.3 Object Groups
  - 8.11 DataSourceColumn Inventory
    - VH_RO_HOLD_UP (16 columns)
- 9. Object Library
- 10. Record Groups
- 11. Referenced Database Objects
  - 11.1 Block-Table Binding Summary
  - 11.2 Object Reference Detail
- 12. Backend Procedures and Packages
  - 12.1 Main Flow Backend Procedure/Package Index
  - 12.2 Procedure and Package Catalogue
    - POPULATE_DETAILS
    - ITEM_ENABLE
    - VIEW_EXCEL_REPORT_NEW
    - GENERAL.ASK_CONFIRM
    - GENERAL.DISP_TEXT
    - GENERAL.L_POP_LIST_ITEM
    - GENERAL.RAISE_ERROR
    - DBMS_APPLICATION_INFO.SET_CLIENT_INFO
    - DBMS_APPLICATION_INFO.SET_MODULE
    - WEBUTIL_CORE.CUSTOMEVENTHANDLER
    - VIEW_EXCEL_REP (INACTIVE)
    - GENERAL.CHECK_FORM_FAILURE (INACTIVE)
- 13. Package Procedure Specifications
- 14. Database Package Catalogue
- 15. PLD Procedure Call Sites
  - DPL.pld (`general`)
  - Inactive / commented-only PLD call sites
  - webutil.pld (`WEBUTIL_CORE`)
  - webutil.pld (`WEBUTIL_C_API`)
- 16. Microservice API Candidates
  - 16.1 Microservices with APIs
- 17. Workflows
- 18. PLD-Backed Logic
  - webutil.pld (`CLIENT_IMAGE`)
  - DPL.pld (`general`)
  - D2kwutil.pld (`Win_API`)
- 19. PCK-Backed Logic
- 20. System Interfaces
  - 20.1 Database Integrations
  - 20.2 External System Integrations
  - 20.3 Report Integrations
    - 20.3.1 Parameters Passed to the Report
- 21. Procedure and Function Business Rule Catalogue
  - 21.1 Catalogue Index
  - 21.2 Detailed Specifications
    - SP-001 - ITEM_ENABLE
    - SP-002 - POPULATE_DETAILS
    - SP-003 - D2KWUTIL.ATTEMPT_DLL_LOAD
    - SP-004 - D2KWUTIL.CHOOSEFILE
    - SP-005 - D2KWUTIL.D2KWUTIL_ACTIVEWIN
    - SP-006 - D2KWUTIL.D2KWUTIL_CHOOSEFILE
    - SP-007 - D2KWUTIL.D2KWUTIL_DEBUGSTRING
    - SP-008 - D2KWUTIL.D2KWUTIL_FILEINFO
    - SP-009 - D2KWUTIL.D2KWUTIL_GETDOSENV
    - SP-010 - D2KWUTIL.D2KWUTIL_GETREGKEY
    - SP-011 - D2KWUTIL.D2KWUTIL_WINDIR
    - SP-012 - D2KWUTIL.FILE_INFO
    - SP-013 - D2KWUTIL.GET_ACTIVE_WINDOW
    - SP-014 - D2KWUTIL.SAVE_FILE
    - SP-015 - D2KWUTIL.TRANSLATETYPE
    - SP-016 - GENERAL.ASK_CONFIRM
    - SP-017 - GENERAL.DISP_TEXT
    - SP-018 - GENERAL.L_POP_LIST_ITEM
    - SP-019 - GENERAL.RAISE_ERROR
    - SP-020 - I.CREATED_DATE
    - SP-021 - WEBUTIL.BLOCKING
    - SP-022 - WEBUTIL.CHECKLIBS
    - SP-023 - WEBUTIL.CLEARCALLBACKTRIGGER
    - SP-024 - WEBUTIL.CLOSEBLOB
    - SP-025 - WEBUTIL.CLOSEFILE
    - SP-026 - WEBUTIL.DOWNLOADFROMURL
    - SP-027 - WEBUTIL.DOWNLOADFROMURLINT
    - SP-028 - WEBUTIL.ERROR
    - SP-029 - WEBUTIL.ERRORALERT
    - SP-030 - WEBUTIL.EXECUTE
    - SP-031 - WEBUTIL.FCLOSE
    - SP-032 - WEBUTIL.FILE_SAVE_DIALOG
    - SP-033 - WEBUTIL.FILE_SELECTION_DIALOG_INT
    - SP-034 - WEBUTIL.FOPEN
    - SP-035 - WEBUTIL.GETCALLBACKTRIGGER
    - SP-036 - WEBUTIL.GETCLIENTOSFAMILY
    - SP-037 - WEBUTIL.GETCLIENTSETTING
    - SP-038 - WEBUTIL.GETIMPLCLASS
    - SP-039 - WEBUTIL.GETLASTERROR
    - SP-040 - WEBUTIL.GETLASTERRORARGS
    - SP-041 - WEBUTIL.GETNUMBER
    - SP-042 - WEBUTIL.GETOSFAMILY
    - SP-043 - WEBUTIL.GETOUTPUT
    - SP-044 - WEBUTIL.GETPROPERTY
    - SP-045 - WEBUTIL.GETSTRING
    - SP-046 - WEBUTIL.GETVAR
    - SP-047 - WEBUTIL.GET_LINE
    - SP-048 - WEBUTIL.GET_RETURN_CODE
    - SP-049 - WEBUTIL.GET_STANDARD_OUTPUT
    - SP-050 - WEBUTIL.HOST
    - SP-051 - WEBUTIL.ID_NULL
    - SP-052 - WEBUTIL.INIT
    - SP-053 - WEBUTIL.INITWEBUTIL
    - SP-054 - WEBUTIL.ISERROR
    - SP-055 - WEBUTIL.IS_OPEN
    - SP-056 - WEBUTIL.LENGTH
    - SP-057 - WEBUTIL.LOG
    - SP-058 - WEBUTIL.POPULATEPROPERTYBUNDLE
    - SP-059 - WEBUTIL.PUTF
    - SP-060 - WEBUTIL.PUT_LINE
    - SP-061 - WEBUTIL.READFROMPROPERTYBUNDLE
    - SP-062 - WEBUTIL.READTRANSFROMMSGBUNDLE
    - SP-063 - WEBUTIL.REGISTERBEAN
    - SP-064 - WEBUTIL.REGISTER_FUNCTION
    - SP-065 - WEBUTIL.RELEASE_PROCESS
    - SP-066 - WEBUTIL.SETCLIENTSETTING
    - SP-067 - WEBUTIL.SETDATA
    - SP-068 - WEBUTIL.SETPROPERTY
    - SP-069 - WEBUTIL.SHOWBEANS
    - SP-070 - WEBUTIL.URL_TO_CLIENT
    - SP-071 - WEBUTIL.WRITEDATA
    - SP-072 - WEBUTIL_CORE.CUSTOMEVENTHANDLER
    - SP-073 - ADD_ERROR
    - SP-074 - ADD_EXTERNAL_ERRORS
    - SP-075 - BOOLTOCHAR
    - SP-076 - CLEAN_ERROR_STACK
    - SP-077 - DEBUGLOG
    - SP-078 - GET_ENVIRONMENT_STRING
    - SP-079 - GET_TEMP_DIRECTORY
    - SP-080 - GET_WINDOWS_DIRECTORY
    - SP-081 - READ_REGISTRY
    - SP-082 - REGISTER_FUNCTION_CALL
    - SP-083 - SETDEBUG
    - SP-084 - STRIPDIRSEP
    - SP-085 - VIEW_EXCEL_REPORT_NEW
    - SP-086 - WINDEBUG

## 1. Document Control

### 1.1 Document Information

| Field | Value |
| ----- | ----- |
| Document Title | VI_RO_HOLD_UP - Business Requirements Document |
| Form Module Name | VI_RO_HOLD_UP |
| Document Version | 1.0 |
| Date Created | August 15, 2026 |
| Author/Prepared By | BRD Agent |

### 1.2 Revision History

| Version | Date | Author | Description |
| --- | --- | --- | --- |
| 1.0 | August 15, 2026 | BRD Agent | Initial draft |

---

## 2. Executive Summary

*High-level overview of the vi_ro_hold_up form, its purpose, and roles referenced in the module.*

The **vi_ro_hold_up** Oracle Forms module is the **CEO Control Point for Service Area** screen. Service managers and supervisors use this screen to monitor repair orders that have not been completed within their promised delivery date - commonly referred to as "hold-up" jobs. The user selects a report type (non-Body and Paint hold-ups, Body and Paint hold-ups, billing ageing, or CEO odometer approval), a service location, and a reference date; the screen then displays a list of all matching job cards along with vehicle registration, job date, model, promised date, and the reason the job is on hold. For the billing ageing view, the screen shows parts cost, labour cost, and total bill amount instead of hold reasons. For the CEO odometer approval view, the screen displays jobs awaiting or having received CEO-level approval for odometer reading changes, including the approval status, odometer reason, and CEO remarks. Users can export any of these views to a CSV file for offline analysis.

### Key Stakeholders

*Who uses vi_ro_hold_up*

| Stakeholder | Role |
| :--- | :--- |
| **Service Manager / Supervisor** | **Primary interactive user** of vi_ro_hold_up. Selects the report type and location, initiates the search, reviews hold-up job cards, and exports results to Excel |
| **CEO / Senior Approver** | Decision-maker for odometer change approval requests; their approval status, reason, and remarks are displayed in the status-800 view but entered outside this form |
| **Vehicle Owner / Customer** | Subject whose vehicle repair order appears in the hold-up list; does not interact with the form directly |

---

---

## 3. System Context

*Describes the vi_ro_hold_up module's role within the DMS ecosystem, scope, process flow, and key integrations.*

The **vi_ro_hold_up** module is the **CEO Control Point for Service Area** monitoring screen within the Dealer Management System. It provides service managers and supervisors with a real-time view of repair orders that have passed their promised delivery date without being closed. The screen feeds into service performance oversight and escalation processes, and connects to the vehicle, model, and hold-reason master data to present actionable information in a single view.

**System purpose:** Allow authorised service personnel to select a report category and location, retrieve all overdue or flagged repair orders meeting the selected criteria, review the relevant job card details, and export the results to a CSV file for further analysis or reporting.

**In scope:**

- Selection of report type (Non-B&P hold-ups, B&P hold-ups, Billing Ageing, CEO Odometer Approval) for the current view
- Selection of active service location from the user's authorised dealer-location list
- Date range entry and validation (single date for hold-up views; date range for Billing Ageing)
- Dynamic column layout - the result grid adjusts its visible fields according to the selected report type
- Retrieval and display of overdue job card details including job card number, vehicle registration, job date, model, promised date, and hold reason
- Display of billing amounts (parts cost, labour cost, total bill) for the Billing Ageing view
- Display of CEO approval status, odometer reason, and CEO remarks for the CEO Odometer Approval view
- CSV export of the current result set to an Excel-compatible file
- Error message display for validation failures and data population issues
- Form exit and clear navigation functions

**Process Name:** RO Hold-Up Monitoring and Export

**Process Owner:** Service Manager / Supervisor

**Process Objective:** Select a report type and service location, enter the reference date, retrieve all overdue or flagged repair orders for that location and date, review the details on screen, and optionally export the result to a CSV file.

**Process Trigger:** A service manager or supervisor opens the CEO Control Point for Service Area screen to review repair order hold-up status for a specific date and location

**Process Flow:**

The complete RO hold-up monitoring and export process follows this sequence. Each step corresponds to Functional Requirements in Section 4.

```
STEP 1 ── SCREEN OPENS
         The user opens the vi_ro_hold_up form.
         The DBMS application context is set to the form name for session tracking.
         The search criteria block is displayed with empty fields.

STEP 2 ── SELECT REPORT TYPE
         The user selects a report type from the Status dropdown:
         ├── 400: Non-Body-and-Paint hold-up jobs (overdue open ROs excluding B&P)
         ├── 500: Body-and-Paint hold-up jobs (overdue open B&P ROs)
         ├── 600: Billing Ageing (billed B&P ROs with total bill above threshold)
         └── 800: CEO Odometer Approval (ROs with odometer change pending or actioned)
         On selection, the result grid columns and the date range fields are reconfigured
         to match the chosen report type. The result block is cleared.

STEP 3 ── SELECT LOCATION
         The user enters or selects a service location using the Location LOV.
         The LOV lists only active locations that the logged-in user is authorised to access.
         The location code and dealer map code are captured internally.

STEP 4 ── ENTER FROM DATE
         The user enters the reference "As on Date" (From Date).
         Validation checks that From Date is not empty, not in the future, and not after To Date.
         For Status 400, 500, and 800 the To Date field is hidden and not required.
         For Status 600 the To Date field is enabled and required.
         On successful validation, To Date is auto-calculated as the last day of From Date's month
         (capped at yesterday if the month end is in the future).

STEP 5 ── ENTER TO DATE - Status 600 only
         For Status 600 only, the user reviews or adjusts the auto-calculated To Date.
         Validation checks that To Date is not null, not less than From Date, not in the
         future, and that the date range does not exceed one month.

STEP 6 ── SEARCH
         The user presses the Search button.
         The system queries the hold-up or repair-order tables using the selected dealer,
         location, report type, and date criteria.
         ├── Status 400: Retrieves non-B&P open ROs with promised date on or before From Date
         ├── Status 500: Retrieves B&P open ROs with promised date on or before From Date
         ├── Status 600: Retrieves billed B&P ROs in the date range with total bill > 11,500
         └── Status 800: Retrieves non-B&P open ROs pending or actioned for odometer approval

STEP 7 ── POPULATE RESULT GRID
         The result grid is populated row by row with serial number, job card number,
         vehicle registration, job date, model description, and status-specific fields.
         For Status 400 and 500: promised date and reason for hold are shown.
         For Status 600: parts amount, labour amount, and total bill are shown.
         For Status 800: job card, registration, job date, model, promised date, CEO
         approval status, odometer reason, and CEO remarks are shown.
         If no data is found, a "Data not available" message is shown.

STEP 8 ── REVIEW RESULTS
         The user reviews the displayed job cards.
         The result block is read-only - no insert, update, or delete is permitted.

STEP 9 ── EXPORT TO EXCEL - optional
         The user presses the Export to Excel button.
         The system builds a CSV query matching the currently selected status and criteria,
         including a header row, and calls the Excel report utility to download the file.
         The exported file is named with the user ID and current timestamp.
         ├── Status 400 export: Job Card No., Reg No., JO Date, Model, Service Type,
                                Promised Date & Time, Reason for Hold
         ├── Status 500 export: Job Card No., Reg No., JO Date, Model,
                                Promised Date & Time, Reason for Hold
         ├── Status 600 export: Reg No., Model, Parts Cost, Labour Cost, Total Bill
         └── Status 800 export: Job Card No., Reg No., JO Date, Model, Service Type,
                                Promised Date & Time, CEO Approval Status, CEO Reason, CEO Remarks

STEP 10 ── CLEAR
          The user presses Clear to reset both the result block and the search criteria block
          without navigating away from the form.

STEP 11 ── EXIT
          The user presses Exit or the NB_EXIT navigation button.
          The DBMS application context is cleared and the form is closed without validation.
```

**Major process interactions:**

- **Hold-up register** - primary data source for all open overdue repair orders by dealer, location, and date
- **Repair order header** - supplementary data source for billing amounts and odometer change approval fields used in status-600 and status-800 views
- **Vehicle model master** - resolves vehicle model description from the model code for display and export
- **Hold reason master** - resolves hold reason description from the reason code for status-400 and status-500 display and export
- **Sub-service category master** - resolves sub-repair category description for service type display in status-400 and status-800 exports
- **Service variant master** - resolves variant description from service model code for status-600 export
- **User-dealer location access** - filters the location LOV to show only locations the logged-in user is authorised to access
- **Excel report utility** - generates and downloads the CSV export file to the user's workstation

---

---

## 4. Functional Requirements

### 4.1 Business Requirements

#### Requirement ID: BR-001

**Requirement Title:** Form Session Initialisation

**Business Description:**
When the RO Hold-Up enquiry screen is opened, the system automatically registers the current session with the application infrastructure so that the form's activity can be properly tracked and audited. It then initialises the search screen to a ready-to-use default state: the main window is maximised, the date filter defaults to yesterday, the view-type dropdown is populated with the available hold-up categories for the dealership, and the results columns are arranged for the default view. This initialisation happens transparently before the user interacts with the screen, ensuring every session is correctly identified, default values are pre-set, and the user can begin searching immediately.

**Actors:** Dealership User (any user who opens the RO Hold-Up enquiry form)

**Preconditions:**
- The user has successfully authenticated to the dealership management system and launched the RO Hold-Up enquiry from the menu.

**Main Flow:**

**Step 1 - Session context registered before the screen appears**
Before the main search screen is displayed to the user, the system silently records the form's module name and an empty action name against the current database session using the application information context. This allows database-level monitoring and auditing tools to attribute all subsequent activity to this screen and user session. No user interaction is required and no message is shown.

**Step 2 - Screen maximised and system message level set**
The main enquiry window is automatically maximised to fill the available display area when it first opens. The system message level is set so that routine informational codes generated by the Forms engine are suppressed and do not appear as distracting pop-up messages during normal use.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

**Step 3 - Date filter and view type defaulted**
The As On Date filter is automatically set to yesterday's date so the user has a sensible starting point without having to type a date. The view type is defaulted to the standard hold-up view (value 400) so the screen is immediately ready for the most common enquiry.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

**Step 4 - Application identifier seed set**
The system assigns the application identifier *`vi_ro_hold_up`* to the session global variable `global.app_id` and copies that value into the form parameter `P_APP_ID`, so that called routines and downstream processing can identify which application module is running.

**Step 5 - View-type dropdown populated from hold-up category list**
The Status dropdown is loaded with the hold-up control-point categories applicable to this dealership's service division. The list is retrieved from the application list master (record group `L_ITEM`), filtered to the CEO control-point list named `CEO_CTRL_POINT` for the `SERVICE` list category and the current dealership principal. Only categories valid for this principal are shown in the dropdown.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| View-type list populated for current principal | WHEN-NEW-FORM-INSTANCE - GENERAL.L_POP_LIST_ITEM('L_ITEM', ...) / POPULATE_LIST('CB_DUMMY.STATUS', 'L_ITEM') | When the form first opens | Ensures the Status dropdown contains only the hold-up categories relevant to this dealership's service division | If no matching list entries are found, the dropdown remains empty; the user cannot select a view type. |

**Step 6 - Results grid arranged for the default view type**
After the dropdown is loaded, the system calls the internal screen-layout routine to show and hide the correct result columns and filter controls for the default view type (standard hold-up). This ensures the grid is immediately correct for the view the user is most likely to run, without requiring them to change the status selection first.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Status (`STATUS`) | Auto-populated | List Item | 500 | CEO control-point list (`L_ITEM` - AM_LIST where list_name = 'CEO_CTRL_POINT', list_name_desc = 'SERVICE') | Available hold-up category codes and descriptions for this principal | Form open | Defaulted to value 400 (standard hold-up view) | Dropdown empty if no matching list entries exist for the principal |
| As on Date (`FROM_DATE`) | Auto-populated | Date | 12 / DD-MM-RRRR | N/A | Yesterday's date (SYSDATE - 1) | Form open | Defaulted by system at initialisation | N/A |

---

---

#### Requirement ID: BR-002

**Requirement Title:** Hold-Up View Type Selection and Results Screen Layout Adjustment

**Business Description:**
The user selects the type of RO hold-up report they want to view from a status list on the search criteria screen. As soon as the selection changes, the system immediately rearranges the results grid to show only the columns relevant to that view type and sets the date filter defaults to yesterday's date. For the billing variance view, both a From Date and a To Date filter are shown and must be provided; for all other views, only the As On Date filter is shown. Fields for approval status, odometer reason, and CEO remarks are shown only when the approval-pending view is selected.

**Actors:** Dealership User

**Preconditions:**
- The RO Hold-Up enquiry screen is open.
- The status drop-down list is available for selection.

**Main Flow:**

**Step 1 - User selects a hold-up view type**
The user selects one of the available view types from the Status drop-down list on the search criteria screen. The system responds immediately, reconfiguring the results area and filter controls to match the selected view.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

**Step 2 - Screen layout adjusted for the selected view type**
Based on the view type selected, the system sets the As On Date filter to yesterday's date and shows or hides result columns and secondary date filters as follows.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

- **Non-Body and Paint (service ROs) view** - As On Date defaulted to yesterday; To Date filter hidden and disabled; result columns shown: Job Card Number, Vehicle Reg No, JO Date, Model, Promised Date & Time, Reason for Hold; billing amount columns hidden; approval-status columns hidden.
- **Body and Paint (B&P) view** - As On Date defaulted to yesterday; To Date filter hidden and disabled; result columns shown: Job Card Number, Vehicle Reg No, JO Date, Model, Promised Date & Time, Reason for Hold; billing amount columns hidden; approval-status columns hidden.
- **Billing variance view** - Both From Date and To Date defaulted to yesterday and both shown and enabled; result columns shown: Vehicle Reg No, Model, Part Amount, Labour Amount, Bill Amount; Job Card Number, JO Date, Promised Date & Time, Reason for Hold columns hidden; approval-status columns hidden.
- **Approval-pending odometer view** - As On Date defaulted to yesterday; To Date filter hidden and disabled; result columns shown: Job Card Number, Vehicle Reg No, JO Date, Model, Promised Date & Time; Reason for Hold hidden; billing amount columns hidden; Approve Status, Odometer Reason, and CEO Remarks columns shown and enabled but set to read-only (insert and update not allowed).

**Step 3 - Results area cleared and focus returned to Location filter**
After the layout is adjusted, any previously loaded results are cleared and the cursor is moved back to the Location filter field so the user can proceed with entering search criteria for the newly selected view.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

#### Business Scenarios - How the results layout differs by view type

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Non-Body and Paint service ROs** | As On Date shown; To Date hidden; grid shows Job Card, Reg No, JO Date, Model, Service Type, Promised Date & Time, Reason for Hold. |
| **Body and Paint (B&P) ROs** | As On Date shown; To Date hidden; grid shows Job Card, Reg No, JO Date, Model, Promised Date & Time, Reason for Hold. |
| **Billing variance** | Both From Date and To Date shown and enabled; grid shows Reg No, Model, Part Amount, Labour Amount, Bill Amount; date range controls differ. |
| **Approval-pending odometer** | As On Date shown; To Date hidden; grid shows Job Card, Reg No, JO Date, Model, Promised Date & Time, plus Approve Status, Odometer Reason, CEO Remarks (read-only). |

**Alternative Flows:**
None evidenced - the trigger runs for each of the four supported status values; no alternative branch produces an error or warning.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Status (`STATUS`) | Mandatory | List Item | 500 | N/A | View type values (400 / 500 / 600 / 800) | Screen open | Must be one of the four supported view type values | N/A - list constrains available values |
| As on Date (`FROM_DATE`) | Auto-populated | Date | 12 / DD-MM-RRRR | N/A | Yesterday's date | Status selected | Defaulted by system on status change | N/A |
| To Date (`TO_DATE`) | Conditional - shown only for billing variance view | Date | 12 / DD-MM-RRRR | N/A | Yesterday's date | Status selected as billing variance | Defaulted by system; user may change within validation rules | Validated on leave (see BR-004) |
| Location (`CB_LOC_DESC`) | Conditional | Text | 200 | Location list (LOV_LOC) | Location description | Status selected | N/A | N/A |

---

---

#### Requirement ID: BR-003

**Requirement Title:** As On Date Entry and Validation

**Business Description:**
For hold-up enquiry views other than the billing variance view, the user provides a single "As On Date" to filter the results. This date represents the hold-up snapshot date being queried. The system validates that the date is not left blank, not in the future, and not after any To Date already entered. After the date is confirmed, the system automatically calculates and sets the To Date to either the last day of the calendar month following the As On Date or yesterday - whichever is earlier - bounding the default search window to one calendar month.

**Actors:** Dealership User

**Preconditions:**
- The search criteria screen is open.
- A view type that uses the As On Date filter has been selected (any view type other than the billing variance view).

**Main Flow:**

**Step 1 - User enters the As On Date**
The user types a date into the As On Date field. The system validates the entered value when the user moves off the field.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

**Step 2 - Date validated against business rules**
The system checks that the date is not blank, not after today, and not after the To Date (if already entered). All three checks run in the order shown; the first failure stops processing and shows an alert.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| As On Date is not blank | WHEN-VALIDATE-ITEM on CB_DUMMY.FROM_DATE - blank check in the ELSE branch | When the user moves off the As On Date field | Prevents searching with no date filter | *"From Date can not be empty"* shown as an error; field entry blocked. |
| As On Date is not after today | WHEN-VALIDATE-ITEM on CB_DUMMY.FROM_DATE - future-date check | When the user moves off the As On Date field | Prevents querying future dates for which hold-up data cannot exist | Alert *"From Date cannot be greater than Current Date"* shown; field entry blocked. |
| As On Date is not after To Date | WHEN-VALIDATE-ITEM on CB_DUMMY.FROM_DATE - date-order cross-check | When the user moves off the As On Date field, after the first two checks pass | Ensures the date range is logically consistent | Alert *"From Date cannot be greater than To Date"* shown; both date fields are cleared. |

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-ES-01** - As On Date left blank - *"From Date can not be empty"*; field entry blocked.
- **BR-003-ES-02** - As On Date is after today - *"From Date cannot be greater than Current Date"*; field entry blocked.
- **BR-003-ES-03** - As On Date is after To Date - *"From Date cannot be greater than To Date"*; both date fields are cleared.

**Step 3 - To Date automatically calculated**
After the As On Date passes all checks, the system calculates the last day of the calendar month following the As On Date. If that date is after today, the To Date is set to yesterday; otherwise it is set to that month-end date.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

**Alternative Flows:**
- **BR-003-AF-01** - (from Step 2) As On Date is blank: *"From Date can not be empty"* shown; field entry blocked; user must enter a valid date.
- **BR-003-AF-02** - (from Step 2) As On Date is after today: alert *"From Date cannot be greater than Current Date"* shown; field entry blocked; user must enter a date on or before today.
- **BR-003-AF-03** - (from Step 2) As On Date is after To Date: alert *"From Date cannot be greater than To Date"* shown; both date fields cleared; user must re-enter both dates.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| As on Date (`FROM_DATE`) | Mandatory | Date | 12 / DD/MM/RRRR | N/A | N/A | View type selected (non-billing variance) | Must not be blank; must not be after today; must not be after To Date | *"From Date can not be empty"* / *"From Date cannot be greater than Current Date"* / *"From Date cannot be greater than To Date"* |
| To Date (`TO_DATE`) | Auto-populated | Date | 12 / DD/MM/RRRR | N/A | Last day of following calendar month, capped at yesterday | As On Date entered and validated | Set by system calculation; user may override subject to BR-004 | N/A |

---

---

#### Requirement ID: BR-004

**Requirement Title:** To Date Entry and Validation for Billing Variance View

**Business Description:**
When the user is using the billing variance view, both a From Date and a To Date are required as date-range filters. The system validates the To Date to ensure it is not blank, that the From Date has already been entered, that it does not precede the From Date, that it is not after today, and that the date range does not exceed one calendar month. These rules protect the system from excessively large or logically inconsistent date-range queries on billing data.

**Actors:** Dealership User

**Preconditions:**
- The billing variance view has been selected.
- The As On Date (From Date) has already been entered in the date filter.
- The user has entered a value into the To Date field and is moving off it.

**Main Flow:**

**Step 1 - To Date validation gate checked**
The system checks whether the billing variance view is currently selected before running any To Date validation. If a different view type is active, no validation runs and the trigger exits silently.

**Step 2 - To Date checked against business rules**
If the billing variance view is active, the system validates the To Date in the following order: the field must not be blank; the From Date must already be entered; the To Date must not be earlier than the From Date; the From Date must not be greater than the To Date (redundant cross-check); the To Date must not be greater than today; and the date range must not exceed one calendar month.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Billing variance view is active | WHEN-VALIDATE-ITEM on CB_DUMMY.TO_DATE - outer `IF :STATUS IN ('600')` gate | When the user moves off the To Date field | Ensures To Date validation is only applied when relevant | No validation runs for other view types; trigger exits silently. |
| To Date is not blank | WHEN-VALIDATE-ITEM on CB_DUMMY.TO_DATE - null check in the ELSE branch | When the user moves off the To Date field with billing variance selected | Ensures a To Date has been provided | *"To Date can not be empty"* shown; field entry blocked. |
| From Date is already entered | WHEN-VALIDATE-ITEM on CB_DUMMY.TO_DATE - From Date null check | When the user moves off the To Date field | Prevents a date range with a missing start date | *"To date cannot be entered without entering From date"* shown; To Date is cleared; field entry blocked. |
| To Date is not before From Date | WHEN-VALIDATE-ITEM on CB_DUMMY.TO_DATE - less-than check | When the user moves off the To Date field | Ensures the date range is logically consistent | Alert *"To Date cannot be lesser than From Date"* shown; field entry blocked. |
| From Date is not after To Date (cross-check) | WHEN-VALIDATE-ITEM on CB_DUMMY.TO_DATE - greater-than cross-check | When the user moves off the To Date field | Secondary consistency check | Alert *"From Date cannot be greater than To Date"* shown; field entry blocked. |
| To Date is not after today | WHEN-VALIDATE-ITEM on CB_DUMMY.TO_DATE - future-date check | When the user moves off the To Date field | Prevents querying future billing data | Alert *"To Date cannot be greater than Current Date"* shown; field entry blocked. |
| Date range does not exceed one calendar month | WHEN-VALIDATE-ITEM on CB_DUMMY.TO_DATE - month-range check | When the user moves off the To Date field | Prevents excessively large billing range queries | Alert *"Please give the date range of maximum One Month"* shown; field entry blocked. |

*Business outcomes (errors, warnings, success, and status):*
- **BR-004-ES-01** - To Date is blank - *"To Date can not be empty"*; field entry blocked.
- **BR-004-ES-02** - From Date not yet entered - *"To date cannot be entered without entering From date"*; To Date is cleared.
- **BR-004-ES-03** - To Date is before From Date - *"To Date cannot be lesser than From Date"*; field entry blocked.
- **BR-004-ES-04** - From Date is after To Date (cross-check) - *"From Date cannot be greater than To Date"*; field entry blocked.
- **BR-004-ES-05** - To Date is after today - *"To Date cannot be greater than Current Date"*; field entry blocked.
- **BR-004-ES-06** - Date range exceeds one calendar month - *"Please give the date range of maximum One Month"*; field entry blocked.

**Alternative Flows:**
- **BR-004-AF-01** - (from Step 1) A view type other than billing variance is currently selected: no validation runs; trigger exits silently.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| To Date (`TO_DATE`) | Mandatory - when billing variance view is selected | Date | 12 / DD/MM/RRRR | N/A | N/A | Billing variance selected; From Date entered | Must not be blank; must not be before From Date; must not be after today; range must not exceed one calendar month | See BR-004-ES-01 through BR-004-ES-06 |
| As on Date (`FROM_DATE`) | Mandatory | Date | 12 / DD/MM/RRRR | N/A | N/A | Billing variance view selected | Must not be blank when To Date is being entered | *"To date cannot be entered without entering From date"* |

---

---

#### Requirement ID: BR-005

**Requirement Title:** Search and Display RO Hold-Up Results

**Business Description:**
After selecting the view type and entering the required date filters, the user clicks Search to retrieve the matching RO hold-up records from the database. The system queries the hold-up data filtered by the user's dealership location, the selected date, and the active view type, then displays the results in the on-screen results grid. Each view type retrieves a different subset of data: service ROs overdue on their promised delivery date (non-Body & Paint), Body & Paint ROs overdue, completed ROs with a billing amount above a set threshold, or ROs with a pending odometer-change approval. If no records are found, the user sees an informational message. If an unexpected error occurs during retrieval, an error is shown and the search stops.

**Actors:** Dealership User

**Preconditions:**
- The search criteria screen is open.
- A view type has been selected.
- The required date filter(s) for the selected view have been entered and have passed validation.
- The dealership location filter has been selected.

**Main Flow:**

**Step 1 - User clicks Search**
The user clicks the Search button. The system identifies the currently selected view type and calls the data-retrieval procedure to populate the results grid.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **POPULATE_DETAILS** ([SP-001](#SP-001--POPULATE_DETAILS)) - POPULATE_DETAILS - retrieves and loads hold-up records into the results grid based on the selected view type, dealership location, and date filter. The procedure uses one of four view-specific queries, loads each matching row into the on-screen results block, performs reference-data lookups for model and hold-reason descriptions, and resets the block to read-only after loading. If no rows are found, an informational note is shown; if an unexpected database error occurs, an error message is shown.
    * **Step 1** - The results block is temporarily enabled for insert, update, and delete so that records can be loaded programmatically.
    * **Step 2** - Based on the selected view type, the appropriate query is executed: service ROs overdue on their promised delivery date (non-Body & Paint category, open status, location and date matching); Body & Paint ROs overdue (same filters, Body & Paint category); completed ROs in the billing-variance date range where the combined part and labour amount exceeds the threshold (2S/3S dealer types only, active location); or hold-up records joined to the RO header to include odometer-change approval status (Pending, Approved, or Rejected).
    * **Step 3** - For each record returned, all relevant fields are loaded into the corresponding row in the results block, and a sequential serial number is assigned based on the current cursor position.
    * **Step 4** - For service RO and Body & Paint views, the model description is looked up from the vehicle model master for each row; if not found, the value "NA" is used. The hold-reason description is also looked up from the delay-reason master; if not found, "NA" is used.
    * **Step 5** - For the billing variance view, the variant/sub-model description is looked up from the variant master for each row; if not found, "NA" is used.
    * **Step 6** - After all rows are loaded, the results block is reset to read-only (insert, update, and delete disallowed).
    * **Step 7** - If no records matched the criteria, the message *"Data not available"* is shown as a note. If any other unexpected error occurs during loading, a message combining the fixed phrase "Unable to populate" with the database error description is shown, and processing stops.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| View type is one of the four supported values | WHEN-BUTTON-PRESSED on CB_DUMMY.PB_SEARCH - outer IF/ELSIF chain on `:STATUS` | When the user clicks the Search button | Ensures the search is only run for a recognised view type | If the status is not 400, 500, 600, or 800, no search executes; results grid is not updated. |
| Records exist for the search criteria | POPULATE_DETAILS [SP-001] - `EXCEPTION WHEN no_data_found` | During search execution | Alerts the user when no hold-up records match the filters | *"Data not available"* shown as a note; results grid remains empty. |
| No unexpected database error during retrieval | POPULATE_DETAILS [SP-001] - `WHEN OTHERS THEN GENERAL.DISP_TEXT('Unable to populate' \|\| SQLERRM, 'Error')` | During search execution | Surfaces retrieval errors to the user rather than silently failing | Message showing "Unable to populate" followed by the database error text is displayed; processing stops. |

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-WS-01** - No records matched - *"Data not available"*; results grid is empty; user may adjust filters and search again.
- **BR-005-ES-01** - Unexpected database error during retrieval - *"Unable to populate"* followed by the database error text; search stops.

**Step 2 - Results displayed and focus positioned on first record**
Once all rows are loaded, the cursor is positioned at the first record in the results grid. The results are shown in read-only mode.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

#### Business Scenarios - How search results differ by view type

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Non-Body and Paint service ROs** | Queries non-B&P service ROs at the location where hold-up date matches As On Date, status is open, and promised date is on or before As On Date; grid shows Job Card, Reg No, JO Date, Model, Service Type, Promised Date & Time, Reason for Hold. |
| **Body and Paint (B&P) ROs** | Queries B&P category ROs with the same hold-up, status, and date criteria; grid shows Job Card, Reg No, JO Date, Model, Promised Date & Time, Reason for Hold. |
| **Billing variance** | Queries completed ROs (status 40, B&P category) where combined part and labour amount exceeds 11,500, bill date falls within the From-To Date range, and the dealership is active (2S/3S type only); grid shows Reg No, Model, Part Amount, Labour Amount, Bill Amount. |
| **Approval-pending odometer** | Queries hold-up records joined to the RO header filtered by odometer-change flag set to Pending, Approved, or Rejected; grid shows Job Card, Reg No, JO Date, Model, Promised Date & Time, CEO Approval Status, Odometer Reason, CEO Remarks. |

**Alternative Flows:**
- **BR-005-AF-01** - (from Step 1) View type value is not 400, 500, 600, or 800: no search is executed; results grid is not updated.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Status (`STATUS`) | Mandatory | List Item | 500 | N/A | 400 / 500 / 600 / 800 | Screen open | Must be one of the four supported view type values | Silent - no search runs if value unrecognised |
| Location (`CB_LOC_DESC`) | Mandatory | Text | 200 | Location list (LOV_LOC - RG_LOC) | Location description | Status selected | Must be selected before search | N/A |
| Location Code (`CB_LOC_CD`) | Auto-populated | Text | N/A | N/A | Code returned from location LOV | Location description selected | System-populated from LOV | N/A |
| As on Date (`FROM_DATE`) | Mandatory | Date | 12 / DD/MM/RRRR | N/A | N/A | View type selected | Must pass BR-003 validation | See BR-003 |
| To Date (`TO_DATE`) | Mandatory - billing variance only | Date | 12 / DD/MM/RRRR | N/A | N/A | Billing variance selected; From Date valid | Must pass BR-004 validation | See BR-004 |
| Srl No. (`SRL_NUM`) | Read-only display | Number | N/A | N/A | Sequential row number | Search executed | System-assigned | N/A |
| Job Card Number (`RO_NUM`) | Read-only display | Text | 12 | N/A | N/A | Search executed | N/A | N/A |
| Vehicle Reg No (`REG_NUM`) | Read-only display | Text | 20 | N/A | N/A | Search executed | N/A | N/A |
| JO Date (`RO_DATE`) | Read-only display | Date | 11 / DD-MM-RRRR | N/A | N/A | Search executed | N/A | N/A |
| Model Code (`MODEL_CODE`) | Read-only display | Text | 5 | N/A | N/A | Search executed | N/A | N/A |
| Model Code (Description) (`MODEL_DESC`) | Read-only display | Text | 50 | Vehicle model master (GM_MOD) | Model description | Search executed | If not found, displays "NA" | N/A |
| Promised Date & Time (`PROMISED_DATE`) | Read-only display | Date | 11 / DD-MM-RRRR | N/A | N/A | Search executed (non-billing variance views) | N/A | N/A |
| Reason for Hold (`REASON_DESC`) | Read-only display | Text | 50 | Delay reason master (VM_DREASON) | Reason description | Search executed (service and B&P views) | If not found, displays "NA" | N/A |
| Part Amount (`PART_AMT`) | Read-only display | Number | N/A | N/A | N/A | Search executed (billing variance view only) | N/A | N/A |
| Labour Amount (`LABOUR_AMT`) | Read-only display | Number | N/A | N/A | N/A | Search executed (billing variance view only) | N/A | N/A |
| Bill Amount (`BILL_AMT`) | Read-only display | Number | N/A | Calculated as Part Amount + Labour Amount | N/A | Search executed (billing variance view only) | N/A | N/A |
| Approve Status (`CEO_APPROVE_STATUS`) | Read-only display | Text | 20 | N/A | Approval Pending / Approved / Rejected | Search executed (approval-pending view only) | Derived from odometer-change flag on RO header | N/A |
| Odometer Reason (`ODOMETER_REASON`) | Read-only display | Text | 500 | N/A | N/A | Search executed (approval-pending view only) | N/A | N/A |
| CEO Remarks (`CEO_REMARKS`) | Read-only display | Text | 200 | N/A | N/A | Search executed (approval-pending view only) | N/A | N/A |

---

---

#### Requirement ID: BR-006

**Requirement Title:** Export Hold-Up Results to Excel (CSV)

**Business Description:**
After hold-up results have been retrieved, the user can export the data to a CSV file for further analysis outside the system. The user clicks the Export to Excel button, and the system dynamically constructs a data extraction query for the currently selected view type, then calls the Excel report utility to generate and download the CSV file to the user's workstation. The file is uniquely named using the logged-in user's ID combined with a date-and-time stamp. If an unexpected error occurs during the export, it is silently discarded without any message to the user.

**Actors:** Dealership User

**Preconditions:**
- The search criteria screen is open.
- A view type has been selected and search criteria have been set.

**Main Flow:**

**Step 1 - User clicks Export to Excel**
The user clicks the Export to Excel button. The system determines the currently selected view type and starts building the data extraction query for that view.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

**Step 2 - Unique CSV file name generated**
The system constructs a file name from the logged-in user's identifier combined with the current date and time (formatted as `YYYYMMDDHH24MISS`), with a `.CSV` extension, ensuring no two exports overwrite each other.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

**Step 3 - Data query constructed for the selected view type**
Based on the selected view type, the system builds a dynamic SQL query that retrieves the same data shown in the results grid (filtered by dealership, location, date, and view-specific criteria) and formats it as comma-separated rows with a header row. The query string is stored in an internal field on the form.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

**Step 4 - Excel report utility called to generate and download the file**
The system calls the Excel report utility, passing the dealership principal code, the generated file name, the constructed query string, the output column name, and the application identifier. The utility executes the query, formats the output, and downloads the CSV to the user's workstation.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **VIEW_EXCEL_REPORT_NEW** ([SP-066](#SP-066--VIEW_EXCEL_REPORT_NEW)) - VIEW_EXCEL_REPORT_NEW (DMS_EXCEL_REPORT library) - receives the principal code, file name, data query, output column name, and application identifier; executes the query against the database; formats the results as CSV; and delivers the file to the client.
    * **Step 1** - The routine receives the principal code, target file name, SQL query, output column name, and application identifier as inputs.
    * **Step 2** - The SQL query is executed to retrieve the rows to be exported.
    * **Step 3** - The resulting rows are formatted as comma-separated values with a header row.
    * **Step 4** - The formatted CSV content is written and transferred to the client workstation for download.
    * **Step 5** - Control returns to the calling screen after the transfer completes or encounters an error.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| View type is one of the four supported values | WHEN-BUTTON-PRESSED on CB_DUMMY.PB_EXCEL - outer IF/ELSIF chain on `:status` | When the user clicks the Export to Excel button | Ensures the export is only performed for a recognised view type | If the status does not match any of the four values, no query is built and no file is generated (silent). |

*Business outcomes (errors, warnings, success, and status):*
- **BR-006-IC-01** - Unexpected export error silently discarded - the `EXCEPTION WHEN OTHERS THEN NULL` branch in the calling trigger means any unexpected error during export is caught without any message to the user.

#### Business Scenarios - How the export differs by view type

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Non-Body and Paint service ROs** | CSV columns: Job Card Number, Registration Number, JO Date, Model, Service Type, Promised Date & Time, Reason for Hold. Service type sourced from service category and sub-category masters. |
| **Body and Paint (B&P) ROs** | CSV columns: Job Card Number, Registration Number, JO Date, Model, Promised Date & Time, Reason for Hold. |
| **Billing variance** | CSV columns: Registration Number, Model, Cost of Part, Cost of Labour, Total Bill. RO date filter starts 90 days before the From Date; bill date upper bound is To Date incremented by 1 day. |
| **Approval-pending odometer** | CSV columns: Job Card Number, Registration Number, JO Date, Model, Service Type, Promised Date & Time, CEO Approval Status, CEO Reason, CEO Remarks. Approval status decoded from the RO header odometer-change flag. |

**Alternative Flows:**
- **BR-006-AF-01** - (from Step 1) View type value is not 400, 500, 600, or 800: no export is executed; no message is shown.
- **BR-006-AF-02** - (from Step 4) Any unexpected error during the export call: silently caught (`EXCEPTION WHEN OTHERS THEN NULL`); no message is shown.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Status (`STATUS`) | Mandatory | List Item | 500 | N/A | 400 / 500 / 600 / 800 | Screen open | Must be one of the four supported view type values | Silent if unmatched |
| As on Date (`FROM_DATE`) | Mandatory | Date | 12 / DD/MM/RRRR | N/A | N/A | View type selected | Used as hold-up date or billing start date in the export query | N/A |
| To Date (`TO_DATE`) | Conditional - billing variance only | Date | 12 / DD/MM/RRRR | N/A | N/A | Billing variance selected | Used as billing end date (incremented by 1 day) in the export query | N/A |
| Export query text (`TXT`) | Auto-populated | Text | 5000 | N/A | System-generated SQL query string | Export button pressed | Set internally; not shown to user | N/A |

---

---

#### Requirement ID: BR-007

**Requirement Title:** Form-Level Error Handling

**Business Description:**
When any error occurs while the user is working with the RO Hold-Up screen - whether from a database constraint violation, a record-locking conflict, or a general system fault - the system intercepts it and provides a clear, user-readable message rather than allowing raw system codes to appear. For a parent-record protection violation, a specific business error is raised. For record-locking conflicts caused by another user editing the same data, the user is instructed to re-query the record. For specific known input errors, the full error context is displayed. For any remaining SQL error, the database error text is shown and the transaction is rolled back. Certain informational error codes are silently ignored.

**Actors:** Dealership User (system-triggered on any error within the form)

**Preconditions:**
- The RO Hold-Up form is open and any user action has triggered a database or Forms error.

**Main Flow:**

**Step 1 - Error intercepted and routed**
When any error fires within the form, the ON-ERROR trigger captures the Forms error code, error text, error type, database error code, and database error text, then routes processing through a series of conditional checks.

**Step 2 - Parent-record constraint violation handled**
If the database error code corresponds to a parent-record integrity violation (ORA-02292), the system raises a specific coded business error message using reference code "E0088". Processing stops; the user stays on the form.

*Procedures called:*
- **GENERAL.RAISE_ERROR** ([SP-010](#SP-010--GENERAL.RAISE_ERROR)) - GENERAL.RAISE_ERROR - looks up and displays the business error message for the supplied error code.
    * **Step 1** - The supplied error code is used to retrieve the corresponding business-defined error message from the error message master.
    * **Step 2** - The retrieved message is displayed to the user and a trigger failure is raised so the user remains on the screen.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Database error is a parent-record constraint violation | ON-ERROR (Form) - `IF Derrnum = -02292` check | On any form error | Routes parent-record violations to a user-friendly business error | Error message for code "E0088" shown; user stays on screen. |

**Step 3 - Known input and system error codes handled**
If the Forms error code is one of the known application-specific error numbers (40209, 40207, 50026, 50004), the system displays the formatted error text (error type + code + description) and raises a trigger failure. The user stays on the screen.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-009](#SP-009--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the supplied text as a message to the user.
    * **Step 1** - The supplied message text and severity label are presented to the user via the form's message display mechanism.
    * **Step 2** - Control returns to the calling code once the message is acknowledged.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Error code is a known input or system error | ON-ERROR (Form) - `IF errnum IN (40209, 40207, 50026, 50004)` check | On any form error | Routes known input-type errors to a formatted display | Full error context (type, code, text) shown; trigger failure raised; user stays on screen. |

**Step 4 - Record-locking conflict handled**
If the error code indicates a record-locking conflict caused by another user updating the same data (error codes 40654, 40655, 40656, 40657, 40659), the system displays a specific message instructing the user to re-query, rolls back the transaction, and raises a trigger failure.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-009](#SP-009--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the record-locking message to the user.
    * **Step 1** - The supplied message text and severity label are presented to the user via the form's message display mechanism.
    * **Step 2** - Control returns to the calling code once the message is acknowledged.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Error is a record-locking conflict | ON-ERROR (Form) - `IF ERROR_CODE IN (40654,40655,40656,40657,40659)` check | On any form error | Informs the user that another user has modified the record | *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"* shown; transaction rolled back; user stays on screen. |

**Step 5 - Any remaining SQL error handled**
If none of the above branches matched and a non-zero SQL error code is present, the system displays the database engine's own error text, rolls back the transaction, and raises a trigger failure.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-009](#SP-009--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the database error text to the user.
    * **Step 1** - The supplied message text and severity label are presented to the user via the form's message display mechanism.
    * **Step 2** - Control returns to the calling code once the message is acknowledged.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Any remaining SQL error | ON-ERROR (Form) - `IF sqlcode <> 0` check | On any form error | Catches all remaining database errors and surfaces the database error text | Database error description (SQLERRM) shown; transaction rolled back; user stays on screen. |

**Step 6 - Specific navigation error codes silently ignored**
If the Forms error code is 40401 or 40405 (standard no-data or navigation codes), the system takes no action and no message is shown.

*Business outcomes (errors, warnings, success, and status):*
- **BR-007-ES-01** - Parent-record constraint violation - coded business error message (E0088) shown; user stays on screen.
- **BR-007-ES-02** - Known input/system error - formatted error text (type, code, description) shown; user stays on screen.
- **BR-007-ES-03** - Record-locking conflict - *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"* shown; transaction rolled back; user stays on screen.
- **BR-007-ES-04** - General SQL error - database error description (SQLERRM) shown; transaction rolled back; user stays on screen.
- **BR-007-IC-01** - Error codes 40401 and 40405 - silently ignored; no message shown; no rollback.

**Alternative Flows:**
- **BR-007-AF-01** - (from Step 6) Error code is 40401 or 40405: no message is displayed; trigger completes silently with no action.

> **ON-MESSAGE trigger (COMMENTED OUT / INACTIVE - does not execute):** A form-level ON-MESSAGE trigger exists in the form XML but its entire body has been commented out and replaced with `null;` (commented at the prototype stage). No message-handling logic from this trigger executes.

> **KEY-COMMIT trigger (COMMENTED OUT / INACTIVE - does not execute):** A form-level KEY-COMMIT trigger exists but its entire body has been commented out and replaced with `null;`. No save-on-commit logic from this trigger executes.

---

---

#### Requirement ID: BR-008

**Requirement Title:** Form Exit and Session Context Cleanup

**Business Description:**
When the user exits the RO Hold-Up screen - by pressing the keyboard Exit shortcut or by clicking any of the available Exit buttons - the form closes immediately, discarding any unsaved changes without prompting. When the keyboard shortcut is used, the system additionally clears the application-tracking context registered at form open from the database session. The NB_EXIT navigation button also sets an exit flag in the session context before closing, signalling to the calling environment that the user explicitly chose to exit.

**Actors:** Dealership User

**Preconditions:**
- The RO Hold-Up form is open.

**Main Flow:**

**Step 1 - User initiates exit**
The user presses the keyboard Exit key (KEY-EXIT) or clicks one of the Exit buttons. The form closes immediately without saving unsaved data and without prompting.

**Step 2 - Session tracking context cleared (keyboard Exit only)**
When the keyboard Exit shortcut is used, the system clears the client-info identifier and clears the module name and action name from the application-information context registered at form open, then exits the form without validating unsaved changes.

**Step 3 - Exit flag set before close (NB_EXIT button only)**
When the NB_EXIT navigation-bar button is clicked, the system sets the global session exit flag to "EXIT" before calling the standard Exit key action, signalling to the calling environment that the user explicitly chose to exit.

**Alternative Flows:**
- **BR-008-AF-01** - (from Step 1) The toolbar Exit button (PB_EXIT) is pressed while the form is in Enter-Query mode: the system calls the standard Exit action regardless, discarding the query mode and closing the form.

---

---

#### Requirement ID: BR-009

**Requirement Title:** Clear Form Without Saving

**Business Description:**
The user can clear all data from the RO Hold-Up screen at any time - both the search criteria fields and the results grid - by pressing the keyboard Clear Form shortcut, by clicking the Clear button in the navigation bar, or by clicking the Cancel toolbar button. All entered filter values and displayed results are discarded instantly without saving and without any confirmation prompt. When the Cancel toolbar button is used, the screen also re-initialises itself to the default ready-to-search state (equivalent to re-opening the form). Additionally, the Tab key on the results block navigates back to clear the results and return focus to the As On Date filter, allowing the user to start a new search quickly. This enables the user to restart a fresh search without having to close and reopen the form.

**Actors:** Dealership User

**Preconditions:**
- The RO Hold-Up form is open.

**Main Flow:**

**Step 1 - User triggers clear form**
The user presses the keyboard Clear Form shortcut (KEY-CLRFRM), clicks the Clear navigation button (NB_CLEAR), or clicks the Cancel toolbar button (PB_CANCEL). All data across the search criteria and results blocks is cleared immediately without saving and without any prompt.

**Step 2 - Screen re-initialised after Cancel button clear (Cancel toolbar button only)**
When the user clicks the Cancel toolbar button and that button is currently enabled, the form clears all data and then re-runs the form-initialisation sequence. This restores all screen defaults - the view-type dropdown is re-populated, the As On Date is reset to yesterday, the results grid is reconfigured for the default view, and the cursor is returned to the first search field - exactly as if the user had just opened the form. If the Cancel button is disabled at the time of the click, no action is taken.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

**Alternative Flows:**
- **BR-009-AF-01** - (from Step 1) The user presses the Tab key while focus is on the results block: the results block is cleared and focus is moved back to the As On Date filter field, allowing the user to enter new search criteria without running a full form clear.
- **BR-009-AF-02** - (from Step 2) The Cancel toolbar button is disabled at the time of the click: no action is taken; the form state is unchanged.

> **Inactive toolbar buttons (do not execute):**
> - **Save button (PB_SAVE / FT_SAVE)** - The Save toolbar button calls a Save trigger (`FT_SAVE`) whose entire body is `null;`. No save action is performed when this button is pressed. This form is a read-only enquiry; saving is not supported. **(INACTIVE - does not execute.)**
> - **Insert button (PB_INSERT / FT_INSERT)** - The Insert toolbar trigger body is entirely commented out and replaced with `null;`. No insert action is performed. **(COMMENTED OUT / INACTIVE - does not execute.)**
> - **Delete button (PB_DEL / FT_DEL)** - The Delete toolbar trigger body is `null;`. No delete action is performed. **(INACTIVE - does not execute.)**
> - **Print button (PB_PRINT / FT_PRINT)** - The Print toolbar trigger body is `null;`. No print action is performed when this button is pressed. **(INACTIVE - does not execute.)**

---

> **Inactive and orphaned program units (do not execute):**
> - **VIEW_EXCEL_REP** - A form-level procedure implementing an earlier version of the CSV export logic. All calls to this routine in the form's triggers are commented out (replaced by `VIEW_EXCEL_REPORT_NEW`). It is not invoked by any active trigger. **(COMMENTED OUT / INACTIVE - does not execute).**
> - **CLEAR_ITEMS** - A form-level procedure stub with an empty body. It contains no logic and is not called from any active trigger. **(EMPTY STUB - does not execute).**
> - **ITEM_ENABLE** - A form-level procedure that duplicates the column-visibility and position-setting logic of the WHEN-LIST-CHANGED trigger. It is not called from any active trigger. **(ORPHANED - does not execute).**

---

## 5. Business Rules Catalogue

Catalogue of the discrete business rules enforced by the form's code.

| Rule ID | Rule Name | Rule Type | Business Requirement ID | Condition | Action | Business Impact |
| ------- | --------- | --------- | ----------------------- | --------- | ------ | --------------- |
| BRC-001 | As On Date is mandatory | Validation | BR-003 | As On Date is left blank when the user moves off the field | Show *"From Date can not be empty"* and block further entry | Prevents the search from running without a date filter |
| BRC-002 | As On Date must not be in the future | Validation | BR-003 | As On Date is after today's date | Show alert *"From Date cannot be greater than Current Date"* and block entry | Prevents querying future dates for which no hold-up data can exist |
| BRC-003 | As On Date must not exceed To Date | Validation | BR-003 | As On Date is later than the To Date | Show alert *"From Date cannot be greater than To Date"* and clear both date fields | Ensures the search date range is logically ordered |
| BRC-004 | To Date validated only for billing variance view | Constraint | BR-004 | To Date field is exited while a view type other than billing variance is active | Skip all To Date validation silently | Prevents inappropriate validation on views that do not use a date range |
| BRC-005 | To Date is mandatory for billing variance view | Validation | BR-004 | To Date is blank when the user moves off the field and the billing variance view is active | Show *"To Date can not be empty"* and block entry | Ensures both dates are provided before a billing range search can proceed |
| BRC-006 | From Date must be entered before To Date | Validation | BR-004 | To Date is entered while From Date is still blank | Show *"To date cannot be entered without entering From date"*, clear To Date, and block entry | Prevents a date range with a missing start boundary |
| BRC-007 | To Date must not be before From Date | Validation | BR-004 | To Date is earlier than From Date | Show alert *"To Date cannot be lesser than From Date"* and block entry | Ensures the billing date range is logically ordered |
| BRC-008 | To Date must not be after today | Validation | BR-004 | To Date is after today's date | Show alert *"To Date cannot be greater than Current Date"* and block entry | Prevents querying future billing data |
| BRC-009 | Billing date range must not exceed one calendar month | Constraint | BR-004 | To Date is more than one calendar month after From Date | Show alert *"Please give the date range of maximum One Month"* and block entry | Protects system performance by limiting the billing range query scope |
| BRC-010 | Search requires a recognised view type | Constraint | BR-005 | Search button is clicked but the selected view type is not one of the four supported values | No search is executed; results grid is not updated | Prevents the retrieval procedure from running with an invalid status value |
| BRC-011 | Billing variance results require minimum amount threshold | Constraint | BR-005 | Billing variance search executes | Only completed ROs where the combined part and labour amount exceeds 11,500 are included in the results | Ensures only financially significant variance cases are surfaced |
| BRC-012 | Billing variance restricted to active 2S/3S dealer locations | Constraint | BR-005 | Billing variance search executes | Only dealer locations of type 2S or 3S with no termination date are included | Ensures billing data is only queried for active, qualifying dealer types |
| BRC-013 | Approval-pending view filtered by odometer-change flag | Constraint | BR-005 | Approval-pending odometer search executes | Only hold-up records joined to an RO where the odometer-change flag is set to Pending, Approved, or Rejected are included | Ensures the approval view only shows ROs where an odometer-change decision is in progress or complete |
| BRC-014 | Parent-record constraint violation routed to business error | Validation | BR-007 | A database operation triggers ORA-02292 (child records exist) | Display the business error message for code "E0088" and stop processing | Surfaces a meaningful business message instead of a raw database constraint code |
| BRC-015 | Record-locking conflict requires re-query | Validation | BR-007 | A record-locking conflict error (codes 40654, 40655, 40656, 40657, or 40659) is raised | Show *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*, roll back, and stop processing | Prevents the user from saving stale data over another user's changes |
| BRC-016 | General SQL errors surfaced with rollback | Validation | BR-007 | Any SQL error with a non-zero error code that does not match a more specific handler | Show the database error text (SQLERRM) and roll back the transaction | Prevents silent data corruption by always rolling back and informing the user of unexpected errors |
| BRC-017 | Export requires a recognised view type | Constraint | BR-006 | Export to Excel button is clicked but the selected view type is not one of the four supported values | No export is executed; no message is shown | Prevents the export query from being built with an invalid status value |
| BRC-018 | To Date auto-calculated after As On Date validation | Derivation | BR-003 | As On Date passes all validation checks | Set To Date to the last day of the calendar month following the As On Date, capped at yesterday if that month-end is in the future | Bounds the default search window to one calendar month from the selected As On Date |

**Total Business Rules Identified: 18**

---

## 6. Data Requirements

*This section covers the business entities referenced by the RO Hold-Up enquiry form, the data captured on screen, the reference data used for lookups, and the lifecycle of records accessed through the form.*

### 6.1 Business Entities and Relationships

*The form operates primarily against the RO hold-up records table, with supporting joins to the main repair-order header and the dealer location master for different view types.*

#### RO Hold-Up Records - MULDMS.VH_RO_HOLD_UP

The RO hold-up records entity stores a snapshot of each repair order that was flagged as overdue or held up on a given date. Each record captures the dealership location, vehicle identifier, job card number, hold-up date, reason for hold, repair-order status, service category, promised delivery date, and odometer reading at the time of the hold. The form uses this entity as its primary data source for all view types except the billing variant (which extends it with billing amounts from the RO header).

#### Repair Order Header - MULDMS.VH_RO

The repair order header stores the full lifecycle of a repair order including billing details (part amount, labour amount, bill date) and the odometer-change approval status. The form joins this entity to the hold-up records entity for the billing variance view and the approval-pending odometer view, using the shared repair-order key fields to enrich the displayed results.

#### Dealer Location Master - MULDMS.AM_DEALER_LOC

The dealer location master stores the details of each dealership workshop location including its dealer type, parent group, location code, and termination date. The form joins this entity to the repair order header for the billing variance view to restrict results to active 2S/3S dealer locations.

#### Entity Relationships

The RO hold-up records entity is the central node. For the billing variance and approval-pending views the form joins it to the repair order header using shared keys (parent group, dealer map code, location code, FA composite key, job card number, and VIN). The dealer location master is joined to the repair order header for the billing variance query to filter by dealer type and active status.

```
MULDMS.VH_RO_HOLD_UP (RO Hold-Up Records)
        ├── MULDMS.VH_RO (Repair Order Header)      <- joined on parent_group, dealer_map_cd, loc_cd, comp_fa, ro_num, vin
        │       └── MULDMS.AM_DEALER_LOC (Dealer Location Master)  <- joined on dealer_map_cd, loc_cd (billing variance view only)
```

### 6.2 Data Capture Requirements

*The form is an enquiry-only screen. All data displayed in the results grid is read from the database; the only data the user enters is the search filter criteria. No records are inserted or updated through this form.*

#### Search Filter Criteria - User-entered before executing a search

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Status (`STATUS`) | Yes | The hold-up view type selected by the user from the drop-down list. Controls which dataset and screen layout are used. | Must be one of the four supported view type values; constrained by the list. |
| Location (`CB_LOC_DESC`) | Yes | The dealership workshop location the user selects via the location look-up. Filtered to the user's authorised locations for the current principal. | Selected from the location LOV; only active service locations assigned to the logged-in user are available. |
| Location Code (`CB_LOC_CD`) | Auto-Populated | The internal location code corresponding to the selected location description. Populated automatically when the location is chosen. | System-populated from the LOV return value; not user-editable. |
| Dealer Map Code (`CB_DEALER_MAP_CD`) | Auto-Populated | The dealer mapping code corresponding to the selected location. Populated automatically when the location is chosen. | System-populated from the LOV return value; not user-editable. |
| As on Date / From Date (`FROM_DATE`) | Yes | The hold-up snapshot date (for non-billing-variance views) or the start of the billing date range (for the billing variance view). | Must not be blank; must not be after today; must not be after To Date. See BR-003. |
| To Date (`TO_DATE`) | Conditional | The end of the billing date range. Required only when the billing variance view is active; hidden and not required for other view types. | Must not be blank (when billing variance is active); must not precede From Date; must not be after today; date range must not exceed one calendar month. See BR-004. |

#### Session and Global Parameters - Non-database flags affecting behaviour

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Application ID (`P_APP_ID`) | Auto-Populated | The application identifier passed as a form parameter from the calling context. Used when invoking the Excel report utility. | System-supplied at form launch; not editable by the user. |
| Principal Code (`GLOBAL.PRINCIPAL`) | Auto-Populated | The current user's dealership group (principal) identifier, held as a session global. Used to filter all queries to the correct dealer group. | Session-established before form launch; not editable. |
| User ID (`GLOBAL.USERID`) | Auto-Populated | The logged-in user's identifier, used to construct the export file name and to filter the location LOV. | Session-established at login; not editable. |
| Exit Flag (`GLOBAL.EXIT_FLAG`) | Auto-Populated | A session flag set to "EXIT" when the user explicitly clicks the NB_EXIT button. Used by the calling environment to detect a deliberate exit. | Set to "EXIT" on explicit exit; otherwise not changed by this form. |

### 6.3 Reference Data

*Lists the master and configuration data referenced by this form (LOVs, record groups, master tables).*

| Reference Data | Business Purpose | Used When |
| :--- | :--- | :--- |
| Location LOV (`LOV_LOC` - `RG_LOC`) | Provides the list of workshop locations the logged-in user is authorised to view, filtered to service-type locations (2S/3S) for the current dealership principal with no termination date. Returns location description, location code, and dealer map code. | When the user opens the location look-up on the search criteria screen. |
| Vehicle model master (`GM_MOD`) | Provides the human-readable model description for a given model code and principal map code. Displayed alongside each hold-up record in the non-billing-variance views. | During the POPULATE_DETAILS search for service RO, B&P, and approval-pending views; also in the Export to Excel query for those views. |
| Delay / hold reason master - non-B&P (`VM_DREASON`, reason type "NBDR") | Provides the human-readable reason description for the hold reason code on service (non-Body & Paint) ROs, filtered by active flag and principal. | During the POPULATE_DETAILS search for the service RO and approval-pending views; also in the Export to Excel query for those views. |
| Delay / hold reason master - B&P (`VM_DREASON`, reason type "BDR") | Provides the human-readable reason description for the hold reason code on Body & Paint ROs, filtered by active flag and principal. | During the POPULATE_DETAILS search for the B&P view; also in the Export to Excel query for that view. |
| Variant / sub-model master (`VM_SVAR`) | Provides the human-readable variant description for a given variant code and principal. Used in the billing variance view in place of the model description. | During the POPULATE_DETAILS search and Export to Excel query for the billing variance view. |
| Service category list (`AM_LIST`, list name "RCATEG_CD") | Provides the service category description for each repair order in the non-B&P and approval-pending export queries, filtered by principal. | During the Export to Excel query for the service RO and approval-pending views. |
| Sub-service category master (`VM_SUB_SRV_CAL`) | Provides the sub-category description for ROs that carry a sub-repair-category code, filtered by principal. Used in the service type column of the export. | During the Export to Excel query for the service RO and approval-pending views when a sub-category code is present. |
| User dealer master (`AM_USER_DEALER_MASTER`) | Filters the location LOV to only those locations assigned to the logged-in user for the current principal and dealer type. | When the location LOV record group (RG_LOC) is populated. |

### 6.4 Data Lifecycle

*Describes how records are created, read, updated, and saved within this form's evidenced behaviour.*

**Creation**

- This form does not create any database records. All data is read-only from a persistence perspective.

**Updates**

- This form does not update any database records. The results block is temporarily enabled for programmatic load during the POPULATE_DETAILS call but is immediately reset to read-only after each search; no user-initiated updates are possible.

**Save and Commit**

- No save or commit operations are executed by this form. The KEY-COMMIT trigger exists but is entirely commented out (inactive). No data is persisted from this form.

**Retention and Audit**

- No audit stamps, create/modify timestamps, or retention policies are managed by this form. Session activity is registered with the database application-information context at form open (via DBMS_APPLICATION_INFO) and cleared at exit; this is database-session-level monitoring only, not a persistent audit trail.

---

### 6.5 Excel Output Columns

Excel download columns produced by this form, with when each Excel is produced (report / principal path), filters that limit which rows are included, and the database source for each value. Column sets vary by export path (for example app_id, principal, and enquiry-date mode); the rows below are evidenced layouts, not a guaranteed list for every combination. Blank Table/Database means the physical column was not proven in source.

| # | What the user selects on screen | Excel column name | When this Excel is produced | Table name | Database column | Logic |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | As on Date, USERID, CB Deal, CB LOC, CB Dealer MAP, Status | Job Card Number |  | VH_RO_HOLD_UP | RO_NUM | Job Card Number sourced from VH_RO_HOLD_UP.RO_NUM (alias UP) in the STATUS=800 CSV export query; commas stripped via REPLACE. |
| 2 | As on Date, USERID, CB Deal, CB LOC, CB Dealer MAP, Status | Registration Number |  | VH_RO_HOLD_UP | REG_NUM | Vehicle registration number sourced from VH_RO_HOLD_UP.REG_NUM (alias UP) in the STATUS=800 CSV export query; commas stripped via REPLACE. |
| 3 | As on Date, USERID, CB Deal, CB LOC, CB Dealer MAP, Status | JO Date |  | VH_RO_HOLD_UP | RO_DATE | Job order date sourced from VH_RO_HOLD_UP.RO_DATE (alias UP) in the STATUS=800 CSV export query; commas stripped via REPLACE. |
| 4 | As on Date, USERID, CB Deal, CB LOC, CB Dealer MAP, Status | Model |  | GM_MOD | MODEL_DESC | Shows the Model taken from the enquiry's related records. |
| 5 | As on Date, USERID, CB Deal, CB LOC, CB Dealer MAP, Status | Service Type |  | VM_SUB_SRV_CAL | SUB_RCATEG_DESC | Service type resolved by a CASE expression: when UP.SUB_RCATEG_CD is not null a scalar subquery returns VM_SUB_SRV_CAL.SUB_RCATEG_DESC (matched on SUB_RCATEG_CD, RCATEG_CD, PRINCIPAL_MAP_CD); otherwise falls back to AM_LIST.LIST_DESC where list_name = 'RCATEG_CD'. |
| 6 | As on Date, USERID, CB Deal, CB LOC, CB Dealer MAP, Status | Promised Date & time |  | VH_RO_HOLD_UP | PROMISED_DATE | Promised delivery date/time sourced from VH_RO_HOLD_UP.PROMISED_DATE (alias UP) in the STATUS=800 CSV export query; commas stripped via REPLACE. |
| 7 | As on Date, USERID, CB Deal, CB LOC, CB Dealer MAP, Status | CEO Approval Status |  | VH_RO | ODOMETER_CHANGE | Shows the CEO Approval Status taken from the enquiry's related records. |
| 8 | As on Date, USERID, CB Deal, CB LOC, CB Dealer MAP, Status | CEO Reason |  | VH_RO | ODOMETER_REASON | Shows the CEO Reason taken from the enquiry's related records. |
| 9 | As on Date, USERID, CB Deal, CB LOC, CB Dealer MAP, Status | CEO Remarks |  | VH_RO | CEO_REMARKS | Shows the CEO Remarks taken from the enquiry's related records. |
| 10 | USERID, Status | Reason for Hold |  | VM_DREASON | REASON_DESC | Shows the Reason for Hold taken from the enquiry's related records. |
| 11 | As on Date, USERID, CB Dealer MAP, CB LOC, CB Deal, Status | Cost of Part |  | VH_RO | PART_AMT | Shows the Cost of Part taken from the enquiry's related records. |
| 12 | As on Date, USERID, CB Dealer MAP, CB LOC, CB Deal, Status | Cost of Labour |  | VH_RO | LABOUR_AMT | Shows the Cost of Labour taken from the enquiry's related records. |

## 7. Glossary

*Definitions of terms, abbreviations, and acronyms used throughout this document.*

The following table defines key terms, acronyms, and abbreviations used throughout this Business Requirements Document.

| Term | Definition | Aliases | Related Terms |
| :--- | :--- | :--- | :--- |
| AM_DEALER_LOC | Dealer location master table - stores dealer location attributes including dealer type, location code, and termination date | - | AM_USER_DEALER_MASTER, Dealer, Location |
| AM_USER_DEALER_MASTER | User-dealer access mapping table - defines which dealer locations each system user is authorised to access | - | AM_DEALER_LOC, LOV, Location |
| B&P | Body and Paint - a repair category code (BANDP) identifying body repair and paint service orders | BANDP | RO, RCATEG_CD, Hold-Up |
| BDR | Billing Delay Reason - hold reason type code used for Body and Paint delayed jobs | - | Hold Reason, NBDR, VM_DREASON |
| CEO Odometer Approval | Approval workflow for repair orders where an odometer reading change has been flagged, requiring senior-level sign-off before the job can proceed | Status 800 | Odometer Change, VH_RO |
| CSV | Comma-Separated Values - file format used for Excel-compatible data exports generated by this form | Excel Export | Export to Excel, DMS_EXCEL_REPORT |
| DMS | Dealer Management System - the integrated software platform for dealership operations within which this form operates | - | vi_ro_hold_up, RO |
| DPL | Shared Oracle Forms program library (DPL.pld) providing common UI procedures used by this and other forms | DPL.pld | GENERAL, PLD, DISP_TEXT |
| GENERAL | Package name prefix for shared DPL library procedures (e.g. GENERAL.DISP_TEXT, GENERAL.RAISE_ERROR) | - | DPL, DISP_TEXT, RAISE_ERROR |
| GM_MOD | Vehicle model master table - stores model codes and descriptions used to resolve model display names | - | Model, VIN |
| Hold-Up | A repair order that has passed its promised delivery date without being closed; the primary subject of this form | RO Hold-Up | Promised Date, RO |
| LOV | List of Values - a popup selection list in Oracle Forms; in this form, LOV_LOC is used for location selection | Dropdown | RG_LOC, Location |
| MULDMS | Database schema owner prefix for core DMS tables (e.g. MULDMS.VH_RO, MULDMS.VH_RO_HOLD_UP) | - | VH_RO, VH_RO_HOLD_UP |
| NBDR | Non-Body-and-Paint Delay Reason - hold reason type code used for non-B&P delayed jobs | - | Hold Reason, BDR, VM_DREASON |
| Odometer Change | A flag on a repair order indicating the vehicle odometer reading has been modified, requiring CEO-level approval | - | CEO Odometer Approval, VH_RO |
| PLD | Oracle Forms program library (.pld) - a shared library of reusable PL/SQL routines attached to the form | Program Library | DPL, WEBUTIL |
| Principal | Multi-organisation identifier stored as a global session variable; used to filter all master data queries to the correct organisation | PRINCIPAL | Global Variable, Organisation |
| Promised Date | The date and time by which a repair order was committed to be completed; the key threshold for identifying hold-up jobs | Promised Delivery Date | Hold-Up, RO |
| RO | Repair Order - the primary document for tracking a vehicle service or repair job at a dealer service centre | Job Card | VH_RO, VH_RO_HOLD_UP, Hold-Up |
| RO_STATUS | Numeric status code on a repair order (e.g. 10 = open, 40 = billed) used to filter which ROs appear in each report type | - | RO, VH_RO_HOLD_UP |
| RCATEG_CD | Repair category code - classifies the type of repair; used to separate B&P (BANDP) from non-B&P jobs | - | B&P, RO |
| VH_RO | Repair order header table - stores billing amounts, odometer change approval data, and job card details | MULDMS.VH_RO | RO, VH_RO_HOLD_UP |
| VH_RO_HOLD_UP | RO hold-up register table - records repair orders placed on hold with hold date, reason, and status | MULDMS.VH_RO_HOLD_UP | RO, Hold-Up, VH_RO |
| VIN | Vehicle Identification Number - unique chassis identifier for the vehicle associated with a repair order | Chassis Number | RO, Vehicle |
| VM_DREASON | Delay/hold reason master table - stores reason descriptions for hold reason codes (BDR and NBDR types) | - | Hold Reason, BDR, NBDR |
| VM_SVAR | Service variant/sub-model master table - provides variant descriptions from service model codes | - | Model, GM_MOD |
| VM_SUB_SRV_CAL | Sub-service category lookup table - provides sub-repair category descriptions used in service type display | - | RCATEG_CD, B&P |
| WEBUTIL | Oracle Forms WebUtil library - provides client-side file and browser integration functions | webutil.pld | PLD, DPL |

---

---

## 8. Technical Inventory

*Complete inventory of Oracle Forms components including blocks, items, triggers, canvases, and global variables.*

### 8.1 Form Architecture

**Form Module Details:**

- Form Name: vi_ro_hold_up (VI_RO_HOLD_UP)
- Form Module XML Title: MODULE4
- Oracle Forms Version: 12c (Module version 122010400); Runtime compatibility: 5.0
- Parent Object Library: DPL.olb (PC_FORM property class)
- Attached Libraries: WEBUTIL (webutil.olb), DMS_EXCEL_REPORT, DPL (DPL.pld program library), D2KWUTIL
- First Navigation Block: -
- Console Window: WN_MAIN - CEO Control Point For Service Area  (Rel:- 1.1.3)
- Compile Dependencies: Requires DPL.olb, DPL.pld, WEBUTIL.olb, menu.mmx
- Source artifacts: `vi_ro_hold_up_fmb.xml`; OLB `DPL.olb`; WEBUTIL (webutil.olb); DMS_EXCEL_REPORT; DPL (DPL.pld program library); D2KWUTIL

### 8.1.1 Global Variables

| Global Variable | Data Type | Set Location | Purpose |
| :--- | :--- | :--- | :--- |
| APP_ID | Char | Trigger | Application identifier propagated at runtime; used to provide report and session context across form invocations |
| APP_LOG | Char | Trigger | Application logging flag or log-path token; used to conditionally enable diagnostic logging during form execution |
| COMP_FA | Char | Trigger | Company/FA code for the active dealership entity; used to scope queries and display to the correct legal entity |
| CURRENCY | Char | Trigger | Currency code for the active session; used to format or label monetary amounts displayed in the form |
| DEALER | Char | Trigger | Dealer identifier for the active session; used to filter dealer-specific data throughout the form |
| EXIT_FLAG | Char | Trigger | Signals form exit intent; set to `EXIT` when the NB_EXIT button is pressed |
| FIN_BEG | Char | Trigger | Financial year begin date for the active session; used to bound date-range queries to the current financial year |
| FIN_END | Char | Trigger | Financial year end date for the active session; used to bound date-range queries to the current financial year |
| LOC_CD | Char | Trigger | Location code for the active session; used to default and filter service-centre location across the form |
| PARENT_GROUP | Char | Trigger | Parent group code for the active dealer hierarchy; used to filter multi-dealer group data |
| PRINCIPAL | Char | ProgramUnit / RecordGroup / Trigger | Current principal (organisation) identifier used to filter multi-organisation data |
| P_FIN_YR | Char | Trigger | Current financial year label (e.g. `2024-25`); used in report headings and query predicates |
| REP_SERVER | Char | Trigger | Report server name or URL; used when invoking Oracle Reports from the form |
| TALLY_INTEGRATION | Char | Trigger | Flag indicating whether Tally accounting integration is active for the current session |
| USERID | Char | ProgramUnit / RecordGroup / Trigger | Logged-in user identifier used for LOV filtering and Excel export filename generation |
| USER_ID | Char | Trigger | Alternate user identifier token; used in session-context and audit trail calls |
| USER_NAME | Char | Trigger | Display name of the logged-in user; used in report headers and session-context registration |

### 8.1.2 Form Parameters

*All 1 ModuleParameter entries from vi_ro_hold_up_fmb.xml.*

| Parameter | Data Type | Default | Description |
| :--- | :--- | :--- | :--- |
| P_APP_ID | Char | - | Application identifier passed at form startup; forwarded to the Excel export utility for report context |

**Total Parameters:** 1

### 8.2 Blocks

| Block Name | Query Data Source | Records | Q/I/U/D | Key Mode | Master-Detail Relationship |
| :--- | :--- | :--- | :--- | :--- | :--- |
| CB_DUMMY | - | 1 | N/N/N/N | Default | Control - search criteria entry block for status, location, and date filter |
| VH_RO_HOLD_UP | - | 15 | N/N/N/N | Default | Detail of CB_DUMMY via CB_DUMMY.CB_DEALER_MAP_CD / CB_DUMMY.CB_LOC_CD |
| PB_BLK | - | 1 | N/N/N/N | Default | Control - toolbar button block for form navigation actions (inherited) |

**Total Blocks:** 3 business blocks

### 8.2.1 Block WhereClause and OrderByClause

*Block query scope from vi_ro_hold_up_fmb.xml. **Description** explains filter and sort in business terms; **Order By** and **Where Clause** columns retain verbatim XML text for migration.*

| Block | Description | Order By (XML) | Where Clause (XML) |
| :--- | :--- | :--- | :--- |
| - | No blocks with WhereClause/OrderByClause in vi_ro_hold_up_fmb.xml | - | - |

### 8.3 Items Summary

*Complete item inventory from `vi_ro_hold_up_fmb.xml`.*

**Block counts:**

*Database / non-database counts derived from XML.*

| Block | Total Items | Database Items | Non-Database Items |
| :--- | ---: | ---: | ---: |
| CB_DUMMY | 12 | 0 | 12 |
| VH_RO_HOLD_UP | 26 | 0 | 26 |
| PB_BLK | 15 | 0 | 15 |
| CB_ERR | 1 | 0 | 1 |
| WEBUTIL | 9 | 0 | 9 |
| **Total** | **63** | **0** | **63** |

**Item detail (all 63 items):**

| Block | Item Name | DatabaseItem | Description |
| :--- | :--- | :--- | :--- |
| CB_DUMMY | CB_PARENT_GROUP | false | Internal parent group code for dealer hierarchy filtering |
| CB_DUMMY | CB_DEALER_MAP_CD | false | Dealer map code used to identify the selected dealer location |
| CB_DUMMY | STATUS | false | Search status selector - drives which report view is displayed (400/500/600/800) |
| CB_DUMMY | CB_LOC_DESC | false | Location description shown to the user; triggers LOV_LOC for selection |
| CB_DUMMY | FROM_DATE | false | Start date for the search filter; validated against current date and TO_DATE |
| CB_DUMMY | TO_DATE | false | End date for the search filter; enabled only for status 600 (Billing Ageing) |
| CB_DUMMY | CB_MODEL | false | **INACTIVE** - Model filter field; hidden on canvas (Visible = false) |
| CB_DUMMY | CB_VARIANT_DESC | false | **INACTIVE** - Variant description display; hidden on canvas (no CanvasName set) |
| CB_DUMMY | PB_SEARCH | false | Search button - triggers POPULATE_DETAILS to load matching records |
| CB_DUMMY | PB_EXCEL | false | Export to Excel button - generates a CSV report for the active status view |
| CB_DUMMY | CB_LOC_CD | false | Location code returned from LOV; used as a query filter parameter |
| CB_DUMMY | TXT | false | Hidden text field storing the current SQL query string for Excel export |
| VH_RO_HOLD_UP | PART_AMT | false | Parts cost amount for the repair order (shown in Billing Ageing status 600) |
| VH_RO_HOLD_UP | LABOUR_AMT | false | Labour cost amount for the repair order (shown in Billing Ageing status 600) |
| VH_RO_HOLD_UP | BILL_AMT | false | Total bill amount (parts + labour) for the repair order |
| VH_RO_HOLD_UP | SVAR_CD | false | Sub-variant/service model code used to look up variant description |
| VH_RO_HOLD_UP | SRL_NUM | false | Serial number - row sequence counter in the result set |
| VH_RO_HOLD_UP | PARENT_GROUP | false | Dealer parent group identifier for the repair order record |
| VH_RO_HOLD_UP | DEALER_MAP_CD | false | Dealer map code identifying the dealership for this record |
| VH_RO_HOLD_UP | LOC_CD | false | Location code of the service centre for this record |
| VH_RO_HOLD_UP | HOLD_UP_DATE | false | Date the repair order was placed on hold |
| VH_RO_HOLD_UP | VIN | false | Vehicle Identification Number |
| VH_RO_HOLD_UP | RO_STATUS | false | Repair order status code (e.g. 10 = open, 40 = billed) |
| VH_RO_HOLD_UP | RCATEG_CD | false | Repair category code (e.g. BANDP = Body and Paint) |
| VH_RO_HOLD_UP | ODOMETER_READING | false | Vehicle odometer reading at the time of the repair order |
| VH_RO_HOLD_UP | CREATED_DATE | false | Date the repair order record was created |
| VH_RO_HOLD_UP | COMP_FA | false | Company/FA code for the dealership entity |
| VH_RO_HOLD_UP | RO_NUM | false | Job card number identifying the repair order |
| VH_RO_HOLD_UP | REG_NUM | false | Vehicle registration number |
| VH_RO_HOLD_UP | RO_DATE | false | Job card (repair order) creation date |
| VH_RO_HOLD_UP | MODEL_CODE | false | Vehicle model code; hidden, used for model description lookup |
| VH_RO_HOLD_UP | PROMISED_DATE | false | Promised delivery/completion date and time for the repair |
| VH_RO_HOLD_UP | HOLD_REASON | false | Hold reason code; hidden, used for reason description lookup |
| VH_RO_HOLD_UP | MODEL_DESC | false | Vehicle model description resolved from the model code |
| VH_RO_HOLD_UP | REASON_DESC | false | Human-readable reason for hold resolved from the hold reason code |
| VH_RO_HOLD_UP | CEO_APPROVE_STATUS | false | CEO approval status label (Approval Pending / Approved / Rejected) for odometer change |
| VH_RO_HOLD_UP | ODOMETER_REASON | false | Reason provided for the odometer change requiring CEO approval |
| VH_RO_HOLD_UP | CEO_REMARKS | false | CEO remarks entered against the odometer change approval request |
| PB_BLK | PB_EXIT | false | Exit button - closes the form with save prompt (inherited) |
| PB_BLK | PB_LIST | false | List button - executes FT_LIST trigger (disabled in this form) (inherited) |
| PB_BLK | PB_INSERT | false | Insert button - executes FT_INSERT trigger (disabled in this form) (inherited) |
| PB_BLK | PM_CONT | false | **INACTIVE** - Continuation button placeholder; disabled with no trigger body (inherited) |
| PB_BLK | PB_DEL | false | Delete button - executes FT_DEL trigger (disabled in this form) (inherited) |
| PB_BLK | PB_CANCEL | false | Cancel button - executes FT_CANCEL trigger to discard changes (inherited) |
| PB_BLK | PB_SAVE | false | Save button - executes FT_SAVE trigger (disabled in this form) (inherited) |
| PB_BLK | PB_PRINT | false | Print button - executes FT_PRINT trigger (disabled in this form) (inherited) |
| PB_BLK | PB_CUT | false | Cut button - cuts selected text region to clipboard (inherited) |
| PB_BLK | PB_COPY | false | Copy button - copies selected text region to clipboard (inherited) |
| PB_BLK | PB_PASTE | false | Paste button - pastes clipboard content into current field (inherited) |
| PB_BLK | PB_ERR_EXIT | false | Error exit button - exits the form on error; inherited from DPL object library (inherited) |
| PB_BLK | NB_EXIT | false | Navigation Exit button - sets EXIT_FLAG global and exits the form (inherited) |
| PB_BLK | NB_CLEAR | false | Clear button - clears the result block and the search criteria block (inherited) |
| PB_BLK | NB_OK | false | OK button - exits the form without validation (inherited) |
| CB_ERR | TXT_ERR | false | Error message text item on the inherited error canvas (CN_ERR); displays runtime error text routed through the DPL error-handling object group (inherited) |
| WEBUTIL | DUMMY | false | Dummy button item in the WEBUTIL block; required by the WEBUTIL object group infrastructure to anchor the WHEN-BUTTON-PRESSED bean event handler (inherited) |
| WEBUTIL | WEBUTIL_CLIENTINFO_FUNCTIONS | false | Bean-area item hosting the WEBUTIL client-information API; provides access to client machine properties at runtime (inherited) |
| WEBUTIL | WEBUTIL_FILE_FUNCTIONS | false | Bean-area item hosting the WEBUTIL file-transfer API; enables client-side file read/write operations (inherited) |
| WEBUTIL | WEBUTIL_HOST_FUNCTIONS | false | Bean-area item hosting the WEBUTIL host-command API; allows execution of operating-system commands on the client (inherited) |
| WEBUTIL | WEBUTIL_SESSION_FUNCTIONS | false | Bean-area item hosting the WEBUTIL session API; exposes session-level client properties (inherited) |
| WEBUTIL | WEBUTIL_FILETRANSFER_FUNCTIONS | false | Bean-area item hosting the WEBUTIL file-transfer functions; used to move files between client and server (inherited) |
| WEBUTIL | WEBUTIL_OLE_FUNCTIONS | false | Bean-area item hosting the WEBUTIL OLE automation API; supports OLE/COM interactions on the client (inherited) |
| WEBUTIL | WEBUTIL_C_API_FUNCTIONS | false | Bean-area item hosting the WEBUTIL C-API bridge; enables calls to native client-side C libraries (inherited) |
| WEBUTIL | WEBUTIL_BROWSER_FUNCTIONS | false | Bean-area item hosting the WEBUTIL browser API; provides browser navigation and URL-launch capabilities (inherited) |

### 8.4 List of Values

| LOV Name | Title | Record Group | Attached Block.Item |
| :--- | :--- | :--- | :--- |
| LOV_LOC | - | RG_LOC | CB_DUMMY.CB_LOC_DESC |

**Total LOVs:** 1

### 8.5 Alerts

| Alert Name | Title | Message Text | Calling Context |
| :--- | :--- | :--- | :--- |
| WEBUTIL_ERROR | Forms | (set at runtime) | Inherited from WEBUTIL object library - called by WebUtil client-side error handling |
| AL_ERRINFO | Error | (set at runtime) | Inherited from DPL object group - displayed by RAISE_ERROR and DISP_TEXT when an error-level message must be acknowledged by the user |
| AL_NOTE | Note | (set at runtime) | Inherited from DPL object group - displayed for informational messages that require user acknowledgement |
| AL_CONFIRM | Caution | (set at runtime) | Inherited from DPL object group - displayed to request user confirmation before a destructive or irreversible action |
| AL_PRINT | Print | (set at runtime) | Inherited from DPL object group - displayed to confirm or configure a print action |

**Total Alerts:** 5

### 8.6 Program Units

*Authoritative catalogue of **4 form-local program units**. Database packages and standalone procedures are in **Section 15.2**; PLD shared-library routines are in **Section 18**.*

| Program Unit | Type | Calls | Description |
| :--- | :--- | :--- | :--- |
| POPULATE_DETAILS | Procedure | MULDMS.VH_RO_HOLD_UP, MULDMS.VH_RO, GM_MOD, VM_DREASON, VM_SVAR, GENERAL.DISP_TEXT | Populates the VH_RO_HOLD_UP block by querying the hold-up table based on the selected status, location, and date; handles four status views (400, 500, 600, 800) with separate cursors |
| VIEW_EXCEL_REP | Procedure | TEXT_IO, WEB.SHOW_DOCUMENT, FIND_GROUP, CREATE_GROUP_FROM_QUERY, POPULATE_GROUP | **COMMENTED OUT / INACTIVE** - Legacy procedure to generate and display a CSV report via server file path; superseded by VIEW_EXCEL_REPORT_NEW from DMS_EXCEL_REPORT library |
| CLEAR_ITEMS | Procedure | (none - empty stub body) | **COMMENTED OUT / INACTIVE** - Empty stub procedure with no implementation body |
| ITEM_ENABLE | Procedure | SET_ITEM_PROPERTY | Sets item visibility and position for the VH_RO_HOLD_UP block fields based on the selected status (400/500/600/800) |

**Total Program Units:** 4

### 8.7 Triggers

**Item-Level Trigger Types (reference):**

| Trigger Name | Purpose |
| :--- | :--- |
| WHEN-VALIDATE-ITEM | Validates field when user leaves item |
| KEY-* | Keyboard actions - commit, exit, LOV, navigation |
| WHEN-NEW-BLOCK-INSTANCE | Initializes block on entry |
| WHEN-BUTTON-PRESSED | Executes button action |
| PRE-INSERT / POST-INSERT | Before/after record creation |
| WHEN-LIST-CHANGED | Dropdown selection changed |
| PRE-QUERY / POST-QUERY | Before/after query execution |
| WHEN-CHECKBOX-CHANGED | Checkbox toggled |
| WHEN-VALIDATE-RECORD | Validates entire record before leaving row |

**DPL library routines invoked from triggers and program units:**

| Routine | Type | Called From | Purpose |
| :--- | :--- | :--- | :--- |
| GENERAL.DISP_TEXT | Library routine | CB_DUMMY.FROM_DATE, CB_DUMMY.TO_DATE, Form level (ON-ERROR), ProgramUnit: POPULATE_DETAILS | Displays a titled message dialog to the user; used for error messages, validation failures, and population errors |
| GENERAL.L_POP_LIST_ITEM | Library routine | Form level | Populates a list item (drop-down) with values at runtime; used to initialise the STATUS list on form startup |
| GENERAL.RAISE_ERROR | Library routine | Form level (ON-ERROR) | Looks up a predefined error message by code from the error message table and displays it via DISP_TEXT; invoked when a database constraint violation (ORA-02292) is detected |

### 8.7.1 Inactive / Commented-Out Trigger Register

*Triggers and field validations where XML source is `null;`, fully block-commented, or legacy code preserved but not executed. Do **not** migrate these as active business requirements.*

| Status | Block | Item | Trigger | Former behaviour (preserved in comments) | Disabled since / note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Inactive stub** | Form | - | FT_SAVE | Committed the current record to the database | Disabled - save is not applicable for this read-only enquiry form; body is `null;` |
| **Inactive stub** | Form | - | FT_DEL | Deleted the current record from the database | Disabled - deletion is not applicable for this read-only enquiry form; body is `null;` |
| **Inactive stub** | Form | - | FT_PRINT | Invoked the print report routine for the current view | Disabled - print functionality not implemented in this form; body is `null;` |
| **Commented out** | Form | - | WHEN-NEW-FORM-INSTANCE | Initialised global variables and form state on startup | Superseded by PRE-FORM and DPL inherited WHEN-NEW-FORM-INSTANCE; body is fully block-commented |
| **Inactive stub** | Form | - | ON-MESSAGE | Suppressed standard Oracle Forms informational messages | Entire body replaced with `null;`; formerly filtered message codes to prevent unwanted dialogs |
| **Inactive stub** | Form | - | KEY-COMMIT | Validated fields and committed the form | Entire body replaced with `null;`; formerly called CHECK_FORM_FAILURE after commit |
| **WEBUTIL infrastructure** | WEBUTIL | WEBUTIL_BROWSER_FUNCTIONS | WHEN-CUSTOM-ITEM-EVENT | Bean-area event handler for browser API bean | Inherited from WEBUTIL object group; no form-specific logic |
| **WEBUTIL infrastructure** | WEBUTIL | WEBUTIL_C_API_FUNCTIONS | WHEN-CUSTOM-ITEM-EVENT | Bean-area event handler for C-API bridge bean | Inherited from WEBUTIL object group; no form-specific logic |
| **WEBUTIL infrastructure** | WEBUTIL | WEBUTIL_OLE_FUNCTIONS | WHEN-CUSTOM-ITEM-EVENT | Bean-area event handler for OLE automation bean | Inherited from WEBUTIL object group; no form-specific logic |
| **WEBUTIL infrastructure** | WEBUTIL | WEBUTIL_FILETRANSFER_FUNCTIONS | WHEN-CUSTOM-ITEM-EVENT | Bean-area event handler for file-transfer bean | Inherited from WEBUTIL object group; no form-specific logic |
| **WEBUTIL infrastructure** | WEBUTIL | WEBUTIL_SESSION_FUNCTIONS | WHEN-CUSTOM-ITEM-EVENT | Bean-area event handler for session API bean | Inherited from WEBUTIL object group; no form-specific logic |
| **WEBUTIL infrastructure** | WEBUTIL | WEBUTIL_HOST_FUNCTIONS | WHEN-CUSTOM-ITEM-EVENT | Bean-area event handler for host-command bean | Inherited from WEBUTIL object group; no form-specific logic |
| **WEBUTIL infrastructure** | WEBUTIL | WEBUTIL_FILE_FUNCTIONS | WHEN-CUSTOM-ITEM-EVENT | Bean-area event handler for file-functions bean | Inherited from WEBUTIL object group; no form-specific logic |
| **WEBUTIL infrastructure** | WEBUTIL | WEBUTIL_CLIENTINFO_FUNCTIONS | WHEN-CUSTOM-ITEM-EVENT | Bean-area event handler for client-information bean | Inherited from WEBUTIL object group; no form-specific logic |
| **WEBUTIL infrastructure** | WEBUTIL | DUMMY | WHEN-BUTTON-PRESSED | Dummy-item button handler required by WEBUTIL infrastructure | Inherited from WEBUTIL object group; no form-specific logic |

*Additional null-only or partially commented triggers exist on estimation and legacy blocks - see XML `TriggerText` starting with `null;` or `/*`.*

**Complete trigger inventory (40 triggers):**
*vi_ro_hold_up_fmb.xml contains 40 Trigger elements.*

| Trigger Name | Block | Item | Called From / Context | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| ON-ERROR | Form | - | Form level | Intercepts form and database errors; displays error messages via GENERAL.DISP_TEXT and raises GENERAL.RAISE_ERROR for referential integrity violations |
| ON-MESSAGE | Form | - | Form level | **INACTIVE** - Legacy message handler; body is `null;`; formerly suppressed standard Forms messages |
| KEY-EXIT | Form | - | Form level | Clears DBMS application info and exits the form without validation |
| KEY-LISTVAL | Form | - | Form level | Displays the LOV associated with the current field and navigates to the next item on successful selection |
| KEY-COMMIT | Form | - | Form level | **INACTIVE** - Legacy commit handler; body is `null;`; formerly validated fields and committed the form |
| KEY-CLRFRM | Form | - | Form level | Clears the entire form without validation |
| KEY-OTHERS | Form | - | Form level | Inherited catch-all key handler from DPL object group; suppresses unhandled key events (inherited) |
| KEY-NEXT-ITEM | Form | - | Form level | Inherited next-item navigation handler from DPL object group; moves focus to the next navigable item (inherited) |
| KEY-PREV-ITEM | Form | - | Form level | Inherited previous-item navigation handler from DPL object group; moves focus to the previous navigable item (inherited) |
| KEY-NXTBLK | Form | - | Form level | Inherited next-block navigation handler from DPL object group; moves focus to the next block (inherited) |
| KEY-PRVBLK | Form | - | Form level | Inherited previous-block navigation handler from DPL object group; moves focus to the previous block (inherited) |
| KEY-DOWN | Form | - | Form level | Inherited down-arrow navigation handler from DPL object group; moves focus to the next record (inherited) |
| KEY-UP | Form | - | Form level | Inherited up-arrow navigation handler from DPL object group; moves focus to the previous record (inherited) |
| FT_SAVE | Form | - | Form level | **INACTIVE** - Inherited save trigger from DPL object group; body is `null;` for this read-only enquiry form (inherited) |
| FT_CANCEL | Form | - | Form level | Inherited cancel trigger from DPL object group; discards unsaved changes and clears the current block (inherited) |
| FT_INSERT | Form | - | Form level | Inherited insert trigger from DPL object group; disabled - insert is not applicable for this read-only enquiry form (inherited) |
| FT_DEL | Form | - | Form level | **INACTIVE** - Inherited delete trigger from DPL object group; body is `null;` for this read-only enquiry form (inherited) |
| FT_LIST | Form | - | Form level | Inherited list trigger from DPL object group; disabled - list action is not used in this form (inherited) |
| FT_PRINT | Form | - | Form level | **INACTIVE** - Inherited print trigger from DPL object group; body is `null;` for this form (inherited) |
| WHEN-NEW-FORM-INSTANCE | Form | - | Form level | **INACTIVE (form-local body commented out)** - Inherited from DPL object group; DPL version initialises global variables and form state; form-local override body is fully block-commented (inherited) |
| PRE-FORM | Form | - | Form level | Sets DBMS application context to `vi_ro_hold_up` for session tracking at form startup |
| WHEN-LIST-CHANGED | CB_DUMMY | STATUS | CB_DUMMY.STATUS | Reconfigures visible columns and layout of the VH_RO_HOLD_UP block based on the selected status (400/500/600/800); navigates to the location field and clears the block |
| KEY-NEXT-ITEM | CB_DUMMY | CB_LOC_DESC | CB_DUMMY.CB_LOC_DESC | Navigates to the VH_RO_HOLD_UP block, clears it, then moves focus to the FROM_DATE field |
| WHEN-VALIDATE-ITEM | CB_DUMMY | FROM_DATE | CB_DUMMY.FROM_DATE | Validates FROM_DATE is not null, not in the future, and not greater than TO_DATE; auto-calculates TO_DATE as the end of the month from FROM_DATE |
| WHEN-VALIDATE-ITEM | CB_DUMMY | TO_DATE | CB_DUMMY.TO_DATE | For status 600 only: validates TO_DATE is not null, not less than FROM_DATE, not in the future, and the date range does not exceed one month |
| WHEN-BUTTON-PRESSED | CB_DUMMY | PB_SEARCH | CB_DUMMY.PB_SEARCH | Calls POPULATE_DETAILS when a valid status (400/500/600/800) is selected |
| WHEN-BUTTON-PRESSED | CB_DUMMY | PB_EXCEL | CB_DUMMY.PB_EXCEL | Builds a status-specific SQL query and calls VIEW_EXCEL_REPORT_NEW to export the result set as a CSV file |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EXIT | PB_BLK.PB_EXIT | Exits the form; handles both ENTER-QUERY mode and normal mode with save-status check |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_LIST | PB_BLK.PB_LIST | Executes the FT_LIST trigger (disabled - button Enabled = false) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_INSERT | PB_BLK.PB_INSERT | Executes the FT_INSERT trigger (disabled - button Enabled = false) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_DEL | PB_BLK.PB_DEL | Executes the FT_DEL trigger (disabled - button Enabled = false) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CANCEL | PB_BLK.PB_CANCEL | Executes the FT_CANCEL trigger to discard unsaved changes |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SAVE | PB_BLK.PB_SAVE | Executes the FT_SAVE trigger (disabled - button Enabled = false) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PRINT | PB_BLK.PB_PRINT | Executes the FT_PRINT trigger (disabled - button Enabled = false) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CUT | PB_BLK.PB_CUT | Cuts the selected text region to the clipboard |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_COPY | PB_BLK.PB_COPY | Copies the selected text region to the clipboard |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PASTE | PB_BLK.PB_PASTE | Pastes clipboard content into the current field |
| WHEN-BUTTON-PRESSED | PB_BLK | NB_EXIT | PB_BLK.NB_EXIT | Sets :GLOBAL.EXIT_FLAG to `EXIT` and exits the form without validation |
| WHEN-BUTTON-PRESSED | PB_BLK | NB_CLEAR | PB_BLK.NB_CLEAR | Clears the VH_RO_HOLD_UP block and the CB_DUMMY block without validation |
| WHEN-BUTTON-PRESSED | PB_BLK | NB_OK | PB_BLK.NB_OK | Exits the form immediately without validation |

### 8.8 Canvas and Window Inventory

**Windows:**

| Window | Title | Primary Canvas |
| :--- | :--- | :--- |
| WIN_ERR | - | CN_ERR |
| WN_MAIN | CEO Control Point For Service Area  (Rel:- 1.1.3) | CN_MAIN |

**Canvases:**

| Canvas | Type | Window |
| :--- | :--- | :--- |
| CN_ERR | Content | WIN_ERR (inherited) |
| CN_TOOL | Vertical Toolbar | WN_MAIN (inherited) |
| CN_MAIN | Content | WN_MAIN |

---

### 8.9 Editors

*No editors found in vi_ro_hold_up_fmb.xml.*

### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

#### 8.10.1 Visual Attributes (form-defined)

*0 VisualAttribute elements defined at form level (not inherited from DPL.olb).*

*No form-local visual attributes found in vi_ro_hold_up_fmb.xml.*

#### 8.10.2 Property Classes (form-defined)

*Form-local PropertyClass elements.*

*No form-local property classes found in vi_ro_hold_up_fmb.xml.*

#### 8.10.3 Object Groups

*Object groups bundle inherited triggers and visual objects applied form-wide at runtime.*

| Object Group Child | Type |
| :--- | :--- |
| KEY-OTHERS | Inherited trigger |
| KEY-NEXT-ITEM | Inherited trigger |
| KEY-PREV-ITEM | Inherited trigger |
| KEY-NXTBLK | Inherited trigger |
| KEY-PRVBLK | Inherited trigger |
| KEY-DOWN | Inherited trigger |
| KEY-UP | Inherited trigger |
| CN_ERR | Inherited canvas |
| VA_DISP | Inherited visualattribute |
| CB_ERR | Inherited block |
| VA_LOV | Inherited visualattribute |
| VA_TRNI_DT | Inherited visualattribute |
| VA_TITLE | Inherited visualattribute |
| VA_ALERT | Inherited visualattribute |
| VA_BUTN | Inherited visualattribute |
| VA_TEXT | Inherited visualattribute |
| VA_MPROMPT | Inherited visualattribute |
| VA_OPROMPT | Inherited visualattribute |
| VA_MAND | Inherited visualattribute |
| VA_NUM | Inherited visualattribute |
| VA_DESC | Inherited visualattribute |
| VA_ICONIC_BUTN | Inherited visualattribute |
| VA_RB | Inherited visualattribute |
| VA_CB | Inherited visualattribute |
| WN_MAIN | Inherited window |
| POP_MAIN | Inherited trigger |
| CN_MAIN | Inherited canvas |
| CN_TOOL | Inherited canvas |
| PB_BLK | Inherited block |
| AL_ERRINFO | Inherited alert |
| AL_NOTE | Inherited alert |
| AL_CONFIRM | Inherited alert |
| WIN_ERR | Inherited window |
| AL_PRINT | Inherited alert |
| FT_SAVE | Inherited trigger |
| FT_CANCEL | Inherited trigger |
| FT_INSERT | Inherited trigger |
| FT_DEL | Inherited trigger |
| FT_LIST | Inherited trigger |
| FT_PRINT | Inherited trigger |
| WHEN-NEW-FORM-INSTANCE | Inherited trigger |

### 8.11 DataSourceColumn Inventory

*16 DataSourceColumn elements across 1 blocks - formal query column-to-block mapping from vi_ro_hold_up_fmb.xml.*

#### VH_RO_HOLD_UP (16 columns)

| Column (DSCName) | Data Type |
| :--- | :--- |
| PARENT_GROUP | VARCHAR2 |
| DEALER_MAP_CD | NUMBER |
| LOC_CD | VARCHAR2 |
| HOLD_UP_DATE | DATE |
| VIN | VARCHAR2 |
| RO_NUM | VARCHAR2 |
| HOLD_REASON | VARCHAR2 |
| RO_STATUS | NUMBER |
| RCATEG_CD | VARCHAR2 |
| REG_NUM | VARCHAR2 |
| RO_DATE | DATE |
| PROMISED_DATE | DATE |
| ODOMETER_READING | NUMBER |
| MODEL_CODE | VARCHAR2 |
| CREATED_DATE | DATE |
| COMP_FA | VARCHAR2 |

**Total DataSourceColumns:** 16 across 1 blocks

## 9. Object Library

*This section catalogues the objects available from the Object Libraries referenced by the form. The form references two Object Library files: DPL_olb.xml (the DPL library, containing visual attributes and property classes used as design standards across dealership forms) and webutil_olb.xml (the WebUtil library, containing object groups for WebUtil client-side integration).*

Source OLB file(s): DPL_olb.xml, webutil_olb.xml

| Name | Type | Description | Used By (count) | Sample Items |
| ---- | ---- | ----------- | --------------- | ------------ |
| VA_CB | VisualAttribute | Visual attribute for check-box items (gray background, Arial 8pt, black foreground, transparent fill). | not used directly in this form | N/A |
| VA_RB | VisualAttribute | Visual attribute for radio-button items (gray background, Arial 8pt, black foreground). | not used directly in this form | N/A |
| VA_ICONIC_BUTN | VisualAttribute | Visual attribute for iconic buttons (white background, black foreground). | not used directly in this form | N/A |
| VA_DESC | VisualAttribute | Visual attribute for descriptive text items (gray background, Small Fonts 7pt, blue foreground). | not used directly in this form | N/A |
| VA_NUM | VisualAttribute | Visual attribute for numeric items (white background, Arial 8pt, black foreground). | not used directly in this form | N/A |
| VA_MAND | VisualAttribute | Visual attribute for mandatory input fields (cyan background, Arial 9pt, black foreground). | not used directly in this form | N/A |
| VA_OPROMPT | VisualAttribute | Visual attribute for optional field prompts (white background, Arial 9pt, black prompt foreground). | not used directly in this form | N/A |
| VA_MPROMPT | VisualAttribute | Visual attribute for mandatory field prompts (white background, Arial 9pt, red prompt foreground). | not used directly in this form | N/A |
| VA_TEXT | VisualAttribute | Visual attribute for standard text items (white background, Arial 9pt, black foreground). | not used directly in this form | N/A |
| VA_BUTN | VisualAttribute | Visual attribute for standard push buttons (gray background, Arial 10pt Bold, black foreground). | not used directly in this form | N/A |
| VA_ALERT | VisualAttribute | Visual attribute for alert dialogs (gray background, MT Extra 11pt, black foreground). | not used directly in this form | N/A |
| VA_TITLE | VisualAttribute | Visual attribute for title labels (gray background, Arial 10pt Bold, blue foreground). | not used directly in this form | N/A |
| VA_TRNI_DT | VisualAttribute | Visual attribute for transaction date fields (white background, Courier Bold, black foreground). | not used directly in this form | N/A |
| VA_LOV | VisualAttribute | Visual attribute for LOV-linked fields (gray background, Arial 9pt, dark-blue foreground). | not used directly in this form | N/A |
| VA_DISP | VisualAttribute | Visual attribute for display-only items (r25g75b75 background, Arial 8pt Bold, black foreground). | not used directly in this form | N/A |
| PC_DESC | PropertyClass | Property class for display items: left-justified, 250 width, white background, Arial 9pt, no bevel, blue foreground, max 110 chars. | not used directly in this form | N/A |
| PC_SC_DATE | PropertyClass | Property class for screen date items: gray background, Arial 8pt Bold, format mask blank, hint for DD-MM-YY entry, mouse-navigable. | not used directly in this form | N/A |
| PC_TITLE | PropertyClass | Property class for title text items: center-justified, gray background, Arial 10pt Bold, uppercase restriction. | not used directly in this form | N/A |
| PC_FORMAT | PropertyClass | Property class for format fields: center-justified, 60 width, white background, Arial 9pt, uppercase, max 12 chars. | not used directly in this form | N/A |
| PC_MR_BLK | PropertyClass | Property class for multi-record blocks: navigates to PB_BLK on next block, vertical orientation. | not used directly in this form | N/A |
| PC_DISP | PropertyClass | Property class for disabled display items: left-justified, lowered bevel, gray8 background, Arial 9pt, not keyboard-navigable. | not used directly in this form | N/A |
| PC_LOV | PropertyClass | Property class for LOV-linked fields: LOV at position 80/96, 250 width, gray background, Arial 8pt, auto-select off, dark-blue foreground, 200 height. | not used directly in this form | N/A |
| PC_FORM | PropertyClass | Property class defining standard form-level properties: validation at item level, savepoint disabled, console window WN_MAIN, menu module menu.mmx. Also defines standard form triggers (ON-ERROR, ON-MESSAGE, KEY-EXIT, KEY-LISTVAL, KEY-COMMIT, KEY-CLRFRM). | referenced by this form's module design | N/A |
| PC_DISP_DATE | PropertyClass | Property class for display-only date items: left-justified, disabled, gray8 background, Arial 9pt, format mask DD-MM-RRRR, not keyboard-navigable. | not used directly in this form | N/A |
| PC_DISP_NUM | PropertyClass | Property class for display-only numeric items: right-justified, disabled, lowered bevel, gray8 background, Arial 9pt, not keyboard-navigable. | not used directly in this form | N/A |
| PC_DATE | PropertyClass | Property class for date entry fields: 60 width, white background, Arial 9pt, format mask DD-MM-RRRR, hint for DD-MM-YYYY/DD/MM/YYYY, mouse-navigable, date data type. | not used directly in this form | N/A |
| PC_DTTIME | PropertyClass | Property class for date-and-time fields: 80 width, format mask DD-MM-RRRR HH24:MI, initialised to current DB datetime. | not used directly in this form | N/A |
| PC_CB | PropertyClass | Property class for check-box items: white background, Arial 9pt, 14 height. | not used directly in this form | N/A |
| PC_ALERT | PropertyClass | Property class for alert dialogs: gray background, MT Extra 11pt. | not used directly in this form | N/A |
| PC_MDATE | PropertyClass | Property class for mandatory date entry fields: white background, Arial 8pt, format mask DD-MM-RRRR, hint for DD-MM-YYYY, red prompt foreground. Includes a WHEN-VALIDATE-ITEM trigger that raises an error when the field is blank. | not used directly in this form | N/A |
| PC_RB | PropertyClass | Property class for radio-button items: gray background, Arial 9pt, 11 height. | not used directly in this form | N/A |
| PC_WIND | PropertyClass | Property class for windows: resizable, maximizable, minimizable, hide-on-exit, gray background, Arial 10pt Bold, blue foreground, 464×286 default size. | not used directly in this form | N/A |
| PC_CANV | PropertyClass | Property class for canvases: white background, Arial, 750×440 size, raise-on-enter, viewport 479×301, associated with WN_MAIN. | not used directly in this form | N/A |
| PC_BUTN | PropertyClass | Property class for push buttons: 42 wide, gray background, Arial 9pt Bold, not mouse-navigable. | not used directly in this form | N/A |
| PC_TEXT | PropertyClass | Property class for standard text items: left-justified, white background, Arial 9pt, mixed case. | not used directly in this form | N/A |
| PC_MTEXT | PropertyClass | Property class for mandatory text items (details not shown in extracted data - standard DPL library entry). | not used directly in this form | N/A |
| PC_UTEXT | PropertyClass | Property class for uppercase text items (details not shown in extracted data - standard DPL library entry). | not used directly in this form | N/A |
| PC_MUTEXT | PropertyClass | Property class for mandatory uppercase text items (details not shown in extracted data - standard DPL library entry). | not used directly in this form | N/A |
| PC_NUM | PropertyClass | Property class for numeric items (details not shown in extracted data - standard DPL library entry). | not used directly in this form | N/A |
| PC_MNUM | PropertyClass | Property class for mandatory numeric items (details not shown in extracted data - standard DPL library entry). | not used directly in this form | N/A |
| PC_ICONIC_BUTN | PropertyClass | Property class for iconic push buttons (details not shown in extracted data - standard DPL library entry). | not used directly in this form | N/A |
| PC_SCROLL | PropertyClass | Property class for scroll bars (details not shown in extracted data - standard DPL library entry). | not used directly in this form | N/A |
| WEBUTIL | ObjectGroup | The WebUtil object group. Contains the WEBUTIL block and all its function-binding items (client-info, file, host, session, file-transfer, OLE, C-API, browser functions) needed to enable WebUtil in Oracle Forms. | 1 (WEBUTIL block subclasses from this group) | WEBUTIL block (DUMMY, WEBUTIL_CLIENTINFO_FUNCTIONS, WEBUTIL_FILE_FUNCTIONS, WEBUTIL_HOST_FUNCTIONS, WEBUTIL_SESSION_FUNCTIONS, WEBUTIL_FILETRANSFER_FUNCTIONS, WEBUTIL_OLE_FUNCTIONS, WEBUTIL_C_API_FUNCTIONS, WEBUTIL_BROWSER_FUNCTIONS) |
| WEBUTIL_NO_OLE | ObjectGroup | An alternative WebUtil object group without OLE function bindings, for deployments where OLE is not required. | not used directly in this form | N/A |
| OG_GROUP | ObjectGroup | Form-level object group defined in the form XML (from the DPL library). Contains shared toolbar objects (PB_BLK button set) inherited across dealership forms. | 1 (PB_BLK items subclass from this group) | PB_EXIT, PB_LIST, PB_INSERT, PM_CONT, PB_DEL, PB_CANCEL, PB_SAVE, PB_PRINT, PB_CUT, PB_COPY, PB_PASTE, PB_ERR_EXIT |

---

## 10. Record Groups

*Lists all record groups, their LOV bindings, query logic, dynamic bindings, business purpose, and form usage.*

| Record Group | Type | Used By LOV | Display Column | Return Column | Dynamic Bindings | Purpose | Where Used |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| RG_LOC | Query | LOV_LOC | LOC_CD | LOC_DESC | No | Lists active service locations available to the logged-in user for dealer selection | LOV_LOC -> CB_DUMMY.CB_LOC_DESC |

**Total Record Groups:** 1

---

## 11. Referenced Database Objects

*Database tables, views, and objects accessed by the form.*

### 11.1 Block-Table Binding Summary

| Block | Base Table | Primary Key Item | Database Item |
| :--- | :--- | :--- | :--- |
| CB_DUMMY | - | - | No |
| VH_RO_HOLD_UP | - | - | No |
| PB_BLK | - | - | No |

### 11.2 Object Reference Detail

| Object | Schema | Used In | Description |
| :--- | :--- | :--- | :--- |
| `AM_LIST` | - | Trigger WHEN-NEW-FORM-INSTANCE | Service category list table - provides service category code descriptions by list name and principal; used in the service-type column of the non-B&P and approval-pending export queries |
| `AM_USER_DEALER_MASTER` | - | RG_LOC | User-dealer access mapping - defines which dealers and locations each user is authorised to access |
| `DUAL` | - | Trigger WHEN-BUTTON-PRESSED | Oracle system pseudo-table - used as the header row source in the Excel export SQL |
| `GM_MOD` | - | POPULATE_DETAILS, Trigger WHEN-BUTTON-PRESSED | Vehicle model master - provides model description from model code for display and export |
| `MULDMS.VH_RO` | - | POPULATE_DETAILS, Trigger WHEN-BUTTON-PRESSED | Repair order header - contains billing amounts, odometer change approval data, and job card details |
| `MULDMS.VH_RO_HOLD_UP` | - | POPULATE_DETAILS, Trigger WHEN-BUTTON-PRESSED | RO hold-up register - primary table tracking repair orders on hold with hold date, reason, and status |
| `VM_DREASON` | - | POPULATE_DETAILS, Trigger WHEN-BUTTON-PRESSED | Delay/hold reason master - provides reason description from reason code for NBDR and BDR categories |
| `VM_SUB_SRV_CAL` | - | Trigger WHEN-BUTTON-PRESSED | Sub-service category lookup - provides sub-repair category description for display in export |
| `VM_SVAR` | - | POPULATE_DETAILS, Trigger WHEN-BUTTON-PRESSED | Service variant/sub-model master - provides variant description from service model code |

**Total Referenced Objects:** 9

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure/Package Index

| Requirement ID | Procedure/Package | Purpose |
| -------------- | ----------------- | ------- |
| BR-005 | POPULATE_DETAILS | Retrieves RO hold-up records from the database for the selected view type, location, and date, and loads them into the results block |
| BR-006 | VIEW_EXCEL_REPORT_NEW (DMS_EXCEL_REPORT) | Generates and downloads a CSV export of the hold-up data for the selected view type to the user's workstation |
| BR-007 | GENERAL.RAISE_ERROR | Looks up and displays a business-defined error message for a given error code (used for parent-record constraint violations) |
| BR-007 | GENERAL.DISP_TEXT | Displays a formatted message to the user (used for record-locking conflicts, known input errors, and general SQL errors) |
| BR-001, BR-008 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Registers or clears the client module identifier in the current database session for activity monitoring |
| BR-001, BR-008 | DBMS_APPLICATION_INFO.SET_MODULE | Registers or clears the module name and action name in the current database session for activity monitoring |
| - | ITEM_ENABLE | Enables or disables named form items at runtime to control user interaction state |
| - | GENERAL.ASK_CONFIRM | Displays a confirmation dialog to the user and returns the user's response before proceeding with an action |
| - | GENERAL.L_POP_LIST_ITEM | Populates a list item control at form startup from a supplied record group name and SELECT statement |
| - | WEBUTIL_CORE.CUSTOMEVENTHANDLER | Central dispatch handler for WebUtil custom item events; routes asynchronous WebUtil Java applet responses to the correct Forms-server subsystem |

---

### 12.2 Procedure and Package Catalogue

#### POPULATE_DETAILS

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| POPULATE_DETAILS | Form program unit (PROCEDURE) | WHEN-BUTTON-PRESSED on CB_DUMMY.PB_SEARCH | Retrieves RO hold-up records for the selected view type, location, and date using one of four dedicated cursors; loads rows into the VH_RO_HOLD_UP block; looks up model descriptions from GM_MOD, variant descriptions from VM_SVAR, and hold-reason descriptions from VM_DREASON; and resets the block to read-only after load. On no-data-found raises an informational message via GENERAL.DISP_TEXT; on other errors raises an error with the database error text. |

---

#### ITEM_ENABLE

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| ITEM_ENABLE | Form program unit (PROCEDURE) | WHEN-NEW-FORM-INSTANCE (Form); other form triggers and program units that need to toggle item interactability | Enables or disables a named form item at runtime by setting its ENABLED property. Used at form initialisation and during user interaction to enforce field-level access control and prevent input to items that are not relevant in the current state. |

---

#### VIEW_EXCEL_REPORT_NEW

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| VIEW_EXCEL_REPORT_NEW | External library procedure (DMS_EXCEL_REPORT.pld/pll) | WHEN-BUTTON-PRESSED on CB_DUMMY.PB_EXCEL | Accepts a principal code, file name, SQL query, column name, and application ID; executes the query against MULDMS.VH_RO_HOLD_UP, MULDMS.VH_RO, GM_MOD, VM_DREASON, VM_SUB_SRV_CAL, and DUAL; formats the result as a CSV file; and downloads it to the client workstation. |

---

#### GENERAL.ASK_CONFIRM

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| GENERAL.ASK_CONFIRM | External package function (GENERAL package, DPL.pld/pll) | WHEN-BUTTON-PRESSED on WEBUTIL.DUMMY | Displays a confirmation dialog to the user with the supplied message text and returns a numeric value indicating the user's response (confirmed or cancelled). Used to prompt for explicit user confirmation before proceeding with a destructive or irreversible action. |

---

#### GENERAL.DISP_TEXT

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| GENERAL.DISP_TEXT | External package procedure (GENERAL package, DPL.pld/pll) | ON-ERROR (Form); WHEN-VALIDATE-ITEM on CB_DUMMY.FROM_DATE; WHEN-VALIDATE-ITEM on CB_DUMMY.TO_DATE; POPULATE_DETAILS (form program unit) | Displays a modal alert dialog using AL_ERRINFO (for errors) or AL_NOTE (for notes) with the supplied message text and title string. Sets the alert message text and title at runtime, then shows the alert. Used for error routing in ON-ERROR, validation failures on date fields, and data-retrieval failure messages from POPULATE_DETAILS. |

---

#### GENERAL.L_POP_LIST_ITEM

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| GENERAL.L_POP_LIST_ITEM | External package procedure (GENERAL package, DPL.pld/pll) | WHEN-NEW-FORM-INSTANCE (Form) | Populates a list item control at form startup using the supplied record group name and SELECT statement. Invoked during WHEN-NEW-FORM-INSTANCE to initialise list-of-values controls - including the service-category list backed by AM_LIST and AM_USER_DEALER_MASTER - with data retrieved from the database before the user begins interacting with the form. |

---

#### GENERAL.RAISE_ERROR

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| GENERAL.RAISE_ERROR | External package procedure (GENERAL package, DPL.pld/pll) | ON-ERROR (Form) | Looks up the predefined business error message for the supplied error code from the error message master and displays it via GENERAL.DISP_TEXT with the appropriate title (Error/Note/Caution); raises FORM_TRIGGER_FAILURE for error-type messages. Used specifically for routing ORA-02292 parent-record constraint violations to a user-friendly message. |

---

#### DBMS_APPLICATION_INFO.SET_CLIENT_INFO

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Oracle built-in package procedure | PRE-FORM (Form); KEY-EXIT (Form) | Sets or clears the client-information string in the current database session, allowing database monitoring tools to identify the active form module. Set to `'vi_ro_hold_up'` at form open; cleared (set to null) at keyboard exit. |

---

#### DBMS_APPLICATION_INFO.SET_MODULE

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| DBMS_APPLICATION_INFO.SET_MODULE | Oracle built-in package procedure | PRE-FORM (Form); KEY-EXIT (Form) | Sets or clears the module name and action name in the current database session. Set to `'vi_ro_hold_up'` with a blank action at form open; cleared to empty strings at keyboard exit. |

---

#### WEBUTIL_CORE.CUSTOMEVENTHANDLER

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| WEBUTIL_CORE.CUSTOMEVENTHANDLER | External library procedure (WEBUTIL_CORE package, webutil.pld/pll) | WHEN-CUSTOM-ITEM-EVENT on WEBUTIL.WEBUTIL_BROWSER_FUNCTIONS; WHEN-CUSTOM-ITEM-EVENT on WEBUTIL.WEBUTIL_CLIENTINFO_FUNCTIONS; WHEN-CUSTOM-ITEM-EVENT on WEBUTIL.WEBUTIL_C_API_FUNCTIONS; WHEN-CUSTOM-ITEM-EVENT on WEBUTIL.WEBUTIL_FILETRANSFER_FUNCTIONS; WHEN-CUSTOM-ITEM-EVENT on WEBUTIL.WEBUTIL_FILE_FUNCTIONS; WHEN-CUSTOM-ITEM-EVENT on WEBUTIL.WEBUTIL_HOST_FUNCTIONS; WHEN-CUSTOM-ITEM-EVENT on WEBUTIL.WEBUTIL_OLE_FUNCTIONS; WHEN-CUSTOM-ITEM-EVENT on WEBUTIL.WEBUTIL_SESSION_FUNCTIONS | Central dispatch handler for WebUtil custom item events. Receives the event name and its associated parameters and routes processing to the appropriate WebUtil subsystem. Registered as the WHEN-CUSTOM-ITEM-EVENT handler across all WebUtil functional bean items so that asynchronous responses from the WebUtil Java applet are correctly processed on the Forms server side. Required for client-file download operations triggered by VIEW_EXCEL_REPORT_NEW. |

---

#### VIEW_EXCEL_REP (INACTIVE)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| VIEW_EXCEL_REP | Form program unit (PROCEDURE) - **(COMMENTED OUT / INACTIVE - does not execute)** | All call sites in PB_EXCEL trigger are commented out | Earlier version of the CSV export function, superseded by VIEW_EXCEL_REPORT_NEW. Reads a server-side path configuration file, builds a record group from the query using WEBUTIL.ID_NULL (WEBUTIL_C_API) to check for an existing group, iterates rows, and writes a CSV file. No longer invoked. |

---

#### GENERAL.CHECK_FORM_FAILURE (INACTIVE)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| GENERAL.CHECK_FORM_FAILURE | External package procedure (GENERAL package, DPL.pld/pll) - **(COMMENTED OUT / INACTIVE - does not execute)** | KEY-COMMIT trigger body (commented out) | Previously validated that the last Forms operation succeeded by checking FORM_SUCCESS; raised an error message via GENERAL.DISP_TEXT if the operation failed. Referenced only in the commented-out KEY-COMMIT trigger body; no longer invoked. |

## 13. Package Procedure Specifications

*NO PCK files found - no ``*.pck`` source files were discovered in ``/app/section-rewrite-pipeline/workspaces/785d62af-9afd-4598-a0eb-f8344769bad2/inputs/form_sources``. Package specifications cannot be generated without uploaded PCK sources.*

## 14. Database Package Catalogue

*NO PCK files found - no `*.pck` source files were discovered in the form sources input directory. The database package catalogue cannot be generated without uploaded PCK sources.*

## 15. PLD Procedure Call Sites

*Maps each program-library routine to its call sites within triggers and program units. Behaviour descriptions are derived from the uploaded ``.pld`` sources.*

### DPL.pld (`general`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ASK_CONFIRM | Function | Function(confirm_msg VARCHAR2) RETURN NUMBER | Trigger: WHEN-BUTTON-PRESSED in WEBUTIL.DUMMY | Displays a confirmation dialog to the user with the supplied message text and returns a numeric value indicating the user's response. Used in the WHEN-BUTTON-PRESSED trigger on the WEBUTIL.DUMMY item to prompt for user confirmation before proceeding with an action. |
| DISP_TEXT | Procedure | Procedure(text_string VARCHAR2, title_string VARCHAR2) | ProgramUnit: POPULATE_DETAILS, Trigger: ON-ERROR in Form, Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.FROM_DATE, Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.TO_DATE | Displays a modal alert dialog using AL_ERRINFO (for errors) or AL_NOTE (for notes) with the supplied message text and title. Sets the alert message text and title at runtime, then shows the alert. Used to report validation errors, data population failures, and system errors to the user. |
| l_pop_list_item | Procedure | Procedure(p_rg_name VARCHAR2, p_select VARCHAR2) | Trigger: WHEN-NEW-FORM-INSTANCE in Form | Populates a list item control at form startup using the supplied record group name and SELECT statement. Invoked during WHEN-NEW-FORM-INSTANCE to initialise list-of-values controls with data retrieved from the database before the user begins interacting with the form. |
| RAISE_ERROR | Procedure | Procedure(mesg_code IN VARCHAR2) | Trigger: ON-ERROR in Form | Looks up a predefined error message by its error code, then displays the message via GENERAL.DISP_TEXT with the appropriate title (Error/Note/Caution) and raises FORM_TRIGGER_FAILURE for error-type messages. Invoked when a referential integrity constraint violation (ORA-02292) is detected in the ON-ERROR trigger. |

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``vi_ro_hold_up_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| CHECK_FORM_FAILURE | Procedure | Procedure() | Trigger: KEY-COMMIT in Form | **COMMENTED OUT / INACTIVE** - Previously validated that the last Forms operation succeeded by checking form_success; raised an error message via GENERAL.DISP_TEXT if the operation failed. Referenced only in the commented-out KEY-COMMIT trigger body. |

**Total Active Routines:** 4 of 24 in DPL.pld source
**Inactive / commented-only routines:** 1

---

### webutil.pld (`WEBUTIL_CORE`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| CustomEventHandler | Procedure | Procedure(EventName in VARCHAR2, EventParameters in VARCHAR2) | Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_BROWSER_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_CLIENTINFO_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_C_API_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_FILETRANSFER_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_FILE_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_HOST_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_OLE_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_SESSION_FUNCTIONS | Central dispatch handler for WebUtil custom item events. Receives the event name and its associated parameters and routes processing to the appropriate WebUtil subsystem. Registered as the WHEN-CUSTOM-ITEM-EVENT handler across all WebUtil functional bean items (browser, client info, C API, file transfer, file, host, OLE, and session) so that asynchronous responses from the WebUtil Java applet are correctly processed on the Forms server side. |

**Total Active Routines:** 1 of 39 in webutil.pld source

---

### webutil.pld (`WEBUTIL_C_API`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ID_NULL | Function | Function(handle IN Pointer) RETURN BOOLEAN | ProgramUnit: VIEW_EXCEL_REP | Checks whether an Oracle Forms handle (record group ID) is null; returns TRUE if the handle has no value, FALSE otherwise. Used in VIEW_EXCEL_REP to determine whether an existing record group needs to be deleted before recreating it. |

**Total Active Routines:** 1 of 28 in webutil.pld source

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| ID | Service Name | Database Object | Input Parameters | Output | Business Function | API Endpoint Suggestion |
| -- | ------------ | --------------- | ---------------- | ------ | ----------------- | ----------------------- |
| MS-001 | RO Hold-Up Query Service | MULDMS.VH_RO_HOLD_UP | dealerMapCd, locCd, holdUpDate, viewType (nonBandP / bandP / odometer) | List of hold-up records with serial number, job card number, VIN, registration number, RO date, promised date, hold reason code, RO status, service category, model code, odometer reading, creation date, composite FA key | Retrieves the list of repair orders that are held up (overdue on promised delivery date) for a given location and date, for the non-B&P, B&P, or approval-pending odometer view type | `GET /api/ro-hold-up/query` |
| MS-002 | Billing Variance Query Service | MULDMS.VH_RO, MULDMS.AM_DEALER_LOC | dealerMapCd, locCd, fromDate, toDate, principal | List of completed ROs with registration number, variant code, part amount, labour amount, total bill amount | Retrieves completed repair orders (B&P category, status closed) for active 2S/3S dealer locations where the combined part and labour cost exceeds the threshold, within the specified billing date range | `GET /api/ro-hold-up/billing-variance` |
| MS-003 | Odometer Approval Status Service | MULDMS.VH_RO_HOLD_UP, MULDMS.VH_RO | dealerMapCd, locCd, holdUpDate, principal | List of hold-up records enriched with CEO approval status (Pending / Approved / Rejected), odometer reason, CEO remarks | Retrieves hold-up records joined to the RO header to obtain odometer-change approval status for ROs where an odometer-change decision is in progress or has been made | `GET /api/ro-hold-up/odometer-approval` |
| MS-004 | Hold-Up CSV Export Service | MULDMS.VH_RO_HOLD_UP, MULDMS.VH_RO, MULDMS.AM_DEALER_LOC | principal, fileName, viewType, dealerMapCd, locCd, fromDate, toDate, appId | CSV file download (comma-separated rows with header) | Generates and delivers a CSV file containing the hold-up data for the selected view type, equivalent to the on-screen results | `POST /api/ro-hold-up/export` |
| MS-005 | Model Description Lookup Service | GM_MOD | modelCd, principalMapCd | Model description (or "N/A" if not found) | Looks up the human-readable model description for a given model code and principal, used to enrich hold-up records | `GET /api/vehicle/models/{modelCd}?principal={principalMapCd}` |
| MS-006 | Hold Reason Description Lookup Service | VM_DREASON | reasonCd, reasonType, principalMapCd | Reason description (or "NA" if not found) | Looks up the human-readable description for a given hold/delay reason code and type (NBDR for non-B&P, BDR for B&P), filtered by active flag and principal | `GET /api/hold-reasons/{reasonCd}?type={reasonType}&principal={principalMapCd}` |
| MS-007 | Variant Description Lookup Service | VM_SVAR | svarCd, principalMapCd | Variant description (or "N/A" if not found) | Looks up the sub-model / variant description for a given variant code and principal, used in the billing variance view | `GET /api/vehicle/variants/{svarCd}?principal={principalMapCd}` |
| MS-008 | User Location Authorisation Service | AM_USER_DEALER_MASTER, AM_DEALER_LOC | userId, principal | List of authorised locations (location code, location description, dealer map code) | Returns the list of active service workshop locations (2S/3S dealer types) that the logged-in user is authorised to view for the current dealership principal | `GET /api/user/authorised-locations?userId={userId}&principal={principal}` |

**Total Microservices Identified: 8**

---

## 17. Workflows

| ID | Workflow Name | Trigger Event | Steps | Decision Points | End State |
| -- | ------------- | ------------- | ----- | --------------- | --------- |
| WF-001 | Form Session Initialisation | PRE-FORM trigger fires when the form opens | 1. Database session context set with module name 'vi_ro_hold_up' and client info registered | None | Search criteria screen displayed to user |
| WF-002 | Hold-Up View Type Selection | WHEN-LIST-CHANGED fires when user changes the Status drop-down | 1. View type value checked; 2. Date defaults set to yesterday; 3. Relevant result columns and date filters shown or hidden; 4. Approval-status fields shown/hidden based on view; 5. Results block cleared; 6. Focus moved to Location filter | Which of the four view types (non-B&P, B&P, billing variance, approval-pending) was selected - determines column visibility, To Date visibility, and approval-field read-only settings | Screen layout reconfigured; results cleared; cursor on Location field |
| WF-003 | As On Date Validation | WHEN-VALIDATE-ITEM fires when user tabs off the As On Date field | 1. Blank check; 2. Future-date check; 3. Cross-check against To Date; 4. To Date auto-calculated as end-of-month (or yesterday if month-end is future) | (a) Blank -> error and stop; (b) Future date -> alert and stop; (c) After To Date -> alert, clear both dates, stop; (d) All pass -> auto-calculate To Date | Valid As On Date accepted; To Date defaulted; user can proceed to Search |
| WF-004 | To Date Validation (Billing Variance) | WHEN-VALIDATE-ITEM fires when user tabs off the To Date field | 1. Check billing variance view is active (gate); 2. Blank check; 3. From Date present check; 4. To Date not before From Date; 5. From Date not after To Date (cross-check); 6. To Date not after today; 7. Date range not more than one month | (a) Not billing variance view -> silent exit; (b) Any date rule fails -> alert and stop; (c) All pass -> validation complete | Valid To Date accepted; user can proceed to Search |
| WF-005 | Hold-Up Results Search | WHEN-BUTTON-PRESSED fires when user clicks Search | 1. View type checked; 2. Results block temporarily enabled; 3. Appropriate query executed for view type; 4. Rows loaded into results block with serial numbers; 5. Reference descriptions looked up per row; 6. Results block reset to read-only; 7. Cursor positioned at first record | (a) View type not recognised -> silent exit; (b) No rows returned -> 'Data not available' note; (c) Database error -> error message, stop | Results displayed in read-only grid; or informational/error message shown |
| WF-006 | Export to Excel (CSV Download) | WHEN-BUTTON-PRESSED fires when user clicks Export to Excel | 1. View type checked; 2. Unique file name generated from user ID and timestamp; 3. Dynamic SQL query built for selected view type; 4. VIEW_EXCEL_REPORT_NEW called with query, file name, and session parameters; 5. CSV downloaded to client | (a) View type not recognised -> silent exit; (b) Any unexpected error -> silently caught (EXCEPTION WHEN OTHERS THEN NULL) | CSV file downloaded to user's workstation; or silent failure with no user message |
| WF-007 | Form Exit with Session Cleanup | KEY-EXIT trigger fires when user presses the Exit keyboard shortcut | 1. Client-info cleared from database session; 2. Module name and action cleared from application-info context; 3. Form closed without validating unsaved data | None | Database session context cleared; form closed |
| WF-008 | Form Exit via Exit Button (PB_BLK) | WHEN-BUTTON-PRESSED fires for PB_EXIT, NB_OK, or NB_EXIT buttons | 1. (PB_EXIT) If in Enter-Query mode, calls Exit action; if form has changes or is normal, calls Exit action - both paths close form; 2. (NB_OK) EXIT_FORM called directly; 3. (NB_EXIT) Exit flag set to 'EXIT', then Exit action called | (PB_EXIT) Form mode (Enter-Query vs. normal) checked - both paths result in exit; (NB_EXIT) Exit flag set before close | Form closed without saving unsaved data |
| WF-009 | Clear Form | KEY-CLRFRM trigger or NB_CLEAR button fires | 1. All blocks cleared without validation | None | All search criteria and results cleared; form in blank state |

**Total Workflows Identified: 9**

---

## 18. PLD-Backed Logic

*Maps shared library routines to their business function and suggested API contracts.*

### webutil.pld (`CLIENT_IMAGE`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | ID_NULL | Business Logic | ProgramUnit: VIEW_EXCEL_REP | /api/v1/pld/id_null | When a record group handle is provided, then returns whether the handle is null to determine if cleanup is required before creating a new group |


---

### DPL.pld (`general`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | CHECK_FORM_FAILURE | Validation | Trigger: KEY-COMMIT in Form | /api/v1/pld/check_form_failure | **COMMENTED OUT / INACTIVE** - When called after a Forms operation, then raises an error message if the operation did not succeed |
| PLD-002 | DISP_TEXT | Business Logic | ProgramUnit: POPULATE_DETAILS, Trigger: ON-ERROR in Form, Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.FROM_DATE, Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.TO_DATE | /api/v1/pld/disp_text | When a message text and title are provided, then displays a modal alert dialog to the user with the specified content |
| PLD-003 | RAISE_ERROR | Validation | Trigger: ON-ERROR in Form | /api/v1/pld/raise_error | When a referential integrity violation or classified error is detected, then retrieves the predefined error message by code and displays it to the user, stopping execution for error-type messages |


---

### D2kwutil.pld (`Win_API`)

*No routines from ``D2kwutil.pld`` are referenced in ``vi_ro_hold_up_fmb.xml``.*

---

---

## 19. PCK-Backed Logic

*NO PCK files found - no ``*.pck`` source files were discovered in ``/app/workspace/vi_ro_hold_up-c9998348468d/in``. PCK-backed logic cannot be generated without uploaded PCK sources.*

---

## 20. System Interfaces

### 20.1 Database Integrations

| Interface Name | Type | Purpose | Data Flow | Error Handling |
| -------------- | ---- | ------- | --------- | -------------- |
| RO Hold-Up Records (MULDMS.VH_RO_HOLD_UP) | Database table - Oracle | Primary data source for all hold-up enquiry views. | Read - form queries this table with filters on dealer map code, location code, hold-up date, RO status, service category, and promised date. | On no data found: informational message shown (*"Data not available"*). On other database errors: error text displayed and processing stops. |
| Repair Order Header (MULDMS.VH_RO) | Database table - Oracle | Joined to the hold-up records table for the billing variance and approval-pending odometer views to retrieve billing amounts and odometer-change approval status. | Read - joined on parent group, dealer map code, location code, composite FA key, job card number, and VIN. | Handled within POPULATE_DETAILS and export query error paths. |
| Dealer Location Master (MULDMS.AM_DEALER_LOC) | Database table - Oracle | Joined to the RO header for the billing variance view to restrict results to active 2S/3S dealer locations only. | Read - joined on dealer map code and location code; filtered by dealer type and active status. | Handled within POPULATE_DETAILS and export query error paths. |
| Vehicle Model Master (GM_MOD) | Database table - Oracle | Provides model descriptions for hold-up records displayed in the service RO, B&P, and approval-pending views and their corresponding exports. | Read - individual SELECT per row during POPULATE_DETAILS; also embedded in export queries. | On no data found: value defaults to "NA" silently. |
| Delay / Hold Reason Master (VM_DREASON) | Database table - Oracle | Provides hold-reason descriptions for service RO and B&P hold-up records and their exports. Different reason-type filters apply for each view (NBDR for non-B&P, BDR for B&P). | Read - individual SELECT per row during POPULATE_DETAILS; also embedded in export queries. | On no data found: value defaults to "NA" silently. |
| Variant / Sub-model Master (VM_SVAR) | Database table - Oracle | Provides variant descriptions for billing variance view hold-up records and their export. | Read - individual SELECT per row during POPULATE_DETAILS; also embedded in export query. | On no data found: value defaults to "NA" silently. |
| Service Category List (AM_LIST) | Database table - Oracle | Provides service-category descriptions for the service RO and approval-pending export queries, matched by list name "RCATEG_CD" and principal. | Read - embedded in export queries only (not in POPULATE_DETAILS). | Handled within export query; no explicit null-guard shown (NVL not applied in this join). |
| Sub-Service Category Master (VM_SUB_SRV_CAL) | Database table - Oracle | Provides sub-category descriptions for the service-type column in the service RO and approval-pending export queries, for ROs that carry a sub-category code. | Read - embedded in export queries only. | Handled within export query structure (CASE/NVL logic). |
| User Dealer Location Master (AM_USER_DEALER_MASTER) | Database table - Oracle | Used in the location LOV record group query to restrict the selectable locations to those authorised for the logged-in user, dealer type SERVICE, and principal. | Read - RG_LOC record group query executed when the location LOV is invoked. | LOV query failure would surface via KEY-LISTVAL exception handler; diagnostic message values shown. |
| Oracle Application Information (DBMS_APPLICATION_INFO) | Oracle built-in package | Used at form open (PRE-FORM) to register the form module identifier in the database session for monitoring, and at keyboard exit (KEY-EXIT) to clear the registration. | Write (session context only) - no persistent table data changed. | No explicit error handling for DBMS_APPLICATION_INFO calls. |

### 20.2 External System Integrations

The form has no external system integrations that transfer data to or from an external application via a protocol such as REST, SOAP, or a message queue. The DMS_EXCEL_REPORT library produces a CSV file that is downloaded to the user's local workstation, but this is a client file transfer via Oracle Forms WebUtil rather than an integration with an external system.

The following file access is evidenced in the inactive VIEW_EXCEL_REP program unit (which does not execute in the current form):

| System Name | Integration Type | Purpose | Protocol | Endpoint | Data Exchange | Success / Error Codes |
| ----------- | ---------------- | ------- | -------- | -------- | ------------- | --------------------- |
| Excel path configuration file (`/reports/DMS/excelpath.txt`) | Server file read - **(INACTIVE - referenced only in commented-out VIEW_EXCEL_REP procedure)** | Reads a server-side path to locate the target directory for CSV file output. Used by the superseded VIEW_EXCEL_REP procedure. | Direct file I/O (TEXT_IO) | `/reports/DMS/excelpath.txt` on the Forms application server | Read-only | Not evidenced (inactive code path) |

### 20.3 Report Integrations

| Report Name | Report Server | Parameters | Output Format | Trigger |
| ----------- | ------------- | ---------- | ------------- | ------- |
| rep.rdf | N/A - no active trigger invokes this report object | N/A - no active trigger invokes this report object | N/A - no active trigger invokes this report object | N/A - report object `REPORT_CALL` is declared in the form XML with execute mode Runtime but is not invoked by any active trigger in this form |

---

### 20.3.1 Parameters Passed to the Report

This form does not pass parameters to an Oracle Report. No report parameters were identified in the form sources.

## 21. Procedure and Function Business Rule Catalogue

End-to-end business requirement specification for every stored procedure and function referenced by the VI_RO_HOLD_UP form.

### 21.1 Catalogue Index

86 procedures/functions - each SP ID links to its detailed specification in Section 21.2.

| SP Index | Routine Name |
| :--- | :--- |
| [SP-001](#SP-001--ITEM_ENABLE) | ITEM_ENABLE |
| [SP-002](#SP-002--POPULATE_DETAILS) | POPULATE_DETAILS |
| [SP-003](#SP-003--D2KWUTIL.ATTEMPT_DLL_LOAD) | D2KWUTIL.ATTEMPT_DLL_LOAD |
| [SP-004](#SP-004--D2KWUTIL.CHOOSEFILE) | D2KWUTIL.CHOOSEFILE |
| [SP-005](#SP-005--D2KWUTIL.D2KWUTIL_ACTIVEWIN) | D2KWUTIL.D2KWUTIL_ACTIVEWIN |
| [SP-006](#SP-006--D2KWUTIL.D2KWUTIL_CHOOSEFILE) | D2KWUTIL.D2KWUTIL_CHOOSEFILE |
| [SP-007](#SP-007--D2KWUTIL.D2KWUTIL_DEBUGSTRING) | D2KWUTIL.D2KWUTIL_DEBUGSTRING |
| [SP-008](#SP-008--D2KWUTIL.D2KWUTIL_FILEINFO) | D2KWUTIL.D2KWUTIL_FILEINFO |
| [SP-009](#SP-009--D2KWUTIL.D2KWUTIL_GETDOSENV) | D2KWUTIL.D2KWUTIL_GETDOSENV |
| [SP-010](#SP-010--D2KWUTIL.D2KWUTIL_GETREGKEY) | D2KWUTIL.D2KWUTIL_GETREGKEY |
| [SP-011](#SP-011--D2KWUTIL.D2KWUTIL_WINDIR) | D2KWUTIL.D2KWUTIL_WINDIR |
| [SP-012](#SP-012--D2KWUTIL.FILE_INFO) | D2KWUTIL.FILE_INFO |
| [SP-013](#SP-013--D2KWUTIL.GET_ACTIVE_WINDOW) | D2KWUTIL.GET_ACTIVE_WINDOW |
| [SP-014](#SP-014--D2KWUTIL.SAVE_FILE) | D2KWUTIL.SAVE_FILE |
| [SP-015](#SP-015--D2KWUTIL.TRANSLATETYPE) | D2KWUTIL.TRANSLATETYPE |
| [SP-016](#SP-016--GENERAL.ASK_CONFIRM) | GENERAL.ASK_CONFIRM |
| [SP-017](#SP-017--GENERAL.DISP_TEXT) | GENERAL.DISP_TEXT |
| [SP-018](#SP-018--GENERAL.L_POP_LIST_ITEM) | GENERAL.L_POP_LIST_ITEM |
| [SP-019](#SP-019--GENERAL.RAISE_ERROR) | GENERAL.RAISE_ERROR |
| [SP-020](#SP-020--I.CREATED_DATE) | I.CREATED_DATE |
| [SP-021](#SP-021--WEBUTIL.BLOCKING) | WEBUTIL.BLOCKING |
| [SP-022](#SP-022--WEBUTIL.CHECKLIBS) | WEBUTIL.CHECKLIBS |
| [SP-023](#SP-023--WEBUTIL.CLEARCALLBACKTRIGGER) | WEBUTIL.CLEARCALLBACKTRIGGER |
| [SP-024](#SP-024--WEBUTIL.CLOSEBLOB) | WEBUTIL.CLOSEBLOB |
| [SP-025](#SP-025--WEBUTIL.CLOSEFILE) | WEBUTIL.CLOSEFILE |
| [SP-026](#SP-026--WEBUTIL.DOWNLOADFROMURL) | WEBUTIL.DOWNLOADFROMURL |
| [SP-027](#SP-027--WEBUTIL.DOWNLOADFROMURLINT) | WEBUTIL.DOWNLOADFROMURLINT |
| [SP-028](#SP-028--WEBUTIL.ERROR) | WEBUTIL.ERROR |
| [SP-029](#SP-029--WEBUTIL.ERRORALERT) | WEBUTIL.ERRORALERT |
| [SP-030](#SP-030--WEBUTIL.EXECUTE) | WEBUTIL.EXECUTE |
| [SP-031](#SP-031--WEBUTIL.FCLOSE) | WEBUTIL.FCLOSE |
| [SP-032](#SP-032--WEBUTIL.FILE_SAVE_DIALOG) | WEBUTIL.FILE_SAVE_DIALOG |
| [SP-033](#SP-033--WEBUTIL.FILE_SELECTION_DIALOG_INT) | WEBUTIL.FILE_SELECTION_DIALOG_INT |
| [SP-034](#SP-034--WEBUTIL.FOPEN) | WEBUTIL.FOPEN |
| [SP-035](#SP-035--WEBUTIL.GETCALLBACKTRIGGER) | WEBUTIL.GETCALLBACKTRIGGER |
| [SP-036](#SP-036--WEBUTIL.GETCLIENTOSFAMILY) | WEBUTIL.GETCLIENTOSFAMILY |
| [SP-037](#SP-037--WEBUTIL.GETCLIENTSETTING) | WEBUTIL.GETCLIENTSETTING |
| [SP-038](#SP-038--WEBUTIL.GETIMPLCLASS) | WEBUTIL.GETIMPLCLASS |
| [SP-039](#SP-039--WEBUTIL.GETLASTERROR) | WEBUTIL.GETLASTERROR |
| [SP-040](#SP-040--WEBUTIL.GETLASTERRORARGS) | WEBUTIL.GETLASTERRORARGS |
| [SP-041](#SP-041--WEBUTIL.GETNUMBER) | WEBUTIL.GETNUMBER |
| [SP-042](#SP-042--WEBUTIL.GETOSFAMILY) | WEBUTIL.GETOSFAMILY |
| [SP-043](#SP-043--WEBUTIL.GETOUTPUT) | WEBUTIL.GETOUTPUT |
| [SP-044](#SP-044--WEBUTIL.GETPROPERTY) | WEBUTIL.GETPROPERTY |
| [SP-045](#SP-045--WEBUTIL.GETSTRING) | WEBUTIL.GETSTRING |
| [SP-046](#SP-046--WEBUTIL.GETVAR) | WEBUTIL.GETVAR |
| [SP-047](#SP-047--WEBUTIL.GET_LINE) | WEBUTIL.GET_LINE |
| [SP-048](#SP-048--WEBUTIL.GET_RETURN_CODE) | WEBUTIL.GET_RETURN_CODE |
| [SP-049](#SP-049--WEBUTIL.GET_STANDARD_OUTPUT) | WEBUTIL.GET_STANDARD_OUTPUT |
| [SP-050](#SP-050--WEBUTIL.HOST) | WEBUTIL.HOST |
| [SP-051](#SP-051--WEBUTIL.ID_NULL) | WEBUTIL.ID_NULL |
| [SP-052](#SP-052--WEBUTIL.INIT) | WEBUTIL.INIT |
| [SP-053](#SP-053--WEBUTIL.INITWEBUTIL) | WEBUTIL.INITWEBUTIL |
| [SP-054](#SP-054--WEBUTIL.ISERROR) | WEBUTIL.ISERROR |
| [SP-055](#SP-055--WEBUTIL.IS_OPEN) | WEBUTIL.IS_OPEN |
| [SP-056](#SP-056--WEBUTIL.LENGTH) | WEBUTIL.LENGTH |
| [SP-057](#SP-057--WEBUTIL.LOG) | WEBUTIL.LOG |
| [SP-058](#SP-058--WEBUTIL.POPULATEPROPERTYBUNDLE) | WEBUTIL.POPULATEPROPERTYBUNDLE |
| [SP-059](#SP-059--WEBUTIL.PUTF) | WEBUTIL.PUTF |
| [SP-060](#SP-060--WEBUTIL.PUT_LINE) | WEBUTIL.PUT_LINE |
| [SP-061](#SP-061--WEBUTIL.READFROMPROPERTYBUNDLE) | WEBUTIL.READFROMPROPERTYBUNDLE |
| [SP-062](#SP-062--WEBUTIL.READTRANSFROMMSGBUNDLE) | WEBUTIL.READTRANSFROMMSGBUNDLE |
| [SP-063](#SP-063--WEBUTIL.REGISTERBEAN) | WEBUTIL.REGISTERBEAN |
| [SP-064](#SP-064--WEBUTIL.REGISTER_FUNCTION) | WEBUTIL.REGISTER_FUNCTION |
| [SP-065](#SP-065--WEBUTIL.RELEASE_PROCESS) | WEBUTIL.RELEASE_PROCESS |
| [SP-066](#SP-066--WEBUTIL.SETCLIENTSETTING) | WEBUTIL.SETCLIENTSETTING |
| [SP-067](#SP-067--WEBUTIL.SETDATA) | WEBUTIL.SETDATA |
| [SP-068](#SP-068--WEBUTIL.SETPROPERTY) | WEBUTIL.SETPROPERTY |
| [SP-069](#SP-069--WEBUTIL.SHOWBEANS) | WEBUTIL.SHOWBEANS |
| [SP-070](#SP-070--WEBUTIL.URL_TO_CLIENT) | WEBUTIL.URL_TO_CLIENT |
| [SP-071](#SP-071--WEBUTIL.WRITEDATA) | WEBUTIL.WRITEDATA |
| [SP-072](#SP-072--WEBUTIL_CORE.CUSTOMEVENTHANDLER) | WEBUTIL_CORE.CUSTOMEVENTHANDLER |
| [SP-073](#SP-073--ADD_ERROR) | ADD_ERROR |
| [SP-074](#SP-074--ADD_EXTERNAL_ERRORS) | ADD_EXTERNAL_ERRORS |
| [SP-075](#SP-075--BOOLTOCHAR) | BOOLTOCHAR |
| [SP-076](#SP-076--CLEAN_ERROR_STACK) | CLEAN_ERROR_STACK |
| [SP-077](#SP-077--DEBUGLOG) | DEBUGLOG |
| [SP-078](#SP-078--GET_ENVIRONMENT_STRING) | GET_ENVIRONMENT_STRING |
| [SP-079](#SP-079--GET_TEMP_DIRECTORY) | GET_TEMP_DIRECTORY |
| [SP-080](#SP-080--GET_WINDOWS_DIRECTORY) | GET_WINDOWS_DIRECTORY |
| [SP-081](#SP-081--READ_REGISTRY) | READ_REGISTRY |
| [SP-082](#SP-082--REGISTER_FUNCTION_CALL) | REGISTER_FUNCTION_CALL |
| [SP-083](#SP-083--SETDEBUG) | SETDEBUG |
| [SP-084](#SP-084--STRIPDIRSEP) | STRIPDIRSEP |
| [SP-085](#SP-085--VIEW_EXCEL_REPORT_NEW) | VIEW_EXCEL_REPORT_NEW |
| [SP-086](#SP-086--WINDEBUG) | WINDEBUG |

---

### 21.2 Detailed Specifications

#### SP-001 - ITEM_ENABLE

**Invoked From:**

- vi_ro_hold_up_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

Search Criteria (N/A / CN_MAIN)

---

**Purpose**

ITEM_ENABLE configures the visibility, enabled state, navigability, layout positions, and widths of search-criteria and results-block items on the RO Hold-Up screen at form startup. It reads the current STATUS value and applies a distinct set of item-property settings for each recognised status code (400, 500, 600, 800), ensuring that only the columns and controls relevant to the selected report mode are presented to the user.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate the global STATUS parameter to determine which display mode is required.
- Step 2 - For STATUS = '400' (Open RO Hold-Up): set CB_DUMMY.FROM_DATE to sysdate-1; hide and disable CB_DUMMY.TO_DATE (visible, enabled, and navigable all set to FALSE); show RO number, RO date, promised date, and reason description columns in the vh_ro_hold_up block; hide part amount, labour amount, and bill amount columns; reposition and resize reg_num, model_desc, ro_num, ro_date, promised_date, and reason_desc items to their standard hold-up layout coordinates; hide CEO_APPROVE_STATUS, ODOMETER_REASON, and CEO_REMARKS columns.
- Step 3 - For STATUS = '500' (applies identical property assignments as STATUS = '400'): repeat all item-property settings described in Step 2 without change.
- Step 4 - For STATUS = '600' (Billing / Amount mode): set both CB_DUMMY.FROM_DATE and CB_DUMMY.TO_DATE to sysdate-1; make CB_DUMMY.TO_DATE visible, enabled, and navigable; hide RO number, RO date, promised date, and reason description columns; show part amount, labour amount, and bill amount columns; reposition reg_num, model_desc, part_amt, labour_amt, and bill_amt to the billing layout coordinates and widen reg_num and model_desc accordingly; hide CEO_APPROVE_STATUS, ODOMETER_REASON, and CEO_REMARKS columns.
- Step 5 - For STATUS = '800' (CEO Approval mode): set both CB_DUMMY.FROM_DATE and CB_DUMMY.TO_DATE to sysdate-1; hide and disable CB_DUMMY.TO_DATE; show RO number, RO date, and promised date columns; hide reason description, part amount, labour amount, and bill amount columns; show CEO_APPROVE_STATUS, ODOMETER_REASON, and CEO_REMARKS columns; apply the same positional and width settings used for STATUS 400/500.
- Step 6 - If STATUS does not match any of the four recognised values, no property changes are applied and the form retains its default design-time layout.

---
**Decision Points**

DP-001

Condition: :STATUS = '400'

TRUE: Initialise FROM_DATE to sysdate-1; hide/disable/non-navigate TO_DATE; display RO-centric columns (ro_num, ro_date, promised_date, reason_desc); hide amount columns (part_amt, labour_amt, bill_amt); hide CEO columns (CEO_APPROVE_STATUS, ODOMETER_REASON, CEO_REMARKS); apply standard hold-up positional layout.

FALSE: Evaluate subsequent ELSIF conditions.

DP-002

Condition: :STATUS = '500'

TRUE: Apply the same item-property configuration as STATUS = '400' (identical FROM_DATE initialisation, TO_DATE suppression, column visibility, positions, and widths).

FALSE: Evaluate subsequent ELSIF conditions.

DP-003

Condition: :STATUS = '600'

TRUE: Initialise both FROM_DATE and TO_DATE to sysdate-1; expose and enable TO_DATE; hide RO-centric columns; show amount columns (part_amt, labour_amt, bill_amt); hide CEO columns; apply billing layout positions and wider column widths.

FALSE: Evaluate subsequent ELSIF condition.

DP-004

Condition: :STATUS = '800'

TRUE: Initialise both FROM_DATE and TO_DATE to sysdate-1; hide/disable/non-navigate TO_DATE; show ro_num, ro_date, and promised_date; hide reason_desc and amount columns; show CEO_APPROVE_STATUS, ODOMETER_REASON, and CEO_REMARKS; apply standard hold-up positional layout.

FALSE: No item-property changes are made; form retains design-time defaults.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure is invoked exclusively at form initialisation (WHEN-NEW-FORM-INSTANCE); item properties are therefore set once per session based on the STATUS value active at startup.
- BR-002 - STATUS codes '400' and '500' produce an identical screen layout: the TO_DATE filter is suppressed, and the display focuses on RO workflow columns (ro_num, ro_date, promised_date, reason_desc) with FROM_DATE defaulted to sysdate-1.
- BR-003 - STATUS code '600' is the only mode that exposes the TO_DATE search criterion; both FROM_DATE and TO_DATE are defaulted to sysdate-1, and the display switches to billing amount columns (part_amt, labour_amt, bill_amt).
- BR-004 - STATUS code '800' activates the CEO Approval layout: CEO_APPROVE_STATUS, ODOMETER_REASON, and CEO_REMARKS are made visible, while reason_desc and all amount columns are hidden; TO_DATE remains suppressed.
- BR-005 - For STATUS codes 400, 500, and 800, the CEO-related columns (CEO_APPROVE_STATUS, ODOMETER_REASON, CEO_REMARKS) must be explicitly hidden, ensuring they are never visible outside the CEO Approval mode (STATUS = '800').
- BR-006 - Column positions and widths are hardcoded per status mode; reg_num and model_desc adopt narrower dimensions (width 95 and 74 respectively) in the hold-up layout (400/500/800) and wider dimensions (width 139 and 160 respectively) in the billing layout (600), ensuring consistent column alignment within each mode.

---
**Implementation Logic**

```plsql
PROCEDURE ITEM_ENABLE IS
BEGIN
  if :STATUS ='400' then
	:CB_DUMMY.from_date:=sysdate-1;
		set_item_property('CB_DUMMY.TO_DATE',visible,property_falsE);
		set_item_property('CB_DUMMY.TO_DATE',ENABLED,property_false);
		set_item_property('CB_DUMMY.TO_DATE',navigable,property_false);
		set_item_property('vh_ro_hold_up.ro_num',visible,property_true);
		set_item_property('vh_ro_hold_up.ro_date',visible,property_true);
		set_item_property('vh_ro_hold_up.promised_date',visible,property_true);
		set_item_property('vh_ro_hold_up.reason_desc',visible,property_true);
		set_item_property('vh_ro_hold_up.part_amt',visible,property_false);
		set_item_property('vh_ro_hold_up.labour_amt',visible,property_false);
		set_item_property('vh_ro_hold_up.bill_amt',visible,property_false);		
		set_item_property('vh_ro_hold_up.ro_num',position,71,114);		
		set_item_property('vh_ro_hold_up.reg_num',position,159,114);
		set_item_property('vh_ro_hold_up.ro_date',position,256,114);				
		set_item_property('vh_ro_hold_up.model_desc',position,338,114);
		set_item_property('vh_ro_hold_up.promised_date',position,412,114);
		set_item_property('vh_ro_hold_up.reason_desc',position,513,114);
		set_item_property('vh_ro_hold_up.reg_num',width,95);
		set_item_property('vh_ro_hold_up.model_desc',width,74);	
			-------- ADDED START BY SANTOSH KUMAR AS ON DS-4704 DATED ON 27-JAN-2026
		set_item_property('vh_ro_hold_up.CEO_APPROVE_STATUS',visible,property_false);
		set_item_property('vh_ro_hold_up.ODOMETER_REASON',visible,property_false);
		set_item_property('vh_ro_hold_up.CEO_REMARKS',visible,property_false);
		-------- ENDED BY SANTOSH KUMAR AS ON DS-4704 DATED ON 27-JAN-2026 
elsif :STATUS ='500' then
	:CB_DUMMY.from_date:=sysdate-1;
		set_item_property('CB_DUMMY.TO_DATE',visible,property_falsE);
		set_item_property('CB_DUMMY.TO_DATE',ENABLED,property_false);
		set_item_property('CB_DUMMY.TO_DATE',navigable,property_false);
		set_item_property('vh_ro_hold_up.ro_num',visible,property_true);
		set_item_property('vh_ro_hold_up.ro_date',visible,property_true);
		set_item_property('vh_ro_hold_up.promised_date',visible,property_true);
		set_item_property('vh_ro_hold_up.reason_desc',visible,property_true);
		set_item_property('vh_ro_hold_up.part_amt',visible,property_false);
		set_item_property('vh_ro_hold_up.labour_amt',visible,property_false);
		set_item_property('vh_ro_hold_up.bill_amt',visible,property_false);
		set_item_property('vh_ro_hold_up.ro_num',position,71,114);		
		set_item_property('vh_ro_hold_up.reg_num',position,159,114);
		set_item_property('vh_ro_hold_up.ro_date',position,256,114);				
		set_item_property('vh_ro_hold_up.model_desc',position,338,114);
		set_item_property('vh_ro_hold_up.promised_date',position,412,114);
		set_item_property('vh_ro_hold_up.reason_desc',position,513,114);
		set_item_property('vh_ro_hold_up.reg_num',width,95);
		set_item_property('vh_ro_hold_up.model_desc',width,74);	
			-------- ADDED START BY SANTOSH KUMAR AS ON DS-4704 DATED ON 27-JAN-2026
		set_item_property('vh_ro_hold_up.CEO_APPROVE_STATUS',visible,property_false);
		set_item_property('vh_ro_hold_up.ODOMETER_REASON',visible,property_false);
		set_item_property('vh_ro_hold_up.CEO_REMARKS',visible,property_false);
		-------- ENDED BY SANTOSH KUMAR AS ON DS-4704 DATED ON 27-JAN-2026 					
elsif :STATUS ='600' then	
		:CB_DUMMY.from_date := sysdate-1;
		:CB_DUMMY.to_date		:= sysdate-1;
		set_item_property('CB_DUMMY.TO_DATE',visible,property_true);
		set_item_property('CB_DUMMY.TO_DATE',ENABLED,property_true);
		set_item_property('CB_DUMMY.TO_DATE',navigable,property_true);
		set_item_property('vh_ro_hold_up.ro_num',visible,property_false);
		set_item_property('vh_ro_hold_up.ro_date',visible,property_false);
		set_item_property('vh_ro_hold_up.promised_date',visible,property_false);
		set_item_property('vh_ro_hold_up.reason_desc',visible,property_false);
		set_item_property('vh_ro_hold_up.part_amt',visible,property_true);
		set_item_property('vh_ro_hold_up.labour_amt',visible,property_true);
		set_item_property('vh_ro_hold_up.bill_amt',visible,property_true);
		set_item_property('vh_ro_hold_up.reg_num',position,71,114);
		set_item_property('vh_ro_hold_up.model_desc',position,210,114);				
		set_item_property('vh_ro_hold_up.part_amt',position,370,114);
		set_item_property('vh_ro_hold_up.labour_amt',position,470,114);
		set_item_property('vh_ro_hold_up.bill_amt',position,570,114);
		set_item_property('vh_ro_hold_up.reg_num',width,139);
		set_item_property('vh_ro_hold_up.model_desc',width,160);
			-------- ADDED START BY SANTOSH KUMAR AS ON DS-4704 DATED ON 27-JAN-2026
		set_item_property('vh_ro_hold_up.CEO_APPROVE_STATUS',visible,property_false);
		set_item_property('vh_ro_hold_up.ODOMETER_REASON',visible,property_false);
		set_item_property('vh_ro_hold_up.CEO_REMARKS',visible,property_false);
	 
elsif :STATUS ='800' then	
		:CB_DUMMY.from_date := sysdate-1;
		:CB_DUMMY.to_date		:= sysdate-1;		
	  set_item_property('CB_DUMMY.TO_DATE',visible,property_falsE);
		set_item_property('CB_DUMMY.TO_DATE',ENABLED,property_false);
		set_item_property('CB_DUMMY.TO_DATE',navigable,property_false);
		set_item_property('vh_ro_hold_up.ro_num',visible,property_true);
		set_item_property('vh_ro_hold_up.ro_date',visible,property_true);
		set_item_property('vh_ro_hold_up.promised_date',visible,property_true);
		set_item_property('vh_ro_hold_up.reason_desc',visible,property_false);
		set_item_property('vh_ro_hold_up.part_amt',visible,property_false);
		set_item_property('vh_ro_hold_up.labour_amt',visible,property_false);
		set_item_property('vh_ro_hold_up.bill_amt',visible,property_false);	
	  set_item_property('vh_ro_hold_up.CEO_APPROVE_STATUS',visible,property_true);
		set_item_property('vh_ro_hold_up.ODOMETER_REASON',visible,property_true);
		set_item_property('vh_ro_hold_up.CEO_REMARKS',visible,property_true);
    set_item_property('vh_ro_hold_up.ro_num',position,71,114);		
		set_item_property('vh_ro_hold_up.reg_num',position,159,114);
		set_item_property('vh_ro_hold_up.ro_date',position,256,114);				
		set_item_property('vh_ro_hold_up.model_desc',position,338,114);
		set_item_property('vh_ro_hold_up.promised_date',position,412,114);
		set_item_property('vh_ro_hold_up.reason_desc',position,513,114);
		set_item_property('vh_ro_hold_up.reg_num',width,95);
		set_item_property('vh_ro_hold_up.model_desc',width,74);	
		-------- ENDED BY SANTOSH KUMAR AS ON DS-4704 DATED ON 27-JAN-2026 
						
end if;	
END;
```

#### SP-002 - POPULATE_DETAILS

**Invoked From:**

- vi_ro_hold_up_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

Search Criteria (N/A / CN_MAIN)

---

**Purpose**

Retrieves repair order hold-up records from the database for the selected view type, populates the on-screen results grid row by row, looks up vehicle model and hold-reason descriptions for each record, and resets the grid to read-only after loading. Displays an informational message if no records are found, or an error message if an unexpected database error occurs.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-017](#SP-017--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)
- I.CREATED_DATE ([SP-020](#SP-020--I.CREATED_DATE)) - D2KWUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Temporarily unlock the results grid to allow data to be loaded into it.
- Step 2 - Clear any existing rows in the results grid and move to the first row.
- Step 3 - Determine the view type selected by the user (Non-B&P Hold-Up, B&P Hold-Up, Billing Variance, or Odometer Approval).
- Step 4 - Query the database using the cursor appropriate for the selected view type, filtering by dealer location, hold-up date, repair category, open status, and promised date.
- Step 5 - For each record retrieved, write all fields into the corresponding row of the results grid.
- Step 6 - For each row, look up the vehicle model description using the model code; if not found, display 'NA'.
- Step 7 - For each row, look up the hold-reason description using the reason code and type; if not found, display 'NA'. (For Billing Variance view, look up the service variant description instead. For Odometer Approval view, the reason lookup is skipped.)
- Step 8 - After loading all rows, return the cursor to the first record.
- Step 9 - Lock the results grid back to read-only (no insert, update, or delete allowed).
- Step 10 - If no records are found, display an informational message to the user.
- Step 11 - If any other unexpected error occurs, display an error message to the user.

---
**Decision Points**

DP-001

Condition:
Selected view type is Non-B&P Hold-Up (status 400)

TRUE:
Query hold-up records where repair category is not B&P, repair order is open, and promised date is on or before the selected date; look up hold-reason using type NBDR.

FALSE:
Proceed to evaluate the next view type condition.

---

DP-002

Condition:
Selected view type is B&P Hold-Up (status 500)

TRUE:
Query hold-up records where repair category is B&P, repair order is open, and promised date is on or before the selected date; look up hold-reason using type BDR.

FALSE:
Proceed to evaluate the next view type condition.

---

DP-003

Condition:
Selected view type is Billing Variance (status 600)

TRUE:
Query repair orders joined to dealer location master for 2S/3S dealer types, billed within the date range, with B&P category, where total bill amount exceeds 11,500; look up service variant description.

FALSE:
Proceed to evaluate the next view type condition.

---

DP-004

Condition:
Selected view type is Odometer Approval (status 800)

TRUE:
Query hold-up records joined to repair orders where the odometer change flag is Pending, Approved, or Rejected; populate CEO approval status, reason, and remarks fields; model description lookup is performed but hold-reason lookup is skipped.

FALSE:
End of view type branching; no data is loaded.

---

DP-005

Condition:
Model description is found in the model reference table for the current record

TRUE:
Display the model description in the model description field.

FALSE:
Display 'NA' in the model description field.

---

DP-006

Condition:
Hold-reason description is found in the hold-reason reference table for the current record (status 400 or 500)

TRUE:
Display the reason description in the reason description field.

FALSE:
Display 'NA' in the reason description field.

---

DP-007

Condition:
Service variant description is found in the service variant reference table for the current record (status 600)

TRUE:
Display the service variant description in the model description field.

FALSE:
Display 'NA' in the model description field.

---

DP-008

Condition:
A no-data-found exception is raised after the entire data load completes

TRUE:
Display an informational message: 'Data not available'.

FALSE:
No message is displayed.

---

DP-009

Condition:
An unexpected (OTHERS) exception is raised

TRUE:
Display an error message: 'Unable to populate' along with the error details.

FALSE:
Procedure completes normally.

---
**Database Interactions**

- DB-001 - Read MULDMS.VH_RO_HOLD_UP - Reads data from MULDMS.VH_RO_HOLD_UP for lookup or validation.
- DB-002 - Read MULDMS.VH_RO - Reads data from MULDMS.VH_RO for lookup or validation.
- DB-003 - Read GM_MOD - Reads data from GM_MOD for lookup or validation.
- DB-004 - Read VM_DREASON - Reads data from VM_DREASON for lookup or validation.
- DB-005 - Read VM_SVAR - Reads data from VM_SVAR for lookup or validation.
**Business Rules**

- BR-001 - Non-B&P hold-up records are those where the repair category is not 'BANDP', the repair order status is open (status 10), and the promised delivery date is on or before the selected hold-up date. Dealer code 99999 is excluded.
- BR-002 - B&P hold-up records are those where the repair category is 'BANDP', the repair order status is open (status 10), and the promised delivery date is on or before the selected hold-up date. Dealer code 99999 is excluded.
- BR-003 - Billing Variance records are repair orders billed within the selected date range for 2S or 3S dealer types where the repair category is 'BANDP', the repair order is in billed status (status 40), and the combined parts and labour amount exceeds 11,500.
- BR-004 - Odometer Approval records are hold-up records joined to their repair orders where the odometer change flag is one of: Pending ('Y'), Approved ('A'), or Rejected ('R').
- BR-005 - All queries are filtered by the current organisation's principal mapping code to support multi-organisation operation.
- BR-006 - If a vehicle model code cannot be matched in the model reference table, 'NA' is displayed as the model description.
- BR-007 - If a hold-reason code cannot be matched in the hold-reason reference table, 'NA' is displayed as the reason description.

---
**Implementation Logic**

```plsql
PROCEDURE populate_details IS
  cursor cur1 is 
  select parent_group,
       dealer_map_cd,
       loc_cd,
       hold_up_date,
       vin,
       ro_num,
       hold_reason,
       ro_status,
       rcateg_cd,
       reg_num,
       ro_date,
       promised_date,
       odometer_reading,
       model_code,
       created_date,
       comp_fa
  from muldms.vh_ro_hold_up 
  where dealer_map_cd = :cb_dummy.cb_dealer_map_cd
   and loc_cd = :cb_dummy.cb_loc_cd
   and hold_up_date = :cb_dummy.from_date
   and rcateg_cd != 'BANDP'
   and ro_status = 10
   and trunc(promised_date)    <= :cb_dummy.from_date
   and dealer_map_cd != 99999   ;

	cursor cur2 is 
  select parent_group,
       dealer_map_cd,
       loc_cd,
       hold_up_date,
       vin,
       ro_num,
       hold_reason,
       ro_status,
       rcateg_cd,
       reg_num,
       ro_date,
       promised_date,
       odometer_reading,
       model_code,
       created_date,
       comp_fa
  from muldms.vh_ro_hold_up 
  where dealer_map_cd = :cb_dummy.cb_dealer_map_cd
   and loc_cd = :cb_dummy.cb_loc_cd
   and hold_up_date = :cb_dummy.from_date
   and rcateg_cd = 'BANDP'
   and ro_status = 10
   and trunc(promised_date)    <= :cb_dummy.from_date
   and dealer_map_cd != 99999;
  
	cursor cur3 is 
		select vh.parent_group,
           vh.dealer_map_cd,
           vh.loc_cd,
       		 vh.ro_num,
		       vh.reg_num,
		       vh.ro_date,
		       vh.smodel_cd,
		       vh.part_amt,
		       vh.labour_amt,
		       vh.part_amt + vh.labour_amt bill_amt
	 	from   muldms.vh_ro vh, muldms.am_dealer_loc al
    where al.dealer_type in ('2S','3S')
      and al.dealer_map_cd = :cb_dummy.cb_dealer_map_cd
		  and  al.loc_cd        = :cb_dummy.cb_loc_cd
		  and  vh.dealer_map_cd = al.dealer_map_cd
		  and  vh.loc_cd        = al.loc_cd
		  and  vh.ro_date       >= :cb_dummy.from_date - 90
		  --and  vh.bill_date     >= trunc(:cb_dummy.from_date)
		  --and  vh.bill_date     <  trunc(:cb_dummy.to_date)
	    and  vh.bill_date     >= trunc(:cb_dummy.from_date)
		  and  vh.bill_date     <  trunc(:cb_dummy.to_date)+1		  
		  and  ro_status        = 40
		  and  rcateg_cd        = 'BANDP'
		  and  vh.dealer_map_cd != 99999
		  and  al.principal_map_cd = :GLOBAL.principal  -- PMC added by Abhishek for multi organization on 03-june-2014..
		  and  al.msil_terminated_date is null
		  and  (vh.part_amt + vh.labour_amt) > 11500;
  
 -------- ADDED START BY SANTOSH KUMAR AS ON DS-4704 DATED ON 27-JAN-2026

 	cursor cur4 is 
   select /*+ index (VH IDX_VH_RO) */
       UP.parent_group,
       UP.dealer_map_cd,
       UP.loc_cd,
       UP.hold_up_date,
       UP.vin,
       UP.ro_num,
       UP.hold_reason,
       UP.ro_status,
       UP.rcateg_cd,
       UP.reg_num,
       UP.ro_date,
       UP.promised_date,
       UP.odometer_reading,
       UP.model_code,
       UP.created_date,
       UP.comp_fa
       ,decode(vh.odometer_change,'Y', 'Approval Pending', 'A' , 'Approved', 'R', 'Rejected' ) CEO_APPROVE_STATUS
       , vh.ODOMETER_REASON CEO_Reason, vh.CEO_REMARKS 
  from muldms.vh_ro_hold_up  UP , VH_RO VH 
  where VH.PARENT_GROUP=UP.PARENT_GROUP
        AND VH.DEALER_MAP_CD=UP.DEALER_MAP_CD
        AND VH.LOC_CD=UP.LOC_CD
        AND VH.COMP_FA=UP.COMP_FA
        AND VH.RO_NUM=UP.RO_NUM
        and up.vin=vh.vin
        AND  UP.dealer_map_cd =  :cb_dummy.cb_dealer_map_cd
        and UP.loc_cd =  :cb_dummy.cb_loc_cd
        and UP.hold_up_date =  :cb_dummy.from_date
        and UP.rcateg_cd != 'BANDP'
        and UP.ro_status = 10
        and trunc(UP.promised_date)    <=  :cb_dummy.from_date
        and UP.dealer_map_cd != 99999   
        and NVL(vh.odometer_change,'N') IN ('Y','A','R')
        ; 
        -------- ENDED BY SANTOSH KUMAR AS ON DS-4704 DATED ON 27-JAN-2026

lv_srl_num number := 0;
  
begin
	  
  SET_BLOCK_PROPERTY('vh_ro_hold_up',insert_allowed,property_true);
  SET_BLOCK_PROPERTY('vh_ro_hold_up',update_allowed,property_true);
  SET_BLOCK_PROPERTY('vh_ro_hold_up',delete_allowed,property_true);
    
   if :status ='400' then    
				    go_block('vh_ro_hold_up');
				    clear_block;
				    first_record;
				    lv_srl_num := 0;
				    for i in cur1 loop
			      :vh_ro_hold_up.srl_num   				:= 		:system.cursor_record;
						:vh_ro_hold_up.parent_group			:=    i.parent_group;
						:vh_ro_hold_up.dealer_map_cd		:=    i.dealer_map_cd;
						:vh_ro_hold_up.loc_cd						:=    i.loc_cd;
						:vh_ro_hold_up.hold_up_date			:=    i.hold_up_date;
						:vh_ro_hold_up.vin							:=    i.vin;
						:vh_ro_hold_up.ro_num						:=    i.ro_num;
						:vh_ro_hold_up.hold_reason			:=    i.hold_reason;
						:vh_ro_hold_up.ro_status				:=    i.ro_status;
						:vh_ro_hold_up.rcateg_cd				:=    i.rcateg_cd;
						:vh_ro_hold_up.reg_num					:=    i.reg_num;
						:vh_ro_hold_up.ro_date					:=    i.ro_date;
						:vh_ro_hold_up.promised_date		:=    i.promised_date;
						:vh_ro_hold_up.odometer_reading	:=    i.odometer_reading;
						:vh_ro_hold_up.model_code				:=    i.model_code;
						:vh_ro_hold_up.created_date			:=    i.created_date;
						:vh_ro_hold_up.comp_fa					:=    i.comp_fa;
						
--------------------***--------------------------
				    begin
				    	begin
				    	select model_desc into :model_desc 
				    		from gm_mod
	     				 where model_cd = :vh_ro_hold_up.model_code
	     					 and principal_map_cd=:global.principal; -- PMC added by Abhishek for multi organization on 03-june-2014.
				    	exception when no_data_found then
				    		:model_desc := 'NA';
				    	end;
				    	
				      begin
								select reason_desc into :reason_desc from vm_dreason 
 	     					 where reason_type = 'NBDR'
           			   and flag = 'Y'		
           			   and principal_map_cd = :GLOBAL.principal  -- PMC added by Abhishek for multi organization on 03-june-2014..
           			   and reason_cd = :vh_ro_hold_up.hold_reason;
				    	exception when no_data_found then
				    		:reason_desc := 'NA';           			   
				    	end;
						end;
--------------------***--------------------------
				    
		      exit when cur1%notfound;
				      next_record;
				 END LOOP;
				 first_record;   
    elsif :status ='500' then    
				    go_block('vh_ro_hold_up');
				    clear_block;
				    first_record;
				    lv_srl_num := 0;
				    for i in cur2 loop
			      :vh_ro_hold_up.srl_num   				:= 		:system.cursor_record;
						:vh_ro_hold_up.parent_group			:=    i.parent_group;
						:vh_ro_hold_up.dealer_map_cd		:=    i.dealer_map_cd;
						:vh_ro_hold_up.loc_cd						:=    i.loc_cd;
						:vh_ro_hold_up.hold_up_date			:=    i.hold_up_date;
						:vh_ro_hold_up.vin							:=    i.vin;
						:vh_ro_hold_up.ro_num						:=    i.ro_num;
						:vh_ro_hold_up.hold_reason			:=    i.hold_reason;
						:vh_ro_hold_up.ro_status				:=    i.ro_status;
						:vh_ro_hold_up.rcateg_cd				:=    i.rcateg_cd;
						:vh_ro_hold_up.reg_num					:=    i.reg_num;
						:vh_ro_hold_up.ro_date					:=    i.ro_date;
						:vh_ro_hold_up.promised_date		:=    i.promised_date;
						:vh_ro_hold_up.odometer_reading	:=    i.odometer_reading;
						:vh_ro_hold_up.model_code				:=    i.model_code;
						:vh_ro_hold_up.created_date			:=    i.created_date;
						:vh_ro_hold_up.comp_fa					:=    i.comp_fa;
						
----------------------***----------------------------
				    begin
				    	begin
				    		select model_desc into :model_desc 
				    		  from gm_mod
	     					 where model_cd = :vh_ro_hold_up.model_code
	     					   and principal_map_cd = :GLOBAL.principal;  -- PMC added by Abhishek for multi organization on 03-june-2014..
				    	exception when no_data_found then
				    		:model_desc := 'NA';
				    	end;
				    	
				      begin
								select reason_desc into :reason_desc 
								from vm_dreason 
 	     					 where reason_type = 'BDR'
           			   and flag = 'Y'		
           			   and principal_map_cd = :GLOBAL.principal  -- PMC added by Abhishek for multi organization on 03-june-2014..
           			   and reason_cd = :vh_ro_hold_up.hold_reason;
				    	exception when no_data_found then
				    		:reason_desc := 'NA';           			   
				    	end;
						end;
----------------------***--------------------------					
			   exit when cur2%notfound;
				    next_record;
			  END LOOP;
				first_record;
    elsif :status ='600' then    
				    go_block('vh_ro_hold_up');
				    clear_block;
				    first_record;
				    lv_srl_num := 0;
				    for i in cur3 loop
			      :vh_ro_hold_up.srl_num   				:= 		:system.cursor_record;
						:vh_ro_hold_up.parent_group			:=    i.parent_group;
						:vh_ro_hold_up.dealer_map_cd		:=    i.dealer_map_cd;
						:vh_ro_hold_up.loc_cd						:=    i.loc_cd;
						:vh_ro_hold_up.ro_num						:=    i.ro_num;
						:vh_ro_hold_up.reg_num					:=    i.reg_num;
						:vh_ro_hold_up.ro_date					:=    i.ro_date;
						:vh_ro_hold_up.svar_cd          :=    i.smodel_cd;
						:vh_ro_hold_up.part_amt					:=		i.part_amt;
		        :vh_ro_hold_up.labour_amt				:=		i.labour_amt;
		        :vh_ro_hold_up.bill_amt					:= 		i.bill_amt;
		       
				    	begin
				    		select svar_desc into :model_desc 
				    		  from vm_svar
	     					 where svar_cd = :vh_ro_hold_up.svar_cd
	     					   and principal_map_cd = :GLOBAL.principal ; -- PMC added by Abhishek for multi organization on 03-june-2014..
				    	exception when no_data_found then
				    		:model_desc := 'NA';
				    	end;
				    	
			   exit when cur3%notfound;
				    next_record;
			  END LOOP;
				first_record;
				
	-------- ADDED START BY SANTOSH KUMAR AS ON DS-4704 DATED ON 27-JAN-2026
  	elsif :status ='800' then    
		  go_block('vh_ro_hold_up');
				    clear_block;
				    first_record;
				    lv_srl_num := 0;
				    for i in cur4 loop
			      :vh_ro_hold_up.srl_num   				:= 		:system.cursor_record;
						:vh_ro_hold_up.parent_group			:=    i.parent_group;
						:vh_ro_hold_up.dealer_map_cd		:=    i.dealer_map_cd;
						:vh_ro_hold_up.loc_cd						:=    i.loc_cd;
						:vh_ro_hold_up.hold_up_date			:=    i.hold_up_date;
						:vh_ro_hold_up.vin							:=    i.vin;
						:vh_ro_hold_up.ro_num						:=    i.ro_num;
						:vh_ro_hold_up.hold_reason			:=    i.hold_reason;
						:vh_ro_hold_up.ro_status				:=    i.ro_status;
						:vh_ro_hold_up.rcateg_cd				:=    i.rcateg_cd;
						:vh_ro_hold_up.reg_num					:=    i.reg_num;
						:vh_ro_hold_up.ro_date					:=    i.ro_date;
						:vh_ro_hold_up.promised_date		:=    i.promised_date;
						:vh_ro_hold_up.odometer_reading	:=    i.odometer_reading;
						:vh_ro_hold_up.model_code				:=    i.model_code;
						:vh_ro_hold_up.created_date			:=    i.created_date;
						:vh_ro_hold_up.comp_fa					:=    i.comp_fa;
						
						:vh_ro_hold_up.CEO_APPROVE_STATUS:=   i.CEO_APPROVE_STATUS;
						:vh_ro_hold_up.ODOMETER_REASON	:=    i.CEO_Reason;
						:vh_ro_hold_up.CEO_REMARKS			:=    i.CEO_REMARKS;
						
						
						
--------------------***--------------------------
				    begin
				    	begin
				    	select model_desc into :model_desc 
				    		from gm_mod
	     				 where model_cd = :vh_ro_hold_up.model_code
	     					 and principal_map_cd=:global.principal; -- PMC added by Abhishek for multi organization on 03-june-2014.
				    	exception when no_data_found then
				    		:model_desc := 'NA';
				    	end;
				    	
				      /*begin
								select reason_desc into :reason_desc from vm_dreason 
 	     					 where reason_type = 'NBDR'
           			   and flag = 'Y'		
           			   and principal_map_cd = :GLOBAL.principal  -- PMC added by Abhishek for multi organization on 03-june-2014..
           			   and reason_cd = :vh_ro_hold_up.hold_reason;
				    	exception when no_data_found then
				    		:reason_desc := 'NA';           			   
				    	end;*/
						end;
--------------------***--------------------------
				    
		      exit when cur4%notfound;
				      next_record;
				      END LOOP;
				 first_record;   
				-------- ENDED BY SANTOSH KUMAR AS ON DS-4704 DATED ON 27-JAN-2026
end if;	
  SET_BLOCK_PROPERTY('vh_ro_hold_up',insert_allowed,property_false);
  SET_BLOCK_PROPERTY('vh_ro_hold_up',update_allowed,property_false);
  SET_BLOCK_PROPERTY('vh_ro_hold_up',delete_allowed,property_false);
EXCEPTION
	when no_data_found then 
 		general.disp_text('Data not available ' ,'Note');
  WHEN OTHERS THEN
    general.disp_text('Unable to populate' || SQLERRM, 'Error');
END;
```

#### SP-003 - D2KWUTIL.ATTEMPT_DLL_LOAD

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Attempts to load a specified DLL into memory via ORA_FFI, optionally verifying the file's physical existence at a given path before loading. If a target path is supplied, the procedure normalises the directory separator using STRIPDIRSEP, confirms the file is accessible, and then loads the library. It also maintains a package-level load counter and an API-availability flag to reflect the outcome of the load attempt to the wider D2KWUTIL framework.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |
| TargetDLL | VARCHAR2 | IN |
| LoadCount | BOOLEAN | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |

---

**Dependencies**

- DEBUGLOG ([SP-077](#SP-077--DEBUGLOG)) - matched by member name
- STRIPDIRSEP ([SP-084](#SP-084--STRIPDIRSEP)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate whether TargetPath is non-null; if it is null, skip file-existence validation and proceed directly to the library load.
- Step 2 - Normalise TargetPath by calling STRIPDIRSEP to remove any trailing directory separator, then append a single backslash ('\'), ensuring a consistent, well-formed path regardless of how the caller supplied it.
- Step 3 - Attempt to open the file identified by the concatenation of TargetPath and TargetDLL in read mode using TEXT_IO.FOPEN; if successful, immediately close the file handle with TEXT_IO.FCLOSE to confirm physical existence without retaining a lock.
- Step 4 - If the file-open attempt raises any exception, invoke DEBUGLOG (Win_API_Debug.DebugLog) at severity level 99, logging the procedure name 'Attempt_DLL_LOAD' and a message identifying the DLL and the path where it was not found, then raise the BadLocation exception to abort processing.
- Step 5 - Call ORA_FFI.LOAD_LIBRARY with TargetPath and TargetDLL to load the DLL into memory and capture the resulting library handle in hDLL.
- Step 6 - If the LoadCount flag is TRUE, increment the package-level counter DLL_LOAD_COUNT by 1 and set the package-level flag API_ENABLED to TRUE, recording a successful load.
- Step 7 - Return hDLL to the caller.
- Step 8 - If any unhandled exception occurs during the load phase, set API_ENABLED to FALSE and return the null hDLL handle to the caller, signalling a failed load without propagating the exception.

---
**Decision Points**

DP-001

Condition: TargetPath IS NOT NULL

TRUE: Normalise the path via STRIPDIRSEP, append a backslash, and perform a physical file-existence check before attempting the DLL load.

FALSE: Skip path normalisation and file-existence validation; proceed directly to ORA_FFI.LOAD_LIBRARY using the null path.

---

DP-002

Condition: TEXT_IO.FOPEN succeeds for the concatenated path and DLL filename.

TRUE: Close the file handle and continue to the ORA_FFI.LOAD_LIBRARY call.

FALSE: Log the missing-file error via DEBUGLOG at severity 99 and raise the BadLocation exception, halting further processing.

---

DP-003

Condition: LoadCount parameter is TRUE after a successful ORA_FFI.LOAD_LIBRARY call.

TRUE: Increment DLL_LOAD_COUNT by 1 and set API_ENABLED to TRUE.

FALSE: Return hDLL without updating DLL_LOAD_COUNT or API_ENABLED.

---

DP-004

Condition: An unhandled exception is raised during the ORA_FFI.LOAD_LIBRARY phase or any subsequent step.

TRUE: Set API_ENABLED to FALSE and return the null hDLL handle to the caller.

FALSE: Normal execution path; hDLL is returned with the loaded library handle.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - If a TargetPath is provided, it must be normalised to a single trailing backslash before use; STRIPDIRSEP is always called to strip any existing trailing separator prior to appending '\', preventing malformed paths caused by duplicate or missing separators.
- BR-002 - A physical file-existence check must be performed whenever TargetPath is non-null; the DLL file must be openable in read mode at the resolved path before any load attempt is made.
- BR-003 - If the DLL file cannot be found at the specified location, the event must be logged via DEBUGLOG at severity level 99 with the DLL name and the attempted path, and the BadLocation exception must be raised to prevent a load attempt against an invalid location.
- BR-004 - Only one path value may be used; if the caller supplies multiple paths in TargetPath, only the first path (as processed by STRIPDIRSEP) is used and the remainder are discarded.
- BR-005 - The package-level counter DLL_LOAD_COUNT must be incremented and API_ENABLED set to TRUE only when a load succeeds and the LoadCount parameter is TRUE, ensuring the counter accurately reflects deliberate, tracked load operations.
- BR-006 - On any load failure, API_ENABLED must be set to FALSE and a null library handle returned; the exception must not propagate to the caller, allowing the caller to handle the failure gracefully.

---
**Implementation Logic**

```plsql

FUNCTION  Attempt_DLL_Load  (TargetPath in out VARCHAR2, TargetDLL in VARCHAR2, LoadCount in BOOLEAN DEFAULT TRUE) return ORA_FFI.LibHandleType is
  hDLL  ORA_FFI.LibHandleType;
  hFile TEXT_IO.FILE_TYPE;
begin 
    	
  if TargetPath is not null then 
    -- Watch out for folks who put multiple Paths in here 
    -- Oh yes it's happened! Just use the first & throw the rest away
    -- Add trailing Directory Sep if required
    TargetPath := StripDirSep(TargetPath)||'\';
    
    -- Check that there is actually a file there.
    begin 
  	  hFile := TEXT_IO.FOPEN(TargetPath||TargetDLL,'R');
  	  TEXT_IO.FCLOSE(hFile);
    exception
  	  when others then
  	    Win_API_Debug.DebugLog(99,'Attempt_DLL_LOAD',TargetDLL||' not found in the specified location of "'||TargetPath||'"'); 
  		  raise BadLocation;
    end;
  end if;
  
  hDLL := ORA_FFI.LOAD_LIBRARY(TargetPath, TargetDLL);
  if LoadCount then 
    DLL_LOAD_COUNT  := DLL_LOAD_COUNT + 1;
    API_ENABLED  := TRUE;
  end if;
  return hDLL;
exception
  when others then 
    API_ENABLED := FALSE;
    return hDLL; /* Will be null */
end Attempt_DLL_Load;
```

#### SP-004 - D2KWUTIL.CHOOSEFILE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.SAVE_FILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Presents the operating system's standard file-selection dialog to the user (either an Open File or Save File dialog), captures the selected file path, and returns it to the caller. Handles modal/non-modal presentation, directory resolution for special paths, and file-filter defaults.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| CalledBy | VARCHAR2 | IN |
| Modal | BOOLEAN | IN |
| szTitle | VARCHAR2 | IN |
| szInitDir | VARCHAR2 | IN |
| szFileFilter | VARCHAR2 | IN |
| Flags | PLS_INTEGER | IN |
| SepChar | VARCHAR2 | IN |
| szBuffer | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| szBuffer | VARCHAR2 | IN OUT |

---

**Dependencies**

- ADD_ERROR ([SP-073](#SP-073--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-074](#SP-074--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-075](#SP-075--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-076](#SP-076--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_CHOOSEFILE ([SP-006](#SP-006--D2KWUTIL.D2KWUTIL_CHOOSEFILE)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- D2KWUTIL.GET_ACTIVE_WINDOW ([SP-013](#SP-013--D2KWUTIL.GET_ACTIVE_WINDOW)) - D2KWUTIL.pck (or .pld)
- DEBUGLOG ([SP-077](#SP-077--DEBUGLOG)) - matched by member name
- GET_TEMP_DIRECTORY ([SP-079](#SP-079--GET_TEMP_DIRECTORY)) - matched by member name
- GET_WINDOWS_DIRECTORY ([SP-080](#SP-080--GET_WINDOWS_DIRECTORY)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-082](#SP-082--REGISTER_FUNCTION_CALL)) - matched by member name
- WEBUTIL.LENGTH ([SP-056](#SP-056--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Log the incoming parameters for diagnostics, then clear any prior error state.
- Step 2 - If the dialog is to be modal, retrieve the current active window handle; otherwise use a null owner handle.
- Step 3 - Verify that the Win32 API bridge is available; if not, raise a NOT_AVAILABLE error.
- Step 4 - Register the underlying file-dialog function, then map the caller type ('Open_File' vs. 'Save File') to the appropriate dialog type code.
- Step 5 - Resolve the initial directory: if the caller specified the Windows directory or the Temp directory token, substitute the actual path; otherwise use the supplied directory. Ensure the path ends with a backslash.
- Step 6 - Apply a default file filter ('All files') if none was supplied.
- Step 7 - Invoke the native file-dialog function and capture the user's selected file path.
- Step 8 - Return the result code and the selected file path to the caller; on any error, add an error entry and re-raise.

---
**Decision Points**

DP-001

Condition:
The dialog is requested to be modal

TRUE:
Retrieve the active window handle to use as the owner of the dialog.

FALSE:
Use a null (zero) owner handle, making the dialog modeless.

---

DP-002

Condition:
The Win32 API bridge is enabled (API_ENABLED)

TRUE:
Proceed to register and invoke the native file-dialog function.

FALSE:
Raise a NOT_AVAILABLE exception; add an error entry and re-raise.

---

DP-003

Condition:
The caller type is 'Open_File'

TRUE:
Set the dialog type code to 1 (Open File dialog).

FALSE:
Set the dialog type code to 2 (Save File dialog).

---

DP-004

Condition:
The initial directory token is '$WINDIR$'

TRUE:
Substitute with the actual Windows directory path.

FALSE:
Evaluate the next token condition.

---

DP-005

Condition:
The initial directory token is '$TEMP$'

TRUE:
Substitute with the actual Temp directory path.

FALSE:
Use the supplied directory as-is.

---

DP-006

Condition:
The file filter parameter is null or empty

TRUE:
Apply the default filter 'All files(*.*)|*.*|'.

FALSE:
Use the supplied file filter.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file-selection dialog requires the Win32 API bridge to be active; if it is unavailable, the function raises an error and cannot present the dialog.
- BR-002 - If no file filter is specified by the caller, all files ('*.*') are shown by default.
- BR-003 - Special directory tokens '$WINDIR$' and '$TEMP$' are resolved to their actual system paths at runtime.

---
**Implementation Logic**

```plsql
    
FUNCTION ChooseFile(  CalledBy      IN      VARCHAR2,
                      Modal         IN      BOOLEAN,
                      szTitle       IN      VARCHAR2,
                      szInitDir     IN      VARCHAR2,
                      szFileFilter  IN      VARCHAR2,
                      Flags         IN      PLS_INTEGER,
                      SepChar       IN      VARCHAR2,
                      szBuffer      IN OUT  VARCHAR2 ) RETURN PLS_INTEGER is
  hwndOwner  PLS_INTEGER;
  iBuff1     PLS_INTEGER;
  iBuff2     PLS_INTEGER;
  iRC        PLS_INTEGER;
  vcBuff1    VARCHAR2(255);
  vcBuff2    VARCHAR2(2000);
  vcBuff3    VARCHAR2(100);
  vcBuff4    VARCHAR2(1);
  vcBuff5    VARCHAR2(4096);
begin 
  Win_API_Debug.DebugLog(99,'ChooseFile','Args: CalledBy="'||CalledBy||', Modal='||win_api_debug.BoolToChar(Modal)||', szTitle="'||szTitle||'", szInitDir="'||szInitDir||'", szFileFilter="'||szFileFilter||'", Flags='||to_char(flags)||', SepChar="'||SepChar||'", szBuffer="'||szBuffer||'"');	
  Win_API.Clean_Error_Stack;
  iRC  := 0;
  if Modal then 
    hwndOwner := win_api_utility.get_active_window;
  else
    hwndOwner := 0;
  end if;

  if Win_API.API_ENABLED then 
      win_api.Register_function_call(iChooseFile,'d2kwutil_ChooseFile','INT','INT,SHORT,*CHAR,*CHAR,*CHAR,LONG,CHAR,*CHAR');

      if CalledBy = 'Open_File' then
        iBuff1     := 1;
      else
        iBuff1    := 2;
      end if;
      iBuff2    := Flags;
      vcBuff1    := szTitle;
      
      if upper(szInitDir) = '$WINDIR$' then 
        vcBuff2 := win_api_environment.get_windows_directory;
      elsif  upper(szInitDir) = '$TEMP$' then 
        vcBuff2 := win_api_environment.get_temp_directory;
      else 
        vcBuff2 := szInitDir;
      end if;
      
      if substr(vcBuff2,length(vcBuff2),1) <> '\' then 
        vcBuff2 := vcBuff2||'\';
      end if;
      
      if szFileFilter = NULL or szFileFilter = '' then 
        vcBuff3 := 'All files(*.*)|*.*|';
      else
        vcBuff3 := szFileFilter;
      end if;
      vcBuff4 := substr(SepChar,1,1);
      vcBuff5 := RPAD(szBuffer,4096,CHR(0)); 
      
      iRC := d2kwutil_choosefile (win_api.FunctionHandle(iChoosefile),iBuff1,hwndOwner,vcBuff1,vcBuff2,vcBuff3,iBuff2,vcBuff4,vcBuff5);
      Win_API_Debug.DebugLog(99,'ChooseFile','Result: RC='||to_char(iRC)||', szBuffer="'||vcBuff5||'"');
      szBuffer := vcBuff5;
      return iRC;
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
exception
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error(CalledBy,Win_API.NoAPI);
    raise;
  when others then
    Win_API.Add_error(CalledBy, Win_API.UError||WIN_API.Add_External_errors); 
    raise;  
end Choosefile;
```

#### SP-005 - D2KWUTIL.D2KWUTIL_ACTIVEWIN

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Low-level Win32 API wrapper that retrieves the handle of the currently active window. This is a specification-only entry point - no implementation body is present; the actual work is performed by the native D2KWUTIL library on the client workstation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept a registered function handle for the native D2KWUTIL library entry point.
- Step 2 - Invoke the native library function and return the active window handle as an integer.

---
**Decision Points**

No conditional branches - specification-only function with no implementation body available.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - No form-specific business rules - low-level Win32 API specification wrapper with no body.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.
FUNCTION d2kwutil_ActiveWin(  hFunc          IN      ORA_FFI.funcHandleType) return PLS_INTEGER;
```

#### SP-006 - D2KWUTIL.D2KWUTIL_CHOOSEFILE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Low-level Win32 API wrapper that invokes the operating system's native Open or Save file-selection dialog. This is a specification-only entry point - the actual dialog is rendered by the D2KWUTIL client-side library.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| dialog_type | PLS_INTEGER | IN |
| hwndOwner | PLS_INTEGER | IN |
| szTitle | VARCHAR2 | IN OUT |
| szInitDir | VARCHAR2 | IN OUT |
| szFileFilter | VARCHAR2 | IN OUT |
| AdvancedFlags | PLS_INTEGER | IN |
| SepChar | VARCHAR2 | IN |
| szBuffer | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| szTitle | VARCHAR2 | IN OUT |
| szInitDir | VARCHAR2 | IN OUT |
| szFileFilter | VARCHAR2 | IN OUT |
| szBuffer | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept a registered function handle, dialog type, owner window handle, title, initial directory, file filter, advanced flags, separator character, and a file path buffer.
- Step 2 - Invoke the native library function and return the selected file path in the buffer along with a result code.

---
**Decision Points**

No conditional branches - specification-only function with no implementation body available.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - No form-specific business rules - low-level Win32 API specification wrapper with no body.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

 FUNCTION d2kwutil_ChooseFile (   hFunc         IN      ORA_FFI.funcHandleType,
                                  dialog_type   IN      PLS_INTEGER,
                                  hwndOwner     IN      PLS_INTEGER,
                                  szTitle       IN OUT  VARCHAR2,
                                  szInitDir     IN OUT  VARCHAR2,
                                  szFileFilter  IN OUT  VARCHAR2,
                                  AdvancedFlags IN      PLS_INTEGER,
                                  SepChar       IN      VARCHAR2,
                                  szBuffer      IN OUT  VARCHAR2) return PLS_INTEGER;
```

#### SP-007 - D2KWUTIL.D2KWUTIL_DEBUGSTRING

**Invoked From:**

- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level foreign-function interface (FFI) bridge that passes a debug text string to an external C routine within the D2KWUTIL library. It is invoked by the WINDEBUG stored procedure to relay diagnostic or debug messages from the Oracle Forms PL/SQL layer to the underlying C implementation identified by the supplied function handle.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the external C function handle (hFunc) that identifies the target debug-string routine within the D2KWUTIL shared library.
- Step 2 - Receive the debug text string (Text) to be transmitted to the external routine.
- Step 3 - Delegate execution to the bound C function via the ORA_FFI PRAGMA INTERFACE mechanism (interface code 11265), passing both hFunc and Text directly to the native library.

---
**Decision Points**

No conditional decision points are present in this procedure. Execution follows a single, unconditional delegation path to the external C function via the ORA_FFI interface.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must be called with a valid ORA_FFI function handle (hFunc) that has been pre-registered against the D2KWUTIL C library; no internal validation of the handle is performed within this procedure.
- BR-002 - The Text parameter must be a VARCHAR2 value; the procedure imposes no additional length or content constraints beyond the data type.
- BR-003 - All execution is delegated to the external C implementation via PRAGMA INTERFACE (interface code 11265); no PL/SQL-level processing, transformation, or error handling is applied to the inputs.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.
   
 PROCEDURE d2kwutil_DebugString (    hFunc       IN      ORA_FFI.funcHandleType,
                                     Text        IN      VARCHAR2);
 -- Pragmas
 PRAGMA INTERFACE(C,d2kwutil_DebugString,      11265);
```

#### SP-008 - D2KWUTIL.D2KWUTIL_FILEINFO

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.FILE_INFO]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Low-level Win32 API wrapper that retrieves file metadata (such as creation date, size, and attributes) for a given file path. This is a specification-only entry point - the actual metadata retrieval is performed by the native D2KWUTIL client-side library.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| FileName | VARCHAR2 | IN OUT |
| Option1 | PLS_INTEGER | IN |
| Option2 | PLS_INTEGER | IN |
| dwOut1 | PLS_INTEGER | IN OUT |
| dwOut2 | PLS_INTEGER | IN OUT |
| dwOut3 | PLS_INTEGER | IN OUT |
| dwOut4 | PLS_INTEGER | IN OUT |
| dwOut5 | PLS_INTEGER | IN OUT |
| dwOut6 | PLS_INTEGER | IN OUT |
| dwOut7 | PLS_INTEGER | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| FileName | VARCHAR2 | IN OUT |
| dwOut1 | PLS_INTEGER | IN OUT |
| dwOut2 | PLS_INTEGER | IN OUT |
| dwOut3 | PLS_INTEGER | IN OUT |
| dwOut4 | PLS_INTEGER | IN OUT |
| dwOut5 | PLS_INTEGER | IN OUT |
| dwOut6 | PLS_INTEGER | IN OUT |
| dwOut7 | PLS_INTEGER | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept a registered function handle, the file path, option flags, and output buffer variables.
- Step 2 - Invoke the native library function and populate the output buffer variables with the requested file metadata.

---
**Decision Points**

No conditional branches - specification-only function with no implementation body available.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - No form-specific business rules - low-level Win32 API specification wrapper with no body.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.
                                                                                                                                                         
FUNCTION d2kwutil_FileInfo ( hFunc      IN      ORA_FFI.funcHandleType,
                             FileName   IN OUT  VARCHAR2,
                             Option1    IN      PLS_INTEGER,
                             Option2    IN      PLS_INTEGER,
                             dwOut1     IN OUT  PLS_INTEGER,
                             dwOut2     IN OUT  PLS_INTEGER,
                             dwOut3     IN OUT  PLS_INTEGER,
                             dwOut4     IN OUT  PLS_INTEGER,
                             dwOut5     IN OUT  PLS_INTEGER,
                             dwOut6     IN OUT  PLS_INTEGER,
                             dwOut7     IN OUT  PLS_INTEGER
                           ) return PLS_INTEGER;
```

#### SP-009 - D2KWUTIL.D2KWUTIL_GETDOSENV

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level Foreign Function Interface (FFI) wrapper that retrieves a DOS/operating-system environment variable value. Given a function handle and a source environment variable name, the routine delegates the call to the underlying OS via ORA_FFI and returns the expanded (resolved) value of the environment variable in the ExpandStr output parameter, along with a PLS_INTEGER return code indicating the outcome of the operation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| SourceStr | VARCHAR2 | IN OUT |
| ExpandStr | VARCHAR2 | IN OUT |
| InBuffLen | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| SourceStr | VARCHAR2 | IN OUT |
| ExpandStr | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that identifies the pre-registered external OS function to be invoked.
- Step 2 - Accept the source environment variable name (SourceStr) as the lookup key to be resolved by the OS.
- Step 3 - Accept the pre-allocated output buffer (ExpandStr) and its declared maximum length (InBuffLen) to hold the resolved environment variable value.
- Step 4 - Delegate execution to the external OS function via the ORA_FFI mechanism using the supplied hFunc handle, passing SourceStr and ExpandStr by reference alongside the buffer length.
- Step 5 - Return a PLS_INTEGER result code reflecting the success or failure of the environment variable retrieval, with the resolved value populated in ExpandStr upon success.

---
**Decision Points**

No explicit conditional decision points are determinable from the available source; only the function specification/declaration is present and no PL/SQL body has been resolved. The implicit decision is handled by the ORA_FFI layer: if the external OS call succeeds, ExpandStr is populated with the resolved environment variable value and a success code is returned; if it fails, the return code reflects the failure and ExpandStr may remain unchanged.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The caller must supply a valid, pre-registered ORA_FFI function handle (hFunc); the routine does not perform handle registration itself.
- BR-002 - SourceStr must contain the name of the OS environment variable to be resolved; it is passed IN OUT, allowing the external function to modify it if required by the FFI contract.
- BR-003 - InBuffLen must accurately reflect the allocated size of the ExpandStr buffer to prevent buffer overrun when the OS writes the expanded environment variable value.
- BR-004 - The routine is intended to be invoked exclusively through its parent caller, D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING], and should not be called directly from application screens or other procedures.
- BR-005 - The function returns a PLS_INTEGER result code; the caller (GET_ENVIRONMENT_STRING) is responsible for interpreting this code and handling any error conditions.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_GetDOSEnv (   hFunc          IN      ORA_FFI.funcHandleType,
                                SourceStr      IN OUT  VARCHAR2,
                                ExpandStr      IN OUT  VARCHAR2,
                                InBuffLen      IN      PLS_INTEGER
                                ) RETURN PLS_INTEGER;
```

#### SP-010 - D2KWUTIL.D2KWUTIL_GETREGKEY

**Invoked From:**

- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

D2KWUTIL_GETREGKEY is a foreign-function interface (FFI) wrapper function that retrieves a Windows Registry key value. It accepts a registry root, path, entry name, and buffer-size constraints, then populates the RegValue output parameter with the corresponding registry value. The function returns a PLS_INTEGER status code indicating the outcome of the registry read operation. It is invoked by the READ_REGISTRY stored procedure within D2kwutil.pld.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| RegRoot | PLS_INTEGER | IN |
| RegPath | VARCHAR2 | IN OUT |
| RegEntry | VARCHAR2 | IN OUT |
| RegValue | VARCHAR2 | IN OUT |
| RegValueLength | PLS_INTEGER | IN |
| RegDontExpand | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RegPath | VARCHAR2 | IN OUT |
| RegEntry | VARCHAR2 | IN OUT |
| RegValue | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that references the underlying native Windows API call responsible for reading the registry.
- Step 2 - Accept the registry root identifier (RegRoot) that specifies the top-level registry hive (e.g., HKEY_LOCAL_MACHINE, HKEY_CURRENT_USER) to be queried.
- Step 3 - Accept the registry path (RegPath) and registry entry name (RegEntry) as IN OUT parameters that identify the exact registry key and value name to be read.
- Step 4 - Accept RegValueLength to define the maximum buffer size allowed for the returned registry value, preventing buffer overflows.
- Step 5 - Accept RegDontExpand to control whether environment-variable references embedded in the registry value string are expanded before being returned.
- Step 6 - Execute the FFI call via the provided hFunc handle, passing all parameters to the native Windows registry API.
- Step 7 - Populate the RegValue IN OUT parameter with the retrieved registry value string.
- Step 8 - Return a PLS_INTEGER status code to the caller (READ_REGISTRY) indicating success or failure of the registry read operation.

---
**Decision Points**

DP-001

Condition: Whether RegDontExpand is set to a non-zero value.

TRUE: Environment-variable references within the retrieved registry value string are returned unexpanded (raw string as stored in the registry).

FALSE: Environment-variable references within the retrieved registry value string are expanded by the underlying Windows API before the value is returned in RegValue.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be invoked with a valid FFI function handle (hFunc); this handle is the mechanism by which the PL/SQL layer delegates execution to the native Windows registry API.
- BR-002 - RegRoot must correspond to a valid Windows registry hive constant; the function does not validate or default this value internally.
- BR-003 - The length of the value written to RegValue must not exceed the buffer size specified by RegValueLength; callers are responsible for supplying an adequate buffer length.
- BR-004 - RegPath and RegEntry are declared IN OUT, meaning the underlying FFI call may normalise or modify these values; callers must not assume they are unchanged after invocation.
- BR-005 - The function returns a PLS_INTEGER status code; the calling routine (READ_REGISTRY) is responsible for interpreting this code to determine whether the registry read succeeded or failed.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_GetRegKey (    hFunc         IN      ORA_FFI.funcHandleType,
                                RegRoot        IN      PLS_INTEGER,
                                RegPath        IN OUT  VARCHAR2,
                                RegEntry       IN OUT  VARCHAR2,
                                RegValue       IN OUT  VARCHAR2,
                                RegValueLength IN      PLS_INTEGER,
                                RegDontExpand	 IN      PLS_INTEGER
                                ) return PLS_INTEGER;
```

#### SP-011 - D2KWUTIL.D2KWUTIL_WINDIR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level foreign-function interface (FFI) wrapper that retrieves a Windows directory path (either the Windows system directory or a temporary directory, depending on the calling context) by invoking a native OS function handle. The result is returned via the IN OUT parameter WindowsDir, and a PLS_INTEGER status code is returned by the function. It is called exclusively by GET_TEMP_DIRECTORY and GET_WINDOWS_DIRECTORY within D2kwutil.pld.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| WindowsDir | VARCHAR2 | IN OUT |
| InBuffLen | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| WindowsDir | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the native function handle (hFunc) identifying the specific OS-level directory-retrieval function to invoke, the pre-allocated output buffer (WindowsDir), and the buffer length (InBuffLen).
- Step 2 - Delegate execution to the native OS function referenced by hFunc, passing WindowsDir as the target buffer and InBuffLen as its maximum capacity, via the ORA_FFI foreign-function interface.
- Step 3 - Allow the OS function to populate WindowsDir in-place with the resolved directory path (Windows directory or temporary directory, as determined by the caller).
- Step 4 - Return a PLS_INTEGER status code to the caller indicating the outcome of the native function call (typically the number of characters written or an OS error code).

---
**Decision Points**

No conditional decision points are present in the available implementation. The function acts as a direct FFI pass-through; all branching logic based on the returned status code is handled by the invoking procedures GET_TEMP_DIRECTORY and GET_WINDOWS_DIRECTORY.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be invoked with a valid ORA_FFI function handle (hFunc); the handle determines which OS directory path is retrieved and must be initialised by the calling procedure before this function is called.
- BR-002 - The caller is responsible for supplying a WindowsDir buffer sized to at least InBuffLen characters to prevent truncation of the returned directory path.
- BR-003 - The function returns a PLS_INTEGER status code; the calling procedure (GET_TEMP_DIRECTORY or GET_WINDOWS_DIRECTORY) is responsible for interpreting and acting on this value.
- BR-004 - This function has no direct database interactions; all data exchange occurs exclusively through the OS via the ORA_FFI mechanism.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_WinDir (      hFunc          IN      ORA_FFI.funcHandleType,
                                WindowsDir     IN OUT  VARCHAR2,
                                InBuffLen      IN      PLS_INTEGER
                                ) RETURN PLS_INTEGER;
```

#### SP-012 - D2KWUTIL.FILE_INFO

**Invoked From:**

- D2kwutil.pld [StoredProcedure: I.CREATED_DATE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves file metadata from the operating system for a specified file by invoking the native D2KWUTIL library. Returns up to seven numeric output values (such as file size, timestamps, and attributes) and optionally raises an exception if the file does not exist or if an error occurs.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| CalledBy | VARCHAR2 | IN |
| FileName | VARCHAR2 | IN |
| Option1 | PLS_INTEGER | IN |
| Option2 | PLS_INTEGER | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-073](#SP-073--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-074](#SP-074--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-075](#SP-075--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-076](#SP-076--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_FILEINFO ([SP-008](#SP-008--D2KWUTIL.D2KWUTIL_FILEINFO)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-077](#SP-077--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-082](#SP-082--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log the input parameters and clear the error stack.
- Step 2 - Verify that the Win32 API bridge is available; if not, raise a NOT_AVAILABLE error.
- Step 3 - Register the native file-information function and invoke it with the file path and option flags.
- Step 4 - Evaluate the return code: if the file does not exist (specific error codes), record an error and optionally raise an exception; if the call fails for another reason, record the system error and optionally raise an exception.
- Step 5 - On any unhandled exception, record the error and re-raise.

---
**Decision Points**

DP-001

Condition:
The Win32 API bridge is enabled (API_ENABLED)

TRUE:
Register and invoke the native file-information function.

FALSE:
Raise a NOT_AVAILABLE exception.

---

DP-002

Condition:
Return code indicates the file does not exist (0, -1074255551, or -1074245406)

TRUE:
Record a 'File does not exist' error; if RaiseExceptions is true, raise NO_DATA_FOUND.

FALSE:
Evaluate the next return code condition.

---

DP-003

Condition:
Return code is not 1 (success) and not a 'not found' code

TRUE:
Record a system error message with the error code; if RaiseExceptions is true, raise NO_DATA_FOUND.

FALSE:
File information was successfully retrieved.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The caller controls whether a missing or unreadable file causes an exception by passing the RaiseExceptions flag.
- BR-002 - File information retrieval requires the Win32 API bridge to be active; if unavailable, the call always fails.

---
**Implementation Logic**

```plsql

Procedure File_info ( CalledBy         IN  VARCHAR2,  
                      FileName         IN  VARCHAR2,
                      Option1          IN  PLS_INTEGER,
                      Option2          IN  PLS_INTEGER,
                      RaiseExceptions  IN BOOLEAN) is
 vcBuff1  varchar2(512);
 iRC      pls_integer;
begin
  Win_API_Debug.DebugLog(99,'File_Info','Args:  CalledBy="'||CalledBy||'", FileName="'||FileName||'", Option1='||to_char(Option1)||', Option2='||to_char(Option2)||', RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	  	
  WIN_API.Clean_Error_Stack;
  iRC    := 0;
  iBuff1 := 0;
  iBuff2 := 0;
  iBuff3 := 0;
  iBuff4 := 0;
  iBuff5 := 0;
  iBuff6 := 0;
  iBuff7 := 0;
  iBuff8 := 0;
  iBuff9 := 0;
  
  if WIN_API.API_ENABLED then 
    win_api.Register_function_call(iFileInfo,'d2kwutil_FileInfo','LONG','*CHAR,INT,INT,*LONG,*LONG,*LONG,*LONG,*LONG,*LONG,*LONG');
    vcBuff1 := RPAD(Filename,512,CHR(0));
    iBuff1  := Option1;
    iBuff2  := Option2;
    iRC     := d2kwutil_FileInfo(win_api.FunctionHandle(iFileInfo),vcBuff1,iBuff1,iBuff2,iBuff3,iBuff4,iBuff5,iBuff6,iBuff7,iBuff8,iBuff9);
    Win_API_Debug.DebugLog(99,'File_Info','Result:  RC='||to_char(iRC)||', iBuff1='||to_char(iBuff1)||', iBuff2='||to_char(iBuff2)||', iBuff3='||to_char(iBuff3)||', iBuff4='||to_char(iBuff4)||', iBuff5='||to_char(iBuff5)||', iBuff6='||to_char(iBuff6)||', iBuff7='||to_char(iBuff7)||', iBuff8='||to_char(iBuff8)||', iBuff9='||to_char(iBuff9));
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;
  if iRC in (0, -1074255551, -1074245406) then
    WIN_API.Add_error(CalledBy,'File '||FileName||' does not exist');
    if RaiseExceptions then 
      raise NO_DATA_FOUND;
    end if;
  elsif iRC <> 1 then 
    WIN_API.Add_error(CalledBy,'Gathering Information about '||FileName||' generated system error '||to_char(iRC));
    if RaiseExceptions then 
      raise NO_DATA_FOUND;
    end if;
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error(CalledBy,Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error(CalledBy, Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end;
```

#### SP-013 - D2KWUTIL.GET_ACTIVE_WINDOW

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the operating system handle of the currently active (focused) window on the user's workstation. The handle is used by other utilities (such as the file-selection dialog) to set the correct owner window for modal dialogs.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-073](#SP-073--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-074](#SP-074--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-075](#SP-075--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-076](#SP-076--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_ACTIVEWIN ([SP-005](#SP-005--D2KWUTIL.D2KWUTIL_ACTIVEWIN)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-077](#SP-077--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-082](#SP-082--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log the input parameters and clear the error stack.
- Step 2 - Verify that the Win32 API bridge is available; if not, raise a NOT_AVAILABLE error.
- Step 3 - Register the native active-window function and invoke it.
- Step 4 - If the returned handle is zero (no active window found), record an error and optionally raise an exception.
- Step 5 - Return the active window handle to the caller.

---
**Decision Points**

DP-001

Condition:
The Win32 API bridge is enabled (API_ENABLED)

TRUE:
Register and invoke the native active-window function.

FALSE:
Raise a NOT_AVAILABLE exception.

---

DP-002

Condition:
The returned window handle is zero

TRUE:
Record an 'Unable to obtain active window handle' error; if RaiseExceptions is true, raise NO_DATA_FOUND.

FALSE:
Return the valid window handle to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - If the active window cannot be determined and RaiseExceptions is false, the function returns zero and records an error without halting execution.
- BR-002 - Requires the Win32 API bridge to be active; if unavailable, the call always fails.

---
**Implementation Logic**

```plsql

FUNCTION Get_Active_Window (RaiseExceptions IN  BOOLEAN DEFAULT FALSE) RETURN PLS_INTEGER is
  iRC    PLS_INTEGER := 0;
begin
  Win_API_Debug.DebugLog(99,'Get_Active_Window','Args: RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	  			
  WIN_API.Clean_Error_Stack;
  if WIN_API.API_ENABLED then 
    win_api.Register_function_call(iActiveWin,'d2kwutil_ActiveWin','INT',NULL);
    iRC   := d2kwutil_ActiveWin(win_api.FunctionHandle(iActiveWin));
    Win_API_Debug.DebugLog(99,'Get_Active_Window','Result: RC='||to_char(iRC));        
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0 then 
    Win_API.Add_error('Get_Active_Window','Unable to obtain active window handle');
    if RaiseExceptions then 
      raise NO_DATA_FOUND;
    end if;
  end if;
  return iRC;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Active_Window',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Active_Window',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Active_window;
```

#### SP-014 - D2KWUTIL.SAVE_FILE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FILE_SAVE_DIALOG]
- webutil.pld [StoredProcedure: WEBUTIL.FILE_SELECTION_DIALOG_INT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Presents the operating system's 'Save File As' dialog to the user and returns the file path selected. If the user cancels without choosing a file, records an error and optionally raises an exception.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| SampleName | VARCHAR2 | IN |
| Title | VARCHAR2 | IN |
| StartDirectory | VARCHAR2 | IN |
| FileFilter | VARCHAR2 | IN |
| Modal | BOOLEAN | IN |
| AdvancedFlags | PLS_INTEGER | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-073](#SP-073--ADD_ERROR)) - matched by member name
- D2KWUTIL.CHOOSEFILE ([SP-004](#SP-004--D2KWUTIL.CHOOSEFILE)) - D2KWUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Invoke the file-selection dialog (ChooseFile) in Save mode, passing the sample filename, title, start directory, file filter, modal flag, and advanced flags.
- Step 2 - If the dialog returns without a selected file (return code 1), record a 'No file was selected' error; if RaiseExceptions is true, raise NO_DATA_FOUND.
- Step 3 - If a file was selected, return the selected file path to the caller.

---
**Decision Points**

DP-001

Condition:
The file dialog returns code 1 (no file selected / user cancelled)

TRUE:
Record a 'No file was selected' error; if RaiseExceptions is true, raise NO_DATA_FOUND.

FALSE:
Return the selected file path to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The caller controls whether a cancelled file dialog raises an exception by passing the RaiseExceptions flag.
- BR-002 - Default title is 'Save File As', default directory is the Windows directory, and default filter shows all files.

---
**Implementation Logic**

```plsql
                    

FUNCTION Save_File (  SampleName       IN  VARCHAR2,
                      Title            IN  VARCHAR2     DEFAULT 'Save File As',
                      StartDirectory   IN  VARCHAR2     DEFAULT '$WINDIR$',
                      FileFilter       IN  VARCHAR2     DEFAULT 'All files(*.*)|*.*|',
                      Modal            IN  BOOLEAN      DEFAULT TRUE,
                      AdvancedFlags    IN  PLS_INTEGER  DEFAULT WIN_API.OFN_FLAG_DEFAULT,
                      RaiseExceptions  IN  BOOLEAN      DEFAULT FALSE
                    ) RETURN VARCHAR2 is
  vcReturnedFile  varchar2(4096);
  iLRC    pls_integer := 0;
begin 
  vcReturnedFile  := SampleName;
  iLRC := choosefile('Save_File',Modal,Title,StartDirectory,FileFilter,AdvancedFlags,' ',vcReturnedFile);
  
  if iLRC = 1 then 
    Win_API.Add_error('Save_File','No file was selected');
    if RaiseExceptions then 
      Raise NO_DATA_FOUND;
    end if;
  else
    return vcReturnedFile;
  end if;
end Save_File;
```

#### SP-015 - D2KWUTIL.TRANSLATETYPE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

TranslateType is a lookup function that converts a string-based C data type name into its corresponding ORA_FFI integer constant. It is used by the REGISTER_FUNCTION_CALL routine to resolve human-readable type tokens (e.g., 'INT', '*CHAR') into the numeric type identifiers required by the ORA_FFI foreign-function interface layer when registering external C function signatures.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DataType | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameter DataType (VARCHAR2) representing a C data type token supplied by the caller.
- Step 2 - Convert the input value to uppercase and store it in the local variable vcType to ensure case-insensitive comparison.
- Step 3 - Evaluate vcType against each recognised C data type token in sequence using an IF-ELSIF chain.
- Step 4 - For each matched token, assign the corresponding ORA_FFI integer constant to the local return variable iRC (e.g., '*CHAR' maps to ORA_FFI.C_CHAR_PTR, 'CHAR' maps to ORA_FFI.C_CHAR, and so on for INT, LONG, SHORT/BYTE, DOUBLE, and VOID variants).
- Step 5 - Return the resolved ORA_FFI integer constant (iRC) to the caller.

---
**Decision Points**

DP-001

Condition: vcType = '*CHAR'
TRUE: Assign iRC := ORA_FFI.C_CHAR_PTR.
FALSE: Proceed to DP-002.

DP-002

Condition: vcType = 'CHAR'
TRUE: Assign iRC := ORA_FFI.C_CHAR.
FALSE: Proceed to DP-003.

DP-003

Condition: vcType = '*INT'
TRUE: Assign iRC := ORA_FFI.C_INT_PTR.
FALSE: Proceed to DP-004.

DP-004

Condition: vcType = 'INT'
TRUE: Assign iRC := ORA_FFI.C_INT.
FALSE: Proceed to DP-005.

DP-005

Condition: vcType = '*LONG'
TRUE: Assign iRC := ORA_FFI.C_LONG_PTR.
FALSE: Proceed to DP-006.

DP-006

Condition: vcType = 'LONG'
TRUE: Assign iRC := ORA_FFI.C_LONG.
FALSE: Proceed to DP-007.

DP-007

Condition: vcType = '*SHORT' OR vcType = '*BYTE'
TRUE: Assign iRC := ORA_FFI.C_SHORT_PTR.
FALSE: Proceed to DP-008.

DP-008

Condition: vcType = 'SHORT' OR vcType = 'BYTE'
TRUE: Assign iRC := ORA_FFI.C_SHORT.
FALSE: Proceed to DP-009.

DP-009

Condition: vcType = '*DOUBLE'
TRUE: Assign iRC := ORA_FFI.C_DOUBLE_PTR.
FALSE: Proceed to DP-010.

DP-010

Condition: vcType = 'DOUBLE'
TRUE: Assign iRC := ORA_FFI.C_DOUBLE.
FALSE: Proceed to DP-011.

DP-011

Condition: vcType = '*VOID'
TRUE: Assign iRC := ORA_FFI.C_VOID_PTR.
FALSE: No assignment is made; iRC remains unset (NULL), and that NULL value is returned to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The DataType input is treated as case-insensitive; the function uppercases the supplied value before evaluation, so 'int', 'INT', and 'Int' are all treated identically.
- BR-002 - The tokens '*SHORT' and '*BYTE' are treated as equivalent and both resolve to ORA_FFI.C_SHORT_PTR; similarly, 'SHORT' and 'BYTE' both resolve to ORA_FFI.C_SHORT.
- BR-003 - Pointer variants of a type are denoted by prefixing the type name with an asterisk (e.g., '*INT' for pointer-to-int); each pointer variant maps to a distinct ORA_FFI pointer constant separate from its non-pointer counterpart.
- BR-004 - If the supplied DataType token does not match any recognised value, the function returns NULL (iRC is never assigned), placing responsibility on the caller to handle an unresolved type.
- BR-005 - The function performs no database access and has no side effects; it is a pure lookup utility whose sole output is the resolved ORA_FFI integer constant.

---
**Implementation Logic**

```plsql
 
FUNCTION TranslateType(DataType in VARCHAR2) return PLS_INTEGER is
   -- Just a simple lookup of the types.
   vcType VARCHAR2(10) := UPPER(DataType);
   iRC    PLS_INTEGER;
begin 
  if vcType = '*CHAR' then 
    iRC := ORA_FFI.C_CHAR_PTR;
  elsif vcType = 'CHAR' then 
    iRC := ORA_FFI.C_CHAR;
  elsif vcType = '*INT' then 
    iRC := ORA_FFI.C_INT_PTR;
  elsif vcType = 'INT' then 
    iRC := ORA_FFI.C_INT;
  elsif vcType = '*LONG' then 
    iRC := ORA_FFI.C_LONG_PTR;
  elsif vcType = 'LONG' then 
    iRC := ORA_FFI.C_LONG;
  elsif vcType = '*SHORT' or vcType = '*BYTE'  then 
    iRC := ORA_FFI.C_SHORT_PTR;
  elsif vcType = 'SHORT' or vcType = 'BYTE' then 
    iRC := ORA_FFI.C_SHORT;
  elsif vcType = '*DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE_PTR;
  elsif vcType = 'DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE;  
  elsif vcType = '*VOID' then 
    iRC := ORA_FFI.C_VOID_PTR;      
  end if;
return iRC;
end TranslateType;
```

#### SP-016 - GENERAL.ASK_CONFIRM

**Invoked From:**

- vi_ro_hold_up_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

N/A

---

**Purpose**

Displays a configurable confirmation alert dialog (AL_CONFIRM) to the user and returns a numeric indicator of the button pressed. The function allows calling screens to present a dynamic confirmation message and branch their processing based on whether the user confirmed or declined the action.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| confirm_msg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the confirmation message text (confirm_msg) passed by the calling trigger.
- Step 2 - Set the message text of the predefined alert AL_CONFIRM to the value of confirm_msg using set_alert_property.
- Step 3 - Display the AL_CONFIRM alert dialog to the user via show_alert and capture the button pressed in p_albtn_pressed.
- Step 4 - Evaluate the captured button response: if the user pressed ALERT_BUTTON1 (the affirmative/confirm button), return 1 to the caller.
- Step 5 - If any other button was pressed (i.e., the user did not confirm), return 0 to the caller.

---
**Decision Points**

DP-001

Condition: p_albtn_pressed = ALERT_BUTTON1 (the user pressed the first/confirm button on the AL_CONFIRM alert dialog).

TRUE: The function returns 1, signalling to the caller that the user confirmed the action.

FALSE: The function returns 0, signalling to the caller that the user did not confirm the action.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The confirmation alert must use the predefined alert component named AL_CONFIRM; no other alert component is used by this function.
- BR-002 - The alert message text is dynamically overridden at runtime with the confirm_msg input parameter before the alert is shown, allowing a single alert component to serve multiple confirmation scenarios.
- BR-003 - A return value of 1 exclusively represents user confirmation (ALERT_BUTTON1 pressed); any other button response yields a return value of 0, treating all non-affirmative responses as a rejection.
- BR-004 - The function has no database interactions and no side effects beyond displaying the alert; the caller is solely responsible for acting on the returned value.

---
**Implementation Logic**

```plsql
FUNCTION ASK_CONFIRM( confirm_msg VARCHAR2)
                                      RETURN  NUMBER IS

    p_alert_name varchar2(10) := 'AL_CONFIRM' ;
    p_albtn_pressed number;
BEGIN
   set_alert_property(p_alert_name,alert_message_text,confirm_msg); 
   p_albtn_pressed := show_alert(p_alert_name);

   IF ( p_albtn_pressed = ALERT_BUTTON1 ) THEN
      return (1);
   ELSE
      return(0);
   END IF;
RETURN NULL; END;
```

#### SP-017 - GENERAL.DISP_TEXT

**Invoked From:**

- vi_ro_hold_up_fmb.xml [ProgramUnit: POPULATE_DETAILS]
- DPL.pld [StoredProcedure: GENERAL.RAISE_ERROR]
- vi_ro_hold_up_fmb.xml [StoredProcedure: POPULATE_DETAILS]
- vi_ro_hold_up_fmb.xml [Trigger: ON-ERROR]
- vi_ro_hold_up_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

Details (N/A / CN_MAIN); Search Criteria (N/A / CN_MAIN)

---

**Purpose**

Displays a message to the user in a modal dialog box. Uses an error-style alert when the severity is 'ERROR', and a note-style alert for all other message types.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| text_string | VARCHAR2 | IN |
| title_string | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Check whether the title (severity) passed by the caller is 'ERROR'.
- Step 2 - If the severity is 'ERROR', select the error alert template; otherwise select the note alert template.
- Step 3 - Set the alert's title and message text to the values supplied by the caller.
- Step 4 - Display the alert to the user and wait for the user to acknowledge it.

---
**Decision Points**

DP-001

Condition:
The title/severity parameter (uppercased) equals 'ERROR'

TRUE:
Use the error-style alert (AL_ERRINFO) to display the message.

FALSE:
Use the note-style alert (AL_NOTE) to display the message.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - All application messages are routed through this procedure to ensure consistent alert styling across the form.
- BR-002 - The distinction between error and non-error messages is based solely on the title string passed by the caller.

---
**Implementation Logic**

```plsql
PROCEDURE DISP_TEXT (text_string VARCHAR2,
                     title_string VARCHAR2 ) IS 
   p_alert_name varchar2(10) := 'AL_ERRINFO' ; 
   p_alert_id number;
BEGIN
   if upper(title_string)='ERROR' then
      p_alert_name := 'AL_ERRINFO' ; 
   else
      p_alert_name := 'AL_NOTE' ; 
   end if;
   set_alert_property(p_alert_name,TITLE,title_string);  
   set_alert_property(p_alert_name,alert_message_text,text_string);  
   p_alert_id := show_alert(p_alert_name); 
END;
```

#### SP-018 - GENERAL.L_POP_LIST_ITEM

**Invoked From:**

- vi_ro_hold_up_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

Search Criteria (N/A / CN_MAIN)

---

**Purpose**

Populates a named Oracle Forms record group from a dynamic SQL query, ensuring any pre-existing record group of the same name is removed before recreation. This procedure is called during form initialisation (WHEN-NEW-FORM-INSTANCE) to load list-item data into the CN_MAIN search criteria block.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_rg_name | VARCHAR2 | IN |
| p_select | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-051](#SP-051--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the record group name (p_rg_name) and the SQL SELECT statement (p_select) as input parameters, and assign the name to a local variable (rg_name).
- Step 2 - Attempt to locate an existing record group with the supplied name using the built-in Find_Group function, storing the result in rg_id.
- Step 3 - Check whether a record group with that name already exists by evaluating rg_id via WEBUTIL.ID_NULL (SP-051). If the group exists (i.e., rg_id is not null), delete it using the built-in Delete_Group to prevent duplicate or stale data.
- Step 4 - Create a new record group from the supplied dynamic SQL query using Create_Group_From_Query, assigning the resulting group handle back to rg_id.
- Step 5 - Populate the newly created record group by executing Populate_Group against rg_id, capturing the return error code in errcode.

---
**Decision Points**

DP-001

Condition: The record group identified by rg_name already exists in the current form session (i.e., Find_Group returns a non-null handle, confirmed via WEBUTIL.ID_NULL / SP-051).

TRUE: The existing record group is deleted via Delete_Group before a fresh group is created from the query.

FALSE: No deletion is performed; the procedure proceeds directly to create the record group from the supplied query.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A record group with the name supplied in p_rg_name must not persist from a prior execution; any pre-existing group of that name is unconditionally deleted before the new group is created, ensuring the list item always reflects the current query result.
- BR-002 - The record group must be created exclusively from the dynamic SQL statement provided in p_select; no hard-coded query is permitted, allowing callers to control the data set loaded into the list item.
- BR-003 - Null-handle detection relies on WEBUTIL.ID_NULL (SP-051); this dependency must be available at runtime for the existence check to function correctly.

---
**Implementation Logic**

```plsql

PROCEDURE l_pop_list_item (p_rg_name VARCHAR2,p_select VARCHAR2 )IS

	 rg_name VARCHAR2(40) := p_rg_name;
	 rg_id RecordGroup;
	 errcode NUMBER; 
BEGIN 
	/* ** Make sure group doesn't already exist */ 
	rg_id := Find_Group( rg_name ); 

	IF NOT Id_Null(rg_id) THEN 
		delete_group(rg_id);
	END IF;
	/* ** If it does not exist, create it and add the two ** necessary columns to it. */ 
		rg_id := Create_Group_From_Query( rg_name, p_select); 
	 
	/* ** Populate the record group */ 
	errcode := Populate_Group( rg_id );
END;
```

#### SP-019 - GENERAL.RAISE_ERROR

**Invoked From:**

- vi_ro_hold_up_fmb.xml [Trigger: ON-ERROR]

---

**Screen:**

N/A

---

**Purpose**

Looks up a predefined business error message by its error code, then displays it to the user using the appropriate alert style. For error-type messages, execution is halted after display. For note- and caution-type messages, execution continues after display.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| mesg_code | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-017](#SP-017--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Retrieve the message text and message type for the supplied error code (note: the lookup call is commented out in the current version, leaving the message text blank).
- Step 2 - Construct the full message by combining the error code and message text.
- Step 3 - Determine the message type and display accordingly:
  - If the type is Error ('E'), display the message as an error and halt execution (raise trigger failure).
  - If the type is Note ('N'), display the message as a note; execution continues.
  - If the type is Caution ('C'), display the message as a caution; execution continues.

---
**Decision Points**

DP-001

Condition:
Message type is 'E' (Error)

TRUE:
Display the message using the error alert style, then raise a trigger failure to halt processing.

FALSE:
Evaluate the next message type condition.

---

DP-002

Condition:
Message type is 'N' (Note)

TRUE:
Display the message using the note alert style; processing continues.

FALSE:
Evaluate the next message type condition.

---

DP-003

Condition:
Message type is 'C' (Caution)

TRUE:
Display the message using the caution alert style; processing continues.

FALSE:
No message is displayed (unrecognised message type).

---
**Database Interactions**

- DB-001 - Read AM_PERMISSIONS - Reads data from AM_PERMISSIONS for lookup or validation.
**Business Rules**

- BR-001 - Error-type messages always stop further processing by raising a trigger failure after display.
- BR-002 - Note- and caution-type messages are informational only and do not halt execution.

---
**Implementation Logic**

```plsql
PROCEDURE RAISE_ERROR ( mesg_code IN VARCHAR2 )IS
  mesg_type  varchar2(7); 
  mesg_text  varchar2(200) ;
  mesg_title varchar2(7);
  BEGIN
     -- murali 17.05.04 GENERAL.get_message(mesg_code,mesg_text,mesg_type );
     mesg_text:=mesg_code||' : '||mesg_text;		
     IF ( mesg_type = 'E' ) THEN
        mesg_title := 'Error' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
        raise FORM_TRIGGER_FAILURE;
     ELSIF ( mesg_type = 'N' ) THEN
        mesg_title := 'Note' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     ELSIF ( mesg_type = 'C' ) THEN
        mesg_title := 'Caution' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     END IF;
  END;     

/* PROCEDURE check_rights( 
pi_form_name in varchar2,
pi_user_id in number) IS
lv_x varchar2(1);
BEGIN
	
	begin
	SELECT substr(access_string, pi_user_id,1) 
	INTO   lv_x
	FROM   	am_permissions
	WHERE  form_name = pi_form_name
	AND SUBSTR(access_string,pi_user_id,1)='Y';
	exception 
		when no_data_found then
		  general.disp_text('You do not have the Permission to access this.','Error rr');
		  raise form_trigger_failure; 
		when too_many_rows then
		  general.disp_text('Many rows in USER_PERMISSIONS','Error ss');
		  raise form_trigger_failure;
		when others then
		       general.disp_text(sqlerrm,'Error mm');
		       raise form_trigger_failure;
	end;

	open_form(pi_form_name,activate,session);
END;
*/
```

#### SP-020 - I.CREATED_DATE

**Invoked From:**

- vi_ro_hold_up_fmb.xml [ProgramUnit: POPULATE_DETAILS]
- vi_ro_hold_up_fmb.xml [StoredProcedure: POPULATE_DETAILS]

---

**Screen:**

Details (N/A / CN_MAIN); Search Criteria (N/A / CN_MAIN)

---

**Purpose**

Retrieves the creation date and millisecond offset of a file on the client workstation by calling the underlying file-information utility. Returns the date as a standard date value and the milliseconds as a number.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| FileName | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| ReturnDate | DATE | OUT |
| ReturnMS | NUMBER | OUT |

---

**Dependencies**

- D2KWUTIL.FILE_INFO ([SP-012](#SP-012--D2KWUTIL.FILE_INFO)) - D2KWUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Invoke the file-information utility, passing the file path and requesting creation date details (option codes 1, 1).
- Step 2 - Assemble the returned numeric output buffers (year, month, day, hour, minute, second) into a date value and assign it to the ReturnDate output parameter.
- Step 3 - Assign the millisecond offset buffer to the ReturnMS output parameter.

---
**Decision Points**

No conditional branches - delegates all decisions to the underlying file-information utility.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - No form-specific business rules - utility function that wraps the file-information call to extract the file creation date.

---
**Implementation Logic**

```plsql

PROCEDURE Created_Date (  FileName        IN   VARCHAR2,
                          ReturnDate      OUT  DATE,
                          ReturnMS        OUT  NUMBER,
                          RaiseExceptions IN   BOOLEAN DEFAULT FALSE) is
begin 
  File_Info('Created_Date',Filename,1,1,RaiseExceptions);
  ReturnDate := to_date(to_char(iBuff3,'0999')||to_char(iBuff4,'09')||to_char(iBuff5,'09')||to_char(iBuff6,'09')||to_char(iBuff7,'09')||to_char(iBuff8,'09'),'YYYYMMDDHH24MISS');
  ReturnMS   := iBuff9;
end Created_Date;
```

#### SP-021 - WEBUTIL.BLOCKING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.HOST]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Executes an operating system command on the client workstation in blocking mode, meaning the form waits for the command to complete before continuing. Returns a process identifier for the launched process.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.EXECUTE ([SP-030](#SP-030--WEBUTIL.EXECUTE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Call the Execute utility with the supplied command and the BLOCKING_MODE execution flag.
- Step 2 - Return the process identifier returned by Execute to the caller.

---
**Decision Points**

No conditional branches - delegates entirely to the Execute function.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - No form-specific business rules - thin wrapper that forces blocking (synchronous) execution mode.

---
**Implementation Logic**

```plsql
  
  FUNCTION  Blocking(cmd in VARCHAR2) return PROCESS_ID is
  begin
    return Execute(cmd,BLOCKING_MODE);
  end Blocking;
```

#### SP-022 - WEBUTIL.CHECKLIBS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.CHECKLIBS verifies that all system libraries required by a given WebUtil package are present and up to date on the client machine. For each library declared in the property bundle for the client OS family and architecture, the procedure compares the installed version against the required version and, where a mismatch or absence is detected, downloads the library from the configured URL and records the new version in the client settings store.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.DOWNLOADFROMURLINT ([SP-027](#SP-027--WEBUTIL.DOWNLOADFROMURLINT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTSETTING ([SP-037](#SP-037--WEBUTIL.GETCLIENTSETTING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-057](#SP-057--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-061](#SP-061--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READTRANSFROMMSGBUNDLE ([SP-062](#SP-062--WEBUTIL.READTRANSFROMMSGBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETCLIENTSETTING ([SP-066](#SP-066--WEBUTIL.SETCLIENTSETTING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Begin iterating through sequentially numbered library specifications in the property bundle, constructing the lookup key from the client OS family, OS architecture, the supplied packageID, and an incrementing index (starting at 1).
- Step 2 - If no specification is found for the OS-family/architecture-specific key, retry the lookup using a key that omits the OS architecture component (OS family and packageID only).
- Step 3 - If neither lookup returns a value, exit the loop; all libraries for this package have been processed.
- Step 4 - Parse the retrieved library specification string (pipe-delimited) to extract: library file name (position 1), expected file size in bytes (position 2), required version string (position 3), and a flag indicating whether a progress indicator should be displayed during download (position 4).
- Step 5 - Increment the library index counter to prepare for the next iteration.
- Step 6 - Query the client settings store via WEBUTIL.GETCLIENTSETTING using the key 'syslib.<libName>' to retrieve the currently installed version of the library.
- Step 7 - Evaluate whether a download is required: the installed version is absent, differs from the required version, or the REDOWNLOAD_SYSLIB flag is set.
- Step 8 - If a download is required, resolve the download base URL from the property bundle, attempting lookups in order of specificity: OS family + architecture, then OS family only, then a generic location key.
- Step 9 - Invoke WEBUTIL.DOWNLOADFROMURLINT with the resolved URL (base URL concatenated with the library file name), the library name as the local target, a download type indicator of 1 (system library install), the expected file size, the progress flag, and localised progress dialog title and subtitle strings retrieved via WEBUTIL.READTRANSFROMMSGBUNDLE.
- Step 10 - If the download succeeds, record the newly installed version in the client settings store via WEBUTIL.SETCLIENTSETTING using the key 'syslib.<libName>'.
- Step 11 - If the download fails, log an error message identifying the library name via WEBUTIL.LOG and continue to the next library in the loop.

---
**Decision Points**

DP-001

Condition: The OS-family/architecture-specific property bundle key ('install.syslib.<OSFamily>.<OSArch>.<packageID>.<index>') returns a non-null library specification.

TRUE: Use the returned specification for this library entry.

FALSE: Fall back to the OS-family-only key ('install.syslib.<OSFamily>.<packageID>.<index>').

---

DP-002

Condition: The OS-family-only property bundle key returns a non-null library specification.

TRUE: Use the returned specification for this library entry.

FALSE: Exit the loop; no further libraries are defined for this package.

---

DP-003

Condition: The installed version retrieved from the client settings store is NULL, differs from the required version declared in the property bundle, or the REDOWNLOAD_SYSLIB flag is TRUE.

TRUE: Proceed to resolve the download URL and download the library.

FALSE: The library is already at the correct version; skip to the next iteration without downloading.

---

DP-004

Condition: The OS-family/architecture-specific download location key ('install.syslib.location.<OSFamily>.<OSArch>') returns a non-null URL.

TRUE: Use this URL as the download base.

FALSE: Fall back to the OS-family-only location key ('install.syslib.location.<OSFamily>').

---

DP-005

Condition: The OS-family-only download location key returns a non-null URL.

TRUE: Use this URL as the download base.

FALSE: Fall back to the generic location key ('install.syslib.location').

---

DP-006

Condition: WEBUTIL.DOWNLOADFROMURLINT returns TRUE (download completed successfully).

TRUE: Record the required version string against the library name in the client settings store via WEBUTIL.SETCLIENTSETTING.

FALSE: Log a failure message for the library via WEBUTIL.LOG and continue processing remaining libraries.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Library specifications for a package are looked up in the property bundle in ascending numeric sequence; processing stops as soon as a sequence index returns no entry, meaning library entries must be contiguous and start at index 1.
- BR-002 - Library specification lookup is first attempted with full OS specificity (family + architecture); if not found, the architecture qualifier is dropped, allowing a single OS-family-level specification to serve multiple architectures.
- BR-003 - A library must be downloaded if its client-side installed version is absent, does not exactly match the version declared in the property bundle, or the REDOWNLOAD_SYSLIB flag is active, ensuring the client always runs the version mandated by the server-side configuration.
- BR-004 - The download base URL is resolved with the same OS-specificity fallback pattern used for library specifications (architecture-specific -> family-only -> generic), ensuring the most targeted URL is used when available.
- BR-005 - The download is classified as a system library install (type indicator 1), which directs WEBUTIL.DOWNLOADFROMURLINT to place the file in the designated system library location rather than a general download directory.
- BR-006 - The client settings store is updated with the new version string only upon confirmed successful download; a failed download leaves the stored version unchanged and generates a log entry, preventing a false record of a successful installation.
- BR-007 - Progress dialog title and subtitle strings are sourced from the message bundle via WEBUTIL.READTRANSFROMMSGBUNDLE (keys INST_PGRS_TITLE and INST_PGRS_SUBTITLE), ensuring user-facing text is localised and not hard-coded.

---
**Implementation Logic**

```plsql
  
  PROCEDURE CheckLibs(packageID in VARCHAR2 ) is
    lib          PLS_INTEGER := 1;
    libSpec      VARCHAR2(200 char);
    libName      VARCHAR2(100 char);
    libSize      PLS_INTEGER;
    libVer       VARCHAR2(20 char);
    installedVer VARCHAR2(20 char);
    libProg      BOOLEAN := false;
    downloadURL  VARCHAR2(1000);
  BEGIN
    -- Read through the property bundle for 
    -- any libraries for this package
    LOOP
      libSpec := readFromPropertyBundle('install.syslib.'||to_char(m_clientOSFamily)||'.'||
             to_char(m_clientOSArch)||'.'||packageID||'.'||to_char(lib));
      if libSpec is null then
        libSpec := readFromPropertyBundle('install.syslib.'||to_char(m_clientOSFamily)||'.'||
             packageID||'.'||to_char(lib));
      end if;
      if libSpec is null then 
        exit;
      end if;
      lib := lib + 1;
      libName := Delimstr.getString(libSpec,1,true,'|');
      libSize := Delimstr.getNumber(libSpec,2,true,'|');
      libVer  := Delimstr.getString(libSpec,3,true,'|');
      libProg := (upper(Delimstr.getString(libSpec,4,true,'|'))='TRUE');

      -- OK we now have the library information
      -- let's check if it's installed
      installedVer := GetClientSetting('syslib.'||libname);
      if installedVer is null or installedVer <> libVer or REDOWNLOAD_SYSLIB then 
        -- need to download
        downloadURL := readFromPropertyBundle('install.syslib.location' || '.' || to_char(m_clientOSFamily) ||
                             '.' || to_char(m_clientOSArch));
        if downloadURL is null then
          downloadURL := readFromPropertyBundle('install.syslib.location' || '.' || to_char(m_clientOSFamily));
        end if;
        if downloadURL is null then
          downloadURL := readFromPropertyBundle('install.syslib.location');
        end if;
        if DownLoadFromURLInt(downloadURL||'/'||libName, 
                              libName,
                              1, -- syslib install download, special location
                              libSize,
                              libProg,
                              ReadTransFromMsgBundle('INST_PGRS_TITLE'),
                              ReadTransFromMsgBundle('INST_PGRS_SUBTITLE'),     
                              libName) then 
          SetClientSetting('syslib.'||libname,libVer);
        else
          log('Download of system library '||libName||' failed',true);
        end if;                          
      end if;
    END LOOP;
  END CheckLibs;
```

#### SP-023 - WEBUTIL.CLEARCALLBACKTRIGGER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Removes a registered callback trigger entry from the internal callback registry using the supplied callback key. Used by the WebUtil infrastructure to clean up after an asynchronous process callback has been handled.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| callbackKey | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Check whether an entry with the supplied callback key exists in the callback registry.
- Step 2 - If the entry exists, delete it from the registry.

---
**Decision Points**

DP-001

Condition:
An entry with the supplied callback key exists in the callback registry

TRUE:
Delete the entry from the registry.

FALSE:
Do nothing; the procedure completes silently.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - No form-specific business rules - WebUtil infrastructure utility for callback lifecycle management.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ClearCallbackTrigger(callbackKey in PLS_INTEGER) is
  begin
    if m_callbacks.exists(callbackKey) then 
      m_callbacks.delete(callbackKey);  
    end if;
  end ClearCallbackTrigger;
```

#### SP-024 - WEBUTIL.CLOSEBLOB

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open BLOB handle identified by its checksum value. The procedure delegates the close operation to the WebUtil_DB package, releasing any server-side resources associated with the BLOB session referenced by the supplied checksum.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| checksum | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the checksum (PLS_INTEGER) that uniquely identifies the open BLOB handle to be closed.
- Step 2 - Delegate the close operation to WebUtil_DB.CloseBlob, passing the checksum as the sole argument.
- Step 3 - Return the BOOLEAN result produced by WebUtil_DB.CloseBlob to the caller, indicating whether the BLOB was successfully closed.

---
**Decision Points**

No decision points are present in the implementation logic. The function unconditionally delegates to WebUtil_DB.CloseBlob and returns its result without branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The checksum supplied must correspond to a BLOB handle previously opened within the WebUtil_DB context; the validity of the checksum is enforced by WebUtil_DB.CloseBlob.
- BR-002 - The success or failure of the close operation is communicated exclusively through the returned BOOLEAN value; no exceptions are raised directly by this function.
- BR-003 - This function must only be called from within the WEBUTIL.SETDATA stored procedure context, as it is not intended for direct invocation from other callers.

---
**Implementation Logic**

```plsql

  FUNCTION  CloseBlob(checksum in PLS_INTEGER) return BOOLEAN is
  BEGIN
    return WebUtil_DB.CloseBlob(checksum);
  END CloseBlob;
```

#### SP-025 - WEBUTIL.CLOSEFILE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open server-side file reader object by invoking the native Java method on the AppServerFileReader class. This procedure releases the file handle associated with the supplied Java object, ensuring that server-side file resources are properly freed after a file transfer or read operation initiated by WEBUTIL.SETDATA.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java object reference (obj) representing an open AppServerFileReader instance on the application server.
- Step 2 - Reset the shared argument list (args) to NULL, ensuring no stale parameters are passed to the Java method invocation.
- Step 3 - Invoke the native Java boolean method closeFile() on the AppServerFileReader class via JNI.CALL_BOOLEAN_METHOD, passing the supplied object reference and an empty argument list.
- Step 4 - Return the boolean result produced by the Java method to the caller, indicating whether the file was successfully closed.

---
**Decision Points**

DP-001

Condition: The JNI call to oracle/forms/webutil/fileTransfer/AppServerFileReader.closeFile() returns TRUE or FALSE.

TRUE: The file handle was successfully closed on the application server; the boolean TRUE is returned to the caller.

FALSE: The file handle could not be closed (e.g., already closed or invalid object reference); the boolean FALSE is returned to the caller, signalling an unsuccessful close attempt.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The argument list (args) must be explicitly set to NULL before the JNI method call to guarantee that no residual parameters from a prior invocation are forwarded to the Java layer.
- BR-002 - The Java method signature ()Z must be used exactly as specified, confirming that closeFile accepts no arguments and returns a primitive boolean; any deviation would cause the JNI call to fail.
- BR-003 - The caller is responsible for supplying a valid, non-null AppServerFileReader Java object reference; the function does not perform null-checking on obj prior to the JNI invocation.
- BR-004 - The boolean return value must be propagated back to the invoking routine (WEBUTIL.SETDATA) so that the caller can determine whether the file resource was successfully released.

---
**Implementation Logic**

```plsql
  FUNCTION closeFile(
    obj   ORA_JAVA.JOBJECT) RETURN BOOLEAN IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_BOOLEAN_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'closeFile', '()Z', args); 
  END;
```

#### SP-026 - WEBUTIL.DOWNLOADFROMURL

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.URL_TO_CLIENT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Downloads a file from a URL to a destination path on the client workstation. Provides a simplified interface by delegating to the internal download function with default settings (no progress display, standard destination mode).

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| fileSize | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.DOWNLOADFROMURLINT ([SP-027](#SP-027--WEBUTIL.DOWNLOADFROMURLINT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Call the internal download function, passing the source URL, client destination path, and optional file size, with all other options set to defaults (no special destination, no progress display).
- Step 2 - Return a boolean indicating whether the download succeeded.

---
**Decision Points**

No conditional branches - delegates entirely to the internal download function.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - No form-specific business rules - simplified wrapper for file download from a URL to the client workstation.

---
**Implementation Logic**

```plsql
  
  FUNCTION DownLoadFromURL(sourceURL         in VARCHAR2, 
                           clientDestination in VARCHAR2, 
                           fileSize          in PLS_INTEGER default 0) return BOOLEAN is
  BEGIN
    return DownLoadFromURLInt(sourceURL,
                              ClientDestination,
                              0,
                              fileSize,
                              false,
                              null,
                              null,
                              null);
  END DownLoadFromURL;
```

#### SP-027 - WEBUTIL.DOWNLOADFROMURLINT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.DOWNLOADFROMURL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Internal implementation of the URL-to-client file download. Validates the source URL and destination path, constructs a property string encoding all download parameters, submits it to the WebUtil bean, and returns a boolean indicating success or failure.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| specialDestination | PLS_INTEGER | IN |
| fileSize | PLS_INTEGER | IN |
| withProgress | BOOLEAN | IN |
| progressTitle | VARCHAR2 | IN |
| progressSubTitle | VARCHAR2 | IN |
| progressMessage | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Validate that the source URL is not null; if it is, raise a URL_NULL exception.
- Step 2 - Validate that the client destination path is not null; if it is, raise a CLIENT_FILE_NULL exception.
- Step 3 - Build the parameter string, handling null values for specialDestination, fileSize, and withProgress.
- Step 4 - Submit the download request to the WebUtil bean and retrieve the result.
- Step 5 - Return TRUE if the result is 'TRUE', FALSE otherwise.
- Step 6 - On exception, record an appropriate error and return FALSE or raise trigger failure.

---
**Decision Points**

DP-001

Condition:
sourceURL is null

TRUE:
Raise a URL_NULL exception, record error 25, and return false.

FALSE:
Continue validation.

---

DP-002

Condition:
clientDestination is null

TRUE:
Raise a CLIENT_FILE_NULL exception, record error 130, and return false.

FALSE:
Continue building the parameter string.

---

DP-003

Condition:
specialDestination is null, negative, or greater than 2

TRUE:
Use '0' as the special destination code in the parameter string.

FALSE:
Use the supplied value as the special destination code.

---

DP-004

Condition:
fileSize is null

TRUE:
Use '0' as the file size in the parameter string.

FALSE:
Use the supplied value as the file size.

---

DP-005

Condition:
withProgress is null or false

TRUE:
Use 'N' as the progress flag in the parameter string.

FALSE:
Use 'Y' as the progress flag.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Both source URL and client destination must be specified; either being null causes the download to fail with an error.
- BR-002 - No form-specific business rules beyond input validation - WebUtil infrastructure utility.

---
**Implementation Logic**

```plsql
  
  FUNCTION DownLoadFromURLInt(sourceURL          in VARCHAR2, 
                              clientDestination  in VARCHAR2, 
                              specialDestination in PLS_INTEGER default 0,                             
                              fileSize           in PLS_INTEGER default 0, 
                              withProgress       in BOOLEAN default false,
                              progressTitle      in VARCHAR2 default null,
                              progressSubTitle   in VARCHAR2 default null,
                              progressMessage    in VARCHAR2 default null) return BOOLEAN is
    result       VARCHAR2(6) := 'FALSE';
    submitString VARCHAR2(4000 char);
    sep          VARCHAR2(1) := '|';
  BEGIN
    if sourceURL is null then
      raise URL_NULL;
    end if;
    if clientDestination is null then
      raise CLIENT_FILE_NULL;
    end if;

    if specialDestination is null or specialDestination < 0 or specialDestination > 2 then 
      submitString := '0'||sep;
    else
      submitString := to_char(specialDestination)||sep;
    end if;
    if fileSize is null then 
      submitString := submitString||'0'||sep;
    else
      submitString := submitString||to_char(fileSize)||sep;
    end if;
    if withProgress is null or not withProgress then 
      submitString := submitString||'N'||sep;
    else
      submitString := submitString||'Y'||sep;
    end if;    

    submitString := submitString||sourceURL
                    ||sep||clientDestination
                    ||sep||nvl(progressTitle,' ')
                    ||sep||nvl(progressSubTitle,' ')
                    ||sep||nvl(progressMessage,' ');                         
  WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_URL_DOWNLOAD',submitString,true);
  result := WebUtil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_URL_DOWNLOAD');
  return (result='TRUE');
  EXCEPTION  
    when CLIENT_FILE_NULL then
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE, 130, 'WEBUTIL_CORE.DownloadFromURLInt');
      return false;
    when URL_NULL then
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE,25, 'WEBUTIL_CORE.DownloadFromURLInt');
      return false;

    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                              ||' bean not found. WEBUTIL_CORE.DownloadFromURLInt will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;
  END DownLoadFromURLInt;
```

#### SP-028 - WEBUTIL.ERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Records an error message in the WebUtil bean by constructing a structured error string from a package identifier, numeric error code, procedure name, and up to three optional argument values. Used internally by WebUtil components to report errors to the bean layer.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |
| code | PLS_INTEGER | IN |
| pu_name | VARCHAR2 | IN |
| arg1 | VARCHAR2 | IN |
| arg2 | VARCHAR2 | IN |
| arg3 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Build an error string beginning with 'ERROR' followed by the zero-padded error code and the procedure name.
- Step 2 - Append each non-null argument to the error string, separated by pipe characters.
- Step 3 - Set the error message property in the WebUtil bean.

---
**Decision Points**

DP-001

Condition:
arg1 is not null

TRUE:
Append arg1 to the error string.

FALSE:
Skip arg1.

---

DP-002

Condition:
arg2 is not null

TRUE:
Append arg2 to the error string.

FALSE:
Skip arg2.

---

DP-003

Condition:
arg3 is not null

TRUE:
Append arg3 to the error string.

FALSE:
Skip arg3.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - No form-specific business rules - WebUtil infrastructure utility for structured error reporting.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Error(packageID in PLS_INTEGER,
                  code      in PLS_INTEGER,
                  pu_name   in VARCHAR2,
                  arg1      in VARCHAR2 :=null,
                  arg2      in VARCHAR2 := null,
                  arg3      in VARCHAR2 := null
                 ) is
    errText varchar2(1024);
  begin 
    errText := 'ERROR'||lpad(to_char(code),3,'0') || '|' || pu_name;
    if arg1 is not null then
      errText := errText || '|' || arg1;
    end if;
    if arg2 is not null then
      errText := errText || '|' || arg2;
    end if;
    if arg3 is not null then
      errText := errText || '|' || arg3;
    end if;
    Webutil_Core.setProperty(packageID, 'WUC_ERROR_MSG', errText);
  end Error;
```

#### SP-029 - WEBUTIL.ERRORALERT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]
- webutil.pld [StoredProcedure: WEBUTIL.LOG]
- webutil.pld [StoredProcedure: WEBUTIL.POPULATEPROPERTYBUNDLE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Displays a WebUtil error message to the user in a modal alert dialog. If a WebUtil error alert is registered and available, it is used; otherwise the message is shown via the standard form message area.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| errText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-051](#SP-051--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Check whether the WebUtil error alert object is available (not null).
- Step 2 - If available, set its message text and display it to the user.
- Step 3 - If not available, display the error text as a standard form message.

---
**Decision Points**

DP-001

Condition:
The WebUtil error alert object is available (not null / not ID_NULL)

TRUE:
Set the alert message text and display the modal alert.

FALSE:
Display the error text using the standard form message function.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - No form-specific business rules - WebUtil infrastructure utility for displaying bean-related error alerts.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ErrorAlert(errText in VARCHAR2) is
    -- currently used for throwing a BEAN_NOT_REGISTERED or bean not found error.
    ignore integer;
  begin
    if not ID_NULL(m_errorAlert) then 
      --SET_ALERT_PROPERTY(m_errorAlert,TITLE,'WebUtil Error'); -- title already set in alert property
      SET_ALERT_PROPERTY(m_errorAlert,ALERT_MESSAGE_TEXT,errText);
      ignore := SHOW_ALERT(m_errorAlert);
    else
      message('WebUtil Error'||': '||errText);
    end if;
  end ErrorAlert;
```

#### SP-030 - WEBUTIL.EXECUTE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.BLOCKING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Executes an operating system command on the client workstation via the WebUtil host bean. Supports both blocking (synchronous) and non-blocking (asynchronous) execution modes. Returns a process identifier for the launched process.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |
| exemode | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - If the command string is not null, set the execution mode property in the WebUtil host bean.
- Step 2 - Submit the command to the WebUtil host bean for execution and retrieve the process handle.
- Step 3 - Return the process identifier to the caller.

---
**Decision Points**

DP-001

Condition:
The command string is not null

TRUE:
Set the execution mode and submit the command to the bean.

FALSE:
Return an empty process identifier without executing anything.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - No form-specific business rules - WebUtil infrastructure utility for executing client-side operating system commands.

---
**Implementation Logic**

```plsql
  FUNCTION Execute (cmd in VARCHAR2, exemode in PLS_INTEGER) return PROCESS_ID is
    procId PROCESS_ID;
  begin 
    if cmd is not null then 
      WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTION_MODE',exemode);            
      WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTE',cmd);      
      procId.handle := to_number(WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTE'));
    end if;
    return procId;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.Execute will not work');
  end Execute;
```

#### SP-031 - WEBUTIL.FCLOSE

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes a file that was previously opened via WebUtil file I/O by releasing the server-side file handle. If the underlying WebUtil bean is unavailable or a property error occurs, the procedure raises a terminal application error after surfacing a descriptive alert to the user.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-029](#SP-029--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETIMPLCLASS ([SP-038](#SP-038--WEBUTIL.GETIMPLCLASS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the file handle (file_type IN OUT parameter) passed by the calling routine (VIEW_EXCEL_REPORT_NEW).
- Step 2 - Check whether the file handle is currently open (file.handle IS NOT NULL).
- Step 3 - If the handle is active, invoke WebUtil_Core.setProperty with the WUF_PACKAGE constant and the WUF_TEXTIO_CLOSE command to instruct the WebUtil bean to flush and close the file.
- Step 4 - Null out file.handle to mark the handle as released and prevent reuse.
- Step 5 - If the WebUtil bean is not registered (BEAN_NOT_REGISTERED exception), call WEBUTIL.ERRORALERT with a message constructed via WEBUTIL.GETIMPLCLASS to identify the missing bean, then raise TOOL_ERR.TOOL_ERROR to abort processing.
- Step 6 - If a property-level error occurs (PROPERTY_ERROR exception), raise TOOL_ERR.TOOL_ERROR to abort processing without an additional alert.

---
**Decision Points**

DP-001

Condition: file.handle IS NOT NULL

TRUE: The WebUtil bean is instructed to close the file (WUF_TEXTIO_CLOSE), and file.handle is set to NULL.

FALSE: No close operation is attempted; the procedure exits silently.

---

DP-002

Condition: WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during the close operation.

TRUE: WEBUTIL.ERRORALERT is called with a message that includes the implementation class name retrieved via WEBUTIL.GETIMPLCLASS, informing the user that the required bean is absent and that CLIENT_TEXT_IO.fclose will not work; TOOL_ERR.TOOL_ERROR is then raised.

FALSE: Exception is not raised; normal execution continues.

---

DP-003

Condition: WebUtil_Core.PROPERTY_ERROR exception is raised during the close operation.

TRUE: TOOL_ERR.TOOL_ERROR is raised immediately to abort processing; no user alert is issued.

FALSE: Exception is not raised; normal execution continues.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A file handle that is already NULL is silently ignored; no close attempt is made and no error is raised, preventing double-close faults.
- BR-002 - Once the WebUtil bean successfully closes the file, the handle must be nulled out immediately to ensure the file_type variable reflects the released state.
- BR-003 - If the WebUtil bean required for file I/O is not registered, the procedure must surface a user-facing alert (via WEBUTIL.ERRORALERT) that identifies the missing bean class (via WEBUTIL.GETIMPLCLASS) before terminating with a hard application error.
- BR-004 - Any property-level error encountered during the close operation results in an immediate hard termination (TOOL_ERR.TOOL_ERROR) without further user notification.
- BR-005 - No database interactions are performed; this is a WebUtil infrastructure utility confined to client-side file I/O resource management.

---
**Implementation Logic**

```plsql
 
  PROCEDURE fclose (file IN OUT file_type) is 
  BEGIN 
    if (file.handle IS NOT NULL) then 
      WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CLOSE',file.handle);        
      file.handle := NULL;
    end if;
 
 EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.fclose will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;
  END fclose;
```

#### SP-032 - WEBUTIL.FILE_SAVE_DIALOG

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Presents the operating system's 'Save File As' dialog to the user on the client workstation and returns the selected file path. Delegates to the underlying file-selection dialog utility.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| directory_name | Varchar2 | IN |
| file_name | Varchar2 | IN |
| file_filter | Varchar2 | IN |
| title | Varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- D2KWUTIL.SAVE_FILE ([SP-014](#SP-014--D2KWUTIL.SAVE_FILE)) - D2KWUTIL.pck (or .pld)
- WEBUTIL.FILE_SELECTION_DIALOG_INT ([SP-033](#SP-033--WEBUTIL.FILE_SELECTION_DIALOG_INT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Call the file-selection dialog utility in Save mode with the supplied title, initial directory, file filter, modal flag, and advanced flags.
- Step 2 - Return the file path selected by the user.

---
**Decision Points**

No conditional branches - delegates entirely to the file-selection dialog utility.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - No form-specific business rules - WebUtil wrapper for the operating system Save File dialog.

---
**Implementation Logic**

```plsql
                                        
  FUNCTION FILE_SAVE_DIALOG(            directory_name Varchar2 := NULL,
                                        file_name      Varchar2 := NULL,
                                        file_filter    Varchar2 := NULL,
                                        title          Varchar2 := NULL) return Varchar2 is
  BEGIN
    RETURN FILE_SELECTION_DIALOG_INT(   directory_name,
                                        file_name,
                                        file_filter,
                                        title,
                                        SAVE_FILE,
                                        TRUE,
                                        FALSE); 
  END FILE_SAVE_DIALOG;
```

#### SP-033 - WEBUTIL.FILE_SELECTION_DIALOG_INT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FILE_SAVE_DIALOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Internal implementation of the WebUtil client-side file-selection dialog. Determines whether to use the D2KWUTIL native dialog or the WebUtil bean dialog based on the runtime environment, then presents the appropriate file browser to the user and returns the selected path.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| directory_name | Varchar2 | IN |
| file_name | Varchar2 | IN |
| file_filter | Varchar2 | IN |
| title | Varchar2 | IN |
| dialog_type | Number | IN |
| select_file | Boolean | IN |
| multiselect | Boolean | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- D2KWUTIL.SAVE_FILE ([SP-014](#SP-014--D2KWUTIL.SAVE_FILE)) - D2KWUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Check whether the D2KWUTIL native library is available.
- Step 2 - If available, invoke the D2KWUTIL Save File dialog with the supplied parameters and return the result.
- Step 3 - If the native library is not available, construct a parameter string and submit a dialog request to the WebUtil client-utilities bean.
- Step 4 - Retrieve and return the selected file path from the bean response.
- Step 5 - On error (bean not registered or property error), display an error alert and raise a trigger failure.

---
**Decision Points**

DP-001

Condition:
The D2KWUTIL native library is available on the client

TRUE:
Use the D2KWUTIL Save File dialog to present the file browser.

FALSE:
Use the WebUtil client-utilities bean to present the file browser.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - No form-specific business rules - WebUtil infrastructure utility that selects the appropriate file-dialog mechanism based on the client environment.

---
**Implementation Logic**

```plsql
  FUNCTION FILE_SELECTION_DIALOG_INT(   directory_name Varchar2,
                                        file_name      Varchar2,
                                        file_filter    Varchar2,
                                        title          Varchar2,
                                        dialog_type    Number,
                                        select_file    Boolean,
                                        multiselect    Boolean) return Varchar2 is
    result varchar2(4000);     
    pos Number;
  BEGIN  
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_DIRNAME', directory_name);
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILENAME',file_name, true);     
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILTER',  file_filter); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_MESSAGE', title); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_MULTISELECT', multiselect,true);     
  
    if (dialog_type = SAVE_FILE) then 
        result := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_SAVEFILE');
    elsif (not select_file) then
        result := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_OPENDIR');
    else
        result := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_OPENFILE');
    end if;
  
    -- handle the situation which we can get with JFileChooser with escaped "\"

    -- if string starts with '\\', replace it with '\\\\', 
    -- before running the original replace statement.
    pos := instr(result, '\\');

    -- concat '\\' in the begining of the string before calling the replace.
    if (pos = 1) then
        result := concat('\\', result);
    end if;

    result := replace(result,'\\','\');
    return result;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. WEBUTIL_FILE.FILE_SELECTION_DIALOG_INT will not work');
      RAISE FORM_TRIGGER_FAILURE;  
   when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;  
  END FILE_SELECTION_DIALOG_INT;
```

#### SP-034 - WEBUTIL.FOPEN

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Opens a client-side file for reading, writing, or appending by submitting the file specification, open mode, and optional character set to the WebUtil file I/O bean via WEBUTIL.GETPROPERTY. Returns a typed file handle for use in subsequent I/O operations. Raises a tool error if input validation fails, the bean is unavailable, or the file cannot be opened.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| spec | VARCHAR2 | IN |
| filemode | VARCHAR2 | IN |
| charSet | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETPROPERTY ([SP-044](#SP-044--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Validate that the supplied file mode is one of the accepted values ('r', 'w', 'a'); raise TOOL_ERR.TOOL_ERROR immediately if it is not.
- Step 2 - Validate that a non-null, non-empty file specification has been provided; raise TOOL_ERR.TOOL_ERROR if the spec is absent.
- Step 3 - Pass the file specification to the WebUtil file I/O bean by setting the WUF_FILENAME property via WebUtil_Core.setProperty.
- Step 4 - Pass the file mode to the bean by setting the WUF_TEXTIO_FILEMODE property via WebUtil_Core.setProperty.
- Step 5 - Pass the character set to the bean by setting the WUF_TEXTIO_CHARSET property via WebUtil_Core.setProperty; if no character set was supplied, transmit the literal '(null)' to signal the default.
- Step 6 - Trigger the actual file-open operation on the client by reading the WUF_TEXTIO_OPEN property via WEBUTIL.GETPROPERTY (SP-044); the bean returns a Java file handle string.
- Step 7 - Inspect the returned handle; if it is null, empty, or '-1', the file was not opened - raise TOOL_ERR.TOOL_ERROR.
- Step 8 - Convert the valid handle string to a number, populate the clientFile.handle field, and return the file_type record to the caller.
- Step 9 - On BEAN_NOT_REGISTERED, display an error alert identifying the missing bean class and raise TOOL_ERR.TOOL_ERROR. On PROPERTY_ERROR or VALUE_ERROR, re-raise the originating exception. On TOOL_ERR.TOOL_ERROR, re-raise to the caller.

---
**Decision Points**

DP-001

Condition: The supplied filemode (case-insensitive) is not one of 'r', 'w', or 'a'.

TRUE: Raise TOOL_ERR.TOOL_ERROR immediately; processing stops.

FALSE: Continue to the next validation step.

---

DP-002

Condition: The supplied file specification (spec) is null or an empty string.

TRUE: Raise TOOL_ERR.TOOL_ERROR immediately; processing stops.

FALSE: Continue to set bean properties.

---

DP-003

Condition: The charSet parameter is null.

TRUE: Set the WUF_TEXTIO_CHARSET bean property to the literal '(null)', signalling the bean to use its default character set.

FALSE: Set the WUF_TEXTIO_CHARSET bean property to the caller-supplied character set value.

---

DP-004

Condition: The Java handle returned by WEBUTIL.GETPROPERTY (WUF_TEXTIO_OPEN) is null, empty, or equal to '-1'.

TRUE: The file was not opened; raise TOOL_ERR.TOOL_ERROR.

FALSE: Convert the handle to a number, assign it to clientFile.handle, and return the file_type record to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file open mode must be exactly one of 'r' (read), 'w' (write), or 'a' (append), evaluated case-insensitively; any other value is rejected before any bean interaction occurs.
- BR-002 - A non-null, non-empty file path must be provided; the procedure does not attempt to open a file without a valid specification.
- BR-003 - Character set is optional; when omitted, the WebUtil bean is explicitly instructed to apply its default character set by receiving the sentinel value '(null)'.
- BR-004 - A Java handle of null, empty string, or '-1' is treated as a failed open; the procedure does not return a partially constructed file handle to the caller.
- BR-005 - The numeric file handle stored in the returned file_type record is derived solely from the string value supplied by the WebUtil bean; a VALUE_ERROR during conversion (non-numeric handle) is re-raised as a tool error, preventing an invalid handle from reaching the caller.
- BR-006 - This is a WebUtil infrastructure utility with no form-specific business rules; it is invoked indirectly from dms_excel_report.pld to support client-side file operations for Excel report generation.

---
**Implementation Logic**

```plsql
  FUNCTION fopen(spec VARCHAR2, filemode VARCHAR2, charSet VARCHAR2 := null) RETURN file_type is
    clientFile file_type;
    javaHandle VARCHAR2(6);
  BEGIN
    -- check the mode is valid
    if (lower(filemode) not in ('r','w','a')) then 
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- make sure a file name has been specified      
    if (spec is null) or (spec='') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;
      
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILENAME',spec, true);
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_FILEMODE',filemode, true);        
    if (charSet is null) then
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET','(null)', true);
    else
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET',charSet, true);
    end if;
    javaHandle := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_OPEN');

    -- If the return is null then the file was not opened      
    if (javaHandle is null) or (javaHandle='') or (javaHandle='-1') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- if we are this far convert the handle to the correct format and return it.      
    clientFile.handle := to_number(javaHandle);
    return clientFile;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.fopen will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                 
      return null;
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE;
    when VALUE_ERROR then
      RAISE TOOL_ERR.TOOL_ERROR; 
    when TOOL_ERR.TOOL_ERROR then 
      RAISE;
  END fopen;
```

#### SP-035 - WEBUTIL.GETCALLBACKTRIGGER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the name of the callback trigger associated with a given numeric key from the internal callbacks collection. This function allows the WEBUTIL package (specifically WEBUTIL.SETDATA) to look up which trigger string has been registered against a particular callback key, supporting the dispatch of WebUtil callback events to the correct Oracle Forms trigger.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| callbackKey | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the integer callback key (callbackKey) supplied by the caller.
- Step 2 - Use callbackKey as an index into the package-level associative array m_callbacks.
- Step 3 - Return the VARCHAR2 trigger name stored at that index position to the caller.

---
**Decision Points**

No conditional decision points exist in this function. The implementation performs a direct index lookup on m_callbacks and returns the result unconditionally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The callbackKey parameter must correspond to a valid, pre-existing index in the m_callbacks collection; supplying an unregistered key will raise a NO_DATA_FOUND or subscript error at runtime.
- BR-002 - The function returns the trigger name exactly as it was stored in m_callbacks, without transformation or validation of the returned value.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetCallbackTrigger(callbackKey in PLS_INTEGER) return VARCHAR2 is 
  begin 
    return m_callbacks(callbackKey);
  end GetCallbackTrigger;
```

#### SP-036 - WEBUTIL.GETCLIENTOSFAMILY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the operating system family name of the client workstation (for example, 'WINDOWS' or 'UNIX'). Used to tailor runtime behaviour based on the client's operating environment.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Query the WebUtil core bean for the client operating system family property.
- Step 2 - Return the result string to the caller.

---
**Decision Points**

No conditional branches - reads and returns a single property value.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - No form-specific business rules - WebUtil infrastructure utility for client environment detection.

---
**Implementation Logic**

```plsql

  FUNCTION GetClientOSFamily return PLS_INTEGER is 
  begin 
    return m_clientOSFamily;
  end GetClientOSFamily;
```

#### SP-037 - WEBUTIL.GETCLIENTSETTING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a named client-side configuration property from the WebUtil Core bean. Given a property name, the function delegates to WebUtil_Core to set a retrieval request and then reads back the resulting value, returning it to the caller. It is used by WEBUTIL.CHECKLIBS and WEBUTIL.REGISTERBEAN to inspect local client settings required during library checking and bean registration.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input property name (propertyName) from the calling routine.
- Step 2 - Check whether propertyName is not null; if it is null, skip retrieval and proceed directly to the return step.
- Step 3 - Invoke WebUtil_Core.setProperty targeting the WUC_PACKAGE component with the key WUC_GET_LOCAL_PROPERTY and the supplied propertyName, signalling the WebUtil Core bean to prepare the requested local property value.
- Step 4 - Invoke WebUtil_Core.getProperty targeting the same WUC_PACKAGE component and WUC_GET_LOCAL_PROPERTY key to read back the value resolved by the bean, storing it in the local result variable.
- Step 5 - Return the result value (VARCHAR2, up to 255 characters) to the caller; if propertyName was null, result remains NULL and is returned as such.
- Step 6 - If a WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during property interaction, display an error alert identifying the missing bean class and raise FORM_TRIGGER_FAILURE to halt processing.
- Step 7 - If a WebUtil_Core.PROPERTY_ERROR exception is raised, raise FORM_TRIGGER_FAILURE to halt processing without an additional alert.

---
**Decision Points**

DP-001

Condition: propertyName IS NOT NULL

TRUE: Proceed to call WebUtil_Core.setProperty and WebUtil_Core.getProperty to retrieve the client setting value.

FALSE: Skip all bean interaction; return NULL to the caller.

DP-002

Condition: WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during bean property interaction.

TRUE: Display an error alert containing the bean implementation class name and raise FORM_TRIGGER_FAILURE, aborting the calling trigger.

FALSE: No bean registration error; continue normal processing.

DP-003

Condition: WebUtil_Core.PROPERTY_ERROR exception is raised during bean property interaction.

TRUE: Raise FORM_TRIGGER_FAILURE immediately, aborting the calling trigger without displaying an additional alert.

FALSE: No property error; return the retrieved value normally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A null propertyName must not trigger any bean interaction; the function must return NULL without invoking WebUtil_Core set or get operations.
- BR-002 - The returned client setting value must not exceed 255 characters, as enforced by the result variable declaration.
- BR-003 - If the WebUtil Core bean is not registered at the time of invocation, the function must surface a descriptive error alert identifying the missing bean class before terminating, ensuring the operator is informed of the missing infrastructure component.
- BR-004 - Any BEAN_NOT_REGISTERED or PROPERTY_ERROR condition must result in FORM_TRIGGER_FAILURE being raised, preventing the calling form trigger from continuing with an unresolved or erroneous client setting value.
- BR-005 - Property retrieval is performed exclusively through WebUtil_Core.setProperty and WebUtil_Core.getProperty using the WUC_PACKAGE component identifier and the WUC_GET_LOCAL_PROPERTY key; no direct database or file-system access is permitted.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetClientSetting(propertyName in VARCHAR2) return VARCHAR2 is 
    result VARCHAR2(255 char);
  BEGIN
    if propertyName is not null then 
    WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_GET_LOCAL_PROPERTY', propertyName);
       result := WebUtil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_GET_LOCAL_PROPERTY');
    end if;
    return result;
  EXCEPTION  
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                            ||' bean not found. WEBUTIL_CORE.GetClientSetting will not work');
    RAISE FORM_TRIGGER_FAILURE;  
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE FORM_TRIGGER_FAILURE;       
  END GetClientSetting;
```

#### SP-038 - WEBUTIL.GETIMPLCLASS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the implementation class name associated with a given WebUtil package identifier. Used in error messages to identify which WebUtil bean is not registered or not functioning correctly.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Query the WebUtil core bean for the implementation class property of the specified package.
- Step 2 - Return the class name string to the caller.

---
**Decision Points**

No conditional branches - reads and returns a single property value.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - No form-specific business rules - WebUtil infrastructure utility for bean identification in error messages.

---
**Implementation Logic**

```plsql

  FUNCTION getImplClass(packageID PLS_INTEGER) return VARCHAR2 is
  BEGIN 
    return WEBUTIL_JAVA_ROOT||m_implClasses(packageID);    
  END;
```

#### SP-039 - WEBUTIL.GETLASTERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the last error code recorded by the AppServerFileReader Java object on the application server. This function is used within the WebUtil file-transfer context to obtain an integer error status from the underlying Java layer after a file-read operation has been attempted, allowing the calling logic (WEBUTIL.SETDATA) to assess whether the preceding operation completed successfully.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the AppServerFileReader Java object reference (obj) as the target instance on which the error-code retrieval will be performed.
- Step 2 - Clear the JNI argument list by setting args to NULL, ensuring no stale arguments are passed to the Java method call.
- Step 3 - Invoke the Java instance method getLastError() on the AppServerFileReader class via JNI.CALL_INT_METHOD, passing FALSE (non-static call), the object reference, the fully qualified class name, the method name, and the method signature '()I' (no parameters, returns integer).
- Step 4 - Return the integer error code obtained from the Java method to the caller.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function unconditionally clears the argument list and delegates to the Java layer, returning whatever integer value the AppServerFileReader.getLastError() method provides.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The args variable must be set to NULL before the JNI call to guarantee that no residual argument data from a prior operation is inadvertently passed to the getLastError() Java method.
- BR-002 - The function must target the non-static instance method getLastError() on the oracle/forms/webutil/fileTransfer/AppServerFileReader class, identified by the method signature '()I', ensuring the error code is retrieved from the correct object instance supplied by the caller.
- BR-003 - The returned value is a raw integer error code sourced directly from the Java layer; no transformation or validation is applied within this function, placing responsibility for interpreting the code on the invoking routine (WEBUTIL.SETDATA).

---
**Implementation Logic**

```plsql
  FUNCTION getLastError(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_INT_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'getLastError', '()I', args); 
  END;
```

#### SP-040 - WEBUTIL.GETLASTERRORARGS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the argument string associated with the last error raised by the AppServerFileReader Java class. The function delegates the call to the underlying JNI layer, passing the provided Java object reference, and returns the error argument string to the caller (WEBUTIL.SETDATA) for error-context reporting during file-transfer operations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the Java object reference (obj) that represents an active AppServerFileReader instance.
- Step 2 - Reset the local args variable to NULL to ensure no residual argument data from a prior call is carried forward.
- Step 3 - Invoke the JNI.CALL_STRING_METHOD bridge, targeting the 'getLastErrorArgs' method on the 'oracle/forms/webutil/fileTransfer/AppServerFileReader' Java class, passing the NULL args value and the supplied obj reference.
- Step 4 - Return the VARCHAR2 string produced by the JNI call to the caller, representing the error argument details from the last recorded error on the AppServerFileReader instance.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a single, unconditional JNI method invocation and returns its result directly.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The args local variable must be set to NULL before the JNI call is made, ensuring that no stale argument data from any previous invocation is passed to the AppServerFileReader.getLastErrorArgs method.
- BR-002 - The function must target the exact Java class path 'oracle/forms/webutil/fileTransfer/AppServerFileReader' and method signature '()Ljava/lang/String;'; any deviation would result in an incorrect or failed JNI dispatch.
- BR-003 - The function returns the raw string value supplied by the JNI layer without transformation; interpretation of the returned error argument string is the responsibility of the calling routine (WEBUTIL.SETDATA).

---
**Implementation Logic**

```plsql
  FUNCTION getLastErrorArgs(
    obj   ORA_JAVA.JOBJECT) RETURN VARCHAR2 IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_STRING_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'getLastErrorArgs', '()Ljava/lang/String;', args); 
  END;
```

#### SP-041 - WEBUTIL.GETNUMBER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Extracts a delimited field from a source string at a specified positional index and converts the result to a numeric value. It serves as a numeric-typed convenience wrapper around WEBUTIL.GETSTRING (SP-045), enabling callers within the WebUtil custom event handler to retrieve number-typed data from structured delimited strings without performing an explicit type conversion.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Source_string | varchar2 | IN |
| Field_position | number | IN |
| UnTerminated | Boolean | IN |
| Delimiter | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETSTRING ([SP-045](#SP-045--WEBUTIL.GETSTRING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the source delimited string, the target field position, an optional flag indicating whether the string is unterminated, and an optional delimiter character (defaulting to a comma).
- Step 2 - Delegate field extraction to WEBUTIL.GETSTRING (SP-045), passing all four arguments unchanged to obtain the raw VARCHAR2 value at the specified position.
- Step 3 - Apply Oracle's TO_NUMBER function to the VARCHAR2 result returned by WEBUTIL.GETSTRING to convert it to a numeric data type.
- Step 4 - Return the resulting NUMBER value to the caller.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The procedure unconditionally delegates to WEBUTIL.GETSTRING and applies TO_NUMBER to the result; all positional and delimiter branching logic is encapsulated within WEBUTIL.GETSTRING.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The field position must correspond to a valid, numeric-valued token within the source string; if WEBUTIL.GETSTRING returns a non-numeric string, TO_NUMBER will raise a runtime conversion error.
- BR-002 - The delimiter parameter defaults to a comma (',') if not supplied by the caller; callers using a non-standard delimiter must pass it explicitly.
- BR-003 - The UnTerminated flag defaults to FALSE if not supplied; callers must set it to TRUE only when the source string does not end with a delimiter after the final token.
- BR-004 - The procedure has no output parameters; the numeric result is returned exclusively as the function's return value and must be captured by the caller.

---
**Implementation Logic**

```plsql

    
  function  GetNumber (Source_string    in varchar2,
                       Field_position   in number,
                       UnTerminated     in Boolean  default FALSE,
                       Delimiter        in varchar2 default ',') return number is
                       iRc              pls_integer;
  begin 
    Return to_number(GetString(Source_string, Field_Position, UnTerminated, Delimiter));
  end GetNumber; /* Number Version */
```

#### SP-042 - WEBUTIL.GETOSFAMILY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines and caches the client operating system family by inspecting the provided OS name string. The function maps the raw OS name to a predefined platform constant (WIN32, MAC, LINUX, SOLARIS, HP, AIX, or UNKNOWN) and stores the result in the package-level variable m_clientOSFamily so that subsequent calls return the cached value without re-evaluating the string. It is invoked by WEBUTIL.REGISTERBEAN to establish the client platform context required for bean registration.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| osName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input OS name string (osName) and convert it to lowercase, storing the result in the local variable l_osName to enable case-insensitive matching.
- Step 2 - Initialise the local result variable to CLIENT_PLATFORM_UNKNOWN as the default platform value.
- Step 3 - Check whether the package-level cache variable m_clientOSFamily is NULL. If it is NOT NULL, skip all classification logic and proceed directly to Step 10, returning the already-cached value.
- Step 4 - If m_clientOSFamily IS NULL, evaluate l_osName for the substring 'windows'. If found, set result to CLIENT_PLATFORM_WIN32.
- Step 5 - If 'windows' was not found, evaluate l_osName for the substring 'mac'. If found, set result to CLIENT_PLATFORM_MAC.
- Step 6 - If 'mac' was not found, evaluate l_osName for the substring 'linux'. If found, set result to CLIENT_PLATFORM_LINUX.
- Step 7 - If 'linux' was not found, evaluate l_osName for the substrings 'solaris' or 'sunos'. If either is found, set result to CLIENT_PLATFORM_SOLARIS.
- Step 8 - If neither Solaris indicator was found, evaluate l_osName for the substring 'hp-ux'. If found, set result to CLIENT_PLATFORM_HP.
- Step 9 - If 'hp-ux' was not found, evaluate l_osName for the substring 'aix'. If found, set result to CLIENT_PLATFORM_AIX.
- Step 10 - Assign the resolved result value to the package-level variable m_clientOSFamily, persisting it for future calls.
- Step 11 - Return m_clientOSFamily to the caller.

---
**Decision Points**

DP-001

Condition: m_clientOSFamily IS NULL (no cached OS family value exists for this session).

TRUE: Execute the full OS name classification logic (DP-002 through DP-007) and populate m_clientOSFamily with the resolved platform constant.

FALSE: Bypass all classification logic and return the previously cached value of m_clientOSFamily immediately.

---

DP-002

Condition: The lowercase OS name string contains the substring 'windows'.

TRUE: Set result to CLIENT_PLATFORM_WIN32.

FALSE: Proceed to DP-003.

---

DP-003

Condition: The lowercase OS name string contains the substring 'mac'.

TRUE: Set result to CLIENT_PLATFORM_MAC.

FALSE: Proceed to DP-004.

---

DP-004

Condition: The lowercase OS name string contains the substring 'linux'.

TRUE: Set result to CLIENT_PLATFORM_LINUX.

FALSE: Proceed to DP-005.

---

DP-005

Condition: The lowercase OS name string contains the substring 'solaris' OR the substring 'sunos'.

TRUE: Set result to CLIENT_PLATFORM_SOLARIS.

FALSE: Proceed to DP-006.

---

DP-006

Condition: The lowercase OS name string contains the substring 'hp-ux'.

TRUE: Set result to CLIENT_PLATFORM_HP.

FALSE: Proceed to DP-007.

---

DP-007

Condition: The lowercase OS name string contains the substring 'aix'.

TRUE: Set result to CLIENT_PLATFORM_AIX.

FALSE: result remains CLIENT_PLATFORM_UNKNOWN (no recognised OS keyword was matched).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - OS name matching is case-insensitive; the input string is converted to lowercase before any comparison is performed, ensuring that variations in OS name casing (e.g., 'Windows', 'WINDOWS', 'windows') are all correctly identified.
- BR-002 - Platform classification follows a strict precedence order: Windows is evaluated first, followed by Mac, Linux, Solaris/SunOS, HP-UX, and AIX. An OS name that matches an earlier keyword will never be reclassified by a later keyword.
- BR-003 - If the OS name does not contain any of the recognised keywords, the platform is classified as CLIENT_PLATFORM_UNKNOWN; no error is raised and processing continues normally.
- BR-004 - The resolved OS family is cached in the package-level variable m_clientOSFamily after the first successful evaluation. All subsequent invocations within the same session return the cached value without re-evaluating the OS name string, regardless of the osName argument passed.
- BR-005 - Solaris platform detection accepts two alternative OS name indicators ('solaris' and 'sunos') to accommodate both the commercial Solaris name and its underlying SunOS kernel identifier.

---
**Implementation Logic**

```plsql
 
  FUNCTION getOSFamily(osName in VARCHAR2) return PLS_INTEGER is
    l_osName VARCHAR2(30) := lower(osName);
    result   PLS_INTEGER  := CLIENT_PLATFORM_UNKNOWN;
  BEGIN
    if m_clientOSFamily  is null then 
      if (instr(l_osName,'windows') > 0) then 
           result := CLIENT_PLATFORM_WIN32;
      elsif instr(l_osName,'mac') > 0 then 
          result := CLIENT_PLATFORM_MAC;      
      elsif instr(l_osName,'linux') > 0 then 
          result := CLIENT_PLATFORM_LINUX;      
      elsif instr(l_osName,'solaris') > 0 OR instr(l_osName, 'sunos') > 0 then 
          result := CLIENT_PLATFORM_SOLARIS;       
      elsif instr(l_osName,'hp-ux') > 0 then 
          result := CLIENT_PLATFORM_HP; 
      elsif instr(l_osName,'aix') > 0 then 
          result := CLIENT_PLATFORM_AIX;                                                       
      end if;            
      m_clientOSFamily := result;
    end if;
    return m_clientOSFamily;
  END getOSFamily;
```

#### SP-043 - WEBUTIL.GETOUTPUT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GET_STANDARD_OUTPUT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the standard output text produced by a previously executed client-side process. Returns the output as a string for the caller to inspect or display.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |
| prop | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.INIT ([SP-052](#SP-052--WEBUTIL.INIT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the process identifier of a completed client-side process.
- Step 2 - Query the WebUtil host bean for the standard output associated with that process.
- Step 3 - Return the output string to the caller.

---
**Decision Points**

No conditional branches - reads and returns a single property value.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - No form-specific business rules - WebUtil infrastructure utility for retrieving process output.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetOutput(process in PROCESS_ID, prop in VARCHAR2) return OUTPUT_ARRAY is   
    lines  OUTPUT_ARRAY;
    i      PLS_INTEGER := 1;
    buffer VARCHAR2(257 char);
    status VARCHAR2(1) := 'X';
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_PROC_ID',process.handle);
    LOOP
      buffer := WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,prop);
      status := substr(buffer,1,1);
      -- Status can be Y: indicating more lines to follow,
      --               N: indicating that this is the last line
      --               X: indicating that the buffer was empty
      if status <> 'X' then 
        lines(i) := substr(buffer,2);
        i := i + 1;
      end if;
      exit when status <> 'Y';
    END LOOP;
    return lines;    
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.GetOutput will not work');
  END GetOutput;  
  
BEGIN
    -- Ensure that Core is instanciated.
    Webutil_Core.Init;
END;

PACKAGE WEBUTIL_SEPARATEFRAME IS

/*********************************************************************************\
 * WEBUTIL_SEPARATEFRAME
 *   This Package contains routines to interact with the MDI frame when Forms
 *   is running with the parameter separateFrame=true
 *   The functions in this package will work with any client type - not just 
 *   Windows clients.
 *   The oracle.forms.webutil.browser.BrowserFunctions bean is needed in your 
 *   Form to use these functions
 *********************************************************************************
 * Version 1.0.0
 *********************************************************************************
 * Change History
 *   1.0.0 DRMILLS 25/MAY/2003 - Creation
 *   1.0.1 DRMILLS 27/MAY/2003 - Added call to get frame size 
 *
\*********************************************************************************/

  /**
   *  IsSeparateFrame - Allows you to check if the form 
   *                is running in separateFrame mode or not
   */
```

#### SP-044 - WEBUTIL.GETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FOPEN]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a named property value from a specified WebUtil bean package. Provides the fundamental get-property mechanism used throughout the WebUtil infrastructure to communicate with WebUtil beans.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept a package identifier and property name.
- Step 2 - Query the specified bean for the named property value.
- Step 3 - Return the property value string to the caller.

---
**Decision Points**

No conditional branches - reads and returns a single named property value.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - No form-specific business rules - WebUtil infrastructure utility providing the core property-read mechanism.

---
**Implementation Logic**

```plsql
  FUNCTION getProperty(
    a0    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'getProperty', '(Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-045 - WEBUTIL.GETSTRING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETNUMBER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Extracts and returns a single delimited field from a source string based on its ordinal position. Given a delimiter-separated string, the function locates the Nth token (where N is Field_Position) and returns it as a VARCHAR2 value. It is invoked by WEBUTIL.GETNUMBER to isolate a positional substring before numeric conversion.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Source_string | varchar2 | IN |
| Field_position | number | IN |
| UnTerminated | Boolean | IN |
| Delimiter | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-056](#SP-056--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the source string, the 1-based field position to extract, a flag indicating whether the string lacks a trailing delimiter (UnTerminated), and the delimiter character to use for parsing.
- Step 2 - Copy the source string into a local working variable (vcSourceStrCopy) to avoid mutating the input.
- Step 3 - If UnTerminated is TRUE, append the delimiter to the end of the working copy so that the final token is bounded and can be located consistently.
- Step 4 - Determine the start position (iPtrStart) of the target token: if Field_Position is greater than 1, locate the delimiter occurrence immediately before the target field (occurrence Field_Position - 1) and advance the pointer past the delimiter; otherwise set iPtrStart to 1 (beginning of the string).
- Step 5 - Determine the end position (iPtrEnd) of the target token by locating the Nth occurrence of the delimiter in the working copy, where N equals Field_Position.
- Step 6 - Extract and return the substring from iPtrStart for a length of (iPtrEnd - iPtrStart), which yields the content of the requested field without its surrounding delimiters.

---
**Decision Points**

DP-001

Condition: UnTerminated is TRUE.

TRUE: The delimiter is appended to the working copy of the source string before any parsing begins, ensuring the last field is bounded by a delimiter and can be located by subsequent INSTR calls.

FALSE: The source string is used as-is; it is assumed to already contain a trailing delimiter or the caller guarantees the requested field position exists within the string.

---

DP-002

Condition: Field_Position is greater than 1.

TRUE: The start pointer (iPtrStart) is calculated by finding the (Field_Position - 1)th occurrence of the delimiter and advancing past it by the length of the delimiter, positioning the pointer at the first character of the target token.

FALSE: Field_Position equals 1, so iPtrStart is set to 1, meaning extraction begins at the very start of the working string.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The delimiter is configurable and defaults to a comma (','); callers may supply any single or multi-character delimiter to support varied string formats.
- BR-002 - Field positions are 1-based; a Field_Position of 1 always refers to the first token in the string.
- BR-003 - When the source string does not carry a trailing delimiter after its last field, the caller must pass UnTerminated = TRUE so that the function appends one, ensuring the final token is correctly bounded and extractable.
- BR-004 - The function operates purely on the in-memory working copy of the source string; the original Source_string parameter is never modified.
- BR-005 - The function returns only the token content, excluding the surrounding delimiter characters; the extracted length is computed as (iPtrEnd - iPtrStart).
- BR-006 - The working string supports a maximum length of 32,000 characters (VARCHAR2(32000)), establishing the upper bound on source string size that this function can process.

---
**Implementation Logic**

```plsql

  function  GetString (Source_string    in varchar2,
                       Field_position   in number,
                       UnTerminated     in Boolean  default FALSE,
                       Delimiter        in varchar2 default ',') return varchar2 is
                       iPtrEnd          pls_integer     := 0;
                       iPtrStart        pls_integer     := 0;
                       vcSourceStrCopy  varchar2(32000)     := Source_string;
  begin
    if UnTerminated then 
      vcSourceStrCopy := vcSourceStrCopy||Delimiter;
    end if;

    if Field_Position > 1 then 
      iPtrStart := instr(vcSourceStrCopy,Delimiter,1,Field_Position-1)+ length(Delimiter);
    else
      iPtrStart := 1;
    end if ; 

    iPtrEnd     := instr(vcSourceStrCopy,Delimiter,1,Field_Position);
    return substr(vcSourceStrCopy,iPtrStart,(iPtrEnd-iPtrStart));
  end GetString; /* String Version */
```

#### SP-046 - WEBUTIL.GETVAR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Reads one or more environment or session variable values from the WebUtil bean and returns them. Supports retrieval of single or multiple variables depending on the overloaded variant called.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VARNAME | VARCHAR2 | IN |
| VARVALUE | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VARVALUE | VARCHAR2 | IN OUT |

---

**Dependencies**

- GET_ENVIRONMENT_STRING ([SP-078](#SP-078--GET_ENVIRONMENT_STRING)) - matched by member name
- READ_REGISTRY ([SP-081](#SP-081--READ_REGISTRY)) - matched by member name
- WEBUTIL.GETCLIENTOSFAMILY ([SP-036](#SP-036--WEBUTIL.GETCLIENTOSFAMILY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_STANDARD_OUTPUT ([SP-049](#SP-049--WEBUTIL.GET_STANDARD_OUTPUT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the variable name(s) to retrieve.
- Step 2 - Query the WebUtil bean for the specified variable value(s).
- Step 3 - Return the retrieved value(s) to the caller.

---
**Decision Points**

No conditional branches - reads and returns the requested variable values.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - No form-specific business rules - WebUtil infrastructure utility for reading session or environment variables.

---
**Implementation Logic**

```plsql

  PROCEDURE GETVAR(VARNAME IN VARCHAR2, VARVALUE IN OUT VARCHAR2) is
    unixOutput WebUtil_HOST.OUTPUT_ARRAY;
    hostHandle WebUtil_HOST.PROCESS_ID;
    varKey     VARCHAR2(100);
    iPos       PLS_INTEGER;
  BEGIN
    if WebUtil_Core.GetClientOSFamily = WebUtil_Core.CLIENT_PLATFORM_WIN32 then 
      -- read the client Registry
      VARVALUE := Client_Win_API_Environment.read_registry('HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE',VARNAME,false);
      if VARVALUE is null OR VARVALUE = '' then
        -- Could not get an Oracle variable in registry. Try to get from environment varialble
        -- java desupported System.getenv method until they supported it again in 1.5.
        -- We can still get the environment variables in windows using
        -- CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING
        VARVALUE := CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING(VARNAME);
      end if;
    elsif WebUtil_Core.GetClientOSFamily in (WebUtil_Core.CLIENT_PLATFORM_MAC,WebUtil_Core.CLIENT_PLATFORM_UNKNOWN) then 
      -- do nothing 
      null;
    else
      -- Unix Ports - do a env to get the environment and parse that
      hostHandle := WebUtil_HOST.Blocking('env');
      unixOutput := WebUtil_HOST.Get_Standard_Output(hostHandle);
      WebUtil_HOST.Release_Process(hostHandle);
      for i in 1..unixOutput.count LOOP
        iPos := instr(unixOutput(i),'=');
        if iPos > 0 then 
          varKey := substr(unixOutput(i),1,iPos-1);
          if varKey = VARNAME then 
            VARVALUE := substr(unixOutput(i),iPos+1);
            EXIT;
          end if;
        end if;
      end LOOP;
    end if;

  exception
    when NO_DATA_FOUND then
      VARVALUE := null;
  END GETVAR;

END CLIENT_TOOL_ENV;

PACKAGE Client_Win_API IS
/*-------------------------------------------------------------------------------*\
 * WebUtil version of D2KWUTIL package WIN_API                                     
 * Note: Not all D2kWutil Functions are ported
 *********************************************************************************
 * Version 1.0.0
 *********************************************************************************
 * Change History
 *   DRMILLS 21/FEB/2003 - Port Creation
 *
 *********************************************************************************
 * WIN_API ->  This package defines the constants used throughout 
 *      the library as a whole, including versions of those 
 *      constants defined within WINDOWS.H/WINUSER.H that 
 *      we'll be using. Add more constants in here if required
 *      The package also contains Explicit Exception declarations,
 *      various status Flags and functions for Error Handling
 * NOTE:    In order to make this library portable across Forms
 *      and Reports we do not use any application 
 *      specific built-ins such as the Forms MESSAGE() 
 *      Built-in. Instead errors are recorded in a package
 *      variable which the programmer can examine if required
\*-------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------*\
 * Internal Version Number  ** Oracle Developer Release 6.0 Version
\*-------------------------------------------------------------------------------*/
  WIN_API_VERSION  CONSTANT  VARCHAR2(30) := '6.0.6.0 Production';
  DLL_NAME         CONSTANT  VARCHAR2(12) := 'd2kwut60.dll';
  DLL_PATH         VARCHAR2(256)          := NULL;

/*-------------------------------------------------------------------------------*\
 * General Window Classes of Common Applications for use with WIN_API_SESSION
 * ** WARNING ** These Window classes are out of our control and might change 
 *               when you upgrade the software in question,
\*-------------------------------------------------------------------------------*/

  -- Oracle Apps
  WINCLASS_DEVELOPER_2000_V1  CONSTANT  VARCHAR2(15)  := 'ui23MDIroot_W32';             /* Developer/2000 release 1.n / Toolkit 2.3 Apps on 32 bit */
  WINCLASS_DEVELOPER_2000_V2  CONSTANT  VARCHAR2(15)  := 'ui25MDIroot_W32';             /* Developer/2000 Release 2.0 / Toolkit 2.5 Apps on 32 bit */
  WINCLASS_DEVELOPER_2000_V6  CONSTANT  VARCHAR2(15)  := 'ui60MDIroot_W32';             /* Developer/2000 Release 6.0 / Toolkit 6.0 Apps on 32 bit */  
  D2K_WINDOW_CLASS            CONSTANT  VARCHAR2(15)  := WINCLASS_DEVELOPER_2000_V6;    /* Set to the "current" version */  
  WINCLASS_INTEROFFICE_40     CONSTANT  VARCHAR2(28)  := 'Afx:10000000:b:10008:6:5023b';/* Oracle Interoffice 4.0 Client 32 bit */
  WINCLASS_INTEROFFICE_41     CONSTANT  VARCHAR2(28)  := 'Afx:10000000:b:1496:6:3a17';  /* Oracle Interoffice 4.0 Client 32 bit */
  WINCLASS_SQLPLUS            CONSTANT  VARCHAR2(13)  := 'SqlplusWClass';               /* Sql*Plus 32 bit */
  WINCLASS_REPORTSSERVER_V1   CONSTANT  VARCHAR2(15)  := 'R25SRV_WINCLASS';             /* Reports Server Reports 2.5 */
  WINCLASS_REPORTSSERVER_V2   CONSTANT  VARCHAR2(15)  := 'R30SRV_WINCLASS';             /* Reports Server Reports 3.0 */
  WINCLASS_REPORTSSERVER_V6   CONSTANT  VARCHAR2(14)  := 'RWRBE_WINCLASS';              /* Reports Server Reports 6.0 */

  -- Microsoft Office Apps - Office97
  WINCLASS_MSWORD_97         CONSTANT  VARCHAR2(7) := 'OpusApp';                        /* Microsoft Word 97 */
  WINCLASS_MSEXCEL_97        CONSTANT  VARCHAR2(6) := 'XLMAIN';                         /* Microsoft Excel 97 */
  WINCLASS_MSPOWERPOINT_97   CONSTANT  VARCHAR2(14):= 'PP97FrameClass';                 /* Microsoft Power Point 97 */

  -- Microsoft Office Apps - Office95
  WINCLASS_MSWORD_7          CONSTANT  VARCHAR2(7) := 'OpusApp';                        /* Microsoft Word 7 */
  WINCLASS_MSEXCEL_7         CONSTANT  VARCHAR2(6) := 'XLMAIN';                         /* Microsoft Excel 7 */
  WINCLASS_MSPOWERPOINT_7    CONSTANT  VARCHAR2(13):= 'PP7FrameClass';                  /* Microsoft Power Point 7 */
  WINCLASS_MSSCHEDULE_7      CONSTANT  VARCHAR2(23):= 'MS Schedule+ 32 Panesdi';        /* Microsoft Schedule 7 */
  WINCLASS_MSEXCHANGE_4      CONSTANT  VARCHAR2(29):= 'Microsoft Exchange 4.0 Viewer';  /* Microsoft Exchange 4 in-tray */

  -- Microsoft O/S Utilities
  WINCLASS_INETEXPLORER      CONSTANT  VARCHAR2(7):= 'IEFrame';                         /* Internet Explorer */
  WINCLASS_OUTLOOK_EXPRESS   CONSTANT  VARCHAR2(29):= 'Outlook Express Browser Class';  /* Outlook Express */
  WINCLASS_EXPLORER          CONSTANT  VARCHAR2(13):= 'ExploreWClass';                  /* Explorer */
  WINCLASS_MYCOMPUTER        CONSTANT  VARCHAR2(13):= 'CabinetWClass';                  /* My Computer & Network Neighborhood*/
  WINCLASS_CALCULATOR        CONSTANT  VARCHAR2(7) := 'SciCalc';                        /* Windows Calculator */
  WINCLASS_NOTEPAD           CONSTANT  VARCHAR2(7) := 'Notepad';                        /* Windows Notepad */
  WINCLASS_WORDPAD           CONSTANT  VARCHAR2(12):= 'WordPadClass';                   /* Windows Wordpad/Write */
  WINCLASS_DOS               CONSTANT  VARCHAR2(18):= 'ConsoleWindowClass';             /* Dos Window */

  -- Other
  WINCLASS_NETSCAPE_3        CONSTANT  VARCHAR2(27):= 'Afx:40000000:b:150e:6:38cfe';    /* Netscape Navigator 3.0 */
  WINCLASS_NETSCAPE_4        CONSTANT  VARCHAR2(28):= 'Afx:40000000:b:10008:6:6063e';   /* Netscape Communicator 4.0 */
  WINCLASS_PFE_7             CONSTANT  VARCHAR2(11):= 'PFE32_Frame';                    /* Programmers File Editor */
  WINCLASS_REGEDIT           CONSTANT  VARCHAR2(15):= 'RegEdit_RegEdit';                /* Registry Editor */

  -- Window Style Constants (from WINUSER.H)
  --  Any PU's that use these constants will explain 
  --  their use.  For further information consult the
  --  Windows SDK.

  SW_HIDE              CONSTANT  PLS_INTEGER := 0;
  SW_SHOWNORMAL        CONSTANT  PLS_INTEGER := 1;
  SW_SHOWMINIMIZED     CONSTANT  PLS_INTEGER := 2;
  SW_SHOWMAXIMIZED     CONSTANT  PLS_INTEGER := 3;
  SW_SHOWNOACTIVATE    CONSTANT  PLS_INTEGER := 4;
  SW_SHOW              CONSTANT  PLS_INTEGER := 5;
  SW_MINIMIZE          CONSTANT  PLS_INTEGER := 6;
  SW_SHOWMINNOACTIVE   CONSTANT  PLS_INTEGER := 7;
  SW_SHOWNA            CONSTANT  PLS_INTEGER := 8;
  SW_RESTORE           CONSTANT  PLS_INTEGER := 9;
  SW_SHOWDEFAULT       CONSTANT  PLS_INTEGER := 10;

  -- Help Access Constants (From WINUSER.H)
  --  See WIN_API_SHELL.WinHelp

  HELP_CONTEXT         CONSTANT  PLS_INTEGER := 1;   /* 0x0001L */
  HELP_QUIT            CONSTANT  PLS_INTEGER := 2;   /* 0x0002L */
  HELP_INDEX           CONSTANT  PLS_INTEGER := 3;   /* 0x0003L */
  HELP_CONTENTS        CONSTANT  PLS_INTEGER := 3;   /* 0x0003L */
  HELP_HELPONHELP      CONSTANT  PLS_INTEGER := 4;   /* 0x0004L */
  HELP_SETINDEX        CONSTANT  PLS_INTEGER := 5;   /* 0x0005L */
  HELP_SETCONTENTS     CONSTANT  PLS_INTEGER := 5;   /* 0x0005L */
  HELP_CONTEXTPOPUP    CONSTANT  PLS_INTEGER := 8;   /* 0x0008L */
  HELP_FORCEFILE       CONSTANT  PLS_INTEGER := 9;   /* 0x0009L */
  HELP_KEY             CONSTANT  PLS_INTEGER := 257; /* 0x0101L */
  HELP_COMMAND         CONSTANT  PLS_INTEGER := 258; /* 0x0102L */
  HELP_PARTIALKEY      CONSTANT  PLS_INTEGER := 261; /* 0x0105L */
  HELP_MULTIKEY        CONSTANT  PLS_INTEGER := 513; /* 0x0201L */
  HELP_SETWINPOS       CONSTANT  PLS_INTEGER := 515; /* 0x0203L */
  -- Windows 4+
  HELP_CONTEXTMENU     CONSTANT  PLS_INTEGER := 10;  /* 0x000a  */
  HELP_FINDER          CONSTANT  PLS_INTEGER := 11;  /* 0x000b  */
  HELP_WM_HELP         CONSTANT  PLS_INTEGER := 12;  /* 0x000c  */
  HELP_SETPOPUP_POS    CONSTANT  PLS_INTEGER := 13;  /* 0x000d  */

  -- Windows Messages for use with SendMessage
  -- DO NOT utilise the Windows Sendmessage interface without being conversant
  -- with the Windows message handling mechanism
  -- Refer to the Microsoft Windows SDK for Messages and Parameter values
  WM_SYSCOMMAND        CONSTANT  PLS_INTEGER := 274;   /* 0x0112 */
  WM_MDITILE           CONSTANT  PLS_INTEGER := 550;   /* 0x0226 */
  WM_MDICASCADE        CONSTANT  PLS_INTEGER := 551;   /* 0x0227 */
  WM_MDIICONARRANGE    CONSTANT  PLS_INTEGER := 552;   /* 0x0228 */      
  SC_RESTORE           CONSTANT  PLS_INTEGER := 61728; /* 0xF120 */
  SC_MINIMIZE          CONSTANT  PLS_INTEGER := 61472; /* 0xF020 */
  SC_MAXIMIZE          CONSTANT  PLS_INTEGER := 61488; /* 0xF030 */
  

  -- Flags for use with File Dialog boxes ("Save As" or "Open")
  -- Refer to your Microsoft documentation for details on the 
  -- Exact usage and dependancies of each option
  OFN_READONLY           CONSTANT  PLS_INTEGER := 1;        /* 0x00000001 */
  OFN_OVERWRITEPROMPT    CONSTANT  PLS_INTEGER := 2;        /* 0x00000002 */
  OFN_HIDEREADONLY       CONSTANT  PLS_INTEGER := 4;        /* 0x00000004 */
  OFN_NOCHANGEDIR        CONSTANT  PLS_INTEGER := 8;        /* 0x00000008 */
  OFN_SHOWHELP           CONSTANT  PLS_INTEGER := 16;       /* 0x00000010 */
  OFN_NOVALIDATE         CONSTANT  PLS_INTEGER := 256;      /* 0x00000100 */
  OFN_ALLOWMULTISELECT   CONSTANT  PLS_INTEGER := 512;      /* 0x00000200 */
  OFN_EXTENSIONDIFFERENT CONSTANT  PLS_INTEGER := 1024;     /* 0x00000400 */
  OFN_PATHMUSTEXIST      CONSTANT  PLS_INTEGER := 2048;     /* 0x00000800 */
  OFN_FILEMUSTEXIST      CONSTANT  PLS_INTEGER := 4096;     /* 0x00001000 */
  OFN_CREATEPROMPT       CONSTANT  PLS_INTEGER := 8192;     /* 0x00002000 */
  OFN_SHAREAWARE         CONSTANT  PLS_INTEGER := 16384;    /* 0x00004000 */
  OFN_NOREADONLYRETURN   CONSTANT  PLS_INTEGER := 32768;    /* 0x00008000 */
  OFN_NOTESTFILECREATE   CONSTANT  PLS_INTEGER := 65536;    /* 0x00010000 */
  OFN_NONETWORKBUTTON    CONSTANT  PLS_INTEGER := 131072;   /* 0x00020000 */
  OFN_NOLONGNAMES        CONSTANT  PLS_INTEGER := 262144;   /* 0x00040000 */
  OFN_EXPLORER           CONSTANT  PLS_INTEGER := 524288;   /* 0x00080000 */
  OFN_NODEREFERENCELINKS CONSTANT  PLS_INTEGER := 1048576;  /* 0x00100000 */
  OFN_LONGNAMES          CONSTANT  PLS_INTEGER := 2097152;  /* 0x00200000 */

  -- The defaults used here (WIN_API.OFN_PATHMUSTEXIST|WIN_API.OFN_FILEMUSTEXIST|WIN_API.OFN_HIDEREADONLY|WIN_API.OFN_NOCHANGEDIR|WIN_API.OFN_EXPLORER)
  OFN_FLAG_DEFAULT       CONSTANT  PLS_INTEGER :=  530444;
  
  
  -- Registry Data types for Write_RegistryEx
  REG_EXPAND_SZ          CONSTANT  PLS_INTEGER := 0;
  REG_SZ                 CONSTANT  PLS_INTEGER := 1;
  REG_DWORD              CONSTANT  PLS_INTEGER := 2;
  
  -- Compatibility Flags - Used where I have changed behaviour and you might not like the new version
  -- Change these at runtime to FALSE to revert to "old" behaviour
  COMPAT_EXPAND_REG_VALUES    BOOLEAN := TRUE;

  
  
  -- Types
  TYPE aFunctionHandle is table of WEBUTIL_C_API.FUNCTIONHANDLE index by BINARY_INTEGER;  
  SUBTYPE FILE_TYPE is PLS_INTEGER;

  -- Public Variables
  ERROR_ENCOUNTERED  BOOLEAN := FALSE;  /* The Last Call resulted in an error */
  ERROR_STACK        VARCHAR2(2000);    /* Holds Text of Last error(s) */ 
  API_ENABLED        BOOLEAN := FALSE;   /* Are API functions usable ?*/
  DLL_HANDLE         ORA_FFI.LibHandleType;
  FunctionHandle     aFunctionHandle;
   

  -- Public Exceptions
  NOT_AVAILABLE      EXCEPTION;  /* A call to the API was made but API functions not currently available (e.g. not on Windows) */
     
  -- Error Constants
  UError             CONSTANT  VARCHAR2(30) := ' Caused an unexpected error: ';
  NoAPI              CONSTANT  VARCHAR2(31) := 'API Functions are not Available';
  MaxDWord           CONSTANT  VARCHAR2(33) := 'Integer Argument exceeds 32 bits ';
  MaxWord            CONSTANT  VARCHAR2(33) := 'Integer Argument exceeds 16 bits ';
  MaxByte            CONSTANT  VARCHAR2(32) := 'Integer Argument exceeds 8 bits ';
  MinBound           CONSTANT  VARCHAR2(27) := 'Integer Argument too Small ';
  MaxBound           CONSTANT  VARCHAR2(27) := 'Integer Argument too Large ';
  NullArg            CONSTANT  VARCHAR2(24) := 'Argument cannot be NULL ';

  /*----------------------------------------------------------------------------*\
  * PreLoad ->  Loads the d2kwut60.dll from the jvm bin directory into memory
  \*----------------------------------------------------------------------------*/
```

#### SP-047 - WEBUTIL.GET_LINE

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Reads a single line of text from an open file on the application server, using the file handle returned by a prior file-open call. Returns the text of the line to the caller.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| item | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the file handle of an open server-side file.
- Step 2 - Read the next available line of text from the file via the WebUtil file I/O bean.
- Step 3 - Return the line text to the caller.

---
**Decision Points**

No conditional branches - reads and returns the next line from the file.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - No form-specific business rules - WebUtil infrastructure utility for reading lines from server-side files.

---
**Implementation Logic**

```plsql
  PROCEDURE get_line (file file_type, item OUT VARCHAR2) is
    buffer VARCHAR2(4000 char);
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);        
    buffer := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_GETLINE');
    -- We can't easily tell the difference between an empty line and a line beyond then 
    -- end of the file so to get around this, the exception handling code in the PJC 
    -- places a newline into the buffer when the end of file is passed.
    -- The rational being that get_line would never normally return a newline because 
    -- it normally uses that to tell it where to read up *to*.
    if buffer = chr(10) then 
      raise NO_DATA_FOUND;
    else
      item := buffer;
    end if;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.get_line will not work');
      RAISE TOOL_ERR.TOOL_ERROR;                                                                 
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE TOOL_ERR.TOOL_ERROR;  
  END get_line;
  
  /**
   * File writing functions
   */
```

#### SP-048 - WEBUTIL.GET_RETURN_CODE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.HOST]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the integer return code produced by a previously executed client-side native function call. Allows the calling code to determine whether the native function succeeded or failed.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the process or function identifier.
- Step 2 - Query the WebUtil bean for the return code associated with that call.
- Step 3 - Return the integer return code to the caller.

---
**Decision Points**

No conditional branches - reads and returns a single return code value.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - No form-specific business rules - WebUtil infrastructure utility for retrieving native function return codes.

---
**Implementation Logic**

```plsql
  
  
  FUNCTION Get_Return_Code(process in PROCESS_ID) return PLS_INTEGER is
  begin 
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_PROC_ID',process.handle);
    return to_number(WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,'WUH_RC'));
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
       WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                               ||' bean not found. WEBUTIL_HOST.Get_Return_Code will not work');
  end Get_Return_Code;
```

#### SP-049 - WEBUTIL.GET_STANDARD_OUTPUT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves all standard output text captured from a client-side process that was executed via the WebUtil host bean. Returns the complete output as a string.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETOUTPUT ([SP-043](#SP-043--WEBUTIL.GETOUTPUT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the process identifier of a previously executed client-side process.
- Step 2 - Query the WebUtil host bean for the captured standard output.
- Step 3 - Return the output string to the caller.

---
**Decision Points**

No conditional branches - reads and returns the captured standard output.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - No form-specific business rules - WebUtil infrastructure utility for capturing process standard output.

---
**Implementation Logic**

```plsql
    
  FUNCTION Get_Standard_Output(process in PROCESS_ID) return OUTPUT_ARRAY is  
  begin 
    return GetOutput(process,'WUH_STDOUT');
  end Get_Standard_Output;
```

#### SP-050 - WEBUTIL.HOST

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Executes an operating system command on the client workstation in blocking (synchronous) mode by delegating to the Blocking function. The form waits for the command to finish before resuming.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.BLOCKING ([SP-021](#SP-021--WEBUTIL.BLOCKING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_RETURN_CODE ([SP-048](#SP-048--WEBUTIL.GET_RETURN_CODE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ID_NULL ([SP-051](#SP-051--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.RELEASE_PROCESS ([SP-065](#SP-065--WEBUTIL.RELEASE_PROCESS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the command string to execute on the client.
- Step 2 - Call the Blocking execution function with the command.
- Step 3 - Return the process identifier to the caller.

---
**Decision Points**

No conditional branches - delegates entirely to the Blocking function.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - No form-specific business rules - WebUtil wrapper for synchronous client-side command execution.

---
**Implementation Logic**

```plsql
  FUNCTION  Host(cmd in VARCHAR2) return PLS_INTEGER is
    procId PROCESS_ID;
    RC     PLS_INTEGER := -1;
  begin
    procId := Blocking(cmd);
    if not ID_NULL(procId) then
      RC := Get_Return_Code(procId);
      -- release the client side object
      Release_Process(procId);
    end if;
    return RC;
  end Host;
```

#### SP-051 - WEBUTIL.ID_NULL

**Invoked From:**

- DPL.pld [StoredProcedure: GENERAL.L_POP_LIST_ITEM]
- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]
- webutil.pld [StoredProcedure: WEBUTIL.ERRORALERT]
- webutil.pld [StoredProcedure: WEBUTIL.HOST]
- webutil.pld [StoredProcedure: WEBUTIL.INITWEBUTIL]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTER_FUNCTION]
- webutil.pld [StoredProcedure: WEBUTIL.SHOWBEANS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Tests whether a given WebUtil object handle is null (unset). Returns TRUE if the handle represents a null/unset object, FALSE otherwise. Used as a guard before performing operations on WebUtil handles.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| handle | Pointer | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the object handle to test.
- Step 2 - Evaluate whether the handle is null or zero.
- Step 3 - Return TRUE if null, FALSE if valid.

---
**Decision Points**

DP-001

Condition:
The handle value is null or zero

TRUE:
Return TRUE (the object is null/unset).

FALSE:
Return FALSE (the object is a valid handle).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - No form-specific business rules - WebUtil infrastructure utility for null-checking object handles.

---
**Implementation Logic**

```plsql

  FUNCTION ID_NULL(handle IN Pointer)        RETURN BOOLEAN is
  BEGIN
    if handle.hnd is null then 
      return TRUE;
    else
      return FALSE;
    end if;
  END ID_NULL;
```

#### SP-052 - WEBUTIL.INIT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETOUTPUT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Initialises the WebUtil infrastructure by locating and registering all required WebUtil bean components. Must be called once before any other WebUtil functions are used. Raises an error if required beans are not available.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.INITWEBUTIL ([SP-053](#SP-053--WEBUTIL.INITWEBUTIL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Locate and register each WebUtil bean required by the infrastructure (core, host, file I/O, C API, URL transfer, etc.).
- Step 2 - For each bean, verify that it is available and store its internal reference.
- Step 3 - If a required bean is missing, display an error alert and raise a trigger failure.
- Step 4 - Once all beans are registered, set the initialisation flag to indicate WebUtil is ready.

---
**Decision Points**

DP-001

Condition:
Each required WebUtil bean is found and available

TRUE:
Register the bean reference and continue initialisation.

FALSE:
Display a 'bean not found' error alert and raise a trigger failure.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - All WebUtil functionality depends on successful initialisation; any missing bean prevents WebUtil features from operating.
- BR-002 - Initialisation must be completed before any WebUtil function is called.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Init is
  begin 
    -- we don't need to do anything here - entering the package is enough to set it up.      
    null;
  end;      

BEGIN
  -- Initialise the Utility
  InitWebUtil;  
END WEBUTIL_CORE;

PACKAGE WEBUTIL_C_API IS
/*********************************************************************************\
 * WEBUTIL_C_API
 *   This Package provides a way of calling C functions in a shared library on the
 *   client PC. Currently only win32 is supported.
 *   The oracle.forms.webutil.cApi.CApiFunctions bean is needed in your Form to 
 *   use these functions
 *********************************************************************************
 * Version 1.0.5
 *********************************************************************************
 * Change History
 *   1.0.1 RVSUILIC 14/FEB/2003 - Creation 
 *   1.0.2 DRMILLS  27/FEB/2003 - Reset LONG to the same value as INT which is fine
 *                                for Windows & removed Tester proc
 *   1.0.3 DRMILLS  01/MAR/2003 - Re-worked the PL/SQL API
 *   1.0.4 DRMILLS  13/MAY/2003 - Added call to WebUtil_Core.Init
 *   1.0.5 RVSUILIC 21/MAY/2003 - Cleaned up some comments and formatting.
 *
\*********************************************************************************/

  /**
   *  Constants to represent PL/SQL IN, OUT and INOUT parameter qualifiers
   */
  PARAM_IN    CONSTANT PLS_INTEGER := 50;
  PARAM_INOUT CONSTANT PLS_INTEGER := 51;
  PARAM_OUT   CONSTANT PLS_INTEGER := 52;
  

  /**
   *  Constants to represent C atomic datatypes and pointers to atomic datatypes
   *  Note that to use OUT and INOUT qualifiers the C function in the DLL *must*
   *  use a pointer type to be able to pass information back.
   *
   *  The comments on the right indicate which types can be used for parameters
   *  and which for function return types.
   *
   *  c_ptr is used as a generic pointer. The onlys supported use for this is to
   *  save the pointer value from C into a PL/SQL variable, so that it may be 
   *  passed back later to C. No operations on the pointer are supported in PL/SQL.
   */
  c_void          CONSTANT PLS_INTEGER := 30;            /* - not used -   */
  c_char          CONSTANT PLS_INTEGER := 31;            /* param & return */
  c_short         CONSTANT PLS_INTEGER := 32;            /* param & return */
  c_int           CONSTANT PLS_INTEGER := 33;            /* param & return */
  c_long          CONSTANT PLS_INTEGER := 33;            /* param & return *//*DRM - same as INT */
  c_float         CONSTANT PLS_INTEGER := 35;            /* param & return */
  c_double        CONSTANT PLS_INTEGER := 36;            /* param & return */

  c_ptr           CONSTANT PLS_INTEGER := 64 + c_void;   /* param & return */
  c_char_ptr      CONSTANT PLS_INTEGER := 64 + c_char;   /* param          */
  c_short_ptr     CONSTANT PLS_INTEGER := 64 + c_short;  /* param          */
  c_int_ptr       CONSTANT PLS_INTEGER := 64 + c_int;    /* param          */
  c_long_ptr      CONSTANT PLS_INTEGER := 64 + c_long;   /* param          */
  c_float_ptr     CONSTANT PLS_INTEGER := 64 + c_float;  /* param          */
  c_double_ptr    CONSTANT PLS_INTEGER := 64 + c_double; /* param          */

  /**
   *  Abstracted types to be used for pointers and handles. The forms programmer
   *  should not attempt any manipulation on these types, but merely obtain them as
   *  a result of functions below, and pass them back in to other functions below.
   */
    SUBTYPE handleType   IS NUMBER;
    TYPE Pointer         IS RECORD (hnd handleType);   /* C pointer             */
    TYPE FunctionHandle  IS RECORD (hnd handleType);   /* function handle       */
    TYPE ParameterHandle IS RECORD (hnd handleType);   /* parameter handle      */
    TYPE ParameterList   IS RECORD (hnd handleType);   /* parameter list handle */

  /**
   *  IS_SUPPORTED - Check if the client is on a supported hardware platform.
   */
```

#### SP-053 - WEBUTIL.INITWEBUTIL

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.INIT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Public entry point for initialising the WebUtil infrastructure. Triggers the full WebUtil bean registration and setup process, making all WebUtil capabilities available to the form.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-051](#SP-051--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SHOWBEANS ([SP-069](#SP-069--WEBUTIL.SHOWBEANS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Call the internal INIT procedure to register all WebUtil beans and perform setup.
- Step 2 - If initialisation fails, the error is reported and a trigger failure is raised by the internal INIT procedure.

---
**Decision Points**

No conditional branches - delegates entirely to the internal INIT procedure.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - No form-specific business rules - public entry point for WebUtil infrastructure initialisation.

---
**Implementation Logic**

```plsql
  
  PROCEDURE InitWebUtil is
    startPoint VARCHAR2(61 char) := NAME_IN('SYSTEM.CURSOR_FIELD');
    hDummy     ITEM              := FIND_ITEM(WEBUTIL_DUMMY_ITEM);
  BEGIN
    -- Set up the various package we know about.
    m_implClasses(WUC_PACKAGE) := 'common.VBeanCommon'; 
    m_implClasses(WUT_PACKAGE) := 'fileTransfer.FileTransfer'; 
    m_implClasses(WUF_PACKAGE) := 'file.FileFunctions'; 
    m_implClasses(WUI_PACKAGE) := 'clientInfo.GetClientInfo'; 
    m_implClasses(WUH_PACKAGE) := 'host.Host'; 
    m_implClasses(WUS_PACKAGE) := 'session.SessionFunctions'; 
    m_implClasses(WUB_PACKAGE) := 'browser.BrowserFunctions'; 
    m_implClasses(WUO_PACKAGE) := 'ole.OleFunctions'; 
    m_implClasses(WUU_PACKAGE) := '';      
    m_implClasses(WUL_PACKAGE) := 'cApi.CApiFunctions';                     
    
    -- Now check for the Webutil Object group which 
    -- contains the Beans etc.
          
    if id_null(m_errorAlert) then 
      -- The Webutil error alert is not around
      -- so the Code cannot operate 
      message('The WEBUTIL object group is not available in this Form.  WebUtil cannot work');
      pause;
    else
      -- Bug 2955789 - this navigation causes problems if they are in Enter-Query mode 
      -- Plus it's not really needed, except as a belt and braces kind of setup.
      -- So put a check to prevent this in E-Q mode and set a top level flag to bypass it 
      -- it all together which we can switch on or off if required as a furture W/A    
      if FLAG_EXPICIT_INSTANCIATE and name_in('SYSTEM.MODE') = 'NORMAL' then 
        if not ID_NULL(hDummy) then 
          -- they are using the standard Object Group
          GO_ITEM(hDummy);
          if GET_ITEM_PROPERTY(startPoint,BLOCK_NAME) = GET_ITEM_PROPERTY(hDummy,BLOCK_NAME) then 
            NEXT_BLOCK;
          else
            GO_ITEM(startPoint);
          end if;
          ShowBeans(false);        
        else
          -- do nothing assume that the programmer is doing their own thing.
          -- with regards to setting up the bean areas and making sure they are drawn
           null;      
        end if;
      end if;
    end if;
        
    -- Work out the server o/s informtion that we need
    if instr(upper(GET_APPLICATION_PROPERTY(OPERATING_SYSTEM)),'WIN') > 0 then 
      m_serverFileSep := '\';
    else
      m_serverFileSep := '/';
    end if;
  END InitWebUtil;
```

#### SP-054 - WEBUTIL.ISERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Checks whether the WebUtil bean has recorded an error condition. Returns TRUE if an error is present, FALSE otherwise. Used as a guard to decide whether to inspect error details after a WebUtil operation.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Query the WebUtil bean for any recorded error condition.
- Step 2 - Return TRUE if an error is present, FALSE if no error has been recorded.

---
**Decision Points**

DP-001

Condition:
The WebUtil bean has a recorded error

TRUE:
Return TRUE.

FALSE:
Return FALSE.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - No form-specific business rules - WebUtil infrastructure utility for error-state checking.

---
**Implementation Logic**

```plsql
  FUNCTION isError   return BOOLEAN is
  begin 
    return m_lastError <> 0;
  end;
```

#### SP-055 - WEBUTIL.IS_OPEN

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Tests whether a server-side file represented by the supplied file handle is currently open. Returns TRUE if the file is open, FALSE otherwise.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the file handle to test.
- Step 2 - Query the WebUtil file I/O bean for the open status of the file handle.
- Step 3 - Return TRUE if the file is open, FALSE if it is closed or invalid.

---
**Decision Points**

DP-001

Condition:
The file handle represents a currently open file

TRUE:
Return TRUE.

FALSE:
Return FALSE.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - No form-specific business rules - WebUtil infrastructure utility for checking file open status.

---
**Implementation Logic**

```plsql
  
  FUNCTION is_open(file file_type) RETURN BOOLEAN IS
  BEGIN
    IF file.handle IS NULL THEN
      RETURN(FALSE);
    ELSE
      RETURN(TRUE);
    END IF;
  END is_open;
```

#### SP-056 - WEBUTIL.LENGTH

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: DEBUGLOG]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: STRIPDIRSEP]
- webutil.pld [StoredProcedure: WEBUTIL.GETSTRING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the length (in bytes or characters) of a server-side file identified by the supplied file handle. Used to determine file size before reading or transferring the file.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the file handle of an open server-side file.
- Step 2 - Query the WebUtil file I/O bean for the file length.
- Step 3 - Return the length value to the caller.

---
**Decision Points**

No conditional branches - reads and returns the file length.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - No form-specific business rules - WebUtil infrastructure utility for retrieving file length.

---
**Implementation Logic**

```plsql
  FUNCTION length(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_LONG_METHOD(FALSE, obj, 'java/io/File', 'length', '()J', args); 
  END;
```

#### SP-057 - WEBUTIL.LOG

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]
- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a diagnostic message to a server-side log file, controlling output based on runtime logging configuration (enabled flag, errors-only mode, and target file path) read from a property bundle. Used by the WebUtil infrastructure to support tracing in CHECKLIBS, REGISTERBEAN, and CUSTOMEVENTHANDLER operations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| msg | VARCHAR2 | IN |
| isError | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-029](#SP-029--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ISERROR ([SP-054](#SP-054--WEBUTIL.ISERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.IS_OPEN ([SP-055](#SP-055--WEBUTIL.IS_OPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.PUT_LINE ([SP-060](#SP-060--WEBUTIL.PUT_LINE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-061](#SP-061--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the message text and a Boolean flag indicating whether the message represents an error condition.
- Step 2 - If the logging configuration cache (m_loggingAllowed) has not yet been initialised, call WEBUTIL.READFROMPROPERTYBUNDLE to retrieve the 'logging.enabled', 'logging.errorsonly', and 'logging.file' property values and populate the module-level cache variables.
- Step 3 - If logging is marked as allowed but no log file path was returned, disable logging (set m_loggingAllowed to FALSE) and report the misconfiguration: if no bean is registered, call WEBUTIL.ERRORALERT to display alert WUC-008; otherwise invoke WebUtil_Core.setProperty to set WUC_SRV_LOGGING to '0' and call WebUtil_Core.error.
- Step 4 - If at least one bean is registered, synchronise the client-side logging level property (WUC_SRV_LOGGING) via WebUtil_Core.setProperty: set '1' for errors-only mode, '2' for full logging, or '0' if logging is disabled.
- Step 5 - If logging is allowed, evaluate whether the current message qualifies for output: it qualifies if errors-only mode is off, or if errors-only mode is on and isError is TRUE.
- Step 6 - Open the log file in append mode using TEXT_IO.FOPEN, then verify the file handle with WEBUTIL.IS_OPEN; if the file cannot be opened, raise NO_DATA_FOUND.
- Step 7 - Write the message to the file using WEBUTIL.PUT_LINE: if a client IP address is available (m_clientIP is not null), prefix the message with the client IP and username; otherwise write the message as-is.
- Step 8 - Close the log file with TEXT_IO.FCLOSE.
- Step 9 - In the exception handler, if SQLCODE is -302000 (file write failure), disable logging and report error WUC-007: call WEBUTIL.ERRORALERT if no bean is registered, or call WebUtil_Core.setProperty and WebUtil_Core.error otherwise; for all other exceptions, re-raise.

---
**Decision Points**

DP-001

Condition:
m_loggingAllowed is NULL (logging configuration cache not yet initialised)

TRUE:
Call WEBUTIL.READFROMPROPERTYBUNDLE to load 'logging.enabled', 'logging.errorsonly', and 'logging.file' into module-level cache variables, then validate and synchronise the configuration (see DP-002 and DP-003).

FALSE:
Skip initialisation; proceed directly to the logging step.

---

DP-002

Condition:
Logging is allowed (m_loggingAllowed = TRUE) but the log file path (m_loggingFile) is NULL

TRUE:
Disable logging (m_loggingAllowed := FALSE). If no bean is registered, call WEBUTIL.ERRORALERT with WUC-008 message. If a bean is registered, set WUC_SRV_LOGGING to '0' via WebUtil_Core.setProperty and call WebUtil_Core.error.

FALSE:
Retain the current logging-allowed state and continue.

---

DP-003

Condition:
At least one bean is registered (m_registeredPackages.FIRST is not null) after configuration initialisation

TRUE:
Synchronise WUC_SRV_LOGGING on the client: '1' if errors-only mode is on, '2' if full logging is on, '0' if logging is disabled.

FALSE:
Skip client-side property synchronisation.

---

DP-004

Condition:
Logging is allowed AND (errors-only mode is off OR (errors-only mode is on AND isError is TRUE))

TRUE:
Open the log file in append mode, verify it is open via WEBUTIL.IS_OPEN, write the message via WEBUTIL.PUT_LINE, and close the file.

FALSE:
Skip writing; return without action.

---

DP-005

Condition:
m_clientIP is not NULL at the point of writing the log entry

TRUE:
Prefix the message with the client IP address and username before writing via WEBUTIL.PUT_LINE.

FALSE:
Write the message text without any prefix.

---

DP-006

Condition:
Exception is raised with SQLCODE -302000 (file write failure)

TRUE:
Disable logging (m_loggingAllowed := FALSE). If no bean is registered, call WEBUTIL.ERRORALERT with WUC-007 message. If a bean is registered, set WUC_SRV_LOGGING to '0' and call WebUtil_Core.error with error code 7.

FALSE (any other exception):
Re-raise the exception to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Logging configuration (enabled flag, errors-only mode, and log file path) is read once from the property bundle via WEBUTIL.READFROMPROPERTYBUNDLE and cached in module-level variables; subsequent calls reuse the cache without re-reading properties.
- BR-002 - If logging is requested but no log file path is configured, logging must be disabled and an error (WUC-008) must be reported; the system must not silently suppress the misconfiguration.
- BR-003 - In errors-only mode, only messages passed with isError = TRUE are written to the log file; informational messages are suppressed.
- BR-004 - When a file write failure (SQLCODE -302000) occurs, logging is permanently disabled for the session (m_loggingAllowed := FALSE) and error WUC-007 is reported; all other exceptions are propagated to the caller.
- BR-005 - If no WebUtil bean is registered at the time an error condition is detected, WEBUTIL.ERRORALERT must be used to surface the error (WUC-007 or WUC-008) because client-side property communication is unavailable.
- BR-006 - No form-specific business rules apply; this procedure is a WebUtil infrastructure utility for diagnostic logging.

---
**Implementation Logic**

```plsql
  

  PROCEDURE Log(msg in VARCHAR2, isError BOOLEAN) is
    logFile       TEXT_IO.FILE_TYPE;
    logFileName   VARCHAR2(1024 char);
    errorOnlyMode BOOLEAN;
  begin
    -- check to see if we should do anything
    if m_loggingAllowed is null then 
      -- set up the logging info Cache
      m_loggingAllowed    := (lower(ReadFromPropertyBundle('logging.enabled')) = 'true');
      m_loggingErrorsOnly := (lower(ReadFromPropertyBundle('logging.errorsonly')) = 'true');
      m_loggingFile       := ReadFromPropertyBundle('logging.file');
      if m_loggingAllowed then 
        if m_loggingFile is null then 
          -- no file == no logging
          m_loggingAllowed := false;
          if m_registeredPackages.FIRST is null then
            -- There is no bean registered yet. Throw error in English using alert
            ErrorAlert('WUC-008: Server side logging was requested but no log file was specified'
                       ||' - logging is disabled');
          else
            WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
            WebUtil_Core.error(WUC_PACKAGE,8,'WebUtil_Core.Log');
          end if;
        end if;
      end if;
      if m_registeredPackages.FIRST is not null then
        -- At least one bean is registered. Can call setProperty(WUC_PACKAGE)
        if m_loggingAllowed and m_loggingErrorsOnly then
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','1',true);
        elsif  m_loggingAllowed then
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','2',true);
        else
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
        end if;
      end if;
    end if;
        
    -- now log if allowed to do so
    if m_loggingAllowed then
      if ((not m_loggingErrorsOnly) or (m_loggingErrorsOnly and isError)) then
        logFile := TEXT_IO.FOPEN(m_loggingFile,'A');
        if not TEXT_IO.IS_OPEN(logFile) then 
          raise NO_DATA_FOUND;
        end if;
        if m_clientIP is null then
        	TEXT_IO.PUT_LINE(logFile,msg);
        else
        	TEXT_IO.PUT_LINE(logFile,m_clientIP||':'||m_clientUserName||': '||msg);
        end if;
        TEXT_IO.FCLOSE(logFile);
      end if;    
    end if;
  EXCEPTION
    when others then 
      if SQLCODE = '-302000' then
        if m_registeredPackages.FIRST is null then
          -- There is no bean registered yet. Throw error in English using alert
          ErrorAlert('WUC-007: Unable to write to WebUtil Logging File '|| m_loggingFile);
        else

          WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
          WebUtil_Core.error(WebUtil_Core.WUC_PACKAGE,7,'WebUtil_Core.Log',m_loggingFile);
        end if;
        m_loggingAllowed := false;
      else
        RAISE;
      end if;      
  end Log;
```

#### SP-058 - WEBUTIL.POPULATEPROPERTYBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.READFROMPROPERTYBUNDLE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Locates and reads the WebUtil configuration file, populates the in-memory property bundle array with all key-value pairs found in that file, and returns the value associated with a requested property key. The function is used internally by the WebUtil infrastructure to resolve configuration properties at runtime without repeated file I/O.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-029](#SP-029--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the property key to search for within the WebUtil configuration file.
- Step 2 - Determine the configuration file path by checking, in priority order: (a) the global variable WEBUTIL_CONFIG_GLOBAL, (b) the environment variable WEBUTIL_CONFIG_ENV via TOOL_ENV.GETVAR, and (c) the Forms parameter WEBUTIL_CONFIG_PARAM. If none of these sources yields a path, raise NO_DATA_FOUND.
- Step 3 - Persist the resolved configuration file path back to WEBUTIL_CONFIG_GLOBAL for subsequent calls.
- Step 4 - Open the configuration file for reading using TEXT_IO.FOPEN.
- Step 5 - Read the file line by line in a loop using TEXT_IO.GET_LINE; exit the loop when NO_DATA_FOUND is raised (end of file).
- Step 6 - For each line, skip lines whose first character is '#' (comment lines).
- Step 7 - For non-comment lines that contain an '=' character, parse the line into a key-value pair: trim whitespace from the key (stored in lower case) and trim whitespace and carriage-return characters from the value.
- Step 8 - Store each parsed pair in the next slot of the m_propertyBundle array, incrementing the property index.
- Step 9 - If the parsed key matches the requested propertyKey (case-insensitive), capture its value as the result to be returned.
- Step 10 - After processing all lines, close the configuration file with TEXT_IO.FCLOSE.
- Step 11 - Return the captured result value (NULL if the key was not found).
- Step 12 - On NO_DATA_FOUND (no configuration file path resolved): if no bean package is yet registered, call WEBUTIL.ERRORALERT to display error 'WUC-005: No WebUtil Configuration File specified'; otherwise delegate to Webutil_Core.Error. Set m_config_error to TRUE and return NULL.
- Step 13 - On SQLCODE -302000 (file unreadable): if no bean package is yet registered, call WEBUTIL.ERRORALERT to display error 'WUC-006: Unable to read WebUtil Configuration File'; otherwise delegate to Webutil_Core.Error with the resolved file path. Set m_config_error to TRUE and return NULL. For all other exceptions, re-raise.

---
**Decision Points**

DP-001

Condition: WEBUTIL_CONFIG_GLOBAL contains a value other than '[NOTSET]'.

TRUE: Use the global variable value as the configuration file path; skip environment and parameter lookups.

FALSE: Proceed to check WEBUTIL_CONFIG_ENV via TOOL_ENV.GETVAR.

---

DP-002

Condition: TOOL_ENV.GETVAR returns a non-null value for WEBUTIL_CONFIG_ENV.

TRUE: Use the environment variable value as the configuration file path; skip the Forms parameter lookup.

FALSE: Attempt to resolve the path from the Forms parameter WEBUTIL_CONFIG_PARAM.

---

DP-003

Condition: WEBUTIL_CONFIG_PARAM yields a non-null value.

TRUE: Use the Forms parameter value as the configuration file path.

FALSE: Raise NO_DATA_FOUND, triggering the missing-configuration-file error path.

---

DP-004

Condition: The first character of a file line is '#'.

TRUE: Skip the line entirely (comment).

FALSE: Attempt to parse the line as a key-value pair.

---

DP-005

Condition: The line contains an '=' character (pos > 0).

TRUE: Parse and store the key-value pair in m_propertyBundle; check whether the key matches propertyKey.

FALSE: Ignore the line (no valid key-value pair present).

---

DP-006

Condition: The parsed key matches the requested propertyKey (case-insensitive comparison).

TRUE: Capture the corresponding value as the function result.

FALSE: Continue processing remaining lines without updating the result.

---

DP-007

Condition: Exception handler for NO_DATA_FOUND or SQLCODE -302000 - m_registeredPackages.FIRST is null (no bean yet registered).

TRUE: Call WEBUTIL.ERRORALERT to display the appropriate WUC error message in English.

FALSE: Delegate error reporting to Webutil_Core.Error.

---

DP-008

Condition: WHEN OTHERS exception - SQLCODE equals -302000 (file I/O failure).

TRUE: Handle as a known file-unreadable condition (WUC-006 error path), set m_config_error, return NULL.

FALSE: Re-raise the exception to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The configuration file path must be resolvable from at least one of three sources (global variable, environment variable, Forms parameter) in that priority order; failure to resolve from any source is a fatal configuration error that halts processing and returns NULL.
- BR-002 - Once the configuration file path is resolved, it is written back to WEBUTIL_CONFIG_GLOBAL so that subsequent invocations avoid redundant environment or parameter lookups.
- BR-003 - Lines beginning with '#' are treated as comments and must not be parsed or stored in the property bundle.
- BR-004 - Only lines containing an '=' delimiter are valid key-value entries; lines without '=' are silently ignored.
- BR-005 - Property keys are normalised to lower case and whitespace-trimmed before storage and comparison, ensuring case-insensitive key resolution.
- BR-006 - Property values are whitespace-trimmed and stripped of carriage-return characters (CHR(13)) to prevent platform-specific line-ending artefacts from corrupting values.
- BR-007 - When a configuration file error occurs and no bean package is registered, the error must be surfaced to the user in plain English via WEBUTIL.ERRORALERT (WUC-005 for missing file; WUC-006 for unreadable file); when a bean is registered, error reporting is delegated to Webutil_Core.Error.
- BR-008 - On any handled configuration error, m_config_error is set to TRUE and the function returns NULL, signalling to the caller that configuration is unavailable.

---
**Implementation Logic**

```plsql
      
  FUNCTION PopulatePropertyBundle(propertyKey in VARCHAR2) return VARCHAR2 is
    configFile   VARCHAR2(512 char);
    buffer       VARCHAR2(1000 char);
    result       VARCHAR2(1000 char);          
    propertyFile TEXT_IO.FILE_TYPE;
    pos          PLS_INTEGER;
    propIndex    PLS_INTEGER := 0;
  begin
    -- First of get the name of the cfg file 
    -- This could come in a global  or from the Environment
    default_value('[NOTSET]',WEBUTIL_CONFIG_GLOBAL);
    configFile := name_in(WEBUTIL_CONFIG_GLOBAL);
    if configFile = '[NOTSET]' then
      configFile := null; 
      -- Try the environment
      TOOL_ENV.GETVAR(WEBUTIL_CONFIG_ENV, configFile); 
      if configFile is null then 
        -- Finally try the Forms parameters
        configFile := name_in(WEBUTIL_CONFIG_PARAM);
        -- if that fails then we have to raise an error
        if configFile is null then 
          raise NO_DATA_FOUND;
        end if;    
      end if;
    end if;
    
    copy(configFile, WEBUTIL_CONFIG_GLOBAL);
      
    propertyFile := Text_IO.FOpen(configFile,'R');
    LOOP
      begin
        Text_IO.Get_Line(propertyFile,buffer);
      exception
        when NO_DATA_FOUND then EXIT;
      end;
        
      -- ignore lines which start with '#'
      if substr(buffer,1,1) <> '#' then 
        pos := instr(buffer,'=');
        -- only process lines with a name value pair
        if pos > 0 then 
          propIndex := propIndex + 1;
          m_propertyBundle(propIndex).propertyKey   := lower(ltrim(rtrim(substr(buffer,1,pos-1))));    
          m_propertyBundle(propIndex).propertyValue := ltrim(rtrim(replace(substr(buffer,pos+1),chr(13),'')));
          -- Check to see if this is the key we are looking for
          if  m_propertyBundle(propIndex).propertyKey = lower(propertyKey) then
            result := m_propertyBundle(propIndex).propertyValue;
          end if;
        end if;
      end if;
    end LOOP;
    Text_IO.FClose(propertyFile);
    return result;
  EXCEPTION
    when NO_DATA_FOUND then 
      if m_registeredPackages.FIRST is null then
        -- There is no bean registered yet. Throw error in English using alert
        ErrorAlert('WUC-005: No WebUtil Configuration File specified');
      else
        Webutil_Core.Error(Webutil_Core.WUC_PACKAGE,5,'WebUtil_Core.PopulatePropertyBundle');
      end if;
      m_config_error := true;
      return null;
    when others then 
      if SQLCODE = '-302000' then
        if m_registeredPackages.FIRST is null then
          -- There is no bean registered yet. Throw error in English using alert
          ErrorAlert('WUC-006: Unable to read WebUtil Configuration File');
        else
          Webutil_Core.Error(Webutil_Core.WUC_PACKAGE,6,'WebUtil_Core.PopulatePropertyBundle', configFile);
        end if;
        m_config_error := true;
        return null;
      else
        RAISE;
      end if;      

  end PopulatePropertyBundle;
```

#### SP-059 - WEBUTIL.PUTF

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a formatted string to an open server-side file. Supports substitution of up to four argument values into a format string before writing. Equivalent to a formatted file write (printf-style).

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |
| arg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the file handle, a format string, and up to four optional argument values.
- Step 2 - Substitute the argument values into the format string where placeholders appear.
- Step 3 - Write the resulting string to the open file via the WebUtil file I/O bean.

---
**Decision Points**

No conditional branches - formats and writes the string unconditionally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - No form-specific business rules - WebUtil infrastructure utility for formatted server-side file writing.

---
**Implementation Logic**

```plsql
   
  
  
  procedure putf (file   file_type, 
                  arg    VARCHAR2) is 
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);              
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_PUTF',arg); 
  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.putf will not work');
      RAISE TOOL_ERR.TOOL_ERROR;                                                                 
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE TOOL_ERR.TOOL_ERROR;  
  END putf;
```

#### SP-060 - WEBUTIL.PUT_LINE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a line of text to an open server-side file, appending a newline character at the end. Used for writing line-by-line text output to server files.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |
| item | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the file handle and the text line to write.
- Step 2 - Write the text followed by a newline character to the open file via the WebUtil file I/O bean.

---
**Decision Points**

No conditional branches - unconditionally writes the line.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - No form-specific business rules - WebUtil infrastructure utility for writing text lines to server-side files.

---
**Implementation Logic**

```plsql
    

  PROCEDURE put_line (file file_type, item VARCHAR2) is
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);              
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_PUT',item); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_NEWLINE',1); 
  EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.put_line will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;  
  END put_line;
```

#### SP-061 - WEBUTIL.READFROMPROPERTYBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.LOG]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Reads a named property value from a WebUtil property bundle. Used internally by the WebUtil infrastructure to retrieve values that were batch-set by POPULATEPROPERTYBUNDLE.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.POPULATEPROPERTYBUNDLE ([SP-058](#SP-058--WEBUTIL.POPULATEPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the package identifier, property bundle name, and property name.
- Step 2 - Retrieve the property value from the bean's property bundle.
- Step 3 - Return the value to the caller.

---
**Decision Points**

No conditional branches - reads and returns the requested property bundle value.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - No form-specific business rules - WebUtil infrastructure utility for reading from property bundles.

---
**Implementation Logic**

```plsql
  
  FUNCTION ReadFromPropertyBundle(propertyKey in VARCHAR2) return VARCHAR2 is   
    result       VARCHAR2(1000 char);
    propCount    PLS_INTEGER := m_propertyBundle.COUNT;
  begin
    if m_config_error then
      -- already encountered problem reading the config file.
      return null;
    elsif (propCount = 0) then
      result := populatePropertyBundle(propertyKey);
    else
      for i in 1..propCount LOOP
        if m_propertyBundle(i).propertyKey = lower(propertyKey) then 
          result := m_propertyBundle(i).propertyValue;
          EXIT;
        end if;
      end LOOP;
    end if;
    return result;
  end ReadFromPropertyBundle;
```

#### SP-062 - WEBUTIL.READTRANSFROMMSGBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a translated message string from the WebUtil message bundle by composing a lookup key from the supplied property key and optional arguments, then delegating the read/write cycle to the WebUtil Core layer. The function is currently used by WEBUTIL.CHECKLIBS to obtain localised text for the progress bar title displayed during library validation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |
| args | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the mandatory propertyKey (message bundle key) and the optional args (substitution arguments) input parameters.
- Step 2 - Concatenate propertyKey and args with a pipe delimiter ('|') to form a composite lookup value.
- Step 3 - Write the composite lookup value to the WebUtil Core property store by calling Webutil_Core.setProperty, targeting the WUC_PACKAGE package constant and the WUC_TRANS_MSG property name.
- Step 4 - Read the resolved translated message back from the same property store by calling Webutil_Core.getProperty with the same WUC_PACKAGE and WUC_TRANS_MSG identifiers.
- Step 5 - Return the translated message string retrieved in Step 4 to the caller.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a fixed set-then-get sequence unconditionally for every invocation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The composite lookup value passed to the WebUtil Core property store must be formed by concatenating propertyKey, a pipe character ('|'), and args; this delimiter convention is required for the message bundle resolution mechanism to parse key and arguments correctly.
- BR-002 - The args parameter is optional (defaults to NULL); when not supplied, the composite value written to the property store will be propertyKey followed by a pipe character and no trailing value, ensuring the call remains valid.
- BR-003 - The function relies exclusively on Webutil_Core.setProperty and Webutil_Core.getProperty for all message bundle interactions; no direct database queries or alternative translation mechanisms are used.
- BR-004 - The same WUC_PACKAGE and WUC_TRANS_MSG constants must be used for both the set and get operations to guarantee that the value written is the value returned to the caller.

---
**Implementation Logic**

```plsql
  
  FUNCTION ReadTransFromMsgBundle(propertyKey in VARCHAR2, args in VARCHAR2 := null) return VARCHAR2 is
    -- currently called from checkLibs only for getting progress bar title.
  begin 
    Webutil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_TRANS_MSG', propertyKey||'|'||args);
    return Webutil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_TRANS_MSG');
  end ReadTransFromMsgBundle;
```

#### SP-063 - WEBUTIL.REGISTERBEAN

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a WebUtil client-side bean with the server-side Oracle Forms session during initial bean handshake. On the first bean registration, the procedure captures client environment details (IP address, OS, architecture, username, locale, path and file separators), resolves the system library download directory, logs the connection if configured, and propagates server-side configuration settings (heartbeat blocking, logging level) back to the client bean. For every bean registration it maps the bean short-name to its internal package constant, records the triggering item, and verifies that all required client libraries are present.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| clientInfo | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.CHECKLIBS ([SP-022](#SP-022--WEBUTIL.CHECKLIBS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTSETTING ([SP-037](#SP-037--WEBUTIL.GETCLIENTSETTING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETOSFAMILY ([SP-042](#SP-042--WEBUTIL.GETOSFAMILY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETPROPERTY ([SP-044](#SP-044--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETVAR ([SP-046](#SP-046--WEBUTIL.GETVAR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-057](#SP-057--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-061](#SP-061--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETCLIENTSETTING ([SP-066](#SP-066--WEBUTIL.SETCLIENTSETTING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Extract the bean short-name from the first pipe-delimited token of the clientInfo string.
- Step 2 - Map the bean short-name (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL) to the corresponding WEBUTIL_CORE package-ID constant; an unrecognised short-name leaves packageID undefined.
- Step 3 - If the client IP address has not yet been recorded (first bean registration in the session), set the checkUserLibs flag to TRUE and parse the remaining clientInfo tokens to populate the session-level client attributes: IP address (token 2), OS name (token 3), OS family via WEBUTIL.GETOSFAMILY (derived from token 3), OS architecture flag (token 4 - set to 1 if the value contains '64'), username (token 5), path separator (token 6), file separator (token 7), and language code (token 8).
- Step 4 - If the resolved packageID has not already been registered in the m_registeredPackages array, store the current trigger item (SYSTEM.TRIGGER_ITEM) against that packageID and set the newPackage flag to TRUE; duplicate registrations for the same package are silently ignored.
- Step 5 - If checkUserLibs is TRUE (first-bean path), resolve the server host name by calling WEBUTIL.GETVAR for 'COMPUTERNAME', falling back to 'HOST' if the first call returns null.
- Step 6 - Attempt to read the client system-library directory from the property bundle using WEBUTIL.READFROMPROPERTYBUNDLE, first with an OS-family and architecture key, then with an OS-family-only key as a fallback.
- Step 7 - If no client library directory is configured, send a WUC_SYSLIB_DIR property to the WUC bean containing only the server host and application CONFIG value, leaving client-side directory handling to the bean itself.
- Step 8 - If a client library directory is configured, substitute the '$(SERVERHOST)' placeholder with the resolved server host name, send the full WUC_SYSLIB_DIR property, then compare the stored client setting (via WEBUTIL.GETCLIENTSETTING) with the new directory; if they differ, update the stored setting via WEBUTIL.SETCLIENTSETTING and set REDOWNLOAD_SYSLIB to TRUE.
- Step 9 - Retrieve and store the WebUtil bean version from the WUC bean property WUC_BEAN_VERSION via WEBUTIL.GETPROPERTY.
- Step 10 - If the 'logging.connections' property bundle entry equals 'true' (case-insensitive), call WEBUTIL.LOG to record the current form name, client OS, and locale.
- Step 11 - If the newPackage flag is TRUE, call WEBUTIL.CHECKLIBS with the string representation of the packageID to verify and download any missing package-specific client libraries.
- Step 12 - If checkUserLibs is TRUE, call WEBUTIL.LOG with a null message to initialise the session logging-state flags (m_loggingAllowed, m_loggingErrorsOnly).
- Step 13 - Read the 'BlockAllowHeartBeat' property bundle entry; if its lower-cased value is 'true', 'yes', or '1', send WUC_BLOCK_ALLOW_HEART_BEAT = '1' to the client bean; otherwise send '0'.
- Step 14 - Evaluate the session logging flags and send the WUC_SRV_LOGGING property to the client bean: '1' if logging is allowed but errors-only, '2' if full logging is allowed, or '0' if logging is disabled.
- Step 15 - If checkUserLibs is TRUE, call WEBUTIL.CHECKLIBS with the literal 'user' to verify and download any user-defined client libraries.

---
**Decision Points**

DP-001
Condition: beanShortName matches one of the known constants (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL).
TRUE: packageID is set to the corresponding WEBUTIL_CORE package constant.
FALSE: No packageID is assigned; subsequent steps that reference packageID will operate with an undefined value.

DP-002
Condition: m_clientIP IS NULL (client environment has not yet been captured for this session).
TRUE: checkUserLibs is set to TRUE and all client environment attributes (IP, OS, OS family, architecture, username, separators, language code) are parsed from clientInfo.
FALSE: Client environment attributes are already populated; checkUserLibs remains FALSE and the parsing block is skipped.

DP-003
Condition: clientOSArch contains the substring '64'.
TRUE: m_clientOSArch is set to 1, indicating a 64-bit client architecture.
FALSE: m_clientOSArch remains at its default value, indicating a 32-bit (or undetected) architecture.

DP-004
Condition: m_registeredPackages does NOT already contain an entry for packageID.
TRUE: The package is recorded in m_registeredPackages using the current trigger item, and newPackage is set to TRUE.
FALSE: The package was already registered; the existing entry is preserved and newPackage remains FALSE.

DP-005
Condition: The architecture-specific property bundle key ('install.syslib.location.client.<OSFamily>.<OSArch>') returns a non-null value.
TRUE: clientLibDir is set to the architecture-specific path.
FALSE: A second lookup is attempted using the OS-family-only key ('install.syslib.location.client.<OSFamily>').

DP-006
Condition: clientLibDir IS NULL after both property bundle lookups.
TRUE: WUC_SYSLIB_DIR is sent to the WUC bean containing only server host and CONFIG value; client bean handles directory resolution independently.
FALSE: clientLibDir contains a configured path; the $(SERVERHOST) placeholder is substituted and the full path is sent as WUC_SYSLIB_DIR.

DP-007
Condition: The previously stored client library directory (from WEBUTIL.GETCLIENTSETTING) differs from the newly resolved clientLibDir.
TRUE: WEBUTIL.SETCLIENTSETTING is called to update the stored directory and REDOWNLOAD_SYSLIB is set to TRUE.
FALSE: Directories match; no update is made and REDOWNLOAD_SYSLIB remains FALSE.

DP-008
Condition: LOWER(WEBUTIL.READFROMPROPERTYBUNDLE('logging.connections')) = 'true'.
TRUE: WEBUTIL.LOG is called to record the connection details (form name, client OS, locale).
FALSE: Connection logging is skipped.

DP-009
Condition: newPackage is TRUE.
TRUE: WEBUTIL.CHECKLIBS is called with the string packageID to verify package-specific client libraries.
FALSE: Library check for this package is skipped.

DP-010
Condition: checkUserLibs is TRUE (post library-check initialisation call).
TRUE: WEBUTIL.LOG is called with a null message to initialise m_loggingAllowed and m_loggingErrorsOnly session flags.
FALSE: Logging initialisation call is skipped.

DP-011
Condition: LOWER(WEBUTIL.READFROMPROPERTYBUNDLE('BlockAllowHeartBeat')) IN ('true', 'yes', '1').
TRUE: WUC_BLOCK_ALLOW_HEART_BEAT property is sent to the client bean as '1' (heartbeat blocking enabled).
FALSE: WUC_BLOCK_ALLOW_HEART_BEAT property is sent as '0' (heartbeat blocking disabled).

DP-012
Condition: m_loggingAllowed is TRUE AND m_loggingErrorsOnly is TRUE.
TRUE: WUC_SRV_LOGGING is sent as '1' (errors-only logging).
FALSE: Evaluation continues to DP-013.

DP-013
Condition: m_loggingAllowed is TRUE (and m_loggingErrorsOnly is FALSE, per DP-012 fall-through).
TRUE: WUC_SRV_LOGGING is sent as '2' (full logging enabled).
FALSE: WUC_SRV_LOGGING is sent as '0' (logging disabled).

DP-014
Condition: checkUserLibs is TRUE (final user-library check).
TRUE: WEBUTIL.CHECKLIBS is called with the literal 'user' to verify and download user-defined client libraries.
FALSE: User library check is skipped.

---
**Database Interactions**

- DB-001 - Update THIS - Updates existing rows in THIS.
**Business Rules**

- BR-001 - The bean short-name extracted from clientInfo must match one of the ten known constants (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL); only recognised beans are mapped to a valid packageID.
- BR-002 - Client environment attributes (IP, OS, OS family, architecture, username, path separator, file separator, language code) are captured exactly once per Forms session; subsequent bean registrations within the same session do not overwrite these values.
- BR-003 - A client OS architecture containing the substring '64' is classified as 64-bit (m_clientOSArch = 1); all other values are treated as non-64-bit.
- BR-004 - Only the first instance of a given bean package is registered; if the same bean package is registered more than once (e.g., placed in a multi-row block), all registrations after the first are silently ignored and the trigger item recorded at first registration is retained.
- BR-005 - System library directory resolution follows a priority order: architecture-specific property bundle key takes precedence over the OS-family-only key; if neither is defined, the client bean is responsible for determining its own directory.
- BR-006 - The placeholder '$(SERVERHOST)' in a configured client library directory path must be replaced with the runtime server host name before the path is transmitted to the client bean.
- BR-007 - If the resolved client library directory differs from the value previously stored via WEBUTIL.GETCLIENTSETTING, the stored value must be updated via WEBUTIL.SETCLIENTSETTING and the REDOWNLOAD_SYSLIB flag must be set to TRUE to trigger a re-download.
- BR-008 - Connection logging is controlled by the 'logging.connections' property bundle entry; only a value of 'true' (case-insensitive) activates connection log entries.
- BR-009 - Per-package client library verification (WEBUTIL.CHECKLIBS) is performed only when a package is being registered for the first time within the session.
- BR-010 - The 'BlockAllowHeartBeat' configuration variable accepts exactly three affirmative values ('true', 'yes', '1', all evaluated case-insensitively); any other value disables heartbeat blocking.
- BR-011 - Server-side logging state must be communicated to each registering client bean via the WUC_SRV_LOGGING property using the codes 0 (disabled), 1 (errors only), or 2 (full), so the bean can avoid sending unnecessary log messages to the server.
- BR-012 - User-defined client library verification (WEBUTIL.CHECKLIBS with 'user') is performed once per session, after at least one bean package has been registered, to ensure a handler bean is available to perform any required download.

---
**Implementation Logic**

```plsql
  PROCEDURE registerBean(clientInfo in VARCHAR2) is  
    packageID       PLS_INTEGER;
    beanShortName   VARCHAR2(3 char);
    newPackage      BOOLEAN := false;
    checkUserLibs   BOOLEAN := false;
    clientLibDir    VARCHAR2(1000 char);
    clientLibDirOld VARCHAR2(1000 char);
    serverHost      VARCHAR2(100 char);
    blockAllowHeartBeat VARCHAR2(10 char);
    clientOSArch    VARCHAR2(30 char);
  begin
    beanShortName := DelimStr.getString(clientInfo,1,true,'|');

    -- To speed access up we crossmatch the Bean Name string
    -- with a constant - this constant is used to access the 
    -- registered package array efficently
    -- need to update this IF statement as we add new packages
    if beanShortName = 'WUC' then
       packageID := WEBUTIL_CORE.WUC_PACKAGE; 
    elsif beanShortName = 'WUT' then     
       packageID := WEBUTIL_CORE.WUT_PACKAGE; 
    elsif beanShortName = 'WUF' then 
       packageID := WEBUTIL_CORE.WUF_PACKAGE; 
    elsif beanShortName = 'WUI' then
        packageID := WEBUTIL_CORE.WUI_PACKAGE; 
    elsif beanShortName = 'WUH' then            
       packageID := WEBUTIL_CORE.WUH_PACKAGE;
    elsif beanShortName = 'WUS' then     
       packageID := WEBUTIL_CORE.WUS_PACKAGE;
    elsif beanShortName = 'WUB' then 
       packageID := WEBUTIL_CORE.WUB_PACKAGE;
    elsif beanShortName = 'WUO' then     
       packageID := WEBUTIL_CORE.WUO_PACKAGE;
    elsif beanShortName = 'WUU' then     
       packageID := WEBUTIL_CORE.WUU_PACKAGE;
    elsif beanShortName = 'WUL' then     
       packageID := WEBUTIL_CORE.WUL_PACKAGE;           
    end if;
    -- For the very first bean we can get a bit of useful information
    -- Only do this once
    if m_clientIP is null then 
      checkUserLibs := true;
      -- Format of the clientinfo packet is
      -- BeanName|IP|OSName|UserName|pathSep|filesep
      m_clientIP       := DelimStr.getString(clientInfo,2,true,'|');
      m_clientOS       := DelimStr.getString(clientInfo,3,true,'|');
      m_clientOSFamily := getOSFamily(m_clientOS);
      clientOSArch     := DelimStr.getString(clientInfo,4,true,'|');
      if instr(clientOSArch, '64') > 0 then
        m_clientOSArch := 1;
      end if;
      m_clientUserName := DelimStr.getString(clientInfo,5,true,'|');      
      m_clientPathSep  := DelimStr.getString(clientInfo,6,true,'|');
      m_clientFileSep  := DelimStr.getString(clientInfo,7,true,'|');
      m_clientLangCode := DelimStr.getString(clientInfo,8,true,'|'); 
    end if;
      
    -- I'd only expect one instance of each bean per form
    -- but just in case we only register the first 
    -- so if multiple copies are used - e.g. it's 
    -- placed in a multi-row block we just use the 
    -- first instance.
    if not m_registeredPackages.EXISTS(packageID) then 
      m_registeredPackages(packageID) := name_in('SYSTEM.TRIGGER_ITEM');
      -- make sure all the required libraries are available
      -- on the client
      newPackage := true;
    end if;
      
    if checkUserLibs then
      -- checkUserLibs would be true if clientIP was null
      -- We can do whatever we want to do but not more than once
      REDOWNLOAD_SYSLIB := FALSE;
      -- We need to get the server host name using available built-ins. This looks lame,
      -- but it should work
      TOOL_ENV.GETVAR('COMPUTERNAME', serverHost);
      if serverHost is null then
        TOOL_ENV.GETVAR('HOST', serverHost);
      end if;
      clientLibDir := readFromPropertyBundle('install.syslib.location.client.'||to_char(m_clientOSFamily) ||
                                             '.' || to_char(m_clientOSArch));
      if clientLibDir is null then
        clientLibDir := readFromPropertyBundle('install.syslib.location.client.'||to_char(m_clientOSFamily));
      end if;
      if clientLibDir is null then
        -- client location when syslib download is not defined in webutil.cfg
        -- will be to client JRE. Send nothing and client will handle
        WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SYSLIB_DIR',
                                 ':' || serverHost || ':' || GET_APPLICATION_PROPERTY(CONFIG),
                                 true);
      else
        -- webutil.cfg contains a specific client directory for syslib download
        -- Replace $(SERVERHOST), if exists, with server host name
        clientLibDir := replace(clientLibDir, '$(SERVERHOST)', serverHost);

        -- The following line makes a few things happen on client including
        -- client directory creation, when clientLibDir is not null
        WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SYSLIB_DIR',
                                 clientLibDir || ':' || serverHost || ':' || GET_APPLICATION_PROPERTY(CONFIG),
                                 true);
        clientLibDirOld := GetClientSetting('install.syslib.dir');

        if clientLibDirOld <> clientLibDir then
    	  SetClientSetting('install.syslib.dir', clientLibDir);
          REDOWNLOAD_SYSLIB := TRUE;
    	end if;
      end if;
      Webutil_Core.WEBUTIL_VERSION := getProperty(WUC_PACKAGE,'WUC_BEAN_VERSION');
      -- We want to write the connection record if it's required.
      -- Any call to ReadFromPropertyBundle or log should be preferably made after
      -- registering at least one bean. That is the reason why the following log
      -- comes after m_registeredPackages(packageID) := name_in('SYSTEM.TRIGGER_ITEM'); above
      if lower(ReadFromPropertyBundle('logging.connections')) = 'true' then 
        log('Connection from Form='||GET_APPLICATION_PROPERTY(CURRENT_FORM)||' Client O/S='||m_clientOS||' locale='||m_clientLangCode,false);
      end if;
    end if;
    if newPackage then  
            checkLibs(to_char(packageID));
    end if;

    if checkUserLibs then
      -- Call a dummy log to initialize m_loggingAllowed and m_loggingErrorsOnly
      log(null,false);
    end if;

    -- 5950737 - Introduce new configuration variable BlockAllowHeartBeat. 
    -- Valid values are true, yes and 1.
    -- If this is set then send a message to the client to behave accordingly.    
    blockAllowHeartBeat := lower(ReadFromPropertyBundle('BlockAllowHeartBeat'));
    if blockAllowHeartBeat = 'true' or blockAllowHeartBeat = 'yes' or blockAllowHeartBeat = '1' then 
      WebUtil_Core.setProperty(packageID,'WUC_BLOCK_ALLOW_HEART_BEAT','1',true);
    else
      WebUtil_Core.setProperty(packageID,'WUC_BLOCK_ALLOW_HEART_BEAT','0',true);
    end if;

    -- Send server logging options to client bean so that the bean does not have
    -- to send message to server unnecessarily.
    if m_loggingAllowed and m_loggingErrorsOnly then
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','1',true);
    elsif m_loggingAllowed then
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','2',true);
    else
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','0',true);
    end if;
      
    -- 2836929 - move the user library check after the first package is registered 
    -- so that a handler bean exists to do the download.     
    if checkUserLibs then 
      --Check for and download any user libs
      checkLibs('user');  
    end if;     
  end registerBean;
```

#### SP-064 - WEBUTIL.REGISTER_FUNCTION

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a native client-side function with the WebUtil C API bean, defining the function's entry-point name, return type, and parameter signature. Must be called before the function can be invoked via INVOKE_WU or INVOKE_INT.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| libName | VARCHAR2 | IN |
| funcName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-051](#SP-051--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the function name, return type, and parameter type signature string.
- Step 2 - Submit the registration request to the WebUtil C API bean.
- Step 3 - Retrieve and return the registered function handle.

---
**Decision Points**

No conditional branches - unconditionally registers the function and returns its handle.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - No form-specific business rules - WebUtil infrastructure utility for registering native client functions before calling them.

---
**Implementation Logic**

```plsql

  FUNCTION REGISTER_FUNCTION (libName IN VARCHAR2, funcName IN VARCHAR2) 
                              RETURN FunctionHandle IS
    strHnd  VARCHAR2(8);                            
    funcHnd FunctionHandle;
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUL_PACKAGE,'WUL_FUNCTION_SPEC', libName || '|' || funcName);
    strHnd := WebUtil_Core.getProperty(WebUtil_Core.WUL_PACKAGE,'WUL_REGISTER_FUNCTION');
    funcHnd.hnd := TO_NUMBER (strHnd);
    if NOT ID_NULL(funcHnd) then
      m_funcHandleCount := m_funcHandleCount + 1;
    end if;

    RETURN funcHnd;
    
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUL_PACKAGE)
                              ||' bean not found. WEBUTIL_C_API.REGISTER_FUNCTION will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;  
    when VALUE_ERROR then
        RAISE TOOL_ERR.TOOL_ERROR; 
  END REGISTER_FUNCTION;
```

#### SP-065 - WEBUTIL.RELEASE_PROCESS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.HOST]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Releases the resources associated with a completed or terminated client-side process. The procedure instructs the WebUtil host bean to clear the process handle on the client side, clears any registered callback trigger for the process via the WebUtil core infrastructure, and nullifies the in-memory process handle. If the required WebUtil host bean is not registered, an error alert is raised to inform the user that the release operation cannot proceed.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the process identifier (IN OUT parameter) whose resources are to be released.
- Step 2 - Invoke WebUtil_Core.setProperty to signal the WebUtil host bean (WUH_PACKAGE) to clear the process handle (WUH_CLEAR_PROC) on the client side.
- Step 3 - Invoke WebUtil_Core.ClearCallbackTrigger to deregister any callback trigger associated with the process handle.
- Step 4 - Nullify the process handle within the process identifier record to mark it as released in the calling context.
- Step 5 - If a BEAN_NOT_REGISTERED exception is raised at any point, invoke WebUtil_Core.ErrorAlert to display a descriptive message indicating that the WebUtil host bean could not be found and the release operation will not function.

---
**Decision Points**

DP-001

Condition: A BEAN_NOT_REGISTERED exception is raised during execution (i.e., the WebUtil host bean identified by WUH_PACKAGE is not available at runtime).

TRUE: WebUtil_Core.ErrorAlert is called, displaying the implementation class name concatenated with a message stating the bean was not found and that WEBUTIL_HOST.Release_Process will not work. No further release steps are performed.

FALSE: All three release steps (setProperty, ClearCallbackTrigger, nullify handle) complete normally and the process identifier is returned with a null handle.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The process handle must be passed as an IN OUT parameter; the procedure nullifies it upon successful release, ensuring the caller cannot reuse a stale handle.
- BR-002 - The WebUtil host bean (WUH_PACKAGE) must be registered in the runtime environment before this procedure is called; if it is not, the release operation is aborted and an error alert is presented to the user.
- BR-003 - Both the client-side property clear (setProperty / WUH_CLEAR_PROC) and the callback trigger deregistration (ClearCallbackTrigger) are performed unconditionally as part of every successful release, ensuring no orphaned client resources or stale triggers remain after the call.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Release_Process(process in out PROCESS_ID) is  
  begin
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_CLEAR_PROC',process.handle);
    WebUtil_Core.ClearCallbackTrigger(process.handle);
    process.handle := null;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.Release_Process will not work');
  end Release_Process;
```

#### SP-066 - WEBUTIL.SETCLIENTSETTING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Transmits a named configuration property and its value to the WebUtil client-side bean by delegating to WebUtil_Core.setProperty. This allows the Oracle Forms runtime to push local client settings (identified by name/value pairs) to the WebUtil core package on the client tier. The procedure is called during library initialisation and bean registration to ensure client-side settings are applied before dependent functionality executes.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyName | VARCHAR2 | IN |
| propertyValue | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the property name (propertyName) and property value (propertyValue) as input parameters.
- Step 2 - Evaluate whether propertyName is not null; only a non-null property name constitutes a valid setting request.
- Step 3 - If propertyName is not null, invoke WebUtil_Core.setProperty, passing the constant WebUtil_Core.WUC_PACKAGE as the target package identifier, the constant WebUtil_Core.WUC_SET_LOCAL_PROPERTY as the operation identifier, and the concatenated string propertyName||'='||propertyValue as the property payload.
- Step 4 - If the WebUtil_Core bean has not been registered (BEAN_NOT_REGISTERED exception), raise an error alert identifying the missing bean class via WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE), then raise FORM_TRIGGER_FAILURE to halt form processing.
- Step 5 - If WebUtil_Core.setProperty reports a property error (PROPERTY_ERROR exception), raise FORM_TRIGGER_FAILURE to halt form processing without an additional alert.

---
**Decision Points**

DP-001

Condition: propertyName IS NOT NULL

TRUE: Call WebUtil_Core.setProperty with the WUC_PACKAGE target, WUC_SET_LOCAL_PROPERTY operation, and the concatenated propertyName||'='||propertyValue payload to apply the client setting.

FALSE: Skip the setProperty call entirely; the procedure exits without performing any action.

---

DP-002

Condition: WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during setProperty execution

TRUE: Display an error alert containing the unresolved bean class name (retrieved via WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)) and raise FORM_TRIGGER_FAILURE to abort the current form trigger.

FALSE: Continue normal execution; no alert is raised for this condition.

---

DP-003

Condition: WebUtil_Core.PROPERTY_ERROR exception is raised during setProperty execution

TRUE: Raise FORM_TRIGGER_FAILURE immediately to abort the current form trigger; no error alert is issued.

FALSE: Continue normal execution; no error is raised for this condition.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A client setting will only be transmitted if propertyName is not null; a null property name is silently ignored and no property is set on the client.
- BR-002 - The property payload delivered to the WebUtil client bean must be formatted as a single string in the pattern propertyName||'='||propertyValue; no other format is accepted by WebUtil_Core.setProperty for the WUC_SET_LOCAL_PROPERTY operation.
- BR-003 - If the WebUtil core bean is not registered at the time of the call, the procedure must surface an informative error alert identifying the missing bean class and must terminate form processing via FORM_TRIGGER_FAILURE; silent failure is not permitted in this scenario.
- BR-004 - If a property error is returned by WebUtil_Core.setProperty, the procedure must terminate form processing via FORM_TRIGGER_FAILURE; the error is not swallowed or logged silently.
- BR-005 - This procedure operates exclusively against the WebUtil_Core.WUC_PACKAGE target and the WebUtil_Core.WUC_SET_LOCAL_PROPERTY operation; it does not interact with any database tables or other packages.

---
**Implementation Logic**

```plsql

  PROCEDURE SetClientSetting(propertyName  in VARCHAR2,
                             propertyValue in VARCHAR2) is
  BEGIN
    if propertyName is not null then 
      WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SET_LOCAL_PROPERTY', propertyName||'='||propertyValue);
    end if;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                              ||' bean not found. WEBUTIL_CORE.SetClientSetting will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;       
  END SetClientSetting;
```

#### SP-067 - WEBUTIL.SETDATA

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.SETDATA receives a single chunk of upload data (as a VARCHAR2 string) and writes it to the appropriate destination - either a database BLOB via WebUtil_DB_LOCAL or a server-side file via JAVA_APPSERV_WRITER. It tracks the remaining chunk count and, once all chunks have been received, finalises the transfer by closing the target resource, recording overall upload success, and executing any registered callback trigger before clearing it.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| uploadData | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.CLEARCALLBACKTRIGGER ([SP-023](#SP-023--WEBUTIL.CLEARCALLBACKTRIGGER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.CLOSEBLOB ([SP-024](#SP-024--WEBUTIL.CLOSEBLOB)) - WEBUTIL.pck (or .pld)
- WEBUTIL.CLOSEFILE ([SP-025](#SP-025--WEBUTIL.CLOSEFILE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCALLBACKTRIGGER ([SP-035](#SP-035--WEBUTIL.GETCALLBACKTRIGGER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETLASTERROR ([SP-039](#SP-039--WEBUTIL.GETLASTERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETLASTERRORARGS ([SP-040](#SP-040--WEBUTIL.GETLASTERRORARGS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.WRITEDATA ([SP-071](#SP-071--WEBUTIL.WRITEDATA)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Validate the incoming chunk: if uploadData is NULL or empty, set the module-level flag m_uploadSucceeded to FALSE and abort further processing.
- Step 2 - Determine the write destination using the module-level flag m_toDB.
- Step 3 (DB path) - If m_toDB is TRUE, delegate the write operation to WebUtil_DB_LOCAL.WriteData, passing uploadData.
- Step 4 (File path) - If m_toDB is FALSE, call JAVA_APPSERV_WRITER.WriteData with the persistent object reference m_persistObj and uploadData. If the call returns FALSE, retrieve the error code via JAVA_APPSERV_WRITER.getLastError and the error arguments via JAVA_APPSERV_WRITER.getLastErrorArgs, log the error through WebUtil_Core.Error, and raise the READWRITE_ERROR exception.
- Step 5 - Decrement the module-level chunk counter m_chunks by 1.
- Step 6 - If m_chunks has reached 0 (all chunks received), proceed to finalise the transfer.
- Step 7 (Finalise - DB path) - If m_toDB is TRUE, call WebUtil_DB_LOCAL.CloseBlob passing m_fileSize. If successful, set m_uploadSucceeded to TRUE; otherwise log the error via WebUtil_Core.Error using WebUtil_DB_Local.getLastError.
- Step 8 (Finalise - File path) - If m_toDB is FALSE, call JAVA_APPSERV_WRITER.CloseFile with m_persistObj and m_fileSize. If successful, set m_uploadSucceeded to TRUE; otherwise retrieve error details, log them via WebUtil_Core.Error, release the Java global reference via ORA_JAVA.DELETE_GLOBAL_REF, and raise READWRITE_ERROR.
- Step 9 - After finalisation, check whether a callback trigger is registered by calling WEBUTIL.GETCALLBACKTRIGGER(-1). If one is present, execute it via EXECUTE_TRIGGER.
- Step 10 - Call WEBUTIL.CLEARCALLBACKTRIGGER(-1) to deregister the callback trigger regardless of whether one was executed.

---
**Decision Points**

DP-001

Condition: uploadData IS NULL or uploadData = ''

TRUE: Set m_uploadSucceeded to FALSE and exit the procedure without writing any data.

FALSE: Proceed to write the data chunk to the appropriate destination.

---

DP-002

Condition: m_toDB is TRUE

TRUE: Write the chunk to the database using WebUtil_DB_LOCAL.WriteData.

FALSE: Write the chunk to the server file system using JAVA_APPSERV_WRITER.WriteData.

---

DP-003

Condition: JAVA_APPSERV_WRITER.WriteData returns FALSE (file-path write failure)

TRUE: Retrieve error details via JAVA_APPSERV_WRITER.getLastError and JAVA_APPSERV_WRITER.getLastErrorArgs, log the error, and raise READWRITE_ERROR.

FALSE: Continue processing (decrement chunk counter).

---

DP-004

Condition: m_chunks equals 0 after decrement (all chunks received)

TRUE: Proceed to close the target resource and finalise the upload.

FALSE: No further action for this invocation; await subsequent chunks.

---

DP-005

Condition: m_toDB is TRUE at finalisation time

TRUE: Close the BLOB via WebUtil_DB_LOCAL.CloseBlob.

FALSE: Close the server file via JAVA_APPSERV_WRITER.CloseFile.

---

DP-006

Condition: WebUtil_DB_LOCAL.CloseBlob returns TRUE (DB close success)

TRUE: Set m_uploadSucceeded to TRUE.

FALSE: Log the error via WebUtil_Core.Error using WebUtil_DB_Local.getLastError; m_uploadSucceeded remains FALSE.

---

DP-007

Condition: JAVA_APPSERV_WRITER.CloseFile returns TRUE (file close success)

TRUE: Set m_uploadSucceeded to TRUE.

FALSE: Retrieve error details, log the error, release the Java global reference via ORA_JAVA.DELETE_GLOBAL_REF, and raise READWRITE_ERROR.

---

DP-008

Condition: WEBUTIL.GETCALLBACKTRIGGER(-1) returns a non-null trigger name

TRUE: Execute the callback trigger via EXECUTE_TRIGGER.

FALSE: Skip trigger execution; proceed directly to clearing the callback trigger.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A NULL or empty uploadData chunk is treated as an error condition; the upload is marked as failed (m_uploadSucceeded = FALSE) and no write operation is attempted.
- BR-002 - The write destination (database BLOB or server-side file) is determined exclusively by the pre-set module-level flag m_toDB; SETDATA does not alter this routing decision.
- BR-003 - Every successfully received chunk must decrement the module-level counter m_chunks; finalisation logic is triggered only when m_chunks reaches exactly zero, ensuring all expected chunks have been processed before the resource is closed.
- BR-004 - A write failure on the file-system path (JAVA_APPSERV_WRITER.WriteData returning FALSE) is a terminal error for the current invocation; processing must stop and READWRITE_ERROR must be raised after logging.
- BR-005 - A close failure on the file-system path (JAVA_APPSERV_WRITER.CloseFile returning FALSE) requires the Java global reference to be explicitly released via ORA_JAVA.DELETE_GLOBAL_REF before raising READWRITE_ERROR, preventing resource leaks.
- BR-006 - Upload success (m_uploadSucceeded = TRUE) is recorded only after the target resource has been successfully closed; a successful write without a successful close does not constitute a completed upload.
- BR-007 - If a callback trigger is registered at index -1 at the time all chunks are received, it must be executed before the trigger registration is cleared, ensuring downstream notification of upload completion.
- BR-008 - WEBUTIL.CLEARCALLBACKTRIGGER(-1) must always be called after the final chunk is processed, regardless of whether a callback trigger was executed, to prevent stale trigger references from affecting subsequent operations.

---
**Implementation Logic**

```plsql
   
  PROCEDURE SetData(uploadData in VARCHAR2) is 
    lastErrorCode    PLS_INTEGER;
    lastErrorArgs    VARCHAR2(1000);   
  BEGIN
    if uploadData is null or uploadData = '' then 
      -- error condition!
      m_uploadSucceeded := false;
    else
      -- Write to the correct place    
      if m_toDB then 
        WebUtil_DB_LOCAL.WriteData(uploadData);
      else
        if not JAVA_APPSERV_WRITER.WriteData(m_persistObj,uploadData) then
          lastErrorCode := JAVA_APPSERV_WRITER.getLastError(m_persistObj);
          lastErrorArgs := JAVA_APPSERV_WRITER.getLastErrorArgs(m_persistObj) ;
          WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                             'WEBUTIL_FILE_TRANSFER.SetData',lastErrorArgs);
          raise READWRITE_ERROR;
        end if;
      end if;
      m_chunks := m_chunks - 1;
      if m_chunks = 0 then 
        if m_toDB then 
          if WebUtil_DB_Local.CloseBlob(m_fileSize) then 
            m_uploadSucceeded := true;
          else
            WebUtil_core.Error(Webutil_Core.WUT_PACKAGE, WebUtil_DB_Local.getLastError,
                               'WEBUTIL_FILE_TRANSFER.SetData');
          end if; -- close
        else
          if JAVA_APPSERV_WRITER.CloseFile(m_persistObj,m_fileSize) then
            m_uploadSucceeded := true;
          else
            lastErrorCode := JAVA_APPSERV_WRITER.getLastError(m_persistObj);
            lastErrorArgs := JAVA_APPSERV_WRITER.getLastErrorArgs(m_persistObj) ;
            WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                               'WEBUTIL_FILE_TRANSFER.SetData',lastErrorArgs);
            ORA_JAVA.DELETE_GLOBAL_REF(m_persistObj);
            raise READWRITE_ERROR;
          end if;    
        end if; -- toDB

        if WebUtil_Core.GetCallbackTrigger(-1) is not null then
          EXECUTE_TRIGGER(WebUtil_Core.GetCallbackTrigger(-1));
        end if;
        WebUtil_Core.ClearCallbackTrigger(-1);
      end if; -- chunks
    end if;
  end SetData;
```

#### SP-068 - WEBUTIL.SETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sets a named property value on a specified WebUtil bean package. Provides the fundamental set-property mechanism used throughout the WebUtil infrastructure to send instructions and values to WebUtil beans.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |
| a1 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept a package identifier, property name, and value to set.
- Step 2 - Submit the property value to the specified bean.
- Step 3 - Optionally wait for the bean to acknowledge the property change if synchronous mode is specified.

---
**Decision Points**

No conditional branches - sets the property on the bean.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - No form-specific business rules - WebUtil infrastructure utility providing the core property-write mechanism.

---
**Implementation Logic**

```plsql
  FUNCTION setProperty(
    a0    VARCHAR2,
    a1    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(2);
    JNI.ADD_STRING_ARG(args, a0);
    JNI.ADD_STRING_ARG(args, a1);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'setProperty', '(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-069 - WEBUTIL.SHOWBEANS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.INITWEBUTIL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Displays diagnostic information about all registered WebUtil beans in the current session. Used for troubleshooting to verify which beans are available and correctly initialised.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| show | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-051](#SP-051--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Query the WebUtil infrastructure for the list of registered beans.
- Step 2 - Display the bean information to the developer or administrator (typically via a message or alert).

---
**Decision Points**

No conditional branches - reads and displays bean registration information.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - No form-specific business rules - WebUtil infrastructure diagnostic utility.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ShowBeans(show BOOLEAN) is
    hWin WINDOW := FIND_WINDOW(WEBUTIL_HIDDEN_WINDOW);
  begin
    -- Bug 2955789 - don't attempt to do this when in Enter Query Mode
    if name_in('SYSTEM.MODE') = 'NORMAL' then 
      if not ID_NULL(hWin) then 
        if show then 
          m_infoFrom := FIND_ITEM(name_in('SYSTEM.CURSOR_ITEM'));
          SET_WINDOW_PROPERTY(hWin,TITLE,'WebUtil '||WEBUTIL_VERSION);
          SHOW_WINDOW(hWin);
          go_item(WEBUTIL_DUMMY_ITEM);
        else
          if not id_null(m_infoFrom) then 
              go_item(m_infoFrom);
          end if;
          HIDE_WINDOW(hWin);
        end if;
      end if;
    end if;
  end ShowBeans;
```

#### SP-070 - WEBUTIL.URL_TO_CLIENT

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Downloads a file from a URL on the application server to a destination file path on the client workstation. Returns a boolean indicating whether the transfer succeeded. Used to deliver generated report files to the user's workstation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| fileSize | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.DOWNLOADFROMURL ([SP-026](#SP-026--WEBUTIL.DOWNLOADFROMURL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the source URL and client destination file path.
- Step 2 - Call the internal download function to transfer the file.
- Step 3 - Return TRUE if the transfer succeeded, FALSE otherwise.

---
**Decision Points**

No conditional branches - delegates to the internal download function and returns the result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - No form-specific business rules - WebUtil utility for transferring files from the application server to the client workstation.

---
**Implementation Logic**

```plsql
  FUNCTION URL_To_Client(sourceURL         in VARCHAR2, 
                         clientDestination in VARCHAR2, 
                         fileSize          in PLS_INTEGER default 0) return BOOLEAN is
  BEGIN
      return WebUtil_Core.DownLoadFromURL(sourceURL, 
                                        clientDestination, 
                                        fileSize);
  END URL_To_Client;
```

#### SP-071 - WEBUTIL.WRITEDATA

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Passes a string data payload to the AppServerFileWriter Java class on the application server by invoking its WriteData method via the JNI bridge. The function returns a Boolean indicating whether the write operation succeeded, enabling the caller (WEBUTIL.SETDATA) to confirm that the data was accepted by the server-side file writer.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java object reference (obj) identifying the target AppServerFileWriter instance and the string data payload (a0) to be written.
- Step 2 - Create a JNI argument list sized for one argument by calling JNI.CREATE_ARG_LIST(1).
- Step 3 - Add the string payload (a0) to the argument list by calling JNI.ADD_STRING_ARG(args, a0).
- Step 4 - Invoke the Java WriteData method on the AppServerFileWriter instance via JNI.CALL_BOOLEAN_METHOD, passing the object reference, the fully qualified class path ('oracle/forms/webutil/fileTransfer/AppServerFileWriter'), the method name ('WriteData'), the method signature ('(Ljava/lang/String;)Z'), and the prepared argument list.
- Step 5 - Return the Boolean result produced by JNI.CALL_BOOLEAN_METHOD to the caller, indicating success (TRUE) or failure (FALSE) of the write operation.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function constructs the JNI call unconditionally and returns the Boolean result directly from JNI.CALL_BOOLEAN_METHOD to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The data payload must be supplied as a VARCHAR2 string (a0); no transformation or validation of the payload is performed within this function before it is forwarded to the Java layer.
- BR-002 - The target Java object (obj) must be a valid AppServerFileWriter instance; the function invokes WriteData exclusively on the 'oracle/forms/webutil/fileTransfer/AppServerFileWriter' class and will not operate against any other class type.
- BR-003 - The function returns FALSE as the default fallback value passed to JNI.CALL_BOOLEAN_METHOD, meaning a failure to execute the Java method resolves to a FALSE (unsuccessful) result rather than raising an unhandled exception.
- BR-004 - The function is intended to be called from WEBUTIL.SETDATA; direct invocation from any other context is outside the defined scope of this procedure.

---
**Implementation Logic**

```plsql
  FUNCTION WriteData(
    obj   ORA_JAVA.JOBJECT,
    a0    VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_BOOLEAN_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileWriter', 'WriteData', '(Ljava/lang/String;)Z', args); 
  END;
```

#### SP-072 - WEBUTIL_CORE.CUSTOMEVENTHANDLER

**Invoked From:**

- vi_ro_hold_up_fmb.xml [Trigger: WHEN-CUSTOM-ITEM-EVENT]

---

**Screen:**

N/A

---

**Purpose**

CUSTOMEVENTHANDLER is the central dispatcher for custom item events raised by the WebUtil client-side bean. It receives an event name and its associated parameters from a WHEN-CUSTOM-ITEM-EVENT trigger, extracts the data payload and multi-part chunk metadata, and routes execution to the appropriate WebUtil subsystem handler (logging, error reporting, bean registration, host-command callbacks, or file-transfer processing). Only recognised WebUtil event names are processed; all others are silently discarded.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| EventName | VARCHAR2 | IN |
| EventParameters | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERROR ([SP-028](#SP-028--WEBUTIL.ERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETNUMBER ([SP-041](#SP-041--WEBUTIL.GETNUMBER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-057](#SP-057--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.REGISTERBEAN ([SP-063](#SP-063--WEBUTIL.REGISTERBEAN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETDATA ([SP-067](#SP-067--WEBUTIL.SETDATA)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETPROPERTY ([SP-068](#SP-068--WEBUTIL.SETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Validate the incoming EventName against the set of known WebUtil events ('WUC_LOG_EVENT', 'WUC_ERROR_EVENT', 'WUC_REGISTER', 'WUH_CALLBACK_EVENT', 'WUT_TRANSFER_EVENT'). If the name is not in this set, raise the internal 'unhandled' exception, which is caught and suppressed, terminating processing with no action.
- Step 2 - Extract the primary data payload from EventParameters by calling the internal helper GET_PARAMETER_ATTR for the attribute key 'WUC_DATA', storing the result in dataPayload.
- Step 3 - Extract the multi-part chunk descriptor from EventParameters by calling GET_PARAMETER_ATTR for the attribute key 'WUC_DATA_MULTIPART', storing the result in dataMultiPart.
- Step 4 - Parse dataMultiPart using DELIMSTR.GETNUMBER to determine the current chunk sequence number (chunkNumber, position 1) and the total number of chunks that constitute the full payload (PayloadChunks, position 2), using '/' as the delimiter.
- Step 5 - Route to the appropriate handler based on EventName:
  - If 'WUC_LOG_EVENT': call WEBUTIL_CORE.LOG with dataPayload and the informational flag set to FALSE.
  - If 'WUC_ERROR_EVENT': call WEBUTIL_CORE.LOG with dataPayload and the error flag set to TRUE.
  - If 'WUC_REGISTER': call WEBUTIL_CORE.REGISTERBEAN with dataPayload to register the client-side bean.
  - If 'WUH_CALLBACK_EVENT': convert dataPayload to a numeric callback index (m_lastCallback). If conversion fails (INVALID_NUMBER), call WEBUTIL_CORE.ERROR with package constant WUC_PACKAGE, error code 408, and the procedure name as context. If the index is not null, execute the corresponding trigger stored in m_callbacks; otherwise log a warning via WEBUTIL_CORE.LOG.
  - If 'WUT_TRANSFER_EVENT': call WEBUTIL_FILE_TRANSFER.SETDATA with dataPayload to store the transferred data, then call WEBUTIL_CORE.SETPROPERTY to mark the WUT_PACKAGE item property 'WUT_TRANSFER_EVENT' as 'RECEIVED'.
- Step 6 - On any unhandled exception other than the internal 'unhandled' exception, re-raise to the caller.

---
**Decision Points**

DP-001

Condition: EventName is NOT in ('WUC_LOG_EVENT', 'WUC_ERROR_EVENT', 'WUC_REGISTER', 'WUH_CALLBACK_EVENT', 'WUT_TRANSFER_EVENT').

TRUE: Raise the internal 'unhandled' exception; the exception handler catches it and suppresses it (NULL), ending the procedure without further processing.

FALSE: Continue to payload extraction and event routing (Steps 2-5).

---

DP-002

Condition: EventName = 'WUC_LOG_EVENT'.

TRUE: Call WEBUTIL_CORE.LOG(dataPayload, FALSE) to write an informational log entry.

FALSE: Evaluate the next event branch (DP-003).

---

DP-003

Condition: EventName = 'WUC_ERROR_EVENT'.

TRUE: Call WEBUTIL_CORE.LOG(dataPayload, TRUE) to write an error log entry.

FALSE: Evaluate the next event branch (DP-004).

---

DP-004

Condition: EventName = 'WUC_REGISTER'.

TRUE: Call WEBUTIL_CORE.REGISTERBEAN(dataPayload) to register the client bean.

FALSE: Evaluate the next event branch (DP-005).

---

DP-005

Condition: EventName = 'WUH_CALLBACK_EVENT'.

TRUE: Attempt numeric conversion of dataPayload to m_lastCallback; handle INVALID_NUMBER by calling WEBUTIL_CORE.ERROR. If m_lastCallback is not null, execute the associated callback trigger; otherwise log a warning. Proceed to DP-005a and DP-005b.

FALSE: Evaluate the next event branch (DP-006).

---

DP-005a

Condition: Conversion of dataPayload to a number raises INVALID_NUMBER.

TRUE: Call WEBUTIL_CORE.ERROR with package constant WUC_PACKAGE, error code 408, and context string 'WEBUTIL_CORE.CustomEventHandler'.

FALSE: Assign the numeric value to m_lastCallback and continue.

---

DP-005b

Condition: m_lastCallback IS NOT NULL (a valid callback index was resolved).

TRUE: Execute the trigger referenced by m_callbacks(m_lastCallback).

FALSE: Call WEBUTIL_CORE.LOG to record the warning 'Callback trigger for host command not specified' with the error flag set to TRUE.

---

DP-006

Condition: EventName = 'WUT_TRANSFER_EVENT'.

TRUE: Call WEBUTIL_FILE_TRANSFER.SETDATA(dataPayload) to store the file-transfer data, then call WEBUTIL_CORE.SETPROPERTY to set the WUT_PACKAGE property 'WUT_TRANSFER_EVENT' to 'RECEIVED'.

FALSE: No further branches; end of routing logic.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only events explicitly enumerated as valid WebUtil events ('WUC_LOG_EVENT', 'WUC_ERROR_EVENT', 'WUC_REGISTER', 'WUH_CALLBACK_EVENT', 'WUT_TRANSFER_EVENT') may be processed; any other event name is silently ignored without raising an error to the caller.
- BR-002 - Every event dispatch, regardless of type, requires prior extraction of both the data payload ('WUC_DATA') and the multi-part chunk descriptor ('WUC_DATA_MULTIPART') from the EventParameters string before handler-specific logic executes.
- BR-003 - A callback payload received via 'WUH_CALLBACK_EVENT' must be convertible to a valid number; if it is not, error code 408 must be raised via WEBUTIL_CORE.ERROR and the callback trigger must not be executed.
- BR-004 - A 'WUH_CALLBACK_EVENT' with a null resolved callback index (m_lastCallback IS NULL) must not attempt trigger execution; a warning must be logged instead.
- BR-005 - On receipt of a 'WUT_TRANSFER_EVENT', the file-transfer data must be stored via WEBUTIL_FILE_TRANSFER.SETDATA and the transfer status property must be updated to 'RECEIVED' via WEBUTIL_CORE.SETPROPERTY before the procedure exits, ensuring downstream components can detect transfer completion.
- BR-006 - Any unexpected exception that is not the internal 'unhandled' sentinel must be re-raised to the calling trigger, preserving full error visibility for the application.

---
**Implementation Logic**

```plsql
  PROCEDURE CustomEventHandler(EventName       in VARCHAR2, 
                               EventParameters in VARCHAR2) is
    dataPayload   VARCHAR2(32767 char);   
    dataMultiPart VARCHAR2(61 char); /* should be enough! */ 
    chunkNumber   PLS_INTEGER;
    PayloadChunks PLS_INTEGER;
    dataType      PLS_INTEGER;
    unhandled     EXCEPTION;
  begin
    --Bug 2839033 - check for valid events only      
    if EventName not in ('WUC_LOG_EVENT',
                         'WUC_ERROR_EVENT', 
                         'WUC_REGISTER',
                         'WUH_CALLBACK_EVENT', 
                         'WUT_TRANSFER_EVENT') then  
      raise unhandled;
    end if;                        

    -- We're pretty much always going to need the data payload and 
    -- number of parts that make up that payload so get it now..
    get_parameter_attr(EventParameters,'WUC_DATA',dataType, dataPayload);
    get_parameter_attr(EventParameters,'WUC_DATA_MULTIPART',dataType, dataMultiPart);      
    -- split the MULTIPART info to work out how many messages from the 
    -- client are required to create the completed payload
    chunkNumber   := DelimStr.getNumber(dataMultiPart,1,true,'/');
    PayloadChunks := DelimStr.getNumber(dataMultiPart,2,true,'/');

    -- Now deal with the specific events that the client may dispatch
    -- This section will have to be extended for each new event that we 
    -- Add in order to hook the handler code for that message to the data 
    -- that is being sent - shame we can't subclass in PL/SQL :-)      
    if EventName = 'WUC_LOG_EVENT' then
        WebUtil_Core.log(dataPayload,false);
    elsif EventName = 'WUC_ERROR_EVENT' then
        WebUtil_Core.log(dataPayload,true);
    elsif EventName = 'WUC_REGISTER' then 
        registerBean(dataPayload);
    elsif EventName = 'WUH_CALLBACK_EVENT' then 
      begin 
        m_lastCallback := to_number(dataPayload);
      exception
          when INVALID_NUMBER then 
            error(WebUtil_Core.WUC_PACKAGE,408,'WEBUTIL_CORE.CustomEventHandler');
      end;
      if m_lastCallback is not null then 
          EXECUTE_TRIGGER(m_callbacks(m_lastCallback));
      else
            log('Callback trigger for host command not specified',true);
      end if;
    elsif EventName = 'WUT_TRANSFER_EVENT' then 
      WebUtil_File_Transfer.setData(dataPayload);
      WebUtil_Core.setProperty(WebUtil_Core.WUT_PACKAGE, 'WUT_TRANSFER_EVENT','RECEIVED');
    end if;
  exception
    when unhandled then
      null;
    when OTHERS then
      raise;
  end CustomEventHandler;
```

#### SP-073 - ADD_ERROR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.FILE_INFO]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.SAVE_FILE]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Records a single error entry in the Win32 API utility error state by setting a shared error flag and overwriting the error stack with the calling function name concatenated with the supplied error message text. Also forwards the composed error entry to the debug logging facility (DEBUGLOG) for diagnostic traceability.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| CallingFunction | VARCHAR2 | IN |
| SetErrorText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-077](#SP-077--DEBUGLOG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Accept the calling function name (CallingFunction) and the error message text (SetErrorText) as inputs.
- Step 2 - Set the shared boolean flag ERROR_ENCOUNTERED to TRUE, indicating that an error condition is now active.
- Step 3 - Compose the error stack entry by concatenating CallingFunction, a colon-space separator, and SetErrorText truncated to a maximum of 1,968 characters, then assign the result to the shared variable ERROR_STACK.
- Step 4 - Invoke DEBUGLOG (SP-077) at debug level 99, identifying the source routine as 'Add_Error' and passing the composed ERROR_STACK value for diagnostic logging.

---
**Decision Points**

No conditional branches - the procedure unconditionally sets the error flag, overwrites the error stack, and calls DEBUGLOG regardless of input values.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The error message text is truncated to 1,968 characters before being stored in ERROR_STACK, preventing overflow of the shared error variable.
- BR-002 - ERROR_STACK holds only the most recently added error entry; each call to ADD_ERROR overwrites any previously recorded error, meaning only the last error in a sequence is retained.
- BR-003 - ERROR_ENCOUNTERED must be set to TRUE on every invocation, ensuring that any downstream caller inspecting the flag can detect that an error has occurred.
- BR-004 - All error entries are forwarded to DEBUGLOG at severity level 99, providing a consistent audit trail for Win32 API utility errors across all ten invoking procedures.

---
**Implementation Logic**

```plsql

PROCEDURE Add_Error (CallingFunction in VARCHAR2, SetErrorText in VARCHAR2) is
begin 
  -- Just watch for value errors 
  ERROR_ENCOUNTERED  := TRUE;
  ERROR_STACK    := CallingFunction||': '||substr(SetErrorText,1,1968);
  Win_API_Debug.DebugLog(99,'Add_Error',ERROR_STACK);
end Add_Error;
```

#### SP-074 - ADD_EXTERNAL_ERRORS

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.FILE_INFO]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves and formats any external system error information (such as OS-level errors) and returns it as a string to be appended to an error message. Used to enrich Win32 API error reports with additional context from the operating system.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Query the Win32 API bridge for any external error information captured since the last operation.
- Step 2 - Format the external error details as a string.
- Step 3 - Return the formatted error string to the caller.

---
**Decision Points**

No conditional branches - retrieves and returns any available external error information.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - No form-specific business rules - Win32 API infrastructure utility for retrieving external error context.

---
**Implementation Logic**

```plsql

FUNCTION Add_External_Errors return varchar2 is
  iCounter   pls_integer;
  vcErrBuff  varchar2(1968);
begin 
  if tool_err.nerrors > 0 then 
    for iCounter in 1..tool_err.nerrors LOOP
      begin 
        vcErrBuff := vcErrBuff||chr(10)||tool_err.message;
      exception
        when VALUE_ERROR then 
          exit; /* String exceeds allowable buffer */
      end;
      tool_err.pop;
    end loop;
  elsif SQLERRM is not null then 
    vcErrBuff := chr(10)||SQLERRM; 
  end if;
  return vcErrBuff;
end Add_External_Errors;
```

#### SP-075 - BOOLTOCHAR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.FILE_INFO]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Converts a PL/SQL BOOLEAN value to its full-word string representation ('TRUE' or 'FALSE'). Used as a diagnostic utility within the D2KWUTIL package to render boolean results as readable text in contexts such as file operations, window queries, registry reads, and environment lookups where a VARCHAR2 representation is required.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| ThisBoolean | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input BOOLEAN value (ThisBoolean).
- Step 2 - Evaluate whether ThisBoolean is TRUE.
- Step 3 - If TRUE, return the string 'TRUE'.
- Step 4 - If FALSE (including when the value is FALSE), return the string 'FALSE'.

---
**Decision Points**

DP-001

Condition:
The input BOOLEAN value (ThisBoolean) evaluates to TRUE.

TRUE:
Return the VARCHAR2 string 'TRUE'.

FALSE:
Return the VARCHAR2 string 'FALSE'.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function returns only two possible values: 'TRUE' or 'FALSE'; a NULL input is not handled as a distinct case and will follow the ELSE branch, returning 'FALSE'.
- BR-002 - No form-specific business rules apply; this is a diagnostic utility used by D2KWUTIL procedures (CHOOSEFILE, FILE_INFO, GET_ACTIVE_WINDOW, GET_ENVIRONMENT_STRING, GET_TEMP_DIRECTORY, GET_WINDOWS_DIRECTORY, READ_REGISTRY) to convert boolean outcomes to displayable text.

---
**Implementation Logic**

```plsql

  
  FUNCTION  BoolToChar(ThisBoolean IN BOOLEAN) return VARCHAR2 is
  begin
  	if ThisBoolean then 
  		RETURN 'TRUE';
  	else
  	    RETURN 'FALSE';
  	end if;
  end BoolToChar;

END;

PACKAGE WIN_API_DIALOG IS

/*-------------------------------------------------------------------------*\
 * WIN_API_DIALOG ->   This package is concerned with Displaying Common
 *      dialogs
 * Contents:
 *    Open_File    -> Open File Dialog
 *    Save_File    -> Save File Dialog
 *    Select_Printer    -> Printer Selection Dialog
 *    Choose_Font       -> Display the Font Selection Dialog
 *    Choose_Color      -> Display the Color Selection Dialog
 * Dependancies:
 *    WIN_API_ENVIRONMENT
 *    WIN_API
 *    WIN_API_DEBUG
\*-------------------------------------------------------------------------*/ 

/*-------------------------------------------------------------------------*\
 * Open_File        -> Displays the standard Open File dialog
 * Arguments: 
 *  Title           -> The Title for the Dialog Box
 *                     (Default -> 'Open File')
 *  StartDirectory  -> Where the dialog should start from
 *                     this should be in the format 'C:\TEMP'
 *                     (Default -> Windows Directory)
 *  FileFilter      ->  Restrict the list of files. The filter string 
 *                      should be in the format:
 *                      '<Description>|<filename>.<Extension>|'
 *                      typically this would be something like
 *                      'All files(*.*)|*.*|' or 'Text files(*.txt)|*.txt|'
 *                      "All Files" is the Default
 *  Modal           ->  Should the dialog be modal with respect to the 
 *                      application? 
 *                      default = TRUE
 *  AdvancedFlags   ->  (See list in WIN_API header) This option allows
 *                      you to change the attributes of the Open File 
 *                      dialog.  Here are some of the Flags that might
 *                      be of interest:
 *                      OFN_HIDEREADONLY  Hides the Read Only check box.
 *                      OFN_NONETWORKBUTTON  Hides the Network Button
 *                      OFN_EXPLORER    Display an Explorer style 
 *                        Dialog rather than the conventional one.
 *                      See your Microsoft docmentation for details on 
 *                      each flag.
 *                      To Set the Advanced_Flags varaible, just add the 
 *                      required flags together.  The default is:
 *                      WIN_API.OFN_PATHMUSTEXIST + WIN_API.OFN_FILEMUSTEXIST +
 *                      WIN_API.OFN_HIDEREADONLY + WIN_API.OFN_NOCHANGEDIR 
 *  RaiseExceptions ->  TRUE of FALSE(Default) If set to true, then if the 
 *                      command is not successful (e.g no filename is  
 *                      returned) then the explicit exception
 *                      NO_DATA_FOUND will be raised.
 *        
 * Returns:
 *  Path and name of the selected file
\*-------------------------------------------------------------------------*/
```

#### SP-076 - CLEAN_ERROR_STACK

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.FILE_INFO]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Clears all entries from the Win32 API error stack, resetting the error state before a new operation begins. Ensures that error reports reflect only errors from the current operation, not from previous calls.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Reset the internal error stack to empty, removing all previously recorded error entries.

---
**Decision Points**

No conditional branches - unconditionally clears the error stack.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - No form-specific business rules - Win32 API infrastructure utility for resetting the error state before each operation.

---
**Implementation Logic**

```plsql

PROCEDURE Clean_Error_Stack is 
begin 
  -- just empty the variables
  ERROR_ENCOUNTERED  := FALSE;
  ERROR_STACK        := NULL;
end Clean_Error_Stack;
```

#### SP-077 - DEBUGLOG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: ADD_ERROR]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.FILE_INFO]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: SETDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a formatted diagnostic log entry to either a Windows debug output channel or a flat file, depending on the active debug mode. The procedure gates output against the current debug state, pause flag, and verbosity threshold, ensuring that only relevant trace entries are recorded. It is used throughout the D2kwutil library to trace procedure calls and diagnostic messages.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugLevel | PLS_INTEGER | IN |
| LoggingCall | VARCHAR2 | IN |
| LogString | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- SETDEBUG ([SP-083](#SP-083--SETDEBUG)) - matched by member name
- WEBUTIL.LENGTH ([SP-056](#SP-056--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)
- WINDEBUG ([SP-086](#SP-086--WINDEBUG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Accept the requested verbosity level (DebugLevel), the calling procedure name (LoggingCall), and the message text (LogString).
- Step 2 - Check whether debug logging is globally disabled (iDebugState = 0); if so, exit immediately with no action.
- Step 3 - Check whether debug logging is currently paused (bDebugPaused); if so, exit immediately with no action.
- Step 4 - Check whether the requested DebugLevel exceeds the current threshold (iDebugLevel); if so, exit immediately with no action.
- Step 5 - If a timestamp is enabled (bDebugTimeStamp), format the current system time as HH24:MI:SS and append a '>' separator.
- Step 6 - Construct the formatted log string by combining the padded debug level, optional timestamp, the calling procedure name right-padded to 30 characters, and the message text truncated so the total does not exceed 2000 characters.
- Step 7 - If the debug state is 2 (Windows debugger mode) and the debug API is available (DEBUG_API_ENABLED), write the formatted string via WINDEBUG (win_api_debug.WinDebug).
- Step 8 - If the debug state is 2 but the debug API is unavailable, fall back to file logging by calling SETDEBUG to switch to file mode (state 1), log a fallback notice, re-emit the original log entry recursively, and set bDebugType2Required to TRUE to remember that debugger mode was intended.
- Step 9 - If the debug state is not 2 but bDebugType2Required is TRUE and the debug API has since become available, call SETDEBUG to restore debugger mode (state 2), log a restoration notice, clear bDebugType2Required, and re-emit the original log entry recursively.
- Step 10 - Otherwise (file logging mode with no pending mode switch), open the target log file in append mode, write the formatted string, and close the file.
- Step 11 - If any exception occurs during the above steps, suppress it and set iDebugState to 0 to prevent further logging errors from disrupting the calling form.

---
**Decision Points**

DP-001

Condition:
iDebugState = 0

TRUE:
Debug logging is globally disabled; exit the procedure immediately without writing any entry.

FALSE:
Proceed to check the pause flag.

---

DP-002

Condition:
bDebugPaused is TRUE

TRUE:
Debug logging is temporarily paused; exit the procedure immediately without writing any entry.

FALSE:
Proceed to check the verbosity threshold.

---

DP-003

Condition:
DebugLevel > iDebugLevel

TRUE:
The requested verbosity level exceeds the current threshold; skip the log entry.

FALSE:
The entry qualifies for logging; proceed to format and write it.

---

DP-004

Condition:
bDebugTimeStamp is TRUE

TRUE:
Format the current system time (HH24:MI:SS) and include it as a prefix in the log string.

FALSE:
Omit the timestamp from the log string.

---

DP-005

Condition:
iDebugState = 2 (Windows debugger mode)

TRUE:
Attempt to write via the Windows debug API (WINDEBUG); evaluate API availability (DP-006).

FALSE:
Proceed to file-based logging path; evaluate pending mode-restore flag (DP-007).

---

DP-006

Condition:
DEBUG_API_ENABLED is TRUE (within debugger mode branch)

TRUE:
Write the formatted log string using WINDEBUG (win_api_debug.WinDebug).

FALSE:
API unavailable; call SETDEBUG to switch to file mode (state 1), log a fallback notice, recursively re-emit the original entry, and set bDebugType2Required to TRUE.

---

DP-007

Condition:
bDebugType2Required is TRUE AND DEBUG_API_ENABLED is TRUE (within file-mode branch)

TRUE:
The Windows debug API has become available again; call SETDEBUG to restore debugger mode (state 2), log a restoration notice, clear bDebugType2Required, and recursively re-emit the original entry.

FALSE:
Write the formatted log string to the target file in append mode using TEXT_IO, then close the file.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Debug output is suppressed entirely when iDebugState is 0, when logging is paused (bDebugPaused), or when the entry's DebugLevel exceeds the configured threshold (iDebugLevel); all three conditions must pass before any output is produced.
- BR-002 - The formatted log string must not exceed 2000 characters; the message text (LogString) is truncated to enforce this limit after the level indicator, optional timestamp, and padded procedure name have been prepended.
- BR-003 - When operating in Windows debugger mode (iDebugState = 2) and the debug API is unavailable, the procedure automatically degrades to file logging by invoking SETDEBUG and sets bDebugType2Required to TRUE so that the original intent is preserved.
- BR-004 - When operating in file mode and the Windows debug API becomes available (bDebugType2Required = TRUE and DEBUG_API_ENABLED = TRUE), the procedure automatically restores debugger mode by invoking SETDEBUG before re-emitting the pending entry, ensuring no log entries are lost during the transition.
- BR-005 - Any unhandled exception raised during logging is silently caught and iDebugState is set to 0, preventing diagnostic instrumentation from propagating errors to the calling business procedure.
- BR-006 - Mode switches and fallback/restore events are themselves logged as discrete entries (at level 0, attributed to 'DebugLog') to maintain a complete audit trail of logging-channel changes.

---
**Implementation Logic**

```plsql
   
PROCEDURE DebugLog (DebugLevel  IN PLS_INTEGER, 
                    LoggingCall IN VARCHAR2, 
                    LogString   IN VARCHAR2) is
 vcDateStamp   VARCHAR2(10);
 vcDebugString VARCHAR2(2000);
 hFile         TEXT_IO.FILE_TYPE;
begin
  if iDebugState = 0 then 
  	NULL;
  elsif bDebugPaused then 
  	NULL;
  elsif DebugLevel > iDebugLevel then 
  	NULL;
  else
  	-- Sort out the Datestamp	
  	if bDebugTimeStamp then 
  		vcDateStamp := to_char(SYSDATE,'HH24:MI:SS')||'> ';
  	end if;
  
  	-- Construct the final String
  	vcDebugString := '<'||lpad(to_char(DebugLevel),2,0)||'> '||vcDateStamp||rpad(LoggingCall||':',30);
    vcDebugString := vcDebugString||substr(LogString,1,(2000-length(vcDebugString)));
  
  	if iDebugState = 2 then
  		if DEBUG_API_ENABLED then 
  	   		win_api_debug.WinDebug(vcDebugString);
  		else
  			-- Can't use API calls if the API functions aren't there
	  		-- So Switch to File Logging to d2kwut$.log
	  		SetDebug(1,nvl(vcDebugFile,'d2kwutil.log'),iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Unable to Log to Debugger Switching to File');
			DebugLog(DebugLevel,LoggingCall,LogString);	  		
	  		bDebugType2Required := TRUE;
	  	end if;
  	else
     	if bDebugType2Required and DEBUG_API_ENABLED then
	     	-- API now Available - Reinstate Debugging to Debugger
	  		SetDebug(2,vcDebugFile,iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Restoring Logging to Debugger');
	  		bDebugType2Required := FALSE;
	  		DebugLog(Debuglevel,LoggingCall,LogString);
	
	  	else
		 	hFile := TEXT_IO.FOPEN(vcDebugFile,'A');
		 	TEXT_IO.PUT_LINE(hFile,vcDebugString);
		 	TEXT_IO.FCLOSE(hFile);
		end if;
  	end if;
  end if;
 exception
  	-- Don't let the debugging cause Problems of it's own
  	when others then 
  		iDebugState := 0;
 end DebugLog;
```

#### SP-078 - GET_ENVIRONMENT_STRING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value of a named operating system environment variable from the client workstation by invoking the D2KWUTIL native bridge function D2KWUTIL_GETDOSENV. Logs entry and result via DEBUGLOG, cleans the error stack before execution, and returns the resolved variable value as a VARCHAR2 string. Returns NULL or raises NO_DATA_FOUND if the variable cannot be resolved, and raises NOT_AVAILABLE if the Win32 API bridge is disabled.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VariableName | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-073](#SP-073--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-074](#SP-074--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-075](#SP-075--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-076](#SP-076--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_GETDOSENV ([SP-009](#SP-009--D2KWUTIL.D2KWUTIL_GETDOSENV)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-077](#SP-077--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-082](#SP-082--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Accept the environment variable name (VariableName) and an optional flag (RaiseExceptions, defaulting to FALSE) controlling error propagation behaviour.
- Step 2 - Write a debug entry via DEBUGLOG recording the input arguments, including the RaiseExceptions flag converted to a character representation using BOOLTOCHAR.
- Step 3 - Clear any pre-existing error state on the Win32 API error stack by calling CLEAN_ERROR_STACK.
- Step 4 - Check whether the Win32 API bridge is enabled (WIN_API.API_ENABLED). If not enabled, raise the NOT_AVAILABLE exception immediately.
- Step 5 - Register the native D2KWUTIL_GETDOSENV function signature via REGISTER_FUNCTION_CALL, specifying the expected parameter types (LONG, *CHAR, *CHAR, LONG).
- Step 6 - Construct the environment variable lookup token by wrapping VariableName with percent signs (e.g. %VariableName%), and initialise a 512-character output buffer padded with null characters.
- Step 7 - Invoke D2KWUTIL.D2KWUTIL_GETDOSENV via the registered function handle, passing the lookup token, the output buffer, and the buffer length; capture the integer return code.
- Step 8 - Write a second debug entry via DEBUGLOG recording the return code (value length) and the resolved value string.
- Step 9 - Evaluate the return code and output buffer: if the return code is 0 or the output buffer still equals the unexpanded lookup token, the variable was not resolved; record an error via ADD_ERROR.
- Step 10 - If the variable was not resolved and RaiseExceptions is TRUE, raise NO_DATA_FOUND; otherwise return NULL.
- Step 11 - If the variable was resolved successfully, return the populated output buffer value to the caller.
- Step 12 - In the exception block: re-raise NO_DATA_FOUND as-is; for NOT_AVAILABLE, log the error via ADD_ERROR and re-raise; for all other exceptions, log the error combined with any external error details via ADD_ERROR and ADD_EXTERNAL_ERRORS, then re-raise.

---
**Decision Points**

DP-001

Condition:
WIN_API.API_ENABLED is TRUE (the Win32 API bridge is available on the client workstation)

TRUE:
Proceed to register D2KWUTIL_GETDOSENV via REGISTER_FUNCTION_CALL and invoke the native function to retrieve the environment variable value.

FALSE:
Raise the WIN_API.NOT_AVAILABLE exception; execution does not proceed to the native call.

---

DP-002

Condition:
The return code from D2KWUTIL.D2KWUTIL_GETDOSENV is 0, or the output buffer is unchanged from the unexpanded lookup token (indicating the variable was not found or could not be expanded)

TRUE:
Record an error via ADD_ERROR stating the variable value could not be retrieved, then evaluate RaiseExceptions (see DP-003).

FALSE:
Return the resolved environment variable value string to the caller.

---

DP-003

Condition:
RaiseExceptions parameter is TRUE (evaluated only when the environment variable could not be resolved)

TRUE:
Raise NO_DATA_FOUND to signal the failure to the calling context.

FALSE:
Return NULL silently to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The Win32 API bridge must be enabled (WIN_API.API_ENABLED) before any attempt is made to read a client environment variable; if the bridge is unavailable the procedure always raises NOT_AVAILABLE regardless of other inputs.
- BR-002 - The environment variable lookup token must be formed by enclosing the supplied VariableName in percent signs before passing it to D2KWUTIL.D2KWUTIL_GETDOSENV; raw variable names without delimiters are not valid lookup tokens for this bridge function.
- BR-003 - The output buffer is fixed at 512 characters; environment variable values exceeding this length will be truncated.
- BR-004 - A return code of 0 from D2KWUTIL.D2KWUTIL_GETDOSENV, or an output buffer that remains equal to the unexpanded lookup token, is treated as a failed resolution and must be recorded as an error via ADD_ERROR.
- BR-005 - The caller controls whether an unresolved variable is a fatal condition: when RaiseExceptions is TRUE a NO_DATA_FOUND exception is raised; when FALSE a NULL value is returned silently.
- BR-006 - All entry arguments and resolution results must be written to the debug log via DEBUGLOG (at debug level 99) to support diagnostic tracing; the RaiseExceptions boolean argument must be converted to a character value using BOOLTOCHAR before concatenation into the log message.
- BR-007 - The error stack must be cleared via CLEAN_ERROR_STACK at the start of each invocation to prevent stale error state from prior calls from contaminating error reporting for the current call.

---
**Implementation Logic**

```plsql

FUNCTION Get_Environment_string (  VariableName      IN  VARCHAR2,
                                   RaiseExceptions   IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  vcBuff2    VARCHAR2(512);
  iBuff1    PLS_INTEGER;
  iRC        PLS_INTEGER;
begin 
  Win_api_debug.DebugLog(99,'Get_Environment_String','Args: VariableName="'||VariableName||'", RaiseExceptions='||win_api_debug.BoolToChar(RaiseExceptions));
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then
    win_api.Register_function_call(iGetDOSEnv,'d2kwutil_GetDOSEnv','LONG','*CHAR,*CHAR,LONG');
    vcBuff1    := '%'||VariableName||'%';
    vcBuff2    := RPAD(' ',512,CHR(0));
    iBuff1    := 512;
    iRC   := d2kwutil_GetDOSEnv(win_api.FunctionHandle(iGetDOSEnv),vcBuff1,vcBuff2,iBuff1);
    Win_api_debug.DebugLog(99,'Get_Environment_String','Result: Value Length='||to_char(iRC)||', Value='||vcBuff2);
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0  or vcBuff2 = vcBuff1 then 
    Win_API.Add_error('Get_Environment_String','Unable to get the value of the variable '||VariableName);
    if RaiseExceptions then
      raise NO_DATA_FOUND;
    else
      return NULL;
    end if;
  else
    return vcBuff2;
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Environment_String',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Environment_String',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Environment_String;
```

#### SP-079 - GET_TEMP_DIRECTORY

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the path of the client workstation's temporary files directory by invoking the native D2KWUTIL Win32 bridge function. The result is used to resolve the temporary directory path (e.g., the '$TEMP$' token) when presenting file dialogs. The caller may control whether a missing result raises an exception or returns NULL via the RaiseExceptions flag.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-073](#SP-073--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-074](#SP-074--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-075](#SP-075--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-076](#SP-076--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_WINDIR ([SP-011](#SP-011--D2KWUTIL.D2KWUTIL_WINDIR)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-077](#SP-077--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-082](#SP-082--REGISTER_FUNCTION_CALL)) - matched by member name
- STRIPDIRSEP ([SP-084](#SP-084--STRIPDIRSEP)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log entry diagnostics by calling DEBUGLOG (Win_API_Debug.DebugLog) at level 99, recording the procedure name and the RaiseExceptions argument value, converted to a character representation via BOOLTOCHAR.
- Step 2 - Clear any previously accumulated error state by calling CLEAN_ERROR_STACK.
- Step 3 - Initialise the return-code variable (iRC) to 0.
- Step 4 - Check whether the Win32 API bridge is enabled (WIN_API.API_ENABLED).
- Step 5 - If the bridge is enabled, register the native temporary-directory function handle by calling REGISTER_FUNCTION_CALL with the function signature 'd2kwutil_TmpDir' / 'INT' / '*CHAR,INT'.
- Step 6 - Allocate a 512-character null-padded output buffer and invoke D2KWUTIL.D2KWUTIL_WINDIR, passing the registered function handle, the buffer, and its length; capture the integer return code.
- Step 7 - Log the outcome by calling DEBUGLOG again at level 99, recording the return code and the raw buffer value returned by the native call.
- Step 8 - If the bridge is not enabled, raise the WIN_API.NOT_AVAILABLE exception.
- Step 9 - Evaluate the return code: if iRC = 0, record an error via ADD_ERROR indicating no value was returned, then either raise NO_DATA_FOUND (when RaiseExceptions is TRUE) or return NULL (when RaiseExceptions is FALSE).
- Step 10 - If iRC is non-zero (success), return the cleaned directory path by passing the buffer through STRIPDIRSEP to remove any trailing directory separator.
- Step 11 - In the exception block, re-raise NO_DATA_FOUND as-is; handle WIN_API.NOT_AVAILABLE by logging via ADD_ERROR then re-raising; handle all other exceptions by logging a combined error message via ADD_ERROR and ADD_EXTERNAL_ERRORS then re-raising.

---
**Decision Points**

DP-001

Condition:
WIN_API.API_ENABLED - the Win32 API bridge is available and initialised.

TRUE:
Register the native function handle, invoke D2KWUTIL.D2KWUTIL_WINDIR to obtain the temporary directory path, and log the result.

FALSE:
Raise the WIN_API.NOT_AVAILABLE exception, which is caught in the exception block, logged via ADD_ERROR, and re-raised to the caller.

---

DP-002

Condition:
iRC = 0 after the native D2KWUTIL.D2KWUTIL_WINDIR call (no directory path was returned).

TRUE:
Record an error via ADD_ERROR ('No Value Returned') and proceed to DP-003 to determine how to signal the failure.

FALSE:
Return the temporary directory path after stripping any trailing separator via STRIPDIRSEP.

---

DP-003

Condition:
RaiseExceptions input parameter is TRUE (evaluated only when iRC = 0).

TRUE:
Raise NO_DATA_FOUND so the caller receives an exception.

FALSE:
Return NULL silently, allowing the caller to handle the missing value without an exception.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The Win32 API bridge must be enabled before any attempt is made to retrieve the temporary directory; if the bridge is unavailable the procedure always raises WIN_API.NOT_AVAILABLE regardless of the RaiseExceptions flag.
- BR-002 - All entry and exit activity is traced via DEBUGLOG at verbosity level 99, including the RaiseExceptions argument (rendered as a character via BOOLTOCHAR) and the raw native return code and buffer value, to support diagnostic analysis.
- BR-003 - The error stack is cleared at the start of each invocation via CLEAN_ERROR_STACK, ensuring that stale errors from prior calls do not contaminate the current result.
- BR-004 - A native return code of 0 is treated as a failure condition (no directory path returned); the failure is recorded via ADD_ERROR and the response to the caller is governed exclusively by the RaiseExceptions flag.
- BR-005 - The returned directory path is always normalised through STRIPDIRSEP before being passed to the caller, ensuring a consistent path format free of trailing directory separators.
- BR-006 - All unhandled exceptions are enriched with supplementary error detail collected via ADD_EXTERNAL_ERRORS before being re-raised, preserving full diagnostic context for upstream handlers.

---
**Implementation Logic**

```plsql

FUNCTION Get_Temp_Directory (RaiseExceptions IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  iRC        PLS_INTEGER;
begin 
  Win_API_Debug.DebugLog(99,'Get_Temp_Directory','Args: RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	 	
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then 
    win_api.Register_function_call(iTmpDir,'d2kwutil_TmpDir','INT','*CHAR,INT');
    vcBuff1    := RPAD(' ',512,CHR(0));
    iRC   := d2kwutil_WinDir(win_api.FunctionHandle(iTmpDir),vcBuff1,512);
    Win_API_Debug.DebugLog(99,'Get_Temp_Directory','Result:  RC='||to_char(iRC)||', vcBuff1="'||vcBuff1||'"');	      
  else
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0 then 
    Win_API.Add_error('Get_Temp_Directory','No Value Returned');
    if RaiseExceptions then
      raise NO_DATA_FOUND;
    else
      return NULL;
    end if;
  else
    return WIN_API.StripDirSep(vcBuff1);
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Temp_Directory',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Temp_Directory',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Temp_Directory;
```

#### SP-080 - GET_WINDOWS_DIRECTORY

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the Windows directory path on the client workstation by invoking the native D2KWUTIL_WINDIR function through the Win32 API bridge. Returns the path as a VARCHAR2 string (with any trailing directory separator stripped) for use by callers such as CHOOSEFILE when resolving the '$WINDIR$' directory token. Accepts a RaiseExceptions flag that controls whether a missing result causes an exception or a silent NULL return.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-073](#SP-073--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-074](#SP-074--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-075](#SP-075--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-076](#SP-076--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_WINDIR ([SP-011](#SP-011--D2KWUTIL.D2KWUTIL_WINDIR)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-077](#SP-077--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-082](#SP-082--REGISTER_FUNCTION_CALL)) - matched by member name
- STRIPDIRSEP ([SP-084](#SP-084--STRIPDIRSEP)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log entry diagnostics by calling DEBUGLOG (via Win_API_Debug.DebugLog) at level 99, recording the procedure name and the value of RaiseExceptions converted to a character string via BOOLTOCHAR.
- Step 2 - Clear any pre-existing error state by calling CLEAN_ERROR_STACK.
- Step 3 - Check whether the Win32 API bridge is enabled (WIN_API.API_ENABLED). If not enabled, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 4 - Register the native function binding by calling REGISTER_FUNCTION_CALL, mapping the internal handle iWinDir to the 'd2kwutil_WinDir' entry point with signature 'INT' / '*CHAR,INT', which resolves to D2KWUTIL.D2KWUTIL_WINDIR.
- Step 5 - Initialise a 512-character NUL-padded output buffer (vcBuff1) and invoke D2KWUTIL.D2KWUTIL_WINDIR, passing the registered function handle, the buffer, and its length (512). Capture the integer return code in iRC.
- Step 6 - Log the raw result (iRC and vcBuff1) via DEBUGLOG at level 99 for diagnostic traceability.
- Step 7 - Evaluate iRC. If iRC = 0 the native call returned no data: call ADD_ERROR to record the failure, then either raise NO_DATA_FOUND (when RaiseExceptions is TRUE) or return NULL (when RaiseExceptions is FALSE).
- Step 8 - If iRC is non-zero, return the Windows directory path after passing vcBuff1 through STRIPDIRSEP to remove any trailing directory separator.
- Step 9 - In the exception block: re-raise NO_DATA_FOUND as-is; on WIN_API.NOT_AVAILABLE log via ADD_ERROR using the NoAPI message and re-raise; on any other exception log via ADD_ERROR concatenating the generic error text with ADD_EXTERNAL_ERRORS output and re-raise.

---
**Decision Points**

DP-001

Condition:
WIN_API.API_ENABLED is TRUE

TRUE:
Proceed to register the D2KWUTIL_WINDIR function handle and invoke the native call to retrieve the Windows directory path.

FALSE:
Raise WIN_API.NOT_AVAILABLE, which is caught in the exception block, logged via ADD_ERROR, and re-raised to the caller.

---

DP-002

Condition:
The native D2KWUTIL_WINDIR call returns iRC = 0 (no value returned)

TRUE:
Record the failure via ADD_ERROR. If RaiseExceptions is TRUE, raise NO_DATA_FOUND; otherwise return NULL to the caller.

FALSE:
The call succeeded; return the Windows directory path after stripping the trailing directory separator via STRIPDIRSEP.

---

DP-003

Condition:
RaiseExceptions input parameter is TRUE (evaluated only when iRC = 0)

TRUE:
Raise NO_DATA_FOUND after logging the error, propagating the failure to the caller.

FALSE:
Return NULL silently, allowing the caller to handle the missing path without an exception.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The Win32 API bridge must be active (WIN_API.API_ENABLED) before any attempt is made to retrieve the Windows directory; if the bridge is unavailable the function always raises WIN_API.NOT_AVAILABLE regardless of the RaiseExceptions flag.
- BR-002 - A return code of zero from D2KWUTIL_WINDIR is treated as a data-absent condition, not a successful call; the function never returns an empty or zero-result path as a valid directory.
- BR-003 - The caller controls error-propagation behaviour through the RaiseExceptions parameter: TRUE causes NO_DATA_FOUND to be raised on a zero return code; FALSE causes a NULL return, enabling non-fatal usage patterns.
- BR-004 - The returned directory path is always normalised by STRIPDIRSEP before being handed back to the caller, ensuring a consistent path format without a trailing separator.
- BR-005 - All entry, result, and exception events are written to the diagnostic log via DEBUGLOG (level 99), providing a full audit trail of each invocation without affecting functional behaviour.

---
**Implementation Logic**

```plsql

FUNCTION Get_Windows_Directory (RaiseExceptions IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  iRC        PLS_INTEGER;
begin 
  Win_API_Debug.DebugLog(99,'Get_Windows_Directory','Args: RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	 	
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then 
    win_api.Register_function_call(iWinDir,'d2kwutil_WinDir','INT','*CHAR,INT');

    vcBuff1    := RPAD(' ',512,CHR(0));
    iRC   := d2kwutil_WinDir(win_api.FunctionHandle(iWinDir),vcBuff1,512);
    Win_API_Debug.DebugLog(99,'Get_Windows_Directory','Result:  RC='||to_char(iRC)||', vcBuff1="'||vcBuff1||'"');	      
  else
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0 then 
    Win_API.Add_error('Get_Windows_Directory','No Value Returned');
    if RaiseExceptions then
      raise NO_DATA_FOUND;
    else
      return NULL;
    end if;
  else
    return WIN_API.StripDirSep(vcBuff1);
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Windows_Directory',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Windows_Directory',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Windows_Directory;
```

#### SP-081 - READ_REGISTRY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Reads a value from the Windows registry on the client workstation by delegating to the D2KWUTIL native bridge function D2KWUTIL.D2KWUTIL_GETREGKEY. Accepts a registry path (hive plus key) and a value name, resolves the hive to a numeric constant, and returns the registry value as a VARCHAR2 string. Diagnostic entries are written via DEBUGLOG throughout execution, and all error conditions are recorded via ADD_ERROR before either returning NULL or raising a PL/SQL exception depending on the RaiseExceptions flag.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RegPath | VARCHAR2 | IN |
| RegEntry | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-073](#SP-073--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-074](#SP-074--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-075](#SP-075--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-076](#SP-076--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_GETREGKEY ([SP-010](#SP-010--D2KWUTIL.D2KWUTIL_GETREGKEY)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-077](#SP-077--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-082](#SP-082--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Write a diagnostic entry via DEBUGLOG recording the input arguments (RegPath, RegEntry, and the Boolean RaiseExceptions flag converted to a character representation using BOOLTOCHAR).
- Step 2 - Clear any previously accumulated error state by calling CLEAN_ERROR_STACK.
- Step 3 - Check whether the Win32 API bridge is enabled (WIN_API.API_ENABLED). If not enabled, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 4 - Register the native registry-read function handle by calling REGISTER_FUNCTION_CALL, binding it to the D2KWUTIL.D2KWUTIL_GETREGKEY entry point with its expected parameter signature.
- Step 5 - Parse the leading segment of RegPath (up to the first backslash) to determine the registry hive, and map it to the corresponding numeric constant (0 = HKEY_LOCAL_MACHINE, 1 = HKEY_CLASSES_ROOT, 2 = HKEY_CURRENT_USER, 3 = HKEY_USERS, 4 = HKEY_CURRENT_CONFIG). If the hive string is unrecognised, record an error via ADD_ERROR and, if RaiseExceptions is TRUE, raise NO_DATA_FOUND.
- Step 6 - Evaluate the WIN_API.COMPAT_EXPAND_REG_VALUES compatibility flag. If expansion is suppressed, set the suppression parameter to 1 and write a diagnostic entry via DEBUGLOG; otherwise set it to 0.
- Step 7 - Invoke D2KWUTIL.D2KWUTIL_GETREGKEY with the resolved hive constant, the sub-key path (RegPath after the first backslash), the value name, a pre-allocated 2000-byte output buffer, and the expansion flag. Capture the integer return code.
- Step 8 - Write a diagnostic entry via DEBUGLOG recording the return code and the retrieved buffer value.
- Step 9 - Evaluate the return code. A return code of -1 (entry not found), -2 (unsupported data type), -3 (value exceeds buffer length), or -4 (environment-string expansion failure) each cause ADD_ERROR to be called with a descriptive message. Depending on RaiseExceptions, the function either returns NULL or raises the appropriate PL/SQL exception (NO_DATA_FOUND for -1, -2, -4; VALUE_ERROR for -3).
- Step 10 - If the return code indicates success, return the populated output buffer (vcBuff3) to the caller.
- Step 11 - In the exception block, re-raise NO_DATA_FOUND and VALUE_ERROR without additional handling; for WIN_API.NOT_AVAILABLE, record the error via ADD_ERROR before re-raising; for all other exceptions, record the error via ADD_ERROR (appending any external error details from ADD_EXTERNAL_ERRORS) before re-raising.

---
**Decision Points**

DP-001

Condition:
WIN_API.API_ENABLED is TRUE

TRUE:
Proceed to register the function handle and execute the registry read.

FALSE:
Raise WIN_API.NOT_AVAILABLE immediately, bypassing all registry operations.

---

DP-002

Condition:
The hive segment parsed from RegPath matches one of the five recognised hive constants (HKEY_LOCAL_MACHINE, HKEY_CLASSES_ROOT, HKEY_CURRENT_USER, HKEY_USERS, HKEY_CURRENT_CONFIG)

TRUE:
Assign the corresponding numeric constant (0-4) and continue.

FALSE:
Call ADD_ERROR with an invalid-key message; if RaiseExceptions is TRUE, raise NO_DATA_FOUND, otherwise continue (subsequent call will likely fail).

---

DP-003

Condition:
WIN_API.COMPAT_EXPAND_REG_VALUES is TRUE

TRUE:
Set the expansion flag to 0, allowing environment-string expansion in the retrieved value.

FALSE:
Set the expansion flag to 1 to suppress expansion, and write a diagnostic entry via DEBUGLOG noting the compatibility override.

---

DP-004

Condition:
Return code from D2KWUTIL.D2KWUTIL_GETREGKEY equals -1 (registry entry not found)

TRUE:
Call ADD_ERROR; if RaiseExceptions is FALSE return NULL, otherwise raise NO_DATA_FOUND.

FALSE:
Evaluate subsequent return-code conditions (DP-005 through DP-007).

---

DP-005

Condition:
Return code equals -2 (unsupported registry data type)

TRUE:
Call ADD_ERROR; if RaiseExceptions is FALSE return NULL, otherwise raise NO_DATA_FOUND.

FALSE:
Evaluate DP-006.

---

DP-006

Condition:
Return code equals -3 (value length exceeds the 2000-byte buffer)

TRUE:
Call ADD_ERROR; if RaiseExceptions is FALSE return NULL, otherwise raise VALUE_ERROR.

FALSE:
Evaluate DP-007.

---

DP-007

Condition:
Return code equals -4 (environment-string expansion failure)

TRUE:
Call ADD_ERROR; if RaiseExceptions is FALSE return NULL, otherwise raise NO_DATA_FOUND.

FALSE:
No error condition applies; return the populated buffer to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function may only execute when the Win32 API bridge is active (WIN_API.API_ENABLED). If the bridge is unavailable, the WIN_API.NOT_AVAILABLE exception is raised unconditionally regardless of the RaiseExceptions flag.
- BR-002 - The registry hive must be supplied as the leading segment of RegPath, separated from the sub-key by a backslash. Only the five standard hives (HKEY_LOCAL_MACHINE, HKEY_CLASSES_ROOT, HKEY_CURRENT_USER, HKEY_USERS, HKEY_CURRENT_CONFIG) are recognised; any other value is treated as an error.
- BR-003 - The caller controls error-propagation behaviour through the RaiseExceptions parameter (default FALSE). When FALSE, all recoverable read failures (return codes -1, -2, -3, -4) result in a NULL return value; when TRUE, the corresponding PL/SQL exception is raised.
- BR-004 - The output buffer is fixed at 2000 bytes. Registry values longer than this limit produce return code -3 and are treated as an error per BR-003.
- BR-005 - Environment-string expansion within registry values is governed by the WIN_API.COMPAT_EXPAND_REG_VALUES flag. When this flag is FALSE, expansion is suppressed and the raw unexpanded string is returned; this behaviour is logged via DEBUGLOG for diagnostic traceability.
- BR-006 - All error conditions, including invalid hive, read failures, and unexpected exceptions, must be recorded via ADD_ERROR before the function returns or re-raises. Unexpected exceptions additionally append external error details obtained from ADD_EXTERNAL_ERRORS.
- BR-007 - DEBUGLOG entries are written at verbosity level 99 at procedure entry (including BOOLTOCHAR-formatted RaiseExceptions value) and after the native call (return code and retrieved value), providing a full audit trail of each invocation without affecting functional behaviour.

---
**Implementation Logic**

```plsql

FUNCTION Read_Registry (RegPath         IN  VARCHAR2,
                        RegEntry        IN  VARCHAR2, 
                        RaiseExceptions IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  vcBuff2    VARCHAR2(512);
  vcBuff3    VARCHAR2(2000);
  vcBuff4    VARCHAR2(512);
  vcBuff5    VARCHAR2(512);                        
  vcRoot     VARCHAR2(20);
  iBuff1     PLS_INTEGER;
  iBuff2     PLS_INTEGER;
  iBuff3		 PLS_INTEGER;
  iRC        PLS_INTEGER;
begin
  Win_API_Debug.DebugLog(99,'Read_Registry','Args: RegPath="'||RegPath||'", RegEntry="'||RegEntry||'", RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	  
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then 
    win_api.Register_function_call(iGetRegKey,'d2kwutil_GetRegKey','INT','INT,*CHAR,*CHAR,*CHAR,INT,INT');  
    -- Which Root?
    vcRoot  := upper(substr(RegPath,1,instr(RegPath,'\')-1));
    if      vcRoot =  'HKEY_LOCAL_MACHINE' then 
      iBuff1 := 0;
    elsif   vcRoot =  'HKEY_CLASSES_ROOT' then 
      iBuff1 := 1;
    elsif   vcRoot =  'HKEY_CURRENT_USER' then 
      iBuff1 := 2;
    elsif   vcRoot =  'HKEY_USERS' then
      iBuff1 := 3;
    elsif   vcRoot =  'HKEY_CURRENT_CONFIG' then
      iBuff1 := 4;      
    else
      WIN_API.Add_error('Read_Registry','Invalid Registry Key '||RegPath);
      if  RaiseExceptions then
        raise NO_DATA_FOUND;
      end if;  
    end if;

    iBuff2     := 2000; /* Length of buffer */
    vcBuff1    := substr(RegPath,instr(RegPath,'\')+1);
    vcBuff2    := RegEntry;
    vcBuff3    := RPAD(SUBSTR(NVL(vcBuff3,' '),1,2000),2000,CHR(0));
    if not WIN_API.COMPAT_EXPAND_REG_VALUES then 
    	iBuff3 := 1;
    	Win_API_Debug.DebugLog(99,'Read_Registry','Compatibility: Reg Value expansion supressed');	  
    else
    	iBuff3 := 0;
    end if;
    
    iRC        := d2kwutil_GetRegKey(win_api.FunctionHandle(iGetRegKey),iBuff1,vcBuff1,vcBuff2,vcBuff3,iBuff2,iBuff3);
    Win_API_Debug.DebugLog(99,'Read_Registry','Result:  RC='||to_char(iRC)||', vcBuff3="'||vcBuff3||'"');	      
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = -1  then 
    Win_API.Add_error('Read_Registry','Cannot read  entry '||RegPath||'->'||RegEntry);
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;
  elsif iRC = -2 then
    Win_API.Add_error('Read_Registry', RegPath||'->'||RegEntry||' is an unsupported datatype');
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;
  elsif iRC = -3 then
    Win_API.Add_error('Read_Registry',RegPath||'->'||RegEntry||' is longer than '||to_char(iBuff2)||' Bytes');
    if not RaiseExceptions then
      return NULL;
    else 
      raise VALUE_ERROR;
    end if;
  elsif iRC = -4 then
    Win_API.Add_error('Read_Registry', RegPath||'->'||RegEntry||' Failed to expand environment string');
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;    
  end if;
  return vcBuff3;
exception
  when NO_DATA_FOUND then 
    raise;
  when VALUE_ERROR then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Read_Registry',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Read_Registry',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Read_Registry;
```

#### SP-082 - REGISTER_FUNCTION_CALL

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.FILE_INFO]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a native DLL function with the Oracle FFI (Foreign Function Interface) bridge by resolving the DLL handle, translating the return type and each parameter type, and recording the registration against a load-count cache. Returns a reusable function handle stored in FunctionHandle(FunctionID). Prevents redundant re-registration unless the DLL has been reloaded since the last registration. Raises NO_DATA_FOUND and disables the API if the DLL cannot be located or loaded.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| FunctionID | PLS_INTEGER | IN |
| FunctionName | VARCHAR2 | IN |
| FunctionReturn | VARCHAR2 | IN |
| FunctionArgs | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-073](#SP-073--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-074](#SP-074--ADD_EXTERNAL_ERRORS)) - matched by member name
- D2KWUTIL.ATTEMPT_DLL_LOAD ([SP-003](#SP-003--D2KWUTIL.ATTEMPT_DLL_LOAD)) - D2KWUTIL.pck (or .pld)
- D2KWUTIL.TRANSLATETYPE ([SP-015](#SP-015--D2KWUTIL.TRANSLATETYPE)) - D2KWUTIL.pck (or .pld)
- DEBUGLOG ([SP-077](#SP-077--DEBUGLOG)) - matched by member name
- WEBUTIL.LENGTH ([SP-056](#SP-056--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)
- WEBUTIL.REGISTER_FUNCTION ([SP-064](#SP-064--WEBUTIL.REGISTER_FUNCTION)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Attempt to locate the already-loaded DLL by calling ORA_FFI.FIND_LIBRARY using the module-level DLL_NAME constant; if successful, store the result in DLL_HANDLE.
- Step 2 - If ORA_FFI.FIND_LIBRARY raises an FFI error (DLL not currently loaded), call D2KWUTIL.ATTEMPT_DLL_LOAD with DLL_Path and DLL_NAME to force a load and obtain DLL_HANDLE.
- Step 3 - If ATTEMPT_DLL_LOAD also raises an FFI error, set API_ENABLED to FALSE, call ADD_ERROR to record a 'not found' message for the DLL, and raise NO_DATA_FOUND to abort processing.
- Step 4 - Check the FunctionLoad cache: if no entry exists for FunctionID, or if the cached load-count for FunctionID does not match the current DLL_LOAD_COUNT, proceed with (re-)registration; otherwise skip to the end.
- Step 5 - Register the function name and calling convention with the DLL handle via ORA_FFI.REGISTER_FUNCTION, storing the resulting handle in FunctionHandle(FunctionID).
- Step 6 - If the function being registered is not the internal debug string function ('d2kwutil_DebugString'), call DEBUGLOG (level 99) to record either an initial registration or a re-registration event, including the DLL load count and, where applicable, the prior load-count value.
- Step 7 - Append a trailing comma to FunctionArgs and iterate through the comma-delimited argument type tokens; for each token, call D2KWUTIL.TRANSLATETYPE to convert the type string to an ORA_FFI type constant and register it via ORA_FFI.REGISTER_PARAMETER. Use WEBUTIL.LENGTH (via the instr/substr/length logic) to detect the end of the argument list; stop when the remaining string is null, a bare comma, or 'VOID,'.
- Step 8 - If FunctionReturn is not 'VOID' and is not NULL, call D2KWUTIL.TRANSLATETYPE on the return type string and register the return type via ORA_FFI.REGISTER_RETURN.
- Step 9 - Record the current DLL_LOAD_COUNT in FunctionLoad(FunctionID) to mark this registration as current and suppress unnecessary future re-registrations.
- Step 10 - In the outer exception handler, if an ORA_FFI.FFI_ERROR is raised during any step after the DLL load block, call ADD_ERROR with the function name and a combined error message built from UError and ADD_EXTERNAL_ERRORS, then raise NO_DATA_FOUND.

---
**Decision Points**

DP-001

Condition:
ORA_FFI.FIND_LIBRARY raises an FFI error (DLL is not currently loaded in memory)

TRUE:
Call D2KWUTIL.ATTEMPT_DLL_LOAD to load the DLL and obtain a fresh DLL_HANDLE.

FALSE:
Use the handle returned by FIND_LIBRARY and continue to the registration check.

---

DP-002

Condition:
D2KWUTIL.ATTEMPT_DLL_LOAD also raises an FFI error (DLL cannot be loaded)

TRUE:
Set API_ENABLED to FALSE, call ADD_ERROR to log the missing DLL, and raise NO_DATA_FOUND to halt execution.

FALSE:
Store the loaded DLL handle and proceed to the registration check.

---

DP-003

Condition:
No entry exists in FunctionLoad for FunctionID, OR the cached load-count for FunctionID does not equal the current DLL_LOAD_COUNT

TRUE:
Perform full (re-)registration: register the function, log via DEBUGLOG, register each parameter type via D2KWUTIL.TRANSLATETYPE, register the return type if applicable, and update FunctionLoad(FunctionID).

FALSE:
Skip registration entirely; the existing FunctionHandle(FunctionID) is still valid.

---

DP-004

Condition:
The function name being registered equals 'd2kwutil_DebugString'

TRUE:
Suppress the DEBUGLOG call to avoid recursive or circular debug logging.

FALSE:
Call DEBUGLOG at level 99 to record the registration event (initial or re-registration) with the function name and DLL load count.

---

DP-005

Condition:
The remaining FunctionArgs token string is null, equals ',', or equals 'VOID,'

TRUE:
Exit the parameter-registration loop; no further parameters to register.

FALSE:
Extract the next comma-delimited type token, call D2KWUTIL.TRANSLATETYPE, register the parameter, and advance the string pointer.

---

DP-006

Condition:
FunctionReturn is not 'VOID' and is not NULL

TRUE:
Call D2KWUTIL.TRANSLATETYPE on the return type string and register the return type via ORA_FFI.REGISTER_RETURN.

FALSE:
Skip return-type registration (procedure has no return value or an explicit VOID return).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A function registration is tied to a specific DLL load instance; if the DLL has been reloaded (DLL_LOAD_COUNT has changed), the function must be re-registered even if a prior handle exists, because stale handles from a previous load are invalid.
- BR-002 - The DLL must be locatable or loadable before any function registration is attempted; failure to load the DLL permanently disables the API (API_ENABLED = FALSE) for the session and surfaces an error via ADD_ERROR.
- BR-003 - All parameter type strings and the return type string must be translated through D2KWUTIL.TRANSLATETYPE before being passed to the ORA_FFI layer; raw VARCHAR2 type names are not passed directly.
- BR-004 - A function whose return type is 'VOID' or NULL has no return type registered with the FFI bridge; only non-void functions receive a return-type registration.
- BR-005 - The internal debug function 'd2kwutil_DebugString' is exempt from DEBUGLOG tracing during its own registration to prevent recursive logging.
- BR-006 - Any ORA_FFI error occurring after the DLL load phase is surfaced to the caller via ADD_ERROR (incorporating ADD_EXTERNAL_ERRORS for supplemental detail) and results in NO_DATA_FOUND being raised, ensuring the caller can detect and handle FFI failures cleanly.
- BR-007 - This procedure contains no form-specific business logic; it is a low-level Win32/FFI infrastructure utility shared across all D2KWUTIL callers.

---
**Implementation Logic**

```plsql

PROCEDURE Register_Function_Call ( FunctionID     in PLS_INTEGER, 
                                   FunctionName   in VARCHAR2,
                                   FunctionReturn in VARCHAR2, 
                                   FunctionArgs   in VARCHAR2) is
  vcArgs  VARCHAR2(200);
  vcFrag  VARCHAR2(10);
  iOffset PLS_INTEGER;   
begin 
   -- See if the DLL has been loaded at all.
   -- if this call to FIND_LIBRARY fails, we'll fall through to the Exception.
   begin
    DLL_HANDLE := ORA_FFI.find_library(DLL_NAME);
  exception
    when ora_ffi.ffi_error then 
      -- Attempt to load the DLL again in a subblock. If this fails
      -- then the API must be disabled and NOT_DATA_FOUND raised
      begin 
          DLL_HANDLE := Attempt_DLL_Load(DLL_Path, DLL_NAME);
      exception
          when ora_ffi.ffi_error then 
            API_ENABLED := FALSE;
              add_error('D2KWUTIL',DLL_NAME||' not found.');
            RAISE NO_DATA_FOUND;
      end;
  end;

  -- now compare the Cached value for this function's loadcount with 
  -- that for the DLL this tells us that the function has either not 
  -- been registered yet, or that the DLL has been reloaded in between 
  -- times.  This would not be healthy so we have to re-register in that case.
  if (not FunctionLoad.exists(FunctionId)) or (FunctionLoad(FunctionId)<> DLL_LOAD_COUNT) then
    -- We need to go through the registration process.      
    -- Register the function with the DLL
    FunctionHandle(FunctionId) := ora_ffi.register_function(Win_API.DLL_HANDLE,FunctionName,ORA_FFI.C_STD);
    if FunctionName <> 'd2kwutil_DebugString' then 
    	if not FunctionLoad.exists(FunctionId) then 
    		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Initial Reg');
    	else
       		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Re-Registration Count = '||to_char(FunctionLoad(FunctionId)));
       	end if;
    end if;
    
    -- Loop through and register the parameters
    vcArgs := FunctionArgs||',';
    while vcArgs is not null and vcArgs <> ',' and vcArgs <> 'VOID,' LOOP
      iOffset := instr(vcArgs,',');
      vcFrag := substr(vcArgs,1,iOffset-1);
      ora_ffi.register_parameter(FunctionHandle(FunctionId),TranslateType(vcFrag));
      if iOffset = length(vcArgs) then
        vcArgs := NULL;
      else
        vcArgs := substr(vcArgs,iOffset+1);
      end if;
    end LOOP;
    
    -- Register the return type IF this is a function
    if upper(FunctionReturn) <> 'VOID' and FunctionReturn is not NULL then 
      ora_ffi.register_return(FunctionHandle(FunctionId),TranslateType(FunctionReturn));
    end if;
    
    -- Now add this Function's Loadcount to the array to prevent un-nessary re-registration
    FunctionLoad(FunctionId) := DLL_LOAD_COUNT;
  end if;
exception
   when ora_ffi.ffi_error then
    Win_API.Add_error(FunctionName, Win_API.UError||WIN_API.Add_External_errors); 
    raise NO_DATA_FOUND;
end Register_Function_Call;
```

#### SP-083 - SETDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Configures the debug logging environment for the application session by accepting the desired logging type, target file, verbosity level, and timestamp preference. The procedure stores these settings in package-level variables and activates or deactivates the logging state accordingly, delegating an initial log entry to DEBUGLOG to confirm the new state.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugType | PLS_INTEGER | IN |
| DebugFile | VARCHAR2 | IN |
| DebugLevel | PLS_INTEGER | IN |
| TimeStamp | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-077](#SP-077--DEBUGLOG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Persist the incoming TimeStamp flag to the package-level variable bDebugTimeStamp, controlling whether subsequent log entries include a timestamp.
- Step 2 - Persist the incoming DebugFile value to the package-level variable vcDebugFile, identifying the target log file for file-based logging.
- Step 3 - Persist the incoming DebugLevel value to the package-level variable iDebugLevel, setting the verbosity threshold for subsequent log entries.
- Step 4 - Evaluate the DebugType parameter to determine which logging mode to activate (see Decision Points).
- Step 5 - Set the package-level variable iDebugState to the resolved mode value (1, 2, or 0).
- Step 6 - Invoke DEBUGLOG with severity 0 and the caller identifier 'SetDebug' to write a confirmation message reflecting the newly activated or deactivated logging state.

---
**Decision Points**

DP-001

Condition: DebugType = 1

TRUE: Set iDebugState to 1 (file-based logging mode) and invoke DEBUGLOG with the message 'Logging to File ' concatenated with the DebugFile value.

FALSE: Evaluate DP-002.

DP-002

Condition: DebugType = 2

TRUE: Set iDebugState to 2 (alternative logging mode, e.g. screen/message output) and invoke DEBUGLOG with the message 'Logging Started'.

FALSE: Invoke DEBUGLOG with the message 'Logging Stopped' and set iDebugState to 0, disabling all debug logging.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - DebugType = 1 activates file-based debug logging; the DebugFile parameter must carry a meaningful file path value when this mode is selected, as it is written directly to the log confirmation message.
- BR-002 - DebugType = 2 activates an alternative (non-file) logging mode; no file path is referenced in the confirmation message for this mode.
- BR-003 - Any DebugType value other than 1 or 2 is treated as a request to stop logging; iDebugState is set to 0 and a 'Logging Stopped' entry is written via DEBUGLOG before deactivation.
- BR-004 - DebugFile defaults to NULL, DebugLevel defaults to 98, and TimeStamp defaults to FALSE, allowing callers to invoke the procedure with only DebugType when non-file logging or stop-logging behaviour is required.
- BR-005 - All three session-scoped settings (bDebugTimeStamp, vcDebugFile, iDebugLevel) are unconditionally overwritten on every invocation, regardless of the DebugType value, ensuring the package state is always consistent with the most recent call to SETDEBUG.

---
**Implementation Logic**

```plsql

PROCEDURE SetDebug( DebugType   IN PLS_INTEGER, 
                    DebugFile   IN VARCHAR2 DEFAULT NULL, 
                    DebugLevel  IN PLS_INTEGER DEFAULT 98,                        
                    TimeStamp   IN BOOLEAN DEFAULT FALSE) is
begin 
    bDebugTimeStamp := TimeStamp;
    vcDebugFile     := DebugFile;
    iDebugLevel     := DebugLevel;
	if DebugType = 1 then 
		iDebugState := 1;
		DebugLog(0,'SetDebug','Logging to File '||DebugFile);
	elsif DebugType = 2 then
		iDebugState := 2;
		DebugLog(0,'SetDebug','Logging Started');
	else 
        DebugLog(0,'SetDebug','Logging Stopped');
        iDebugState := 0;
	end if;
end SetDebug;
```

#### SP-084 - STRIPDIRSEP

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Removes a trailing directory separator character (backslash or forward slash) from a file path string if one is present. Ensures consistent path formatting before the path is used in further operations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| InPath | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-056](#SP-056--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the file path string.
- Step 2 - Check whether the last character is a backslash or forward slash.
- Step 3 - If a trailing separator is present, remove it and return the trimmed path; otherwise return the path unchanged.

---
**Decision Points**

DP-001

Condition:
The last character of the path is a backslash or forward slash

TRUE:
Return the path with the trailing separator removed.

FALSE:
Return the path unchanged.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - No form-specific business rules - file path normalisation utility.

---
**Implementation Logic**

```plsql

  

Function StripDirSep ( InPath in varchar2) return varchar2 is 
  vcPath  varchar2(500) := InPath;
begin 
  -- Check and Strip SemiColons, we take everything
  -- Before the first Semicolon as our path
  if instr(vcPath,';') > 0 then
    vcPath := substr(vcPath,1,instr(vcPath,';') -1);
  end if;

  -- Check and Strip '\'
  if substr(vcPath,-1,1) = '\' then 
    vcPath := substr(vcPath,1,length(vcPath)-1);
  end if;

  return vcPath;
end StripDirSep;
```

#### SP-085 - VIEW_EXCEL_REPORT_NEW

**Invoked From:**

- vi_ro_hold_up_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

Search Criteria (N/A / CN_MAIN)

---

**Purpose**

Generates a CSV export of hold-up report data for the selected view type and delivers it to the user's workstation. Depending on whether a report server is configured for the current organisation and application, the procedure either delegates CSV generation to a stored procedure on a linked database (dms1_db3_lnk) or builds the file directly from a record group query within the form. In both paths the output file is transferred to the client workstation and opened immediately using the operating system's default application.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_principal | number | IN |
| p_file_name | VARCHAR2 | IN |
| p_query | VARCHAR2 | IN |
| p_column_name | VARCHAR2 | IN |
| p_app_id | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.FCLOSE ([SP-031](#SP-031--WEBUTIL.FCLOSE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.FILE_SAVE_DIALOG ([SP-032](#SP-032--WEBUTIL.FILE_SAVE_DIALOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.FOPEN ([SP-034](#SP-034--WEBUTIL.FOPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_LINE ([SP-047](#SP-047--WEBUTIL.GET_LINE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.HOST ([SP-050](#SP-050--WEBUTIL.HOST)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ID_NULL ([SP-051](#SP-051--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.PUTF ([SP-059](#SP-059--WEBUTIL.PUTF)) - WEBUTIL.pck (or .pld)
- WEBUTIL.URL_TO_CLIENT ([SP-070](#SP-070--WEBUTIL.URL_TO_CLIENT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Query EH_REPORTS for a report server entry matching the supplied principal (p_principal) and application identifier (p_app_id). Store the result in lv_rep_server; if no row is found, set lv_rep_server to null.
- Step 2 - Determine the output filename: if p_file_name is null, invoke WEBUTIL.FILE_SAVE_DIALOG to prompt the user for a save location; otherwise use the supplied p_file_name value. Append a '.csv' extension to produce the final FILENAME.
- Step 3 - Check whether FILENAME contains any spaces. If it does, redirect the path to the C drive root (retaining only the bare filename) and display a message informing the user that the file will be stored in the C drive as default.
- Step 4 (report-server path) - If lv_rep_server is not null: call sp_csv_report_generate via the linked database (dms1_db3_lnk), passing FILENAME and p_query, to generate the CSV file in the utility directory. Move the generated file from /utl_dir/ to /iashome/ias/reports/printer/ using WEBUTIL.HOST. Read the base URL from /reports/DMS/excelpath.txt using WEBUTIL.FOPEN and WEBUTIL.GET_LINE, then WEBUTIL.FCLOSE the config file. Construct the full download URL and transfer the file to the client workstation using WEBUTIL.URL_TO_CLIENT.
- Step 5 (no report-server path) - If lv_rep_server is null: delete any existing record group named 'DataRecordSet' (checking with WEBUTIL.ID_NULL), create a new record group from p_query, and populate it. Determine the server-side file path under /iashome/ias/reports/printer/. Read the base URL from /reports/DMS/excelpath.txt using WEBUTIL.FOPEN, WEBUTIL.GET_LINE, and WEBUTIL.FCLOSE. Open a new server-side file for writing using WEBUTIL.FOPEN. Locate the target column in the record group using p_column_name, then loop through all rows, writing each cell value as a line with WEBUTIL.PUTF. Close the file with WEBUTIL.FCLOSE. Construct the download URL and transfer the file to the client workstation using WEBUTIL.URL_TO_CLIENT.
- Step 6 - If the file transfer to the client fails (URL_TO_CLIENT returns FALSE), display a 'File Transfer failed' message and pause.
- Step 7 - Open the transferred file on the client workstation by invoking WEBUTIL.HOST with a 'cmd /c' command, causing the operating system to open the file with its default application.
- Step 8 - If any unhandled exception occurs at any point, display the error code and error text to the user and raise Form_Trigger_Failure to halt execution.

---
**Decision Points**

DP-001

Condition:
A report server entry exists in EH_REPORTS for the supplied principal and application identifier (lv_rep_server is not null)

TRUE:
Delegate CSV generation to sp_csv_report_generate on the linked database (dms1_db3_lnk), move the file to the reports printer directory, read the base URL, and transfer the file to the client.

FALSE:
Build the CSV file directly within the form using a record group created from p_query, write it to the server, read the base URL, and transfer the file to the client.

---

DP-002

Condition:
The input parameter p_file_name is null

TRUE:
Invoke WEBUTIL.FILE_SAVE_DIALOG to prompt the user to select an output file location.

FALSE:
Use the supplied p_file_name value as the basis for the output filename.

---

DP-003

Condition:
The constructed FILENAME contains one or more spaces

TRUE:
Override the file path to save the file directly in the C drive root (retaining only the bare filename) and notify the user that the default C drive location is being used.

FALSE:
Continue using the original FILENAME path as constructed.

---

DP-004

Condition:
An existing record group named 'DataRecordSet' is found (ID_NULL check returns FALSE) - applicable only in the no-report-server path

TRUE:
Delete the existing record group before creating a new one from p_query.

FALSE:
Proceed directly to creating the new record group from p_query.

---

DP-005

Condition:
The file transfer to the client workstation succeeds (WEBUTIL.URL_TO_CLIENT returns TRUE)

TRUE:
Open the file on the client workstation using WEBUTIL.HOST ('cmd /c').

FALSE:
Display a 'File Transfer failed' message to the user and pause.

---
**Database Interactions**

- DB-001 - Read EH_REPORTS - Reads data from EH_REPORTS for lookup or validation.
**Business Rules**

- BR-001 - The report server configuration is determined at runtime by querying EH_REPORTS for the matching principal and application identifier; if no row is found the procedure falls back to in-form CSV generation.
- BR-002 - A '.csv' extension is always appended to the resolved filename regardless of whether a report server is configured or a filename was supplied by the caller.
- BR-003 - If the output file path contains spaces in any folder name, the file is automatically redirected to the C drive root to avoid path resolution issues, and the user is notified.
- BR-004 - The base URL used to construct the download path is read at runtime from the configuration file /reports/DMS/excelpath.txt on the application server and is never hard-coded.
- BR-005 - In the no-report-server path, any pre-existing record group named 'DataRecordSet' must be deleted before a new one is created to ensure the query and column data are current.
- BR-006 - CSV rows are written one cell value per line, with each value taken from the column identified by p_column_name in the record group.
- BR-007 - After a successful file transfer, the file is opened immediately on the client workstation using the operating system's default file handler via a 'cmd /c' host command.
- BR-008 - A failed file transfer is surfaced to the user with a 'File Transfer failed' message; execution is paused to allow the user to acknowledge the failure.
- BR-009 - Any unhandled exception causes the error code and error text to be displayed to the user, after which Form_Trigger_Failure is raised to halt further processing.

---
**Implementation Logic**

```plsql
PROCEDURE view_excel_report_new(p_principal number,p_file_name VARCHAR2, p_query VARCHAR2,p_column_name VARCHAR2,p_app_id VARCHAR2) IS
	rg_name 				 		VARCHAR2(40) := 'DataRecordSet'; 
	rg_id 					 		RecordGroup; 
	gc_id 					 		GroupColumn; 
	errcode 				 		NUMBER; 
	the_rowcount 		 		NUMBER; 
  FILENAME			   		VARCHAR2(4000);
  MYFILE 					 		TEXT_IO.FILE_TYPE;
  urlFile 					 	TEXT_IO.FILE_TYPE;
  urlPath							VARCHAR2(5000);
	V_STRING 				 		VARCHAR2(4000);
	l_alert 				 		NUMBER;
	server_file      		VARCHAR2(2000);
	file_transfer_bool	BOOLEAN;
	formserverpath   		VARCHAR2(2000);
	lv_err_reas			varchar2(2000);
	lv_cmd	varchar2(1000);
	lv_rep_server	varchar2(50);

begin
			begin
				select rep_server into lv_rep_server from eh_reports
				where principal_map_cd=p_principal
				and   app_id=p_app_id;
			exception
				when others then
				 lv_rep_server:=null;
			end;	

if lv_rep_server is not null then
		
			If p_file_name is null then
				FILENAME  := Webutil_file.FILE_SAVE_DIALOG;
			Else
			  FILENAME := p_file_name;
			End If;
  
  		FILENAME:=p_file_name||'.csv';
  
			 	If instr(FILENAME,' ') > 0 then
			 		FILENAME := 'C:\'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
			 		Message('File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default.');
			 		message('  ');
			 	end if;
 	
			sp_csv_report_generate@dms1_db3_lnk(FILENAME,p_query,errcode,lv_err_reas);
			
			host('/bin/mv /utl_dir/'||FILENAME||' /iashome/ias/reports/printer/'||FILENAME);
			
			server_file := '/iashome/ias/reports/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	
			urlFile := Text_Io.Fopen('/reports/DMS/excelpath.txt','R');
			Text_Io.Get_Line(urlFile,urlPath);
			Text_Io.Fclose(urlFile);
			formserverpath := urlPath||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);

 		file_transfer_bool := WebUtil_File_Transfer.Url_To_Client(formserverpath,FILENAME);
	 	
	 	if not file_transfer_bool  then 
	 		message('File Transfer failed');pause;
	 	end if;
	 	
	WebUtil_Host.HOST('cmd /c '||FILENAME);
	
else
  If p_file_name is null then
		FILENAME  := Webutil_file.FILE_SAVE_DIALOG;
  Else
    FILENAME := p_file_name;
  End If;
 	If instr(FILENAME,' ') > 0 then
 		FILENAME := 'C:\'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
 		Message('File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default.');
 		message('  ');
 	end if;
	rg_id := Find_Group( rg_name ); 
	IF NOT Id_Null(rg_id) THEN 
		Delete_Group( rg_id ); 
	END IF; 
	rg_id := Create_Group_From_Query( rg_name, p_query ); 
	errcode := Populate_Group( rg_id ); 
	the_rowcount := Get_Group_Row_Count( rg_id );
	server_file := '/iashome/ias/reports/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	urlFile := Text_Io.Fopen('/reports/DMS/excelpath.txt','R');
	Text_Io.Get_Line(urlFile,urlPath);
	Text_Io.Fclose(urlFile);
	formserverpath := urlPath||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	MYFILE := TEXT_IO.FOPEN(server_file, 'W');
	gc_id := Find_Column( rg_name||'.'||p_column_name); 	
	for total_loop IN 1..the_rowcount
		loop
	  	V_STRING :=  GET_GROUP_CHAR_CELL(gc_id  , total_loop )||CHR(10); 
	  	TEXT_IO.PUTF(MYFILE,V_STRING);  
		end loop;
	 	TEXT_IO.FCLOSE(MYFILE);
	 	file_transfer_bool := WebUtil_File_Transfer.Url_To_Client(formserverpath,FILENAME);
	 	if not file_transfer_bool  then 
	 		message('File Transfer failed');pause;
	 	end if;
	 	WebUtil_Host.HOST('cmd /c '||FILENAME);	 		
	 		
end if;

exception
	when others then
	Message('Error  - '||ERROR_CODE|| ERROR_TEXT);
	Raise Form_trigger_failure;
end;
```

#### SP-086 - WINDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WINDEBUG provides a debug-string output facility by delegating to the external D2KWUTIL library function D2KWUTIL_DEBUGSTRING. It accepts a text string, appends a newline character, registers the required external function call handle via REGISTER_FUNCTION_CALL, and then invokes the external debug-string routine. The procedure is only operational when the WIN_API layer is available; if it is not, or if any other runtime error occurs, a structured error is recorded via ADD_ERROR and ADD_EXTERNAL_ERRORS before re-raising the exception.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-073](#SP-073--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-074](#SP-074--ADD_EXTERNAL_ERRORS)) - matched by member name
- D2KWUTIL.D2KWUTIL_DEBUGSTRING ([SP-007](#SP-007--D2KWUTIL.D2KWUTIL_DEBUGSTRING)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- REGISTER_FUNCTION_CALL ([SP-082](#SP-082--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input text string and append a newline character (CHR(10)) to form the output buffer (vcBuff1).
- Step 2 - Check whether the WIN_API layer is enabled (WIN_API.API_ENABLED).
- Step 3 - If the API is enabled, register the external function call for D2KWUTIL_DEBUGSTRING by invoking REGISTER_FUNCTION_CALL, passing the debug-string function handle identifier (iDebugString), the function name 'd2kwutil_DebugString', NULL, and the parameter type marker '*CHAR'.
- Step 4 - Invoke D2KWUTIL.D2KWUTIL_DEBUGSTRING, passing the resolved function handle (WIN_API.FunctionHandle(iDebugString)) and the prepared buffer (vcBuff1) to output the debug string through the external utility.
- Step 5 - If the API is not enabled, raise the WIN_API.NOT_AVAILABLE exception.
- Step 6 - On a WIN_API.NOT_AVAILABLE exception, call ADD_ERROR with the procedure name 'WinDebug' and the WIN_API.NoAPI error code, then re-raise the exception.
- Step 7 - On any other exception, call ADD_ERROR with the procedure name 'WinDebug' and a composite error message built from WIN_API.UError concatenated with the result of ADD_EXTERNAL_ERRORS, then re-raise the exception.

---
**Decision Points**

DP-001

Condition: WIN_API.API_ENABLED evaluates to TRUE.

TRUE: Register the external function call via REGISTER_FUNCTION_CALL and invoke D2KWUTIL.D2KWUTIL_DEBUGSTRING to output the debug string.

FALSE: Raise the WIN_API.NOT_AVAILABLE exception, which is subsequently caught and logged via ADD_ERROR before being re-raised.

DP-002

Condition: The exception raised is specifically WIN_API.NOT_AVAILABLE.

TRUE: Log the error using ADD_ERROR with the procedure identifier 'WinDebug' and the WIN_API.NoAPI error constant, then re-raise.

FALSE (OTHERS): Log the error using ADD_ERROR with the procedure identifier 'WinDebug' and a composite message combining WIN_API.UError with the output of ADD_EXTERNAL_ERRORS, then re-raise.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure may only execute its core debug-output logic when WIN_API.API_ENABLED is TRUE; execution without an available WIN_API layer is not permitted and results in a raised exception.
- BR-002 - The input text is always extended with a newline character (CHR(10)) before being passed to the external debug-string function, ensuring consistent line termination in debug output.
- BR-003 - The external function D2KWUTIL.D2KWUTIL_DEBUGSTRING must be registered via REGISTER_FUNCTION_CALL before each invocation; the registration supplies the function name 'd2kwutil_DebugString' and the parameter type '*CHAR'.
- BR-004 - All exceptions must be re-raised after logging; the procedure does not silently suppress errors, ensuring that calling contexts (e.g., DEBUGLOG in D2kwutil.pld) are aware of failures.
- BR-005 - Error logging for a WIN_API.NOT_AVAILABLE condition uses ADD_ERROR with the WIN_API.NoAPI code; error logging for all other exceptions uses ADD_ERROR combined with ADD_EXTERNAL_ERRORS to capture any additional external error detail.

---
**Implementation Logic**

```plsql
  

  
PROCEDURE WinDebug  (  Text  IN   VARCHAR2) is
  vcBuff1 VARCHAR2(2000) := Text||chr(10);
begin 
  --WIN_API.Clean_Error_Stack;
  if Win_API.API_ENABLED then
    win_api.Register_function_call(iDebugString,'d2kwutil_DebugString',NULL,'*CHAR');
    d2kwutil_DebugString(win_api.FunctionHandle(iDebugString),vcBuff1);
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if; 
exception
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('WinDebug',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('WinDebug',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end WinDebug;
```

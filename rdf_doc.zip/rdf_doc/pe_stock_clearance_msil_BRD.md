# BUSINESS REQUIREMENTS DOCUMENT

## Table of Contents

- 1. Document Control
  - 1.1 Document Information
  - 1.2 Revision History
- 2. Executive Summary
  - Key Stakeholders
- 3. System Context
- 4. Functional Requirements
  - 4.1 Business Requirements
    - Requirement ID: BR-001
    - Requirement ID: BR-002
    - Requirement ID: BR-003
    - Requirement ID: BR-004
    - Requirement ID: BR-005
    - Requirement ID: BR-006
    - Requirement ID: BR-007
    - Requirement ID: BR-008
    - Requirement ID: BR-009
    - Requirement ID: BR-010
    - Requirement ID: BR-011
    - Requirement ID: BR-012
    - Requirement ID: BR-013
    - Note on Inactive Triggers
- 5. Business Rules Catalogue
- 6. Data Requirements
  - 6.1 Business Entities and Relationships
    - Parts Stock Register - PM_STOCK
    - Parts Master - PM_PART
    - Part MRP Pricing - PI_PM_PART_MRP
    - Dealer Location Master - AM_DEALER_LOC
    - Entity Relationships
  - 6.2 Data Capture Requirements
    - Search Filters (User - before triggering stock search)
    - Session / Global Context (System-set - not directly entered by the user)
    - Stock Results Grid (Read-only - system-populated after search)
  - 6.3 Reference Data
  - 6.4 Data Lifecycle
  - 6.5 Excel Output Columns
- 7. Glossary
- 8. Technical Inventory
  - 8.1 Form Architecture
    - 8.1.1 Global Variables
    - 8.1.2 Form Parameters
  - 8.2 Blocks
    - 8.2.1 Block WhereClause and OrderByClause
  - 8.3 Items Summary
  - 8.4 List of Values
  - 8.5 Alerts
  - 8.6 Program Units
  - 8.7 Triggers
    - 8.7.1 Inactive / Commented-Out Trigger Register
  - 8.8 Canvas and Window Inventory
  - 8.9 Editors
  - 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups
    - 8.10.1 Visual Attributes (form-defined)
    - 8.10.2 Property Classes (form-defined)
    - 8.10.3 Object Groups
  - 8.11 DataSourceColumn Inventory
    - B_PM_STOCK (31 columns)
- 9. Object Library
- 10. Record Groups
- 11. Referenced Database Objects
- 12. Backend Procedures and Packages
  - 12.1 Main Flow Backend Procedure/Package Index
  - 12.2 Procedure and Package Catalogue
    - POP_STOCK_DETAILS
    - GENERAL.DISP_TEXT
    - GENERAL.RAISE_ERROR
    - GENERAL.CHECK_FORM_FAILURE
    - GENERAL.ASK_CONFIRM
    - GENERAL.CHECK_NULL
    - GENERAL.L_POP_LIST_ITEM
    - SF_COPYRIGHT_DECLARATION
- 13. Package Procedure Specifications
- 14. Database Package Catalogue
- 15. PLD Procedure Call Sites
- 16. Microservice API Candidates
  - 16.1 Microservices with APIs
- 17. Workflows
- 18. PLD-Backed Logic
- 19. PCK-Backed Logic
- 20. System Interfaces
  - 20.1 Database Integrations
  - 20.2 External System Integrations
  - 20.3 Report Integrations
    - 20.3.1 Parameters Passed to the Report
- 21. Procedure and Function Business Rule Catalogue
  - 21.1 Catalogue Index
  - 21.2 Detailed Specifications
    - SP-001 - POP_STOCK_DETAILS
    - SP-002 - GENERAL.ASK_CONFIRM
    - SP-003 - GENERAL.CHECK_FORM_FAILURE
    - SP-004 - GENERAL.CHECK_NULL
    - SP-005 - GENERAL.DISP_TEXT
    - SP-006 - GENERAL.L_POP_LIST_ITEM
    - SP-007 - GENERAL.RAISE_ERROR
    - SP-008 - SF_COPYRIGHT_DECLARATION

## 1. Document Control

### 1.1 Document Information

| Field | Value |
| ----- | ----- |
| Document Title | PE_LOC_STOCK - Business Requirements Document |
| Form Module Name | PE_LOC_STOCK |
| Document Version | 1.0 |
| Date Created | October 17, 2026 |
| Author/Prepared By | BRD Agent |

### 1.2 Revision History

| Version | Date | Author | Description |
| --- | --- | --- | --- |
| 1.0 | October 17, 2026 | BRD Agent | Initial draft |

---

## 2. Executive Summary

*High-level overview of the pe_loc_stock form, its purpose, and roles referenced in the module.*

The **pe_loc_stock** Oracle Forms module is the **Location Wise Stock Enquiry** screen used within the Dealer Management System. A dealer user opens the screen, selects their dealership from a list, optionally filters by store location, and enters a part number to enquire about. The system automatically resolves the corresponding root part group, then retrieves and displays current stock levels, float stock, and allocated quantities across every store location matching the search criteria. Users can choose to view only locations that hold stock at that moment by toggling the in-stock filter. The resulting grid shows stock figures, part descriptions, and maximum retail prices per dealer, location, and store combination, allowing dealership staff to quickly assess part availability across their network before placing orders or advising customers.

### Key Stakeholders

*Who uses pe_loc_stock*

| Stakeholder | Role |
| :--- | :--- |
| **Dealer User** | Primary interactive user of the screen; selects dealership and location, enters a part number, and reviews location-wise stock figures to assess availability |

---

---

## 3. System Context

*Describes the pe_loc_stock module's role within the DMS ecosystem, scope, process flow, and key integrations.*

The **pe_loc_stock** module is the **Location Wise Stock Enquiry** screen within the Dealer Management System parts operations. It provides dealership staff with a consolidated, read-only view of parts stock across all of a dealer's store locations and connects the parts enquiry workflow with the dealer master, parts catalogue, and stock records.

**System purpose:** Enable dealer users to enquire about current, float, and allocated stock quantities for a specific part across all applicable store locations, from dealer and part selection through to on-screen display of location-wise stock figures and optional report generation.

**In scope:**

- Select a dealer from the authorised dealer list scoped to the user's organisation and principal
- Filter the stock view by a specific store location within the selected dealer
- Enter a part number and automatically resolve the root part group for the enquiry
- Toggle a filter to show all stock positions or only locations with stock greater than zero
- Display current net stock, float stock, and allocated quantities per dealer, location, and store combination
- Show part description, root part number, and maximum retail price alongside stock figures
- Present running totals for current stock, float stock, and allocated stock across the displayed rows
- Support cancellation and clear of the form with optional confirmation when unsaved state exists
- Generate a print report of the displayed stock data

**Process Name:** Location Wise Stock Enquiry

**Process Owner:** Dealer User

**Process Objective:** Allow a dealer user to select a dealership and part, resolve the root part group, and view current stock, float stock, and allocated quantities across all store locations - with an option to restrict results to locations holding stock.

**Process Trigger:** A dealer user needs to check part availability across locations before placing a parts order or advising a customer on availability.

**Process Flow:**

The complete location wise stock enquiry process follows this sequence. Each step corresponds to Functional Requirements BR-001 through BR-010 in Section 4.

```
STEP 1 ── SCREEN OPENS (BR-001)
         Dealer User opens the pe_loc_stock screen.
         The main window is maximised, copyright text is displayed, and the
         in-stock filter is initialised to off (show all stock).

STEP 2 ── INTER-FORM LAUNCH - OPTIONAL (BR-001)
         ├── CALLED FROM ANOTHER FORM: Part number and root part number are
         │    pre-populated automatically from the calling form's context;
         │    the stock display fires immediately without further user input.
         └── DIRECT LAUNCH: User proceeds manually from STEP 3.

STEP 3 ── SELECT DEALER (BR-002)
         User opens the dealer selection list and picks a dealership.
         System populates the dealer name, dealer code, and location code
         from the authorised dealer and location master.

STEP 4 ── SELECT LOCATION - OPTIONAL (BR-003)
         User selects a store location from the dropdown list, which is
         dynamically populated based on the selected dealer.
         If no location is chosen, all locations for the dealer are included.

STEP 5 ── ENTER PART NUMBER (BR-004)
         User enters the part number to enquire about.
         System looks up the part in the parts catalogue and automatically
         fills in the root part number used to group related part variants.

STEP 6 ── ROOT PART NUMBER CONFIRMED (BR-005)
         The root part number is confirmed or adjusted by the user.
         The root part number is the key used to retrieve all matching
         stock records across the dealer's locations.

STEP 7 ── TOGGLE IN-STOCK FILTER (BR-006)
         ├── FILTER ON: User checks the "show only in-stock parts" option;
         │    only locations with a net stock quantity greater than zero
         │    will appear in the results.
         └── FILTER OFF: All locations and stores are shown regardless of
              stock level.

STEP 8 ── STOCK RETRIEVAL TRIGGERED (BR-007)
         Changing the in-stock filter or navigating to the results block
         triggers the stock data retrieval.
         System iterates through all qualifying dealer-location combinations
         from the dealer location master.

STEP 9 ── STOCK DATA POPULATED (BR-008)
         For each qualifying dealer, location, and store combination, the
         system retrieves stock records and calculates current net stock,
         float stock, and allocated quantity. Part description and MRP are
         populated from the parts catalogue and price master.

STEP 10 ── RESULTS DISPLAYED (BR-009)
          The stock grid is displayed showing one row per dealer-location-
          store-part combination, with running totals for current stock,
          float stock, and allocated stock at the bottom of the grid.

STEP 11 ── PRINT REPORT - OPTIONAL (BR-010)
          User clicks the Print button; system prompts for confirmation
          and sort order preference, then submits a stock report to the
          report server for printing.

STEP 12 ── CLEAR OR EXIT (BR-010)
          ├── CLEAR: User clears the form; if unsaved state is detected,
          │    a confirmation prompt is displayed before clearing.
          └── EXIT: User exits the screen; form closes without DML commit
               as the screen is read-only.
```

**Major process interactions:**

- **Dealer and location master** - provides the authorised list of dealers and their store locations for the dealer selection dropdown
- **Parts catalogue** - resolves the root part number from an entered part number and supplies part descriptions
- **Stock records** - holds current, float, and allocated quantities per dealer, location, and store; the primary data source for the stock grid
- **Parts price master** - supplies the maximum retail price displayed alongside each stock row
- **Report server** - receives parameterised print requests when the user triggers the print report action

---

---

## 4. Functional Requirements

### 4.1 Business Requirements

#### Requirement ID: BR-001

**Requirement Title:** Form Initialization and Session Startup

**Business Description:**
When a user opens the Local Stock Enquiry screen, the system automatically prepares the working environment: it maximizes the main window for full-screen viewing, loads the copyright notice for the current financial year, and sets the stock filter to its default state. If another screen has passed a part number through to this screen (for example, from a linked enquiry), the system pre-loads that part number, resolves its root, and immediately runs the stock search so the user sees results without having to enter anything manually. After pre-loading, any passed-in values are cleared from the shared session memory so they do not affect subsequent searches.

**Actors:** Dealer User

**Preconditions:**
- The user has a valid session with the principal organisation and parent group already established.

**Main Flow:**

**Step 1 - Main window maximized and copyright notice loaded**
The system maximizes the main enquiry window so the stock results grid occupies the full screen. It then retrieves the current-year copyright declaration and displays it on the screen header.

*Procedures called:*
- **SF_COPYRIGHT_DECLARATION** ([SP-008](#SP-008--SF_COPYRIGHT_DECLARATION)) - SF_COPYRIGHT_DECLARATION - Returns a formatted copyright string for Maruti Suzuki India Limited, adjusted to display the correct financial year: January through March are attributed to the previous calendar year (reflecting the April-March Indian financial year), while April through December use the current calendar year.
    * **Step 1** - Capture the current date.
    * **Step 2** - Check whether the current month falls in January, February, or March (before the April start of the Indian financial year).
    * **Step 3** - If the month is January, February, or March, build the copyright string using the previous calendar year (since the financial year started in April of that year).
    * **Step 4** - If the month is April through December, build the copyright string using the current calendar year.
    * **Step 5** - Return the formatted copyright string in the form "© [year] Maruti Suzuki India Limited".

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Copyright year selection | Month-check branch - SF_COPYRIGHT_DECLARATION [SP-008], Steps 2-4: evaluates whether current month is before or after April | When the form is opened | Ensures the displayed copyright year matches the current Indian financial year | N/A - derivation always succeeds; no failure path |

**Step 2 - Stock filter checkbox initialized to default**
The system sets the "Stock > 0" filter to its unchecked (off) default state, ensuring that when the user first runs a stock search, results for all stock levels (including zero) are returned unless the user explicitly checks the filter.

**Step 3 - Check for pre-passed part number from calling screen**
The system checks the shared session memory for a part number value that may have been passed in from another screen. If no value is present, session memory defaults to a sentinel value and the system takes no further action in this step.

**Step 4 - Pre-load part number and trigger stock search (when passed-in value found)**
If a part number was passed from a calling screen, the system loads it into the Part Number field and also loads the corresponding root part number into the Root Part Number field. It then programmatically navigates to the Stock > 0 checkbox and fires the stock search sequence automatically, so the stock results appear immediately. After the search completes, the Stock > 0 checkbox is reset to its unchecked default state. Once consumed, the passed-in values are erased from session memory so subsequent manual searches are not affected.

*Business outcomes (errors, warnings, success, and status):*
- **BR-001-SM-01** - Form initialized successfully - the copyright notice is displayed, the window is maximized, and the form is ready for the user to enter search criteria or view pre-loaded results.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Copyright Notice (`COPY_RIGHT`) | Auto-populated | Display Item | 100 | N/A | Current-year Maruti Suzuki copyright text | Session initialized | System-set only; not user-editable | N/A |
| Stock > 0 (`STOCK_CHK`) | Optional | Check Box | N/A | N/A | Checked / Unchecked | N/A | Defaults to unchecked on form open | N/A |
| Part Number (`PART_NUM`) | Conditional - when passed from calling screen | Text Item | 15 | N/A | Value passed from calling screen | Session global populated by calling screen | Pre-loaded automatically if session global contains a value | N/A |
| Root Part Number (`ROOT_PART_NUM`) | Conditional - when Part Number is pre-loaded | Text Item | 15 | N/A | Resolved from session global | Part Number pre-loaded | Pre-loaded automatically alongside Part Number | N/A |

---

#### Requirement ID: BR-002

**Requirement Title:** Dealer Location Drop-down Population

**Business Description:**
When the user selects or enters a Dealer Name on the stock enquiry screen, the system automatically refreshes the Location drop-down to show only the locations that are relevant for the search. If a specific dealer has been selected, only that dealer's locations appear. If no dealer is selected, all locations for the user's organisation group are made available. This ensures that the Location filter always contains a valid, contextual list and prevents the user from combining a dealer with a location that does not belong to them.

**Actors:** Dealer User

**Preconditions:**
- The user has entered or selected a Dealer Name on the stock enquiry screen.

**Main Flow:**

**Step 1 - Location drop-down refreshed based on selected dealer**
After the user enters or changes the Dealer Name, the system builds and applies a fresh list of locations. If a specific dealer has been chosen, the location list is restricted to that dealer's locations within the user's organisation group. If no dealer is chosen, the location list includes all locations for the organisation group. The refreshed list is immediately available for the user to select from.

*Screen: PART DETAILS (`CN_MAIN`).*

*Procedures called:*
- **GENERAL.L_POP_LIST_ITEM** ([SP-006](#SP-006--GENERAL.L_POP_LIST_ITEM)) - GENERAL.L_POP_LIST_ITEM - Creates (or recreates) a named record group from a caller-supplied SQL query and populates it with fresh data, providing a reusable mechanism for dynamically loading list-of-values data into Oracle Forms record groups at runtime.
    * **Step 1** - Check whether a record group with the target name already exists; if it does, delete it to ensure a clean slate.
    * **Step 2** - Create a new record group using the SQL query that retrieves location descriptions and codes for the current organisation group and principal, optionally filtered to the selected dealer's code.
    * **Step 3** - Execute the query to populate the new record group, capturing any error code.
    * **Step 4** - The refreshed record group is now available to back the on-screen Location list.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dealer Name (`DEALER_NAME`) | Optional | Text Item | 100 | Dealer and Location List (LV_DEALER) | Dealer name | N/A | Must correspond to a valid dealer in the organisation group for the principal | N/A |
| Dealer Code (`DEALER`) | Auto-populated | Text Item (Number) | 5 | Dealer and Location List (LV_DEALER) | Dealer map code returned from LOV | Dealer Name entered | Set automatically from LOV selection; used to filter the location query | N/A |
| Location (`LOCATION`) | Optional | List Item | 3 | Dealer Location Master (AM_DEALER_LOC) | Location code | Dealer Name validated | Refreshed dynamically; available values depend on selected dealer (or all locations if no dealer selected) | N/A |

---

#### Requirement ID: BR-003

**Requirement Title:** Part Number to Root Part Number Resolution

**Business Description:**
When the user enters a part number on the stock enquiry screen, the system automatically looks up and fills in the corresponding root part number. The root part number groups related part variants (such as different colour or specification variants of the same underlying part) under a single family identifier. By resolving the root part number automatically, the user does not need to know or look up this grouping identifier manually - the system supplies it from the parts catalogue. If the entered part number cannot be matched in the catalogue (for any reason), the root part number field is left unchanged and the user can continue without an error being raised.

**Actors:** Dealer User

**Preconditions:**
- The user has entered a part number in the Part Number field on the stock enquiry screen.

**Main Flow:**

**Step 1 - Root part number looked up from parts catalogue**
As the user leaves the Part Number field (either by tabbing out or pressing the Tab key), the system searches the parts catalogue for the entered part number, scoped to the current principal and the user's dealer group. If a match is found, the Root Part Number field is automatically populated with the corresponding root part number. If no match is found (for any reason), no error is raised; the Root Part Number field retains its current value and the user may enter it manually if needed.

*Screen: PART DETAILS (`CN_MAIN`).*

**Alternative Flows:**
- **BR-003-AF-01** - (from Step 1) If the part number does not exist in the parts catalogue for the current principal and dealer group, the system silently takes no action - the Root Part Number field is left as-is and no message is displayed. The user can proceed to enter a root part number manually or correct the part number.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Part Number (`PART_NUM`) | Optional | Text Item | 15 | N/A | N/A | N/A | Entered by the user; used as the lookup key against the parts catalogue | No error raised on mismatch - root part number simply not updated |
| Root Part Number (`ROOT_PART_NUM`) | Auto-populated | Text Item | 15 | Parts Master (PM_PART) | Root part number for the entered part | Part Number entered | Auto-filled from the parts catalogue on field exit; user may override if needed | N/A |

---

#### Requirement ID: BR-004

**Requirement Title:** Part Stock Enquiry - Search and Display Stock Results

**Business Description:**
When the user activates the stock search (by checking or unchecking the "Stock > 0" filter), the system retrieves the current stock position for the requested part across all matching dealer locations and store bins, and displays the results in the stock grid. The user can search by a specific part number, by a root (family) part number, or by both together. Optionally, a dealer and/or location filter can be applied to narrow results to a specific site. When the "Stock > 0" filter is checked, only store bins that currently hold available stock are shown; when unchecked, all bins are shown regardless of quantity. For each row returned, the grid shows the store name, location, dealer name, part number and description, current available stock, float stock, allocated quantity, and the part's current published price.

**Actors:** Dealer User

**Preconditions:**
- At least one of Part Number or Root Part Number has been entered on the screen before activating the search.

**Main Flow:**

**Step 1 - Results grid cleared**
The system clears the stock results grid to remove any previously displayed rows, preparing it for the fresh set of results.

**Step 2 - Part number and root part number checked before search proceeds**
The system checks whether either a Part Number or a Root Part Number has been entered. If both are blank, the system displays an error and returns focus to the Part Number field; no search is performed.

*Screen: PART DETAILS (`CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Part Number or Root Part Number must be entered | WHEN-CHECKBOX-CHANGED (CB_DUMMY.STOCK_CHK) own condition - checks cb_dummy.part_num IS NOT NULL OR cb_dummy.root_part_num IS NOT NULL | When the user activates the stock search by changing the Stock > 0 checkbox | Ensures the user has provided at least one search key before the system queries the database, preventing a search that would return results for all parts | *"Please enter Part Number or Root Part Number to get details"* displayed; focus returns to Part Number field; search is stopped |

*Business outcomes (errors, warnings, success, and status):*
- **BR-004-ES-01** - Neither Part Number nor Root Part Number is entered - *"Please enter Part Number or Root Part Number to get details"*; the search is stopped and the user must enter at least one value before trying again.

**Step 3 - Dealer locations identified for stock retrieval**
The system determines which dealer locations to include in the search based on the filter values the user has entered. Four combinations are handled: no dealer and no location filter (all locations in the organisation group), dealer only (all locations for that dealer), location only (all locations matching that location code regardless of dealer), and both dealer and location (exactly that dealer-location combination). For each location identified, the stock retrieval step is called.

**Step 4 - Stock details loaded for each location**
For each dealer location identified in Step 3, the system retrieves the stock records and populates the results grid.

*Procedures called:*
- **POP_STOCK_DETAILS** ([SP-001](#SP-001--POP_STOCK_DETAILS)) - POP_STOCK_DETAILS - Populates the stock detail grid for a given dealer and location by iterating over all parts that share the selected root part number, then loading each part's available stock quantity, float stock, allocated quantity, MRP, store description, and location/dealer identifiers into the `B_PM_STOCK` block. If no root part number has been entered the procedure halts immediately and redirects focus to the mandatory field, preventing a blank grid population.
    * **Step 1** - Verify that the Root Part Number is present; if it is blank, display a "Root Part Number is required" message and stop processing for this location.
    * **Step 2** - Retrieve all child part numbers and their descriptions from the parts catalogue that belong to the entered root part number, scoped to the current principal.
    * **Step 3** - For each child part number, retrieve the store-level stock records from the stock register, joined to the store master for store descriptions and to the MRP pricing table for the current published price, filtered to the specified dealer, location, parent group, and company code.
    * **Step 4** - For each store stock record, calculate: available stock = local-store quantity + out-of-station quantity minus allocated quantity minus local float minus out-of-station float minus workshop reservation quantity; float stock = local float + out-of-station float; retrieve MRP from the most recent pricing batch.
    * **Step 5** - Apply the "Stock > 0" filter: when the checkbox is checked, only rows where the calculated available stock is greater than zero are included; when unchecked, all rows are included.
    * **Step 6** - For each qualifying row, write the location code, dealer code, store code, store description, available stock, part description, allocated quantity, float stock, location description, dealer name, part number, and MRP to the stock results grid.
    * **Step 7** - Advance the grid cursor to the next row, ready for the next store record.
    * **Step 8** - Repeat the retrieval and grid-population steps for every child part in the family until all parts and their store rows have been loaded.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Root part number must be present before stock can be retrieved | Root Part Number check - POP_STOCK_DETAILS [SP-001], Step 1: checks root_part_num is not null, calls GENERAL.CHECK_NULL [SP-004] if blank | When the stock retrieval procedure is invoked for each dealer location | Ensures that the procedure has a valid root part number to look up child parts, which is required to drive the parts-family stock query | Root Part Number field shown as blank with a "Enter a valid Root Part Number" message; processing for that location is stopped |

**Step 5 - First record navigated after all results loaded**
After all matching rows are loaded into the grid, the system positions the cursor on the first record so the user can review results from the top.

**Business Scenarios - How the stock search differs by filter combination**

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **No dealer, no location filter** | All dealer locations in the organisation group are searched; the results grid shows stock across all sites. |
| **Dealer selected, no location filter** | Only that dealer's locations are searched; results show all the selected dealer's sites. |
| **Location selected, no dealer filter** | Only locations matching the selected location code are searched (across any dealer in the group). |
| **Both dealer and location selected** | Only the exact dealer-location combination is searched; the most targeted result set. |
| **Stock > 0 filter checked** | Only store bins with a positive calculated available stock are included in the results. |
| **Stock > 0 filter unchecked** | All store bins are shown, including those with zero or negative stock. |

**Alternative Flows:**
- **BR-004-AF-01** - (from Step 2) Neither Part Number nor Root Part Number entered: *"Please enter Part Number or Root Part Number to get details"* is displayed; focus returns to the Part Number field; the search is aborted.
- **BR-004-AF-02** - (from Step 4) Root Part Number is blank when the stock retrieval procedure runs for a location: a "Enter a valid Root Part Number" message is displayed; processing for that location stops; the grid may show partial results from previously processed locations.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Part Number (`PART_NUM`) | Conditional - at least one of Part Number / Root Part Number required | Text Item | 15 | N/A | N/A | N/A | At least one of Part Number or Root Part Number must be entered before the search activates | *"Please enter Part Number or Root Part Number to get details"* |
| Root Part Number (`ROOT_PART_NUM`) | Conditional - at least one of Part Number / Root Part Number required | Text Item | 15 | Parts Master (PM_PART) | Root part number | N/A | Must be non-blank when the stock retrieval procedure runs; auto-resolved from Part Number where possible | "Enter a valid Root Part Number" message displayed by stock retrieval procedure |
| Dealer Name (`DEALER_NAME`) | Optional | Text Item | 100 | Dealer and Location List (LV_DEALER) | Dealer name | N/A | Optional filter; when provided narrows the search to that dealer's locations | N/A |
| Location (`LOCATION`) | Optional | List Item | 3 | Dealer Location Master (AM_DEALER_LOC) | Location code | N/A | Optional filter; when provided narrows the search to that location | N/A |
| Stock > 0 (`STOCK_CHK`) | Optional | Check Box | N/A | N/A | Checked / Unchecked | N/A | Controls whether zero-stock rows are included in results | N/A |
| Stores (`NB_STORES_DESC`) | Auto-populated | Text Item | 50 | Store Master (GM_STORE) | Store description | Search executed | Read-only; populated from store master | N/A |
| Location (`NB_LOC_DESC`) | Auto-populated | Text Item | 50 | Dealer Location Master (AM_DEALER_LOC) | Location description | Search executed | Read-only | N/A |
| Dealer Name (grid) (`B_PM_STOCK.DEALER_NAME`) | Auto-populated | Text Item | 75 | Dealer Location Master (AM_DEALER_LOC) | Dealer name | Search executed | Read-only | N/A |
| Part Number (grid) (`B_PM_STOCK.PART_NUM`) | Auto-populated | Text Item | N/A | Parts Master (PM_PART) | Part number | Search executed | Read-only; child part number within the root family | N/A |
| Part Description (`NB_PART_DESC`) | Auto-populated | Display Item | 50 | Parts Master (PM_PART) | Part description | Search executed | Read-only | N/A |
| Current Stock (`NB_CURR_STOCK`) | Auto-populated | Text Item | 16 / 9,99,99,99,990.000 | N/A | Calculated net available stock | Search executed | Read-only; calculated by retrieval procedure | N/A |
| Float Stock (`NB_FLOAT_STOCK`) | Auto-populated | Text Item | 16 / 9,99,99,99,990.000 | N/A | Calculated float stock | Search executed | Read-only | N/A |
| Allocated Stock (`ALLOC_QTY`) | Auto-populated | Text Item | 17 / 9,99,99,99,990.000 | N/A | Allocated quantity from stock register | Search executed | Read-only | N/A |
| Part MRP (`PART_MRP`) | Auto-populated | Display Item (Number) | 50 | MRP Pricing (PI_PM_PART_MRP) | Current published price | Search executed | Read-only; most recent batch MRP | N/A |

---

#### Requirement ID: BR-005

**Requirement Title:** Custom Error and Message Handling

**Business Description:**
Whenever the application encounters an error or system message during any operation, the form's custom error and message handlers intercept it and display the information to the user in a consistent, readable format rather than allowing the raw system error to appear unformatted. The error handler covers several specific categories: invalid date entry, incorrect date format, entry of non-numeric characters in a numeric field, a value that is too long for the field, a concurrent-update conflict (where another user has changed the same record), foreign-key constraint violations, and any other database or system error. For date errors and numeric type errors the user is given a clear, actionable message and the form stops the current action so the user can correct their input. For concurrent-update conflicts the form rolls back any pending changes and stops. For other database errors it rolls back and stops. Certain informational-only message codes are silently suppressed. The ON-MESSAGE trigger intercepts Forms informational messages that match numeric type/length validation codes and re-routes them to the same error display.

**Actors:** Dealer User

**Preconditions:**
- Any active form operation that raises a Forms runtime or database error.

**Main Flow:**

**Step 1 - General error text displayed for all errors**
When any error occurs, the system first displays a message combining the error type, error number, and error text in a readable format to alert the user.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - Displays a message to the user through a named Oracle Forms alert, routing the message to either an error alert (`AL_ERRINFO`) or a note/informational alert (`AL_NOTE`) based on the supplied title, so that all form-level notifications are shown through a consistent, styled dialog.
    * **Step 1** - Set the alert type to the error alert by default.
    * **Step 2** - Evaluate the severity title: if it is "Error", keep the error alert; otherwise switch to the informational alert.
    * **Step 3** - Set the alert's title to the severity string.
    * **Step 4** - Set the alert's message text to the supplied error description.
    * **Step 5** - Display the alert to the user and capture which button was pressed (no further action taken on the return value within this call).

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Error alert type selection | Alert-type branch - GENERAL.DISP_TEXT [SP-005], Step 2: evaluates severity title string | When an error is detected during any form operation | Ensures the user sees the correct alert severity (error vs. informational) for the type of problem encountered | Alert is displayed with the appropriate severity styling |

**Step 2 - Invalid date entry intercepted**
If the error code matches an invalid date entry (error code 50004), the system additionally displays: *"Entered Date is not valid Date"* and stops the current action so the user can correct the date.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - Displays a message to the user through a named Oracle Forms alert, routing the message to either an error alert (`AL_ERRINFO`) or a note/informational alert (`AL_NOTE`) based on the supplied title, so that all form-level notifications are shown through a consistent, styled dialog.
    * **Step 1** - Set the alert type to the error alert.
    * **Step 2** - Evaluate the title string "Error" and keep the error alert.
    * **Step 3** - Set the alert title.
    * **Step 4** - Set the alert message to *"Entered Date is not valid Date"*.
    * **Step 5** - Display the alert.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Date value must be a valid calendar date | Error code 50004 check - ON-ERROR trigger own condition | When the user enters a value in a date field that cannot be parsed as a valid date | Prevents invalid dates from being accepted by the form and gives the user a clear correction message | *"Entered Date is not valid Date"*; action halted; user must correct the date entry |

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-ES-01** - Invalid date value entered - *"Entered Date is not valid Date"*; the current action is stopped.

**Step 3 - Incorrect date format intercepted**
If the error code indicates the date was entered in the wrong format (error codes 50025 or 50026), the system displays: *"Enter the Date in the proper format (DD-MM-YYYY)"* and stops the action.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - Displays a message to the user through a named Oracle Forms alert, routing the message to either an error alert (`AL_ERRINFO`) or a note/informational alert (`AL_NOTE`) based on the supplied title, so that all form-level notifications are shown through a consistent, styled dialog.
    * **Step 1** - Set the alert type to the error alert.
    * **Step 2** - Evaluate the "Error" title and keep the error alert.
    * **Step 3** - Set the alert title.
    * **Step 4** - Set the alert message to *"Enter the Date in the proper format (DD-MM-YYYY)"*.
    * **Step 5** - Display the alert.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Date must be entered in DD-MM-YYYY format | Error codes 50025/50026 check - ON-ERROR trigger own condition | When the user enters a date in an unrecognised format | Guides the user to enter dates in the required DD-MM-YYYY format | *"Enter the Date in the proper format (DD-MM-YYYY)"*; action halted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-ES-02** - Date entered in wrong format - *"Enter the Date in the proper format (DD-MM-YYYY)"*; action halted.

**Step 4 - Non-numeric characters in numeric field intercepted**
If the error code indicates alphanumeric or special characters were entered in a numeric-only field (error codes 40209 or 50016), the system displays: *"Characters/Special Characters are not allowed here, enter the numeric value"* and stops the action.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - Displays a message to the user through a named Oracle Forms alert, routing the message to either an error alert (`AL_ERRINFO`) or a note/informational alert (`AL_NOTE`) based on the supplied title, so that all form-level notifications are shown through a consistent, styled dialog.
    * **Step 1** - Set the alert type to the error alert.
    * **Step 2** - Evaluate the "Error" title and keep the error alert.
    * **Step 3** - Set the alert title.
    * **Step 4** - Set the alert message to *"Characters/Special Characters are not allowed here, enter the numeric value"*.
    * **Step 5** - Display the alert.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Numeric fields accept only numeric input | Error codes 40209/50016 check - ON-ERROR trigger own condition | When the user types alphabetic or special characters into a field that only accepts numbers | Prevents data-type errors and guides the user to enter the correct type of value | *"Characters/Special Characters are not allowed here, enter the numeric value"*; action halted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-ES-03** - Non-numeric characters entered in a numeric field - *"Characters/Special Characters are not allowed here, enter the numeric value"*; action halted.

**Step 5 - Value too long for field intercepted**
If the error code indicates the entered value exceeds the field's maximum length (error code 40207), the system displays the standard Forms field-length error text and stops the action.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - Displays a message to the user through a named Oracle Forms alert, routing the message to either an error alert (`AL_ERRINFO`) or a note/informational alert (`AL_NOTE`) based on the supplied title, so that all form-level notifications are shown through a consistent, styled dialog.
    * **Step 1** - Set the alert type to the error alert.
    * **Step 2** - Evaluate the "Error" title and keep the error alert.
    * **Step 3** - Set the alert title.
    * **Step 4** - Set the alert message to the Forms error text for code 40207 (the built-in field-length error description).
    * **Step 5** - Display the alert.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Field value must not exceed the maximum allowed length | Error code 40207 check - ON-ERROR trigger own condition | When the user enters a value that is longer than the field accepts | Prevents data truncation or overflow and notifies the user to shorten their entry | Forms field-length error text displayed; action halted |

**Step 6 - Foreign-key (child-record) constraint violation intercepted**
If a database foreign-key constraint error occurs (DBMS error code -02292, indicating a child record exists that prevents the operation), the system calls the error code handler.

*Procedures called:*
- **GENERAL.RAISE_ERROR** ([SP-007](#SP-007--GENERAL.RAISE_ERROR)) - GENERAL.RAISE_ERROR - Receives a message code, formats it into a display string, and presents it to the user through a severity-appropriate alert (error, note, or caution), halting trigger processing when the message is of error severity.
    * **Step 1** - Build the display message by combining the error code 'E0088' with its registered message text (note: the message text lookup is commented out in the current implementation, so the message text is blank at runtime; only the code 'E0088' appears with a colon separator).
    * **Step 2** - Evaluate the message type to determine severity: if 'E' (error), display with error alert and stop processing; if 'N' (note), display informationally; if 'C' (caution), display as caution.
    * **Step 3** - Display the alert with the appropriate severity.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Foreign-key / child-record constraint | DBMS error -02292 check - ON-ERROR trigger, calls GENERAL.RAISE_ERROR [SP-007] | When a database operation violates a foreign-key constraint (a child record prevents deletion or modification) | Prevents referential integrity violations and notifies the user with a business-level error message | Business error message for code 'E0088' displayed; action halted |

**Step 7 - Concurrent-update conflict intercepted**
If the error code indicates the record was changed by another user between the time it was queried and the time the current user attempts to save (error codes 40654 through 40657, or 40659), the system displays: *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*, rolls back any pending changes, and stops the action.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - Displays a message to the user through a named Oracle Forms alert, routing the message to either an error alert (`AL_ERRINFO`) or a note/informational alert (`AL_NOTE`) based on the supplied title, so that all form-level notifications are shown through a consistent, styled dialog.
    * **Step 1** - Set the alert type to the error alert.
    * **Step 2** - Evaluate the "Error" title and keep the error alert.
    * **Step 3** - Set the alert title.
    * **Step 4** - Set the alert message to *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*.
    * **Step 5** - Display the alert.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Record must not be saved if it was changed by another user since it was last queried | Error codes 40654-40659 check - ON-ERROR trigger own condition | When the user attempts to save a record that has been modified by another user in the intervening time | Prevents overwriting another user's changes and instructs the user to re-query the record before making modifications | *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*; pending changes rolled back; action halted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-ES-04** - Concurrent-update conflict detected - *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*; changes rolled back.

**Step 8 - Any other database error intercepted**
For any other database error (where the SQL error code is non-zero and does not match any specific case above), the system displays the database error text (the system-generated error description), rolls back pending changes, and stops the current action.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - Displays a message to the user through a named Oracle Forms alert, routing the message to either an error alert (`AL_ERRINFO`) or a note/informational alert (`AL_NOTE`) based on the supplied title, so that all form-level notifications are shown through a consistent, styled dialog.
    * **Step 1** - Set the alert type to the error alert.
    * **Step 2** - Evaluate the "Error" title and keep the error alert.
    * **Step 3** - Set the alert title.
    * **Step 4** - Set the alert message to the database error text returned by the system (the actual database error description from SQLERRM).
    * **Step 5** - Display the alert.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| All unhandled database errors are caught and reported | SQLCODE not equal to zero check - ON-ERROR trigger own condition | When a database-level error not covered by any specific handler above occurs | Ensures no database error goes unnoticed; the user always receives a meaningful message rather than a silent failure | Database error text from the system displayed; pending changes rolled back; action halted |

**Step 9 - Informational form messages suppressed silently**
Form informational codes 40401 and 40405 (which relate to standard navigation and no-records events) are silently suppressed - the system takes no action and does not display these to the user.

**Step 10 - ON-MESSAGE handler for numeric validation messages**
If a Forms informational message with code 40209 or 40207 is raised (for example, when a non-numeric value is entered in a numeric field during data entry), the ON-MESSAGE trigger intercepts it and re-displays it as an error via GENERAL.DISP_TEXT, then stops the current action.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - Displays a message to the user through a named Oracle Forms alert, routing the message to either an error alert (`AL_ERRINFO`) or a note/informational alert (`AL_NOTE`) based on the supplied title, so that all form-level notifications are shown through a consistent, styled dialog.
    * **Step 1** - Set the alert type to the error alert.
    * **Step 2** - Evaluate the "Error" title and keep the error alert.
    * **Step 3** - Set the alert title.
    * **Step 4** - Set the alert message to the combined error type, code, and text.
    * **Step 5** - Display the alert.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Non-numeric or too-long field entry messages promoted to error status | Error codes 40209/40207 check - ON-MESSAGE trigger own condition | When the user enters an invalid type or oversized value during field data entry | Prevents such messages from appearing as benign information notices and ensures the user understands they must correct the entry | Error message displayed; action halted |

---

#### Requirement ID: BR-006

**Requirement Title:** Cancel and Clear Form

**Business Description:**
When the user clicks the Cancel button on the enquiry screen, the system checks whether any unsaved changes exist. If no changes have been made, the form is immediately cleared and reset so the user can start a new search. If changes have been made but not yet saved, the system asks the user to confirm that they are happy to lose those changes before clearing the form. This prevents the user from accidentally discarding work they intended to save, while still giving them the option to proceed with the clear if they wish.

**Actors:** Dealer User

**Preconditions:**
- The user is on the stock enquiry screen and has clicked the Cancel button while the button is enabled.

**Main Flow:**

**Step 1 - Cancel button's enabled state checked**
The system checks whether the Cancel button is currently active (enabled). If the button is not enabled, no action is taken.

**Step 2 - Check for unsaved changes**
If the Cancel button is enabled, the system checks whether any unsaved data changes exist on the form. If no changes exist, the form is cleared immediately without prompting the user (Step 4). If unsaved changes are present, the user is asked to confirm before clearing (Step 3).

**Step 3 - User asked to confirm discarding unsaved changes**
If the form contains unsaved changes, the system displays a confirmation prompt asking the user to confirm that unsaved data will be lost.

*Procedures called:*
- **GENERAL.ASK_CONFIRM** ([SP-002](#SP-002--GENERAL.ASK_CONFIRM)) - GENERAL.ASK_CONFIRM - Presents a confirmation dialog to the user with a caller-supplied message and returns a numeric indicator of the user's response, allowing calling code to branch based on whether the user confirmed or declined the requested action.
    * **Step 1** - Set the text of the confirmation alert to *"Entered data will not be Saved"*.
    * **Step 2** - Display the confirmation alert and capture which button the user pressed.
    * **Step 3** - If the user pressed the first (confirmation) button, return a value of 1 to signal that the user confirmed.
    * **Step 4** - If the user pressed any other button, return 0 to signal that the user cancelled the action.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| User must confirm before unsaved changes are discarded | Confirmation gate - GENERAL.ASK_CONFIRM [SP-002], returns 1 (confirmed) or 0 (dismissed) | When the user clicks Cancel while the form contains unsaved changes | Prevents accidental loss of work by requiring the user to explicitly acknowledge that unsaved data will be discarded | If the user dismisses the dialog (returns 0), the form is not cleared and remains as-is; the user can continue working or save |

*Business outcomes (errors, warnings, success, and status):*
- **BR-006-WS-01** - Unsaved changes exist - *"Entered data will not be Saved"* - confirmation prompt displayed; user must confirm to proceed with clear.

**Step 4 - Form cleared**
Once confirmation is given (or if there were no unsaved changes to confirm), the system clears the form, removing all entered filter values and displayed stock results, returning it to a blank state ready for a new search.

**Alternative Flows:**
- **BR-006-AF-01** - (from Step 3) User dismisses the confirmation dialog (does not confirm): the form is not cleared; the user returns to the screen with their entered data and results intact.
- **BR-006-AF-02** - (from Step 1) Cancel button is disabled: the system takes no action at all.

---

#### Requirement ID: BR-007

**Requirement Title:** Guarded Save and Commit

**Business Description:**
When the user presses the Save keyboard shortcut or clicks the Save button, the system first verifies that the Save action is permitted (the Save button must be enabled) before committing any pending changes to the database. The save sequence performs a validation check before and after the commit to confirm the operation succeeded. If the commit is successful, the form is then cleared so the user starts with a clean screen. If the Save button is not enabled - which is the normal state for this read-only enquiry form - the system takes no action, effectively preventing accidental saves.

**Actors:** Dealer User

**Preconditions:**
- The user has activated the Save action (keyboard shortcut or Save button) while on the stock enquiry screen.

**Main Flow:**

**Step 1 - Save button enabled state checked**
The system checks whether the Save button is currently active (enabled). If the button is not enabled, the save sequence is skipped and no commit is performed. This is the normal state for this enquiry form, where no data is entered for saving.

**Step 2 - Pre-commit validation check performed**
If the Save button is enabled, the system performs a pre-commit validation to confirm the form is in a valid state before committing.

*Procedures called:*
- **GENERAL.CHECK_FORM_FAILURE** ([SP-003](#SP-003--GENERAL.CHECK_FORM_FAILURE)) - GENERAL.CHECK_FORM_FAILURE - Inspects the Oracle Forms success status after a form operation and, if the operation failed, retrieves and displays the relevant error message (Oracle database error or Forms runtime error) to the user before halting further trigger processing.
    * **Step 1** - Check whether the most recent form operation was successful.
    * **Step 2** - If the operation was not successful, identify whether it was a database error or a Forms runtime error.
    * **Step 3** - For a database error, display the database error text to the user and stop processing.
    * **Step 4** - For a Forms runtime error, display the Forms error text and stop processing.
    * **Step 5** - For a successful operation, take no action and return.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Pre-commit form state must be valid | Pre-commit check - GENERAL.CHECK_FORM_FAILURE [SP-003] | When the user initiates a save while the Save button is enabled | Ensures the form data is in a valid state before the commit is attempted, preventing corrupt or incomplete data from being saved | Error message displayed and save halted if the form is not in a valid state |

**Step 3 - Data committed to database**
The system commits the pending changes to the database.

**Step 4 - Post-commit validation check performed**
After the commit, the system performs a second form-failure check to verify the commit completed without error.

*Procedures called:*
- **GENERAL.CHECK_FORM_FAILURE** ([SP-003](#SP-003--GENERAL.CHECK_FORM_FAILURE)) - GENERAL.CHECK_FORM_FAILURE - Inspects the Oracle Forms success status after a form operation and, if the operation failed, retrieves and displays the relevant error message (Oracle database error or Forms runtime error) to the user before halting further trigger processing.
    * **Step 1** - Check whether the commit operation was successful.
    * **Step 2** - If not successful, display the error and stop.
    * **Step 3** - If successful, return without action.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Post-commit form state must be valid | Post-commit check - GENERAL.CHECK_FORM_FAILURE [SP-003] | Immediately after the database commit is issued | Confirms that the commit did not raise any deferred errors and the data was genuinely saved | Error message displayed; user informed of the commit failure |

**Step 5 - Form cleared after successful save**
After a successful commit, the system clears the form so the user starts with a clean screen.

**Alternative Flows:**
- **BR-007-AF-01** - (from Step 1) Save button is disabled: no action taken; the save sequence does not execute. This is the normal state for this enquiry form.

---

#### Requirement ID: BR-008

**Requirement Title:** Form Exit

**Business Description:**
When the user clicks the Exit button or uses the exit keyboard shortcut, the system closes the stock enquiry screen and returns to the calling application context. Any pending unsaved data on the screen is discarded without prompting - the exit is unconditional and immediate. This allows the user to leave the enquiry at any time without being blocked by unsaved-data warnings that would be irrelevant for a read-only enquiry screen.

**Actors:** Dealer User

**Preconditions:**
- The user is on the stock enquiry screen.

**Main Flow:**

**Step 1 - Exit initiated via button or keyboard shortcut**
The user clicks the Exit button or activates the exit keyboard shortcut. The system exits the form immediately, closing the screen without validating or saving any pending data. All entered values and displayed results are discarded.

**Alternative Flows:**
- **BR-008-AF-01** - (from Step 1) If the form is currently in Enter-Query mode when the Exit button is clicked, the Exit button also triggers an exit from the form in the same unconditional manner.

---

#### Requirement ID: BR-009

**Requirement Title:** Form Reset and Copyright Refresh

**Business Description:**
When the user activates the Clear Form keyboard shortcut, the system clears all current data from the screen - removing any search filters and stock results - without prompting or saving. After clearing, the system reloads the current-year copyright notice in the screen header to ensure it reflects the correct financial year. This gives the user a quick way to reset the enquiry to a blank state for a fresh search, without exiting and reopening the form.

**Actors:** Dealer User

**Preconditions:**
- The user is on the stock enquiry screen.

**Main Flow:**

**Step 1 - Form cleared without saving**
The system immediately clears all entered values and displayed results from the screen, discarding any pending data changes without validation or saving.

**Step 2 - Copyright notice refreshed**
After clearing, the system reloads the copyright declaration for the current financial year and displays it in the screen header.

*Procedures called:*
- **SF_COPYRIGHT_DECLARATION** ([SP-008](#SP-008--SF_COPYRIGHT_DECLARATION)) - SF_COPYRIGHT_DECLARATION - Returns a formatted copyright string for Maruti Suzuki India Limited, adjusted to display the correct financial year: January through March are attributed to the previous calendar year (reflecting the April-March Indian financial year), while April through December use the current calendar year.
    * **Step 1** - Capture the current date.
    * **Step 2** - Determine whether the current month falls in January, February, or March.
    * **Step 3** - If January through March, build the copyright string using the previous calendar year (financial year started April prior year).
    * **Step 4** - If April through December, build the copyright string using the current calendar year.
    * **Step 5** - Return the formatted copyright string "© [year] Maruti Suzuki India Limited".

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Copyright year derived from current date and financial-year start month | Month-check branch - SF_COPYRIGHT_DECLARATION [SP-008], Steps 2-4: evaluates whether current month is before or after April | When the form is cleared via the keyboard shortcut | Ensures the copyright notice always displays the correct financial year, regardless of when the form is opened | N/A - the derivation always produces a value; no failure path |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Copyright Notice (`COPY_RIGHT`) | Auto-populated | Display Item | 100 | N/A | Current-year Maruti Suzuki copyright text | N/A | System-set only; refreshed from current date on every clear | N/A |

---

#### Requirement ID: BR-010

**Requirement Title:** Guarded Delete of Unsaved Records

**Business Description:**
When the user clicks the Delete button on the stock enquiry screen, the system checks whether the Delete action is currently permitted and whether the current record is a newly created, not-yet-saved row. Only new (unsaved) records can be deleted through this path. Existing saved records are not deleted by this button, preventing accidental removal of committed stock data. If the Delete button is not enabled, the system takes no action. This guard is consistent with this form being a read-only enquiry where the delete capability is disabled by design.

**Actors:** Dealer User

**Preconditions:**
- The user is on the stock enquiry screen and has clicked the Delete button while it is enabled.

**Main Flow:**

**Step 1 - Delete button enabled state checked**
The system checks whether the Delete button is currently active. If the button is not enabled, no action is taken.

**Step 2 - Form validation suspended**
The system temporarily suspends form-level validation to allow the deletion to proceed without triggering validation rules that might block removal of an incomplete new record.

**Step 3 - Record status checked before deletion**
The system checks whether the current record is a brand-new, not-yet-saved row. Only records that are newly inserted (not yet committed to the database) can be deleted at this point.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Only newly inserted (unsaved) records can be deleted | Record-status check - FT_DEL trigger own condition: checks system record status is INSERT | When the user clicks the Delete button while it is enabled | Prevents deletion of already-committed stock records, limiting this action to discarding unsaved new rows only | If the record is not a new unsaved row, no deletion is performed; the record is left unchanged |

**Step 4 - Unsaved record deleted**
If the current record is a new unsaved row, the system removes it from the form's buffer.

**Step 5 - Form validation reinstated**
After the deletion (or after confirming no action was needed), the system reinstates normal form-level validation.

**Alternative Flows:**
- **BR-010-AF-01** - (from Step 1) Delete button is disabled: no action taken; no record is deleted.
- **BR-010-AF-02** - (from Step 3) Current record is not a newly inserted row: validation is reinstated and no deletion is performed.

---

#### Requirement ID: BR-011

**Requirement Title:** Print Action (Currently Inactive)

**Business Description:**
The stock enquiry screen includes a Print button that is intended to produce a printed or exported report of the current stock results. However, the print action is not currently active - the underlying print-report call has been commented out and the form takes no action when the Print button is pressed, even if the button were enabled. The button's enabled state in the form definition is set to disabled (off), so the user cannot activate it under normal operation.

**Actors:** Dealer User

**Preconditions:**
- The user is on the stock enquiry screen.

**Main Flow:**

**Step 1 - Print button enabled state checked**
The system checks whether the Print button is currently active (enabled). If the button is not enabled (which is its configured state), no action is taken.

**Step 2 - Print action (COMMENTED OUT / INACTIVE - does not execute)**
If the Print button were enabled, the form would proceed to execute a print action. However, the print report call is commented out in the current form implementation and replaced with a no-operation placeholder. No report is generated and no output is produced regardless of the button's state.

---

#### Requirement ID: BR-012

**Requirement Title:** Guarded Insert Record (Currently Disabled)

**Business Description:**
The stock enquiry screen includes an Insert button that, if enabled, would create a new blank row in the stock results grid for manual data entry. The button is currently disabled - it cannot be activated by the user under normal operation. This is consistent with the form being a read-only enquiry screen where new stock records are not entered directly. The insert logic is present in the form but guarded by the Insert button's enabled state.

**Actors:** Dealer User

**Preconditions:**
- The user is on the stock enquiry screen.

**Main Flow:**

**Step 1 - Insert button enabled state checked**
The system checks whether the Insert button is currently active (enabled). Because the button is disabled in the form's current configuration, no action is taken and the insert sequence does not proceed.

**Step 2 - Insert sequence (guarded - only when button is enabled)**
If the Insert button were enabled, the system would navigate to the current block, move to the last existing record, and then create a new blank row for data entry.

**Alternative Flows:**
- **BR-012-AF-01** - (from Step 1) Insert button is disabled (current configuration): no action taken.

---

#### Requirement ID: BR-013

**Requirement Title:** Parts Continuity Navigation (Vestigial - Block Not Found)

**Business Description:**
The stock enquiry screen includes a Continuity button in the toolbar. When pressed, the button attempts to navigate the user to a secondary data block intended to show parts stock-on-order or factor data. However, the target block referenced by this button does not exist in the current form build. The button press executes the navigation command but the navigation will not succeed because the target block is absent. This appears to be a remnant of an earlier version of the form where the secondary block existed; its current state is effectively non-functional.

**Actors:** Dealer User

**Preconditions:**
- The user is on the stock enquiry screen.

**Main Flow:**

**Step 1 - Continuity button pressed**
The user presses the Continuity button. The system issues a navigation command to move focus to a secondary block. Because that block does not exist in the current form, the navigation fails silently or raises a runtime navigation error, and the user remains on the main screen.

---

#### Note on Inactive Triggers

The following triggers are defined in the form but are inactive (empty body or commented-out code replaced with a `null;` no-op). They do not execute and are documented here for completeness only:

| Trigger | Level / Owner | Status |
| --- | --- | --- |
| KEY-LISTVAL | Form | INACTIVE - empty body; does not execute |
| KEY-OTHERS | Form | INACTIVE - empty body; does not execute |
| KEY-NEXT-ITEM | Form | INACTIVE - empty body; does not execute |
| KEY-PREV-ITEM | Form | INACTIVE - empty body; does not execute |
| KEY-NXTBLK | Form | INACTIVE - empty body; does not execute |
| KEY-PRVBLK | Form | INACTIVE - empty body; does not execute |
| KEY-DOWN | Form | INACTIVE - empty body; does not execute |
| KEY-UP | Form | INACTIVE - empty body; does not execute |
| WHEN-VALIDATE-ITEM | CB_DUMMY.ROOT_PART_NUM (Item) | INACTIVE - body is `null;` (previously checked Part Number, now commented out); does not execute |

---

## 5. Business Rules Catalogue

Catalogue of the discrete business rules enforced by the form's code.

| Rule ID | Rule Name | Rule Type | Business Requirement ID | Condition | Action | Business Impact |
| ------- | --------- | --------- | ----------------------- | --------- | ------ | --------------- |
| BRC-001 | Part Number or Root Part Number required for stock search | Validation | BR-004 | The user activates the stock search (by checking or unchecking the Stock > 0 filter) without entering either a Part Number or a Root Part Number | Display *"Please enter Part Number or Root Part Number to get details"*, return focus to the Part Number field, and stop the search | Prevents a query that would attempt to retrieve stock for all parts, ensuring the search is scoped and meaningful |
| BRC-002 | Root Part Number required inside stock retrieval | Validation | BR-004 | The stock retrieval procedure is called for a dealer location but the Root Part Number field is blank | Display "Enter a valid Root Part Number" message and stop processing for that dealer location | Prevents the parts-family stock query from running without a valid root part number, which is required to enumerate child parts |
| BRC-003 | Entered date must be a valid calendar date | Validation | BR-005 | An error with code 50004 is raised during any form operation, indicating that a date field contains a value that cannot be parsed as a real date | Display *"Entered Date is not valid Date"* and halt the current action | Prevents invalid date values from being accepted, protecting data integrity |
| BRC-004 | Date must be entered in DD-MM-YYYY format | Validation | BR-005 | An error with code 50025 or 50026 is raised, indicating the date value was entered in an unrecognised format | Display *"Enter the Date in the proper format (DD-MM-YYYY)"* and halt the current action | Enforces a consistent date entry format and guides the user to correct their input |
| BRC-005 | Numeric fields must not contain non-numeric characters | Validation | BR-005 | An error with code 40209 or 50016 is raised, indicating alphabetic or special characters were entered in a field that only accepts numbers | Display *"Characters/Special Characters are not allowed here, enter the numeric value"* and halt the action | Prevents data-type errors and ensures numeric fields receive only valid numeric input |
| BRC-006 | Field value must not exceed maximum length | Validation | BR-005 | An error with code 40207 is raised, indicating the value entered exceeds the field's configured maximum length | Display the Forms built-in field-length error text and halt the action | Prevents oversized values from being submitted, protecting against truncation or overflow errors |
| BRC-007 | Foreign-key constraint violation must be reported to the user | Constraint | BR-005 | A database foreign-key constraint error (DBMS error code -02292) is raised, indicating a child record prevents the current operation | Call the business error handler for code 'E0088' to display the registered constraint violation message and halt the action | Prevents referential integrity violations and gives the user a meaningful business-level explanation rather than a raw database error |
| BRC-008 | Concurrent-update conflict must be detected and reported | Validation | BR-005 | An error with codes 40654, 40655, 40656, 40657, or 40659 is raised, indicating the record was modified by another user since it was last queried | Display *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*, roll back pending changes, and halt the action | Prevents one user from silently overwriting another user's changes; instructs the user to re-query before proceeding |
| BRC-009 | Any unhandled database error must be reported and rolled back | Constraint | BR-005 | Any database operation raises a non-zero SQL error code not covered by the specific handlers above | Display the database error description text, roll back pending changes, and halt the action | Ensures no database error is silently ignored; all failures are surfaced to the user so they can take corrective action |
| BRC-010 | Informational form messages 40401 and 40405 suppressed | Constraint | BR-005 | An error code of 40401 or 40405 is raised (standard no-records or navigation event) | Take no action; suppress the message silently | Prevents irrelevant platform informational messages from being displayed to the user during normal navigation |
| BRC-011 | Save action blocked when Save button is disabled | Authorization | BR-007 | The user activates the Save keyboard shortcut or clicks the Save button while the Save button is in a disabled state | Take no action; do not commit | Prevents accidental data commits on this read-only enquiry form, where the Save button is disabled by design |
| BRC-012 | Pre-commit form state must be valid before saving | Validation | BR-007 | The Save button is enabled and the user initiates a save, but the form's most recent operation did not complete successfully | Display the relevant error message (database or Forms runtime error) and halt the save sequence before the commit | Prevents corrupt or partially-entered data from being committed to the database |
| BRC-013 | Post-commit form state must confirm successful save | Validation | BR-007 | The database commit has been issued but the post-commit form-failure check detects that the commit did not succeed | Display the relevant error message and halt further processing | Catches deferred commit errors and alerts the user that the save did not complete successfully |
| BRC-014 | Cancel blocked when Cancel button is disabled | Authorization | BR-006 | The user clicks the Cancel button while it is in a disabled state | Take no action | Prevents the cancel/clear action when the interface has been configured to disallow it |
| BRC-015 | Unsaved changes require confirmation before discarding | Validation | BR-006 | The user clicks the Cancel button while the form contains unsaved changes | Display *"Entered data will not be Saved"* confirmation prompt; only proceed with clearing the form if the user confirms | Prevents accidental loss of work by requiring explicit user acknowledgement before unsaved data is discarded |
| BRC-016 | Delete blocked when Delete button is disabled | Authorization | BR-010 | The user clicks the Delete button while it is in a disabled state | Take no action | Prevents deletion when the form is in read-only mode or the delete capability is not permitted |
| BRC-017 | Only newly inserted (unsaved) records may be deleted | Constraint | BR-010 | The Delete button is enabled and the user clicks it, but the current record is not in a newly inserted (unsaved) state | Reinstate form validation and take no delete action | Prevents deletion of already-committed stock records through this path; limits deletion to discarding unsaved new rows only |
| BRC-018 | Insert blocked when Insert button is disabled | Authorization | BR-012 | The user clicks the Insert button while it is in a disabled state | Take no action | Prevents insertion of new records on this read-only enquiry form, where the Insert button is disabled by design |
| BRC-019 | Print blocked when Print button is disabled | Authorization | BR-011 | The user clicks the Print button while it is in a disabled state, or even when enabled, the print-report call is inactive | Take no action; no report is generated | Prevents an incomplete print action from executing; the print feature is currently not operational |
| BRC-020 | Copyright year must reflect the current Indian financial year | Derivation | BR-001, BR-009 | The form is opened or the Clear Form key is pressed | Calculate the appropriate financial year: use the previous calendar year if the current month is January, February, or March; use the current calendar year otherwise; display the result as the copyright notice | Ensures the copyright notice always displays the correct financial year for Maruti Suzuki India Limited |
| BRC-021 | Location drop-down restricted to selected dealer's locations | Derivation | BR-002 | The user has selected a specific dealer in the Dealer Name field | Build the location list query filtered to that dealer's locations for the current principal and parent group | Prevents the user from combining a dealer filter with a location that does not belong to that dealer |
| BRC-022 | Location drop-down shows all locations when no dealer selected | Derivation | BR-002 | The Dealer Name field is blank when the location list is rebuilt | Build the location list query for all locations in the parent group for the current principal, without dealer restriction | Ensures the location filter shows all available options when the user has not restricted by dealer |
| BRC-023 | Stock > 0 filter restricts results to positive-stock rows only | Derivation | BR-004 | The user checks the Stock > 0 checkbox before or after running a search | Include only stock rows where the calculated available stock (local + out-of-station minus allocated minus floats minus workshop reservation) is greater than zero | Allows users to focus on locations and stores that actually have stock available, reducing noise in the results |

**Total Business Rules Identified: 23**

---

## 6. Data Requirements

*This section covers the business entities, data capture requirements, reference data, and record lifecycle applicable to the Local Stock Enquiry form (PE_LOC_STOCK), which enables users to search for and view part-level stock positions across dealer locations and store bins.*

### 6.1 Business Entities and Relationships

*The form primarily reads stock position data from the parts stock register, cross-referenced against the parts master and the MRP pricing record, and filtered by dealer location information.*

#### Parts Stock Register - PM_STOCK

The parts stock register holds the current inventory quantities for each part number at a given dealer, location, and store combination. For each combination the record carries the local-store and out-of-station stock quantities, float stock, allocated quantities, reservation quantities, and year-to-date receipt and issue figures. This form reads these quantities to compute the available (net) stock position displayed on screen.

#### Parts Master - PM_PART

The parts master contains the canonical reference record for each part number recognised by the principal organisation. It stores the part number, its root (parent) part number, a description, and the dealer and principal codes that own the record. This form uses the parts master to resolve the root part number from a user-entered part number, and to enumerate all child part numbers belonging to a given root part before querying stock.

#### Part MRP Pricing - PI_PM_PART_MRP

The part MRP (Maximum Retail Price) table holds the manufacturer-published price for each part number, versioned by batch number. This form retrieves the most recently published MRP for each part displayed in the stock results grid.

#### Dealer Location Master - AM_DEALER_LOC

The dealer location master stores the set of physical locations (branches/sites) belonging to each dealer within the principal's network. Each record carries the dealer code, location code, location description, dealer name, parent group code, and principal map code. This form reads this table to populate the Location drop-down list when the user enters or changes the Dealer Name, and to drive the loop that fetches stock across all applicable locations when the user triggers a stock search.

#### Entity Relationships

The Parts Stock Register is the central entity. It is linked to the Parts Master by part number and to the Store master (GM_STORE, joined inside the POP_STOCK_DETAILS procedure) by store code. The Part MRP Pricing record is linked to the Parts Stock Register by part number, with the most recent batch selected. The Dealer Location Master provides the filter context (dealer code and location code) that scopes which PM_STOCK rows are retrieved.

```
AM_DEALER_LOC (dealer/location filter context)
        │
        └──► PM_STOCK (stock register - dealer + location + store)
                    ├── PM_PART   (parts master - part number / root part)
                    └── PI_PM_PART_MRP (MRP pricing - most recent batch)
```

### 6.2 Data Capture Requirements

*The form captures search filter criteria entered by the user; the stock results grid is read-only and populated programmatically. Filters may be entered individually or in combination.*

#### Search Filters (User - before triggering stock search)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Dealer Name (`DEALER_NAME`) | No | The name of the dealer whose stock is to be viewed. Selected from the Dealer LOV. When entered, it restricts the location drop-down to that dealer's locations. | Selected value must exist in the dealer/location master for the current principal and parent group. |
| Location (`LOCATION`) | No | The dealer location (branch or site) to filter results. Populated dynamically from the dealer/location master after the Dealer Name is entered. | When a dealer is selected, only that dealer's locations are shown. When no dealer is selected, all locations for the principal's parent group are available. |
| Part Number (`PART_NUM`) | Conditional | The specific part number whose stock is to be searched. Either Part Number or Root Part Number (or both) must be provided before a search can be initiated. | Must match a part in the parts master for the principal's dealer group. The system silently resolves the root part number from this value on field exit; no error is raised if no match is found. |
| Root Part Number (`ROOT_PART_NUM`) | Conditional | The root (family) part number used to retrieve all child part variants in one search. Either Root Part Number or Part Number must be provided. | Must be populated (either by the user or resolved automatically from the Part Number) before the stock search can execute; if blank when the search runs, an error is displayed. |
| Stock > 0 (`STOCK_CHK`) | No | A checkbox filter. When checked, only locations and stores where the calculated available stock is greater than zero are included in the results. When unchecked, all rows are shown regardless of stock level. | No database validation; controls the query filter applied at retrieval time. |

#### Session / Global Context (System-set - not directly entered by the user)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Principal (`GLOBAL.PRINCIPAL`) | Auto-Populated | The OEM/principal organisation code for the current session, injected at login. Scopes all queries to the correct principal's data. | Set by the session framework; not editable by the user. |
| Parent Group (`GLOBAL.PARENT_GROUP`) | Auto-Populated | The dealer parent-group code for the current session. Used to restrict dealer and location lookups to the correct group. | Set by the session framework; not editable by the user. |
| Dealer (`GLOBAL.DEALER`) | Auto-Populated | The dealer code for the logged-in user's dealership. Used as a fallback when no explicit dealer filter is entered. | Set by the session framework; not editable by the user. |
| Company/FA Code (`GLOBAL.COMP_FA`) | Auto-Populated | The company/financial-area code for the current session. Used to join stock and store records to the correct financial entity. | Set by the session framework; not editable by the user. |

#### Stock Results Grid (Read-only - system-populated after search)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Stores (`NB_STORES_DESC`) | Auto-Populated | The description of the store/bin where the stock is held. | Read-only; populated from the store master. |
| Location (`NB_LOC_DESC`) | Auto-Populated | The description of the dealer location for this stock row. | Read-only; sourced from the dealer location master. |
| Dealer Name (`DEALER_NAME`) | Auto-Populated | The name of the dealer for this stock row. | Read-only; sourced from the dealer location master. |
| Part Number (`PART_NUM`) | Auto-Populated | The part number for this stock row. | Read-only; sourced from the parts master (child part numbers under the root). |
| Part Description (`NB_PART_DESC`) | Auto-Populated | The description of the part. | Read-only; sourced from the parts master. |
| Root Part Number (`NB_ROOT_PART`) | Auto-Populated | The root part number for the displayed part. | Read-only; sourced from the parts master. |
| Current Stock (`NB_CURR_STOCK`) | Auto-Populated | The calculated net available stock (local-store qty + out-of-station qty - allocated - float - workshop reservation). | Read-only; calculated by the stock retrieval procedure. |
| Float Stock (`NB_FLOAT_STOCK`) | Auto-Populated | The quantity currently held as float stock (local + out-of-station float). | Read-only; calculated by the stock retrieval procedure. |
| Allocated Stock (`ALLOC_QTY`) | Auto-Populated | The quantity currently allocated (reserved for specific orders). | Read-only; sourced from the stock register. |
| Part MRP (`PART_MRP`) | Auto-Populated | The most recently published Maximum Retail Price for the part. | Read-only; sourced from the MRP pricing table using the latest batch number. |

### 6.3 Reference Data

*Lists the master and configuration data referenced by this form. The Dealer LOV is documented here; it is not a separate functional requirement.*

| Reference Data | Business Purpose | Used When |
| :--- | :--- | :--- |
| Dealer and Location List (LV_DEALER / RG_DEALER - AM_DEALER_LOC) | Provides the list of valid dealers and their locations for the current principal and parent group, used to populate the Dealer Name LOV and the Location drop-down. | When the user opens the Dealer Name LOV or when the Dealer Name field is validated to dynamically populate the Location list. |
| Parts Master (PM_PART) | Provides part descriptions, root part number linkages, and the canonical set of child parts under each root, scoped to the principal. | When the user enters a Part Number (to resolve the root part number) and when the stock search executes (to enumerate child parts under a root). |
| Store Master (GM_STORE) | Provides store/bin descriptions used to label each stock row in the results grid. Joined inside the stock retrieval procedure. | When the stock search executes and results are loaded into the grid. `EXTERNAL / NOT IN BUNDLE` - GM_STORE is referenced inside the POP_STOCK_DETAILS procedure but not directly in the form XML triggers. |
| Part MRP Pricing (PI_PM_PART_MRP) | Provides the most recently published MRP for each part, selected by the maximum batch number. | When the stock search executes, to display the current price alongside each stock row. |

### 6.4 Data Lifecycle

*Describes how records are created, updated, and saved within this form's evidenced behaviour.*

**Creation**

- This form does not create new stock, part, or dealer records. It is a read-only enquiry form; no INSERT operations are executed by any active trigger or program unit.

**Updates**

- No UPDATE operations are performed. The stock results grid is programmatically populated from database reads; the user cannot edit the displayed rows.
- The form's toolbar buttons for Save, Insert, and Delete are disabled (their enabled state is set to false in the form definition and the business logic guards these actions against the Save button's enabled state before executing).

**Save and Commit**

- The form's save path (`KEY-COMMIT` / `FT_SAVE`) checks whether the Save button is currently enabled before proceeding. Since the Save button is disabled for this enquiry form, no commit is issued during a normal session.
- If the Save button were enabled (e.g. in a derived/extended context), the save sequence calls a form-failure check before and after committing, and then clears the form.

**Retention and Audit**

- No audit-stamp or change-history columns are written by this form. Stock quantities, MRP values, and location records are maintained by upstream transactional forms and batch processes; this form only reads and displays those values. No data retention or purge policy is implemented here.

---

### 6.5 Excel Output Columns

This form does not use Excel download. No Excel export columns were identified in the form sources.

## 7. Glossary

*Definitions of terms, abbreviations, and acronyms used throughout this document.*

The following table defines key terms, acronyms, and abbreviations used throughout this Business Requirements Document.

| Term | Definition | Aliases | Related Terms |
| :--- | :--- | :--- | :--- |
| Allocated Quantity | Quantity of a part reserved from available stock for pending orders or jobs | ALLOC_QTY | Stock, Float Stock |
| AM_DEALER_LOC | Dealer location master table - maps dealers to their physical store locations and codes | - | Dealer, Location |
| CB_DUMMY | Control block in the Oracle Form that holds the search criteria (dealer, location, part number) entered by the user; not bound directly to a database table | - | Block, B_PM_STOCK |
| Comp FA | Company Financial Area identifier used to scope stock queries to the correct legal entity within the DMS | COMP_FA | Parent Group, Principal |
| Dealer | A franchised dealership within the DMS network identified by a dealer map code | Dealer User | Dealer Map Code, Location |
| Dealer Administrator | Role responsible for maintaining dealer and location master data in the DMS | - | Dealer |
| Dealer Map Code | Numeric identifier uniquely identifying a dealer within the organisation | DEALER_MAP_CD | Dealer, Principal |
| DMS | Dealer Management System - the integrated software platform used by dealerships to manage parts, vehicles, and service operations | - | LOV, OLB, PLD |
| DPL | Shared Oracle Forms program library (DPL.pld) providing common UI utilities used across DMS forms | DPL.pld | PLD, GENERAL |
| Float Stock | Parts stock held in transit or allocated to floating inventory positions | NB_FLOAT_STOCK | Current Stock, Allocated Quantity |
| GENERAL | Package within the DPL program library that provides shared utility procedures (alerts, null checks, list population) | - | DPL, PLD |
| GM_STORE | Store master table - stores bin and store descriptions within dealer locations | - | PM_STOCK, Stores Code |
| LOV | List of Values - a dropdown popup list in an Oracle Form that allows the user to select from a pre-defined set of valid values | - | Record Group, RG_DEALER |
| MRP | Maximum Retail Price - the government-notified ceiling price for a part | PART_MRP | Part Number, PM_PART |
| OLB | Oracle Object Library - a shared library of reusable UI components (property classes, visual attributes, window templates) subclassed by DMS forms | DPL.olb | PLD, DPL |
| Parent Group | Organisation-level grouping code used as the primary multi-org scoping key for all dealer and stock queries | PARENT_GROUP | Comp FA, Principal |
| Part Number | Unique identifier for a spare part in the DMS parts catalogue | PART_NUM | Root Part Number, PM_PART |
| PI_PM_PART_MRP | Parts MRP table - stores the current maximum retail price per part | - | MRP, PM_PART |
| PLD | Oracle Forms program library (`.pld`) - a shared PL/SQL library attached to a form to provide reusable procedures and functions | Program Library | DPL, GENERAL |
| PM_PART | Parts master table - stores part numbers, descriptions, and root part relationships | - | Part Number, Root Part Number |
| PM_STOCK | Parts stock table - stores current, float, and allocated stock quantities per dealer, location, and store | pm_Stock | Stock, Allocated Quantity |
| Principal | Numeric principal map code identifying the principal organisation in a multi-org DMS setup | PRINCIPAL | Parent Group, Dealer |
| Record Group | An Oracle Forms data structure that holds the result set for a List of Values popup | RG | LOV, RG_DEALER |
| RG_DEALER | Record group providing the dealer list for the LV_DEALER LOV; queries AM_DEALER_LOC scoped by organisation and principal | - | LOV, AM_DEALER_LOC |
| Root Part Number | The parent part number that groups related part variants; used as the primary key for stock retrieval | ROOT_PART_NUM | Part Number, PM_PART |
| Stock CHK | In-stock filter checkbox (STOCK_CHK) - when checked, restricts the stock results to locations with net stock greater than zero | STOCK_CHK | Current Stock, Float Stock |
| Stores Code | Identifier for a bin or storage area within a dealer location | STORES_CD | GM_STORE, Location |

---

---

## 8. Technical Inventory

*Complete inventory of Oracle Forms components including blocks, items, triggers, canvases, and global variables.*

### 8.1 Form Architecture

**Form Module Details:**

- Form Name: pe_loc_stock (PE_LOC_STOCK)
- Form Module XML Title: MODULE2
- Oracle Forms Version: 12c (Module version 122010400)
- Parent Object Library: DPL.olb (PC_FORM property class)
- Attached Libraries: DPL (DPL.pld program library), D2KWUTIL
- First Navigation Block: -
- Console Window: WN_MAIN - Stock Clearance Portal (Rel: 1.1.0)
- Compile Dependencies: Requires DPL.olb, DPL.pld, WEBUTIL.olb
- Source artifacts: `pe_loc_stock_fmb.xml`; OLB `DPL.olb`; DPL (DPL.pld program library); D2KWUTIL; PCK `PKG_EINV.pck`; PCK `PK_PARTS_FAMILY_STOCK.pck`; PCK `PK_PART_SEARCH_NEW.pck`; PCK `PK_VALIDATE_PARTS.pck`; `dependencies.json`; `pe_loc_stock_fmb.jsonld`

### 8.1.1 Global Variables

| Global Variable | Data Type | Set Location | Purpose |
| :--- | :--- | :--- | :--- |
| COMP_FA | Char | ProgramUnit | Company/FA identifier used to scope stock queries to the correct company |
| DEALER | Number | Trigger | Currently logged-in dealer map code; filters stock display to a specific dealer |
| PARA_PART_NUM | Char | Trigger | Inter-form part number passed from a calling form to pre-populate the part search field |
| PARA_ROOT_PART_NUM | Char | Trigger | Inter-form root part number passed from a calling form to pre-populate the root part field |
| PARENT_GROUP | Char | ProgramUnit / RecordGroup / Trigger | Organisation/parent group code used as the primary multi-org scoping key across all queries |
| PRINCIPAL | Number | ProgramUnit / RecordGroup / Trigger | Principal map code for multi-org filtering applied to dealer and part queries |

### 8.1.2 Form Parameters

*All 3 ModuleParameter entries from pe_loc_stock_fmb.xml.*

| Parameter | Data Type | Default | Description |
| :--- | :--- | :--- | :--- |
| P_FROM_DATE | Date | - | Start date boundary passed into the form at startup; reserved - not referenced in active trigger logic |
| P_TO_DATE | Date | - | End date boundary passed into the form at startup; reserved - not referenced in active trigger logic |
| P_MODEL | Char | - | Vehicle model filter passed into the form at startup; reserved - not referenced in active trigger logic |

**Total Parameters:** 3

### 8.2 Blocks

| Block Name | Query Data Source | Records | Q/I/U/D | Key Mode | Master-Detail Relationship |
| :--- | :--- | :--- | :--- | :--- | :--- |
| CB_ERR | - | 1 | N/N/N/N | Default | Control - displays error messages to the user via TXT_ERR text item |
| PB_BLK | - | 1 | N/N/N/N | Default | Control - toolbar block housing all standard action buttons (Exit, Save, Cancel, Insert, Delete, List, Print, Cut, Copy, Paste, Continue) inherited from DPL OLB |
| CB_DUMMY | - | 1 | N/N/N/N | Default | Control - entry point for dealer and part search criteria |
| B_PM_STOCK | - (programmatic population via POP_STOCK_DETAILS) | 15 | N/N/N/N | Delayed | Detail of CB_DUMMY - populated programmatically via POP_STOCK_DETAILS based on search criteria |

**Total Blocks:** 4 blocks (4 control blocks; 0 database blocks)

### 8.2.1 Block WhereClause and OrderByClause

*Block query scope from pe_loc_stock_fmb.xml. **Description** explains filter and sort in business terms; **Order By** and **Where Clause** columns retain verbatim XML text for migration.*

| Block | Description | Order By (XML) | Where Clause (XML) |
| :--- | :--- | :--- | :--- |
| CB_ERR | Control block for error display; no query data source, no where or order-by clause | - | - |
| PB_BLK | Toolbar control block housing inherited DPL action buttons; no query data source, no where or order-by clause | - | - |
| CB_DUMMY | Control block for search criteria entry; no query data source, no where or order-by clause | - | - |
| B_PM_STOCK | Displays stock records for the selected part number and dealer, filtered by location and organisation, sorted by dealer, location, store, and part number | dealer_map_cd, loc_cd, stores_cd,part_num | parent_group = :global.parent_group  and dealer_map_cd = global.dealer and loc_cd like nvl(:CB_DUMMY.LOCATION,'%') and part_num = :CB_DUMMY.PART_NUM and comp_fa = :global.comp_fa |

### 8.3 Items Summary

*Complete item inventory from `pe_loc_stock_fmb.xml`.*

**Block counts:**

*Database / non-database counts derived from XML.*

| Block | Total Items | Database Items | Non-Database Items |
| :--- | ---: | ---: | ---: |
| CB_ERR | 1 | 0 | 1 |
| PB_BLK | 16 | 0 | 16 |
| CB_DUMMY | 8 | 0 | 8 |
| B_PM_STOCK | 18 | 0 | 18 |
| **Total** | **43** | **0** | **43** |

**Item detail (all items, excluding WEBUTIL block):**

| Block | Item Name | DatabaseItem | Description |
| :--- | :--- | :--- | :--- |
| CB_ERR | TXT_ERR | false | Error message text display field; shows formatted error text to the user via the error canvas |
| PB_BLK | PB_EXIT | false | Exit button - closes the form; prompts for unsaved-changes confirmation if form has been modified |
| PB_BLK | PB_LIST | false | List of Values button - invokes the LOV for the currently focused field |
| PB_BLK | PB_INSERT | false | Insert button - inserts a new record (disabled on this read-only enquiry form) |
| PB_BLK | PB_DEL | false | Delete button - deletes the current record (disabled on this enquiry form; guard applied for query-status records) |
| PB_BLK | PM_CONT | false | Continue button - standard DPL toolbar navigation button (not navigating to a form-specific block in this form) |
| PB_BLK | PB_CANCEL | false | Cancel button - fires FT_CANCEL to discard unsaved changes with optional confirmation |
| PB_BLK | PB_SAVE | false | Save button - fires FT_SAVE to commit pending changes (disabled on this read-only enquiry form) |
| PB_BLK | PB_PRINT | false | Print button - fires FT_PRINT (inactive/null body in this form; no report is generated) |
| PB_BLK | PB_CUT | false | Cut button - clipboard cut operation |
| PB_BLK | PB_COPY | false | Copy button - clipboard copy operation |
| PB_BLK | PB_PASTE | false | Paste button - clipboard paste operation |
| PB_BLK | PB_ERR_EXIT | false | Error exit button - exits the error display canvas and returns to the main form |
| PB_BLK | PB_OK | false | OK confirmation button - acknowledges and dismisses the current action or dialog |
| PB_BLK | PB_DCANCEL | false | Dismiss/Cancel button - cancels the current action without saving |
| PB_BLK | CLOSE | false | Close button - closes the current dialog or sub-window |
| CB_DUMMY | DEALER_NAME | false | Dealer name search field; validated against the dealer master and used to populate the Location dropdown |
| CB_DUMMY | LOCATION | false | Dropdown list of locations for the selected dealer; dynamically populated after dealer name is entered |
| CB_DUMMY | PART_NUM | false | Part number search field; auto-populates the Root Part Number when a valid part is entered |
| CB_DUMMY | LOC_CD | false | Hidden location code field; linked to LV_DEALER LOV to capture the selected dealer location code |
| CB_DUMMY | DEALER | false | Numeric dealer map code; captured via the LV_DEALER LOV as the dealer identifier for stock filtering |
| CB_DUMMY | ROOT_PART_NUM | false | Root part number; auto-populated from the part master when a part number is entered |
| CB_DUMMY | COPY_RIGHT | false | Displays the system copyright declaration text populated at form startup |
| CB_DUMMY | STOCK_CHK | false | Checkbox toggle - when checked (Y), shows only parts with stock greater than zero; triggers stock repopulation |
| B_PM_STOCK | NB_STORES_DESC | false | Store description (display); name of the bin/store within the dealer location |
| B_PM_STOCK | DEALER_MAP_CD | false | Dealer map code (display); identifies the dealer for this stock row |
| B_PM_STOCK | LOC_CD | false | Location code (display); identifies the dealer location for this stock row |
| B_PM_STOCK | NB_LOC_DESC | false | Location description (display); name of the dealer location |
| B_PM_STOCK | DEALER_NAME | false | Dealer name (display); full name of the dealer for this stock row |
| B_PM_STOCK | STORES_CD | false | Store code (display); bin/store identifier within the location |
| B_PM_STOCK | NB_CURR_STOCK | false | Calculated current net stock quantity (display); derived from local and outstation stock less allocations and float |
| B_PM_STOCK | NB_FLOAT_STOCK | false | Calculated float stock quantity (display); sum of local and outstation float quantities |
| B_PM_STOCK | ALLOC_QTY | false | Allocated stock quantity (display); quantity reserved from the available stock |
| B_PM_STOCK | NB_CURR_TOT | false | Running total of current net stock across all displayed rows |
| B_PM_STOCK | NB_FLOAT_TOT | false | Running total of float stock across all displayed rows |
| B_PM_STOCK | NB_ALLOT_TOT | false | Running total of allocated stock quantity across all displayed rows |
| B_PM_STOCK | DEALER_CD | false | Dealer code (display); numeric code identifying the dealer |
| B_PM_STOCK | PARENT_GROUP | false | Parent group code (display); organisation scoping key for this stock row |
| B_PM_STOCK | PART_NUM | false | Part number (display); identifies which part this stock row belongs to |
| B_PM_STOCK | NB_PART_DESC | false | Part description (display); full name of the part from the part master |
| B_PM_STOCK | NB_ROOT_PART | false | Root part number (display); the parent part that groups related part variants |
| B_PM_STOCK | PART_MRP | false | Part maximum retail price (display); current MRP of the part from the price master |

### 8.4 List of Values

| LOV Name | Title | Record Group | Attached Block.Item |
| :--- | :--- | :--- | :--- |
| LV_DEALER | List of Dealers | RG_DEALER | CB_DUMMY.DEALER_NAME, CB_DUMMY.LOC_CD, CB_DUMMY.DEALER |

**Total LOVs:** 1

### 8.5 Alerts

*Alert elements defined in pe_loc_stock_fmb.xml. All four alerts are inherited via the DPL OLB object group and used at runtime through GENERAL.DISP_TEXT and GENERAL.ASK_CONFIRM library helpers.*

| Alert Name | Title | Message Text | Calling Context |
| :--- | :--- | :--- | :--- |
| AL_CONFIRM | (set at runtime by GENERAL.ASK_CONFIRM) | (caller-supplied confirmation text, e.g. "Entered data will not be Saved") | FT_CANCEL trigger (Form level) via GENERAL.ASK_CONFIRM; WHEN-BUTTON-PRESSED on PB_BLK.PB_EXIT via GENERAL.ASK_CONFIRM |
| AL_NOTE | (set at runtime by GENERAL.DISP_TEXT) | (caller-supplied informational message text) | ON-MESSAGE trigger (Form level), WHEN-NEW-FORM-INSTANCE trigger (Form level), WHEN-CHECKBOX-CHANGED trigger (CB_DUMMY.STOCK_CHK), WHEN-NEW-BLOCK-INSTANCE trigger (B_PM_STOCK) - all via GENERAL.DISP_TEXT |
| AL_ERRINFO | (set at runtime by GENERAL.DISP_TEXT) | (caller-supplied error message text) | ON-ERROR trigger (Form level), WHEN-VALIDATE-ITEM triggers - all via GENERAL.DISP_TEXT |
| AL_PRINT | (set at runtime) | (print-related confirmation - inactive in current implementation) | ProgramUnit CALL_REPORT_PR_PO - currently inactive (FT_PRINT has null body) |

**Total Alerts:** 4

### 8.6 Program Units

*Authoritative catalogue of **1 form-local program units**. Database packages and standalone procedures are in **Section 15.2**; PLD shared-library routines are in **Section 18**.*

| Program Unit | Type | Calls | Description |
| :--- | :--- | :--- | :--- |
| POP_STOCK_DETAILS | Procedure | GENERAL.CHECK_NULL, PM_PART (cursor), PM_STOCK (cursor), GM_STORE (join), PI_PM_PART_MRP (join) | Fetches and displays stock details for each part variant under the entered root part number, across all matching dealer-location-store combinations; applies the show-in-stock-only filter if STOCK_CHK is checked |

**Total Program Units:** 1

### 8.7 Triggers

**Item-Level Trigger Types (reference):**

| Trigger Name | Purpose |
| :--- | :--- |
| WHEN-VALIDATE-ITEM | Validates field when user leaves item |
| KEY-* | Keyboard actions - commit, exit, LOV, navigation |
| WHEN-NEW-BLOCK-INSTANCE | Initializes block on entry |
| WHEN-BUTTON-PRESSED | Executes button action |
| PRE-INSERT / POST-INSERT | Before/after record creation |
| WHEN-LIST-CHANGED | Dropdown selection changed |
| PRE-QUERY / POST-QUERY | Before/after query execution |
| WHEN-CHECKBOX-CHANGED | Checkbox toggled |
| WHEN-VALIDATE-RECORD | Validates entire record before leaving row |



**DPL library routines invoked from triggers and program units:**

| Routine | Type | Called From | Purpose |
| :--- | :--- | :--- | :--- |
| GENERAL.ASK_CONFIRM | Library routine | Form level, PB_BLK.PB_EXIT (inherited) | Displays a Yes/No confirmation dialog (AL_CONFIRM alert) and returns 1 if the user confirms, 0 otherwise; used before discarding unsaved changes |
| GENERAL.CHECK_NULL | Library routine | CB_DUMMY.ROOT_PART_NUM, ProgramUnit: POP_STOCK_DETAILS | Raises a validation error and FORM_TRIGGER_FAILURE if the supplied value is null, prompting the user to enter a valid value |
| GENERAL.DISP_TEXT | Library routine | B_PM_STOCK, CB_DUMMY.STOCK_CHK, Form level | Displays a message in an alert box (AL_ERRINFO for errors, AL_NOTE for informational); title and message text are set at runtime |
| GENERAL.L_POP_LIST_ITEM | Library routine | CB_DUMMY.DEALER_NAME | Creates or re-creates a record group from a dynamic SQL query and populates it; used to dynamically load the Location dropdown after dealer name is entered |
| GENERAL.RAISE_ERROR | Library routine | Form level | Looks up a message by code and displays it via DISP_TEXT with the appropriate severity (Error/Note/Caution); raises FORM_TRIGGER_FAILURE for error-type messages |



### 8.7.1 Inactive / Commented-Out Trigger Register

*Triggers and field validations where XML source is `null;`, fully block-commented, or legacy code preserved but not executed. Do **not** migrate these as active business requirements.*

| Status | Block | Item | Trigger | Former behaviour (preserved in comments) | Disabled since / note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Commented out** | Form | - | ON-ERROR | Handled error codes 40209, 40207, ORA-02292, 50004, 50026, record-lock errors (40654-40659), and any non-zero SQLCODE using GENERAL.RAISE_ERROR and GENERAL.DISP_TEXT | Replaced by the active, more complete ON-ERROR block that handles the same cases with improved messaging; earlier iterations left in source as comments |
| **Inactive (null body)** | Form | - | KEY-UP | Navigation - scroll up one record | Disabled; null body in pe_loc_stock_fmb.xml |
| **Inactive (null body)** | Form | - | KEY-DOWN | Navigation - scroll down one record | Disabled; null body in pe_loc_stock_fmb.xml |
| **Inactive (null body)** | Form | - | KEY-PRVBLK | Navigation - go to previous block | Disabled; null body in pe_loc_stock_fmb.xml |
| **Inactive (null body)** | Form | - | KEY-NXTBLK | Navigation - go to next block | Disabled; null body in pe_loc_stock_fmb.xml |
| **Inactive (null body)** | Form | - | KEY-PREV-ITEM | Navigation - go to previous item | Disabled; null body in pe_loc_stock_fmb.xml |
| **Inactive (null body)** | Form | - | KEY-NEXT-ITEM | Navigation - go to next item (form-level) | Disabled at form level; item-level KEY-NEXT-ITEM on CB_DUMMY.PART_NUM is active |
| **Inactive (null body)** | Form | - | KEY-OTHERS | Suppress unhandled key events | Disabled; null body in pe_loc_stock_fmb.xml |
| **Inactive (null body)** | Form | - | KEY-LISTVAL | Invoke list of values | Disabled; null body in pe_loc_stock_fmb.xml |
| **Inactive (null body)** | CB_DUMMY | ROOT_PART_NUM | WHEN-VALIDATE-ITEM | Formerly validated ROOT_PART_NUM is not null | Disabled; null body in pe_loc_stock_fmb.xml; validation for ROOT_PART_NUM now handled inside POP_STOCK_DETAILS via GENERAL.CHECK_NULL |

*Additional null-only or partially commented triggers exist on estimation and legacy blocks - see XML `TriggerText` starting with `null;` or `/*`.*


**Complete trigger inventory (37 business triggers):**
*pe_loc_stock_fmb.xml contains Trigger elements.*

| Trigger Name | Block | Item | Called From / Context | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| ON-ERROR | Form | - | Form level | Intercepts all Forms runtime errors; formats and displays error messages via GENERAL.DISP_TEXT; handles ORA-02292, date format errors, numeric entry errors, and record-locked-by-another-user errors |
| ON-MESSAGE | Form | - | Form level | Intercepts Forms messages; suppresses or reformats messages 40209 and 40207; displays formatted messages via GENERAL.DISP_TEXT |
| KEY-EXIT | Form | - | Form level | Exits the form without validation |
| KEY-LISTVAL | Form | - | Form level | **INACTIVE (null body)** - formerly invoked list of values; not executing in current implementation |
| KEY-COMMIT | Form | - | Form level | Commits the current transaction if the Save button is enabled; checks for failure after entering, then clears the form |
| KEY-CLRFRM | Form | - | Form level | Clears the form without validation, then repopulates the copyright display item |
| KEY-OTHERS | Form | - | Form level | **INACTIVE (null body)** - formerly suppressed all unhandled key events; not executing in current implementation |
| KEY-NEXT-ITEM | Form | - | Form level | **INACTIVE (null body)** - formerly navigated to next item at form level; item-level KEY-NEXT-ITEM on CB_DUMMY.PART_NUM is active |
| KEY-PREV-ITEM | Form | - | Form level | **INACTIVE (null body)** - formerly navigated to previous item; not executing |
| KEY-NXTBLK | Form | - | Form level | **INACTIVE (null body)** - formerly navigated to next block; not executing |
| KEY-PRVBLK | Form | - | Form level | **INACTIVE (null body)** - formerly navigated to previous block; not executing |
| KEY-DOWN | Form | - | Form level | **INACTIVE (null body)** - formerly scrolled down one record; not executing |
| KEY-UP | Form | - | Form level | **INACTIVE (null body)** - formerly scrolled up one record; not executing |
| FT_SAVE | Form | - | Form level | Fires COMMIT_FORM if the Save button is enabled |
| FT_CANCEL | Form | - | Form level | If the form has unsaved changes, prompts user for confirmation via ASK_CONFIRM; clears form if confirmed |
| FT_INSERT | Form | - | Form level | Navigates to the current block, goes to the last record, and inserts a new row if the Insert button is enabled |
| FT_DEL | Form | - | Form level | Deletes the current record; for QUERY-status records asks confirmation before delete if the Delete button is enabled |
| FT_LIST | Form | - | Form level | Fires LIST_VALUES if the List button is enabled |
| FT_PRINT | Form | - | Form level | Print action - body is null (print functionality suppressed) |
| WHEN-NEW-FORM-INSTANCE | Form | - | Form level | Maximizes the main window; sets copyright text; sets STOCK_CHK to N; pre-populates part fields and triggers stock display if called with inter-form parameters |
| WHEN-VALIDATE-ITEM | CB_DUMMY | DEALER_NAME | CB_DUMMY.DEALER_NAME | Builds dynamic SQL on AM_DEALER_LOC filtered by principal and parent group; calls GENERAL.L_POP_LIST_ITEM to create Location record group; populates Location dropdown |
| WHEN-VALIDATE-ITEM | CB_DUMMY | PART_NUM | CB_DUMMY.PART_NUM | Queries PM_PART to auto-populate ROOT_PART_NUM for the entered part number, scoped by principal and dealer |
| KEY-NEXT-ITEM | CB_DUMMY | PART_NUM | CB_DUMMY.PART_NUM | Performs same part number lookup as WHEN-VALIDATE-ITEM, then explicitly navigates to CB_DUMMY.ROOT_PART_NUM |
| WHEN-VALIDATE-ITEM | CB_DUMMY | ROOT_PART_NUM | CB_DUMMY.ROOT_PART_NUM | **INACTIVE (null body)** - formerly validated ROOT_PART_NUM is not null; body is null; validation now handled inside POP_STOCK_DETAILS via GENERAL.CHECK_NULL |
| WHEN-CHECKBOX-CHANGED | CB_DUMMY | STOCK_CHK | CB_DUMMY.STOCK_CHK | Navigates to B_PM_STOCK, clears the block, then iterates dealer-location combinations from AM_DEALER_LOC and calls POP_STOCK_DETAILS for each; raises error if no part entered |
| WHEN-NEW-BLOCK-INSTANCE | B_PM_STOCK | - | B_PM_STOCK | Clears B_PM_STOCK and repopulates it by iterating dealer-location combinations and calling POP_STOCK_DETAILS |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EXIT | PB_BLK.PB_EXIT (inherited) | Exits form; prompts for unsaved-changes confirmation via GENERAL.ASK_CONFIRM before exiting if form has been modified |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_LIST | PB_BLK.PB_LIST (inherited) | Fires FT_LIST trigger to invoke list of values |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_INSERT | PB_BLK.PB_INSERT (inherited) | Fires FT_INSERT trigger to create a new record |
| WHEN-BUTTON-PRESSED | PB_BLK | PM_CONT | PB_BLK.PM_CONT (inherited) | Standard DPL toolbar Continue button; not wired to a specific navigation target in this form |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_DEL | PB_BLK.PB_DEL (inherited) | Fires FT_DEL trigger to delete the current record |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CANCEL | PB_BLK.PB_CANCEL (inherited) | Fires FT_CANCEL trigger to discard unsaved changes |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SAVE | PB_BLK.PB_SAVE (inherited) | Fires FT_SAVE trigger to commit the current transaction |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PRINT | PB_BLK.PB_PRINT (inherited) | Fires FT_PRINT trigger for report printing |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CUT | PB_BLK.PB_CUT (inherited) | Executes clipboard cut operation |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_COPY | PB_BLK.PB_COPY (inherited) | Executes clipboard copy operation |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PASTE | PB_BLK.PB_PASTE (inherited) | Executes clipboard paste operation |

### 8.8 Canvas and Window Inventory

*Canvas and window elements from pe_loc_stock_fmb.xml.*

**Canvas Inventory:**

| Canvas | Type | Window |
| :--- | :--- | :--- |
| CN_ERR | Stacked | WIN_ERR |
| CN_TOOL | Content | - |
| CN_MAIN | Content | - |

**Window Inventory:**

| Window | Title | Primary Canvas |
| :--- | :--- | :--- |
| WN_MAIN | Stock Clearance Portal (Rel: 1.1.0) | CN_MAIN (inferred) |
| WIN_ERR | (no title) | CN_ERR |

### 8.9 Editors

*Popup multi-line editors defined in pe_loc_stock_fmb.xml; items reference editors via Item.EditName.*

| Editor | Title | Item Count | Attached Items (Block.Item) |
| :--- | :--- | ---: | :--- |
| ED_INVOICE | Enter  Invoice Description | 0 | - |
| ED_PROFORMA | Enter Proforma Description | 0 | - |
| ED_PRICEDESC | Enter Price Description | 0 | - |
| ED_LONG | Enter Long Description | 0 | - |

**Total Editors:** 4 *(0 attached to items; 4 defined but not currently bound)*

### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

#### 8.10.1 Visual Attributes (form-defined)

*0 VisualAttribute elements defined at form level (not inherited from DPL.olb).*

*No form-local visual attributes found in pe_loc_stock_fmb.xml.*

#### 8.10.2 Property Classes (form-defined)

*Form-local PropertyClass elements.*

*No form-local property classes found in pe_loc_stock_fmb.xml.*

#### 8.10.3 Object Groups

*Object groups bundle inherited triggers and visual objects applied form-wide at runtime.*

| Object Group Child | Type |
| :--- | :--- |
| KEY-OTHERS | Inherited trigger/object |
| KEY-NEXT-ITEM | Inherited trigger/object |
| KEY-PREV-ITEM | Inherited trigger/object |
| KEY-NXTBLK | Inherited trigger/object |
| KEY-PRVBLK | Inherited trigger/object |
| KEY-DOWN | Inherited trigger/object |
| KEY-UP | Inherited trigger/object |
| CN_ERR | Inherited trigger/object |
| VA_DISP | Inherited trigger/object |
| CB_ERR | Inherited trigger/object |
| VA_LOV | Inherited trigger/object |
| VA_TRNI_DT | Inherited trigger/object |
| VA_TITLE | Inherited trigger/object |
| VA_ALERT | Inherited trigger/object |
| VA_BUTN | Inherited trigger/object |
| VA_TEXT | Inherited trigger/object |
| VA_MPROMPT | Inherited trigger/object |
| VA_OPROMPT | Inherited trigger/object |
| VA_MAND | Inherited trigger/object |
| VA_NUM | Inherited trigger/object |
| VA_DESC | Inherited trigger/object |
| VA_ICONIC_BUTN | Inherited trigger/object |
| VA_RB | Inherited trigger/object |
| VA_CB | Inherited trigger/object |
| WN_MAIN | Inherited trigger/object |
| POP_MAIN | Inherited trigger/object |
| CN_MAIN | Inherited trigger/object |
| CN_TOOL | Inherited trigger/object |
| PB_BLK | Inherited trigger/object |
| AL_ERRINFO | Inherited trigger/object |
| AL_NOTE | Inherited trigger/object |
| AL_CONFIRM | Inherited trigger/object |
| WIN_ERR | Inherited trigger/object |
| AL_PRINT | Inherited trigger/object |
| FT_SAVE | Inherited trigger/object |
| FT_CANCEL | Inherited trigger/object |
| FT_INSERT | Inherited trigger/object |
| FT_DEL | Inherited trigger/object |
| FT_LIST | Inherited trigger/object |
| FT_PRINT | Inherited trigger/object |
| WHEN-NEW-FORM-INSTANCE | Inherited trigger/object |

### 8.11 DataSourceColumn Inventory

*31 DataSourceColumn elements across 1 blocks - formal query column-to-block mapping from pe_loc_stock_fmb.xml.*

#### B_PM_STOCK (31 columns)

| Column (DSCName) | Data Type |
| :--- | :--- |
| DEALER_MAP_CD | NUMBER |
| LOC_CD | VARCHAR2 |
| STORES_CD | VARCHAR2 |
| PART_NUM | VARCHAR2 |
| LS_STOCK_QTY | NUMBER |
| OS_STOCK_QTY | NUMBER |
| LS_YTD_REC_QTY | NUMBER |
| OS_YTD_REC_QTY | NUMBER |
| LS_YTD_ISS_QTY | NUMBER |
| OS_YTD_ISS_QTY | NUMBER |
| LAST_ISSUE_DATE | DATE |
| LAST_RECEIPT_DATE | DATE |
| LS_VALUE | NUMBER |
| OS_VALUE | NUMBER |
| LS_OPEN_STOCK_QTY | NUMBER |
| OS_OPEN_STOCK_QTY | NUMBER |
| ALLOC_QTY | NUMBER |
| LC_CCY | VARCHAR2 |
| LS_OPEN_VALUE | NUMBER |
| OS_OPEN_VALUE | NUMBER |
| LS_YTD_REC_VALUE | NUMBER |
| OS_YTD_REC_VALUE | NUMBER |
| LS_YTD_ISS_VALUE | NUMBER |
| OS_YTD_ISS_VALUE | NUMBER |
| CS_RESRV_QTY | NUMBER |
| WS_RESRV_QTY | NUMBER |
| ROOT_PART_NUM | VARCHAR2 |
| RESRV_QTY | NUMBER |
| LS_FLOAT_QTY | NUMBER |
| OS_FLOAT_QTY | NUMBER |
| PARENT_GROUP | VARCHAR2 |

**Total DataSourceColumns:** 31 across 1 blocks

---

## 9. Object Library

*The form PE_LOC_STOCK subclasses Visual Attributes, Property Classes, and one Object Group from the DPL shared Object Library. The catalogue below covers all OLB-sourced objects; form-local Visual Attributes (none defined in this form) would appear in Section 8.10.*

Source OLB file(s): DPL.olb (DPL_olb.xml)

| Name | Type | Description | Used By (count) | Sample Items |
| ---- | ---- | ----------- | --------------- | ------------ |
| VA_TEXT | VisualAttribute | Standard text item visual style - black foreground, Arial font. Applied to input/editable text fields. | 2 | B_PM_STOCK.PART_NUM, B_PM_STOCK.NB_ROOT_PART |
| VA_DISP | VisualAttribute | Display-only item visual style - black foreground, Arial font. | 0 | (no direct item-level usage in this form; defined in OLB) |
| VA_LOV | VisualAttribute | LOV field visual style - dark blue foreground, Arial font. | 0 | (no direct item-level usage in this form; defined in OLB) |
| VA_TRNI_DT | VisualAttribute | Transaction date field style - black foreground, Courier font (fixed-width). | 0 | (no direct item-level usage in this form; defined in OLB) |
| VA_TITLE | VisualAttribute | Title/header label style - blue foreground, Arial font. | 0 | (no direct item-level usage in this form; defined in OLB) |
| VA_ALERT | VisualAttribute | Alert dialog style - black foreground, MT Extra font. | 0 | (no direct item-level usage in this form; defined in OLB) |
| VA_BUTN | VisualAttribute | Standard push-button style - black foreground, Arial font. | 0 | (no direct item-level usage in this form; defined in OLB) |
| VA_TEXT | VisualAttribute | See above (also registered in OLB tab). | 0 | (duplicate OLB registration) |
| VA_MPROMPT | VisualAttribute | Mandatory-field prompt label style - black foreground, Arial font. | 0 | (no direct item-level usage in this form; defined in OLB) |
| VA_OPROMPT | VisualAttribute | Optional-field prompt label style - black foreground, Arial font. | 0 | (no direct item-level usage in this form; defined in OLB) |
| VA_MAND | VisualAttribute | Mandatory input field style - black foreground, Arial font. | 0 | (no direct item-level usage in this form; defined in OLB) |
| VA_NUM | VisualAttribute | Numeric input field style - black foreground, Arial font. | 0 | (no direct item-level usage in this form; defined in OLB) |
| VA_DESC | VisualAttribute | Description/lookup result field style - blue foreground, Small Fonts. | 0 | (no direct item-level usage in this form; defined in OLB) |
| VA_ICONIC_BUTN | VisualAttribute | Iconic button style - black foreground, no specific font set. | 0 | (no direct item-level usage in this form; defined in OLB) |
| VA_RB | VisualAttribute | Radio button style - black foreground, Arial font. | 0 | (no direct item-level usage in this form; defined in OLB) |
| VA_CB | VisualAttribute | Check box style - black foreground, Arial font. | 0 | (no direct item-level usage in this form; defined in OLB) |
| PC_FORM | PropertyClass | PROPERTY CLASS FOR FORM MODULE - defines form-level properties subclassed by the module itself. | 1 | PE_LOC_STOCK (form module) |
| PC_TEXT | PropertyClass | PROPERTY CLASS FOR TEXT ITEMS - standard editable text item properties. | 4 | CB_DUMMY.DEALER_NAME, CB_DUMMY.LOCATION, CB_DUMMY.DEALER, B_PM_STOCK.DEALER_NAME |
| PC_UTEXT | PropertyClass | PROPERTY CLASS FOR TEXT ITEMS (upper-case variant) - editable text field with upper-case formatting properties. | 1 | CB_DUMMY.PART_NUM |
| PC_DISP | PropertyClass | PROPERTY CLASS FOR TEXT ITEMS (display/read-only) - applied to non-editable display fields. | 3 | B_PM_STOCK.NB_STORES_DESC, B_PM_STOCK.NB_LOC_DESC, B_PM_STOCK.STORES_CD |
| PC_DISP_NUM | PropertyClass | PROPERTY CLASS FOR TEXT ITEMS (display numeric) - applied to read-only numeric display fields. | 6 | B_PM_STOCK.NB_CURR_STOCK, B_PM_STOCK.NB_FLOAT_STOCK, B_PM_STOCK.ALLOC_QTY, B_PM_STOCK.NB_CURR_TOT, B_PM_STOCK.NB_FLOAT_TOT, B_PM_STOCK.NB_ALLOT_TOT |
| PC_LOV | PropertyClass | PROPERTY CLASS FOR LIST OF VALUES - applied to LOV-associated form objects. | 1 | LV_DEALER (LOV) |
| PC_DESC | PropertyClass | (No comment in OLB.) General description field property class. | 0 | (no direct item-level usage in this form; defined in OLB) |
| PC_SC_DATE | PropertyClass | PROPERTY CLASS FOR DATE - short-form date field properties. | 0 | (no direct item-level usage in this form; defined in OLB) |
| PC_TITLE | PropertyClass | PROPERTY CLASS FOR TEXT ITEMS (title variant). | 0 | (no direct item-level usage in this form; defined in OLB) |
| PC_FORMAT | PropertyClass | PROPERTY CLASS FOR TEXT ITEMS (format-specific). | 0 | (no direct item-level usage in this form; defined in OLB) |
| PC_MR_BLK | PropertyClass | (No comment in OLB.) Master-record block property class. | 0 | (no direct item-level usage in this form; defined in OLB) |
| PC_DISP_DATE | PropertyClass | PROPERTY CLASS FOR TEXT ITEMS (display date, read-only). | 0 | (no direct item-level usage in this form; defined in OLB) |
| PC_DATE | PropertyClass | PROPERTY CLASS FOR DATE - editable date field. | 0 | (no direct item-level usage in this form; defined in OLB) |
| PC_DTTIME | PropertyClass | Property class for Date and Time - editable date-time field. | 0 | (no direct item-level usage in this form; defined in OLB) |
| PC_CB | PropertyClass | (No comment in OLB.) Check box property class. | 0 | (no direct item-level usage in this form; defined in OLB) |
| PC_ALERT | PropertyClass | (No comment in OLB.) Alert property class. | 0 | (no direct item-level usage in this form; defined in OLB) |
| PC_MDATE | PropertyClass | PROPERTY CLASS FOR DATE (mandatory date). | 0 | (no direct item-level usage in this form; defined in OLB) |
| PC_RB | PropertyClass | (No comment in OLB.) Radio button property class. | 0 | (no direct item-level usage in this form; defined in OLB) |
| PC_WIND | PropertyClass | PROPERTY CLASS FOR WINDOWS. | 0 | (no direct item-level usage in this form; defined in OLB) |
| PC_CANV | PropertyClass | (No comment in OLB.) Canvas property class. | 0 | (no direct item-level usage in this form; defined in OLB) |
| PC_BUTN | PropertyClass | PROPERTY CLASS FOR PUSH BUTTONS. | 0 | (no direct item-level usage in this form; defined in OLB) |
| PC_MTEXT | PropertyClass | PROPERTY CLASS FOR TEXT ITEMS (mandatory text). | 0 | (no direct item-level usage in this form; defined in OLB) |
| PC_MUTEXT | PropertyClass | PROPERTY CLASS FOR TEXT ITEMS (mandatory upper-case text). | 0 | (no direct item-level usage in this form; defined in OLB) |
| PC_NUM | PropertyClass | PROPERTY CLASS FOR NUMERIC ITEMS - editable numeric field. | 0 | (no direct item-level usage in this form; defined in OLB) |
| PC_MNUM | PropertyClass | PROPERTY CLASS FOR NUMERIC ITEMS (mandatory numeric). | 0 | (no direct item-level usage in this form; defined in OLB) |
| PC_ICONIC_BUTN | PropertyClass | PROPERTY CLASS FOR PUSH BUTTONS (iconic). | 0 | (no direct item-level usage in this form; defined in OLB) |
| PC_SCROLL | PropertyClass | (No comment in OLB.) Scrollable area / scroll-bar property class. | 0 | (no direct item-level usage in this form; defined in OLB) |
| OG_GROUP | ObjectGroup | Standard shared object group from DPL. Subclassed at the form module level; provides shared toolbar button group and common form-level trigger definitions. | 2 | PE_LOC_STOCK (form module), OG_GROUP subclass reference |

---

## 10. Record Groups

*Lists all record groups, their LOV bindings, query logic, dynamic bindings, business purpose, and form usage.*

| Record Group | Type | Used By LOV | Display Column | Return Column | Dynamic Bindings | Purpose | Where Used |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| RG_DEALER | Query | LV_DEALER | DEALER_NAME | DEALER_MAP_CD | No | Lists active dealers and their locations for the current organisation and principal, enabling the user to select a dealer for stock enquiry | LV_DEALER -> CB_DUMMY.DEALER_NAME, CB_DUMMY.LOC_CD, CB_DUMMY.DEALER |

**Total Record Groups:** 1

---

## 11. Referenced Database Objects

*Database tables, views, and objects accessed by the form.*

| Block | Base Table | Primary Key Item | Database Item |
| :--- | :--- | :--- | :--- |
| CB_DUMMY | - | - | No |
| B_PM_STOCK | pm_Stock | - | Yes |

| Object | Schema | Used In | Description |
| :--- | :--- | :--- | :--- |
| `AM_DEALER_LOC` | - | RG_DEALER, Trigger WHEN-CHECKBOX-CHANGED, Trigger WHEN-NEW-BLOCK-INSTANCE, Trigger WHEN-VALIDATE-ITEM | Dealer location master - maps dealers to their physical locations and codes |
| `PM_PART` | - | POP_STOCK_DETAILS, Trigger KEY-NEXT-ITEM, Trigger WHEN-VALIDATE-ITEM | Parts master - stores part numbers, descriptions, and root part relationships |
| `PM_STOCK` | - | B_PM_STOCK, POP_STOCK_DETAILS | Parts stock - stores current, float, and allocated stock quantities per dealer, location, and store |

**Total Referenced Objects:** 3

---

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure/Package Index

| Requirement ID | Procedure/Package | Purpose |
| -------------- | ----------------- | ------- |
| BR-001, BR-009 | SF_COPYRIGHT_DECLARATION | Returns the current-year Maruti Suzuki copyright string formatted for the active Indian financial year |
| BR-002 | GENERAL.L_POP_LIST_ITEM | Rebuilds and repopulates the Location list record group from the dealer location master, filtered by the selected dealer |
| BR-004 | POP_STOCK_DETAILS | Loads store-level stock records for a given dealer/location into the stock results grid, grouped by child parts under the root part number |
| BR-004 | GENERAL.CHECK_NULL | Validates that the Root Part Number is present before stock retrieval proceeds; raises an error and stops if blank |
| BR-005, BR-006, BR-007, BR-009 | GENERAL.DISP_TEXT | Displays error, warning, or informational alert messages to the user using the appropriate alert style |
| BR-005 | GENERAL.RAISE_ERROR | Looks up and displays a registered business error message by code (used for foreign-key constraint violations) |
| BR-006 | GENERAL.ASK_CONFIRM | Displays a confirmation alert asking the user to confirm an action (used to confirm discarding unsaved changes) |
| BR-007 | GENERAL.CHECK_FORM_FAILURE | Checks whether the most recent form operation succeeded; displays an error and halts processing if it did not |

### 12.2 Procedure and Package Catalogue

#### POP_STOCK_DETAILS

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| POP_STOCK_DETAILS | Form-local Program Unit (PROCEDURE) | WHEN-CHECKBOX-CHANGED trigger (CB_DUMMY.STOCK_CHK); WHEN-NEW-BLOCK-INSTANCE trigger (B_PM_STOCK) | Loads store-level stock records for a specified dealer/location combination into the stock results grid. Iterates over child parts belonging to the root part number, queries PM_STOCK joined to GM_STORE and PI_PM_PART_MRP, applies the Stock > 0 filter when checked, and populates each grid row with store description, stock quantities, part details, and MRP. |

#### GENERAL.DISP_TEXT

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| GENERAL.DISP_TEXT | DPL Attached Library - EXTERNAL / referenced via DPL package (callable) | ON-ERROR trigger (Form); ON-MESSAGE trigger (Form); WHEN-CHECKBOX-CHANGED trigger (CB_DUMMY.STOCK_CHK); WHEN-NEW-BLOCK-INSTANCE trigger (B_PM_STOCK) | Displays a modal alert to the user. Selects the error alert or informational alert based on the supplied title string, sets the alert title and message text, and shows the alert. Used for all error, warning, and informational messages across the form. |

#### GENERAL.RAISE_ERROR

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| GENERAL.RAISE_ERROR | DPL Attached Library - EXTERNAL / referenced via DPL package (callable) | ON-ERROR trigger (Form) | Looks up a registered business error message by its code, formats the display message, and calls GENERAL.DISP_TEXT to display it. Used to present foreign-key constraint violation errors (code 'E0088') in business-friendly language. Note: the message text lookup (`GENERAL.get_message`) is commented out in the current implementation; only the code is shown at runtime. |

#### GENERAL.CHECK_FORM_FAILURE

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| GENERAL.CHECK_FORM_FAILURE | DPL Attached Library - EXTERNAL / referenced via DPL package (callable) | KEY-COMMIT trigger (Form) | Checks whether the most recent Oracle Forms operation completed successfully. If not, determines whether the failure is a database error or a Forms runtime error, displays the appropriate error message, and raises FORM_TRIGGER_FAILURE to halt processing. Used as a pre-commit and post-commit guard in the save sequence. |

#### GENERAL.ASK_CONFIRM

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| GENERAL.ASK_CONFIRM | DPL Attached Library - EXTERNAL / referenced via DPL package (callable) | FT_CANCEL trigger (Form) | Displays a confirmation alert with a caller-supplied message and returns 1 if the user confirms (presses the first button) or 0 if the user dismisses the dialog. Used to ask the user to confirm discarding unsaved changes before the form is cleared. |

#### GENERAL.CHECK_NULL

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| GENERAL.CHECK_NULL | DPL Attached Library - EXTERNAL / referenced via DPL package (callable) | POP_STOCK_DETAILS (Form-local Program Unit) | Checks whether a supplied value is null. If it is, constructs a message "Enter a valid [field name]", calls GENERAL.DISP_TEXT to display the error, and raises FORM_TRIGGER_FAILURE to abort processing. Used inside POP_STOCK_DETAILS to validate that the Root Part Number is present before the stock query runs. |

#### GENERAL.L_POP_LIST_ITEM

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| GENERAL.L_POP_LIST_ITEM | DPL Attached Library - EXTERNAL / referenced via DPL package (callable) | WHEN-VALIDATE-ITEM trigger (CB_DUMMY.DEALER_NAME) | Rebuilds a named record group from a supplied SQL query and repopulates the associated list item. Used to refresh the Location drop-down list whenever the Dealer Name is entered or changed, filtering available locations to the selected dealer or the full organisation group. |

#### SF_COPYRIGHT_DECLARATION

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| SF_COPYRIGHT_DECLARATION | Standalone Function (SF_COPYRIGHT_DECLARATION.fnc - present in source bundle) | WHEN-NEW-FORM-INSTANCE trigger (Form); KEY-CLRFRM trigger (Form) | Returns the current Maruti Suzuki India Limited copyright string for the active Indian financial year. Determines the year based on whether the current month is in the first quarter (January-March, use prior year) or the remaining months (April-December, use current year). Called at form startup and on every clear-form action to refresh the copyright display. |

---

## 13. Package Procedure Specifications

*Behavioural requirements for each database package invoked from the form. Only packages referenced in the form XML that have a matching source ``.pck`` file in the input directory are listed. Descriptions are derived from the package bodies in the uploaded PCK sources.*

*No packages from the available PCK files are referenced in ``pe_loc_stock_fmb.xml``. The form XML does not invoke any routine from the uploaded package sources.*

| ID | Package | Description | Business Requirement | Acceptance Criteria |
| :--- | :--- | :--- | :--- | :--- |
| - | (No packages referenced) | No database package routines from the available PCK source files (PKG_EINV, PK_PARTS_FAMILY_STOCK, PK_PART_SEARCH_NEW, PK_VALIDATE_PARTS) are invoked from pe_loc_stock_fmb.xml. | N/A | N/A |

---

## 14. Database Package Catalogue

*Detailed specifications for each database package routine called from the form, including signatures and business rules.*

*No package routines from the available PCK files are referenced in ``pe_loc_stock_fmb.xml``.*

| Source File (.pck) | Package | Routine Name | Type | Definition (signature / excerpt) | Called From | Purpose |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| - | (No packages referenced) | - | - | - | - | No database package routines from the available PCK source files are invoked from pe_loc_stock_fmb.xml. |

---

**Function return values:**

| Function | Returns | Values | Description |
| :--- | :--- | :--- | :--- |
| - | Not applicable | Not applicable | *No matched package functions with documented return values in the available PCK sources.* |

---

## 15. PLD Procedure Call Sites

*Behaviour descriptions derived from ``DPL.pld``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ASK_CONFIRM | Function | Function(confirm_msg VARCHAR2) RETURN NUMBER | Trigger: FT_CANCEL in Form | Displays the AL_CONFIRM alert with the supplied message; returns 1 if the user clicks the confirmation button (Button1) or 0 otherwise; used to confirm cancellation of unsaved changes |
| CHECK_FORM_FAILURE | Procedure | Procedure() | Trigger: KEY-COMMIT in Form | Checks whether the most recent Forms operation succeeded; if not, retrieves and displays the Oracle or Forms error message via GENERAL.DISP_TEXT, then raises FORM_TRIGGER_FAILURE |
| CHECK_NULL | Procedure | Procedure(p_value IN VARCHAR2, column_title IN VARCHAR2) | ProgramUnit: POP_STOCK_DETAILS | Raises FORM_TRIGGER_FAILURE if p_value is null, displaying "Enter a valid {column_title}" error via DISP_TEXT; prevents stock population when no root part number is provided |
| DISP_TEXT | Procedure | Procedure(text_string VARCHAR2, title_string VARCHAR2) | Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: WHEN-CHECKBOX-CHANGED in CB_DUMMY.STOCK_CHK, Trigger: WHEN-NEW-BLOCK-INSTANCE in B_PM_STOCK | Sets the title and message text of AL_ERRINFO (for errors) or AL_NOTE (for all other messages) and displays the chosen alert; used throughout the form for user-facing error and informational messages |
| l_pop_list_item | Procedure | Procedure(p_rg_name VARCHAR2,p_select VARCHAR2) | Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.DEALER_NAME | Deletes any existing record group with the given name, creates a new record group from the supplied SQL query, and populates it; used to dynamically rebuild the Location list when the dealer name changes |
| PRINT_REPORT | Procedure | Procedure(TBNAME VARCHAR2, -- Table name C1NAME VARCHAR2, -- Column 1 C2NAME VARCHAR2, -- Column 2 C3NAME VARCHAR2, -- Column 3 LABEL1 VARCHAR2, -- Label for... | Trigger: FT_PRINT in Form | Prompts user to confirm printing and select report sort order; builds a parameter string and submits the GENCODEP report to the report server; displays any error via DISP_TEXT |
| RAISE_ERROR | Procedure | Procedure(mesg_code IN VARCHAR2) | Trigger: ON-ERROR in Form | Displays the message identified by mesg_code via DISP_TEXT with the appropriate severity title (Error/Note/Caution); raises FORM_TRIGGER_FAILURE for error-type messages |

**Total Active Routines:** 7 of 24 in DPL.pld source

---

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| ID | Service Name | Database Object | Input Parameters | Output | Business Function | API Endpoint Suggestion |
| -- | ------------ | --------------- | ---------------- | ------ | ----------------- | ----------------------- |
| MS-001 | Part Stock Position Service | PM_STOCK, GM_STORE, PI_PM_PART_MRP (via POP_STOCK_DETAILS) | dealer_map_cd (dealer code), loc_cd (location code), root_part_num (root part number), stock_chk (include zero-stock flag: Y/N), principal (principal org code), parent_group (dealer group code), comp_fa (company/FA code) | List of store-level stock rows: stores description, location description, dealer name, part number, part description, root part number, current stock, float stock, allocated quantity, MRP | Retrieves the current stock position for all child parts of a root part number across a given dealer location, applying an optional positive-stock filter. Drives the main stock results grid on the enquiry screen. | GET /api/v1/stock/location-stock |
| MS-002 | Dealer Location Lookup Service | AM_DEALER_LOC (via GENERAL.L_POP_LIST_ITEM / RG_DEALER) | principal (principal org code), parent_group (dealer group code), dealer_map_cd (optional dealer filter) | List of dealer locations: loc_desc (location description), loc_cd (location code), dealer_name (dealer name), dealer_map_cd (dealer code) | Returns the list of dealer locations for a principal/parent group, optionally filtered to a specific dealer. Used to populate the Dealer Name LOV and the Location drop-down on the stock enquiry screen. | GET /api/v1/dealers/locations |
| MS-003 | Part Root Number Resolution Service | PM_PART | dealer_map_cd (dealer code), principal_map_cd (principal org code), part_num (part number) | root_part_num (root part number for the entered part) | Resolves the root part number for a given part number within the dealer and principal scope. Used to auto-fill the Root Part Number field when the user enters a part number. | GET /api/v1/parts/{part_num}/root-part |
| MS-004 | Copyright Declaration Service | System date (SYSDATE) - no database table | (none - uses current date from the database server) | copyright_text (formatted copyright string: "© [year] Maruti Suzuki India Limited") | Returns the current Maruti Suzuki India Limited copyright notice for the active Indian financial year. Financial year determination: January-March use prior calendar year; April-December use current year. | GET /api/v1/config/copyright |

**Total Microservices Identified: 4**

---

## 17. Workflows

| ID | Workflow Name | Trigger Event | Steps | Decision Points | End State |
| -- | ------------- | ------------- | ----- | --------------- | --------- |
| WF-001 | Form Initialization and Pre-load | Form opened (WHEN-NEW-FORM-INSTANCE) | 1. Maximize main window. 2. Load copyright notice. 3. Set Stock > 0 filter to unchecked default. 4. Check session memory for passed-in part number. 5. If part number found: load Part Number and Root Part Number, navigate to Stock > 0 checkbox, fire stock search, reset checkbox to unchecked, erase session memory. | Is a part number present in session memory? If yes, pre-load and search; if no, present blank form for manual entry. | Form displayed ready for user input, with or without pre-loaded stock results. |
| WF-002 | Dealer Location Filter Refresh | User enters or changes Dealer Name (WHEN-VALIDATE-ITEM on CB_DUMMY.DEALER_NAME) | 1. User enters or selects a Dealer Name. 2. Build location query filtered to the selected dealer (if chosen) or all locations in the group (if no dealer). 3. Recreate the Location record group. 4. Populate the Location drop-down with the refreshed list. | Is a dealer code present? If yes, filter location list to that dealer; if no, show all locations for the organisation group. | Location drop-down reflects valid options for the current dealer context. |
| WF-003 | Part Number to Root Part Resolution | User leaves Part Number field (WHEN-VALIDATE-ITEM or KEY-NEXT-ITEM on CB_DUMMY.PART_NUM) | 1. User enters a part number and tabs off. 2. Query parts master for root part number matching the entered part number, scoped to principal and dealer group. 3. If found, populate Root Part Number field. 4. If not found, leave Root Part Number unchanged. | Does the entered part number exist in the parts catalogue? If yes, populate Root Part Number; if no, silently take no action. | Root Part Number field populated from catalogue, or unchanged if no match found. |
| WF-004 | Stock Enquiry Search | User checks or unchecks Stock > 0 checkbox (WHEN-CHECKBOX-CHANGED on CB_DUMMY.STOCK_CHK; also fires on WHEN-NEW-BLOCK-INSTANCE on B_PM_STOCK) | 1. Clear the stock results grid. 2. Validate that Part Number or Root Part Number is entered. 3. Determine applicable dealer locations based on filter combination (no dealer/no location, dealer only, location only, both). 4. For each location, call stock retrieval to load store-level stock rows. 5. Within retrieval: validate root part number is present; enumerate child parts; query PM_STOCK/GM_STORE/PI_PM_PART_MRP; apply Stock > 0 filter; populate grid rows. 6. Navigate to first result record. | Is at least one of Part Number/Root Part Number entered? (If no, abort with error.) Is the Root Part Number present when retrieval runs? (If no, abort that location.) Is the Stock > 0 filter checked? (If yes, filter to positive stock only; if no, include all.) | Stock results grid populated with store-level inventory positions for the requested part(s), or error displayed if required input is missing. |
| WF-005 | Cancel and Clear Form | User clicks Cancel button (FT_CANCEL trigger; WHEN-BUTTON-PRESSED on PB_BLK.PB_CANCEL delegates to FT_CANCEL) | 1. Check Cancel button is enabled. 2. Check form change status. 3. If changes exist, prompt user to confirm discarding. 4. If confirmed (or no changes), clear the form. | Is the Cancel button enabled? (If no, no action.) Does the form have unsaved changes? (If yes, show confirmation; if no, clear immediately.) Did the user confirm? (If yes, clear; if no, leave form unchanged.) | Form cleared and ready for new search, or form left unchanged if user cancelled the confirmation. |
| WF-006 | Save and Commit | User presses Save keyboard shortcut or clicks Save button (KEY-COMMIT; FT_SAVE; WHEN-BUTTON-PRESSED on PB_BLK.PB_SAVE delegates to FT_SAVE) | 1. Check Save button is enabled. 2. Perform pre-commit form-failure check. 3. Commit pending data to the database. 4. Perform post-commit form-failure check. 5. Clear the form after successful commit. | Is the Save button enabled? (If no, no action - normal state for this read-only enquiry.) Did the pre-commit check pass? (If no, display error and halt.) Did the commit succeed? (If no, display error and halt.) | Data committed and form cleared, or error displayed and save aborted if the button is disabled or a failure is detected. |
| WF-007 | Form Exit | User clicks Exit button or presses exit keyboard shortcut (KEY-EXIT; WHEN-BUTTON-PRESSED on PB_BLK.PB_EXIT) | 1. User activates the exit action. 2. Form exits immediately without validation or saving. All data discarded. | Is the form in Enter-Query mode when the Exit button is clicked? (Exit proceeds in either case - the button's action is unconditional.) | Form closed; user returned to calling application context. |
| WF-008 | Form Reset and Copyright Refresh | User activates Clear Form keyboard shortcut (KEY-CLRFRM) | 1. Clear all form data without saving. 2. Reload the current-year copyright notice from the copyright function. | Current month determines which financial year is used for the copyright string (January-March: prior year; April-December: current year). | Form reset to blank state with refreshed copyright notice. |

**Total Workflows Identified: 8**

---

## 18. PLD-Backed Logic

*Maps shared library routines to their business function and suggested API contracts.*

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | ASK_CONFIRM | Business Logic | Trigger: FT_CANCEL in Form | /api/v1/pld/ask_confirm | When a user cancels with unsaved changes, then a Yes/No dialog is displayed and the form is cleared only on confirmation |
| PLD-002 | CHECK_FORM_FAILURE | Validation | Trigger: KEY-COMMIT in Form | /api/v1/pld/check_form_failure | When the preceding Forms operation did not succeed, then an error message is displayed and further processing is halted |
| PLD-003 | CHECK_NULL | Validation | ProgramUnit: POP_STOCK_DETAILS | /api/v1/pld/check_null | When the root part number field is empty, then stock population is blocked with a mandatory-field error message |
| PLD-004 | DISP_TEXT | Business Logic | Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: WHEN-CHECKBOX-CHANGED in CB_DUMMY.STOCK_CHK, Trigger: WHEN-NEW-BLOCK-INSTANCE in B_PM_STOCK | /api/v1/pld/disp_text | When a message or error needs to be shown to the user, then the appropriate alert box is displayed with the supplied title and text |
| PLD-005 | l_pop_list_item | Business Logic | Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.DEALER_NAME | /api/v1/pld/l_pop_list_item | When a dealer name is entered, then the Location dropdown is dynamically rebuilt from a query against the dealer location master |
| PLD-006 | PRINT_REPORT | Business Logic | Trigger: FT_PRINT in Form | /api/v1/pld/print_report | When the user requests a print, then the system confirms and submits a parameterised report job to the report server |
| PLD-007 | RAISE_ERROR | Validation | Trigger: ON-ERROR in Form | /api/v1/pld/raise_error | When an error code is raised, then the corresponding message is retrieved and displayed with appropriate severity, halting processing for error-type messages |

---

---

## 19. PCK-Backed Logic

*Maps database package routines to their business rules and suggested API contracts.*

*No package routines from the available PCK files are referenced in ``pe_loc_stock_fmb.xml``.*

| ID | Package.Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| :--- | :--- | :--- | :--- | :--- | :--- |
| - | (No packages referenced) | - | - | - | No database package routines from the available PCK source files are invoked from pe_loc_stock_fmb.xml. |

---

## 20. System Interfaces

### 20.1 Database Integrations

| Interface Name | Type | Purpose | Data Flow | Error Handling |
| -------------- | ---- | ------- | --------- | -------------- |
| Parts Stock Register (PM_STOCK) | Database Table - SELECT | Retrieve store-level inventory quantities for parts at a given dealer, location, and store combination | Form reads ls_stock_qty, os_stock_qty, alloc_qty, ls_float_qty, os_float_qty, ws_resrv_qty, resrv_qty, ls_open_stock_qty, os_open_stock_qty, and related YTD quantities from PM_STOCK inside POP_STOCK_DETAILS | Errors propagated via ON-ERROR handler; no data silently returns empty grid rows |
| Parts Master (PM_PART) | Database Table - SELECT | Resolve root part number from an entered part number; enumerate child parts under a root part number for stock retrieval | Form reads root_part_num, part_num, part_desc from PM_PART in WHEN-VALIDATE-ITEM (CB_DUMMY.PART_NUM), KEY-NEXT-ITEM (CB_DUMMY.PART_NUM), and POP_STOCK_DETAILS; scoped to principal and dealer group | WHEN OTHERS exception handler silently suppresses no-match results for part number resolution; errors in POP_STOCK_DETAILS propagated via ON-ERROR |
| Part MRP Pricing (PI_PM_PART_MRP) | Database Table - SELECT | Retrieve the most recently published Maximum Retail Price for each part displayed in the stock results grid | Form reads mrp from PI_PM_PART_MRP inside POP_STOCK_DETAILS, using the most recent batch number (max batch_num) for each part number | Errors propagated via ON-ERROR handler |
| Dealer Location Master (AM_DEALER_LOC) | Database Table - SELECT | Populate the Dealer Name LOV and Location drop-down; drive the loop of dealer locations queried during a stock search | Form reads dealer_map_cd, dealer_name, loc_desc, loc_cd from AM_DEALER_LOC in WHEN-VALIDATE-ITEM (CB_DUMMY.DEALER_NAME), WHEN-CHECKBOX-CHANGED (CB_DUMMY.STOCK_CHK), and WHEN-NEW-BLOCK-INSTANCE (B_PM_STOCK); scoped to parent_group and principal | Errors propagated via ON-ERROR handler |
| Store Master (GM_STORE) | Database Table - SELECT (via POP_STOCK_DETAILS) | Provide store/bin descriptions for each stock row displayed in the results grid | Form reads stores_desc from GM_STORE joined to PM_STOCK inside POP_STOCK_DETAILS by stores_cd, dealer_map_cd, loc_cd, and comp_fa | Errors propagated via ON-ERROR handler; GM_STORE source file not included in bundle - join logic verified from POP_STOCK_DETAILS program unit code |

### 20.2 External System Integrations

This form does not integrate with any external systems outside the database. There are no cross-form references (CALL_FORM / OPEN_FORM), no external file accesses (HOST / file system), no web-service calls, and no interface table interactions evidenced in the form's trigger and program-unit code. The attached libraries (DPL, D2KWUTIL) provide shared utility procedures called within the form but do not constitute external system integrations.

| System Name | Integration Type | Purpose | Protocol | Endpoint | Data Exchange | Success / Error Codes |
| ----------- | ---------------- | ------- | -------- | -------- | ------------- | --------------------- |
| (None - no external system integrations evidenced in this form) | - | - | - | - | - | - |

### 20.3 Report Integrations

No report integrations are defined in this form. The `reference_data.reports` list in the functional slice is empty, and no active `RUN_PRODUCT(REPORTS, ...)` or equivalent report-launch calls exist in any active trigger or program unit. The Print button's report call is commented out and inactive (see BR-011).

| Report Name | Report Server | Parameters | Output Format | Trigger |
| ----------- | ------------- | ---------- | ------------- | ------- |
| (None - no active report integrations; print functionality is currently inactive) | - | - | - | - |

---

### 20.3.1 Parameters Passed to the Report

Values this form sends when running an Oracle Report. When the selected format is Excel, the form may take an Excel export path instead of building the full report parameter string; lexical SQL fragments (type L/C via lv_default_value) can still apply. The rows below are evidenced submit parameters for this form.

| # | What the user selects on screen | Parameter passed to the report | What is passed |
| --- | --- | --- | --- |
| 1 | Parent | P_PARENT | Passes the form value used for P_PARENT (p_parent). |

## 21. Procedure and Function Business Rule Catalogue

End-to-end business requirement specification for every stored procedure and function referenced by the PE_LOC_STOCK form.

### 21.1 Catalogue Index

8 procedures/functions - each SP ID links to its detailed specification in Section 21.2.

| SP Index | Routine Name |
| :--- | :--- |
| [SP-001](#SP-001--POP_STOCK_DETAILS) | POP_STOCK_DETAILS |
| [SP-002](#SP-002--GENERAL.ASK_CONFIRM) | GENERAL.ASK_CONFIRM |
| [SP-003](#SP-003--GENERAL.CHECK_FORM_FAILURE) | GENERAL.CHECK_FORM_FAILURE |
| [SP-004](#SP-004--GENERAL.CHECK_NULL) | GENERAL.CHECK_NULL |
| [SP-005](#SP-005--GENERAL.DISP_TEXT) | GENERAL.DISP_TEXT |
| [SP-006](#SP-006--GENERAL.L_POP_LIST_ITEM) | GENERAL.L_POP_LIST_ITEM |
| [SP-007](#SP-007--GENERAL.RAISE_ERROR) | GENERAL.RAISE_ERROR |
| [SP-008](#SP-008--SF_COPYRIGHT_DECLARATION) | SF_COPYRIGHT_DECLARATION |

---

### 21.2 Detailed Specifications

#### SP-001 - POP_STOCK_DETAILS

**Invoked From:**

- pe_loc_stock_fmb.xml [Trigger: WHEN-CHECKBOX-CHANGED]
- pe_loc_stock_fmb.xml [Trigger: WHEN-NEW-BLOCK-INSTANCE]

---

**Screen:**

PART DETAILS (N/A / CN_MAIN)

---

**Purpose**

Populates the stock detail grid for a given dealer and location by iterating over all parts that share the selected root part number, then loading each part's available stock quantity, float stock, allocated quantity, MRP, store description, and location/dealer identifiers into the `B_PM_STOCK` block. If no root part number has been entered the procedure halts immediately and redirects focus to the mandatory field, preventing a blank grid population.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| p_dealer | Caller (dealer map code from AM_DEALER_LOC loop) | NUMBER |
| p_loc_cd | Caller (location code from AM_DEALER_LOC loop) | VARCHAR2 |
| p_dealer_name | Caller (dealer name from AM_DEALER_LOC loop) | VARCHAR2 |
| p_loc_desc | Caller (location description from AM_DEALER_LOC loop) | VARCHAR2 |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.CHECK_NULL ([SP-004](#SP-004--GENERAL.CHECK_NULL)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Check whether `:CB_DUMMY.ROOT_PART_NUM` is NULL; if it is, call `GENERAL.CHECK_NULL` to display a validation message, navigate focus to the `ROOT_PART_NUM` field, and raise `FORM_TRIGGER_FAILURE` to abort further processing.
- Step 2 - If `:CB_DUMMY.ROOT_PART_NUM` is not NULL, open cursor `cur_part` to retrieve all part numbers and descriptions from `PM_PART` where the root part number matches the entered value, restricted to the principal organisation (`GLOBAL.principal`) and dealer code equal to the principal (to exclude local parts and prevent duplicate rows).
- Step 3 - For each part returned by `cur_part`, open cursor `cur_stk` (parameterised with the current part number) to retrieve stock position data from `PM_STOCK` joined to `GM_STORE` and `PI_PM_PART_MRP`, filtered to the specified dealer, location, parent group, and company/FA code.
- Step 4 - Within `cur_stk`, calculate available stock as: `ls_stock_qty + os_stock_qty - alloc_qty - ls_float_qty - os_float_qty - ws_resrv_qty`. Calculate float stock as `ls_float_qty + os_float_qty`. Retrieve the MRP from `PI_PM_PART_MRP` using the most recent batch number for the part.
- Step 5 - Apply the stock-check filter: when `:CB_DUMMY.STOCK_CHK = 'Y'` (via the UNION ALL cursor definition), only rows where the computed available stock is greater than zero are included; when `:CB_DUMMY.STOCK_CHK = 'N'`, all stock rows are included regardless of quantity.
- Step 6 - For each row returned by `cur_stk`, populate the corresponding `B_PM_STOCK` block fields: location code, dealer code, store code, store description, current stock, part description, allocated quantity, float stock, location description, dealer name, part number, and part MRP.
- Step 7 - Call `NEXT_RECORD` to advance the block cursor to the next row, ready for the next iteration.
- Step 8 - Repeat Steps 3-7 for every part in the `cur_part` result set until all parts and their store-level stock rows have been loaded into the grid.

---

**Decision Points**

DP-001

Condition:
`:CB_DUMMY.ROOT_PART_NUM` is NULL when the procedure is invoked.

TRUE:
Call `GENERAL.CHECK_NULL` to display a "Enter a valid Root Part Number" error message, set focus to the `ROOT_PART_NUM` field, and raise `FORM_TRIGGER_FAILURE` - no stock data is loaded.

FALSE:
Proceed with the nested cursor loops to populate the stock detail grid.

DP-002

Condition:
`:CB_DUMMY.STOCK_CHK = 'Y'` (stock-check filter is active).

TRUE:
Only stock rows where the computed available stock quantity is greater than zero are returned by `cur_stk` - zero or negative stock positions are excluded from the grid.

FALSE:
`:CB_DUMMY.STOCK_CHK = 'N'`: all stock rows for the part/dealer/location are returned regardless of available quantity.

---

**Database Interactions**

- DB-001 - Read PM_PART - retrieve all part numbers and descriptions belonging to the entered root part number, scoped to the principal organisation and dealer code, to drive the outer iteration loop.
- DB-002 - Read PM_STOCK - retrieve stock quantity components (local stock, outstation stock, allocated, float, workshop-reserved) for each part at the specified dealer and location, joined to GM_STORE for store description.
- DB-003 - Read PI_PM_PART_MRP - retrieve the most recent MRP value for each part using the maximum batch number, to display alongside the stock position in the grid.

---

**Business Rules**

- SBR-001 - A root part number is mandatory; attempting to populate stock details without one is blocked and the user is directed to enter the value before proceeding.
- SBR-002 - Only parts whose `principal_map_cd` equals the current principal global value and whose `dealer_map_cd` equals the principal are eligible for display, preventing duplicate rows from locally-added parts.
- SBR-003 - Available stock is computed as `ls_stock_qty + os_stock_qty - alloc_qty - ls_float_qty - os_float_qty - ws_resrv_qty`; this net figure is the stock quantity shown per store row.
- SBR-004 - When the stock-check filter (`:CB_DUMMY.STOCK_CHK`) is set to `'Y'`, only stores with a positive net available stock are shown; stores with zero or negative stock are suppressed.
- SBR-005 - The MRP displayed for each part is always taken from the most recent import batch (`MAX(batch_num)`) in `PI_PM_PART_MRP`.

---

**Implementation Logic**

```plsql
--Added by Anjiv on 04/01/2007
Procedure pop_stock_details (p_dealer NUMBER, p_loc_cd VARCHAR2, p_dealer_name VARCHAR2, p_loc_desc VARCHAR2)
IS
/*
      CURSOR c_stock1
      IS
            SELECT (  NVL ( ls_stock_qty, 0)
                    + NVL ( os_stock_qty, 0)
                    - NVL ( alloc_qty, 0)
                    - NVL ( ls_float_qty, 0)
                    - NVL ( os_float_qty, 0)
                    - NVL ( ws_resrv_qty, 0)
                   ) stock,
                   NVL ( ls_float_qty, 0) + NVL (os_float_qty, 0) float_stock,
                   NVL ( pm.alloc_qty, 0) alloc_qty,
                   gm.stores_desc,
                   pm.stores_cd,
                   pm.part_num
              FROM pm_stock pm, gm_store gm
             WHERE pm.parent_group = :GLOBAL.parent_group
               AND pm.dealer_map_cd = p_dealer
               AND pm.loc_cd = p_loc_cd
               --AND comp_fa = :GLOBAL.comp_fa
               AND pm.stores_cd = gm.stores_cd
               AND pm.part_num = :cb_dummy.part_num
               AND pm.dealer_map_cd = gm.dealer_map_cd
               AND pm.loc_cd = gm.loc_cd
               AND pm.comp_fa = gm.comp_fa;

     cursor c_stock2
     is
      			SELECT (  NVL ( ls_stock_qty, 0)
                    + NVL ( os_stock_qty, 0)
                    - NVL ( alloc_qty, 0)
                    - NVL ( ls_float_qty, 0)
                    - NVL ( os_float_qty, 0)
                    - NVL ( ws_resrv_qty, 0)
                   ) stock,
                   NVL ( ls_float_qty, 0) + NVL (os_float_qty, 0) float_stock,
                   NVL ( pm.alloc_qty, 0) alloc_qty,
                   gm.stores_desc,
                   pm.stores_cd,
				   				 pm.part_num, pt.part_desc
              FROM PM_STOCK pm, GM_STORE gm, PM_PART pt
             WHERE pm.parent_group = :GLOBAL.parent_group
               AND pm.dealer_map_cd = p_dealer
               AND pm.loc_cd = p_loc_cd
               AND pm.comp_fa = :GLOBAL.comp_fa
               AND pm.stores_cd = gm.stores_cd
               AND pm.dealer_map_cd = gm.dealer_map_cd
               AND pm.loc_cd = gm.loc_cd
               AND pm.comp_fa = gm.comp_fa
			   AND pt.dealer_map_cd IN (1,pm.dealer_map_cd)
			   AND pt.part_num = pm.part_num
			   AND pt.root_part_num = :cb_dummy.root_part_num;			   

			   
		cursor c_stock3
		is 
					SELECT (  NVL ( ls_stock_qty, 0)
                    + NVL ( os_stock_qty, 0)
                    - NVL ( alloc_qty, 0)
                    - NVL ( ls_float_qty, 0)
                    - NVL ( os_float_qty, 0)
                    - NVL ( ws_resrv_qty, 0)
                   ) stock,
                   NVL ( ls_float_qty, 0) + NVL (os_float_qty, 0) float_stock,
                   NVL ( pm.alloc_qty, 0) alloc_qty,
                   gm.stores_desc,
                   pm.stores_cd,
				   pm.part_num
              FROM PM_STOCK pm, GM_STORE gm, PM_PART pt
             WHERE pm.parent_group = :GLOBAL.parent_group
               AND pm.dealer_map_cd = p_dealer
               AND pm.loc_cd = p_loc_cd
               --AND comp_fa = :GLOBAL.comp_fa
			   AND pm.part_num = :cb_dummy.part_num
               AND pm.stores_cd = gm.stores_cd
               AND pm.dealer_map_cd = gm.dealer_map_cd
               AND pm.loc_cd = gm.loc_cd
               AND pm.comp_fa = gm.comp_fa
			   AND pt.dealer_map_cd IN (1,pm.dealer_map_cd)
			   AND pt.part_num = pm.part_num
			   AND pt.root_part_num = :cb_dummy.root_part_num;	
*/

 CURSOR cur_part IS
   SELECT pt.part_num,pt.part_desc
     FROM pm_part pt
    WHERE pt.root_part_num = :cb_dummy.root_part_num
      and principal_map_cd = :global.principal --Added by prerna for multi-org
      and dealer_map_Cd = :global.principal --Added by Arpan on 23-Aug-14 to avoid the duplicate record in detail grid due to local parts
    ;

--STOCK CHK ADDED BY NITIN ON 23-05-2025
 CURSOR cur_stk(p_part varchar2) IS
   SELECT * FROM (SELECT (  NVL ( ls_stock_qty, 0)
                    + NVL ( os_stock_qty, 0)
                    - NVL ( alloc_qty, 0)
                    - NVL ( ls_float_qty, 0)
                    - NVL ( os_float_qty, 0)
                    - NVL ( ws_resrv_qty, 0)
                   ) stock,
         NVL ( ls_float_qty, 0) + NVL (os_float_qty, 0) float_stock,
         NVL ( pm.alloc_qty, 0) alloc_qty,
         gm.stores_desc,
         pm.stores_cd,
         mr.mrp
    FROM PM_STOCK pm, GM_STORE gm, pi_pm_part_mrp mr
   WHERE pm.dealer_map_cd = p_dealer 
     AND pm.loc_cd = p_loc_cd
     AND pm.parent_group = :GLOBAL.parent_group
     AND pm.comp_fa = :GLOBAL.comp_fa
     AND pm.stores_cd = gm.stores_cd
     AND pm.dealer_map_cd = gm.dealer_map_cd
     AND pm.loc_cd = gm.loc_cd
     AND pm.comp_fa = gm.comp_fa
     AND pm.part_num = p_part
     and mr.part_num = p_part
     and mr.batch_num = (select max(batch_num)
                         from pi_pm_part_mrp rp
                         where rp.part_num = p_part))
     WHERE :CB_DUMMY.STOCK_CHK = 'Y'
     AND STOCK > 0
     UNION ALL
     SELECT * FROM (SELECT (  NVL ( ls_stock_qty, 0)
                    + NVL ( os_stock_qty, 0)
                    - NVL ( alloc_qty, 0)
                    - NVL ( ls_float_qty, 0)
                    - NVL ( os_float_qty, 0)
                    - NVL ( ws_resrv_qty, 0)
                   ) stock,
         NVL ( ls_float_qty, 0) + NVL (os_float_qty, 0) float_stock,
         NVL ( pm.alloc_qty, 0) alloc_qty,
         gm.stores_desc,
         pm.stores_cd,
         mr.mrp
    FROM PM_STOCK pm, GM_STORE gm, pi_pm_part_mrp mr
   WHERE pm.dealer_map_cd = p_dealer 
     AND pm.loc_cd = p_loc_cd
     AND pm.parent_group = :GLOBAL.parent_group
     AND pm.comp_fa = :GLOBAL.comp_fa
     AND pm.stores_cd = gm.stores_cd
     AND pm.dealer_map_cd = gm.dealer_map_cd
     AND pm.loc_cd = gm.loc_cd
     AND pm.comp_fa = gm.comp_fa
     AND pm.part_num = p_part
     and mr.part_num = p_part
     and mr.batch_num = (select max(batch_num)
                         from pi_pm_part_mrp rp
                         where rp.part_num = p_part))
     WHERE :CB_DUMMY.STOCK_CHK = 'N';       

BEGIN
/* -- Commented by Rajeev on 02-02-2013, now always search on root part number.
   -- If user enter part number then first find root part number of parts and then populate detaisl according to root part number.
	if :cb_dummy.part_num is not null and :cb_dummy.root_part_num is null then 
      
      FOR c IN c_stock1
      LOOP
            :b_pm_stock.loc_cd := p_loc_cd;
            :b_pm_stock.dealer_map_cd := p_dealer;
            :b_pm_stock.stores_cd := c.stores_cd;
            :b_pm_stock.nb_stores_desc := c.stores_desc;
            --:b_pm_stock.nb_curr_stock := c.stock; -- Commented By Rajeev 

        -- Below block Added by Rajeev    
            :b_pm_stock.nb_curr_stock := GET_PART_NET_STOCK(p_dealer, p_loc_cd, c.part_num, 'P'); 
      	BEGIN
      		SELECT part_desc, root_part_num
      		  INTO :b_pm_stock.nb_part_desc, :b_pm_stock.nb_root_part
      		  FROM pm_part
      		 WHERE dealer_map_cd in (1,p_dealer)
      		   AND part_num = c.part_num;
      	EXCEPTION WHEN OTHERS THEN
      		NULL;
      	END;	

      	-- End Block
	
            :b_pm_stock.alloc_qty := c.alloc_qty;
            :b_pm_stock.nb_float_stock := c.float_stock;
            :b_pm_stock.nb_loc_desc := p_loc_desc;
            :b_pm_stock.dealer_name := p_dealer_name;
            :b_pm_stock.part_num := c.part_num;
            next_record;
      END LOOP;
	END if;
	
	if :cb_dummy.part_num is null and :cb_dummy.root_part_num is not null then
	
		 FOR c IN c_stock2
      LOOP
            :b_pm_stock.loc_cd := p_loc_cd;
            :b_pm_stock.dealer_map_cd := p_dealer;
            :b_pm_stock.stores_cd := c.stores_cd;
            :b_pm_stock.nb_stores_desc := c.stores_desc;
            --:b_pm_stock.nb_curr_stock := c.stock; -- Commented By Rajeev 
	
        -- Below block Added by Rajeev    
            :b_pm_stock.nb_curr_stock := GET_PART_NET_STOCK(p_dealer, p_loc_cd, c.part_num, 'P'); 
      	BEGIN
      		SELECT part_desc, root_part_num
      		  INTO :b_pm_stock.nb_part_desc, :b_pm_stock.nb_root_part
      		  FROM pm_part
      		 WHERE dealer_map_cd in (1,p_dealer)
      		   AND part_num = c.part_num;
      	EXCEPTION WHEN OTHERS THEN
      		NULL;
      	END;	
	
      	-- End Block
	
            :b_pm_stock.alloc_qty := c.alloc_qty;
            :b_pm_stock.nb_float_stock := c.float_stock;
            :b_pm_stock.nb_loc_desc := p_loc_desc;
            :b_pm_stock.dealer_name := p_dealer_name;
            :b_pm_stock.part_num := c.part_num;
            next_record;
      END LOOP;
	END if; 
	
		if :cb_dummy.part_num is not null and :cb_dummy.root_part_num is not null then
	
		 FOR c IN c_stock3
      LOOP
            :b_pm_stock.loc_cd := p_loc_cd;
            :b_pm_stock.dealer_map_cd := p_dealer;
            :b_pm_stock.stores_cd := c.stores_cd;
            :b_pm_stock.nb_stores_desc := c.stores_desc;
            --:b_pm_stock.nb_curr_stock := c.stock; -- Commented By Rajeev 
	
        -- Below block Added by Rajeev    
            :b_pm_stock.nb_curr_stock := GET_PART_NET_STOCK(p_dealer, p_loc_cd, c.part_num, 'P'); 
      	BEGIN
      		SELECT part_desc, root_part_num
      		  INTO :b_pm_stock.nb_part_desc, :b_pm_stock.nb_root_part
      		  FROM pm_part
      		 WHERE dealer_map_cd in (1,p_dealer)
      		   AND part_num = c.part_num;
      	EXCEPTION WHEN OTHERS THEN
      		NULL;
      	END;	
	
      	-- End Block
	
            :b_pm_stock.alloc_qty := c.alloc_qty;
            :b_pm_stock.nb_float_stock := c.float_stock;
            :b_pm_stock.nb_loc_desc := p_loc_desc;
            :b_pm_stock.dealer_name := p_dealer_name;
            :b_pm_stock.part_num := c.part_num;
            next_record;
      END LOOP;
		END if; 
*/

IF :cb_dummy.root_part_num IS NULL THEN
	 general.check_null(:cb_dummy.root_part_num,'Root Part Number');
	 go_item('cb_dummy.root_part_num');
	 raise form_trigger_failure;
END IF;
	IF :cb_dummy.root_part_num IS NOT NULL THEN
	  FOR cur_p IN cur_part LOOP
	    FOR cur_s IN cur_stk(cur_p.part_num) LOOP
		    :b_pm_stock.loc_cd := p_loc_cd;
		    :b_pm_stock.dealer_map_cd := p_dealer;
		    :b_pm_stock.stores_cd := cur_s.stores_cd;
		    :b_pm_stock.nb_stores_desc := cur_s.stores_desc;
		    :b_pm_stock.nb_curr_stock := cur_s.stock; 
		    :b_pm_stock.nb_part_desc := cur_p.part_desc;
		    :b_pm_stock.alloc_qty := cur_s.alloc_qty;
		    :b_pm_stock.nb_float_stock := cur_s.float_stock;
		    :b_pm_stock.nb_loc_desc := p_loc_desc;
		    :b_pm_stock.dealer_name := p_dealer_name;
		    :b_pm_stock.part_num := cur_p.part_num;
		    :b_pm_stock.part_mrp := cur_s.mrp;
		    next_record;
	    END LOOP; 
	  END LOOP;  
	END IF;	
end;
```

#### SP-002 - GENERAL.ASK_CONFIRM

**Invoked From:**

- pe_loc_stock_fmb.xml [Trigger: FT_CANCEL]

---

**Screen:**

N/A

---

**Purpose**

Presents a confirmation dialog to the user with a caller-supplied message and returns a numeric indicator of the user's response, allowing calling code to branch based on whether the user confirmed or declined the requested action.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| confirm_msg | Caller (confirmation prompt text to display to the user) | VARCHAR2 |

**Output Parameters**

No formal output parameters in source signature. Returns NUMBER (1 = confirmed, 0 = cancelled) as a function return value.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Set the message text of the `AL_CONFIRM` alert to the caller-supplied `confirm_msg` string.
- Step 2 - Display the `AL_CONFIRM` alert to the user and capture which button was pressed.
- Step 3 - If the user pressed the first button (`ALERT_BUTTON1`), return `1` to the caller to indicate confirmation.
- Step 4 - If the user pressed any other button (i.e., not `ALERT_BUTTON1`), return `0` to the caller to indicate cancellation or rejection.

---

**Decision Points**

DP-001

Condition:
The button pressed on the `AL_CONFIRM` alert equals `ALERT_BUTTON1`.

TRUE:
Return `1` - the user confirmed the action.

FALSE:
Return `0` - the user declined or dismissed the dialog without confirming.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - Only pressing the first alert button (`ALERT_BUTTON1`) is treated as a positive confirmation; all other responses (second button, third button, or dismiss) are treated as cancellation.
- SBR-002 - The confirmation message shown to the user is determined entirely by the caller via `confirm_msg`, making this a reusable generic confirmation utility.

---

**Implementation Logic**

```plsql
FUNCTION ASK_CONFIRM( confirm_msg VARCHAR2)
                                      RETURN  NUMBER IS

    p_alert_name varchar2(10) := 'AL_CONFIRM' ;
    p_albtn_pressed number;
BEGIN
   set_alert_property(p_alert_name,alert_message_text,confirm_msg); 
   p_albtn_pressed := show_alert(p_alert_name);

   IF ( p_albtn_pressed = ALERT_BUTTON1 ) THEN
      return (1);
   ELSE
      return(0);
   END IF;
RETURN NULL; END;
```

#### SP-003 - GENERAL.CHECK_FORM_FAILURE

**Invoked From:**

- pe_loc_stock_fmb.xml [Trigger: KEY-COMMIT]

---

**Screen:**

N/A

---

**Purpose**

Inspects the Oracle Forms success status after a form operation and, if the operation failed, retrieves and displays the relevant error message (Oracle database error or Forms runtime error) to the user before halting further trigger processing.

---

**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Check the Oracle Forms built-in `FORM_SUCCESS` function to determine whether the most recent form operation completed successfully.
- Step 2 - If the form operation was not successful, inspect the `ERROR_TYPE` built-in to identify the category of failure.
- Step 3 - If `ERROR_TYPE = 'ORA'` (an Oracle database error), call `GENERAL.DISP_TEXT` with `SQLERRM` as the message text and `'Error'` as the title to display the Oracle error message.
- Step 4 - If `ERROR_TYPE = 'FRM'` (an Oracle Forms runtime error), call `GENERAL.DISP_TEXT` with the built-in `ERROR_TEXT` as the message text and `'Error'` as the title to display the Forms error message.
- Step 5 - After displaying the error message, raise `FORM_TRIGGER_FAILURE` to halt the trigger that called this procedure.
- Step 6 - If `FORM_SUCCESS` is true, the procedure exits without taking any action.

---

**Decision Points**

DP-001

Condition:
`FORM_SUCCESS` returns FALSE (the most recent form operation did not succeed).

TRUE:
Identify the error type and display the appropriate error message, then raise `FORM_TRIGGER_FAILURE`.

FALSE:
The procedure exits silently - no message is displayed and processing continues normally.

DP-002

Condition:
`ERROR_TYPE = 'ORA'` (the failure is an Oracle database error).

TRUE:
Display `SQLERRM` (the Oracle error message) via `GENERAL.DISP_TEXT` with title `'Error'`.

FALSE:
Evaluate whether `ERROR_TYPE = 'FRM'` (a Forms runtime error) and if so, display `ERROR_TEXT` via `GENERAL.DISP_TEXT` with title `'Error'`.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - Any failed form operation (indicated by `NOT FORM_SUCCESS`) must be reported to the user before trigger processing is allowed to continue.
- SBR-002 - Oracle database errors (`ERROR_TYPE = 'ORA'`) are presented using the Oracle-provided `SQLERRM` message text.
- SBR-003 - Oracle Forms runtime errors (`ERROR_TYPE = 'FRM'`) are presented using the Forms-provided `ERROR_TEXT` message text.

---

**Implementation Logic**

```plsql
PROCEDURE CHECK_FORM_FAILURE IS
BEGIN
 IF (NOT form_success) THEN
     IF ERROR_TYPE = 'ORA' THEN
        GENERAL.disp_text(SQLERRM,'Error');
     ELSIF ERROR_TYPE = 'FRM' THEN
        GENERAL.disp_text(ERROR_TEXT,'Error');
     END IF;
     raise form_trigger_failure;
  END IF; 

END;
```

#### SP-004 - GENERAL.CHECK_NULL

**Invoked From:**

- pe_loc_stock_fmb.xml [ProgramUnit: POP_STOCK_DETAILS]
- pe_loc_stock_fmb.xml [StoredProcedure: POP_STOCK_DETAILS]

---

**Screen:**

PART DETAILS (N/A / CN_MAIN)

---

**Purpose**

Validates that a required field value is not null and, if it is, displays a user-readable error message identifying the offending field by name and raises a form trigger failure to halt further processing.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| P_value | Caller (value to check for null - typically a field value from the form) | VARCHAR2 |
| column_title | Caller (business label of the field being validated, used in the error message) | VARCHAR2 |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Construct the error message text as `'Enter a valid ' || column_title`, embedding the supplied field name so the user knows which field is blank.
- Step 2 - Check whether `P_value` is NULL.
- Step 3 - If `P_value` is NULL, call `GENERAL.DISP_TEXT` with the constructed message and the severity title `'Error'` to display the alert to the user, then raise `FORM_TRIGGER_FAILURE` to stop processing.
- Step 4 - If `P_value` is not NULL, the procedure completes without action - the value is considered present and no message is shown.

---

**Decision Points**

DP-001

Condition:
The supplied field value (`P_value`) is NULL.

TRUE:
Display an error alert with the message "Enter a valid \<column_title\>" and raise `FORM_TRIGGER_FAILURE` to halt the current trigger.

FALSE:
No action is taken; the procedure exits normally, allowing the caller to continue.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - Every field passed to this procedure is treated as mandatory; a NULL value is unconditionally rejected with an error message that names the field.
- SBR-002 - The error message always follows the pattern `'Enter a valid <field name>'`, where the field name is provided by the caller via `column_title`.

---

**Implementation Logic**

```plsql
PROCEDURE CHECK_NULL( P_value IN VARCHAR2, column_title  IN VARCHAR2) IS
mesg_text        varchar2(80) := 'Enter a valid '||column_title ;
BEGIN
   IF p_value IS null  THEN
      GENERAL.DISP_TEXT(mesg_text,'Error');
      raise form_trigger_failure;
   END IF;
END;
```

#### SP-005 - GENERAL.DISP_TEXT

**Invoked From:**

- DPL.pld [StoredProcedure: GENERAL.CHECK_FORM_FAILURE]
- DPL.pld [StoredProcedure: GENERAL.CHECK_NULL]
- DPL.pld [StoredProcedure: GENERAL.RAISE_ERROR]
- pe_loc_stock_fmb.xml [Trigger: ON-ERROR]
- pe_loc_stock_fmb.xml [Trigger: ON-MESSAGE]
- pe_loc_stock_fmb.xml [Trigger: WHEN-CHECKBOX-CHANGED]
- pe_loc_stock_fmb.xml [Trigger: WHEN-NEW-BLOCK-INSTANCE]

---

**Screen:**

PART DETAILS (N/A / CN_MAIN)

---

**Purpose**

Displays a message to the user through a named Oracle Forms alert, routing the message to either an error alert (`AL_ERRINFO`) or a note/informational alert (`AL_NOTE`) based on the supplied title, so that all form-level notifications are shown through a consistent, styled dialog.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| text_string | Caller (the message text to display in the alert) | VARCHAR2 |
| title_string | Caller (the alert title; if it equals 'Error' the error alert is used, otherwise the informational alert) | VARCHAR2 |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Default the alert name to `'AL_ERRINFO'` (error alert).
- Step 2 - Evaluate the `title_string` parameter (case-insensitively): if it equals `'ERROR'`, keep the alert name as `'AL_ERRINFO'`; otherwise set the alert name to `'AL_NOTE'` (informational alert).
- Step 3 - Set the selected alert's title property to the value of `title_string`.
- Step 4 - Set the selected alert's message-text property to the value of `text_string`.
- Step 5 - Display the alert to the user by calling `SHOW_ALERT` and capture the button pressed (the return value is stored but not acted upon further within this procedure).

---

**Decision Points**

DP-001

Condition:
`UPPER(title_string) = 'ERROR'`

TRUE:
Use the `AL_ERRINFO` alert (error styling) to present the message.

FALSE:
Use the `AL_NOTE` alert (informational/note styling) to present the message.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - All error-severity messages (where `title_string` is `'ERROR'`, case-insensitive) are presented through the `AL_ERRINFO` alert; all other messages (notes, cautions, confirmations routed here) are presented through `AL_NOTE`.
- SBR-002 - The alert title and message text are always set dynamically from the caller's arguments, ensuring the displayed text precisely matches the context in which the alert is invoked.

---

**Implementation Logic**

```plsql
PROCEDURE DISP_TEXT (text_string VARCHAR2,
                     title_string VARCHAR2 ) IS 
   p_alert_name varchar2(10) := 'AL_ERRINFO' ; 
   p_alert_id number;
BEGIN
   if upper(title_string)='ERROR' then
      p_alert_name := 'AL_ERRINFO' ; 
   else
      p_alert_name := 'AL_NOTE' ; 
   end if;
   set_alert_property(p_alert_name,TITLE,title_string);  
   set_alert_property(p_alert_name,alert_message_text,text_string);  
   p_alert_id := show_alert(p_alert_name); 
END;
```

#### SP-006 - GENERAL.L_POP_LIST_ITEM

**Invoked From:**

- pe_loc_stock_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

PART DETAILS (N/A / CN_MAIN)

---

**Purpose**

Creates (or recreates) a named record group from a caller-supplied SQL query and populates it with fresh data, providing a reusable mechanism for dynamically loading list-of-values data into Oracle Forms record groups at runtime.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| p_rg_name | Caller (the name to assign to the record group being created or recreated) | VARCHAR2 |
| p_select | Caller (the SQL SELECT query used to populate the record group with data) | VARCHAR2 |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Attempt to locate an existing record group with the name supplied in `p_rg_name` using `FIND_GROUP`.
- Step 2 - If the record group already exists (i.e., `ID_NULL` returns FALSE for the found group ID), delete it with `DELETE_GROUP` to ensure a clean slate before recreating it.
- Step 3 - Create a new record group with the name `p_rg_name` and the SQL query `p_select` using `CREATE_GROUP_FROM_QUERY`.
- Step 4 - Populate the newly created record group by executing the query via `POPULATE_GROUP`, capturing the error code in `errcode`.

---

**Decision Points**

DP-001

Condition:
A record group named `p_rg_name` already exists in the form (i.e., `FIND_GROUP` returns a non-null ID).

TRUE:
Delete the existing record group with `DELETE_GROUP` before creating a new one, preventing duplicate group definitions.

FALSE:
No existing group to delete; proceed directly to creating the new record group.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - If a record group with the given name already exists, it must be deleted before a new one is created; this prevents stale data from persisting in the group across successive calls.
- SBR-002 - The SQL query used to build and populate the record group is determined entirely by the caller via `p_select`, making this a generic, reusable utility.

---

**Implementation Logic**

```plsql

PROCEDURE l_pop_list_item (p_rg_name VARCHAR2,p_select VARCHAR2 )IS

	 rg_name VARCHAR2(40) := p_rg_name;
	 rg_id RecordGroup;
	 errcode NUMBER; 
BEGIN 
	/* ** Make sure group doesn't already exist */ 
	rg_id := Find_Group( rg_name ); 

	IF NOT Id_Null(rg_id) THEN 
		delete_group(rg_id);
	END IF;
	/* ** If it does not exist, create it and add the two ** necessary columns to it. */ 
		rg_id := Create_Group_From_Query( rg_name, p_select); 
	 
	/* ** Populate the record group */ 
	errcode := Populate_Group( rg_id );
END;
```

#### SP-007 - GENERAL.RAISE_ERROR

**Invoked From:**

- pe_loc_stock_fmb.xml [Trigger: ON-ERROR]

---

**Screen:**

N/A

---

**Purpose**

Receives a message code, formats it into a display string, and presents it to the user through a severity-appropriate alert (error, note, or caution), halting trigger processing when the message is of error severity.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| mesg_code | Caller (the business error code to look up and display, e.g. 'E0088' for foreign-key constraint violations) | VARCHAR2 |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Construct the display message text by concatenating `mesg_code`, the literal `' : '`, and `mesg_text` (note: the `GENERAL.get_message` call that would populate `mesg_text` and `mesg_type` is commented out, so `mesg_text` and `mesg_type` remain NULL/default at runtime).
- Step 2 - Evaluate `mesg_type` to determine the alert severity and presentation path.
- Step 3 - If `mesg_type = 'E'` (error), set the title to `'Error'`, call `GENERAL.DISP_TEXT` to display the message, and raise `FORM_TRIGGER_FAILURE` to halt processing.
- Step 4 - If `mesg_type = 'N'` (note), set the title to `'Note'` and call `GENERAL.DISP_TEXT` to display the message without raising a failure.
- Step 5 - If `mesg_type = 'C'` (caution), set the title to `'Caution'` and call `GENERAL.DISP_TEXT` to display the message without raising a failure.

---

**Decision Points**

DP-001

Condition:
`mesg_type = 'E'` (the message is of error severity).

TRUE:
Display the message with title `'Error'` via `GENERAL.DISP_TEXT` and raise `FORM_TRIGGER_FAILURE` to stop trigger execution.

FALSE:
Evaluate further severity levels (note or caution).

DP-002

Condition:
`mesg_type = 'N'` (the message is informational).

TRUE:
Display the message with title `'Note'` via `GENERAL.DISP_TEXT`; processing continues after the alert is dismissed.

FALSE:
Evaluate whether `mesg_type = 'C'` (caution).

DP-003

Condition:
`mesg_type = 'C'` (the message is a caution).

TRUE:
Display the message with title `'Caution'` via `GENERAL.DISP_TEXT`; processing continues after the alert is dismissed.

FALSE:
No alert is displayed; the procedure exits silently (no matching severity branch).

---

**Database Interactions**

- DB-001 - Read am_permissions - referenced only within the commented-out `check_rights` procedure body; this interaction is inactive in the live code and does not execute at runtime.

---

**Business Rules**

- SBR-001 - Error-severity messages (`mesg_type = 'E'`) always halt the calling trigger via `FORM_TRIGGER_FAILURE`; note and caution messages do not interrupt processing.
- SBR-002 - The message displayed to the user always includes the raw `mesg_code` as a prefix (concatenated with `' : '`), ensuring the code is visible even when the descriptive text cannot be resolved.

---

**Implementation Logic**

```plsql
PROCEDURE RAISE_ERROR ( mesg_code IN VARCHAR2 )IS
  mesg_type  varchar2(7); 
  mesg_text  varchar2(200) ;
  mesg_title varchar2(7);
  BEGIN
     -- murali 17.05.04 GENERAL.get_message(mesg_code,mesg_text,mesg_type );
     mesg_text:=mesg_code||' : '||mesg_text;		
     IF ( mesg_type = 'E' ) THEN
        mesg_title := 'Error' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
        raise FORM_TRIGGER_FAILURE;
     ELSIF ( mesg_type = 'N' ) THEN
        mesg_title := 'Note' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     ELSIF ( mesg_type = 'C' ) THEN
        mesg_title := 'Caution' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     END IF;
  END;     

/* PROCEDURE check_rights( 
pi_form_name in varchar2,
pi_user_id in number) IS
lv_x varchar2(1);
BEGIN
	
	begin
	SELECT substr(access_string, pi_user_id,1) 
	INTO   lv_x
	FROM   	am_permissions
	WHERE  form_name = pi_form_name
	AND SUBSTR(access_string,pi_user_id,1)='Y';
	exception 
		when no_data_found then
		  general.disp_text('You do not have the Permission to access this.','Error rr');
		  raise form_trigger_failure; 
		when too_many_rows then
		  general.disp_text('Many rows in USER_PERMISSIONS','Error ss');
		  raise form_trigger_failure;
		when others then
		       general.disp_text(sqlerrm,'Error mm');
		       raise form_trigger_failure;
	end;

	open_form(pi_form_name,activate,session);
END;
*/
```

#### SP-008 - SF_COPYRIGHT_DECLARATION

**Invoked From:**

- pe_loc_stock_fmb.xml [Trigger: KEY-CLRFRM]
- pe_loc_stock_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

PART DETAILS (N/A / CN_MAIN)

---

**Purpose**

Returns a formatted copyright string for Maruti Suzuki India Limited, adjusted to display the correct financial year: January through March are attributed to the previous calendar year (reflecting the April-March Indian financial year), while April through December use the current calendar year.

---

**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Capture the current date using `SYSDATE`.
- Step 2 - Extract the month abbreviation from the current date and check whether it falls in January, February, or March.
- Step 3 - If the month is January, February, or March, construct the copyright string using the previous calendar year (current year minus 1), reflecting that the financial year started in April of the prior year.
- Step 4 - If the month is April through December, construct the copyright string using the current calendar year.
- Step 5 - Return the formatted string in the form `'© <year> Maruti Suzuki India Limited '`.

---

**Decision Points**

DP-001

Condition:
The current month (from `SYSDATE`) is January, February, or March.

TRUE:
Use the previous calendar year (`current year - 1`) in the copyright string, as these months fall within the financial year that began the previous April.

FALSE:
Use the current calendar year in the copyright string (months April through December).

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The copyright year is based on the Indian financial year (April-March): months January, February, and March are attributed to the financial year that started in the previous calendar year.
- SBR-002 - The copyright notice always identifies "Maruti Suzuki India Limited" as the rights holder.

---

**Implementation Logic**

```plsql
CREATE OR REPLACE
function sf_copyright_declaration return varchar is
a varchar2(50);
dt date;
begin
--Modified by Prerna on 16-May-11  to display current Financial Year Copyright
dt := sysdate;

    if( to_char(dt,'MON') in ('JAN','FEB','MAR')) then
        a := '© '||to_char(to_number(to_char(dt,'RRRR')) - 1)||' Maruti Suzuki India Limited ';
    else
        a := '© '||to_char(dt,'RRRR')||' Maruti Suzuki India Limited ';
    end if;
return(a);
end;
```

---

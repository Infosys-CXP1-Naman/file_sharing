# BUSINESS REQUIREMENTS DOCUMENT

## Table of Contents

- 1. Document Control
  - 1.1 Document Information
  - 1.2 Revision History
- 2. Executive Summary
  - Key Stakeholders
- 3. System Context
- 4. Functional Requirements
  - 4.1 Business Requirements
    - Requirement ID: BR-001
    - Requirement ID: BR-002
    - Requirement ID: BR-003
    - Requirement ID: BR-004
    - Requirement ID: BR-005
    - Requirement ID: BR-006
    - Requirement ID: BR-007
- 5. Business Rules Catalogue
- 6. Data Requirements
  - 6.1 Business Entities and Relationships
    - Repair Orders - VH_RO
    - Employee Master - GM_EMP (via SF_GET_EMP_NAME)
    - Vehicle Technical Services Detail - VT_VTS (via PKG_VTS_BODYSHOP.SF_GET_PANEL)
    - Working Day Register - WD_BTN (via PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT)
    - Entity Relationships
  - 6.2 Data Capture Requirements
    - Query Filter - date range entered by the user before running the search
    - Productivity Results Display - system-populated per-technician results after search
    - Session and Global Parameters - passed at session level, not entered on screen
  - 6.3 Reference Data
  - 6.4 Data Lifecycle
  - 6.5 Excel Output Columns
- 7. Glossary
- 8. Technical Inventory
  - 8.1 Form Architecture
    - 8.1.1 Global Variables
    - 8.1.2 Form Parameters
  - 8.2 Blocks
    - 8.2.1 Block WhereClause and OrderByClause
  - 8.3 Items Summary
  - 8.4 List of Values
  - 8.5 Alerts
  - 8.6 Program Units
  - 8.7 Triggers
    - 8.7.1 Inactive / Commented-Out Trigger Register
  - 8.8 Canvas and Window Inventory
  - 8.9 Editors
  - 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups
    - 8.10.1 Visual Attributes (form-defined)
    - 8.10.2 Property Classes (form-defined)
    - 8.10.3 Object Groups
  - 8.11 DataSourceColumn Inventory
- 9. Object Library
- 10. Record Groups
- 11. Referenced Database Objects
- 12. Backend Procedures and Packages
  - 12.1 Main Flow Backend Procedure/Package Index
  - 12.2 Procedure and Package Catalogue
    - PKG_VTS_BODYSHOP
    - SF_GET_EMP_NAME
    - VIEW_EXCEL_REP
    - DBMS_APPLICATION_INFO
    - WEB
    - GENERAL (DPL.pld)
    - GENERAL - Inactive / Commented-Only Routines (DPL.pld)
    - WEBUTIL_CORE (webutil.pld)
    - WEBUTIL (webutil.pld - WEBUTIL_C_API)
    - D2KWUTIL
    - SET_GLOBAL (Form Program Unit - active, no active callers)
- 13. Package Procedure Specifications
- 14. Database Package Catalogue
- 15. PLD Procedure Call Sites
  - DPL.pld (`general`)
  - Inactive / commented-only PLD call sites
  - webutil.pld (`WEBUTIL_CORE`)
  - webutil.pld (`WEBUTIL_C_API`)
- 16. Microservice API Candidates
  - 16.1 Microservices with APIs
- 17. Workflows
- 18. PLD-Backed Logic
  - webutil.pld (`CLIENT_IMAGE`)
  - DPL.pld (`general`)
  - D2kwutil.pld (`Win_API`)
- 19. PCK-Backed Logic
- 20. System Interfaces
  - 20.1 Database Integrations
  - 20.2 External System Integrations
  - 20.3 Report Integrations
    - 20.3.1 Parameters Passed to the Report
- 21. Procedure and Function Business Rule Catalogue
  - 21.1 Catalogue Index
  - 21.2 Detailed Specifications
    - SP-001 - VIEW_EXCEL_REP
    - SP-002 - D2KWUTIL.ATTEMPT_DLL_LOAD
    - SP-003 - D2KWUTIL.D2KWUTIL_DEBUGSTRING
    - SP-004 - D2KWUTIL.D2KWUTIL_GETDOSENV
    - SP-005 - D2KWUTIL.D2KWUTIL_GETREGKEY
    - SP-006 - D2KWUTIL.TRANSLATETYPE
    - SP-007 - GENERAL.ASK_CONFIRM
    - SP-008 - GENERAL.CHECK_FORM_FAILURE
    - SP-009 - GENERAL.DISP_TEXT
    - SP-010 - PKG_VTS_BODYSHOP.SF_GET_PANEL
    - SP-011 - PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT
    - SP-012 - WEBUTIL.BLOCKING
    - SP-013 - WEBUTIL.CHECKLIBS
    - SP-014 - WEBUTIL.CLEARCALLBACKTRIGGER
    - SP-015 - WEBUTIL.CLOSEBLOB
    - SP-016 - WEBUTIL.CLOSEFILE
    - SP-017 - WEBUTIL.DOWNLOADFROMURLINT
    - SP-018 - WEBUTIL.ERROR
    - SP-019 - WEBUTIL.ERRORALERT
    - SP-020 - WEBUTIL.EXECUTE
    - SP-021 - WEBUTIL.FCLOSE
    - SP-022 - WEBUTIL.FOPEN
    - SP-023 - WEBUTIL.GETCALLBACKTRIGGER
    - SP-024 - WEBUTIL.GETCLIENTOSFAMILY
    - SP-025 - WEBUTIL.GETCLIENTSETTING
    - SP-026 - WEBUTIL.GETIMPLCLASS
    - SP-027 - WEBUTIL.GETLASTERROR
    - SP-028 - WEBUTIL.GETLASTERRORARGS
    - SP-029 - WEBUTIL.GETNUMBER
    - SP-030 - WEBUTIL.GETOSFAMILY
    - SP-031 - WEBUTIL.GETOUTPUT
    - SP-032 - WEBUTIL.GETPROPERTY
    - SP-033 - WEBUTIL.GETSTRING
    - SP-034 - WEBUTIL.GETVAR
    - SP-035 - WEBUTIL.GET_LINE
    - SP-036 - WEBUTIL.GET_STANDARD_OUTPUT
    - SP-037 - WEBUTIL.ID_NULL
    - SP-038 - WEBUTIL.INIT
    - SP-039 - WEBUTIL.INITWEBUTIL
    - SP-040 - WEBUTIL.ISERROR
    - SP-041 - WEBUTIL.IS_OPEN
    - SP-042 - WEBUTIL.LENGTH
    - SP-043 - WEBUTIL.LOG
    - SP-044 - WEBUTIL.POPULATEPROPERTYBUNDLE
    - SP-045 - WEBUTIL.PUT_LINE
    - SP-046 - WEBUTIL.READFROMPROPERTYBUNDLE
    - SP-047 - WEBUTIL.READTRANSFROMMSGBUNDLE
    - SP-048 - WEBUTIL.REGISTERBEAN
    - SP-049 - WEBUTIL.REGISTER_FUNCTION
    - SP-050 - WEBUTIL.RELEASE_PROCESS
    - SP-051 - WEBUTIL.SETCLIENTSETTING
    - SP-052 - WEBUTIL.SETDATA
    - SP-053 - WEBUTIL.SETPROPERTY
    - SP-054 - WEBUTIL.SHOWBEANS
    - SP-055 - WEBUTIL.WRITEDATA
    - SP-056 - WEBUTIL_CORE.CUSTOMEVENTHANDLER
    - SP-057 - ADD_ERROR
    - SP-058 - ADD_EXTERNAL_ERRORS
    - SP-059 - BOOLTOCHAR
    - SP-060 - CLEAN_ERROR_STACK
    - SP-061 - DEBUGLOG
    - SP-062 - GET_ENVIRONMENT_STRING
    - SP-063 - READ_REGISTRY
    - SP-064 - REGISTER_FUNCTION_CALL
    - SP-065 - SETDEBUG
    - SP-066 - SF_GET_EMP_NAME
    - SP-067 - STRIPDIRSEP
    - SP-068 - WINDEBUG

## 1. Document Control

### 1.1 Document Information

| Field | Value |
| ----- | ----- |
| Document Title | VR_BODYSHOP_TECH_PROD - Business Requirements Document |
| Form Module Name | VR_BODYSHOP_TECH_PROD |
| Document Version | 1.0 |
| Date Created | August 13, 2026 |
| Author/Prepared By | BRD Agent |

### 1.2 Revision History

| Version | Date | Author | Description |
| --- | --- | --- | --- |
| 1.0 | August 13, 2026 | BRD Agent | Initial draft |

---

## 2. Executive Summary

*High-level overview of the vr_bodyshop_tech_prod Bodyshop Technician Productivity form, its purpose, and roles referenced in the module.*

The **vr_bodyshop_tech_prod** module is the dealership **Bodyshop Technician Productivity** screen. A service manager or operations analyst opens the screen, enters a billing date range of up to one month, and clicks Search to view a per-technician breakdown of bodyshop output: how many working days were available in the period, how many vehicles each technician repaired, how many body panels each technician handled, and the resulting productivity ratios. The screen enforces date validation rules - the from date is mandatory, neither date may be in the future, and the range is capped at 31 days. Once results are displayed, the user may export the full dataset to a CSV file by clicking **Export to Excel**, which builds the report and opens it in the browser for download. The form does not allow data entry or modification; it is a read-only productivity reporting tool.

### Key Stakeholders

*Who uses vr_bodyshop_tech_prod*

| Stakeholder | Role |
| :--- | :--- |
| **Service Manager / Operations Analyst** | **Primary interactive user** of vr_bodyshop_tech_prod. Opens the screen, enters the billing date range, initiates the search, reviews per-technician productivity results, and exports the report to Excel when required. |
| **Bodyshop Technician** | Work output subject - vehicle repairs, panels, and labour amounts attributed to each technician are displayed in the report; technicians do not use the form directly. |

---

---

## 3. System Context

*Describes the vr_bodyshop_tech_prod module's role within the DMS ecosystem, scope, process flow, and key integrations.*

The **vr_bodyshop_tech_prod** module is the dealership **Bodyshop Technician Productivity** reporting screen within the Vehicle Tracking System (VTS) component of the Dealer Management System (DMS). It provides management with a per-technician view of bodyshop output over a selected billing period, drawing data from completed repair orders and the location's working-day calendar. The results support operational oversight and performance reviews of bodyshop staff.

**System purpose:** Allow a service manager to define a billing date range, retrieve per-technician productivity metrics (working days, vehicles repaired, panels handled, and calculated productivity ratios) from bodyshop repair order data, and optionally export the results to a CSV file - as implemented in the vr_bodyshop_tech_prod Oracle Forms module.

**In scope:**

- Enter and validate a billing date range (from date mandatory, neither date in the future, range capped at 31 days)
- Retrieve per-technician bodyshop productivity metrics for the selected period and dealership/location scope
- Display working-day count, vehicle repair count, panel count, and productivity ratios per technician
- Display summary averages across all technicians for each metric
- Export the productivity results to a CSV file opened in the browser

**Process Name:** Bodyshop Technician Productivity Reporting

**Process Owner:** Service Manager / Operations Analyst

**Process Objective:** Enter a valid billing date range, retrieve and display per-technician bodyshop productivity data, and optionally export the results to CSV.

**Process Trigger:** A service manager or operations analyst opens the Bodyshop Technician Productivity screen to review staff output for a completed billing period.

**Process Flow:**

The complete bodyshop technician productivity reporting process follows this sequence. Each step corresponds to Functional Requirements in Section 4.

```
STEP 1 ── SCREEN OPENS
         The user opens the vr_bodyshop_tech_prod form.
         Session context is registered; the query block is presented with blank date fields.

STEP 2 ── ENTER FROM BILL DATE
         User enters the start of the billing period in the From Bill Date field.
         System validates: date must not be null and must not be in the future.
         ├── NULL entered: alert shown, navigation blocked.
         └── Future date entered: alert shown, navigation blocked.

STEP 3 ── NAVIGATE TO TO BILL DATE
         User tabs from From Bill Date; focus moves automatically to the To Bill Date field.

STEP 4 ── ENTER TO BILL DATE
         User enters the end of the billing period in the To Bill Date field.
         System validates: date must not be in the future, must not be before From Bill Date,
         and the range must not exceed 31 days.
         ├── Future date entered: alert shown, navigation blocked.
         ├── Date before From Bill Date: alert shown, navigation blocked.
         └── Range exceeds 31 days: alert shown, focus returned to To Bill Date.

STEP 5 ── CLICK SEARCH
         User clicks the Search button.
         System re-validates that To Bill Date is not in the future and not before From Bill Date
         before executing the query.

STEP 6 ── PRODUCTIVITY QUERY EXECUTED
         System queries completed bodyshop repair orders (category BANDP) for the
         selected dealer, location, and parent group within the billing date range.
         Working-day count is retrieved from the dealership holiday calendar.

STEP 7 ── RESULTS DISPLAYED
         The CB_DOC block is populated with one row per technician showing:
         technician name, working days, job card count, panel count, technician
         vehicle productivity, and panel productivity.

STEP 8 ── SUMMARY AVERAGES DISPLAYED
         Average values for working days, panels, vehicles repaired, labour productivity,
         and panel productivity are calculated and displayed below the technician rows.

STEP 9 ── USER REVIEWS RESULTS
         User reviews the per-technician and summary productivity data on screen.

STEP 10 ── EXPORT TO EXCEL (optional)
          User clicks the Export to Excel button.
          System builds a dynamic CSV query for the same productivity dataset and
          calls the export procedure.

STEP 11 ── CSV FILE GENERATED
          The export procedure creates a record group from the query, writes the
          results to a CSV file on the server, and opens the file in the browser.
          ├── Row count exceeds 65,535: file is truncated and user is notified.
          └── Normal: full dataset is written and the file is opened for download.

STEP 12 ── SESSION EXIT
          User presses the Exit key; session context and pagination globals are cleared
          before the form closes.
```

**Major process interactions:**

- **Repair order data (VH_RO)** - source of technician assignments, vehicle counts, labour amounts, and billing dates for the productivity query
- **VTS panel tracking (VT_VTS)** - provides the panel count for each repair order via the bodyshop package
- **Working-day calendar (WD_BTN)** - supplies holiday records used to calculate the number of productive working days in the selected period
- **DMS session context** - application info is set at form open and cleared at exit to support session monitoring

---

---

## 4. Functional Requirements

### 4.1 Business Requirements

#### Requirement ID: BR-001

**Requirement Title:** Form Initialization and Session Context Registration

**Business Description:**
When the Bodyshop Technician Productivity report screen is opened, the system immediately registers the current session with the database, identifying this screen as the active module. This registration allows database administrators and monitoring tools to trace which application module is running under a given session, supporting operational visibility and troubleshooting across all active dealership sessions.

**Actors:** Service Advisor / Bodyshop Manager (any user launching the form)

**Preconditions:**
- The user has launched the Bodyshop Technician Productivity report from the dealership management system menu.

**Main Flow:**

**Step 1 - Session context is registered with the database**
As soon as the form opens, the system records the module name `vr_bshop_tech_prod` and clears any prior action label for this session in the database's session tracking registry. This happens automatically before the user sees the screen, ensuring that every active session is identifiable in the database monitoring layer by the module that owns it.

*Business outcomes (errors, warnings, success, and status):*
- **BR-001-IC-01** - `module_name = 'vr_bshop_tech_prod'` - the session is registered under the Bodyshop Technician Productivity module name in the database session registry; no on-screen confirmation is shown to the user.

**Step 2 - Report description and application identity are initialised**
Immediately after session registration, the system sets the global report description to *"Technician Productivity Report(For Job Cards Billed and Punched in VTS Bodyshop)"* and writes it to the report description display field on screen. The global application identifier (`global.app_id`) is also set to `vr_bshop_tech_prod` and copied to the form parameter `p_app_id`, making both values available for downstream report and audit calls.

*Business outcomes (errors, warnings, success, and status):*
- **BR-001-IC-02** - Report description display field is populated with *"Technician Productivity Report(For Job Cards Billed and Punched in VTS Bodyshop)"*; `global.app_id` is set to `vr_bshop_tech_prod`.

**Step 3 - Main window is maximised and default date range is set**
The system maximises the MDI host window and the main application window (`WN_MAIN`) to full screen. It then calculates a default date range by setting the From Bill Date to the first day of the previous calendar month and the To Bill Date to today's date, so the user sees a pre-populated one-month range upon opening the form.

*Business outcomes (errors, warnings, success, and status):*
- **BR-001-IC-03** - Both windows are maximised; From Bill Date is defaulted to the first day of the previous month and To Bill Date is defaulted to today's date.

**Step 4 - Copyright declaration is loaded from the database**
The system queries the copyright declaration text from the database using the `SF_COPYRIGHT_DECLARATION` function and stores the result in the copyright declaration display field on screen. This field is not user-editable and is populated once at form startup.

*Business outcomes (errors, warnings, success, and status):*
- **BR-001-IC-04** - Copyright declaration field is populated with the value returned by `SF_COPYRIGHT_DECLARATION`; no user action is required.

**Step 5 - Form-wide Oracle Forms message interception is active**
Throughout the entire session, the form intercepts Oracle Forms internal messages at the form level before they are displayed to the user. When Oracle Forms raises message number `40209` (value does not meet the field's length or data type constraint) or message number `40207` (field-level validation failure), the standard Oracle Forms message is suppressed. Instead, the system displays a custom-formatted error combining the error type code, the message number, and the full error description text, then aborts the triggering action. This interception applies to all field validation events across the form for the duration of the session.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Oracle Forms message `40209` intercepted | Message code check - ON-MESSAGE form-level trigger | Whenever Oracle Forms raises message `40209` on any field in this form | Replaces the generic field-constraint message with a user-friendly custom display combining error type, code, and description | Custom error display is shown via `GENERAL.DISP_TEXT`; triggering action is aborted |
| Oracle Forms message `40207` intercepted | Message code check - ON-MESSAGE form-level trigger | Whenever Oracle Forms raises message `40207` on any field in this form | Replaces the generic field-validation message with a user-friendly custom display combining error type, code, and description | Custom error display is shown via `GENERAL.DISP_TEXT`; triggering action is aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-001-ES-01** - Oracle Forms raises message `40209` on any field - the standard message is suppressed and a custom-formatted error message composed of the error type, message number `40209`, and error description text is shown to the user; the triggering action is aborted.
- **BR-001-ES-02** - Oracle Forms raises message `40207` on any field - the standard message is suppressed and a custom-formatted error message composed of the error type, message number `40207`, and error description text is shown to the user; the triggering action is aborted.

**Alternative Flows:**
- **BR-001-AF-01** - (from Step 1) If the database session-context package call fails at startup (e.g. the database is unavailable), no session registration is completed; the form will not display further content as the pre-form stage fails.
- **BR-001-AF-02** - (from Step 4) If the `SF_COPYRIGHT_DECLARATION` query raises an exception, the copyright field remains empty; the form continues to open normally and the initialisation steps for dates and report description are unaffected.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Module Name (session context) | Auto-populated | Character | N/A | N/A | Fixed value: `vr_bshop_tech_prod` | Form launch | System-set only; not user-editable | N/A |
| Report Description (`REPORT_DESC` / `global.report_desc`) | Auto-populated | Character | Up to 200 characters | N/A | *"Technician Productivity Report(For Job Cards Billed and Punched in VTS Bodyshop)"* | Form launch | System-set at startup; not user-editable | N/A |
| Application ID (`global.app_id` / `parameter.p_app_id`) | Auto-populated | Character | N/A | N/A | Fixed value: `vr_bshop_tech_prod` | Form launch | System-set at startup; not user-editable | N/A |
| From Bill Date (`FROM_JC_BILL_DT`) | Auto-populated (default) | Date | DD-MM-RRRR | N/A | First day of previous calendar month | Form launch | System-defaulted; user may override | N/A |
| To Bill Date (`TO_BILL_DT`) | Auto-populated (default) | Date | DD-MM-RRRR | N/A | Today's date | Form launch | System-defaulted; user may override | N/A |
| Copyright Declaration (`COPYRIGHT_DECLARATION`) | Auto-populated | Character | N/A | Database - `SF_COPYRIGHT_DECLARATION` | Value returned by function | Form launch | System-set; not user-editable | Field left empty if function raises an exception |

---

---

#### Requirement ID: BR-002

**Requirement Title:** From Bill Date Entry and Validation

**Business Description:**
When a user enters the starting date of the billing period they want to report on, the system validates the date to ensure it is not blank and does not fall after today's date. Only a valid, present or past billing start date is accepted. Once the date passes validation, the cursor automatically advances to the ending date field so the user can complete the date range without manual navigation.

**Actors:** Service Advisor / Bodyshop Manager

**Preconditions:**
- The Bodyshop Technician Productivity report screen is open.

**Main Flow:**

**Step 1 - User enters the billing start date**
The user types a date value into the From Bill Date field. When the user leaves the field (tabs off or presses Enter), the system validates the entered date before allowing navigation to proceed.

**Step 2 - From Bill Date is validated**
The system checks two conditions in sequence. First, if the From Bill Date field is left empty, the system displays an alert message *"From Date can not be null"* and prevents the cursor from moving forward. Second, if a date has been entered but it is later than today's date, the system displays an alert message *"From Date cannot be greater than Current Date"* and similarly prevents navigation. Both checks abort the field-exit, returning focus to the From Bill Date field so the user can correct the entry.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| From Bill Date is not blank | Null check - WHEN-VALIDATE-ITEM on `CB_DOC_QUERY.FROM_JC_BILL_DT` | When the user leaves the From Bill Date field | Ensures a billing start date is always provided before the report range can be completed | Alert: *"From Date can not be null"*; cursor stays on the From Bill Date field |
| From Bill Date is not in the future | Future-date check - WHEN-VALIDATE-ITEM on `CB_DOC_QUERY.FROM_JC_BILL_DT` | When the user leaves the From Bill Date field (after the null check passes) | Prevents reporting on billing periods that have not yet occurred | Alert: *"From Date cannot be greater than Current Date"*; cursor stays on the From Bill Date field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-002-ES-01** - From Bill Date is blank - *"From Date can not be null"*; trigger is aborted and cursor remains on the From Bill Date field.
- **BR-002-ES-02** - From Bill Date is later than today - *"From Date cannot be greater than Current Date"*; trigger is aborted and cursor remains on the From Bill Date field.

**Step 3 - Cursor advances automatically to the To Bill Date field**
Once the From Bill Date passes both validations, the cursor moves directly to the To Bill Date field. This navigation is automatic and requires no additional user action.

**Alternative Flows:**
- **BR-002-AF-01** - (from Step 2) If the user enters an invalid date format the form's standard date-parsing error fires before this validation trigger runs; the field is not accepted and the user must re-enter a valid date.
- **BR-002-AF-02** - (Form-wide message interception) The form intercepts Oracle Forms internal message numbers `40209` (value does not meet field length or type constraint) and `40207` (field-level validation failure) wherever they arise across the form. When either code fires, the system replaces the standard Oracle Forms message with a custom-formatted error display combining the error type code, the message number, and the error text, then aborts the triggering action. This interception applies to all field validation on this form, not only the From Bill Date field.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| From Bill Date (`FROM_JC_BILL_DT`) | Mandatory | Date | DD-MM-RRRR (10 characters) | N/A | N/A | Screen is open | Must not be blank; must not be later than today's date | Alert: *"From Date can not be null"* if blank; Alert: *"From Date cannot be greater than Current Date"* if future date |

---

---

#### Requirement ID: BR-003

**Requirement Title:** To Bill Date Validation and Date Range Enforcement

**Business Description:**
When a user enters the ending date of the billing period for the productivity report, the system validates the entered date against several business rules: the ending date must not be in the future, it must not be earlier than the starting date, and the total date range must not exceed one month (31 days). If the ending date field is left blank, the system automatically defaults it to today's date. These controls ensure that the report is always generated over a meaningful and manageable date range.

**Actors:** Service Advisor / Bodyshop Manager

**Preconditions:**
- The Bodyshop Technician Productivity report screen is open.
- A valid billing start date has been entered.

**Main Flow:**

**Step 1 - User enters the billing end date**
The user types a date value into the To Bill Date field. When the user leaves the field, the system executes validations in the sequence below.

**Step 2 - To Bill Date validations are applied in sequence**
The system performs three checks in order. First, if the To Bill Date is later than today, the system shows an alert *"To Date cannot be greater than Current Date"* and aborts, returning focus to the To Bill Date field. Second, if the To Bill Date is earlier than the From Bill Date, the system shows *"To Date cannot be less than From Date"* and aborts. Third, if the difference between the To Bill Date and the From Bill Date exceeds 31 days, the system shows *"Report can be generated for maximum 1 Month"* and returns focus to the To Bill Date field.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| To Bill Date is not in the future | Future-date check - WHEN-VALIDATE-ITEM on `CB_DOC_QUERY.TO_BILL_DT` (first executable block) | When the user leaves the To Bill Date field | Prevents reporting on billing periods that have not yet closed | Alert: *"To Date cannot be greater than Current Date"*; trigger aborted; cursor returns to the To Bill Date field |
| To Bill Date is not before From Bill Date | Date-order check - WHEN-VALIDATE-ITEM on `CB_DOC_QUERY.TO_BILL_DT` (first executable block) | When the user leaves the To Bill Date field, after the future-date check passes | Ensures the report range is logically valid - end cannot precede start | Alert: *"To Date cannot be less than From Date"*; trigger aborted; cursor returns to the To Bill Date field |
| Date range does not exceed 31 days | Range-limit check - WHEN-VALIDATE-ITEM on `CB_DOC_QUERY.TO_BILL_DT` (first executable block) | When the user leaves the To Bill Date field, after the date-order check passes | Limits the report to a maximum one-month window to maintain performance and manageability | Alert: *"Report can be generated for maximum 1 Month"*; trigger aborted; cursor returns to the To Bill Date field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-ES-01** - To Bill Date is later than today - *"To Date cannot be greater than Current Date"*; trigger aborted; cursor stays on the To Bill Date field.
- **BR-003-ES-02** - To Bill Date is earlier than From Bill Date - *"To Date cannot be less than From Date"*; trigger aborted; cursor stays on the To Bill Date field.
- **BR-003-ES-03** - Date span exceeds 31 days - *"Report can be generated for maximum 1 Month"*; trigger aborted; cursor returns to the To Bill Date field.

**Step 3 - To Bill Date is defaulted to today if left blank**
After the sequential validations in Step 2, a second executable block within the same validation trigger runs: if the To Bill Date is still null at this point (i.e. the user did not enter a value and none of the above validation checks fired), the system automatically sets the To Bill Date to today's date. No alert or message is shown to the user for this defaulting action.

**Alternative Flows:**
- **BR-003-AF-01** - (from Step 1) If the user enters an invalid date format, the form's standard date-parsing error fires before this validation trigger runs; the field is not accepted and the user must re-enter a valid date.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| From Bill Date (`FROM_JC_BILL_DT`) | Mandatory | Date | DD-MM-RRRR | N/A | N/A | Screen is open | Referenced in range checks against To Bill Date | N/A (validated in BR-002) |
| To Bill Date (`TO_BILL_DT`) | Conditional - defaults to today if blank | Date | DD-MM-RRRR (10 characters) | N/A | N/A | From Bill Date is populated | Must not be in the future; must not be before From Bill Date; date span must be 31 days or fewer; defaults to today if blank | Alert per applicable check (see Business outcomes above) |

---

---

#### Requirement ID: BR-004

**Requirement Title:** Technician Productivity Search and Results Display

**Business Description:**
When the user presses the Search button, the system re-validates the selected date range and then retrieves bodyshop productivity data for all repair technicians whose repair orders were billed within the specified period. For each technician, the system displays the number of working days in the period, the number of vehicles repaired, the number of panels repaired, and the labour amount generated, together with calculated per-day productivity ratios. The results provide management with an at-a-glance view of individual technician output for the chosen billing window.

**Actors:** Service Advisor / Bodyshop Manager

**Preconditions:**
- The Bodyshop Technician Productivity report screen is open.
- Valid From Bill Date and To Bill Date values have been entered.

**Main Flow:**

**Step 1 - Date range is re-validated before the query runs**
When the Search button is pressed, the system re-checks two date-range rules: it verifies that the To Bill Date is not in the future, and that the To Bill Date is not earlier than the From Bill Date. If either check fails, the system displays the corresponding alert and moves focus to the To Bill Date field without executing the query.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| To Bill Date is not in the future | Future-date check - WHEN-BUTTON-PRESSED on `CB_DOC_QUERY.SEARCH` | When the user presses the Search button | Prevents the query from running against a billing period that has not yet occurred | Alert: *"To Date cannot be greater than Current Date"*; focus moves to the To Bill Date field; query is not executed |
| To Bill Date is not before From Bill Date | Date-order check - WHEN-BUTTON-PRESSED on `CB_DOC_QUERY.SEARCH` | When the user presses the Search button, after the future-date check passes | Ensures the date range is logically valid before querying the database | Alert: *"To Date cannot be less than From Date"*; focus moves to the To Bill Date field; query is not executed |

*Business outcomes (errors, warnings, success, and status):*
- **BR-004-ES-01** - To Bill Date is later than today at search time - *"To Date cannot be greater than Current Date"*; trigger aborted; focus moves to To Bill Date field.
- **BR-004-ES-02** - To Bill Date is earlier than From Bill Date at search time - *"To Date cannot be less than From Date"*; trigger aborted; focus moves to To Bill Date field.

**Step 2 - Technician productivity data is retrieved from billed repair orders**
The system queries all bodyshop repair orders for the current dealership and location with a billing date within the selected range and a repair category of Body and Paint. The records are grouped by the technician assigned as the service employee on each repair order. For each technician in the result set, the system retrieves the technician's full name, the count of vehicles repaired, the total number of body panels repaired across those repair orders, the total labour amount generated, and a per-day productivity ratio.

*Procedures called:*
- **SF_GET_EMP_NAME** ([SP-013](#sp-013)) - SF_GET_EMP_NAME - looks up the full display name of a technician using the dealership code, location code, and service employee code from the repair order. If no matching employee record is found, the function returns a not-available indicator.
    * **Step 1** - Accept the dealership code, location, and employee code as inputs.
    * **Step 2** - Look up the employee's first name, middle name, and last name from the employee master.
    * **Step 3** - Concatenate the available name parts in order (first, then middle if present, then last if present) to build the full display name.
    * **Step 4** - If no employee record is found for the given codes, return a not-available placeholder; otherwise return the assembled full name.
- **PKG_VTS_BODYSHOP.SF_GET_PANEL** ([SP-002](#sp-002)) - PKG_VTS_BODYSHOP.SF_GET_PANEL - calculates the total number of body panels repaired for a given repair order at the specified dealership and location. Returns zero if no panel data is found.
    * **Step 1** - Accept the parent group, dealership code, location code, completion flag, and repair order number as inputs.
    * **Step 2** - Query the vehicle technical services detail table to sum the total panel count for the matching repair order.
    * **Step 3** - Return the summed panel count, or zero if no records are found.
- **PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT** ([SP-003](#sp-003)) - PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT - counts the number of actual working days within the selected billing date range for the dealership and location, excluding any days recorded as holidays or leave in the working-day register.
    * **Step 1** - Accept the parent group, dealership code, location code, from date, and to date as inputs.
    * **Step 2** - Iterate over each calendar day from the start date to the end date (inclusive).
    * **Step 3** - For each day, check whether it is recorded as a non-working day in the working-day register for the dealership and location.
    * **Step 4** - Count each day that is not recorded as a non-working day; if the working-day register check encounters an error for a specific day, treat that day as a working day and continue.
    * **Step 5** - Return the total count of working days in the period.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Technician name lookup | Name resolution - SF_GET_EMP_NAME [SP-013] | When repair order records are retrieved in the query cursor for each grouped technician row | Provides a readable technician name in the results rather than a raw employee code | If no employee record matches, the technician name is displayed as `N/A` |
| Panel count per repair order | Panel count - PKG_VTS_BODYSHOP.SF_GET_PANEL [SP-002] | Applied within the query cursor for each repair order being aggregated per technician | Calculates the number of body panels repaired per repair order for aggregation into the technician's total | Returns zero if no panel detail records exist for the repair order; no error is raised |
| Working day count for the period | Working-day count - PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT [SP-003] | Applied within the outer query per technician row to compute productivity ratios | Provides the denominator for per-day productivity calculations, excluding recorded non-working days | If the working-day register has no entry for a given day, that day is counted as a working day; no error is raised |

**Step 3 - Results area is cleared and populated with retrieved data**
The system navigates to the results display area and clears any previously shown data without prompting for confirmation. It then iterates through the query results and populates one row per technician with: the technician's name (in the Technician field), the working day count, the vehicles repaired count, the panel count, the vehicle productivity ratio (vehicles repaired divided by working days), and the panel productivity ratio (panels divided by working days). After all rows are filled, focus returns to the first record and is then moved to the Export to Excel button.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| From Bill Date (`FROM_JC_BILL_DT`) | Mandatory | Date | DD-MM-RRRR | N/A | N/A | Entered in search filter | Used as lower bound of billing date range filter | Validated in BR-002; re-checked at search time |
| To Bill Date (`TO_BILL_DT`) | Mandatory | Date | DD-MM-RRRR | N/A | N/A | Entered in search filter | Used as upper bound; re-validated at search time | Validated in BR-003; re-checked at search time |
| Technician (`NO_OF_BAYS`) | Read-only display | Character | N/A | Employee master (via SF_GET_EMP_NAME) | Full name of technician | Search executed | Resolved via employee name lookup; returns `N/A` if not found | Displayed as `N/A` when employee record is absent |
| Working Days (`NO_OF_WORK_DAYS`) | Read-only display | Numeric | N/A | Working-day register (via SF_GET_WORKING_DAY_CNT) | Count of actual working days in period | Search executed | System-calculated; excludes days in holiday/leave register | Non-working day check errors default to counting the day as a working day |
| Vehicles Repaired (`NO_OF_VEH_REP`) | Read-only display | Numeric | N/A | N/A | Count of repair orders for technician in period | Search executed | System-calculated count of repair orders grouped by technician | N/A |
| Panels Repaired (`NO_OF_PANELS`) | Read-only display | Numeric | N/A | Vehicle technical services (via SF_GET_PANEL) | Sum of panel count across repair orders | Search executed | System-calculated sum; returns 0 if no panel records | N/A |
| Technician Vehicle Productivity (`LAB_GEN`) | Read-only display | Numeric | 9999999D00 format mask | N/A | Vehicles repaired divided by working days | Search executed | System-calculated ratio | N/A |
| Panel Productivity (`PANEL_PROD`) | Read-only display | Numeric | 0D00 format mask | N/A | Panels repaired divided by working days | Search executed | System-calculated ratio | N/A |

---

---

#### Requirement ID: BR-005

**Requirement Title:** Export Technician Productivity Results to Excel (CSV)

**Business Description:**
After the productivity results have been retrieved and displayed, the user can press the Export to Excel button to download the displayed data as a comma-separated values file. The system builds a query that mirrors the search results, generates a uniquely named CSV file on the server using the current user identity and timestamp, writes all result rows to the file (up to a maximum of 65,535 rows), and then opens the file in the user's browser for download. This capability allows management to further analyse technician productivity data in a spreadsheet.

**Actors:** Service Advisor / Bodyshop Manager

**Preconditions:**
- The Bodyshop Technician Productivity report screen is open.
- The productivity search has been executed and results are displayed.

**Main Flow:**

**Step 1 - Export query and filename are prepared**
When the user presses the Export to Excel button, the system builds a dynamic SQL query that retrieves the same productivity data shown on screen - technician name, working day count, number of vehicles repaired, panel count, technician productivity ratio, and panel productivity ratio - for the Body and Paint repair category within the selected billing date range. Simultaneously, the system generates a unique filename using the current logged-in user's identity and the current date and time, with a `.CSV` extension.

**Step 2 - Query text is stored and the export procedure is invoked**
The system stores the constructed query text in the form's internal query-text field, then calls the export procedure to execute the query, write the results to a server file, and open the file in the browser.

*Procedures called:*
- **VIEW_EXCEL_REP** ([SP-001](#sp-001)) - VIEW_EXCEL_REP - accepts the CSV filename, the dynamic export query, and the column name to extract; creates a record group from the query, reads the server-side export directory from a configuration file, writes each row of data to a CSV file on the server, and then opens the file in the user's browser for download. If any step fails, it shows the system error details and aborts.
    * **Step 1** - Derive the output filename from the current user's identity and the current timestamp with a `.csv` extension; if the constructed path contains spaces, redirect the output to the default drive root and inform the user.
    * **Step 2** - Check whether a record group with the reserved export name already exists; if so, delete it to avoid conflicts, then create a new record group from the export query and populate it with the query results.
    * **Step 3** - Count the rows retrieved; if the count exceeds the spreadsheet row limit (65,536), cap the export at 65,535 rows and inform the user.
    * **Step 4** - Read the server-side export file directory path from the path configuration file.
    * **Step 5** - Open a new CSV file at the server path, write each row of the record group to the file, and close the file.
    * **Step 6** - Open the completed CSV file in the user's browser so the user can download or view it.
    * **Step 7** - If any unexpected error occurs during any of the above steps, display the error code and error text and stop the export.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| File path does not contain spaces | Path-space check - VIEW_EXCEL_REP [SP-001] (inline path check) | When the export button is pressed and the filename is constructed | Prevents the file from being saved in a directory path that includes spaces, which the file server cannot handle | Info message: *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."*; file is redirected to the root drive and export continues |
| Result set within spreadsheet row limit | Row-count check - VIEW_EXCEL_REP [SP-001] (row count check after group population) | After the record group is populated with export results | Prevents the exported file from exceeding the maximum number of rows a spreadsheet can handle | Info message: *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."*; first 65,535 rows are exported and the process continues |

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-IC-01** - File path contains spaces - *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."*; export redirected to root drive and continues.
- **BR-005-IC-02** - Result set exceeds spreadsheet row limit - *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."*; first 65,535 rows are exported.
- **BR-005-ES-01** - An unexpected error occurs during any export step - message dynamically composed: *"Error  - "* followed by the system error code and error text; trigger is aborted.

**Alternative Flows:**
- **BR-005-AF-01** - (from Step 2) If any error occurs during record group creation, file creation, path-configuration reading, file writing, or browser launch, the system displays the composed error message *"Error  - "* followed by the error code and description, and aborts the export.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| From Bill Date (`FROM_JC_BILL_DT`) | Mandatory | Date | DD-MM-RRRR | N/A | N/A | Search executed | Used as lower bound in the export query | N/A |
| To Bill Date (`TO_BILL_DT`) | Mandatory | Date | DD-MM-RRRR | N/A | N/A | Search executed | Used as upper bound in the export query | N/A |
| Query Text (`TXT`) | Auto-populated | Character | Up to 5000 characters | N/A | Dynamic SQL string constructed for export | Export button pressed | System-populated; not user-editable | N/A |

---

---

#### Requirement ID: BR-006

**Requirement Title:** Form Exit and Session Context Cleanup

**Business Description:**
When the user presses the standard exit key, the system clears any session-level variables used during the session, removes this screen's identity from the database session tracking registry, and then closes the form without prompting the user to save unsaved changes. This ensures that no stale session data persists after the user leaves the screen and that the database session monitoring registry is kept current.

**Actors:** Service Advisor / Bodyshop Manager (any user closing the form)

**Preconditions:**
- The Bodyshop Technician Productivity report screen is open.

**Main Flow:**

**Step 1 - Session-level navigation variables are cleared**
When the user initiates exit via the standard exit key, the system first removes three session-level variables that hold pagination range values - the from-record marker, the to-record marker, and the increment value - from the session global variable store, so they cannot interfere with any subsequent screen opened in the same session.

**Step 2 - Database session context is cleared**
The system clears the session client information tag in the database session registry and also clears the module name and action name registered at form startup (see BR-001). After this step the database monitoring layer no longer shows this form as the active module for the session.

**Step 3 - Form is closed without save validation**
The form is closed immediately without checking for unsaved changes. No save dialog is shown to the user.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| From-record marker (global variable) | Auto-populated | Character | N/A | N/A | Session value cleared on exit | Exit key pressed | System-cleared; not user-editable | N/A |
| To-record marker (global variable) | Auto-populated | Character | N/A | N/A | Session value cleared on exit | Exit key pressed | System-cleared; not user-editable | N/A |
| Increment marker (global variable) | Auto-populated | Character | N/A | N/A | Session value cleared on exit | Exit key pressed | System-cleared; not user-editable | N/A |

---

---

#### Requirement ID: BR-007

**Requirement Title:** Clear Form and Restore Report Description

**Business Description:**
When the user triggers the clear-form action, the system re-populates the report description field on the screen from the current session's stored report description value. The remainder of the clear-form logic that existed in an earlier version of this screen - clearing search filters and resetting control states - is currently inactive and does not execute.

**Actors:** Service Advisor / Bodyshop Manager

**Preconditions:**
- The Bodyshop Technician Productivity report screen is open.

**Main Flow:**

**Step 1 - Report description is refreshed from the session value**
When the clear-form key is pressed, the system reads the report description stored in the current session and writes it back to the report description display field on screen. This is the only active action in this trigger; all remaining clear-form logic (resetting filters, re-enabling fields, clearing the results block) is commented out and does not execute.

*Note: The full clear-form reset logic - including clearing the results block, resetting field properties, and re-initialising session variables - is present in this trigger's code body but is entirely commented out (INACTIVE - does not execute).*

**Alternative Flows:**
- **BR-007-AF-01** - (Save and Clear action) When the user presses the Save toolbar button or the standard commit key, the system first runs field-level validation (enter) and checks for any validation failure before attempting to commit. If validation passes, the system commits all pending changes to the database, verifies the commit succeeded, and then clears the form - restoring the report description display field from the session value as described in Step 1 above. If validation or the commit fails at either checkpoint, the save-and-clear sequence is aborted and the form remains in its current state without data loss.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Report Description (`REPORT_DESC`) | Read-only display | Character | Up to 200 characters | N/A | Value from session report description variable | Clear-form action triggered | System-repopulated; not user-editable | N/A |

---

---

## 5. Business Rules Catalogue

| Rule ID | Rule Name | Rule Type | Business Requirement ID | Condition | Action | Business Impact |
| ------- | --------- | --------- | ----------------------- | --------- | ------ | --------------- |
| BRC-001 | From Bill Date Mandatory | Validation | BR-002 | The From Bill Date field is left blank when the user attempts to leave it | Block navigation and display alert *"From Date can not be null"*; return focus to the From Bill Date field | Ensures a billing start date is always provided before the date range can be completed; prevents empty searches |
| BRC-002 | From Bill Date Not in Future | Validation | BR-002 | The entered From Bill Date is later than today's date | Block navigation and display alert *"From Date cannot be greater than Current Date"*; return focus to the From Bill Date field | Prevents reporting on billing periods that have not yet occurred |
| BRC-003 | To Bill Date Not in Future | Validation | BR-003, BR-004 | The To Bill Date is later than today's date when the field is exited or the Search button is pressed | Block navigation / block search execution and display alert *"To Date cannot be greater than Current Date"*; return focus to the To Bill Date field | Prevents reporting on billing periods that have not yet closed |
| BRC-004 | To Bill Date Not Before From Bill Date | Validation | BR-003, BR-004 | The To Bill Date is earlier than the From Bill Date when the field is exited or the Search button is pressed | Block navigation / block search execution and display alert *"To Date cannot be less than From Date"*; return focus to the To Bill Date field | Ensures the date range is logically valid - end cannot precede start |
| BRC-005 | Date Range Maximum One Month | Constraint | BR-003 | The span from From Bill Date to To Bill Date exceeds 31 days when the To Bill Date field is exited | Block navigation and display alert *"Report can be generated for maximum 1 Month"*; return focus to the To Bill Date field | Limits the report to a manageable one-month window to maintain system performance |
| BRC-006 | To Bill Date Defaults to Today When Blank | Derivation | BR-003 | The To Bill Date field is still blank after all sequential date validations have passed | Automatically set the To Bill Date to today's date; no message is shown | Provides a default end date so the user can run the report without explicitly entering a To Bill Date |
| BRC-007 | Export Row Count Limit | Constraint | BR-005 | The number of rows retrieved for the Excel export exceeds 65,536 | Cap the exported rows at 65,535 and display *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."*; export continues with the truncated data | Prevents the exported file from exceeding the maximum number of rows a spreadsheet application can handle |
| BRC-008 | Export File Path Space Redirect | Derivation | BR-005 | The constructed export file path contains one or more space characters | Redirect the output file to the default drive root and display *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."*; export continues | Prevents file-save failures caused by space characters in the server directory path |
| BRC-009 | Session Context Registration on Form Open | Authorization | BR-001 | The form is opened by a user | Register the module name and clear any prior action label in the database session tracking registry before the screen is shown | Allows database administrators and monitoring tools to identify which screen a session belongs to at all times |
| BRC-010 | Session Context Cleared on Form Exit | Authorization | BR-006 | The user presses the exit key to close the form | Clear the session client information tag, module name, and action name from the database session tracking registry, and remove pagination global variables; then close the form without prompting for save | Ensures no stale session data persists and the database monitoring registry accurately reflects that this screen is no longer active |

**Total Business Rules Identified: 10**

---

## 6. Data Requirements

*This section describes the data entities accessed by the Bodyshop Technician Productivity report, the fields captured or displayed by the form, reference data used for lookups, and the data lifecycle applicable to this read-only reporting screen.*

### 6.1 Business Entities and Relationships

*The form accesses repair order records and supporting master data to calculate and display technician productivity metrics; no records are created or modified by this screen.*

#### Repair Orders - VH_RO

The repair order table is the primary data source for this report. The form queries it to retrieve all Body and Paint repair orders billed within the selected date range for the current dealership and location, grouped by the technician (service employee) assigned to each order. The labour amount and repair order count per technician are summed from this entity.

#### Employee Master - GM_EMP (via SF_GET_EMP_NAME)

The employee master holds the first, middle, and last names of all dealership employees including technicians. The report accesses this entity through the employee name lookup function to resolve each technician's employee code into a readable full name. This entity is not queried directly by the form's triggers; it is accessed only through the called function.

#### Vehicle Technical Services Detail - VT_VTS (via PKG_VTS_BODYSHOP.SF_GET_PANEL)

This entity stores the panel-level repair detail records for each repair order, specifically the windshield and panel count entries. The report uses it to sum the total number of panels repaired per repair order and by extension per technician. It is accessed only through the called package function.

#### Working Day Register - WD_BTN (via PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT)

The working day register records designated non-working days (holidays and leave) for each dealership and location. The report uses this entity to calculate the number of actual working days within the selected billing date range, which serves as the denominator for per-day productivity ratios. It is accessed only through the called package function.

#### Entity Relationships

The form's data flows from the repair order entity as the root, with supporting lookups resolving employee names and panel detail, and working-day records providing the productivity denominator. No Forms-declared master-detail relationships exist between blocks in this form; all inter-entity joins are performed inside called database functions.

```
VH_RO (Repair Orders - root query entity)
    ├── GM_EMP (Employee Master)      <- joined by dealer_map_cd + emp_cd via SF_GET_EMP_NAME
    ├── VT_VTS (Panel Detail)         <- joined by dealer_map_cd + loc_cd + ro_num via SF_GET_PANEL
    └── WD_BTN (Working Day Register) <- joined by parent_group + dealer_map_cd + loc_cd via SF_GET_WORKING_DAY_CNT
```

### 6.2 Data Capture Requirements

*The form captures a date-range filter from the user and displays calculated productivity metrics; all result fields are system-populated and read-only.*

#### Query Filter - date range entered by the user before running the search

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| From Bill Date (`FROM_JC_BILL_DT`) | Yes | Starting date of the billing period to include in the productivity report | Must not be blank; must not be later than today's date |
| To Bill Date (`TO_BILL_DT`) | Conditional | Ending date of the billing period; defaults to today if left blank | Must not be in the future; must not be before From Bill Date; the span from From to To must not exceed 31 days |

#### Productivity Results Display - system-populated per-technician results after search

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Technician (`NO_OF_BAYS`) | Auto-Populated | Full name of the technician, resolved from the employee master using the service employee code on the repair order | Display only; shown as not-available if no matching employee record exists |
| Working Days (`NO_OF_WORK_DAYS`) | Auto-Populated | Number of actual working days in the selected billing period for this dealership, excluding recorded holidays and leave | Display only; system-calculated via working-day function |
| Vehicles Repaired (`NO_OF_VEH_REP`) | Auto-Populated | Count of Body and Paint repair orders billed to this technician within the selected date range | Display only; system-calculated count |
| Panels Repaired (`NO_OF_PANELS`) | Auto-Populated | Total number of body panels repaired across all of this technician's repair orders in the period | Display only; system-calculated sum; zero if no panel detail records exist |
| Labour Amount Generated (`LAB_GEN`) | Auto-Populated | Total labour amount billed on this technician's repair orders in the period, formatted with a large numeric mask (`9999999D00`) | Display only; summed from repair order labour amounts |
| Technician Vehicle Productivity (`PANEL_PROD`) | Auto-Populated | Per-day ratio of vehicles repaired divided by working days, rounded to two decimal places, formatted with a decimal mask (`0D00`) | Display only; system-calculated |
| Average Work (`AVG_WORK`) | Auto-Populated | Numeric average field in the results display area; populated as part of the results output | Display only; numeric format |
| Average Panel (`AVG_PANEL`) | Auto-Populated | Panel average field in the results display area; formatted with a three-digit decimal mask (`999D00`) | Display only; numeric format |
| Average Vehicle (`AVG_VEH`) | Auto-Populated | Vehicle average field in the results display area; formatted with a three-digit decimal mask (`999D00`) | Display only; numeric format |
| Average Labour (`AVG_LAB`) | Auto-Populated | Labour average field in the results display area; formatted with a large numeric mask (`9999999D00`) | Display only; numeric format |
| Average Group Panel (`AVG_GRP_PANEL`) | Auto-Populated | Group-level panel average field in the results display area; formatted with a decimal mask (`0D00`) | Display only; numeric format |
| Number of Bays (`NO_OF_BAYS`) | Auto-Populated | Number of service bays field in the results display area | Display only; numeric |

#### Session and Global Parameters - passed at session level, not entered on screen

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Dealer Code (global: `DEALER`) | Auto-Populated | Identifies the dealership whose repair orders are queried; set at session login and passed to all queries | System-set; not user-editable on this screen |
| Parent Group (global: `PARENT_GROUP`) | Auto-Populated | Identifies the dealer group; used as a filter in all repair order and master data queries | System-set; not user-editable on this screen |
| Location Code (global: `LOC_CD`) | Auto-Populated | Identifies the specific service location within the dealership | System-set; not user-editable on this screen |
| Report Description (global: `REPORT_DESC`) | Auto-Populated | Descriptive label for the current report; restored to the display field on clear-form | System-set; displayed read-only on screen via `REPORT_DESC` display item |
| Query Text (`TXT`) | Auto-Populated | Internal field used to store the dynamic SQL string built for the Excel export; max 5000 characters | System-populated; not visible to the user for editing |
| Copyright Declaration (`COPYRIGHT_DECLARATION`) | Auto-Populated | Internal field; max 100 characters | System-populated; not visible to the user for editing |

### 6.3 Reference Data

*Lists the master and configuration data referenced by this form. This form defines no LOVs or record groups; all reference data is accessed through called database functions.*

| Reference Data | Business Purpose | Used When |
| :--- | :--- | :--- |
| Repair Orders (`VH_RO`) | Primary data source providing billed repair orders grouped by technician for the selected date range and Body and Paint repair category | When the Search button is pressed to retrieve productivity results |
| Employee Master (`GM_EMP`) | Resolves technician employee codes to full display names for on-screen and export display | During the productivity query, for each technician row retrieved |
| Vehicle Technical Services Detail (`VT_VTS`) | Provides the panel count per repair order, summed to give total panels repaired per technician | During the productivity query, for each repair order in the result set |
| Working Day Register (`WD_BTN`) | Provides the list of non-working days (holidays/leave) per dealership and location, used to calculate actual working days in the reporting period | During the productivity query, once per result row to compute per-day ratios |
| Export Path Configuration (`/reports/DMS/excelpath.txt`) | Supplies the server-side directory path where the CSV export file is written | When the Export to Excel button is pressed |

### 6.4 Data Lifecycle

*Describes how data flows through this form; this is a read-only reporting screen with no record creation, update, or commit capability.*

**Creation**

- No records are created by this form. All data displayed is retrieved by read-only queries from the repair order database.

**Updates**

- No records are updated by this form. Query results are displayed in non-database, non-updateable result fields. The form has no commit or save path.

**Save and Commit**

- No save or commit actions are implemented on this form. The Key-Commit trigger is inactive and does not execute. The only write action performed by this form is the creation of a server-side CSV export file when the Export to Excel button is pressed; this does not affect any database record.

**Retention and Audit**

- The form sets and clears session context information in the database monitoring registry (module name and client info) at form open and form exit, respectively. No creation or modification timestamps are written to any business table. No audit trail is recorded by this form.

---

### 6.5 Excel Output Columns

This form does not use Excel download. No Excel export columns were identified in the form sources.

## 7. Glossary

*Definitions of terms, abbreviations, and acronyms used throughout this document.*

The following table defines key terms, acronyms, and abbreviations used throughout this Business Requirements Document.

| Term | Definition | Aliases | Related Terms |
| :--- | :--- | :--- | :--- |
| BANDP | Body and Paint - the repair order category code used to identify bodyshop jobs in the DMS | Body & Paint | Bodyshop, Repair Order, RO |
| Bodyshop | The vehicle body repair and paint department within a dealership | Body Shop | Technician, Panel, VTS |
| CB_DOC | Control block that displays per-technician productivity result rows on the screen | Results block | CB_DOC_QUERY, Technician |
| CB_DOC_QUERY | Control block that holds the date-range search criteria and action buttons on the form | Query block | CB_DOC |
| CSV | Comma-Separated Values - the file format used when exporting productivity data to Excel | Comma-Delimited | Export, Excel |
| Dealer Map Code | Numeric identifier that maps a physical dealer location within the DMS | DEALER | Location Code, Parent Group |
| DMS | Dealer Management System - the integrated software platform used by the dealership for vehicle sales, service, and parts operations | | VTS, Bodyshop, DPL |
| DPL | Shared Oracle Forms program library (DPL.pld) providing common utility procedures used across DMS forms | DPL.pld | PLD, DMS |
| DUAL | Oracle database pseudo-table used in SQL queries that do not require a real table source | | SQL |
| From Bill Date | The start date of the billing period entered by the user to filter bodyshop repair orders | FROM_JC_BILL_DT | To Bill Date, Billing Period |
| Job Card | A repair order record in the DMS documenting a vehicle service event; counted per technician in the productivity report | JC | Repair Order, RO |
| Loc Cd | Location code identifying the branch or workshop within the dealer group | LOC_CD | Dealer Map Code, Parent Group |
| Panel Count | The total number of body panels recorded against a repair order in the VTS tracking table; used as a workload measure for bodyshop technicians | PANEL_CNT | VTS, Panel Productivity |
| Panel Productivity | The ratio of total panels to working days for a technician; a key bodyshop performance metric | PANEL_PROD | Panel Count, Working Day Count |
| Parent Group | Dealer group code that groups multiple dealer locations under a common organisation | PARENT_GROUP | Dealer Map Code, Loc Cd |
| PCK | Oracle PL/SQL package - a compiled database object grouping related stored procedures and functions | Package | PKG_VTS_BODYSHOP, PLD |
| PKG_VTS_BODYSHOP | Database package providing bodyshop-specific analytics functions: panel count retrieval and working-day calculation | | VTS, sf_get_panel, sf_get_working_day_cnt |
| PLD | Oracle Forms attached program library (`.pld` file) containing shared utility procedures available to multiple forms | Program Library | DPL, D2kwutil, webutil |
| RO | Repair Order - the primary document recording a vehicle service or repair event at the dealership | Repair Order, Job Card | VH_RO, Bodyshop |
| sf_get_panel | Database function in PKG_VTS_BODYSHOP that returns the total panel count for a given repair order from VT_VTS | | PKG_VTS_BODYSHOP, Panel Count, VT_VTS |
| sf_get_working_day_cnt | Database function in PKG_VTS_BODYSHOP that counts non-holiday working days in a date range using the WD_BTN calendar | | PKG_VTS_BODYSHOP, Working Day Count, WD_BTN |
| Technician | A bodyshop service employee whose repair and panel output is measured and displayed per row in the productivity report | Service Employee | Job Card, Panel Count |
| Technician Vehicle Productivity | The ratio of job cards handled to working days for a technician; measures vehicle throughput per working day | Tech_Veh_Prod, LAB_GEN | Panel Productivity, Working Day Count |
| To Bill Date | The end date of the billing period entered by the user; must not be in the future, before From Bill Date, or more than 31 days after it | TO_BILL_DT | From Bill Date, Billing Period |
| VH_RO | Vehicle Repair Order - the database table storing completed repair order records for all dealership service jobs | | Repair Order, Bodyshop, RO |
| VTS | Vehicle Tracking System - the DMS sub-system that records bodyshop vehicle movement, panel work, and technician assignments | Vehicle Tracking System | VT_VTS, Bodyshop, PKG_VTS_BODYSHOP |
| VT_VTS | VTS tracking table holding panel and time-related records for each repair order; queried by sf_get_panel | | VTS, Panel Count, sf_get_panel |
| WD_BTN | Working-day calendar table recording public holidays and non-working days per dealer and location; used to exclude holidays from the working-day count | Holiday Calendar | sf_get_working_day_cnt, Working Day Count |
| WebUtil | Oracle Forms utility library (webutil.pld / webutil.olb) providing browser integration functions such as file transfer and ID handle checking | WEBUTIL | DPL, PLD |
| Working Day Count | The number of calendar days in the billing period that are not listed as holidays in WD_BTN; the denominator for all productivity ratios | NO_OF_WORK_DAYS | sf_get_working_day_cnt, WD_BTN, Panel Productivity |

---

---

## 8. Technical Inventory

*Complete inventory of Oracle Forms components including blocks, items, triggers, canvases, and global variables.*

### 8.1 Form Architecture

**Form Module Details:**

- Form Name: vr_bodyshop_tech_prod (VR_BODYSHOP_TECH_PROD)
- Form Module XML Title: MODULE2
- Oracle Forms Version: 12c (Module version 122010400)
- Parent Object Library: DPL.olb (PC_FORM property class)
- Attached Libraries: DMS_EXCEL_REPORT, DPL (DPL.pld program library), D2KWUTIL, WEBUTIL (webutil.olb)
- First Navigation Block: -
- Console Window: WEBUTIL_HIDDEN_WINDOW (subclassed infrastructure window from webutil.olb; no business console window defined in the form)
- Compile Dependencies: Requires DPL.olb, DPL.pld, WEBUTIL.olb, database packages PKG_VTS_BODYSHOP
- Source artifacts: `vr_bshop_tech_prod_fmb.xml`; OLB `DPL.olb`; DMS_EXCEL_REPORT; DPL (DPL.pld program library); D2KWUTIL; WEBUTIL (webutil.olb); PCK `PKG_VTS_BODYSHOP.pck`

### 8.1.1 Global Variables

| Global Variable | Data Type | Set Location | Purpose |
| :--- | :--- | :--- | :--- |
| APP_ID | Char | Trigger | Application identifier passed at session context; used for application-level routing and security scoping |
| APP_LOG | Char | Trigger | Application log identifier used to record session activity for audit and diagnostic purposes |
| COMP_FA | Char | ProgramUnit / Trigger | Company/FA code used to filter bodyshop repair order records in queries |
| CURRENCY | Char | Trigger | Currency code for the session; used to format or label monetary values in reports |
| DEALER | Number | ProgramUnit / Trigger | Dealer map code identifying the dealership; used to filter VH_RO records |
| FIN_BEG | Char | Trigger | Financial year beginning date for the session; used to scope financial period queries |
| FIN_END | Char | Trigger | Financial year ending date for the session; used to scope financial period queries |
| FROM_NO | Number | ProgramUnit / Trigger | Starting record number for pagination; initialised to 1 by SET_GLOBAL |
| FROM_REC | Number | ProgramUnit / Trigger | Starting record pointer used by the POPULATE procedure (COMMENTED OUT / INACTIVE) |
| INCREMENT_NO | Number | ProgramUnit / Trigger | Page size (number of records per page); initialised to 10 by SET_GLOBAL |
| LOC_CD | Char | ProgramUnit / Trigger | Location code used to scope VH_RO and working-day queries to a branch |
| PARENT_GROUP | Char | ProgramUnit / Trigger | Parent dealer group code used in all bodyshop data queries |
| PRINCIPAL | Char | Trigger | Principal identifier passed at session context for Excel export routing |
| P_FIN_YR | Char | Trigger | Financial year parameter passed at session startup; used to set the active financial year context |
| REPORT_DESC | Char | Trigger | Report description displayed on screen; carried into KEY-CLRFRM for reset |
| REP_SERVER | Char | Trigger | Report server name used to route Oracle Reports execution requests |
| TALLY_INTEGRATION | Char | Trigger | Flag indicating whether Tally accounting integration is active for the session |
| TO_NO | Number | ProgramUnit / Trigger | Ending record number for pagination; initialised to 10 by SET_GLOBAL |
| TO_REC | Number | ProgramUnit / Trigger | Ending record pointer used by the POPULATE procedure (COMMENTED OUT / INACTIVE) |
| USERID | Char | ProgramUnit / Trigger | Logged-in user identifier used to generate unique CSV file names for export |
| USER_NAME | Char | Trigger | Display name of the logged-in user; used for labelling and session context |

### 8.1.2 Form Parameters

*All 2 ModuleParameter entries from vr_bshop_tech_prod_fmb.xml.*

| Parameter | Data Type | Default | Description |
| :--- | :--- | :--- | :--- |
| P_RO_NUM | Char | - | Repair order number passed when form is called from parent; used in inactive EXCEL_GENERATION query |
| P_APP_ID | Char | - | Application identifier passed at startup; referenced in commented-out Excel export call - not used in active logic |

**Total Parameters:** 2

### 8.2 Blocks

| Block Name | Query Data Source | Records | Q/I/U/D | Key Mode | Master-Detail Relationship |
| :--- | :--- | :--- | :--- | :--- | :--- |
| CB_DOC_QUERY | - | 1 | N/N/N/N | Default | Control block - entry point for date-range search and report generation |
| CB_DOC | - | 5 | N/N/N/N | Default | Control block - displays technician productivity results populated by the SEARCH trigger |

**Total Blocks:** 2 business blocks

### 8.2.1 Block WhereClause and OrderByClause

*Block query scope from vr_bshop_tech_prod_fmb.xml. **Description** explains filter and sort in business terms; **Order By** and **Where Clause** columns retain verbatim XML text for migration.*

| Block | Description | Order By (XML) | Where Clause (XML) |
| :--- | :--- | :--- | :--- |
| - | No blocks with WhereClause/OrderByClause in vr_bshop_tech_prod_fmb.xml | - | - |

### 8.3 Items Summary

*Complete item inventory from `vr_bshop_tech_prod_fmb.xml`.*

**Block counts:**

*Database / non-database counts derived from XML.*

| Block | Total Items | Database Items | Non-Database Items |
| :--- | ---: | ---: | ---: |
| CB_DOC_QUERY | 7 | 0 | 7 |
| CB_DOC | 11 | 0 | 11 |
| CB_ERR | 1 | 0 | 1 |
| PB_BLK | 13 | 0 | 13 |
| WEBUTIL | 9 | 0 | 9 |
| **Total** | **41** | **0** | **41** |

**Item detail (all 41 items):**

| Block | Item Name | DatabaseItem | Description |
| :--- | :--- | :--- | :--- |
| CB_DOC_QUERY | FROM_JC_BILL_DT | false | Start date for the bill date range filter; mandatory, cannot be null or future |
| CB_DOC_QUERY | TO_BILL_DT | false | End date for the bill date range filter; must not exceed current date or be before From Date; range capped at 31 days |
| CB_DOC_QUERY | SEARCH | false | Search button - triggers bodyshop technician productivity query for the selected date range |
| CB_DOC_QUERY | PB_EXCEL | false | Export to Excel button - generates and downloads a CSV file of the productivity results |
| CB_DOC_QUERY | TXT | false | Hidden text buffer storing the dynamic SQL query string used for Excel export |
| CB_DOC_QUERY | COPYRIGHT_DECLARATION | false | Display field showing copyright or form ownership declaration text |
| CB_DOC_QUERY | REPORT_DESC | false | Display field showing the report title or description label |
| CB_DOC | NO_OF_WORK_DAYS | false | Number of working days for the technician in the selected period |
| CB_DOC | NO_OF_BAYS | false | Technician name (service employee) for the productivity row |
| CB_DOC | NO_OF_VEH_REP | false | Number of job cards (vehicles repaired) by the technician in the period |
| CB_DOC | NO_OF_PANELS | false | Total panel count attributed to the technician in the period |
| CB_DOC | LAB_GEN | false | Technician vehicle productivity - job cards per working day |
| CB_DOC | PANEL_PROD | false | Panel productivity - panels per working day |
| CB_DOC | AVG_WORK | false | Summary: average number of working days across displayed technicians |
| CB_DOC | AVG_PANEL | false | Summary: average panel count across displayed technicians |
| CB_DOC | AVG_VEH | false | Summary: average number of vehicles repaired across displayed technicians |
| CB_DOC | AVG_LAB | false | Summary: average technician vehicle productivity across displayed technicians |
| CB_DOC | AVG_GRP_PANEL | false | Summary: average panel productivity across displayed technicians |
| CB_ERR | TXT_ERR | false | Inherited error display text item within the CB_ERR block; shows error message text surfaced by the DPL error-handling framework at runtime (inherited) |
| PB_BLK | PB_EXIT | false | Inherited toolbar button - exits the current form (inherited) |
| PB_BLK | PB_LIST | false | Inherited toolbar button - invokes the List of Values for the current field (inherited) |
| PB_BLK | PB_INSERT | false | Inherited toolbar button - inserts a new record in the current block (inherited) |
| PB_BLK | PM_CONT | false | Inherited toolbar button - continues or confirms the current operation (inherited) |
| PB_BLK | PB_DEL | false | Inherited toolbar button - deletes the current record (inherited) |
| PB_BLK | PB_CANCEL | false | Inherited toolbar button - cancels the current operation without saving (inherited) |
| PB_BLK | PB_SAVE | false | Inherited toolbar button - saves (commits) the current transaction (inherited) |
| PB_BLK | PB_PRINT | false | Inherited toolbar button - triggers the print action for the current report or screen (inherited) |
| PB_BLK | PB_CUT | false | Inherited toolbar button - cuts the selected text or field value to the clipboard (inherited) |
| PB_BLK | PB_COPY | false | Inherited toolbar button - copies the selected text or field value to the clipboard (inherited) |
| PB_BLK | PB_PASTE | false | Inherited toolbar button - pastes clipboard content into the current field (inherited) |
| PB_BLK | PB_ERR_EXIT | false | Inherited toolbar button - closes the error dialog without further action (inherited) |
| PB_BLK | PB_ERR_OK | false | Inherited toolbar button - acknowledges and dismisses the error dialog (inherited) |
| WEBUTIL | DUMMY | false | Placeholder item required by the WEBUTIL infrastructure block; carries no business data (inherited WEBUTIL infrastructure) |
| WEBUTIL | WEBUTIL_CLIENTINFO_FUNCTIONS | false | WEBUTIL bean area item exposing client information functions (e.g. client OS, locale) to the form (inherited WEBUTIL infrastructure) |
| WEBUTIL | WEBUTIL_FILE_FUNCTIONS | false | WEBUTIL bean area item exposing client-side file system functions used for file transfer operations (inherited WEBUTIL infrastructure) |
| WEBUTIL | WEBUTIL_HOST_FUNCTIONS | false | WEBUTIL bean area item exposing host command execution functions on the application server (inherited WEBUTIL infrastructure) |
| WEBUTIL | WEBUTIL_SESSION_FUNCTIONS | false | WEBUTIL bean area item exposing session-level utility functions (inherited WEBUTIL infrastructure) |
| WEBUTIL | WEBUTIL_FILETRANSFER_FUNCTIONS | false | WEBUTIL bean area item managing file transfer between client and server; used by VIEW_EXCEL_REP to deliver the generated CSV to the browser (inherited WEBUTIL infrastructure) |
| WEBUTIL | WEBUTIL_OLE_FUNCTIONS | false | WEBUTIL bean area item exposing OLE automation functions for client-side application integration (inherited WEBUTIL infrastructure) |
| WEBUTIL | WEBUTIL_C_API_FUNCTIONS | false | WEBUTIL bean area item exposing C API calls for low-level client-side operations (inherited WEBUTIL infrastructure) |
| WEBUTIL | WEBUTIL_BROWSER_FUNCTIONS | false | WEBUTIL bean area item exposing browser control functions; used by VIEW_EXCEL_REP to open the generated CSV file URL in the client browser (inherited WEBUTIL infrastructure) |

### 8.4 List of Values

*No LOVs found in vr_bshop_tech_prod_fmb.xml.*

### 8.5 Alerts

| Alert Name | Title | Message Text | Calling Context |
| :--- | :--- | :--- | :--- |
| WEBUTIL_ERROR | Forms | (set at runtime) | Subclassed from webutil.olb; invoked by WebUtil internal error handling within the WEBUTIL block (inherited) |
| AL_PRINT | Print | (set at runtime) | Inherited from DPL.olb; invoked by DPL print-routing routines when prompting the user for print destination selection (inherited) |
| AL_ERRINFO | Error | (set at runtime) | Inherited from DPL.olb; invoked by GENERAL.DISP_TEXT to display error-level messages to the user (inherited) |
| AL_NOTE | Note | (set at runtime) | Inherited from DPL.olb; invoked by GENERAL.DISP_TEXT to display informational note messages to the user (inherited) |
| AL_CONFIRM | Caution | (set at runtime) | Inherited from DPL.olb; invoked by GENERAL.ASK_CONFIRM to present a confirmation prompt before destructive or significant operations (inherited) |

**Total Alerts:** 5

### 8.6 Program Units

*Authoritative catalogue of **5 form-local program units**. Database packages and standalone procedures are in **Section 15.2**; PLD shared-library routines are in **Section 18**.*

| Program Unit | Type | Calls | Description |
| :--- | :--- | :--- | :--- |
| SET_GLOBAL | Procedure | :GLOBAL.FROM_NO, :GLOBAL.TO_NO, :GLOBAL.INCREMENT_NO | Initialises pagination globals: sets :GLOBAL.FROM_NO to 1, :GLOBAL.TO_NO to 10, and :GLOBAL.INCREMENT_NO to 10 at form startup |
| POPULATE | Unknown | **COMMENTED OUT / INACTIVE** | **COMMENTED OUT / INACTIVE** - formerly iterated over DOC_DET.V_DOC_TAB to populate CB_DOC block rows from a PL/SQL table; replaced by inline cursor in SEARCH trigger |
| DOC_DET | Unknown | **COMMENTED OUT / INACTIVE** | **COMMENTED OUT / INACTIVE** - formerly a form-local package spec holding a PL/SQL table V_DOC_TAB for document detail rows; no longer active |
| EXCEL_GENERATION | Unknown | **COMMENTED OUT / INACTIVE** | **COMMENTED OUT / INACTIVE** - formerly generated a CSV Excel file from VH_RO and PH_ISSUE data; superseded by VIEW_EXCEL_REP in the active PB_EXCEL button |
| VIEW_EXCEL_REP | Procedure | webutil.ID_NULL, Find_Group, Create_Group_From_Query, Populate_Group, Get_Group_Row_Count, Text_IO, web.show_document | Builds a dynamic record group from a supplied SQL query, writes results to a CSV file on the server, and opens the file in the browser; called from PB_EXCEL trigger |

**Total Program Units:** 5

### 8.7 Triggers

**Item-Level Trigger Types (reference):**

| Trigger Name | Purpose |
| :--- | :--- |
| WHEN-VALIDATE-ITEM | Validates field when user leaves item |
| KEY-* | Keyboard actions - commit, exit, LOV, navigation |
| WHEN-NEW-BLOCK-INSTANCE | Initializes block on entry |
| WHEN-BUTTON-PRESSED | Executes button action |
| PRE-INSERT / POST-INSERT | Before/after record creation |
| WHEN-LIST-CHANGED | Dropdown selection changed |
| PRE-QUERY / POST-QUERY | Before/after query execution |
| WHEN-CHECKBOX-CHANGED | Checkbox toggled |
| WHEN-VALIDATE-RECORD | Validates entire record before leaving row |

**DPL library routines invoked from triggers and program units:**

| Routine | Type | Called From | Purpose |
| :--- | :--- | :--- | :--- |
| GENERAL.ASK_CONFIRM | Library routine | Form level | Presents a confirmation dialog (AL_CONFIRM alert) to the user before a significant or destructive operation; returns the user's choice to the calling trigger |
| GENERAL.DISP_TEXT | Library routine | Form level, ProgramUnit: EXCEL_GENERATION | Displays an alert dialog with provided message text and title (AL_ERRINFO for errors, AL_NOTE for notes); referenced in ON-ERROR and in the inactive EXCEL_GENERATION program unit |
| GENERAL.RAISE_ERROR | Library routine | Form level | Retrieves an error message by code from the message table and displays it via GENERAL.DISP_TEXT; raises FORM_TRIGGER_FAILURE for error-type messages; referenced in ON-ERROR handling |

### 8.7.1 Inactive / Commented-Out Trigger Register

*Triggers and field validations where XML source is `null;`, fully block-commented, or legacy code preserved but not executed. Do **not** migrate these as active business requirements.*

| Status | Block | Item | Trigger | Former behaviour (preserved in comments) | Disabled since / note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Inactive stub** | Form | - | ON-ERROR | Formerly caught specific Oracle Forms error codes (40209, 40207, 50026, etc.) and displayed friendly error dialogs via GENERAL.DISP_TEXT; also handled integrity constraint violations and concurrent-update conflicts | Body is `null;`; all error-handling code is block-commented; replaced with no active error interception |
| **Inactive stub** | Form | - | KEY-CLRFRM | Formerly reset the form by calling CLEAR_FORM, re-initialising block properties, setting DOC_TYPE, and calling SET_GLOBAL | Body starts with `null;`; clear-form code is block-commented; form clearing is not active |
| **Inactive stub** | Form | - | FT_CANCEL | Formerly cancelled the current operation and reverted unsaved changes via the inherited DPL cancel action | Body is `null;`; inherited cancel behaviour is suppressed in this read-only report form |
| **Inactive stub** | Form | - | FT_DEL | Formerly deleted the current record via the inherited DPL delete action | Body is `null;`; delete is not applicable in this read-only report form |
| **Inactive stub** | Form | - | FT_LIST | Formerly invoked the List of Values for the current field via the inherited DPL list action | Body is `null;`; LOV invocation is suppressed at form level |
| **Commented out** | Form | - | WHEN-NEW-FORM-INSTANCE | Formerly initialised session globals (COMP_FA, DEALER, LOC_CD, PARENT_GROUP, USERID, PRINCIPAL, REPORT_DESC and others) by reading from application context and called SET_GLOBAL to set pagination defaults | Body is fully block-commented; session initialisation is inactive; globals are set by other means at runtime |
| **Inactive stub** | CB_DOC_QUERY | - | KEY-UP | Formerly provided upward navigation within the CB_DOC_QUERY block | Body is `NULL;`; no upward navigation active |
| **Inactive stub** | CB_DOC_QUERY | - | KEY-DOWN | Formerly provided downward navigation within the CB_DOC_QUERY block | Body is `NULL;`; no downward navigation active |

*Additional null-only or partially commented triggers exist on estimation and legacy blocks - see XML `TriggerText` starting with `null;` or `/*`.*

**Complete trigger inventory (39 business triggers):**
*vr_bshop_tech_prod_fmb.xml contains Trigger elements.*

| Trigger Name | Block | Item | Called From / Context | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| ON-ERROR | Form | - | Form level | **COMMENTED OUT / INACTIVE** - body is `null;`; formerly intercepted Forms error codes and displayed error dialogs via GENERAL.DISP_TEXT |
| ON-MESSAGE | Form | - | Form level | Suppresses or passes through Oracle Forms informational messages at form level |
| KEY-EXIT | Form | - | Form level | Clears application info and global pagination variables (FROM_NO, TO_NO, INCREMENT_NO) then exits the form without validation |
| KEY-LISTVAL | Form | - | Form level | Intercepts List-of-Values key; body is empty - LOV invocation is suppressed at form level |
| KEY-COMMIT | Form | - | Form level | Intercepts commit key; body is empty - no save operation is performed (read-only report form) |
| KEY-CLRFRM | Form | - | Form level | **COMMENTED OUT / INACTIVE** - body starts with `null;`; formerly cleared the form and reset block/item properties |
| KEY-UP | Form | - | Form level | Intercepts the upward navigation key at form level; suppresses default upward cursor movement (inherited) |
| KEY-DOWN | Form | - | Form level | Intercepts the downward navigation key at form level; suppresses default downward cursor movement (inherited) |
| KEY-PRVBLK | Form | - | Form level | Intercepts the previous-block key at form level; suppresses or overrides default previous-block navigation (inherited) |
| KEY-NXTBLK | Form | - | Form level | Intercepts the next-block key at form level; suppresses or overrides default next-block navigation (inherited) |
| KEY-PREV-ITEM | Form | - | Form level | Intercepts the previous-item key at form level; overrides default backward tab navigation (inherited) |
| KEY-NEXT-ITEM | Form | - | Form level | Intercepts the next-item key at form level; overrides default forward tab navigation (inherited) |
| KEY-OTHERS | Form | - | Form level | Intercepts all other unhandled key events at form level; suppresses unrecognised keystrokes (inherited) |
| FT_SAVE | Form | - | Form level | Inherited DPL toolbar trigger - intercepts the save action; body suppresses commit in this read-only report form (inherited) |
| FT_CANCEL | Form | - | Form level | **INACTIVE** - inherited DPL toolbar trigger; body is `null;`; cancel action is suppressed |
| FT_INSERT | Form | - | Form level | Inherited DPL toolbar trigger - intercepts the insert action; body suppresses record insertion in this read-only report form (inherited) |
| FT_DEL | Form | - | Form level | **INACTIVE** - inherited DPL toolbar trigger; body is `null;`; delete action is suppressed |
| FT_LIST | Form | - | Form level | **INACTIVE** - inherited DPL toolbar trigger; body is `null;`; LOV toolbar action is suppressed |
| FT_PRINT | Form | - | Form level | Inherited DPL toolbar trigger - handles the print toolbar button action; routes to report printing logic (inherited) |
| WHEN-NEW-FORM-INSTANCE | Form | - | Form level | **COMMENTED OUT** - formerly initialised session globals and called SET_GLOBAL; body is fully block-commented; no active initialisation logic executes |
| PRE-FORM | Form | - | Form level | Sets Oracle application info (client_info and module_name) to 'vr_bshop_tech_prod' before the form opens |
| KEY-UP | CB_DOC_QUERY | - | CB_DOC_QUERY | **COMMENTED OUT / INACTIVE** - body is `NULL;`; upward navigation is suppressed in the query block |
| KEY-DOWN | CB_DOC_QUERY | - | CB_DOC_QUERY | **COMMENTED OUT / INACTIVE** - body is `NULL;`; downward navigation is suppressed in the query block |
| WHEN-VALIDATE-ITEM | CB_DOC_QUERY | FROM_JC_BILL_DT | CB_DOC_QUERY.FROM_JC_BILL_DT | Validates FROM_JC_BILL_DT: rejects null value and rejects any date greater than system date |
| KEY-NEXT-ITEM | CB_DOC_QUERY | FROM_JC_BILL_DT | CB_DOC_QUERY.FROM_JC_BILL_DT | Navigates focus to CB_DOC_QUERY.TO_BILL_DT after the From Bill Date field |
| WHEN-VALIDATE-ITEM | CB_DOC_QUERY | TO_BILL_DT | CB_DOC_QUERY.TO_BILL_DT | Validates TO_BILL_DT: rejects future dates, rejects dates before FROM_JC_BILL_DT, and rejects date ranges exceeding 31 days |
| WHEN-BUTTON-PRESSED | CB_DOC_QUERY | SEARCH | CB_DOC_QUERY.SEARCH | Validates date range then executes a cursor query against VH_RO to retrieve technician productivity metrics (working days, job count, panel count, labour amount) and populates CB_DOC block |
| WHEN-BUTTON-PRESSED | CB_DOC_QUERY | PB_EXCEL | CB_DOC_QUERY.PB_EXCEL | Builds a dynamic SQL query for the same productivity data, calls VIEW_EXCEL_REP to generate a CSV file, and opens it in the browser for download |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EXIT | PB_BLK.PB_EXIT (inherited) | Inherited toolbar button trigger - exits the current form when the Exit button is pressed (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_LIST | PB_BLK.PB_LIST (inherited) | Inherited toolbar button trigger - invokes the List of Values for the current field when the List button is pressed (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_INSERT | PB_BLK.PB_INSERT (inherited) | Inherited toolbar button trigger - inserts a new record when the Insert button is pressed; suppressed in this read-only form (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PM_CONT | PB_BLK.PM_CONT (inherited) | Inherited toolbar button trigger - continues or confirms the current operation when the Continue button is pressed (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_DEL | PB_BLK.PB_DEL (inherited) | Inherited toolbar button trigger - deletes the current record when the Delete button is pressed; suppressed in this read-only form (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CANCEL | PB_BLK.PB_CANCEL (inherited) | Inherited toolbar button trigger - cancels the current operation when the Cancel button is pressed (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SAVE | PB_BLK.PB_SAVE (inherited) | Inherited toolbar button trigger - commits the current transaction when the Save button is pressed; suppressed in this read-only form (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PRINT | PB_BLK.PB_PRINT (inherited) | Inherited toolbar button trigger - triggers the print action when the Print button is pressed (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CUT | PB_BLK.PB_CUT (inherited) | Inherited toolbar button trigger - cuts the selected field value to the clipboard when the Cut button is pressed (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_COPY | PB_BLK.PB_COPY (inherited) | Inherited toolbar button trigger - copies the selected field value to the clipboard when the Copy button is pressed (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PASTE | PB_BLK.PB_PASTE (inherited) | Inherited toolbar button trigger - pastes clipboard content into the current field when the Paste button is pressed (inherited) |

### 8.8 Canvas and Window Inventory

**Windows:**

| Window | Title | Primary Canvas |
| :--- | :--- | :--- |
| WIN_ERR | (none - inherited DPL error window; displays error messages surfaced by the CB_ERR block) | CN_ERR |
| WN_MAIN | Technical Productivity Report (1.1.2) | CN_MAIN |

**Canvases:**

| Canvas | Type | Window |
| :--- | :--- | :--- |
| CN_TOOL | Content | WN_MAIN (inherited DPL toolbar canvas hosting the PB_BLK toolbar buttons) |
| CN_MAIN | Content | WN_MAIN (main business canvas displaying the CB_DOC_QUERY search panel and CB_DOC results grid) |
| CN_ERR | Content | WIN_ERR (inherited DPL error canvas hosting the CB_ERR error display block) |

---

### 8.9 Editors

*No editors found in vr_bshop_tech_prod_fmb.xml.*

### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

#### 8.10.1 Visual Attributes (form-defined)

*0 VisualAttribute elements defined at form level (not inherited from DPL.olb).*

*No form-local visual attributes found in vr_bshop_tech_prod_fmb.xml.*

#### 8.10.2 Property Classes (form-defined)

*Form-local PropertyClass elements.*

*No form-local property classes found in vr_bshop_tech_prod_fmb.xml.*

#### 8.10.3 Object Groups

*Object groups bundle inherited triggers and visual objects applied form-wide at runtime.*

| Object Group Child | Type |
| :--- | :--- |
| KEY-OTHERS | Inherited trigger |
| KEY-NEXT-ITEM | Inherited trigger |
| KEY-PREV-ITEM | Inherited trigger |
| KEY-NXTBLK | Inherited trigger |
| KEY-PRVBLK | Inherited trigger |
| KEY-DOWN | Inherited trigger |
| KEY-UP | Inherited trigger |
| CN_ERR | Inherited canvas |
| VA_DISP | Inherited visualattribute |
| CB_ERR | Inherited block |
| VA_LOV | Inherited visualattribute |
| VA_TRNI_DT | Inherited visualattribute |
| VA_TITLE | Inherited visualattribute |
| VA_ALERT | Inherited visualattribute |
| VA_BUTN | Inherited visualattribute |
| VA_TEXT | Inherited visualattribute |
| VA_MPROMPT | Inherited visualattribute |
| VA_OPROMPT | Inherited visualattribute |
| VA_MAND | Inherited visualattribute |
| VA_NUM | Inherited visualattribute |
| VA_DESC | Inherited visualattribute |
| VA_ICONIC_BUTN | Inherited visualattribute |
| VA_RB | Inherited visualattribute |
| VA_CB | Inherited visualattribute |
| WN_MAIN | Inherited window |
| POP_MAIN | Inherited trigger |
| CN_MAIN | Inherited canvas |
| CN_TOOL | Inherited canvas |
| PB_BLK | Inherited block |
| AL_ERRINFO | Inherited alert |
| AL_NOTE | Inherited alert |
| AL_CONFIRM | Inherited alert |
| WIN_ERR | Inherited window |
| AL_PRINT | Inherited alert |
| FT_SAVE | Inherited trigger |
| FT_CANCEL | Inherited trigger |
| FT_INSERT | Inherited trigger |
| FT_DEL | Inherited trigger |
| FT_LIST | Inherited trigger |
| FT_PRINT | Inherited trigger |
| WHEN-NEW-FORM-INSTANCE | Inherited trigger |

### 8.11 DataSourceColumn Inventory

*No DataSourceColumns found in vr_bshop_tech_prod_fmb.xml.*

## 9. Object Library

*The form module inherits from two Object Library files: the dealership platform library (DPL) for property classes and visual attributes, and the Oracle WebUtil library (WEBUTIL) for the client-utility object group. The entries below catalogue all objects defined in the supplied OLB files.*

Source OLB file(s): DPL_olb.xml, webutil_olb.xml

| Name | Type | Description | Used By (count) | Sample Items |
| ---- | ---- | ----------- | --------------- | ------------ |
| PC_DESC | PropertyClass | Property class for descriptive text items (DPL) | not used directly in this form | N/A |
| PC_SC_DATE | PropertyClass | Property class for date items - PROPERTY CLASS FOR DATE (DPL) | not used directly in this form | N/A |
| PC_TITLE | PropertyClass | Property class for text items - PROPERTY CLASS FOR TEXT ITEMS (DPL) | not used directly in this form | N/A |
| PC_FORMAT | PropertyClass | Property class for text items - PROPERTY CLASS FOR TEXT ITEMS (DPL) | not used directly in this form | N/A |
| PC_MR_BLK | PropertyClass | Property class for multi-row blocks (DPL) | not used directly in this form | N/A |
| PC_DISP | PropertyClass | Property class for display text items - PROPERTY CLASS FOR TEXT ITEMS (DPL) | not used directly in this form | N/A |
| PC_LOV | PropertyClass | Property class for list-of-values items - PROPERTY CLASS FOR LIST OF VALUES (DPL) | not used directly in this form | N/A |
| PC_FORM | PropertyClass | Property class for the form module (DPL) | 1 | VR_BODYSHOP_TECH_PROD (form module) |
| PC_DISP_DATE | PropertyClass | Property class for display date items - PROPERTY CLASS FOR TEXT ITEMS (DPL) | not used directly in this form | N/A |
| PC_DISP_NUM | PropertyClass | Property class for display numeric items - PROPERTY CLASS FOR TEXT ITEMS (DPL) | not used directly in this form | N/A |
| PC_DATE | PropertyClass | Property class for date items - PROPERTY CLASS FOR DATE (DPL) | 2 | FROM_JC_BILL_DT, TO_BILL_DT |
| PC_DTTIME | PropertyClass | Property class for date-time items - Property class for Date and Time (DPL) | not used directly in this form | N/A |
| PC_CB | PropertyClass | Property class for check-box items (DPL) | not used directly in this form | N/A |
| PC_ALERT | PropertyClass | Property class for alert objects (DPL) | not used directly in this form | N/A |
| PC_MDATE | PropertyClass | Property class for mandatory date items - PROPERTY CLASS FOR DATE (DPL) | not used directly in this form | N/A |
| PC_RB | PropertyClass | Property class for radio-button items (DPL) | not used directly in this form | N/A |
| PC_WIND | PropertyClass | Property class for windows - PROPERTY CLASS FOR WINDOWS (DPL) | not used directly in this form | N/A |
| PC_CANV | PropertyClass | Property class for canvases (DPL) | not used directly in this form | N/A |
| PC_BUTN | PropertyClass | Property class for push buttons - PROPERTY CLASS FOR PUSH BUTTONS (DPL) | 1 | SEARCH button |
| PC_TEXT | PropertyClass | Property class for text items - PROPERTY CLASS FOR TEXT ITEMS (DPL) | not used directly in this form | N/A |
| PC_MTEXT | PropertyClass | Property class for mandatory text items - PROPERTY CLASS FOR TEXT ITEMS (DPL) | not used directly in this form | N/A |
| PC_UTEXT | PropertyClass | Property class for uppercase text items - PROPERTY CLASS FOR TEXT ITEMS (DPL) | not used directly in this form | N/A |
| PC_MUTEXT | PropertyClass | Property class for mandatory uppercase text items - PROPERTY CLASS FOR TEXT ITEMS (DPL) | not used directly in this form | N/A |
| PC_NUM | PropertyClass | Property class for numeric items - PROPERTY CLASS FOR NUMERIC ITEMS (DPL) | not used directly in this form | N/A |
| PC_MNUM | PropertyClass | Property class for mandatory numeric items - PROPERTY CLASS FOR NUMERIC ITEMS (DPL) | not used directly in this form | N/A |
| PC_ICONIC_BUTN | PropertyClass | Property class for iconic push buttons - PROPERTY CLASS FOR PUSH BUTTONS (DPL) | not used directly in this form | N/A |
| PC_SCROLL | PropertyClass | Property class for scroll bars (DPL) | not used directly in this form | N/A |
| VA_CB | VisualAttribute | Check-box visual attribute; black foreground on transparent background, Arial font (DPL) | not used directly in this form | N/A |
| VA_RB | VisualAttribute | Radio-button visual attribute; black foreground on transparent background, Arial font (DPL) | not used directly in this form | N/A |
| VA_ICONIC_BUTN | VisualAttribute | Iconic button visual attribute; black foreground on transparent background (DPL) | not used directly in this form | N/A |
| VA_DESC | VisualAttribute | Descriptive text visual attribute; blue foreground on transparent background, Small Fonts (DPL) | not used directly in this form | N/A |
| VA_NUM | VisualAttribute | Numeric item visual attribute; black foreground on transparent background, Arial font (DPL) | not used directly in this form | N/A |
| VA_MAND | VisualAttribute | Mandatory field visual attribute; black foreground on transparent background, Arial font (DPL) | not used directly in this form | N/A |
| VA_OPROMPT | VisualAttribute | Optional-field prompt visual attribute; black foreground on transparent background, Arial font (DPL) | not used directly in this form | N/A |
| VA_MPROMPT | VisualAttribute | Mandatory-field prompt visual attribute; black foreground on transparent background, Arial font (DPL) | not used directly in this form | N/A |
| VA_TEXT | VisualAttribute | Standard text item visual attribute; black foreground on transparent background, Arial font (DPL) | not used directly in this form | N/A |
| VA_BUTN | VisualAttribute | Push button visual attribute; black foreground on transparent background, Arial font (DPL) | not used directly in this form | N/A |
| VA_ALERT | VisualAttribute | Alert visual attribute; black foreground on transparent background, MT Extra font (DPL) | not used directly in this form | N/A |
| VA_TITLE | VisualAttribute | Title visual attribute; blue foreground on transparent background, Arial font (DPL) | not used directly in this form | N/A |
| VA_TRNI_DT | VisualAttribute | Transaction date visual attribute; black foreground on transparent background, Courier font (DPL) | not used directly in this form | N/A |
| VA_LOV | VisualAttribute | List-of-values visual attribute; dark-blue foreground on transparent background, Arial font (DPL) | not used directly in this form | N/A |
| VA_DISP | VisualAttribute | Display item visual attribute; black foreground on transparent background, Arial font (DPL) | not used directly in this form | N/A |
| OG_GROUP | ObjectGroup | Standard form object group providing common form objects inherited from the DPL_MTPL library | 1 | Form module (OG_GROUP) |
| WEBUTIL | ObjectGroup | Oracle WebUtil client-utility object group providing client information, file, host, session, file-transfer, OLE, C API, and browser function beans (webutil_olb.xml) | 5 | WEBUTIL block items (DUMMY, WEBUTIL_CLIENTINFO_FUNCTIONS, WEBUTIL_FILE_FUNCTIONS, WEBUTIL_HOST_FUNCTIONS, WEBUTIL_SESSION_FUNCTIONS, and others) |
| WEBUTIL_NO_OLE | ObjectGroup | Oracle WebUtil object group variant without OLE support (webutil_olb.xml) | not used in this form | N/A |

---

## 10. Record Groups

*No record groups found in `vr_bshop_tech_prod_fmb.xml`.*

## 11. Referenced Database Objects

*Database tables, views, and objects accessed by the form.*

| Block | Base Table | Primary Key Item | Database Item |
| :--- | :--- | :--- | :--- |
| CB_DOC_QUERY | - | - | No |
| CB_DOC | - | - | No |

| Object | Schema | Used In | Description |
| :--- | :--- | :--- | :--- |
| `DUAL` | - | Trigger WHEN-BUTTON-PRESSED, Trigger WHEN-NEW-FORM-INSTANCE | Oracle pseudo-table - used in PB_EXCEL's WHEN-BUTTON-PRESSED trigger to generate the CSV column header row, and in WHEN-NEW-FORM-INSTANCE for initialisation-time scalar queries that require a syntactically valid FROM clause. |

**Total Referenced Objects:** 1

---

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure/Package Index

| Requirement ID | Procedure/Package | Purpose |
| -------------- | ----------------- | ------- |
| BR-001 | DBMS_APPLICATION_INFO | Registers the form module name and client information in the database session tracking registry at form startup |
| BR-004 | PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT | Calculates the number of actual working days in the selected billing date range, excluding recorded holidays and leave, to use as the productivity denominator |
| BR-004 | PKG_VTS_BODYSHOP.SF_GET_PANEL | Sums the total panel count for each repair order from the vehicle technical services detail table |
| BR-004 | SF_GET_EMP_NAME | Resolves a technician's employee code into a full display name from the employee master |
| BR-005 | VIEW_EXCEL_REP | Builds a record group from the export query, writes the results to a server-side CSV file, and opens the file in the user's browser |
| BR-005 | WEB.SHOW_DOCUMENT | Opens a server-side file in the user's browser as part of the Excel export flow |
| BR-006 | DBMS_APPLICATION_INFO | Clears the module name and client information from the database session tracking registry at form exit |
| - | GENERAL.ASK_CONFIRM | Gates every toolbar push-button action (copy, cut, delete, insert, paste, print, save, exit) behind an explicit user confirmation dialog |
| - | GENERAL.CHECK_FORM_FAILURE | Inspects form status after a commit attempt and raises FORM_TRIGGER_FAILURE if the commit did not succeed |
| - | GENERAL.DISP_TEXT | Presents informational and status messages to the user via styled alert dialogs in the ON-MESSAGE trigger |
| - | WEBUTIL_CORE.CUSTOMEVENTHANDLER | Central dispatch routine that routes all WebUtil client-side events to the appropriate WebUtil subsystem callback |
| - | WEBUTIL.ID_NULL | Checks whether a RecordGroup handle is null inside VIEW_EXCEL_REP before creating a new record group for the export query |
| - | D2KWUTIL.ATTEMPT_DLL_LOAD | WebUtil/D2KWUTIL infrastructure routine for DLL loading, called during WebUtil initialisation |
| - | D2KWUTIL.D2KWUTIL_DEBUGSTRING | WebUtil/D2KWUTIL infrastructure routine for debug string formatting |
| - | D2KWUTIL.D2KWUTIL_GETDOSENV | WebUtil/D2KWUTIL infrastructure routine for reading DOS environment variables |
| - | D2KWUTIL.D2KWUTIL_GETREGKEY | WebUtil/D2KWUTIL infrastructure routine for reading Windows registry keys |
| - | D2KWUTIL.TRANSLATETYPE | WebUtil/D2KWUTIL infrastructure routine for type translation during WebUtil operations |

### 12.2 Procedure and Package Catalogue

#### PKG_VTS_BODYSHOP

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| PKG_VTS_BODYSHOP.SF_GET_PANEL | Package Function | WHEN-BUTTON-PRESSED on `CB_DOC_QUERY.SEARCH` (inline SQL cursor) | Sums the total panel count (sum of PANEL_WNSHLD) for a given repair order from the vehicle technical services detail table (`VT_VTS`), scoped to the specified parent group, dealer map code, location code, company code, and RO number; returns zero (NVL to 0) if no record is found. Invoked once per RO in the SEARCH cursor to accumulate panel workload per technician. |
| PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT | Package Function | WHEN-BUTTON-PRESSED on `CB_DOC_QUERY.SEARCH` (inline SQL cursor); WHEN-BUTTON-PRESSED on `CB_DOC_QUERY.PB_EXCEL` | Calculates the number of working days between two dates by iterating day by day and subtracting holidays found in the WD_BTN table for the given parent group, dealer map code, and location code; returns a count of non-holiday days (zero if all days are holidays or the range is invalid). Invoked from both the SEARCH button (to compute productivity ratios per technician) and the PB_EXCEL button (to embed the same ratios in the exported CSV). |

#### SF_GET_EMP_NAME

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| SF_GET_EMP_NAME | Standalone Function | WHEN-BUTTON-PRESSED on `CB_DOC_QUERY.SEARCH` (inline SQL cursor) | Resolves a dealership employee code into a full display name (first + middle + last) by querying the employee master table (`GM_EMP`); returns a not-available placeholder if no matching employee record exists. |

#### VIEW_EXCEL_REP

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| VIEW_EXCEL_REP | Form Program Unit (Procedure) | WHEN-BUTTON-PRESSED on `CB_DOC_QUERY.PB_EXCEL` | Accepts a filename, a dynamic SQL query string, and a column name; checks whether an existing `DataRecordSet` record group must be deleted (via WEBUTIL.ID_NULL) before creating a new one from the query; reads the server export path from a configuration file (`/reports/DMS/excelpath.txt`); writes all result rows to a CSV file on the server (capped at 65,535 rows); and opens the file in the browser via `WEB.SHOW_DOCUMENT`. Raises a trigger failure with error details on any exception. |

#### DBMS_APPLICATION_INFO

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Package Procedure | PRE-FORM trigger (Form level); KEY-EXIT trigger (Form level) | Sets (at form open) or clears (at form exit) the client information tag in the Oracle database session registry, associating the session with the form module name. |
| DBMS_APPLICATION_INFO.SET_MODULE | Package Procedure | PRE-FORM trigger (Form level); KEY-EXIT trigger (Form level) | Sets (at form open) or clears (at form exit) the module name and action name in the Oracle database session registry for session monitoring and diagnostics. |

#### WEB

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| WEB.SHOW_DOCUMENT | Package Procedure | VIEW_EXCEL_REP (Form Program Unit) | Opens a server-side URL (the generated CSV file path) in the user's browser in a new browser window/tab, delivering the exported CSV file for download. |

#### GENERAL (DPL.pld)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| GENERAL.ASK_CONFIRM | PLD Library Function | WHEN-BUTTON-PRESSED on `PB_BLK.PB_COPY`, `PB_BLK.PB_CUT`, `PB_BLK.PB_DEL`, `PB_BLK.PB_EXIT`, `PB_BLK.PB_INSERT`, `PB_BLK.PB_LIST`, `PB_BLK.PB_PASTE`, `PB_BLK.PB_PRINT`, `PB_BLK.PB_SAVE`; WHEN-BUTTON-PRESSED on `WEBUTIL.DUMMY` | Presents a confirmation dialog to the user using the supplied message text and returns a numeric response code. Called from every toolbar push-button trigger to gate destructive or significant actions - copy, cut, delete, insert, paste, print, save, and exit - behind an explicit user confirmation before proceeding. |
| GENERAL.CHECK_FORM_FAILURE | PLD Library Procedure | KEY-COMMIT trigger (Form level) | Inspects the current form status after a commit attempt and raises FORM_TRIGGER_FAILURE if the operation did not succeed; ensures any commit-time database or validation error is surfaced and processing is halted cleanly rather than silently continuing. |
| GENERAL.DISP_TEXT | PLD Library Procedure | ON-MESSAGE trigger (Form level) | Displays an alert dialog using AL_ERRINFO (for errors) or AL_NOTE (for notes) with the supplied message text and title. Called from the ON-MESSAGE trigger to present informational or status messages to the user in a consistent, styled alert rather than through the default Forms message line. |

#### GENERAL - Inactive / Commented-Only Routines (DPL.pld)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| RAISE_ERROR | PLD Library Procedure | ON-ERROR trigger (Form level) - **commented out / inactive** | Looks up a message by code, formats it with type and text, and displays it via GENERAL.DISP_TEXT; raises FORM_TRIGGER_FAILURE for error-type messages. Referenced only in the inactive ON-ERROR trigger body; not part of any currently executing code path. |

#### WEBUTIL_CORE (webutil.pld)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| WEBUTIL_CORE.CUSTOMEVENTHANDLER | PLD Library Procedure | WHEN-CUSTOM-ITEM-EVENT on `WEBUTIL.WEBUTIL_BROWSER_FUNCTIONS`, `WEBUTIL.WEBUTIL_CLIENTINFO_FUNCTIONS`, `WEBUTIL.WEBUTIL_C_API_FUNCTIONS`, `WEBUTIL.WEBUTIL_FILETRANSFER_FUNCTIONS`, `WEBUTIL.WEBUTIL_FILE_FUNCTIONS`, `WEBUTIL.WEBUTIL_HOST_FUNCTIONS`, `WEBUTIL.WEBUTIL_OLE_FUNCTIONS`, `WEBUTIL.WEBUTIL_SESSION_FUNCTIONS` | Central dispatch routine for all WebUtil client-side events. Each WHEN-CUSTOM-ITEM-EVENT trigger on a WebUtil bean item forwards the fired event name and its serialised parameter string to this handler, which routes execution to the appropriate WebUtil subsystem callback. Covers browser interaction, client information, C API calls, file transfer, file system operations, host commands, OLE automation, and session management. |

#### WEBUTIL (webutil.pld - WEBUTIL_C_API)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| WEBUTIL.ID_NULL | PLD Library Function | VIEW_EXCEL_REP (Form Program Unit) | Checks whether a RecordGroup handle is null; returns TRUE if the handle's internal pointer is null, FALSE otherwise. Called in VIEW_EXCEL_REP to determine whether an existing `DataRecordSet` record group must be deleted before a new one is created from the export query. |

#### D2KWUTIL

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| D2KWUTIL.ATTEMPT_DLL_LOAD | WebUtil Infrastructure Procedure | WebUtil initialisation routines (WEBUTIL.INIT / WEBUTIL.INITWEBUTIL) | Attempts to load the WebUtil client-side DLL; part of the WebUtil bootstrap sequence that establishes the client-server bridge required for file I/O and browser interaction features used by this form. |
| D2KWUTIL.D2KWUTIL_DEBUGSTRING | WebUtil Infrastructure Function | WebUtil internal diagnostics | Formats a debug string for WebUtil diagnostic output; used internally by the WebUtil library during development and troubleshooting of client-side operations. |
| D2KWUTIL.D2KWUTIL_GETDOSENV | WebUtil Infrastructure Function | WebUtil internal environment resolution | Reads a named DOS/OS environment variable from the client machine; used by WebUtil infrastructure to resolve client-side path and environment settings. |
| D2KWUTIL.D2KWUTIL_GETREGKEY | WebUtil Infrastructure Function | WebUtil internal registry access | Reads a named key from the Windows registry on the client machine; used by WebUtil infrastructure to retrieve client configuration values. |
| D2KWUTIL.TRANSLATETYPE | WebUtil Infrastructure Function | WebUtil internal type handling | Translates internal WebUtil type identifiers to their string representations; used by WebUtil infrastructure during parameter marshalling for client-side function calls. |

#### SET_GLOBAL (Form Program Unit - active, no active callers)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| SET_GLOBAL | Form Program Unit (Procedure) | No active callers identified (its only reference is in the commented-out KEY-CLRFRM body) | Initialises the session pagination variables (from-record, to-record, and increment) to fixed default values; the procedure is defined and active but is not called by any currently executing code path. |

## 13. Package Procedure Specifications

*Behavioural requirements for each database package invoked from the form. Only packages referenced in the form XML that have a matching source `.pck` file in the input directory are listed. Descriptions are derived from the package bodies in the uploaded PCK sources.*

| ID | Package | Description | Business Requirement | Acceptance Criteria |
| :--- | :--- | :--- | :--- | :--- |
| BR-T-PKG-VTS-BODYSHOP | PKG_VTS_BODYSHOP | Bodyshop VTS (Vehicle Tracking System) analytics package - provides two scalar functions: `sf_get_panel` retrieves the total panel count for a repair order from the VT_VTS table, and `sf_get_working_day_cnt` calculates the number of working days in a date range by excluding holidays registered in the WD_BTN table | The form depends on this package to compute bodyshop technician productivity metrics: working-day count for the selected period and panel workload per repair order - both are required to populate and export the productivity report | `sf_get_panel` returns a non-negative number for each RO from VT_VTS; `sf_get_working_day_cnt` returns a count ≥ 0 excluding dates listed as holidays in WD_BTN; both functions are invoked for the correct dealer/location/parent-group scope; zero is returned when no matching record exists |

**Total Matched Packages:** 1

## 14. Database Package Catalogue

*Detailed specifications for each database package routine called from the form, including signatures and business rules.*
**Source PCK file(s):** PKG_VTS_BODYSHOP.pck

| Source File (.pck) | Package | Routine Name | Type | Definition (signature / excerpt) | Called From | Purpose |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| PKG_VTS_BODYSHOP.pck | PKG_VTS_BODYSHOP | sf_get_panel | Function | function sf_get_panel(p_pgroup varchar2, p_dealermap number, p_loc varchar2, p_comp varchar2, p_ronum varchar2) | Trigger: WHEN-BUTTON-PRESSED in CB_DOC_QUERY.SEARCH | Returns the total panel count (sum of PANEL_WNSHLD) for a given repair order from the VT_VTS table, scoped to the specified dealer group, dealer map, and location. Accepts parent group, dealer map code, location code, company code, and RO number; returns a NUMBER (NVL to 0 if no record found). Invoked once per RO in the SEARCH cursor to accumulate panel workload for each technician. |
| PKG_VTS_BODYSHOP.pck | PKG_VTS_BODYSHOP | sf_get_working_day_cnt | Function | function sf_get_working_day_cnt(p_pgroup varchar2, p_dealermap number, p_loc varchar2, p_frm_dt date, p_to_dt date) | Trigger: WHEN-BUTTON-PRESSED in CB_DOC_QUERY.PB_EXCEL, Trigger: WHEN-BUTTON-PRESSED in CB_DOC_QUERY.SEARCH | Calculates the number of working days between two dates by iterating day by day and subtracting holidays found in the WD_BTN table for the given dealer group, dealer map, and location. Accepts parent group, dealer map code, location code, from date, and to date; returns a NUMBER count of non-holiday days. Invoked from both the SEARCH button (to compute productivity ratios per technician) and the PB_EXCEL button (to embed the same ratios in the exported CSV). |

**Total Matched Package Routines (called from form XML):** 2

---

**Function return values:**

| Function | Returns | Values | Description |
| :--- | :--- | :--- | :--- |
| sf_get_panel | Number | 0 or positive integer (panel count) | Total number of panels recorded for the repair order in the VT_VTS table; zero if no record exists |
| sf_get_working_day_cnt | Number | 0 or positive integer (day count) | Count of calendar days in the range that are not listed as holidays in WD_BTN; zero if all days are holidays or range is invalid |

## 15. PLD Procedure Call Sites

*Maps each program-library routine to its call sites within triggers and program units. Behaviour descriptions are derived from the uploaded ``.pld`` sources.*

### DPL.pld (`general`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ASK_CONFIRM | Function | Function(confirm_msg VARCHAR2) RETURN NUMBER | Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_COPY, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_CUT, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_DEL, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_EXIT, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_INSERT, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_LIST, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_PASTE, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_PRINT, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_SAVE, Trigger: WHEN-BUTTON-PRESSED in WEBUTIL.DUMMY | Presents a confirmation dialog to the user using the supplied message text and returns a numeric response code. Called from every toolbar push-button trigger (inherited) to gate destructive or significant actions - such as copy, cut, delete, insert, paste, print, save, and exit - behind an explicit user confirmation before proceeding. |
| CHECK_FORM_FAILURE | Procedure | Procedure() | Trigger: KEY-COMMIT in Form | Inspects the current form status after a commit attempt and raises FORM_TRIGGER_FAILURE if the operation did not succeed. Called from the KEY-COMMIT trigger to ensure that any commit-time database or validation error is surfaced and processing is halted cleanly rather than silently continuing. |
| DISP_TEXT | Procedure | Procedure(text_string VARCHAR2, title_string VARCHAR2) | Trigger: ON-MESSAGE in Form | Displays an alert dialog using AL_ERRINFO (for errors) or AL_NOTE (for notes) with the supplied message text and title. Called from the ON-MESSAGE trigger to present informational or status messages to the user in a consistent, styled alert rather than through the default Forms message line. |

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``vr_bshop_tech_prod_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| RAISE_ERROR | Procedure | Procedure(mesg_code IN VARCHAR2) | Trigger: ON-ERROR in Form | **COMMENTED OUT / INACTIVE** - looks up a message by code, formats it with type and text, and displays it via GENERAL.DISP_TEXT; raises FORM_TRIGGER_FAILURE for error-type messages. Referenced only in the inactive ON-ERROR trigger body. |

**Total Active Routines:** 3 of 24 in DPL.pld source
**Inactive / commented-only routines:** 1

---

### webutil.pld (`WEBUTIL_CORE`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| CustomEventHandler | Procedure | Procedure(EventName in VARCHAR2, EventParameters in VARCHAR2) | Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_BROWSER_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_CLIENTINFO_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_C_API_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_FILETRANSFER_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_FILE_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_HOST_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_OLE_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_SESSION_FUNCTIONS | Central dispatch routine for all WebUtil client-side events. Each WHEN-CUSTOM-ITEM-EVENT trigger on a WebUtil bean item forwards the fired event name and its serialised parameter string to this handler, which routes execution to the appropriate WebUtil subsystem callback. Covers the full range of WebUtil functional areas: browser interaction, client information, C API calls, file transfer, file system operations, host commands, OLE automation, and session management. |

**Total Active Routines:** 1 of 39 in webutil.pld source

---

### webutil.pld (`WEBUTIL_C_API`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ID_NULL | Function | Function(handle IN Pointer) RETURN BOOLEAN | ProgramUnit: VIEW_EXCEL_REP | Checks whether a RecordGroup handle is null. Returns TRUE if the handle's internal pointer is null, FALSE otherwise. Called in VIEW_EXCEL_REP to determine whether an existing 'DataRecordSet' record group must be deleted before a new one is created from the export query. |

**Total Active Routines:** 1 of 28 in webutil.pld source

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| ID | Service Name | Database Object | Input Parameters | Output | Business Function | API Endpoint Suggestion |
| -- | ------------ | --------------- | ---------------- | ------ | ----------------- | ----------------------- |
| MS-001 | Technician Productivity Query Service | VH_RO, SF_GET_EMP_NAME, PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT, PKG_VTS_BODYSHOP.SF_GET_PANEL | dealerMapCd, parentGroup, locCd, fromBillDate, toBillDate | Array of technician productivity records: technician name, workingDays, vehiclesRepaired, panelCount, techVehicleProductivity, panelProductivity | Retrieves bodyshop productivity metrics per technician for a specified billing date range at a dealership/location, grouping billed Body and Paint repair orders by service employee and calculating per-day ratios | GET /api/bodyshop/technician-productivity?dealerMapCd={}&parentGroup={}&locCd={}&fromBillDate={}&toBillDate={} |
| MS-002 | Working Day Count Service | PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT, WD_BTN | parentGroup, dealerMapCd, locCd, fromDate, toDate | Integer count of actual working days | Calculates the number of actual working days within a date range for a dealership/location by excluding days recorded as holidays or leave in the working-day register | GET /api/bodyshop/working-days?parentGroup={}&dealerMapCd={}&locCd={}&fromDate={}&toDate={} |
| MS-003 | Panel Count Service | PKG_VTS_BODYSHOP.SF_GET_PANEL, VT_VTS | parentGroup, dealerMapCd, locCd, compFa, roNum | Numeric panel count for the repair order | Retrieves the total number of body panels repaired on a specific repair order from the vehicle technical services detail records | GET /api/bodyshop/panel-count?parentGroup={}&dealerMapCd={}&locCd={}&compFa={}&roNum={} |
| MS-004 | Employee Name Lookup Service | SF_GET_EMP_NAME, GM_EMP | dealerMapCd, locCd, empCd | Full employee display name (string) | Resolves a dealership employee code into a full display name by querying the employee master; returns a not-available indicator if no matching record is found | GET /api/employees/name?dealerMapCd={}&locCd={}&empCd={} |
| MS-005 | Productivity Export Service | VIEW_EXCEL_REP logic, VH_RO, PKG_VTS_BODYSHOP | dealerMapCd, parentGroup, locCd, fromBillDate, toBillDate | CSV file stream | Generates and delivers a CSV export file containing the technician productivity data for the specified date range and dealership, suitable for download and analysis in a spreadsheet | POST /api/bodyshop/technician-productivity/export |

**Total Microservices Identified: 5**

---

## 17. Workflows

| ID | Workflow Name | Trigger Event | Steps | Decision Points | End State |
| -- | ------------- | ------------- | ----- | --------------- | --------- |
| WF-001 | Form Open and Session Registration | User opens the Bodyshop Technician Productivity report form (PRE-FORM event) | 1. System registers the module name `vr_bshop_tech_prod` and clears any prior action label in the database session registry | None | Form screen is presented to the user with the session registered |
| WF-002 | Billing Date Range Entry and Validation | User enters the From Bill Date and tabs to the next field (WHEN-VALIDATE-ITEM on From Bill Date; KEY-NEXT-ITEM on From Bill Date) | 1. User enters a value in From Bill Date. 2. System checks if the value is blank. 3. System checks if the value is in the future. 4. Cursor advances to To Bill Date field | If blank -> alert and block (BR-002-ES-01); if future date -> alert and block (BR-002-ES-02); if valid -> cursor moves to To Bill Date | From Bill Date accepted and cursor on To Bill Date field |
| WF-003 | To Bill Date Validation and Default | User enters the To Bill Date and tabs off (WHEN-VALIDATE-ITEM on To Bill Date) | 1. User enters a value in To Bill Date (or leaves it blank). 2. System checks if value is in the future. 3. System checks if value is before From Bill Date. 4. System checks if span exceeds 31 days. 5. If still blank after all checks, system defaults To Bill Date to today | Future date -> alert and block (BR-003-ES-01); earlier than From Date -> alert and block (BR-003-ES-02); span > 31 days -> alert, focus returns to To Bill Date (BR-003-ES-03); blank after checks -> defaulted to today | To Bill Date accepted; both filter dates populated |
| WF-004 | Technician Productivity Search | User presses the Search button (WHEN-BUTTON-PRESSED on Search button) | 1. System re-validates the To Bill Date is not in the future. 2. System re-validates the To Bill Date is not before the From Bill Date. 3. System queries VH_RO for Body and Paint repair orders billed in the range, grouped by technician. 4. For each technician: system resolves the employee name, sums panel counts, and calculates working days. 5. System clears the results area and populates one row per technician. 6. Focus moves to the Export to Excel button | Re-validation failure -> alert and abort (BR-004-ES-01 or BR-004-ES-02); valid -> query executes and results are displayed | Productivity results displayed per technician; focus on Export to Excel button |
| WF-005 | Productivity Data Export to CSV | User presses the Export to Excel button (WHEN-BUTTON-PRESSED on Export to Excel button) | 1. System builds the export query mirroring the search results. 2. System stores the query text in the internal query-text field. 3. System calls VIEW_EXCEL_REP: derives filename from user identity and timestamp, validates the output path (redirects if the path includes space characters in folder names), creates a record group from the query, applies the row-count cap, reads the server path configuration, writes the CSV file, and opens it in the browser | File path contains space characters in folder names -> redirect and info message (BR-005-IC-01); row count > 65,535 -> truncation and info message (BR-005-IC-02); any other error -> error message and abort (BR-005-ES-01) | CSV file opened in user's browser for download |
| WF-006 | Form Exit and Session Cleanup | User presses the exit key (KEY-EXIT event) | 1. System erases session pagination global variables (from-record, to-record, increment). 2. System clears the client information tag, module name, and action name from the database session registry. 3. System closes the form without checking for unsaved changes | None | Form closed; session context cleared from database registry |
| WF-007 | Clear Form and Report Description Restore | User triggers the clear-form key (KEY-CLRFRM event) | 1. System reads the report description from the session global store. 2. System writes the value back to the report description display field on screen. (All remaining clear-form reset logic is inactive and does not execute.) | None | Report description field refreshed with the session value |

**Total Workflows Identified: 7**

---

## 18. PLD-Backed Logic

*Maps shared library routines to their business function and suggested API contracts.*

### webutil.pld (`CLIENT_IMAGE`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | ID_NULL | Business Logic | ProgramUnit: VIEW_EXCEL_REP | /api/v1/pld/id_null | When a RecordGroup handle is evaluated, then returns TRUE if the handle is null so that the caller can decide whether to delete the existing group before creating a new one |


---

### DPL.pld (`general`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-002 | DISP_TEXT | Business Logic | ProgramUnit: EXCEL_GENERATION, Trigger: ON-ERROR in Form | /api/v1/pld/disp_text | **COMMENTED OUT / INACTIVE** - when called with a message and title, then displays an alert dialog to the user; referenced only in inactive code |
| PLD-003 | RAISE_ERROR | Validation | Trigger: ON-ERROR in Form | /api/v1/pld/raise_error | **COMMENTED OUT / INACTIVE** - when an error code is provided, then retrieves the message text and raises FORM_TRIGGER_FAILURE for error-type messages; referenced only in inactive ON-ERROR code |


---

### D2kwutil.pld (`Win_API`)

*No routines from ``D2kwutil.pld`` are referenced in ``vr_bshop_tech_prod_fmb.xml``.*

---

---

## 19. PCK-Backed Logic

*Maps database package routines to their business rules and suggested API contracts.*

| ID | Package.Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ------------- | ---- | ---------- | ------------- | --------------------- |
| PCK-001 | PKG_VTS_BODYSHOP.sf_get_panel | Business Logic | Trigger: WHEN-BUTTON-PRESSED in CB_DOC_QUERY.SEARCH | /api/v1/packages/pkg_vts_bodyshop/sf_get_panel | When a repair order is queried, then the total panel count is retrieved from the VT_VTS table for the specified dealer, location, and RO number |
| PCK-002 | PKG_VTS_BODYSHOP.sf_get_working_day_cnt | Business Logic | Trigger: WHEN-BUTTON-PRESSED in CB_DOC_QUERY.PB_EXCEL, Trigger: WHEN-BUTTON-PRESSED in CB_DOC_QUERY.SEARCH | /api/v1/packages/pkg_vts_bodyshop/sf_get_working_day_cnt | When a date range is provided, then the number of working days is calculated by excluding holidays registered in WD_BTN for the specified dealer and location |

---

---

## 20. System Interfaces

### 20.1 Database Integrations

| Interface Name | Type | Purpose | Data Flow | Error Handling |
| -------------- | ---- | ------- | --------- | -------------- |
| Repair Order Table (VH_RO) | Database Table (SELECT) | Primary data source for the productivity report; provides billed repair orders grouped by technician for the selected billing date range and Body and Paint repair category | Form -> Database (read-only SELECT in cursor within WHEN-BUTTON-PRESSED on Search and Export to Excel buttons) | Query failures would surface as unhandled exceptions in the calling trigger; no explicit error handling for VH_RO SELECT in the form's trigger code |
| Employee Master (GM_EMP) via SF_GET_EMP_NAME | Database Table (SELECT via function) | Resolves service employee codes to full technician display names | Form -> Database (read-only SELECT inside SF_GET_EMP_NAME function, called from the productivity query cursor) | On NO_DATA_FOUND the function returns a not-available placeholder; no error is propagated to the form |
| Vehicle Technical Services Detail (VT_VTS) via PKG_VTS_BODYSHOP.SF_GET_PANEL | Database Table (SELECT via package function) | Provides panel count per repair order for productivity calculations | Form -> Database (read-only SELECT inside SF_GET_PANEL function, called from the productivity query cursor) | Returns zero if no records found; no error is raised |
| Working Day Register (WD_BTN) via PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT | Database Table (SELECT via package function) | Provides non-working day records to calculate actual working days in the billing period | Form -> Database (read-only SELECT inside SF_GET_WORKING_DAY_CNT, called from the productivity query cursor) | On any exception for a specific day, the holiday count defaults to zero and the day is counted as a working day; processing continues |
| Oracle Database Session Registry (DBMS_APPLICATION_INFO) | Oracle Built-in Package | Registers and clears the form module name and client information tag in the database session monitoring registry | Form -> Database (at form open via PRE-FORM; at form exit via KEY-EXIT) | No explicit error handling; failure at PRE-FORM level would prevent the form from opening |

### 20.2 External System Integrations

| System Name | Integration Type | Purpose | Protocol | Endpoint | Data Exchange | Success / Error Codes |
| ----------- | ---------------- | ------- | -------- | -------- | ------------- | --------------------- |
| Oracle WebUtil (WEB.SHOW_DOCUMENT) | Oracle Forms Client Library | Delivers the generated CSV export file to the user's browser for download after it has been written to the server | Oracle Forms built-in web package call | Server-side file URL constructed from the export path configuration | Server-side CSV file opened in user's browser as a new document | Success: file opens in browser; Error: any exception in VIEW_EXCEL_REP raises FORM_TRIGGER_FAILURE and displays *"Error  - "* with error code and text |
| Export Path Configuration File (/reports/DMS/excelpath.txt) | Server File (TEXT_IO read) | Provides the server-side directory path where the CSV export file is written; read at export time by the VIEW_EXCEL_REP program unit | Server file read via Oracle TEXT_IO (literal path: `/reports/DMS/excelpath.txt`) | `/reports/DMS/excelpath.txt` on the forms server | Single line of text: the server directory path for CSV output | Success: path read and used for file creation; Error: any exception in VIEW_EXCEL_REP raises FORM_TRIGGER_FAILURE and displays *"Error  - "* with error code and text |

### 20.3 Report Integrations

*No Oracle Reports integrations are defined in this form. The productivity data export is handled directly by the VIEW_EXCEL_REP form program unit writing a CSV file to the server and opening it in the browser; no RUN_PRODUCT, RUN_REPORT, or equivalent Oracle Reports calls are present in this form's active code.*

| Report Name | Report Server | Parameters | Output Format | Trigger |
| ----------- | ------------- | ---------- | ------------- | ------- |

---

### 20.3.1 Parameters Passed to the Report

This form does not pass parameters to an Oracle Report. No report parameters were identified in the form sources.

## 21. Procedure and Function Business Rule Catalogue

End-to-end business requirement specification for every stored procedure and function referenced by the VR_BODYSHOP_TECH_PROD form.

### 21.1 Catalogue Index

68 procedures/functions - each SP ID links to its detailed specification in Section 21.2.

| SP Index | Routine Name |
| :--- | :--- |
| [SP-001](#SP-001--VIEW_EXCEL_REP) | VIEW_EXCEL_REP |
| [SP-002](#SP-002--D2KWUTIL.ATTEMPT_DLL_LOAD) | D2KWUTIL.ATTEMPT_DLL_LOAD |
| [SP-003](#SP-003--D2KWUTIL.D2KWUTIL_DEBUGSTRING) | D2KWUTIL.D2KWUTIL_DEBUGSTRING |
| [SP-004](#SP-004--D2KWUTIL.D2KWUTIL_GETDOSENV) | D2KWUTIL.D2KWUTIL_GETDOSENV |
| [SP-005](#SP-005--D2KWUTIL.D2KWUTIL_GETREGKEY) | D2KWUTIL.D2KWUTIL_GETREGKEY |
| [SP-006](#SP-006--D2KWUTIL.TRANSLATETYPE) | D2KWUTIL.TRANSLATETYPE |
| [SP-007](#SP-007--GENERAL.ASK_CONFIRM) | GENERAL.ASK_CONFIRM |
| [SP-008](#SP-008--GENERAL.CHECK_FORM_FAILURE) | GENERAL.CHECK_FORM_FAILURE |
| [SP-009](#SP-009--GENERAL.DISP_TEXT) | GENERAL.DISP_TEXT |
| [SP-010](#SP-010--PKG_VTS_BODYSHOP.SF_GET_PANEL) | PKG_VTS_BODYSHOP.SF_GET_PANEL |
| [SP-011](#SP-011--PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT) | PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT |
| [SP-012](#SP-012--WEBUTIL.BLOCKING) | WEBUTIL.BLOCKING |
| [SP-013](#SP-013--WEBUTIL.CHECKLIBS) | WEBUTIL.CHECKLIBS |
| [SP-014](#SP-014--WEBUTIL.CLEARCALLBACKTRIGGER) | WEBUTIL.CLEARCALLBACKTRIGGER |
| [SP-015](#SP-015--WEBUTIL.CLOSEBLOB) | WEBUTIL.CLOSEBLOB |
| [SP-016](#SP-016--WEBUTIL.CLOSEFILE) | WEBUTIL.CLOSEFILE |
| [SP-017](#SP-017--WEBUTIL.DOWNLOADFROMURLINT) | WEBUTIL.DOWNLOADFROMURLINT |
| [SP-018](#SP-018--WEBUTIL.ERROR) | WEBUTIL.ERROR |
| [SP-019](#SP-019--WEBUTIL.ERRORALERT) | WEBUTIL.ERRORALERT |
| [SP-020](#SP-020--WEBUTIL.EXECUTE) | WEBUTIL.EXECUTE |
| [SP-021](#SP-021--WEBUTIL.FCLOSE) | WEBUTIL.FCLOSE |
| [SP-022](#SP-022--WEBUTIL.FOPEN) | WEBUTIL.FOPEN |
| [SP-023](#SP-023--WEBUTIL.GETCALLBACKTRIGGER) | WEBUTIL.GETCALLBACKTRIGGER |
| [SP-024](#SP-024--WEBUTIL.GETCLIENTOSFAMILY) | WEBUTIL.GETCLIENTOSFAMILY |
| [SP-025](#SP-025--WEBUTIL.GETCLIENTSETTING) | WEBUTIL.GETCLIENTSETTING |
| [SP-026](#SP-026--WEBUTIL.GETIMPLCLASS) | WEBUTIL.GETIMPLCLASS |
| [SP-027](#SP-027--WEBUTIL.GETLASTERROR) | WEBUTIL.GETLASTERROR |
| [SP-028](#SP-028--WEBUTIL.GETLASTERRORARGS) | WEBUTIL.GETLASTERRORARGS |
| [SP-029](#SP-029--WEBUTIL.GETNUMBER) | WEBUTIL.GETNUMBER |
| [SP-030](#SP-030--WEBUTIL.GETOSFAMILY) | WEBUTIL.GETOSFAMILY |
| [SP-031](#SP-031--WEBUTIL.GETOUTPUT) | WEBUTIL.GETOUTPUT |
| [SP-032](#SP-032--WEBUTIL.GETPROPERTY) | WEBUTIL.GETPROPERTY |
| [SP-033](#SP-033--WEBUTIL.GETSTRING) | WEBUTIL.GETSTRING |
| [SP-034](#SP-034--WEBUTIL.GETVAR) | WEBUTIL.GETVAR |
| [SP-035](#SP-035--WEBUTIL.GET_LINE) | WEBUTIL.GET_LINE |
| [SP-036](#SP-036--WEBUTIL.GET_STANDARD_OUTPUT) | WEBUTIL.GET_STANDARD_OUTPUT |
| [SP-037](#SP-037--WEBUTIL.ID_NULL) | WEBUTIL.ID_NULL |
| [SP-038](#SP-038--WEBUTIL.INIT) | WEBUTIL.INIT |
| [SP-039](#SP-039--WEBUTIL.INITWEBUTIL) | WEBUTIL.INITWEBUTIL |
| [SP-040](#SP-040--WEBUTIL.ISERROR) | WEBUTIL.ISERROR |
| [SP-041](#SP-041--WEBUTIL.IS_OPEN) | WEBUTIL.IS_OPEN |
| [SP-042](#SP-042--WEBUTIL.LENGTH) | WEBUTIL.LENGTH |
| [SP-043](#SP-043--WEBUTIL.LOG) | WEBUTIL.LOG |
| [SP-044](#SP-044--WEBUTIL.POPULATEPROPERTYBUNDLE) | WEBUTIL.POPULATEPROPERTYBUNDLE |
| [SP-045](#SP-045--WEBUTIL.PUT_LINE) | WEBUTIL.PUT_LINE |
| [SP-046](#SP-046--WEBUTIL.READFROMPROPERTYBUNDLE) | WEBUTIL.READFROMPROPERTYBUNDLE |
| [SP-047](#SP-047--WEBUTIL.READTRANSFROMMSGBUNDLE) | WEBUTIL.READTRANSFROMMSGBUNDLE |
| [SP-048](#SP-048--WEBUTIL.REGISTERBEAN) | WEBUTIL.REGISTERBEAN |
| [SP-049](#SP-049--WEBUTIL.REGISTER_FUNCTION) | WEBUTIL.REGISTER_FUNCTION |
| [SP-050](#SP-050--WEBUTIL.RELEASE_PROCESS) | WEBUTIL.RELEASE_PROCESS |
| [SP-051](#SP-051--WEBUTIL.SETCLIENTSETTING) | WEBUTIL.SETCLIENTSETTING |
| [SP-052](#SP-052--WEBUTIL.SETDATA) | WEBUTIL.SETDATA |
| [SP-053](#SP-053--WEBUTIL.SETPROPERTY) | WEBUTIL.SETPROPERTY |
| [SP-054](#SP-054--WEBUTIL.SHOWBEANS) | WEBUTIL.SHOWBEANS |
| [SP-055](#SP-055--WEBUTIL.WRITEDATA) | WEBUTIL.WRITEDATA |
| [SP-056](#SP-056--WEBUTIL_CORE.CUSTOMEVENTHANDLER) | WEBUTIL_CORE.CUSTOMEVENTHANDLER |
| [SP-057](#SP-057--ADD_ERROR) | ADD_ERROR |
| [SP-058](#SP-058--ADD_EXTERNAL_ERRORS) | ADD_EXTERNAL_ERRORS |
| [SP-059](#SP-059--BOOLTOCHAR) | BOOLTOCHAR |
| [SP-060](#SP-060--CLEAN_ERROR_STACK) | CLEAN_ERROR_STACK |
| [SP-061](#SP-061--DEBUGLOG) | DEBUGLOG |
| [SP-062](#SP-062--GET_ENVIRONMENT_STRING) | GET_ENVIRONMENT_STRING |
| [SP-063](#SP-063--READ_REGISTRY) | READ_REGISTRY |
| [SP-064](#SP-064--REGISTER_FUNCTION_CALL) | REGISTER_FUNCTION_CALL |
| [SP-065](#SP-065--SETDEBUG) | SETDEBUG |
| [SP-066](#SP-066--SF_GET_EMP_NAME) | SF_GET_EMP_NAME |
| [SP-067](#SP-067--STRIPDIRSEP) | STRIPDIRSEP |
| [SP-068](#SP-068--WINDEBUG) | WINDEBUG |

---

### 21.2 Detailed Specifications

#### SP-001 - VIEW_EXCEL_REP

**Invoked From:**

- vr_bshop_tech_prod_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

PARAMETERS (N/A / CN_MAIN)

---

**Purpose**

Generates a CSV export file from a dynamic SQL query and delivers it to the user's browser for download. The procedure derives a unique filename from the current user identity and timestamp, builds a record group from the supplied query, reads the server-side export directory from a configuration file, writes each result row to the server file using TEXT_IO, and opens the file in the browser via WEB.SHOW_DOCUMENT. If any step fails, the error code and message are displayed and the export is aborted.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_file_name | VARCHAR2 | IN |
| p_query | VARCHAR2 | IN |
| p_column_name | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.FCLOSE ([SP-021](#SP-021--WEBUTIL.FCLOSE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.FOPEN ([SP-022](#SP-022--WEBUTIL.FOPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_LINE ([SP-035](#SP-035--WEBUTIL.GET_LINE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ID_NULL ([SP-037](#SP-037--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.PUT_LINE ([SP-045](#SP-045--WEBUTIL.PUT_LINE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Derive the export filename by concatenating the current logged-in user's identity (read from :global.userid) with the current date and time formatted as YYYYMMDDHHMISS, then append a .csv extension to create a unique filename.
- Step 2 - If the derived filename is not null, assign it to the output FILENAME variable; otherwise take no action.
- Step 3 - Check whether the FILENAME contains any space character. If so, redirect the filename to the C:\ root drive using only the base filename portion and display an informational message advising the user that the file will be stored on the C drive because the original path contains spaces in a folder name.
- Step 4 - Check whether a record group named 'DataRecordSet' already exists using FIND_GROUP and ID_NULL. If it exists, delete it with DELETE_GROUP to avoid conflicts before creating a new one.
- Step 5 - Create a new record group named 'DataRecordSet' from the provided SQL query using CREATE_GROUP_FROM_QUERY, then populate it with POPULATE_GROUP.
- Step 6 - Retrieve the row count of the populated record group using GET_GROUP_ROW_COUNT. If the count exceeds 65,536, display a truncation warning message with MESSAGE and cap the effective row count at 65,535.
- Step 7 - Construct the server-side file path by prepending '/iashome/ias/reports/printer/' to the base filename portion (extracted after the last backslash).
- Step 8 - Open the export path configuration file '/reports/DMS/excelpath.txt' for reading using TEXT_IO.FOPEN, read the server directory path from the first line with TEXT_IO.GET_LINE, and close the file with TEXT_IO.FCLOSE.
- Step 9 - Build the full server output file path (formserverpath) by concatenating the directory path read from the configuration file with the base filename portion.
- Step 10 - Open the server-side output CSV file at the path derived in Step 7 for writing using TEXT_IO.FOPEN.
- Step 11 - Locate the target column in the record group by calling FIND_COLUMN with the composite name 'DataRecordSet.<p_column_name>'. Iterate over each row from 1 to the effective row count, retrieve the cell value with GET_GROUP_CHAR_CELL, and write it as a line to the output file with TEXT_IO.PUT_LINE.
- Step 12 - Close the output CSV file with TEXT_IO.FCLOSE, then open the file in the user's browser in a new window using WEB.SHOW_DOCUMENT with the formserverpath constructed in Step 9.
- Step 13 - If any unexpected exception occurs during any step, display the system error code and error text to the user via MESSAGE and raise a Form_trigger_failure to abort the export.

---
**Decision Points**

DP-001

Condition:
The derived filename variable (vcFile) is null

TRUE:
Take no action; the FILENAME variable remains unset

FALSE:
Assign the derived filename to the FILENAME variable

---

DP-002

Condition:
The FILENAME contains one or more space characters (INSTR(FILENAME,' ') > 0)

TRUE:
Redirect the output path to the C:\ root drive using only the base filename portion and display an informational message to the user

FALSE:
Continue with the original FILENAME and path

---

DP-003

Condition:
A record group named 'DataRecordSet' already exists (FIND_GROUP returns a non-null handle as confirmed by ID_NULL)

TRUE:
Delete the existing record group with DELETE_GROUP before creating a new one

FALSE:
Proceed directly to create the new record group

---

DP-004

Condition:
The row count returned by GET_GROUP_ROW_COUNT exceeds 65,536

TRUE:
Display a truncation warning message via MESSAGE and cap the effective row count at 65,535

FALSE:
Proceed with the full row count as returned

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The export filename must always be derived from the current user identity and a timestamp (YYYYMMDDHHMISS) to guarantee uniqueness across concurrent export operations.
- BR-002 - If the generated output path contains space characters in any folder name, the file must be redirected to the C:\ root drive and the user must be notified; this prevents file-save failures caused by spaces in directory paths.
- BR-003 - Any existing record group named 'DataRecordSet' must be deleted before a new export record group is created, to prevent conflicts with prior export operations.
- BR-004 - The number of rows written to the CSV export file must not exceed 65,535; if the query returns more than 65,536 rows the export is capped at this limit and the user is notified via MESSAGE.
- BR-005 - The server-side export directory is determined at runtime by reading the first line of the configuration file '/reports/DMS/excelpath.txt'; this path is not hardcoded in the procedure.
- BR-006 - The completed CSV file is delivered to the user by opening the server-side formserverpath URL in a new browser window; the client-side path (FILENAME) is used only for constructing the base filename, not for direct client file access.
- BR-007 - If any error occurs during any export step, the error code and message must be displayed to the user and the export must be aborted by raising Form_trigger_failure.

---
**Implementation Logic**

```plsql
PROCEDURE view_excel_rep(p_file_name VARCHAR2 DEFAULT NULL, 
 												 p_query VARCHAR2,
 												 p_column_name VARCHAR2) 
IS	
  rg_name 				 		VARCHAR2(40) := 'DataRecordSet'; 
	rg_id 					 		RecordGroup; 
	gc_id 					 		GroupColumn; 
	urlFile1        TEXT_IO.FILE_TYPE;
	the_rowcount 		 		NUMBER;
	po_err_msg    VARCHAR2 (3000);
	po_err_cd     NUMBER (10);
	low           NUMBER (10);
	high          NUMBER (10);
	remainder     NUMBER (10);

	vcfile varchar2(150);
	lv_user  varchar2(150);
	v_string varchar2(5000);
	bin_str varchar2(250);
	errcode 				 		NUMBER; 
  FILENAME			   		VARCHAR2(4000);
  MYFILE 					 		TEXT_IO.FILE_TYPE;
  urlFile 					 	TEXT_IO.FILE_TYPE;
  urlPath							VARCHAR2(5000);
	l_alert 				 		NUMBER;
	server_file      		VARCHAR2(2000);
	file_transfer_bool	BOOLEAN;
	formserverpath   		VARCHAR2(2000);

begin
	lv_user := name_in(':global.userid'); 
	vcFile:= lv_user||To_Char(Sysdate,'YYYYMMDDHHMISS'); 
	vcFile := vcFile||'.csv';

	if vcFile is null then
		null;
	else
		filename:=vcFile;
	end if;
	
	If instr(FILENAME,' ') > 0 then
 		FILENAME := 'C:\'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
 		Message('File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default.');
 		message('  ');
	end if;

	rg_id := Find_Group( rg_name ); 
	IF NOT Id_Null(rg_id) THEN 
		Delete_Group( rg_id ); 
	END IF; 
	
	rg_id := Create_Group_From_Query( rg_name, p_query ); 
	errcode := Populate_Group( rg_id ); 
	the_rowcount := Get_Group_Row_Count( rg_id );
	
	IF the_rowcount > 65536 THEN  
		Message('Maximum number of rows in excel exceeded. It will truncate to 65535 rows.');
		Message('  ');
		CLEAR_MESSAGE;
		the_rowcount := 65535;
	END IF;
--message('1 '||filename);	
	server_file := '/iashome/ias/reports/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
--message('2 '||server_file);
	urlFile := Text_Io.Fopen('/reports/DMS/excelpath.txt','R');
--message('3');	
	Text_Io.Get_Line(urlFile,urlPath);
	Text_Io.Fclose(urlFile);
--message('4');	
	formserverpath := urlPath||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	MYFILE := TEXT_IO.FOPEN(server_file, 'W');
--message('5');	
	gc_id := Find_Column( rg_name||'.'||p_column_name); 	
--message('6');
	for total_loop IN 1..the_rowcount
		loop
	  	V_STRING :=  GET_GROUP_CHAR_CELL(gc_id  , total_loop ); 
	  	text_io.put_line(myfile,v_string);
	end loop;
    text_io.fclose(myfile);   
	 	web.show_document(formserverpath,'_blank');
--message('7');
exception when others then
		Message('Error  - '||ERROR_CODE|| ERROR_TEXT);
		Raise Form_trigger_failure;
 
END;
```

#### SP-002 - D2KWUTIL.ATTEMPT_DLL_LOAD

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Attempts to load a specified DLL into memory via ORA_FFI, optionally verifying the file's physical existence at a given path before loading. If a target path is supplied, the procedure validates that the DLL file is accessible at that location before invoking the load. On successful load, it optionally increments the module-level DLL load counter and marks the API as enabled. On any failure, it disables the API and returns a null library handle, allowing the caller (REGISTER_FUNCTION_CALL) to handle the error gracefully.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |
| TargetDLL | VARCHAR2 | IN |
| LoadCount | BOOLEAN | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |

---

**Dependencies**

- DEBUGLOG ([SP-061](#SP-061--DEBUGLOG)) - matched by member name
- STRIPDIRSEP ([SP-067](#SP-067--STRIPDIRSEP)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Receive the target directory path (TargetPath, IN OUT), the DLL filename (TargetDLL), and a flag indicating whether the load counter should be incremented (LoadCount).
- Step 2 - If TargetPath is not null, normalise it by calling STRIPDIRSEP to remove any existing trailing directory separator, then append a single backslash ('\') to produce a well-formed directory path. This also discards any additional paths that may have been concatenated into TargetPath, retaining only the first.
- Step 3 - Attempt to open the file at the concatenated path (TargetPath || TargetDLL) in read mode using TEXT_IO.FOPEN to confirm the file physically exists.
- Step 4 - If the file opens successfully, close it immediately with TEXT_IO.FCLOSE; the open was for existence verification only.
- Step 5 - If the file cannot be opened (any exception), call DEBUGLOG (severity 99) to record that the DLL was not found at the specified location, then raise the BadLocation exception to abort the load attempt.
- Step 6 - Call ORA_FFI.LOAD_LIBRARY with TargetPath and TargetDLL to load the DLL and obtain a library handle (hDLL).
- Step 7 - If LoadCount is TRUE, increment the module-level counter DLL_LOAD_COUNT by 1 and set the module-level flag API_ENABLED to TRUE.
- Step 8 - Return the populated library handle (hDLL) to the caller.
- Step 9 - If any unhandled exception occurs during or after the ORA_FFI load, set API_ENABLED to FALSE and return the null library handle.

---
**Decision Points**

DP-001

Condition: TargetPath IS NOT NULL

TRUE: Normalise TargetPath via STRIPDIRSEP and append a backslash, then perform file-existence verification (Steps 2-5) before attempting the DLL load.

FALSE: Skip path normalisation and file-existence check; proceed directly to ORA_FFI.LOAD_LIBRARY using the null path.

---

DP-002

Condition: TEXT_IO.FOPEN succeeds for the path and DLL combination.

TRUE: Close the file handle and continue to the ORA_FFI.LOAD_LIBRARY call.

FALSE: Log the missing-file condition via DEBUGLOG (severity 99) and raise BadLocation, aborting the load.

---

DP-003

Condition: LoadCount parameter is TRUE after a successful ORA_FFI.LOAD_LIBRARY call.

TRUE: Increment DLL_LOAD_COUNT by 1 and set API_ENABLED to TRUE.

FALSE: Skip counter increment and API_ENABLED assignment; return the library handle without updating module-level state.

---

DP-004

Condition: An unhandled exception is raised during or after the ORA_FFI.LOAD_LIBRARY call (outer WHEN OTHERS handler).

TRUE: Set API_ENABLED to FALSE and return the null library handle to the caller.

FALSE (no exception): Normal return path; hDLL is populated and API_ENABLED reflects the LoadCount outcome.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - TargetPath must contain exactly one directory path; if multiple paths are present, only the first is used and the remainder are discarded by STRIPDIRSEP before the backslash is appended.
- BR-002 - A trailing backslash directory separator must always be present on TargetPath before it is used for file verification or DLL loading; STRIPDIRSEP is called unconditionally when TargetPath is not null to enforce this.
- BR-003 - Physical existence of the DLL file must be confirmed via TEXT_IO.FOPEN before ORA_FFI.LOAD_LIBRARY is invoked whenever a TargetPath is provided; a DLL that cannot be opened is treated as absent.
- BR-004 - A failed file-existence check must be logged at severity level 99 via DEBUGLOG, identifying the DLL name and the path that was searched, before the BadLocation exception is raised.
- BR-005 - DLL_LOAD_COUNT must be incremented and API_ENABLED must be set to TRUE only when the load succeeds and LoadCount is TRUE; these module-level flags must not be updated on a failed load.
- BR-006 - On any exception that escapes the outer handler, API_ENABLED must be set to FALSE and a null library handle must be returned, ensuring the caller can detect the failure without an unhandled error propagating.

---
**Implementation Logic**

```plsql

FUNCTION  Attempt_DLL_Load  (TargetPath in out VARCHAR2, TargetDLL in VARCHAR2, LoadCount in BOOLEAN DEFAULT TRUE) return ORA_FFI.LibHandleType is
  hDLL  ORA_FFI.LibHandleType;
  hFile TEXT_IO.FILE_TYPE;
begin 
    	
  if TargetPath is not null then 
    -- Watch out for folks who put multiple Paths in here 
    -- Oh yes it's happened! Just use the first & throw the rest away
    -- Add trailing Directory Sep if required
    TargetPath := StripDirSep(TargetPath)||'\';
    
    -- Check that there is actually a file there.
    begin 
  	  hFile := TEXT_IO.FOPEN(TargetPath||TargetDLL,'R');
  	  TEXT_IO.FCLOSE(hFile);
    exception
  	  when others then
  	    Win_API_Debug.DebugLog(99,'Attempt_DLL_LOAD',TargetDLL||' not found in the specified location of "'||TargetPath||'"'); 
  		  raise BadLocation;
    end;
  end if;
  
  hDLL := ORA_FFI.LOAD_LIBRARY(TargetPath, TargetDLL);
  if LoadCount then 
    DLL_LOAD_COUNT  := DLL_LOAD_COUNT + 1;
    API_ENABLED  := TRUE;
  end if;
  return hDLL;
exception
  when others then 
    API_ENABLED := FALSE;
    return hDLL; /* Will be null */
end Attempt_DLL_Load;
```

#### SP-003 - D2KWUTIL.D2KWUTIL_DEBUGSTRING

**Invoked From:**

- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level foreign-function interface (FFI) bridge that passes a debug text string to the underlying C library routine d2kwutil_DebugString (pragma interface identifier 11265). It is invoked by the WINDEBUG stored procedure within D2kwutil.pld to emit diagnostic or debug messages through the Oracle Forms C external interface layer.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that identifies the bound C function entry point and the debug text string (Text) to be transmitted.
- Step 2 - Delegate execution directly to the C-language implementation of d2kwutil_DebugString via the ORA_FFI PRAGMA INTERFACE binding (interface identifier 11265), passing both hFunc and Text as arguments.
- Step 3 - Return control to the calling routine (WINDEBUG) upon completion of the C function call; no return value or output parameter is produced.

---
**Decision Points**

No decision points are present in this procedure. The implementation consists solely of a foreign-function interface declaration with a direct pass-through to the bound C routine; there is no conditional branching logic.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure operates exclusively as an FFI wrapper; all business logic governing when and how debug strings are generated resides in the calling routine WINDEBUG, not within this procedure.
- BR-002 - The hFunc parameter must be a valid ORA_FFI.funcHandleType handle bound to the C entry point before this procedure is invoked; the procedure does not validate or initialise the handle itself.
- BR-003 - No database interactions are performed; the procedure is confined to inter-language communication between the Oracle Forms PL/SQL layer and the underlying C library.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.
   
 PROCEDURE d2kwutil_DebugString (    hFunc       IN      ORA_FFI.funcHandleType,
                                     Text        IN      VARCHAR2);
 -- Pragmas
 PRAGMA INTERFACE(C,d2kwutil_DebugString,      11265);
```

#### SP-004 - D2KWUTIL.D2KWUTIL_GETDOSENV

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level Foreign Function Interface (FFI) wrapper that retrieves a DOS/operating-system environment variable value. It accepts a function handle to the underlying native OS call, passes the source environment variable name and a buffer for the expanded value, and returns an integer status code indicating the outcome of the OS-level lookup.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| SourceStr | VARCHAR2 | IN OUT |
| ExpandStr | VARCHAR2 | IN OUT |
| InBuffLen | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| SourceStr | VARCHAR2 | IN OUT |
| ExpandStr | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that references the pre-registered native OS function responsible for resolving environment variable strings.
- Step 2 - Accept the source environment variable name (SourceStr) as an IN OUT parameter to be passed to the native function.
- Step 3 - Accept the expansion buffer (ExpandStr) as an IN OUT parameter that will be populated with the resolved environment variable value returned by the OS.
- Step 4 - Accept the input buffer length (InBuffLen) that defines the maximum character capacity of the ExpandStr buffer, constraining the OS call to prevent overflow.
- Step 5 - Invoke the native OS function via the supplied FFI handle, passing SourceStr, ExpandStr, and InBuffLen.
- Step 6 - Return a PLS_INTEGER status code to the caller (GET_ENVIRONMENT_STRING in D2kwutil.pld) indicating success or failure of the environment variable resolution.

---
**Decision Points**

No decision points are determinable from the available source. Only the function specification is present; no conditional logic is visible in the implementation body.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be invoked with a valid ORA_FFI function handle (hFunc); the handle must reference the correct pre-registered native OS function before this routine is called.
- BR-002 - The caller is responsible for supplying InBuffLen equal to or less than the allocated size of the ExpandStr buffer to prevent data truncation or overflow during the OS environment variable expansion.
- BR-003 - Both SourceStr and ExpandStr are declared IN OUT, meaning the caller must initialise them before invocation and must read their post-call values to obtain the resolved environment string.
- BR-004 - The integer return value must be evaluated by the calling routine (GET_ENVIRONMENT_STRING) to determine whether the OS environment variable was successfully resolved.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_GetDOSEnv (   hFunc          IN      ORA_FFI.funcHandleType,
                                SourceStr      IN OUT  VARCHAR2,
                                ExpandStr      IN OUT  VARCHAR2,
                                InBuffLen      IN      PLS_INTEGER
                                ) RETURN PLS_INTEGER;
```

#### SP-005 - D2KWUTIL.D2KWUTIL_GETREGKEY

**Invoked From:**

- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

D2KWUTIL_GETREGKEY is a foreign-function interface (FFI) wrapper function that retrieves a Windows Registry key value. Given a registry root, path, and entry name, it populates the RegValue output parameter with the corresponding registry data and returns an integer status code indicating the outcome of the retrieval operation. It is invoked by the READ_REGISTRY stored procedure within D2kwutil.pld to abstract low-level registry access from higher-level application logic.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| RegRoot | PLS_INTEGER | IN |
| RegPath | VARCHAR2 | IN OUT |
| RegEntry | VARCHAR2 | IN OUT |
| RegValue | VARCHAR2 | IN OUT |
| RegValueLength | PLS_INTEGER | IN |
| RegDontExpand | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RegPath | VARCHAR2 | IN OUT |
| RegEntry | VARCHAR2 | IN OUT |
| RegValue | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that references the underlying native Windows Registry API entry point to be called.
- Step 2 - Accept the registry root identifier (RegRoot) as a PLS_INTEGER constant representing the target hive (e.g., HKEY_LOCAL_MACHINE, HKEY_CURRENT_USER).
- Step 3 - Accept the registry path (RegPath) and entry name (RegEntry) as IN OUT VARCHAR2 parameters identifying the specific registry key and value name to be read.
- Step 4 - Accept RegValueLength (maximum buffer size) and RegDontExpand (flag controlling whether environment-variable strings are expanded) as control parameters governing how the value is retrieved.
- Step 5 - Invoke the native registry read operation via the supplied ORA_FFI function handle, passing all provided parameters.
- Step 6 - Populate the RegValue IN OUT parameter with the registry value data returned by the native call, up to the length specified by RegValueLength.
- Step 7 - Return a PLS_INTEGER status code to the caller (READ_REGISTRY) indicating success or failure of the registry key retrieval.

---
**Decision Points**

DP-001

Condition: Whether RegDontExpand is set to a non-zero (true) value.

TRUE: The native registry call retrieves the raw registry value string without expanding embedded environment-variable references (e.g., %SystemRoot% is returned as-is).

FALSE: The native registry call expands any environment-variable references within the registry value before returning the data in RegValue.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be invoked with a valid ORA_FFI function handle (hFunc); the handle is the sole mechanism by which the PL/SQL layer delegates execution to the underlying native Windows Registry API.
- BR-002 - RegRoot must be supplied as a recognised Windows registry hive constant (PLS_INTEGER); an invalid root will result in a failed native call reflected in the returned status code.
- BR-003 - RegValueLength defines the maximum number of characters that may be written into RegValue; the retrieved registry data must not exceed this buffer size.
- BR-004 - The RegDontExpand flag governs environment-variable expansion within the retrieved value; callers must explicitly set this flag to control whether the raw or expanded form of the value is returned.
- BR-005 - RegPath and RegEntry are declared IN OUT; callers must supply initialised values and must handle the possibility that the native layer modifies these buffers during the call.
- BR-006 - The integer return value must be evaluated by the calling routine (READ_REGISTRY) to determine whether the registry key was successfully read before consuming the contents of RegValue.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_GetRegKey (    hFunc         IN      ORA_FFI.funcHandleType,
                                RegRoot        IN      PLS_INTEGER,
                                RegPath        IN OUT  VARCHAR2,
                                RegEntry       IN OUT  VARCHAR2,
                                RegValue       IN OUT  VARCHAR2,
                                RegValueLength IN      PLS_INTEGER,
                                RegDontExpand	 IN      PLS_INTEGER
                                ) return PLS_INTEGER;
```

#### SP-006 - D2KWUTIL.TRANSLATETYPE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

TranslateType is a lookup function that converts a string-based C data type name into its corresponding ORA_FFI integer constant. It is used internally by the D2KWUTIL package to resolve parameter and return-value type codes before registering external function calls via the Oracle Foreign Function Interface (ORA_FFI).

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DataType | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input string DataType and convert it to uppercase, storing the result in the local variable vcType, to ensure case-insensitive matching.
- Step 2 - Evaluate vcType against the full set of recognised C data type name tokens using a sequential IF-ELSIF chain.
- Step 3 - For each matched token, assign the corresponding ORA_FFI integer constant to the local return variable iRC (e.g., '*CHAR' maps to ORA_FFI.C_CHAR_PTR, 'CHAR' maps to ORA_FFI.C_CHAR, '*INT' maps to ORA_FFI.C_INT_PTR, 'INT' maps to ORA_FFI.C_INT, '*LONG' maps to ORA_FFI.C_LONG_PTR, 'LONG' maps to ORA_FFI.C_LONG, '*SHORT' or '*BYTE' maps to ORA_FFI.C_SHORT_PTR, 'SHORT' or 'BYTE' maps to ORA_FFI.C_SHORT, '*DOUBLE' maps to ORA_FFI.C_DOUBLE_PTR, 'DOUBLE' maps to ORA_FFI.C_DOUBLE, '*VOID' maps to ORA_FFI.C_VOID_PTR).
- Step 4 - If no token matches, iRC remains unassigned (NULL), and no exception is raised by the function itself.
- Step 5 - Return iRC (the resolved ORA_FFI type constant, or NULL if the input was unrecognised) to the caller.

---
**Decision Points**

DP-001
Condition: vcType = '*CHAR'
TRUE: iRC is set to ORA_FFI.C_CHAR_PTR.
FALSE: Evaluation continues to the next condition.

DP-002
Condition: vcType = 'CHAR'
TRUE: iRC is set to ORA_FFI.C_CHAR.
FALSE: Evaluation continues to the next condition.

DP-003
Condition: vcType = '*INT'
TRUE: iRC is set to ORA_FFI.C_INT_PTR.
FALSE: Evaluation continues to the next condition.

DP-004
Condition: vcType = 'INT'
TRUE: iRC is set to ORA_FFI.C_INT.
FALSE: Evaluation continues to the next condition.

DP-005
Condition: vcType = '*LONG'
TRUE: iRC is set to ORA_FFI.C_LONG_PTR.
FALSE: Evaluation continues to the next condition.

DP-006
Condition: vcType = 'LONG'
TRUE: iRC is set to ORA_FFI.C_LONG.
FALSE: Evaluation continues to the next condition.

DP-007
Condition: vcType = '*SHORT' OR vcType = '*BYTE'
TRUE: iRC is set to ORA_FFI.C_SHORT_PTR.
FALSE: Evaluation continues to the next condition.

DP-008
Condition: vcType = 'SHORT' OR vcType = 'BYTE'
TRUE: iRC is set to ORA_FFI.C_SHORT.
FALSE: Evaluation continues to the next condition.

DP-009
Condition: vcType = '*DOUBLE'
TRUE: iRC is set to ORA_FFI.C_DOUBLE_PTR.
FALSE: Evaluation continues to the next condition.

DP-010
Condition: vcType = 'DOUBLE'
TRUE: iRC is set to ORA_FFI.C_DOUBLE.
FALSE: Evaluation continues to the next condition.

DP-011
Condition: vcType = '*VOID'
TRUE: iRC is set to ORA_FFI.C_VOID_PTR.
FALSE: No assignment is made; iRC remains NULL and is returned as-is.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The input DataType value is normalised to uppercase before comparison, making type name resolution case-insensitive.
- BR-002 - Pointer variants of a C type are denoted by prefixing the type name with an asterisk (e.g., '*INT' for pointer-to-int); the function maps these to the corresponding ORA_FFI pointer constant rather than the value constant.
- BR-003 - The type tokens '*SHORT' and '*BYTE' are treated as equivalent and both resolve to ORA_FFI.C_SHORT_PTR; similarly, 'SHORT' and 'BYTE' both resolve to ORA_FFI.C_SHORT.
- BR-004 - The supported type vocabulary is limited to the eleven tokens explicitly listed in the IF-ELSIF chain (*CHAR, CHAR, *INT, INT, *LONG, LONG, *SHORT/*BYTE, SHORT/BYTE, *DOUBLE, DOUBLE, *VOID); any input outside this set returns NULL without raising an error.
- BR-005 - The function performs no database reads or writes; it operates entirely as an in-memory lookup and has no side effects.

---
**Implementation Logic**

```plsql
 
FUNCTION TranslateType(DataType in VARCHAR2) return PLS_INTEGER is
   -- Just a simple lookup of the types.
   vcType VARCHAR2(10) := UPPER(DataType);
   iRC    PLS_INTEGER;
begin 
  if vcType = '*CHAR' then 
    iRC := ORA_FFI.C_CHAR_PTR;
  elsif vcType = 'CHAR' then 
    iRC := ORA_FFI.C_CHAR;
  elsif vcType = '*INT' then 
    iRC := ORA_FFI.C_INT_PTR;
  elsif vcType = 'INT' then 
    iRC := ORA_FFI.C_INT;
  elsif vcType = '*LONG' then 
    iRC := ORA_FFI.C_LONG_PTR;
  elsif vcType = 'LONG' then 
    iRC := ORA_FFI.C_LONG;
  elsif vcType = '*SHORT' or vcType = '*BYTE'  then 
    iRC := ORA_FFI.C_SHORT_PTR;
  elsif vcType = 'SHORT' or vcType = 'BYTE' then 
    iRC := ORA_FFI.C_SHORT;
  elsif vcType = '*DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE_PTR;
  elsif vcType = 'DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE;  
  elsif vcType = '*VOID' then 
    iRC := ORA_FFI.C_VOID_PTR;      
  end if;
return iRC;
end TranslateType;
```

#### SP-007 - GENERAL.ASK_CONFIRM

**Invoked From:**

- vr_bshop_tech_prod_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

N/A

---

**Purpose**

Displays a configurable confirmation alert dialog (AL_CONFIRM) to the user and returns a numeric flag indicating which button was pressed. The function allows calling screens to pause processing and obtain explicit user confirmation before proceeding with an action.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| confirm_msg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the confirmation message text passed in via the confirm_msg input parameter.
- Step 2 - Set the message text of the predefined alert AL_CONFIRM to the value of confirm_msg using set_alert_property.
- Step 3 - Display the AL_CONFIRM alert dialog to the user using show_alert and capture the button pressed in the local variable p_albtn_pressed.
- Step 4 - Evaluate the value of p_albtn_pressed against the Oracle Forms constant ALERT_BUTTON1.
- Step 5 - Return 1 if the user pressed the first button (affirmative/confirm), or 0 for any other button press (negative/cancel).

---
**Decision Points**

DP-001

Condition: p_albtn_pressed = ALERT_BUTTON1 (the user pressed the first/affirmative button on the AL_CONFIRM alert)

TRUE: The function returns 1, signalling to the caller that the user confirmed the action.

FALSE: The function returns 0, signalling to the caller that the user did not confirm the action (cancelled or dismissed the alert).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The confirmation alert used must be the predefined Oracle Forms alert named AL_CONFIRM; no other alert object is used by this function.
- BR-002 - The message displayed to the user is determined entirely by the confirm_msg parameter supplied by the caller; the function does not apply any default or fallback message text.
- BR-003 - A return value of 1 exclusively represents user confirmation (ALERT_BUTTON1); any other button press, including dismissal, yields a return value of 0 and is treated as a non-confirmation.
- BR-004 - The function has no side effects on database state; it solely controls the alert display and returns a binary confirmation indicator to the caller.

---
**Implementation Logic**

```plsql
FUNCTION ASK_CONFIRM( confirm_msg VARCHAR2)
                                      RETURN  NUMBER IS

    p_alert_name varchar2(10) := 'AL_CONFIRM' ;
    p_albtn_pressed number;
BEGIN
   set_alert_property(p_alert_name,alert_message_text,confirm_msg); 
   p_albtn_pressed := show_alert(p_alert_name);

   IF ( p_albtn_pressed = ALERT_BUTTON1 ) THEN
      return (1);
   ELSE
      return(0);
   END IF;
RETURN NULL; END;
```

#### SP-008 - GENERAL.CHECK_FORM_FAILURE

**Invoked From:**

- vr_bshop_tech_prod_fmb.xml [Trigger: KEY-COMMIT]

---

**Screen:**

N/A

---

**Purpose**

Centralises post-operation failure detection for Oracle Forms commits. After a KEY-COMMIT trigger fires, this procedure inspects the Forms runtime success flag and, if the operation did not succeed, determines the error category (Oracle database error or Forms runtime error), displays the appropriate error message to the user via GENERAL.DISP_TEXT, and then halts further trigger processing by raising FORM_TRIGGER_FAILURE.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-009](#SP-009--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate the Forms built-in FORM_SUCCESS flag to determine whether the most recent Forms operation completed without error.
- Step 2 - If FORM_SUCCESS is FALSE (i.e., the operation failed), inspect the ERROR_TYPE built-in to classify the failure.
- Step 3 - If ERROR_TYPE is 'ORA' (an Oracle database-level error), call GENERAL.DISP_TEXT passing SQLERRM as the message text and 'Error' as the severity label to display the database error to the user.
- Step 4 - If ERROR_TYPE is 'FRM' (a Forms runtime-level error), call GENERAL.DISP_TEXT passing ERROR_TEXT as the message text and 'Error' as the severity label to display the Forms error to the user.
- Step 5 - After displaying the error message, raise FORM_TRIGGER_FAILURE to abort the KEY-COMMIT trigger and prevent any further processing.
- Step 6 - If FORM_SUCCESS is TRUE, no action is taken and execution returns normally to the caller.

---
**Decision Points**

DP-001

Condition: FORM_SUCCESS evaluates to FALSE (the preceding Forms operation failed).

TRUE: Proceed to classify the error type and display an error message, then raise FORM_TRIGGER_FAILURE.

FALSE: No error has occurred; the procedure exits without any user notification or trigger interruption.

---

DP-002

Condition: ERROR_TYPE = 'ORA' (the failure originated from an Oracle database error).

TRUE: Call GENERAL.DISP_TEXT with SQLERRM (the Oracle error message) and the label 'Error'.

FALSE: Evaluate the next condition (DP-003).

---

DP-003

Condition: ERROR_TYPE = 'FRM' (the failure originated from a Forms runtime error).

TRUE: Call GENERAL.DISP_TEXT with ERROR_TEXT (the Forms error message) and the label 'Error'.

FALSE: No matching error category; the error message display is skipped, but FORM_TRIGGER_FAILURE is still raised to abort the trigger.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A commit operation that does not achieve FORM_SUCCESS must never complete silently; an error message must always be presented to the user before the trigger is aborted.
- BR-002 - Oracle database errors (ERROR_TYPE = 'ORA') must be reported using the Oracle-supplied error message returned by SQLERRM.
- BR-003 - Forms runtime errors (ERROR_TYPE = 'FRM') must be reported using the Forms-supplied error text available in the ERROR_TEXT built-in.
- BR-004 - All error messages displayed by this procedure must be classified with the severity label 'Error' when invoking GENERAL.DISP_TEXT.
- BR-005 - Regardless of error type, once a failure is detected, FORM_TRIGGER_FAILURE must be raised to ensure the KEY-COMMIT trigger is unconditionally halted and no partial commit result is accepted.

---
**Implementation Logic**

```plsql
PROCEDURE CHECK_FORM_FAILURE IS
BEGIN
 IF (NOT form_success) THEN
     IF ERROR_TYPE = 'ORA' THEN
        GENERAL.disp_text(SQLERRM,'Error');
     ELSIF ERROR_TYPE = 'FRM' THEN
        GENERAL.disp_text(ERROR_TEXT,'Error');
     END IF;
     raise form_trigger_failure;
  END IF; 

END;
```

#### SP-009 - GENERAL.DISP_TEXT

**Invoked From:**

- DPL.pld [StoredProcedure: GENERAL.CHECK_FORM_FAILURE]
- vr_bshop_tech_prod_fmb.xml [Trigger: ON-MESSAGE]

---

**Screen:**

N/A

---

**Purpose**

Displays a modal alert dialog to the user containing a provided message and title. The procedure selects the appropriate Oracle Forms alert template ('AL_ERRINFO' for error-type messages, 'AL_NOTE' for all other message types), sets the alert's title and message text dynamically at runtime, and presents the dialog to the user. It is used as a centralised utility for surfacing informational or error text across the application.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| text_string | VARCHAR2 | IN |
| title_string | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message body (text_string) and the dialog title (title_string) as input parameters.
- Step 2 - Evaluate the title_string value (case-insensitive) to determine which alert template to use: if the title is 'ERROR', assign alert name 'AL_ERRINFO'; otherwise assign alert name 'AL_NOTE'.
- Step 3 - Set the TITLE property of the selected alert to the value of title_string using SET_ALERT_PROPERTY.
- Step 4 - Set the ALERT_MESSAGE_TEXT property of the selected alert to the value of text_string using SET_ALERT_PROPERTY.
- Step 5 - Display the configured alert to the user via SHOW_ALERT and capture the user's response in the local variable p_alert_id (response is not evaluated further).

---
**Decision Points**

DP-001

Condition:
UPPER(title_string) = 'ERROR'

TRUE:
The alert template 'AL_ERRINFO' is selected, indicating an error-severity dialog will be displayed.

FALSE:
The alert template 'AL_NOTE' is selected, indicating a non-error (informational/note) dialog will be displayed.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure supports exactly two alert templates: 'AL_ERRINFO' for messages whose title resolves to 'ERROR' (case-insensitive), and 'AL_NOTE' for all other titles; no other alert types are used.
- BR-002 - Title matching is performed case-insensitively (via UPPER), so values such as 'error', 'Error', or 'ERROR' all route to the 'AL_ERRINFO' template.
- BR-003 - Both the alert title and the alert message text are set dynamically at runtime from the caller-supplied parameters; no hard-coded message content is displayed.
- BR-004 - The procedure does not evaluate or act upon the user's alert button response; it is solely responsible for display, not for downstream flow control based on user input.

---
**Implementation Logic**

```plsql
PROCEDURE DISP_TEXT (text_string VARCHAR2,
                     title_string VARCHAR2 ) IS 
   p_alert_name varchar2(10) := 'AL_ERRINFO' ; 
   p_alert_id number;
BEGIN
   if upper(title_string)='ERROR' then
      p_alert_name := 'AL_ERRINFO' ; 
   else
      p_alert_name := 'AL_NOTE' ; 
   end if;
   set_alert_property(p_alert_name,TITLE,title_string);  
   set_alert_property(p_alert_name,alert_message_text,text_string);  
   p_alert_id := show_alert(p_alert_name); 
END;
```

#### SP-010 - PKG_VTS_BODYSHOP.SF_GET_PANEL

**Invoked From:**

- vr_bshop_tech_prod_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

PARAMETERS (N/A / CN_MAIN)

---

**Purpose**

Retrieves the total number of body panels repaired for a specific repair order from the vehicle technical services detail table. Accepts the dealer group, dealer map code, location code, company code, and repair order number; returns the sum of the panel and windshield count. Returns zero if no matching records are found.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_pgroup | varchar2 | IN |
| p_dealermap | number | IN |
| p_loc | varchar2 | IN |
| p_comp | varchar2 | IN |
| p_ronum | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the parent group code, dealer map code, location code, company code, and repair order number as inputs.
- Step 2 - Query the vehicle technical services detail table (VT_VTS) to calculate the sum of the panel and windshield count (PANEL_WNSHLD) for records matching the provided inputs.
- Step 3 - Return the summed panel count. If no records are found for the given inputs, return zero.

---
**Decision Points**

DP-001

Condition:
Records exist in VT_VTS matching the provided parent group, dealer map code, location code, and repair order number

TRUE:
Return the sum of PANEL_WNSHLD values for the matching records

FALSE:
NVL returns zero (no panel records found for this repair order)

---
**Database Interactions**

- DB-001 - Read VT_VTS - Reads data from VT_VTS for lookup or validation.
**Business Rules**

- BR-001 - The total panel count for a repair order is calculated as the sum of all panel and windshield detail records for that repair order in the vehicle technical services table, scoped to the specified dealer group and location.
- BR-002 - If no panel detail records exist for the given repair order, a count of zero is returned; no error is raised.

---
**Implementation Logic**

```plsql

  function sf_get_panel(p_pgroup    varchar2,
                        p_dealermap number,
                        p_loc       varchar2,
                        p_comp      varchar2,
                        p_ronum     varchar2) RETURN NUMBER IS

    LV_PANEL NUMBER := 0;

  BEGIN
    SELECT sum(panel_wnshld)
      into LV_PANEL
      FROM VT_VTS
     WHERE parent_group = p_pgroup
       and dealer_map_cd = p_dealermap
       and loc_cd = p_loc
       and ro_NUM = p_ronum;

    RETURN NVL(LV_PANEL, 0);
  END sf_get_panel;
```

#### SP-011 - PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT

**Invoked From:**

- vr_bshop_tech_prod_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

PARAMETERS (N/A / CN_MAIN)

---

**Purpose**

Calculates the number of actual working days within a specified date range for a given dealership and location by iterating day by day and excluding any days recorded as holidays or leave in the working-day register. Returns the total count of non-holiday days in the range.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_pgroup | varchar2 | IN |
| p_dealermap | number | IN |
| p_loc | varchar2 | IN |
| p_frm_dt | date | IN |
| p_to_dt | date | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the parent group code, dealer map code, location code, from date, and to date as inputs.
- Step 2 - Truncate both the start and end dates to midnight to ensure day-level comparison.
- Step 3 - Iterate through each calendar day from the start date to the end date (inclusive), advancing one day per iteration.
- Step 4 - For each day in the range, query the working-day register (WD_BTN) to check whether the current day is recorded as a leave or holiday day for the specified dealer group, dealer map code, and location code.
- Step 5 - If no holiday/leave record is found for the day (count = 0), increment the working-day counter by one. If an exception occurs for a specific day during the holiday check, default the holiday count to zero and count that day as a working day.
- Step 6 - After iterating through all days, return the total count of working days.

---
**Decision Points**

DP-001

Condition:
The current iteration date equals the end date plus one day (loop exit condition)

TRUE:
Exit the loop

FALSE:
Continue processing the current day

---

DP-002

Condition:
The holiday count for the current day in WD_BTN is zero (no holiday/leave record found)

TRUE:
Increment the working-day counter by one

FALSE:
Do not increment the counter; this day is a recorded non-working day

---
**Database Interactions**

- DB-001 - Read WD_BTN - Reads data from WD_BTN for lookup or validation.
**Business Rules**

- BR-001 - The working-day count for a date range is calculated by iterating over every calendar day in the range and counting those not recorded as leave or holiday days in the working-day register for the specified dealership and location.
- BR-002 - If a database exception occurs when checking a specific day's holiday status, that day is treated as a working day (holiday count defaults to zero) and processing continues, ensuring robustness against data gaps.
- BR-003 - The function returns the total number of days in the range that are not recorded as non-working days.

---
**Implementation Logic**

```plsql

  function sf_get_working_day_cnt(p_pgroup    varchar2,
                                  p_dealermap number,
                                  p_loc       varchar2,
                                  p_frm_dt    date,
                                  p_to_dt     date) RETURN NUMBER IS
    lv_start_dt    date;
    lv_end_dt      date;
    lv_day_cnt     number := 0;
    LV_HOLIDAY_CNT number := 0;
  begin
    begin
      lv_start_dt := trunc(p_frm_dt);
      lv_end_dt   := trunc(p_to_dt);
      LOOP
        exit when lv_start_dt = lv_end_dt + 1;
        begin
          SELECT COUNT(*)
            INTO LV_HOLIDAY_CNT
            FROM WD_BTN
           where parent_group = p_pgroup
             and dealer_map_cd = p_dealermap
             and loc_cd = p_loc
             and LEAVE_DATE = lv_start_dt;
        exception
          when others then
            LV_HOLIDAY_CNT := 0;
        end;
        if LV_HOLIDAY_CNT = 0 then
          lv_day_cnt := lv_day_cnt + 1;
        end if;
        lv_start_dt := lv_start_dt + 1;
      END LOOP;
    end;
    return lv_day_cnt;
  end sf_get_working_day_cnt;
```

#### SP-012 - WEBUTIL.BLOCKING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Executes a shell or system command in blocking mode, meaning the calling process waits for the command to complete before continuing. The function delegates execution to WEBUTIL.EXECUTE, passing the supplied command string together with the BLOCKING_MODE constant to enforce synchronous behaviour.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.EXECUTE ([SP-020](#SP-020--WEBUTIL.EXECUTE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the command string (cmd) to be executed as an input parameter.
- Step 2 - Invoke WEBUTIL.EXECUTE, passing cmd and the BLOCKING_MODE constant to request synchronous (blocking) execution.
- Step 3 - Return the PROCESS_ID value produced by WEBUTIL.EXECUTE to the caller, allowing the caller to reference the completed process if required.

---
**Decision Points**

No conditional decision points exist within this function. Execution flow is unconditional: the function always forwards the command to WEBUTIL.EXECUTE with BLOCKING_MODE and returns the resulting PROCESS_ID.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The command must always be executed in blocking mode; the BLOCKING_MODE constant is hardcoded and cannot be overridden by the caller.
- BR-002 - The function must return a PROCESS_ID to the caller, as supplied by WEBUTIL.EXECUTE, to enable downstream identification or tracking of the executed process.
- BR-003 - All actual command execution responsibility is delegated to WEBUTIL.EXECUTE; WEBUTIL.BLOCKING introduces no independent execution logic.

---
**Implementation Logic**

```plsql
  
  FUNCTION  Blocking(cmd in VARCHAR2) return PROCESS_ID is
  begin
    return Execute(cmd,BLOCKING_MODE);
  end Blocking;
```

#### SP-013 - WEBUTIL.CHECKLIBS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.CHECKLIBS verifies that all system libraries required by a given WebUtil package are present and up to date on the client machine. For each library entry defined in the property bundle for the package, the procedure compares the installed version recorded in the client settings against the expected version. Where a library is absent, outdated, or a forced re-download flag is active, the procedure downloads the library from the configured URL to the client's system library location and records the new version in the client settings. Any download failure is logged as an error.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.DOWNLOADFROMURLINT ([SP-017](#SP-017--WEBUTIL.DOWNLOADFROMURLINT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTSETTING ([SP-025](#SP-025--WEBUTIL.GETCLIENTSETTING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-043](#SP-043--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-046](#SP-046--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READTRANSFROMMSGBUNDLE ([SP-047](#SP-047--WEBUTIL.READTRANSFROMMSGBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETCLIENTSETTING ([SP-051](#SP-051--WEBUTIL.SETCLIENTSETTING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the packageID input parameter that identifies the WebUtil package whose required system libraries are to be checked.
- Step 2 - Begin an iterative loop, incrementing a library counter (lib) with each iteration, to read all library specifications defined for the package from the property bundle.
- Step 3 - Retrieve the library specification string by calling WEBUTIL.READFROMPROPERTYBUNDLE using a key composed of 'install.syslib', the client OS family, the client OS architecture, the packageID, and the current library counter. If no entry is found for the OS-family/architecture combination, retry the lookup using a key that omits the OS architecture.
- Step 4 - If no library specification is found for the current counter value, exit the loop; all library entries for this package have been processed.
- Step 5 - Parse the retrieved library specification string (pipe-delimited) to extract: the library file name (position 1), the expected file size in bytes (position 2), the expected version string (position 3), and a boolean flag indicating whether a progress indicator should be displayed during download (position 4).
- Step 6 - Call WEBUTIL.GETCLIENTSETTING with the key 'syslib.<libName>' to retrieve the version of the library currently installed on the client.
- Step 7 - Evaluate whether the library must be downloaded: if the installed version is null, differs from the expected version, or the REDOWNLOAD_SYSLIB flag is active, proceed to download; otherwise skip to Step 11.
- Step 8 - Determine the download base URL by calling WEBUTIL.READFROMPROPERTYBUNDLE in order of specificity: first using OS family and architecture, then OS family only, then a generic key ('install.syslib.location'). The first non-null result is used as the download base URL.
- Step 9 - Call WEBUTIL.DOWNLOADFROMURLINT with the full URL (base URL concatenated with the library file name), the library file name, a destination type indicator of 1 (system library install location), the expected file size, the progress flag, and localised progress dialog title and subtitle strings retrieved via WEBUTIL.READTRANSFROMMSGBUNDLE.
- Step 10 - If WEBUTIL.DOWNLOADFROMURLINT returns TRUE (download succeeded), call WEBUTIL.SETCLIENTSETTING to record the expected version against the key 'syslib.<libName>' in the client settings. If it returns FALSE, call WEBUTIL.LOG to record an error message stating that the download of the named system library failed.
- Step 11 - Return to Step 2 to process the next library entry in the bundle.

---
**Decision Points**

DP-001

Condition: The property bundle lookup using the OS-family and OS-architecture specific key ('install.syslib.<OSFamily>.<OSArch>.<packageID>.<lib>') returns a non-null library specification.

TRUE: Use the returned specification for the current library entry.

FALSE: Retry the lookup using the OS-family-only key ('install.syslib.<OSFamily>.<packageID>.<lib>').

---

DP-002

Condition: The OS-family-only property bundle lookup also returns null.

TRUE: No further library entries exist for the current counter value; exit the loop and end processing.

FALSE: A specification was found; continue processing the current library entry.

---

DP-003

Condition: The installed version retrieved from WEBUTIL.GETCLIENTSETTING is null, differs from the expected version, or the REDOWNLOAD_SYSLIB flag is active.

TRUE: The library must be downloaded; proceed to resolve the download URL and invoke WEBUTIL.DOWNLOADFROMURLINT.

FALSE: The correct version is already installed; skip download and advance to the next library entry.

---

DP-004

Condition: The OS-family and OS-architecture specific download URL key ('install.syslib.location.<OSFamily>.<OSArch>') returns a non-null value from WEBUTIL.READFROMPROPERTYBUNDLE.

TRUE: Use this URL as the download base URL.

FALSE: Fall back to the OS-family-only key ('install.syslib.location.<OSFamily>').

---

DP-005

Condition: The OS-family-only download URL key returns a non-null value from WEBUTIL.READFROMPROPERTYBUNDLE.

TRUE: Use this URL as the download base URL.

FALSE: Fall back to the generic key ('install.syslib.location').

---

DP-006

Condition: WEBUTIL.DOWNLOADFROMURLINT returns TRUE, indicating the library file was successfully downloaded to the client.

TRUE: Call WEBUTIL.SETCLIENTSETTING to record the expected library version in the client settings under 'syslib.<libName>'.

FALSE: Call WEBUTIL.LOG to record a failure message indicating that the download of the named system library was unsuccessful.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Library specifications for a package are defined in the property bundle using a hierarchical key scheme; the most specific key (OS family + OS architecture) takes precedence over the OS-family-only key. A null result from both keys signals the end of the library list for the package.
- BR-002 - Each library specification must be a pipe-delimited string encoding, in order: the library file name, the expected file size, the expected version string, and a progress-indicator flag ('TRUE'/'FALSE').
- BR-003 - A library must be downloaded if any one of the following conditions is true: no version is recorded in the client settings for that library, the recorded version does not match the expected version in the property bundle, or the REDOWNLOAD_SYSLIB flag is active.
- BR-004 - The download destination type is always set to 1 (system library install location) when downloading libraries via WEBUTIL.DOWNLOADFROMURLINT; this distinguishes system library downloads from other download types.
- BR-005 - The download base URL is resolved from the property bundle using a three-level fallback: OS family + architecture, OS family only, then a generic location key. The first non-null value found is used.
- BR-006 - Upon a successful download, the expected version string must be persisted to the client settings under the key 'syslib.<libName>' via WEBUTIL.SETCLIENTSETTING, so that subsequent invocations can determine that the library is already at the correct version.
- BR-007 - A failed download must be recorded by calling WEBUTIL.LOG with a descriptive error message identifying the library name; processing continues with the next library entry rather than aborting the entire procedure.
- BR-008 - Progress dialog title and subtitle strings displayed during download must be sourced from the message bundle via WEBUTIL.READTRANSFROMMSGBUNDLE using the keys 'INST_PGRS_TITLE' and 'INST_PGRS_SUBTITLE', ensuring localised user-facing text.

---
**Implementation Logic**

```plsql
  
  PROCEDURE CheckLibs(packageID in VARCHAR2 ) is
    lib          PLS_INTEGER := 1;
    libSpec      VARCHAR2(200 char);
    libName      VARCHAR2(100 char);
    libSize      PLS_INTEGER;
    libVer       VARCHAR2(20 char);
    installedVer VARCHAR2(20 char);
    libProg      BOOLEAN := false;
    downloadURL  VARCHAR2(1000);
  BEGIN
    -- Read through the property bundle for 
    -- any libraries for this package
    LOOP
      libSpec := readFromPropertyBundle('install.syslib.'||to_char(m_clientOSFamily)||'.'||
             to_char(m_clientOSArch)||'.'||packageID||'.'||to_char(lib));
      if libSpec is null then
        libSpec := readFromPropertyBundle('install.syslib.'||to_char(m_clientOSFamily)||'.'||
             packageID||'.'||to_char(lib));
      end if;
      if libSpec is null then 
        exit;
      end if;
      lib := lib + 1;
      libName := Delimstr.getString(libSpec,1,true,'|');
      libSize := Delimstr.getNumber(libSpec,2,true,'|');
      libVer  := Delimstr.getString(libSpec,3,true,'|');
      libProg := (upper(Delimstr.getString(libSpec,4,true,'|'))='TRUE');

      -- OK we now have the library information
      -- let's check if it's installed
      installedVer := GetClientSetting('syslib.'||libname);
      if installedVer is null or installedVer <> libVer or REDOWNLOAD_SYSLIB then 
        -- need to download
        downloadURL := readFromPropertyBundle('install.syslib.location' || '.' || to_char(m_clientOSFamily) ||
                             '.' || to_char(m_clientOSArch));
        if downloadURL is null then
          downloadURL := readFromPropertyBundle('install.syslib.location' || '.' || to_char(m_clientOSFamily));
        end if;
        if downloadURL is null then
          downloadURL := readFromPropertyBundle('install.syslib.location');
        end if;
        if DownLoadFromURLInt(downloadURL||'/'||libName, 
                              libName,
                              1, -- syslib install download, special location
                              libSize,
                              libProg,
                              ReadTransFromMsgBundle('INST_PGRS_TITLE'),
                              ReadTransFromMsgBundle('INST_PGRS_SUBTITLE'),     
                              libName) then 
          SetClientSetting('syslib.'||libname,libVer);
        else
          log('Download of system library '||libName||' failed',true);
        end if;                          
      end if;
    END LOOP;
  END CheckLibs;
```

#### SP-014 - WEBUTIL.CLEARCALLBACKTRIGGER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Removes a previously registered callback entry from the internal callbacks collection using the provided key. This procedure ensures that stale or consumed callback registrations are cleaned up, preventing unintended re-execution of callback triggers within the WebUtil session context.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| callbackKey | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the integer key (callbackKey) that identifies the target callback entry in the internal m_callbacks collection.
- Step 2 - Check whether an entry corresponding to callbackKey currently exists in the m_callbacks collection.
- Step 3 - If the entry exists, delete it from the m_callbacks collection, effectively deregistering the callback trigger.
- Step 4 - If the entry does not exist, take no action and exit silently.

---
**Decision Points**

DP-001

Condition: m_callbacks.exists(callbackKey) - the supplied callbackKey is present in the m_callbacks collection.

TRUE: The entry at callbackKey is deleted from m_callbacks, removing the registered callback trigger.

FALSE: No action is taken; the procedure exits without modifying the collection.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A callback entry is only deleted if it exists in the m_callbacks collection; the procedure must not raise an error when the specified key is absent.
- BR-002 - The callbackKey parameter must be a PLS_INTEGER value that corresponds to a valid index in the m_callbacks collection; no type coercion or default substitution is applied.
- BR-003 - Deletion is unconditional once existence is confirmed; no additional validation of the entry's state or content is performed before removal.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ClearCallbackTrigger(callbackKey in PLS_INTEGER) is
  begin
    if m_callbacks.exists(callbackKey) then 
      m_callbacks.delete(callbackKey);  
    end if;
  end ClearCallbackTrigger;
```

#### SP-015 - WEBUTIL.CLOSEBLOB

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open BLOB handle identified by the supplied checksum value. The procedure acts as a thin delegation layer within the WEBUTIL package, forwarding the close request to the underlying WebUtil_DB library to release any server-side resources associated with the BLOB session.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| checksum | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the checksum (PLS_INTEGER) that uniquely identifies the open BLOB handle to be closed.
- Step 2 - Delegate the close operation to WebUtil_DB.CloseBlob, passing the checksum value unchanged.
- Step 3 - Return the BOOLEAN result produced by WebUtil_DB.CloseBlob to the caller, indicating whether the BLOB was successfully closed.

---
**Decision Points**

No decision points are present in this procedure. The function unconditionally forwards the call to WebUtil_DB.CloseBlob and returns its result without branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The checksum supplied to CloseBlob must correspond to a previously opened BLOB handle; the validity of the checksum is enforced by the delegated call to WebUtil_DB.CloseBlob.
- BR-002 - The success or failure of the close operation is communicated exclusively through the returned BOOLEAN value; callers must inspect this value to determine whether the BLOB handle was released successfully.

---
**Implementation Logic**

```plsql

  FUNCTION  CloseBlob(checksum in PLS_INTEGER) return BOOLEAN is
  BEGIN
    return WebUtil_DB.CloseBlob(checksum);
  END CloseBlob;
```

#### SP-016 - WEBUTIL.CLOSEFILE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open server-side file handle represented by the supplied Java object. The procedure delegates the close operation to the native Java class oracle/forms/webutil/fileTransfer/AppServerFileReader by invoking its closeFile method via the JNI bridge, ensuring that file resources held on the application server are properly released after a file transfer or read operation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java object reference (obj) that represents the open AppServerFileReader file handle on the application server.
- Step 2 - Reset the JNI argument list by setting args to NULL, ensuring no stale arguments are passed to the Java method call.
- Step 3 - Invoke the closeFile boolean method on the AppServerFileReader Java class via JNI.CALL_BOOLEAN_METHOD, passing the object reference and an empty argument signature '()Z'.
- Step 4 - Return the boolean result produced by the Java closeFile method to the caller (WEBUTIL.SETDATA), indicating whether the file was successfully closed.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The procedure unconditionally resets the argument list and delegates the close operation to the Java layer, returning the boolean outcome directly to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The JNI argument list must be cleared (set to NULL) before invoking the Java closeFile method to prevent unintended arguments from being passed to the AppServerFileReader.closeFile call.
- BR-002 - The file close operation is performed exclusively through the oracle/forms/webutil/fileTransfer/AppServerFileReader Java class via the JNI bridge; no direct PL/SQL or database mechanism is used to close the file handle.
- BR-003 - The function must return the boolean result from the Java closeFile invocation unchanged to the caller, preserving the success or failure status of the close operation.

---
**Implementation Logic**

```plsql
  FUNCTION closeFile(
    obj   ORA_JAVA.JOBJECT) RETURN BOOLEAN IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_BOOLEAN_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'closeFile', '()Z', args); 
  END;
```

#### SP-017 - WEBUTIL.DOWNLOADFROMURLINT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Downloads a file from a specified URL to a client-side destination by constructing a delimited parameter string and delegating the transfer request to the WebUtil Core bean. The function returns TRUE if the download completes successfully, or FALSE if mandatory inputs are absent or an error occurs. Optional progress-indicator parameters allow the calling form to display a titled progress dialog during the transfer.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| specialDestination | PLS_INTEGER | IN |
| fileSize | PLS_INTEGER | IN |
| withProgress | BOOLEAN | IN |
| progressTitle | VARCHAR2 | IN |
| progressSubTitle | VARCHAR2 | IN |
| progressMessage | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Validate that sourceURL is not null; if null, raise the URL_NULL exception and return FALSE after logging error code 25 via WebUtil_Core.Error.
- Step 2 - Validate that clientDestination is not null; if null, raise the CLIENT_FILE_NULL exception and return FALSE after logging error code 130 via WebUtil_Core.Error.
- Step 3 - Evaluate specialDestination: if it is null, negative, or greater than 2, default the value to '0'; otherwise convert the supplied integer to a character. Append the result followed by the pipe delimiter ('|') to the submitString.
- Step 4 - Evaluate fileSize: if null, append '0|' to submitString; otherwise append the character representation of fileSize followed by '|'.
- Step 5 - Evaluate withProgress: if null or FALSE, append 'N|' to submitString; if TRUE, append 'Y|'.
- Step 6 - Concatenate sourceURL, clientDestination, progressTitle (defaulting to a single space if null), progressSubTitle (defaulting to a single space if null), and progressMessage (defaulting to a single space if null) to submitString, each separated by '|'.
- Step 7 - Submit the fully assembled submitString to the WebUtil Core bean by calling WebUtil_Core.setProperty with property key 'WUC_URL_DOWNLOAD'.
- Step 8 - Retrieve the result of the download operation by calling WebUtil_Core.getProperty with the same property key.
- Step 9 - Return TRUE if the retrieved result string equals 'TRUE'; otherwise return FALSE.
- Step 10 - If the WebUtil_Core.BEAN_NOT_REGISTERED exception is raised, display an error alert identifying the missing bean class and raise FORM_TRIGGER_FAILURE.
- Step 11 - If the WebUtil_Core.PROPERTY_ERROR exception is raised, raise FORM_TRIGGER_FAILURE.

---
**Decision Points**

DP-001

Condition: sourceURL IS NULL

TRUE: Raise URL_NULL exception; log error code 25 via WebUtil_Core.Error referencing 'WEBUTIL_CORE.DownloadFromURLInt'; return FALSE.

FALSE: Continue to validate clientDestination.

---

DP-002

Condition: clientDestination IS NULL

TRUE: Raise CLIENT_FILE_NULL exception; log error code 130 via WebUtil_Core.Error referencing 'WEBUTIL_CORE.DownloadFromURLInt'; return FALSE.

FALSE: Continue to build the submitString.

---

DP-003

Condition: specialDestination IS NULL OR specialDestination < 0 OR specialDestination > 2

TRUE: Prepend '0|' to submitString (default to no special destination).

FALSE: Prepend the character representation of specialDestination followed by '|' to submitString.

---

DP-004

Condition: fileSize IS NULL

TRUE: Append '0|' to submitString.

FALSE: Append the character representation of fileSize followed by '|' to submitString.

---

DP-005

Condition: withProgress IS NULL OR withProgress = FALSE

TRUE: Append 'N|' to submitString (progress indicator suppressed).

FALSE: Append 'Y|' to submitString (progress indicator enabled).

---

DP-006

Condition: Result string returned by WebUtil_Core.getProperty equals 'TRUE'

TRUE: Function returns TRUE, indicating a successful download.

FALSE: Function returns FALSE, indicating the download did not complete successfully.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - sourceURL is mandatory; a null value is a hard error that prevents execution and returns FALSE.
- BR-002 - clientDestination is mandatory; a null value is a hard error that prevents execution and returns FALSE.
- BR-003 - specialDestination must be an integer in the range 0-2 inclusive; any null, negative, or out-of-range value is silently coerced to 0.
- BR-004 - fileSize defaults to 0 when null, ensuring the downstream bean always receives a numeric file-size token.
- BR-005 - Progress indicator parameters (progressTitle, progressSubTitle, progressMessage) are optional; null values are replaced with a single space to maintain the integrity of the pipe-delimited submitString structure.
- BR-006 - The pipe character ('|') is used exclusively as the field delimiter within the submitString submitted to the WebUtil Core bean; no pipe characters may appear within individual parameter values without risk of misparse.
- BR-007 - If the WebUtil Core bean is not registered, the procedure raises FORM_TRIGGER_FAILURE after alerting the user, preventing silent failure of the download operation.
- BR-008 - If a property error is returned by the WebUtil Core bean, the procedure raises FORM_TRIGGER_FAILURE to halt further form processing.

---
**Implementation Logic**

```plsql
  
  FUNCTION DownLoadFromURLInt(sourceURL          in VARCHAR2, 
                              clientDestination  in VARCHAR2, 
                              specialDestination in PLS_INTEGER default 0,                             
                              fileSize           in PLS_INTEGER default 0, 
                              withProgress       in BOOLEAN default false,
                              progressTitle      in VARCHAR2 default null,
                              progressSubTitle   in VARCHAR2 default null,
                              progressMessage    in VARCHAR2 default null) return BOOLEAN is
    result       VARCHAR2(6) := 'FALSE';
    submitString VARCHAR2(4000 char);
    sep          VARCHAR2(1) := '|';
  BEGIN
    if sourceURL is null then
      raise URL_NULL;
    end if;
    if clientDestination is null then
      raise CLIENT_FILE_NULL;
    end if;

    if specialDestination is null or specialDestination < 0 or specialDestination > 2 then 
      submitString := '0'||sep;
    else
      submitString := to_char(specialDestination)||sep;
    end if;
    if fileSize is null then 
      submitString := submitString||'0'||sep;
    else
      submitString := submitString||to_char(fileSize)||sep;
    end if;
    if withProgress is null or not withProgress then 
      submitString := submitString||'N'||sep;
    else
      submitString := submitString||'Y'||sep;
    end if;    

    submitString := submitString||sourceURL
                    ||sep||clientDestination
                    ||sep||nvl(progressTitle,' ')
                    ||sep||nvl(progressSubTitle,' ')
                    ||sep||nvl(progressMessage,' ');                         
  WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_URL_DOWNLOAD',submitString,true);
  result := WebUtil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_URL_DOWNLOAD');
  return (result='TRUE');
  EXCEPTION  
    when CLIENT_FILE_NULL then
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE, 130, 'WEBUTIL_CORE.DownloadFromURLInt');
      return false;
    when URL_NULL then
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE,25, 'WEBUTIL_CORE.DownloadFromURLInt');
      return false;

    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                              ||' bean not found. WEBUTIL_CORE.DownloadFromURLInt will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;
  END DownLoadFromURLInt;
```

#### SP-018 - WEBUTIL.ERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Constructs a structured error message string from a numeric error code, a program unit name, and up to three optional argument values, then publishes the assembled message to the WebUtil core property 'WUC_ERROR_MSG' for the specified package instance. This centralises error reporting within the WebUtil framework so that calling code (WEBUTIL_CORE.CUSTOMEVENTHANDLER) can retrieve a consistently formatted error notification.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |
| code | PLS_INTEGER | IN |
| pu_name | VARCHAR2 | IN |
| arg1 | VARCHAR2 | IN |
| arg2 | VARCHAR2 | IN |
| arg3 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the package instance identifier (packageID), a numeric error code (code), the originating program unit name (pu_name), and up to three optional supplementary argument strings (arg1, arg2, arg3).
- Step 2 - Initialise the error text string by concatenating the literal prefix 'ERROR', the error code zero-padded to three digits (e.g. code 5 becomes '005'), a pipe delimiter '|', and the program unit name (pu_name).
- Step 3 - Evaluate whether arg1 is not null; if so, append a pipe delimiter followed by arg1 to the error text string.
- Step 4 - Evaluate whether arg2 is not null; if so, append a pipe delimiter followed by arg2 to the error text string.
- Step 5 - Evaluate whether arg3 is not null; if so, append a pipe delimiter followed by arg3 to the error text string.
- Step 6 - Invoke Webutil_Core.setProperty to store the fully assembled error text string against the property key 'WUC_ERROR_MSG' for the given packageID, making the error message available to the calling framework.

---
**Decision Points**

DP-001

Condition: arg1 IS NOT NULL

TRUE: Append '|' || arg1 to the error text string.

FALSE: arg1 is omitted from the error text string; no change is made.

---

DP-002

Condition: arg2 IS NOT NULL

TRUE: Append '|' || arg2 to the error text string.

FALSE: arg2 is omitted from the error text string; no change is made.

---

DP-003

Condition: arg3 IS NOT NULL

TRUE: Append '|' || arg3 to the error text string.

FALSE: arg3 is omitted from the error text string; no change is made.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The error message must always begin with the fixed prefix 'ERROR' followed immediately by the numeric code formatted as a zero-padded three-digit string (e.g. 'ERROR005'), ensuring a consistent, parseable message format across all WebUtil error events.
- BR-002 - The program unit name (pu_name) is mandatory and must always be included as the second pipe-delimited segment of the error message, identifying the origin of the error.
- BR-003 - Supplementary arguments (arg1, arg2, arg3) are optional; only non-null arguments are appended to the error message, preventing empty pipe-delimited segments in the output string.
- BR-004 - The assembled error message must not exceed 1 024 characters, as enforced by the VARCHAR2(1024) declaration of the internal errText variable.
- BR-005 - The finalised error message must be published to the WebUtil core property 'WUC_ERROR_MSG' via Webutil_Core.setProperty, scoped to the package instance identified by packageID, so that the error is retrievable by the invoking framework context.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Error(packageID in PLS_INTEGER,
                  code      in PLS_INTEGER,
                  pu_name   in VARCHAR2,
                  arg1      in VARCHAR2 :=null,
                  arg2      in VARCHAR2 := null,
                  arg3      in VARCHAR2 := null
                 ) is
    errText varchar2(1024);
  begin 
    errText := 'ERROR'||lpad(to_char(code),3,'0') || '|' || pu_name;
    if arg1 is not null then
      errText := errText || '|' || arg1;
    end if;
    if arg2 is not null then
      errText := errText || '|' || arg2;
    end if;
    if arg3 is not null then
      errText := errText || '|' || arg3;
    end if;
    Webutil_Core.setProperty(packageID, 'WUC_ERROR_MSG', errText);
  end Error;
```

#### SP-019 - WEBUTIL.ERRORALERT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]
- webutil.pld [StoredProcedure: WEBUTIL.LOG]
- webutil.pld [StoredProcedure: WEBUTIL.POPULATEPROPERTYBUNDLE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Displays an error message to the user via the WebUtil error alert object. If the error alert handle is not null, it sets the alert message text and shows the alert; otherwise it falls back to displaying the error as a standard Forms message.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| errText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-037](#SP-037--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Check whether the WebUtil error alert handle is not null (i.e. the error alert object has been initialised).
- Step 2 - If the handle is not null, set the alert message text to the provided error text and display the alert to the user.
- Step 3 - If the handle is null (alert object not available), fall back to displaying the error using a standard Forms message prefixed with 'WebUtil Error:'.

---
**Decision Points**

DP-001

Condition:
The WebUtil error alert handle (m_errorAlert) is not null

TRUE:
Set the alert message text to the provided error text and show the alert dialog to the user

FALSE:
Display the error as a standard Forms message with the 'WebUtil Error:' prefix

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Error messages from WebUtil operations are always displayed to the user; the display method adapts based on whether the WebUtil error alert object has been initialised (alert dialog preferred, Forms message as fallback).

---
**Implementation Logic**

```plsql
  
  PROCEDURE ErrorAlert(errText in VARCHAR2) is
    -- currently used for throwing a BEAN_NOT_REGISTERED or bean not found error.
    ignore integer;
  begin
    if not ID_NULL(m_errorAlert) then 
      --SET_ALERT_PROPERTY(m_errorAlert,TITLE,'WebUtil Error'); -- title already set in alert property
      SET_ALERT_PROPERTY(m_errorAlert,ALERT_MESSAGE_TEXT,errText);
      ignore := SHOW_ALERT(m_errorAlert);
    else
      message('WebUtil Error'||': '||errText);
    end if;
  end ErrorAlert;
```

#### SP-020 - WEBUTIL.EXECUTE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.BLOCKING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Submits a shell command to the WebUtil host execution framework and returns a process handle identifying the launched process. The procedure sets the desired execution mode and command string as properties on the WebUtil host package bean, then retrieves the resulting process identifier. It is invoked by WEBUTIL.BLOCKING to support controlled, blocking or non-blocking host-side command execution from an Oracle Forms session.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |
| exemode | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the command string (cmd) and the execution mode flag (exemode) as input parameters.
- Step 2 - Evaluate whether cmd is non-null; if null, skip all processing and return an uninitialised PROCESS_ID record.
- Step 3 - Set the execution mode on the WebUtil host package bean by calling WebUtil_Core.setProperty with property key WUH_EXECUTION_MODE and the supplied exemode value.
- Step 4 - Set the command to be executed on the WebUtil host package bean by calling WebUtil_Core.setProperty with property key WUH_EXECUTE and the supplied cmd value.
- Step 5 - Retrieve the process handle assigned by the bean by calling WebUtil_Core.getProperty with property key WUH_EXECUTE and convert the returned string to a number, storing it in procId.handle.
- Step 6 - Return the populated PROCESS_ID record to the caller.
- Step 7 - If a WebUtil_Core.BEAN_NOT_REGISTERED exception is raised at any point, display an error alert identifying the missing bean class and indicating that WEBUTIL_HOST.Execute will not function.

---
**Decision Points**

DP-001

Condition: The input parameter cmd IS NOT NULL.

TRUE: Set the execution mode and command properties on the WebUtil host bean, retrieve the resulting process handle, and populate procId.handle before returning.

FALSE: Bypass all bean interactions and return an uninitialised PROCESS_ID record to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A host command will only be dispatched to the WebUtil execution framework if the cmd parameter is non-null; a null command results in a no-operation return with an empty process handle.
- BR-002 - The execution mode (exemode) must be supplied and is applied to the bean before the command is set, ensuring the framework honours the intended blocking or non-blocking behaviour for every execution request.
- BR-003 - The WebUtil host package bean (WUH_PACKAGE) must be registered and available at runtime; if it is not, the procedure raises an error alert citing the missing implementation class and the function will not execute.
- BR-004 - The process handle returned to the caller is derived exclusively from the value the WebUtil bean assigns after accepting the WUH_EXECUTE property, converted to a numeric identifier; no alternative source for the handle is used.

---
**Implementation Logic**

```plsql
  FUNCTION Execute (cmd in VARCHAR2, exemode in PLS_INTEGER) return PROCESS_ID is
    procId PROCESS_ID;
  begin 
    if cmd is not null then 
      WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTION_MODE',exemode);            
      WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTE',cmd);      
      procId.handle := to_number(WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTE'));
    end if;
    return procId;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.Execute will not work');
  end Execute;
```

#### SP-021 - WEBUTIL.FCLOSE

**Invoked From:**

- vr_bshop_tech_prod_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes a client-side text file that was previously opened via FOPEN. If the file handle is active, the procedure instructs the WebUtil core bean to close the file and clears the handle. If the required WebUtil bean is not registered on the client, it delegates error messaging to WEBUTIL.ERRORALERT and uses WEBUTIL.GETIMPLCLASS to identify the missing implementation class before raising a tool error. A property error on the bean interaction also raises a tool error.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-019](#SP-019--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETIMPLCLASS ([SP-026](#SP-026--WEBUTIL.GETIMPLCLASS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate whether the file handle is not null, indicating the file is currently open.
- Step 2 - If the handle is not null, invoke the WebUtil core bean property setter to issue a close command (WUF_TEXTIO_CLOSE) against the file handle, then set the handle to null to mark the file as closed.
- Step 3 - If a BEAN_NOT_REGISTERED exception is raised, call WEBUTIL.GETIMPLCLASS to resolve the display name of the missing WUF_PACKAGE implementation class, then pass a descriptive message to WEBUTIL.ERRORALERT informing the user that the bean was not found and that CLIENT_TEXT_IO.fclose will not work.
- Step 4 - After displaying the alert, raise TOOL_ERROR to halt further processing.
- Step 5 - If a PROPERTY_ERROR exception is raised instead, raise TOOL_ERROR directly without displaying an alert.

---
**Decision Points**

DP-001

Condition:
The file handle (file.handle) is not null

TRUE:
Invoke the WebUtil core bean to close the file associated with the handle, then set the handle to null

FALSE:
Skip all close logic; the file is already closed or was never opened

---

DP-002

Condition:
A BEAN_NOT_REGISTERED exception is caught during bean interaction

TRUE:
Resolve the implementation class name via WEBUTIL.GETIMPLCLASS, display an error alert via WEBUTIL.ERRORALERT, then raise TOOL_ERROR

FALSE:
Continue normal exception handling (evaluate for PROPERTY_ERROR)

---

DP-003

Condition:
A PROPERTY_ERROR exception is caught during bean interaction

TRUE:
Raise TOOL_ERROR immediately

FALSE:
No further exception handling required

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A file is only closed if its handle is not null; attempting to close an already-closed or never-opened file is silently ignored with no error raised.
- BR-002 - When the WebUtil bean is not registered on the client, WEBUTIL.GETIMPLCLASS must be called to obtain the implementation class name before WEBUTIL.ERRORALERT presents the failure message, ensuring the alert identifies the specific missing component.
- BR-003 - Both BEAN_NOT_REGISTERED and PROPERTY_ERROR conditions must terminate processing by raising TOOL_ERROR, preventing silent data corruption or an inconsistent file state.
- BR-004 - The file handle is set to null only after a successful bean close command; if an exception interrupts the close, the handle state is governed by the exception path rather than being forcibly nulled.

---
**Implementation Logic**

```plsql
 
  PROCEDURE fclose (file IN OUT file_type) is 
  BEGIN 
    if (file.handle IS NOT NULL) then 
      WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CLOSE',file.handle);        
      file.handle := NULL;
    end if;
 
 EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.fclose will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;
  END fclose;
```

#### SP-022 - WEBUTIL.FOPEN

**Invoked From:**

- vr_bshop_tech_prod_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Opens a client-side text file for reading, writing, or appending via the WebUtil client-side Java bean. Validates the file mode and file specification, sets the required properties on the WebUtil bean, retrieves the resulting Java file handle through WEBUTIL.GETPROPERTY, and returns a numeric file handle to the caller. Raises a tool error if the mode is invalid, the filename is blank, the file cannot be opened, or the WebUtil bean is not registered.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| spec | VARCHAR2 | IN |
| filemode | VARCHAR2 | IN |
| charSet | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETPROPERTY ([SP-032](#SP-032--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Validate the file mode; if it is not one of 'r' (read), 'w' (write), or 'a' (append) (case-insensitive), raise a tool error immediately.
- Step 2 - Validate that a file specification has been provided; if it is null or empty, raise a tool error immediately.
- Step 3 - Set the filename property (WUF_FILENAME) on the WebUtil bean via WebUtil_Core.setProperty.
- Step 4 - Set the file mode property (WUF_TEXTIO_FILEMODE) on the WebUtil bean via WebUtil_Core.setProperty.
- Step 5 - Evaluate the charSet parameter: if null, set the charset property (WUF_TEXTIO_CHARSET) to the literal '(null)'; otherwise set it to the supplied character set value.
- Step 6 - Invoke WEBUTIL.GETPROPERTY (via WebUtil_Core.getProperty) to request the WebUtil bean to open the file and retrieve the resulting Java file handle (WUF_TEXTIO_OPEN).
- Step 7 - If the returned Java handle is null, empty, or '-1', raise a tool error to signal that the file could not be opened.
- Step 8 - Convert the valid Java handle to a numeric value, assign it to the file_type record's handle field, and return it to the caller.
- Step 9 - In the exception block: if the bean is not registered, display an error alert and raise a tool error; re-raise PROPERTY_ERROR, VALUE_ERROR (as a tool error), and TOOL_ERROR as appropriate.

---
**Decision Points**

DP-001

Condition:
The file mode (case-insensitive) is not one of 'r', 'w', or 'a'

TRUE:
Raise a tool error immediately; processing stops

FALSE:
Continue to file specification validation

---

DP-002

Condition:
The file specification (spec) is null or empty

TRUE:
Raise a tool error immediately; processing stops

FALSE:
Proceed to set WebUtil bean properties

---

DP-003

Condition:
The charSet parameter is null

TRUE:
Pass the literal '(null)' as the WUF_TEXTIO_CHARSET property value to the WebUtil bean

FALSE:
Pass the supplied charSet value as the WUF_TEXTIO_CHARSET property value to the WebUtil bean

---

DP-004

Condition:
The Java file handle returned by WEBUTIL.GETPROPERTY (WUF_TEXTIO_OPEN) is null, empty, or '-1'

TRUE:
Raise a tool error to indicate the file could not be opened

FALSE:
Convert the handle to a numeric value and return it as the file_type handle

---

DP-005

Condition:
An exception is raised during processing

TRUE (BEAN_NOT_REGISTERED):
Display an error alert identifying the missing bean class and raise a tool error

TRUE (PROPERTY_ERROR):
Re-raise the exception as-is

TRUE (VALUE_ERROR or TOOL_ERROR):
Raise (or re-raise) a tool error

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only the file modes 'r' (read), 'w' (write), and 'a' (append) are valid (evaluated case-insensitively); any other mode causes an immediate tool error before any bean interaction.
- BR-002 - A non-null, non-empty file path must be supplied; a missing or blank path causes an immediate tool error before any bean interaction.
- BR-003 - When no character set is specified, the WebUtil bean must receive the literal string '(null)' for the WUF_TEXTIO_CHARSET property; the actual null value is never passed directly to the bean.
- BR-004 - The Java file handle is obtained exclusively through WEBUTIL.GETPROPERTY (WUF_TEXTIO_OPEN); a null, empty, or '-1' result indicates failure and triggers a tool error.
- BR-005 - If the WebUtil bean is not registered on the client, an informational error alert is displayed before the tool error is raised, identifying the missing implementation class.

---
**Implementation Logic**

```plsql
  FUNCTION fopen(spec VARCHAR2, filemode VARCHAR2, charSet VARCHAR2 := null) RETURN file_type is
    clientFile file_type;
    javaHandle VARCHAR2(6);
  BEGIN
    -- check the mode is valid
    if (lower(filemode) not in ('r','w','a')) then 
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- make sure a file name has been specified      
    if (spec is null) or (spec='') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;
      
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILENAME',spec, true);
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_FILEMODE',filemode, true);        
    if (charSet is null) then
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET','(null)', true);
    else
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET',charSet, true);
    end if;
    javaHandle := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_OPEN');

    -- If the return is null then the file was not opened      
    if (javaHandle is null) or (javaHandle='') or (javaHandle='-1') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- if we are this far convert the handle to the correct format and return it.      
    clientFile.handle := to_number(javaHandle);
    return clientFile;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.fopen will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                 
      return null;
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE;
    when VALUE_ERROR then
      RAISE TOOL_ERR.TOOL_ERROR; 
    when TOOL_ERR.TOOL_ERROR then 
      RAISE;
  END fopen;
```

#### SP-023 - WEBUTIL.GETCALLBACKTRIGGER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the name of the callback trigger associated with a given numeric key from the internal callbacks collection. This function is used by WEBUTIL.SETDATA to resolve which trigger string corresponds to a specific callback identifier during WebUtil data-setting operations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| callbackKey | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the integer callback key (callbackKey) as input.
- Step 2 - Look up the corresponding trigger name in the internal package-level collection m_callbacks using callbackKey as the index.
- Step 3 - Return the VARCHAR2 trigger name retrieved from the collection to the caller.

---
**Decision Points**

No decision points are present in this function. The implementation performs a direct indexed lookup against the m_callbacks collection and returns the result unconditionally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The callbackKey parameter must correspond to a valid, pre-existing index in the m_callbacks collection; supplying an undefined index will result in a runtime collection error.
- BR-002 - The function returns a VARCHAR2 value representing the trigger name exactly as stored in m_callbacks; no transformation or defaulting is applied to the retrieved value.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetCallbackTrigger(callbackKey in PLS_INTEGER) return VARCHAR2 is 
  begin 
    return m_callbacks(callbackKey);
  end GetCallbackTrigger;
```

#### SP-024 - WEBUTIL.GETCLIENTOSFAMILY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the operating system family identifier of the client machine as a PLS_INTEGER value. This function exposes the internally stored client OS family variable (m_clientOSFamily) to callers, enabling the application to determine the client platform category for conditional processing or display logic.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - The function is invoked with no input parameters.
- Step 2 - The function reads the value of the internal module-level variable m_clientOSFamily, which holds the client operating system family identifier.
- Step 3 - The function returns the PLS_INTEGER value of m_clientOSFamily directly to the caller.

---
**Decision Points**

No decision points are present. The function unconditionally reads and returns the value of m_clientOSFamily without branching logic.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function accepts no input parameters; the client OS family value is sourced exclusively from the pre-populated internal variable m_clientOSFamily.
- BR-002 - The return value is typed as PLS_INTEGER, representing the client operating system family as a numeric identifier.
- BR-003 - The function performs no computation, transformation, or validation on m_clientOSFamily; the value is returned as-is.

---
**Implementation Logic**

```plsql

  FUNCTION GetClientOSFamily return PLS_INTEGER is 
  begin 
    return m_clientOSFamily;
  end GetClientOSFamily;
```

#### SP-025 - WEBUTIL.GETCLIENTSETTING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a named client-side configuration setting by delegating the property lookup to the WebUtil Core bean. The function accepts a property name, sets a request on the WUC_PACKAGE bean, reads back the resolved value, and returns it to the caller (WEBUTIL.CHECKLIBS or WEBUTIL.REGISTERBEAN). If the underlying bean is not registered or the property lookup fails, the function raises an appropriate error and halts form processing.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameter propertyName (VARCHAR2).
- Step 2 - Evaluate whether propertyName is not null; if null, skip the lookup and return a null result.
- Step 3 - Call WebUtil_Core.setProperty, passing the constant WebUtil_Core.WUC_PACKAGE and the key 'WUC_GET_LOCAL_PROPERTY' together with the supplied propertyName, to request the client-side setting from the WebUtil Core bean.
- Step 4 - Call WebUtil_Core.getProperty with the same package constant and key to retrieve the value resolved by the bean, and assign it to the local variable result.
- Step 5 - Return result to the caller.
- Step 6 - If the exception WebUtil_Core.BEAN_NOT_REGISTERED is raised during Steps 3-4, display an error alert identifying the missing implementation class and raise FORM_TRIGGER_FAILURE to halt processing.
- Step 7 - If the exception WebUtil_Core.PROPERTY_ERROR is raised during Steps 3-4, raise FORM_TRIGGER_FAILURE to halt processing without an additional alert.

---
**Decision Points**

DP-001

Condition: propertyName IS NOT NULL

TRUE: Proceed to set the property request on the WebUtil Core bean (WUC_PACKAGE / WUC_GET_LOCAL_PROPERTY) and retrieve the resolved client-side value.

FALSE: Skip the bean interaction entirely and return a null value to the caller.

---

DP-002

Condition: WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during the bean property set/get operation.

TRUE: Display an error alert identifying the missing WebUtil Core implementation class and raise FORM_TRIGGER_FAILURE to abort form processing.

FALSE: No exception of this type; continue normal execution.

---

DP-003

Condition: WebUtil_Core.PROPERTY_ERROR exception is raised during the bean property set/get operation.

TRUE: Raise FORM_TRIGGER_FAILURE to abort form processing (no alert is displayed).

FALSE: No exception of this type; continue normal execution.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A null propertyName must not trigger a bean interaction; the function must return null immediately without calling WebUtil_Core.setProperty or WebUtil_Core.getProperty.
- BR-002 - The client setting lookup must be performed exclusively through the WebUtil Core bean identified by the constant WebUtil_Core.WUC_PACKAGE using the designated key 'WUC_GET_LOCAL_PROPERTY'; no direct client-side or database access is permitted.
- BR-003 - If the WebUtil Core bean is not registered at the time of the call, the function must display a descriptive error alert (including the bean's implementation class name) and raise FORM_TRIGGER_FAILURE, preventing any further form processing.
- BR-004 - If a property error occurs during the bean interaction, the function must raise FORM_TRIGGER_FAILURE immediately without displaying an alert, ensuring consistent form-level error handling.
- BR-005 - The returned value is limited to 255 characters; any client setting value exceeding this length will be truncated to fit the declared result variable.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetClientSetting(propertyName in VARCHAR2) return VARCHAR2 is 
    result VARCHAR2(255 char);
  BEGIN
    if propertyName is not null then 
    WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_GET_LOCAL_PROPERTY', propertyName);
       result := WebUtil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_GET_LOCAL_PROPERTY');
    end if;
    return result;
  EXCEPTION  
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                            ||' bean not found. WEBUTIL_CORE.GetClientSetting will not work');
    RAISE FORM_TRIGGER_FAILURE;  
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE FORM_TRIGGER_FAILURE;       
  END GetClientSetting;
```

#### SP-026 - WEBUTIL.GETIMPLCLASS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the fully qualified Java class name for a given WebUtil package identifier by concatenating the WebUtil Java root path with the registered implementation class name for that package. Used internally by WebUtil error reporting to identify which bean class was not found.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the package identifier as input.
- Step 2 - Concatenate the WebUtil Java root path constant with the implementation class name stored in the internal implementation class registry for the given package identifier.
- Step 3 - Return the fully qualified Java class name string.

---
**Decision Points**

No conditional branches present in the Implementation Logic.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The fully qualified Java class name for a WebUtil package is always derived by combining the WebUtil Java root path with the package-specific implementation class name from the internal registry.

---
**Implementation Logic**

```plsql

  FUNCTION getImplClass(packageID PLS_INTEGER) return VARCHAR2 is
  BEGIN 
    return WEBUTIL_JAVA_ROOT||m_implClasses(packageID);    
  END;
```

#### SP-027 - WEBUTIL.GETLASTERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the last error code recorded by the AppServerFileReader Java object. The function interrogates the underlying Java instance via a JNI integer method call and returns the numeric error code to the caller (WEBUTIL.SETDATA), enabling error-state inspection after file-transfer operations performed by the AppServerFileReader component.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the AppServerFileReader Java object reference (obj) as input.
- Step 2 - Clear the JNI argument list by setting args to NULL, ensuring no stale arguments are passed to the Java method.
- Step 3 - Invoke the Java instance method getLastError on the AppServerFileReader object via JNI.CALL_INT_METHOD, targeting the method signature '()I' (no arguments, integer return) on the class oracle/forms/webutil/fileTransfer/AppServerFileReader.
- Step 4 - Return the integer error code obtained from the Java method call to the invoking routine.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function unconditionally clears the argument list and delegates the call to the Java layer, returning whatever integer value the AppServerFileReader instance reports.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The argument list (args) must be reset to NULL before each JNI call to prevent unintended argument data from a previous operation being passed to the Java method.
- BR-002 - The target Java class is fixed as oracle/forms/webutil/fileTransfer/AppServerFileReader and the method signature is fixed as '()I'; no variation in class or method resolution is permitted at runtime.
- BR-003 - The function returns a numeric error code only; interpretation and handling of the returned value is the responsibility of the calling routine (WEBUTIL.SETDATA).

---
**Implementation Logic**

```plsql
  FUNCTION getLastError(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_INT_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'getLastError', '()I', args); 
  END;
```

#### SP-028 - WEBUTIL.GETLASTERRORARGS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the argument string associated with the most recent error raised by the AppServerFileReader Java class. The function delegates the call to the underlying Java Native Interface (JNI) layer, returning the error argument payload as a VARCHAR2 string for use by the calling routine (WEBUTIL.SETDATA).

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the Java object reference (obj) that identifies the AppServerFileReader instance on which the last error occurred.
- Step 2 - Clear the args variable by setting it to NULL, ensuring no residual argument data from a prior call is carried forward.
- Step 3 - Invoke the Java method getLastErrorArgs on the oracle/forms/webutil/fileTransfer/AppServerFileReader class via JNI.CALL_STRING_METHOD, passing the cleared args value and the method signature '()Ljava/lang/String;'.
- Step 4 - Return the VARCHAR2 string produced by the JNI call to the caller, representing the error argument details from the last AppServerFileReader error.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a linear sequence: clear args, invoke the JNI method, and return the result unconditionally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The args variable must be explicitly set to NULL before the JNI call to prevent stale argument data from a previous invocation from being passed to the Java method.
- BR-002 - The target Java method must be resolved against the fully qualified class oracle/forms/webutil/fileTransfer/AppServerFileReader using the exact method signature '()Ljava/lang/String;'; any deviation would result in a failed JNI dispatch.
- BR-003 - The function returns the raw error argument string as provided by the Java layer without transformation; interpretation of the returned value is the responsibility of the calling routine (WEBUTIL.SETDATA).

---
**Implementation Logic**

```plsql
  FUNCTION getLastErrorArgs(
    obj   ORA_JAVA.JOBJECT) RETURN VARCHAR2 IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_STRING_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'getLastErrorArgs', '()Ljava/lang/String;', args); 
  END;
```

#### SP-029 - WEBUTIL.GETNUMBER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Extracts a delimited field from a source string at a specified position and returns its value as a NUMBER. The procedure delegates string extraction to WEBUTIL.GETSTRING and applies a TO_NUMBER conversion to the result, providing callers with a type-safe numeric value without requiring them to perform the conversion themselves.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Source_string | varchar2 | IN |
| Field_position | number | IN |
| UnTerminated | Boolean | IN |
| Delimiter | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETSTRING ([SP-033](#SP-033--WEBUTIL.GETSTRING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the source string, the target field position, an optional flag indicating whether the final field is unterminated, and an optional delimiter character (defaulting to a comma).
- Step 2 - Invoke WEBUTIL.GETSTRING, passing all four arguments unchanged, to extract the raw VARCHAR2 token at the specified field position within the delimited source string.
- Step 3 - Apply the Oracle built-in TO_NUMBER function to the VARCHAR2 value returned by WEBUTIL.GETSTRING.
- Step 4 - Return the resulting NUMBER value to the caller.

---
**Decision Points**

- DP-001

  Condition: UnTerminated parameter is TRUE.

  TRUE: WEBUTIL.GETSTRING treats the final field in the source string as unterminated (i.e., not followed by a delimiter) when locating the requested position.

  FALSE: WEBUTIL.GETSTRING treats all fields, including the final one, as delimiter-terminated when locating the requested position.

- DP-002

  Condition: The VARCHAR2 token returned by WEBUTIL.GETSTRING is a valid numeric string that TO_NUMBER can convert without error.

  TRUE: Conversion succeeds and the numeric value is returned to the caller.

  FALSE: Oracle raises a VALUE_ERROR (or equivalent numeric conversion exception); no result is returned and the exception propagates to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The delimiter character defaults to a comma (',') if not explicitly supplied by the caller; any single-character delimiter supported by WEBUTIL.GETSTRING may be used.
- BR-002 - The UnTerminated flag defaults to FALSE, meaning the source string is assumed to have a delimiter following every field, including the last.
- BR-003 - All field-extraction logic is fully delegated to WEBUTIL.GETSTRING; WEBUTIL.GETNUMBER performs no independent parsing of the source string.
- BR-004 - The extracted token must represent a value that Oracle's TO_NUMBER function can convert; non-numeric content in the targeted field position will cause a runtime conversion error that is not handled within this function.

---
**Implementation Logic**

```plsql

    
  function  GetNumber (Source_string    in varchar2,
                       Field_position   in number,
                       UnTerminated     in Boolean  default FALSE,
                       Delimiter        in varchar2 default ',') return number is
                       iRc              pls_integer;
  begin 
    Return to_number(GetString(Source_string, Field_Position, UnTerminated, Delimiter));
  end GetNumber; /* Number Version */
```

#### SP-030 - WEBUTIL.GETOSFAMILY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines and caches the client operating system family by inspecting the supplied OS name string and mapping it to a predefined platform constant (e.g., CLIENT_PLATFORM_WIN32, CLIENT_PLATFORM_MAC, CLIENT_PLATFORM_LINUX, CLIENT_PLATFORM_SOLARIS, CLIENT_PLATFORM_HP, CLIENT_PLATFORM_AIX, or CLIENT_PLATFORM_UNKNOWN). The resolved platform value is stored in the module-level variable m_clientOSFamily so that subsequent calls return the cached result without re-evaluating the OS name. This function is invoked by WEBUTIL.REGISTERBEAN to identify the client platform before proceeding with bean registration.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| osName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input OS name string (osName) and convert it to lowercase, storing the result in the local variable l_osName to enable case-insensitive matching.
- Step 2 - Initialise the local result variable to CLIENT_PLATFORM_UNKNOWN as the default platform value.
- Step 3 - Check whether the module-level cache variable m_clientOSFamily is null; if it is not null, skip all evaluation steps and proceed directly to Step 10, returning the cached value.
- Step 4 - If m_clientOSFamily is null, evaluate l_osName for the substring 'windows'; if found, set result to CLIENT_PLATFORM_WIN32.
- Step 5 - If 'windows' was not matched, evaluate l_osName for the substring 'mac'; if found, set result to CLIENT_PLATFORM_MAC.
- Step 6 - If no match yet, evaluate l_osName for the substring 'linux'; if found, set result to CLIENT_PLATFORM_LINUX.
- Step 7 - If no match yet, evaluate l_osName for the substring 'solaris' or 'sunos'; if either is found, set result to CLIENT_PLATFORM_SOLARIS.
- Step 8 - If no match yet, evaluate l_osName for the substring 'hp-ux'; if found, set result to CLIENT_PLATFORM_HP.
- Step 9 - If no match yet, evaluate l_osName for the substring 'aix'; if found, set result to CLIENT_PLATFORM_AIX.
- Step 10 - Assign the resolved result value to m_clientOSFamily, persisting it as the cached platform for the session.
- Step 11 - Return m_clientOSFamily to the caller.

---
**Decision Points**

DP-001

Condition: m_clientOSFamily IS NULL

TRUE: The OS name evaluation chain (DP-002 through DP-007) is executed to determine the platform constant, and the resolved value is written to m_clientOSFamily.

FALSE: The evaluation chain is bypassed entirely; the previously cached value of m_clientOSFamily is returned immediately.

---

DP-002

Condition: l_osName contains the substring 'windows'

TRUE: result is set to CLIENT_PLATFORM_WIN32; no further OS checks are performed.

FALSE: Evaluation continues to DP-003.

---

DP-003

Condition: l_osName contains the substring 'mac'

TRUE: result is set to CLIENT_PLATFORM_MAC; no further OS checks are performed.

FALSE: Evaluation continues to DP-004.

---

DP-004

Condition: l_osName contains the substring 'linux'

TRUE: result is set to CLIENT_PLATFORM_LINUX; no further OS checks are performed.

FALSE: Evaluation continues to DP-005.

---

DP-005

Condition: l_osName contains the substring 'solaris' OR l_osName contains the substring 'sunos'

TRUE: result is set to CLIENT_PLATFORM_SOLARIS; no further OS checks are performed.

FALSE: Evaluation continues to DP-006.

---

DP-006

Condition: l_osName contains the substring 'hp-ux'

TRUE: result is set to CLIENT_PLATFORM_HP; no further OS checks are performed.

FALSE: Evaluation continues to DP-007.

---

DP-007

Condition: l_osName contains the substring 'aix'

TRUE: result is set to CLIENT_PLATFORM_AIX.

FALSE: result remains CLIENT_PLATFORM_UNKNOWN, indicating the OS could not be classified.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The OS name comparison is performed in a case-insensitive manner; the input value is converted to lowercase before any substring matching occurs.
- BR-002 - Platform classification is mutually exclusive and evaluated in a fixed priority order: Windows -> Mac -> Linux -> Solaris/SunOS -> HP-UX -> AIX. The first matching condition wins and all subsequent checks are skipped.
- BR-003 - If the supplied OS name does not match any recognised platform keyword, the function returns CLIENT_PLATFORM_UNKNOWN; no error or exception is raised.
- BR-004 - The resolved platform value is cached in the module-level variable m_clientOSFamily after the first successful evaluation. All subsequent invocations within the same session return the cached value without re-evaluating the OS name string.
- BR-005 - SunOS is treated as equivalent to Solaris; both substrings map to the single constant CLIENT_PLATFORM_SOLARIS.

---
**Implementation Logic**

```plsql
 
  FUNCTION getOSFamily(osName in VARCHAR2) return PLS_INTEGER is
    l_osName VARCHAR2(30) := lower(osName);
    result   PLS_INTEGER  := CLIENT_PLATFORM_UNKNOWN;
  BEGIN
    if m_clientOSFamily  is null then 
      if (instr(l_osName,'windows') > 0) then 
           result := CLIENT_PLATFORM_WIN32;
      elsif instr(l_osName,'mac') > 0 then 
          result := CLIENT_PLATFORM_MAC;      
      elsif instr(l_osName,'linux') > 0 then 
          result := CLIENT_PLATFORM_LINUX;      
      elsif instr(l_osName,'solaris') > 0 OR instr(l_osName, 'sunos') > 0 then 
          result := CLIENT_PLATFORM_SOLARIS;       
      elsif instr(l_osName,'hp-ux') > 0 then 
          result := CLIENT_PLATFORM_HP; 
      elsif instr(l_osName,'aix') > 0 then 
          result := CLIENT_PLATFORM_AIX;                                                       
      end if;            
      m_clientOSFamily := result;
    end if;
    return m_clientOSFamily;
  END getOSFamily;
```

#### SP-031 - WEBUTIL.GETOUTPUT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GET_STANDARD_OUTPUT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves all lines of output from a previously spawned host process by repeatedly polling the WebUtil client-side bean for buffered output lines. The function accumulates each line into an OUTPUT_ARRAY and returns the complete array to the caller (WEBUTIL.GET_STANDARD_OUTPUT). Package initialisation ensures the WebUtil Core bean is instantiated before any property interaction occurs.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |
| prop | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.INIT ([SP-038](#SP-038--WEBUTIL.INIT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Set the process handle on the WebUtil Core package by calling WebUtil_Core.setProperty with the WUH_PACKAGE constant, the property key 'WUH_PROC_ID', and the handle value from the supplied PROCESS_ID parameter.
- Step 2 - Enter a loop and call WebUtil_Core.getProperty with the WUH_PACKAGE constant and the caller-supplied prop parameter to retrieve the next buffered output line from the client-side bean.
- Step 3 - Extract the first character of the returned buffer as a status indicator ('Y' = more lines to follow, 'N' = this is the last line, 'X' = buffer was empty).
- Step 4 - If the status is not 'X' (i.e., the buffer contained data), store the remainder of the buffer string (characters from position 2 onward) as the next element in the OUTPUT_ARRAY and increment the array index.
- Step 5 - Exit the loop when the status is not 'Y', meaning either the last line has been read ('N') or the buffer was empty ('X').
- Step 6 - Return the populated OUTPUT_ARRAY to the caller.
- Step 7 - If a BEAN_NOT_REGISTERED exception is raised at any point, display an error alert identifying the missing bean class and indicating that WEBUTIL_HOST.GetOutput will not function, then terminate without returning an array.
- Step 8 - At package initialisation (BEGIN block), call WebUtil_Core.Init to ensure the Core bean is instantiated before any function in the package is invoked.

---
**Decision Points**

DP-001

Condition: The status character extracted from the buffer equals 'X'.

TRUE: The buffer was empty; the current iteration does not add an entry to the OUTPUT_ARRAY and the index is not incremented.

FALSE: The buffer contained a valid line (status 'Y' or 'N'); the line content (buffer substring from position 2) is stored in the OUTPUT_ARRAY at the current index and the index is incremented.

DP-002

Condition: The status character extracted from the buffer is not 'Y'.

TRUE: No further output lines are expected (status is 'N' or 'X'); the loop exits and the accumulated OUTPUT_ARRAY is returned.

FALSE: Status is 'Y', indicating more lines remain; the loop continues to the next iteration to retrieve the next buffered line.

DP-003

Condition: A BEAN_NOT_REGISTERED exception is raised during execution.

TRUE: The WebUtil bean is not available on the client; an error alert is displayed identifying the missing bean class and the function terminates without returning output.

FALSE: No exception is raised; normal processing continues and the OUTPUT_ARRAY is returned to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The process handle must be registered with the WebUtil Core package via WebUtil_Core.setProperty before any output retrieval is attempted; this is performed unconditionally at the start of each GetOutput invocation.
- BR-002 - Output lines are identified by a single-character status prefix embedded in the buffer: 'Y' signals that additional lines follow, 'N' signals the final line, and 'X' signals an empty buffer. Only the substring from position 2 onward is treated as actual output content.
- BR-003 - Lines with a status of 'X' (empty buffer) are silently discarded and do not contribute an entry to the OUTPUT_ARRAY.
- BR-004 - If the required client-side bean is not registered, the procedure must not silently fail; it must surface an error alert that identifies the missing bean class and states that WEBUTIL_HOST.GetOutput will not work.
- BR-005 - The WebUtil Core bean must be initialised (via WebUtil_Core.Init) at package load time to guarantee that all functions within the package can interact with the client-side bean immediately upon invocation.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetOutput(process in PROCESS_ID, prop in VARCHAR2) return OUTPUT_ARRAY is   
    lines  OUTPUT_ARRAY;
    i      PLS_INTEGER := 1;
    buffer VARCHAR2(257 char);
    status VARCHAR2(1) := 'X';
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_PROC_ID',process.handle);
    LOOP
      buffer := WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,prop);
      status := substr(buffer,1,1);
      -- Status can be Y: indicating more lines to follow,
      --               N: indicating that this is the last line
      --               X: indicating that the buffer was empty
      if status <> 'X' then 
        lines(i) := substr(buffer,2);
        i := i + 1;
      end if;
      exit when status <> 'Y';
    END LOOP;
    return lines;    
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.GetOutput will not work');
  END GetOutput;  
  
BEGIN
    -- Ensure that Core is instanciated.
    Webutil_Core.Init;
END;

PACKAGE WEBUTIL_SEPARATEFRAME IS

/*********************************************************************************\
 * WEBUTIL_SEPARATEFRAME
 *   This Package contains routines to interact with the MDI frame when Forms
 *   is running with the parameter separateFrame=true
 *   The functions in this package will work with any client type - not just 
 *   Windows clients.
 *   The oracle.forms.webutil.browser.BrowserFunctions bean is needed in your 
 *   Form to use these functions
 *********************************************************************************
 * Version 1.0.0
 *********************************************************************************
 * Change History
 *   1.0.0 DRMILLS 25/MAY/2003 - Creation
 *   1.0.1 DRMILLS 27/MAY/2003 - Added call to get frame size 
 *
\*********************************************************************************/

  /**
   *  IsSeparateFrame - Allows you to check if the form 
   *                is running in separateFrame mode or not
   */
```

#### SP-032 - WEBUTIL.GETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FOPEN]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value of a named Java system property via JNI. Accepts a property name string and returns the corresponding value from the Java runtime environment. Used internally by WebUtil to read configuration and runtime properties.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the property name as input.
- Step 2 - Create a JNI argument list with one argument and add the property name string as the argument.
- Step 3 - Invoke the Java System.getProperty method via JNI, passing the property name.
- Step 4 - Return the property value string returned by the Java runtime.

---
**Decision Points**

No conditional branches present in the Implementation Logic.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Java system property values are retrieved at runtime via JNI, providing WebUtil with access to the Java runtime environment configuration.

---
**Implementation Logic**

```plsql
  FUNCTION getProperty(
    a0    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'getProperty', '(Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-033 - WEBUTIL.GETSTRING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETNUMBER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Extracts a single delimited token from a source string by position. Given a delimiter-separated string, a 1-based field position, an optional flag indicating whether the string lacks a trailing delimiter, and an optional delimiter character, the function returns the substring that occupies the requested position within the string. It is used internally by WEBUTIL.GETNUMBER to isolate individual fields from a concatenated string before numeric conversion.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Source_string | varchar2 | IN |
| Field_position | number | IN |
| UnTerminated | Boolean | IN |
| Delimiter | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-042](#SP-042--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Copy the input Source_string into a working variable (vcSourceStrCopy) to avoid mutating the original value.
- Step 2 - Evaluate the UnTerminated flag: if TRUE, append the Delimiter character to the end of vcSourceStrCopy so that the last token is bounded consistently with all other tokens.
- Step 3 - Determine the start position (iPtrStart) of the requested token: if Field_Position is greater than 1, locate the (Field_Position - 1)th occurrence of the Delimiter within vcSourceStrCopy using INSTR and advance the pointer past the delimiter by adding the length of the Delimiter; if Field_Position equals 1, set iPtrStart to 1 (the beginning of the string).
- Step 4 - Determine the end position (iPtrEnd) of the requested token by locating the Field_Position-th occurrence of the Delimiter within vcSourceStrCopy using INSTR.
- Step 5 - Extract and return the substring from iPtrStart for a length of (iPtrEnd - iPtrStart), which yields the token at the requested field position, excluding the surrounding delimiters.

---
**Decision Points**

DP-001

Condition: UnTerminated is TRUE.

TRUE: The Delimiter is appended to the working copy of the source string (vcSourceStrCopy) before any parsing occurs, ensuring the final token is bounded by a trailing delimiter and can be located by the same INSTR logic used for all other tokens.

FALSE: The source string is used as-is; it is assumed to already carry a trailing delimiter or the caller guarantees the last token is not being requested without a terminator.

---

DP-002

Condition: Field_Position is greater than 1.

TRUE: iPtrStart is calculated by finding the (Field_Position - 1)th occurrence of the Delimiter and advancing the pointer by the length of the Delimiter, positioning it at the first character of the requested token.

FALSE: Field_Position equals 1, so iPtrStart is set to 1, meaning extraction begins at the very start of the working string.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Field positions are 1-based; a Field_Position value of 1 always refers to the first token in the source string.
- BR-002 - When the source string does not carry a trailing delimiter after its last token, the caller must pass UnTerminated = TRUE so that the function appends the Delimiter internally; failure to do so will cause the last token to be unreachable via the standard INSTR boundary logic.
- BR-003 - The Delimiter parameter defaults to a comma (',') if not supplied; any single or multi-character delimiter may be specified, and its full length is accounted for when calculating iPtrStart.
- BR-004 - The function performs no database interactions; all processing is purely in-memory string manipulation.
- BR-005 - The function returns only the content between the bounding delimiters; the delimiter characters themselves are never included in the returned value.

---
**Implementation Logic**

```plsql

  function  GetString (Source_string    in varchar2,
                       Field_position   in number,
                       UnTerminated     in Boolean  default FALSE,
                       Delimiter        in varchar2 default ',') return varchar2 is
                       iPtrEnd          pls_integer     := 0;
                       iPtrStart        pls_integer     := 0;
                       vcSourceStrCopy  varchar2(32000)     := Source_string;
  begin
    if UnTerminated then 
      vcSourceStrCopy := vcSourceStrCopy||Delimiter;
    end if;

    if Field_Position > 1 then 
      iPtrStart := instr(vcSourceStrCopy,Delimiter,1,Field_Position-1)+ length(Delimiter);
    else
      iPtrStart := 1;
    end if ; 

    iPtrEnd     := instr(vcSourceStrCopy,Delimiter,1,Field_Position);
    return substr(vcSourceStrCopy,iPtrStart,(iPtrEnd-iPtrStart));
  end GetString; /* String Version */
```

#### SP-034 - WEBUTIL.GETVAR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.GETVAR retrieves the value of a named configuration or environment variable from the client machine. The resolution strategy is platform-dependent: on Windows clients the procedure first queries the Oracle registry key (HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE) and falls back to the Windows environment string if the registry lookup returns no value; on Unix/Linux clients it executes the 'env' command, captures its standard output, and parses the output to locate the matching variable; on macOS and unknown platforms the procedure takes no action and returns the value unchanged. The procedure is invoked during bean registration (WEBUTIL.REGISTERBEAN) to obtain client-side runtime configuration values.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VARNAME | VARCHAR2 | IN |
| VARVALUE | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VARVALUE | VARCHAR2 | IN OUT |

---

**Dependencies**

- GET_ENVIRONMENT_STRING ([SP-062](#SP-062--GET_ENVIRONMENT_STRING)) - matched by member name
- READ_REGISTRY ([SP-063](#SP-063--READ_REGISTRY)) - matched by member name
- WEBUTIL.BLOCKING ([SP-012](#SP-012--WEBUTIL.BLOCKING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTOSFAMILY ([SP-024](#SP-024--WEBUTIL.GETCLIENTOSFAMILY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_STANDARD_OUTPUT ([SP-036](#SP-036--WEBUTIL.GET_STANDARD_OUTPUT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.RELEASE_PROCESS ([SP-050](#SP-050--WEBUTIL.RELEASE_PROCESS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the variable name (VARNAME) and the current value holder (VARVALUE) as input.
- Step 2 - Determine the client operating system family by calling WEBUTIL.GETCLIENTOSFAMILY.
- Step 3 - If the client OS is Windows (CLIENT_PLATFORM_WIN32): attempt to read the variable value from the Oracle registry path HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE using READ_REGISTRY, passing VARNAME as the value key.
- Step 4 - (Windows only) If the registry lookup returns NULL or an empty string, fall back to retrieving the value via GET_ENVIRONMENT_STRING, passing VARNAME.
- Step 5 - If the client OS is macOS (CLIENT_PLATFORM_MAC) or unrecognised (CLIENT_PLATFORM_UNKNOWN): perform no action; VARVALUE remains unchanged.
- Step 6 - If the client OS is any other platform (Unix/Linux): invoke WEBUTIL.BLOCKING with the command 'env' to execute the environment listing synchronously and obtain a process handle.
- Step 7 - (Unix only) Retrieve the full standard output of the 'env' process as an array of strings using WEBUTIL.GET_STANDARD_OUTPUT.
- Step 8 - (Unix only) Release the process handle by calling WEBUTIL.RELEASE_PROCESS.
- Step 9 - (Unix only) Iterate over each output line; for each line locate the '=' delimiter, extract the key portion (left of '='), and compare it to VARNAME. When a match is found, assign the value portion (right of '=') to VARVALUE and exit the loop.
- Step 10 - If a NO_DATA_FOUND exception is raised at any point, set VARVALUE to NULL and return.

---
**Decision Points**

DP-001

Condition: Client OS family equals CLIENT_PLATFORM_WIN32.

TRUE: Attempt registry lookup via READ_REGISTRY under HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE; if that returns NULL or empty, fall back to GET_ENVIRONMENT_STRING.

FALSE: Proceed to DP-002.

---

DP-002

Condition: Client OS family is CLIENT_PLATFORM_MAC or CLIENT_PLATFORM_UNKNOWN.

TRUE: Take no action; VARVALUE is left unchanged.

FALSE: Treat the client as a Unix/Linux platform and proceed to execute the 'env' command.

---

DP-003

Condition: (Windows path) The value returned by READ_REGISTRY is NULL or an empty string.

TRUE: Call GET_ENVIRONMENT_STRING to retrieve the variable value from the Windows environment.

FALSE: Use the registry value already retrieved as VARVALUE.

---

DP-004

Condition: (Unix path) A line from the 'env' output contains a '=' character (iPos > 0) and the extracted key matches VARNAME.

TRUE: Assign the substring after '=' to VARVALUE and exit the iteration loop.

FALSE: Continue iterating to the next output line.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - On a Windows client, the Oracle registry path HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE is always the primary source for variable resolution; the Windows environment is only consulted as a secondary fallback.
- BR-002 - On macOS and unrecognised client platforms, no variable resolution is attempted; the procedure returns without modifying VARVALUE.
- BR-003 - On Unix/Linux clients, variable resolution is performed exclusively by parsing the output of the 'env' shell command; direct environment API calls are not used.
- BR-004 - The 'env' process on Unix must be executed in blocking mode (WEBUTIL.BLOCKING) to ensure output is fully available before parsing begins, and the process handle must be released via WEBUTIL.RELEASE_PROCESS after output retrieval.
- BR-005 - Each line of the Unix 'env' output is parsed by locating the first '=' character; only lines containing '=' are evaluated as candidate key-value pairs.
- BR-006 - If a NO_DATA_FOUND exception is raised during any resolution path, VARVALUE is set to NULL, ensuring the caller receives a defined, non-error result.

---
**Implementation Logic**

```plsql

  PROCEDURE GETVAR(VARNAME IN VARCHAR2, VARVALUE IN OUT VARCHAR2) is
    unixOutput WebUtil_HOST.OUTPUT_ARRAY;
    hostHandle WebUtil_HOST.PROCESS_ID;
    varKey     VARCHAR2(100);
    iPos       PLS_INTEGER;
  BEGIN
    if WebUtil_Core.GetClientOSFamily = WebUtil_Core.CLIENT_PLATFORM_WIN32 then 
      -- read the client Registry
      VARVALUE := Client_Win_API_Environment.read_registry('HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE',VARNAME,false);
      if VARVALUE is null OR VARVALUE = '' then
        -- Could not get an Oracle variable in registry. Try to get from environment varialble
        -- java desupported System.getenv method until they supported it again in 1.5.
        -- We can still get the environment variables in windows using
        -- CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING
        VARVALUE := CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING(VARNAME);
      end if;
    elsif WebUtil_Core.GetClientOSFamily in (WebUtil_Core.CLIENT_PLATFORM_MAC,WebUtil_Core.CLIENT_PLATFORM_UNKNOWN) then 
      -- do nothing 
      null;
    else
      -- Unix Ports - do a env to get the environment and parse that
      hostHandle := WebUtil_HOST.Blocking('env');
      unixOutput := WebUtil_HOST.Get_Standard_Output(hostHandle);
      WebUtil_HOST.Release_Process(hostHandle);
      for i in 1..unixOutput.count LOOP
        iPos := instr(unixOutput(i),'=');
        if iPos > 0 then 
          varKey := substr(unixOutput(i),1,iPos-1);
          if varKey = VARNAME then 
            VARVALUE := substr(unixOutput(i),iPos+1);
            EXIT;
          end if;
        end if;
      end LOOP;
    end if;

  exception
    when NO_DATA_FOUND then
      VARVALUE := null;
  END GETVAR;

END CLIENT_TOOL_ENV;

PACKAGE Client_Win_API IS
/*-------------------------------------------------------------------------------*\
 * WebUtil version of D2KWUTIL package WIN_API                                     
 * Note: Not all D2kWutil Functions are ported
 *********************************************************************************
 * Version 1.0.0
 *********************************************************************************
 * Change History
 *   DRMILLS 21/FEB/2003 - Port Creation
 *
 *********************************************************************************
 * WIN_API ->  This package defines the constants used throughout 
 *      the library as a whole, including versions of those 
 *      constants defined within WINDOWS.H/WINUSER.H that 
 *      we'll be using. Add more constants in here if required
 *      The package also contains Explicit Exception declarations,
 *      various status Flags and functions for Error Handling
 * NOTE:    In order to make this library portable across Forms
 *      and Reports we do not use any application 
 *      specific built-ins such as the Forms MESSAGE() 
 *      Built-in. Instead errors are recorded in a package
 *      variable which the programmer can examine if required
\*-------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------*\
 * Internal Version Number  ** Oracle Developer Release 6.0 Version
\*-------------------------------------------------------------------------------*/
  WIN_API_VERSION  CONSTANT  VARCHAR2(30) := '6.0.6.0 Production';
  DLL_NAME         CONSTANT  VARCHAR2(12) := 'd2kwut60.dll';
  DLL_PATH         VARCHAR2(256)          := NULL;

/*-------------------------------------------------------------------------------*\
 * General Window Classes of Common Applications for use with WIN_API_SESSION
 * ** WARNING ** These Window classes are out of our control and might change 
 *               when you upgrade the software in question,
\*-------------------------------------------------------------------------------*/

  -- Oracle Apps
  WINCLASS_DEVELOPER_2000_V1  CONSTANT  VARCHAR2(15)  := 'ui23MDIroot_W32';             /* Developer/2000 release 1.n / Toolkit 2.3 Apps on 32 bit */
  WINCLASS_DEVELOPER_2000_V2  CONSTANT  VARCHAR2(15)  := 'ui25MDIroot_W32';             /* Developer/2000 Release 2.0 / Toolkit 2.5 Apps on 32 bit */
  WINCLASS_DEVELOPER_2000_V6  CONSTANT  VARCHAR2(15)  := 'ui60MDIroot_W32';             /* Developer/2000 Release 6.0 / Toolkit 6.0 Apps on 32 bit */  
  D2K_WINDOW_CLASS            CONSTANT  VARCHAR2(15)  := WINCLASS_DEVELOPER_2000_V6;    /* Set to the "current" version */  
  WINCLASS_INTEROFFICE_40     CONSTANT  VARCHAR2(28)  := 'Afx:10000000:b:10008:6:5023b';/* Oracle Interoffice 4.0 Client 32 bit */
  WINCLASS_INTEROFFICE_41     CONSTANT  VARCHAR2(28)  := 'Afx:10000000:b:1496:6:3a17';  /* Oracle Interoffice 4.0 Client 32 bit */
  WINCLASS_SQLPLUS            CONSTANT  VARCHAR2(13)  := 'SqlplusWClass';               /* Sql*Plus 32 bit */
  WINCLASS_REPORTSSERVER_V1   CONSTANT  VARCHAR2(15)  := 'R25SRV_WINCLASS';             /* Reports Server Reports 2.5 */
  WINCLASS_REPORTSSERVER_V2   CONSTANT  VARCHAR2(15)  := 'R30SRV_WINCLASS';             /* Reports Server Reports 3.0 */
  WINCLASS_REPORTSSERVER_V6   CONSTANT  VARCHAR2(14)  := 'RWRBE_WINCLASS';              /* Reports Server Reports 6.0 */

  -- Microsoft Office Apps - Office97
  WINCLASS_MSWORD_97         CONSTANT  VARCHAR2(7) := 'OpusApp';                        /* Microsoft Word 97 */
  WINCLASS_MSEXCEL_97        CONSTANT  VARCHAR2(6) := 'XLMAIN';                         /* Microsoft Excel 97 */
  WINCLASS_MSPOWERPOINT_97   CONSTANT  VARCHAR2(14):= 'PP97FrameClass';                 /* Microsoft Power Point 97 */

  -- Microsoft Office Apps - Office95
  WINCLASS_MSWORD_7          CONSTANT  VARCHAR2(7) := 'OpusApp';                        /* Microsoft Word 7 */
  WINCLASS_MSEXCEL_7         CONSTANT  VARCHAR2(6) := 'XLMAIN';                         /* Microsoft Excel 7 */
  WINCLASS_MSPOWERPOINT_7    CONSTANT  VARCHAR2(13):= 'PP7FrameClass';                  /* Microsoft Power Point 7 */
  WINCLASS_MSSCHEDULE_7      CONSTANT  VARCHAR2(23):= 'MS Schedule+ 32 Panesdi';        /* Microsoft Schedule 7 */
  WINCLASS_MSEXCHANGE_4      CONSTANT  VARCHAR2(29):= 'Microsoft Exchange 4.0 Viewer';  /* Microsoft Exchange 4 in-tray */

  -- Microsoft O/S Utilities
  WINCLASS_INETEXPLORER      CONSTANT  VARCHAR2(7):= 'IEFrame';                         /* Internet Explorer */
  WINCLASS_OUTLOOK_EXPRESS   CONSTANT  VARCHAR2(29):= 'Outlook Express Browser Class';  /* Outlook Express */
  WINCLASS_EXPLORER          CONSTANT  VARCHAR2(13):= 'ExploreWClass';                  /* Explorer */
  WINCLASS_MYCOMPUTER        CONSTANT  VARCHAR2(13):= 'CabinetWClass';                  /* My Computer & Network Neighborhood*/
  WINCLASS_CALCULATOR        CONSTANT  VARCHAR2(7) := 'SciCalc';                        /* Windows Calculator */
  WINCLASS_NOTEPAD           CONSTANT  VARCHAR2(7) := 'Notepad';                        /* Windows Notepad */
  WINCLASS_WORDPAD           CONSTANT  VARCHAR2(12):= 'WordPadClass';                   /* Windows Wordpad/Write */
  WINCLASS_DOS               CONSTANT  VARCHAR2(18):= 'ConsoleWindowClass';             /* Dos Window */

  -- Other
  WINCLASS_NETSCAPE_3        CONSTANT  VARCHAR2(27):= 'Afx:40000000:b:150e:6:38cfe';    /* Netscape Navigator 3.0 */
  WINCLASS_NETSCAPE_4        CONSTANT  VARCHAR2(28):= 'Afx:40000000:b:10008:6:6063e';   /* Netscape Communicator 4.0 */
  WINCLASS_PFE_7             CONSTANT  VARCHAR2(11):= 'PFE32_Frame';                    /* Programmers File Editor */
  WINCLASS_REGEDIT           CONSTANT  VARCHAR2(15):= 'RegEdit_RegEdit';                /* Registry Editor */

  -- Window Style Constants (from WINUSER.H)
  --  Any PU's that use these constants will explain 
  --  their use.  For further information consult the
  --  Windows SDK.

  SW_HIDE              CONSTANT  PLS_INTEGER := 0;
  SW_SHOWNORMAL        CONSTANT  PLS_INTEGER := 1;
  SW_SHOWMINIMIZED     CONSTANT  PLS_INTEGER := 2;
  SW_SHOWMAXIMIZED     CONSTANT  PLS_INTEGER := 3;
  SW_SHOWNOACTIVATE    CONSTANT  PLS_INTEGER := 4;
  SW_SHOW              CONSTANT  PLS_INTEGER := 5;
  SW_MINIMIZE          CONSTANT  PLS_INTEGER := 6;
  SW_SHOWMINNOACTIVE   CONSTANT  PLS_INTEGER := 7;
  SW_SHOWNA            CONSTANT  PLS_INTEGER := 8;
  SW_RESTORE           CONSTANT  PLS_INTEGER := 9;
  SW_SHOWDEFAULT       CONSTANT  PLS_INTEGER := 10;

  -- Help Access Constants (From WINUSER.H)
  --  See WIN_API_SHELL.WinHelp

  HELP_CONTEXT         CONSTANT  PLS_INTEGER := 1;   /* 0x0001L */
  HELP_QUIT            CONSTANT  PLS_INTEGER := 2;   /* 0x0002L */
  HELP_INDEX           CONSTANT  PLS_INTEGER := 3;   /* 0x0003L */
  HELP_CONTENTS        CONSTANT  PLS_INTEGER := 3;   /* 0x0003L */
  HELP_HELPONHELP      CONSTANT  PLS_INTEGER := 4;   /* 0x0004L */
  HELP_SETINDEX        CONSTANT  PLS_INTEGER := 5;   /* 0x0005L */
  HELP_SETCONTENTS     CONSTANT  PLS_INTEGER := 5;   /* 0x0005L */
  HELP_CONTEXTPOPUP    CONSTANT  PLS_INTEGER := 8;   /* 0x0008L */
  HELP_FORCEFILE       CONSTANT  PLS_INTEGER := 9;   /* 0x0009L */
  HELP_KEY             CONSTANT  PLS_INTEGER := 257; /* 0x0101L */
  HELP_COMMAND         CONSTANT  PLS_INTEGER := 258; /* 0x0102L */
  HELP_PARTIALKEY      CONSTANT  PLS_INTEGER := 261; /* 0x0105L */
  HELP_MULTIKEY        CONSTANT  PLS_INTEGER := 513; /* 0x0201L */
  HELP_SETWINPOS       CONSTANT  PLS_INTEGER := 515; /* 0x0203L */
  -- Windows 4+
  HELP_CONTEXTMENU     CONSTANT  PLS_INTEGER := 10;  /* 0x000a  */
  HELP_FINDER          CONSTANT  PLS_INTEGER := 11;  /* 0x000b  */
  HELP_WM_HELP         CONSTANT  PLS_INTEGER := 12;  /* 0x000c  */
  HELP_SETPOPUP_POS    CONSTANT  PLS_INTEGER := 13;  /* 0x000d  */

  -- Windows Messages for use with SendMessage
  -- DO NOT utilise the Windows Sendmessage interface without being conversant
  -- with the Windows message handling mechanism
  -- Refer to the Microsoft Windows SDK for Messages and Parameter values
  WM_SYSCOMMAND        CONSTANT  PLS_INTEGER := 274;   /* 0x0112 */
  WM_MDITILE           CONSTANT  PLS_INTEGER := 550;   /* 0x0226 */
  WM_MDICASCADE        CONSTANT  PLS_INTEGER := 551;   /* 0x0227 */
  WM_MDIICONARRANGE    CONSTANT  PLS_INTEGER := 552;   /* 0x0228 */      
  SC_RESTORE           CONSTANT  PLS_INTEGER := 61728; /* 0xF120 */
  SC_MINIMIZE          CONSTANT  PLS_INTEGER := 61472; /* 0xF020 */
  SC_MAXIMIZE          CONSTANT  PLS_INTEGER := 61488; /* 0xF030 */
  

  -- Flags for use with File Dialog boxes ("Save As" or "Open")
  -- Refer to your Microsoft documentation for details on the 
  -- Exact usage and dependancies of each option
  OFN_READONLY           CONSTANT  PLS_INTEGER := 1;        /* 0x00000001 */
  OFN_OVERWRITEPROMPT    CONSTANT  PLS_INTEGER := 2;        /* 0x00000002 */
  OFN_HIDEREADONLY       CONSTANT  PLS_INTEGER := 4;        /* 0x00000004 */
  OFN_NOCHANGEDIR        CONSTANT  PLS_INTEGER := 8;        /* 0x00000008 */
  OFN_SHOWHELP           CONSTANT  PLS_INTEGER := 16;       /* 0x00000010 */
  OFN_NOVALIDATE         CONSTANT  PLS_INTEGER := 256;      /* 0x00000100 */
  OFN_ALLOWMULTISELECT   CONSTANT  PLS_INTEGER := 512;      /* 0x00000200 */
  OFN_EXTENSIONDIFFERENT CONSTANT  PLS_INTEGER := 1024;     /* 0x00000400 */
  OFN_PATHMUSTEXIST      CONSTANT  PLS_INTEGER := 2048;     /* 0x00000800 */
  OFN_FILEMUSTEXIST      CONSTANT  PLS_INTEGER := 4096;     /* 0x00001000 */
  OFN_CREATEPROMPT       CONSTANT  PLS_INTEGER := 8192;     /* 0x00002000 */
  OFN_SHAREAWARE         CONSTANT  PLS_INTEGER := 16384;    /* 0x00004000 */
  OFN_NOREADONLYRETURN   CONSTANT  PLS_INTEGER := 32768;    /* 0x00008000 */
  OFN_NOTESTFILECREATE   CONSTANT  PLS_INTEGER := 65536;    /* 0x00010000 */
  OFN_NONETWORKBUTTON    CONSTANT  PLS_INTEGER := 131072;   /* 0x00020000 */
  OFN_NOLONGNAMES        CONSTANT  PLS_INTEGER := 262144;   /* 0x00040000 */
  OFN_EXPLORER           CONSTANT  PLS_INTEGER := 524288;   /* 0x00080000 */
  OFN_NODEREFERENCELINKS CONSTANT  PLS_INTEGER := 1048576;  /* 0x00100000 */
  OFN_LONGNAMES          CONSTANT  PLS_INTEGER := 2097152;  /* 0x00200000 */

  -- The defaults used here (WIN_API.OFN_PATHMUSTEXIST|WIN_API.OFN_FILEMUSTEXIST|WIN_API.OFN_HIDEREADONLY|WIN_API.OFN_NOCHANGEDIR|WIN_API.OFN_EXPLORER)
  OFN_FLAG_DEFAULT       CONSTANT  PLS_INTEGER :=  530444;
  
  
  -- Registry Data types for Write_RegistryEx
  REG_EXPAND_SZ          CONSTANT  PLS_INTEGER := 0;
  REG_SZ                 CONSTANT  PLS_INTEGER := 1;
  REG_DWORD              CONSTANT  PLS_INTEGER := 2;
  
  -- Compatibility Flags - Used where I have changed behaviour and you might not like the new version
  -- Change these at runtime to FALSE to revert to "old" behaviour
  COMPAT_EXPAND_REG_VALUES    BOOLEAN := TRUE;

  
  
  -- Types
  TYPE aFunctionHandle is table of WEBUTIL_C_API.FUNCTIONHANDLE index by BINARY_INTEGER;  
  SUBTYPE FILE_TYPE is PLS_INTEGER;

  -- Public Variables
  ERROR_ENCOUNTERED  BOOLEAN := FALSE;  /* The Last Call resulted in an error */
  ERROR_STACK        VARCHAR2(2000);    /* Holds Text of Last error(s) */ 
  API_ENABLED        BOOLEAN := FALSE;   /* Are API functions usable ?*/
  DLL_HANDLE         ORA_FFI.LibHandleType;
  FunctionHandle     aFunctionHandle;
   

  -- Public Exceptions
  NOT_AVAILABLE      EXCEPTION;  /* A call to the API was made but API functions not currently available (e.g. not on Windows) */
     
  -- Error Constants
  UError             CONSTANT  VARCHAR2(30) := ' Caused an unexpected error: ';
  NoAPI              CONSTANT  VARCHAR2(31) := 'API Functions are not Available';
  MaxDWord           CONSTANT  VARCHAR2(33) := 'Integer Argument exceeds 32 bits ';
  MaxWord            CONSTANT  VARCHAR2(33) := 'Integer Argument exceeds 16 bits ';
  MaxByte            CONSTANT  VARCHAR2(32) := 'Integer Argument exceeds 8 bits ';
  MinBound           CONSTANT  VARCHAR2(27) := 'Integer Argument too Small ';
  MaxBound           CONSTANT  VARCHAR2(27) := 'Integer Argument too Large ';
  NullArg            CONSTANT  VARCHAR2(24) := 'Argument cannot be NULL ';

  /*----------------------------------------------------------------------------*\
  * PreLoad ->  Loads the d2kwut60.dll from the jvm bin directory into memory
  \*----------------------------------------------------------------------------*/
```

#### SP-035 - WEBUTIL.GET_LINE

**Invoked From:**

- vr_bshop_tech_prod_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Reads the next line of text from an open client-side file by interacting with the WebUtil core bean. Passes the file handle to the bean, retrieves the resulting text, and returns it in the output parameter. Raises NO_DATA_FOUND when end-of-file is reached (signalled by the bean returning a newline character). Raises a tool error if the bean is not registered or a property error occurs.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| item | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the open file handle as input.
- Step 2 - Pass the file handle to the WebUtil core bean by setting the WUF_TEXTIO_HANDLE property on the WUF_PACKAGE bean.
- Step 3 - Retrieve the next line of text from the bean by reading the WUF_TEXTIO_GETLINE property, storing the result in a local buffer.
- Step 4 - Check whether the buffer contains a single newline character (CHR(10)), which is the bean's convention for signalling end-of-file.
- Step 5 - If the buffer equals CHR(10), raise NO_DATA_FOUND to indicate end-of-file to the caller.
- Step 6 - If the buffer does not equal CHR(10), assign the buffer content to the output parameter and return it to the caller.
- Step 7 - If a BEAN_NOT_REGISTERED exception occurs, display an error alert identifying the missing bean class and raise TOOL_ERR.TOOL_ERROR. If a PROPERTY_ERROR exception occurs, raise TOOL_ERR.TOOL_ERROR.

---
**Decision Points**

DP-001

Condition:
The text returned by the WebUtil core bean equals CHR(10) (a single newline character, indicating end-of-file)

TRUE:
Raise NO_DATA_FOUND to signal end-of-file to the caller

FALSE:
Assign the returned buffer to the output parameter and return it

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - End-of-file is signalled to the caller by raising NO_DATA_FOUND; a single newline character (CHR(10)) returned by the WebUtil core bean is the agreed end-of-file indicator and is never returned as line content.
- BR-002 - The file handle must be set on the WUF_PACKAGE bean before the line can be retrieved; the procedure relies entirely on WebUtil_Core property get/set operations and has no direct database interactions.
- BR-003 - If the WebUtil core bean is not registered on the client, an error alert identifying the missing bean class is displayed and a tool error is raised, preventing further execution.
- BR-004 - If a property error occurs during the bean interaction, a tool error is raised immediately with no additional alert.

---
**Implementation Logic**

```plsql
  PROCEDURE get_line (file file_type, item OUT VARCHAR2) is
    buffer VARCHAR2(4000 char);
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);        
    buffer := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_GETLINE');
    -- We can't easily tell the difference between an empty line and a line beyond then 
    -- end of the file so to get around this, the exception handling code in the PJC 
    -- places a newline into the buffer when the end of file is passed.
    -- The rational being that get_line would never normally return a newline because 
    -- it normally uses that to tell it where to read up *to*.
    if buffer = chr(10) then 
      raise NO_DATA_FOUND;
    else
      item := buffer;
    end if;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.get_line will not work');
      RAISE TOOL_ERR.TOOL_ERROR;                                                                 
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE TOOL_ERR.TOOL_ERROR;  
  END get_line;
  
  /**
   * File writing functions
   */
```

#### SP-036 - WEBUTIL.GET_STANDARD_OUTPUT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the standard output stream for a given host process by delegating to the WEBUTIL.GETOUTPUT function with the fixed stream identifier 'WUH_STDOUT'. This allows callers to obtain all standard output lines produced by a previously executed host process without needing to know the internal stream key.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETOUTPUT ([SP-031](#SP-031--WEBUTIL.GETOUTPUT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the target host process identifier (PROCESS_ID) as input.
- Step 2 - Invoke WEBUTIL.GETOUTPUT (SP-031), passing the supplied process identifier and the fixed stream constant 'WUH_STDOUT' to retrieve all standard output lines associated with that process.
- Step 3 - Return the OUTPUT_ARRAY result produced by WEBUTIL.GETOUTPUT directly to the caller.

---
**Decision Points**

None. The function contains no conditional branching; it unconditionally delegates to WEBUTIL.GETOUTPUT with the fixed stream identifier 'WUH_STDOUT' and returns the result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The stream identifier used to retrieve output is always 'WUH_STDOUT'; callers cannot override or substitute a different stream key through this function.
- BR-002 - The function returns an OUTPUT_ARRAY; the caller is responsible for handling an empty or null array if the specified process produced no standard output.
- BR-003 - A valid PROCESS_ID must be supplied; the function performs no independent validation of the process identifier and relies on WEBUTIL.GETOUTPUT (SP-031) to handle any process-level resolution.

---
**Implementation Logic**

```plsql
    
  FUNCTION Get_Standard_Output(process in PROCESS_ID) return OUTPUT_ARRAY is  
  begin 
    return GetOutput(process,'WUH_STDOUT');
  end Get_Standard_Output;
```

#### SP-037 - WEBUTIL.ID_NULL

**Invoked From:**

- vr_bshop_tech_prod_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]
- webutil.pld [StoredProcedure: WEBUTIL.ERRORALERT]
- webutil.pld [StoredProcedure: WEBUTIL.INITWEBUTIL]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTER_FUNCTION]
- webutil.pld [StoredProcedure: WEBUTIL.SHOWBEANS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Checks whether a handle (pointer) is null. Returns TRUE if the handle's internal pointer field is null, and FALSE otherwise. Used by VIEW_EXCEL_REP to determine whether an existing record group handle must be deleted before creating a new one, and by WEBUTIL.ERRORALERT to verify that the error alert object handle is valid before attempting to display it.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| handle | Pointer | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the handle (pointer) as input.
- Step 2 - Check whether the handle's internal pointer field (hnd) is null.
- Step 3 - Return TRUE if the pointer is null (handle is invalid/unset); return FALSE if the pointer is not null (handle is valid).

---
**Decision Points**

DP-001

Condition:
The handle's internal pointer field (hnd) is null

TRUE:
Return TRUE (handle is null/invalid)

FALSE:
Return FALSE (handle is not null/valid)

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A handle is considered null if its internal pointer field is null; this check is used before performing operations on record groups and error alert objects to avoid invalid-handle errors.

---
**Implementation Logic**

```plsql

  FUNCTION ID_NULL(handle IN Pointer)        RETURN BOOLEAN is
  BEGIN
    if handle.hnd is null then 
      return TRUE;
    else
      return FALSE;
    end if;
  END ID_NULL;
```

#### SP-038 - WEBUTIL.INIT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETOUTPUT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.INIT serves as the package-level entry point for the WebUtil core utility. Although the procedure body performs no explicit processing steps (it executes a null statement), its invocation causes the PL/SQL package to be instantiated in the session, which in turn triggers the package initialisation block. That block calls WEBUTIL.INITWEBUTIL (SP-039) to perform the actual WebUtil setup. The procedure is invoked by WEBUTIL.GETOUTPUT as a lightweight initialisation gate.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.INITWEBUTIL ([SP-039](#SP-039--WEBUTIL.INITWEBUTIL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - WEBUTIL.GETOUTPUT calls WEBUTIL.INIT to ensure the WebUtil package is initialised for the current session.
- Step 2 - The INIT procedure body executes a null statement; no explicit processing is performed within the procedure itself.
- Step 3 - Because invoking any procedure in the package causes the package to be loaded into session memory, the package-level initialisation block is triggered automatically by the PL/SQL runtime.
- Step 4 - The package initialisation block calls WEBUTIL.INITWEBUTIL (SP-039), which carries out the substantive WebUtil setup logic.
- Step 5 - Control returns to the caller (WEBUTIL.GETOUTPUT) with the WebUtil package fully initialised.

---
**Decision Points**

No decision points exist within WEBUTIL.INIT. The procedure body contains only a null statement and delegates all conditional logic to WEBUTIL.INITWEBUTIL (SP-039) via the package initialisation block.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Entering (instantiating) the WEBUTIL package in a session is sufficient to trigger initialisation; no explicit procedural steps inside INIT are required, and the procedure body must therefore remain a no-op (null statement).
- BR-002 - The actual WebUtil initialisation must be performed by WEBUTIL.INITWEBUTIL (SP-039), which is called exclusively through the package initialisation block and not directly from within the INIT procedure body.
- BR-003 - WEBUTIL.INIT accepts no input parameters and produces no output parameters; its sole contract is to act as a callable entry point that guarantees package instantiation.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Init is
  begin 
    -- we don't need to do anything here - entering the package is enough to set it up.      
    null;
  end;      

BEGIN
  -- Initialise the Utility
  InitWebUtil;  
END WEBUTIL_CORE;

PACKAGE WEBUTIL_C_API IS
/*********************************************************************************\
 * WEBUTIL_C_API
 *   This Package provides a way of calling C functions in a shared library on the
 *   client PC. Currently only win32 is supported.
 *   The oracle.forms.webutil.cApi.CApiFunctions bean is needed in your Form to 
 *   use these functions
 *********************************************************************************
 * Version 1.0.5
 *********************************************************************************
 * Change History
 *   1.0.1 RVSUILIC 14/FEB/2003 - Creation 
 *   1.0.2 DRMILLS  27/FEB/2003 - Reset LONG to the same value as INT which is fine
 *                                for Windows & removed Tester proc
 *   1.0.3 DRMILLS  01/MAR/2003 - Re-worked the PL/SQL API
 *   1.0.4 DRMILLS  13/MAY/2003 - Added call to WebUtil_Core.Init
 *   1.0.5 RVSUILIC 21/MAY/2003 - Cleaned up some comments and formatting.
 *
\*********************************************************************************/

  /**
   *  Constants to represent PL/SQL IN, OUT and INOUT parameter qualifiers
   */
  PARAM_IN    CONSTANT PLS_INTEGER := 50;
  PARAM_INOUT CONSTANT PLS_INTEGER := 51;
  PARAM_OUT   CONSTANT PLS_INTEGER := 52;
  

  /**
   *  Constants to represent C atomic datatypes and pointers to atomic datatypes
   *  Note that to use OUT and INOUT qualifiers the C function in the DLL *must*
   *  use a pointer type to be able to pass information back.
   *
   *  The comments on the right indicate which types can be used for parameters
   *  and which for function return types.
   *
   *  c_ptr is used as a generic pointer. The onlys supported use for this is to
   *  save the pointer value from C into a PL/SQL variable, so that it may be 
   *  passed back later to C. No operations on the pointer are supported in PL/SQL.
   */
  c_void          CONSTANT PLS_INTEGER := 30;            /* - not used -   */
  c_char          CONSTANT PLS_INTEGER := 31;            /* param & return */
  c_short         CONSTANT PLS_INTEGER := 32;            /* param & return */
  c_int           CONSTANT PLS_INTEGER := 33;            /* param & return */
  c_long          CONSTANT PLS_INTEGER := 33;            /* param & return *//*DRM - same as INT */
  c_float         CONSTANT PLS_INTEGER := 35;            /* param & return */
  c_double        CONSTANT PLS_INTEGER := 36;            /* param & return */

  c_ptr           CONSTANT PLS_INTEGER := 64 + c_void;   /* param & return */
  c_char_ptr      CONSTANT PLS_INTEGER := 64 + c_char;   /* param          */
  c_short_ptr     CONSTANT PLS_INTEGER := 64 + c_short;  /* param          */
  c_int_ptr       CONSTANT PLS_INTEGER := 64 + c_int;    /* param          */
  c_long_ptr      CONSTANT PLS_INTEGER := 64 + c_long;   /* param          */
  c_float_ptr     CONSTANT PLS_INTEGER := 64 + c_float;  /* param          */
  c_double_ptr    CONSTANT PLS_INTEGER := 64 + c_double; /* param          */

  /**
   *  Abstracted types to be used for pointers and handles. The forms programmer
   *  should not attempt any manipulation on these types, but merely obtain them as
   *  a result of functions below, and pass them back in to other functions below.
   */
    SUBTYPE handleType   IS NUMBER;
    TYPE Pointer         IS RECORD (hnd handleType);   /* C pointer             */
    TYPE FunctionHandle  IS RECORD (hnd handleType);   /* function handle       */
    TYPE ParameterHandle IS RECORD (hnd handleType);   /* parameter handle      */
    TYPE ParameterList   IS RECORD (hnd handleType);   /* parameter list handle */

  /**
   *  IS_SUPPORTED - Check if the client is on a supported hardware platform.
   */
```

#### SP-039 - WEBUTIL.INITWEBUTIL

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.INIT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Initialises the WebUtil runtime environment when the parent WEBUTIL.INIT procedure is invoked. The procedure registers the Java implementation class names for each WebUtil functional package, verifies that the mandatory WebUtil object group (including its error alert and bean areas) is present in the calling form, optionally navigates to and renders the WebUtil bean items, and determines the server-side file-path separator character based on the host operating system.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-037](#SP-037--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SHOWBEANS ([SP-054](#SP-054--WEBUTIL.SHOWBEANS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Capture the current cursor field (SYSTEM.CURSOR_FIELD) and locate the WebUtil dummy item (WEBUTIL_DUMMY_ITEM) to support later navigation logic.
- Step 2 - Populate the m_implClasses associative array by mapping each WebUtil package constant (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL) to its corresponding Java implementation class name string.
- Step 3 - Call WEBUTIL.ID_NULL against m_errorAlert to determine whether the WebUtil error alert object is present in the current form.
- Step 4 - If the error alert is absent, display a message informing the user that the WEBUTIL object group is not available and that WebUtil cannot operate, then pause execution; no further initialisation is performed.
- Step 5 - If the error alert is present and the FLAG_EXPICIT_INSTANCIATE flag is enabled and the form is in NORMAL mode, proceed with explicit bean instantiation.
- Step 6 - Within the explicit instantiation branch, call WEBUTIL.ID_NULL against hDummy to confirm the standard WebUtil object group dummy item exists.
- Step 7 - If the dummy item exists, navigate to it via GO_ITEM(hDummy), then determine whether the original cursor field resides in the same block as the dummy item; if so, move to the next block, otherwise return navigation to the original cursor field.
- Step 8 - Call WEBUTIL.SHOWBEANS(false) to render the bean areas without displaying them visibly, completing the explicit instantiation.
- Step 9 - If the dummy item does not exist, take no action, deferring bean area setup to the calling programmer.
- Step 10 - After the object-group checks, inspect the server operating system via GET_APPLICATION_PROPERTY(OPERATING_SYSTEM); if the OS name contains 'WIN', set the package-level server file separator (m_serverFileSep) to backslash, otherwise set it to forward slash.

---
**Decision Points**

DP-001

Condition: WEBUTIL.ID_NULL(m_errorAlert) returns TRUE - the WebUtil error alert object is not present in the current form.

TRUE: Display an error message stating the WEBUTIL object group is unavailable and WebUtil cannot work, then pause. No further initialisation steps are executed.

FALSE: Continue with bean instantiation and server OS detection.

---

DP-002

Condition: FLAG_EXPICIT_INSTANCIATE is TRUE AND SYSTEM.MODE equals 'NORMAL'.

TRUE: Proceed with explicit navigation to the dummy item and bean rendering.

FALSE: Skip explicit bean instantiation entirely; proceed directly to server OS detection.

---

DP-003

Condition: WEBUTIL.ID_NULL(hDummy) returns FALSE - the standard WebUtil dummy item is found in the form.

TRUE: Navigate to the dummy item, resolve block context, and call WEBUTIL.SHOWBEANS(false) to render bean areas.

FALSE: Take no action; the programmer is assumed to manage bean area setup independently.

---

DP-004

Condition: The block of the original cursor field (startPoint) is the same block as the dummy item's block.

TRUE: Execute NEXT_BLOCK to move focus away from the dummy item's block.

FALSE: Return focus to the original cursor field via GO_ITEM(startPoint).

---

DP-005

Condition: The server operating system name (from GET_APPLICATION_PROPERTY(OPERATING_SYSTEM)) contains the string 'WIN' (case-insensitive).

TRUE: Set m_serverFileSep to backslash ('\') for Windows-style file paths.

FALSE: Set m_serverFileSep to forward slash ('/') for Unix/Linux-style file paths.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The WEBUTIL object group, including its error alert, must be present in the calling form before any WebUtil functionality can be used; absence of the error alert object is treated as a fatal configuration error and halts initialisation.
- BR-002 - Explicit bean instantiation via navigation is performed only when the form is in NORMAL mode; Enter-Query mode is explicitly excluded to avoid navigation conflicts (per Bug 2955789 resolution).
- BR-003 - Explicit bean instantiation is further gated by the FLAG_EXPICIT_INSTANCIATE package-level flag, allowing the behaviour to be enabled or disabled as a configurable workaround.
- BR-004 - When navigating to the dummy item, the procedure must restore the user's original cursor position: if the dummy item shares the same block as the original cursor field, focus moves to the next block; otherwise focus returns directly to the original cursor field.
- BR-005 - WEBUTIL.SHOWBEANS must be called with the parameter false during initialisation, rendering bean areas without making them visible.
- BR-006 - If the dummy item is not found, no automatic bean area setup is performed; responsibility for bean area configuration rests entirely with the calling developer.
- BR-007 - The server file-path separator (m_serverFileSep) must be determined at initialisation time based on the runtime server OS and applied consistently to all subsequent server-side file path operations within the WebUtil session.

---
**Implementation Logic**

```plsql
  
  PROCEDURE InitWebUtil is
    startPoint VARCHAR2(61 char) := NAME_IN('SYSTEM.CURSOR_FIELD');
    hDummy     ITEM              := FIND_ITEM(WEBUTIL_DUMMY_ITEM);
  BEGIN
    -- Set up the various package we know about.
    m_implClasses(WUC_PACKAGE) := 'common.VBeanCommon'; 
    m_implClasses(WUT_PACKAGE) := 'fileTransfer.FileTransfer'; 
    m_implClasses(WUF_PACKAGE) := 'file.FileFunctions'; 
    m_implClasses(WUI_PACKAGE) := 'clientInfo.GetClientInfo'; 
    m_implClasses(WUH_PACKAGE) := 'host.Host'; 
    m_implClasses(WUS_PACKAGE) := 'session.SessionFunctions'; 
    m_implClasses(WUB_PACKAGE) := 'browser.BrowserFunctions'; 
    m_implClasses(WUO_PACKAGE) := 'ole.OleFunctions'; 
    m_implClasses(WUU_PACKAGE) := '';      
    m_implClasses(WUL_PACKAGE) := 'cApi.CApiFunctions';                     
    
    -- Now check for the Webutil Object group which 
    -- contains the Beans etc.
          
    if id_null(m_errorAlert) then 
      -- The Webutil error alert is not around
      -- so the Code cannot operate 
      message('The WEBUTIL object group is not available in this Form.  WebUtil cannot work');
      pause;
    else
      -- Bug 2955789 - this navigation causes problems if they are in Enter-Query mode 
      -- Plus it's not really needed, except as a belt and braces kind of setup.
      -- So put a check to prevent this in E-Q mode and set a top level flag to bypass it 
      -- it all together which we can switch on or off if required as a furture W/A    
      if FLAG_EXPICIT_INSTANCIATE and name_in('SYSTEM.MODE') = 'NORMAL' then 
        if not ID_NULL(hDummy) then 
          -- they are using the standard Object Group
          GO_ITEM(hDummy);
          if GET_ITEM_PROPERTY(startPoint,BLOCK_NAME) = GET_ITEM_PROPERTY(hDummy,BLOCK_NAME) then 
            NEXT_BLOCK;
          else
            GO_ITEM(startPoint);
          end if;
          ShowBeans(false);        
        else
          -- do nothing assume that the programmer is doing their own thing.
          -- with regards to setting up the bean areas and making sure they are drawn
           null;      
        end if;
      end if;
    end if;
        
    -- Work out the server o/s informtion that we need
    if instr(upper(GET_APPLICATION_PROPERTY(OPERATING_SYSTEM)),'WIN') > 0 then 
      m_serverFileSep := '\';
    else
      m_serverFileSep := '/';
    end if;
  END InitWebUtil;
```

#### SP-040 - WEBUTIL.ISERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns a Boolean indicator of whether the most recent WebUtil operation resulted in an error. It exposes the internal error-state variable `m_lastError` to callers (such as WEBUTIL.LOG) so they can branch their processing based on whether a prior operation succeeded or failed.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate the internal package-level variable `m_lastError` against zero.
- Step 2 - Return TRUE if `m_lastError` is not equal to zero, indicating that an error condition is currently recorded.
- Step 3 - Return FALSE if `m_lastError` equals zero, indicating no error is currently recorded.

---
**Decision Points**

DP-001

Condition: `m_lastError <> 0`

TRUE: The function returns TRUE, signalling to the caller that an error state is active.

FALSE: The function returns FALSE, signalling to the caller that no error state is active.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The sole criterion for determining an error state is whether `m_lastError` is non-zero; any non-zero value, regardless of its specific code, is treated as an error.
- BR-002 - The function is read-only; it reports the current error state but does not modify, reset, or clear `m_lastError`.
- BR-003 - The function accepts no input parameters; the error state is derived entirely from the internal package-level variable `m_lastError`.

---
**Implementation Logic**

```plsql
  FUNCTION isError   return BOOLEAN is
  begin 
    return m_lastError <> 0;
  end;
```

#### SP-041 - WEBUTIL.IS_OPEN

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines whether a file handle is currently open by inspecting the handle attribute of the supplied FILE_TYPE record. Returns TRUE if the file is open and FALSE if it is not, allowing callers such as WEBUTIL.LOG to gate file-write operations on a valid open handle.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FILE_TYPE record passed in via the 'file' input parameter.
- Step 2 - Inspect the 'handle' attribute of the FILE_TYPE record to determine whether it holds a non-NULL value.
- Step 3 - If the handle attribute is NULL, return FALSE to indicate the file is not open.
- Step 4 - If the handle attribute is not NULL, return TRUE to indicate the file is open.

---
**Decision Points**

DP-001

Condition: file.handle IS NULL

TRUE: The function returns FALSE, signalling to the caller that no valid file handle exists and the file is not open.

FALSE: The function returns TRUE, signalling to the caller that a valid file handle exists and the file is open.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A FILE_TYPE record is considered closed (not open) if and only if its handle attribute is NULL; any non-NULL handle value is treated as a valid open file reference.
- BR-002 - The function performs no side effects and does not alter the state of the file or its handle; it is a pure read-only check.
- BR-003 - The function must receive a properly typed FILE_TYPE record; no default or fallback value is applied to the input parameter.

---
**Implementation Logic**

```plsql
  
  FUNCTION is_open(file file_type) RETURN BOOLEAN IS
  BEGIN
    IF file.handle IS NULL THEN
      RETURN(FALSE);
    ELSE
      RETURN(TRUE);
    END IF;
  END is_open;
```

#### SP-042 - WEBUTIL.LENGTH

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: STRIPDIRSEP]
- webutil.pld [StoredProcedure: WEBUTIL.GETSTRING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the byte length of a file represented by a Java File object. The function delegates to the native Java method java.io.File.length() via the Oracle JNI bridge, providing Oracle Forms PL/SQL routines with a means to determine the size of a file on the client or server file system without direct database interaction.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java File object (obj) passed in by the calling routine (e.g., DEBUGLOG, REGISTER_FUNCTION_CALL, STRIPDIRSEP, or WEBUTIL.GETSTRING).
- Step 2 - Clear the JNI argument list by setting args to NULL, ensuring no residual arguments from a previous call are carried forward.
- Step 3 - Invoke the Java instance method java.io.File.length() on the supplied object via JNI.CALL_LONG_METHOD, passing FALSE (non-static call), the target object, the fully qualified class path 'java/io/File', the method name 'length', and the method signature '()J' (no parameters, returns a long integer).
- Step 4 - Return the numeric result (file size in bytes) to the calling routine.

---
**Decision Points**

No conditional decision points exist in this function. The logic follows a single, unconditional execution path: clear arguments, invoke the JNI method, and return the result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The input parameter obj must be a valid ORA_JAVA.JOBJECT reference to a java.io.File instance; the function does not validate the object reference before invoking the JNI call.
- BR-002 - The argument list (args) must be explicitly reset to NULL before each JNI invocation to prevent argument pollution from prior calls.
- BR-003 - The file length is returned as a NUMBER representing bytes, sourced directly from the Java runtime via java.io.File.length(); no rounding, conversion, or unit transformation is applied.
- BR-004 - This function performs no database reads or writes; all processing is confined to the JNI/Java layer.

---
**Implementation Logic**

```plsql
  FUNCTION length(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_LONG_METHOD(FALSE, obj, 'java/io/File', 'length', '()J', args); 
  END;
```

#### SP-043 - WEBUTIL.LOG

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]
- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.LOG writes diagnostic and error messages to a server-side log file on behalf of the WebUtil framework. It initialises logging configuration on first invocation by reading property-bundle settings, communicates the resolved logging mode to the WebUtil bean layer, and appends each qualifying message (optionally prefixed with the client IP address and username) to the configured log file. The procedure also handles file-write failures gracefully by disabling logging and raising a user-visible alert when no bean is yet registered.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| msg | VARCHAR2 | IN |
| isError | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-019](#SP-019--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ISERROR ([SP-040](#SP-040--WEBUTIL.ISERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.IS_OPEN ([SP-041](#SP-041--WEBUTIL.IS_OPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-046](#SP-046--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - On the first call (module-level cache variable m_loggingAllowed is NULL), read three logging configuration values from the property bundle: 'logging.enabled' (stored in m_loggingAllowed), 'logging.errorsonly' (stored in m_loggingErrorsOnly), and 'logging.file' (stored in m_loggingFile), using WEBUTIL.READFROMPROPERTYBUNDLE.
- Step 2 - If logging is enabled but no log file name was returned, set m_loggingAllowed to FALSE to disable logging for the session.
- Step 3 - When the log file is missing and no WebUtil bean is registered yet, call WEBUTIL.ERRORALERT to display error message 'WUC-008: Server side logging was requested but no log file was specified - logging is disabled' in English.
- Step 4 - When the log file is missing and at least one bean is registered, communicate the disabled state to the bean layer by setting the WUC_SRV_LOGGING property to '0' and raising error code 8 via WebUtil_Core.
- Step 5 - If at least one bean is registered and logging is active, communicate the resolved logging mode to the bean layer: set WUC_SRV_LOGGING to '1' for errors-only mode, '2' for full logging, or '0' if logging is disabled.
- Step 6 - After configuration initialisation, evaluate whether the current message qualifies for writing: logging must be allowed and either errors-only mode is off, or errors-only mode is on and the isError flag is TRUE.
- Step 7 - Open the log file in append mode ('A') using TEXT_IO.FOPEN.
- Step 8 - Verify the file was opened successfully using TEXT_IO.IS_OPEN; if not, raise NO_DATA_FOUND.
- Step 9 - Write the message to the log file. If m_clientIP is populated, prefix the message with the client IP address and username in the format 'clientIP:clientUserName: msg'; otherwise write the message as-is.
- Step 10 - Close the log file using TEXT_IO.FCLOSE.
- Step 11 - In the exception handler, if SQLCODE is -302000 (file write failure), display error 'WUC-007: Unable to write to WebUtil Logging File <filename>' via WEBUTIL.ERRORALERT when no bean is registered, or set WUC_SRV_LOGGING to '0' and raise error code 7 via WebUtil_Core when a bean is registered; in both cases set m_loggingAllowed to FALSE to suppress further logging attempts. All other exceptions are re-raised.

---
**Decision Points**

DP-001
Condition: m_loggingAllowed IS NULL (logging configuration cache has not yet been initialised for this session).
TRUE: Read logging configuration from the property bundle via WEBUTIL.READFROMPROPERTYBUNDLE and populate the module-level cache variables m_loggingAllowed, m_loggingErrorsOnly, and m_loggingFile.
FALSE: Skip initialisation; use previously cached configuration values.

DP-002
Condition: m_loggingAllowed is TRUE but m_loggingFile IS NULL (logging enabled with no target file specified).
TRUE: Set m_loggingAllowed to FALSE to disable logging and proceed to DP-003 to determine how to report the configuration error.
FALSE: Retain the current value of m_loggingAllowed and proceed.

DP-003
Condition: m_registeredPackages.FIRST IS NULL (no WebUtil bean is registered) - evaluated when the log file is missing.
TRUE: Call WEBUTIL.ERRORALERT to display the WUC-008 English-language error message directly.
FALSE: Set the WUC_SRV_LOGGING bean property to '0' and raise error code 8 via WebUtil_Core.

DP-004
Condition: m_registeredPackages.FIRST IS NOT NULL (at least one bean is registered) - evaluated after the log-file validation block during cache initialisation.
TRUE: Communicate the resolved logging mode to the bean layer (WUC_SRV_LOGGING = '1', '2', or '0' depending on mode).
FALSE: Skip bean-layer property update.

DP-005
Condition: m_loggingAllowed is TRUE AND (m_loggingErrorsOnly is FALSE OR (m_loggingErrorsOnly is TRUE AND isError is TRUE)).
TRUE: Proceed to open the log file and write the message.
FALSE: Exit the procedure without writing anything.

DP-006
Condition: TEXT_IO.IS_OPEN(logFile) returns FALSE after attempting to open the log file.
TRUE: Raise NO_DATA_FOUND, transferring control to the exception handler.
FALSE: Continue to write the message to the open file.

DP-007
Condition: m_clientIP IS NULL at the point of writing the log entry.
TRUE: Write the message string alone to the log file.
FALSE: Prefix the message with 'm_clientIP:m_clientUserName: ' before writing.

DP-008
Condition: An exception is raised and SQLCODE = -302000 (file write error).
TRUE: Report the WUC-007 error (via WEBUTIL.ERRORALERT if no bean is registered, or via WebUtil_Core if a bean is registered), then set m_loggingAllowed to FALSE.
FALSE: Re-raise the exception for the caller to handle.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Logging configuration (enabled flag, errors-only flag, and log file path) is read from the property bundle exactly once per session; subsequent calls reuse the cached values without re-reading the bundle.
- BR-002 - If logging is configured as enabled but no log file path is provided, logging is unconditionally disabled for the remainder of the session (m_loggingAllowed = FALSE).
- BR-003 - When errors-only mode is active (m_loggingErrorsOnly = TRUE), only messages passed with isError = TRUE are written to the log file; informational messages are silently suppressed.
- BR-004 - Log entries for sessions with a known client IP address must be prefixed with the client IP and username ('clientIP:clientUserName: ') to support per-client traceability.
- BR-005 - The log file is opened in append mode for each individual write operation and closed immediately afterwards, ensuring no file handle is held open between log calls.
- BR-006 - When no WebUtil bean is registered, configuration or write errors must be surfaced to the user via WEBUTIL.ERRORALERT using plain English messages (WUC-007, WUC-008); when a bean is registered, errors are communicated through the WebUtil_Core property and error mechanism instead.
- BR-007 - A file write failure (SQLCODE -302000) permanently disables logging for the session (m_loggingAllowed = FALSE) to prevent repeated failed write attempts.
- BR-008 - The resolved logging mode must be communicated to the bean layer via the WUC_SRV_LOGGING property ('0' = disabled, '1' = errors only, '2' = full) whenever at least one bean is registered, ensuring the client-side bean reflects the server-side logging state.

---
**Implementation Logic**

```plsql
  

  PROCEDURE Log(msg in VARCHAR2, isError BOOLEAN) is
    logFile       TEXT_IO.FILE_TYPE;
    logFileName   VARCHAR2(1024 char);
    errorOnlyMode BOOLEAN;
  begin
    -- check to see if we should do anything
    if m_loggingAllowed is null then 
      -- set up the logging info Cache
      m_loggingAllowed    := (lower(ReadFromPropertyBundle('logging.enabled')) = 'true');
      m_loggingErrorsOnly := (lower(ReadFromPropertyBundle('logging.errorsonly')) = 'true');
      m_loggingFile       := ReadFromPropertyBundle('logging.file');
      if m_loggingAllowed then 
        if m_loggingFile is null then 
          -- no file == no logging
          m_loggingAllowed := false;
          if m_registeredPackages.FIRST is null then
            -- There is no bean registered yet. Throw error in English using alert
            ErrorAlert('WUC-008: Server side logging was requested but no log file was specified'
                       ||' - logging is disabled');
          else
            WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
            WebUtil_Core.error(WUC_PACKAGE,8,'WebUtil_Core.Log');
          end if;
        end if;
      end if;
      if m_registeredPackages.FIRST is not null then
        -- At least one bean is registered. Can call setProperty(WUC_PACKAGE)
        if m_loggingAllowed and m_loggingErrorsOnly then
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','1',true);
        elsif  m_loggingAllowed then
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','2',true);
        else
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
        end if;
      end if;
    end if;
        
    -- now log if allowed to do so
    if m_loggingAllowed then
      if ((not m_loggingErrorsOnly) or (m_loggingErrorsOnly and isError)) then
        logFile := TEXT_IO.FOPEN(m_loggingFile,'A');
        if not TEXT_IO.IS_OPEN(logFile) then 
          raise NO_DATA_FOUND;
        end if;
        if m_clientIP is null then
        	TEXT_IO.PUT_LINE(logFile,msg);
        else
        	TEXT_IO.PUT_LINE(logFile,m_clientIP||':'||m_clientUserName||': '||msg);
        end if;
        TEXT_IO.FCLOSE(logFile);
      end if;    
    end if;
  EXCEPTION
    when others then 
      if SQLCODE = '-302000' then
        if m_registeredPackages.FIRST is null then
          -- There is no bean registered yet. Throw error in English using alert
          ErrorAlert('WUC-007: Unable to write to WebUtil Logging File '|| m_loggingFile);
        else

          WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
          WebUtil_Core.error(WebUtil_Core.WUC_PACKAGE,7,'WebUtil_Core.Log',m_loggingFile);
        end if;
        m_loggingAllowed := false;
      else
        RAISE;
      end if;      
  end Log;
```

#### SP-044 - WEBUTIL.POPULATEPROPERTYBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.READFROMPROPERTYBUNDLE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Locates and reads the WebUtil configuration file, parses its key-value property pairs into the in-memory property bundle (m_propertyBundle), and returns the value associated with the requested property key. The procedure resolves the configuration file path through a prioritised lookup across a Forms global variable, an environment variable, and a Forms parameter, ensuring that downstream callers such as WEBUTIL.READFROMPROPERTYBUNDLE can retrieve runtime configuration values without direct file-system knowledge.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-019](#SP-019--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Read the configuration file path from the Forms global variable identified by WEBUTIL_CONFIG_GLOBAL; if the global holds the sentinel value '[NOTSET]', treat it as unset.
- Step 2 - If the global variable is unset, attempt to resolve the configuration file path from the operating-system environment variable identified by WEBUTIL_CONFIG_ENV using TOOL_ENV.GETVAR.
- Step 3 - If the environment variable also yields no value, fall back to the Forms parameter identified by WEBUTIL_CONFIG_PARAM via NAME_IN; if this too is null, raise NO_DATA_FOUND to signal that no configuration source is available.
- Step 4 - Persist the resolved file path back into WEBUTIL_CONFIG_GLOBAL using COPY so that subsequent calls bypass the lookup chain.
- Step 5 - Open the resolved configuration file for reading using TEXT_IO.FOPEN.
- Step 6 - Read the file line by line in a loop using TEXT_IO.GET_LINE; exit the loop when NO_DATA_FOUND is raised at end-of-file.
- Step 7 - Skip any line whose first character is '#' (comment lines are not processed).
- Step 8 - For each non-comment line, locate the '=' delimiter using INSTR; lines without a '=' separator are ignored.
- Step 9 - For each valid name-value line, increment the property index, then store the trimmed, lower-cased key and the trimmed, carriage-return-stripped value into the next slot of m_propertyBundle.
- Step 10 - Compare the stored key against the lower-cased input parameter propertyKey; if they match, capture the corresponding value in the result variable.
- Step 11 - After the loop completes, close the configuration file using TEXT_IO.FCLOSE and return the result value (NULL if the key was not found).
- Step 12 - On NO_DATA_FOUND exception (no configuration file path resolved): if no bean package is yet registered (m_registeredPackages.FIRST is null), invoke WEBUTIL.ERRORALERT to display error 'WUC-005: No WebUtil Configuration File specified'; otherwise delegate to Webutil_Core.Error. Set m_config_error to TRUE and return NULL.
- Step 13 - On SQLCODE -302000 (file read failure): if no bean package is registered, invoke WEBUTIL.ERRORALERT to display error 'WUC-006: Unable to read WebUtil Configuration File'; otherwise delegate to Webutil_Core.Error. Set m_config_error to TRUE and return NULL.
- Step 14 - All other exceptions are re-raised to the caller without suppression.

---
**Decision Points**

DP-001
Condition: The Forms global variable WEBUTIL_CONFIG_GLOBAL contains the sentinel value '[NOTSET]'.
TRUE: Clear the local configFile variable and attempt to resolve the path from the environment variable WEBUTIL_CONFIG_ENV.
FALSE: Use the value held in WEBUTIL_CONFIG_GLOBAL as the configuration file path and proceed to open the file.

DP-002
Condition: The environment variable WEBUTIL_CONFIG_ENV returns a non-null value.
TRUE: Use the returned value as the configuration file path.
FALSE: Attempt to resolve the configuration file path from the Forms parameter WEBUTIL_CONFIG_PARAM.

DP-003
Condition: The Forms parameter WEBUTIL_CONFIG_PARAM returns a non-null value.
TRUE: Use the returned value as the configuration file path.
FALSE: Raise NO_DATA_FOUND, triggering the no-configuration-file error handling path.

DP-004
Condition: The first character of the current file line is '#'.
TRUE: Skip the line entirely; no property is parsed or stored.
FALSE: Proceed to check for a '=' delimiter and parse the line as a key-value pair.

DP-005
Condition: The current line contains a '=' character (INSTR returns a position greater than zero).
TRUE: Parse the line into a key-value pair, store it in m_propertyBundle, and check whether the key matches propertyKey.
FALSE: Ignore the line; no property is stored.

DP-006
Condition: The lower-cased parsed key equals the lower-cased input parameter propertyKey.
TRUE: Assign the parsed value to the result variable for return to the caller.
FALSE: Continue processing remaining lines without updating the result variable.

DP-007
Condition: A NO_DATA_FOUND exception is raised during error handling and m_registeredPackages.FIRST is null (no bean yet registered).
TRUE: Call WEBUTIL.ERRORALERT with message 'WUC-005: No WebUtil Configuration File specified'.
FALSE: Delegate error reporting to Webutil_Core.Error.

DP-008
Condition: An OTHERS exception is raised with SQLCODE equal to -302000 (file read failure) and m_registeredPackages.FIRST is null.
TRUE: Call WEBUTIL.ERRORALERT with message 'WUC-006: Unable to read WebUtil Configuration File'.
FALSE: If SQLCODE is -302000 but a bean is registered, delegate to Webutil_Core.Error; if SQLCODE is any other value, re-raise the exception.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The configuration file path must be resolvable from exactly one of three sources in strict priority order: (1) the Forms global variable WEBUTIL_CONFIG_GLOBAL, (2) the environment variable WEBUTIL_CONFIG_ENV, (3) the Forms parameter WEBUTIL_CONFIG_PARAM. If none yields a value, the procedure treats the absence as a fatal configuration error.
- BR-002 - Once the configuration file path is successfully resolved from any source, it must be written back into WEBUTIL_CONFIG_GLOBAL so that the lookup chain is bypassed on subsequent invocations within the same Forms session.
- BR-003 - Lines beginning with the '#' character are treated as comments and must not be parsed or stored in the property bundle.
- BR-004 - Only lines containing a '=' character are treated as valid property definitions; lines without this delimiter are silently ignored.
- BR-005 - Property keys are stored and matched in lower-case with leading and trailing whitespace removed, ensuring case-insensitive and whitespace-tolerant key lookup.
- BR-006 - Property values are stored with leading and trailing whitespace removed and carriage-return characters (CHR(13)) stripped, ensuring clean values on both Unix and Windows line-ending formats.
- BR-007 - When no configuration file path can be determined (NO_DATA_FOUND), the procedure must set the module-level error flag m_config_error to TRUE and return NULL, preventing further property resolution attempts from proceeding silently.
- BR-008 - When the configuration file cannot be read (SQLCODE -302000), the procedure must set m_config_error to TRUE and return NULL rather than propagating the file-system error to the caller.
- BR-009 - User-facing error alerts (WUC-005, WUC-006) are raised via WEBUTIL.ERRORALERT only when no bean package has yet been registered (m_registeredPackages.FIRST is null); once a bean is registered, error reporting is delegated to the Webutil_Core framework.
- BR-010 - Any exception other than NO_DATA_FOUND and SQLCODE -302000 must be re-raised unconditionally, preserving the original error context for the calling routine.

---
**Implementation Logic**

```plsql
      
  FUNCTION PopulatePropertyBundle(propertyKey in VARCHAR2) return VARCHAR2 is
    configFile   VARCHAR2(512 char);
    buffer       VARCHAR2(1000 char);
    result       VARCHAR2(1000 char);          
    propertyFile TEXT_IO.FILE_TYPE;
    pos          PLS_INTEGER;
    propIndex    PLS_INTEGER := 0;
  begin
    -- First of get the name of the cfg file 
    -- This could come in a global  or from the Environment
    default_value('[NOTSET]',WEBUTIL_CONFIG_GLOBAL);
    configFile := name_in(WEBUTIL_CONFIG_GLOBAL);
    if configFile = '[NOTSET]' then
      configFile := null; 
      -- Try the environment
      TOOL_ENV.GETVAR(WEBUTIL_CONFIG_ENV, configFile); 
      if configFile is null then 
        -- Finally try the Forms parameters
        configFile := name_in(WEBUTIL_CONFIG_PARAM);
        -- if that fails then we have to raise an error
        if configFile is null then 
          raise NO_DATA_FOUND;
        end if;    
      end if;
    end if;
    
    copy(configFile, WEBUTIL_CONFIG_GLOBAL);
      
    propertyFile := Text_IO.FOpen(configFile,'R');
    LOOP
      begin
        Text_IO.Get_Line(propertyFile,buffer);
      exception
        when NO_DATA_FOUND then EXIT;
      end;
        
      -- ignore lines which start with '#'
      if substr(buffer,1,1) <> '#' then 
        pos := instr(buffer,'=');
        -- only process lines with a name value pair
        if pos > 0 then 
          propIndex := propIndex + 1;
          m_propertyBundle(propIndex).propertyKey   := lower(ltrim(rtrim(substr(buffer,1,pos-1))));    
          m_propertyBundle(propIndex).propertyValue := ltrim(rtrim(replace(substr(buffer,pos+1),chr(13),'')));
          -- Check to see if this is the key we are looking for
          if  m_propertyBundle(propIndex).propertyKey = lower(propertyKey) then
            result := m_propertyBundle(propIndex).propertyValue;
          end if;
        end if;
      end if;
    end LOOP;
    Text_IO.FClose(propertyFile);
    return result;
  EXCEPTION
    when NO_DATA_FOUND then 
      if m_registeredPackages.FIRST is null then
        -- There is no bean registered yet. Throw error in English using alert
        ErrorAlert('WUC-005: No WebUtil Configuration File specified');
      else
        Webutil_Core.Error(Webutil_Core.WUC_PACKAGE,5,'WebUtil_Core.PopulatePropertyBundle');
      end if;
      m_config_error := true;
      return null;
    when others then 
      if SQLCODE = '-302000' then
        if m_registeredPackages.FIRST is null then
          -- There is no bean registered yet. Throw error in English using alert
          ErrorAlert('WUC-006: Unable to read WebUtil Configuration File');
        else
          Webutil_Core.Error(Webutil_Core.WUC_PACKAGE,6,'WebUtil_Core.PopulatePropertyBundle', configFile);
        end if;
        m_config_error := true;
        return null;
      else
        RAISE;
      end if;      

  end PopulatePropertyBundle;
```

#### SP-045 - WEBUTIL.PUT_LINE

**Invoked From:**

- vr_bshop_tech_prod_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes one line of text to an open server-side file via the WebUtil client-side Java bean, appending a newline after the text. Passes the file handle and the text content to the WebUtil bean for writing. Raises a tool error if the WebUtil bean is not registered or a property error occurs.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |
| item | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the open file handle and the text line to write as inputs.
- Step 2 - Pass the file handle to the WebUtil client-side Java bean.
- Step 3 - Instruct the WebUtil bean to write the provided text content to the file.
- Step 4 - Instruct the WebUtil bean to write a newline character after the text content.
- Step 5 - If a BEAN_NOT_REGISTERED exception occurs, display an error message and raise a tool error. If a PROPERTY_ERROR exception occurs, raise a tool error.

---
**Decision Points**

No conditional branches present in the Implementation Logic.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Each call to this function writes one line of text followed by a newline to the open file, ensuring each result row is written on its own line in the CSV output.
- BR-002 - If the WebUtil file bean is not available on the client, a tool error is raised to prevent silent data loss.

---
**Implementation Logic**

```plsql
    

  PROCEDURE put_line (file file_type, item VARCHAR2) is
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);              
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_PUT',item); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_NEWLINE',1); 
  EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.put_line will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;  
  END put_line;
```

#### SP-046 - WEBUTIL.READFROMPROPERTYBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.LOG]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value associated with a given property key from an in-memory property bundle cache. If the bundle has not yet been populated, it delegates to WEBUTIL.POPULATEPROPERTYBUNDLE to load the configuration data before performing the lookup. This function supports callers such as WEBUTIL.CHECKLIBS, WEBUTIL.LOG, and WEBUTIL.REGISTERBEAN in resolving runtime configuration properties.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.POPULATEPROPERTYBUNDLE ([SP-044](#SP-044--WEBUTIL.POPULATEPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input property key (propertyKey) and initialise a local result variable and a count of entries currently held in the in-memory property bundle (m_propertyBundle).
- Step 2 - Check whether a configuration error flag (m_config_error) has previously been raised; if so, abort immediately and return NULL to the caller.
- Step 3 - If no configuration error exists but the property bundle is empty (count = 0), invoke WEBUTIL.POPULATEPROPERTYBUNDLE passing the requested propertyKey to load the bundle and obtain the value in a single operation; assign the returned value to result.
- Step 4 - If the property bundle is already populated (count > 0), iterate through all entries in m_propertyBundle, comparing each entry's propertyKey (stored in lower-case) against the lower-case form of the supplied propertyKey.
- Step 5 - On finding a matching entry, assign the corresponding propertyValue to result and exit the loop immediately.
- Step 6 - Return result to the caller; result remains NULL if no matching key was found in the bundle.

---
**Decision Points**

DP-001

Condition: m_config_error flag is TRUE.

TRUE: Return NULL immediately; no further processing is performed.

FALSE: Proceed to evaluate the state of the property bundle.

---

DP-002

Condition: The property bundle (m_propertyBundle) contains zero entries (COUNT = 0).

TRUE: Call WEBUTIL.POPULATEPROPERTYBUNDLE with the supplied propertyKey to populate the bundle and retrieve the value.

FALSE: Iterate through the existing bundle entries to locate the matching key.

---

DP-003

Condition: During iteration, the current bundle entry's propertyKey matches the lower-case form of the supplied propertyKey.

TRUE: Assign the entry's propertyValue to result and exit the loop.

FALSE: Continue to the next entry in the bundle; result remains NULL if no match is found after all entries are exhausted.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - If a configuration error has previously been recorded (m_config_error = TRUE), the function must return NULL without attempting any property lookup or bundle population.
- BR-002 - Property key matching is case-insensitive; all stored keys are held in lower-case and the supplied propertyKey is compared in lower-case to ensure consistent resolution.
- BR-003 - The property bundle is populated on demand: WEBUTIL.POPULATEPROPERTYBUNDLE is called only when the bundle is empty, preventing redundant reloads on subsequent lookups.
- BR-004 - The function returns NULL when the requested key is not present in the bundle and no configuration error has occurred; callers must handle a NULL return as a key-not-found condition.
- BR-005 - Once a matching entry is found during iteration, the loop exits immediately, ensuring the first matching entry takes precedence and avoiding unnecessary processing.

---
**Implementation Logic**

```plsql
  
  FUNCTION ReadFromPropertyBundle(propertyKey in VARCHAR2) return VARCHAR2 is   
    result       VARCHAR2(1000 char);
    propCount    PLS_INTEGER := m_propertyBundle.COUNT;
  begin
    if m_config_error then
      -- already encountered problem reading the config file.
      return null;
    elsif (propCount = 0) then
      result := populatePropertyBundle(propertyKey);
    else
      for i in 1..propCount LOOP
        if m_propertyBundle(i).propertyKey = lower(propertyKey) then 
          result := m_propertyBundle(i).propertyValue;
          EXIT;
        end if;
      end LOOP;
    end if;
    return result;
  end ReadFromPropertyBundle;
```

#### SP-047 - WEBUTIL.READTRANSFROMMSGBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a translated message string from the WebUtil message bundle by submitting a property key and optional arguments to the WebUtil Core communication layer. The function is used to obtain localised UI text - currently limited to fetching the progress bar title during library checking performed by WEBUTIL.CHECKLIBS.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |
| args | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message bundle property key (propertyKey) and an optional arguments string (args) as input.
- Step 2 - Concatenate propertyKey and args with a pipe delimiter ('|') to form a composite lookup token.
- Step 3 - Write the composite token to the WebUtil Core communication channel by calling Webutil_Core.setProperty, targeting the WUC_PACKAGE package identifier and the WUC_TRANS_MSG property name.
- Step 4 - Read the resolved translated message back from the same WebUtil Core channel by calling Webutil_Core.getProperty with the same WUC_PACKAGE and WUC_TRANS_MSG identifiers.
- Step 5 - Return the retrieved translated message string to the caller.

---
**Decision Points**

No conditional decision points exist within this function. The set/get sequence executes unconditionally for every invocation regardless of the values supplied for propertyKey or args.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The propertyKey parameter is mandatory; args is optional and defaults to NULL when not supplied by the caller.
- BR-002 - The composite lookup token passed to the WebUtil Core layer must be formatted as propertyKey||'|'||args; this delimiter convention is required for the message bundle resolution mechanism to parse the key and arguments correctly.
- BR-003 - Message retrieval is performed exclusively through the Webutil_Core.setProperty and Webutil_Core.getProperty interface targeting WUC_PACKAGE and WUC_TRANS_MSG; no direct database or file-system access is performed.
- BR-004 - The function is currently authorised for use only from WEBUTIL.CHECKLIBS, where it serves the specific purpose of obtaining the localised progress bar title.

---
**Implementation Logic**

```plsql
  
  FUNCTION ReadTransFromMsgBundle(propertyKey in VARCHAR2, args in VARCHAR2 := null) return VARCHAR2 is
    -- currently called from checkLibs only for getting progress bar title.
  begin 
    Webutil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_TRANS_MSG', propertyKey||'|'||args);
    return Webutil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_TRANS_MSG');
  end ReadTransFromMsgBundle;
```

#### SP-048 - WEBUTIL.REGISTERBEAN

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a WebUtil client-side bean with the server-side Forms session on its first contact. The procedure parses the bean's registration packet, maps the bean short-name to an internal package identifier, captures one-time client environment metadata (IP address, OS, architecture, locale, path/file separators, user name), resolves the system-library download directory, configures heartbeat and server-logging behaviour on the client bean, and triggers library availability checks for both the newly registered package and any user-defined libraries.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| clientInfo | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.CHECKLIBS ([SP-013](#SP-013--WEBUTIL.CHECKLIBS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTSETTING ([SP-025](#SP-025--WEBUTIL.GETCLIENTSETTING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETOSFAMILY ([SP-030](#SP-030--WEBUTIL.GETOSFAMILY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETPROPERTY ([SP-032](#SP-032--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETVAR ([SP-034](#SP-034--WEBUTIL.GETVAR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-043](#SP-043--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-046](#SP-046--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETCLIENTSETTING ([SP-051](#SP-051--WEBUTIL.SETCLIENTSETTING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Extract the bean short-name from the pipe-delimited clientInfo string (position 1) and map it to the corresponding internal WEBUTIL_CORE package-ID constant (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, or WUL).
- Step 2 - If the client IP address (m_clientIP) has not yet been recorded, mark the session for one-time initialisation (checkUserLibs = TRUE) and parse positions 2-8 of clientInfo to populate m_clientIP, m_clientOS, m_clientOSFamily (via WEBUTIL.GETOSFAMILY), m_clientOSArch (set to 1 when the architecture string contains '64'), m_clientUserName, m_clientPathSep, m_clientFileSep, and m_clientLangCode.
- Step 3 - If the resolved packageID has not already been registered in m_registeredPackages, store the current SYSTEM.TRIGGER_ITEM value against that package ID and flag the package as new (newPackage = TRUE).
- Step 4 - When checkUserLibs is TRUE, perform one-time server-host and library-directory resolution: reset REDOWNLOAD_SYSLIB to FALSE; retrieve the server host name via WEBUTIL.GETVAR using the 'COMPUTERNAME' variable, falling back to 'HOST' if null; look up the client system-library directory from the property bundle using WEBUTIL.READFROMPROPERTYBUNDLE with OS-family and architecture-specific keys, falling back to the OS-family-only key.
- Step 5 - Communicate the resolved system-library directory to the WUC bean via WEBUTIL_CORE.setProperty with the WUC_SYSLIB_DIR property. If no directory was found in the property bundle, send a server-only token (colon-prefixed serverHost and CONFIG application property) so the client defaults to the JRE location. If a directory was found, substitute the '$(SERVERHOST)' placeholder with the actual server host name, then compare it with the previously stored client setting (WEBUTIL.GETCLIENTSETTING 'install.syslib.dir'); if they differ, update the setting via WEBUTIL.SETCLIENTSETTING and set REDOWNLOAD_SYSLIB to TRUE.
- Step 6 - Retrieve and store the WebUtil bean version from the WUC bean property WUC_BEAN_VERSION via WEBUTIL.GETPROPERTY.
- Step 7 - If the 'logging.connections' property bundle entry equals 'true' (case-insensitive), write a connection log entry via WEBUTIL.LOG recording the current form name, client OS, and locale.
- Step 8 - If the package is newly registered (newPackage = TRUE), invoke WEBUTIL.CHECKLIBS with the package ID string to verify and download required client libraries for that package.
- Step 9 - If checkUserLibs is TRUE, call WEBUTIL.LOG with a null message to initialise the m_loggingAllowed and m_loggingErrorsOnly session flags.
- Step 10 - Read the 'BlockAllowHeartBeat' property bundle entry; if its lower-case value is 'true', 'yes', or '1', set the WUC_BLOCK_ALLOW_HEART_BEAT property to '1' on the client bean; otherwise set it to '0'.
- Step 11 - Transmit the server-side logging mode to the client bean via the WUC_SRV_LOGGING property: '1' when logging is allowed but errors-only, '2' when full logging is allowed, or '0' when logging is disabled.
- Step 12 - If checkUserLibs is TRUE, invoke WEBUTIL.CHECKLIBS with the literal string 'user' to check for and download any user-defined client libraries.

---
**Decision Points**

DP-001
Condition: beanShortName equals one of the recognised short-name constants (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL).
TRUE: The corresponding WEBUTIL_CORE package-ID constant is assigned to packageID.
FALSE: packageID remains uninitialised and no package-specific processing is performed for that bean.

DP-002
Condition: m_clientIP is null (client environment has not yet been captured for this session).
TRUE: checkUserLibs is set to TRUE and client metadata fields (IP, OS, OS family, OS architecture, user name, path separator, file separator, language code) are parsed from clientInfo.
FALSE: One-time client initialisation is skipped; checkUserLibs remains FALSE.

DP-003
Condition: The architecture string extracted from clientInfo (position 4) contains '64'.
TRUE: m_clientOSArch is set to 1 (64-bit client).
FALSE: m_clientOSArch retains its default value (not set to 1).

DP-004
Condition: m_registeredPackages does not already contain an entry for packageID.
TRUE: The package is registered by storing SYSTEM.TRIGGER_ITEM against packageID; newPackage is set to TRUE.
FALSE: The package is already registered; newPackage remains FALSE and the duplicate registration is ignored.

DP-005
Condition: checkUserLibs is TRUE (first-contact initialisation path).
TRUE: Server host resolution, system-library directory lookup, version retrieval, connection logging, user library check, and logging-flag initialisation are performed.
FALSE: All one-time initialisation steps are bypassed.

DP-006
Condition: serverHost is null after attempting WEBUTIL.GETVAR with 'COMPUTERNAME'.
TRUE: WEBUTIL.GETVAR is called again with 'HOST' to obtain the server host name.
FALSE: The value retrieved via 'COMPUTERNAME' is used as serverHost.

DP-007
Condition: clientLibDir is null after the OS-family-and-architecture-specific property bundle lookup.
TRUE: A second lookup is attempted using only the OS-family key (without architecture suffix).
FALSE: The architecture-specific directory value is used directly.

DP-008
Condition: clientLibDir is still null after both property bundle lookups.
TRUE: WUC_SYSLIB_DIR is set to a server-token-only value (colon-prefixed serverHost and CONFIG), delegating directory resolution to the client JRE.
FALSE: The resolved clientLibDir is used; '$(SERVERHOST)' placeholder is replaced, WUC_SYSLIB_DIR is set with the full path, and the stored client setting is compared.

DP-009
Condition: The previously stored client library directory (clientLibDirOld from WEBUTIL.GETCLIENTSETTING) differs from the newly resolved clientLibDir.
TRUE: WEBUTIL.SETCLIENTSETTING updates 'install.syslib.dir' with the new directory and REDOWNLOAD_SYSLIB is set to TRUE.
FALSE: The stored directory is current; no update is made and REDOWNLOAD_SYSLIB remains FALSE.

DP-010
Condition: The lower-case value of the 'logging.connections' property bundle entry equals 'true'.
TRUE: A connection log entry is written via WEBUTIL.LOG including form name, client OS, and locale.
FALSE: No connection log entry is written.

DP-011
Condition: newPackage is TRUE (the bean's package was registered for the first time in this invocation).
TRUE: WEBUTIL.CHECKLIBS is called with the package ID string to verify client library availability for that package.
FALSE: Library check for the package is skipped.

DP-012
Condition: The lower-case 'BlockAllowHeartBeat' property bundle value equals 'true', 'yes', or '1'.
TRUE: WUC_BLOCK_ALLOW_HEART_BEAT is set to '1' on the client bean, instructing it to block heartbeat allowance.
FALSE: WUC_BLOCK_ALLOW_HEART_BEAT is set to '0', permitting normal heartbeat behaviour.

DP-013
Condition: m_loggingAllowed is TRUE and m_loggingErrorsOnly is TRUE.
TRUE: WUC_SRV_LOGGING is set to '1' (errors-only logging mode communicated to client).
FALSE: Evaluation continues to the next condition.

DP-014
Condition: m_loggingAllowed is TRUE (and m_loggingErrorsOnly is FALSE, from DP-013 FALSE branch).
TRUE: WUC_SRV_LOGGING is set to '2' (full logging mode communicated to client).
FALSE: WUC_SRV_LOGGING is set to '0' (logging disabled on client).

DP-015
Condition: checkUserLibs is TRUE after all package-specific processing.
TRUE: WEBUTIL.CHECKLIBS is called with the literal 'user' to check and download user-defined client libraries.
FALSE: User library check is skipped.

---
**Database Interactions**

- DB-001 - Update THIS - Updates existing rows in THIS.
**Business Rules**

- BR-001 - Only recognised bean short-names (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL) are mapped to internal package IDs; unrecognised short-names result in no package registration.
- BR-002 - Client environment metadata (IP address, OS, architecture, user name, path/file separators, language code) is captured exactly once per Forms session; subsequent bean registrations within the same session do not overwrite these values.
- BR-003 - Each bean package is registered at most once per session; if the same bean is present in a multi-row block or instantiated multiple times, only the first instance is recorded.
- BR-004 - The client system-library directory is resolved with preference for the most specific property bundle key (OS-family + architecture), falling back to the OS-family-only key, and finally delegating to the client JRE when neither key is defined.
- BR-005 - The '$(SERVERHOST)' placeholder in a configured client library directory must be substituted with the runtime server host name before the value is transmitted to the client bean.
- BR-006 - When the resolved system-library directory differs from the previously stored client setting, the stored setting is updated and REDOWNLOAD_SYSLIB is flagged TRUE to trigger a re-download of system libraries.
- BR-007 - Connection logging is conditional on the 'logging.connections' property bundle entry being set to 'true' (case-insensitive); the log entry must include the current form name, client OS, and client locale.
- BR-008 - Library availability for a newly registered package (via WEBUTIL.CHECKLIBS) must be checked only after the package has been recorded in m_registeredPackages, ensuring a handler bean exists to perform any required download.
- BR-009 - The 'BlockAllowHeartBeat' configuration variable accepts only the values 'true', 'yes', or '1' (case-insensitive) as affirmative; any other value is treated as disabled.
- BR-010 - Server-side logging mode must be communicated to the client bean as a discrete numeric code: '0' (disabled), '1' (errors only), or '2' (full logging), derived from the m_loggingAllowed and m_loggingErrorsOnly session flags.
- BR-011 - User-defined library checks (WEBUTIL.CHECKLIBS with 'user') must be performed only once per session and only after at least one bean package has been registered, ensuring a client handler is available.

---
**Implementation Logic**

```plsql
  PROCEDURE registerBean(clientInfo in VARCHAR2) is  
    packageID       PLS_INTEGER;
    beanShortName   VARCHAR2(3 char);
    newPackage      BOOLEAN := false;
    checkUserLibs   BOOLEAN := false;
    clientLibDir    VARCHAR2(1000 char);
    clientLibDirOld VARCHAR2(1000 char);
    serverHost      VARCHAR2(100 char);
    blockAllowHeartBeat VARCHAR2(10 char);
    clientOSArch    VARCHAR2(30 char);
  begin
    beanShortName := DelimStr.getString(clientInfo,1,true,'|');

    -- To speed access up we crossmatch the Bean Name string
    -- with a constant - this constant is used to access the 
    -- registered package array efficently
    -- need to update this IF statement as we add new packages
    if beanShortName = 'WUC' then
       packageID := WEBUTIL_CORE.WUC_PACKAGE; 
    elsif beanShortName = 'WUT' then     
       packageID := WEBUTIL_CORE.WUT_PACKAGE; 
    elsif beanShortName = 'WUF' then 
       packageID := WEBUTIL_CORE.WUF_PACKAGE; 
    elsif beanShortName = 'WUI' then
        packageID := WEBUTIL_CORE.WUI_PACKAGE; 
    elsif beanShortName = 'WUH' then            
       packageID := WEBUTIL_CORE.WUH_PACKAGE;
    elsif beanShortName = 'WUS' then     
       packageID := WEBUTIL_CORE.WUS_PACKAGE;
    elsif beanShortName = 'WUB' then 
       packageID := WEBUTIL_CORE.WUB_PACKAGE;
    elsif beanShortName = 'WUO' then     
       packageID := WEBUTIL_CORE.WUO_PACKAGE;
    elsif beanShortName = 'WUU' then     
       packageID := WEBUTIL_CORE.WUU_PACKAGE;
    elsif beanShortName = 'WUL' then     
       packageID := WEBUTIL_CORE.WUL_PACKAGE;           
    end if;
    -- For the very first bean we can get a bit of useful information
    -- Only do this once
    if m_clientIP is null then 
      checkUserLibs := true;
      -- Format of the clientinfo packet is
      -- BeanName|IP|OSName|UserName|pathSep|filesep
      m_clientIP       := DelimStr.getString(clientInfo,2,true,'|');
      m_clientOS       := DelimStr.getString(clientInfo,3,true,'|');
      m_clientOSFamily := getOSFamily(m_clientOS);
      clientOSArch     := DelimStr.getString(clientInfo,4,true,'|');
      if instr(clientOSArch, '64') > 0 then
        m_clientOSArch := 1;
      end if;
      m_clientUserName := DelimStr.getString(clientInfo,5,true,'|');      
      m_clientPathSep  := DelimStr.getString(clientInfo,6,true,'|');
      m_clientFileSep  := DelimStr.getString(clientInfo,7,true,'|');
      m_clientLangCode := DelimStr.getString(clientInfo,8,true,'|'); 
    end if;
      
    -- I'd only expect one instance of each bean per form
    -- but just in case we only register the first 
    -- so if multiple copies are used - e.g. it's 
    -- placed in a multi-row block we just use the 
    -- first instance.
    if not m_registeredPackages.EXISTS(packageID) then 
      m_registeredPackages(packageID) := name_in('SYSTEM.TRIGGER_ITEM');
      -- make sure all the required libraries are available
      -- on the client
      newPackage := true;
    end if;
      
    if checkUserLibs then
      -- checkUserLibs would be true if clientIP was null
      -- We can do whatever we want to do but not more than once
      REDOWNLOAD_SYSLIB := FALSE;
      -- We need to get the server host name using available built-ins. This looks lame,
      -- but it should work
      TOOL_ENV.GETVAR('COMPUTERNAME', serverHost);
      if serverHost is null then
        TOOL_ENV.GETVAR('HOST', serverHost);
      end if;
      clientLibDir := readFromPropertyBundle('install.syslib.location.client.'||to_char(m_clientOSFamily) ||
                                             '.' || to_char(m_clientOSArch));
      if clientLibDir is null then
        clientLibDir := readFromPropertyBundle('install.syslib.location.client.'||to_char(m_clientOSFamily));
      end if;
      if clientLibDir is null then
        -- client location when syslib download is not defined in webutil.cfg
        -- will be to client JRE. Send nothing and client will handle
        WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SYSLIB_DIR',
                                 ':' || serverHost || ':' || GET_APPLICATION_PROPERTY(CONFIG),
                                 true);
      else
        -- webutil.cfg contains a specific client directory for syslib download
        -- Replace $(SERVERHOST), if exists, with server host name
        clientLibDir := replace(clientLibDir, '$(SERVERHOST)', serverHost);

        -- The following line makes a few things happen on client including
        -- client directory creation, when clientLibDir is not null
        WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SYSLIB_DIR',
                                 clientLibDir || ':' || serverHost || ':' || GET_APPLICATION_PROPERTY(CONFIG),
                                 true);
        clientLibDirOld := GetClientSetting('install.syslib.dir');

        if clientLibDirOld <> clientLibDir then
    	  SetClientSetting('install.syslib.dir', clientLibDir);
          REDOWNLOAD_SYSLIB := TRUE;
    	end if;
      end if;
      Webutil_Core.WEBUTIL_VERSION := getProperty(WUC_PACKAGE,'WUC_BEAN_VERSION');
      -- We want to write the connection record if it's required.
      -- Any call to ReadFromPropertyBundle or log should be preferably made after
      -- registering at least one bean. That is the reason why the following log
      -- comes after m_registeredPackages(packageID) := name_in('SYSTEM.TRIGGER_ITEM'); above
      if lower(ReadFromPropertyBundle('logging.connections')) = 'true' then 
        log('Connection from Form='||GET_APPLICATION_PROPERTY(CURRENT_FORM)||' Client O/S='||m_clientOS||' locale='||m_clientLangCode,false);
      end if;
    end if;
    if newPackage then  
            checkLibs(to_char(packageID));
    end if;

    if checkUserLibs then
      -- Call a dummy log to initialize m_loggingAllowed and m_loggingErrorsOnly
      log(null,false);
    end if;

    -- 5950737 - Introduce new configuration variable BlockAllowHeartBeat. 
    -- Valid values are true, yes and 1.
    -- If this is set then send a message to the client to behave accordingly.    
    blockAllowHeartBeat := lower(ReadFromPropertyBundle('BlockAllowHeartBeat'));
    if blockAllowHeartBeat = 'true' or blockAllowHeartBeat = 'yes' or blockAllowHeartBeat = '1' then 
      WebUtil_Core.setProperty(packageID,'WUC_BLOCK_ALLOW_HEART_BEAT','1',true);
    else
      WebUtil_Core.setProperty(packageID,'WUC_BLOCK_ALLOW_HEART_BEAT','0',true);
    end if;

    -- Send server logging options to client bean so that the bean does not have
    -- to send message to server unnecessarily.
    if m_loggingAllowed and m_loggingErrorsOnly then
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','1',true);
    elsif m_loggingAllowed then
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','2',true);
    else
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','0',true);
    end if;
      
    -- 2836929 - move the user library check after the first package is registered 
    -- so that a handler bean exists to do the download.     
    if checkUserLibs then 
      --Check for and download any user libs
      checkLibs('user');  
    end if;     
  end registerBean;
```

#### SP-049 - WEBUTIL.REGISTER_FUNCTION

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a named function from a specified library with the WebUtil bean layer, returning a FunctionHandle that uniquely identifies the registered function for subsequent invocation. The procedure communicates the library and function specification to the WebUtil core component, retrieves the resulting handle token, and tracks the total count of successfully registered function handles within the session.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| libName | VARCHAR2 | IN |
| funcName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-037](#SP-037--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the library name (libName) and function name (funcName) as input parameters.
- Step 2 - Concatenate libName and funcName with a pipe delimiter ('|') and submit the combined specification to the WebUtil core layer by calling WebUtil_Core.setProperty for the WUL_FUNCTION_SPEC property on the WUL_PACKAGE component.
- Step 3 - Retrieve the string representation of the function handle by calling WebUtil_Core.getProperty for the WUL_REGISTER_FUNCTION property on the WUL_PACKAGE component; store the result in the local variable strHnd.
- Step 4 - Convert strHnd to a numeric value using TO_NUMBER and assign it to the hnd field of the local FunctionHandle variable funcHnd.
- Step 5 - Evaluate the validity of funcHnd by calling ID_NULL (SP-037). If the handle is NOT null (i.e., registration succeeded), increment the session-level function handle counter m_funcHandleCount by 1.
- Step 6 - Return funcHnd to the caller.
- Step 7 - If a BEAN_NOT_REGISTERED exception is raised, display an error alert identifying the missing bean class and raise FORM_TRIGGER_FAILURE to halt processing.
- Step 8 - If a PROPERTY_ERROR exception is raised, raise FORM_TRIGGER_FAILURE to halt processing.
- Step 9 - If a VALUE_ERROR exception is raised (e.g., TO_NUMBER conversion failure), raise TOOL_ERR.TOOL_ERROR.

---
**Decision Points**

DP-001

Condition: ID_NULL(funcHnd) evaluates to FALSE (i.e., the handle returned by the WebUtil core is not null/invalid).

TRUE: The session-level counter m_funcHandleCount is incremented by 1, recording that a valid function handle was successfully registered.

FALSE: The counter is not incremented; funcHnd is still returned to the caller but is treated as an invalid/unregistered handle.

---

DP-002

Condition: WebUtil_Core raises BEAN_NOT_REGISTERED during the setProperty or getProperty calls.

TRUE: An error alert is displayed identifying the missing bean class (retrieved via WebUtil_Core.getImplClass), and FORM_TRIGGER_FAILURE is raised to abort the current form trigger.

FALSE: Processing continues normally to the getProperty step.

---

DP-003

Condition: WebUtil_Core raises PROPERTY_ERROR during the setProperty or getProperty calls.

TRUE: FORM_TRIGGER_FAILURE is raised to abort the current form trigger without additional messaging.

FALSE: Processing continues normally.

---

DP-004

Condition: A VALUE_ERROR is raised during TO_NUMBER conversion of the string handle.

TRUE: TOOL_ERR.TOOL_ERROR is raised, signalling a data conversion failure to the calling environment.

FALSE: Conversion succeeds and the numeric handle is stored in funcHnd.hnd.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function specification submitted to the WebUtil core must be formatted as a pipe-delimited string combining the library name and function name (libName || '|' || funcName); neither component may be omitted.
- BR-002 - A function handle is only counted as successfully registered (m_funcHandleCount incremented) when ID_NULL returns FALSE for the retrieved handle, ensuring invalid or unresolved handles are not tallied.
- BR-003 - If the required WebUtil bean is not registered in the runtime environment, the procedure must not silently fail; it must alert the user with the missing bean class name and raise FORM_TRIGGER_FAILURE.
- BR-004 - A PROPERTY_ERROR from the WebUtil core layer must immediately abort form trigger execution via FORM_TRIGGER_FAILURE, preventing use of an unreliable handle.
- BR-005 - A VALUE_ERROR during handle conversion must be surfaced as TOOL_ERR.TOOL_ERROR, distinguishing a data integrity failure from a form trigger abort.

---
**Implementation Logic**

```plsql

  FUNCTION REGISTER_FUNCTION (libName IN VARCHAR2, funcName IN VARCHAR2) 
                              RETURN FunctionHandle IS
    strHnd  VARCHAR2(8);                            
    funcHnd FunctionHandle;
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUL_PACKAGE,'WUL_FUNCTION_SPEC', libName || '|' || funcName);
    strHnd := WebUtil_Core.getProperty(WebUtil_Core.WUL_PACKAGE,'WUL_REGISTER_FUNCTION');
    funcHnd.hnd := TO_NUMBER (strHnd);
    if NOT ID_NULL(funcHnd) then
      m_funcHandleCount := m_funcHandleCount + 1;
    end if;

    RETURN funcHnd;
    
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUL_PACKAGE)
                              ||' bean not found. WEBUTIL_C_API.REGISTER_FUNCTION will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;  
    when VALUE_ERROR then
        RAISE TOOL_ERR.TOOL_ERROR; 
  END REGISTER_FUNCTION;
```

#### SP-050 - WEBUTIL.RELEASE_PROCESS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Releases a previously acquired host process handle by clearing its associated callback trigger and nullifying the handle reference. This ensures that process resources managed by the WebUtil host utility are properly freed after use, preventing stale or orphaned process handles from persisting in the session.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the PROCESS_ID handle (IN OUT) identifying the host process to be released.
- Step 2 - Invoke WebUtil_Core.setProperty to clear the process property on the WUH_PACKAGE bean, passing the current handle value via the WUH_CLEAR_PROC property key.
- Step 3 - Invoke WebUtil_Core.ClearCallbackTrigger with the current handle to deregister any callback trigger associated with the process.
- Step 4 - Set process.handle to NULL, marking the PROCESS_ID as released and preventing further use of the stale handle.
- Step 5 - If a BEAN_NOT_REGISTERED exception is raised during any of the above steps, display an error alert identifying the unregistered implementation class and informing the caller that WEBUTIL_HOST.Release_Process will not function.

---
**Decision Points**

DP-001

Condition: A BEAN_NOT_REGISTERED exception is raised when attempting to interact with the WUH_PACKAGE bean via WebUtil_Core.

TRUE: WebUtil_Core.ErrorAlert is called, displaying the implementation class name obtained from WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE) concatenated with a message stating the bean was not found and that WEBUTIL_HOST.Release_Process will not work. The handle is not nullified.

FALSE: The property is cleared, the callback trigger is deregistered, and process.handle is set to NULL successfully.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The process handle must be cleared via WebUtil_Core.setProperty using the WUH_CLEAR_PROC property key before the handle reference is nullified, ensuring the WebUtil bean layer is notified of the release prior to the client-side reference being discarded.
- BR-002 - The callback trigger associated with the process handle must be explicitly deregistered via WebUtil_Core.ClearCallbackTrigger as part of the release sequence; it is not automatically removed when the handle is nullified.
- BR-003 - Upon successful completion, process.handle must be set to NULL, rendering the PROCESS_ID invalid for any subsequent operations and preventing reuse of a released handle.
- BR-004 - If the underlying WebUtil bean is not registered, the procedure must raise a user-facing error alert and must not silently suppress the failure; the caller is informed that the release operation will not work in this state.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Release_Process(process in out PROCESS_ID) is  
  begin
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_CLEAR_PROC',process.handle);
    WebUtil_Core.ClearCallbackTrigger(process.handle);
    process.handle := null;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.Release_Process will not work');
  end Release_Process;
```

#### SP-051 - WEBUTIL.SETCLIENTSETTING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Transmits a named client-side configuration property and its value to the WebUtil Core bean running on the client machine. The procedure serialises the name/value pair and delegates to WebUtil_Core.setProperty, allowing the Oracle Forms session to push local runtime settings to the WebUtil infrastructure without direct database interaction.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyName | VARCHAR2 | IN |
| propertyValue | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the client setting name (propertyName) and its intended value (propertyValue) as input parameters.
- Step 2 - Evaluate whether propertyName is non-null; if it is null, the procedure exits silently without performing any action.
- Step 3 - Concatenate propertyName and propertyValue into a single 'name=value' string and pass it to WebUtil_Core.setProperty, targeting the WUC_PACKAGE package identifier and the WUC_SET_LOCAL_PROPERTY action, to apply the setting on the client.
- Step 4 - If the WebUtil Core bean is not registered on the client (BEAN_NOT_REGISTERED exception), raise an error alert identifying the missing bean class and then raise FORM_TRIGGER_FAILURE to halt further form processing.
- Step 5 - If the property assignment fails within the bean (PROPERTY_ERROR exception), raise FORM_TRIGGER_FAILURE to halt further form processing without displaying an additional alert.

---
**Decision Points**

DP-001

Condition: propertyName IS NOT NULL

TRUE: Concatenate propertyName and propertyValue as 'propertyName=propertyValue' and invoke WebUtil_Core.setProperty to transmit the client setting to the WebUtil Core bean.

FALSE: Skip the setProperty call entirely; the procedure completes without error and without sending any setting to the client.

---

DP-002

Condition: WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during the setProperty call

TRUE: Display an error alert identifying the unregistered bean class (retrieved via WebUtil_Core.getImplClass) and raise FORM_TRIGGER_FAILURE to abort the current form trigger.

FALSE: No BEAN_NOT_REGISTERED exception; continue normal exception-handling flow.

---

DP-003

Condition: WebUtil_Core.PROPERTY_ERROR exception is raised during the setProperty call

TRUE: Raise FORM_TRIGGER_FAILURE immediately to abort the current form trigger without displaying an additional alert.

FALSE: No PROPERTY_ERROR exception; procedure completes successfully.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A client setting is transmitted to the WebUtil Core bean only when propertyName is non-null; a null property name is silently ignored and no property is set.
- BR-002 - The property name and value must be combined into a single 'name=value' string before being passed to WebUtil_Core.setProperty; neither value is sent independently.
- BR-003 - The target package and action for the setProperty call are fixed as WebUtil_Core.WUC_PACKAGE and WUC_SET_LOCAL_PROPERTY respectively; callers cannot redirect the setting to a different bean target.
- BR-004 - If the WebUtil Core bean is not registered on the client at the time of invocation, the form session must be interrupted via FORM_TRIGGER_FAILURE after alerting the user with the missing bean class name.
- BR-005 - A PROPERTY_ERROR returned by the bean constitutes a fatal condition; the procedure must raise FORM_TRIGGER_FAILURE to prevent the form from continuing in an inconsistent state.

---
**Implementation Logic**

```plsql

  PROCEDURE SetClientSetting(propertyName  in VARCHAR2,
                             propertyValue in VARCHAR2) is
  BEGIN
    if propertyName is not null then 
      WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SET_LOCAL_PROPERTY', propertyName||'='||propertyValue);
    end if;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                              ||' bean not found. WEBUTIL_CORE.SetClientSetting will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;       
  END SetClientSetting;
```

#### SP-052 - WEBUTIL.SETDATA

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.SETDATA receives a single chunk of upload data (as a VARCHAR2 string) and writes it to the appropriate destination - either a database BLOB via WebUtil_DB_Local or a server-side file via JAVA_APPSERV_WRITER. It tracks the remaining chunk count and, once all chunks have been received, finalises the transfer by closing the target resource and optionally firing a registered callback trigger. The procedure is invoked by WEBUTIL_CORE.CUSTOMEVENTHANDLER as part of the WebUtil file-upload protocol.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| uploadData | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.CLEARCALLBACKTRIGGER ([SP-014](#SP-014--WEBUTIL.CLEARCALLBACKTRIGGER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.CLOSEBLOB ([SP-015](#SP-015--WEBUTIL.CLOSEBLOB)) - WEBUTIL.pck (or .pld)
- WEBUTIL.CLOSEFILE ([SP-016](#SP-016--WEBUTIL.CLOSEFILE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCALLBACKTRIGGER ([SP-023](#SP-023--WEBUTIL.GETCALLBACKTRIGGER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETLASTERROR ([SP-027](#SP-027--WEBUTIL.GETLASTERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETLASTERRORARGS ([SP-028](#SP-028--WEBUTIL.GETLASTERRORARGS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.WRITEDATA ([SP-055](#SP-055--WEBUTIL.WRITEDATA)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the uploadData VARCHAR2 chunk passed in by WEBUTIL_CORE.CUSTOMEVENTHANDLER.
- Step 2 - Validate that uploadData is not NULL and not an empty string; if it is, set the internal flag m_uploadSucceeded to FALSE and exit - no further processing occurs.
- Step 3 - Determine the write destination by evaluating the module-level flag m_toDB.
- Step 4a (DB path) - If m_toDB is TRUE, call WebUtil_DB_Local.WriteData to append the chunk to the target BLOB.
- Step 4b (File path) - If m_toDB is FALSE, call JAVA_APPSERV_WRITER.WriteData to write the chunk to the server-side file. If the write fails, retrieve the error code via JAVA_APPSERV_WRITER.getLastError and the error arguments via JAVA_APPSERV_WRITER.getLastErrorArgs, log the error through WebUtil_core.Error, and raise the READWRITE_ERROR exception.
- Step 5 - Decrement the module-level chunk counter m_chunks by 1.
- Step 6 - Evaluate whether m_chunks has reached 0 (i.e., all expected chunks have been received).
- Step 7a (Final chunk - DB path) - If m_toDB is TRUE, call WebUtil_DB_Local.CloseBlob passing m_fileSize. If CloseBlob succeeds, set m_uploadSucceeded to TRUE; otherwise retrieve the last error from WebUtil_DB_Local.getLastError and log it via WebUtil_core.Error.
- Step 7b (Final chunk - File path) - If m_toDB is FALSE, call JAVA_APPSERV_WRITER.CloseFile passing m_persistObj and m_fileSize. If CloseFile succeeds, set m_uploadSucceeded to TRUE; otherwise retrieve the error code and arguments, log the error via WebUtil_core.Error, release the Java global reference via ORA_JAVA.DELETE_GLOBAL_REF, and raise READWRITE_ERROR.
- Step 8 - After finalisation, call WEBUTIL.GETCALLBACKTRIGGER with index -1 to check whether a callback trigger has been registered. If one is found, execute it via EXECUTE_TRIGGER.
- Step 9 - Call WEBUTIL.CLEARCALLBACKTRIGGER with index -1 to deregister the callback trigger regardless of whether it was fired.

---
**Decision Points**

DP-001

Condition: uploadData IS NULL OR uploadData = ''

TRUE: Set m_uploadSucceeded to FALSE and exit the procedure immediately; no data is written and no counters are updated.

FALSE: Proceed to write the chunk to the designated destination.

---

DP-002

Condition: m_toDB IS TRUE

TRUE: Write the chunk to the database BLOB using WebUtil_DB_Local.WriteData.

FALSE: Write the chunk to the server-side file using JAVA_APPSERV_WRITER.WriteData.

---

DP-003

Condition: JAVA_APPSERV_WRITER.WriteData returns a failure result (file-path write only)

TRUE: Retrieve last error code and arguments, log the error via WebUtil_core.Error, and raise READWRITE_ERROR.

FALSE: Continue processing; decrement m_chunks.

---

DP-004

Condition: m_chunks = 0 after decrement (all chunks received)

TRUE: Proceed to close the target resource (BLOB or file) and handle post-transfer callback logic.

FALSE: No further action for this invocation; await the next chunk.

---

DP-005

Condition: m_toDB IS TRUE at final-chunk closure

TRUE: Call WebUtil_DB_Local.CloseBlob to finalise the BLOB.

FALSE: Call JAVA_APPSERV_WRITER.CloseFile to finalise the server-side file.

---

DP-006

Condition: WebUtil_DB_Local.CloseBlob succeeds (DB path, final chunk)

TRUE: Set m_uploadSucceeded to TRUE.

FALSE: Retrieve the last error from WebUtil_DB_Local.getLastError and log it via WebUtil_core.Error; m_uploadSucceeded remains FALSE.

---

DP-007

Condition: JAVA_APPSERV_WRITER.CloseFile succeeds (file path, final chunk)

TRUE: Set m_uploadSucceeded to TRUE.

FALSE: Retrieve error code and arguments, log via WebUtil_core.Error, release the Java global reference via ORA_JAVA.DELETE_GLOBAL_REF, and raise READWRITE_ERROR.

---

DP-008

Condition: WEBUTIL.GETCALLBACKTRIGGER(-1) returns a non-NULL trigger name

TRUE: Execute the registered callback trigger via EXECUTE_TRIGGER.

FALSE: Skip trigger execution; proceed directly to WEBUTIL.CLEARCALLBACKTRIGGER.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A NULL or empty uploadData chunk is treated as an error condition; the upload is marked as failed (m_uploadSucceeded = FALSE) and no write operation is attempted.
- BR-002 - Every call to SETDATA must write exactly one chunk; partial or empty submissions are not permitted to advance the chunk counter.
- BR-003 - The write destination (database BLOB vs. server-side file) is determined exclusively by the pre-set module-level flag m_toDB; SETDATA does not alter this routing decision.
- BR-004 - Any write failure on the file path (JAVA_APPSERV_WRITER.WriteData) must be fully logged with both an error code and error arguments before the READWRITE_ERROR exception is raised.
- BR-005 - The chunk counter m_chunks must reach exactly 0 before the target resource is closed; closure is triggered only on receipt of the final expected chunk.
- BR-006 - On successful closure of the final chunk, m_uploadSucceeded must be explicitly set to TRUE; it remains FALSE if closure fails.
- BR-007 - On a file-path closure failure, the Java persistent object reference (m_persistObj) must be released via ORA_JAVA.DELETE_GLOBAL_REF before raising READWRITE_ERROR, preventing resource leaks.
- BR-008 - After all chunks are processed, any registered callback trigger (index -1) must be executed before it is cleared, ensuring post-upload business logic is invoked.
- BR-009 - WEBUTIL.CLEARCALLBACKTRIGGER must always be called after the final chunk is processed, regardless of whether a callback trigger was present, to leave the callback slot in a clean state.

---
**Implementation Logic**

```plsql
   
  PROCEDURE SetData(uploadData in VARCHAR2) is 
    lastErrorCode    PLS_INTEGER;
    lastErrorArgs    VARCHAR2(1000);   
  BEGIN
    if uploadData is null or uploadData = '' then 
      -- error condition!
      m_uploadSucceeded := false;
    else
      -- Write to the correct place    
      if m_toDB then 
        WebUtil_DB_LOCAL.WriteData(uploadData);
      else
        if not JAVA_APPSERV_WRITER.WriteData(m_persistObj,uploadData) then
          lastErrorCode := JAVA_APPSERV_WRITER.getLastError(m_persistObj);
          lastErrorArgs := JAVA_APPSERV_WRITER.getLastErrorArgs(m_persistObj) ;
          WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                             'WEBUTIL_FILE_TRANSFER.SetData',lastErrorArgs);
          raise READWRITE_ERROR;
        end if;
      end if;
      m_chunks := m_chunks - 1;
      if m_chunks = 0 then 
        if m_toDB then 
          if WebUtil_DB_Local.CloseBlob(m_fileSize) then 
            m_uploadSucceeded := true;
          else
            WebUtil_core.Error(Webutil_Core.WUT_PACKAGE, WebUtil_DB_Local.getLastError,
                               'WEBUTIL_FILE_TRANSFER.SetData');
          end if; -- close
        else
          if JAVA_APPSERV_WRITER.CloseFile(m_persistObj,m_fileSize) then
            m_uploadSucceeded := true;
          else
            lastErrorCode := JAVA_APPSERV_WRITER.getLastError(m_persistObj);
            lastErrorArgs := JAVA_APPSERV_WRITER.getLastErrorArgs(m_persistObj) ;
            WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                               'WEBUTIL_FILE_TRANSFER.SetData',lastErrorArgs);
            ORA_JAVA.DELETE_GLOBAL_REF(m_persistObj);
            raise READWRITE_ERROR;
          end if;    
        end if; -- toDB

        if WebUtil_Core.GetCallbackTrigger(-1) is not null then
          EXECUTE_TRIGGER(WebUtil_Core.GetCallbackTrigger(-1));
        end if;
        WebUtil_Core.ClearCallbackTrigger(-1);
      end if; -- chunks
    end if;
  end SetData;
```

#### SP-053 - WEBUTIL.SETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sets the value of a named Java system property via JNI. Accepts a property name and a new value string, and stores the value in the Java runtime environment. Used internally by WebUtil to configure runtime properties for file I/O and other operations. Returns the previous value of the property.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |
| a1 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the property name and new property value as inputs.
- Step 2 - Create a JNI argument list with two arguments and add the property name and value strings as arguments.
- Step 3 - Invoke the Java System.setProperty method via JNI, passing the property name and value.
- Step 4 - Return the previous value of the property as returned by the Java runtime.

---
**Decision Points**

No conditional branches present in the Implementation Logic.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Java system property values can be set at runtime via JNI, allowing WebUtil to configure the Java runtime environment for file I/O and other operations.

---
**Implementation Logic**

```plsql
  FUNCTION setProperty(
    a0    VARCHAR2,
    a1    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(2);
    JNI.ADD_STRING_ARG(args, a0);
    JNI.ADD_STRING_ARG(args, a1);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'setProperty', '(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-054 - WEBUTIL.SHOWBEANS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.INITWEBUTIL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Controls the visibility of the WebUtil hidden window (WEBUTIL_HIDDEN_WINDOW) by either displaying or concealing it based on the supplied boolean flag. When showing the window, the procedure captures the current cursor item so focus can be restored when the window is subsequently hidden. This routine is restricted to NORMAL mode to prevent interference with Enter Query Mode.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| show | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-037](#SP-037--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the boolean parameter 'show', which indicates whether the WebUtil hidden window should be displayed or hidden.
- Step 2 - Check whether the current system mode is 'NORMAL'. If the form is in any other mode (e.g., Enter Query Mode), no further action is taken.
- Step 3 - Locate the WebUtil hidden window using FIND_WINDOW with the constant WEBUTIL_HIDDEN_WINDOW and store the handle in a local variable.
- Step 4 - Evaluate the window handle using WEBUTIL.ID_NULL (SP-037) to confirm the window exists. If the handle is null (window not found), no further action is taken.
- Step 5 - If 'show' is TRUE: capture the current cursor item by calling FIND_ITEM against SYSTEM.CURSOR_ITEM and store it in the module-level variable m_infoFrom; set the window title to 'WebUtil ' concatenated with WEBUTIL_VERSION; call SHOW_WINDOW to display the hidden window; navigate focus to WEBUTIL_DUMMY_ITEM.
- Step 6 - If 'show' is FALSE: check whether the previously stored m_infoFrom item handle is non-null using WEBUTIL.ID_NULL (SP-037); if valid, return focus to that item via GO_ITEM; call HIDE_WINDOW to conceal the WebUtil hidden window.

---
**Decision Points**

DP-001

Condition: SYSTEM.MODE equals 'NORMAL'.

TRUE: Proceed to locate the WebUtil hidden window and evaluate the show/hide logic.

FALSE: Exit the procedure immediately without performing any window operations, preventing interference with Enter Query Mode.

---

DP-002

Condition: The window handle returned by FIND_WINDOW for WEBUTIL_HIDDEN_WINDOW is non-null (evaluated via WEBUTIL.ID_NULL, SP-037).

TRUE: Proceed to show or hide the window based on the 'show' parameter.

FALSE: Exit without performing any window operations, as the target window does not exist.

---

DP-003

Condition: The 'show' parameter is TRUE.

TRUE: Capture the current cursor item into m_infoFrom, set the window title, display the hidden window, and navigate focus to WEBUTIL_DUMMY_ITEM.

FALSE: Proceed to hide the window and attempt to restore focus to the previously captured cursor item.

---

DP-004

Condition: When hiding the window, the stored m_infoFrom item handle is non-null (evaluated via WEBUTIL.ID_NULL, SP-037).

TRUE: Navigate focus back to the item stored in m_infoFrom before hiding the window.

FALSE: Skip the GO_ITEM call and proceed directly to hiding the window.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must not execute any window visibility changes when the form is in Enter Query Mode; all operations are gated on SYSTEM.MODE being 'NORMAL'.
- BR-002 - The WebUtil hidden window must exist (non-null handle as verified by WEBUTIL.ID_NULL) before any show or hide operation is attempted; a missing window is silently ignored.
- BR-003 - When displaying the WebUtil hidden window, the cursor item active at the time of the call must be captured and stored so that focus can be accurately restored when the window is later hidden.
- BR-004 - The WebUtil hidden window title must be set to 'WebUtil ' concatenated with the WEBUTIL_VERSION constant each time the window is shown, ensuring the version is always visible in the window title bar.
- BR-005 - Focus must be directed to WEBUTIL_DUMMY_ITEM immediately after the hidden window is shown, ensuring the form's focus model remains consistent while the WebUtil window is active.
- BR-006 - Focus restoration to the originating item (m_infoFrom) is conditional; if the stored item handle is null, focus restoration is skipped and the window is hidden without a GO_ITEM call.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ShowBeans(show BOOLEAN) is
    hWin WINDOW := FIND_WINDOW(WEBUTIL_HIDDEN_WINDOW);
  begin
    -- Bug 2955789 - don't attempt to do this when in Enter Query Mode
    if name_in('SYSTEM.MODE') = 'NORMAL' then 
      if not ID_NULL(hWin) then 
        if show then 
          m_infoFrom := FIND_ITEM(name_in('SYSTEM.CURSOR_ITEM'));
          SET_WINDOW_PROPERTY(hWin,TITLE,'WebUtil '||WEBUTIL_VERSION);
          SHOW_WINDOW(hWin);
          go_item(WEBUTIL_DUMMY_ITEM);
        else
          if not id_null(m_infoFrom) then 
              go_item(m_infoFrom);
          end if;
          HIDE_WINDOW(hWin);
        end if;
      end if;
    end if;
  end ShowBeans;
```

#### SP-055 - WEBUTIL.WRITEDATA

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Passes a string data payload to the AppServerFileWriter Java class on the application server by invoking its WriteData method via the JNI bridge. The function returns a Boolean indicating whether the write operation succeeded, and is called by WEBUTIL.SETDATA to physically write data to a server-side file during a file-transfer operation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java object reference (obj) representing an active AppServerFileWriter instance and the string data payload (a0) to be written.
- Step 2 - Create a JNI argument list sized for one argument by calling JNI.CREATE_ARG_LIST(1).
- Step 3 - Add the string data payload (a0) to the argument list by calling JNI.ADD_STRING_ARG(args, a0).
- Step 4 - Invoke the Java method WriteData on the AppServerFileWriter class via JNI.CALL_BOOLEAN_METHOD, passing the object reference, the fully-qualified class path, the method name, the method signature, and the populated argument list.
- Step 5 - Return the Boolean result produced by the Java method to the caller, indicating success (TRUE) or failure (FALSE) of the write operation.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function delegates all branching to the underlying JNI.CALL_BOOLEAN_METHOD call and returns its Boolean result directly to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The data payload (a0) must be provided as a VARCHAR2 string; it is added to the JNI argument list as a String type matching the Java method signature '(Ljava/lang/String;)Z'.
- BR-002 - The Java object reference (obj) must represent a valid, already-instantiated AppServerFileWriter instance on the application server; the function does not create or validate the object itself.
- BR-003 - The function returns FALSE as the default fallback value to JNI.CALL_BOOLEAN_METHOD, ensuring a safe Boolean result is returned even if the JNI invocation cannot determine a return value.
- BR-004 - This function must only be called from within the WEBUTIL package context (specifically WEBUTIL.SETDATA), as it relies on the package-level variable 'args' for the JNI argument list.

---
**Implementation Logic**

```plsql
  FUNCTION WriteData(
    obj   ORA_JAVA.JOBJECT,
    a0    VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_BOOLEAN_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileWriter', 'WriteData', '(Ljava/lang/String;)Z', args); 
  END;
```

#### SP-056 - WEBUTIL_CORE.CUSTOMEVENTHANDLER

**Invoked From:**

- vr_bshop_tech_prod_fmb.xml [Trigger: WHEN-CUSTOM-ITEM-EVENT]

---

**Screen:**

N/A

---

**Purpose**

CustomEventHandler is the central dispatcher for custom item events raised by the WebUtil client-side bean. It receives an event name and its associated parameter string, extracts the data payload and multipart chunking metadata, and routes control to the appropriate WebUtil service routine (logging, error reporting, bean registration, host-command callback execution, or file-transfer data staging) based on the event name. Only the five recognised WebUtil event types are processed; all others are silently discarded.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| EventName | VARCHAR2 | IN |
| EventParameters | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERROR ([SP-018](#SP-018--WEBUTIL.ERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETNUMBER ([SP-029](#SP-029--WEBUTIL.GETNUMBER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-043](#SP-043--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.REGISTERBEAN ([SP-048](#SP-048--WEBUTIL.REGISTERBEAN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETDATA ([SP-052](#SP-052--WEBUTIL.SETDATA)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETPROPERTY ([SP-053](#SP-053--WEBUTIL.SETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Validate the incoming EventName against the five permitted WebUtil event identifiers: WUC_LOG_EVENT, WUC_ERROR_EVENT, WUC_REGISTER, WUH_CALLBACK_EVENT, and WUT_TRANSFER_EVENT. If the name is not in this list, raise the internal 'unhandled' exception, which is caught and suppressed, terminating processing with no action.
- Step 2 - Extract the data payload string from EventParameters by calling the internal helper get_parameter_attr for the attribute key 'WUC_DATA', storing the result in dataPayload.
- Step 3 - Extract the multipart descriptor string from EventParameters by calling get_parameter_attr for the attribute key 'WUC_DATA_MULTIPART', storing the result in dataMultiPart.
- Step 4 - Parse dataMultiPart using DelimStr.getNumber to derive the current chunk sequence number (chunkNumber, position 1) and the total number of chunks that constitute the complete payload (PayloadChunks, position 2), using '/' as the delimiter.
- Step 5 - Route to the appropriate handler based on EventName:
  - WUC_LOG_EVENT: call WEBUTIL.LOG (WebUtil_Core.log) with dataPayload and severity flag FALSE to write an informational log entry.
  - WUC_ERROR_EVENT: call WEBUTIL.LOG (WebUtil_Core.log) with dataPayload and severity flag TRUE to write an error log entry.
  - WUC_REGISTER: call WEBUTIL.REGISTERBEAN (registerBean) with dataPayload to register the client-side bean.
  - WUH_CALLBACK_EVENT: convert dataPayload to a number and store it in the package-level variable m_lastCallback. If conversion fails (INVALID_NUMBER), call WEBUTIL.ERROR to record error code 408 attributed to WEBUTIL_CORE.CustomEventHandler. If m_lastCallback resolves to a valid value, execute the corresponding callback trigger via EXECUTE_TRIGGER using the m_callbacks collection; otherwise call WEBUTIL.LOG to record that no callback trigger was specified.
  - WUT_TRANSFER_EVENT: call WEBUTIL.SETDATA (WebUtil_File_Transfer.setData) with dataPayload to stage the transferred file data, then call WEBUTIL.SETPROPERTY (WebUtil_Core.setProperty) to mark the WUT_TRANSFER_EVENT property as 'RECEIVED' on the WUT_PACKAGE component.
- Step 6 - Any exception other than the internal 'unhandled' exception is re-raised to the caller unchanged.

---
**Decision Points**

DP-001
Condition: EventName is contained in the set ('WUC_LOG_EVENT', 'WUC_ERROR_EVENT', 'WUC_REGISTER', 'WUH_CALLBACK_EVENT', 'WUT_TRANSFER_EVENT').
TRUE: Continue processing - extract payload and multipart metadata, then route to the appropriate handler.
FALSE: Raise the internal 'unhandled' exception; the exception handler catches it and returns silently with no further action.

DP-002
Condition: EventName = 'WUC_LOG_EVENT'.
TRUE: Call WEBUTIL.LOG with dataPayload and severity flag FALSE (informational).
FALSE: Evaluate subsequent event-name conditions.

DP-003
Condition: EventName = 'WUC_ERROR_EVENT'.
TRUE: Call WEBUTIL.LOG with dataPayload and severity flag TRUE (error).
FALSE: Evaluate subsequent event-name conditions.

DP-004
Condition: EventName = 'WUC_REGISTER'.
TRUE: Call WEBUTIL.REGISTERBEAN with dataPayload.
FALSE: Evaluate subsequent event-name conditions.

DP-005
Condition: EventName = 'WUH_CALLBACK_EVENT'.
TRUE: Attempt to convert dataPayload to a number and store in m_lastCallback; evaluate DP-006 and DP-007.
FALSE: Evaluate the WUT_TRANSFER_EVENT condition.

DP-006
Condition: Conversion of dataPayload to NUMBER succeeds (no INVALID_NUMBER exception).
TRUE: Store the numeric value in m_lastCallback and proceed to DP-007.
FALSE: Call WEBUTIL.ERROR with error code 408 and context 'WEBUTIL_CORE.CustomEventHandler'; m_lastCallback remains unset.

DP-007
Condition: m_lastCallback IS NOT NULL after the conversion attempt.
TRUE: Execute the trigger identified by m_callbacks(m_lastCallback) via EXECUTE_TRIGGER.
FALSE: Call WEBUTIL.LOG to record that the callback trigger for the host command was not specified.

DP-008
Condition: EventName = 'WUT_TRANSFER_EVENT'.
TRUE: Call WEBUTIL.SETDATA with dataPayload, then call WEBUTIL.SETPROPERTY to set the WUT_TRANSFER_EVENT property to 'RECEIVED'.
FALSE: No further routing; end of event-dispatch block.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only the five predefined WebUtil event names (WUC_LOG_EVENT, WUC_ERROR_EVENT, WUC_REGISTER, WUH_CALLBACK_EVENT, WUT_TRANSFER_EVENT) are valid inputs; any other event name is silently ignored and no processing occurs, preventing unrecognised client events from causing errors.
- BR-002 - The data payload and multipart chunk metadata must always be extracted from EventParameters before event-specific routing is attempted, regardless of which event type is being handled.
- BR-003 - For WUH_CALLBACK_EVENT, the dataPayload must be convertible to a valid number representing a callback index; if conversion fails, error code 408 is recorded via WEBUTIL.ERROR and no callback trigger is executed.
- BR-004 - A WUH_CALLBACK_EVENT with a NULL or unconvertible callback index must not silently succeed; the absence of a valid callback is logged as an error via WEBUTIL.LOG.
- BR-005 - For WUT_TRANSFER_EVENT, the file-transfer data must be staged via WEBUTIL.SETDATA before the transfer status property is updated to 'RECEIVED' via WEBUTIL.SETPROPERTY; the property update confirms end-to-end receipt.
- BR-006 - Exceptions other than the internally handled 'unhandled' event type are propagated to the caller unchanged, ensuring that unexpected runtime errors are not masked.

---
**Implementation Logic**

```plsql
  PROCEDURE CustomEventHandler(EventName       in VARCHAR2, 
                               EventParameters in VARCHAR2) is
    dataPayload   VARCHAR2(32767 char);   
    dataMultiPart VARCHAR2(61 char); /* should be enough! */ 
    chunkNumber   PLS_INTEGER;
    PayloadChunks PLS_INTEGER;
    dataType      PLS_INTEGER;
    unhandled     EXCEPTION;
  begin
    --Bug 2839033 - check for valid events only      
    if EventName not in ('WUC_LOG_EVENT',
                         'WUC_ERROR_EVENT', 
                         'WUC_REGISTER',
                         'WUH_CALLBACK_EVENT', 
                         'WUT_TRANSFER_EVENT') then  
      raise unhandled;
    end if;                        

    -- We're pretty much always going to need the data payload and 
    -- number of parts that make up that payload so get it now..
    get_parameter_attr(EventParameters,'WUC_DATA',dataType, dataPayload);
    get_parameter_attr(EventParameters,'WUC_DATA_MULTIPART',dataType, dataMultiPart);      
    -- split the MULTIPART info to work out how many messages from the 
    -- client are required to create the completed payload
    chunkNumber   := DelimStr.getNumber(dataMultiPart,1,true,'/');
    PayloadChunks := DelimStr.getNumber(dataMultiPart,2,true,'/');

    -- Now deal with the specific events that the client may dispatch
    -- This section will have to be extended for each new event that we 
    -- Add in order to hook the handler code for that message to the data 
    -- that is being sent - shame we can't subclass in PL/SQL :-)      
    if EventName = 'WUC_LOG_EVENT' then
        WebUtil_Core.log(dataPayload,false);
    elsif EventName = 'WUC_ERROR_EVENT' then
        WebUtil_Core.log(dataPayload,true);
    elsif EventName = 'WUC_REGISTER' then 
        registerBean(dataPayload);
    elsif EventName = 'WUH_CALLBACK_EVENT' then 
      begin 
        m_lastCallback := to_number(dataPayload);
      exception
          when INVALID_NUMBER then 
            error(WebUtil_Core.WUC_PACKAGE,408,'WEBUTIL_CORE.CustomEventHandler');
      end;
      if m_lastCallback is not null then 
          EXECUTE_TRIGGER(m_callbacks(m_lastCallback));
      else
            log('Callback trigger for host command not specified',true);
      end if;
    elsif EventName = 'WUT_TRANSFER_EVENT' then 
      WebUtil_File_Transfer.setData(dataPayload);
      WebUtil_Core.setProperty(WebUtil_Core.WUT_PACKAGE, 'WUT_TRANSFER_EVENT','RECEIVED');
    end if;
  exception
    when unhandled then
      null;
    when OTHERS then
      raise;
  end CustomEventHandler;
```

#### SP-057 - ADD_ERROR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Records a runtime error condition by setting a global error flag, composing a formatted error stack entry from the calling function name and error text, and forwarding the composed message to the debug logging facility. This procedure provides a centralised error-capture mechanism used by multiple utility procedures within D2kwutil.pld.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| CallingFunction | VARCHAR2 | IN |
| SetErrorText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-061](#SP-061--DEBUGLOG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Receive the name of the calling function (CallingFunction) and the descriptive error text (SetErrorText) as input parameters.
- Step 2 - Set the global flag ERROR_ENCOUNTERED to TRUE to signal that an error condition has been raised.
- Step 3 - Compose the ERROR_STACK value by concatenating CallingFunction, a colon-space separator, and SetErrorText truncated to a maximum of 1,968 characters, preventing value-range overflow on the target variable.
- Step 4 - Invoke DEBUGLOG (SP-061) via Win_API_Debug.DebugLog, passing severity level 99, the literal procedure identifier 'Add_Error', and the composed ERROR_STACK string, so the error is written to the debug log for diagnostic purposes.

---
**Decision Points**

No conditional decision points are present in this procedure. All steps execute unconditionally for every invocation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The ERROR_ENCOUNTERED flag must be set to TRUE whenever ADD_ERROR is called, ensuring that any downstream logic which checks this flag is correctly informed that an error has occurred.
- BR-002 - The error text stored in ERROR_STACK must be prefixed with the calling function name followed by a colon-space separator, providing unambiguous traceability of the error origin.
- BR-003 - The SetErrorText contribution to ERROR_STACK must be truncated to 1,968 characters to prevent value-overflow errors on the ERROR_STACK variable.
- BR-004 - Every error captured by this procedure must be forwarded to DEBUGLOG (SP-061) at severity level 99, guaranteeing that all errors are recorded in the debug log regardless of the calling context.

---
**Implementation Logic**

```plsql

PROCEDURE Add_Error (CallingFunction in VARCHAR2, SetErrorText in VARCHAR2) is
begin 
  -- Just watch for value errors 
  ERROR_ENCOUNTERED  := TRUE;
  ERROR_STACK    := CallingFunction||': '||substr(SetErrorText,1,1968);
  Win_API_Debug.DebugLog(99,'Add_Error',ERROR_STACK);
end Add_Error;
```

#### SP-058 - ADD_EXTERNAL_ERRORS

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Collects and concatenates error messages from the Oracle Forms tool error stack (tool_err) into a single string buffer, which is returned to the caller for consolidated error reporting. If no tool errors are present but a SQL error exists, the current SQLERRM message is captured instead. The function serves as a utility to aggregate external or tool-level errors into one returnable text block.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Declare a counter variable (iCounter) and a varchar2 buffer (vcErrBuff, max 1968 characters) to accumulate error messages.
- Step 2 - Check whether the tool error stack contains one or more errors by evaluating tool_err.nerrors > 0.
- Step 3 - If tool errors exist, iterate through each error on the stack from 1 to tool_err.nerrors.
- Step 4 - For each iteration, append a newline character (CHR(10)) followed by the current tool_err.message to the accumulation buffer (vcErrBuff).
- Step 5 - If appending the message would cause the buffer to exceed its maximum length (VALUE_ERROR exception), exit the loop immediately, discarding any remaining errors that would overflow the buffer.
- Step 6 - After appending each message, call tool_err.pop to remove the processed error from the stack and advance to the next.
- Step 7 - If no tool errors are present but SQLERRM is not null, assign a newline character followed by SQLERRM to vcErrBuff as the sole error message.
- Step 8 - Return vcErrBuff (which may be NULL if no errors were present and SQLERRM was null) to the caller.

---
**Decision Points**

DP-001

Condition: tool_err.nerrors > 0

TRUE: Iterate through the tool error stack, appending each error message to the buffer and popping each entry from the stack.

FALSE: Skip the loop and evaluate the SQLERRM fallback condition (DP-002).

---

DP-002

Condition: SQLERRM is not null (evaluated only when tool_err.nerrors is not > 0)

TRUE: Assign a newline character concatenated with SQLERRM to vcErrBuff as the error message.

FALSE: vcErrBuff remains NULL; the function returns NULL to the caller.

---

DP-003

Condition: VALUE_ERROR exception raised during buffer concatenation inside the loop

TRUE: Exit the iteration loop immediately; the buffer has reached its 1968-character capacity and no further messages are appended.

FALSE: Continue appending messages and popping errors for the remaining iterations.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The error message buffer is capped at 1968 characters (varchar2(1968)); any error messages that would cause the buffer to exceed this limit are silently discarded and processing stops at that point.
- BR-002 - Tool error stack messages take precedence over SQL error messages; SQLERRM is only captured when tool_err.nerrors is zero or less.
- BR-003 - Each error message appended to the buffer is prefixed with a newline character (CHR(10)) to ensure messages are separated when the buffer is displayed or logged by the caller.
- BR-004 - Each tool error is popped from the stack (tool_err.pop) after its message is collected, ensuring the stack is consumed as the function processes it.
- BR-005 - The function returns NULL when no tool errors exist and SQLERRM is null, indicating a clean error state to the caller.

---
**Implementation Logic**

```plsql

FUNCTION Add_External_Errors return varchar2 is
  iCounter   pls_integer;
  vcErrBuff  varchar2(1968);
begin 
  if tool_err.nerrors > 0 then 
    for iCounter in 1..tool_err.nerrors LOOP
      begin 
        vcErrBuff := vcErrBuff||chr(10)||tool_err.message;
      exception
        when VALUE_ERROR then 
          exit; /* String exceeds allowable buffer */
      end;
      tool_err.pop;
    end loop;
  elsif SQLERRM is not null then 
    vcErrBuff := chr(10)||SQLERRM; 
  end if;
  return vcErrBuff;
end Add_External_Errors;
```

#### SP-059 - BOOLTOCHAR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

BOOLTOCHAR is a utility function that converts a PL/SQL BOOLEAN value into its VARCHAR2 string equivalent ('TRUE' or 'FALSE'). It is used internally by GET_ENVIRONMENT_STRING and READ_REGISTRY within D2kwutil.pld to represent boolean results as character strings where a textual representation is required.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| ThisBoolean | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input BOOLEAN value (ThisBoolean) passed by the calling routine.
- Step 2 - Evaluate the BOOLEAN value using a conditional check.
- Step 3 - If the value evaluates to TRUE, return the VARCHAR2 literal 'TRUE' to the caller.
- Step 4 - If the value evaluates to FALSE (or NULL resolves to the ELSE branch), return the VARCHAR2 literal 'FALSE' to the caller.

---
**Decision Points**

DP-001

Condition:
Whether the input parameter ThisBoolean evaluates to TRUE.

TRUE:
The function returns the VARCHAR2 string 'TRUE'.

FALSE:
The function returns the VARCHAR2 string 'FALSE'.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must always return a non-null VARCHAR2 value; every possible BOOLEAN input (TRUE or FALSE) maps to a corresponding string literal, ensuring callers such as GET_ENVIRONMENT_STRING and READ_REGISTRY always receive a printable character result.
- BR-002 - The only valid return values are the exact string literals 'TRUE' and 'FALSE'; no other representations (e.g., '1'/'0', 'Y'/'N') are produced.
- BR-003 - A BOOLEAN input that resolves to the ELSE branch (including a NULL BOOLEAN) will be returned as 'FALSE', as the conditional does not distinguish NULL from FALSE.

---
**Implementation Logic**

```plsql

  
  FUNCTION  BoolToChar(ThisBoolean IN BOOLEAN) return VARCHAR2 is
  begin
  	if ThisBoolean then 
  		RETURN 'TRUE';
  	else
  	    RETURN 'FALSE';
  	end if;
  end BoolToChar;

END;

PACKAGE WIN_API_DIALOG IS

/*-------------------------------------------------------------------------*\
 * WIN_API_DIALOG ->   This package is concerned with Displaying Common
 *      dialogs
 * Contents:
 *    Open_File    -> Open File Dialog
 *    Save_File    -> Save File Dialog
 *    Select_Printer    -> Printer Selection Dialog
 *    Choose_Font       -> Display the Font Selection Dialog
 *    Choose_Color      -> Display the Color Selection Dialog
 * Dependancies:
 *    WIN_API_ENVIRONMENT
 *    WIN_API
 *    WIN_API_DEBUG
\*-------------------------------------------------------------------------*/ 

/*-------------------------------------------------------------------------*\
 * Open_File        -> Displays the standard Open File dialog
 * Arguments: 
 *  Title           -> The Title for the Dialog Box
 *                     (Default -> 'Open File')
 *  StartDirectory  -> Where the dialog should start from
 *                     this should be in the format 'C:\TEMP'
 *                     (Default -> Windows Directory)
 *  FileFilter      ->  Restrict the list of files. The filter string 
 *                      should be in the format:
 *                      '<Description>|<filename>.<Extension>|'
 *                      typically this would be something like
 *                      'All files(*.*)|*.*|' or 'Text files(*.txt)|*.txt|'
 *                      "All Files" is the Default
 *  Modal           ->  Should the dialog be modal with respect to the 
 *                      application? 
 *                      default = TRUE
 *  AdvancedFlags   ->  (See list in WIN_API header) This option allows
 *                      you to change the attributes of the Open File 
 *                      dialog.  Here are some of the Flags that might
 *                      be of interest:
 *                      OFN_HIDEREADONLY  Hides the Read Only check box.
 *                      OFN_NONETWORKBUTTON  Hides the Network Button
 *                      OFN_EXPLORER    Display an Explorer style 
 *                        Dialog rather than the conventional one.
 *                      See your Microsoft docmentation for details on 
 *                      each flag.
 *                      To Set the Advanced_Flags varaible, just add the 
 *                      required flags together.  The default is:
 *                      WIN_API.OFN_PATHMUSTEXIST + WIN_API.OFN_FILEMUSTEXIST +
 *                      WIN_API.OFN_HIDEREADONLY + WIN_API.OFN_NOCHANGEDIR 
 *  RaiseExceptions ->  TRUE of FALSE(Default) If set to true, then if the 
 *                      command is not successful (e.g no filename is  
 *                      returned) then the explicit exception
 *                      NO_DATA_FOUND will be raised.
 *        
 * Returns:
 *  Path and name of the selected file
\*-------------------------------------------------------------------------*/
```

#### SP-060 - CLEAN_ERROR_STACK

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Resets the shared error-tracking state by clearing the error-encountered flag and emptying the error message stack. This procedure is called by GET_ENVIRONMENT_STRING and READ_REGISTRY prior to their own processing so that any error information left from a previous operation does not carry over into the new call.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Set the package-level boolean variable ERROR_ENCOUNTERED to FALSE, indicating that no error is currently active.
- Step 2 - Set the package-level variable ERROR_STACK to NULL, discarding any error messages accumulated from prior processing.

---
**Decision Points**

No conditional decision points exist in this procedure. Both reset operations execute unconditionally on every invocation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - ERROR_ENCOUNTERED must be set to FALSE on every invocation, regardless of its prior value, ensuring callers always start with a clean error state.
- BR-002 - ERROR_STACK must be set to NULL on every invocation, ensuring no residual error messages from a previous operation are visible to the calling routine.
- BR-003 - The procedure accepts no parameters and returns no output; all state changes are applied directly to shared package-level variables.

---
**Implementation Logic**

```plsql

PROCEDURE Clean_Error_Stack is 
begin 
  -- just empty the variables
  ERROR_ENCOUNTERED  := FALSE;
  ERROR_STACK        := NULL;
end Clean_Error_Stack;
```

#### SP-061 - DEBUGLOG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: ADD_ERROR]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: SETDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

DEBUGLOG writes formatted diagnostic messages to either a Windows debug output channel or a flat log file, depending on the current debug configuration. It is a shared utility invoked by multiple D2kwutil procedures to record runtime trace information at a specified severity level, suppressing output when debugging is inactive, paused, or when the requested level exceeds the configured threshold.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugLevel | PLS_INTEGER | IN |
| LoggingCall | VARCHAR2 | IN |
| LogString | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- SETDEBUG ([SP-065](#SP-065--SETDEBUG)) - matched by member name
- WEBUTIL.LENGTH ([SP-042](#SP-042--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)
- WINDEBUG ([SP-068](#SP-068--WINDEBUG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate whether logging should proceed: if the global debug state (iDebugState) is 0 (disabled), or if debugging is paused (bDebugPaused), or if the supplied DebugLevel exceeds the configured threshold (iDebugLevel), exit immediately without writing any output.
- Step 2 - Optionally prepend a timestamp: if the bDebugTimeStamp flag is set, format the current system time as HH24:MI:SS followed by '> ' and store it in vcDateStamp.
- Step 3 - Construct the formatted debug string: prefix the message with the zero-padded debug level in angle brackets, append the optional timestamp, pad the LoggingCall label to 30 characters, then append the LogString truncated so the total does not exceed 2,000 characters.
- Step 4 - Determine the output channel based on iDebugState:
  - Step 4a - If iDebugState = 2 (Windows debugger mode): check whether DEBUG_API_ENABLED is true. If true, call WINDEBUG (win_api_debug.WinDebug) to write the formatted string to the Windows debug output. If false, the API is unavailable; call SETDEBUG to redirect logging to file mode using the current vcDebugFile (defaulting to 'd2kwutil.log'), log a warning message at level 0, recursively call DEBUGLOG to write the original message to the file, and set bDebugType2Required to TRUE to remember that Windows debugger mode was intended.
  - Step 4b - If iDebugState is not 2 (file mode): check whether bDebugType2Required is TRUE and DEBUG_API_ENABLED is now true. If both conditions hold, the Windows debug API has become available again; call SETDEBUG to restore Windows debugger mode, log a restoration message at level 0, reset bDebugType2Required to FALSE, and recursively call DEBUGLOG to write the original message via the debugger. Otherwise, open the log file in append mode using TEXT_IO, write the formatted string, and close the file.
- Step 5 - If any exception occurs during the procedure, suppress the error and set iDebugState to 0 to disable further debug logging, preventing diagnostic code from disrupting the host application.

---
**Decision Points**

DP-001

Condition: iDebugState = 0

TRUE: Logging is disabled globally; the procedure exits without writing any output.

FALSE: Continue to DP-002.

---

DP-002

Condition: bDebugPaused is TRUE

TRUE: Logging is temporarily paused; the procedure exits without writing any output.

FALSE: Continue to DP-003.

---

DP-003

Condition: DebugLevel > iDebugLevel

TRUE: The message's severity level exceeds the configured verbosity threshold; the procedure exits without writing any output.

FALSE: The message qualifies for output; continue to construct and write the log entry.

---

DP-004

Condition: bDebugTimeStamp is TRUE

TRUE: Format the current system time (HH24:MI:SS) and append it to the debug string prefix.

FALSE: No timestamp is included in the formatted string.

---

DP-005

Condition: iDebugState = 2 (Windows debugger output mode)

TRUE: Attempt to write via the Windows debug API (see DP-006).

FALSE: Use file-based logging (see DP-007).

---

DP-006

Condition: DEBUG_API_ENABLED is TRUE (evaluated when iDebugState = 2)

TRUE: Call WINDEBUG to write the formatted string to the Windows debug output channel.

FALSE: The Windows debug API is unavailable; call SETDEBUG to switch to file mode, log a warning, recursively log the original message to the file, and set bDebugType2Required to TRUE.

---

DP-007

Condition: bDebugType2Required is TRUE AND DEBUG_API_ENABLED is TRUE (evaluated when iDebugState ≠ 2)

TRUE: The Windows debug API has become available again; call SETDEBUG to restore Windows debugger mode, log a restoration notice, reset bDebugType2Required to FALSE, and recursively log the original message via the debugger.

FALSE: Write the formatted string to the log file in append mode using TEXT_IO and close the file.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Logging is suppressed entirely when the global debug state is 0; no output is produced regardless of the DebugLevel or message content.
- BR-002 - Logging is suppressed when the debug session is paused (bDebugPaused = TRUE), allowing temporary suspension without fully disabling the debug configuration.
- BR-003 - A message is only written when its DebugLevel is less than or equal to the configured threshold (iDebugLevel), ensuring that high-verbosity trace messages are filtered out at lower debug settings.
- BR-004 - The formatted debug string must not exceed 2,000 characters; LogString is truncated to enforce this limit after the fixed prefix components are assembled.
- BR-005 - When Windows debugger mode (iDebugState = 2) is requested but DEBUG_API_ENABLED is FALSE, the procedure automatically falls back to file-based logging via SETDEBUG, preserving continuity of the debug record without raising an error to the calling procedure.
- BR-006 - The fallback file name defaults to 'd2kwutil.log' when vcDebugFile is null, ensuring a log destination is always available during an API-unavailable fallback.
- BR-007 - Once file-based fallback is active (bDebugType2Required = TRUE), the procedure automatically restores Windows debugger mode as soon as DEBUG_API_ENABLED becomes TRUE, maintaining the originally configured debug channel when the API recovers.
- BR-008 - Any unhandled exception raised within DEBUGLOG is silently caught and resolves by setting iDebugState to 0, ensuring that diagnostic instrumentation never propagates errors to the host application.

---
**Implementation Logic**

```plsql
   
PROCEDURE DebugLog (DebugLevel  IN PLS_INTEGER, 
                    LoggingCall IN VARCHAR2, 
                    LogString   IN VARCHAR2) is
 vcDateStamp   VARCHAR2(10);
 vcDebugString VARCHAR2(2000);
 hFile         TEXT_IO.FILE_TYPE;
begin
  if iDebugState = 0 then 
  	NULL;
  elsif bDebugPaused then 
  	NULL;
  elsif DebugLevel > iDebugLevel then 
  	NULL;
  else
  	-- Sort out the Datestamp	
  	if bDebugTimeStamp then 
  		vcDateStamp := to_char(SYSDATE,'HH24:MI:SS')||'> ';
  	end if;
  
  	-- Construct the final String
  	vcDebugString := '<'||lpad(to_char(DebugLevel),2,0)||'> '||vcDateStamp||rpad(LoggingCall||':',30);
    vcDebugString := vcDebugString||substr(LogString,1,(2000-length(vcDebugString)));
  
  	if iDebugState = 2 then
  		if DEBUG_API_ENABLED then 
  	   		win_api_debug.WinDebug(vcDebugString);
  		else
  			-- Can't use API calls if the API functions aren't there
	  		-- So Switch to File Logging to d2kwut$.log
	  		SetDebug(1,nvl(vcDebugFile,'d2kwutil.log'),iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Unable to Log to Debugger Switching to File');
			DebugLog(DebugLevel,LoggingCall,LogString);	  		
	  		bDebugType2Required := TRUE;
	  	end if;
  	else
     	if bDebugType2Required and DEBUG_API_ENABLED then
	     	-- API now Available - Reinstate Debugging to Debugger
	  		SetDebug(2,vcDebugFile,iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Restoring Logging to Debugger');
	  		bDebugType2Required := FALSE;
	  		DebugLog(Debuglevel,LoggingCall,LogString);
	
	  	else
		 	hFile := TEXT_IO.FOPEN(vcDebugFile,'A');
		 	TEXT_IO.PUT_LINE(hFile,vcDebugString);
		 	TEXT_IO.FCLOSE(hFile);
		end if;
  	end if;
  end if;
 exception
  	-- Don't let the debugging cause Problems of it's own
  	when others then 
  		iDebugState := 0;
 end DebugLog;
```

#### SP-062 - GET_ENVIRONMENT_STRING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value of a named operating-system environment variable by delegating to the D2KWUTIL native library call D2KWUTIL_GETDOSENV. The function is invoked by WEBUTIL.GETVAR and returns the resolved variable value as a VARCHAR2 string. If the Win API layer is unavailable, or if the variable cannot be resolved, the function either raises an exception or returns NULL, depending on the caller's preference expressed through the RaiseExceptions flag.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VariableName | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-057](#SP-057--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-058](#SP-058--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-059](#SP-059--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-060](#SP-060--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_GETDOSENV ([SP-004](#SP-004--D2KWUTIL.D2KWUTIL_GETDOSENV)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-061](#SP-061--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-064](#SP-064--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log entry diagnostics: call DEBUGLOG (via Win_api_debug.DebugLog) at trace level 99, recording the input VariableName and the string representation of RaiseExceptions (obtained via BOOLTOCHAR).
- Step 2 - Reset the error stack: call CLEAN_ERROR_STACK to clear any previously accumulated API errors before processing begins.
- Step 3 - Initialise the return code iRC to 0.
- Step 4 - Check API availability: evaluate the WIN_API.API_ENABLED flag to determine whether the native Win API layer is accessible.
- Step 5 - Register the native function: call REGISTER_FUNCTION_CALL to bind the iGetDOSEnv handle to the external function 'd2kwutil_GetDOSEnv', declaring its signature as LONG with parameters *CHAR, *CHAR, LONG.
- Step 6 - Prepare call arguments: wrap VariableName in percent signs (e.g. '%VAR_NAME%') to form vcBuff1, initialise vcBuff2 as a 512-character null-padded output buffer, and set iBuff1 to 512 as the buffer length.
- Step 7 - Invoke the native environment lookup: call D2KWUTIL.D2KWUTIL_GETDOSENV via the registered function handle, passing vcBuff1 (variable name pattern), vcBuff2 (output buffer), and iBuff1 (buffer size); capture the integer return code in iRC.
- Step 8 - Log the result: call DEBUGLOG at trace level 99 to record the returned value length (iRC) and the contents of vcBuff2.
- Step 9 - Evaluate the lookup outcome: if iRC equals 0 or vcBuff2 still equals vcBuff1 (indicating the variable was not resolved), record an error via ADD_ERROR and either raise NO_DATA_FOUND (when RaiseExceptions is TRUE) or return NULL (when RaiseExceptions is FALSE).
- Step 10 - Return the resolved value: if the lookup succeeded, return vcBuff2 containing the environment variable's value.
- Step 11 - Handle NO_DATA_FOUND: re-raise the exception to the caller without additional error logging.
- Step 12 - Handle WIN_API.NOT_AVAILABLE: log an error via ADD_ERROR using the WIN_API.NoAPI message constant, then re-raise the exception.
- Step 13 - Handle all other exceptions: log an error via ADD_ERROR combining the WIN_API.UError prefix with any external error details obtained from ADD_EXTERNAL_ERRORS, then re-raise the exception.

---
**Decision Points**

DP-001

Condition: WIN_API.API_ENABLED is TRUE.

TRUE: Proceed to register the native function handle and invoke D2KWUTIL.D2KWUTIL_GETDOSENV to resolve the environment variable.

FALSE: Raise the WIN_API.NOT_AVAILABLE exception, which is caught by the exception block, logged via ADD_ERROR, and re-raised to the caller.

---

DP-002

Condition: The native call return code iRC equals 0, OR the output buffer vcBuff2 still equals the input pattern vcBuff1 (i.e. the environment variable was not found or not expanded).

TRUE: Record a failure message via ADD_ERROR and branch on the RaiseExceptions flag (see DP-003).

FALSE: Return vcBuff2 as the resolved environment variable value.

---

DP-003

Condition: RaiseExceptions input parameter is TRUE (evaluated only when DP-002 is TRUE).

TRUE: Raise NO_DATA_FOUND to signal the unresolved variable to the caller as an exception.

FALSE: Return NULL silently, allowing the caller to handle the missing value without an exception.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function may only execute the environment variable lookup when the WIN_API layer is enabled (WIN_API.API_ENABLED = TRUE); if the layer is unavailable, the function must raise WIN_API.NOT_AVAILABLE and log the WIN_API.NoAPI message via ADD_ERROR.
- BR-002 - The environment variable name must be wrapped in percent signs before being passed to D2KWUTIL.D2KWUTIL_GETDOSENV (e.g. VariableName 'PATH' becomes '%PATH%'), conforming to the DOS/Windows environment variable expansion convention expected by the native library.
- BR-003 - The output buffer passed to D2KWUTIL.D2KWUTIL_GETDOSENV must be pre-allocated as a 512-character null-padded string; the buffer length constant 512 is also passed as the capacity argument.
- BR-004 - A lookup is considered failed if the native call returns iRC = 0 or if the output buffer value is identical to the percent-wrapped input pattern, indicating no expansion occurred; in either case an error must be registered via ADD_ERROR.
- BR-005 - The caller controls exception propagation behaviour through the RaiseExceptions parameter: when TRUE, a failed lookup raises NO_DATA_FOUND; when FALSE (the default), a failed lookup returns NULL without raising an exception.
- BR-006 - The error stack must be cleared via CLEAN_ERROR_STACK at the start of every invocation to prevent stale errors from prior calls from contaminating the current error context.
- BR-007 - All unexpected exceptions must be logged via ADD_ERROR with the WIN_API.UError prefix concatenated with any additional external error details from ADD_EXTERNAL_ERRORS before being re-raised to the caller.
- BR-008 - Diagnostic trace logging via DEBUGLOG must be performed both on entry (recording VariableName and RaiseExceptions) and after the native call (recording the returned value length and value), supporting runtime debugging at trace level 99.

---
**Implementation Logic**

```plsql

FUNCTION Get_Environment_string (  VariableName      IN  VARCHAR2,
                                   RaiseExceptions   IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  vcBuff2    VARCHAR2(512);
  iBuff1    PLS_INTEGER;
  iRC        PLS_INTEGER;
begin 
  Win_api_debug.DebugLog(99,'Get_Environment_String','Args: VariableName="'||VariableName||'", RaiseExceptions='||win_api_debug.BoolToChar(RaiseExceptions));
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then
    win_api.Register_function_call(iGetDOSEnv,'d2kwutil_GetDOSEnv','LONG','*CHAR,*CHAR,LONG');
    vcBuff1    := '%'||VariableName||'%';
    vcBuff2    := RPAD(' ',512,CHR(0));
    iBuff1    := 512;
    iRC   := d2kwutil_GetDOSEnv(win_api.FunctionHandle(iGetDOSEnv),vcBuff1,vcBuff2,iBuff1);
    Win_api_debug.DebugLog(99,'Get_Environment_String','Result: Value Length='||to_char(iRC)||', Value='||vcBuff2);
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0  or vcBuff2 = vcBuff1 then 
    Win_API.Add_error('Get_Environment_String','Unable to get the value of the variable '||VariableName);
    if RaiseExceptions then
      raise NO_DATA_FOUND;
    else
      return NULL;
    end if;
  else
    return vcBuff2;
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Environment_String',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Environment_String',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Environment_String;
```

#### SP-063 - READ_REGISTRY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

READ_REGISTRY retrieves a named value from the Windows Registry for a given registry path and entry key. It translates a human-readable root hive name (e.g., HKEY_LOCAL_MACHINE) into its numeric constant, delegates the low-level read to the D2KWUTIL native library call D2KWUTIL_GETREGKEY, and returns the retrieved string value. Error handling is configurable: callers may request silent NULL returns on failure or have exceptions raised, making the function suitable for both optional configuration look-ups and mandatory registry reads.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RegPath | VARCHAR2 | IN |
| RegEntry | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-057](#SP-057--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-058](#SP-058--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-059](#SP-059--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-060](#SP-060--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_GETREGKEY ([SP-005](#SP-005--D2KWUTIL.D2KWUTIL_GETREGKEY)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-061](#SP-061--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-064](#SP-064--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log entry diagnostics by calling DEBUGLOG (level 99) recording RegPath, RegEntry, and the string representation of RaiseExceptions (via BOOLTOCHAR).
- Step 2 - Clear any pre-existing error state by calling CLEAN_ERROR_STACK.
- Step 3 - Check whether the WIN_API subsystem is available (API_ENABLED flag). If it is not available, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 4 - Register the external function handle for D2KWUTIL_GETREGKEY by calling REGISTER_FUNCTION_CALL, binding the handle iGetRegKey to the native signature 'INT,*CHAR,*CHAR,*CHAR,INT,INT'.
- Step 5 - Parse the root hive from RegPath by extracting the substring before the first backslash and converting it to upper case.
- Step 6 - Map the root hive string to its numeric constant (iBuff1): HKEY_LOCAL_MACHINE=0, HKEY_CLASSES_ROOT=1, HKEY_CURRENT_USER=2, HKEY_USERS=3, HKEY_CURRENT_CONFIG=4. If the hive is unrecognised, log an error via ADD_ERROR and, if RaiseExceptions is TRUE, raise NO_DATA_FOUND.
- Step 7 - Prepare call parameters: set the sub-path (RegPath after the first backslash), the entry name, a 2000-character null-padded output buffer, and the buffer length (2000).
- Step 8 - Evaluate the COMPAT_EXPAND_REG_VALUES compatibility flag. If expansion is suppressed, set iBuff3=1 and log a diagnostic message via DEBUGLOG; otherwise set iBuff3=0.
- Step 9 - Invoke D2KWUTIL_GETREGKEY with the prepared parameters and capture the integer return code (iRC).
- Step 10 - Log the result (iRC and the retrieved buffer value) via DEBUGLOG.
- Step 11 - Evaluate iRC for error conditions (-1 entry not found, -2 unsupported data type, -3 value exceeds buffer, -4 environment string expansion failure). For each error code, call ADD_ERROR with a descriptive message, then either return NULL or raise the appropriate exception (NO_DATA_FOUND or VALUE_ERROR) depending on RaiseExceptions.
- Step 12 - If iRC indicates success, return the populated output buffer (vcBuff3) as the function result.
- Step 13 - In the exception block, re-raise NO_DATA_FOUND and VALUE_ERROR as-is; for WIN_API.NOT_AVAILABLE, call ADD_ERROR with the NoAPI message then re-raise; for all other exceptions, call ADD_ERROR with the generic error message concatenated with ADD_EXTERNAL_ERRORS output, then re-raise.

---
**Decision Points**

DP-001
Condition: WIN_API.API_ENABLED is TRUE.
TRUE: Proceed with registry read processing (Steps 4-12).
FALSE: Raise WIN_API.NOT_AVAILABLE exception immediately.

DP-002
Condition: The extracted root hive string matches one of the five recognised hive names (HKEY_LOCAL_MACHINE, HKEY_CLASSES_ROOT, HKEY_CURRENT_USER, HKEY_USERS, HKEY_CURRENT_CONFIG).
TRUE: Set the corresponding numeric constant in iBuff1 and continue.
FALSE: Call ADD_ERROR reporting an invalid registry key; if RaiseExceptions is TRUE raise NO_DATA_FOUND, otherwise continue (subsequent call will likely fail).

DP-003
Condition: WIN_API.COMPAT_EXPAND_REG_VALUES is FALSE (expansion suppressed).
TRUE: Set iBuff3=1 (suppress environment variable expansion) and log a compatibility diagnostic via DEBUGLOG.
FALSE: Set iBuff3=0 (allow environment variable expansion).

DP-004
Condition: iRC returned by D2KWUTIL_GETREGKEY equals -1 (entry not found).
TRUE: Call ADD_ERROR; return NULL if RaiseExceptions is FALSE, raise NO_DATA_FOUND if TRUE.
FALSE: Evaluate next error code condition.

DP-005
Condition: iRC equals -2 (unsupported data type).
TRUE: Call ADD_ERROR; return NULL if RaiseExceptions is FALSE, raise NO_DATA_FOUND if TRUE.
FALSE: Evaluate next error code condition.

DP-006
Condition: iRC equals -3 (value exceeds 2000-byte buffer).
TRUE: Call ADD_ERROR; return NULL if RaiseExceptions is FALSE, raise VALUE_ERROR if TRUE.
FALSE: Evaluate next error code condition.

DP-007
Condition: iRC equals -4 (environment string expansion failure).
TRUE: Call ADD_ERROR; return NULL if RaiseExceptions is FALSE, raise NO_DATA_FOUND if TRUE.
FALSE: No error condition; return vcBuff3 to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function only executes when the WIN_API subsystem is enabled; if WIN_API.API_ENABLED is FALSE the function raises WIN_API.NOT_AVAILABLE and does not attempt any registry access.
- BR-002 - The registry root hive must be one of exactly five supported values (HKEY_LOCAL_MACHINE, HKEY_CLASSES_ROOT, HKEY_CURRENT_USER, HKEY_USERS, HKEY_CURRENT_CONFIG); any other value is treated as an invalid key and an error is recorded.
- BR-003 - The maximum supported registry value size is 2000 bytes; values exceeding this length are reported as an error (iRC=-3) and cannot be returned.
- BR-004 - The RaiseExceptions parameter governs error propagation: when FALSE the function returns NULL on all retrieval failures, allowing callers to handle absence gracefully; when TRUE the function raises a PL/SQL exception, enforcing mandatory availability of the registry value.
- BR-005 - Environment variable expansion within registry values is controlled by the WIN_API.COMPAT_EXPAND_REG_VALUES flag; when this flag is FALSE, expansion is suppressed (iBuff3=1) to maintain compatibility with environments where expansion is undesirable.
- BR-006 - All error conditions are recorded via ADD_ERROR before the function either returns NULL or raises an exception, ensuring the error stack is populated for upstream diagnostic use.
- BR-007 - Unhandled exceptions are enriched with ADD_EXTERNAL_ERRORS output before being re-raised, ensuring that any externally sourced error detail is captured in the error stack.

---
**Implementation Logic**

```plsql

FUNCTION Read_Registry (RegPath         IN  VARCHAR2,
                        RegEntry        IN  VARCHAR2, 
                        RaiseExceptions IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  vcBuff2    VARCHAR2(512);
  vcBuff3    VARCHAR2(2000);
  vcBuff4    VARCHAR2(512);
  vcBuff5    VARCHAR2(512);                        
  vcRoot     VARCHAR2(20);
  iBuff1     PLS_INTEGER;
  iBuff2     PLS_INTEGER;
  iBuff3		 PLS_INTEGER;
  iRC        PLS_INTEGER;
begin
  Win_API_Debug.DebugLog(99,'Read_Registry','Args: RegPath="'||RegPath||'", RegEntry="'||RegEntry||'", RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	  
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then 
    win_api.Register_function_call(iGetRegKey,'d2kwutil_GetRegKey','INT','INT,*CHAR,*CHAR,*CHAR,INT,INT');  
    -- Which Root?
    vcRoot  := upper(substr(RegPath,1,instr(RegPath,'\')-1));
    if      vcRoot =  'HKEY_LOCAL_MACHINE' then 
      iBuff1 := 0;
    elsif   vcRoot =  'HKEY_CLASSES_ROOT' then 
      iBuff1 := 1;
    elsif   vcRoot =  'HKEY_CURRENT_USER' then 
      iBuff1 := 2;
    elsif   vcRoot =  'HKEY_USERS' then
      iBuff1 := 3;
    elsif   vcRoot =  'HKEY_CURRENT_CONFIG' then
      iBuff1 := 4;      
    else
      WIN_API.Add_error('Read_Registry','Invalid Registry Key '||RegPath);
      if  RaiseExceptions then
        raise NO_DATA_FOUND;
      end if;  
    end if;

    iBuff2     := 2000; /* Length of buffer */
    vcBuff1    := substr(RegPath,instr(RegPath,'\')+1);
    vcBuff2    := RegEntry;
    vcBuff3    := RPAD(SUBSTR(NVL(vcBuff3,' '),1,2000),2000,CHR(0));
    if not WIN_API.COMPAT_EXPAND_REG_VALUES then 
    	iBuff3 := 1;
    	Win_API_Debug.DebugLog(99,'Read_Registry','Compatibility: Reg Value expansion supressed');	  
    else
    	iBuff3 := 0;
    end if;
    
    iRC        := d2kwutil_GetRegKey(win_api.FunctionHandle(iGetRegKey),iBuff1,vcBuff1,vcBuff2,vcBuff3,iBuff2,iBuff3);
    Win_API_Debug.DebugLog(99,'Read_Registry','Result:  RC='||to_char(iRC)||', vcBuff3="'||vcBuff3||'"');	      
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = -1  then 
    Win_API.Add_error('Read_Registry','Cannot read  entry '||RegPath||'->'||RegEntry);
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;
  elsif iRC = -2 then
    Win_API.Add_error('Read_Registry', RegPath||'->'||RegEntry||' is an unsupported datatype');
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;
  elsif iRC = -3 then
    Win_API.Add_error('Read_Registry',RegPath||'->'||RegEntry||' is longer than '||to_char(iBuff2)||' Bytes');
    if not RaiseExceptions then
      return NULL;
    else 
      raise VALUE_ERROR;
    end if;
  elsif iRC = -4 then
    Win_API.Add_error('Read_Registry', RegPath||'->'||RegEntry||' Failed to expand environment string');
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;    
  end if;
  return vcBuff3;
exception
  when NO_DATA_FOUND then 
    raise;
  when VALUE_ERROR then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Read_Registry',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Read_Registry',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Read_Registry;
```

#### SP-064 - REGISTER_FUNCTION_CALL

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

REGISTER_FUNCTION_CALL ensures that a named DLL function is correctly registered with the Oracle FFI (Foreign Function Interface) layer before it is called. It verifies that the target DLL is loaded, determines whether the function has already been registered under the current DLL load cycle, and-if registration is absent or stale-registers the function handle, its parameter types, and its return type. This procedure is the central gateway used by D2KWUTIL callers (GET_ENVIRONMENT_STRING, READ_REGISTRY, WINDEBUG) to prepare any DLL-based function for safe invocation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| FunctionID | PLS_INTEGER | IN |
| FunctionName | VARCHAR2 | IN |
| FunctionReturn | VARCHAR2 | IN |
| FunctionArgs | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-057](#SP-057--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-058](#SP-058--ADD_EXTERNAL_ERRORS)) - matched by member name
- D2KWUTIL.ATTEMPT_DLL_LOAD ([SP-002](#SP-002--D2KWUTIL.ATTEMPT_DLL_LOAD)) - D2KWUTIL.pck (or .pld)
- D2KWUTIL.TRANSLATETYPE ([SP-006](#SP-006--D2KWUTIL.TRANSLATETYPE)) - D2KWUTIL.pck (or .pld)
- DEBUGLOG ([SP-061](#SP-061--DEBUGLOG)) - matched by member name
- WEBUTIL.LENGTH ([SP-042](#SP-042--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)
- WEBUTIL.REGISTER_FUNCTION ([SP-049](#SP-049--WEBUTIL.REGISTER_FUNCTION)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Attempt to locate the DLL in the FFI library cache by calling ORA_FFI.FIND_LIBRARY using the package-level DLL_NAME constant. If the library is found, execution continues to Step 3.
- Step 2 - If ORA_FFI.FIND_LIBRARY raises an FFI_ERROR (DLL not currently loaded), invoke D2KWUTIL.ATTEMPT_DLL_LOAD passing DLL_Path and DLL_NAME to attempt a fresh load and obtain a DLL handle. If ATTEMPT_DLL_LOAD also raises an FFI_ERROR, set the package flag API_ENABLED to FALSE, call ADD_ERROR with source 'D2KWUTIL' and a message indicating the DLL was not found, and raise NO_DATA_FOUND to abort processing.
- Step 3 - Check whether the function has previously been registered by testing whether FunctionLoad(FunctionId) exists in the associative array and, if it does, whether its stored load-count matches the current DLL_LOAD_COUNT. If either condition fails, proceed with registration (Steps 4-8); otherwise skip to Step 9.
- Step 4 - Register the function with the loaded DLL by calling ORA_FFI.REGISTER_FUNCTION using the current DLL_HANDLE, FunctionName, and the ORA_FFI.C_STD calling convention; store the returned handle in FunctionHandle(FunctionId).
- Step 5 - If FunctionName is not 'd2kwutil_DebugString', call DEBUGLOG (via Win_API_Debug.DebugLog at level 99) to record either an initial registration or a re-registration event, including the function name and current DLL_LOAD_COUNT. Re-registration log entries also include the previously stored load-count for diagnostic traceability.
- Step 6 - Parse the FunctionArgs string by appending a trailing comma delimiter and iterating through comma-separated type tokens. For each token, call D2KWUTIL.TRANSLATETYPE to convert the string type name to its FFI type constant, then call ORA_FFI.REGISTER_PARAMETER to register that parameter against the function handle. Continue until the remaining argument string is NULL, a bare comma, or 'VOID,'.
- Step 7 - After all parameters are registered, evaluate FunctionReturn: if it is not 'VOID' (case-insensitive) and is not NULL, call D2KWUTIL.TRANSLATETYPE on the return type string and register the return type via ORA_FFI.REGISTER_RETURN.
- Step 8 - Record the current DLL_LOAD_COUNT in FunctionLoad(FunctionId) to mark this function as registered under the current DLL load cycle, preventing redundant re-registration on subsequent calls.
- Step 9 - If an ORA_FFI.FFI_ERROR is raised at any point outside the inner DLL-load block, call ADD_ERROR with the FunctionName and a composed error message built from Win_API.UError concatenated with the output of ADD_EXTERNAL_ERRORS, then raise NO_DATA_FOUND to signal failure to the caller.

---
**Decision Points**

DP-001
Condition: ORA_FFI.FIND_LIBRARY succeeds in locating the DLL by DLL_NAME.
TRUE: DLL_HANDLE is set and processing continues to the registration check (DP-002).
FALSE: An FFI_ERROR is raised; D2KWUTIL.ATTEMPT_DLL_LOAD is invoked to reload the DLL (DP-002 sub-path via DP-003).

DP-002
Condition: D2KWUTIL.ATTEMPT_DLL_LOAD successfully loads the DLL when FIND_LIBRARY has failed.
TRUE: DLL_HANDLE is obtained from ATTEMPT_DLL_LOAD and processing continues to the registration check.
FALSE: An FFI_ERROR is raised; API_ENABLED is set to FALSE, ADD_ERROR is called, and NO_DATA_FOUND is raised to abort.

DP-003
Condition: FunctionLoad(FunctionId) does not exist in the associative array, OR FunctionLoad(FunctionId) does not equal the current DLL_LOAD_COUNT.
TRUE: The function is unregistered or stale; full registration (handle, parameters, return type) is performed.
FALSE: The function is already registered under the current DLL load cycle; the registration block is skipped entirely.

DP-004
Condition: FunctionName equals 'd2kwutil_DebugString'.
TRUE: The DEBUGLOG diagnostic call is suppressed to avoid recursive logging.
FALSE: DEBUGLOG is called to record whether this is an initial registration or a re-registration.

DP-005
Condition: FunctionLoad(FunctionId) does not exist in the associative array at the point of logging (within the non-debug-string branch).
TRUE: DEBUGLOG records an 'Initial Reg' message.
FALSE: DEBUGLOG records a 'Re-Registration' message that includes the previously stored load-count.

DP-006
Condition: During argument parsing, the remaining vcArgs string is NULL, equals ',', or equals 'VOID,'.
TRUE: The parameter registration loop exits.
FALSE: The next comma-delimited type token is extracted, translated via D2KWUTIL.TRANSLATETYPE, and registered via ORA_FFI.REGISTER_PARAMETER.

DP-007
Condition: FunctionReturn is not 'VOID' (case-insensitive) AND is not NULL.
TRUE: D2KWUTIL.TRANSLATETYPE is called on FunctionReturn and ORA_FFI.REGISTER_RETURN is called to register the return type.
FALSE: No return type is registered (the function is treated as a void procedure).

DP-008
Condition: An ORA_FFI.FFI_ERROR is raised in the outer exception handler.
TRUE: ADD_ERROR is called with FunctionName and a message composed from Win_API.UError and ADD_EXTERNAL_ERRORS; NO_DATA_FOUND is raised.
FALSE: Normal execution completes without error propagation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The DLL identified by DLL_NAME must be locatable via ORA_FFI.FIND_LIBRARY or recoverable via D2KWUTIL.ATTEMPT_DLL_LOAD before any function registration may proceed; failure to load the DLL disables the API (API_ENABLED = FALSE) and halts execution.
- BR-002 - A function registration is considered valid only if its cached load-count (FunctionLoad(FunctionId)) matches the current DLL_LOAD_COUNT; a mismatch indicates the DLL has been reloaded and mandates full re-registration of the function handle, parameters, and return type.
- BR-003 - Function parameters encoded in FunctionArgs must be supplied as a comma-separated list of type-name strings; each token is individually translated to an FFI type constant via D2KWUTIL.TRANSLATETYPE before being registered. A value of 'VOID' or an empty list signals that the function takes no parameters.
- BR-004 - A return type is registered only when FunctionReturn is non-NULL and not equal to 'VOID' (case-insensitive); void-returning functions must not have a return type registered with the FFI layer.
- BR-005 - Diagnostic logging via DEBUGLOG must not be performed for the internal function 'd2kwutil_DebugString' to prevent recursive log calls.
- BR-006 - On any FFI error that escapes the outer block, the error details must be composed from both the internal error context (Win_API.UError) and any external error information (ADD_EXTERNAL_ERRORS) before being surfaced via ADD_ERROR, and NO_DATA_FOUND must be raised to notify the caller of the failure.
- BR-007 - The FunctionHandle and FunctionLoad associative arrays are keyed by FunctionId (PLS_INTEGER); each distinct function must have a unique FunctionId to ensure correct handle isolation across concurrent registrations.

---
**Implementation Logic**

```plsql

PROCEDURE Register_Function_Call ( FunctionID     in PLS_INTEGER, 
                                   FunctionName   in VARCHAR2,
                                   FunctionReturn in VARCHAR2, 
                                   FunctionArgs   in VARCHAR2) is
  vcArgs  VARCHAR2(200);
  vcFrag  VARCHAR2(10);
  iOffset PLS_INTEGER;   
begin 
   -- See if the DLL has been loaded at all.
   -- if this call to FIND_LIBRARY fails, we'll fall through to the Exception.
   begin
    DLL_HANDLE := ORA_FFI.find_library(DLL_NAME);
  exception
    when ora_ffi.ffi_error then 
      -- Attempt to load the DLL again in a subblock. If this fails
      -- then the API must be disabled and NOT_DATA_FOUND raised
      begin 
          DLL_HANDLE := Attempt_DLL_Load(DLL_Path, DLL_NAME);
      exception
          when ora_ffi.ffi_error then 
            API_ENABLED := FALSE;
              add_error('D2KWUTIL',DLL_NAME||' not found.');
            RAISE NO_DATA_FOUND;
      end;
  end;

  -- now compare the Cached value for this function's loadcount with 
  -- that for the DLL this tells us that the function has either not 
  -- been registered yet, or that the DLL has been reloaded in between 
  -- times.  This would not be healthy so we have to re-register in that case.
  if (not FunctionLoad.exists(FunctionId)) or (FunctionLoad(FunctionId)<> DLL_LOAD_COUNT) then
    -- We need to go through the registration process.      
    -- Register the function with the DLL
    FunctionHandle(FunctionId) := ora_ffi.register_function(Win_API.DLL_HANDLE,FunctionName,ORA_FFI.C_STD);
    if FunctionName <> 'd2kwutil_DebugString' then 
    	if not FunctionLoad.exists(FunctionId) then 
    		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Initial Reg');
    	else
       		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Re-Registration Count = '||to_char(FunctionLoad(FunctionId)));
       	end if;
    end if;
    
    -- Loop through and register the parameters
    vcArgs := FunctionArgs||',';
    while vcArgs is not null and vcArgs <> ',' and vcArgs <> 'VOID,' LOOP
      iOffset := instr(vcArgs,',');
      vcFrag := substr(vcArgs,1,iOffset-1);
      ora_ffi.register_parameter(FunctionHandle(FunctionId),TranslateType(vcFrag));
      if iOffset = length(vcArgs) then
        vcArgs := NULL;
      else
        vcArgs := substr(vcArgs,iOffset+1);
      end if;
    end LOOP;
    
    -- Register the return type IF this is a function
    if upper(FunctionReturn) <> 'VOID' and FunctionReturn is not NULL then 
      ora_ffi.register_return(FunctionHandle(FunctionId),TranslateType(FunctionReturn));
    end if;
    
    -- Now add this Function's Loadcount to the array to prevent un-nessary re-registration
    FunctionLoad(FunctionId) := DLL_LOAD_COUNT;
  end if;
exception
   when ora_ffi.ffi_error then
    Win_API.Add_error(FunctionName, Win_API.UError||WIN_API.Add_External_errors); 
    raise NO_DATA_FOUND;
end Register_Function_Call;
```

#### SP-065 - SETDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Configures the debug logging environment by setting the debug output type (file or screen), the target log file name, the logging verbosity level, and whether log entries should include a timestamp. Once configuration is applied, the procedure activates or deactivates the logging state accordingly and records an initial diagnostic entry via DEBUGLOG.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugType | PLS_INTEGER | IN |
| DebugFile | VARCHAR2 | IN |
| DebugLevel | PLS_INTEGER | IN |
| TimeStamp | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-061](#SP-061--DEBUGLOG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Accept four input parameters: DebugType (output destination), DebugFile (target file name, optional), DebugLevel (verbosity threshold, defaulting to 98), and TimeStamp (flag controlling timestamp inclusion, defaulting to FALSE).
- Step 2 - Assign the TimeStamp parameter value to the package-level variable bDebugTimeStamp.
- Step 3 - Assign the DebugFile parameter value to the package-level variable vcDebugFile.
- Step 4 - Assign the DebugLevel parameter value to the package-level variable iDebugLevel.
- Step 5 - Evaluate DebugType to determine the logging destination and set the debug state accordingly.
- Step 6 - If DebugType equals 1, set iDebugState to 1 (file logging) and invoke DEBUGLOG to record the message 'Logging to File' concatenated with the supplied DebugFile name.
- Step 7 - If DebugType equals 2, set iDebugState to 2 (screen/alternative logging) and invoke DEBUGLOG to record the message 'Logging Started'.
- Step 8 - For any other DebugType value, invoke DEBUGLOG to record the message 'Logging Stopped' and set iDebugState to 0, disabling logging.

---
**Decision Points**

DP-001

Condition: DebugType = 1

TRUE: Set iDebugState to 1 (file-based logging mode) and call DEBUGLOG to record 'Logging to File' with the supplied DebugFile name.

FALSE: Proceed to evaluate DebugType = 2 (DP-002).

---

DP-002

Condition: DebugType = 2

TRUE: Set iDebugState to 2 (screen/alternative logging mode) and call DEBUGLOG to record 'Logging Started'.

FALSE: Call DEBUGLOG to record 'Logging Stopped' and set iDebugState to 0, disabling all debug logging.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - DebugType must be 1 to enable file-based logging; any value other than 1 or 2 is treated as a request to stop logging entirely.
- BR-002 - DebugType must be 2 to enable screen (or alternative destination) logging.
- BR-003 - When logging is stopped (DebugType is neither 1 nor 2), iDebugState is set to 0 before the procedure exits, ensuring the logging state is explicitly disabled rather than left in an indeterminate condition.
- BR-004 - The DebugLevel parameter defaults to 98 if not supplied, establishing a high-verbosity baseline unless the caller explicitly restricts it.
- BR-005 - The TimeStamp parameter defaults to FALSE; timestamp inclusion in log entries must be explicitly requested by the caller.
- BR-006 - An initial diagnostic log entry is always written via DEBUGLOG upon any invocation of SETDEBUG, regardless of whether logging is being enabled or disabled, providing an audit trail of configuration changes.

---
**Implementation Logic**

```plsql

PROCEDURE SetDebug( DebugType   IN PLS_INTEGER, 
                    DebugFile   IN VARCHAR2 DEFAULT NULL, 
                    DebugLevel  IN PLS_INTEGER DEFAULT 98,                        
                    TimeStamp   IN BOOLEAN DEFAULT FALSE) is
begin 
    bDebugTimeStamp := TimeStamp;
    vcDebugFile     := DebugFile;
    iDebugLevel     := DebugLevel;
	if DebugType = 1 then 
		iDebugState := 1;
		DebugLog(0,'SetDebug','Logging to File '||DebugFile);
	elsif DebugType = 2 then
		iDebugState := 2;
		DebugLog(0,'SetDebug','Logging Started');
	else 
        DebugLog(0,'SetDebug','Logging Stopped');
        iDebugState := 0;
	end if;
end SetDebug;
```

#### SP-066 - SF_GET_EMP_NAME

**Invoked From:**

- vr_bshop_tech_prod_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

PARAMETERS (N/A / CN_MAIN)

---

**Purpose**

Resolves a dealership employee code into a full display name by querying the employee master table (GM_EMP) for the employee's first, middle, and last names using the dealer map code and employee code. Concatenates available name parts in order to build a single display string. Returns 'N/A' if no matching employee record is found. The function is invoked during the body shop technician productivity report button-press trigger to supply readable employee names for display.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_dealer_map_cd | NUMBER | IN |
| p_loc_cd | VARCHAR2 | IN |
| p_emp_cd | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the dealer map code, location code, and employee code as input parameters.
- Step 2 - Query GM_EMP to retrieve first_name, middle_name, and last_name for the employee matching the supplied dealer_map_cd and emp_cd. Note: p_loc_cd is accepted as a parameter but is not used as a filter predicate in the query.
- Step 3 - Initialise the display name (lv_desc) with the retrieved first_name value.
- Step 4 - Evaluate whether middle_name is not null. If true and lv_desc already holds a value, append a space and the middle name; if lv_desc is null, assign the middle name as the starting value of lv_desc.
- Step 5 - Evaluate whether last_name is not null. If true and lv_desc already holds a value, append a space and the last name; if lv_desc is null, assign the last name as the starting value of lv_desc.
- Step 6 - Return the assembled display name string.
- Step 7 - If no matching row exists in GM_EMP (NO_DATA_FOUND), return 'N/A' instead of raising an error.

---
**Decision Points**

DP-001

Condition:
The middle_name retrieved from GM_EMP is not null

TRUE:
Check whether lv_desc already contains a value. If so, append a space followed by the middle name; otherwise assign the middle name as the initial value of lv_desc.

FALSE:
Skip middle name processing; lv_desc remains unchanged.

---

DP-002

Condition:
lv_desc is not null at the point of middle name concatenation (nested within DP-001 TRUE branch)

TRUE:
Append ' ' || middle_name to lv_desc.

FALSE:
Assign middle_name directly to lv_desc.

---

DP-003

Condition:
The last_name retrieved from GM_EMP is not null

TRUE:
Check whether lv_desc already contains a value. If so, append a space followed by the last name; otherwise assign the last name as the initial value of lv_desc.

FALSE:
Skip last name processing; lv_desc remains unchanged.

---

DP-004

Condition:
lv_desc is not null at the point of last name concatenation (nested within DP-003 TRUE branch)

TRUE:
Append ' ' || last_name to lv_desc.

FALSE:
Assign last_name directly to lv_desc.

---
**Database Interactions**

- DB-001 - Read GM_EMP - Reads data from GM_EMP for lookup or validation.
**Business Rules**

- BR-001 - The full employee display name is assembled exclusively from the first_name, middle_name, and last_name columns of GM_EMP, with each non-null part appended in order (first, middle, last) and separated by a single space, ensuring a consistent and readable name for the productivity report.
- BR-002 - The lookup is keyed solely on dealer_map_cd and emp_cd; the p_loc_cd input parameter is not applied as a filter against GM_EMP, meaning location code does not restrict the employee record retrieved.
- BR-003 - If no employee record exists in GM_EMP for the given dealer map code and employee code, the function returns the literal string 'N/A' rather than propagating a NO_DATA_FOUND exception, allowing the productivity report to continue processing remaining technicians without interruption.
- BR-004 - Name part concatenation is defensive: if first_name is null but a subsequent name part is present, that subsequent part becomes the starting value of the display name rather than producing a leading-space artefact.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
FUNCTION sf_get_emp_name(p_dealer_map_cd NUMBER, p_loc_cd VARCHAR2, p_emp_cd VARCHAR2)
RETURN VARCHAR2 IS
lv_desc VARCHAR2(100);
m_name VARCHAR2(30);
l_name VARCHAR2(30);
BEGIN
  SELECT first_name, middle_name, last_name INTO lv_desc, m_name, l_name FROM gm_emp
  WHERE dealer_map_cd = p_dealer_map_cd  AND emp_cd = p_emp_cd;
  IF m_name IS NOT NULL THEN
   IF lv_desc IS NOT NULL THEN
      lv_desc := lv_desc || ' ' || m_name;
  ELSE
   lv_desc := m_name;
    END IF;
   END IF;
   IF l_name IS NOT NULL THEN
    IF lv_desc IS NOT NULL THEN
     lv_desc := lv_desc || ' ' || l_name;
    ELSE
     lv_desc := l_name;
    END IF;
   END IF;
   RETURN (lv_desc);
EXCEPTION
   WHEN NO_DATA_FOUND THEN
       RETURN 'N/A';
END;

```

#### SP-067 - STRIPDIRSEP

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sanitises a file-system path string supplied by the caller by removing any semicolon-delimited suffix and any trailing backslash directory separator, returning a clean, single-path value ready for downstream use in DLL load operations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| InPath | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-042](#SP-042--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Initialise a local working copy of the input path (InPath) into a VARCHAR2(500) variable.
- Step 2 - Inspect the working path for the presence of a semicolon character using INSTR.
- Step 3 - If a semicolon is found, truncate the working path to retain only the substring that precedes the first semicolon, discarding everything from the semicolon onward.
- Step 4 - Inspect the last character of the (possibly truncated) working path to determine whether it is a backslash ('\') directory separator.
- Step 5 - If a trailing backslash is present, remove it by taking the substring from position 1 to (length - 1).
- Step 6 - Return the cleaned path string to the caller.

---
**Decision Points**

DP-001

Condition: INSTR(vcPath, ';') > 0 - the path contains one or more semicolon characters.

TRUE: Truncate vcPath to the substring before the first semicolon, effectively discarding any additional path entries or parameters appended after the semicolon.

FALSE: Leave vcPath unchanged and proceed to the trailing-separator check.

---

DP-002

Condition: SUBSTR(vcPath, -1, 1) = '\' - the last character of the (possibly truncated) path is a backslash directory separator.

TRUE: Remove the trailing backslash by reassigning vcPath to SUBSTR(vcPath, 1, LENGTH(vcPath) - 1).

FALSE: Leave vcPath unchanged and return it as-is.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only the portion of the path that precedes the first semicolon is considered a valid path; any semicolon-delimited content (e.g., additional paths or parameters) must be discarded before the path is used.
- BR-002 - A valid path must not carry a trailing backslash directory separator; if one is present it must be stripped before the value is returned.
- BR-003 - The function operates non-destructively on the original input: all modifications are applied to an internal copy, and the original parameter value is never altered.
- BR-004 - The maximum supported path length is 500 characters; input paths exceeding this length will be silently truncated to fit the internal working variable.

---
**Implementation Logic**

```plsql

  

Function StripDirSep ( InPath in varchar2) return varchar2 is 
  vcPath  varchar2(500) := InPath;
begin 
  -- Check and Strip SemiColons, we take everything
  -- Before the first Semicolon as our path
  if instr(vcPath,';') > 0 then
    vcPath := substr(vcPath,1,instr(vcPath,';') -1);
  end if;

  -- Check and Strip '\'
  if substr(vcPath,-1,1) = '\' then 
    vcPath := substr(vcPath,1,length(vcPath)-1);
  end if;

  return vcPath;
end StripDirSep;
```

#### SP-068 - WINDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WINDEBUG provides a debug string output mechanism by delegating to the external D2KWUTIL debug string function via the WIN_API integration layer. It accepts a text string, appends a newline character, registers the required external function call handle, and invokes the D2KWUTIL debug string routine. If the WIN_API layer is unavailable or an unexpected error occurs, the procedure raises a structured error and re-raises the exception to the caller.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-057](#SP-057--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-058](#SP-058--ADD_EXTERNAL_ERRORS)) - matched by member name
- D2KWUTIL.D2KWUTIL_DEBUGSTRING ([SP-003](#SP-003--D2KWUTIL.D2KWUTIL_DEBUGSTRING)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- REGISTER_FUNCTION_CALL ([SP-064](#SP-064--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameter Text (VARCHAR2) and construct an internal buffer (vcBuff1) by appending a newline character (CHR(10)) to the supplied text.
- Step 2 - Check whether the WIN_API integration layer is enabled by evaluating WIN_API.API_ENABLED.
- Step 3 - If the API is enabled, register the external function call for the debug string operation by invoking REGISTER_FUNCTION_CALL, passing the debug string handle (iDebugString), the function name 'd2kwutil_DebugString', NULL, and the data type marker '*CHAR'.
- Step 4 - Invoke D2KWUTIL.D2KWUTIL_DEBUGSTRING, passing the resolved function handle (WIN_API.FunctionHandle(iDebugString)) and the prepared buffer (vcBuff1) to output the debug string via the external utility.
- Step 5 - If the API is not enabled, raise the WIN_API.NOT_AVAILABLE exception.
- Step 6 - In the WIN_API.NOT_AVAILABLE exception handler, call ADD_ERROR with the procedure name 'WinDebug' and the WIN_API.NoAPI error code, then re-raise the exception.
- Step 7 - In the OTHERS exception handler, call ADD_ERROR with the procedure name 'WinDebug' and a composite error message built from WIN_API.UError concatenated with the result of ADD_EXTERNAL_ERRORS, then re-raise the exception.

---
**Decision Points**

DP-001

Condition:
WIN_API.API_ENABLED evaluates to TRUE.

TRUE:
Register the external function call via REGISTER_FUNCTION_CALL and invoke D2KWUTIL.D2KWUTIL_DEBUGSTRING to output the debug string.

FALSE:
Raise the WIN_API.NOT_AVAILABLE exception, which is subsequently caught by the dedicated exception handler.

---

DP-002

Condition:
The WIN_API.NOT_AVAILABLE exception is raised (either directly from the FALSE branch of DP-001 or propagated from the API call).

TRUE:
Call ADD_ERROR with the procedure identifier 'WinDebug' and the WIN_API.NoAPI error code, then re-raise the exception to the caller.

FALSE:
Not applicable; this handler only fires on WIN_API.NOT_AVAILABLE.

---

DP-003

Condition:
An unhandled exception other than WIN_API.NOT_AVAILABLE is raised during execution.

TRUE:
Call ADD_ERROR with the procedure identifier 'WinDebug' and a composite error message formed by concatenating WIN_API.UError with the output of ADD_EXTERNAL_ERRORS, then re-raise the exception to the caller.

FALSE:
No error handling required; normal execution completes without exception.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The input text must be extended with a newline character (CHR(10)) before being passed to the external debug string function; the raw input value is never transmitted directly.
- BR-002 - Debug string output is only permitted when the WIN_API integration layer is active (WIN_API.API_ENABLED = TRUE); any attempt to invoke the debug function while the API is unavailable must result in a WIN_API.NOT_AVAILABLE exception.
- BR-003 - The external function call must be registered via REGISTER_FUNCTION_CALL before D2KWUTIL.D2KWUTIL_DEBUGSTRING is invoked; the resolved function handle obtained from WIN_API.FunctionHandle is used as the execution reference.
- BR-004 - All exceptions must be re-raised to the caller after error recording; WINDEBUG does not suppress exceptions.
- BR-005 - API unavailability errors must be recorded using ADD_ERROR with the WIN_API.NoAPI error code; all other unexpected errors must be recorded using ADD_ERROR with a composite message that includes ADD_EXTERNAL_ERRORS output to capture any externally registered error detail.

---
**Implementation Logic**

```plsql
  

  
PROCEDURE WinDebug  (  Text  IN   VARCHAR2) is
  vcBuff1 VARCHAR2(2000) := Text||chr(10);
begin 
  --WIN_API.Clean_Error_Stack;
  if Win_API.API_ENABLED then
    win_api.Register_function_call(iDebugString,'d2kwutil_DebugString',NULL,'*CHAR');
    d2kwutil_DebugString(win_api.FunctionHandle(iDebugString),vcBuff1);
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if; 
exception
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('WinDebug',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('WinDebug',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end WinDebug;
```

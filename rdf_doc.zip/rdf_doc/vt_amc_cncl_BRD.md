# BUSINESS REQUIREMENTS DOCUMENT

## Table of Contents

- 1. Document Control
  - 1.1 Document Information
  - 1.2 Revision History
- 2. Executive Summary
  - Key Stakeholders
- 3. System Context
- 4. Functional Requirements
  - 4.1 Business Requirements
    - Requirement ID: BR-001
    - Requirement ID: BR-002
    - Requirement ID: BR-003
    - Requirement ID: BR-004
    - Requirement ID: BR-005
    - Requirement ID: BR-006
    - Requirement ID: BR-007
    - Requirement ID: BR-008
    - Requirement ID: BR-009
    - Requirement ID: BR-010
    - Requirement ID: BR-011
    - Requirement ID: BR-012
    - Requirement ID: BR-013
    - Requirement ID: BR-014
- 5. Business Rules Catalogue
- 6. Data Requirements
  - 6.1 Business Entities and Relationships
    - MCP Enrollment - VH_AMC_ENROL
    - MCP Cancellation Charges Detail - VD_AMC_CANCELCHARGES
    - MCP Enrollment Detail - VD_AMC_ENROL
    - Package Detail - GBL_AMC_DTL
    - Package Charge Master - GBL_AMC_CHARGES
    - Vehicle Master - GM_VIN
    - Vehicle Extension - GM_VIN_EXT
    - Entity Relationships
  - 6.2 Data Capture Requirements
    - Search / Contract Identification
    - Cancellation Parameters (entered by advisor)
    - Session / Context (auto-populated from calling application)
  - 6.3 Reference Data
  - 6.4 Data Lifecycle
  - 6.5 Excel Output Columns
- 7. Glossary
- 8. Technical Inventory
  - 8.1 Form Architecture
    - 8.1.1 Global Variables
    - 8.1.2 Form Parameters
  - 8.2 Blocks
    - 8.2.1 Block WhereClause and OrderByClause
  - 8.3 Items Summary
  - 8.4 List of Values
  - 8.5 Alerts
  - 8.6 Program Units
  - 8.7 Triggers
    - 8.7.1 Inactive / Commented-Out Trigger Register
  - 8.8 Canvas and Window Inventory
  - 8.9 Editors
  - 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups
    - 8.10.1 Visual Attributes (form-defined)
    - 8.10.2 Property Classes (form-defined)
    - 8.10.3 Object Groups
  - 8.11 DataSourceColumn Inventory
    - B_VH_AMC_ENQ (35 columns)
- 9. Object Library
- 10. Record Groups
- 11. Referenced Database Objects
  - 11.1 Block-Table Binding Summary
  - 11.2 Referenced Database Objects
- 12. Backend Procedures and Packages
  - 12.1 Main Flow Backend Procedure/Package Index
  - 12.2 Procedure and Package Catalogue
    - GENERAL (Attached Library - DPL)
    - PKG_AMC
    - PKG_LOYALTY
    - PKG_FDI
    - PK_VALIDATE_BACK_DATE
    - SP_PUSH_DMS_MESSAGE
    - SP_PUSH_MCPC_FDI_DATA
    - SP_VALIDATE_ALPHANUMERIC
    - SF_COPYRIGHT_DECLARATION
    - SF_PRINCIPAL_MAP_CD
    - SF_GET_CAR_USER_PHONE
    - SF_GET_MODEL_CHANNEL
    - SF_GET_NEXA_VIN
    - SP_SMS_CMPMGR
    - FNC_VERIF_MOBILE
    - DBMS_APPLICATION_INFO
    - STOP_WATCH
    - WEB (Attached Library)
- 13. Package Procedure Specifications
- 14. Database Package Catalogue
- 15. PLD Procedure Call Sites
  - DPL.pld (`general`)
- 16. Microservice API Candidates
  - 16.1 Microservices with APIs
- 17. Workflows
- 18. PLD-Backed Logic
  - webutil.pld (`CLIENT_IMAGE`)
  - DPL.pld (`general`)
  - D2kwutil.pld (`Win_API`)
- 19. PCK-Backed Logic
- 20. System Interfaces
  - 20.1 Database Integrations
  - 20.2 External System Integrations
  - 20.3 Report Integrations
    - 20.3.1 Parameters Passed to the Report
- 21. Procedure and Function Business Rule Catalogue
  - 21.1 Catalogue Index
  - 21.2 Detailed Specifications
    - SP-001 - CALL_REPORT_ENQ
    - SP-002 - POP_LIST
    - SP-003 - POP_PKG_DETAILS_NEW
    - SP-004 - PROC_AMC_DETAILS
    - SP-005 - SP_INSERT_CHARGES
    - SP-006 - D2KWUTIL.ATTEMPT_DLL_LOAD
    - SP-007 - D2KWUTIL.CREATED_DATE
    - SP-008 - D2KWUTIL.D2KWUTIL_DEBUGSTRING
    - SP-009 - D2KWUTIL.D2KWUTIL_FILEINFO
    - SP-010 - D2KWUTIL.FILE_INFO
    - SP-011 - D2KWUTIL.MODIFIED_DATE
    - SP-012 - D2KWUTIL.TRANSLATETYPE
    - SP-013 - GENERAL.ASK_CONFIRM
    - SP-014 - GENERAL.CHECK_NULL
    - SP-015 - GENERAL.DISP_TEXT
    - SP-016 - GENERAL.PROC_REPORT_CALL
    - SP-017 - GENERAL.PROC_TIMER
    - SP-018 - GENERAL.PROC_TIMER_EXPIRED
    - SP-019 - GENERAL.RAISE_ERROR
    - SP-020 - PKG_AMC.SF_GET_SELL_PRICE
    - SP-021 - PKG_AMC.SP_AMC_AVAIL_QTY
    - SP-022 - PKG_AMC.SP_POP_CANCEL_DTL
    - SP-023 - PKG_FDI.SF_VALID_DEALER
    - SP-024 - PKG_FDI.SP_PUSH_FDI_TRANSACTIONS
    - SP-025 - PKG_LOYALTY.SF_CALCULATE_POINTS_TO_RUPEES
    - SP-026 - PKG_LOYALTY.SF_CALCULATE_RUPEES_TO_POINTS
    - SP-027 - PKG_LOYALTY.SP_CALCULATE_BAL_POINTS
    - SP-028 - PKG_LOYALTY.SP_GET_VIN_LOYALTY_DTL
    - SP-029 - PKG_LOYALTY.SP_INS_LOYALTY_TRANSACTIONS
    - SP-030 - PKG_LOYALTY.SP_RED_RESTRICTION_BAL_POINTS
    - SP-031 - PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM
    - SP-032 - WEBUTIL.ERRORALERT
    - SP-033 - WEBUTIL.FCLOSE
    - SP-034 - WEBUTIL.FOPEN
    - SP-035 - WEBUTIL.GETIMPLCLASS
    - SP-036 - WEBUTIL.GETPROPERTY
    - SP-037 - WEBUTIL.ID_NULL
    - SP-038 - WEBUTIL.LENGTH
    - SP-039 - WEBUTIL.PUT_LINE
    - SP-040 - WEBUTIL.REGISTER_FUNCTION
    - SP-041 - WEBUTIL.SETPROPERTY
    - SP-042 - WEBUTIL.WAIT
    - SP-043 - ADD_ERROR
    - SP-044 - ADD_EXTERNAL_ERRORS
    - SP-045 - BOOLTOCHAR
    - SP-046 - CLEAN_ERROR_STACK
    - SP-047 - DEBUGLOG
    - SP-048 - FNC_VERIF_MOBILE
    - SP-049 - REGISTER_FUNCTION_CALL
    - SP-050 - SETDEBUG
    - SP-051 - SF_COPYRIGHT_DECLARATION
    - SP-052 - SF_GET_CAR_USER_PHONE
    - SP-053 - SF_GET_MODEL_CHANNEL
    - SP-054 - SF_GET_NEXA_VIN
    - SP-055 - SF_PRINCIPAL_MAP_CD
    - SP-056 - SP_PUSH_DMS_MESSAGE
    - SP-057 - SP_PUSH_MCPC_FDI_DATA
    - SP-058 - SP_SMS_CMPMGR
    - SP-059 - SP_VALIDATE_ALPHANUMERIC
    - SP-060 - STRIPDIRSEP
    - SP-061 - WINDEBUG

## 1. Document Control

### 1.1 Document Information

| Field | Value |
| ----- | ----- |
| Document Title | VT_AMC_CNCL - Business Requirements Document |
| Form Module Name | VT_AMC_CNCL |
| Document Version | 1.0 |
| Date Created | August 16, 2026 |
| Author/Prepared By | BRD Agent |

### 1.2 Revision History

| Version | Date | Author | Description |
| --- | --- | --- | --- |
| 1.0 | August 16, 2026 | BRD Agent | Initial draft |

---

## 2. Executive Summary

*High-level overview of the vt_amc_cncl MCP AMC Cancellation form, its purpose, and roles referenced in the module.*

The **vt_amc_cncl** Oracle Forms module is the dealer workshop **MCP (Maintenance Care Plan) AMC Cancellation** screen. A service advisor or dealer back-office user opens the form and searches for an active AMC contract by entering the enrollment number, vehicle registration number, or Vehicle Identification Number. The form automatically loads the full contract details - vehicle information, customer contact details, package breakdown, amounts paid for labour, parts, and consumables, amounts already utilised, and the loyalty card details linked to the vehicle. The user selects an applicable cancellation charge percentage from a pre-configured list, which triggers an immediate recalculation of the refund amounts by service category including applicable tax components. The user then selects a cancellation reason, confirms the intent to cancel, and the form records the cancellation against the contract, inserts the charge and refund lines, updates the vehicle's coverage expiry date, posts a loyalty programme cancellation event, and generates a credit note reference number where required. After a successful cancellation, the form offers the user the option to print or view the AMC cancellation report as a PDF or printed document, then clears the screen ready for the next transaction.

### Key Stakeholders

*Who uses vt_amc_cncl*

| Stakeholder | Role |
| :--- | :--- |
| **Dealer Service Advisor / Back-Office User** | Primary interactive user of vt_amc_cncl. Searches for the AMC contract, reviews contract and customer details, selects the cancellation charge and reason, confirms the cancellation, and prints the cancellation document. |
| **Customer / Vehicle Owner** | Vehicle and contact details are displayed from the enrollment record; the customer does not interact directly with the form. |
| **Loyalty Programme** | Customer loyalty card balance is displayed during the cancellation process; a cancellation transaction is posted to the loyalty account on confirmation. |

---

---

## 3. System Context

*Describes the vt_amc_cncl module's role within the DMS ecosystem, scope, process flow, and key integrations.*

The **vt_amc_cncl** module is the dealer **MCP (Maintenance Care Plan) AMC Cancellation** screen within the Dealer Management System. It is the single point for processing the premature termination of an active AMC contract and connects the dealer service desk with the AMC enrollment data, refund calculation, loyalty programme, document numbering, and downstream DMS integration.

**System purpose:** Locate an active AMC enrollment by enrollment number, registration number, or VIN, display contract and customer details, compute refund amounts after applying a selected cancellation charge percentage, capture the cancellation reason, confirm the cancellation, record the transaction, and optionally generate and print the AMC cancellation report - as implemented in the vt_amc_cncl Oracle Forms module.

**In scope:**

- Search for an active AMC contract by enrollment number, vehicle registration number, or VIN
- Load and display the full contract details including vehicle identity, customer contact information, package breakdown, utilised amounts, and remaining balances
- Retrieve and display the loyalty card details and current point balance associated with the vehicle
- Select an applicable cancellation charge percentage from a pre-configured list and recalculate refund amounts by service category (labour, parts, consumables) with applicable tax components
- Validate that the contract is active, not already cancelled, not expired, and belongs to the current dealer location before proceeding
- Capture a mandatory cancellation reason from a pre-configured list
- Confirm user intent to cancel before any data is written
- Generate a credit note reference number for AMC enrollments dated on or after 01-Jul-2017
- Insert cancellation charge lines, update the AMC enrollment record with cancellation details and refund amounts, and update the vehicle coverage expiry date
- Post a loyalty cancellation transaction against the vehicle's loyalty card
- Push the MCP cancellation event to the DMS integration layer after commit
- Generate and print or view the AMC cancellation report (PDF or printer) after successful cancellation

**Process Name:** MCP AMC Cancellation

**Process Owner:** Dealer Service Manager

**Process Objective:** Locate an active AMC contract, validate eligibility for cancellation, compute the refund after applying the chosen cancellation charges, capture the cancellation reason, confirm the user's intent, and record the complete cancellation transaction including credit note generation, loyalty posting, and DMS notification.

**Process Trigger:** A customer requests cancellation of an active MCP (AMC) contract at the dealer service desk

**Process Flow:**

The complete MCP AMC cancellation process follows this sequence. Each step corresponds to Functional Requirements in Section 4.

```
STEP 1 ── SCREEN OPENS
         Service advisor opens the MCP AMC Cancellation screen.
         The search entry block is presented with three search options: enrollment number,
         registration number, or VIN. All detail fields are blank.

STEP 2 ── SEARCH BY ENROLLMENT NUMBER - when enrollment number is known
         Advisor enters the MCP enrollment number.
         System verifies the enrollment exists, is not already cancelled, is not expired,
         and was originally sold by the current dealer location.
         If any check fails, an error is displayed and the search is rejected.

STEP 3 ── SEARCH BY REGISTRATION NUMBER - when enrollment number is not available
         Advisor enters the vehicle registration number.
         System validates the registration number exists in the vehicle master and finds
         the active, non-cancelled, non-expired AMC enrollment for that vehicle at the
         current dealer group.

STEP 4 ── SEARCH BY VIN - when neither enrollment number nor registration is available
         Advisor enters the Vehicle Identification Number.
         System validates the VIN in the vehicle master and finds the active AMC
         enrollment for that VIN at the current dealer group.

STEP 5 ── CONTRACT DETAILS LOADED
         System retrieves and displays the full AMC contract: principal, enrollment number,
         enrollment date, coverage start and end dates, expiry mileage, vehicle details
         (registration number, VIN, chassis, engine, super-variant, variant), customer
         details (name, address, city, phone, mobile, email), selling dealer details,
         package code and description, package amounts (labour, parts, consumables,
         discount, taxes, total billed), utilised amounts, and remaining balances.

STEP 6 ── LOYALTY DETAILS DISPLAYED
         System retrieves and displays the loyalty card type, card number, registered
         mobile, current point balance, and rupee equivalent linked to the vehicle.
         If no loyalty card is mapped, the loyalty fields remain empty.

STEP 7 ── CANCELLATION CHARGE SELECTION
         Advisor selects the applicable cancellation charge percentage from the drop-down list.
         The list is populated from the pre-configured cancellation charge values for the principal.

STEP 8 ── REFUND AMOUNTS CALCULATED
         System invokes the cancellation refund calculation engine with the selected charge
         percentage. Refund amounts are computed per service type (labour, parts, consumables)
         with tax components (service tax, SBC, KKC / GST) and displayed in the detail fields
         including total cancellation charges, individual refunds, total tax, total refund before
         tax, and net refund amount.

STEP 9 ── CANCELLATION REASON ENTERED
         Advisor selects the cancellation reason from the LOV list.
         System validates that a cancellation reason has been provided.

STEP 10 ── CONFIRMATION PROMPT
          Advisor clicks the Cancel button.
          System validates that both cancellation charges and reason are populated.
          System presents a confirmation dialog: "Do you really want to cancel the MCP?"

STEP 11 ── CANCELLATION CONFIRMED
          ├── CONFIRMED: Advisor confirms the cancellation; processing continues.
          └── CANCELLED: Advisor declines; the form returns to the entry state.

STEP 12 ── CREDIT NOTE NUMBER GENERATED - for contracts enrolled from 01-Jul-2017
          System generates and reserves a sequential credit note reference number
          from the document master for the ACR document type in the current financial year.
          If the document master is missing or locked, the cancellation is rejected with an error.

STEP 13 ── CANCELLATION CHARGES INSERTED
          System inserts the detailed cancellation charge lines from the session-computed
          charge table into the cancellation charges transaction table.

STEP 14 ── AMC ENROLLMENT RECORD UPDATED
          System marks the AMC enrollment as cancelled, records the cancellation date,
          charge percentage, refund amounts by service type, total cancellation amount,
          net refund amount, cancellation reason, and credit note number.

STEP 15 ── VEHICLE COVERAGE EXPIRY UPDATED
          System updates the AMC coverage expiry date on the vehicle extension record
          to the cancellation date.

STEP 16 ── LOYALTY TRANSACTION POSTED
          System posts a loyalty cancellation transaction (type MCPC) against the vehicle's
          loyalty card. Transaction errors are silently suppressed and do not block the commit.

STEP 17 ── TRANSACTION COMMITTED
          System commits the complete cancellation transaction to the database.

STEP 18 ── FDI DATA PUSHED - for the principal mapped to FDI integration
          System posts the MCP cancellation data to the FDI integration service.
          Errors are silently suppressed.

STEP 19 ── DMS NOTIFICATION SENT
          System pushes the MCP cancellation event (SRV_MCPCANCEL) to the DMS
          integration layer with dealer, location, AMC number, and user details.
          Errors are silently suppressed.

STEP 20 ── CANCELLATION REPORT OFFERED
          System presents the AMC cancellation report prompt asking the user whether
          to view as PDF, print, or skip.
          ├── PDF: Report is submitted to the report server and opened in the browser.
          ├── PRINT: Report is submitted in batch print mode; a polling timer monitors
                     the job and opens the output in the browser when complete.
          └── SKIP: Report is not generated; form proceeds to clear.

STEP 21 ── FORM CLEARED
          System clears the form and returns to the initial search state,
          ready for the next AMC cancellation.
```

**Major process interactions:**

- **AMC enrollment master** - primary data source for contract details, validation, and the record updated on cancellation
- **Vehicle master** - validates registration number and VIN during search, and receives the updated coverage expiry date on cancellation
- **Cancellation charge configuration** - pre-configured list of charge percentages and cancellation reasons used during processing
- **Refund calculation engine** - database package that computes GST-aware refund amounts per service type for the selected charge percentage
- **Document numbering** - generates sequential credit note reference numbers from the document master for eligible contracts
- **Loyalty programme** - displays loyalty card balance at load and records a cancellation transaction on commit
- **FDI financial integration** - receives MCP cancellation data for financial integrity (principal-specific)
- **DMS integration layer** - receives the MCP cancellation event notification after commit
- **Report server** - generates and delivers the AMC cancellation report in PDF or print format

---

---

## 4. Functional Requirements

### 4.1 Business Requirements

#### Requirement ID: BR-001

**Requirement Title:** Form Startup and Application Session Registration

**Business Description:**
When the MCP Cancellation form is opened, the application first registers the current session under the module identity so that system administrators and monitoring tools can identify which users are running this form at any point in time. If application-level activity logging is enabled for the dealership, a session timer is started. The form then checks whether MCP has been authorised for the current dealership: if MCP has been deactivated by the manufacturer, the form displays a message and closes immediately without allowing further use. If MCP is authorised, the form completes its initialisation by populating the cancellation charges list, refreshing the copyright notice, setting the transaction save flag to its default state, maximising the main window, and enabling transaction savepoint tracking. This initialisation happens automatically and requires no action from the user under normal conditions.

**Actors:** System (automatic on form open)

**Preconditions:**
- The user has launched the MCP Cancellation form from the dealership application menu.

**Main Flow:**

**Step 1 - Session identity registered for the MCP Cancellation module**
The system automatically registers the current database session with the module name `vt_amc_cncl` so that database monitoring tools can see which application module is active. No message is shown to the user.

**Step 2 - Application activity timer started when logging is enabled**
If the dealership's application-level logging setting (`GLOBAL.APP_LOG`) is active (`Y`), the system starts a session timer that will record how long this form session runs. If logging is not active, this step is skipped.

**Step 3 - MCP authorisation is verified for the dealership**
The system queries the dealer location parameter table (`am_dealer_loc_param`) for the current dealer, parent group, and location to retrieve the MCP deactivation flag. If the flag value is `Y`, MCP has been deactivated for this dealership by the manufacturer and the form cannot be used.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| MCP is not deactivated for this dealership | `WHEN-NEW-FORM-INSTANCE` trigger - queries `am_dealer_loc_param.mcp_deactivate_flag` for the current dealer, parent group, and location | When the form first opens | Prevents any MCP cancellation work at a dealership where the manufacturer has disabled MCP | *"MCP has been disabled by MSIL-Service"*; the form closes immediately |

*Business outcomes (errors, warnings, success, and status):*
- **BR-001-ES-01** - MCP is deactivated for this dealership - *"MCP has been disabled by MSIL-Service"*; the form exits without allowing any further use.

**Step 4 - Cancellation charges list is populated**
The system calls the list population routine to load the cancellation charge types from the reference data master into the on-screen dropdown, so that the advisor can select a charge type when processing a cancellation.

**Step 5 - Copyright notice is populated and the form is prepared for use**
The system populates the copyright display field with the current financial year copyright text. The transaction save flag (`parameter.p_save`) is initialised to `N` (not saved). The main window (`WN_MAIN`) is maximised, and the form's savepoint mode is set to active so that the system can manage transaction recovery correctly during the session.

**Alternative Flows:**
- **BR-001-AF-01** - (from Step 2) Application logging is not enabled: the timer start is skipped entirely; the form continues to Step 3 with no logging active.
- **BR-001-AF-02** - (from Step 3) The dealer location parameter record is not found (exception): the MCP deactivation flag defaults to `N` and the form initialisation continues normally.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Application Logging Flag (`GLOBAL.APP_LOG`) | Auto-populated | Character | 1 | N/A | `Y` / other | Session established | System-set session global; not user-editable | N/A |
| MCP Deactivation Flag (`am_dealer_loc_param.mcp_deactivate_flag`) | System-read | Character | 1 | `am_dealer_loc_param` | `Y` / `N` | Dealer globals set | If `Y`, form is not available for use | *"MCP has been disabled by MSIL-Service"*; form exits |
| Transaction Save Flag (`parameter.p_save`) | Auto-populated | Character | 1 | N/A | `N` | Form open | Initialised to `N` on form open; set to `Y` by the save button before the save trigger fires | N/A |
| Copyright Display (`CB_VT_AMC_ENROLL.COPY_RIGHT`) | Read-only display | Character | N/A | N/A | N/A | Form open | System-populated from copyright function on initialisation | N/A |

---

---

#### Requirement ID: BR-002

**Requirement Title:** MCP Enrollment Lookup by Contract Number

**Business Description:**
When a service advisor enters an MCP contract number and moves off the field, the system looks up the enrollment record for the current dealership. It then checks whether the contract was enrolled at a different dealer location, whether it has already been cancelled, or whether it has already expired. Only a valid, active MCP contract that was enrolled at the same dealership can proceed to the cancellation screen. Any failed check shows a clear message and returns the advisor to the field to correct the entry.

**Actors:** Service Advisor

**Preconditions:**
- The MCP Cancellation form is open.
- The advisor has entered a contract number in the enrollment search field.

**Main Flow:**

**Step 1 - Contract number is validated against the enrollment records**
The service advisor enters a contract number. When they move off the field, the system looks up the MCP enrollment record for that contract number under the current dealership's principal mapping. The system verifies the contract exists and retrieves its cancellation status, expiry date, and selling dealer location.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Contract number exists in enrollment records | `WHEN-VALIDATE-ITEM` on `CB_VT_AMC_ENROLL.NB_AMC_NUM` - SELECT from `VH_AMC_ENROL` where `principal_map_cd = :global.principal AND amc_num = :NB_AMC_NUM AND enq_type IS NULL` | When the advisor moves off the contract number field | Confirms the entered contract number corresponds to an existing MCP enrollment for this principal | *"MCP Enrollment Number Not Found"* - field focus stays on the contract number field; processing stops |
| No data width or incompatible data error | `WHEN-VALIDATE-ITEM` on `CB_VT_AMC_ENROLL.NB_AMC_NUM` - `VALUE_ERROR` exception branch | When the lookup query encounters a data type mismatch | Catches any data width or type incompatibility from the enrollment query | *"Width problem/Incompatible data"* - field focus stays on the contract number field; processing stops |
| Unexpected system error during lookup | `WHEN-VALIDATE-ITEM` on `CB_VT_AMC_ENROLL.NB_AMC_NUM` - `WHEN OTHERS` exception branch | When the lookup query encounters any other database error | Surfaces any unexpected error from the enrollment lookup so the advisor is informed | The system's own database error text is shown (the dynamic database error message); field focus stays on the contract number field; processing stops |

*Business outcomes (errors, warnings, success, and status):*
- **BR-002-ES-01** - Contract number not found in enrollment records for this dealership - *"MCP Enrollment Number Not Found"*; the field retains focus so the advisor can correct the entry.
- **BR-002-ES-02** - Data incompatibility error during lookup - *"Width problem/Incompatible data"*; the field retains focus.
- **BR-002-ES-03** - Unexpected database error during contract lookup - the system's own database error description is displayed; the field retains focus.

**Step 2 - Contract eligibility for cancellation is verified**
After the contract is found, the system checks three business rules in sequence: the contract must have been enrolled at the same dealer location as the current user; it must not have already been cancelled; and its validity period must not have already expired. If any check fails, the advisor is shown a specific message and cannot proceed.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Contract was enrolled at the current dealer location | `WHEN-VALIDATE-ITEM` on `CB_VT_AMC_ENROLL.NB_AMC_NUM` - checks `lv_parent <> :GLOBAL.parent_group OR lv_dealer <> :GLOBAL.Dealer OR lv_loc <> :global.loc_cd` (when `lv_parent IS NOT NULL`) | When the system has retrieved the enrollment record and checks its selling dealer | Prevents a dealer from cancelling an MCP contract that was sold by a different dealer or location | *"You can not cancel MCP Enrolled At Other Dealer Location"*; processing stops, field retains focus |
| Contract has not already been cancelled | `WHEN-VALIDATE-ITEM` on `CB_VT_AMC_ENROLL.NB_AMC_NUM` - checks `NVL(lv_cancel_yn,'N') = 'Y'` | When the system has retrieved the enrollment record and checks its cancellation status | Prevents duplicate cancellation of an already-cancelled MCP contract | *"MCP already cancelled"*; processing stops, field retains focus |
| Contract validity has not already expired | `WHEN-VALIDATE-ITEM` on `CB_VT_AMC_ENROLL.NB_AMC_NUM` - checks `lv_exp_date <= TRUNC(SYSDATE)` | When the system has retrieved the enrollment record and checks its expiry date | Prevents cancellation of an MCP contract whose coverage period has already lapsed | *"MCP already expired"*; processing stops, field retains focus |

*Business outcomes (errors, warnings, success, and status):*
- **BR-002-ES-04** - Contract enrolled at a different dealer location - *"You can not cancel MCP Enrolled At Other Dealer Location"*; field retains focus.
- **BR-002-ES-05** - Contract already cancelled - *"MCP already cancelled"*; field retains focus.
- **BR-002-ES-06** - Contract already expired - *"MCP already expired"*; field retains focus.

**Step 3 - Valid contract number is accepted and passed forward**
When all checks pass, the contract number is accepted. The validated contract reference is copied internally so it can be used to load the full enrollment details on the next screen section.

**Alternative Flows:**
- **BR-002-AF-01** - (from Step 1) Contract number field is left blank: no lookup is performed; the trigger exits without action and the form waits for the next user input.
- **BR-002-AF-02** - (from Step 2) Selling dealer information is null (contract enrolled without a selling parent group): the cross-dealer location check is skipped; only the cancellation status and expiry checks apply.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Enrollment No. (`CB_VT_AMC_ENROLL.NB_AMC_NUM`) | Conditional - when searching by contract number | Character | 15 | N/A | N/A | Form open | Must match an active, non-cancelled, non-expired MCP enrollment for the current dealership | *"MCP Enrollment Number Not Found"*; *"MCP already cancelled"*; *"MCP already expired"*; *"You can not cancel MCP Enrolled At Other Dealer Location"* |

---

---

#### Requirement ID: BR-003

**Requirement Title:** MCP Enrollment Lookup by Vehicle Registration Number

**Business Description:**
When a service advisor enters a vehicle registration number and moves off the field, the system first sanitises the value by removing any special characters, then confirms the vehicle exists in the system, and finally finds the active MCP enrollment for that vehicle at the current dealership. This allows the advisor to start the cancellation process when they have the vehicle's registration plate rather than the MCP contract number. If the vehicle is not found, has multiple records, or has no active MCP enrollment, the advisor sees a specific message and must correct the entry.

**Actors:** Service Advisor

**Preconditions:**
- The MCP Cancellation form is open.
- The advisor has entered a vehicle registration number in the registration number search field.

**Main Flow:**

**Step 1 - Registration number is sanitised**
When the advisor moves off the registration number field (and the field is not blank), the system removes any special or non-alphanumeric characters from the value entered, so that the number is in a clean format before the vehicle lookup proceeds.

*Procedures called:*
- **SP_VALIDATE_ALPHANUMERIC** ([SP-081](#SP-081--SP_VALIDATE_ALPHANUMERIC)) - SP_VALIDATE_ALPHANUMERIC - removes any non-alphanumeric characters (characters outside the ranges A-Z and 0-9) from the registration number string, correcting the value in place before the vehicle record is searched.
    * **Step 1** - Determine the length of the registration number entered.
    * **Step 2** - Examine each character position in the value one at a time.
    * **Step 3** - For each character that is not a letter (A-Z) and not a digit (0-9), remove it from the value and adjust the remaining length accordingly.
    * **Step 4** - Return the cleaned registration number with only letters and digits remaining.

**Step 2 - Vehicle existence is confirmed in the vehicle master**
The cleaned registration number is looked up in the vehicle master to confirm that a vehicle with that registration exists. If no vehicle is found, or if more than one vehicle matches the registration, the advisor is informed and cannot proceed.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Vehicle exists with the entered registration number | `WHEN-VALIDATE-ITEM` on `CB_VT_AMC_ENROLL.NB_REG_NUM` - SELECT from `GM_VIN` where `reg_num = :NB_REG_NUM`; `NO_DATA_FOUND` exception | When the advisor moves off the registration number field | Confirms the registration number matches a known vehicle before attempting an MCP lookup | *"Registration Number Not Found"*; processing stops, field retains focus |
| Registration number matches exactly one vehicle | `WHEN-VALIDATE-ITEM` on `CB_VT_AMC_ENROLL.NB_REG_NUM` - `TOO_MANY_ROWS` exception | When the vehicle lookup finds more than one vehicle | Prevents ambiguous lookups where the same registration is recorded against multiple vehicles | *"More than one Records found for "* followed by the registration number entered; processing stops, field retains focus |
| No data width or incompatible data error during vehicle lookup | `WHEN-VALIDATE-ITEM` on `CB_VT_AMC_ENROLL.NB_REG_NUM` - `VALUE_ERROR` exception from vehicle query | When the vehicle query encounters a data type mismatch | Catches any data width or type incompatibility | *"Width problem/Incompatiable data"*; processing stops, field retains focus |
| Unexpected system error during vehicle lookup | `WHEN-VALIDATE-ITEM` on `CB_VT_AMC_ENROLL.NB_REG_NUM` - `WHEN OTHERS` exception from vehicle query | When the vehicle query encounters any other database error | Surfaces any unexpected database error from the vehicle lookup | *"Execution failed while retrieving Registration No. "* followed by the system's own database error text; processing stops, field retains focus |

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-ES-01** - Registration number not found in vehicle records - *"Registration Number Not Found"*; field retains focus.
- **BR-003-ES-02** - Multiple vehicle records found for the registration number - *"More than one Records found for "* followed by the registration number; field retains focus.
- **BR-003-ES-03** - Data incompatibility error during vehicle lookup - *"Width problem/Incompatiable data"*; field retains focus.
- **BR-003-ES-04** - Unexpected database error during vehicle lookup - *"Execution failed while retrieving Registration No. "* followed by the system's own database error text; field retains focus.

**Step 3 - Active MCP enrollment is located for the vehicle at the current dealership**
With the vehicle confirmed, the system searches for an active, non-cancelled MCP enrollment for that vehicle at the current dealership's parent group. The first matching active enrollment found is selected and its contract number is stored internally for use in loading the full cancellation details.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Active MCP enrollment exists for the vehicle at the current dealer group | `WHEN-VALIDATE-ITEM` on `CB_VT_AMC_ENROLL.NB_REG_NUM` - SELECT from `VH_AMC_ENROL` where `principal_map_cd = :global.principal AND reg_num = :NB_REG_NUM AND NVL(cancel_yn,'N') = 'N' AND amc_end_date > TRUNC(SYSDATE) AND selling_parent_group = :GLOBAL.parent_group AND enq_type IS NULL AND rownum = 1`; `NO_DATA_FOUND` exception | When the vehicle is confirmed and the MCP enrollment is searched | Ensures only vehicles with a current, active MCP at this dealership group can be cancelled | *"Active MCP Enrollment Not Found against Reg No. "* followed by the registration number; processing stops, field retains focus |
| No data width or incompatible data error during enrollment lookup | `WHEN-VALIDATE-ITEM` on `CB_VT_AMC_ENROLL.NB_REG_NUM` - `VALUE_ERROR` exception from enrollment query | When the enrollment query encounters a data type mismatch | Catches any data width or type incompatibility during enrollment lookup | *"Width problem/Incompatible data"*; processing stops, field retains focus |
| Unexpected system error during enrollment lookup | `WHEN-VALIDATE-ITEM` on `CB_VT_AMC_ENROLL.NB_REG_NUM` - `WHEN OTHERS` exception from enrollment query | When the enrollment query encounters any other database error | Surfaces any unexpected database error from the MCP enrollment lookup | *"Execution failed while retrieving MCP Detials "* followed by the system's own database error text; processing stops, field retains focus |

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-ES-05** - No active MCP enrollment found for the vehicle at this dealership - *"Active MCP Enrollment Not Found against Reg No. "* followed by the registration number; field retains focus.
- **BR-003-ES-06** - Data incompatibility error during enrollment lookup - *"Width problem/Incompatible data"*; field retains focus.
- **BR-003-ES-07** - Unexpected database error during enrollment lookup - *"Execution failed while retrieving MCP Detials "* followed by the system's own database error text; field retains focus.

**Alternative Flows:**
- **BR-003-AF-01** - (from Step 1) Registration number field is left blank: no validation or lookup is performed; the trigger exits without action.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Registration No. (`CB_VT_AMC_ENROLL.NB_REG_NUM`) | Conditional - when searching by registration number | Character | N/A | N/A | N/A | Form open | Must match exactly one vehicle in the vehicle master; vehicle must have an active, non-expired, non-cancelled MCP at the current dealer group | See BR-003-ES-01 through BR-003-ES-07 above |

---

---

#### Requirement ID: BR-004

**Requirement Title:** MCP Enrollment Lookup by Vehicle Identification Number (VIN)

**Business Description:**
When a service advisor enters a vehicle's VIN and moves off the field, the system confirms the VIN exists in the vehicle master and then finds the active MCP enrollment for that vehicle at the current dealership. This provides a third search method when the advisor has neither the contract number nor the registration plate but does have the vehicle identification number. If the VIN is not found, is ambiguous, or has no active MCP enrollment, the advisor is shown a specific message.

**Actors:** Service Advisor

**Preconditions:**
- The MCP Cancellation form is open.
- The advisor has entered a VIN in the VIN search field.

**Main Flow:**

**Step 1 - VIN existence is confirmed in the vehicle master**
When the advisor moves off the VIN field, the system looks up the VIN in the vehicle master. It confirms the VIN exists and is unique. If no vehicle is found for that VIN, or more than one record is returned, the advisor is shown a specific message and must correct the entry.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| VIN exists in the vehicle master | `WHEN-VALIDATE-ITEM` on `CB_VT_AMC_ENROLL.NB_VIN` - SELECT from `GM_VIN` where `vin = :NB_VIN`; `NO_DATA_FOUND` exception | When the advisor moves off the VIN field | Confirms the entered VIN corresponds to a known vehicle before any MCP lookup is attempted | *"VIN Not Found"*; processing stops, field retains focus |
| VIN matches exactly one vehicle record | `WHEN-VALIDATE-ITEM` on `CB_VT_AMC_ENROLL.NB_VIN` - `TOO_MANY_ROWS` exception | When the VIN lookup finds more than one vehicle | Prevents ambiguous lookups where the same VIN is recorded against multiple vehicles | *"More than one Records found for "* followed by the VIN entered; processing stops, field retains focus |
| No data width or incompatible data error during VIN lookup | `WHEN-VALIDATE-ITEM` on `CB_VT_AMC_ENROLL.NB_VIN` - `VALUE_ERROR` exception from VIN query | When the VIN query encounters a data type mismatch | Catches any data width or type incompatibility | *"Width problem/Incompatiable data"*; processing stops, field retains focus |
| Unexpected system error during VIN lookup | `WHEN-VALIDATE-ITEM` on `CB_VT_AMC_ENROLL.NB_VIN` - `WHEN OTHERS` exception from VIN query | When the VIN query encounters any other database error | Surfaces any unexpected database error | *"Execution failed while retrieving VIN "* followed by the system's own database error text; processing stops, field retains focus |

*Business outcomes (errors, warnings, success, and status):*
- **BR-004-ES-01** - VIN not found in vehicle records - *"VIN Not Found"*; field retains focus.
- **BR-004-ES-02** - Multiple vehicle records found for the VIN - *"More than one Records found for "* followed by the VIN; field retains focus.
- **BR-004-ES-03** - Data incompatibility error during VIN lookup - *"Width problem/Incompatiable data"*; field retains focus.
- **BR-004-ES-04** - Unexpected database error during VIN lookup - *"Execution failed while retrieving VIN "* followed by the system's own database error text; field retains focus.

**Step 2 - Active MCP enrollment is located for the VIN at the current dealership**
With the VIN confirmed, the system searches for an active, non-cancelled MCP enrollment for that vehicle at the current dealership's principal and parent group. The first matching active enrollment is selected and its contract number stored internally.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Active MCP enrollment exists for the VIN at the current dealer group | `WHEN-VALIDATE-ITEM` on `CB_VT_AMC_ENROLL.NB_VIN` - SELECT from `VH_AMC_ENROL` where `principal_map_cd = :global.principal AND vin = :NB_VIN AND NVL(cancel_yn,'N') = 'N' AND amc_end_date > TRUNC(SYSDATE) AND selling_parent_group = :GLOBAL.parent_group AND enq_type IS NULL AND rownum = 1`; `NO_DATA_FOUND` exception | When the VIN is confirmed and the MCP enrollment is searched | Ensures only vehicles with a current, active MCP at this dealership group can proceed to cancellation | *"Active MCP Enrollment Not Found against VIN "* followed by the VIN entered; processing stops, field retains focus |
| No data width or incompatible data error during enrollment lookup | `WHEN-VALIDATE-ITEM` on `CB_VT_AMC_ENROLL.NB_VIN` - `VALUE_ERROR` exception from enrollment query | When the enrollment query encounters a data type mismatch | Catches any data width or type incompatibility during enrollment lookup | *"Width problem/Incompatible data"*; processing stops, field retains focus |
| Unexpected system error during enrollment lookup | `WHEN-VALIDATE-ITEM` on `CB_VT_AMC_ENROLL.NB_VIN` - `WHEN OTHERS` exception from enrollment query | When the enrollment query encounters any other database error | Surfaces any unexpected database error from the MCP enrollment lookup | *"Execution failed while retrieving MCP Detials "* followed by the system's own database error text; processing stops, field retains focus |

*Business outcomes (errors, warnings, success, and status):*
- **BR-004-ES-05** - No active MCP enrollment found for the VIN at this dealership - *"Active MCP Enrollment Not Found against VIN "* followed by the VIN; field retains focus.
- **BR-004-ES-06** - Data incompatibility error during enrollment lookup - *"Width problem/Incompatible data"*; field retains focus.
- **BR-004-ES-07** - Unexpected database error during enrollment lookup - *"Execution failed while retrieving MCP Detials "* followed by the system's own database error text; field retains focus.

**Alternative Flows:**
- **BR-004-AF-01** - (from Step 1) VIN field is left blank: no lookup is performed; the trigger exits without action.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| VIN (`CB_VT_AMC_ENROLL.NB_VIN`) | Conditional - when searching by VIN | Character | N/A | N/A | N/A | Form open | Must match exactly one vehicle in the vehicle master; vehicle must have an active, non-expired, non-cancelled MCP at the current dealer group | See BR-004-ES-01 through BR-004-ES-07 above |

---

---

#### Requirement ID: BR-005

**Requirement Title:** Load Full MCP Enrollment Details for Review and Cancellation

**Business Description:**
Once a valid MCP contract has been identified - either by contract number, registration number, or VIN - the system automatically loads all enrollment details onto the screen so the service advisor can review the contract before cancelling it. This includes vehicle details, customer contact information, package coverage amounts and their usage, the balance remaining in each coverage category, tax amounts, and the customer's loyalty programme status. If no contract has been identified, the system prompts the advisor to select one first.

**Actors:** System (automatic when the MCP details section becomes active)

**Preconditions:**
- A valid MCP contract number has been identified through one of the three search methods (by contract number, registration number, or VIN).

**Main Flow:**

**Step 1 - Presence of a selected contract is verified before loading**
When the details section of the form becomes active, the system checks whether a contract number has been selected through the search section. If no contract has been identified, the system shows a message and returns the advisor to the search section.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| A contract number has been selected via the search | `WHEN-NEW-BLOCK-INSTANCE` on `B_VH_AMC_ENQ` - checks `CB_VT_AMC_ENROLL.NB_AMC_NUM1 IS NOT NULL` | When focus moves to the MCP details section | Prevents the detail section from loading with no context, ensuring the advisor has first identified the contract to cancel | *"Please select Enrollment No./Registration No./VIN for fetch MCP details"*; focus is returned to the contract number search field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-ES-01** - No contract identified - *"Please select Enrollment No./Registration No./VIN for fetch MCP details"*; focus returns to the search field.

**Step 2 - Full MCP enrollment details are loaded onto the screen**
With the contract number confirmed, the system loads all enrollment information from the records. This includes all fields covering the contract, vehicle identity, customer contact details, selling dealer information, package coverage amounts, amounts used to date, and tax components.

*Procedures called:*
- **PROC_AMC_DETAILS** ([SP-003](#SP-003--PROC_AMC_DETAILS)) - PROC_AMC_DETAILS - retrieves the complete MCP enrollment record for the selected contract and principal, then populates all detail fields on screen with the contract and vehicle information. Also retrieves the customer's loyalty programme status for the vehicle.
    * **Step 1** - Retrieve the full MCP enrollment record for the selected contract number under the current principal, filtering to standard enrollments only (not enquiry types).
    * **Step 2** - Retrieve the discount amounts broken down by service type (labour, parts, consumables) and any additional charge amounts from the enrollment detail records for that contract.
    * **Step 3** - Populate all on-screen contract, vehicle, and customer fields from the retrieved enrollment record, including dates, amounts, vehicle identity details, customer contact information, and selling dealer details.
    * **Step 4** - Calculate the remaining balance available in each coverage category (labour, parts, consumables) by subtracting the amounts already used and any discounts from the original coverage amounts.
    * **Step 5** - Retrieve loyalty programme points (awarded and redeemed) from the enrollment record and populate the corresponding on-screen loyalty fields.
    * **Step 6** - Call the loyalty details service to retrieve the loyalty card type, card number, linked registration number, balance points, and balance monetary value for the vehicle; silently continue if that call fails.
    * **Step 7** - Look up and populate the descriptive display names for the vehicle model, vehicle variant, the customer's city, and the package description using master reference tables; silently continue if any individual lookup fails.

- **PKG_LOYALTY.SP_GET_VIN_LOYALTY_DTL** ([SP-024](#SP-024--PKG_LOYALTY.SP_GET_VIN_LOYALTY_DTL)) - PKG_LOYALTY.SP_GET_VIN_LOYALTY_DTL - retrieves the loyalty programme card details and current point balances for the vehicle from the loyalty system, returning the card type, card number, linked registration number, balance points, and equivalent monetary value; silently continues without populating loyalty fields if any error occurs.
    * **Step 1** - Accept the principal/dealer identifier and the vehicle's VIN as inputs.
    * **Step 2** - Look up the loyalty programme membership record for the vehicle at the current dealership.
    * **Step 3** - Retrieve the loyalty card type, card number, the registration number linked to the loyalty account, the current balance in points, and the equivalent monetary value of those points.
    * **Step 4** - Return all loyalty card details and balances to the calling procedure; if any error occurs during retrieval, return silently without raising an error.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Enrollment No. (`B_VH_AMC_ENQ.AMC_NUM`) | Read-only display | Character | 15 | N/A | N/A | Contract identified via search | System-populated from enrollment record | N/A |
| Date (`B_VH_AMC_ENQ.AMC_DATE`) | Read-only display | Date | DD-MM-RRRR HH24:MI | N/A | N/A | Contract loaded | System-populated | N/A |
| MCP Validity Start Date (`B_VH_AMC_ENQ.AMC_START_DATE`) | Read-only display | Date | DD-MM-RRRR | N/A | N/A | Contract loaded | System-populated | N/A |
| MCP Validity End Date (`B_VH_AMC_ENQ.AMC_END_DATE`) | Read-only display | Date | DD-MM-RRRR | N/A | N/A | Contract loaded | System-populated | N/A |
| Upto Mileage (`B_VH_AMC_ENQ.EXPIRY_MILEAGE`) | Read-only display | Number | N/A | N/A | N/A | Contract loaded | System-populated | N/A |
| Upto Vehicle Age (`B_VH_AMC_ENQ.EXPIRY_MONTH`) | Read-only display | Number | N/A | N/A | N/A | Contract loaded | System-populated | N/A |
| Registration No. (`B_VH_AMC_ENQ.REG_NUM`) | Read-only display | Character | N/A | N/A | N/A | Contract loaded | System-populated | N/A |
| VIN (`B_VH_AMC_ENQ.VIN`) | Read-only display | Character | N/A | N/A | N/A | Contract loaded | System-populated | N/A |
| Chassis (`B_VH_AMC_ENQ.CHASSIS_NUM`) | Read-only display | Character | N/A | N/A | N/A | Contract loaded | System-populated | N/A |
| Engine No. (`B_VH_AMC_ENQ.ENGINE_NUM`) | Read-only display | Character | N/A | N/A | N/A | Contract loaded | System-populated | N/A |
| Vehicle Model (`B_VH_AMC_ENQ.SVAR_CD`) | Read-only display | Character | N/A | N/A | N/A | Contract loaded | System-populated | N/A |
| Vehicle Variant (`B_VH_AMC_ENQ.VARIANT_CD`) | Read-only display | Character | N/A | N/A | N/A | Contract loaded | System-populated | N/A |
| Customer ID (`B_VH_AMC_ENQ.CUST_CD`) | Read-only display | Character | N/A | N/A | N/A | Contract loaded | System-populated | N/A |
| Name (`B_VH_AMC_ENQ.CUST_NAME`) | Read-only display | Character | N/A | N/A | N/A | Contract loaded | System-populated | N/A |
| Address (`B_VH_AMC_ENQ.CUST_ADDR1`) | Read-only display | Character | N/A | N/A | N/A | Contract loaded | System-populated | N/A |
| Contact No. (`B_VH_AMC_ENQ.PHONE`) | Read-only display | Character | N/A | N/A | N/A | Contract loaded | System-populated | N/A |
| Mobile (`B_VH_AMC_ENQ.MOBILE`) | Read-only display | Character | N/A | N/A | N/A | Contract loaded | System-populated | N/A |
| Email (`B_VH_AMC_ENQ.EMAIL`) | Read-only display | Character | N/A | N/A | N/A | Contract loaded | System-populated | N/A |
| Current Mileage (`B_VH_AMC_ENQ.ODOMETER_READING`) | Read-only display | Number | N/A | N/A | N/A | Contract loaded | System-populated | N/A |
| Applicable Package (`B_VH_AMC_ENQ.PKG_CODE`) | Read-only display | Character | N/A | N/A | N/A | Contract loaded | System-populated | N/A |
| Package Amount (`B_VH_AMC_ENQ.PKG_AMT`) | Read-only display | Number | 99999999999.99 | N/A | N/A | Contract loaded | System-populated | N/A |
| Labour Amt (`B_VH_AMC_ENQ.LABOUR_AMT`) | Read-only display | Number | 99999999999.99 | N/A | N/A | Contract loaded | System-populated | N/A |
| Part Amt (`B_VH_AMC_ENQ.PART_AMT`) | Read-only display | Number | 99999999999.99 | N/A | N/A | Contract loaded | System-populated | N/A |
| Consumable Amt (`B_VH_AMC_ENQ.CONSUMABLE_AMT`) | Read-only display | Number | 99999999999.99 | N/A | N/A | Contract loaded | System-populated | N/A |
| Discount Amt (`B_VH_AMC_ENQ.DISCOUNT_AMT`) | Read-only display | Number | 99999999999.99 | N/A | N/A | Contract loaded | System-populated | N/A |
| Tax Amt (`B_VH_AMC_ENQ.SRV_TAX_AMT`) | Read-only display | Number | 99999999999.99 | N/A | N/A | Contract loaded | System-populated (service tax + Swachh Bharat cess + Krishi Kalyan cess + charge amounts combined) | N/A |
| Net Amt (`B_VH_AMC_ENQ.TOT_BILL_AMT`) | Read-only display | Number | 99999999999.99 | N/A | N/A | Contract loaded | System-populated | N/A |
| Labour Amt (used) (`B_VH_AMC_ENQ.LABOUR_USED_AMT`) | Read-only display | Number | 99999999999.99 | N/A | N/A | Contract loaded | System-populated | N/A |
| Part Amt (used) (`B_VH_AMC_ENQ.PART_USED_AMT`) | Read-only display | Number | 99999999999.99 | N/A | N/A | Contract loaded | System-populated | N/A |
| Cons Amt (used) (`B_VH_AMC_ENQ.CONSUMABLE_USED_AMT`) | Read-only display | Number | 99999999999.99 | N/A | N/A | Contract loaded | System-populated | N/A |
| Balance (labour) (`B_VH_AMC_ENQ.NB_LBR_BAL`) | Read-only display | Number | 99999999999.99 | N/A | N/A | Contract loaded | Calculated: labour amount minus labour used minus labour discount | N/A |
| Balance (parts) (`B_VH_AMC_ENQ.NB_PART_BAL`) | Read-only display | Number | 99999999999.99 | N/A | N/A | Contract loaded | Calculated: parts amount minus parts used minus parts discount | N/A |
| Balance (consumables) (`B_VH_AMC_ENQ.NB_CONS_BAL`) | Read-only display | Number | 99999999999.99 | N/A | N/A | Contract loaded | Calculated: consumables amount minus consumables used minus consumables discount | N/A |
| Awarded points (`B_VH_AMC_ENQ.LOYL_AWARD_PTS`) | Read-only display | Number | N/A | N/A | N/A | Contract loaded | System-populated from enrollment record | N/A |
| Redeemed points (`B_VH_AMC_ENQ.LOYL_REDEEM_PTS`) | Read-only display | Number | N/A | N/A | N/A | Contract loaded | System-populated from enrollment record | N/A |
| Card Type (`B_VH_AMC_ENQ.NB_LOY_CARD_TYPE`) | Read-only display | Character | N/A | N/A | N/A | Contract loaded | System-populated from loyalty service | N/A |

---

---

#### Requirement ID: BR-006

**Requirement Title:** Cancellation Charge Type Selection and Refund Breakdown Calculation

**Business Description:**
After reviewing the MCP enrollment details, the service advisor must select the applicable cancellation charge type from a predefined list and also enter a cancellation reason. The system uses the selected charge type to look up the applicable cancellation charge details and calculate the refund amounts for each coverage category (labour, parts, consumables), the associated taxes, and the net amount payable to the customer. If cancellation charges is left blank when leaving the field, the advisor is prompted to complete it. When a charge type is chosen, the system automatically calculates and displays all refund breakdown figures.

**Actors:** Service Advisor

**Preconditions:**
- The MCP enrollment details have been loaded onto the screen.
- The service advisor is on the MCP details section ready to complete cancellation.

**Main Flow:**

**Step 1 - Cancellation Charges field is validated as not blank**
When the service advisor moves off the Cancellation Charges field, the system checks that a value has been selected. If the field is blank, the advisor is prompted to select one before continuing.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-010](#SP-010--GENERAL.CHECK_NULL)) - GENERAL.CHECK_NULL - checks whether the Cancellation Charges field has a value; if blank, prompts the advisor to enter one and prevents further navigation.
    * **Step 1** - Check whether the Cancellation Charges field value is blank.
    * **Step 2** - If blank, display the message *"Enter a valid Cancellation Charges"* and stop processing so the advisor must complete the field before continuing.
    * **Step 3** - If the field has a value, no action is taken and processing continues normally.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Cancellation Charges field is not blank | Mandatory field check - GENERAL.CHECK_NULL [SP-010] | When the advisor moves off the Cancellation Charges field | Ensures the advisor selects a charge type before any refund calculation proceeds | *"Enter a valid Cancellation Charges"*; processing stops, field retains focus |

*Business outcomes (errors, warnings, success, and status):*
- **BR-006-ES-01** - Cancellation Charges field is blank - *"Enter a valid Cancellation Charges"*; field retains focus.

**Step 2 - Cancellation charge details are retrieved and refund amounts calculated**
When the advisor selects a cancellation charge type from the dropdown list, the system retrieves the detailed breakdown of applicable cancellation charges and calculates the refund amounts for labour, parts, and consumables, together with the applicable tax amounts and the total net refund payable. If the charge type is cleared back to blank, all refund fields are reset to empty.

*Procedures called:*
- **PKG_AMC.SP_POP_CANCEL_DTL** ([SP-018](#SP-018--PKG_AMC.SP_POP_CANCEL_DTL)) - PKG_AMC.SP_POP_CANCEL_DTL - retrieves the cancellation charge detail breakdown from the package master for the selected charge type and contract, returning an error code and message if the retrieval fails.
    * **Step 1** - Accept the principal code, contract number, and selected cancellation charge type as inputs.
    * **Step 2** - Look up the cancellation charge detail records for the given principal, contract, and charge type from the package master.
    * **Step 3** - Return the charge breakdown details to the calling trigger; if retrieval fails, return error code 1 together with an error message describing the problem.
    * **Step 4** - If the returned error code indicates failure, stop processing and display the error message to the advisor.

- **POP_PKG_DETAILS_NEW** ([SP-002](#SP-002--POP_PKG_DETAILS_NEW)) - POP_PKG_DETAILS_NEW - calculates and populates the refund amount breakdown for each service type (labour, parts, consumables) and total figures based on the cancellation charge details retrieved, updating all refund and tax amount fields on screen.
    * **Step 1** - Retrieve the package detail records for the current dealer, location, and contract from the global package detail table.
    * **Step 2** - For each detail record, calculate the cancellation charge amount and the refund amount for its service type (labour, parts, or consumables) by subtracting discounts and usage from the original coverage, then accumulate the applicable tax amount.
    * **Step 3** - Sum the cancellation amounts, refund amounts, and tax amounts across all service types.
    * **Step 4** - Populate the on-screen refund fields for labour, parts, and consumables with the calculated refund amounts and their corresponding tax amounts.
    * **Step 5** - Populate the total cancellation charge amount, total tax amount, total refund amount, and net refund payable amount on screen.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Cancellation charge detail retrieval succeeds | Charge retrieval - PKG_AMC.SP_POP_CANCEL_DTL [SP-018] - checks returned error code `ln_err_cd = 1` | When the advisor selects a charge type from the Cancellation Charges dropdown | Ensures the cancellation charge details can be retrieved before refund amounts are calculated | Error message returned by the package is displayed; processing stops, trigger aborts |

*Business outcomes (errors, warnings, success, and status):*
- **BR-006-ES-02** - Cancellation charge detail retrieval fails - the error message returned by the cancellation detail service is displayed; processing stops.

**Step 3 - Cancellation Reason field is validated as not blank**
When the service advisor moves off the Cancellation Reason field, the system checks that a Cancellation Charges value is also present (both fields are required together). If Cancellation Charges is blank at that point, the advisor is prompted to enter it first.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-010](#SP-010--GENERAL.CHECK_NULL)) - GENERAL.CHECK_NULL - checks that Cancellation Charges is not blank when the advisor has moved off the Cancellation Reason field; prompts if missing.
    * **Step 1** - Check whether the Cancellation Charges field value is blank.
    * **Step 2** - If blank, display the message *"Enter a valid Cancellation Charges"* and stop processing so the advisor completes that field first.
    * **Step 3** - If the Cancellation Charges field has a value, no action is taken and processing continues.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Cancellation Charges is not blank when leaving Cancellation Reason | Mandatory field check - GENERAL.CHECK_NULL [SP-010] - on `WHEN-VALIDATE-ITEM` for `B_VH_AMC_ENQ.CANC_REASON` | When the advisor moves off the Cancellation Reason field | Ensures the cancellation charge type is always selected before the reason is entered | *"Enter a valid Cancellation Charges"*; processing stops |

**Alternative Flows:**
- **BR-006-AF-01** - (from Step 2) Cancellation Charges list selection is cleared back to blank: all refund amount fields (labour refund, parts refund, consumables refund, net refund payable) are cleared to null; no refund figures are shown.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Cancellation Charges (`B_VH_AMC_ENQ.CANCEL_CHARGES`) | Mandatory | List (character) | N/A | Cancellation charge type list (`AM_LIST_RANGE` via `RG_CNCL_CHG`) | List code from the active cancellation charges master | Contract details loaded | Must not be blank | *"Enter a valid Cancellation Charges"* |
| Date (`B_VH_AMC_ENQ.CANCEL_DATE`) | Mandatory | Date/Datetime | DD-MM-RRRR HH24:MI | N/A | N/A | Contract loaded | N/A | N/A |
| Cancellation Reason (`B_VH_AMC_ENQ.CANC_REASON`) | Mandatory | Character | N/A | N/A | N/A | Contract loaded | Cancellation Charges must be selected first | *"Enter a valid Cancellation Charges"* |
| Labour (`B_VH_AMC_ENQ.LABOUR_RFND_AMT`) | Read-only display | Number | 99999999999.99 | N/A | N/A | Charge type selected | System-calculated | N/A |
| Part (`B_VH_AMC_ENQ.PART_RFND_AMT`) | Read-only display | Number | 99999999999.99 | N/A | N/A | Charge type selected | System-calculated | N/A |
| Consumable (`B_VH_AMC_ENQ.CONS_RFND_AMT`) | Read-only display | Number | 99999999999.99 | N/A | N/A | Charge type selected | System-calculated | N/A |
| Srv Tax on Labour (`B_VH_AMC_ENQ.SRV_TAX_AMT_RFND`) | Read-only display | Number | 99999999999.99 | N/A | N/A | Charge type selected | System-calculated | N/A |
| Swachh Bharat Cess on Labour (`B_VH_AMC_ENQ.SBC_TAX_AMT_RFND`) | Read-only display | Number | 99999999999.99 | N/A | N/A | Charge type selected | System-calculated | N/A |
| Krishi Kalyan Cess on Labour (`B_VH_AMC_ENQ.KKC_TAX_AMT_RFND`) | Read-only display | Number | 99999999999.99 | N/A | N/A | Charge type selected | System-calculated | N/A |
| Value (`B_VH_AMC_ENQ.CANCEL_AMT`) | Read-only display | Number | 99999999999.99 | N/A | N/A | Charge type selected | System-calculated total cancellation charge | N/A |
| Total (`B_VH_AMC_ENQ.NB_TOT_TAX`) | Read-only display | Number | 99999999999.99 | N/A | N/A | Charge type selected | System-calculated total tax | N/A |
| Total refund (`B_VH_AMC_ENQ.NB_TOT_RFND`) | Read-only display | Number | 99999999999.99 | N/A | N/A | Charge type selected | System-calculated total refund | N/A |
| Net Payable Amt (`B_VH_AMC_ENQ.NET_RFND_AMT`) | Read-only display | Number | 99999999999.99 | N/A | N/A | Charge type selected | System-calculated net refund payable | N/A |

---

---

#### Requirement ID: BR-007

**Requirement Title:** MCP Contract Cancellation Confirmation and Save

**Business Description:**
When the service advisor clicks the Cancel MCP button, the system first validates that both the cancellation charge type and the cancellation reason have been entered. If both are present, the system asks the advisor to confirm the cancellation. On confirmation, the cancellation charges and refund details are saved to the database, the MCP enrollment is marked as cancelled with the cancellation date and refund amounts recorded, and the vehicle's expiry date is updated. For dealerships under a specific principal, the cancellation data is also submitted to the financial integrity system. Once saved, the cancellation report is offered for printing or PDF viewing. After the report is handled, the form is cleared for the next transaction.

**Actors:** Service Advisor

**Preconditions:**
- The MCP enrollment details are loaded on screen.
- The cancellation charge type, cancellation date, and cancellation reason have been completed.
- The refund breakdown has been calculated.

**Main Flow:**

**Step 1 - Mandatory cancellation fields are validated before confirmation**
When the advisor clicks the Cancel MCP button, the system first checks that both the Cancellation Charges and Cancellation Reason fields are populated. If either is blank, the advisor is prompted to complete it before the confirmation dialogue is shown.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-010](#SP-010--GENERAL.CHECK_NULL)) - GENERAL.CHECK_NULL - checks that the Cancellation Charges field is not blank; if blank, prompts the advisor and stops the cancellation flow.
    * **Step 1** - Check whether the Cancellation Charges field value is blank.
    * **Step 2** - If blank, display the message *"Enter a valid Cancellation Charges"* and stop processing.
    * **Step 3** - If the field has a value, no action is taken and processing continues.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Cancellation Charges field is not blank | Mandatory field check - GENERAL.CHECK_NULL [SP-010] - first call in `WHEN-BUTTON-PRESSED` on `CB_VT_AMC_ENROLL.PB_CNCL` | When the advisor clicks the Cancel MCP button | Ensures the charge type is selected before the cancellation confirmation is shown | *"Enter a valid Cancellation Charges"*; processing stops |
| Cancellation Reason field is not blank | Mandatory field check - GENERAL.CHECK_NULL [SP-010] - second call in `WHEN-BUTTON-PRESSED` on `CB_VT_AMC_ENROLL.PB_CNCL` | When the advisor clicks the Cancel MCP button | Ensures the reason is provided before confirmation | *"Enter a valid Cancellation Reason"*; processing stops |

*Business outcomes (errors, warnings, success, and status):*
- **BR-007-ES-01** - Cancellation Charges is blank - *"Enter a valid Cancellation Charges"*; cancellation is not initiated.
- **BR-007-ES-02** - Cancellation Reason is blank - *"Enter a valid Cancellation Reason"*; cancellation is not initiated.

**Step 2 - Advisor confirms the cancellation**
With both mandatory fields complete, the system presents a confirmation dialogue asking the advisor whether they really want to cancel the MCP contract. If the advisor confirms, the cancellation proceeds. If the advisor declines, no further action is taken and the form stays as is.

*Procedures called:*
- **GENERAL.ASK_CONFIRM** ([SP-009](#SP-009--GENERAL.ASK_CONFIRM)) - GENERAL.ASK_CONFIRM - presents an alert dialogue with the message *"Do you really want to cancel the MCP ?"* and returns 1 if the advisor clicks the confirmation button, or 0 if they cancel the dialogue.
    * **Step 1** - Display a confirmation alert with the message *"Do you really want to cancel the MCP ?"*.
    * **Step 2** - Wait for the advisor to click either the confirmation button or the dismiss button.
    * **Step 3** - Return 1 if the advisor confirmed, or 0 if they dismissed the dialogue.

*Business outcomes (errors, warnings, success, and status):*
- **BR-007-WS-01** - *"Do you really want to cancel the MCP ?"* - shown to the advisor before any database changes are made; the advisor must explicitly confirm to proceed.

**Step 3 - Cancellation charges and enrollment records are saved to the database**
On confirmation, the system saves the cancellation charges by inserting the charge detail records. Before inserting, if the original contract date is on or after 1 July 2017, the system generates a credit note number for the cancellation. It then inserts the charge breakdown records from the package charge master and updates the enrollment record to mark it as cancelled, recording the cancellation date, charge type, refund amounts per category, total cancellation charge, net refund, cancellation reason, and the credit note number. The vehicle's MCP expiry date in the vehicle extension record is also updated to the cancellation date.

*Procedures called:*
- **SP_INSERT_CHARGES** ([SP-004](#SP-004--SP_INSERT_CHARGES)) - SP_INSERT_CHARGES - performs the full database save for the MCP cancellation: generates a credit note number when applicable, inserts the cancellation charge detail records, updates the enrollment as cancelled, updates the vehicle extension record, records the loyalty programme transaction for the cancellation event, and commits all changes.
    * **Step 1** - Check whether the MCP contract date falls on or after 1 July 2017; if so, generate a credit note number by calling the back-date validation and sequence generation service; if the credit note number generation fails (error code is non-zero), display the error message and stop processing.
    * **Step 2** - If the credit note number was generated successfully (or was not required for pre-July 2017 contracts), insert the cancellation charge detail records by copying the applicable charge lines from the package charge master for the current dealer, location, and contract.
    * **Step 3** - Update the MCP enrollment record to mark it as cancelled, recording the cancellation flag, cancellation date, charge type, labour refund amount, parts refund amount, consumables refund amount, total cancellation charge, net refund payable, cancellation reason, and credit note number.
    * **Step 4** - Update the vehicle extension record to set the MCP expiry date to the cancellation date.
    * **Step 5** - Record a loyalty programme transaction for the MCP cancellation event for the vehicle's loyalty card, passing the card number, VIN, transaction type, contract number, dealer details, and user identity; silently continue if the loyalty transaction recording fails.
    * **Step 6** - Commit all database changes.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Credit note number generation succeeds (for contracts dated on or after 1 July 2017) | SP_INSERT_CHARGES [SP-004] - calls `PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM`; checks returned error code is non-zero | When saving the cancellation for a contract dated from 1 July 2017 onwards | Ensures a valid credit note reference is assigned to the cancellation before any database records are written | The error message from the credit note generation service is displayed; processing stops |
| All database writes succeed | SP_INSERT_CHARGES [SP-004] - `WHEN OTHERS` exception at the procedure level | When inserting cancellation charge records and updating enrollment | Catches any unexpected database error during the cancellation save | *"Error... AMC Calculation"* followed by the system's own database error text; processing stops |

*Business outcomes (errors, warnings, success, and status):*
- **BR-007-ES-03** - Credit note number generation fails - the error message from the credit note generation service is displayed; cancellation is not saved.
- **BR-007-ES-04** - Unexpected database error during cancellation save - *"Error... AMC Calculation"* followed by the system's own database error text; processing stops.

**Step 4 - Cancellation data is pushed to the financial integrity system (principal 1 only)**
Immediately after the cancellation records are saved, for dealerships under principal 1, the system submits the cancellation transaction data to the financial integrity system. If that submission fails for any reason, the error is silently ignored and the transaction remains saved.

*Procedures called:*
- **SP_PUSH_MCPC_FDI_DATA** ([SP-079](#SP-079--SP_PUSH_MCPC_FDI_DATA)) - SP_PUSH_MCPC_FDI_DATA - pushes the MCP cancellation transaction details (vehicle, dealer, selling details, amounts, customer data) to the financial data integration system; called only for dealerships under principal 1; any errors from the push are silently ignored.
    * **Step 1** - Accept the principal code and contract number as inputs.
    * **Step 2** - Retrieve the full cancellation transaction detail from the enrollment records, including vehicle, dealer, customer, financial, and tax information required for financial integration.
    * **Step 3** - Format and submit the transaction data to the financial data integration package for processing.
    * **Step 4** - Return an error code and message if the submission fails; the calling trigger ignores any errors silently.

**Step 5 - Database changes are committed**
The saved cancellation records are permanently committed to the database. This commit applies to the cancellation charges, the enrollment update, the vehicle extension update, and the loyalty transaction record all together.

**Alternative Flows:**
- **BR-007-AF-01** - (from Step 2) Advisor dismisses the confirmation dialogue without confirming: the cancellation is not processed; the form remains on the details screen with all fields unchanged.
- **BR-007-AF-02** - (from Step 1) Cancellation Charges field is null (advisor did not select one): mandatory validation fails before the confirmation dialogue is shown; no database changes occur.
- **BR-007-AF-03** - (from Step 4) Principal is not 1: the financial integrity push step is skipped entirely; processing continues directly to generating the cancellation report.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Cancellation Charges (`B_VH_AMC_ENQ.CANCEL_CHARGES`) | Mandatory | List (character) | N/A | Cancellation charge type list | N/A | Contract loaded | Must not be blank | *"Enter a valid Cancellation Charges"* |
| Cancellation Reason (`B_VH_AMC_ENQ.CANC_REASON`) | Mandatory | Character | N/A | N/A | N/A | Contract loaded | Must not be blank | *"Enter a valid Cancellation Reason"* |
| Date (`B_VH_AMC_ENQ.CANCEL_DATE`) | Mandatory | Date/Datetime | DD-MM-RRRR HH24:MI | N/A | N/A | Contract loaded | Used as the cancellation date in the enrollment update | N/A |
| Enrollment No. (`B_VH_AMC_ENQ.AMC_NUM`) | Read-only display | Character | 15 | N/A | N/A | Contract loaded | Used as the key for all database update operations | N/A |

---

---

#### Requirement ID: BR-008

**Requirement Title:** MCP Cancellation Report Generation

**Business Description:**
After the MCP cancellation has been saved, the system offers the service advisor the choice of viewing the cancellation report as a PDF document or sending it to a printer. The advisor selects their preferred output format and the system generates and delivers the MCP cancellation report (report `vr_amc_cncl`) with the full details of the cancelled contract. If the advisor dismisses the prompt without choosing a format, no report is generated. This report step follows directly from the successful save of the cancellation.

**Actors:** Service Advisor

**Preconditions:**
- The MCP cancellation has been successfully saved (BR-007 completed).
- The contract number is available for the report.

**Main Flow:**

**Step 1 - Print toolbar availability and contract number are confirmed before the report is offered**
The report flow is only initiated when the Print toolbar button (`PB_BLK.PB_PRINT`) is enabled on screen and a contract number is present. If the button is disabled or no contract number has been loaded, no report action is taken.

**Step 2 - Report format is selected by the advisor**
With the print button active and a contract number present, the system presents an alert with options to view the report as a PDF, send it to a printer, or skip the report entirely. The advisor selects one of these options.

**Step 3 - Cancellation report is generated in the selected format**
Based on the advisor's choice, the system generates the MCP cancellation report (`vr_amc_cncl`) using the contract's principal, dealer, location, financial area, and contract number as report parameters. For PDF output, the report is opened in the browser. For printer output, the report is sent to the print server using character-mode output settings (`MODE=CHARACTER BLANKPAGES=NO`) and a polling timer is started to track the print job.

*Procedures called:*
- **CALL_REPORT_ENQ** ([SP-001](#SP-001--CALL_REPORT_ENQ)) - CALL_REPORT_ENQ - presents the output format alert, then generates the MCP cancellation report in the chosen format (PDF to browser or character-mode print to the report server); clears the alert if the advisor declines.
    * **Step 1** - Locate the report object and the report output format alert in the current form.
    * **Step 2** - Display the alert to prompt the advisor to choose PDF output, print output, or skip the report.
    * **Step 3** - If PDF is chosen: set the report output format to PDF, set all report parameters (parent group, principal, financial area, dealer, location, and contract number), assign the report server and the report filename (`vr_amc_cncl`), run the report, and open the resulting document in the browser as a new page.
    * **Step 4** - If print is chosen: set the report output format to character mode with output option string `MODE=CHARACTER BLANKPAGES=NO`, set the same report parameters, call the report execution and print routing service to submit the print job, and store the report job handle and print output reference in the session for tracking.
    * **Step 5** - If neither output option is selected, clear any pending messages and take no further action.

- **GENERAL.PROC_REPORT_CALL** ([SP-012](#SP-012--GENERAL.PROC_REPORT_CALL)) - GENERAL.PROC_REPORT_CALL - runs the report object against the report server and returns the report job identifier and print output reference to the caller for status tracking.
    * **Step 1** - Execute the configured report object on the assigned report server.
    * **Step 2** - Capture the report job identifier returned by the report server.
    * **Step 3** - Return the job identifier and the print output reference to the calling procedure.

- **GENERAL.PROC_TIMER** ([SP-013](#SP-013--GENERAL.PROC_TIMER)) - GENERAL.PROC_TIMER - starts a timer after the print job is submitted so the form can later check the print job status when the timer fires.
    * **Step 1** - Start a timer in the current form session to trigger a status check after a defined interval.

**Business Scenarios - How report delivery differs by output format**

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **PDF output selected** | Report is generated in PDF format and opened in a new browser tab; no printer interaction; timer is not started. |
| **Print output selected** | Report is generated in character mode (`MODE=CHARACTER BLANKPAGES=NO`) and sent to the printer via the report server; the print job handle is stored in the session; a timer is started to track the print job completion. |
| **Report prompt dismissed** | No report is generated; any pending alert messages are cleared; the form proceeds to the clear step. |

**Alternative Flows:**
- **BR-008-AF-01** - (from Step 2) Advisor dismisses the alert without selecting a format: messages are cleared and no report output is produced; the form proceeds to clear.
- **BR-008-AF-02** - (from Step 1) Print button is disabled or contract number is null: the report generation step is skipped entirely; no report is produced and the form clears.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Enrollment No. (`B_VH_AMC_ENQ.AMC_NUM`) | Read-only display | Character | 15 | N/A | N/A | Cancellation saved | Used as the `P_AMC_NUM` report parameter | N/A |

---

---

#### Requirement ID: BR-009

**Requirement Title:** Form-Level Error and Message Interception

**Business Description:**
Whenever a system error or informational message occurs anywhere in the form, a centralised handler intercepts it and either shows the advisor a clear, plain-language message and stops further processing, or silently suppresses low-severity informational messages that do not require user attention. This ensures the advisor always sees meaningful feedback rather than raw system codes. A separate message handler intercepts certain system messages to provide cleaner formatted output.

**Actors:** System (automatic on any form error or system message)

**Preconditions:**
- The MCP Cancellation form is open.

**Main Flow:**

**Step 1 - Date format errors are intercepted and shown as plain-language messages**
When the form encounters a date entry error (code 50004 for invalid date value, or 50025/50026 for incorrect date format), the handler displays a clear message and stops further processing in the current trigger.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Date value entered is a valid date | `ON-ERROR` form trigger - error codes `50004` | When any date field receives an invalid date value | Shows the advisor a clear message instead of a cryptic system error code | *"Entered Date is not valid Date"*; processing stops in the current trigger |
| Date value is in the correct format (DD-MM-YYYY) | `ON-ERROR` form trigger - error codes `50025`, `50026` | When any date field receives a value in an unsupported format | Tells the advisor the expected format | *"Enter the Date in the proper format (DD-MM-YYYY)"*; processing stops in the current trigger |

*Business outcomes (errors, warnings, success, and status):*
- **BR-009-ES-01** - Invalid date value entered - *"Entered Date is not valid Date"*; the current trigger is stopped.
- **BR-009-ES-02** - Date format is incorrect - *"Enter the Date in the proper format (DD-MM-YYYY)"*; the current trigger is stopped.

**Step 2 - Numeric-only field violations are intercepted**
When the form detects that a non-numeric or special character was entered in a field that only accepts numbers (error codes 40209 or 50016), the handler displays an explanatory message and stops the current trigger.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Numeric-only field contains a non-numeric or special character | `ON-ERROR` form trigger - error codes `40209`, `50016` | When a non-numeric value is detected in a numeric field | Advises the advisor to enter a number | *"Characters/Special Characters are not allowed here, enter the numeric value"*; current trigger stops |

*Business outcomes (errors, warnings, success, and status):*
- **BR-009-ES-03** - Non-numeric character entered in a numeric field - *"Characters/Special Characters are not allowed here, enter the numeric value"*; current trigger stops.

**Step 3 - Standard field-level errors are surfaced to the advisor**
For error code 40207 (a standard field-level validation error), the handler displays the standard error text as produced by the system and stops the current trigger.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Standard field validation error | `ON-ERROR` form trigger - error code `40207` | When a standard Oracle Forms field validation error occurs | Surfaces the system's own error description to the advisor | The system's own error text for that error is shown; current trigger stops |

**Step 4 - Database integrity violation is reported via the standard error catalogue**
When a database foreign-key or referential integrity constraint is violated (database error code -02292), the handler looks up and displays the corresponding catalogued error message and stops the current trigger.

*Procedures called:*
- **GENERAL.RAISE_ERROR** ([SP-015](#SP-015--GENERAL.RAISE_ERROR)) - GENERAL.RAISE_ERROR - looks up the catalogued message for error code `E0088` and displays it with the appropriate severity title; for error-type messages, stops the current trigger after display.
    * **Step 1** - Receive the message code to be raised.
    * **Step 2** - Look up the message text and message type for the given code from the error catalogue.
    * **Step 3** - If the message is of error type, display it with the title "Error" and stop the current trigger.
    * **Step 4** - If the message is of note type, display it with the title "Note" without stopping processing.
    * **Step 5** - If the message is of caution type, display it with the title "Caution" without stopping processing.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Referential integrity violation during save | `ON-ERROR` form trigger - database error code `-02292` -> GENERAL.RAISE_ERROR [SP-015] for message code `E0088` | When a database operation violates a foreign key or referential integrity rule | Informs the advisor of a data dependency conflict using the catalogued error message | Catalogued error message for E0088 is displayed; current trigger stops |

**Step 5 - Concurrent update conflicts are detected and reported**
When error codes 40654 through 40659 occur (indicating another user has updated the same record since the advisor loaded it), the handler displays a specific message, rolls back the current transaction, and stops the current trigger.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Concurrent update conflict on the same record | `ON-ERROR` form trigger - error codes `40654`, `40655`, `40656`, `40657`, `40659` | When a save or update operation finds the record has already been changed by another user | Prevents the advisor from overwriting another user's changes without knowing about the conflict | *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*; transaction rolled back; current trigger stops |

*Business outcomes (errors, warnings, success, and status):*
- **BR-009-ES-04** - Record updated by another user - *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*; transaction rolled back; current trigger stops.

**Step 6 - All other database errors are surfaced with rollback**
For any remaining database error where `SQLCODE` is non-zero (not already handled above), the handler displays the system's own database error message, rolls back the current transaction, and stops the current trigger.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Unhandled database error | `ON-ERROR` form trigger - `SQLCODE <> 0` (catch-all branch for unhandled database errors) | When any unhandled database error occurs | Ensures the advisor is informed of any unexpected database error and the transaction is safely rolled back | The system's own database error text (`SQLERRM`) is displayed; transaction rolled back; current trigger stops |

**Step 7 - Low-severity informational messages are silently suppressed**
Error codes 40401 and 40405 (form-level information messages with no user impact) are silently ignored by the handler and cause no visible message or processing interruption.

**Step 8 - System messages are intercepted and formatted**
A separate form-level message handler intercepts system messages with codes 40209 and 40207. For these, it formats the message as the error type, error number, and error text separated by dashes, displays it, and stops the current trigger.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| System message codes 40209 or 40207 | `ON-MESSAGE` form trigger - error codes `40209`, `40207` | When the form raises a system informational message with these codes | Converts the system-generated message into a formatted, readable error display | Formatted message shown as error type, dash, error number, colon, and error text; current trigger stops |

**Alternative Flows:**
- **BR-009-AF-01** - (from Step 7) Error codes 40401 or 40405 are encountered: silently suppressed; no message is shown; processing continues normally.

---

---

#### Requirement ID: BR-010

**Requirement Title:** Form Screen Clear and Copyright Display Refresh

**Business Description:**
When the service advisor uses the form's clear function to reset the screen for a new transaction, the system clears all fields and resets the form to its initial state. At the same time, the copyright notice displayed on the screen is refreshed to show the current financial year's copyright text. This allows the advisor to begin a new MCP cancellation without having to close and reopen the form.

**Actors:** Service Advisor

**Preconditions:**
- The MCP Cancellation form is open.

**Main Flow:**

**Step 1 - All screen data is cleared**
The form clears all fields and resets to its initial state without performing any database save or validation. Any unsaved changes are discarded.

**Step 2 - Copyright notice is refreshed**
After the screen is cleared, the system calculates and displays the current financial year copyright text in the copyright display area. For months January, February, and March, the copyright shows the previous year; for all other months, it shows the current year.

*Procedures called:*
- **SF_COPYRIGHT_DECLARATION** ([SP-073](#SP-073--SF_COPYRIGHT_DECLARATION)) - SF_COPYRIGHT_DECLARATION - calculates and returns the current financial year copyright text for Maruti Suzuki India Limited, based on today's date, and populates the copyright display field.
    * **Step 1** - Check the current month to determine which financial year applies.
    * **Step 2** - If the current month is January, February, or March, the copyright year is the previous calendar year.
    * **Step 3** - For all other months, the copyright year is the current calendar year.
    * **Step 4** - Return the formatted copyright text (e.g., "© [year] Maruti Suzuki India Limited") for display.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Copyright (`CB_VT_AMC_ENROLL.COPY_RIGHT`) | Read-only display | Character | N/A | N/A | N/A | Form cleared | System-populated from copyright function | N/A |

---

---

#### Requirement ID: BR-011

**Requirement Title:** Print Job Status Check on Timer Expiry

**Business Description:**
When the print job timer fires after the advisor has submitted a report to the printer, the system checks whether the print job has completed. If the job is still running, the timer continues without action. If the job has finished, the system opens the printed document output. If the job has failed or encountered an unexpected state, the advisor is notified.

**Actors:** System (automatic on timer expiry)

**Preconditions:**
- A cancellation report has been submitted for printing and a print timer has been started (BR-008 print path).

**Main Flow:**

**Step 1 - Print job status is checked when the timer fires**
When the application timer expires, the system checks whether it is the print queue timer and, if so, retrieves the current status of the submitted print job using the stored report job handle.

*Procedures called:*
- **GENERAL.PROC_TIMER_EXPIRED** ([SP-014](#SP-014--GENERAL.PROC_TIMER_EXPIRED)) - GENERAL.PROC_TIMER_EXPIRED - checks the status of the active print job on the timer queue; if the job has finished, opens the print output in the browser and removes the timer; if still in progress, takes no action; if the job failed or is in an unexpected state, shows an error message and removes the timer.
    * **Step 1** - Retrieve the current timer name and the stored report job handle and print output reference from the session.
    * **Step 2** - If the active timer is the print queue timer, check the current status of the report job.
    * **Step 3** - If the job is still running, opening, or queued, take no action and allow the timer to fire again on the next interval.
    * **Step 4** - If the job has finished successfully, open the print output in a new browser tab and remove the print queue timer.
    * **Step 5** - If the job is in any other state (failed or unexpected), display *"Unable to generate the report"* and remove the print queue timer.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Print job completed successfully | GENERAL.PROC_TIMER_EXPIRED [SP-014] - checks `REPORT_OBJECT_STATUS` result for `FINISHED` state | When the print queue timer fires | Ensures the print output is only opened once the job is actually complete | If job is not finished: no action; if failed: *"Unable to generate the report"*; timer removed |

*Business outcomes (errors, warnings, success, and status):*
- **BR-011-ES-01** - Print job failed or is in an unexpected state - *"Unable to generate the report"*; the print queue timer is removed.

**Alternative Flows:**
- **BR-011-AF-01** - (from Step 2) The active timer is not the print queue timer: no print status check is performed; the timer handler exits without action.
- **BR-011-AF-02** - (from Step 3) Print job is still running or queued: the handler takes no action and waits for the next timer firing.

---

---

#### Requirement ID: BR-012

**Requirement Title:** Post-Commit DMS Notification for MCP Cancellation

**Business Description:**
Immediately after a successful database commit for the MCP cancellation, the system automatically sends a DMS notification message for the "SRV_MCPCANCEL" transaction type, informing downstream systems that the contract has been cancelled. This notification includes the dealer, location, and contract details. If the notification fails for any reason, the failure is silently ignored and the cancellation record already committed is not affected.

**Actors:** System (automatic on database commit)

**Preconditions:**
- The MCP cancellation has been committed to the database (BR-007 completed successfully).

**Main Flow:**

**Step 1 - DMS cancellation notification is sent**
Immediately after the database commit, the system calls the DMS message push service to notify downstream systems of the MCP cancellation. The call passes the transaction type "SRV_MCPCANCEL", along with the current dealer's parent group, dealer code, location, financial area, the DMS document type "MCP_CNCL", the contract number, and the current user's identity. If the call encounters any error, it is silently ignored.

*Procedures called:*
- **SP_PUSH_DMS_MESSAGE** ([SP-078](#SP-078--SP_PUSH_DMS_MESSAGE)) - SP_PUSH_DMS_MESSAGE - pushes a DMS notification for the MCP cancellation transaction, sending the transaction type, dealer identity, location, document type, contract number, and user identity to the DMS messaging service; any failure is silently ignored.
    * **Step 1** - Accept the transaction type, parent group, dealer code, location, financial area, document type, contract number, and user identity as inputs.
    * **Step 2** - Look up the DMS process configuration for the transaction type and format the notification message.
    * **Step 3** - Submit the formatted notification message to the DMS messaging system, including all required dealer and transaction identifiers.
    * **Step 4** - If any error occurs during the notification push, continue silently without raising an error or affecting the committed cancellation record.

**Alternative Flows:**
- **BR-012-AF-01** - (from Step 1) DMS notification call fails for any reason: the error is silently caught and ignored; the MCP cancellation record remains committed; no visible message is shown to the advisor.

---

---

#### Requirement ID: BR-013

**Requirement Title:** Form Exit and Session Cleanup

**Business Description:**
When the service advisor chooses to exit the MCP Cancellation form, the system clears the session identity and module tracking information before closing the form without saving any pending changes. This ensures that database monitoring tools no longer show this module as active for the advisor's session after the form closes.

**Actors:** Service Advisor

**Preconditions:**
- The MCP Cancellation form is open.

**Main Flow:**

**Step 1 - Session tracking information is cleared**
When the advisor exits the form, the system clears the client information and module name from the current database session, so that no module is shown as active in database monitoring after the form closes.

**Step 2 - Form is closed without saving**
The form closes immediately without performing any save or validation of pending changes. All unsaved data is discarded.

---

---

#### Requirement ID: BR-014

**Requirement Title:** Saved Contract Reference Re-Validation on Navigation

**Business Description:**
When the form navigates internally through the saved contract reference field (the internal copy of the contract number used to load enrollment details), the system re-validates that the referenced contract is still active - confirming it has not already been cancelled and has not expired. This prevents the enrollment details section from being loaded with a contract that has changed status since it was first looked up.

**Actors:** System (automatic on field navigation)

**Preconditions:**
- A contract number has previously been entered or resolved and its reference stored internally.

**Main Flow:**

**Step 1 - Stored contract reference is re-validated**
When the internal contract reference field is navigated, the system checks the stored contract number against the enrollment records. It verifies the contract is not already cancelled and its validity has not expired. If either condition fails, the advisor sees a specific message and processing stops.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Contract has not already been cancelled | `WHEN-VALIDATE-ITEM` on `CB_VT_AMC_ENROLL.NB_AMC_NUM1` - checks `NVL(lv_cancel_yn,'N') = 'Y'` on `VH_AMC_ENROL` | When the internal contract reference field is navigated | Prevents loading the details section with a contract that has since been cancelled | *"MCP already cancelled"*; processing stops |
| Contract validity has not expired | `WHEN-VALIDATE-ITEM` on `CB_VT_AMC_ENROLL.NB_AMC_NUM1` - checks `lv_exp_date <= TRUNC(SYSDATE)` | When the internal contract reference field is navigated | Prevents loading the details section with a contract that has since expired | *"MCP already expired"*; processing stops |
| Contract number exists in enrollment records | `WHEN-VALIDATE-ITEM` on `CB_VT_AMC_ENROLL.NB_AMC_NUM1` - `NO_DATA_FOUND` exception from SELECT on `VH_AMC_ENROL` | When the internal contract reference field is navigated | Ensures the stored reference still exists in the enrollment records | *"MCP Enrollment Number Not Found"*; processing stops |
| No data incompatibility error | `WHEN-VALIDATE-ITEM` on `CB_VT_AMC_ENROLL.NB_AMC_NUM1` - `VALUE_ERROR` exception | When the lookup encounters a data type mismatch | Catches data width or type incompatibility | *"Width problem/Incompatible data"*; processing stops |
| No unexpected system error | `WHEN-VALIDATE-ITEM` on `CB_VT_AMC_ENROLL.NB_AMC_NUM1` - `WHEN OTHERS` exception | When any other database error occurs | Surfaces any unexpected error from the re-validation lookup | *"Execution failed while retrieving MCP Detials "* followed by the system's own database error text; processing stops |

*Business outcomes (errors, warnings, success, and status):*
- **BR-014-ES-01** - Stored contract reference no longer found - *"MCP Enrollment Number Not Found"*; processing stops.
- **BR-014-ES-02** - Data incompatibility during re-validation - *"Width problem/Incompatible data"*; processing stops.
- **BR-014-ES-03** - Unexpected error during re-validation - *"Execution failed while retrieving MCP Detials "* followed by the system's own database error text; processing stops.
- **BR-014-ES-04** - Contract has been cancelled since lookup - *"MCP already cancelled"*; processing stops.
- **BR-014-ES-05** - Contract has expired since lookup - *"MCP already expired"*; processing stops.

**Alternative Flows:**
- **BR-014-AF-01** - (from Step 1) The internal contract reference field is blank: no validation is performed; the trigger exits without action.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Internal contract reference (`CB_VT_AMC_ENROLL.NB_AMC_NUM1`) | Auto-populated | Character | 15 | N/A | N/A | Contract number resolved via any search method | Must match an active, non-cancelled, non-expired MCP enrollment | See BR-014-ES-01 through BR-014-ES-05 |

---

**Inactive Triggers (COMMENTED OUT / INACTIVE - does not execute)**

The following triggers are present in the form but are inactive and do not execute:

- **KEY-COMMIT** (Form level) - `(COMMENTED OUT / INACTIVE - does not execute)` - Contains a `NULL;` statement; no commit or validation logic executes.
- **KEY-UP** (`B_VH_AMC_ENQ` block level) - `(COMMENTED OUT / INACTIVE - does not execute)` - Contains a `null;` statement; no navigation logic executes.
- **KEY-DOWN** (`B_VH_AMC_ENQ` block level) - `(COMMENTED OUT / INACTIVE - does not execute)` - Contains a `null;` statement; no navigation logic executes.

**Unused Program Unit (defined but not called from any active trigger)**

- **POP_LIST** - A form program unit that populates the cancellation charges list from the record group `RG_CNCL_CHG` (querying active entries from the `AM_LIST_RANGE` master for the current principal). This procedure is defined in the form but is not referenced from any active trigger in this form.

---

## 5. Business Rules Catalogue

Catalogue of the discrete business rules enforced by the MCP Cancellation form's code.

| Rule ID | Rule Name | Rule Type | Business Requirement ID | Condition | Action | Business Impact |
| ------- | --------- | --------- | ----------------------- | --------- | ------ | --------------- |
| BRC-001 | MCP Contract Must Exist for Dealership | Validation | BR-002, BR-003, BR-004, BR-014 | An MCP contract number, registration number, or VIN is entered and no matching enrollment record is found for the current dealership | Show the appropriate not-found message (e.g., *"MCP Enrollment Number Not Found"*, *"Registration Number Not Found"*, *"VIN Not Found"*, *"Active MCP Enrollment Not Found against Reg No. [value]"*, *"Active MCP Enrollment Not Found against VIN [value]"*) and prevent navigation to the details section | Prevents the form from attempting to cancel a non-existent contract, protecting data integrity |
| BRC-002 | MCP Contract Must Be Enrolled at Current Dealer Location | Authorization | BR-002 | A contract number is entered and the selling dealer location on the enrollment record differs from the current dealer's parent group, dealer code, or location (and the selling parent group is not null) | Show *"You can not cancel MCP Enrolled At Other Dealer Location"* and prevent the contract from proceeding to the details section | Ensures dealers can only cancel contracts they themselves enrolled, preventing cross-dealer cancellations |
| BRC-003 | MCP Contract Must Not Already Be Cancelled | Constraint | BR-002, BR-014 | An MCP contract number is entered (or re-validated on navigation) and the enrollment record shows the contract is already cancelled | Show *"MCP already cancelled"* and stop processing | Prevents duplicate cancellations on an already-cancelled contract |
| BRC-004 | MCP Contract Must Not Be Expired | Constraint | BR-002, BR-014 | An MCP contract number is entered (or re-validated on navigation) and the enrollment record shows the contract's validity end date is on or before today's date | Show *"MCP already expired"* and stop processing | Prevents attempts to cancel a contract whose coverage period has already lapsed |
| BRC-005 | Registration Number Must Match Exactly One Vehicle | Validation | BR-003 | A registration number is entered and more than one vehicle record is found for that registration | Show *"More than one Records found for [registration number]"* and prevent the lookup from proceeding | Avoids ambiguous lookups where the same plate is associated with multiple vehicles |
| BRC-006 | VIN Must Match Exactly One Vehicle | Validation | BR-004 | A VIN is entered and more than one vehicle record is found for that VIN | Show *"More than one Records found for [VIN]"* and prevent the lookup from proceeding | Avoids ambiguous lookups where the same VIN is associated with multiple vehicle records |
| BRC-007 | Registration Number Must Belong to a Known Vehicle | Validation | BR-003 | A registration number is entered and no matching vehicle record is found in the vehicle master | Show *"Registration Number Not Found"* and stop processing | Ensures the registration number refers to a real vehicle before any MCP lookup is attempted |
| BRC-008 | VIN Must Belong to a Known Vehicle | Validation | BR-004 | A VIN is entered and no matching vehicle record is found in the vehicle master | Show *"VIN Not Found"* and stop processing | Ensures the VIN refers to a real vehicle before any MCP lookup is attempted |
| BRC-009 | Cancellation Charges Must Be Selected Before Proceeding | Validation | BR-006, BR-007 | The service advisor navigates off the Cancellation Charges field or clicks the Cancel MCP button while the Cancellation Charges field is blank | Show *"Enter a valid Cancellation Charges"* and prevent further processing | Ensures the correct charge type is always selected before the refund is calculated or the cancellation is saved |
| BRC-010 | Cancellation Reason Must Be Provided | Validation | BR-007 | The service advisor clicks the Cancel MCP button and the Cancellation Reason field is blank | Show *"Enter a valid Cancellation Reason"* and prevent the cancellation from proceeding | Ensures a business reason is always recorded for every MCP cancellation |
| BRC-011 | Cancellation Confirmation Required Before Save | Constraint | BR-007 | The service advisor clicks the Cancel MCP button with all mandatory fields completed | Display *"Do you really want to cancel the MCP ?"* and wait for explicit confirmation; if the advisor does not confirm, no database changes are made | Prevents accidental cancellations by requiring an explicit confirmation step before any data is written |
| BRC-012 | Credit Note Required for Contracts From 1 July 2017 Onwards | Derivation | BR-007 | The original MCP contract date is on or after 1 July 2017 and a cancellation is being saved | Generate a credit note number through the back-date validation and sequence service before inserting the cancellation charge records; if generation fails, show the error and stop processing | Ensures every eligible MCP cancellation has a traceable credit note reference for financial and audit compliance |
| BRC-013 | Date Values Must Be Valid and in the Correct Format | Validation | BR-009 | A date field receives a value that is not a valid date (error code 50004) or is not in the DD-MM-YYYY format (error codes 50025, 50026) | Show *"Entered Date is not valid Date"* (for invalid date) or *"Enter the Date in the proper format (DD-MM-YYYY)"* (for format error) and stop the current trigger | Prevents invalid or unrecognisable date values from being committed to the database |
| BRC-014 | Numeric Fields Must Not Contain Non-Numeric Characters | Validation | BR-009 | A numeric field receives a non-numeric or special character value (error codes 40209 or 50016) | Show *"Characters/Special Characters are not allowed here, enter the numeric value"* and stop the current trigger | Ensures numeric amounts and identifiers are always stored in a valid numeric format |
| BRC-015 | Concurrent Update Conflicts Must Be Detected and Notified | Constraint | BR-009 | A save or update operation finds that the record has already been modified by another user since it was loaded (error codes 40654-40659) | Roll back the current transaction, show *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*, and stop the current trigger | Prevents one user's changes from silently overwriting another user's concurrent updates to the same record |
| BRC-016 | Referential Integrity Violations Must Be Reported | Validation | BR-009 | A database operation violates a foreign key or referential integrity constraint (database error code -02292) | Display the catalogued error message for code E0088 and stop the current trigger | Informs the advisor of a data dependency conflict so the constraint violation can be understood and resolved |
| BRC-017 | FDI Financial Data Push Applies to Principal 1 Only | Authorization | BR-007 | An MCP cancellation is saved and the current session's principal is 1 | Submit the cancellation transaction data to the financial data integration system; silently ignore any submission failure | Ensures that financial integrity data for MCP cancellations is pushed to the financial system only for dealerships under the designated principal |
| BRC-018 | Print Job Status Must Be Monitored After Printer Submission | Constraint | BR-011 | A cancellation report has been submitted to a printer and the print queue timer fires | Check the print job status; open the print output if the job has finished; show *"Unable to generate the report"* if the job failed | Ensures the advisor is notified of print job failures and that the print output is only opened once the print job is confirmed complete |
| BRC-019 | Registration Number Is Sanitised of Special Characters Before Lookup | Derivation | BR-003 | A registration number is entered and moved off its field | Remove any characters that are not letters (A-Z) or digits (0-9) from the registration number value before performing the vehicle lookup | Ensures registration number lookups are not blocked by accidental special characters such as hyphens or spaces in the entered value |

**Total Business Rules Identified: 19**

---

## 6. Data Requirements

*This section describes the MCP (Maintenance Care Package) enrollment and cancellation data entities, the cancellation-related data captured on the form, the reference data lookups used, and the data lifecycle for MCP cancellation transactions.*

### 6.1 Business Entities and Relationships

*The form's primary data objects are the MCP enrollment record, the cancellation charge detail, and the vehicle extension record. Supporting reference entities include the vehicle master, package detail, and package charge master.*

#### MCP Enrollment - VH_AMC_ENROL

The MCP enrollment record is the central entity managed by this form. It stores the full details of a vehicle's Maintenance Care Package contract including the enrolled vehicle, customer, selling dealer, package coverage amounts, tax amounts, and the cancellation outcome. On this form, enrollment records are read for display and updated to record the cancellation status, cancellation date, charge type, refund amounts, cancellation reason, and credit note number.

#### MCP Cancellation Charges Detail - VD_AMC_CANCELCHARGES

When an MCP contract is cancelled, the applicable cancellation charge breakdown lines are written to this table. Each row records one charge line (by service type - labour, parts, or consumables) including the charge type, charge value, calculated charge amount, and the user who created it. These records are inserted as part of the cancellation save operation.

#### MCP Enrollment Detail - VD_AMC_ENROL

Read-only during this form operation. Contains the usage detail records for the enrolled MCP contract, including amounts used by service type (labour, parts, consumables) and any discount amounts. Used to calculate balance amounts for display.

#### Package Detail - GBL_AMC_DTL

Read-only reference. Contains the dealer-specific package detail lines for the enrolled package, used to calculate the refund breakdown by service type when the cancellation charge type is selected.

#### Package Charge Master - GBL_AMC_CHARGES

Read-only reference. Contains the standard charge lines for the package at the current dealer location. These charge lines are copied into the cancellation charges detail table when the cancellation is saved.

#### Vehicle Master - GM_VIN

Read-only reference. Used to validate that a registration number or VIN corresponds to a known vehicle before the MCP enrollment lookup is attempted.

#### Vehicle Extension - GM_VIN_EXT

The vehicle extension record holds additional vehicle attributes including the MCP expiry date. When an MCP cancellation is saved, the expiry date in this record is updated to the cancellation date.

#### Entity Relationships

The MCP enrollment record is the central entity; cancellation charge detail records and the vehicle extension record are updated as part of the cancellation. Package charges and detail are used as source data for the cancellation charge lines. The vehicle master is referenced for identity validation.

```
VH_AMC_ENROL (MCP Enrollment)
        ├── VD_AMC_ENROL (MCP Enrollment Detail - usage amounts)
        ├── VD_AMC_CANCELCHARGES (Cancellation Charge Detail - written on cancel)
        └── GM_VIN_EXT (Vehicle Extension - expiry date updated on cancel)

GBL_AMC_DTL (Package Detail - refund calculation source)
GBL_AMC_CHARGES (Package Charge Master - charge lines copied on cancel)
GM_VIN (Vehicle Master - identity validation only)
```

### 6.2 Data Capture Requirements

*The form captures three types of data: search criteria used to identify the MCP contract, the cancellation parameters entered by the advisor, and the session context supplied by the calling application. All other displayed fields are read-only and loaded from the enrollment record.*

#### Search / Contract Identification

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Enrollment No. (`CB_VT_AMC_ENROLL.NB_AMC_NUM`) | Conditional | The MCP contract number entered by the advisor to search for the enrollment directly | Must exist in the enrollment records for the current dealership; contract must not be already cancelled, already expired, or enrolled at a different dealer location |
| Registration No. (`CB_VT_AMC_ENROLL.NB_REG_NUM`) | Conditional | The vehicle registration number entered as an alternative search key | Must match exactly one vehicle in the vehicle master; vehicle must have an active, non-expired, non-cancelled MCP enrollment at the current dealer group; special characters are removed before validation |
| VIN (`CB_VT_AMC_ENROLL.NB_VIN`) | Conditional | The vehicle identification number entered as a third alternative search key | Must match exactly one vehicle in the vehicle master; vehicle must have an active, non-expired, non-cancelled MCP enrollment at the current dealer group |

#### Cancellation Parameters (entered by advisor)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Cancellation Charges (`B_VH_AMC_ENQ.CANCEL_CHARGES`) | Yes | The cancellation charge type selected from the predefined list; determines the charge percentage applied to each coverage category | Must not be blank; must be a valid value from the active cancellation charge type list for the current principal |
| Date (`B_VH_AMC_ENQ.CANCEL_DATE`) | Yes | The cancellation date and time, entered by the advisor | Used as the cancellation date in all database updates; format DD-MM-RRRR HH24:MI |
| Cancellation Reason (`B_VH_AMC_ENQ.CANC_REASON`) | Yes | A free-text reason for cancelling the MCP contract | Must not be blank; Cancellation Charges must be selected before this field is accepted |

#### Session / Context (auto-populated from calling application)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Principal (`GLOBAL.PRINCIPAL`) | Auto-Populated | The dealer principal code for the current user's dealership | System-set; used in all database queries and updates to scope data to the current principal |
| Parent Group (`GLOBAL.PARENT_GROUP`) | Auto-Populated | The dealer parent group identifier | System-set; used to validate enrollment's selling parent group and to scope package detail lookups |
| Dealer (`GLOBAL.DEALER`) | Auto-Populated | The dealer code for the current location | System-set; used in database updates and FDI push |
| Location Code (`GLOBAL.LOC_CD`) | Auto-Populated | The location code for the current dealership branch | System-set; used in database updates |
| Financial Area (`GLOBAL.COMP_FA`) | Auto-Populated | The company/financial area code | System-set; used in credit note generation and report parameters |
| Financial Year (`GLOBAL.P_FIN_YR`) | Auto-Populated | The current financial year | System-set; used in credit note generation |
| User ID (`GLOBAL.USERID`) | Auto-Populated | The logged-in user's identifier | System-set; recorded in inserted charge detail records and DMS notification |
| Report Server (`GLOBAL.REP_SERVER`) | Auto-Populated | The report server address for report output | System-set; used when generating the cancellation report |
| Application Logging Flag (`GLOBAL.APP_LOG`) | Auto-Populated | Flag indicating whether application-level activity logging is enabled | System-set; if set to active, a session timer is started on form open |

### 6.3 Reference Data

*Lists the master and configuration data referenced by this form.*

| Reference Data | Business Purpose | Used When |
| :--- | :--- | :--- |
| Cancellation Charge Types (`AM_LIST_RANGE` via record group `RG_CNCL_CHG`) | Provides the list of valid cancellation charge type codes and descriptions for the current principal | Populating the Cancellation Charges dropdown on the MCP details section; filtered to active entries (entries where `close_date` is null or today or in the future) for the current principal with list name `AMC_CNCL_CHG` |
| Cancellation Reasons (`AM_LIST` via record group `RG_CANC`) | Provides the list of valid cancellation reason codes and descriptions for the current principal | Available as a lookup (`LV_CANC` LOV) on the Cancellation Reason field; filtered to the current principal with list name `AMC_CANCEL_REASON` |
| Vehicle Master (`GM_VIN`) | Used to validate that a registration number or VIN corresponds to a known vehicle | When the advisor enters a registration number or VIN in the search section |
| MCP Package Master (`VM_AMC_PKG`) | Provides the package description, expiry months, and MCP type for the enrolled package | When loading enrollment details to populate the package description display field |
| Vehicle Model Master (`VM_SVAR`) | Provides the vehicle model description for display | When loading enrollment details to populate the model description display field |
| Vehicle Variant Master (`GM_VAR`) | Provides the vehicle variant description for display | When loading enrollment details to populate the variant description display field |
| City Master (`GM_CITY`) | Provides the city description for the customer's city code | When loading enrollment details to populate the city description display field |
| Loyalty Programme Details (`PKG_LOYALTY.SP_GET_VIN_LOYALTY_DTL`) | Provides the loyalty card type, number, balance points, and monetary value for the vehicle | When loading enrollment details if a loyalty card is associated with the vehicle's VIN |

### 6.4 Data Lifecycle

*Describes how records are created, updated, and committed within this form's evidenced behaviour.*

**Creation**

- Cancellation charge detail records (`VD_AMC_CANCELCHARGES`) are inserted when the advisor confirms the cancellation. The charge lines are copied from the package charge master (`GBL_AMC_CHARGES`) for the current dealer location and contract. Each inserted row records the principal, contract number, service type, charge details, the creating user, and the creation date.

**Updates**

- The MCP enrollment record (`VH_AMC_ENROL`) is updated on confirmed cancellation to set the cancellation flag to active, the cancellation date, the charge type, the labour/parts/consumables refund amounts, the total cancellation charge, the net refund payable, the cancellation reason, and the credit note number (where applicable).
- The vehicle extension record (`GM_VIN_EXT`) is updated on confirmed cancellation to set the MCP expiry date to the cancellation date for the vehicle's VIN.

**Save and Commit**

- All database changes (insertion of cancellation charge detail records, update of the enrollment record, update of the vehicle extension record, and the loyalty transaction recording) are committed together in a single COMMIT within the `SP_INSERT_CHARGES` program unit, after all writes are complete. There is no intermediate partial save.
- For dealerships under the designated principal, the cancellation data is additionally submitted to the financial data integration system via `SP_PUSH_MCPC_FDI_DATA` immediately after the commit; any failure from this submission is silently ignored.
- A DMS notification for the "SRV_MCPCANCEL" transaction type is sent automatically after the database commit via the `POST-DATABASE-COMMIT` trigger.

**Retention and Audit**

- Each cancellation charge detail record (`VD_AMC_CANCELCHARGES`) stores `CREATED_BY` (the user ID) and `CREATED_DATE` (the system date at save time), providing an audit trail of who created the cancellation charge lines and when.
- The enrolled MCP record retains all original coverage amounts alongside the cancellation amounts, providing a full before/after record. The credit note number (for contracts from 1 July 2017 onwards) provides a financial document reference for the cancellation.

---

### 6.5 Excel Output Columns

This form does not use Excel download. No Excel export columns were identified in the form sources.

## 7. Glossary

*Definitions of terms, abbreviations, and acronyms used throughout this document.*

The following table defines key terms, acronyms, and abbreviations used throughout this Business Requirements Document.

| Term | Definition | Aliases | Related Terms |
| :--- | :--- | :--- | :--- |
| ACR | Credit note document type used to generate sequential credit note reference numbers for AMC cancellations in the document master | Credit Note | Credit Note Number, AM_DOCS |
| AMC | Annual Maintenance Contract - a vehicle service contract covering labour, parts, and consumables for a defined period or mileage | MCP, Maintenance Care Plan | MCP Cancellation, AMC Enrollment |
| AMC Enrollment | The act of registering a vehicle under an AMC contract; stored in the AMC enrollment master table | AMC Contract | AMC Cancellation, VH_AMC_ENROL |
| B_VH_AMC_ENQ | Detail block within the form that displays AMC contract details, refund calculations, and loyalty information after a contract is selected | - | CB_VT_AMC_ENROLL |
| CB_VT_AMC_ENROLL | Control block (search entry block) at the top of the form where the user enters the enrollment number, registration number, or VIN to look up the AMC contract | - | B_VH_AMC_ENQ |
| Cancel Charges | The percentage of the remaining AMC package value withheld as a fee on cancellation; selected by the dealer user from a pre-configured list | Cancellation Charge Percentage | Net Refund Amount |
| Cancellation Reason | A mandatory free-text or coded reason for cancelling the AMC contract; selected from a pre-configured LOV | - | AMC Cancellation |
| CB | Control Block - an Oracle Forms block not bound to a database table; used for search key entry | - | Block |
| Chassis Number | The unique identifier stamped on a vehicle chassis; displayed on the AMC detail screen | Chassis No | VIN, Engine Number |
| Comp FA | Company/Financial Advisor code identifying the company entity within the dealer session | Company FA | Dealer, Location Code |
| Consumables | Consumable materials category within an AMC package (e.g. engine oil, filter); has its own balance, used amount, and refund fields | Consumable Amount | Labour, Parts |
| Credit Note Number | A unique sequential reference number generated on AMC cancellation for accounting purposes; used as lv_crn in the processing logic | CRN | ACR, Document Master |
| Dealer | The authorised vehicle dealer where the AMC was sold or where the cancellation is being processed | Dealer Map Code | Principal, Location Code |
| DMS | Dealer Management System - the integrated software platform managing vehicle sales and after-sales operations at authorised dealerships | - | AMC, MCP |
| DPL | Shared PL/SQL program library attached to the form; provides reusable routines such as DISP_TEXT, ASK_CONFIRM, CHECK_NULL, and report utilities | DPL.pld | PLD, General Library |
| Engine Number | Unique identifier of the vehicle engine; displayed on the AMC contract detail screen | Engine No | Chassis Number, VIN |
| FDI | Financial Data Integration - an integration service that receives MCP cancellation financial data for specific principals | Financial Integrity | DMS Integration, PKG_FDI |
| GST | Goods and Services Tax - the Indian indirect tax framework applied to AMC service components; includes CGST, SGST, IGST, and cess components | - | Service Tax, SBC, KKC |
| KKC | Krishi Kalyan Cess - a legacy Indian tax component applied to service transactions before GST implementation | Krishi Kalyan Cess | SBC, Service Tax, GST |
| Labour | Labour service component within an AMC package; has its own allocated amount, used amount, balance, refund, and tax fields | Labour Amount | Parts, Consumables |
| Location Code | The location identifier within a dealer's operations used for data scoping and document numbering | Loc CD | Dealer, Comp FA |
| LOV | List of Values - a pop-up selection dialog within Oracle Forms allowing the user to pick from a pre-defined list | Dropdown, Picklist | Record Group |
| Loyalty Card | A customer loyalty programme card linked to a vehicle VIN; card type, number, registered mobile, and point balance are displayed and updated on AMC cancellation | - | Loyalty Points, MCP |
| Loyalty Points | Points accumulated on a loyalty card through vehicle service activities; displayed as balance and rupee equivalent at the time of AMC cancellation | Balance Points | Loyalty Card |
| MCP | Maintenance Care Plan - a branded term for an Annual Maintenance Contract offered to vehicle owners | AMC, Annual Maintenance Contract | AMC Enrollment, AMC Cancellation |
| MCP Cancellation | The process of terminating an active MCP/AMC contract before its natural expiry, resulting in a partial refund to the customer | AMC Cancellation | AMC, Cancel Charges, Net Refund Amount |
| Net Refund Amount | The final refund payable to the customer after deducting cancellation charges and adding applicable tax refunds | Refund Amount | Cancel Charges, Labour Refund |
| Odometer Reading | Vehicle mileage recorded at the time of AMC enrollment, displayed on the contract detail screen | Mileage | Expiry Mileage |
| Parts | Spare parts component within an AMC package; has its own allocated amount, used amount, balance, refund, and tax fields | Part Amount | Labour, Consumables |
| PCK | PL/SQL Package (`.pck` file) - a named collection of database procedures and functions; PKG_AMC, PKG_LOYALTY, and PK_VALIDATE_BACK_DATE are used in this form | Package | PLD, Stored Procedure |
| PKG_AMC | Database package providing AMC cancellation refund calculation logic; SP_POP_CANCEL_DTL is the key routine invoked from the form | AMC Package | SP_POP_CANCEL_DTL, PCK |
| PKG_LOYALTY | Database package providing loyalty programme integration routines; used to retrieve card details and post cancellation transactions | Loyalty Package | Loyalty Card, Loyalty Points |
| PK_VALIDATE_BACK_DATE | Database package responsible for generating sequential document (credit note) numbers from the document master | Document Number Package | ACR, Credit Note Number |
| PLD | PL/SQL Library (`.pld` file) - a shared program library containing reusable Oracle Forms routines; DPL.pld is the primary library for this form | Program Library | DPL |
| Principal | The vehicle manufacturer or brand represented by a numeric code (principal_map_cd); used to scope all data and document generation | Principal Map Code | Dealer, MCP |
| Record Group | An Oracle Forms query result set used to populate LOV lists; RG_CNCL_CHG and RG_CANC are defined for this form | - | LOV |
| Reg Number | Vehicle registration number - the government-issued plate number used to identify and search for an AMC contract | Registration Number, Reg No | VIN, Chassis Number |
| SBC | Swachh Bharat Cess - a legacy Indian cess applied on service tax before GST implementation | Swachh Bharat Cess | KKC, Service Tax, GST |
| Service Tax | Pre-GST indirect tax applied on service amounts within an AMC package; shown as a component in package and refund calculations | SRV_TAX | SBC, KKC, GST |
| SRV_MCPCANCEL | The DMS message type code identifying an MCP cancellation event pushed to the DMS integration layer after commit | - | DMS, Post-Database-Commit |
| VIN | Vehicle Identification Number - a 17-character unique identifier assigned to each vehicle at manufacture; used as a primary search key for AMC contracts | Chassis VIN | Registration Number, Chassis Number |
| VT_AMC_CNCL | The Oracle Forms module identifier for the MCP AMC Cancellation form | vt_amc_cncl | AMC Cancellation, MCP |

---

---

## 8. Technical Inventory

*Complete inventory of Oracle Forms components including blocks, items, triggers, canvases, and global variables.*

### 8.1 Form Architecture

**Form Module Details:**

- Form Name: vt_amc_cncl (VT_AMC_CNCL)
- Form Module XML Title: MODULE2
- Oracle Forms Version: 12c (Module version 122010400)
- Parent Object Library: DPL.olb (PC_FORM property class)
- Attached Libraries: DPL (DPL.pld program library), D2KWUTIL, WEBUTIL (webutil.olb)
- First Navigation Block: -
- Console Window: WN_MAIN (inherited from DPL.olb object group at runtime)
- Compile Dependencies: Requires DPL.olb, DPL.pld, WEBUTIL.olb, database packages PKG_AMC, PKG_LOYALTY, PK_VALIDATE_BACK_DATE
- Source artifacts: `vt_amc_cncl_fmb.xml`; OLB `DPL.olb`; DPL (DPL.pld program library); D2KWUTIL; WEBUTIL (webutil.olb); PCK `PKG_AMC.pck`; PCK `PKG_FDI.pck`; PCK `PKG_LOYALTY.pck`; PCK `PK_VALIDATE_BACK_DATE.pck`

### 8.1.1 Global Variables

| Global Variable | Data Type | Set Location | Purpose |
| :--- | :--- | :--- | :--- |
| APP_LOG | Char | Trigger | Application logging flag; when Y, starts stop-watch timer at form open |
| COMP_FA | Char | ProgramUnit / Trigger | Company/FA code for the current dealer session |
| CURRENCY | Char | Trigger | Currency code for the current session context |
| DEALER | Char | ProgramUnit / Trigger | Dealer map code for the current session context |
| FIN_BEG | Char | Trigger | Financial year begin date for the current session |
| FIN_END | Char | Trigger | Financial year end date for the current session |
| LOC_CD | Char | ProgramUnit / Trigger | Location code for the current dealer session |
| PARENT_GROUP | Char | ProgramUnit / Trigger | Parent dealer group code used for access and data scoping |
| PRINCIPAL | Char | ProgramUnit / RecordGroup / Trigger | Principal map code (manufacturer/brand) for the session |
| PRINTOUTPUT | Char | ProgramUnit | Report print output file name set after report submission |
| P_FIN_YR | Char | ProgramUnit / Trigger | Current financial year used for credit note number generation |
| REPORTHANDLE | Char | ProgramUnit | Report job handle returned after submitting print report |
| REP_SERVER | Char | ProgramUnit | Report server name used to run the AMC cancellation report |
| TALLY_INTEGRATION | Char | Trigger | Flag indicating whether Tally accounting integration is enabled for the session |
| USERID | Char | ProgramUnit / Trigger | Logged-in user ID recorded as created-by and for DMS push messages |
| USER_NAME | Char | Trigger | Display name of the logged-in user for session context |

### 8.1.2 Form Parameters

*All 7 ModuleParameter entries from vt_amc_cncl_fmb.xml.*

| Parameter | Data Type | Default | Description |
| :--- | :--- | :--- | :--- |
| P_QUERY | Char | N | When Y, opens the form in query mode; controls whether the initial search block is pre-executed |
| P_OKFOR_SAVE | Char | N | Flag indicating the form is in a state that permits saving; controls save eligibility |
| P_SAVE | Char | N | When Y, triggers an automatic save on form load; used when calling form from parent context |
| CLOSE | Char | N | When Y, signals the form to close automatically after an operation; used for batch or chain operations |
| CHECK_NEW | Char | Y | Controls whether new-record validation checks are enforced on entry |
| NEW_ITEM | Char | Y | Indicates that a new item context is being created; controls item-level initialisation |
| NEW_REC | Char | N | When Y, initialises the form for a new record entry rather than a query |

**Total Parameters:** 7

### 8.2 Blocks

| Block Name | Query Data Source | Records | Q/I/U/D | Key Mode | Master-Detail Relationship |
| :--- | :--- | :--- | :--- | :--- | :--- |
| CB_VT_AMC_ENROLL | - | 1 | N/N/N/N | Default | Control - search entry block for AMC cancellation lookup |
| B_VH_AMC_ENQ | - | 1 | N/N/N/N | Delayed | Display block for AMC enrollment detail; no direct DML (DML handled programmatically by SP_INSERT_CHARGES) |

**Total Blocks:** 2 business blocks

### 8.2.1 Block WhereClause and OrderByClause

*Block query scope from vt_amc_cncl_fmb.xml. **Description** explains filter and sort in business terms; **Order By** and **Where Clause** columns retain verbatim XML text for migration.*

| Block | Description | Order By (XML) | Where Clause (XML) |
| :--- | :--- | :--- | :--- |
| - | No blocks with WhereClause/OrderByClause in vt_amc_cncl_fmb.xml | - | - |

### 8.3 Items Summary

*Complete item inventory from `vt_amc_cncl_fmb.xml`.*

**Block counts:**

*Database / non-database counts derived from XML.*

| Block | Total Items | Database Items | Non-Database Items |
| :--- | ---: | ---: | ---: |
| CB_VT_AMC_ENROLL | 6 | 0 | 6 |
| B_VH_AMC_ENQ | 72 | 47 | 25 |
| CB_ERR | 1 | 0 | 1 |
| PB_BLK | 14 | 0 | 14 |
| **Total** | **93** | **47** | **46** |

**Item detail (all 93 items):**

| Block | Item Name | DatabaseItem | Description |
| :--- | :--- | :--- | :--- |
| CB_VT_AMC_ENROLL | NB_AMC_NUM | false | MCP (AMC) enrollment number search field; user-entered or looked-up |
| CB_VT_AMC_ENROLL | NB_REG_NUM | false | Vehicle registration number search field for AMC lookup |
| CB_VT_AMC_ENROLL | NB_AMC_NUM1 | false | Internal copy of the resolved AMC number used for detail fetch |
| CB_VT_AMC_ENROLL | COPY_RIGHT | false | Displays copyright declaration text at form level |
| CB_VT_AMC_ENROLL | PB_CNCL | false | Cancel button - confirms and processes AMC cancellation |
| CB_VT_AMC_ENROLL | NB_VIN | false | Vehicle Identification Number search field for AMC lookup |
| B_VH_AMC_ENQ | PRINCIPAL_MAP_CD | true | Principal map code identifying the manufacturer/brand |
| B_VH_AMC_ENQ | AMC_NUM | false | AMC enrollment number displayed after record fetch |
| B_VH_AMC_ENQ | AMC_DATE | false | Date the AMC was originally enrolled |
| B_VH_AMC_ENQ | AMC_START_DATE | true | AMC coverage start date |
| B_VH_AMC_ENQ | AMC_END_DATE | true | AMC coverage end date |
| B_VH_AMC_ENQ | EXPIRY_MILEAGE | true | Mileage limit at which AMC coverage expires |
| B_VH_AMC_ENQ | EXPIRY_MONTH | false | Number of months until AMC expiry |
| B_VH_AMC_ENQ | REG_NUM | true | Vehicle registration number |
| B_VH_AMC_ENQ | VIN | true | Vehicle Identification Number |
| B_VH_AMC_ENQ | CHASSIS_NUM | true | Vehicle chassis number |
| B_VH_AMC_ENQ | ENGINE_NUM | true | Vehicle engine number |
| B_VH_AMC_ENQ | SVAR_CD | true | Super-variant code for the vehicle model |
| B_VH_AMC_ENQ | VARIANT_CD | true | Variant code for the vehicle |
| B_VH_AMC_ENQ | CUST_CD | true | Customer code from enrollment record |
| B_VH_AMC_ENQ | CUST_NAME | true | Customer name from enrollment record |
| B_VH_AMC_ENQ | CUST_ADDR1 | true | Customer address line 1 |
| B_VH_AMC_ENQ | CUST_ADDR2 | true | Customer address line 2 |
| B_VH_AMC_ENQ | CUST_ADDR3 | true | Customer address line 3 |
| B_VH_AMC_ENQ | CITY_CD | true | City code from enrollment record |
| B_VH_AMC_ENQ | CITY_DESC | false | City description resolved from city code |
| B_VH_AMC_ENQ | PHONE | true | Customer phone number |
| B_VH_AMC_ENQ | MOBILE | true | Customer mobile number |
| B_VH_AMC_ENQ | ODOMETER_READING | true | Vehicle odometer reading at enrollment |
| B_VH_AMC_ENQ | SELLING_PARENT_GROUP | true | Parent dealer group that sold the AMC |
| B_VH_AMC_ENQ | SELLING_DEALER_MAP_CD | true | Dealer map code of the selling dealer |
| B_VH_AMC_ENQ | SELLING_LOC_CD | true | Location code of the selling dealer |
| B_VH_AMC_ENQ | SELLING_COMP_FA | true | Company/FA code of the selling dealer |
| B_VH_AMC_ENQ | ENQ_NUM | false | Enquiry number associated with the AMC enrollment |
| B_VH_AMC_ENQ | PKG_CODE | true | AMC package code |
| B_VH_AMC_ENQ | AMC_TYPE | true | AMC type code (e.g. basic, comprehensive) |
| B_VH_AMC_ENQ | PKG_AMT | true | Total AMC package amount at enrollment |
| B_VH_AMC_ENQ | LABOUR_AMT | true | Labour component amount in the AMC package |
| B_VH_AMC_ENQ | PART_AMT | true | Parts component amount in the AMC package |
| B_VH_AMC_ENQ | CONSUMABLE_AMT | true | Consumables component amount in the AMC package |
| B_VH_AMC_ENQ | DISCOUNT_AMT | true | Discount applied on the AMC package |
| B_VH_AMC_ENQ | SRV_TAX_AMT | true | Service tax amount included in the AMC package |
| B_VH_AMC_ENQ | SBC_TAX_AMT | false | Swachh Bharat Cess tax amount in the AMC package |
| B_VH_AMC_ENQ | KKC_TAX_AMT | false | Krishi Kalyan Cess tax amount in the AMC package |
| B_VH_AMC_ENQ | TOT_BILL_AMT | true | Total billed amount for the AMC package |
| B_VH_AMC_ENQ | NB_MODEL_DESC | false | Vehicle model description resolved from super-variant code |
| B_VH_AMC_ENQ | NB_VARIANT_DESC | false | Vehicle variant description resolved from variant code |
| B_VH_AMC_ENQ | PKG_DESC | false | AMC package description resolved from package code |
| B_VH_AMC_ENQ | LABOUR_USED_AMT | true | Labour amount already consumed/used under the AMC |
| B_VH_AMC_ENQ | PART_USED_AMT | true | Parts amount already consumed/used under the AMC |
| B_VH_AMC_ENQ | CONSUMABLE_USED_AMT | true | Consumables amount already consumed/used under the AMC |
| B_VH_AMC_ENQ | PART_RFND_AMT | true | Parts refund amount on cancellation |
| B_VH_AMC_ENQ | CONS_RFND_AMT | true | Consumables refund amount on cancellation |
| B_VH_AMC_ENQ | CANCEL_CHARGES | false | Cancellation charge percentage selected by the user |
| B_VH_AMC_ENQ | CANCEL_DATE | false | Date on which the AMC cancellation is processed |
| B_VH_AMC_ENQ | NB_LBR_BAL | true | Remaining labour balance (enrolled minus used minus discount) |
| B_VH_AMC_ENQ | NB_PART_BAL | true | Remaining parts balance (enrolled minus used minus discount) |
| B_VH_AMC_ENQ | NB_CONS_BAL | true | Remaining consumables balance (enrolled minus used minus discount) |
| B_VH_AMC_ENQ | CANCEL_AMT | true | Total cancellation charge amount deducted from refund |
| B_VH_AMC_ENQ | LABOUR_RFND_AMT | true | Labour refund amount after applying cancellation charges |
| B_VH_AMC_ENQ | SRV_TAX_AMT_RFND | true | Service tax refund amount on cancellation |
| B_VH_AMC_ENQ | NB_LBR_TAX | false | Labour tax component of the refund amount |
| B_VH_AMC_ENQ | SBC_TAX_AMT_RFND | false | SBC tax refund amount on cancellation |
| B_VH_AMC_ENQ | NB_PART_TAX | false | Parts tax component of the refund amount |
| B_VH_AMC_ENQ | KKC_TAX_AMT_RFND | false | KKC tax refund amount on cancellation |
| B_VH_AMC_ENQ | NB_CONS_TAX | false | Consumables tax component of the refund amount |
| B_VH_AMC_ENQ | EMAIL | true | Customer email address from enrollment record |
| B_VH_AMC_ENQ | NET_RFND_AMT | true | Net refund amount payable to the customer after cancellation |
| B_VH_AMC_ENQ | CANC_REASON | false | Cancellation reason selected from LOV by the user |
| B_VH_AMC_ENQ | NB_TOT_TAX | false | Total tax refund amount (sum of all tax components) |
| B_VH_AMC_ENQ | NB_TOT_RFND | false | Total refund amount before tax (sum of all service component refunds) |
| B_VH_AMC_ENQ | NB_LOY_CARD_TYPE | false | Loyalty card type associated with the vehicle |
| B_VH_AMC_ENQ | NB_LOY_CARD_NUM | false | Loyalty card number associated with the vehicle |
| B_VH_AMC_ENQ | NB_LOY_REG_NUM | false | Registered mobile number on the loyalty card |
| B_VH_AMC_ENQ | NB_LOY_BAL_POINT | false | Current loyalty point balance on the card |
| B_VH_AMC_ENQ | NB_LOY_BAL_RS | false | Current loyalty balance in rupee equivalent |
| B_VH_AMC_ENQ | LOYL_AWARD_PTS | true | Loyalty points awarded at the time of AMC enrollment |
| B_VH_AMC_ENQ | LOYL_REDEEM_PTS | true | Loyalty points redeemed at the time of AMC enrollment |
| CB_ERR | TXT_ERR | false | Error message display item in the inherited error block; shows formatted error or informational text to the user (inherited from DPL.olb via CB_ERR block) |
| PB_BLK | PB_EXIT | false | Toolbar Exit button; closes the current form (inherited from DPL.olb via PB_BLK block) |
| PB_BLK | PB_LIST | false | Toolbar List button; invokes the LOV for the current item (inherited) |
| PB_BLK | PB_INSERT | false | Toolbar Insert button; initiates a new record in the current block (inherited) |
| PB_BLK | PM_CONT | false | Toolbar Contents/menu button; navigates to the application menu or contents (inherited) |
| PB_BLK | PB_DEL | false | Toolbar Delete button; marks the current record for deletion (inherited) |
| PB_BLK | PB_CANCEL | false | Toolbar Cancel button; cancels pending changes in the current block (inherited) |
| PB_BLK | PB_SAVE | false | Toolbar Save button; commits the current transaction (inherited; commit is suppressed at form level for this form) |
| PB_BLK | PB_PRINT | false | Toolbar Print button; triggers the print report workflow (inherited) |
| PB_BLK | PB_CUT | false | Toolbar Cut button; cuts the selected text from the current item (inherited) |
| PB_BLK | PB_COPY | false | Toolbar Copy button; copies the selected text from the current item (inherited) |
| PB_BLK | PB_PASTE | false | Toolbar Paste button; pastes clipboard text into the current item (inherited) |
| PB_BLK | PB_ERR_EXIT | false | Error dialog Exit button; dismisses the error window without action (inherited) |
| PB_BLK | PB_ERR_OK | false | Error dialog OK button; acknowledges and dismisses the error message (inherited) |
| PB_BLK | PB_BACK | false | Toolbar Back button; navigates to the previous form or calling context (inherited) |

### 8.4 List of Values

| LOV Name | Title | Record Group | Attached Block.Item |
| :--- | :--- | :--- | :--- |
| LV_CANC | CancellationReasons | RG_CANC | B_VH_AMC_ENQ.CANC_REASON |

**Total LOVs:** 1

### 8.5 Alerts

| Alert Name | Title | Message Text | Calling Context |
| :--- | :--- | :--- | :--- |
| AL_PRINT | Print | (set at runtime) | Inherited from DPL.olb object group; invoked by ASK_PRINT library routine when the user selects a print destination |
| AL_ERRINFO | Error | (set at runtime) | Inherited from DPL.olb object group; invoked by DISP_TEXT and RAISE_ERROR library routines to display formatted error messages |
| AL_NOTE | Note | (set at runtime) | Inherited from DPL.olb object group; invoked by DISP_TEXT library routine to display informational messages |
| AL_REPORT | AMC Enrollment | Do you want to? | Invoked by CALL_REPORT_ENQ program unit to prompt the user before running the vr_amc_cncl cancellation report |
| AL_CONFIRM | Caution | (set at runtime) | Inherited from DPL.olb object group; invoked by GENERAL.ASK_CONFIRM to prompt the user for confirmation before destructive operations |

**Total Alerts:** 5

### 8.6 Program Units

*Authoritative catalogue of **5 form-local program units**. Database packages and standalone procedures are in **Section 15.2**; PLD shared-library routines are in **Section 18**.*

| Program Unit | Type | Calls | Description |
| :--- | :--- | :--- | :--- |
| CALL_REPORT_ENQ | Procedure | AL_REPORT alert, RUN_REPORT_OBJECT, GENERAL.PROC_REPORT_CALL, GENERAL.PROC_TIMER, report server | Displays the AMC cancellation report alert and runs the vr_amc_cncl report to PDF or printer based on user choice |
| PROC_AMC_DETAILS | Procedure | VH_AMC_ENROL (SELECT), VD_AMC_ENROL (SELECT), VM_SVAR (SELECT), GM_VAR (SELECT), GM_CITY (SELECT), VM_AMC_PKG (SELECT), PKG_LOYALTY.SP_GET_VIN_LOYALTY_DTL, GENERAL.DISP_TEXT | Loads all AMC enrollment details and loyalty card information into the detail block after the user selects an enrollment |
| POP_LIST | Procedure | Populate_Group('RG_CNCL_CHG'), Populate_List('CANCEL_CHARGES') | Populates the cancellation charges drop-down list from the RG_CNCL_CHG record group |
| POP_PKG_DETAILS_NEW | Procedure | GBL_AMC_DTL (SELECT) | Reads cancellation charge detail rows from the session temp table and aggregates refund amounts by service type (labour, parts, consumables) into the detail block |
| SP_INSERT_CHARGES | Procedure | PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM, VD_AMC_CANCELCHARGES (INSERT from GBL_AMC_CHARGES), VH_AMC_ENROL (UPDATE), GM_VIN_EXT (UPDATE), PKG_LOYALTY.SP_INS_LOYALTY_TRANSACTIONS, GENERAL.DISP_TEXT | Generates a credit note number, inserts cancellation charge lines, updates the AMC enrollment record with cancellation details and refund amounts, updates the VIN expiry date, and posts a loyalty cancellation transaction |

**Total Program Units:** 5

### 8.7 Triggers

**Item-Level Trigger Types (reference):**

| Trigger Name | Purpose |
| :--- | :--- |
| WHEN-VALIDATE-ITEM | Validates field when user leaves item |
| KEY-* | Keyboard actions - commit, exit, LOV, navigation |
| WHEN-NEW-BLOCK-INSTANCE | Initializes block on entry |
| WHEN-BUTTON-PRESSED | Executes button action |
| PRE-INSERT / POST-INSERT | Before/after record creation |
| WHEN-LIST-CHANGED | Dropdown selection changed |
| PRE-QUERY / POST-QUERY | Before/after query execution |
| WHEN-CHECKBOX-CHANGED | Checkbox toggled |
| WHEN-VALIDATE-RECORD | Validates entire record before leaving row |

**DPL library routines invoked from triggers and program units:**

| Routine | Type | Called From | Purpose |
| :--- | :--- | :--- | :--- |
| GENERAL.ASK_CONFIRM | Library routine | CB_VT_AMC_ENROLL.PB_CNCL | Displays the AL_CONFIRM alert with a supplied message and returns the user's Yes/No choice; used in the cancel button handler to obtain explicit user confirmation before processing cancellation |
| GENERAL.CHECK_NULL | Library routine | B_VH_AMC_ENQ.CANCEL_CHARGES, B_VH_AMC_ENQ.CANC_REASON, CB_VT_AMC_ENROLL.PB_CNCL | Raises an error and halts execution if the supplied field value is null |
| GENERAL.DISP_TEXT | Library routine | B_VH_AMC_ENQ, B_VH_AMC_ENQ.CANCEL_CHARGES, CB_VT_AMC_ENROLL.NB_AMC_NUM, CB_VT_AMC_ENROLL.NB_AMC_NUM1, CB_VT_AMC_ENROLL.NB_REG_NUM, CB_VT_AMC_ENROLL.NB_VIN, Form level, ProgramUnit: PROC_AMC_DETAILS, ProgramUnit: SP_INSERT_CHARGES | Displays a message alert box with a specified text and title (Error or Note); used for all user-facing error and informational messages |
| GENERAL.PROC_REPORT_CALL | Library routine | ProgramUnit: CALL_REPORT_ENQ | Submits the report object in batch/file mode to the report server and returns the report job handle and output file name |
| GENERAL.RAISE_ERROR | Library routine | Form level | Looks up the error message text for a given code and displays it via DISP_TEXT; raises FORM_TRIGGER_FAILURE for error-type messages |

### 8.7.1 Inactive / Commented-Out Trigger Register

*Triggers and field validations where XML source is `null;`, fully block-commented, or legacy code preserved but not executed. Do **not** migrate these as active business requirements.*

| Status | Block | Item | Trigger | Former behaviour (preserved in comments) | Disabled since / note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Inactive stub** | Form | - | KEY-COMMIT | Commit the form transaction | Body is `null;` - commit is suppressed at form level; DML is handled programmatically by SP_INSERT_CHARGES |
| **Inactive stub** | Form | - | FT_SAVE | Save/commit the current record via the toolbar Save button | Body is `null;` - toolbar save is suppressed; DML is handled programmatically by SP_INSERT_CHARGES |
| **Inactive stub** | Form | - | FT_INSERT | Insert a new record via the toolbar Insert button | Body is `null;` - toolbar insert is suppressed; new record entry is controlled via the search block |
| **Inactive stub** | Form | - | FT_DEL | Delete the current record via the toolbar Delete button | Body is `null;` - toolbar delete is suppressed; cancellation is handled exclusively via SP_INSERT_CHARGES |
| **Commented out** | Form | - | WHEN-NEW-FORM-INSTANCE | Initialise global variables and session context on form open | Inherited trigger body is overridden/commented out at form level; inherited version from DPL.olb object group applies at runtime |
| **Inactive stub** | B_VH_AMC_ENQ | - | KEY-UP | Navigate to the previous record in the block | Body is `null;` - upward record navigation is disabled in the enquiry block |
| **Inactive stub** | B_VH_AMC_ENQ | - | KEY-DOWN | Navigate to the next record in the block | Body is `null;` - downward record navigation is disabled in the enquiry block |

*Additional null-only or partially commented triggers exist on estimation and legacy blocks - see XML `TriggerText` starting with `null;` or `/*`.*

**Complete trigger inventory (51 business triggers):**
*vt_amc_cncl_fmb.xml contains Trigger elements.*

| Trigger Name | Block | Item | Called From / Context | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| ON-ERROR | Form | - | Form level | Intercepts Oracle Forms errors; displays a formatted error message via DISP_TEXT for specific error codes (e.g. invalid date); raises FORM_TRIGGER_FAILURE |
| ON-MESSAGE | Form | - | Form level | Intercepts Forms system messages and redirects specific message numbers (40209, 40207) to a styled error display |
| KEY-EXIT | Form | - | Form level | Clears application info from the session and exits the form without validation |
| KEY-LISTVAL | Form | - | Form level | Displays the LOV associated with the current item; navigates to the next item on successful selection |
| KEY-COMMIT | Form | - | Form level | **INACTIVE** - body is `null;`; commit is handled programmatically by SP_INSERT_CHARGES |
| KEY-CLRFRM | Form | - | Form level | Clears the form without validation and resets the copyright declaration display item |
| KEY-OTHERS | Form | - | Form level | Inherited from DPL.olb object group; suppresses unhandled key actions to prevent default Forms behaviour (inherited) |
| KEY-NEXT-ITEM | Form | - | Form level | Inherited from DPL.olb object group; navigates to the next item in the default tab order (inherited) |
| KEY-PREV-ITEM | Form | - | Form level | Inherited from DPL.olb object group; navigates to the previous item in the default tab order (inherited) |
| KEY-NXTBLK | Form | - | Form level | Inherited from DPL.olb object group; navigates to the next block (inherited) |
| KEY-PRVBLK | Form | - | Form level | Inherited from DPL.olb object group; navigates to the previous block (inherited) |
| KEY-DOWN | Form | - | Form level | Inherited from DPL.olb object group; navigates to the next record at form level (inherited) |
| KEY-UP | Form | - | Form level | Inherited from DPL.olb object group; navigates to the previous record at form level (inherited) |
| FT_SAVE | Form | - | Form level | **INACTIVE** - body is `null;`; toolbar save is suppressed; DML handled by SP_INSERT_CHARGES (inherited trigger overridden) |
| FT_CANCEL | Form | - | Form level | Inherited from DPL.olb object group; cancels pending changes in the current block when the toolbar Cancel button is pressed (inherited) |
| FT_INSERT | Form | - | Form level | **INACTIVE** - body is `null;`; toolbar insert is suppressed; new record entry is controlled via the search block (inherited trigger overridden) |
| FT_DEL | Form | - | Form level | **INACTIVE** - body is `null;`; toolbar delete is suppressed; cancellation handled exclusively via SP_INSERT_CHARGES (inherited trigger overridden) |
| FT_LIST | Form | - | Form level | Inherited from DPL.olb object group; invokes the LOV for the current item when the toolbar List button is pressed (inherited) |
| FT_PRINT | Form | - | Form level | Inherited from DPL.olb object group; triggers the print report workflow when the toolbar Print button is pressed (inherited) |
| WHEN-NEW-FORM-INSTANCE | Form | - | Form level | **COMMENTED OUT** at form level; inherited version from DPL.olb object group initialises global variables and session context on form open (inherited) |
| PRE-FORM | Form | - | Form level | Sets Oracle application info with the form name for session monitoring; starts the stop-watch timer when application logging is enabled |
| WHEN-TIMER-EXPIRED | Form | - | Form level | Delegates timer expiry handling to GENERAL.PROC_TIMER_EXPIRED to poll and display print report output |
| POST-DATABASE-COMMIT | Form | - | Form level | Pushes the MCP cancellation event to the DMS integration layer via SP_PUSH_DMS_MESSAGE after a successful commit |
| WHEN-VALIDATE-ITEM | CB_VT_AMC_ENROLL | NB_AMC_NUM | CB_VT_AMC_ENROLL.NB_AMC_NUM | Validates that the entered AMC number exists, belongs to the current dealer/location, is not already cancelled, and is not expired; copies the value to NB_AMC_NUM1 |
| KEY-NEXT-ITEM | CB_VT_AMC_ENROLL | NB_AMC_NUM | CB_VT_AMC_ENROLL.NB_AMC_NUM | Navigates to the AMC detail block when an AMC number is entered; otherwise moves to the registration number field |
| WHEN-VALIDATE-ITEM | CB_VT_AMC_ENROLL | NB_REG_NUM | CB_VT_AMC_ENROLL.NB_REG_NUM | Validates the registration number in GM_VIN, finds the active AMC enrollment for the registration number, and populates NB_AMC_NUM1 |
| KEY-NEXT-ITEM | CB_VT_AMC_ENROLL | NB_REG_NUM | CB_VT_AMC_ENROLL.NB_REG_NUM | Navigates to the AMC detail block when a registration number is entered; otherwise moves to the VIN field |
| WHEN-VALIDATE-ITEM | CB_VT_AMC_ENROLL | NB_AMC_NUM1 | CB_VT_AMC_ENROLL.NB_AMC_NUM1 | Re-validates the resolved AMC number for cancellation and expiry status |
| KEY-NEXT-ITEM | CB_VT_AMC_ENROLL | NB_AMC_NUM1 | CB_VT_AMC_ENROLL.NB_AMC_NUM1 | Navigates to the registration number field in the detail block if AMC number is present; otherwise returns to registration number entry |
| WHEN-BUTTON-PRESSED | CB_VT_AMC_ENROLL | PB_CNCL | CB_VT_AMC_ENROLL.PB_CNCL | Validates mandatory cancellation fields, prompts user to confirm via GENERAL.ASK_CONFIRM, then calls SP_INSERT_CHARGES to process cancellation, posts FDI data, generates report, and clears the form |
| WHEN-VALIDATE-ITEM | CB_VT_AMC_ENROLL | NB_VIN | CB_VT_AMC_ENROLL.NB_VIN | Validates the VIN in GM_VIN, finds the active AMC enrollment for the VIN, and populates NB_AMC_NUM1 |
| KEY-NEXT-ITEM | CB_VT_AMC_ENROLL | NB_VIN | CB_VT_AMC_ENROLL.NB_VIN | Navigates to the AMC detail block when a VIN is entered; otherwise returns to the AMC number field |
| WHEN-NEW-BLOCK-INSTANCE | B_VH_AMC_ENQ | - | B_VH_AMC_ENQ | Calls PROC_AMC_DETAILS to load AMC enrollment details when the block is entered, provided NB_AMC_NUM1 is populated |
| KEY-UP | B_VH_AMC_ENQ | - | B_VH_AMC_ENQ | **INACTIVE** - body is `null;`; upward record navigation is disabled in the enquiry block |
| KEY-DOWN | B_VH_AMC_ENQ | - | B_VH_AMC_ENQ | **INACTIVE** - body is `null;`; downward record navigation is disabled in the enquiry block |
| WHEN-VALIDATE-ITEM | B_VH_AMC_ENQ | CANCEL_CHARGES | B_VH_AMC_ENQ.CANCEL_CHARGES | Validates that a cancellation charge percentage has been selected before allowing navigation away from the field |
| WHEN-LIST-CHANGED | B_VH_AMC_ENQ | CANCEL_CHARGES | B_VH_AMC_ENQ.CANCEL_CHARGES | Calls PKG_AMC.SP_POP_CANCEL_DTL with the selected charge percentage to compute refund amounts, then calls POP_PKG_DETAILS_NEW to populate the detail block |
| WHEN-VALIDATE-ITEM | B_VH_AMC_ENQ | CANC_REASON | B_VH_AMC_ENQ.CANC_REASON | Validates that a cancellation reason has been provided before allowing navigation |
| KEY-NEXT-ITEM | B_VH_AMC_ENQ | CANC_REASON | B_VH_AMC_ENQ.CANC_REASON | Moves focus to the cancel button (PB_CNCL) after the cancellation reason is entered |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EXIT | PB_BLK.PB_EXIT (inherited) | Closes the current form when the toolbar Exit button is pressed (inherited from DPL.olb) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_LIST | PB_BLK.PB_LIST (inherited) | Invokes the LOV for the current item when the toolbar List button is pressed (inherited from DPL.olb) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_INSERT | PB_BLK.PB_INSERT (inherited) | Initiates a new record in the current block when the toolbar Insert button is pressed (inherited from DPL.olb) |
| WHEN-BUTTON-PRESSED | PB_BLK | PM_CONT | PB_BLK.PM_CONT (inherited) | Navigates to the application menu or contents when the Contents button is pressed (inherited from DPL.olb) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_DEL | PB_BLK.PB_DEL (inherited) | Marks the current record for deletion when the toolbar Delete button is pressed (inherited from DPL.olb) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CANCEL | PB_BLK.PB_CANCEL (inherited) | Cancels pending changes in the current block when the toolbar Cancel button is pressed (inherited from DPL.olb) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SAVE | PB_BLK.PB_SAVE (inherited) | Commits the current transaction when the toolbar Save button is pressed; suppressed at form level by null KEY-COMMIT (inherited from DPL.olb) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PRINT | PB_BLK.PB_PRINT (inherited) | Triggers the print report workflow when the toolbar Print button is pressed (inherited from DPL.olb) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CUT | PB_BLK.PB_CUT (inherited) | Cuts the selected text from the current item when the toolbar Cut button is pressed (inherited from DPL.olb) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_COPY | PB_BLK.PB_COPY (inherited) | Copies the selected text from the current item when the toolbar Copy button is pressed (inherited from DPL.olb) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PASTE | PB_BLK.PB_PASTE (inherited) | Pastes clipboard text into the current item when the toolbar Paste button is pressed (inherited from DPL.olb) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_BACK | PB_BLK.PB_BACK (inherited) | Navigates to the previous form or calling context when the toolbar Back button is pressed (inherited from DPL.olb) |

### 8.8 Canvas and Window Inventory

**Windows:**

| Window | Title | Primary Canvas |
| :--- | :--- | :--- |
| WIN_ERR | - | CN_ERR (inherited from DPL.olb) |
| WN_MAIN | MCP Termination (Rel:1.1.8) | CN_MAIN (inherited from DPL.olb) |

**Canvases:**

| Canvas | Type | Window |
| :--- | :--- | :--- |
| CN_TOOL | Content | WN_MAIN (inherited from DPL.olb) |
| CN_MAIN | Content | WN_MAIN (inherited from DPL.olb) |
| CN_DEF | Stacked | WN_MAIN |
| CN_ERR | Content | WIN_ERR (inherited from DPL.olb) |

---

### 8.9 Editors

*No editors found in vt_amc_cncl_fmb.xml.*

### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

#### 8.10.1 Visual Attributes (form-defined)

*2 VisualAttribute elements defined at form level (not inherited from DPL.olb).*

| Visual Attribute |
| :--- |
| VA_DEFAULT |
| VA_MANDATORY |

#### 8.10.2 Property Classes (form-defined)

*Form-local PropertyClass elements.*

*No form-local property classes found in vt_amc_cncl_fmb.xml.*

#### 8.10.3 Object Groups

*Object groups bundle inherited triggers and visual objects applied form-wide at runtime. All entries below are sourced from the DPL.olb object group and applied to this form at runtime.*

| Object Group Child | Type |
| :--- | :--- |
| KEY-OTHERS | Inherited trigger |
| KEY-NEXT-ITEM | Inherited trigger |
| KEY-PREV-ITEM | Inherited trigger |
| KEY-NXTBLK | Inherited trigger |
| KEY-PRVBLK | Inherited trigger |
| KEY-DOWN | Inherited trigger |
| KEY-UP | Inherited trigger |
| CN_ERR | Inherited canvas |
| VA_DISP | Inherited visualattribute |
| CB_ERR | Inherited block |
| VA_LOV | Inherited visualattribute |
| VA_TRNI_DT | Inherited visualattribute |
| VA_TITLE | Inherited visualattribute |
| VA_ALERT | Inherited visualattribute |
| VA_BUTN | Inherited visualattribute |
| VA_TEXT | Inherited visualattribute |
| VA_MPROMPT | Inherited visualattribute |
| VA_OPROMPT | Inherited visualattribute |
| VA_MAND | Inherited visualattribute |
| VA_NUM | Inherited visualattribute |
| VA_DESC | Inherited visualattribute |
| VA_ICONIC_BUTN | Inherited visualattribute |
| VA_RB | Inherited visualattribute |
| VA_CB | Inherited visualattribute |
| WN_MAIN | Inherited window |
| POP_MAIN | Inherited trigger |
| CN_MAIN | Inherited canvas |
| CN_TOOL | Inherited canvas |
| PB_BLK | Inherited block |
| AL_ERRINFO | Inherited alert |
| AL_NOTE | Inherited alert |
| AL_CONFIRM | Inherited alert |
| WIN_ERR | Inherited window |
| AL_PRINT | Inherited alert |
| FT_SAVE | Inherited trigger |
| FT_CANCEL | Inherited trigger |
| FT_INSERT | Inherited trigger |
| FT_DEL | Inherited trigger |
| FT_LIST | Inherited trigger |
| FT_PRINT | Inherited trigger |
| WHEN-NEW-FORM-INSTANCE | Inherited trigger |

### 8.11 DataSourceColumn Inventory

*35 DataSourceColumn elements across 1 blocks - formal query column-to-block mapping from vt_amc_cncl_fmb.xml.*

#### B_VH_AMC_ENQ (35 columns)

| Column (DSCName) | Data Type |
| :--- | :--- |
| PRINCIPAL_MAP_CD | NUMBER |
| EWARR_NUM | VARCHAR2 |
| EWARR_DATE | DATE |
| CUST_CD | VARCHAR2 |
| VIN | VARCHAR2 |
| REG_NUM | VARCHAR2 |
| MUL_FIN_YN | VARCHAR2 |
| MUL_FIN_NUM | VARCHAR2 |
| OPTION_CD | VARCHAR2 |
| MAX_MILEAGE | NUMBER |
| VALID_UPTO | DATE |
| PAY_MODE_CD | VARCHAR2 |
| BOOKLET_NUM | VARCHAR2 |
| INSTRUMENT_FAVOUR | VARCHAR2 |
| BRANCH_NAME | VARCHAR2 |
| INSTRUMENT_NUM | VARCHAR2 |
| INSTRUMENT_DATE | DATE |
| BANK_NAME | VARCHAR2 |
| INSTRUMENT_AMT | VARCHAR2 |
| CREDIT_CARD_NUM | VARCHAR2 |
| EXPIRY_DATE | DATE |
| SERVICE_PER | NUMBER |
| SERVICE_AMT | NUMBER |
| PREMIMUM_RECD | NUMBER |
| PREMIMUM_ACTL | NUMBER |
| PREMIMUM_CAL | NUMBER |
| EWARR_AMT | NUMBER |
| PARENT_GROUP | VARCHAR2 |
| DEALER_MAP_CD | NUMBER |
| COMP_FA | VARCHAR2 |
| LOC_CD | VARCHAR2 |
| CREATED_DATE | DATE |
| CREATED_BY | VARCHAR2 |
| MODIFIED_DATE | DATE |
| MODIFIED_BY | VARCHAR2 |

**Total DataSourceColumns:** 35 across 1 blocks

## 9. Object Library

*The form references objects from the DPL Object Library (DPL_olb.xml). The library contains Visual Attributes defining colour/font styles, Property Classes providing reusable item-level configuration templates, and one Object Group providing standard form triggers. The form references two Visual Attributes and a subset of Property Classes from this library.*

Source OLB file(s): DPL_olb.xml

| Name | Type | Description | Used By (count) | Sample Items |
| ---- | ---- | ----------- | --------------- | ------------ |
| VA_CB | VisualAttribute | Grey background, Arial 8pt, black foreground, transparent fill - for check-box items | not used in this form | N/A |
| VA_RB | VisualAttribute | Grey background, Arial 8pt, black foreground, transparent fill - for radio-button items | not used in this form | N/A |
| VA_ICONIC_BUTN | VisualAttribute | White background, black foreground, transparent fill - for iconic push buttons | not used in this form | N/A |
| VA_DESC | VisualAttribute | Grey background, Small Fonts 7pt, blue foreground - for description display items | not used in this form | N/A |
| VA_NUM | VisualAttribute | White background, Arial 8pt Medium, black foreground - for numeric text items | not used in this form | N/A |
| VA_MAND | VisualAttribute | Cyan background, Arial 9pt Medium, black foreground - for mandatory entry fields | 2 items in this form | CANCEL_CHARGES, CANC_REASON |
| VA_OPROMPT | VisualAttribute | Optional prompt visual - white background, Arial 9pt, black prompt foreground | not used in this form | N/A |
| VA_MPROMPT | VisualAttribute | Mandatory prompt visual - white background, Arial 9pt, red prompt foreground | not used in this form | N/A |
| VA_TEXT | VisualAttribute | White background, Arial 9pt Medium, black foreground - standard text items | not used in this form | N/A |
| VA_BUTN | VisualAttribute | Grey background, Arial 10pt Bold, black foreground - for push buttons | not used in this form | N/A |
| VA_ALERT | VisualAttribute | Grey background, MT Extra 11pt Demilight, black foreground - for alert text | not used in this form | N/A |
| VA_TITLE | VisualAttribute | Grey background, Arial 10pt Bold, blue foreground - for title/label items | not used in this form | N/A |
| VA_TRNI_DT | VisualAttribute | White background, Courier Bold, black foreground - for transaction date fields | not used in this form | N/A |
| VA_LOV | VisualAttribute | Grey background, Arial 9pt, dark blue foreground - for LOV-linked items | not used in this form | N/A |
| VA_DEFAULT | VisualAttribute | r25g75b75 background, Arial 8pt Bold, black foreground - default display attribute | 1 item in this form | VA_DEFAULT reference on VA_DISP items |
| VA_DISP | VisualAttribute | r25g75b75 background, Arial 8pt Bold, black foreground - for display-only items (alias of VA_DEFAULT with explicit colour) | not used directly in this form | N/A |
| PC_DESC | PropertyClass | Left-justified display item, 250px wide, max 110 chars, white background, Arial 9pt, blue foreground, no bevel - for description display items | 1 item in this form | Items inheriting PC_DESC |
| PC_SC_DATE | PropertyClass | 73px wide, max 11 chars, grey background, Arial 8pt Bold, auto-hint date field for SC date entry (format DD-MM-YY / DD/MM/YY) | not used in this form | N/A |
| PC_TITLE | PropertyClass | Centred, grey background, Arial 10pt Bold, blue foreground, upper-case - for title/header items | not used in this form | N/A |
| PC_FORMAT | PropertyClass | Centred, 60px, max 12 chars, white background, Arial 9pt, upper-case - for formatted reference items | not used in this form | N/A |
| PC_MR_BLK | PropertyClass | Master-record block navigation class - navigates to next block on record change | not used in this form | N/A |
| PC_DISP | PropertyClass | Left-justified disabled display item, grey8 background, Arial 9pt, lowered bevel, not keyboard-navigable - for read-only display fields | 6 items in this form | AMC_DATE, AMC_START_DATE, AMC_END_DATE, CUST_ADDR1, CUST_ADDR2, CUST_ADDR3 |
| PC_LOV | PropertyClass | LOV-linked text item, 250px wide, grey background, Arial 8pt, dark blue foreground, auto-select off - for LOV entry items | not used in this form | N/A |
| PC_FORM | PropertyClass | Form-level property class defining validation unit (Item), savepoint mode (off), console window, menu module, and standard form-level triggers (ON-ERROR, ON-MESSAGE, KEY-EXIT, KEY-LISTVAL, KEY-COMMIT, KEY-CLRFRM) | 1 form in this form | Form module CB_VT_AMC_ENROLL |
| PC_DISP_DATE | PropertyClass | Left-justified disabled display item, grey8 background, Arial 9pt, date data type, format DD-MM-RRRR - for read-only date display | not used directly in this form | N/A |
| PC_DISP_NUM | PropertyClass | Right-justified disabled display item, grey8 background, Arial 9pt, lowered bevel, numeric data type - for read-only numeric display | not used directly in this form | N/A |
| PC_DATE | PropertyClass | 60px, max 10 chars, white background, Arial 9pt, date data type, format DD-MM-RRRR, mouse navigate, hint for date entry format - for date entry fields | 1 item in this form | CANCEL_DATE |
| PC_DTTIME | PropertyClass | 80px, max 15 chars, Arial, date+time data type, format DD-MM-RRRR HH24:MI, initialised to current DB datetime - for date-and-time entry fields | not used in this form | N/A |
| PC_CB | PropertyClass | White background, Arial 9pt, check-box item type - for check-box items | not used in this form | N/A |
| PC_ALERT | PropertyClass | Grey background, MT Extra 11pt Demilight, alert item type | not used in this form | N/A |
| PC_MDATE | PropertyClass | Mandatory date entry, 60px, white background, red prompt foreground, format DD-MM-RRRR; includes WHEN-VALIDATE-ITEM trigger that checks the date field is not blank | not used in this form | N/A |
| PC_RB | PropertyClass | Grey background, Arial 9pt, radio-button item type | not used in this form | N/A |
| PC_WIND | PropertyClass | Window property class - resizable, hide-on-exit, grey background, Arial 10pt Bold, blue foreground, standard window dimensions | not used in this form | N/A |
| PC_CANV | PropertyClass | Canvas property class - white background, Arial, window WN_MAIN, raise on enter | not used in this form | N/A |
| PC_BUTN | PropertyClass | 42px wide push button, grey background, Arial 9pt Bold, not mouse-navigable - for standard action buttons | not used in this form | N/A |
| PC_TEXT | PropertyClass | Left-justified text item, white background, Arial 9pt, popup menu POP_MAIN, black foreground - for standard text entry | 3 items in this form | NB_AMC_NUM, NB_REG_NUM, AMC_NUM |
| PC_MTEXT | PropertyClass | Mandatory text item, left-justified, white background, Arial 9pt, red prompt foreground, popup menu POP_MAIN; includes WHEN-VALIDATE-ITEM trigger that checks the field is not blank | not used in this form | N/A |
| PC_UTEXT | PropertyClass | Upper-case text item, left-justified, white background, Arial 9pt, black prompt foreground, popup menu POP_MAIN | not used in this form | N/A |
| PC_MUTEXT | PropertyClass | Mandatory upper-case text item, red prompt foreground, popup menu POP_MAIN; includes WHEN-VALIDATE-ITEM that checks the field is not blank | not used in this form | N/A |
| PC_NUM | PropertyClass | Right-justified numeric text item, white background, Arial 9pt, lowest value 0, upper-case | 1 item in this form | PKG_AMT |
| PC_MNUM | PropertyClass | Mandatory numeric text item, right-justified, white background, red prompt foreground; includes WHEN-VALIDATE-ITEM that checks the value is non-zero | not used in this form | N/A |
| PC_ICONIC_BUTN | PropertyClass | Iconic push button, 20px, white background, no bevel, not mouse-navigable | not used in this form | N/A |
| PC_SCROLL | PropertyClass | Scrollbar width 13 - for scrollable blocks | not used in this form | N/A |
| OG_GROUP | ObjectGroup | Standard form object group containing common form-level triggers (WHEN-NEW-FORM-INSTANCE and associated standard behaviour). Referenced by this form via a subclassed object group child. | 1 reference in this form | Form module OG_GROUP reference |

---

## 10. Record Groups

*Lists all record groups, their LOV bindings, query logic, dynamic bindings, business purpose, and form usage.*

| Record Group | Type | Used By LOV | Display Column | Return Column | Dynamic Bindings | Purpose | Where Used |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| RG_CNCL_CHG | Query | - | LIST_DESC | LIST_CODE | No | Provides the list of applicable cancellation charge percentages for the AMC package | - |
| RG_CANC | Query | LV_CANC | LIST_CODE | LIST_DESC | No | Provides the list of valid cancellation reasons for the AMC cancellation transaction | LV_CANC -> B_VH_AMC_ENQ.CANC_REASON |

**Total Record Groups:** 2

## 11. Referenced Database Objects

*Database tables, views, and objects accessed by the form.*

### 11.1 Block-Table Binding Summary

| Block | Base Table | Primary Key Item | Database Item |
| :--- | :--- | :--- | :--- |
| CB_VT_AMC_ENROLL | - | - | No |
| B_VH_AMC_ENQ | - | - | No |

### 11.2 Referenced Database Objects

| Object | Schema | Used In | Description |
| :--- | :--- | :--- | :--- |
| `AM_DEALER_LOC_PARAM` | - | Trigger WHEN-NEW-FORM-INSTANCE | AMC dealer location parameter - stores dealer- and location-level configuration parameters read at form startup to initialise session context (e.g. dealer code, location defaults) |
| `AM_LIST` | - | RG_CANC | AMC list master - stores configurable lookup values including AMC cancellation reasons |
| `AM_LIST_RANGE` | - | RG_CNCL_CHG | AMC list range master - stores range-based lookup values including cancellation charge percentages |
| `GBL_AMC_DTL` | - | POP_PKG_DETAILS_NEW | Global AMC detail - session-scoped temporary table holding AMC package service line details for cancellation calculation |
| `GM_CITY` | - | PROC_AMC_DETAILS | Global master city - city code to city description lookup used to resolve customer city |
| `GM_VAR` | - | PROC_AMC_DETAILS | Global master variant - vehicle variant code to description lookup |
| `GM_VIN` | - | Trigger WHEN-VALIDATE-ITEM | Global master VIN - vehicle master table used to validate registration number and VIN entries |
| `GM_VIN_EXT` | - | SP_INSERT_CHARGES | Global master VIN extension - stores AMC expiry date per VIN; updated on AMC cancellation |
| `VD_AMC_CANCELCHARGES` | - | SP_INSERT_CHARGES | Vehicle dealer AMC cancel charges - transactional table recording charge line details inserted on AMC cancellation |
| `VD_AMC_ENROL` | - | PROC_AMC_DETAILS | Vehicle dealer AMC enrollment detail - detail-level service lines (labour/parts/consumables) for the enrolled AMC package |
| `VH_AMC_ENROL` | - | PROC_AMC_DETAILS, SP_INSERT_CHARGES, Trigger WHEN-VALIDATE-ITEM | Vehicle AMC enrollment header - master record for each AMC contract; read for validation and updated with cancellation details on processing |
| `VM_AMC_PKG` | - | PROC_AMC_DETAILS | Vehicle master AMC package - stores package descriptions and expiry month definitions per package code |
| `VM_SVAR` | - | PROC_AMC_DETAILS | Vehicle master super-variant - stores super-variant (model) description per principal |

**Total Referenced Objects:** 13

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure/Package Index

| Requirement ID | Procedure/Package | Purpose |
| -------------- | ----------------- | ------- |
| BR-001 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Registers the form module identity in the current database session on form open |
| BR-001 | DBMS_APPLICATION_INFO.SET_MODULE | Sets the module name in the current database session on form open |
| BR-001 | STOP_WATCH.START_TIMER | Starts the application session timer when activity logging is enabled |
| BR-003 | SP_VALIDATE_ALPHANUMERIC | Removes non-alphanumeric characters from the registration number before the vehicle lookup |
| BR-005 | PROC_AMC_DETAILS | Loads the full MCP enrollment details onto the screen for the selected contract |
| BR-005 | PKG_LOYALTY.SP_GET_VIN_LOYALTY_DTL | Retrieves loyalty card details and point balances for the vehicle |
| BR-006 | PKG_AMC.SP_POP_CANCEL_DTL | Retrieves cancellation charge details for the selected charge type |
| BR-006 | POP_PKG_DETAILS_NEW | Calculates and populates refund breakdown amounts for all service types |
| BR-006 | GENERAL.CHECK_NULL | Validates that the Cancellation Charges and Cancellation Reason fields are not blank |
| BR-007 | GENERAL.ASK_CONFIRM | Displays the cancellation confirmation dialogue to the advisor |
| BR-007 | GENERAL.CHECK_NULL | Validates mandatory cancellation fields before the confirmation dialogue is shown |
| BR-007 | SP_INSERT_CHARGES | Saves the cancellation charges, updates the enrollment record, updates the vehicle extension, records the loyalty transaction, and commits all changes |
| BR-007 | PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM | Generates the credit note number for cancellations of contracts from 1 July 2017 onwards |
| BR-007 | PKG_LOYALTY.SP_INS_LOYALTY_TRANSACTIONS | Records the loyalty programme transaction for the MCP cancellation event |
| BR-007 | SP_PUSH_MCPC_FDI_DATA | Submits the MCP cancellation data to the financial data integration system (principal 1 only) |
| BR-007 | PKG_FDI.SF_VALID_DEALER | Validates that the current dealer is registered in the FDI system before submitting cancellation data |
| BR-007 | PKG_FDI.SP_PUSH_FDI_TRANSACTIONS | Pushes the MCP cancellation financial transaction record to the FDI system |
| BR-008 | CALL_REPORT_ENQ | Presents the report output format prompt and generates the MCP cancellation report |
| BR-008 | GENERAL.PROC_REPORT_CALL | Runs the report object and returns the job handle for print output tracking |
| BR-008 | GENERAL.PROC_TIMER | Starts the print job status polling timer after a print job is submitted |
| BR-009 | GENERAL.RAISE_ERROR | Looks up and displays the catalogued error message for a given error code |
| BR-009 | GENERAL.DISP_TEXT | Displays error and informational messages to the advisor |
| BR-010 | SF_COPYRIGHT_DECLARATION | Returns the current financial year copyright text for Maruti Suzuki India Limited |
| BR-011 | GENERAL.PROC_TIMER_EXPIRED | Checks the print job status when the timer fires and opens or reports the print output |
| BR-012 | SP_PUSH_DMS_MESSAGE | Sends the DMS cancellation notification after the database commit |
| BR-013 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Clears the session client identity when the form exits |
| BR-013 | DBMS_APPLICATION_INFO.SET_MODULE | Clears the session module name when the form exits |
| - | POP_LIST | Populates list-of-values (LOV) items on the form with lookup data from AMC list master tables |
| - | PKG_AMC.SF_GET_SELL_PRICE | Returns the sell price for an AMC package line item during cancellation calculation |
| - | PKG_AMC.SP_AMC_AVAIL_QTY | Returns the available quantity for an AMC service line during cancellation calculation |
| - | PKG_LOYALTY.SF_CALCULATE_POINTS_TO_RUPEES | Converts a loyalty point balance to its rupee equivalent for display |
| - | PKG_LOYALTY.SF_CALCULATE_RUPEES_TO_POINTS | Converts a rupee amount to loyalty points for transaction recording |
| - | PKG_LOYALTY.SP_CALCULATE_BAL_POINTS | Calculates the current net balance of loyalty points for a card |
| - | PKG_LOYALTY.SP_RED_RESTRICTION_BAL_POINTS | Applies redemption restriction rules when computing redeemable loyalty point balance |
| - | SF_PRINCIPAL_MAP_CD | Returns the principal map code for the current dealer session context |
| - | SF_GET_CAR_USER_PHONE | Returns the registered phone number for the car owner associated with a VIN |
| - | SF_GET_MODEL_CHANNEL | Returns the sales channel (e.g. Arena / Nexa) for a given vehicle model |
| - | SF_GET_NEXA_VIN | Determines whether a given VIN belongs to the Nexa channel |
| - | SP_SMS_CMPMGR | Sends an SMS notification to the customer on MCP cancellation |
| - | FNC_VERIF_MOBILE | Validates the format of a mobile number before SMS dispatch |
| - | WEB.SHOW_DOCUMENT | Opens a URL in a new browser tab to display the PDF report or print job document |

---

### 12.2 Procedure and Package Catalogue

#### GENERAL (Attached Library - DPL)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| GENERAL.DISP_TEXT | Procedure (DPL library) | ON-ERROR (form level), ON-MESSAGE (form level), WHEN-NEW-FORM-INSTANCE (form level), WHEN-VALIDATE-ITEM (CB_VT_AMC_ENROLL.NB_REG_NUM, CB_VT_AMC_ENROLL.NB_VIN, CB_VT_AMC_ENROLL.NB_AMC_NUM, CB_VT_AMC_ENROLL.NB_AMC_NUM1), WHEN-LIST-CHANGED (B_VH_AMC_ENQ.CANCEL_CHARGES), WHEN-NEW-BLOCK-INSTANCE (B_VH_AMC_ENQ), PROC_AMC_DETAILS, SP_INSERT_CHARGES | Displays an alert dialog with the supplied text and title. Shows AL_ERRINFO for "Error" title and AL_NOTE for other titles. Acts as the single display mechanism for all error messages, validation failures, and informational messages throughout the form |
| GENERAL.RAISE_ERROR | Procedure (DPL library) | ON-ERROR (form level, for database error -02292) | Retrieves the error message text for the supplied error code and displays it via DISP_TEXT with the appropriate title; raises FORM_TRIGGER_FAILURE for error-type messages. Used in ON-ERROR to handle forms-level error interception |
| GENERAL.CHECK_NULL | Procedure (DPL library) | WHEN-VALIDATE-ITEM (B_VH_AMC_ENQ.CANCEL_CHARGES, B_VH_AMC_ENQ.CANC_REASON), WHEN-BUTTON-PRESSED (CB_VT_AMC_ENROLL.PB_CNCL) | Raises FORM_TRIGGER_FAILURE and displays "Enter a valid {column_title}" if the supplied value is null; enforces mandatory field validation for cancellation charges and cancellation reason |
| GENERAL.ASK_CONFIRM | Function (DPL library) | WHEN-BUTTON-PRESSED (CB_VT_AMC_ENROLL.PB_CNCL, PB_BLK.PB_COPY, PB_BLK.PB_CUT, PB_BLK.PB_DEL, PB_BLK.PB_EXIT, PB_BLK.PB_INSERT, PB_BLK.PB_LIST, PB_BLK.PB_PASTE, PB_BLK.PB_PRINT) | Displays the AL_CONFIRM alert with the supplied confirmation message; returns 1 if the user confirms or 0 if they cancel. Used to obtain user confirmation before processing the AMC cancellation and to guard inherited toolbar button operations |
| GENERAL.PROC_TIMER_EXPIRED | Procedure (DPL library) | WHEN-TIMER-EXPIRED (form level) | Checks the status of the PRINTER_QUEUE timer on expiry; opens the print output file in the browser and deletes the timer if the report job is finished, or displays an error and deletes the timer if the job failed |
| GENERAL.PROC_REPORT_CALL | Procedure (DPL library) | CALL_REPORT_ENQ (form program unit) | Submits the given report object in FILE/BATCH mode to the configured report server; returns the report job handle and the output file name. Used by CALL_REPORT_ENQ when the user selects the print-to-printer option |
| GENERAL.PROC_TIMER | Procedure (DPL library) | CALL_REPORT_ENQ (form program unit) | Creates a repeating timer named PRINTER_QUEUE with a 5-second interval to periodically poll the report job status after a print job is submitted |

---

#### PKG_AMC

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| PKG_AMC.SP_POP_CANCEL_DTL | Procedure (database package) | WHEN-LIST-CHANGED (B_VH_AMC_ENQ.CANCEL_CHARGES) | Computes GST-aware cancellation refund amounts for each AMC service line (labour, parts, consumables) based on the selected cancellation charge percentage. Reads the AMC enrollment header and service detail records, applies tax calculations per dealer tax configuration, and inserts computed charge and refund rows into the GBL_AMC_DTL and GBL_AMC_CHARGES session-scoped temporary tables. Returns error code 1 with a descriptive message if the calculation fails |
| PKG_AMC.SF_GET_SELL_PRICE | Function (database package) | POP_PKG_DETAILS_NEW (form program unit) | Returns the sell price for an AMC package line item; used during cancellation refund breakdown calculation |
| PKG_AMC.SP_AMC_AVAIL_QTY | Procedure (database package) | POP_PKG_DETAILS_NEW (form program unit) | Returns the available quantity for an AMC service line; used during cancellation refund breakdown calculation |

---

#### PKG_LOYALTY

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| PKG_LOYALTY.SP_GET_VIN_LOYALTY_DTL | Procedure (database package) | PROC_AMC_DETAILS (form program unit) | Retrieves the loyalty card details associated with a vehicle VIN - card type, card number, registered mobile number, and current point balance - and converts points to a rupee equivalent. Returns an error code and message if the VIN is not mapped to any loyalty card |
| PKG_LOYALTY.SP_INS_LOYALTY_TRANSACTIONS | Procedure (database package) | SP_INSERT_CHARGES (form program unit) | Records a loyalty programme transaction (type MCPC) for the MCP cancellation event against the loyalty card associated with the vehicle VIN, including transaction date, AMC number as reference, dealer and location context, and user ID. Errors are silently suppressed to prevent blocking the cancellation commit |
| PKG_LOYALTY.SF_CALCULATE_POINTS_TO_RUPEES | Function (database package) | PROC_AMC_DETAILS (form program unit) | Converts a loyalty point balance to its rupee equivalent for display on the cancellation screen |
| PKG_LOYALTY.SF_CALCULATE_RUPEES_TO_POINTS | Function (database package) | SP_INSERT_CHARGES (form program unit) | Converts a rupee amount to the equivalent loyalty points for use in the cancellation loyalty transaction record |
| PKG_LOYALTY.SP_CALCULATE_BAL_POINTS | Procedure (database package) | PROC_AMC_DETAILS (form program unit) | Calculates the current net balance of loyalty points for a card after accounting for all prior transactions |
| PKG_LOYALTY.SP_RED_RESTRICTION_BAL_POINTS | Procedure (database package) | PROC_AMC_DETAILS (form program unit) | Applies redemption restriction rules to determine the redeemable loyalty point balance available for the card |

---

#### PKG_FDI

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| PKG_FDI.SF_VALID_DEALER | Function (database package) | SP_PUSH_MCPC_FDI_DATA (form program unit) | Validates that the current dealer is registered and active in the FDI system before the cancellation transaction is submitted; returns a boolean-equivalent flag |
| PKG_FDI.SP_PUSH_FDI_TRANSACTIONS | Procedure (database package) | SP_PUSH_MCPC_FDI_DATA (form program unit) | Pushes the MCP cancellation financial transaction record to the financial data integration system; called only after SF_VALID_DEALER confirms the dealer is registered |

---

#### PK_VALIDATE_BACK_DATE

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM | Procedure (database package) | SP_INSERT_CHARGES (form program unit) | Locks the document master row for the given dealer, principal, location, company, document type, and financial year; increments the document sequence number; and returns the formatted credit note number for the ACR document type. Returns error code 1 with a message if the document master record is missing, has duplicate entries, or is locked by another user. Invoked only for AMC enrollments dated on or after 01-Jul-2017 |

---

#### SP_PUSH_DMS_MESSAGE

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| SP_PUSH_DMS_MESSAGE | Procedure (standalone database procedure) | POST-DATABASE-COMMIT (form level) | Sends a DMS notification message for the MCP cancellation transaction to downstream systems after the database commit; any failure is silently ignored |

---

#### SP_PUSH_MCPC_FDI_DATA

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| SP_PUSH_MCPC_FDI_DATA | Procedure (standalone database procedure) | WHEN-BUTTON-PRESSED (CB_VT_AMC_ENROLL.PB_CNCL) | Submits the MCP cancellation transaction data to the financial data integration system; called only when the current principal is 1; internally calls PKG_FDI.SF_VALID_DEALER and PKG_FDI.SP_PUSH_FDI_TRANSACTIONS; any failure is silently ignored |

---

#### SP_VALIDATE_ALPHANUMERIC

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| SP_VALIDATE_ALPHANUMERIC | Procedure (standalone database procedure) | WHEN-VALIDATE-ITEM (CB_VT_AMC_ENROLL.NB_REG_NUM) | Removes any non-alphanumeric characters (outside A-Z and 0-9) from the supplied string in place, sanitising the registration number before the vehicle lookup |

---

#### SF_COPYRIGHT_DECLARATION

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| SF_COPYRIGHT_DECLARATION | Function (standalone database function) | KEY-CLRFRM (form level) | Returns the current financial year copyright text for Maruti Suzuki India Limited based on today's date; used to refresh the copyright display on form clear |

---

#### SF_PRINCIPAL_MAP_CD

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| SF_PRINCIPAL_MAP_CD | Function (standalone database function) | PRE-FORM / WHEN-NEW-FORM-INSTANCE (form level), SP_INSERT_CHARGES (form program unit) | Returns the principal map code for the current dealer session context; used to gate principal-specific logic such as FDI submission and to supply the principal code to database procedures |

---

#### SF_GET_CAR_USER_PHONE

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| SF_GET_CAR_USER_PHONE | Function (standalone database function) | SP_INSERT_CHARGES (form program unit) | Returns the registered phone number for the car owner associated with a given VIN; used to supply the customer contact number for SMS notification on MCP cancellation |

---

#### SF_GET_MODEL_CHANNEL

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| SF_GET_MODEL_CHANNEL | Function (standalone database function) | PROC_AMC_DETAILS (form program unit) | Returns the sales channel identifier (e.g. Arena or Nexa) for a given vehicle model code; used to apply channel-specific display or processing rules on the cancellation screen |

---

#### SF_GET_NEXA_VIN

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| SF_GET_NEXA_VIN | Function (standalone database function) | PROC_AMC_DETAILS (form program unit) | Determines whether a given VIN belongs to the Nexa sales channel; used to conditionally apply Nexa-specific business rules during enrollment detail loading |

---

#### SP_SMS_CMPMGR

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| SP_SMS_CMPMGR | Procedure (standalone database procedure) | SP_INSERT_CHARGES (form program unit) | Sends an SMS notification to the customer on MCP cancellation using the phone number returned by SF_GET_CAR_USER_PHONE; mobile number format is validated by FNC_VERIF_MOBILE before dispatch |

---

#### FNC_VERIF_MOBILE

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| FNC_VERIF_MOBILE | Function (standalone database function) | SP_INSERT_CHARGES (form program unit) | Validates the format of a mobile number before it is passed to SP_SMS_CMPMGR for SMS dispatch; returns a flag indicating whether the number is valid |

---

#### DBMS_APPLICATION_INFO

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Procedure (Oracle system package) | PRE-FORM (form level), KEY-EXIT (form level) | Sets or clears the client application info in the current database session for monitoring purposes |
| DBMS_APPLICATION_INFO.SET_MODULE | Procedure (Oracle system package) | PRE-FORM (form level), KEY-EXIT (form level) | Sets or clears the module name in the current database session for monitoring purposes |

---

#### STOP_WATCH

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| STOP_WATCH.START_TIMER | Procedure (database package) | PRE-FORM (form level) | Starts the application session duration timer when activity logging is enabled for the dealership |

---

#### WEB (Attached Library)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| WEB.SHOW_DOCUMENT | Procedure (Oracle web toolkit / attached library) | CALL_REPORT_ENQ (form program unit), GENERAL.PROC_TIMER_EXPIRED (DPL library) | Opens a URL in a new browser tab; used to display the PDF report output or the print job document |

## 13. Package Procedure Specifications

*Behavioural requirements for each database package invoked from the form. Only packages referenced in the form XML that have a matching source `.pck` file in the input directory are listed. Descriptions are derived from the package bodies in the uploaded PCK sources.*

| ID | Package | Description | Business Requirement | Acceptance Criteria |
| :--- | :--- | :--- | :--- | :--- |
| BR-T-PKG-AMC | PKG_AMC | AMC cancellation engine - computes and persists GST-aware refund amounts by service type (labour, parts, consumables) into session temp tables when a cancellation charge percentage is selected | The form depends on this package to calculate, split, and store the correct refund and tax amounts for each AMC service line before the user confirms the cancellation | SP_POP_CANCEL_DTL populates refund data for the selected charge percentage; cancellation block values are populated only after a successful call; error code 1 blocks the cancellation |
| BR-T-PKG-LOYALTY | pkg_loyalty | Loyalty programme integration - retrieves the loyalty card details linked to a vehicle VIN and records a loyalty point transaction when an AMC is cancelled | The form depends on this package to display current loyalty card balance for the vehicle and to post the MCP cancellation loyalty transaction on commit | sp_get_vin_loyalty_dtl returns card type, card number, registered mobile, and point balance for the VIN; sp_ins_loyalty_transactions records the cancellation loyalty event without blocking the commit |
| BR-T-PK-VALIDATE-BACK-DATE | Pk_Validate_Back_Date | Credit note number generation - generates and reserves a sequenced credit note number from the document master for the ACR document type in the current financial year | The form depends on this package to generate a unique, sequential credit note reference number before inserting cancellation charge records for AMC enrollments created after 01-Jul-2017 | Generate_Next_Num returns a valid credit note number when the document master record exists; a non-zero error code blocks the cancellation with an error message |

**Total Matched Packages:** 3

## 14. Database Package Catalogue

*Detailed specifications for each database package routine called from the form, including signatures and business rules.*
**Source PCK file(s):** PKG_AMC.pck, PKG_LOYALTY.pck, PK_VALIDATE_BACK_DATE.pck

| Source File (.pck) | Package | Routine Name | Type | Definition (signature / excerpt) | Called From | Purpose |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| PKG_AMC.pck | PKG_AMC | SP_POP_CANCEL_DTL | Procedure | PROCEDURE SP_POP_CANCEL_DTL(p_pmc IN NUMBER, p_amc_num IN VARCHAR2, p_cncl_chg IN NUMBER, p_err_cd OUT NUMBER, p_err_msg OUT VARCHAR2) | Trigger: WHEN-LIST-CHANGED in B_VH_AMC_ENQ.CANCEL_CHARGES | Computes GST-aware cancellation refund amounts for each AMC service line (labour, parts, consumables) based on the selected cancellation charge percentage. Reads the AMC enrollment header and service detail records; applies tax calculations per dealer tax configuration; inserts computed charge and refund rows into the GBL_AMC_DTL and GBL_AMC_CHARGES session-scoped temporary tables. Returns error code 1 with a descriptive message if the calculation fails. Invoked each time the user changes the cancellation charge selection. |
| PKG_LOYALTY.pck | pkg_loyalty | sp_get_vin_loyalty_dtl | Procedure | PROCEDURE sp_get_vin_loyalty_dtl(pn_pmc IN NUMBER, pn_vin IN VARCHAR2, po_card_type OUT VARCHAR2, po_card_num OUT VARCHAR2, po_reg_mob OUT VARCHAR2, po_bal_point OUT NUMBER, po_... | ProgramUnit: PROC_AMC_DETAILS | Retrieves the loyalty card details associated with a vehicle VIN. Looks up the loyalty card mapped to the VIN, fetches the card type, registered mobile number, and current point balance from the loyalty enrolment table, and converts points to a rupee equivalent. Returns an error code and message if the VIN is not mapped to any loyalty card. Called when AMC enrollment details are loaded. |
| PKG_LOYALTY.pck | pkg_loyalty | sp_ins_loyalty_transactions | Procedure | PROCEDURE sp_ins_loyalty_transactions(p_card_num in varchar2, p_vin in varchar2, p_trans_type in varchar2, p_trans_date in varchar2, --DD-MM-YYYY HH24:MI:SS p_trans_num in varch... | ProgramUnit: SP_INSERT_CHARGES | Records a loyalty programme transaction for the MCP cancellation event. Posts a cancellation-type transaction against the loyalty card associated with the vehicle VIN, including transaction date, AMC number as reference, dealer and location context, and the user ID. Transaction type MCPC is used for MCP cancellation. Errors are silently suppressed to prevent the transaction from blocking the cancellation commit. |
| PK_VALIDATE_BACK_DATE.pck | Pk_Validate_Back_Date | Generate_Next_Num | Procedure | PROCEDURE Generate_Next_Num ( pi_dealer_map_cd IN NUMBER, pi_principal_map_cd IN NUMBER, pi_loc_cd IN VARCHAR2, pi_comp_fa IN VARCHAR2, pi_doc_type IN VARCHAR2, po_doc_num OUT V... | ProgramUnit: SP_INSERT_CHARGES | Generates and reserves a sequenced credit note number for the ACR document type. Locks the document master row for the given dealer, principal, location, company, document type, and financial year; increments the document sequence number; and returns the formatted credit note number. Returns error code 1 with a message if the document master record is missing, has duplicate entries, or is locked by another user. Invoked only for AMC enrollments dated on or after 01-Jul-2017. |

**Total Matched Package Routines (called from form XML):** 4

---

**Function return values:**

| Function | Returns | Values | Description |
| :--- | :--- | :--- | :--- |
| - | - | - | *No matched package functions with documented return values in the available PCK sources.* |

## 15. PLD Procedure Call Sites

*Maps each program-library routine to its call sites within triggers and program units. Behaviour descriptions are derived from the uploaded `.pld` sources.*

### DPL.pld (`general`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ASK_CONFIRM | Function | Function(confirm_msg VARCHAR2) RETURN NUMBER | Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENROLL.PB_CNCL, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_COPY, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_CUT, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_DEL, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_EXIT, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_INSERT, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_LIST, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_PASTE, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_PRINT | Displays the AL_CONFIRM alert with the supplied confirmation message and returns 1 if the user clicks the confirm button, or 0 otherwise. Used to obtain user confirmation before processing the AMC cancellation, and also invoked by the inherited PB_BLK toolbar buttons (PB_COPY, PB_CUT, PB_DEL, PB_EXIT, PB_INSERT, PB_LIST, PB_PASTE, PB_PRINT) to guard their respective operations with a confirmation prompt. |
| CHECK_NULL | Procedure | Procedure(p_value IN VARCHAR2, column_title IN VARCHAR2) | Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENROLL.PB_CNCL, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.CANCEL_CHARGES, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.CANC_REASON | Raises FORM_TRIGGER_FAILURE and displays an error message if the supplied value is null. The error message is "Enter a valid {column_title}". Used to enforce mandatory field validation for cancellation charges and cancellation reason fields. |
| DISP_TEXT | Procedure | Procedure(text_string VARCHAR2, title_string VARCHAR2) | ProgramUnit: PROC_AMC_DETAILS, ProgramUnit: SP_INSERT_CHARGES, Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: WHEN-LIST-CHANGED in B_VH_AMC_ENQ.CANCEL_CHARGES, Trigger: WHEN-NEW-BLOCK-INSTANCE in B_VH_AMC_ENQ, Trigger: WHEN-NEW-FORM-INSTANCE in Form, Trigger: WHEN-VALIDATE-ITEM in CB_VT_AMC_ENROLL.NB_AMC_NUM, Trigger: WHEN-VALIDATE-ITEM in CB_VT_AMC_ENROLL.NB_AMC_NUM1, Trigger: WHEN-VALIDATE-ITEM in CB_VT_AMC_ENROLL.NB_REG_NUM, Trigger: WHEN-VALIDATE-ITEM in CB_VT_AMC_ENROLL.NB_VIN | Displays an alert dialog with the supplied text and title. Shows AL_ERRINFO for "ERROR" title, AL_NOTE for other titles. Used as the single display mechanism for all error messages, validation failures, and informational messages throughout the form, including during form initialisation in WHEN-NEW-FORM-INSTANCE. |
| PROC_REPORT_CALL | Procedure | Procedure(REPID report_object, lv_report OUT varchar2, lv_print OUT varchar2) | ProgramUnit: CALL_REPORT_ENQ | Submits the given report object in FILE/BATCH mode to the configured report server, generating an output file. Returns the report job handle and the output file name. Used by CALL_REPORT_ENQ when the user selects the print-to-printer option. |
| PROC_TIMER | Procedure | Procedure() | ProgramUnit: CALL_REPORT_ENQ | Creates a repeating timer named PRINTER_QUEUE with a 5-second interval. Used after submitting a print job to periodically poll the report status via PROC_TIMER_EXPIRED. |
| PROC_TIMER_EXPIRED | Procedure | Procedure() | Trigger: WHEN-TIMER-EXPIRED in Form | Checks the status of the PRINTER_QUEUE timer. If the report job is FINISHED, opens the print output file in the browser and deletes the timer. If the status indicates failure, displays an error and deletes the timer. |
| RAISE_ERROR | Procedure | Procedure(mesg_code IN VARCHAR2) | Trigger: ON-ERROR in Form | Retrieves the error message text for the supplied code and displays it via DISP_TEXT with the appropriate title. Raises FORM_TRIGGER_FAILURE for error-type messages. Used in ON-ERROR to handle forms-level error interception. |

**Total Active Routines:** 7 of 24 in DPL.pld source

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| ID | Service Name | Database Object | Input Parameters | Output | Business Function | API Endpoint Suggestion |
| -- | ------------ | --------------- | ---------------- | ------ | ----------------- | ----------------------- |
| MS-001 | MCP Cancellation Save Service | SP_INSERT_CHARGES (form program unit), VH_AMC_ENROL, VD_AMC_CANCELCHARGES, GM_VIN_EXT, GBL_AMC_CHARGES | Principal code, contract number, dealer code, location code, financial area, financial year, cancellation date, charge type, refund amounts (labour/parts/consumables), net refund amount, cancellation reason, user ID | Success/failure status, generated credit note number (where applicable), error code and message | Saves the full MCP cancellation to the database: generates a credit note number for eligible contracts, inserts the cancellation charge lines, marks the enrollment as cancelled with all refund details, updates the vehicle expiry date, and records the loyalty transaction | `POST /api/mcp/cancellations` |
| MS-002 | Cancellation Charge Detail Retrieval Service | PKG_AMC.SP_POP_CANCEL_DTL | Principal code, contract number, selected cancellation charge type | Error code, error message (on failure); populated cancellation charge details (on success) | Retrieves the cancellation charge breakdown from the package master for the selected charge type and contract, returning an error when the retrieval fails | `GET /api/mcp/cancellation-charges/{principalCode}/{contractNumber}/{chargeType}` |
| MS-003 | Credit Note Number Generation Service | PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM | Dealer code, principal code, location code, financial area, document type (ACR), financial year, cancellation date | Generated credit note number, error code, error message | Generates a validated, sequential credit note reference number for MCP cancellations, applying back-date validation rules for contracts dated from 1 July 2017 onwards | `POST /api/finance/credit-notes/generate` |
| MS-004 | Loyalty Programme Details Service | PKG_LOYALTY.SP_GET_VIN_LOYALTY_DTL | Principal/dealer code, VIN | Loyalty card type, card number, linked registration number, balance points, balance monetary value, error code, error message | Retrieves the loyalty programme membership card details and current point balance for a given vehicle at the current dealership | `GET /api/loyalty/details/vin/{vin}` |
| MS-005 | Loyalty Transaction Recording Service | PKG_LOYALTY.SP_INS_LOYALTY_TRANSACTIONS | Loyalty card number, VIN, transaction type (MCPC), transaction date/time, contract number, transaction description, parent group, dealer code, location code, points (null for MCP cancellation), monetary equivalent (null), transaction flag (null), user ID | Error code, error message | Records a loyalty programme transaction event for the MCP cancellation against the vehicle's loyalty card for audit and balance tracking | `POST /api/loyalty/transactions` |
| MS-006 | DMS Cancellation Notification Service | SP_PUSH_DMS_MESSAGE | Transaction type (SRV_MCPCANCEL), parent group, dealer code, location code, financial area, document type (MCP_CNCL), contract number, user ID | Success/failure status (failure is silently suppressed by caller) | Sends a downstream DMS notification for the MCP cancellation event, informing connected dealer management systems of the cancellation transaction | `POST /api/dms/notifications/mcp-cancellation` |
| MS-007 | FDI Financial Data Integration Service | SP_PUSH_MCPC_FDI_DATA | Principal code, contract number | Error code, error message | Submits the MCP cancellation transaction details (vehicle, dealer, customer, financial amounts, tax, and regulatory data) to the financial data integration system; applicable to principal 1 only | `POST /api/fdi/transactions/mcp-cancellation` |
| MS-008 | Registration Number Sanitisation Service | SP_VALIDATE_ALPHANUMERIC | Registration number string (in/out) | Cleaned alphanumeric-only string | Removes any non-alphanumeric characters (characters outside A-Z and 0-9) from a registration number, ensuring lookups are not blocked by accidental formatting characters | `POST /api/vehicles/registration-number/sanitise` |
| MS-009 | MCP Enrollment Detail Load Service | PROC_AMC_DETAILS (form program unit), VH_AMC_ENROL, VD_AMC_ENROL, VM_SVAR, GM_VAR, GM_CITY, VM_AMC_PKG | Principal code, contract number | Full enrollment detail payload: contract dates, vehicle identity, customer details, selling dealer info, package amounts (original/used/balance), tax amounts, loyalty points | Retrieves the complete MCP enrollment record and all related descriptive data (vehicle model/variant/city descriptions, package description, loyalty programme details) for display and cancellation processing | `GET /api/mcp/enrollments/{principalCode}/{contractNumber}` |
| MS-010 | Package Refund Breakdown Calculation Service | POP_PKG_DETAILS_NEW (form program unit), GBL_AMC_DTL | Parent group, dealer code, location code, financial area, contract number (package code) | Refund amounts by service type (labour/parts/consumables), tax amounts by service type, total cancellation charge, total tax, total refund, net refund payable | Calculates the refund amount breakdown for each service type based on the package detail records and the selected cancellation charge type, returning all amounts needed for the refund summary display | `GET /api/mcp/refund-breakdown/{contractNumber}` |

**Total Microservices Identified: 10**

---

## 17. Workflows

| ID | Workflow Name | Trigger Event | Steps | Decision Points | End State |
| -- | ------------- | ------------- | ----- | --------------- | --------- |
| WF-001 | Form Startup and Session Registration | PRE-FORM trigger fires when the MCP Cancellation form is opened | 1. Register session identity under module "vt_amc_cncl". 2. Check application logging flag. 3. If logging is active, start the session timer. | Application logging flag: if active -> start timer; otherwise -> skip timer | Form is open and session is registered; advisor sees the search section ready for input |
| WF-002 | MCP Contract Identification and Detail Load | Advisor enters a contract number, registration number, or VIN and navigates off the search field | 1. Receive search value. 2. For registration number: sanitise input. 3. Validate the entered value against the relevant master (enrollment for contract number; vehicle master then enrollment for registration/VIN). 4. Check contract eligibility (not cancelled, not expired, enrolled at current dealer). 5. Store resolved contract reference. 6. On navigation to the details section: check contract reference is present; load full enrollment details and loyalty data | Which search field is used (contract number / registration / VIN); vehicle found vs not found; enrollment found vs not found; contract cancelled vs active; contract expired vs valid; contract at current dealer vs different dealer | All enrollment details displayed; advisor can review and proceed to cancellation, OR an error message shown and advisor remains on the search section |
| WF-003 | Cancellation Charge Selection and Refund Calculation | Advisor selects or changes the Cancellation Charges dropdown; advisor navigates off the field | 1. Validate Cancellation Charges field is not blank (WHEN-VALIDATE-ITEM). 2. On list change: if a charge type is selected, call the charge detail retrieval service. 3. Check the return code from charge detail retrieval. 4. If successful, call the refund breakdown calculation. 5. Populate all refund amount fields. If charge type is cleared, reset all refund fields to null. | Cancellation Charges is blank (error) vs has a value; charge detail retrieval succeeds vs fails; charge type selected vs cleared | Refund amounts (labour/parts/consumables refunds, taxes, net refund payable) are displayed for advisor review, OR an error is shown and the advisor must select a different charge type |
| WF-004 | MCP Cancellation Confirmation, Save, Financial Push, and Report | Advisor clicks the Cancel MCP button | 1. Validate Cancellation Charges and Cancellation Reason are not blank. 2. Present confirmation dialogue. 3. If advisor confirms: save cancellation (generate credit note if applicable; insert charge lines; update enrollment; update vehicle extension; record loyalty transaction; commit). 4. If principal is 1: push FDI data (silently ignore failure). 5. If contract number is present: prompt advisor for report format. 6. Generate and deliver report in selected format (PDF or print). 7. Clear the form. | Mandatory fields blank (stop) vs complete; advisor confirms cancellation vs dismisses; credit note required (contract from 1 July 2017) vs not required; credit note generation success vs failure; principal is 1 vs other; report format selected (PDF / print / skip); contract number present vs null for report step | Cancellation is committed to database; report is generated or skipped; form is cleared for the next transaction. OR: error message shown, form stays on cancellation details screen |
| WF-005 | Print Job Status Monitoring | WHEN-TIMER-EXPIRED fires periodically after a print job is submitted | 1. Identify the timer name. 2. If it is the print queue timer: retrieve the report job handle. 3. Check print job status. 4a. If still running/queued: take no action, wait for next timer firing. 4b. If finished: open print output in browser, delete timer. 4c. If failed/unexpected: show error message, delete timer. | Timer is print queue timer vs other; print job status: still running vs finished vs failed | Print document is opened and timer removed (success), OR error is shown and timer removed (failure), OR no action (job still running) |
| WF-006 | Form Exit and Session Cleanup | Advisor presses the exit key | 1. Clear client identity from the database session. 2. Clear the module name from the database session. 3. Exit the form without saving any pending changes. | None | Form is closed; database session monitoring shows no active module |
| WF-007 | Form Clear and Copyright Refresh | Advisor uses the clear form function | 1. Clear all form fields and reset to initial state. 2. Refresh copyright display with current financial year text. | Current month determines copyright year (January-March: previous year; other months: current year) | Form is reset to blank search state; copyright text updated |
| WF-008 | Post-Commit DMS Notification | POST-DATABASE-COMMIT trigger fires after any successful database commit | 1. Call DMS message push service with transaction type "SRV_MCPCANCEL" and current dealer, location, and contract details. 2. Silently ignore any failure from the push. | DMS push success vs failure (failure is silently ignored) | DMS notification sent to downstream systems (or silently skipped on error); committed cancellation record is unaffected |

**Total Workflows Identified: 8**

---

## 18. PLD-Backed Logic

*Maps shared library routines to their business function and suggested API contracts.*

### webutil.pld (`CLIENT_IMAGE`)

*No routines from ``webutil.pld`` are referenced in ``vt_amc_cncl_fmb.xml``.*


---

### DPL.pld (`general`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | ASK_CONFIRM | Business Logic | Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENROLL.PB_CNCL | /api/v1/pld/ask_confirm | Prompts the user to confirm the AMC cancellation before the cancellation is processed |
| PLD-002 | CHECK_NULL | Validation | Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENROLL.PB_CNCL, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.CANCEL_CHARGES, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.CANC_REASON | /api/v1/pld/check_null | Rejects navigation or submission when a mandatory field value is null |
| PLD-003 | DISP_TEXT | Business Logic | ProgramUnit: PROC_AMC_DETAILS, ProgramUnit: SP_INSERT_CHARGES, Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: WHEN-LIST-CHANGED in B_VH_AMC_ENQ.CANCEL_CHARGES, Trigger: WHEN-NEW-BLOCK-INSTANCE in B_VH_AMC_ENQ, Trigger: WHEN-VALIDATE-ITEM in CB_VT_AMC_ENROLL.NB_AMC_NUM, Trigger: WHEN-VALIDATE-ITEM in CB_VT_AMC_ENROLL.NB_AMC_NUM1, Trigger: WHEN-VALIDATE-ITEM in CB_VT_AMC_ENROLL.NB_REG_NUM, Trigger: WHEN-VALIDATE-ITEM in CB_VT_AMC_ENROLL.NB_VIN | /api/v1/pld/disp_text | Displays error or informational alert dialogs to the user across all form error and validation events |
| PLD-004 | PROC_REPORT_CALL | Business Logic | ProgramUnit: CALL_REPORT_ENQ | /api/v1/pld/proc_report_call | Submits the AMC cancellation report for batch printing and returns the job handle and output file name |
| PLD-005 | PROC_TIMER | Business Logic | ProgramUnit: CALL_REPORT_ENQ | /api/v1/pld/proc_timer | Creates a repeating polling timer to monitor a submitted print report job until completion |
| PLD-006 | PROC_TIMER_EXPIRED | Business Logic | Trigger: WHEN-TIMER-EXPIRED in Form | /api/v1/pld/proc_timer_expired | Opens the print output in the browser when the report job finishes and clears the polling timer |
| PLD-007 | RAISE_ERROR | Validation | Trigger: ON-ERROR in Form | /api/v1/pld/raise_error | Displays the error message for the given error code and halts execution for error-type conditions |


---

### D2kwutil.pld (`Win_API`)

*No routines from ``D2kwutil.pld`` are referenced in ``vt_amc_cncl_fmb.xml``.*

---

---

## 19. PCK-Backed Logic

*Maps database package routines to their business rules and suggested API contracts.*

| ID | Package.Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ------------- | ---- | ---------- | ------------- | --------------------- |
| PCK-001 | PKG_AMC.SP_POP_CANCEL_DTL | Business Logic | Trigger: WHEN-LIST-CHANGED in B_VH_AMC_ENQ.CANCEL_CHARGES | /api/v1/packages/pkg_amc/sp_pop_cancel_dtl | When a cancellation charge percentage is selected, then GST-aware refund amounts are calculated per service type and stored in session temp tables for display |
| PCK-002 | pkg_loyalty.sp_get_vin_loyalty_dtl | Business Logic | ProgramUnit: PROC_AMC_DETAILS | /api/v1/packages/pkg_loyalty/sp_get_vin_loyalty_dtl | When an AMC enrollment is loaded, then loyalty card details and current point balance are retrieved for the enrolled vehicle VIN |
| PCK-003 | pkg_loyalty.sp_ins_loyalty_transactions | Business Logic | ProgramUnit: SP_INSERT_CHARGES | /api/v1/packages/pkg_loyalty/sp_ins_loyalty_transactions | When an AMC is cancelled, then a loyalty cancellation transaction is posted against the vehicle's loyalty card with transaction type MCPC |
| PCK-004 | Pk_Validate_Back_Date.Generate_Next_Num | Business Logic | ProgramUnit: SP_INSERT_CHARGES | /api/v1/packages/pk_validate_back_date/generate_next_num | When the AMC enrollment date is on or after 01-Jul-2017, then a sequential credit note number is generated and reserved from the document master before cancellation charges are inserted |

---

---

## 20. System Interfaces

### 20.1 Database Integrations

| Interface Name | Type | Purpose | Data Flow | Error Handling |
| -------------- | ---- | ------- | --------- | -------------- |
| MCP Enrollment Master (VH_AMC_ENROL) | Table - SELECT, UPDATE | Retrieve MCP enrollment records for validation and display; update enrollment to record cancellation details | SELECT: contract lookup, validation, and detail load; UPDATE: sets cancellation flag, date, charge type, refund amounts, reason, and credit note number | NO_DATA_FOUND / TOO_MANY_ROWS / VALUE_ERROR / WHEN OTHERS handled per trigger; concurrent update conflicts detected via error codes 40654-40659 |
| MCP Enrollment Detail (VD_AMC_ENROL) | Table - SELECT | Retrieve usage amount breakdown (by service type) and discount/charge amounts for balance calculation | SELECT only: used to compute labour/parts/consumables used amounts and discounts when loading enrollment details | WHEN OTHERS -> silent default (zero amounts) |
| MCP Cancellation Charges Detail (VD_AMC_CANCELCHARGES) | Table - INSERT | Record the cancellation charge detail lines when an MCP contract is cancelled | INSERT: copies charge lines from the package charge master for the current dealer, contract, and location | WHEN OTHERS -> GENERAL.DISP_TEXT shows error, RAISE FORM_TRIGGER_FAILURE |
| Package Detail (GBL_AMC_DTL) | Table - SELECT | Retrieve dealer-specific package detail lines used to calculate refund amounts by service type | SELECT: provides sell price, discount, usage value, and tax amount per service type for the current dealer and contract | WHEN OTHERS -> loop exits, no refund calculated |
| Package Charge Master (GBL_AMC_CHARGES) | Table - SELECT | Provide the source charge lines to be copied into the cancellation charges detail on save | SELECT: used in INSERT...SELECT during SP_INSERT_CHARGES to copy standard charge lines | WHEN OTHERS -> GENERAL.DISP_TEXT shows error, RAISE FORM_TRIGGER_FAILURE |
| Vehicle Master (GM_VIN) | Table - SELECT | Validate that a registration number or VIN corresponds to a known vehicle | SELECT: existence check only, no data returned beyond confirmation | NO_DATA_FOUND: not-found message; TOO_MANY_ROWS: multiple-records message; others handled |
| Vehicle Extension (GM_VIN_EXT) | Table - UPDATE | Update the vehicle's MCP expiry date to the cancellation date when the cancellation is saved | UPDATE: sets `amc_exp_date` to the cancellation date for the vehicle's VIN | Included in the overall cancellation transaction commit; any failure propagates to the outer WHEN OTHERS handler |
| PKG_AMC.SP_POP_CANCEL_DTL | Package procedure - CALL | Retrieve the cancellation charge details for the selected charge type and contract | Input: principal code, contract number, charge type; Output: charge detail data, error code, error message | Error code 1 returned -> error message displayed, trigger aborts |
| PKG_LOYALTY.SP_GET_VIN_LOYALTY_DTL | Package procedure - CALL | Retrieve the loyalty card details and point balances for the vehicle's VIN | Input: principal code, VIN; Output: card type, card number, registration, balance points, balance value, error code, error message | WHEN OTHERS -> NULL (silent; loyalty fields remain unpopulated) |
| PKG_LOYALTY.SP_INS_LOYALTY_TRANSACTIONS | Package procedure - CALL | Record the MCP cancellation as a loyalty programme transaction | Input: card number, VIN, transaction type (MCPC), date, contract number, description, dealer details, user ID; Output: error code, error message | WHEN OTHERS -> NULL (silent; cancellation save proceeds unaffected) |
| PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM | Package procedure - CALL | Generate the credit note sequence number for MCP cancellations dated from 1 July 2017 | Input: dealer code, principal code, location code, financial area, document type (ACR), financial year, cancellation date; Output: credit note number, error message, error code | Error code non-zero -> error message displayed via GENERAL.DISP_TEXT, RAISE FORM_TRIGGER_FAILURE |
| DBMS_APPLICATION_INFO | Oracle system package - CALL | Register and clear the form module identity in the database session for monitoring | Input: module name, client info; Output: session-level metadata updated | No error handling; standard Oracle package |
| SP_VALIDATE_ALPHANUMERIC | Standalone procedure - CALL | Remove non-alphanumeric characters from the registration number before vehicle lookup | Input/Output: registration number string (modified in place) | No exception handling; characters removed iteratively |
| SF_COPYRIGHT_DECLARATION | Standalone function - CALL | Return the current financial year copyright text | Input: none; Output: copyright string | No exception handling; returns string directly |
| SP_PUSH_DMS_MESSAGE | Standalone procedure - CALL | Send DMS notification for the MCP cancellation transaction after commit | Input: transaction type, parent group, dealer, location, financial area, document type, contract number, user ID | WHEN OTHERS -> NULL (silent; commit is unaffected) |
| SP_PUSH_MCPC_FDI_DATA | Standalone procedure - CALL | Submit MCP cancellation data to the financial data integration system | Input: principal code, contract number; Output: error code, error message | WHEN OTHERS -> NULL (silent; calling trigger ignores errors) |

### 20.2 External System Integrations

| System Name | Integration Type | Purpose | Protocol | Endpoint | Data Exchange | Success / Error Codes |
| ----------- | ---------------- | ------- | -------- | -------- | ------------- | --------------------- |
| DMS (Dealer Management System) | Outbound notification via database procedure SP_PUSH_DMS_MESSAGE | Notifies downstream DMS systems of the MCP cancellation event after the database commit | Internal database procedure call (called from POST-DATABASE-COMMIT trigger) | SP_PUSH_DMS_MESSAGE in the application database | Transaction type "SRV_MCPCANCEL", dealer/location/contract details, user identity - outbound only | Success: notification sent silently; any failure is silently ignored by the calling trigger |
| FDI (Financial Data Integration) | Outbound transaction push via database procedure SP_PUSH_MCPC_FDI_DATA and PKG_FDI package | Submits MCP cancellation financial transaction data (vehicle, dealer, customer, amounts, tax, regulatory data) to the financial integrity system; applicable to dealerships under principal 1 only | Internal database procedure call (called from WHEN-BUTTON-PRESSED trigger) | SP_PUSH_MCPC_FDI_DATA / PKG_FDI.SP_PUSH_FDI_TRANSACTIONS in the application database | Full cancellation transaction payload including VIN, engine/chassis numbers, selling dealer, amounts, GST data, customer details - outbound only | Success: data submitted; any failure is silently ignored by the calling trigger |
| Loyalty Programme System | Outbound transaction via PKG_LOYALTY.SP_INS_LOYALTY_TRANSACTIONS | Records the MCP cancellation as a loyalty event against the customer's loyalty card | Internal database package call (called from SP_INSERT_CHARGES program unit) | PKG_LOYALTY.SP_INS_LOYALTY_TRANSACTIONS in the application database | Loyalty card number, VIN, transaction type, contract number, dealer details, user identity - outbound only | Success: transaction recorded; any failure is silently ignored |
| Oracle Reports Server | Outbound report generation | Generates the MCP cancellation report (vr_amc_cncl) in PDF or print format and delivers the output to the browser or printer | Oracle Reports server HTTP call via RUN_REPORT_OBJECT / PROC_REPORT_CALL | Oracle Reports server at `GLOBAL.REP_SERVER` - report file `vr_amc_cncl` | Report parameters: P_PARENT, P_PRINCIPAL, P_COMP_FA, P_DEALER, P_LOC, P_AMC_NUM - outbound parameters; report document returned as PDF or print job | PDF: job ID returned; browser opened via WEB.SHOW_DOCUMENT. Print: job submitted; status polled via GENERAL.PROC_TIMER_EXPIRED on timer expiry; *"Unable to generate the report"* shown on failure |

### 20.3 Report Integrations

| Report Name | Report Server | Parameters | Output Format | Trigger |
| ----------- | ------------- | ---------- | ------------- | ------- |
| vr_amc_cncl | `GLOBAL.REP_SERVER` (session global) | P_PARENT (parent group), P_PRINCIPAL (principal code), P_COMP_FA (financial area), P_DEALER (dealer code), P_LOC (location code), P_AMC_NUM (MCP contract number); REPORT_DESTYPE = FILE (PDF) or PRINTER (print); MODE = BITMAP (PDF) or CHARACTER (print); BLANKPAGES = NO | PDF (view in browser) or character-mode print (submitted to printer queue) | CALL_REPORT_ENQ program unit invoked from WHEN-BUTTON-PRESSED on PB_CNCL, after a successful MCP cancellation save; advisor selects PDF or print from the AL_REPORT alert |
| `D:\reports\samples\demo\vr_ew_certificate.rdf` | `GLOBAL.REP_SERVER` (session global) | P_PARENT, P_PRINCIPAL, P_COMP_FA, P_DEALER, P_LOC, P_AMC_NUM (same parameter set, set via SET_REPORT_OBJECT_PROPERTY in CALL_REPORT_ENQ) | PDF or print (set dynamically by CALL_REPORT_ENQ via SET_REPORT_OBJECT_PROPERTY at runtime) | CALL_REPORT_ENQ (form program unit, invoked from WHEN-BUTTON-PRESSED on PB_CNCL); this is the declarative report object (handle: REPORT_CALL) - the filename is overridden at runtime to vr_amc_cncl via SET_REPORT_OBJECT_PROPERTY(repid, REPORT_FILENAME, lv_report_name) |

---

### 20.3.1 Parameters Passed to the Report

This form does not pass parameters to an Oracle Report. No report parameters were identified in the form sources.

## 21. Procedure and Function Business Rule Catalogue

End-to-end business requirement specification for every stored procedure and function referenced by the VT_AMC_CNCL form.

### 21.1 Catalogue Index

61 procedures/functions - each SP ID links to its detailed specification in Section 21.2.

| SP Index | Routine Name |
| :--- | :--- |
| [SP-001](#SP-001--CALL_REPORT_ENQ) | CALL_REPORT_ENQ |
| [SP-002](#SP-002--POP_LIST) | POP_LIST |
| [SP-003](#SP-003--POP_PKG_DETAILS_NEW) | POP_PKG_DETAILS_NEW |
| [SP-004](#SP-004--PROC_AMC_DETAILS) | PROC_AMC_DETAILS |
| [SP-005](#SP-005--SP_INSERT_CHARGES) | SP_INSERT_CHARGES |
| [SP-006](#SP-006--D2KWUTIL.ATTEMPT_DLL_LOAD) | D2KWUTIL.ATTEMPT_DLL_LOAD |
| [SP-007](#SP-007--D2KWUTIL.CREATED_DATE) | D2KWUTIL.CREATED_DATE |
| [SP-008](#SP-008--D2KWUTIL.D2KWUTIL_DEBUGSTRING) | D2KWUTIL.D2KWUTIL_DEBUGSTRING |
| [SP-009](#SP-009--D2KWUTIL.D2KWUTIL_FILEINFO) | D2KWUTIL.D2KWUTIL_FILEINFO |
| [SP-010](#SP-010--D2KWUTIL.FILE_INFO) | D2KWUTIL.FILE_INFO |
| [SP-011](#SP-011--D2KWUTIL.MODIFIED_DATE) | D2KWUTIL.MODIFIED_DATE |
| [SP-012](#SP-012--D2KWUTIL.TRANSLATETYPE) | D2KWUTIL.TRANSLATETYPE |
| [SP-013](#SP-013--GENERAL.ASK_CONFIRM) | GENERAL.ASK_CONFIRM |
| [SP-014](#SP-014--GENERAL.CHECK_NULL) | GENERAL.CHECK_NULL |
| [SP-015](#SP-015--GENERAL.DISP_TEXT) | GENERAL.DISP_TEXT |
| [SP-016](#SP-016--GENERAL.PROC_REPORT_CALL) | GENERAL.PROC_REPORT_CALL |
| [SP-017](#SP-017--GENERAL.PROC_TIMER) | GENERAL.PROC_TIMER |
| [SP-018](#SP-018--GENERAL.PROC_TIMER_EXPIRED) | GENERAL.PROC_TIMER_EXPIRED |
| [SP-019](#SP-019--GENERAL.RAISE_ERROR) | GENERAL.RAISE_ERROR |
| [SP-020](#SP-020--PKG_AMC.SF_GET_SELL_PRICE) | PKG_AMC.SF_GET_SELL_PRICE |
| [SP-021](#SP-021--PKG_AMC.SP_AMC_AVAIL_QTY) | PKG_AMC.SP_AMC_AVAIL_QTY |
| [SP-022](#SP-022--PKG_AMC.SP_POP_CANCEL_DTL) | PKG_AMC.SP_POP_CANCEL_DTL |
| [SP-023](#SP-023--PKG_FDI.SF_VALID_DEALER) | PKG_FDI.SF_VALID_DEALER |
| [SP-024](#SP-024--PKG_FDI.SP_PUSH_FDI_TRANSACTIONS) | PKG_FDI.SP_PUSH_FDI_TRANSACTIONS |
| [SP-025](#SP-025--PKG_LOYALTY.SF_CALCULATE_POINTS_TO_RUPEES) | PKG_LOYALTY.SF_CALCULATE_POINTS_TO_RUPEES |
| [SP-026](#SP-026--PKG_LOYALTY.SF_CALCULATE_RUPEES_TO_POINTS) | PKG_LOYALTY.SF_CALCULATE_RUPEES_TO_POINTS |
| [SP-027](#SP-027--PKG_LOYALTY.SP_CALCULATE_BAL_POINTS) | PKG_LOYALTY.SP_CALCULATE_BAL_POINTS |
| [SP-028](#SP-028--PKG_LOYALTY.SP_GET_VIN_LOYALTY_DTL) | PKG_LOYALTY.SP_GET_VIN_LOYALTY_DTL |
| [SP-029](#SP-029--PKG_LOYALTY.SP_INS_LOYALTY_TRANSACTIONS) | PKG_LOYALTY.SP_INS_LOYALTY_TRANSACTIONS |
| [SP-030](#SP-030--PKG_LOYALTY.SP_RED_RESTRICTION_BAL_POINTS) | PKG_LOYALTY.SP_RED_RESTRICTION_BAL_POINTS |
| [SP-031](#SP-031--PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM) | PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM |
| [SP-032](#SP-032--WEBUTIL.ERRORALERT) | WEBUTIL.ERRORALERT |
| [SP-033](#SP-033--WEBUTIL.FCLOSE) | WEBUTIL.FCLOSE |
| [SP-034](#SP-034--WEBUTIL.FOPEN) | WEBUTIL.FOPEN |
| [SP-035](#SP-035--WEBUTIL.GETIMPLCLASS) | WEBUTIL.GETIMPLCLASS |
| [SP-036](#SP-036--WEBUTIL.GETPROPERTY) | WEBUTIL.GETPROPERTY |
| [SP-037](#SP-037--WEBUTIL.ID_NULL) | WEBUTIL.ID_NULL |
| [SP-038](#SP-038--WEBUTIL.LENGTH) | WEBUTIL.LENGTH |
| [SP-039](#SP-039--WEBUTIL.PUT_LINE) | WEBUTIL.PUT_LINE |
| [SP-040](#SP-040--WEBUTIL.REGISTER_FUNCTION) | WEBUTIL.REGISTER_FUNCTION |
| [SP-041](#SP-041--WEBUTIL.SETPROPERTY) | WEBUTIL.SETPROPERTY |
| [SP-042](#SP-042--WEBUTIL.WAIT) | WEBUTIL.WAIT |
| [SP-043](#SP-043--ADD_ERROR) | ADD_ERROR |
| [SP-044](#SP-044--ADD_EXTERNAL_ERRORS) | ADD_EXTERNAL_ERRORS |
| [SP-045](#SP-045--BOOLTOCHAR) | BOOLTOCHAR |
| [SP-046](#SP-046--CLEAN_ERROR_STACK) | CLEAN_ERROR_STACK |
| [SP-047](#SP-047--DEBUGLOG) | DEBUGLOG |
| [SP-048](#SP-048--FNC_VERIF_MOBILE) | FNC_VERIF_MOBILE |
| [SP-049](#SP-049--REGISTER_FUNCTION_CALL) | REGISTER_FUNCTION_CALL |
| [SP-050](#SP-050--SETDEBUG) | SETDEBUG |
| [SP-051](#SP-051--SF_COPYRIGHT_DECLARATION) | SF_COPYRIGHT_DECLARATION |
| [SP-052](#SP-052--SF_GET_CAR_USER_PHONE) | SF_GET_CAR_USER_PHONE |
| [SP-053](#SP-053--SF_GET_MODEL_CHANNEL) | SF_GET_MODEL_CHANNEL |
| [SP-054](#SP-054--SF_GET_NEXA_VIN) | SF_GET_NEXA_VIN |
| [SP-055](#SP-055--SF_PRINCIPAL_MAP_CD) | SF_PRINCIPAL_MAP_CD |
| [SP-056](#SP-056--SP_PUSH_DMS_MESSAGE) | SP_PUSH_DMS_MESSAGE |
| [SP-057](#SP-057--SP_PUSH_MCPC_FDI_DATA) | SP_PUSH_MCPC_FDI_DATA |
| [SP-058](#SP-058--SP_SMS_CMPMGR) | SP_SMS_CMPMGR |
| [SP-059](#SP-059--SP_VALIDATE_ALPHANUMERIC) | SP_VALIDATE_ALPHANUMERIC |
| [SP-060](#SP-060--STRIPDIRSEP) | STRIPDIRSEP |
| [SP-061](#SP-061--WINDEBUG) | WINDEBUG |

---

### 21.2 Detailed Specifications

#### SP-001 - CALL_REPORT_ENQ

**Invoked From:**

- vt_amc_cncl_fmb.xml [Trigger: FT_PRINT]
- vt_amc_cncl_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

Cancellation Details (N/A / CN_MAIN); Search Details (N/A / CN_MAIN)

---

**Purpose**

Presents the service advisor with a report format selection prompt (PDF or print) after an MCP cancellation has been saved. Depending on the advisor's choice, the procedure generates the MCP cancellation report (`vr_amc_cncl`) by setting all required report parameters and running the report against the Oracle Reports server, either opening the output in the browser as a PDF or submitting it to a printer queue and starting a polling timer.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_principal | VARCHAR2 | IN |
| p_parent | VARCHAR2 | IN |
| p_dealer | VARCHAR2 | IN |
| p_loc | VARCHAR2 | IN |
| p_comp_fa | VARCHAR2 | IN |
| p_amc_num | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.PROC_REPORT_CALL ([SP-016](#SP-016--GENERAL.PROC_REPORT_CALL)) - matched by member name (package unresolved)
- GENERAL.PROC_TIMER ([SP-017](#SP-017--GENERAL.PROC_TIMER)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Locate the declarative report object `REPORT_CALL` in the form and set the report filename to `vr_amc_cncl`.
- Step 2 - Find the `AL_REPORT` alert and display it to the advisor, prompting a choice of PDF (Button 1), Print (Button 2), or dismiss (Button 3/close).
- Step 3 - Read the report server name from the session global `GLOBAL.REP_SERVER`.
- Step 4 - If the advisor selects PDF (Button 1): clear any pending messages; set the report output format to PDF; set all report parameters (P_PARENT, P_PRINCIPAL, P_COMP_FA, P_DEALER, P_LOC, P_AMC_NUM, REPORT_DESTYPE=FILE, MODE=BITMAP, BLANKPAGES=NO); assign the report server and filename; run the report via `RUN_REPORT_OBJECT`; open the resulting document in a new browser tab via `WEB.SHOW_DOCUMENT`.
- Step 5 - If the advisor selects Print (Button 2): set the report filename; set output format to `wided` (character/wide); set all report parameters (REPORT_DESTYPE=PRINTER, MODE=CHARACTER, BLANKPAGES=NO); assign the report server; submit the print job via `GENERAL.PROC_REPORT_CALL`, capturing the report handle and print output filename into session globals `GLOBAL.REPORTHANDLE` and `GLOBAL.PRINTOUTPUT`; start the print polling timer via `GENERAL.PROC_TIMER`.
- Step 6 - If the advisor dismisses the alert (neither Button 1 nor Button 2): clear any pending messages and take no further report action.

---
**Decision Points**

DP-001

Condition:
Advisor selects Button 1 on the AL_REPORT alert (PDF output requested).

TRUE:
Generate the cancellation report in PDF format, set DESTYPE=FILE, MODE=BITMAP, run the report, and open the PDF in a new browser tab.

FALSE:
Proceed to evaluate whether the advisor selected print (DP-002).

DP-002

Condition:
Advisor selects Button 2 on the AL_REPORT alert (Print output requested).

TRUE:
Generate the cancellation report in character/print format, submit to the printer via GENERAL.PROC_REPORT_CALL, store the report handle and print output in session globals, and start the print polling timer.

FALSE:
Advisor dismissed the alert - clear messages and do not generate any report.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The report can only be generated in one of two formats (PDF or print); the advisor must actively choose a format - there is no default generation.
- BR-002 - The report server address is always read from the session global `GLOBAL.REP_SERVER`; no hardcoded server address is used.
- BR-003 - For PDF output, all six report parameters (P_PARENT, P_PRINCIPAL, P_COMP_FA, P_DEALER, P_LOC, P_AMC_NUM) must be set along with REPORT_DESTYPE=FILE, MODE=BITMAP, and BLANKPAGES=NO before the report is run.
- BR-004 - For print output, the report job handle and print output filename are stored in session globals so that the print polling timer (started by GENERAL.PROC_TIMER) can track the job to completion.

---
**Implementation Logic**

```plsql
PROCEDURE CALL_REPORT_ENQ(p_principal VARCHAR2,
												  p_parent 		VARCHAR2,
												  p_dealer 	  VARCHAR2,
                          p_loc 			VARCHAR2, 
                          p_comp_fa 	VARCHAR2,  
                          p_amc_num 	VARCHAR2
                         )IS
	repid  					REPORT_OBJECT;
	lv_rep  				VARCHAR2(100);
	lv_report_name 	VARCHAR2(50);
	lv_server 			VARCHAR2(20) := :global.rep_server;
	lv_alert 				VARCHAR2(20);
	l_v_Param				VARCHAR2(50);
	l_AlertId				ALERT;
	lv_param				VARCHAR2(100);
	lv_report       varchar2(2000);
	lv_print        varchar2(2000);
	LV_REP_FLAG			varchar2(1);

Begin
	--Checking The Alert Button
	repid := Find_Report_Object('REPORT_CALL');
	lv_report_name := 'vr_amc_cncl';
	l_AlertId := Find_Alert('AL_REPORT');
	lv_alert := Show_Alert(l_AlertId);
	If lv_alert = Alert_Button1 Then
    Clear_Message;
	  Set_Report_Object_Property(repid,Report_Desformat,'PDF');
		--Set_Report_Object_Property(repid,Report_Destype,'FILE');    
	  SET_REPORT_OBJECT_PROPERTY(repid,Report_Other,' P_PARENT='||p_parent||
                                                  ' P_PRINCIPAL='||to_number(p_principal)||
                                                  ' P_COMP_FA='||p_comp_fa||
                                                  ' P_DEALER='||to_number(p_dealer)||
                                                  ' P_LOC='||p_loc||
                                                  ' P_AMC_NUM='||p_amc_num||
                                                  ' REPORT_DESTYPE =FILE'||
                                                  ' MODE=BITMAP BLANKPAGES=NO');		                                         
		Set_Report_Object_Property(repid,Report_Server,lv_server);
		Set_Report_Object_Property(repid,REPORT_FILENAME,lv_report_name);
    lv_rep := RUN_REPORT_OBJECT(repid);
    web.show_document('/reports/rwservlet/getjobid'||substr(lv_rep,instr(lv_rep,'_',-1)+1)||'?'||'server='||lv_server,'_blank');
	Elsif lv_alert = Alert_Button2 Then
		SET_REPORT_OBJECT_PROPERTY(repid,REPORT_FILENAME,lv_report_name);
		SET_REPORT_OBJECT_PROPERTY(repid,REPORT_DESFORMAT,'wided');
	  SET_REPORT_OBJECT_PROPERTY(repid,Report_Other,' P_PARENT='||p_parent||
                                                  ' P_PRINCIPAL='||to_number(p_principal)||
                                                  ' P_COMP_FA='||p_comp_fa||
                                                  ' P_DEALER='||to_number(p_dealer)||
                                                  ' P_LOC='||p_loc||
                                                  ' P_AMC_NUM='||p_amc_num||
                                                  ' REPORT_DESTYPE =PRINTER'||
                                                  ' MODE=CHARACTER BLANKPAGES=NO');		                                         
	 	SET_REPORT_OBJECT_PROPERTY(repid,REPORT_SERVER,lv_server);
	 	general.PROC_REPORT_CALL (REPID,lv_report,lv_print);
	 	:global.reporthandle := lv_report;
		:global.printoutput  := lv_print;
        general.PROC_TIMER;	
	Else
		Clear_Message;
	End If;
End;
```

#### SP-002 - POP_LIST

**Invoked From:**

- vt_amc_cncl_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

Search Details (N/A / CN_MAIN)

---

**Purpose**

Initialises the cancellation charges drop-down list on the CN_MAIN screen at form startup by populating the record group RG_CNCL_CHG and binding it to the CANCEL_CHARGES list item, ensuring the list is ready for user interaction when the form opens.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Execute the built-in Populate_Group function against the record group RG_CNCL_CHG and capture the return code in the local variable errcode.
- Step 2 - Call the built-in Populate_List to bind the freshly populated record group RG_CNCL_CHG to the CANCEL_CHARGES list item, loading all available cancellation charge values into the on-screen drop-down.

---
**Decision Points**

No conditional decision points are present in this procedure. The logic executes sequentially without branching; the return code from Populate_Group is captured but no conditional action is taken based on its value.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The record group RG_CNCL_CHG must be populated before the CANCEL_CHARGES list item is rendered; POP_LIST is therefore invoked during the WHEN-NEW-FORM-INSTANCE trigger to guarantee the list is available prior to any user interaction.
- BR-002 - The CANCEL_CHARGES list item is exclusively sourced from the record group RG_CNCL_CHG; no alternative data source is used to populate this list.

---
**Implementation Logic**

```plsql
PROCEDURE POP_LIST IS
	errcode NUMBER;
BEGIN
  errcode := Populate_Group('RG_CNCL_CHG');
  Populate_List('CANCEL_CHARGES', 'RG_CNCL_CHG'); 	  
END;
```

#### SP-003 - POP_PKG_DETAILS_NEW

**Invoked From:**

- vt_amc_cncl_fmb.xml [Trigger: WHEN-LIST-CHANGED]

---

**Screen:**

Cancellation Details (N/A / CN_MAIN)

---

**Purpose**

Aggregates the AMC package cancellation charge and refund amounts from the session temporary table (`GBL_AMC_DTL`) and populates the cancellation detail block on the form. It reads all package service lines for the current contract, separates them by service type (Labour, Parts, Consumables), and calculates the cancellation deduction, refund, and tax amounts per service type as well as the overall totals shown to the advisor.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Open a cursor over `GBL_AMC_DTL` filtered to the current session context (parent group, dealer, location, financial area) and the selected AMC contract number.
- Step 2 - For each service detail row, determine the service type code (`srv_type`): if 'L' (Labour), accumulate the cancellation amount, refund amount, and tax amount into Labour accumulators; if 'P' (Parts), accumulate into Parts accumulators; if 'C' (Consumables), accumulate into Consumables accumulators.
- Step 3 - Cancellation amount per row = (sell price - discount amount - total value); refund amount per row = total value; tax amount per row = charge amount.
- Step 4 - After all rows are processed, compute the overall totals: total cancellation amount = sum of Labour + Parts + Consumables cancellation amounts; total refund = sum of all refund amounts; total tax = sum of all tax amounts.
- Step 5 - Write the rounded (2 decimal places) results into the form block fields: labour/parts/consumable refund amounts, labour/parts/consumable tax amounts, total cancellation amount, total tax, total refund, and net refund (total refund + total tax).

---
**Decision Points**

DP-001

Condition:
Current service detail row has `srv_type = 'L'` (Labour).

TRUE:
Add the row's cancellation amount, refund amount, and tax amount to the Labour accumulators.

FALSE:
Evaluate whether `srv_type = 'P'` (DP-002).

DP-002

Condition:
Current service detail row has `srv_type = 'P'` (Parts).

TRUE:
Add the row's cancellation amount, refund amount, and tax amount to the Parts accumulators.

FALSE:
Evaluate whether `srv_type = 'C'` (DP-003).

DP-003

Condition:
Current service detail row has `srv_type = 'C'` (Consumables).

TRUE:
Add the row's cancellation amount, refund amount, and tax amount to the Consumables accumulators.

FALSE:
Row is ignored for aggregation purposes.

---
**Database Interactions**

- DB-001 - Read GBL_AMC_DTL - Reads data from GBL_AMC_DTL for lookup or validation.
**Business Rules**

- BR-001 - All monetary values are treated as zero if NULL (NVL to 0) before accumulation to avoid propagation of null amounts.
- BR-002 - Cancellation deduction per service line = sell_price - discount_amt - tot_value; this ensures only the non-discounted, non-refundable portion is treated as the cancellation charge.
- BR-003 - Final amounts are rounded to 2 decimal places before being written to the form block.
- BR-004 - Net refund amount = total refund amount + total tax amount, representing the total amount to be returned to the customer.

---
**Implementation Logic**

```plsql
PROCEDURE POP_PKG_DETAILS_NEW IS
	CURSOR cur_d IS
		SELECT *
		  FROM gbl_amc_dtl r
	   WHERE parent_group = :global.parent_group
	     AND dealer_map_cd = :global.dealer
	     AND loc_cd = :global.loc_cd
	     AND comp_fa = :global.comp_fa        
	     AND pkg_code = :B_VH_AMC_ENQ.AMC_NUM;

  ln_lbr_can_amt   NUMBER(12,3) := 0;
  ln_part_can_amt  NUMBER(12,3) := 0;
  ln_cons_can_amt  NUMBER(12,3) := 0;
  ln_tot_can_amt   NUMBER(12,3) := 0;  	     	       	     	     

  ln_lbr_ref_amt   NUMBER(12,3) := 0;
  ln_part_ref_amt  NUMBER(12,3) := 0;
  ln_cons_ref_amt  NUMBER(12,3) := 0;  	     	     
  ln_tot_ref_amt   NUMBER(12,3) := 0;  	     	     
   
  ln_lbr_tax   NUMBER(12,3) := 0;
  ln_part_tax  NUMBER(12,3) := 0;
  ln_cons_tax  NUMBER(12,3) := 0;
  ln_tot_tax   NUMBER(12,3) := 0;  	      	       	      	     
BEGIN
	FOR cur_i IN cur_d LOOP
		IF cur_i.srv_type = 'L' THEN
			ln_lbr_can_amt := NVL(ln_lbr_can_amt, 0) + (NVL(cur_i.sell_price,0) - NVL(cur_i.discount_amt,0) - NVL(cur_i.tot_value,0));
      ln_lbr_ref_amt := NVL(ln_lbr_ref_amt, 0) + NVL(cur_i.tot_value, 0 );
      ln_lbr_tax := NVL(ln_lbr_tax, 0) + NVL(cur_i.charge_amt, 0 );
		ELSIF cur_i.srv_type = 'P' THEN
			ln_part_can_amt := NVL(ln_part_can_amt, 0) + (NVL(cur_i.sell_price,0) - NVL(cur_i.discount_amt,0) - NVL(cur_i.tot_value,0));
			ln_part_ref_amt := NVL(ln_part_ref_amt, 0) + NVL(cur_i.tot_value, 0 );
			ln_part_tax := NVL(ln_part_tax, 0) + NVL(cur_i.charge_amt, 0 );
		ELSIF cur_i.srv_type = 'C' THEN
			ln_cons_can_amt := NVL(ln_cons_can_amt, 0) + (NVL(cur_i.sell_price,0) - NVL(cur_i.discount_amt,0) - NVL(cur_i.tot_value,0));
			ln_cons_ref_amt := NVL(ln_cons_ref_amt, 0) + NVL(cur_i.tot_value, 0 );
			ln_cons_tax := NVL(ln_cons_tax, 0) + NVL(cur_i.charge_amt, 0 );
    END IF;
	END LOOP;	
	ln_tot_can_amt := NVL(ln_lbr_can_amt, 0) + NVL(ln_part_can_amt, 0) + NVL(ln_cons_can_amt, 0);
	ln_tot_ref_amt := NVL(ln_lbr_ref_amt, 0) + NVL(ln_part_ref_amt, 0) + NVL(ln_cons_ref_amt, 0);
	ln_tot_tax		 := NVL(ln_lbr_tax, 0) + NVL(ln_part_tax, 0) + NVL(ln_cons_tax, 0);
	
  :b_vh_amc_enq.labour_rfnd_amt := ROUND(NVL(ln_lbr_ref_amt,  0), 2);
  :b_vh_amc_enq.part_rfnd_amt   := ROUND(NVL(ln_part_ref_amt, 0), 2);
  :b_vh_amc_enq.cons_rfnd_amt   := ROUND(NVL(ln_cons_ref_amt, 0), 2);    

  :b_vh_amc_enq.nb_lbr_tax  := ROUND(NVL(ln_lbr_tax,  0), 2);
  :b_vh_amc_enq.nb_part_tax := ROUND(NVL(ln_part_tax, 0), 2);
  :b_vh_amc_enq.nb_cons_tax := ROUND(NVL(ln_cons_tax, 0), 2);    
  
	:b_vh_amc_enq.cancel_amt  := ROUND(ln_tot_can_amt, 2); 
	:b_vh_amc_enq.nb_tot_tax  := ROUND(ln_tot_tax, 2); 
	:b_vh_amc_enq.nb_tot_rfnd := ROUND(ln_tot_ref_amt, 2); 
	
	:b_vh_amc_enq.net_rfnd_amt := ROUND(NVL(ln_tot_ref_amt, 0) + NVL(ln_tot_tax, 0), 2); 
END;
```

#### SP-004 - PROC_AMC_DETAILS

**Invoked From:**

- vt_amc_cncl_fmb.xml [Trigger: WHEN-NEW-BLOCK-INSTANCE]

---

**Screen:**

Package Details (N/A / CN_MAIN)

---

**Purpose**

Loads the complete AMC enrollment details for a selected MCP contract into the cancellation detail block on the form. It retrieves the enrollment header and detail records, computes remaining service balances (Labour, Parts, Consumables) and combined tax amounts, resolves descriptive lookups (vehicle model, variant, city, package name), and fetches the customer's loyalty programme card status - giving the service advisor a full picture of the contract before processing the cancellation.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-015](#SP-015--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)
- PKG_LOYALTY.SP_GET_VIN_LOYALTY_DTL ([SP-028](#SP-028--PKG_LOYALTY.SP_GET_VIN_LOYALTY_DTL)) - PKG_LOYALTY.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Query `VH_AMC_ENROL` for the AMC enrollment record matching the current principal and selected contract number (with no enquiry type, i.e., active contracts only); iterate over results.
- Step 2 - For each enrollment record, query `VD_AMC_ENROL` to sum the discount amounts by service type (Labour, Parts, Consumables) and the total charge amount; suppress errors if no detail rows exist.
- Step 3 - Copy all enrollment header fields from the cursor row into the detail block on the form (contract dates, vehicle details, customer information, package amounts, used amounts, loyalty points, etc.).
- Step 4 - Compute remaining balances for Labour, Parts, and Consumables: balance = original amount - used amount - discount amount.
- Step 5 - Compute total service tax as the sum of SRV_TAX_AMT, SBC_TAX_AMT, KKC_TAX_AMT from the enrollment plus the detail-level charge amount.
- Step 6 - Call `PKG_LOYALTY.SP_GET_VIN_LOYALTY_DTL` for the current principal and VIN to retrieve loyalty card type, card number, registered vehicle number, balance points, and balance rupees into the form block; suppress any exceptions.
- Step 7 - Resolve the sub-variant description from `VM_SVAR` using the variant and principal; suppress errors.
- Step 8 - Resolve the variant description from `GM_VAR` using the variant code and principal; suppress errors.
- Step 9 - Resolve the city description from `GM_CITY` using the city code and principal; suppress errors.
- Step 10 - Resolve the package description, expiry months, and AMC type from `VM_AMC_PKG` using the package code and principal; suppress errors.
- Step 11 - If any unexpected exception occurs during the overall procedure, display the error message to the advisor via `GENERAL.DISP_TEXT`.

---
**Decision Points**

DP-001

Condition:
`VD_AMC_ENROL` query for discount and charge amounts raises an exception (no detail rows or other error).

TRUE:
Set Labour, Parts, and Consumables discount amounts to zero and continue processing.

FALSE:
Use the retrieved discount and charge amounts in balance calculations.

DP-002

Condition:
`PKG_LOYALTY.SP_GET_VIN_LOYALTY_DTL` raises any exception.

TRUE:
Silently suppress the exception (NULL) - loyalty fields remain unpopulated.

FALSE:
Loyalty card details are populated in the form block.

DP-003

Condition:
Any of the lookup queries (VM_SVAR, GM_VAR, GM_CITY, VM_AMC_PKG) raises an exception.

TRUE:
Silently suppress the exception (NULL) - the corresponding description field remains unpopulated.

FALSE:
The description is resolved and stored in the appropriate form block field.

---
**Database Interactions**

- DB-001 - Read VH_AMC_ENROL - Reads data from VH_AMC_ENROL for lookup or validation.
- DB-002 - Read VD_AMC_ENROL - Reads data from VD_AMC_ENROL for lookup or validation.
- DB-003 - Read VM_SVAR - Reads data from VM_SVAR for lookup or validation.
- DB-004 - Read GM_VAR - Reads data from GM_VAR for lookup or validation.
- DB-005 - Read GM_CITY - Reads data from GM_CITY for lookup or validation.
- DB-006 - Read VM_AMC_PKG - Reads data from VM_AMC_PKG for lookup or validation.
**Business Rules**

- BR-001 - Only active AMC enrollments are retrieved: the query filters on `enq_type IS NULL` to exclude enquiry-type records.
- BR-002 - Remaining service balances are computed as: original amount - used amount - discount amount, ensuring the advisor sees the net available balance per service type.
- BR-003 - Total service tax is the combined sum of three tax components (SRV_TAX_AMT + SBC_TAX_AMT + KKC_TAX_AMT) plus any additional charge amounts from the detail lines.
- BR-004 - All lookup resolutions (sub-variant, variant, city, package) are non-fatal - failures are silently suppressed so the form can still be used with partially resolved descriptions.

---
**Implementation Logic**

```plsql
PROCEDURE PROC_AMC_DETAILS IS
  CURSOR cur_amc IS
     SELECT *
       FROM vh_amc_enrol
      WHERE principal_map_cd  = :global.principal  
			  AND amc_num = :cb_vt_amc_enroll.nb_amc_num1
			  AND enq_type IS NULL;		

  ln_lbr_disc		  NUMBER(15,3) := 0;
  ln_part_disc		NUMBER(15,3) := 0;
  ln_cons_disc		NUMBER(15,3) := 0;	  	
  ln_charge_amt   NUMBER(15,3) := 0;	  
  
BEGIN
	--general.disp_text('Lopp ... '||:global.principal||' - '||:cb_vt_amc_enroll.nb_amc_num1,'Error');	
	FOR cur_i IN cur_amc LOOP
		BEGIN
			SELECT SUM(DECODE(d.srv_type,'L', discount_amt, 0)) lbr_disc,
       			 SUM(DECODE(d.srv_type,'P', discount_amt, 0)) part_disc,
       			 SUM(DECODE(d.srv_type,'C', discount_amt, 0)) cons_disc,
       			 SUM(charge_amt) 
       	INTO ln_lbr_disc, ln_part_disc, ln_cons_disc, ln_charge_amt		 
  			FROM vd_amc_enrol d
 			 WHERE principal_map_cd = cur_i.principal_map_cd
 			   AND amc_num = cur_i.amc_num;
		EXCEPTION WHEN OTHERS THEN
			ln_lbr_disc  := 0; 
			ln_part_disc := 0; 
			ln_cons_disc := 0;
		END;	
 
		--general.disp_text('AMC... '||cur_i.amc_num,'Error');
		:b_vh_amc_enq.principal_map_cd := cur_i.principal_map_cd;
		:b_vh_amc_enq.amc_num  				 := cur_i.amc_num;
		:b_vh_amc_enq.amc_date 				 := cur_i.amc_date;
		:b_vh_amc_enq.amc_start_date 	 := cur_i.amc_start_date;
		:b_vh_amc_enq.amc_end_date 		 := cur_i.amc_end_date;
		:b_vh_amc_enq.expiry_mileage 	 := cur_i.amc_end_mileage;
		:b_vh_amc_enq.reg_num 				 := cur_i.reg_num;
		:b_vh_amc_enq.vin 						 := cur_i.vin;
		:b_vh_amc_enq.chassis_num  		 := cur_i.chassis_num;
		:b_vh_amc_enq.engine_num 			 := cur_i.engine_num;
		:b_vh_amc_enq.variant_cd 	 		 := cur_i.variant_cd;
		:b_vh_amc_enq.svar_cd 		 		 := cur_i.svar_cd;
		:b_vh_amc_enq.cust_cd 	 			 := cur_i.cust_cd;
		:b_vh_amc_enq.cust_name 			 := cur_i.cust_name;
		:b_vh_amc_enq.cust_addr1 			 := cur_i.cust_addr1;
		:b_vh_amc_enq.cust_addr2  		 := cur_i.cust_addr2;
		:b_vh_amc_enq.cust_addr3 			 := cur_i.cust_addr3;
		:b_vh_amc_enq.city_cd 	 			 := cur_i.city_cd;
		:b_vh_amc_enq.phone 		 			 := cur_i.phone;
		:b_vh_amc_enq.mobile 	 				 := cur_i.mobile;
		:b_vh_amc_enq.email					   := cur_i.email;
		:b_vh_amc_enq.odometer_reading := cur_i.odometer_reading;
		:b_vh_amc_enq.selling_parent_group 	:= cur_i.selling_parent_group;
		:b_vh_amc_enq.selling_dealer_map_cd := cur_i.selling_dealer_map_cd;
		:b_vh_amc_enq.selling_loc_cd 			  := cur_i.selling_loc_cd;
		:b_vh_amc_enq.selling_comp_fa 	 		:= cur_i.selling_comp_fa;
		:b_vh_amc_enq.enq_num 		 		 := cur_i.enq_num;
		:b_vh_amc_enq.pkg_code 	 			 := cur_i.pkg_code;
		:b_vh_amc_enq.pkg_amt 			   := cur_i.pkg_amt;
		:b_vh_amc_enq.labour_amt 			 := cur_i.labour_amt;
		:b_vh_amc_enq.part_amt  			 := cur_i.part_amt;
		:b_vh_amc_enq.consumable_amt 	 := cur_i.consumable_amt;
		:b_vh_amc_enq.srv_tax_amt 	   := NVL(cur_i.srv_tax_amt, 0) + NVL(cur_i.sbc_tax_amt, 0) + NVL(cur_i.kkc_tax_amt, 0) + NVL(ln_charge_amt, 0);		
		:b_vh_amc_enq.discount_amt 		 := cur_i.discount_amt;
		:b_vh_amc_enq.tot_bill_amt 	   := cur_i.tot_bill_amt;		
	  :b_vh_amc_enq.labour_used_amt 	   := cur_i.labour_used_amt;
	  :b_vh_amc_enq.part_used_amt  		   := cur_i.part_used_amt;
	  :b_vh_amc_enq.consumable_used_amt  := cur_i.consumable_used_amt;
	  	  
	  :b_vh_amc_enq.nb_lbr_bal	  := nvl(cur_i.labour_amt,0) - nvl(cur_i.labour_used_amt,0) - nvl(ln_lbr_disc,0);
	  :b_vh_amc_enq.nb_part_bal		:= nvl(cur_i.part_amt,0) - nvl(cur_i.part_used_amt,0) - nvl(ln_part_disc,0);
		:b_vh_amc_enq.nb_cons_bal		:= nvl(cur_i.consumable_amt,0) - nvl(cur_i.consumable_used_amt,0) - nvl(ln_cons_disc,0);
		:b_vh_amc_enq.sbc_tax_amt 	   := cur_i.sbc_tax_amt;	---bhawana
		:b_vh_amc_enq.kkc_tax_amt 	   := cur_i.kkc_tax_amt;	---bhawana on 18-may-2016
		
		-- Added by Rajeev on 16-MAY-2018 for Loyalty Details.
		:b_vh_amc_enq.loyl_award_pts 	   := cur_i.loyl_award_pts;	
		:b_vh_amc_enq.loyl_redeem_pts 	 := cur_i.loyl_redeem_pts;
		DECLARE
			lv_err_cd   		NUMBER;
	    lv_err_msg  		VARCHAR2(500);
		BEGIN
			-- Call the procedure
			PKG_LOYALTY.SP_GET_VIN_LOYALTY_DTL(:global.principal,
			                                   :b_vh_amc_enq.VIN,
			                                   :b_vh_amc_enq.NB_LOY_CARD_TYPE,
			                                   :b_vh_amc_enq.NB_LOY_CARD_NUM,
			                                   :b_vh_amc_enq.NB_LOY_REG_NUM,
			                                   :b_vh_amc_enq.NB_LOY_BAL_POINT,
			                                   :b_vh_amc_enq.NB_LOY_BAL_RS,                                     
			                                   lv_err_cd,
			                                   lv_err_msg
			                                   );
		EXCEPTION
			WHEN OTHERS THEN
			  NULL;
		END;
		
		BEGIN
			SELECT svar_desc INTO :b_vh_amc_enq.nb_model_desc
		  	FROM vm_svar
		 	 WHERE svar_cd = :b_vh_amc_enq.svar_cd
		   	 AND principal_map_cd = :global.principal;
		EXCEPTION WHEN OTHERS THEN
			NULL;
		END;

		BEGIN      
			SELECT variant_desc
	    	INTO :b_vh_amc_enq.nb_variant_desc 
	    	FROM gm_var
	   	 WHERE variant_cd = :b_vh_amc_enq.variant_cd 
	     	 AND principal_map_cd = :global.principal;
		EXCEPTION WHEN OTHERS THEN
			NULL;
		END;

		BEGIN
			SELECT city_desc
			  INTO :b_vh_amc_enq.city_desc
			  FROM gm_city
			 WHERE city_cd = :b_vh_amc_enq.city_cd
			   AND principal_map_cd = :global.principal;
		EXCEPTION WHEN OTHERS THEN
			NULL;
		END;	

		BEGIN
			SELECT g.pkg_desc, g.expiry_months, g.amc_type 
			  INTO :b_vh_amc_enq.pkg_desc, :b_vh_amc_enq.expiry_month, :b_vh_amc_enq.amc_type
			  FROM vm_amc_pkg g
			 WHERE principal_map_cd = :global.principal
			   AND g.pkg_code = :b_vh_amc_enq.pkg_code;	
		EXCEPTION WHEN OTHERS THEN
			NULL;
		END;

	END LOOP;	  
EXCEPTION WHEN OTHERS THEN
	general.disp_text('Error... '||sqlerrm,'Error');	
END;
```

#### SP-005 - SP_INSERT_CHARGES

**Invoked From:**

- vt_amc_cncl_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

Cancellation Details (N/A / CN_MAIN)

---

**Purpose**

Finalises the MCP cancellation by generating a credit note (for contracts dated on or after 1 July 2017), inserting all applicable cancellation charge lines into `VD_AMC_CANCELCHARGES` from the session charges table, updating the AMC enrollment record with the cancellation details and computed refund amounts, resetting the VIN expiry date to the cancellation date, recording a loyalty cancellation transaction, and committing the transaction to the database.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-015](#SP-015--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)
- PKG_LOYALTY.SP_INS_LOYALTY_TRANSACTIONS ([SP-029](#SP-029--PKG_LOYALTY.SP_INS_LOYALTY_TRANSACTIONS)) - PKG_LOYALTY.pck (or .pld)
- PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM ([SP-031](#SP-031--PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM)) - PK_VALIDATE_BACK_DATE.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Check whether the AMC enrollment date is on or after 1 July 2017. If yes, call `PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM` with the current dealer, principal, location, financial area, document type 'ACR', financial year, and cancellation date to generate the credit note number; if the call returns a non-zero error code, display the error message and halt with a form trigger failure.
- Step 2 - If the enrollment date is before 1 July 2017, skip credit note generation (set error code to 0 and error message to NULL).
- Step 3 - If no error (credit note generation succeeded or was not required), insert all charge lines from `GBL_AMC_CHARGES` (filtered by the current session context and contract number) into `VD_AMC_CANCELCHARGES`, carrying over all charge details plus setting `created_by` to the current user and `created_date` to SYSDATE.
- Step 4 - Update `VH_AMC_ENROL` to record the cancellation: set `CANCEL_YN = 'Y'`, `CANCEL_DATE`, `CANCEL_CHARGES`, `LABOUR_RFND_AMT`, `PART_RFND_AMT`, `CONS_RFND_AMT`, `CANCEL_AMT`, `NET_RFND_AMT`, `CANCEL_REASON`, and `CREDIT_NOTE_NO` (the generated credit note number) for the matching principal and contract number.
- Step 5 - Update `GM_VIN_EXT` to set the AMC expiry date for the vehicle's VIN to the truncated cancellation date.
- Step 6 - Call `PKG_LOYALTY.SP_INS_LOYALTY_TRANSACTIONS` to record a loyalty cancellation transaction (transaction type 'MCPC') for the loyalty card associated with the vehicle; suppress any exceptions silently.
- Step 7 - Commit the database transaction.
- Step 8 - If any unhandled exception occurs during the procedure, display the error message via `GENERAL.DISP_TEXT` and raise a form trigger failure.

---
**Decision Points**

DP-001

Condition:
AMC enrollment date (`amc_date`) is on or after 1 July 2017.

TRUE:
Generate a credit note number via `PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM` using document type 'ACR'.

FALSE:
Skip credit note generation; proceed directly to inserting cancellation charge lines.

DP-002

Condition:
Credit note generation call returns a non-zero error code (`NVL(lv_err_cd, 0) <> 0`).

TRUE:
Display the error message to the advisor and raise `FORM_TRIGGER_FAILURE` to abort the save.

FALSE:
Continue with inserting cancellation charges and updating records.

DP-003

Condition:
`PKG_LOYALTY.SP_INS_LOYALTY_TRANSACTIONS` raises any exception.

TRUE:
Silently suppress the exception (NULL) - the cancellation proceeds without blocking on a loyalty failure.

FALSE:
Loyalty transaction is recorded successfully.

---
**Database Interactions**

- DB-001 - Insert into VD_AMC_CANCELCHARGES - Persists a new row into VD_AMC_CANCELCHARGES using columns: principal map cd, amc num, srl num, srv type, srv cd, charge srl, common ind, order srl, and 7 more column(s).
- DB-002 - Read GBL_AMC_CHARGES - Reads data from GBL_AMC_CHARGES for lookup or validation.
- DB-003 - Update VH_AMC_ENROL - Updates existing rows in VH_AMC_ENROL (columns: cancel yn, cancel date, cancel charges, labour rfnd amt, part rfnd amt, cons rfnd amt, cancel amt, net rfnd amt, and 2 more column(s)).
- DB-004 - Update GM_VIN_EXT - Updates existing rows in GM_VIN_EXT (columns: amc exp date).
**Business Rules**

- BR-001 - A credit note (document type 'ACR') must be generated for any MCP contract with an enrollment date on or after 1 July 2017; contracts before that date do not require a credit note.
- BR-002 - If credit note generation fails (non-zero error code returned), the entire cancellation transaction must be aborted - no charges are inserted and no records are updated.
- BR-003 - Cancellation charge lines are sourced from the session table `GBL_AMC_CHARGES` filtered to the current dealer session context; the principal code is taken from the session global (`GLOBAL.PRINCIPAL`).
- BR-004 - The AMC enrollment record must be updated to mark `CANCEL_YN = 'Y'` with all refund amounts, cancellation date, charges, reason, and credit note number as a single atomic update.
- BR-005 - The vehicle's AMC expiry date in `GM_VIN_EXT` must be reset to the cancellation date (truncated) to prevent the vehicle from showing active AMC coverage after cancellation.
- BR-006 - A loyalty cancellation transaction of type 'MCPC' is always attempted after the main database updates, but a failure in this loyalty call must not block or roll back the cancellation.
- BR-007 - The entire set of database changes (charges insert, enrollment update, VIN extension update, loyalty transaction) is committed in a single COMMIT at the end of the procedure.

---
**Implementation Logic**

```plsql
PROCEDURE SP_INSERT_CHARGES IS
  lv_crn      vh_amc_enrol.credit_note_no%TYPE;
  lv_err_msg  VARCHAR2 (1000);
  lv_err_cd   NUMBER;  
BEGIN
	IF :b_vh_amc_enq.amc_date >= '01-JUL-2017' THEN
		 pk_validate_back_date.generate_next_num (:GLOBAL.dealer,
		                                          :GLOBAL.principal,
		                                          :GLOBAL.loc_cd,
		                                          :GLOBAL.comp_fa,
		                                          'ACR',
		                                          lv_crn,
		                                          lv_err_msg,
		                                          lv_err_cd,
		                                          :GLOBAL.p_fin_yr,
		                                          :b_vh_amc_enq.cancel_date
		                                          );
		
		 IF NVL (lv_err_cd, 0) <> 0 THEN
		    general.disp_text (lv_err_msg, 'Error');
		    RAISE form_trigger_failure;
		 END IF;
	ELSE
		 lv_err_cd  := 0;
		 lv_err_msg := NULL;	
	END IF;
	 
  IF NVL (lv_err_cd, 0) = 0 THEN   
	  INSERT INTO vd_amc_cancelcharges(principal_map_cd,
																		 amc_num,
																		 srl_num,
																		 srv_type,
																		 srv_cd,
																		 charge_srl,
																		 common_ind,
																		 order_srl,
																		 charge_cd,
																		 charge_type,
																		 charge_ind,
																		 charge_value,
																		 charge_amt,
																		 created_by,
																		 created_date
																		 )
														SELECT :GLOBAL.PRINCIPAL,
																	 pkg_code,
																	 srl_num,
																	 srv_type,
																	 srv_cd,
																	 charge_srl,
																	 common_ind,
																	 order_srl,
																	 charge_cd,
																	 charge_type,
																	 charge_ind,
																	 charge_value,
																	 charge_amt,
																	 :GLOBAL.USERID,
																	 SYSDATE
	                            FROM gbl_amc_charges
												 		 WHERE parent_group = :global.parent_group
														   AND dealer_map_cd = :global.dealer
														   AND loc_cd = :global.loc_cd
														   AND comp_fa = :global.comp_fa        
														   AND pkg_code = :B_VH_AMC_ENQ.AMC_NUM;    
	    
			UPDATE vh_amc_enrol 
			   SET cancel_yn     = 'Y',      
					   cancel_date   =  :b_vh_amc_enq.cancel_date,    
						 cancel_charges = :b_vh_amc_enq.cancel_charges,   
						 labour_rfnd_amt  = :b_vh_amc_enq.labour_rfnd_amt,    
						 part_rfnd_amt    = :b_vh_amc_enq.part_rfnd_amt,     
						 cons_rfnd_amt    = :b_vh_amc_enq.cons_rfnd_amt,     
						 cancel_amt   	  = :b_vh_amc_enq.cancel_amt,
						 net_rfnd_amt	    = :b_vh_amc_enq.net_rfnd_amt,
						 cancel_reason    = :b_vh_amc_enq.canc_reason,
						 credit_note_no   = lv_crn
			 WHERE principal_map_cd = :global.principal 
				 AND amc_num = :b_vh_amc_enq.amc_num;
	
		  UPDATE gm_vin_ext
		     SET amc_exp_date	= trunc(:b_vh_amc_enq.cancel_date)
		   WHERE vin = :b_vh_amc_enq.vin;	 
      
       /*
       -- Added by Rajeev on 16-MAY-2018 for Loyalty Details.
   		 IF :b_vh_amc_enq.LOYL_REDEEM_PTS > 0 THEN   				
   				pkg_loyalty.sp_ins_loyalty_transactions(:b_vh_amc_enq.NB_LOY_CARD_NUM,
	                                                :b_vh_amc_enq.VIN,         				 
	                                                'REDM',                          
	                                                to_char(SYSDATE,'DD-MM-YYYY HH24:MI:SS'),                          
	                                                :b_vh_amc_enq.AMC_NUM,    				 
	                                                'MCP Cancellation',    						
	                                                :GLOBAL.PARENT_GROUP,             
	                                                :GLOBAL.DEALER,                    
	                                                :GLOBAL.LOC_CD ,                  
	                                                :b_vh_amc_enq.LOYL_REDEEM_PTS,    
	                                                :b_vh_amc_enq.LOYL_REDEEM_PTS,     
	                                                'C',                              
	                                                :GLOBAL.userid,                   
	                                                lv_err_cd,
	                                                lv_err_msg
	                                                );                                               
   		 END IF;	
   		 IF :b_vh_amc_enq.LOYL_AWARD_PTS > 0 THEN   				
   				pkg_loyalty.sp_ins_loyalty_transactions(:b_vh_amc_enq.NB_LOY_CARD_NUM,
                                                  :b_vh_amc_enq.VIN,       				
                                                  'MCPC',                          
                                                   to_char(SYSDATE,'DD-MM-YYYY HH24:MI:SS'),                      
                                                  :b_vh_amc_enq.AMC_NUM,   				 
                                                  'MCP Cancellation',    					
                                                  :GLOBAL.PARENT_GROUP,           
                                                  :GLOBAL.DEALER,                 
                                                  :GLOBAL.LOC_CD ,                 
                                                  :b_vh_amc_enq.LOYL_AWARD_PTS, 	 
                                                  :b_vh_amc_enq.LOYL_AWARD_PTS, 	
                                                  'D',
                                                  :GLOBAL.userid,                  
                                                  lv_err_cd,
                                                  lv_err_msg
                                                  );                                                  
   			END IF;	
        */
   			BEGIN
   				pkg_loyalty.sp_ins_loyalty_transactions(:b_vh_amc_enq.NB_LOY_CARD_NUM,
                                                  :b_vh_amc_enq.VIN,       				
                                                  'MCPC',                          
                                                   to_char(SYSDATE,'DD-MM-YYYY HH24:MI:SS'),                      
                                                  :b_vh_amc_enq.AMC_NUM,   				 
                                                  'MCP Cancellation',    					
                                                  :GLOBAL.PARENT_GROUP,           
                                                  :GLOBAL.DEALER,                 
                                                  :GLOBAL.LOC_CD ,                 
                                                  NULL, 	 
                                                  NULL, 	
                                                  NULL,
                                                  :GLOBAL.userid,                  
                                                  lv_err_cd,
                                                  lv_err_msg
                                                  );                                                  
   			EXCEPTION
   				WHEN OTHERS THEN
   				 NULL;
   			END;	
      
		  COMMIT;
  END IF;
  
EXCEPTION WHEN OTHERS THEN
	general.disp_text ('Error... AMC Calculation'||sqlerrm, 'Error');
	RAISE form_trigger_failure; 		
END;
```

#### SP-006 - D2KWUTIL.ATTEMPT_DLL_LOAD

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Attempts to load a specified DLL into memory via ORA_FFI, optionally verifying the file's physical existence at a given path before loading. The procedure normalises the target path, confirms the DLL file is accessible, loads the library, and-when instructed-increments the global DLL load counter and marks the API as enabled. It returns an ORA_FFI library handle to the caller (REGISTER_FUNCTION_CALL) for subsequent foreign-function interface registrations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |
| TargetDLL | VARCHAR2 | IN |
| LoadCount | BOOLEAN | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |

---

**Dependencies**

- DEBUGLOG ([SP-047](#SP-047--DEBUGLOG)) - matched by member name
- STRIPDIRSEP ([SP-060](#SP-060--STRIPDIRSEP)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate whether TargetPath is non-null; if it is null, skip path validation and proceed directly to the library load attempt.
- Step 2 - Normalise TargetPath by passing it through STRIPDIRSEP to remove any extraneous trailing directory separators, then append a single backslash ('\'), ensuring a consistently formatted path regardless of how the caller supplied it. This also discards any secondary paths that may have been concatenated in TargetPath.
- Step 3 - Attempt to open the file at the concatenated location (TargetPath || TargetDLL) in read mode using TEXT_IO.FOPEN to confirm the DLL physically exists at that location.
- Step 4 - If the file opens successfully, close it immediately with TEXT_IO.FCLOSE; the open was purely a file-existence check.
- Step 5 - If the file cannot be opened, invoke DEBUGLOG (severity 99, context 'Attempt_DLL_LOAD') to record that the DLL was not found at the specified location, then raise the BadLocation exception to abort processing.
- Step 6 - Call ORA_FFI.LOAD_LIBRARY with the validated TargetPath and TargetDLL to load the library into memory and obtain an ORA_FFI.LibHandleType handle (hDLL).
- Step 7 - If the LoadCount flag is TRUE, increment the package-level counter DLL_LOAD_COUNT by 1 and set the package-level flag API_ENABLED to TRUE, recording that a DLL was successfully loaded and the API is available.
- Step 8 - Return the populated library handle hDLL to the caller.
- Step 9 - If any unhandled exception occurs during the load phase, set API_ENABLED to FALSE and return the null hDLL handle, signalling to the caller that the load failed without raising a hard error.

---
**Decision Points**

DP-001

Condition: TargetPath IS NOT NULL

TRUE: Normalise TargetPath via STRIPDIRSEP and append a backslash, then perform a physical file-existence check before attempting the library load.

FALSE: Skip path normalisation and file-existence verification; proceed directly to ORA_FFI.LOAD_LIBRARY using the null path.

---

DP-002

Condition: TEXT_IO.FOPEN succeeds for the file at TargetPath || TargetDLL

TRUE: Close the file handle and continue to the ORA_FFI.LOAD_LIBRARY call.

FALSE: Log the missing-file event via DEBUGLOG and raise the BadLocation exception, halting further processing.

---

DP-003

Condition: LoadCount IS TRUE (after a successful ORA_FFI.LOAD_LIBRARY call)

TRUE: Increment DLL_LOAD_COUNT by 1 and set API_ENABLED to TRUE.

FALSE: Skip counter increment and API_ENABLED update; return the handle without modifying package-level state.

---

DP-004

Condition: An unhandled exception is raised during the ORA_FFI library load phase

TRUE: Set API_ENABLED to FALSE and return the null hDLL handle to the caller.

FALSE: Normal execution path; return the populated hDLL handle.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - TargetPath must contain exactly one directory path; if multiple paths are present, only the first segment (as produced by STRIPDIRSEP) is used and any additional paths are silently discarded.
- BR-002 - A trailing backslash separator must always be appended to TargetPath after normalisation, ensuring ORA_FFI.LOAD_LIBRARY receives a consistently formatted directory path.
- BR-003 - When TargetPath is provided, the DLL file must physically exist and be readable at the resolved location before a load is attempted; a DLL that cannot be opened triggers a BadLocation exception and prevents the load.
- BR-004 - All file-not-found failures must be logged via DEBUGLOG at severity level 99 with the context identifier 'Attempt_DLL_LOAD' before the BadLocation exception is raised.
- BR-005 - The package-level counter DLL_LOAD_COUNT must be incremented by exactly 1 for each successful DLL load where LoadCount is TRUE, maintaining an accurate tally of loaded libraries.
- BR-006 - API_ENABLED must be set to TRUE only upon a successful library load with LoadCount TRUE, and must be set to FALSE whenever an unhandled exception prevents the load from completing.
- BR-007 - On any unhandled load failure, the procedure must return a null library handle rather than propagating the exception, allowing the caller to handle the failure gracefully.

---
**Implementation Logic**

```plsql

FUNCTION  Attempt_DLL_Load  (TargetPath in out VARCHAR2, TargetDLL in VARCHAR2, LoadCount in BOOLEAN DEFAULT TRUE) return ORA_FFI.LibHandleType is
  hDLL  ORA_FFI.LibHandleType;
  hFile TEXT_IO.FILE_TYPE;
begin 
    	
  if TargetPath is not null then 
    -- Watch out for folks who put multiple Paths in here 
    -- Oh yes it's happened! Just use the first & throw the rest away
    -- Add trailing Directory Sep if required
    TargetPath := StripDirSep(TargetPath)||'\';
    
    -- Check that there is actually a file there.
    begin 
  	  hFile := TEXT_IO.FOPEN(TargetPath||TargetDLL,'R');
  	  TEXT_IO.FCLOSE(hFile);
    exception
  	  when others then
  	    Win_API_Debug.DebugLog(99,'Attempt_DLL_LOAD',TargetDLL||' not found in the specified location of "'||TargetPath||'"'); 
  		  raise BadLocation;
    end;
  end if;
  
  hDLL := ORA_FFI.LOAD_LIBRARY(TargetPath, TargetDLL);
  if LoadCount then 
    DLL_LOAD_COUNT  := DLL_LOAD_COUNT + 1;
    API_ENABLED  := TRUE;
  end if;
  return hDLL;
exception
  when others then 
    API_ENABLED := FALSE;
    return hDLL; /* Will be null */
end Attempt_DLL_Load;
```

#### SP-007 - D2KWUTIL.CREATED_DATE

**Invoked From:**

- PKG_FDI.pck [StoredProcedure: PKG_FDI.SP_PUSH_FDI_TRANSACTIONS]
- PKG_LOYALTY.pck [StoredProcedure: PKG_LOYALTY.SP_INS_LOYALTY_TRANSACTIONS]
- SP_PUSH_DMS_MESSAGE.prc [StoredProcedure: SP_PUSH_DMS_MESSAGE]
- SP_SMS_CMPMGR.prc [StoredProcedure: SP_SMS_CMPMGR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the creation timestamp (date and milliseconds) of a specified client-side file by invoking the low-level file information utility. It translates the raw numeric date/time buffers returned by the system call into an Oracle DATE value and a milliseconds component.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| FileName | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| ReturnDate | DATE | OUT |
| ReturnMS | NUMBER | OUT |

---

**Dependencies**

- D2KWUTIL.FILE_INFO ([SP-010](#SP-010--D2KWUTIL.FILE_INFO)) - D2KWUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Call `File_Info` with function context "Created_Date", the supplied filename, and option values 1/1 (indicating creation date fields), passing through the `RaiseExceptions` flag.
- Step 2 - Convert the integer buffers (iBuff3-iBuff9) returned by `File_Info` into a DATE value in YYYYMMDDHH24MISS format and assign it to the `ReturnDate` OUT parameter.
- Step 3 - Assign the milliseconds buffer (iBuff9) to the `ReturnMS` OUT parameter.

---
**Decision Points**

No branching decision points identified in the implementation logic.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

BR-001 - The creation date is derived from the numeric buffers populated by the system-level `FILE_INFO` call; no direct file I/O is performed by this routine.
BR-002 - If `RaiseExceptions` is TRUE and the file does not exist or an error occurs in the underlying call, an exception is raised to the caller.

---
**Implementation Logic**

```plsql

PROCEDURE Created_Date (  FileName        IN   VARCHAR2,
                          ReturnDate      OUT  DATE,
                          ReturnMS        OUT  NUMBER,
                          RaiseExceptions IN   BOOLEAN DEFAULT FALSE) is
begin 
  File_Info('Created_Date',Filename,1,1,RaiseExceptions);
  ReturnDate := to_date(to_char(iBuff3,'0999')||to_char(iBuff4,'09')||to_char(iBuff5,'09')||to_char(iBuff6,'09')||to_char(iBuff7,'09')||to_char(iBuff8,'09'),'YYYYMMDDHH24MISS');
  ReturnMS   := iBuff9;
end Created_Date;
```

#### SP-008 - D2KWUTIL.D2KWUTIL_DEBUGSTRING

**Invoked From:**

- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level interface to an external C library function that outputs a debug string during Oracle Forms runtime. The procedure passes a function handle and a text message to the underlying C implementation via the ORA_FFI foreign-function interface, enabling diagnostic or trace messages to be surfaced through the D2KWUTIL windowing debug channel.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the foreign-function handle (hFunc) identifying the target C routine within the D2KWUTIL library and the debug text string (Text) to be transmitted.
- Step 2 - Delegate execution directly to the bound C function referenced by hFunc, passing Text as the message payload, using the ORA_FFI PRAGMA INTERFACE mechanism (interface code 11265).
- Step 3 - Return control to the caller (WINDEBUG in D2kwutil.pld) upon completion of the external call; no return value or output parameter is produced.

---
**Decision Points**

No decision points are present in this procedure. The implementation consists solely of a foreign-function call with no conditional branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must be invoked with a valid ORA_FFI.funcHandleType handle; the handle must reference the D2KWUTIL C library function bound at interface code 11265, as declared by the PRAGMA INTERFACE directive.
- BR-002 - The Text parameter carries the debug message exactly as supplied by the caller; no transformation, truncation, or validation is applied within this procedure.
- BR-003 - This procedure produces no output parameters and performs no database interactions; its sole effect is the side-effect of the external C call, making it unsuitable for use outside a debug or diagnostic context.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.
   
 PROCEDURE d2kwutil_DebugString (    hFunc       IN      ORA_FFI.funcHandleType,
                                     Text        IN      VARCHAR2);
 -- Pragmas
 PRAGMA INTERFACE(C,d2kwutil_DebugString,      11265);
```

#### SP-009 - D2KWUTIL.D2KWUTIL_FILEINFO

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.FILE_INFO]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

A low-level foreign function interface (FFI) declaration that bridges Oracle Forms PL/SQL to the native Windows `D2KWUTIL` DLL to obtain file metadata. Only a specification is present in the source - no PL/SQL body was found. It is called internally by `D2KWUTIL.FILE_INFO` to invoke the native file information system call.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| FileName | VARCHAR2 | IN OUT |
| Option1 | PLS_INTEGER | IN |
| Option2 | PLS_INTEGER | IN |
| dwOut1 | PLS_INTEGER | IN OUT |
| dwOut2 | PLS_INTEGER | IN OUT |
| dwOut3 | PLS_INTEGER | IN OUT |
| dwOut4 | PLS_INTEGER | IN OUT |
| dwOut5 | PLS_INTEGER | IN OUT |
| dwOut6 | PLS_INTEGER | IN OUT |
| dwOut7 | PLS_INTEGER | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| FileName | VARCHAR2 | IN OUT |
| dwOut1 | PLS_INTEGER | IN OUT |
| dwOut2 | PLS_INTEGER | IN OUT |
| dwOut3 | PLS_INTEGER | IN OUT |
| dwOut4 | PLS_INTEGER | IN OUT |
| dwOut5 | PLS_INTEGER | IN OUT |
| dwOut6 | PLS_INTEGER | IN OUT |
| dwOut7 | PLS_INTEGER | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept a function handle, filename (IN OUT), two option integers, and seven output integer buffers.
- Step 2 - Invoke the native DLL function via the Oracle FFI handle to populate the output buffers with file metadata.
- Step 3 - Return an integer return code indicating success or failure.

---
**Decision Points**

No branching decision points identified in the implementation logic.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

BR-001 - This is an external FFI declaration only; the actual logic is implemented in the native DLL. No PL/SQL body is available in the source.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.
                                                                                                                                                         
FUNCTION d2kwutil_FileInfo ( hFunc      IN      ORA_FFI.funcHandleType,
                             FileName   IN OUT  VARCHAR2,
                             Option1    IN      PLS_INTEGER,
                             Option2    IN      PLS_INTEGER,
                             dwOut1     IN OUT  PLS_INTEGER,
                             dwOut2     IN OUT  PLS_INTEGER,
                             dwOut3     IN OUT  PLS_INTEGER,
                             dwOut4     IN OUT  PLS_INTEGER,
                             dwOut5     IN OUT  PLS_INTEGER,
                             dwOut6     IN OUT  PLS_INTEGER,
                             dwOut7     IN OUT  PLS_INTEGER
                           ) return PLS_INTEGER;
```

#### SP-010 - D2KWUTIL.FILE_INFO

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CREATED_DATE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.MODIFIED_DATE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Calls the native Windows D2KWUTIL DLL to retrieve metadata for a specified client-side file (size, dates, etc.) and stores the results in shared integer buffers (iBuff1-iBuff9). It initialises all buffers to zero, registers the FFI function call, invokes the DLL, and interprets the return code, adding structured error information if the file is not found or an error occurs.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| CalledBy | VARCHAR2 | IN |
| FileName | VARCHAR2 | IN |
| Option1 | PLS_INTEGER | IN |
| Option2 | PLS_INTEGER | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-043](#SP-043--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-044](#SP-044--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-045](#SP-045--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-046](#SP-046--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_FILEINFO ([SP-009](#SP-009--D2KWUTIL.D2KWUTIL_FILEINFO)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-047](#SP-047--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-049](#SP-049--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log diagnostic information (debug level 99) including the caller name, filename, option values, and exception flag.
- Step 2 - Clear the error stack via `WIN_API.Clean_Error_Stack` and initialise all nine integer buffers (iBuff1-iBuff9) to zero.
- Step 3 - Check whether the Windows API is available (`WIN_API.API_ENABLED`); if not, raise `WIN_API.NOT_AVAILABLE`.
- Step 4 - Register the FFI function call for `d2kwutil_FileInfo` with the appropriate type signature.
- Step 5 - Pad the filename to 512 characters, set the option buffers, and invoke `d2kwutil_FileInfo` via the registered function handle.
- Step 6 - Log the result buffers at debug level 99.
- Step 7 - Check the return code: if zero or one of the "file not found" codes, add a "file does not exist" error; if not 1, add a system error with the return code; if exactly 1, the call succeeded.
- Step 8 - Re-raise `NO_DATA_FOUND` if `RaiseExceptions` is TRUE and an error was encountered.

---
**Decision Points**

DP-001

Condition:
Windows API is available (`WIN_API.API_ENABLED` is true).

TRUE:
Register and invoke the native FFI function call to retrieve file metadata.

FALSE:
Raise `WIN_API.NOT_AVAILABLE`.

DP-002

Condition:
Return code is zero or one of the "file not found" sentinel values.

TRUE:
Add a "file does not exist" error and optionally raise `NO_DATA_FOUND`.

FALSE:
Check if return code is not 1 (system error).

DP-003

Condition:
Return code is not 1 (and not a "file not found" code).

TRUE:
Add a system error message with the return code and optionally raise `NO_DATA_FOUND`.

FALSE:
File metadata retrieval was successful - buffers contain valid data.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

BR-001 - All nine integer buffers must be zeroed before the DLL call to prevent stale data from a previous call.
BR-002 - The Windows API availability must be checked before attempting the FFI call; if unavailable, `WIN_API.NOT_AVAILABLE` is raised immediately.
BR-003 - Exception handling distinguishes `NO_DATA_FOUND` (re-raised), `NOT_AVAILABLE` (error added and re-raised), and all other errors (message built and re-raised).

---
**Implementation Logic**

```plsql

Procedure File_info ( CalledBy         IN  VARCHAR2,  
                      FileName         IN  VARCHAR2,
                      Option1          IN  PLS_INTEGER,
                      Option2          IN  PLS_INTEGER,
                      RaiseExceptions  IN BOOLEAN) is
 vcBuff1  varchar2(512);
 iRC      pls_integer;
begin
  Win_API_Debug.DebugLog(99,'File_Info','Args:  CalledBy="'||CalledBy||'", FileName="'||FileName||'", Option1='||to_char(Option1)||', Option2='||to_char(Option2)||', RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	  	
  WIN_API.Clean_Error_Stack;
  iRC    := 0;
  iBuff1 := 0;
  iBuff2 := 0;
  iBuff3 := 0;
  iBuff4 := 0;
  iBuff5 := 0;
  iBuff6 := 0;
  iBuff7 := 0;
  iBuff8 := 0;
  iBuff9 := 0;
  
  if WIN_API.API_ENABLED then 
    win_api.Register_function_call(iFileInfo,'d2kwutil_FileInfo','LONG','*CHAR,INT,INT,*LONG,*LONG,*LONG,*LONG,*LONG,*LONG,*LONG');
    vcBuff1 := RPAD(Filename,512,CHR(0));
    iBuff1  := Option1;
    iBuff2  := Option2;
    iRC     := d2kwutil_FileInfo(win_api.FunctionHandle(iFileInfo),vcBuff1,iBuff1,iBuff2,iBuff3,iBuff4,iBuff5,iBuff6,iBuff7,iBuff8,iBuff9);
    Win_API_Debug.DebugLog(99,'File_Info','Result:  RC='||to_char(iRC)||', iBuff1='||to_char(iBuff1)||', iBuff2='||to_char(iBuff2)||', iBuff3='||to_char(iBuff3)||', iBuff4='||to_char(iBuff4)||', iBuff5='||to_char(iBuff5)||', iBuff6='||to_char(iBuff6)||', iBuff7='||to_char(iBuff7)||', iBuff8='||to_char(iBuff8)||', iBuff9='||to_char(iBuff9));
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;
  if iRC in (0, -1074255551, -1074245406) then
    WIN_API.Add_error(CalledBy,'File '||FileName||' does not exist');
    if RaiseExceptions then 
      raise NO_DATA_FOUND;
    end if;
  elsif iRC <> 1 then 
    WIN_API.Add_error(CalledBy,'Gathering Information about '||FileName||' generated system error '||to_char(iRC));
    if RaiseExceptions then 
      raise NO_DATA_FOUND;
    end if;
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error(CalledBy,Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error(CalledBy, Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end;
```

#### SP-011 - D2KWUTIL.MODIFIED_DATE

**Invoked From:**

- PKG_LOYALTY.pck [StoredProcedure: PKG_LOYALTY.SP_CALCULATE_BAL_POINTS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the last-modified timestamp (date and milliseconds) of a specified client-side file, using the same underlying file information mechanism as `CREATED_DATE` but with option code 3 to request the modified date fields.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| FileName | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| ReturnDate | DATE | OUT |
| ReturnMS | NUMBER | OUT |

---

**Dependencies**

- D2KWUTIL.FILE_INFO ([SP-010](#SP-010--D2KWUTIL.FILE_INFO)) - D2KWUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Call `File_Info` with function context "Modified_Date", the supplied filename, and option values 1/3 (indicating last-modified date fields), passing through the `RaiseExceptions` flag.
- Step 2 - Convert the integer buffers (iBuff3-iBuff8) returned by `File_Info` into a DATE value in YYYYMMDDHH24MISS format and assign it to the `ReturnDate` OUT parameter.
- Step 3 - Assign the milliseconds buffer (iBuff9) to the `ReturnMS` OUT parameter.

---
**Decision Points**

No branching decision points identified in the implementation logic.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

BR-001 - The modified date is obtained using option code 3 (as opposed to 1 for created date), which selects the appropriate date fields from the file metadata.
BR-002 - If `RaiseExceptions` is TRUE and the file does not exist or an error occurs, an exception propagates to the caller.

---
**Implementation Logic**

```plsql

PROCEDURE Modified_Date ( FileName        IN   VARCHAR2,
                          ReturnDate      OUT  DATE,
                          ReturnMS        OUT  NUMBER,
                          RaiseExceptions IN   BOOLEAN DEFAULT FALSE) is
begin 
  File_Info('Modified_Date',Filename,1,3,RaiseExceptions);
  ReturnDate := to_date(to_char(iBuff3,'0999')||to_char(iBuff4,'09')||to_char(iBuff5,'09')||to_char(iBuff6,'09')||to_char(iBuff7,'09')||to_char(iBuff8,'09'),'YYYYMMDDHH24MISS');
  ReturnMS   := iBuff9;
end Modified_Date;
```

#### SP-012 - D2KWUTIL.TRANSLATETYPE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

TranslateType is a lookup function that converts a caller-supplied string data-type name into the corresponding ORA_FFI integer constant. It is used by REGISTER_FUNCTION_CALL to resolve human-readable C data-type tokens (e.g., 'INT', '*CHAR') into the numeric type codes required by the ORA_FFI foreign-function interface before a native library call is registered.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DataType | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameter DataType (VARCHAR2) and normalise it to uppercase, storing the result in the local variable vcType.
- Step 2 - Evaluate vcType against the full set of recognised C data-type tokens in a sequential IF/ELSIF chain.
- Step 3 - For each matching token, assign the corresponding ORA_FFI constant to the local return variable iRC (e.g., vcType = '*CHAR' -> ORA_FFI.C_CHAR_PTR; vcType = 'CHAR' -> ORA_FFI.C_CHAR; and so on for INT, LONG, SHORT/BYTE, DOUBLE, and VOID variants).
- Step 4 - Return the resolved ORA_FFI integer constant (iRC) to the caller.

---
**Decision Points**

DP-001
Condition: vcType = '*CHAR'
TRUE: iRC is set to ORA_FFI.C_CHAR_PTR.
FALSE: Evaluation continues to the next condition.

DP-002
Condition: vcType = 'CHAR'
TRUE: iRC is set to ORA_FFI.C_CHAR.
FALSE: Evaluation continues to the next condition.

DP-003
Condition: vcType = '*INT'
TRUE: iRC is set to ORA_FFI.C_INT_PTR.
FALSE: Evaluation continues to the next condition.

DP-004
Condition: vcType = 'INT'
TRUE: iRC is set to ORA_FFI.C_INT.
FALSE: Evaluation continues to the next condition.

DP-005
Condition: vcType = '*LONG'
TRUE: iRC is set to ORA_FFI.C_LONG_PTR.
FALSE: Evaluation continues to the next condition.

DP-006
Condition: vcType = 'LONG'
TRUE: iRC is set to ORA_FFI.C_LONG.
FALSE: Evaluation continues to the next condition.

DP-007
Condition: vcType = '*SHORT' OR vcType = '*BYTE'
TRUE: iRC is set to ORA_FFI.C_SHORT_PTR.
FALSE: Evaluation continues to the next condition.

DP-008
Condition: vcType = 'SHORT' OR vcType = 'BYTE'
TRUE: iRC is set to ORA_FFI.C_SHORT.
FALSE: Evaluation continues to the next condition.

DP-009
Condition: vcType = '*DOUBLE'
TRUE: iRC is set to ORA_FFI.C_DOUBLE_PTR.
FALSE: Evaluation continues to the next condition.

DP-010
Condition: vcType = 'DOUBLE'
TRUE: iRC is set to ORA_FFI.C_DOUBLE.
FALSE: Evaluation continues to the next condition.

DP-011
Condition: vcType = '*VOID'
TRUE: iRC is set to ORA_FFI.C_VOID_PTR.
FALSE: No branch matches; iRC remains unassigned (NULL) and is returned as-is.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The input DataType string must be one of the recognised C data-type tokens (*CHAR, CHAR, *INT, INT, *LONG, LONG, *SHORT, SHORT, *BYTE, BYTE, *DOUBLE, DOUBLE, *VOID); any unrecognised value results in a NULL return, which the caller is responsible for handling.
- BR-002 - Type-name matching is case-insensitive; the function uppercases the input before comparison, so callers may supply mixed-case tokens without causing a mismatch.
- BR-003 - The tokens '*SHORT' and '*BYTE' are treated as equivalent and both map to ORA_FFI.C_SHORT_PTR; similarly, 'SHORT' and 'BYTE' both map to ORA_FFI.C_SHORT.
- BR-004 - The function performs a pure lookup with no side effects; it does not interact with any database table and does not modify any package-level state.

---
**Implementation Logic**

```plsql
 
FUNCTION TranslateType(DataType in VARCHAR2) return PLS_INTEGER is
   -- Just a simple lookup of the types.
   vcType VARCHAR2(10) := UPPER(DataType);
   iRC    PLS_INTEGER;
begin 
  if vcType = '*CHAR' then 
    iRC := ORA_FFI.C_CHAR_PTR;
  elsif vcType = 'CHAR' then 
    iRC := ORA_FFI.C_CHAR;
  elsif vcType = '*INT' then 
    iRC := ORA_FFI.C_INT_PTR;
  elsif vcType = 'INT' then 
    iRC := ORA_FFI.C_INT;
  elsif vcType = '*LONG' then 
    iRC := ORA_FFI.C_LONG_PTR;
  elsif vcType = 'LONG' then 
    iRC := ORA_FFI.C_LONG;
  elsif vcType = '*SHORT' or vcType = '*BYTE'  then 
    iRC := ORA_FFI.C_SHORT_PTR;
  elsif vcType = 'SHORT' or vcType = 'BYTE' then 
    iRC := ORA_FFI.C_SHORT;
  elsif vcType = '*DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE_PTR;
  elsif vcType = 'DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE;  
  elsif vcType = '*VOID' then 
    iRC := ORA_FFI.C_VOID_PTR;      
  end if;
return iRC;
end TranslateType;
```

#### SP-013 - GENERAL.ASK_CONFIRM

**Invoked From:**

- vt_amc_cncl_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

Cancellation Details (N/A / CN_MAIN)

---

**Purpose**

Displays a configurable confirmation dialog to the user using the `AL_CONFIRM` alert and returns 1 if the user confirmed (clicked Button 1) or 0 if the user declined or dismissed the dialog. Used throughout the form to obtain advisor approval before irreversible operations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| confirm_msg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Set the message text of the `AL_CONFIRM` alert to the supplied `confirm_msg` string.
- Step 2 - Display the alert and capture which button the user pressed.
- Step 3 - If the user pressed Button 1 (confirm), return 1.
- Step 4 - Otherwise (any other button or dismiss), return 0.

---
**Decision Points**

DP-001

Condition:
User pressed Alert Button 1 (confirmation/yes).

TRUE:
Return 1 - user confirmed the action.

FALSE:
Return 0 - user declined or dismissed.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

BR-001 - The confirmation message displayed is the caller-supplied string; the function does not impose any fixed text.
BR-002 - Only Button 1 is treated as confirmation; any other button press or alert dismissal results in a return of 0 (not confirmed).

---
**Implementation Logic**

```plsql
FUNCTION ASK_CONFIRM( confirm_msg VARCHAR2)
                                      RETURN  NUMBER IS

    p_alert_name varchar2(10) := 'AL_CONFIRM' ;
    p_albtn_pressed number;
BEGIN
   set_alert_property(p_alert_name,alert_message_text,confirm_msg); 
   p_albtn_pressed := show_alert(p_alert_name);

   IF ( p_albtn_pressed = ALERT_BUTTON1 ) THEN
      return (1);
   ELSE
      return(0);
   END IF;
RETURN NULL; END;
```

#### SP-014 - GENERAL.CHECK_NULL

**Invoked From:**

- vt_amc_cncl_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]
- vt_amc_cncl_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

Cancellation Details (N/A / CN_MAIN)

---

**Purpose**

Validates that a supplied field value is not null. If the value is null, it displays an error message of the form "Enter a valid <column_title>" and raises a form trigger failure to halt processing.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_value | VARCHAR2 | IN |
| column_title | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-015](#SP-015--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Check whether the supplied `P_value` is NULL.
- Step 2 - If null, construct the error message "Enter a valid <column_title>" and call `GENERAL.DISP_TEXT` with title "Error".
- Step 3 - Raise `FORM_TRIGGER_FAILURE` to stop the current trigger execution.
- Step 4 - If not null, return without action.

---
**Decision Points**

DP-001

Condition:
The supplied `P_value` IS NULL.

TRUE:
Display an error message "Enter a valid <column_title>" and raise `FORM_TRIGGER_FAILURE`.

FALSE:
Proceed without error - value is present.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

BR-001 - A NULL value for any mandatory field must always be rejected with a user-friendly message that identifies the field by its column title.
BR-002 - Raising `FORM_TRIGGER_FAILURE` ensures the current form trigger is aborted, preventing any subsequent processing on null inputs.

---
**Implementation Logic**

```plsql
PROCEDURE CHECK_NULL( P_value IN VARCHAR2, column_title  IN VARCHAR2) IS
mesg_text        varchar2(80) := 'Enter a valid '||column_title ;
BEGIN
   IF p_value IS null  THEN
      GENERAL.DISP_TEXT(mesg_text,'Error');
      raise form_trigger_failure;
   END IF;
END;
```

#### SP-015 - GENERAL.DISP_TEXT

**Invoked From:**

- vt_amc_cncl_fmb.xml [ProgramUnit: PROC_AMC_DETAILS]
- vt_amc_cncl_fmb.xml [ProgramUnit: SP_INSERT_CHARGES]
- DPL.pld [StoredProcedure: GENERAL.CHECK_NULL]
- DPL.pld [StoredProcedure: GENERAL.PROC_TIMER_EXPIRED]
- DPL.pld [StoredProcedure: GENERAL.RAISE_ERROR]
- vt_amc_cncl_fmb.xml [StoredProcedure: PROC_AMC_DETAILS]
- vt_amc_cncl_fmb.xml [StoredProcedure: SP_INSERT_CHARGES]
- vt_amc_cncl_fmb.xml [Trigger: ON-ERROR]
- vt_amc_cncl_fmb.xml [Trigger: ON-MESSAGE]
- vt_amc_cncl_fmb.xml [Trigger: WHEN-LIST-CHANGED]
- vt_amc_cncl_fmb.xml [Trigger: WHEN-NEW-BLOCK-INSTANCE]
- vt_amc_cncl_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]
- vt_amc_cncl_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

Cancellation Details (N/A / CN_MAIN); Package Details (N/A / CN_MAIN); Search Details (N/A / CN_MAIN)

---

**Purpose**

Displays a message to the user in a modal alert dialog. If the title is "ERROR", it uses the `AL_ERRINFO` alert; for any other title it uses the `AL_NOTE` alert. This is the single standardised message display mechanism used throughout the form for all error and informational messages.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| text_string | VARCHAR2 | IN |
| title_string | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Determine the appropriate alert name: if `title_string` (uppercased) equals "ERROR", use `AL_ERRINFO`; otherwise use `AL_NOTE`.
- Step 2 - Set the alert title property to the supplied `title_string`.
- Step 3 - Set the alert message text property to the supplied `text_string`.
- Step 4 - Show the alert to the user and capture the button pressed (result not used).

---
**Decision Points**

DP-001

Condition:
`title_string` (upper-cased) equals "ERROR".

TRUE:
Use the `AL_ERRINFO` alert for display.

FALSE:
Use the `AL_NOTE` alert for display.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

BR-001 - Error messages (title = "ERROR") must use the designated `AL_ERRINFO` alert; informational messages use `AL_NOTE`.
BR-002 - The caller is responsible for providing meaningful message text and an appropriate title; this procedure only handles display.

---
**Implementation Logic**

```plsql
PROCEDURE DISP_TEXT (text_string VARCHAR2,
                     title_string VARCHAR2 ) IS 
   p_alert_name varchar2(10) := 'AL_ERRINFO' ; 
   p_alert_id number;
BEGIN
   if upper(title_string)='ERROR' then
      p_alert_name := 'AL_ERRINFO' ; 
   else
      p_alert_name := 'AL_NOTE' ; 
   end if;
   set_alert_property(p_alert_name,TITLE,title_string);  
   set_alert_property(p_alert_name,alert_message_text,text_string);  
   p_alert_id := show_alert(p_alert_name); 
END;
```

#### SP-016 - GENERAL.PROC_REPORT_CALL

**Invoked From:**

- vt_amc_cncl_fmb.xml [ProgramUnit: CALL_REPORT_ENQ]
- vt_amc_cncl_fmb.xml [StoredProcedure: CALL_REPORT_ENQ]

---

**Screen:**

N/A

---

**Purpose**

Submits a report to the Oracle Reports server in batch print mode by running the pre-configured report object and capturing the job handle and output filename. It sets the report execution mode to BATCH, the destination type to FILE, constructs a unique output filename based on the current user and timestamp, assigns the report server, and runs the report.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| REPID | report_object | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| lv_report | varchar2 | OUT |
| lv_print | varchar2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Read the report server name from the session global `GLOBAL.REP_SERVER`.
- Step 2 - Construct a unique output filename using the current application username and the current date/time in YYYYMMDDHHMISS format, appended with ".rrpp".
- Step 3 - Set the report execution mode to BATCH and destination type to FILE on the report object.
- Step 4 - Set the report destination file path to `/iashome/ias/reports/printer/<filename>`.
- Step 5 - Set the report server property on the report object.
- Step 6 - Run the report object via `RUN_REPORT_OBJECT` and capture the job handle into `lv_report`.
- Step 7 - Return the output filename in `lv_print`.

---
**Decision Points**

No branching decision points identified in the implementation logic.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

BR-001 - Print reports must be submitted in BATCH execution mode with DESTYPE=FILE; interactive (non-batch) execution is not used for print submissions.
BR-002 - The output filename is generated dynamically (username + timestamp + ".rrpp") to ensure uniqueness per print job.
BR-003 - Both the report job handle (`lv_report`) and the print output filename (`lv_print`) must be returned to allow the caller to track and retrieve the print output.

---
**Implementation Logic**

```plsql

PROCEDURE PROC_REPORT_CALL (REPID report_object, lv_report OUT varchar2, lv_print OUT varchar2) IS
      vcFile    VARCHAR2(225) := 'test';
      vcResult  VARCHAR2(30);
      lv_server VARCHAR2(1000);
    Begin
    	  lv_server := name_in(':global.rep_server');
        vcFile:= Get_Application_Property(UserName)||To_Char(Sysdate,'YYYYMMDDHHMISS');
        vcFile := vcFile||'.rrpp';
         Set_Report_Object_Property(repid,REPORT_EXECUTION_MODE,BATCH);
        Set_Report_Object_Property(repid,REPORT_DESTYPE,FILE);
      	set_report_object_property(repid,REPORT_DESNAME,'/iashome/ias/reports/printer/'||vcFile);
				Set_Report_Object_Property(repid,REPORT_SERVER,lv_server); --'mulreports
			  lv_report:= RUN_REPORT_OBJECT(repid);
			  lv_print := vcFile;			  
End;
```

#### SP-017 - GENERAL.PROC_TIMER

**Invoked From:**

- vt_amc_cncl_fmb.xml [ProgramUnit: CALL_REPORT_ENQ]
- vt_amc_cncl_fmb.xml [StoredProcedure: CALL_REPORT_ENQ]

---

**Screen:**

N/A

---

**Purpose**

Creates a repeating Oracle Forms timer named `PRINTER_QUEUE` with a 5-second interval to poll the status of a submitted print report job. This timer is started after a print report submission and fires the `WHEN-TIMER-EXPIRED` trigger at regular intervals to check whether the print job has completed.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Create a repeating timer named "PRINTER_QUEUE" with an interval of 5000 milliseconds (5 seconds).

---
**Decision Points**

No branching decision points identified in the implementation logic.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

BR-001 - The print polling timer must be named "PRINTER_QUEUE" so that the `PROC_TIMER_EXPIRED` handler can identify it when the timer fires.
BR-002 - The timer interval is fixed at 5 seconds (5000 ms) and runs in REPEAT mode until explicitly deleted by the timer expiry handler.

---
**Implementation Logic**

```plsql
PROCEDURE PROC_TIMER IS
  hTimer    TIMER;
 begin
  hTimer := CREATE_TIMER('PRINTER_QUEUE','5000',REPEAT);
 end;
```

#### SP-018 - GENERAL.PROC_TIMER_EXPIRED

**Invoked From:**

- vt_amc_cncl_fmb.xml [Trigger: WHEN-TIMER-EXPIRED]

---

**Screen:**

N/A

---

**Purpose**

Handles the expiry of the `PRINTER_QUEUE` timer by checking the status of the submitted print report job. If the job is still running or queued it takes no action; if the job has finished it opens the print output in the browser and deletes the timer; if the job has failed or reached any other terminal state it displays an error message and deletes the timer.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-015](#SP-015--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Retrieve the name of the expired timer from the application properties.
- Step 2 - Read the current report job handle from `GLOBAL.REPORTHANDLE` and the print output filename from `GLOBAL.PRINTOUTPUT`.
- Step 3 - If the timer name is "PRINTER_QUEUE": check the report object status using the job handle.
- Step 4 - If status is RUNNING, OPENING_REPORT, or ENQUEUED: do nothing (wait for the next timer fire).
- Step 5 - If status is FINISHED: open the print output file in a new browser window via `WEB.SHOW_DOCUMENT` and delete the timer.
- Step 6 - For any other status (job failed or error): display "Unable to generate the report" to the advisor via `GENERAL.DISP_TEXT` and delete the timer.

---
**Decision Points**

DP-001

Condition:
Timer name equals "PRINTER_QUEUE".

TRUE:
Check the report job status and act accordingly.

FALSE:
Ignore the timer event - it is not a print queue timer.

DP-002

Condition:
Report object status is RUNNING, OPENING_REPORT, or ENQUEUED.

TRUE:
Take no action - the job is still in progress; wait for the next timer interval.

FALSE:
Evaluate whether the job has FINISHED or errored.

DP-003

Condition:
Report object status is FINISHED.

TRUE:
Open the print output in the browser via `WEB.SHOW_DOCUMENT` and delete the PRINTER_QUEUE timer.

FALSE:
Job has failed or reached an unexpected terminal state - display error and delete timer.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

BR-001 - The timer must be deleted once the print job reaches a terminal state (FINISHED or error) to prevent it from continuing to fire.
BR-002 - Only the "PRINTER_QUEUE" timer is handled by this procedure; other timers are ignored.
BR-003 - A failed print job must always be communicated to the advisor with an explicit error message.

---
**Implementation Logic**

```plsql
PROCEDURE PROC_TIMER_EXPIRED IS
	vcStatus varchar2(50);
	vcTimerName varchar2(30);
	hTimer timer;
	report_id report_object;
  lv_report_handle varchar2(4000);
  lv_printout      varchar2(4000);
begin
	vcTimerName := get_application_property(timer_name);
   			lv_report_handle := name_in(':global.reporthandle');
        lv_printout      := name_in(':GLOBAL.PRINTOUTPUT');
 
	if vcTimerName = 'PRINTER_QUEUE' then
		 vcStatus := REPORT_OBJECT_STATUS(lv_report_handle);
	   if vcStatus in ('RUNNING','OPENING_REPORT','ENQUEUED') THEN
	   	  NULL;
	   ELSIF VCsTATUS = 'FINISHED' THEN
        web.show_document('/printer/'||lv_printout ,'_blank');
--        web.show_document('/reports/rwservlet/getjobid'||substr(:global.reporthandle,instr(:global.reporthandle,'_',-1)+1)||'?'||'server=mulreports'||:GLOBAL.PRINTOUTPUT,'_blank');
--        web.show_document('/reports/rwservlet/getjobid'||substr(lv_rep,instr(lv_rep,'_',-1)+1)||'?'||'server='||lv_server,'_blank');
        delete_timer(vcTimerName);
	   ELSE
--	   	  general.disp_text('Unable to generate the report'||vcStatus,'Error');
        general.disp_text('Unable to generate the report','Error');
	   	  delete_timer(vcTimerName);
	   end if;
	end if;   
end;
```

#### SP-019 - GENERAL.RAISE_ERROR

**Invoked From:**

- vt_amc_cncl_fmb.xml [Trigger: ON-ERROR]

---

**Screen:**

N/A

---

**Purpose**

Looks up a message by code, formats it, and displays it to the user with an appropriate severity title (Error, Note, or Caution). For Error severity, it also raises a form trigger failure to halt processing. Used as the centralised error display mechanism for the ON-ERROR trigger.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| mesg_code | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-015](#SP-015--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Accept a message code and look up the corresponding message text and type (E/N/C) - note the actual lookup call is commented out in the source; only the code/text concatenation and display logic is active.
- Step 2 - Concatenate the message code with the message text.
- Step 3 - If the message type is "E" (Error): set title to "Error", display via `GENERAL.DISP_TEXT`, and raise `FORM_TRIGGER_FAILURE`.
- Step 4 - If the message type is "N" (Note): set title to "Note" and display via `GENERAL.DISP_TEXT`.
- Step 5 - If the message type is "C" (Caution): set title to "Caution" and display via `GENERAL.DISP_TEXT`.

---
**Decision Points**

DP-001

Condition:
Message type equals "E" (Error).

TRUE:
Display the message with "Error" title and raise `FORM_TRIGGER_FAILURE`.

FALSE:
Evaluate whether the type is "N" (Note).

DP-002

Condition:
Message type equals "N" (Note).

TRUE:
Display the message with "Note" title; do not raise an exception.

FALSE:
Evaluate whether the type is "C" (Caution).

DP-003

Condition:
Message type equals "C" (Caution).

TRUE:
Display the message with "Caution" title; do not raise an exception.

FALSE:
No matching type - message is not displayed.

---
**Database Interactions**

- DB-001 - Read AM_PERMISSIONS - Reads data from AM_PERMISSIONS for lookup or validation.
**Business Rules**

BR-001 - Error-type messages (type "E") must always halt form processing by raising `FORM_TRIGGER_FAILURE` after display.
BR-002 - Note and Caution messages are informational only and do not halt processing.

---
**Implementation Logic**

```plsql
PROCEDURE RAISE_ERROR ( mesg_code IN VARCHAR2 )IS
  mesg_type  varchar2(7); 
  mesg_text  varchar2(200) ;
  mesg_title varchar2(7);
  BEGIN
     -- murali 17.05.04 GENERAL.get_message(mesg_code,mesg_text,mesg_type );
     mesg_text:=mesg_code||' : '||mesg_text;		
     IF ( mesg_type = 'E' ) THEN
        mesg_title := 'Error' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
        raise FORM_TRIGGER_FAILURE;
     ELSIF ( mesg_type = 'N' ) THEN
        mesg_title := 'Note' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     ELSIF ( mesg_type = 'C' ) THEN
        mesg_title := 'Caution' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     END IF;
  END;     

/* PROCEDURE check_rights( 
pi_form_name in varchar2,
pi_user_id in number) IS
lv_x varchar2(1);
BEGIN
	
	begin
	SELECT substr(access_string, pi_user_id,1) 
	INTO   lv_x
	FROM   	am_permissions
	WHERE  form_name = pi_form_name
	AND SUBSTR(access_string,pi_user_id,1)='Y';
	exception 
		when no_data_found then
		  general.disp_text('You do not have the Permission to access this.','Error rr');
		  raise form_trigger_failure; 
		when too_many_rows then
		  general.disp_text('Many rows in USER_PERMISSIONS','Error ss');
		  raise form_trigger_failure;
		when others then
		       general.disp_text(sqlerrm,'Error mm');
		       raise form_trigger_failure;
	end;

	open_form(pi_form_name,activate,session);
END;
*/
```

#### SP-020 - PKG_AMC.SF_GET_SELL_PRICE

**Invoked From:**

- PKG_AMC.pck [StoredProcedure: PKG_AMC.SP_POP_CANCEL_DTL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Calculates the before-tax selling price (ex-tax price) for an AMC package item by looking up the applicable GST/service tax rate from the charge configuration and back-calculating from the MRP. It determines the tax type (Own-state or Cross-state) based on the `p_lst_yn` flag, sums the applicable tax charges, and returns the sell price truncated to one decimal place.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_parent | VARCHAR2 | IN |
| p_dealer | NUMBER | IN |
| p_loc | VARCHAR2 | IN |
| p_tax_cd | VARCHAR2 | IN |
| p_mrp | NUMBER | IN |
| p_lst_yn | VARCHAR2 | IN |
| p_gst_state | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Determine the tax type: if `p_lst_yn = "Y"`, use "O" (own-state/local); otherwise use "C" (cross-state).
- Step 2 - Query `AM_CHARGE` joined with `PM_TAX` to retrieve all applicable service-type ("S") charge factors for the given dealer, location, tax code, and GST state, filtered by the determined tax type.
- Step 3 - Sum all charge values (tax percentages) from the query results.
- Step 4 - Calculate the before-tax sell price: `TRUNC((MRP * 100) / (100 + total_tax_factor), 1)` - back-calculating to remove the tax component from the MRP.
- Step 5 - Return the computed sell price.

---
**Decision Points**

DP-001

Condition:
`p_lst_yn = "Y"` (local/own-state sale).

TRUE:
Use tax type "O" (own-state) for the charge lookup.

FALSE:
Use tax type "C" (cross-state) for the charge lookup.

---
**Database Interactions**

- DB-001 - Read AM_CHARGE - Reads data from AM_CHARGE for lookup or validation.
**Business Rules**

BR-001 - The sell price is derived by back-calculating from MRP using the formula: sell_price = TRUNC((MRP × 100) / (100 + tax_rate), 1).
BR-002 - The tax type (own-state vs cross-state) is determined by the `p_lst_yn` flag, allowing correct tax rates to be applied based on the customer's location.
BR-003 - The result is truncated (not rounded) to 1 decimal place.

---
**Implementation Logic**

```plsql
  FUNCTION SF_GET_SELL_PRICE(p_parent    IN VARCHAR2,
                             p_dealer    IN NUMBER,
                             p_loc       IN VARCHAR2,
                             p_tax_cd    IN VARCHAR2,
                             p_mrp       IN NUMBER,
                             p_lst_yn    IN VARCHAR2,
                             p_gst_state IN VARCHAR2) RETURN NUMBER IS
    ln_os_sell_price pm_part_var.os_sell_price%TYPE;
    lv_os_factor     pm_tax_hdr.os_factor%TYPE;
    lv_taxtype       pm_tax.common_ind%TYPE;
  BEGIN
    IF p_lst_yn = 'Y' THEN
      lv_taxtype := 'O';
    ELSE
      lv_taxtype := 'C';
    END IF;

    BEGIN
      BEGIN
        FOR K IN (SELECT a.charge_type,
                         a.charge_ind,
                         a.charge_value,
                         a.charge_cd,
                         b.common_ind,
                         b.order_srl
                    FROM am_charge a, pm_tax b
                   WHERE b.dealer_map_cd = p_dealer
                     AND a.dealer_map_cd = b.dealer_map_cd
                     AND a.loc_cd = b.loc_cd
                     AND b.loc_cd = p_loc
                     AND a.charge_type = b.charge_type
                     AND a.charge_cd = b.charge_cd
                     AND b.tax_type = 'S'
                     AND (b.common_ind = lv_taxtype)
                     AND b.part_tax_cd = p_tax_cd
                     AND b.parent_group = p_parent
                     AND b.gst_state_cd = p_gst_state
                   ORDER BY charge_srl) LOOP
          lv_os_factor := NVL(lv_os_factor, 0) + k.charge_value;
        END LOOP;
      END;
      ln_os_sell_price := TRUNC((NVL(p_mrp, 0) * 100) /
                                (100 + NVL(lv_os_factor, 0)),
                                1);
    END;

    RETURN ln_os_sell_price;
  END;
```

#### SP-021 - PKG_AMC.SP_AMC_AVAIL_QTY

**Invoked From:**

- PKG_AMC.pck [StoredProcedure: PKG_AMC.SP_POP_CANCEL_DTL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines the available (unused) quantities and amounts for each service type (Labour, Parts, Consumables) in an AMC contract by comparing the enrolled service quantities against the quantities already utilised in completed job cards. Returns the remaining available values and a count of service items, or an error code/message if the operation fails.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_PMC | NUMBER | IN |
| P_AMC_NUM | VARCHAR2 | IN |
| P_VIN | VARCHAR2 | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_ERRMSG | VARCHAR2 | OUT |
| P_ERRCODE | NUMBER | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Initialise all accumulators (part value, consumables value, labour value, and service count) to zero.
- Step 2 - Query the AMC enrollment detail and related job card usage data to compute remaining available amounts by service type.
- Step 3 - Accumulate labour, parts, and consumables remaining values and increment the service count.
- Step 4 - Return the computed balances and service count, or set an error code/message on exception.

---
**Decision Points**

No branching decision points identified in the implementation logic.

---
**Database Interactions**

- DB-001 - Update VH_AMC_ENROL - Updates existing rows in VH_AMC_ENROL (columns: tot srv offered, labour used amt, part used amt, consumable used amt).
- DB-002 - Update VD_AMC_ENROL - Updates existing rows in VD_AMC_ENROL (columns: srv used qty).
- DB-003 - Read VH_RO - Reads data from VH_RO for lookup or validation.
- DB-004 - Read PD_ISSUE - Reads data from PD_ISSUE for lookup or validation.
- DB-005 - Read PM_PART_GROUP - Reads data from PM_PART_GROUP for lookup or validation.
- DB-006 - Read VD_RO_OPR - Reads data from VD_RO_OPR for lookup or validation.
**Business Rules**

BR-001 - Available quantity is the enrolled amount minus the used (job card billed) amount; negative balances indicate over-utilisation.
BR-002 - On any exception, an error code and message are returned to the caller rather than propagating the exception.

---
**Implementation Logic**

```plsql
  PROCEDURE SP_AMC_AVAIL_QTY(P_PMC     IN NUMBER,
                             P_AMC_NUM IN VARCHAR2,
                             P_VIN     IN VARCHAR2,
                             P_ERRMSG  OUT VARCHAR2,
                             P_ERRCODE OUT NUMBER) IS
    ln_part_val NUMBER(15, 3) := 0;
    ln_cons_val NUMBER(15, 3) := 0;
    ln_lbr_val  NUMBER(15, 3) := 0;
    ln_srv_cnt  NUMBER := 0;
    ln_part     NUMBER := 0;
    ln_lbr      NUMBER := 0;
  BEGIN
    ln_part_val := 0;
    ln_cons_val := 0;
    ln_lbr_val  := 0;
    ln_srv_cnt  := 0;
    ln_part     := 0;
    ln_lbr      := NULL;
    P_ERRMSG    := 0;
    P_ERRCODE   := 0;

    UPDATE vh_amc_enrol
       SET tot_srv_offered     = NULL,
           labour_used_amt     = NULL,
           part_used_amt       = NULL,
           consumable_used_amt = NULL
     WHERE principal_map_cd = P_PMC
       AND amc_num = P_AMC_NUM;

    UPDATE vd_amc_enrol
       SET srv_used_qty = NULL
     WHERE principal_map_cd = P_PMC
       AND amc_num = P_AMC_NUM
       AND srv_code NOT IN ('ZE21L0P', 'ZE22L0P', 'ZE23L0D', 'ZE24L0D');

    UPDATE vd_amc_enrol
       SET srv_used_qty = stlm_qty
     WHERE principal_map_cd = P_PMC
       AND amc_num = P_AMC_NUM
       AND srv_code IN ('ZE21L0P', 'ZE22L0P', 'ZE23L0D', 'ZE24L0D');

    FOR cur_r IN (SELECT r.parent_group,
                         r.dealer_map_cd,
                         r.loc_cd,
                         r.comp_fa,
                         r.ro_num,
                         r.mcp_type -- Added on 27-MAR-2026 for SMP
                    FROM vh_ro r
                   WHERE r.vin = P_VIN
                     AND r.amc_yn = 'Y'
                     AND r.ro_status in ('30', '40')
                     AND r.amc_num = P_AMC_NUM) LOOP
      ln_part := 0;
      ln_lbr  := 0;
      FOR cur_p IN (SELECT d.doc_num,
                           d.srl_num,
                           d.part_num,
                           d.bill_qty,
                           d.ret_qty,
                           d.sell_price,
                           d.item_value,
                           pm.root_part_num,
                           pm.catg_cd,
                           d.amc_rate,
                           nvl(d.amc_rate, 0) *
                           (nvl(d.bill_qty, 0) - nvl(d.ret_qty, 0)) amc_adj
                      FROM pd_issue d, pm_part pm
                     WHERE d.ro_num = cur_r.ro_num
                       AND d.dealer_map_cd = cur_r.dealer_map_cd
                       AND d.loc_cd = cur_r.loc_cd
                       AND d.doc_type = 'SRI'
                       AND d.req_iss_type = 'AMC'
                       AND pm.principal_map_cd = P_PMC
                       AND pm.dealer_map_cd = P_PMC
                       AND pm.part_num = d.part_num) LOOP
        ln_part := 1;
        IF cur_p.catg_cd = 'AG' THEN
          ln_cons_val := nvl(ln_cons_val, 0) + nvl(cur_p.amc_adj, 0);
        ELSE
          ln_part_val := nvl(ln_part_val, 0) + nvl(cur_p.amc_adj, 0);
        END IF;

        IF cur_r.mcp_type = 'SMP' THEN -- Added on 27-MAR-2026 for SMP
          UPDATE vd_amc_enrol d
             SET srv_used_qty = nvl(srv_used_qty, 0) + nvl(cur_p.bill_qty, 0) -
                                nvl(cur_p.ret_qty, 0)
           WHERE d.principal_map_cd = P_PMC
             AND d.amc_num = P_AMC_NUM
             AND d.srv_type IN ('P', 'C')
             --AND d.srv_code = cur_p.part_num
             AND EXISTS (SELECT g.group_cd
                             FROM pm_part_group g
                            WHERE g.principal_map_cd = d.principal_map_cd
                              AND g.part_num = cur_p.part_num
                              AND g.group_cd = d.group_cd
                              );

          IF SQL%NOTFOUND THEN
            UPDATE vd_amc_enrol d
               SET srv_used_qty = nvl(srv_used_qty, 0) + nvl(cur_p.bill_qty, 0) -
                                  nvl(cur_p.ret_qty, 0)
             WHERE d.principal_map_cd = P_PMC
               AND d.amc_num = P_AMC_NUM
               AND d.srv_type IN ('P', 'C')
               AND d.srv_code = cur_p.part_num;

            IF SQL%NOTFOUND THEN
              UPDATE vd_amc_enrol d
                 SET srv_used_qty = nvl(srv_used_qty, 0) + nvl(cur_p.bill_qty, 0) -
                                    nvl(cur_p.ret_qty, 0)
               WHERE d.principal_map_cd = P_PMC
                 AND d.amc_num = P_AMC_NUM
                 AND d.srv_type IN ('P', 'C')
                 AND d.srv_code = cur_p.root_part_num;
            END IF;
          END IF;

        ELSE
          UPDATE vd_amc_enrol d
             SET srv_used_qty = nvl(srv_used_qty, 0) + nvl(cur_p.bill_qty, 0) -
                                nvl(cur_p.ret_qty, 0)
           WHERE d.principal_map_cd = P_PMC
             AND d.amc_num = P_AMC_NUM
             AND d.srv_type in ('P', 'C')
             AND d.catg_cd = 'I'
             AND d.srv_code = cur_p.root_part_num;

          IF SQL%NOTFOUND THEN
            UPDATE vd_amc_enrol d
               SET srv_used_qty = nvl(srv_used_qty, 0) +
                                  nvl(cur_p.bill_qty, 0) -
                                  nvl(cur_p.ret_qty, 0)
             WHERE d.principal_map_cd = P_PMC
               AND d.amc_num = P_AMC_NUM
               AND d.srv_type in ('P', 'C')
               AND d.catg_cd = 'G'
               AND EXISTS
             (SELECT g.group_cd
                      FROM pm_part_group g
                     WHERE g.principal_map_cd = d.principal_map_cd
                       AND g.part_num = cur_p.root_part_num
                       AND g.group_cd = d.group_cd);
          END IF;
        END IF;
      END LOOP;

      FOR cur_l IN (SELECT /*+ INDEX(r IDX_VD_RO_OPR_RO_NUM)*/
                     r.opr_cd, r.opr_qty, r.opr_amt
                      FROM vd_ro_opr r
                     WHERE r.parent_group = cur_r.parent_group
                       AND r.dealer_map_cd = cur_r.dealer_map_cd
                       AND r.loc_cd = cur_r.loc_cd
                       AND r.comp_fa = cur_r.comp_fa
                       AND r.ro_num = cur_r.ro_num
                       AND r.doc_type = 'SRI'
                       AND r.opr_type = 'AMC') LOOP
        ln_lbr     := 1;
        ln_lbr_val := nvl(ln_lbr_val, 0) + nvl(cur_l.opr_amt, 0);

        UPDATE vd_amc_enrol d
           SET srv_used_qty = nvl(srv_used_qty, 0) + 1
         WHERE d.principal_map_cd = P_PMC
           AND d.amc_num = P_AMC_NUM
           AND d.srv_type = 'L'
           AND d.srv_code = cur_l.opr_cd;
      END LOOP;
      IF ln_part = 1 OR ln_lbr = 1 THEN
        ln_srv_cnt := nvl(ln_srv_cnt, 0) + 1;
      END IF;
    END LOOP;

    IF ln_part_val > 0 OR ln_cons_val > 0 OR ln_lbr_val > 0 OR
       ln_srv_cnt > 0 THEN
      UPDATE vh_amc_enrol d
         SET part_used_amt       = nvl(part_used_amt, 0) +
                                   nvl(ln_part_val, 0),
             consumable_used_amt = nvl(consumable_used_amt, 0) +
                                   nvl(ln_cons_val, 0),
             labour_used_amt     = nvl(labour_used_amt, 0) +
                                   nvl(ln_lbr_val, 0),
             tot_srv_offered     = nvl(tot_srv_offered, 0) + ln_srv_cnt
       WHERE d.principal_map_cd = P_PMC
         AND d.amc_num = P_AMC_NUM;
    END IF;
    COMMIT;

  END sp_amc_avail_qty;
```

#### SP-022 - PKG_AMC.SP_POP_CANCEL_DTL

**Invoked From:**

- vt_amc_cncl_fmb.xml [Trigger: WHEN-LIST-CHANGED]

---

**Screen:**

Cancellation Details (N/A / CN_MAIN)

---

**Purpose**

Populates the session-scoped cancellation detail tables (`GBL_AMC_DTL` and `GBL_AMC_CHARGES`) with the calculated refund and charge amounts for an AMC cancellation. For each service line in the enrolled AMC package, it determines the cancellation charge (based on the selected charge percentage), computes the refund amount, resolves the applicable tax rates, and inserts the results into the global working tables for the current session.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_pmc | NUMBER | IN |
| p_amc_num | VARCHAR2 | IN |
| p_cncl_chg | NUMBER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_err_cd | NUMBER | OUT |
| p_err_msg | VARCHAR2 | OUT |

---

**Dependencies**

- PKG_AMC.SF_GET_SELL_PRICE ([SP-020](#SP-020--PKG_AMC.SF_GET_SELL_PRICE)) - PKG_AMC.pck (or .pld)
- PKG_AMC.SP_AMC_AVAIL_QTY ([SP-021](#SP-021--PKG_AMC.SP_AMC_AVAIL_QTY)) - PKG_AMC.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Retrieve the AMC enrollment header (GST type, customer state, dealer state, customer code, parent group, selling details, etc.) from `VH_AMC_ENROL`.
- Step 2 - For each service detail line in `VD_AMC_ENROL` for the contract, calculate the available (remaining) service amount by calling `PKG_AMC.SP_AMC_AVAIL_QTY`.
- Step 3 - Determine the before-tax sell price using `PKG_AMC.SF_GET_SELL_PRICE` based on MRP, tax code, and GST state.
- Step 4 - Apply the selected cancellation charge percentage to the available balance to calculate the cancellation deduction amount.
- Step 5 - Calculate the refund amount = available balance - cancellation charge amount.
- Step 6 - Resolve the applicable GST/tax amounts for the refund using the tax configuration.
- Step 7 - Insert the computed line into `GBL_AMC_DTL` (service detail for display) and `GBL_AMC_CHARGES` (charge lines for saving).
- Step 8 - Return error code 0 on success, or a non-zero error code with message on failure.

---
**Decision Points**

DP-001

Condition:
GST type of the AMC enrollment determines which tax calculation path to use.

TRUE:
Apply GST-type-specific tax rate calculation (IGST vs CGST/SGST split).

FALSE:
Apply the standard (pre-GST) service tax calculation.

DP-002

Condition:
Available service balance is greater than zero.

TRUE:
Compute cancellation charges and refund amounts and insert into GBL tables.

FALSE:
Skip the service line (no available balance to cancel).

---
**Database Interactions**

- DB-001 - Read GBL_AMC_DTL - Reads data from GBL_AMC_DTL (columns: parent group, dealer map cd, loc cd, comp fa, pkg code, srl num, srv type, srv cd, and 10 more column(s)) for lookup or validation.
- DB-002 - Read AM_CHARGE - Reads data from AM_CHARGE for lookup or validation.
- DB-003 - Read AM_LIST_RANGE - Reads data from AM_LIST_RANGE for lookup or validation.
- DB-004 - Read VH_AMC_ENROL - Reads data from VH_AMC_ENROL for lookup or validation.
- DB-005 - Read GM_CIN - Reads data from GM_CIN for lookup or validation.
- DB-006 - Read AM_DEALER_LOC - Reads data from AM_DEALER_LOC for lookup or validation.
- DB-007 - Delete from TEMP - Deletes rows from TEMP.
- DB-008 - Delete from GBL_AMC_DTL - Deletes rows from GBL_AMC_DTL.
- DB-009 - Delete from GBL_AMC_CHARGES - Deletes rows from GBL_AMC_CHARGES.
- DB-010 - Insert into DETAILS - Persists a new row into DETAILS.
- DB-011 - Read VD_AMC_ENROL - Reads data from VD_AMC_ENROL for lookup or validation.
- DB-012 - Read PM_PART - Reads data from PM_PART for lookup or validation.
- DB-013 - Insert into GBL_AMC_DTL - Persists a new row into GBL_AMC_DTL using columns: parent group, dealer map cd, loc cd, comp fa, pkg code, srl num, srv type, srv cd, and 10 more column(s).
- DB-014 - Read VM_DLR_LTS - Reads data from VM_DLR_LTS for lookup or validation.
- DB-015 - Update GBL_AMC_DTL - Updates existing rows in GBL_AMC_DTL (columns: parent group, dealer map cd, loc cd, comp fa, pkg code, srl num, srv type, srv cd, and 10 more column(s)).
- DB-016 - Insert into GBL_AMC_CHARGES - Persists a new row into GBL_AMC_CHARGES using columns: parent group, dealer map cd, loc cd, comp fa, pkg code, srl num, srv type, srv cd, and 8 more column(s).
**Business Rules**

BR-001 - Cancellation charge amount = available balance × (selected charge percentage / 100); refund amount = available balance - cancellation charge.
BR-002 - Tax amounts on the refund are calculated based on the enrollment's GST type and the applicable state (customer state vs dealer state for IGST determination).
BR-003 - Results are written to session-scoped global tables (`GBL_AMC_DTL`, `GBL_AMC_CHARGES`) - these are temporary working tables that hold calculation results until the cancellation is confirmed and saved.

---
**Implementation Logic**

```plsql
  PROCEDURE SP_POP_CANCEL_DTL(p_pmc      IN NUMBER,
                              p_amc_num  IN VARCHAR2,
                              p_cncl_chg IN NUMBER,
                              p_err_cd   OUT NUMBER,
                              p_err_msg  OUT VARCHAR2) IS
    lv_gst_type   vh_amc_enrol.gst_type%TYPE;
    lv_cust_state vh_amc_enrol.cust_state_cd%TYPE;
    lv_dlr_state  vh_amc_enrol.dlr_state_cd%TYPE;
    lv_cust_cd    vh_amc_enrol.cust_cd%TYPE;
    lv_parent     vh_amc_enrol.selling_parent_group%TYPE;
    lv_dealer     vh_amc_enrol.selling_dealer_map_cd%TYPE;
    lv_loc        vh_amc_enrol.selling_loc_cd%TYPE;
    lv_comp       vh_amc_enrol.selling_comp_fa%TYPE;
    lv_svar       vh_amc_enrol.svar_cd%TYPE;
    ld_amc_date   vh_amc_enrol.amc_start_date%TYPE; --ADDED BY POOJA ON 12.08.17
    lv_vin        vh_amc_enrol.vin%TYPE;

    lv_part_tax   pm_part.part_tax_cd%TYPE;
    lv_opr_tax_cd vm_dlr_lts.opr_tax_cd%TYPE;

    lv_gst_state  VARCHAR2(3);
    lv_lst_yn     VARCHAR2(3);
    ln_rate       NUMBER(12, 3) := 0;
    ln_disc       NUMBER(12, 3) := 0;
    ln_cancel_amt NUMBER(12, 3) := 0;
    ln_rfnd_amt   NUMBER(12, 3) := 0;

    ln_sell_price  NUMBER(13, 2);
    ln_disc_amt    NUMBER(13, 2);
    ln_com_per     NUMBER := 0;
    ln_nor_per     NUMBER := 0;
    ln_opr_srl     NUMBER := 0;
    lv_param       VARCHAR2(4000);
    ln_chg_srl     NUMBER := 1;
    lv_divide      NUMBER(15, 4);
    lv_divisor     NUMBER(15, 2);
    lc_cus_chg_cnt NUMBER := 1;
    lv_oparam      VARCHAR2(4000);
    lv_token       VARCHAR2(200);
    lv_value       NUMBER;
    lv_opr_chg_amt NUMBER;
    ln_num         VARCHAR2(15) := 0;
    tc_opr_charges ctab;
    to_opr_charges ctab;

    tc_part_charges ctab;
    to_part_charges ctab;
    ln_pchg_srl     NUMBER := 1;
    ln_part_srl     NUMBER := 0;
    lv_part_chg_amt NUMBER;

    -- For GST Imp Date 12-MAR-2018
    ld_gst_imp_dt   DATE;
    ld_mcp_pdt      DATE;

    -- Added by Rajeev on 29-MAY-2019 for KERALA CESS
    --lv_party_cd   gm_vin.party_cd%TYPE;
    lv_gst_num    gm_cin.gst_num%TYPE;
    lv_cess_appl  VARCHAR2(5) := 'N';--RR Kerala Flood Cess 21-Jun-2019

    CURSOR cur_lbr(pi_parent   VARCHAR2,
                   pi_dealer   NUMBER,
                   pi_loc      VARCHAR2,
                   pi_comp     VARCHAR2,
                   pi_pkg_code VARCHAR2) IS
      SELECT srl_num,
             srv_type,
             srv_cd,
             qty,
             basic_value,
             0           discount_amt,
             tot_value   sell_price
        FROM gbl_amc_dtl
       WHERE parent_group = pi_parent
         AND dealer_map_cd = pi_dealer
         AND loc_cd = pi_loc
         AND comp_fa = pi_comp
         AND pkg_code = pi_pkg_code
         AND srv_type = 'L';

    CURSOR cur_lbr_charge(pi_dealer    NUMBER,
                          pi_loc       VARCHAR2,
                          pi_ptax_cd   IN VARCHAR2,
                          pi_gst_type  IN VARCHAR2,
                          pi_gst_state IN VARCHAR2) IS
      SELECT a.charge_type,
             a.charge_ind,
             a.charge_value,
             a.charge_cd,
             b.common_ind,
             b.order_srl
        FROM am_charge a, vm_tax b
       WHERE b.dealer_map_cd = pi_dealer
         AND a.dealer_map_cd = b.dealer_map_cd
         AND a.loc_cd = b.loc_cd
         AND a.loc_cd = pi_loc
         AND a.charge_type = b.charge_type
         AND a.charge_cd = b.charge_cd
         AND NVL(b.gst_type, 'S') = pi_gst_type
         AND b.gst_state_cd = pi_gst_state
         AND b.common_ind = 'M'
         AND b.opr_tax_cd = pi_ptax_cd;

    CURSOR cur_part(pi_parent   VARCHAR2,
                    pi_dealer   NUMBER,
                    pi_loc      VARCHAR2,
                    pi_comp     VARCHAR2,
                    pi_pkg_code VARCHAR2) IS
      SELECT srl_num,
             srv_type,
             srv_cd,
             qty,
             basic_value,
             0           discount_amt,
             tot_value   sell_price
        FROM gbl_amc_dtl
       WHERE parent_group = pi_parent
         AND dealer_map_cd = pi_dealer
         AND loc_cd = pi_loc
         AND comp_fa = pi_comp
         AND pkg_code = pi_pkg_code
         AND srv_type != 'L';

    CURSOR cur_part_charge(pi_dealer    NUMBER,
                           pi_loc       VARCHAR2,
                           pi_ptax_cd   IN VARCHAR2,
                           pi_gst_type  IN VARCHAR2,
                           pi_gst_state IN VARCHAR2) IS
      SELECT a.charge_type,
             a.charge_ind,
             a.charge_value,
             a.charge_cd,
             b.common_ind,
             b.order_srl
        FROM am_charge a, Pm_tax b
       WHERE b.dealer_map_cd = pi_dealer
         AND a.dealer_map_cd = b.dealer_map_cd
         AND a.loc_cd = b.loc_cd
         AND A.LOC_CD = pi_loc
         AND a.charge_type = b.charge_type
         AND a.charge_cd = b.charge_cd
         AND (b.common_ind IN ('M') OR
             b.common_ind = DECODE(pi_gst_type, 'S', 'O', 'I', 'C'))
         AND tax_type = 'S'
         AND b.gst_state_cd = pi_gst_state
         AND b.part_tax_cd = pi_ptax_cd;

  BEGIN
    p_err_cd      := 0;
    p_err_msg     := NULL;
    lv_gst_type   := NULL;
    lv_cust_state := NULL;
    lv_dlr_state  := NULL;
    ld_amc_date   := NULL;

    -- For GST Imp Date 12-MAR-2018
    BEGIN
      SELECT TO_DATE(list_from_range, 'DD-MON-RRRR') imp_dt
        INTO ld_gst_imp_dt
        FROM am_list_range
       WHERE list_name = 'GST_IMP_DATE'
         AND principal_map_cd = p_pmc
         AND list_code = 'GST';
    EXCEPTION WHEN OTHERS THEN
      ld_gst_imp_dt := NULL;
    END;
    BEGIN
      SELECT TO_DATE(list_from_range, 'DD-MON-RRRR') imp_dt
        INTO ld_mcp_pdt
        FROM am_list_range
       WHERE list_name = 'MCP_PTAX_IDATE'
         AND principal_map_cd = p_pmc
         AND list_code = 'PTX';
    EXCEPTION WHEN OTHERS THEN
      ld_mcp_pdt := NULL;
    END;

    BEGIN
      SELECT gst_type,
             cust_state_cd,
             dlr_state_cd,
             cust_cd,
             selling_dealer_map_cd,
             selling_loc_cd,
             selling_parent_group,
             selling_comp_fa,
             svar_Cd,
             amc_start_date,
             vin
        INTO lv_gst_type,
             lv_cust_state,
             lv_dlr_state,
             lv_cust_cd,
             lv_dealer,
             lv_loc,
             lv_parent,
             lv_comp,
             lv_svar,
             ld_amc_date,
             lv_vin
        FROM vh_amc_enrol
       WHERE principal_map_cd = p_pmc
         AND amc_num = p_amc_num;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    -- Added by Shailesh on 31.07.2019 for KERALA CESS
    BEGIN
      BEGIN
        SELECT gst_num
          INTO lv_gst_num
          FROM gm_cin
         WHERE principal_map_cd = p_pmc
           AND cust_cd = lv_cust_cd;
      EXCEPTION WHEN OTHERS THEN
         lv_gst_num := 'GSTUNREGISTERED';
      END;
      --SS Kerala Flood Cess 31.07.2019
      lv_cess_appl := SF_CESS_APPLICABLE_DEALER(lv_parent,
                                                lv_dealer,
                                                lv_loc);
    END;

    BEGIN
      SP_AMC_AVAIL_QTY(p_pmc, p_amc_num, lv_vin, p_err_cd, p_err_msg);
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    IF lv_gst_type IS NULL THEN
      lv_gst_type := 'S';
      BEGIN
        SELECT m.gst_state_cd
          INTO lv_gst_state
          FROM am_dealer_loc l, gm_state m
         WHERE l.parent_group = lv_parent
           AND l.dealer_map_cd = lv_dealer
           AND l.loc_cd = lv_loc
           AND m.principal_map_cd = l.principal_map_cd
           AND m.state_cd = l.state_cd;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;
    ELSE
      IF lv_gst_type = 'S' THEN
        lv_gst_state := lv_dlr_state;
        lv_lst_yn    := 'Y';
      ELSE
        lv_gst_state := lv_cust_state;
        lv_lst_yn    := 'N';
      END IF;
    END IF;

    -- Delete from temp table
    DELETE FROM gbl_amc_dtl
     WHERE parent_group = lv_parent
       AND dealer_map_cd = lv_dealer
       AND loc_cd = lv_loc
       AND comp_fa = lv_comp
       AND pkg_code = p_amc_num;

    DELETE FROM gbl_amc_charges
     WHERE parent_group = lv_parent
       AND dealer_map_cd = lv_dealer
       AND loc_cd = lv_loc
       AND comp_fa = lv_comp
       AND pkg_code = p_amc_num;

    -- Insert into Details Table
    FOR cur_d IN (SELECT /*+ index (r PK_VD_AMC_ENROL)*/
                   r.srl_num,
                   r.srv_type,
                   r.srv_code,
                   NVL(r.qty, 0) -
                   (NVL(r.srv_used_qty, 0) /*+ NVL(r.stlm_qty, 0)*/) qty,
                   r.rate,
                   r.discount_per disc_per
                    FROM vd_amc_enrol r
                   WHERE principal_map_cd = p_pmc
                     AND amc_num = p_amc_num
                   ORDER BY srl_num, srv_code) LOOP
      ln_rate       := NULL;
      ln_disc       := NULL;
      ln_sell_price := NULL;
      ln_disc_amt   := NULL;
      ln_cancel_amt := NULL;
      ln_rfnd_amt   := NULL;

      ln_rate := NVL(cur_d.qty, 0) * NVL(cur_d.rate, 0);
      ln_disc := NVL(ln_rate, 0) * NVL(cur_d.disc_per, 0) / 100;
      --dbms_output.put_line(cur_d.srv_code||' - '||ln_rate||' - '||ln_disc||' - '||ln_total);

      IF cur_d.srv_type = 'L' THEN
        ln_sell_price := ln_rate;
        ln_disc_amt   := ln_disc;
      ELSE
        -- Added by Rajeev on 13-MAR-2018,
        -- Selling price canculated only for GST Period AMC
        IF p_err_cd = 0 AND ld_amc_date >= ld_gst_imp_dt AND ld_amc_date < ld_mcp_pdt THEN
          BEGIN
            SELECT NVL(part_tax_cd, 'A')
              INTO lv_part_tax
              FROM pm_part
             WHERE part_num = cur_d.srv_code
               AND principal_map_cd = p_pmc
               AND dealer_map_cd = p_pmc;
          EXCEPTION
            WHEN OTHERS THEN
              lv_part_tax := 'A';
          END;

          IF lv_part_tax IS NOT NULL THEN
            ln_sell_price := PKG_AMC.SF_GET_SELL_PRICE(lv_parent,
                                                       lv_dealer,
                                                       lv_loc,
                                                       lv_part_tax,
                                                       ln_rate,
                                                       lv_lst_yn,
                                                       lv_gst_state);
            ln_disc_amt   := ln_sell_price * cur_d.disc_per / 100;
          END IF;
        ELSE
          ln_sell_price := ln_rate;
          ln_disc_amt   := ln_disc;
        END IF;
      END IF;

      ln_cancel_amt := (NVL(ln_sell_price, 0) - NVL(ln_disc_amt, 0)) *
                       NVL(p_cncl_chg, 0) / 100;
      ln_rfnd_amt   := ROUND((NVL(ln_sell_price, 0) - NVL(ln_disc_amt, 0)) -
                             NVL(ln_cancel_amt, 0),
                             2);

      -- Insert into details table
      INSERT INTO gbl_amc_dtl
        (parent_group,
         dealer_map_cd,
         loc_cd,
         comp_fa,
         pkg_code,
         srl_num,
         srv_type,
         srv_cd,
         qty,
         discount_per,
         rate,
         basic_value,
         discount_amt,
         tot_value,
         gst_type,
         sell_price)
      VALUES
        (lv_parent,
         lv_dealer,
         lv_loc,
         lv_comp,
         p_amc_num,
         cur_d.srl_num,
         cur_d.srv_type,
         cur_d.srv_code,
         cur_d.qty,
         cur_d.disc_per,
         cur_d.rate,
         ln_rate,
         ln_disc_amt,
         ln_rfnd_amt,
         lv_gst_type,
         ln_sell_price);
    END LOOP;

    IF p_err_cd = 0 AND ld_amc_date >= ld_gst_imp_dt AND ld_amc_date < ld_mcp_pdt /*'01-JUL-2017'*/ THEN
      --MODIFIED BY POOJA ON 12.08.17
      FOR cur_l IN cur_lbr(lv_parent, lv_dealer, lv_loc, lv_comp, p_amc_num) LOOP
        --lv_tax_cd     := NULL;
        ln_opr_srl := cur_l.srl_num;
        lv_param   := NULL;

        ln_nor_per := 100;
        ln_com_per := 0;
        BEGIN
          SELECT opr_tax_cd, 100, 0
            INTO lv_opr_tax_cd, ln_nor_per, ln_com_per
            FROM vm_dlr_lts
           WHERE dealer_map_cd = lv_dealer
             AND loc_cd = lv_loc
             AND opr_cd = cur_l.srv_cd
             AND svar_cd = lv_svar;
        EXCEPTION
          WHEN OTHERS THEN
            lv_opr_tax_cd := 'LB001';
            ln_nor_per    := 100;
            ln_com_per    := 0;
        END;

        DECLARE
          ln_charge_cnt NUMBER := 1;
        BEGIN
          FOR cur_c IN cur_lbr_charge(lv_dealer,
                                      lv_loc,
                                      lv_opr_tax_cd,
                                      lv_gst_type,
                                      lv_gst_state) LOOP
            tc_opr_charges(ln_charge_cnt).charge_type := cur_c.charge_type;
            tc_opr_charges(ln_charge_cnt).charge_ind := cur_c.charge_ind;
            tc_opr_charges(ln_charge_cnt).charge_value := cur_c.charge_value;
            tc_opr_charges(ln_charge_cnt).charge_cd := cur_c.charge_cd;
            tc_opr_charges(ln_charge_cnt).common_ind := cur_c.common_ind;
            tc_opr_charges(ln_charge_cnt).charge_srl := ln_chg_srl;
            tc_opr_charges(ln_charge_cnt).order_srl := cur_c.order_srl;
            tc_opr_charges(ln_charge_cnt).srv_type := cur_l.srv_type;
            tc_opr_charges(ln_charge_cnt).opr_cd := cur_l.srv_cd;
            tc_opr_charges(ln_charge_cnt).opr_srl := cur_l.srl_num;
            ln_charge_cnt := ln_charge_cnt + 1;

            IF cur_c.charge_ind = 'P' THEN
              lv_divisor := 100;
            ELSE
              lv_divisor := 1;
            END IF;
            lv_divide := cur_c.charge_value / lv_divisor;
            lv_param  := lv_param || cur_c.charge_type || ';' ||
                         TO_CHAR(cur_c.charge_value / lv_divisor) || ';' ||
                         cur_c.charge_ind || ';';

            ln_chg_srl := ln_chg_srl + 1;
          END LOOP;

          FOR x IN 1 .. tc_opr_charges.COUNT LOOP
            to_opr_charges(lc_cus_chg_cnt).charge_type := tc_opr_charges(x)
                                                          .charge_type;
            to_opr_charges(lc_cus_chg_cnt).charge_ind := tc_opr_charges(x)
                                                         .charge_ind;
            to_opr_charges(lc_cus_chg_cnt).charge_value := tc_opr_charges(x)
                                                           .charge_value;
            to_opr_charges(lc_cus_chg_cnt).charge_cd := tc_opr_charges(x)
                                                        .charge_cd;
            to_opr_charges(lc_cus_chg_cnt).common_ind := tc_opr_charges(x)
                                                         .common_ind;
            to_opr_charges(lc_cus_chg_cnt).charge_srl := tc_opr_charges(x)
                                                         .charge_srl;
            to_opr_charges(lc_cus_chg_cnt).order_srl := tc_opr_charges(x)
                                                        .order_srl;
            to_opr_charges(lc_cus_chg_cnt).srv_type := tc_opr_charges(x)
                                                       .srv_type;
            to_opr_charges(lc_cus_chg_cnt).opr_cd := tc_opr_charges(x)
                                                     .opr_cd;
            to_opr_charges(lc_cus_chg_cnt).opr_srl := tc_opr_charges(x)
                                                      .opr_srl;
            lc_cus_chg_cnt := lc_cus_chg_cnt + 1;
          END LOOP;

          lv_param := 'SP;' || TO_CHAR(cur_l.sell_price) || ';' || 'P;' ||
                      'QTY;' || TO_CHAR(NVL(1, 1)) || ';' || 'A;' || 'DIS;' ||
                      TO_CHAR(NVL(cur_l.discount_amt, 0)) || ';' || 'A;' ||
                      'NAT;' || (NVL(ln_nor_per, 0) / 100) || ';' || 'P;' ||
                      'COM;' || TO_CHAR(NVL(ln_com_per, 0) / 100) || ';' || 'P;' ||
                      lv_param;
        END;

        BEGIN
          IF NVL(lv_cess_appl, 'N') = 'Y' AND lv_gst_type = 'S' AND
                  NVL(lv_gst_num,'GSTUNREGISTERED') = 'GSTUNREGISTERED' THEN
            Evaluate_Expr('MCPINV',
                          lv_param,
                          lv_dealer,
                          lv_loc,
                          lv_oparam,
                          ln_num);
          ELSE
          Evaluate_Expr('AMCINV',
                        lv_param,
                        lv_dealer,
                        lv_loc,
                        lv_oparam,
                        ln_num);
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            p_err_cd  := 1;
            p_err_msg := 'Evaluate Error - Operation';
        END;
        lv_opr_chg_amt := 0;

        LOOP
          lv_token  := SUBSTR(lv_oparam, 1, INSTR(lv_oparam, ';', 1, 1) - 1);
          lv_oparam := SUBSTR(lv_oparam, INSTR(lv_oparam, ';', 1, 1) + 1);
          lv_value  := TO_NUMBER(SUBSTR(lv_oparam,
                                        1,
                                        INSTR(lv_oparam, ';', 1, 1) - 1));
          lv_oparam := SUBSTR(lv_oparam, INSTR(lv_oparam, ';', 1, 1) + 1);
          --dbms_output.put_line(lv_token || ' - '||lv_value);
          IF to_opr_charges.COUNT > 0 THEN
            FOR i IN to_opr_charges.FIRST .. to_opr_charges.LAST LOOP
              IF to_opr_charges(i).charge_type = lv_token AND to_opr_charges(i)
                 .opr_srl = ln_opr_srl THEN
                to_opr_charges(i).charge_amt := ROUND(lv_value, 2);
                lv_opr_chg_amt := NVL(lv_opr_chg_amt, 0) +
                                  ROUND(NVL(lv_value, 0), 2);
              END IF;
            END LOOP;
          END IF;
          EXIT WHEN lv_oparam IS NULL;
        END LOOP;
        UPDATE gbl_amc_dtl
           SET charge_amt = lv_opr_chg_amt,
               net_value  = NVL(tot_value, 0) + NVL(lv_opr_chg_amt, 0)
         WHERE parent_group = lv_parent
           AND dealer_map_cd = lv_dealer
           AND loc_cd = lv_loc
           AND comp_fa = lv_comp
           AND pkg_code = p_amc_num
           AND srl_num = cur_l.srl_num
           AND srv_type = cur_l.srv_type
           AND srv_cd = cur_l.srv_cd;
      END LOOP;
      -- Insert Labour Charges
      FOR i IN 1 .. to_opr_charges.COUNT LOOP
        IF to_opr_charges(i).opr_cd IS NOT NULL /*AND
                                                                  NVL(to_opr_charges(i).charge_amt, 0) > 0*/
         THEN
          INSERT INTO gbl_amc_charges
            (parent_group,
             dealer_map_cd,
             loc_cd,
             comp_fa,
             pkg_code,
             srl_num,
             srv_type,
             srv_cd,
             charge_srl,
             common_ind,
             order_srl,
             charge_cd,
             charge_type,
             charge_ind,
             charge_value,
             charge_amt)
          VALUES
            (lv_parent,
             lv_dealer,
             lv_loc,
             lv_comp,
             p_amc_num,
             to_opr_charges(i).opr_srl,
             to_opr_charges(i).srv_type,
             to_opr_charges(i).opr_cd,
             to_opr_charges(i).charge_srl,
             to_opr_charges(i).common_ind,
             to_opr_charges(i).order_srl,
             to_opr_charges(i).charge_cd,
             to_opr_charges(i).charge_type,
             to_opr_charges(i).charge_ind,
             to_opr_charges(i).charge_value,
             to_opr_charges(i).charge_amt);
        END IF;
      END LOOP;

      -- Calculate Part Charges
      lc_cus_chg_cnt := 1;
      ln_pchg_srl    := ln_chg_srl;
      FOR cur_p IN cur_part(lv_parent,
                            lv_dealer,
                            lv_loc,
                            lv_comp,
                            p_amc_num) LOOP
        lv_param    := NULL;
        lv_oparam   := NULL;
        ln_part_srl := cur_p.srl_num;
        BEGIN
          SELECT NVL(part_tax_cd, 'A')
            INTO lv_part_tax
            FROM pm_part
           WHERE part_num = cur_p.srv_cd
             AND principal_map_cd = p_pmc
             AND dealer_map_cd = p_pmc;
        EXCEPTION
          WHEN OTHERS THEN
            lv_part_tax := 'A';
        END;

        DECLARE
          ln_chg_cnt NUMBER := 1;
        BEGIN
          FOR cur_c IN cur_part_charge(lv_dealer,
                                       lv_loc,
                                       lv_part_tax,
                                       lv_gst_type,
                                       lv_gst_state) LOOP
            tc_part_charges(ln_chg_cnt).charge_type := cur_c.charge_type;
            tc_part_charges(ln_chg_cnt).charge_ind := cur_c.charge_ind;
            tc_part_charges(ln_chg_cnt).charge_value := cur_c.charge_value;
            tc_part_charges(ln_chg_cnt).charge_cd := cur_c.charge_cd;
            tc_part_charges(ln_chg_cnt).common_ind := cur_c.common_ind;
            tc_part_charges(ln_chg_cnt).charge_srl := ln_pchg_srl;
            tc_part_charges(ln_chg_cnt).srl_num := cur_p.srl_num;
            tc_part_charges(ln_chg_cnt).order_srl := cur_c.order_srl;
            tc_part_charges(ln_chg_cnt).srv_type := cur_p.srv_type;
            tc_part_charges(ln_chg_cnt).opr_cd := cur_p.srv_cd;
            ln_chg_cnt := ln_chg_cnt + 1;

            IF cur_c.charge_ind = 'P' THEN
              lv_divisor := 100;
            ELSE
              lv_divisor := 1;
            END IF;

            lv_divide   := cur_c.charge_value / lv_divisor;
            lv_param    := lv_param || cur_c.charge_type || ';' ||
                           TO_CHAR(cur_c.charge_value / lv_divisor) || ';' ||
                           cur_c.charge_ind || ';';
            ln_pchg_srl := ln_pchg_srl + 1;
          END LOOP;

          FOR x IN 1 .. tc_opr_charges.COUNT LOOP
            to_part_charges(lc_cus_chg_cnt).charge_type := tc_part_charges(x)
                                                           .charge_type;
            to_part_charges(lc_cus_chg_cnt).charge_ind := tc_part_charges(x)
                                                          .charge_ind;
            to_part_charges(lc_cus_chg_cnt).charge_value := tc_part_charges(x)
                                                            .charge_value;
            to_part_charges(lc_cus_chg_cnt).charge_cd := tc_part_charges(x)
                                                         .charge_cd;
            to_part_charges(lc_cus_chg_cnt).common_ind := tc_part_charges(x)
                                                          .common_ind;
            to_part_charges(lc_cus_chg_cnt).charge_srl := tc_part_charges(x)
                                                          .charge_srl;
            to_part_charges(lc_cus_chg_cnt).order_srl := tc_part_charges(x)
                                                         .order_srl;
            to_part_charges(lc_cus_chg_cnt).srl_num := tc_part_charges(x)
                                                       .srl_num;
            to_part_charges(lc_cus_chg_cnt).srv_type := tc_part_charges(x)
                                                        .srv_type;
            to_part_charges(lc_cus_chg_cnt).opr_cd := tc_part_charges(x)
                                                      .opr_cd;
            --dbms_output.put_line('1 '||to_part_charges(lc_cus_chg_cnt).charge_type);
            lc_cus_chg_cnt := lc_cus_chg_cnt + 1;
          END LOOP;
          lv_param := 'SP;' || TO_CHAR(cur_p.sell_price) || ';' || 'P;' ||
                      'QTY;' || TO_CHAR(NVL(1, 1)) || ';' || 'A;' || 'DIS;' ||
                      TO_CHAR(NVL(cur_p.discount_amt, 0)) || ';' || 'A;' ||
                      'NAT;' || (NVL(100, 0) / 100) || ';' || 'P;' ||
                      'COM;' || TO_CHAR(NVL(0, 0) / 100) || ';' || 'P;' ||
                      lv_param;
        END;
        BEGIN
         IF NVL(lv_cess_appl, 'N') = 'Y' AND lv_gst_type = 'S' AND
                  NVL(lv_gst_num,'GSTUNREGISTERED') = 'GSTUNREGISTERED' THEN
            Evaluate_Expr('MCPINV',
                          lv_param,
                          lv_dealer,
                          lv_loc,
                          lv_oparam,
                          ln_num);
          ELSE
          Evaluate_Expr('AMCINV',
                        lv_param,
                        lv_dealer,
                        lv_loc,
                        lv_oparam,
                        ln_num);
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            p_err_cd  := 1;
            p_err_msg := 'Evaluate Error - Operation';
        END;
        lv_part_chg_amt := 0;
        LOOP
          lv_token  := SUBSTR(lv_oparam, 1, INSTR(lv_oparam, ';', 1, 1) - 1);
          lv_oparam := SUBSTR(lv_oparam, INSTR(lv_oparam, ';', 1, 1) + 1);
          lv_value  := TO_NUMBER(SUBSTR(lv_oparam,
                                        1,
                                        INSTR(lv_oparam, ';', 1, 1) - 1));
          lv_oparam := SUBSTR(lv_oparam, INSTR(lv_oparam, ';', 1, 1) + 1);

          IF to_part_charges.COUNT > 0 THEN
            FOR z IN to_part_charges.FIRST .. to_part_charges.LAST LOOP
              IF to_part_charges(z).charge_type = lv_token AND to_part_charges(z)
                 .srl_num = ln_part_srl THEN
                to_part_charges(z).charge_amt := ROUND(lv_value, 2);
                lv_part_chg_amt := NVL(lv_part_chg_amt, 0) +
                                   ROUND(NVL(lv_value, 0), 2);
              END IF;
            END LOOP;
          END IF;
          EXIT WHEN lv_oparam IS NULL;
        END LOOP;
        UPDATE gbl_amc_dtl
           SET charge_amt = lv_part_chg_amt,
               net_value  = NVL(tot_value, 0) + NVL(lv_part_chg_amt, 0)
         WHERE parent_group = lv_parent
           AND dealer_map_cd = lv_dealer
           AND loc_cd = lv_loc
           AND comp_fa = lv_comp
           AND pkg_code = p_amc_num
           AND srl_num = cur_p.srl_num
           AND srv_type = cur_p.srv_type
           AND srv_cd = cur_p.srv_cd;
      END LOOP;

      -- Insert Part Charges
      FOR z IN 1 .. to_part_charges.COUNT LOOP
        IF to_part_charges(z).opr_cd IS NOT NULL /*AND
                                                                  NVL(to_part_charges(z).charge_amt, 0) > 0*/
         THEN
          INSERT INTO gbl_amc_charges
            (parent_group,
             dealer_map_cd,
             loc_cd,
             comp_fa,
             pkg_code,
             srl_num,
             srv_type,
             srv_cd,
             charge_srl,
             common_ind,
             order_srl,
             charge_cd,
             charge_type,
             charge_ind,
             charge_value,
             charge_amt)
          VALUES
            (lv_parent,
             lv_dealer,
             lv_loc,
             lv_comp,
             p_amc_num,
             to_part_charges(z).srl_num,
             to_part_charges(z).srv_type,
             to_part_charges(z).opr_cd,
             to_part_charges(z).charge_srl,
             to_part_charges(z).common_ind,
             to_part_charges(z).order_srl,
             to_part_charges(z).charge_cd,
             to_part_charges(z).charge_type,
             to_part_charges(z).charge_ind,
             to_part_charges(z).charge_value,
             to_part_charges(z).charge_amt);
        END IF;
      END LOOP;
    -- Added by Rajeev on 13-MAR-2018
    ELSIF p_err_cd = 0 AND ld_amc_date >= ld_mcp_pdt THEN
      FOR cur_l IN cur_lbr(lv_parent, lv_dealer, lv_loc, lv_comp, p_amc_num) LOOP
        --lv_tax_cd     := NULL;
        ln_opr_srl := cur_l.srl_num;
        lv_param   := NULL;

        ln_nor_per := 100;
        ln_com_per := 0;
        BEGIN
          SELECT opr_tax_cd, 100, 0
            INTO lv_opr_tax_cd, ln_nor_per, ln_com_per
            FROM vm_dlr_lts
           WHERE dealer_map_cd = lv_dealer
             AND loc_cd = lv_loc
             AND opr_cd = cur_l.srv_cd
             AND svar_cd = lv_svar;
        EXCEPTION
          WHEN OTHERS THEN
            lv_opr_tax_cd := 'LB001';
            ln_nor_per    := 100;
            ln_com_per    := 0;
        END;

        DECLARE
          ln_charge_cnt NUMBER := 1;
        BEGIN
          FOR cur_c IN cur_lbr_charge(lv_dealer,
                                      lv_loc,
                                      lv_opr_tax_cd,
                                      lv_gst_type,
                                      lv_gst_state) LOOP
            tc_opr_charges(ln_charge_cnt).charge_type := cur_c.charge_type;
            tc_opr_charges(ln_charge_cnt).charge_ind := cur_c.charge_ind;
            tc_opr_charges(ln_charge_cnt).charge_value := cur_c.charge_value;
            tc_opr_charges(ln_charge_cnt).charge_cd := cur_c.charge_cd;
            tc_opr_charges(ln_charge_cnt).common_ind := cur_c.common_ind;
            tc_opr_charges(ln_charge_cnt).charge_srl := ln_chg_srl;
            tc_opr_charges(ln_charge_cnt).order_srl := cur_c.order_srl;
            tc_opr_charges(ln_charge_cnt).srv_type := cur_l.srv_type;
            tc_opr_charges(ln_charge_cnt).opr_cd := cur_l.srv_cd;
            tc_opr_charges(ln_charge_cnt).opr_srl := cur_l.srl_num;
            ln_charge_cnt := ln_charge_cnt + 1;

            IF cur_c.charge_ind = 'P' THEN
              lv_divisor := 100;
            ELSE
              lv_divisor := 1;
            END IF;
            lv_divide := cur_c.charge_value / lv_divisor;
            lv_param  := lv_param || cur_c.charge_type || ';' ||
                         TO_CHAR(cur_c.charge_value / lv_divisor) || ';' ||
                         cur_c.charge_ind || ';';

            ln_chg_srl := ln_chg_srl + 1;
          END LOOP;

          FOR x IN 1 .. tc_opr_charges.COUNT LOOP
            to_opr_charges(lc_cus_chg_cnt).charge_type := tc_opr_charges(x)
                                                          .charge_type;
            to_opr_charges(lc_cus_chg_cnt).charge_ind := tc_opr_charges(x)
                                                         .charge_ind;
            to_opr_charges(lc_cus_chg_cnt).charge_value := tc_opr_charges(x)
                                                           .charge_value;
            to_opr_charges(lc_cus_chg_cnt).charge_cd := tc_opr_charges(x)
                                                        .charge_cd;
            to_opr_charges(lc_cus_chg_cnt).common_ind := tc_opr_charges(x)
                                                         .common_ind;
            to_opr_charges(lc_cus_chg_cnt).charge_srl := tc_opr_charges(x)
                                                         .charge_srl;
            to_opr_charges(lc_cus_chg_cnt).order_srl := tc_opr_charges(x)
                                                        .order_srl;
            to_opr_charges(lc_cus_chg_cnt).srv_type := tc_opr_charges(x)
                                                       .srv_type;
            to_opr_charges(lc_cus_chg_cnt).opr_cd := tc_opr_charges(x)
                                                     .opr_cd;
            to_opr_charges(lc_cus_chg_cnt).opr_srl := tc_opr_charges(x)
                                                      .opr_srl;
            lc_cus_chg_cnt := lc_cus_chg_cnt + 1;
          END LOOP;

          lv_param := 'SP;' || TO_CHAR(cur_l.sell_price) || ';' || 'P;' ||
                      'QTY;' || TO_CHAR(NVL(1, 1)) || ';' || 'A;' || 'DIS;' ||
                      TO_CHAR(NVL(cur_l.discount_amt, 0)) || ';' || 'A;' ||
                      'NAT;' || (NVL(ln_nor_per, 0) / 100) || ';' || 'P;' ||
                      'COM;' || TO_CHAR(NVL(ln_com_per, 0) / 100) || ';' || 'P;' ||
                      lv_param;
        END;

        BEGIN
          IF NVL(lv_cess_appl, 'N') = 'Y' AND lv_gst_type = 'S' AND
                  NVL(lv_gst_num,'GSTUNREGISTERED') = 'GSTUNREGISTERED' THEN
            Evaluate_Expr('MCPINV',
                          lv_param,
                          lv_dealer,
                          lv_loc,
                          lv_oparam,
                          ln_num);
          ELSE
          Evaluate_Expr('AMCINV',
                        lv_param,
                        lv_dealer,
                        lv_loc,
                        lv_oparam,
                        ln_num);
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            p_err_cd  := 1;
            p_err_msg := 'Evaluate Error - Operation';
        END;
        lv_opr_chg_amt := 0;

        LOOP
          lv_token  := SUBSTR(lv_oparam, 1, INSTR(lv_oparam, ';', 1, 1) - 1);
          lv_oparam := SUBSTR(lv_oparam, INSTR(lv_oparam, ';', 1, 1) + 1);
          lv_value  := TO_NUMBER(SUBSTR(lv_oparam,
                                        1,
                                        INSTR(lv_oparam, ';', 1, 1) - 1));
          lv_oparam := SUBSTR(lv_oparam, INSTR(lv_oparam, ';', 1, 1) + 1);
          --dbms_output.put_line(lv_token || ' - '||lv_value);
          IF to_opr_charges.COUNT > 0 THEN
            FOR i IN to_opr_charges.FIRST .. to_opr_charges.LAST LOOP
              IF to_opr_charges(i).charge_type = lv_token AND to_opr_charges(i)
                 .opr_srl = ln_opr_srl THEN
                to_opr_charges(i).charge_amt := ROUND(lv_value, 2);
                lv_opr_chg_amt := NVL(lv_opr_chg_amt, 0) +
                                  ROUND(NVL(lv_value, 0), 2);
              END IF;
            END LOOP;
          END IF;
          EXIT WHEN lv_oparam IS NULL;
        END LOOP;
        UPDATE gbl_amc_dtl
           SET charge_amt = lv_opr_chg_amt,
               net_value  = NVL(tot_value, 0) + NVL(lv_opr_chg_amt, 0)
         WHERE parent_group = lv_parent
           AND dealer_map_cd = lv_dealer
           AND loc_cd = lv_loc
           AND comp_fa = lv_comp
           AND pkg_code = p_amc_num
           AND srl_num = cur_l.srl_num
           AND srv_type = cur_l.srv_type
           AND srv_cd = cur_l.srv_cd;
      END LOOP;
      -- Insert Labour Charges
      FOR i IN 1 .. to_opr_charges.COUNT LOOP
        IF to_opr_charges(i).opr_cd IS NOT NULL /*AND
                                                                  NVL(to_opr_charges(i).charge_amt, 0) > 0*/
         THEN
          INSERT INTO gbl_amc_charges
            (parent_group,
             dealer_map_cd,
             loc_cd,
             comp_fa,
             pkg_code,
             srl_num,
             srv_type,
             srv_cd,
             charge_srl,
             common_ind,
             order_srl,
             charge_cd,
             charge_type,
             charge_ind,
             charge_value,
             charge_amt)
          VALUES
            (lv_parent,
             lv_dealer,
             lv_loc,
             lv_comp,
             p_amc_num,
             to_opr_charges(i).opr_srl,
             to_opr_charges(i).srv_type,
             to_opr_charges(i).opr_cd,
             to_opr_charges(i).charge_srl,
             to_opr_charges(i).common_ind,
             to_opr_charges(i).order_srl,
             to_opr_charges(i).charge_cd,
             to_opr_charges(i).charge_type,
             to_opr_charges(i).charge_ind,
             to_opr_charges(i).charge_value,
             to_opr_charges(i).charge_amt);
        END IF;
      END LOOP;

      -- Calculate Part Charges
      lc_cus_chg_cnt := 1;
      ln_pchg_srl    := ln_chg_srl;
      FOR cur_p IN cur_part(lv_parent,
                            lv_dealer,
                            lv_loc,
                            lv_comp,
                            p_amc_num) LOOP
        UPDATE gbl_amc_dtl
           SET charge_amt = lv_part_chg_amt,
               net_value  = NVL(tot_value, 0) + NVL(lv_part_chg_amt, 0)
         WHERE parent_group = lv_parent
           AND dealer_map_cd = lv_dealer
           AND loc_cd = lv_loc
           AND comp_fa = lv_comp
           AND pkg_code = p_amc_num
           AND srl_num = cur_p.srl_num
           AND srv_type = cur_p.srv_type
           AND srv_cd = cur_p.srv_cd;
      END LOOP;

    END IF;
    COMMIT;
  END sp_pop_cancel_dtl;
```

#### SP-023 - PKG_FDI.SF_VALID_DEALER

**Invoked From:**

- PKG_FDI.pck [StoredProcedure: PKG_FDI.SP_PUSH_FDI_TRANSACTIONS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Validates whether a given dealer location is configured for financial data interface (FDI) integration by checking the `AM_DEALER_LOC_PARAM` table. Returns "Y" if the dealer/location combination is FDI-enabled, "N" otherwise.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_PARENT_GROUP | VARCHAR2 | IN |
| P_DEALER_MAP_CD | NUMBER | IN |
| P_LOC_CD | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Query `AM_DEALER_LOC_PARAM` for a record matching the supplied parent group, dealer map code, and location code where `fin_data_yn = "Y"`.
- Step 2 - If a matching record is found, return "Y" (FDI-enabled).
- Step 3 - If no matching record or any exception, return "N" (not FDI-enabled).

---
**Decision Points**

DP-001

Condition:
A record in `AM_DEALER_LOC_PARAM` exists with `fin_data_yn = "Y"` for the dealer/location.

TRUE:
Return "Y" - dealer is FDI-enabled.

FALSE:
Return "N" - dealer is not FDI-enabled (exception suppressed).

---
**Database Interactions**

- DB-001 - Read AM_DEALER_LOC_PARAM - Reads data from AM_DEALER_LOC_PARAM for lookup or validation.
**Business Rules**

BR-001 - Only dealers with `fin_data_yn = "Y"` in `AM_DEALER_LOC_PARAM` are eligible for FDI transaction pushing; all others are silently bypassed.

---
**Implementation Logic**

```plsql
  FUNCTION SF_VALID_DEALER(P_PARENT_GROUP  IN VARCHAR2,
                           P_DEALER_MAP_CD IN NUMBER,
                           P_LOC_CD        IN VARCHAR2) RETURN VARCHAR2 IS
    lv_check VARCHAR2(1);
  BEGIN
    BEGIN
      select 'Y'
        into lv_check
        from am_dealer_loc_param
       where PARENT_GROUP = P_PARENT_GROUP
         and DEALER_MAP_CD = P_DEALER_MAP_CD
         and LOC_CD = P_LOC_CD
         and nvl(fin_data_yn, 'N') = 'Y';
    EXCEPTION
      WHEN OTHERS THEN
        lv_check := 'N';
    END;
    return lv_check;
  END SF_VALID_DEALER;
```

#### SP-024 - PKG_FDI.SP_PUSH_FDI_TRANSACTIONS

**Invoked From:**

- SP_PUSH_MCPC_FDI_DATA.prc [StoredProcedure: SP_PUSH_MCPC_FDI_DATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Pushes a financial data interface (FDI) transaction to the external FDI system for a given dealer and transaction type. It validates FDI eligibility, builds a structured FDI transaction record with all required financial details, and calls the FDI service to submit the data, returning a success or error status.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_PARENT_GROUP | VARCHAR2 | IN |
| P_DEALER_MAP_CD | NUMBER | IN |
| P_LOC_CD | VARCHAR2 | IN |
| P_COMP_FA | VARCHAR2 | IN |
| P_TRANS_TYPE | VARCHAR2 | IN |
| P_TRANS_DATE | DATE | IN |
| P_TRANS_ID | VARCHAR2 | IN |
| P_TRANS_REF_NO | VARCHAR2 | IN |
| P_TRANS_REF_DATE | DATE | IN |
| P_TRANS_QTY | NUMBER | IN |
| P_TRANS_SEGMENT | VARCHAR2 | IN |
| P_VIN | VARCHAR2 | IN |
| P_ENGINE_NUM | VARCHAR2 | IN |
| P_CHASSIS_NUM | VARCHAR2 | IN |
| P_MODEL_CD | VARCHAR2 | IN |
| P_VARIANT_CD | VARCHAR2 | IN |
| P_ECOLOR_CD | VARCHAR2 | IN |
| P_BASIC_PRICE | NUMBER | IN |
| P_DISCOUNT | NUMBER | IN |
| P_TAXABLE_VALUE | NUMBER | IN |
| P_SERVICE_AMOUNT | NUMBER | IN |
| P_GST_NO | VARCHAR2 | IN |
| P_PLACE_OF_SUPPLY | VARCHAR2 | IN |
| P_HSN_NO | VARCHAR2 | IN |
| P_EXECUTIVE | VARCHAR2 | IN |
| P_TEAM_HEAD | VARCHAR2 | IN |
| P_FINC_NAME | VARCHAR2 | IN |
| P_PAYMENT_MODE | VARCHAR2 | IN |
| P_DEPOSIT_BANK | VARCHAR2 | IN |
| P_PAYMENT_FOR | VARCHAR2 | IN |
| P_INV_TYPE | VARCHAR2 | IN |
| P_GE1 | VARCHAR2 | IN |
| P_GE2 | VARCHAR2 | IN |
| P_GE3 | VARCHAR2 | IN |
| P_GE4 | VARCHAR2 | IN |
| P_GE5 | VARCHAR2 | IN |
| P_GE6 | VARCHAR2 | IN |
| P_GE7 | VARCHAR2 | IN |
| P_GE8 | VARCHAR2 | IN |
| P_GE9 | VARCHAR2 | IN |
| P_GE10 | VARCHAR2 | IN |
| P_GE11 | VARCHAR2 | IN |
| P_GE12 | VARCHAR2 | IN |
| P_GE13 | VARCHAR2 | IN |
| P_GE14 | VARCHAR2 | IN |
| P_GE15 | VARCHAR2 | IN |
| P_CUST_ID | VARCHAR2 | IN |
| P_SALUTATION | VARCHAR2 | IN |
| P_CUST_NAME | VARCHAR2 | IN |
| P_GENDER | VARCHAR2 | IN |
| P_MARITAL_STATUS | VARCHAR2 | IN |
| P_COMMUNICATE_TO | VARCHAR2 | IN |
| P_RES_ADDRESS1 | VARCHAR2 | IN |
| P_RES_ADDRESS2 | VARCHAR2 | IN |
| P_RES_ADDRESS3 | VARCHAR2 | IN |
| P_RES_PIN_CD | VARCHAR2 | IN |
| P_RES_CITY | VARCHAR2 | IN |
| P_RES_PHONE | VARCHAR2 | IN |
| P_OFF_ADDRESS1 | VARCHAR2 | IN |
| P_OFF_ADDRESS2 | VARCHAR2 | IN |
| P_OFF_ADDRESS3 | VARCHAR2 | IN |
| P_OFF_PIN_CD | VARCHAR2 | IN |
| P_OFF_CITY | VARCHAR2 | IN |
| P_OFF_PHONE | VARCHAR2 | IN |
| P_MOBILE1 | VARCHAR2 | IN |
| P_MOBILE2 | VARCHAR2 | IN |
| P_EMAIL_ID | VARCHAR2 | IN |
| P_PAN_NO | VARCHAR2 | IN |
| P_STATE | VARCHAR2 | IN |
| P_DISTRICT | VARCHAR2 | IN |
| P_TEHSIL | VARCHAR2 | IN |
| P_VILLAGE | VARCHAR2 | IN |
| P_GST_NUM | VARCHAR2 | IN |
| P_TIN | VARCHAR2 | IN |
| P_UIN | VARCHAR2 | IN |
| P_DOB | DATE | IN |
| P_DOA | DATE | IN |
| P_SHIP_ADDRESS1 | VARCHAR2 | IN |
| P_SHIP_ADDRESS2 | VARCHAR2 | IN |
| P_SHIP_ADDRESS3 | VARCHAR2 | IN |
| P_SHIP_PIN_CD | VARCHAR2 | IN |
| P_SHIP_CITY | VARCHAR2 | IN |
| P_SHIP_STATE | VARCHAR2 | IN |
| P_SHIP_FULL_NAME | VARCHAR2 | IN |
| P_SHIP_PAN | VARCHAR2 | IN |
| P_SHIP_GST_NUM | VARCHAR2 | IN |
| P_SHIP_UIN | VARCHAR2 | IN |
| P_FDI_CHARGES_TAB | PKG_FDI.FDI_CHARGES | IN |
| P_CREATED_BY | VARCHAR2 | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_ERR_CD | NUMBER | OUT |
| P_ERR_MSG | VARCHAR2 | OUT |

---

**Dependencies**

- D2KWUTIL.CREATED_DATE ([SP-007](#SP-007--D2KWUTIL.CREATED_DATE)) - D2KWUTIL.pck (or .pld)
- PKG_FDI.SF_VALID_DEALER ([SP-023](#SP-023--PKG_FDI.SF_VALID_DEALER)) - PKG_FDI.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Validate that the dealer/location is FDI-enabled by calling `SF_VALID_DEALER`; if not enabled, return immediately with no error.
- Step 2 - Retrieve all required financial data for the transaction (amounts, tax details, customer information, vehicle details) from the relevant tables.
- Step 3 - Build the FDI transaction payload structure with all required fields.
- Step 4 - Call the FDI service API/procedure to submit the transaction.
- Step 5 - Capture and return the error code and message from the FDI service call.

---
**Decision Points**

DP-001

Condition:
Dealer/location combination has FDI enabled (`SF_VALID_DEALER` returns "Y").

TRUE:
Proceed to build and submit the FDI transaction.

FALSE:
Return without action - dealer is not FDI-enabled; no error is raised.

---
**Database Interactions**

- DB-001 - Read AM_DEALER_LOC - Reads data from AM_DEALER_LOC for lookup or validation.
- DB-002 - Read SYS.DUAL - Reads data from SYS.DUAL for lookup or validation.
- DB-003 - Insert into MULDMS.GD_FDI_TRANS - Persists a new row into MULDMS.GD_FDI_TRANS using columns: utd, parent group, dealer map cd, loc cd, comp fa, mul dealer cd, dealer for cd, outlet cd, and 47 more column(s).
- DB-004 - Insert into GD_FDI_TRANS_CHARGES - Persists a new row into GD_FDI_TRANS_CHARGES using columns: utd, parent group, dealer map cd, loc cd, comp fa, mul dealer cd, dealer for cd, outlet cd, and 10 more column(s).
- DB-005 - Insert into GD_FDI_TRANS_CUSTOMER - Persists a new row into GD_FDI_TRANS_CUSTOMER using columns: utd, parent group, dealer map cd, loc cd, comp fa, mul dealer cd, dealer for cd, outlet cd, and 43 more column(s).
**Business Rules**

BR-001 - FDI transaction submission is only attempted for FDI-enabled dealers; non-FDI dealers are silently bypassed.
BR-002 - The error code and message from the FDI system are always returned to the caller; the caller decides whether to display the error or suppress it.

---
**Implementation Logic**

```plsql
  PROCEDURE SP_PUSH_FDI_TRANSACTIONS(P_PARENT_GROUP    IN VARCHAR2,
                                     P_DEALER_MAP_CD   IN NUMBER,
                                     P_LOC_CD          IN VARCHAR2,
                                     P_COMP_FA         IN VARCHAR2,
                                     P_TRANS_TYPE      IN VARCHAR2,
                                     P_TRANS_DATE      IN DATE,
                                     P_TRANS_ID        IN VARCHAR2,
                                     P_TRANS_REF_NO    IN VARCHAR2,
                                     P_TRANS_REF_DATE  IN DATE,
                                     P_TRANS_QTY       IN NUMBER,
                                     P_TRANS_SEGMENT   IN VARCHAR2,
                                     P_VIN             IN VARCHAR2,
                                     P_ENGINE_NUM      IN VARCHAR2,
                                     P_CHASSIS_NUM     IN VARCHAR2,
                                     P_MODEL_CD        IN VARCHAR2,
                                     P_VARIANT_CD      IN VARCHAR2,
                                     P_ECOLOR_CD       IN VARCHAR2,
                                     P_BASIC_PRICE     IN NUMBER,
                                     P_DISCOUNT        IN NUMBER,
                                     P_TAXABLE_VALUE   IN NUMBER,
                                     P_SERVICE_AMOUNT  IN NUMBER,
                                     P_GST_NO          IN VARCHAR2,
                                     P_PLACE_OF_SUPPLY IN VARCHAR2,
                                     P_HSN_NO          IN VARCHAR2,
                                     P_EXECUTIVE       IN VARCHAR2,
                                     P_TEAM_HEAD       IN VARCHAR2,
                                     P_FINC_NAME       IN VARCHAR2,
                                     P_PAYMENT_MODE    IN VARCHAR2,
                                     P_DEPOSIT_BANK    IN VARCHAR2,
                                     P_PAYMENT_FOR     IN VARCHAR2,
                                     P_INV_TYPE        IN VARCHAR2,
                                     P_GE1             IN VARCHAR2,
                                     P_GE2             IN VARCHAR2,
                                     P_GE3             IN VARCHAR2,
                                     P_GE4             IN VARCHAR2,
                                     P_GE5             IN VARCHAR2,
                                     P_GE6             IN VARCHAR2,
                                     P_GE7             IN VARCHAR2,
                                     P_GE8             IN VARCHAR2,
                                     P_GE9             IN VARCHAR2,
                                     P_GE10            IN VARCHAR2,
                                     P_GE11            IN VARCHAR2,
                                     P_GE12            IN VARCHAR2,
                                     P_GE13            IN VARCHAR2,
                                     P_GE14            IN VARCHAR2,
                                     P_GE15            IN VARCHAR2,
                                     P_CUST_ID         IN VARCHAR2,
                                     P_SALUTATION      IN VARCHAR2,
                                     P_CUST_NAME       IN VARCHAR2,
                                     P_GENDER          IN VARCHAR2,
                                     P_MARITAL_STATUS  IN VARCHAR2,
                                     P_COMMUNICATE_TO  IN VARCHAR2,
                                     P_RES_ADDRESS1    IN VARCHAR2,
                                     P_RES_ADDRESS2    IN VARCHAR2,
                                     P_RES_ADDRESS3    IN VARCHAR2,
                                     P_RES_PIN_CD      IN VARCHAR2,
                                     P_RES_CITY        IN VARCHAR2,
                                     P_RES_PHONE       IN VARCHAR2,
                                     P_OFF_ADDRESS1    IN VARCHAR2,
                                     P_OFF_ADDRESS2    IN VARCHAR2,
                                     P_OFF_ADDRESS3    IN VARCHAR2,
                                     P_OFF_PIN_CD      IN VARCHAR2,
                                     P_OFF_CITY        IN VARCHAR2,
                                     P_OFF_PHONE       IN VARCHAR2,
                                     P_MOBILE1         IN VARCHAR2,
                                     P_MOBILE2         IN VARCHAR2,
                                     P_EMAIL_ID        IN VARCHAR2,
                                     P_PAN_NO          IN VARCHAR2,
                                     P_STATE           IN VARCHAR2,
                                     P_DISTRICT        IN VARCHAR2,
                                     P_TEHSIL          IN VARCHAR2,
                                     P_VILLAGE         IN VARCHAR2,
                                     P_GST_NUM         IN VARCHAR2,
                                     P_TIN             IN VARCHAR2,
                                     P_UIN             IN VARCHAR2,
                                     P_DOB             IN DATE,
                                     P_DOA             IN DATE,
                                     P_SHIP_ADDRESS1   IN VARCHAR2,
                                     P_SHIP_ADDRESS2   IN VARCHAR2,
                                     P_SHIP_ADDRESS3   IN VARCHAR2,
                                     P_SHIP_PIN_CD     IN VARCHAR2,
                                     P_SHIP_CITY       IN VARCHAR2,
                                     P_SHIP_STATE      IN VARCHAR2,
                                     P_SHIP_FULL_NAME  IN VARCHAR2,
                                     P_SHIP_PAN        IN VARCHAR2,
                                     P_SHIP_GST_NUM    IN VARCHAR2,
                                     P_SHIP_UIN        IN VARCHAR2,
                                     P_FDI_CHARGES_TAB IN PKG_FDI.FDI_CHARGES,
                                     P_CREATED_BY      IN VARCHAR2,
                                     P_ERR_CD          OUT NUMBER,
                                     P_ERR_MSG         OUT VARCHAR2) IS

    LV_MUL_DEALER_CD   AM_DEALER_LOC.MUL_DEALER_CD%TYPE;
    LV_DEALER_FOR_CD   GM_FOR.FOR_CD%TYPE;
    LV_OUTLET_CD       AM_DEALER_LOC.OUTLET_CD%TYPE;
    LV_PLACE_OF_SUPPLY GD_FDI_TRANS.PLACE_OF_SUPPLY%TYPE;
    LV_PMC             AM_DEALER_LOC.PRINCIPAL_MAP_CD%TYPE;
    LV_UTD             GD_FDI_TRANS.UTD%TYPE;
  BEGIN

    P_ERR_CD := 0;

    IF PKG_FDI.SF_VALID_DEALER(P_PARENT_GROUP, P_DEALER_MAP_CD, P_LOC_CD) = 'Y' THEN

      SELECT AM.FOR_CD,
             AM.STATE_CD,
             AM.PRINCIPAL_MAP_CD,
             AM.MUL_DEALER_CD,
             AM.OUTLET_CD
        INTO LV_DEALER_FOR_CD,
             LV_PLACE_OF_SUPPLY,
             LV_PMC,
             LV_MUL_DEALER_CD,
             LV_OUTLET_CD
        FROM AM_DEALER_LOC AM, GM_FOR FR
       WHERE AM.PARENT_GROUP = P_PARENT_GROUP
         AND AM.DEALER_MAP_CD = P_DEALER_MAP_CD
         AND AM.LOC_CD = P_LOC_CD
         AND AM.FOR_CD = FR.FOR_CD
         AND AM.PRINCIPAL_MAP_CD = FR.PRINCIPAL_MAP_CD;

      SELECT MULDMS.FDI_TRANS_SEQ.NEXTVAL INTO LV_UTD FROM SYS.DUAL;

      INSERT INTO MULDMS.GD_FDI_TRANS
        (UTD,
         PARENT_GROUP,
         DEALER_MAP_CD,
         LOC_CD,
         COMP_FA,
         MUL_DEALER_CD,
         DEALER_FOR_CD,
         OUTLET_CD,
         TRANS_TYPE,
         TRANS_DATE,
         TRANS_ID,
         TRANS_REF_NUM,
         TRANS_REF_DATE,
         TRANS_QTY,
         TRANS_SEGMENT,
         VIN,
         ENGINE_NUM,
         CHASSIS_NUM,
         MODEL_CD,
         VARIANT_CD,
         ECOLOR_CD,
         BASIC_PRICE,
         DISCOUNT,
         TAXABLE_VALUE,
         SERVICE_AMOUNT,
         GST_NO,
         PLACE_OF_SUPPLY,
         HSN_NO,
         CUST_ID,
         CUST_NAME,
         EXECUTIVE,
         TEAM_HEAD,
         FINC_NAME,
         PAYMENT_MODE,
         DEPOSIT_BANK,
         PAYMENT_FOR,
         GE1,
         GE2,
         GE3,
         GE4,
         GE5,
         GE6,
         GE7,
         GE8,
         GE9,
         GE10,
         GE11,
         GE12,
         GE13,
         GE14,
         GE15,
         BATCH_PICK_FLAG,
         BATCH_PICK_DATE,
         CREATED_BY,
         CREATED_DATE)
      VALUES
        (LV_UTD,
         P_PARENT_GROUP,
         P_DEALER_MAP_CD,
         P_LOC_CD,
         P_COMP_FA,
         LV_MUL_DEALER_CD,
         LV_DEALER_FOR_CD,
         LV_OUTLET_CD,
         P_TRANS_TYPE,
         P_TRANS_DATE,
         P_TRANS_ID,
         P_TRANS_REF_NO,
         P_TRANS_REF_DATE,
         P_TRANS_QTY,
         P_TRANS_SEGMENT,
         P_VIN,
         P_ENGINE_NUM,
         P_CHASSIS_NUM,
         P_MODEL_CD,
         P_VARIANT_CD,
         P_ECOLOR_CD,
         P_BASIC_PRICE,
         P_DISCOUNT,
         P_TAXABLE_VALUE,
         P_SERVICE_AMOUNT,
         P_GST_NO,
         P_PLACE_OF_SUPPLY, --NVL(P_PLACE_OF_SUPPLY, LV_PLACE_OF_SUPPLY),
         P_HSN_NO,
         P_CUST_ID,
         P_CUST_NAME,
         P_EXECUTIVE,
         P_TEAM_HEAD,
         P_FINC_NAME,
         P_PAYMENT_MODE,
         P_DEPOSIT_BANK,
         P_PAYMENT_FOR,
         P_GE1,
         P_GE2,
         P_GE3,
         P_GE4,
         NVL(P_GE5, P_INV_TYPE),
         P_GE6,
         P_GE7,
         P_GE8,
         P_GE9,
         P_GE10,
         P_GE11,
         P_GE12,
         P_GE13,
         P_GE14,
         P_GE15,
         'N',
         NULL,
         P_CREATED_BY,
         SYSDATE);

      IF P_FDI_CHARGES_TAB.COUNT <> 0 THEN
        FOR X IN 1 .. P_FDI_CHARGES_TAB.COUNT LOOP
          INSERT INTO GD_FDI_TRANS_CHARGES
            (UTD,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             COMP_FA,
             MUL_DEALER_CD,
             DEALER_FOR_CD,
             OUTLET_CD,
             HSN_NO,
             CHARGE_CD,
             CHARGE_TYPE,
             CHARGE_DESC,
             CHARGE_RATE,
             CHARGE_AMT,
             MSIL_SHARE,
             DLR_SHARE,
             CREATED_BY,
             CREATED_DATE)
          VALUES
            (LV_UTD,
             P_PARENT_GROUP,
             P_DEALER_MAP_CD,
             P_LOC_CD,
             P_COMP_FA,
             LV_MUL_DEALER_CD,
             LV_DEALER_FOR_CD,
             LV_OUTLET_CD,
             P_HSN_NO,
             P_FDI_CHARGES_TAB(X).CHARGE_CD,
             P_FDI_CHARGES_TAB(X).CHARGE_TYPE,
             P_FDI_CHARGES_TAB(X).CHARGE_DESC,
             P_FDI_CHARGES_TAB(X).CHARGE_RATE,
             P_FDI_CHARGES_TAB(X).CHARGE_AMT,
             P_FDI_CHARGES_TAB(X).MSIL_SHARE,
             P_FDI_CHARGES_TAB(X).DLR_SHARE,
             P_CREATED_BY,
             SYSDATE);
        END LOOP;
      END IF;

      IF P_CUST_ID IS NOT NULL OR P_CUST_NAME IS NOT NULL THEN
        INSERT INTO GD_FDI_TRANS_CUSTOMER
          (UTD,
           PARENT_GROUP,
           DEALER_MAP_CD,
           LOC_CD,
           COMP_FA,
           MUL_DEALER_CD,
           DEALER_FOR_CD,
           OUTLET_CD,
           CUST_ID,
           SALUTATION,
           CUST_NAME,
           GENDER,
           MARITAL_STATUS,
           COMMUNICATE_TO,
           RES_ADDRESS1,
           RES_ADDRESS2,
           RES_ADDRESS3,
           RES_PIN_CD,
           RES_CITY,
           RES_PHONE,
           OFF_ADDRESS1,
           OFF_ADDRESS2,
           OFF_ADDRESS3,
           OFF_PIN_CD,
           OFF_CITY,
           OFF_PHONE,
           MOBILE1,
           MOBILE2,
           EMAIL_ID,
           PAN_NO,
           STATE,
           DISTRICT,
           TEHSIL,
           VILLAGE,
           GST_NUM,
           TIN,
           UIN,
           DOB,
           DOA,
           SHIP_ADDRESS1,
           SHIP_ADDRESS2,
           SHIP_ADDRESS3,
           SHIP_PIN_CD,
           SHIP_CITY,
           SHIP_STATE,
           SHIP_FULL_NAME,
           SHIP_PAN,
           SHIP_GST_NUM,
           SHIP_UIN,
           CREATED_BY,
           CREATED_DATE)
        VALUES
          (LV_UTD,
           P_PARENT_GROUP,
           P_DEALER_MAP_CD,
           P_LOC_CD,
           P_COMP_FA,
           LV_MUL_DEALER_CD,
           LV_DEALER_FOR_CD,
           LV_OUTLET_CD,
           P_CUST_ID,
           P_SALUTATION,
           P_CUST_NAME,
           P_GENDER,
           P_MARITAL_STATUS,
           P_COMMUNICATE_TO,
           P_RES_ADDRESS1,
           P_RES_ADDRESS2,
           P_RES_ADDRESS3,
           P_RES_PIN_CD,
           P_RES_CITY,
           P_RES_PHONE,
           P_OFF_ADDRESS1,
           P_OFF_ADDRESS2,
           P_OFF_ADDRESS3,
           P_OFF_PIN_CD,
           P_OFF_CITY,
           P_OFF_PHONE,
           P_MOBILE1,
           P_MOBILE2,
           P_EMAIL_ID,
           P_PAN_NO,
           P_STATE,
           P_DISTRICT,
           P_TEHSIL,
           P_VILLAGE,
           P_GST_NUM,
           P_TIN,
           P_UIN,
           P_DOB,
           P_DOA,
           P_SHIP_ADDRESS1,
           P_SHIP_ADDRESS2,
           P_SHIP_ADDRESS3,
           P_SHIP_PIN_CD,
           P_SHIP_CITY,
           P_SHIP_STATE,
           P_SHIP_FULL_NAME,
           P_SHIP_PAN,
           P_SHIP_GST_NUM,
           P_SHIP_UIN,
           P_CREATED_BY,
           SYSDATE);
      END IF;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      P_ERR_CD  := 1;
      P_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
  END SP_PUSH_FDI_TRANSACTIONS;
```

#### SP-025 - PKG_LOYALTY.SF_CALCULATE_POINTS_TO_RUPEES

**Invoked From:**

- PKG_LOYALTY.pck [StoredProcedure: PKG_LOYALTY.SP_GET_VIN_LOYALTY_DTL]
- PKG_LOYALTY.pck [StoredProcedure: PKG_LOYALTY.SP_INS_LOYALTY_TRANSACTIONS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Converts a loyalty points balance to its monetary (rupee) equivalent by looking up the current points-to-rupees conversion rate for the given card type, channel, tier, and transaction date, and multiplying the points amount by the applicable rate.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_trans_date | varchar2 | IN |
| p_card_type | varchar2 | IN |
| p_channel | varchar2 | IN |
| p_tier | varchar2 | IN |
| p_points | number | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Look up the conversion rate from the loyalty rate master table based on the transaction date, card type, channel, and tier.
- Step 2 - Multiply the supplied points amount by the retrieved conversion rate to calculate the rupee value.
- Step 3 - Return the computed rupee value.

---
**Decision Points**

No branching decision points identified in the implementation logic.

---
**Database Interactions**

- DB-001 - Read GM_LOYALTY_MASTER - Reads data from GM_LOYALTY_MASTER for lookup or validation.
**Business Rules**

BR-001 - The conversion rate is date-sensitive; the transaction date determines which rate configuration is applicable.
BR-002 - The conversion is specific to the combination of card type, channel, and tier - different loyalty programme tiers may have different conversion rates.

---
**Implementation Logic**

```plsql
  FUNCTION sf_calculate_points_to_rupees(p_trans_date in varchar2, --'DD-MM-YYYY HH24:MI:SS'
                                         p_card_type  in varchar2,
                                         p_channel    in varchar2,
                                         p_tier       in varchar2,
                                         p_points     in number)
    return number is
    lv_rupees number;
  BEGIN
    SELECT p_points * value_per_point
      INTO lv_rupees
      FROM gm_loyalty_master
     WHERE card_type = p_card_type
       AND channel = p_channel
       AND tier = p_tier
       AND trunc(to_date(p_trans_date, 'DD-MM-YYYY HH24:MI:SS')) between
           start_date and
           nvl(end_date,
               trunc(to_date(p_trans_date, 'DD-MM-YYYY HH24:MI:SS')));
    return lv_rupees;
  END sf_calculate_points_to_rupees;
```

#### SP-026 - PKG_LOYALTY.SF_CALCULATE_RUPEES_TO_POINTS

**Invoked From:**

- PKG_LOYALTY.pck [StoredProcedure: PKG_LOYALTY.SP_INS_LOYALTY_TRANSACTIONS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Converts a monetary (rupee) amount to loyalty points by looking up the current rupees-to-points conversion rate for the given card type, channel, tier, and transaction date, and dividing/multiplying to compute the equivalent points.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_trans_date | varchar2 | IN |
| p_card_type | varchar2 | IN |
| p_channel | varchar2 | IN |
| p_tier | varchar2 | IN |
| p_rupees | number | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Look up the conversion rate from the loyalty rate master table based on the transaction date, card type, channel, and tier.
- Step 2 - Convert the supplied rupee amount to points using the retrieved rate.
- Step 3 - Return the computed points value.

---
**Decision Points**

No branching decision points identified in the implementation logic.

---
**Database Interactions**

- DB-001 - Read GM_LOYALTY_MASTER - Reads data from GM_LOYALTY_MASTER for lookup or validation.
**Business Rules**

BR-001 - The conversion rate is date-sensitive; the transaction date determines which rate configuration is applicable.
BR-002 - The points-per-rupee rate varies by card type, channel, and tier.

---
**Implementation Logic**

```plsql
  FUNCTION sf_calculate_rupees_to_points(p_trans_date in varchar2, --'DD-MM-YYYY HH24:MI:SS'
                                         p_card_type  in varchar2,
                                         p_channel    in varchar2,
                                         p_tier       in varchar2,
                                         p_rupees     in number)
    return number is
    lv_points number;

  BEGIN
    SELECT --trunc(p_rupees / trans_points_rs)  -- commented by veeresh on 29th April 2024 dms-1868
        -- * total_share --p_rupees / value_per_point
    trunc((p_rupees*AWRD_PER)/100)  -- added by veeresh on 29 april 2024 dms-1868
      INTO lv_points
      FROM gm_loyalty_master
     WHERE card_type = p_card_type
       AND channel = p_channel
       AND tier = p_tier
       AND trunc(to_date(p_trans_date, 'DD-MM-YYYY HH24:MI:SS')) between
           start_date and
           nvl(end_date,
               trunc(to_date(p_trans_date, 'DD-MM-YYYY HH24:MI:SS')));
    return lv_points;

  END sf_calculate_rupees_to_points;
```

#### SP-027 - PKG_LOYALTY.SP_CALCULATE_BAL_POINTS

**Invoked From:**

- PKG_LOYALTY.pck [StoredProcedure: PKG_LOYALTY.SP_INS_LOYALTY_TRANSACTIONS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Calculates the current loyalty points balance for a specified loyalty card by reading the enrollment record's starting balance, summing all debit and credit transactions up to the most recent financial year boundary, and applying the current financial year's transactions to compute the live balance.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_card_num | varchar2 | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_bal_points | number | OUT |
| p_error_cd | number | OUT |
| p_error_msg | varchar2 | OUT |

---

**Dependencies**

- D2KWUTIL.MODIFIED_DATE ([SP-011](#SP-011--D2KWUTIL.MODIFIED_DATE)) - D2KWUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Retrieve the loyalty enrollment details (card type, financial year balance, enrollment date) from `GD_LOYALTY_ENROL`.
- Step 2 - Query all loyalty transactions for the card to compute the net transaction balance (credits minus debits) for the current period.
- Step 3 - Calculate the running balance: starting balance plus net transactions.
- Step 4 - Return the computed balance points.
- Step 5 - On any exception, return an error code and message.

---
**Decision Points**

DP-001

Condition:
Loyalty enrollment record exists for the card number.

TRUE:
Compute the balance from enrollment balance plus transaction history.

FALSE:
Return an error code indicating no enrollment found.

---
**Database Interactions**

- DB-001 - Read GD_LOYALTY_TRANS - Reads data from GD_LOYALTY_TRANS for lookup or validation.
- DB-002 - Update GD_LOYALTY_ENROL - Updates existing rows in GD_LOYALTY_ENROL (columns: bal point, modified date).
- DB-003 - Read GD_LOYALTY_PT_SUMM - Reads data from GD_LOYALTY_PT_SUMM (columns: card num, bal points, updated date, fin year) for lookup or validation.
- DB-004 - Update GD_LOYALTY_PT_SUMM - Updates existing rows in GD_LOYALTY_PT_SUMM (columns: card num, bal points, updated date, fin year).
- DB-005 - Insert into GD_LOYALTY_PT_SUMM - Persists a new row into GD_LOYALTY_PT_SUMM using columns: card num, bal points, updated date, fin year.
- DB-006 - Read GD_LOYALTY_ENROL - Reads data from GD_LOYALTY_ENROL (columns: bal point, modified date) for lookup or validation.
- DB-007 - Read GM_LOYALTY_MASTER - Reads data from GM_LOYALTY_MASTER for lookup or validation.
- DB-008 - Read FM_COMPANY - Reads data from FM_COMPANY for lookup or validation.
**Business Rules**

BR-001 - The current balance is the sum of the enrollment opening balance and all subsequent credit/debit transactions.
BR-002 - On failure to find the enrollment or compute the balance, a non-zero error code and descriptive message are returned.

---
**Implementation Logic**

```plsql
  PROCEDURE sp_calculate_bal_points(p_card_num   in varchar2,
                                    p_bal_points out number,
                                    p_error_cd   out number,
                                    p_error_msg  out varchar2) IS
    lv_card_type       gd_loyalty_enrol.card_type%type;
    lv_bal_points_fnyr gd_loyalty_enrol.bal_point%type;
    lv_enrollment_date gd_loyalty_enrol.enrollment_date%type;
    lv_bal_points      gd_loyalty_enrol.bal_point%type;
    lv_check           number;
    lv_card_num        gd_loyalty_enrol.card_num%type;
  BEGIN
    p_error_cd := 0;
    /*sp_get_card_num(p_mobile_no,
                    p_card_type,
                    lv_card_num,
                    p_error_cd,
                    p_error_msg);

    IF p_error_cd <> 0 THEN
      return;
    END IF;*/

    BEGIN
      Select nvl(sum(balance_points),0)
        into p_bal_points
        from gd_loyalty_trans
       where card_num = p_card_num
         AND nvl(expired, 'N') = 'N';

      UPDATE gd_loyalty_enrol
         SET bal_point = p_bal_points
            ,modified_date = sysdate  --Added by saket as on 27-10-2021
       WHERE card_num = p_card_num;

      /*BEGIN
        SELECT 1
          INTO lv_check
          FROM gd_loyalty_pt_summ
         WHERE card_num = lv_card_num;

        UPDATE gd_loyalty_pt_summ
           SET bal_points = lv_bal_points, updated_date = sysdate
         WHERE card_num = lv_card_num;

      EXCEPTION
        WHEN no_data_found THEN
          INSERT INTO gd_loyalty_pt_summ
            (card_num, bal_points, updated_date, fin_year)
          VALUES
            (lv_card_num, lv_bal_points, sysdate, null);
      END;*/

    END;

    /*
        SELECT enrollment_date
          INTO lv_enrollment_date
          FROM gd_loyalty_enrol
         WHERE card_num = lv_card_num;

        IF p_error_cd = 0 THEN
          select nvl(SUM(credit_pts), 0) - nvl(sum(debit_pts), 0)
            INTO p_bal_points
            from (SELECT credit_pts,
                         debit_pts,
                         (SELECT value_per_point
                            FROM gm_loyalty_master
                           WHERE CARD_TYPE = lv_card_type
                             AND trans_date BETWEEN start_date AND
                                 nvl(end_date, trans_date)) value_per_point
                    FROM gd_loyalty_trans
                   WHERE card_num = lv_card_num);
          UPDATE gd_loyalty_enrol
             SET bal_point = p_bal_points
           WHERE card_num = lv_card_num;

          lv_bal_points := 0;
          FOR rec IN (SELECT DISTINCT fin_beg, fin_end, fin_year fnyr
                        FROM fm_company
                       WHERE parent_group = '99999'
                         AND loc_cd = '999'
                         AND dealer_map_cd = 99999
                         AND fin_end >= lv_enrollment_date
                       ORDER BY fin_beg) LOOP
            SELECT nvl(SUM(credit_pts), 0) - nvl(sum(debit_pts), 0)
              INTO lv_bal_points_fnyr
              FROM gd_loyalty_trans
             WHERE card_num = lv_card_num
               AND trans_date BETWEEN rec.fin_beg and rec.fin_end;
            lv_bal_points := lv_bal_points + lv_bal_points_fnyr;
            BEGIN
              SELECT 1
                INTO lv_check
                FROM gd_loyalty_pt_summ
               WHERE card_num = lv_card_num
                 AND fin_year = rec.fnyr;
              UPDATE gd_loyalty_pt_summ
                 SET bal_points = lv_bal_points, updated_date = sysdate
               WHERE card_num = lv_card_num
                 AND fin_year = rec.fnyr;
            EXCEPTION
              WHEN no_data_found THEN
                INSERT INTO gd_loyalty_pt_summ
                  (card_num, bal_points, updated_date, fin_year)
                VALUES
                  (lv_card_num, lv_bal_points, sysdate, rec.fnyr);
            END;
          END LOOP;
        END IF;
    */

  EXCEPTION
    WHEN others THEN
      p_error_cd  := 1;
      p_error_msg := substr(sqlerrm, 1, 100);
  END sp_calculate_bal_points;
```

#### SP-028 - PKG_LOYALTY.SP_GET_VIN_LOYALTY_DTL

**Invoked From:**

- vt_amc_cncl_fmb.xml [ProgramUnit: PROC_AMC_DETAILS]
- vt_amc_cncl_fmb.xml [StoredProcedure: PROC_AMC_DETAILS]

---

**Screen:**

Package Details (N/A / CN_MAIN); Search Details (N/A / CN_MAIN)

---

**Purpose**

Retrieves the loyalty programme card details associated with a vehicle VIN for a given principal. Returns the card type, card number, registered mobile number, current balance in points, and current balance in rupees. Used when loading AMC enrollment details to display loyalty status to the service advisor.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| pn_pmc | NUMBER | IN |
| pn_vin | VARCHAR2 | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| po_card_type | VARCHAR2 | OUT |
| po_card_num | VARCHAR2 | OUT |
| po_reg_mob | VARCHAR2 | OUT |
| po_bal_point | NUMBER | OUT |
| po_bal_rs | NUMBER | OUT |
| po_err_cd | NUMBER | OUT |
| po_err_msg | VARCHAR2 | OUT |

---

**Dependencies**

- PKG_LOYALTY.SF_CALCULATE_POINTS_TO_RUPEES ([SP-025](#SP-025--PKG_LOYALTY.SF_CALCULATE_POINTS_TO_RUPEES)) - PKG_LOYALTY.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Query the loyalty VIN mapping table to find the loyalty card linked to the supplied VIN for the given principal.
- Step 2 - Retrieve the card type and registered mobile number from the loyalty enrollment table.
- Step 3 - Calculate the current points balance by calling `SP_CALCULATE_BAL_POINTS`.
- Step 4 - Convert the points balance to rupees by calling `SF_CALCULATE_POINTS_TO_RUPEES`.
- Step 5 - Return all values via OUT parameters; on any failure return an error code and message.

---
**Decision Points**

DP-001

Condition:
A loyalty card is mapped to the supplied VIN.

TRUE:
Retrieve card details and compute balances.

FALSE:
Return an error code indicating no loyalty mapping found for this VIN.

---
**Database Interactions**

- DB-001 - Read GD_LOYALTY_CARD_VIN_MAP - Reads data from GD_LOYALTY_CARD_VIN_MAP for lookup or validation.
- DB-002 - Read GD_LOYALTY_ENROL - Reads data from GD_LOYALTY_ENROL for lookup or validation.
**Business Rules**

BR-001 - Loyalty details are always VIN-specific - the lookup is by VIN and principal, not by customer code.
BR-002 - Both the points balance and the equivalent rupee value are always returned together.
BR-003 - An error code of 0 indicates success; non-zero indicates a specific failure reason communicated via the error message parameter.

---
**Implementation Logic**

```plsql
  PROCEDURE sp_get_vin_loyalty_dtl(pn_pmc       IN NUMBER,
                                   pn_vin       IN VARCHAR2,
                                   po_card_type OUT VARCHAR2,
                                   po_card_num  OUT VARCHAR2,
                                   po_reg_mob   OUT VARCHAR2,
                                   po_bal_point OUT NUMBER,
                                   po_bal_rs    OUT NUMBER,
                                   po_err_cd    OUT NUMBER,
                                   po_err_msg   OUT VARCHAR2) IS

    lv_channel varchar2(3);
    lv_tier    varchar2(5);
  BEGIN
    po_err_cd  := 0;
    po_err_msg := NULL;

    -- Check VIN
    IF pn_vin IS NULL THEN
      po_err_msg := 'VIN can not be blank';
      po_err_cd  := 1;
    ELSE
      -- Get Card Number
      BEGIN
        SELECT card_num
          INTO po_card_num
          FROM gd_loyalty_card_vin_map
         WHERE card_vin = pn_vin
           AND mapped_yn = 'Y';
      EXCEPTION
        WHEN OTHERS THEN
          po_err_cd  := 1;
          po_err_msg := 'VIN not Mapped with any Loyalty Card';
          RETURN;
      END;
      -- Get Reg Number, Loyalty Point
      BEGIN
        SELECT card_type, reg_mobile, NVL(bal_point, 0), channel, tier
          INTO po_card_type, po_reg_mob, po_bal_point, lv_channel, lv_tier
          FROM gd_loyalty_enrol
         WHERE card_num = po_card_num
           and card_status = 'P';--Added check for SR245997 on 12-May-2021
      EXCEPTION
        WHEN OTHERS THEN
          po_err_cd  := 1;
          po_err_msg := 'Loyalty Cart not defined';
          ----Added by mohan as on 22-08-2023 to handdle exception
          po_card_num :=null;
          po_card_type :=null;
          po_reg_mob :=null;
          po_bal_point :=null;
          lv_channel :=null;
          lv_tier :=null;
          return;
          ----Added by mohan as on 22-08-2023 to handdle exception

      END;
      -- Get Loyalty Rupees
      po_bal_rs := SF_CALCULATE_POINTS_TO_RUPEES(to_char(SYSDATE,'DD-MM-YYYY HH24:MI:SS'),
                                                 po_card_type,
                                                 lv_channel,
                                                 lv_tier,
                                                 po_bal_point);
    END IF;
  END sp_get_vin_loyalty_dtl;
```

#### SP-029 - PKG_LOYALTY.SP_INS_LOYALTY_TRANSACTIONS

**Invoked From:**

- vt_amc_cncl_fmb.xml [ProgramUnit: SP_INSERT_CHARGES]
- vt_amc_cncl_fmb.xml [StoredProcedure: SP_INSERT_CHARGES]

---

**Screen:**

Package Details (N/A / CN_MAIN)

---

**Purpose**

Records a loyalty programme transaction (credit or debit) for a specified loyalty card and vehicle. Used during MCP cancellation to record a cancellation transaction (type "MCPC") against the loyalty card associated with the cancelled contract's VIN.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_card_num | varchar2 | IN |
| p_vin | varchar2 | IN |
| p_trans_type | varchar2 | IN |
| p_trans_date | varchar2 | IN |
| p_trans_num | varchar2 | IN |
| p_remarks | varchar2 | IN |
| p_parent | varchar2 | IN |
| p_dlr_map_cd | number | IN |
| p_loc_cd | varchar2 | IN |
| p_trans_amt | number | IN |
| p_red_points | number | IN |
| p_dr_cr_flag | varchar2 | IN |
| p_user_id | varchar2 | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_error_cd | number | OUT |
| p_error_msg | varchar2 | OUT |

---

**Dependencies**

- D2KWUTIL.CREATED_DATE ([SP-007](#SP-007--D2KWUTIL.CREATED_DATE)) - D2KWUTIL.pck (or .pld)
- PKG_LOYALTY.SF_CALCULATE_POINTS_TO_RUPEES ([SP-025](#SP-025--PKG_LOYALTY.SF_CALCULATE_POINTS_TO_RUPEES)) - PKG_LOYALTY.pck (or .pld)
- PKG_LOYALTY.SF_CALCULATE_RUPEES_TO_POINTS ([SP-026](#SP-026--PKG_LOYALTY.SF_CALCULATE_RUPEES_TO_POINTS)) - PKG_LOYALTY.pck (or .pld)
- PKG_LOYALTY.SP_CALCULATE_BAL_POINTS ([SP-027](#SP-027--PKG_LOYALTY.SP_CALCULATE_BAL_POINTS)) - PKG_LOYALTY.pck (or .pld)
- PKG_LOYALTY.SP_RED_RESTRICTION_BAL_POINTS ([SP-030](#SP-030--PKG_LOYALTY.SP_RED_RESTRICTION_BAL_POINTS)) - PKG_LOYALTY.pck (or .pld)
- SF_PRINCIPAL_MAP_CD ([SP-055](#SP-055--SF_PRINCIPAL_MAP_CD)) - standalone source file

---

**Step-by-Step Business Logic**

- Step 1 - Look up the loyalty card details for the supplied card number.
- Step 2 - Validate that the card is active and the transaction type is permitted.
- Step 3 - Insert a new transaction record into the loyalty transactions table with the supplied transaction details (type, date, reference, remark, parent group, dealer, location, points, amount, indicator, user).
- Step 4 - Update the loyalty enrollment balance.
- Step 5 - Return error code 0 on success or a non-zero error code with message on failure.

---
**Decision Points**

DP-001

Condition:
Loyalty card is found and active.

TRUE:
Insert the transaction and update the card balance.

FALSE:
Return an error indicating card not found or inactive.

---
**Database Interactions**

- DB-001 - Read GM_LOY_TRANS_TYPES - Reads data from GM_LOY_TRANS_TYPES for lookup or validation.
- DB-002 - Read AM_DEALER_LOC - Reads data from AM_DEALER_LOC for lookup or validation.
- DB-003 - Read GD_LOYALTY_ENROL - Reads data from GD_LOYALTY_ENROL for lookup or validation.
- DB-004 - Read AM_LIST - Reads data from AM_LIST for lookup or validation.
- DB-005 - Read DUAL - Reads data from DUAL for lookup or validation.
- DB-006 - Insert into GD_LOYALTY_TRANS - Persists a new row into GD_LOYALTY_TRANS using columns: transaction id, card num, vin, trans type, trans date, trans num, remarks, trans parent group, and 46 more column(s).
- DB-007 - Read GD_LOYALTY_TRANS - Reads data from GD_LOYALTY_TRANS (columns: transaction id, card num, vin, trans type, trans date, trans num, remarks, trans parent group, and 46 more column(s)) for lookup or validation.
- DB-008 - Update GD_LOYALTY_TRANS - Updates existing rows in GD_LOYALTY_TRANS (columns: transaction id, card num, vin, trans type, trans date, trans num, remarks, trans parent group, and 46 more column(s)).
- DB-009 - Read PH_ENQ - Reads data from PH_ENQ for lookup or validation.
**Business Rules**

BR-001 - All loyalty transactions must specify a transaction type ("MCPC" for MCP cancellation); the type drives the credit/debit direction.
BR-002 - A failure to record the loyalty transaction during MCP cancellation must not block the cancellation itself (the caller suppresses loyalty exceptions).

---
**Implementation Logic**

```plsql
  PROCEDURE sp_ins_loyalty_transactions(p_card_num   in varchar2,
                                        p_vin        in varchar2,
                                        p_trans_type in varchar2,
                                        p_trans_date in varchar2, --DD-MM-YYYY HH24:MI:SS
                                        p_trans_num  in varchar2,
                                        p_remarks    in varchar2,
                                        p_parent     in varchar2,
                                        p_dlr_map_cd in number,
                                        p_loc_cd     in varchar2,
                                        p_trans_amt  in number,
                                        p_red_points in number,
                                        p_dr_cr_flag in varchar2,
                                        p_user_id    in varchar2,
                                        p_error_cd   out number,
                                        p_error_msg  out varchar2) is
    lv_check         number;
    lv_bal_points    number;
    lv_exp_months    number;
    lv_trans_owner   varchar2(10);
    lv_trans_nature  varchar2(10);
    lv_debit_pts     number;
    lv_trans_points  number;
    lv_channel       varchar2(5);
    lv_tier          varchar2(5);
    lv_card_type     varchar2(5);
    lv_loy_trans_seq number;
    lv_trans_amt    number;
    lv_liability_amount_debt     number;--Added by saket as on 10-04-2020
    lv_security_amount_debt      number;--Added by saket as on 10-04-2020
    lv_liability_amount          number;--Added by saket as on 10-04-2020
    lv_security_amount_balance   number;--Added by saket as on 10-04-2020
    lv_card_bal                  number;--Added by saket as on 10-04-2020
    lv_restricted_bal            number;--Added by saket as on 18-04-2020
    lv_trans_id   number;--Added by saket as on 12-08-2020
    lv_trans_date date; ---Added by nawal as on 11-Jan-2022
    lv_chk3       number;
    lv_chk2       number;
    lv_chk1       number;
    lv_ord_status VARCHAR2(5);
    lv_enq_stat_count number;
    lv_rev_can_count number;
  BEGIN
    p_error_cd := 0;

    IF p_trans_type is null then
      p_error_cd  := 1;
      p_error_msg := 'Trans Type can not be blank.';
      RETURN;
    END IF;

/*start -- added by veeresh on 18 DEC 2025 (DMS-5049)*/
   IF p_trans_type ='MI' then
      p_error_cd  := 1;
      p_error_msg := 'Awarding for MI is Stopped';
      RETURN;
    END IF;
/*end -- added by veeresh on 18 DEC 2025 (DMS-5049)*/

    BEGIN
      SELECT trans_owner, trans_nature
        into lv_trans_owner, lv_trans_nature
        from gm_loy_trans_types
       where trans_type = p_trans_type
         and trans_act_flag = 'Y'
         and principal_map_cd = sf_principal_map_cd(p_dlr_map_cd, p_loc_cd);
    EXCEPTION
      when no_data_found then
        p_error_cd  := 1;
        p_error_msg := 'Transaction Type not found.';
        RETURN;
    END;

    IF lv_trans_nature = 'C' THEN
      IF p_parent is null or p_dlr_map_cd is null or p_loc_cd is null or
         p_card_num is null or p_user_id is null or p_trans_num is null THEN
        p_error_cd  := 1;
        p_error_msg := 'Parent Group/Dealer map Code/Loc Code/Card Number/Trans Number/User are mandatory Parameters';
        RETURN;
      END IF;
    END IF;
    IF lv_trans_nature <> 'C' THEN
      IF p_parent is null or p_dlr_map_cd is null or p_loc_cd is null or
         p_card_num is null or p_trans_type is null and p_trans_num is null or
         p_trans_date is null or p_user_id is null /*or p_trans_amt is null*/ or
         p_dr_cr_flag is null THEN
        p_error_cd  := 1;
        p_error_msg := 'Parent Group/Dealer map Code/Loc Code/Card Number/Trans Type/Trans Number/Trans Date/User/Trans Amount/DR_CR Flag all are mandatory Parameters';
        RETURN;
      END IF;
    END IF;

    BEGIN
      SELECT 1
        INTO lv_check
        FROM am_dealer_loc
       WHERE parent_group = p_parent
         AND dealer_map_cd = p_dlr_map_cd
         AND loc_cd = p_loc_cd;
    EXCEPTION
      WHEN no_data_found THEN
        p_error_cd  := 1;
        p_error_msg := 'Wrong Dealer Code';
        RETURN;
    END;

    IF p_dr_cr_flag not in ('C', 'D') THEN
      p_error_cd  := 1;
      p_error_msg := 'DR/CR flag can be only C and D';
      RETURN;
    END IF;

    begin
      select card_type, channel, tier,
             bal_point --Added by saket as on 10-04-2020
        into lv_card_type, lv_channel, lv_tier,
             lv_card_bal   --Added by saket as on 10-04-2020
        from gd_loyalty_enrol
       where card_num = p_card_num;
    --Added by saket as on 05-05-2021(start)
    EXCEPTION
      when no_data_found then
        p_error_cd  := 1;
        p_error_msg := 'Card Not found.';
        RETURN;
    --Added by saket as on 05-05-2021(end)
    end;

    BEGIN
      select list_desc
        into lv_exp_months
        from am_list
       where list_name = 'LOYL_PONITS_EXPIRED'
         and list_code = nvl(lv_tier,'T1')--'EXP' changed by saket as on 06-04-2022
         and principal_map_cd = sf_principal_map_cd(p_dlr_map_cd, p_loc_cd)
         and nvl(list_flag, 'Y') = 'Y';
    EXCEPTION
      when no_data_found then
        p_error_cd  := 1;
        p_error_msg := 'Expire Months not defined in the system';
        RETURN;
    END;

    --Added by saket as on 05-05-2021(start)
    begin
      select card_type, channel, tier,
             bal_point
        into lv_card_type, lv_channel, lv_tier,
             lv_card_bal
        from gd_loyalty_enrol
       where card_num = p_card_num
         and card_status='P';
    EXCEPTION
      when no_data_found then
        p_error_cd  := 1;
        p_error_msg := 'Card Status is not P(printed).';
        RETURN;
    end;
    --Added by saket as on 05-05-2021(end)

     --Added by nawal as on 03-01-2022(start)
     begin
     Select count(1) into lv_chk1
       from am_list
      where list_name = 'TRAN_CHK'
        and principal_map_cd = 1
        and nvl(list_flag, 'Y') = 'Y';
      exception
        when others then
          lv_chk1 := 0;
      end;

    IF nvl(p_trans_amt,0) <= 0 and lv_chk1 <> 0 THEN
        p_error_cd  := 1;
        p_error_msg := 'Transaction Amt should be greater than be 0.';
        RETURN;
    --Added by saket as on 10-06-2021(start)
    ELSIF p_trans_amt is not null and p_trans_amt < 0 THEN
          p_error_cd  := 1;
          p_error_msg := 'Transaction Amt can not be less than 0.';
          RETURN;
    END IF;
    --Added by saket as on 10-06-2021(end)

    --Added by nawal as on 03-01-2022(end)

    --Added by Nawal(21-Dec-2021) to handle 0,null,-ve debit points (start)

     begin
     Select count(1) into lv_chk2
       from am_list
      where list_name = 'DEB_CHK'
        and principal_map_cd = 1
        and nvl(list_flag, 'Y') = 'Y';
      exception
        when others then
          lv_chk2 := 0;
      end;

     IF p_dr_cr_flag = 'D' and lv_trans_nature <> 'C' and lv_chk2 <> 0 THEN
     IF nvl(p_red_points,0) <= 0 THEN
        p_error_cd  := 1;
        p_error_msg := 'Debit Points should be greater than 0.';
        RETURN;
    END IF;
    END IF;
    --Added by Nawal(21-Dec-2021) to handle debit points(end)
   /*
    */
    lv_trans_amt:=p_trans_amt;
    IF p_red_points is not null THEN
      lv_trans_points := p_red_points;
    ELSIF lv_trans_nature='R' THEN
      lv_trans_points:=p_trans_amt;
      lv_trans_amt:=null;
    ELSIF lv_trans_nature='A' THEN
      lv_trans_points:=p_trans_amt;
      --lv_trans_amt:=sf_calculate_points_to_rupees(p_trans_date,lv_card_type,lv_channel,lv_tier,lv_trans_points); Commented by saket as on 09-04-2021
      lv_trans_amt:=sf_calculate_points_to_rupees(to_char(sysdate,'DD-MM-YYYY HH24:MI:SS'),lv_card_type,lv_channel,lv_tier,lv_trans_points); --Added by saket as on 09-04-2021
    ELSE
      lv_trans_points := sf_calculate_rupees_to_points(--p_trans_date,  Commneted by saket as on 09-04-2021
                                                       to_char(sysdate,'DD-MM-YYYY HH24:MI:SS'),  --Added by saket as on 09-04-2021
                                                       lv_card_type,
                                                       lv_channel,
                                                       lv_tier,
                                                       lv_trans_amt);
    END IF;

     --Added by Nawal(21-Dec-2021) to handle -ve credit points (start)
     begin
     Select count(1) into lv_chk3
       from am_list
      where list_name = 'CRE_CHK'
        and principal_map_cd = 1
        and nvl(list_flag, 'Y') = 'Y';
      exception
        when others then
          lv_chk3 := 0;
      end;
     IF p_dr_cr_flag = 'C' and lv_trans_nature <> 'C' and lv_chk3 <> 0 THEN
     IF lv_trans_points < 0 THEN
        p_error_cd  := 1;
        p_error_msg := 'Credit Points should not be Negative.';
        RETURN;
    END IF;
    END IF;
    --Added by Nawal(21-Dec-2021) to handle credit points(end)

    /*    sp_get_card_num(p_mobile_no,
                    p_card_type,
                    lv_card_num,
                    p_error_cd,
                    p_error_msg);

    IF p_error_cd <> 0 THEN
      p_error_msg := 'Card Number Not found. Pls. hceck the mobile number and card type.';
      return;
    END IF;*/

    IF p_dr_cr_flag = 'C' and lv_trans_nature <> 'C' THEN
      select LOY_TRANS_SEQ.Nextval into lv_trans_id from dual; --Added by saket as on 12-08-2020
      lv_trans_date:= sysdate;
      INSERT INTO gd_loyalty_trans
        (transaction_id,
         card_num,
         vin,
         trans_type,
         trans_date,
         trans_num,
         remarks,
         trans_parent_group,
         trans_dlr_map_cd,
         trans_loc_cd,
         trans_amt,
         credit_pts,
         created_by,
         created_date,
         expiry_date,
         balance_points,
         tier,
         security_amount,             --Added by saket as on 10-04-2020
         security_amount_balance,     --Added by saket as on 10-04-2020
         liability_amount,           --Added by saket as on 10-04-2020
         org_parent_group,         --added by saket as on 08-08-2020
         org_dlr_map_cd,           --added by saket as on 08-08-2020
         org_loc_cd)               --added by saket as on 08-08-2020
      VALUES
        (lv_trans_id,--LOY_TRANS_SEQ.Nextval, Changed by saket as on 12-08-2020
         p_card_num,
         p_vin,
         p_trans_type,
         sysdate, --Added by saket as on 09-04-2021
         --to_date(p_trans_date, 'DD-MM-YYYY HH24:MI:SS'), commented by saket as on 09-04-2021
         p_trans_num,
         p_remarks,
         decode(lv_trans_owner, 'M', '99999', p_parent),
         decode(lv_trans_owner, 'M', 99999, p_dlr_map_cd),
         decode(lv_trans_owner, 'M', '999', p_loc_cd),
         decode(p_trans_type,'LEXB',null,lv_trans_amt),/*updated by veeresh on 08 JULY 2024  DMS-1898*/
         lv_trans_points,
         p_user_id,
         sysdate,
         /*add_months(last_day(trunc(to_date(p_trans_date,
                                           'DD-MM-YYYY HH24:MI:SS'))),
                    lv_exp_months - 1),commented by saket as on 09-04-2021*/
         add_months(last_day(trunc(sysdate)),lv_exp_months - 1),  --Added by saket as on 09-04-2021
         decode(p_trans_type,'LEXB',/*0*/lv_trans_points,lv_trans_points),/*updated by veeresh on 08 JULY 2024  DMS-1898*/
         lv_tier,
         /*  Commented by saket as on 24-06-2020
         decode(lv_trans_owner, 'M',0,lv_trans_points/2),     --Added by saket as on 10-04-2020
         decode(lv_trans_owner, 'M',0,lv_trans_points/2),     --Added by saket as on 10-04-2020
         decode(lv_trans_owner, 'M',lv_trans_points,lv_trans_points/2));    --Added by saket as on 10-04-2020
         */
         --Added by saket as on 24-06-2020(start)
         /*decode(lv_trans_owner, 'M',0,lv_trans_points*.25),
         decode(lv_trans_owner, 'M',0,lv_trans_points*.25),
         decode(p_trans_type,'LEXB',0,decode(lv_trans_owner, 'M',lv_trans_points,lv_trans_points*.75)), commented by saket as on 09-07-2021  aginst scr number DMSSAL-12832*/
         --Added by saket as on 09-07-2021 aginst scr number DMSSAL-12832(start)
         --decode(lv_trans_owner, 'M',lv_trans_points,lv_trans_points*.25),-- commented by veeresh on 11july2023
         decode(p_trans_type,'MI',decode(p_parent,'99999',lv_trans_points,lv_trans_points*.25),decode(lv_trans_owner, 'M',lv_trans_points,lv_trans_points*.25)),-- added by veeresh on 11july2023
         --decode(lv_trans_owner, 'M',lv_trans_points,lv_trans_points*.25),  --Commented by saket as on 27-10-2021
         --decode(p_trans_type,'LEXB',0,decode(lv_trans_owner, 'M',lv_trans_points,lv_trans_points*.25)), --Added by saket as on 27-10-2021 -- commented by veeresh on 11july2023
         decode(p_trans_type,/*'LEXB',0,*/'MI',decode(p_parent,'99999',lv_trans_points,lv_trans_points*.25),decode(lv_trans_owner, 'M',lv_trans_points,lv_trans_points*.25)),-- added by veeresh on 11july2023/*LEXB Commented by veeresh on 08 JULY 2024  DMS-1898*/
         --decode(p_trans_type,'LEXB',0,decode(lv_trans_owner, 'M',0,lv_trans_points*.75)),-- commented by veeresh on 11july2023
         decode(p_trans_type,/*'LEXB',0,*/'MI',decode(p_parent,'99999',0,lv_trans_points*.75),decode(lv_trans_owner, 'M',0,lv_trans_points*.75)),---- added by veeresh on 11july2023/*LEXB Commented by veeresh on 05 JULY 2024  DMS-1898*/
         --Added by saket as on 09-07-2021 aginst scr number DMSSAL-12832(end)
         --Added by saket as on 24-06-2020(end)
         p_parent,           --Added by saket as on 08-08-2020
         p_dlr_map_cd,       --Added by saket as on 08-08-2020
         p_loc_cd);          --Added by saket as on 08-08-2020
    --Added by saket as on 11-08-2020(start)
      /*LEXB Debit entry Commented by veeresh on 08 JULY 2024  DMS-1898*/
      /*IF p_trans_type='LEXB' THEN
      INSERT INTO gd_loyalty_trans
        (transaction_id,
         card_num,
         vin,
         trans_type,
         trans_date,
         trans_num,
         remarks,
         trans_parent_group,
         trans_dlr_map_cd,
         trans_loc_cd,
         trans_amt,
         debit_pts,
         created_by,
         created_date,
         expiry_date,
         balance_points,
         tier,
         security_amount,
         security_amount_balance,
         liability_amount,
         liability_amount_debt,
         security_amount_debt ,
         org_parent_group,
         org_dlr_map_cd,
         org_loc_cd,
         dr_parent_group,
         dr_dlr_map_cd,
         dr_loc_cd ,
         dr_transaction_id,
         dr_trans_date ---Added by nawal as on 07-JAN-2022
          )
      VALUES
        (LOY_TRANS_SEQ.Nextval,
         p_card_num,
         p_vin,
         p_trans_type,
         --to_date(p_trans_date, 'DD-MM-YYYY HH24:MI:SS'), commneted by saket as on 09-04-2021
         sysdate,   --Added by saket as on 09-04-2021
         p_trans_num,
         p_remarks,
         p_parent,
         p_dlr_map_cd,
         p_loc_cd,
         lv_trans_amt,
         lv_trans_points,
         p_user_id,
         sysdate,
         \*add_months(last_day(trunc(to_date(p_trans_date,
                                           'DD-MM-YYYY HH24:MI:SS'))),
                    lv_exp_months - 1),commented by saket as on 09-04-2021*\
         add_months(last_day(trunc(sysdate)),lv_exp_months - 1),  --Added by saket as on 09-04-2021
         0,
         lv_tier,
         0,
         0,
         0,
         0,--lv_trans_points, changed by saket as on 07-09-2021 aginst scr number DMSSAL-12832
         lv_trans_points,--0, changed by saket as on 07-09-2021 aginst scr number DMSSAL-12832
         p_parent,
         p_dlr_map_cd,
         p_loc_cd,
         '99999',
         99999,
         999,
         lv_trans_id,
         lv_trans_date ---Added by nawal as on 11-JAN-2022
         );
         END IF;*/
    --Added by saket as on 11-08-2020(end)
    END IF;

    IF p_dr_cr_flag = 'D' and lv_trans_nature <> 'C' and p_red_points > 0 THEN
      --Added by saket as on 10-04-2020(start)
      IF lv_card_bal < p_red_points THEN
         p_error_cd  := 1;
         p_error_msg := 'Redeemed points : '|| p_red_points||' is greater than card balance : '||lv_card_bal;
         return;
      END IF;
      --Added by saket as on 10-04-2020(end)
      --Added by saket as on 18-04-2020(start)
      DECLARE
      lv_err   number;
      lv_errm  varchar2(500);
      BEGIN
        pkg_loyalty.sp_red_restriction_bal_points(p_card_num,lv_restricted_bal,lv_err,lv_errm);
        IF lv_err =1 THEN
          p_error_cd  := 1;
          p_error_msg := 'Error in calulating Redemption Restricted Balance : '||lv_card_bal;
          return;
        END IF;
        IF lv_restricted_bal < p_red_points THEN
          p_error_cd  := 1;
          p_error_msg := 'Total redeemable points for the loyalty card are '||lv_restricted_bal||'. Loyalty points earned will be redeemable only after 48 hours';
          return;
        END IF;
      END;
      --Added by saket as on 18-04-2020(end)
      lv_debit_pts := p_red_points;
      for rec in (select x.rowid rid, x.*
                    from gd_loyalty_trans x
                   where card_num = p_card_num
                     and nvl(expired, 'N') = 'N'
                     --and balance_points <> 0 Commneted as on 08-08-2020
                     and balance_points > 0  --Added as on 08-08-2020
                   order by transaction_id) loop
        if lv_debit_pts >= rec.BALANCE_pOINTS then
          --Added by saket as on 10-04-2020(start)
          if rec.liability_amount >= rec.BALANCE_pOINTS then
             lv_liability_amount_debt:=rec.BALANCE_pOINTS;
             lv_security_amount_debt:=0;
             lv_liability_amount:=rec.liability_amount-rec.BALANCE_pOINTS;
             lv_security_amount_balance:=rec.security_amount_balance;
          else
             lv_liability_amount_debt:=rec.liability_amount;
             lv_security_amount_debt:=rec.BALANCE_pOINTS-lv_liability_amount_debt;
             lv_liability_amount:=0;
             lv_security_amount_balance:=rec.security_amount_balance-lv_security_amount_debt;
          end if;
          --Added by saket as on 10-04-2020(end)
          INSERT INTO gd_loyalty_trans
            (transaction_id,
             card_num,
             vin,
             trans_type,
             trans_date,
             trans_num,
             remarks,
             trans_parent_group,
             trans_dlr_map_cd,
             trans_loc_cd,
             trans_amt,
             debit_pts,
             dr_transaction_id,
             dr_parent_group,
             dr_dlr_map_cd,
             dr_loc_cd,
             created_by,
             created_date,
             expiry_date,
             tier,
             liability_amount_debt,    ----Added by saket as on 10-04-2020
             security_amount_debt,  ----Added by saket as on 10-04-2020
             org_parent_group,         --added by saket as on 08-08-2020
             org_dlr_map_cd,           --added by saket as on 08-08-2020
             org_loc_cd,               --added by saket as on 08-08-2020
             dr_trans_date ---Added by nawal as on 07-JAN-2022
             )
          VALUES
            (LOY_TRANS_SEQ.Nextval,
             p_card_num,
             p_vin,
             p_trans_type,
             --to_date(p_trans_date, 'DD-MM-YYYY HH24:MI:SS'), commented by saket as on 09-04-2021
             sysdate, --Added by saket as on 09-04-2021
             p_trans_num,
             p_remarks,
             p_parent,
             p_dlr_map_cd,
             p_loc_cd,
             lv_trans_amt,
             rec.balance_points,
             rec.transaction_id,
             rec.trans_parent_group,
             rec.trans_dlr_map_cd,
             rec.trans_loc_cd,
             p_user_id,
             sysdate,
             /*add_months(last_day(trunc(to_date(p_trans_date,
                                               'DD-MM-YYYY HH24:MI:SS'))),
                        lv_exp_months - 1),commented by saket as on 09-04-2021*/
             add_months(last_day(trunc(sysdate)),lv_exp_months - 1),  --Added by saket as on 09-04-2021
             lv_tier,
             lv_liability_amount_debt,    ----Added by saket as on 10-04-2020
             lv_security_amount_debt,    ----Added by saket as on 10-04-2020
             p_parent,           --Added by saket as on 08-08-2020
             p_dlr_map_cd,       --Added by saket as on 08-08-2020
             p_loc_cd,          --Added by saket as on 08-08-2020
             rec.trans_date ---Added by nawal as on 07-JAN-2022
             );

          update gd_loyalty_trans
             set balance_points = balance_points - rec.balance_points,
                 liability_amount = lv_liability_amount,                  ----Added by saket as on 10-04-2020
                 security_amount_balance = lv_security_amount_balance     ----Added by saket as on 10-04-2020
                 ,updated_date = sysdate  --Added by saket as on 27-10-2021
                 ,updated_by=p_user_id  --Added by saket as on 27-10-2021
           where rowid = rec.rid;

          lv_debit_pts := lv_debit_pts - rec.balance_points;
        else
          if lv_debit_pts <> 0 THEN
          --Added by saket as on 10-04-2020(start)
          if rec.liability_amount >= lv_debit_pts then
             lv_liability_amount_debt:=lv_debit_pts;
             lv_security_amount_debt:=0;
             lv_liability_amount:=rec.liability_amount-lv_debit_pts;
             lv_security_amount_balance:=rec.security_amount_balance;
          else
             lv_liability_amount_debt:=rec.liability_amount;
             lv_security_amount_debt:=lv_debit_pts-lv_liability_amount_debt;
             lv_liability_amount:=0;
             lv_security_amount_balance:=rec.security_amount_balance-lv_security_amount_debt;
          end if;
          --Added by saket as on 10-04-2020(end)
            INSERT INTO gd_loyalty_trans
              (transaction_id,
               card_num,
               vin,
               trans_type,
               trans_date,
               trans_num,
               remarks,
               trans_parent_group,
               trans_dlr_map_cd,
               trans_loc_cd,
               trans_amt,
               debit_pts,
               dr_transaction_id,
               dr_parent_group,
               dr_dlr_map_cd,
               dr_loc_cd,
               created_by,
               created_date,
               expiry_date,
               tier,
               liability_amount_debt,    ----Added by saket as on 10-04-2020
               security_amount_debt,  ----Added by saket as on 10-04-2020
               org_parent_group,         --added by saket as on 08-08-2020
               org_dlr_map_cd,           --added by saket as on 08-08-2020
               org_loc_cd,               --added by saket as on 08-08-2020
               dr_trans_date ---Added by nawal as on 07-JAN-2022
               )
            VALUES
              (LOY_TRANS_SEQ.Nextval,
               p_card_num,
               p_vin,
               p_trans_type,
               --to_date(p_trans_date, 'DD-MM-YYYY HH24:MI:SS'), commented by saket as on 09-04-2021
               sysdate, --Added by saket as on 09-04-2021
               p_trans_num,
               p_remarks,
               p_parent,
               p_dlr_map_cd,
               p_loc_cd,
               lv_trans_amt,
               lv_debit_pts,
               rec.transaction_id,
               rec.trans_parent_group,
               rec.trans_dlr_map_cd,
               rec.trans_loc_cd,
               p_user_id,
               sysdate,
               /*add_months(last_day(trunc(to_date(p_trans_date,
                                                 'DD-MM-YYYY HH24:MI:SS'))),
                          lv_exp_months - 1),commented by saket as on 09-04-2021*/
               add_months(last_day(trunc(sysdate)),lv_exp_months - 1),  --Added by saket as on 09-04-2021
               lv_tier,
               lv_liability_amount_debt,    ----Added by saket as on 10-04-2020
               lv_security_amount_debt,    ----Added by saket as on 10-04-2020
               p_parent,           --Added by saket as on 08-08-2020
               p_dlr_map_cd,       --Added by saket as on 08-08-2020
               p_loc_cd,          --Added by saket as on 08-08-2020
               rec.trans_date); ---Added by nawal as on 07-JAN-2022

            update gd_loyalty_trans
               set balance_points = balance_points - lv_debit_pts,
                   liability_amount = lv_liability_amount,                  ----Added by saket as on 10-04-2020
                   security_amount_balance = lv_security_amount_balance     ----Added by saket as on 10-04-2020
                   ,updated_date = sysdate  --Added by saket as on 27-10-2021
                   ,updated_by=p_user_id  --Added by saket as on 27-10-2021
             where rowid = rec.rid;

          end if;
          lv_debit_pts := 0;
        end if;
        if lv_debit_pts = 0 then
          exit;
        end if;
      end loop;
    END IF;

    IF lv_trans_nature = 'C' THEN
      -- for rec in (select x.rowid rid,  x.* from gd_loyalty_trans x where card_num=p_card_num and trans_parent_group = p_parent  AND trans_dlr_map_cd = p_dlr_map_cd AND trans_loc_cd = p_loc_cd and x.trans_num=p_trans_num order by transaction_id)
      -- loop
      select LOY_TRANS_SEQ.Nextval into lv_loy_trans_seq from dual;
      -- Added By Pooja on 16-Apr-24 for DMS-1797
     IF p_trans_type = 'ACCC' THEN

     select count(*) into lv_enq_stat_count from ph_enq en
       where en.parent_group = p_parent
       and en.dealer_map_cd  = p_dlr_map_cd
       and en.loc_cd = p_loc_cd
       and en.web_enq_num = p_trans_num;

       IF lv_enq_stat_count>0 then
            select en.enq_status into lv_ord_status from ph_enq en
         where en.parent_group = p_parent
         and en.dealer_map_cd  = p_dlr_map_cd
         and en.loc_cd = p_loc_cd
         and en.web_enq_num = p_trans_num;
       ELSE
           p_error_cd  := 1;
          p_error_msg := 'Enquiry Not Found';
          return;
       END IF;

       Begin
         -- Added By Pooja on 25-Apr-24 for DMS-1797
         select count(*) into lv_rev_can_count from gd_loyalty_trans gd where
         gd.trans_parent_group = p_parent
         and gd.trans_dlr_map_cd = p_dlr_map_cd
         and gd.trans_loc_cd = p_loc_cd
         and gd.trans_num = p_trans_num
         and gd.remarks = 'Points Revarsal Due To Transaction Cancellation'
         and gd.trans_type = 'ACCC';

       end;

       If lv_ord_status = 'C' and lv_rev_can_count>0 THEN
         p_error_cd  := 1;
          p_error_msg := 'Order is cancelled and points are reversed already.';
          return;
         END IF;
     END IF;
     ----------------------------------------------------
      INSERT INTO gd_loyalty_trans
        (transaction_id,
         card_num,
         vin,
         trans_type,
         trans_date,
         trans_num,
         remarks,
         trans_parent_group,
         trans_dlr_map_cd,
         trans_loc_cd,
         trans_amt,
         credit_pts,
         created_by,
         created_date,
         balance_points,
         expiry_date,
         tier,
         /*
         liability_amount_debt,    ----Added by saket as on 13-04-2020
         security_amount_debt)    ----Added by saket as on 13-04-2020*/
         security_amount,         ----Added by saket as on 14-04-2020
         security_amount_balance, ----Added by saket as on 14-04-2020
         liability_amount ,       ----Added by saket as on 14-04-2020
         org_parent_group,         --added by saket as on 08-08-2020
         org_dlr_map_cd,           --added by saket as on 08-08-2020
         org_loc_cd)               --added by saket as on 08-08-2020
        select lv_loy_trans_seq,
               p_card_num,
               p_vin,
               p_trans_type,
               --to_date(p_trans_date, 'DD-MM-YYYY HH24:MI:SS'), --Commnetd by saket as on 09-04-2021
               sysdate, --Added by saket as on 09-04-2021
               trans_num,
               'Points Revarsal Due To Transaction Cancellation',--remarks,/*DMS-1493 remarks hard coded by veeresh on 29 jan 2024*/
               decode(p_trans_type,'REFC','99999','LACBC','99999','LEXBC',trans_parent_group,p_parent),                  /*Added by Kanav on 08-Feb-2021 for DMSSAL-12760*/
               decode(p_trans_type,'REFC',99999,'LACBC',99999,'LEXBC',trans_dlr_map_cd,p_dlr_map_cd),                  /*Added by Kanav on 08-Feb-2021 for DMSSAL-12760*/
               decode(p_trans_type,'REFC','999','LACBC','999','LEXBC',trans_loc_cd,p_loc_cd),                            /*Added by Kanav on 08-Feb-2021 for DMSSAL-12760*/
               trans_amt,
               SUM(debit_pts),
               p_user_id,
               sysdate,
               SUM(debit_pts),
               /*add_months(last_day(trunc(to_date(p_trans_date,
                                                 'DD-MM-YYYY HH24:MI:SS'))),
                          lv_exp_months - 1),commented by saket as on 09-04-2021*/
               add_months(last_day(trunc(sysdate)),lv_exp_months - 1),  --Added by saket as on 09-04-2021
               lv_tier,
              /* SUM(debit_pts)/2,  ----Added by saket as on 13-04-2020
               SUM(debit_pts)/2   ----Added by saket as on 13-04-2020*/
               /* Commented by saket as on 24-06-2020
               SUM(debit_pts)/2,  ----Added by saket as on 14-04-2020
               SUM(debit_pts)/2,  ----Added by saket as on 14-04-2020
               SUM(debit_pts)/2   ----Added by saket as on 14-04-2020
               */
               --Added by saket as on 24-06-2020(start)
               SUM(debit_pts)*.25,  ----Added by saket as on 14-04-2020
               SUM(debit_pts)*.25,  ----Added by saket as on 14-04-2020
               SUM(debit_pts)*.75,   ----Added by saket as on 14-04-2020
               --Added by saket as on 24-06-2020(end)
               p_parent,           --Added by saket as on 08-08-2020
               p_dlr_map_cd,       --Added by saket as on 08-08-2020
               p_loc_cd          --Added by saket as on 08-08-2020
          from gd_loyalty_trans a,  gm_loy_trans_types b
         where card_num = p_card_num
           and nvl(expired, 'N') = 'N'
           and trans_num = p_trans_num
           and a.trans_type=decode(p_trans_type,'REFRC','REFRE','REFC','REFF','LACBC','LACB','LEXBC','LEXB',a.trans_type)                                /*Added by Kanav on 08-Feb-2021 for DMSSAL-12760*/
           and decode(p_trans_type,'REFC',org_parent_group,'LACBC',org_parent_group,'LEXBC',org_parent_group,trans_parent_group) = p_parent              /*Added by Kanav on 08-Feb-2021 for DMSSAL-12760*/
           and decode(p_trans_type,'REFC',org_dlr_map_cd,'LACBC',org_dlr_map_cd,'LEXBC',org_dlr_map_cd,trans_dlr_map_cd) = p_dlr_map_cd                  /*Added by Kanav on 08-Feb-2021 for DMSSAL-12760*/
           and decode(p_trans_type,'REFC',org_loc_cd,'LACBC',org_loc_cd,'LEXBC',org_loc_cd,trans_loc_cd) = p_loc_cd                                      /*Added by Kanav on 08-Feb-2021 for DMSSAL-12760*/
           and debit_pts > 0
           --Added by saket as on 07-08-2020(start)
           and a.trans_type=b.trans_type
           and b.trans_nature<>'C'
           and trans_date >= nvl((select max(x.trans_date) from gd_loyalty_trans x, gm_loy_trans_types y
                              where x.trans_type=y.trans_type
                                and x.trans_num=p_trans_num
                                and x.card_num = p_card_num
                                and nvl(x.expired, 'N') = 'N'
                                and x.debit_pts > 0
                                and x.trans_type=decode(p_trans_type,'REFRC','REFRE','REFC','REFF','LACBC','LACB','LEXBC','LEXB',x.trans_type)            /*Added by Kanav on 08-Feb-2021 for DMSSAL-12760*/
                                /*and x.trans_parent_group = p_parent
                                and x.trans_dlr_map_cd = p_dlr_map_cd
                                and x.trans_loc_cd = p_loc_cd*/
                                 and decode(p_trans_type,'REFC',org_parent_group,'LACBC',org_parent_group,'LEXBC',org_parent_group,trans_parent_group) = p_parent    /*Added by Kanav on 08-Feb-2021 for DMSSAL-12760*/
                                 and decode(p_trans_type,'REFC',org_dlr_map_cd,'LACBC',org_dlr_map_cd,'LEXBC',org_dlr_map_cd,trans_dlr_map_cd) = p_dlr_map_cd        /*Added by Kanav on 08-Feb-2021 for DMSSAL-12760*/
                                 and decode(p_trans_type,'REFC',org_loc_cd,'LACBC',org_loc_cd,'LEXBC',org_loc_cd,trans_loc_cd) = p_loc_cd                            /*Added by Kanav on 08-Feb-2021 for DMSSAL-12760*/
                                and y.trans_nature='C'),trans_date)
           --Added by saket as on 07-08-2020(end)
         group by card_num,
                  trans_num,
                  trans_parent_group,
                  trans_dlr_map_cd,
                  trans_loc_cd,
                  trans_amt,
                  p_trans_date,
                  'Points Revarsal Due To Transaction Cancellation'--remarks,/*DMS-1493 remarks hard coded by veeresh on 29 jan 2024*/
                  ;
      /* Commented IF  BLOCK TO INCLUDE by LEXBC  veeresh on 05 JULY 2024  DMS-1898*/  /*IF p_trans_type<>'LEXBC' THEN  */  -- Added by saket as on 14-08-2020
      for rec in (select x.rowid rid, x.*
                    from gd_loyalty_trans x,gm_loy_trans_types x1
                   where card_num = p_card_num
                     and nvl(expired, 'N') = 'N'
                     and x.trans_num = p_trans_num
                     /*and trans_parent_group = p_parent
                     and trans_dlr_map_cd = p_dlr_map_cd
                     and trans_loc_cd = p_loc_cd*/
                     and decode(p_trans_type,'REFC',org_parent_group,'LACBC',org_parent_group,'LEXBC',org_parent_group,trans_parent_group) = p_parent    /*Added by Kanav on 08-Feb-2021 for DMSSAL-12760*/
                     and decode(p_trans_type,'REFC',org_dlr_map_cd,'LACBC',org_dlr_map_cd,'LEXBC',org_dlr_map_cd,trans_dlr_map_cd) = p_dlr_map_cd        /*Added by Kanav on 08-Feb-2021 for DMSSAL-12760*/
                     and decode(p_trans_type,'REFC',org_loc_cd,'LACBC',org_loc_cd,'LEXBC',org_loc_cd,trans_loc_cd) = p_loc_cd                            /*Added by Kanav on 08-Feb-2021 for DMSSAL-12760*/
                     and credit_pts <> 0
                     and x.trans_type=decode(p_trans_type,'REFRC','REFRE','REFC','REFF','LACBC','LACB','LEXBC','LEXB',x.trans_type)                      /*Added by Kanav on 08-Feb-2021 for DMSSAL-12760*/
                     and x.trans_type=x1.trans_type
                     and x1.trans_nature<>'C'
                     and transaction_id <> lv_loy_trans_seq
                     --Added by saket as on 07-08-2020(start)
                     and trans_date >= nvl((select max(z.trans_date) from gd_loyalty_trans z, gm_loy_trans_types y
                                        where z.trans_type=y.trans_type
                                          and z.trans_num=p_trans_num
                                          and z.card_num = p_card_num
                                          and nvl(z.expired, 'N') = 'N'
                                          and z.debit_pts > 0
                                          /*and z.trans_parent_group = p_parent
                                          and z.trans_dlr_map_cd = p_dlr_map_cd
                                          and z.trans_loc_cd = p_loc_cd*/
                                         and decode(p_trans_type,'REFC',org_parent_group,'LACBC',org_parent_group,'LEXBC',org_parent_group,trans_parent_group) = p_parent                    /*Added by Kanav on 08-Feb-2021 for DMSSAL-12760*/
                                         and z.trans_type=decode(p_trans_type,'REFRC','REFRE','REFC','REFF','LACBC','LACB','LEXBC','LEXB',z.trans_type)                                      /*Added by Kanav on 08-Feb-2021 for DMSSAL-12760*/
                                         and decode(p_trans_type,'REFC',org_dlr_map_cd,'LACBC',org_dlr_map_cd,'LEXBC',org_dlr_map_cd,trans_dlr_map_cd) = p_dlr_map_cd                        /*Added by Kanav on 08-Feb-2021 for DMSSAL-12760*/
                                         and decode(p_trans_type,'REFC',org_loc_cd,'LACBC',org_loc_cd,'LEXBC',org_loc_cd,trans_loc_cd) = p_loc_cd                                            /*Added by Kanav on 08-Feb-2021 for DMSSAL-12760*/
                                          and y.trans_nature='C'),trans_date)
                     --Added by saket as on 07-08-2020(end)
                   order by transaction_id) loop
        INSERT INTO gd_loyalty_trans
          (transaction_id,
           card_num,
           vin,
           trans_type,
           trans_date,
           trans_num,
           remarks,
           trans_parent_group,
           trans_dlr_map_cd,
           trans_loc_cd,
           trans_amt,
           debit_pts,
           dr_transaction_id,
           dr_parent_group,
           dr_dlr_map_cd,
           dr_loc_cd,
           created_by,
           created_date,
           expiry_date,
           tier,
           liability_amount_debt,    ----Added by saket as on 13-04-2020
           security_amount_debt,     ----Added by saket as on 13-04-2020)
           org_parent_group,         --added by saket as on 08-08-2020
           org_dlr_map_cd,           --added by saket as on 08-08-2020
           org_loc_cd,               --added by saket as on 08-08-2020
           dr_trans_date ---Added by nawal as on 07-JAN-2022
           )
        VALUES
          (LOY_TRANS_SEQ.Nextval,
           p_card_num,
           p_vin,
           p_trans_type,
           --to_date(p_trans_date, 'DD-MM-YYYY HH24:MI:SS'),  commnted by saket as on 09-04-2021
           sysdate, --Added by saket as on 09-04-2021
           p_trans_num,
           'Points Revarsal Due To Transaction Cancellation',--p_remarks,/*DMS-1493 remarks hard coded by veeresh on 29 jan 2024*/
           decode(p_trans_type,'REFC','99999','LACBC','99999','LEXBC',rec.trans_parent_group,p_parent),                                  /*Added by Kanav on 08-Feb-2021 for DMSSAL-12760*/
           decode(p_trans_type,'REFC',99999,'LACBC',99999,'LEXBC',rec.trans_dlr_map_cd,p_dlr_map_cd),                                  /*Added by Kanav on 08-Feb-2021 for DMSSAL-12760*/
           decode(p_trans_type,'REFC','999','LACBC','999','LEXBC',rec.trans_loc_cd,p_loc_cd),                                            /*Added by Kanav on 08-Feb-2021 for DMSSAL-12760*/
           rec.trans_amt,
           rec.credit_pts,
           rec.transaction_id,
           rec.trans_parent_group,
           rec.trans_dlr_map_cd,
           rec.trans_loc_cd,
           p_user_id,
           sysdate,
           /*add_months(last_day(trunc(to_date(p_trans_date,
                                             'DD-MM-YYYY HH24:MI:SS'))),
                      lv_exp_months - 1),commented by saket as on 09-04-2021*/
           add_months(last_day(trunc(sysdate)),lv_exp_months - 1),  --Added by saket as on 09-04-2021
           lv_tier,
           --rec.credit_pts/2,  ----Added by saket as on 13-04-2020  Commented by saket as on 22-07-2020
           --rec.credit_pts/2   ----Added by saket as on 13-04-2020  Commented by saket as on 22-07-2020
--commented by saket as on 13-07-2021 aginst scr number DMSSAL-12832          decode(p_trans_type,'REFC',rec.credit_pts,'LACBC',rec.credit_pts,'LEXB',rec.credit_pts,rec.credit_pts*.75),  --Added by saket as on 22-07-2020    /*Added by Kanav on 08-Feb-2021 for DMSSAL-12760*/
--commented by saket as on 13-07-2021           decode(p_trans_type,'REFC',0,'LACBC',0,'LEXB',0,rec.credit_pts*.25),   --Added by saket as on 22-07-2020                      /*Added by Kanav on 08-Feb-2021 for DMSSAL-12760*/
           decode(p_trans_type,'REFC',0,'LACBC',0/*rec.credit_pts*//*Commented by veeresh on 19 july 2024 DMS-2134*/,'LEXB',rec.credit_pts,'LEXBC',0,/* LEXBC added by  veeresh on 08 JULY 2024  DMS-1898*/
           'MIC',decode(p_parent,'99999',decode(greatest(rec.trans_date,TO_DATE('13-JUL-2023')),TO_DATE('13-JUL-2023'),rec.credit_pts*.75,0)
                                ,rec.credit_pts*.75)   /* Added by veeresh 18 jul 2023    */
           ,rec.credit_pts*.75),  --Added by saket as on 13-07-2021  aginst scr number DMSSAL-12832 aginst scr number DMSSAL-12832
           decode(p_trans_type,'REFC',rec.credit_pts,'LACBC',rec.credit_pts/*0*//*Commented by veeresh on 19 july 2024 DMS-2134*/,'LEXB',0,'LEXBC',rec.credit_pts, /* LEXBC added by  veeresh on 08 JULY 2024  DMS-1898*/
           'MIC',decode(p_parent,'99999',decode(greatest(rec.trans_date,TO_DATE('13-JUL-2023')),TO_DATE('13-JUL-2023'),rec.credit_pts*.25,rec.credit_pts)
                                ,rec.credit_pts*.25)  /* Added by veeresh 18 jul 2023    */
           ,rec.credit_pts*.25),   --Added by saket as on 13-07-2021 aginst scr number DMSSAL-12832
           p_parent,           --Added by saket as on 08-08-2020
           p_dlr_map_cd,       --Added by saket as on 08-08-2020
           p_loc_cd,          --Added by saket as on 08-08-2020
           rec.trans_date  ---Added by nawal as on 07-JAN-2022
           );
        update gd_loyalty_trans
           set balance_points = balance_points - rec.credit_pts
            --Commented by saket as on 22-07-2020  ,security_amount_balance=security_amount_balance-rec.credit_pts  ----Added by saket as on 14-04-2020
            --Commented by saket as on 22-07-2020  ,liability_amount=liability_amount-rec.credit_pts  ----Added by saket as on 14-04-2020
              ,security_amount_balance=decode(p_trans_type,'REFC',0,'LACBC',0,'LEXB',0,'LEXBC',0,/* LEXBC added by  veeresh on 08 JULY 2024  DMS-1898*/
              'MIC',decode(p_parent,'99999',decode(greatest(rec.trans_date,TO_DATE('13-JUL-2023')),TO_DATE('13-JUL-2023'),security_amount_balance-rec.credit_pts*.25,security_amount_balance-rec.credit_pts)
                                ,security_amount_balance-rec.credit_pts*.25) /* Added by veeresh 18 jul 2023*/
              ,security_amount_balance-rec.credit_pts*.25) --Added by saket as on 22-07-2020        /*Added by Kanav on 08-Feb-2021 for DMSSAL-12760*/
              ,liability_amount=decode(p_trans_type,'REFC',0,'LACBC',0,'LEXB',0,'LEXBC',0,/* LEXBC added by  veeresh on 08 JULY 2024  DMS-1898*/
              'MIC',decode(p_parent,'99999',decode(greatest(rec.trans_date,TO_DATE('13-JUL-2023')),TO_DATE('13-JUL-2023'),liability_amount-rec.credit_pts*.75,0)
                                ,liability_amount-rec.credit_pts*.75) /* Added by veeresh 18 jul 2023*/
              ,liability_amount-rec.credit_pts*.75)  --Added by saket as on 22-07-2020                      /*Added by Kanav on 08-Feb-2021 for DMSSAL-12760*/
              ,updated_date = sysdate  --Added by saket as on 27-10-2021
              ,updated_by=p_user_id  --Added by saket as on 27-10-2021
         where rowid = rec.rid;
      end loop;
      /* Commented END IF  BLOCK TO INCLUDE  LEXBC  veeresh on 08 JULY 2024  DMS-1898*/ --END IF;
      --Added by saket as on 14-Aug-2020(start)
      /* Commented BELOW IF END BLOCK TO REMOVE LEXBC debit entry by  veeresh on 08 JULY 2024  DMS-1898*/
     /*  IF p_trans_type='LEXBC' THEN
       for rec in (select x.rowid rid, x.*
                    from gd_loyalty_trans x,gm_loy_trans_types x1
                   where card_num = p_card_num
                     and nvl(expired, 'N') = 'N'
                     and x.trans_num = p_trans_num
                     and decode(p_trans_type,'REFC',org_parent_group,'LACBC',org_parent_group,'LEXBC',org_parent_group,trans_parent_group) = p_parent                        \*Added by Kanav on 08-Feb-2021 for DMSSAL-12760*\
                     and decode(p_trans_type,'REFC',org_dlr_map_cd,'LACBC',org_dlr_map_cd,'LEXBC',org_dlr_map_cd,trans_dlr_map_cd) = p_dlr_map_cd                           \*Added by Kanav on 08-Feb-2021 for DMSSAL-12760*\
                     and decode(p_trans_type,'REFC',org_loc_cd,'LACBC',org_loc_cd,'LEXBC',org_loc_cd,trans_loc_cd) = p_loc_cd                                                \*Added by Kanav on 08-Feb-2021 for DMSSAL-12760*\
                     and credit_pts <> 0
                     and x.trans_type='LEXBC'
                     and x.trans_type=x1.trans_type
                     --and x1.trans_nature<>'C'
                     and transaction_id = lv_loy_trans_seq
                   order by transaction_id) loop
        INSERT INTO gd_loyalty_trans
          (transaction_id,
           card_num,
           vin,
           trans_type,
           trans_date,
           trans_num,
           remarks,
           trans_parent_group,
           trans_dlr_map_cd,
           trans_loc_cd,
           trans_amt,
           debit_pts,
           dr_transaction_id,
           dr_parent_group,
           dr_dlr_map_cd,
           dr_loc_cd,
           created_by,
           created_date,
           expiry_date,
           tier,
           liability_amount_debt,    ----Added by saket as on 13-04-2020
           security_amount_debt,     ----Added by saket as on 13-04-2020)
           org_parent_group,         --added by saket as on 08-08-2020
           org_dlr_map_cd,           --added by saket as on 08-08-2020
           org_loc_cd,               --added by saket as on 08-08-2020
           dr_trans_date ---Added by nawal as on 07-JAN-2022
           )
        VALUES
          (LOY_TRANS_SEQ.Nextval,
           p_card_num,
           p_vin,
           p_trans_type,
           --to_date(p_trans_date, 'DD-MM-YYYY HH24:MI:SS'), Commneted by saket as on 09-04-2021
           sysdate, --Added by saket as on 09-04-2021
           p_trans_num,
           'Points Revarsal Due To Transaction Cancellation',--p_remarks,\*DMS-1493 remarks hard coded by veeresh on 29 jan 2024*\
           '99999',
           99999,
           '999',
           rec.trans_amt,
           rec.credit_pts,
           rec.transaction_id,
           rec.trans_parent_group,
           rec.trans_dlr_map_cd,
           rec.trans_loc_cd,
           p_user_id,
           sysdate,
           \*add_months(last_day(trunc(to_date(p_trans_date,
                                             'DD-MM-YYYY HH24:MI:SS'))),
                      lv_exp_months - 1),commented by saket as on 09-04-2021*\
           add_months(last_day(trunc(sysdate)),lv_exp_months - 1),  --Added by saket as on 09-04-2021
           lv_tier,
           --rec.credit_pts/2,  ----Added by saket as on 13-04-2020  Commented by saket as on 22-07-2020
           --rec.credit_pts/2   ----Added by saket as on 13-04-2020  Commented by saket as on 22-07-2020
           decode(p_trans_type,'REFC',rec.credit_pts,'LACBC',rec.credit_pts,'LEXB',rec.credit_pts,rec.credit_pts*.75),  --Added by saket as on 22-07-2020                    \*Added by Kanav on 08-Feb-2021 for DMSSAL-12760*\
           decode(p_trans_type,'REFC',0,'LACBC',0,'LEXB',0,rec.credit_pts*.25),   --Added by saket as on 22-07-2020                \*Added by Kanav on 08-Feb-2021 for DMSSAL-12760*\
           p_parent,           --Added by saket as on 08-08-2020
           p_dlr_map_cd,       --Added by saket as on 08-08-2020
           p_loc_cd,          --Added by saket as on 08-08-2020
           rec.trans_date ---Added by nawal as on 07-JAN-2022
           );
        update gd_loyalty_trans
           set balance_points = balance_points - rec.credit_pts
            --Commented by saket as on 22-07-2020  ,security_amount_balance=security_amount_balance-rec.credit_pts  ----Added by saket as on 14-04-2020
            --Commented by saket as on 22-07-2020  ,liability_amount=liability_amount-rec.credit_pts  ----Added by saket as on 14-04-2020
              ,security_amount_balance=decode(p_trans_type,'REFC',0,'LACBC',0,'LEXB',0,security_amount_balance-rec.credit_pts*.25)  --Added by saket as on 22-07-2020  \*Added by Kanav on 08-Feb-2021 for DMSSAL-12760*\
              ,liability_amount=decode(p_trans_type,'REFC',0,'LACBC',0,'LEXB',0,liability_amount-rec.credit_pts*.75)  --Added by saket as on 22-07-2020    \*Added by Kanav on 08-Feb-2021 for DMSSAL-12760*\
              ,updated_date = sysdate  --Added by saket as on 27-10-2021
              ,updated_by=p_user_id  --Added by saket as on 27-10-2021
         where rowid = rec.rid;
      end loop;
      END IF;*/
      --Added by saket as on 14-Aug-2020(end)
    END IF;

    BEGIN
      sp_calculate_bal_points(p_card_num,
                              lv_bal_points,
                              p_error_cd,
                              p_error_msg);
      IF p_error_cd <> 0 THEN
        p_error_cd  := 1;
        p_error_msg := 'Error in Calculating Balance Points : ' ||
                       p_error_msg;
      END IF;
    END;
  EXCEPTION
    WHEN others THEN
      p_error_cd  := 1;
      p_error_msg := substr(sqlerrm, 1, 100);
  END sp_ins_loyalty_transactions;
```

#### SP-030 - PKG_LOYALTY.SP_RED_RESTRICTION_BAL_POINTS

**Invoked From:**

- PKG_LOYALTY.pck [StoredProcedure: PKG_LOYALTY.SP_INS_LOYALTY_TRANSACTIONS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the current restricted (redemption-restricted) points balance for a loyalty card, taking into account any restriction window rules that prevent recently earned points from being redeemed immediately.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_card_num | varchar2 | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_bal_points | number | OUT |
| p_error_cd | number | OUT |
| p_error_msg | varchar2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Retrieve the loyalty card number and restriction hours from the loyalty configuration.
- Step 2 - Sum all loyalty credit transactions within the restriction window (earned within the last N hours, where N is the restriction period).
- Step 3 - Subtract the restricted points from the total balance to compute the available (unrestricted) balance.
- Step 4 - Return the unrestricted balance as `p_bal_points`.
- Step 5 - Return error code 0 on success or a non-zero error code with message on failure.

---
**Decision Points**

DP-001

Condition:
Restriction hours configuration exists for the card type.

TRUE:
Apply the restriction window to exclude recently earned points from the redeemable balance.

FALSE:
Return the full balance without restriction.

---
**Database Interactions**

- DB-001 - Read AM_LIST - Reads data from AM_LIST for lookup or validation.
- DB-002 - Read GD_LOYALTY_TRANS - Reads data from GD_LOYALTY_TRANS for lookup or validation.
**Business Rules**

BR-001 - Points earned within the restriction window cannot be redeemed; only points older than the restriction period are considered redeemable.
BR-002 - The restriction period (hours) is configurable per card type.

---
**Implementation Logic**

```plsql
  PROCEDURE sp_red_restriction_bal_points(p_card_num   in varchar2,
                                          p_bal_points out number,
                                          p_error_cd   out number,
                                          p_error_msg  out varchar2) IS
    lv_card_num        gd_loyalty_enrol.card_num%type;
    lv_res_hours       number;
  BEGIN
    p_error_cd := 0;
    BEGIN
      select list_desc
        into lv_res_hours
        from am_list
       where list_name='LOYL_RED_RES_HRS'
         and principal_map_cd=1
         and list_code='RRH'
         and nvl(list_flag,'Y')='Y';
    EXCEPTION
      when others then
          lv_res_hours:=0;
    END;
    BEGIN
      Select nvl(sum(balance_points), 0)
        into p_bal_points
        from gd_loyalty_trans
       where card_num = p_card_num
         and trans_date <= sysdate-(lv_res_hours/24)-1/(24*60*60)
         AND nvl(expired, 'N') = 'N';
    END;

  EXCEPTION
    WHEN others THEN
      p_error_cd  := 1;
      p_error_msg := substr(sqlerrm, 1, 100);
  END sp_red_restriction_bal_points;
```

#### SP-031 - PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM

**Invoked From:**

- vt_amc_cncl_fmb.xml [ProgramUnit: SP_INSERT_CHARGES]
- vt_amc_cncl_fmb.xml [StoredProcedure: SP_INSERT_CHARGES]

---

**Screen:**

Package Details (N/A / CN_MAIN)

---

**Purpose**

Generates the next sequential document number for a specified document type (such as "ACR" for credit notes) in a specific dealer/location/financial area context, with optional back-date validation. Ensures unique, sequential numbering of financial documents such as cancellation credit notes.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| pi_dealer_map_cd | NUMBER | IN |
| pi_principal_map_cd | NUMBER | IN |
| pi_loc_cd | VARCHAR2 | IN |
| pi_comp_fa | VARCHAR2 | IN |
| pi_doc_type | VARCHAR2 | IN |
| pi_fin_yr | NUMBER | IN |
| pi_last_doc_date | DATE | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| po_doc_num | VARCHAR2 | OUT |
| po_err_msg | VARCHAR2 | OUT |
| po_error | NUMBER | OUT |

---

**Dependencies**

- WEBUTIL.PUT_LINE ([SP-039](#SP-039--WEBUTIL.PUT_LINE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.WAIT ([SP-042](#SP-042--WEBUTIL.WAIT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Validate the supplied cancellation/document date against back-date restrictions for the dealer and document type.
- Step 2 - If the date is invalid (back-dated beyond the allowed period), return a non-zero error code with an appropriate message.
- Step 3 - If the date is valid, retrieve the current sequence counter for the document type, dealer, location, financial area, and financial year.
- Step 4 - Increment the counter and construct the formatted document number.
- Step 5 - Update the sequence counter in the database.
- Step 6 - Return the generated document number via the OUT parameter.

---
**Decision Points**

DP-001

Condition:
The supplied date passes back-date validation rules.

TRUE:
Generate and return the next sequential document number.

FALSE:
Return a non-zero error code and message indicating the back-date violation.

---
**Database Interactions**

- DB-001 - Read AM_DOCS - Reads data from AM_DOCS (columns: doc num, last doc date) for lookup or validation.
- DB-002 - Update WAIT - Updates existing rows in WAIT.
- DB-003 - Update AM_DOCS - Updates existing rows in AM_DOCS (columns: doc num, last doc date).
**Business Rules**

BR-001 - Document numbers must be sequentially generated per document type, dealer, location, financial area, and financial year.
BR-002 - Back-dated document generation is subject to configurable restrictions; dates beyond the allowed back-date window are rejected.
BR-003 - The calling procedure must check the returned error code and abort if non-zero.

---
**Implementation Logic**

```plsql
      PROCEDURE Generate_Next_Num (
            pi_dealer_map_cd      IN       NUMBER,
            pi_principal_map_cd   IN       NUMBER,
            pi_loc_cd             IN       VARCHAR2,
            pi_comp_fa            IN       VARCHAR2,
            pi_doc_type           IN       VARCHAR2,
            po_doc_num            OUT      VARCHAR2,
            po_err_msg            OUT      VARCHAR2,
            po_error              OUT      NUMBER,
            pi_fin_yr             IN       NUMBER,
            pi_last_doc_date      IN       DATE DEFAULT SYSDATE
      )
      IS
            lv_doc_prefix   VARCHAR2 (4);
            lv_doc_num      NUMBER (6);
            lv_doc_suffix   VARCHAR2 (2);
            lock_found      EXCEPTION;
            lv_year         VARCHAR2 (1);
            lv_rowid        ROWID;
            PRAGMA EXCEPTION_INIT (lock_found, -54);
            v_sql           VARCHAR2 (2000);
      BEGIN

            BEGIN

                  SELECT     doc_prefix,
                             doc_num,
                             doc_suffix,
                             ROWID
                        INTO lv_doc_prefix,
                             lv_doc_num,
                             lv_doc_suffix,
                             lv_rowid
                        FROM AM_DOCS
                       WHERE dealer_map_cd = pi_dealer_map_cd
                         AND principal_map_cd = pi_principal_map_cd
                         AND loc_cd = pi_loc_cd
                         AND comp_fa = pi_comp_fa
                         AND doc_type = pi_doc_type
                         AND Fin_Year = pi_fin_yr
                  FOR UPDATE WAIT 5;
            EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                        po_error := 1;
                        po_err_msg := po_err_msg || ' Type not defined in the document master';
                  WHEN TOO_MANY_ROWS THEN
                        po_error := 1;
                        po_err_msg := po_err_msg || ' Duplicate rows in the document master';
                  WHEN OTHERS THEN
                        po_error := 1;

                        IF SQLCODE = -54 THEN                                                             ---IN (-30006,-54) THEN
                              po_err_msg := 'Record is used by another user.Please Re-try';
                        ---RAISE_APPLICATION_ERROR(-54,'Record is used by another user.Please Re-try');
                        ELSE
                              po_err_msg := 'Execution failed while trying to access the record ' || SQLERRM;
                        END IF;
            END;

            /*EXECUTE IMMEDIATE v_sql
                         INTO lv_doc_prefix,
                              lv_doc_num,
                              lv_doc_suffix,
                              lv_rowid
                        USING pi_dealer_map_cd, pi_principal_map_cd, pi_loc_cd, pi_comp_fa, pi_doc_type, pi_fin_yr;*/
            IF NVL ( po_error, 0) <> 1 THEN
                  lv_doc_num := lv_doc_num + 1;
                  po_doc_num := lv_doc_prefix || lv_doc_suffix || LPAD (lv_doc_num, 6, '0');

                  UPDATE AM_DOCS
                     SET doc_num = lv_doc_num,
                         last_doc_date = pi_last_doc_date
                   WHERE ROWID = lv_rowid;
            END IF;
      EXCEPTION
            WHEN NO_DATA_FOUND THEN
                  po_error := 1;
                  po_err_msg := po_err_msg || ' Type not defined in the document master';
            WHEN TOO_MANY_ROWS THEN
                  po_error := 1;
                  po_err_msg := po_err_msg || ' Duplicate rows in the document master';
            WHEN OTHERS THEN
                  po_error := 1;
                  po_err_msg := po_err_msg || SQLERRM;
                  DBMS_OUTPUT.put_line ('ERRORCD' || po_error);
      END Generate_Next_Num;
```

#### SP-032 - WEBUTIL.ERRORALERT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.PUT_LINE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Displays a WebUtil error message in a modal alert dialog. Used internally by WebUtil infrastructure to surface bean-not-registered and similar framework errors to the end user.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| errText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-037](#SP-037--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Verify that the error alert handle (`m_errorAlert`) is not null.
- Step 2 - Set the alert message text to the supplied error text.
- Step 3 - Show the alert to the user.

---
**Decision Points**

DP-001

Condition:
`m_errorAlert` handle is not null (alert object exists).

TRUE:
Set the message text and show the alert.

FALSE:
Do nothing - no error alert configured.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

BR-001 - WebUtil errors must always be surfaced to the user when the error alert is configured.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ErrorAlert(errText in VARCHAR2) is
    -- currently used for throwing a BEAN_NOT_REGISTERED or bean not found error.
    ignore integer;
  begin
    if not ID_NULL(m_errorAlert) then 
      --SET_ALERT_PROPERTY(m_errorAlert,TITLE,'WebUtil Error'); -- title already set in alert property
      SET_ALERT_PROPERTY(m_errorAlert,ALERT_MESSAGE_TEXT,errText);
      ignore := SHOW_ALERT(m_errorAlert);
    else
      message('WebUtil Error'||': '||errText);
    end if;
  end ErrorAlert;
```

#### SP-033 - WEBUTIL.FCLOSE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open client-side text file via the WebUtil file I/O bean, releasing the file handle. After closing, the file handle is set to NULL to prevent accidental reuse.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Check whether the file handle is not null (file is open).
- Step 2 - Send a close command to the WebUtil file I/O bean with the file handle.
- Step 3 - Set the file handle to NULL.

---
**Decision Points**

DP-001

Condition:
File handle is not null (file is open).

TRUE:
Close the file via the WebUtil bean and null the handle.

FALSE:
Do nothing - file is already closed.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

BR-001 - File handles must always be nulled after closing to prevent reuse of a closed handle.

---
**Implementation Logic**

```plsql
 
  PROCEDURE fclose (file IN OUT file_type) is 
  BEGIN 
    if (file.handle IS NOT NULL) then 
      WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CLOSE',file.handle);        
      file.handle := NULL;
    end if;
 
 EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.fclose will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;
  END fclose;
```

#### SP-034 - WEBUTIL.FOPEN

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Opens a client-side text file in the specified mode (read "r", write "w", or append "a") via the WebUtil file I/O bean. Validates the mode and filename, transmits the open request to the WebUtil bean using property set/get calls (including a call to WEBUTIL.GETPROPERTY to retrieve the resulting Java file handle), and returns a typed file handle object for use in subsequent client-side text I/O operations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| spec | VARCHAR2 | IN |
| filemode | VARCHAR2 | IN |
| charSet | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETPROPERTY ([SP-036](#SP-036--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Validate that the file mode (case-insensitive) is one of "r", "w", or "a"; raise `TOOL_ERR.TOOL_ERROR` if the value is not recognised.
- Step 2 - Validate that the file specification (filename) is non-null and non-empty; raise `TOOL_ERR.TOOL_ERROR` if either condition fails.
- Step 3 - Push the filename, file mode, and charset (or the literal "(null)" when no charset is supplied) to the WebUtil bean as named properties via `WebUtil_Core.setProperty`.
- Step 4 - Invoke `WebUtil_Core.getProperty` (aligned with WEBUTIL.GETPROPERTY) to retrieve the Java file handle string returned by the bean after processing the open request.
- Step 5 - Evaluate the returned handle: if it is null, empty, or equal to "-1", raise `TOOL_ERR.TOOL_ERROR` to signal that the file could not be opened.
- Step 6 - Convert the valid handle string to a number, assign it to the `file_type.handle` field, and return the populated file handle object to the caller.

---
**Decision Points**

DP-001

Condition:
File mode (lowercased) is one of "r", "w", or "a".

TRUE:
Proceed to validate the filename.

FALSE:
Raise `TOOL_ERR.TOOL_ERROR` - unsupported file mode.

DP-002

Condition:
File specification is non-null and non-empty.

TRUE:
Push filename, mode, and charset properties to the WebUtil bean.

FALSE:
Raise `TOOL_ERR.TOOL_ERROR` - no filename specified.

DP-003

Condition:
Charset parameter is null.

TRUE:
Set the WUF_TEXTIO_CHARSET bean property to the literal string "(null)".

FALSE:
Set the WUF_TEXTIO_CHARSET bean property to the supplied charset value.

DP-004

Condition:
Java handle returned by WEBUTIL.GETPROPERTY (WUF_TEXTIO_OPEN) is null, empty, or "-1".

TRUE:
Raise `TOOL_ERR.TOOL_ERROR` - the bean failed to open the file.

FALSE:
Convert the handle to a number, populate the `file_type` record, and return it.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

BR-001 - Only read ("r"), write ("w"), and append ("a") modes are supported; the comparison is case-insensitive.
BR-002 - A filename must always be specified; null or empty filenames are rejected before any bean interaction occurs.
BR-003 - When no charset is provided, the literal value "(null)" must be passed to the bean property WUF_TEXTIO_CHARSET to explicitly signal the absence of a charset.
BR-004 - A Java handle value of null, empty string, or "-1" is treated as a failed open and must result in `TOOL_ERR.TOOL_ERROR` being raised.
BR-005 - If the WebUtil bean is not registered (`BEAN_NOT_REGISTERED`), an error alert identifying the missing implementation class is displayed before re-raising `TOOL_ERR.TOOL_ERROR`.
BR-006 - A `VALUE_ERROR` encountered during handle conversion must be re-raised as `TOOL_ERR.TOOL_ERROR` to maintain a consistent error contract with the caller.

---
**Implementation Logic**

```plsql
  FUNCTION fopen(spec VARCHAR2, filemode VARCHAR2, charSet VARCHAR2 := null) RETURN file_type is
    clientFile file_type;
    javaHandle VARCHAR2(6);
  BEGIN
    -- check the mode is valid
    if (lower(filemode) not in ('r','w','a')) then 
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- make sure a file name has been specified      
    if (spec is null) or (spec='') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;
      
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILENAME',spec, true);
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_FILEMODE',filemode, true);        
    if (charSet is null) then
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET','(null)', true);
    else
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET',charSet, true);
    end if;
    javaHandle := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_OPEN');

    -- If the return is null then the file was not opened      
    if (javaHandle is null) or (javaHandle='') or (javaHandle='-1') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- if we are this far convert the handle to the correct format and return it.      
    clientFile.handle := to_number(javaHandle);
    return clientFile;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.fopen will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                 
      return null;
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE;
    when VALUE_ERROR then
      RAISE TOOL_ERR.TOOL_ERROR; 
    when TOOL_ERR.TOOL_ERROR then 
      RAISE;
  END fopen;
```

#### SP-035 - WEBUTIL.GETIMPLCLASS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.PUT_LINE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the fully qualified Java implementation class name for a given WebUtil package ID. Used internally to construct error messages that identify the specific WebUtil bean implementation that failed.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Concatenate the WebUtil Java root path with the implementation class name from the `m_implClasses` index for the supplied package ID.
- Step 2 - Return the fully qualified class name.

---
**Decision Points**

No branching decision points identified in the implementation logic.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

BR-001 - Each WebUtil package has a registered implementation class; the mapping is set up during `InitWebUtil`.

---
**Implementation Logic**

```plsql

  FUNCTION getImplClass(packageID PLS_INTEGER) return VARCHAR2 is
  BEGIN 
    return WEBUTIL_JAVA_ROOT||m_implClasses(packageID);    
  END;
```

#### SP-036 - WEBUTIL.GETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FOPEN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a JVM system property value using the Java Native Interface (JNI). A thin wrapper around `java.lang.System.getProperty()` that allows Oracle Forms to access JVM-level system properties on the client.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Create a JNI argument list with one argument.
- Step 2 - Add the property name string as the argument.
- Step 3 - Call the Java `System.getProperty` method via JNI.
- Step 4 - Return the property value string.

---
**Decision Points**

No branching decision points identified in the implementation logic.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

BR-001 - Returns NULL if the property is not set in the JVM.

---
**Implementation Logic**

```plsql
  FUNCTION getProperty(
    a0    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'getProperty', '(Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-037 - WEBUTIL.ID_NULL

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.ERRORALERT]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTER_FUNCTION]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Tests whether a WebUtil handle (pointer) is null/uninitialised. Returns TRUE if the handle's `hnd` member is null, FALSE otherwise. Used throughout WebUtil to check whether objects have been properly created before use.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| handle | Pointer | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Check whether the `hnd` member of the supplied handle is null.
- Step 2 - Return TRUE if null, FALSE if not null.

---
**Decision Points**

DP-001

Condition:
`handle.hnd` is null.

TRUE:
Return TRUE - handle is uninitialised/null.

FALSE:
Return FALSE - handle is valid.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

BR-001 - All WebUtil handles should be validated with `ID_NULL` before use to prevent null pointer errors.

---
**Implementation Logic**

```plsql

  FUNCTION ID_NULL(handle IN Pointer)        RETURN BOOLEAN is
  BEGIN
    if handle.hnd is null then 
      return TRUE;
    else
      return FALSE;
    end if;
  END ID_NULL;
```

#### SP-038 - WEBUTIL.LENGTH

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]
- FNC_VERIF_MOBILE.fnc [StoredProcedure: FNC_VERIF_MOBILE]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- SP_PUSH_DMS_MESSAGE.prc [StoredProcedure: SP_PUSH_DMS_MESSAGE]
- SP_VALIDATE_ALPHANUMERIC.prc [StoredProcedure: SP_VALIDATE_ALPHANUMERIC]
- D2kwutil.pld [StoredProcedure: STRIPDIRSEP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the byte length of a file represented by a Java File object via the JNI interface. A low-level utility to determine file size from the Java layer.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Create a JNI argument list with two arguments (long and int types).
- Step 2 - Add the length arguments.
- Step 3 - Call the Java `File.length()` method via JNI on the supplied file object.
- Step 4 - Return the file length as a NUMBER.

---
**Decision Points**

No branching decision points identified in the implementation logic.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

BR-001 - Returns 0 if the file does not exist or if the length cannot be determined.

---
**Implementation Logic**

```plsql
  FUNCTION length(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_LONG_METHOD(FALSE, obj, 'java/io/File', 'length', '()J', args); 
  END;
```

#### SP-039 - WEBUTIL.PUT_LINE

**Invoked From:**

- PK_VALIDATE_BACK_DATE.pck [StoredProcedure: PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a line of text (followed by a newline) to an open client-side text file via the WebUtil file I/O bean.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |
| item | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-032](#SP-032--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETIMPLCLASS ([SP-035](#SP-035--WEBUTIL.GETIMPLCLASS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETPROPERTY ([SP-041](#SP-041--WEBUTIL.SETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Set the file handle on the WebUtil file I/O package.
- Step 2 - Write the text string to the file via the WebUtil bean.
- Step 3 - Signal a newline after the text.

---
**Decision Points**

No branching decision points identified in the implementation logic.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

BR-001 - A newline is always appended after the written text.

---
**Implementation Logic**

```plsql
    

  PROCEDURE put_line (file file_type, item VARCHAR2) is
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);              
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_PUT',item); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_NEWLINE',1); 
  EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.put_line will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;  
  END put_line;
```

#### SP-040 - WEBUTIL.REGISTER_FUNCTION

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a native library function with WebUtil by composing a function specification and submitting it to the WebUtil core bean. Returns a FunctionHandle that uniquely identifies the registered function for use in subsequent invocation calls. Increments the internal function-handle counter when a valid handle is obtained.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| libName | VARCHAR2 | IN |
| funcName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-037](#SP-037--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Concatenate the input library name and function name into a pipe-delimited specification string (libName || '|' || funcName).
- Step 2 - Write the specification string to the WebUtil core bean by calling WebUtil_Core.setProperty with the WUL_PACKAGE target and property key WUL_FUNCTION_SPEC.
- Step 3 - Retrieve the raw string handle from the bean by calling WebUtil_Core.getProperty with property key WUL_REGISTER_FUNCTION.
- Step 4 - Convert the raw string handle to a numeric value and store it in the FunctionHandle record field (funcHnd.hnd).
- Step 5 - Evaluate the resulting handle using ID_NULL (SP-037); if the handle is not null, increment the module-level function-handle counter (m_funcHandleCount).
- Step 6 - Return the populated FunctionHandle to the caller.

---
**Decision Points**

DP-001

Condition:
ID_NULL(funcHnd) returns FALSE (i.e., the bean returned a valid, non-null handle).

TRUE:
Increment m_funcHandleCount by 1 and return the FunctionHandle.

FALSE:
Skip counter increment; return the FunctionHandle as-is (null handle).

---

DP-002

Condition:
WebUtil_Core raises BEAN_NOT_REGISTERED during the setProperty or getProperty calls.

TRUE:
Display an error alert identifying the missing bean class and raise FORM_TRIGGER_FAILURE to abort processing.

FALSE:
Continue normal execution.

---

DP-003

Condition:
WebUtil_Core raises PROPERTY_ERROR during the setProperty or getProperty calls.

TRUE:
Raise FORM_TRIGGER_FAILURE to abort processing.

FALSE:
Continue normal execution.

---

DP-004

Condition:
TO_NUMBER conversion of the raw string handle raises VALUE_ERROR.

TRUE:
Raise TOOL_ERR.TOOL_ERROR to signal an invalid handle value.

FALSE:
Continue normal execution.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

BR-001 - A function must be registered via REGISTER_FUNCTION before it can be invoked; the returned FunctionHandle is the required token for any subsequent invocation call.

BR-002 - The function specification submitted to the bean must follow the exact format libName|funcName; deviating from this format will produce an unusable or null handle.

BR-003 - The internal function-handle counter (m_funcHandleCount) is incremented only when ID_NULL confirms the returned handle is valid; null handles do not contribute to the count.

BR-004 - If the WebUtil bean is not registered in the form, function registration cannot proceed and the form trigger is failed immediately after alerting the user with the missing bean class name.

BR-005 - A VALUE_ERROR during numeric conversion of the raw handle string is treated as a hard error and surfaces as TOOL_ERR.TOOL_ERROR, preventing a corrupt handle from being returned to the caller.

---
**Implementation Logic**

```plsql

  FUNCTION REGISTER_FUNCTION (libName IN VARCHAR2, funcName IN VARCHAR2) 
                              RETURN FunctionHandle IS
    strHnd  VARCHAR2(8);                            
    funcHnd FunctionHandle;
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUL_PACKAGE,'WUL_FUNCTION_SPEC', libName || '|' || funcName);
    strHnd := WebUtil_Core.getProperty(WebUtil_Core.WUL_PACKAGE,'WUL_REGISTER_FUNCTION');
    funcHnd.hnd := TO_NUMBER (strHnd);
    if NOT ID_NULL(funcHnd) then
      m_funcHandleCount := m_funcHandleCount + 1;
    end if;

    RETURN funcHnd;
    
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUL_PACKAGE)
                              ||' bean not found. WEBUTIL_C_API.REGISTER_FUNCTION will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;  
    when VALUE_ERROR then
        RAISE TOOL_ERR.TOOL_ERROR; 
  END REGISTER_FUNCTION;
```

#### SP-041 - WEBUTIL.SETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.PUT_LINE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sets a JVM system property to the specified value using the Java Native Interface (JNI). A thin wrapper around `java.lang.System.setProperty()` that allows Oracle Forms to set JVM-level properties on the client.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |
| a1 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Create a JNI argument list with two string arguments (property name and value).
- Step 2 - Call `java.lang.System.setProperty` via JNI.
- Step 3 - Return the previous value of the property (as returned by the Java method).

---
**Decision Points**

No branching decision points identified in the implementation logic.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

BR-001 - Returns the previous value of the property, or null if it was not previously set.

---
**Implementation Logic**

```plsql
  FUNCTION setProperty(
    a0    VARCHAR2,
    a1    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(2);
    JNI.ADD_STRING_ARG(args, a0);
    JNI.ADD_STRING_ARG(args, a1);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'setProperty', '(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-042 - WEBUTIL.WAIT

**Invoked From:**

- PK_VALIDATE_BACK_DATE.pck [StoredProcedure: PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sends a timed wait to a Java file writer object via JNI, allowing synchronisation with asynchronous file write operations on the client. Delegates to the `oracle/forms/webutil/fileTransfer/AppServerFileWriter.wait` Java method.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |
| a0 | NUMBER | IN |
| a1 | NUMBER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Create a JNI argument list with two numeric arguments (long and int).
- Step 2 - Add the wait time arguments.
- Step 3 - Call the Java `AppServerFileWriter.wait` method via JNI on the supplied object.

---
**Decision Points**

No branching decision points identified in the implementation logic.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

BR-001 - Used for synchronising with asynchronous file transfer operations; the exact wait semantics are determined by the Java implementation.

---
**Implementation Logic**

```plsql
  PROCEDURE wait(
    obj   ORA_JAVA.JOBJECT,
    a0    NUMBER,
    a1    NUMBER) IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(2);
    JNI.ADD_LONG_ARG(args, a0);
    JNI.ADD_INT_ARG(args, a1);
    JNI.CALL_VOID_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileWriter', 'wait', '(JI)V', args); 
  END;
```

#### SP-043 - ADD_ERROR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.FILE_INFO]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Records an error in the WIN_API error stack by setting the ERROR_ENCOUNTERED flag to TRUE and storing the formatted error text. Used by the D2KWUTIL infrastructure (FILE_INFO, REGISTER_FUNCTION_CALL, WINDEBUG) to accumulate error information when native API calls fail, and logs the error via DEBUGLOG.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| CallingFunction | VARCHAR2 | IN |
| SetErrorText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-047](#SP-047--DEBUGLOG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Set the ERROR_ENCOUNTERED package-level flag to TRUE to signal that an error condition exists.
- Step 2 - Format and store the error text in ERROR_STACK as "CallingFunction: SetErrorText", truncating SetErrorText to a maximum of 1968 characters.
- Step 3 - Log the formatted error string at debug level 99 by invoking Win_API_Debug.DebugLog (SP-047), identifying the originating routine as 'Add_Error'.

---
**Decision Points**

No branching decision points identified in the implementation logic.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only one error message is retained in the error stack at a time; each call to ADD_ERROR overwrites the previous ERROR_STACK value.
- BR-002 - Error text supplied in SetErrorText is truncated at 1968 characters before being written to ERROR_STACK.
- BR-003 - Every error recorded must be logged at debug level 99 via DEBUGLOG (SP-047); logging is unconditional and not dependent on any external debug flag at this procedure level.

---
**Implementation Logic**

```plsql

PROCEDURE Add_Error (CallingFunction in VARCHAR2, SetErrorText in VARCHAR2) is
begin 
  -- Just watch for value errors 
  ERROR_ENCOUNTERED  := TRUE;
  ERROR_STACK    := CallingFunction||': '||substr(SetErrorText,1,1968);
  Win_API_Debug.DebugLog(99,'Add_Error',ERROR_STACK);
end Add_Error;
```

#### SP-044 - ADD_EXTERNAL_ERRORS

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.FILE_INFO]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Collects and returns any external error messages from the `TOOL_ERR` error buffer as a concatenated string. Used to append external (non-WIN_API) error messages to WIN_API error reports.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Check whether `TOOL_ERR` has any errors (`nerrors > 0`).
- Step 2 - If yes, iterate through all error messages and concatenate them (one per line).
- Step 3 - Return the concatenated error string, or empty string if no errors.

---
**Decision Points**

DP-001

Condition:
`tool_err.nerrors > 0` (external errors exist).

TRUE:
Concatenate all error messages and return the string.

FALSE:
Return an empty string - no external errors.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

BR-001 - Concatenation stops if the result would exceed the buffer length (VALUE_ERROR exception is caught and the loop exits).

---
**Implementation Logic**

```plsql

FUNCTION Add_External_Errors return varchar2 is
  iCounter   pls_integer;
  vcErrBuff  varchar2(1968);
begin 
  if tool_err.nerrors > 0 then 
    for iCounter in 1..tool_err.nerrors LOOP
      begin 
        vcErrBuff := vcErrBuff||chr(10)||tool_err.message;
      exception
        when VALUE_ERROR then 
          exit; /* String exceeds allowable buffer */
      end;
      tool_err.pop;
    end loop;
  elsif SQLERRM is not null then 
    vcErrBuff := chr(10)||SQLERRM; 
  end if;
  return vcErrBuff;
end Add_External_Errors;
```

#### SP-045 - BOOLTOCHAR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.FILE_INFO]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Converts a PL/SQL BOOLEAN value to its VARCHAR2 string representation, returning either 'TRUE' or 'FALSE'. The function is invoked from D2KWUTIL.FILE_INFO (D2kwutil.pld) to support contexts where a boolean value must be expressed as readable text.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| ThisBoolean | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept a single BOOLEAN input parameter (ThisBoolean).
- Step 2 - Evaluate the boolean value using a PL/SQL IF condition.
- Step 3 - If the condition evaluates to TRUE, return the VARCHAR2 literal 'TRUE'.
- Step 4 - If the condition does not evaluate to TRUE (including NULL), return the VARCHAR2 literal 'FALSE'.

---
**Decision Points**

DP-001

Condition:
ThisBoolean evaluates to TRUE.

TRUE:
Return the VARCHAR2 string 'TRUE'.

FALSE:
Return the VARCHAR2 string 'FALSE'.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function returns exactly one of two possible string values: 'TRUE' or 'FALSE'; no other output is produced.
- BR-002 - A NULL BOOLEAN input is treated as FALSE by the PL/SQL IF construct and therefore returns 'FALSE'.
- BR-003 - The function has no external or internal dependencies; all logic is self-contained within the function body.

---
**Implementation Logic**

```plsql

  
  FUNCTION  BoolToChar(ThisBoolean IN BOOLEAN) return VARCHAR2 is
  begin
  	if ThisBoolean then 
  		RETURN 'TRUE';
  	else
  	    RETURN 'FALSE';
  	end if;
  end BoolToChar;

END;

PACKAGE WIN_API_DIALOG IS

/*-------------------------------------------------------------------------*\
 * WIN_API_DIALOG ->   This package is concerned with Displaying Common
 *      dialogs
 * Contents:
 *    Open_File    -> Open File Dialog
 *    Save_File    -> Save File Dialog
 *    Select_Printer    -> Printer Selection Dialog
 *    Choose_Font       -> Display the Font Selection Dialog
 *    Choose_Color      -> Display the Color Selection Dialog
 * Dependancies:
 *    WIN_API_ENVIRONMENT
 *    WIN_API
 *    WIN_API_DEBUG
\*-------------------------------------------------------------------------*/ 

/*-------------------------------------------------------------------------*\
 * Open_File        -> Displays the standard Open File dialog
 * Arguments: 
 *  Title           -> The Title for the Dialog Box
 *                     (Default -> 'Open File')
 *  StartDirectory  -> Where the dialog should start from
 *                     this should be in the format 'C:\TEMP'
 *                     (Default -> Windows Directory)
 *  FileFilter      ->  Restrict the list of files. The filter string 
 *                      should be in the format:
 *                      '<Description>|<filename>.<Extension>|'
 *                      typically this would be something like
 *                      'All files(*.*)|*.*|' or 'Text files(*.txt)|*.txt|'
 *                      "All Files" is the Default
 *  Modal           ->  Should the dialog be modal with respect to the 
 *                      application? 
 *                      default = TRUE
 *  AdvancedFlags   ->  (See list in WIN_API header) This option allows
 *                      you to change the attributes of the Open File 
 *                      dialog.  Here are some of the Flags that might
 *                      be of interest:
 *                      OFN_HIDEREADONLY  Hides the Read Only check box.
 *                      OFN_NONETWORKBUTTON  Hides the Network Button
 *                      OFN_EXPLORER    Display an Explorer style 
 *                        Dialog rather than the conventional one.
 *                      See your Microsoft docmentation for details on 
 *                      each flag.
 *                      To Set the Advanced_Flags varaible, just add the 
 *                      required flags together.  The default is:
 *                      WIN_API.OFN_PATHMUSTEXIST + WIN_API.OFN_FILEMUSTEXIST +
 *                      WIN_API.OFN_HIDEREADONLY + WIN_API.OFN_NOCHANGEDIR 
 *  RaiseExceptions ->  TRUE of FALSE(Default) If set to true, then if the 
 *                      command is not successful (e.g no filename is  
 *                      returned) then the explicit exception
 *                      NO_DATA_FOUND will be raised.
 *        
 * Returns:
 *  Path and name of the selected file
\*-------------------------------------------------------------------------*/
```

#### SP-046 - CLEAN_ERROR_STACK

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.FILE_INFO]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Resets the WIN_API error stack by clearing the `ERROR_ENCOUNTERED` flag and setting the error stack text to NULL. Called before a new native API call sequence to ensure any previous errors do not interfere.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Set `ERROR_ENCOUNTERED` to FALSE.
- Step 2 - Set `ERROR_STACK` to NULL.

---
**Decision Points**

No branching decision points identified in the implementation logic.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

BR-001 - The error stack must always be cleaned before a new native API call to prevent false-positive error detection.

---
**Implementation Logic**

```plsql

PROCEDURE Clean_Error_Stack is 
begin 
  -- just empty the variables
  ERROR_ENCOUNTERED  := FALSE;
  ERROR_STACK        := NULL;
end Clean_Error_Stack;
```

#### SP-047 - DEBUGLOG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: ADD_ERROR]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.FILE_INFO]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: SETDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a formatted diagnostic log entry to either a debug window or a flat file, depending on the active debug output mode. Applies three-stage filtering (state, pause, level) before constructing and routing the entry, and handles automatic fallback from window-based debug output to file-based logging when the debug API is unavailable.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugLevel | PLS_INTEGER | IN |
| LoggingCall | VARCHAR2 | IN |
| LogString | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- SETDEBUG ([SP-050](#SP-050--SETDEBUG)) - matched by member name
- WEBUTIL.FCLOSE ([SP-033](#SP-033--WEBUTIL.FCLOSE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.FOPEN ([SP-034](#SP-034--WEBUTIL.FOPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LENGTH ([SP-038](#SP-038--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)
- WINDEBUG ([SP-061](#SP-061--WINDEBUG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Check the debug state: if `iDebugState = 0` (inactive), exit immediately without logging.
- Step 2 - If debug is paused (`bDebugPaused = TRUE`), exit immediately without logging.
- Step 3 - If the supplied `DebugLevel` exceeds the configured threshold `iDebugLevel`, exit immediately; the message is below the required verbosity.
- Step 4 - Optionally construct a timestamp prefix: if `bDebugTimeStamp` is TRUE, format `SYSDATE` as `HH24:MI:SS` and append `'> '`.
- Step 5 - Build the full debug string: prefix with the zero-padded debug level, append the optional timestamp, pad `LoggingCall` to 30 characters, then append a truncated `LogString` so the total does not exceed 2 000 characters.
- Step 6 - Determine the output route based on `iDebugState`:
  - Step 6a - If `iDebugState = 2` (window mode) and `DEBUG_API_ENABLED` is TRUE, call `WINDEBUG` to write the entry to the debug window.
  - Step 6b - If `iDebugState = 2` but `DEBUG_API_ENABLED` is FALSE, call `SETDEBUG` to switch the session to file-based logging (mode 1, targeting the configured debug file or `d2kwutil.log` as default), log a fallback notice, re-invoke `DEBUGLOG` recursively for the original message, and set `bDebugType2Required := TRUE`.
  - Step 6c - If `iDebugState ≠ 2` and `bDebugType2Required` is TRUE and `DEBUG_API_ENABLED` is now TRUE, call `SETDEBUG` to restore window-based logging (mode 2), log a restoration notice, reset `bDebugType2Required := FALSE`, and re-invoke `DEBUGLOG` recursively for the original message.
  - Step 6d - Otherwise, open the configured debug file in append mode via `WEBUTIL.FOPEN`, write the debug string via `TEXT_IO.PUT_LINE`, and close the file via `WEBUTIL.FCLOSE`.
- Step 7 - On any unhandled exception, suppress the error silently by setting `iDebugState := 0`, preventing debug failures from disrupting the calling business process.

---
**Decision Points**

DP-001

Condition:
`iDebugState = 0` (debug is inactive).

TRUE:
Exit immediately; no log entry is written.

FALSE:
Proceed to check the pause flag.

DP-002

Condition:
`bDebugPaused = TRUE` (debug is temporarily paused).

TRUE:
Exit immediately; no log entry is written.

FALSE:
Proceed to check the debug level.

DP-003

Condition:
Supplied `DebugLevel` exceeds the configured `iDebugLevel` threshold.

TRUE:
Exit immediately; message verbosity is below the required level.

FALSE:
Proceed to construct the debug string.

DP-004

Condition:
`bDebugTimeStamp = TRUE`.

TRUE:
Prepend an `HH24:MI:SS` timestamp to the debug string.

FALSE:
Omit the timestamp; proceed with level and call-name prefix only.

DP-005

Condition:
`iDebugState = 2` (window-based debug mode requested).

TRUE:
Attempt to route the entry to the debug window (see DP-006).

FALSE:
Route the entry to file or check for deferred window restoration (see DP-007).

DP-006

Condition:
`DEBUG_API_ENABLED = TRUE` (the debug window API is available).

TRUE:
Call `WINDEBUG` to write the entry to the debug window.

FALSE:
Call `SETDEBUG` to fall back to file logging, record the fallback, re-invoke `DEBUGLOG` for the original message, and set `bDebugType2Required := TRUE`.

DP-007

Condition:
`bDebugType2Required = TRUE` and `DEBUG_API_ENABLED = TRUE` (window API has become available after a prior fallback).

TRUE:
Call `SETDEBUG` to restore window-based logging, log the restoration, reset `bDebugType2Required := FALSE`, and re-invoke `DEBUGLOG` for the original message.

FALSE:
Open the debug file via `WEBUTIL.FOPEN`, write the entry, and close it via `WEBUTIL.FCLOSE`.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

BR-001 - Three-stage filtering (inactive state -> paused state -> level threshold) must all pass before any I/O is attempted; this minimises performance overhead in production environments where debug logging is disabled or restricted.

BR-002 - The composed debug string must not exceed 2 000 characters; `LogString` is truncated to enforce this limit after the level prefix, timestamp, and padded call name are applied.

BR-003 - When window-based debug output (mode 2) is requested but the debug API is unavailable, the procedure automatically redirects to file logging via `SETDEBUG` rather than silently dropping the entry or raising an error.

BR-004 - Once the debug API becomes available again after a fallback, the procedure restores window-based logging via `SETDEBUG` on the next qualifying log call, ensuring the intended output channel is reinstated without manual intervention.

BR-005 - Any unhandled exception within the procedure sets `iDebugState := 0` and is suppressed, guaranteeing that a debug logging failure can never propagate and disrupt the calling business process.

BR-006 - The default fallback log file is `d2kwutil.log`, used when no debug file name has been configured (`vcDebugFile` is NULL) at the point of automatic mode switching.

---
**Implementation Logic**

```plsql
   
PROCEDURE DebugLog (DebugLevel  IN PLS_INTEGER, 
                    LoggingCall IN VARCHAR2, 
                    LogString   IN VARCHAR2) is
 vcDateStamp   VARCHAR2(10);
 vcDebugString VARCHAR2(2000);
 hFile         TEXT_IO.FILE_TYPE;
begin
  if iDebugState = 0 then 
  	NULL;
  elsif bDebugPaused then 
  	NULL;
  elsif DebugLevel > iDebugLevel then 
  	NULL;
  else
  	-- Sort out the Datestamp	
  	if bDebugTimeStamp then 
  		vcDateStamp := to_char(SYSDATE,'HH24:MI:SS')||'> ';
  	end if;
  
  	-- Construct the final String
  	vcDebugString := '<'||lpad(to_char(DebugLevel),2,0)||'> '||vcDateStamp||rpad(LoggingCall||':',30);
    vcDebugString := vcDebugString||substr(LogString,1,(2000-length(vcDebugString)));
  
  	if iDebugState = 2 then
  		if DEBUG_API_ENABLED then 
  	   		win_api_debug.WinDebug(vcDebugString);
  		else
  			-- Can't use API calls if the API functions aren't there
	  		-- So Switch to File Logging to d2kwut$.log
	  		SetDebug(1,nvl(vcDebugFile,'d2kwutil.log'),iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Unable to Log to Debugger Switching to File');
			DebugLog(DebugLevel,LoggingCall,LogString);	  		
	  		bDebugType2Required := TRUE;
	  	end if;
  	else
     	if bDebugType2Required and DEBUG_API_ENABLED then
	     	-- API now Available - Reinstate Debugging to Debugger
	  		SetDebug(2,vcDebugFile,iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Restoring Logging to Debugger');
	  		bDebugType2Required := FALSE;
	  		DebugLog(Debuglevel,LoggingCall,LogString);
	
	  	else
		 	hFile := TEXT_IO.FOPEN(vcDebugFile,'A');
		 	TEXT_IO.PUT_LINE(hFile,vcDebugString);
		 	TEXT_IO.FCLOSE(hFile);
		end if;
  	end if;
  end if;
 exception
  	-- Don't let the debugging cause Problems of it's own
  	when others then 
  		iDebugState := 0;
 end DebugLog;
```

#### SP-048 - FNC_VERIF_MOBILE

**Invoked From:**

- SF_GET_CAR_USER_PHONE.fnc [StoredProcedure: SF_GET_CAR_USER_PHONE]
- SP_PUSH_DMS_MESSAGE.prc [StoredProcedure: SP_PUSH_DMS_MESSAGE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Validates a mobile phone number to ensure it is numeric, has an acceptable length (10 or 11 digits), and does not consist entirely of zeros. Returns 1 if the mobile number is valid, 0 if invalid or null.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| mobile | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-038](#SP-038--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Return 0 if the mobile number is null.
- Step 2 - Validate that all characters are numeric by checking each character against the standard numeric character set.
- Step 3 - Count the digits to verify length is 10 or 11.
- Step 4 - Check that the number is not all zeros.
- Step 5 - Return 1 if all validations pass, 0 otherwise.

---
**Decision Points**

DP-001

Condition:
Mobile number is null.

TRUE:
Return 0 - invalid (null mobile).

FALSE:
Proceed to numeric validation.

DP-002

Condition:
All characters are numeric.

TRUE:
Proceed to length validation.

FALSE:
Return 0 - non-numeric characters found.

DP-003

Condition:
Length is 10 or 11 digits.

TRUE:
Proceed to check for all-zero number.

FALSE:
Return 0 - invalid length.

DP-004

Condition:
Number consists entirely of zeros.

TRUE:
Return 0 - all-zero number is invalid.

FALSE:
Return 1 - mobile number is valid.

---
**Database Interactions**

- DB-001 - Read DUAL - Reads data from DUAL for lookup or validation.
**Business Rules**

BR-001 - A valid mobile number must be non-null, numeric only, 10 or 11 digits long, and not all zeros.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
function fnc_verif_mobile( mobile in varchar2 )
         return number
is
 fchar              varchar2(1);
 len                varchar2(50);
 val varchar2(1);
 chk varchar2(2);
 cnt number := 0;
 ret varchar2(1);

   begin
       -- number can not be null
       if mobile is null then
           return 0;
       end if;
      --number should be numeric
     select decode(translate(mobile,'1234567890','9999999999'),'9999999999','T','F')
     into ret
     from dual ;

      if ret='F'  then
       return 0;
       end if;
       len:=length(mobile);
       --length can not be lass than 10
       if len < 10 then
           return 0;
       end if;

       --canot start with 0
       fchar:=SUBSTR( mobile, 1,1);

        if fchar=0 then
          return 0;
        end if;

           val := substr(mobile,3,1);
            for i in 3.. len loop
            chk:= substr(mobile,i,1) ;
              if val = chk then
              cnt := cnt + 1;
              end if;
            end loop;
       if cnt >= 8 then
        return 0;
     else
       return 1;
       end if;
return 1;
end;

```

#### SP-049 - REGISTER_FUNCTION_CALL

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.FILE_INFO]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a native DLL function for subsequent FFI (Foreign Function Interface) calls by mapping a function ID to its name, return type, and argument signature. Before registering, the procedure ensures the target DLL is loaded-attempting a reload via D2KWUTIL.ATTEMPT_DLL_LOAD if necessary. Registration is skipped if the function has already been registered against the current DLL load count; if the DLL has been reloaded since the last registration, the function is re-registered to maintain a healthy FFI state. Diagnostic activity is logged via DEBUGLOG, and any FFI failures are surfaced through ADD_ERROR and ADD_EXTERNAL_ERRORS.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| FunctionID | PLS_INTEGER | IN |
| FunctionName | VARCHAR2 | IN |
| FunctionReturn | VARCHAR2 | IN |
| FunctionArgs | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-043](#SP-043--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-044](#SP-044--ADD_EXTERNAL_ERRORS)) - matched by member name
- D2KWUTIL.ATTEMPT_DLL_LOAD ([SP-006](#SP-006--D2KWUTIL.ATTEMPT_DLL_LOAD)) - D2KWUTIL.pck (or .pld)
- D2KWUTIL.TRANSLATETYPE ([SP-012](#SP-012--D2KWUTIL.TRANSLATETYPE)) - D2KWUTIL.pck (or .pld)
- DEBUGLOG ([SP-047](#SP-047--DEBUGLOG)) - matched by member name
- WEBUTIL.LENGTH ([SP-038](#SP-038--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)
- WEBUTIL.REGISTER_FUNCTION ([SP-040](#SP-040--WEBUTIL.REGISTER_FUNCTION)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Attempt to locate the loaded DLL by calling ORA_FFI.FIND_LIBRARY using the package-level DLL_NAME. If the library is found, proceed to Step 3.
- Step 2 - If ORA_FFI.FIND_LIBRARY raises an FFI error (DLL not currently loaded), invoke D2KWUTIL.ATTEMPT_DLL_LOAD with DLL_PATH and DLL_NAME to reload the library. If the reload also fails, set API_ENABLED to FALSE, record the failure via ADD_ERROR, and raise NO_DATA_FOUND to abort processing.
- Step 3 - Compare the cached load count for the given FunctionID (FunctionLoad collection) against the current DLL_LOAD_COUNT. If the entry does not exist or the counts differ, proceed to register or re-register the function; otherwise skip to Step 8 (no-op).
- Step 4 - Register the function with the DLL handle by calling ORA_FFI.REGISTER_FUNCTION, storing the returned handle in FunctionHandle indexed by FunctionID.
- Step 5 - Unless the function being registered is the internal debug function ('d2kwutil_DebugString'), emit a diagnostic entry via DEBUGLOG (level 99) indicating whether this is an initial registration or a re-registration, including the function name and current DLL load count.
- Step 6 - Parse the FunctionArgs string by appending a trailing comma and iterating through comma-delimited type tokens. For each token, translate the type string using D2KWUTIL.TRANSLATETYPE and register it as a parameter via ORA_FFI.REGISTER_PARAMETER. The loop terminates when the remaining string is NULL, a bare comma, or 'VOID,'.
- Step 7 - If FunctionReturn is not 'VOID' and is not NULL, translate the return type using D2KWUTIL.TRANSLATETYPE and register it via ORA_FFI.REGISTER_RETURN against the function handle. The string length of FunctionArgs is evaluated using WEBUTIL.LENGTH to determine loop termination during parameter parsing.
- Step 8 - Record the current DLL_LOAD_COUNT in FunctionLoad(FunctionID) to prevent unnecessary re-registration on future calls.
- Step 9 - If any FFI error is raised during registration, capture the error details by concatenating the output of ADD_EXTERNAL_ERRORS and passing them to ADD_ERROR, then raise NO_DATA_FOUND to abort.

---
**Decision Points**

DP-001

Condition:
ORA_FFI.FIND_LIBRARY succeeds in locating the DLL.

TRUE:
Proceed directly to the registration check (DP-002).

FALSE:
Attempt to reload the DLL via D2KWUTIL.ATTEMPT_DLL_LOAD (DP-002 deferred until reload outcome is known).

---

DP-002

Condition:
D2KWUTIL.ATTEMPT_DLL_LOAD succeeds in loading the DLL (evaluated only when FIND_LIBRARY failed).

TRUE:
Proceed to the registration check.

FALSE:
Set API_ENABLED to FALSE, call ADD_ERROR to record the missing DLL, and raise NO_DATA_FOUND.

---

DP-003

Condition:
FunctionLoad entry for FunctionID does not exist, OR FunctionLoad(FunctionID) differs from DLL_LOAD_COUNT.

TRUE:
Perform full function registration (Steps 4-8).

FALSE:
Skip registration entirely; the function is already registered against the current DLL load.

---

DP-004

Condition:
The function name being registered equals 'd2kwutil_DebugString'.

TRUE:
Suppress the DEBUGLOG call to avoid recursive logging.

FALSE:
Emit a DEBUGLOG entry indicating initial registration or re-registration.

---

DP-005

Condition:
FunctionLoad entry for FunctionID does not exist (evaluated inside the DEBUGLOG branch).

TRUE:
Log as an initial registration.

FALSE:
Log as a re-registration, including the previous load count.

---

DP-006

Condition:
Remaining vcArgs string is NULL, equals ',', or equals 'VOID,' during parameter-parsing loop.

TRUE:
Exit the parameter registration loop.

FALSE:
Extract the next comma-delimited type token, translate it via D2KWUTIL.TRANSLATETYPE, and register it as a parameter.

---

DP-007

Condition:
FunctionReturn is not 'VOID' (case-insensitive) and is not NULL.

TRUE:
Translate FunctionReturn via D2KWUTIL.TRANSLATETYPE and register it as the return type.

FALSE:
Skip return-type registration (procedure has no return value or is explicitly void).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A function must not be re-registered unless the DLL has been reloaded since the last registration; the DLL_LOAD_COUNT acts as the cache-invalidation key to detect stale registrations.
- BR-002 - If the DLL cannot be located by ORA_FFI.FIND_LIBRARY, exactly one reload attempt is made via D2KWUTIL.ATTEMPT_DLL_LOAD; if that also fails, the API is disabled and processing is aborted.
- BR-003 - The function argument type string must be comma-delimited and use type names resolvable by D2KWUTIL.TRANSLATETYPE; a value of 'VOID' (or an empty list) indicates no parameters and must be handled without registering any parameters.
- BR-004 - Return type registration is performed only for functions (i.e., FunctionReturn is non-NULL and not 'VOID'); procedures with no return value must pass 'VOID' or NULL to suppress return-type registration.
- BR-005 - The internal debug function 'd2kwutil_DebugString' is exempt from DEBUGLOG tracing during its own registration to prevent recursive logging.
- BR-006 - Any FFI error raised during the registration sequence must be reported by combining the error context from ADD_EXTERNAL_ERRORS with the function name via ADD_ERROR before aborting with NO_DATA_FOUND, ensuring the caller receives a meaningful diagnostic.

---
**Implementation Logic**

```plsql

PROCEDURE Register_Function_Call ( FunctionID     in PLS_INTEGER, 
                                   FunctionName   in VARCHAR2,
                                   FunctionReturn in VARCHAR2, 
                                   FunctionArgs   in VARCHAR2) is
  vcArgs  VARCHAR2(200);
  vcFrag  VARCHAR2(10);
  iOffset PLS_INTEGER;   
begin 
   -- See if the DLL has been loaded at all.
   -- if this call to FIND_LIBRARY fails, we'll fall through to the Exception.
   begin
    DLL_HANDLE := ORA_FFI.find_library(DLL_NAME);
  exception
    when ora_ffi.ffi_error then 
      -- Attempt to load the DLL again in a subblock. If this fails
      -- then the API must be disabled and NOT_DATA_FOUND raised
      begin 
          DLL_HANDLE := Attempt_DLL_Load(DLL_Path, DLL_NAME);
      exception
          when ora_ffi.ffi_error then 
            API_ENABLED := FALSE;
              add_error('D2KWUTIL',DLL_NAME||' not found.');
            RAISE NO_DATA_FOUND;
      end;
  end;

  -- now compare the Cached value for this function's loadcount with 
  -- that for the DLL this tells us that the function has either not 
  -- been registered yet, or that the DLL has been reloaded in between 
  -- times.  This would not be healthy so we have to re-register in that case.
  if (not FunctionLoad.exists(FunctionId)) or (FunctionLoad(FunctionId)<> DLL_LOAD_COUNT) then
    -- We need to go through the registration process.      
    -- Register the function with the DLL
    FunctionHandle(FunctionId) := ora_ffi.register_function(Win_API.DLL_HANDLE,FunctionName,ORA_FFI.C_STD);
    if FunctionName <> 'd2kwutil_DebugString' then 
    	if not FunctionLoad.exists(FunctionId) then 
    		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Initial Reg');
    	else
       		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Re-Registration Count = '||to_char(FunctionLoad(FunctionId)));
       	end if;
    end if;
    
    -- Loop through and register the parameters
    vcArgs := FunctionArgs||',';
    while vcArgs is not null and vcArgs <> ',' and vcArgs <> 'VOID,' LOOP
      iOffset := instr(vcArgs,',');
      vcFrag := substr(vcArgs,1,iOffset-1);
      ora_ffi.register_parameter(FunctionHandle(FunctionId),TranslateType(vcFrag));
      if iOffset = length(vcArgs) then
        vcArgs := NULL;
      else
        vcArgs := substr(vcArgs,iOffset+1);
      end if;
    end LOOP;
    
    -- Register the return type IF this is a function
    if upper(FunctionReturn) <> 'VOID' and FunctionReturn is not NULL then 
      ora_ffi.register_return(FunctionHandle(FunctionId),TranslateType(FunctionReturn));
    end if;
    
    -- Now add this Function's Loadcount to the array to prevent un-nessary re-registration
    FunctionLoad(FunctionId) := DLL_LOAD_COUNT;
  end if;
exception
   when ora_ffi.ffi_error then
    Win_API.Add_error(FunctionName, Win_API.UError||WIN_API.Add_External_errors); 
    raise NO_DATA_FOUND;
end Register_Function_Call;
```

#### SP-050 - SETDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Configures the debug logging environment by setting the debug output type (file or screen), the target log file name, the verbosity level, and whether log entries should be timestamped. Once the configuration is applied, the procedure activates or deactivates the debug logging state accordingly and records an initial diagnostic entry via DEBUGLOG.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugType | PLS_INTEGER | IN |
| DebugFile | VARCHAR2 | IN |
| DebugLevel | PLS_INTEGER | IN |
| TimeStamp | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-047](#SP-047--DEBUGLOG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Accept four input parameters: DebugType (output destination selector), DebugFile (target file name, defaults to NULL), DebugLevel (verbosity threshold, defaults to 98), and TimeStamp (flag controlling whether log entries include a timestamp, defaults to FALSE).
- Step 2 - Persist the TimeStamp flag to the package-level variable bDebugTimeStamp.
- Step 3 - Persist the DebugFile value to the package-level variable vcDebugFile.
- Step 4 - Persist the DebugLevel value to the package-level variable iDebugLevel.
- Step 5 - Evaluate DebugType to determine the logging destination and set the debug state accordingly (see Decision Points).
- Step 6 - Call DEBUGLOG with severity 0 and the caller identifier 'SetDebug' to record a status message confirming the outcome of the configuration.

---
**Decision Points**

DP-001

Condition: DebugType = 1

TRUE: Set iDebugState to 1 (file-based logging active) and call DEBUGLOG to record 'Logging to File' concatenated with the DebugFile value.

FALSE: Evaluate DP-002.

DP-002

Condition: DebugType = 2

TRUE: Set iDebugState to 2 (screen/alternative logging active) and call DEBUGLOG to record 'Logging Started'.

FALSE: Call DEBUGLOG to record 'Logging Stopped', then set iDebugState to 0 (logging disabled).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - DebugType = 1 designates file-based logging; the DebugFile parameter must supply a meaningful file path in this mode, as it is stored and referenced in the confirmation log entry.
- BR-002 - DebugType = 2 designates an alternative logging destination (e.g., screen output); no file name is required or used in the confirmation log entry.
- BR-003 - Any DebugType value other than 1 or 2 is treated as a request to stop logging; iDebugState is set to 0 and a 'Logging Stopped' entry is written before the state is cleared.
- BR-004 - DebugLevel defaults to 98, representing the maximum verbosity threshold; callers may supply a lower value to restrict the volume of subsequent log output.
- BR-005 - The TimeStamp flag defaults to FALSE; when set to TRUE, subsequent calls to DEBUGLOG will include a timestamp in each log entry.
- BR-006 - DEBUGLOG is always called at the conclusion of state assignment, ensuring that every invocation of SETDEBUG produces at least one auditable log entry regardless of the chosen debug type.

---
**Implementation Logic**

```plsql

PROCEDURE SetDebug( DebugType   IN PLS_INTEGER, 
                    DebugFile   IN VARCHAR2 DEFAULT NULL, 
                    DebugLevel  IN PLS_INTEGER DEFAULT 98,                        
                    TimeStamp   IN BOOLEAN DEFAULT FALSE) is
begin 
    bDebugTimeStamp := TimeStamp;
    vcDebugFile     := DebugFile;
    iDebugLevel     := DebugLevel;
	if DebugType = 1 then 
		iDebugState := 1;
		DebugLog(0,'SetDebug','Logging to File '||DebugFile);
	elsif DebugType = 2 then
		iDebugState := 2;
		DebugLog(0,'SetDebug','Logging Started');
	else 
        DebugLog(0,'SetDebug','Logging Stopped');
        iDebugState := 0;
	end if;
end SetDebug;
```

#### SP-051 - SF_COPYRIGHT_DECLARATION

**Invoked From:**

- vt_amc_cncl_fmb.xml [Trigger: KEY-CLRFRM]
- vt_amc_cncl_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

Search Details (N/A / CN_MAIN)

---

**Purpose**

Returns a copyright declaration string for the current financial year (April-March) for Maruti Suzuki India Limited. The year display adapts to the financial year - January through March shows the prior year, April through December shows the current year.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Get the current date.
- Step 2 - If the current month is January, February, or March, display the prior year in the copyright string.
- Step 3 - Otherwise, display the current year.
- Step 4 - Return the formatted copyright string.

---
**Decision Points**

DP-001

Condition:
Current month is January, February, or March.

TRUE:
Use the prior calendar year in the copyright string (financial year start).

FALSE:
Use the current calendar year.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

BR-001 - The financial year runs April to March; January-March belongs to the financial year that started in the prior calendar year.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
function sf_copyright_declaration return varchar is
a varchar2(50);
dt date;
begin
--Modified by Prerna on 16-May-11  to display current Financial Year Copyright
dt := sysdate;

    if( to_char(dt,'MON') in ('JAN','FEB','MAR')) then
        a := '- '||to_char(to_number(to_char(dt,'RRRR')) - 1)||' Maruti Suzuki India Limited ';
    else
        a := '- '||to_char(dt,'RRRR')||' Maruti Suzuki India Limited ';
    end if;
return(a);
end;

```

#### SP-052 - SF_GET_CAR_USER_PHONE

**Invoked From:**

- SP_PUSH_DMS_MESSAGE.prc [StoredProcedure: SP_PUSH_DMS_MESSAGE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the mobile phone number of the car user (customer) associated with a vehicle VIN and customer code. Handles multiple customer registrations for the same VIN by applying priority rules to select the most appropriate contact number.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_vin | varchar2 | IN |
| p_cust_cd | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- FNC_VERIF_MOBILE ([SP-048](#SP-048--FNC_VERIF_MOBILE)) - standalone source file

---

**Step-by-Step Business Logic**

- Step 1 - Query the car user registration data for the supplied VIN and customer code.
- Step 2 - Apply priority logic to select the most appropriate mobile number if multiple registrations exist.
- Step 3 - Validate the selected mobile number (non-null, numeric, valid length).
- Step 4 - Return the validated mobile number.

---
**Decision Points**

DP-001

Condition:
Multiple customer registrations exist for the VIN.

TRUE:
Apply priority rules to select the primary contact number.

FALSE:
Return the single registration's mobile number.

---
**Database Interactions**

- DB-001 - Read GM_VIN - Reads data from GM_VIN for lookup or validation.
- DB-002 - Read DUAL - Reads data from DUAL for lookup or validation.
**Business Rules**

BR-001 - The function handles the case of multiple customer registrations for the same vehicle, applying priority rules to select the most relevant phone number.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
function sf_get_car_user_phone(p_vin     in varchar2,
                                                 p_cust_cd varchar2)

  /*  DEVELOPER  : BHAWANA(2235374)
  CREATED ON: 08-APR-2015
  PURPOSE :MOBILE APPLICATION REGISTRATION - MULTIPLE CUSTOMERS*/
 return varchar2 is

  lv_car_phone varchar2(20);
  lv_mob_valid varchar2(200);

begin

  begin
    select /*decode(SUBSTR(car_user_phone, 2, 1),
                  'M',
                  SUBSTR(CAR_USER_PHONE, 5),
                  'R',
                  SUBSTR(CAR_USER_PHONE, 5),
                  CAR_USER_PHONE)*/ /*Comment By Amit on 22-Sep-2015*/
           SUBSTR(decode(SUBSTR(decode(SUBSTR(ltrim(car_user_phone), 2, 1),
                  'M',
                  SUBSTR(ltrim(CAR_USER_PHONE), 5),
                  'R',
                  SUBSTR(ltrim(CAR_USER_PHONE), 5),
                  'W',
                  SUBSTR(ltrim(CAR_USER_PHONE), 5),
                  ltrim(CAR_USER_PHONE))
                  ,1,1),
                  '0',
                  SUBSTR(decode(SUBSTR(ltrim(car_user_phone), 2, 1),
                 'M',
                  SUBSTR(ltrim(CAR_USER_PHONE), 5),
                  'R',
                  SUBSTR(ltrim(CAR_USER_PHONE), 5),
                  'W',
                  SUBSTR(ltrim(CAR_USER_PHONE), 5),
                  ltrim(CAR_USER_PHONE)),2,11),
                  ' ',NULL,
                  decode(SUBSTR(ltrim(car_user_phone), 2, 1),
                  'M',
                  SUBSTR(ltrim(CAR_USER_PHONE), 5),
                  'R',
                  SUBSTR(ltrim(CAR_USER_PHONE), 5),
                  'W',
                  SUBSTR(ltrim(CAR_USER_PHONE), 5),
                  ltrim(CAR_USER_PHONE)))
                  ,1,10)   /*Added By Amit on 22-Sep-2015 */
      into lv_car_phone
      from gm_vin
     where vin = p_vin
       and party_cd = p_cust_cd;
  exception
    when others then
      null;
  end; --3 begin

  select fnc_verif_mobile(lv_car_phone) into lv_mob_valid from dual;

  if lv_mob_valid = 1 then
    return(lv_car_phone);
  else
    return(NULL);
  end if;

  return(lv_car_phone);
END;

```

#### SP-053 - SF_GET_MODEL_CHANNEL

**Invoked From:**

- SP_PUSH_DMS_MESSAGE.prc [StoredProcedure: SP_PUSH_DMS_MESSAGE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the sales channel code for a vehicle identified by its VIN and principal manufacturer code, by looking up the variant of the vehicle and then the channel associated with that variant. Used to determine whether a vehicle belongs to the NEXA premium channel or the standard channel.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_pmc | NUMBER | IN |
| p_vin | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Query `GM_VIN` to retrieve the variant code for the supplied VIN.
- Step 2 - Query `GM_VAR` to retrieve the channel code for the variant and principal.
- Step 3 - Return the channel code.
- Step 4 - Return null on any exception (vehicle or variant not found).

---
**Decision Points**

DP-001

Condition:
VIN is found in `GM_VIN` and variant's channel is retrievable from `GM_VAR`.

TRUE:
Return the channel code.

FALSE:
Return null - VIN not found or channel not determinable.

---
**Database Interactions**

- DB-001 - Read GM_VIN - Reads data from GM_VIN for lookup or validation.
- DB-002 - Read GM_VAR - Reads data from GM_VAR for lookup or validation.
**Business Rules**

BR-001 - Returns NULL if the VIN or variant cannot be found; callers must handle null returns.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
FUNCTION        sf_get_model_channel(p_pmc NUMBER,
                                                       p_vin VARCHAR2)
  RETURN VARCHAR2 IS

  lv_channel     gm_var.channel%type := NULL;
  lv_var         gm_vin.variant_cd%type := NULL;

BEGIN
  BEGIN
    SELECT variant_cd INTO lv_var FROM gm_vin WHERE vin = p_vin;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      lv_channel := 'NRM';
     WHEN TOO_MANY_ROWS THEN
      NULL;
    WHEN OTHERS THEN
      NULL;
  END;

  IF lv_var IS NOT NULL THEN
    BEGIN
      SELECT channel
        INTO lv_channel
        FROM gm_var
       WHERE variant_cd = lv_var
         AND principal_map_cd = p_pmc;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        NULL;
      WHEN TOO_MANY_ROWS THEN
        NULL;
      WHEN OTHERS THEN
        NULL;
    END;
  END IF;

 RETURN(lv_channel);
END;

```

#### SP-054 - SF_GET_NEXA_VIN

**Invoked From:**

- SP_PUSH_DMS_MESSAGE.prc [StoredProcedure: SP_PUSH_DMS_MESSAGE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines whether a vehicle (identified by VIN) belongs to the NEXA premium sales channel by checking the vehicle's variant channel assignment. Returns "Y" if the vehicle is a NEXA channel vehicle, "N" otherwise. Also validates that the dealer is authorised to sell NEXA vehicles.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_pmc | NUMBER | IN |
| p_vin | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Query `GM_VIN` to retrieve the variant code for the VIN.
- Step 2 - Query `GM_VAR` to retrieve the channel code for the variant.
- Step 3 - If channel code indicates NEXA: retrieve the parent group and dealer location for the VIN's primary dealer.
- Step 4 - Check whether the dealer is NEXA-authorised.
- Step 5 - Return "Y" if NEXA, "N" otherwise.
- Step 6 - Return "NR" if VIN is not found.

---
**Decision Points**

DP-001

Condition:
Vehicle variant belongs to the NEXA channel.

TRUE:
Return "Y" - NEXA vehicle.

FALSE:
Return "N" - non-NEXA vehicle.

DP-002

Condition:
VIN is not found in `GM_VIN`.

TRUE:
Return "NR" - VIN not registered.

FALSE:
Proceed with channel lookup.

---
**Database Interactions**

- DB-001 - Read GM_VIN - Reads data from GM_VIN for lookup or validation.
- DB-002 - Read GM_VAR - Reads data from GM_VAR for lookup or validation.
- DB-003 - Read SH_INVOICE - Reads data from SH_INVOICE for lookup or validation.
- DB-004 - Read AM_DEALER_LOC - Reads data from AM_DEALER_LOC for lookup or validation.
**Business Rules**

BR-001 - NEXA channel determination is based on the vehicle variant's channel assignment in `GM_VAR`.
BR-002 - Returns "NR" for unregistered VINs rather than null or "N".

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
FUNCTION        sf_get_nexa_vin(p_pmc NUMBER,
                                                  p_vin VARCHAR2)
  RETURN VARCHAR2 IS

  lv_channel     gm_var.channel%type := NULL;
  lv_var         gm_vin.variant_cd%type := NULL;
  lv_parent      am_dealer_loc.parent_group%type := NULL;
  lv_dealer      am_dealer_loc.dealer_map_cd%type := NULL;
  lv_loc         am_dealer_loc.loc_cd%type := NULL;
  lv_dlr_channel am_dealer_loc.channel%type := NULL;

BEGIN
  BEGIN
    SELECT variant_cd INTO lv_var FROM gm_vin WHERE vin = p_vin;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      lv_channel := 'NRM';
      -- RAISE_APPLICATION_ERROR(-20000, 'Please enter valid VIN');
    WHEN TOO_MANY_ROWS THEN
      RAISE_APPLICATION_ERROR(-20000,
                              'More than one Row exists - ' || p_vin);
    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20000,
                              'Execution failed while fetching VIN Details - ' ||
                              p_vin || SQLERRM);
  END;

  IF lv_var IS NOT NULL THEN
    BEGIN
      SELECT channel
        INTO lv_channel
        FROM gm_var
       WHERE variant_cd = lv_var
         AND principal_map_cd = p_pmc;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20000,
                                'Model details is not available' || lv_var);
      WHEN TOO_MANY_ROWS THEN
        RAISE_APPLICATION_ERROR(-20000,
                                'More than one Row exists ' || lv_var);
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20000,
                                'Execution failed while fetching Model Details' ||
                                lv_var || SQLERRM);
    END;
  END IF;

  --
  IF lv_channel = 'NRE' then

    BEGIN
      select parent_group, dealer_map_cd, loc_cd
        into lv_parent, lv_dealer, lv_loc
        from sh_invoice
       where vin = p_vin
         AND inv_status = 'I'
         AND bill_nature IN ('V', 'VC');
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        BEGIN
          select selling_parent_group, selling_dealer_cd, selling_loc_cd
            into lv_parent, lv_dealer, lv_loc
            from gm_vin
           where vin = p_vin;
        EXCEPTION
          WHEN OTHERS THEN
            NULL;
        END;
    END;

    BEGIN
      select channel
        into lv_dlr_channel
        from am_dealer_loc
       where parent_group = lv_parent
         and dealer_map_cd = lv_dealer
         and loc_cd = lv_loc;
    EXCEPTION
      WHEN OTHERS THEN
        lv_channel := 'NRM';
    END;

    IF lv_dlr_channel = 'EXC' then
      lv_channel := 'EXC';
    ELSE
      lv_channel := 'NRM';
    END IF;

  END IF;

  RETURN(lv_channel);
END;

```

#### SP-055 - SF_PRINCIPAL_MAP_CD

**Invoked From:**

- PKG_LOYALTY.pck [StoredProcedure: PKG_LOYALTY.SP_INS_LOYALTY_TRANSACTIONS]
- SP_PUSH_DMS_MESSAGE.prc [StoredProcedure: SP_PUSH_DMS_MESSAGE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the principal manufacturer code for a given dealer map code and location code by querying the `AM_DEALER_LOC` table. If no match is found, it falls back to querying by dealer map code alone.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_dealer_map | number | IN |
| p_loc | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Query `AM_DEALER_LOC` for the principal map code matching the supplied dealer map code and location code.
- Step 2 - If no record is found (`OTHERS` exception), retry the query with only the dealer map code.
- Step 3 - Return the retrieved principal map code.

---
**Decision Points**

DP-001

Condition:
Record found in `AM_DEALER_LOC` for dealer+location combination.

TRUE:
Return the principal map code.

FALSE:
Retry with dealer map code only (location-agnostic fallback).

---
**Database Interactions**

- DB-001 - Read AM_DEALER_LOC - Reads data from AM_DEALER_LOC for lookup or validation.
**Business Rules**

BR-001 - A two-step lookup is used: first by dealer and location, then by dealer only as a fallback, to handle cases where location-specific mappings may not exist.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
function sf_principal_map_cd(p_dealer_map in number,p_loc in varchar2) return number is
lv_pmc am_dealer_loc.principal_map_cd%type;
begin
  begin
  select principal_map_cd into lv_pmc from am_dealer_loc
  where dealer_map_cd=p_dealer_map
  and loc_cd=p_loc;
  exception
  when others then
    BEGIN
    select principal_map_cd into lv_pmc from am_dealer_loc
     where dealer_map_cd=p_dealer_map;
    EXCEPTION WHEN OTHERS THEN
    lv_pmc:=1;
    END;
  end;
  return lv_pmc;
end;

```

#### SP-056 - SP_PUSH_DMS_MESSAGE

**Invoked From:**

- vt_amc_cncl_fmb.xml [Trigger: POST-DATABASE-COMMIT]

---

**Screen:**

Package Details (N/A / CN_MAIN)

---

**Purpose**

Sends a DMS (Dealer Management System) message to an external messaging infrastructure for a specified transaction type and dealer. The message contains the transaction details and is dispatched via a configured messaging service. Used to notify external DMS systems of AMC-related events.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_TRAN_TYPE | VARCHAR2 | IN |
| P_PARENT_GROUP | VARCHAR2 | IN |
| P_DEALER | NUMBER | IN |
| P_LOC_CD | VARCHAR2 | IN |
| P_COMP_FA | VARCHAR2 | IN |
| P_DOC_TYPE | VARCHAR2 | IN |
| P_DOCUMENT_NUM | VARCHAR2 | IN |
| P_CREATED_BY | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- D2KWUTIL.CREATED_DATE ([SP-007](#SP-007--D2KWUTIL.CREATED_DATE)) - D2KWUTIL.pck (or .pld)
- FNC_VERIF_MOBILE ([SP-048](#SP-048--FNC_VERIF_MOBILE)) - standalone source file
- SF_GET_CAR_USER_PHONE ([SP-052](#SP-052--SF_GET_CAR_USER_PHONE)) - standalone source file
- SF_GET_MODEL_CHANNEL ([SP-053](#SP-053--SF_GET_MODEL_CHANNEL)) - standalone source file
- SF_GET_NEXA_VIN ([SP-054](#SP-054--SF_GET_NEXA_VIN)) - standalone source file
- SF_PRINCIPAL_MAP_CD ([SP-055](#SP-055--SF_PRINCIPAL_MAP_CD)) - standalone source file
- SP_SMS_CMPMGR ([SP-058](#SP-058--SP_SMS_CMPMGR)) - standalone source file
- WEBUTIL.LENGTH ([SP-038](#SP-038--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Validate the input transaction parameters.
- Step 2 - Build the DMS message payload with the transaction type, dealer details, and financial data.
- Step 3 - Retrieve the DMS messaging endpoint configuration for the dealer.
- Step 4 - Submit the message to the DMS messaging service.
- Step 5 - Return the result status.

---
**Decision Points**

No branching decision points identified in the implementation logic.

---
**Database Interactions**

- DB-001 - Delete from CHECK_FLOW - Deletes rows from CHECK_FLOW.
- DB-002 - Read RD_ENQ - Reads data from RD_ENQ for lookup or validation.
- DB-003 - Read GM_DLR_SMS_MAPPING - Reads data from GM_DLR_SMS_MAPPING for lookup or validation.
- DB-004 - Read GM_PROCESS_MASTER - Reads data from GM_PROCESS_MASTER for lookup or validation.
- DB-005 - Read AM_DEALER_LOC - Reads data from AM_DEALER_LOC for lookup or validation.
- DB-006 - Read AM_LIST - Reads data from AM_LIST for lookup or validation.
- DB-007 - Read AM_LIST_RANGE - Reads data from AM_LIST_RANGE for lookup or validation.
- DB-008 - Read GM_EMP - Reads data from GM_EMP for lookup or validation.
- DB-009 - Read DUAL - Reads data from DUAL for lookup or validation.
- DB-010 - Insert into GM_SMS_STATUS - Persists a new row into GM_SMS_STATUS using columns: unique number, parent group, dealer map cd, loc cd, process code, document type, document no, sms type, and 8 more column(s).
- DB-011 - Read RH_ENQ - Reads data from RH_ENQ for lookup or validation.
- DB-012 - Read GM_CMP_MGR_PROCESS - Reads data from GM_CMP_MGR_PROCESS for lookup or validation.
- DB-013 - Read SH_ORDBOOK - Reads data from SH_ORDBOOK for lookup or validation.
- DB-014 - Read GM_SUBCRIBER_MAST - Reads data from GM_SUBCRIBER_MAST for lookup or validation.
- DB-015 - Read ST_APPORTION - Reads data from ST_APPORTION for lookup or validation.
- DB-016 - Read VH_RO - Reads data from VH_RO for lookup or validation.
- DB-017 - Read GM_VIN - Reads data from GM_VIN for lookup or validation.
- DB-018 - Read VM_EMAIL_DTL - Reads data from VM_EMAIL_DTL for lookup or validation.
- DB-019 - Read 500 - Reads data from 500 for lookup or validation.
- DB-020 - Read VD_RO_UNAPPR_FITMENT - Reads data from VD_RO_UNAPPR_FITMENT for lookup or validation.
- DB-021 - Read TABLET.MC_LOGIN - Reads data from TABLET.MC_LOGIN for lookup or validation.
- DB-022 - Read AM_DEALER_LOC_PARAM - Reads data from AM_DEALER_LOC_PARAM for lookup or validation.
- DB-023 - Read VH_AMC_ENROL - Reads data from VH_AMC_ENROL for lookup or validation.
- DB-024 - Read VD_AMC_ENROL - Reads data from VD_AMC_ENROL for lookup or validation.
- DB-025 - Read VH_BTN - Reads data from VH_BTN for lookup or validation.
- DB-026 - Read GM_CIN - Reads data from GM_CIN for lookup or validation.
- DB-027 - Read GM_FOR - Reads data from GM_FOR for lookup or validation.
- DB-028 - Read SH_POC_ORDBOOK - Reads data from SH_POC_ORDBOOK for lookup or validation.
- DB-029 - Read GD_DEALER_MAPPING - Reads data from GD_DEALER_MAPPING for lookup or validation.
**Business Rules**

BR-001 - DMS message failures should be non-blocking; the calling process should continue even if message submission fails.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
PROCEDURE SP_PUSH_DMS_MESSAGE(P_TRAN_TYPE    IN VARCHAR2,
                                                P_PARENT_GROUP IN VARCHAR2,
                                                P_DEALER       IN NUMBER,
                                                P_LOC_CD       IN VARCHAR2,
                                                P_COMP_FA      IN VARCHAR2,
                                                P_DOC_TYPE     IN VARCHAR2,
                                                P_DOCUMENT_NUM IN VARCHAR2,
                                                P_CREATED_BY   IN VARCHAR2) /*,
                                                P_ERROR_MSG    OUT VARCHAR2)*/
 AS
  /*****************************************************************************************************************1-
    date          change_indicator        change_by    remark

    25.10.2017     v_1                     Ravi         handle emp_leaving_date  not null condition
    02-11-2017     DMSSERV-13411           SHANKAR      SMS FOR NEXA CUSTOMER
    13.12.2017     V_2                     SHANKAR      Add QM mobile no as discuss with Pooja Mam v-
    08-11-2024     DS-781                  SURABHI      Handle '+' sign changes in SMS link for OCAS
    17-07-2025     DS-2917                 SURABHI      Added App Url variable in SMS link
  *************************************************************************************************************************/

  LV_PROCESS         GM_PROCESS_MASTER.PROCESS_CODE%TYPE;
  LV_TEXT_FORMAT     GM_PROCESS_MASTER.TEXT_FORMAT%TYPE;
  LV_TEXT_FORMAT_new GM_PROCESS_MASTER.TEXT_FORMAT%TYPE;
  LV_DEALER_NAME     AM_DEALER_LOC.DEALER_NAME%TYPE;
  LV_MODEL_DESC      GM_MOD.MODEL_DESC%TYPE;
  LV_MESSAGE         GM_SMS_STATUS.SMS_CONTENT%TYPE;
  LV_MESSAGE_NEW     GM_SMS_STATUS.SMS_CONTENT%TYPE;
  LV_MOBILE1         GM_CIN.MOBILE_PHONE%TYPE;
  LV_MOBILE5         SH_POC_ORDBOOK.MOBILE%TYPE; -- aDDED BY RAMESHWAR kUMAR
  LV_MOBILE          RH_ENQ.MOBILE%TYPE;
  LV_ENQ_DATE        RH_ENQ.ENQ_DATE%TYPE;
  LV_BOOKING_NUM     SH_ORDBOOK.ORDER_NUM%TYPE;
  LV_RO_NUM          VH_RO.RO_NUM%TYPE;
  LV_RECPT_AMT       ST_APPORTION.APPORTIONED_AMT%TYPE;
  LV_RO_DATE         VARCHAR(30);
  LV_MOBILE_LENGTH   NUMBER(2);
  LV_ERROR_CD        NUMBER(5) := 0;
  LV_ETD             VARCHAR(30);
  LV_ETD_AMT         VH_RO.LABOUR_AMT%TYPE;
  LV_RO_SNAME        GM_EMP.FIRST_NAME%TYPE;
  LV_RO_SMOB         GM_EMP.MOBILE%TYPE;
  LV_REG             VH_RO.REG_NUM%TYPE;
  LV_RO_REV          VARCHAR(30);
  LV_CUST            GM_CIN.CUST_NAME%TYPE; --bhawana
  LV_VALID_MOBILE    NUMBER;
  LV_RCATEG_CD       VH_RO.RCATEG_CD%TYPE; /*Added By Amit for DMSSERV-13207*/
  LV_TEXT_FORMAT1    GM_PROCESS_MASTER.TEXT_FORMAT%TYPE; /*Added By Amit for DMSSERV-13207*/
  LV_AMC_NUM         VARCHAR(100);
  LV_DATE            DATE;
  LV_MIL             NUMBER;
  LV_DATE1           DATE;
  LV_USED            NUMBER;
  LV_BAL             NUMBER;
  LV_REF             NUMBER;
  --lv_tot           NUMBER;
  LV_REF1      NUMBER;
  LV_RO_SMOB1  VARCHAR(50);
  LV_RO_SMOB2  VARCHAR(50);
  LV_RO_SMOB3  VARCHAR(80);
  LV_RO_SMOBA3 VARCHAR(80);
  LV_RO_SMOBN3 VARCHAR(80);
  LV_RO_SMOB4  VARCHAR(50);
  --added by pooja on 01.09.17
  LV_VIN       GM_VIN.VIN%TYPE;
  LV_MSIL_NO   VARCHAR(500);
  LV_CC_MOBILE VARCHAR(50);
  ---added by shankar 25-09-2017 DMSSERV-13396
  LV_UNFT              VARCHAR2(2000);
  LV_UNFT1              VARCHAR2(2000);----Added by chandan ason 11-4-24
  LV_UNFT2              VARCHAR2(2000);----Added by chandan ason 11-4-24
  LV_TEXT_FORMAT_UNFT  GM_PROCESS_MASTER.TEXT_FORMAT%TYPE;
  LV_TEXT_WAITING_CUST GM_PROCESS_MASTER.TEXT_FORMAT%TYPE; ----added by shankar 02-11-2017 DMSSERV-13411
  LV_WATING_YN         VARCHAR2(1); ----added by shankar 02-11-2017 DMSSERV-13411
  LV_CUST_NAME         GM_VIN.CAR_USER_NAME%TYPE; ----DMSSERV-13411
  LV_SA_NAME           GM_EMP.EMP_NAME%TYPE;
  LV_QM_NAME           GM_EMP.EMP_NAME%TYPE;
  LV_QM_MOB            GM_EMP.MOBILE%TYPE; --V_2

  LV_FM_NAME    GM_EMP.EMP_NAME%TYPE; --- ADDED BY AMAN ON 26-02-2018
  LV_FM_MOB     GM_EMP.MOBILE%TYPE; --- ADDED BY AMAN ON 26-02-2018
  LV_SA_MOB     GM_EMP.MOBILE%TYPE; --- ADDED BY AMAN ON 26-02-2018
  LV_REG_NUM    GM_VIN.REG_NUM%TYPE; --- ADDED BY AMAN ON 26-02-2018
  LV_CUST_CD    GM_CIN.CUST_CD%TYPE; --- ADDED BY AMAN ON 26-02-2018
  LV_SA_EMP_CD  GM_EMP.EMP_CD%TYPE; --- ADDED BY AMAN ON 26-02-2018
  LV_FM_EMP_CD  GM_EMP.EMP_CD%TYPE; --- ADDED BY AMAN ON 26-02-2018
  LV_DOC_TYPE   VARCHAR2(1000); --- ADDED BY AMAN ON 26-02-2018
  LV_LINK       VARCHAR2(4000); --- ADDED BY AMAN ON 26-02-2018
  LV_CUST_EMAIL GM_CIN.EMAIL%TYPE; --- ADDED BY AMAN ON 26-02-2018
  LV_TAB_DESC   VARCHAR2(1000); --- ADDED BY SHANKAR ON 30-03-2018

  LV_CHANNEL  AM_DEALER_LOC.CHANNEL%TYPE; ---ADDED BY SHANKAR 06-04-2018
  LV_DESG     GM_EMP.EMP_DESG_CD%TYPE; ---ADDED BY SHANKAR 06-04-2018
  LV_EMP_CD   GM_EMP.EMP_CD%TYPE; ---ADDED BY SHANKAR 06-04-2018
  LV_PMC      AM_DEALER_LOC.PRINCIPAL_MAP_CD%TYPE; ---ADDED BY SHANKAR 06-04-2018
  LV_LOC_DESG AM_DEALER_LOC.LOC_DESC%TYPE; ---ADDED BY SHANKAR 06-04-2018

  LV_UID          NUMBER; -- added by aman on 08-09-2018
  LV_CHK_OCAS_SMS VARCHAR2(100); -- added by aman on 08-09-2018
  LV_SMS_STATUS   NUMBER;
  P_DOC_TYPE_NW varchar2(3000);
  lv_app_url varchar2(150); --ADDED BY SURABHI ON 16-JUL-2025

  --Added by Mahima on 19-Jun-2018 for Critical Customer
  LV_DEALER_CD          VARCHAR2(20);
  LV_CUST_NAME1         GM_CIN.CUST_NAME%TYPE;
  LV_CUST_CATEGORY      GM_VIN.JDPOWER%TYPE;
  LV_MSG                GM_SMS_STATUS.SMS_CONTENT%TYPE;
  LV_TSM_ID             AM_DEALER_LOC.TSMS_ID%TYPE;
  LV_TEXT_CRITICAL_CUST GM_PROCESS_MASTER.TEXT_FORMAT%TYPE;
  LV_MOBILE2            VM_EMAIL_DTL.MOBILE%TYPE;
  LV_TEXT_VOT_OPEN      GM_PROCESS_MASTER.TEXT_FORMAT%TYPE;  --------Added by mohan against scr DMSSERV(S)-13359
  LV_MOB_VOT_OPEN       GM_VIN.CAR_USER_PHONE%TYPE;    --------Added by mohan against scr DMSSERV(S)-13359
  LV_TEXT_VOT_BILL      GM_PROCESS_MASTER.TEXT_FORMAT%TYPE;  --------Added by mohan against scr DMSSERV(S)-13359
  LV_MOB_VOT_BILL       GM_VIN.CAR_USER_PHONE%TYPE;    --------Added by mohan against scr DMSSERV(S)-13359
  LV_WM_VOT_BILL        GM_EMP.FIRST_NAME%TYPE;        --------Added by mohan against scr DMSSERV(S)-13359
  LV_FIND_ID_BILL       VH_RO.FIND_ID%TYPE;  --------Added by mohan against scr DMSSERV(S)-13359
  LV_CVMS_MSG           GM_PROCESS_MASTER.TEXT_FORMAT%TYPE;  -- added by mukesh against SCP2425095183366

  LV_ARENA_NEXA   VARCHAR2(100); --added by aman on 11-01-2018
  lv_channel_sms  varchar2(15); --added by Rameshwar Kumar on 06-March-2019 DMSSAL-12505
  LV_WEBSITE_LINK VARCHAR2(500);
  LV_SVOC_URL     VARCHAR2(100);
  --LV_SVOC_URL              VARCHAR2(100);

  LV_TSMS_ID       am_dealer_loc.tsms_id%type; -- Added by shailesh on 14.02.2020 against DMSSERV-13690
  LV_TSMN_ID       am_dealer_loc.tsmn_id%type; -- Added by shailesh on 14.02.2020 against DMSSERV-13690
  LV_SRL           NUMBER := 0; -- Added by shailesh on 20.02.2020 against DMSSERV-13690
  LV_MOD           RD_ENQ.MODEL_CD%type; /*Added by Kanav on 19-aug-2020 for DMSSAL-12695*/
  LV_LIST_DESC     AM_LIST_RANGE.LIST_DESC%type; /*Added by Kanav on 19-aug-2020 for DMSSAL-12695*/
  LV_MODEL         GM_MOD.MODEL_CD%type; /*Added by Kanav on 19-aug-2020 for DMSSAL-12695*/
  LV_MODEL_CHANNEL gm_var.channel%type;
  lv_rsm_email     vm_email_dtl.email_id%type;
  lv_rsm_email8     vm_email_dtl.email_id%type;--Added by chandan ason 18-4-24
  lv_rsm_email9     vm_email_dtl.email_id%type;--Added by chandan ason 18-4-24
  lv_zsh_email     vm_email_dtl.email_id%type;
  lv_rsm_mobile    vm_email_dtl.mobile%type; --- added by navneet
  lv_zsh_mobile    vm_email_dtl.mobile%type; ---- added by navneet
  LV_REGION        AM_DEALER_LOC.REGION_CD%TYPE;
  lv_check         am_list_range.list_name_desc%type;      --Added by Kanav on 02-Mar-2021 for DMSSAL-12768
  lv_check1        am_list_range.list_from_range%type;      --Added by Kanav on 02-Mar-2021 for DMSSAL-12768

  /*Started by Kanav on 28-Jan-2021 for DMSSAL-12766*/
  LV_BOOKING_DATE     DATE;
  LV_CITY             VARCHAR2(200);
  LV_CCM              VARCHAR2(3000);
  LV_GM               VARCHAR2(1000);
  LV_POC_DSE_CD       VARCHAR2(100);
  LV_GM_EMP_CD        GD_DEALER_MAPPING.GM_EMP_CD%TYPE;
  LV_Gm_Dealer_Map_Cd GD_DEALER_MAPPING.GM_DEALER_MAP_CD%TYPE;
  LV_TESM             VARCHAR2(1000);
  LV_TESM_MOB         GM_EMP.MOBILE%TYPE;
  LV_CCM_MOB          GM_EMP.MOBILE%TYPE;
  LV_CCM_NAME         GM_EMP.EMP_NAME%TYPE;
  LV_GM_MOB           GM_EMP.MOBILE%TYPE;
  /*Ended by Kanav on 28-Jan-2021 for DMSSAL-12766*/

    --Added By Utkarsh Against Smartpick

  LV_BTN_NUM29      VH_BTN.BTN_NUM%TYPE;
  LV_BTN_DATE29     VH_BTN.BTN_DATE%TYPE;
  LV_BTN_SLOT29     VH_BTN.BOOKING_SLOT%TYPE;
  LV_REG_NUM29      VH_BTN.REG_NUM%TYPE;
  LV_SRV_ADV_NAME29 GM_EMP.EMP_NAME%TYPE;
  LV_SRV_ADV_NO29   GM_EMP.PHONE_NO%TYPE;
  LV_DEALER_NAME29  AM_DEALER_LOC.Dealer_Name%TYPE;
 LV_DEALER_NAME1     AM_DEALER_LOC.DEALER_NAME%TYPE;--chandan ason 9/apr/24
 LV_DEALER_NAME2     AM_DEALER_LOC.DEALER_NAME%TYPE;---chandan ason 9/apr/24
  LV_MOBILE29       VARCHAR2(20);

 --Ended By Utkarsh Against Smartpick

  LV_TEXT_FORMAT_PREVENTIVE GM_PROCESS_MASTER.TEXT_FORMAT%TYPE;

   lv_link1         varchar2(30); -- added by shailesh on 20.06.2022
   lv_link2         varchar2(30);
   lv_link3         varchar2(30);
   lv_link4         varchar2(30);

   LV_SUBS_MOBILE          GM_SUBCRIBER_MAST.MOBILE%TYPE;  --Added by saket as on 17-01-2023
   LV_DMS_SUBSCRIBER_ID    GM_SUBCRIBER_MAST.DMS_SUBSCRIBER_ID%TYPE;   --Added by saket as on 17-01-2023
   LV_SUBS_MESSAGE         GM_SMS_STATUS.SMS_CONTENT%TYPE;  --Added by saket as on 17-01-2023
   LV_SUBS_MOBILE_LENGTH   NUMBER;
   v_model_cd rd_enq.model_cd%type:=null; -- added by Nayan on 02-04-2023
   V_ERRCD1  varchar2(50):=null;           -- added by Nayan on 02-04-2023
   V_ERRMSG1   varchar2(150):=null;         -- added by Nayan on 02-04-2023
   V_step1    number(10):=0;                -- added by Nayan on 02-04-2023

  lv_srv_desc  am_list.list_desc%TYPE := NULL; -- Added by Rajeev on 16-JUN-2025 for CDS service type
  lv_dms_sms gm_process_master.dms_sms_flag%type;         --Added by saket as on 04-08-2025
  lv_cmpmgr_sms gm_process_master.cmpmgr_sms_flag%type;   --Added by saket as on 04-08-2025
BEGIN
  -- delete from  check_flow ft where ft.p_proc_nm='SP_PUSH_DMS_MESSAGE';
 -- pick model based on doc number. by Nayan
   V_step1:=1;
        BEGIN  -- added by Nayan
            select rd.model_cd
            INTO v_model_cd
            from rd_enq rd
            WHERE rd.PARENT_GROUP = P_PARENT_GROUP
            AND rd.DEALER_MAP_CD = P_DEALER
            AND rd.LOC_CD = P_LOC_CD
            AND rd.comp_fa = P_COMP_FA
            AND rd.enq_num = P_DOCUMENT_NUM;
        EXCEPTION WHEN OTHERS THEN
            v_model_cd:=null;
            V_ERRCD1:=SQLCODE;
            V_ERRMSG1:=substr(SQLERRM,1,150);
        END;

    BEGIN
      SELECT PRM.PROCESS_CODE, PRM.TEXT_FORMAT
            ,NVL(PRM.DMS_SMS_FLAG,'Y'),PRM.CMPMGR_SMS_FLAG  --Added by saket as on 04-08-2025
        INTO LV_PROCESS, LV_TEXT_FORMAT
            ,LV_DMS_SMS,LV_CMPMGR_SMS  --Added by saket as on 04-08-2025
        FROM GM_DLR_SMS_MAPPING SMM, GM_PROCESS_MASTER PRM
       WHERE SMM.PARENT_GROUP = P_PARENT_GROUP
         AND SMM.DEALER_MAP_CD = P_DEALER
         AND SMM.LOC_CD = P_LOC_CD
         AND SMM.PROCESS_CODE = P_TRAN_TYPE
         AND TRUNC(SMM.CREATED_DATE) <= TRUNC(SYSDATE)
         AND NVL(SMM.DEACTIVATION_DATE, SYSDATE) >= TRUNC(SYSDATE)
         AND SMM.PROCESS_CODE = PRM.PROCESS_CODE
         AND PRM.PRINCIPAL_MAP_CD = SF_PRINCIPAL_MAP_CD(P_DEALER, P_LOC_CD) --added by akanksha for multicompany change
         AND PRM.ACTIVE_FLAG = 'Y';
     EXCEPTION WHEN OTHERS THEN
        LV_PROCESS     := NULL;
        LV_TEXT_FORMAT := NULL;
        V_ERRCD1:=SQLCODE;
        V_ERRMSG1:=substr(SQLERRM,1,150);
    END;

    IF  NVL(v_model_cd,'X')='GV' THEN
                V_STEP1:=2;
                    BEGIN
                      SELECT PROCESS_CODE,TEXT_FORMAT
                      ,NVL(gm.DMS_SMS_FLAG,'Y'),gm.CMPMGR_SMS_FLAG  --Added by saket as on 04-08-2025
                      INTO LV_PROCESS, LV_TEXT_FORMAT
                      ,LV_DMS_SMS,LV_CMPMGR_SMS  --Added by saket as on 04-08-2025
                      from gm_process_master gm
                      where gm.process_code = 'DMS_ENQUIRY_GV'
                      and principal_map_cd = 1;
                    EXCEPTION WHEN OTHERS THEN
                        LV_PROCESS     := NULL;
                        LV_TEXT_FORMAT := NULL;
                          V_ERRCD1:=SQLCODE;
                          V_ERRMSG1:=substr(SQLERRM,1,150);
                    END;
          ELSIF  NVL(v_model_cd,'X')='FR' THEN
          V_STEP1:=3;
                    BEGIN
                      SELECT PROCESS_CODE,TEXT_FORMAT
                          ,NVL(gm.DMS_SMS_FLAG,'Y'),gm.CMPMGR_SMS_FLAG  --Added by saket as on 04-08-2025
                      INTO LV_PROCESS, LV_TEXT_FORMAT
                          ,LV_DMS_SMS,LV_CMPMGR_SMS  --Added by saket as on 04-08-2025
                      from gm_process_master gm
                      where gm.process_code = 'DMS_ENQUIRY_FR'
                      and principal_map_cd = 1;
                   EXCEPTION WHEN OTHERS THEN
                        LV_PROCESS     := NULL;
                        LV_TEXT_FORMAT := NULL;
                        V_ERRCD1:=SQLCODE;
                        V_ERRMSG1:=substr(SQLERRM,1,150);
                    END;
          ELSE
            V_STEP1:=4;
               BEGIN
                      SELECT PRM.PROCESS_CODE, PRM.TEXT_FORMAT
                                            INTO LV_PROCESS, LV_TEXT_FORMAT
                        FROM GM_DLR_SMS_MAPPING SMM, GM_PROCESS_MASTER PRM
                       WHERE SMM.PARENT_GROUP = P_PARENT_GROUP
                         AND SMM.DEALER_MAP_CD = P_DEALER
                         AND SMM.LOC_CD = P_LOC_CD
                         AND SMM.PROCESS_CODE = P_TRAN_TYPE
                         AND TRUNC(SMM.CREATED_DATE) <= TRUNC(SYSDATE)
                         AND NVL(SMM.DEACTIVATION_DATE, SYSDATE) >= TRUNC(SYSDATE)
                         AND SMM.PROCESS_CODE =   PRM.PROCESS_CODE
                         AND PRM.PRINCIPAL_MAP_CD = SF_PRINCIPAL_MAP_CD(P_DEALER, P_LOC_CD) --added by akanksha for multicompany change
                         AND PRM.ACTIVE_FLAG = 'Y';
                    EXCEPTION WHEN OTHERS THEN
                        LV_PROCESS     := NULL;
                        LV_TEXT_FORMAT := NULL;
                        V_ERRCD1:=SQLCODE;
                        V_ERRMSG1:=substr(SQLERRM,1,150);
                     end;
          END IF;

  ------------->  Begin Added by Rameshwar Kumar on 06-Mar-2019  DMSSAL-12505   <-------------------
  V_STEP1:=5;
  Begin
    Select channel
      into lv_channel_sms
      from Am_Dealer_Loc am
     WHERE am.PARENT_GROUP = P_PARENT_GROUP
       AND am.DEALER_MAP_CD = P_DEALER
       AND am.LOC_CD = P_LOC_CD
       and am.principal_map_cd = SF_PRINCIPAL_MAP_CD(P_DEALER, P_LOC_CD);
  Exception when others then
      lv_channel_sms:=null;
      V_ERRCD1:=SQLCODE;
      V_ERRMSG1:=substr(SQLERRM,1,150);
 end;
   /*Begin

    SELECT LIST_DESC
    INTO LV_WEBSITE_LINK
    FROM AM_LIST
    WHERE LIST_NAME = 'SMS_BOOKING_CHANNEL'
    AND PRINCIPAL_MAP_CD = 1
    AND LIST_CODE = lv_channel_sms;

  Exception
    when others then
      null;
  End;*/ /*Commented by Kanav on 19-aug-2020 for DMSSAL-12695*/
 V_STEP1:=6;

    Begin
      SELECT LIST_DESC
      INTO LV_SVOC_URL
      FROM AM_LIST
      WHERE LIST_NAME = 'SVOC_URL'
      AND PRINCIPAL_MAP_CD = 1;
    Exception  when others then
                V_ERRCD1:=SQLCODE;
                V_ERRMSG1:=substr(SQLERRM,1,150);
    End;

    --ADDED APP URL VARIABLE BY SURABHI ON 16-JUL-2025
      BEGIN
       SELECT LIST_DESC  INTO lv_app_url FROM am_list_range WHERE list_name = 'MSL_APP_URL' AND PRINCIPAL_MAP_CD =1 AND LIST_CODE = '01';
      EXCEPTION
        WHEN OTHERS THEN
          lv_app_url := NULL;
      END;

    IF NVL(LV_PROCESS, '@') = 'SVOC_URL' AND LV_TEXT_FORMAT IS NOT NULL THEN
         V_STEP1:=7;
        BEGIN
          SELECT MOBILE
            INTO LV_MOBILE
            FROM GM_EMP
           WHERE MSPIN = P_DOCUMENT_NUM
             AND NVL(EMP_LEAVING_DATE, SYSDATE) >= SYSDATE
             AND EMP_APPROVE = 'A';
         EXCEPTION WHEN OTHERS THEN
                LV_ERROR_CD := 1;
                LV_MOBILE := NULL;
                V_ERRCD1:=SQLCODE;
                V_ERRMSG1:=substr(SQLERRM,1,150);
        end;

        IF NVL(LV_ERROR_CD, 0) != 1 THEN
        V_STEP1:=8;
        begin
          SELECT REPLACE(LV_TEXT_FORMAT, '<SVOC URL>', LV_SVOC_URL)
          INTO LV_MESSAGE
          FROM DUAL;
         EXCEPTION WHEN OTHERS THEN
            LV_MESSAGE := NULL;
            V_ERRCD1:=SQLCODE;
            V_ERRMSG1:=substr(SQLERRM,1,150);
        end;

          IF LV_SVOC_URL IS NOT NULL THEN
            INSERT INTO GM_SMS_STATUS
              (UNIQUE_NUMBER,
               PARENT_GROUP,
               DEALER_MAP_CD,
               LOC_CD,
               PROCESS_CODE,
               DOCUMENT_TYPE,
               DOCUMENT_NO,
               SMS_TYPE,
               MOBILE_NO,
               SMS_CONTENT,
               CREATED_DATE,
               CREATED_BY,
               STATUS,
               SENT_DATE,
               REMARKS,
               SRL_NO)
            VALUES
              (DMS_SMS_UNIQUE_NO.NEXTVAL,
               P_PARENT_GROUP,
               P_DEALER,
               P_LOC_CD,
               LV_PROCESS,
               P_DOC_TYPE,
               P_DOCUMENT_NUM,
               'T',
               '91' || LV_MOBILE,
               LV_MESSAGE,
               SYSDATE,
               P_CREATED_BY,
               1,
               NULL,
               NULL,
               1);

          ELSE
            INSERT INTO GM_SMS_STATUS
              (UNIQUE_NUMBER,
               PARENT_GROUP,
               DEALER_MAP_CD,
               LOC_CD,
               PROCESS_CODE,
               DOCUMENT_TYPE,
               DOCUMENT_NO,
               SMS_TYPE,
               MOBILE_NO,
               SMS_CONTENT,
               CREATED_DATE,
               CREATED_BY,
               STATUS,
               SENT_DATE,
               REMARKS,
               SRL_NO)
            VALUES
              (DMS_SMS_UNIQUE_NO.NEXTVAL,
               P_PARENT_GROUP,
               P_DEALER,
               P_LOC_CD,
               LV_PROCESS,
               P_DOC_TYPE,
               P_DOCUMENT_NUM,
               'T',
               LV_MOBILE,
               LV_MESSAGE,
               SYSDATE,
               P_CREATED_BY,
               8,
               NULL,
               'DATA NOT CORRECT',
               1);

          END IF;
        END IF;
      COMMIT;
    END IF;
  ------------->  End Added by Rameshwar Kumar on 06-Mar-2019    DMSSAL-12505   <-------------------

  ---FOR ENQUIRY--
      V_STEP1:=9;
      LV_PROCESS:=upper(LV_PROCESS);

  IF instr(NVL(LV_PROCESS, '@'),'DMS_ENQUIRY')>0 AND LV_TEXT_FORMAT IS NOT NULL THEN
    V_step1:=10;

    BEGIN
      BEGIN
        SELECT GM.MODEL_DESC,
               DECODE(SUBSTR(RH.MOBILE, 1, 1),
                      '0',
                      SUBSTR(RH.MOBILE, 2),
                      RH.MOBILE),
               TRUNC(RH.ENQ_DATE),
               SUBSTR(LOC.DEALER_NAME, 1, 30) DEALER_NAME,
               LENGTH(DECODE(SUBSTR(RH.MOBILE, 1, 1),
                             '0',
                             SUBSTR(RH.MOBILE, 2),
                             RH.MOBILE)),
               RD.MODEL_CD /*Added by Kanav on 19-aug-2020 for DMSSAL-12695*/
          INTO LV_MODEL_DESC,
               LV_MOBILE,
               LV_ENQ_DATE,
               LV_DEALER_NAME,
               LV_MOBILE_LENGTH,
               LV_MOD /*Added by Kanav on 19-aug-2020 for DMSSAL-12695*/
          FROM RH_ENQ        RH,
               RD_ENQ        RD,
               AM_DEALER_LOC LOC,
               RM_ETYPES     RM,
               GM_MOD        GM
         WHERE RH.PARENT_GROUP = P_PARENT_GROUP
           AND RH.DEALER_MAP_CD = P_DEALER
           AND RH.LOC_CD = P_LOC_CD
           AND RH.COMP_FA = P_COMP_FA
           AND RH.ENQ_NUM = P_DOCUMENT_NUM
           AND RD.PARENT_GROUP = RH.PARENT_GROUP
           AND RD.DEALER_MAP_CD = RH.DEALER_MAP_CD
           AND RD.LOC_CD = RH.LOC_CD
           AND RD.COMP_FA = RH.COMP_FA
           AND RD.ENQ_NUM = RH.ENQ_NUM
           AND RD.ENQ_VAR_SRL = 1
           AND LOC.DEALER_MAP_CD = RH.DEALER_MAP_CD
           AND LOC.LOC_CD = RH.LOC_CD
           AND RM.DEALER_MAP_CD = RH.DEALER_MAP_CD
           AND RM.ETYPE_CD = RH.ETYPE_CD
           AND RM.ETYPE_FLAG != 'D'
              --AND   GM.PRINCIPAL_MAP_CD=1
           AND GM.PRINCIPAL_MAP_CD = LOC.PRINCIPAL_MAP_CD --added by akanksha for multicompany change
           AND GM.MODEL_CD = RD.MODEL_CD;
      EXCEPTION WHEN OTHERS THEN
          LV_ERROR_CD := 1;
          LV_MODEL_DESC    := NULL;
          LV_MOBILE        := NULL;
          LV_ENQ_DATE      := NULL;
          LV_DEALER_NAME   := NULL;
          LV_MOBILE_LENGTH := 0;
          LV_MOD           := NULL; /*Added by Kanav on 19-aug-2020 for DMSSAL-12695*/
          V_ERRCD1:=SQLCODE;
          V_ERRMSG1:=substr(SQLERRM,1,150);
      END;

            -- added by nayan on -01-apr-24
            if nvl(v_model_cd,'X')='GV' and v_model_cd is not null then -- GV
              v_step1:=11;
                begin
                    select al.list_desc,al.list_name_desc
                    into LV_LIST_DESC,lv_check
                    from am_list_range al
                    where al.list_name = 'DMS_ENQUIRY_SMS'
                    and al.list_code=v_model_cd
                    and al.principal_map_cd=1;
                exception  when others then
                        LV_LIST_DESC := '';
                        lv_check     := '';                  --lv_check added by Kanav on 02-Mar-2021 for DMSSAL-12768
                        V_ERRCD1:=SQLCODE;
                        V_ERRMSG1:=substr(SQLERRM,1,150);
                end;
          elsif nvl(v_model_cd,'X')='FR' and v_model_cd is not null then --CASE FR
                v_step1:=12;
               begin
                    select al.list_desc,al.list_name_desc
                    into LV_LIST_DESC,lv_check
                    from am_list_range al
                    where al.list_name = 'DMS_ENQUIRY_SMS'
                    and al.list_code=v_model_cd
                    and al.principal_map_cd=1;
                exception  when others then
                        LV_LIST_DESC := '';
                        lv_check     := '';                  --lv_check added by Kanav on 02-Mar-2021 for DMSSAL-12768
                        V_ERRCD1:=SQLCODE;
          V_ERRMSG1:=substr(SQLERRM,1,150);
       end;
    else    -- BELOW IS THE OLD CODE AS IT IS
              V_STEP1:=13;
        begin
          select list_Desc,LIST_NAME_DESC        --LIST_NAME_DESC added by Kanav on 02-Mar-2021 for DMSSAL-12768
          into LV_LIST_DESC,lv_check
          from am_list_range
          WHERE LIST_NAME = 'DMS_ENQUIRY_SMS'
          and principal_map_cd = 1
          and list_Code = LV_MOD;
        exception when others then
          LV_LIST_DESC := '';
          lv_check     := '';                  --lv_check added by Kanav on 02-Mar-2021 for DMSSAL-12768
          V_ERRCD1:=SQLCODE;
          V_ERRMSG1:=substr(SQLERRM,1,150);
        end; /*Added by Kanav on 19-aug-2020 for DMSSAL-12695*/
    end if;
      IF NVL(LV_ERROR_CD, 0) != 1 THEN
                 if nvl(v_model_cd,'X') IN ('GV','FR') and v_model_cd is not null AND LV_TEXT_FORMAT IS NOT NULL then
                               SELECT REPLACE(LV_TEXT_FORMAT,
                                                             '<Test Link>',
                                                             LV_LIST_DESC)   --added by NARAN on 01-APR-2024
                                INTO LV_MESSAGE
                                FROM DUAL;
                 ELSE
                                SELECT replace(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LV_TEXT_FORMAT,
                                                               '<Model name>',
                                                               LV_MODEL_DESC),
                                                       '<Enquiry Date>',
                                                       LV_ENQ_DATE),
                                               '<Dealer name>',
                                               LV_DEALER_NAME),
                                       '<URL>',
                                       LV_LIST_DESC), /*Added by Kanav on 19-aug-2020 for DMSSAL-12695*/
                               '<CM>',
                               LV_MOBILE), /*Added by Kanav on 19-aug-2020 for DMSSAL-12695*/
                       '<check>',
                       lv_check)              --lv_check added by Kanav on 02-Mar-2021 for DMSSAL-12768
            INTO LV_MESSAGE
            FROM DUAL;
                 END IF;
        IF LV_MODEL_DESC IS NOT NULL AND LV_MOBILE IS NOT NULL AND
           LV_MOBILE_LENGTH = 10 AND LV_ENQ_DATE IS NOT NULL AND
           LV_DEALER_NAME IS NOT NULL THEN
           ----Added by saket as on 15-07-2025 for SMS Changes(start)
           IF lv_cmpmgr_sms='Y' THEN   --Added by saket as on 04-08-2025
           DECLARE
                L_ERR_CD   NUMBER;
                L_ERR_DESC VARCHAR2(500);
                lv_campaign_name  VARCHAR2(100);
                Lv_template_name  VARCHAR2(100);
           BEGIN
          BEGIN
            Select GM.Campaign_Name, gm.template_name
            into lv_campaign_name, lv_template_name
            from GM_CMP_MGR_PROCESS GM, gm_process_master X
             where gm.template_id = x.template_id
             and x.process_code = LV_PROCESS;
          EXCEPTION
            WHEN OTHERS THEN
              lv_campaign_name:=NULL;
              lv_template_name:=NULL;
          END;
      IF lv_campaign_name is not null and LV_PROCESS='DMS_ENQUIRY' THEN
           SP_SMS_CMPMGR(P_CAMPAIGNNAME => lv_campaign_name,
                              P_TEMPLATENAME => lv_template_name,
                              P_PROCESS_CODE => LV_PROCESS,
                              P_PARENT_GROUP => P_PARENT_GROUP,
                              P_DEALER_MAP_CD => P_DEALER,
                              P_LOC_CD => P_LOC_CD,
                              P_DOCUMENT_TYPE => P_DOC_TYPE,
                              P_DOCUMENT_NO => P_DOCUMENT_NUM,
                              P_MOBILE_NO => LV_MOBILE,
                              P_PLACEHOLDER1 => LV_MODEL_DESC,
                              P_PLACEHOLDER2 => LV_ENQ_DATE,
                              P_PLACEHOLDER3 => LV_DEALER_NAME,
                              P_PLACEHOLDER4 => lv_check,
                              P_PLACEHOLDER5 => LV_MODEL_DESC,
                              P_PLACEHOLDER6 => substr(LV_LIST_DESC,1,30),
                              P_PLACEHOLDER7 => substr(LV_LIST_DESC,31,30),
                              P_PLACEHOLDER8 => substr(LV_LIST_DESC,61,30),
                              P_PLACEHOLDER9 => LV_MOBILE,
                              P_REAL_TIME_YN => 'N',
                              P_USER_ID => P_CREATED_BY,
                              P_URLSHORTEN_YN => 'N',
                              P_MSG_TYPE => 'SMS',
                              P_ERR_CD => L_ERR_CD,
                              P_ERR_DESC => L_ERR_DESC
                              );
            END IF;
      IF lv_campaign_name is not null and LV_PROCESS in ('DMS_ENQUIRY_FR','DMS_ENQUIRY_GV') THEN
           SP_SMS_CMPMGR(P_CAMPAIGNNAME => lv_campaign_name,
                              P_TEMPLATENAME => lv_template_name,
                              P_PROCESS_CODE => LV_PROCESS,
                              P_PARENT_GROUP => P_PARENT_GROUP,
                              P_DEALER_MAP_CD => P_DEALER,
                              P_LOC_CD => P_LOC_CD,
                              P_DOCUMENT_TYPE => P_DOC_TYPE,
                              P_DOCUMENT_NO => P_DOCUMENT_NUM,
                              P_MOBILE_NO => LV_MOBILE,
                              P_PLACEHOLDER1 => substr(LV_LIST_DESC,1,30),
                              P_PLACEHOLDER2 => substr(LV_LIST_DESC,31,30),
                              P_PLACEHOLDER3 => Null,
                              P_PLACEHOLDER4 => Null,
                              P_PLACEHOLDER5 => Null,
                              P_PLACEHOLDER6 => Null,
                              P_PLACEHOLDER7 => Null,
                              P_PLACEHOLDER8 => Null,
                              P_PLACEHOLDER9 => Null,
                              P_REAL_TIME_YN => 'Y',
                              P_USER_ID => P_CREATED_BY,
                              P_URLSHORTEN_YN => 'Y',
                              P_MSG_TYPE => 'SMS',
                              P_ERR_CD => L_ERR_CD,
                              P_ERR_DESC => L_ERR_DESC
                              );
            END IF;
            END;
            END IF; --Added by saket as on 04-08-2025
           ----Added by saket as on 15-07-2025 for SMS Changes(end)
         IF lv_dms_sms='Y' THEN  --Added by saket as on 04-08-2025
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             '91' || LV_MOBILE,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             1,
             NULL,
             NULL,
             1);
          END IF;--Added by saket as on 04-08-2025

        ELSE
         IF lv_dms_sms='Y' THEN  --Added by saket as on 04-08-2025
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             LV_MOBILE,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             8,
             NULL,
             'DATA NOT CORRECT',
             1);
         END IF;  --Added by saket as on 04-08-2025

        END IF;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    COMMIT;
  END IF;

  -----FOR BOOKING--------

  IF NVL(LV_PROCESS, '@') = 'DMS_BOOKING' AND LV_TEXT_FORMAT IS NOT NULL THEN

    LV_MODEL_DESC  := NULL;
    LV_MOBILE      := NULL;
    LV_BOOKING_NUM := NULL;
    LV_DEALER_NAME := NULL;
    LV_SUBS_MOBILE:=NULL;                 --Added by saket as on 17-01-2023
    LV_SUBS_MOBILE_LENGTH:=NULL;          --Added by saket as on 17-01-2023

    BEGIN
      BEGIN
        SELECT GM.MODEL_DESC,
               DECODE(SUBSTR(SH.MOBILE, 1, 1),
                      '0',
                      SUBSTR(SH.MOBILE, 2),
                      SH.MOBILE),
               SH.ORDER_NUM,
               SUBSTR(LOC.DEALER_NAME, 1, 30) DEALER_NAME,
               LENGTH(DECODE(SUBSTR(SH.MOBILE, 1, 1),
                             '0',
                             SUBSTR(SH.MOBILE, 2),
                             SH.MOBILE)),
               GM.MODEL_CD, /*Added by Kanav on 19-aug-2020 for DMSSAL-12695*/
               sh.dms_subscriber_id  --Added by saket as on 17-01-2023
          INTO LV_MODEL_DESC,
               LV_MOBILE,
               LV_BOOKING_NUM,
               LV_DEALER_NAME,
               LV_MOBILE_LENGTH,
               LV_MODEL, /*Added by Kanav on 19-aug-2020 for DMSSAL-12695*/
               LV_DMS_SUBSCRIBER_ID  --Added by saket as on 17-01-2023
          FROM SH_ORDBOOK SH, AM_DEALER_LOC LOC, GM_VAR GV, GM_MOD GM
         WHERE SH.PARENT_GROUP = P_PARENT_GROUP
           AND SH.DEALER_MAP_CD = P_DEALER
           AND SH.LOC_CD = P_LOC_CD
           AND SH.COMP_FA = P_COMP_FA
           AND SH.ORDER_NUM = P_DOCUMENT_NUM
           AND LOC.DEALER_MAP_CD = SH.DEALER_MAP_CD
           AND LOC.LOC_CD = SH.LOC_CD
           AND GV.VARIANT_CD = NVL(SH.AMND_VARIANT_CD, SH.VARIANT_CD)
           AND GV.MODEL_CAT_CD = '001'
           AND GV.PRINCIPAL_MAP_CD = LOC.PRINCIPAL_MAP_CD --added by akanksha for multicompany change
           AND GM.PRINCIPAL_MAP_CD = LOC.PRINCIPAL_MAP_CD --added by akanksha for multicompany change
           AND GM.MODEL_CD = GV.MODEL_CD;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          LV_ERROR_CD := 1;
        WHEN OTHERS THEN
          LV_MODEL_DESC    := NULL;
          LV_MOBILE        := NULL;
          LV_BOOKING_NUM   := NULL;
          LV_DEALER_NAME   := NULL;
          LV_MOBILE_LENGTH := 0;
          LV_MODEL         := NULL; /*Added by Kanav on 19-aug-2020 for DMSSAL-12695*/
      END;

      begin
        select list_Desc,LIST_NAME_DESC,list_from_range        --LIST_NAME_DESC and list_from_range added by Kanav on 02-Mar-2021 for DMSSAL-12768
          into LV_WEBSITE_LINK,lv_check,lv_check1
          from am_list_range
         WHERE LIST_NAME = 'DMS_BOOKING_SMS'
           and principal_map_cd = 1
           and list_Code = LV_MODEL;
      exception
        when others then
          LV_WEBSITE_LINK := '';
          lv_check     := '';                  --lv_check added by Kanav on 02-Mar-2021 for DMSSAL-12768
          lv_check1     := '';                 --lv_check1 added by Kanav on 02-Mar-2021 for DMSSAL-12768
      end;

      IF NVL(LV_ERROR_CD, 0) != 1 THEN

        SELECT REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LV_TEXT_FORMAT,
                                                                       '<Model Booked>',
                                                                       LV_MODEL_DESC),
                                                               '<Booking ID>',
                                                               LV_BOOKING_NUM),
                                                       '<Dealershp name>',
                                                       LV_DEALER_NAME),
                                               '<Website Link>',
                                               LV_WEBSITE_LINK), -- ------------->  Begin Added by Rameshwar Kumar on 06-Mar-2019  DMSSAL-12505   <-------------------
                                       '<CM>',
                                       LV_MOBILE), /*Added by Kanav on 19-aug-2020 for DMSSAL-12695*/
                               '<check>',
                               LV_CHECK), --lv_check added by Kanav on 02-Mar-2021 for DMSSAL-12768
                       '<check1>',
                       LV_CHECK1)         --lv_check1 added by Kanav on 02-Mar-2021 for DMSSAL-12768
          INTO LV_MESSAGE
          FROM DUAL;

        IF LV_MODEL_DESC IS NOT NULL AND LV_MOBILE IS NOT NULL AND
           LV_MOBILE_LENGTH = 10 AND LV_BOOKING_NUM IS NOT NULL AND
           LV_DEALER_NAME IS NOT NULL THEN
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             '91' || LV_MOBILE,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             1,
             NULL,
             NULL,
             1);

        ELSE
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             LV_MOBILE,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             8,
             NULL,
             'DATA NOT CORRECT',
             1);

        END IF;
        --Added by saket as on 17-01-2023(start)
        IF LV_DMS_SUBSCRIBER_ID IS NOT NULL THEN
            BEGIN
              SELECT MOBILE
                    ,LENGTH(DECODE(SUBSTR(MOBILE, 1, 1),
                             '0',
                             SUBSTR(MOBILE, 2),
                             MOBILE))
                INTO LV_SUBS_MOBILE
                    ,LV_SUBS_MOBILE_LENGTH
                FROM GM_SUBCRIBER_MAST
               WHERE DMS_SUBSCRIBER_ID=LV_DMS_SUBSCRIBER_ID;
            EXCEPTION
              WHEN OTHERS THEN
                LV_SUBS_MOBILE:=NULL;
                LV_SUBS_MOBILE_LENGTH:=NULL;
            END;
      IF NVL(LV_ERROR_CD, 0) != 1 THEN

        SELECT REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LV_TEXT_FORMAT,
                                                                       '<Model Booked>',
                                                                       LV_MODEL_DESC),
                                                               '<Booking ID>',
                                                               LV_BOOKING_NUM),
                                                       '<Dealershp name>',
                                                       LV_DEALER_NAME),
                                               '<Website Link>',
                                               LV_WEBSITE_LINK), -- ------------->  Begin Added by Rameshwar Kumar on 06-Mar-2019  DMSSAL-12505   <-------------------
                                       '<CM>',
                                       LV_SUBS_MOBILE), /*Added by Kanav on 19-aug-2020 for DMSSAL-12695*/
                               '<check>',
                               LV_CHECK), --lv_check added by Kanav on 02-Mar-2021 for DMSSAL-12768
                       '<check1>',
                       LV_CHECK1)         --lv_check1 added by Kanav on 02-Mar-2021 for DMSSAL-12768
          INTO LV_SUBS_MESSAGE
          FROM DUAL;
      END IF;
            IF LV_MODEL_DESC IS NOT NULL AND LV_SUBS_MOBILE IS NOT NULL AND
               LV_SUBS_MOBILE_LENGTH = 10 AND LV_BOOKING_NUM IS NOT NULL AND
               LV_DEALER_NAME IS NOT NULL AND LV_SUBS_MESSAGE IS NOT NULL THEN
              INSERT INTO GM_SMS_STATUS
                (UNIQUE_NUMBER,
                 PARENT_GROUP,
                 DEALER_MAP_CD,
                 LOC_CD,
                 PROCESS_CODE,
                 DOCUMENT_TYPE,
                 DOCUMENT_NO,
                 SMS_TYPE,
                 MOBILE_NO,
                 SMS_CONTENT,
                 CREATED_DATE,
                 CREATED_BY,
                 STATUS,
                 SENT_DATE,
                 REMARKS,
                 SRL_NO)
              VALUES
                (DMS_SMS_UNIQUE_NO.NEXTVAL,
                 P_PARENT_GROUP,
                 P_DEALER,
                 P_LOC_CD,
                 LV_PROCESS,
                 P_DOC_TYPE,
                 P_DOCUMENT_NUM,
                 'T',
                 '91' || LV_SUBS_MOBILE,
                 LV_SUBS_MESSAGE,
                 SYSDATE,
                 P_CREATED_BY,
                 1,
                 NULL,
                 NULL,
                 2);

            ELSE
              INSERT INTO GM_SMS_STATUS
                (UNIQUE_NUMBER,
                 PARENT_GROUP,
                 DEALER_MAP_CD,
                 LOC_CD,
                 PROCESS_CODE,
                 DOCUMENT_TYPE,
                 DOCUMENT_NO,
                 SMS_TYPE,
                 MOBILE_NO,
                 SMS_CONTENT,
                 CREATED_DATE,
                 CREATED_BY,
                 STATUS,
                 SENT_DATE,
                 REMARKS,
                 SRL_NO)
              VALUES
                (DMS_SMS_UNIQUE_NO.NEXTVAL,
                 P_PARENT_GROUP,
                 P_DEALER,
                 P_LOC_CD,
                 LV_PROCESS,
                 P_DOC_TYPE,
                 P_DOCUMENT_NUM,
                 'T',
                 LV_SUBS_MOBILE,
                 LV_SUBS_MESSAGE,
                 SYSDATE,
                 P_CREATED_BY,
                 8,
                 NULL,
                 'DATA NOT CORRECT',
                 2);

            END IF;
        END IF;
        --Added by saket as on 17-01-2023(end)
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    COMMIT;
  END IF;
  ---Receipts
  IF NVL(LV_PROCESS, '@') = 'DMS_RECEIPT' AND LV_TEXT_FORMAT IS NOT NULL THEN
    BEGIN
      BEGIN
        SELECT /*+ index (st IDX_ST_APPORTION_REC_NUM)*/
         DECODE(SUBSTR(GM.MOBILE_PHONE, 1, 1), --add index kanhaiya 23-nov-2016
                '0',
                SUBSTR(GM.MOBILE_PHONE, 2),
                GM.MOBILE_PHONE),
         ST.DOC_NUM,
         SUBSTR(LOC.DEALER_NAME, 1, 30) DEALER_NAME,
         ST.APPORTIONED_AMT,
         LENGTH(DECODE(SUBSTR(GM.MOBILE_PHONE, 1, 1),
                       '0',
                       SUBSTR(GM.MOBILE_PHONE, 2),
                       GM.MOBILE_PHONE))
          INTO LV_MOBILE,
               LV_BOOKING_NUM,
               LV_DEALER_NAME,
               LV_RECPT_AMT,
               LV_MOBILE_LENGTH
          FROM ST_APPORTION ST, AM_DEALER_LOC LOC, GM_CIN GM
         WHERE ST.PARENT_GROUP = P_PARENT_GROUP
           AND ST.DEALER_MAP_CD = P_DEALER
           AND ST.LOC_CD = P_LOC_CD
           AND ST.COMP_FA = P_COMP_FA
           AND ST.REC_NUM = P_DOCUMENT_NUM
           --AND ST.DOC_TYPE = 'ORD' Commented by Rameshwar on 30-Nov-2021, SMS to be sent for any receipt creation
           AND LOC.DEALER_MAP_CD = ST.DEALER_MAP_CD
           AND LOC.LOC_CD = ST.LOC_CD
           AND GM.PRINCIPAL_MAP_CD = LOC.PRINCIPAL_MAP_CD --added by akanksha for multicompany change
           AND GM.CUST_CD = ST.CUST_CD;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          LV_ERROR_CD := 1;
        WHEN OTHERS THEN
          LV_MOBILE        := NULL;
          LV_BOOKING_NUM   := NULL;
          LV_DEALER_NAME   := NULL;
          LV_MOBILE_LENGTH := 0;
          LV_RECPT_AMT     := 0;
      END;
--Added by saket o 16-12-2025 aginst DMS-5610(start)
        begin
        select list_Desc
         into LV_WEBSITE_LINK
          from am_list_range
         WHERE LIST_NAME = 'DMS_RECEIPT_SMS'
           and principal_map_cd = 1
           and nvl(list_flag,'Y')='Y' ;
        exception
          when others then
               LV_WEBSITE_LINK:=null;
        end;
--Added by saket o 16-12-2025 aginst DMS-5610(end)
      IF NVL(LV_ERROR_CD, 0) != 1 THEN
        /*SELECT REPLACE(REPLACE(REPLACE(LV_TEXT_FORMAT,
                                       '<dealership name>',
                                       LV_DEALER_NAME),
                               '<Amount>',
                               LV_RECPT_AMT),
                       '<Booking ID>',
                       LV_BOOKING_NUM)
          INTO LV_MESSAGE
          FROM DUAL;Commeted against DMS-5610*/
--Added by saket o 16-12-2025 aginst DMS-5610(start)
        SELECT REPLACE(REPLACE(REPLACE(REPLACE(LV_TEXT_FORMAT,
                                       '<dealership name>',
                                       LV_DEALER_NAME),
                               '<Amount>',
                               LV_RECPT_AMT),
                       '<Booking ID>',
                       LV_BOOKING_NUM),
                       '<url>',
                       LV_WEBSITE_LINK)
          INTO LV_MESSAGE
          FROM DUAL;
--Added by saket o 16-12-2025 aginst DMS-5610(end)

        IF LV_MOBILE IS NOT NULL AND LV_MOBILE_LENGTH = 10 AND
           LV_BOOKING_NUM IS NOT NULL AND LV_DEALER_NAME IS NOT NULL AND
           LV_RECPT_AMT IS NOT NULL THEN
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             '91' || LV_MOBILE,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             1,
             NULL,
             NULL,
             1);

        ELSE

          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             LV_MOBILE,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             8,
             NULL,
             'DATA NOT CORRECT',
             1);

        END IF;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    COMMIT;
  END IF;

  --------------------Code added by BHAWANA-------------------------------
  ---FOR JOBCARD OPENING-
  IF NVL(LV_PROCESS, '@') = 'JC_OPENING' AND LV_TEXT_FORMAT IS NOT NULL THEN
    BEGIN
      BEGIN
        SELECT RO.RO_NUM,
               TO_CHAR(RO.RO_DATE, 'DD/MON/YYYY HH24:MI'),
               TO_CHAR(RO.PROMISED_DATE, 'DD/MON/YYYY HH24:MI'),
               --nvl((RO.EST_PART_AMT + RO.EST_LAB_AMT), 0),--Commented by Aafaq on 03-08-2015
               DECODE(NVL(RO.REV_EST_PART_AMT, 0),
                      0,
                      NVL(RO.EST_PART_AMT, 0),
                      RO.REV_EST_PART_AMT) +
               DECODE(NVL(RO.REV_EST_LAB_AMT, 0),
                      0,
                      NVL(RO.EST_LAB_AMT, 0),
                      RO.REV_EST_LAB_AMT) + --Added by Aafaq on 03-08-2015 for checking Revised Estimation Amount if found.
               DECODE(NVL(RO.SCH_REV_EST_PART_AMT, 0), --ADDED BY POOJA ON 11.08.17
                      0,
                      NVL(RO.SCH_EST_PART_AMT, 0),
                      RO.SCH_REV_EST_PART_AMT) +
               DECODE(NVL(RO.SCH_REV_EST_LAB_AMT, 0),
                      0,
                      NVL(RO.SCH_EST_LAB_AMT, 0),
                      RO.SCH_REV_EST_LAB_AMT),
               RO.VIN, --Added By Mahima on 19-JUN-2018 against Critical Customer
               LOC.MUL_SRV_DEALER_CD || LOC.FOR_CD || LOC.OUTLET_CD, --Added By Mahima on 19-JUN-2018 against Critical Customer
               CI.CUST_NAME, --Added By Mahima on 19-JUN-2018 against Critical Customer
               RO.REG_NUM, --Added By Mahima on 19-JUN-2018 against Critical Customer
               NVL(LOC.TSMS_ID, LOC.TSMN_ID), --Added By Mahima on 19-JUN-2018 against Critical Customer
               SUBSTR(LOC.DEALER_NAME, 1, 12) DEALER_NAME,
               NVL(SF_GET_CAR_USER_PHONE(RO.VIN, CI.CUST_CD), --added by bhawana against dmsserv-13188
                   DECODE(SUBSTR(CI.MOBILE_PHONE, 1, 1),
                          '0',
                          SUBSTR(CI.MOBILE_PHONE, 2),
                          CI.MOBILE_PHONE)),
               LENGTH(DECODE(SUBSTR(CI.MOBILE_PHONE, 1, 1),
                             '0',
                             SUBSTR(CI.MOBILE_PHONE, 2),
                             CI.MOBILE_PHONE))
          , RO.RCATEG_CD               -- added by mukesh SCP2425095183366
          INTO LV_RO_NUM,
               LV_RO_DATE,
               LV_ETD,
               LV_ETD_AMT,
               --Added By Mahima on 19-JUN-2018 against Critical Customer
               LV_VIN,
               LV_DEALER_CD,
               LV_CUST_NAME1,
               LV_REG_NUM,
               LV_TSM_ID,
               ----------------------------------------------------------
               LV_DEALER_NAME,
               LV_MOBILE1,
               LV_MOBILE_LENGTH,
               LV_RCATEG_CD                               -- added by mukesh SCP2425095183366
          FROM VH_RO RO, GM_CIN CI, AM_DEALER_LOC LOC
         WHERE RO.CUST_CD = CI.CUST_CD
           AND RO.PARENT_GROUP = P_PARENT_GROUP
           AND RO.DEALER_MAP_CD = P_DEALER
           AND RO.LOC_CD = P_LOC_CD
           AND RO.COMP_FA = P_COMP_FA
           AND RO.RO_NUM = P_DOCUMENT_NUM
           AND CI.PRINCIPAL_MAP_CD = LOC.PRINCIPAL_MAP_CD --added by akanksha for multicompany change
           AND RO.PARENT_GROUP = LOC.PARENT_GROUP
           AND RO.DEALER_MAP_CD = LOC.DEALER_MAP_CD
           AND RO.LOC_CD = LOC.LOC_CD
           AND RO.RCATEG_CD NOT IN ('BDW', 'TRN', 'REF')
           AND NVL(RO.PICKUP_TYPE, 'X') <> 'MMS'
           ; ---ADDED BY SHANKAR 02-04-2018

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          LV_ERROR_CD := 1;
        WHEN OTHERS THEN
          LV_RO_NUM        := NULL;
          LV_MOBILE1       := NULL;
          LV_RO_DATE       := NULL;
          LV_DEALER_NAME   := NULL;
          LV_MOBILE_LENGTH := 0;
          LV_ETD           := NULL;
          LV_ETD_AMT       := 0;
      END;

      IF NVL(LV_ERROR_CD, 0) != 1 THEN
        SELECT REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LV_TEXT_FORMAT,
                                                       '<Joc cardno.>',
                                                       LV_RO_NUM),
                                               '<open date>',
                                               LV_RO_DATE),
                                       '<prom date>',
                                       LV_ETD),
                               '<amount>',
                               LV_ETD_AMT),
                       '<dealer_name>',
                       LV_DEALER_NAME),
                       '<APP_URL>',
                       LV_APP_URL) --Added by Surabhi on 17/7/2025

          INTO LV_MESSAGE
          FROM DUAL;

        --Added By Mahima on 19-JUN-2018 against Critical Customer
        BEGIN
          SELECT jdpower
            INTO LV_CUST_CATEGORY
            FROM gm_vin
           WHERE vin = LV_VIN;
        EXCEPTION
          WHEN OTHERS THEN
            LV_CUST_CATEGORY := NULL;
        END;

        IF LV_CUST_CATEGORY = 'A+' THEN
          BEGIN
            SELECT PRM.TEXT_FORMAT
              INTO LV_TEXT_CRITICAL_CUST
              FROM GM_PROCESS_MASTER PRM
             WHERE PRM.PROCESS_CODE = 'JC_CRITICAL_CUS'
               AND PRM.PRINCIPAL_MAP_CD = 1
               AND PRM.ACTIVE_FLAG = 'Y';
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              LV_TEXT_CRITICAL_CUST := NULL;
            WHEN OTHERS THEN
              LV_TEXT_CRITICAL_CUST := NULL;
          END;

          SELECT REPLACE(REPLACE(REPLACE(REPLACE(LV_TEXT_CRITICAL_CUST,
                                                 '<dealer_cd>',
                                                 LV_DEALER_CD),
                                         '<cust_name>',
                                         LV_CUST_NAME1),
                                 '<reg_num>',
                                 LV_REG_NUM),
                         '<dealer_name>',
                         LV_DEALER_NAME)
            INTO LV_MSG
            FROM DUAL;

          BEGIN
            IF LV_TSM_ID IS NOT NULL THEN

              BEGIN
                SELECT mobile
                  INTO LV_MOBILE2
                  FROM vm_email_dtl
                 WHERE staff_id = LV_TSM_ID
                   AND mobile IS NOT NULL
                   AND rownum = 1;
              EXCEPTION
                WHEN OTHERS THEN
                  LV_MOBILE2 := NULL;
              END;
            END IF;
            ---- added by navneet

            begin
              SELECT sf_get_model_channel(LOC.PRINCIPAL_MAP_CD, VIN),
                     LOC.REGION_CD
                INTO LV_MODEL_CHANNEL, LV_REGION
                FROM VH_RO RO, GM_CIN CI, AM_DEALER_LOC LOC
               WHERE RO.CUST_CD = CI.CUST_CD
                 AND RO.PARENT_GROUP = P_PARENT_GROUP
                 AND RO.DEALER_MAP_CD = P_DEALER
                 AND RO.LOC_CD = P_LOC_CD
                 AND RO.COMP_FA = P_COMP_FA
                 AND RO.RO_NUM = P_DOCUMENT_NUM
                 AND CI.PRINCIPAL_MAP_CD = LOC.PRINCIPAL_MAP_CD
                 AND RO.PARENT_GROUP = LOC.PARENT_GROUP
                 AND RO.DEALER_MAP_CD = LOC.DEALER_MAP_CD
                 AND RO.LOC_CD = LOC.LOC_CD
                 AND RO.RCATEG_CD NOT IN ('BDW', 'TRN', 'REF')
                 AND NVL(RO.PICKUP_TYPE, 'X') <> 'MMS';
            EXCEPTION
              WHEN OTHERS THEN
                NULL;
            END;

            BEGIN
              SELECT mobile
                INTO lv_rsm_mobile
                FROM VM_EMAIL_DTL
               WHERE ROLE = 'RSM'
                 AND ACTIVE_YN = 'Y'
                 AND CHANNEL = DECODE(LV_MODEL_CHANNEL,
                                      'EXC',
                                      'EXC',
                                      'NRE',
                                      'EXC',
                                      'NRM')
                 AND REGION = LV_REGION
                 AND ROWNUM = 1;
            EXCEPTION
              WHEN OTHERS THEN
                lv_rsm_mobile := NULL;
            END;

            BEGIN
              SELECT mobile
                INTO lv_zsh_mobile
                FROM VM_EMAIL_DTL
               WHERE ROLE = 'ZSH'
                 AND ACTIVE_YN = 'Y'
                 AND CHANNEL = DECODE(LV_MODEL_CHANNEL,
                                      'EXC',
                                      'EXC',
                                      'NRE',
                                      'EXC',
                                      'NRM')
                 AND REGION = SUBSTR(LV_REGION, 1, 1)
                 AND ROWNUM = 1;
            EXCEPTION
              WHEN OTHERS THEN
                lv_zsh_mobile := NULL;
            END;

            INSERT INTO GM_SMS_STATUS
              (UNIQUE_NUMBER,
               PARENT_GROUP,
               DEALER_MAP_CD,
               LOC_CD,
               PROCESS_CODE,
               DOCUMENT_TYPE,
               DOCUMENT_NO,
               SMS_TYPE,
               MOBILE_NO,
               SMS_CONTENT,
               CREATED_DATE,
               CREATED_BY,
               STATUS,
               SENT_DATE,
               REMARKS,
               SRL_NO)
            VALUES
              (DMS_SMS_UNIQUE_NO.NEXTVAL,
               P_PARENT_GROUP,
               P_DEALER,
               P_LOC_CD,
               'JC_CRITICAL_CUS',
               P_DOC_TYPE,
               P_DOCUMENT_NUM,
               'T',
               '91' || lv_rsm_mobile,
               LV_MSG,
               SYSDATE,
               P_CREATED_BY,
               1,
               NULL,
               NULL,
               1);

            INSERT INTO GM_SMS_STATUS
              (UNIQUE_NUMBER,
               PARENT_GROUP,
               DEALER_MAP_CD,
               LOC_CD,
               PROCESS_CODE,
               DOCUMENT_TYPE,
               DOCUMENT_NO,
               SMS_TYPE,
               MOBILE_NO,
               SMS_CONTENT,
               CREATED_DATE,
               CREATED_BY,
               STATUS,
               SENT_DATE,
               REMARKS,
               SRL_NO)
            VALUES
              (DMS_SMS_UNIQUE_NO.NEXTVAL,
               P_PARENT_GROUP,
               P_DEALER,
               P_LOC_CD,
               'JC_CRITICAL_CUS',
               P_DOC_TYPE,
               P_DOCUMENT_NUM,
               'T',
               '91' || lv_zsh_mobile,
               LV_MSG,
               SYSDATE,
               P_CREATED_BY,
               1,
               NULL,
               NULL,
               2);

            --- end by navneet

            INSERT INTO GM_SMS_STATUS
              (UNIQUE_NUMBER,
               PARENT_GROUP,
               DEALER_MAP_CD,
               LOC_CD,
               PROCESS_CODE,
               DOCUMENT_TYPE,
               DOCUMENT_NO,
               SMS_TYPE,
               MOBILE_NO,
               SMS_CONTENT,
               CREATED_DATE,
               CREATED_BY,
               STATUS,
               SENT_DATE,
               REMARKS,
               SRL_NO)
            VALUES
              (DMS_SMS_UNIQUE_NO.NEXTVAL,
               P_PARENT_GROUP,
               P_DEALER,
               P_LOC_CD,
               'JC_CRITICAL_CUS',
               P_DOC_TYPE,
               P_DOCUMENT_NUM,
               'T',
               '91' || LV_MOBILE2,
               LV_MSG,
               SYSDATE,
               P_CREATED_BY,
               1,
               NULL,
               NULL,
               3);
          END;

          ---- added by navneet

          BEGIN
            BEGIN
              SELECT RO.RO_NUM,
                     SUBSTR(LOC.DEALER_NAME, 1, 20) DEALER_NAME,
                     NVL(SF_GET_CAR_USER_PHONE(RO.VIN, CI.CUST_CD), --added by bhawana against dmsserv-13188
                         DECODE(SUBSTR(CI.MOBILE_PHONE, 1, 1),
                                '0',
                                SUBSTR(CI.MOBILE_PHONE, 2),
                                CI.MOBILE_PHONE)),
                     LENGTH(DECODE(SUBSTR(CI.MOBILE_PHONE, 1, 1),
                                   '0',
                                   SUBSTR(CI.MOBILE_PHONE, 2),
                                   CI.MOBILE_PHONE)),
                     -----------added by bhawana against dmsserv-13310 on 15-jul-2016--------
                     (SELECT EM.MOBILE
                        FROM GM_EMP EM
                       WHERE EM.DEALER_MAP_CD = RO.DEALER_MAP_CD
                         AND EM.EMP_CD = RO.SVC_EMP_CODE),
                     (SELECT EM.MOBILE
                        FROM GM_EMP EM
                       WHERE EM.DEALER_MAP_CD = RO.DEALER_MAP_CD
                         AND EM.LOC_CD = RO.LOC_CD
                         AND EM.EMP_DESG_CD = 'WM'
                         AND MOBILE IS NOT NULL
                            -- And em.emp_leaving_Date is null--v_1
                         AND NVL(EM.EMP_LEAVING_DATE, SYSDATE + 1) >=
                             SYSDATE --v_1
                         AND EM.EMP_APPROVE = 'A'
                         AND EM.CREATED_DATE =
                             (SELECT MAX(CREATED_DATE)
                                FROM GM_EMP EP
                               WHERE EP.DEALER_MAP_CD = RO.DEALER_MAP_CD
                                 AND EP.LOC_CD = RO.LOC_CD
                                 AND EP.EMP_DESG_CD = 'WM'
                                    -- And ep.emp_leaving_Date is null--v_1
                                 AND NVL(EP.EMP_LEAVING_DATE, SYSDATE + 1) >=
                                     SYSDATE --v_1
                                 AND EP.EMP_APPROVE = 'A'
                                 AND EP.MOBILE IS NOT NULL)),
                     (SELECT EM.MOBILE
                        FROM GM_EMP EM
                       WHERE EM.DEALER_MAP_CD = RO.DEALER_MAP_CD
                         AND EM.LOC_CD = RO.LOC_CD
                         AND EM.EMP_DESG_CD = 'CCM'
                         AND MOBILE IS NOT NULL
                            -- And em.emp_leaving_Date is null--v_1
                         AND NVL(EM.EMP_LEAVING_DATE, SYSDATE + 1) >=
                             SYSDATE --v_1
                         AND EM.EMP_APPROVE = 'A'
                         AND EM.CREATED_DATE =
                             (SELECT MAX(CREATED_DATE)
                                FROM GM_EMP EP
                               WHERE EP.DEALER_MAP_CD = RO.DEALER_MAP_CD
                                 AND EP.LOC_CD = RO.LOC_CD
                                 AND EP.EMP_DESG_CD = 'CCM'
                                    -- And ep.emp_leaving_Date is null--v_1
                                 AND NVL(EP.EMP_LEAVING_DATE, SYSDATE + 1) >=
                                     SYSDATE --v_1
                                 AND EP.EMP_APPROVE = 'A'
                                 AND EP.MOBILE IS NOT NULL)),
                     --'Territory Service Manager' modified with new text(MSIL Reg. Off. Contact No) on 08/sep/2016 By Arun
                     (SELECT 'Maruti Suzuki Regional Office Contact Number' || '-' || ' ' ||
                             ---(SELECT 'MSIL Reg. Off. Contact No.' || '-' || ' ' ||                --BLOCKED BY AMAN ON 01-09-2018
                              COMPLAIN_PHONE --mobile--Commented by arun on 30/aug/2016
                        FROM VM_EMAIL_DTL
                       WHERE STAFF_ID = LOC.TSMS_ID
                         AND ROLE = 'TSM'
                         AND ROWNUM = 1),
                     (SELECT 'Maruti Suzuki Regional Office Contact Number' || '-' || ' ' ||
                             ---(SELECT 'MSIL Reg. Off. Contact No.' || '-' || ' ' ||                --BLOCKED BY AMAN ON 01-09-2018
                              COMPLAIN_PHONE --mobile--Commented by arun on 30/aug/2016
                        FROM VM_EMAIL_DTL
                       WHERE STAFF_ID = LOC.TSMN_ID
                         AND ROLE = 'TSM'
                         AND ROWNUM = 1),
                     VIN,
                     (SELECT EM.MOBILE
                        FROM GM_EMP EM
                       WHERE EM.DEALER_MAP_CD = RO.DEALER_MAP_CD
                         AND EM.LOC_CD = RO.LOC_CD
                         AND EM.EMP_DESG_CD = 'QM'
                         AND MOBILE IS NOT NULL
                         AND NVL(EM.EMP_LEAVING_DATE, SYSDATE + 1) >=
                             SYSDATE
                         AND EM.EMP_APPROVE = 'A'
                         AND EM.CREATED_DATE =
                             (SELECT MAX(CREATED_DATE)
                                FROM GM_EMP EP
                               WHERE EP.DEALER_MAP_CD = RO.DEALER_MAP_CD
                                 AND EP.LOC_CD = RO.LOC_CD
                                 AND EP.EMP_DESG_CD = 'QM'
                                 AND NVL(EP.EMP_LEAVING_DATE, SYSDATE + 1) >=
                                     SYSDATE
                                 AND EP.EMP_APPROVE = 'A'
                                 AND EP.MOBILE IS NOT NULL)), --V_2
                     sf_get_model_channel(LOC.PRINCIPAL_MAP_CD, VIN),
                     LOC.REGION_CD
                INTO LV_RO_NUM,
                     LV_DEALER_NAME,
                     LV_MOBILE1,
                     LV_MOBILE_LENGTH,
                     LV_RO_SMOB4, --Sa
                     LV_RO_SMOB1, --wm
                     LV_RO_SMOB2, --CCM
                     LV_RO_SMOBA3, --TSMS
                     LV_RO_SMOBN3, --TSMN
                     LV_VIN,
                     LV_QM_MOB, ---QM--V_2
                     LV_MODEL_CHANNEL,
                     LV_REGION
                FROM VH_RO RO, GM_CIN CI, AM_DEALER_LOC LOC
               WHERE RO.CUST_CD = CI.CUST_CD
                 AND RO.PARENT_GROUP = P_PARENT_GROUP
                 AND RO.DEALER_MAP_CD = P_DEALER
                 AND RO.LOC_CD = P_LOC_CD
                 AND RO.COMP_FA = P_COMP_FA
                 AND RO.RO_NUM = P_DOCUMENT_NUM
                 AND CI.PRINCIPAL_MAP_CD = LOC.PRINCIPAL_MAP_CD -- added by akanksha for multicompany change
                 AND RO.PARENT_GROUP = LOC.PARENT_GROUP
                 AND RO.DEALER_MAP_CD = LOC.DEALER_MAP_CD
                 AND RO.LOC_CD = LOC.LOC_CD
                 AND RO.RCATEG_CD NOT IN ('BDW', 'TRN', 'REF')
                 AND NVL(RO.PICKUP_TYPE, 'X') <> 'MMS'; ---ADDED BY SHANKAR 02-04-2018

            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                LV_ERROR_CD := 1;
              WHEN OTHERS THEN
                DBMS_OUTPUT.PUT_LINE(SQLCODE || SQLERRM);
                LV_RO_NUM        := NULL;
                LV_MOBILE1       := NULL;
                LV_DEALER_NAME   := NULL;
                LV_MOBILE_LENGTH := 0;
                LV_RO_SMOB       := NULL;
                LV_RO_SMOB1      := NULL;
                LV_RO_SMOB2      := NULL;
                LV_RO_SMOB3      := NULL;
                LV_MODEL_CHANNEL := NULL;
                LV_REGION        := NULL;
            END;
            BEGIN
              SELECT EMAIL_ID
                INTO lv_rsm_email
                FROM VM_EMAIL_DTL
               WHERE ROLE = 'RSM'
                 AND ACTIVE_YN = 'Y'
                 AND CHANNEL = DECODE(LV_MODEL_CHANNEL,
                                      'EXC',
                                      'EXC',
                                      'NRE',
                                      'EXC',
                                      'NRM')
                 AND REGION = LV_REGION
                 AND ROWNUM = 1;
            EXCEPTION
              WHEN OTHERS THEN
                lv_rsm_email := NULL;
            END;
            lv_rsm_email8 := substr(lv_rsm_email,1,30);--Added by chandan ason 18-4-24
            lv_rsm_email9 := substr(lv_rsm_email,31,30);--Added by chandan ason 18-4-24

            BEGIN
              SELECT EMAIL_ID
                INTO lv_zsh_email
                FROM VM_EMAIL_DTL
               WHERE ROLE = 'ZSH'
                 AND ACTIVE_YN = 'Y'
                 AND CHANNEL = DECODE(LV_MODEL_CHANNEL,
                                      'EXC',
                                      'EXC',
                                      'NRE',
                                      'EXC',
                                      'NRM')
                 AND REGION = SUBSTR(LV_REGION, 1, 1)
                 AND ROWNUM = 1;
            EXCEPTION
              WHEN OTHERS THEN
                lv_zsh_email := NULL;
            END;
            SELECT (CASE
                     WHEN LV_MODEL_CHANNEL IN ('EXC', 'NRE') THEN
                      LV_RO_SMOBN3
                     ELSE
                      LV_RO_SMOBA3
                   END)
              INTO LV_RO_SMOB3
              FROM DUAL;
            IF NVL(LV_ERROR_CD, 0) != 1 THEN
              BEGIN
                SELECT LIST_DESC
                  INTO LV_MSIL_NO
                  FROM AM_LIST L
                 WHERE L.PRINCIPAL_MAP_CD = 1
                   AND L.LIST_NAME = 'JC_BILLING_NO'
                   AND L.LIST_CODE = SF_GET_NEXA_VIN(1, LV_VIN); /*Modified by Mahima on 18.05.2017 */
              EXCEPTION
                WHEN OTHERS THEN
                  NULL;
              END;

              begin
                select text_format
                  into LV_TEXT_FORMAT_new
                  from gm_process_master
                 where process_code = 'JC_BILLING_CUS'
                   and ACTIVE_flag = 'Y';
              EXCEPTION
                WHEN OTHERS THEN
                  NULL;
              END;

              SELECT SUBSTR(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LV_TEXT_FORMAT_new,
                                                                                                    '<dealer_name>',
                                                                                                    LV_DEALER_NAME),
                                                                                            '<smob4>',
                                                                                            LV_RO_SMOB4),
                                                                                    '<smob1>',
                                                                                    LV_RO_SMOB1),
                                                                            '<smob2>',
                                                                            LV_RO_SMOB2),
                                                                    '<smob3>',
                                                                    LV_RO_SMOB3),
                                                            '<lv_msil_no>',
                                                            LV_MSIL_NO),
                                                    '<qm_mob>',
                                                    LV_QM_MOB),
                                            '<Email_id1>',
                                            LV_RSM_EMAIL),
                                            '<Email_id18>',---Added by chandan ason 18-04-24
                                            LV_RSM_EMAIL8),---Added by chandan ason 18-04-24
                                            '<Email_id19>',---Added by chandan ason 18-04-24
                                            LV_RSM_EMAIL9),---Added by chandan ason 18-04-24
                                    '<Email_id2>',
                                    LV_ZSH_EMAIL),
                            1,
                            1000)---substring size increases from 500 chandan ason 01-5-24

                INTO LV_MESSAGE_new
                FROM DUAL;
              DBMS_OUTPUT.PUT_LINE(LV_MESSAGE);
              SELECT FNC_VERIF_MOBILE(LV_MOBILE1)
                INTO LV_VALID_MOBILE
                FROM DUAL; --CHANGES DONE BY BHAWANA AGAINST DMSSERV-13188 ON8-APR-2015

              IF LV_RO_NUM IS NOT NULL AND LV_MOBILE1 IS NOT NULL AND
                 LV_MOBILE_LENGTH = 10 AND LV_DEALER_NAME IS NOT NULL AND
                 LV_VALID_MOBILE = 1 THEN
                INSERT INTO GM_SMS_STATUS
                  (UNIQUE_NUMBER,
                   PARENT_GROUP,
                   DEALER_MAP_CD,
                   LOC_CD,
                   PROCESS_CODE,
                   DOCUMENT_TYPE,
                   DOCUMENT_NO,
                   SMS_TYPE,
                   MOBILE_NO,
                   SMS_CONTENT,
                   CREATED_DATE,
                   CREATED_BY,
                   STATUS,
                   SENT_DATE,
                   REMARKS,
                   SRL_NO)
                VALUES
                  (DMS_SMS_UNIQUE_NO.NEXTVAL,
                   P_PARENT_GROUP,
                   P_DEALER,
                   P_LOC_CD,
                   'JC_BILLING_CUS',
                   P_DOC_TYPE,
                   P_DOCUMENT_NUM,
                   'T',
                   '91' || LV_MOBILE1,
                   LV_MESSAGE_new,
                   SYSDATE,
                   P_CREATED_BY,
                   1,
                   NULL,
                   NULL,
                   4);
              ELSE
                INSERT INTO GM_SMS_STATUS
                  (UNIQUE_NUMBER,
                   PARENT_GROUP,
                   DEALER_MAP_CD,
                   LOC_CD,
                   PROCESS_CODE,
                   DOCUMENT_TYPE,
                   DOCUMENT_NO,
                   SMS_TYPE,
                   MOBILE_NO,
                   SMS_CONTENT,
                   CREATED_DATE,
                   CREATED_BY,
                   STATUS,
                   SENT_DATE,
                   REMARKS,
                   SRL_NO)
                VALUES
                  (DMS_SMS_UNIQUE_NO.NEXTVAL,
                   P_PARENT_GROUP,
                   P_DEALER,
                   P_LOC_CD,
                   'JC_BILLING_CUS',
                   P_DOC_TYPE,
                   P_DOCUMENT_NUM,
                   'T',
                   LV_MOBILE1,
                   LV_MESSAGE_new,
                   SYSDATE,
                   P_CREATED_BY,
                   8,
                   NULL,
                   'DATA NOT CORRECT',
                   5);

              END IF;
            END IF;
          EXCEPTION
            WHEN OTHERS THEN
              --DBMS_OUTPUT.PUT_LINE(SQLERRM);
              NULL;
          END;
          COMMIT;
          ---- end by navneet

        END IF;

        SELECT FNC_VERIF_MOBILE(LV_MOBILE1) INTO LV_VALID_MOBILE FROM DUAL; --CHANGES DONE BY BHAWANA AGAINST DMSSERV-13188 ON8-APR-2015

        IF LV_RO_NUM IS NOT NULL AND LV_MOBILE1 IS NOT NULL AND
           LV_MOBILE_LENGTH = 10 AND LV_RO_DATE IS NOT NULL AND
           LV_DEALER_NAME IS NOT NULL AND LV_ETD IS NOT NULL AND
           LV_ETD_AMT IS NOT NULL
          ---and LV_MOBILE1=1 THEN        /*Comment By Amit on 21-Jul-2015 for SMS are not sent */
           AND LV_VALID_MOBILE = 1 THEN

          ---------------added by shankar 02-11-2017 DMSSERV-13411 FOR NEXA ----------------
          BEGIN
            SELECT X.WAITING_YN
              INTO LV_WATING_YN
              FROM VH_RO X
             WHERE PARENT_GROUP = P_PARENT_GROUP
               AND DEALER_MAP_CD = P_DEALER
               AND LOC_CD = P_LOC_CD
               AND COMP_FA = P_COMP_FA
               AND RO_NUM = P_DOCUMENT_NUM;
          EXCEPTION
            WHEN OTHERS THEN
              LV_WATING_YN := 'N';
          END;

          IF LV_WATING_YN = 'Y' THEN
            BEGIN
              SELECT PRM.TEXT_FORMAT
                INTO LV_TEXT_WAITING_CUST
                FROM GM_PROCESS_MASTER PRM
               WHERE PRM.PROCESS_CODE = 'JC_WAITING_CUST'
                 AND PRM.PRINCIPAL_MAP_CD = 1
                 AND PRM.ACTIVE_FLAG = 'Y';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                LV_TEXT_WAITING_CUST := NULL;
              WHEN OTHERS THEN
                LV_TEXT_WAITING_CUST := NULL;
            END;
            INSERT INTO GM_SMS_STATUS
              (UNIQUE_NUMBER,
               PARENT_GROUP,
               DEALER_MAP_CD,
               LOC_CD,
               PROCESS_CODE,
               DOCUMENT_TYPE,
               DOCUMENT_NO,
               SMS_TYPE,
               MOBILE_NO,
               SMS_CONTENT,
               CREATED_DATE,
               CREATED_BY,
               STATUS,
               SENT_DATE,
               REMARKS,
               SRL_NO)
            VALUES
              (DMS_SMS_UNIQUE_NO.NEXTVAL,
               P_PARENT_GROUP,
               P_DEALER,
               P_LOC_CD,
               'JC_WAITING_CUST',
               P_DOC_TYPE,
               P_DOCUMENT_NUM,
               'T',
               '91' || LV_MOBILE1,
               LV_TEXT_WAITING_CUST,
               SYSDATE,
               P_CREATED_BY,
               1,
               NULL,
               NULL,
               1);
          END IF;
          -----------------------------
          -------added by shankar 21-08-2017 DMSSERV-13396

          BEGIN
            SELECT REPLACE(DBMS_LOB.SUBSTR(WM_CONCAT(AL.LIST_DESC)),
                           ',',
                           '%20')
              INTO LV_UNFT
              FROM VD_RO_UNAPPR_FITMENT FT, AM_LIST_RANGE AL
             WHERE FT.PARENT_GROUP = P_PARENT_GROUP
               AND FT.DEALER_MAP_CD = P_DEALER
               AND FT.LOC_CD = P_LOC_CD
               AND FT.COMP_FA = P_COMP_FA
               AND FT.RO_NUM = P_DOCUMENT_NUM
               AND LIST_NAME = 'UNAPPROVED_FITMENTS'
               AND LIST_CODE = FITMENT_CD
               AND PRINCIPAL_MAP_CD = 1;

          EXCEPTION
            WHEN OTHERS THEN
              LV_UNFT := NULL;
          END;
          IF LV_UNFT IS NOT NULL THEN
            BEGIN
              SELECT PRM.TEXT_FORMAT
                INTO LV_TEXT_FORMAT_UNFT
                FROM GM_PROCESS_MASTER PRM
               WHERE PRM.PROCESS_CODE = 'JC_UNAPPROVE_FT'
                 AND PRM.PRINCIPAL_MAP_CD = 1
                 AND PRM.ACTIVE_FLAG = 'Y';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                LV_TEXT_FORMAT_UNFT := NULL;
              WHEN OTHERS THEN
                LV_TEXT_FORMAT_UNFT := NULL;
            END;
            LV_UNFT1:=substr(LV_UNFT,1,30);--Added by chandan ason 11-4-24
            LV_UNFT2:=substr(LV_UNFT,31,30);--Added by chandan ason 11-4-24

            INSERT INTO GM_SMS_STATUS
              (UNIQUE_NUMBER,
               PARENT_GROUP,
               DEALER_MAP_CD,
               LOC_CD,
               PROCESS_CODE,
               DOCUMENT_TYPE,
               DOCUMENT_NO,
               SMS_TYPE,
               MOBILE_NO,
               SMS_CONTENT,
               CREATED_DATE,
               CREATED_BY,
               STATUS,
               SENT_DATE,
               REMARKS,
               SRL_NO)
            VALUES
              (DMS_SMS_UNIQUE_NO.NEXTVAL,
               P_PARENT_GROUP,
               P_DEALER,
               P_LOC_CD,
               'JC_UNAPPROVE_FT',
               P_DOC_TYPE,
               P_DOCUMENT_NUM,
               'T',
               '91' || LV_MOBILE1,
               REPLACE(REPLACE(REPLACE(LV_TEXT_FORMAT_UNFT, '<unapporve_fit>', LV_UNFT),
                                          '<unapporve_fit1>', LV_UNFT1),----Added by Chandan ason 11-4-24
                                        '<unapporve_fit2>', LV_UNFT2),  ----Added by Chandan ason 11-4-24
               SYSDATE,
               P_CREATED_BY,
               1,
               NULL,
               NULL,
               1);

            /*  ELSE
            INSERT INTO GM_SMS_STATUS
              (UNIQUE_NUMBER,
               PARENT_GROUP,
               DEALER_MAP_CD,
               LOC_CD,
               PROCESS_CODE,
               DOCUMENT_TYPE,
               DOCUMENT_NO,
               SMS_TYPE,
               MOBILE_NO,
               SMS_CONTENT,
               CREATED_DATE,
               CREATED_BY,
               STATUS,
               SENT_DATE,
               REMARKS,
               SRL_NO)
            VALUES
              (DMS_SMS_UNIQUE_NO.NEXTVAL,
               P_PARENT_GROUP,
               P_DEALER,
               P_LOC_CD,
               'JC_UNAPPROVE_FT',
               P_DOC_TYPE,
               P_DOCUMENT_NUM,
               'T',
               LV_MOBILE1,
               REPLACE(LV_TEXT_FORMAT_UNFT,'<unapporve_fit>',lv_unft),
               SYSDATE,
               P_CREATED_BY,
               8,
               NULL,
               'DATA NOT CORRECT',
               1);*/
          END IF;

          /*Added By Amit on 21-Jul-2015 for SMS are not sent */
          BEGIN
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             '91' || LV_MOBILE1,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             1,
             NULL,
             NULL,
             1);
          EXCEPTION WHEN OTHERS THEN
              DBMS_OUTPUT.PUT_LINE('ERROR :: '||SQLERRM);
          END;

          -- Added by Rajeev on 16-JUN-2025 for CDS service type
          IF LV_RCATEG_CD='CDS' then
            BEGIN
              SELECT GM.TEXT_FORMAT INTO lv_cvms_msg
                FROM GM_PROCESS_MASTER GM
               WHERE GM.PRINCIPAL_MAP_CD = 1
                 AND GM.PROCESS_CODE = 'SRV_JC_OPEN'
                 AND GM.ACTIVE_FLAG = 'Y';
            EXCEPTION WHEN OTHERS THEN
                 lv_cvms_msg:=NULL;
            END;

            IF LV_CVMS_MSG IS NOT NULL THEN
              BEGIN
                SELECT INITCAP(list_desc) INTO lv_srv_desc
                   FROM am_list
                  where principal_map_cd = 1
                  and list_code = LV_RCATEG_CD
                  and list_name = 'RCATEG_CD';
              EXCEPTION WHEN OTHERS THEN
                lv_srv_desc := NULL;
              END;

                SELECT REPLACE(lv_cvms_msg,
                               '<srv_type>',
                               lv_srv_desc)
                  INTO lv_cvms_msg
                  FROM DUAL;
            --    DBMS_OUTPUT.PUT_LINE('STEP 1 :: '||lv_cvms_msg);

              BEGIN
               INSERT INTO GM_SMS_STATUS
                        (UNIQUE_NUMBER,
                         PARENT_GROUP,
                         DEALER_MAP_CD,
                         LOC_CD,
                         PROCESS_CODE,
                         DOCUMENT_TYPE,
                         DOCUMENT_NO,
                         SMS_TYPE,
                         MOBILE_NO,
                         SMS_CONTENT,
                         CREATED_DATE,
                         CREATED_BY,
                         STATUS,
                         SENT_DATE,
                         REMARKS,
                         SRL_NO)
                 VALUES
                        (DMS_SMS_UNIQUE_NO.NEXTVAL,
                         P_PARENT_GROUP,
                         P_DEALER,
                         P_LOC_CD,
                         'SRV_JC_OPEN',
                         P_DOC_TYPE,
                         P_DOCUMENT_NUM,
                         'T',
                         '91' || LV_MOBILE1,
                         LV_CVMS_MSG,
                         SYSDATE,
                         P_CREATED_BY,
                         1,
                         NULL,
                         NULL,
                         1);
              EXCEPTION WHEN OTHERS THEN
                DBMS_OUTPUT.PUT_LINE('ERROR :: '||SQLERRM);
              END;
            END IF;

          END IF;
          -- Added by Rajeev on 16-JUN-2025 for CDS service type

         ---                          -- added by mukesh SCP2425095183366
          if LV_RCATEG_CD='CVMS' then
            begin
                  SELECT GM.TEXT_FORMAT into LV_CVMS_MSG
                  FROM GM_PROCESS_MASTER GM
                WHERE GM.PRINCIPAL_MAP_CD = 1
                   AND GM.PROCESS_CODE = 'CVMS_JC_OPEN'
                   AND GM.ACTIVE_FLAG = 'Y';
             exception
               when others then
                 LV_CVMS_MSG:=null;
             end;

             if LV_CVMS_MSG is not null then

             INSERT INTO GM_SMS_STATUS
              (UNIQUE_NUMBER,
               PARENT_GROUP,
               DEALER_MAP_CD,
               LOC_CD,
               PROCESS_CODE,
               DOCUMENT_TYPE,
               DOCUMENT_NO,
               SMS_TYPE,
               MOBILE_NO,
               SMS_CONTENT,
               CREATED_DATE,
               CREATED_BY,
               STATUS,
               SENT_DATE,
               REMARKS,
               SRL_NO)
            VALUES
              (DMS_SMS_UNIQUE_NO.NEXTVAL,
               P_PARENT_GROUP,
               P_DEALER,
               P_LOC_CD,
               'CVMS_JC_OPEN',
               P_DOC_TYPE,
               P_DOCUMENT_NUM,
               'T',
               '91' || LV_MOBILE1,
               LV_CVMS_MSG,
               SYSDATE,
               P_CREATED_BY,
               1,
               NULL,
               NULL,
               1);
               end if;

          end if;
          ----                                -- end SCP2425095183366

        ELSE
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             LV_MOBILE1,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             8,
             NULL,
             'DATA NOT CORRECT',
             1);

        END IF;

      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
        --- added by navneet
    END;
    COMMIT;
  END IF;

  ---FOR JOBCARD BILLING----

  IF NVL(LV_PROCESS, '@') = 'JC_BILLING' AND LV_TEXT_FORMAT IS NOT NULL THEN

    BEGIN
      BEGIN
        SELECT RO.RO_NUM,
               SUBSTR(LOC.DEALER_NAME, 1, 20) DEALER_NAME,
               NVL(SF_GET_CAR_USER_PHONE(RO.VIN, CI.CUST_CD), --added by bhawana against dmsserv-13188
                   DECODE(SUBSTR(CI.MOBILE_PHONE, 1, 1),
                          '0',
                          SUBSTR(CI.MOBILE_PHONE, 2),
                          CI.MOBILE_PHONE)),
               LENGTH(DECODE(SUBSTR(CI.MOBILE_PHONE, 1, 1),
                             '0',
                             SUBSTR(CI.MOBILE_PHONE, 2),
                             CI.MOBILE_PHONE)),
               -----------added by bhawana against dmsserv-13310 on 15-jul-2016--------
               (SELECT EM.MOBILE
                  FROM GM_EMP EM
                 WHERE EM.DEALER_MAP_CD = RO.DEALER_MAP_CD
                   AND EM.EMP_CD = RO.SVC_EMP_CODE),
               (SELECT EM.MOBILE
                  FROM GM_EMP EM
                 WHERE EM.DEALER_MAP_CD = RO.DEALER_MAP_CD
                   AND EM.LOC_CD = RO.LOC_CD
                   AND EM.EMP_DESG_CD = 'WM'
                   AND MOBILE IS NOT NULL
                      -- And em.emp_leaving_Date is null--v_1
                   AND NVL(EM.EMP_LEAVING_DATE, SYSDATE + 1) >= SYSDATE --v_1
                   AND EM.EMP_APPROVE = 'A'
                   AND EM.CREATED_DATE =
                       (SELECT MAX(CREATED_DATE)
                          FROM GM_EMP EP
                         WHERE EP.DEALER_MAP_CD = RO.DEALER_MAP_CD
                           AND EP.LOC_CD = RO.LOC_CD
                           AND EP.EMP_DESG_CD = 'WM'
                              -- And ep.emp_leaving_Date is null--v_1
                           AND NVL(EP.EMP_LEAVING_DATE, SYSDATE + 1) >=
                               SYSDATE --v_1
                           AND EP.EMP_APPROVE = 'A'
                           AND EP.MOBILE IS NOT NULL)),
               (SELECT EM.MOBILE
                  FROM GM_EMP EM
                 WHERE EM.DEALER_MAP_CD = RO.DEALER_MAP_CD
                   AND EM.LOC_CD = RO.LOC_CD
                   AND EM.EMP_DESG_CD = 'CCM'
                   AND MOBILE IS NOT NULL
                      -- And em.emp_leaving_Date is null--v_1
                   AND NVL(EM.EMP_LEAVING_DATE, SYSDATE + 1) >= SYSDATE --v_1
                   AND EM.EMP_APPROVE = 'A'
                   AND EM.CREATED_DATE =
                       (SELECT MAX(CREATED_DATE)
                          FROM GM_EMP EP
                         WHERE EP.DEALER_MAP_CD = RO.DEALER_MAP_CD
                           AND EP.LOC_CD = RO.LOC_CD
                           AND EP.EMP_DESG_CD = 'CCM'
                              -- And ep.emp_leaving_Date is null--v_1
                           AND NVL(EP.EMP_LEAVING_DATE, SYSDATE + 1) >=
                               SYSDATE --v_1
                           AND EP.EMP_APPROVE = 'A'
                           AND EP.MOBILE IS NOT NULL)),
               --'Territory Service Manager' modified with new text(MSIL Reg. Off. Contact No) on 08/sep/2016 By Arun
               (SELECT 'Maruti Suzuki Regional Office Contact Number' || '-' || ' ' ||
                       ---(SELECT 'MSIL Reg. Off. Contact No.' || '-' || ' ' ||                --BLOCKED BY AMAN ON 01-09-2018
                        COMPLAIN_PHONE --mobile--Commented by arun on 30/aug/2016
                  FROM VM_EMAIL_DTL
                 WHERE STAFF_ID = LOC.TSMS_ID
                   AND ROLE = 'TSM'
                   AND ROWNUM = 1),
               (SELECT 'Maruti Suzuki Regional Office Contact Number' || '-' || ' ' ||
                       ---(SELECT 'MSIL Reg. Off. Contact No.' || '-' || ' ' ||                --BLOCKED BY AMAN ON 01-09-2018
                        COMPLAIN_PHONE --mobile--Commented by arun on 30/aug/2016
                  FROM VM_EMAIL_DTL
                 WHERE STAFF_ID = LOC.TSMN_ID
                   AND ROLE = 'TSM'
                   AND ROWNUM = 1),
               VIN,
               (SELECT EM.MOBILE
                  FROM GM_EMP EM
                 WHERE EM.DEALER_MAP_CD = RO.DEALER_MAP_CD
                   AND EM.LOC_CD = RO.LOC_CD
                   AND EM.EMP_DESG_CD = 'QM'
                   AND MOBILE IS NOT NULL
                   AND NVL(EM.EMP_LEAVING_DATE, SYSDATE + 1) >= SYSDATE
                   AND EM.EMP_APPROVE = 'A'
                   AND EM.CREATED_DATE =
                       (SELECT MAX(CREATED_DATE)
                          FROM GM_EMP EP
                         WHERE EP.DEALER_MAP_CD = RO.DEALER_MAP_CD
                           AND EP.LOC_CD = RO.LOC_CD
                           AND EP.EMP_DESG_CD = 'QM'
                           AND NVL(EP.EMP_LEAVING_DATE, SYSDATE + 1) >=
                               SYSDATE
                           AND EP.EMP_APPROVE = 'A'
                           AND EP.MOBILE IS NOT NULL)), --V_2
               sf_get_model_channel(LOC.PRINCIPAL_MAP_CD, VIN),
               LOC.REGION_CD
          INTO LV_RO_NUM,
               LV_DEALER_NAME,
               LV_MOBILE1,
               LV_MOBILE_LENGTH,
               LV_RO_SMOB4, --Sa
               LV_RO_SMOB1, --wm
               LV_RO_SMOB2, --CCM
               LV_RO_SMOBA3, --TSMS
               LV_RO_SMOBN3, --TSMN
               LV_VIN,
               LV_QM_MOB, ---QM--V_2
               LV_MODEL_CHANNEL,
               LV_REGION
          FROM VH_RO RO, GM_CIN CI, AM_DEALER_LOC LOC
         WHERE RO.CUST_CD = CI.CUST_CD
           AND RO.PARENT_GROUP = P_PARENT_GROUP
           AND RO.DEALER_MAP_CD = P_DEALER
           AND RO.LOC_CD = P_LOC_CD
           AND RO.COMP_FA = P_COMP_FA
           AND RO.RO_NUM = P_DOCUMENT_NUM
           AND CI.PRINCIPAL_MAP_CD = LOC.PRINCIPAL_MAP_CD -- added by akanksha for multicompany change
           AND RO.PARENT_GROUP = LOC.PARENT_GROUP
           AND RO.DEALER_MAP_CD = LOC.DEALER_MAP_CD
           AND RO.LOC_CD = LOC.LOC_CD
           AND RO.RCATEG_CD NOT IN ('BDW', 'TRN', 'REF')
           AND NVL(RO.PICKUP_TYPE, 'X') <> 'MMS'; ---ADDED BY SHANKAR 02-04-2018

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          LV_ERROR_CD := 1;
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SQLCODE || SQLERRM);
          LV_RO_NUM        := NULL;
          LV_MOBILE1       := NULL;
          LV_DEALER_NAME   := NULL;
          LV_MOBILE_LENGTH := 0;
          LV_RO_SMOB       := NULL;
          LV_RO_SMOB1      := NULL;
          LV_RO_SMOB2      := NULL;
          LV_RO_SMOB3      := NULL;
          LV_MODEL_CHANNEL := NULL;
          LV_REGION        := NULL;
      END;
      BEGIN
        SELECT EMAIL_ID
          INTO lv_rsm_email
          FROM VM_EMAIL_DTL
         WHERE ROLE = 'RSM'
           AND ACTIVE_YN = 'Y'
           AND CHANNEL =
               DECODE(LV_MODEL_CHANNEL, 'EXC', 'EXC', 'NRE', 'EXC', 'NRM')
           AND REGION = LV_REGION
           AND ROWNUM = 1;
      EXCEPTION
        WHEN OTHERS THEN
          lv_rsm_email := NULL;
      END;
      LV_RSM_EMAIL8 := SUBSTR(LV_RSM_EMAIL,1,30);---Added by chandan ason 18-4-24
      LV_RSM_EMAIL9 := SUBSTR(LV_RSM_EMAIL,31,30);---Added by chandan ason 18-4-24

      BEGIN
        SELECT EMAIL_ID
          INTO lv_zsh_email
          FROM VM_EMAIL_DTL
         WHERE ROLE = 'ZSH'
           AND ACTIVE_YN = 'Y'
           AND CHANNEL =
               DECODE(LV_MODEL_CHANNEL, 'EXC', 'EXC', 'NRE', 'EXC', 'NRM')
           AND REGION = SUBSTR(LV_REGION, 1, 1)
           AND ROWNUM = 1;
      EXCEPTION
        WHEN OTHERS THEN
          lv_zsh_email := NULL;
      END;
      SELECT (CASE
               WHEN LV_MODEL_CHANNEL IN ('EXC', 'NRE') THEN
                LV_RO_SMOBN3
               ELSE
                LV_RO_SMOBA3
             END)
        INTO LV_RO_SMOB3
        FROM DUAL;
      IF NVL(LV_ERROR_CD, 0) != 1 THEN
        BEGIN
          SELECT LIST_DESC
            INTO LV_MSIL_NO
            FROM AM_LIST L
           WHERE L.PRINCIPAL_MAP_CD = 1
             AND L.LIST_NAME = 'JC_BILLING_NO'
             AND L.LIST_CODE = SF_GET_NEXA_VIN(1, LV_VIN); /*Modified by Mahima on 18.05.2017 */
        EXCEPTION
          WHEN OTHERS THEN
            NULL;
        END;

        SELECT SUBSTR(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LV_TEXT_FORMAT,
                                                                                              '<dealer_name>',
                                                                                              LV_DEALER_NAME),
                                                                                      '<smob4>',
                                                                                      LV_RO_SMOB4),
                                                                              '<smob1>',
                                                                              LV_RO_SMOB1),
                                                                      '<smob2>',
                                                                      LV_RO_SMOB2),
                                                              '<smob3>',
                                                              LV_RO_SMOB3),
                                                      '<lv_msil_no>',
                                                      LV_MSIL_NO),
                                              '<qm_mob>',
                                              LV_QM_MOB),
                                      '<Email_id1>',
                                      LV_RSM_EMAIL),
                                      '<Email_id18>',--added by chandan ason 18-4-24
                                      LV_RSM_EMAIL8),--added by chandan ason 18-4-24
                                      '<Email_id19>',--added by chandan ason 18-4-24
                                      LV_RSM_EMAIL9),--added by chandan ason 18-4-24
                              '<Email_id2>',
                              LV_ZSH_EMAIL),
                      1,
                      1000)---substring size increases from 500 chandan ason 01-5-24

          INTO LV_MESSAGE
          FROM DUAL;
        DBMS_OUTPUT.PUT_LINE(LV_MESSAGE);
        SELECT FNC_VERIF_MOBILE(LV_MOBILE1) INTO LV_VALID_MOBILE FROM DUAL; --CHANGES DONE BY BHAWANA AGAINST DMSSERV-13188 ON8-APR-2015

        IF LV_RO_NUM IS NOT NULL AND LV_MOBILE1 IS NOT NULL AND
           LV_MOBILE_LENGTH = 10 AND LV_DEALER_NAME IS NOT NULL AND
           LV_VALID_MOBILE = 1 THEN
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             '91' || LV_MOBILE1,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             1,
             NULL,
             NULL,
             1);
        ELSE
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             LV_MOBILE1,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             8,
             NULL,
             'DATA NOT CORRECT',
             1);

        END IF;
      END IF;
     ---------Added by mohan as on 13-07-2021 against scr DMSSERV(S)-13359 --------------
            BEGIN
      /*    SELECT  PRM.TEXT_FORMAT
            INTO  LV_TEXT_VOT_BILL
            FROM GM_DLR_SMS_MAPPING SMM, GM_PROCESS_MASTER PRM
           WHERE SMM.PARENT_GROUP = P_PARENT_GROUP
             AND SMM.DEALER_MAP_CD = P_DEALER
             AND SMM.LOC_CD = P_LOC_CD
             AND SMM.PROCESS_CODE = 'VOT_JC_BILL'
             AND TRUNC(SMM.CREATED_DATE) <= TRUNC(SYSDATE)
             AND NVL(SMM.DEACTIVATION_DATE, SYSDATE) >= TRUNC(SYSDATE)
             AND SMM.PROCESS_CODE = PRM.PROCESS_CODE
             AND PRM.PRINCIPAL_MAP_CD = SF_PRINCIPAL_MAP_CD(P_DEALER, P_LOC_CD)
             AND PRM.ACTIVE_FLAG = 'Y';
        */
       --commented and added by Surabhi on 20-Nov-2024 for Jira DS-942
      SELECT  PRM.TEXT_FORMAT
            INTO  LV_TEXT_VOT_BILL
            FROM  GM_PROCESS_MASTER PRM
           WHERE PRM.PROCESS_CODE = 'VOT_JC_BILL'
             AND PRM.PRINCIPAL_MAP_CD = SF_PRINCIPAL_MAP_CD(P_DEALER, P_LOC_CD)
             AND PRM.ACTIVE_FLAG = 'Y';

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            LV_TEXT_VOT_BILL     := NULL;
         WHEN OTHERS THEN
              LV_TEXT_VOT_BILL := NULL;
          end;
        /*END;
           BEGIN
            SELECT PRM.TEXT_FORMAT
              INTO LV_TEXT_VOT_BILL
              FROM GM_PROCESS_MASTER PRM
             WHERE PRM.PROCESS_CODE = 'VOT_JC_BILL'
               AND PRM.PRINCIPAL_MAP_CD = 1
               AND PRM.ACTIVE_FLAG = 'Y';
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              LV_TEXT_VOT_BILL := NULL;
            WHEN OTHERS THEN
              LV_TEXT_VOT_BILL := NULL;
          END;*/

          BEGIN
             SELECT
              (SELECT EM.MOBILE
                FROM GM_EMP EM
                WHERE EM.DEALER_MAP_CD = RO.DEALER_MAP_CD
                AND EM.LOC_CD = RO.LOC_CD
                AND EM.EMP_DESG_CD = 'WM'
                AND MOBILE IS NOT NULL
                AND NVL(EM.EMP_LEAVING_DATE, SYSDATE + 1) >= SYSDATE
                AND EM.EMP_APPROVE = 'A'
                AND EM.CREATED_DATE =
                  (SELECT MAX(CREATED_DATE)
                  FROM GM_EMP EP
                  WHERE EP.DEALER_MAP_CD = RO.DEALER_MAP_CD
                  AND EP.LOC_CD = RO.LOC_CD
                  AND EP.EMP_DESG_CD = 'WM'
                  AND NVL(EP.EMP_LEAVING_DATE, SYSDATE + 1) >=SYSDATE
                  AND EP.EMP_APPROVE = 'A'
                  AND EP.MOBILE IS NOT NULL)),
                  (SELECT EM.FIRST_NAME
                FROM GM_EMP EM
                WHERE EM.DEALER_MAP_CD = RO.DEALER_MAP_CD
                AND EM.LOC_CD = RO.LOC_CD
                AND EM.EMP_DESG_CD = 'WM'
                AND MOBILE IS NOT NULL
                AND NVL(EM.EMP_LEAVING_DATE, SYSDATE + 1) >= SYSDATE
                AND EM.EMP_APPROVE = 'A'
                AND EM.CREATED_DATE =
                  (SELECT MAX(CREATED_DATE)
                  FROM GM_EMP EP
                  WHERE EP.DEALER_MAP_CD = RO.DEALER_MAP_CD
                  AND EP.LOC_CD = RO.LOC_CD
                  AND EP.EMP_DESG_CD = 'WM'
                  AND NVL(EP.EMP_LEAVING_DATE, SYSDATE + 1) >=SYSDATE
                  AND EP.EMP_APPROVE = 'A'
                  AND EP.MOBILE IS NOT NULL)),
                  RO.FIND_ID
          INTO  LV_MOB_VOT_BILL,
                LV_WM_VOT_BILL,
                LV_FIND_ID_BILL
          FROM VH_RO RO, GM_CIN CI, AM_DEALER_LOC LOC
         WHERE RO.PARENT_GROUP = P_PARENT_GROUP
           AND RO.DEALER_MAP_CD = P_DEALER
           AND RO.LOC_CD = P_LOC_CD
           AND RO.COMP_FA = P_COMP_FA
           AND RO.RO_NUM = P_DOCUMENT_NUM
           AND RO.CUST_CD = CI.CUST_CD
           AND ci.principal_map_cd= LOC.PRINCIPAL_MAP_CD
           AND LOC.PARENT_GROUP=RO.PARENT_GROUP
           AND LOC.DEALER_MAP_CD=RO.DEALER_MAP_CD
           AND LOC.LOC_CD=RO.LOC_CD
           AND LOC.PRINCIPAL_MAP_CD=SF_PRINCIPAL_MAP_CD(P_DEALER, P_LOC_CD) ;
           EXCEPTION WHEN OTHERS THEN
             LV_MOB_VOT_BILL :=NULL;
             LV_WM_VOT_BILL :=NULL;
             LV_FIND_ID_BILL :=NULL;
          END;

          SELECT REPLACE(REPLACE(REPLACE(LV_TEXT_VOT_BILL,
                                                 '<WM>',
                                                 LV_WM_VOT_BILL),
                                       '<REG_NUM>',
                                       LV_REG_NUM),
                               '<FIND_ID>',
                               LV_FIND_ID_BILL)
            INTO LV_MSG
            FROM DUAL;

    IF LV_MSG IS NOT NULL AND --added condition by Surabhi on 20-Nov-2024 for Jira DS-942
       LV_MOB_VOT_BILL IS NOT NULL  THEN
       BEGIN
         INSERT INTO GM_SMS_STATUS
              (UNIQUE_NUMBER,
               PARENT_GROUP,
               DEALER_MAP_CD,
               LOC_CD,
               PROCESS_CODE,
               DOCUMENT_TYPE,
               DOCUMENT_NO,
               SMS_TYPE,
               MOBILE_NO,
               SMS_CONTENT,
               CREATED_DATE,
               CREATED_BY,
               STATUS,
               SENT_DATE,
               REMARKS,
               SRL_NO)
            VALUES
              (DMS_SMS_UNIQUE_NO.NEXTVAL,
               P_PARENT_GROUP,
               P_DEALER,
               P_LOC_CD,
               'VOT_JC_BILL',
               P_DOC_TYPE,
               P_DOCUMENT_NUM,
               'T',
               '91' || LV_MOB_VOT_BILL,
               LV_MSG,
               SYSDATE,
               P_CREATED_BY,
               1,
               NULL,
               NULL,
               1);
           EXCEPTION WHEN OTHERS THEN
             NULL;
          END ;
        END IF;
 ---------Added by mohan as on 13-07-2021 against scr DMSSERV(S)-13359 --------------
    EXCEPTION
      WHEN OTHERS THEN
        --DBMS_OUTPUT.PUT_LINE(SQLERRM);
        NULL;
    END;
    COMMIT;
  END IF;
  ---FOR JOBCARD closing-
  IF NVL(LV_PROCESS, '@') = 'JC_CLOSING' AND LV_TEXT_FORMAT IS NOT NULL THEN
    BEGIN
      BEGIN
        SELECT RO.RO_NUM,
               SUBSTR(LOC.DEALER_NAME, 1, 12) DEALER_NAME,
               SUBSTR((SELECT EM.FIRST_NAME
                        FROM GM_EMP EM
                       WHERE RO.SVC_EMP_CODE = EM.EMP_CD
                         AND RO.DEALER_MAP_CD = EM.DEALER_MAP_CD),
                      1,
                      12),
               /*Comment By Amit for DMSSERV-13206*/
               /*(select em.mobile
                from gm_emp em
               where ro.svc_emp_code = em.emp_cd
                 AND RO.DEALER_MAP_CD = EM.DEALER_MAP_CD),*/
               /*Added By Amit for DMSSERV-13206*/
               (SELECT DECODE(SUBSTR(REPLACE(EM.MOBILE, ' ', ','),
                                     1,
                                     INSTR(REPLACE(EM.MOBILE, ' ', ','), ',') - 1),
                              NULL,
                              EM.MOBILE,
                              SUBSTR(REPLACE(EM.MOBILE, ' ', ','),
                                     1,
                                     INSTR(REPLACE(EM.MOBILE, ' ', ','), ',') - 1)) MOBILE
                  FROM GM_EMP EM
                 WHERE RO.SVC_EMP_CODE = EM.EMP_CD
                   AND RO.DEALER_MAP_CD = EM.DEALER_MAP_CD),
               /*Added End By Amit for DMSSERV-13206*/
               NVL(SF_GET_CAR_USER_PHONE(RO.VIN, CI.CUST_CD), --added by bhawana against dmsserv-13188
                   DECODE(SUBSTR(CI.MOBILE_PHONE, 1, 1),
                          '0',
                          SUBSTR(CI.MOBILE_PHONE, 2),
                          CI.MOBILE_PHONE)),

               LENGTH(DECODE(SUBSTR(CI.MOBILE_PHONE, 1, 1),
                             '0',
                             SUBSTR(CI.MOBILE_PHONE, 2),
                             CI.MOBILE_PHONE)),
               RO.RCATEG_CD, /*Added By Amit for DMSSERV-13207*/
               (SELECT NVL(X.VINNO, NULL)
                  FROM TABLET.MC_LOGIN X
                 WHERE X.VINNO = RO.VIN
                   AND X.ISVALIDATED = 'Y') TAB_VIN
          INTO LV_RO_NUM,
               LV_DEALER_NAME,
               LV_RO_SNAME,
               LV_RO_SMOB,
               LV_MOBILE1,
               LV_MOBILE_LENGTH,
               LV_RCATEG_CD, /*Added By Amit for DMSSERV-13207*/
               LV_VIN
          FROM VH_RO RO, GM_CIN CI, AM_DEALER_LOC LOC
         WHERE RO.CUST_CD = CI.CUST_CD
           AND RO.PARENT_GROUP = P_PARENT_GROUP
           AND RO.DEALER_MAP_CD = P_DEALER
           AND RO.LOC_CD = P_LOC_CD
           AND RO.COMP_FA = P_COMP_FA
           AND RO.RO_NUM = P_DOCUMENT_NUM
           AND CI.PRINCIPAL_MAP_CD = LOC.PRINCIPAL_MAP_CD --added by akanksha for multicompany change
           AND RO.PARENT_GROUP = LOC.PARENT_GROUP
           AND RO.DEALER_MAP_CD = LOC.DEALER_MAP_CD
           AND RO.LOC_CD = LOC.LOC_CD
           AND RO.RCATEG_CD NOT IN ('BDW', 'TRN', 'REF')
           AND NVL(RO.PICKUP_TYPE, 'X') <> 'MMS'; ---ADDED BY SHANKAR 02-04-2018
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          LV_ERROR_CD := 1;
        WHEN OTHERS THEN
          LV_RO_NUM        := NULL;
          LV_MOBILE1       := NULL;
          LV_DEALER_NAME   := NULL;
          LV_MOBILE_LENGTH := 0;
          LV_VIN           := NULL;
      END;

      IF NVL(LV_ERROR_CD, 0) != 1 THEN
        /*Comment By Amit for DMSSERV-13207*/
        /*SELECT REPLACE(REPLACE(REPLACE(LV_TEXT_FORMAT, '<A>', LV_ro_sname),
                             '<mobile>',
                             LV_ro_smob),
                     '<dealer_name>',
                     LV_DEALER_NAME)
        INTO LV_MESSAGE
        FROM DUAL;*/
        /*Comment End By Amit for DMSSERV-13207*/

        /*Added By Amit for DMSSERV-13207*/

        -- IF LV_VIN IS NULL THEN  commented by Govind to bypass check of mc_login table for sending tab_app link
        ---added by shankar on 30-03-2018
        BEGIN
          SELECT XY.LIST_DESC
            INTO LV_TAB_DESC
            FROM AM_LIST XY
           WHERE XY.LIST_NAME = 'TAB_APP'
             AND XY.PRINCIPAL_MAP_CD = 1;
        EXCEPTION
          WHEN OTHERS THEN
            LV_TAB_DESC := NULL;
        END;

        --END IF; commented by Govind to bypass mc_login check

        IF LV_RCATEG_CD = 'BANDP' THEN
          BEGIN
            SELECT PRM.TEXT_FORMAT
              INTO LV_TEXT_FORMAT1
              FROM GM_PROCESS_MASTER PRM
             WHERE PRM.PROCESS_CODE = 'JC_CLOSING_BNDP'
               AND PRM.PRINCIPAL_MAP_CD = 1
               AND PRM.ACTIVE_FLAG = 'Y';
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              LV_TEXT_FORMAT1 := NULL;
            WHEN OTHERS THEN
              LV_TEXT_FORMAT1 := NULL;
          END;

          SELECT REPLACE(REPLACE(REPLACE(LV_TEXT_FORMAT1,
                                         '<A>',
                                         LV_RO_SNAME),
                                 '<mobile>',
                                 LV_RO_SMOB),
                         '<dealer_name>',
                         LV_DEALER_NAME || '. ' || LV_TAB_DESC)
            INTO LV_MESSAGE
            FROM DUAL;
        ELSE
          SELECT REPLACE(REPLACE(REPLACE(LV_TEXT_FORMAT, '<A>', LV_RO_SNAME),
                                 '<mobile>',
                                 LV_RO_SMOB),
                         '<dealer_name>',
                         LV_DEALER_NAME || '. ' || LV_TAB_DESC)
            INTO LV_MESSAGE
            FROM DUAL;
        END IF;
        /*Added End By Amit for DMSSERV-13207*/
        SELECT FNC_VERIF_MOBILE(LV_MOBILE1) INTO LV_VALID_MOBILE FROM DUAL; --CHANGES DONE BY BHAWANA AGAINST DMSSERV-13188 ON8-APR-2015

        IF LV_RO_NUM IS NOT NULL AND LV_MOBILE1 IS NOT NULL AND
           LV_MOBILE_LENGTH = 10 AND LV_DEALER_NAME IS NOT NULL AND
           LV_VALID_MOBILE = 1 THEN
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             '91' || LV_MOBILE1,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             1,
             NULL,
             NULL,
             1);
        ELSE
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             LV_MOBILE1,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             8,
             NULL,
             'DATA NOT CORRECT',
             1);

        END IF;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    COMMIT;
  END IF;
  IF NVL(LV_PROCESS, '@') = 'JC_RESTMAT_TIME' AND
     LV_TEXT_FORMAT IS NOT NULL THEN

    BEGIN
      BEGIN
        SELECT RO.RO_NUM,
               TO_CHAR(RO.REV_PROMISED_DATE, 'DD/MON/YYYY HH24:MI'),
               SUBSTR(LOC.DEALER_NAME, 1, 12) DEALER_NAME,
               NVL(SF_GET_CAR_USER_PHONE(RO.VIN, CI.CUST_CD), --added by bhawana against dmsserv-13188
                   DECODE(SUBSTR(CI.MOBILE_PHONE, 1, 1),
                          '0',
                          SUBSTR(CI.MOBILE_PHONE, 2),
                          CI.MOBILE_PHONE)),
               LENGTH(DECODE(SUBSTR(CI.MOBILE_PHONE, 1, 1),
                             '0',
                             SUBSTR(CI.MOBILE_PHONE, 2),
                             CI.MOBILE_PHONE)),
               RO.REG_NUM
          INTO LV_RO_NUM,
               LV_RO_REV,
               LV_DEALER_NAME,
               LV_MOBILE1,
               LV_MOBILE_LENGTH,
               LV_REG
          FROM VH_RO RO, GM_CIN CI, AM_DEALER_LOC LOC
         WHERE RO.CUST_CD = CI.CUST_CD
           AND RO.PARENT_GROUP = P_PARENT_GROUP
           AND RO.DEALER_MAP_CD = P_DEALER
           AND RO.LOC_CD = P_LOC_CD
           AND RO.COMP_FA = P_COMP_FA
           AND RO.RO_NUM = P_DOCUMENT_NUM
           AND CI.PRINCIPAL_MAP_CD = LOC.PRINCIPAL_MAP_CD --added by akanksha for multicompany change
           AND RO.PARENT_GROUP = LOC.PARENT_GROUP
           AND RO.DEALER_MAP_CD = LOC.DEALER_MAP_CD
           AND RO.LOC_CD = LOC.LOC_CD
           AND RO.RCATEG_CD NOT IN ('BDW', 'TRN', 'REF');

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          LV_ERROR_CD := 1;
        WHEN OTHERS THEN
          LV_RO_NUM        := NULL;
          LV_MOBILE1       := NULL;
          LV_DEALER_NAME   := NULL;
          LV_MOBILE_LENGTH := 0;
          LV_REG           := NULL;
      END;

      IF NVL(LV_ERROR_CD, 0) != 1 THEN
        SELECT REPLACE(REPLACE(REPLACE(LV_TEXT_FORMAT, '<reg>', LV_REG),
                               '<prom date>',
                               LV_RO_REV),
                       '<dealer_name>',
                       LV_DEALER_NAME)
          INTO LV_MESSAGE
          FROM DUAL;
        SELECT FNC_VERIF_MOBILE(LV_MOBILE1) INTO LV_VALID_MOBILE FROM DUAL; --CHANGES DONE BY BHAWANA AGAINST DMSSERV-13188 ON8-APR-2015

        IF LV_RO_NUM IS NOT NULL AND LV_MOBILE1 IS NOT NULL AND
           LV_MOBILE_LENGTH = 10 AND LV_DEALER_NAME IS NOT NULL AND
           LV_REG IS NOT NULL AND LV_RO_REV IS NOT NULL AND
           LV_VALID_MOBILE = 1 THEN
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             '91' || LV_MOBILE1,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             1,
             NULL,
             NULL,
             1);
        ELSE
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             LV_MOBILE1,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             8,
             NULL,
             'DATA NOT CORRECT',
             1);

        END IF;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    COMMIT;
  END IF;
  IF NVL(LV_PROCESS, '@') = 'JC_RESTMAT_COST' AND
     LV_TEXT_FORMAT IS NOT NULL THEN
    BEGIN
      BEGIN
        SELECT RO.RO_NUM,
               --NVL((RO.EST_PART_AMT + RO.EST_LAB_AMT), 0),--Commented by Aafaq on 03-08-2015
               DECODE(NVL(RO.REV_EST_PART_AMT, 0),
                      0,
                      NVL(RO.EST_PART_AMT, 0),
                      RO.REV_EST_PART_AMT) +
               DECODE(NVL(RO.REV_EST_LAB_AMT, 0),
                      0,
                      NVL(RO.EST_LAB_AMT, 0),
                      RO.REV_EST_LAB_AMT) + --Added by Aafaq on 03-08-2015 for checking Revised Estimation Amount if found.
               DECODE(NVL(RO.SCH_REV_EST_PART_AMT, 0), --ADDED BY POOJA ON 11.08.17
                      0,
                      NVL(RO.SCH_EST_PART_AMT, 0),
                      RO.SCH_REV_EST_PART_AMT) +
               DECODE(NVL(RO.SCH_REV_EST_LAB_AMT, 0),
                      0,
                      NVL(RO.SCH_EST_LAB_AMT, 0),
                      RO.SCH_REV_EST_LAB_AMT),
               SUBSTR(LOC.DEALER_NAME, 1, 12) DEALER_NAME,
               NVL(SF_GET_CAR_USER_PHONE(RO.VIN, CI.CUST_CD), --added by bhawana against dmsserv-13188
                   DECODE(SUBSTR(CI.MOBILE_PHONE, 1, 1),
                          '0',
                          SUBSTR(CI.MOBILE_PHONE, 2),
                          CI.MOBILE_PHONE)),
               LENGTH(DECODE(SUBSTR(CI.MOBILE_PHONE, 1, 1),
                             '0',
                             SUBSTR(CI.MOBILE_PHONE, 2),
                             CI.MOBILE_PHONE)),
               RO.REG_NUM,
               SUBSTR((SELECT EM.FIRST_NAME
                        FROM GM_EMP EM
                       WHERE RO.SVC_EMP_CODE = EM.EMP_CD
                         AND RO.DEALER_MAP_CD = EM.DEALER_MAP_CD),
                      1,
                      12),
               (SELECT EM.MOBILE
                  FROM GM_EMP EM
                 WHERE RO.SVC_EMP_CODE = EM.EMP_CD
                   AND RO.DEALER_MAP_CD = EM.DEALER_MAP_CD)
          INTO LV_RO_NUM,
               LV_ETD_AMT,
               LV_DEALER_NAME,
               LV_MOBILE1,
               LV_MOBILE_LENGTH,
               LV_REG,
               LV_RO_SNAME,
               LV_RO_SMOB
          FROM VH_RO RO, GM_CIN CI, AM_DEALER_LOC LOC
         WHERE RO.CUST_CD = CI.CUST_CD
           AND RO.PARENT_GROUP = P_PARENT_GROUP
           AND RO.DEALER_MAP_CD = P_DEALER
           AND RO.LOC_CD = P_LOC_CD
           AND RO.COMP_FA = P_COMP_FA
           AND RO.RO_NUM = P_DOCUMENT_NUM
           AND CI.PRINCIPAL_MAP_CD = LOC.PRINCIPAL_MAP_CD --added by akanksha for multicompany change
           AND RO.PARENT_GROUP = LOC.PARENT_GROUP
           AND RO.DEALER_MAP_CD = LOC.DEALER_MAP_CD
           AND RO.LOC_CD = LOC.LOC_CD
           AND RO.RCATEG_CD NOT IN ('BDW', 'TRN', 'REF');

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          LV_ERROR_CD := 1;
        WHEN OTHERS THEN
          LV_RO_NUM        := NULL;
          LV_ETD_AMT       := 0;
          LV_MOBILE1       := NULL;
          LV_DEALER_NAME   := NULL;
          LV_MOBILE_LENGTH := 0;
          LV_REG           := NULL;
          LV_RO_SNAME      := NULL;
          LV_RO_SMOB       := 0;
      END;

      IF NVL(LV_ERROR_CD, 0) != 1 THEN

        SELECT REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LV_TEXT_FORMAT,
                                                       '<advisor>',
                                                       LV_RO_SNAME),
                                               '<smobile>',
                                               LV_RO_SMOB),
                                       '<amount>',
                                       LV_ETD_AMT),
                               '<reg>',
                               LV_REG),
                       '<dealer_name>',
                       LV_DEALER_NAME)
          INTO LV_MESSAGE
          FROM DUAL;
        SELECT FNC_VERIF_MOBILE(LV_MOBILE1) INTO LV_VALID_MOBILE FROM DUAL; --CHANGES DONE BY BHAWANA AGAINST DMSSERV-13188 ON8-APR-2015

        IF LV_RO_NUM IS NOT NULL AND LV_MOBILE1 IS NOT NULL AND
           LV_MOBILE_LENGTH = 10 AND LV_DEALER_NAME IS NOT NULL AND
           LV_REG IS NOT NULL AND LV_VALID_MOBILE = 1 THEN
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             '91' || LV_MOBILE1,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             1,
             NULL,
             NULL,
             1);
        ELSE
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             LV_MOBILE1,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             8,
             NULL,
             'DATA NOT CORRECT',
             1);

        END IF;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    COMMIT;
  END IF;
  IF NVL(LV_PROCESS, '@') = 'JC_RESTMAT_TC' AND LV_TEXT_FORMAT IS NOT NULL THEN
    BEGIN
      BEGIN
        SELECT RO.RO_NUM,
               TO_CHAR(RO.REV_PROMISED_DATE, 'DD/MON/YYYY HH24:MI'),
               --nvl((RO.EST_PART_AMT + RO.EST_LAB_AMT), 0),--Commented by Aafaq on 03-08-2015
               DECODE(NVL(RO.REV_EST_PART_AMT, 0),
                      0,
                      NVL(RO.EST_PART_AMT, 0),
                      RO.REV_EST_PART_AMT) +
               DECODE(NVL(RO.REV_EST_LAB_AMT, 0),
                      0,
                      NVL(RO.EST_LAB_AMT, 0),
                      RO.REV_EST_LAB_AMT) + --Added by Aafaq on 03-08-2015 for checking Revised Estimation Amount if found.
               DECODE(NVL(RO.SCH_REV_EST_PART_AMT, 0), --ADDED BY POOJA ON 11.08.17
                      0,
                      NVL(RO.SCH_EST_PART_AMT, 0),
                      RO.SCH_REV_EST_PART_AMT) +
               DECODE(NVL(RO.SCH_REV_EST_LAB_AMT, 0),
                      0,
                      NVL(RO.SCH_EST_LAB_AMT, 0),
                      RO.SCH_REV_EST_LAB_AMT),
               SUBSTR(LOC.DEALER_NAME, 1, 12) DEALER_NAME,
               NVL(SF_GET_CAR_USER_PHONE(RO.VIN, CI.CUST_CD), --added by bhawana against dmsserv-13188
                   DECODE(SUBSTR(CI.MOBILE_PHONE, 1, 1),
                          '0',
                          SUBSTR(CI.MOBILE_PHONE, 2),
                          CI.MOBILE_PHONE)),
               LENGTH(DECODE(SUBSTR(CI.MOBILE_PHONE, 1, 1),
                             '0',
                             SUBSTR(CI.MOBILE_PHONE, 2),
                             CI.MOBILE_PHONE)),
               RO.REG_NUM
          INTO LV_RO_NUM,
               LV_RO_REV,
               LV_ETD_AMT,
               LV_DEALER_NAME,
               LV_MOBILE1,
               LV_MOBILE_LENGTH,
               LV_REG
          FROM VH_RO RO, GM_CIN CI, AM_DEALER_LOC LOC
         WHERE RO.CUST_CD = CI.CUST_CD
           AND RO.PARENT_GROUP = P_PARENT_GROUP
           AND RO.DEALER_MAP_CD = P_DEALER
           AND RO.LOC_CD = P_LOC_CD
           AND RO.COMP_FA = P_COMP_FA
           AND RO.RO_NUM = P_DOCUMENT_NUM
           AND CI.PRINCIPAL_MAP_CD = LOC.PRINCIPAL_MAP_CD --added by akanksha for multicompany change
           AND RO.PARENT_GROUP = LOC.PARENT_GROUP
           AND RO.DEALER_MAP_CD = LOC.DEALER_MAP_CD
           AND RO.LOC_CD = LOC.LOC_CD
           AND RO.RCATEG_CD NOT IN ('BDW', 'TRN', 'REF');

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          LV_ERROR_CD := 1;
        WHEN OTHERS THEN
          LV_RO_NUM        := NULL;
          LV_RO_REV        := NULL;
          LV_ETD_AMT       := 0;
          LV_MOBILE1       := NULL;
          LV_DEALER_NAME   := NULL;
          LV_MOBILE_LENGTH := 0;
          LV_REG           := NULL;
      END;
      SELECT FNC_VERIF_MOBILE(LV_MOBILE1) INTO LV_VALID_MOBILE FROM DUAL; --CHANGES DONE BY BHAWANA AGAINST DMSSERV-13188 ON8-APR-2015

      IF NVL(LV_ERROR_CD, 0) != 1 THEN
        SELECT REPLACE(REPLACE(REPLACE(REPLACE(LV_TEXT_FORMAT,
                                               '<reg>',
                                               LV_REG),
                                       '<prom date>',
                                       LV_RO_REV),
                               '<amount>',
                               LV_ETD_AMT),
                       '<dealer_name>',
                       LV_DEALER_NAME)
          INTO LV_MESSAGE
          FROM DUAL;
        SELECT FNC_VERIF_MOBILE(LV_MOBILE1) INTO LV_VALID_MOBILE FROM DUAL; --CHANGES DONE BY BHAWANA AGAINST DMSSERV-13188 ON8-APR-2015

        IF LV_RO_NUM IS NOT NULL AND LV_MOBILE1 IS NOT NULL AND
           LV_MOBILE_LENGTH = 10 AND LV_DEALER_NAME IS NOT NULL AND
           LV_REG IS NOT NULL AND LV_RO_REV IS NOT NULL AND
           LV_VALID_MOBILE = 1 THEN
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             '91' || LV_MOBILE1,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             1,
             NULL,
             NULL,
             1);

        ELSE
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             LV_MOBILE1,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             8,
             NULL,
             'DATA NOT CORRECT',
             1);

        END IF;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    COMMIT;
  END IF;
  -----------------added on nov14 by  bhawana against DMSSERV-13131---------------
  IF NVL(LV_PROCESS, '@') = 'SRV_INITIATION' AND LV_TEXT_FORMAT IS NOT NULL THEN
    BEGIN
      BEGIN
        SELECT RO.RO_NUM,
               CI.CUST_NAME,
               NVL(SF_GET_CAR_USER_PHONE(RO.VIN, CI.CUST_CD), --added by bhawana against dmsserv-13188
                   DECODE(SUBSTR(CI.MOBILE_PHONE, 1, 1),
                          '0',
                          SUBSTR(CI.MOBILE_PHONE, 2),
                          CI.MOBILE_PHONE)),
               LENGTH(DECODE(SUBSTR(CI.MOBILE_PHONE, 1, 1),
                             '0',
                             SUBSTR(CI.MOBILE_PHONE, 2),
                             CI.MOBILE_PHONE)),
               RO.REG_NUM,
               NVL(SUBSTR((SELECT EM.FIRST_NAME
                            FROM GM_EMP EM
                           WHERE RO.SVC_EMP_CODE = EM.EMP_CD
                             AND RO.DEALER_MAP_CD = EM.DEALER_MAP_CD),
                          1,
                          12),
                   'Advisor'),
               (SELECT EM.MOBILE
                  FROM GM_EMP EM
                 WHERE RO.SVC_EMP_CODE = EM.EMP_CD
                   AND RO.DEALER_MAP_CD = EM.DEALER_MAP_CD),
               (SELECT PM.TEAM_CC_MOBILE
                  FROM AM_DEALER_LOC_PARAM PM
                 WHERE PM.PARENT_GROUP = RO.PARENT_GROUP
                   AND PM.DEALER_MAP_CD = RO.DEALER_MAP_CD
                   AND PM.LOC_CD = RO.LOC_CD),
               LOC.DEALER_NAME
          INTO LV_RO_NUM,
               LV_CUST,
               LV_MOBILE1,
               LV_MOBILE_LENGTH,
               LV_REG,
               LV_RO_SNAME,
               LV_RO_SMOB,
               LV_CC_MOBILE,
               LV_DEALER_NAME
          FROM VH_RO RO, GM_CIN CI, AM_DEALER_LOC LOC
         WHERE RO.CUST_CD = CI.CUST_CD
           AND RO.PARENT_GROUP = P_PARENT_GROUP
           AND RO.DEALER_MAP_CD = P_DEALER
           AND RO.LOC_CD = P_LOC_CD
           AND RO.COMP_FA = P_COMP_FA
           AND RO.RO_NUM = P_DOCUMENT_NUM
           AND CI.PRINCIPAL_MAP_CD = LOC.PRINCIPAL_MAP_CD
           AND RO.PARENT_GROUP = LOC.PARENT_GROUP
           AND RO.DEALER_MAP_CD = LOC.DEALER_MAP_CD
           AND RO.LOC_CD = LOC.LOC_CD
           AND RO.RCATEG_CD NOT IN ('BDW', 'TRN', 'REF');

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          LV_ERROR_CD := 1;
        WHEN OTHERS THEN
          LV_CUST          := NULL;
          LV_MOBILE1       := NULL;
          LV_MOBILE_LENGTH := 0;
          LV_REG           := NULL;
          LV_RO_SNAME      := NULL;
          LV_RO_SMOB       := 0;
          LV_CC_MOBILE     := 0;
          LV_DEALER_NAME   := NULL;
          LV_DEALER_NAME1   := NULL; ------Chandan
          LV_DEALER_NAME2   := NULL;-------Chandan
      END;
      LV_DEALER_NAME1 := substr(LV_DEALER_NAME,1,30);------Chandan
      LV_DEALER_NAME2 := substr(LV_DEALER_NAME,31,30);------Chandan

      IF NVL(LV_ERROR_CD, 0) != 1 THEN

        SELECT REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LV_TEXT_FORMAT,
                                                                       '<advisor>',
                                                                       LV_RO_SNAME),
                                                               '<smobile>',
                                                               LV_RO_SMOB),
                                                       '<Customer>',
                                                       LV_CUST),
                                               '<reg>',
                                               LV_REG),
                                       '<MOBILE1>',
                                       LV_MOBILE1),
                               '<cc_mobile>',
                               LV_CC_MOBILE),
                       '<dealer_name>',
                       LV_DEALER_NAME),
            '<dealer_name1>',        ---chandan start
                      LV_DEALER_NAME1),
          '<dealer_name2>',
      LV_DEALER_NAME2),---chandan end
       '<APP_URL>',
   LV_APP_URL) --Added by chandan ason on 9/7/2026
          INTO LV_MESSAGE
          FROM DUAL;
        SELECT FNC_VERIF_MOBILE(LV_MOBILE1) INTO LV_VALID_MOBILE FROM DUAL; --CHANGES DONE BY BHAWANA AGAINST DMSSERV-13188 ON8-APR-2015
        IF LV_RO_NUM IS NOT NULL AND LV_MOBILE1 IS NOT NULL AND
           LV_MOBILE_LENGTH = 10 AND LV_RO_SMOB IS NOT NULL AND
           LV_REG IS NOT NULL AND LV_CUST IS NOT NULL AND
           LV_VALID_MOBILE = 1 THEN
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             '91' || LV_MOBILE1,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             1,
             NULL,
             NULL,
             1);
        ELSE
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             LV_MOBILE1,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             8,
             NULL,
             'DATA NOT CORRECT',
             1);

        END IF;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    COMMIT;
  END IF;

  -----------------------Added By Utkarsh Against DMSSERV-13957-----------------------
 IF NVL(LV_PROCESS, '@') = 'PICK_DROP_APNT' AND LV_TEXT_FORMAT IS NOT NULL THEN

    BEGIN
      BEGIN
          SELECT VH.BTN_NUM,
                 VH.BTN_DATE,
                 VH.BOOKING_SLOT,
                 VH.REG_NUM,
                 (Select GZ.EMP_NAME
                    from GM_EMP gz
                   WHERE PARENT_GROUP = VH.PARENT_GROUP
                     AND DEALER_MAP_CD = VH.DEALER_MAP_CD
                     AND LOC_CD = VH.LOC_CD
                     and GZ.EMP_CD = VH.SVR_EMP_CODE) Service_Advisor,
                 (Select GZ.PHONE_NO
                    from GM_EMP GZ
                   WHERE PARENT_GROUP = VH.PARENT_GROUP
                     AND DEALER_MAP_CD = VH.DEALER_MAP_CD
                     AND LOC_CD = VH.LOC_CD
                     and GZ.EMP_CD = VH.SVR_EMP_CODE) Serviec_Advisor_No,
                 (select dealer_name
                    from am_dealer_loc
                   WHERE PARENT_GROUP = VH.PARENT_GROUP
                     AND DEALER_MAP_CD = VH.DEALER_MAP_CD
                     AND LOC_CD = VH.LOC_CD) Dealer_Name
            INTO LV_BTN_NUM29,
                 LV_BTN_DATE29,
                 LV_BTN_SLOT29,
                 LV_REG_NUM29,
                 LV_SRV_ADV_NAME29,
                 LV_SRV_ADV_NO29,
                 LV_DEALER_NAME29
            FROM VH_BTN VH
           WHERE VH.PARENT_GROUP = P_PARENT_GROUP
             AND VH.DEALER_MAP_CD = P_DEALER
             AND VH.LOC_CD = P_LOC_CD
             AND VH.BTN_NUM = P_DOCUMENT_NUM
             AND VH.COMP_FA = P_COMP_FA;

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          LV_ERROR_CD := 1;
        WHEN OTHERS THEN
          LV_BTN_NUM29      :=NULL;
          LV_BTN_DATE29     :=NULL;
          LV_BTN_SLOT29     :=NULL;
          LV_REG_NUM29      :=NULL;
          LV_SRV_ADV_NAME29 :=NULL;
          LV_SRV_ADV_NO29   :=NULL;
          LV_DEALER_NAME29  :=NULL;
      END;

      IF NVL(LV_ERROR_CD, 0) != 1 THEN

        SELECT REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LV_TEXT_FORMAT,
                                                                       '<Appointment_Number>',
                                                                       LV_BTN_NUM29),
                                                               '<Appointment_Date>',
                                                               LV_BTN_DATE29),
                                                       '<Booking_Slot>',
                                                       LV_BTN_SLOT29),
                                               '<Registration_Number>',
                                               LV_REG_NUM29),
                                       '<Service_Advisor>',
                                       LV_SRV_ADV_NAME29),
                               '<Service_Advisor_No>',
                               LV_SRV_ADV_NO29),
                               '<LINK>',
                               'http://smartpick.marutisuzuki.com/pickdroplink_dev'),
                       '<Dealer_name>',
                       LV_DEALER_NAME29)
          INTO LV_MESSAGE
          FROM DUAL;

       BEGIN
         SELECT GZ.CAR_USER_PHONE
         INTO LV_MOBILE29
         FROM GM_VIN GZ
         WHERE GZ.REG_NUM=LV_REG_NUM29;

        EXCEPTION
          WHEN OTHERS THEN
            LV_MOBILE29:=NULL;
            END;

           IF  LV_MOBILE29 IS NOT NULL THEN

          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             '91' || LV_MOBILE29,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             1,
             NULL,
             NULL,
             1);
        ELSE
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             LV_MOBILE29,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             8,
             NULL,
             'DATA NOT CORRECT',
             1);

        END IF;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    COMMIT;
  END IF;

  ------------added by bhawana aganst dmsserv-13191--------------------
  IF NVL(LV_PROCESS, '@') = 'SRV_MCPENROL' AND LV_TEXT_FORMAT IS NOT NULL THEN

    BEGIN
      BEGIN
        SELECT EN.AMC_NUM,
               SUBSTR(LOC.DEALER_NAME, 1, 12) DEALER_NAME,
               NVL(SF_GET_CAR_USER_PHONE(EN.VIN, EN.CUST_CD),
                   DECODE(SUBSTR(EN.MOBILE, 1, 1),
                          '0',
                          SUBSTR(EN.MOBILE, 2),
                          EN.MOBILE)),
               LENGTH(DECODE(SUBSTR(EN.MOBILE, 1, 1),
                             '0',
                             SUBSTR(EN.MOBILE, 2),
                             EN.MOBILE)),
               EN.AMC_END_DATE,
               EN.AMC_END_MILEAGE,
               AMC_DATE
          INTO LV_AMC_NUM,
               LV_DEALER_NAME,
               LV_MOBILE1,
               LV_MOBILE_LENGTH,
               LV_DATE,
               LV_MIL,
               LV_DATE1
          FROM VH_AMC_ENROL EN, AM_DEALER_LOC LOC
         WHERE EN.SELLING_PARENT_GROUP = P_PARENT_GROUP
           AND EN.SELLING_DEALER_MAP_CD = P_DEALER
           AND EN.SELLING_LOC_CD = P_LOC_CD
           AND EN.AMC_NUM = P_DOCUMENT_NUM
           AND LOC.PRINCIPAL_MAP_CD = 1
           AND EN.SELLING_PARENT_GROUP = LOC.PARENT_GROUP
           AND EN.SELLING_DEALER_MAP_CD = LOC.DEALER_MAP_CD
           AND EN.SELLING_LOC_CD = LOC.LOC_CD;

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          LV_ERROR_CD := 1;
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SQLCODE || SQLERRM);
          LV_AMC_NUM       := NULL;
          LV_MOBILE1       := NULL;
          LV_DEALER_NAME   := NULL;
          LV_MOBILE_LENGTH := 0;
      END;
      IF NVL(LV_ERROR_CD, 0) != 1 THEN
        SELECT REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LV_TEXT_FORMAT,
                                                       '<MCP>',
                                                       LV_AMC_NUM),
                                               '<dealer>',
                                               LV_DEALER_NAME),
                                       '<exp_milg>',
                                       LV_MIL),
                               '<exp_date>',
                               LV_DATE),
                       '<date>',
                       LV_DATE1)

          INTO LV_MESSAGE
          FROM DUAL;
        SELECT FNC_VERIF_MOBILE(LV_MOBILE1) INTO LV_VALID_MOBILE FROM DUAL;

        IF LV_AMC_NUM IS NOT NULL AND LV_MOBILE1 IS NOT NULL AND
           LV_MOBILE_LENGTH = 10 AND LV_DEALER_NAME IS NOT NULL AND
           LV_VALID_MOBILE = 1 AND LV_DATE IS NOT NULL AND
           LV_MIL IS NOT NULL THEN
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             '91' || LV_MOBILE1,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             1,
             NULL,
             NULL,
             1);
        ELSE
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             LV_MOBILE1,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             8,
             NULL,
             'DATA NOT CORRECT',
             1);

        END IF;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN

        NULL;
    END;
    COMMIT;
  END IF;

  -----------FOR MCP CANCEL

  IF NVL(LV_PROCESS, '@') = 'SRV_MCPCANCEL' AND LV_TEXT_FORMAT IS NOT NULL THEN
    BEGIN
      BEGIN
        /*
        SELECT en.amc_num,
               nvl(sf_get_car_user_phone(en.vin, en.cust_cd),
                   decode(substr(en.mobile, 1, 1),
                          '0',
                          substr(en.mobile, 2),
                          en.mobile)),
               length(decode(substr(en.mobile, 1, 1),
                             '0',
                             substr(en.mobile, 2),
                             en.mobile)),
               en.Cancel_Date,
               (nvl(en.labour_used_amt, 0) + nvl(en.part_used_amt, 0) +
               nvl(en.Consumable_Used_Amt, 0)),
               ((nvl(en.labour_amt, 0) + nvl(en.part_amt, 0) +
               nvl(en.consumable_amt, 0)) -
               (NVL(en.labour_used_amt, 0) + nvl(en.part_used_amt, 0) +
               nvl(en.Consumable_Used_Amt, 0))),
               nvl(en.net_rfnd_amt, 0)
          INTO LV_AMC_NUM,
               lv_mobile1,
               lv_mobile_length,
               lv_date,
               lv_used,
               lv_bal,
               lv_ref
          FROM vh_amc_enrol en, am_dealer_loc loc
         WHERE en.selling_parent_group = P_PARENT_GROUP
           and en.selling_dealer_map_cd = P_DEALER
           and en.selling_loc_cd = P_LOC_CD
           AND en.amc_num = P_DOCUMENT_NUM
           AND LOC.PRINCIPAL_MAP_CD = 1
           AND en.selling_parent_group = LOC.parent_group
           AND en.selling_dealer_map_cd = LOC.dealer_map_cd
           AND en.selling_loc_cd = LOC.loc_cd
           AND en.cancel_yn = 'Y'; */

        SELECT EN.AMC_NUM,
               NVL(SF_GET_CAR_USER_PHONE(EN.VIN, EN.CUST_CD),
                   DECODE(SUBSTR(EN.MOBILE, 1, 1),
                          '0',
                          SUBSTR(EN.MOBILE, 2),
                          EN.MOBILE)),
               LENGTH(DECODE(SUBSTR(EN.MOBILE, 1, 1),
                             '0',
                             SUBSTR(EN.MOBILE, 2),
                             EN.MOBILE)),
               EN.CANCEL_DATE,
               trunc((NVL(EN.LABOUR_USED_AMT, 0) + NVL(EN.PART_USED_AMT, 0) +
               NVL(EN.CONSUMABLE_USED_AMT, 0)),2),
               trunc(((NVL(EN.LABOUR_AMT, 0) + NVL(EN.PART_AMT, 0) +
               NVL(EN.CONSUMABLE_AMT, 0)) -
               (NVL(EN.LABOUR_USED_AMT, 0) + NVL(EN.PART_USED_AMT, 0) +
               NVL(EN.CONSUMABLE_USED_AMT, 0) + NVL(EN.DISCOUNT_AMT, 0))),2),
              trunc( NVL(EN.NET_RFND_AMT, 0),2)  ---Added trunc by chandan ason 18-4-24
          INTO LV_AMC_NUM,
               LV_MOBILE1,
               LV_MOBILE_LENGTH,
               LV_DATE,
               LV_USED,
               LV_BAL,
               LV_REF
          FROM VH_AMC_ENROL EN, AM_DEALER_LOC LOC
         WHERE EN.SELLING_PARENT_GROUP = P_PARENT_GROUP
           AND EN.SELLING_DEALER_MAP_CD = P_DEALER
           AND EN.SELLING_LOC_CD = P_LOC_CD
           AND EN.AMC_NUM = P_DOCUMENT_NUM
           AND LOC.PRINCIPAL_MAP_CD = 1
           AND TRUNC(EN.AMC_DATE) < '01-jul-2017'
           AND EN.SELLING_PARENT_GROUP = LOC.PARENT_GROUP
           AND EN.SELLING_DEALER_MAP_CD = LOC.DEALER_MAP_CD
           AND EN.SELLING_LOC_CD = LOC.LOC_CD
           AND EN.CANCEL_YN = 'Y'
        UNION
        SELECT EN.AMC_NUM,
               NVL(SF_GET_CAR_USER_PHONE(EN.VIN, EN.CUST_CD),
                   DECODE(SUBSTR(EN.MOBILE, 1, 1),
                          '0',
                          SUBSTR(EN.MOBILE, 2),
                          EN.MOBILE)),
               LENGTH(DECODE(SUBSTR(EN.MOBILE, 1, 1),
                             '0',
                             SUBSTR(EN.MOBILE, 2),
                             EN.MOBILE)),
               EN.CANCEL_DATE,
              trunc( (SELECT SUM(DECODE(NVL(QTY, 0),
                                  0,
                                  0,
                                  ((NVL(D.BASIC_AMT, 0) -
                                  NVL(D.DISCOUNT_AMT, 0)) / NVL(QTY, 0)) *
                                  NVL(D.SRV_USED_QTY, 0)))
                  FROM VD_AMC_ENROL D
                 WHERE PRINCIPAL_MAP_CD = 1
                   AND AMC_NUM = P_DOCUMENT_NUM),2),
               trunc((SELECT SUM(DECODE(NVL(QTY, 0),
                                  0,
                                  0,
                                  ((NVL(D.BASIC_AMT, 0) -
                                  NVL(D.DISCOUNT_AMT, 0)) / NVL(QTY, 0)) *
                                  (NVL(D.QTY, 0) - NVL(D.SRV_USED_QTY, 0))))
                  FROM VD_AMC_ENROL D
                 WHERE PRINCIPAL_MAP_CD = 1
                   AND AMC_NUM = P_DOCUMENT_NUM),2),
              trunc( ROUND(NVL(EN.NET_RFND_AMT, 0), 0),2) --Added trunc by chandan ason 18-4-24
          FROM VH_AMC_ENROL EN, AM_DEALER_LOC LOC
         WHERE EN.SELLING_PARENT_GROUP = P_PARENT_GROUP
           AND EN.SELLING_DEALER_MAP_CD = P_DEALER
           AND EN.SELLING_LOC_CD = P_LOC_CD
           AND EN.AMC_NUM = P_DOCUMENT_NUM
           AND LOC.PRINCIPAL_MAP_CD = 1
           AND TRUNC(EN.AMC_DATE) >= '01-jul-2017'
           AND EN.SELLING_PARENT_GROUP = LOC.PARENT_GROUP
           AND EN.SELLING_DEALER_MAP_CD = LOC.DEALER_MAP_CD
           AND EN.SELLING_LOC_CD = LOC.LOC_CD
           AND EN.CANCEL_YN = 'Y';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          LV_ERROR_CD := 1;
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SQLCODE || SQLERRM);
          LV_AMC_NUM := NULL;
          LV_MOBILE1 := NULL;

          LV_MOBILE_LENGTH := 0;
      END;

      IF NVL(LV_ERROR_CD, 0) != 1 THEN
        SELECT REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LV_TEXT_FORMAT,
                                                               '<MCP>',
                                                               LV_AMC_NUM),

                                                       '<exp_milg>',
                                                       LV_MIL),
                                               '<used>',
                                               LV_USED),
                                       '<date>',
                                       LV_DATE),
                               '<bal>',
                               LV_BAL),
                       '<ref>',
                       LV_REF)

          INTO LV_MESSAGE
          FROM DUAL;
        SELECT FNC_VERIF_MOBILE(LV_MOBILE1) INTO LV_VALID_MOBILE FROM DUAL;

        IF LV_AMC_NUM IS NOT NULL AND LV_MOBILE1 IS NOT NULL AND
           LV_MOBILE_LENGTH = 10 AND LV_VALID_MOBILE = 1 AND
           LV_DATE IS NOT NULL THEN
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             '91' || LV_MOBILE1,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             1,
             NULL,
             NULL,
             1);
        ELSE
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             LV_MOBILE1,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             8,
             NULL,
             'DATA NOT CORRECT',
             1);

        END IF;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE(P_PARENT_GROUP || ' ' || P_DEALER || ' ' ||
                             P_LOC_CD || ' ' || P_DOCUMENT_NUM || SQLERRM);
        NULL;
    END;
    COMMIT;
  END IF;

  ---------------ADDED BY BHAWANA AGAINST DMSSERV-13278 ON 17-MAY-2016--------------

  --  IF NVL(LV_PROCESS, '@') = 'SMR_SMS' AND LV_TEXT_FORMAT IS NOT NULL THEN
  --CHANGED BY AMAN ON 11-01-2018
  IF NVL(P_TRAN_TYPE, '@') = 'SMR_SMS' THEN

    BEGIN
      BEGIN
        SELECT DUE_DATE,
               REG_NUM,
               NVL(SF_GET_CAR_USER_PHONE(PS.VIN, PS.CUST_CD),
                   DECODE(SUBSTR(CI.MOBILE_PHONE, 1, 1),
                          '0',
                          SUBSTR(CI.MOBILE_PHONE, 2),
                          CI.MOBILE_PHONE)),
               (SELECT PM.TEAM_CC_MOBILE
                  FROM AM_DEALER_LOC_PARAM PM
                 WHERE PM.PARENT_GROUP = PS.PARENT_GROUP
                   AND PM.DEALER_MAP_CD = PS.DEALER_MAP_CD
                   AND PM.LOC_CD = PS.LOC_CD),
               SUBSTR(AL.DEALER_NAME, 1, 30),
               VIN --ADDED BY AMAN ON 11-01-2018
          INTO LV_DATE,
               LV_REG,
               LV_MOBILE1,
               LV_MOBILE,
               LV_DEALER_NAME,
               LV_VIN
          FROM VH_PSF PS, GM_CIN CI, AM_DEALER_LOC AL
         WHERE PS.PARENT_GROUP = P_PARENT_GROUP
           AND PS.DEALER_MAP_CD = P_DEALER
           AND PS.LOC_CD = P_LOC_CD
           AND PS.COMP_FA = P_COMP_FA
           AND PS.PSF_NUM = P_DOCUMENT_NUM
           AND PS.PSF_TYPE = P_DOC_TYPE
           AND CI.CUST_CD = PS.CUST_CD
           AND CI.PRINCIPAL_MAP_CD = 1
           AND AL.PARENT_GROUP = PS.PARENT_GROUP
           AND AL.DEALER_MAP_CD = PS.DEALER_MAP_CD
           AND AL.LOC_CD = PS.LOC_CD;

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          LV_ERROR_CD := 1;
        WHEN OTHERS THEN
          LV_MOBILE      := NULL;
          LV_MOBILE1     := NULL; --cust
          LV_REG         := NULL;
          LV_DEALER_NAME := NULL;
          LV_DATE        := NULL;
          LV_VIN         := NULL;
      END;

      --BELOW CODE ADDED BY AMAN ON 11-01-2019
      IF sf_get_model_channel(1, LV_VIN) in ('NRM', 'NRC', 'COM') THEN
        --ARENA
        LV_ARENA_NEXA := 'A';
      ELSIF sf_get_model_channel(1, LV_VIN) in ('EXC', 'NRE') THEN
        --NEXA
        LV_ARENA_NEXA := 'N';
      END IF;

      BEGIN
        SELECT PRM.PROCESS_CODE, PRM.TEXT_FORMAT
          INTO LV_PROCESS, LV_TEXT_FORMAT
          FROM GM_DLR_SMS_MAPPING SMM, GM_PROCESS_MASTER PRM
         WHERE SMM.PARENT_GROUP = P_PARENT_GROUP
           AND SMM.DEALER_MAP_CD = P_DEALER
           AND SMM.LOC_CD = P_LOC_CD
           AND SMM.PROCESS_CODE = DECODE(LV_ARENA_NEXA,
                                         'A',
                                         'SMR_SMS_ARENA',
                                         'N',
                                         'SMR_SMS_NEXA',
                                         NULL)
           AND TRUNC(SMM.CREATED_DATE) <= TRUNC(SYSDATE)
           AND NVL(SMM.DEACTIVATION_DATE, SYSDATE) >= TRUNC(SYSDATE)
           AND SMM.PROCESS_CODE = PRM.PROCESS_CODE
           AND PRM.PRINCIPAL_MAP_CD =
               SF_PRINCIPAL_MAP_CD(P_DEALER, P_LOC_CD) --added by akanksha for multicompany change
           AND PRM.ACTIVE_FLAG = 'Y';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          LV_PROCESS     := NULL;
          LV_TEXT_FORMAT := NULL;
          LV_ERROR_CD    := 1;
      END;
      ---- added by shailesh on 22.11.2021 against dmsserv-13917

      BEGIN
        SELECT PRM.TEXT_FORMAT
          INTO LV_TEXT_FORMAT_PREVENTIVE
          FROM GM_DLR_SMS_MAPPING SMM, GM_PROCESS_MASTER PRM
         WHERE SMM.PARENT_GROUP = P_PARENT_GROUP
           AND SMM.DEALER_MAP_CD = P_DEALER
           AND SMM.LOC_CD = P_LOC_CD
           AND SMM.PROCESS_CODE = 'DCM_SMR_SMS'
           AND TRUNC(SMM.CREATED_DATE) <= TRUNC(SYSDATE)
           AND NVL(SMM.DEACTIVATION_DATE, SYSDATE) >= TRUNC(SYSDATE)
           AND SMM.PROCESS_CODE = PRM.PROCESS_CODE
           AND PRM.PRINCIPAL_MAP_CD =
               SF_PRINCIPAL_MAP_CD(P_DEALER, P_LOC_CD) --added by akanksha for multicompany change
           AND PRM.ACTIVE_FLAG = 'Y';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          LV_TEXT_FORMAT_PREVENTIVE     := NULL;
      END;

      ----
      IF NVL(LV_ERROR_CD, 0) != 1 THEN

         SELECT replace(REPLACE(REPLACE(REPLACE(REPLACE(LV_TEXT_FORMAT,
                                               '<reg>',
                                               LV_REG),
                                       '<due>',
                                       LV_DATE),
                               '<mob>',
                               LV_MOBILE),
                       '<dealer>',
                       LV_DEALER_NAME),
                       '<app_url>',
                       LV_APP_URL) --Added by Surabhi on 12/Nov/2025 for SMS template changes

          INTO LV_MESSAGE
          FROM DUAL;
        SELECT FNC_VERIF_MOBILE(LV_MOBILE1),
               LENGTH(DECODE(SUBSTR(LV_MOBILE1, 1, 1),
                             '0',
                             SUBSTR(LV_MOBILE1, 2),
                             LV_MOBILE1))
          INTO LV_VALID_MOBILE, LV_MOBILE_LENGTH
          FROM DUAL;
        IF LV_MOBILE1 IS NOT NULL AND LV_MOBILE_LENGTH = 10 AND
           LV_MOBILE IS NOT NULL AND LV_DEALER_NAME IS NOT NULL AND
           LV_VALID_MOBILE = 1 THEN
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             '91' || LV_MOBILE1,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             1,
             NULL,
             NULL,
             1);

          ----Added by Saurav for Monsoon campaign SMS----
          DECLARE
            LV_CHECK_PROMO VARCHAR2(1) := 'Y';
          BEGIN
            BEGIN
              SELECT GPM.TEXT_FORMAT
                INTO LV_MESSAGE
                FROM GM_PROCESS_MASTER GPM
               WHERE GPM.PROCESS_CODE = 'SPR_MONSOON_SMS'
                 AND GPM.ACTIVE_FLAG = 'Y';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                LV_CHECK_PROMO := 'N';
            END;

            IF LV_CHECK_PROMO <> 'N' THEN
              INSERT INTO GM_SMS_STATUS
                (UNIQUE_NUMBER,
                 PARENT_GROUP,
                 DEALER_MAP_CD,
                 LOC_CD,
                 PROCESS_CODE,
                 DOCUMENT_TYPE,
                 DOCUMENT_NO,
                 SMS_TYPE,
                 MOBILE_NO,
                 SMS_CONTENT,
                 CREATED_DATE,
                 CREATED_BY,
                 STATUS,
                 SENT_DATE,
                 REMARKS,
                 SRL_NO)
              VALUES
                (DMS_SMS_UNIQUE_NO.NEXTVAL,
                 P_PARENT_GROUP,
                 P_DEALER,
                 P_LOC_CD,
                 'SPR_MONSOON_SMS',
                 'PROMO_SMS',
                 P_DOCUMENT_NUM,
                 'P',
                 '91' || LV_MOBILE1,
                 LV_MESSAGE,
                 SYSDATE,
                 P_CREATED_BY,
                 1,
                 NULL,
                 NULL,
                 1);
            END IF;
          END;
          -------End here by Saurav----
          -- ADDED BY SHAILESH ON 22.11.2021 AGAINST DMSSERV-13917
          BEGIN
            IF LV_TEXT_FORMAT_PREVENTIVE IS NOT NULL THEN
             INSERT INTO GM_SMS_STATUS
                (UNIQUE_NUMBER,
                 PARENT_GROUP,
                 DEALER_MAP_CD,
                 LOC_CD,
                 PROCESS_CODE,
                 DOCUMENT_TYPE,
                 DOCUMENT_NO,
                 SMS_TYPE,
                 MOBILE_NO,
                 SMS_CONTENT,
                 CREATED_DATE,
                 CREATED_BY,
                 STATUS,
                 SENT_DATE,
                 REMARKS,
                 SRL_NO)
              VALUES
                (DMS_SMS_UNIQUE_NO.NEXTVAL,
                 P_PARENT_GROUP,
                 P_DEALER,
                 P_LOC_CD,
                 'DCM_SMR_SMS',
                 'DCM_SMR_SMS',
                 P_DOCUMENT_NUM,
                 'T',
                 '91' || LV_MOBILE1,
                 LV_TEXT_FORMAT_PREVENTIVE,
                 SYSDATE,
                 P_CREATED_BY,
                 1,
                 NULL,
                 NULL,
                 1);
            END IF;
          END;
          -------End here by Shailesh----
        ELSE
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             LV_MOBILE1,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             8,
             NULL,
             'DATA NOT CORRECT',
             1);
        END IF;

        -- ADDED BY SHAILESH ON 22.11.2021 AGAINST DMSSERV-13917
          BEGIN
            IF LV_TEXT_FORMAT_PREVENTIVE IS NOT NULL THEN
             INSERT INTO GM_SMS_STATUS
                (UNIQUE_NUMBER,
                 PARENT_GROUP,
                 DEALER_MAP_CD,
                 LOC_CD,
                 PROCESS_CODE,
                 DOCUMENT_TYPE,
                 DOCUMENT_NO,
                 SMS_TYPE,
                 MOBILE_NO,
                 SMS_CONTENT,
                 CREATED_DATE,
                 CREATED_BY,
                 STATUS,
                 SENT_DATE,
                 REMARKS,
                 SRL_NO)
              VALUES
                (DMS_SMS_UNIQUE_NO.NEXTVAL,
                 P_PARENT_GROUP,
                 P_DEALER,
                 P_LOC_CD,
                 'DCM_SMR_SMS',
                 'DCM_SMR_SMS',
                 P_DOCUMENT_NUM,
                 'T',
                 '91' || LV_MOBILE1,
                 LV_TEXT_FORMAT_PREVENTIVE,
                 SYSDATE,
                 P_CREATED_BY,
                 8,
                 NULL,
                 'DATA NOT CORRECT',
                 1);
            END IF;
          END;
          -------End here by Shailesh----
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    COMMIT;
  END IF;

  ---------------added by shankar on 02-11-2017 DMSSERV-13411 FOR NEXA -----------------------------------
  IF P_TRAN_TYPE = 'DMS_NEXA_SALE' THEN

    BEGIN
      SELECT PRM.PROCESS_CODE, PRM.TEXT_FORMAT
        INTO LV_PROCESS, LV_TEXT_FORMAT
        FROM GM_DLR_SMS_MAPPING SMM, GM_PROCESS_MASTER PRM
       WHERE SMM.PARENT_GROUP = P_PARENT_GROUP
         AND SMM.DEALER_MAP_CD = P_DEALER
         AND SMM.LOC_CD = P_LOC_CD
         AND SMM.PROCESS_CODE = 'DMS_NEXA_CUST'
         AND TRUNC(SMM.CREATED_DATE) <= TRUNC(SYSDATE)
         AND NVL(SMM.DEACTIVATION_DATE, SYSDATE) >= TRUNC(SYSDATE)
         AND SMM.PROCESS_CODE = PRM.PROCESS_CODE
         AND PRM.PRINCIPAL_MAP_CD = SF_PRINCIPAL_MAP_CD(P_DEALER, P_LOC_CD)
         AND PRM.ACTIVE_FLAG = 'Y';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        LV_PROCESS     := NULL;
        LV_TEXT_FORMAT := NULL;
    END;

    IF NVL(LV_PROCESS, '@') = 'DMS_NEXA_CUST' AND
       LV_TEXT_FORMAT IS NOT NULL THEN
      BEGIN
        BEGIN
          LV_CUST_NAME     := NULL;
          LV_MOBILE1       := NULL;
          LV_MOBILE_LENGTH := 0;
          LV_SA_NAME       := NULL;
          LV_RO_SMOB       := NULL;
          LV_DEALER_NAME   := NULL;

          SELECT CIN.CUST_NAME,
                 NVL(SF_GET_CAR_USER_PHONE(P_DOCUMENT_NUM, CIN.CUST_CD),
                     DECODE(SUBSTR(CIN.MOBILE_PHONE, 1, 1),
                            '0',
                            SUBSTR(CIN.MOBILE_PHONE, 2),
                            CIN.MOBILE_PHONE)),
                 LENGTH(DECODE(SUBSTR(CIN.MOBILE_PHONE, 1, 1),
                               '0',
                               SUBSTR(CIN.MOBILE_PHONE, 2),
                               CIN.MOBILE_PHONE)),
                 SUBSTR((SELECT EM.FIRST_NAME
                          FROM GM_EMP EM
                         WHERE EM.EMP_CD = P_COMP_FA
                           AND EM.DEALER_MAP_CD = P_DEALER),
                        1,
                        12),
                 (SELECT DECODE(SUBSTR(REPLACE(EM.MOBILE, ' ', ','),
                                       1,
                                       INSTR(REPLACE(EM.MOBILE, ' ', ','),
                                             ',') - 1),
                                NULL,
                                EM.MOBILE,
                                SUBSTR(REPLACE(EM.MOBILE, ' ', ','),
                                       1,
                                       INSTR(REPLACE(EM.MOBILE, ' ', ','), ',') - 1)) MOBILE
                    FROM GM_EMP EM
                   WHERE EM.EMP_CD = P_COMP_FA
                     AND EM.DEALER_MAP_CD = P_DEALER),

                 (SELECT AM.DEALER_NAME
                    FROM AM_DEALER_LOC AM
                   WHERE PARENT_GROUP = P_PARENT_GROUP
                     AND DEALER_MAP_CD = P_DEALER
                     AND LOC_CD = P_LOC_CD) DEALER_NAME

            INTO LV_CUST_NAME,
                 LV_MOBILE1,
                 LV_MOBILE_LENGTH,
                 LV_SA_NAME,
                 LV_RO_SMOB,
                 LV_DEALER_NAME
            FROM GM_CIN CIN
           WHERE CIN.CUST_CD = P_DOC_TYPE;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            LV_ERROR_CD := 1;
          WHEN OTHERS THEN
            LV_CUST_NAME     := NULL;
            LV_MOBILE1       := NULL;
            LV_MOBILE_LENGTH := 0;
            LV_SA_NAME       := NULL;
            LV_RO_SMOB       := NULL;
            LV_DEALER_NAME   := NULL;
        END;

        IF NVL(LV_ERROR_CD, 0) != 1 THEN

          SELECT REPLACE(REPLACE(REPLACE(REPLACE(LV_TEXT_FORMAT,
                                                 '<Customer_Name>',
                                                 LV_CUST_NAME),
                                         '<SM_Name>',
                                         LV_SA_NAME),
                                 '<SM_Mobile_No>',
                                 LV_RO_SMOB),
                         '<Dealership_name>',
                         LV_DEALER_NAME)
            INTO LV_MESSAGE
            FROM DUAL;
          SELECT FNC_VERIF_MOBILE(LV_MOBILE1)
            INTO LV_VALID_MOBILE
            FROM DUAL;

          IF LV_CUST_NAME IS NOT NULL AND LV_MOBILE1 IS NOT NULL AND
             LV_MOBILE_LENGTH = 10 AND LV_SA_NAME IS NOT NULL AND
             LV_RO_SMOB IS NOT NULL AND LV_DEALER_NAME IS NOT NULL AND
             LV_VALID_MOBILE = 1 THEN

            INSERT INTO GM_SMS_STATUS
              (UNIQUE_NUMBER,
               PARENT_GROUP,
               DEALER_MAP_CD,
               LOC_CD,
               PROCESS_CODE,
               DOCUMENT_TYPE,
               DOCUMENT_NO,
               SMS_TYPE,
               MOBILE_NO,
               SMS_CONTENT,
               CREATED_DATE,
               CREATED_BY,
               STATUS,
               SENT_DATE,
               REMARKS,
               SRL_NO)
            VALUES
              (DMS_SMS_UNIQUE_NO.NEXTVAL,
               P_PARENT_GROUP,
               P_DEALER,
               P_LOC_CD,
               LV_PROCESS,
               'CUS',
               P_DOCUMENT_NUM,
               'T',
               '91' || LV_MOBILE1,
               LV_MESSAGE,
               SYSDATE,
               P_CREATED_BY,
               1,
               NULL,
               NULL,
               1);

          END IF;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;

      COMMIT;
    END IF;
    ------------------------SM--------------------------------------
    BEGIN
      SELECT PRM.PROCESS_CODE, PRM.TEXT_FORMAT
        INTO LV_PROCESS, LV_TEXT_FORMAT
        FROM GM_DLR_SMS_MAPPING SMM, GM_PROCESS_MASTER PRM
       WHERE SMM.PARENT_GROUP = P_PARENT_GROUP
         AND SMM.DEALER_MAP_CD = P_DEALER
         AND SMM.LOC_CD = P_LOC_CD
         AND SMM.PROCESS_CODE = 'DMS_NEXA_SM'
         AND TRUNC(SMM.CREATED_DATE) <= TRUNC(SYSDATE)
         AND NVL(SMM.DEACTIVATION_DATE, SYSDATE) >= TRUNC(SYSDATE)
         AND SMM.PROCESS_CODE = PRM.PROCESS_CODE
         AND PRM.PRINCIPAL_MAP_CD = SF_PRINCIPAL_MAP_CD(P_DEALER, P_LOC_CD)
         AND PRM.ACTIVE_FLAG = 'Y';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        LV_PROCESS     := NULL;
        LV_TEXT_FORMAT := NULL;
    END;

    IF NVL(LV_PROCESS, '@') = 'DMS_NEXA_SM' AND LV_TEXT_FORMAT IS NOT NULL THEN
      BEGIN
        BEGIN
          LV_CUST_NAME     := NULL;
          LV_MOBILE1       := NULL;
          LV_MOBILE_LENGTH := 0;
          LV_SA_NAME       := NULL;
          LV_RO_SMOB       := NULL;
          LV_MODEL_DESC    := NULL;
          LV_REG           := NULL;

          SELECT CIN.CUST_NAME,
                 NVL(SF_GET_CAR_USER_PHONE(P_DOCUMENT_NUM, CIN.CUST_CD),
                     DECODE(SUBSTR(CIN.MOBILE_PHONE, 1, 1),
                            '0',
                            SUBSTR(CIN.MOBILE_PHONE, 2),
                            CIN.MOBILE_PHONE)),
                 LENGTH(DECODE(SUBSTR(CIN.MOBILE_PHONE, 1, 1),
                               '0',
                               SUBSTR(CIN.MOBILE_PHONE, 2),
                               CIN.MOBILE_PHONE)),
                 SUBSTR((SELECT EM.FIRST_NAME
                          FROM GM_EMP EM
                         WHERE EM.EMP_CD = P_COMP_FA
                           AND EM.DEALER_MAP_CD = P_DEALER),
                        1,
                        12),
                 (SELECT DECODE(SUBSTR(REPLACE(EM.MOBILE, ' ', ','),
                                       1,
                                       INSTR(REPLACE(EM.MOBILE, ' ', ','),
                                             ',') - 1),
                                NULL,
                                EM.MOBILE,
                                SUBSTR(REPLACE(EM.MOBILE, ' ', ','),
                                       1,
                                       INSTR(REPLACE(EM.MOBILE, ' ', ','), ',') - 1)) MOBILE
                    FROM GM_EMP EM
                   WHERE EM.EMP_CD = P_COMP_FA
                     AND EM.DEALER_MAP_CD = P_DEALER),
                 (SELECT MD.MODEL_DESC
                    FROM GM_VIN VIN, GM_MOD MD
                   WHERE VIN.VIN = P_DOCUMENT_NUM
                     AND MD.PRINCIPAL_MAP_CD = VIN.PRINCIPAL_MAP_CD
                     AND MD.MODEL_CD = VIN.MODEL_CD),
                 (SELECT VIN.REG_NUM
                    FROM GM_VIN VIN
                   WHERE VIN.VIN = P_DOCUMENT_NUM)

            INTO LV_CUST_NAME,
                 LV_MOBILE1,
                 LV_MOBILE_LENGTH,
                 LV_SA_NAME,
                 LV_RO_SMOB,
                 LV_MODEL_DESC,
                 LV_REG

            FROM GM_CIN CIN
           WHERE CIN.CUST_CD = P_DOC_TYPE;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            LV_ERROR_CD := 1;
          WHEN OTHERS THEN
            LV_CUST_NAME     := NULL;
            LV_MOBILE1       := NULL;
            LV_MOBILE_LENGTH := 0;
            LV_SA_NAME       := NULL;
            LV_RO_SMOB       := NULL;
            LV_MODEL_DESC    := NULL;
            LV_REG           := NULL;
        END;

        IF NVL(LV_ERROR_CD, 0) != 1 THEN

          SELECT REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LV_TEXT_FORMAT,
                                                         '<SM_Name>',
                                                         LV_SA_NAME),
                                                 '<Customer_Name>',
                                                 LV_CUST_NAME),
                                         '<Model>',
                                         LV_MODEL_DESC),
                                 '<Reg_No>',
                                 LV_REG),
                         '<Customer_Mobile_No>',
                         LV_MOBILE1)

            INTO LV_MESSAGE
            FROM DUAL;
          SELECT FNC_VERIF_MOBILE(LV_MOBILE1)
            INTO LV_VALID_MOBILE
            FROM DUAL;
          IF LV_CUST_NAME IS NOT NULL AND LV_MOBILE1 IS NOT NULL AND
             LV_MOBILE_LENGTH = 10 AND LV_SA_NAME IS NOT NULL AND
             LV_RO_SMOB IS NOT NULL AND LV_MODEL_DESC IS NOT NULL AND
             LV_VALID_MOBILE = 1 THEN

            INSERT INTO GM_SMS_STATUS
              (UNIQUE_NUMBER,
               PARENT_GROUP,
               DEALER_MAP_CD,
               LOC_CD,
               PROCESS_CODE,
               DOCUMENT_TYPE,
               DOCUMENT_NO,
               SMS_TYPE,
               MOBILE_NO,
               SMS_CONTENT,
               CREATED_DATE,
               CREATED_BY,
               STATUS,
               SENT_DATE,
               REMARKS,
               SRL_NO)
            VALUES
              (DMS_SMS_UNIQUE_NO.NEXTVAL,
               P_PARENT_GROUP,
               P_DEALER,
               P_LOC_CD,
               LV_PROCESS,
               'SM', --P_DOC_TYPE,
               P_DOCUMENT_NUM,
               'T',
               '91' || LV_RO_SMOB,
               LV_MESSAGE,
               SYSDATE,
               P_CREATED_BY,
               1,
               NULL,
               NULL,
               1);

          END IF;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;

      COMMIT;
    END IF;
    -----------------------------QM--------------------------------------
    BEGIN
      SELECT PRM.PROCESS_CODE, PRM.TEXT_FORMAT
        INTO LV_PROCESS, LV_TEXT_FORMAT
        FROM GM_DLR_SMS_MAPPING SMM, GM_PROCESS_MASTER PRM
       WHERE SMM.PARENT_GROUP = P_PARENT_GROUP
         AND SMM.DEALER_MAP_CD = P_DEALER
         AND SMM.LOC_CD = P_LOC_CD
         AND SMM.PROCESS_CODE = 'DMS_NEXA_QM'
         AND TRUNC(SMM.CREATED_DATE) <= TRUNC(SYSDATE)
         AND NVL(SMM.DEACTIVATION_DATE, SYSDATE) >= TRUNC(SYSDATE)
         AND SMM.PROCESS_CODE = PRM.PROCESS_CODE
         AND PRM.PRINCIPAL_MAP_CD = SF_PRINCIPAL_MAP_CD(P_DEALER, P_LOC_CD)
         AND PRM.ACTIVE_FLAG = 'Y';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        LV_PROCESS     := NULL;
        LV_TEXT_FORMAT := NULL;
    END;

    IF NVL(LV_PROCESS, '@') = 'DMS_NEXA_QM' AND LV_TEXT_FORMAT IS NOT NULL THEN
      BEGIN

        BEGIN
          LV_CUST_NAME     := NULL;
          LV_MOBILE1       := NULL;
          LV_MOBILE_LENGTH := 0;
          LV_SA_NAME       := NULL;
          LV_QM_NAME       := NULL;
          LV_RO_SMOB       := NULL;
          LV_MODEL_DESC    := NULL;
          LV_REG           := NULL;
          SELECT CIN.CUST_NAME,
                 NVL(SF_GET_CAR_USER_PHONE(P_DOCUMENT_NUM, CIN.CUST_CD),
                     DECODE(SUBSTR(CIN.MOBILE_PHONE, 1, 1),
                            '0',
                            SUBSTR(CIN.MOBILE_PHONE, 2),
                            CIN.MOBILE_PHONE)),
                 LENGTH(DECODE(SUBSTR(CIN.MOBILE_PHONE, 1, 1),
                               '0',
                               SUBSTR(CIN.MOBILE_PHONE, 2),
                               CIN.MOBILE_PHONE)),
                 SUBSTR((SELECT EM.FIRST_NAME
                          FROM GM_EMP EM
                         WHERE EM.EMP_CD = P_COMP_FA
                           AND EM.DEALER_MAP_CD = P_DEALER),
                        1,
                        12),
                 SUBSTR((SELECT (REPLACE(EM.EMP_NAME, ' ', ','))
                          FROM GM_EMP EM
                         WHERE EM.DEALER_MAP_CD = P_DEALER
                           AND EM.EMP_DESG_CD = 'QM'
                           AND ROWNUM = 1),
                        1,
                        12),
                 (SELECT DECODE(SUBSTR(REPLACE(EM.MOBILE, ' ', ','),
                                       1,
                                       INSTR(REPLACE(EM.MOBILE, ' ', ','),
                                             ',') - 1),
                                NULL,
                                EM.MOBILE,
                                SUBSTR(REPLACE(EM.MOBILE, ' ', ','),
                                       1,
                                       INSTR(REPLACE(EM.MOBILE, ' ', ','), ',') - 1)) MOBILE
                    FROM GM_EMP EM
                   WHERE EM.DEALER_MAP_CD = P_DEALER
                     AND EM.EMP_DESG_CD = 'QM'
                     AND ROWNUM = 1),
                 (SELECT MD.MODEL_DESC
                    FROM GM_VIN VIN, GM_MOD MD
                   WHERE VIN.VIN = P_DOCUMENT_NUM
                     AND MD.PRINCIPAL_MAP_CD = VIN.PRINCIPAL_MAP_CD
                     AND MD.MODEL_CD = VIN.MODEL_CD),
                 (SELECT VIN.REG_NUM
                    FROM GM_VIN VIN
                   WHERE VIN.VIN = P_DOCUMENT_NUM)
            INTO LV_CUST_NAME,
                 LV_MOBILE1,
                 LV_MOBILE_LENGTH,
                 LV_SA_NAME,
                 LV_QM_NAME,
                 LV_RO_SMOB,
                 LV_MODEL_DESC,
                 LV_REG
            FROM GM_CIN CIN
           WHERE CIN.CUST_CD = P_DOC_TYPE;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            LV_ERROR_CD := 1;
          WHEN OTHERS THEN
            LV_CUST_NAME     := NULL;
            LV_MOBILE1       := NULL;
            LV_MOBILE_LENGTH := 0;
            LV_SA_NAME       := NULL;
            LV_QM_NAME       := NULL;
            LV_RO_SMOB       := NULL;
            LV_MODEL_DESC    := NULL;
            LV_REG           := NULL;
        END;

        IF NVL(LV_ERROR_CD, 0) != 1 THEN

          SELECT REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LV_TEXT_FORMAT,
                                                                 '<SM_Name>',
                                                                 LV_SA_NAME),
                                                         '<QM_Name>',
                                                         LV_QM_NAME),
                                                 '<Customer_Name>',
                                                 LV_CUST_NAME),
                                         '<Vehicle_Model>',
                                         LV_MODEL_DESC),
                                 '<Reg_No>',
                                 LV_REG),
                         '<Customer_Mobile_No>',
                         LV_MOBILE1)

            INTO LV_MESSAGE
            FROM DUAL;
          SELECT FNC_VERIF_MOBILE(LV_MOBILE1)
            INTO LV_VALID_MOBILE
            FROM DUAL;
          IF LV_CUST_NAME IS NOT NULL AND LV_MOBILE1 IS NOT NULL AND
             LV_MOBILE_LENGTH = 10 AND LV_SA_NAME IS NOT NULL AND
             LV_RO_SMOB IS NOT NULL AND LV_MODEL_DESC IS NOT NULL AND
             LV_VALID_MOBILE = 1 THEN

            INSERT INTO GM_SMS_STATUS
              (UNIQUE_NUMBER,
               PARENT_GROUP,
               DEALER_MAP_CD,
               LOC_CD,
               PROCESS_CODE,
               DOCUMENT_TYPE,
               DOCUMENT_NO,
               SMS_TYPE,
               MOBILE_NO,
               SMS_CONTENT,
               CREATED_DATE,
               CREATED_BY,
               STATUS,
               SENT_DATE,
               REMARKS,
               SRL_NO)
            VALUES
              (DMS_SMS_UNIQUE_NO.NEXTVAL,
               P_PARENT_GROUP,
               P_DEALER,
               P_LOC_CD,
               LV_PROCESS,
               'QM', --P_DOC_TYPE,
               P_DOCUMENT_NUM,
               'T',
               '91' || LV_RO_SMOB,
               LV_MESSAGE,
               SYSDATE,
               P_CREATED_BY,
               1,
               NULL,
               NULL,
               1);

          END IF;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;

      COMMIT;
    END IF;
    ------------------
  END IF;
  ------------

  ---------------------------------------------------------
  --- ADDED BY AMAN ON 23-02-2018
  ---------------------------------------------------------
  IF P_TRAN_TYPE = 'MTAB_SA' THEN
    BEGIN
      BEGIN
        SELECT PRM.PROCESS_CODE, PRM.TEXT_FORMAT
          INTO LV_PROCESS, LV_TEXT_FORMAT
          FROM GM_DLR_SMS_MAPPING SMM, GM_PROCESS_MASTER PRM
         WHERE SMM.PARENT_GROUP = P_PARENT_GROUP
           AND SMM.DEALER_MAP_CD = P_DEALER
           AND SMM.LOC_CD = P_LOC_CD
           AND SMM.PROCESS_CODE = 'MTAB_SA'
           AND TRUNC(SMM.CREATED_DATE) <= TRUNC(SYSDATE)
           AND NVL(SMM.DEACTIVATION_DATE, SYSDATE) >= TRUNC(SYSDATE)
           AND SMM.PROCESS_CODE = PRM.PROCESS_CODE
           AND PRM.PRINCIPAL_MAP_CD =
               SF_PRINCIPAL_MAP_CD(P_DEALER, P_LOC_CD)
           AND PRM.ACTIVE_FLAG = 'Y';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          LV_PROCESS     := NULL;
          LV_TEXT_FORMAT := NULL;
      END;

      SELECT SUBSTR(P_DOC_TYPE, 1, INSTR(P_DOC_TYPE, '$,') - 1),
             SUBSTR(P_DOC_TYPE,
                    INSTR(P_DOC_TYPE, '$,') + 2,
                    INSTR(P_DOC_TYPE, '$,', 1, 2) - INSTR(P_DOC_TYPE, '$,') - 2),
             SUBSTR(P_DOC_TYPE,
                    INSTR(P_DOC_TYPE, '$,', 1, 2) + 2,
                    INSTR(P_DOC_TYPE, '$;', 1) -
                    INSTR(P_DOC_TYPE, '$,', 1, 2) - 2)
        INTO LV_DOC_TYPE, LV_FM_EMP_CD, LV_LINK
        FROM DUAL;

      IF NVL(LV_PROCESS, '@') = 'MTAB_SA' AND LV_TEXT_FORMAT IS NOT NULL THEN
        BEGIN
          BEGIN
            LV_CUST_NAME     := NULL;
            LV_MOBILE1       := NULL;
            LV_MOBILE_LENGTH := 0;
            LV_SA_NAME       := NULL;
            LV_RO_SMOB       := NULL;
            LV_DEALER_NAME   := NULL;

            SELECT REG_NUM, VIN, CUST_CD, SVC_EMP_CODE
              INTO LV_REG_NUM, LV_VIN, LV_CUST_CD, LV_SA_EMP_CD
              FROM VH_RO
             WHERE PARENT_GROUP = P_PARENT_GROUP
               AND DEALER_MAP_CD = P_DEALER
               AND LOC_CD = P_LOC_CD
               AND COMP_FA = P_COMP_FA
               AND RO_NUM = substr(P_DOCUMENT_NUM, 1, 10);

            SELECT CIN.CUST_NAME,
                   NVL(SF_GET_CAR_USER_PHONE(P_DOCUMENT_NUM, CIN.CUST_CD),
                       DECODE(SUBSTR(CIN.MOBILE_PHONE, 1, 1),
                              '0',
                              SUBSTR(CIN.MOBILE_PHONE, 2),
                              CIN.MOBILE_PHONE)) CUST_MOB_NUM, /*
                                                                            LENGTH(NVL(SF_GET_CAR_USER_PHONE(P_DOCUMENT_NUM,
                                                                                                             CIN.CUST_CD),
                                                                                       DECODE(SUBSTR(CIN.MOBILE_PHONE, 1, 1),
                                                                                              '0',
                                                                                              SUBSTR(CIN.MOBILE_PHONE, 2),
                                                                                              CIN.MOBILE_PHONE))) CUST_MOB_LGHT,*/
                   SUBSTR((SELECT EM.FIRST_NAME
                            FROM GM_EMP EM
                           WHERE EM.EMP_CD = LV_SA_EMP_CD
                             AND EM.DEALER_MAP_CD = P_DEALER),
                          1,
                          12) SA_NAME,
                   SUBSTR((SELECT EM.FIRST_NAME
                            FROM GM_EMP EM
                           WHERE EM.EMP_CD = LV_FM_EMP_CD
                             AND EM.DEALER_MAP_CD = P_DEALER),
                          1,
                          12) FM_NAME,
                   (SELECT DECODE(SUBSTR(REPLACE(EM.MOBILE, ' ', ','),
                                         1,
                                         INSTR(REPLACE(EM.MOBILE, ' ', ','),
                                               ',') - 1),
                                  NULL,
                                  EM.MOBILE,
                                  SUBSTR(REPLACE(EM.MOBILE, ' ', ','),
                                         1,
                                         INSTR(REPLACE(EM.MOBILE, ' ', ','),
                                               ',') - 1)) MOBILE
                      FROM GM_EMP EM
                     WHERE EM.EMP_CD = LV_SA_EMP_CD
                       AND EM.DEALER_MAP_CD = P_DEALER
                       AND ROWNUM = 1) SA_MOB_NUM,
                   (SELECT DECODE(SUBSTR(REPLACE(EM.MOBILE, ' ', ','),
                                         1,
                                         INSTR(REPLACE(EM.MOBILE, ' ', ','),
                                               ',') - 1),
                                  NULL,
                                  EM.MOBILE,
                                  SUBSTR(REPLACE(EM.MOBILE, ' ', ','),
                                         1,
                                         INSTR(REPLACE(EM.MOBILE, ' ', ','),
                                               ',') - 1)) MOBILE
                      FROM GM_EMP EM
                     WHERE EM.EMP_CD = LV_FM_EMP_CD
                       AND EM.DEALER_MAP_CD = P_DEALER
                       AND ROWNUM = 1) FM_MOB_NUM,
                   (SELECT MD.MODEL_DESC
                      FROM GM_VIN VIN, GM_MOD MD
                     WHERE VIN.VIN = LV_VIN
                       AND MD.PRINCIPAL_MAP_CD = VIN.PRINCIPAL_MAP_CD
                       AND MD.MODEL_CD = VIN.MODEL_CD)
              INTO LV_CUST_NAME,
                   LV_MOBILE1,
                   --LV_MOBILE_LENGTH,
                   LV_SA_NAME,
                   LV_FM_NAME,
                   LV_SA_MOB,
                   LV_FM_MOB,
                   LV_MODEL_DESC
              FROM GM_CIN CIN
             WHERE CIN.CUST_CD = LV_CUST_CD
               AND PRINCIPAL_MAP_CD = 1;

          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              LV_ERROR_CD := 1;
            WHEN OTHERS THEN
              LV_CUST_NAME     := NULL;
              LV_MOBILE1       := NULL;
              LV_MOBILE_LENGTH := 0;
              LV_SA_NAME       := NULL;
              LV_FM_NAME       := NULL;
              LV_FM_MOB        := NULL;
              LV_SA_MOB        := NULL;
              LV_MODEL_DESC    := NULL;
          END;
          IF NVL(LV_ERROR_CD, 0) != 1 THEN

            SELECT REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LV_TEXT_FORMAT,
                                                                                   '<SA_NAME>',
                                                                                   LV_SA_NAME),
                                                                           '<FM_NAME>',
                                                                           LV_FM_NAME),
                                                                   '<JC_NO>',
                                                                   substr(P_DOCUMENT_NUM,
                                                                          1,
                                                                          10)),
                                                           '<CUST_NAME>',
                                                           LV_CUST_NAME),
                                                   '<CUST_NUM>',
                                                   LV_MOBILE1),
                                           '<MODEL>',
                                           LV_MODEL_DESC),
                                   '<REG_NO>',
                                   LV_REG_NUM),
                           '<LINK>',
                           LV_LINK)
              INTO LV_MESSAGE
              FROM DUAL;

            SELECT FNC_VERIF_MOBILE(LV_MOBILE1)
              INTO LV_VALID_MOBILE
              FROM DUAL;

            LV_MOBILE1       := LV_SA_MOB;
            LV_MOBILE_LENGTH := LENGTH(LV_MOBILE1);

            IF LV_CUST_NAME IS NOT NULL AND LV_MOBILE1 IS NOT NULL AND
               LV_MOBILE_LENGTH = 10 AND LV_SA_NAME IS NOT NULL AND
              -- LV_ro_smob is not null and LV_DEALER_NAME is not null and
               LV_VALID_MOBILE = 1 THEN

              INSERT INTO GM_SMS_STATUS
                (UNIQUE_NUMBER,
                 PARENT_GROUP,
                 DEALER_MAP_CD,
                 LOC_CD,
                 PROCESS_CODE,
                 DOCUMENT_TYPE,
                 DOCUMENT_NO,
                 SMS_TYPE,
                 MOBILE_NO,
                 SMS_CONTENT,
                 CREATED_DATE,
                 CREATED_BY,
                 STATUS,
                 SENT_DATE,
                 REMARKS,
                 SRL_NO)
              VALUES
                (DMS_SMS_UNIQUE_NO.NEXTVAL,
                 P_PARENT_GROUP,
                 P_DEALER,
                 P_LOC_CD,
                 LV_PROCESS,
                 LV_DOC_TYPE,
                 P_DOCUMENT_NUM,
                 'T',
                 '91' || LV_MOBILE1,
                 LV_MESSAGE,
                 SYSDATE,
                 P_CREATED_BY,
                 1,
                 NULL,
                 NULL,
                 1);

              DBMS_OUTPUT.PUT_LINE('INSERT');
            ELSE

              DBMS_OUTPUT.PUT_LINE('NOT INSERT');
            END IF;

          ELSE
            DBMS_OUTPUT.PUT_LINE('NOT INSERT2');
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE('NOT INSERT2--' || SQLERRM);
            NULL;
        END;

        COMMIT;
      END IF;
    END;
  END IF;

  IF P_TRAN_TYPE = 'MTAB_CUS' THEN
    BEGIN

    --Added by Surabhi on 8-11-2024 for DS-781 to Handle '+' sign changes in SMS link for OCAS
     SELECT REPLACE(P_DOC_TYPE,'+','%2B') INTO P_DOC_TYPE_NW FROM DUAL;

     DBMS_OUTPUT.put_line('NEW DOC TYPE -' ||P_DOC_TYPE_NW   );

      SELECT SUBSTR(P_DOC_TYPE_NW, 1, INSTR(P_DOC_TYPE_NW, '$,') - 1),
             SUBSTR(P_DOC_TYPE_NW,
                    INSTR(P_DOC_TYPE_NW, '$,') + 2,
                    INSTR(P_DOC_TYPE_NW, '$,', 1, 2) - INSTR(P_DOC_TYPE_NW, '$,') - 2),
             SUBSTR(P_DOC_TYPE_NW,
                    INSTR(P_DOC_TYPE_NW, '$,', 1, 2) + 2,
                    INSTR(P_DOC_TYPE_NW, '$;', 1) -
                    INSTR(P_DOC_TYPE_NW, '$,', 1, 2) - 2)
        INTO LV_DOC_TYPE, LV_FM_EMP_CD, LV_LINK
        FROM DUAL;

      lv_link1 := substr(LV_LINK,1,30);
      lv_link2 := substr(LV_LINK,31,30);
      lv_link3 := substr(LV_LINK,61,30);
      lv_link4 := substr(LV_LINK,91,30);

      FOR LV IN (SELECT PRM.PROCESS_CODE LV_PROCESS,
                        PRM.TEXT_FORMAT  LV_TEXT_FORMAT
                 --                INTO LV_PROCESS, LV_TEXT_FORMAT
                   FROM GM_DLR_SMS_MAPPING SMM, GM_PROCESS_MASTER PRM
                  WHERE SMM.PARENT_GROUP = P_PARENT_GROUP
                    AND SMM.DEALER_MAP_CD = P_DEALER
                    AND SMM.LOC_CD = P_LOC_CD
                    AND SMM.PROCESS_CODE IN ('MTAB_CUS1', 'MTAB_CUS2')
                    AND TRUNC(SMM.CREATED_DATE) <= TRUNC(SYSDATE)
                    AND NVL(SMM.DEACTIVATION_DATE, SYSDATE) >=
                        TRUNC(SYSDATE)
                    AND SMM.PROCESS_CODE = PRM.PROCESS_CODE
                    AND PRM.PRINCIPAL_MAP_CD =
                        SF_PRINCIPAL_MAP_CD(P_DEALER, P_LOC_CD)
                    AND PRM.ACTIVE_FLAG = 'Y') LOOP
        IF NVL(LV.LV_PROCESS, '@') IN ('MTAB_CUS1', 'MTAB_CUS2') AND
           LV.LV_TEXT_FORMAT IS NOT NULL THEN
          DBMS_OUTPUT.PUT_LINE('IN LOOP');
          BEGIN
            BEGIN
              LV_CUST_NAME     := NULL;
              LV_MOBILE1       := NULL;
              LV_MOBILE_LENGTH := 0;
              LV_SA_NAME       := NULL;
              LV_RO_SMOB       := NULL;
              LV_DEALER_NAME   := NULL;

              SELECT REG_NUM, VIN, CUST_CD, SVC_EMP_CODE
                INTO LV_REG_NUM, LV_VIN, LV_CUST_CD, LV_SA_EMP_CD
                FROM VH_RO
               WHERE PARENT_GROUP = P_PARENT_GROUP
                 AND DEALER_MAP_CD = P_DEALER
                 AND LOC_CD = P_LOC_CD
                 AND COMP_FA = P_COMP_FA
                 AND RO_NUM = substr(P_DOCUMENT_NUM, 1, 10);

              SELECT CIN.CUST_NAME,
                     NVL(SF_GET_CAR_USER_PHONE(P_DOCUMENT_NUM, CIN.CUST_CD),
                         DECODE(SUBSTR(CIN.MOBILE_PHONE, 1, 1),
                                '0',
                                SUBSTR(CIN.MOBILE_PHONE, 2),
                                CIN.MOBILE_PHONE)) CUST_MOB_NUM,
                     LENGTH(NVL(SF_GET_CAR_USER_PHONE(P_DOCUMENT_NUM,
                                                      CIN.CUST_CD),
                                DECODE(SUBSTR(CIN.MOBILE_PHONE, 1, 1),
                                       '0',
                                       SUBSTR(CIN.MOBILE_PHONE, 2),
                                       CIN.MOBILE_PHONE))) CUST_MOB_LGHT,
                     SUBSTR((SELECT EM.FIRST_NAME
                              FROM GM_EMP EM
                             WHERE EM.EMP_CD = LV_SA_EMP_CD
                               AND EM.DEALER_MAP_CD = P_DEALER),
                            1,
                            12) SA_NAME,
                     SUBSTR((SELECT EM.FIRST_NAME
                              FROM GM_EMP EM
                             WHERE EM.EMP_CD = LV_FM_EMP_CD
                               AND EM.DEALER_MAP_CD = P_DEALER),
                            1,
                            12) FM_NAME,
                     (SELECT DECODE(SUBSTR(REPLACE(EM.MOBILE, ' ', ','),
                                           1,
                                           INSTR(REPLACE(EM.MOBILE, ' ', ','),
                                                 ',') - 1),
                                    NULL,
                                    EM.MOBILE,
                                    SUBSTR(REPLACE(EM.MOBILE, ' ', ','),
                                           1,
                                           INSTR(REPLACE(EM.MOBILE, ' ', ','),
                                                 ',') - 1)) MOBILE
                        FROM GM_EMP EM
                       WHERE EM.EMP_CD = LV_SA_EMP_CD
                         AND EM.DEALER_MAP_CD = P_DEALER
                         AND ROWNUM = 1) SA_MOB_NUM,
                     (SELECT DECODE(SUBSTR(REPLACE(EM.MOBILE, ' ', ','),
                                           1,
                                           INSTR(REPLACE(EM.MOBILE, ' ', ','),
                                                 ',') - 1),
                                    NULL,
                                    EM.MOBILE,
                                    SUBSTR(REPLACE(EM.MOBILE, ' ', ','),
                                           1,
                                           INSTR(REPLACE(EM.MOBILE, ' ', ','),
                                                 ',') - 1)) MOBILE
                        FROM GM_EMP EM
                       WHERE EM.EMP_CD = LV_FM_EMP_CD
                         AND EM.DEALER_MAP_CD = P_DEALER
                         AND ROWNUM = 1) FM_MOB_NUM,
                     (SELECT MD.MODEL_DESC
                        FROM GM_VIN VIN, GM_MOD MD
                       WHERE VIN.VIN = LV_VIN
                         AND MD.PRINCIPAL_MAP_CD = VIN.PRINCIPAL_MAP_CD
                         AND MD.MODEL_CD = VIN.MODEL_CD),
                     EMAIL

                INTO LV_CUST_NAME,
                     LV_MOBILE1,
                     LV_MOBILE_LENGTH,
                     LV_SA_NAME,
                     LV_FM_NAME,
                     LV_SA_MOB,
                     LV_FM_MOB,
                     LV_MODEL_DESC,
                     LV_CUST_EMAIL
                FROM GM_CIN CIN
               WHERE CIN.CUST_CD = LV_CUST_CD
                 AND PRINCIPAL_MAP_CD = 1;

            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                LV_ERROR_CD := 1;
              WHEN OTHERS THEN
                LV_CUST_NAME     := NULL;
                LV_MOBILE1       := NULL;
                LV_MOBILE_LENGTH := 0;
                LV_SA_NAME       := NULL;
                LV_FM_NAME       := NULL;
                LV_FM_MOB        := NULL;
                LV_SA_MOB        := NULL;
                LV_MODEL_DESC    := NULL;
            END;

            IF NVL(LV_ERROR_CD, 0) != 1 THEN

              SELECT REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LV.LV_TEXT_FORMAT,
                                                                                             '<SA_NAME>',
                                                                                             LV_SA_NAME),
                                                                                     '<FM_NAME>',
                                                                                     LV_FM_NAME),
                                                                             '<JC_NO>',
                                                                             substr(P_DOCUMENT_NUM,
                                                                                    1,
                                                                                    10)),
                                                                     '<CUST_NAME>',
                                                                     LV_CUST_NAME),
                                                             '<CUST_NUM>',
                                                             LV_MOBILE1),
                                                     '<MODEL>',
                                                     LV_MODEL_DESC),
                                             '<REG_NO>',
                                             LV_REG_NUM),
                                     '<Link1>',
                                     LV_LINK1),
                                  '<Link2>',
                                  LV_LINK2),
                               '<Link3>',
                               LV_LINK3),
                             '<Link4>',
                             LV_LINK4),
                         '<CUST_EMAIL>',
                        LV_CUST_EMAIL),
                       '<APP_URL>',
                       LV_APP_URL) --Added by Surabhi on 17/7/2025
                INTO LV_MESSAGE
                FROM DUAL;
              SELECT FNC_VERIF_MOBILE(LV_MOBILE1)
                INTO LV_VALID_MOBILE
                FROM DUAL;
              LV_UID := NULL;
              IF NVL(LV.LV_PROCESS, '@') IN ('MTAB_CUS2') THEN
                LV_MOBILE1       := LV_SA_MOB;
                LV_MOBILE_LENGTH := LENGTH(LV_MOBILE1);
                LV_CHK_OCAS_SMS  := 'N';
              ELSE
                BEGIN
                  SELECT LIST_CODE
                    INTO LV_CHK_OCAS_SMS
                    FROM AM_LIST
                   WHERE LIST_NAME = 'SND_MSG_YN'
                     AND NVL(LIST_FLAG, 'Y') = 'Y';
                EXCEPTION
                  WHEN OTHERS THEN
                    LV_CHK_OCAS_SMS := 'N';
                END;
              END IF;

              IF LV_CHK_OCAS_SMS = 'Y' THEN
                LV_SMS_STATUS := 3;
              ELSE
                LV_SMS_STATUS := 1;
              END IF;
              IF LV_CUST_NAME IS NOT NULL AND LV_MOBILE1 IS NOT NULL AND
                 LV_MOBILE_LENGTH = 10 AND LV_SA_NAME IS NOT NULL AND
                -- LV_ro_smob is not null and LV_DEALER_NAME is not null and
                 LV_VALID_MOBILE = 1 THEN
                LV_UID := NULL;
                SELECT DMS_SMS_UNIQUE_NO.NEXTVAL INTO LV_UID FROM DUAL;
                INSERT INTO GM_SMS_STATUS
                  (UNIQUE_NUMBER,
                   PARENT_GROUP,
                   DEALER_MAP_CD,
                   LOC_CD,
                   PROCESS_CODE,
                   DOCUMENT_TYPE,
                   DOCUMENT_NO,
                   SMS_TYPE,
                   MOBILE_NO,
                   SMS_CONTENT,
                   CREATED_DATE,
                   CREATED_BY,
                   STATUS,
                   SENT_DATE,
                   REMARKS,
                   SRL_NO)
                VALUES
                  (LV_UID, --DMS_SMS_UNIQUE_NO.NEXTVAL, BLOCKED BY AMAN FOR Priority SMS for O-CAS
                   P_PARENT_GROUP,
                   P_DEALER,
                   P_LOC_CD,
                   LV.LV_PROCESS,
                   LV_DOC_TYPE,
                   P_DOCUMENT_NUM,
                   'T',
                   '91' || LV_MOBILE1,
                   LV_MESSAGE,
                   SYSDATE,
                   P_CREATED_BY,
                   LV_SMS_STATUS, --1,--DMS_SMS_UNIQUE_NO.NEXTVAL, BLOCKED BY AMAN FOR Priority SMS for O-CAS
                   NULL,
                   NULL,
                   1);

                DBMS_OUTPUT.PUT_LINE('INSERT');
              ELSE

                DBMS_OUTPUT.PUT_LINE('NOT INSERT');
              END IF;

            ELSE
              DBMS_OUTPUT.PUT_LINE('NOT INSERT2');
            END IF;
          EXCEPTION
            WHEN OTHERS THEN
              NULL;
          END;
          COMMIT;

          IF NVL(LV.LV_PROCESS, '@') IN ('MTAB_CUS1') AND
             LV_CHK_OCAS_SMS = 'Y' THEN
            BEGIN
              DMS_SEND_SMS_PROCESS('91' || LV_MOBILE1, LV_MESSAGE, LV_UID);
              COMMIT;
            EXCEPTION
              WHEN OTHERS THEN
                NULL;
            END;
          END IF;

        END IF;
      END LOOP;
    END;
  END IF;

  IF P_TRAN_TYPE = 'MTAB_A' THEN
    BEGIN
      SELECT SUBSTR(P_DOC_TYPE, 1, INSTR(P_DOC_TYPE, '$,') - 1),
             SUBSTR(P_DOC_TYPE,
                    INSTR(P_DOC_TYPE, '$,') + 2,
                    INSTR(P_DOC_TYPE, '$,', 1, 2) - INSTR(P_DOC_TYPE, '$,') - 2),
             SUBSTR(P_DOC_TYPE,
                    INSTR(P_DOC_TYPE, '$,', 1, 2) + 2,
                    INSTR(P_DOC_TYPE, '$;', 1) -
                    INSTR(P_DOC_TYPE, '$,', 1, 2) - 2)
        INTO LV_DOC_TYPE, LV_FM_EMP_CD, LV_LINK
        FROM DUAL;
      FOR LV IN (SELECT PRM.PROCESS_CODE LV_PROCESS,
                        PRM.TEXT_FORMAT  LV_TEXT_FORMAT
                 --                INTO LV_PROCESS, LV_TEXT_FORMAT
                   FROM GM_DLR_SMS_MAPPING SMM, GM_PROCESS_MASTER PRM
                  WHERE SMM.PARENT_GROUP = P_PARENT_GROUP
                    AND SMM.DEALER_MAP_CD = P_DEALER
                    AND SMM.LOC_CD = P_LOC_CD
                    AND SMM.PROCESS_CODE IN
                        ('MTAB_A1', 'MTAB_A2', 'MTAB_A3')
                    AND TRUNC(SMM.CREATED_DATE) <= TRUNC(SYSDATE)
                    AND NVL(SMM.DEACTIVATION_DATE, SYSDATE) >=
                        TRUNC(SYSDATE)
                    AND SMM.PROCESS_CODE = PRM.PROCESS_CODE
                    AND PRM.PRINCIPAL_MAP_CD =
                        SF_PRINCIPAL_MAP_CD(P_DEALER, P_LOC_CD)
                    AND PRM.ACTIVE_FLAG = 'Y') LOOP
        IF NVL(LV.LV_PROCESS, '@') IN ('MTAB_A1', 'MTAB_A2', 'MTAB_A3') AND
           LV.LV_TEXT_FORMAT IS NOT NULL THEN
          DBMS_OUTPUT.PUT_LINE('IN LOOP');
          BEGIN
            BEGIN
              LV_CUST_NAME     := NULL;
              LV_MOBILE1       := NULL;
              LV_MOBILE_LENGTH := 0;
              LV_SA_NAME       := NULL;
              LV_RO_SMOB       := NULL;
              LV_DEALER_NAME   := NULL;

              SELECT REG_NUM, VIN, CUST_CD, SVC_EMP_CODE
                INTO LV_REG_NUM, LV_VIN, LV_CUST_CD, LV_SA_EMP_CD
                FROM VH_RO
               WHERE PARENT_GROUP = P_PARENT_GROUP
                 AND DEALER_MAP_CD = P_DEALER
                 AND LOC_CD = P_LOC_CD
                 AND COMP_FA = P_COMP_FA
                 AND RO_NUM = substr(P_DOCUMENT_NUM, 1, 10);

              SELECT CIN.CUST_NAME,
                     NVL(SF_GET_CAR_USER_PHONE(P_DOCUMENT_NUM, CIN.CUST_CD),
                         DECODE(SUBSTR(CIN.MOBILE_PHONE, 1, 1),
                                '0',
                                SUBSTR(CIN.MOBILE_PHONE, 2),
                                CIN.MOBILE_PHONE)) CUST_MOB_NUM,
                     LENGTH(NVL(SF_GET_CAR_USER_PHONE(P_DOCUMENT_NUM,
                                                      CIN.CUST_CD),
                                DECODE(SUBSTR(CIN.MOBILE_PHONE, 1, 1),
                                       '0',
                                       SUBSTR(CIN.MOBILE_PHONE, 2),
                                       CIN.MOBILE_PHONE))) CUST_MOB_LGHT,
                     SUBSTR((SELECT EM.FIRST_NAME
                              FROM GM_EMP EM
                             WHERE EM.EMP_CD = LV_SA_EMP_CD
                               AND EM.DEALER_MAP_CD = P_DEALER),
                            1,
                            12) SA_NAME,
                     SUBSTR((SELECT EM.FIRST_NAME
                              FROM GM_EMP EM
                             WHERE EM.EMP_CD = LV_FM_EMP_CD
                               AND EM.DEALER_MAP_CD = P_DEALER),
                            1,
                            12) FM_NAME,
                     (SELECT DECODE(SUBSTR(REPLACE(EM.MOBILE, ' ', ','),
                                           1,
                                           INSTR(REPLACE(EM.MOBILE, ' ', ','),
                                                 ',') - 1),
                                    NULL,
                                    EM.MOBILE,
                                    SUBSTR(REPLACE(EM.MOBILE, ' ', ','),
                                           1,
                                           INSTR(REPLACE(EM.MOBILE, ' ', ','),
                                                 ',') - 1)) MOBILE
                        FROM GM_EMP EM
                       WHERE EM.EMP_CD = LV_SA_EMP_CD
                         AND EM.DEALER_MAP_CD = P_DEALER
                         AND ROWNUM = 1) SA_MOB_NUM,
                     (SELECT DECODE(SUBSTR(REPLACE(EM.MOBILE, ' ', ','),
                                           1,
                                           INSTR(REPLACE(EM.MOBILE, ' ', ','),
                                                 ',') - 1),
                                    NULL,
                                    EM.MOBILE,
                                    SUBSTR(REPLACE(EM.MOBILE, ' ', ','),
                                           1,
                                           INSTR(REPLACE(EM.MOBILE, ' ', ','),
                                                 ',') - 1)) MOBILE
                        FROM GM_EMP EM
                       WHERE EM.EMP_CD = LV_FM_EMP_CD
                         AND EM.DEALER_MAP_CD = P_DEALER
                         AND ROWNUM = 1) FM_MOB_NUM,
                     (SELECT MD.MODEL_DESC
                        FROM GM_VIN VIN, GM_MOD MD
                       WHERE VIN.VIN = LV_VIN
                         AND MD.PRINCIPAL_MAP_CD = VIN.PRINCIPAL_MAP_CD
                         AND MD.MODEL_CD = VIN.MODEL_CD),
                     EMAIL

                INTO LV_CUST_NAME,
                     LV_MOBILE1,
                     LV_MOBILE_LENGTH,
                     LV_SA_NAME,
                     LV_FM_NAME,
                     LV_SA_MOB,
                     LV_FM_MOB,
                     LV_MODEL_DESC,
                     LV_CUST_EMAIL
                FROM GM_CIN CIN
               WHERE CIN.CUST_CD = LV_CUST_CD
                 AND PRINCIPAL_MAP_CD = 1;

            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                LV_ERROR_CD := 1;
              WHEN OTHERS THEN
                LV_CUST_NAME     := NULL;
                LV_MOBILE1       := NULL;
                LV_MOBILE_LENGTH := 0;
                LV_SA_NAME       := NULL;
                LV_FM_NAME       := NULL;
                LV_FM_MOB        := NULL;
                LV_SA_MOB        := NULL;
                LV_MODEL_DESC    := NULL;
            END;

            IF NVL(LV.LV_PROCESS, '@') IN ('MTAB_A1') THEN
              LV_MOBILE1       := LV_SA_MOB;
              LV_MOBILE_LENGTH := LENGTH(LV_MOBILE1);
            ELSIF NVL(LV.LV_PROCESS, '@') IN ('MTAB_A3') THEN
              LV_MOBILE1       := LV_FM_MOB;
              LV_MOBILE_LENGTH := LENGTH(LV_MOBILE1);
            END IF;
            IF NVL(LV_ERROR_CD, 0) != 1 THEN

              SELECT REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LV.LV_TEXT_FORMAT,
                                                                                             '<SA_NAME>',
                                                                                             LV_SA_NAME),
                                                                                     '<FM_NAME>',
                                                                                     LV_FM_NAME),
                                                                             '<JC_NO>',
                                                                             substr(P_DOCUMENT_NUM,
                                                                                    1,
                                                                                    10)),
                                                                     '<CUST_NAME>',
                                                                     LV_CUST_NAME),
                                                             '<CUST_NUM>',
                                                             LV_MOBILE1),
                                                     '<MODEL>',
                                                     LV_MODEL_DESC),
                                             '<REG_NO>',
                                             LV_REG_NUM),
                                     '<LINK>',
                                     LV_LINK),
                             '<CUST_EMAIL>',
                             LV_CUST_EMAIL),
                              '<APP_URL>',
                           LV_APP_URL) --Added by chandan on 09/7/2026

                INTO LV_MESSAGE
                FROM DUAL;
              SELECT FNC_VERIF_MOBILE(LV_MOBILE1)
                INTO LV_VALID_MOBILE
                FROM DUAL;

              IF LV_CUST_NAME IS NOT NULL AND LV_MOBILE1 IS NOT NULL AND
                 LV_MOBILE_LENGTH = 10 AND LV_SA_NAME IS NOT NULL AND
                -- LV_ro_smob is not null and LV_DEALER_NAME is not null and
                 LV_VALID_MOBILE = 1 THEN

                INSERT INTO GM_SMS_STATUS
                  (UNIQUE_NUMBER,
                   PARENT_GROUP,
                   DEALER_MAP_CD,
                   LOC_CD,
                   PROCESS_CODE,
                   DOCUMENT_TYPE,
                   DOCUMENT_NO,
                   SMS_TYPE,
                   MOBILE_NO,
                   SMS_CONTENT,
                   CREATED_DATE,
                   CREATED_BY,
                   STATUS,
                   SENT_DATE,
                   REMARKS,
                   SRL_NO)
                VALUES
                  (DMS_SMS_UNIQUE_NO.NEXTVAL,
                   P_PARENT_GROUP,
                   P_DEALER,
                   P_LOC_CD,
                   LV.LV_PROCESS,
                   LV_DOC_TYPE,
                   P_DOCUMENT_NUM,
                   'T',
                   '91' || LV_MOBILE1,
                   LV_MESSAGE,
                   SYSDATE,
                   P_CREATED_BY,
                   1,
                   NULL,
                   NULL,
                   1);

                DBMS_OUTPUT.PUT_LINE('INSERT');
              ELSE

                DBMS_OUTPUT.PUT_LINE('NOT INSERT');
              END IF;

            ELSE
              DBMS_OUTPUT.PUT_LINE('NOT INSERT2');
            END IF;
          EXCEPTION
            WHEN OTHERS THEN
              NULL;
          END;

          COMMIT;
        END IF;
      END LOOP;
    END;
  END IF;

  IF P_TRAN_TYPE = 'MTAB_R' THEN
    BEGIN
      SELECT SUBSTR(P_DOC_TYPE, 1, INSTR(P_DOC_TYPE, '$,') - 1),
             SUBSTR(P_DOC_TYPE,
                    INSTR(P_DOC_TYPE, '$,') + 2,
                    INSTR(P_DOC_TYPE, '$,', 1, 2) - INSTR(P_DOC_TYPE, '$,') - 2),
             SUBSTR(P_DOC_TYPE,
                    INSTR(P_DOC_TYPE, '$,', 1, 2) + 2,
                    INSTR(P_DOC_TYPE, '$;', 1) -
                    INSTR(P_DOC_TYPE, '$,', 1, 2) - 2)
        INTO LV_DOC_TYPE, LV_FM_EMP_CD, LV_LINK
        FROM DUAL;
      FOR LV IN (SELECT PRM.PROCESS_CODE LV_PROCESS,
                        PRM.TEXT_FORMAT  LV_TEXT_FORMAT
                 --                INTO LV_PROCESS, LV_TEXT_FORMAT
                   FROM GM_DLR_SMS_MAPPING SMM, GM_PROCESS_MASTER PRM
                  WHERE SMM.PARENT_GROUP = P_PARENT_GROUP
                    AND SMM.DEALER_MAP_CD = P_DEALER
                    AND SMM.LOC_CD = P_LOC_CD
                    AND SMM.PROCESS_CODE IN
                        ('MTAB_R1', 'MTAB_R2', 'MTAB_R3')
                    AND TRUNC(SMM.CREATED_DATE) <= TRUNC(SYSDATE)
                    AND NVL(SMM.DEACTIVATION_DATE, SYSDATE) >=
                        TRUNC(SYSDATE)
                    AND SMM.PROCESS_CODE = PRM.PROCESS_CODE
                    AND PRM.PRINCIPAL_MAP_CD =
                        SF_PRINCIPAL_MAP_CD(P_DEALER, P_LOC_CD)
                    AND PRM.ACTIVE_FLAG = 'Y') LOOP
        IF NVL(LV.LV_PROCESS, '@') IN ('MTAB_R1', 'MTAB_R2', 'MTAB_R3') AND
           LV.LV_TEXT_FORMAT IS NOT NULL THEN
          DBMS_OUTPUT.PUT_LINE('IN LOOP');
          BEGIN
            BEGIN
              LV_CUST_NAME     := NULL;
              LV_MOBILE1       := NULL;
              LV_MOBILE_LENGTH := 0;
              LV_SA_NAME       := NULL;
              LV_RO_SMOB       := NULL;
              LV_DEALER_NAME   := NULL;

              SELECT REG_NUM, VIN, CUST_CD, SVC_EMP_CODE
                INTO LV_REG_NUM, LV_VIN, LV_CUST_CD, LV_SA_EMP_CD
                FROM VH_RO
               WHERE PARENT_GROUP = P_PARENT_GROUP
                 AND DEALER_MAP_CD = P_DEALER
                 AND LOC_CD = P_LOC_CD
                 AND COMP_FA = P_COMP_FA
                 AND RO_NUM = substr(P_DOCUMENT_NUM, 1, 10);

              SELECT CIN.CUST_NAME,
                     NVL(SF_GET_CAR_USER_PHONE(P_DOCUMENT_NUM, CIN.CUST_CD),
                         DECODE(SUBSTR(CIN.MOBILE_PHONE, 1, 1),
                                '0',
                                SUBSTR(CIN.MOBILE_PHONE, 2),
                                CIN.MOBILE_PHONE)) CUST_MOB_NUM,
                     LENGTH(NVL(SF_GET_CAR_USER_PHONE(P_DOCUMENT_NUM,
                                                      CIN.CUST_CD),
                                DECODE(SUBSTR(CIN.MOBILE_PHONE, 1, 1),
                                       '0',
                                       SUBSTR(CIN.MOBILE_PHONE, 2),
                                       CIN.MOBILE_PHONE))) CUST_MOB_LGHT,
                     SUBSTR((SELECT EM.FIRST_NAME
                              FROM GM_EMP EM
                             WHERE EM.EMP_CD = LV_SA_EMP_CD
                               AND EM.DEALER_MAP_CD = P_DEALER),
                            1,
                            12) SA_NAME,
                     SUBSTR((SELECT EM.FIRST_NAME
                              FROM GM_EMP EM
                             WHERE EM.EMP_CD = LV_FM_EMP_CD
                               AND EM.DEALER_MAP_CD = P_DEALER),
                            1,
                            12) FM_NAME,
                     (SELECT DECODE(SUBSTR(REPLACE(EM.MOBILE, ' ', ','),
                                           1,
                                           INSTR(REPLACE(EM.MOBILE, ' ', ','),
                                                 ',') - 1),
                                    NULL,
                                    EM.MOBILE,
                                    SUBSTR(REPLACE(EM.MOBILE, ' ', ','),
                                           1,
                                           INSTR(REPLACE(EM.MOBILE, ' ', ','),
                                                 ',') - 1)) MOBILE
                        FROM GM_EMP EM
                       WHERE EM.EMP_CD = LV_SA_EMP_CD
                         AND EM.DEALER_MAP_CD = P_DEALER
                         AND ROWNUM = 1) SA_MOB_NUM,
                     (SELECT DECODE(SUBSTR(REPLACE(EM.MOBILE, ' ', ','),
                                           1,
                                           INSTR(REPLACE(EM.MOBILE, ' ', ','),
                                                 ',') - 1),
                                    NULL,
                                    EM.MOBILE,
                                    SUBSTR(REPLACE(EM.MOBILE, ' ', ','),
                                           1,
                                           INSTR(REPLACE(EM.MOBILE, ' ', ','),
                                                 ',') - 1)) MOBILE
                        FROM GM_EMP EM
                       WHERE EM.EMP_CD = LV_FM_EMP_CD
                         AND EM.DEALER_MAP_CD = P_DEALER
                         AND ROWNUM = 1) FM_MOB_NUM,
                     (SELECT MD.MODEL_DESC
                        FROM GM_VIN VIN, GM_MOD MD
                       WHERE VIN.VIN = LV_VIN
                         AND MD.PRINCIPAL_MAP_CD = VIN.PRINCIPAL_MAP_CD
                         AND MD.MODEL_CD = VIN.MODEL_CD),
                     EMAIL

                INTO LV_CUST_NAME,
                     LV_MOBILE1,
                     LV_MOBILE_LENGTH,
                     LV_SA_NAME,
                     LV_FM_NAME,
                     LV_SA_MOB,
                     LV_FM_MOB,
                     LV_MODEL_DESC,
                     LV_CUST_EMAIL
                FROM GM_CIN CIN
               WHERE CIN.CUST_CD = LV_CUST_CD
                 AND PRINCIPAL_MAP_CD = 1;

            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                LV_ERROR_CD := 1;
              WHEN OTHERS THEN
                LV_CUST_NAME     := NULL;
                LV_MOBILE1       := NULL;
                LV_MOBILE_LENGTH := 0;
                LV_SA_NAME       := NULL;
                LV_FM_NAME       := NULL;
                LV_FM_MOB        := NULL;
                LV_SA_MOB        := NULL;
                LV_MODEL_DESC    := NULL;
            END;
            IF NVL(LV.LV_PROCESS, '@') IN ('MTAB_R1') THEN
              LV_MOBILE1       := LV_SA_MOB;
              LV_MOBILE_LENGTH := LENGTH(LV_MOBILE1);
            ELSIF NVL(LV.LV_PROCESS, '@') IN ('MTAB_R3') THEN
              LV_MOBILE1       := LV_FM_MOB;
              LV_MOBILE_LENGTH := LENGTH(LV_MOBILE1);
            END IF;
            IF NVL(LV_ERROR_CD, 0) != 1 THEN

              SELECT REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LV.LV_TEXT_FORMAT,
                                                                                             '<SA_NAME>',
                                                                                             LV_SA_NAME),
                                                                                     '<FM_NAME>',
                                                                                     LV_FM_NAME),
                                                                             '<JC_NO>',
                                                                             substr(P_DOCUMENT_NUM,
                                                                                    1,
                                                                                    10)),
                                                                     '<CUST_NAME>',
                                                                     LV_CUST_NAME),
                                                             '<CUST_NUM>',
                                                             LV_MOBILE1),
                                                     '<MODEL>',
                                                     LV_MODEL_DESC),
                                             '<REG_NO>',
                                             LV_REG_NUM),
                                     '<LINK>',
                                     LV_LINK),
                             '<CUST_EMAIL>',
                             LV_CUST_EMAIL)

                INTO LV_MESSAGE
                FROM DUAL;
              SELECT FNC_VERIF_MOBILE(LV_MOBILE1)
                INTO LV_VALID_MOBILE
                FROM DUAL;

              IF LV_CUST_NAME IS NOT NULL AND LV_MOBILE1 IS NOT NULL AND
                 LV_MOBILE_LENGTH = 10 AND LV_SA_NAME IS NOT NULL AND
                -- LV_ro_smob is not null and LV_DEALER_NAME is not null and
                 LV_VALID_MOBILE = 1 THEN

                INSERT INTO GM_SMS_STATUS
                  (UNIQUE_NUMBER,
                   PARENT_GROUP,
                   DEALER_MAP_CD,
                   LOC_CD,
                   PROCESS_CODE,
                   DOCUMENT_TYPE,
                   DOCUMENT_NO,
                   SMS_TYPE,
                   MOBILE_NO,
                   SMS_CONTENT,
                   CREATED_DATE,
                   CREATED_BY,
                   STATUS,
                   SENT_DATE,
                   REMARKS,
                   SRL_NO)
                VALUES
                  (DMS_SMS_UNIQUE_NO.NEXTVAL,
                   P_PARENT_GROUP,
                   P_DEALER,
                   P_LOC_CD,
                   LV.LV_PROCESS,
                   LV_DOC_TYPE,
                   P_DOCUMENT_NUM,
                   'T',
                   '91' || LV_MOBILE1,
                   LV_MESSAGE,
                   SYSDATE,
                   P_CREATED_BY,
                   1,
                   NULL,
                   NULL,
                   1);

                DBMS_OUTPUT.PUT_LINE('INSERT');
              ELSE

                DBMS_OUTPUT.PUT_LINE('NOT INSERT');
              END IF;

            ELSE
              DBMS_OUTPUT.PUT_LINE('NOT INSERT2');
            END IF;
          EXCEPTION
            WHEN OTHERS THEN
              NULL;
          END;

          COMMIT;
        END IF;
      END LOOP;
    END;
  END IF;

  -----------------ADDED BY SHANKAR 03-04-2018----------------------
  IF P_TRAN_TYPE = 'NAPPT_APPOINTMENT' THEN
    -----------SA----------
    BEGIN
      SELECT PRM.PROCESS_CODE, PRM.TEXT_FORMAT
        INTO LV_PROCESS, LV_TEXT_FORMAT
        FROM GM_DLR_SMS_MAPPING SMM, GM_PROCESS_MASTER PRM
       WHERE SMM.PARENT_GROUP = P_PARENT_GROUP
         AND SMM.DEALER_MAP_CD = P_DEALER
         AND SMM.LOC_CD = P_LOC_CD
         AND SMM.PROCESS_CODE = 'NPPAT_SA'
         AND TRUNC(SMM.CREATED_DATE) <= TRUNC(SYSDATE)
         AND NVL(SMM.DEACTIVATION_DATE, SYSDATE) >= TRUNC(SYSDATE)
         AND SMM.PROCESS_CODE = PRM.PROCESS_CODE
         AND PRM.PRINCIPAL_MAP_CD = SF_PRINCIPAL_MAP_CD(P_DEALER, P_LOC_CD)
         AND PRM.ACTIVE_FLAG = 'Y';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        LV_PROCESS     := NULL;
        LV_TEXT_FORMAT := NULL;
    END;

    IF NVL(LV_PROCESS, '@') = 'NPPAT_SA' AND LV_TEXT_FORMAT IS NOT NULL THEN
      BEGIN
        BEGIN
          LV_MOBILE1   := NULL;
          LV_SA_NAME   := NULL;
          LV_RO_NUM    := NULL;
          LV_RO_DATE   := NULL;
          LV_REG       := NULL;
          LV_ETD       := NULL;
          LV_CUST_NAME := NULL;
          LV_RCATEG_CD := NULL;
          LV_EMP_CD    := NULL;
          LV_RO_SMOB   := NULL;
          LV_MESSAGE   := NULL;

          BEGIN
            BEGIN
              SELECT SUBSTR(P_DOCUMENT_NUM,
                            1,
                            (INSTR(P_DOCUMENT_NUM, '#')) - 1),
                     SUBSTR(P_DOCUMENT_NUM,
                            (INSTR(P_DOCUMENT_NUM, '#')) + 1,
                            50),
                     SUBSTR(P_COMP_FA, 1, (INSTR(P_COMP_FA, '#')) - 1),
                     SUBSTR(P_COMP_FA, (INSTR(P_COMP_FA, '#')) + 1, 50),
                     SUBSTR(P_DOC_TYPE, 1, (INSTR(P_DOC_TYPE, '#')) - 1),
                     SUBSTR(P_DOC_TYPE, (INSTR(P_DOC_TYPE, '#')) + 1, 50),
                     SUBSTR(P_CREATED_BY, 1, (INSTR(P_CREATED_BY, '#')) - 1),
                     SUBSTR(P_CREATED_BY,
                            (INSTR(P_CREATED_BY, '#')) + 1,
                            10)

                INTO LV_RO_NUM, ---APPOINTMENT NO
                     LV_RO_DATE, ---APPOINT DATE
                     LV_REG, ---reg_num
                     LV_ETD, ----Slot_15mins
                     LV_CUST_NAME,
                     LV_RCATEG_CD, --SERVICE TYPE
                     LV_EMP_CD,
                     LV_RO_SMOB ----customer mob
                FROM DUAL;
            END;

            SELECT EMP.EMP_NAME, EMP.MOBILE
              INTO LV_SA_NAME, LV_MOBILE1
              FROM GM_EMP EMP
             WHERE EMP.DEALER_MAP_CD = P_DEALER
               AND EMP.EMP_CD = LV_EMP_CD;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              LV_ERROR_CD := 1;
            WHEN OTHERS THEN
              LV_SA_NAME := NULL;
              LV_MOBILE1 := NULL;
          END;
        END;

        IF NVL(LV_ERROR_CD, 0) != 1 THEN

          SELECT REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LV_TEXT_FORMAT,
                                                                         '<SA_Name>',
                                                                         LV_SA_NAME),
                                                                 '<Customer_Name>',
                                                                 LV_CUST_NAME), ---LV_CUST_NAME),
                                                         '<Reg_No>',
                                                         LV_REG),
                                                 '<Cust_Mob_NO>',
                                                 LV_RO_SMOB), ---cust mob
                                         '<Appointment_No>',
                                         LV_RO_NUM),
                                 '<Appointment_date_time>',
                                 LV_RO_DATE),
                         '<Slot_15mins>',
                         LV_ETD)
            INTO LV_MESSAGE
            FROM DUAL;

          SELECT FNC_VERIF_MOBILE(LV_MOBILE1)
            INTO LV_VALID_MOBILE
            FROM DUAL;
          IF LV_MOBILE1 IS NOT NULL AND LV_SA_NAME IS NOT NULL AND
             LV_VALID_MOBILE = 1 THEN

            INSERT INTO GM_SMS_STATUS
              (UNIQUE_NUMBER,
               PARENT_GROUP,
               DEALER_MAP_CD,
               LOC_CD,
               PROCESS_CODE,
               DOCUMENT_TYPE,
               DOCUMENT_NO,
               SMS_TYPE,
               MOBILE_NO,
               SMS_CONTENT,
               CREATED_DATE,
               CREATED_BY,
               STATUS,
               SENT_DATE,
               REMARKS,
               SRL_NO)
            VALUES
              (DMS_SMS_UNIQUE_NO.NEXTVAL,
               P_PARENT_GROUP,
               P_DEALER,
               P_LOC_CD,
               LV_PROCESS,
               'SA', --P_DOC_TYPE,
               LV_RO_NUM, --P_DOCUMENT_NUM,
               'T',
               '91' || LV_MOBILE1,
               LV_MESSAGE,
               SYSDATE,
               'ADMIN', ---P_CREATED_BY,
               1,
               NULL,
               NULL,
               1);

          END IF;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;

      COMMIT;
    END IF;
    ---------------------------QM------------------------------
    BEGIN
      SELECT PRM.PROCESS_CODE, PRM.TEXT_FORMAT
        INTO LV_PROCESS, LV_TEXT_FORMAT
        FROM GM_DLR_SMS_MAPPING SMM, GM_PROCESS_MASTER PRM
       WHERE SMM.PARENT_GROUP = P_PARENT_GROUP
         AND SMM.DEALER_MAP_CD = P_DEALER
         AND SMM.LOC_CD = P_LOC_CD
         AND SMM.PROCESS_CODE = 'NPPAT_QM'
         AND TRUNC(SMM.CREATED_DATE) <= TRUNC(SYSDATE)
         AND NVL(SMM.DEACTIVATION_DATE, SYSDATE) >= TRUNC(SYSDATE)
         AND SMM.PROCESS_CODE = PRM.PROCESS_CODE
         AND PRM.PRINCIPAL_MAP_CD = SF_PRINCIPAL_MAP_CD(P_DEALER, P_LOC_CD)
         AND PRM.ACTIVE_FLAG = 'Y';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        LV_PROCESS     := NULL;
        LV_TEXT_FORMAT := NULL;
    END;

    IF NVL(LV_PROCESS, '@') = 'NPPAT_QM' AND LV_TEXT_FORMAT IS NOT NULL THEN
      BEGIN
        BEGIN
          LV_MOBILE1   := NULL;
          LV_SA_NAME   := NULL;
          LV_RO_NUM    := NULL;
          LV_RO_DATE   := NULL;
          LV_CHANNEL   := NULL;
          LV_DESG      := NULL;
          LV_QM_NAME   := NULL;
          LV_REG       := NULL;
          LV_ETD       := NULL; ----Slot_15mins
          LV_CUST_NAME := NULL;
          LV_RCATEG_CD := NULL; --SERVICE TYPE
          LV_EMP_CD    := NULL;
          LV_RO_SMOB   := NULL;
          LV_MESSAGE   := NULL;

          BEGIN
            BEGIN
              SELECT SUBSTR(P_DOCUMENT_NUM,
                            1,
                            (INSTR(P_DOCUMENT_NUM, '#')) - 1),
                     SUBSTR(P_DOCUMENT_NUM,
                            (INSTR(P_DOCUMENT_NUM, '#')) + 1,
                            50),
                     SUBSTR(P_COMP_FA, 1, (INSTR(P_COMP_FA, '#')) - 1),
                     SUBSTR(P_COMP_FA, (INSTR(P_COMP_FA, '#')) + 1, 50),
                     SUBSTR(P_DOC_TYPE, 1, (INSTR(P_DOC_TYPE, '#')) - 1),
                     SUBSTR(P_DOC_TYPE, (INSTR(P_DOC_TYPE, '#')) + 1, 50),
                     SUBSTR(P_CREATED_BY, 1, (INSTR(P_CREATED_BY, '#')) - 1),
                     SUBSTR(P_CREATED_BY,
                            (INSTR(P_CREATED_BY, '#')) + 1,
                            10)

                INTO LV_RO_NUM, ---APPOINTMENT NO
                     LV_RO_DATE, ---APPOINT DATE
                     LV_REG, ---reg_num
                     LV_ETD, ----Slot_15mins
                     LV_CUST_NAME,
                     LV_RCATEG_CD, --SERVICE TYPE
                     LV_EMP_CD,
                     LV_RO_SMOB
                FROM DUAL;
            END;
            SELECT EMP.EMP_NAME
              INTO LV_SA_NAME
              FROM GM_EMP EMP
             WHERE EMP.DEALER_MAP_CD = P_DEALER
               AND EMP.EMP_CD = LV_EMP_CD;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              LV_ERROR_CD := 1;
            WHEN OTHERS THEN
              LV_SA_NAME := NULL;
          END;
          BEGIN
            SELECT LOC.CHANNEL
              INTO LV_CHANNEL
              FROM AM_DEALER_LOC LOC
             WHERE LOC.PARENT_GROUP = P_PARENT_GROUP
               AND LOC.DEALER_MAP_CD = P_DEALER
               AND LOC.LOC_CD = P_LOC_CD;
          EXCEPTION
            WHEN OTHERS THEN
              LV_CHANNEL := NULL;
          END;

          IF LV_CHANNEL = 'EXC' THEN
            LV_DESG := 'QM';
          ELSE
            LV_DESG := 'WM';
          END IF;

          BEGIN
            SELECT (SELECT EM.MOBILE
                      FROM GM_EMP EM
                     WHERE EM.DEALER_MAP_CD = P_DEALER
                       AND EM.LOC_CD = P_LOC_CD
                       AND EM.EMP_DESG_CD = LV_DESG
                       AND MOBILE IS NOT NULL
                       AND NVL(EM.EMP_LEAVING_DATE, SYSDATE + 1) >= SYSDATE
                       AND EM.EMP_APPROVE = 'A'
                       AND EM.CREATED_DATE =
                           (SELECT MAX(CREATED_DATE)
                              FROM GM_EMP EP
                             WHERE EP.DEALER_MAP_CD = P_DEALER
                               AND EP.LOC_CD = P_LOC_CD
                               AND EP.EMP_DESG_CD = LV_DESG
                               AND NVL(EP.EMP_LEAVING_DATE, SYSDATE + 1) >=
                                   SYSDATE
                               AND EP.EMP_APPROVE = 'A'
                               AND EP.MOBILE IS NOT NULL)),
                   (SELECT EM.EMP_NAME
                      FROM GM_EMP EM
                     WHERE EM.DEALER_MAP_CD = P_DEALER
                       AND EM.LOC_CD = P_LOC_CD
                       AND EM.EMP_DESG_CD = LV_DESG
                       AND MOBILE IS NOT NULL
                       AND NVL(EM.EMP_LEAVING_DATE, SYSDATE + 1) >= SYSDATE
                       AND EM.EMP_APPROVE = 'A'
                       AND EM.CREATED_DATE =
                           (SELECT MAX(CREATED_DATE)
                              FROM GM_EMP EP
                             WHERE EP.DEALER_MAP_CD = P_DEALER
                               AND EP.LOC_CD = P_LOC_CD
                               AND EP.EMP_DESG_CD = LV_DESG
                               AND NVL(EP.EMP_LEAVING_DATE, SYSDATE + 1) >=
                                   SYSDATE
                               AND EP.EMP_APPROVE = 'A'
                               AND EP.MOBILE IS NOT NULL))
              INTO LV_MOBILE1, ---QM_MOB
                   LV_QM_NAME
              FROM DUAL;
          END;
        END;

        IF NVL(LV_ERROR_CD, 0) != 1 THEN

          SELECT REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LV_TEXT_FORMAT,
                                                                                 '<QM_WM_Name>', ----QM_WM NAME
                                                                                 LV_QM_NAME),
                                                                         '<SA_Name>',
                                                                         LV_SA_NAME),
                                                                 '<Customer_Name>',
                                                                 LV_CUST_NAME), ---LV_CUST_NAME),
                                                         '<Reg_No>',
                                                         LV_REG),
                                                 '<Cust_Mob_NO>',
                                                 LV_RO_SMOB), ---cust mob
                                         '<Appointment_No>',
                                         LV_RO_NUM),
                                 '<Appoi_date_time>',
                                 LV_RO_DATE),
                         '<Slot_15mins>',
                         LV_ETD)
            INTO LV_MESSAGE
            FROM DUAL;

          SELECT FNC_VERIF_MOBILE(LV_MOBILE1)
            INTO LV_VALID_MOBILE
            FROM DUAL;
          IF LV_MOBILE1 IS NOT NULL AND LV_SA_NAME IS NOT NULL AND
             LV_VALID_MOBILE = 1 THEN

            INSERT INTO GM_SMS_STATUS
              (UNIQUE_NUMBER,
               PARENT_GROUP,
               DEALER_MAP_CD,
               LOC_CD,
               PROCESS_CODE,
               DOCUMENT_TYPE,
               DOCUMENT_NO,
               SMS_TYPE,
               MOBILE_NO,
               SMS_CONTENT,
               CREATED_DATE,
               CREATED_BY,
               STATUS,
               SENT_DATE,
               REMARKS,
               SRL_NO)
            VALUES
              (DMS_SMS_UNIQUE_NO.NEXTVAL,
               P_PARENT_GROUP,
               P_DEALER,
               P_LOC_CD,
               LV_PROCESS,
               'QM', --P_DOC_TYPE,
               LV_RO_NUM, --P_DOCUMENT_NUM,
               'T',
               '91' || LV_MOBILE1,
               LV_MESSAGE,
               SYSDATE,
               'ADMIN', ---P_CREATED_BY,
               1,
               NULL,
               NULL,
               1);

          END IF;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;

      COMMIT;
    END IF;

    ---------------------CUST------------------------------
    BEGIN
      SELECT PRM.PROCESS_CODE, PRM.TEXT_FORMAT
        INTO LV_PROCESS, LV_TEXT_FORMAT
        FROM GM_DLR_SMS_MAPPING SMM, GM_PROCESS_MASTER PRM
       WHERE SMM.PARENT_GROUP = P_PARENT_GROUP
         AND SMM.DEALER_MAP_CD = P_DEALER
         AND SMM.LOC_CD = P_LOC_CD
         AND SMM.PROCESS_CODE = 'NPPAT_CUST'
         AND TRUNC(SMM.CREATED_DATE) <= TRUNC(SYSDATE)
         AND NVL(SMM.DEACTIVATION_DATE, SYSDATE) >= TRUNC(SYSDATE)
         AND SMM.PROCESS_CODE = PRM.PROCESS_CODE
         AND PRM.PRINCIPAL_MAP_CD = SF_PRINCIPAL_MAP_CD(P_DEALER, P_LOC_CD)
         AND PRM.ACTIVE_FLAG = 'Y';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        LV_PROCESS     := NULL;
        LV_TEXT_FORMAT := NULL;
    END;

    IF NVL(LV_PROCESS, '@') = 'NPPAT_CUST' AND LV_TEXT_FORMAT IS NOT NULL THEN
      BEGIN
        BEGIN
          LV_MOBILE1     := NULL;
          LV_SA_NAME     := NULL;
          LV_RO_NUM      := NULL;
          LV_RO_DATE     := NULL;
          LV_REG         := NULL;
          LV_ETD         := NULL; ----Slot_15mins
          LV_CUST_NAME   := NULL;
          LV_RCATEG_CD   := NULL; ---SERVICE TYPE
          LV_EMP_CD      := NULL;
          LV_DEALER_NAME := NULL;
          LV_LOC_DESG    := NULL;
          LV_PMC         := NULL;
          LV_MESSAGE     := NULL;
          LV_SA_MOB      := NULL;

          BEGIN
            SELECT SUBSTR(P_DOCUMENT_NUM,
                          1,
                          (INSTR(P_DOCUMENT_NUM, '#')) - 1),
                   SUBSTR(P_DOCUMENT_NUM,
                          (INSTR(P_DOCUMENT_NUM, '#')) + 1,
                          50),
                   SUBSTR(P_COMP_FA, 1, (INSTR(P_COMP_FA, '#')) - 1),
                   SUBSTR(P_COMP_FA, (INSTR(P_COMP_FA, '#')) + 1, 50),
                   SUBSTR(P_DOC_TYPE, 1, (INSTR(P_DOC_TYPE, '#')) - 1),
                   SUBSTR(P_DOC_TYPE, (INSTR(P_DOC_TYPE, '#')) + 1, 50),
                   SUBSTR(P_CREATED_BY, 1, (INSTR(P_CREATED_BY, '#')) - 1),
                   SUBSTR(P_CREATED_BY, (INSTR(P_CREATED_BY, '#')) + 1, 10)

              INTO LV_RO_NUM, ---APPOINTMENT NO
                   LV_RO_DATE, ---APPOINT DATE
                   LV_REG, ---reg_num
                   LV_ETD, ----Slot_15mins
                   LV_CUST_NAME,
                   LV_RCATEG_CD, --SERVICE TYPE
                   LV_EMP_CD,
                   LV_MOBILE1
              FROM DUAL;
          END;

          BEGIN
            SELECT LOC.DEALER_NAME, LOC.LOC_DESC, LOC.PRINCIPAL_MAP_CD
              INTO LV_DEALER_NAME, LV_LOC_DESG, LV_PMC
              FROM AM_DEALER_LOC LOC
             WHERE LOC.PARENT_GROUP = P_PARENT_GROUP
               AND LOC.DEALER_MAP_CD = P_DEALER
               AND LOC.LOC_CD = P_LOC_CD;
          EXCEPTION
            WHEN OTHERS THEN
              LV_DEALER_NAME := NULL;
              LV_LOC_DESG    := NULL;
          END;

          BEGIN
            SELECT EMP.EMP_NAME, EMP.MOBILE
              INTO LV_SA_NAME, LV_SA_MOB
              FROM GM_EMP EMP
             WHERE EMP.DEALER_MAP_CD = P_DEALER
               AND EMP.EMP_CD = LV_EMP_CD;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              LV_ERROR_CD := 1;
            WHEN OTHERS THEN
              LV_SA_NAME := NULL;
              LV_SA_MOB  := NULL;
          END;
        END;

        IF NVL(LV_ERROR_CD, 0) != 1 THEN

          SELECT REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LV_TEXT_FORMAT,
                                                                                 '<workshop>',
                                                                                 LV_DEALER_NAME),
                                                                         '<Location>',
                                                                         LV_LOC_DESG), ---location,
                                                                 '<Dateandtime>',
                                                                 LV_RO_DATE),
                                                         '<service>',
                                                         LV_RCATEG_CD),
                                                 '<SA_Name>',
                                                 LV_SA_NAME),
                                         '<SA_Mob_No>',
                                         LV_SA_MOB),
                                 '<Slot_15mins>',
                                 LV_ETD),
                         '<doc_num>',
                         LV_RO_NUM)

            INTO LV_MESSAGE
            FROM DUAL;

          SELECT FNC_VERIF_MOBILE(LV_MOBILE1)
            INTO LV_VALID_MOBILE
            FROM DUAL;
          IF LV_MOBILE1 IS NOT NULL AND LV_SA_NAME IS NOT NULL AND
             LV_VALID_MOBILE = 1 THEN

            INSERT INTO GM_SMS_STATUS
              (UNIQUE_NUMBER,
               PARENT_GROUP,
               DEALER_MAP_CD,
               LOC_CD,
               PROCESS_CODE,
               DOCUMENT_TYPE,
               DOCUMENT_NO,
               SMS_TYPE,
               MOBILE_NO,
               SMS_CONTENT,
               CREATED_DATE,
               CREATED_BY,
               STATUS,
               SENT_DATE,
               REMARKS,
               SRL_NO)
            VALUES
              (DMS_SMS_UNIQUE_NO.NEXTVAL,
               P_PARENT_GROUP,
               P_DEALER,
               P_LOC_CD,
               LV_PROCESS,
               'CUST', --P_DOC_TYPE,
               LV_RO_NUM, --P_DOCUMENT_NUM,
               'T',
               '91' || LV_MOBILE1,
               LV_MESSAGE,
               SYSDATE,
               'ADMIN', ---P_CREATED_BY,
               1,
               NULL,
               NULL,
               1);

          END IF;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;

      COMMIT;
    END IF;
  END IF;

  IF P_TRAN_TYPE = 'TODAY_CUST_APP' THEN

    BEGIN
      SELECT PRM.PROCESS_CODE, PRM.TEXT_FORMAT
        INTO LV_PROCESS, LV_TEXT_FORMAT
        FROM GM_DLR_SMS_MAPPING SMM, GM_PROCESS_MASTER PRM
       WHERE SMM.PARENT_GROUP = P_PARENT_GROUP
         AND SMM.DEALER_MAP_CD = P_DEALER
         AND SMM.LOC_CD = P_LOC_CD
         AND SMM.PROCESS_CODE = 'TODAY_CUST_APP'
         AND TRUNC(SMM.CREATED_DATE) <= TRUNC(SYSDATE)
         AND NVL(SMM.DEACTIVATION_DATE, SYSDATE) >= TRUNC(SYSDATE)
         AND SMM.PROCESS_CODE = PRM.PROCESS_CODE
         AND PRM.PRINCIPAL_MAP_CD = SF_PRINCIPAL_MAP_CD(P_DEALER, P_LOC_CD)
         AND PRM.ACTIVE_FLAG = 'Y';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        LV_PROCESS     := NULL;
        LV_TEXT_FORMAT := NULL;
    END;
    IF LV_TEXT_FORMAT IS NULL OR LV_PROCESS IS NULL THEN
      RETURN;
    END IF;
    DECLARE
      LV_DLR_NAME  VARCHAR2(500);
      LV_TIME_SLOT VARCHAR2(500);
      LV_SA_NAME   VARCHAR2(500);
      LV_SA_MOB    VARCHAR2(500);
      LV_CUST_MOB  VARCHAR2(500);
      LV_SMS_DESC  VARCHAR2(4000) := LV_TEXT_FORMAT;
    BEGIN
      FOR I IN (SELECT /*+INDEX (BNT IDX_VH_BTN_FOR_DATE)*/
                 LOC.PARENT_GROUP,
                 LOC.DEALER_NAME,
                 LOC.DEALER_MAP_CD,
                 LOC.LOC_CD,
                 TO_CHAR(TRUNC(BTN.BTN_FOR_DATE), 'DD-MON-YYYY') BTN_FOR_DATE,
                 SUBSTR(BOOKING_SLOT_TIME, 1, 2) || ':' ||
                 SUBSTR(BOOKING_SLOT_TIME, 3, 2) || ' - ' ||
                 SUBSTR(BOOKING_SLOT_TIME,
                        INSTR(BOOKING_SLOT_TIME, '-') + 1,
                        2) || ':' || SUBSTR(BOOKING_SLOT_TIME,
                                            INSTR(BOOKING_SLOT_TIME, '-') + 3,
                                            2) BOOKING_SLOT,
                 SVR_EMP_CODE,
                 CUST_CD,
                 VIN,
                 BTN_NUM
                  FROM VH_BTN BTN, AM_DEALER_LOC LOC
                 WHERE TRUNC(BTN.BTN_FOR_DATE) = TRUNC(SYSDATE)
                   AND NVL(CONFIRMED_YN, 'N') = 'N'
                   AND NVL(CANCEL_YN, 'N') = 'N'
                   AND LOC.DEALER_MAP_CD = BTN.DEALER_MAP_CD
                   AND LOC.LOC_CD = BTN.LOC_CD
                   AND LOC.PRINCIPAL_MAP_CD = 1
                   AND BOOKING_SLOT IS NOT NULL
                   AND SVR_EMP_CODE IS NOT NULL) LOOP
        BEGIN

          LV_SMS_DESC := LV_TEXT_FORMAT;
          LV_SA_MOB   := NULL;
          LV_SA_NAME  := NULL;
          SELECT DECODE(SUBSTR(REPLACE(EM.MOBILE, ' ', ','),
                               1,
                               INSTR(REPLACE(EM.MOBILE, ' ', ','), ',') - 1),
                        NULL,
                        EM.MOBILE,
                        SUBSTR(REPLACE(EM.MOBILE, ' ', ','),
                               1,
                               INSTR(REPLACE(EM.MOBILE, ' ', ','), ',') - 1)) MOBILE,
                 EMP_NAME
            INTO LV_SA_MOB, LV_SA_NAME
            FROM GM_EMP EM
           WHERE DEALER_MAP_CD = I.DEALER_MAP_CD
                --AND LOC_CD        = I.LOC_CD
             AND EMP_CD = I.SVR_EMP_CODE;
        EXCEPTION
          WHEN OTHERS THEN
            LV_SA_MOB  := NULL;
            LV_SA_NAME := NULL;
        END;

        BEGIN
          SELECT NVL(SF_GET_CAR_USER_PHONE(I.VIN, CIN.CUST_CD),
                     DECODE(SUBSTR(CIN.MOBILE_PHONE, 1, 1),
                            '0',
                            SUBSTR(CIN.MOBILE_PHONE, 2),
                            CIN.MOBILE_PHONE))
            INTO --LV_CUST_NAME,
                 LV_CUST_MOB
            FROM GM_CIN CIN
           WHERE CUST_CD = I.CUST_CD
             AND PRINCIPAL_MAP_CD = 1;
        EXCEPTION
          WHEN OTHERS THEN
            LV_CUST_MOB := NULL;
        END;

        LV_SMS_DESC := REPLACE(LV_SMS_DESC,
                               '<WORKSHOP_NAME>',
                               I.DEALER_NAME);
        LV_SMS_DESC := REPLACE(LV_SMS_DESC, '<BTN_DATE>', I.BTN_FOR_DATE);
        LV_SMS_DESC := REPLACE(LV_SMS_DESC, '<TIME_SLOT>', I.BOOKING_SLOT);
        LV_SMS_DESC := REPLACE(LV_SMS_DESC, '<SA_NAME>', LV_SA_NAME);
        LV_SMS_DESC := REPLACE(LV_SMS_DESC, '<MOBILE_NO>', LV_SA_MOB);
        LV_SMS_DESC := REPLACE(LV_SMS_DESC, '<APP_URL>',  LV_APP_URL); --Added by Surabhi on 17/7/2025
        --DBMS_OUTPUT.PUT_LINE('MESSAGE BODY -->'||LV_SMS_DESC||' TO NUMBER -->'||LV_CUST_MOB);
        LV_MOBILE1 := LV_CUST_MOB;
        LV_MESSAGE := LV_SMS_DESC;
        SELECT FNC_VERIF_MOBILE(LV_MOBILE1) INTO LV_VALID_MOBILE FROM DUAL;
        IF LV_MOBILE1 IS NOT NULL AND LV_SA_NAME IS NOT NULL AND
           LV_VALID_MOBILE = 1 THEN
          BEGIN
            INSERT INTO GM_SMS_STATUS
              (UNIQUE_NUMBER,
               PARENT_GROUP,
               DEALER_MAP_CD,
               LOC_CD,
               PROCESS_CODE,
               DOCUMENT_TYPE,
               DOCUMENT_NO,
               SMS_TYPE,
               MOBILE_NO,
               SMS_CONTENT,
               CREATED_DATE,
               CREATED_BY,
               STATUS,
               SENT_DATE,
               REMARKS,
               SRL_NO)
            VALUES
              (DMS_SMS_UNIQUE_NO.NEXTVAL,
               I.PARENT_GROUP,
               I.DEALER_MAP_CD,
               I.LOC_CD,
               LV_PROCESS,
               'BTN', --P_DOC_TYPE,
               I.BTN_NUM, --P_DOCUMENT_NUM,
               'T',
               '91' || LV_MOBILE1,
               LV_MESSAGE,
               SYSDATE,
               'ADMIN', ---P_CREATED_BY,
               1,
               NULL,
               NULL,
               1);
            COMMIT;
          EXCEPTION
            WHEN OTHERS THEN
              NULL;
          END;
        END IF;

      END LOOP;
    END;
  END IF;

  IF P_TRAN_TYPE = 'SA_LEAVE_2MGR' THEN
    /**************************************
    ** P_DOC_TYPE = Left Employee code
    **************************************/
    BEGIN
      SELECT PRM.PROCESS_CODE, PRM.TEXT_FORMAT
        INTO LV_PROCESS, LV_TEXT_FORMAT
        FROM GM_DLR_SMS_MAPPING SMM, GM_PROCESS_MASTER PRM
       WHERE SMM.PARENT_GROUP = P_PARENT_GROUP
         AND SMM.DEALER_MAP_CD = P_DEALER
         AND SMM.LOC_CD = P_LOC_CD
         AND SMM.PROCESS_CODE = 'SA_LEAVE_2MGR'
         AND TRUNC(SMM.CREATED_DATE) <= TRUNC(SYSDATE)
         AND NVL(SMM.DEACTIVATION_DATE, SYSDATE) >= TRUNC(SYSDATE)
         AND SMM.PROCESS_CODE = PRM.PROCESS_CODE
         AND PRM.PRINCIPAL_MAP_CD = SF_PRINCIPAL_MAP_CD(P_DEALER, P_LOC_CD)
         AND PRM.ACTIVE_FLAG = 'Y';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        LV_PROCESS     := NULL;
        LV_TEXT_FORMAT := NULL;
    END;
    IF LV_TEXT_FORMAT IS NULL OR LV_PROCESS IS NULL THEN
      RETURN;
    END IF;

    DECLARE
      LV_EMP_NAME VARCHAR2(100);
      LV_EMP_MOB  VARCHAR2(100);
      LV_EMP_CD   VARCHAR2(100);
      LV_CHK_APP  VARCHAR2(1) := 'N';
      LV_QM_GM    VARCHAR2(10);
      LV_CHANNEL  VARCHAR2(100);
      LV_SMS_DESC VARCHAR2(4000);
      LV_SA_MOB   VARCHAR2(1000) := NULL;
      LV_SA_NAME  VARCHAR2(1000) := NULL;
    BEGIN
      BEGIN
        SELECT /*+INDEX (BNT IDX_VH_BTN_FOR_DATE)*/
         'Y'
          INTO LV_CHK_APP
          FROM VH_BTN BTN
         WHERE TRUNC(BTN.BTN_FOR_DATE) >= TRUNC(SYSDATE)
           AND NVL(CANCEL_YN, 'N') = 'N'
           AND DEALER_MAP_CD = p_DEALER
              --AND LOC_CD                  = P_LOC_CD
           AND BTN.SVR_EMP_CODE = P_DOC_TYPE
           AND ROWNUM = 1;
      EXCEPTION
        WHEN OTHERS THEN
          LV_CHK_APP := 'N';
      END;
      IF LV_CHK_APP = 'Y' THEN
        BEGIN
          LV_SA_MOB  := NULL;
          LV_SA_NAME := NULL;
          SELECT DECODE(SUBSTR(REPLACE(EM.MOBILE, ' ', ','),
                               1,
                               INSTR(REPLACE(EM.MOBILE, ' ', ','), ',') - 1),
                        NULL,
                        EM.MOBILE,
                        SUBSTR(REPLACE(EM.MOBILE, ' ', ','),
                               1,
                               INSTR(REPLACE(EM.MOBILE, ' ', ','), ',') - 1)) MOBILE,
                 EMP_NAME
            INTO LV_SA_MOB, LV_SA_NAME
            FROM GM_EMP EM
           WHERE DEALER_MAP_CD = P_DEALER
                --AND LOC_CD        = I.LOC_CD
             AND EMP_CD = P_DOC_TYPE;
        EXCEPTION
          WHEN OTHERS THEN
            LV_SA_MOB  := NULL;
            LV_SA_NAME := NULL;
        END;
        BEGIN
          SELECT CHANNEL
            INTO LV_CHANNEL
            FROM AM_DEALER_LOC
           WHERE DEALER_MAP_CD = p_DEALER
             AND LOC_CD = p_LOC_CD;
        EXCEPTION
          WHEN OTHERS THEN
            LV_CHANNEL := NULL;
        END;
        IF LV_CHANNEL IN ('EXC', 'NRE') THEN
          LV_QM_GM := 'QM';
        ELSE
          LV_QM_GM := 'GM';
        END IF;
        FOR I IN (SELECT EM.EMP_NAME,
                         DECODE(SUBSTR(REPLACE(EM.MOBILE, ' ', ','),
                                       1,
                                       INSTR(REPLACE(EM.MOBILE, ' ', ','),
                                             ',') - 1),
                                NULL,
                                EM.MOBILE,
                                SUBSTR(REPLACE(EM.MOBILE, ' ', ','),
                                       1,
                                       INSTR(REPLACE(EM.MOBILE, ' ', ','), ',') - 1)) MOBILE,
                         EMP_CD
                    FROM GM_EMP EM
                   WHERE DEALER_MAP_CD = p_DEALER
                     AND EM.EMP_DESG_CD = LV_QM_GM
                     AND EM.EMP_LEAVING_DATE IS NULL) LOOP

          LV_EMP_NAME := I.EMP_NAME;
          LV_EMP_MOB  := I.MOBILE;
          LV_EMP_CD   := I.EMP_CD;

          LV_SMS_DESC := LV_TEXT_FORMAT;
          LV_SMS_DESC := REPLACE(LV_SMS_DESC, '<M_NAME>', LV_EMP_NAME);
          LV_SMS_DESC := REPLACE(LV_SMS_DESC, '<SA_NAME>', LV_SA_NAME);

          IF LV_EMP_MOB IS NOT NULL THEN
            DBMS_OUTPUT.PUT_LINE('MESSAGE BODY -->' || LV_SMS_DESC ||
                                 ' TO NUMBER -->' || LV_EMP_MOB);
          END IF;
          LV_MOBILE1 := LV_EMP_MOB;
          LV_MESSAGE := LV_SMS_DESC;
          SELECT FNC_VERIF_MOBILE(LV_MOBILE1)
            INTO LV_VALID_MOBILE
            FROM DUAL;
          IF LV_MOBILE1 IS NOT NULL AND LV_EMP_NAME IS NOT NULL AND
             LV_VALID_MOBILE = 1 THEN
            BEGIN
              INSERT INTO GM_SMS_STATUS
                (UNIQUE_NUMBER,
                 PARENT_GROUP,
                 DEALER_MAP_CD,
                 LOC_CD,
                 PROCESS_CODE,
                 DOCUMENT_TYPE,
                 DOCUMENT_NO,
                 SMS_TYPE,
                 MOBILE_NO,
                 SMS_CONTENT,
                 CREATED_DATE,
                 CREATED_BY,
                 STATUS,
                 SENT_DATE,
                 REMARKS,
                 SRL_NO)
              VALUES
                (DMS_SMS_UNIQUE_NO.NEXTVAL,
                 P_PARENT_GROUP,
                 P_DEALER,
                 P_LOC_CD,
                 LV_PROCESS,
                 'BTN',
                 P_DOC_TYPE || '-' || LV_EMP_CD,
                 'T',
                 '91' || LV_MOBILE1,
                 LV_MESSAGE,
                 SYSDATE,
                 'ADMIN', ---P_CREATED_BY,
                 1,
                 NULL,
                 NULL,
                 1);
            EXCEPTION
              WHEN OTHERS THEN
                NULL;
            END;
          END IF;
        END LOOP;
      END IF;
    END;

  END IF;

  IF P_TRAN_TYPE = 'APP_CHANGE_2SA' THEN

    /**************************************
    ** P_DOC_TYPE = changed Employee code
    **************************************/
    BEGIN
      SELECT PRM.PROCESS_CODE, PRM.TEXT_FORMAT
        INTO LV_PROCESS, LV_TEXT_FORMAT
        FROM GM_DLR_SMS_MAPPING SMM, GM_PROCESS_MASTER PRM
       WHERE SMM.PARENT_GROUP = P_PARENT_GROUP
         AND SMM.DEALER_MAP_CD = P_DEALER
         AND SMM.LOC_CD = P_LOC_CD
         AND SMM.PROCESS_CODE = 'APP_CHANGE_2SA'
         AND TRUNC(SMM.CREATED_DATE) <= TRUNC(SYSDATE)
         AND NVL(SMM.DEACTIVATION_DATE, SYSDATE) >= TRUNC(SYSDATE)
         AND SMM.PROCESS_CODE = PRM.PROCESS_CODE
         AND PRM.PRINCIPAL_MAP_CD = SF_PRINCIPAL_MAP_CD(P_DEALER, P_LOC_CD)
         AND PRM.ACTIVE_FLAG = 'Y';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        LV_PROCESS     := NULL;
        LV_TEXT_FORMAT := NULL;
    END;
    IF LV_TEXT_FORMAT IS NULL OR LV_PROCESS IS NULL THEN
      RETURN;
    END IF;

    DECLARE
      LV_SA_NAME   VARCHAR2(500);
      LV_SA_MOB    VARCHAR2(500);
      LV_CUST_MOB  VARCHAR2(500);
      LV_CUST_NAME VARCHAR2(500);
      LV_EMP_CD    VARCHAR2(100);
      LV_CHK_APP   VARCHAR2(1) := 'N';
      LV_SMS_DESC  VARCHAR2(4000) := LV_TEXT_FORMAT;
    BEGIN
      FOR I IN (SELECT DEALER_MAP_CD,
                       LOC_CD,
                       TO_CHAR(TRUNC(BTN.BTN_FOR_DATE), 'DD-MON-YYYY') BTN_FOR_DATE,
                       SUBSTR(BOOKING_SLOT_TIME, 1, 2) || ':' ||
                       SUBSTR(BOOKING_SLOT_TIME, 3, 2) || ' - ' ||
                       SUBSTR(BOOKING_SLOT_TIME,
                              INSTR(BOOKING_SLOT_TIME, '-') + 1,
                              2) || ':' ||
                       SUBSTR(BOOKING_SLOT_TIME,
                              INSTR(BOOKING_SLOT_TIME, '-') + 3,
                              2) BOOKING_SLOT,
                       SVR_EMP_CODE,
                       CUST_CD,
                       BTN_NUM,
                       VIN
                  FROM VH_BTN BTN
                 WHERE PARENT_GROUP = p_PARENT_GROUP
                   AND DEALER_MAP_CD = p_DEALER
                   AND COMP_FA = p_COMP_FA
                   AND LOC_CD = p_LOC_CD
                   AND BTN_NUM = P_DOCUMENT_NUM) LOOP
        BEGIN
          LV_SA_MOB  := NULL;
          LV_SA_NAME := NULL;
          SELECT DECODE(SUBSTR(REPLACE(EM.MOBILE, ' ', ','),
                               1,
                               INSTR(REPLACE(EM.MOBILE, ' ', ','), ',') - 1),
                        NULL,
                        EM.MOBILE,
                        SUBSTR(REPLACE(EM.MOBILE, ' ', ','),
                               1,
                               INSTR(REPLACE(EM.MOBILE, ' ', ','), ',') - 1)) MOBILE,
                 EMP_NAME
            INTO LV_SA_MOB, LV_SA_NAME
            FROM GM_EMP EM
           WHERE DEALER_MAP_CD = I.DEALER_MAP_CD
                --AND LOC_CD        = I.LOC_CD
             AND EMP_CD = P_DOC_TYPE;
        EXCEPTION
          WHEN OTHERS THEN
            LV_SA_MOB  := NULL;
            LV_SA_NAME := NULL;
        END;
        BEGIN
          SELECT CUST_NAME,
                 NVL(SF_GET_CAR_USER_PHONE(I.VIN, CIN.CUST_CD),
                     DECODE(SUBSTR(CIN.MOBILE_PHONE, 1, 1),
                            '0',
                            SUBSTR(CIN.MOBILE_PHONE, 2),
                            CIN.MOBILE_PHONE))
            INTO LV_CUST_NAME, LV_CUST_MOB
            FROM GM_CIN CIN
           WHERE CUST_CD = I.CUST_CD
             AND PRINCIPAL_MAP_CD = 1;
        EXCEPTION
          WHEN OTHERS THEN
            LV_CUST_NAME := NULL;
            LV_CUST_MOB  := NULL;
        END;
        LV_SMS_DESC := REPLACE(LV_SMS_DESC, '<SA_NAME>', LV_SA_NAME);
        LV_SMS_DESC := REPLACE(LV_SMS_DESC, '<DOC_NUM>', I.BTN_NUM);
        LV_SMS_DESC := REPLACE(LV_SMS_DESC, '<CUST_NAME>', LV_CUST_NAME);
        LV_SMS_DESC := REPLACE(LV_SMS_DESC, '<DOC_DATE>', I.BTN_FOR_DATE);
        LV_SMS_DESC := REPLACE(LV_SMS_DESC, '<TIME_SLOT>', I.BOOKING_SLOT);
        LV_SMS_DESC := REPLACE(LV_SMS_DESC, '<CUST_MOBILE_NO>', LV_CUST_MOB);
        DBMS_OUTPUT.PUT_LINE('MESSAGE BODY -->' || LV_SMS_DESC ||
                             ' TO NUMBER -->' || LV_SA_MOB);
        LV_MOBILE1 := LV_SA_MOB;
        LV_MESSAGE := LV_SMS_DESC;
        SELECT FNC_VERIF_MOBILE(LV_MOBILE1) INTO LV_VALID_MOBILE FROM DUAL;
        IF LV_MOBILE1 IS NOT NULL AND LV_SA_NAME IS NOT NULL AND
           LV_CUST_NAME IS NOT NULL AND LV_VALID_MOBILE = 1 THEN
          BEGIN
            INSERT INTO GM_SMS_STATUS
              (UNIQUE_NUMBER,
               PARENT_GROUP,
               DEALER_MAP_CD,
               LOC_CD,
               PROCESS_CODE,
               DOCUMENT_TYPE,
               DOCUMENT_NO,
               SMS_TYPE,
               MOBILE_NO,
               SMS_CONTENT,
               CREATED_DATE,
               CREATED_BY,
               STATUS,
               SENT_DATE,
               REMARKS,
               SRL_NO)
            VALUES
              (DMS_SMS_UNIQUE_NO.NEXTVAL,
               P_PARENT_GROUP,
               P_DEALER,
               P_LOC_CD,
               LV_PROCESS,
               'BTN', --P_DOC_TYPE,
               I.BTN_NUM, --P_DOCUMENT_NUM,
               'T',
               '91' || LV_MOBILE1,
               LV_MESSAGE,
               SYSDATE,
               'ADMIN', ---P_CREATED_BY,
               1,
               NULL,
               NULL,
               1);
          EXCEPTION
            WHEN OTHERS THEN
              NULL;
          END;
        END IF;
      END LOOP;
    END;
  END IF;

  IF P_TRAN_TYPE = 'APP_CHANGE_2CUS' THEN

    /**************************************
    ** P_DOC_TYPE = changed Employee code
    **************************************/
    BEGIN
      SELECT PRM.PROCESS_CODE, PRM.TEXT_FORMAT
        INTO LV_PROCESS, LV_TEXT_FORMAT
        FROM GM_DLR_SMS_MAPPING SMM, GM_PROCESS_MASTER PRM
       WHERE SMM.PARENT_GROUP = P_PARENT_GROUP
         AND SMM.DEALER_MAP_CD = P_DEALER
         AND SMM.LOC_CD = P_LOC_CD
         AND SMM.PROCESS_CODE = 'APP_CHANGE_2CUS'
         AND TRUNC(SMM.CREATED_DATE) <= TRUNC(SYSDATE)
         AND NVL(SMM.DEACTIVATION_DATE, SYSDATE) >= TRUNC(SYSDATE)
         AND SMM.PROCESS_CODE = PRM.PROCESS_CODE
         AND PRM.PRINCIPAL_MAP_CD = SF_PRINCIPAL_MAP_CD(P_DEALER, P_LOC_CD)
         AND PRM.ACTIVE_FLAG = 'Y';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        LV_PROCESS     := NULL;
        LV_TEXT_FORMAT := NULL;
    END;
    IF LV_TEXT_FORMAT IS NULL OR LV_PROCESS IS NULL THEN
      RETURN;
    END IF;

    DECLARE
      LV_DLR_NAME  VARCHAR2(500);
      LV_TIME_SLOT VARCHAR2(500);
      LV_SA_NAME   VARCHAR2(500);
      LV_SA_MOB    VARCHAR2(500);
      LV_CUST_MOB  VARCHAR2(500);
      LV_SMS_DESC  VARCHAR2(4000) := LV_TEXT_FORMAT;
    BEGIN
      FOR I IN (SELECT /*+INDEX (BNT IDX_VH_BTN_FOR_DATE)*/
                 LOC.DEALER_NAME,
                 LOC.LOC_DESC,
                 LOC.DEALER_MAP_CD,
                 LOC.LOC_CD,
                 TO_CHAR(TRUNC(BTN.BTN_FOR_DATE), 'DD-MON-YYYY') BTN_FOR_DATE,
                 SUBSTR(BOOKING_SLOT_TIME, 1, 2) || ':' ||
                 SUBSTR(BOOKING_SLOT_TIME, 3, 2) || ' - ' ||
                 SUBSTR(BOOKING_SLOT_TIME,
                        INSTR(BOOKING_SLOT_TIME, '-') + 1,
                        2) || ':' || SUBSTR(BOOKING_SLOT_TIME,
                                            INSTR(BOOKING_SLOT_TIME, '-') + 3,
                                            2) BOOKING_SLOT,
                 SVR_EMP_CODE,
                 CUST_CD,
                 VIN,
                 BTN_NUM,
                 (SELECT LIST_DESC
                    FROM AM_LIST
                   WHERE LIST_NAME = 'RCATEG_CD'
                     AND PRINCIPAL_MAP_CD = 1
                     AND LIST_CODE = BTN.RCATEG_CD
                     AND ROWNUM = 1) RCATEG_DESC
                  FROM VH_BTN BTN, AM_DEALER_LOC LOC
                 WHERE BTN.PARENT_GROUP = p_PARENT_GROUP
                   AND BTN.DEALER_MAP_CD = p_DEALER
                   AND BTN.COMP_FA = p_COMP_FA
                   AND BTN.LOC_CD = p_LOC_CD
                   AND BTN.BTN_NUM = P_DOCUMENT_NUM
                   AND NVL(BTN.CONFIRMED_YN, 'N') = 'N'
                   AND NVL(BTN.CANCEL_YN, 'N') = 'N'
                   AND LOC.DEALER_MAP_CD = BTN.DEALER_MAP_CD
                   AND LOC.LOC_CD = BTN.LOC_CD
                   AND LOC.PRINCIPAL_MAP_CD = 1
                   AND BOOKING_SLOT IS NOT NULL
                   AND ROWNUM = 1) LOOP
        BEGIN
          LV_SA_MOB  := NULL;
          LV_SA_NAME := NULL;
          SELECT DECODE(SUBSTR(REPLACE(EM.MOBILE, ' ', ','),
                               1,
                               INSTR(REPLACE(EM.MOBILE, ' ', ','), ',') - 1),
                        NULL,
                        EM.MOBILE,
                        SUBSTR(REPLACE(EM.MOBILE, ' ', ','),
                               1,
                               INSTR(REPLACE(EM.MOBILE, ' ', ','), ',') - 1)) MOBILE,
                 EMP_NAME
            INTO LV_SA_MOB, LV_SA_NAME
            FROM GM_EMP EM
           WHERE DEALER_MAP_CD = I.DEALER_MAP_CD
                --AND LOC_CD        = I.LOC_CD
             AND EMP_CD = I.SVR_EMP_CODE;
        EXCEPTION
          WHEN OTHERS THEN
            LV_SA_MOB  := NULL;
            LV_SA_NAME := NULL;
        END;

        BEGIN
          SELECT NVL(SF_GET_CAR_USER_PHONE(I.VIN, CIN.CUST_CD),
                     DECODE(SUBSTR(CIN.MOBILE_PHONE, 1, 1),
                            '0',
                            SUBSTR(CIN.MOBILE_PHONE, 2),
                            CIN.MOBILE_PHONE))
            INTO --LV_CUST_NAME,
                 LV_CUST_MOB
            FROM GM_CIN CIN
           WHERE CUST_CD = I.CUST_CD
             AND PRINCIPAL_MAP_CD = 1;
        EXCEPTION
          WHEN OTHERS THEN
            LV_CUST_MOB := NULL;
        END;

        LV_SMS_DESC := REPLACE(LV_SMS_DESC,
                               '<WORKSHOP_NAME>',
                               I.DEALER_NAME);
        LV_SMS_DESC := REPLACE(LV_SMS_DESC, '<BTN_DATE>', I.BTN_FOR_DATE);
        LV_SMS_DESC := REPLACE(LV_SMS_DESC, '<TIME_SLOT>', I.BOOKING_SLOT);
        LV_SMS_DESC := REPLACE(LV_SMS_DESC, '<SA_NAME>', LV_SA_NAME);
        LV_SMS_DESC := REPLACE(LV_SMS_DESC, '<MOBILE_NO>', LV_SA_MOB);

        LV_SMS_DESC := REPLACE(LV_SMS_DESC, '<LOC_DESC>', I.LOC_DESC);
        LV_SMS_DESC := REPLACE(LV_SMS_DESC, '<BTN_NUM>', I.BTN_NUM);
        LV_SMS_DESC := REPLACE(LV_SMS_DESC, '<RCATEG_CD>', I.RCATEG_DESC);
        DBMS_OUTPUT.PUT_LINE('MESSAGE BODY -->' || LV_SMS_DESC ||
                             ' TO NUMBER -->' || LV_CUST_MOB);
        LV_MOBILE1 := LV_CUST_MOB;
        LV_MESSAGE := LV_SMS_DESC;
        SELECT FNC_VERIF_MOBILE(LV_MOBILE1) INTO LV_VALID_MOBILE FROM DUAL;
        IF LV_MOBILE1 IS NOT NULL AND LV_SA_NAME IS NOT NULL AND
          --LV_CUST_NAME IS NOT NULL AND
           LV_VALID_MOBILE = 1 THEN
          BEGIN
            INSERT INTO GM_SMS_STATUS
              (UNIQUE_NUMBER,
               PARENT_GROUP,
               DEALER_MAP_CD,
               LOC_CD,
               PROCESS_CODE,
               DOCUMENT_TYPE,
               DOCUMENT_NO,
               SMS_TYPE,
               MOBILE_NO,
               SMS_CONTENT,
               CREATED_DATE,
               CREATED_BY,
               STATUS,
               SENT_DATE,
               REMARKS,
               SRL_NO)
            VALUES
              (DMS_SMS_UNIQUE_NO.NEXTVAL,
               P_PARENT_GROUP,
               P_DEALER,
               P_LOC_CD,
               LV_PROCESS,
               'BTN', --P_DOC_TYPE,
               I.BTN_NUM, --P_DOCUMENT_NUM,
               'T',
               '91' || LV_MOBILE1,
               LV_MESSAGE,
               SYSDATE,
               'ADMIN', ---P_CREATED_BY,
               1,
               NULL,
               NULL,
               1);
          EXCEPTION
            WHEN OTHERS THEN
              NULL;
          END;
        END IF;
      END LOOP;
    END;
  END IF;

  -- 'LAST_FP_JC' condition added by shailesh on 14.02.2020 against DMSSERV-13690 --
  IF NVL(LV_PROCESS, '@') = 'LAST_FP_JC' AND LV_TEXT_FORMAT IS NOT NULL THEN
    BEGIN

      BEGIN
        SELECT RO.REG_NUM,
               loc.tsms_id,
               loc.tsmn_id,
               (SELECT EM.MOBILE
                  FROM GM_EMP EM
                 WHERE EM.DEALER_MAP_CD = RO.DEALER_MAP_CD
                   AND EM.EMP_CD = RO.SVC_EMP_CODE),
               (SELECT EM.MOBILE
                  FROM GM_EMP EM
                 WHERE EM.DEALER_MAP_CD = RO.DEALER_MAP_CD
                   AND EM.LOC_CD = RO.LOC_CD
                   AND EM.EMP_DESG_CD = 'WM'
                   AND MOBILE IS NOT NULL
                      -- And em.emp_leaving_Date is null--v_1
                   AND NVL(EM.EMP_LEAVING_DATE, SYSDATE + 1) >= SYSDATE --v_1
                   AND EM.EMP_APPROVE = 'A'
                   AND EM.CREATED_DATE =
                       (SELECT MAX(CREATED_DATE)
                          FROM GM_EMP EP
                         WHERE EP.DEALER_MAP_CD = RO.DEALER_MAP_CD
                           AND EP.LOC_CD = RO.LOC_CD
                           AND EP.EMP_DESG_CD = 'WM'
                           AND NVL(EP.EMP_LEAVING_DATE, SYSDATE + 1) >=
                               SYSDATE
                           AND EP.EMP_APPROVE = 'A'
                           AND EP.MOBILE IS NOT NULL)),
               DECODE(DECODE(sf_get_model_channel(LOC.PRINCIPAL_MAP_CD,
                                                  ro.vin),
                             'NRC',
                             'NRM',
                             'NRE',
                             'EXC',
                             sf_get_model_channel(LOC.PRINCIPAL_MAP_CD,
                                                  ro.vin)),
                      'NRM',
                      (SELECT MOBILE
                         FROM VM_EMAIL_DTL
                        WHERE STAFF_ID = LOC.TSMS_ID
                          AND MOBILE IS not NULL
                          AND active_yn = 'Y'
                          AND ROWNUM = 1),
                      (SELECT MOBILE
                         FROM VM_EMAIL_DTL
                        WHERE STAFF_ID = LOC.TSMN_ID
                          AND MOBILE IS not NULL
                          AND active_yn = 'Y'
                          AND ROWNUM = 1)),
               DECODE(DECODE(sf_get_model_channel(LOC.PRINCIPAL_MAP_CD,
                                                  ro.vin),
                             'NRC',
                             'NRM',
                             'NRE',
                             'EXC',
                             sf_get_model_channel(LOC.PRINCIPAL_MAP_CD,
                                                  ro.vin)),
                      'NRM',
                      (SELECT MOBILE
                         FROM vm_email_dtl xr
                        WHERE xr.role = 'RSM'
                          AND xr.active_yn = 'Y'
                          AND region in
                              (SELECT region
                                 FROM vm_email_dtl xt
                                WHERE xt.role = 'TSM'
                                  AND xt.active_yn = 'Y'
                                  and UPPER(xt.staff_id) = UPPER(LOC.TSMS_ID))
                          AND ROWNUM = 1),
                      (SELECT MOBILE
                         FROM vm_email_dtl xr
                        WHERE xr.role = 'RSM'
                          AND xr.active_yn = 'Y'
                          AND region in
                              (SELECT region
                                 FROM vm_email_dtl xt
                                WHERE xt.role = 'TSM'
                                  AND xt.active_yn = 'Y'
                                  and UPPER(xt.staff_id) = UPPER(LOC.TSMN_ID))
                          AND ROWNUM = 1))
          INTO LV_REG,
               LV_TSMS_ID,
               LV_TSMN_ID,
               LV_RO_SMOB1, --Sa
               LV_RO_SMOB2, --wm
               LV_RO_SMOB3, --TSM
               LV_RO_SMOB4 --RSM
          FROM VH_RO RO, GM_CIN CI, AM_DEALER_LOC LOC
         WHERE RO.CUST_CD = CI.CUST_CD
           AND RO.PARENT_GROUP = P_PARENT_GROUP
           AND RO.DEALER_MAP_CD = P_DEALER
           AND RO.LOC_CD = P_LOC_CD
           AND RO.COMP_FA = P_COMP_FA
           AND RO.RO_NUM = P_DOCUMENT_NUM
           AND CI.PRINCIPAL_MAP_CD = LOC.PRINCIPAL_MAP_CD
           AND RO.PARENT_GROUP = LOC.PARENT_GROUP
           AND RO.DEALER_MAP_CD = LOC.DEALER_MAP_CD
           AND RO.LOC_CD = LOC.LOC_CD;

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          LV_ERROR_CD := 1;
        WHEN OTHERS THEN
          LV_RO_NUM := NULL;

      END;

      IF NVL(LV_ERROR_CD, 0) != 1 THEN
        SELECT REPLACE(LV_TEXT_FORMAT, '<reg_num>', LV_REG)
          INTO LV_MESSAGE
          FROM DUAL;
        -- SA
        SELECT FNC_VERIF_MOBILE(LV_RO_SMOB1)
          INTO LV_VALID_MOBILE
          FROM DUAL; --CHANGES DONE BY BHAWANA AGAINST DMSSERV-13188 ON8-APR-2015
        IF LV_VALID_MOBILE = 1 THEN
          LV_SRL := LV_SRL + 1;
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             '91' || LV_RO_SMOB1,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             1,
             NULL,
             NULL,
             LV_SRL);

        ELSE
          LV_SRL := LV_SRL + 1;
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             LV_RO_SMOB1,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             8,
             NULL,
             'DATA NOT CORRECT',
             LV_SRL);

        END IF;

        -- WM
        SELECT FNC_VERIF_MOBILE(LV_RO_SMOB2)
          INTO LV_VALID_MOBILE
          FROM DUAL; --CHANGES DONE BY BHAWANA AGAINST DMSSERV-13188 ON8-APR-2015
        IF LV_VALID_MOBILE = 1 THEN
          LV_SRL := LV_SRL + 1;
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             '91' || LV_RO_SMOB2,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             1,
             NULL,
             NULL,
             LV_SRL);

        ELSE
          LV_SRL := LV_SRL + 1;
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             LV_RO_SMOB2,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             8,
             NULL,
             'DATA NOT CORRECT',
             LV_SRL);

        END IF;

        -- TSM
        SELECT FNC_VERIF_MOBILE(LV_RO_SMOB3)
          INTO LV_VALID_MOBILE
          FROM DUAL; --CHANGES DONE BY BHAWANA AGAINST DMSSERV-13188 ON8-APR-2015
        IF LV_VALID_MOBILE = 1 THEN
          LV_SRL := LV_SRL + 1;
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             '91' || LV_RO_SMOB3,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             1,
             NULL,
             NULL,
             LV_SRL);

        ELSE
          LV_SRL := LV_SRL + 1;
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             LV_RO_SMOB3,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             8,
             NULL,
             'DATA NOT CORRECT',
             LV_SRL);

        END IF;

        -- RSM
        SELECT FNC_VERIF_MOBILE(LV_RO_SMOB4)
          INTO LV_VALID_MOBILE
          FROM DUAL; --CHANGES DONE BY BHAWANA AGAINST DMSSERV-13188 ON8-APR-2015
        IF LV_VALID_MOBILE = 1 THEN
          LV_SRL := LV_SRL + 1;
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             '91' || LV_RO_SMOB4,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             1,
             NULL,
             NULL,
             LV_SRL);

        ELSE
          LV_SRL := LV_SRL + 1;
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             LV_RO_SMOB4,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             8,
             NULL,
             'DATA NOT CORRECT',
             LV_SRL);

        END IF;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    COMMIT;
  END IF;

/*Started by Kanav on 28-Jan-2021 for DMSSAL-12766*/

  IF NVL(LV_PROCESS, '@') = 'DMS_POC_BOOKING' AND
     LV_TEXT_FORMAT IS NOT NULL THEN

    LV_BOOKING_NUM  := NULL;
    LV_BOOKING_DATE := NULL;
    LV_DEALER_NAME  := NULL;
    LV_MOBILE5      := NULL;
    LV_CITY         := NULL;
    BEGIN
      BEGIN
        SELECT SH.ORDER_NUM,
               SH.ORDER_DATE,
               SUBSTR(LOC.DEALER_NAME, 1, 30) DEALER_NAME,
               sh.mobile,

               (select for_desc
                  from GM_FOR am1
                 where am1.for_cd = loc.for_cd
                   and am1.principal_map_cd = loc.PRINCIPAL_MAP_CD) city
          INTO LV_BOOKING_NUM,
               LV_BOOKING_DATE,
               LV_DEALER_NAME,
               LV_MOBILE5,
               LV_CITY
          FROM SH_POC_ORDBOOK SH, AM_DEALER_LOC LOC
         WHERE SH.PARENT_GROUP = P_PARENT_GROUP
           AND SH.DEALER_MAP_CD = P_DEALER
           AND SH.LOC_CD = P_LOC_CD
           AND SH.COMP_FA = P_COMP_FA
           AND SH.ORDER_NUM = P_DOCUMENT_NUM
           AND LOC.DEALER_MAP_CD = SH.DEALER_MAP_CD
           AND LOC.LOC_CD = SH.LOC_CD
           AND LOC.PARENT_GROUP = SH.PARENT_GROUP;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          LV_ERROR_CD := 1;
        WHEN OTHERS THEN
          LV_BOOKING_NUM  := NULL;
          LV_BOOKING_DATE := NULL;
          LV_DEALER_NAME  := NULL;
          LV_MOBILE5      := NULL;
          LV_CITY         := NULL;
      END;

      IF NVL(LV_ERROR_CD, 0) != 1 THEN

        SELECT REPLACE(REPLACE(REPLACE(REPLACE(LV_TEXT_FORMAT,
                                               '<Booking ID>',
                                               LV_BOOKING_NUM),
                                       '<Booking Date>',
                                       LV_BOOKING_DATE),
                               '<Dealershp name>',
                               LV_DEALER_NAME),
                       '<City>',
                       LV_CITY)
          INTO LV_MESSAGE
          FROM DUAL;

        IF LV_MOBILE5 IS NOT NULL AND LV_BOOKING_NUM IS NOT NULL AND
           LV_DEALER_NAME IS NOT NULL THEN
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             '91' || LV_MOBILE5,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             1,
             NULL,
             NULL,
             1);

        ELSE
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             LV_MOBILE5,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             8,
             NULL,
             'DATA NOT CORRECT',
             1);

        END IF;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    COMMIT;
  END IF;

  IF NVL(LV_PROCESS, '@') = 'DMS_POC_DEALER1' AND LV_TEXT_FORMAT IS NOT NULL THEN

    LV_CCM          := NULL;
    LV_GM           := NULL;
    LV_MOBILE5      := NULL;

    BEGIN
      BEGIN
        SELECT SH.POC_DSE_CD, sh.mobile
          INTO LV_POC_DSE_CD, LV_MOBILE5
          FROM SH_POC_ORDBOOK SH, AM_DEALER_LOC LOC
         WHERE SH.PARENT_GROUP = P_PARENT_GROUP
           AND SH.DEALER_MAP_CD = P_DEALER
           AND SH.LOC_CD = P_LOC_CD
           AND SH.COMP_FA = P_COMP_FA
           AND SH.ORDER_NUM = P_DOCUMENT_NUM
           AND LOC.DEALER_MAP_CD = SH.DEALER_MAP_CD
           AND LOC.LOC_CD = SH.LOC_CD
           AND LOC.PARENT_GROUP = SH.PARENT_GROUP;

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          LV_ERROR_CD := 1;
        WHEN OTHERS THEN
          LV_POC_DSE_CD   := NULL;
          LV_MOBILE5      := NULL;
      END;

      BEGIN
        SELECT GE.EMP_NAME, GE.MOBILE
          INTO LV_TESM, LV_TESM_MOB
          FROM GM_EMP GE
         WHERE DEALER_MAP_CD = 99999
           AND EMP_cD IN (SELECT AL.TESM_ID
                            FROM AM_DEALER_LOC AL
                           WHERE DEALER_MAP_CD = P_DEALER
                             AND LOC_CD = P_LOC_CD
                             AND PARENT_GROUP = P_PARENT_GROUP)
           AND NVL(EMP_LEAVING_DATE, SYSDATE) >= SYSDATE
           AND EMP_APPROVE = 'A';
      EXCEPTION
        WHEN OTHERS THEN
          LV_TESM     := ' ';
          LV_TESM_MOB := ' ';
      END;

      IF NVL(LV_ERROR_CD, 0) != 1 THEN

        SELECT REPLACE(REPLACE(LV_TEXT_FORMAT,
                               '<Customer Care Mgr>',
                               LV_TESM),
                       '<TESM_MOB>',
                       LV_TESM_MOB)
          INTO LV_MESSAGE
          FROM DUAL;

        IF LV_POC_DSE_CD IS NOT NULL THEN
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             '91' || LV_MOBILE5,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             1,
             NULL,
             NULL,
             1);

        ELSE
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             LV_MOBILE5,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             8,
             NULL,
             'DATA NOT CORRECT',
             1);

        END IF;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    COMMIT;
  END IF;

  IF NVL(LV_PROCESS, '@') = 'DMS_POC_DEALER2' AND LV_TEXT_FORMAT IS NOT NULL THEN

    LV_CCM          := NULL;
    LV_GM           := NULL;
    LV_MOBILE5      := NULL;

    BEGIN
      BEGIN
        SELECT SH.POC_DSE_CD, sh.mobile
          INTO LV_POC_DSE_CD, LV_MOBILE5
          FROM SH_POC_ORDBOOK SH, AM_DEALER_LOC LOC
         WHERE SH.PARENT_GROUP = P_PARENT_GROUP
           AND SH.DEALER_MAP_CD = P_DEALER
           AND SH.LOC_CD = P_LOC_CD
           AND SH.COMP_FA = P_COMP_FA
           AND SH.ORDER_NUM = P_DOCUMENT_NUM
           AND LOC.DEALER_MAP_CD = SH.DEALER_MAP_CD
           AND LOC.LOC_CD = SH.LOC_CD
           AND LOC.PARENT_GROUP = SH.PARENT_GROUP;

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          LV_ERROR_CD := 1;
        WHEN OTHERS THEN
          LV_CCM          := NULL;
          LV_GM           := NULL;
          LV_MOBILE5      := NULL;
      END;

      BEGIN
        SELECT EMP.EMP_NAME, EMP.MOBILE
          INTO LV_CCM_NAME, LV_CCM_MOB
          FROM GM_EMP EMP
         WHERE EMP.DEALER_MAP_CD = P_DEALER
           AND EMP.LOC_CD = P_LOC_CD
           AND NVL(EMP.EMP_LEAVING_DATE, SYSDATE) >= SYSDATE
           AND EMP.EMP_APPROVE = 'A'
           and EMP.EMP_DESG_CD in ('TCM')
           AND ROWNUM = 1;
      EXCEPTION
        WHEN OTHERS THEN
          LV_CCM_NAME  := ' ';
          LV_CCM_MOB   := ' ';
      END;

      BEGIN
        SELECT GE.EMP_NAME, GE.MOBILE
          INTO LV_TESM, LV_TESM_MOB
          FROM GM_EMP GE
         WHERE DEALER_MAP_CD = 99999
           AND EMP_CD IN (SELECT AL.TESM_ID
                            FROM AM_DEALER_LOC AL
                           WHERE DEALER_MAP_CD = P_DEALER
                             AND LOC_CD = P_LOC_CD
                             AND PARENT_GROUP = P_PARENT_GROUP)
           AND NVL(EMP_LEAVING_DATE, SYSDATE) >= SYSDATE
           AND EMP_APPROVE = 'A';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          LV_TESM     := ' ';
          LV_TESM_MOB := ' ';
      END;

      IF NVL(LV_ERROR_CD, 0) != 1 THEN

        SELECT REPLACE(REPLACE(REPLACE(REPLACE(LV_TEXT_FORMAT,
                                               '<Customer Care Mgr>',
                                               LV_TESM),
                                       '<TESM_MOB>',
                                       LV_TESM_MOB),
                               '<CCM_MOB>',
                               LV_CCM_MOB),
                       '<CCM_NAME>',
                       LV_CCM_NAME)
          INTO LV_MESSAGE
          FROM DUAL;

        IF LV_POC_DSE_CD IS NOT NULL THEN
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             '91' || LV_MOBILE5,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             1,
             NULL,
             NULL,
             1);

        ELSE
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             LV_MOBILE5,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             8,
             NULL,
             'DATA NOT CORRECT',
             1);

        END IF;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    COMMIT;
  END IF;

  IF NVL(LV_PROCESS, '@') = 'DMS_POC_DEALER3' AND LV_TEXT_FORMAT IS NOT NULL THEN

    LV_CCM          := NULL;
    LV_GM           := NULL;
    LV_MOBILE5      := NULL;

    BEGIN
      BEGIN
        SELECT SH.POC_DSE_CD, sh.mobile
          INTO LV_POC_DSE_CD, LV_MOBILE5
          FROM SH_POC_ORDBOOK SH, AM_DEALER_LOC LOC
         WHERE SH.PARENT_GROUP = P_PARENT_GROUP
           AND SH.DEALER_MAP_CD = P_DEALER
           AND SH.LOC_CD = P_LOC_CD
           AND SH.COMP_FA = P_COMP_FA
           AND SH.ORDER_NUM = P_DOCUMENT_NUM
           AND LOC.DEALER_MAP_CD = SH.DEALER_MAP_CD
           AND LOC.LOC_CD = SH.LOC_CD
           AND LOC.PARENT_GROUP = SH.PARENT_GROUP;

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          LV_ERROR_CD := 1;
        WHEN OTHERS THEN
          LV_CCM          := NULL;
          LV_GM           := NULL;
          LV_MOBILE5      := NULL;
      END;

      BEGIN
        SELECT EMP.EMP_NAME, EMP.MOBILE
          INTO LV_CCM_NAME, LV_CCM_MOB
          FROM GM_EMP EMP
         WHERE EMP.DEALER_MAP_CD = P_DEALER
           AND EMP.LOC_CD = P_LOC_CD
           AND NVL(EMP.EMP_LEAVING_DATE, SYSDATE) >= SYSDATE
           AND EMP.EMP_APPROVE = 'A'
           and EMP.EMP_DESG_CD in ('TCM')
           AND ROWNUM = 1;
      EXCEPTION
        WHEN OTHERS THEN
          LV_CCM_NAME  := ' ';
          LV_CCM_MOB   := ' ';
      END;

      BEGIN
        SELECT GE.GM_EMP_CD, GE.Gm_Dealer_Map_Cd
          INTO LV_GM_EMP_CD, LV_Gm_Dealer_Map_Cd
          FROM GD_DEALER_MAPPING GE
         WHERE DEALER_MAP_CD = P_DEALER
           AND LOC_CD = P_LOC_CD
           AND PARENT_GROUP = P_PARENT_GROUP;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          LV_GM_EMP_CD        := '';
          LV_Gm_Dealer_Map_Cd := '';
      END;

      BEGIN
        SELECT GE.EMP_NAME, GE.MOBILE
          INTO LV_GM, LV_GM_MOB
          FROM GM_EMP GE
         WHERE DEALER_MAP_CD = LV_Gm_Dealer_Map_Cd
           AND EMP_cD = LV_GM_EMP_CD
           AND NVL(EMP_LEAVING_DATE,SYSDATE) >= SYSDATE
           AND EMP_APPROVE = 'A';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          LV_GM     := ' ';
          LV_GM_MOB := ' ';
      END;

      BEGIN
        SELECT GE.EMP_NAME, GE.MOBILE
          INTO LV_TESM, LV_TESM_MOB
          FROM GM_EMP GE
         WHERE DEALER_MAP_CD = 99999
           AND EMP_CD IN (SELECT AL.TESM_ID
                            FROM AM_DEALER_LOC AL
                           WHERE DEALER_MAP_CD = P_DEALER
                             AND LOC_CD = P_LOC_CD
                             AND PARENT_GROUP = P_PARENT_GROUP)
           AND NVL(EMP_LEAVING_DATE, SYSDATE) >= SYSDATE
           AND EMP_APPROVE = 'A';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          LV_TESM     := ' ';
          LV_TESM_MOB := ' ';
      END;

      IF NVL(LV_ERROR_CD, 0) != 1 THEN

        SELECT replace(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LV_TEXT_FORMAT,
                                                               '<Customer Care Mgr>',
                                                               LV_TESM),
                                                       '<TESM_MOB>',
                                                       LV_TESM_MOB),
                                               '<CCM_MOB>',
                                               LV_CCM_MOB),
                                       '<CCM_NAME>',
                                       LV_CCM_NAME),
                               '<GM_MOB>',
                               LV_GM_MOB),
                       '<GM_NAME>',
                       LV_GM)
          INTO LV_MESSAGE
          FROM DUAL;

        IF LV_POC_DSE_CD IS NOT NULL THEN
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             '91' || LV_MOBILE5,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             1,
             NULL,
             NULL,
             1);

        ELSE
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             LV_MOBILE5,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             8,
             NULL,
             'DATA NOT CORRECT',
             1);

        END IF;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    COMMIT;
  END IF;

  IF NVL(LV_PROCESS, '@') = 'DMS_POC_DEALER4' AND LV_TEXT_FORMAT IS NOT NULL THEN

    LV_CCM          := NULL;
    LV_GM           := NULL;
    LV_MOBILE5      := NULL;

    BEGIN
      BEGIN
        SELECT SH.POC_DSE_CD, sh.mobile
          INTO LV_POC_DSE_CD, LV_MOBILE5
          FROM SH_POC_ORDBOOK SH, AM_DEALER_LOC LOC
         WHERE SH.PARENT_GROUP = P_PARENT_GROUP
           AND SH.DEALER_MAP_CD = P_DEALER
           AND SH.LOC_CD = P_LOC_CD
           AND SH.COMP_FA = P_COMP_FA
           AND SH.ORDER_NUM = P_DOCUMENT_NUM
           AND LOC.DEALER_MAP_CD = SH.DEALER_MAP_CD
           AND LOC.LOC_CD = SH.LOC_CD
           AND LOC.PARENT_GROUP = SH.PARENT_GROUP;

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          LV_ERROR_CD := 1;
        WHEN OTHERS THEN
          LV_CCM          := NULL;
          LV_GM           := NULL;
          LV_MOBILE5      := NULL;
      END;

      BEGIN
        SELECT GE.GM_EMP_CD, GE.Gm_Dealer_Map_Cd
          INTO LV_GM_EMP_CD, LV_Gm_Dealer_Map_Cd
          FROM GD_DEALER_MAPPING GE
         WHERE DEALER_MAP_CD = P_DEALER
           AND LOC_CD = P_LOC_CD
           AND PARENT_GROUP = P_PARENT_GROUP;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          LV_GM_EMP_CD        := '';
          LV_Gm_Dealer_Map_Cd := '';
      END;

      BEGIN
        SELECT GE.EMP_NAME, GE.MOBILE
          INTO LV_GM, LV_GM_MOB
          FROM GM_EMP GE
         WHERE DEALER_MAP_CD = LV_Gm_Dealer_Map_Cd
           AND EMP_cD = LV_GM_EMP_CD
           AND NVL(EMP_LEAVING_DATE,SYSDATE) >= SYSDATE
           AND EMP_APPROVE = 'A';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          LV_GM     := ' ';
          LV_GM_MOB := ' ';
      END;

      BEGIN
        SELECT GE.EMP_NAME, GE.MOBILE
          INTO LV_TESM, LV_TESM_MOB
          FROM GM_EMP GE
         WHERE DEALER_MAP_CD = 99999
           AND EMP_CD IN (SELECT AL.TESM_ID
                            FROM AM_DEALER_LOC AL
                           WHERE DEALER_MAP_CD = P_DEALER
                             AND LOC_CD = P_LOC_CD
                             AND PARENT_GROUP = P_PARENT_GROUP)
           AND NVL(EMP_LEAVING_DATE, SYSDATE) >= SYSDATE
           AND EMP_APPROVE = 'A';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          LV_TESM     := ' ';
          LV_TESM_MOB := ' ';
      END;

      IF NVL(LV_ERROR_CD, 0) != 1 THEN

        SELECT replace(REPLACE(REPLACE(REPLACE(LV_TEXT_FORMAT,
                                               '<Customer Care Mgr>',
                                               LV_TESM),
                                       '<TESM_MOB>',
                                       LV_TESM_MOB),
                               '<GM_MOB>',
                               LV_GM_MOB),
                       '<GM_NAME>',
                       LV_GM)
          INTO LV_MESSAGE
          FROM DUAL;

        IF LV_POC_DSE_CD IS NOT NULL THEN
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             '91' || LV_MOBILE5,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             1,
             NULL,
             NULL,
             1);

        ELSE
          INSERT INTO GM_SMS_STATUS
            (UNIQUE_NUMBER,
             PARENT_GROUP,
             DEALER_MAP_CD,
             LOC_CD,
             PROCESS_CODE,
             DOCUMENT_TYPE,
             DOCUMENT_NO,
             SMS_TYPE,
             MOBILE_NO,
             SMS_CONTENT,
             CREATED_DATE,
             CREATED_BY,
             STATUS,
             SENT_DATE,
             REMARKS,
             SRL_NO)
          VALUES
            (DMS_SMS_UNIQUE_NO.NEXTVAL,
             P_PARENT_GROUP,
             P_DEALER,
             P_LOC_CD,
             LV_PROCESS,
             P_DOC_TYPE,
             P_DOCUMENT_NUM,
             'T',
             LV_MOBILE5,
             LV_MESSAGE,
             SYSDATE,
             P_CREATED_BY,
             8,
             NULL,
             'DATA NOT CORRECT',
             1);

        END IF;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    COMMIT;
  END IF;
/*Ended by Kanav on 28-Jan-2021 for DMSSAL-12766*/

END;

```

#### SP-057 - SP_PUSH_MCPC_FDI_DATA

**Invoked From:**

- vt_amc_cncl_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

Cancellation Details (N/A / CN_MAIN)

---

**Purpose**

Pushes MCP cancellation financial data to the FDI (Financial Data Interface) system for a completed AMC cancellation transaction. Retrieves the cancellation details from the database, prepares FDI charge line structures, and calls the FDI push procedure for each applicable charge type.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| PN_PMC | NUMBER | IN |
| PN_AMC_NUM | VARCHAR2 | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| PO_ERR_CD | NUMBER | OUT |
| PO_ERR_MSG | VARCHAR2 | OUT |

---

**Dependencies**

- PKG_FDI.SP_PUSH_FDI_TRANSACTIONS ([SP-024](#SP-024--PKG_FDI.SP_PUSH_FDI_TRANSACTIONS)) - PKG_FDI.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Retrieve the AMC cancellation details (refund amounts, tax amounts, contract details) from `VH_AMC_ENROL` and `VD_AMC_CANCELCHARGES`.
- Step 2 - For each cancellation charge line, build an FDI transaction record with the appropriate financial amounts.
- Step 3 - Validate that the dealer is FDI-enabled via `PKG_FDI.SF_VALID_DEALER`.
- Step 4 - Call `PKG_FDI.SP_PUSH_FDI_TRANSACTIONS` for each charge line to submit to the FDI system.
- Step 5 - Aggregate any errors and return the error code and message.

---
**Decision Points**

DP-001

Condition:
Dealer/location is FDI-enabled.

TRUE:
Build and submit FDI transactions for each cancellation charge line.

FALSE:
Return without action - dealer not FDI-enabled.

DP-002

Condition:
FDI push call returns an error.

TRUE:
Accumulate the error and continue processing remaining lines.

FALSE:
Mark the line as successfully submitted.

---
**Database Interactions**

- DB-001 - Read AM_DEALER_LOC - Reads data from AM_DEALER_LOC for lookup or validation.
- DB-002 - Read GM_STATE - Reads data from GM_STATE for lookup or validation.
- DB-003 - Read GM_EMP - Reads data from GM_EMP for lookup or validation.
- DB-004 - Read AM_DEALER_LOC_PARAM - Reads data from AM_DEALER_LOC_PARAM for lookup or validation.
- DB-005 - Read VD_AMC_ENROLCHARGES - Reads data from VD_AMC_ENROLCHARGES for lookup or validation.
- DB-006 - Read AM_CHARGE - Reads data from AM_CHARGE for lookup or validation.
**Business Rules**

BR-001 - FDI data push is only performed for FDI-enabled dealers.
BR-002 - All cancellation charge lines must be individually submitted to the FDI system.
BR-003 - The procedure returns after attempting all lines; partial failures are reported via the error code/message OUT parameters.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
PROCEDURE        SP_PUSH_MCPC_FDI_DATA(PN_PMC      NUMBER,
                                                  PN_AMC_NUM  VARCHAR2,
                                                  PO_ERR_CD   OUT NUMBER,
                                                  PO_ERR_MSG  OUT VARCHAR2) IS

 P_ERR_CD         NUMBER;
 P_ERR_MSG        VARCHAR2(1000);
 LV_FDI_CHARGES   MULDMS.PKG_FDI.FDI_CHARGES;
 LV_CNT            NUMBER;
BEGIN
 PO_ERR_CD  := 0;
 PO_ERR_MSG := NULL;
FOR II IN (SELECT SELLING_PARENT_GROUP, SELLING_DEALER_MAP_CD, MUL_SRV_DEALER_CD||'-'||FOR_CD DEALER_CODE, SELLING_LOC_CD,
                  TRANSACTION_TYPE, TRANSACTION_DATE, TRANSACTION_ID,TRANSACTION_REFERENCE_NO, TRANSACTION_REFERENCE_DATE,
                  1 /*SUM(TRANSACTION_QTY)*/ TRANSACTION_QTY, TRANSACTION_SEGMENT, VIN_NO, ENGINE_NUM, CHASSIS_NUM, MODEL_CD, VARIANT_CD, ECOLOR_CD,
                  SUM(BASIC_PRICE) BASIC_PRICE, SUM(DISCOUNT_AMT) DISCOUNT_AMT, SUM(TAXABLE_VALUE) TAXABLE_VALUE, SUM(SERVICE_AMOUNT) SERVICE_AMOUNT,
                  GST_NUM, PLACE_OF_SUPPLY, DECODE(PN_PMC,2,SUBSTR(HSN_SAC_CODE,1,4),HSN_SAC_CODE) HS_CODE, CUST_CD, CUSTOMER_NAME, EXECUTIVE, NULL TEAM_HEAD,
                  NULL FINANCIER_NAME,  NULL PAYMENT_MODE, NULL DEPOSIT_BANK,  NULL PAYMENT_FOR,
                  NULL GE1, NULL GE2, NULL GE3, NULL GE4, NULL GE5, NULL GE6, GE7, GE8,
                  GE9, NULL GE10, NULL GE11, NULL GE12, NULL GE13, NULL GE14, TAX_RATE GE15,
                  COMP_FA,
                  TITLE_CD,           SEX_IND,              MARITAL_IND,       PERMANENT_ADDRESS1,
                  PERMANENT_ADDRESS2, PERMANENT_ADDRESS3,   PPIN,              CITY_CD,
                  RES_PHONE,          OFF_ADDRESS1,         OFF_ADDRESS2,      OFF_ADDRESS3,
                  OFF_PIN,            OFF_CITY_CD,          STATE_CD,          DISTRICT,              TEHSIL_CD,
                  VILLAGE_CD,         GST_NUM CN_GST_NUM,   TIN,               UIN,                   DOB,
                  DOA,                SHIP_ADDRESS1,        SHIP_ADDRESS2,     SHIP_ADDRESS3,
                  SHIP_PIN,           SHIP_CITY_CD,         SHIP_FULL_NAME,
                  SHIP_GST_NUM,       SHIP_PAN,             SHIP_UIN,          COMMUNICATION_IND,
                  MOBILE,             MOBILE_PHONE,         EMAIL,             PAN_NUM
             FROM (
                    SELECT VH.SELLING_PARENT_GROUP, VH.SELLING_DEALER_MAP_CD,
                           (SELECT AM.MUL_SRV_DEALER_CD FROM AM_DEALER_LOC AM
                            WHERE AM.PRINCIPAL_MAP_CD = PN_PMC
                            AND AM.PARENT_GROUP = VH.SELLING_PARENT_GROUP
                            AND AM.DEALER_MAP_CD = VH.SELLING_DEALER_MAP_CD
                            AND AM.LOC_CD = VH.SELLING_LOC_CD
                          ) MUL_SRV_DEALER_CD,
                          (SELECT AM.FOR_CD FROM AM_DEALER_LOC AM
                          WHERE AM.PRINCIPAL_MAP_CD = PN_PMC
                            AND AM.PARENT_GROUP = VH.SELLING_PARENT_GROUP
                            AND AM.DEALER_MAP_CD = VH.SELLING_DEALER_MAP_CD
                            AND AM.LOC_CD = VH.SELLING_LOC_CD
                          ) FOR_CD,
                           VH.SELLING_LOC_CD,
                          'MCPC' TRANSACTION_TYPE, VH.CANCEL_DATE TRANSACTION_DATE, VH.CREDIT_NOTE_NO/*VH.DOC_NUM*/ TRANSACTION_ID,
                           VH.Doc_Num TRANSACTION_REFERENCE_NO, VH.AMC_DATE TRANSACTION_REFERENCE_DATE,
                           1 TRANSACTION_QTY, 'MCPC' TRANSACTION_SEGMENT, VH.VIN VIN_NO, VH.ENGINE_NUM,
                           VH.CHASSIS_NUM, VN.MODEL_CD, VH.VARIANT_CD, VN.ECOLOR_CD,
                          NVL(VH.LABOUR_AMT,0)+ NVL(VH.PART_AMT,0)+NVL(VH.CONSUMABLE_AMT,0)BASIC_PRICE,
                          (VH.DISCOUNT_AMT) DISCOUNT_AMT,
                          NVL(VH.LABOUR_RFND_AMT,0)+ NVL(VH.PART_RFND_AMT,0)+NVL(VH.CONS_RFND_AMT,0) TAXABLE_VALUE,
                          VH.CANCEL_AMT SERVICE_AMOUNT, NULL GST_NO, CN.GST_NUM GST_NUM,
                          (SELECT GST_STATE_CD FROM GM_STATE WHERE STATE_CD = CN.STATE_CD AND PRINCIPAL_MAP_CD = 1) PLACE_OF_SUPPLY,
                           NULL HSN_SAC_CODE, VH.CUST_CD, VH.CUST_NAME CUSTOMER_NAME,
                          (SELECT MSPIN||' - '||EMP_NAME FROM GM_EMP EM WHERE EM.EMP_CD = VH.EMP_CD AND EM.DEALER_MAP_CD = VH.SELLING_DEALER_MAP_CD) EXECUTIVE,
                           VH.SELLING_DEALER_MAP_CD GE7,
                          (SELECT GST_NUM FROM AM_DEALER_LOC_PARAM PR
                            WHERE PR.PARENT_GROUP = VH.SELLING_PARENT_GROUP
                              AND PR.DEALER_MAP_CD = VH.SELLING_DEALER_MAP_CD
                              AND PR.LOC_CD = VH.SELLING_LOC_CD) GE8,VH.AMC_NUM GE9,
                          /*(SELECT DISTINCT VC.CHARGE_VALUE
                             FROM VD_AMC_ENROLCHARGES VC
                            WHERE VC.PRINCIPAL_MAP_CD = 1
                              AND VC.AMC_NUM = VD.AMC_NUM
                              AND VC.SRV_TYPE = VD.SRV_TYPE
                              AND VC.SRL_NUM = VD.SRL_NUM )*/NULL TAX_RATE,
                           VH.SELLING_COMP_FA COMP_FA,
                           CN.TITLE_CD,           CN.SEX_IND,              CN.MARITAL_IND,       CN.PERMANENT_ADDRESS1,
                           CN.PERMANENT_ADDRESS2, CN.PERMANENT_ADDRESS3,   CN.PPIN,              CN.CITY_CD,
                           CN.RES_PHONE,          CN.OFF_ADDRESS1,         CN.OFF_ADDRESS2,      CN.OFF_ADDRESS3,
                           CN.OFF_PIN,            CN.OFF_CITY_CD,          CN.STATE_CD,          CN.DISTRICT,              CN.TEHSIL_CD,
                           CN.VILLAGE_CD,         CN.GST_NUM CN_GST_NUM,   CN.TIN,               CN.UIN,                   CN.DOB,
                           CN.DOA,                CN.SHIP_ADDRESS1,        CN.SHIP_ADDRESS2,     CN.SHIP_ADDRESS3,
                           CN.SHIP_PIN,           CN.SHIP_CITY_CD,         CN.SHIP_FULL_NAME,
                           CN.SHIP_GST_NUM,       CN.SHIP_PAN,             CN.SHIP_UIN,          CN.COMMUNICATION_IND,
                           CN.MOBILE,             CN.MOBILE_PHONE,         CN.EMAIL,             CN.PAN_NUM
                      FROM VH_AMC_ENROL VH, GM_VIN VN, GM_CIN CN
                     WHERE VH.PRINCIPAL_MAP_CD = PN_PMC
                       AND VH.AMC_NUM = PN_AMC_NUM
                       AND NVL(VH.CANCEL_YN,'N') = 'Y'
                       AND VH.VIN = VN.VIN
                       AND VN.PRINCIPAL_MAP_CD = PN_PMC
                       AND VN.PARTY_CD = CN.CUST_CD
                       AND CN.PRINCIPAL_MAP_CD = PN_PMC
                )
         GROUP BY SELLING_PARENT_GROUP, SELLING_DEALER_MAP_CD, MUL_SRV_DEALER_CD||'-'||FOR_CD, SELLING_LOC_CD,
                  TRANSACTION_TYPE, TRANSACTION_DATE, TRANSACTION_ID, TRANSACTION_REFERENCE_NO, TRANSACTION_REFERENCE_DATE,
                  TRANSACTION_SEGMENT, VIN_NO, ENGINE_NUM, CHASSIS_NUM, MODEL_CD, VARIANT_CD, ECOLOR_CD,
                  GST_NO, GST_NUM, PLACE_OF_SUPPLY, HSN_SAC_CODE, CUST_CD, CUSTOMER_NAME, EXECUTIVE,
                  GE7, GE8, GE9, TAX_RATE, COMP_FA,
                  TITLE_CD,           SEX_IND,              MARITAL_IND,       PERMANENT_ADDRESS1,
                  PERMANENT_ADDRESS2, PERMANENT_ADDRESS3,   PPIN,              CITY_CD,
                  RES_PHONE,          OFF_ADDRESS1,         OFF_ADDRESS2,      OFF_ADDRESS3,
                  OFF_PIN,            OFF_CITY_CD,          STATE_CD,          DISTRICT,              TEHSIL_CD,
                  VILLAGE_CD,         CN_GST_NUM,           TIN,               UIN,                   DOB,
                  DOA,                SHIP_ADDRESS1,        SHIP_ADDRESS2,     SHIP_ADDRESS3,
                  SHIP_PIN,           SHIP_CITY_CD,         SHIP_FULL_NAME,
                  SHIP_GST_NUM,       SHIP_PAN,             SHIP_UIN,          COMMUNICATION_IND,
                  MOBILE,             MOBILE_PHONE,         EMAIL,             PAN_NUM
         ORDER BY 2,8,3)
    LOOP
      LV_CNT:=1;
      LV_FDI_CHARGES.DELETE;
      FOR CHRG IN (
                   SELECT  DECODE(PN_PMC,2,SUBSTR(HSN_SAC_CODE,1,4),HSN_SAC_CODE)  HS_CODE, CHARGE_TYPE,  CHARGE_CD, CHARGE_DESC, TAX_RATE, SUM(CHARGE_AMT) CHARGE_AMT,
                          NULL MSIL_SHARE, NULL DEALER_SHARE
                     FROM (
                           SELECT VD.HSN_SAC_CODE, VC.CHARGE_CD,(SELECT CH.CHARGE_TYPE FROM AM_CHARGE CH
                                                                  WHERE CH.DEALER_MAP_CD =VH.SELLING_DEALER_MAP_CD
                                                                    AND CH.LOC_CD = VH.SELLING_LOC_CD
                                                                    AND CH.CHARGE_CD = VC.CHARGE_CD
                                                                    AND CH.CHARGE_TYPE = VC.CHARGE_TYPE) CHARGE_TYPE,
                                                                (SELECT CHARGE_DESC FROM AM_CHARGE CH
                                                                  WHERE CH.DEALER_MAP_CD =VH.SELLING_DEALER_MAP_CD
                                                                    AND CH.LOC_CD = VH.SELLING_LOC_CD
                                                                    AND CH.CHARGE_CD = VC.CHARGE_CD
                                                                    AND CH.CHARGE_TYPE = VC.CHARGE_TYPE) CHARGE_DESC,
                                  VC.CHARGE_VALUE TAX_RATE, VC.CHARGE_AMT
                             FROM VH_AMC_ENROL VH, VD_AMC_ENROL VD, /*VD_AMC_ENROLCHARGES*/ VD_AMC_CANCELCHARGES VC
                            WHERE VH.PRINCIPAL_MAP_CD = PN_PMC
                              AND VH.AMC_NUM = II.GE9 --II.TRANSACTION_REFERENCE_NO
                              AND VH.PRINCIPAL_MAP_CD = VD.PRINCIPAL_MAP_CD
                              AND VH.AMC_NUM = VD.AMC_NUM
                              AND VD.PRINCIPAL_MAP_CD = VC.PRINCIPAL_MAP_CD
                              AND VD.AMC_NUM = VC.AMC_NUM
                              AND VD.SRV_TYPE = VC.SRV_TYPE
                              AND VD.SRL_NUM = VC.SRL_NUM
                              AND NVL(VD.HSN_SAC_CODE,'NOTAVAIL') = NVL(II.HS_CODE,NVL(VD.HSN_SAC_CODE,'NOTAVAIL'))
                          )
                    WHERE NVL(CHARGE_AMT,0) > 0
                    --  AND TAX_RATE = II.GE15
                    GROUP BY DECODE(PN_PMC,2,SUBSTR(HSN_SAC_CODE,1,4),HSN_SAC_CODE) , CHARGE_TYPE, CHARGE_CD, CHARGE_DESC, TAX_RATE
                    )
       LOOP
        LV_FDI_CHARGES(LV_CNT).HSN_NO:=CHRG.HS_CODE;
        LV_FDI_CHARGES(LV_CNT).CHARGE_CD:=CHRG.CHARGE_CD;
        LV_FDI_CHARGES(LV_CNT).CHARGE_TYPE:=CHRG.CHARGE_TYPE;
        LV_FDI_CHARGES(LV_CNT).CHARGE_DESC:=CHRG.CHARGE_DESC;
        LV_FDI_CHARGES(LV_CNT).CHARGE_RATE:=CHRG.TAX_RATE;
        LV_FDI_CHARGES(LV_CNT).CHARGE_AMT:=CHRG.CHARGE_AMT;
        LV_FDI_CHARGES(LV_CNT).MSIL_SHARE:=NULL;
        LV_FDI_CHARGES(LV_CNT).DLR_SHARE:=NULL;
        LV_CNT:=LV_CNT+1;
       END LOOP;
       PKG_FDI.SP_PUSH_FDI_TRANSACTIONS(II.SELLING_PARENT_GROUP, --P_PARENT_GROUP    IN VARCHAR2,
                                        II.SELLING_DEALER_MAP_CD, --P_DEALER_MAP_CD   IN NUMBER,
                                        II.SELLING_LOC_CD, --P_LOC_CD          IN VARCHAR2,
                                        II.COMP_FA, --P_COMP_FA         IN VARCHAR2,
                                        II.TRANSACTION_TYPE, --P_TRANS_TYPE      IN VARCHAR2,
                                        II.TRANSACTION_DATE, --P_TRANS_DATE      IN DATE,
                                        II.TRANSACTION_ID, --P_TRANS_ID        IN VARCHAR2,
                                        II.TRANSACTION_REFERENCE_NO, --P_TRANS_REF_NO    IN VARCHAR2,
                                        II.TRANSACTION_REFERENCE_DATE, --P_TRANS_REF_DATE  IN DATE,
                                        II.TRANSACTION_QTY, --P_TRANS_QTY       IN NUMBER,
                                        II.TRANSACTION_SEGMENT, --P_TRANS_SEGMENT   IN VARCHAR2,
                                        II.VIN_NO, --P_VIN             IN VARCHAR2,
                                        II.ENGINE_NUM, --P_ENGINE_NUM      IN VARCHAR2,
                                        II.CHASSIS_NUM, --P_CHASSIS_NUM     IN VARCHAR2,
                                        II.MODEL_CD, --P_MODEL_CD        IN VARCHAR2,
                                        II.VARIANT_CD, --P_VARIANT_CD      IN VARCHAR2,
                                        II.ECOLOR_CD, --P_ECOLOR_CD       IN VARCHAR2,
                                        II.BASIC_PRICE, --P_BASIC_PRICE     IN NUMBER,
                                        II.DISCOUNT_AMT, --P_DISCOUNT        IN NUMBER,
                                        II.TAXABLE_VALUE, --P_TAXABLE_VALUE   IN NUMBER,
                                        II.SERVICE_AMOUNT, --P_SERVICE_AMOUNT  IN NUMBER,
                                        II.GST_NUM, --P_GST_NO          IN VARCHAR2,
                                        II.PLACE_OF_SUPPLY, --P_PLACE_OF_SUPPLY IN VARCHAR2,
                                        II.HS_CODE, --P_HSN_NO          IN VARCHAR2,
                                        II.EXECUTIVE, --P_EXECUTIVE       IN VARCHAR2,
                                        II.TEAM_HEAD, --P_TEAM_HEAD       IN VARCHAR2,
                                        II.FINANCIER_NAME, --P_FINC_NAME       IN VARCHAR2,
                                        II.PAYMENT_MODE, --P_PAYMENT_MODE    IN VARCHAR2,
                                        II.DEPOSIT_BANK, --P_DEPOSIT_BANK    IN VARCHAR2,
                                        II.PAYMENT_FOR, --P_PAYMENT_FOR     IN VARCHAR2,
                                        NULL, --P_INV_TYPE        IN VARCHAR2,
                                        II.GE1, --P_GE1             IN VARCHAR2,
                                        II.GE2, --P_GE2             IN VARCHAR2,
                                        II.GE3, --P_GE3             IN VARCHAR2,
                                        II.GE4, --P_GE4             IN VARCHAR2,
                                        II.GE5, --P_GE5             IN VARCHAR2,
                                        II.GE6, --P_GE6             IN VARCHAR2,
                                        II.GE7, --P_GE7             IN VARCHAR2,
                                        II.GE8, --P_GE8             IN VARCHAR2,
                                        II.GE9, --P_GE9             IN VARCHAR2,
                                        II.GE10, --P_GE10            IN VARCHAR2,
                                        II.GE11, --P_GE11            IN VARCHAR2,
                                        II.GE12, --P_GE12            IN VARCHAR2,
                                        II.GE13, --P_GE13            IN VARCHAR2,
                                        II.GE14, --P_GE14            IN VARCHAR2,
                                        II.GE15, --P_GE15            IN VARCHAR2,
                                        II.CUST_CD, --P_CUST_ID         IN VARCHAR2,
                                        NULL, --P_SALUTATION      IN VARCHAR2,
                                        II.CUSTOMER_NAME, --P_CUST_NAME       IN VARCHAR2,
                                        II.SEX_IND, --P_GENDER          IN VARCHAR2,
                                        II.MARITAL_IND, --P_MARITAL_STATUS  IN VARCHAR2,
                                        II.COMMUNICATION_IND, --P_COMMUNICATE_TO  IN VARCHAR2,
                                        II.PERMANENT_ADDRESS1, --P_RES_ADDRESS1    IN VARCHAR2,
                                        II.PERMANENT_ADDRESS2, --P_RES_ADDRESS2    IN VARCHAR2,
                                        II.PERMANENT_ADDRESS3, --P_RES_ADDRESS3    IN VARCHAR2,
                                        II.PPIN, --P_RES_PIN_CD      IN VARCHAR2,
                                        NULL, --P_RES_CITY        IN VARCHAR2,
                                        II.RES_PHONE, --P_RES_PHONE       IN VARCHAR2,
                                        II.OFF_ADDRESS1, --P_OFF_ADDRESS1    IN VARCHAR2,
                                        II.OFF_ADDRESS2, --P_OFF_ADDRESS2    IN VARCHAR2,
                                        II.OFF_ADDRESS3, --P_OFF_ADDRESS3    IN VARCHAR2,
                                        II.OFF_PIN, --P_OFF_PIN_CD      IN VARCHAR2,
                                        NULL, --P_OFF_CITY        IN VARCHAR2,
                                        II.OFF_PIN, --P_OFF_PHONE       IN VARCHAR2,
                                        II.MOBILE, --P_MOBILE1         IN VARCHAR2,
                                        II.MOBILE_PHONE, --P_MOBILE2         IN VARCHAR2,
                                        II.EMAIL, --P_EMAIL_ID        IN VARCHAR2,
                                        II.PAN_NUM, --P_PAN_NO          IN VARCHAR2,
                                        NULL, --P_STATE           IN VARCHAR2,
                                        NULL, --P_DISTRICT        IN VARCHAR2,
                                        NULL, --P_TEHSIL          IN VARCHAR2,
                                        NULL, --P_VILLAGE         IN VARCHAR2,
                                        II.CN_GST_NUM, --P_GST_NUM         IN VARCHAR2,
                                        II.TIN, --P_TIN             IN VARCHAR2,
                                        II.UIN, --P_UIN             IN VARCHAR2,
                                        II.DOB, --P_DOB             IN DATE,
                                        II.DOA, --P_DOA             IN DATE,
                                        II.SHIP_ADDRESS1, --P_SHIP_ADDRESS1   IN VARCHAR2,
                                        II.SHIP_ADDRESS2, --P_SHIP_ADDRESS2   IN VARCHAR2,
                                        II.SHIP_ADDRESS3, --P_SHIP_ADDRESS3   IN VARCHAR2,
                                        II.SHIP_PIN, --P_SHIP_PIN_CD     IN VARCHAR2,
                                        NULL, --P_SHIP_CITY       IN VARCHAR2,
                                        NULL, --P_SHIP_STATE      IN VARCHAR2,
                                        II.SHIP_FULL_NAME, --P_SHIP_FULL_NAME  IN VARCHAR2,
                                        II.SHIP_PAN, --P_SHIP_PAN        IN VARCHAR2,
                                        II.SHIP_GST_NUM, --P_SHIP_GST_NUM    IN VARCHAR2,
                                        II.SHIP_UIN, --P_SHIP_UIN        IN VARCHAR2,
                                        LV_FDI_CHARGES, --P_FDI_CHARGES_TAB IN PKG_FDI.FDI_CHARGES,
                                        'ADMIN', --P_CREATED_BY      IN VARCHAR2,
                                        P_ERR_CD, --P_ERR_CD          OUT NUMBER,
                                        P_ERR_MSG --P_ERR_MSG         OUT VARCHAR2);
                                        );
    END LOOP;
    PO_ERR_CD  := P_ERR_CD;
    PO_ERR_MSG := P_ERR_MSG;
EXCEPTION
  WHEN OTHERS THEN
     PO_ERR_CD  := 1;
     PO_ERR_MSG := 'ERROR IN DATA INSERTION';
END SP_PUSH_MCPC_FDI_DATA;

```

#### SP-058 - SP_SMS_CMPMGR

**Invoked From:**

- SP_PUSH_DMS_MESSAGE.prc [StoredProcedure: SP_PUSH_DMS_MESSAGE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sends an SMS notification to a customer via a campaign management service for a specified process and template. Used to notify customers of AMC-related events (such as cancellation) through the configured SMS campaign manager.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_CAMPAIGNNAME | VARCHAR2 | IN |
| P_TEMPLATENAME | VARCHAR2 | IN |
| P_PROCESS_CODE | VARCHAR2 | IN |
| P_PARENT_GROUP | VARCHAR2 | IN |
| P_DEALER_MAP_CD | VARCHAR2 | IN |
| P_LOC_CD | VARCHAR2 | IN |
| P_DOCUMENT_TYPE | VARCHAR2 | IN |
| P_DOCUMENT_NO | VARCHAR2 | IN |
| P_MOBILE_NO | VARCHAR2 | IN |
| P_PLACEHOLDER1 | VARCHAR2 | IN |
| P_PLACEHOLDER2 | VARCHAR2 | IN |
| P_PLACEHOLDER3 | VARCHAR2 | IN |
| P_PLACEHOLDER4 | VARCHAR2 | IN |
| P_PLACEHOLDER5 | VARCHAR2 | IN |
| P_PLACEHOLDER6 | VARCHAR2 | IN |
| P_PLACEHOLDER7 | VARCHAR2 | IN |
| P_PLACEHOLDER8 | VARCHAR2 | IN |
| P_PLACEHOLDER9 | VARCHAR2 | IN |
| P_REAL_TIME_YN | VARCHAR2 | IN |
| P_USER_ID | VARCHAR2 | IN |
| P_URLSHORTEN_YN | VARCHAR2 | IN |
| P_MSG_TYPE | VARCHAR2 | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_ERR_CD | NUMBER | OUT |
| P_ERR_DESC | VARCHAR2 | OUT |

---

**Dependencies**

- D2KWUTIL.CREATED_DATE ([SP-007](#SP-007--D2KWUTIL.CREATED_DATE)) - D2KWUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Validate the campaign name, template name, and process code.
- Step 2 - Retrieve the customer's mobile number for the targeted VIN/customer.
- Step 3 - Build the SMS message from the template, substituting the process-specific data fields.
- Step 4 - Call the SMS campaign manager API to dispatch the message.
- Step 5 - Return the dispatch result status.

---
**Decision Points**

DP-001

Condition:
Customer mobile number is valid and SMS service is reachable.

TRUE:
Dispatch the SMS notification.

FALSE:
Log the failure and return without sending.

---
**Database Interactions**

- DB-001 - Insert into GD_CMPMGR_SMS - Persists a new row into GD_CMPMGR_SMS using columns: uid num, campaignname, templatename, process code, parent group, dealer map cd, loc cd, document type, and 16 more column(s).
**Business Rules**

BR-001 - SMS notifications are non-blocking; a failure to send must not halt the main business transaction.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
PROCEDURE        SP_SMS_CMPMGR(P_CAMPAIGNNAME  IN VARCHAR2,
                                          P_TEMPLATENAME  IN VARCHAR2,
                                          P_PROCESS_CODE  IN VARCHAR2,
                                          P_PARENT_GROUP  IN VARCHAR2,
                                          P_DEALER_MAP_CD IN VARCHAR2,
                                          P_LOC_CD        IN VARCHAR2,
                                          P_DOCUMENT_TYPE IN VARCHAR2,
                                          P_DOCUMENT_NO   IN VARCHAR2,
                                          P_MOBILE_NO     IN VARCHAR2,
                                          P_PLACEHOLDER1  IN VARCHAR2,
                                          P_PLACEHOLDER2  IN VARCHAR2,
                                          P_PLACEHOLDER3  IN VARCHAR2,
                                          P_PLACEHOLDER4  IN VARCHAR2,
                                          P_PLACEHOLDER5  IN VARCHAR2,
                                          P_PLACEHOLDER6  IN VARCHAR2,
                                          P_PLACEHOLDER7  IN VARCHAR2,
                                          P_PLACEHOLDER8  IN VARCHAR2,
                                          P_PLACEHOLDER9  IN VARCHAR2,
                                          P_REAL_TIME_YN  IN VARCHAR2,
                                          P_USER_ID       IN VARCHAR2,
                                          P_URLSHORTEN_YN IN VARCHAR2,
                                          P_MSG_TYPE      IN VARCHAR2,
                                          P_ERR_CD        OUT NUMBER,
                                          P_ERR_DESC      OUT VARCHAR2) IS
BEGIN
  INSERT INTO GD_CMPMGR_SMS
    (UID_NUM,
     CAMPAIGNNAME,
     TEMPLATENAME,
     PROCESS_CODE,
     PARENT_GROUP,
     DEALER_MAP_CD,
     LOC_CD,
     DOCUMENT_TYPE,
     DOCUMENT_NO,
     MOBILE_NO,
     PLACEHOLDER1,
     PLACEHOLDER2,
     PLACEHOLDER3,
     PLACEHOLDER4,
     PLACEHOLDER5,
     PLACEHOLDER6,
     PLACEHOLDER7,
     PLACEHOLDER8,
     PLACEHOLDER9,
     REAL_TIME_YN,
     CREATED_DATE,
     CREATED_BY,
     URLSHORTEN_YN,
     MSG_TYPE)
  VALUES
    (SEQ_SMS_UID_NUM.NEXTVAL,
     P_CAMPAIGNNAME,
     P_TEMPLATENAME,
     P_PROCESS_CODE,
     P_PARENT_GROUP,
     P_DEALER_MAP_CD,
     P_LOC_CD,
     P_DOCUMENT_TYPE,
     P_DOCUMENT_NO,
     P_MOBILE_NO,
     P_PLACEHOLDER1,
     P_PLACEHOLDER2,
     P_PLACEHOLDER3,
     P_PLACEHOLDER4,
     P_PLACEHOLDER5,
     P_PLACEHOLDER6,
     P_PLACEHOLDER7,
     P_PLACEHOLDER8,
     P_PLACEHOLDER9,
     P_REAL_TIME_YN,
     SYSDATE,
     P_USER_ID,
     P_URLSHORTEN_YN,
     P_MSG_TYPE);
EXCEPTION
  WHEN OTHERS THEN
    P_ERR_CD   := 1;
    P_ERR_DESC := SUBSTR(SQLERRM, 1, 300);
END SP_SMS_CMPMGR;

```

#### SP-059 - SP_VALIDATE_ALPHANUMERIC

**Invoked From:**

- vt_amc_cncl_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

Search Details (N/A / CN_MAIN)

---

**Purpose**

Validates and sanitises an alphanumeric string passed via an IN OUT parameter by removing any character that is not an uppercase letter (A-Z) or a digit (0-9). The procedure is triggered during item validation on the Search Details screen (CN_MAIN) and uses DUAL-based SELECT statements to perform string operations, relying on WEBUTIL.LENGTH (SP-038) as a dependency.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_var | Varchar2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_var | Varchar2 | IN OUT |

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-038](#SP-038--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Query DUAL to obtain the current length of the input string P_var and store it in the local variable LEN.
- Step 2 - Initialise the loop counter I to 1 and begin iterating through each character position up to LEN.
- Step 3 - For each position I, query DUAL using SUBSTR to extract the single character C at that position.
- Step 4 - Evaluate the ASCII code of C: if it does NOT fall within the uppercase-letter range (65-90) AND does NOT fall within the digit range (48-57), the character is non-conforming and must be removed.
- Step 5 - When a non-conforming character is detected, query DUAL using REPLACE to remove all occurrences of that character from P_var, updating P_var in place.
- Step 6 - After removal, re-query DUAL to recalculate the new length of P_var and update LEN; decrement I by 1 so the same position is re-evaluated on the next iteration (accounting for the shortened string).
- Step 7 - Increment I by 1 and continue the loop until all characters have been validated.
- Step 8 - Return the sanitised string to the caller via the IN OUT parameter P_var.

---
**Decision Points**

DP-001

Condition:
ASCII code of the current character C is NOT in the range 65-90 (A-Z) AND NOT in the range 48-57 (0-9).

TRUE:
Remove the character from P_var using REPLACE (queried via DUAL), recalculate the string length, and decrement the loop counter to re-examine the current position.

FALSE:
Character is conforming; leave P_var unchanged and advance the loop counter to the next position.

---
**Database Interactions**

- DB-001 - Read DUAL - Reads data from DUAL for lookup or validation.
**Business Rules**

- BR-001 - Only uppercase letters (ASCII 65-90, A-Z) and digits (ASCII 48-57, 0-9) are considered valid alphanumeric characters; lowercase letters (a-z) are NOT retained and will be removed.
- BR-002 - All string operations (length calculation, character extraction, and character removal) are performed via SELECT statements against DUAL, with WEBUTIL.LENGTH (SP-038) declared as a package dependency.
- BR-003 - The procedure modifies the string in place via the IN OUT parameter P_var; the caller receives the sanitised string directly without a separate return value.
- BR-004 - When a non-conforming character is removed, ALL occurrences of that character are eliminated from P_var in a single REPLACE operation, and the loop length is recalculated immediately to reflect the shorter string.
- BR-005 - The procedure is invoked from the WHEN-VALIDATE-ITEM trigger in vt_amc_cncl_fmb.xml, ensuring input is sanitised at the point of field validation on the CN_MAIN screen.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
procedure sp_validate_alphanumeric
/*
$Log: SP_VALIDATE_ALPHANUMERIC.sql,v $
Revision 1.2  2004/09/02 14:45:05  muralidhard
no message

*/

(
P_var  IN OUT Varchar2)
is
len number;
c   char  ;
i   number := 1;
begin
    select length(P_var) into len from dual;
    while (i <= len)
    loop
     select substr(P_var,i,1) into c from dual;
       if not (ASCII(c) >=65 and ASCII(c) <= 90)  and
          not (ASCII(c) >=48 and ASCII(c) <= 57)    then
          select replace(P_var,c,Null) into P_var from dual;
          select length(p_var) into len from dual;
          i := i - 1;
       end if;
          i := i + 1;
    end loop;
  end;

```

#### SP-060 - STRIPDIRSEP

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sanitises a file-system path string supplied by the caller by removing any semicolon-delimited suffix and any trailing backslash directory separator, returning a clean, single-path value ready for use in DLL load operations invoked from D2KWUTIL.ATTEMPT_DLL_LOAD.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| InPath | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-038](#SP-038--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Initialise a local working variable (vcPath) with the value of the InPath input parameter.
- Step 2 - Inspect vcPath for the presence of a semicolon character using INSTR. If a semicolon is found, truncate vcPath to retain only the substring preceding the first semicolon, discarding all subsequent characters.
- Step 3 - Inspect the last character of the (possibly truncated) vcPath. If that character is a backslash ('\'), remove it by taking the substring from position 1 to one character less than the current length of vcPath.
- Step 4 - Return the sanitised vcPath value to the caller.

---
**Decision Points**

DP-001

Condition:
INSTR(vcPath, ';') > 0 - the path string contains one or more semicolon characters.

TRUE:
vcPath is truncated to the substring before the first semicolon, effectively discarding any additional path entries or extraneous trailing data.

FALSE:
vcPath is left unchanged and processing continues to DP-002.

DP-002

Condition:
SUBSTR(vcPath, -1, 1) = '\' - the last character of the (possibly truncated) path is a backslash directory separator.

TRUE:
The trailing backslash is stripped by taking SUBSTR(vcPath, 1, LENGTH(vcPath) - 1), yielding a path without a trailing separator.

FALSE:
vcPath is left unchanged and the current value is returned as-is.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only the portion of the path that precedes the first semicolon is considered valid; any text from the first semicolon onward is discarded. This ensures that multi-path or environment-variable-style strings are reduced to a single, unambiguous directory path.
- BR-002 - A trailing backslash directory separator must not be present on the returned path; if one exists it is unconditionally removed before the value is returned.
- BR-003 - The function operates solely on the input string using in-memory string operations; no database reads or writes are performed and no external routines are invoked during execution.

---
**Implementation Logic**

```plsql

  

Function StripDirSep ( InPath in varchar2) return varchar2 is 
  vcPath  varchar2(500) := InPath;
begin 
  -- Check and Strip SemiColons, we take everything
  -- Before the first Semicolon as our path
  if instr(vcPath,';') > 0 then
    vcPath := substr(vcPath,1,instr(vcPath,';') -1);
  end if;

  -- Check and Strip '\'
  if substr(vcPath,-1,1) = '\' then 
    vcPath := substr(vcPath,1,length(vcPath)-1);
  end if;

  return vcPath;
end StripDirSep;
```

#### SP-061 - WINDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WINDEBUG provides a debug string output mechanism by delegating to the external D2KWUTIL debug string function via the WIN_API framework. It accepts a text string, appends a newline character, registers the required external function call, and invokes the D2KWUTIL debug string routine. If the WIN_API layer is unavailable or an unexpected error occurs, the procedure captures and surfaces a structured error before re-raising the exception.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-043](#SP-043--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-044](#SP-044--ADD_EXTERNAL_ERRORS)) - matched by member name
- D2KWUTIL.D2KWUTIL_DEBUGSTRING ([SP-008](#SP-008--D2KWUTIL.D2KWUTIL_DEBUGSTRING)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- REGISTER_FUNCTION_CALL ([SP-049](#SP-049--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input text string and construct a working buffer (vcBuff1) by appending a newline character (CHR(10)) to the supplied text.
- Step 2 - Evaluate whether the WIN_API layer is active and available by checking WIN_API.API_ENABLED.
- Step 3 - If the API is enabled, register the external function call for 'D2KWUTIL_DEBUGSTRING' against the debug string function handle (iDebugString) using REGISTER_FUNCTION_CALL, specifying a wildcard character parameter type ('*CHAR').
- Step 4 - Invoke D2KWUTIL.D2KWUTIL_DEBUGSTRING, passing the resolved function handle and the constructed buffer (vcBuff1) to output the debug string.
- Step 5 - If WIN_API is not enabled, raise the WIN_API.NOT_AVAILABLE exception to signal that the API layer is unavailable.
- Step 6 - In the NOT_AVAILABLE exception handler, call ADD_ERROR to record a structured error identifying the calling procedure ('WinDebug') and the no-API error code (WIN_API.NoAPI), then re-raise the exception.
- Step 7 - In the OTHERS exception handler, call ADD_ERROR to record the calling procedure ('WinDebug') along with a combined unexpected-error message built from WIN_API.UError and ADD_EXTERNAL_ERRORS, then re-raise the exception.

---
**Decision Points**

DP-001

Condition:
WIN_API.API_ENABLED evaluates to TRUE.

TRUE:
The procedure registers the external function call via REGISTER_FUNCTION_CALL and then invokes D2KWUTIL.D2KWUTIL_DEBUGSTRING to output the debug string.

FALSE:
The WIN_API.NOT_AVAILABLE exception is raised, triggering the NOT_AVAILABLE exception handler.

---

DP-002

Condition:
The WIN_API.NOT_AVAILABLE exception is raised (either directly from the API_ENABLED check or propagated from a called routine).

TRUE:
ADD_ERROR is called with the procedure name 'WinDebug' and WIN_API.NoAPI as the error code, and the exception is re-raised to the caller.

FALSE:
Execution continues normally or falls through to the OTHERS handler if a different exception is raised.

---

DP-003

Condition:
An unexpected exception (OTHERS) is raised during execution.

TRUE:
ADD_ERROR is called with the procedure name 'WinDebug' and a composite error message combining WIN_API.UError with the result of ADD_EXTERNAL_ERRORS, and the exception is re-raised to the caller.

FALSE:
No error handling is required; normal execution completes.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The input text string must always be suffixed with a newline character (CHR(10)) before being passed to the external debug string function; the procedure enforces this formatting internally.
- BR-002 - Debug string output is only permitted when the WIN_API layer is active (WIN_API.API_ENABLED is TRUE); if the layer is unavailable, the operation is rejected and WIN_API.NOT_AVAILABLE is raised.
- BR-003 - The external function 'D2KWUTIL_DEBUGSTRING' must be registered via REGISTER_FUNCTION_CALL before it is invoked; the registration must specify the function handle (iDebugString), the function name, and the parameter type '*CHAR'.
- BR-004 - All exceptions must be re-raised after error recording, ensuring that error conditions are propagated to the calling context (D2KWUTIL.pld DEBUGLOG) rather than silently suppressed.
- BR-005 - Unexpected errors must be enriched with external error details retrieved via ADD_EXTERNAL_ERRORS before being recorded through ADD_ERROR, ensuring complete error context is captured.

---
**Implementation Logic**

```plsql
  

  
PROCEDURE WinDebug  (  Text  IN   VARCHAR2) is
  vcBuff1 VARCHAR2(2000) := Text||chr(10);
begin 
  --WIN_API.Clean_Error_Stack;
  if Win_API.API_ENABLED then
    win_api.Register_function_call(iDebugString,'d2kwutil_DebugString',NULL,'*CHAR');
    d2kwutil_DebugString(win_api.FunctionHandle(iDebugString),vcBuff1);
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if; 
exception
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('WinDebug',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('WinDebug',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end WinDebug;
```

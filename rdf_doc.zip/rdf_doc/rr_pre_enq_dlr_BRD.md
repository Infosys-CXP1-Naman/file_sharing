# BUSINESS REQUIREMENTS DOCUMENT

## Table of Contents

- 1. Document Control
  - 1.1 Document Information
  - 1.2 Revision History
- 2. Executive Summary
  - Key Stakeholders
- 3. System Context
- 4. Functional Requirements
  - 4.1 Business Requirements
    - Requirement ID: BR-001
    - Requirement ID: BR-002
    - Requirement ID: BR-003
    - Requirement ID: BR-004
    - Requirement ID: BR-005
    - Requirement ID: BR-006
    - Requirement ID: BR-007
    - Requirement ID: BR-008
    - Business Scenarios - How the report generation differs by report server availability
    - Requirement ID: BR-009
    - Requirement ID: BR-010
    - Requirement ID: BR-011
- 5. Business Rules Catalogue
- 6. Data Requirements
  - 6.1 Business Entities and Relationships
    - Pre-Enquiry Campaign - MULDMS.PRE_ENQ_CAMPAIGN
    - Dealer Location Master - MULDMS.AM_DEALER_LOC
    - City Master - MULDMS.GM_CITY
    - Enquiry Header - MULDMS.RH_ENQ
    - Enquiry Detail - MULDMS.RD_ENQ
    - Enquiry Type Master - MULDMS.RM_ETYPES
    - Enquiry Source List - AM_LIST
    - Order Booking - MULDMS.SH_ORDBOOK
    - Invoice - MULDMS.SH_INVOICE (joined via SH_ORDBOOK)
    - Model Master - GM_MOD / MULDMS.GM_VAR (via enquiry and invoice joins)
    - Region Master - MULDMS.GM_REGN
    - Report Server Configuration - EH_REPORTS
    - Entity Relationships
  - 6.2 Data Capture Requirements
    - Report Filter Parameters - User Inputs at Report Request Time
    - Session / Non-Database Parameters
  - 6.3 Reference Data
  - 6.4 Data Lifecycle
  - 6.5 Excel Output Columns
- 7. Glossary
- 8. Technical Inventory
  - 8.1 Form Architecture
    - 8.1.1 Global Variables
    - 8.1.2 Form Parameters
  - 8.2 Blocks
    - 8.2.1 Block WhereClause and OrderByClause
  - 8.3 Items Summary
  - 8.4 List of Values
  - 8.5 Alerts
  - 8.6 Program Units
  - 8.7 Triggers
    - 8.7.1 Inactive / Commented-Out Trigger Register
  - 8.8 Canvas and Window Inventory
  - 8.9 Editors
  - 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups
    - 8.10.1 Visual Attributes (form-defined)
    - 8.10.2 Property Classes (form-defined)
    - 8.10.3 Object Groups
  - 8.11 DataSourceColumn Inventory
- 9. Object Library
- 10. Record Groups
- 11. Referenced Database Objects
- 12. Backend Procedures and Packages
  - 12.1 Main Flow Backend Procedure/Package Index
  - 12.2 Procedure and Package Catalogue
    - GENERAL.DISP_TEXT
    - GENERAL.RAISE_ERROR
    - GENERAL.ASK_CONFIRM
    - VIEW_EXCEL_REPORT_NEW
    - SF_COPYRIGHT_DECLARATION
    - L_POPULATE
    - PR_REMOVE_ASCII_CHR
    - POPULATE_ERRORS
    - WEBUTIL_CORE.CUSTOMEVENTHANDLER
    - WEBUTIL.ID_NULL
- 13. Package Procedure Specifications
- 14. Database Package Catalogue
- 15. PLD Procedure Call Sites
  - DPL.pld (`general`)
  - Inactive / commented-only PLD call sites
  - webutil.pld (`WEBUTIL_CORE`)
  - webutil.pld (`WEBUTIL_C_API`)
- 16. Microservice API Candidates
  - 16.1 Microservices with APIs
- 17. Workflows
- 18. PLD-Backed Logic
  - webutil.pld (`CLIENT_IMAGE`)
  - DPL.pld (`general`)
  - D2kwutil.pld (`Win_API`)
- 19. PCK-Backed Logic
- 20. System Interfaces
  - 20.1 Database Integrations
  - 20.2 External System Integrations
  - 20.3 Report Integrations
    - 20.3.1 Parameters Passed to the Report
- 21. Procedure and Function Business Rule Catalogue
  - 21.1 Catalogue Index
  - 21.2 Detailed Specifications
    - SP-001 - D2KWUTIL.ATTEMPT_DLL_LOAD
    - SP-002 - D2KWUTIL.CHOOSEFILE
    - SP-003 - D2KWUTIL.D2KWUTIL_ACTIVEWIN
    - SP-004 - D2KWUTIL.D2KWUTIL_CHOOSEFILE
    - SP-005 - D2KWUTIL.D2KWUTIL_DEBUGSTRING
    - SP-006 - D2KWUTIL.D2KWUTIL_GETDOSENV
    - SP-007 - D2KWUTIL.D2KWUTIL_GETREGKEY
    - SP-008 - D2KWUTIL.D2KWUTIL_WINDIR
    - SP-009 - D2KWUTIL.GET_ACTIVE_WINDOW
    - SP-010 - D2KWUTIL.SAVE_FILE
    - SP-011 - D2KWUTIL.TRANSLATETYPE
    - SP-012 - GENERAL.ASK_CONFIRM
    - SP-013 - GENERAL.DISP_TEXT
    - SP-014 - GENERAL.RAISE_ERROR
    - SP-015 - WEBUTIL.BLOCKING
    - SP-016 - WEBUTIL.CHECKLIBS
    - SP-017 - WEBUTIL.CLEARCALLBACKTRIGGER
    - SP-018 - WEBUTIL.CLOSEBLOB
    - SP-019 - WEBUTIL.CLOSEFILE
    - SP-020 - WEBUTIL.DOWNLOADFROMURL
    - SP-021 - WEBUTIL.DOWNLOADFROMURLINT
    - SP-022 - WEBUTIL.ERROR
    - SP-023 - WEBUTIL.ERRORALERT
    - SP-024 - WEBUTIL.EXECUTE
    - SP-025 - WEBUTIL.FCLOSE
    - SP-026 - WEBUTIL.FILE_SAVE_DIALOG
    - SP-027 - WEBUTIL.FILE_SELECTION_DIALOG_INT
    - SP-028 - WEBUTIL.FOPEN
    - SP-029 - WEBUTIL.GETCALLBACKTRIGGER
    - SP-030 - WEBUTIL.GETCLIENTOSFAMILY
    - SP-031 - WEBUTIL.GETCLIENTSETTING
    - SP-032 - WEBUTIL.GETIMPLCLASS
    - SP-033 - WEBUTIL.GETLASTERROR
    - SP-034 - WEBUTIL.GETLASTERRORARGS
    - SP-035 - WEBUTIL.GETNUMBER
    - SP-036 - WEBUTIL.GETOSFAMILY
    - SP-037 - WEBUTIL.GETOUTPUT
    - SP-038 - WEBUTIL.GETPROPERTY
    - SP-039 - WEBUTIL.GETSTRING
    - SP-040 - WEBUTIL.GETVAR
    - SP-041 - WEBUTIL.GET_LINE
    - SP-042 - WEBUTIL.GET_RETURN_CODE
    - SP-043 - WEBUTIL.GET_STANDARD_OUTPUT
    - SP-044 - WEBUTIL.HOST
    - SP-045 - WEBUTIL.ID_NULL
    - SP-046 - WEBUTIL.INIT
    - SP-047 - WEBUTIL.INITWEBUTIL
    - SP-048 - WEBUTIL.ISERROR
    - SP-049 - WEBUTIL.IS_OPEN
    - SP-050 - WEBUTIL.LENGTH
    - SP-051 - WEBUTIL.LOG
    - SP-052 - WEBUTIL.POPULATEPROPERTYBUNDLE
    - SP-053 - WEBUTIL.PUTF
    - SP-054 - WEBUTIL.PUT_LINE
    - SP-055 - WEBUTIL.READFROMPROPERTYBUNDLE
    - SP-056 - WEBUTIL.READTRANSFROMMSGBUNDLE
    - SP-057 - WEBUTIL.REGISTERBEAN
    - SP-058 - WEBUTIL.REGISTER_FUNCTION
    - SP-059 - WEBUTIL.RELEASE_PROCESS
    - SP-060 - WEBUTIL.SETCLIENTSETTING
    - SP-061 - WEBUTIL.SETDATA
    - SP-062 - WEBUTIL.SETPROPERTY
    - SP-063 - WEBUTIL.SHOWBEANS
    - SP-064 - WEBUTIL.URL_TO_CLIENT
    - SP-065 - WEBUTIL.WRITEDATA
    - SP-066 - WEBUTIL_CORE.CUSTOMEVENTHANDLER
    - SP-067 - ADD_ERROR
    - SP-068 - ADD_EXTERNAL_ERRORS
    - SP-069 - BOOLTOCHAR
    - SP-070 - CLEAN_ERROR_STACK
    - SP-071 - DEBUGLOG
    - SP-072 - GET_ENVIRONMENT_STRING
    - SP-073 - GET_TEMP_DIRECTORY
    - SP-074 - GET_WINDOWS_DIRECTORY
    - SP-075 - READ_REGISTRY
    - SP-076 - REGISTER_FUNCTION_CALL
    - SP-077 - SETDEBUG
    - SP-078 - SF_COPYRIGHT_DECLARATION
    - SP-079 - STRIPDIRSEP
    - SP-080 - VIEW_EXCEL_REPORT_NEW
    - SP-081 - WINDEBUG

## 1. Document Control

### 1.1 Document Information

| Field | Value |
| ----- | ----- |
| Document Title | RR_PRE_ENQ_DLR - Business Requirements Document |
| Form Module Name | RR_PRE_ENQ_DLR |
| Document Version | 1.0 |
| Date Created | August 04, 2026 |
| Author/Prepared By | BRD Agent |

### 1.2 Revision History

| Version | Date | Author | Description |
| --- | --- | --- | --- |
| 1.0 | August 04, 2026 | BRD Agent | Initial draft |

---

## 2. Executive Summary

*High-level overview of the rr_pre_enq_dlr Pre-Enquiry Dealer Report form, its purpose, and roles referenced in the module.*

The **rr_pre_enq_dlr** Oracle Forms module is the Dealer Pre-Enquiry Report screen within the Dealer Management System (DMS). A dealer user opens the screen, selects a campaign and a date range of up to three months, and requests an Excel export of pre-enquiry activity. The form validates that both dates are present, that the from date is not in the future, and that the date range does not exceed three months before generating the report. On submission, the system retrieves all matching pre-enquiry campaign prospects for the dealer, joins them to any associated enquiries, orders, and invoices, and produces a downloadable CSV file containing prospect details, follow-up status, enquiry information, and final vehicle outcome. The form does not create or update records; its sole function is to extract and deliver a structured pre-enquiry performance report.

### Key Stakeholders

*Who uses rr_pre_enq_dlr*

| Stakeholder | Role |
| :--- | :--- |
| **Dealer User** | Primary and only interactive user of this screen. Selects the campaign and date range, then submits to generate and download the pre-enquiry report. |
| **Dealer / Location** | Business entity whose pre-enquiry and campaign data is extracted; scoped by the dealer, location, and parent group context established at login. |
| **Principal / Manufacturer** | Organisation whose campaign and model data is included in the report; used to scope campaign names, model descriptions, and enquiry source lookups. |

---

---

## 3. System Context

*Describes the rr_pre_enq_dlr module's role within the DMS ecosystem, scope, process flow, and key integrations.*

The **rr_pre_enq_dlr** module is the Pre-Enquiry Dealer Report screen in the Dealer Management System (DMS). It provides dealer users with a structured, downloadable report of pre-enquiry campaign activity, showing how campaign prospects have progressed through to enquiry, booking, and invoice. The module is read-only and does not modify any data; it extracts and presents performance information to support dealer review and follow-up.

**System purpose:** Accept a campaign filter and date range from the dealer user, validate the input, and generate a downloadable Excel/CSV report covering pre-enquiry campaign prospects and their associated enquiry, booking, and invoice outcomes - as implemented in the rr_pre_enq_dlr Oracle Forms module.

**In scope:**

- Display a report filter screen with a date range (From Date and To Date) and a campaign selector
- Validate that From Date is not null, not in the future, and not greater than To Date
- Validate that To Date is not null, not earlier than From Date, not in the future, and within three months of From Date
- Automatically set To Date to the last day of the month when From Date is entered
- Allow the user to select a campaign code and description from a campaign list of values
- Generate a dynamic SQL report query joining pre-enquiry campaign, dealer location, and enquiry data
- Include a static 'ALL Campaign Code' option so the report can cover all campaigns for the period
- Export the report as a downloadable CSV/Excel file identified by the user ID and generation timestamp
- Clear the form and reset filter fields without saving data
- Display the copyright declaration on the form

**Process Name:** Pre-Enquiry Dealer Report Generation

**Process Owner:** Dealer Operations Manager

**Process Objective:** Enable the dealer user to select a campaign and date range, validate the search criteria, and download a pre-enquiry performance report showing prospect details, follow-up status, enquiry outcomes, and final vehicle booking and invoice results.

**Process Trigger:** Dealer user opens the Pre-Enquiry Report screen to review campaign pre-enquiry activity for a selected period

**Process Flow:**

The complete pre-enquiry dealer report generation process follows this sequence. Each step corresponds to Functional Requirements in Section 4.

```
STEP 1 ── FORM OPENS
         Dealer user opens the rr_pre_enq_dlr screen.
         The system registers the session module name for tracking and starts a
         performance timer when application logging is enabled.

STEP 2 ── CAMPAIGN LOV LOADS
         The campaign list is populated from the pre-enquiry campaign master,
         filtered by the dealer, location, parent group, and principal context
         that was established at login.
         An 'All Campaign Code' option is always included at the top of the list.

STEP 3 ── USER SELECTS CAMPAIGN
         The dealer user opens the campaign list of values and selects a
         campaign code and description.
         ├── ALL CAMPAIGNS: User selects 'All Campaign Code'; the report will
                            cover all campaigns for the date period.
         └── SPECIFIC CAMPAIGN: User selects one campaign code; the report is
                                 filtered to that campaign only.

STEP 4 ── USER ENTERS FROM DATE
         The dealer user enters the From Date for the report period.

STEP 5 ── FROM DATE VALIDATION
         ├── From Date is null: error - "From Date can not be empty"; user must re-enter.
         ├── From Date is in the future: error - "From Date cannot be greater than Current Date";
                                         user must re-enter.
         └── From Date is valid: To Date is automatically calculated and set to the last day
                                  of the calendar month from From Date, or today's date if that
                                  would be in the future.

STEP 6 ── USER ENTERS TO DATE
         The dealer user reviews the automatically set To Date and may adjust it.

STEP 7 ── TO DATE VALIDATION
         ├── To Date is null: error - "To Date can not be empty"; user must re-enter.
         ├── From Date is null (To Date entered first): error - user must enter From Date first.
         ├── To Date is earlier than From Date: error - "To Date cannot be lesser than From Date".
         ├── To Date is in the future: error - "To Date cannot be greater than Current Date".
         └── Date range exceeds three months: error - "Please give the date range of maximum
                                               three month"; user must adjust the dates.

STEP 8 ── USER CLICKS SUBMIT
         The dealer user clicks the Submit button to generate the report.
         The system assembles a dynamic query using the selected campaign code,
         dealer context (parent group, dealer code, location code), and date range.

STEP 9 ── REPORT QUERY EXECUTES
         The system queries pre-enquiry campaign prospects for the dealer and
         joins them to dealer location, regional enquiry headers, city descriptions,
         model information, enquiry source lookups, order records, and invoice records.
         Prospect name, address, follow-up status, and remark are included.
         Enquiry number, date, model, source, mode, prospect name, mobile, and
         enquiry status are added where a linked enquiry exists.
         Booking date, invoice date, and invoiced model are added where an order and
         invoice exist within the enquiry period.

STEP 10 ── FILE IS GENERATED AND DOWNLOADED
          The report is written as a CSV file named with the user ID and a timestamp
          (e.g. USERID_202405221030.csv) and made available for download via the browser.

STEP 11 ── CLEAR FORM (OPTIONAL)
          The dealer user may press the clear key to reset all filter fields.
          The copyright declaration is refreshed and the form returns to its initial state.

STEP 12 ── EXIT
          The dealer user exits the form.
          Session module information is cleared from the database session tracker.
```

**Major process interactions:**

- **Pre-enquiry campaign master** - source of campaign codes, names, target models, and prospect records used to populate the campaign LOV and the report body
- **Dealer location master** - provides dealer name, location code, region code, and city code for each campaign prospect row in the report
- **Regional and city master data** - resolves city descriptions for the dealer city column in the report
- **Enquiry header data** - joined to campaign prospects to add enquiry number, date, model, source, mode, prospect contact details, and current enquiry status
- **Order and invoice data** - joined to matched enquiries to add booking date, invoice date, and invoiced model for fully converted prospects
- **Application master list** - provides enquiry source descriptions used in the report body
- **Report file system** - receives the generated CSV file written to the server reports directory and opened in the user's browser

---

---

## 4. Functional Requirements

### 4.1 Business Requirements

#### Requirement ID: BR-001

**Requirement Title:** Form Initialization and Application Session Registration

**Business Description:**
When the Pre-Enquiry Dealer Report screen is opened, the system registers the active user session against this form so that performance and activity can be monitored. If application-level performance logging is switched on, the system also starts a timer to track how long the screen takes to respond. The screen is then maximised, default date values are pre-filled for the current reporting period, and the report title and copyright declaration are set ready for use. This ensures that the business can trace screen usage, diagnose performance issues, and present the user with a fully initialised, ready-to-use screen.

**Actors:** Dealer User

**Preconditions:**
- The user has navigated to the Pre-Enquiry Dealer Report screen.

**Main Flow:**

**Step 1 - Session and module identity registered at screen open**
Before the screen is displayed, the system registers the form identifier (`rr_pre_enq_dlr`) as both the client-info tag and the active module name in the database session so that any database-level monitoring or audit tool can identify which screen the user is working in. The Oracle session tracking calls used here (DBMS_APPLICATION_INFO) are Oracle built-ins not catalogued in Section 21.1; no `Procedures called` bullet is emitted per R5.

**Step 2 - Performance timer started if application logging is active**
If the system's application logging setting is enabled (`GLOBAL.APP_LOG = 'Y'`), the system starts an internal performance timer at the moment the screen opens. This timer allows the monitoring team to measure screen load times.

**Step 3 - Screen and application window maximised**
As the form opens, the main application window and the form's own window (`WN_MAIN`) are both maximised to fill the available display area, ensuring the reporting screen occupies the full desktop.

**Step 4 - Report title set and default date range pre-filled**
The report description field is set to *"Pre-Enquiry Followup Report"* so the user can see which report they are running. The Campaign From Date is defaulted to the first day of the current calendar month and the Campaign To Date is defaulted to today's date, giving the user a sensible starting date range without manual entry.

**Step 5 - Application identifier seed recorded for session tracking**
The global application identifier (`GLOBAL.APP_ID`) is set to `rr_pre_enq_dlr` and copied to the session parameter (`PARAMETER.P_APP_ID`) so that downstream reporting and logging routines can identify the calling form.

**Step 6 - Copyright declaration retrieved and displayed**
The system calls the copyright declaration function to retrieve the company copyright notice applicable to the logged-in dealership context and populates the copyright declaration display field. This call reuses the same routine invoked on a form-clear (see BR-003).

*Procedures called:*
- **SF_COPYRIGHT_DECLARATION** ([SP-045](#SP-045--SF_COPYRIGHT_DECLARATION)) - SF_COPYRIGHT_DECLARATION - retrieves the copyright declaration text applicable to the currently logged-in company and returns it for display on screen. If the function fails or returns nothing, the field remains blank.
    * **Step 1** - Retrieve the current copyright declaration text applicable to the logged-in company context.
    * **Step 2** - Validate the input values.
    * **Step 3** - Return the processing result (the copyright declaration text).

**Alternative Flows:**
- **BR-001-AF-01** - (from Step 2) If application logging is not enabled, the timer is not started and no logging action is performed; the screen opens normally without any performance tracking.

---

---

#### Requirement ID: BR-002

**Requirement Title:** Form Exit with Session Cleanup

**Business Description:**
When the user presses the designated exit key, the system clears the active module and session identity from the database monitoring register before closing the screen without saving any unsaved changes. This ensures that session tracking is properly tidied up when the user leaves the screen.

**Actors:** Dealer User

**Preconditions:**
- The Pre-Enquiry Dealer Report screen is open.

**Main Flow:**

**Step 1 - Session identity cleared and form closed without saving**
When the user presses the exit key, the system clears the session client-info identifier and resets the module name to an empty value in the database session tracking register. The screen then closes immediately, discarding any unsaved input without prompting the user to save.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Campaign From Date (`P_FROMDT`) | Optional | Date | 10 / DD-MM-RRRR | N/A | N/A | Screen open | N/A | Unsaved data is discarded on exit without warning |
| Campaign To Date (`P_TODT`) | Optional | Date | 10 / DD-MM-RRRR | N/A | N/A | Screen open | N/A | Unsaved data is discarded on exit without warning |
| Campaign Code (`P_CAMPAIGN_CODE`) | Optional | Text | 100 | N/A | N/A | Screen open | N/A | Unsaved data is discarded on exit without warning |

---

---

#### Requirement ID: BR-003

**Requirement Title:** Form Clear and Copyright Declaration Refresh

**Business Description:**
When the user presses the clear-form key or clicks the Cancel toolbar button, the system wipes all entered values from the screen without saving any changes. It then re-populates the copyright declaration display field to reflect the correct company copyright notice for the currently logged-in dealership context. When the user clicks the Save toolbar button, the system commits any pending changes to the database and then clears the screen. The Insert toolbar button is explicitly disabled on this form - clicking it shows an error message to prevent unsupported record creation. These operations ensure the copyright information is always current and accurate after a clear operation, that data is correctly committed when saved, and that the user is clearly informed when an operation is not supported.

**Actors:** Dealer User

**Preconditions:**
- The Pre-Enquiry Dealer Report screen is open.

**Main Flow:**

**Step 1 - Screen cleared and copyright declaration refreshed**
The user presses the clear-form key. The system clears all field values from the screen without saving. It then calls the copyright declaration function to retrieve the current copyright notice applicable to the logged-in company context and displays it in the copyright declaration field.

*Procedures called:*
- **SF_COPYRIGHT_DECLARATION** ([SP-045](#SP-045--SF_COPYRIGHT_DECLARATION)) - SF_COPYRIGHT_DECLARATION - retrieves the copyright declaration text applicable to the currently logged-in company and returns it for display on screen. If the function fails or returns nothing, the field remains blank.
    * **Step 1** - Retrieve the current copyright declaration text applicable to the logged-in company context.
    * **Step 2** - Validate the input values.
    * **Step 3** - Return the processing result (the copyright declaration text).

**Step 2 - Save toolbar button commits data then clears the screen**
When the user clicks the Save button on the toolbar, the system commits all pending changes to the database and then clears the screen, returning it to a fresh state ready for the next entry. This action is equivalent to a commit followed by a form-clear.

**Step 3 - Cancel toolbar button discards unsaved changes with confirmation**
When the user clicks the Cancel button on the toolbar and there are unsaved changes on the screen, the system asks the user to confirm that they wish to discard those changes. If the user confirms, the screen is cleared without saving. If the form has no unsaved changes, the screen is cleared immediately without prompting.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Unsaved data present when Cancel clicked | FT_CANCEL - check of SYSTEM.FORM_STATUS = 'CHANGED' via GENERAL.ASK_CONFIRM | When the user clicks the Cancel toolbar button | Prevent accidental loss of entered data by requiring explicit confirmation before discarding changes | Confirmation dialogue shown: *"Entered data will not be Saved"*; screen cleared only if the user confirms |

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-WS-01** - Unsaved changes detected on Cancel - *"Entered data will not be Saved"* confirmation shown; screen cleared if confirmed, left unchanged if declined.

**Step 4 - Insert toolbar button blocked on this form**
When the user clicks the Insert button on the toolbar, the system shows an error message indicating that record creation is not supported on this screen. No new record is created.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Insert operation not supported on this form | FT_INSERT - explicit guard via GENERAL.DISP_TEXT | When the user clicks the Insert toolbar button | Prevent users from attempting to create records on a reporting-only screen | *"This Operation Cannot be performed Here"* shown; no record created |

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-ES-01** - Insert attempted on reporting screen - *"This Operation Cannot be performed Here"*; no record created.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Copyright Declaration (`COPYRIGHT_DECLARATION`) | Auto-populated | Display | 500 | N/A | N/A | Screen open | System-populated; read-only | N/A |

---

---

#### Requirement ID: BR-004

**Requirement Title:** Custom Form Error Handling

**Business Description:**
When any Oracle Forms system error occurs while the user is working on the Pre-Enquiry Dealer Report screen, the system intercepts the error and presents it in a clear, user-friendly dialogue instead of the standard Oracle Forms error format. Different categories of error are handled distinctly: date format errors, character-type violations, field-length errors, and database-level integrity failures each show a specific, plain-language message. Concurrent record-update conflicts are also detected and explained, and any remaining unrecognised database errors are shown using the database error text. Errors code 40401 and 40405 (query-with-no-records situations) are silently suppressed and do not interrupt the user.

**Actors:** Dealer User (error handler fires automatically on any system error)

**Preconditions:**
- The Pre-Enquiry Dealer Report screen is open and an Oracle Forms or database error has been raised.

**Main Flow:**

**Step 1 - Invalid date entry detected and reported**
If the system raises error code 50004 (invalid date value), the user is shown the message *"Entered Date is not valid Date"* in an error dialogue, and the current action is stopped.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-010](#SP-010--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the error message text in an alert dialogue to the user. Raises a trigger failure to stop the current processing after the message is shown.
    * **Step 1** - Receive the error message text and the dialogue title from the caller.
    * **Step 2** - Based on the title, select the appropriate alert box (error-type alert or note-type alert).
    * **Step 3** - Set the alert box title and message text.
    * **Step 4** - Display the alert box to the user and wait for acknowledgement.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Invalid date value detected | Error code 50004 - ON-ERROR trigger (Form) | When the system raises an error as the user enters or commits data | Intercept the cryptic Oracle Forms date error and replace it with a plain-language message the user can act on | *"Entered Date is not valid Date"* shown; current action aborted (trigger failure raised) |

*Business outcomes (errors, warnings, success, and status):*
- **BR-004-ES-01** - Error code 50004 raised - *"Entered Date is not valid Date"*; current action is stopped.

**Step 2 - Incorrect date format detected and reported**
If the system raises error codes 50025 or 50026 (date format violation), the user is shown the message *"Enter the Date in the proper format (DD-MM-YYYY)"* and the current action is stopped.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-010](#SP-010--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the date format error message to the user (see Step 1 sub-bullets for routine logic).

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Incorrect date format | Error codes 50025 or 50026 - ON-ERROR trigger (Form) | When the system raises a date-format error as the user enters or commits data | Guide the user to use the correct date format (DD-MM-YYYY) | *"Enter the Date in the proper format (DD-MM-YYYY)"* shown; current action aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-004-ES-02** - Error codes 50025/50026 raised - *"Enter the Date in the proper format (DD-MM-YYYY)"*; current action is stopped.

**Step 3 - Non-numeric character entry detected and reported**
If the system raises error codes 40209 or 50016 (non-numeric character in a numeric field), the user is shown the message *"Characters/Special Characters are not allowed here, enter the numeric value"* and the current action is stopped.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-010](#SP-010--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the character-type error message (see Step 1 sub-bullets for routine logic).

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Non-numeric character in numeric field | Error codes 40209 or 50016 - ON-ERROR trigger (Form) | When the system raises a type-violation error as the user enters data | Prevent invalid characters from being entered in numeric fields and inform the user clearly | *"Characters/Special Characters are not allowed here, enter the numeric value"* shown; current action aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-004-ES-03** - Error codes 40209/50016 raised - *"Characters/Special Characters are not allowed here, enter the numeric value"*; current action is stopped.

**Step 4 - Field-level validation error reported using the error text**
If the system raises error code 40207 (field validation failed), the user is shown the error text returned by the system for that field and the current action is stopped.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-010](#SP-010--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the system-provided error text (see Step 1 sub-bullets for routine logic).

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Field validation error | Error code 40207 - ON-ERROR trigger (Form) | When a field validation check fails | Show the field-specific validation error text to the user | System error text shown (value of ERROR_TEXT at that moment); current action aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-004-ES-04** - Error code 40207 raised - the system-provided error text for the failed field is shown; current action is stopped.

**Step 5 - Database integrity constraint violation reported**
If a database-level child-record constraint violation occurs (database error -02292), the system raises a standardised internal error reference and stops the current action.

*Procedures called:*
- **GENERAL.RAISE_ERROR** ([SP-011](#SP-011--GENERAL.RAISE_ERROR)) - GENERAL.RAISE_ERROR - looks up the error message text for the given error code, selects the appropriate alert type (Error, Note, or Caution), displays the message to the user via GENERAL.DISP_TEXT, and raises a trigger failure to stop processing for Error-type messages.
    * **Step 1** - Accept the internal error code.
    * **Step 2** - Retrieve the error message text and type associated with that code.
    * **Step 3** - Compose the message text by prepending the error code to the retrieved message text.
    * **Step 4** - Based on the message type, select the dialogue title (Error, Note, or Caution) and display the composed message to the user.
    * **Step 5** - If the message type is an error, raise a trigger failure to stop the current processing.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Database child-record constraint violated | Database error -02292 - ON-ERROR trigger (Form) via GENERAL.RAISE_ERROR [SP-011] | When the user attempts an action that would violate a foreign-key or child-record integrity constraint | Prevent data integrity violations and present a meaningful business message | Standardised error message for constraint code E0088 shown; current action aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-004-ES-05** - Database error -02292 (child-record constraint) - standardised message for internal code E0088 shown; current action is stopped.

**Step 6 - Concurrent record-update conflict reported**
If error codes 40654, 40655, 40656, 40657, or 40659 are raised (another user has modified the same record), the user is shown the message *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*, the transaction is rolled back, and the current action is stopped.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-010](#SP-010--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the concurrent-update conflict message (see Step 1 sub-bullets for routine logic).

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Record modified by another user | Error codes 40654-40659 - ON-ERROR trigger (Form) | When a save or commit action is attempted after another user has already changed the same record | Protect data integrity and guide the user to re-query and re-apply their changes | *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"* shown; transaction rolled back; current action aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-004-ES-06** - Concurrent update conflict - *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*; transaction rolled back; current action stopped.

**Step 7 - Unrecognised database error reported using database error text**
If a database error other than those already handled above is detected (SQLCODE is not zero), the system displays the database error message text and rolls back the transaction.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-010](#SP-010--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the database error message text (SQLERRM at that point) to the user (see Step 1 sub-bullets for routine logic).

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Unrecognised database error | SQLCODE not zero - ON-ERROR trigger (Form) | When any unrecognised database error occurs | Ensure the user sees a meaningful diagnostic message for any unexpected database problem | The database error text (SQLERRM at that moment) shown; transaction rolled back; current action aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-004-ES-07** - Unrecognised database error - the database-provided error text (SQLERRM) is shown; transaction rolled back; current action stopped.

**Step 8 - Query-with-no-records errors silently suppressed**
If error codes 40401 or 40405 are raised (no records found for the query), the system silently suppresses the error and takes no action - the user is not shown any message and processing continues normally.

**Alternative Flows:**
- **BR-004-AF-01** - (from Step 8) Error codes 40401 or 40405 (no records returned by a query) are silently ignored; no message is shown and the screen remains fully operational.

---

---

#### Requirement ID: BR-005

**Requirement Title:** Custom Form Message Handling

**Business Description:**
When certain Oracle Forms system messages (codes 40209 or 40207) would otherwise be displayed in the standard Oracle Forms message banner, the system intercepts them and shows them instead in a user-friendly pop-up error dialogue. This replaces the less noticeable standard message banner with a dialogue the user is more likely to see and respond to.

**Actors:** Dealer User (message handler fires automatically on Forms system messages)

**Preconditions:**
- The Pre-Enquiry Dealer Report screen is open and a Forms system message is raised.

**Main Flow:**

**Step 1 - Message codes 40209 or 40207 intercepted and displayed as error dialogues**
When the Forms system raises message code 40209 or 40207, the system composes a message string from the error type, error code number, and error text (in the format: error-type, dash, error-number, colon, space, error-text) and displays it in an error dialogue to the user, then stops the current action.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-010](#SP-010--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the composed message text in an error alert (see BR-004 Step 1 sub-bullets for routine logic).

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Forms message codes 40209 or 40207 raised | Error codes 40209 or 40207 - ON-MESSAGE trigger (Form) | When the system is about to display a standard Forms message for these codes | Replace the low-visibility standard message banner with a prominent error dialogue | A composed message (error type + code + text) shown in an error dialogue; current action aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-ES-01** - Forms message codes 40209 or 40207 raised - composed message (error-type code concatenated with error text) shown in error dialogue; current action stopped.

---

---

#### Requirement ID: BR-006

**Requirement Title:** Campaign From Date Entry and Validation

**Business Description:**
When the user enters the start date for the campaign period they wish to report on, the system validates that the date has been provided, that it does not fall after today's date, and that it does not fall after the end date. Once the From Date passes those checks, the system automatically calculates and sets the campaign end date to either one month after the start date or today's date - whichever is earlier - so the user does not have to enter the end date manually.

**Actors:** Dealer User

**Preconditions:**
- The Pre-Enquiry Dealer Report screen is open.

**Main Flow:**

**Step 1 - Campaign From Date entered and mandatory check applied**
The user enters the campaign From Date. The system checks that a value has been supplied. If the field is left empty, the user sees an error and cannot proceed.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Campaign From Date must be provided | WHEN-VALIDATE-ITEM on CB_BLK.P_FROMDT - direct null check | When the user tabs off the Campaign From Date field | Ensure the report always has a valid start date | *"From Date can not be empty"* shown via GENERAL.DISP_TEXT; current action aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-006-ES-01** - Campaign From Date is empty - *"From Date can not be empty"*; current action is stopped.

**Step 2 - From Date checked against current date**
If a From Date has been provided, the system checks that it does not fall after today's date. A future start date is not allowed for this report.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Campaign From Date must not be in the future | WHEN-VALIDATE-ITEM on CB_BLK.P_FROMDT - comparison against current system date | When the user tabs off the Campaign From Date field | Prevent users from requesting a campaign report for a period that has not yet started | Alert message *"From Date cannot be greater than Current Date"* shown; current action aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-006-ES-02** - Campaign From Date is after today - alert *"From Date cannot be greater than Current Date"* shown; current action is stopped.

**Step 3 - From Date checked against To Date**
The system checks that the From Date does not fall after the currently entered To Date. A start date later than the end date is logically invalid.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Campaign From Date must not be after Campaign To Date | WHEN-VALIDATE-ITEM on CB_BLK.P_FROMDT - comparison of P_FROMDT with P_TODT | When the user tabs off the Campaign From Date field after a To Date has been entered | Prevent a date range where the start is later than the end | Alert message *"From Date cannot be greater than To Date"* shown; current action aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-006-ES-03** - Campaign From Date is after Campaign To Date - alert *"From Date cannot be greater than To Date"* shown; current action is stopped.

**Step 4 - Campaign To Date automatically calculated and set**
After all validations pass, the system calculates the end of the one-month period starting on the entered From Date (one month later minus one day). If that calculated date falls after today, the system sets the To Date to today's date; otherwise it sets it to the calculated month-end date. This auto-calculation means the user does not need to enter the To Date manually after entering a valid From Date.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| To Date auto-calculation - capped at today | WHEN-VALIDATE-ITEM on CB_BLK.P_FROMDT - ADD_MONTHS calculation then comparison with SYSDATE | Immediately after From Date validation passes | Automatically set a sensible default To Date (one calendar month from the From Date, not exceeding today) so the user can submit the report without manually entering the To Date | If calculated month-end exceeds today, To Date is set to today; otherwise To Date is set to the calculated month-end |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Campaign From Date (`P_FROMDT`) | Mandatory | Date | 10 / DD-MM-RRRR | N/A | N/A | Screen open | Must be provided; must not be after today; must not be after To Date | *"From Date can not be empty"*; *"From Date cannot be greater than Current Date"*; *"From Date cannot be greater than To Date"* |
| Campaign To Date (`P_TODT`) | Auto-populated | Date | 10 / DD-MM-RRRR | N/A | N/A | From Date validated | System-set to min(FromDate + 1 month - 1 day, today) | N/A (auto-calculated) |

---

---

#### Requirement ID: BR-007

**Requirement Title:** Campaign To Date Entry and Validation

**Business Description:**
When the user manually overrides the automatically set campaign end date, the system applies a comprehensive set of date-range validations: the To Date cannot be entered without a From Date already set; it cannot be less than the From Date; it cannot be after today; and the total date range cannot span more than three months. These rules ensure the report covers only a valid, supported reporting window.

**Actors:** Dealer User

**Preconditions:**
- The Pre-Enquiry Dealer Report screen is open and a Campaign From Date has already been entered.

**Main Flow:**

**Step 1 - To Date mandatory check applied**
The user enters the Campaign To Date. If the field is left empty, the system shows an error.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Campaign To Date must be provided | WHEN-VALIDATE-ITEM on CB_BLK.P_TODT - direct null check | When the user tabs off the Campaign To Date field | Ensure the report always has a valid end date | *"To Date can not be empty"* shown via GENERAL.DISP_TEXT; current action aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-007-ES-01** - Campaign To Date is empty - *"To Date can not be empty"*; current action is stopped.

**Step 2 - To Date checked for prerequisite From Date**
If the user has entered a To Date but has not yet entered a From Date, the system clears the To Date field and shows an error. A To Date without a From Date is not meaningful for the report.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| From Date must be entered before To Date | WHEN-VALIDATE-ITEM on CB_BLK.P_TODT - check that P_FROMDT is not null | When the user tabs off the To Date field | Enforce logical entry order - a date range requires both ends to be defined | *"To date cannot be entered without entering From date"* shown; To Date field cleared; current action aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-007-ES-02** - To Date entered without a From Date - *"To date cannot be entered without entering From date"*; To Date cleared; current action stopped.

**Step 3 - To Date checked: must not be less than From Date**
The system checks that the To Date is not earlier than the From Date.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| To Date must not be before From Date | WHEN-VALIDATE-ITEM on CB_BLK.P_TODT - comparison of P_TODT with P_FROMDT | When the user tabs off the To Date field | Prevent a negative date range | Alert message *"To Date cannot be lesser than From Date"* shown; current action aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-007-ES-03** - To Date is before From Date - alert *"To Date cannot be lesser than From Date"* shown; current action stopped.

**Step 4 - Cross-check: From Date must not be after To Date**
The system performs a symmetric check confirming the From Date is not after the To Date.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| From Date must not exceed To Date | WHEN-VALIDATE-ITEM on CB_BLK.P_TODT - comparison of P_FROMDT with P_TODT | When the user tabs off the To Date field | Double-check that the date range is in logical order | Alert message *"From Date cannot be greater than To Date"* shown; current action aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-007-ES-04** - From Date is after To Date (checked at To Date) - alert *"From Date cannot be greater than To Date"* shown; current action stopped.

**Step 5 - To Date checked against current date**
The system checks that the To Date does not fall after today's date.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| To Date must not be in the future | WHEN-VALIDATE-ITEM on CB_BLK.P_TODT - comparison against current system date | When the user tabs off the To Date field | Prevent requesting a report for a period not yet complete | Alert message *"To Date cannot be greater than Current Date"* shown; current action aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-007-ES-05** - To Date is after today - alert *"To Date cannot be greater than Current Date"* shown; current action stopped.

**Step 6 - Date range maximum span of three months enforced**
The system checks that the span between the From Date and the To Date does not exceed three calendar months minus one day. Reports spanning more than three months are not supported.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Date range must not exceed three months | WHEN-VALIDATE-ITEM on CB_BLK.P_TODT - comparison of P_TODT with ADD_MONTHS(P_FROMDT, 3)-1 | When the user tabs off the To Date field | Limit the report data range to at most three months to keep report generation feasible | Alert message *"Please give the date range of maximum three month"* shown; current action aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-007-ES-06** - Date range exceeds three months - alert *"Please give the date range of maximum three month"* shown; current action stopped.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Campaign To Date (`P_TODT`) | Mandatory | Date | 10 / DD-MM-RRRR | N/A | N/A | Campaign From Date entered | Must be provided; must not be before From Date; must not be after today; range must not exceed 3 months | *"To Date can not be empty"*; *"To date cannot be entered without entering From date"*; *"To Date cannot be lesser than From Date"*; *"From Date cannot be greater than To Date"*; *"To Date cannot be greater than Current Date"*; *"Please give the date range of maximum three month"* |
| Campaign From Date (`P_FROMDT`) | Mandatory | Date | 10 / DD-MM-RRRR | N/A | N/A | Screen open | Must be entered before To Date | *"To date cannot be entered without entering From date"*; To Date cleared |

---

---

#### Requirement ID: BR-008

**Requirement Title:** Pre-Enquiry Campaign Report Generation and Download

**Business Description:**
When the user clicks the Submit Report button after selecting a campaign period and optionally a specific campaign code, the system builds a comprehensive pre-enquiry campaign data extract. The extract covers all prospect pre-enquiry records for the selected dealer, location, and campaign code within the chosen date range. For each pre-enquiry record the report includes the region, campaign details, dealer information, prospect name and address, pre-enquiry follow-up status, any linked enquiry details (model, source, mode, prospect name, mobile number, enquiry status), and any resulting booking, invoice, and invoiced model details. The report is delivered as a CSV file that is transferred to the user's desktop and opened automatically.

**Actors:** Dealer User

**Preconditions:**
- The campaign reporting date range (From Date and To Date) has been entered and validated.
- A campaign code has been selected or "All Campaign Code" has been chosen to include all campaigns.

**Main Flow:**

**Step 1 - Report filename generated from user identity and current timestamp**
The system generates a unique output filename by combining the logged-in user's identifier with the current date and time, formatted as a CSV file name. This ensures that each report download has a distinct name.

**Step 2 - To Date adjusted to include the full end date in the query**
The system calculates an exclusive upper-bound date by adding one day to the To Date. This ensures the SQL data query correctly includes all records created on the To Date itself (up to midnight).

**Step 3 - Pre-enquiry data query constructed and executed**
The system builds a dynamic SQL query that selects one header row (containing column labels) followed by all pre-enquiry campaign records that match the current dealer, location, principal, and campaign code filters within the entered date range. The query joins the pre-enquiry campaign table to the dealer location master, enquiry header, enquiry detail, order booking, and invoice tables, and also looks up city name, enquiry type, enquiry source, enquiry status, and invoiced model for each record. All data is assembled into a single delimited string per row for CSV output. The query respects the campaign code filter: if a specific campaign code has been selected, only records for that code are included; if "All" was selected, all codes for the dealer are included. Similarly, the parent-group, dealer, and location values are filtered to the logged-in user's scope.

*Procedures called:*
- **VIEW_EXCEL_REPORT_NEW** ([SP-047](#SP-047--VIEW_EXCEL_REPORT_NEW)) - VIEW_EXCEL_REPORT_NEW - executes the prepared data query, writes the results to a CSV file on the application server, transfers the file to the user's desktop using the file transfer utility, and opens the file automatically. If a report server is configured for the current principal, the routine delegates CSV generation to a remote database procedure and retrieves the file from the server path before transferring it to the client. If the file path contains spaces the file is redirected to a default location.
    * **Step 1** - Look up the report server configuration for the current principal and application identifier.
    * **Step 2** - Determine the output filename; use the provided filename or prompt the user with a file-save dialogue if none is supplied.
    * **Step 3** - If a report server is available: delegate the CSV data generation to a remote database procedure, move the output file to the reports printer directory, read the base download URL from a configuration file, and transfer the file to the user's desktop using the file transfer utility. Open the file on the client.
    * **Step 4** - If no report server is available: execute the query using an in-memory record group, write each row to the output CSV file on the server file system, transfer the file to the user's desktop, and open the file on the client.
    * **Step 5** - If the file transfer fails, display a message indicating the transfer failed.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Report server configuration lookup | VIEW_EXCEL_REPORT_NEW [SP-047] - SELECT from EH_REPORTS table keyed on principal and application identifier | When the Submit Report button is pressed | Determine whether to use a dedicated report server or local in-memory generation for the CSV report | If no report server row is found, the routine proceeds with local in-memory report generation |
| File path must not contain spaces | VIEW_EXCEL_REPORT_NEW [SP-047] - INSTR check on the filename | When the output filename is determined | Prevent file-save failures caused by folder names with spaces in the path | If the path contains spaces, the file is saved to a default location (C:\ root) and the user is informed |
| File transfer to client | VIEW_EXCEL_REPORT_NEW [SP-047] - WebUtil file transfer result check | After the CSV file is generated and available on the server | Ensure the report reaches the user's desktop | If file transfer fails, the user sees "File Transfer failed" |

*Business outcomes (errors, warnings, success, and status):*
- **BR-008-IC-01** - Report server configured - the report is generated via the remote database procedure and transferred to the client desktop; file is opened automatically.
- **BR-008-IC-02** - No report server configured - the report is generated locally from the in-memory record group and transferred to the client desktop; file is opened automatically.
- **BR-008-WS-01** - File path contains spaces - *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."* shown; file stored at C:\ root.
- **BR-008-ES-01** - File transfer to client fails - *"File Transfer failed"* shown.

#### Business Scenarios - How the report generation differs by report server availability

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Report server is configured for the dealer's principal** | The CSV is generated by a remote database procedure; the output file is placed in the server's printer directory; the file is then transferred to the user's desktop. |
| **No report server is configured** | The data is loaded into an in-memory record group on the application server; the CSV is written directly to the server file system; then transferred to the user's desktop. |

**Alternative Flows:**
- **BR-008-AF-01** - (from Step 3) If the file transfer to the user's desktop fails, the message *"File Transfer failed"* is shown to the user and the file remains on the server; the report is not delivered.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Campaign From Date (`P_FROMDT`) | Mandatory | Date | 10 / DD-MM-RRRR | N/A | N/A | Screen open | Validated before submit | See BR-006 |
| Campaign To Date (`P_TODT`) | Mandatory | Date | 10 / DD-MM-RRRR | N/A | N/A | From Date validated | Validated before submit | See BR-007 |
| Campaign Code (`P_CAMPAIGN_CODE`) | Mandatory | Text | 100 | Campaign lookup (LV_CAMPAIGN / RG_CAMPAIGN) | Campaign code or 'ALL' | Screen open | Must be selected or default to ALL | N/A |
| Campaign Description (`P_CAMPAIGN_DESC`) | Auto-populated | Text | 100 | Campaign lookup (LV_CAMPAIGN / RG_CAMPAIGN) | Campaign name | Campaign Code selected | System-populated from LOV selection | N/A |
| Destination (`P_DESTYPE`) | Read-only display | List | N/A | N/A | N/A | Screen open | Read-only; not user-editable (enabled=false) | N/A |
| Report Description (`REPORT_DESC`) | Read-only display | Display | 200 | N/A | N/A | Screen open | Display field; not editable | N/A |

---

---

#### Requirement ID: BR-009

**Requirement Title:** Campaign List Population for Selection

**Business Description:**
The campaign code selection on the report screen is backed by a dynamically loaded list that shows all campaigns available for the logged-in dealer, location, and company. The list always includes an option to include all campaigns, followed by the distinct campaign codes and their descriptions applicable to the current user's context. This population happens when the Campaign Code field is used to select a campaign.

**Actors:** Dealer User

**Preconditions:**
- The Pre-Enquiry Dealer Report screen is open.
- The user is logged in with a valid dealer, location, and company context.

**Main Flow:**

**Step 1 - Campaign list populated from dealer and company context**
When the user opens the campaign code selection list, the system queries all distinct campaign codes and names for the logged-in dealer, location, and company, and adds an "All Campaign Code" option at the top of the list. The list is presented to the user for selection.

*Procedures called:*
- **L_POPULATE** (not catalogued in Section 21.1 - this is a form-level program unit; per R5 no SP-xxx bullet is emitted since L_POPULATE has no matching row in the Section 21.1 index)

> Note: The form-level program unit L_POPULATE drives the list population using a dynamic query against AM_LIST for general list lookups. However, the Campaign Code field (P_CAMPAIGN_DESC / P_CAMPAIGN_CODE) uses the record group RG_CAMPAIGN directly via the LOV LV_CAMPAIGN, which queries MULDMS.PRE_ENQ_CAMPAIGN joined with MULDMS.AM_DEALER_LOC and MULDMS.GM_REGN filtered to the logged-in dealer's context. L_POPULATE is a general-purpose utility for other list items and is not what populates the campaign LOV directly. Since L_POPULATE has no Section 21.1 entry, no Procedures called bullet is emitted for it.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Campaign Description (`P_CAMPAIGN_DESC`) | Mandatory | Text | 100 | Campaign Code lookup (LV_CAMPAIGN backed by RG_CAMPAIGN) | Campaign description | Screen open | Must be selected from the list; validated against list values | N/A |
| Campaign Code (`P_CAMPAIGN_CODE`) | Mandatory | Text | 100 | Campaign Code lookup (LV_CAMPAIGN backed by RG_CAMPAIGN) | Campaign code (returned from LOV) | Screen open | Must match a valid campaign code or 'ALL' | N/A |

---

---

#### Requirement ID: BR-010

**Requirement Title:** Inactive Program Units (Non-Executing Code)

**Business Description:**
The form contains two program units that are fully commented out and do not execute under any circumstances. These represent logic that was written for an earlier version of the form (test-drive validation and pre-enquiry delete check) but was disabled before the form was deployed. The copyright-related note below describes their original intent for documentation purposes only.

**Actors:** N/A (code does not execute)

**Preconditions:** N/A

**Main Flow:**

**Step 1 - VALIDATE_CN_MAIN (COMMENTED OUT / INACTIVE - does not execute)**
This program unit was designed to validate test-drive entry fields (plate number, model year, actual test-drive date, from/to times, location, sales consultant, odometer readings, and booking conversion flag) before saving. It has been entirely commented out and no longer runs. All validation messages within it (such as date/time checks and odometer comparisons) are inactive and never shown to users.

**Step 2 - CHECK_BEFORE_DELETE (COMMENTED OUT / INACTIVE - does not execute)**
This program unit was designed to prevent deletion of a record if child records existed in the enquiry table. It has been entirely commented out (replaced by `NULL;`) and does not run. The message *"Cannot Delete. Records exists in Enquiry"* within it is inactive and never shown.

---

---

---

#### Requirement ID: BR-011

**Requirement Title:** Campaign Record Deletion

**Business Description:**
When the user clicks the Delete toolbar button while the cursor is positioned in the campaign data block, the system asks for explicit confirmation before removing the record. This prevents accidental deletion of campaign records and ensures the user has a deliberate opportunity to cancel. If the user confirms, the system deletes the current record from the database.

**Actors:** Dealer User

**Preconditions:**
- The Pre-Enquiry Dealer Report screen is open.
- The cursor is positioned in the campaign data block.
- The Delete toolbar button is enabled.

**Main Flow:**

**Step 1 - Delete confirmation requested before record removal**
When the user clicks the Delete button on the toolbar and the cursor is in the campaign data block, the system temporarily suspends form-level validation and asks the user to confirm the deletion. If the user confirms, the system deletes the current record. If the user declines, no deletion is performed and the record remains unchanged.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| User must confirm deletion before record is removed | FT_DEL - GENERAL.ASK_CONFIRM check; DELETE_RECORD executed only if confirmation returns 1 | When the user clicks the Delete toolbar button with the cursor in the campaign data block | Prevent accidental data loss by requiring explicit user confirmation before a record is permanently deleted | *"Are you sure to Delete?"* shown; record deleted only if confirmed; no change if declined |

*Business outcomes (errors, warnings, success, and status):*
- **BR-011-IC-01** - User confirms deletion - record is deleted from the database.
- **BR-011-IC-02** - User declines deletion - no record is removed; screen returns to normal state.

**Alternative Flows:**
- **BR-011-AF-01** - (from Step 1) If the Delete toolbar button is not enabled, or the cursor is not in the campaign data block, no action is taken and no message is shown.

---

## 5. Business Rules Catalogue

Catalogue of the discrete business rules enforced by the form's code.

| Rule ID | Rule Name | Rule Type | Business Requirement ID | Condition | Action | Business Impact |
| ------- | --------- | --------- | ----------------------- | --------- | ------ | --------------- |
| BRC-001 | Campaign From Date is mandatory | Validation | BR-006 | Campaign From Date field is left empty when the user tabs off it | Block further action and show *"From Date can not be empty"* to the user | Ensures every report request has a valid start date; no report can be generated without one |
| BRC-002 | Campaign From Date must not be in the future | Validation | BR-006 | Campaign From Date entered is after today's date | Block further action and show alert *"From Date cannot be greater than Current Date"* | Prevents requesting a report for a campaign period that has not yet begun |
| BRC-003 | Campaign From Date must not be after Campaign To Date | Validation | BR-006 | Campaign From Date is later than the currently entered Campaign To Date | Block further action and show alert *"From Date cannot be greater than To Date"* | Ensures the reporting date range is chronologically valid |
| BRC-004 | Campaign To Date auto-calculated after valid From Date | Derivation | BR-006 | Campaign From Date passes all validations | Set Campaign To Date to one calendar month minus one day after From Date, capped at today's date if the calculated date falls in the future | Provides a convenient default end date so the user does not have to enter it manually; caps the default at today to avoid future dates |
| BRC-005 | Campaign To Date is mandatory | Validation | BR-007 | Campaign To Date field is left empty when the user tabs off it | Block further action and show *"To Date can not be empty"* | Ensures every report request has a valid end date |
| BRC-006 | Campaign From Date must be entered before Campaign To Date | Validation | BR-007 | User enters a To Date without having entered a From Date | Block further action, clear the To Date field, and show *"To date cannot be entered without entering From date"* | Enforces logical entry order and prevents an incomplete date range from being submitted |
| BRC-007 | Campaign To Date must not be before Campaign From Date | Validation | BR-007 | Campaign To Date entered is earlier than Campaign From Date | Block further action and show alert *"To Date cannot be lesser than From Date"* | Prevents an inverted date range where the end precedes the start |
| BRC-008 | Campaign From Date must not exceed Campaign To Date (To Date perspective) | Validation | BR-007 | Campaign From Date is later than the Campaign To Date (checked when To Date is entered) | Block further action and show alert *"From Date cannot be greater than To Date"* | Second-pass confirmation that the date range is in logical order |
| BRC-009 | Campaign To Date must not be in the future | Validation | BR-007 | Campaign To Date entered is after today's date | Block further action and show alert *"To Date cannot be greater than Current Date"* | Prevents requesting data for a period not yet complete |
| BRC-010 | Campaign date range must not exceed three months | Constraint | BR-007 | Campaign To Date is more than three calendar months minus one day after Campaign From Date | Block further action and show alert *"Please give the date range of maximum three month"* | Limits report data volume to a supported maximum window of three months |
| BRC-011 | Invalid date value must be reported clearly | Validation | BR-004 | Oracle Forms raises system error 50004 (invalid date value) during data entry | Intercept the error and show *"Entered Date is not valid Date"*; stop the current action | Replaces a cryptic system error with a plain-language message the user can act on |
| BRC-012 | Incorrect date format must be reported clearly | Validation | BR-004 | Oracle Forms raises system error 50025 or 50026 (date format violation) | Intercept the error and show *"Enter the Date in the proper format (DD-MM-YYYY)"*; stop the current action | Guides the user to enter dates in the expected DD-MM-YYYY format |
| BRC-013 | Non-numeric characters in numeric fields must be rejected | Validation | BR-004 | Oracle Forms raises system error 40209 or 50016 (character type violation in a numeric field) | Intercept the error and show *"Characters/Special Characters are not allowed here, enter the numeric value"*; stop the current action | Prevents invalid data types from being entered in numeric fields |
| BRC-014 | Field validation failure must display the system error text | Validation | BR-004 | Oracle Forms raises system error 40207 (field validation failed) | Display the error text returned by the system for that field; stop the current action | Ensures the specific validation failure message for that field is shown rather than a generic error |
| BRC-015 | Database integrity constraint violation must trigger standardised error | Validation | BR-004 | Database error -02292 (child-record constraint violation) is raised | Raise standardised internal error E0088 via GENERAL.RAISE_ERROR; stop the current action | Protects referential integrity and provides a consistent, business-meaningful error message |
| BRC-016 | Concurrent record-update conflict must be reported and rolled back | Validation | BR-004 | Oracle Forms raises error codes 40654, 40655, 40656, 40657, or 40659 (concurrent update conflict) | Show *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*; roll back the transaction; stop the current action | Prevents data corruption from concurrent updates and instructs the user how to recover |
| BRC-017 | Unrecognised database error must be displayed and rolled back | Validation | BR-004 | SQLCODE is not zero and the error does not match any specifically handled code | Display the database error text (SQLERRM); roll back the transaction; stop the current action | Ensures any unexpected database problem is visible to the user and leaves the database in a consistent state |
| BRC-018 | No-records-found query errors are silently suppressed | Constraint | BR-004 | Oracle Forms raises error codes 40401 or 40405 (no records returned by a query) | Suppress the error silently; take no action | Prevents harmless "no data" messages from interrupting the user's workflow |
| BRC-019 | Session module identity must be registered on form open | Derivation | BR-001 | Pre-Enquiry Dealer Report screen is opened | Register the form name as the active module and client info in the database session tracking system | Enables database-level monitoring and activity tracing for this screen |
| BRC-020 | Performance timer started if application logging is active | Constraint | BR-001 | Screen opens and the application logging global is set to active | Start the performance timer to record screen load time | Supports performance monitoring and diagnosis when logging is enabled |
| BRC-021 | Session identity must be cleared on form exit | Derivation | BR-002 | User presses the exit key | Clear the client-info and module-name identifiers in the database session tracking system before closing | Ensures the database session tracking register is left in a clean state when the user leaves the screen |
| BRC-022 | Copyright declaration refreshed on form clear | Derivation | BR-003 | User presses the clear-form key | After clearing all fields, re-populate the copyright declaration display field by calling the copyright declaration function | Keeps the copyright notice current and correctly reflecting the logged-in company context after every clear operation |
| BRC-023 | Report filename must be unique per user and time | Derivation | BR-008 | User submits the report request | Generate a filename combining the logged-in user identifier and the current date-time stamp | Prevents filename collisions when the same user submits multiple reports in the same session |
| BRC-024 | Report date range upper bound adjusted for inclusive end date | Derivation | BR-008 | User submits the report request | Add one day to the Campaign To Date to form the exclusive upper bound used in the data query | Ensures that all records created on the To Date itself are included in the report output |
| BRC-025 | Report content filtered by logged-in dealer and principal context | Constraint | BR-008 | User submits the report request | Restrict the data query to records matching the logged-in dealer, location, parent group, and company principal | Prevents a dealer user from seeing data belonging to other dealers or companies |
| BRC-026 | Campaign code filter applied to report when a specific code is selected | Constraint | BR-008 | User selects a specific campaign code (not "All") before submitting | Restrict the data query to records matching that campaign code only | Allows the user to narrow the report to a single campaign for focused analysis |
| BRC-027 | File path spaces redirect file to default location | Constraint | BR-008 | The generated output filename or path contains one or more space characters | Save the file to the C:\ root directory instead and inform the user | Prevents file-save failures caused by folder names with spaces in the path |

**Total Business Rules Identified: 27**

---

## 6. Data Requirements

*This section describes the data entities, capture requirements, reference data, and lifecycle behaviour for the Pre-Enquiry Dealer Report form (RR_PRE_ENQ_DLR). The form is a reporting-only screen with no base tables of its own; it reads from several operational tables to construct a CSV extract.*

### 6.1 Business Entities and Relationships

*The form reads data from multiple operational tables to assemble the pre-enquiry campaign report; it does not persist any records of its own.*

#### Pre-Enquiry Campaign - MULDMS.PRE_ENQ_CAMPAIGN

The pre-enquiry campaign table is the primary data source for the report. It stores prospect records created from marketing campaign activities at dealer locations - each record links a prospect (name, address, follow-up status) to a campaign code, dealer, location, and parent group. The report reads from this table and joins it to the dealer location, enquiry, order, and invoice tables to produce a full prospect-to-sale tracing report.

#### Dealer Location Master - MULDMS.AM_DEALER_LOC

This table holds dealership location records, including region code, dealer name, city code, and principal mapping. The report joins it to each pre-enquiry campaign record to obtain the dealer's region and name for the output.

#### City Master - MULDMS.GM_CITY

This lookup table translates a city code into a city description. The report uses it to show the dealer's city name rather than the raw code.

#### Enquiry Header - MULDMS.RH_ENQ

The enquiry header table holds customer enquiry records associated with a pre-enquiry campaign record. The report optionally joins it (outer join) to show enquiry number, enquiry date, enquiry source, prospect name, mobile number, and the date the enquiry status last changed.

#### Enquiry Detail - MULDMS.RD_ENQ

This table holds the model variant details for a linked enquiry. The report selects the model description and enquiry status for the first enquiry variant line.

#### Enquiry Type Master - MULDMS.RM_ETYPES

This lookup table translates an enquiry type code into a description for the report output.

#### Enquiry Source List - AM_LIST

This list-of-values table is used to translate the enquiry source code into a readable description. The report queries it filtered to the `ENQUIRY_SOURCE` list name and the current principal.

#### Order Booking - MULDMS.SH_ORDBOOK

When an enquiry leads to a booking, the order booking table holds the order date and order number. The report uses this to show the booking date for a pre-enquiry prospect.

#### Invoice - MULDMS.SH_INVOICE (joined via SH_ORDBOOK)

The invoice table, joined through the order booking record, provides the invoice date and invoiced model details. The report includes the invoice date and invoiced model description when the invoice type is a vehicle or vehicle cash sale and the invoice has been completed.

#### Model Master - GM_MOD / MULDMS.GM_VAR (via enquiry and invoice joins)

These model and variant master tables supply the model description for both the enquiry's selected model and the invoiced model.

#### Region Master - MULDMS.GM_REGN

This table is queried in the campaign code list (record group RG_CAMPAIGN) to link dealer locations to their region codes.

#### Report Server Configuration - EH_REPORTS

This configuration table holds the report server identifier for a given principal and application. VIEW_EXCEL_REPORT_NEW queries it to determine whether to use a report server or local generation for the CSV output.

#### Entity Relationships

The Pre-Enquiry Campaign record is the root entity. Each campaign record may optionally link to one enquiry header (and through it to enquiry detail, order, and invoice). The dealer location master provides dimensional data for region, dealer name, and city.

```
MULDMS.PRE_ENQ_CAMPAIGN (x)
    ├── MULDMS.AM_DEALER_LOC (am)        <- dealer_map_cd + loc_cd join
    │       └── MULDMS.GM_CITY           <- city_cd lookup
    ├── MULDMS.RH_ENQ (rh)               <- outer join on enq_num + dealer_map_cd + loc_cd + comp_fa
    │       ├── MULDMS.RD_ENQ            <- enq_num + enq_var_srl=1 (model + status)
    │       ├── MULDMS.RM_ETYPES         <- etype_cd lookup
    │       ├── AM_LIST                  <- enq_source lookup (ENQUIRY_SOURCE)
    │       ├── MULDMS.SH_ORDBOOK (ord)  <- enq_num + order_date >= enq_date
    │       │       └── MULDMS.SH_INVOICE (inv) <- order_num + bill_nature + inv_status='I'
    │       │               ├── GM_VAR   <- variant_cd join
    │       │               └── GM_MOD   <- model_cd join (invoiced model)
    │       └── GM_MOD                   <- model_cd join (enquiry model via RD_ENQ)
```

### 6.2 Data Capture Requirements

*The form captures report filter parameters only - no transactional data is entered or saved. All captured values are used as query inputs to generate the CSV export.*

#### Report Filter Parameters - User Inputs at Report Request Time

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Campaign From Date (`P_FROMDT`) | Yes | The start date of the campaign period to include in the report. Entered by the user in DD-MM-YYYY format. | Must not be empty; must not be after today; must not be after the To Date. Format mask DD-MM-RRRR enforced. |
| Campaign To Date (`P_TODT`) | Yes | The end date of the campaign period. Automatically set to one month after the From Date (capped at today) when the From Date is entered; can be overridden by the user. | Must not be empty; must not be before From Date; must not be after today; range must not exceed three months. Format mask DD-MM-RRRR enforced. |
| Campaign Description / Code (`P_CAMPAIGN_DESC` / `P_CAMPAIGN_CODE`) | Yes | The campaign to report on. The user selects a campaign description from the campaign list; the system stores the corresponding campaign code. Selecting "All Campaign Code" includes all campaigns for the dealer. | Must be selected from the campaign list; validated against list values (ValidateFromList=true on P_CAMPAIGN_CODE). |

#### Session / Non-Database Parameters

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Application Identifier (`P_APP_ID`) | Auto-Populated | Module parameter passed to the form at invocation; used by VIEW_EXCEL_REPORT_NEW to look up the report server configuration for this application. | Passed at form call; not editable by the user. |
| Destination (`P_DESTYPE`) | Auto-Populated | Display-only list field showing the report destination type. Enabled is set to false; not user-editable. | Read-only; system-managed. |
| Copyright Declaration (`COPYRIGHT_DECLARATION`) | Auto-Populated | Display field showing the copyright notice for the logged-in company. Populated at form open and refreshed on every form clear via SF_COPYRIGHT_DECLARATION. | Read-only; system-managed. |
| Report Description (`REPORT_DESC`) | Auto-Populated | Display field for the report title or description. Read-only. | Display field; not editable. |

### 6.3 Reference Data

*Lists the master and configuration data referenced by this form (LOVs, record groups, master tables). LOVs are documented here - not as separate Section 4 BRs.*

| Reference Data | Business Purpose | Used When |
| :--- | :--- | :--- |
| Campaign Code lookup (LV_CAMPAIGN / RG_CAMPAIGN - MULDMS.PRE_ENQ_CAMPAIGN, MULDMS.AM_DEALER_LOC, MULDMS.GM_REGN) | Provides the list of distinct campaign codes and names for the logged-in dealer, location, and principal; includes an "All Campaign Code" option at the top | When the user selects a campaign code to filter the report |
| Enquiry Source list (AM_LIST, list_name = 'ENQUIRY_SOURCE') | Translates enquiry source codes to readable descriptions in the report output | When the report query assembles the enquiry source column for each record |
| City Master (MULDMS.GM_CITY) | Provides the city description for the dealer's city code | When the report query assembles the dealer city column |
| Enquiry Type Master (MULDMS.RM_ETYPES) | Provides the enquiry type description for the enquiry type code | When the report query assembles the enquiry mode column |
| Model Master (GM_MOD) | Provides model descriptions for enquiry model and invoiced model | When the report query assembles the enquiry model and invoiced model columns |
| Region Master (MULDMS.GM_REGN) | Used in the campaign LOV query to join dealer locations to regions | When the campaign code list is populated for the current dealer |
| Report Server Configuration (EH_REPORTS) | Holds the report server identifier for a given principal and application; determines the CSV generation path | When the Submit Report button is pressed and VIEW_EXCEL_REPORT_NEW looks up the generation method |

### 6.4 Data Lifecycle

*Describes how data is managed within this form's evidenced behaviour. This form is a reporting-only screen; it reads existing operational records and exports a CSV file. No records are created, updated, or deleted by this form.*

**Creation**

- No records are created by this form. The form generates a CSV file as an output artefact; the file is created on the server file system by VIEW_EXCEL_REPORT_NEW and transferred to the user's desktop, but no database rows are inserted.

**Updates**

- No database records are updated by this form. The Session module identity registered in the database session tracking system (DBMS_APPLICATION_INFO) is updated at form open and cleared at form exit, but this is a session-level Oracle built-in with no persistent table write.

**Save and Commit**

- There is no save or commit action on this form. The KEY-COMMIT trigger is inactive (code body is `NULL;` - COMMENTED OUT / INACTIVE - does not execute). The form does not persist any user-entered data to the database.
- On exit (KEY-EXIT), the form closes without saving, discarding any entered filter values.

**Retention and Audit**

- No audit or retention behaviour is implemented within this form. The operational tables queried (PRE_ENQ_CAMPAIGN, RH_ENQ, etc.) maintain their own records independently of this form. No archival or purge logic is present in the form.

---

### 6.5 Excel Output Columns

Excel download columns produced by this form, with when each Excel is produced (report / principal path), filters that limit which rows are included, and the database source for each value. Column sets vary by export path (for example app_id, principal, and enquiry-date mode); the rows below are evidenced layouts, not a guaranteed list for every combination. Blank Table/Database means the physical column was not proven in source.

| # | What the user selects on screen | Excel column name | When this Excel is produced | Table name | Database column | Logic |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | PRINCIPAL | Region |  | AM_LIST | REGION_CD | Shows the Region taken from the enquiry's related records. |
| 2 | PRINCIPAL | Campaign Code |  | PRE_ENQ_CAMPAIGN | CAMPAIGN_CODE | Campaign code for the pre-enquiry record sourced directly from the campaign master table (alias x). |
| 3 | PRINCIPAL | Campaign Name |  | PRE_ENQ_CAMPAIGN | CAMPAIGN_NAME | Campaign name from the campaign master; commas replaced with spaces for CSV safety. |
| 4 | PRINCIPAL | Campaign Loading Date |  | PRE_ENQ_CAMPAIGN | CREATED_DATE | Date the campaign record was loaded into the system, taken from the campaign master creation date. |
| 5 | PRINCIPAL | Campaign Model |  | PRE_ENQ_CAMPAIGN | TARGET_MODEL | Target vehicle model associated with the campaign as stored on the campaign master. |
| 6 | PRINCIPAL | Dealer Code |  | PRE_ENQ_CAMPAIGN | DLR_CODE | Dealer code recorded on the pre-enquiry campaign record. |
| 7 | PRINCIPAL | For Code |  | PRE_ENQ_CAMPAIGN | FOR_CODE | For-code field on the pre-enquiry campaign record, indicating the purpose or category classification. |
| 8 | PRINCIPAL | Dealer Name |  | AM_LIST | LIST_DESC | Shows the Dealer Name taken from the enquiry's related records. |
| 9 | PRINCIPAL | Delr City |  | GM_CITY | CITY_DESC | Shows the Delr City taken from the enquiry's related records. |
| 10 | PRINCIPAL | Pre-Enq Prospect Name |  | PRE_ENQ_CAMPAIGN | CUSTOMER_NAME | Prospect customer name from the pre-enquiry campaign record; commas replaced with spaces for CSV safety. |
| 11 | PRINCIPAL | Pre-Enq Prospect Address |  | PRE_ENQ_CAMPAIGN | ADDRESS1 | Concatenation of address lines 1, 2 and 3 from the pre-enquiry campaign record; commas replaced with spaces for CSV safety. |
| 12 | PRINCIPAL | Status of Pre-Enq |  | PRE_ENQ_CAMPAIGN | FOLLOWUP | Follow-up status code on the campaign record decoded to a readable label (Interested, Call Back, Not Interested, Not Reachable, Wrong Number). |
| 13 | PRINCIPAL | Remarks |  | PRE_ENQ_CAMPAIGN | REASON | Remark or reason text recorded on the pre-enquiry campaign record; commas replaced with spaces for CSV safety. |
| 14 | PRINCIPAL | Enquiry Num |  | RH_ENQ | ENQ_NUM | Enquiry number from the enquiry header record linked to the pre-enquiry campaign via outer join. |
| 15 | PRINCIPAL | Enquiry date |  | RH_ENQ | ENQ_DATE | Date the formal enquiry was raised, sourced from the enquiry header record. |
| 16 | PRINCIPAL | Enq. Source |  | RM_ETYPES | ETYPE_DESC | Shows the Enq. Source taken from the enquiry's related records. |
| 17 | PRINCIPAL | Enq. Mode |  | AM_LIST | LIST_DESC | Shows the Enq. Mode taken from the enquiry's related records. |
| 18 | PRINCIPAL | Enq. Prospect Name |  | RH_ENQ | ENQ_NAME | Full prospect name built by concatenating first name (ENQ_NAME), middle name and last name from the enquiry header; commas replaced with spaces for CSV safety. |
| 19 | PRINCIPAL | Mobile Number |  | RH_ENQ | MOBILE | Prospect mobile contact number from the enquiry header record. |
| 20 | PRINCIPAL | Status of Enquiry |  | RD_ENQ | ENQ_STATUS | Shows the Status of Enquiry taken from the enquiry's related records. |
| 21 | PRINCIPAL | Lost/Dropped Date |  | RH_ENQ | ENQ_CHANGE_DATE | Date the enquiry status was last changed to Lost or Dropped, sourced from the enquiry header change-date column. |
| 22 | PRINCIPAL | Invoice Date |  | SH_ORDBOOK | INV_DATE | Shows the Invoice Date taken from the enquiry's related records. |

## 7. Glossary

*Definitions of terms, abbreviations, and acronyms used throughout this document.*

The following table defines key terms, acronyms, and abbreviations used throughout this Business Requirements Document.

| Term | Definition | Aliases | Related Terms |
| :--- | :--- | :--- | :--- |
| AL_CONFIRM | Alert dialog used to prompt the user for Yes/No confirmation before a destructive action | Confirm Alert | Alert, AL_ERRINFO, AL_NOTE |
| AL_ERRINFO | Oracle Forms alert object used to display error-level messages to the user | Error Alert | Alert, DISP_TEXT |
| AL_NOTE | Oracle Forms alert object used to display informational or note-level messages | Note Alert | Alert, DISP_TEXT |
| AL_PRINT | Oracle Forms alert object used to ask the user to choose a print destination (Screen, Printer, or Cancel) | Print Alert | ASK_PRINT, Alert |
| AM_LIST | Application master list database table storing lookup values keyed by list name and principal map code | - | Principal, LOV, Record Group |
| ASK_PRINT | DPL shared library function that shows the AL_PRINT dialog and returns the user's print destination choice | - | DPL, AL_PRINT, PROC_REPORT_CALL |
| BTN | Button - a non-database form item that triggers an action when clicked | Button | SUBMIT, Item |
| Campaign | A marketing campaign defined in the pre-enquiry campaign master, linking dealers to targeted prospects and vehicle models | - | Pre-Enquiry, Prospect, Campaign Code |
| Campaign Code | Unique identifier for a pre-enquiry marketing campaign used to filter report data | - | Campaign, RG_CAMPAIGN |
| CB_BLK | Control block - the only data block in rr_pre_enq_dlr; holds filter fields and the Submit button; not bound to a database table | Control Block | Block, Item |
| CHECK_NULL | DPL library procedure that raises a validation failure if a supplied field value is null | - | DPL, Validation, DISP_TEXT |
| DMS | Dealer Management System - the integrated software platform for dealership operations in which rr_pre_enq_dlr runs | - | Dealer, Principal |
| DPL | Shared Oracle Forms program library (DPL.pld) providing common utility procedures and functions used across DMS forms | GENERAL | PLD, Library |
| DISP_TEXT | DPL library procedure that displays a text message to the user in an error or note alert dialog | - | DPL, AL_ERRINFO, AL_NOTE |
| Dealer | An automotive dealer entity identified by dealer code and location code, scoped to a parent group and principal | - | Dealer Code, Location, DMS |
| Dealer Code | Unique code identifying a dealership within the DMS; used to filter campaign and report data | - | Dealer, Location Code |
| Enquiry | A sales enquiry raised in the DMS linking a prospect to a vehicle model, source, and current status | RH_ENQ | Pre-Enquiry, Prospect, Enquiry Status |
| Enquiry Status | Status code indicating the current stage of an enquiry (Hot, Warm, Cold, Lost, Dropped, Postponed, Invoiced, Order) | - | Enquiry, Invoice |
| Excel Report | The output format of the rr_pre_enq_dlr report; a CSV file downloadable through the browser | CSV | Report, SUBMIT |
| From Date | The start date of the report date range; must not be null, future, or greater than To Date | P_FROMDT | To Date, Date Range |
| Invoice | A vehicle invoice record in the DMS indicating a completed vehicle sale linked to an order and enquiry | - | Order, Enquiry |
| LOV | List of Values - a popup selection list in Oracle Forms used to choose a value for a form field | Dropdown, Picklist | Record Group, LV_CAMPAIGN |
| Location Code | Code identifying the physical dealer location within the DMS; used with dealer code to scope report data | LOC_CD | Dealer Code, Dealer |
| LV_CAMPAIGN | The campaign LOV object in rr_pre_enq_dlr, bound to RG_CAMPAIGN; allows the user to pick a campaign code | Campaign LOV | LOV, RG_CAMPAIGN |
| MULDMS | Database schema prefix for core DMS tables (e.g. MULDMS.AM_DEALER_LOC, MULDMS.GM_CITY) | - | Schema, DMS |
| Order | A vehicle order booking record in the DMS linking a prospect enquiry to a final sale | Booking | Enquiry, Invoice |
| Parent Group | Multi-company grouping code used to scope dealers and campaigns across company boundaries | PARENT_GROUP | Dealer, Principal |
| PLD | Oracle Forms program library (`.pld` file) containing shared PL/SQL procedures and functions linked to one or more forms | Program Library | DPL, Webutil |
| Pre-Enquiry | An initial customer contact or prospect record captured as part of a campaign before a formal enquiry is raised | Prospect | Campaign, Enquiry |
| Principal | The vehicle manufacturer or principal organisation whose products and campaigns are managed in the DMS; identified by principal map code | Manufacturer | Dealer, Campaign, MULDMS |
| RAISE_ERROR | DPL library procedure that looks up an error message by code and displays it; raises form failure for error-type messages | - | DPL, DISP_TEXT, ON-ERROR |
| Record Group | An Oracle Forms data structure that holds the query result set used to populate a LOV | - | LOV, RG_CAMPAIGN |
| RG_CAMPAIGN | The record group in rr_pre_enq_dlr that holds the campaign lookup query result; supplies data to LV_CAMPAIGN | - | Record Group, LV_CAMPAIGN |
| To Date | The end date of the report date range; must not be null, future, earlier than From Date, or more than three months after From Date | P_TODT | From Date, Date Range |
| Webutil | Oracle Forms WebUtil library (webutil.pld / webutil.olb) providing client-side utilities and handle operations | WEBUTIL | PLD, ID_NULL |

---

---

## 8. Technical Inventory

*Complete inventory of Oracle Forms components including blocks, items, triggers, canvases, and global variables.*

### 8.1 Form Architecture

**Form Module Details:**

- Form Name: rr_pre_enq_dlr (RR_PRE_ENQ_DLR)
- Form Module XML Title: MODULE2
- Oracle Forms Version: 12c (Module version 122010400)
- Parent Object Library: DPL.olb (PC_FORM property class)
- Attached Libraries: WEBUTIL (webutil.olb), D2KWUTIL, DMS_EXCEL_REPORT, DPL (DPL.pld program library)
- First Navigation Block: -
- Console Window: WN_MAIN - Pre-Enquiry Dealer Report
- Compile Dependencies: Requires DPL.olb, DPL.pld, WEBUTIL.olb, menu.mmx
- Source artifacts: `rr_pre_enq_dlr_fmb.xml`; OLB `DPL.olb`; WEBUTIL (webutil.olb); D2KWUTIL; DMS_EXCEL_REPORT; DPL (DPL.pld program library)

### 8.1.1 Global Variables

| Global Variable | Data Type | Set Location | Purpose |
| :--- | :--- | :--- | :--- |
| APP_ID | Char | Trigger | Application identifier passed at form launch; used to construct the Excel report output request and session context |
| APP_LOG | Char | Trigger | Application logging flag; when set to 'Y' the form starts a performance timer on open |
| COMP_FA | Char | Trigger | Company financial authority code; set at session initialisation and used to scope financial data access |
| CURRENCY | Char | Trigger | Currency code for the current session; used to format monetary values in report output |
| CUR_DATE | Date | ProgramUnit | Current business date used as upper bound in date validations |
| DEALER | Char | ProgramUnit / RecordGroup / Trigger | Dealer code used to filter campaign and report data for the current dealer |
| FIN_BEG | Char | Trigger | Financial year begin date for the current session; used to bound date range defaults and validations |
| FIN_END | Char | Trigger | Financial year end date for the current session; used to bound date range defaults and validations |
| LOC_CD | Char | RecordGroup / Trigger | Location code used to filter campaign records and report output by dealer location |
| PARENT_GROUP | Char | RecordGroup / Trigger | Parent group (multi-company) identifier used to scope campaign and dealer queries |
| PRINCIPAL | Char | ProgramUnit / RecordGroup / Trigger | Principal/manufacturer map code used to filter campaigns, models, and dealer data |
| P_FIN_YR | Char | Trigger | Current financial year label; passed to report queries to restrict output to the active financial year |
| REP_SERVER | Char | Trigger | Report server name or URL used to route Excel/CSV report generation requests |
| TALLY_INTEGRATION | Char | Trigger | Flag indicating whether Tally accounting integration is active for the current session |
| USERID | Char | Trigger | Logged-in user identifier prefixed to the generated report filename |
| USER_NAME | Char | Trigger | Display name of the logged-in user; used in report headers and session audit fields |

### 8.1.2 Form Parameters

*All 9 ModuleParameter entries from rr_pre_enq_dlr_fmb.xml.*

| Parameter | Data Type | Default | Description |
| :--- | :--- | :--- | :--- |
| P_APP_ID | Char | - | Application identifier passed at form launch; used to construct the Excel report output request |
| ENQ_DATE | Date | - | Enquiry reference date passed from the calling module; used as a default date reference in report filtering |
| P_CHECK | Number | 0 | Numeric check flag passed at startup; reserved for controlling conditional form behaviour |
| TB | Number | 0 | Toolbar state indicator passed at startup; reserved for toolbar visibility control |
| PR_REMARK | Char | - | Pre-enquiry remark passed from the calling context; available as a report parameter |
| CHECK_MAND | Char | N | Mandatory-field check flag; when 'N' optional validations are relaxed at form load |
| P_USER_TYPE | Char | DLR | User type qualifier; defaults to 'DLR' (dealer) to scope report data to dealer-level access |
| P_REGION | Char | - | Region code passed from the parent screen; used to restrict report output to a specific region |
| P_USER_HORO | Char | - | User home region or hierarchy override code; passed from the calling module for access-scoping purposes |

**Total Parameters:** 9

### 8.2 Blocks

| Block Name | Query Data Source | Records | Q/I/U/D | Key Mode | Master-Detail Relationship |
| :--- | :--- | :--- | :--- | :--- | :--- |
| CB_BLK | - | 1 | N/N/N/N | Default | Control - entry point for report date range and campaign filter selection |

**Total Blocks:** 1 business blocks

### 8.2.1 Block WhereClause and OrderByClause

*Block query scope from rr_pre_enq_dlr_fmb.xml. **Description** explains filter and sort in business terms; **Order By** and **Where Clause** columns retain verbatim XML text for migration.*

| Block | Description | Order By (XML) | Where Clause (XML) |
| :--- | :--- | :--- | :--- |
| - | No blocks with WhereClause/OrderByClause in rr_pre_enq_dlr_fmb.xml | - | - |

### 8.3 Items Summary

*Complete item inventory from `rr_pre_enq_dlr_fmb.xml`.*

**Block counts:**

*Database / non-database counts derived from XML.*

| Block | Total Items | Database Items | Non-Database Items |
| :--- | ---: | ---: | ---: |
| CB_BLK | 8 | 0 | 8 |
| PB_BLK | 12 | 0 | 12 |
| CB_ERR | 1 | 0 | 1 |
| WEBUTIL | 9 | 0 | 9 |
| **Total** | **30** | **0** | **30** |

**Item detail (all 30 items):**

| Block | Item Name | DatabaseItem | Description |
| :--- | :--- | :--- | :--- |
| CB_BLK | REPORT_DESC | false | Report title/description label displayed at the top of the form |
| CB_BLK | P_FROMDT | false | From date field for the report date range filter |
| CB_BLK | P_TODT | false | To date field for the report date range filter |
| CB_BLK | P_CAMPAIGN_CODE | false | Campaign code returned from the campaign LOV selection |
| CB_BLK | P_CAMPAIGN_DESC | false | Campaign description displayed in the campaign LOV and returned on selection |
| CB_BLK | SUBMIT | false | Submit button that executes the pre-enquiry Excel report |
| CB_BLK | P_DESTYPE | false | Destination type indicator for report output routing |
| CB_BLK | COPYRIGHT_DECLARATION | false | Copyright declaration text displayed at the bottom of the form |
| PB_BLK | PB_EXIT | false | Inherited toolbar push button - exits the form; triggers WHEN-BUTTON-PRESSED which calls GENERAL.ASK_CONFIRM before closing (inherited from DPL.olb) |
| PB_BLK | PB_LIST | false | Inherited toolbar push button - displays the LOV for the current item (inherited from DPL.olb) |
| PB_BLK | PB_INSERT | false | Inherited toolbar push button - inserts a new record; suppressed in this report-only form (inherited from DPL.olb) |
| PB_BLK | PM_CONT | false | Inherited toolbar push button - context/menu continuation action (inherited from DPL.olb) |
| PB_BLK | PB_DEL | false | Inherited toolbar push button - deletes the current record; suppressed in this report-only form (inherited from DPL.olb) |
| PB_BLK | PB_CANCEL | false | Inherited toolbar push button - cancels pending changes (inherited from DPL.olb) |
| PB_BLK | PB_SAVE | false | Inherited toolbar push button - saves the current record; suppressed in this report-only form (inherited from DPL.olb) |
| PB_BLK | PB_PRINT | false | Inherited toolbar push button - triggers print action for the current screen (inherited from DPL.olb) |
| PB_BLK | PB_CUT | false | Inherited toolbar push button - cuts the selected text in the current item (inherited from DPL.olb) |
| PB_BLK | PB_COPY | false | Inherited toolbar push button - copies the selected text in the current item (inherited from DPL.olb) |
| PB_BLK | PB_PASTE | false | Inherited toolbar push button - pastes clipboard text into the current item (inherited from DPL.olb) |
| PB_BLK | PB_ERR_EXIT | false | Inherited toolbar push button - exits the error window (CB_ERR/WIN_ERR) and returns focus to the main canvas (inherited from DPL.olb) |
| CB_ERR | TXT_ERR | false | Inherited text item in the CB_ERR error block - displays the error message text in the WIN_ERR error window (inherited from DPL.olb) |
| WEBUTIL | DUMMY | false | **INACTIVE** - Push button in the WEBUTIL block with an inactive WHEN-BUTTON-PRESSED trigger (no active body); not visible or operable by users; inherited as part of the WebUtil object group |
| WEBUTIL | WEBUTIL_CLIENTINFO_FUNCTIONS | false | Inherited WebUtil bean area item - handles client-info functions between the Forms server and the client browser (inherited from webutil.olb) |
| WEBUTIL | WEBUTIL_FILE_FUNCTIONS | false | Inherited WebUtil bean area item - handles client-side file operations such as file upload and download (inherited from webutil.olb) |
| WEBUTIL | WEBUTIL_HOST_FUNCTIONS | false | Inherited WebUtil bean area item - handles host-command execution on the client machine (inherited from webutil.olb) |
| WEBUTIL | WEBUTIL_SESSION_FUNCTIONS | false | Inherited WebUtil bean area item - handles session-level client/server communication functions (inherited from webutil.olb) |
| WEBUTIL | WEBUTIL_FILETRANSFER_FUNCTIONS | false | Inherited WebUtil bean area item - handles file transfer operations between server and client (inherited from webutil.olb) |
| WEBUTIL | WEBUTIL_OLE_FUNCTIONS | false | Inherited WebUtil bean area item - handles OLE automation calls on the client (inherited from webutil.olb) |
| WEBUTIL | WEBUTIL_C_API_FUNCTIONS | false | Inherited WebUtil bean area item - handles C-API native function calls on the client (inherited from webutil.olb) |
| WEBUTIL | WEBUTIL_BROWSER_FUNCTIONS | false | Inherited WebUtil bean area item - handles browser-level operations such as opening URLs on the client (inherited from webutil.olb) |

### 8.4 List of Values

| LOV Name | Title | Record Group | Attached Block.Item |
| :--- | :--- | :--- | :--- |
| LV_CAMPAIGN | Service Type | RG_CAMPAIGN | CB_BLK.P_CAMPAIGN_DESC |

**Total LOVs:** 1

### 8.5 Alerts

| Alert Name | Title | Message Text | Calling Context |
| :--- | :--- | :--- | :--- |
| WEBUTIL_ERROR | Forms | (set at runtime) | Inherited from webutil.olb; invoked by WebUtil infrastructure on client-side errors |
| ALERT_BUT | Note | Please select valid region code and for code | Trigger: WHEN-BUTTON-PRESSED in CB_BLK.SUBMIT |
| AL_PRINT | Print | (set at runtime) | Inherited from DPL.olb; invoked by print-related actions triggered from PB_BLK.PB_PRINT or GENERAL library routines |
| AL_ERRINFO | Error | (set at runtime) | Inherited from DPL.olb; invoked by GENERAL.DISP_TEXT and GENERAL.RAISE_ERROR to display error-level messages |
| AL_NOTE | Note | (set at runtime) | Inherited from DPL.olb; invoked by GENERAL.DISP_TEXT to display informational note messages |
| AL_CONFIRM | Caution | (set at runtime) | Inherited from DPL.olb; invoked by GENERAL.ASK_CONFIRM to prompt the user for a yes/no confirmation |

**Total Alerts:** 6

### 8.6 Program Units

*Authoritative catalogue of **5 form-local program units**. Database packages and standalone procedures are in **Section 15.2**; PLD shared-library routines are in **Section 18**.*

| Program Unit | Type | Calls | Description |
| :--- | :--- | :--- | :--- |
| VALIDATE_CN_MAIN | Unknown | GENERAL.CHECK_NULL, GENERAL.DISP_TEXT | **COMMENTED OUT / INACTIVE** - Entire procedure body is block-commented; originally validated test-drive record fields using GENERAL.CHECK_NULL and date range checks |
| CHECK_BEFORE_DELETE | Unknown | GENERAL.DISP_TEXT | **COMMENTED OUT / INACTIVE** - Entire procedure body is block-commented; originally checked enquiry records before allowing deletion |
| POPULATE_ERRORS | Package spec | - | Package specification declaring a PL/SQL table variable (v_tab) for error code storage; no active body |
| L_POPULATE | Procedure | AM_LIST, FIND_ITEM, FIND_GROUP, ID_NULL (webutil), DELETE_GROUP, CREATE_GROUP_FROM_QUERY, POPULATE_GROUP, POPULATE_LIST | Dynamically builds a record group from AM_LIST for a given list name and principal, then populates the target list item; used to load the campaign LOV |
| PR_REMOVE_ASCII_CHR | Procedure | TEXT_IO, WEB.SHOW_DOCUMENT, GENERAL.DISP_TEXT | Reads a generated report CSV file line by line, strips form-feed characters, writes to an output file, and opens the result in the browser; handles exceptions by displaying an error message |

**Total Program Units:** 5

### 8.7 Triggers

**Item-Level Trigger Types (reference):**

| Trigger Name | Purpose |
| :--- | :--- |
| WHEN-VALIDATE-ITEM | Validates field when user leaves item |
| KEY-* | Keyboard actions - commit, exit, LOV, navigation |
| WHEN-NEW-BLOCK-INSTANCE | Initializes block on entry |
| WHEN-BUTTON-PRESSED | Executes button action |
| PRE-INSERT / POST-INSERT | Before/after record creation |
| WHEN-LIST-CHANGED | Dropdown selection changed |
| PRE-QUERY / POST-QUERY | Before/after query execution |
| WHEN-CHECKBOX-CHANGED | Checkbox toggled |
| WHEN-VALIDATE-RECORD | Validates entire record before leaving row |

**DPL library routines invoked from triggers and program units:**

| Routine | Type | Called From | Purpose |
| :--- | :--- | :--- | :--- |
| GENERAL.ASK_CONFIRM | Library routine | Form level, PB_BLK.PB_EXIT (inherited) | Displays a caution confirmation dialog (AL_CONFIRM) and returns the user's yes/no response; used to prompt before destructive actions such as form exit |
| GENERAL.CHECK_NULL | Library routine | ProgramUnit: VALIDATE_CN_MAIN | **COMMENTED OUT / INACTIVE** - Referenced only within the commented-out VALIDATE_CN_MAIN procedure; raises an error if a required field is null |
| GENERAL.DISP_TEXT | Library routine | CB_BLK.P_FROMDT, CB_BLK.P_TODT, Form level, ProgramUnit: CHECK_BEFORE_DELETE, ProgramUnit: PR_REMOVE_ASCII_CHR, ProgramUnit: VALIDATE_CN_MAIN | Displays a message dialog using an error or note alert; the title argument determines which alert style (AL_ERRINFO or AL_NOTE) is used |
| GENERAL.RAISE_ERROR | Library routine | Form level | Looks up an error message by code and displays it as an Error, Note, or Caution alert; raises FORM_TRIGGER_FAILURE for error-type messages |

### 8.7.1 Inactive / Commented-Out Trigger Register

*Triggers and field validations where XML source is `null;`, fully block-commented, or legacy code preserved but not executed. Do **not** migrate these as active business requirements.*

| Status | Block | Item | Trigger | Former behaviour (preserved in comments) | Disabled since / note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Commented out** | Form | - | ON-ERROR | Two earlier commented-out error handler variants that displayed error messages using GENERAL.DISP_TEXT for specific error codes (40209, 40207, -02292) and handled multi-user locking conflicts | Superseded by the active ON-ERROR handler; legacy variants preserved in block comments |
| **Inactive stub** | Form | - | KEY-COMMIT | Body contains only `NULL;`; no commit operation is performed | Commit is intentionally disabled; form operates as a report-only enquiry screen with no DML |
| **Commented out** | Form | - | FT_SAVE | Earlier save-action handler body is block-commented; no save operation is performed | Superseded or suppressed; form is report-only with no DML save path |
| **Commented out** | PB_BLK | PB_EXIT | WHEN-BUTTON-PRESSED | Earlier exit handler logic is block-commented; the active path calls GENERAL.ASK_CONFIRM before closing | Legacy exit variant preserved in block comments within the inherited PB_EXIT trigger |

*Additional null-only or partially commented triggers exist on estimation and legacy blocks - see XML `TriggerText` starting with `null;` or `/*`.*

**Complete trigger inventory (35 business triggers):**
*rr_pre_enq_dlr_fmb.xml contains Trigger elements.*

| Trigger Name | Block | Item | Called From / Context | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| ON-ERROR | Form | - | Form level | Intercepts Oracle Forms errors; displays user-friendly messages for date format, numeric, and mandatory-field errors; rolls back and raises failure on SQL exceptions |
| ON-MESSAGE | Form | - | Form level | Intercepts Oracle Forms informational messages; displays them using GENERAL.DISP_TEXT for specific message codes |
| KEY-EXIT | Form | - | Form level | Clears application info from DBMS_APPLICATION_INFO and exits the form without validation |
| KEY-LISTVAL | Form | - | Form level | Retrieves the LOV name for the current item and displays it; navigates to the next item after successful LOV selection |
| KEY-COMMIT | Form | - | Form level | **INACTIVE** - Body is `NULL;`; commit is intentionally suppressed as the form is report-only |
| KEY-CLRFRM | Form | - | Form level | Clears the form without validation and refreshes the copyright declaration field |
| KEY-OTHERS | Form | - | Form level (inherited) | Inherited catch-all key handler from DPL.olb; suppresses undefined key actions to prevent default Forms behaviour |
| KEY-NEXT-ITEM | Form | - | Form level (inherited) | Inherited key handler from DPL.olb; navigates focus to the next item in tab order |
| KEY-PREV-ITEM | Form | - | Form level (inherited) | Inherited key handler from DPL.olb; navigates focus to the previous item in tab order |
| KEY-NXTBLK | Form | - | Form level (inherited) | Inherited key handler from DPL.olb; navigates focus to the next block |
| KEY-PRVBLK | Form | - | Form level (inherited) | Inherited key handler from DPL.olb; navigates focus to the previous block |
| KEY-DOWN | Form | - | Form level (inherited) | Inherited key handler from DPL.olb; navigates focus downward within the current block |
| KEY-UP | Form | - | Form level (inherited) | Inherited key handler from DPL.olb; navigates focus upward within the current block |
| FT_SAVE | Form | - | Form level (inherited) | Inherited save-action trigger from DPL.olb; body is commented out in this form - no save operation is performed |
| FT_CANCEL | Form | - | Form level (inherited) | Inherited cancel-action trigger from DPL.olb; cancels pending changes and reverts the current record |
| FT_INSERT | Form | - | Form level (inherited) | Inherited insert-action trigger from DPL.olb; initiates a new record insert; suppressed in this report-only form |
| FT_DEL | Form | - | Form level (inherited) | Inherited delete-action trigger from DPL.olb; deletes the current record; suppressed in this report-only form |
| FT_LIST | Form | - | Form level (inherited) | Inherited list-action trigger from DPL.olb; displays the LOV for the current item |
| FT_PRINT | Form | - | Form level (inherited) | Inherited print-action trigger from DPL.olb; triggers the print dialog for the current screen |
| WHEN-NEW-FORM-INSTANCE | Form | - | Form level (inherited) | Inherited from DPL.olb; initialises global session variables (DEALER, PRINCIPAL, LOC_CD, PARENT_GROUP, USERID, CUR_DATE, etc.), sets the window title, and configures the toolbar canvas |
| PRE-FORM | Form | - | Form level | Sets DBMS application module info for session tracking; starts performance timer if application logging is enabled |
| WHEN-VALIDATE-ITEM | CB_BLK | P_FROMDT | CB_BLK.P_FROMDT | Validates that From Date is not null, not in the future, and not greater than To Date; automatically calculates and sets To Date as one month from From Date |
| WHEN-VALIDATE-ITEM | CB_BLK | P_TODT | CB_BLK.P_TODT | Validates that To Date is not null, not before From Date, not in the future, and that the date range does not exceed three months |
| WHEN-BUTTON-PRESSED | CB_BLK | SUBMIT | CB_BLK.SUBMIT | Builds and executes a dynamic SQL query across pre-enquiry campaign, dealer, and enquiry data; generates and downloads the report as an Excel CSV file |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EXIT | PB_BLK.PB_EXIT (inherited) | Inherited from DPL.olb; prompts the user via GENERAL.ASK_CONFIRM and exits the form if confirmed |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_LIST | PB_BLK.PB_LIST (inherited) | Inherited from DPL.olb; displays the LOV for the currently focused item |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_INSERT | PB_BLK.PB_INSERT (inherited) | Inherited from DPL.olb; initiates a new record insert; suppressed in this report-only form |
| WHEN-BUTTON-PRESSED | PB_BLK | PM_CONT | PB_BLK.PM_CONT (inherited) | Inherited from DPL.olb; context/menu continuation action for the toolbar |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_DEL | PB_BLK.PB_DEL (inherited) | Inherited from DPL.olb; deletes the current record; suppressed in this report-only form |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CANCEL | PB_BLK.PB_CANCEL (inherited) | Inherited from DPL.olb; cancels pending changes on the current record |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SAVE | PB_BLK.PB_SAVE (inherited) | Inherited from DPL.olb; saves the current record; suppressed in this report-only form |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PRINT | PB_BLK.PB_PRINT (inherited) | Inherited from DPL.olb; triggers the print dialog for the current screen |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CUT | PB_BLK.PB_CUT (inherited) | Inherited from DPL.olb; cuts the selected text from the currently focused item |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_COPY | PB_BLK.PB_COPY (inherited) | Inherited from DPL.olb; copies the selected text from the currently focused item |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PASTE | PB_BLK.PB_PASTE (inherited) | Inherited from DPL.olb; pastes clipboard text into the currently focused item |

### 8.8 Canvas and Window Inventory

**Windows:**

| Window | Title | Primary Canvas |
| :--- | :--- | :--- |
| WIN_ERR | - | CN_ERR |
| WN_MAIN | Pre-Enquiry Followup (Rel 1.1.1) | CN_MAIN |

**Canvases:**

| Canvas | Type | Window |
| :--- | :--- | :--- |
| CN_ERR | Content | WIN_ERR |
| CN_MAIN | Content | WN_MAIN |
| CN_TOOL | Content | WN_MAIN |

---

### 8.9 Editors

*No editors found in rr_pre_enq_dlr_fmb.xml.*

### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

#### 8.10.1 Visual Attributes (form-defined)

*3 VisualAttribute elements defined at form level (not inherited from DPL.olb).*

| Visual Attribute |
| :--- |
| VA_MANDATORY |
| VA_DEFAULT |
| VA_DISPLAY |

#### 8.10.2 Property Classes (form-defined)

*Form-local PropertyClass elements.*

*No form-local property classes found in rr_pre_enq_dlr_fmb.xml.*

#### 8.10.3 Object Groups

*Object groups bundle inherited triggers and visual objects applied form-wide at runtime.*

| Object Group Child | Type |
| :--- | :--- |
| KEY-OTHERS | Inherited trigger |
| KEY-NEXT-ITEM | Inherited trigger |
| KEY-PREV-ITEM | Inherited trigger |
| KEY-NXTBLK | Inherited trigger |
| KEY-PRVBLK | Inherited trigger |
| KEY-DOWN | Inherited trigger |
| KEY-UP | Inherited trigger |
| CN_ERR | Inherited canvas |
| VA_DISP | Inherited visualattribute |
| CB_ERR | Inherited block |
| VA_LOV | Inherited visualattribute |
| VA_TRNI_DT | Inherited visualattribute |
| VA_TITLE | Inherited visualattribute |
| VA_ALERT | Inherited visualattribute |
| VA_BUTN | Inherited visualattribute |
| VA_TEXT | Inherited visualattribute |
| VA_MPROMPT | Inherited visualattribute |
| VA_OPROMPT | Inherited visualattribute |
| VA_MAND | Inherited visualattribute |
| VA_NUM | Inherited visualattribute |
| VA_DESC | Inherited visualattribute |
| VA_ICONIC_BUTN | Inherited visualattribute |
| VA_RB | Inherited visualattribute |
| VA_CB | Inherited visualattribute |
| WN_MAIN | Inherited window |
| POP_MAIN | Inherited trigger |
| CN_MAIN | Inherited canvas |
| CN_TOOL | Inherited canvas |
| PB_BLK | Inherited block |
| AL_ERRINFO | Inherited alert |
| AL_NOTE | Inherited alert |
| AL_CONFIRM | Inherited alert |
| WIN_ERR | Inherited window |
| AL_PRINT | Inherited alert |
| FT_SAVE | Inherited trigger |
| FT_CANCEL | Inherited trigger |
| FT_INSERT | Inherited trigger |
| FT_DEL | Inherited trigger |
| FT_LIST | Inherited trigger |
| FT_PRINT | Inherited trigger |
| WHEN-NEW-FORM-INSTANCE | Inherited trigger |

### 8.11 DataSourceColumn Inventory

*No DataSourceColumns found in rr_pre_enq_dlr_fmb.xml.*

## 9. Object Library

*The form references two Object Library files. The DPL_olb.xml provides the standard property classes and visual attributes shared across the DMS form suite. The webutil_olb.xml provides the WebUtil object group used for client-side file operations and host commands.*

Source OLB file(s): DPL_olb.xml, webutil_olb.xml

| Name | Type | Description | Used By (count) | Sample Items |
| ---- | ---- | ----------- | --------------- | ------------ |
| VA_CB | VisualAttribute | Check box visual attribute - gray background, Arial 8pt, black foreground, transparent fill | not used directly in this form | N/A |
| VA_RB | VisualAttribute | Radio button visual attribute - gray background, Arial 8pt, black foreground, transparent fill | not used directly in this form | N/A |
| VA_ICONIC_BUTN | VisualAttribute | Iconic button visual attribute - white background, black foreground, transparent fill | not used directly in this form | N/A |
| VA_DESC | VisualAttribute | Description display visual attribute - gray background, Small Fonts 7pt, blue foreground | not used directly in this form | N/A |
| VA_NUM | VisualAttribute | Numeric item visual attribute - white background, Arial 8pt, medium weight, black foreground | not used directly in this form | N/A |
| VA_MAND | VisualAttribute | Mandatory field visual attribute - cyan background, Arial 9pt, medium weight, black foreground | not used directly in this form | N/A |
| VA_OPROMPT | VisualAttribute | Optional prompt visual attribute - prompt style, Arial 8pt/9pt, black prompt foreground | not used directly in this form | N/A |
| VA_MPROMPT | VisualAttribute | Mandatory prompt visual attribute - prompt style, Arial 8pt/9pt, red prompt foreground | not used directly in this form | N/A |
| VA_TEXT | VisualAttribute | Standard text item visual attribute - white background, Arial 9pt, medium weight, black foreground | not used directly in this form | N/A |
| VA_BUTN | VisualAttribute | Button visual attribute - gray background, Arial 10pt, bold, black foreground | not used directly in this form | N/A |
| VA_ALERT | VisualAttribute | Alert visual attribute - gray background, MT EXTRA 11pt, demilight weight, black foreground | not used directly in this form | N/A |
| VA_TITLE | VisualAttribute | Title visual attribute - gray background, Arial 10pt, bold, blue foreground | not used directly in this form | N/A |
| VA_TRNI_DT | VisualAttribute | Transaction date visual attribute - white background, Courier bold, black foreground | not used directly in this form | N/A |
| VA_LOV | VisualAttribute | LOV visual attribute - gray background, Arial 9pt, dark-blue foreground | not used directly in this form | N/A |
| VA_DISP | VisualAttribute | Display item visual attribute - r25g75b75 background, Arial 8pt, bold, black foreground | not used directly in this form | N/A |
| PC_DESC | PropertyClass | Display item property class - left-justified, 250 wide, Arial 9pt, white background, blue foreground, max 110 chars | not referenced in this form | N/A |
| PC_SC_DATE | PropertyClass | Date display property class - 73 wide, gray background, Arial 8pt bold, DD-MM-RRRR format mask, auto-hint | not referenced in this form | N/A |
| PC_TITLE | PropertyClass | Title text item property class - centered, gray background, Arial 10pt bold, uppercase | not referenced in this form | N/A |
| PC_FORMAT | PropertyClass | Format text item property class - centered, 60 wide, white background, Arial 9pt, uppercase | not referenced in this form | N/A |
| PC_MR_BLK | PropertyClass | Master record block property class - navigation style Change Record, next block PB_BLK | not referenced in this form | N/A |
| PC_DISP | PropertyClass | Display-only text item property class - left-justified, disabled, gray8 background, Arial 9pt, not keyboard-navigable | not referenced in this form | N/A |
| PC_LOV | PropertyClass | LOV property class - 80/96 XY position, 250 wide, gray background, Arial 8pt, dark-blue foreground, no auto-select | not referenced in this form | N/A |
| PC_FORM | PropertyClass | Form-level property class - includes standard ON-ERROR, ON-MESSAGE, KEY-EXIT, KEY-LISTVAL, KEY-COMMIT, KEY-CLRFRM triggers; validation unit Item; console window WN_MAIN; menu.mmx | 1 - RR_PRE_ENQ_DLR FormModule inherits from this class | RR_PRE_ENQ_DLR (FormModule) |
| PC_DISP_DATE | PropertyClass | Display date item property class - disabled, gray8 background, Arial 9pt, DD-MM-RRRR format, date datatype | not referenced in this form | N/A |
| PC_DISP_NUM | PropertyClass | Display numeric item property class - right-justified, disabled, gray8 background, Arial 9pt, lowered bevel | not referenced in this form | N/A |
| PC_DATE | PropertyClass | Editable date field property class - 60 wide, white background, Arial 9pt, DD-MM-RRRR format mask, mouse-navigate, hint for date entry format, WHEN-VALIDATE-ITEM inherited | not referenced in this form | N/A |
| PC_DTTIME | PropertyClass | Date-time field property class - 80 wide, DD-MM-RRRR HH24:MI format mask, initialises to $$dbdatetime$$ | not referenced in this form | N/A |
| PC_CB | PropertyClass | Check box property class - white background, Arial 9pt, 14 high | not referenced in this form | N/A |
| PC_ALERT | PropertyClass | Alert property class - gray background, MT Extra 11pt, demilight | not referenced in this form | N/A |
| PC_MDATE | PropertyClass | Mandatory date field property class - 60 wide, white background, DD-MM-RRRR format, red prompt foreground, WHEN-VALIDATE-ITEM enforces non-null | not referenced in this form | N/A |
| PC_RB | PropertyClass | Radio button property class - gray background, Arial 9pt, 11 high | not referenced in this form | N/A |
| PC_WIND | PropertyClass | Window property class - standard DMS window (resizable, minimisable, maximisable, moveable, hide on exit) | not referenced in this form | N/A |
| PC_CANV | PropertyClass | Canvas property class - white background, Arial, window WN_MAIN, raise on enter | not referenced in this form | N/A |
| PC_BUTN | PropertyClass | Push button property class - 42 wide, gray background, Arial 9pt bold, no mouse-navigate | not referenced in this form | N/A |
| PC_TEXT | PropertyClass | Standard text item property class - left-justified, white background, Arial 9pt, mixed case | not referenced in this form | N/A |
| PC_MTEXT | PropertyClass | Mandatory text item property class - left-justified, white background, Arial 9pt, red prompt foreground, WHEN-VALIDATE-ITEM enforces non-null | not referenced in this form | N/A |
| PC_UTEXT | PropertyClass | Uppercase text item property class - left-justified, white background, Arial 9pt, uppercase restriction | not referenced in this form | N/A |
| PC_MUTEXT | PropertyClass | Mandatory uppercase text item property class - left-justified, white background, Arial 9pt, red prompt, uppercase, WHEN-VALIDATE-ITEM enforces non-null | not referenced in this form | N/A |
| PC_NUM | PropertyClass | Numeric text item property class - right-justified, white background, Arial 9pt, number datatype, lowest value 0 | not referenced in this form | N/A |
| PC_MNUM | PropertyClass | Mandatory numeric text item property class - right-justified, white background, Arial 9pt, red prompt, WHEN-VALIDATE-ITEM enforces non-zero | not referenced in this form | N/A |
| PC_ICONIC_BUTN | PropertyClass | Iconic push button property class - iconic=true, 20 wide, white background, no bevel | not referenced in this form | N/A |
| PC_SCROLL | PropertyClass | Scroll bar property class - scroll bar width 13 | not referenced in this form | N/A |
| WEBUTIL | ObjectGroup | WebUtil object group - provides the WEBUTIL_HIDDEN_WINDOW, WEBUTIL_CANVAS, and all WebUtil bean item components needed to use WebUtil client-side utilities in a form | 1 - WEBUTIL block in RR_PRE_ENQ_DLR is subclassed from this group | WEBUTIL block, WEBUTIL_CANVAS, WEBUTIL_HIDDEN_WINDOW |
| WEBUTIL_NO_OLE | ObjectGroup | WebUtil object group (OLE-free variant) - same WebUtil components but without OLE support | not used in this form | N/A |
| OG_GROUP | ObjectGroup | Form-level object group defined in RR_PRE_ENQ_DLR (references WN_MAIN, CN_MAIN, VA_TITLE) | 1 reference in form | WN_MAIN (Window), CN_MAIN (Canvas), VA_TITLE (VisualAttribute) |

---

## 10. Record Groups

*Lists all record groups, their LOV bindings, query logic, dynamic bindings, business purpose, and form usage.*

| Record Group | Type | Used By LOV | Display Column | Return Column | Dynamic Bindings | Purpose | Where Used |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| RG_CAMPAIGN | Query | LV_CAMPAIGN | LIST_CODE | LIST_DESC | No | Lists all pre-enquiry campaign codes and names available for the current dealer, location, and principal | LV_CAMPAIGN -> CB_BLK.P_CAMPAIGN_DESC |

**Total Record Groups:** 1

## 11. Referenced Database Objects

*Database tables, views, and objects accessed by the form.*

| Block | Base Table | Primary Key Item | Database Item |
| :--- | :--- | :--- | :--- |
| CB_BLK | - | - | No |

| Object | Schema | Used In | Description |
| :--- | :--- | :--- | :--- |
| `AM_LIST` | - | L_POPULATE | Application master list - lookup values for list-of-values population keyed by list name and principal |
| `DUAL` | - | RG_CAMPAIGN, Trigger WHEN-BUTTON-PRESSED | Oracle system table - used in UNION queries to inject a static 'ALL' option into the campaign and report queries |
| `MULDMS.AM_DEALER_LOC` | - | RG_CAMPAIGN | Dealer location master - dealer code, location code, region, and principal mapping for filtering report data |
| `MULDMS.GM_CITY` | - | Trigger WHEN-BUTTON-PRESSED | City master - city description lookup used to display the dealer city in the pre-enquiry report output |

**Total Referenced Objects:** 4

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure/Package Index

| Requirement ID | Procedure/Package | Purpose |
| -------------- | ----------------- | ------- |
| BR-001 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Registers the form name as the active client session identifier at screen open |
| BR-001 | DBMS_APPLICATION_INFO.SET_MODULE | Registers the form module name in the database session tracking system at screen open |
| BR-001 | STOP_WATCH.START_TIMER | Starts the application performance timer when logging is active |
| BR-002 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Clears the client session identifier on form exit |
| BR-002 | DBMS_APPLICATION_INFO.SET_MODULE | Clears the module name in the session tracking system on form exit |
| BR-003 | SF_COPYRIGHT_DECLARATION | Retrieves the copyright declaration text for the logged-in company context on form clear |
| BR-004 | GENERAL.DISP_TEXT | Displays user-facing error messages for all custom ON-ERROR branches |
| BR-004 | GENERAL.RAISE_ERROR | Looks up and displays a standardised error message for database error E0088 (integrity constraint violation) |
| BR-005 | GENERAL.DISP_TEXT | Displays user-facing messages for intercepted Forms message codes 40209 and 40207 |
| BR-006 | GENERAL.DISP_TEXT | Displays the "From Date can not be empty" error message |
| BR-007 | GENERAL.DISP_TEXT | Displays the "To date cannot be entered without entering From date" error message |
| BR-008 | VIEW_EXCEL_REPORT_NEW | Executes the pre-enquiry data query, writes and transfers the CSV report to the user's desktop |
| BR-009 | L_POPULATE | General-purpose list population utility for AM_LIST-backed list items |
| - | GENERAL.ASK_CONFIRM | Presents a confirmation dialogue before discarding changes (FT_CANCEL) or deleting a record (FT_DEL) |
| - | WEBUTIL_CORE.CUSTOMEVENTHANDLER | Central WebUtil event dispatcher; routes all client-side custom events to the appropriate WebUtil subsystem handler |
| - | WEBUTIL.ID_NULL | Checks whether a WebUtil record-group handle is null; used inside L_POPULATE before creating a new record group |
| - | D2KWUTIL.ATTEMPT_DLL_LOAD | Attempts to load a named DLL via the D2KWUTIL client-side utility library |
| - | D2KWUTIL.CHOOSEFILE | Presents a client-side file-chooser dialogue via D2KWUTIL |
| - | D2KWUTIL.D2KWUTIL_ACTIVEWIN | Returns the handle of the currently active window via D2KWUTIL |
| - | D2KWUTIL.D2KWUTIL_CHOOSEFILE | D2KWUTIL internal file-chooser delegate |
| - | D2KWUTIL.D2KWUTIL_DEBUGSTRING | Emits a debug string through the D2KWUTIL channel |
| - | D2KWUTIL.D2KWUTIL_GETDOSENV | Reads a DOS/OS environment variable via D2KWUTIL |
| - | D2KWUTIL.D2KWUTIL_GETREGKEY | Reads a Windows registry key via D2KWUTIL |
| - | D2KWUTIL.D2KWUTIL_WINDIR | Returns the Windows directory path via D2KWUTIL |
| - | D2KWUTIL.GET_ACTIVE_WINDOW | Returns the active window handle via D2KWUTIL |
| - | D2KWUTIL.SAVE_FILE | Saves a file on the client via D2KWUTIL |
| - | D2KWUTIL.TRANSLATETYPE | Translates a D2KWUTIL type code to its string representation |
| - | WEBUTIL.BLOCKING | Sets WebUtil blocking mode on or off during asynchronous operations |
| - | WEBUTIL.CHECKLIBS | Verifies that required WebUtil client libraries are present and loaded |
| - | WEBUTIL.CLEARCALLBACKTRIGGER | Clears a previously registered WebUtil callback trigger |
| - | WEBUTIL.CLOSEBLOB | Closes an open BLOB handle managed by WebUtil |
| - | WEBUTIL.CLOSEFILE | Closes an open server-side file handle managed by WebUtil |
| - | WEBUTIL.DOWNLOADFROMURL | Downloads a file from a URL to the client desktop via WebUtil |
| - | WEBUTIL.DOWNLOADFROMURLINT | Internal URL-download delegate used by WEBUTIL.DOWNLOADFROMURL |
| - | WEBUTIL.ERROR | Returns the last WebUtil error string |
| - | WEBUTIL.ERRORALERT | Displays a WebUtil error in an alert dialogue |
| - | WEBUTIL.EXECUTE | Executes a host command or process via WebUtil |
| - | WEBUTIL.FCLOSE | Closes a file opened with WEBUTIL.FOPEN |
| - | WEBUTIL.FILE_SAVE_DIALOG | Presents a client-side Save File dialogue via WebUtil |
| - | WEBUTIL.FILE_SELECTION_DIALOG_INT | Internal file-selection dialogue delegate used by WebUtil |
| - | WEBUTIL.FOPEN | Opens a server-side file for reading or writing via WebUtil |
| - | WEBUTIL.GETCALLBACKTRIGGER | Retrieves the name of the currently registered WebUtil callback trigger |
| - | WEBUTIL.GETCLIENTOSFAMILY | Returns the OS family string of the connected client |
| - | WEBUTIL.GETCLIENTSETTING | Reads a named client-side setting value via WebUtil |
| - | WEBUTIL.GETIMPLCLASS | Returns the Java implementation class name for a WebUtil bean |
| - | WEBUTIL.GETLASTERROR | Returns the last error code recorded by WebUtil |
| - | WEBUTIL.GETLASTERRORARGS | Returns the argument list associated with the last WebUtil error |
| - | WEBUTIL.GETNUMBER | Retrieves a numeric value from a WebUtil property bundle |
| - | WEBUTIL.GETOSFAMILY | Returns the OS family of the application server |
| - | WEBUTIL.GETOUTPUT | Retrieves standard output captured from a WebUtil host execution |
| - | WEBUTIL.GETPROPERTY | Reads a named property from a WebUtil bean |
| - | WEBUTIL.GETSTRING | Retrieves a string value from a WebUtil property bundle |
| - | WEBUTIL.GETVAR | Reads a named WebUtil session variable |
| - | WEBUTIL.GET_LINE | Reads one line from a file opened via WEBUTIL.FOPEN |
| - | WEBUTIL.GET_RETURN_CODE | Returns the exit/return code of the last WebUtil host execution |
| - | WEBUTIL.GET_STANDARD_OUTPUT | Returns the full standard-output buffer from the last WebUtil execution |
| - | WEBUTIL.HOST | Runs a host operating-system command via WebUtil |
| - | WEBUTIL.INIT | Initialises the WebUtil subsystem for the current Forms session |
| - | WEBUTIL.INITWEBUTIL | Performs low-level WebUtil bean initialisation |
| - | WEBUTIL.ISERROR | Returns TRUE if the last WebUtil operation recorded an error |
| - | WEBUTIL.IS_OPEN | Returns TRUE if a given WebUtil file handle is currently open |
| - | WEBUTIL.LENGTH | Returns the byte length of a WebUtil-managed data buffer |
| - | WEBUTIL.LOG | Writes a message to the WebUtil diagnostic log |
| - | WEBUTIL.POPULATEPROPERTYBUNDLE | Populates a WebUtil property bundle with name-value pairs |
| - | WEBUTIL.PUTF | Writes a formatted string to a file opened via WEBUTIL.FOPEN |
| - | WEBUTIL.PUT_LINE | Writes one line to a file opened via WEBUTIL.FOPEN |
| - | WEBUTIL.READFROMPROPERTYBUNDLE | Reads a value from a WebUtil property bundle by key |
| - | WEBUTIL.READTRANSFROMMSGBUNDLE | Reads a translated message from a WebUtil message bundle |
| - | WEBUTIL.REGISTERBEAN | Registers a WebUtil JavaBean component with the Forms runtime |
| - | WEBUTIL.REGISTER_FUNCTION | Registers a named function with the WebUtil dispatch table |
| - | WEBUTIL.RELEASE_PROCESS | Releases resources held by a completed WebUtil host process |
| - | WEBUTIL.SETCLIENTSETTING | Writes a named client-side setting value via WebUtil |
| - | WEBUTIL.SETDATA | Sets binary data on a WebUtil-managed data buffer |
| - | WEBUTIL.SETPROPERTY | Sets a named property on a WebUtil bean |
| - | WEBUTIL.SHOWBEANS | Displays diagnostic information about registered WebUtil beans |
| - | WEBUTIL.URL_TO_CLIENT | Transfers a server-side file identified by URL to the client desktop |
| - | WEBUTIL.WRITEDATA | Writes binary data from a WebUtil buffer to a file |
| - | ADD_ERROR | Adds an error entry to the form-level error stack |
| - | ADD_EXTERNAL_ERRORS | Adds externally sourced errors to the form-level error stack |
| - | BOOLTOCHAR | Converts a PL/SQL BOOLEAN value to its VARCHAR2 character equivalent |
| - | CLEAN_ERROR_STACK | Clears all entries from the form-level error stack |
| - | DEBUGLOG | Writes a debug message to the application diagnostic log |
| - | GET_ENVIRONMENT_STRING | Reads a named environment variable from the server session |
| - | GET_TEMP_DIRECTORY | Returns the path of the server-side temporary directory |
| - | GET_WINDOWS_DIRECTORY | Returns the Windows directory path on the client |
| - | READ_REGISTRY | Reads a value from the Windows registry on the client |
| - | REGISTER_FUNCTION_CALL | Registers a function call entry in the WebUtil dispatch mechanism |
| - | SETDEBUG | Enables or disables WebUtil debug-mode output |
| - | STRIPDIRSEP | Strips trailing directory-separator characters from a path string |
| - | WINDEBUG | Writes a debug message through the Windows debug output channel |
| - | WEB.SHOW_DOCUMENT | Displays a server-side document or file in the user's browser |
| - | POPULATE_ERRORS (package spec) | Defines the shared PL/SQL table variable v_tab (PK_PLSQL_TABLE.CODE_TAB); no executable body |
| - | PR_REMOVE_ASCII_CHR | Strips form-feed lines from a server-side CSV file and opens the cleaned file in the browser |

---

### 12.2 Procedure and Package Catalogue

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| GENERAL.DISP_TEXT | Package Procedure (DPL library - GENERAL package) | ON-ERROR trigger (Form); ON-MESSAGE trigger (Form); WHEN-VALIDATE-ITEM trigger (CB_BLK.P_FROMDT); WHEN-VALIDATE-ITEM trigger (CB_BLK.P_TODT); PR_REMOVE_ASCII_CHR program unit; via GENERAL.RAISE_ERROR | Displays a message to the user in an alert dialogue. Accepts a message text string and a title string. If the title is 'ERROR', uses the AL_ERRINFO alert; otherwise uses AL_NOTE. Sets the alert title and message text at runtime, shows the alert, and waits for acknowledgement. Raises FORM_TRIGGER_FAILURE after display when used in error paths. |
| GENERAL.RAISE_ERROR | Package Procedure (DPL library - GENERAL package) | ON-ERROR trigger (Form) - database error -02292 branch | Accepts an error code string, retrieves the corresponding message text and type from the error dictionary, prefixes the message with the code, selects the dialogue title based on message type, calls GENERAL.DISP_TEXT to display it, and raises FORM_TRIGGER_FAILURE for Error-type ('E') messages. |
| GENERAL.ASK_CONFIRM | Package Function (DPL library - GENERAL package) | FT_CANCEL trigger (Form); FT_DEL trigger (Form); WHEN-BUTTON-PRESSED trigger (WEBUTIL.DUMMY) | Presents a confirmation dialogue to the user with the supplied message text. Returns a numeric result indicating the user's choice. Called before discarding unsaved changes or deleting a record to obtain explicit user consent. |
| DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Oracle Built-in Package Procedure | PRE-FORM trigger (Form); KEY-EXIT trigger (Form) | Sets or clears the client-info string in the database session, used for monitoring and activity tracing. |
| DBMS_APPLICATION_INFO.SET_MODULE | Oracle Built-in Package Procedure | PRE-FORM trigger (Form); KEY-EXIT trigger (Form) | Sets or clears the module name and action name in the database session for monitoring purposes. |
| STOP_WATCH.START_TIMER | Package Procedure (STOP_WATCH.pck) | PRE-FORM trigger (Form) - conditional on :GLOBAL.APP_LOG = 'Y' | Starts the application-level performance timer for session duration tracking. Called only when application logging is active. |
| SF_COPYRIGHT_DECLARATION | Standalone Function (.fnc file) | KEY-CLRFRM trigger (Form) | Returns the copyright declaration text applicable to the currently logged-in company. The return value is assigned to the copyright declaration display field. |
| VIEW_EXCEL_REPORT_NEW | Procedure (DMS_EXCEL_REPORT library) | WHEN-BUTTON-PRESSED trigger (CB_BLK.SUBMIT) | Accepts a principal identifier, filename, SQL query string, column name, and application ID. Queries EH_REPORTS to look up the report server. If a server is found, calls a remote database CSV-generation procedure, moves the file to the printer directory, reads the download URL from a configuration file, and transfers the file to the client desktop via WebUtil. If no server is found, creates an in-memory record group from the query, iterates over rows writing each to a server-side text file, then transfers the file to the client desktop via WebUtil. In both paths opens the file on the client desktop and reports a failure message if the transfer does not succeed. |
| L_POPULATE | Form Program Unit (Procedure) | Not called from any active trigger in the current form - present for general list population use; internally delegates to GENERAL.L_POPULATE (DPL library) | Accepts a list name and a field reference. Queries AM_LIST for the given list name and principal context. Checks whether an existing record group handle is null via WEBUTIL.ID_NULL, deletes it if present, creates a new record group, populates it, and applies it to the specified list item. |
| PR_REMOVE_ASCII_CHR | Form Program Unit (Procedure) | Not called from any active trigger in the current form - present for server-side file ASCII-strip use | Reads an input CSV file from the server's printer directory line by line, strips lines starting with form-feed characters (CHR(12)), and writes the clean output to a second file. Closes both files and calls WEB.SHOW_DOCUMENT to open the cleaned file in the browser. On exception, displays "Exception" followed by SQLCODE and SQLERRM via GENERAL.DISP_TEXT. |
| POPULATE_ERRORS | Form Program Unit (Package Specification - no body) | Not called from any active trigger | Defines a package-level PL/SQL table variable (v_tab of type PK_PLSQL_TABLE.CODE_TAB). No executable body is present; functions as a shared data-structure definition. |
| WEB.SHOW_DOCUMENT | Package Procedure (Oracle Forms built-in) | PR_REMOVE_ASCII_CHR program unit | Displays a document or file in the user's browser using the specified URL path and target window. |
| WEBUTIL_CORE.CUSTOMEVENTHANDLER | Package Procedure (webutil.pld - WEBUTIL_CORE package) | WHEN-CUSTOM-ITEM-EVENT trigger (WEBUTIL.WEBUTIL_BROWSER_FUNCTIONS); WHEN-CUSTOM-ITEM-EVENT trigger (WEBUTIL.WEBUTIL_CLIENTINFO_FUNCTIONS); WHEN-CUSTOM-ITEM-EVENT trigger (WEBUTIL.WEBUTIL_C_API_FUNCTIONS); WHEN-CUSTOM-ITEM-EVENT trigger (WEBUTIL.WEBUTIL_FILETRANSFER_FUNCTIONS); WHEN-CUSTOM-ITEM-EVENT trigger (WEBUTIL.WEBUTIL_FILE_FUNCTIONS); WHEN-CUSTOM-ITEM-EVENT trigger (WEBUTIL.WEBUTIL_HOST_FUNCTIONS); WHEN-CUSTOM-ITEM-EVENT trigger (WEBUTIL.WEBUTIL_OLE_FUNCTIONS); WHEN-CUSTOM-ITEM-EVENT trigger (WEBUTIL.WEBUTIL_SESSION_FUNCTIONS) | Central WebUtil event dispatcher. Receives the name of a custom client-side event and its associated parameter string, then routes processing to the appropriate WebUtil subsystem handler. Ensures all client-to-server callbacks are handled through a single, consistent entry point. |
| WEBUTIL.ID_NULL | Package Function (webutil.pld - WEBUTIL_C_API package) | L_POPULATE program unit | Checks whether a WebUtil handle (record-group pointer) is null. Returns TRUE if the handle has no value. Used in L_POPULATE to determine whether an existing record group must be deleted before creating a new one. |
| WEBUTIL.BLOCKING | Package Procedure (WebUtil library) | WebUtil internal infrastructure | Sets WebUtil blocking mode on or off during asynchronous client-side operations. |
| WEBUTIL.CHECKLIBS | Package Procedure (WebUtil library) | WebUtil internal infrastructure | Verifies that required WebUtil client libraries are present and loaded before use. |
| WEBUTIL.CLEARCALLBACKTRIGGER | Package Procedure (WebUtil library) | WebUtil internal infrastructure | Clears a previously registered WebUtil callback trigger from the dispatch table. |
| WEBUTIL.CLOSEBLOB | Package Procedure (WebUtil library) | WebUtil internal infrastructure | Closes an open BLOB handle managed by the WebUtil subsystem. |
| WEBUTIL.CLOSEFILE | Package Procedure (WebUtil library) | WebUtil internal infrastructure | Closes an open server-side file handle managed by WebUtil. |
| WEBUTIL.DOWNLOADFROMURL | Package Procedure (WebUtil library) | WebUtil internal infrastructure / VIEW_EXCEL_REPORT_NEW | Downloads a file identified by a URL to the client desktop via the WebUtil file-transfer mechanism. |
| WEBUTIL.DOWNLOADFROMURLINT | Package Procedure (WebUtil library) | Internal delegate of WEBUTIL.DOWNLOADFROMURL | Internal URL-download delegate; performs the low-level transfer invoked by WEBUTIL.DOWNLOADFROMURL. |
| WEBUTIL.ERROR | Package Function (WebUtil library) | WebUtil internal infrastructure | Returns the last error string recorded by the WebUtil subsystem. |
| WEBUTIL.ERRORALERT | Package Procedure (WebUtil library) | WebUtil internal infrastructure | Displays the last WebUtil error in an alert dialogue for user notification. |
| WEBUTIL.EXECUTE | Package Procedure (WebUtil library) | WebUtil internal infrastructure | Executes a host operating-system command or process via the WebUtil client agent. |
| WEBUTIL.FCLOSE | Package Procedure (WebUtil library) | WebUtil internal infrastructure | Closes a file previously opened with WEBUTIL.FOPEN. |
| WEBUTIL.FILE_SAVE_DIALOG | Package Function (WebUtil library) | WebUtil internal infrastructure | Presents a client-side Save File dialogue and returns the chosen file path. |
| WEBUTIL.FILE_SELECTION_DIALOG_INT | Package Function (WebUtil library) | Internal delegate of WebUtil file-selection dialogue | Internal file-selection dialogue delegate used by the WebUtil file-chooser infrastructure. |
| WEBUTIL.FOPEN | Package Function (WebUtil library) | WebUtil internal infrastructure / VIEW_EXCEL_REPORT_NEW | Opens a server-side file for reading or writing and returns a file handle. |
| WEBUTIL.GETCALLBACKTRIGGER | Package Function (WebUtil library) | WebUtil internal infrastructure | Retrieves the name of the currently registered WebUtil callback trigger. |
| WEBUTIL.GETCLIENTOSFAMILY | Package Function (WebUtil library) | WebUtil internal infrastructure | Returns the OS-family string (e.g. Windows, Unix) of the connected client machine. |
| WEBUTIL.GETCLIENTSETTING | Package Function (WebUtil library) | WebUtil internal infrastructure | Reads a named client-side configuration setting value. |
| WEBUTIL.GETIMPLCLASS | Package Function (WebUtil library) | WebUtil internal infrastructure | Returns the Java implementation class name for a registered WebUtil bean. |
| WEBUTIL.GETLASTERROR | Package Function (WebUtil library) | WebUtil internal infrastructure | Returns the numeric code of the last error recorded by WebUtil. |
| WEBUTIL.GETLASTERRORARGS | Package Function (WebUtil library) | WebUtil internal infrastructure | Returns the argument list associated with the last WebUtil error for diagnostic purposes. |
| WEBUTIL.GETNUMBER | Package Function (WebUtil library) | WebUtil internal infrastructure | Retrieves a numeric value from a WebUtil property bundle by key. |
| WEBUTIL.GETOSFAMILY | Package Function (WebUtil library) | WebUtil internal infrastructure | Returns the OS-family string of the application server host. |
| WEBUTIL.GETOUTPUT | Package Function (WebUtil library) | WebUtil internal infrastructure | Retrieves standard output captured from the most recent WebUtil host execution. |
| WEBUTIL.GETPROPERTY | Package Function (WebUtil library) | WebUtil internal infrastructure | Reads a named property value from a registered WebUtil bean. |
| WEBUTIL.GETSTRING | Package Function (WebUtil library) | WebUtil internal infrastructure | Retrieves a string value from a WebUtil property bundle by key. |
| WEBUTIL.GETVAR | Package Function (WebUtil library) | WebUtil internal infrastructure | Reads a named WebUtil session variable. |
| WEBUTIL.GET_LINE | Package Function (WebUtil library) | WebUtil internal infrastructure / PR_REMOVE_ASCII_CHR | Reads one line of text from a file opened via WEBUTIL.FOPEN. |
| WEBUTIL.GET_RETURN_CODE | Package Function (WebUtil library) | WebUtil internal infrastructure | Returns the exit or return code of the last WebUtil host-execution call. |
| WEBUTIL.GET_STANDARD_OUTPUT | Package Function (WebUtil library) | WebUtil internal infrastructure | Returns the full standard-output buffer captured from the last WebUtil execution. |
| WEBUTIL.HOST | Package Procedure (WebUtil library) | WebUtil internal infrastructure | Runs a host operating-system command on the server via the WebUtil agent. |
| WEBUTIL.INIT | Package Procedure (WebUtil library) | WebUtil internal infrastructure | Initialises the WebUtil subsystem for the current Oracle Forms session. |
| WEBUTIL.INITWEBUTIL | Package Procedure (WebUtil library) | WebUtil internal infrastructure | Performs low-level JavaBean initialisation for the WebUtil subsystem. |
| WEBUTIL.ISERROR | Package Function (WebUtil library) | WebUtil internal infrastructure | Returns TRUE if the last WebUtil operation recorded an error condition. |
| WEBUTIL.IS_OPEN | Package Function (WebUtil library) | WebUtil internal infrastructure | Returns TRUE if a given WebUtil file handle is currently open. |
| WEBUTIL.LENGTH | Package Function (WebUtil library) | WebUtil internal infrastructure | Returns the byte length of a WebUtil-managed data buffer. |
| WEBUTIL.LOG | Package Procedure (WebUtil library) | WebUtil internal infrastructure | Writes a diagnostic message to the WebUtil log output. |
| WEBUTIL.POPULATEPROPERTYBUNDLE | Package Procedure (WebUtil library) | WebUtil internal infrastructure | Populates a WebUtil property bundle with a set of name-value pairs. |
| WEBUTIL.PUTF | Package Procedure (WebUtil library) | WebUtil internal infrastructure | Writes a formatted string to a file opened via WEBUTIL.FOPEN. |
| WEBUTIL.PUT_LINE | Package Procedure (WebUtil library) | WebUtil internal infrastructure / VIEW_EXCEL_REPORT_NEW | Writes one line of text to a file opened via WEBUTIL.FOPEN. |
| WEBUTIL.READFROMPROPERTYBUNDLE | Package Function (WebUtil library) | WebUtil internal infrastructure | Reads a value from a WebUtil property bundle by its key name. |
| WEBUTIL.READTRANSFROMMSGBUNDLE | Package Function (WebUtil library) | WebUtil internal infrastructure | Reads a translated message string from a WebUtil message bundle. |
| WEBUTIL.REGISTERBEAN | Package Procedure (WebUtil library) | WebUtil internal infrastructure | Registers a WebUtil JavaBean component with the Oracle Forms runtime. |
| WEBUTIL.REGISTER_FUNCTION | Package Procedure (WebUtil library) | WebUtil internal infrastructure | Registers a named function in the WebUtil client-side dispatch table. |
| WEBUTIL.RELEASE_PROCESS | Package Procedure (WebUtil library) | WebUtil internal infrastructure | Releases resources held by a completed WebUtil host process. |
| WEBUTIL.SETCLIENTSETTING | Package Procedure (WebUtil library) | WebUtil internal infrastructure | Writes a named client-side configuration setting value. |
| WEBUTIL.SETDATA | Package Procedure (WebUtil library) | WebUtil internal infrastructure | Sets binary data content on a WebUtil-managed data buffer. |
| WEBUTIL.SETPROPERTY | Package Procedure (WebUtil library) | WebUtil internal infrastructure | Sets a named property value on a registered WebUtil bean. |
| WEBUTIL.SHOWBEANS | Package Procedure (WebUtil library) | WebUtil internal infrastructure | Displays diagnostic information about all currently registered WebUtil beans. |
| WEBUTIL.URL_TO_CLIENT | Package Function (WebUtil library) | VIEW_EXCEL_REPORT_NEW | Transfers a server-side file identified by a URL to the client desktop. Returns TRUE on success. |
| WEBUTIL.WRITEDATA | Package Procedure (WebUtil library) | WebUtil internal infrastructure | Writes binary data from a WebUtil buffer to a designated output file. |
| D2KWUTIL.ATTEMPT_DLL_LOAD | Package Procedure (D2KWUTIL library) | D2KWUTIL internal infrastructure | Attempts to load a named DLL via the D2KWUTIL client-side utility library. |
| D2KWUTIL.CHOOSEFILE | Package Function (D2KWUTIL library) | D2KWUTIL internal infrastructure | Presents a client-side file-chooser dialogue and returns the selected file path. |
| D2KWUTIL.D2KWUTIL_ACTIVEWIN | Package Function (D2KWUTIL library) | D2KWUTIL internal infrastructure | Returns the handle of the currently active client window. |
| D2KWUTIL.D2KWUTIL_CHOOSEFILE | Package Function (D2KWUTIL library) | Internal delegate of D2KWUTIL.CHOOSEFILE | Internal file-chooser delegate invoked by D2KWUTIL.CHOOSEFILE. |
| D2KWUTIL.D2KWUTIL_DEBUGSTRING | Package Procedure (D2KWUTIL library) | D2KWUTIL internal infrastructure | Emits a debug string through the D2KWUTIL diagnostic channel. |
| D2KWUTIL.D2KWUTIL_GETDOSENV | Package Function (D2KWUTIL library) | D2KWUTIL internal infrastructure | Reads a DOS or OS environment variable from the client environment. |
| D2KWUTIL.D2KWUTIL_GETREGKEY | Package Function (D2KWUTIL library) | D2KWUTIL internal infrastructure | Reads a named value from the Windows registry on the client machine. |
| D2KWUTIL.D2KWUTIL_WINDIR | Package Function (D2KWUTIL library) | D2KWUTIL internal infrastructure | Returns the Windows directory path on the client machine. |
| D2KWUTIL.GET_ACTIVE_WINDOW | Package Function (D2KWUTIL library) | D2KWUTIL internal infrastructure | Returns the handle of the active window via the D2KWUTIL interface. |
| D2KWUTIL.SAVE_FILE | Package Procedure (D2KWUTIL library) | D2KWUTIL internal infrastructure | Saves a file to a specified path on the client machine via D2KWUTIL. |
| D2KWUTIL.TRANSLATETYPE | Package Function (D2KWUTIL library) | D2KWUTIL internal infrastructure | Translates a D2KWUTIL numeric type code to its string representation. |
| ADD_ERROR | Form Program Unit (Procedure) | Error-handling infrastructure | Adds an error entry to the form-level error stack for deferred display or processing. |
| ADD_EXTERNAL_ERRORS | Form Program Unit (Procedure) | Error-handling infrastructure | Adds externally sourced error entries to the form-level error stack. |
| BOOLTOCHAR | Form Program Unit (Function) | General utility | Converts a PL/SQL BOOLEAN value to its VARCHAR2 character equivalent ('TRUE' / 'FALSE'). |
| CLEAN_ERROR_STACK | Form Program Unit (Procedure) | Error-handling infrastructure | Clears all entries from the form-level error stack, resetting it for a new operation. |
| DEBUGLOG | Form Program Unit (Procedure) | Diagnostic infrastructure | Writes a debug message to the application diagnostic log when debug mode is active. |
| GET_ENVIRONMENT_STRING | Form Program Unit (Function) | General utility | Reads a named environment variable from the server session and returns its value as a string. |
| GET_TEMP_DIRECTORY | Form Program Unit (Function) | General utility | Returns the path of the server-side temporary directory for file staging. |
| GET_WINDOWS_DIRECTORY | Form Program Unit (Function) | General utility | Returns the Windows directory path on the client machine. |
| READ_REGISTRY | Form Program Unit (Function) | General utility | Reads a named value from the Windows registry on the client machine. |
| REGISTER_FUNCTION_CALL | Form Program Unit (Procedure) | WebUtil dispatch infrastructure | Registers a function call entry in the WebUtil client-side dispatch mechanism. |
| SETDEBUG | Form Program Unit (Procedure) | Diagnostic infrastructure | Enables or disables WebUtil debug-mode output for the current session. |
| STRIPDIRSEP | Form Program Unit (Function) | General utility | Strips trailing directory-separator characters from a file path string. |
| WINDEBUG | Form Program Unit (Procedure) | Diagnostic infrastructure | Writes a debug message through the Windows debug output channel. |

---

#### GENERAL.DISP_TEXT

Called from: ON-ERROR (Form), ON-MESSAGE (Form), WHEN-VALIDATE-ITEM (CB_BLK.P_FROMDT), WHEN-VALIDATE-ITEM (CB_BLK.P_TODT), PR_REMOVE_ASCII_CHR (Form PU), via GENERAL.RAISE_ERROR (DPL.pld)

Signature: `Procedure(text_string VARCHAR2, title_string VARCHAR2)`

Displays an alert dialogue to the user with the provided message text and title. If `title_string` is `'ERROR'`, selects the AL_ERRINFO alert; for any other title, selects AL_NOTE. Sets the alert title and message text at runtime, shows the alert, and waits for user acknowledgement. No return value. Used for validation errors, system messages, and exception notifications.

---

#### GENERAL.RAISE_ERROR

Called from: ON-ERROR (Form) - database error -02292 branch

Signature: `Procedure(mesg_code IN VARCHAR2)`

Accepts an error code string, retrieves the corresponding message text and type from the error dictionary, prefixes the full message with the error code, selects the dialogue title based on message type, calls GENERAL.DISP_TEXT to show the message, and raises FORM_TRIGGER_FAILURE for Error-type ('E') messages. Shows a note or caution dialogue for other message types without raising failure.

---

#### GENERAL.ASK_CONFIRM

Called from: FT_CANCEL (Form), FT_DEL (Form), WHEN-BUTTON-PRESSED (WEBUTIL.DUMMY)

Signature: `Function(confirm_msg VARCHAR2) RETURN NUMBER`

Presents a confirmation dialogue to the user with the supplied message text. Returns a numeric result indicating the user's choice (confirmed or cancelled). Called before discarding unsaved changes (FT_CANCEL) or deleting a record (FT_DEL) to obtain explicit user consent.

---

#### VIEW_EXCEL_REPORT_NEW

Called from: WHEN-BUTTON-PRESSED (CB_BLK.SUBMIT)

Accepts principal identifier, filename, query string, column name, and application ID. Queries EH_REPORTS to look up the report server. If a server is found, uses a remote database procedure to generate the CSV, moves the file to the printer directory, reads the download URL from a configuration file, and transfers the file to the client desktop via WebUtil. If no server is found, creates an in-memory record group from the query, iterates over rows writing each to a text file on the server, then transfers the file to the client desktop via WebUtil. In both paths, opens the file on the client desktop. Reports a failure message if the file transfer does not succeed.

---

#### SF_COPYRIGHT_DECLARATION

Called from: KEY-CLRFRM (Form)

Returns the copyright declaration text for the current company. The return value is assigned to the COPYRIGHT_DECLARATION display item.

---

#### L_POPULATE

Present in form; not called from any active trigger in this form. Internally delegates list-population logic to GENERAL.L_POPULATE (DPL library) and uses WEBUTIL.ID_NULL to check whether an existing record-group handle must be deleted before creating a new one.

General-purpose list population utility. Builds a record group from a SELECT on AM_LIST for a given list name and the current principal, then populates the specified list item from that record group.

---

#### PR_REMOVE_ASCII_CHR

Present in form; not called from any active trigger in this form.

Reads a server-side CSV file line by line, skipping lines beginning with CHR(12) (form-feed), and writes the cleaned content to a second output file. Closes both files and shows the output file in the browser via WEB.SHOW_DOCUMENT. On exception, displays the SQLCODE and SQLERRM via GENERAL.DISP_TEXT.

---

#### POPULATE_ERRORS

Present in form as a package specification; no executable body.

Defines the shared variable `v_tab` (PK_PLSQL_TABLE.CODE_TAB type). No active logic.

---

#### WEBUTIL_CORE.CUSTOMEVENTHANDLER

Called from: WHEN-CUSTOM-ITEM-EVENT triggers on all WEBUTIL bean items (WEBUTIL_BROWSER_FUNCTIONS, WEBUTIL_CLIENTINFO_FUNCTIONS, WEBUTIL_C_API_FUNCTIONS, WEBUTIL_FILETRANSFER_FUNCTIONS, WEBUTIL_FILE_FUNCTIONS, WEBUTIL_HOST_FUNCTIONS, WEBUTIL_OLE_FUNCTIONS, WEBUTIL_SESSION_FUNCTIONS)

Signature: `Procedure(EventName in VARCHAR2, EventParameters in VARCHAR2)`

Central WebUtil event dispatcher. Receives the name of a custom client-side event and its associated parameter string, then routes processing to the appropriate WebUtil subsystem handler. Each WHEN-CUSTOM-ITEM-EVENT trigger on the respective WEBUTIL bean item delegates immediately to this routine, ensuring all client-to-server callbacks are handled through a single, consistent entry point.

---

#### WEBUTIL.ID_NULL

Called from: L_POPULATE (Form Program Unit)

Signature: `Function(handle IN Pointer) RETURN BOOLEAN`

Checks whether a WebUtil handle (record-group pointer) is null. Returns TRUE if the handle has no value. Used in L_POPULATE to determine whether an existing 'list' record group must be deleted before creating a new one.

## 13. Package Procedure Specifications

*NO PCK files found - no `*.pck` source files were discovered in `/app/section-rewrite-pipeline/workspaces/25e325a6-6c09-4527-bb93-d3d134e7d91a/inputs/form_sources`. Package specifications cannot be generated without uploaded PCK sources.*

## 14. Database Package Catalogue

*Detailed specifications for each database package routine called from the form, including signatures and business rules.*

*No PCK files found - no `*.pck` source files were discovered in the form sources directory. The database package catalogue cannot be generated without uploaded PCK sources.*

## 15. PLD Procedure Call Sites

*Maps each program-library routine to its call sites within triggers and program units. Behaviour descriptions are derived from the uploaded ``.pld`` sources.*

### DPL.pld (`general`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ASK_CONFIRM | Function | Function(confirm_msg VARCHAR2) RETURN NUMBER | Trigger: FT_CANCEL in Form, Trigger: FT_DEL in Form, Trigger: WHEN-BUTTON-PRESSED in WEBUTIL.DUMMY | Presents a confirmation dialog to the user with the supplied message text and returns a numeric result indicating the user's choice. Called from FT_CANCEL and FT_DEL to prompt the user before discarding changes or deleting a record, and from the WEBUTIL.DUMMY WHEN-BUTTON-PRESSED trigger. |
| DISP_TEXT | Procedure | Procedure(text_string VARCHAR2, title_string VARCHAR2) | ProgramUnit: PR_REMOVE_ASCII_CHR, Trigger: FT_INSERT in Form, Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_FROMDT, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_TODT | Displays a message to the user via an alert dialog. If title_string is 'ERROR', uses the AL_ERRINFO alert; otherwise uses AL_NOTE. Sets the alert title and message text at runtime before showing it. No return value. Used for validation errors, system messages, and exception notifications. |
| L_POPULATE | Procedure | Procedure(P_LIST_NAME VARCHAR2,P_LIST_FIELD VARCHAR2) | ProgramUnit: L_POPULATE | Populates a named list item (LOV/list element) by building or refreshing a record group identified by P_LIST_NAME and binding it to the form field P_LIST_FIELD. Called from within the L_POPULATE program unit to delegate list-population logic to the shared DPL library routine. |
| RAISE_ERROR | Procedure | Procedure(mesg_code IN VARCHAR2) | Trigger: ON-ERROR in Form | Looks up an error message by its code, prefixes it with the code, and displays it via DISP_TEXT. Raises FORM_TRIGGER_FAILURE for error-type messages ('E'); shows note or caution dialog for other types. Used to surface database integrity errors (e.g. E0088 for -02292 constraint violation). |

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``rr_pre_enq_dlr_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| CHECK_NULL | Procedure | Procedure(p_value IN VARCHAR2, column_title IN VARCHAR2) | ProgramUnit: VALIDATE_CN_MAIN | **COMMENTED OUT / INACTIVE** - Referenced only within the fully commented-out VALIDATE_CN_MAIN procedure. Would have raised FORM_TRIGGER_FAILURE if p_value was null, displaying "Enter a valid {column_title}" as an error message. |

**Total Active Routines:** 4 of 24 in DPL.pld source
**Inactive / commented-only routines:** 1

---

### webutil.pld (`WEBUTIL_CORE`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| CustomEventHandler | Procedure | Procedure(EventName in VARCHAR2, EventParameters in VARCHAR2) | Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_BROWSER_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_CLIENTINFO_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_C_API_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_FILETRANSFER_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_FILE_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_HOST_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_OLE_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_SESSION_FUNCTIONS | Central WebUtil event dispatcher. Receives the name of a custom client-side event and its associated parameter string, then routes processing to the appropriate WebUtil subsystem handler. Each WHEN-CUSTOM-ITEM-EVENT trigger on the respective WEBUTIL bean item delegates immediately to this routine, ensuring all client-to-server callbacks are handled through a single, consistent entry point. |

**Total Active Routines:** 1 of 39 in webutil.pld source

---

### webutil.pld (`WEBUTIL_C_API`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ID_NULL | Function | Function(handle IN Pointer) RETURN BOOLEAN | ProgramUnit: L_POPULATE | Checks whether a WebUtil handle (record group pointer) is null. Returns TRUE if the handle has no value. Used in L_POPULATE to determine whether an existing 'list' record group must be deleted before creating a new one. |

**Total Active Routines:** 1 of 28 in webutil.pld source

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| ID | Service Name | Database Object | Input Parameters | Output | Business Function | API Endpoint Suggestion |
| -- | ------------ | --------------- | ---------------- | ------ | ----------------- | ----------------------- |
| MS-001 | Pre-Enquiry Campaign Report Generator | MULDMS.PRE_ENQ_CAMPAIGN, MULDMS.AM_DEALER_LOC, MULDMS.RH_ENQ, MULDMS.RD_ENQ, MULDMS.SH_ORDBOOK, MULDMS.SH_INVOICE, GM_MOD, GM_VAR, MULDMS.GM_CITY, MULDMS.RM_ETYPES, AM_LIST | principal, dealerMapCd, locCd, parentGroup, campaignCode (or 'ALL'), fromDate, toDate, appId | CSV file stream (one row per pre-enquiry record: region, campaign code/name/date/model, dealer code/name/city, prospect name/address, follow-up status, remarks, enquiry details, booking date, invoice date, invoiced model) | Generates the pre-enquiry dealer campaign report covering all prospect records for the specified dealer, location, campaign, and date range; includes full tracing from pre-enquiry through to booking and invoice | POST /api/v1/reports/pre-enquiry-campaign/generate |
| MS-002 | Campaign Code Lookup | MULDMS.PRE_ENQ_CAMPAIGN, MULDMS.AM_DEALER_LOC, MULDMS.GM_REGN | principal, dealerMapCd, locCd, parentGroup | List of campaign codes and names available for the dealer (including an "All" option) | Provides the list of valid campaign codes and descriptions for the logged-in dealer to populate the campaign selection filter | GET /api/v1/campaigns/lookup?principal={principal}&dealerMapCd={dealerMapCd}&locCd={locCd}&parentGroup={parentGroup} |
| MS-003 | Error Message Lookup | AM_PERMISSIONS (via GENERAL.RAISE_ERROR) | errorCode | Error message text, message type (Error / Note / Caution) | Retrieves the business-friendly error message text for a given internal error code; used by the error handling layer to display standardised messages to users | GET /api/v1/messages/{errorCode} |
| MS-004 | Report Server Configuration Lookup | EH_REPORTS | principal, appId | Report server identifier (or null if not configured) | Determines whether a dedicated report server is configured for the given principal and application; drives the report generation path selection | GET /api/v1/config/report-server?principal={principal}&appId={appId} |
| MS-005 | Copyright Declaration Retrieval | N/A (function logic - EXTERNAL / NOT IN BUNDLE - source file SF_COPYRIGHT_DECLARATION.fnc not fully readable) | N/A (principal / company context from session) | Copyright declaration text for the current company | Returns the copyright notice applicable to the currently logged-in company for display on each form screen | GET /api/v1/company/copyright-declaration |

**Total Microservices Identified: 5**

---

## 17. Workflows

| ID | Workflow Name | Trigger Event | Steps | Decision Points | End State |
| -- | ------------- | ------------- | ----- | --------------- | --------- |
| WF-001 | Form Open and Session Initialisation | User opens the Pre-Enquiry Dealer Report screen (PRE-FORM trigger fires) | 1. Register form name and session identity in database monitoring. 2. Check if application logging is active. 3. If active, start the performance timer. | Is application logging active? Yes -> start timer; No -> skip timer | Screen is open and ready for filter input; session identity is registered in the database |
| WF-002 | Campaign Date Range Entry and Validation | User enters the Campaign From Date (WHEN-VALIDATE-ITEM on CB_BLK.P_FROMDT fires) | 1. Check From Date is not empty. 2. Check From Date is not after today. 3. Check From Date is not after To Date (if To Date is already entered). 4. Auto-calculate and set To Date to min(From Date + 1 month - 1 day, today). | Is From Date empty? -> error and stop. Is From Date after today? -> error and stop. Is From Date after To Date? -> error and stop. Is calculated month-end after today? -> set To Date = today; otherwise set To Date = calculated month-end. | From Date accepted; To Date automatically set to appropriate default |
| WF-003 | Campaign To Date Validation | User overrides or enters the Campaign To Date (WHEN-VALIDATE-ITEM on CB_BLK.P_TODT fires) | 1. Check To Date is not empty. 2. Check From Date has been entered. 3. Check To Date is not before From Date. 4. Check From Date is not after To Date. 5. Check To Date is not after today. 6. Check date range does not exceed three months. | Is To Date empty? -> error. Is From Date absent? -> clear To Date, error. Is To Date < From Date? -> error. Is From Date > To Date? -> error. Is To Date after today? -> error. Is range > 3 months? -> error. | To Date accepted; date range is valid and ready for report submission |
| WF-004 | Pre-Enquiry Campaign Report Generation | User clicks the Submit Report button (WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT fires) | 1. Generate unique report filename from user ID and timestamp. 2. Adjust To Date to exclusive upper bound (To Date + 1 day). 3. Build dynamic SQL query for pre-enquiry campaign data. 4. Call VIEW_EXCEL_REPORT_NEW with principal, filename, query, and app ID. 5. VIEW_EXCEL_REPORT_NEW looks up report server; if found, generates CSV via remote procedure and transfers to client; if not found, generates CSV locally and transfers to client. 6. Open the CSV file on the user's desktop. | Is a dedicated report server configured? -> Yes: use remote generation path; No: use local in-memory generation path. Does the filename path contain spaces? -> Yes: redirect to C:\ root and warn user. Does file transfer succeed? -> No: show "File Transfer failed" message. | CSV report file delivered to user's desktop and opened; or error message displayed if delivery fails |
| WF-005 | Custom Form Error Handling | Any Oracle Forms or database error event during user interaction (ON-ERROR trigger fires) | 1. Check error code 50004 -> show date-invalid message, stop. 2. Check error codes 50025/50026 -> show date-format message, stop. 3. Check error codes 40209/50016 -> show character-type message, stop. 4. Check error code 40207 -> show field error text, stop. 5. Check database error -02292 -> raise standardised E0088 error. 6. Check error codes 40654-40659 -> show concurrent-update message, rollback, stop. 7. Check SQLCODE ≠ 0 -> show SQLERRM, rollback, stop. 8. Check error codes 40401/40405 -> suppress silently. | Which error code is raised? -> Route to the matching handler. Is database error -02292? -> Call GENERAL.RAISE_ERROR. Is SQLCODE non-zero and no other handler matched? -> Show SQLERRM. Are error codes 40401 or 40405? -> Suppress silently and continue. | Error message displayed to user (or suppressed silently for 40401/40405); trigger failure raised to stop current processing where applicable; transaction rolled back for concurrency and SQL errors |
| WF-006 | Custom Form Message Handling | Oracle Forms raises system message code 40209 or 40207 (ON-MESSAGE trigger fires) | 1. Compose message string: error-type + '-' + error-code + ': ' + error-text. 2. Display composed string in error dialogue via GENERAL.DISP_TEXT. 3. Raise trigger failure to stop current action. | Is error code 40209 or 40207? -> Yes: intercept and show as error dialogue. Any other message code -> not intercepted (falls through to default Forms handling). | Message shown in a prominent error dialogue; current action stopped |
| WF-007 | Form Clear and Copyright Refresh | User presses the clear-form key (KEY-CLRFRM trigger fires) | 1. Clear all form field values without saving (clear_form no_validate). 2. Call SF_COPYRIGHT_DECLARATION to retrieve the current copyright text. 3. Populate the copyright declaration display field with the retrieved text. | N/A - no conditional branching (copyright function called unconditionally after clear) | All fields cleared; copyright declaration refreshed to reflect current company context |
| WF-008 | Form Exit with Session Cleanup | User presses the exit key (KEY-EXIT trigger fires) | 1. Clear the session client-info identifier (DBMS_APPLICATION_INFO.SET_CLIENT_INFO to null). 2. Clear the session module name and action (DBMS_APPLICATION_INFO.SET_MODULE to empty values). 3. Close the form without saving (EXIT_FORM NO_VALIDATE). | N/A - all steps execute unconditionally | Form closed; session monitoring identifiers cleared; unsaved data discarded |

**Total Workflows Identified: 8**

---

## 18. PLD-Backed Logic

*Maps shared library routines to their business function and suggested API contracts.*

### webutil.pld (`CLIENT_IMAGE`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | ID_NULL | Business Logic | ProgramUnit: L_POPULATE | /api/v1/pld/id_null | When a record group handle is checked, then returns true if the handle is null, allowing the caller to decide whether to delete and recreate the group |


---

### DPL.pld (`general`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | CHECK_NULL | Validation | ProgramUnit: VALIDATE_CN_MAIN | /api/v1/pld/check_null | **COMMENTED OUT / INACTIVE** - When a required field is null, then raises a validation failure with an "Enter a valid {field}" message |
| PLD-002 | DISP_TEXT | Business Logic | ProgramUnit: PR_REMOVE_ASCII_CHR, Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_FROMDT, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_TODT | /api/v1/pld/disp_text | When a message must be shown to the user, then displays it in an alert dialog using error or note style based on the supplied title |
| PLD-003 | RAISE_ERROR | Validation | Trigger: ON-ERROR in Form | /api/v1/pld/raise_error | When a database error code is encountered, then retrieves the corresponding message and displays it as an error, note, or caution alert, raising form failure for error-type messages |


---

### D2kwutil.pld (`Win_API`)

*No routines from ``D2kwutil.pld`` are referenced in ``rr_pre_enq_dlr_fmb.xml``.*

---

---

## 19. PCK-Backed Logic

*Maps database package routines to their business rules and suggested API contracts.*

*No package routines from the available PCK files are referenced in ``rr_pre_enq_dlr_fmb.xml``.*

---

---

## 20. System Interfaces

### 20.1 Database Integrations

| Interface Name | Type | Purpose | Data Flow | Error Handling |
| -------------- | ---- | ------- | --------- | -------------- |
| Pre-Enquiry Campaign Data Read | SQL SELECT (dynamic, via VIEW_EXCEL_REPORT_NEW) | Retrieves all pre-enquiry campaign prospect records for the selected dealer, location, campaign, and date range for CSV export | Form -> MULDMS.PRE_ENQ_CAMPAIGN (+ joined tables: MULDMS.AM_DEALER_LOC, MULDMS.RH_ENQ, MULDMS.RD_ENQ, MULDMS.SH_ORDBOOK, MULDMS.SH_INVOICE, GM_MOD, GM_VAR, MULDMS.GM_CITY, MULDMS.RM_ETYPES, AM_LIST) | Unhandled database errors are caught by the ON-ERROR trigger and displayed via GENERAL.DISP_TEXT; rollback performed |
| Report Server Configuration Lookup | SQL SELECT | Looks up whether a dedicated report server is configured for the current principal and application ID | Form -> EH_REPORTS | WHEN OTHERS exception handler sets lv_rep_server to null; local generation path used as fallback |
| Campaign Code List Query | SQL SELECT (via record group RG_CAMPAIGN) | Populates the campaign code selection list with distinct campaign codes and names for the logged-in dealer | Form -> MULDMS.PRE_ENQ_CAMPAIGN, MULDMS.AM_DEALER_LOC, MULDMS.GM_REGN | N/A - list displayed at LOV invocation time |
| General List Population | SQL SELECT (via L_POPULATE form program unit - AM_LIST) | Provides a generic mechanism to populate any AM_LIST-backed list item on the form | Form -> AM_LIST (filtered by list_name and principal) | N/A - program unit not called from any active trigger in this form |
| Database Session Registration | Oracle DBMS_APPLICATION_INFO package | Registers and clears the form module identity in the database session for monitoring purposes | Form -> Oracle session metadata (DBMS_APPLICATION_INFO.SET_CLIENT_INFO, SET_MODULE) | No error handling - these are fire-and-forget session calls |
| Error Message Lookup (GENERAL.RAISE_ERROR) | SQL SELECT (within DPL.pld - GENERAL.RAISE_ERROR reads AM_PERMISSIONS) | Retrieves the error message text and type for a given internal error code on database constraint violations | DPL GENERAL package -> AM_PERMISSIONS | GENERAL.RAISE_ERROR composes message from available data; GENERAL.DISP_TEXT displays it; FORM_TRIGGER_FAILURE raised |
| Remote CSV Generation (Report Server path) | Remote database link call (sp_csv_report_generate@dms1_db3_lnk) | When a report server is configured, delegates CSV generation to a remote database procedure over a database link | Form (VIEW_EXCEL_REPORT_NEW) -> remote database via dms1_db3_lnk | WHEN OTHERS in VIEW_EXCEL_REPORT_NEW - errors logged or surfaced |

### 20.2 External System Integrations

| System Name | Integration Type | Purpose | Protocol | Endpoint | Data Exchange | Success / Error Codes |
| ----------- | ---------------- | ------- | -------- | -------- | ------------- | --------------------- |
| Oracle Application Server / Reports Printer Directory | File System (HOST command via WebUtil) | The generated CSV file is moved from the UTL_DIR output location to the reports printer directory using a server-side shell command | WebUtil HOST (shell command) | /bin/mv /utl_dir/{filename} /iashome/ias/reports/printer/{filename} (INFERRED server path) | File move on application server | Failure not explicitly handled - VIEW_EXCEL_REPORT_NEW proceeds to file transfer step after the move |
| Client Desktop (file transfer via WebUtil) | WebUtil file transfer (WebUtil_File_Transfer.Url_To_Client) | Transfers the generated CSV file from the application server to the user's local desktop | WebUtil HTTP/file transfer | URL read from /reports/DMS/excelpath.txt on server + filename | Outbound: server-side CSV file -> client desktop file | If transfer returns false, message "File Transfer failed" is shown to the user |
| Client Desktop (file open via WebUtil HOST) | WebUtil HOST command | Opens the transferred CSV file on the user's desktop using the default application (typically a spreadsheet application) | WebUtil HOST | cmd /c {FILENAME} (client-side shell) | Outbound: filename to client shell | No explicit error handling for the open command |

### 20.3 Report Integrations

| Report Name | Report Server | Parameters | Output Format | Trigger |
| ----------- | ------------- | ---------- | ------------- | ------- |
| rep.rdf | INFERRED - application server report server (looked up at runtime via EH_REPORTS for the current principal and app ID) | principal, filename, query string ('entire_string' column), P_APP_ID | CSV (comma-separated values, one header row followed by data rows) | WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT - user clicks the Submit Report button |

---

### 20.3.1 Parameters Passed to the Report

This form does not pass parameters to an Oracle Report. No report parameters were identified in the form sources.

## 21. Procedure and Function Business Rule Catalogue

End-to-end business requirement specification for every stored procedure and function referenced by the RR_PRE_ENQ_DLR form.

### 21.1 Catalogue Index

81 procedures/functions - each SP ID links to its detailed specification in Section 21.2.

| SP Index | Routine Name |
| :--- | :--- |
| [SP-001](#SP-001--D2KWUTIL.ATTEMPT_DLL_LOAD) | D2KWUTIL.ATTEMPT_DLL_LOAD |
| [SP-002](#SP-002--D2KWUTIL.CHOOSEFILE) | D2KWUTIL.CHOOSEFILE |
| [SP-003](#SP-003--D2KWUTIL.D2KWUTIL_ACTIVEWIN) | D2KWUTIL.D2KWUTIL_ACTIVEWIN |
| [SP-004](#SP-004--D2KWUTIL.D2KWUTIL_CHOOSEFILE) | D2KWUTIL.D2KWUTIL_CHOOSEFILE |
| [SP-005](#SP-005--D2KWUTIL.D2KWUTIL_DEBUGSTRING) | D2KWUTIL.D2KWUTIL_DEBUGSTRING |
| [SP-006](#SP-006--D2KWUTIL.D2KWUTIL_GETDOSENV) | D2KWUTIL.D2KWUTIL_GETDOSENV |
| [SP-007](#SP-007--D2KWUTIL.D2KWUTIL_GETREGKEY) | D2KWUTIL.D2KWUTIL_GETREGKEY |
| [SP-008](#SP-008--D2KWUTIL.D2KWUTIL_WINDIR) | D2KWUTIL.D2KWUTIL_WINDIR |
| [SP-009](#SP-009--D2KWUTIL.GET_ACTIVE_WINDOW) | D2KWUTIL.GET_ACTIVE_WINDOW |
| [SP-010](#SP-010--D2KWUTIL.SAVE_FILE) | D2KWUTIL.SAVE_FILE |
| [SP-011](#SP-011--D2KWUTIL.TRANSLATETYPE) | D2KWUTIL.TRANSLATETYPE |
| [SP-012](#SP-012--GENERAL.ASK_CONFIRM) | GENERAL.ASK_CONFIRM |
| [SP-013](#SP-013--GENERAL.DISP_TEXT) | GENERAL.DISP_TEXT |
| [SP-014](#SP-014--GENERAL.RAISE_ERROR) | GENERAL.RAISE_ERROR |
| [SP-015](#SP-015--WEBUTIL.BLOCKING) | WEBUTIL.BLOCKING |
| [SP-016](#SP-016--WEBUTIL.CHECKLIBS) | WEBUTIL.CHECKLIBS |
| [SP-017](#SP-017--WEBUTIL.CLEARCALLBACKTRIGGER) | WEBUTIL.CLEARCALLBACKTRIGGER |
| [SP-018](#SP-018--WEBUTIL.CLOSEBLOB) | WEBUTIL.CLOSEBLOB |
| [SP-019](#SP-019--WEBUTIL.CLOSEFILE) | WEBUTIL.CLOSEFILE |
| [SP-020](#SP-020--WEBUTIL.DOWNLOADFROMURL) | WEBUTIL.DOWNLOADFROMURL |
| [SP-021](#SP-021--WEBUTIL.DOWNLOADFROMURLINT) | WEBUTIL.DOWNLOADFROMURLINT |
| [SP-022](#SP-022--WEBUTIL.ERROR) | WEBUTIL.ERROR |
| [SP-023](#SP-023--WEBUTIL.ERRORALERT) | WEBUTIL.ERRORALERT |
| [SP-024](#SP-024--WEBUTIL.EXECUTE) | WEBUTIL.EXECUTE |
| [SP-025](#SP-025--WEBUTIL.FCLOSE) | WEBUTIL.FCLOSE |
| [SP-026](#SP-026--WEBUTIL.FILE_SAVE_DIALOG) | WEBUTIL.FILE_SAVE_DIALOG |
| [SP-027](#SP-027--WEBUTIL.FILE_SELECTION_DIALOG_INT) | WEBUTIL.FILE_SELECTION_DIALOG_INT |
| [SP-028](#SP-028--WEBUTIL.FOPEN) | WEBUTIL.FOPEN |
| [SP-029](#SP-029--WEBUTIL.GETCALLBACKTRIGGER) | WEBUTIL.GETCALLBACKTRIGGER |
| [SP-030](#SP-030--WEBUTIL.GETCLIENTOSFAMILY) | WEBUTIL.GETCLIENTOSFAMILY |
| [SP-031](#SP-031--WEBUTIL.GETCLIENTSETTING) | WEBUTIL.GETCLIENTSETTING |
| [SP-032](#SP-032--WEBUTIL.GETIMPLCLASS) | WEBUTIL.GETIMPLCLASS |
| [SP-033](#SP-033--WEBUTIL.GETLASTERROR) | WEBUTIL.GETLASTERROR |
| [SP-034](#SP-034--WEBUTIL.GETLASTERRORARGS) | WEBUTIL.GETLASTERRORARGS |
| [SP-035](#SP-035--WEBUTIL.GETNUMBER) | WEBUTIL.GETNUMBER |
| [SP-036](#SP-036--WEBUTIL.GETOSFAMILY) | WEBUTIL.GETOSFAMILY |
| [SP-037](#SP-037--WEBUTIL.GETOUTPUT) | WEBUTIL.GETOUTPUT |
| [SP-038](#SP-038--WEBUTIL.GETPROPERTY) | WEBUTIL.GETPROPERTY |
| [SP-039](#SP-039--WEBUTIL.GETSTRING) | WEBUTIL.GETSTRING |
| [SP-040](#SP-040--WEBUTIL.GETVAR) | WEBUTIL.GETVAR |
| [SP-041](#SP-041--WEBUTIL.GET_LINE) | WEBUTIL.GET_LINE |
| [SP-042](#SP-042--WEBUTIL.GET_RETURN_CODE) | WEBUTIL.GET_RETURN_CODE |
| [SP-043](#SP-043--WEBUTIL.GET_STANDARD_OUTPUT) | WEBUTIL.GET_STANDARD_OUTPUT |
| [SP-044](#SP-044--WEBUTIL.HOST) | WEBUTIL.HOST |
| [SP-045](#SP-045--WEBUTIL.ID_NULL) | WEBUTIL.ID_NULL |
| [SP-046](#SP-046--WEBUTIL.INIT) | WEBUTIL.INIT |
| [SP-047](#SP-047--WEBUTIL.INITWEBUTIL) | WEBUTIL.INITWEBUTIL |
| [SP-048](#SP-048--WEBUTIL.ISERROR) | WEBUTIL.ISERROR |
| [SP-049](#SP-049--WEBUTIL.IS_OPEN) | WEBUTIL.IS_OPEN |
| [SP-050](#SP-050--WEBUTIL.LENGTH) | WEBUTIL.LENGTH |
| [SP-051](#SP-051--WEBUTIL.LOG) | WEBUTIL.LOG |
| [SP-052](#SP-052--WEBUTIL.POPULATEPROPERTYBUNDLE) | WEBUTIL.POPULATEPROPERTYBUNDLE |
| [SP-053](#SP-053--WEBUTIL.PUTF) | WEBUTIL.PUTF |
| [SP-054](#SP-054--WEBUTIL.PUT_LINE) | WEBUTIL.PUT_LINE |
| [SP-055](#SP-055--WEBUTIL.READFROMPROPERTYBUNDLE) | WEBUTIL.READFROMPROPERTYBUNDLE |
| [SP-056](#SP-056--WEBUTIL.READTRANSFROMMSGBUNDLE) | WEBUTIL.READTRANSFROMMSGBUNDLE |
| [SP-057](#SP-057--WEBUTIL.REGISTERBEAN) | WEBUTIL.REGISTERBEAN |
| [SP-058](#SP-058--WEBUTIL.REGISTER_FUNCTION) | WEBUTIL.REGISTER_FUNCTION |
| [SP-059](#SP-059--WEBUTIL.RELEASE_PROCESS) | WEBUTIL.RELEASE_PROCESS |
| [SP-060](#SP-060--WEBUTIL.SETCLIENTSETTING) | WEBUTIL.SETCLIENTSETTING |
| [SP-061](#SP-061--WEBUTIL.SETDATA) | WEBUTIL.SETDATA |
| [SP-062](#SP-062--WEBUTIL.SETPROPERTY) | WEBUTIL.SETPROPERTY |
| [SP-063](#SP-063--WEBUTIL.SHOWBEANS) | WEBUTIL.SHOWBEANS |
| [SP-064](#SP-064--WEBUTIL.URL_TO_CLIENT) | WEBUTIL.URL_TO_CLIENT |
| [SP-065](#SP-065--WEBUTIL.WRITEDATA) | WEBUTIL.WRITEDATA |
| [SP-066](#SP-066--WEBUTIL_CORE.CUSTOMEVENTHANDLER) | WEBUTIL_CORE.CUSTOMEVENTHANDLER |
| [SP-067](#SP-067--ADD_ERROR) | ADD_ERROR |
| [SP-068](#SP-068--ADD_EXTERNAL_ERRORS) | ADD_EXTERNAL_ERRORS |
| [SP-069](#SP-069--BOOLTOCHAR) | BOOLTOCHAR |
| [SP-070](#SP-070--CLEAN_ERROR_STACK) | CLEAN_ERROR_STACK |
| [SP-071](#SP-071--DEBUGLOG) | DEBUGLOG |
| [SP-072](#SP-072--GET_ENVIRONMENT_STRING) | GET_ENVIRONMENT_STRING |
| [SP-073](#SP-073--GET_TEMP_DIRECTORY) | GET_TEMP_DIRECTORY |
| [SP-074](#SP-074--GET_WINDOWS_DIRECTORY) | GET_WINDOWS_DIRECTORY |
| [SP-075](#SP-075--READ_REGISTRY) | READ_REGISTRY |
| [SP-076](#SP-076--REGISTER_FUNCTION_CALL) | REGISTER_FUNCTION_CALL |
| [SP-077](#SP-077--SETDEBUG) | SETDEBUG |
| [SP-078](#SP-078--SF_COPYRIGHT_DECLARATION) | SF_COPYRIGHT_DECLARATION |
| [SP-079](#SP-079--STRIPDIRSEP) | STRIPDIRSEP |
| [SP-080](#SP-080--VIEW_EXCEL_REPORT_NEW) | VIEW_EXCEL_REPORT_NEW |
| [SP-081](#SP-081--WINDEBUG) | WINDEBUG |

---

### 21.2 Detailed Specifications

#### SP-001 - D2KWUTIL.ATTEMPT_DLL_LOAD

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Attempts to load a Windows DLL from a specified file-system path so that external Win32 API functions become available to the form. If the file cannot be found at the given location the attempt is abandoned gracefully and the API is marked as unavailable.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |
| TargetDLL | VARCHAR2 | IN |
| LoadCount | BOOLEAN | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |

---

**Dependencies**

- DEBUGLOG ([SP-071](#SP-071--DEBUGLOG)) - matched by member name
- STRIPDIRSEP ([SP-079](#SP-079--STRIPDIRSEP)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - If a target path is supplied, strip any extra path segments after a semicolon and ensure the path ends with a backslash.
- Step 2 - Attempt to open the DLL file at the combined path and filename to confirm it physically exists; if the file cannot be opened, log a debug message and raise a "bad location" error to abort.
- Step 3 - Load the DLL library using the validated path and filename.
- Step 4 - If the load-count flag is TRUE, increment the global DLL load counter and mark the API as enabled.
- Step 5 - Return the library handle to the caller; if any unhandled error occurs, mark the API as disabled and return a null handle.

---
**Decision Points**

DP-001

Condition:
Whether a target path was supplied by the caller.

TRUE:
Strip the path of extraneous segments, append a trailing backslash, verify the file exists, then proceed to load the DLL.

FALSE:
Skip path validation and attempt to load the DLL using only the filename (no specific directory prefix).

DP-002

Condition:
Whether the DLL file can be physically opened at the specified location.

TRUE:
Close the test file handle and proceed to load the DLL.

FALSE:
Log a debug warning and raise a "bad location" exception to prevent the load.

DP-003

Condition:
Whether the load-count flag is TRUE.

TRUE:
Increment the global DLL load counter and mark the API as enabled.

FALSE:
Load the DLL without updating the counter or enabling the API flag.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - If multiple paths are included in the target path (separated by semicolons), only the first path segment is used; the rest are discarded.
- BR-002 - The DLL file must be physically present on the file system before a load is attempted; a missing file results in an immediate abort.
- BR-003 - If the DLL load fails for any reason, the API is marked as unavailable so that subsequent callers know Win32 functions cannot be used.

---
**Implementation Logic**

```plsql

FUNCTION  Attempt_DLL_Load  (TargetPath in out VARCHAR2, TargetDLL in VARCHAR2, LoadCount in BOOLEAN DEFAULT TRUE) return ORA_FFI.LibHandleType is
  hDLL  ORA_FFI.LibHandleType;
  hFile TEXT_IO.FILE_TYPE;
begin 
    	
  if TargetPath is not null then 
    -- Watch out for folks who put multiple Paths in here 
    -- Oh yes it's happened! Just use the first & throw the rest away
    -- Add trailing Directory Sep if required
    TargetPath := StripDirSep(TargetPath)||'\';
    
    -- Check that there is actually a file there.
    begin 
  	  hFile := TEXT_IO.FOPEN(TargetPath||TargetDLL,'R');
  	  TEXT_IO.FCLOSE(hFile);
    exception
  	  when others then
  	    Win_API_Debug.DebugLog(99,'Attempt_DLL_LOAD',TargetDLL||' not found in the specified location of "'||TargetPath||'"'); 
  		  raise BadLocation;
    end;
  end if;
  
  hDLL := ORA_FFI.LOAD_LIBRARY(TargetPath, TargetDLL);
  if LoadCount then 
    DLL_LOAD_COUNT  := DLL_LOAD_COUNT + 1;
    API_ENABLED  := TRUE;
  end if;
  return hDLL;
exception
  when others then 
    API_ENABLED := FALSE;
    return hDLL; /* Will be null */
end Attempt_DLL_Load;
```

#### SP-002 - D2KWUTIL.CHOOSEFILE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.SAVE_FILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Presents a Windows file-chooser dialogue (either Open or Save) to the user and returns the path of the selected file. It resolves special directory tokens such as the Windows directory or the TEMP directory, ensures a valid file filter is applied, and gracefully reports any errors back to the calling routine.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| CalledBy | VARCHAR2 | IN |
| Modal | BOOLEAN | IN |
| szTitle | VARCHAR2 | IN |
| szInitDir | VARCHAR2 | IN |
| szFileFilter | VARCHAR2 | IN |
| Flags | PLS_INTEGER | IN |
| SepChar | VARCHAR2 | IN |
| szBuffer | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| szBuffer | VARCHAR2 | IN OUT |

---

**Dependencies**

- ADD_ERROR ([SP-067](#SP-067--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-068](#SP-068--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-069](#SP-069--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-070](#SP-070--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_CHOOSEFILE ([SP-004](#SP-004--D2KWUTIL.D2KWUTIL_CHOOSEFILE)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- D2KWUTIL.GET_ACTIVE_WINDOW ([SP-009](#SP-009--D2KWUTIL.GET_ACTIVE_WINDOW)) - D2KWUTIL.pck (or .pld)
- DEBUGLOG ([SP-071](#SP-071--DEBUGLOG)) - matched by member name
- GET_TEMP_DIRECTORY ([SP-073](#SP-073--GET_TEMP_DIRECTORY)) - matched by member name
- GET_WINDOWS_DIRECTORY ([SP-074](#SP-074--GET_WINDOWS_DIRECTORY)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-076](#SP-076--REGISTER_FUNCTION_CALL)) - matched by member name
- WEBUTIL.LENGTH ([SP-050](#SP-050--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Log input arguments for diagnostic purposes and clear the error stack.
- Step 2 - If the dialogue is to be modal, obtain the handle of the currently active window to use as the owner; otherwise set the owner handle to zero (no parent window).
- Step 3 - Check whether the Win32 API is available; if not, raise a "not available" exception.
- Step 4 - Register the underlying Win32 file-chooser DLL function.
- Step 5 - Determine the dialogue type: Open File if the caller is "Open_File", otherwise Save File.
- Step 6 - Resolve the initial directory: if the caller passed the token "$WINDIR$" use the Windows directory; if "$TEMP$" use the temporary directory; otherwise use the value as supplied.
- Step 7 - Ensure the resolved directory path ends with a backslash.
- Step 8 - If no file filter was supplied, default to "All files (*.*)|*.*|".
- Step 9 - Pad the file buffer to 4096 characters with null terminators and invoke the Win32 chooser function.
- Step 10 - Log the result, update the output buffer with the selected filename, and return the numeric return code.
- Step 11 - On "not available" error, record the error and re-raise; on any other error, record the error with external error details and re-raise.

---
**Decision Points**

DP-001

Condition:
Whether the dialogue should be displayed as modal (owned by the active window).

TRUE:
Obtain the active window handle to act as the dialogue owner.

FALSE:
Set the owner handle to zero so the dialogue has no parent window.

DP-002

Condition:
Whether the Win32 API is currently enabled and available.

TRUE:
Proceed to register the function and display the dialogue.

FALSE:
Raise a "not available" exception and record the error.

DP-003

Condition:
Whether the caller identifier is "Open_File".

TRUE:
Set the dialogue type to Open (type 1).

FALSE:
Set the dialogue type to Save (type 2).

DP-004

Condition:
Whether the initial directory token is the special value "$WINDIR$".

TRUE:
Resolve the directory to the Windows installation directory.

FALSE:
Check for "$TEMP$" or use the supplied directory value as-is.

DP-005

Condition:
Whether the initial directory token is the special value "$TEMP$".

TRUE:
Resolve the directory to the operating system temporary directory.

FALSE:
Use the supplied directory value unchanged.

DP-006

Condition:
Whether the resolved directory path already ends with a backslash.

TRUE:
Use the path as-is.

FALSE:
Append a backslash to the end of the path.

DP-007

Condition:
Whether a file filter string was supplied by the caller.

TRUE:
Use the caller-supplied filter.

FALSE:
Default the filter to "All files(*.*)|*.*|".

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The dialogue type is determined solely by the "CalledBy" parameter value; only "Open_File" produces an Open dialogue - all other callers produce a Save dialogue.
- BR-002 - If no file filter is provided, the dialogue always defaults to showing all files.
- BR-003 - The special directory tokens "$WINDIR$" and "$TEMP$" (case-insensitive) are translated at runtime to the actual Windows and TEMP directory paths respectively.
- BR-004 - The file-name buffer is always padded to 4096 characters before being passed to the Win32 API to accommodate long paths.

---
**Implementation Logic**

```plsql
    
FUNCTION ChooseFile(  CalledBy      IN      VARCHAR2,
                      Modal         IN      BOOLEAN,
                      szTitle       IN      VARCHAR2,
                      szInitDir     IN      VARCHAR2,
                      szFileFilter  IN      VARCHAR2,
                      Flags         IN      PLS_INTEGER,
                      SepChar       IN      VARCHAR2,
                      szBuffer      IN OUT  VARCHAR2 ) RETURN PLS_INTEGER is
  hwndOwner  PLS_INTEGER;
  iBuff1     PLS_INTEGER;
  iBuff2     PLS_INTEGER;
  iRC        PLS_INTEGER;
  vcBuff1    VARCHAR2(255);
  vcBuff2    VARCHAR2(2000);
  vcBuff3    VARCHAR2(100);
  vcBuff4    VARCHAR2(1);
  vcBuff5    VARCHAR2(4096);
begin 
  Win_API_Debug.DebugLog(99,'ChooseFile','Args: CalledBy="'||CalledBy||', Modal='||win_api_debug.BoolToChar(Modal)||', szTitle="'||szTitle||'", szInitDir="'||szInitDir||'", szFileFilter="'||szFileFilter||'", Flags='||to_char(flags)||', SepChar="'||SepChar||'", szBuffer="'||szBuffer||'"');	
  Win_API.Clean_Error_Stack;
  iRC  := 0;
  if Modal then 
    hwndOwner := win_api_utility.get_active_window;
  else
    hwndOwner := 0;
  end if;

  if Win_API.API_ENABLED then 
      win_api.Register_function_call(iChooseFile,'d2kwutil_ChooseFile','INT','INT,SHORT,*CHAR,*CHAR,*CHAR,LONG,CHAR,*CHAR');

      if CalledBy = 'Open_File' then
        iBuff1     := 1;
      else
        iBuff1    := 2;
      end if;
      iBuff2    := Flags;
      vcBuff1    := szTitle;
      
      if upper(szInitDir) = '$WINDIR$' then 
        vcBuff2 := win_api_environment.get_windows_directory;
      elsif  upper(szInitDir) = '$TEMP$' then 
        vcBuff2 := win_api_environment.get_temp_directory;
      else 
        vcBuff2 := szInitDir;
      end if;
      
      if substr(vcBuff2,length(vcBuff2),1) <> '\' then 
        vcBuff2 := vcBuff2||'\';
      end if;
      
      if szFileFilter = NULL or szFileFilter = '' then 
        vcBuff3 := 'All files(*.*)|*.*|';
      else
        vcBuff3 := szFileFilter;
      end if;
      vcBuff4 := substr(SepChar,1,1);
      vcBuff5 := RPAD(szBuffer,4096,CHR(0)); 
      
      iRC := d2kwutil_choosefile (win_api.FunctionHandle(iChoosefile),iBuff1,hwndOwner,vcBuff1,vcBuff2,vcBuff3,iBuff2,vcBuff4,vcBuff5);
      Win_API_Debug.DebugLog(99,'ChooseFile','Result: RC='||to_char(iRC)||', szBuffer="'||vcBuff5||'"');
      szBuffer := vcBuff5;
      return iRC;
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
exception
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error(CalledBy,Win_API.NoAPI);
    raise;
  when others then
    Win_API.Add_error(CalledBy, Win_API.UError||WIN_API.Add_External_errors); 
    raise;  
end Choosefile;
```

#### SP-003 - D2KWUTIL.D2KWUTIL_ACTIVEWIN

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Specification-only routine - no implementation body available in the source bundle.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

No implementation body available - this routine is declared in the specification only.

---
**Decision Points**

No implementation body available.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

No implementation body available.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.
FUNCTION d2kwutil_ActiveWin(  hFunc          IN      ORA_FFI.funcHandleType) return PLS_INTEGER;
```

#### SP-004 - D2KWUTIL.D2KWUTIL_CHOOSEFILE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Specification-only routine - no implementation body available in the source bundle.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| dialog_type | PLS_INTEGER | IN |
| hwndOwner | PLS_INTEGER | IN |
| szTitle | VARCHAR2 | IN OUT |
| szInitDir | VARCHAR2 | IN OUT |
| szFileFilter | VARCHAR2 | IN OUT |
| AdvancedFlags | PLS_INTEGER | IN |
| SepChar | VARCHAR2 | IN |
| szBuffer | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| szTitle | VARCHAR2 | IN OUT |
| szInitDir | VARCHAR2 | IN OUT |
| szFileFilter | VARCHAR2 | IN OUT |
| szBuffer | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

No implementation body available - this routine is declared in the specification only.

---
**Decision Points**

No implementation body available.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

No implementation body available.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

 FUNCTION d2kwutil_ChooseFile (   hFunc         IN      ORA_FFI.funcHandleType,
                                  dialog_type   IN      PLS_INTEGER,
                                  hwndOwner     IN      PLS_INTEGER,
                                  szTitle       IN OUT  VARCHAR2,
                                  szInitDir     IN OUT  VARCHAR2,
                                  szFileFilter  IN OUT  VARCHAR2,
                                  AdvancedFlags IN      PLS_INTEGER,
                                  SepChar       IN      VARCHAR2,
                                  szBuffer      IN OUT  VARCHAR2) return PLS_INTEGER;
```

#### SP-005 - D2KWUTIL.D2KWUTIL_DEBUGSTRING

**Invoked From:**

- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Specification-only routine - no implementation body available in the source bundle.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

No implementation body available - this routine is declared in the specification only.

---
**Decision Points**

No implementation body available.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

No implementation body available.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.
   
 PROCEDURE d2kwutil_DebugString (    hFunc       IN      ORA_FFI.funcHandleType,
                                     Text        IN      VARCHAR2);
 -- Pragmas
 PRAGMA INTERFACE(C,d2kwutil_DebugString,      11265);
```

#### SP-006 - D2KWUTIL.D2KWUTIL_GETDOSENV

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level foreign-function interface (FFI) wrapper that retrieves a DOS/operating-system environment variable value. It accepts a function handle and a source environment variable name, then populates an output buffer with the expanded (resolved) value of that variable, returning an integer status code to the caller. It is invoked exclusively by the GET_ENVIRONMENT_STRING stored procedure within D2kwutil.pld.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| SourceStr | VARCHAR2 | IN OUT |
| ExpandStr | VARCHAR2 | IN OUT |
| InBuffLen | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| SourceStr | VARCHAR2 | IN OUT |
| ExpandStr | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that references the underlying OS-level routine responsible for environment variable resolution.
- Step 2 - Accept the source environment variable name (SourceStr) as an IN OUT parameter, making it available for the foreign function call.
- Step 3 - Accept the pre-allocated output buffer (ExpandStr) as an IN OUT parameter, which will be populated with the resolved value of the environment variable.
- Step 4 - Accept the input buffer length (InBuffLen) to define the maximum size of the expanded string the OS routine may write into ExpandStr.
- Step 5 - Delegate execution to the OS-level function referenced by hFunc, passing SourceStr, ExpandStr, and InBuffLen.
- Step 6 - Return a PLS_INTEGER status code to the caller (GET_ENVIRONMENT_STRING) indicating the success or failure of the environment variable retrieval.

---
**Decision Points**

No explicit decision points are determinable from the available source. Only the function specification is present; no conditional branching logic is evidenced in the implementation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be invoked with a valid ORA_FFI function handle (hFunc); the handle must reference the correct OS-level environment-variable retrieval routine before this function is called.
- BR-002 - The caller is responsible for pre-allocating ExpandStr to a length sufficient to hold the resolved environment variable value; InBuffLen must accurately reflect that allocated length to prevent buffer overrun.
- BR-003 - Both SourceStr and ExpandStr are declared IN OUT, meaning the calling routine (GET_ENVIRONMENT_STRING) must pass initialised variables and should inspect their values after the call returns.
- BR-004 - The integer return value must be evaluated by the caller to determine whether the environment variable was successfully resolved; no error handling is performed within this function itself.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_GetDOSEnv (   hFunc          IN      ORA_FFI.funcHandleType,
                                SourceStr      IN OUT  VARCHAR2,
                                ExpandStr      IN OUT  VARCHAR2,
                                InBuffLen      IN      PLS_INTEGER
                                ) RETURN PLS_INTEGER;
```

#### SP-007 - D2KWUTIL.D2KWUTIL_GETREGKEY

**Invoked From:**

- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

D2KWUTIL_GETREGKEY is a foreign-function interface (FFI) wrapper that retrieves a Windows registry key value. It accepts a pre-registered FFI function handle together with the registry root, path, entry name, a buffer for the returned value, the maximum value length, and an expansion flag, then returns an integer status code indicating the outcome of the registry read operation. The procedure is called exclusively by the READ_REGISTRY stored procedure within D2kwutil.pld to abstract low-level Win32 registry access from higher-level Oracle Forms logic.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| RegRoot | PLS_INTEGER | IN |
| RegPath | VARCHAR2 | IN OUT |
| RegEntry | VARCHAR2 | IN OUT |
| RegValue | VARCHAR2 | IN OUT |
| RegValueLength | PLS_INTEGER | IN |
| RegDontExpand | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RegPath | VARCHAR2 | IN OUT |
| RegEntry | VARCHAR2 | IN OUT |
| RegValue | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that identifies the pre-loaded external Windows registry function to be invoked.
- Step 2 - Accept the registry root constant (RegRoot) that specifies the top-level registry hive (e.g., HKEY_LOCAL_MACHINE) under which the target key resides.
- Step 3 - Accept the registry path (RegPath, IN OUT) identifying the sub-key path within the specified hive.
- Step 4 - Accept the registry entry name (RegEntry, IN OUT) identifying the specific named value to be read within the sub-key.
- Step 5 - Accept the output buffer (RegValue, IN OUT) that will receive the registry value string returned by the external call.
- Step 6 - Accept RegValueLength, which defines the maximum allowable length of the value to be read into RegValue.
- Step 7 - Accept RegDontExpand, a flag that controls whether environment-variable references embedded in the registry value are expanded before being returned.
- Step 8 - Invoke the external Win32 registry function via the ORA_FFI mechanism using hFunc and the supplied parameters.
- Step 9 - Return a PLS_INTEGER status code to the caller (READ_REGISTRY) indicating success or failure of the registry read.

---
**Decision Points**

No decision points are determinable from the available source. Only the function specification is present; no PL/SQL body or conditional logic is exposed in the implementation extract.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be called with a valid, pre-registered ORA_FFI function handle (hFunc); the handle is supplied by the caller (READ_REGISTRY) and is not initialised within this function.
- BR-002 - RegValueLength must be set by the caller to a value that does not exceed the allocated size of the RegValue buffer, preventing buffer overrun in the underlying Win32 call.
- BR-003 - When RegDontExpand is set to a non-zero value, environment-variable placeholders within the registry value string are returned unexpanded; when set to zero, the external function is expected to expand them before returning the value.
- BR-004 - RegPath, RegEntry, and RegValue are declared IN OUT, meaning the caller must supply initialised variables; the function may modify their contents as part of the registry retrieval operation.
- BR-005 - The integer return value must be evaluated by the calling routine (READ_REGISTRY) to determine whether the registry read succeeded or failed; this function does not raise exceptions internally based on the available specification.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_GetRegKey (    hFunc         IN      ORA_FFI.funcHandleType,
                                RegRoot        IN      PLS_INTEGER,
                                RegPath        IN OUT  VARCHAR2,
                                RegEntry       IN OUT  VARCHAR2,
                                RegValue       IN OUT  VARCHAR2,
                                RegValueLength IN      PLS_INTEGER,
                                RegDontExpand	 IN      PLS_INTEGER
                                ) return PLS_INTEGER;
```

#### SP-008 - D2KWUTIL.D2KWUTIL_WINDIR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Specification-only routine - no implementation body available in the source bundle.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| WindowsDir | VARCHAR2 | IN OUT |
| InBuffLen | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| WindowsDir | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

No implementation body available - this routine is declared in the specification only.

---
**Decision Points**

No implementation body available.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

No implementation body available.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_WinDir (      hFunc          IN      ORA_FFI.funcHandleType,
                                WindowsDir     IN OUT  VARCHAR2,
                                InBuffLen      IN      PLS_INTEGER
                                ) RETURN PLS_INTEGER;
```

#### SP-009 - D2KWUTIL.GET_ACTIVE_WINDOW

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the Windows handle of the currently active application window using the Win32 API. This handle is used by other routines (such as the file-chooser dialogue) to correctly set the parent window for modal dialogues.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-067](#SP-067--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-068](#SP-068--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-069](#SP-069--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-070](#SP-070--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_ACTIVEWIN ([SP-003](#SP-003--D2KWUTIL.D2KWUTIL_ACTIVEWIN)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-071](#SP-071--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-076](#SP-076--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log the input arguments for diagnostic purposes and clear the error stack.
- Step 2 - Check whether the Win32 API is available; if not, raise a "not available" exception.
- Step 3 - Register the underlying Win32 active-window function with the DLL.
- Step 4 - Call the Win32 function to obtain the active window handle and log the result.
- Step 5 - If the returned handle is zero (no active window found), record an error; optionally raise NO_DATA_FOUND if the caller requested exceptions on failure.
- Step 6 - Return the window handle to the caller.
- Step 7 - On "not available" error, record the error and re-raise; on any other error, record the error with external error details and re-raise.

---
**Decision Points**

DP-001

Condition:
Whether the Win32 API is currently enabled and available.

TRUE:
Register the function and call the Win32 API to get the active window handle.

FALSE:
Raise a "not available" exception.

DP-002

Condition:
Whether the returned window handle is zero (no active window was found).

TRUE:
Record an error message; if the RaiseExceptions flag is TRUE, raise NO_DATA_FOUND.

FALSE:
Return the valid window handle to the caller.

DP-003

Condition:
Whether the caller requested exceptions to be raised on failure (RaiseExceptions = TRUE).

TRUE:
Raise NO_DATA_FOUND when no window handle is returned.

FALSE:
Return zero without raising an exception.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - If the Win32 API layer is not available, the routine always raises an exception - it cannot fall back to an alternative mechanism.
- BR-002 - A zero return value from the Win32 call is treated as a failure; it is not silently ignored.
- BR-003 - The caller controls whether a missing window handle causes a hard exception (RaiseExceptions = TRUE) or merely records an error (RaiseExceptions = FALSE).

---
**Implementation Logic**

```plsql

FUNCTION Get_Active_Window (RaiseExceptions IN  BOOLEAN DEFAULT FALSE) RETURN PLS_INTEGER is
  iRC    PLS_INTEGER := 0;
begin
  Win_API_Debug.DebugLog(99,'Get_Active_Window','Args: RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	  			
  WIN_API.Clean_Error_Stack;
  if WIN_API.API_ENABLED then 
    win_api.Register_function_call(iActiveWin,'d2kwutil_ActiveWin','INT',NULL);
    iRC   := d2kwutil_ActiveWin(win_api.FunctionHandle(iActiveWin));
    Win_API_Debug.DebugLog(99,'Get_Active_Window','Result: RC='||to_char(iRC));        
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0 then 
    Win_API.Add_error('Get_Active_Window','Unable to obtain active window handle');
    if RaiseExceptions then 
      raise NO_DATA_FOUND;
    end if;
  end if;
  return iRC;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Active_Window',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Active_Window',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Active_window;
```

#### SP-010 - D2KWUTIL.SAVE_FILE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FILE_SAVE_DIALOG]
- webutil.pld [StoredProcedure: WEBUTIL.FILE_SELECTION_DIALOG_INT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Displays the Save File As dialogue to the user and returns the full path of the file name the user has chosen to save to. If no file is selected, an error is recorded and, if the caller requested it, an exception is raised.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| SampleName | VARCHAR2 | IN |
| Title | VARCHAR2 | IN |
| StartDirectory | VARCHAR2 | IN |
| FileFilter | VARCHAR2 | IN |
| Modal | BOOLEAN | IN |
| AdvancedFlags | PLS_INTEGER | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-067](#SP-067--ADD_ERROR)) - matched by member name
- D2KWUTIL.CHOOSEFILE ([SP-002](#SP-002--D2KWUTIL.CHOOSEFILE)) - D2KWUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Initialise the return buffer with the supplied sample filename.
- Step 2 - Invoke the underlying file-chooser in Save mode, passing the title, starting directory, file filter, modal flag, and advanced flags.
- Step 3 - If the return code indicates that no file was selected (code = 1), record an error message; if the caller requested exceptions on failure, raise NO_DATA_FOUND.
- Step 4 - If a file was selected, return its full path to the caller.

---
**Decision Points**

DP-001

Condition:
Whether the underlying file-chooser returned code 1, indicating that the user did not select a file.

TRUE:
Record an error; raise NO_DATA_FOUND if RaiseExceptions is TRUE.

FALSE:
Return the selected file path to the caller.

DP-002

Condition:
Whether the caller requested exceptions on failure (RaiseExceptions = TRUE).

TRUE:
Raise NO_DATA_FOUND when no file is selected.

FALSE:
Return without raising an exception (caller must check the error stack).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A return code of 1 from the file-chooser is treated as "no selection made" and is always recorded as an error.
- BR-002 - The caller controls whether a missing file selection causes a hard exception or simply records an error, via the RaiseExceptions parameter.

---
**Implementation Logic**

```plsql
                    

FUNCTION Save_File (  SampleName       IN  VARCHAR2,
                      Title            IN  VARCHAR2     DEFAULT 'Save File As',
                      StartDirectory   IN  VARCHAR2     DEFAULT '$WINDIR$',
                      FileFilter       IN  VARCHAR2     DEFAULT 'All files(*.*)|*.*|',
                      Modal            IN  BOOLEAN      DEFAULT TRUE,
                      AdvancedFlags    IN  PLS_INTEGER  DEFAULT WIN_API.OFN_FLAG_DEFAULT,
                      RaiseExceptions  IN  BOOLEAN      DEFAULT FALSE
                    ) RETURN VARCHAR2 is
  vcReturnedFile  varchar2(4096);
  iLRC    pls_integer := 0;
begin 
  vcReturnedFile  := SampleName;
  iLRC := choosefile('Save_File',Modal,Title,StartDirectory,FileFilter,AdvancedFlags,' ',vcReturnedFile);
  
  if iLRC = 1 then 
    Win_API.Add_error('Save_File','No file was selected');
    if RaiseExceptions then 
      Raise NO_DATA_FOUND;
    end if;
  else
    return vcReturnedFile;
  end if;
end Save_File;
```

#### SP-011 - D2KWUTIL.TRANSLATETYPE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Translates a string data-type name (such as "*CHAR" or "INT") into the corresponding numeric type constant used by the Oracle Foreign Function Interface. This mapping is required before DLL function parameters can be correctly registered for Win32 API calls.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DataType | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Convert the input data-type string to uppercase for case-insensitive comparison.
- Step 2 - Compare the normalised type string against each known type name in sequence (*CHAR, CHAR, *INT, INT, *LONG, LONG, *SHORT/*BYTE, SHORT/BYTE, *DOUBLE, DOUBLE, *VOID).
- Step 3 - Assign the matching Oracle FFI type constant to the result variable.
- Step 4 - Return the numeric type constant.

---
**Decision Points**

DP-001

Condition:
Which data-type string matches the input value (evaluated as a series of ELSIF comparisons against *CHAR, CHAR, *INT, INT, *LONG, LONG, *SHORT, *BYTE, SHORT, BYTE, *DOUBLE, DOUBLE, *VOID).

TRUE:
Assign the corresponding Oracle FFI type constant for the matching type.

FALSE:
Continue to the next type comparison; if no type matches, the result variable remains unassigned (NULL).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Type matching is always performed case-insensitively; callers may pass type names in any case.
- BR-002 - "*SHORT" and "*BYTE" are treated as equivalent pointer types and map to the same FFI constant.
- BR-003 - "SHORT" and "BYTE" are treated as equivalent value types and map to the same FFI constant.
- BR-004 - If an unrecognised type name is passed, the function returns NULL without raising an error.

---
**Implementation Logic**

```plsql
 
FUNCTION TranslateType(DataType in VARCHAR2) return PLS_INTEGER is
   -- Just a simple lookup of the types.
   vcType VARCHAR2(10) := UPPER(DataType);
   iRC    PLS_INTEGER;
begin 
  if vcType = '*CHAR' then 
    iRC := ORA_FFI.C_CHAR_PTR;
  elsif vcType = 'CHAR' then 
    iRC := ORA_FFI.C_CHAR;
  elsif vcType = '*INT' then 
    iRC := ORA_FFI.C_INT_PTR;
  elsif vcType = 'INT' then 
    iRC := ORA_FFI.C_INT;
  elsif vcType = '*LONG' then 
    iRC := ORA_FFI.C_LONG_PTR;
  elsif vcType = 'LONG' then 
    iRC := ORA_FFI.C_LONG;
  elsif vcType = '*SHORT' or vcType = '*BYTE'  then 
    iRC := ORA_FFI.C_SHORT_PTR;
  elsif vcType = 'SHORT' or vcType = 'BYTE' then 
    iRC := ORA_FFI.C_SHORT;
  elsif vcType = '*DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE_PTR;
  elsif vcType = 'DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE;  
  elsif vcType = '*VOID' then 
    iRC := ORA_FFI.C_VOID_PTR;      
  end if;
return iRC;
end TranslateType;
```

#### SP-012 - GENERAL.ASK_CONFIRM

**Invoked From:**

- rr_pre_enq_dlr_fmb.xml [Trigger: FT_CANCEL]
- rr_pre_enq_dlr_fmb.xml [Trigger: FT_DEL]
- rr_pre_enq_dlr_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

N/A

---

**Purpose**

Displays a configurable confirmation alert dialogue (AL_CONFIRM) to the user and returns a numeric indicator of the button pressed. The function is used by cancel, delete, and button-press triggers in the dealer pre-enquiry screen to obtain explicit user confirmation before proceeding with a potentially destructive or irreversible action.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| confirm_msg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the confirmation message text via the confirm_msg input parameter.
- Step 2 - Set the message text of the predefined alert AL_CONFIRM to the value of confirm_msg using SET_ALERT_PROPERTY.
- Step 3 - Display the AL_CONFIRM alert to the user using SHOW_ALERT and capture the button pressed in the local variable p_albtn_pressed.
- Step 4 - Evaluate p_albtn_pressed: if the user pressed ALERT_BUTTON1 (the affirmative/confirm button), return 1 to the calling trigger; otherwise return 0 to indicate the action was not confirmed.

---
**Decision Points**

DP-001

Condition: p_albtn_pressed = ALERT_BUTTON1 (the user pressed the first - affirmative - button on the AL_CONFIRM alert).

TRUE: The function returns 1, signalling to the calling trigger that the user has confirmed the action.

FALSE: The function returns 0, signalling to the calling trigger that the user declined or dismissed the confirmation dialogue.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The confirmation alert displayed must always be AL_CONFIRM; no other alert object is used by this function.
- BR-002 - The alert message text must be supplied by the caller at runtime via confirm_msg; the function does not define or default the message text itself.
- BR-003 - A return value of 1 exclusively represents user confirmation (ALERT_BUTTON1 pressed); any other button response yields a return value of 0, treating all non-affirmative responses as a rejection.
- BR-004 - The function must be invoked wherever a user confirmation gate is required before executing cancel, delete, or button-driven operations on the dealer pre-enquiry screen.

---
**Implementation Logic**

```plsql
FUNCTION ASK_CONFIRM( confirm_msg VARCHAR2)
                                      RETURN  NUMBER IS

    p_alert_name varchar2(10) := 'AL_CONFIRM' ;
    p_albtn_pressed number;
BEGIN
   set_alert_property(p_alert_name,alert_message_text,confirm_msg); 
   p_albtn_pressed := show_alert(p_alert_name);

   IF ( p_albtn_pressed = ALERT_BUTTON1 ) THEN
      return (1);
   ELSE
      return(0);
   END IF;
RETURN NULL; END;
```

#### SP-013 - GENERAL.DISP_TEXT

**Invoked From:**

- rr_pre_enq_dlr_fmb.xml [ProgramUnit: PR_REMOVE_ASCII_CHR]
- DPL.pld [StoredProcedure: GENERAL.RAISE_ERROR]
- rr_pre_enq_dlr_fmb.xml [Trigger: FT_INSERT]
- rr_pre_enq_dlr_fmb.xml [Trigger: ON-ERROR]
- rr_pre_enq_dlr_fmb.xml [Trigger: ON-MESSAGE]
- rr_pre_enq_dlr_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

N/A

---

**Purpose**

Displays a message to the user in a pop-up alert dialogue. If the title supplied is "Error", the message is shown in the error-style alert; otherwise it is shown in the note-style alert. Used throughout the form to surface validation failures, system error notifications, and informational messages.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| text_string | VARCHAR2 | IN |
| title_string | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Default the alert style to the error alert (AL_ERRINFO).
- Step 2 - If the title string is "ERROR" (case-insensitive), use the error-style alert (AL_ERRINFO); otherwise switch to the note-style alert (AL_NOTE).
- Step 3 - Set the alert title and message text on the selected alert.
- Step 4 - Display the alert to the user.

---
**Decision Points**

DP-001

Condition:
Whether the title string equals "ERROR" (case-insensitive).

TRUE:
Use the error-style alert (AL_ERRINFO) to display the message.

FALSE:
Use the note-style alert (AL_NOTE) to display the message.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The choice of alert style (error vs. note) is driven purely by the title string; only the exact word "ERROR" (regardless of case) triggers the error alert.
- BR-002 - No exception is raised after showing the alert; the calling code is responsible for any further error handling.

---
**Implementation Logic**

```plsql
PROCEDURE DISP_TEXT (text_string VARCHAR2,
                     title_string VARCHAR2 ) IS 
   p_alert_name varchar2(10) := 'AL_ERRINFO' ; 
   p_alert_id number;
BEGIN
   if upper(title_string)='ERROR' then
      p_alert_name := 'AL_ERRINFO' ; 
   else
      p_alert_name := 'AL_NOTE' ; 
   end if;
   set_alert_property(p_alert_name,TITLE,title_string);  
   set_alert_property(p_alert_name,alert_message_text,text_string);  
   p_alert_id := show_alert(p_alert_name); 
END;
```

#### SP-014 - GENERAL.RAISE_ERROR

**Invoked From:**

- rr_pre_enq_dlr_fmb.xml [Trigger: ON-ERROR]

---

**Screen:**

N/A

---

**Purpose**

Looks up a standardised error or notification message by its code, displays it to the user in the appropriate alert style, and - for error-type messages - halts further form processing by raising a form trigger failure. This ensures all user-facing messages follow a consistent format and that critical errors stop the current operation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| mesg_code | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-013](#SP-013--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message code identifying the required system message.
- Step 2 - Compose the message text by combining the message code with any retrieved message text (the database lookup is commented out in the current source; the code prefix is always prepended).
- Step 3 - Evaluate the message type: if it is "E" (Error), set the title to "Error", display the message, and raise FORM_TRIGGER_FAILURE to halt processing.
- Step 4 - If the message type is "N" (Note), set the title to "Note" and display the message without halting processing.
- Step 5 - If the message type is "C" (Caution), set the title to "Caution" and display the message without halting processing.

---
**Decision Points**

DP-001

Condition:
Whether the message type is "E" (Error).

TRUE:
Display the message with "Error" title and raise FORM_TRIGGER_FAILURE to stop the current operation.

FALSE:
Check for message type "N" or "C".

DP-002

Condition:
Whether the message type is "N" (Note).

TRUE:
Display the message with "Note" title; processing continues normally.

FALSE:
Check for message type "C".

DP-003

Condition:
Whether the message type is "C" (Caution).

TRUE:
Display the message with "Caution" title; processing continues normally.

FALSE:
No action is taken (unrecognised type).

---
**Database Interactions**

- DB-001 - Read AM_PERMISSIONS - Reads data from AM_PERMISSIONS for lookup or validation.
**Business Rules**

- BR-001 - Only messages of type "E" (Error) halt further form processing; type "N" and "C" messages are informational only.
- BR-002 - The message code is always prepended to the message text, ensuring the code is visible to the user regardless of message type.
- BR-003 - The message type determines both the alert title and whether processing is allowed to continue.

---
**Implementation Logic**

```plsql
PROCEDURE RAISE_ERROR ( mesg_code IN VARCHAR2 )IS
  mesg_type  varchar2(7); 
  mesg_text  varchar2(200) ;
  mesg_title varchar2(7);
  BEGIN
     -- murali 17.05.04 GENERAL.get_message(mesg_code,mesg_text,mesg_type );
     mesg_text:=mesg_code||' : '||mesg_text;		
     IF ( mesg_type = 'E' ) THEN
        mesg_title := 'Error' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
        raise FORM_TRIGGER_FAILURE;
     ELSIF ( mesg_type = 'N' ) THEN
        mesg_title := 'Note' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     ELSIF ( mesg_type = 'C' ) THEN
        mesg_title := 'Caution' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     END IF;
  END;     

/* PROCEDURE check_rights( 
pi_form_name in varchar2,
pi_user_id in number) IS
lv_x varchar2(1);
BEGIN
	
	begin
	SELECT substr(access_string, pi_user_id,1) 
	INTO   lv_x
	FROM   	am_permissions
	WHERE  form_name = pi_form_name
	AND SUBSTR(access_string,pi_user_id,1)='Y';
	exception 
		when no_data_found then
		  general.disp_text('You do not have the Permission to access this.','Error rr');
		  raise form_trigger_failure; 
		when too_many_rows then
		  general.disp_text('Many rows in USER_PERMISSIONS','Error ss');
		  raise form_trigger_failure;
		when others then
		       general.disp_text(sqlerrm,'Error mm');
		       raise form_trigger_failure;
	end;

	open_form(pi_form_name,activate,session);
END;
*/
```

#### SP-015 - WEBUTIL.BLOCKING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.HOST]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Executes a host operating-system command in blocking mode, meaning the form waits for the command to finish before continuing. It is a convenience wrapper that passes the blocking execution mode to the underlying Execute function.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.EXECUTE ([SP-024](#SP-024--WEBUTIL.EXECUTE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the host command string to be executed.
- Step 2 - Delegate to the Execute function with the blocking-mode flag set, and return the resulting process identifier.

---
**Decision Points**

No conditional decision points in this routine.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine always uses blocking mode; the form is not released to the user until the host command completes.

---
**Implementation Logic**

```plsql
  
  FUNCTION  Blocking(cmd in VARCHAR2) return PROCESS_ID is
  begin
    return Execute(cmd,BLOCKING_MODE);
  end Blocking;
```

#### SP-016 - WEBUTIL.CHECKLIBS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.CHECKLIBS ensures that all native system libraries required by a given WebUtil package are present and up to date on the client machine. For each library entry defined in the property bundle for the package, it compares the installed version recorded in the client settings against the expected version. Where a library is absent, outdated, or a forced re-download flag is active, it downloads the library from the configured URL and records the new version in the client settings. The procedure is invoked by WEBUTIL.REGISTERBEAN as part of the package registration sequence.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.DOWNLOADFROMURLINT ([SP-021](#SP-021--WEBUTIL.DOWNLOADFROMURLINT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTSETTING ([SP-031](#SP-031--WEBUTIL.GETCLIENTSETTING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-051](#SP-051--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-055](#SP-055--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READTRANSFROMMSGBUNDLE ([SP-056](#SP-056--WEBUTIL.READTRANSFROMMSGBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETCLIENTSETTING ([SP-060](#SP-060--WEBUTIL.SETCLIENTSETTING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the package identifier (packageID) as input to scope the library lookup.
- Step 2 - Enter a loop that iterates through sequentially numbered library entries (starting at index 1) in the property bundle, constructing the lookup key as 'install.syslib.<OSFamily>.<OSArch>.<packageID>.<index>' via WEBUTIL.READFROMPROPERTYBUNDLE.
- Step 3 - If no entry is found for the OS-family/architecture-specific key, retry the lookup using the OS-family-only key ('install.syslib.<OSFamily>.<packageID>.<index>').
- Step 4 - If both lookups return NULL, exit the loop; all library entries for the package have been processed.
- Step 5 - Parse the pipe-delimited library specification string to extract: library file name (field 1), expected file size (field 2), expected version string (field 3), and a progress-display flag (field 4).
- Step 6 - Retrieve the currently installed version of the library from the client settings using WEBUTIL.GETCLIENTSETTING with the key 'syslib.<libName>'.
- Step 7 - Evaluate whether a download is required: the installed version is NULL, the installed version does not match the expected version, or the global REDOWNLOAD_SYSLIB flag is TRUE.
- Step 8 - If a download is required, resolve the download base URL by checking three property bundle keys in priority order: OS-family + architecture specific, OS-family specific, then generic ('install.syslib.location'), using WEBUTIL.READFROMPROPERTYBUNDLE at each level.
- Step 9 - Invoke WEBUTIL.DOWNLOADFROMURLINT with the resolved URL appended with the library file name, the file size, the progress flag, and localised progress dialog titles retrieved via WEBUTIL.READTRANSFROMMSGBUNDLE ('INST_PGRS_TITLE' and 'INST_PGRS_SUBTITLE').
- Step 10 - If the download succeeds, record the new version against the library key in the client settings via WEBUTIL.SETCLIENTSETTING.
- Step 11 - If the download fails, log a failure message using WEBUTIL.LOG with the library name and a hard-error flag of TRUE.
- Step 12 - Increment the library index counter and return to Step 2 to process the next library entry.

---
**Decision Points**

DP-001

Condition: The OS-family + architecture-specific property bundle key ('install.syslib.<OSFamily>.<OSArch>.<packageID>.<index>') returns a non-NULL value.

TRUE: Use the returned value as the library specification and proceed to parsing.

FALSE: Fall back to the OS-family-only key ('install.syslib.<OSFamily>.<packageID>.<index>') via a second WEBUTIL.READFROMPROPERTYBUNDLE call.

---

DP-002

Condition: The OS-family-only fallback lookup also returns NULL.

TRUE: Exit the loop; no further library entries exist for this package.

FALSE: Use the returned value as the library specification and proceed to parsing.

---

DP-003

Condition: The installed version retrieved from client settings is NULL, differs from the expected version, or the REDOWNLOAD_SYSLIB flag is TRUE.

TRUE: Resolve the download URL and proceed to download the library.

FALSE: The library is already at the correct version; skip download and advance to the next library entry.

---

DP-004

Condition: The OS-family + architecture-specific download location key ('install.syslib.location.<OSFamily>.<OSArch>') returns a non-NULL URL.

TRUE: Use this URL as the download base.

FALSE: Attempt the OS-family-only location key ('install.syslib.location.<OSFamily>').

---

DP-005

Condition: The OS-family-only download location key returns a non-NULL URL.

TRUE: Use this URL as the download base.

FALSE: Use the generic location key ('install.syslib.location') as the final fallback.

---

DP-006

Condition: WEBUTIL.DOWNLOADFROMURLINT returns TRUE (download completed successfully).

TRUE: Record the expected library version in client settings via WEBUTIL.SETCLIENTSETTING.

FALSE: Log a download failure message for the library via WEBUTIL.LOG with the hard-error flag set to TRUE.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Library entries for a package must be defined in the property bundle using sequentially numbered keys starting at index 1; the loop terminates at the first missing index, so gaps in numbering will prevent subsequent entries from being processed.
- BR-002 - Library specifications must be pipe-delimited strings containing at minimum: library file name (field 1), expected file size in bytes (field 2), expected version string (field 3), and a Boolean progress-display indicator (field 4).
- BR-003 - A library is considered current only when the version string stored in client settings exactly matches the version string defined in the property bundle; a partial or case-variant match is treated as a mismatch requiring re-download.
- BR-004 - When the global REDOWNLOAD_SYSLIB flag is TRUE, all libraries are re-downloaded regardless of the installed version, ensuring a forced refresh capability.
- BR-005 - The download base URL is resolved with a three-level fallback (OS-family + architecture, OS-family only, generic); if all three levels return NULL the download URL will be NULL and the behaviour of WEBUTIL.DOWNLOADFROMURLINT is governed by that dependency.
- BR-006 - A successful download must be confirmed by WEBUTIL.DOWNLOADFROMURLINT returning TRUE before the client setting is updated; a failed download does not update the installed version record, allowing a subsequent invocation to retry.
- BR-007 - Download failure is treated as a hard error: WEBUTIL.LOG is called with the error flag set to TRUE, ensuring the failure is surfaced to the operator rather than silently ignored.
- BR-008 - Progress dialog labels displayed during download must be sourced from the message bundle via WEBUTIL.READTRANSFROMMSGBUNDLE using the keys 'INST_PGRS_TITLE' and 'INST_PGRS_SUBTITLE', ensuring localisation compliance.

---
**Implementation Logic**

```plsql
  
  PROCEDURE CheckLibs(packageID in VARCHAR2 ) is
    lib          PLS_INTEGER := 1;
    libSpec      VARCHAR2(200 char);
    libName      VARCHAR2(100 char);
    libSize      PLS_INTEGER;
    libVer       VARCHAR2(20 char);
    installedVer VARCHAR2(20 char);
    libProg      BOOLEAN := false;
    downloadURL  VARCHAR2(1000);
  BEGIN
    -- Read through the property bundle for 
    -- any libraries for this package
    LOOP
      libSpec := readFromPropertyBundle('install.syslib.'||to_char(m_clientOSFamily)||'.'||
             to_char(m_clientOSArch)||'.'||packageID||'.'||to_char(lib));
      if libSpec is null then
        libSpec := readFromPropertyBundle('install.syslib.'||to_char(m_clientOSFamily)||'.'||
             packageID||'.'||to_char(lib));
      end if;
      if libSpec is null then 
        exit;
      end if;
      lib := lib + 1;
      libName := Delimstr.getString(libSpec,1,true,'|');
      libSize := Delimstr.getNumber(libSpec,2,true,'|');
      libVer  := Delimstr.getString(libSpec,3,true,'|');
      libProg := (upper(Delimstr.getString(libSpec,4,true,'|'))='TRUE');

      -- OK we now have the library information
      -- let's check if it's installed
      installedVer := GetClientSetting('syslib.'||libname);
      if installedVer is null or installedVer <> libVer or REDOWNLOAD_SYSLIB then 
        -- need to download
        downloadURL := readFromPropertyBundle('install.syslib.location' || '.' || to_char(m_clientOSFamily) ||
                             '.' || to_char(m_clientOSArch));
        if downloadURL is null then
          downloadURL := readFromPropertyBundle('install.syslib.location' || '.' || to_char(m_clientOSFamily));
        end if;
        if downloadURL is null then
          downloadURL := readFromPropertyBundle('install.syslib.location');
        end if;
        if DownLoadFromURLInt(downloadURL||'/'||libName, 
                              libName,
                              1, -- syslib install download, special location
                              libSize,
                              libProg,
                              ReadTransFromMsgBundle('INST_PGRS_TITLE'),
                              ReadTransFromMsgBundle('INST_PGRS_SUBTITLE'),     
                              libName) then 
          SetClientSetting('syslib.'||libname,libVer);
        else
          log('Download of system library '||libName||' failed',true);
        end if;                          
      end if;
    END LOOP;
  END CheckLibs;
```

#### SP-017 - WEBUTIL.CLEARCALLBACKTRIGGER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Removes a previously registered callback trigger entry from the internal callback registry using its key. This cleanup step is called when a host process is released to ensure that stale callback registrations do not accumulate in memory.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| callbackKey | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Check whether an entry with the given callback key exists in the internal callbacks collection.
- Step 2 - If the entry exists, delete it from the collection.

---
**Decision Points**

DP-001

Condition:
Whether the callback key exists in the internal callbacks collection.

TRUE:
Delete the entry from the collection.

FALSE:
Do nothing; the routine returns silently.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The routine is idempotent: calling it with a key that does not exist has no effect and does not raise an error.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ClearCallbackTrigger(callbackKey in PLS_INTEGER) is
  begin
    if m_callbacks.exists(callbackKey) then 
      m_callbacks.delete(callbackKey);  
    end if;
  end ClearCallbackTrigger;
```

#### SP-018 - WEBUTIL.CLOSEBLOB

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open BLOB handle identified by its checksum value. The procedure delegates the close operation to the WebUtil_DB package, releasing any server-side resources associated with the BLOB session.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| checksum | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the checksum (PLS_INTEGER) that uniquely identifies the open BLOB handle to be closed.
- Step 2 - Delegate the close operation to WebUtil_DB.CloseBlob, passing the checksum as the identifying key.
- Step 3 - Return the BOOLEAN result produced by WebUtil_DB.CloseBlob to the caller, indicating whether the BLOB was successfully closed.

---
**Decision Points**

No decision points are present in this procedure. All conditional logic is encapsulated within WebUtil_DB.CloseBlob; this function acts solely as a pass-through delegate.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The checksum parameter must correspond to a previously opened BLOB handle; the validity of the checksum is enforced by the delegated call to WebUtil_DB.CloseBlob.
- BR-002 - The outcome of the close operation is determined entirely by WebUtil_DB.CloseBlob; this function must faithfully return that BOOLEAN result to its caller without modification.

---
**Implementation Logic**

```plsql

  FUNCTION  CloseBlob(checksum in PLS_INTEGER) return BOOLEAN is
  BEGIN
    return WebUtil_DB.CloseBlob(checksum);
  END CloseBlob;
```

#### SP-019 - WEBUTIL.CLOSEFILE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open server-side file reader object by invoking the corresponding Java method on the AppServerFileReader class. This procedure is called by WEBUTIL.SETDATA to release the file handle once data transfer operations are complete, ensuring that server-side file resources are properly freed.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java object reference (obj) representing an active AppServerFileReader instance on the application server.
- Step 2 - Clear the argument list by setting args to NULL, as the closeFile Java method requires no arguments.
- Step 3 - Invoke the Java instance method closeFile on the AppServerFileReader class via JNI.CALL_BOOLEAN_METHOD, passing the object reference and a NULL argument list.
- Step 4 - Return the Boolean result produced by the Java method call, indicating whether the file was successfully closed.

---
**Decision Points**

DP-001

Condition: The JNI.CALL_BOOLEAN_METHOD call to oracle/forms/webutil/fileTransfer/AppServerFileReader.closeFile returns TRUE or FALSE.

TRUE: The underlying Java closeFile method executed successfully and the file handle was released; the function returns TRUE to the caller (WEBUTIL.SETDATA).

FALSE: The underlying Java closeFile method was unable to close the file; the function returns FALSE to the caller, signalling that the file resource may not have been released.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must always clear the argument list (args := NULL) before invoking the Java method, because the AppServerFileReader.closeFile method accepts no parameters.
- BR-002 - The Java method is invoked with the static flag set to FALSE, confirming that closeFile is an instance method and must be called against a valid, non-null AppServerFileReader object reference.
- BR-003 - The Boolean return value from the Java layer must be propagated unchanged to the caller; no additional transformation or defaulting of the result is permitted.
- BR-004 - This function operates exclusively on the application server file layer (oracle/forms/webutil/fileTransfer/AppServerFileReader) and performs no direct database interactions.

---
**Implementation Logic**

```plsql
  FUNCTION closeFile(
    obj   ORA_JAVA.JOBJECT) RETURN BOOLEAN IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_BOOLEAN_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'closeFile', '()Z', args); 
  END;
```

#### SP-020 - WEBUTIL.DOWNLOADFROMURL

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.URL_TO_CLIENT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Downloads a file from a given URL to a specified location on the client desktop. This is a simplified public-facing wrapper that delegates to the internal download implementation with default settings (no progress indicator, no special destination).

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| fileSize | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.DOWNLOADFROMURLINT ([SP-021](#SP-021--WEBUTIL.DOWNLOADFROMURLINT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the source URL, client destination path, and optional file size.
- Step 2 - Delegate to the internal download function with the standard destination type (0), no progress display, and no progress title or message.
- Step 3 - Return the boolean result (TRUE for success, FALSE for failure) from the internal implementation.

---
**Decision Points**

No conditional decision points in this routine.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine always disables the progress display; callers requiring a progress indicator must use the internal function directly.
- BR-002 - The success or failure of the download is communicated via the returned boolean value.

---
**Implementation Logic**

```plsql
  
  FUNCTION DownLoadFromURL(sourceURL         in VARCHAR2, 
                           clientDestination in VARCHAR2, 
                           fileSize          in PLS_INTEGER default 0) return BOOLEAN is
  BEGIN
    return DownLoadFromURLInt(sourceURL,
                              ClientDestination,
                              0,
                              fileSize,
                              false,
                              null,
                              null,
                              null);
  END DownLoadFromURL;
```

#### SP-021 - WEBUTIL.DOWNLOADFROMURLINT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.DOWNLOADFROMURL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Internal implementation that transfers a file from a server URL to the client machine. It validates that both a source URL and a client destination have been provided, constructs a pipe-delimited command string with all download parameters (destination type, file size, progress options, and progress label strings), submits it to the WebUtil Core bean via WebUtil_Core.setProperty, retrieves the result via WebUtil_Core.getProperty, and returns TRUE on success or FALSE on failure.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| specialDestination | PLS_INTEGER | IN |
| fileSize | PLS_INTEGER | IN |
| withProgress | BOOLEAN | IN |
| progressTitle | VARCHAR2 | IN |
| progressSubTitle | VARCHAR2 | IN |
| progressMessage | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Validate that a source URL has been provided; if null, raise URL_NULL.
- Step 2 - Validate that a client destination path has been provided; if null, raise CLIENT_FILE_NULL.
- Step 3 - Begin building the pipe-delimited command string: if specialDestination is null, negative, or greater than 2, append '0'; otherwise append the supplied specialDestination value, followed by the pipe separator.
- Step 4 - Append the file size: if fileSize is null, append '0'; otherwise append the supplied fileSize value, followed by the pipe separator.
- Step 5 - Append the progress flag: if withProgress is null or FALSE, append 'N'; if TRUE, append 'Y', followed by the pipe separator.
- Step 6 - Append the sourceURL, clientDestination, progressTitle (defaulting to a single space if null), progressSubTitle (defaulting to a single space if null), and progressMessage (defaulting to a single space if null), each separated by the pipe character.
- Step 7 - Submit the completed command string to the WebUtil Core bean by calling WebUtil_Core.setProperty with the WUC_PACKAGE identifier and the 'WUC_URL_DOWNLOAD' property key.
- Step 8 - Retrieve the bean's response by calling WebUtil_Core.getProperty with the same package and property key.
- Step 9 - Return TRUE if the retrieved result equals 'TRUE', FALSE otherwise.
- Step 10 - Handle exceptions: CLIENT_FILE_NULL calls WebUtil_Core.Error with code 130 and returns FALSE; URL_NULL calls WebUtil_Core.Error with code 25 and returns FALSE; BEAN_NOT_REGISTERED calls WebUtil_Core.ErrorAlert with a descriptive message and raises FORM_TRIGGER_FAILURE; PROPERTY_ERROR raises FORM_TRIGGER_FAILURE.

---
**Decision Points**

DP-001

Condition:
Whether the source URL is null.

TRUE:
Raise the URL_NULL exception; WebUtil_Core.Error records error code 25 and the function returns FALSE.

FALSE:
Continue to validate the client destination.

DP-002

Condition:
Whether the client destination path is null.

TRUE:
Raise the CLIENT_FILE_NULL exception; WebUtil_Core.Error records error code 130 and the function returns FALSE.

FALSE:
Proceed to build the download command string.

DP-003

Condition:
Whether specialDestination is null, less than 0, or greater than 2.

TRUE:
Append '0' as the destination code in the command string.

FALSE:
Append the supplied specialDestination value as the destination code.

DP-004

Condition:
Whether fileSize is null.

TRUE:
Append '0' as the file size in the command string.

FALSE:
Append the supplied fileSize value.

DP-005

Condition:
Whether withProgress is null or evaluates to FALSE.

TRUE:
Append 'N' to disable the progress indicator.

FALSE:
Append 'Y' to enable the progress indicator.

DP-006

Condition:
Whether the WebUtil Core bean is registered on the client (BEAN_NOT_REGISTERED exception).

TRUE (bean not registered):
Call WebUtil_Core.ErrorAlert to display a descriptive alert identifying the missing bean class, then raise FORM_TRIGGER_FAILURE to abort processing.

FALSE (bean is registered):
Processing completes normally and the boolean result is returned.

DP-007

Condition:
Whether a PROPERTY_ERROR is raised during the setProperty or getProperty call.

TRUE:
Raise FORM_TRIGGER_FAILURE to abort processing.

FALSE:
Return the boolean result derived from the retrieved property value.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Both the source URL and client destination are mandatory; passing either as null is treated as a named exception error and the function returns FALSE without attempting the download.
- BR-002 - The specialDestination code must be in the range 0-2 inclusive; any null value or out-of-range integer is silently replaced with 0 in the command string.
- BR-003 - Null progress label strings (progressTitle, progressSubTitle, progressMessage) are substituted with a single space character to ensure the pipe-delimited command string remains well-formed.
- BR-004 - If the WebUtil Core bean is not registered on the client, the form displays an error alert identifying the missing bean class and aborts further processing by raising FORM_TRIGGER_FAILURE.
- BR-005 - A PROPERTY_ERROR during bean communication causes immediate abort via FORM_TRIGGER_FAILURE; no partial result is returned.

---
**Implementation Logic**

```plsql
  
  FUNCTION DownLoadFromURLInt(sourceURL          in VARCHAR2, 
                              clientDestination  in VARCHAR2, 
                              specialDestination in PLS_INTEGER default 0,                             
                              fileSize           in PLS_INTEGER default 0, 
                              withProgress       in BOOLEAN default false,
                              progressTitle      in VARCHAR2 default null,
                              progressSubTitle   in VARCHAR2 default null,
                              progressMessage    in VARCHAR2 default null) return BOOLEAN is
    result       VARCHAR2(6) := 'FALSE';
    submitString VARCHAR2(4000 char);
    sep          VARCHAR2(1) := '|';
  BEGIN
    if sourceURL is null then
      raise URL_NULL;
    end if;
    if clientDestination is null then
      raise CLIENT_FILE_NULL;
    end if;

    if specialDestination is null or specialDestination < 0 or specialDestination > 2 then 
      submitString := '0'||sep;
    else
      submitString := to_char(specialDestination)||sep;
    end if;
    if fileSize is null then 
      submitString := submitString||'0'||sep;
    else
      submitString := submitString||to_char(fileSize)||sep;
    end if;
    if withProgress is null or not withProgress then 
      submitString := submitString||'N'||sep;
    else
      submitString := submitString||'Y'||sep;
    end if;    

    submitString := submitString||sourceURL
                    ||sep||clientDestination
                    ||sep||nvl(progressTitle,' ')
                    ||sep||nvl(progressSubTitle,' ')
                    ||sep||nvl(progressMessage,' ');                         
  WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_URL_DOWNLOAD',submitString,true);
  result := WebUtil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_URL_DOWNLOAD');
  return (result='TRUE');
  EXCEPTION  
    when CLIENT_FILE_NULL then
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE, 130, 'WEBUTIL_CORE.DownloadFromURLInt');
      return false;
    when URL_NULL then
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE,25, 'WEBUTIL_CORE.DownloadFromURLInt');
      return false;

    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                              ||' bean not found. WEBUTIL_CORE.DownloadFromURLInt will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;
  END DownLoadFromURLInt;
```

#### SP-022 - WEBUTIL.ERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Records a formatted error message for a WebUtil component by composing a standardised error string from the error code, the calling program unit name, and up to three optional argument values, then storing it as a property on the component. This centralised error-recording mechanism ensures all WebUtil errors are captured in a consistent format.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |
| code | PLS_INTEGER | IN |
| pu_name | VARCHAR2 | IN |
| arg1 | VARCHAR2 | IN |
| arg2 | VARCHAR2 | IN |
| arg3 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Compose the base error string by combining the literal "ERROR", the zero-padded three-digit error code, a pipe separator, and the program unit name.
- Step 2 - If the first optional argument is provided, append a pipe separator and the argument value.
- Step 3 - If the second optional argument is provided, append a pipe separator and the argument value.
- Step 4 - If the third optional argument is provided, append a pipe separator and the argument value.
- Step 5 - Store the completed error string as a property on the specified WebUtil package component.

---
**Decision Points**

DP-001

Condition:
Whether optional argument 1 is non-null.

TRUE:
Append it to the error string.

FALSE:
Skip it.

DP-002

Condition:
Whether optional argument 2 is non-null.

TRUE:
Append it to the error string.

FALSE:
Skip it.

DP-003

Condition:
Whether optional argument 3 is non-null.

TRUE:
Append it to the error string.

FALSE:
Skip it.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Error codes are always formatted as three digits padded with leading zeros to ensure consistent display.
- BR-002 - Up to three contextual arguments can be attached to the error message to provide additional detail to support staff.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Error(packageID in PLS_INTEGER,
                  code      in PLS_INTEGER,
                  pu_name   in VARCHAR2,
                  arg1      in VARCHAR2 :=null,
                  arg2      in VARCHAR2 := null,
                  arg3      in VARCHAR2 := null
                 ) is
    errText varchar2(1024);
  begin 
    errText := 'ERROR'||lpad(to_char(code),3,'0') || '|' || pu_name;
    if arg1 is not null then
      errText := errText || '|' || arg1;
    end if;
    if arg2 is not null then
      errText := errText || '|' || arg2;
    end if;
    if arg3 is not null then
      errText := errText || '|' || arg3;
    end if;
    Webutil_Core.setProperty(packageID, 'WUC_ERROR_MSG', errText);
  end Error;
```

#### SP-023 - WEBUTIL.ERRORALERT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]
- webutil.pld [StoredProcedure: WEBUTIL.LOG]
- webutil.pld [StoredProcedure: WEBUTIL.POPULATEPROPERTYBUNDLE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Displays a WebUtil error message to the user. If a pre-configured error alert handle is available, the message is shown in that alert; otherwise it falls back to displaying the message via the standard form message bar. This is typically used to report that a required Java bean is missing or not registered.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| errText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-045](#SP-045--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Check whether the error alert handle (m_errorAlert) is not null.
- Step 2 - If the handle is valid, set the alert message text and display the alert to the user.
- Step 3 - If the handle is null, display the error text via the standard form message mechanism, prefixed with "WebUtil Error".

---
**Decision Points**

DP-001

Condition:
Whether the WebUtil error alert handle is non-null (i.e., the alert is registered and available).

TRUE:
Set the alert message and show the alert dialogue.

FALSE:
Display the error as a standard form message.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The routine gracefully degrades to a standard message display when the dedicated error alert is not configured, ensuring the error is always visible to the user.
- BR-002 - The alert title is pre-set on the alert definition and is not overridden by this routine.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ErrorAlert(errText in VARCHAR2) is
    -- currently used for throwing a BEAN_NOT_REGISTERED or bean not found error.
    ignore integer;
  begin
    if not ID_NULL(m_errorAlert) then 
      --SET_ALERT_PROPERTY(m_errorAlert,TITLE,'WebUtil Error'); -- title already set in alert property
      SET_ALERT_PROPERTY(m_errorAlert,ALERT_MESSAGE_TEXT,errText);
      ignore := SHOW_ALERT(m_errorAlert);
    else
      message('WebUtil Error'||': '||errText);
    end if;
  end ErrorAlert;
```

#### SP-024 - WEBUTIL.EXECUTE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.BLOCKING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Submits a host command to the operating system for execution via the WebUtil Java bean, setting the execution mode (blocking or non-blocking) before launching. Returns a process identifier that can be used by the caller to monitor the process or retrieve its exit code.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |
| exemode | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - If the command string is non-null, set the execution mode on the WebUtil host bean.
- Step 2 - Send the command to the WebUtil host bean for execution and retrieve the resulting numeric process handle.
- Step 3 - Store the process handle in a PROCESS_ID structure and return it.
- Step 4 - If the WebUtil host bean is not registered, display an alert and return without a valid handle.

---
**Decision Points**

DP-001

Condition:
Whether the command string is non-null.

TRUE:
Set the execution mode and submit the command to the WebUtil bean.

FALSE:
Return an empty (null) process identifier without executing anything.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A null command is silently ignored and results in an empty process identifier being returned.
- BR-002 - If the WebUtil bean is not available on the client, an alert is displayed but no exception propagates to the caller.

---
**Implementation Logic**

```plsql
  FUNCTION Execute (cmd in VARCHAR2, exemode in PLS_INTEGER) return PROCESS_ID is
    procId PROCESS_ID;
  begin 
    if cmd is not null then 
      WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTION_MODE',exemode);            
      WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTE',cmd);      
      procId.handle := to_number(WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTE'));
    end if;
    return procId;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.Execute will not work');
  end Execute;
```

#### SP-025 - WEBUTIL.FCLOSE

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open client-side text file handle by instructing the WebUtil Core bean to flush and close the file, then clears the handle to prevent further use. If the bean is not registered, the routine calls WEBUTIL.ERRORALERT to display a descriptive alert - identifying the implementation class via WEBUTIL.GETIMPLCLASS - before raising a tool error. This ensures client-side file resources are properly released after reading or writing is complete.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-023](#SP-023--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETIMPLCLASS ([SP-032](#SP-032--WEBUTIL.GETIMPLCLASS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate whether the file handle is non-null, indicating the file is currently open.
- Step 2 - If the handle is valid, send a close command to the WebUtil Core bean (WUF_TEXTIO_CLOSE) using the current file handle value.
- Step 3 - Set the file handle to null to mark the file as closed and prevent accidental reuse.
- Step 4 - If a BEAN_NOT_REGISTERED exception is raised, call WEBUTIL.GETIMPLCLASS to retrieve the implementation class name for the WUF_PACKAGE, pass it to WEBUTIL.ERRORALERT to display a user-facing message stating the bean was not found and CLIENT_TEXT_IO.fclose will not work, then raise TOOL_ERROR.
- Step 5 - If a PROPERTY_ERROR exception is raised, raise TOOL_ERROR immediately without displaying an alert.

---
**Decision Points**

DP-001

Condition:
Whether the file handle (file.handle) is non-null at the time the procedure is called.

TRUE:
Send the WUF_TEXTIO_CLOSE command to the WebUtil Core bean and set the handle to null.

FALSE:
Skip all close processing; the routine exits silently without error.

---

DP-002

Condition:
Whether a BEAN_NOT_REGISTERED exception is raised during the close operation.

TRUE:
Resolve the implementation class name via WEBUTIL.GETIMPLCLASS, display an alert via WEBUTIL.ERRORALERT indicating the bean was not found, then raise TOOL_ERROR.

FALSE:
Continue normal processing or handle any PROPERTY_ERROR exception separately.

---

DP-003

Condition:
Whether a PROPERTY_ERROR exception is raised during the close operation.

TRUE:
Raise TOOL_ERROR immediately.

FALSE:
Continue normal processing.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - After this routine completes successfully, the file handle is always set to null, preventing accidental reuse of a closed file reference.
- BR-002 - Calling this routine when the file handle is already null is a no-op; no error is raised and no bean interaction occurs.
- BR-003 - If the WebUtil bean is not registered, WEBUTIL.GETIMPLCLASS must be used to identify the missing implementation class, and WEBUTIL.ERRORALERT must be used to surface a meaningful error message to the user before the routine terminates with TOOL_ERROR.
- BR-004 - A PROPERTY_ERROR during the close command results in an immediate TOOL_ERROR with no user-facing alert.

---
**Implementation Logic**

```plsql
 
  PROCEDURE fclose (file IN OUT file_type) is 
  BEGIN 
    if (file.handle IS NOT NULL) then 
      WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CLOSE',file.handle);        
      file.handle := NULL;
    end if;
 
 EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.fclose will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;
  END fclose;
```

#### SP-026 - WEBUTIL.FILE_SAVE_DIALOG

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Presents a Save File dialogue to the user and returns the selected file path. It is a convenience wrapper around the internal file-selection dialogue, configured specifically for save operations with single-file selection enforced.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| directory_name | Varchar2 | IN |
| file_name | Varchar2 | IN |
| file_filter | Varchar2 | IN |
| title | Varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- D2KWUTIL.SAVE_FILE ([SP-010](#SP-010--D2KWUTIL.SAVE_FILE)) - D2KWUTIL.pck (or .pld)
- WEBUTIL.FILE_SELECTION_DIALOG_INT ([SP-027](#SP-027--WEBUTIL.FILE_SELECTION_DIALOG_INT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the initial directory, default filename, file filter, and dialogue title.
- Step 2 - Delegate to the internal file-selection function with the Save File mode flag, single-file selection enabled, and multi-select disabled.
- Step 3 - Return the file path chosen by the user.

---
**Decision Points**

No conditional decision points in this routine.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine always operates in Save File mode; it cannot be used for Open File or directory selection.
- BR-002 - Multi-file selection is always disabled; only a single save destination can be chosen.

---
**Implementation Logic**

```plsql
                                        
  FUNCTION FILE_SAVE_DIALOG(            directory_name Varchar2 := NULL,
                                        file_name      Varchar2 := NULL,
                                        file_filter    Varchar2 := NULL,
                                        title          Varchar2 := NULL) return Varchar2 is
  BEGIN
    RETURN FILE_SELECTION_DIALOG_INT(   directory_name,
                                        file_name,
                                        file_filter,
                                        title,
                                        SAVE_FILE,
                                        TRUE,
                                        FALSE); 
  END FILE_SAVE_DIALOG;
```

#### SP-027 - WEBUTIL.FILE_SELECTION_DIALOG_INT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FILE_SAVE_DIALOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Internal implementation of the file selection dialogue that configures and invokes the WebUtil file-chooser bean. It handles all three dialogue modes (Save File, Open Directory, Open File), normalises any path separator inconsistencies in the returned path, and raises appropriate exceptions if the bean is not available.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| directory_name | Varchar2 | IN |
| file_name | Varchar2 | IN |
| file_filter | Varchar2 | IN |
| title | Varchar2 | IN |
| dialog_type | Number | IN |
| select_file | Boolean | IN |
| multiselect | Boolean | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- D2KWUTIL.SAVE_FILE ([SP-010](#SP-010--D2KWUTIL.SAVE_FILE)) - D2KWUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Set the initial directory, default filename, file filter, dialogue title, and multi-select option on the WebUtil file bean.
- Step 2 - Determine the dialogue type: if Save File mode, retrieve the save-file result; if not selecting a file (directory mode), retrieve the open-directory result; otherwise retrieve the open-file result.
- Step 3 - Check whether the returned path begins with a double backslash (UNC path); if so, prepend an extra backslash to preserve the UNC format after the subsequent replace.
- Step 4 - Replace all double backslashes in the result with single backslashes to normalise the path.
- Step 5 - Return the normalised path.
- Step 6 - If the WebUtil bean is not registered, display an alert and raise FORM_TRIGGER_FAILURE; if a property error occurs, raise FORM_TRIGGER_FAILURE.

---
**Decision Points**

DP-001

Condition:
Whether the dialogue type is Save File mode.

TRUE:
Retrieve the save-file selection result from the bean.

FALSE:
Check whether directory (non-file) selection mode is requested.

DP-002

Condition:
Whether the select_file flag is FALSE (directory selection mode).

TRUE:
Retrieve the open-directory selection result from the bean.

FALSE:
Retrieve the open-file selection result from the bean.

DP-003

Condition:
Whether the returned path string starts with a double backslash (indicating a UNC path).

TRUE:
Prepend an additional backslash before normalising, to preserve the UNC prefix.

FALSE:
Proceed directly to normalise the path.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - UNC (network) paths starting with "\\\\" are handled specially to prevent corruption of the path prefix during normalisation.
- BR-002 - Double backslashes in the returned path are always collapsed to single backslashes before returning the result.
- BR-003 - If the WebUtil Java bean is not present on the client, form processing is halted immediately.

---
**Implementation Logic**

```plsql
  FUNCTION FILE_SELECTION_DIALOG_INT(   directory_name Varchar2,
                                        file_name      Varchar2,
                                        file_filter    Varchar2,
                                        title          Varchar2,
                                        dialog_type    Number,
                                        select_file    Boolean,
                                        multiselect    Boolean) return Varchar2 is
    result varchar2(4000);     
    pos Number;
  BEGIN  
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_DIRNAME', directory_name);
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILENAME',file_name, true);     
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILTER',  file_filter); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_MESSAGE', title); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_MULTISELECT', multiselect,true);     
  
    if (dialog_type = SAVE_FILE) then 
        result := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_SAVEFILE');
    elsif (not select_file) then
        result := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_OPENDIR');
    else
        result := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_OPENFILE');
    end if;
  
    -- handle the situation which we can get with JFileChooser with escaped "\"

    -- if string starts with '\\', replace it with '\\\\', 
    -- before running the original replace statement.
    pos := instr(result, '\\');

    -- concat '\\' in the begining of the string before calling the replace.
    if (pos = 1) then
        result := concat('\\', result);
    end if;

    result := replace(result,'\\','\');
    return result;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. WEBUTIL_FILE.FILE_SELECTION_DIALOG_INT will not work');
      RAISE FORM_TRIGGER_FAILURE;  
   when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;  
  END FILE_SELECTION_DIALOG_INT;
```

#### SP-028 - WEBUTIL.FOPEN

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Opens a client-side text file for reading, writing, or appending via the WebUtil Java bean and returns a file handle for subsequent read/write operations. Validates the access mode and filename before attempting to open the file, then uses WEBUTIL.GETPROPERTY to retrieve the Java-layer file handle, raising an error if the file cannot be opened or if the bean is unavailable.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| spec | VARCHAR2 | IN |
| filemode | VARCHAR2 | IN |
| charSet | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETPROPERTY ([SP-038](#SP-038--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Validate that the file mode is one of the allowed values ("r", "w", "a") using a case-insensitive check; if not, raise a tool error immediately.
- Step 2 - Validate that the filename/path (spec) is not null or empty; if it is, raise a tool error immediately.
- Step 3 - Send the filename to the WebUtil file bean by setting the WUF_FILENAME property via WebUtil_Core.setProperty.
- Step 4 - Send the file mode to the bean by setting the WUF_TEXTIO_FILEMODE property.
- Step 5 - Evaluate the charSet parameter: if null, pass the literal "(null)" to the WUF_TEXTIO_CHARSET property; otherwise pass the supplied character set string.
- Step 6 - Invoke WEBUTIL.GETPROPERTY (via WebUtil_Core.getProperty) for the WUF_TEXTIO_OPEN property to retrieve the numeric Java file handle returned by the bean.
- Step 7 - If the returned handle is null, empty, or "-1", the file could not be opened; raise a tool error.
- Step 8 - Convert the valid handle string to a number, store it in the file-type structure, and return it to the caller.
- Step 9 - In the exception block, if the bean is not registered, display an error alert identifying the missing implementation class and raise a tool error; propagate PROPERTY_ERROR, VALUE_ERROR (as tool error), and TOOL_ERROR directly.

---
**Decision Points**

DP-001

Condition:
Whether the file mode (case-insensitive) is one of "r", "w", or "a".

TRUE:
Proceed to validate the filename.

FALSE:
Raise TOOL_ERR.TOOL_ERROR immediately.

DP-002

Condition:
Whether the filename/path (spec) is null or empty.

TRUE:
Raise TOOL_ERR.TOOL_ERROR immediately.

FALSE:
Proceed to set bean properties and open the file.

DP-003

Condition:
Whether the charSet parameter is null.

TRUE:
Pass the literal "(null)" to the WUF_TEXTIO_CHARSET bean property.

FALSE:
Pass the supplied charSet string to the WUF_TEXTIO_CHARSET bean property.

DP-004

Condition:
Whether the Java file handle returned by WEBUTIL.GETPROPERTY (WUF_TEXTIO_OPEN) is null, empty, or "-1".

TRUE:
Raise TOOL_ERR.TOOL_ERROR to signal that the file could not be opened.

FALSE:
Convert the handle to a number, store it in the file-type structure, and return it to the caller.

DP-005

Condition:
Whether a WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during bean interaction.

TRUE:
Display an error alert identifying the missing bean class, then raise TOOL_ERR.TOOL_ERROR.

FALSE:
Continue normal processing or propagate other exception types as applicable.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only the three standard file modes - read ("r"), write ("w"), and append ("a") - are permitted; any other value is rejected before any bean interaction occurs.
- BR-002 - A filename (spec) must always be provided; a null or empty value is unconditionally rejected.
- BR-003 - A handle value of "-1" returned from the Java layer via WEBUTIL.GETPROPERTY is treated as an open failure and is never returned to the caller as a valid handle.
- BR-004 - When no character set is specified, the literal string "(null)" is passed to the bean to indicate that no specific encoding is requested; a null charSet is never forwarded directly.
- BR-005 - If the WebUtil bean is not registered on the client, the procedure must surface a descriptive error alert identifying the missing implementation class before raising a tool error, ensuring the failure is diagnosable.

---
**Implementation Logic**

```plsql
  FUNCTION fopen(spec VARCHAR2, filemode VARCHAR2, charSet VARCHAR2 := null) RETURN file_type is
    clientFile file_type;
    javaHandle VARCHAR2(6);
  BEGIN
    -- check the mode is valid
    if (lower(filemode) not in ('r','w','a')) then 
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- make sure a file name has been specified      
    if (spec is null) or (spec='') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;
      
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILENAME',spec, true);
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_FILEMODE',filemode, true);        
    if (charSet is null) then
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET','(null)', true);
    else
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET',charSet, true);
    end if;
    javaHandle := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_OPEN');

    -- If the return is null then the file was not opened      
    if (javaHandle is null) or (javaHandle='') or (javaHandle='-1') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- if we are this far convert the handle to the correct format and return it.      
    clientFile.handle := to_number(javaHandle);
    return clientFile;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.fopen will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                 
      return null;
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE;
    when VALUE_ERROR then
      RAISE TOOL_ERR.TOOL_ERROR; 
    when TOOL_ERR.TOOL_ERROR then 
      RAISE;
  END fopen;
```

#### SP-029 - WEBUTIL.GETCALLBACKTRIGGER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the name of the callback trigger associated with a given numeric key from the internal callbacks collection. This function is used by WEBUTIL.SETDATA to resolve which trigger string corresponds to a specific callback identifier at runtime.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| callbackKey | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the integer callback key (callbackKey) supplied by the calling routine.
- Step 2 - Look up the entry at position callbackKey within the internal collection m_callbacks.
- Step 3 - Return the VARCHAR2 trigger name stored at that collection index to the caller.

---
**Decision Points**

No conditional decision points exist in this function. The implementation performs a direct index lookup on m_callbacks and returns the result unconditionally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The callbackKey parameter must correspond to a valid, populated index within the m_callbacks collection; supplying an undefined or out-of-range key will result in a runtime collection error.
- BR-002 - The function returns exactly one VARCHAR2 value per invocation, representing the trigger name registered under the supplied key.
- BR-003 - The function does not modify the m_callbacks collection or any other state; it is a read-only retrieval operation.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetCallbackTrigger(callbackKey in PLS_INTEGER) return VARCHAR2 is 
  begin 
    return m_callbacks(callbackKey);
  end GetCallbackTrigger;
```

#### SP-030 - WEBUTIL.GETCLIENTOSFAMILY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the operating system family identifier of the client machine as a PLS_INTEGER value. This function exposes the internally stored client OS family constant (m_clientOSFamily) to calling routines, enabling the application to make OS-aware decisions based on the client environment.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - The function is invoked by WEBUTIL.GETVAR, which requires knowledge of the client operating system family.
- Step 2 - The function reads the module-level variable m_clientOSFamily, which holds the pre-populated client OS family identifier.
- Step 3 - The function returns the value of m_clientOSFamily as a PLS_INTEGER to the caller.

---
**Decision Points**

No conditional decision points exist in this function. The function unconditionally reads and returns the value of m_clientOSFamily without branching logic.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function returns the client OS family as a PLS_INTEGER; no input parameters are accepted, and the return value is sourced exclusively from the module-level variable m_clientOSFamily.
- BR-002 - The client OS family value (m_clientOSFamily) must have been populated prior to this function being called; the function performs no initialisation or validation of the variable before returning it.

---
**Implementation Logic**

```plsql

  FUNCTION GetClientOSFamily return PLS_INTEGER is 
  begin 
    return m_clientOSFamily;
  end GetClientOSFamily;
```

#### SP-031 - WEBUTIL.GETCLIENTSETTING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a named client-side configuration property from the WebUtil Core bean and returns its value as a string. The function acts as a controlled accessor, delegating the property lookup to WebUtil_Core and surfacing any bean-availability or property-retrieval failures as handled exceptions before the result is returned to the calling routine (WEBUTIL.CHECKLIBS or WEBUTIL.REGISTERBEAN).

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the property name to be retrieved via the IN parameter propertyName.
- Step 2 - Evaluate whether propertyName is non-null; if null, skip the retrieval logic and proceed directly to returning a null result.
- Step 3 - Invoke WebUtil_Core.setProperty, targeting the WUC_PACKAGE bean and the WUC_GET_LOCAL_PROPERTY slot, passing propertyName as the value to set, thereby instructing the bean which client-side property to resolve.
- Step 4 - Invoke WebUtil_Core.getProperty against the same WUC_PACKAGE bean and WUC_GET_LOCAL_PROPERTY slot to read back the resolved property value, storing it in the local variable result.
- Step 5 - Return result to the caller.
- Step 6 - If the WebUtil Core bean is not registered (BEAN_NOT_REGISTERED exception), display an error alert identifying the missing implementation class and raise FORM_TRIGGER_FAILURE to halt form processing.
- Step 7 - If a property retrieval error occurs (PROPERTY_ERROR exception), raise FORM_TRIGGER_FAILURE to halt form processing without an additional alert.

---
**Decision Points**

DP-001

Condition: propertyName IS NOT NULL

TRUE: Call WebUtil_Core.setProperty to register the requested property name against WUC_GET_LOCAL_PROPERTY on the WUC_PACKAGE bean, then call WebUtil_Core.getProperty to retrieve and store the resolved value in result.

FALSE: Skip both WebUtil_Core calls; result remains NULL and is returned immediately to the caller.

---

DP-002

Condition: WebUtil_Core raises BEAN_NOT_REGISTERED during property set or get

TRUE: Display an error alert that identifies the unregistered implementation class (obtained via WebUtil_Core.getImplClass) and raise FORM_TRIGGER_FAILURE to abort the current form trigger.

FALSE: No bean-registration error; continue normal processing.

---

DP-003

Condition: WebUtil_Core raises PROPERTY_ERROR during property set or get

TRUE: Raise FORM_TRIGGER_FAILURE to abort the current form trigger; no additional alert is displayed.

FALSE: No property error; continue normal processing and return result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A null propertyName must not trigger any interaction with the WebUtil Core bean; the function must return NULL silently without raising an error.
- BR-002 - Property retrieval must be performed exclusively through the WebUtil_Core bean identified by the WUC_PACKAGE constant, using the WUC_GET_LOCAL_PROPERTY slot for both the set and get operations.
- BR-003 - If the WebUtil Core bean is not registered at the time of invocation, the function must surface a descriptive error alert that includes the expected implementation class name before terminating form processing via FORM_TRIGGER_FAILURE.
- BR-004 - A PROPERTY_ERROR condition must cause immediate termination of form processing via FORM_TRIGGER_FAILURE; no user-facing alert is required for this error type.
- BR-005 - The returned property value must not exceed 255 characters, as enforced by the VARCHAR2(255 char) declaration of the internal result variable.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetClientSetting(propertyName in VARCHAR2) return VARCHAR2 is 
    result VARCHAR2(255 char);
  BEGIN
    if propertyName is not null then 
    WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_GET_LOCAL_PROPERTY', propertyName);
       result := WebUtil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_GET_LOCAL_PROPERTY');
    end if;
    return result;
  EXCEPTION  
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                            ||' bean not found. WEBUTIL_CORE.GetClientSetting will not work');
    RAISE FORM_TRIGGER_FAILURE;  
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE FORM_TRIGGER_FAILURE;       
  END GetClientSetting;
```

#### SP-032 - WEBUTIL.GETIMPLCLASS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the fully qualified Java class name for a given WebUtil component package identifier. This name is used in error messages and bean-registration checks to help identify which Java bean is missing or not functioning.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Look up the implementation class suffix in the internal class-name array using the supplied package identifier.
- Step 2 - Prepend the standard WebUtil Java root package path to the class suffix.
- Step 3 - Return the fully qualified class name.

---
**Decision Points**

No conditional decision points in this routine.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The returned class name is always prefixed with the standard WebUtil Java root path; individual components supply only the class-specific suffix.

---
**Implementation Logic**

```plsql

  FUNCTION getImplClass(packageID PLS_INTEGER) return VARCHAR2 is
  BEGIN 
    return WEBUTIL_JAVA_ROOT||m_implClasses(packageID);    
  END;
```

#### SP-033 - WEBUTIL.GETLASTERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the last error code recorded by the AppServerFileReader Java object on the application server. This function is called by WEBUTIL.SETDATA to determine whether a preceding file-transfer operation completed successfully or encountered an error, returning the error status as a numeric code for downstream handling.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the AppServerFileReader Java object instance (obj) as the target on which the error code is to be queried.
- Step 2 - Clear the JNI argument list by setting args to NULL, ensuring no stale arguments are passed to the Java method call.
- Step 3 - Invoke the Java method getLastError() on the oracle/forms/webutil/fileTransfer/AppServerFileReader class via JNI.CALL_INT_METHOD, passing the supplied object instance with no additional arguments (signature '()I').
- Step 4 - Return the integer value received from the Java method call directly to the caller as the last error code.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function unconditionally clears the argument list, invokes the Java method, and returns the resulting integer to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The argument list (args) must be explicitly set to NULL before the JNI method call to prevent unintended arguments from being forwarded to the AppServerFileReader Java method.
- BR-002 - The error code is retrieved exclusively from the AppServerFileReader Java class (oracle/forms/webutil/fileTransfer/AppServerFileReader) using the JNI integer method call interface; no database or PL/SQL-level error source is consulted.
- BR-003 - The function returns a NUMBER representing the last error code; the caller (WEBUTIL.SETDATA) is responsible for interpreting and acting upon the returned value.

---
**Implementation Logic**

```plsql
  FUNCTION getLastError(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_INT_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'getLastError', '()I', args); 
  END;
```

#### SP-034 - WEBUTIL.GETLASTERRORARGS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the argument string associated with the most recent error raised by the AppServerFileReader Java class. The function delegates the call to the underlying Java Native Interface, returning a VARCHAR2 value that describes the error arguments for the last recorded failure, enabling the caller (WEBUTIL.SETDATA) to obtain diagnostic detail about file-transfer errors.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the Java object reference (obj) that represents an active AppServerFileReader instance passed in by the calling routine WEBUTIL.SETDATA.
- Step 2 - Initialise the local argument list (args) to NULL, indicating that the Java method requires no input arguments.
- Step 3 - Invoke the Java method getLastErrorArgs on the AppServerFileReader class via JNI.CALL_STRING_METHOD, passing the object reference, the fully-qualified class path, the method name, and its return-type descriptor.
- Step 4 - Return the VARCHAR2 string result received from the JNI call to the caller, representing the error-argument detail from the last error recorded by the AppServerFileReader instance.

---
**Decision Points**

No conditional decision points exist in this function. The implementation unconditionally clears the argument list and delegates execution to JNI.CALL_STRING_METHOD, returning whatever value that call produces.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The args variable must be set to NULL before the JNI call, ensuring no residual argument data from a prior invocation is passed to the AppServerFileReader.getLastErrorArgs Java method.
- BR-002 - The target Java method is identified by the fully-qualified class path oracle/forms/webutil/fileTransfer/AppServerFileReader and the method signature ()Ljava/lang/String;; any deviation from these identifiers would result in a failed or incorrect JNI dispatch.
- BR-003 - The function returns the raw VARCHAR2 string produced by the JNI call without modification; no transformation, truncation, or default substitution is applied to the error-argument value.

---
**Implementation Logic**

```plsql
  FUNCTION getLastErrorArgs(
    obj   ORA_JAVA.JOBJECT) RETURN VARCHAR2 IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_STRING_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'getLastErrorArgs', '()Ljava/lang/String;', args); 
  END;
```

#### SP-035 - WEBUTIL.GETNUMBER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Extracts a delimited numeric field from a source string at a specified positional index. The function delegates string extraction to WEBUTIL.GETSTRING and converts the resulting substring to a NUMBER, providing callers with a type-safe numeric value without requiring them to perform explicit conversion.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Source_string | varchar2 | IN |
| Field_position | number | IN |
| UnTerminated | Boolean | IN |
| Delimiter | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETSTRING ([SP-039](#SP-039--WEBUTIL.GETSTRING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the source string, the 1-based field position, an optional Boolean flag indicating whether the final field is unterminated, and an optional delimiter character (defaulting to comma).
- Step 2 - Pass all four arguments directly to WEBUTIL.GETSTRING (SP-039), which locates and returns the raw VARCHAR2 token at the specified position within the delimited source string.
- Step 3 - Apply the Oracle built-in TO_NUMBER function to the VARCHAR2 token returned by WEBUTIL.GETSTRING.
- Step 4 - Return the resulting NUMBER value to the caller.

---
**Decision Points**

DP-001

Condition: UnTerminated parameter value passed to WEBUTIL.GETSTRING.

TRUE: WEBUTIL.GETSTRING treats the last field in the source string as having no trailing delimiter, correctly extracting the final token even when it is not followed by the delimiter character.

FALSE: WEBUTIL.GETSTRING applies standard delimited parsing, expecting each field including the last to conform to the delimiter-bounded format.

DP-002

Condition: The VARCHAR2 token returned by WEBUTIL.GETSTRING is a valid numeric string that TO_NUMBER can convert.

TRUE: TO_NUMBER succeeds and the resulting NUMBER value is returned to the caller.

FALSE: TO_NUMBER raises a VALUE_ERROR exception, which propagates unhandled to the calling context (WEBUTIL_CORE.CUSTOMEVENTHANDLER).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The field position must correspond to a valid token within the delimited source string; positional resolution is entirely governed by WEBUTIL.GETSTRING (SP-039).
- BR-002 - The delimiter defaults to a comma if not explicitly supplied; callers may override this to support alternative delimited formats.
- BR-003 - The UnTerminated flag defaults to FALSE; it must be explicitly set to TRUE only when the target field is the last token in a source string that carries no trailing delimiter.
- BR-004 - The extracted token must represent a value that is implicitly convertible to Oracle NUMBER by TO_NUMBER; no internal error handling is provided, and any non-numeric token will cause an unhandled exception to propagate to the caller.

---
**Implementation Logic**

```plsql

    
  function  GetNumber (Source_string    in varchar2,
                       Field_position   in number,
                       UnTerminated     in Boolean  default FALSE,
                       Delimiter        in varchar2 default ',') return number is
                       iRc              pls_integer;
  begin 
    Return to_number(GetString(Source_string, Field_Position, UnTerminated, Delimiter));
  end GetNumber; /* Number Version */
```

#### SP-036 - WEBUTIL.GETOSFAMILY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines and caches the client operating system family by inspecting the supplied OS name string and mapping it to a predefined platform constant (e.g., CLIENT_PLATFORM_WIN32, CLIENT_PLATFORM_MAC, CLIENT_PLATFORM_LINUX, CLIENT_PLATFORM_SOLARIS, CLIENT_PLATFORM_HP, CLIENT_PLATFORM_AIX, or CLIENT_PLATFORM_UNKNOWN). The resolved platform value is stored in the package-level variable m_clientOSFamily so that subsequent calls return the cached result without re-evaluating the OS name. This function is invoked by WEBUTIL.REGISTERBEAN to establish the client platform context required for bean registration.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| osName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the osName input parameter and convert it to lowercase, storing the result in the local variable l_osName to ensure case-insensitive matching.
- Step 2 - Initialise the local result variable to CLIENT_PLATFORM_UNKNOWN as the default platform value.
- Step 3 - Check whether the package-level cache variable m_clientOSFamily is null; if it already holds a value, skip all classification logic and proceed directly to Step 10.
- Step 4 - Search l_osName for the substring 'windows'; if found, set result to CLIENT_PLATFORM_WIN32.
- Step 5 - If Step 4 did not match, search l_osName for the substring 'mac'; if found, set result to CLIENT_PLATFORM_MAC.
- Step 6 - If Step 5 did not match, search l_osName for the substring 'linux'; if found, set result to CLIENT_PLATFORM_LINUX.
- Step 7 - If Step 6 did not match, search l_osName for the substring 'solaris' or 'sunos'; if either is found, set result to CLIENT_PLATFORM_SOLARIS.
- Step 8 - If Step 7 did not match, search l_osName for the substring 'hp-ux'; if found, set result to CLIENT_PLATFORM_HP.
- Step 9 - If Step 8 did not match, search l_osName for the substring 'aix'; if found, set result to CLIENT_PLATFORM_AIX.
- Step 10 - Assign the resolved result value to the package-level variable m_clientOSFamily, persisting it for future calls.
- Step 11 - Return m_clientOSFamily to the caller.

---
**Decision Points**

DP-001

Condition: m_clientOSFamily IS NULL

TRUE: Proceed with OS name classification (Steps 4-10) and populate m_clientOSFamily with the resolved platform constant.

FALSE: Skip all classification logic and return the already-cached value of m_clientOSFamily immediately.

---

DP-002

Condition: l_osName contains the substring 'windows'

TRUE: Set result to CLIENT_PLATFORM_WIN32.

FALSE: Evaluate the next OS family condition (DP-003).

---

DP-003

Condition: l_osName contains the substring 'mac'

TRUE: Set result to CLIENT_PLATFORM_MAC.

FALSE: Evaluate the next OS family condition (DP-004).

---

DP-004

Condition: l_osName contains the substring 'linux'

TRUE: Set result to CLIENT_PLATFORM_LINUX.

FALSE: Evaluate the next OS family condition (DP-005).

---

DP-005

Condition: l_osName contains the substring 'solaris' OR l_osName contains the substring 'sunos'

TRUE: Set result to CLIENT_PLATFORM_SOLARIS.

FALSE: Evaluate the next OS family condition (DP-006).

---

DP-006

Condition: l_osName contains the substring 'hp-ux'

TRUE: Set result to CLIENT_PLATFORM_HP.

FALSE: Evaluate the next OS family condition (DP-007).

---

DP-007

Condition: l_osName contains the substring 'aix'

TRUE: Set result to CLIENT_PLATFORM_AIX.

FALSE: result remains CLIENT_PLATFORM_UNKNOWN; no recognised OS family was matched.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - OS name comparison is always performed in lowercase; the input osName is converted to lowercase before any substring search, ensuring platform detection is case-insensitive.
- BR-002 - Platform classification is mutually exclusive and evaluated in priority order: Windows -> Mac -> Linux -> Solaris/SunOS -> HP-UX -> AIX. The first matching condition wins and subsequent conditions are not evaluated.
- BR-003 - If the supplied OS name does not match any recognised platform substring, the function returns CLIENT_PLATFORM_UNKNOWN as the default platform identifier.
- BR-004 - The resolved OS family is cached in the package-level variable m_clientOSFamily after the first successful evaluation; all subsequent invocations return the cached value without re-processing the OS name string.
- BR-005 - The function accepts no output parameters; the determined platform constant is communicated solely through the function return value (PLS_INTEGER).

---
**Implementation Logic**

```plsql
 
  FUNCTION getOSFamily(osName in VARCHAR2) return PLS_INTEGER is
    l_osName VARCHAR2(30) := lower(osName);
    result   PLS_INTEGER  := CLIENT_PLATFORM_UNKNOWN;
  BEGIN
    if m_clientOSFamily  is null then 
      if (instr(l_osName,'windows') > 0) then 
           result := CLIENT_PLATFORM_WIN32;
      elsif instr(l_osName,'mac') > 0 then 
          result := CLIENT_PLATFORM_MAC;      
      elsif instr(l_osName,'linux') > 0 then 
          result := CLIENT_PLATFORM_LINUX;      
      elsif instr(l_osName,'solaris') > 0 OR instr(l_osName, 'sunos') > 0 then 
          result := CLIENT_PLATFORM_SOLARIS;       
      elsif instr(l_osName,'hp-ux') > 0 then 
          result := CLIENT_PLATFORM_HP; 
      elsif instr(l_osName,'aix') > 0 then 
          result := CLIENT_PLATFORM_AIX;                                                       
      end if;            
      m_clientOSFamily := result;
    end if;
    return m_clientOSFamily;
  END getOSFamily;
```

#### SP-037 - WEBUTIL.GETOUTPUT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GET_STANDARD_OUTPUT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves all lines of output from a previously launched host process by iteratively polling the WebUtil client-side bean for buffered output lines. The function collects each line into an OUTPUT_ARRAY and returns the complete array to the caller (WEBUTIL.GET_STANDARD_OUTPUT), ensuring that all available output - including multi-line results - is captured before the loop terminates.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |
| prop | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.INIT ([SP-046](#SP-046--WEBUTIL.INIT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Set the process handle on the WebUtil core package by calling WebUtil_Core.setProperty with the WUH_PACKAGE constant, the property key 'WUH_PROC_ID', and the handle value from the supplied PROCESS_ID parameter.
- Step 2 - Enter a loop that repeatedly calls WebUtil_Core.getProperty with the WUH_PACKAGE constant and the caller-supplied prop parameter to retrieve the next buffered output line into a VARCHAR2 buffer.
- Step 3 - Extract the first character of the returned buffer as a status indicator ('Y' = more lines follow, 'N' = this is the last line, 'X' = buffer was empty).
- Step 4 - If status is not 'X' (i.e., a real line was returned), store the remainder of the buffer (characters from position 2 onward) into the next element of the OUTPUT_ARRAY and increment the index counter.
- Step 5 - Exit the loop when status is not 'Y' (i.e., the last line has been read or the buffer was empty).
- Step 6 - Return the populated OUTPUT_ARRAY to the caller.
- Step 7 - If the WebUtil bean is not registered on the client, catch the WebUtil_Core.BEAN_NOT_REGISTERED exception and display an error alert identifying the missing bean class, informing the user that WEBUTIL_HOST.GetOutput will not work.

---
**Decision Points**

DP-001

Condition: The first character of the buffer returned by WebUtil_Core.getProperty is not 'X'.

TRUE: The buffer contains a valid output line; strip the status character and append the remaining text to the OUTPUT_ARRAY, then increment the index.

FALSE: The buffer is empty; skip storage and proceed to the exit evaluation.

DP-002

Condition: The status character extracted from the buffer is not 'Y'.

TRUE: No further output lines are pending (status is 'N' - last line - or 'X' - empty buffer); exit the polling loop and return the collected array.

FALSE: Status is 'Y', indicating additional output lines remain; continue looping to retrieve the next line.

DP-003

Condition: The WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during execution.

TRUE: The required client-side bean is absent; display an error alert composed of the bean's implementation class name and a message stating that WEBUTIL_HOST.GetOutput will not work.

FALSE: No exception; normal processing continues and the OUTPUT_ARRAY is returned.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The process handle must be registered with the WebUtil core package via WebUtil_Core.setProperty before any output retrieval is attempted; this binding associates subsequent getProperty calls with the correct host process.
- BR-002 - Each value returned by WebUtil_Core.getProperty is a prefixed string: the first character is a control status ('Y', 'N', or 'X') and must be stripped before the remaining text is stored as an output line.
- BR-003 - A status of 'X' indicates an empty buffer; the corresponding buffer value must not be stored in the output array.
- BR-004 - Polling continues as long as the status character is 'Y'; the loop must exit on any non-'Y' status to prevent infinite iteration.
- BR-005 - If the WebUtil client-side bean is not registered, the function must not silently fail; it must surface an error alert that identifies the missing bean class and explicitly states that output retrieval is non-functional.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetOutput(process in PROCESS_ID, prop in VARCHAR2) return OUTPUT_ARRAY is   
    lines  OUTPUT_ARRAY;
    i      PLS_INTEGER := 1;
    buffer VARCHAR2(257 char);
    status VARCHAR2(1) := 'X';
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_PROC_ID',process.handle);
    LOOP
      buffer := WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,prop);
      status := substr(buffer,1,1);
      -- Status can be Y: indicating more lines to follow,
      --               N: indicating that this is the last line
      --               X: indicating that the buffer was empty
      if status <> 'X' then 
        lines(i) := substr(buffer,2);
        i := i + 1;
      end if;
      exit when status <> 'Y';
    END LOOP;
    return lines;    
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.GetOutput will not work');
  END GetOutput;  
  
BEGIN
    -- Ensure that Core is instanciated.
    Webutil_Core.Init;
END;

PACKAGE WEBUTIL_SEPARATEFRAME IS

/*********************************************************************************\
 * WEBUTIL_SEPARATEFRAME
 *   This Package contains routines to interact with the MDI frame when Forms
 *   is running with the parameter separateFrame=true
 *   The functions in this package will work with any client type - not just 
 *   Windows clients.
 *   The oracle.forms.webutil.browser.BrowserFunctions bean is needed in your 
 *   Form to use these functions
 *********************************************************************************
 * Version 1.0.0
 *********************************************************************************
 * Change History
 *   1.0.0 DRMILLS 25/MAY/2003 - Creation
 *   1.0.1 DRMILLS 27/MAY/2003 - Added call to get frame size 
 *
\*********************************************************************************/

  /**
   *  IsSeparateFrame - Allows you to check if the form 
   *                is running in separateFrame mode or not
   */
```

#### SP-038 - WEBUTIL.GETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FOPEN]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value of a named Java system property from the client JVM. This allows the form to read runtime environment settings (such as file paths or system configuration values) that are held in the client's Java environment.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the name of the Java system property to retrieve.
- Step 2 - Call the Java System.getProperty method on the client JVM via JNI with the property name as the argument.
- Step 3 - Return the property value as a string.

---
**Decision Points**

No conditional decision points in this routine.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The property name is passed directly to the Java runtime; no validation or transformation is applied before the call.
- BR-002 - If the property does not exist in the Java environment, the Java runtime returns null.

---
**Implementation Logic**

```plsql
  FUNCTION getProperty(
    a0    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'getProperty', '(Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-039 - WEBUTIL.GETSTRING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETNUMBER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Extracts a single delimited token from a source string at a specified field position. Given a delimiter-separated string, the function locates the Nth occurrence of the delimiter to isolate and return the substring occupying the requested field position. It is used internally within the WEBUTIL package, notably invoked by WEBUTIL.GETNUMBER, to parse structured string values before further type conversion.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Source_string | varchar2 | IN |
| Field_position | number | IN |
| UnTerminated | Boolean | IN |
| Delimiter | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-050](#SP-050--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the source string, the target field position (1-based), an optional flag indicating whether the string lacks a trailing delimiter (UnTerminated), and an optional delimiter character (defaulting to comma).
- Step 2 - Create a working copy of the source string to avoid mutating the input.
- Step 3 - If UnTerminated is TRUE, append the delimiter to the working copy so that the final token is bounded and can be located using standard delimiter-search logic.
- Step 4 - Determine the start pointer (iPtrStart): if Field_Position is greater than 1, locate the delimiter occurrence at position Field_Position-1 using INSTR and advance the pointer past the delimiter by adding the length of the delimiter string; otherwise, set the start pointer to 1 (beginning of the string).
- Step 5 - Determine the end pointer (iPtrEnd) by locating the delimiter occurrence at Field_Position using INSTR.
- Step 6 - Extract and return the substring from iPtrStart for a length of (iPtrEnd - iPtrStart), yielding the token at the requested field position.

---
**Decision Points**

DP-001

Condition: UnTerminated parameter is TRUE.

TRUE: The delimiter is appended to the working copy of the source string before parsing begins, ensuring the last token in an unterminated string is bounded and correctly extractable.

FALSE: The source string is used as-is; no modification is made prior to parsing.

---

DP-002

Condition: Field_Position is greater than 1.

TRUE: The start pointer is calculated by finding the (Field_Position - 1)th occurrence of the delimiter and advancing past it by the length of the delimiter, positioning the pointer at the first character of the requested token.

FALSE: The start pointer is set to 1, meaning extraction begins at the very start of the string (first token).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Field positions are 1-based; a Field_Position value of 1 always begins extraction from the first character of the source string.
- BR-002 - The delimiter defaults to a comma if not explicitly supplied, supporting standard CSV-style parsing without requiring the caller to specify a delimiter.
- BR-003 - If the source string does not end with the delimiter and the caller knows this, UnTerminated must be set to TRUE so that the function appends the delimiter internally; failure to do so will cause the last token to be unreachable.
- BR-004 - The function operates on a local copy of the source string; the original input is never modified.
- BR-005 - The working string supports up to 32,000 characters, constraining the maximum length of the source string that can be parsed.
- BR-006 - Token length is derived implicitly as (iPtrEnd - iPtrStart); no explicit length parameter is required from the caller.

---
**Implementation Logic**

```plsql

  function  GetString (Source_string    in varchar2,
                       Field_position   in number,
                       UnTerminated     in Boolean  default FALSE,
                       Delimiter        in varchar2 default ',') return varchar2 is
                       iPtrEnd          pls_integer     := 0;
                       iPtrStart        pls_integer     := 0;
                       vcSourceStrCopy  varchar2(32000)     := Source_string;
  begin
    if UnTerminated then 
      vcSourceStrCopy := vcSourceStrCopy||Delimiter;
    end if;

    if Field_Position > 1 then 
      iPtrStart := instr(vcSourceStrCopy,Delimiter,1,Field_Position-1)+ length(Delimiter);
    else
      iPtrStart := 1;
    end if ; 

    iPtrEnd     := instr(vcSourceStrCopy,Delimiter,1,Field_Position);
    return substr(vcSourceStrCopy,iPtrStart,(iPtrEnd-iPtrStart));
  end GetString; /* String Version */
```

#### SP-040 - WEBUTIL.GETVAR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.GETVAR resolves the value of a named configuration variable on the client machine by selecting the appropriate retrieval strategy based on the client operating system family. On Windows clients it queries the Oracle registry key first, falling back to an environment variable lookup. On Unix clients it executes the 'env' command and parses its output. On Mac and unknown platforms no action is taken. The procedure is invoked during bean registration to supply runtime environment values needed by the WebUtil framework.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VARNAME | VARCHAR2 | IN |
| VARVALUE | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VARVALUE | VARCHAR2 | IN OUT |

---

**Dependencies**

- GET_ENVIRONMENT_STRING ([SP-072](#SP-072--GET_ENVIRONMENT_STRING)) - matched by member name
- READ_REGISTRY ([SP-075](#SP-075--READ_REGISTRY)) - matched by member name
- WEBUTIL.GETCLIENTOSFAMILY ([SP-030](#SP-030--WEBUTIL.GETCLIENTOSFAMILY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_STANDARD_OUTPUT ([SP-043](#SP-043--WEBUTIL.GET_STANDARD_OUTPUT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the variable name (VARNAME) and an IN OUT buffer (VARVALUE) as inputs.
- Step 2 - Call WEBUTIL.GETCLIENTOSFAMILY (WebUtil_Core.GetClientOSFamily) to determine the client platform.
- Step 3 - If the client platform is WIN32, attempt to read the variable value from the Windows registry under HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE using READ_REGISTRY (Client_Win_API_Environment.read_registry), passing VARNAME and a non-recursive flag.
- Step 4 - If the registry lookup returns NULL or an empty string, fall back to reading the value from the client environment variables using GET_ENVIRONMENT_STRING (CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING) with VARNAME.
- Step 5 - If the client platform is MAC or UNKNOWN, take no action and leave VARVALUE unchanged.
- Step 6 - If the client platform is any other value (Unix), execute the 'env' shell command in blocking mode to obtain all environment variables, then retrieve the command output via WEBUTIL.GET_STANDARD_OUTPUT (WebUtil_HOST.Get_Standard_Output) and release the process handle.
- Step 7 - Iterate over each line of the Unix 'env' output; for each line locate the '=' delimiter, extract the key portion, and compare it to VARNAME. When a match is found, extract the value portion into VARVALUE and exit the loop.
- Step 8 - If a NO_DATA_FOUND exception is raised at any point, set VARVALUE to NULL and return.

---
**Decision Points**

DP-001

Condition: Client OS family equals WIN32 (WebUtil_Core.CLIENT_PLATFORM_WIN32).

TRUE: Attempt registry lookup under HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE for VARNAME; if that returns NULL or empty, fall back to GET_ENVIRONMENT_STRING.

FALSE: Evaluate DP-002.

DP-002

Condition: Client OS family is MAC or UNKNOWN (WebUtil_Core.CLIENT_PLATFORM_MAC or WebUtil_Core.CLIENT_PLATFORM_UNKNOWN).

TRUE: No action is taken; VARVALUE is left unchanged.

FALSE: Platform is treated as Unix; proceed to execute the 'env' command and parse its output (DP-003 applies within that branch).

DP-003

Condition: Registry value returned by READ_REGISTRY is NULL or empty string (Windows branch only).

TRUE: Call GET_ENVIRONMENT_STRING to retrieve the variable value from the client environment.

FALSE: Use the registry value already stored in VARVALUE; no further lookup is performed.

DP-004

Condition: A '=' character is found at a position greater than zero within the current Unix 'env' output line.

TRUE: Extract the key (left of '=') and compare it to VARNAME; if equal, extract the value (right of '=') into VARVALUE and exit the loop.

FALSE: Skip the current line and continue iterating.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - On a Windows client, the Oracle registry path HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE is always the primary source for the requested variable; the environment variable is only consulted when the registry yields no value.
- BR-002 - On Mac and unknown client platforms, variable resolution is not supported; VARVALUE is returned unchanged without raising an error.
- BR-003 - On Unix clients, variable resolution is performed exclusively by executing the 'env' command and parsing its output; no registry or direct API call is used.
- BR-004 - Unix 'env' output lines that do not contain a '=' character are silently ignored during parsing.
- BR-005 - Only the first matching Unix environment variable entry is used; the loop exits immediately upon finding a key equal to VARNAME, preventing duplicate matches from overwriting the result.
- BR-006 - A NO_DATA_FOUND exception anywhere in the procedure is handled gracefully by setting VARVALUE to NULL, ensuring the caller always receives a defined output value.

---
**Implementation Logic**

```plsql

  PROCEDURE GETVAR(VARNAME IN VARCHAR2, VARVALUE IN OUT VARCHAR2) is
    unixOutput WebUtil_HOST.OUTPUT_ARRAY;
    hostHandle WebUtil_HOST.PROCESS_ID;
    varKey     VARCHAR2(100);
    iPos       PLS_INTEGER;
  BEGIN
    if WebUtil_Core.GetClientOSFamily = WebUtil_Core.CLIENT_PLATFORM_WIN32 then 
      -- read the client Registry
      VARVALUE := Client_Win_API_Environment.read_registry('HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE',VARNAME,false);
      if VARVALUE is null OR VARVALUE = '' then
        -- Could not get an Oracle variable in registry. Try to get from environment varialble
        -- java desupported System.getenv method until they supported it again in 1.5.
        -- We can still get the environment variables in windows using
        -- CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING
        VARVALUE := CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING(VARNAME);
      end if;
    elsif WebUtil_Core.GetClientOSFamily in (WebUtil_Core.CLIENT_PLATFORM_MAC,WebUtil_Core.CLIENT_PLATFORM_UNKNOWN) then 
      -- do nothing 
      null;
    else
      -- Unix Ports - do a env to get the environment and parse that
      hostHandle := WebUtil_HOST.Blocking('env');
      unixOutput := WebUtil_HOST.Get_Standard_Output(hostHandle);
      WebUtil_HOST.Release_Process(hostHandle);
      for i in 1..unixOutput.count LOOP
        iPos := instr(unixOutput(i),'=');
        if iPos > 0 then 
          varKey := substr(unixOutput(i),1,iPos-1);
          if varKey = VARNAME then 
            VARVALUE := substr(unixOutput(i),iPos+1);
            EXIT;
          end if;
        end if;
      end LOOP;
    end if;

  exception
    when NO_DATA_FOUND then
      VARVALUE := null;
  END GETVAR;

END CLIENT_TOOL_ENV;

PACKAGE Client_Win_API IS
/*-------------------------------------------------------------------------------*\
 * WebUtil version of D2KWUTIL package WIN_API                                     
 * Note: Not all D2kWutil Functions are ported
 *********************************************************************************
 * Version 1.0.0
 *********************************************************************************
 * Change History
 *   DRMILLS 21/FEB/2003 - Port Creation
 *
 *********************************************************************************
 * WIN_API ->  This package defines the constants used throughout 
 *      the library as a whole, including versions of those 
 *      constants defined within WINDOWS.H/WINUSER.H that 
 *      we'll be using. Add more constants in here if required
 *      The package also contains Explicit Exception declarations,
 *      various status Flags and functions for Error Handling
 * NOTE:    In order to make this library portable across Forms
 *      and Reports we do not use any application 
 *      specific built-ins such as the Forms MESSAGE() 
 *      Built-in. Instead errors are recorded in a package
 *      variable which the programmer can examine if required
\*-------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------*\
 * Internal Version Number  ** Oracle Developer Release 6.0 Version
\*-------------------------------------------------------------------------------*/
  WIN_API_VERSION  CONSTANT  VARCHAR2(30) := '6.0.6.0 Production';
  DLL_NAME         CONSTANT  VARCHAR2(12) := 'd2kwut60.dll';
  DLL_PATH         VARCHAR2(256)          := NULL;

/*-------------------------------------------------------------------------------*\
 * General Window Classes of Common Applications for use with WIN_API_SESSION
 * ** WARNING ** These Window classes are out of our control and might change 
 *               when you upgrade the software in question,
\*-------------------------------------------------------------------------------*/

  -- Oracle Apps
  WINCLASS_DEVELOPER_2000_V1  CONSTANT  VARCHAR2(15)  := 'ui23MDIroot_W32';             /* Developer/2000 release 1.n / Toolkit 2.3 Apps on 32 bit */
  WINCLASS_DEVELOPER_2000_V2  CONSTANT  VARCHAR2(15)  := 'ui25MDIroot_W32';             /* Developer/2000 Release 2.0 / Toolkit 2.5 Apps on 32 bit */
  WINCLASS_DEVELOPER_2000_V6  CONSTANT  VARCHAR2(15)  := 'ui60MDIroot_W32';             /* Developer/2000 Release 6.0 / Toolkit 6.0 Apps on 32 bit */  
  D2K_WINDOW_CLASS            CONSTANT  VARCHAR2(15)  := WINCLASS_DEVELOPER_2000_V6;    /* Set to the "current" version */  
  WINCLASS_INTEROFFICE_40     CONSTANT  VARCHAR2(28)  := 'Afx:10000000:b:10008:6:5023b';/* Oracle Interoffice 4.0 Client 32 bit */
  WINCLASS_INTEROFFICE_41     CONSTANT  VARCHAR2(28)  := 'Afx:10000000:b:1496:6:3a17';  /* Oracle Interoffice 4.0 Client 32 bit */
  WINCLASS_SQLPLUS            CONSTANT  VARCHAR2(13)  := 'SqlplusWClass';               /* Sql*Plus 32 bit */
  WINCLASS_REPORTSSERVER_V1   CONSTANT  VARCHAR2(15)  := 'R25SRV_WINCLASS';             /* Reports Server Reports 2.5 */
  WINCLASS_REPORTSSERVER_V2   CONSTANT  VARCHAR2(15)  := 'R30SRV_WINCLASS';             /* Reports Server Reports 3.0 */
  WINCLASS_REPORTSSERVER_V6   CONSTANT  VARCHAR2(14)  := 'RWRBE_WINCLASS';              /* Reports Server Reports 6.0 */

  -- Microsoft Office Apps - Office97
  WINCLASS_MSWORD_97         CONSTANT  VARCHAR2(7) := 'OpusApp';                        /* Microsoft Word 97 */
  WINCLASS_MSEXCEL_97        CONSTANT  VARCHAR2(6) := 'XLMAIN';                         /* Microsoft Excel 97 */
  WINCLASS_MSPOWERPOINT_97   CONSTANT  VARCHAR2(14):= 'PP97FrameClass';                 /* Microsoft Power Point 97 */

  -- Microsoft Office Apps - Office95
  WINCLASS_MSWORD_7          CONSTANT  VARCHAR2(7) := 'OpusApp';                        /* Microsoft Word 7 */
  WINCLASS_MSEXCEL_7         CONSTANT  VARCHAR2(6) := 'XLMAIN';                         /* Microsoft Excel 7 */
  WINCLASS_MSPOWERPOINT_7    CONSTANT  VARCHAR2(13):= 'PP7FrameClass';                  /* Microsoft Power Point 7 */
  WINCLASS_MSSCHEDULE_7      CONSTANT  VARCHAR2(23):= 'MS Schedule+ 32 Panesdi';        /* Microsoft Schedule 7 */
  WINCLASS_MSEXCHANGE_4      CONSTANT  VARCHAR2(29):= 'Microsoft Exchange 4.0 Viewer';  /* Microsoft Exchange 4 in-tray */

  -- Microsoft O/S Utilities
  WINCLASS_INETEXPLORER      CONSTANT  VARCHAR2(7):= 'IEFrame';                         /* Internet Explorer */
  WINCLASS_OUTLOOK_EXPRESS   CONSTANT  VARCHAR2(29):= 'Outlook Express Browser Class';  /* Outlook Express */
  WINCLASS_EXPLORER          CONSTANT  VARCHAR2(13):= 'ExploreWClass';                  /* Explorer */
  WINCLASS_MYCOMPUTER        CONSTANT  VARCHAR2(13):= 'CabinetWClass';                  /* My Computer & Network Neighborhood*/
  WINCLASS_CALCULATOR        CONSTANT  VARCHAR2(7) := 'SciCalc';                        /* Windows Calculator */
  WINCLASS_NOTEPAD           CONSTANT  VARCHAR2(7) := 'Notepad';                        /* Windows Notepad */
  WINCLASS_WORDPAD           CONSTANT  VARCHAR2(12):= 'WordPadClass';                   /* Windows Wordpad/Write */
  WINCLASS_DOS               CONSTANT  VARCHAR2(18):= 'ConsoleWindowClass';             /* Dos Window */

  -- Other
  WINCLASS_NETSCAPE_3        CONSTANT  VARCHAR2(27):= 'Afx:40000000:b:150e:6:38cfe';    /* Netscape Navigator 3.0 */
  WINCLASS_NETSCAPE_4        CONSTANT  VARCHAR2(28):= 'Afx:40000000:b:10008:6:6063e';   /* Netscape Communicator 4.0 */
  WINCLASS_PFE_7             CONSTANT  VARCHAR2(11):= 'PFE32_Frame';                    /* Programmers File Editor */
  WINCLASS_REGEDIT           CONSTANT  VARCHAR2(15):= 'RegEdit_RegEdit';                /* Registry Editor */

  -- Window Style Constants (from WINUSER.H)
  --  Any PU's that use these constants will explain 
  --  their use.  For further information consult the
  --  Windows SDK.

  SW_HIDE              CONSTANT  PLS_INTEGER := 0;
  SW_SHOWNORMAL        CONSTANT  PLS_INTEGER := 1;
  SW_SHOWMINIMIZED     CONSTANT  PLS_INTEGER := 2;
  SW_SHOWMAXIMIZED     CONSTANT  PLS_INTEGER := 3;
  SW_SHOWNOACTIVATE    CONSTANT  PLS_INTEGER := 4;
  SW_SHOW              CONSTANT  PLS_INTEGER := 5;
  SW_MINIMIZE          CONSTANT  PLS_INTEGER := 6;
  SW_SHOWMINNOACTIVE   CONSTANT  PLS_INTEGER := 7;
  SW_SHOWNA            CONSTANT  PLS_INTEGER := 8;
  SW_RESTORE           CONSTANT  PLS_INTEGER := 9;
  SW_SHOWDEFAULT       CONSTANT  PLS_INTEGER := 10;

  -- Help Access Constants (From WINUSER.H)
  --  See WIN_API_SHELL.WinHelp

  HELP_CONTEXT         CONSTANT  PLS_INTEGER := 1;   /* 0x0001L */
  HELP_QUIT            CONSTANT  PLS_INTEGER := 2;   /* 0x0002L */
  HELP_INDEX           CONSTANT  PLS_INTEGER := 3;   /* 0x0003L */
  HELP_CONTENTS        CONSTANT  PLS_INTEGER := 3;   /* 0x0003L */
  HELP_HELPONHELP      CONSTANT  PLS_INTEGER := 4;   /* 0x0004L */
  HELP_SETINDEX        CONSTANT  PLS_INTEGER := 5;   /* 0x0005L */
  HELP_SETCONTENTS     CONSTANT  PLS_INTEGER := 5;   /* 0x0005L */
  HELP_CONTEXTPOPUP    CONSTANT  PLS_INTEGER := 8;   /* 0x0008L */
  HELP_FORCEFILE       CONSTANT  PLS_INTEGER := 9;   /* 0x0009L */
  HELP_KEY             CONSTANT  PLS_INTEGER := 257; /* 0x0101L */
  HELP_COMMAND         CONSTANT  PLS_INTEGER := 258; /* 0x0102L */
  HELP_PARTIALKEY      CONSTANT  PLS_INTEGER := 261; /* 0x0105L */
  HELP_MULTIKEY        CONSTANT  PLS_INTEGER := 513; /* 0x0201L */
  HELP_SETWINPOS       CONSTANT  PLS_INTEGER := 515; /* 0x0203L */
  -- Windows 4+
  HELP_CONTEXTMENU     CONSTANT  PLS_INTEGER := 10;  /* 0x000a  */
  HELP_FINDER          CONSTANT  PLS_INTEGER := 11;  /* 0x000b  */
  HELP_WM_HELP         CONSTANT  PLS_INTEGER := 12;  /* 0x000c  */
  HELP_SETPOPUP_POS    CONSTANT  PLS_INTEGER := 13;  /* 0x000d  */

  -- Windows Messages for use with SendMessage
  -- DO NOT utilise the Windows Sendmessage interface without being conversant
  -- with the Windows message handling mechanism
  -- Refer to the Microsoft Windows SDK for Messages and Parameter values
  WM_SYSCOMMAND        CONSTANT  PLS_INTEGER := 274;   /* 0x0112 */
  WM_MDITILE           CONSTANT  PLS_INTEGER := 550;   /* 0x0226 */
  WM_MDICASCADE        CONSTANT  PLS_INTEGER := 551;   /* 0x0227 */
  WM_MDIICONARRANGE    CONSTANT  PLS_INTEGER := 552;   /* 0x0228 */      
  SC_RESTORE           CONSTANT  PLS_INTEGER := 61728; /* 0xF120 */
  SC_MINIMIZE          CONSTANT  PLS_INTEGER := 61472; /* 0xF020 */
  SC_MAXIMIZE          CONSTANT  PLS_INTEGER := 61488; /* 0xF030 */
  

  -- Flags for use with File Dialog boxes ("Save As" or "Open")
  -- Refer to your Microsoft documentation for details on the 
  -- Exact usage and dependancies of each option
  OFN_READONLY           CONSTANT  PLS_INTEGER := 1;        /* 0x00000001 */
  OFN_OVERWRITEPROMPT    CONSTANT  PLS_INTEGER := 2;        /* 0x00000002 */
  OFN_HIDEREADONLY       CONSTANT  PLS_INTEGER := 4;        /* 0x00000004 */
  OFN_NOCHANGEDIR        CONSTANT  PLS_INTEGER := 8;        /* 0x00000008 */
  OFN_SHOWHELP           CONSTANT  PLS_INTEGER := 16;       /* 0x00000010 */
  OFN_NOVALIDATE         CONSTANT  PLS_INTEGER := 256;      /* 0x00000100 */
  OFN_ALLOWMULTISELECT   CONSTANT  PLS_INTEGER := 512;      /* 0x00000200 */
  OFN_EXTENSIONDIFFERENT CONSTANT  PLS_INTEGER := 1024;     /* 0x00000400 */
  OFN_PATHMUSTEXIST      CONSTANT  PLS_INTEGER := 2048;     /* 0x00000800 */
  OFN_FILEMUSTEXIST      CONSTANT  PLS_INTEGER := 4096;     /* 0x00001000 */
  OFN_CREATEPROMPT       CONSTANT  PLS_INTEGER := 8192;     /* 0x00002000 */
  OFN_SHAREAWARE         CONSTANT  PLS_INTEGER := 16384;    /* 0x00004000 */
  OFN_NOREADONLYRETURN   CONSTANT  PLS_INTEGER := 32768;    /* 0x00008000 */
  OFN_NOTESTFILECREATE   CONSTANT  PLS_INTEGER := 65536;    /* 0x00010000 */
  OFN_NONETWORKBUTTON    CONSTANT  PLS_INTEGER := 131072;   /* 0x00020000 */
  OFN_NOLONGNAMES        CONSTANT  PLS_INTEGER := 262144;   /* 0x00040000 */
  OFN_EXPLORER           CONSTANT  PLS_INTEGER := 524288;   /* 0x00080000 */
  OFN_NODEREFERENCELINKS CONSTANT  PLS_INTEGER := 1048576;  /* 0x00100000 */
  OFN_LONGNAMES          CONSTANT  PLS_INTEGER := 2097152;  /* 0x00200000 */

  -- The defaults used here (WIN_API.OFN_PATHMUSTEXIST|WIN_API.OFN_FILEMUSTEXIST|WIN_API.OFN_HIDEREADONLY|WIN_API.OFN_NOCHANGEDIR|WIN_API.OFN_EXPLORER)
  OFN_FLAG_DEFAULT       CONSTANT  PLS_INTEGER :=  530444;
  
  
  -- Registry Data types for Write_RegistryEx
  REG_EXPAND_SZ          CONSTANT  PLS_INTEGER := 0;
  REG_SZ                 CONSTANT  PLS_INTEGER := 1;
  REG_DWORD              CONSTANT  PLS_INTEGER := 2;
  
  -- Compatibility Flags - Used where I have changed behaviour and you might not like the new version
  -- Change these at runtime to FALSE to revert to "old" behaviour
  COMPAT_EXPAND_REG_VALUES    BOOLEAN := TRUE;

  
  
  -- Types
  TYPE aFunctionHandle is table of WEBUTIL_C_API.FUNCTIONHANDLE index by BINARY_INTEGER;  
  SUBTYPE FILE_TYPE is PLS_INTEGER;

  -- Public Variables
  ERROR_ENCOUNTERED  BOOLEAN := FALSE;  /* The Last Call resulted in an error */
  ERROR_STACK        VARCHAR2(2000);    /* Holds Text of Last error(s) */ 
  API_ENABLED        BOOLEAN := FALSE;   /* Are API functions usable ?*/
  DLL_HANDLE         ORA_FFI.LibHandleType;
  FunctionHandle     aFunctionHandle;
   

  -- Public Exceptions
  NOT_AVAILABLE      EXCEPTION;  /* A call to the API was made but API functions not currently available (e.g. not on Windows) */
     
  -- Error Constants
  UError             CONSTANT  VARCHAR2(30) := ' Caused an unexpected error: ';
  NoAPI              CONSTANT  VARCHAR2(31) := 'API Functions are not Available';
  MaxDWord           CONSTANT  VARCHAR2(33) := 'Integer Argument exceeds 32 bits ';
  MaxWord            CONSTANT  VARCHAR2(33) := 'Integer Argument exceeds 16 bits ';
  MaxByte            CONSTANT  VARCHAR2(32) := 'Integer Argument exceeds 8 bits ';
  MinBound           CONSTANT  VARCHAR2(27) := 'Integer Argument too Small ';
  MaxBound           CONSTANT  VARCHAR2(27) := 'Integer Argument too Large ';
  NullArg            CONSTANT  VARCHAR2(24) := 'Argument cannot be NULL ';

  /*----------------------------------------------------------------------------*\
  * PreLoad ->  Loads the d2kwut60.dll from the jvm bin directory into memory
  \*----------------------------------------------------------------------------*/
```

#### SP-041 - WEBUTIL.GET_LINE

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Reads the next line of text from an open client-side text file and returns it as a string. The procedure communicates the file handle to the WebUtil Core bean, retrieves the next line, and raises NO_DATA_FOUND when the end of the file is reached. If the WebUtil bean is unavailable or a property error occurs, the procedure raises a fatal TOOL_ERROR.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| item | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Pass the file handle to the WebUtil Core bean by setting the WUF_TEXTIO_HANDLE property on the WUF_PACKAGE component.
- Step 2 - Retrieve the next line of text from the bean by reading the WUF_TEXTIO_GETLINE property into a local VARCHAR2 buffer.
- Step 3 - Evaluate the buffer content: if it equals a lone newline character (CHR(10)), the bean is signalling end-of-file; raise NO_DATA_FOUND.
- Step 4 - If the buffer does not equal CHR(10), assign the buffer value to the OUT parameter and return normally.
- Step 5 - If the bean is not registered (BEAN_NOT_REGISTERED exception), display an error alert identifying the missing implementation class and raise TOOL_ERROR.
- Step 6 - If a property retrieval error occurs (PROPERTY_ERROR exception), raise TOOL_ERROR immediately.

---
**Decision Points**

DP-001

Condition:
Whether the buffer returned by the WebUtil Core bean equals CHR(10) (the end-of-file sentinel).

TRUE:
Raise NO_DATA_FOUND to signal that there are no more lines to read.

FALSE:
Assign the buffer to the OUT parameter and return normally.

---

DP-002

Condition:
Whether the WebUtil Core bean is registered when the procedure attempts to interact with it (BEAN_NOT_REGISTERED exception).

TRUE:
Display an error alert naming the missing implementation class and raise TOOL_ERROR.

FALSE:
Continue normal execution.

---

DP-003

Condition:
Whether a property error occurs during bean communication (PROPERTY_ERROR exception).

TRUE:
Raise TOOL_ERROR immediately.

FALSE:
Continue normal execution.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - End-of-file is communicated by the WebUtil Core bean as a lone newline character (CHR(10)); callers must handle NO_DATA_FOUND to detect end-of-file correctly.
- BR-002 - An empty line within the file is returned as an empty string and is not treated as end-of-file, because the bean only places a bare CHR(10) into the buffer when reading beyond the last line.
- BR-003 - If the WebUtil Core bean is not registered, the procedure must not silently fail; it displays a descriptive alert and raises TOOL_ERROR to halt processing.
- BR-004 - Any property retrieval error from the WebUtil Core bean is treated as a fatal condition and surfaces as TOOL_ERROR to the caller.

---
**Implementation Logic**

```plsql
  PROCEDURE get_line (file file_type, item OUT VARCHAR2) is
    buffer VARCHAR2(4000 char);
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);        
    buffer := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_GETLINE');
    -- We can't easily tell the difference between an empty line and a line beyond then 
    -- end of the file so to get around this, the exception handling code in the PJC 
    -- places a newline into the buffer when the end of file is passed.
    -- The rational being that get_line would never normally return a newline because 
    -- it normally uses that to tell it where to read up *to*.
    if buffer = chr(10) then 
      raise NO_DATA_FOUND;
    else
      item := buffer;
    end if;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.get_line will not work');
      RAISE TOOL_ERR.TOOL_ERROR;                                                                 
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE TOOL_ERR.TOOL_ERROR;  
  END get_line;
  
  /**
   * File writing functions
   */
```

#### SP-042 - WEBUTIL.GET_RETURN_CODE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.HOST]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the exit code of a completed host process from the WebUtil Java bean. This allows the form to determine whether an externally executed command completed successfully or reported a failure.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Pass the process handle to the WebUtil host bean as a property.
- Step 2 - Request the return code from the bean for the identified process.
- Step 3 - Convert the string result to a number and return it to the caller.

---
**Decision Points**

No conditional decision points in this routine.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - If the WebUtil host bean is not registered on the client, an alert is shown and the routine returns without a value (implicitly null).

---
**Implementation Logic**

```plsql
  
  
  FUNCTION Get_Return_Code(process in PROCESS_ID) return PLS_INTEGER is
  begin 
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_PROC_ID',process.handle);
    return to_number(WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,'WUH_RC'));
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
       WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                               ||' bean not found. WEBUTIL_HOST.Get_Return_Code will not work');
  end Get_Return_Code;
```

#### SP-043 - WEBUTIL.GET_STANDARD_OUTPUT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the standard output stream produced by a previously executed host process. Given a process identifier, the function delegates to WEBUTIL.GETOUTPUT to extract all output lines associated with the 'WUH_STDOUT' channel and returns them as an array for the caller to consume.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETOUTPUT ([SP-037](#SP-037--WEBUTIL.GETOUTPUT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the process identifier (PROCESS_ID) that references a previously executed host process.
- Step 2 - Invoke WEBUTIL.GETOUTPUT, passing the supplied process identifier and the fixed output-channel token 'WUH_STDOUT', to retrieve all standard output lines captured for that process.
- Step 3 - Return the OUTPUT_ARRAY result produced by WEBUTIL.GETOUTPUT directly to the caller.

---
**Decision Points**

No conditional decision points exist in this function. Execution follows a single, unconditional path: delegate to WEBUTIL.GETOUTPUT with the 'WUH_STDOUT' channel token and return the result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The output channel targeted by this function is exclusively 'WUH_STDOUT'; standard error or any other output channel is outside the scope of this function.
- BR-002 - The function produces no side effects and performs no database interactions; it acts solely as a typed wrapper that constrains WEBUTIL.GETOUTPUT to the standard output channel.
- BR-003 - The caller is responsible for supplying a valid PROCESS_ID; no input validation is performed within this function before the call to WEBUTIL.GETOUTPUT.

---
**Implementation Logic**

```plsql
    
  FUNCTION Get_Standard_Output(process in PROCESS_ID) return OUTPUT_ARRAY is  
  begin 
    return GetOutput(process,'WUH_STDOUT');
  end Get_Standard_Output;
```

#### SP-044 - WEBUTIL.HOST

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Executes a host command synchronously, waits for it to complete, retrieves its exit code, releases the process handle, and returns the exit code to the caller. This is the primary routine for running external programs from the form and checking whether they completed successfully.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.BLOCKING ([SP-015](#SP-015--WEBUTIL.BLOCKING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_RETURN_CODE ([SP-042](#SP-042--WEBUTIL.GET_RETURN_CODE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ID_NULL ([SP-045](#SP-045--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.RELEASE_PROCESS ([SP-059](#SP-059--WEBUTIL.RELEASE_PROCESS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Execute the command in blocking mode and receive a process identifier.
- Step 2 - Check whether the process identifier is non-null (i.e., the command was launched successfully).
- Step 3 - If the process identifier is valid, retrieve the exit code from the completed process.
- Step 4 - Release the process handle to free the associated client-side resources.
- Step 5 - Return the exit code to the caller (default is -1 if the process was never launched).

---
**Decision Points**

DP-001

Condition:
Whether the process identifier returned by the blocking execution is non-null (the process was successfully launched).

TRUE:
Retrieve the exit code and release the process handle.

FALSE:
Return the default exit code of -1 without attempting to get a return code.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The default exit code of -1 is returned when the command could not be launched; callers should treat -1 as an indication of launch failure.
- BR-002 - Process handles are always released after the exit code is retrieved, regardless of the exit code value.

---
**Implementation Logic**

```plsql
  FUNCTION  Host(cmd in VARCHAR2) return PLS_INTEGER is
    procId PROCESS_ID;
    RC     PLS_INTEGER := -1;
  begin
    procId := Blocking(cmd);
    if not ID_NULL(procId) then
      RC := Get_Return_Code(procId);
      -- release the client side object
      Release_Process(procId);
    end if;
    return RC;
  end Host;
```

#### SP-045 - WEBUTIL.ID_NULL

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]
- webutil.pld [StoredProcedure: WEBUTIL.ERRORALERT]
- webutil.pld [StoredProcedure: WEBUTIL.HOST]
- webutil.pld [StoredProcedure: WEBUTIL.INITWEBUTIL]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTER_FUNCTION]
- webutil.pld [StoredProcedure: WEBUTIL.SHOWBEANS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Tests whether a given handle (pointer) is null, returning TRUE if no value has been assigned and FALSE if the handle contains a value. Used throughout the WebUtil library to guard against operating on uninitialised or released handles.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| handle | Pointer | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Examine the internal handle value of the supplied pointer.
- Step 2 - Return TRUE if the handle value is null; return FALSE if it is not null.

---
**Decision Points**

DP-001

Condition:
Whether the handle's internal value is null.

TRUE:
Return TRUE to indicate the handle is null.

FALSE:
Return FALSE to indicate the handle contains a value.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine performs a purely structural null check; it does not validate whether the handle refers to a currently active resource.

---
**Implementation Logic**

```plsql

  FUNCTION ID_NULL(handle IN Pointer)        RETURN BOOLEAN is
  BEGIN
    if handle.hnd is null then 
      return TRUE;
    else
      return FALSE;
    end if;
  END ID_NULL;
```

#### SP-046 - WEBUTIL.INIT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETOUTPUT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.INIT is a package initialisation procedure that serves as the formal entry point for the WEBUTIL_CORE package. Its sole responsibility is to trigger package-level initialisation by delegating to WEBUTIL.INITWEBUTIL (SP-047) via the package initialisation block. The procedure body itself performs no discrete processing; the act of entering the package is sufficient to invoke the package-level BEGIN block, which calls INITWEBUTIL to set up the WebUtil utility environment.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.INITWEBUTIL ([SP-047](#SP-047--WEBUTIL.INITWEBUTIL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - The procedure body executes a NULL statement, performing no discrete processing; entering the package is sufficient to activate the package initialisation block.
- Step 2 - Upon package instantiation, the package-level BEGIN block is executed automatically by the PL/SQL runtime.
- Step 3 - The package-level BEGIN block calls WEBUTIL.INITWEBUTIL (SP-047) to perform the actual WebUtil utility initialisation.

---
**Decision Points**

No decision points exist within this procedure. The procedure body is unconditional (NULL statement only) and the package-level initialisation block calls WEBUTIL.INITWEBUTIL without any conditional branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure body must not contain active processing logic; entering the WEBUTIL_CORE package is the mechanism that triggers initialisation, not any explicit step within INIT itself.
- BR-002 - All substantive WebUtil initialisation must be delegated exclusively to WEBUTIL.INITWEBUTIL (SP-047), which is invoked once via the package-level BEGIN block when the package is first instantiated within a session.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Init is
  begin 
    -- we don't need to do anything here - entering the package is enough to set it up.      
    null;
  end;      

BEGIN
  -- Initialise the Utility
  InitWebUtil;  
END WEBUTIL_CORE;

PACKAGE WEBUTIL_C_API IS
/*********************************************************************************\
 * WEBUTIL_C_API
 *   This Package provides a way of calling C functions in a shared library on the
 *   client PC. Currently only win32 is supported.
 *   The oracle.forms.webutil.cApi.CApiFunctions bean is needed in your Form to 
 *   use these functions
 *********************************************************************************
 * Version 1.0.5
 *********************************************************************************
 * Change History
 *   1.0.1 RVSUILIC 14/FEB/2003 - Creation 
 *   1.0.2 DRMILLS  27/FEB/2003 - Reset LONG to the same value as INT which is fine
 *                                for Windows & removed Tester proc
 *   1.0.3 DRMILLS  01/MAR/2003 - Re-worked the PL/SQL API
 *   1.0.4 DRMILLS  13/MAY/2003 - Added call to WebUtil_Core.Init
 *   1.0.5 RVSUILIC 21/MAY/2003 - Cleaned up some comments and formatting.
 *
\*********************************************************************************/

  /**
   *  Constants to represent PL/SQL IN, OUT and INOUT parameter qualifiers
   */
  PARAM_IN    CONSTANT PLS_INTEGER := 50;
  PARAM_INOUT CONSTANT PLS_INTEGER := 51;
  PARAM_OUT   CONSTANT PLS_INTEGER := 52;
  

  /**
   *  Constants to represent C atomic datatypes and pointers to atomic datatypes
   *  Note that to use OUT and INOUT qualifiers the C function in the DLL *must*
   *  use a pointer type to be able to pass information back.
   *
   *  The comments on the right indicate which types can be used for parameters
   *  and which for function return types.
   *
   *  c_ptr is used as a generic pointer. The onlys supported use for this is to
   *  save the pointer value from C into a PL/SQL variable, so that it may be 
   *  passed back later to C. No operations on the pointer are supported in PL/SQL.
   */
  c_void          CONSTANT PLS_INTEGER := 30;            /* - not used -   */
  c_char          CONSTANT PLS_INTEGER := 31;            /* param & return */
  c_short         CONSTANT PLS_INTEGER := 32;            /* param & return */
  c_int           CONSTANT PLS_INTEGER := 33;            /* param & return */
  c_long          CONSTANT PLS_INTEGER := 33;            /* param & return *//*DRM - same as INT */
  c_float         CONSTANT PLS_INTEGER := 35;            /* param & return */
  c_double        CONSTANT PLS_INTEGER := 36;            /* param & return */

  c_ptr           CONSTANT PLS_INTEGER := 64 + c_void;   /* param & return */
  c_char_ptr      CONSTANT PLS_INTEGER := 64 + c_char;   /* param          */
  c_short_ptr     CONSTANT PLS_INTEGER := 64 + c_short;  /* param          */
  c_int_ptr       CONSTANT PLS_INTEGER := 64 + c_int;    /* param          */
  c_long_ptr      CONSTANT PLS_INTEGER := 64 + c_long;   /* param          */
  c_float_ptr     CONSTANT PLS_INTEGER := 64 + c_float;  /* param          */
  c_double_ptr    CONSTANT PLS_INTEGER := 64 + c_double; /* param          */

  /**
   *  Abstracted types to be used for pointers and handles. The forms programmer
   *  should not attempt any manipulation on these types, but merely obtain them as
   *  a result of functions below, and pass them back in to other functions below.
   */
    SUBTYPE handleType   IS NUMBER;
    TYPE Pointer         IS RECORD (hnd handleType);   /* C pointer             */
    TYPE FunctionHandle  IS RECORD (hnd handleType);   /* function handle       */
    TYPE ParameterHandle IS RECORD (hnd handleType);   /* parameter handle      */
    TYPE ParameterList   IS RECORD (hnd handleType);   /* parameter list handle */

  /**
   *  IS_SUPPORTED - Check if the client is on a supported hardware platform.
   */
```

#### SP-047 - WEBUTIL.INITWEBUTIL

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.INIT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Initialises the WebUtil framework within an Oracle Form session. The procedure registers the Java implementation class names for each WebUtil functional package, verifies that the mandatory WebUtil object group (including its error alert and dummy item) is present in the form, optionally navigates to the WebUtil bean area to force bean instantiation, and determines the server-side file-path separator based on the host operating system. It is called once during form initialisation by WEBUTIL.INIT.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-045](#SP-045--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SHOWBEANS ([SP-063](#SP-063--WEBUTIL.SHOWBEANS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Capture the current cursor field (SYSTEM.CURSOR_FIELD) and locate the WebUtil dummy item (WEBUTIL_DUMMY_ITEM) for later navigation use.
- Step 2 - Populate the internal implementation-class registry (m_implClasses) by mapping each WebUtil package constant (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL) to its corresponding Java class name string.
- Step 3 - Check whether the WebUtil error alert (m_errorAlert) is present in the form by calling WEBUTIL.ID_NULL.
- Step 4 - If the error alert is absent, display a message informing the user that the WEBUTIL object group is not available and that WebUtil cannot operate, then pause execution. No further initialisation is performed.
- Step 5 - If the error alert is present and the explicit-instantiation flag (FLAG_EXPICIT_INSTANCIATE) is enabled and the form is in NORMAL mode, evaluate whether the WebUtil dummy item exists (via WEBUTIL.ID_NULL).
- Step 6 - If the dummy item exists, navigate to it using GO_ITEM to trigger bean-area rendering. If the starting cursor field belongs to the same block as the dummy item, call NEXT_BLOCK to move focus away; otherwise navigate back to the original cursor field using GO_ITEM(startPoint).
- Step 7 - Call WEBUTIL.SHOWBEANS(false) to render the bean areas without making them visible to the end user.
- Step 8 - If the dummy item does not exist, take no action, assuming the developer manages bean-area setup independently.
- Step 9 - Determine the server operating system by inspecting GET_APPLICATION_PROPERTY(OPERATING_SYSTEM). If the OS name contains 'WIN', set the server file-path separator (m_serverFileSep) to backslash; otherwise set it to forward slash.

---
**Decision Points**

DP-001

Condition: WEBUTIL.ID_NULL(m_errorAlert) is TRUE (the WebUtil error alert is not present in the form).

TRUE: Display an error message stating the WEBUTIL object group is unavailable and WebUtil cannot work, then pause. Initialisation halts; Steps 5-9 are not executed.

FALSE: Continue with conditional bean instantiation (Steps 5-8) and server OS detection (Step 9).

---

DP-002

Condition: FLAG_EXPICIT_INSTANCIATE is TRUE AND SYSTEM.MODE equals 'NORMAL'.

TRUE: Proceed to evaluate the dummy item and perform bean-area navigation (Steps 6-8).

FALSE: Skip bean-area navigation entirely; proceed directly to server OS detection (Step 9).

---

DP-003

Condition: WEBUTIL.ID_NULL(hDummy) is FALSE (the WebUtil dummy item exists in the form).

TRUE: Navigate to the dummy item, conditionally call NEXT_BLOCK or return to the original cursor field, then call WEBUTIL.SHOWBEANS(false).

FALSE: Take no action; the developer is assumed to handle bean-area setup independently.

---

DP-004

Condition: After navigating to the dummy item, GET_ITEM_PROPERTY(startPoint, BLOCK_NAME) equals GET_ITEM_PROPERTY(hDummy, BLOCK_NAME) (the original cursor field is in the same block as the dummy item).

TRUE: Call NEXT_BLOCK to move focus out of the dummy item's block before calling WEBUTIL.SHOWBEANS.

FALSE: Return focus to the original cursor field using GO_ITEM(startPoint) before calling WEBUTIL.SHOWBEANS.

---

DP-005

Condition: INSTR(UPPER(GET_APPLICATION_PROPERTY(OPERATING_SYSTEM)), 'WIN') > 0 (the server OS name contains 'WIN').

TRUE: Set m_serverFileSep to backslash ('\') for Windows-style file paths.

FALSE: Set m_serverFileSep to forward slash ('/') for Unix/Linux-style file paths.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The WEBUTIL object group, including its error alert component, must be present in the calling form before WebUtil can be initialised. If the error alert is absent, initialisation is blocked and the form is notified via a message and pause.
- BR-002 - Bean-area navigation and explicit instantiation are performed only when the form is in NORMAL mode; Enter-Query mode is explicitly excluded to prevent navigation conflicts.
- BR-003 - Explicit bean instantiation (navigation to the dummy item and invocation of WEBUTIL.SHOWBEANS) is governed by the FLAG_EXPICIT_INSTANCIATE flag, allowing the behaviour to be toggled on or off as a workaround mechanism.
- BR-004 - If the WebUtil dummy item is not found in the form, the procedure assumes the developer has implemented a custom bean-area setup and takes no navigation action.
- BR-005 - When navigating away from the dummy item after bean instantiation, the procedure must restore focus to the original cursor field unless that field shares the same block as the dummy item, in which case NEXT_BLOCK is used to avoid block-level navigation conflicts.
- BR-006 - The server file-path separator stored in m_serverFileSep must reflect the actual server operating system: backslash for any Windows variant, forward slash for all other operating systems. This value is used by subsequent WebUtil file-handling operations.

---
**Implementation Logic**

```plsql
  
  PROCEDURE InitWebUtil is
    startPoint VARCHAR2(61 char) := NAME_IN('SYSTEM.CURSOR_FIELD');
    hDummy     ITEM              := FIND_ITEM(WEBUTIL_DUMMY_ITEM);
  BEGIN
    -- Set up the various package we know about.
    m_implClasses(WUC_PACKAGE) := 'common.VBeanCommon'; 
    m_implClasses(WUT_PACKAGE) := 'fileTransfer.FileTransfer'; 
    m_implClasses(WUF_PACKAGE) := 'file.FileFunctions'; 
    m_implClasses(WUI_PACKAGE) := 'clientInfo.GetClientInfo'; 
    m_implClasses(WUH_PACKAGE) := 'host.Host'; 
    m_implClasses(WUS_PACKAGE) := 'session.SessionFunctions'; 
    m_implClasses(WUB_PACKAGE) := 'browser.BrowserFunctions'; 
    m_implClasses(WUO_PACKAGE) := 'ole.OleFunctions'; 
    m_implClasses(WUU_PACKAGE) := '';      
    m_implClasses(WUL_PACKAGE) := 'cApi.CApiFunctions';                     
    
    -- Now check for the Webutil Object group which 
    -- contains the Beans etc.
          
    if id_null(m_errorAlert) then 
      -- The Webutil error alert is not around
      -- so the Code cannot operate 
      message('The WEBUTIL object group is not available in this Form.  WebUtil cannot work');
      pause;
    else
      -- Bug 2955789 - this navigation causes problems if they are in Enter-Query mode 
      -- Plus it's not really needed, except as a belt and braces kind of setup.
      -- So put a check to prevent this in E-Q mode and set a top level flag to bypass it 
      -- it all together which we can switch on or off if required as a furture W/A    
      if FLAG_EXPICIT_INSTANCIATE and name_in('SYSTEM.MODE') = 'NORMAL' then 
        if not ID_NULL(hDummy) then 
          -- they are using the standard Object Group
          GO_ITEM(hDummy);
          if GET_ITEM_PROPERTY(startPoint,BLOCK_NAME) = GET_ITEM_PROPERTY(hDummy,BLOCK_NAME) then 
            NEXT_BLOCK;
          else
            GO_ITEM(startPoint);
          end if;
          ShowBeans(false);        
        else
          -- do nothing assume that the programmer is doing their own thing.
          -- with regards to setting up the bean areas and making sure they are drawn
           null;      
        end if;
      end if;
    end if;
        
    -- Work out the server o/s informtion that we need
    if instr(upper(GET_APPLICATION_PROPERTY(OPERATING_SYSTEM)),'WIN') > 0 then 
      m_serverFileSep := '\';
    else
      m_serverFileSep := '/';
    end if;
  END InitWebUtil;
```

#### SP-048 - WEBUTIL.ISERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns a Boolean indicator that signals whether the most recent WebUtil operation resulted in an error. It exposes the internal error-state variable `m_lastError` to callers - specifically WEBUTIL.LOG - so that upstream logic can branch on whether a prior WebUtil call succeeded or failed without directly inspecting the raw error code.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Read the value of the package-level variable `m_lastError`, which holds the numeric error code set by the most recently executed WebUtil operation.
- Step 2 - Evaluate whether `m_lastError` is not equal to zero.
- Step 3 - Return TRUE if `m_lastError` is non-zero (an error condition exists), or FALSE if `m_lastError` equals zero (no error condition exists).

---
**Decision Points**

DP-001

Condition: `m_lastError <> 0`

TRUE: The function returns TRUE, indicating that the last WebUtil operation produced an error.

FALSE: The function returns FALSE, indicating that the last WebUtil operation completed without error.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A non-zero value of `m_lastError` is the sole criterion for classifying the last WebUtil operation as an error; any non-zero code, regardless of its specific value, is treated as an error state.
- BR-002 - The function is read-only with respect to `m_lastError`; it reports the error state but does not reset or modify it.
- BR-003 - The function accepts no input parameters; the error state it reports is entirely determined by the current value of the package-level variable `m_lastError` at the time of invocation.

---
**Implementation Logic**

```plsql
  FUNCTION isError   return BOOLEAN is
  begin 
    return m_lastError <> 0;
  end;
```

#### SP-049 - WEBUTIL.IS_OPEN

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines whether a given file handle is currently open by inspecting the handle attribute of the supplied FILE_TYPE parameter. Returns TRUE if the file is open and FALSE if it is not, allowing callers such as WEBUTIL.LOG to guard against operations on unopened files.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FILE_TYPE input parameter containing the file handle to be evaluated.
- Step 2 - Inspect the handle attribute of the supplied FILE_TYPE value.
- Step 3 - If the handle is NULL, return FALSE to indicate the file is not open.
- Step 4 - If the handle is not NULL, return TRUE to indicate the file is open.

---
**Decision Points**

DP-001

Condition:
file.handle IS NULL

TRUE:
The function returns FALSE, signalling that no file is currently open for the supplied FILE_TYPE parameter.

FALSE:
The function returns TRUE, signalling that the file is open and its handle is valid.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A FILE_TYPE value whose handle attribute is NULL is treated as a closed (or never-opened) file; no further file operations should be attempted on it.
- BR-002 - A FILE_TYPE value whose handle attribute is NOT NULL is treated as an open file, and the function confirms its availability for subsequent file operations.
- BR-003 - The function is read-only with respect to the FILE_TYPE parameter; it performs no modification to the file handle or any other state.

---
**Implementation Logic**

```plsql
  
  FUNCTION is_open(file file_type) RETURN BOOLEAN IS
  BEGIN
    IF file.handle IS NULL THEN
      RETURN(FALSE);
    ELSE
      RETURN(TRUE);
    END IF;
  END is_open;
```

#### SP-050 - WEBUTIL.LENGTH

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: DEBUGLOG]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: STRIPDIRSEP]
- webutil.pld [StoredProcedure: WEBUTIL.GETSTRING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the size in bytes of a Java File object on the client machine. This is used by other routines to determine the file size before or after a download operation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept a reference to a Java File object.
- Step 2 - Invoke the Java File.length() method on the object via JNI to obtain the file size.
- Step 3 - Return the file size as a number.

---
**Decision Points**

No conditional decision points in this routine.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file size is obtained directly from the Java File object; no formatting or conversion is applied before returning.

---
**Implementation Logic**

```plsql
  FUNCTION length(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_LONG_METHOD(FALSE, obj, 'java/io/File', 'length', '()J', args); 
  END;
```

#### SP-051 - WEBUTIL.LOG

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]
- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.LOG writes diagnostic and error messages to a server-side log file on behalf of the WebUtil framework. On first invocation it reads logging configuration from the property bundle (enabled flag, errors-only flag, and target file path), caches those settings in package-level variables, and synchronises the logging mode with the registered WebUtil bean. On subsequent calls it appends the supplied message-optionally prefixed with the client IP address and username-to the configured log file, subject to the active logging mode.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| msg | VARCHAR2 | IN |
| isError | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-023](#SP-023--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ISERROR ([SP-048](#SP-048--WEBUTIL.ISERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.IS_OPEN ([SP-049](#SP-049--WEBUTIL.IS_OPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.PUT_LINE ([SP-054](#SP-054--WEBUTIL.PUT_LINE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-055](#SP-055--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Check whether the package-level logging cache has been initialised (m_loggingAllowed IS NULL). If uninitialised, proceed to Steps 2-7; otherwise skip to Step 8.
- Step 2 - Call WEBUTIL.READFROMPROPERTYBUNDLE to read 'logging.enabled', 'logging.errorsonly', and 'logging.file', and store the results in the package-level variables m_loggingAllowed, m_loggingErrorsOnly, and m_loggingFile respectively.
- Step 3 - If logging is enabled but no log file path was returned, disable logging (m_loggingAllowed := FALSE) and report configuration error WUC-008: if no bean is registered, raise the error via WEBUTIL.ERRORALERT; otherwise push property WUC_SRV_LOGGING = '0' to the bean and raise the error through the WebUtil_Core error mechanism.
- Step 4 - If at least one bean is registered, synchronise the logging mode with the bean by setting WUC_SRV_LOGGING to '2' (full logging), '1' (errors-only logging), or '0' (logging disabled) depending on the cached flag values.
- Step 5 - After cache initialisation, evaluate whether logging is currently allowed (m_loggingAllowed = TRUE).
- Step 6 - If logging is allowed, evaluate whether the current message qualifies for writing: it qualifies if errors-only mode is inactive, or if errors-only mode is active and the isError parameter is TRUE.
- Step 7 - Open the log file in append mode using TEXT_IO.FOPEN. Verify the file is open via TEXT_IO.IS_OPEN; if not, raise NO_DATA_FOUND to trigger the exception handler.
- Step 8 - Write the message to the log file using TEXT_IO.PUT_LINE. If m_clientIP is populated, prefix the message with the client IP address and username; otherwise write the message as supplied.
- Step 9 - Close the log file with TEXT_IO.FCLOSE.
- Step 10 - In the exception handler, if SQLCODE = -302000 (file write failure), report error WUC-007 (unable to write to log file) via WEBUTIL.ERRORALERT or the bean error mechanism, disable logging permanently for the session (m_loggingAllowed := FALSE), and suppress the exception. Any other exception is re-raised.

---
**Decision Points**

DP-001
Condition: m_loggingAllowed IS NULL (logging cache not yet initialised).
TRUE: Read logging configuration from the property bundle via WEBUTIL.READFROMPROPERTYBUNDLE and populate the package-level cache variables.
FALSE: Skip initialisation and proceed directly to the log-write evaluation.

DP-002
Condition: Logging is enabled (m_loggingAllowed = TRUE) but m_loggingFile IS NULL.
TRUE: Disable logging (m_loggingAllowed := FALSE) and raise configuration error WUC-008 via WEBUTIL.ERRORALERT (no bean) or the WebUtil_Core bean error mechanism (bean present).
FALSE: Retain the logging-enabled state and continue.

DP-003
Condition: At least one bean is registered (m_registeredPackages.FIRST IS NOT NULL) at the end of cache initialisation.
TRUE: Push the resolved logging mode (WUC_SRV_LOGGING = '0', '1', or '2') to the bean via WebUtil_Core.setProperty.
FALSE: Skip bean synchronisation.

DP-004
Condition: m_loggingAllowed = TRUE when the log-write section is reached.
TRUE: Evaluate whether the message qualifies for writing (see DP-005).
FALSE: Exit the procedure without writing anything.

DP-005
Condition: m_loggingErrorsOnly = FALSE, OR (m_loggingErrorsOnly = TRUE AND isError = TRUE).
TRUE: Open the log file and write the message.
FALSE: Skip writing this message.

DP-006
Condition: TEXT_IO.IS_OPEN returns FALSE after the FOPEN call.
TRUE: Raise NO_DATA_FOUND, transferring control to the exception handler.
FALSE: Proceed to write the message.

DP-007
Condition: m_clientIP IS NULL at the point of writing.
TRUE: Write the message to the log file without any prefix.
FALSE: Prefix the message with m_clientIP and m_clientUserName before writing.

DP-008
Condition: An exception occurs and SQLCODE = -302000 (file write error).
TRUE: Report error WUC-007 via WEBUTIL.ERRORALERT (no bean) or the bean error mechanism (bean present), set m_loggingAllowed := FALSE, and suppress the exception.
FALSE: Re-raise the exception to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Logging configuration (enabled flag, errors-only flag, and log file path) is read from the property bundle exactly once per session; the results are cached in package-level variables and reused on all subsequent calls.
- BR-002 - If logging is enabled but no log file path is configured, logging must be disabled immediately and error WUC-008 must be reported; the absence of a file path is treated as a fatal configuration error.
- BR-003 - When errors-only mode is active (logging.errorsonly = 'true'), only calls where isError = TRUE result in a log entry; informational messages are silently suppressed.
- BR-004 - Each log entry is appended to the existing log file (open mode 'A'); the file is opened and closed on every qualifying call to avoid file-handle leaks.
- BR-005 - When a client IP address is available (m_clientIP IS NOT NULL), every log entry must be prefixed with the client IP address and username to support auditability.
- BR-006 - The logging mode communicated to the WebUtil bean must reflect the resolved configuration: '0' = disabled, '1' = errors only, '2' = full logging.
- BR-007 - A file write failure (SQLCODE -302000) must disable logging for the remainder of the session (m_loggingAllowed := FALSE) and report error WUC-007; it must not propagate an unhandled exception to the caller.
- BR-008 - When no bean is registered, configuration and write errors must be surfaced to the user immediately via WEBUTIL.ERRORALERT using hard-coded English text, as no bean-based error mechanism is yet available.

---
**Implementation Logic**

```plsql
  

  PROCEDURE Log(msg in VARCHAR2, isError BOOLEAN) is
    logFile       TEXT_IO.FILE_TYPE;
    logFileName   VARCHAR2(1024 char);
    errorOnlyMode BOOLEAN;
  begin
    -- check to see if we should do anything
    if m_loggingAllowed is null then 
      -- set up the logging info Cache
      m_loggingAllowed    := (lower(ReadFromPropertyBundle('logging.enabled')) = 'true');
      m_loggingErrorsOnly := (lower(ReadFromPropertyBundle('logging.errorsonly')) = 'true');
      m_loggingFile       := ReadFromPropertyBundle('logging.file');
      if m_loggingAllowed then 
        if m_loggingFile is null then 
          -- no file == no logging
          m_loggingAllowed := false;
          if m_registeredPackages.FIRST is null then
            -- There is no bean registered yet. Throw error in English using alert
            ErrorAlert('WUC-008: Server side logging was requested but no log file was specified'
                       ||' - logging is disabled');
          else
            WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
            WebUtil_Core.error(WUC_PACKAGE,8,'WebUtil_Core.Log');
          end if;
        end if;
      end if;
      if m_registeredPackages.FIRST is not null then
        -- At least one bean is registered. Can call setProperty(WUC_PACKAGE)
        if m_loggingAllowed and m_loggingErrorsOnly then
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','1',true);
        elsif  m_loggingAllowed then
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','2',true);
        else
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
        end if;
      end if;
    end if;
        
    -- now log if allowed to do so
    if m_loggingAllowed then
      if ((not m_loggingErrorsOnly) or (m_loggingErrorsOnly and isError)) then
        logFile := TEXT_IO.FOPEN(m_loggingFile,'A');
        if not TEXT_IO.IS_OPEN(logFile) then 
          raise NO_DATA_FOUND;
        end if;
        if m_clientIP is null then
        	TEXT_IO.PUT_LINE(logFile,msg);
        else
        	TEXT_IO.PUT_LINE(logFile,m_clientIP||':'||m_clientUserName||': '||msg);
        end if;
        TEXT_IO.FCLOSE(logFile);
      end if;    
    end if;
  EXCEPTION
    when others then 
      if SQLCODE = '-302000' then
        if m_registeredPackages.FIRST is null then
          -- There is no bean registered yet. Throw error in English using alert
          ErrorAlert('WUC-007: Unable to write to WebUtil Logging File '|| m_loggingFile);
        else

          WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
          WebUtil_Core.error(WebUtil_Core.WUC_PACKAGE,7,'WebUtil_Core.Log',m_loggingFile);
        end if;
        m_loggingAllowed := false;
      else
        RAISE;
      end if;      
  end Log;
```

#### SP-052 - WEBUTIL.POPULATEPROPERTYBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.READFROMPROPERTYBUNDLE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Locates and reads the WebUtil configuration file, parses its key-value properties into the in-memory property bundle (m_propertyBundle), and returns the value associated with the requested property key. The procedure resolves the configuration file path from three sources in priority order: a Forms global variable, an environment variable, and a Forms parameter. It is invoked by WEBUTIL.READFROMPROPERTYBUNDLE to supply configuration values at runtime.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-023](#SP-023--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Read the WebUtil configuration file path from the Forms global variable (WEBUTIL_CONFIG_GLOBAL); if the global is unset ('[NOTSET]'), clear it and proceed to the next source.
- Step 2 - If the global was unset, attempt to retrieve the configuration file path from the operating-system environment variable (WEBUTIL_CONFIG_ENV) using TOOL_ENV.GETVAR.
- Step 3 - If the environment variable also yields no value, attempt to retrieve the configuration file path from the Forms parameter (WEBUTIL_CONFIG_PARAM).
- Step 4 - If all three sources fail to provide a path, raise NO_DATA_FOUND to trigger the error-handling branch.
- Step 5 - Persist the resolved configuration file path back into the Forms global variable (WEBUTIL_CONFIG_GLOBAL) via COPY so that subsequent calls do not need to re-resolve it.
- Step 6 - Open the resolved configuration file for reading using TEXT_IO.FOPEN.
- Step 7 - Read the file line by line in a loop using TEXT_IO.GET_LINE; exit the loop when NO_DATA_FOUND is raised (end of file).
- Step 8 - For each line, skip it if the first character is '#' (comment line).
- Step 9 - For non-comment lines, locate the '=' delimiter using INSTR; skip lines that do not contain '='
- Step 10 - For lines containing '=', increment the property index, then store the trimmed, lowercased key and the trimmed, carriage-return-stripped value into the next slot of m_propertyBundle.
- Step 11 - Compare the stored key (lowercased) against the lowercased input propertyKey; if they match, capture the corresponding value into the result variable.
- Step 12 - After the loop completes, close the configuration file using TEXT_IO.FCLOSE.
- Step 13 - Return the result value (the matching property value, or NULL if the key was not found in the file).
- Step 14 - On NO_DATA_FOUND exception (no config file path resolved): if no bean is registered (m_registeredPackages.FIRST is null), invoke WEBUTIL.ERRORALERT to display error 'WUC-005: No WebUtil Configuration File specified'; otherwise delegate to Webutil_Core.Error. Set m_config_error to TRUE and return NULL.
- Step 15 - On SQLCODE -302000 (file read failure): if no bean is registered, invoke WEBUTIL.ERRORALERT to display error 'WUC-006: Unable to read WebUtil Configuration File'; otherwise delegate to Webutil_Core.Error. Set m_config_error to TRUE and return NULL. For all other exceptions, re-raise.

---
**Decision Points**

DP-001
Condition: The Forms global variable WEBUTIL_CONFIG_GLOBAL contains a value other than '[NOTSET]'.
TRUE: Use the global variable value as the configuration file path and skip environment-variable and parameter lookups.
FALSE: Clear the global variable value and proceed to check the environment variable (DP-002).

DP-002
Condition: The environment variable WEBUTIL_CONFIG_ENV yields a non-null configuration file path.
TRUE: Use the environment variable value as the configuration file path and skip the Forms parameter lookup.
FALSE: Attempt to retrieve the configuration file path from the Forms parameter WEBUTIL_CONFIG_PARAM (DP-003).

DP-003
Condition: The Forms parameter WEBUTIL_CONFIG_PARAM yields a non-null configuration file path.
TRUE: Use the parameter value as the configuration file path.
FALSE: Raise NO_DATA_FOUND; no configuration source is available.

DP-004
Condition: The first character of a line read from the configuration file is '#'.
TRUE: Skip the line entirely (treat as a comment).
FALSE: Proceed to check for a key-value delimiter (DP-005).

DP-005
Condition: The line contains an '=' character (INSTR returns a position greater than 0).
TRUE: Parse the line into a key-value pair, store it in m_propertyBundle, and check whether the key matches propertyKey (DP-006).
FALSE: Skip the line; it does not represent a valid property entry.

DP-006
Condition: The lowercased, trimmed key parsed from the current line equals the lowercased input propertyKey.
TRUE: Assign the corresponding property value to the result variable.
FALSE: Continue to the next line without updating the result variable.

DP-007
Condition: A NO_DATA_FOUND or SQLCODE -302000 exception is raised and m_registeredPackages.FIRST is null (no bean registered).
TRUE: Invoke WEBUTIL.ERRORALERT to display the appropriate English-language error message (WUC-005 or WUC-006), set m_config_error to TRUE, and return NULL.
FALSE: Delegate error reporting to Webutil_Core.Error, set m_config_error to TRUE, and return NULL.

DP-008
Condition: An exception other than NO_DATA_FOUND or SQLCODE -302000 is raised.
TRUE: Re-raise the exception to the caller.
FALSE: Not applicable (condition is only evaluated in the OTHERS handler).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The configuration file path must be resolvable from exactly one of three sources in strict priority order: (1) Forms global variable WEBUTIL_CONFIG_GLOBAL, (2) environment variable WEBUTIL_CONFIG_ENV, (3) Forms parameter WEBUTIL_CONFIG_PARAM. If none provides a value, processing cannot continue.
- BR-002 - Once the configuration file path is resolved, it must be written back to the Forms global variable WEBUTIL_CONFIG_GLOBAL so that the resolved path is reused on subsequent invocations without repeating the three-source lookup.
- BR-003 - Lines in the configuration file that begin with the '#' character are treated as comments and must be ignored entirely.
- BR-004 - Only lines containing an '=' character are treated as valid property entries; lines without '=' are silently skipped.
- BR-005 - Property keys stored in m_propertyBundle must be lowercased and stripped of leading and trailing whitespace; property values must be stripped of leading and trailing whitespace and carriage-return characters (CHR(13)).
- BR-006 - Key matching against the input propertyKey is case-insensitive; both the stored key and the input parameter are lowercased before comparison.
- BR-007 - When a configuration file path cannot be resolved (NO_DATA_FOUND) or the file cannot be read (SQLCODE -302000), the global error flag m_config_error must be set to TRUE and the function must return NULL.
- BR-008 - When no WebUtil bean is registered (m_registeredPackages.FIRST is null) and a configuration error occurs, the error must be surfaced to the user in English via WEBUTIL.ERRORALERT using the designated error codes WUC-005 (no file specified) or WUC-006 (file unreadable).

---
**Implementation Logic**

```plsql
      
  FUNCTION PopulatePropertyBundle(propertyKey in VARCHAR2) return VARCHAR2 is
    configFile   VARCHAR2(512 char);
    buffer       VARCHAR2(1000 char);
    result       VARCHAR2(1000 char);          
    propertyFile TEXT_IO.FILE_TYPE;
    pos          PLS_INTEGER;
    propIndex    PLS_INTEGER := 0;
  begin
    -- First of get the name of the cfg file 
    -- This could come in a global  or from the Environment
    default_value('[NOTSET]',WEBUTIL_CONFIG_GLOBAL);
    configFile := name_in(WEBUTIL_CONFIG_GLOBAL);
    if configFile = '[NOTSET]' then
      configFile := null; 
      -- Try the environment
      TOOL_ENV.GETVAR(WEBUTIL_CONFIG_ENV, configFile); 
      if configFile is null then 
        -- Finally try the Forms parameters
        configFile := name_in(WEBUTIL_CONFIG_PARAM);
        -- if that fails then we have to raise an error
        if configFile is null then 
          raise NO_DATA_FOUND;
        end if;    
      end if;
    end if;
    
    copy(configFile, WEBUTIL_CONFIG_GLOBAL);
      
    propertyFile := Text_IO.FOpen(configFile,'R');
    LOOP
      begin
        Text_IO.Get_Line(propertyFile,buffer);
      exception
        when NO_DATA_FOUND then EXIT;
      end;
        
      -- ignore lines which start with '#'
      if substr(buffer,1,1) <> '#' then 
        pos := instr(buffer,'=');
        -- only process lines with a name value pair
        if pos > 0 then 
          propIndex := propIndex + 1;
          m_propertyBundle(propIndex).propertyKey   := lower(ltrim(rtrim(substr(buffer,1,pos-1))));    
          m_propertyBundle(propIndex).propertyValue := ltrim(rtrim(replace(substr(buffer,pos+1),chr(13),'')));
          -- Check to see if this is the key we are looking for
          if  m_propertyBundle(propIndex).propertyKey = lower(propertyKey) then
            result := m_propertyBundle(propIndex).propertyValue;
          end if;
        end if;
      end if;
    end LOOP;
    Text_IO.FClose(propertyFile);
    return result;
  EXCEPTION
    when NO_DATA_FOUND then 
      if m_registeredPackages.FIRST is null then
        -- There is no bean registered yet. Throw error in English using alert
        ErrorAlert('WUC-005: No WebUtil Configuration File specified');
      else
        Webutil_Core.Error(Webutil_Core.WUC_PACKAGE,5,'WebUtil_Core.PopulatePropertyBundle');
      end if;
      m_config_error := true;
      return null;
    when others then 
      if SQLCODE = '-302000' then
        if m_registeredPackages.FIRST is null then
          -- There is no bean registered yet. Throw error in English using alert
          ErrorAlert('WUC-006: Unable to read WebUtil Configuration File');
        else
          Webutil_Core.Error(Webutil_Core.WUC_PACKAGE,6,'WebUtil_Core.PopulatePropertyBundle', configFile);
        end if;
        m_config_error := true;
        return null;
      else
        RAISE;
      end if;      

  end PopulatePropertyBundle;
```

#### SP-053 - WEBUTIL.PUTF

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a text string to an open client-side file without automatically appending a newline. This allows the form to write partial lines or formatted content to a file on the user's desktop.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |
| arg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Set the file handle on the WebUtil file bean to identify the target file.
- Step 2 - Write the supplied text string to the file via the bean's write property (no newline is appended).
- Step 3 - If the WebUtil bean is not registered, display an alert and raise a tool error; if a property error occurs, raise a tool error.

---
**Decision Points**

No conditional decision points in this routine.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - No newline is appended after the written text; callers must explicitly include newline characters if line-break formatting is required.

---
**Implementation Logic**

```plsql
   
  
  
  procedure putf (file   file_type, 
                  arg    VARCHAR2) is 
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);              
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_PUTF',arg); 
  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.putf will not work');
      RAISE TOOL_ERR.TOOL_ERROR;                                                                 
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE TOOL_ERR.TOOL_ERROR;  
  END putf;
```

#### SP-054 - WEBUTIL.PUT_LINE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a line of text to an open client-side file and automatically appends a newline character. This is the standard mechanism for writing complete lines of data to report or CSV files on the user's desktop.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |
| item | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Set the file handle on the WebUtil file bean to identify the target file.
- Step 2 - Write the supplied text string to the file via the bean's write property.
- Step 3 - Instruct the bean to append a newline character to complete the line.
- Step 4 - If the WebUtil bean is not registered, display an alert and raise a tool error; if a property error occurs, raise a tool error.

---
**Decision Points**

No conditional decision points in this routine.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A newline is always appended after the written text; callers should not include a trailing newline in the item string unless an additional blank line is intended.

---
**Implementation Logic**

```plsql
    

  PROCEDURE put_line (file file_type, item VARCHAR2) is
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);              
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_PUT',item); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_NEWLINE',1); 
  EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.put_line will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;  
  END put_line;
```

#### SP-055 - WEBUTIL.READFROMPROPERTYBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.LOG]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value associated with a given property key from an in-memory property bundle cache. If the bundle has not yet been loaded, it delegates population to WEBUTIL.POPULATEPROPERTYBUNDLE before performing the lookup. The function is used by WEBUTIL.CHECKLIBS, WEBUTIL.LOG, and WEBUTIL.REGISTERBEAN to resolve configuration properties at runtime without repeated file reads.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.POPULATEPROPERTYBUNDLE ([SP-052](#SP-052--WEBUTIL.POPULATEPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input property key (propertyKey) and capture the current count of entries in the in-memory property bundle (m_propertyBundle).
- Step 2 - Check whether a prior configuration error flag (m_config_error) is set; if so, immediately return NULL, bypassing all further processing.
- Step 3 - If no configuration error exists and the property bundle is empty (propCount = 0), delegate to WEBUTIL.POPULATEPROPERTYBUNDLE, passing the requested property key, and assign its return value as the result.
- Step 4 - If the property bundle is already populated (propCount > 0), iterate through all entries in m_propertyBundle, comparing each entry's propertyKey (stored in lowercase) against the lowercase-equivalent of the supplied propertyKey.
- Step 5 - On finding a matching entry, assign the corresponding propertyValue to the result variable and exit the loop immediately.
- Step 6 - Return the resolved property value (or NULL if no match was found or a config error was previously flagged).

---
**Decision Points**

DP-001

Condition: m_config_error flag is TRUE.

TRUE: Return NULL immediately; no further processing is performed.

FALSE: Proceed to evaluate the state of the property bundle cache.

---

DP-002

Condition: The property bundle cache is empty (m_propertyBundle.COUNT = 0).

TRUE: Invoke WEBUTIL.POPULATEPROPERTYBUNDLE with the supplied propertyKey to load the bundle and obtain the result.

FALSE: Search the already-populated bundle for a matching key.

---

DP-003

Condition: During iteration, the current bundle entry's propertyKey matches the lowercase form of the supplied propertyKey.

TRUE: Assign the entry's propertyValue to the result and exit the loop.

FALSE: Continue iterating to the next bundle entry.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - If a configuration error has previously been recorded (m_config_error = TRUE), the function must return NULL without attempting any property lookup or bundle population.
- BR-002 - Property key comparisons are performed in a case-insensitive manner by storing and matching keys in lowercase; callers may supply the key in any case.
- BR-003 - The property bundle is populated on demand: WEBUTIL.POPULATEPROPERTYBUNDLE is called only when the bundle cache contains zero entries, ensuring the configuration file is not read redundantly on subsequent calls.
- BR-004 - The returned property value is limited to a maximum of 1000 characters (VARCHAR2(1000 char)); values exceeding this length cannot be stored or returned.
- BR-005 - If the property bundle is populated but no entry matches the supplied key, the function returns NULL rather than raising an error.

---
**Implementation Logic**

```plsql
  
  FUNCTION ReadFromPropertyBundle(propertyKey in VARCHAR2) return VARCHAR2 is   
    result       VARCHAR2(1000 char);
    propCount    PLS_INTEGER := m_propertyBundle.COUNT;
  begin
    if m_config_error then
      -- already encountered problem reading the config file.
      return null;
    elsif (propCount = 0) then
      result := populatePropertyBundle(propertyKey);
    else
      for i in 1..propCount LOOP
        if m_propertyBundle(i).propertyKey = lower(propertyKey) then 
          result := m_propertyBundle(i).propertyValue;
          EXIT;
        end if;
      end LOOP;
    end if;
    return result;
  end ReadFromPropertyBundle;
```

#### SP-056 - WEBUTIL.READTRANSFROMMSGBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a translated message string from the WebUtil message bundle by composing a lookup key and optional argument string, then delegating the get/set cycle to the WebUtil Core property mechanism. The function is currently used by WEBUTIL.CHECKLIBS to obtain the localised progress bar title.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |
| args | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the message bundle property key (propertyKey) and an optional arguments string (args) as inputs.
- Step 2 - Compose a pipe-delimited lookup value by concatenating propertyKey, a pipe character ('|'), and args.
- Step 3 - Write the composed lookup value to the WebUtil Core property store by calling Webutil_Core.setProperty, targeting the WUC_PACKAGE package context under the property name WUC_TRANS_MSG.
- Step 4 - Immediately retrieve the resolved (translated) message from the same property store by calling Webutil_Core.getProperty with the same WUC_PACKAGE context and WUC_TRANS_MSG property name.
- Step 5 - Return the retrieved translated message string to the caller.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a linear set-then-get sequence unconditionally for every invocation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The args parameter is optional and defaults to NULL; when NULL, the pipe-delimited lookup value is composed as propertyKey concatenated with '|' followed by an empty string.
- BR-002 - The translated message is resolved entirely through the Webutil_Core property mechanism (setProperty / getProperty) using the fixed context WUC_PACKAGE and property name WUC_TRANS_MSG; no direct database or file I/O is performed.
- BR-003 - The function is currently restricted in scope to supporting WEBUTIL.CHECKLIBS, specifically for retrieving the localised progress bar title; use outside this context is not defined.

---
**Implementation Logic**

```plsql
  
  FUNCTION ReadTransFromMsgBundle(propertyKey in VARCHAR2, args in VARCHAR2 := null) return VARCHAR2 is
    -- currently called from checkLibs only for getting progress bar title.
  begin 
    Webutil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_TRANS_MSG', propertyKey||'|'||args);
    return Webutil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_TRANS_MSG');
  end ReadTransFromMsgBundle;
```

#### SP-057 - WEBUTIL.REGISTERBEAN

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a WebUtil client-side bean with the Oracle Forms server-side runtime during session initialisation. On the first bean registration, the procedure captures client environment details (IP address, OS, architecture, username, locale, path and file separators), resolves the system library download directory, logs the connection if configured, and propagates server logging and heartbeat-blocking settings to the client bean. For every bean registration it maps the bean short-name to its internal package constant, records the triggering item, and verifies that all required client-side libraries are present.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| clientInfo | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.CHECKLIBS ([SP-016](#SP-016--WEBUTIL.CHECKLIBS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTSETTING ([SP-031](#SP-031--WEBUTIL.GETCLIENTSETTING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETOSFAMILY ([SP-036](#SP-036--WEBUTIL.GETOSFAMILY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETPROPERTY ([SP-038](#SP-038--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETVAR ([SP-040](#SP-040--WEBUTIL.GETVAR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-051](#SP-051--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-055](#SP-055--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETCLIENTSETTING ([SP-060](#SP-060--WEBUTIL.SETCLIENTSETTING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Extract the bean short-name from the pipe-delimited clientInfo string (position 1) using DelimStr.getString.
- Step 2 - Map the bean short-name ('WUC', 'WUT', 'WUF', 'WUI', 'WUH', 'WUS', 'WUB', 'WUO', 'WUU', 'WUL') to the corresponding WEBUTIL_CORE package-ID constant.
- Step 3 - If the module-level client IP address (m_clientIP) is null, this is the first bean to register; set the checkUserLibs flag to TRUE and parse the remaining clientInfo fields (positions 2-8) to populate m_clientIP, m_clientOS, m_clientOSFamily (via WEBUTIL.GETOSFAMILY), m_clientOSArch (set to 1 when the architecture string contains '64'), m_clientUserName, m_clientPathSep, m_clientFileSep, and m_clientLangCode.
- Step 4 - If the resolved packageID does not already exist in the m_registeredPackages array, store the current SYSTEM.TRIGGER_ITEM value against that packageID and set the newPackage flag to TRUE (only the first instance of each bean type is registered).
- Step 5 - When checkUserLibs is TRUE, reset REDOWNLOAD_SYSLIB to FALSE, then retrieve the server host name by calling WEBUTIL.GETVAR for 'COMPUTERNAME'; if null, fall back to WEBUTIL.GETVAR for 'HOST'.
- Step 6 - Resolve the client system-library directory by calling WEBUTIL.READFROMPROPERTYBUNDLE with the key 'install.syslib.location.client.<OSFamily>.<OSArch>'; if null, retry with the key 'install.syslib.location.client.<OSFamily>'.
- Step 7 - If no client library directory is found in the property bundle, send a WUC_SYSLIB_DIR property to the WUC bean containing only the server host and application config (client JRE handling delegated to the client). If a directory is found, substitute the '$(SERVERHOST)' token with the resolved server host name, send the full WUC_SYSLIB_DIR property, then compare the stored client setting ('install.syslib.dir' via WEBUTIL.GETCLIENTSETTING) with the new directory; if they differ, update the setting via WEBUTIL.SETCLIENTSETTING and set REDOWNLOAD_SYSLIB to TRUE.
- Step 8 - Retrieve and store the WebUtil bean version by calling WEBUTIL.GETPROPERTY for 'WUC_BEAN_VERSION' on the WUC_PACKAGE.
- Step 9 - If the property bundle key 'logging.connections' equals 'true' (case-insensitive), write a connection log entry via WEBUTIL.LOG recording the current form name, client OS, and locale.
- Step 10 - If newPackage is TRUE, call WEBUTIL.CHECKLIBS passing the string representation of the packageID to verify that all required package-specific client libraries are available.
- Step 11 - If checkUserLibs is TRUE, call WEBUTIL.LOG with a null message to initialise the m_loggingAllowed and m_loggingErrorsOnly flags.
- Step 12 - Read the 'BlockAllowHeartBeat' property bundle value; if it equals 'true', 'yes', or '1' (case-insensitive), send WUC_BLOCK_ALLOW_HEART_BEAT = '1' to the client bean for the current packageID; otherwise send '0'.
- Step 13 - Determine the server logging level and send the WUC_SRV_LOGGING property to the client bean: '1' when logging is allowed but errors-only, '2' when full logging is allowed, or '0' when logging is disabled.
- Step 14 - If checkUserLibs is TRUE, call WEBUTIL.CHECKLIBS with the argument 'user' to check for and download any user-defined client libraries.

---
**Decision Points**

DP-001
Condition: beanShortName matches one of the known constants ('WUC', 'WUT', 'WUF', 'WUI', 'WUH', 'WUS', 'WUB', 'WUO', 'WUU', 'WUL').
TRUE: The corresponding WEBUTIL_CORE package-ID constant is assigned to packageID.
FALSE: packageID remains uninitialised; no package mapping is performed.

DP-002
Condition: m_clientIP IS NULL (no bean has been registered yet in this session).
TRUE: checkUserLibs is set to TRUE and client environment fields (IP, OS, OS family, architecture, username, path separator, file separator, language code) are parsed from clientInfo.
FALSE: Client environment fields are not re-parsed; checkUserLibs remains FALSE.

DP-003
Condition: The architecture string extracted from clientInfo contains '64'.
TRUE: m_clientOSArch is set to 1 (64-bit client).
FALSE: m_clientOSArch remains at its default value (not set to 1).

DP-004
Condition: m_registeredPackages does NOT already contain an entry for packageID.
TRUE: The current SYSTEM.TRIGGER_ITEM is stored in m_registeredPackages for packageID and newPackage is set to TRUE.
FALSE: The existing registration is preserved; newPackage remains FALSE.

DP-005
Condition: The server host name returned by WEBUTIL.GETVAR('COMPUTERNAME') IS NULL.
TRUE: WEBUTIL.GETVAR('HOST') is called as a fallback to obtain the server host name.
FALSE: The value from 'COMPUTERNAME' is used as the server host name.

DP-006
Condition: WEBUTIL.READFROMPROPERTYBUNDLE returns a non-null value for the OS-family-and-architecture-specific key ('install.syslib.location.client.<OSFamily>.<OSArch>').
TRUE: clientLibDir is set to that value.
FALSE: A second lookup is attempted using the OS-family-only key ('install.syslib.location.client.<OSFamily>').

DP-007
Condition: clientLibDir IS NULL after both property bundle lookups.
TRUE: WUC_SYSLIB_DIR is sent to the WUC bean containing only ':serverHost:CONFIG', delegating client directory resolution to the client JRE.
FALSE: The resolved directory is used; the '$(SERVERHOST)' token is replaced and WUC_SYSLIB_DIR is sent with the full path.

DP-008
Condition: The previously stored client library directory (from WEBUTIL.GETCLIENTSETTING) differs from the newly resolved clientLibDir.
TRUE: WEBUTIL.SETCLIENTSETTING updates 'install.syslib.dir' and REDOWNLOAD_SYSLIB is set to TRUE.
FALSE: No update is made; REDOWNLOAD_SYSLIB remains FALSE.

DP-009
Condition: WEBUTIL.READFROMPROPERTYBUNDLE('logging.connections') equals 'true' (case-insensitive).
TRUE: WEBUTIL.LOG records a connection entry containing the form name, client OS, and locale.
FALSE: No connection log entry is written.

DP-010
Condition: newPackage is TRUE.
TRUE: WEBUTIL.CHECKLIBS is called with the string representation of packageID to verify package-specific client libraries.
FALSE: Library check for this package is skipped.

DP-011
Condition: blockAllowHeartBeat (lower-cased) equals 'true', 'yes', or '1'.
TRUE: WUC_BLOCK_ALLOW_HEART_BEAT is sent as '1' to the client bean, instructing it to block heartbeat allowance.
FALSE: WUC_BLOCK_ALLOW_HEART_BEAT is sent as '0'.

DP-012
Condition: m_loggingAllowed is TRUE AND m_loggingErrorsOnly is TRUE.
TRUE: WUC_SRV_LOGGING is sent as '1' (errors-only logging).
FALSE: Evaluation continues to DP-013.

DP-013
Condition: m_loggingAllowed is TRUE (and m_loggingErrorsOnly is FALSE).
TRUE: WUC_SRV_LOGGING is sent as '2' (full logging).
FALSE: WUC_SRV_LOGGING is sent as '0' (logging disabled).

DP-014
Condition: checkUserLibs is TRUE (evaluated after the newPackage library check).
TRUE: WEBUTIL.CHECKLIBS is called with 'user' to check and download user-defined client libraries.
FALSE: User library check is skipped.

---
**Database Interactions**

- DB-001 - Update THIS - Updates existing rows in THIS.
**Business Rules**

- BR-001 - The bean short-name extracted from clientInfo must match one of the ten recognised constants (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL); only matching beans are mapped to a package ID and processed further.
- BR-002 - Client environment information (IP, OS, architecture, username, separators, locale) is captured exactly once per session; subsequent bean registrations within the same session do not overwrite these values.
- BR-003 - Only the first instance of each bean type is registered; if the same bean type appears multiple times (e.g. in a multi-row block), only the first occurrence is recorded in m_registeredPackages.
- BR-004 - The system library download directory is resolved in priority order: OS-family-and-architecture-specific key first, OS-family-only key second, and client JRE default last; the most specific available configuration takes precedence.
- BR-005 - The '$(SERVERHOST)' token within a configured client library directory must be substituted with the runtime server host name before the directory path is transmitted to the client.
- BR-006 - If the resolved client system-library directory differs from the previously stored client setting, the setting is updated and the REDOWNLOAD_SYSLIB flag is set to TRUE to trigger a re-download of system libraries.
- BR-007 - Connection logging is conditional; a log entry is written only when the 'logging.connections' property bundle key is explicitly set to 'true'.
- BR-008 - The heartbeat-blocking instruction sent to the client bean is controlled by the 'BlockAllowHeartBeat' configuration property; accepted truthy values are 'true', 'yes', and '1' (case-insensitive).
- BR-009 - Server-side logging state (m_loggingAllowed, m_loggingErrorsOnly) must be communicated to each registering client bean via the WUC_SRV_LOGGING property so that the bean avoids unnecessary round-trips to the server.
- BR-010 - User-defined client library verification (WEBUTIL.CHECKLIBS with 'user') is performed only once per session and only after at least one bean has been registered, ensuring a handler bean exists to perform any required download.

---
**Implementation Logic**

```plsql
  PROCEDURE registerBean(clientInfo in VARCHAR2) is  
    packageID       PLS_INTEGER;
    beanShortName   VARCHAR2(3 char);
    newPackage      BOOLEAN := false;
    checkUserLibs   BOOLEAN := false;
    clientLibDir    VARCHAR2(1000 char);
    clientLibDirOld VARCHAR2(1000 char);
    serverHost      VARCHAR2(100 char);
    blockAllowHeartBeat VARCHAR2(10 char);
    clientOSArch    VARCHAR2(30 char);
  begin
    beanShortName := DelimStr.getString(clientInfo,1,true,'|');

    -- To speed access up we crossmatch the Bean Name string
    -- with a constant - this constant is used to access the 
    -- registered package array efficently
    -- need to update this IF statement as we add new packages
    if beanShortName = 'WUC' then
       packageID := WEBUTIL_CORE.WUC_PACKAGE; 
    elsif beanShortName = 'WUT' then     
       packageID := WEBUTIL_CORE.WUT_PACKAGE; 
    elsif beanShortName = 'WUF' then 
       packageID := WEBUTIL_CORE.WUF_PACKAGE; 
    elsif beanShortName = 'WUI' then
        packageID := WEBUTIL_CORE.WUI_PACKAGE; 
    elsif beanShortName = 'WUH' then            
       packageID := WEBUTIL_CORE.WUH_PACKAGE;
    elsif beanShortName = 'WUS' then     
       packageID := WEBUTIL_CORE.WUS_PACKAGE;
    elsif beanShortName = 'WUB' then 
       packageID := WEBUTIL_CORE.WUB_PACKAGE;
    elsif beanShortName = 'WUO' then     
       packageID := WEBUTIL_CORE.WUO_PACKAGE;
    elsif beanShortName = 'WUU' then     
       packageID := WEBUTIL_CORE.WUU_PACKAGE;
    elsif beanShortName = 'WUL' then     
       packageID := WEBUTIL_CORE.WUL_PACKAGE;           
    end if;
    -- For the very first bean we can get a bit of useful information
    -- Only do this once
    if m_clientIP is null then 
      checkUserLibs := true;
      -- Format of the clientinfo packet is
      -- BeanName|IP|OSName|UserName|pathSep|filesep
      m_clientIP       := DelimStr.getString(clientInfo,2,true,'|');
      m_clientOS       := DelimStr.getString(clientInfo,3,true,'|');
      m_clientOSFamily := getOSFamily(m_clientOS);
      clientOSArch     := DelimStr.getString(clientInfo,4,true,'|');
      if instr(clientOSArch, '64') > 0 then
        m_clientOSArch := 1;
      end if;
      m_clientUserName := DelimStr.getString(clientInfo,5,true,'|');      
      m_clientPathSep  := DelimStr.getString(clientInfo,6,true,'|');
      m_clientFileSep  := DelimStr.getString(clientInfo,7,true,'|');
      m_clientLangCode := DelimStr.getString(clientInfo,8,true,'|'); 
    end if;
      
    -- I'd only expect one instance of each bean per form
    -- but just in case we only register the first 
    -- so if multiple copies are used - e.g. it's 
    -- placed in a multi-row block we just use the 
    -- first instance.
    if not m_registeredPackages.EXISTS(packageID) then 
      m_registeredPackages(packageID) := name_in('SYSTEM.TRIGGER_ITEM');
      -- make sure all the required libraries are available
      -- on the client
      newPackage := true;
    end if;
      
    if checkUserLibs then
      -- checkUserLibs would be true if clientIP was null
      -- We can do whatever we want to do but not more than once
      REDOWNLOAD_SYSLIB := FALSE;
      -- We need to get the server host name using available built-ins. This looks lame,
      -- but it should work
      TOOL_ENV.GETVAR('COMPUTERNAME', serverHost);
      if serverHost is null then
        TOOL_ENV.GETVAR('HOST', serverHost);
      end if;
      clientLibDir := readFromPropertyBundle('install.syslib.location.client.'||to_char(m_clientOSFamily) ||
                                             '.' || to_char(m_clientOSArch));
      if clientLibDir is null then
        clientLibDir := readFromPropertyBundle('install.syslib.location.client.'||to_char(m_clientOSFamily));
      end if;
      if clientLibDir is null then
        -- client location when syslib download is not defined in webutil.cfg
        -- will be to client JRE. Send nothing and client will handle
        WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SYSLIB_DIR',
                                 ':' || serverHost || ':' || GET_APPLICATION_PROPERTY(CONFIG),
                                 true);
      else
        -- webutil.cfg contains a specific client directory for syslib download
        -- Replace $(SERVERHOST), if exists, with server host name
        clientLibDir := replace(clientLibDir, '$(SERVERHOST)', serverHost);

        -- The following line makes a few things happen on client including
        -- client directory creation, when clientLibDir is not null
        WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SYSLIB_DIR',
                                 clientLibDir || ':' || serverHost || ':' || GET_APPLICATION_PROPERTY(CONFIG),
                                 true);
        clientLibDirOld := GetClientSetting('install.syslib.dir');

        if clientLibDirOld <> clientLibDir then
    	  SetClientSetting('install.syslib.dir', clientLibDir);
          REDOWNLOAD_SYSLIB := TRUE;
    	end if;
      end if;
      Webutil_Core.WEBUTIL_VERSION := getProperty(WUC_PACKAGE,'WUC_BEAN_VERSION');
      -- We want to write the connection record if it's required.
      -- Any call to ReadFromPropertyBundle or log should be preferably made after
      -- registering at least one bean. That is the reason why the following log
      -- comes after m_registeredPackages(packageID) := name_in('SYSTEM.TRIGGER_ITEM'); above
      if lower(ReadFromPropertyBundle('logging.connections')) = 'true' then 
        log('Connection from Form='||GET_APPLICATION_PROPERTY(CURRENT_FORM)||' Client O/S='||m_clientOS||' locale='||m_clientLangCode,false);
      end if;
    end if;
    if newPackage then  
            checkLibs(to_char(packageID));
    end if;

    if checkUserLibs then
      -- Call a dummy log to initialize m_loggingAllowed and m_loggingErrorsOnly
      log(null,false);
    end if;

    -- 5950737 - Introduce new configuration variable BlockAllowHeartBeat. 
    -- Valid values are true, yes and 1.
    -- If this is set then send a message to the client to behave accordingly.    
    blockAllowHeartBeat := lower(ReadFromPropertyBundle('BlockAllowHeartBeat'));
    if blockAllowHeartBeat = 'true' or blockAllowHeartBeat = 'yes' or blockAllowHeartBeat = '1' then 
      WebUtil_Core.setProperty(packageID,'WUC_BLOCK_ALLOW_HEART_BEAT','1',true);
    else
      WebUtil_Core.setProperty(packageID,'WUC_BLOCK_ALLOW_HEART_BEAT','0',true);
    end if;

    -- Send server logging options to client bean so that the bean does not have
    -- to send message to server unnecessarily.
    if m_loggingAllowed and m_loggingErrorsOnly then
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','1',true);
    elsif m_loggingAllowed then
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','2',true);
    else
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','0',true);
    end if;
      
    -- 2836929 - move the user library check after the first package is registered 
    -- so that a handler bean exists to do the download.     
    if checkUserLibs then 
      --Check for and download any user libs
      checkLibs('user');  
    end if;     
  end registerBean;
```

#### SP-058 - WEBUTIL.REGISTER_FUNCTION

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a DLL function with the WebUtil C-API layer by providing the library name and function name, and returns a handle that can be used to call the function. If the registration is successful, the global function-handle count is incremented.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| libName | VARCHAR2 | IN |
| funcName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-045](#SP-045--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Combine the library name and function name into a pipe-separated specification string and pass it to the WebUtil library bean.
- Step 2 - Retrieve the string handle returned by the bean and convert it to a numeric function handle.
- Step 3 - If the resulting handle is non-null, increment the global function-handle count.
- Step 4 - Return the function handle to the caller.
- Step 5 - If the WebUtil bean is not registered, display an alert and raise FORM_TRIGGER_FAILURE; if a property error occurs, raise FORM_TRIGGER_FAILURE; if a value conversion error occurs, raise a tool error.

---
**Decision Points**

DP-001

Condition:
Whether the returned function handle is non-null (registration was successful).

TRUE:
Increment the global function-handle counter.

FALSE:
Return the null handle without incrementing the counter.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function specification sent to the bean is always formatted as "library_name|function_name".
- BR-002 - If the bean is not available on the client, form processing is halted immediately.

---
**Implementation Logic**

```plsql

  FUNCTION REGISTER_FUNCTION (libName IN VARCHAR2, funcName IN VARCHAR2) 
                              RETURN FunctionHandle IS
    strHnd  VARCHAR2(8);                            
    funcHnd FunctionHandle;
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUL_PACKAGE,'WUL_FUNCTION_SPEC', libName || '|' || funcName);
    strHnd := WebUtil_Core.getProperty(WebUtil_Core.WUL_PACKAGE,'WUL_REGISTER_FUNCTION');
    funcHnd.hnd := TO_NUMBER (strHnd);
    if NOT ID_NULL(funcHnd) then
      m_funcHandleCount := m_funcHandleCount + 1;
    end if;

    RETURN funcHnd;
    
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUL_PACKAGE)
                              ||' bean not found. WEBUTIL_C_API.REGISTER_FUNCTION will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;  
    when VALUE_ERROR then
        RAISE TOOL_ERR.TOOL_ERROR; 
  END REGISTER_FUNCTION;
```

#### SP-059 - WEBUTIL.RELEASE_PROCESS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.HOST]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Releases a completed host process handle from client-side memory by instructing the WebUtil core bean to clear the process reference, removing the associated callback trigger registration, and nullifying the local process identifier. This ensures that client resources are not leaked after a process completes.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Instruct the WebUtil core bean to clear the process reference by setting the WUH_CLEAR_PROC property with the current process handle value.
- Step 2 - Remove the associated callback trigger registration via WebUtil_Core.ClearCallbackTrigger, using the process handle as the key.
- Step 3 - Set the process handle to null to mark the process as released and prevent further use of the stale handle.
- Step 4 - If the WebUtil bean is not registered, catch the BEAN_NOT_REGISTERED exception and display an error alert identifying the missing bean class; execution then ends without propagating an exception to the caller.

---
**Decision Points**

DP-001

Condition: The WebUtil core bean identified by WUH_PACKAGE is registered and reachable when the procedure executes.

TRUE: Steps 1-3 complete normally; the process handle is cleared and nullified.

FALSE: A BEAN_NOT_REGISTERED exception is raised; an error alert is displayed to the user stating that the bean was not found and that WEBUTIL_HOST.Release_Process will not work, and the handle is not modified.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - After this routine completes successfully, the process handle is always null; any subsequent use of the handle by the caller will be treated as an uninitialised handle.
- BR-002 - Both the property clear (WUH_CLEAR_PROC) and the callback trigger removal must be performed in sequence against the same handle value before the handle is nullified, ensuring no orphaned registrations remain on the client.
- BR-003 - If the WebUtil bean is not registered, an error alert is displayed but no exception propagates to the caller; the process handle retains its pre-call value in this error path.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Release_Process(process in out PROCESS_ID) is  
  begin
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_CLEAR_PROC',process.handle);
    WebUtil_Core.ClearCallbackTrigger(process.handle);
    process.handle := null;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.Release_Process will not work');
  end Release_Process;
```

#### SP-060 - WEBUTIL.SETCLIENTSETTING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Transmits a named configuration property and its value to the WebUtil client-side bean by delegating to WebUtil_Core.setProperty. The procedure allows Oracle Forms to push local client settings (identified by a property name/value pair) to the WebUtil Core package at runtime, enabling client-environment configuration without direct database interaction.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyName | VARCHAR2 | IN |
| propertyValue | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the property name (propertyName) and property value (propertyValue) as input parameters.
- Step 2 - Evaluate whether propertyName is not null; only a non-null property name constitutes a valid setting request.
- Step 3 - If propertyName is not null, invoke WebUtil_Core.setProperty passing the constant WebUtil_Core.WUC_PACKAGE as the target package identifier, the constant WebUtil_Core.WUC_SET_LOCAL_PROPERTY as the action identifier, and the concatenated string propertyName||'='||propertyValue as the property payload.
- Step 4 - If the WebUtil_Core bean is not registered at the time of the call (exception WebUtil_Core.BEAN_NOT_REGISTERED), display an error alert identifying the missing bean class via WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE) and raise FORM_TRIGGER_FAILURE to halt form processing.
- Step 5 - If a property error occurs during the setProperty call (exception WebUtil_Core.PROPERTY_ERROR), raise FORM_TRIGGER_FAILURE to halt form processing without an additional alert.

---
**Decision Points**

DP-001

Condition: propertyName IS NOT NULL

TRUE: Call WebUtil_Core.setProperty with WUC_PACKAGE, WUC_SET_LOCAL_PROPERTY, and the concatenated propertyName||'='||propertyValue payload to apply the client setting.

FALSE: Skip the setProperty call entirely; the procedure exits without performing any action and without raising an error.

DP-002

Condition: WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during setProperty execution

TRUE: Display an error alert identifying the unregistered bean class (retrieved via WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)) and raise FORM_TRIGGER_FAILURE to abort the current form trigger.

FALSE: No BEAN_NOT_REGISTERED exception; processing continues normally.

DP-003

Condition: WebUtil_Core.PROPERTY_ERROR exception is raised during setProperty execution

TRUE: Raise FORM_TRIGGER_FAILURE silently to abort the current form trigger without displaying an additional alert.

FALSE: No PROPERTY_ERROR exception; processing completes successfully.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A client setting will only be transmitted to the WebUtil Core bean if propertyName is not null; a null property name causes the procedure to exit silently with no action taken.
- BR-002 - The property payload delivered to WebUtil_Core.setProperty must be formatted as a single string in the form propertyName||'='||propertyValue; no other format is permitted.
- BR-003 - The target package and action identifiers passed to WebUtil_Core.setProperty are fixed constants (WebUtil_Core.WUC_PACKAGE and WebUtil_Core.WUC_SET_LOCAL_PROPERTY respectively) and must not be substituted with arbitrary values.
- BR-004 - If the WebUtil Core bean is not registered when this procedure executes, the form trigger must be aborted via FORM_TRIGGER_FAILURE after presenting a descriptive error alert; silent failure is not permitted in this scenario.
- BR-005 - If a property error is returned by WebUtil_Core.setProperty, the form trigger must be aborted via FORM_TRIGGER_FAILURE; no user-facing alert is raised for this condition.

---
**Implementation Logic**

```plsql

  PROCEDURE SetClientSetting(propertyName  in VARCHAR2,
                             propertyValue in VARCHAR2) is
  BEGIN
    if propertyName is not null then 
      WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SET_LOCAL_PROPERTY', propertyName||'='||propertyValue);
    end if;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                              ||' bean not found. WEBUTIL_CORE.SetClientSetting will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;       
  END SetClientSetting;
```

#### SP-061 - WEBUTIL.SETDATA

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.SETDATA receives a single chunk of upload data (as a VARCHAR2 string) and writes it to the appropriate server-side destination - either a database BLOB or a file on the application server - as part of a multi-chunk file-upload sequence. When the final chunk is received, the procedure closes the target resource, marks the upload as succeeded or failed, fires any registered callback trigger, and clears that trigger registration.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| uploadData | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.CLEARCALLBACKTRIGGER ([SP-017](#SP-017--WEBUTIL.CLEARCALLBACKTRIGGER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.CLOSEBLOB ([SP-018](#SP-018--WEBUTIL.CLOSEBLOB)) - WEBUTIL.pck (or .pld)
- WEBUTIL.CLOSEFILE ([SP-019](#SP-019--WEBUTIL.CLOSEFILE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCALLBACKTRIGGER ([SP-029](#SP-029--WEBUTIL.GETCALLBACKTRIGGER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETLASTERROR ([SP-033](#SP-033--WEBUTIL.GETLASTERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETLASTERRORARGS ([SP-034](#SP-034--WEBUTIL.GETLASTERRORARGS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.WRITEDATA ([SP-065](#SP-065--WEBUTIL.WRITEDATA)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Validate the incoming chunk: if uploadData is NULL or empty, set the internal upload-success flag (m_uploadSucceeded) to FALSE and treat the call as an error condition; no further processing occurs.
- Step 2 - Determine the write destination: evaluate the internal flag m_toDB to decide whether data should be written to a database BLOB (TRUE) or to a file on the application server via a Java writer (FALSE).
- Step 3a (DB path) - Write the data chunk to the database by calling WebUtil_DB_LOCAL.WriteData, passing uploadData.
- Step 3b (File path) - Write the data chunk to the application-server file by calling JAVA_APPSERV_WRITER.WriteData. If the write fails, retrieve the error code via JAVA_APPSERV_WRITER.getLastError and the error arguments via JAVA_APPSERV_WRITER.getLastErrorArgs, log the error through WebUtil_Core.Error, and raise the READWRITE_ERROR exception, halting further processing.
- Step 4 - Decrement the remaining-chunk counter (m_chunks) by 1.
- Step 5 - If m_chunks reaches 0 (i.e., all expected chunks have been received), proceed to close the target resource.
- Step 6a (DB close) - Call WebUtil_DB_Local.CloseBlob, passing the expected file size (m_fileSize). If successful, set m_uploadSucceeded to TRUE; otherwise retrieve the last error via WebUtil_DB_Local.getLastError and log it through WebUtil_Core.Error.
- Step 6b (File close) - Call JAVA_APPSERV_WRITER.CloseFile, passing the persistent object reference (m_persistObj) and m_fileSize. If successful, set m_uploadSucceeded to TRUE; otherwise retrieve the error code and arguments, log the error through WebUtil_Core.Error, release the Java global reference via ORA_JAVA.DELETE_GLOBAL_REF, and raise READWRITE_ERROR.
- Step 7 - After the resource is closed, check whether a callback trigger is registered by calling WEBUTIL.GETCALLBACKTRIGGER(-1). If a trigger name is returned (non-NULL), execute it via EXECUTE_TRIGGER.
- Step 8 - Unconditionally clear the callback trigger registration by calling WEBUTIL.CLEARCALLBACKTRIGGER(-1), regardless of whether a trigger was fired.

---
**Decision Points**

DP-001
Condition: uploadData IS NULL or uploadData = ''
TRUE: Set m_uploadSucceeded to FALSE and exit the procedure without writing any data.
FALSE: Proceed to determine the write destination and write the chunk.

DP-002
Condition: m_toDB is TRUE
TRUE: Write the chunk to the database BLOB via WebUtil_DB_LOCAL.WriteData.
FALSE: Write the chunk to the application-server file via JAVA_APPSERV_WRITER.WriteData.

DP-003
Condition: JAVA_APPSERV_WRITER.WriteData returns FALSE (file-path write failure)
TRUE: Retrieve error details, log the error via WebUtil_Core.Error, and raise READWRITE_ERROR.
FALSE: Continue processing (decrement chunk counter).

DP-004
Condition: m_chunks equals 0 after decrement (all chunks received)
TRUE: Proceed to close the target resource (BLOB or file) and handle post-upload logic.
FALSE: Return without closing; await the next chunk.

DP-005
Condition: m_toDB is TRUE at the point of resource closure
TRUE: Close the BLOB via WebUtil_DB_Local.CloseBlob.
FALSE: Close the file via JAVA_APPSERV_WRITER.CloseFile.

DP-006
Condition: WebUtil_DB_Local.CloseBlob returns TRUE (DB-path close)
TRUE: Set m_uploadSucceeded to TRUE.
FALSE: Retrieve and log the last error via WebUtil_Core.Error; m_uploadSucceeded remains FALSE.

DP-007
Condition: JAVA_APPSERV_WRITER.CloseFile returns TRUE (file-path close)
TRUE: Set m_uploadSucceeded to TRUE.
FALSE: Retrieve error details, log the error via WebUtil_Core.Error, delete the Java global reference, and raise READWRITE_ERROR.

DP-008
Condition: WEBUTIL.GETCALLBACKTRIGGER(-1) returns a non-NULL trigger name
TRUE: Execute the registered callback trigger via EXECUTE_TRIGGER.
FALSE: Skip trigger execution; proceed directly to clearing the callback trigger registration.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A NULL or empty uploadData value is treated as an error condition; the upload-success flag is set to FALSE and no data is written or appended to the target resource.
- BR-002 - The write destination (database BLOB vs. application-server file) is determined solely by the pre-set internal flag m_toDB; the procedure does not negotiate or detect the destination at runtime.
- BR-003 - Any failure during the application-server file write (JAVA_APPSERV_WRITER.WriteData returning FALSE) must be logged with both an error code and error arguments before raising READWRITE_ERROR; partial writes are not silently ignored.
- BR-004 - The chunk counter (m_chunks) must reach exactly zero before the target resource is closed; resource closure is not triggered by individual chunk success alone.
- BR-005 - On final-chunk processing, the target resource (BLOB or file) must be closed with the expected total file size (m_fileSize); the upload is only marked as succeeded if the close operation itself confirms success.
- BR-006 - A failed file-path close must result in the Java global reference being explicitly released (ORA_JAVA.DELETE_GLOBAL_REF) before READWRITE_ERROR is raised, preventing resource leaks.
- BR-007 - The callback trigger registered against index -1 is always cleared via WEBUTIL.CLEARCALLBACKTRIGGER after final-chunk processing, regardless of whether the trigger was executed or whether the close operation succeeded.
- BR-008 - The callback trigger is executed only when all chunks have been received and the target resource has been closed; it is not fired on intermediate chunk writes.

---
**Implementation Logic**

```plsql
   
  PROCEDURE SetData(uploadData in VARCHAR2) is 
    lastErrorCode    PLS_INTEGER;
    lastErrorArgs    VARCHAR2(1000);   
  BEGIN
    if uploadData is null or uploadData = '' then 
      -- error condition!
      m_uploadSucceeded := false;
    else
      -- Write to the correct place    
      if m_toDB then 
        WebUtil_DB_LOCAL.WriteData(uploadData);
      else
        if not JAVA_APPSERV_WRITER.WriteData(m_persistObj,uploadData) then
          lastErrorCode := JAVA_APPSERV_WRITER.getLastError(m_persistObj);
          lastErrorArgs := JAVA_APPSERV_WRITER.getLastErrorArgs(m_persistObj) ;
          WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                             'WEBUTIL_FILE_TRANSFER.SetData',lastErrorArgs);
          raise READWRITE_ERROR;
        end if;
      end if;
      m_chunks := m_chunks - 1;
      if m_chunks = 0 then 
        if m_toDB then 
          if WebUtil_DB_Local.CloseBlob(m_fileSize) then 
            m_uploadSucceeded := true;
          else
            WebUtil_core.Error(Webutil_Core.WUT_PACKAGE, WebUtil_DB_Local.getLastError,
                               'WEBUTIL_FILE_TRANSFER.SetData');
          end if; -- close
        else
          if JAVA_APPSERV_WRITER.CloseFile(m_persistObj,m_fileSize) then
            m_uploadSucceeded := true;
          else
            lastErrorCode := JAVA_APPSERV_WRITER.getLastError(m_persistObj);
            lastErrorArgs := JAVA_APPSERV_WRITER.getLastErrorArgs(m_persistObj) ;
            WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                               'WEBUTIL_FILE_TRANSFER.SetData',lastErrorArgs);
            ORA_JAVA.DELETE_GLOBAL_REF(m_persistObj);
            raise READWRITE_ERROR;
          end if;    
        end if; -- toDB

        if WebUtil_Core.GetCallbackTrigger(-1) is not null then
          EXECUTE_TRIGGER(WebUtil_Core.GetCallbackTrigger(-1));
        end if;
        WebUtil_Core.ClearCallbackTrigger(-1);
      end if; -- chunks
    end if;
  end SetData;
```

#### SP-062 - WEBUTIL.SETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sets a named Java system property to a given value in the client JVM and returns the previous value of that property. This allows the form to configure runtime Java environment settings on the client machine.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |
| a1 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the property name and the new value to assign.
- Step 2 - Call the Java System.setProperty method on the client JVM via JNI with both the property name and the new value as arguments.
- Step 3 - Return the previous value of the property (as returned by the Java runtime).

---
**Decision Points**

No conditional decision points in this routine.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The property name and value are passed directly to the Java runtime without validation or transformation.
- BR-002 - The previous value of the property is returned; callers can use this to restore the original setting if needed.

---
**Implementation Logic**

```plsql
  FUNCTION setProperty(
    a0    VARCHAR2,
    a1    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(2);
    JNI.ADD_STRING_ARG(args, a0);
    JNI.ADD_STRING_ARG(args, a1);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'setProperty', '(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-063 - WEBUTIL.SHOWBEANS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.INITWEBUTIL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Controls the visibility of the hidden WebUtil window (WEBUTIL_HIDDEN_WINDOW) by either displaying or concealing it based on the supplied boolean flag. When showing the window, the procedure captures the current cursor item so that focus can be restored when the window is subsequently hidden. This procedure is only active when the form is in NORMAL mode, preventing interference during Enter Query operations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| show | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-045](#SP-045--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the boolean parameter 'show', which determines whether the WebUtil hidden window should be displayed or hidden.
- Step 2 - Locate the hidden WebUtil window handle by calling FIND_WINDOW with the constant WEBUTIL_HIDDEN_WINDOW.
- Step 3 - Check whether the form is currently in NORMAL system mode; if the form is in Enter Query mode, all subsequent processing is skipped entirely.
- Step 4 - Verify that the window handle is valid (not null) by calling WEBUTIL.ID_NULL; if the handle is null, no further action is taken.
- Step 5 - If 'show' is TRUE: capture the current cursor item by calling FIND_ITEM against SYSTEM.CURSOR_ITEM and store it in the module-level variable m_infoFrom; set the window title to 'WebUtil ' concatenated with WEBUTIL_VERSION; display the window using SHOW_WINDOW; then navigate focus to WEBUTIL_DUMMY_ITEM.
- Step 6 - If 'show' is FALSE: check whether m_infoFrom holds a valid item reference using WEBUTIL.ID_NULL; if valid, navigate focus back to that item using GO_ITEM; then hide the window using HIDE_WINDOW.

---
**Decision Points**

DP-001

Condition: SYSTEM.MODE equals 'NORMAL'.

TRUE: Proceed to evaluate the window handle and perform show/hide logic.

FALSE: Exit the procedure immediately without modifying window state or focus, preserving Enter Query mode integrity.

---

DP-002

Condition: The window handle returned by FIND_WINDOW for WEBUTIL_HIDDEN_WINDOW is not null (evaluated via WEBUTIL.ID_NULL).

TRUE: Proceed to evaluate the 'show' flag and act on the window.

FALSE: Exit without performing any window or focus operations.

---

DP-003

Condition: The input parameter 'show' is TRUE.

TRUE: Capture the current cursor item into m_infoFrom, set the window title, display the window, and move focus to WEBUTIL_DUMMY_ITEM.

FALSE: Evaluate whether m_infoFrom is a valid item reference and, if so, restore focus to it, then hide the window.

---

DP-004

Condition: When hiding the window ('show' is FALSE), the stored item reference m_infoFrom is not null (evaluated via WEBUTIL.ID_NULL).

TRUE: Navigate focus back to the item stored in m_infoFrom before hiding the window.

FALSE: Skip focus restoration and proceed directly to hiding the window.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must not execute any window visibility or focus changes when the form is in Enter Query mode; only NORMAL mode permits window state modifications.
- BR-002 - The WebUtil hidden window must have a valid (non-null) handle before any show or hide operation is attempted; an unresolvable window reference causes the procedure to abort silently.
- BR-003 - When displaying the WebUtil window, the originating cursor item must be captured and stored in m_infoFrom prior to transferring focus, ensuring accurate focus restoration when the window is later hidden.
- BR-004 - The WebUtil hidden window title must be set to the string 'WebUtil ' concatenated with the WEBUTIL_VERSION constant each time the window is shown, keeping the displayed version label current.
- BR-005 - Focus restoration to the original cursor item upon hiding the window is conditional; if m_infoFrom does not hold a valid item reference, focus restoration is skipped and the window is hidden without a GO_ITEM call.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ShowBeans(show BOOLEAN) is
    hWin WINDOW := FIND_WINDOW(WEBUTIL_HIDDEN_WINDOW);
  begin
    -- Bug 2955789 - don't attempt to do this when in Enter Query Mode
    if name_in('SYSTEM.MODE') = 'NORMAL' then 
      if not ID_NULL(hWin) then 
        if show then 
          m_infoFrom := FIND_ITEM(name_in('SYSTEM.CURSOR_ITEM'));
          SET_WINDOW_PROPERTY(hWin,TITLE,'WebUtil '||WEBUTIL_VERSION);
          SHOW_WINDOW(hWin);
          go_item(WEBUTIL_DUMMY_ITEM);
        else
          if not id_null(m_infoFrom) then 
              go_item(m_infoFrom);
          end if;
          HIDE_WINDOW(hWin);
        end if;
      end if;
    end if;
  end ShowBeans;
```

#### SP-064 - WEBUTIL.URL_TO_CLIENT

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Downloads a file from a server URL to the user's client machine. This is a public-facing convenience wrapper around the internal WebUtil download mechanism and is used by the report generation routine to deliver generated files to the user's desktop.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| fileSize | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.DOWNLOADFROMURL ([SP-020](#SP-020--WEBUTIL.DOWNLOADFROMURL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the source URL, client destination path, and optional file size.
- Step 2 - Delegate to the DownLoadFromURL function and return its boolean result.

---
**Decision Points**

No conditional decision points in this routine.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is a thin wrapper with no additional logic; all business rules are enforced by the underlying DownLoadFromURL function.
- BR-002 - The boolean return value indicates whether the download succeeded (TRUE) or failed (FALSE).

---
**Implementation Logic**

```plsql
  FUNCTION URL_To_Client(sourceURL         in VARCHAR2, 
                         clientDestination in VARCHAR2, 
                         fileSize          in PLS_INTEGER default 0) return BOOLEAN is
  BEGIN
      return WebUtil_Core.DownLoadFromURL(sourceURL, 
                                        clientDestination, 
                                        fileSize);
  END URL_To_Client;
```

#### SP-065 - WEBUTIL.WRITEDATA

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Passes a string data payload to the Java-layer AppServerFileWriter class on the application server by invoking its WriteData method via the JNI bridge. The function returns a Boolean indicating whether the write operation succeeded, and is called exclusively by WEBUTIL.SETDATA to perform the underlying file-write action.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the target Java object reference (obj) representing an active AppServerFileWriter instance, and the string data payload (a0) to be written.
- Step 2 - Create a JNI argument list sized for one argument using JNI.CREATE_ARG_LIST(1).
- Step 3 - Append the string data payload (a0) to the argument list using JNI.ADD_STRING_ARG.
- Step 4 - Invoke the Java method WriteData on the AppServerFileWriter class via JNI.CALL_BOOLEAN_METHOD, passing the assembled argument list and specifying the method signature '(Ljava/lang/String;)Z'.
- Step 5 - Return the Boolean result from the JNI call to the caller (WEBUTIL.SETDATA), indicating success (TRUE) or failure (FALSE) of the write operation.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function unconditionally constructs the argument list, delegates execution to the Java AppServerFileWriter.WriteData method via JNI, and returns the Boolean result as received.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The data payload must be supplied as a VARCHAR2 string (a0); the function accepts exactly one string argument, enforced by the JNI argument list being created with a fixed size of 1.
- BR-002 - The Java object reference (obj) must represent a valid, pre-instantiated AppServerFileWriter instance; the function does not create or validate the object itself - that responsibility belongs to the calling context (WEBUTIL.SETDATA).
- BR-003 - The success or failure of the file-write operation is determined solely by the return value of the Java WriteData method; the function propagates this Boolean result without modification or additional error handling.
- BR-004 - The target Java class and method are fixed at 'oracle/forms/webutil/fileTransfer/AppServerFileWriter' and 'WriteData' respectively; no dynamic class or method resolution is performed.

---
**Implementation Logic**

```plsql
  FUNCTION WriteData(
    obj   ORA_JAVA.JOBJECT,
    a0    VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_BOOLEAN_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileWriter', 'WriteData', '(Ljava/lang/String;)Z', args); 
  END;
```

#### SP-066 - WEBUTIL_CORE.CUSTOMEVENTHANDLER

**Invoked From:**

- rr_pre_enq_dlr_fmb.xml [Trigger: WHEN-CUSTOM-ITEM-EVENT]

---

**Screen:**

N/A

---

**Purpose**

Acts as the central dispatcher for custom item events raised by the WebUtil client-side Java bean. When a WHEN-CUSTOM-ITEM-EVENT trigger fires, this procedure receives the event name and its serialised parameter string, extracts the data payload and multipart metadata, and routes execution to the appropriate WebUtil handler routine (logging, error reporting, bean registration, host-command callback, or file-transfer processing). Events not belonging to the recognised WebUtil set are silently discarded.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| EventName | VARCHAR2 | IN |
| EventParameters | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERROR ([SP-022](#SP-022--WEBUTIL.ERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETNUMBER ([SP-035](#SP-035--WEBUTIL.GETNUMBER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-051](#SP-051--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.REGISTERBEAN ([SP-057](#SP-057--WEBUTIL.REGISTERBEAN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETDATA ([SP-061](#SP-061--WEBUTIL.SETDATA)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETPROPERTY ([SP-062](#SP-062--WEBUTIL.SETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the EventName and EventParameters strings passed by the WHEN-CUSTOM-ITEM-EVENT trigger.
- Step 2 - Validate that EventName is one of the five recognised WebUtil events ('WUC_LOG_EVENT', 'WUC_ERROR_EVENT', 'WUC_REGISTER', 'WUH_CALLBACK_EVENT', 'WUT_TRANSFER_EVENT'); raise the internal 'unhandled' exception and exit silently if it is not.
- Step 3 - Extract the data payload by calling get_parameter_attr on the EventParameters string using the key 'WUC_DATA', storing the result in dataPayload.
- Step 4 - Extract the multipart descriptor by calling get_parameter_attr on the EventParameters string using the key 'WUC_DATA_MULTIPART', storing the result in dataMultiPart.
- Step 5 - Parse dataMultiPart using DelimStr.getNumber to derive the current chunk sequence number (chunkNumber) and the total number of chunks required to assemble the full payload (PayloadChunks).
- Step 6 - Route to the appropriate handler based on EventName:
  - If 'WUC_LOG_EVENT': call WEBUTIL.LOG (WebUtil_Core.log) with the payload, flagged as a non-error entry.
  - If 'WUC_ERROR_EVENT': call WEBUTIL.LOG (WebUtil_Core.log) with the payload, flagged as an error entry.
  - If 'WUC_REGISTER': call WEBUTIL.REGISTERBEAN (registerBean) with the payload to register the client bean.
  - If 'WUH_CALLBACK_EVENT': convert the payload to a numeric callback index (m_lastCallback); if conversion fails, call WEBUTIL.ERROR to report error code 408; if the index is valid, execute the corresponding stored callback trigger; if the index is null, log a warning via WEBUTIL.LOG.
  - If 'WUT_TRANSFER_EVENT': call WEBUTIL.SETDATA (WebUtil_File_Transfer.setData) with the payload to store the transferred data, then call WEBUTIL.SETPROPERTY to mark the transfer event status as 'RECEIVED'.
- Step 7 - On the 'unhandled' exception, suppress the error and return normally. All other exceptions are re-raised to the caller.

---
**Decision Points**

DP-001

Condition: EventName is one of 'WUC_LOG_EVENT', 'WUC_ERROR_EVENT', 'WUC_REGISTER', 'WUH_CALLBACK_EVENT', or 'WUT_TRANSFER_EVENT'.

TRUE: Continue processing - extract payload and multipart metadata, then route to the appropriate handler.

FALSE: Raise the internal 'unhandled' exception, which is caught and suppressed, effectively ignoring the unrecognised event.

---

DP-002

Condition: EventName = 'WUC_LOG_EVENT'.

TRUE: Call WEBUTIL.LOG with dataPayload and the non-error flag (false).

FALSE: Evaluate subsequent event-name conditions.

---

DP-003

Condition: EventName = 'WUC_ERROR_EVENT'.

TRUE: Call WEBUTIL.LOG with dataPayload and the error flag (true).

FALSE: Evaluate subsequent event-name conditions.

---

DP-004

Condition: EventName = 'WUC_REGISTER'.

TRUE: Call WEBUTIL.REGISTERBEAN with dataPayload.

FALSE: Evaluate subsequent event-name conditions.

---

DP-005

Condition: EventName = 'WUH_CALLBACK_EVENT'.

TRUE: Attempt to convert dataPayload to a numeric callback index and execute the associated trigger (see DP-006 and DP-007).

FALSE: Evaluate the final event-name condition.

---

DP-006

Condition: Conversion of dataPayload to a number succeeds (no INVALID_NUMBER exception) during 'WUH_CALLBACK_EVENT' processing.

TRUE: Assign the numeric value to m_lastCallback and proceed to DP-007.

FALSE: Call WEBUTIL.ERROR to report error code 408 for 'WEBUTIL_CORE.CustomEventHandler'; m_lastCallback remains unset.

---

DP-007

Condition: m_lastCallback IS NOT NULL after the conversion attempt.

TRUE: Execute the trigger stored at m_callbacks(m_lastCallback) via EXECUTE_TRIGGER.

FALSE: Call WEBUTIL.LOG to record a warning that no callback trigger was specified for the host command.

---

DP-008

Condition: EventName = 'WUT_TRANSFER_EVENT'.

TRUE: Call WEBUTIL.SETDATA with dataPayload, then call WEBUTIL.SETPROPERTY to set the 'WUT_TRANSFER_EVENT' property to 'RECEIVED'.

FALSE: No further routing is performed (end of event dispatch chain).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only the five predefined WebUtil event names ('WUC_LOG_EVENT', 'WUC_ERROR_EVENT', 'WUC_REGISTER', 'WUH_CALLBACK_EVENT', 'WUT_TRANSFER_EVENT') are handled; any other event name is silently discarded without raising an error to the caller.
- BR-002 - The data payload and multipart descriptor must always be extracted from the EventParameters string before event-specific routing is attempted, regardless of which event is being processed.
- BR-003 - A log event ('WUC_LOG_EVENT') must be recorded as a non-error entry, whereas an error event ('WUC_ERROR_EVENT') must be recorded as an error entry; the two must not be conflated.
- BR-004 - For a callback event ('WUH_CALLBACK_EVENT'), the payload must be a valid number representing a callback index; an invalid (non-numeric) payload must trigger error code 408 via WEBUTIL.ERROR rather than allowing an unhandled exception to propagate.
- BR-005 - A callback trigger is only executed when m_lastCallback resolves to a non-null numeric index; a null index must result in a warning log entry via WEBUTIL.LOG instead of a trigger execution attempt.
- BR-006 - On completion of a file-transfer event ('WUT_TRANSFER_EVENT'), the transfer status property must be updated to 'RECEIVED' via WEBUTIL.SETPROPERTY immediately after the data is stored via WEBUTIL.SETDATA, ensuring the two operations are always performed together.
- BR-007 - Exceptions other than the internal 'unhandled' event must be re-raised to the caller unchanged, preserving the original error context for upstream handling.

---
**Implementation Logic**

```plsql
  PROCEDURE CustomEventHandler(EventName       in VARCHAR2, 
                               EventParameters in VARCHAR2) is
    dataPayload   VARCHAR2(32767 char);   
    dataMultiPart VARCHAR2(61 char); /* should be enough! */ 
    chunkNumber   PLS_INTEGER;
    PayloadChunks PLS_INTEGER;
    dataType      PLS_INTEGER;
    unhandled     EXCEPTION;
  begin
    --Bug 2839033 - check for valid events only      
    if EventName not in ('WUC_LOG_EVENT',
                         'WUC_ERROR_EVENT', 
                         'WUC_REGISTER',
                         'WUH_CALLBACK_EVENT', 
                         'WUT_TRANSFER_EVENT') then  
      raise unhandled;
    end if;                        

    -- We're pretty much always going to need the data payload and 
    -- number of parts that make up that payload so get it now..
    get_parameter_attr(EventParameters,'WUC_DATA',dataType, dataPayload);
    get_parameter_attr(EventParameters,'WUC_DATA_MULTIPART',dataType, dataMultiPart);      
    -- split the MULTIPART info to work out how many messages from the 
    -- client are required to create the completed payload
    chunkNumber   := DelimStr.getNumber(dataMultiPart,1,true,'/');
    PayloadChunks := DelimStr.getNumber(dataMultiPart,2,true,'/');

    -- Now deal with the specific events that the client may dispatch
    -- This section will have to be extended for each new event that we 
    -- Add in order to hook the handler code for that message to the data 
    -- that is being sent - shame we can't subclass in PL/SQL :-)      
    if EventName = 'WUC_LOG_EVENT' then
        WebUtil_Core.log(dataPayload,false);
    elsif EventName = 'WUC_ERROR_EVENT' then
        WebUtil_Core.log(dataPayload,true);
    elsif EventName = 'WUC_REGISTER' then 
        registerBean(dataPayload);
    elsif EventName = 'WUH_CALLBACK_EVENT' then 
      begin 
        m_lastCallback := to_number(dataPayload);
      exception
          when INVALID_NUMBER then 
            error(WebUtil_Core.WUC_PACKAGE,408,'WEBUTIL_CORE.CustomEventHandler');
      end;
      if m_lastCallback is not null then 
          EXECUTE_TRIGGER(m_callbacks(m_lastCallback));
      else
            log('Callback trigger for host command not specified',true);
      end if;
    elsif EventName = 'WUT_TRANSFER_EVENT' then 
      WebUtil_File_Transfer.setData(dataPayload);
      WebUtil_Core.setProperty(WebUtil_Core.WUT_PACKAGE, 'WUT_TRANSFER_EVENT','RECEIVED');
    end if;
  exception
    when unhandled then
      null;
    when OTHERS then
      raise;
  end CustomEventHandler;
```

#### SP-067 - ADD_ERROR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.SAVE_FILE]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Records an error in the global error state by setting the error-encountered flag to TRUE and storing the calling function name together with the error description in the error stack. Used by all Win32 API wrapper routines to capture diagnostic information when an operation fails.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| CallingFunction | VARCHAR2 | IN |
| SetErrorText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-071](#SP-071--DEBUGLOG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Set the global error-encountered flag to TRUE.
- Step 2 - Compose the error stack entry by combining the calling function name, a colon separator, and up to 1968 characters of the error text.
- Step 3 - Log the error stack entry via the debug logging mechanism.

---
**Decision Points**

No conditional decision points in this routine.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The error text is truncated to 1968 characters to prevent value errors from excessively long messages.
- BR-002 - Once this routine is called, the error-encountered flag remains TRUE until the error stack is explicitly cleared by calling CLEAN_ERROR_STACK.

---
**Implementation Logic**

```plsql

PROCEDURE Add_Error (CallingFunction in VARCHAR2, SetErrorText in VARCHAR2) is
begin 
  -- Just watch for value errors 
  ERROR_ENCOUNTERED  := TRUE;
  ERROR_STACK    := CallingFunction||': '||substr(SetErrorText,1,1968);
  Win_API_Debug.DebugLog(99,'Add_Error',ERROR_STACK);
end Add_Error;
```

#### SP-068 - ADD_EXTERNAL_ERRORS

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Collects any pending errors from the TOOL_ERR error stack or, if none are present, the current SQL error message, and returns them concatenated as a single string. This allows Win32 API wrapper routines to include additional system-level error detail in the error messages they record.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Check whether there are any pending errors on the TOOL_ERR stack.
- Step 2 - If there are TOOL_ERR errors, loop through each one, appending it to the result buffer separated by newlines; stop if the buffer would overflow.
- Step 3 - After collecting all messages, pop each entry off the TOOL_ERR stack.
- Step 4 - If there are no TOOL_ERR errors but SQLERRM is non-null, append the SQL error message to the result buffer.
- Step 5 - Return the concatenated error string.

---
**Decision Points**

DP-001

Condition:
Whether the TOOL_ERR error stack contains one or more pending errors.

TRUE:
Loop through and collect all TOOL_ERR messages, then return them.

FALSE:
Check whether SQLERRM contains an error message.

DP-002

Condition:
Whether the accumulated error text would exceed the buffer capacity on the next append (VALUE_ERROR exception).

TRUE:
Exit the loop early; the buffer is full.

FALSE:
Continue appending error messages.

DP-003

Condition:
Whether SQLERRM is non-null (when no TOOL_ERR errors were present).

TRUE:
Append the SQL error message to the result buffer.

FALSE:
Return an empty string.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - TOOL_ERR errors take precedence over SQLERRM; if TOOL_ERR errors are present, SQLERRM is ignored.
- BR-002 - The function silently truncates the result when the 1968-character buffer limit is reached, rather than raising an error.

---
**Implementation Logic**

```plsql

FUNCTION Add_External_Errors return varchar2 is
  iCounter   pls_integer;
  vcErrBuff  varchar2(1968);
begin 
  if tool_err.nerrors > 0 then 
    for iCounter in 1..tool_err.nerrors LOOP
      begin 
        vcErrBuff := vcErrBuff||chr(10)||tool_err.message;
      exception
        when VALUE_ERROR then 
          exit; /* String exceeds allowable buffer */
      end;
      tool_err.pop;
    end loop;
  elsif SQLERRM is not null then 
    vcErrBuff := chr(10)||SQLERRM; 
  end if;
  return vcErrBuff;
end Add_External_Errors;
```

#### SP-069 - BOOLTOCHAR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Converts a BOOLEAN value to its string representation ("TRUE" or "FALSE"). This utility function is used by debug logging routines to include boolean flag values in diagnostic messages.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| ThisBoolean | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate the boolean input value.
- Step 2 - If the value is TRUE, return the string "TRUE"; otherwise return the string "FALSE".

---
**Decision Points**

DP-001

Condition:
Whether the supplied boolean value is TRUE.

TRUE:
Return the string "TRUE".

FALSE:
Return the string "FALSE".

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The output is always one of exactly two values: "TRUE" or "FALSE" - no null or other representation is returned.

---
**Implementation Logic**

```plsql

  
  FUNCTION  BoolToChar(ThisBoolean IN BOOLEAN) return VARCHAR2 is
  begin
  	if ThisBoolean then 
  		RETURN 'TRUE';
  	else
  	    RETURN 'FALSE';
  	end if;
  end BoolToChar;

END;

PACKAGE WIN_API_DIALOG IS

/*-------------------------------------------------------------------------*\
 * WIN_API_DIALOG ->   This package is concerned with Displaying Common
 *      dialogs
 * Contents:
 *    Open_File    -> Open File Dialog
 *    Save_File    -> Save File Dialog
 *    Select_Printer    -> Printer Selection Dialog
 *    Choose_Font       -> Display the Font Selection Dialog
 *    Choose_Color      -> Display the Color Selection Dialog
 * Dependancies:
 *    WIN_API_ENVIRONMENT
 *    WIN_API
 *    WIN_API_DEBUG
\*-------------------------------------------------------------------------*/ 

/*-------------------------------------------------------------------------*\
 * Open_File        -> Displays the standard Open File dialog
 * Arguments: 
 *  Title           -> The Title for the Dialog Box
 *                     (Default -> 'Open File')
 *  StartDirectory  -> Where the dialog should start from
 *                     this should be in the format 'C:\TEMP'
 *                     (Default -> Windows Directory)
 *  FileFilter      ->  Restrict the list of files. The filter string 
 *                      should be in the format:
 *                      '<Description>|<filename>.<Extension>|'
 *                      typically this would be something like
 *                      'All files(*.*)|*.*|' or 'Text files(*.txt)|*.txt|'
 *                      "All Files" is the Default
 *  Modal           ->  Should the dialog be modal with respect to the 
 *                      application? 
 *                      default = TRUE
 *  AdvancedFlags   ->  (See list in WIN_API header) This option allows
 *                      you to change the attributes of the Open File 
 *                      dialog.  Here are some of the Flags that might
 *                      be of interest:
 *                      OFN_HIDEREADONLY  Hides the Read Only check box.
 *                      OFN_NONETWORKBUTTON  Hides the Network Button
 *                      OFN_EXPLORER    Display an Explorer style 
 *                        Dialog rather than the conventional one.
 *                      See your Microsoft docmentation for details on 
 *                      each flag.
 *                      To Set the Advanced_Flags varaible, just add the 
 *                      required flags together.  The default is:
 *                      WIN_API.OFN_PATHMUSTEXIST + WIN_API.OFN_FILEMUSTEXIST +
 *                      WIN_API.OFN_HIDEREADONLY + WIN_API.OFN_NOCHANGEDIR 
 *  RaiseExceptions ->  TRUE of FALSE(Default) If set to true, then if the 
 *                      command is not successful (e.g no filename is  
 *                      returned) then the explicit exception
 *                      NO_DATA_FOUND will be raised.
 *        
 * Returns:
 *  Path and name of the selected file
\*-------------------------------------------------------------------------*/
```

#### SP-070 - CLEAN_ERROR_STACK

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Resets the global error state by clearing the error-encountered flag and emptying the error stack string. This is called at the start of each Win32 API operation to ensure that any previous error information does not persist into the new operation.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Set the global error-encountered flag to FALSE.
- Step 2 - Set the global error stack string to NULL.

---
**Decision Points**

No conditional decision points in this routine.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - All previous error information is discarded unconditionally; callers must ensure they have handled any existing errors before calling this routine.

---
**Implementation Logic**

```plsql

PROCEDURE Clean_Error_Stack is 
begin 
  -- just empty the variables
  ERROR_ENCOUNTERED  := FALSE;
  ERROR_STACK        := NULL;
end Clean_Error_Stack;
```

#### SP-071 - DEBUGLOG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: ADD_ERROR]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: SETDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a formatted diagnostic message to the configured debug output destination - either a file (via TEXT_IO) or the Win32 debug window (via WINDEBUG) - subject to the current debug state, pause flag, and message level threshold. Automatically falls back from Win32 debug window logging to file logging when the debug API is unavailable, and restores Win32 window logging once the API becomes available. File I/O is performed exclusively through TEXT_IO; no dependency on WEBUTIL.PUT_LINE exists in this version.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugLevel | PLS_INTEGER | IN |
| LoggingCall | VARCHAR2 | IN |
| LogString | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- SETDEBUG ([SP-077](#SP-077--SETDEBUG)) - matched by member name
- WEBUTIL.LENGTH ([SP-050](#SP-050--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)
- WINDEBUG ([SP-081](#SP-081--WINDEBUG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - If the debug state is 0 (disabled), debugging is paused, or the message's debug level exceeds the configured threshold, do nothing and return immediately.
- Step 2 - If timestamps are enabled, capture the current time in HH24:MI:SS format and append a '> ' separator.
- Step 3 - Construct the full debug string: a zero-padded level indicator in angle brackets, the optional timestamp, the calling function name padded to 30 characters with a colon, and the log message truncated so the total does not exceed 2000 characters. String length is measured using WEBUTIL.LENGTH.
- Step 4 - If the debug state is mode 2 (Win32 debug window) and DEBUG_API_ENABLED is TRUE, send the constructed string to the Win32 debug output window via WINDEBUG.
- Step 5 - If mode 2 is requested but DEBUG_API_ENABLED is FALSE, call SETDEBUG to switch to mode 1 file logging (defaulting to 'd2kwutil.log' if no file is configured), log a fallback notice and the original message recursively, then set the bDebugType2Required flag to TRUE so mode 2 is reinstated when the API becomes available.
- Step 6 - If the debug state is mode 1, check whether bDebugType2Required is TRUE and DEBUG_API_ENABLED is now TRUE. If so, call SETDEBUG to restore mode 2, log a restoration notice recursively, clear bDebugType2Required, and re-log the current message via the restored mode 2 path.
- Step 7 - Otherwise (mode 1 file logging with no pending mode 2 restoration), open the configured debug log file in append mode using TEXT_IO.FOPEN, write the debug string with TEXT_IO.PUT_LINE, and close the file with TEXT_IO.FCLOSE.
- Step 8 - If any exception occurs during the above steps, silently set the debug state to 0 to prevent diagnostic code from disrupting normal form operation.

---
**Decision Points**

DP-001

Condition:
Whether debug logging is currently disabled (iDebugState = 0), paused (bDebugPaused = TRUE), or the supplied DebugLevel exceeds the configured iDebugLevel threshold.

TRUE:
Do nothing and return immediately.

FALSE:
Proceed to format and write the debug message.

DP-002

Condition:
Whether the timestamp flag (bDebugTimeStamp) is enabled.

TRUE:
Format the current system time as HH24:MI:SS and append '> ' to use as the timestamp prefix.

FALSE:
Leave the timestamp portion of the debug string blank.

DP-003

Condition:
Whether the debug state is mode 2 (Win32 debug window) and DEBUG_API_ENABLED is TRUE.

TRUE:
Send the formatted debug string to the Win32 debug output window via WINDEBUG.

FALSE:
Evaluate the fallback condition (DP-004).

DP-004

Condition:
Whether mode 2 is configured (iDebugState = 2) but DEBUG_API_ENABLED is FALSE.

TRUE:
Call SETDEBUG to switch to mode 1 file logging, recursively log a fallback notice and the original message, and set bDebugType2Required to TRUE.

FALSE:
Evaluate the mode 2 restoration condition (DP-005).

DP-005

Condition:
Whether bDebugType2Required is TRUE and DEBUG_API_ENABLED is now TRUE (mode 2 was previously unavailable but the API is now accessible).

TRUE:
Call SETDEBUG to restore mode 2, recursively log a restoration notice, clear bDebugType2Required, and re-log the current message.

FALSE:
Write the debug string to the configured log file using TEXT_IO (append mode).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Messages whose DebugLevel exceeds the configured iDebugLevel threshold are silently discarded; only messages at or below the threshold are written.
- BR-002 - The total formatted debug string must not exceed 2000 characters; the log message is truncated using WEBUTIL.LENGTH to enforce this limit.
- BR-003 - When mode 2 (Win32 debug window) is configured but the debug API is unavailable, the procedure automatically switches to file logging via SETDEBUG without interrupting the form, and records the fallback in the log.
- BR-004 - Once the Win32 debug API becomes available after a fallback, mode 2 logging is automatically reinstated via SETDEBUG and the restoration is recorded in the log.
- BR-005 - File logging is performed exclusively through TEXT_IO (FOPEN in append mode, PUT_LINE, FCLOSE); no other file-writing mechanism is used.
- BR-006 - Any exception raised during debug logging is silently suppressed by setting iDebugState to 0, ensuring that diagnostic code never causes visible failures in the form.

---
**Implementation Logic**

```plsql
   
PROCEDURE DebugLog (DebugLevel  IN PLS_INTEGER, 
                    LoggingCall IN VARCHAR2, 
                    LogString   IN VARCHAR2) is
 vcDateStamp   VARCHAR2(10);
 vcDebugString VARCHAR2(2000);
 hFile         TEXT_IO.FILE_TYPE;
begin
  if iDebugState = 0 then 
  	NULL;
  elsif bDebugPaused then 
  	NULL;
  elsif DebugLevel > iDebugLevel then 
  	NULL;
  else
  	-- Sort out the Datestamp	
  	if bDebugTimeStamp then 
  		vcDateStamp := to_char(SYSDATE,'HH24:MI:SS')||'> ';
  	end if;
  
  	-- Construct the final String
  	vcDebugString := '<'||lpad(to_char(DebugLevel),2,0)||'> '||vcDateStamp||rpad(LoggingCall||':',30);
    vcDebugString := vcDebugString||substr(LogString,1,(2000-length(vcDebugString)));
  
  	if iDebugState = 2 then
  		if DEBUG_API_ENABLED then 
  	   		win_api_debug.WinDebug(vcDebugString);
  		else
  			-- Can't use API calls if the API functions aren't there
	  		-- So Switch to File Logging to d2kwut$.log
	  		SetDebug(1,nvl(vcDebugFile,'d2kwutil.log'),iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Unable to Log to Debugger Switching to File');
			DebugLog(DebugLevel,LoggingCall,LogString);	  		
	  		bDebugType2Required := TRUE;
	  	end if;
  	else
     	if bDebugType2Required and DEBUG_API_ENABLED then
	     	-- API now Available - Reinstate Debugging to Debugger
	  		SetDebug(2,vcDebugFile,iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Restoring Logging to Debugger');
	  		bDebugType2Required := FALSE;
	  		DebugLog(Debuglevel,LoggingCall,LogString);
	
	  	else
		 	hFile := TEXT_IO.FOPEN(vcDebugFile,'A');
		 	TEXT_IO.PUT_LINE(hFile,vcDebugString);
		 	TEXT_IO.FCLOSE(hFile);
		end if;
  	end if;
  end if;
 exception
  	-- Don't let the debugging cause Problems of it's own
  	when others then 
  		iDebugState := 0;
 end DebugLog;
```

#### SP-072 - GET_ENVIRONMENT_STRING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value of a named operating-system environment variable by delegating to the D2KWUTIL native library call D2KWUTIL_GETDOSENV. The function returns the resolved variable value as a VARCHAR2 string, or NULL (optionally raising an exception) when the variable cannot be resolved. It is invoked by WEBUTIL.GETVAR to supply environment-variable data to the calling form.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VariableName | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-067](#SP-067--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-068](#SP-068--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-069](#SP-069--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-070](#SP-070--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_GETDOSENV ([SP-006](#SP-006--D2KWUTIL.D2KWUTIL_GETDOSENV)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-071](#SP-071--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-076](#SP-076--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log entry diagnostics by calling DEBUGLOG (Win_api_debug.DebugLog) at trace level 99, recording the input VariableName and the Boolean flag RaiseExceptions (converted to a character representation via BOOLTOCHAR).
- Step 2 - Clear any previously accumulated error state by calling CLEAN_ERROR_STACK (WIN_API.Clean_Error_Stack), ensuring a clean context for this invocation.
- Step 3 - Initialise the return-code variable iRC to 0.
- Step 4 - Check whether the WIN_API layer is available (WIN_API.API_ENABLED). If it is not available, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 5 - Register the native function handle for D2KWUTIL_GETDOSENV via REGISTER_FUNCTION_CALL, supplying the function name, return type ('LONG'), and parameter type signature ('*CHAR,*CHAR,LONG').
- Step 6 - Prepare the environment-variable lookup token by wrapping VariableName in percent signs (e.g. '%VARNAME%') and initialise a 512-character null-padded output buffer.
- Step 7 - Invoke D2KWUTIL.D2KWUTIL_GETDOSENV with the registered function handle, the formatted variable token, the output buffer, and the buffer length (512). Capture the integer return code iRC and the populated output buffer vcBuff2.
- Step 8 - Log the result diagnostics via DEBUGLOG, recording the returned value length (iRC) and the buffer contents.
- Step 9 - Evaluate the outcome: if iRC equals 0 or the output buffer still equals the unexpanded input token (indicating the OS did not resolve the variable), record an error via ADD_ERROR and either raise NO_DATA_FOUND (when RaiseExceptions is TRUE) or return NULL (when RaiseExceptions is FALSE).
- Step 10 - If resolution succeeded, return the populated output buffer vcBuff2 as the environment-variable value.
- Step 11 - In the exception block: re-raise NO_DATA_FOUND as-is; handle WIN_API.NOT_AVAILABLE by logging an error via ADD_ERROR with the WIN_API.NoAPI message and re-raising; handle all other exceptions by logging an error via ADD_ERROR combining WIN_API.UError with any external error details from ADD_EXTERNAL_ERRORS, then re-raising.

---
**Decision Points**

DP-001

Condition: WIN_API.API_ENABLED is TRUE.

TRUE: Proceed to register the native function call and invoke D2KWUTIL.D2KWUTIL_GETDOSENV to resolve the environment variable.

FALSE: Raise WIN_API.NOT_AVAILABLE, bypassing all resolution logic.

---

DP-002

Condition: The return code iRC equals 0 OR the output buffer vcBuff2 still equals the unexpanded input token vcBuff1 (i.e. the OS did not substitute the variable).

TRUE: The variable could not be resolved. Log an error via ADD_ERROR and branch on RaiseExceptions (see DP-003).

FALSE: The variable was resolved successfully; return the output buffer vcBuff2 to the caller.

---

DP-003

Condition: RaiseExceptions input parameter is TRUE (evaluated only when DP-002 is TRUE).

TRUE: Raise NO_DATA_FOUND to propagate the failure to the caller.

FALSE: Return NULL silently, allowing the caller to handle the absence of a value without an exception.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function may only execute the environment-variable lookup when the WIN_API layer reports itself as available (WIN_API.API_ENABLED). If the API layer is unavailable, the function must raise WIN_API.NOT_AVAILABLE and must not attempt the native call.
- BR-002 - The environment-variable name must be submitted to the OS in percent-sign-delimited format (e.g. '%VARNAME%') as required by the D2KWUTIL_GETDOSENV convention.
- BR-003 - A successful resolution is confirmed only when the return code iRC is non-zero AND the output buffer differs from the unexpanded input token. Both conditions must hold; if either fails, the lookup is treated as unsuccessful.
- BR-004 - When a lookup is unsuccessful, an error must always be recorded via ADD_ERROR before any return or raise action is taken.
- BR-005 - The caller controls exception propagation through the RaiseExceptions flag: passing TRUE causes the function to raise NO_DATA_FOUND on lookup failure; passing FALSE (the default) causes the function to return NULL, keeping failure handling at the caller's discretion.
- BR-006 - All unexpected exceptions must be enriched with external error details (ADD_EXTERNAL_ERRORS) before being re-raised, ensuring complete diagnostic information is preserved in the error stack.
- BR-007 - Entry and result diagnostics must be written to the debug log (DEBUGLOG) at trace level 99 for every invocation, capturing the input variable name, the RaiseExceptions flag, the resolved value length, and the resolved value.

---
**Implementation Logic**

```plsql

FUNCTION Get_Environment_string (  VariableName      IN  VARCHAR2,
                                   RaiseExceptions   IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  vcBuff2    VARCHAR2(512);
  iBuff1    PLS_INTEGER;
  iRC        PLS_INTEGER;
begin 
  Win_api_debug.DebugLog(99,'Get_Environment_String','Args: VariableName="'||VariableName||'", RaiseExceptions='||win_api_debug.BoolToChar(RaiseExceptions));
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then
    win_api.Register_function_call(iGetDOSEnv,'d2kwutil_GetDOSEnv','LONG','*CHAR,*CHAR,LONG');
    vcBuff1    := '%'||VariableName||'%';
    vcBuff2    := RPAD(' ',512,CHR(0));
    iBuff1    := 512;
    iRC   := d2kwutil_GetDOSEnv(win_api.FunctionHandle(iGetDOSEnv),vcBuff1,vcBuff2,iBuff1);
    Win_api_debug.DebugLog(99,'Get_Environment_String','Result: Value Length='||to_char(iRC)||', Value='||vcBuff2);
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0  or vcBuff2 = vcBuff1 then 
    Win_API.Add_error('Get_Environment_String','Unable to get the value of the variable '||VariableName);
    if RaiseExceptions then
      raise NO_DATA_FOUND;
    else
      return NULL;
    end if;
  else
    return vcBuff2;
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Environment_String',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Environment_String',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Environment_String;
```

#### SP-073 - GET_TEMP_DIRECTORY

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the path of the Windows TEMP directory from the operating system using the Win32 API and returns it as a string. This directory path is used by the file-chooser dialogue when the "$TEMP$" token is specified as the initial directory.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-067](#SP-067--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-068](#SP-068--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-069](#SP-069--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-070](#SP-070--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_WINDIR ([SP-008](#SP-008--D2KWUTIL.D2KWUTIL_WINDIR)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-071](#SP-071--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-076](#SP-076--REGISTER_FUNCTION_CALL)) - matched by member name
- STRIPDIRSEP ([SP-079](#SP-079--STRIPDIRSEP)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log the input arguments for diagnostic purposes and clear the error stack.
- Step 2 - Check whether the Win32 API is available; if not, raise a "not available" exception.
- Step 3 - Register the Win32 function for retrieving the TEMP directory path.
- Step 4 - Allocate a 512-character buffer padded with null terminators and call the Win32 function to retrieve the path.
- Step 5 - Log the result.
- Step 6 - If the return code is zero (no value returned), record an error; raise NO_DATA_FOUND if the caller requested exceptions, or return NULL otherwise.
- Step 7 - If a path was returned, strip any trailing backslash and return the cleaned path.

---
**Decision Points**

DP-001

Condition:
Whether the Win32 API is currently enabled and available.

TRUE:
Register the function and call the Win32 API to retrieve the TEMP directory path.

FALSE:
Raise a "not available" exception.

DP-002

Condition:
Whether the Win32 function returned a zero return code (no value returned).

TRUE:
Record an error; raise NO_DATA_FOUND if RaiseExceptions is TRUE, otherwise return NULL.

FALSE:
Strip the trailing separator from the path and return it.

DP-003

Condition:
Whether the caller requested exceptions on failure (RaiseExceptions = TRUE).

TRUE:
Raise NO_DATA_FOUND when no path is returned.

FALSE:
Return NULL without raising an exception.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - If the Win32 API is unavailable, no fallback exists and an exception is always raised.
- BR-002 - The returned path always has any trailing backslash removed so callers receive a consistent format.
- BR-003 - The caller controls whether a missing TEMP directory causes a hard exception or a NULL return via the RaiseExceptions parameter.

---
**Implementation Logic**

```plsql

FUNCTION Get_Temp_Directory (RaiseExceptions IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  iRC        PLS_INTEGER;
begin 
  Win_API_Debug.DebugLog(99,'Get_Temp_Directory','Args: RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	 	
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then 
    win_api.Register_function_call(iTmpDir,'d2kwutil_TmpDir','INT','*CHAR,INT');
    vcBuff1    := RPAD(' ',512,CHR(0));
    iRC   := d2kwutil_WinDir(win_api.FunctionHandle(iTmpDir),vcBuff1,512);
    Win_API_Debug.DebugLog(99,'Get_Temp_Directory','Result:  RC='||to_char(iRC)||', vcBuff1="'||vcBuff1||'"');	      
  else
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0 then 
    Win_API.Add_error('Get_Temp_Directory','No Value Returned');
    if RaiseExceptions then
      raise NO_DATA_FOUND;
    else
      return NULL;
    end if;
  else
    return WIN_API.StripDirSep(vcBuff1);
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Temp_Directory',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Temp_Directory',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Temp_Directory;
```

#### SP-074 - GET_WINDOWS_DIRECTORY

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the path of the Windows installation directory from the operating system using the Win32 API and returns it as a string. This directory path is used by the file-chooser dialogue when the "$WINDIR$" token is specified as the initial directory.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-067](#SP-067--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-068](#SP-068--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-069](#SP-069--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-070](#SP-070--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_WINDIR ([SP-008](#SP-008--D2KWUTIL.D2KWUTIL_WINDIR)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-071](#SP-071--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-076](#SP-076--REGISTER_FUNCTION_CALL)) - matched by member name
- STRIPDIRSEP ([SP-079](#SP-079--STRIPDIRSEP)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log the input arguments for diagnostic purposes and clear the error stack.
- Step 2 - Check whether the Win32 API is available; if not, raise a "not available" exception.
- Step 3 - Register the Win32 function for retrieving the Windows directory path.
- Step 4 - Allocate a 512-character buffer padded with null terminators and call the Win32 function to retrieve the path.
- Step 5 - Log the result.
- Step 6 - If the return code is zero (no value returned), record an error; raise NO_DATA_FOUND if the caller requested exceptions, or return NULL otherwise.
- Step 7 - If a path was returned, strip any trailing backslash and return the cleaned path.

---
**Decision Points**

DP-001

Condition:
Whether the Win32 API is currently enabled and available.

TRUE:
Register the function and call the Win32 API to retrieve the Windows directory path.

FALSE:
Raise a "not available" exception.

DP-002

Condition:
Whether the Win32 function returned a zero return code (no value returned).

TRUE:
Record an error; raise NO_DATA_FOUND if RaiseExceptions is TRUE, otherwise return NULL.

FALSE:
Strip the trailing separator from the path and return it.

DP-003

Condition:
Whether the caller requested exceptions on failure (RaiseExceptions = TRUE).

TRUE:
Raise NO_DATA_FOUND when no path is returned.

FALSE:
Return NULL without raising an exception.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - If the Win32 API is unavailable, no fallback exists and an exception is always raised.
- BR-002 - The returned path always has any trailing backslash removed so callers receive a consistent format.
- BR-003 - The caller controls whether a missing Windows directory path causes a hard exception or a NULL return via the RaiseExceptions parameter.

---
**Implementation Logic**

```plsql

FUNCTION Get_Windows_Directory (RaiseExceptions IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  iRC        PLS_INTEGER;
begin 
  Win_API_Debug.DebugLog(99,'Get_Windows_Directory','Args: RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	 	
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then 
    win_api.Register_function_call(iWinDir,'d2kwutil_WinDir','INT','*CHAR,INT');

    vcBuff1    := RPAD(' ',512,CHR(0));
    iRC   := d2kwutil_WinDir(win_api.FunctionHandle(iWinDir),vcBuff1,512);
    Win_API_Debug.DebugLog(99,'Get_Windows_Directory','Result:  RC='||to_char(iRC)||', vcBuff1="'||vcBuff1||'"');	      
  else
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0 then 
    Win_API.Add_error('Get_Windows_Directory','No Value Returned');
    if RaiseExceptions then
      raise NO_DATA_FOUND;
    else
      return NULL;
    end if;
  else
    return WIN_API.StripDirSep(vcBuff1);
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Windows_Directory',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Windows_Directory',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Windows_Directory;
```

#### SP-075 - READ_REGISTRY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

READ_REGISTRY retrieves a named value from the Windows Registry for a specified registry path and entry. It translates a human-readable registry root name (e.g., HKEY_LOCAL_MACHINE) into the numeric constant expected by the D2KWUTIL native library call, invokes D2KWUTIL.D2KWUTIL_GETREGKEY to perform the low-level read, interprets the return code, and returns the registry value as a VARCHAR2 string. The procedure is designed to be called indirectly via WEBUTIL.GETVAR and supports an optional exception-raising mode to allow callers to choose between silent NULL returns and hard exceptions on failure.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RegPath | VARCHAR2 | IN |
| RegEntry | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-067](#SP-067--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-068](#SP-068--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-069](#SP-069--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-070](#SP-070--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_GETREGKEY ([SP-007](#SP-007--D2KWUTIL.D2KWUTIL_GETREGKEY)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-071](#SP-071--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-076](#SP-076--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log entry diagnostics: call DEBUGLOG (severity 99) recording the RegPath, RegEntry, and RaiseExceptions flag to the debug output.
- Step 2 - Clear the error stack: call CLEAN_ERROR_STACK to reset any previously accumulated errors before processing begins.
- Step 3 - Initialise the return code (iRC = 0) and check API availability: evaluate WIN_API.API_ENABLED; if the Windows API is not available, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 4 - Register the native function handle: call REGISTER_FUNCTION_CALL to bind the iGetRegKey handle to the D2KWUTIL_GETREGKEY entry point with its expected signature, making the function callable via the D2KWUTIL bridge.
- Step 5 - Resolve the registry root: extract the root key name from RegPath (the segment before the first backslash, uppercased) and map it to its numeric constant: HKEY_LOCAL_MACHINE=0, HKEY_CLASSES_ROOT=1, HKEY_CURRENT_USER=2, HKEY_USERS=3, HKEY_CURRENT_CONFIG=4. If the root name matches none of these values, record an error via ADD_ERROR and, if RaiseExceptions is TRUE, raise NO_DATA_FOUND.
- Step 6 - Prepare call buffers: set the subpath buffer (vcBuff1) to the portion of RegPath after the first backslash, set the entry name buffer (vcBuff2) to RegEntry, initialise the result buffer (vcBuff3) to a 2000-character NUL-padded string, and set the buffer length (iBuff2) to 2000.
- Step 7 - Apply compatibility flag: if WIN_API.COMPAT_EXPAND_REG_VALUES is FALSE, set iBuff3=1 to suppress environment-variable expansion in registry values and log a compatibility debug message; otherwise set iBuff3=0 to allow expansion.
- Step 8 - Invoke the native registry read: call D2KWUTIL.D2KWUTIL_GETREGKEY passing the function handle, root constant, subpath, entry name, result buffer, buffer length, and expansion flag; capture the integer return code in iRC.
- Step 9 - Log the result: call DEBUGLOG (severity 99) recording iRC and the contents of vcBuff3.
- Step 10 - Evaluate the return code and handle errors:
  - iRC = -1: entry not found; call ADD_ERROR, return NULL or raise NO_DATA_FOUND depending on RaiseExceptions.
  - iRC = -2: unsupported data type; call ADD_ERROR, return NULL or raise NO_DATA_FOUND depending on RaiseExceptions.
  - iRC = -3: value exceeds 2000-byte buffer; call ADD_ERROR, return NULL or raise VALUE_ERROR depending on RaiseExceptions.
  - iRC = -4: environment string expansion failed; call ADD_ERROR, return NULL or raise NO_DATA_FOUND depending on RaiseExceptions.
- Step 11 - Return the result: if iRC indicates success (none of the above error codes), return vcBuff3 containing the retrieved registry value.
- Step 12 - Exception handling: NO_DATA_FOUND and VALUE_ERROR are re-raised as-is; WIN_API.NOT_AVAILABLE triggers ADD_ERROR with the NoAPI message then re-raises; all other exceptions trigger ADD_ERROR with the generic unhandled-error message concatenated with ADD_EXTERNAL_ERRORS output, then re-raise.

---
**Decision Points**

DP-001
Condition: WIN_API.API_ENABLED is TRUE.
TRUE: Proceed with function registration, root resolution, and the registry read.
FALSE: Raise WIN_API.NOT_AVAILABLE immediately without attempting any registry access.

DP-002
Condition: The extracted registry root name (upper-cased prefix of RegPath before the first backslash) matches one of the five recognised constants (HKEY_LOCAL_MACHINE, HKEY_CLASSES_ROOT, HKEY_CURRENT_USER, HKEY_USERS, HKEY_CURRENT_CONFIG).
TRUE: Assign the corresponding numeric constant to iBuff1 and continue.
FALSE: Call ADD_ERROR reporting an invalid registry key; if RaiseExceptions is TRUE raise NO_DATA_FOUND, otherwise continue (iRC remains 0 but no valid root is set).

DP-003
Condition: WIN_API.COMPAT_EXPAND_REG_VALUES is FALSE.
TRUE: Set iBuff3=1 to suppress environment-variable expansion in the retrieved value and log a compatibility debug message.
FALSE: Set iBuff3=0 to allow environment-variable expansion.

DP-004
Condition: iRC returned by D2KWUTIL.D2KWUTIL_GETREGKEY equals -1 (entry not found).
TRUE: Call ADD_ERROR; if RaiseExceptions is FALSE return NULL, if TRUE raise NO_DATA_FOUND.
FALSE: Evaluate subsequent return-code conditions.

DP-005
Condition: iRC equals -2 (unsupported data type).
TRUE: Call ADD_ERROR; if RaiseExceptions is FALSE return NULL, if TRUE raise NO_DATA_FOUND.
FALSE: Evaluate subsequent return-code conditions.

DP-006
Condition: iRC equals -3 (value length exceeds 2000-byte buffer).
TRUE: Call ADD_ERROR; if RaiseExceptions is FALSE return NULL, if TRUE raise VALUE_ERROR.
FALSE: Evaluate subsequent return-code conditions.

DP-007
Condition: iRC equals -4 (environment string expansion failed).
TRUE: Call ADD_ERROR; if RaiseExceptions is FALSE return NULL, if TRUE raise NO_DATA_FOUND.
FALSE: No error condition applies; return vcBuff3 to the caller.

DP-008
Condition: RaiseExceptions is TRUE (evaluated within each error-code branch, DP-002 through DP-007).
TRUE: Raise the appropriate exception (NO_DATA_FOUND or VALUE_ERROR) so the caller receives a hard failure.
FALSE: Return NULL silently, allowing the caller to handle the absence of a value without an exception.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The Windows API bridge must be enabled (WIN_API.API_ENABLED) before any registry read is attempted; if the API is unavailable the function must not proceed and must raise WIN_API.NOT_AVAILABLE.
- BR-002 - The registry root must be one of exactly five recognised values: HKEY_LOCAL_MACHINE, HKEY_CLASSES_ROOT, HKEY_CURRENT_USER, HKEY_USERS, or HKEY_CURRENT_CONFIG. Any other root name is treated as an invalid registry key and an error is recorded.
- BR-003 - The result buffer for the registry value is fixed at 2000 bytes; any registry value exceeding this limit is treated as an error condition (iRC=-3) and the oversized value is not returned.
- BR-004 - Environment-variable expansion within registry values is controlled by the WIN_API.COMPAT_EXPAND_REG_VALUES flag; when the flag is FALSE, expansion is suppressed (iBuff3=1) to maintain backward compatibility.
- BR-005 - The caller controls error-handling behaviour through the RaiseExceptions parameter: when FALSE the function returns NULL on any read failure, allowing silent degradation; when TRUE the function raises an exception, enforcing strict failure handling in the calling context.
- BR-006 - All error conditions (invalid root, entry not found, unsupported type, buffer overflow, expansion failure, API unavailable, unexpected exceptions) must be recorded via ADD_ERROR before the function returns or raises, ensuring the error stack is populated for upstream diagnostics.
- BR-007 - The error stack must be cleared at the start of each invocation via CLEAN_ERROR_STACK so that errors from previous calls do not contaminate the current operation's error context.
- BR-008 - The native D2KWUTIL_GETREGKEY function handle must be registered via REGISTER_FUNCTION_CALL before each invocation; the function signature is fixed as 'INT','INT,*CHAR,*CHAR,*CHAR,INT,INT' and must not be altered.
- BR-009 - Debug logging at severity level 99 must be performed at entry (recording all input arguments) and after the native call (recording iRC and the retrieved value), supporting traceability of registry access operations.

---
**Implementation Logic**

```plsql

FUNCTION Read_Registry (RegPath         IN  VARCHAR2,
                        RegEntry        IN  VARCHAR2, 
                        RaiseExceptions IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  vcBuff2    VARCHAR2(512);
  vcBuff3    VARCHAR2(2000);
  vcBuff4    VARCHAR2(512);
  vcBuff5    VARCHAR2(512);                        
  vcRoot     VARCHAR2(20);
  iBuff1     PLS_INTEGER;
  iBuff2     PLS_INTEGER;
  iBuff3		 PLS_INTEGER;
  iRC        PLS_INTEGER;
begin
  Win_API_Debug.DebugLog(99,'Read_Registry','Args: RegPath="'||RegPath||'", RegEntry="'||RegEntry||'", RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	  
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then 
    win_api.Register_function_call(iGetRegKey,'d2kwutil_GetRegKey','INT','INT,*CHAR,*CHAR,*CHAR,INT,INT');  
    -- Which Root?
    vcRoot  := upper(substr(RegPath,1,instr(RegPath,'\')-1));
    if      vcRoot =  'HKEY_LOCAL_MACHINE' then 
      iBuff1 := 0;
    elsif   vcRoot =  'HKEY_CLASSES_ROOT' then 
      iBuff1 := 1;
    elsif   vcRoot =  'HKEY_CURRENT_USER' then 
      iBuff1 := 2;
    elsif   vcRoot =  'HKEY_USERS' then
      iBuff1 := 3;
    elsif   vcRoot =  'HKEY_CURRENT_CONFIG' then
      iBuff1 := 4;      
    else
      WIN_API.Add_error('Read_Registry','Invalid Registry Key '||RegPath);
      if  RaiseExceptions then
        raise NO_DATA_FOUND;
      end if;  
    end if;

    iBuff2     := 2000; /* Length of buffer */
    vcBuff1    := substr(RegPath,instr(RegPath,'\')+1);
    vcBuff2    := RegEntry;
    vcBuff3    := RPAD(SUBSTR(NVL(vcBuff3,' '),1,2000),2000,CHR(0));
    if not WIN_API.COMPAT_EXPAND_REG_VALUES then 
    	iBuff3 := 1;
    	Win_API_Debug.DebugLog(99,'Read_Registry','Compatibility: Reg Value expansion supressed');	  
    else
    	iBuff3 := 0;
    end if;
    
    iRC        := d2kwutil_GetRegKey(win_api.FunctionHandle(iGetRegKey),iBuff1,vcBuff1,vcBuff2,vcBuff3,iBuff2,iBuff3);
    Win_API_Debug.DebugLog(99,'Read_Registry','Result:  RC='||to_char(iRC)||', vcBuff3="'||vcBuff3||'"');	      
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = -1  then 
    Win_API.Add_error('Read_Registry','Cannot read  entry '||RegPath||'->'||RegEntry);
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;
  elsif iRC = -2 then
    Win_API.Add_error('Read_Registry', RegPath||'->'||RegEntry||' is an unsupported datatype');
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;
  elsif iRC = -3 then
    Win_API.Add_error('Read_Registry',RegPath||'->'||RegEntry||' is longer than '||to_char(iBuff2)||' Bytes');
    if not RaiseExceptions then
      return NULL;
    else 
      raise VALUE_ERROR;
    end if;
  elsif iRC = -4 then
    Win_API.Add_error('Read_Registry', RegPath||'->'||RegEntry||' Failed to expand environment string');
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;    
  end if;
  return vcBuff3;
exception
  when NO_DATA_FOUND then 
    raise;
  when VALUE_ERROR then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Read_Registry',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Read_Registry',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Read_Registry;
```

#### SP-076 - REGISTER_FUNCTION_CALL

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Ensures that a named DLL function is registered and ready for use via the Oracle Foreign Function Interface. It verifies the DLL is loaded (attempting to load it if not), checks whether the function needs re-registration, registers the function's parameter types and return type, and records the current DLL load count to avoid unnecessary future re-registrations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| FunctionID | PLS_INTEGER | IN |
| FunctionName | VARCHAR2 | IN |
| FunctionReturn | VARCHAR2 | IN |
| FunctionArgs | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-067](#SP-067--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-068](#SP-068--ADD_EXTERNAL_ERRORS)) - matched by member name
- D2KWUTIL.ATTEMPT_DLL_LOAD ([SP-001](#SP-001--D2KWUTIL.ATTEMPT_DLL_LOAD)) - D2KWUTIL.pck (or .pld)
- D2KWUTIL.TRANSLATETYPE ([SP-011](#SP-011--D2KWUTIL.TRANSLATETYPE)) - D2KWUTIL.pck (or .pld)
- DEBUGLOG ([SP-071](#SP-071--DEBUGLOG)) - matched by member name
- WEBUTIL.LENGTH ([SP-050](#SP-050--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)
- WEBUTIL.REGISTER_FUNCTION ([SP-058](#SP-058--WEBUTIL.REGISTER_FUNCTION)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Attempt to locate the DLL using its library name; if the DLL is not currently loaded, attempt to load it from the configured path; if loading fails, mark the API as disabled and raise NO_DATA_FOUND.
- Step 2 - Compare the cached DLL load count for this function against the current DLL load count; if they differ (DLL was reloaded) or if the function has never been registered, proceed to register.
- Step 3 - Register the function handle with the DLL using the Oracle FFI.
- Step 4 - Log the registration action (initial or re-registration) for diagnostic purposes (except for the debug string function itself, to avoid infinite recursion).
- Step 5 - Parse the comma-separated list of parameter type names; for each parameter, translate the type name to an FFI type constant and register the parameter.
- Step 6 - If the function has a non-void return type, translate and register the return type.
- Step 7 - Store the current DLL load count for this function to prevent unnecessary future re-registrations.

---
**Decision Points**

DP-001

Condition:
Whether the DLL is currently found by the Oracle FFI library lookup.

TRUE:
Proceed to check whether the function needs re-registration.

FALSE:
Attempt to load the DLL; if loading fails, mark API disabled, record error, and raise NO_DATA_FOUND.

DP-002

Condition:
Whether the function has not yet been registered, or whether the DLL was reloaded since the last registration (load count mismatch).

TRUE:
Register the function, its parameters, and return type with the Oracle FFI.

FALSE:
Skip registration - the function is already registered and the DLL has not been reloaded.

DP-003

Condition:
Whether the function has a non-void, non-null return type.

TRUE:
Translate the return type string and register it with the Oracle FFI.

FALSE:
Skip return type registration (the function returns void or has no declared return).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - If the DLL cannot be found or loaded, the Win32 API is marked as unavailable and the calling routine receives NO_DATA_FOUND to prevent further API calls.
- BR-002 - Function registration is skipped when the function has already been registered against the current DLL load - this prevents redundant re-registration on every call.
- BR-003 - When the DLL is reloaded, all previously registered function handles become invalid; this routine automatically re-registers them on the next call.

---
**Implementation Logic**

```plsql

PROCEDURE Register_Function_Call ( FunctionID     in PLS_INTEGER, 
                                   FunctionName   in VARCHAR2,
                                   FunctionReturn in VARCHAR2, 
                                   FunctionArgs   in VARCHAR2) is
  vcArgs  VARCHAR2(200);
  vcFrag  VARCHAR2(10);
  iOffset PLS_INTEGER;   
begin 
   -- See if the DLL has been loaded at all.
   -- if this call to FIND_LIBRARY fails, we'll fall through to the Exception.
   begin
    DLL_HANDLE := ORA_FFI.find_library(DLL_NAME);
  exception
    when ora_ffi.ffi_error then 
      -- Attempt to load the DLL again in a subblock. If this fails
      -- then the API must be disabled and NOT_DATA_FOUND raised
      begin 
          DLL_HANDLE := Attempt_DLL_Load(DLL_Path, DLL_NAME);
      exception
          when ora_ffi.ffi_error then 
            API_ENABLED := FALSE;
              add_error('D2KWUTIL',DLL_NAME||' not found.');
            RAISE NO_DATA_FOUND;
      end;
  end;

  -- now compare the Cached value for this function's loadcount with 
  -- that for the DLL this tells us that the function has either not 
  -- been registered yet, or that the DLL has been reloaded in between 
  -- times.  This would not be healthy so we have to re-register in that case.
  if (not FunctionLoad.exists(FunctionId)) or (FunctionLoad(FunctionId)<> DLL_LOAD_COUNT) then
    -- We need to go through the registration process.      
    -- Register the function with the DLL
    FunctionHandle(FunctionId) := ora_ffi.register_function(Win_API.DLL_HANDLE,FunctionName,ORA_FFI.C_STD);
    if FunctionName <> 'd2kwutil_DebugString' then 
    	if not FunctionLoad.exists(FunctionId) then 
    		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Initial Reg');
    	else
       		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Re-Registration Count = '||to_char(FunctionLoad(FunctionId)));
       	end if;
    end if;
    
    -- Loop through and register the parameters
    vcArgs := FunctionArgs||',';
    while vcArgs is not null and vcArgs <> ',' and vcArgs <> 'VOID,' LOOP
      iOffset := instr(vcArgs,',');
      vcFrag := substr(vcArgs,1,iOffset-1);
      ora_ffi.register_parameter(FunctionHandle(FunctionId),TranslateType(vcFrag));
      if iOffset = length(vcArgs) then
        vcArgs := NULL;
      else
        vcArgs := substr(vcArgs,iOffset+1);
      end if;
    end LOOP;
    
    -- Register the return type IF this is a function
    if upper(FunctionReturn) <> 'VOID' and FunctionReturn is not NULL then 
      ora_ffi.register_return(FunctionHandle(FunctionId),TranslateType(FunctionReturn));
    end if;
    
    -- Now add this Function's Loadcount to the array to prevent un-nessary re-registration
    FunctionLoad(FunctionId) := DLL_LOAD_COUNT;
  end if;
exception
   when ora_ffi.ffi_error then
    Win_API.Add_error(FunctionName, Win_API.UError||WIN_API.Add_External_errors); 
    raise NO_DATA_FOUND;
end Register_Function_Call;
```

#### SP-077 - SETDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Configures the debug logging mode, log file path, threshold level, and timestamp option for the Win32 API debug logging system. Calling this routine either starts file logging, starts Win32 debug-window logging, or stops debug logging entirely, depending on the debug type specified.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugType | PLS_INTEGER | IN |
| DebugFile | VARCHAR2 | IN |
| DebugLevel | PLS_INTEGER | IN |
| TimeStamp | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-071](#SP-071--DEBUGLOG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Store the timestamp flag, debug file path, and debug level threshold in the global debug configuration variables.
- Step 2 - Evaluate the debug type: if type 1, set the debug state to file logging and log a startup message noting the file name.
- Step 3 - If type 2, set the debug state to Win32 debug-window logging and log a startup message.
- Step 4 - If any other type, log a shutdown message and set the debug state to disabled (0).

---
**Decision Points**

DP-001

Condition:
Whether the debug type is 1 (file logging mode).

TRUE:
Set the debug state to file-logging mode and write a startup diagnostic entry to the file.

FALSE:
Check for debug type 2.

DP-002

Condition:
Whether the debug type is 2 (Win32 debug-window mode).

TRUE:
Set the debug state to debug-window mode and write a startup diagnostic entry.

FALSE:
Log a "Logging Stopped" message and set the debug state to 0 (disabled).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only type codes 1 (file) and 2 (debug window) activate logging; any other value disables it.
- BR-002 - The timestamp and debug level settings are always applied regardless of the debug type, ensuring they take effect immediately when logging is next enabled.

---
**Implementation Logic**

```plsql

PROCEDURE SetDebug( DebugType   IN PLS_INTEGER, 
                    DebugFile   IN VARCHAR2 DEFAULT NULL, 
                    DebugLevel  IN PLS_INTEGER DEFAULT 98,                        
                    TimeStamp   IN BOOLEAN DEFAULT FALSE) is
begin 
    bDebugTimeStamp := TimeStamp;
    vcDebugFile     := DebugFile;
    iDebugLevel     := DebugLevel;
	if DebugType = 1 then 
		iDebugState := 1;
		DebugLog(0,'SetDebug','Logging to File '||DebugFile);
	elsif DebugType = 2 then
		iDebugState := 2;
		DebugLog(0,'SetDebug','Logging Started');
	else 
        DebugLog(0,'SetDebug','Logging Stopped');
        iDebugState := 0;
	end if;
end SetDebug;
```

#### SP-078 - SF_COPYRIGHT_DECLARATION

**Invoked From:**

- rr_pre_enq_dlr_fmb.xml [Trigger: KEY-CLRFRM]
- rr_pre_enq_dlr_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

N/A

---

**Purpose**

Returns the copyright declaration text for the current financial year on behalf of Maruti Suzuki India Limited. The returned text is displayed on screen to inform users of the applicable copyright notice each time the form is cleared.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Capture the current system date.
- Step 2 - Determine the financial year: if the current month is January, February, or March, use the previous calendar year as the financial year start; otherwise use the current calendar year.
- Step 3 - Compose the copyright string using the determined year and the company name "Maruti Suzuki India Limited".
- Step 4 - Return the formatted copyright string.

---
**Decision Points**

DP-001

Condition:
Whether the current month is January, February, or March (i.e., within the first quarter of the calendar year, which falls in the previous financial year).

TRUE:
Use the previous calendar year (current year minus one) as the financial year for the copyright notice.

FALSE:
Use the current calendar year as the financial year for the copyright notice.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The financial year for the copyright declaration starts in April; months January through March belong to the financial year that started in the previous April.
- BR-002 - The copyright holder is always "Maruti Suzuki India Limited" and is hard-coded in the function.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
function sf_copyright_declaration return varchar is
a varchar2(50);
dt date;
begin
--Modified by Prerna on 16-May-11  to display current Financial Year Copyright
dt := sysdate;

    if( to_char(dt,'MON') in ('JAN','FEB','MAR')) then
        a := '- '||to_char(to_number(to_char(dt,'RRRR')) - 1)||' Maruti Suzuki India Limited ';
    else
        a := '- '||to_char(dt,'RRRR')||' Maruti Suzuki India Limited ';
    end if;
return(a);
end;

```

#### SP-079 - STRIPDIRSEP

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Cleans up a Windows directory path string by removing any text after a semicolon (in case multiple paths were concatenated) and stripping a trailing backslash. This ensures the path is in a consistent, usable format before it is passed to DLL loading or file operations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| InPath | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-050](#SP-050--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the directory path string.
- Step 2 - If the path contains a semicolon, truncate it at the character immediately before the first semicolon, discarding the rest.
- Step 3 - If the resulting path ends with a backslash, remove the trailing backslash.
- Step 4 - Return the cleaned path.

---
**Decision Points**

DP-001

Condition:
Whether the path contains a semicolon character.

TRUE:
Truncate the path to everything before the first semicolon.

FALSE:
Use the path as-is.

DP-002

Condition:
Whether the path ends with a backslash character.

TRUE:
Remove the trailing backslash.

FALSE:
Return the path unchanged.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - If a path list (multiple paths separated by semicolons) is passed, only the first path is used; all subsequent entries are silently discarded.
- BR-002 - The returned path never ends with a backslash; callers that require a trailing backslash must add it themselves.

---
**Implementation Logic**

```plsql

  

Function StripDirSep ( InPath in varchar2) return varchar2 is 
  vcPath  varchar2(500) := InPath;
begin 
  -- Check and Strip SemiColons, we take everything
  -- Before the first Semicolon as our path
  if instr(vcPath,';') > 0 then
    vcPath := substr(vcPath,1,instr(vcPath,';') -1);
  end if;

  -- Check and Strip '\'
  if substr(vcPath,-1,1) = '\' then 
    vcPath := substr(vcPath,1,length(vcPath)-1);
  end if;

  return vcPath;
end StripDirSep;
```

#### SP-080 - VIEW_EXCEL_REPORT_NEW

**Invoked From:**

- rr_pre_enq_dlr_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

N/A

---

**Purpose**

Generates a pre-enquiry campaign report as a CSV file and delivers it to the user's desktop. It queries the report server configuration to determine whether to use a remote database procedure or local in-memory processing to build the CSV, then transfers the resulting file to the client machine and opens it automatically.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_principal | number | IN |
| p_file_name | VARCHAR2 | IN |
| p_query | VARCHAR2 | IN |
| p_column_name | VARCHAR2 | IN |
| p_app_id | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.FCLOSE ([SP-025](#SP-025--WEBUTIL.FCLOSE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.FILE_SAVE_DIALOG ([SP-026](#SP-026--WEBUTIL.FILE_SAVE_DIALOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.FOPEN ([SP-028](#SP-028--WEBUTIL.FOPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_LINE ([SP-041](#SP-041--WEBUTIL.GET_LINE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.HOST ([SP-044](#SP-044--WEBUTIL.HOST)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ID_NULL ([SP-045](#SP-045--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.PUTF ([SP-053](#SP-053--WEBUTIL.PUTF)) - WEBUTIL.pck (or .pld)
- WEBUTIL.URL_TO_CLIENT ([SP-064](#SP-064--WEBUTIL.URL_TO_CLIENT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Look up the report server identifier for the current principal and application ID from the EH_REPORTS configuration table; if not found, set the server identifier to null.
- Step 2 - Determine the output filename: if no filename was supplied, show the user a Save File dialogue; otherwise use the supplied filename appended with ".csv".
- Step 3 - If the filename path contains spaces, redirect the file to the C:\ root directory and warn the user.
- Step 4 - **Report-server path:** Call the remote CSV generation procedure over the database link to produce the file; move the output file from the UTL_DIR location to the reports printer directory using a host shell command; read the base download URL from the server configuration file; combine the URL with the filename to form the download path; transfer the file to the user's desktop using WebUtil; if the transfer fails, show a failure message; open the file on the client using the default application.
- Step 5 - **Local path (no report server):** Determine the output filename using the same filename logic; check whether a record group with the working name already exists and delete it if so; create a new record group from the provided query; populate the record group and determine the number of rows; read the base download URL from the server configuration file; open the server-side output file for writing; loop through all rows and write each formatted row to the file; close the output file; transfer the file to the user's desktop; if the transfer fails, show a failure message; open the file on the client.
- Step 6 - If any exception occurs, display an error message with the error code and text, and raise a form trigger failure.

---
**Decision Points**

DP-001

Condition:
Whether the EH_REPORTS table contains a report server entry for the current principal and application ID.

TRUE:
Use the remote database procedure path to generate the CSV (report server is available).

FALSE:
Use the local in-memory record group path to generate the CSV.

DP-002

Condition:
Whether the supplied output filename is null.

TRUE:
Show the user a Save File dialogue to obtain a destination filename.

FALSE:
Use the supplied filename, appended with ".csv".

DP-003

Condition:
Whether the output filename or path contains one or more space characters.

TRUE:
Redirect the output file to the C:\ root directory and show a warning message to the user.

FALSE:
Use the original filename and path.

DP-004

Condition:
Whether the file transfer to the user's desktop succeeded.

TRUE:
Open the transferred file on the client desktop.

FALSE:
Show the user a "File Transfer failed" message.

DP-005

Condition:
Whether a record group with the working name already exists in memory (local path only).

TRUE:
Delete the existing record group before creating a new one.

FALSE:
Proceed directly to create the record group from the query.

---
**Database Interactions**

- DB-001 - Read EH_REPORTS - Reads data from EH_REPORTS for lookup or validation.
**Business Rules**

- BR-001 - If a report server is configured in EH_REPORTS, the CSV is always generated remotely; local generation is used only when no server is configured.
- BR-002 - Output file paths containing spaces are silently redirected to C:\ to prevent file-save failures from folder names with spaces.
- BR-003 - A failed file transfer to the client always results in a visible failure message; the report is not silently discarded.
- BR-004 - Any unhandled exception during report generation causes the form to display an error message and halt the current action via FORM_TRIGGER_FAILURE.

---
**Implementation Logic**

```plsql
PROCEDURE view_excel_report_new(p_principal number,p_file_name VARCHAR2, p_query VARCHAR2,p_column_name VARCHAR2,p_app_id VARCHAR2) IS
	rg_name 				 		VARCHAR2(40) := 'DataRecordSet'; 
	rg_id 					 		RecordGroup; 
	gc_id 					 		GroupColumn; 
	errcode 				 		NUMBER; 
	the_rowcount 		 		NUMBER; 
  FILENAME			   		VARCHAR2(4000);
  MYFILE 					 		TEXT_IO.FILE_TYPE;
  urlFile 					 	TEXT_IO.FILE_TYPE;
  urlPath							VARCHAR2(5000);
	V_STRING 				 		VARCHAR2(4000);
	l_alert 				 		NUMBER;
	server_file      		VARCHAR2(2000);
	file_transfer_bool	BOOLEAN;
	formserverpath   		VARCHAR2(2000);
	lv_err_reas			varchar2(2000);
	lv_cmd	varchar2(1000);
	lv_rep_server	varchar2(50);

begin
			begin
				select rep_server into lv_rep_server from eh_reports
				where principal_map_cd=p_principal
				and   app_id=p_app_id;
			exception
				when others then
				 lv_rep_server:=null;
			end;	

if lv_rep_server is not null then
		
			If p_file_name is null then
				FILENAME  := Webutil_file.FILE_SAVE_DIALOG;
			Else
			  FILENAME := p_file_name;
			End If;
  
  		FILENAME:=p_file_name||'.csv';
  
			 	If instr(FILENAME,' ') > 0 then
			 		FILENAME := 'C:\'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
			 		Message('File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default.');
			 		message('  ');
			 	end if;
 	
			sp_csv_report_generate@dms1_db3_lnk(FILENAME,p_query,errcode,lv_err_reas);
			
			host('/bin/mv /utl_dir/'||FILENAME||' /iashome/ias/reports/printer/'||FILENAME);
			
			server_file := '/iashome/ias/reports/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	
			urlFile := Text_Io.Fopen('/reports/DMS/excelpath.txt','R');
			Text_Io.Get_Line(urlFile,urlPath);
			Text_Io.Fclose(urlFile);
			formserverpath := urlPath||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);

 		file_transfer_bool := WebUtil_File_Transfer.Url_To_Client(formserverpath,FILENAME);
	 	
	 	if not file_transfer_bool  then 
	 		message('File Transfer failed');pause;
	 	end if;
	 	
	WebUtil_Host.HOST('cmd /c '||FILENAME);
	
else
  If p_file_name is null then
		FILENAME  := Webutil_file.FILE_SAVE_DIALOG;
  Else
    FILENAME := p_file_name;
  End If;
 	If instr(FILENAME,' ') > 0 then
 		FILENAME := 'C:\'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
 		Message('File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default.');
 		message('  ');
 	end if;
	rg_id := Find_Group( rg_name ); 
	IF NOT Id_Null(rg_id) THEN 
		Delete_Group( rg_id ); 
	END IF; 
	rg_id := Create_Group_From_Query( rg_name, p_query ); 
	errcode := Populate_Group( rg_id ); 
	the_rowcount := Get_Group_Row_Count( rg_id );
	server_file := '/iashome/ias/reports/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	urlFile := Text_Io.Fopen('/reports/DMS/excelpath.txt','R');
	Text_Io.Get_Line(urlFile,urlPath);
	Text_Io.Fclose(urlFile);
	formserverpath := urlPath||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	MYFILE := TEXT_IO.FOPEN(server_file, 'W');
	gc_id := Find_Column( rg_name||'.'||p_column_name); 	
	for total_loop IN 1..the_rowcount
		loop
	  	V_STRING :=  GET_GROUP_CHAR_CELL(gc_id  , total_loop )||CHR(10); 
	  	TEXT_IO.PUTF(MYFILE,V_STRING);  
		end loop;
	 	TEXT_IO.FCLOSE(MYFILE);
	 	file_transfer_bool := WebUtil_File_Transfer.Url_To_Client(formserverpath,FILENAME);
	 	if not file_transfer_bool  then 
	 		message('File Transfer failed');pause;
	 	end if;
	 	WebUtil_Host.HOST('cmd /c '||FILENAME);	 		
	 		
end if;

exception
	when others then
	Message('Error  - '||ERROR_CODE|| ERROR_TEXT);
	Raise Form_trigger_failure;
end;
```

#### SP-081 - WINDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sends a diagnostic text string to the Win32 debug output window by registering and invoking the d2kwutil DLL function D2KWUTIL.D2KWUTIL_DEBUGSTRING. This is the final output step used by the debug logging system when operating in Win32 debug-window mode, allowing developers to monitor form activity in real time using a Windows debugger tool.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-067](#SP-067--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-068](#SP-068--ADD_EXTERNAL_ERRORS)) - matched by member name
- D2KWUTIL.D2KWUTIL_DEBUGSTRING ([SP-005](#SP-005--D2KWUTIL.D2KWUTIL_DEBUGSTRING)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- REGISTER_FUNCTION_CALL ([SP-076](#SP-076--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Append a newline character (CHR(10)) to the supplied text to form the complete debug output line.
- Step 2 - Check whether the Win32 API is currently enabled via WIN_API.API_ENABLED.
- Step 3 - If enabled, call REGISTER_FUNCTION_CALL (SP-076) to register the debug-string DLL function handle for iDebugString, binding it to 'd2kwutil_DebugString' with a CHAR return type.
- Step 4 - Invoke D2KWUTIL.D2KWUTIL_DEBUGSTRING (SP-005) using the registered function handle and the formatted text buffer to write the message to the Win32 debug output window.
- Step 5 - If the Win32 API is not enabled, raise the WIN_API.NOT_AVAILABLE exception.
- Step 6 - On a WIN_API.NOT_AVAILABLE exception, call ADD_ERROR (SP-067) to record the error with the 'WinDebug' context and the NoAPI error code, then re-raise.
- Step 7 - On any other exception, call ADD_ERROR (SP-067) to record the error with the 'WinDebug' context and the UError code concatenated with the output of ADD_EXTERNAL_ERRORS (SP-068), then re-raise.

---
**Decision Points**

DP-001

Condition:
Whether WIN_API.API_ENABLED is TRUE at the time of invocation.

TRUE:
Register the DLL function via REGISTER_FUNCTION_CALL and invoke D2KWUTIL.D2KWUTIL_DEBUGSTRING to write the debug message to the Win32 output window.

FALSE:
Raise the WIN_API.NOT_AVAILABLE exception, which is caught by the exception handler, logged via ADD_ERROR, and re-raised.

---

DP-002

Condition:
Whether the exception raised is WIN_API.NOT_AVAILABLE or a different (unexpected) error.

TRUE (WIN_API.NOT_AVAILABLE):
Record the error using ADD_ERROR with the NoAPI error code and re-raise.

FALSE (any other exception):
Record the error using ADD_ERROR with the UError code appended with external error details from ADD_EXTERNAL_ERRORS, and re-raise.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A newline character (CHR(10)) is always appended to the input text before it is sent to the Win32 debug window, ensuring each message appears on its own line.
- BR-002 - The DLL function handle must be registered via REGISTER_FUNCTION_CALL before D2KWUTIL.D2KWUTIL_DEBUGSTRING can be called; registration specifies the function name 'd2kwutil_DebugString' and a CHAR parameter type.
- BR-003 - If the Win32 API is unavailable, the routine raises an exception and cannot fall back to any alternative output mechanism.
- BR-004 - All exceptions are re-raised after being recorded, ensuring that error awareness propagates to the calling routine DEBUGLOG without silent failure.
- BR-005 - Unexpected errors are enriched with external error details retrieved via ADD_EXTERNAL_ERRORS before being logged, providing additional diagnostic context beyond the internal error code.

---
**Implementation Logic**

```plsql
  

  
PROCEDURE WinDebug  (  Text  IN   VARCHAR2) is
  vcBuff1 VARCHAR2(2000) := Text||chr(10);
begin 
  --WIN_API.Clean_Error_Stack;
  if Win_API.API_ENABLED then
    win_api.Register_function_call(iDebugString,'d2kwutil_DebugString',NULL,'*CHAR');
    d2kwutil_DebugString(win_api.FunctionHandle(iDebugString),vcBuff1);
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if; 
exception
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('WinDebug',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('WinDebug',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end WinDebug;
```

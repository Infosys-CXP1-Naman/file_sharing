# BUSINESS REQUIREMENTS DOCUMENT

## Table of Contents

- 1. Document Control
  - 1.1 Document Information
  - 1.2 Revision History
- 2. Executive Summary
  - Key Stakeholders
- 3. System Context
- 4. Functional Requirements
  - 4.1 Business Requirements
    - Requirement ID: BR-001
    - Requirement ID: BR-002
    - Requirement ID: BR-003
    - Requirement ID: BR-004
    - Requirement ID: BR-005
    - Requirement ID: BR-006
    - Requirement ID: BR-007
    - Business Scenarios - How the edit-mode filter differs by parts category
    - Requirement ID: BR-008
    - Business Scenarios - How the filter behaves by category and edit-mode combination
    - Requirement ID: BR-009
    - Requirement ID: BR-010
    - Business Scenarios - How sorting differs by selected column
    - Requirement ID: BR-011
    - Business Scenarios - How editability differs by part family age and category
    - Requirement ID: BR-012
    - Business Scenarios - How the quantity rule differs by decimal-quantity setting
    - Requirement ID: BR-013
    - Requirement ID: BR-014
    - Business Scenarios - How the supplier list differs by session mode
    - Requirement ID: BR-015
    - Requirement ID: BR-016
    - Requirement ID: BR-017
    - Requirement ID: BR-018
    - Requirement ID: BR-019
    - Requirement ID: BR-020
    - Requirement ID: BR-021
    - Requirement ID: BR-022
    - Requirement ID: BR-023
    - Requirement ID: BR-024
    - Requirement ID: BR-025
    - Requirement ID: BR-026
    - Requirement ID: BR-027
    - Requirement ID: BR-028
- 5. Business Rules Catalogue
- 6. Data Requirements
  - 6.1 Business Entities and Relationships
    - Suggested Order Quantity Record - PT_SOQ_MUL_TIL
    - Entity Relationships
  - 6.2 Data Capture Requirements
    - Filter and Configuration (Main Panel)
    - Location Selection
    - SOQ Parts List (Amendable Data)
    - Consumption Detail (Per Location)
    - PO Details (Supplier and Status)
    - Report Date Selection
    - Session / Control Parameters
  - 6.3 Reference Data
  - 6.4 Data Lifecycle
  - 6.5 Excel Output Columns
- 7. Glossary
- 8. Technical Inventory
  - 8.1 Form Architecture
    - 8.1.1 Global Variables
    - 8.1.2 Form Parameters
  - 8.2 Blocks
    - 8.2.1 Block WhereClause and OrderByClause
  - 8.3 Items Summary
  - 8.4 List of Values
  - 8.5 Alerts
  - 8.6 Program Units
  - 8.7 Triggers
    - 8.7.1 Inactive / Commented-Out Trigger Register
  - 8.8 Canvas and Window Inventory
  - 8.9 Editors
  - 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups
    - 8.10.1 Visual Attributes (form-defined)
    - 8.10.2 Property Classes (form-defined)
    - 8.10.3 Object Groups
  - 8.11 DataSourceColumn Inventory
    - B_SOQ (18 columns)
- 9. Object Library
- 10. Record Groups
- 11. Referenced Database Objects
- 12. Backend Procedures and Packages
  - 12.1 Main Flow Backend Procedure/Package Index
  - 12.2 Procedure and Package Catalogue
- 13. Package Procedure Specifications
- 14. Database Package Catalogue
- 15. PLD Procedure Call Sites
  - DPL.pld (`general`)
- 16. Microservice API Candidates
  - 16.1 Microservices with APIs
- 17. Workflows
- 18. PLD-Backed Logic
  - DPL.pld (`general`)
  - D2kwutil.pld (`Win_API`)
- 19. PCK-Backed Logic
- 20. System Interfaces
  - 20.1 Database Integrations
  - 20.2 External System Integrations
  - 20.3 Report Integrations
    - 20.3.1 Parameters Passed to the Report
- 21. Procedure and Function Business Rule Catalogue
  - 21.1 Catalogue Index
  - 21.2 Detailed Specifications
    - SP-001 - FETCH_LOC
    - SP-002 - GET_LAST_SOQ_DATE
    - SP-003 - LOC_CATEG_POPULATION
    - SP-004 - SORT_BLOCK
    - SP-005 - UPDATE_PO_STOCK
    - SP-006 - VIEW_EXCEL_REP
    - SP-007 - D2KWUTIL.ADD_ERROR
    - SP-008 - D2KWUTIL.ADD_EXTERNAL_ERRORS
    - SP-009 - D2KWUTIL.ATTEMPT_DLL_LOAD
    - SP-010 - D2KWUTIL.BOOLTOCHAR
    - SP-011 - D2KWUTIL.CLEAN_ERROR_STACK
    - SP-012 - D2KWUTIL.CREATED_DATE
    - SP-013 - D2KWUTIL.D2KWUTIL_DEBUGSTRING
    - SP-014 - D2KWUTIL.D2KWUTIL_FILEINFO
    - SP-015 - D2KWUTIL.DEBUGLOG
    - SP-016 - D2KWUTIL.FILE_INFO
    - SP-017 - D2KWUTIL.REGISTER_FUNCTION_CALL
    - SP-018 - D2KWUTIL.SETDEBUG
    - SP-019 - D2KWUTIL.STRIPDIRSEP
    - SP-020 - D2KWUTIL.TRANSLATETYPE
    - SP-021 - D2KWUTIL.WINDEBUG
    - SP-022 - GENERAL.ASK_CONFIRM
    - SP-023 - GENERAL.CHECK_FORM_FAILURE
    - SP-024 - GENERAL.CHECK_NULL
    - SP-025 - GENERAL.DISP_TEXT
    - SP-026 - GENERAL.L_POP_LIST_ITEM
    - SP-027 - GENERAL.RAISE_ERROR
    - SP-028 - PKG_DS_AUTO_CLEARANCE.FN_GET_PEND_ORDER
    - SP-029 - PKG_DS_AUTO_CLEARANCE.SP_DEADSTK_PO_SO
    - SP-030 - PK_VALIDATE_PARTS.UPDATE_ON_ORDER
    - SP-031 - SF_COPYRIGHT_DECLARATION
    - SP-032 - SP_CALCULATE_SOQ_IMS
    - SP-033 - SP_INSERT_PM_PART_VAR
    - SP-034 - SP_SOQ_POPULATE_CONSUMPTION
    - SP-035 - SP_UPDATE_PART_PRICE
    - SP-036 - SP_UPDATE_PO_NUMBER_NEW

## 1. Document Control

### 1.1 Document Information

| Field | Value |
| ----- | ----- |
| Document Title | PT_SOQ_IMS - Business Requirements Document |
| Form Module Name | PT_SOQ_IMS |
| Document Version | 1.0 |
| Date Created | August 07, 2026 |
| Author/Prepared By | BRD Agent |

### 1.2 Revision History

| Version | Date | Author | Description |
| --- | --- | --- | --- |
| 1.0 | August 07, 2026 | BRD Agent | Initial draft |

---

## 2. Executive Summary

*High-level overview of the pt_soq_ims Suggested Order Quantity (IMS) form, its purpose, and roles referenced in the module.*

The **pt_soq_ims** Oracle Forms module is the **Suggested Order Quantity (IMS)** screen used by dealerships to review and amend system-generated order recommendations for automotive spare parts. A Parts Manager or Inventory Controller opens the form, selects a part category, optionally adjusts the number of consumption months and the display filters (including whether to show parts with zero suggested quantities), and chooses which dealer locations to include. The form then presents the parts list showing each part's current stock, on-order quantity, average consumption, and the system-suggested order quantity. The user may override the suggested quantity for any editable part line. Once satisfied, the user selects a supplier and a purchase order status, then saves the record - at which point all amended quantities are validated and persisted as on-order stock against the parts master. A consumption detail view is available for any part to inspect the last twelve months of stock movement before deciding on the final order quantity. A print option generates a formal SOQ report for the selected date.

### Key Stakeholders

*Who uses pt_soq_ims*

| Stakeholder | Role |
| :--- | :--- |
| **Parts Manager / Inventory Controller** | **Primary interactive user.** Reviews the system-generated order recommendations, applies consumption-based analysis, adjusts individual part order quantities, selects the supplier, and commits the amended order. |
| **Supplier / Party** | Supplier whose party code and name are selected during the order submission; the supplier does not interact with the form directly. |
| **Dealer / Dealership** | Business entity whose stock, location, and parts master data is displayed and updated by the order process. |

---

---

## 3. System Context

*Describes the pt_soq_ims module's role within the DMS ecosystem, scope, process flow, and key integrations.*

The **pt_soq_ims** module is the **Suggested Order Quantity (IMS)** screen in the Dealer Management System. It is the point where inventory controllers review system-computed parts order recommendations, apply consumption-based analysis across multiple dealer locations, amend individual order quantities, and commit the final order to the parts master. The form connects the SOQ calculation service with the supplier selection and on-order inventory update workflows.

**System purpose:** Review and amend system-generated spare parts order recommendations for the selected category and dealer location, validate the order quantities and supplier, and persist the amended on-order stock - as implemented in the pt_soq_ims Oracle Forms module.

**In scope:**

- Select the part category and configure display filters (number of consumption months, show-zero-SOQ flag, edit-list, stock-yard mode)
- Select and review available dealer locations for inclusion in the order calculation
- Query the SOQ data list showing suggested quantities, on-hand stock, on-order quantities, and average consumption per part
- View monthly consumption history (last 12 months) for any individual part across all selected locations
- Override the system-suggested order quantity for eligible parts
- Sort the SOQ list by part number, suggested quantity, amended quantity, purchase price, or total value
- Select a supplier from the party master and confirm the purchase order status
- Save and persist amended order quantities as on-order records against the parts inventory
- Generate and print a formal SOQ report for the selected as-on date

**Process Name:** Suggested Order Quantity Review and Amendment

**Process Owner:** Parts Manager / Inventory Controller

**Process Objective:** Open the SOQ screen for the selected category, review system-generated order recommendations by location, amend quantities where required, select the supplier, and commit the updated on-order stock before purchase order creation begins.

**Process Trigger:** Periodic SOQ review cycle initiated by the Parts Manager after the system SOQ population process has completed

**Process Flow:**

The complete suggested order quantity review and amendment process follows this sequence. Each step corresponds to Functional Requirements in Section 4.

```
STEP 1 ── SCREEN OPENS
         The inventory controller opens the pt_soq_ims form.
         The session is registered, the last SOQ run date is retrieved, and
         the category field is prepared for input.

STEP 2 ── CATEGORY SELECTION
         The user selects a part category code from the category field.
         The system validates that a category is entered before allowing
         further navigation.

STEP 3 ── CONFIGURE CONSUMPTION MONTHS
         The user confirms or adjusts the number of months of consumption
         history to include in the calculation (default applies if unchanged).
         The system rejects blank entry.

STEP 4 ── CONFIGURE STOCK-YARD MODE
         The user checks or unchecks the stock-yard checkbox.
         ├── STOCK-YARD ON: all live dealer locations for the consignee
         │                  are loaded into the location selection list.
         └── STOCK-YARD OFF: only the current active location is loaded.

STEP 5 ── LOCATION SELECTION
         The location list displays all available dealer locations.
         The user selects which locations to include by checking individual rows.
         At least one location must be selected before proceeding.

STEP 6 ── CONFIGURE DISPLAY FILTERS
         The user sets the show-zero-SOQ checkbox to include or exclude
         parts with a zero suggested quantity.
         The user sets the edit-list dropdown to show all parts (A),
         editable parts only (E), or non-editable parts only.

STEP 7 ── SOQ LIST QUERY EXECUTES
         The system retrieves the SOQ data for the active dealer, parent group,
         location, and selected category.
         Only records with a positive suggested quantity are shown by default
         unless the show-zero flag is set.

STEP 8 ── REVIEW SOQ LIST
         The list displays part number, description, on-hand quantity,
         on-order quantity, system-suggested quantity, average consumption,
         purchase price, and total value per part row.
         Parts whose family age indicates they are non-orderable are locked
         against amendment.

STEP 9 ── VIEW CONSUMPTION DETAIL (optional - per part)
         The user selects a part row and presses the consumption button.
         The system iterates over all selected locations, calls the consumption
         calculation service for each, and populates the detail panel with
         monthly stock movement figures for up to 12 months per location.

STEP 10 ── SORT SOQ LIST (optional)
          The user changes the sort-by or sort-direction dropdown.
          The system re-sorts the list by the chosen field (part number,
          suggested quantity, amended quantity, purchase price, or value)
          without losing pending amendments.

STEP 11 ── AMEND ORDER QUANTITIES
          The user enters or modifies the amended order quantity for
          eligible part rows.
          The system enforces whole-number rounding for parts where
          decimal quantities are not permitted.

STEP 12 ── REVIEW TOTALS
          The form recalculates the total order value (amended quantity
          multiplied by purchase price) for each row and accumulates the
          grand total displayed in the supplier block.

STEP 13 ── SUPPLIER SELECTION
          The user navigates to the supplier block and selects a supplier
          from the party list (multi-location or standard depending on mode).
          The system validates the entered supplier code and resolves the
          supplier name.

STEP 14 ── PURCHASE ORDER STATUS
          The user confirms the purchase order status (raise PO or hold).
          The system validates that the status field is not blank.

STEP 15 ── SAVE
          The user commits the record.
          The system validates that all mandatory fields (category, PO status)
          are populated, then calls the on-order update service with the full
          list of amended part quantities.
          ├── SUCCESS: On-order quantities are updated in the parts master;
          │            the form clears and resets to the initial state.
          └── FAILURE: An error message is displayed; the save is prevented
                       and the user must correct the reported issue.

STEP 16 ── PRINT REPORT (optional)
          The user navigates to the print block, enters the as-on date,
          and presses the report button.
          The system generates the SOQ print report for the selected date.
```

**Major process interactions:**

- **Suggested Order Quantity data store** - source of pre-computed SOQ records queried and updated by the form
- **Dealer location master** - provides the list of active dealer locations for the consignee to scope the order
- **Parts master** - supplies part descriptions, purchase prices, decimal-quantity rules, and minimum order quantities for each SOQ line
- **Consumption calculation service** - computes monthly stock movement history for each part and location on demand
- **On-order inventory** - receives the amended order quantities and updates part-level on-order stock on commit
- **Supplier / party master** - provides the lookup for supplier selection and name resolution
- **SOQ report** - generates a printable summary of the confirmed order for the selected as-on date

---

---

## 4. Functional Requirements

### 4.1 Business Requirements

#### Requirement ID: BR-001

**Requirement Title:** Form Session Registration

**Business Description:**
When the Suggested Order Quantity Processing form is launched, the system registers the active session under this form's identity so that application-level monitoring and audit tools can track which form is currently running for the logged-in user. This happens invisibly before any data or screen is shown to the user.

**Actors:** System (automated on form launch)

**Preconditions:**
- The user has opened the Suggested Order Quantity Processing form from the application menu.

**Main Flow:**

**Step 1 - Session tracking information is registered**
The system automatically records that the Suggested Order Quantity Processing form is now the active form for the current user session, enabling application monitoring tools to identify the module in use. No user action is required.

*Procedures called:*
- **DBMS_APPLICATION_INFO.SET_CLIENT_INFO** - registers the current module name (`pt_soq_ims`) with the database session client-info attribute so that application monitoring can identify this form as the active module.
    * **Step 1** - Record the name of the currently running form against the active database session so that session-monitoring tools can identify which application module the user is in.
- **DBMS_APPLICATION_INFO.SET_MODULE** - registers the module name and clears the action attribute for the session, setting the top-level module name to `pt_soq_ims` and leaving the action field blank.
    * **Step 1** - Set the database session's module name to the name of this form and clear any previously recorded action label, completing the session-identification record.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Copyright Notice (`COPYRIGHT`) | Auto-populated | Character | 100 | N/A | N/A | N/A | System-populated on form clear/initialize | N/A |

---

---

#### Requirement ID: BR-002

**Requirement Title:** Form Initialization - Load Locations, Last SOQ Date, and Default Filters

**Business Description:**
When the Suggested Order Quantity Processing form is initialized (whether on first open or after clearing all data), the system automatically resets all filters and fields to their default values, loads the list of active locations for the current user's dealership, retrieves the date of the most recently completed SOQ calculation for the selected parts category, and applies the standard SOQ data filter. The copyright notice is also refreshed. This initialization ensures the user always begins with a clean, consistent screen ready for order quantity review.

**Actors:** System (automated on form clear/initialize), Dealer Parts User

**Preconditions:**
- The user has launched the form or triggered a full reset of the screen.
- The database session has been registered with the form's identity (`pt_soq_ims`) via the application monitoring hook before the first screen is shown.
- The dealership's consignee code is available in the current session.
- The applicable stock-yard mode flag is available from the session parameters.

**Main Flow:**

**Step 1 - Main application window is maximised**
When the form opens, the main application window (`WN_MAIN`) is automatically expanded to fill the full screen so the user has the maximum available space for the SOQ list.

*Screen: SUGGESTED ORDER QUANTITY PROCESSING (`WN_MAIN` / `CN_MAIN`).*

**Step 2 - Parts Category dropdown is populated from the principal's active categories**
The form builds the Parts Category selection list by querying all active, AOS-flagged part categories for the current principal and loads them into the `Categ` record group. The `sb_title.part_categ` dropdown is then populated from this group and defaulted to category `M`.

*Screen: SUGGESTED ORDER QUANTITY PROCESSING (`WN_MAIN` / `CN_MAIN`).*

**Step 3 - Location session parameters are resolved from the dealer location record**
The system reads the consignee code, stock-yard mode flag (`p_stock_yard`), and location description for the current dealer and location from the dealer location master, and stores these in session parameters for use throughout the form.

*Screen: SUGGESTED ORDER QUANTITY PROCESSING (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Stock-yard mode must be active for this form | WHEN-NEW-FORM-INSTANCE - if `p_stock_yard = 'N'`, shows informational note and exits without validating | On form open | Prevents the form from being used at locations that do not operate a stock yard | *"Take output from Parts ->>transaction ->>stock transfer ->> indent"* displayed; form exits immediately |

**Step 4 - Screen data is cleared and editable fields are enabled**
The form clears all existing on-screen data without prompting to save. The Save button is re-enabled, and the Amended Quantity, Purchase Price, and Part Number columns in the SOQ list are set back to editable so the user can make changes in the next session.

*Screen: SUGGESTED ORDER QUANTITY PROCESSING (`WN_MAIN` / `CN_MAIN`).*

**Step 5 - Default filter values are applied**
The Parts Category filter is preset to the default category and the Show Zero SOQ flag is set to not show parts with zero SOQ. The SOQ population flag is reset to indicate that no SOQ calculation has been run yet. The edit-mode list is re-enabled.

*Screen: SUGGESTED ORDER QUANTITY PROCESSING (`WN_MAIN` / `CN_MAIN`).*

**Step 6 - Active locations are loaded into the location list**
The system queries the dealership's active service locations and populates the location selection list. If the session is running in stock-yard mode (all locations visible), all live locations linked to the consignee are loaded with their check boxes pre-ticked. If the session is in single-location mode, only the user's home location is loaded. The location list is then locked against manual editing.

*Screen: SUGGESTED ORDER QUANTITY PROCESSING (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **FETCH_LOC** ([SP-001](#SP-001--FETCH_LOC)) - FETCH_LOC - loads the list of locations the SOQ calculation should consider and pre-selects them, based on whether the session is operating at stock-yard (all locations) or single-location level. After loading, the location list is locked to prevent manual changes.
    * **Step 1** - Clear any previously loaded location entries from the in-memory location table and unlock the on-screen location list for population.
    * **Step 2** - Navigate to the location list area and remove all existing rows.
    * **Step 3** - If the session is in stock-yard (all-locations) mode, query every active service location for the current consignee and principal that has a live service date recorded; for each location found, write a row into the location list and the in-memory location table with its location code, description, and dealer mapping code, and mark it as selected.
    * **Step 4** - If the session is in single-location mode, write a single row using the current user's home location details only and mark it as selected.
    * **Step 5** - Lock the on-screen location list against further insert, update, or delete; return focus to the main filter area.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Location list load (stock-yard vs single-location mode) | FETCH_LOC [SP-001] - branches on the stock-yard session parameter; stock-yard mode loads all active locations, single-location mode loads only the home location | When the form is initialized or reset | Ensures the correct set of service locations is pre-selected for the SOQ calculation based on how the form was launched | If no locations are retrieved, the list will be empty and the SOQ calculation button will remain unavailable |

**Step 7 - Last SOQ date and category are retrieved**
The system looks up the date when the most recent SOQ was last calculated for the selected parts category and displays it as the "Last SOQ Date" on screen. The SOQ category description is also populated for both the main header and the supplier detail area.

*Screen: SUGGESTED ORDER QUANTITY PROCESSING (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GET_LAST_SOQ_DATE** ([SP-002](#SP-002--GET_LAST_SOQ_DATE)) - GET_LAST_SOQ_DATE - looks up the date of the most recent SOQ record for the current dealership and selected parts category, and populates the "Last SOQ Date" display field and the SOQ category description. If no prior SOQ exists for this category, both fields are left blank.
    * **Step 1** - Query the SOQ history table for the most recent SOQ date, parts category description, and category code matching the current dealership, location, company code, and selected parts category.
    * **Step 2** - Populate the Last SOQ Date field and the SOQ Category description field in both the header area and the supplier detail area with the retrieved values.
    * **Step 3** - If no matching SOQ record is found (no prior calculation for this category), clear the Last SOQ Date and category description fields without displaying an error.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Last SOQ date lookup | GET_LAST_SOQ_DATE [SP-002] - SELECT from PT_SOQ_MUL_TIL joined to PM_CATEGORY; NO_DATA_FOUND sets fields to null; OTHERS also sets fields to null | When the form initializes or resets | Informs the user when the most recent SOQ was run for the selected category, so they can assess whether a recalculation is needed | If no SOQ has been run before, the Last SOQ Date field is simply blank; no error is shown |

**Step 8 - Default SOQ data filter and copyright notice are set**
The system applies a default where-clause to the SOQ parts list (restricting it to the current dealership, parent group, and home location) so that the query will return the correct data when the user runs the calculation. The copyright notice is refreshed with the current financial year.

*Screen: SUGGESTED ORDER QUANTITY PROCESSING (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **SF_COPYRIGHT_DECLARATION** ([SP-009](#SP-009--SF_COPYRIGHT_DECLARATION)) - SF_COPYRIGHT_DECLARATION - returns the current financial-year copyright string and the system stores it in the copyright display field.
    * **Step 1** - Determine the current financial year based on today's date (if the current month is January, February, or March, the financial year is the prior calendar year; otherwise it is the current calendar year).
    * **Step 2** - Construct and return the copyright notice string for the calculated financial year.

**Alternative Flows:**
- **BR-002-AF-01** - (from Step 3) If the location's stock-yard mode flag is not active (`p_stock_yard = 'N'`), the form displays the message *"Take output from Parts ->>transaction ->>stock transfer ->> indent"* and exits immediately without loading any further data. The user must access the form from a stock-yard-enabled location.
- **BR-002-AF-02** - (from Step 6) If the session is in stock-yard mode but no active service locations exist for the consignee, the location list will be empty; the SOQ calculation button will remain disabled and the user will not be able to proceed until a valid location is configured.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Parts Category (`PART_CATEG`) | Mandatory | Character | N/A | Active part categories for principal (`PM_CATEGORY`), loaded via `Categ` record group | Default: `M` (set by system on init) | N/A | Must be set to a valid category before SOQ calculation | Cleared and reset to default on form initialize |
| Show Zero SOQ (`SHOW_ZERO_SOQ`) | Auto-populated | Checkbox | 1 | N/A | `N` (default) / `Y` | N/A | System-set to `N` on init | N/A |
| Last SOQ Date (`NB_LAST_SOQ_DATE`) | Read-only display | Date | DD-MM-RRRR HH:MI AM | N/A | N/A | Parts Category selected | Populated from SOQ history; blank if no prior SOQ for this category | N/A |
| SOQ Category (`NB_SOQ_CATG`) | Read-only display | Character | 100 | N/A | N/A | Parts Category selected | Populated from parts category master | N/A |
| Location(s) Considered (`LOC_DESC`) | Read-only display | Character | 50 | Active service locations for consignee (`AM_DEALER_LOC`) | Location description | Session consignee code present | Loaded from active live locations only | N/A |
| Consider (`CHECK_YN`) | Auto-populated | Checkbox | 1 | N/A | `Y` (pre-ticked on load) | Location loaded | All locations pre-selected on initialization | N/A |
| Copyright Notice (`COPYRIGHT`) | Read-only display | Character | 100 | N/A | Current financial-year copyright string | N/A | System-populated on init | N/A |

---

---

#### Requirement ID: BR-003

**Requirement Title:** Parts Category Mandatory Validation

**Business Description:**
When the user moves away from the Parts Category field after entering a value, the system checks that a parts category has been provided. If the field is left blank, the user is alerted and cannot proceed until a valid category is entered. Additionally, the system marks the SOQ population status as requiring recalculation whenever the category changes.

**Actors:** Dealer Parts User

**Preconditions:**
- The form has been initialized and the main filter screen is displayed.
- The user has entered or changed the value in the Parts Category field.

**Main Flow:**

**Step 1 - Parts Category is validated as mandatory**
When the user tabs out of the Parts Category field, the system checks whether a category has been entered. If the field is blank, an error alert is shown and the user cannot move to the next field until a valid category is provided. The SOQ population status is also reset to indicate that any previously calculated SOQ data for this session is now stale and must be recalculated.

*Screen: SUGGESTED ORDER QUANTITY PROCESSING (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-005](#SP-005--GENERAL.CHECK_NULL)) - GENERAL.CHECK_NULL - checks whether the Parts Category value is blank; if blank, displays an error message saying *"Enter a valid Category"* and prevents navigation away from the field.
    * **Step 1** - Check whether the supplied Parts Category value is null.
    * **Step 2** - If null, display the message *"Enter a valid Category"* in an error alert and raise a failure that stops the user from leaving the field.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Parts Category must be entered | GENERAL.CHECK_NULL [SP-005] - `IF p_value IS NULL` raises FORM_TRIGGER_FAILURE with *"Enter a valid Category"* | When the user tabs off the Parts Category field | Ensures a parts category is always selected before any SOQ data is loaded or calculated | *"Enter a valid Category"* is shown; the cursor stays on the Parts Category field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-ES-01** - Parts Category field is blank - *"Enter a valid Category"*; the user must enter a category before proceeding.
- **BR-003-IC-01** - SOQ population flag reset - the system marks that SOQ data needs to be recalculated for the newly entered category.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Parts Category (`PART_CATEG`) | Mandatory | Character | N/A | N/A | N/A | Form initialized | Must not be blank | *"Enter a valid Category"* shown; field retains focus |

---

---

#### Requirement ID: BR-004

**Requirement Title:** Months of Consumption - Mandatory Entry Validation

**Business Description:**
When the user finishes entering the number of months to be used for the consumption calculation and moves to the next field, the system checks that a value has been provided. If the field is empty, the user is alerted and cannot proceed until they enter the desired number of months. This ensures that the SOQ calculation always has a valid consumption period to work with.

**Actors:** Dealer Parts User

**Preconditions:**
- The form has been initialized and the main filter screen is displayed.
- The user has entered or cleared the Months of Consumption field.

**Main Flow:**

**Step 1 - Months of Consumption is validated as mandatory**
When the user tabs off the Months of Consumption field, the system checks whether a value has been entered. If the field is blank, an error message is displayed and the cursor remains on the field until the user provides a value.

*Screen: SUGGESTED ORDER QUANTITY PROCESSING (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-006](#SP-006--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the message *"Enter the Number of months of consumption to be considered"* in an error alert; raises a failure that prevents the user from navigating away.
    * **Step 1** - Set the alert title to *"Error"* and the alert message text to the provided error string.
    * **Step 2** - Display the alert to the user.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Months of Consumption must be entered | WHEN-VALIDATE-ITEM on SB_TITLE.NO_MONTHS - `IF :SB_TITLE.NO_MONTHS IS NULL` raises FORM_TRIGGER_FAILURE | When the user tabs off the Months of Consumption field | Ensures the consumption calculation period is always defined before the SOQ is run | *"Enter the Number of months of consumption to be considered"* shown; field retains focus |

*Business outcomes (errors, warnings, success, and status):*
- **BR-004-ES-01** - Months of Consumption field is blank - *"Enter the Number of months of consumption to be considered"*; user must enter the number of months before proceeding.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Consider Months Consumption (`NO_MONTHS`) | Mandatory | Numeric | 2 | N/A | N/A | Form initialized | Must not be blank | *"Enter the Number of months of consumption to be considered"* shown; field retains focus |

---

---

#### Requirement ID: BR-005

**Requirement Title:** Disable Calculate SOQ Button on Filter Panel Entry

**Business Description:**
When the user navigates into the filter panel area of the form, the Calculate SOQ button is automatically disabled. This prevents the user from triggering a calculation while they are still making changes to the filter criteria, ensuring that the SOQ calculation only runs with a complete and confirmed set of filters.

**Actors:** Dealer Parts User

**Preconditions:**
- The form has been initialized and is ready for use.

**Main Flow:**

**Step 1 - Calculate SOQ button is disabled on filter panel entry**
Each time the user enters the filter panel section of the screen, the Calculate SOQ button is automatically set to inactive (greyed out) so it cannot be clicked. The user must complete all filter entries and then explicitly re-enable the button by confirming their filter selections before a calculation can be triggered.

*Screen: SUGGESTED ORDER QUANTITY PROCESSING (`WN_MAIN` / `CN_MAIN`).*

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Parts Category (`PART_CATEG`) | Mandatory | Character | N/A | N/A | N/A | Filter panel entered | Must be completed before Calculate SOQ is re-enabled | N/A |

---

---

#### Requirement ID: BR-006

**Requirement Title:** Toggle Location Scope Between Consignee-Level and Home Location

**Business Description:**
When the user checks or unchecks the "Consigne Level" option on the filter panel, the system immediately reloads the location list to reflect the new scope. When consignee-level mode is enabled, all active service locations associated with the consignee are shown. When it is disabled, only the user's home location is shown. This allows the user to choose whether to generate the SOQ for all locations under the consignee or for their own location only.

**Actors:** Dealer Parts User

**Preconditions:**
- The form has been initialized and the main filter screen is displayed.

**Main Flow:**

**Step 1 - Location list is reloaded based on the selected scope**
When the user ticks or unticks the "Consigne Level" checkbox, the system immediately refreshes the location list. If the checkbox is now ticked (all-locations / consignee-level mode), all live service locations linked to the consignee are loaded. If the checkbox is unticked (single-location mode), only the user's home location is loaded. The location list is locked after loading.

*Screen: SUGGESTED ORDER QUANTITY PROCESSING (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **FETCH_LOC** ([SP-001](#SP-001--FETCH_LOC)) - FETCH_LOC - reloads the location selection list; passes the current checkbox value so the procedure knows whether to load all consignee locations (when ticked) or only the home location (when unticked). After loading, the location list is locked to prevent manual changes.
    * **Step 1** - Clear any previously loaded location entries from the in-memory location table and unlock the on-screen location list for population.
    * **Step 2** - Navigate to the location list area and remove all existing rows.
    * **Step 3** - If the session is in stock-yard (all-locations) mode, query every active service location for the current consignee and principal that has a live service date recorded; for each location found, write a row into the location list and the in-memory location table with its location code, description, and dealer mapping code, and mark it as selected.
    * **Step 4** - If the session is in single-location mode, write a single row using the current user's home location details only and mark it as selected.
    * **Step 5** - Lock the on-screen location list against further insert, update, or delete; return focus to the main filter area.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Consigne Level (`CHK_STK_YARD`) | Optional | Checkbox | 1 | N/A | `Y` (all locations) / `N` (home location only) | Form initialized | Controls whether all consignee locations or only the home location are loaded | N/A |
| Location(s) Considered (`LOC_DESC`) | Read-only display | Character | 50 | Active service locations for consignee (`AM_DEALER_LOC`) | Location description | Checkbox changed | Reloaded each time the checkbox is changed | N/A |

---

---

#### Requirement ID: BR-007

**Requirement Title:** Filter SOQ List by Amended Quantity Edit-Mode

**Business Description:**
When the user changes the "Ammended Qty" filter on the SOQ list, the system immediately refreshes the list to show only the parts that match the selected edit-mode. Three modes are available: all parts, only parts whose quantities can still be amended (parts that have been in the portfolio long enough and are not newly introduced or aged out), and only parts that cannot be amended (very new or very old portfolio parts). If there are unsaved quantity changes, the system saves them before refreshing the list. The "Show zero SOQ" option is also set to show all records for the new mode. This filter helps the user focus their review on the specific set of parts they are responsible for amending.

**Actors:** Dealer Parts User

**Preconditions:**
- The SOQ data has been calculated and the parts list is displayed.

**Main Flow:**

**Step 1 - Unsaved changes are saved before the filter is applied**
If the user has made quantity changes that have not yet been saved, the system saves those pending changes to the database before refreshing the list. This prevents data loss when the display filter changes.

*Screen: PART AND STOCK DETAILS (`CN_SOQ`).*

**Step 2 - SOQ list is filtered by the selected edit-mode and refreshed**
The system applies the chosen edit-mode filter to the SOQ list and re-runs the query. Depending on the selection: if "All" mode is selected, all parts for the current dealership, parent group, and location are shown; if "Editable" mode is selected, only parts eligible for quantity amendment (those with a part family age that qualifies them for editing, under non-All-categories mode) are shown; if "Non-editable" mode is selected, only parts not eligible for amendment (parts outside the eligible age range) are shown. For the special all-parts category, no age-based sub-filter is applied regardless of edit-mode. The "Show zero SOQ" indicator is also set to show all records for the new mode.

*Screen: PART AND STOCK DETAILS (`CN_SOQ`).*

#### Business Scenarios - How the edit-mode filter differs by parts category

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Standard category selected (not All-category)** | Editable mode shows only parts within the eligible amendment age range; Non-editable mode shows only parts outside that range; All mode shows all parts regardless of age. |
| **All-category mode active** | The age-based sub-filter is not applied; all parts for the location are shown regardless of edit-mode selection. |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ammended Qty (filter mode) (`NB_EDIT_LST`) | Optional | List | 100 | N/A | All / Editable / Non-editable | SOQ data loaded | Controls which parts appear in the SOQ list based on whether they can be amended | N/A |
| Show zero SOQ (`SHOW_ZERO_SOQ`) | Auto-populated | Checkbox | 1 | N/A | `Y` (reset on edit-mode change) | SOQ data loaded | System-set to show all records when edit mode changes | N/A |

---

---

#### Requirement ID: BR-008

**Requirement Title:** Show or Hide Parts with Zero SOQ Quantity

**Business Description:**
When the user checks or unchecks the "Show zero SOQ" option on the SOQ list panel, the system immediately refreshes the parts list according to the chosen setting. If "Show zero SOQ" is ticked, all parts (including those with a calculated SOQ of zero) are shown. If unticked, only parts with a positive SOQ quantity are shown. The display is further refined by the currently active edit-mode filter and parts category. After refreshing, the system recalculates and shows the updated grand total value for the displayed parts.

**Actors:** Dealer Parts User

**Preconditions:**
- The SOQ data has been calculated and the parts list is displayed.

**Main Flow:**

**Step 1 - Unsaved changes are saved before the filter is applied**
If the user has made quantity changes that have not yet been saved, the system saves those pending changes before refreshing the list.

*Screen: PART AND STOCK DETAILS (`CN_SOQ`).*

**Step 2 - SOQ list is filtered by the zero-SOQ setting, edit-mode, and category, then refreshed**
The system applies the zero-SOQ filter combined with the current edit-mode and category selections to the parts list and re-runs the query. If "Show zero SOQ" is now ticked, the SOQ-quantity restriction is removed. If unticked, only parts with a positive SOQ quantity are included. For the special all-parts category, only the zero-SOQ condition is toggled; for other categories, the age-based edit-mode filter is also applied. The list scrolls to the first record.

*Screen: PART AND STOCK DETAILS (`CN_SOQ`).*

**Step 3 - Grand total value is recalculated for the displayed parts**
After the list refreshes, the system loops through all displayed records and sums up their total values, then updates the grand total value display in the supplier details area.

*Screen: PART AND STOCK DETAILS (`CN_SOQ`).*

#### Business Scenarios - How the filter behaves by category and edit-mode combination

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Standard category + All edit-mode + Show zero SOQ ticked** | All parts for the location and category are shown, including those with zero SOQ. |
| **Standard category + All edit-mode + Show zero SOQ unticked** | Only parts for the location and category with SOQ quantity greater than zero are shown. |
| **Standard category + Editable mode + Show zero SOQ ticked** | Only parts eligible for amendment (within the qualifying age range) for the category are shown, including zero-SOQ ones. |
| **Standard category + Editable mode + Show zero SOQ unticked** | Only editable parts with positive SOQ quantity are shown. |
| **Standard category + Non-editable mode + Show zero/unticked** | The same age-filter logic applies but for the non-eligible (outside the qualifying age range) parts. |
| **All-category mode** | Age-based sub-filter is not applied; only the zero-SOQ condition is toggled. |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Show zero SOQ (`SHOW_ZERO_SOQ`) | Optional | Checkbox | 1 | N/A | `Y` (show zero SOQ parts) / `N` (hide zero SOQ parts) | SOQ data loaded | Controls whether parts with zero SOQ appear in the list | N/A |
| Ammended Qty (filter mode) (`NB_EDIT_LST`) | Read-only reference | List | 100 | N/A | All / Editable / Non-editable | SOQ data loaded | Combined with the zero-SOQ setting to determine which parts are shown | N/A |
| Parts Category (`PART_CATEG`) | Read-only reference | Character | N/A | N/A | N/A | SOQ data loaded | Determines whether the age-based sub-filter is applied | N/A |
| Total (`TOT_VALUE`) | Auto-populated | Currency | 9,99,99,990.00 | N/A | Grand total of all displayed parts' total values | SOQ list refreshed | Recalculated as the sum of all visible records' total values after each list refresh | N/A |

---

---

#### Requirement ID: BR-009

**Requirement Title:** View Monthly Consumption and Stock Details for a Part

**Business Description:**
When the user clicks the "Show Consumption" button for a part in the SOQ list, the system retrieves and displays the monthly consumption history, current stock level, and on-order quantity for each of the dealer's active service locations. Up to twelve months of historical consumption figures are shown for each location, together with the average consumption across those months. If the part number is missing, or if no locations have been loaded, or if the root part number cannot be found, the user is informed with an appropriate message.

**Actors:** Dealer Parts User

**Preconditions:**
- The SOQ data has been calculated and the parts list is displayed.
- A part row in the SOQ list is currently selected.

**Main Flow:**

**Step 1 - Part number is checked before fetching consumption data**
When the user clicks the Show Consumption button, the system first checks whether a part number is associated with the currently highlighted row. If no part number is available, the user is informed and no consumption data is loaded.

*Screen: PART AND STOCK DETAILS (`CN_SOQ`).*

*Business outcomes (errors, warnings, success, and status):*
- **BR-009-ES-01** - No part number on the selected row - *"Part Number Not available to show consumption"*; the consumption detail area remains empty.

**Step 2 - Date basis is set for the consumption calculation period**
The system sets the date up to which consumption should be calculated. Because the current-month consumption is not considered for SOQ purposes (the flag is set to exclude the current month), the date is set back by one month from today. This ensures the consumption history reflects only completed months.

**Step 3 - Consumption detail area is cleared and data is fetched location by location**
The consumption detail area is cleared and the system checks whether any locations have been loaded. If no locations are available, the user is informed. Otherwise, for each loaded service location, the system looks up the root part number for the selected part at that location, then retrieves the monthly consumption figures, current stock, and on-order quantity.

*Screen: PART AND STOCK DETAILS (`CN_SOQ`).*

*Procedures called:*
- **SP_SOQ_POPULATE_CONSUMPTION** ([SP-010](#SP-010--SP_SOQ_POPULATE_CONSUMPTION)) - SP_SOQ_POPULATE_CONSUMPTION - retrieves the monthly consumption history (up to the specified number of months), current stock level, and on-order quantity for a given part at a given location. If an error occurs, it returns an error code and message.
    * **Step 1** - Accept the dealer, principal, parent group, location, company code, part number, number of months, and reference date as inputs.
    * **Step 2** - Calculate the consumption figures for each of the requested months working back from the reference date.
    * **Step 3** - Retrieve the current stock level and on-order quantity for the part at the specified location.
    * **Step 4** - Return the monthly consumption array, current stock, and on-order quantity to the caller; if any error occurs during retrieval, return a non-zero error code and the error message.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Part number is present on the selected row | WHEN-BUTTON-PRESSED in SB_TITLE.SHOW_CON - `IF :b_soq.part_num IS NULL` | When the user clicks the Show Consumption button | Ensures the system has a part to look up before attempting to fetch data | *"Part Number Not available to show consumption"*; detail area stays empty |
| At least one location is loaded | WHEN-BUTTON-PRESSED in SB_TITLE.SHOW_CON - `IF dealer_loc.dloc_tab.count = 0` | When consumption fetch is attempted | Ensures there are locations to fetch consumption data for | *"No Location available"* note shown; detail area stays empty |
| Root part number found for each location | WHEN-BUTTON-PRESSED in SB_TITLE.SHOW_CON - SELECT from PM_PART; NO_DATA_FOUND, TOO_MANY_ROWS, VALUE_ERROR, OTHERS each raise FORM_TRIGGER_FAILURE | When the root part is looked up for each location | The consumption database stores data against the root/parent part; the root must be identified before data can be fetched | See Business outcomes for the four distinct error messages |
| Consumption retrieval succeeded for each location | SP_SOQ_POPULATE_CONSUMPTION [SP-010] - `IF ln_errcd <> 0` raises FORM_TRIGGER_FAILURE after calling GENERAL.DISP_TEXT with the returned error message | After consumption data is fetched per location | Ensures valid consumption data is available before it is written to the screen | The error message returned by the consumption procedure is shown to the user; focus returns to the SOQ list |

*Business outcomes (errors, warnings, success, and status):*
- **BR-009-WS-01** - No locations loaded - *"No Location available"*; detail area is empty.
- **BR-009-ES-02** - Data width problem reading root part for the location - *"Width problem/Incompatible Data while fetching Root Part number"*; the consumption detail fetch stops for this location.
- **BR-009-ES-03** - More than one root part record found - *" More than one  Root Part Number found "*; the consumption detail fetch stops.
- **BR-009-ES-04** - Root part not found for the part number - *"Root Part Number not found for this Part Number"* followed by the part number; the consumption detail fetch stops.
- **BR-009-ES-05** - Database error while fetching root part - *"Execution failed while fetching Root Number-"* followed by the database error text; the consumption detail fetch stops.

**Step 4 - Monthly consumption figures and averages are written to the detail rows**
For each location, the consumption figures for up to twelve months are populated into the corresponding monthly columns, the average consumption across all available months is calculated and displayed, and the location name is shown in the row.

*Screen: PART AND STOCK DETAILS (`CN_SOQ`).*

**Alternative Flows:**
- **BR-009-AF-01** - (from Step 3) An unhandled exception occurs after all location data has been processed - *"Error : "*  followed by the database error text is shown to the user.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Part Number (`PART_NUM`) | Read-only reference | Character | 15 | N/A | N/A | SOQ row selected | Must not be null before consumption fetch is attempted | *"Part Number Not available to show consumption"* shown |
| Location (`LOCATION`) | Auto-populated | Character | 50 | N/A | N/A | Locations loaded | Populated from the in-memory location table | N/A |
| Current Stock (`CURR_STOCK`) | Auto-populated | Numeric | N/A | N/A | N/A | Root part found | Returned by the consumption procedure | N/A |
| On Order (`ON_ORDER`) | Auto-populated | Numeric | N/A | N/A | N/A | Root part found | Returned by the consumption procedure | N/A |
| Average Consumption (`AVER_CONSUMPTION`) | Auto-populated | Numeric | N/A | N/A | N/A | Monthly consumption data returned | Calculated as sum of monthly figures divided by the count of months returned | N/A |
| Month 1-12 consumption (C1-C12) | Auto-populated | Numeric | 9,990.990 | N/A | N/A | Root part found | Populated only for months where data is returned; blank if fewer months returned | N/A |

---

---

#### Requirement ID: BR-010

**Requirement Title:** Sort the SOQ Parts List by Selected Column and Direction

**Business Description:**
When the user changes either the sort column or the sort direction on the SOQ list panel, the system immediately re-sorts and refreshes the parts list according to the new selection. The user can sort by part number, system-calculated SOQ quantity, amended quantity, purchase price, or total value, and can choose ascending or descending order. This allows the user to review and prioritise parts efficiently.

**Actors:** Dealer Parts User

**Preconditions:**
- The SOQ data has been calculated and the parts list is displayed.

**Main Flow:**

**Step 1 - SOQ list is re-sorted and refreshed by the selected column and direction**
When the user changes the Sort By or Sort Type selector, the system saves any pending changes, then re-queries the SOQ data ordered by the chosen column in the chosen direction. The list is refreshed and the first record is positioned at the top.

*Screen: PART AND STOCK DETAILS (`CN_SOQ`).*

*Procedures called:*
- **SORT_BLOCK** ([SP-003](#SP-003--SORT_BLOCK)) - SORT_BLOCK - saves any pending changes, then re-queries the SOQ parts list ordered by the selected sort column and direction. The sort column is determined by the current Sort By selection (part number, SOQ quantity, amended quantity, purchase price, or total value) and the sort direction (ascending or descending) by the Sort Type selection.
    * **Step 1** - Save any unsaved changes to the database before re-sorting.
    * **Step 2** - Navigate to the SOQ parts list.
    * **Step 3** - Determine which column to sort by based on the current Sort By selection (part number, system SOQ quantity, amended quantity, purchase price calculated from the pricing function, or total value).
    * **Step 4** - Apply the sort column and direction to the list and re-execute the query to refresh the display.

#### Business Scenarios - How sorting differs by selected column

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Sort by Part Number** | List is ordered by part number alphanumerically in the selected direction. |
| **Sort by SOQ Quantity** | List is ordered by the system-calculated SOQ quantity. |
| **Sort by Amended Quantity** | List is ordered by the user-entered amended SOQ quantity. |
| **Sort by Purchase Price** | List is ordered by the computed purchase price for each part at the current location. |
| **Sort by Value** | List is ordered by the calculated total value (purchase price multiplied by amended quantity) for each part. |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sort By (`NB_SORT_BY`) | Optional | List | 100 | N/A | PART_NUM / SOQ_QTY / AMD_SOQ_QTY / PURCHASE_PRICE / VALUE | SOQ data loaded | Determines which column the list is sorted on | N/A |
| Sort Type (`NB_SORT_TYPE`) | Optional | List | 100 | N/A | ASC / DESC | SOQ data loaded | Determines sort direction | N/A |

---

---

#### Requirement ID: BR-011

**Requirement Title:** Load Part Pricing and Set Quantity Editability on Each SOQ Row

**Business Description:**
Each time a row is loaded into the SOQ parts list, the system automatically fetches the part's current purchase price, minimum pack quantity, and whether the part allows decimal quantities. It also determines whether the user can amend the SOQ quantity for that specific row, based on how long the part has been in the product portfolio - very new parts (family age zero) and parts past their retirement threshold (family age six months) are locked against amendment when operating in a standard category, while all others remain editable. If the session is in a special editing mode for a specific data-correction scenario, the amended quantity is reset to zero on load.

**Actors:** System (automated on each SOQ row load)

**Preconditions:**
- The SOQ data has been queried and rows are being loaded into the parts list.

**Main Flow:**

**Step 1 - Serial number is set for the current row**
As each row is loaded into the SOQ list, the system assigns the row's position number as its serial number.

*Screen: PART AND STOCK DETAILS (`CN_SOQ`).*

**Step 2 - Purchase price, minimum pack quantity, and decimal-quantity flag are fetched**
The system queries the part master and part variant records to retrieve the purchase price, minimum pack quantity, and whether decimal quantities are allowed for this part at the current location. If the part is not found in the part variant records, the price and minimum quantity default to zero and the decimal flag is set to the non-decimal default - no error is shown. If a data-width error occurs, the same defaults are applied and the row fails to load (the user is notified). Any other database error also applies the defaults and notifies the user.

*Screen: PART AND STOCK DETAILS (`CN_SOQ`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Part pricing lookup | POST-QUERY on B_SOQ - SELECT from PM_PART joined to PM_PART_VAR; NO_DATA_FOUND silently sets defaults; VALUE_ERROR shows error and raises failure; OTHERS shows dynamic error and raises failure | When each SOQ row is loaded into the list | Ensures each row displays current pricing information and knows the order quantity rules for that part | For VALUE_ERROR: *"Width problem while fetching details for part number "* followed by the part number is shown; row load fails. For other database errors: *"Execution failed while fetching details for part number "* followed by the part number and the database error text is shown; row load fails |

*Business outcomes (errors, warnings, success, and status):*
- **BR-011-ES-01** - Data width error fetching part details - *"Width problem while fetching details for part number "* followed by the part number; the row fails to load.
- **BR-011-ES-02** - Unexpected database error fetching part details - *"Execution failed while fetching details for part number "* followed by the part number and the database error text; the row fails to load.

**Step 3 - Amended quantity editability is determined by part family age and category**
For each part row, the system checks the part's family age status. Parts with a family age of zero (newly introduced) or a family age of six (aged out of active portfolio) are locked for amendment when the selected category is not the all-parts category. All other parts, or any part when the all-parts category is active, remain editable.

*Screen: PART AND STOCK DETAILS (`CN_SOQ`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Amended quantity editability by part family age | POST-QUERY on B_SOQ - part family age 0 or 6 sets insert/update not allowed when category is not all-parts; otherwise sets insert/update allowed | When each SOQ row is loaded | Prevents amendment of quantities for parts that are not in the active ordering cycle | The Amended Quantity field is locked for that row; the user cannot enter or change a quantity |

**Step 4 - Amended quantity is reset to zero in data-correction mode**
If the session is operating in a special global editing mode combined with the editable-only list filter, the amended quantity for the current row is reset to zero on load. This applies only when both conditions are active simultaneously.

*Screen: PART AND STOCK DETAILS (`CN_SOQ`).*

#### Business Scenarios - How editability differs by part family age and category

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Part family age is zero (newly introduced), standard category** | Amended Quantity field is locked for this row; the user cannot enter an amended quantity. |
| **Part family age is six (aged out), standard category** | Amended Quantity field is locked for this row. |
| **Part family age is any other value, or all-parts category is active** | Amended Quantity field is editable for this row. |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Serial No. (`NB_SRL_NUM`) | Auto-populated | Numeric | N/A | N/A | Row position number | Row loaded | System-set from row position | N/A |
| Purchase Price (`NB_PUR_PRICE`) | Auto-populated | Numeric | 99,99,990.00 | Part pricing master (`PM_PART_VAR`) | Purchase price | Row loaded | Fetched from part variant; defaults to 0 if not found | *"Width problem while fetching details for part number "* + part number on VALUE_ERROR |
| Minimum Pack Quantity (`NB_MIN_ORD_QTY`) | Auto-populated | Numeric | 9,99,990.990 | Part master (`PM_PART`) | Minimum order quantity | Row loaded | Fetched from part master; defaults to 0 if not found | N/A |
| Ammended Quantity (`AMD_SOQ_QTY`) | Conditional - when part is eligible for amendment | N/A | 9,99,990.990 | N/A | N/A | Row loaded | Editable only when part family age is not 0 or 6 (under standard category); read-only otherwise | N/A |

---

---

#### Requirement ID: BR-012

**Requirement Title:** Validate and Enforce Decimal Quantity Rules for Amended SOQ Quantity

**Business Description:**
When the user enters or changes the amended SOQ quantity for a part and moves to the next field, the system enforces the decimal quantity rule defined for that part. If the part does not allow decimal quantities, the entered value is automatically rounded down to the nearest whole number. If the part's decimal-quantity indicator has an unexpected error value, the user is notified and cannot proceed. Parts that allow decimal quantities pass through without modification.

**Actors:** Dealer Parts User

**Preconditions:**
- The SOQ parts list is displayed.
- A part row is open for editing and the Amended Quantity field has been filled in.
- The part's decimal-quantity rule has been loaded alongside the row.

**Main Flow:**

**Step 1 - Amended quantity is validated and adjusted for decimal-quantity rules**
When the user finishes entering the amended quantity and moves off the field, the system checks whether decimal quantities are permitted for that part. If decimals are not allowed, the entered value is silently truncated to the integer portion (any decimal fraction is discarded). If decimals are allowed, the value is accepted as entered. If the part's decimal indicator contains an unexpected error flag, the user is shown an error and cannot save the quantity.

*Screen: PART AND STOCK DETAILS (`CN_SOQ`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Decimal quantity rule for the part | WHEN-VALIDATE-ITEM on B_SOQ.AMD_SOQ_QTY - `IF NVL(nb_allow_decimal_qty,'N')='N'` truncates to integer; `ELSIF = 'E'` raises FORM_TRIGGER_FAILURE with *"Error while judging to allow Amended SOQ Quantity in decimal."* | When the user tabs off the Amended Quantity field | Ensures amended quantities comply with the part's packaging and ordering rules - whole-number parts must be ordered in whole units | For the 'E' flag (unexpected error): *"Error while judging to allow Amended SOQ Quantity in decimal."* is shown; user cannot save the quantity until the issue is resolved |

*Business outcomes (errors, warnings, success, and status):*
- **BR-012-ES-01** - Part's decimal indicator has an unexpected error value - *"Error while judging to allow Amended SOQ Quantity in decimal."*; the user cannot leave the Amended Quantity field until the issue is resolved.

#### Business Scenarios - How the quantity rule differs by decimal-quantity setting

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Part does not allow decimal quantities** | Any fractional amount entered is discarded; only the whole-number part is retained as the amended quantity. |
| **Part allows decimal quantities** | The entered value is accepted as-is, including any decimal places. |
| **Decimal indicator has an error value** | An error is shown and the user cannot proceed; this indicates a data integrity issue with the part record. |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ammended Quantity (`AMD_SOQ_QTY`) | Conditional - when part is eligible | N/A | 9,99,990.990 | N/A | N/A | Row editable and decimal rule loaded | If decimal not allowed: truncated to integer; if decimal flag is error: rejected | *"Error while judging to allow Amended SOQ Quantity in decimal."* on error flag |

---

---

#### Requirement ID: BR-013

**Requirement Title:** Record Audit Stamp on SOQ Quantity Update

**Business Description:**
Each time an SOQ record is saved with a quantity change, the system automatically records who made the change and when. This audit information is stored on the record so that the history of amendments can be tracked for accountability and review purposes.

**Actors:** System (automated before each SOQ record save)

**Preconditions:**
- The user has made changes to one or more SOQ records in the parts list.
- The save action has been initiated.

**Main Flow:**

**Step 1 - Audit fields are stamped before saving the record**
Before an amended SOQ record is written to the database, the system automatically sets the "last modified by" field to the current user's login name and the "last modified date" to the current system date and time. These values are stored on each changed record as part of the save.

*Screen: PART AND STOCK DETAILS (`CN_SOQ`).*

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Modified By (`MODIFIED_BY`) | Auto-populated | Character | 8 | N/A | Current logged-in user | Record being saved | System-set from the session user; not user-editable | N/A |
| Modified Date (`MODIFIED_DATE`) | Auto-populated | Date | N/A | N/A | Current system date and time | Record being saved | System-set to current date/time; not user-editable | N/A |

---

---

#### Requirement ID: BR-014

**Requirement Title:** Assign Supplier Lookup List Based on Stock Yard Mode

**Business Description:**
When the user navigates to the purchase order supplier details panel, the system automatically assigns the appropriate supplier selection list depending on whether the form is operating in stock-yard (multi-location) mode or standard single-location mode. In stock-yard mode, the supplier list shows only suppliers who are approved for multi-location purchasing. In standard mode, only regular suppliers are available. This ensures that the correct supplier types are presented for the session's operational context.

**Actors:** System (automated on navigation to the PO details panel), Dealer Parts User

**Preconditions:**
- The form has been initialized and the session mode (stock-yard or standard) has been determined.

**Main Flow:**

**Step 1 - Supplier LOV is assigned based on session mode**
When the user enters the PO details panel, the system checks the stock-yard mode flag. If stock-yard mode is active, the supplier field is configured to show only multi-location-approved suppliers. If standard mode is active, the supplier field is configured to show only single-location suppliers.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Supplier list assignment by mode | WHEN-NEW-BLOCK-INSTANCE on B_PARTY - `IF NVL(:parameter.p_stock_yard,'N')='N'` assigns LV_NON_MUL_PARTY; else assigns LV_MUL_PARTY | When the user navigates to the PO details panel | Ensures only applicable suppliers are available for selection based on the session's operational scope | N/A (assignment always succeeds) |

#### Business Scenarios - How the supplier list differs by session mode

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Standard single-location mode** | The supplier list shows only suppliers who are not designated for multi-location purchasing. |
| **Stock-yard (multi-location) mode** | The supplier list shows only suppliers who are approved for multi-location purchasing. |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Supplier (`PARTY_CD`) | Mandatory | Character | N/A | Supplier master - single-location suppliers (`LV_NON_MUL_PARTY` / `GM_PARTY`) or multi-location suppliers (`LV_MUL_PARTY` / `GM_PARTY`) | Supplier name | PO details panel entered | Must be selected from the appropriate LOV for the session mode | *"Enter a valid Supplier"* shown if the entered value is not found in the applicable supplier list |

---

---

#### Requirement ID: BR-015

**Requirement Title:** PO Status Mandatory Validation

**Business Description:**
When the user moves away from the PO Status field in the supplier details panel, the system checks that a PO status value has been entered. If the field is blank, the user is notified and must provide a valid status before proceeding. This ensures that every purchase order generated from the SOQ has a defined status.

**Actors:** Dealer Parts User

**Preconditions:**
- The PO details panel is displayed.
- The user has entered or cleared the PO Status field.

**Main Flow:**

**Step 1 - PO Status is validated as mandatory**
When the user tabs off the PO Status field, the system checks whether a value has been provided. If the field is blank, an error alert is shown and the user cannot move on until a valid PO status is entered.

*Screen: PO DETAILS (`CN_PARTY`).*

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-005](#SP-005--GENERAL.CHECK_NULL)) - GENERAL.CHECK_NULL - checks whether the PO Status value is blank; if blank, displays an error message saying *"Enter a valid PO Status"* and prevents navigation away from the field.
    * **Step 1** - Check whether the supplied PO Status value is null.
    * **Step 2** - If null, display the message *"Enter a valid PO Status"* in an error alert and raise a failure that stops the user from leaving the field.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| PO Status must be entered | GENERAL.CHECK_NULL [SP-005] - `IF p_value IS NULL` raises FORM_TRIGGER_FAILURE with *"Enter a valid PO Status"* | When the user tabs off the PO Status field | Ensures every purchase order has an assigned status before the SOQ data is committed | *"Enter a valid PO Status"* is shown; the cursor stays on the PO Status field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-015-ES-01** - PO Status field is blank - *"Enter a valid PO Status"*; user must enter a status before proceeding.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| PO Status (`PO_STATUS`) | Mandatory | Character | 10 | N/A | N/A | PO details panel entered | Must not be blank | *"Enter a valid PO Status"* shown; field retains focus |

---

---

#### Requirement ID: BR-016

**Requirement Title:** Validate Supplier Code in PO Details

**Business Description:**
When the user enters a supplier code in the PO details panel and moves off the field, the system looks up the supplier in the supplier master to confirm it exists and is of the correct type for the current session mode. If a valid supplier is found, the supplier's name is automatically displayed. If the code does not match a valid supplier of the required type, the user is notified and must provide a correct code. Any unexpected database errors are also reported to the user.

**Actors:** Dealer Parts User

**Preconditions:**
- The PO details panel is displayed.
- The user has entered a value in the Supplier field.

**Main Flow:**

**Step 1 - Supplier code is looked up and the supplier name is populated**
When the user enters a supplier code and tabs off the field, the system checks whether the code belongs to a supplier of the correct type for the current session. If the supplier exists and matches the required type, the supplier's name is automatically shown next to the code. If the code is blank, no lookup is performed and the field is left empty.

*Screen: PO DETAILS (`CN_PARTY`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Supplier code exists and is of the correct type | WHEN-VALIDATE-ITEM on B_PARTY.PARTY_CD - SELECT from GM_PARTY filtering on supplier type and multi-location flag matching the session mode; NO_DATA_FOUND raises FORM_TRIGGER_FAILURE; OTHERS raises FORM_TRIGGER_FAILURE with database error text | When the user tabs off the Supplier field | Ensures only authorised, correctly typed suppliers are used for the purchase order, preventing PO generation for invalid parties | *"Enter a valid Supplier"* shown on NO_DATA_FOUND; database error text shown on other errors; the cursor remains on the Supplier field in both cases |

*Business outcomes (errors, warnings, success, and status):*
- **BR-016-ES-01** - Supplier code not found or wrong type - *"Enter a valid Supplier"*; user must enter a correct supplier code.
- **BR-016-ES-02** - Unexpected database error during supplier lookup - the database error text (SQLERRM) is shown; the user must resolve the issue before proceeding.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Supplier (`PARTY_CD`) | Mandatory | Character | N/A | Supplier master (`GM_PARTY`) via LOV | Supplier code | PO details panel entered | Must exist in the supplier master as a supplier of the correct type for the session mode | *"Enter a valid Supplier"* on no match |
| Supplier Name (`PARTY_NAME`) | Auto-populated | Character | N/A | N/A | N/A | Valid supplier code entered | Populated from the supplier master on valid entry | N/A |

---

---

#### Requirement ID: BR-017

**Requirement Title:** Save and Commit Amended SOQ Quantities to the Database

**Business Description:**
When the user triggers the save action, the system validates all outstanding data entries, commits all amended SOQ quantities and related data to the database, confirms the commit was successful, and then resets the form to a clean state ready for the next round of amendments. If any validation or commit step fails, the user is informed of the error and the data is not saved.

**Actors:** Dealer Parts User

**Preconditions:**
- The SOQ list is displayed with one or more amended quantity changes.
- The user has triggered the save action.

**Main Flow:**

**Step 1 - Outstanding data entries are validated**
The system validates all pending data entries. Any in-progress field edits are completed before the commit proceeds.

**Step 2 - First validation check: entry processing confirmed**
After completing pending entries, the system checks whether the entry processing succeeded. If an Oracle error occurred during the entry step, the user is shown the Oracle error text; if a form error occurred, the form error text is shown. In either case, the commit is aborted.

*Procedures called:*
- **GENERAL.CHECK_FORM_FAILURE** ([SP-004](#SP-004--GENERAL.CHECK_FORM_FAILURE)) - GENERAL.CHECK_FORM_FAILURE - checks whether the most recent form operation succeeded; if it failed due to an Oracle error, displays the Oracle error message; if it failed due to a form error, displays the form error text; raises a failure to stop processing in either case.
    * **Step 1** - Check whether the most recent form operation completed successfully.
    * **Step 2** - If the operation failed: if the error is a database (Oracle) error, display the database error text; if it is a form-level error, display the form error text.
    * **Step 3** - Raise a failure that prevents the commit from proceeding.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Entry processing success check | GENERAL.CHECK_FORM_FAILURE [SP-004] - `IF NOT form_success` raises FORM_TRIGGER_FAILURE after showing the error | After completing entry processing | Ensures all data is valid and fully entered before committing to the database | Oracle or form error text is displayed; the commit is aborted |

**Step 3 - Amended quantities are committed to the database**
The system writes all pending SOQ amendments to the database.

**Step 4 - Second validation check: commit confirmed**
After the commit, the system checks again whether the operation succeeded. If the commit failed, the error is reported to the user.

*Procedures called:*
- **GENERAL.CHECK_FORM_FAILURE** ([SP-004](#SP-004--GENERAL.CHECK_FORM_FAILURE)) - GENERAL.CHECK_FORM_FAILURE - checks whether the commit operation succeeded; reports any Oracle or form error if it did not.
    * **Step 1** - Check whether the most recent form operation completed successfully.
    * **Step 2** - If the operation failed: if the error is a database (Oracle) error, display the database error text; if it is a form-level error, display the form error text.
    * **Step 3** - Raise a failure that prevents the clear-form from proceeding.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Commit success check | GENERAL.CHECK_FORM_FAILURE [SP-004] - second call after commit_form; `IF NOT form_success` raises FORM_TRIGGER_FAILURE after showing error | After the database commit | Confirms the data was saved successfully before resetting the form | Oracle or form error text is displayed; form remains in its current state for the user to review |

**Step 5 - Form is cleared and reset for the next session**
After a successful commit, the form is automatically cleared and reinitialized, triggering the full form initialization sequence (see BR-002) so the user is immediately ready to begin a new round of amendments.

**Step 6 - SOQ list is refreshed and category dropdown is repopulated after save**
After the form clears, the system navigates to the SOQ list block and re-executes the query to reload the latest data. It then resets the report "To Date" field to today's date. To avoid spurious validation errors during re-population, form validation is temporarily suspended while the parts category dropdown list is repopulated (via `LOC_CATEG_POPULATION`), then re-enabled. The screen is then ready for the next session.

*Screen: SUGGESTED ORDER QUANTITY PROCESSING (`WN_MAIN` / `CN_MAIN`).*

**Alternative Flows:**

- **BR-017-AF-01** - (from Step 1) **Save button is disabled** - if the Save button (`PB_SAVE`) is not currently enabled, the save action is silently ignored and no processing occurs. The user must enable the save button (by making at least one amendment) before the save sequence will proceed.

- **BR-017-AF-02** - (from Step 1) **User cancels unsaved changes** - if the user clicks the Cancel toolbar button while the form has unsaved changes, the system asks for confirmation: *"Entered data will not be Saved"*. If the user confirms, the form is cleared and all pending amendments are discarded. If the user does not confirm, the amendments remain and the user can continue editing.

- **BR-017-AF-03** - (from Step 1) **User deletes a record** - if the user clicks the Delete toolbar button while the form has changed data, the system asks for confirmation: *"Are you sure to Delete"*. If the user confirms, the current record is deleted. If the form has no pending changes when Delete is clicked, the form is cleared directly.

---

---

#### Requirement ID: BR-018

**Requirement Title:** Exit Form and Clear Session Tracking Information

**Business Description:**
When the user exits the Suggested Order Quantity Processing form, the system clears the session tracking information that was registered when the form was opened, so that application monitoring tools are informed that this form is no longer active. The form then closes immediately without prompting the user to save any unsaved changes.

**Actors:** Dealer Parts User

**Preconditions:**
- The form is open and the user has triggered the exit action.

**Main Flow:**

**Step 1 - Session tracking information is cleared**
When the user exits, the system clears the client-info and module-name attributes that were registered at form startup. Both are set to blank, so application monitoring tools no longer show this form as the active module for the session.

*Procedures called:*
- **DBMS_APPLICATION_INFO.SET_CLIENT_INFO** - clears the client-info attribute that was set when the form opened, so that monitoring tools can see the form is no longer active.
    * **Step 1** - Clear the database session's client-info attribute so that monitoring tools no longer identify this form as the active module.
- **DBMS_APPLICATION_INFO.SET_MODULE** - clears the module name and action name attributes set at form startup, leaving both blank.
    * **Step 1** - Clear the database session's module name and action label, completing the session de-registration.

**Step 2 - Form is closed without saving**
The form closes immediately without validating or saving any pending changes. Any unsaved amendments are discarded.

---

---

#### Requirement ID: BR-019

**Requirement Title:** Form-Level Error Handling and User Notification

**Business Description:**
The form provides centralised error handling that intercepts common data entry errors and database errors, translating them into plain-language messages for the user. Invalid date formats, numeric-only field violations, concurrent modification conflicts, constraint violations, and general database errors are each handled with a specific user-facing message and appropriate recovery action (either stopping the current action so the user can correct the input, or rolling back the change and prompting a re-query).

**Actors:** System (automated on any form error)

**Preconditions:**
- The form is open and an error has occurred during a user action or data operation.

**Main Flow:**

**Step 1 - Error is identified and the appropriate message is shown**
When any form error occurs, the system checks the error code and responds with the relevant message and action. The specific responses are:

- If an invalid date value was entered, the system shows *"Entered Date is not valid Date"* and stops the current action.
- If a date was entered in the wrong format, the system shows *"Enter the Date in the proper format (DD-MM-YYYY)"* and stops the current action.
- If a character or special character was entered in a numeric-only field, the system shows *"Characters/Special Characters are not allowed here, enter the numeric value"* and stops the current action.
- If a standard form display error occurred (error code 40207), the system shows the form's own error text and stops the current action.
- If a database referential integrity violation occurred (a child record preventing a parent from being changed), the system raises the corresponding constraint error message via the standard error-raising routine.
- If a concurrent update conflict occurred (another user has already modified the record), the system shows *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*, rolls back the pending change, and stops the current action.
- If any other database error occurred, the system shows the database engine's own error text, rolls back the pending change, and stops the current action.
- Certain non-critical informational error codes (query-status messages) are silently suppressed with no action.

**Step 2 - Form messages for data-entry violations are redirected to error alerts**
In addition to the error handler, the form message handler intercepts informational form messages carrying codes `40209` or `40207` and redirects them to the same error-alert mechanism. When a form-generated message with either of these codes fires, the system builds a message string from the error type, code, and text and displays it in an error alert, then stops the current action. This ensures data-entry feedback always appears as a consistent error dialog rather than the default Forms message bar.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-006](#SP-006--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the error or informational message in an alert dialog with the appropriate title (Error or Note) for all handled error codes that require a user-visible notification.
    * **Step 1** - Set the alert title to the provided severity label (Error or Note).
    * **Step 2** - Set the alert message text to the provided message string.
    * **Step 3** - Display the alert to the user and wait for acknowledgement.
- **GENERAL.RAISE_ERROR** ([SP-007](#SP-007--GENERAL.RAISE_ERROR)) - GENERAL.RAISE_ERROR - looks up and displays the message associated with the referential integrity error code, then raises the appropriate failure based on the message type (Error stops the action; Note shows the message without stopping; Caution also shows without stopping).
    * **Step 1** - Receive the error message code to be raised.
    * **Step 2** - Construct the message text from the error code.
    * **Step 3** - Display the message in an alert with the title corresponding to the message type (Error, Note, or Caution).
    * **Step 4** - If the message type is Error, raise a failure to stop the current operation.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Date value validity (error code 50004) | ON-ERROR in Form - `IF errnum IN (50004)` calls GENERAL.DISP_TEXT and raises FORM_TRIGGER_FAILURE | When a date validation error fires | Ensures the user is told clearly that the date entered is not valid | *"Entered Date is not valid Date"* shown; current action stopped |
| Date format compliance (error codes 50025, 50026) | ON-ERROR in Form - `IF errnum IN (50025,50026)` calls GENERAL.DISP_TEXT and raises FORM_TRIGGER_FAILURE | When a date format error fires | Ensures the user is told the required date format | *"Enter the Date in the proper format (DD-MM-YYYY)"* shown; current action stopped |
| Numeric-only field violation (error codes 40209, 50016) | ON-ERROR in Form - `IF errnum IN (40209,50016)` calls GENERAL.DISP_TEXT and raises FORM_TRIGGER_FAILURE | When a character is entered in a numeric field | Ensures the user is told only numeric values are accepted | *"Characters/Special Characters are not allowed here, enter the numeric value"* shown; current action stopped |
| Referential integrity violation (database error -02292) | ON-ERROR in Form - `IF Derrnum = -02292` calls GENERAL.RAISE_ERROR [SP-007] | When a referential integrity constraint is violated | Informs the user that a dependent record is preventing the operation | Constraint error message shown; current action stopped |
| Concurrent update conflict (error codes 40654-40659) | ON-ERROR in Form - `IF ERROR_CODE IN (40654,40655,40656,40657,40659)` calls GENERAL.DISP_TEXT, Rollback, raises FORM_TRIGGER_FAILURE | When a concurrent modification is detected | Prevents data loss from overwriting another user's changes | *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"* shown; change rolled back; current action stopped |
| General database error (sqlcode <> 0) | ON-ERROR in Form - `IF sqlcode <> 0` calls GENERAL.DISP_TEXT with SQLERRM, Rollback, raises FORM_TRIGGER_FAILURE | When any unhandled database error occurs | Ensures all database errors are surfaced to the user rather than silently failing | Database error text shown; change rolled back; current action stopped |
| Form message redirection (message codes 40209, 40207) | ON-MESSAGE in Form - `IF errnum IN (40209,40207)` calls GENERAL.DISP_TEXT and raises FORM_TRIGGER_FAILURE | When a form-generated message with code 40209 or 40207 fires | Ensures data-entry feedback appears as an error alert rather than the default Forms message bar | Error-type, code, and message text displayed in an error alert; current action stopped |

*Business outcomes (errors, warnings, success, and status):*
- **BR-019-ES-01** - Invalid date entered - *"Entered Date is not valid Date"*; current action stopped.
- **BR-019-ES-02** - Date format error - *"Enter the Date in the proper format (DD-MM-YYYY)"*; current action stopped.
- **BR-019-ES-03** - Character in numeric field - *"Characters/Special Characters are not allowed here, enter the numeric value"*; current action stopped.
- **BR-019-ES-04** - Form display error (code 40207) - the form's error text is shown; current action stopped.
- **BR-019-ES-05** - Concurrent update conflict - *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*; change rolled back; current action stopped.
- **BR-019-ES-06** - General database error - the database engine's own error text is shown; change rolled back; current action stopped.
- **BR-019-ES-07** - Form message codes 40209 / 40207 intercepted - error type, code, and text displayed in error alert; current action stopped.
- **BR-019-IC-01** - Non-critical query-status codes (40401, 40405) - silently suppressed; no message shown to the user.

---

---

#### Requirement ID: BR-020

**Requirement Title:** Generate and Print the SOQ History Report

**Business Description:**
When the user specifies a date on the report date selection panel and clicks the Report button, the system generates the Suggested Order Quantity history report for the specified date and displays it. If no date has been entered, clicking the button has no effect. The report is based on the PT_SOQHS report object configured for the form.

**Actors:** Dealer Parts User

**Preconditions:**
- The report date selection panel is visible.
- The user has entered a date in the "As On Date" field on the report panel.

**Main Flow:**

**Step 1 - Report generation is triggered only when a date has been entered**
When the user clicks the Report button, the system checks whether the "As On Date" field has been filled in. If the field contains a date, the report generation sequence is executed. If the field is empty, no action is taken.

*Screen: `WN_MAIN` / `CN_DATE`.*

**Step 2 - SOQ history report is generated and displayed**
The system executes the report generation trigger, which runs the PT_SOQHS report to produce the Suggested Order Quantity history report for the entered date. The report is displayed to the user.

*Screen: `WN_MAIN` / `CN_DATE`.*

**Alternative Flows:**
- **BR-020-AF-01** - (from Step 1) The "As On Date" field is empty when the Report button is clicked - no action is taken; the panel remains as-is for the user to enter the date.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| As On Date (`NB_AS_ON_DATE`) | Conditional - when printing report | Date | DD-MM-YYYY | N/A | N/A | Report date panel visible | Must be entered before the Report button will trigger report generation; if blank, no report is generated | N/A (blank simply produces no action) |

---

---

#### Requirement ID: BR-021

**Requirement Title:** Navigate Back from Report Panel to PO Generation

**Business Description:**
When the user clicks the Back button on the report date selection panel, the screen focus returns to the PO generation button so the user can continue with the purchase order creation workflow without having to navigate manually.

**Actors:** Dealer Parts User

**Preconditions:**
- The report date selection panel is visible and the user has decided not to print or has finished printing.

**Main Flow:**

**Step 1 - Focus returns to the PO generation button**
When the user clicks the Back button, the cursor moves directly to the Generate PO button on the main toolbar, returning the user to the PO generation flow.

*Screen: `WN_MAIN` / `CN_DATE`.*

---

---

#### Requirement ID: BR-022

**Requirement Title:** Remove Unchecked Location Row When No Location Description is Present

**Business Description:**
When the user unchecks a location checkbox in the location selection list and the location has no description loaded, the system automatically removes that empty row from the list. This keeps the location list clean and prevents empty placeholder rows from appearing when a location record was added without a description.

**Actors:** Dealer Parts User

**Preconditions:**
- The form is initialized and the location list is displayed.
- The user has interacted with a location checkbox.

**Main Flow:**

**Step 1 - Empty location row is removed when checkbox changes**
When the user changes the checked state of a location entry, the system checks whether that location has a description. If the location description is absent, the row is deleted from the list. If the description is present, the row is kept regardless of the checked state.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Location description must be present to retain the row | WHEN-CHECKBOX-CHANGED on B_LOC.CHECK_YN - `IF :b_loc.loc_desc IS NULL THEN delete_record` | When the user changes the checked state of a location entry | Prevents empty, description-less location rows from cluttering the location list | N/A (row is silently deleted) |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Consider (`CHECK_YN`) | Optional | Checkbox | 1 | N/A | `Y` / `N` | Location row loaded | Row is automatically deleted if the location description is null when the checkbox is changed | N/A |
| Location(s) Considered (`LOC_DESC`) | Read-only display | Character | 50 | Active service locations | Location description | Location row loaded | Must be present for the row to remain in the list | N/A |

---

---

#### Requirement ID: BR-023

**Requirement Title:** Export SOQ Data to a CSV File for Review in Excel

**Business Description:**
When the user triggers the Excel export function, the system generates a comma-separated values file containing the SOQ data returned by the specified query, saves it on the report server, and opens it in the user's browser as a downloadable file. The filename is generated automatically based on the current user identity and the timestamp. If the data set exceeds the maximum Excel row limit, the file is truncated at 65,535 rows and the user is informed. Any file path with spaces is redirected to the C drive to avoid saving issues. If any error occurs during the export, the user is shown the error code and text.

**Actors:** Dealer Parts User

**Preconditions:**
- The SOQ data has been calculated and is available.
- The user has triggered the Excel export action.

**Main Flow:**

**Step 1 - Output filename is generated automatically**
The system generates a unique filename based on the current user's login ID combined with the current date and time, appended with the `.csv` extension. If the resulting path contains spaces (which would prevent saving), the file is redirected to the C drive root.

*Business outcomes (errors, warnings, success, and status):*
- **BR-023-IC-01** - Path contains spaces - *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."* - the file is saved to the C drive root instead.

**Step 2 - SOQ data is retrieved and written to the file**
The system runs the provided query to populate a temporary record group with the SOQ data. If the data exceeds 65,536 rows, the export is limited to 65,535 rows and the user is notified. The data is written row by row to the server-side file. The server file path is read from a configuration text file on the server.

*Business outcomes (errors, warnings, success, and status):*
- **BR-023-IC-02** - Data exceeds Excel row limit - *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."* - the export continues with the first 65,535 rows.

**Step 3 - The exported file is presented to the user for download**
After the file is written, the system opens the file URL in the user's browser in a new tab so the user can view or download the CSV.

*Business outcomes (errors, warnings, success, and status):*
- **BR-023-ES-01** - Any error during the export process - *"Error  -"* followed by the error code and error text; the export is aborted.

---

---

#### Requirement ID: BR-024

**Requirement Title:** Update On-Order Quantities and Generate Purchase Order

**Business Description:**
When the user triggers the purchase order generation action, the system collects all amended SOQ quantities from the parts list and submits them to the database-level order validation and update procedure. The procedure updates the on-order quantities for each part and applies the PO status specified by the user. If the update fails for any reason, the error details are shown to the user in a dedicated error display panel. Successful completion means all on-order quantities have been updated and the PO has been generated.

**Actors:** Dealer Parts User

**Preconditions:**
- The SOQ quantities have been amended and the parts list is displayed.
- A valid supplier and PO status have been specified in the PO details panel.

**Main Flow:**

**Step 1 - Part order quantities are collected from the SOQ list**
The system loops through all records in the SOQ parts list and assembles a collection of part numbers and their amended SOQ quantities. This collection is passed to the database update procedure.

*Screen: PART AND STOCK DETAILS (`CN_SOQ`).*

**Step 2 - On-order quantities are updated in the database**
The assembled collection is passed to the database on-order update procedure along with the parent group, dealer code, location, PO status, and the current user's name. The procedure updates the on-order quantities for each part and records the PO status.

*Procedures called:*
- **PK_VALIDATE_PARTS.UPDATE_ON_ORDER** ([SP-008](#SP-008--PK_VALIDATE_PARTS.UPDATE_ON_ORDER)) - PK_VALIDATE_PARTS.UPDATE_ON_ORDER - updates the on-order quantity for each part in the supplied list at the current location and applies the purchase order status. Returns a success or error indicator.
    * **Step 1** - Validate the input values.
    * **Step 2** - Retrieve the required business data.
    * **Step 3** - Apply business validations.
    * **Step 4** - Update the required records.
    * **Step 5** - Return the processing result.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| On-order update success | UPDATE_PO_STOCK program unit - `IF lv_err_cd <> 0` populates the error block and shows CN_ERR, then raises FORM_TRIGGER_FAILURE | When the on-order update procedure is called | Ensures any database-level order validation failures are surfaced to the user before the PO is considered generated | Error message from the procedure is displayed in the error panel; PO generation stops |

**Step 3 - Error details are shown if the update fails**
If the update procedure reports an error, the system navigates to the error display panel, populates it with the error message returned by the procedure, and shows it to the user. The PO generation is stopped.

*Screen: PART AND STOCK DETAILS (`CN_SOQ`).*

---

---

#### Requirement ID: BR-025

**Requirement Title:** Validate Location Selection and Build Query Filter

**Business Description:**
Before the SOQ calculation can proceed, the system verifies that at least one service location has been selected in the location list. If no location is selected, the user is notified and the calculation is blocked. When at least one location is selected, the system assembles the list of selected locations to pass to the SOQ calculation query. The part-class filtering logic (for A, B, C, and unclassified parts) is defined but currently inactive in this version.

**Actors:** System (called as part of the SOQ calculation sequence)

**Preconditions:**
- The SOQ calculation has been triggered.
- The location list is populated.

**Main Flow:**

**Step 1 - Selected locations are collected and validated**
The system loops through all rows in the location list and collects those that are checked (selected). If no location is checked, the user is shown an error and the calculation stops. If at least one location is selected, the collected locations are returned to the calling process to be used as the SOQ query filter.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| At least one location must be selected | BUILD_WHERE program unit - `IF NOT lb_flag THEN GENERAL.DISP_TEXT('Atlease one location should be considered','Error')` raises FORM_TRIGGER_FAILURE | When the SOQ calculation is triggered | Ensures the calculation always has a defined scope of locations; prevents a calculation from running with no data scope | *"Atlease one location should be considered"* shown; SOQ calculation is blocked |

*Business outcomes (errors, warnings, success, and status):*
- **BR-025-ES-01** - No location checked - *"Atlease one location should be considered"*; the SOQ calculation does not proceed.

**Step 2 - Part-class filtering (INACTIVE)**
The logic to build a part-class filter (for A, B, C classification segments) is defined but entirely commented out and does not execute in the current version of the form. (COMMENTED OUT / INACTIVE - does not execute)

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Consider (`CHECK_YN`) | Mandatory - at least one must be checked | Checkbox | 1 | N/A | `Y` (selected) / `N` (not selected) | Location list loaded | At least one location must be checked before calculation proceeds | *"Atlease one location should be considered"* shown if none checked |

---

---

#### Requirement ID: BR-026

**Requirement Title:** Pre-populate Location Selections from Existing SOQ History

**Business Description:**
When the SOQ calculation is being set up, the system checks whether a prior SOQ calculation exists for the current dealership and location. If prior SOQ data is found, the system pre-selects the locations in the location list that were included in the most recent calculation. This helps the user quickly reuse the same location scope as the previous SOQ run. Any errors during the pre-population are silently suppressed to avoid interrupting the user's setup flow.

**Actors:** System (called as part of the SOQ calculation setup sequence)

**Preconditions:**
- The form is initialized and location list rows are loaded.

**Main Flow:**

**Step 1 - Prior SOQ record count is checked for the current dealership**
The system checks whether any existing SOQ records exist for the current dealership, location, parent group, and company code in the new SOQ staging table. If no records are found, no pre-population is performed.

**Step 2 - Locations used in the prior SOQ are identified and pre-selected**
If prior records exist, the system queries the list of distinct locations from the prior SOQ data for the same dealership, parent group, and company code. For each location found, the system checks the location list and marks the corresponding row as selected. Any query errors during this step are silently suppressed.

**Step 3 - Parts category for the prior SOQ is looked up (informational - not applied)**
The system retrieves the parts category code from the prior SOQ part data but does not apply it to the category filter (the category-assignment line is commented out and inactive in this version). Any errors during this lookup are silently suppressed.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Consider (`CHECK_YN`) | Auto-populated | Checkbox | 1 | Prior SOQ staging data (`PT_SOQ_NEW`, `PT_SOQ_MUL_NEW`) | `Y` (location was used in prior SOQ) | Location list loaded | Pre-selected to match prior SOQ scope; user can override | Errors silently suppressed |

---

---

#### Requirement ID: BR-027

**Requirement Title:** Clear Consumption Detail When Navigating to a New SOQ Row

**Business Description:**
Each time the user navigates to a new row in the SOQ parts list, the system automatically clears the consumption detail panel. This ensures the detail area always shows data relevant to the currently selected part and does not display stale information from a previously viewed part. The serial number for the current row is also refreshed to reflect the row's position in the list.

**Actors:** System (automated on SOQ row navigation)

**Preconditions:**
- The SOQ parts list is displayed with data.
- The user has moved to a different row in the parts list.

**Main Flow:**

**Step 1 - Serial number is updated for the current row**
When the user navigates to a different row in the SOQ list, the system updates the serial number displayed for that row to reflect its current position in the list.

*Screen: PART AND STOCK DETAILS (`CN_SOQ`).*

**Step 2 - Consumption detail panel is cleared**
The system navigates to the consumption detail section and removes all previously displayed consumption rows. Focus then returns to the SOQ parts list so the user can continue reviewing parts.

*Screen: PART AND STOCK DETAILS (`CN_SOQ`).*

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Serial No. (`NB_SRL_NUM`) | Auto-populated | Numeric | N/A | N/A | Row position number | SOQ row navigated to | System-set from current row position | N/A |

---

---

#### Requirement ID: BR-028

**Requirement Title:** Clear Part Number Search Field on Entry

**Business Description:**
Each time the user moves focus into the Part Number search field, the field is automatically cleared. This ensures the user always starts with a blank search field when they are ready to enter a part number, preventing residual values from a previous search from appearing.

**Actors:** Dealer Parts User

**Preconditions:**
- The form is open and the Part Number search field is visible.

**Main Flow:**

**Step 1 - Part Number search field is cleared on entry**
Each time focus moves into the Part Number search field, the field is automatically set to blank. The user can then type the desired part number from a clean starting state.

**Note - Related navigation and post-text triggers (INACTIVE):** The `KEY-NEXT-ITEM` and `POST-TEXT-ITEM` triggers associated with the Part Number search field are commented out and do not execute in the current version. (COMMENTED OUT / INACTIVE - does not execute)

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Part Number (search) (`NB_FINIS`) | Optional | Character | 15 | N/A | N/A | N/A | Cleared automatically when focus enters the field | N/A |

---

**Note - Inactive Form-Level Triggers**

The following form-level and block-level triggers exist in this form but are entirely inactive (commented out or contain only a `null;` statement) and do not execute:

- **ON-MESSAGE** (Form level) - active form-level message handler; intercepts message codes `40209` and `40207` and redirects them to error alerts (documented in BR-019).
- **KEY-LISTVAL** (Form level) - `(COMMENTED OUT / INACTIVE - does not execute)` - LOV key override.
- **KEY-UP** and **KEY-DOWN** (SB_TITLE block level) - `(COMMENTED OUT / INACTIVE - does not execute)` - navigation key overrides.
- **WHEN-NEW-BLOCK-INSTANCE** (DET_BLK block level) - `(COMMENTED OUT / INACTIVE - does not execute)` - an earlier stock/consumption population block trigger.
- **WHEN-VALIDATE-ITEM** on PO_STATUS (B_PARTY block) - `(COMMENTED OUT / INACTIVE - does not execute)` - an earlier PO status validation (replaced by the active `WVI` trigger, BR-015).
- **KEY-NEXT-ITEM** on NB_FINIS (SB_TITLE block) - `(COMMENTED OUT / INACTIVE - does not execute)`.
- **POST-TEXT-ITEM** on NB_FINIS (SB_TITLE block) - `(COMMENTED OUT / INACTIVE - does not execute)`.
- **WHEN-VALIDATE-ITEM** on B_PRN.NB_AS_ON_DATE - `(COMMENTED OUT / INACTIVE - does not execute)` - earlier date validation (commented out per developer note).

---

## 5. Business Rules Catalogue

Catalogue of the discrete business rules enforced by the form's code.

| Rule ID | Rule Name | Rule Type | Business Requirement ID | Condition | Action | Business Impact |
| ------- | --------- | --------- | ----------------------- | --------- | ------ | --------------- |
| BRC-001 | Parts Category is Mandatory | Validation | BR-003 | Parts Category field is blank when the user moves off it | Show *"Enter a valid Category"* and prevent the user from moving to the next field | Ensures a parts category is always selected before the SOQ list can be queried or calculated |
| BRC-002 | SOQ Population Flag Reset on Category Change | Derivation | BR-003 | Parts Category value changes | Reset the SOQ population indicator to show that previously calculated SOQ data is now stale for this session | Prevents the user from working with SOQ data that was calculated for a different category |
| BRC-003 | Months of Consumption is Mandatory | Validation | BR-004 | Months of Consumption field is blank when the user moves off it | Show *"Enter the Number of months of consumption to be considered"* and prevent the user from moving to the next field | Ensures the SOQ calculation always has a defined consumption period |
| BRC-004 | At Least One Location Must Be Selected | Validation | BR-025 | No location is checked in the location list when the SOQ calculation is triggered | Show *"Atlease one location should be considered"* and block the SOQ calculation | Prevents the SOQ calculation from running with no location scope |
| BRC-005 | Amended Quantity Decimal Rule - No Decimals | Derivation | BR-012 | Amended SOQ Quantity is entered for a part that does not allow decimal quantities | Truncate the entered value to the nearest whole number (remove any decimal fraction) | Ensures quantities comply with the part's packaging and ordering rules |
| BRC-006 | Amended Quantity Decimal Rule - Error Flag | Validation | BR-012 | Amended SOQ Quantity is entered for a part whose decimal indicator has an unexpected error value | Show *"Error while judging to allow Amended SOQ Quantity in decimal."* and prevent saving | Indicates a data integrity issue with the part record that must be resolved |
| BRC-007 | Amended Quantity Locked for Newly Introduced Parts | Constraint | BR-011 | A part has a family age of zero (newly introduced) and the selected category is not the all-parts category | The Amended Quantity field is locked for that row; the user cannot enter or change a quantity | Prevents amendment of order quantities for parts not yet in the active ordering cycle |
| BRC-008 | Amended Quantity Locked for Aged-Out Parts | Constraint | BR-011 | A part has a family age of six months (past retirement threshold) and the selected category is not the all-parts category | The Amended Quantity field is locked for that row | Prevents amendment of order quantities for parts that have passed the active portfolio threshold |
| BRC-009 | Supplier Code Must Be Valid | Validation | BR-016 | Supplier code entered in the PO details panel is not found in the supplier master for the required type | Show *"Enter a valid Supplier"* and prevent moving off the supplier field | Ensures only authorised, correctly typed suppliers are used for purchase orders |
| BRC-010 | PO Status is Mandatory | Validation | BR-015 | PO Status field is blank when the user moves off it | Show *"Enter a valid PO Status"* and prevent moving to the next field | Ensures every purchase order has an assigned status before the data is saved |
| BRC-011 | Concurrent Update Protection | Constraint | BR-019 | A record being saved has already been modified by another user since it was queried | Show *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*, roll back the change, and stop the current action | Prevents data loss from two users overwriting each other's changes |
| BRC-012 | Invalid Date Format | Validation | BR-019 | A date value in an incorrect format is entered (error codes 50025 or 50026) | Show *"Enter the Date in the proper format (DD-MM-YYYY)"* and stop the current action | Ensures date fields contain parseable, correctly formatted values |
| BRC-013 | Invalid Date Value | Validation | BR-019 | A date field contains a value that is not a valid calendar date (error code 50004) | Show *"Entered Date is not valid Date"* and stop the current action | Ensures date fields contain real calendar dates |
| BRC-014 | Numeric-Only Field Violation | Validation | BR-019 | A character or special character is entered in a numeric-only field (error codes 40209 or 50016) | Show *"Characters/Special Characters are not allowed here, enter the numeric value"* and stop the current action | Enforces data type integrity for numeric fields |
| BRC-015 | Referential Integrity Violation | Constraint | BR-019 | A database operation violates a referential integrity constraint (Oracle error -02292) | Raise the registered constraint error message and stop the current action | Protects database referential integrity by informing the user when a dependent record prevents the operation |
| BRC-016 | Amended Quantity Reset to Zero in Data-Correction Mode | Derivation | BR-011 | The session is in a special global editing mode combined with the editable-only list filter when a SOQ row is loaded | The amended quantity for the current row is reset to zero on load | Supports data-correction scenarios where all amended quantities must start from zero |
| BRC-017 | Location List Loaded Based on Session Mode | Derivation | BR-002, BR-006 | Session is in stock-yard (all-locations) mode - all active live locations for the consignee are loaded | All active service locations with a live service date are pre-selected in the location list | Ensures the correct set of locations is available for the SOQ calculation based on how the form was launched |
| BRC-018 | Location List Restricted to Home Location in Single-Location Mode | Derivation | BR-002, BR-006 | Session is in single-location mode | Only the user's home location is loaded and pre-selected in the location list | Restricts the SOQ scope to the user's own location when not in consignee-level mode |
| BRC-019 | Empty Location Row Removed on Checkbox Change | Constraint | BR-022 | A location row has no description when its checkbox is changed | The row is automatically deleted from the location list | Prevents empty, description-less rows from cluttering the location list |
| BRC-020 | Supplier LOV Restricted to Correct Type for Session Mode | Derivation | BR-014 | Session is in stock-yard (multi-location) mode | The supplier list shows only suppliers approved for multi-location purchasing | Ensures the correct supplier types are available for the purchase order based on the operational context |
| BRC-021 | Audit Stamp on SOQ Record Update | Derivation | BR-013 | An SOQ record is being saved with a quantity change | The last modified by and last modified date fields are set to the current user and current system date/time | Maintains a complete audit trail of who amended each SOQ quantity and when |

**Total Business Rules Identified: 21**

---

## 6. Data Requirements

*This section covers the data entities persisted and referenced by the Suggested Order Quantity Processing form, the fields captured and displayed across its screens, the reference and master data it draws upon, and the lifecycle of SOQ quantity records from display through amendment and commit.*

### 6.1 Business Entities and Relationships

*The primary entity persisted by this form is the SOQ quantity record; related entities include service location definitions, parts master data, part pricing, party (supplier) records, and the SOQ history.*

#### Suggested Order Quantity Record - PT_SOQ_MUL_TIL

The PT_SOQ_MUL_TIL table holds the Suggested Order Quantity records for each part at each dealer location. This form presents these records to the user for review and amendment of the suggested order quantities. Users can modify the amended quantity for each row; the table's audit columns track who last changed each record and when.

#### Entity Relationships

The SOQ record is the central entity on this form. Part master and part variant records are joined to each SOQ row when it is loaded, to supply the purchase price, minimum order quantity, and decimal-quantity flag. Service location records define which locations are available for the SOQ scope. Supplier (party) records are referenced for purchase order generation. The SOQ history table (PT_SOQ_MUL_TIL) is also queried to retrieve the most recent SOQ date for the selected category, and the SOQ staging tables (PT_SOQ_MUL_NEW, PT_SOQ_NEW) are read to pre-populate location selections.

```
PT_SOQ_MUL_TIL (SOQ Records)
        ├── PM_PART (Part Master - joined on part_num + dealer/principal)
        │       └── PM_PART_VAR (Part Variant / Pricing - joined on part_num + location)
        ├── AM_DEALER_LOC (Service Locations - for location list population)
        ├── GM_PARTY (Supplier Master - for supplier validation and LOV)
        └── PM_CATEGORY (Parts Category Master - joined via PT_SOQ_MUL_TIL.catg_cd)
```

### 6.2 Data Capture Requirements

*The form captures filter criteria on the main panel, amended SOQ quantities and purchase prices on the parts list, and supplier / PO details on the PO panel; most fields are auto-populated from the database.*

#### Filter and Configuration (Main Panel)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Parts Category (`PART_CATEG`) | Yes | The parts classification category for which the SOQ data is to be displayed and calculated | Must not be blank; validated when the user leaves the field - *"Enter a valid Category"* if blank |
| Consider Months Consumption (`NO_MONTHS`) | Yes | The number of months of historical consumption to include in the SOQ calculation | Must not be blank; validated when the user leaves the field - *"Enter the Number of months of consumption to be considered"* if blank |
| As On Date (`NB_TO_DATE`) | No | The reference date for the SOQ calculation (display only) | Date format must be DD-MM-RRRR if entered |
| Last SOQ Date (`NB_LAST_SOQ_DATE`) | Auto-Populated | The date when the most recent SOQ was last calculated for the selected category, fetched from SOQ history | Read-only; blank if no prior SOQ exists for the selected category |
| SOQ Category (`NB_SOQ_CATG`) | Auto-Populated | The parts category description corresponding to the last SOQ date | Read-only; populated when the last SOQ date is retrieved |
| Show zero SOQ (`SHOW_ZERO_SOQ`) | No | Checkbox controlling whether parts with zero SOQ quantity appear in the list | Default: not ticked (zero-SOQ parts hidden); toggled by the user to show all parts |
| Consigne Level (`CHK_STK_YARD`) | No | Checkbox selecting whether all active consignee locations or only the home location are included | When ticked, all live locations for the consignee are loaded; when unticked, only the home location |
| Copyright Notice (`COPYRIGHT`) | Auto-Populated | Financial-year copyright statement displayed on the screen | System-populated; read-only |

#### Location Selection

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Srl. No. (`SRL_NO`) | Auto-Populated | Sequential row number in the location list | System-set |
| Location(s) Considered (`LOC_DESC`) | Auto-Populated | Description of each active service location loaded into the location list | Read-only; loaded from the active locations master; rows with no description are automatically removed |
| Consider (`CHECK_YN`) | Conditional | Checkbox indicating whether the location should be included in the SOQ calculation | At least one location must be checked before the SOQ calculation can proceed |

#### SOQ Parts List (Amendable Data)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Srl. No. (`NB_SRL_NUM`) | Auto-Populated | Row position number in the SOQ list | System-set from row position |
| Part Number (`PART_NUM`) | Auto-Populated | The part number of the SOQ record | Read from the SOQ data table; used as the lookup key for part details |
| Part Description (`PART_DESC`) | Auto-Populated | The description of the part | Read from the SOQ data table |
| On Hand Quantity (`ON_HAND_QTY`) | Auto-Populated | The current quantity in stock for the part at the location | Read from the SOQ data |
| On Order Quantity (`ON_ORDER_QTY`) | Auto-Populated | The quantity currently on order for the part | Read from the SOQ data |
| SOQ Quantity (`SOQ_QTY`) | Auto-Populated | The system-calculated Suggested Order Quantity for the part | Read from the SOQ data |
| Average Consumption (`AVG_CONSUMPTION`) | Auto-Populated | The calculated average monthly consumption for the part | Read from the SOQ data |
| Ammended Quantity (`AMD_SOQ_QTY`) | Conditional | The user's manually adjusted order quantity for the part | Editable only for parts with a qualifying family age (not newly introduced or aged out) under standard category; decimal quantities truncated to integer if the part does not allow decimals |
| Purchase Price (`NB_PUR_PRICE`) | Auto-Populated | The current purchase price of the part at the location | Fetched from the part variant pricing record; defaults to 0 if not found |
| Total Value (`NB_TOT_VALUE`) | Auto-Populated | The calculated total value (purchase price multiplied by amended quantity) | Calculated field; read-only |
| Minimum Pack Quantity (`NB_MIN_ORD_QTY`) | Auto-Populated | The minimum order pack quantity defined for the part | Fetched from the part master; defaults to 0 if not found |

#### Consumption Detail (Per Location)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Location (`LOCATION`) | Auto-Populated | The service location description for the consumption detail row | Populated from the in-memory location table when consumption is fetched |
| Current Stock (`CURR_STOCK`) | Auto-Populated | The current stock level for the part at the location | Retrieved by the consumption procedure |
| On Order (`ON_ORDER`) | Auto-Populated | The on-order quantity for the part at the location | Retrieved by the consumption procedure |
| Average Consumption (`AVER_CONSUMPTION`) | Auto-Populated | The average monthly consumption calculated from the returned monthly figures | Calculated as the total of all monthly figures divided by the number of months returned |
| Month 1-12 (`C1`-`C12`) | Auto-Populated | Monthly consumption figures for up to twelve months | Populated per month from the consumption procedure; blank for months beyond the count returned |

#### PO Details (Supplier and Status)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Supplier (`PARTY_CD`) | Yes | The supplier code for the purchase order being generated | Must exist in the supplier master as a supplier of the correct type for the session mode; LOV available to browse valid suppliers |
| Supplier Name (`PARTY_NAME`) | Auto-Populated | The name of the selected supplier | Auto-populated from the supplier master when a valid supplier code is entered |
| PO Status (`PO_STATUS`) | Yes | The status to assign to the generated purchase order | Must not be blank |
| Last SOQ Category (`NB_SOQ_CATG`) | Auto-Populated | The SOQ category description shown in the PO details panel | Copied from the header area when the last SOQ date is retrieved |
| Total (`TOT_VALUE`) | Auto-Populated | The grand total value of all displayed SOQ records | Recalculated as the sum of total values across all visible rows whenever the list filter changes |

#### Report Date Selection

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| As On Date (`NB_AS_ON_DATE`) | Conditional | The date parameter for the SOQ history report | Required before the Report button will trigger report generation; date format DD-MM-YYYY |

#### Session / Control Parameters

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| SOQ Population Flag (`P_SOQ_POP`) | Auto-Populated | Session flag tracking whether SOQ data has been calculated in the current session | Set to 'N' on initialize; reset to 'N' when Parts Category changes |
| Location Description (`P_LOC_DESC`) | Auto-Populated | Session parameter holding the home location description for use when single-location mode is active | Read-only; set by the calling session |
| Consignee Code (`P_CONSG_CD`) | Auto-Populated | Session parameter identifying the consignee for location list queries | Read-only; set by the calling session |
| Stock Yard Mode (`P_STOCK_YARD`) | Auto-Populated | Session flag controlling whether stock-yard (all-locations) or single-location mode is active | Read-only; determines the location list scope and the supplier LOV type |

### 6.3 Reference Data

*Lists the master and configuration data referenced by this form.*

| Reference Data | Business Purpose | Used When |
| :--- | :--- | :--- |
| Single-location Supplier list (`LV_NON_MUL_PARTY` / `RG_NON_MUL_PARTY` / `GM_PARTY`) | Provides the list of suppliers approved for single-location purchasing (supplier type 'S', multi-location flag 'N') | When the session is in standard single-location mode and the user browses for a supplier in the PO details panel |
| Multi-location Supplier list (`LV_MUL_PARTY` / `RG_MUL_PARTY` / `GM_PARTY`) | Provides the list of suppliers approved for multi-location purchasing (supplier type 'S', multi-location flag 'Y') | When the session is in stock-yard (multi-location) mode and the user browses for a supplier |
| Active Service Locations (`AM_DEALER_LOC`) | Provides the list of live service locations for the consignee and principal, filtered to locations with a live service date | When the form initializes or when the consignee-level checkbox is toggled, to populate the location selection list |
| Parts Category Master (`PM_CATEGORY`) | Provides the category description for the last SOQ date display and for populating the SOQ category label | When the last SOQ date is retrieved, to resolve the category code to its description |
| Part Master (`PM_PART`) | Provides the minimum order quantity, decimal-quantity flag, and category code for each part | When each SOQ row is loaded into the list, and when the root part number is looked up for consumption fetching |
| Part Pricing Variant (`PM_PART_VAR`) | Provides the current purchase price for each part at the current location | When each SOQ row is loaded into the list |
| SOQ History (`PT_SOQ_MUL_TIL`) | Provides the most recent SOQ date and category for the current dealership and location | When the form initializes or resets, to display the last SOQ calculation date |
| SOQ Staging - Multi-location (`PT_SOQ_MUL_NEW`) | Provides data on whether a prior SOQ calculation exists for the current dealership | When pre-populating location selections from prior SOQ history |
| SOQ Staging - Single-location (`PT_SOQ_NEW`) | Provides the list of locations included in the most recent prior SOQ for pre-selection | When pre-populating location selections from prior SOQ history |
| Excel Path Configuration (`/reports/DMS/excelpath.txt`) | Server-side text file holding the base URL path for saving exported CSV files | EXTERNAL / NOT IN BUNDLE - when the Excel export function generates a file and needs to construct the download URL |

### 6.4 Data Lifecycle

*Describes how records are created, updated, and saved within this form's evidenced behaviour.*

**Creation**

- SOQ quantity records (PT_SOQ_MUL_TIL) are created by a separate SOQ calculation process outside this form; this form reads and displays existing records only.
- The in-memory location table (DEALER_LOC.DLOC_TAB) is populated fresh each time the form is initialized or the consignee-level checkbox is changed.

**Updates**

- The user can modify the Amended Quantity (`AMD_SOQ_QTY`) and Purchase Price (`NB_PUR_PRICE`) fields for eligible SOQ rows directly on the SOQ list screen.
- Rows where the part family age is zero or six (under a standard category) are locked against amendment automatically when each row is loaded.
- The Amended Quantity for a row is reset to zero on load when the session is in a special data-correction mode combined with the editable-only list filter.
- Before each SOQ row is written to the database, the Modified By and Modified Date audit fields are automatically set to the current user and system date/time (PRE-UPDATE trigger on the SOQ list block).

**Save and Commit**

- The user-initiated save action (via the Save button) validates all pending field entries, commits all amended SOQ rows to the database, checks that the commit succeeded, and then clears the form ready for the next session.
- On-order quantities in the part variant records are updated by the separate on-order update procedure (PK_VALIDATE_PARTS.UPDATE_ON_ORDER), called when the user triggers PO generation.

**Retention and Audit**

- Each saved SOQ record carries a Modified By (user login) and Modified Date (system date/time) stamp, populated automatically by the form before every database update.
- No archival or purge logic is implemented within this form.

---

### 6.5 Excel Output Columns

This form does not use Excel download. No Excel export columns were identified in the form sources.

## 7. Glossary

*Definitions of terms, abbreviations, and acronyms used throughout this document.*

The following table defines key terms, acronyms, and abbreviations used throughout this Business Requirements Document.

| Term | Definition | Aliases | Related Terms |
| :--- | :--- | :--- | :--- |
| AMD_SOQ_QTY | Amended SOQ Quantity - the user-entered override of the system-suggested order quantity for a part | Amended Quantity | SOQ_QTY, SOQ |
| AOS | Automatic Order Suggestion - system-generated indicator that classifies the order type for a part | | SOQ |
| B_LOC | Location block - the form section where the user reviews and selects dealer locations for inclusion in the SOQ | Location Selector | Dealer Location, LOC_CD |
| B_PARTY | Supplier block - the form section where the user selects the supplier and confirms the purchase order status before saving | Supplier Block | Party, PO Status |
| B_PRN | Print block - the form section containing the as-on date field and the report and back buttons | Print Block | Report, As-On Date |
| B_SOQ | SOQ data block - the main query block displaying part-level SOQ data bound to PT_SOQ_MUL_TIL | SOQ Block | SOQ, PT_SOQ_MUL_TIL |
| BRD | Business Requirements Document - this document describing the functional and technical specifications of pt_soq_ims | | |
| Catg_CD | Category code - the alphanumeric code identifying the part category used to scope the SOQ query | Part Category | PART_CATEG |
| CHK_STK_YARD | Stock-yard checkbox - controls whether all multi-location dealer locations are loaded or only the current location | | Stock Yard, B_LOC |
| Consignee | A designated party under whose code dealer locations are grouped for SOQ generation | Consg_CD | Dealer, Dealer Location |
| Dealer | Dealer map code - identifies the authorised dealer whose parts inventory is being managed | Dealer_Map_CD | Principal, Parent Group |
| Dealer Location | A specific stock-holding site operated by the dealer, identified by a location code and description | LOC_CD | B_LOC, Consignee |
| DET_BLK | Consumption detail block - the form section displaying monthly stock movement figures for the selected part | Detail Block | Consumption, C1-C12 |
| DMS | Dealer Management System - the integrated software platform within which pt_soq_ims operates | | |
| DPL | Shared program library (DPL.pld) providing common utility procedures (DISP_TEXT, CHECK_NULL, CHECK_FORM_FAILURE, RAISE_ERROR) | | PLD |
| Edit List | Dropdown filter that narrows the SOQ list to all parts (A), editable parts (E), or non-editable parts | NB_EDIT_LST | Part Family Age |
| IMS | Inventory Management System - the subsystem context for the SOQ screen | | SOQ, DMS |
| LOC_CD | Location code - unique identifier for a dealer location used to scope SOQ data queries | Location Code | Dealer Location, B_LOC |
| LOV | List of Values - a popup selection list used in Oracle Forms; in this form used for supplier selection | Dropdown | Record Group, Supplier |
| MUL | Multi-location - designation for suppliers (MUL_YN = Y) and processes that span multiple dealer stock locations | Multi-Location | Stock Yard, B_PARTY |
| On-Hand Qty | The current stock quantity of a part held at the selected dealer location | ON_HAND_QTY | Stock, Inventory |
| On-Order Qty | The quantity of a part currently ordered but not yet received | ON_ORDER_QTY | PO, Order |
| Parent Group | Parent group code - identifies the principal group under which the dealer operates; used to scope all data queries | | Principal, Dealer |
| Part Category | A classification grouping of spare parts (e.g. M = mechanical, AA = all categories) used to filter the SOQ list | CATG_CD | Part Class, SOQ |
| Part Family Age | Numeric indicator of the maturity stage of a part family; parts with age 0 or 6 are locked from SOQ amendment | PART_FAMILY_AGE | Edit List, AMD_SOQ_QTY |
| PCK | Database package - a compiled PL/SQL unit stored in the database; in this form the PK_VALIDATE_PARTS package is called | Package | PK_VALIDATE_PARTS |
| PK_VALIDATE_PARTS | Database package providing the update_on_order procedure that validates and persists amended SOQ quantities as on-order records | | PCK, update_on_order |
| PLD | Program Library Definition - a shared Oracle Forms library (DPL.pld) providing reusable procedures across forms | Program Library | DPL |
| PO | Purchase Order - the commercial document raised to a supplier for the ordered parts | Purchase Order | PO Status, B_PARTY |
| PO Status | Purchase order status code entered by the user; R = raise PO, H = hold | | B_PARTY, PO |
| Principal | Principal map code - identifies the parts manufacturer or importer whose parts are being ordered | Principal_Map_CD | Dealer, Parent Group |
| PT_SOQ_MUL_TIL | Suggested Order Quantity till-date table - the database table that stores pre-computed SOQ data for multi-location dealers | SOQ Table | SOQ, B_SOQ |
| SB_TITLE | Filter and control block - the form section containing category selection, filter checkboxes, and display controls | Control Block | PART_CATEG, B_SOQ |
| SOQ | Suggested Order Quantity - the system-computed recommended order volume for a spare part based on consumption and stock levels | Suggested Order Quantity | AMD_SOQ_QTY, SOQ_QTY |
| SOQ_QTY | System-suggested order quantity for a part row, as stored in PT_SOQ_MUL_TIL | Suggested Quantity | SOQ, AMD_SOQ_QTY |
| Stock Yard | Operational mode in which SOQ generation covers all live dealer locations under the consignee | CHK_STK_YARD | MUL, Dealer Location |
| Supplier | The party selected to fulfil the parts order; identified by party code and resolved from the party master | Party, PARTY_CD | B_PARTY, GM_PARTY |

---

---

## 8. Technical Inventory

*Complete inventory of Oracle Forms components including blocks, items, triggers, canvases, and global variables.*

### 8.1 Form Architecture

**Form Module Details:**

- Form Name: pt_soq_ims (PT_SOQ_IMS)
- Form Module XML Title: MODULE4
- Oracle Forms Version: 12c (Module version 122010400); Runtime compatibility: 5.0
- Parent Object Library: DPL.olb (PC_FORM property class)
- Attached Libraries: DPL (DPL.pld program library), D2KWUTIL
- First Navigation Block: SB_TITLE
- Console Window: WN_MAIN - Suggested Order Quantity(IMS) (Rel : 2.8.9)
- Compile Dependencies: Requires DPL.olb, DPL.pld, WEBUTIL.olb, database packages PKG_DS_AUTO_CLEARANCE, PK_VALIDATE_PARTS
- Source artifacts: `pt_soq_ims_fmb.xml`; OLB `DPL.olb`; DPL (DPL.pld program library); D2KWUTIL; PCK `PKG_DS_AUTO_CLEARANCE.pck`; PCK `PK_VALIDATE_PARTS.pck`

### 8.1.1 Global Variables

| Global Variable | Data Type | Set Location | Purpose |
| :--- | :--- | :--- | :--- |
| BLOCKS | Char | Trigger | Search-navigation mode flag used to control block-level navigation in part-search flow |
| COMP_FA | Char | ProgramUnit / Trigger | Company/FA identifier used to scope SOQ data to the current business entity |
| CURRENCY | Char | Trigger | Currency code for the active session; used to format or label monetary values displayed in the SOQ form |
| DEALER | Char | ProgramUnit / RecordGroup / Trigger | Dealer map code identifying the active dealer for query and DML operations |
| FLAG | Char | Trigger | General-purpose flag set during POST-QUERY to control editable SOQ quantity display |
| LOC_CD | Char | ProgramUnit / Trigger | Location code for the active dealer location used to scope SOQ queries |
| PARENT_GROUP | Char | ProgramUnit / RecordGroup / Trigger | Parent group code identifying the principal group for cross-company data access |
| PRINCIPAL | Char | ProgramUnit / Trigger | Principal map code used to filter part and price data for the current principal |
| P_FIN_YR | Char | Trigger | Financial year context passed into the form session; used to scope SOQ calculations to the correct fiscal period |
| REP_SERVER | Char | Trigger | Report server name used at runtime to route Oracle Reports execution to the correct server instance |
| USERID | Char | ProgramUnit / Trigger | Logged-in user ID used for file-naming during Excel report export |
| USER_NAME | Char | ProgramUnit / Trigger | Logged-in user name recorded as the modifier when SOQ records are updated |

### 8.1.2 Form Parameters

*All 7 ModuleParameter entries from pt_soq_ims_fmb.xml.*

| Parameter | Data Type | Default | Description |
| :--- | :--- | :--- | :--- |
| P_SOQ_POP | Char | N | Controls whether the SOQ population process is triggered on form load; N = do not auto-populate |
| P_LOC_DESC | Char | - | Description of the active location passed in at startup; used to pre-fill the location display in B_LOC |
| P_CONSG_CD | Char | - | Consignee code used by FETCH_LOC to retrieve the dealer locations for the consignee |
| P_STOCK_YARD | Char | N | Indicates whether the form is operating in stock-yard (multi-location) mode; Y activates MUL party LOV |
| P_ABC | Char | - | ABC inventory classification filter string built by BUILD_WHERE and passed to the SOQ report |
| P_PRINT | Char | - | Print destination flag passed to the report-calling procedure for output routing |
| P_REP_ID | Char | PT_SOQHS | Report identifier used by the print procedure to locate the correct report definition |

**Total Parameters:** 7

### 8.2 Blocks

| Block Name | Query Data Source | Records | Q/I/U/D | Key Mode | Master-Detail Relationship |
| :--- | :--- | :--- | :--- | :--- | :--- |
| SB_TITLE | - | 1 | N/N/N/N | Default | Control - entry point for category and filter selection before querying SOQ data |
| B_LOC | - | 5 | N/N/N/N | Default | Control - displays available dealer locations; user selects locations to include in SOQ |
| B_SOQ | PT_SOQ_MUL_TIL | 10 | Y/N/Y/N | Delayed | Control - main SOQ data block; displays suggested and amended order quantities per part |
| DET_BLK | - | 5 | N/N/N/N | Default | Control - shows monthly consumption detail for the selected part across dealer locations |
| B_PARTY | - | 1 | N/N/N/N | Default | Control - captures supplier party and purchase order details for the SOQ submission |
| B_PRN | - | 1 | N/N/N/N | Default | Control - provides print/report parameters including as-on date and report/back buttons |

**Total Blocks:** 6 business blocks

### 8.2.1 Block WhereClause and OrderByClause

*Block query scope from pt_soq_ims_fmb.xml. **Description** explains filter and sort in business terms; **Order By** and **Where Clause** columns retain verbatim XML text for migration.*

| Block | Description | Order By (XML) | Where Clause (XML) |
| :--- | :--- | :--- | :--- |
| B_SOQ | Retrieves SOQ records for the active dealer, parent group, location, and selected part category where the suggested order quantity is greater than zero, sorted by part number | part_num | dealer_map_cd = :global.dealer and parent_group = :global.parent_group and loc_cd = :global.loc_cd and catg_cd=:sb_title.part_categ and nvl(SOQ_QTY,0) > 0 |

### 8.3 Items Summary

*Complete item inventory from `pt_soq_ims_fmb.xml`.*

**Block counts:**

*Database / non-database counts derived from XML.*

| Block | Total Items | Database Items | Non-Database Items |
| :--- | ---: | ---: | ---: |
| SB_TITLE | 26 | 0 | 26 |
| B_LOC | 5 | 0 | 5 |
| B_SOQ | 22 | 6 | 16 |
| DET_BLK | 17 | 0 | 17 |
| B_PARTY | 9 | 0 | 9 |
| B_PRN | 3 | 0 | 3 |
| PB_BLK | 24 | 0 | 24 |
| CB_ERR | 1 | 0 | 1 |
| **Total** | **107** | **6** | **101** |

**Item detail (all 107 items):**

| Block | Item Name | DatabaseItem | Description |
| :--- | :--- | :--- | :--- |
| SB_TITLE | NB_LAST_SOQ_DATE | false | Date of the last Suggested Order Quantity run for the selected category |
| SB_TITLE | NB_TO_DATE | false | To-date filter used for the SOQ calculation period |
| SB_TITLE | PART_CATEG | false | Part category code selected by the user to scope the SOQ query |
| SB_TITLE | PROCESS | false | Processing status or mode indicator for the SOQ generation |
| SB_TITLE | CONSUMPTION | false | Consumption type flag (N = exclude current month, C = actual, V = extrapolate) |
| SB_TITLE | SHOW_ZERO_SOQ | false | Checkbox - when checked, includes parts with zero SOQ quantity in the list |
| SB_TITLE | NO_MONTHS | false | Number of months of consumption history to consider for SOQ calculation |
| SB_TITLE | CHK_STK_YARD | false | Checkbox - when checked, enables stock-yard (multi-location) mode for location fetch |
| SB_TITLE | DUMMY | false | Placeholder field; not used in active form logic |
| SB_TITLE | SOQ_FACT_1 | false | SOQ factor field 1 - weighting or adjustment factor for SOQ computation |
| SB_TITLE | SOQ_FACT_2 | false | SOQ factor field 2 - weighting or adjustment factor for SOQ computation |
| SB_TITLE | SOQ_FACT_3 | false | SOQ factor field 3 - weighting or adjustment factor for SOQ computation |
| SB_TITLE | SOQ_FACT_4 | false | SOQ factor field 4 - weighting or adjustment factor for SOQ computation |
| SB_TITLE | SOQ_FACT_5 | false | SOQ factor field 5 - weighting or adjustment factor for SOQ computation |
| SB_TITLE | SOQ_FACT_6 | false | SOQ factor field 6 - weighting or adjustment factor for SOQ computation |
| SB_TITLE | NO_OF_MONTHS | false | Display field showing the configured number of consumption months |
| SB_TITLE | NB_PART_CLASS | false | Part class filter applied to narrow the SOQ part list |
| SB_TITLE | NB_PART_NUM | false | Part number search field for finding a specific part within the SOQ list |
| SB_TITLE | NB_FINIS | false | Finish/search part number entry used in commented-out block-navigation logic |
| SB_TITLE | P | false | Internal display field; purpose derived from form context |
| SB_TITLE | SHOW_CON | false | Button - when pressed, shows monthly consumption detail for the selected part |
| SB_TITLE | NB_SOQ_CATG | false | SOQ category description display derived from the last SOQ run |
| SB_TITLE | NB_SORT_BY | false | Sort-by dropdown - user selects the column by which the SOQ list is sorted |
| SB_TITLE | NB_SORT_TYPE | false | Sort-order dropdown - user selects ascending or descending sort direction |
| SB_TITLE | NB_EDIT_LST | false | Edit-list dropdown - filters SOQ to all (A), editable (E), or non-editable parts |
| SB_TITLE | COPYRIGHT | false | Displays copyright declaration text fetched from SF_COPYRIGHT_DECLARATION function |
| B_LOC | SRL_NO | false | Serial number of the location row within the B_LOC block |
| B_LOC | LOC_CD | false | Location code for each dealer location available for SOQ selection |
| B_LOC | LOC_DESC | false | Description of the dealer location corresponding to LOC_CD |
| B_LOC | DEALER_MAP_CD | false | Dealer map code associated with the dealer location row |
| B_LOC | CHECK_YN | false | Checkbox - Y includes this location in the SOQ calculation; N excludes it |
| B_SOQ | DEALER_MAP_CD | false | Dealer map code from the PT_SOQ_MUL_TIL query; used as a display/filter reference |
| B_SOQ | PO_CREATED | false | Indicator showing whether a purchase order has already been created for this part |
| B_SOQ | LOC_CD | false | Location code from the SOQ record for the current row |
| B_SOQ | AS_ON_DATE | false | As-on date of the SOQ data row from PT_SOQ_MUL_TIL |
| B_SOQ | NB_SRL_NUM | false | Serial number of the current SOQ record row (system.trigger_record) |
| B_SOQ | PART_NUM | false | Part number for the SOQ line item |
| B_SOQ | PART_DESC | true | Part description fetched from the part master and bound to the database column |
| B_SOQ | ON_HAND_QTY | true | Current on-hand stock quantity for the part at the selected location |
| B_SOQ | ON_ORDER_QTY | true | Quantity of the part currently on order |
| B_SOQ | SOQ_QTY | true | System-suggested order quantity computed by the SOQ process |
| B_SOQ | AVG_CONSUMPTION | true | Average monthly consumption of the part over the configured number of months |
| B_SOQ | AMD_SOQ_QTY | true | User-amended (edited) order quantity; user can override the system SOQ |
| B_SOQ | NB_PUR_PRICE | false | Purchase price of the part fetched from PM_PART_VAR after query |
| B_SOQ | NB_TOT_VALUE | false | Calculated total value of the amended SOQ (AMD_SOQ_QTY × NB_PUR_PRICE) |
| B_SOQ | MODIFIED_BY | false | User name stamped on the record when the SOQ quantity is amended |
| B_SOQ | MODIFIED_DATE | false | Date stamped on the record when the SOQ quantity is amended |
| B_SOQ | NB_TOTAL | false | Running total display field for the SOQ block |
| B_SOQ | NB_ALLOW_DECIMAL_QTY | false | Flag indicating whether decimal quantities are allowed for this part (from PM_PART) |
| B_SOQ | NB_MIN_ORD_QTY | false | Minimum order quantity for the part fetched from PM_PART_VAR |
| B_SOQ | PART_FAMILY_AGE | false | Age of the part family; controls edit permissions on amended SOQ quantity |
| B_SOQ | AOS_TYPE | false | AOS (Automatic Order Suggestion) type code for the part |
| B_SOQ | CATG_CD | false | Category code of the part used for filtering within the SOQ query |
| DET_BLK | ITEM172 | false | Unnamed label or display item in the consumption detail header row |
| DET_BLK | LOCATION | false | Dealer location description displayed for each consumption row |
| DET_BLK | CURR_STOCK | false | Current stock quantity at the displayed location |
| DET_BLK | ON_ORDER | false | On-order quantity at the displayed location |
| DET_BLK | AVER_CONSUMPTION | false | Calculated average monthly consumption for this location |
| DET_BLK | C1 | false | Monthly consumption quantity for month 1 (most recent) |
| DET_BLK | C2 | false | Monthly consumption quantity for month 2 |
| DET_BLK | C3 | false | Monthly consumption quantity for month 3 |
| DET_BLK | C4 | false | Monthly consumption quantity for month 4 |
| DET_BLK | C5 | false | Monthly consumption quantity for month 5 |
| DET_BLK | C6 | false | Monthly consumption quantity for month 6 |
| DET_BLK | C7 | false | Monthly consumption quantity for month 7 |
| DET_BLK | C8 | false | Monthly consumption quantity for month 8 |
| DET_BLK | C9 | false | Monthly consumption quantity for month 9 |
| DET_BLK | C10 | false | Monthly consumption quantity for month 10 |
| DET_BLK | C11 | false | Monthly consumption quantity for month 11 |
| DET_BLK | C12 | false | Monthly consumption quantity for month 12 (oldest) |
| B_PARTY | PARTY_CLASS | false | Party classification code for the selected supplier |
| B_PARTY | PO_DESC | false | Purchase order description entered by the user for the SOQ submission |
| B_PARTY | PO_STATUS | false | Purchase order status code; R = raise PO, H = hold; controls order-update behaviour |
| B_PARTY | PARTY_CD | false | Supplier party code selected from the supplier LOV |
| B_PARTY | PARTY_NAME | false | Supplier name resolved from GM_PARTY on validation of PARTY_CD |
| B_PARTY | MUL_CREATED_YN | false | Flag indicating whether a multi-location PO has already been created |
| B_PARTY | NB_SOQ_CATG | false | SOQ category description carried from SB_TITLE for display on the party screen |
| B_PARTY | TOT_VALUE | false | Grand total value of the amended SOQ order quantities across all parts |
| B_PARTY | ITEM265 | false | Unnamed display or spacer item in the B_PARTY block |
| B_PRN | NB_AS_ON_DATE | false | As-on date entered by the user for the SOQ print report |
| B_PRN | PB_REP | false | Report button - executes the FT_PRINT trigger to generate the SOQ report |
| B_PRN | PB_BACK | false | Back button - navigates back to the main SOQ entry block |
| PB_BLK | PB_EXIT | false | Toolbar Exit button (inherited from DPL object group); exits the form |
| PB_BLK | PB_LIST | false | Toolbar List of Values button (inherited); opens the LOV for the current item |
| PB_BLK | PB_INSERT | false | Toolbar Insert button (inherited); inserts a new record in the current block |
| PB_BLK | PM_CONT | false | Toolbar Continue/context button (inherited); resumes a paused or modal operation |
| PB_BLK | PB_DEL | false | Toolbar Delete button (inherited); marks the current record for deletion |
| PB_BLK | PB_CANCEL | false | Toolbar Cancel button (inherited); cancels pending changes in the current block |
| PB_BLK | PB_SAVE | false | Toolbar Save button (inherited); commits all pending changes to the database |
| PB_BLK | PB_PRINT | false | Toolbar Print button (inherited); invokes the FT_PRINT trigger for report generation |
| PB_BLK | PB_CUT | false | Toolbar Cut button (inherited); cuts the selected text or field value |
| PB_BLK | PB_COPY | false | Toolbar Copy button (inherited); copies the selected text or field value |
| PB_BLK | PB_PASTE | false | Toolbar Paste button (inherited); pastes clipboard content into the current item |
| PB_BLK | PB_ERR_EXIT | false | Toolbar Error Exit button (inherited); closes the error canvas and returns focus to the main block |
| PB_BLK | PB_EDIT_AMD | false | Toolbar Edit Amended SOQ button (inherited); toggles edit mode for the AMD_SOQ_QTY column in B_SOQ |
| PB_BLK | PB_CALC_SOQ | false | Toolbar Calculate SOQ button (inherited); triggers the SOQ population process for the selected category and location set |
| PB_BLK | PB_ESOQ | false | Toolbar Export SOQ button (inherited); initiates the Excel export of the current SOQ data via VIEW_EXCEL_REP |
| PB_BLK | PB_GENPO | false | Toolbar Generate PO button (inherited); navigates to B_PARTY to capture supplier details and raise a purchase order |
| PB_BLK | PB_BACK | false | Toolbar Back button (inherited); navigates back from the current stacked canvas to the main SOQ view |
| PB_BLK | PB_SOQ_BACK | false | Toolbar SOQ Back button (inherited); returns from the SOQ detail view to the SB_TITLE filter block |
| PB_BLK | NB_PART_NUM | false | Toolbar part number search field (inherited); accepts a part number for quick-search navigation within B_SOQ |
| PB_BLK | PB_SEARCH | false | Toolbar Search button (inherited); executes a part-number search using NB_PART_NUM and positions the cursor on the matching row in B_SOQ |
| PB_BLK | PB_BACK_PARTY | false | Toolbar Back from Party button (inherited); navigates back from the B_PARTY supplier screen to the SOQ list |
| PB_BLK | PB_OK | false | Toolbar OK button (inherited); confirms the current selection or dialog and proceeds to the next step |
| PB_BLK | CB_TEMP_SOQ | false | Toolbar Temporary SOQ checkbox (inherited); toggles display of temporary SOQ records in B_SOQ |
| PB_BLK | BT_EXCEL | false | Toolbar Excel export button (inherited); calls VIEW_EXCEL_REP to write the SOQ data to a CSV file and open it in the browser |
| CB_ERR | TXT_ERR | false | Text item on the CN_ERR error canvas (inherited via CB_ERR block); displays the error message text when UPDATE_PO_STOCK or other operations raise a block-level error |

### 8.4 List of Values

| LOV Name | Title | Record Group | Attached Block.Item |
| :--- | :--- | :--- | :--- |
| LV_MUL_PARTY | Supplier Details | RG_MUL_PARTY | B_PARTY.PARTY_CD |
| LV_NON_MUL_PARTY | Supplier Details | RG_NON_MUL_PARTY | - |

**Total LOVs:** 2

### 8.5 Alerts

| Alert Name | Title | Message Text | Calling Context |
| :--- | :--- | :--- | :--- |
| AL_ERRINFO | Error | (set at runtime) | Displayed by GENERAL.DISP_TEXT for error-level messages throughout form triggers and program units (inherited from DPL object group) |
| AL_NOTE | Note | (set at runtime) | Displayed by GENERAL.DISP_TEXT for informational messages throughout form triggers and program units (inherited from DPL object group) |
| AL_CONFIRM | Caution | (set at runtime) | Displayed by GENERAL.DISP_TEXT or direct SET_ALERT_PROPERTY calls where user confirmation is required before a destructive or irreversible action (inherited from DPL object group) |
| AL_PRINT | Print | (set at runtime) | Displayed by the DPL ASK_PRINT routine to present the three-button print-destination dialog (Screen / Printer / Cancel) (inherited from DPL object group) |

**Total Alerts:** 4

### 8.6 Program Units

*Authoritative catalogue of **8 form-local program units**. Database packages and standalone procedures are in **Section 15.2**; PLD shared-library routines are in **Section 18**.*

| Program Unit | Type | Calls | Description |
| :--- | :--- | :--- | :--- |
| FETCH_LOC | Procedure | AM_DEALER_LOC, DEALER_LOC package | Fetches active dealer locations for the current consignee and principal into B_LOC and the DEALER_LOC.dloc_tab PL/SQL table; populates the location selector at form initialisation and on filter changes |
| BUILD_WHERE | Procedure | GENERAL.DISP_TEXT | Validates that at least one location is checked in B_LOC and builds the location-code table passed to SOQ calculation routines; raises an error if no location is selected |
| DEALER_LOC | Package spec | None - package spec declaration only; no procedure calls | Declares the dloc_tab PL/SQL table (code_tab3 type) used to store dealer location codes, descriptions, and dealer map codes for consumption population |
| LOC_CATEG_POPULATION | Procedure | PT_SOQ_MUL_NEW, PT_SOQ_NEW, PM_PART | Reads previously saved SOQ data from PT_SOQ_MUL_NEW and PT_SOQ_NEW to pre-select and highlight the matching locations in B_LOC |
| GET_LAST_SOQ_DATE | Procedure | PT_SOQ_MUL_TIL, PM_CATEGORY, PM_PART | Queries the most recent SOQ run date and category description for the selected category and populates SB_TITLE.NB_LAST_SOQ_DATE and the SOQ category fields |
| UPDATE_PO_STOCK | Procedure | PK_VALIDATE_PARTS.update_on_order, B_SOQ, B_PARTY | Iterates through all B_SOQ records, builds a part-order type table, and calls PK_VALIDATE_PARTS.update_on_order to update on-order quantities; displays errors via CN_ERR canvas |
| SORT_BLOCK | Procedure | B_SOQ | Posts pending changes, builds an ORDER BY clause based on the selected sort field and direction, re-applies it to B_SOQ, and refreshes the query |
| VIEW_EXCEL_REP | Procedure | PM_PART, GENERAL library, WEBUTIL_FILE_TRANSFER.URL_TO_CLIENT, WEBUTIL_HOST.HOST | Creates a dynamic record group from a supplied SQL query, writes the result to a CSV file on the server, transfers it to the client via WebUtil, and opens it in a browser window for download |

**Total Program Units:** 8

### 8.7 Triggers

**Item-Level Trigger Types (reference):**

| Trigger Name | Purpose |
| :--- | :--- |
| WHEN-VALIDATE-ITEM | Validates field when user leaves item |
| KEY-* | Keyboard actions - commit, exit, LOV, navigation |
| WHEN-NEW-BLOCK-INSTANCE | Initializes block on entry |
| WHEN-BUTTON-PRESSED | Executes button action |
| PRE-INSERT / POST-INSERT | Before/after record creation |
| WHEN-LIST-CHANGED | Dropdown selection changed |
| PRE-QUERY / POST-QUERY | Before/after query execution |
| WHEN-CHECKBOX-CHANGED | Checkbox toggled |
| WHEN-VALIDATE-RECORD | Validates entire record before leaving row |

**DPL library routines invoked from triggers and program units:**

| Routine | Type | Called From | Purpose |
| :--- | :--- | :--- | :--- |
| GENERAL.CHECK_NULL | Library routine | B_PARTY.PARTY_CD, B_PARTY.PO_STATUS, B_PRN.NB_AS_ON_DATE, PB_BLK.PB_CALC_SOQ (inherited), SB_TITLE.PART_CATEG | Raises FORM_TRIGGER_FAILURE and displays an error message if the supplied value is null; used to enforce mandatory field entry |
| GENERAL.DISP_TEXT | Library routine | B_PARTY.PARTY_CD, B_SOQ, B_SOQ.AMD_SOQ_QTY, DET_BLK, Form level, PB_BLK.BT_EXCEL (inherited), PB_BLK.PB_CALC_SOQ (inherited), PB_BLK.PB_ESOQ (inherited), PB_BLK.PB_OK (inherited), PB_BLK.PB_SEARCH (inherited), ProgramUnit: BUILD_WHERE, ProgramUnit: LOC_CATEG_POPULATION, SB_TITLE.NO_MONTHS, SB_TITLE.SHOW_CON | Displays a message through AL_ERRINFO or AL_NOTE alert box with the specified title and text; used throughout the form for error and informational messages |
| GENERAL.RAISE_ERROR | Library routine | Form level, SB_TITLE.NB_FINIS | Looks up a message code in the error catalogue, formats the message, and displays it via DISP_TEXT; raises FORM_TRIGGER_FAILURE for error-type messages |
| WEBUTIL_FILE_TRANSFER.URL_TO_CLIENT | Library routine | ProgramUnit: VIEW_EXCEL_REP | Transfers the server-side CSV file generated by VIEW_EXCEL_REP to the client machine via the WebUtil file-transfer mechanism |
| WEBUTIL_HOST.HOST | Library routine | ProgramUnit: VIEW_EXCEL_REP | Executes a host operating-system command from VIEW_EXCEL_REP; used to invoke server-side file operations during CSV generation |

### 8.7.1 Inactive / Commented-Out Trigger Register

*Triggers and field validations where XML source is `null;`, fully block-commented, or legacy code preserved but not executed. Do **not** migrate these as active business requirements.*

| Status | Block | Item | Trigger | Former behaviour (preserved in comments) | Disabled since / note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Commented out** | Form | - | ON-ERROR | Previously handled form error codes (40209, 40207, 50026, 50004), ORA errors, lock-conflict codes, and DBMS errors with GENERAL.DISP_TEXT; replaced by a trimmed active version that handles specific Oracle error codes | Legacy multi-block error handler replaced by simplified active trigger |
| **Inactive stub** | SB_TITLE | - | KEY-UP | Body is `null;`; no active navigation logic | Replaced by inherited KEY-UP from DPL object group |
| **Inactive stub** | SB_TITLE | - | KEY-DOWN | Body is `null;`; no active navigation logic | Replaced by inherited KEY-DOWN from DPL object group |
| **Commented out** | SB_TITLE | NB_FINIS | KEY-NEXT-ITEM | Previously navigated to B_TEMP_SOQ or B_SOQ and located the matching part number row on entry; also called GENERAL.RAISE_ERROR for not-found cases | Commented out by Pankaj on 07-05-2004; replaced by simplified active trigger navigating to PB_BLK.PB_CALC_SOQ |
| **Commented out** | SB_TITLE | NB_FINIS | POST-TEXT-ITEM | Previously triggered navigation to B_TEMP_SOQ or B_SOQ to locate the entered finish part number | Commented out; superseded by KEY-NEXT-ITEM logic changes |
| **Commented out** | B_SOQ | - | WHEN-NEW-RECORD-INSTANCE | Previously called SP_SOQ_POPULATE_CONSUMPTION for each dealer location to load per-record consumption history; consumption load was moved to WHEN-BUTTON-PRESSED on SHOW_CON | Commented out on performance grounds; active stub clears DET_BLK and returns to B_SOQ |
| **Inactive stub** | DET_BLK | - | WHEN-NEW-BLOCK-INSTANCE | Body is `null;`; previously populated DET_BLK with stock and on-order data from PM_STOCK and PM_PART_VAR via a cursor | Block-commented cursor replaced by consumption population logic in SHOW_CON trigger |
| **Commented out** | B_PRN | NB_AS_ON_DATE | WHEN-VALIDATE-ITEM | Previously called GENERAL.CHECK_NULL(:B_PRN.NB_AS_ON_DATE, 'As on Date') to enforce mandatory date entry | Commented out by Pankaj on 07-05-2004; field validation removed from active flow |

*Additional null-only or partially commented triggers exist on estimation and legacy blocks - see XML `TriggerText` starting with `null;` or `/*`.*

**Complete trigger inventory (76 business triggers):**
*pt_soq_ims_fmb.xml contains Trigger elements.*

| Trigger Name | Block | Item | Called From / Context | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| ON-ERROR | Form | - | Form level | **COMMENTED OUT / INACTIVE** (partial) - active portion intercepts Oracle date/numeric/lock errors, displays them via GENERAL.DISP_TEXT, and raises FORM_TRIGGER_FAILURE; RAISE_ERROR called for constraint violation (E0088) |
| ON-MESSAGE | Form | - | Form level | Inherited from DPL object group; suppresses or routes Oracle Forms informational messages |
| KEY-EXIT | Form | - | Form level | Clears DBMS application info, resets module/action, then exits the form without validation |
| KEY-LISTVAL | Form | - | Form level | Inherited from DPL object group; opens the LOV associated with the current item |
| KEY-COMMIT | Form | - | Form level | Calls ENTER, GENERAL.CHECK_FORM_FAILURE, COMMIT_FORM, CHECK_FORM_FAILURE, then DO_KEY('CLEAR_FORM') to save all pending SOQ amendments |
| KEY-CLRFRM | Form | - | Form level | Clears the form, resets SOQ filters to defaults, re-fetches locations via FETCH_LOC, retrieves last SOQ date, and restores default WHERE clause on B_SOQ |
| KEY-OTHERS | Form | - | Form level | Inherited from DPL object group; handles all unassigned key events at form level |
| KEY-NEXT-ITEM | Form | - | Form level | Inherited from DPL object group; moves focus to the next navigable item |
| KEY-PREV-ITEM | Form | - | Form level | Inherited from DPL object group; moves focus to the previous navigable item |
| KEY-NXTBLK | Form | - | Form level | Inherited from DPL object group; navigates to the next block |
| KEY-PRVBLK | Form | - | Form level | Inherited from DPL object group; navigates to the previous block |
| KEY-DOWN | Form | - | Form level | Inherited from DPL object group; moves focus down one record in the current block |
| KEY-UP | Form | - | Form level | Inherited from DPL object group; moves focus up one record in the current block |
| FT_SAVE | Form | - | Form level | Inherited from DPL object group; performs a save (COMMIT) operation equivalent to KEY-COMMIT |
| FT_CANCEL | Form | - | Form level | Inherited from DPL object group; cancels pending changes and clears the current block |
| FT_INSERT | Form | - | Form level | Inherited from DPL object group; inserts a new record in the current block |
| FT_DEL | Form | - | Form level | Inherited from DPL object group; deletes the current record after confirmation |
| FT_LIST | Form | - | Form level | Inherited from DPL object group; opens the LOV for the current item |
| FT_PRINT | Form | - | Form level | Inherited from DPL object group; invokes the report-print procedure using P_REP_ID and P_PRINT parameters |
| WHEN-NEW-FORM-INSTANCE | Form | - | Form level | Inherited from DPL object group; initialises global variables, sets DBMS application context, calls FETCH_LOC and GET_LAST_SOQ_DATE, and prepares the form for first use |
| PRE-FORM | Form | - | Form level | Sets DBMS application info (module name = pt_soq_ims) for session tracing |
| KEY-UP | SB_TITLE | - | SB_TITLE | **INACTIVE** - stub body `null;`; no active upward navigation in this block |
| KEY-DOWN | SB_TITLE | - | SB_TITLE | **INACTIVE** - stub body `null;`; no active downward navigation in this block |
| WHEN-NEW-BLOCK-INSTANCE | SB_TITLE | - | SB_TITLE | Disables the PB_CALC_SOQ toolbar button when the SB_TITLE block is entered |
| WHEN-VALIDATE-ITEM | SB_TITLE | PART_CATEG | SB_TITLE.PART_CATEG | Calls GENERAL.CHECK_NULL to ensure category is selected; resets P_SOQ_POP to N |
| WHEN-CHECKBOX-CHANGED | SB_TITLE | SHOW_ZERO_SOQ | SB_TITLE.SHOW_ZERO_SOQ | Posts any pending B_SOQ changes, rebuilds the B_SOQ WHERE clause to include or exclude zero-SOQ parts based on the checkbox and edit-list filter, re-executes the query, and updates the grand total |
| WHEN-VALIDATE-ITEM | SB_TITLE | NO_MONTHS | SB_TITLE.NO_MONTHS | Validates that the number of consumption months is not null; displays an error and raises failure if blank |
| KEY-NEXT-ITEM | SB_TITLE | NO_MONTHS | SB_TITLE.NO_MONTHS | Navigates to PB_BLK.PB_CALC_SOQ after the number of months field |
| WHEN-CHECKBOX-CHANGED | SB_TITLE | CHK_STK_YARD | SB_TITLE.CHK_STK_YARD | Re-fetches dealer locations using the current CHK_STK_YARD value; Y = all stock-yard locations, N = single location |
| KEY-NEXT-ITEM | SB_TITLE | CHK_STK_YARD | SB_TITLE.CHK_STK_YARD | Navigates to B_LOC.CHECK_YN after the stock-yard checkbox |
| KEY-NEXT-ITEM | SB_TITLE | NB_FINIS | SB_TITLE.NB_FINIS | **COMMENTED OUT / INACTIVE** - active stub navigates to PB_BLK.PB_CALC_SOQ |
| WHEN-NEW-ITEM-INSTANCE | SB_TITLE | NB_FINIS | SB_TITLE.NB_FINIS | Fires when focus enters NB_FINIS; subclassed from DPL object group |
| POST-TEXT-ITEM | SB_TITLE | NB_FINIS | SB_TITLE.NB_FINIS | **COMMENTED OUT / INACTIVE** - body is block-commented; previously navigated to part row in B_SOQ |
| WHEN-BUTTON-PRESSED | SB_TITLE | SHOW_CON | SB_TITLE.SHOW_CON | Determines consumption calculation date based on the CONSUMPTION flag, iterates over all selected dealer locations via DEALER_LOC.dloc_tab, calls SP_SOQ_POPULATE_CONSUMPTION for each, and populates DET_BLK with 12-month consumption history and averages |
| WHEN-LIST-CHANGED | SB_TITLE | NB_SORT_BY | SB_TITLE.NB_SORT_BY | Posts pending changes and calls SORT_BLOCK to re-order the B_SOQ list by the newly selected sort column |
| WHEN-LIST-CHANGED | SB_TITLE | NB_SORT_TYPE | SB_TITLE.NB_SORT_TYPE | Posts pending changes and calls SORT_BLOCK to re-order the B_SOQ list by the current sort column with the new ascending/descending direction |
| WHEN-LIST-CHANGED | SB_TITLE | NB_EDIT_LST | SB_TITLE.NB_EDIT_LST | Posts pending changes, rebuilds the B_SOQ WHERE clause to filter by edit-list selection (all, editable, non-editable parts), forces SHOW_ZERO_SOQ to Y, and re-executes the query |
| WHEN-CHECKBOX-CHANGED | B_LOC | CHECK_YN | B_LOC.CHECK_YN | Records whether the location checkbox is selected; changes propagate to consumption calculations via DEALER_LOC.dloc_tab |
| KEY-NEXT-ITEM | B_LOC | CHECK_YN | B_LOC.CHECK_YN | Navigates to B_LOC.CHECK_YN in the next location row |
| PRE-UPDATE | B_SOQ | - | B_SOQ | Stamps the current user name and system date into MODIFIED_BY and MODIFIED_DATE before each SOQ row update |
| WHEN-NEW-RECORD-INSTANCE | B_SOQ | - | B_SOQ | Sets NB_SRL_NUM to the current system trigger record number and clears DET_BLK; main consumption-load loop is commented out |
| POST-QUERY | B_SOQ | - | B_SOQ | After each row query, fetches allow-decimal-qty, min-order-qty, and purchase price from PM_PART / PM_PART_VAR; sets edit permissions on AMD_SOQ_QTY based on PART_FAMILY_AGE; resets AMD_SOQ_QTY to zero if FLAG = Y and edit list is E |
| WHEN-VALIDATE-ITEM | B_SOQ | AMD_SOQ_QTY | B_SOQ.AMD_SOQ_QTY | Truncates AMD_SOQ_QTY to whole number if decimal quantities are not allowed for the part; displays error and raises failure if the decimal flag has an unexpected value |
| WHEN-NEW-BLOCK-INSTANCE | DET_BLK | - | DET_BLK | **INACTIVE** - stub body `null;`; previously populated DET_BLK stock data from PM_STOCK |
| WHEN-NEW-BLOCK-INSTANCE | B_PARTY | - | B_PARTY | Sets the LOV on B_PARTY.PARTY_CD to LV_NON_MUL_PARTY or LV_MUL_PARTY based on the P_STOCK_YARD parameter |
| WHEN-VALIDATE-ITEM | B_PARTY | PO_STATUS | B_PARTY.PO_STATUS | Inherited subclassed trigger; body is `null;` - no active validation |
| WVI | B_PARTY | PO_STATUS | B_PARTY.PO_STATUS | Calls GENERAL.CHECK_NULL to ensure PO Status is not left blank before saving |
| WHEN-VALIDATE-ITEM | B_PARTY | PARTY_CD | B_PARTY.PARTY_CD | Validates the entered supplier code against GM_PARTY; resolves and displays the party name; raises failure if not found or invalid |
| WHEN-VALIDATE-ITEM | B_PRN | NB_AS_ON_DATE | B_PRN.NB_AS_ON_DATE | **COMMENTED OUT / INACTIVE** - active stub is `null;`; previously enforced mandatory as-on date via CHECK_NULL |
| WHEN-BUTTON-PRESSED | B_PRN | PB_REP | B_PRN.PB_REP | Executes the FT_PRINT inherited trigger to launch the SOQ print report if NB_AS_ON_DATE is populated |
| WHEN-BUTTON-PRESSED | B_PRN | PB_BACK | B_PRN.PB_BACK | Navigates back to the PB_BLK.PB_GENPO toolbar button |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EXIT | PB_BLK.PB_EXIT (inherited) | Exits the form; equivalent to KEY-EXIT; clears DBMS application context before closing |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_LIST | PB_BLK.PB_LIST (inherited) | Opens the LOV for the currently focused item; equivalent to KEY-LISTVAL |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_INSERT | PB_BLK.PB_INSERT (inherited) | Inserts a new record in the current block; equivalent to INSERT_RECORD |
| WHEN-BUTTON-PRESSED | PB_BLK | PM_CONT | PB_BLK.PM_CONT (inherited) | Continues a paused or modal operation; context-dependent behaviour defined in the DPL library |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_DEL | PB_BLK.PB_DEL (inherited) | Marks the current record for deletion after confirmation; equivalent to DELETE_RECORD |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CANCEL | PB_BLK.PB_CANCEL (inherited) | Cancels pending changes in the current block; equivalent to CLEAR_RECORD |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SAVE | PB_BLK.PB_SAVE (inherited) | Commits all pending changes; equivalent to KEY-COMMIT |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PRINT | PB_BLK.PB_PRINT (inherited) | Invokes the FT_PRINT trigger to generate the SOQ report |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CUT | PB_BLK.PB_CUT (inherited) | Cuts the selected text or field value to the clipboard |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_COPY | PB_BLK.PB_COPY (inherited) | Copies the selected text or field value to the clipboard |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PASTE | PB_BLK.PB_PASTE (inherited) | Pastes clipboard content into the currently focused item |
| KEY-NEXT-ITEM | PB_BLK | PB_EDIT_AMD | PB_BLK.PB_EDIT_AMD (inherited) | Moves focus to the next item after PB_EDIT_AMD in the toolbar tab order |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EDIT_AMD | PB_BLK.PB_EDIT_AMD (inherited) | Toggles edit mode on the AMD_SOQ_QTY column in B_SOQ, enabling or locking user amendments to suggested order quantities |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CALC_SOQ | PB_BLK.PB_CALC_SOQ (inherited) | Triggers the SOQ population process for the selected category, location set, and filter criteria; calls GENERAL.CHECK_NULL to validate mandatory inputs before execution |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_ESOQ | PB_BLK.PB_ESOQ (inherited) | Initiates the Excel export of the current SOQ data by calling VIEW_EXCEL_REP; displays status messages via GENERAL.DISP_TEXT |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_GENPO | PB_BLK.PB_GENPO (inherited) | Navigates to B_PARTY to capture supplier and PO details for raising a purchase order against the amended SOQ |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_BACK | PB_BLK.PB_BACK (inherited) | Navigates back from the current stacked canvas to the main SOQ view |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SOQ_BACK | PB_BLK.PB_SOQ_BACK (inherited) | Returns from the SOQ detail view to the SB_TITLE filter block |
| KEY-NEXT-ITEM | PB_BLK | PB_SOQ_BACK | PB_BLK.PB_SOQ_BACK (inherited) | Moves focus to the next toolbar item after PB_SOQ_BACK |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SEARCH | PB_BLK.PB_SEARCH (inherited) | Executes a part-number search using the value in NB_PART_NUM; positions the cursor on the matching row in B_SOQ; displays a not-found message via GENERAL.DISP_TEXT if no match exists |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_BACK_PARTY | PB_BLK.PB_BACK_PARTY (inherited) | Navigates back from the B_PARTY supplier screen to the SOQ list |
| KEY-NEXT-ITEM | PB_BLK | PB_BACK_PARTY | PB_BLK.PB_BACK_PARTY (inherited) | Moves focus to the next toolbar item after PB_BACK_PARTY |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_OK | PB_BLK.PB_OK (inherited) | Confirms the current selection or dialog and proceeds; displays status via GENERAL.DISP_TEXT as required |
| WHEN-CHECKBOX-CHANGED | PB_BLK | CB_TEMP_SOQ | PB_BLK.CB_TEMP_SOQ (inherited) | Toggles display of temporary SOQ records in B_SOQ when the checkbox state changes |
| WHEN-BUTTON-PRESSED | PB_BLK | BT_EXCEL | PB_BLK.BT_EXCEL (inherited) | Calls VIEW_EXCEL_REP to write the SOQ data to a CSV file and open it in the browser; displays progress or error messages via GENERAL.DISP_TEXT |

### 8.8 Canvas and Window Inventory

**Windows:**

| Window | Title | Primary Canvas |
| :--- | :--- | :--- |
| WIN_ERR | - | CN_ERR |
| WN_MAIN | Suggested Order Quantity(IMS) (Rel : 2.8.9) | CN_MAIN |

**Canvases:**

| Canvas | Type | Window |
| :--- | :--- | :--- |
| CN_MAIN | Content | - |
| CN_PARTY | Stacked | - |
| CN_SOQ | Stacked | - |
| CN_DATE | Stacked | WN_MAIN |
| CN_TOOL | Content | - |
| CN_ERR | Content | - |

---

### 8.9 Editors

*No editors found in pt_soq_ims_fmb.xml.*

### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

#### 8.10.1 Visual Attributes (form-defined)

*1 VisualAttribute elements defined at form level (not inherited from DPL.olb).*

| Visual Attribute |
| :--- |
| VA_ROW_SELECT |

#### 8.10.2 Property Classes (form-defined)

*Form-local PropertyClass elements.*

*No form-local property classes found in pt_soq_ims_fmb.xml.*

#### 8.10.3 Object Groups

*Object groups bundle inherited triggers and visual objects applied form-wide at runtime.*

| Object Group Child | Type |
| :--- | :--- |
| KEY-OTHERS | Inherited trigger |
| KEY-NEXT-ITEM | Inherited trigger |
| KEY-PREV-ITEM | Inherited trigger |
| KEY-NXTBLK | Inherited trigger |
| KEY-PRVBLK | Inherited trigger |
| KEY-DOWN | Inherited trigger |
| KEY-UP | Inherited trigger |
| CN_ERR | Inherited canvas |
| VA_DISP | Inherited visualattribute |
| CB_ERR | Inherited block |
| VA_LOV | Inherited visualattribute |
| VA_TRNI_DT | Inherited visualattribute |
| VA_TITLE | Inherited visualattribute |
| VA_ALERT | Inherited visualattribute |
| VA_BUTN | Inherited visualattribute |
| VA_TEXT | Inherited visualattribute |
| VA_MPROMPT | Inherited visualattribute |
| VA_OPROMPT | Inherited visualattribute |
| VA_MAND | Inherited visualattribute |
| VA_NUM | Inherited visualattribute |
| VA_DESC | Inherited visualattribute |
| VA_ICONIC_BUTN | Inherited visualattribute |
| VA_RB | Inherited visualattribute |
| VA_CB | Inherited visualattribute |
| WN_MAIN | Inherited window |
| POP_MAIN | Inherited trigger |
| CN_MAIN | Inherited canvas |
| CN_TOOL | Inherited canvas |
| PB_BLK | Inherited block |
| AL_ERRINFO | Inherited alert |
| AL_NOTE | Inherited alert |
| AL_CONFIRM | Inherited alert |
| WIN_ERR | Inherited window |
| AL_PRINT | Inherited alert |
| FT_SAVE | Inherited trigger |
| FT_CANCEL | Inherited trigger |
| FT_INSERT | Inherited trigger |
| FT_DEL | Inherited trigger |
| FT_LIST | Inherited trigger |
| FT_PRINT | Inherited trigger |
| WHEN-NEW-FORM-INSTANCE | Inherited trigger |

### 8.11 DataSourceColumn Inventory

*18 DataSourceColumn elements across 1 blocks - formal query column-to-block mapping from pt_soq_ims_fmb.xml.*

#### B_SOQ (18 columns)

| Column (DSCName) | Data Type |
| :--- | :--- |
| DEALER_MAP_CD | NUMBER |
| PART_CLASS | VARCHAR2 |
| PART_NUM | VARCHAR2 |
| AS_ON_DATE | DATE |
| NO_OF_MONTHS | NUMBER |
| AMD_QTY | NUMBER |
| AMD_QTY1 | NUMBER |
| AMD_QTY2 | NUMBER |
| AMD_QTY3 | NUMBER |
| AMD_QTY4 | NUMBER |
| AMD_QTY5 | NUMBER |
| AMD_QTY6 | NUMBER |
| AMD_QTY7 | NUMBER |
| AMD_QTY8 | NUMBER |
| AMD_QTY9 | NUMBER |
| AMD_QTY10 | NUMBER |
| AMD_QTY11 | NUMBER |
| AMD_QTY12 | NUMBER |

**Total DataSourceColumns:** 18 across 1 blocks

## 9. Object Library

*The form references the DPL object library for standardised visual attributes, property classes, and object groups used across the DMS application suite.*

Source OLB file(s): DPL_olb.xml

| Name | Type | Description | Used By (count) | Sample Items |
| ---- | ---- | ----------- | --------------- | ------------ |
| VA_CB | VisualAttribute | Checkbox style - grey background, Arial 8pt, black foreground, transparent fill | Referenced (DPL_olb.xml) | Checkbox items inheriting this style |
| VA_RB | VisualAttribute | Radio button style - grey background, Arial 8pt, black foreground, transparent fill | Referenced (DPL_olb.xml) | Radio button items |
| VA_ICONIC_BUTN | VisualAttribute | Iconic button style - white background, black foreground, transparent fill | Referenced (DPL_olb.xml) | Iconic push button items |
| VA_DESC | VisualAttribute | Description field style - grey background, Small Fonts 7pt medium blue, transparent fill | Referenced (DPL_olb.xml) | Description display items |
| VA_NUM | VisualAttribute | Numeric field style - white background, Arial 8pt medium black, transparent fill | Referenced (DPL_olb.xml) | Numeric text items |
| VA_MAND | VisualAttribute | Mandatory field highlight - cyan background, Arial 9pt medium black | Referenced (DPL_olb.xml) | Mandatory field items |
| VA_OPROMPT | VisualAttribute | Optional field prompt style - white/Arial 8pt prompt in black | Referenced (DPL_olb.xml) | Optional field prompts |
| VA_MPROMPT | VisualAttribute | Mandatory field prompt style - white/Arial 8pt prompt in red | Referenced (DPL_olb.xml) | Mandatory field prompts |
| VA_TEXT | VisualAttribute | Standard text field style - white background, Arial 9pt medium black, transparent fill | Referenced (DPL_olb.xml) | Standard text items |
| VA_BUTN | VisualAttribute | Push button style - grey background, Arial 10pt bold black | Referenced (DPL_olb.xml) | Push button items |
| VA_ALERT | VisualAttribute | Alert dialog style - grey background, MT Extra 11pt demilight black | Referenced (DPL_olb.xml) | Alert dialogs |
| VA_TITLE | VisualAttribute | Title/header field style - grey background, Arial 10pt bold blue | Referenced (DPL_olb.xml) | Title display items |
| VA_TRNI_DT | VisualAttribute | Transaction date field style - white background, Courier bold black | Referenced (DPL_olb.xml) | Date/time items |
| VA_LOV | VisualAttribute | LOV field style - grey background, Arial 9pt dark blue | Referenced (DPL_olb.xml) | LOV-linked text items |
| VA_DISP | VisualAttribute | Display (read-only) field style - background r25g75b75, Arial 8pt bold black | Referenced (DPL_olb.xml) | Read-only display items |
| VA_ROW_SELECT | VisualAttribute | Row selection highlight for the SOQ parts list - background frame colour, foreground background colour | 1 (B_SOQ block record visual attribute) | B_SOQ block (RecordVisualAttributeGroupName) |
| PC_DESC | PropertyClass | Display item property class - left-justified display item, Arial 9pt blue, width 250, no bevel | Referenced (DPL_olb.xml) | Description display items |
| PC_SC_DATE | PropertyClass | Screen date property class - display item, Arial 8pt bold blue, format DD-MM-YY or DD/MM/YY | Referenced (DPL_olb.xml) | Date display items |
| PC_TITLE | PropertyClass | Title text property class - centred, Arial 10pt bold blue, uppercase | Referenced (DPL_olb.xml) | Section title items |
| PC_FORMAT | PropertyClass | Format/code text property class - centred, Arial 9pt, width 60, uppercase | Referenced (DPL_olb.xml) | Short code fields |
| PC_MR_BLK | PropertyClass | Multi-record block property class - vertical orientation, next-navigation to PB_BLK | Referenced (DPL_olb.xml) | B_SOQ block inherits this class |
| PC_DISP | PropertyClass | Read-only display item property class - left-justified, enabled false, grey background, Arial 9pt | Referenced (DPL_olb.xml) | Read-only display items |
| PC_LOV | PropertyClass | LOV field property class - grey background, Arial 8pt, auto-select off, width 250 | Referenced (DPL_olb.xml) | LOV-linked fields |
| PC_FORM | PropertyClass | Form-level property class - includes ON-ERROR, ON-MESSAGE, KEY-EXIT, KEY-LISTVAL, KEY-COMMIT, KEY-CLRFRM inherited triggers and console/menu settings | Referenced (DPL_olb.xml) | Form-level properties |
| PC_DISP_DATE | PropertyClass | Date display property class - display item, Arial 9pt, format DD-MM-RRRR, disabled | Referenced (DPL_olb.xml) | Date display fields |
| PC_DISP_NUM | PropertyClass | Numeric display property class - right-justified display item, Arial 9pt, lowered bevel, disabled | Referenced (DPL_olb.xml) | Numeric display fields |
| PC_DATE | PropertyClass | Date entry property class - editable, Arial 9pt, format DD-MM-RRRR, hint DD-MM-YYYY or DD/MM/YYYY, width 60 | Referenced (DPL_olb.xml) | Date entry items |
| PC_DTTIME | PropertyClass | Date-time entry property class - editable, VA_TEXT, format DD-MM-RRRR HH24:MI, initialises to current date-time | Referenced (DPL_olb.xml) | Date-time items |
| PC_CB | PropertyClass | Checkbox property class - white background, Arial 9pt | Referenced (DPL_olb.xml) | Checkbox items |
| PC_ALERT | PropertyClass | Alert property class - grey background, MT Extra 11pt demilight | Referenced (DPL_olb.xml) | Alert objects |
| PC_MDATE | PropertyClass | Mandatory date property class - editable, red prompt, format DD-MM-RRRR; WHEN-VALIDATE-ITEM raises error if blank | Referenced (DPL_olb.xml) | Mandatory date fields |
| PC_RB | PropertyClass | Radio button property class - grey background, Arial 9pt | Referenced (DPL_olb.xml) | Radio button items |
| PC_WIND | PropertyClass | Window property class - grey background, Arial 10pt bold blue title, resize/maximise/minimise allowed | Referenced (DPL_olb.xml) | WN_MAIN window |
| PC_CANV | PropertyClass | Canvas property class - white background, Arial, width 750, viewport height 301, raise on enter | Referenced (DPL_olb.xml) | Canvas objects |
| PC_BUTN | PropertyClass | Button property class - grey background, Arial 9pt bold, width 42, no mouse navigate | Referenced (DPL_olb.xml) | Push button items |
| PC_TEXT | PropertyClass | Optional text property class - left-justified, white background, Arial 9pt, black prompt | Referenced (DPL_olb.xml) | Optional text items |
| PC_MTEXT | PropertyClass | Mandatory text property class - left-justified, white background, Arial 9pt, red prompt; WHEN-VALIDATE-ITEM raises error if blank | Referenced (DPL_olb.xml) | Mandatory text fields |
| PC_UTEXT | PropertyClass | Optional uppercase text property class - left-justified, white background, Arial 9pt, uppercase restriction | Referenced (DPL_olb.xml) | Uppercase text items |
| PC_MUTEXT | PropertyClass | Mandatory uppercase text property class - left-justified, white background, Arial 9pt, uppercase restriction, red prompt; WHEN-VALIDATE-ITEM raises error if blank | Referenced (DPL_olb.xml) | Mandatory uppercase fields |
| PC_NUM | PropertyClass | Optional numeric property class - right-justified, white background, Arial 9pt, lowest value 0 | Referenced (DPL_olb.xml) | Optional numeric fields |
| PC_MNUM | PropertyClass | Mandatory numeric property class - right-justified, white background, Arial 9pt, lowest value 0, red prompt; WHEN-VALIDATE-ITEM raises error if zero | Referenced (DPL_olb.xml) | Mandatory numeric fields |
| PC_ICONIC_BUTN | PropertyClass | Iconic button property class - iconic mode, white background, no bevel, width 20, no mouse navigate | Referenced (DPL_olb.xml) | Iconic buttons |
| PC_SCROLL | PropertyClass | Scrollbar property class - scrollbar width 13 | Referenced (DPL_olb.xml) | Scrollbar objects |
| OG_GROUP | ObjectGroup | Standard DMS object group containing shared key triggers (KEY-OTHERS, KEY-NEXT-ITEM, KEY-PREV-ITEM, KEY-NXTBLK, KEY-PRVBLK, KEY-DOWN, KEY-UP), error/LOV canvases (CN_ERR, CB_ERR), visual attributes (VA_DISP, VA_LOV, VA_TRNI_DT, VA_TITLE, VA_ALERT, VA_BUTN, VA_TEXT, VA_MPROMPT, VA_OPROMPT, VA_MAND, VA_NUM, VA_DESC, VA_ICONIC_BUTN, VA_RB, VA_CB), windows and canvases (WN_MAIN, POP_MAIN, CN_MAIN, CN_TOOL), toolbar button block (PB_BLK), and the FT_PRINT trigger | 1 (form-level - subclassed into this form) | Form inherits OG_GROUP from the DPL library (ParentModule=DPL_MTPL) |

---

## 10. Record Groups

*Lists all record groups, their LOV bindings, query logic, dynamic bindings, business purpose, and form usage.*

| Record Group | Type | Used By LOV | Display Column | Return Column | Dynamic Bindings | Purpose | Where Used |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| RG_NON_MUL_PARTY | Query | LV_NON_MUL_PARTY | PARTY_NAME | PARTY_CD | No | Lists non-multi-location suppliers (MUL_YN = N) for the current dealer to select when creating a standard purchase order | LV_NON_MUL_PARTY |
| RG_MUL_PARTY | Query | LV_MUL_PARTY | PARTY_NAME | PARTY_CD | No | Lists multi-location suppliers (MUL_YN = Y) for the current dealer to select when creating a stock-yard purchase order | LV_MUL_PARTY -> B_PARTY.PARTY_CD |

**Total Record Groups:** 2

## 11. Referenced Database Objects

*Database tables, views, and objects accessed by the form.*

| Block | Base Table | Primary Key Item | Database Item |
| :--- | :--- | :--- | :--- |
| SB_TITLE | - | - | No |
| B_LOC | - | - | No |
| B_SOQ | PT_SOQ_MUL_TIL | - | Yes |
| DET_BLK | - | - | No |
| B_PARTY | - | - | No |
| B_PRN | - | - | No |

| Object | Schema | Used In | Description |
| :--- | :--- | :--- | :--- |
| `AM_DEALER_LOC` | - | FETCH_LOC, Trigger WHEN-BUTTON-PRESSED, Trigger WHEN-NEW-FORM-INSTANCE | Dealer location master - stores location codes, descriptions, and consignee associations for each dealer; queried during form initialisation, location fetch, and button-driven location lookups |
| `DUAL` | - | Trigger WHEN-BUTTON-PRESSED | Oracle pseudo-table - used for single-row SELECT to derive calculation dates (SYSDATE, ADD_MONTHS) |
| `GM_PARTY` | - | RG_MUL_PARTY, RG_NON_MUL_PARTY, Trigger WHEN-VALIDATE-ITEM | Party master - holds supplier details; queried to validate party code and resolve party name in B_PARTY |
| `PD_PO` | - | Trigger WHEN-BUTTON-PRESSED | Purchase Order detail line table - queried during button-driven processing to retrieve line-level PO details for SOQ-to-PO conversion or validation |
| `PD_PO_SO` | - | Trigger WHEN-BUTTON-PRESSED | Purchase Order detail suggested-order table - queried during button-driven processing to retrieve or cross-reference SOQ-linked PO detail lines |
| `PH_PO` | - | Trigger WHEN-BUTTON-PRESSED | Purchase Order header table - queried during button-driven processing to retrieve or create PO header records associated with the suggested order quantity workflow |
| `PH_PO_SO` | - | Trigger WHEN-BUTTON-PRESSED | Purchase Order header suggested-order table - queried during button-driven processing to retrieve or cross-reference SOQ-linked PO header records |
| `PM_CATEGORY` | - | Trigger WHEN-NEW-FORM-INSTANCE | Part category master - queried at form initialisation to populate or validate category reference data used in the SOQ processing context |
| `PM_NUMBER_GEN` | - | Trigger WHEN-BUTTON-PRESSED | Number generation master - queried during button-driven processing to generate or retrieve system-assigned document numbers (e.g. PO numbers) for the SOQ workflow |
| `PM_PART` | - | GET_LAST_SOQ_DATE, LOC_CATEG_POPULATION, Trigger POST-QUERY, Trigger WHEN-BUTTON-PRESSED | Part master - stores part attributes including category, allow-decimal-qty, and root part number for each dealer-principal combination |
| `PT_SOQ_MUL_NEW` | - | LOC_CATEG_POPULATION | Suggested Order Quantity staging table (new multi-location) - used to determine previously processed SOQ locations and categories |
| `PT_SOQ_MUL_TIL` | - | B_SOQ, GET_LAST_SOQ_DATE, Trigger WHEN-BUTTON-PRESSED | Suggested Order Quantity till-date table - base table for B_SOQ; holds part-level SOQ data including suggested quantities, on-hand, and as-on date; also accessed directly in button-driven processing |
| `PT_SOQ_NEW` | - | LOC_CATEG_POPULATION | Suggested Order Quantity staging table (new single-location) - used to pre-select matching locations in B_LOC during LOC_CATEG_POPULATION |

**Total Referenced Objects:** 13

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure/Package Index

| Requirement ID | Procedure/Package | Purpose |
| -------------- | ----------------- | ------- |
| BR-001 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Registers the form name as the active client-info attribute in the database session |
| BR-001 | DBMS_APPLICATION_INFO.SET_MODULE | Registers the form module name and clears the action attribute in the database session |
| BR-002 | FETCH_LOC | Loads the list of active service locations into the location selection panel based on the session scope (all consignee locations or home location only) |
| BR-002 | GET_LAST_SOQ_DATE | Retrieves the most recent SOQ calculation date and category description for the selected parts category and dealership |
| BR-002 | SF_COPYRIGHT_DECLARATION | Returns the current financial-year copyright notice string |
| BR-002 | GENERAL.L_POP_LIST_ITEM | Populates list-of-values controls from record groups during form initialisation |
| BR-003 | GENERAL.CHECK_NULL | Validates that the Parts Category field is not blank before the user can navigate away |
| BR-006 | FETCH_LOC | Reloads the location list when the consignee-level checkbox is toggled |
| BR-009 | SP_SOQ_POPULATE_CONSUMPTION | Retrieves monthly consumption history, current stock, and on-order quantity per location for a selected part |
| BR-010 | SORT_BLOCK | Re-queries and re-sorts the SOQ parts list by the selected column and direction |
| BR-015 | GENERAL.CHECK_NULL | Validates that the PO Status field is not blank |
| BR-017 | GENERAL.CHECK_FORM_FAILURE | Checks that each step of the save/commit sequence (entry and commit) succeeded; surfaces Oracle or form errors |
| BR-018 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Clears the client-info session attribute on form exit |
| BR-018 | DBMS_APPLICATION_INFO.SET_MODULE | Clears the module name and action attributes on form exit |
| BR-019 | GENERAL.DISP_TEXT | Displays error messages for all handled error types (date format, numeric-only, concurrent update, general database errors) |
| BR-019 | GENERAL.RAISE_ERROR | Looks up and displays the registered message for the referential integrity violation error code |
| BR-024 | PK_VALIDATE_PARTS.UPDATE_ON_ORDER | Updates the on-order quantity for each part in the SOQ list and records the PO status at the database level |
| - | GENERAL.ASK_CONFIRM | Presents a confirmation dialog before destructive or navigational operations (Cancel, Delete, Exit, Save, clipboard actions) |
| - | BUILD_WHERE | Validates that at least one location is selected and assembles the location filter list for the SOQ query |
| - | LOC_CATEG_POPULATION | Queries prior SOQ history to pre-select locations and identify the category used in the most recent prior calculation |
| - | UPDATE_PO_STOCK | Assembles amended part order quantities from the SOQ list and calls PK_VALIDATE_PARTS.UPDATE_ON_ORDER to persist them |
| - | VIEW_EXCEL_REP | Generates a CSV file from the SOQ query result, writes it to the report server, and opens it in the browser |
| - | PKG_DS_AUTO_CLEARANCE.SP_DEADSTK_PO_SO | Executes dead-stock automatic clearance logic, generating or updating associated PO and SO records when the user confirms the OK action |
| - | PKG_DS_AUTO_CLEARANCE.FN_GET_PEND_ORDER | Retrieves pending order information as part of the dead-stock auto-clearance evaluation workflow |
| - | SP_CALCULATE_SOQ_IMS | Executes the core SOQ calculation for the IMS multi-location context, producing suggested order quantities per part and location |
| - | SP_INSERT_PM_PART_VAR | Inserts a new part variant record into PM_PART_VAR when no existing record is found during on-order quantity update processing |
| - | SP_UPDATE_PART_PRICE | Updates part price information as part of the SOQ or PO generation workflow |
| - | SP_UPDATE_PO_NUMBER_NEW | Assigns or updates the system-generated PO number for SOQ-linked purchase orders |
| - | D2KWUTIL.ADD_ERROR | Adds an error entry to the D2KWUTIL internal error stack |
| - | D2KWUTIL.ADD_EXTERNAL_ERRORS | Adds externally sourced errors to the D2KWUTIL error stack for unified error reporting |
| - | D2KWUTIL.ATTEMPT_DLL_LOAD | Attempts to load a named DLL via the D2KWUTIL library; used to initialise native library support |
| - | D2KWUTIL.BOOLTOCHAR | Converts a Boolean value to its character representation for use in D2KWUTIL utility calls |
| - | D2KWUTIL.CLEAN_ERROR_STACK | Clears the D2KWUTIL internal error stack between operations |
| - | D2KWUTIL.CREATED_DATE | Returns the creation date metadata for a D2KWUTIL-managed resource |
| - | D2KWUTIL.D2KWUTIL_DEBUGSTRING | Returns a formatted debug string from the D2KWUTIL library for diagnostic logging |
| - | D2KWUTIL.D2KWUTIL_FILEINFO | Returns file metadata information via the D2KWUTIL library |
| - | D2KWUTIL.DEBUGLOG | Writes a debug log entry via the D2KWUTIL library |
| - | D2KWUTIL.FILE_INFO | Retrieves file system information for a specified file path via D2KWUTIL |
| - | D2KWUTIL.REGISTER_FUNCTION_CALL | Registers a function call event within the D2KWUTIL diagnostic framework |
| - | D2KWUTIL.SETDEBUG | Enables or disables D2KWUTIL debug-logging mode |
| - | D2KWUTIL.STRIPDIRSEP | Strips trailing directory separator characters from a file path string |
| - | D2KWUTIL.TRANSLATETYPE | Translates an internal type code to its display string within the D2KWUTIL framework |
| - | D2KWUTIL.WINDEBUG | Writes a debug entry to the D2KWUTIL windowed debug log |
| - | WEB.SHOW_DOCUMENT | Opens the specified URL in the user's browser to deliver the exported CSV file |

---

### 12.2 Procedure and Package Catalogue

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| FETCH_LOC | Form Program Unit (Procedure) | KEY-CLRFRM trigger (form-level), WHEN-CHECKBOX-CHANGED on SB_TITLE.CHK_STK_YARD | Loads active service locations into the location selection list; population scope controlled by session parameter |
| BUILD_WHERE | Form Program Unit (Procedure) | WHEN-BUTTON-PRESSED (PB_BLK.PB_CALC_SOQ) as part of the SOQ calculation sequence | Validates at least one location is selected and assembles the selected-location list for the SOQ query filter |
| DEALER_LOC | Form Program Unit (Package Spec) | FETCH_LOC, UPDATE_PO_STOCK, WHEN-BUTTON-PRESSED (SHOW_CON) | Defines the in-memory table structure (DLOC_TAB) used to hold the selected location codes and descriptions across program units |
| LOC_CATEG_POPULATION | Form Program Unit (Procedure) | Called as part of the SOQ calculation setup | Queries prior SOQ history to pre-select the locations and identify the category used in the most recent prior calculation |
| GET_LAST_SOQ_DATE | Form Program Unit (Procedure) | KEY-CLRFRM trigger (form-level) | Retrieves the most recently calculated SOQ date and category description for the current dealership and selected category |
| UPDATE_PO_STOCK | Form Program Unit (Procedure) | WHEN-BUTTON-PRESSED (PB_BLK.PB_OK) when the Generate PO action is triggered | Assembles part order quantities from the SOQ list and calls PK_VALIDATE_PARTS.UPDATE_ON_ORDER to persist on-order records at the database level |
| SORT_BLOCK | Form Program Unit (Procedure) | WHEN-LIST-CHANGED on SB_TITLE.NB_SORT_BY, WHEN-LIST-CHANGED on SB_TITLE.NB_SORT_TYPE | Re-queries the SOQ list ordered by the user-selected sort column and direction |
| VIEW_EXCEL_REP | Form Program Unit (Procedure) | WHEN-BUTTON-PRESSED (PB_BLK.BT_EXCEL) | Generates a CSV file from the SOQ query result, writes it to the report server, and opens it in the browser |
| GENERAL.ASK_CONFIRM | Attached Library (DPL - GENERAL package) | Trigger FT_CANCEL (form-level), Trigger FT_DEL (form-level), WHEN-BUTTON-PRESSED in PB_BLK.PB_CANCEL, PB_BLK.PB_COPY, PB_BLK.PB_CUT, PB_BLK.PB_DEL, PB_BLK.PB_EXIT, PB_BLK.PB_INSERT, PB_BLK.PB_LIST, PB_BLK.PB_PASTE, PB_BLK.PB_SAVE | Presents the supplied confirmation message in an alert dialog and returns a numeric result indicating the user's choice; called before destructive or navigational operations to obtain explicit user consent |
| GENERAL.CHECK_NULL | Attached Library (DPL - GENERAL package) | WHEN-VALIDATE-ITEM on SB_TITLE.PART_CATEG, WHEN-VALIDATE-ITEM on B_PARTY.PO_STATUS, WHEN-VALIDATE-ITEM on B_PRN.NB_AS_ON_DATE, WHEN-BUTTON-PRESSED on PB_BLK.PB_CALC_SOQ | Checks whether a supplied value is null; if null, displays an *"Enter a valid [field label]"* error and raises FORM_TRIGGER_FAILURE; guards mandatory fields and the SOQ calculation button |
| GENERAL.DISP_TEXT | Attached Library (DPL - GENERAL package) | ON-ERROR (form-level), ON-MESSAGE (form-level), BUILD_WHERE, POST-QUERY (B_SOQ), WHEN-BUTTON-PRESSED (PB_BLK.BT_EXCEL), WHEN-BUTTON-PRESSED (PB_BLK.PB_CALC_SOQ), WHEN-BUTTON-PRESSED (PB_BLK.PB_ESOQ), WHEN-BUTTON-PRESSED (PB_BLK.PB_OK), WHEN-BUTTON-PRESSED (PB_BLK.PB_SEARCH), WHEN-BUTTON-PRESSED (SB_TITLE.SHOW_CON), WHEN-NEW-FORM-INSTANCE (form-level), WHEN-VALIDATE-ITEM (B_PARTY.PARTY_CD), WHEN-VALIDATE-ITEM (B_PARTY.PO_STATUS), WHEN-VALIDATE-ITEM (B_SOQ.AMD_SOQ_QTY), WHEN-VALIDATE-ITEM (SB_TITLE.NO_MONTHS) | Displays a message string in an alert dialog (AL_ERRINFO for Error title, AL_NOTE for all other titles) with the specified severity title; used across the form and library for all user-facing error and informational messages |
| GENERAL.RAISE_ERROR | Attached Library (DPL - GENERAL package) | ON-ERROR (form-level) | Looks up a registered error code and displays the corresponding message; raises FORM_TRIGGER_FAILURE for error-severity messages; called in ON-ERROR for Oracle constraint violation code -02292 |
| GENERAL.CHECK_FORM_FAILURE | Attached Library (DPL - GENERAL package) | KEY-COMMIT (form-level) | Checks whether the most recent form operation succeeded; reports the error and raises FORM_TRIGGER_FAILURE if it did not; called twice in KEY-COMMIT to guard both the ENTER and COMMIT_FORM steps |
| GENERAL.L_POP_LIST_ITEM | Attached Library (DPL - GENERAL package) | WHEN-NEW-FORM-INSTANCE (form-level) | Populates a list item from a record group at form startup; accepts the record-group name and a SELECT statement, builds or refreshes the group, and transfers resulting rows into the target list item |
| PKG_DS_AUTO_CLEARANCE.SP_DEADSTK_PO_SO | Database Package (PKG_DS_AUTO_CLEARANCE) | WHEN-BUTTON-PRESSED in PB_BLK.PB_OK | Receives principal, consignment, parent, dealer, location, company, and processing-type parameters assembled by the form, then executes dead-stock automatic clearance logic - generating or updating associated purchase order and sales order records; returns the AOS reference number and error information via OUT parameters; a non-zero error response causes the form to display the error and halt further processing |
| PKG_DS_AUTO_CLEARANCE.FN_GET_PEND_ORDER | Database Package (PKG_DS_AUTO_CLEARANCE) | Called as part of the dead-stock auto-clearance evaluation workflow | Retrieves pending order information for a candidate dead-stock record to support the auto-clearance eligibility assessment |
| PK_VALIDATE_PARTS.UPDATE_ON_ORDER | Database Package (PK_VALIDATE_PARTS) | UPDATE_PO_STOCK program unit | Receives the complete list of amended SOQ part quantities, iterates through each part, locks or creates the corresponding PM_PART_VAR record, then increments or resets the on-order quantity based on the PO flag (R = raise, other = reset); any lock conflict, data width error, or DML failure returns a non-zero error code and message; the form displays the error and halts the save |
| SP_CALCULATE_SOQ_IMS | Database Procedure | WHEN-BUTTON-PRESSED (PB_BLK.PB_CALC_SOQ) as part of the SOQ calculation sequence | Executes the core SOQ calculation for the IMS multi-location context, producing suggested order quantities per part and location and populating PT_SOQ_MUL_TIL |
| SP_INSERT_PM_PART_VAR | Database Procedure | Called from PK_VALIDATE_PARTS.UPDATE_ON_ORDER processing chain | Inserts a new part variant record into PM_PART_VAR when no existing record is found during on-order quantity update processing |
| SP_SOQ_POPULATE_CONSUMPTION | Database Procedure | WHEN-BUTTON-PRESSED (SB_TITLE.SHOW_CON) | Retrieves monthly consumption history (up to the specified number of months), current stock level, and on-order quantity for a given part at a given location |
| SP_UPDATE_PART_PRICE | Database Procedure | WHEN-BUTTON-PRESSED processing chain (PO generation workflow) | Updates part price information as part of the SOQ or PO generation workflow |
| SP_UPDATE_PO_NUMBER_NEW | Database Procedure | WHEN-BUTTON-PRESSED processing chain (PO generation workflow) | Assigns or updates the system-generated PO number for SOQ-linked purchase orders |
| SF_COPYRIGHT_DECLARATION | Database Function | KEY-CLRFRM (form-level) | Returns the current financial-year copyright notice string based on today's date |
| DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Oracle Built-in Package | PRE-FORM trigger, KEY-EXIT trigger | Sets or clears the client-info attribute in the current database session for application monitoring |
| DBMS_APPLICATION_INFO.SET_MODULE | Oracle Built-in Package | PRE-FORM trigger, KEY-EXIT trigger | Sets or clears the module name and action attributes in the current database session for application monitoring |
| WEB.SHOW_DOCUMENT | Attached Library (D2KWUTIL) | VIEW_EXCEL_REP program unit | Opens the specified URL in the user's browser; used to deliver the exported CSV file |
| D2KWUTIL.ADD_ERROR | Attached Library (D2KWUTIL) | D2KWUTIL internal error-handling chain | Adds an error entry to the D2KWUTIL internal error stack |
| D2KWUTIL.ADD_EXTERNAL_ERRORS | Attached Library (D2KWUTIL) | D2KWUTIL internal error-handling chain | Adds externally sourced errors to the D2KWUTIL error stack for unified error reporting |
| D2KWUTIL.ATTEMPT_DLL_LOAD | Attached Library (D2KWUTIL) | D2KWUTIL library initialisation | Attempts to load a named DLL via the D2KWUTIL library; used to initialise native library support |
| D2KWUTIL.BOOLTOCHAR | Attached Library (D2KWUTIL) | D2KWUTIL utility calls | Converts a Boolean value to its character representation for use in D2KWUTIL utility calls |
| D2KWUTIL.CLEAN_ERROR_STACK | Attached Library (D2KWUTIL) | D2KWUTIL internal error-handling chain | Clears the D2KWUTIL internal error stack between operations |
| D2KWUTIL.CREATED_DATE | Attached Library (D2KWUTIL) | D2KWUTIL resource management | Returns the creation date metadata for a D2KWUTIL-managed resource |
| D2KWUTIL.D2KWUTIL_DEBUGSTRING | Attached Library (D2KWUTIL) | D2KWUTIL diagnostic logging | Returns a formatted debug string from the D2KWUTIL library for diagnostic logging |
| D2KWUTIL.D2KWUTIL_FILEINFO | Attached Library (D2KWUTIL) | D2KWUTIL file operations | Returns file metadata information via the D2KWUTIL library |
| D2KWUTIL.DEBUGLOG | Attached Library (D2KWUTIL) | D2KWUTIL diagnostic logging | Writes a debug log entry via the D2KWUTIL library |
| D2KWUTIL.FILE_INFO | Attached Library (D2KWUTIL) | VIEW_EXCEL_REP and D2KWUTIL file operations | Retrieves file system information for a specified file path via D2KWUTIL |
| D2KWUTIL.REGISTER_FUNCTION_CALL | Attached Library (D2KWUTIL) | D2KWUTIL diagnostic framework | Registers a function call event within the D2KWUTIL diagnostic framework |
| D2KWUTIL.SETDEBUG | Attached Library (D2KWUTIL) | D2KWUTIL diagnostic framework | Enables or disables D2KWUTIL debug-logging mode |
| D2KWUTIL.STRIPDIRSEP | Attached Library (D2KWUTIL) | VIEW_EXCEL_REP and D2KWUTIL file operations | Strips trailing directory separator characters from a file path string |
| D2KWUTIL.TRANSLATETYPE | Attached Library (D2KWUTIL) | D2KWUTIL diagnostic framework | Translates an internal type code to its display string within the D2KWUTIL framework |
| D2KWUTIL.WINDEBUG | Attached Library (D2KWUTIL) | D2KWUTIL diagnostic logging | Writes a debug entry to the D2KWUTIL windowed debug log |

## 13. Package Procedure Specifications

*Behavioural requirements for each database package invoked from the form. Only packages referenced in the form XML that have a matching source ``.pck`` file in the input directory are listed. Descriptions are derived from the package bodies in the uploaded PCK sources.*

| ID | Package | Description | Business Requirement | Acceptance Criteria |
| :--- | :--- | :--- | :--- | :--- |
| BR-T-PKG-DS-AUTO-CLEARANCE | PKG_DS_AUTO_CLEARANCE | Auto-clearance processing package invoked from the form to evaluate and automatically clear demand-supply records that meet predefined clearance criteria, reducing the need for manual intervention in routine clearance workflows. | The form depends on this package to assess eligible demand-supply records and apply automatic clearance logic so that qualifying records are resolved without requiring explicit user-driven approval steps. | PKG_DS_AUTO_CLEARANCE must evaluate all candidate records against clearance rules and clear qualifying records without error; records that do not meet clearance criteria must remain unchanged; any processing error must return a non-zero error code with a descriptive message and the form must surface the error and prevent any partial commit. |
| BR-T-PK-VALIDATE-PARTS | Pk_Validate_Parts | Parts order validation and on-order quantity update engine - exposes `update_on_order` to receive an ordered list of part quantities, validate each part exists in PM_PART_VAR, and update or insert on-order records accordingly. | The form depends on this package to validate and persist amended SOQ order quantities as on-order records in the parts inventory when the user saves the SOQ. | `update_on_order` must process all part rows without error for the commit to succeed; when a part record is missing from PM_PART_VAR it must be created before updating; any data error must return a non-zero error code and a descriptive message; the form must display the error and prevent save. |

**Total Matched Packages:** 2

## 14. Database Package Catalogue

*Detailed specifications for each database package routine called from the form, including signatures and business rules.*
**Source PCK file(s):** PKG_DS_AUTO_CLEARANCE.pck, PK_VALIDATE_PARTS.pck

| Source File (.pck) | Package | Routine Name | Type | Definition (signature / excerpt) | Called From | Purpose |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| PKG_DS_AUTO_CLEARANCE.pck | PKG_DS_AUTO_CLEARANCE | SP_DEADSTK_PO_SO | Procedure | PROCEDURE SP_DEADSTK_PO_SO(P_PRINCIPAL NUMBER, P_CONSG VARCHAR2, P_PARENT VARCHAR2, P_DEALER NUMBER, P_LOC VARCHAR2, P_COMP VARCHAR2, P_TYPE VARCHAR2, P_AOS_NUM OUT VARCHAR2, P_... | Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_OK | Invoked when the user clicks the OK button on the main canvas. Receives the principal, consignment, parent, dealer, location, company, and processing-type parameters assembled by the form, then executes the dead-stock automatic clearance logic - generating or updating the associated purchase order and sales order records. Returns the AOS reference number and any error information via OUT parameters; a non-zero error response causes the form to display the error message and halt further processing. |
| PK_VALIDATE_PARTS.pck | Pk_Validate_Parts | update_on_order | Procedure | PROCEDURE update_on_order(p_parent IN VARCHAR2, p_dealer IN NUMBER, p_loc_cd IN VARCHAR2, p_part_ordtab part_order_type, p_po_flag IN VARCHAR2, p_created_by IN VARCHAR2, p_error... | ProgramUnit: UPDATE_PO_STOCK | Receives the complete list of amended SOQ part quantities from the form, iterates through each part, locks or creates the corresponding PM_PART_VAR record, then increments or resets the on-order quantity based on the PO flag (R = raise, other = reset). Any lock conflict, data width error, or DML failure returns a non-zero error code and message to the calling form, which displays the error and halts the save. Invoked from UPDATE_PO_STOCK after the user confirms supplier and PO status. |

**Total Matched Package Routines (called from form XML):** 2

---

**Function return values:**

| Function | Returns | Values | Description |
| :--- | :--- | :--- | :--- |
| - | - | - | *No matched package functions with documented return values in the available PCK sources.* |

## 15. PLD Procedure Call Sites

*Maps each program-library routine to its call sites within triggers and program units. Behaviour descriptions are derived from the uploaded `.pld` sources.*

### DPL.pld (`general`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ASK_CONFIRM | Function | Function(confirm_msg VARCHAR2) RETURN NUMBER | Trigger: FT_CANCEL in Form, Trigger: FT_DEL in Form, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_CANCEL, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_COPY, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_CUT, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_DEL, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_EXIT, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_INSERT, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_LIST, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_PASTE, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_SAVE | Presents the supplied confirm_msg in a confirmation alert and returns a numeric result indicating the user's choice. Called from destructive or navigational button handlers (Cancel, Delete, Exit, Save, and clipboard operations) and from the FT_CANCEL and FT_DEL form-level triggers to obtain explicit user consent before proceeding with the operation. |
| CHECK_FORM_FAILURE | Procedure | Procedure() | Trigger: KEY-COMMIT in Form | Checks the Oracle Forms form_success flag after ENTER and COMMIT_FORM. If the last operation did not succeed, displays the Oracle error message (ORA errors via SQLERRM, Forms errors via ERROR_TEXT) through DISP_TEXT and raises FORM_TRIGGER_FAILURE, aborting the save. Called twice in KEY-COMMIT to guard both the enter and commit steps. |
| CHECK_NULL | Procedure | Procedure(p_value IN VARCHAR2, column_title IN VARCHAR2) | Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_CALC_SOQ, Trigger: WHEN-VALIDATE-ITEM in B_PARTY.PARTY_CD, Trigger: WHEN-VALIDATE-ITEM in B_PRN.NB_AS_ON_DATE, Trigger: WHEN-VALIDATE-ITEM in SB_TITLE.PART_CATEG, Trigger: WVI in B_PARTY.PO_STATUS | Raises FORM_TRIGGER_FAILURE with an error message ("Enter a valid {column_title}") when p_value is null. Used to enforce mandatory entry on category, PO status, and as-on date fields before the form allows navigation, and additionally guards the SOQ calculation button to ensure required inputs are present before the calculation is attempted. |
| DISP_TEXT | Procedure | Procedure(text_string VARCHAR2, title_string VARCHAR2) | ProgramUnit: BUILD_WHERE, Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: POST-QUERY in B_SOQ, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.BT_EXCEL, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_CALC_SOQ, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_ESOQ, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_OK, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_SEARCH, Trigger: WHEN-BUTTON-PRESSED in SB_TITLE.SHOW_CON, Trigger: WHEN-NEW-FORM-INSTANCE in Form, Trigger: WHEN-VALIDATE-ITEM in B_PARTY.PARTY_CD, Trigger: WHEN-VALIDATE-ITEM in B_PARTY.PO_STATUS, Trigger: WHEN-VALIDATE-ITEM in B_SOQ.AMD_SOQ_QTY, Trigger: WHEN-VALIDATE-ITEM in SB_TITLE.NO_MONTHS | Displays the supplied text_string in an alert dialog (AL_ERRINFO for Error title, AL_NOTE for all other titles) with the specified title_string. Used across the form and library for user-facing error and informational messages. The call surface has expanded relative to the prior baseline to include the ON-MESSAGE form trigger, several PB_BLK toolbar button handlers (BT_EXCEL, PB_CALC_SOQ, PB_ESOQ, PB_OK, PB_SEARCH), the WHEN-NEW-FORM-INSTANCE initialisation trigger, and the PO_STATUS validation trigger. |
| l_pop_list_item | Procedure | Procedure(p_rg_name VARCHAR2, p_select VARCHAR2) | Trigger: WHEN-NEW-FORM-INSTANCE in Form | Populates a list item from a record group at form startup. Accepts the record-group name (p_rg_name) and a SELECT statement (p_select) used to build or refresh the group, then transfers the resulting rows into the target list item. Called once during WHEN-NEW-FORM-INSTANCE to initialise list-of-values controls before the user interacts with the form. |
| RAISE_ERROR | Procedure | Procedure(mesg_code IN VARCHAR2) | Trigger: ON-ERROR in Form | Looks up the message text for the supplied error code (e.g. E0088) in the message catalogue, formats it, and calls DISP_TEXT to show the error to the user. Raises FORM_TRIGGER_FAILURE for error-severity messages. Called in ON-ERROR for Oracle constraint violation code -02292. |

**Total Active Routines:** 6 of 24 in DPL.pld source

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| ID | Service Name | Database Object | Input Parameters | Output | Business Function | API Endpoint Suggestion |
| -- | ------------ | --------------- | ---------------- | ------ | ----------------- | ----------------------- |
| MS-001 | Location Loader Service | AM_DEALER_LOC | parent_group, principal_map_cd, consg_cd, scope (all / home), loc_cd (for home-location mode), loc_desc (for home-location mode), dealer_map_cd (for home-location mode) | List of location records: loc_cd, loc_desc, dealer_map_cd | Loads the list of active service locations for the SOQ scope based on consignee and session mode | GET /api/soq/locations |
| MS-002 | Last SOQ Date Service | PT_SOQ_MUL_TIL, PM_CATEGORY | parent_group, dealer_map_cd, loc_cd, comp_fa, catg_cd | as_on_date (last SOQ date), catg_desc (category description), catg_cd | Retrieves the most recent SOQ calculation date and category description for the selected dealership and parts category | GET /api/soq/last-date |
| MS-003 | SOQ Consumption Service | SP_SOQ_POPULATE_CONSUMPTION (database procedure) | dealer_map_cd (or parent dealer), principal, parent_group, loc_cd, comp_fa, part_num (root part), months, reference_date | Monthly consumption array (up to months entries), current stock, on-order quantity, error code, error message | Retrieves monthly consumption history, current stock level, and on-order quantity for a specified part at a specified location | GET /api/soq/consumption |
| MS-004 | Part Pricing and Rules Service | PM_PART, PM_PART_VAR | principal, parent_group, dealer_map_cd, loc_cd, part_num | purchase_price, min_ord_qty, allow_decimal_qty | Retrieves the current purchase price, minimum pack quantity, and decimal-quantity rule for a part at a specified location | GET /api/parts/pricing |
| MS-005 | Supplier Validation Service | GM_PARTY | parent_group, dealer_map_cd, party_cd, mul_yn (multi-location flag) | party_name | Validates a supplier code against the supplier master for the appropriate type and returns the supplier name | GET /api/suppliers/{party_cd} |
| MS-006 | On-Order Update Service | PK_VALIDATE_PARTS.UPDATE_ON_ORDER | parent_group, dealer_map_cd, loc_cd, part_order_list (array of part_num + qty), po_status, created_by | error_code, error_message | Updates on-order quantities in the part variant records for the specified list of parts and quantities; applies the PO status | POST /api/soq/update-on-order |
| MS-007 | Copyright Declaration Service | SF_COPYRIGHT_DECLARATION (database function) | (none) | copyright_string | Returns the current financial-year copyright notice string | GET /api/system/copyright |
| MS-008 | SOQ Record Query and Amendment Service | PT_SOQ_MUL_TIL | parent_group, dealer_map_cd, loc_cd, catg_cd, filters (show_zero, edit_mode, sort_by, sort_direction) | List of SOQ records with part details, quantities, and pricing | Queries and returns the SOQ parts list for the specified scope and filters; supports amendment of order quantities | GET /api/soq/records, PUT /api/soq/records/{part_num} |

**Total Microservices Identified: 8**

---

## 17. Workflows

| ID | Workflow Name | Trigger Event | Steps | Decision Points | End State |
| -- | ------------- | ------------- | ----- | --------------- | --------- |
| WF-001 | Form Session Registration | User opens the Suggested Order Quantity Processing form (PRE-FORM trigger) | 1. Database session is tagged with the form name for application monitoring | None | Session is registered; form opens for the user |
| WF-002 | Form Initialization and Location Load | User opens the form or resets all data (KEY-CLRFRM trigger) | 1. Screen data cleared and editable fields re-enabled; 2. Default filter values set; 3. Active locations loaded into location list (FETCH_LOC); 4. Last SOQ date and category retrieved (GET_LAST_SOQ_DATE); 5. Default SOQ filter applied; 6. Copyright notice refreshed (SF_COPYRIGHT_DECLARATION) | Single-location vs. stock-yard (all-locations) mode determines which locations are loaded | Form is ready for the user to set filter criteria and trigger a SOQ calculation |
| WF-003 | SOQ Filter and Calculation | User sets filters (category, months, locations) and triggers the SOQ calculation | 1. Parts Category validated as mandatory (GENERAL.CHECK_NULL); 2. Months of Consumption validated as mandatory; 3. Locations validated - at least one must be selected (BUILD_WHERE); 4. Prior SOQ location pre-selection applied (LOC_CATEG_POPULATION); 5. SOQ data is calculated and loaded into the parts list | If any mandatory filter is blank or no location is selected, the flow stops with an error | SOQ parts list displayed with calculated quantities, pricing, and editability set per part family age |
| WF-004 | SOQ Row Initialization | Each SOQ record row is loaded into the parts list (POST-QUERY and WHEN-NEW-RECORD-INSTANCE triggers on B_SOQ) | 1. Serial number assigned; 2. Purchase price, minimum pack quantity, and decimal flag fetched from part master and variant; 3. Amended quantity editability set based on part family age and category; 4. Consumption detail panel cleared | NO_DATA_FOUND for part details: defaults applied silently; VALUE_ERROR or OTHERS: error shown and row load fails; Part family age 0 or 6 (standard category): amended quantity locked | SOQ row is displayed with pricing and correct editability for the user |
| WF-005 | SOQ Quantity Amendment | User amends the order quantity for an eligible part row | 1. User enters amended quantity; 2. Decimal-quantity rule checked on field exit (WHEN-VALIDATE-ITEM): quantity truncated if decimals not allowed, or error shown if flag is invalid | Decimal allowed: quantity accepted as-is; Decimal not allowed: quantity truncated to integer; Error flag: amendment blocked | Amended quantity is updated in the form pending save |
| WF-006 | Show Consumption Detail | User clicks the Show Consumption button for a selected part | 1. Part number checked - must not be blank; 2. Date basis set (exclude current month); 3. Consumption detail area cleared; 4. Location count checked - must not be zero; 5. For each location: root part number looked up; 6. Consumption procedure called (SP_SOQ_POPULATE_CONSUMPTION) per location; 7. Monthly figures, average, current stock, and on-order written to detail rows | No part number: error, stop; No locations: warning, stop; Root part not found (various errors): error, stop per location; Consumption retrieval error: error, stop | Consumption detail panel shows monthly figures per location for the selected part |
| WF-007 | Sort SOQ List | User changes Sort By or Sort Type selector (WHEN-LIST-CHANGED on NB_SORT_BY or NB_SORT_TYPE) | 1. Pending changes saved; 2. Sort column and direction determined from selectors; 3. SOQ list re-queried in the new order (SORT_BLOCK) | Sort column selection determines which column is ordered (part number, SOQ quantity, amended quantity, purchase price, or total value) | SOQ list is refreshed in the selected sort order |
| WF-008 | Filter SOQ List by Edit-Mode | User changes the Ammended Qty edit-mode filter (WHEN-LIST-CHANGED on NB_EDIT_LST) | 1. Pending changes saved; 2. Filter applied based on edit-mode selection (All, Editable, Non-editable) combined with category; 3. Show-zero-SOQ indicator set to show all records; 4. SOQ list re-queried | Category = all-parts: age-filter not applied; Standard category: Editable mode shows only qualifying-age parts, Non-editable shows only excluded-age parts | SOQ list refreshed showing only parts matching the selected edit-mode |
| WF-009 | Toggle Zero-SOQ Display | User ticks or unticks Show zero SOQ checkbox (WHEN-CHECKBOX-CHANGED on SHOW_ZERO_SOQ) | 1. Pending changes saved; 2. Filter updated to include or exclude zero-SOQ parts combined with current edit-mode and category; 3. SOQ list re-queried; 4. Grand total value recalculated | Category and edit-mode determine the combined filter; zero-SOQ condition is toggled on top | SOQ list refreshed with updated parts scope; grand total value updated |
| WF-010 | Save and Commit SOQ Amendments | User triggers the save action (KEY-COMMIT trigger) | 1. Pending entries validated (enter); 2. Entry success checked (GENERAL.CHECK_FORM_FAILURE); 3. Amended quantities committed (commit_form); 4. Commit success checked (GENERAL.CHECK_FORM_FAILURE); 5. Form cleared and reinitialized (DO_KEY CLEAR_FORM -> WF-002) | Entry or commit failure: error shown, save aborted, form remains for user to review | All amended SOQ quantities are saved; form resets to initial state |
| WF-011 | Generate Purchase Order | User triggers the PO generation action | 1. All part order quantities assembled from SOQ list; 2. On-order quantities updated at database level (PK_VALIDATE_PARTS.UPDATE_ON_ORDER via UPDATE_PO_STOCK) | On-order update error: error message shown in CN_ERR panel, PO generation stopped | On-order quantities updated; purchase order generated and recorded at the database level |
| WF-012 | Toggle Consignee-Level Location Scope | User ticks or unticks the Consigne Level checkbox (WHEN-CHECKBOX-CHANGED on CHK_STK_YARD) | 1. Checkbox value checked; 2. Location list reloaded via FETCH_LOC with the new scope | Stock-yard mode: all active consignee locations loaded; Single-location mode: only home location loaded | Location list refreshed to reflect the new scope |
| WF-013 | Supplier Selection and PO Detail Entry | User navigates to the PO details panel | 1. Supplier LOV assigned based on session mode (WHEN-NEW-BLOCK-INSTANCE on B_PARTY); 2. User selects supplier; 3. Supplier validated against the master (WHEN-VALIDATE-ITEM on PARTY_CD); 4. Supplier name auto-populated; 5. PO Status entered; 6. PO Status validated as mandatory (WVI on PO_STATUS via GENERAL.CHECK_NULL) | Stock-yard mode: multi-location supplier LOV used; Standard mode: single-location supplier LOV used; Invalid supplier: error shown | Valid supplier and PO status recorded; user can proceed to save or generate PO |
| WF-014 | Print SOQ History Report | User selects a date and clicks Report on the report date panel | 1. As On Date checked - must not be blank; 2. Report generation sequence executed (Execute_Trigger FT_PRINT -> PT_SOQHS report) | Date blank: no action taken | PT_SOQHS report generated and displayed for the selected date |
| WF-015 | Excel Export of SOQ Data | User triggers the Excel export action | 1. Unique filename generated from user ID and timestamp; 2. SOQ data queried into a record group; 3. Row count checked against Excel limit; 4. Data written row by row to a server-side CSV file; 5. File URL opened in the browser | Row count > 65,536: truncated to 65,535 with user notification; File path has spaces: redirected to C drive | CSV file is available for the user to download or open in Excel |
| WF-016 | Form Exit and Session De-registration | User triggers the exit action (KEY-EXIT trigger) | 1. Session client-info and module attributes cleared (DBMS_APPLICATION_INFO); 2. Form closed immediately without saving | None (unconditional) | Form is closed; session monitoring attributes are cleared |

**Total Workflows Identified: 16**

---

## 18. PLD-Backed Logic

*Maps shared library routines to their business function and suggested API contracts.*

### DPL.pld (`general`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | CHECK_FORM_FAILURE | Validation | Trigger: KEY-COMMIT in Form | /api/v1/pld/check_form_failure | When the last form operation fails, then the save is aborted and the error message is shown to the user |
| PLD-002 | CHECK_NULL | Validation | Trigger: WHEN-VALIDATE-ITEM in B_PARTY.PARTY_CD, Trigger: WHEN-VALIDATE-ITEM in B_PRN.NB_AS_ON_DATE, Trigger: WHEN-VALIDATE-ITEM in SB_TITLE.PART_CATEG, Trigger: WVI in B_PARTY.PO_STATUS | /api/v1/pld/check_null | When a mandatory field is left empty, then the user is alerted and navigation is blocked |
| PLD-003 | DISP_TEXT | Business Logic | ProgramUnit: BUILD_WHERE, Trigger: ON-ERROR in Form, Trigger: POST-QUERY in B_SOQ, Trigger: WHEN-BUTTON-PRESSED in SB_TITLE.SHOW_CON, Trigger: WHEN-VALIDATE-ITEM in B_PARTY.PARTY_CD, Trigger: WHEN-VALIDATE-ITEM in B_SOQ.AMD_SOQ_QTY, Trigger: WHEN-VALIDATE-ITEM in SB_TITLE.NO_MONTHS | /api/v1/pld/disp_text | When an error or informational event occurs, then a modal dialog is shown to the user with the appropriate title and message |
| PLD-004 | RAISE_ERROR | Validation | Trigger: ON-ERROR in Form | /api/v1/pld/raise_error | When a catalogued error code is raised, then the corresponding error message is displayed and form trigger failure is raised |


---

### D2kwutil.pld (`Win_API`)

*No routines from ``D2kwutil.pld`` are referenced in ``pt_soq_ims_fmb.xml``.*

---

---

## 19. PCK-Backed Logic

*Maps database package routines to their business rules and suggested API contracts.*

| ID | Package.Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ------------- | ---- | ---------- | ------------- | --------------------- |
| PCK-001 | Pk_Validate_Parts.update_on_order | Business Logic | ProgramUnit: UPDATE_PO_STOCK | /api/v1/packages/pk_validate_parts/update_on_order | When the user saves amended SOQ quantities, then on-order quantities in PM_PART_VAR are updated or created for each part, and any failure returns an error code that prevents the commit |

---

---

## 20. System Interfaces

### 20.1 Database Integrations

| Interface Name | Type | Purpose | Data Flow | Error Handling |
| -------------- | ---- | ------- | --------- | -------------- |
| SOQ Record Table (PT_SOQ_MUL_TIL) | Oracle Table (SELECT, UPDATE) | Primary data source for the SOQ parts list; stores the system-calculated SOQ quantity and the user-amended quantity for each part per location | Form reads SOQ records into the parts list on query; amended quantities and audit stamps (modified by / modified date) are written back on commit | NO_DATA_FOUND: silently ignored (no prior SOQ exists); concurrent update conflicts (error codes 40654-40659): user notified via ON-ERROR handler, change rolled back |
| Part Master (PM_PART) | Oracle Table (SELECT) | Provides the minimum pack quantity, decimal-quantity flag, category code, and root part number for each part | Form reads on each SOQ row load (POST-QUERY) and when the consumption detail is fetched (WHEN-BUTTON-PRESSED SHOW_CON) | NO_DATA_FOUND: defaults applied (min_ord_qty=0, allow_decimal_qty='N'); VALUE_ERROR: error shown and row load fails; OTHERS: error shown and row load fails |
| Part Pricing Variant (PM_PART_VAR) | Oracle Table (SELECT) | Provides the current purchase price for each part at the current dealer location | Form reads on each SOQ row load (POST-QUERY) | NO_DATA_FOUND: purchase price defaults to 0; VALUE_ERROR and OTHERS: error shown |
| Service Location Master (AM_DEALER_LOC) | Oracle Table (SELECT) | Provides the list of active live service locations for the consignee and principal | Form reads when loading the location list (FETCH_LOC) on initialization and on checkbox toggle | No locations found: location list remains empty; SOQ calculation button stays disabled |
| Supplier Master (GM_PARTY) | Oracle Table (SELECT) | Provides supplier name and validates supplier code for PO generation | Form reads on supplier field validation (WHEN-VALIDATE-ITEM B_PARTY.PARTY_CD) and populates the supplier LOV record groups (RG_MUL_PARTY, RG_NON_MUL_PARTY) | NO_DATA_FOUND: *"Enter a valid Supplier"* shown and field rejected; OTHERS: database error text shown |
| Parts Category Master (PM_CATEGORY) | Oracle Table (SELECT) | Provides the category description for the last SOQ date display | Form reads when retrieving the last SOQ date (GET_LAST_SOQ_DATE) | NO_DATA_FOUND or OTHERS: last SOQ date and category set to null; no error shown |
| SOQ History - Multi-location (PT_SOQ_MUL_TIL) | Oracle Table (SELECT) | Provides the most recent SOQ calculation date for retrieval by GET_LAST_SOQ_DATE | Form reads on initialization (GET_LAST_SOQ_DATE) | NO_DATA_FOUND or OTHERS: fields left null |
| SOQ Staging - Multi (PT_SOQ_MUL_NEW) | Oracle Table (SELECT) | Used by LOC_CATEG_POPULATION to check whether a prior SOQ exists and identify its category | Form reads during SOQ setup | OTHERS: silently suppressed |
| SOQ Staging - Single (PT_SOQ_NEW) | Oracle Table (SELECT) | Used by LOC_CATEG_POPULATION to identify which locations were included in the most recent prior SOQ | Form reads during SOQ setup | OTHERS: silently suppressed |
| On-Order Update Procedure (PK_VALIDATE_PARTS.UPDATE_ON_ORDER) | Oracle Package Procedure (CALL) | Updates on-order quantities in PM_PART_VAR for all parts in the order list and records the PO status | Form calls via UPDATE_PO_STOCK on PO generation; passes list of parts and amended quantities, PO status, and user | Non-zero error code returned: error message displayed in CN_ERR panel; PO generation stops |
| Consumption Procedure (SP_SOQ_POPULATE_CONSUMPTION) | Oracle Procedure (CALL) | Retrieves monthly consumption history, current stock, and on-order quantity for a part at a location | Form calls from WHEN-BUTTON-PRESSED (SHOW_CON) once per loaded location | Non-zero error code: error message shown to user; consumption fetch stops for that location |
| Copyright Function (SF_COPYRIGHT_DECLARATION) | Oracle Function (CALL) | Returns the current financial-year copyright string | Form calls from KEY-CLRFRM on initialization | N/A (function always returns a value) |

### 20.2 External System Integrations

The form accesses one external file resource: a server-side text file (`/reports/DMS/excelpath.txt`) that holds the base URL path for saving and delivering exported CSV files. This file is read by the VIEW_EXCEL_REP program unit when the user triggers the Excel export. The file is external to the Oracle Forms application and is not in the form bundle. All other processing is contained within the Oracle database and the DMS application.

| System Name | Integration Type | Purpose | Protocol | Endpoint | Data Exchange | Success / Error Codes |
| ----------- | ---------------- | ------- | -------- | -------- | ------------- | --------------------- |
| DMS Excel Path Configuration (`/reports/DMS/excelpath.txt`) | Server file read | Provides the base URL path for delivering the exported CSV file to the user's browser | Server-side file I/O (TEXT_IO) | `/reports/DMS/excelpath.txt` on the Forms application server | Reads one line: the base URL path string | File not found or read error: WHEN OTHERS catches the exception and shows *"Error  -"* + error code + error text; export fails |
| Browser (WEB.SHOW_DOCUMENT via D2KWUTIL) | Web URL delivery | Opens the generated CSV file URL in the user's browser as a downloadable file | HTTP (browser-initiated download) | Constructed from the excelpath.txt base URL + generated filename | Passes the CSV file URL to the browser as a new-tab document | Delivery failure caught by WHEN OTHERS in VIEW_EXCEL_REP; *"Error  -"* shown |

### 20.3 Report Integrations

| Report Name | Report Server | Parameters | Output Format | Trigger |
| ----------- | ------------- | ---------- | ------------- | ------- |
| PT_SOQHS | INFERRED (Oracle Reports server configured for the DMS environment) | as_on_date (the date entered by the user on the report date panel - B_PRN.NB_AS_ON_DATE) | INFERRED (standard Oracle Reports output - screen / PDF) | WHEN-BUTTON-PRESSED on B_PRN.PB_REP calls Execute_Trigger('FT_PRINT'); FT_PRINT is an inherited trigger from OG_GROUP that executes the report using the PT_SOQHS report object (Filename="PT_SOQHS", ExecuteMode="Runtime") |

---

### 20.3.1 Parameters Passed to the Report

This form does not pass parameters to an Oracle Report. No report parameters were identified in the form sources.

## 21. Procedure and Function Business Rule Catalogue

End-to-end business requirement specification for every stored procedure and function referenced by the PT_SOQ_IMS form.

### 21.1 Catalogue Index

36 procedures/functions - each SP ID links to its detailed specification in Section 21.2.

| SP Index | Routine Name |
| :--- | :--- |
| [SP-001](#SP-001--FETCH_LOC) | FETCH_LOC |
| [SP-002](#SP-002--GET_LAST_SOQ_DATE) | GET_LAST_SOQ_DATE |
| [SP-003](#SP-003--LOC_CATEG_POPULATION) | LOC_CATEG_POPULATION |
| [SP-004](#SP-004--SORT_BLOCK) | SORT_BLOCK |
| [SP-005](#SP-005--UPDATE_PO_STOCK) | UPDATE_PO_STOCK |
| [SP-006](#SP-006--VIEW_EXCEL_REP) | VIEW_EXCEL_REP |
| [SP-007](#SP-007--D2KWUTIL.ADD_ERROR) | D2KWUTIL.ADD_ERROR |
| [SP-008](#SP-008--D2KWUTIL.ADD_EXTERNAL_ERRORS) | D2KWUTIL.ADD_EXTERNAL_ERRORS |
| [SP-009](#SP-009--D2KWUTIL.ATTEMPT_DLL_LOAD) | D2KWUTIL.ATTEMPT_DLL_LOAD |
| [SP-010](#SP-010--D2KWUTIL.BOOLTOCHAR) | D2KWUTIL.BOOLTOCHAR |
| [SP-011](#SP-011--D2KWUTIL.CLEAN_ERROR_STACK) | D2KWUTIL.CLEAN_ERROR_STACK |
| [SP-012](#SP-012--D2KWUTIL.CREATED_DATE) | D2KWUTIL.CREATED_DATE |
| [SP-013](#SP-013--D2KWUTIL.D2KWUTIL_DEBUGSTRING) | D2KWUTIL.D2KWUTIL_DEBUGSTRING |
| [SP-014](#SP-014--D2KWUTIL.D2KWUTIL_FILEINFO) | D2KWUTIL.D2KWUTIL_FILEINFO |
| [SP-015](#SP-015--D2KWUTIL.DEBUGLOG) | D2KWUTIL.DEBUGLOG |
| [SP-016](#SP-016--D2KWUTIL.FILE_INFO) | D2KWUTIL.FILE_INFO |
| [SP-017](#SP-017--D2KWUTIL.REGISTER_FUNCTION_CALL) | D2KWUTIL.REGISTER_FUNCTION_CALL |
| [SP-018](#SP-018--D2KWUTIL.SETDEBUG) | D2KWUTIL.SETDEBUG |
| [SP-019](#SP-019--D2KWUTIL.STRIPDIRSEP) | D2KWUTIL.STRIPDIRSEP |
| [SP-020](#SP-020--D2KWUTIL.TRANSLATETYPE) | D2KWUTIL.TRANSLATETYPE |
| [SP-021](#SP-021--D2KWUTIL.WINDEBUG) | D2KWUTIL.WINDEBUG |
| [SP-022](#SP-022--GENERAL.ASK_CONFIRM) | GENERAL.ASK_CONFIRM |
| [SP-023](#SP-023--GENERAL.CHECK_FORM_FAILURE) | GENERAL.CHECK_FORM_FAILURE |
| [SP-024](#SP-024--GENERAL.CHECK_NULL) | GENERAL.CHECK_NULL |
| [SP-025](#SP-025--GENERAL.DISP_TEXT) | GENERAL.DISP_TEXT |
| [SP-026](#SP-026--GENERAL.L_POP_LIST_ITEM) | GENERAL.L_POP_LIST_ITEM |
| [SP-027](#SP-027--GENERAL.RAISE_ERROR) | GENERAL.RAISE_ERROR |
| [SP-028](#SP-028--PKG_DS_AUTO_CLEARANCE.FN_GET_PEND_ORDER) | PKG_DS_AUTO_CLEARANCE.FN_GET_PEND_ORDER |
| [SP-029](#SP-029--PKG_DS_AUTO_CLEARANCE.SP_DEADSTK_PO_SO) | PKG_DS_AUTO_CLEARANCE.SP_DEADSTK_PO_SO |
| [SP-030](#SP-030--PK_VALIDATE_PARTS.UPDATE_ON_ORDER) | PK_VALIDATE_PARTS.UPDATE_ON_ORDER |
| [SP-031](#SP-031--SF_COPYRIGHT_DECLARATION) | SF_COPYRIGHT_DECLARATION |
| [SP-032](#SP-032--SP_CALCULATE_SOQ_IMS) | SP_CALCULATE_SOQ_IMS |
| [SP-033](#SP-033--SP_INSERT_PM_PART_VAR) | SP_INSERT_PM_PART_VAR |
| [SP-034](#SP-034--SP_SOQ_POPULATE_CONSUMPTION) | SP_SOQ_POPULATE_CONSUMPTION |
| [SP-035](#SP-035--SP_UPDATE_PART_PRICE) | SP_UPDATE_PART_PRICE |
| [SP-036](#SP-036--SP_UPDATE_PO_NUMBER_NEW) | SP_UPDATE_PO_NUMBER_NEW |

---

### 21.2 Detailed Specifications

#### SP-001 - FETCH_LOC

**Invoked From:**

- pt_soq_ims_fmb.xml [Trigger: KEY-CLRFRM]
- pt_soq_ims_fmb.xml [Trigger: WHEN-CHECKBOX-CHANGED]
- pt_soq_ims_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

N/A

---

**Purpose**

Fetches dealer location records into the b_loc block and a PL/SQL table (dealer_loc.dloc_tab) for use during SOQ form initialisation, form clear, and checkbox-change events. When invoked in 'all records' mode the procedure queries AM_DEALER_LOC for every live location belonging to the current parent group, consignee, and principal; otherwise it loads only the single location held in global/parameter context. After population the block is made read-only and focus is returned to the SB_TITLE block.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| all_rec | CHAR | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Initialise the PL/SQL location table: if dealer_loc.dloc_tab already contains rows, delete all entries to ensure a clean load.
- Step 2 - Enable insert, update, and delete on the b_loc block to allow programmatic population.
- Step 3 - Navigate to the b_loc block, clear it without validation, and move to the first record.
- Step 4 - Evaluate the all_rec input parameter to determine which population path to follow.
- Step 5 (all_rec = 'Y') - Open dealer_cur, which selects loc_cd, loc_desc, and dealer_map_cd from AM_DEALER_LOC filtered by GLOBAL.parent_group, parameter.p_consg_cd, GLOBAL.principal, and a non-null SRV_LIVE_DATE (live locations only).
- Step 6 (all_rec = 'Y') - For each row returned by dealer_cur, write loc_cd, loc_desc, dealer_map_cd, and a serial number (SYSTEM.cursor_record) to the current b_loc record, mirror the same values into dealer_loc.dloc_tab at the corresponding index, set check_yn to 'Y', then advance to the next record.
- Step 7 (all_rec ≠ 'Y') - Load a single record into b_loc using GLOBAL.loc_cd, parameter.p_loc_desc, and GLOBAL.dealer; set srl_no to 1 and check_yn to 'Y'; store the same values in dealer_loc.dloc_tab at index 1.
- Step 8 - Revoke insert, update, and delete permissions on b_loc to make the block read-only after population.
- Step 9 - Navigate focus to the SB_TITLE block to complete the procedure.

---
**Decision Points**

DP-001

Condition:
dloc_tab.COUNT > 0 (the PL/SQL location table is non-empty at the start of the procedure)

TRUE:
Delete all existing rows from dealer_loc.dloc_tab before repopulating, preventing stale location data from persisting across invocations.

FALSE:
Skip the delete step; the table is already empty and can be populated directly.

---

DP-002

Condition:
all_rec = 'Y'

TRUE:
Execute dealer_cur against AM_DEALER_LOC (filtered by parent group, consignee, principal, and live SRV_LIVE_DATE) and iterate over all matching location rows, populating b_loc and dealer_loc.dloc_tab with one entry per location.

FALSE:
Bypass the database query and load a single location record into b_loc and dealer_loc.dloc_tab using the values already held in GLOBAL.loc_cd, parameter.p_loc_desc, and GLOBAL.dealer.

---
**Database Interactions**

- DB-001 - Read AM_DEALER_LOC - Reads data from AM_DEALER_LOC for lookup or validation.
**Business Rules**

- BR-001 - Only locations with a non-null SRV_LIVE_DATE are eligible for retrieval; inactive or not-yet-live locations are excluded from the result set.
- BR-002 - Location retrieval is always scoped to the current parent group (GLOBAL.parent_group), consignee (parameter.p_consg_cd), and principal (GLOBAL.principal), ensuring cross-company data isolation.
- BR-003 - The dealer_loc.dloc_tab PL/SQL table must be cleared before each load cycle to prevent residual location data from a prior invocation from appearing in the current session context.
- BR-004 - Every location record loaded into b_loc is automatically pre-selected (check_yn = 'Y'), indicating that all fetched locations are included by default.
- BR-005 - The b_loc block is set to fully editable (insert, update, delete allowed) only for the duration of the programmatic load; permissions are revoked immediately after population to prevent end-user modification of the location list.
- BR-006 - When all_rec ≠ 'Y', exactly one location record is loaded, derived from the global and parameter context rather than a live database query, supporting single-location form scenarios such as direct navigation or form-clear resets.

---
**Implementation Logic**

```plsql
PROCEDURE fetch_loc (all_rec CHAR DEFAULT 'N')
IS
      CURSOR dealer_cur
      IS
            SELECT loc_cd,
                   loc_desc,
                   dealer_map_cd                /*Added by Anjiv on 01/12/2006 to get dealer_map_cd under the consignee */
            FROM   am_dealer_loc
            WHERE  parent_group = :GLOBAL.parent_group
                   --Commented by Anjiv on 03-03-06 to generate SOQ at the consigne level
                   --and           dealer_map_cd = :global.dealer;
            AND consg_cd = :parameter.p_consg_cd
            AND principal_map_cd = :global.principal --Added by Rajeev for multi company changes
            and SRV_LIVE_DATE is not null;             /*Added by Anjiv on 19/01/2007 to show live locations only.*/
BEGIN
      IF dealer_loc.dloc_tab.COUNT > 0 THEN                                      --initialise the plsql table of dealer locations
            dealer_loc.dloc_tab.DELETE;
      END IF;
      
      set_block_property('b_loc',insert_allowed,property_true);
      set_block_property('b_loc',update_allowed,property_true);
      set_block_property('b_loc',delete_allowed,property_true);
      
      GO_BLOCK ('b_loc');
      CLEAR_BLOCK (no_validate);
      FIRST_RECORD;
      IF all_rec = 'Y' THEN
            FOR dealer_rec IN dealer_cur
            LOOP
                  :b_loc.srl_no :=:SYSTEM.cursor_record;
                  :b_loc.loc_cd := dealer_rec.loc_cd;
                  :b_loc.loc_desc := dealer_rec.loc_desc;
                  :b_loc.dealer_map_cd := dealer_rec.dealer_map_cd; /*Added by Anjiv on 01/12/2006 to get dealer_map_cd under the consignee */
                  dealer_loc.dloc_tab (:SYSTEM.cursor_record).col1 := dealer_rec.loc_cd;
                  dealer_loc.dloc_tab (:SYSTEM.cursor_record).col2 := dealer_rec.loc_desc;
                  dealer_loc.dloc_tab (:SYSTEM.cursor_record).col3 := dealer_rec.dealer_map_cd;    /*Added by Anjiv on 01/12/2006 to get dealer_map_cd under the consignee */
                  :b_loc.check_yn := 'Y';
                  /*
                  SET_ITEM_INSTANCE_PROPERTY ('b_loc.check_yn', current_record, update_allowed, property_false);
                  SET_ITEM_INSTANCE_PROPERTY ('b_loc.check_yn', current_record, insert_allowed, property_false);
                  */
                  NEXT_RECORD;
            END LOOP;
      ELSE
            :b_loc.check_yn := 'Y';
            :b_loc.srl_no:=1;
            :b_loc.loc_cd := :GLOBAL.loc_cd;
            :b_loc.loc_desc := :parameter.p_loc_desc;
            :b_loc.dealer_map_cd := :GLOBAL.dealer;
            dealer_loc.dloc_tab (1).col1 := :GLOBAL.loc_cd;
            dealer_loc.dloc_tab (1).col2 := :parameter.p_loc_desc;
            dealer_loc.dloc_tab (1).col3 := :GLOBAL.dealer;
      END IF;
      
      set_block_property('b_loc',insert_allowed,property_false);
			set_block_property('b_loc',update_allowed,property_false);
      set_block_property('b_loc',delete_allowed,property_false);
      --GO_BLOCK ('b_loc');
      --FIRST_RECORD;
      GO_BLOCK ('SB_TITLE');
      --go_item('SB_TITLE.PART_CATEG');
END;
```

#### SP-002 - GET_LAST_SOQ_DATE

**Invoked From:**

- pt_soq_ims_fmb.xml [Trigger: KEY-CLRFRM]
- pt_soq_ims_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]
- pt_soq_ims_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

SUGGESTED ORDER QUANTITY PROCESSING (N/A / CN_MAIN)

---

**Purpose**

Retrieves the most recent Suggested Order Quantity (SOQ) date and the associated category description for the current session context (parent group, dealer, location, company, and part category). The results are used to populate display fields on the SUGGESTED ORDER QUANTITY PROCESSING screen so that users can see when the last SOQ was generated and under which product category.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Using the current session globals (GLOBAL.parent_group, GLOBAL.dealer, GLOBAL.loc_cd, GLOBAL.comp_fa) and the screen-level part category (:SB_TITLE.part_categ), query PT_SOQ_MUL_TIL joined to PM_CATEGORY to obtain the AS_ON_DATE (last SOQ date), category description, and category code for the first matching SOQ header record (ROWNUM < 2).
- Step 2 - The PM_CATEGORY join is resolved by looking up the category code from PM_PART where the part number matches the SOQ line and the dealer map code is either the principal or the dealer, further filtered by GLOBAL.principal as the principal map code, ensuring multi-company correctness.
- Step 3 - Assign the retrieved AS_ON_DATE to the screen item :SB_TITLE.NB_LAST_SOQ_DATE.
- Step 4 - Assign the retrieved category description (lv_soq_catg) to both :SB_TITLE.NB_SOQ_CATG and :B_PARTY.NB_SOQ_CATG so that both screen blocks reflect the current SOQ category.
- Step 5 - If no matching SOQ record exists (NO_DATA_FOUND) or any other exception occurs, set :SB_TITLE.NB_LAST_SOQ_DATE to NULL and lv_soq_catg to NULL, effectively clearing the date and category fields on screen without raising an error to the user.

---
**Decision Points**

DP-001

Condition:
A row is found in PT_SOQ_MUL_TIL / PM_CATEGORY matching the session globals and the selected part category (ROWNUM < 2 satisfied).

TRUE:
Populate :SB_TITLE.NB_LAST_SOQ_DATE with the retrieved AS_ON_DATE, and populate :SB_TITLE.NB_SOQ_CATG and :B_PARTY.NB_SOQ_CATG with the retrieved category description.

FALSE (NO_DATA_FOUND):
Set :SB_TITLE.NB_LAST_SOQ_DATE to NULL and lv_soq_catg to NULL, leaving the SOQ date and category fields blank on screen.

---

DP-002

Condition:
An unexpected runtime exception (WHEN OTHERS) occurs during the SELECT.

TRUE:
Set :SB_TITLE.NB_LAST_SOQ_DATE to NULL and lv_soq_catg to NULL, suppressing the error and clearing the display fields.

FALSE:
Normal execution continues; no action required under this branch.

---
**Database Interactions**

- DB-001 - Read PT_SOQ_MUL_TIL - Reads data from PT_SOQ_MUL_TIL for lookup or validation.
- DB-002 - Read PM_PART - Reads data from PM_PART for lookup or validation.
**Business Rules**

- BR-001 - The last SOQ date lookup is scoped strictly to the active session context: only records matching GLOBAL.parent_group, GLOBAL.dealer, GLOBAL.loc_cd, GLOBAL.comp_fa, and the screen-selected part category (:SB_TITLE.part_categ) are considered.
- BR-002 - Only the single most recent (or first qualifying) SOQ header record is retrieved; ROWNUM < 2 ensures at most one row is returned, preventing ambiguity when multiple SOQ records exist for the same context.
- BR-003 - Part category resolution is performed via PM_PART, where the dealer_map_cd must be either the principal (GLOBAL.principal) or the dealer (pt.dealer_map_cd), and the principal_map_cd must equal GLOBAL.principal; this enforces multi-company data segregation.
- BR-004 - The retrieved category description is written to both the SB_TITLE block (:SB_TITLE.NB_SOQ_CATG) and the B_PARTY block (:B_PARTY.NB_SOQ_CATG), keeping both screen blocks synchronised with the same SOQ category value.
- BR-005 - If no SOQ record is found or any error occurs, the procedure silently nullifies the date and category output fields rather than propagating an exception, ensuring the screen remains in a stable, displayable state.

---
**Implementation Logic**

```plsql
PROCEDURE get_last_soq_date
IS
lv_soq_catg  pm_category.catg_desc%type;
lv_catg_cd  pm_category.catg_cd%type;
BEGIN
		  SELECT pt.as_on_date,
             pm.catg_desc,pm.catg_cd
        INTO :sb_title.nb_last_soq_date,
             lv_soq_catg,lv_catg_cd
        FROM pt_soq_mul_til pt, pm_category pm
       WHERE pt.parent_group = :GLOBAL.parent_group
         AND pt.dealer_map_cd = :GLOBAL.dealer
         AND pt.loc_cd = :GLOBAL.loc_cd
         AND pt.comp_fa = :GLOBAL.comp_fa
         AND pt.catg_cd =:SB_TITLE.part_categ
         AND pm.catg_cd = (SELECT catg_cd
                             FROM pm_part
                            WHERE part_num = pt.part_num AND dealer_map_cd IN (:GLOBAL.principal, pt.dealer_map_cd)
                            AND principal_map_cd = :global.principal --Added by Rajeev for multi company changes
                            )
         AND pm.principal_map_cd = :GLOBAL.principal
         AND ROWNUM < 2;
         
         :sb_title.NB_SOQ_CATG:=lv_soq_catg;
         :B_PARTY.NB_SOQ_CATG:=lv_soq_catg;
         --:sb_title.PART_CATEG := lv_catg_cd;
EXCEPTION
      WHEN NO_DATA_FOUND THEN
            :sb_title.nb_last_soq_date := NULL;
            lv_soq_catg:=null;
      WHEN OTHERS THEN
            :sb_title.nb_last_soq_date := NULL;
            lv_soq_catg:=null;
END;
```

#### SP-003 - LOC_CATEG_POPULATION

**Invoked From:**

- pt_soq_ims_fmb.xml [Trigger: FT_SAVE]
- pt_soq_ims_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]
- pt_soq_ims_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

SUGGESTED ORDER QUANTITY PROCESSING (N/A / CN_MAIN)

---

**Purpose**

Populates category and location data on the Suggested Order Quantity Processing screen (CN_MAIN) for the current SOQ context. Specifically, it resolves the category code of the SOQ parts stored in PT_SOQ_MUL_NEW and marks the corresponding location records in the B_LOC block as checked, based on matching location codes found in PT_SOQ_NEW.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Count the number of rows in PT_SOQ_MUL_NEW that match the current global context (DEALER_MAP_CD, LOC_CD, PARENT_GROUP, COMP_FA).
- Step 2 - If the count is greater than zero, retrieve the CATG_CD from PM_PART for the first matching part number found in PT_SOQ_MUL_NEW (using ROWNUM < 2 to select a single representative part). The PM_PART lookup filters by DEALER_MAP_CD (accepting either the dealer or principal value) and PRINCIPAL_MAP_CD to support multi-company scenarios. Any exception during this lookup is silently suppressed.
- Step 3 - Using a cursor, select all distinct LOC_CD values from PT_SOQ_NEW where DEALER_MAP_CD, GEN_LOC, PARENT_GROUP, and COMP_FA match the current global context.
- Step 4 - For each LOC_CD returned by the cursor, navigate to the B_LOC block, iterate through all records, and set CHECK_YN to 'Y' on any record whose LOC_CD matches the cursor value.
- Step 5 - If the initial count (Step 1) is zero, no category retrieval or location marking is performed. All outer and inner exceptions are silently suppressed to prevent screen-level errors.

---
**Decision Points**

DP-001

Condition: The count of rows in PT_SOQ_MUL_NEW matching the current DEALER_MAP_CD, LOC_CD, PARENT_GROUP, and COMP_FA is greater than zero.

TRUE: Proceed to retrieve the category code from PM_PART for the first matching part and iterate through PT_SOQ_NEW locations to mark B_LOC records.

FALSE: Skip all category and location population logic; procedure exits without making any changes to the screen.

DP-002

Condition: A B_LOC block record's LOC_CD matches the LOC_CD value from the PT_SOQ_NEW cursor iteration.

TRUE: Set CHECK_YN to 'Y' on that B_LOC record.

FALSE: Leave the B_LOC record's CHECK_YN unchanged and continue to the next record.

---
**Database Interactions**

- DB-001 - Read PT_SOQ_MUL_NEW - Reads data from PT_SOQ_MUL_NEW for lookup or validation.
- DB-002 - Read PM_PART - Reads data from PM_PART for lookup or validation.
- DB-003 - Read PT_SOQ_NEW - Reads data from PT_SOQ_NEW for lookup or validation.
**Business Rules**

- BR-001 - The procedure operates exclusively within the global session context defined by GLOBAL.DEALER, GLOBAL.LOC_CD, GLOBAL.PARENT_GROUP, GLOBAL.COMP_FA, and GLOBAL.PRINCIPAL; no input parameters are accepted.
- BR-002 - Category code resolution is performed only when at least one SOQ multi-line record exists in PT_SOQ_MUL_NEW for the current global context.
- BR-003 - Only the first part number (ROWNUM < 2) from the matching PT_SOQ_MUL_NEW rows is used to determine the representative category code for the entire SOQ group.
- BR-004 - The PM_PART lookup for category code must match on PRINCIPAL_MAP_CD equal to GLOBAL.PRINCIPAL, and DEALER_MAP_CD must be either GLOBAL.DEALER or GLOBAL.PRINCIPAL, enforcing multi-company data isolation.
- BR-005 - Location marking in the B_LOC block is driven by distinct GEN_LOC-based location codes from PT_SOQ_NEW; only locations already present as records in B_LOC can be marked, as no new records are inserted.
- BR-006 - All exceptions at every nesting level are silently suppressed (WHEN OTHERS THEN NULL), ensuring that failures in category or location population do not interrupt the calling trigger's execution.

---
**Implementation Logic**

```plsql
PROCEDURE loc_categ_population IS
BEGIN
  --added on 04/06 to display the category of soq parts in screen  which is in pt_soq_mul
DECLARE
 lv_count NUMBER(5):=0;	
 lv_categ varchar2(30);
BEGIN
   SELECT COUNT(1) 
   INTO   lv_count
   FROM   pt_soq_mul_new
   WHERE  dealer_map_cd=:global.dealer
   AND    loc_cd      =:global.loc_cd
   AND    parent_group =:global.parent_group
   AND    comp_fa      =:global.comp_fa;
   IF     lv_count >0  THEN
   		BEGIN
		   	  SELECT catg_cd 
		   	  INTO  lv_categ 
		   	  FROM   pm_part pm
		   	  WHERE  dealer_map_cd in(:global.dealer,:global.principal)
		   	  AND principal_map_cd = :global.principal --Added by Rajeev for multi company changes
		   	  AND    part_num= (  SELECT PART_NUM
		   	  										  FROM pt_soq_mul_new
		   	  										 WHERE dealer_map_cd=:global.dealer
		   												   AND loc_cd       =:global.loc_cd
		   												   AND parent_group =:global.parent_group
		   												   AND comp_fa      =:global.comp_fa
		   												   AND rownum < 2);
		   	--:sb_title.part_categ:=lv_categ;		   												 
   	  EXCEPTION
   	  	WHEN OTHERS THEN
   	--	 general.disp_text(sqlerrm,'Error');
   	  NULL;
   	  END;
  
  --added on 04/06 to display the location of soq parts in screen, which is in pt_soq 	  
   	  DECLARE
   	  	CURSOR LOC_CUR IS
   	  	SELECT DISTINCT loc_cd 
   	  	FROM   pt_soq_new
   	  	WHERE  dealer_map_cd=:global.dealer
   		  AND    gen_loc       =:global.loc_cd
        AND    parent_group =:global.parent_group
        AND    comp_fa      =:global.comp_fa;
   	  BEGIN
   	   	FOR  i IN loc_cur
   	  	LOOP
   	  		    
		   	  		GO_BLOCK('b_loc');
		    	  	FIRST_RECORD;
		          LOOP
		          	  IF :b_loc.loc_cd=i.loc_cd THEN
		          	  	 :b_loc.check_yn:='Y';
		          	  END IF;	
				          EXIT WHEN :system.last_record='TRUE';
				          NEXT_RECORD;
		          END LOOP;	
   	  	END LOOP;	--end of FOR  i IN loc_cur
   	  EXCEPTION
   	  	WHEN OTHERS THEN
   	  null;
   	  END;
   	END IF;	
EXCEPTION
	WHEN OTHERS THEN
	 NULL;
END; --end of catgory 	

END;
```

#### SP-004 - SORT_BLOCK

**Invoked From:**

- pt_soq_ims_fmb.xml [Trigger: WHEN-LIST-CHANGED]

---

**Screen:**

PART AND STOCK DETAILS (N/A / CN_SOQ)

---

**Purpose**

Reorders the rows displayed in the SOQ detail block (b_soq) on the PART AND STOCK DETAILS screen based on the sort column and sort direction selected by the user in the title/filter bar. The procedure is triggered whenever the sort-by list item changes, ensuring the grid reflects the user's chosen ordering without re-validating pending changes.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Post any pending form changes to the database buffer (POST) to preserve in-flight data before navigating away from the current block.
- Step 2 - Navigate to the SOQ detail block (b_soq) using GO_BLOCK.
- Step 3 - Initialise the local sort expression variable (lv_order_by) to the default value 'PART_NUM'.
- Step 4 - Evaluate the value of the sort-by list item (:sb_title.nb_sort_by) and set lv_order_by to the appropriate ORDER BY expression:
  - 'PART_NUM' -> order by the PART_NUM column.
  - 'SOQ_QTY' -> order by the SOQ_QTY column.
  - 'AMD_SOQ_QTY' -> order by the AMD_SOQ_QTY column.
  - 'PURCHASE_PRICE' -> order by the calculated purchase price using the inline expression sf_get_price(parent_group, dealer_map_cd, loc_cd, :global.principal, 'P', part_num).
  - 'VALUE' -> order by the calculated line value: nvl(sf_get_price(...), 0) * nvl(AMD_SOQ_QTY, 0).
- Step 5 - Navigate to block b_soq again to confirm block focus before applying the property.
- Step 6 - Apply the constructed ORDER BY expression (lv_order_by concatenated with the sort direction from :sb_title.nb_sort_type) to block b_soq via SET_BLOCK_PROPERTY.
- Step 7 - Clear the block's current records with CLEAR_BLOCK.
- Step 8 - Re-execute the block query using EXECUTE_QUERY(NO_VALIDATE) to reload and display records in the newly specified order.

---
**Decision Points**

DP-001

Condition:
:sb_title.nb_sort_by = 'PART_NUM'

TRUE:
lv_order_by is set to 'PART_NUM'; the block will be sorted by part number.

FALSE:
Evaluation continues to DP-002.

---

DP-002

Condition:
:sb_title.nb_sort_by = 'SOQ_QTY'

TRUE:
lv_order_by is set to 'SOQ_QTY'; the block will be sorted by standard SOQ quantity.

FALSE:
Evaluation continues to DP-003.

---

DP-003

Condition:
:sb_title.nb_sort_by = 'AMD_SOQ_QTY'

TRUE:
lv_order_by is set to 'AMD_SOQ_QTY'; the block will be sorted by amended SOQ quantity.

FALSE:
Evaluation continues to DP-004.

---

DP-004

Condition:
:sb_title.nb_sort_by = 'PURCHASE_PRICE'

TRUE:
lv_order_by is set to the sf_get_price() expression resolving the dealer purchase price per part, incorporating parent_group, dealer_map_cd, loc_cd, :global.principal, price type 'P', and part_num.

FALSE:
Evaluation continues to DP-005.

---

DP-005

Condition:
:sb_title.nb_sort_by = 'VALUE'

TRUE:
lv_order_by is set to the expression nvl(sf_get_price(...), 0) * nvl(AMD_SOQ_QTY, 0), sorting by the total line value (price × amended quantity).

FALSE:
No further branch is matched; lv_order_by retains its default value of 'PART_NUM'.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The default sort column is PART_NUM; if the sort-by selection does not match any recognised value, the block is ordered by part number.
- BR-002 - The sort direction (ascending or descending) is always sourced from :sb_title.nb_sort_type and appended to the ORDER BY expression, making direction independent of the chosen sort column.
- BR-003 - Purchase price sorting and line value sorting must use the multi-company-aware sf_get_price function, passing parent_group, dealer_map_cd, loc_cd, :global.principal, price type 'P', and part_num to derive the correct price for the active principal.
- BR-004 - Line value is calculated as the product of the purchase price (defaulting to zero when null) and the amended SOQ quantity (defaulting to zero when null), ensuring null values do not disrupt the sort order.
- BR-005 - The query is re-executed with NO_VALIDATE to avoid triggering item-level validation on the refreshed rows, preserving form stability during a sort operation.
- BR-006 - A POST is issued before navigating to the sort block to ensure any unsaved changes in the current block are preserved in the form buffer prior to clearing and re-querying.

---
**Implementation Logic**

```plsql
Procedure sort_block
IS
      lv_order_by   VARCHAR2 (2000);
BEGIN
      POST;
      GO_BLOCK ('b_soq');
      lv_order_by := 'PART_NUM';

      IF :sb_title.nb_sort_by = 'PART_NUM' THEN
            lv_order_by := 'PART_NUM';
      ELSIF :sb_title.nb_sort_by = 'SOQ_QTY' THEN
            lv_order_by := 'SOQ_QTY';
      ELSIF :sb_title.nb_sort_by = 'AMD_SOQ_QTY' THEN
            lv_order_by := 'AMD_SOQ_QTY';
      ELSIF :sb_title.nb_sort_by = 'PURCHASE_PRICE' THEN
            lv_order_by := 'sf_get_price(parent_group,dealer_map_cd,loc_cd,:global.principal,''P'',part_num)'; --pmc Added by Rajeev for multi company changes
            NULL;
      ELSIF :sb_title.nb_sort_by = 'VALUE' THEN
            lv_order_by := 'nvl(sf_get_price(parent_group,dealer_map_cd,loc_cd,:global.principal,''P'',part_num),0) * nvl(AMD_SOQ_QTY,0)'; --pmc Added by Rajeev for multi company changes
      END IF;

      GO_BLOCK ('b_soq');
      SET_BLOCK_PROPERTY ('b_soq', order_by, lv_order_by || ' ' || :sb_title.nb_sort_type);
      CLEAR_BLOCK;
      EXECUTE_QUERY (no_validate);
      
END;
```

#### SP-005 - UPDATE_PO_STOCK

**Invoked From:**

- pt_soq_ims_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

PO DETAILS (N/A / CN_PARTY)

---

**Purpose**

UPDATE_PO_STOCK collects the ordered quantity for every part line in the B_SOQ block and submits the consolidated list to PK_VALIDATE_PARTS.UPDATE_ON_ORDER to synchronise the on-order stock position for the current purchase order. If the package reports an error, the procedure surfaces the error message to the user via the CN_ERR view and halts further form processing.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- PK_VALIDATE_PARTS.UPDATE_ON_ORDER ([SP-030](#SP-030--PK_VALIDATE_PARTS.UPDATE_ON_ORDER)) - PK_VALIDATE_PARTS.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Navigate to the B_SOQ block and position the cursor on the first record.
- Step 2 - Iterate through every record in B_SOQ; for each record, populate an entry in the PL/SQL index-by table TI_PART_ORD_QTY with the part number (B_SOQ.PART_NUM) and the amended SOQ quantity (B_SOQ.AMD_SOQ_QTY), leaving the reserve quantity (R_QTY) as NULL, then advance the counter.
- Step 3 - Continue the loop until SYSTEM.LAST_RECORD is TRUE, ensuring all part lines are captured.
- Step 4 - Invoke PK_VALIDATE_PARTS.UPDATE_ON_ORDER, passing the parent group, dealer, location code, the populated part-order table, the PO status from B_PARTY, the current username, and two output variables to receive an error code and error message.
- Step 5 - Evaluate the returned error code (LV_ERR_CD). If it is non-zero, navigate to the CB_ERR block, clear it, write the error message (LV_ERR_MSG) into CB_ERR.TXT_ERR, display the CN_ERR view, and raise FORM_TRIGGER_FAILURE to abort the trigger.
- Step 6 - If the error code is zero, the procedure completes normally with no further action required.

---
**Decision Points**

DP-001

Condition:
LV_ERR_CD returned by PK_VALIDATE_PARTS.UPDATE_ON_ORDER is not equal to 0.

TRUE:
Navigate to the CB_ERR block, clear its contents, write LV_ERR_MSG into CB_ERR.TXT_ERR, display the CN_ERR error view, and raise FORM_TRIGGER_FAILURE to halt further form processing.

FALSE:
No error handling is performed; the procedure exits normally and form processing continues.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Every part line present in the B_SOQ block at the time of invocation must be included in the on-order update; no lines may be skipped.
- BR-002 - The reserve quantity (R_QTY) is always submitted as NULL when building the part-order table; only the amended SOQ quantity (AMD_SOQ_QTY) is used to represent the ordered quantity.
- BR-003 - The on-order stock update is executed in the context of the current parent group, dealer, location code, PO status, and username held in global/block variables; these values must be populated before this procedure is called.
- BR-004 - A non-zero error code returned by PK_VALIDATE_PARTS.UPDATE_ON_ORDER is treated as a blocking error; the user must be informed via the CN_ERR view and the triggering action must be cancelled via FORM_TRIGGER_FAILURE.
- BR-005 - Only a single consolidated error message (LV_ERR_MSG) is displayed to the user; per-line error detail from the error table (TO_ERROR) is not surfaced in the current implementation.

---
**Implementation Logic**

```plsql
PROCEDURE update_po_stock
IS
      ti_part_ord_qty   pk_validate_parts.part_order_type;
      to_error          pk_validate_parts.err_tab;
      l_cnt             PLS_INTEGER                       := 1;
      lv_error_cd       NUMBER;
      lv_err_msg        VARCHAR2 (1000);
      lv_err_cd         NUMBER;
BEGIN
      GO_BLOCK ('B_SOQ');
      FIRST_RECORD;

      LOOP
            ti_part_ord_qty (l_cnt).p_part := :b_soq.part_num;
            ti_part_ord_qty (l_cnt).p_qty := :b_soq.amd_soq_qty;
            ti_part_ord_qty (l_cnt).r_qty := null;
            l_cnt := l_cnt + 1;
            EXIT WHEN :SYSTEM.LAST_RECORD = 'TRUE';
            NEXT_RECORD;
      END LOOP;

      pk_validate_parts.update_on_order (:GLOBAL.parent_group,
                                         :GLOBAL.dealer,
                                         :GLOBAL.loc_cd,
                                         ti_part_ord_qty,
                                         :b_party.po_status,
                                         :GLOBAL.user_name,
                                         lv_err_cd,
                                         lv_err_msg);
      IF lv_err_cd <> 0 THEN
            BEGIN
                  GO_BLOCK ('CB_ERR');
                  CLEAR_BLOCK (no_validate);
                  FIRST_RECORD;
                  /*
                          for i in 1..to_error.last
                          loop
                                  :cb_err.txt_err := to_error(i);
                                  next_record;
                          end loop;
                          */
                  :cb_err.txt_err := lv_err_msg;
            END;

            SHOW_VIEW ('CN_ERR');
            RAISE form_trigger_failure;
      END IF;
END;
```

#### SP-006 - VIEW_EXCEL_REP

**Invoked From:**

- pt_soq_ims_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

PART AND STOCK DETAILS (N/A / CN_SOQ)

---

**Purpose**

VIEW_EXCEL_REP generates a CSV report file on the application server from a dynamic SQL query and makes it available to the end user via a browser download link. Invoked from the PART AND STOCK DETAILS screen (CN_SOQ) when the user presses the designated export button, the procedure builds an Oracle Forms record group from the supplied query, writes the target column values row-by-row to a server-side CSV file, and then opens the file in a new browser tab using a URL resolved at runtime from a configuration file.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_file_name | VARCHAR2 | IN |
| p_query | VARCHAR2 | IN |
| p_column_name | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Derive the output filename by concatenating the current Forms user ID (read from the global variable :global.userid) with the current system date/time formatted as YYYYMMDDHHMISS and appending the .csv extension, ensuring a unique filename per user per invocation.
- Step 2 - Validate the generated filename for embedded spaces in folder path segments; if spaces are detected, override the path to the C:\ root drive and display a warning message to the user.
- Step 3 - Check whether a record group named 'DataRecordSet' already exists in the Forms session; if it does, delete it before proceeding to avoid stale data conflicts.
- Step 4 - Create a new record group named 'DataRecordSet' from the dynamic SQL string supplied in p_query, then populate it by executing the query.
- Step 5 - Retrieve the total row count of the populated record group. If the row count exceeds 65,536, cap it at 65,535 and display a truncation warning message to the user.
- Step 6 - Construct the server-side file path by prefixing the base directory /iashome/ias/reports/printer/ with the bare filename (extracted after the last backslash).
- Step 7 - Read the base URL for the Forms server's printer directory from the configuration file /reports/DMS/excelpath.txt, then append the bare filename to form the full download URL (formserverpath).
- Step 8 - Open the server-side CSV file for writing, then iterate over each row (up to the capped row count), retrieve the character cell value for the column identified by p_column_name from the record group, and write each value as a line to the file.
- Step 9 - Close the server-side file after all rows have been written.
- Step 10 - Open the completed CSV file in a new browser tab by invoking web.show_document with the resolved formserverpath URL and the '_blank' target.
- Step 11 - If any exception occurs during processing, display an error message containing the Forms error code and error text, then raise Form_Trigger_Failure to halt execution.

---
**Decision Points**

DP-001

Condition: The generated filename (vcFile) contains a space character within one of its folder path segments (INSTR(FILENAME,' ') > 0).

TRUE: The filename is redirected to the C:\ root drive using only the bare filename portion, and a warning message is shown to the user informing them that the file will be saved to the C drive as a default.

FALSE: The filename is used as generated without path modification.

DP-002

Condition: A record group named 'DataRecordSet' already exists in the current Forms session (NOT Id_Null(rg_id)).

TRUE: The existing record group is deleted before a new one is created, preventing data carry-over from a prior invocation.

FALSE: No deletion is performed; processing continues directly to record group creation.

DP-003

Condition: The row count returned from the populated record group exceeds 65,536 rows (the_rowcount > 65536).

TRUE: The effective row count is capped at 65,535, a truncation warning message is displayed to the user, and only the first 65,535 rows are written to the CSV file.

FALSE: All rows in the record group are written to the CSV file without truncation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The output filename must be unique per user session; it is constructed by combining the logged-in user ID with the current date and time (YYYYMMDDHHMISS) and the .csv extension to prevent file collisions between concurrent users.
- BR-002 - A filename whose folder path contains spaces is not permitted at the specified location; in such cases the system automatically redirects output to the C:\ root drive and notifies the user.
- BR-003 - Any pre-existing Forms record group named 'DataRecordSet' must be destroyed before a new export is initiated to ensure the output reflects only the current query execution.
- BR-004 - The maximum number of data rows that may be exported to a single CSV file is 65,535; any result set exceeding this limit is silently truncated to 65,535 rows after the user is warned.
- BR-005 - The server-side base URL for the export directory must be read at runtime from the configuration file /reports/DMS/excelpath.txt; this path must be accessible and readable by the Forms server process at the time of export.
- BR-006 - The exported file is delivered to the user by opening the server-hosted CSV URL in a new browser tab; no client-to-server file transfer mechanism is used.
- BR-007 - Any runtime exception during the export process must surface a descriptive error message (including the Forms error code and error text) to the user, and execution must be terminated via Form_Trigger_Failure.

---
**Implementation Logic**

```plsql
PROCEDURE view_excel_rep(p_file_name VARCHAR2 DEFAULT NULL, p_query VARCHAR2,p_column_name VARCHAR2) IS	
  rg_name 				 		VARCHAR2(40) := 'DataRecordSet'; 
	rg_id 					 		RecordGroup; 
	gc_id 					 		GroupColumn; 
	urlFile1        TEXT_IO.FILE_TYPE;
	the_rowcount 		 		NUMBER;
	po_tot_rec    NUMBER (6);
	--po_part_tab   pk_part_search_new.part_tab_10;
	po_part_tab   pk_part_search_new.part_tab_11;
	po_err_msg    VARCHAR2 (3000);
	po_err_cd     NUMBER (10);
	low           NUMBER (10);
	high          NUMBER (10);
	remainder     NUMBER (10);
	order_by      VARCHAR2 (300);
	vcfile varchar2(150);
	lv_user  varchar2(150);
	l_Old_URL varchar2(500);	
		l_new_URL varchar2(500);	
	v_string varchar2(5000);
	bin_str varchar2(250);
	errcode 				 		NUMBER; 
  FILENAME			   		VARCHAR2(4000);
  MYFILE 					 		TEXT_IO.FILE_TYPE;
  urlFile 					 	TEXT_IO.FILE_TYPE;
  urlPath							VARCHAR2(5000);
	l_alert 				 		NUMBER;
	server_file      		VARCHAR2(2000);
	file_transfer_bool	BOOLEAN;
	formserverpath   		VARCHAR2(2000);
begin
lv_user := name_in(':global.userid');  -- New line added after dpl change
vcFile:= lv_user||To_Char(Sysdate,'YYYYMMDDHHMISS');    -- New line added after dpl change
vcFile := vcFile||'.csv';
if vcFile is null then
	--FILENAME  := Webutil_file.FILE_SAVE_DIALOG;
	null;
else
	filename:=vcFile;
end if;
	If instr(FILENAME,' ') > 0 then
 		FILENAME := 'C:\'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
 		Message('File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default.');
 		message('  ');
	end if;
	
	rg_id := Find_Group( rg_name ); 
	IF NOT Id_Null(rg_id) THEN 
		Delete_Group( rg_id ); 
	END IF; 
	rg_id := Create_Group_From_Query( rg_name, p_query ); 
	errcode := Populate_Group( rg_id ); 
	the_rowcount := Get_Group_Row_Count( rg_id );
	IF the_rowcount > 65536 THEN  
		Message('Maximum number of rows in excel exceeded. It will truncate to 65535 rows.');
		Message('  ');
		CLEAR_MESSAGE;
		the_rowcount := 65535;
	END IF;

	server_file := '/iashome/ias/reports/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	--formserverpath := 'http://10.100.34.230:7778/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	urlFile := Text_Io.Fopen('/reports/DMS/excelpath.txt','R');
	Text_Io.Get_Line(urlFile,urlPath);
	Text_Io.Fclose(urlFile);
	formserverpath := urlPath||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	MYFILE := TEXT_IO.FOPEN(server_file, 'W');
	gc_id := Find_Column( rg_name||'.'||p_column_name); 	
	for total_loop IN 1..the_rowcount
		loop
	  	V_STRING :=  GET_GROUP_CHAR_CELL(gc_id  , total_loop ); 
	  	text_io.put_line(myfile,v_string);
	  	--TEXT_IO.PUTF(MYFILE,V_STRING);  
		end loop;
      text_io.fclose(myfile);
   
	 --	file_transfer_bool := WebUtil_File_Transfer.Url_To_Client(formserverpath,FILENAME);
	/* 	if not file_transfer_bool  then 
	 		message('File Transfer failed');pause;
	 	end if;
	 	WebUtil_Host.HOST('cmd /c '||FILENAME);*/
	 	
	 	web.show_document(formserverpath,'_blank');
	exception
		when others then
		Message('Error  - '||ERROR_CODE|| ERROR_TEXT);
		Raise Form_trigger_failure;
	end;
```

#### SP-007 - D2KWUTIL.ADD_ERROR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.FILE_INFO]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Records a single error condition encountered during processing by setting a package-level error flag and composing a formatted error message that combines the calling function name with the supplied error text. The composed message is also written to the debug log at severity level 99, ensuring the error is both flagged for downstream inspection and traceable in diagnostic output.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| CallingFunction | VARCHAR2 | IN |
| SetErrorText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the name of the calling function (CallingFunction) and the descriptive error text (SetErrorText) as inputs.
- Step 2 - Set the package-level boolean variable ERROR_ENCOUNTERED to TRUE, signalling that at least one error has occurred in the current execution context.
- Step 3 - Compose the ERROR_STACK message by concatenating CallingFunction, a colon-space separator, and the first 1,968 characters of SetErrorText, truncating any excess to prevent overflow.
- Step 4 - Write the composed ERROR_STACK value to the debug log by calling Win_API_Debug.DebugLog with severity level 99 and the label 'Add_Error', making the error traceable in diagnostic output.

---
**Decision Points**

No conditional decision points exist in this procedure. All four processing steps execute unconditionally for every invocation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The error flag ERROR_ENCOUNTERED must be set to TRUE whenever this procedure is called, regardless of the nature or severity of the error being reported.
- BR-002 - The error text stored in ERROR_STACK must be prefixed with the calling function name followed by a colon-space separator to provide unambiguous context for the error.
- BR-003 - The error text portion of ERROR_STACK must be truncated to a maximum of 1,968 characters to prevent value-range errors when storing the composed message.
- BR-004 - Every error recorded through this procedure must also be written to the debug log at severity level 99 to ensure auditability and diagnostic traceability.

---
**Implementation Logic**

```plsql

PROCEDURE Add_Error (CallingFunction in VARCHAR2, SetErrorText in VARCHAR2) is
begin 
  -- Just watch for value errors 
  ERROR_ENCOUNTERED  := TRUE;
  ERROR_STACK    := CallingFunction||': '||substr(SetErrorText,1,1968);
  Win_API_Debug.DebugLog(99,'Add_Error',ERROR_STACK);
end Add_Error;
```

#### SP-008 - D2KWUTIL.ADD_EXTERNAL_ERRORS

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.FILE_INFO]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Collects and consolidates error messages from the Oracle Forms tool error stack (TOOL_ERR) into a single delimited string buffer, falling back to the current SQL error message (SQLERRM) when no tool errors are present. The resulting string is returned to the caller (D2KWUTIL.FILE_INFO) for downstream error reporting.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Initialise a local counter (iCounter) and an empty varchar2 buffer (vcErrBuff) to accumulate error message text.
- Step 2 - Check whether the TOOL_ERR stack contains one or more errors by evaluating TOOL_ERR.NERRORS.
- Step 3 - If TOOL_ERR.NERRORS is greater than zero, iterate through each error on the stack from index 1 to TOOL_ERR.NERRORS.
- Step 4 - For each iteration, append a newline character (CHR(10)) followed by the current TOOL_ERR.MESSAGE to vcErrBuff.
- Step 5 - If appending the next message would exceed the 1,968-character buffer limit (VALUE_ERROR exception), exit the loop immediately to prevent overflow.
- Step 6 - After appending each message, call TOOL_ERR.POP to remove the processed error from the stack.
- Step 7 - If the TOOL_ERR stack is empty but SQLERRM is not null, set vcErrBuff to a newline character followed by the SQLERRM text.
- Step 8 - Return vcErrBuff to the caller.

---
**Decision Points**

DP-001

Condition: TOOL_ERR.NERRORS > 0

TRUE: Iterate over the TOOL_ERR stack, appending each error message to the buffer and popping each entry after processing.

FALSE: Evaluate SQLERRM to determine whether a SQL-level error message is available (proceed to DP-002).

---

DP-002

Condition: SQLERRM IS NOT NULL (evaluated only when TOOL_ERR.NERRORS = 0)

TRUE: Assign a newline-prefixed SQLERRM value to vcErrBuff.

FALSE: vcErrBuff remains empty/null; no error text is added.

---

DP-003

Condition: A VALUE_ERROR exception is raised while appending the next TOOL_ERR.MESSAGE to vcErrBuff (i.e., the concatenated string would exceed 1,968 characters)

TRUE: Exit the iteration loop immediately, discarding any remaining unprocessed tool errors to prevent buffer overflow.

FALSE: Continue appending messages and popping entries from the TOOL_ERR stack.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The error message buffer (vcErrBuff) is capped at 1,968 characters; any tool error messages that would cause the buffer to exceed this limit are silently discarded.
- BR-002 - Each error message appended from the TOOL_ERR stack must be preceded by a newline character (CHR(10)) to ensure messages are separated when the buffer is consumed by the caller.
- BR-003 - TOOL_ERR stack entries are consumed (popped) during collection; once this function executes, the processed tool errors are no longer available on the stack.
- BR-004 - The SQLERRM fallback is only applied when the TOOL_ERR stack is empty; if tool errors exist, SQLERRM is ignored entirely.
- BR-005 - The function always returns a value (vcErrBuff) to the caller; if neither tool errors nor a SQL error are present, the return value is null.

---
**Implementation Logic**

```plsql

FUNCTION Add_External_Errors return varchar2 is
  iCounter   pls_integer;
  vcErrBuff  varchar2(1968);
begin 
  if tool_err.nerrors > 0 then 
    for iCounter in 1..tool_err.nerrors LOOP
      begin 
        vcErrBuff := vcErrBuff||chr(10)||tool_err.message;
      exception
        when VALUE_ERROR then 
          exit; /* String exceeds allowable buffer */
      end;
      tool_err.pop;
    end loop;
  elsif SQLERRM is not null then 
    vcErrBuff := chr(10)||SQLERRM; 
  end if;
  return vcErrBuff;
end Add_External_Errors;
```

#### SP-009 - D2KWUTIL.ATTEMPT_DLL_LOAD

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Attempts to load a specified DLL into Oracle Forms via ORA_FFI, optionally verifying the file's physical existence at a given path before loading. The function normalises the target path, confirms the DLL file is accessible, loads the library handle, and optionally increments the global DLL load counter and enables the API flag. It returns the resulting ORA_FFI library handle to the caller (D2KWUTIL.REGISTER_FUNCTION_CALL).

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |
| TargetDLL | VARCHAR2 | IN |
| LoadCount | BOOLEAN | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |

---

**Dependencies**

- D2KWUTIL.STRIPDIRSEP ([SP-019](#SP-019--D2KWUTIL.STRIPDIRSEP)) - D2KWUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate whether TargetPath is supplied. If it is non-null, proceed with path normalisation and file existence checks; if null, skip directly to the library load attempt.
- Step 2 - Normalise the supplied TargetPath by passing it to D2KWUTIL.STRIPDIRSEP to remove any trailing directory separator, then appending a single backslash ('\'), ensuring a consistently formatted path regardless of how the caller supplied it.
- Step 3 - Attempt to open the file identified by the concatenation of the normalised TargetPath and TargetDLL using TEXT_IO.FOPEN in read mode ('R'). If the file opens successfully, close it immediately with TEXT_IO.FCLOSE; this confirms the DLL physically exists at the specified location.
- Step 4 - If the file open in Step 3 raises any exception (file not found or inaccessible), log a debug entry via Win_API_Debug.DebugLog recording the DLL name and the path that was checked, then raise the BadLocation exception to abort processing.
- Step 5 - Call ORA_FFI.LOAD_LIBRARY with TargetPath and TargetDLL to obtain an ORA_FFI library handle (hDLL).
- Step 6 - If the LoadCount parameter is TRUE, increment the package-level counter DLL_LOAD_COUNT by 1 and set the package-level flag API_ENABLED to TRUE, recording that a DLL has been successfully loaded.
- Step 7 - Return the ORA_FFI library handle hDLL to the caller.
- Step 8 - If any unhandled exception occurs during the load phase (Steps 5-7), set API_ENABLED to FALSE and return the null hDLL handle to the caller, allowing the caller to handle the failure gracefully.

---
**Decision Points**

DP-001

Condition: TargetPath IS NOT NULL

TRUE: Normalise TargetPath via D2KWUTIL.STRIPDIRSEP and append a backslash, then perform the file existence check (Steps 2-4) before attempting the library load.

FALSE: Skip path normalisation and file existence verification; proceed directly to ORA_FFI.LOAD_LIBRARY using only the TargetDLL value.

---

DP-002

Condition: TEXT_IO.FOPEN succeeds for the resolved file path (TargetPath || TargetDLL)

TRUE: Close the file handle and continue to the ORA_FFI library load.

FALSE: Log a debug message identifying the missing DLL and its expected location, then raise the BadLocation exception, halting further execution of the function.

---

DP-003

Condition: LoadCount parameter is TRUE

TRUE: Increment the package-level DLL_LOAD_COUNT counter by 1 and set API_ENABLED to TRUE.

FALSE: Leave DLL_LOAD_COUNT and API_ENABLED unchanged after the successful library load.

---

DP-004

Condition: An unhandled exception is raised during or after the ORA_FFI.LOAD_LIBRARY call

TRUE: Set API_ENABLED to FALSE and return a null ORA_FFI library handle to the caller.

FALSE: Return the valid ORA_FFI library handle obtained from ORA_FFI.LOAD_LIBRARY.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - TargetPath must be normalised to a single, consistently formatted directory path before use; D2KWUTIL.STRIPDIRSEP is called to remove any existing trailing separator, and exactly one backslash is then appended. This prevents errors caused by callers supplying paths with inconsistent or multiple trailing separators.
- BR-002 - When TargetPath is provided, the physical existence of the DLL file at the resolved location must be confirmed before any library load is attempted. A failure to open the file is treated as a hard error (BadLocation), not a silent fallback.
- BR-003 - Only the first path segment is used when TargetPath is supplied; any additional paths concatenated by the caller are discarded. The normalisation in Step 2 enforces this by treating the entire TargetPath value as a single directory.
- BR-004 - The package-level DLL_LOAD_COUNT counter and API_ENABLED flag are updated only when LoadCount is TRUE, allowing callers to load a library without affecting the global load-tracking state when required.
- BR-005 - On any exception during the library load phase, API_ENABLED must be set to FALSE and a null handle returned, ensuring the calling context can detect and respond to a failed load without an unhandled runtime error propagating further.

---
**Implementation Logic**

```plsql

FUNCTION  Attempt_DLL_Load  (TargetPath in out VARCHAR2, TargetDLL in VARCHAR2, LoadCount in BOOLEAN DEFAULT TRUE) return ORA_FFI.LibHandleType is
  hDLL  ORA_FFI.LibHandleType;
  hFile TEXT_IO.FILE_TYPE;
begin 
    	
  if TargetPath is not null then 
    -- Watch out for folks who put multiple Paths in here 
    -- Oh yes it's happened! Just use the first & throw the rest away
    -- Add trailing Directory Sep if required
    TargetPath := StripDirSep(TargetPath)||'\';
    
    -- Check that there is actually a file there.
    begin 
  	  hFile := TEXT_IO.FOPEN(TargetPath||TargetDLL,'R');
  	  TEXT_IO.FCLOSE(hFile);
    exception
  	  when others then
  	    Win_API_Debug.DebugLog(99,'Attempt_DLL_LOAD',TargetDLL||' not found in the specified location of "'||TargetPath||'"'); 
  		  raise BadLocation;
    end;
  end if;
  
  hDLL := ORA_FFI.LOAD_LIBRARY(TargetPath, TargetDLL);
  if LoadCount then 
    DLL_LOAD_COUNT  := DLL_LOAD_COUNT + 1;
    API_ENABLED  := TRUE;
  end if;
  return hDLL;
exception
  when others then 
    API_ENABLED := FALSE;
    return hDLL; /* Will be null */
end Attempt_DLL_Load;
```

#### SP-010 - D2KWUTIL.BOOLTOCHAR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.FILE_INFO]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Converts a PL/SQL BOOLEAN value to its VARCHAR2 string equivalent ('TRUE' or 'FALSE'). This utility function is used within the D2KWUTIL package to produce a human-readable or string-compatible representation of a boolean result, supporting downstream logic that requires character-based boolean output - such as the FILE_INFO stored procedure that invokes it.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| ThisBoolean | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input BOOLEAN value (ThisBoolean) passed by the calling routine.
- Step 2 - Evaluate the BOOLEAN input against a TRUE condition.
- Step 3 - If the condition evaluates to TRUE, return the VARCHAR2 literal 'TRUE' to the caller.
- Step 4 - If the condition evaluates to FALSE (or NULL resolves to the ELSE branch), return the VARCHAR2 literal 'FALSE' to the caller.

---
**Decision Points**

DP-001

Condition:
ThisBoolean evaluates to TRUE.

TRUE:
The function returns the VARCHAR2 string 'TRUE'.

FALSE:
The function returns the VARCHAR2 string 'FALSE'.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must always return a non-null VARCHAR2 value; either 'TRUE' or 'FALSE' is returned for every invocation, with no other return values permitted.
- BR-002 - The mapping is strictly binary: a BOOLEAN TRUE maps exclusively to the string 'TRUE', and any non-TRUE BOOLEAN value (FALSE or NULL resolved via the ELSE branch) maps to the string 'FALSE'.
- BR-003 - The function accepts no parameters other than the single IN BOOLEAN argument and performs no database interactions; it is a pure conversion utility with no side effects.

---
**Implementation Logic**

```plsql

  
  FUNCTION  BoolToChar(ThisBoolean IN BOOLEAN) return VARCHAR2 is
  begin
  	if ThisBoolean then 
  		RETURN 'TRUE';
  	else
  	    RETURN 'FALSE';
  	end if;
  end BoolToChar;

END;

PACKAGE WIN_API_DIALOG IS

/*-------------------------------------------------------------------------*\
 * WIN_API_DIALOG ->   This package is concerned with Displaying Common
 *      dialogs
 * Contents:
 *    Open_File    -> Open File Dialog
 *    Save_File    -> Save File Dialog
 *    Select_Printer    -> Printer Selection Dialog
 *    Choose_Font       -> Display the Font Selection Dialog
 *    Choose_Color      -> Display the Color Selection Dialog
 * Dependancies:
 *    WIN_API_ENVIRONMENT
 *    WIN_API
 *    WIN_API_DEBUG
\*-------------------------------------------------------------------------*/ 

/*-------------------------------------------------------------------------*\
 * Open_File        -> Displays the standard Open File dialog
 * Arguments: 
 *  Title           -> The Title for the Dialog Box
 *                     (Default -> 'Open File')
 *  StartDirectory  -> Where the dialog should start from
 *                     this should be in the format 'C:\TEMP'
 *                     (Default -> Windows Directory)
 *  FileFilter      ->  Restrict the list of files. The filter string 
 *                      should be in the format:
 *                      '<Description>|<filename>.<Extension>|'
 *                      typically this would be something like
 *                      'All files(*.*)|*.*|' or 'Text files(*.txt)|*.txt|'
 *                      "All Files" is the Default
 *  Modal           ->  Should the dialog be modal with respect to the 
 *                      application? 
 *                      default = TRUE
 *  AdvancedFlags   ->  (See list in WIN_API header) This option allows
 *                      you to change the attributes of the Open File 
 *                      dialog.  Here are some of the Flags that might
 *                      be of interest:
 *                      OFN_HIDEREADONLY  Hides the Read Only check box.
 *                      OFN_NONETWORKBUTTON  Hides the Network Button
 *                      OFN_EXPLORER    Display an Explorer style 
 *                        Dialog rather than the conventional one.
 *                      See your Microsoft docmentation for details on 
 *                      each flag.
 *                      To Set the Advanced_Flags varaible, just add the 
 *                      required flags together.  The default is:
 *                      WIN_API.OFN_PATHMUSTEXIST + WIN_API.OFN_FILEMUSTEXIST +
 *                      WIN_API.OFN_HIDEREADONLY + WIN_API.OFN_NOCHANGEDIR 
 *  RaiseExceptions ->  TRUE of FALSE(Default) If set to true, then if the 
 *                      command is not successful (e.g no filename is  
 *                      returned) then the explicit exception
 *                      NO_DATA_FOUND will be raised.
 *        
 * Returns:
 *  Path and name of the selected file
\*-------------------------------------------------------------------------*/
```

#### SP-011 - D2KWUTIL.CLEAN_ERROR_STACK

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.FILE_INFO]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Resets the shared error-tracking state within the D2KWUTIL package by clearing the error-encountered flag and discarding any accumulated error messages. This ensures that a clean, empty error context is available before a new operation begins, preventing stale error information from affecting subsequent processing.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Set the package-level variable ERROR_ENCOUNTERED to FALSE, indicating that no error condition is currently active.
- Step 2 - Set the package-level variable ERROR_STACK to NULL, discarding any previously accumulated error message text.
- Step 3 - Return control to the caller (D2KWUTIL.FILE_INFO) with both error-state variables fully reset.

---
**Decision Points**

No conditional decision points exist in this procedure. The reset of ERROR_ENCOUNTERED and ERROR_STACK is unconditional on every invocation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - ERROR_ENCOUNTERED must be set to FALSE on every invocation, regardless of its prior value, ensuring no residual error flag persists into subsequent operations.
- BR-002 - ERROR_STACK must be set to NULL on every invocation, ensuring no residual error message text persists into subsequent operations.
- BR-003 - The procedure accepts no input and produces no formal output; its sole effect is the unconditional reset of the two package-level error-state variables.

---
**Implementation Logic**

```plsql

PROCEDURE Clean_Error_Stack is 
begin 
  -- just empty the variables
  ERROR_ENCOUNTERED  := FALSE;
  ERROR_STACK        := NULL;
end Clean_Error_Stack;
```

#### SP-012 - D2KWUTIL.CREATED_DATE

**Invoked From:**

- PKG_DS_AUTO_CLEARANCE.pck [StoredProcedure: PKG_DS_AUTO_CLEARANCE.SP_DEADSTK_PO_SO]
- SP_CALCULATE_SOQ_IMS.prc [StoredProcedure: SP_CALCULATE_SOQ_IMS]
- SP_INSERT_PM_PART_VAR.prc [StoredProcedure: SP_INSERT_PM_PART_VAR]
- SP_UPDATE_PO_NUMBER_NEW.prc [StoredProcedure: SP_UPDATE_PO_NUMBER_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the creation date and millisecond timestamp of a specified file by delegating to D2KWUTIL.FILE_INFO. The procedure returns a formatted DATE value representing the file's creation date and time, and a separate NUMBER value for the sub-second (millisecond) component. It is consumed by batch and procedural routines that require file-level audit or sequencing information based on when a file was originally created.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| FileName | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| ReturnDate | DATE | OUT |
| ReturnMS | NUMBER | OUT |

---

**Dependencies**

- D2KWUTIL.FILE_INFO ([SP-016](#SP-016--D2KWUTIL.FILE_INFO)) - D2KWUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the file name (FileName), an exception-handling flag (RaiseExceptions), and prepare to populate the output parameters ReturnDate and ReturnMS.
- Step 2 - Invoke D2KWUTIL.FILE_INFO, passing the operation identifier 'Created_Date', the supplied FileName, positional arguments 1 and 1, and the RaiseExceptions flag. FILE_INFO populates a set of shared integer buffers (iBuff3 through iBuff9) with the raw date/time components of the file's creation timestamp.
- Step 3 - Construct the ReturnDate output by formatting buffers iBuff3 (year), iBuff4 (month), iBuff5 (day), iBuff6 (hour), iBuff7 (minute), and iBuff8 (second) into a concatenated string and converting it to a DATE using the mask 'YYYYMMDDHH24MISS'.
- Step 4 - Assign the value of iBuff9 to ReturnMS, providing the millisecond portion of the creation timestamp as a NUMBER.
- Step 5 - Return control to the caller with ReturnDate and ReturnMS populated.

---
**Decision Points**

DP-001

Condition: The RaiseExceptions flag passed to D2KWUTIL.FILE_INFO is TRUE or FALSE.

TRUE: D2KWUTIL.FILE_INFO raises an exception to the caller if the file cannot be accessed or the creation date cannot be retrieved.

FALSE: D2KWUTIL.FILE_INFO suppresses any internal errors; ReturnDate and ReturnMS may remain NULL or unpopulated if the file operation fails.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file creation date must be derived exclusively by calling D2KWUTIL.FILE_INFO with the operation identifier 'Created_Date'; no direct file-system or database query is used to obtain the timestamp.
- BR-002 - The creation date is assembled from six discrete numeric buffer values (year, month, day, hour, minute, second) and must conform to the format mask 'YYYYMMDDHH24MISS' before conversion to a DATE; any deviation in buffer content will cause a conversion error.
- BR-003 - The millisecond component (ReturnMS) is treated as a separate NUMBER output and is not incorporated into the DATE value, preserving sub-second precision independently.
- BR-004 - Exception propagation is caller-controlled via the RaiseExceptions parameter; callers that require strict error handling must explicitly pass TRUE to ensure failures in file access are surfaced rather than silently ignored.

---
**Implementation Logic**

```plsql

PROCEDURE Created_Date (  FileName        IN   VARCHAR2,
                          ReturnDate      OUT  DATE,
                          ReturnMS        OUT  NUMBER,
                          RaiseExceptions IN   BOOLEAN DEFAULT FALSE) is
begin 
  File_Info('Created_Date',Filename,1,1,RaiseExceptions);
  ReturnDate := to_date(to_char(iBuff3,'0999')||to_char(iBuff4,'09')||to_char(iBuff5,'09')||to_char(iBuff6,'09')||to_char(iBuff7,'09')||to_char(iBuff8,'09'),'YYYYMMDDHH24MISS');
  ReturnMS   := iBuff9;
end Created_Date;
```

#### SP-013 - D2KWUTIL.D2KWUTIL_DEBUGSTRING

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level Foreign Function Interface (FFI) bridge that passes a debug text string to an underlying C-language routine within the D2KWUTIL library. It is called exclusively by D2KWUTIL.WINDEBUG to relay debug messages from the Oracle Forms environment to the native windowing debug output channel.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that identifies the target C function entry point within the D2KWUTIL shared library.
- Step 2 - Receive the debug text string (Text) to be transmitted to the external debug output channel.
- Step 3 - Invoke the bound C routine via the ORA_FFI PRAGMA INTERFACE mechanism (interface code 11265), passing both the function handle and the text string directly to the native layer.
- Step 4 - Return control to the caller (D2KWUTIL.WINDEBUG) upon completion; no return value or output parameter is produced.

---
**Decision Points**

No decision points are present in this procedure. The implementation consists solely of a direct FFI call to the underlying C routine with no conditional branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must be invoked with a valid ORA_FFI.funcHandleType handle; the handle must have been registered and bound to the D2KWUTIL C library prior to invocation, as no internal validation or fallback is performed.
- BR-002 - The procedure operates exclusively as an FFI wrapper (PRAGMA INTERFACE C, interface code 11265); all debug string processing logic resides in the external C routine, not within PL/SQL.
- BR-003 - No output parameters or return values are defined; the caller (D2KWUTIL.WINDEBUG) must not expect any result from this procedure.
- BR-004 - The procedure has no database interactions; it does not read from or write to any database tables or sequences.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.
   
 PROCEDURE d2kwutil_DebugString (    hFunc       IN      ORA_FFI.funcHandleType,
                                     Text        IN      VARCHAR2);
 -- Pragmas
 PRAGMA INTERFACE(C,d2kwutil_DebugString,      11265);
```

#### SP-014 - D2KWUTIL.D2KWUTIL_FILEINFO

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.FILE_INFO]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Acts as a low-level Foreign Function Interface (FFI) wrapper that delegates a file-information request to an external native library function. It accepts a pre-resolved FFI function handle together with a file name, two option flags, and seven integer output buffers, then returns an integer result code. The procedure is invoked exclusively by D2KWUTIL.FILE_INFO within D2kwutil.pld, which is responsible for resolving the function handle and interpreting the output values.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| FileName | VARCHAR2 | IN OUT |
| Option1 | PLS_INTEGER | IN |
| Option2 | PLS_INTEGER | IN |
| dwOut1 | PLS_INTEGER | IN OUT |
| dwOut2 | PLS_INTEGER | IN OUT |
| dwOut3 | PLS_INTEGER | IN OUT |
| dwOut4 | PLS_INTEGER | IN OUT |
| dwOut5 | PLS_INTEGER | IN OUT |
| dwOut6 | PLS_INTEGER | IN OUT |
| dwOut7 | PLS_INTEGER | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| FileName | VARCHAR2 | IN OUT |
| dwOut1 | PLS_INTEGER | IN OUT |
| dwOut2 | PLS_INTEGER | IN OUT |
| dwOut3 | PLS_INTEGER | IN OUT |
| dwOut4 | PLS_INTEGER | IN OUT |
| dwOut5 | PLS_INTEGER | IN OUT |
| dwOut6 | PLS_INTEGER | IN OUT |
| dwOut7 | PLS_INTEGER | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that identifies the bound native library entry point for file-information retrieval.
- Step 2 - Accept the target file name (FileName) as an IN OUT parameter, allowing the native function to normalise or modify the path if required.
- Step 3 - Accept two integer option flags (Option1, Option2) that control the type or scope of file information requested from the native layer.
- Step 4 - Pass seven integer output buffers (dwOut1-dwOut7) IN OUT to the native function; these buffers receive the file-attribute values returned by the external call (e.g. size components, timestamps, attributes).
- Step 5 - Invoke the bound native function via the ORA_FFI mechanism using hFunc and all supplied parameters.
- Step 6 - Return the integer result code produced by the native function to the caller (D2KWUTIL.FILE_INFO) for further interpretation.

---
**Decision Points**

No decision points are determinable from the available source. Only the function specification is present; no PL/SQL body with conditional logic has been resolved.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function handle (hFunc) must be a valid, pre-bound ORA_FFI.funcHandleType; binding and validation of the handle is the responsibility of the calling routine D2KWUTIL.FILE_INFO.
- BR-002 - FileName is treated as IN OUT, meaning the native library may alter the supplied file path; the caller must use the returned value of FileName after the call.
- BR-003 - Seven discrete integer output buffers (dwOut1-dwOut7) must be supplied by the caller; the interpretation of each buffer's value is determined by the caller (D2KWUTIL.FILE_INFO) in conjunction with the Option1 and Option2 flags.
- BR-004 - The function returns a PLS_INTEGER result code; the caller is responsible for evaluating this code to determine success or failure of the file-information retrieval.
- BR-005 - This function contains no database interactions; all processing is delegated entirely to the external native library via ORA_FFI.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.
                                                                                                                                                         
FUNCTION d2kwutil_FileInfo ( hFunc      IN      ORA_FFI.funcHandleType,
                             FileName   IN OUT  VARCHAR2,
                             Option1    IN      PLS_INTEGER,
                             Option2    IN      PLS_INTEGER,
                             dwOut1     IN OUT  PLS_INTEGER,
                             dwOut2     IN OUT  PLS_INTEGER,
                             dwOut3     IN OUT  PLS_INTEGER,
                             dwOut4     IN OUT  PLS_INTEGER,
                             dwOut5     IN OUT  PLS_INTEGER,
                             dwOut6     IN OUT  PLS_INTEGER,
                             dwOut7     IN OUT  PLS_INTEGER
                           ) return PLS_INTEGER;
```

#### SP-015 - D2KWUTIL.DEBUGLOG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.FILE_INFO]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.SETDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

DEBUGLOG writes a formatted diagnostic message to the active debug output channel (an external debug API or a flat log file) when the current debug state permits logging. It enforces debug-level filtering, optional timestamping, and automatic fallback or restoration between the two output channels, ensuring that debug activity never raises an unhandled exception in the calling application.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugLevel | PLS_INTEGER | IN |
| LoggingCall | VARCHAR2 | IN |
| LogString | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- D2KWUTIL.SETDEBUG ([SP-018](#SP-018--D2KWUTIL.SETDEBUG)) - D2KWUTIL.pck (or .pld)
- D2KWUTIL.WINDEBUG ([SP-021](#SP-021--D2KWUTIL.WINDEBUG)) - D2KWUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate whether debugging is active: if the package-level debug state flag (iDebugState) equals 0 (disabled) or the debug-paused flag (bDebugPaused) is TRUE, exit immediately without writing anything.
- Step 2 - Evaluate the requested debug level: if the supplied DebugLevel exceeds the configured maximum level (iDebugLevel), exit immediately; the message is below the current verbosity threshold.
- Step 3 - Build the timestamp segment: if the timestamp flag (bDebugTimeStamp) is TRUE, format the current system time as HH24:MI:SS followed by '> ' and store it in vcDateStamp; otherwise vcDateStamp remains empty.
- Step 4 - Construct the full debug string: prefix the message with a zero-padded two-digit debug level in angle brackets, append the optional timestamp, then a right-padded 30-character caller label (LoggingCall + ':'), and finally append as much of LogString as fits within the 2,000-character limit.
- Step 5 - Determine the output channel based on iDebugState:
  - If iDebugState = 2 (debug API mode): attempt to write vcDebugString via the external debug API (win_api_debug.WinDebug). If the API is unavailable (DEBUG_API_ENABLED is FALSE), call SETDEBUG to switch to file-based logging (mode 1, target file vcDebugFile or 'd2kwutil.log'), log a channel-switch notice, re-invoke DEBUGLOG recursively with the original arguments, and set bDebugType2Required to TRUE to remember that API mode was requested.
  - If iDebugState ≠ 2 (file mode): check whether bDebugType2Required is TRUE and the API has become available again. If so, call SETDEBUG to restore API mode (mode 2), log a restoration notice, clear bDebugType2Required, and re-invoke DEBUGLOG recursively with the original arguments. Otherwise, open the log file (vcDebugFile) in append mode using TEXT_IO, write the formatted string, and close the file.
- Step 6 - Exception handling: if any error occurs during the logging attempt, silently set iDebugState to 0 (disable debugging) so that subsequent calls exit at Step 1 and the fault does not propagate to the calling business process.

---
**Decision Points**

DP-001

Condition: iDebugState = 0 (debug is globally disabled)

TRUE: Procedure exits immediately; no message is written and no further processing occurs.

FALSE: Proceed to DP-002.

---

DP-002

Condition: bDebugPaused is TRUE (debug is temporarily paused)

TRUE: Procedure exits immediately; no message is written.

FALSE: Proceed to DP-003.

---

DP-003

Condition: DebugLevel > iDebugLevel (the message's verbosity exceeds the configured threshold)

TRUE: Procedure exits immediately; the message is suppressed as below the active verbosity level.

FALSE: The message qualifies for output; proceed to timestamp and string construction.

---

DP-004

Condition: bDebugTimeStamp is TRUE

TRUE: The current system time (HH24:MI:SS) is appended to the debug string prefix.

FALSE: No timestamp is included in the formatted string.

---

DP-005

Condition: iDebugState = 2 (API-based debug output is configured)

TRUE: Attempt to write via the external debug API; proceed to DP-006.

FALSE: Use file-based output; proceed to DP-007.

---

DP-006

Condition: DEBUG_API_ENABLED is TRUE (the external debug API is available at runtime)

TRUE: Write vcDebugString directly via win_api_debug.WinDebug; processing complete.

FALSE: API is unavailable; call SETDEBUG to switch to file mode (mode 1), log a channel-switch notice via recursive DEBUGLOG calls, re-invoke DEBUGLOG with the original arguments, and set bDebugType2Required to TRUE.

---

DP-007

Condition: bDebugType2Required is TRUE AND DEBUG_API_ENABLED is TRUE (API mode was previously lost but is now available again)

TRUE: Call SETDEBUG to restore API mode (mode 2), log a restoration notice, clear bDebugType2Required, and re-invoke DEBUGLOG with the original arguments.

FALSE: Write vcDebugString to the flat log file (vcDebugFile) in append mode using TEXT_IO and close the file.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Logging is suppressed entirely when iDebugState equals 0; DEBUGLOG must never write output or raise errors when debugging is globally disabled.
- BR-002 - Logging is suppressed entirely when bDebugPaused is TRUE; a paused debug session must not produce any output regardless of debug level.
- BR-003 - A message is written only when its DebugLevel does not exceed the configured maximum iDebugLevel; messages above the threshold are silently discarded.
- BR-004 - The formatted debug string must not exceed 2,000 characters; LogString is truncated to fit within this limit after the fixed prefix and timestamp are applied.
- BR-005 - When API-based logging (iDebugState = 2) is configured but the API is unavailable, the procedure must automatically fall back to file-based logging and record the channel switch, ensuring no log entries are lost.
- BR-006 - When file-based logging is active and the API subsequently becomes available, the procedure must automatically restore API-based logging and record the restoration, reverting to the originally configured output channel.
- BR-007 - Any exception raised during the logging operation must be silently caught and iDebugState set to 0; debug instrumentation must never interrupt or fault the calling business process.
- BR-008 - The log file is opened in append mode for each write and closed immediately afterwards; DEBUGLOG must not hold the file open between calls.

---
**Implementation Logic**

```plsql
   
PROCEDURE DebugLog (DebugLevel  IN PLS_INTEGER, 
                    LoggingCall IN VARCHAR2, 
                    LogString   IN VARCHAR2) is
 vcDateStamp   VARCHAR2(10);
 vcDebugString VARCHAR2(2000);
 hFile         TEXT_IO.FILE_TYPE;
begin
  if iDebugState = 0 then 
  	NULL;
  elsif bDebugPaused then 
  	NULL;
  elsif DebugLevel > iDebugLevel then 
  	NULL;
  else
  	-- Sort out the Datestamp	
  	if bDebugTimeStamp then 
  		vcDateStamp := to_char(SYSDATE,'HH24:MI:SS')||'> ';
  	end if;
  
  	-- Construct the final String
  	vcDebugString := '<'||lpad(to_char(DebugLevel),2,0)||'> '||vcDateStamp||rpad(LoggingCall||':',30);
    vcDebugString := vcDebugString||substr(LogString,1,(2000-length(vcDebugString)));
  
  	if iDebugState = 2 then
  		if DEBUG_API_ENABLED then 
  	   		win_api_debug.WinDebug(vcDebugString);
  		else
  			-- Can't use API calls if the API functions aren't there
	  		-- So Switch to File Logging to d2kwut$.log
	  		SetDebug(1,nvl(vcDebugFile,'d2kwutil.log'),iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Unable to Log to Debugger Switching to File');
			DebugLog(DebugLevel,LoggingCall,LogString);	  		
	  		bDebugType2Required := TRUE;
	  	end if;
  	else
     	if bDebugType2Required and DEBUG_API_ENABLED then
	     	-- API now Available - Reinstate Debugging to Debugger
	  		SetDebug(2,vcDebugFile,iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Restoring Logging to Debugger');
	  		bDebugType2Required := FALSE;
	  		DebugLog(Debuglevel,LoggingCall,LogString);
	
	  	else
		 	hFile := TEXT_IO.FOPEN(vcDebugFile,'A');
		 	TEXT_IO.PUT_LINE(hFile,vcDebugString);
		 	TEXT_IO.FCLOSE(hFile);
		end if;
  	end if;
  end if;
 exception
  	-- Don't let the debugging cause Problems of it's own
  	when others then 
  		iDebugState := 0;
 end DebugLog;
```

#### SP-016 - D2KWUTIL.FILE_INFO

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CREATED_DATE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves file system information for a specified file by invoking the native Windows API function D2KWUTIL_FILEINFO via the D2KWUTIL integration layer. The procedure populates a set of internal integer buffers with file attributes returned by the API call, logs entry and result diagnostics, and raises a structured application error if the file does not exist, if the API is unavailable, or if the underlying system call returns an unexpected error code. It is called by D2KWUTIL.CREATED_DATE to support file metadata retrieval.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| CalledBy | VARCHAR2 | IN |
| FileName | VARCHAR2 | IN |
| Option1 | PLS_INTEGER | IN |
| Option2 | PLS_INTEGER | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- D2KWUTIL.ADD_ERROR ([SP-007](#SP-007--D2KWUTIL.ADD_ERROR)) - D2KWUTIL.pck (or .pld)
- D2KWUTIL.ADD_EXTERNAL_ERRORS ([SP-008](#SP-008--D2KWUTIL.ADD_EXTERNAL_ERRORS)) - D2KWUTIL.pck (or .pld)
- D2KWUTIL.BOOLTOCHAR ([SP-010](#SP-010--D2KWUTIL.BOOLTOCHAR)) - D2KWUTIL.pck (or .pld)
- D2KWUTIL.CLEAN_ERROR_STACK ([SP-011](#SP-011--D2KWUTIL.CLEAN_ERROR_STACK)) - D2KWUTIL.pck (or .pld)
- D2KWUTIL.D2KWUTIL_FILEINFO ([SP-014](#SP-014--D2KWUTIL.D2KWUTIL_FILEINFO)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- D2KWUTIL.DEBUGLOG ([SP-015](#SP-015--D2KWUTIL.DEBUGLOG)) - D2KWUTIL.pck (or .pld)
- D2KWUTIL.REGISTER_FUNCTION_CALL ([SP-017](#SP-017--D2KWUTIL.REGISTER_FUNCTION_CALL)) - D2KWUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Log entry diagnostics by calling D2KWUTIL.DEBUGLOG (at level 99), recording the CalledBy identifier, FileName, Option1, Option2, and the Boolean RaiseExceptions flag (converted to character via D2KWUTIL.BOOLTOCHAR).
- Step 2 - Clear the application error stack by calling D2KWUTIL.CLEAN_ERROR_STACK, ensuring no residual errors from prior calls are carried forward.
- Step 3 - Initialise the return code (iRC) and all nine integer output buffers (iBuff1-iBuff9) to zero, establishing a clean state before the API call.
- Step 4 - Check whether the Windows API integration layer is enabled (WIN_API.API_ENABLED).
- Step 5 - If the API is enabled, register the external function handle for D2KWUTIL_FILEINFO by calling D2KWUTIL.REGISTER_FUNCTION_CALL, declaring the expected parameter signature ('LONG','*CHAR,INT,INT,*LONG,*LONG,*LONG,*LONG,*LONG,*LONG,*LONG').
- Step 6 - Prepare the FileName argument by right-padding it to 512 characters with a null terminator (CHR(0)) to satisfy the C-string convention required by the external function.
- Step 7 - Assign Option1 to iBuff1 and Option2 to iBuff2, then invoke D2KWUTIL.D2KWUTIL_FILEINFO with the registered function handle, the padded filename, and all nine buffer variables, capturing the integer return code in iRC.
- Step 8 - Log result diagnostics by calling D2KWUTIL.DEBUGLOG (at level 99), recording iRC and the values of all nine output buffers.
- Step 9 - Evaluate iRC: if iRC is 0, -1074255551, or -1074245406 (codes indicating the file does not exist), call D2KWUTIL.ADD_ERROR with a 'File does not exist' message; if RaiseExceptions is TRUE, raise NO_DATA_FOUND.
- Step 10 - If iRC is any other value not equal to 1 (unexpected system error), call D2KWUTIL.ADD_ERROR with a message quoting the numeric error code; if RaiseExceptions is TRUE, raise NO_DATA_FOUND.
- Step 11 - In the exception block, re-raise NO_DATA_FOUND as-is; on WIN_API.NOT_AVAILABLE, call D2KWUTIL.ADD_ERROR with the standard no-API message and re-raise; on all other exceptions, call D2KWUTIL.ADD_ERROR appending the output of D2KWUTIL.ADD_EXTERNAL_ERRORS and re-raise.

---
**Decision Points**

DP-001
Condition: WIN_API.API_ENABLED is TRUE.
TRUE: Proceed to register the external function, prepare the filename buffer, and invoke D2KWUTIL.D2KWUTIL_FILEINFO.
FALSE: Raise the WIN_API.NOT_AVAILABLE exception, bypassing the API call entirely.

DP-002
Condition: iRC is one of the known file-not-found codes (0, -1074255551, or -1074245406).
TRUE: Call D2KWUTIL.ADD_ERROR with a 'File does not exist' message, then evaluate RaiseExceptions (see DP-003).
FALSE: Proceed to evaluate whether iRC indicates a different system error (DP-004).

DP-003
Condition: RaiseExceptions is TRUE (evaluated after a file-not-found or system-error condition is detected).
TRUE: Raise NO_DATA_FOUND to propagate the error to the caller.
FALSE: Allow the procedure to complete without raising an exception, leaving the error on the stack for the caller to inspect.

DP-004
Condition: iRC is not equal to 1 (and was not already handled as a file-not-found code).
TRUE: Call D2KWUTIL.ADD_ERROR with a system error message quoting iRC, then evaluate RaiseExceptions (see DP-003).
FALSE: iRC equals 1, indicating a successful API call; no error is recorded and processing completes normally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The Windows API integration layer must be enabled (WIN_API.API_ENABLED = TRUE) before any attempt is made to retrieve file information; if the API is unavailable, the procedure raises WIN_API.NOT_AVAILABLE and records a standardised no-API error message via D2KWUTIL.ADD_ERROR.
- BR-002 - The FileName argument must be null-terminated and padded to exactly 512 characters using CHR(0) before being passed to the external C function D2KWUTIL.D2KWUTIL_FILEINFO, ensuring compatibility with the external function's string convention.
- BR-003 - A return code of 0, -1074255551, or -1074245406 from D2KWUTIL.D2KWUTIL_FILEINFO is treated as a file-not-found condition and results in the error message 'File <FileName> does not exist' being added to the error stack.
- BR-004 - Any return code other than 1 that is not a recognised file-not-found code is treated as an unexpected system error; the numeric error code is included verbatim in the error message added via D2KWUTIL.ADD_ERROR.
- BR-005 - Exception propagation is caller-controlled: when RaiseExceptions is TRUE, both file-not-found and system-error conditions result in a NO_DATA_FOUND exception being raised; when FALSE, errors are recorded on the stack but execution returns normally.
- BR-006 - The error stack is always cleared at the start of execution via D2KWUTIL.CLEAN_ERROR_STACK, ensuring that error state reported to the caller reflects only the current invocation.
- BR-007 - All unhandled exceptions are caught, enriched with external error details via D2KWUTIL.ADD_EXTERNAL_ERRORS, recorded via D2KWUTIL.ADD_ERROR, and re-raised to preserve the original exception context for the caller.

---
**Implementation Logic**

```plsql

Procedure File_info ( CalledBy         IN  VARCHAR2,  
                      FileName         IN  VARCHAR2,
                      Option1          IN  PLS_INTEGER,
                      Option2          IN  PLS_INTEGER,
                      RaiseExceptions  IN BOOLEAN) is
 vcBuff1  varchar2(512);
 iRC      pls_integer;
begin
  Win_API_Debug.DebugLog(99,'File_Info','Args:  CalledBy="'||CalledBy||'", FileName="'||FileName||'", Option1='||to_char(Option1)||', Option2='||to_char(Option2)||', RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	  	
  WIN_API.Clean_Error_Stack;
  iRC    := 0;
  iBuff1 := 0;
  iBuff2 := 0;
  iBuff3 := 0;
  iBuff4 := 0;
  iBuff5 := 0;
  iBuff6 := 0;
  iBuff7 := 0;
  iBuff8 := 0;
  iBuff9 := 0;
  
  if WIN_API.API_ENABLED then 
    win_api.Register_function_call(iFileInfo,'d2kwutil_FileInfo','LONG','*CHAR,INT,INT,*LONG,*LONG,*LONG,*LONG,*LONG,*LONG,*LONG');
    vcBuff1 := RPAD(Filename,512,CHR(0));
    iBuff1  := Option1;
    iBuff2  := Option2;
    iRC     := d2kwutil_FileInfo(win_api.FunctionHandle(iFileInfo),vcBuff1,iBuff1,iBuff2,iBuff3,iBuff4,iBuff5,iBuff6,iBuff7,iBuff8,iBuff9);
    Win_API_Debug.DebugLog(99,'File_Info','Result:  RC='||to_char(iRC)||', iBuff1='||to_char(iBuff1)||', iBuff2='||to_char(iBuff2)||', iBuff3='||to_char(iBuff3)||', iBuff4='||to_char(iBuff4)||', iBuff5='||to_char(iBuff5)||', iBuff6='||to_char(iBuff6)||', iBuff7='||to_char(iBuff7)||', iBuff8='||to_char(iBuff8)||', iBuff9='||to_char(iBuff9));
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;
  if iRC in (0, -1074255551, -1074245406) then
    WIN_API.Add_error(CalledBy,'File '||FileName||' does not exist');
    if RaiseExceptions then 
      raise NO_DATA_FOUND;
    end if;
  elsif iRC <> 1 then 
    WIN_API.Add_error(CalledBy,'Gathering Information about '||FileName||' generated system error '||to_char(iRC));
    if RaiseExceptions then 
      raise NO_DATA_FOUND;
    end if;
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error(CalledBy,Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error(CalledBy, Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end;
```

#### SP-017 - D2KWUTIL.REGISTER_FUNCTION_CALL

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.FILE_INFO]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a named external DLL function and its calling signature with the Oracle FFI (Foreign Function Interface) layer so that the function can be invoked at runtime. The procedure ensures the target DLL is loaded, then registers the function handle, each of its parameters, and its return type against the DLL handle. A load-count cache prevents redundant re-registration unless the DLL has been reloaded since the last registration.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| FunctionID | PLS_INTEGER | IN |
| FunctionName | VARCHAR2 | IN |
| FunctionReturn | VARCHAR2 | IN |
| FunctionArgs | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- D2KWUTIL.ADD_ERROR ([SP-007](#SP-007--D2KWUTIL.ADD_ERROR)) - D2KWUTIL.pck (or .pld)
- D2KWUTIL.ATTEMPT_DLL_LOAD ([SP-009](#SP-009--D2KWUTIL.ATTEMPT_DLL_LOAD)) - D2KWUTIL.pck (or .pld)
- D2KWUTIL.TRANSLATETYPE ([SP-020](#SP-020--D2KWUTIL.TRANSLATETYPE)) - D2KWUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Attempt to locate the DLL in the Oracle FFI library cache by calling ORA_FFI.FIND_LIBRARY using the package-level DLL_NAME constant. If the library is found, execution continues; if an FFI error is raised, proceed to Step 2.
- Step 2 - If the DLL is not found in cache, call D2KWUTIL.ATTEMPT_DLL_LOAD passing DLL_Path and DLL_NAME to attempt a fresh load. If the load succeeds, execution continues with the returned handle; if it fails with an FFI error, proceed to Step 3.
- Step 3 - If ATTEMPT_DLL_LOAD fails, set the package-level flag API_ENABLED to FALSE, record the error via D2KWUTIL.ADD_ERROR with the message '<DLL_NAME> not found.', and raise NO_DATA_FOUND to abort processing.
- Step 4 - Check whether the function has already been registered by testing whether FunctionLoad(FunctionId) exists in the cache array and whether its stored load count matches the current DLL_LOAD_COUNT. If either condition is not met, registration (or re-registration) is required; otherwise skip to the end.
- Step 5 - Register the function with the DLL by calling ORA_FFI.REGISTER_FUNCTION using the DLL handle, FunctionName, and the C_STD calling convention, storing the resulting handle in FunctionHandle(FunctionId).
- Step 6 - Log the registration event for diagnostic purposes (initial registration or re-registration), except when the function being registered is 'd2kwutil_DebugString' to avoid recursive debug output.
- Step 7 - Parse the comma-delimited FunctionArgs string iteratively. For each argument fragment extracted before a comma delimiter, call D2KWUTIL.TRANSLATETYPE to convert the type name to its ORA_FFI constant, then call ORA_FFI.REGISTER_PARAMETER to register that parameter against the function handle. Continue until the argument string is exhausted, NULL, or equals 'VOID'.
- Step 8 - If FunctionReturn is not 'VOID' and is not NULL, call D2KWUTIL.TRANSLATETYPE on the return type string and register it against the function handle via ORA_FFI.REGISTER_RETURN.
- Step 9 - Store the current DLL_LOAD_COUNT in FunctionLoad(FunctionId) to mark this function as successfully registered for the current DLL load cycle.
- Step 10 - If an ORA_FFI.FFI_ERROR is raised at any point outside the inner DLL-load block, call D2KWUTIL.ADD_ERROR with the FunctionName and combined error details, then raise NO_DATA_FOUND.

---
**Decision Points**

DP-001

Condition: ORA_FFI.FIND_LIBRARY succeeds in locating the DLL in the FFI cache.

TRUE: DLL_HANDLE is populated and processing continues to the registration cache check (DP-003).

FALSE: An ORA_FFI.FFI_ERROR exception is raised; processing falls through to the inner exception handler and D2KWUTIL.ATTEMPT_DLL_LOAD is called (DP-002).

---

DP-002

Condition: D2KWUTIL.ATTEMPT_DLL_LOAD successfully loads the DLL and returns a valid handle.

TRUE: DLL_HANDLE is populated and processing continues to the registration cache check (DP-003).

FALSE: An ORA_FFI.FFI_ERROR exception is raised; API_ENABLED is set to FALSE, an error is logged via D2KWUTIL.ADD_ERROR, and NO_DATA_FOUND is raised to terminate the procedure.

---

DP-003

Condition: FunctionLoad(FunctionId) exists in the cache array AND its stored value equals the current DLL_LOAD_COUNT.

TRUE: The function is already registered for the current DLL load cycle; no registration steps are performed and the procedure exits normally.

FALSE: The function has not been registered, or the DLL has been reloaded since last registration; the full registration sequence (Steps 5-9) is executed.

---

DP-004

Condition: The FunctionName being registered equals 'd2kwutil_DebugString'.

TRUE: The debug log call is suppressed to prevent recursive logging.

FALSE: A debug log entry is written recording the function name, DLL load count, and whether this is an initial registration or a re-registration.

---

DP-005

Condition: During argument parsing, the remaining vcArgs string is NULL, equals ',', or equals 'VOID,'.

TRUE: The parameter registration loop exits; no further parameters are registered.

FALSE: The next comma-delimited argument fragment is extracted, translated via D2KWUTIL.TRANSLATETYPE, and registered via ORA_FFI.REGISTER_PARAMETER; the loop continues.

---

DP-006

Condition: FunctionReturn is not 'VOID' (case-insensitive) and is not NULL.

TRUE: D2KWUTIL.TRANSLATETYPE is called on FunctionReturn and the result is registered as the function's return type via ORA_FFI.REGISTER_RETURN.

FALSE: No return type is registered (the external function is treated as a void/procedure).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The DLL must be locatable via ORA_FFI.FIND_LIBRARY or loadable via D2KWUTIL.ATTEMPT_DLL_LOAD before any function registration is attempted; if neither succeeds, the API is disabled and the procedure aborts.
- BR-002 - API_ENABLED must be set to FALSE whenever the DLL cannot be loaded, ensuring that subsequent callers are aware that the external API is unavailable.
- BR-003 - A function must be re-registered whenever its cached DLL load count (FunctionLoad(FunctionId)) does not match the current DLL_LOAD_COUNT, guarding against stale handles caused by DLL reloads.
- BR-004 - All parameter type names supplied in FunctionArgs and the FunctionReturn value must be translated through D2KWUTIL.TRANSLATETYPE before being passed to the ORA_FFI layer; raw string type names are not accepted directly.
- BR-005 - FunctionArgs must be supplied as a comma-delimited string; the procedure appends a trailing comma and parses fragments iteratively, registering each non-VOID argument in declaration order.
- BR-006 - A return type is registered only when FunctionReturn is explicitly provided and is not 'VOID'; omitting or passing 'VOID' causes the external function to be treated as a procedure with no return value.
- BR-007 - The function 'd2kwutil_DebugString' is exempt from debug logging during registration to prevent recursive invocation of the debug subsystem.
- BR-008 - Any ORA_FFI.FFI_ERROR raised during the registration phase must be caught, reported via D2KWUTIL.ADD_ERROR, and re-raised as NO_DATA_FOUND so that callers receive a consistent exception signal.

---
**Implementation Logic**

```plsql

PROCEDURE Register_Function_Call ( FunctionID     in PLS_INTEGER, 
                                   FunctionName   in VARCHAR2,
                                   FunctionReturn in VARCHAR2, 
                                   FunctionArgs   in VARCHAR2) is
  vcArgs  VARCHAR2(200);
  vcFrag  VARCHAR2(10);
  iOffset PLS_INTEGER;   
begin 
   -- See if the DLL has been loaded at all.
   -- if this call to FIND_LIBRARY fails, we'll fall through to the Exception.
   begin
    DLL_HANDLE := ORA_FFI.find_library(DLL_NAME);
  exception
    when ora_ffi.ffi_error then 
      -- Attempt to load the DLL again in a subblock. If this fails
      -- then the API must be disabled and NOT_DATA_FOUND raised
      begin 
          DLL_HANDLE := Attempt_DLL_Load(DLL_Path, DLL_NAME);
      exception
          when ora_ffi.ffi_error then 
            API_ENABLED := FALSE;
              add_error('D2KWUTIL',DLL_NAME||' not found.');
            RAISE NO_DATA_FOUND;
      end;
  end;

  -- now compare the Cached value for this function's loadcount with 
  -- that for the DLL this tells us that the function has either not 
  -- been registered yet, or that the DLL has been reloaded in between 
  -- times.  This would not be healthy so we have to re-register in that case.
  if (not FunctionLoad.exists(FunctionId)) or (FunctionLoad(FunctionId)<> DLL_LOAD_COUNT) then
    -- We need to go through the registration process.      
    -- Register the function with the DLL
    FunctionHandle(FunctionId) := ora_ffi.register_function(Win_API.DLL_HANDLE,FunctionName,ORA_FFI.C_STD);
    if FunctionName <> 'd2kwutil_DebugString' then 
    	if not FunctionLoad.exists(FunctionId) then 
    		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Initial Reg');
    	else
       		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Re-Registration Count = '||to_char(FunctionLoad(FunctionId)));
       	end if;
    end if;
    
    -- Loop through and register the parameters
    vcArgs := FunctionArgs||',';
    while vcArgs is not null and vcArgs <> ',' and vcArgs <> 'VOID,' LOOP
      iOffset := instr(vcArgs,',');
      vcFrag := substr(vcArgs,1,iOffset-1);
      ora_ffi.register_parameter(FunctionHandle(FunctionId),TranslateType(vcFrag));
      if iOffset = length(vcArgs) then
        vcArgs := NULL;
      else
        vcArgs := substr(vcArgs,iOffset+1);
      end if;
    end LOOP;
    
    -- Register the return type IF this is a function
    if upper(FunctionReturn) <> 'VOID' and FunctionReturn is not NULL then 
      ora_ffi.register_return(FunctionHandle(FunctionId),TranslateType(FunctionReturn));
    end if;
    
    -- Now add this Function's Loadcount to the array to prevent un-nessary re-registration
    FunctionLoad(FunctionId) := DLL_LOAD_COUNT;
  end if;
exception
   when ora_ffi.ffi_error then
    Win_API.Add_error(FunctionName, Win_API.UError||WIN_API.Add_External_errors); 
    raise NO_DATA_FOUND;
end Register_Function_Call;
```

#### SP-018 - D2KWUTIL.SETDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Configures the debug logging state for the D2KWUTIL utility library. Accepts the desired debug output type (file or screen), an optional file path, a severity threshold level, and a timestamp flag, then sets the corresponding package-level variables and records an initialisation entry via D2KWUTIL.DEBUGLOG. This procedure must be called before any debug logging activity to establish where and how log messages will be written.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugType | PLS_INTEGER | IN |
| DebugFile | VARCHAR2 | IN |
| DebugLevel | PLS_INTEGER | IN |
| TimeStamp | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- D2KWUTIL.DEBUGLOG ([SP-015](#SP-015--D2KWUTIL.DEBUGLOG)) - D2KWUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Store the incoming TimeStamp flag in the package-level variable bDebugTimeStamp to control whether timestamps are prepended to subsequent log entries.
- Step 2 - Store the incoming DebugFile path in the package-level variable vcDebugFile to identify the target file for file-based logging.
- Step 3 - Store the incoming DebugLevel value in the package-level variable iDebugLevel to define the severity threshold that subsequent log calls will honour.
- Step 4 - Evaluate the DebugType parameter to determine the logging destination and set the package-level state variable iDebugState accordingly (see Decision Points).
- Step 5 - Call D2KWUTIL.DEBUGLOG with severity 0 and the module identifier 'SetDebug' to record an initialisation message that confirms the chosen logging mode.

---
**Decision Points**

DP-001

Condition: DebugType = 1

TRUE: Set iDebugState to 1 (file-based logging) and call D2KWUTIL.DEBUGLOG to record the message 'Logging to File ' concatenated with the supplied DebugFile path.

FALSE: Evaluate DP-002.

---

DP-002

Condition: DebugType = 2 (evaluated only when DP-001 is FALSE)

TRUE: Set iDebugState to 2 (screen/alternative logging) and call D2KWUTIL.DEBUGLOG to record the message 'Logging Started'.

FALSE: Call D2KWUTIL.DEBUGLOG to record the message 'Logging Stopped', then set iDebugState to 0, disabling all subsequent debug logging.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - DebugType = 1 activates file-based logging; the DebugFile parameter must contain a valid file path when this mode is selected, as it is stored directly and passed to D2KWUTIL.DEBUGLOG without further validation within this procedure.
- BR-002 - DebugType = 2 activates the alternative (non-file) logging mode; no file path is required or used in this mode.
- BR-003 - Any DebugType value other than 1 or 2 disables logging entirely by setting iDebugState to 0; the disablement is recorded via D2KWUTIL.DEBUGLOG before the state is cleared.
- BR-004 - DebugLevel defaults to 98 if not supplied, establishing the maximum severity threshold for subsequent log filtering.
- BR-005 - The TimeStamp flag defaults to FALSE if not supplied; when FALSE, timestamps are not prepended to log entries generated during the session.
- BR-006 - An initialisation log entry at severity level 0 is always written via D2KWUTIL.DEBUGLOG regardless of the DebugType value, providing an audit trail of every debug configuration change.

---
**Implementation Logic**

```plsql

PROCEDURE SetDebug( DebugType   IN PLS_INTEGER, 
                    DebugFile   IN VARCHAR2 DEFAULT NULL, 
                    DebugLevel  IN PLS_INTEGER DEFAULT 98,                        
                    TimeStamp   IN BOOLEAN DEFAULT FALSE) is
begin 
    bDebugTimeStamp := TimeStamp;
    vcDebugFile     := DebugFile;
    iDebugLevel     := DebugLevel;
	if DebugType = 1 then 
		iDebugState := 1;
		DebugLog(0,'SetDebug','Logging to File '||DebugFile);
	elsif DebugType = 2 then
		iDebugState := 2;
		DebugLog(0,'SetDebug','Logging Started');
	else 
        DebugLog(0,'SetDebug','Logging Stopped');
        iDebugState := 0;
	end if;
end SetDebug;
```

#### SP-019 - D2KWUTIL.STRIPDIRSEP

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sanitises a raw file-system path string by removing any semicolon-delimited suffix and any trailing backslash, returning a clean, single-path value suitable for use in DLL load operations invoked by D2KWUTIL.ATTEMPT_DLL_LOAD.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| InPath | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the raw path string (InPath) and assign it to a working variable (vcPath) of up to 500 characters.
- Step 2 - Check whether vcPath contains a semicolon character. If a semicolon is present, truncate vcPath to retain only the substring that precedes the first semicolon, discarding everything from the semicolon onward.
- Step 3 - Check whether the last character of the (possibly truncated) vcPath is a backslash. If it is, remove that trailing backslash by retaining only the substring up to but not including the final character.
- Step 4 - Return the cleaned path string to the caller.

---
**Decision Points**

DP-001

Condition:
The working path string (vcPath) contains one or more semicolon characters (INSTR(vcPath, ';') > 0).

TRUE:
vcPath is truncated to the substring that precedes the first semicolon, effectively discarding any additional path entries or parameters appended after the semicolon.

FALSE:
vcPath is left unchanged and processing continues to the trailing-backslash check.

---

DP-002

Condition:
The last character of vcPath is a backslash (SUBSTR(vcPath, -1, 1) = '\').

TRUE:
The trailing backslash is stripped by retaining only the substring from position 1 to LENGTH(vcPath) - 1.

FALSE:
vcPath is left unchanged and the cleaned path is returned as-is.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only the portion of a path that precedes the first semicolon is considered a valid path; any semicolon-delimited content that follows is discarded.
- BR-002 - A valid directory path must not end with a trailing backslash; if one is present it must be removed before the path is returned.
- BR-003 - The input path must not exceed 500 characters; the working variable is defined with this upper bound and any value exceeding it would be implicitly truncated at assignment.
- BR-004 - The function is non-destructive with respect to the original input; all modifications are applied to a local copy (vcPath), leaving the caller's value unchanged.

---
**Implementation Logic**

```plsql

  

Function StripDirSep ( InPath in varchar2) return varchar2 is 
  vcPath  varchar2(500) := InPath;
begin 
  -- Check and Strip SemiColons, we take everything
  -- Before the first Semicolon as our path
  if instr(vcPath,';') > 0 then
    vcPath := substr(vcPath,1,instr(vcPath,';') -1);
  end if;

  -- Check and Strip '\'
  if substr(vcPath,-1,1) = '\' then 
    vcPath := substr(vcPath,1,length(vcPath)-1);
  end if;

  return vcPath;
end StripDirSep;
```

#### SP-020 - D2KWUTIL.TRANSLATETYPE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Translates a string representation of a C data type into its corresponding ORA_FFI integer constant. The function is used internally by D2KWUTIL.REGISTER_FUNCTION_CALL to convert human-readable type names (e.g., 'INT', '*CHAR') into the numeric type identifiers required by the ORA_FFI foreign-function interface layer when registering external C function signatures.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DataType | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameter DataType (VARCHAR2) representing a C data type name, either by value or by pointer (prefixed with '*').
- Step 2 - Convert the input string to uppercase to ensure case-insensitive matching.
- Step 3 - Evaluate the uppercased type string against the full set of supported C type names using a sequential IF-ELSIF chain.
- Step 4 - Assign the matching ORA_FFI integer constant to the return variable iRC (e.g., ORA_FFI.C_CHAR_PTR, ORA_FFI.C_INT, ORA_FFI.C_LONG, etc.).
- Step 5 - Handle the aliases '*SHORT'/'*BYTE' as equivalent pointer types mapping to ORA_FFI.C_SHORT_PTR, and 'SHORT'/'BYTE' as equivalent value types mapping to ORA_FFI.C_SHORT.
- Step 6 - Return the resolved ORA_FFI integer constant to the caller.

---
**Decision Points**

DP-001

Condition: Uppercased DataType equals '*CHAR'

TRUE: Assign ORA_FFI.C_CHAR_PTR to iRC.

FALSE: Proceed to DP-002.

---

DP-002

Condition: Uppercased DataType equals 'CHAR'

TRUE: Assign ORA_FFI.C_CHAR to iRC.

FALSE: Proceed to DP-003.

---

DP-003

Condition: Uppercased DataType equals '*INT'

TRUE: Assign ORA_FFI.C_INT_PTR to iRC.

FALSE: Proceed to DP-004.

---

DP-004

Condition: Uppercased DataType equals 'INT'

TRUE: Assign ORA_FFI.C_INT to iRC.

FALSE: Proceed to DP-005.

---

DP-005

Condition: Uppercased DataType equals '*LONG'

TRUE: Assign ORA_FFI.C_LONG_PTR to iRC.

FALSE: Proceed to DP-006.

---

DP-006

Condition: Uppercased DataType equals 'LONG'

TRUE: Assign ORA_FFI.C_LONG to iRC.

FALSE: Proceed to DP-007.

---

DP-007

Condition: Uppercased DataType equals '*SHORT' OR '*BYTE'

TRUE: Assign ORA_FFI.C_SHORT_PTR to iRC.

FALSE: Proceed to DP-008.

---

DP-008

Condition: Uppercased DataType equals 'SHORT' OR 'BYTE'

TRUE: Assign ORA_FFI.C_SHORT to iRC.

FALSE: Proceed to DP-009.

---

DP-009

Condition: Uppercased DataType equals '*DOUBLE'

TRUE: Assign ORA_FFI.C_DOUBLE_PTR to iRC.

FALSE: Proceed to DP-010.

---

DP-010

Condition: Uppercased DataType equals 'DOUBLE'

TRUE: Assign ORA_FFI.C_DOUBLE to iRC.

FALSE: Proceed to DP-011.

---

DP-011

Condition: Uppercased DataType equals '*VOID'

TRUE: Assign ORA_FFI.C_VOID_PTR to iRC.

FALSE: No assignment is made; iRC remains NULL and is returned as-is.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Type matching is case-insensitive; the input DataType is converted to uppercase before evaluation, so callers may supply mixed-case type names.
- BR-002 - Pointer variants of a type are denoted by prefixing the type name with '*' (e.g., '*INT' maps to ORA_FFI.C_INT_PTR; 'INT' maps to ORA_FFI.C_INT).
- BR-003 - The type names 'BYTE' and 'SHORT' are treated as equivalent value types, both mapping to ORA_FFI.C_SHORT; similarly '*BYTE' and '*SHORT' both map to ORA_FFI.C_SHORT_PTR.
- BR-004 - If the supplied DataType does not match any recognised type name, the function returns NULL (iRC is never initialised), and no error is raised; the caller is responsible for handling a NULL return value.
- BR-005 - The supported type set is fixed at: CHAR, INT, LONG, SHORT, BYTE, DOUBLE, and VOID, each available in both value and pointer forms except VOID, which is supported only as a pointer type (*VOID).

---
**Implementation Logic**

```plsql
 
FUNCTION TranslateType(DataType in VARCHAR2) return PLS_INTEGER is
   -- Just a simple lookup of the types.
   vcType VARCHAR2(10) := UPPER(DataType);
   iRC    PLS_INTEGER;
begin 
  if vcType = '*CHAR' then 
    iRC := ORA_FFI.C_CHAR_PTR;
  elsif vcType = 'CHAR' then 
    iRC := ORA_FFI.C_CHAR;
  elsif vcType = '*INT' then 
    iRC := ORA_FFI.C_INT_PTR;
  elsif vcType = 'INT' then 
    iRC := ORA_FFI.C_INT;
  elsif vcType = '*LONG' then 
    iRC := ORA_FFI.C_LONG_PTR;
  elsif vcType = 'LONG' then 
    iRC := ORA_FFI.C_LONG;
  elsif vcType = '*SHORT' or vcType = '*BYTE'  then 
    iRC := ORA_FFI.C_SHORT_PTR;
  elsif vcType = 'SHORT' or vcType = 'BYTE' then 
    iRC := ORA_FFI.C_SHORT;
  elsif vcType = '*DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE_PTR;
  elsif vcType = 'DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE;  
  elsif vcType = '*VOID' then 
    iRC := ORA_FFI.C_VOID_PTR;      
  end if;
return iRC;
end TranslateType;
```

#### SP-021 - D2KWUTIL.WINDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sends a debug text string to an external Windows debug output channel by invoking the native D2KWUTIL_DEBUGSTRING function via the WIN_API dynamic-call framework. The procedure acts as a thin, safe wrapper that appends a newline to the supplied text, registers the external function handle, and dispatches the call, raising a structured error if the Windows API layer is unavailable or if any other runtime fault occurs.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- D2KWUTIL.D2KWUTIL_DEBUGSTRING ([SP-013](#SP-013--D2KWUTIL.D2KWUTIL_DEBUGSTRING)) - D2KWUTIL.pck (or .pld) (specification only - no body found)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameter Text (VARCHAR2) and construct a local buffer (vcBuff1) by appending a newline character (CHR(10)) to the supplied text, ensuring each debug message is terminated on its own line.
- Step 2 - Evaluate whether the Windows API layer is active by testing WIN_API.API_ENABLED.
- Step 3 - If the API is enabled, register the external function call for D2KWUTIL_DEBUGSTRING against the internal handle iDebugString, declaring the return type as '*CHAR', via WIN_API.REGISTER_FUNCTION_CALL.
- Step 4 - Invoke D2KWUTIL_DEBUGSTRING, passing the resolved function handle (WIN_API.FUNCTIONHANDLE(iDebugString)) and the newline-terminated buffer (vcBuff1), to write the debug string to the Windows debug output.
- Step 5 - If the API is not enabled, raise the WIN_API.NOT_AVAILABLE exception to signal that the debug channel cannot be reached.
- Step 6 - In the WIN_API.NOT_AVAILABLE exception handler, log the error against the 'WinDebug' context using WIN_API.ADD_ERROR with the WIN_API.NOAPI error code, then re-raise the exception to the caller.
- Step 7 - In the OTHERS exception handler, log the error against the 'WinDebug' context combining WIN_API.UERROR with any additional external error detail from WIN_API.ADD_EXTERNAL_ERRORS, then re-raise the exception to the caller.

---
**Decision Points**

DP-001

Condition: WIN_API.API_ENABLED evaluates to TRUE.

TRUE: Register the D2KWUTIL_DEBUGSTRING function handle and dispatch the debug string to the Windows debug output channel.

FALSE: Raise WIN_API.NOT_AVAILABLE to indicate that the Windows API layer is not accessible and the debug output cannot be written.

DP-002

Condition: Exception WIN_API.NOT_AVAILABLE is caught in the exception block.

TRUE: Log a structured error for the 'WinDebug' context using WIN_API.NOAPI as the error code, then re-raise the exception so the calling routine (D2KWUTIL.DEBUGLOG) is notified of the unavailability.

FALSE: Not applicable; control falls to the OTHERS handler for any other exception type.

DP-003

Condition: An unclassified (OTHERS) exception is caught in the exception block.

TRUE: Log a structured error for the 'WinDebug' context combining WIN_API.UERROR with supplementary detail from WIN_API.ADD_EXTERNAL_ERRORS, then re-raise the exception.

FALSE: Not applicable; no exception means normal completion after the debug string has been dispatched.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The input text must always be suffixed with a newline character (CHR(10)) before being passed to the external debug function, ensuring each debug message occupies a distinct line in the debug output.
- BR-002 - The procedure may only dispatch a debug string when the Windows API layer is active (WIN_API.API_ENABLED is TRUE); any attempt to write debug output when the layer is unavailable must result in a WIN_API.NOT_AVAILABLE exception.
- BR-003 - All exceptions, whether WIN_API.NOT_AVAILABLE or any other runtime fault, must be logged against the 'WinDebug' context via WIN_API.ADD_ERROR before being re-raised, preserving a traceable error record for upstream handlers.
- BR-004 - Unclassified runtime errors must include supplementary external error detail (WIN_API.ADD_EXTERNAL_ERRORS) appended to the base error code (WIN_API.UERROR) when logged, ensuring maximum diagnostic information is captured.
- BR-005 - The external function D2KWUTIL_DEBUGSTRING must be registered with a return type of '*CHAR' via WIN_API.REGISTER_FUNCTION_CALL on every invocation before the function handle is resolved and used, conforming to the WIN_API dynamic-call protocol.

---
**Implementation Logic**

```plsql
  

  
PROCEDURE WinDebug  (  Text  IN   VARCHAR2) is
  vcBuff1 VARCHAR2(2000) := Text||chr(10);
begin 
  --WIN_API.Clean_Error_Stack;
  if Win_API.API_ENABLED then
    win_api.Register_function_call(iDebugString,'d2kwutil_DebugString',NULL,'*CHAR');
    d2kwutil_DebugString(win_api.FunctionHandle(iDebugString),vcBuff1);
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if; 
exception
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('WinDebug',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('WinDebug',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end WinDebug;
```

#### SP-022 - GENERAL.ASK_CONFIRM

**Invoked From:**

- pt_soq_ims_fmb.xml [Trigger: FT_CANCEL]
- pt_soq_ims_fmb.xml [Trigger: FT_DEL]
- pt_soq_ims_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

N/A

---

**Purpose**

Displays a configurable confirmation alert (AL_CONFIRM) to the user and returns a numeric indicator of the button pressed. Calling triggers use the return value to determine whether the user confirmed or cancelled a requested action (e.g., record deletion or form cancellation).

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| confirm_msg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the confirmation message text via the input parameter confirm_msg.
- Step 2 - Set the message text of the predefined alert AL_CONFIRM to the value of confirm_msg using set_alert_property.
- Step 3 - Display the AL_CONFIRM alert to the user via show_alert and capture the button pressed in the local variable p_albtn_pressed.
- Step 4 - Evaluate the captured button response: if the user pressed ALERT_BUTTON1 (the affirmative/confirm button), return 1 to the caller; otherwise return 0 to indicate the user did not confirm.

---
**Decision Points**

DP-001

Condition: p_albtn_pressed = ALERT_BUTTON1 (the user pressed the first/confirm button on the AL_CONFIRM alert)

TRUE: The function returns 1, signalling to the calling trigger that the user has confirmed the requested action.

FALSE: The function returns 0, signalling to the calling trigger that the user has not confirmed (i.e., declined or dismissed) the requested action.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The confirmation dialog must always use the predefined alert component AL_CONFIRM; no other alert component is used by this function.
- BR-002 - The alert message text is dynamically overwritten with the caller-supplied confirm_msg before the alert is shown, allowing a single reusable alert component to serve multiple confirmation scenarios.
- BR-003 - A return value of 1 exclusively represents user confirmation (ALERT_BUTTON1); any other button response yields a return value of 0, treating all non-affirmative responses as a cancellation.
- BR-004 - The function has no side effects on database state; it solely governs user-confirmation flow and returns a binary numeric result to the calling trigger for further processing.

---
**Implementation Logic**

```plsql
FUNCTION ASK_CONFIRM( confirm_msg VARCHAR2)
                                      RETURN  NUMBER IS

    p_alert_name varchar2(10) := 'AL_CONFIRM' ;
    p_albtn_pressed number;
BEGIN
   set_alert_property(p_alert_name,alert_message_text,confirm_msg); 
   p_albtn_pressed := show_alert(p_alert_name);

   IF ( p_albtn_pressed = ALERT_BUTTON1 ) THEN
      return (1);
   ELSE
      return(0);
   END IF;
RETURN NULL; END;
```

#### SP-023 - GENERAL.CHECK_FORM_FAILURE

**Invoked From:**

- pt_soq_ims_fmb.xml [Trigger: KEY-COMMIT]

---

**Screen:**

N/A

---

**Purpose**

Centralises post-operation failure handling for Oracle Forms commit processing. After a commit attempt, this procedure inspects the built-in form status indicators to determine whether the operation succeeded. If it did not, it retrieves the appropriate error message (Oracle database error or Oracle Forms runtime error) and displays it to the user via GENERAL.DISP_TEXT before halting further trigger execution by raising FORM_TRIGGER_FAILURE.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-025](#SP-025--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate the built-in FORM_SUCCESS function to determine whether the most recent Forms operation completed without error.
- Step 2 - If the operation was not successful, inspect the built-in ERROR_TYPE indicator to classify the failure.
- Step 3 - If ERROR_TYPE equals 'ORA' (an Oracle database-level error), call GENERAL.DISP_TEXT passing SQLERRM as the message text and 'Error' as the severity label to display the database error to the user.
- Step 4 - If ERROR_TYPE equals 'FRM' (an Oracle Forms runtime error), call GENERAL.DISP_TEXT passing ERROR_TEXT as the message text and 'Error' as the severity label to display the Forms error to the user.
- Step 5 - After displaying the error message, raise FORM_TRIGGER_FAILURE to abort the KEY-COMMIT trigger and prevent any further processing.

---
**Decision Points**

DP-001

Condition:
NOT FORM_SUCCESS - the most recent Forms operation did not complete successfully.

TRUE:
Proceed to classify the error type and display an error message, then raise FORM_TRIGGER_FAILURE.

FALSE:
No action is taken; the procedure exits normally and commit processing continues.

---

DP-002

Condition:
ERROR_TYPE = 'ORA' - the failure originated at the Oracle database layer.

TRUE:
Call GENERAL.DISP_TEXT with SQLERRM (the Oracle database error message) and severity label 'Error'.

FALSE:
Fall through to evaluate whether ERROR_TYPE = 'FRM'.

---

DP-003

Condition:
ERROR_TYPE = 'FRM' - the failure originated within the Oracle Forms runtime layer.

TRUE:
Call GENERAL.DISP_TEXT with ERROR_TEXT (the Forms runtime error message) and severity label 'Error'.

FALSE:
No message is displayed (error type is neither 'ORA' nor 'FRM'); FORM_TRIGGER_FAILURE is still raised to abort the trigger.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A commit operation that does not satisfy FORM_SUCCESS must never be allowed to complete silently; an error message must always be presented to the user before the trigger is aborted.
- BR-002 - Oracle database errors (ERROR_TYPE = 'ORA') must be reported using the standard Oracle error message returned by SQLERRM, ensuring the user receives the precise database-level failure description.
- BR-003 - Oracle Forms runtime errors (ERROR_TYPE = 'FRM') must be reported using the Forms-supplied ERROR_TEXT, ensuring the user receives the Forms-layer failure description.
- BR-004 - All error messages must be displayed with severity label 'Error' via GENERAL.DISP_TEXT (SP-025), enforcing a consistent error-presentation standard across the application.
- BR-005 - Regardless of whether an error message is displayed, FORM_TRIGGER_FAILURE must be raised whenever FORM_SUCCESS is FALSE, unconditionally preventing downstream KEY-COMMIT processing from continuing.

---
**Implementation Logic**

```plsql
PROCEDURE CHECK_FORM_FAILURE IS
BEGIN
 IF (NOT form_success) THEN
     IF ERROR_TYPE = 'ORA' THEN
        GENERAL.disp_text(SQLERRM,'Error');
     ELSIF ERROR_TYPE = 'FRM' THEN
        GENERAL.disp_text(ERROR_TEXT,'Error');
     END IF;
     raise form_trigger_failure;
  END IF; 

END;
```

#### SP-024 - GENERAL.CHECK_NULL

**Invoked From:**

- pt_soq_ims_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]
- pt_soq_ims_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]
- pt_soq_ims_fmb.xml [Trigger: WVI]

---

**Screen:**

SUGGESTED ORDER QUANTITY PROCESSING (N/A / CN_MAIN); PO DETAILS (N/A / CN_PARTY)

---

**Purpose**

Validates that a mandatory field value has been supplied by the user. If the provided value is NULL, the procedure displays a contextual error message identifying the offending field and halts further form processing. It is used across the Suggested Order Quantity Processing and PO Details screens to enforce non-null entry on required inputs.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_value | VARCHAR2 | IN |
| column_title | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-025](#SP-025--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the field value (P_value) and the human-readable column title (column_title) as input parameters.
- Step 2 - Construct an error message text by concatenating the static prefix 'Enter a valid ' with the supplied column_title, producing a field-specific prompt (e.g., 'Enter a valid Supplier').
- Step 3 - Evaluate whether P_value is NULL.
- Step 4 - If P_value IS NULL, invoke GENERAL.DISP_TEXT (SP-025) passing the constructed message text and the severity indicator 'Error' to present the error to the user.
- Step 5 - After displaying the error, raise FORM_TRIGGER_FAILURE to halt the triggering event and prevent the form from proceeding.
- Step 6 - If P_value is NOT NULL, no action is taken and control returns normally to the calling trigger.

---
**Decision Points**

DP-001

Condition:
P_value IS NULL

TRUE:
Call GENERAL.DISP_TEXT with the message 'Enter a valid <column_title>' and severity 'Error', then raise FORM_TRIGGER_FAILURE to abort the current form trigger.

FALSE:
No error is raised; the procedure exits silently and the calling trigger continues normal execution.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A field submitted for null-check validation must contain a non-null value; a NULL value is treated as an invalid entry and is not permitted to pass validation.
- BR-002 - The error message presented to the user must identify the specific field in error by incorporating the column_title parameter, ensuring the message is contextual and actionable (format: 'Enter a valid <column_title>').
- BR-003 - When a null value is detected, form processing must be unconditionally halted via FORM_TRIGGER_FAILURE; no partial or subsequent processing steps in the calling trigger may proceed.
- BR-004 - Error notification must be delivered through GENERAL.DISP_TEXT (SP-025) with severity 'Error', ensuring consistent error presentation across all screens that invoke this procedure.

---
**Implementation Logic**

```plsql
PROCEDURE CHECK_NULL( P_value IN VARCHAR2, column_title  IN VARCHAR2) IS
mesg_text        varchar2(80) := 'Enter a valid '||column_title ;
BEGIN
   IF p_value IS null  THEN
      GENERAL.DISP_TEXT(mesg_text,'Error');
      raise form_trigger_failure;
   END IF;
END;
```

#### SP-025 - GENERAL.DISP_TEXT

**Invoked From:**

- pt_soq_ims_fmb.xml [ProgramUnit: BUILD_WHERE]
- DPL.pld [StoredProcedure: GENERAL.CHECK_FORM_FAILURE]
- DPL.pld [StoredProcedure: GENERAL.CHECK_NULL]
- DPL.pld [StoredProcedure: GENERAL.RAISE_ERROR]
- pt_soq_ims_fmb.xml [Trigger: ON-ERROR]
- pt_soq_ims_fmb.xml [Trigger: ON-MESSAGE]
- pt_soq_ims_fmb.xml [Trigger: POST-QUERY]
- pt_soq_ims_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]
- pt_soq_ims_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]
- pt_soq_ims_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

SUGGESTED ORDER QUANTITY PROCESSING (N/A / CN_MAIN); PO DETAILS (N/A / CN_PARTY); PART AND STOCK DETAILS (N/A / CN_SOQ)

---

**Purpose**

Displays a modal alert dialog to the user containing a supplied message and title. The procedure selects the appropriate Oracle Forms alert object based on whether the message is classified as an error or a general notification, then presents it to the user. It is used across multiple screens and calling contexts to provide consistent, centralised message presentation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| text_string | VARCHAR2 | IN |
| title_string | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Initialise the local alert name variable to the default error alert 'AL_ERRINFO'.
- Step 2 - Evaluate the supplied title string: if it equals 'ERROR' (case-insensitive), retain 'AL_ERRINFO' as the alert object; otherwise assign 'AL_NOTE' to indicate a general informational notice.
- Step 3 - Set the TITLE property of the selected alert object to the supplied title_string using SET_ALERT_PROPERTY.
- Step 4 - Set the ALERT_MESSAGE_TEXT property of the selected alert object to the supplied text_string using SET_ALERT_PROPERTY.
- Step 5 - Display the configured alert to the user via SHOW_ALERT and capture the user's response in the local alert ID variable (response is not evaluated further).

---
**Decision Points**

DP-001

Condition:
UPPER(title_string) = 'ERROR'

TRUE:
The alert object 'AL_ERRINFO' is used, presenting the message as an error-severity dialog.

FALSE:
The alert object 'AL_NOTE' is used, presenting the message as a general informational or notification dialog.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must receive both a message body (text_string) and a title (title_string); neither has a default value, so callers are responsible for supplying meaningful content.
- BR-002 - Alert severity is determined solely by the title string: a title of 'ERROR' (case-insensitive) maps to the error alert 'AL_ERRINFO'; any other title maps to the informational alert 'AL_NOTE'.
- BR-003 - The user's button response returned by SHOW_ALERT is not evaluated or acted upon; the procedure is used purely to inform the user and does not branch on the user's acknowledgement.
- BR-004 - All message display across the Suggested Order Quantity Processing, PO Details, and Part and Stock Details screens must route through this procedure to ensure consistent alert formatting and behaviour.

---
**Implementation Logic**

```plsql
PROCEDURE DISP_TEXT (text_string VARCHAR2,
                     title_string VARCHAR2 ) IS 
   p_alert_name varchar2(10) := 'AL_ERRINFO' ; 
   p_alert_id number;
BEGIN
   if upper(title_string)='ERROR' then
      p_alert_name := 'AL_ERRINFO' ; 
   else
      p_alert_name := 'AL_NOTE' ; 
   end if;
   set_alert_property(p_alert_name,TITLE,title_string);  
   set_alert_property(p_alert_name,alert_message_text,text_string);  
   p_alert_id := show_alert(p_alert_name); 
END;
```

#### SP-026 - GENERAL.L_POP_LIST_ITEM

**Invoked From:**

- pt_soq_ims_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

N/A

---

**Purpose**

Populates a named Oracle Forms record group from a dynamic SQL query supplied at runtime. The procedure ensures a clean record group state by deleting any pre-existing group with the same name before recreating it from the provided SELECT statement and populating it with current data. It is invoked during form initialisation (WHEN-NEW-FORM-INSTANCE) to load list-item data into the form.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_rg_name | VARCHAR2 | IN |
| p_select | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the record group name (p_rg_name) and the SQL SELECT statement (p_select) as input parameters.
- Step 2 - Attempt to locate an existing Oracle Forms record group whose name matches p_rg_name using Find_Group.
- Step 3 - If a matching record group is found (i.e., the returned ID is not null), delete it using delete_group to ensure no stale data or structural conflicts remain.
- Step 4 - Create a new record group from the supplied query string by calling Create_Group_From_Query with the group name and p_select; store the resulting record group ID in rg_id.
- Step 5 - Populate the newly created record group with data by calling Populate_Group, capturing the return code in errcode.

---
**Decision Points**

DP-001

Condition: The record group identified by p_rg_name already exists in the current Oracle Forms session (Find_Group returns a non-null ID).

TRUE: The existing record group is deleted via delete_group before a fresh group is created, preventing duplicate or conflicting group definitions.

FALSE: No deletion is performed; processing continues directly to creating the new record group from the supplied query.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A record group with the name supplied in p_rg_name must not persist from a previous instantiation; any pre-existing group of that name must be removed before the new group is created, ensuring the list item is always loaded from a fresh, query-driven data set.
- BR-002 - The record group must be built dynamically from the SQL SELECT statement provided in p_select, meaning the structure and content of the list item are entirely determined by the caller-supplied query rather than a hard-coded definition.
- BR-003 - The procedure must be executed during form initialisation (WHEN-NEW-FORM-INSTANCE) so that list-item data is available to the user from the moment the form opens.

---
**Implementation Logic**

```plsql

PROCEDURE l_pop_list_item (p_rg_name VARCHAR2,p_select VARCHAR2 )IS

	 rg_name VARCHAR2(40) := p_rg_name;
	 rg_id RecordGroup;
	 errcode NUMBER; 
BEGIN 
	/* ** Make sure group doesn't already exist */ 
	rg_id := Find_Group( rg_name ); 

	IF NOT Id_Null(rg_id) THEN 
		delete_group(rg_id);
	END IF;
	/* ** If it does not exist, create it and add the two ** necessary columns to it. */ 
		rg_id := Create_Group_From_Query( rg_name, p_select); 
	 
	/* ** Populate the record group */ 
	errcode := Populate_Group( rg_id );
END;
```

#### SP-027 - GENERAL.RAISE_ERROR

**Invoked From:**

- pt_soq_ims_fmb.xml [Trigger: ON-ERROR]

---

**Screen:**

N/A

---

**Purpose**

Centralises error, note, and caution message handling for Oracle Forms. When invoked from the ON-ERROR trigger, the procedure receives a message code, constructs a display string, classifies the message by type, and presents it to the user via GENERAL.DISP_TEXT with an appropriate title. For error-type messages it additionally raises FORM_TRIGGER_FAILURE to halt further form processing.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| mesg_code | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-025](#SP-025--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message code (mesg_code) as the sole input parameter.
- Step 2 - Concatenate mesg_code with the resolved message text to form the full display string in the format '<code> : <text>'.
- Step 3 - Evaluate the mesg_type value to determine the classification of the message ('E' for Error, 'N' for Note, 'C' for Caution).
- Step 4 - If the message type is 'E', set the title to 'Error', call GENERAL.DISP_TEXT to present the message to the user, then raise FORM_TRIGGER_FAILURE to stop form processing.
- Step 5 - If the message type is 'N', set the title to 'Note' and call GENERAL.DISP_TEXT to present the message; processing continues normally.
- Step 6 - If the message type is 'C', set the title to 'Caution' and call GENERAL.DISP_TEXT to present the message; processing continues normally.
- Step 7 - If mesg_type does not match any of the three recognised values, no display action is taken and the procedure exits silently.

---
**Decision Points**

DP-001

Condition:
mesg_type = 'E'

TRUE:
Set mesg_title to 'Error', invoke GENERAL.DISP_TEXT with the composed message and title, then raise FORM_TRIGGER_FAILURE to abort the current form trigger chain.

FALSE:
Proceed to evaluate whether mesg_type = 'N' (DP-002).

---

DP-002

Condition:
mesg_type = 'N'

TRUE:
Set mesg_title to 'Note' and invoke GENERAL.DISP_TEXT with the composed message and title; form processing continues.

FALSE:
Proceed to evaluate whether mesg_type = 'C' (DP-003).

---

DP-003

Condition:
mesg_type = 'C'

TRUE:
Set mesg_title to 'Caution' and invoke GENERAL.DISP_TEXT with the composed message and title; form processing continues.

FALSE:
None of the recognised message types matched; no display action is taken and the procedure exits without further action.

---
**Database Interactions**

- DB-001 - Read AM_PERMISSIONS - Reads data from AM_PERMISSIONS for lookup or validation.
**Business Rules**

- BR-001 - The display string presented to the user must always be composed as '<mesg_code> : <mesg_text>', ensuring the originating code is visible alongside the descriptive text.
- BR-002 - Only three message type classifications are recognised: 'E' (Error), 'N' (Note), and 'C' (Caution); any other value results in no user notification.
- BR-003 - An Error-type message (mesg_type = 'E') must always terminate the active form trigger by raising FORM_TRIGGER_FAILURE after displaying the message, preventing any further processing.
- BR-004 - Note-type ('N') and Caution-type ('C') messages are informational only; they are displayed to the user but do not interrupt form processing.
- BR-005 - All user-facing message display must be performed exclusively through GENERAL.DISP_TEXT (SP-025), ensuring consistent message presentation across the application.

---
**Implementation Logic**

```plsql
PROCEDURE RAISE_ERROR ( mesg_code IN VARCHAR2 )IS
  mesg_type  varchar2(7); 
  mesg_text  varchar2(200) ;
  mesg_title varchar2(7);
  BEGIN
     -- murali 17.05.04 GENERAL.get_message(mesg_code,mesg_text,mesg_type );
     mesg_text:=mesg_code||' : '||mesg_text;		
     IF ( mesg_type = 'E' ) THEN
        mesg_title := 'Error' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
        raise FORM_TRIGGER_FAILURE;
     ELSIF ( mesg_type = 'N' ) THEN
        mesg_title := 'Note' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     ELSIF ( mesg_type = 'C' ) THEN
        mesg_title := 'Caution' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     END IF;
  END;     

/* PROCEDURE check_rights( 
pi_form_name in varchar2,
pi_user_id in number) IS
lv_x varchar2(1);
BEGIN
	
	begin
	SELECT substr(access_string, pi_user_id,1) 
	INTO   lv_x
	FROM   	am_permissions
	WHERE  form_name = pi_form_name
	AND SUBSTR(access_string,pi_user_id,1)='Y';
	exception 
		when no_data_found then
		  general.disp_text('You do not have the Permission to access this.','Error rr');
		  raise form_trigger_failure; 
		when too_many_rows then
		  general.disp_text('Many rows in USER_PERMISSIONS','Error ss');
		  raise form_trigger_failure;
		when others then
		       general.disp_text(sqlerrm,'Error mm');
		       raise form_trigger_failure;
	end;

	open_form(pi_form_name,activate,session);
END;
*/
```

#### SP-028 - PKG_DS_AUTO_CLEARANCE.FN_GET_PEND_ORDER

**Invoked From:**

- PKG_DS_AUTO_CLEARANCE.pck [StoredProcedure: PKG_DS_AUTO_CLEARANCE.SP_DEADSTK_PO_SO]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Calculates the total pending order quantity for a given part (identified by its root part number) across indent and sales order documents raised within the last 7 days, for a specific dealer, location, parent group, and company. The function returns the net unfulfilled quantity (indent quantity plus sales order quantity, each reduced by cancellations and fulfilment quantities) to support the dead-stock auto-clearance process.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_PARENT | VARCHAR2 | IN |
| P_DEALER | NUMBER | IN |
| P_LOC | VARCHAR2 | IN |
| P_COMP | VARCHAR2 | IN |
| P_PART | VARCHAR2 | IN |
| P_ROOT_PART | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the six input parameters: parent group (P_PARENT), dealer code (P_DEALER), location code (P_LOC), company/FA code (P_COMP), part number (P_PART), and root part number (P_ROOT_PART).
- Step 2 - Query PD_INDENT joined with PH_INDENT and PM_PART to compute the net pending indent quantity for the root part. For each matching indent line, the pending quantity is calculated as: indent_qty minus the greater of (cancel_qty or full indent_qty when status is 'C') minus allocated_qty minus issued_qty. Only indents dated within the last 7 days (indent_date >= TRUNC(SYSDATE) - 7) and belonging to the specified dealer, location (indent_to), parent group, and company are included. PM_PART is used to resolve the root part number, filtering on dealer_map_cd = 1. The aggregate SUM is stored in lv_indent_qty.
- Step 3 - Query PD_SO joined with PM_PART and PD_PO_SO to compute the net pending sales order quantity for the root part. For each matching SO line, the pending quantity is: so_qty minus cancel_qty minus alloc_qty minus bill_qty. Only SO records dated within the last 7 days (so_date >= TRUNC(SYSDATE) - 7) and linked to the specified dealer, location, parent group, company, SO number, and part number via PD_PO_SO are included. PM_PART resolves the root part number with dealer_map_cd = 1. The aggregate SUM is stored in lv_so_qty.
- Step 4 - Combine the two pending quantities: lv_qty = NVL(lv_indent_qty, 0) + NVL(lv_so_qty, 0). NULL values are treated as zero.
- Step 5 - If the combined quantity is negative, return 0 to prevent a negative pending order figure from being passed to the caller.
- Step 6 - If the combined quantity is zero or positive, return lv_qty as the total pending order quantity.
- Step 7 - If any unhandled exception occurs during execution, return 0 to ensure the calling routine receives a safe default value.

---
**Decision Points**

DP-001

Condition: The indent header status (ph.indent_status) equals 'C' (Cancelled).

TRUE: The full indent_qty is treated as the cancelled amount (DECODE returns indent_qty), effectively zeroing out that line's contribution to the pending quantity.

FALSE: The actual cancel_qty value is used in the deduction, allowing the remaining uncancelled quantity to contribute to the pending total.

DP-002

Condition: The computed combined pending quantity (lv_qty) is less than 0.

TRUE: The function returns 0, preventing a negative pending order value from being surfaced to the caller.

FALSE: The function returns lv_qty as the valid non-negative pending order quantity.

DP-003

Condition: An unhandled exception is raised at any point during function execution.

TRUE: The WHEN OTHERS exception handler returns 0, ensuring the caller always receives a numeric result.

FALSE: Normal execution continues and the result is returned via DP-002 logic.

---
**Database Interactions**

- DB-001 - Read PD_INDENT - Reads data from PD_INDENT for lookup or validation.
- DB-002 - Read PD_SO - Reads data from PD_SO for lookup or validation.
- DB-003 - Read PD_PICK_LIST - Reads data from PD_PICK_LIST for lookup or validation.
- DB-004 - Read PM_PART - Reads data from PM_PART for lookup or validation.
**Business Rules**

- BR-001 - Only indent and sales order documents dated within the last 7 calendar days (document date >= TRUNC(SYSDATE) - 7) are considered when calculating pending order quantities, limiting the scope to recent unfulfilled demand.
- BR-002 - Part matching is performed via the root part number (PM_PART.ROOT_PART_NUM = P_ROOT_PART) with PM_PART filtered to the master dealer (dealer_map_cd = 1), ensuring that all variant parts sharing the same root are aggregated together regardless of the specific part number variant.
- BR-003 - For indent lines, the net pending quantity deducts cancellations (or the full quantity if the indent is fully cancelled with status 'C'), allocated quantities, and issued quantities from the original indent quantity, reflecting only the truly unfulfilled demand.
- BR-004 - For sales order lines, the net pending quantity deducts cancel_qty, alloc_qty, and bill_qty from so_qty, ensuring already fulfilled or allocated SO quantities are excluded from the pending total.
- BR-005 - NULL values returned by either aggregate query are treated as zero (via NVL) before summation, preventing arithmetic errors when no qualifying records exist.
- BR-006 - The function must never return a negative value; if the calculated total is less than zero, it is floored to 0 to maintain data integrity for the dead-stock clearance evaluation.
- BR-007 - In the event of any runtime exception, the function returns 0 as a safe default, ensuring the parent procedure PKG_DS_AUTO_CLEARANCE.SP_DEADSTK_PO_SO is not interrupted by errors within this lookup function.

---
**Implementation Logic**

```plsql

  FUNCTION FN_GET_PEND_ORDER(P_PARENT    VARCHAR2,
                             P_DEALER    NUMBER,
                             P_LOC       VARCHAR2,
                             P_COMP      VARCHAR2,
                             P_PART      VARCHAR2,
                             P_ROOT_PART VARCHAR2) RETURN NUMBER IS
    lv_qty            number;
    lv_indent_qty     number;
    lv_so_qty         number;
    lv_picked_qty_ind number;
    lv_picked_qty_co  number;

  BEGIN

    select sum(x.indent_qty -
               nvl(decode(ph.indent_status, 'C', x.indent_qty, x.cancel_qty),
                   0) - nvl(x.allocated_qty, 0) - nvl(x.issued_qty, 0))
      into lv_indent_qty
      from pd_indent x, ph_indent ph, pm_part pm
     where ph.dealer_map_cd = P_DEALER
          --and x.loc_cd=P_LOC  --Modified by pooja 22-05-2023
       and ph.indent_to = P_LOC
       and ph.parent_group = P_PARENT
       and ph.comp_fa = P_COMP
       and x.part_num = pm.part_num
       and pm.root_part_num = P_ROOT_PART
       and pm.dealer_map_cd = 1
       and ph.indent_date >= trunc(sysdate) - 7
       and x.parent_group = ph.parent_group
       and x.dealer_map_cd = ph.dealer_map_cd
       and x.loc_cd = ph.loc_cd
       and x.comp_fa = ph.comp_fa
       and x.indent_num = ph.indent_num; --modified by Pooja 18-05-2023

    /*  select sum(x.so_qty-nvl(x.cancel_qty,0)-nvl(x.alloc_qty,0)-nvl(x.bill_qty,0))
    into lv_so_qty
    from pd_so x,pm_part pm,ph_so ph
    where ph.dealer_map_cd=P_DEALER
      and ph.loc_cd=P_LOC
      and ph.parent_group=P_PARENT
      and ph.comp_fa=P_COMP
      and x.part_num=pm.part_num
      and pm.root_part_num = P_ROOT_PART
      and pm.dealer_map_cd = 1
       and ph.so_date >= trunc(sysdate)-7
      and ph.parent_group = x.parent_group
      and ph.dealer_map_cd = x.dealer_map_cd
      and ph.loc_cd = x.loc_cd
      and ph.comp_fa = x.comp_fa; */ --modified by Pooja 19-05-2023

    select sum(x.so_qty - nvl(x.cancel_qty, 0) - nvl(x.alloc_qty, 0) -
               nvl(x.bill_qty, 0))
      into lv_so_qty
      from pd_so x, pm_part pm, pd_po_so d
     where d.so_dealer_map_cd = P_DEALER
       and d.so_loc_cd = P_LOC
       and d.so_parent_group = P_PARENT
       and d.so_comp_fa = P_COMP
       and x.part_num = pm.part_num
       and pm.root_part_num = P_ROOT_PART
       and pm.dealer_map_cd = 1
       and d.so_date >= trunc(sysdate) - 7
       and d.so_parent_group = x.parent_group
       and d.so_dealer_map_cd = x.dealer_map_cd
       and d.so_loc_cd = x.loc_cd
       and d.so_comp_fa = x.comp_fa
       and d.so_num = x.so_num
       and d.part_num = x.part_num; --Added by pooja 29-Jun-2023

    /*SELECT sum(x.pick_qty)
     INTO lv_picked_qty_ind
     FROM pd_pick_list x,pd_indent y
    WHERE x.parent_group = P_PARENT
      and x.dealer_map_cd = P_DEALER
      and x.loc_cd = P_LOC
      and x.comp_fa = P_COMP
      and x.parent_group = y.parent_group
      and x.dealer_map_cd = y.dealer_map_cd
      and x.loc_cd = y.loc_cd
      and x.comp_fa = y.comp_fa
      and x.ref_doc_num=y.indent_num
      and x.part_num=y.part_num
      and x.part_num in (select y.part_num from pm_part y where y.dealer_map_cd=P_DEALER and y.root_part_num=P_ROOT_PART)
      and x.pick_date >= trunc(sysdate - 7);*/ --commented by Pooja on 18-May-23

    /*SELECT sum(x.pick_qty)
     INTO lv_picked_qty_co
     FROM pd_pick_list x,pd_so y
    WHERE x.parent_group = P_PARENT
      and x.dealer_map_cd = P_DEALER
      and x.loc_cd = P_LOC
      and x.comp_fa = P_COMP
      and x.parent_group = y.parent_group
      and x.dealer_map_cd = y.dealer_map_cd
      and x.loc_cd = y.loc_cd
      and x.comp_fa = y.comp_fa
      and x.ref_doc_num=y.so_num
      and x.part_num=y.part_num
      and x.part_num in (select y.part_num from pm_part y where y.dealer_map_cd=P_DEALER and y.root_part_num=P_ROOT_PART)
      and x.pick_date >= trunc(sysdate - 7);*/ --commented by Pooja on 18-May-23

    lv_qty := nvl(lv_indent_qty, 0) + nvl(lv_so_qty, 0);
    -- -nvl(lv_picked_qty_ind,0)-nvl(lv_picked_qty_co,0); --commented by Pooja on 18-MAY-23

    IF lv_qty < 0 then
      --Added by pooja on 27-07-2023
      return 0;
    ELSE
      RETURN lv_qty;
    END IF;

  exception
    when others then
      return 0;
  END FN_GET_PEND_ORDER;
```

#### SP-029 - PKG_DS_AUTO_CLEARANCE.SP_DEADSTK_PO_SO

**Invoked From:**

- pt_soq_ims_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

PO DETAILS (N/A / CN_PARTY)

---

**Purpose**

This procedure automates the dead-stock clearance process by identifying parts from a dealer's SOQ (Statement of Quantity) list that qualify for inter-dealer transfer, locating suitable supplier dealers within the same cluster/region that hold sufficient net stock, and generating the corresponding sales order (CO) or material transfer indent (MTI) documents - along with their detail and header records - so that dead-stock inventory can be redistributed without manual intervention.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_PRINCIPAL | NUMBER | IN |
| P_CONSG | VARCHAR2 | IN |
| P_PARENT | VARCHAR2 | IN |
| P_DEALER | NUMBER | IN |
| P_LOC | VARCHAR2 | IN |
| P_COMP | VARCHAR2 | IN |
| P_TYPE | VARCHAR2 | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_AOS_NUM | VARCHAR2 | OUT |
| P_ERR_CD | NUMBER | OUT |
| P_ERR_MSG | VARCHAR2 | OUT |

---

**Dependencies**

- D2KWUTIL.CREATED_DATE ([SP-012](#SP-012--D2KWUTIL.CREATED_DATE)) - D2KWUTIL.pck (or .pld)
- PKG_DS_AUTO_CLEARANCE.FN_GET_PEND_ORDER ([SP-028](#SP-028--PKG_DS_AUTO_CLEARANCE.FN_GET_PEND_ORDER)) - PKG_DS_AUTO_CLEARANCE.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Truncate the global temporary table GLB_TEMP_DEAD_STK_NEW to clear any residual data from a prior execution.
- Step 2 - Derive the current financial year from SYSDATE using a floor-division on the month number.
- Step 3 - Construct the AOS (Auto Order Session) number by concatenating a fixed prefix 'C', the consignee code (P_CONSG), 'D', a timestamp string, and the order type (P_TYPE); initialise P_ERR_CD and P_ERR_MSG to NULL.
- Step 4 - Fetch the requesting dealer's category (mapped to party type 'DI' or 'D'), FORMAT code, region code, and previous SOQ date from AM_DEALER_LOC and AM_DEALER_LOC_PARAM; raise an error if the dealer record is not found.
- Step 5 - Retrieve all active cluster codes (comma-aggregated) from PM_PO_CLUS_MPG for the given consignee, parent group, and principal, to be used later when identifying eligible supplier dealers.
- Step 6 - Loop over each qualifying SOQ line (CUR_PART) from PT_SOQ_MUL_TIL where SOQ quantity > 0, filtered by order type: type 'E' excludes parts with family age 0 or 6; type 'N' includes only parts with family age 0 or 6.
- Step 7 - For each SOQ part, look up purchase price, part value (price × SOQ qty), order reason code, and dead-stock flag from PM_PART_VAR; if the direct lookup yields no data, fall back to a root-part-based lookup via PM_PART.
- Step 8 - For order type 'N', retrieve the part's tag code from PM_PART; if the tag code is 5, resolve the minimum available tag code (1, 3, or 4) across all master parts sharing the same root part number.
- Step 9 - Apply the eligibility threshold: proceed only if part value ≥ 300 AND (for type 'N') tag code ≠ 5, order reason code = 0, and dead-stock flag = 'N'.
- Step 10 - Check PD_PO_SO for any existing picked order ('C') for the same part and dealer dated on or after the previous SOQ date; if one exists, skip the part (no duplicate processing).
- Step 11 - For eligible parts with no pending order, loop over candidate supplier dealers (CUR_DS_DTL) that hold positive net stock for the root part, are active in the cluster mapping, and belong to a spares stock yard location.
- Step 12 - For each candidate supplier dealer, fetch its company code from AM_DEALER_LOC_COMPANY_MASTER and the requesting dealer's party details (code, name, address, city) from GM_PARTY.
- Step 13 - Check PD_PO_SO for any cancelled/picked order within the last 30 days between the requesting dealer and the candidate supplier for the same part; if found, skip this supplier.
- Step 14 - If the party code is resolved and no recent cancellation exists, evaluate net available stock: candidate supplier's current stock minus pending ordered quantity (via FN_GET_PEND_ORDER) must be ≥ the requested SOQ quantity.
- Step 15 - If the stock condition is met, insert a staging row into GLB_TEMP_DEAD_STK_NEW capturing buyer and seller dealer details, quantities, pricing, and party information; set the local AOS flag (ln_aos) to 1.
- Step 16 - After processing each SOQ line, if ln_aos = 1, update PT_SOQ_MUL_TIL to set AOS_TYPE = 'S' for that row, marking it as matched for auto-clearance.
- Step 17 - Loop over distinct buyer-seller dealer combinations from GLB_TEMP_DEAD_STK_NEW (excluding same-consignee pairs) to generate transaction documents.
- Step 18 - For each combination, fetch the GST registration numbers for both the buyer dealer and the seller dealer from AM_DEALER_LOC_PARAM; skip the combination if either party is GST-unregistered.
- Step 19 - Fetch an active salesman code from GM_EMP for the seller dealer (category 'P' or 'S'); fall back to category 'C' if no active salesman is found.
- Step 20 - Determine document type: if the buyer and seller GST numbers differ, generate a Customer Order (CO) document number via PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM against the seller dealer; otherwise generate a Material Transfer Indent (MTI) document number against the buyer dealer. Raise an application error if document number generation fails.
- Step 21 - For each part line within the seller dealer group, accumulate serial number, basic amount, and total value; fetch the FSN indicator from PM_PART_VAR for the part.
- Step 22 - Insert the sales order detail into PD_SO (for CO) or the indent detail into PD_INDENT (for MTI), recording quantities, pricing, and audit fields.
- Step 23 - Insert the inter-dealer PO/SO link record into PD_PO_SO for every part line, capturing buyer stock quantity, seller stock quantity, FSN indicator, and the generated document number.
- Step 24 - After processing all part lines for a dealer combination, if at least one line was inserted (ln_srl > 0), insert the PO/SO header record into PH_PO_SO.
- Step 25 - Insert the sales order header into PH_SO (for CO) or the indent header into PH_INDENT (for MTI), recording party details, amounts, salesman, and remarks.

---
**Decision Points**

DP-001

Condition: P_TYPE = 'E' AND part_family_age NOT IN (0, 6), OR P_TYPE = 'N' AND part_family_age IN (0, 6)

TRUE: The SOQ line is included in CUR_PART for processing.

FALSE: The SOQ line is excluded from the current execution.

---

DP-002

Condition: Direct PM_PART_VAR lookup by part number returns NO_DATA_FOUND.

TRUE: A fallback query is executed using the root part number via PM_PART (catg_cd = 'M') to retrieve purchase price and related attributes.

FALSE: Purchase price, part value, order reason code, and dead-stock flag are taken from the direct lookup result.

---

DP-003

Condition: P_TYPE = 'N'

TRUE: The tag code is retrieved from PM_PART for the part; if tag code = 5, the minimum non-obsolete tag code (1, 3, or 4) is resolved from sibling master parts sharing the same root part number.

FALSE: Tag code logic is skipped entirely.

---

DP-004

Condition: tag_cd = 5 (resolved after PM_PART lookup, applicable only when P_TYPE = 'N')

TRUE: Minimum tag code among values 1, 3, 4 for the same root part is fetched; lv_tag_cd is updated with this resolved value.

FALSE: The originally fetched tag code is retained.

---

DP-005

Condition: (P_TYPE = 'E' AND ln_part_val >= 300) OR (P_TYPE = 'N' AND ln_part_val >= 300 AND lv_tag_cd != 5 AND lv_ord_reas = 0 AND lv_dead_sock = 'N')

TRUE: The part proceeds to pending-order and supplier-stock checks.

FALSE: The part is skipped; no transfer records are created.

---

DP-006

Condition: A picked PD_PO_SO record exists for the part and dealer dated on or after the previous SOQ date (lv_pend_co = 'Y').

TRUE: The part is skipped; no supplier search or staging insert is performed.

FALSE: The procedure proceeds to search for eligible supplier dealers.

---

DP-007

Condition: A picked PD_PO_SO record exists between the requesting dealer and the candidate supplier for the same part within the last 30 days (lv_cncl_co = 'Y').

TRUE: The candidate supplier is skipped for this part.

FALSE: The candidate supplier is evaluated for stock availability.

---

DP-008

Condition: lv_pcode IS NOT NULL (party code was successfully resolved from GM_PARTY).

TRUE: The cancellation check and stock availability check are performed.

FALSE: The candidate supplier is skipped.

---

DP-009

Condition: Candidate supplier's current stock minus FN_GET_PEND_ORDER result >= requested SOQ quantity.

TRUE: A staging row is inserted into GLB_TEMP_DEAD_STK_NEW and ln_aos is set to 1.

FALSE: The candidate supplier is skipped; no staging insert is performed.

---

DP-010

Condition: ln_aos = 1 after completing the supplier search loop for a SOQ part.

TRUE: PT_SOQ_MUL_TIL is updated to set AOS_TYPE = 'S' for the processed row.

FALSE: No update is made to PT_SOQ_MUL_TIL.

---

DP-011

Condition: Either the buyer or seller GST number is NULL or equals 'GSTUNREGISTERED'.

TRUE: The dealer combination is skipped (CONTINUE); no documents are generated.

FALSE: Document generation proceeds.

---

DP-012

Condition: lv_gst_num <> lv_gst_num_ds (buyer and seller have different GST registrations).

TRUE: A Customer Order (CO) document number is generated against the seller dealer; PD_SO and PH_SO records are inserted.

FALSE: A Material Transfer Indent (MTI) document number is generated against the buyer dealer; PD_INDENT and PH_INDENT records are inserted.

---

DP-013

Condition: ln_srl > 0 after processing all part lines for a dealer combination.

TRUE: Header records are inserted into PH_PO_SO and either PH_SO (CO path) or PH_INDENT (MTI path).

FALSE: No header records are inserted.

---
**Database Interactions**

- DB-001 - Read PT_SOQ_MUL_TIL - Reads data from PT_SOQ_MUL_TIL (columns: aos type) for lookup or validation.
- DB-002 - Read AM_DEALER_LOC - Reads data from AM_DEALER_LOC for lookup or validation.
- DB-003 - Read DUAL - Reads data from DUAL for lookup or validation.
- DB-004 - Read PM_PO_CLUS_MPG - Reads data from PM_PO_CLUS_MPG for lookup or validation.
- DB-005 - Read PM_PART_VAR - Reads data from PM_PART_VAR for lookup or validation.
- DB-006 - Read SUB - Reads data from SUB for lookup or validation.
- DB-007 - Read PM_PART - Reads data from PM_PART for lookup or validation.
- DB-008 - Read PD_PO_SO - Reads data from PD_PO_SO (columns: aos num, consg cd, parent group, dealer map cd, loc cd, comp fa, part num, srl num, and 16 more column(s)) for lookup or validation.
- DB-009 - Read AM_DEALER_LOC_COMPANY_MASTER - Reads data from AM_DEALER_LOC_COMPANY_MASTER for lookup or validation.
- DB-010 - Read GM_PARTY - Reads data from GM_PARTY for lookup or validation.
- DB-011 - Insert into GLB_TEMP_DEAD_STK_NEW - Persists a new row into GLB_TEMP_DEAD_STK_NEW using columns: part num, root part num, consg cd, parent group, dealer map cd, loc cd, comp fa, ds consg cd, and 16 more column(s).
- DB-012 - Update PT_SOQ_MUL_TIL - Updates existing rows in PT_SOQ_MUL_TIL (columns: aos type).
- DB-013 - Read GLB_TEMP_DEAD_STK_NEW - Reads data from GLB_TEMP_DEAD_STK_NEW (columns: part num, root part num, consg cd, parent group, dealer map cd, loc cd, comp fa, ds consg cd, and 16 more column(s)) for lookup or validation.
- DB-014 - Read AM_DEALER_LOC_PARAM - Reads data from AM_DEALER_LOC_PARAM for lookup or validation.
- DB-015 - Read GM_EMP - Reads data from GM_EMP for lookup or validation.
- DB-016 - Insert into PD_SO - Persists a new row into PD_SO using columns: dealer map cd, loc cd, so num, comp fa, srl num, part num, so qty, sell price, and 10 more column(s).
- DB-017 - Insert into PD_INDENT - Persists a new row into PD_INDENT using columns: dealer map cd, loc cd, indent qty, part num, sti srl, landed cost, received qty, created by, and 6 more column(s).
- DB-018 - Insert into PD_PO_SO - Persists a new row into PD_PO_SO using columns: aos num, consg cd, parent group, dealer map cd, loc cd, comp fa, part num, srl num, and 16 more column(s).
- DB-019 - Insert into PH_PO_SO - Persists a new row into PH_PO_SO using columns: aos num, consg cd, parent group, dealer map cd, loc cd, comp fa, so consg cd, so parent group, and 7 more column(s).
- DB-020 - Insert into PH_SO - Persists a new row into PH_SO using columns: dealer map cd, loc cd, so num, comp fa, so date, party type, party cd, basic amt, and 13 more column(s).
- DB-021 - Insert into PH_INDENT - Persists a new row into PH_INDENT using columns: dealer map cd, loc cd, indent num, indent date, indent to, requested by, remarks, created date, and 7 more column(s).
**Business Rules**

- BR-001 - The AOS number is system-generated as 'C' + consignee code + 'D' + timestamp (YYYYMMDDHHMISS) + order type, ensuring a unique session identifier per execution.
- BR-002 - The financial year is determined by the calendar month: months 1-3 (floor of month/4 = 0) belong to the prior calendar year; all other months belong to the current calendar year.
- BR-003 - SOQ lines with zero or null SOQ quantity are excluded from dead-stock clearance processing.
- BR-004 - For order type 'E' (existing/aged parts), only parts with a part family age other than 0 or 6 are eligible; for order type 'N' (new/zero-age parts), only parts with family age 0 or 6 are eligible.
- BR-005 - A part is eligible for dead-stock clearance only if its total part value (purchase price × SOQ quantity) is at least 300.
- BR-006 - For order type 'N', a part is additionally ineligible if its tag code resolves to 5 (obsolete), its order reason code is non-zero, or its dead-stock flag is 'Y'.
- BR-007 - If a part's tag code is 5 under order type 'N', the system resolves the minimum available tag code among 1, 3, and 4 from sibling master parts (catg_cd = 'M') sharing the same root part number; if the resolved code is still 5, the part remains ineligible.
- BR-008 - A part is not processed for transfer if a picked (status 'C') PD_PO_SO order already exists for the same part and requesting dealer on or after the previous SOQ date, preventing duplicate orders within the same SOQ cycle.
- BR-009 - A candidate supplier dealer is disqualified if a picked PD_PO_SO order for the same part between the requesting dealer and that supplier exists within the last 30 calendar days, preventing repeated transfers after a recent cancellation.
- BR-010 - Supplier dealers are identified only from locations marked as spares stock yards (spares_stock_yard_yn = 'Y') that are active in the cluster mapping (active_yn = 'Y', mapp_type = 'R') for the requesting dealer's principal.
- BR-011 - The net available stock at the supplier is calculated as current stock minus pending ordered quantity (via FN_GET_PEND_ORDER); this net figure must be greater than or equal to the requested SOQ quantity for the supplier to qualify.
- BR-012 - Supplier candidates are prioritised in descending order of net current stock, ensuring the best-stocked supplier is matched first.
- BR-013 - A dealer combination is excluded from document generation if either the buyer or seller dealer does not have a valid (non-'GSTUNREGISTERED') GST number in AM_DEALER_LOC_PARAM.
- BR-014 - If the buyer and seller dealers have different GST numbers, a Customer Order (CO) is raised at the seller dealer location; if they share the same GST number, a Material Transfer Indent (MTI) is raised at the buyer dealer location.
- BR-015 - Document numbers for CO and MTI are generated by PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM; a failure in document number generation immediately raises an application error and halts processing for that dealer combination.
- BR-016 - The consignee code of the buyer must differ from the consignee code of the seller (consg_cd != ds_consg_cd) for a dealer combination to be eligible for document generation, preventing intra-consignee self-transfers.
- BR-017 - All transactional records (PD_SO / PD_INDENT, PD_PO_SO, PH_PO_SO, PH_SO / PH_INDENT) are stamped with created_by = 'MUL' or 'ADMIN' and created_date = SYSDATE, identifying them as system-generated auto-clearance documents.
- BR-018 - The FSN (Fast/Slow/Non-moving) indicator from PM_PART_VAR is captured and stored in PD_PO_SO at the time of order creation to preserve the part's movement classification at the point of transfer.
- BR-019 - Both buyer and seller net stock quantities at the time of order creation are recorded in PD_PO_SO (BUYER_STOCK_QTY and SELLER_STOCK_QTY) for audit and reconciliation purposes.
- BR-020 - Duplicate key violations during insertion into PD_SO, PD_PO_SO, PH_SO, and PH_INDENT are handled gracefully (logged via DBMS_OUTPUT) without aborting the overall procedure, allowing remaining combinations to be processed.

---
**Implementation Logic**

```plsql
  PROCEDURE SP_DEADSTK_PO_SO(P_PRINCIPAL NUMBER,
                             P_CONSG     VARCHAR2,
                             P_PARENT    VARCHAR2,
                             P_DEALER    NUMBER,
                             P_LOC       VARCHAR2,
                             P_COMP      VARCHAR2,
                             P_TYPE      VARCHAR2,
                             P_AOS_NUM   OUT VARCHAR2,
                             P_ERR_CD    OUT NUMBER,
                             P_ERR_MSG   OUT VARCHAR2) IS
    lv_clus   VARCHAR2(500); --pm_po_clus_mpg.clus_cd%type; Commented by saket as on 03-05-2023
    lv_comp   am_dealer_loc_company_master.comp_code%type;
    lv_for_cd am_dealer_loc.for_cd%type;
    lv_reg_cd am_dealer_loc.region_cd%type; --Added by Anand on 05-Dec-2018 for making cluster within region

    lv_ptype VARCHAR2(2);
    lv_pcode gm_party.party_cd%type;
    lv_pname gm_party.party_name%type;

    lv_padd1 gm_party.party_address1%type;
    lv_padd2 gm_party.party_address2%type;
    lv_padd3 gm_party.party_address3%type;
    lv_pcity gm_party.city_cd%type;

    lv_doc_num ph_so.so_num%type;
    lv_errmsg  VARCHAR2(100);
    lv_error   NUMBER;
    lv_fin_yr  VARCHAR2(4);
    lv_sman    gm_emp.emp_cd%type;

    ln_srl       NUMBER := 0;
    ln_basic_amt NUMBER(21, 6) := 0;
    ln_disc_amt  NUMBER(21, 6) := 0;
    ln_tot_val   NUMBER(21, 6) := 0;

    lv_pend_co   VARCHAR2(1);
    lv_cncl_co   VARCHAR2(1);
    ln_pur_price pm_part_var.purchase_price%type;
    lv_ord_reas  pm_part_var.order_reason_cd%type;
    lv_dead_sock pm_part_var.dead_stock_yn%type;

    lv_tag_cd   NUMBER := 0;
    ln_part_val NUMBER(21, 6) := 0;
    ln_aos      NUMBER;

    ld_prev_soq_date DATE;

    lv_gst_num    VARCHAR2(50); --Added by pooja on 26-07-2023
    lv_gst_num_ds VARCHAR2(50); --Added by pooja on 26-07-2023

    lv_fsn_ind PM_PART_VAR.FSN_IND%TYPE; --Added by Nawal for JIRA:DMS-2200

    CURSOR CUR_PART IS
      SELECT tl.rowid,
             tl.parent_group,
             tl.dealer_map_cd,
             tl.loc_cd,
             tl.comp_fa,
             tl.part_num,
             tl.root_part_num,
             tl.amd_soq_qty soq_qty
        FROM pt_soq_mul_til tl
       WHERE tl.parent_group = P_PARENT
         AND tl.dealer_map_cd = P_DEALER
         AND tl.loc_cd = P_LOC
         AND tl.comp_fa = P_COMP
         AND NVL(tl.soq_qty, 0) > 0
         AND ((P_TYPE = 'E' AND tl.part_family_age NOT IN (0, 6)) OR
             (P_TYPE = 'N' AND tl.part_family_age IN (0, 6)));

    CURSOR CUR_DS_DTL(P_PART VARCHAR2, P_CLUS VARCHAR2, P_REG VARCHAR2) IS
      SELECT pd.part_num,
             am.consg_cd,
             am.parent_group,
             am.dealer_map_cd,
             am.loc_cd,
             am.dealer_name,
             am.loc_desc,
             pm.root_part_num,
             --GET_PART_NET_STOCK(pd.dealer_map_Cd, pd.loc_Cd, pd.part_num, 'P') cur_stk,
             GET_PART_NET_STOCK(pd.dealer_map_Cd,
                                pd.loc_Cd,
                                pm.root_part_num,
                                'R') cur_stk,
             pd.part_discount,
             pv.mrp_1,
             pv.purchase_price
        FROM am_dealer_loc      am,
             pm_part_dead_stock pd,
             pm_po_clus_mpg     dl,
             pm_part_var        pv,
             pm_part            pm
       WHERE pd.part_num = P_PART
         AND nvl(pd.deleted_yn, 'N') = 'N'
         AND am.parent_group = pd.parent_group
         AND am.dealer_map_cd = pd.dealer_map_cd
         AND am.loc_cd = pd.loc_cd
         AND am.spares_stock_yard_yn = 'Y'
            --AND dl.for_cd = am.for_cd                --Check of for_code removed By Anand on 05-Dec-2018
         AND dl.clus_region_cd = am.region_cd --Check of region Added By Anand on 05-Dec-2018
         AND dl.consg_cd = am.consg_cd
            --AND dl.for_cd = P_FOR                      --Check of for_code removed By Anand on 05-Dec-2018
            --AND dl.clus_region_cd = P_REG --Check of region Added By Anand on 05-Dec-2018 --Commented by saket as on 05-05-2023
            --AND dl.clus_cd = P_CLUS Commented by saket as on 05-05-2023
         AND dl.clus_cd in
             (SELECT REGEXP_SUBSTR(lv_clus, '[^,]+', 1, LEVEL) TXT
                FROM DUAL
              CONNECT By REGEXP_SUBSTR(lv_clus, '[^,]+', 1, LEVEL) IS NOT NULL) --added by Pooja on 21-06-2023
         AND dl.mapp_type = 'R'
         AND dl.active_yn = 'Y'
         AND dl.principal_map_cd = P_PRINCIPAL
         AND pv.parent_group = am.parent_group
         AND pv.dealer_map_cd = am.dealer_map_cd
         AND pv.loc_cd = am.loc_cd
         AND pv.part_num = pd.part_num
         AND pm.dealer_map_cd = P_PRINCIPAL
         AND pm.part_num = pv.part_num
         AND pm.principal_map_cd = am.principal_map_cd
         AND GET_PART_NET_STOCK(pd.dealer_map_Cd,
                                pd.loc_Cd,
                                pm.root_part_num,
                                'R') > 0
       ORDER BY 9 DESC;
  BEGIN
    EXECUTE IMMEDIATE 'TRUNCATE TABLE GLB_TEMP_DEAD_STK_NEW';

    SELECT DECODE(FLOOR(TO_CHAR(SYSDATE, 'MM') / 4),
                  0,
                  TO_CHAR(SYSDATE, 'RRRR') - 1,
                  TO_CHAR(SYSDATE, 'RRRR'))
      INTO lv_fin_yr
      FROM DUAL;

    P_AOS_NUM := 'C' || P_CONSG || 'D' ||
                 TO_CHAR(SYSDATE, 'YYYYMMDDHHMISS') || P_TYPE;
    P_ERR_CD  := null;
    P_ERR_MSG := null;

    BEGIN
      SELECT decode(l.dealer_category, 'DDT', 'DI', 'D'),
             l.for_cd,
             l.region_cd, --   region added by Anand on 5-dec-2018
             next_day(l.last_soq_date,
                      substr(am.mul_order_days,
                             instr(am.mul_order_days,
                                   to_char(l.last_soq_date, 'DY')) - 4,
                             3)) - 7 prev_soq_day
        INTO lv_ptype, lv_for_cd, lv_reg_cd, ld_prev_soq_date
        FROM am_dealer_loc l, am_dealer_loc_param am
       WHERE l.parent_group = P_PARENT
         AND l.dealer_map_cd = P_DEALER
         AND l.loc_cd = P_LOC
         AND l.parent_group = am.parent_group
         AND l.dealer_map_cd = am.dealer_map_cd
         AND l.loc_cd = am.loc_cd;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_ERR_CD  := 1;
        P_ERR_MSG := 'Error in Getting Dealer Details';
      WHEN VALUE_ERROR THEN
        P_ERR_CD  := 1;
        P_ERR_MSG := 'Width problem/Incompatible data for fetching the Details';
      WHEN OTHERS THEN
        P_ERR_CD  := 1;
        P_ERR_MSG := 'Execution failed to fetch Details' || SQLERRM;
    END;

    BEGIN
      --SELECT dl.clus_cd   Commented by saket as on 03-05-2023
      SELECT listagg(clus_cd, ',') WITHIN GROUP(ORDER BY dl.clus_cd) --Added by saket as on 03-05-2023
        INTO lv_clus
        FROM pm_po_clus_mpg dl
       WHERE dl.consg_cd = P_CONSG
         AND dl.parent_group = P_PARENT
         AND dl.MAPP_TYPE = 'R'
         AND dl.active_yn = 'Y'
         AND dl.principal_map_cd = P_PRINCIPAL;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        NULL;
      WHEN VALUE_ERROR THEN
        P_ERR_CD  := 1;
        P_ERR_MSG := 'Width problem/Incompatible data for fetching the Details';
      WHEN OTHERS THEN
        P_ERR_CD  := 1;
        P_ERR_MSG := 'Execution failed to fetch Details' || SQLERRM;
    END;

    FOR cur_p IN cur_part LOOP
      lv_pend_co   := 'N';
      ln_pur_price := 0;
      ln_part_val  := 0;
      ln_aos       := 0;
      BEGIN
        SELECT nvl(pv.purchase_price, 0),
               nvl(pv.purchase_price, 0) * cur_p.soq_qty,
               NVL(order_reason_cd, 0),
               NVL(dead_stock_yn, 'N')
          INTO ln_pur_price, ln_part_val, lv_ord_reas, lv_dead_sock
          FROM pm_part_var pv
         WHERE parent_group = P_PARENT
           AND dealer_map_cd = P_DEALER
           AND loc_cd = P_LOC
           AND part_num = cur_p.part_num;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          BEGIN
            SELECT max(nvl(pv.purchase_price, 0)), --max added by arpan -- to avoid the case of multiple rows from sub-query
                   max(nvl(pv.purchase_price, 0) * cur_p.soq_qty),
                   max(NVL(order_reason_cd, 0)),
                   max(NVL(dead_stock_yn, 'N'))
              INTO ln_pur_price, ln_part_val, lv_ord_reas, lv_dead_sock
              FROM pm_part_var pv
             WHERE parent_group = P_PARENT
               AND dealer_map_cd = P_DEALER
               AND loc_cd = P_LOC
               AND part_num IN
                   (SELECT part_num
                      FROM pm_part pm
                     WHERE pm.dealer_map_cd = P_PRINCIPAL
                       AND pm.catg_cd = 'M'
                       AND pm.root_part_num = cur_p.root_part_num
                       AND pm.principal_map_cd = P_PRINCIPAL);
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              ln_pur_price := 0;
              ln_part_val  := 0;
            WHEN VALUE_ERROR THEN
              P_ERR_CD  := 1;
              P_ERR_MSG := 'Width problem/Incompatible data for fetching the Details';
            WHEN OTHERS THEN
              P_ERR_CD  := 1;
              P_ERR_MSG := 'Execution failed to fetch Details' || SQLERRM;
          END;
        WHEN VALUE_ERROR THEN
          P_ERR_CD  := 1;
          P_ERR_MSG := 'Width problem/Incompatible data for fetching the Details';
        WHEN OTHERS THEN
          P_ERR_CD  := 1;
          P_ERR_MSG := 'Execution failed to fetch Details' || SQLERRM;
      END;

      IF P_TYPE = 'N' THEN
        BEGIN
          SELECT tag_cd
            INTO lv_tag_cd
            FROM pm_part
           WHERE dealer_map_cd = P_PRINCIPAL
             AND part_num = cur_p.part_num
             AND principal_map_cd = P_PRINCIPAL;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            P_ERR_CD  := 1;
            P_ERR_MSG := 'Error in Getting Part Details';
          WHEN VALUE_ERROR THEN
            P_ERR_CD  := 1;
            P_ERR_MSG := 'Width problem/Incompatible data for fetching the Details';
          WHEN OTHERS THEN
            P_ERR_CD  := 1;
            P_ERR_MSG := 'Execution failed to fetch Details' || SQLERRM;
        END;

        IF lv_tag_cd = 5 THEN
          BEGIN
            SELECT min(tag_cd)
              INTO lv_tag_cd
              FROM pm_part
             WHERE dealer_map_cd = P_PRINCIPAL
               AND catg_cd = 'M'
               AND root_part_num = cur_p.root_part_num
               --AND tag_cd in (1, 4, 5)
               AND tag_cd in (1, 3, 4) /*Changed by Dp Swain for DP-599*/
               AND principal_map_cd = P_PRINCIPAL;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              P_ERR_CD  := 1;
              P_ERR_MSG := 'Error in Getting Part Details';
            WHEN VALUE_ERROR THEN
              P_ERR_CD  := 1;
              P_ERR_MSG := 'Width problem/Incompatible data for fetching the Details';
            WHEN OTHERS THEN
              P_ERR_CD  := 1;
              P_ERR_MSG := 'Execution failed to fetch Details' || SQLERRM;
          END;
        END IF;
      END IF;
      --  and p_order_reason_cd = 0 and
      IF ((P_TYPE = 'E' AND ln_part_val >= 300) OR
         (P_TYPE = 'N' AND ln_part_val >= 300 AND lv_tag_cd != 5 AND
         lv_ord_reas = 0 AND lv_dead_sock = 'N')) THEN
        BEGIN
          SELECT 'Y'
            INTO lv_pend_co
            FROM pd_po_so h
           WHERE h.picked_yn = 'C'
             AND h.po_date >= ld_prev_soq_date
             AND h.part_num = cur_p.part_num
             AND h.dealer_map_cd = P_DEALER
             AND h.loc_cd = P_LOC
             AND rownum = 1;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            lv_pend_co := 'N';
          WHEN VALUE_ERROR THEN
            P_ERR_CD  := 1;
            P_ERR_MSG := 'Width problem/Incompatible data for fetching the Details';
          WHEN OTHERS THEN
            P_ERR_CD  := 1;
            P_ERR_MSG := 'Execution failed to fetch Details' || SQLERRM;
        END;

        IF nvl(lv_pend_co, 'N') != 'Y' THEN

          FOR cur_d IN cur_ds_dtl(cur_p.part_num, lv_clus, lv_reg_cd) LOOP
            --lv_for_cd changed with lv_reg_cd by Anand on 5-dec-2018
            BEGIN
              SELECT comp_code
                INTO lv_comp
                FROM am_dealer_loc_company_master am
               WHERE am.parent_group = cur_d.parent_group
                 AND am.dealer_map_cd = cur_d.dealer_map_cd
                 AND am.loc_cd = cur_d.loc_cd;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                P_ERR_CD  := 1;
                P_ERR_MSG := 'Error in Getting Dealer Company Details';
              WHEN VALUE_ERROR THEN
                P_ERR_CD  := 1;
                P_ERR_MSG := 'Width problem/Incompatible data for fetching the Details';
              WHEN OTHERS THEN
                P_ERR_CD  := 1;
                P_ERR_MSG := 'Execution failed to fetch Details' || SQLERRM;
            END;

            BEGIN
              SELECT party_cd,
                     party_name,
                     party_address1,
                     party_address2,
                     party_address3,
                     city_cd
                INTO lv_pcode,
                     lv_pname,
                     lv_padd1,
                     lv_padd2,
                     lv_padd3,
                     lv_pcity
                FROM gm_party gm
               WHERE gm.party_type = lv_ptype
                 AND gm.party_cd = P_DEALER || P_LOC
                 AND gm.parent_group = cur_d.parent_group
                 AND gm.dealer_map_cd = cur_d.dealer_map_cd;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                lv_pcode := NULL;
              WHEN VALUE_ERROR THEN
                P_ERR_CD  := 1;
                P_ERR_MSG := 'Width problem/Incompatible data for fetching the Details';
              WHEN OTHERS THEN
                P_ERR_CD  := 1;
                P_ERR_MSG := 'Execution failed to fetch Details' || SQLERRM;
            END;

            BEGIN
              SELECT 'Y'
                INTO lv_cncl_co
                FROM pd_po_so h
               WHERE h.picked_yn = 'C'
                 AND h.po_date >= TRUNC(SYSDATE) - 30
                 AND h.part_num = cur_p.part_num
                 AND h.dealer_map_cd = P_DEALER
                 AND h.loc_cd = P_LOC
                 AND h.so_dealer_map_cd = cur_d.dealer_map_cd
                 AND h.so_loc_cd = cur_d.loc_cd
                 AND rownum = 1;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                lv_cncl_co := 'N';
              WHEN VALUE_ERROR THEN
                P_ERR_CD  := 1;
                P_ERR_MSG := 'Width problem/Incompatible data for fetching the Details';
              WHEN OTHERS THEN
                P_ERR_CD  := 1;
                P_ERR_MSG := 'Execution failed to fetch Details' || SQLERRM;
            END;

            IF lv_pcode IS NOT NULL THEN
              IF lv_cncl_co = 'Y' THEN
                NULL;
              ELSE
                --IF cur_d.cur_stk >= cur_p.soq_qty THEN  Commented by saket as on 05-05-2023
                IF cur_d.cur_stk --Added by saket as on 05-05-2023
                   - FN_GET_PEND_ORDER(P_PARENT    => cur_d.parent_group,
                                       P_DEALER    => cur_d.dealer_map_cd,
                                       P_LOC       => cur_d.loc_cd,
                                       P_COMP      => lv_comp,
                                       P_PART      => cur_d.part_num,
                                       P_ROOT_PART => cur_d.root_part_num) --ordered part
                   >= cur_p.soq_qty THEN
                  ln_aos := 1;
                  BEGIN
                    INSERT INTO GLB_TEMP_DEAD_STK_NEW
                      (part_num,
                       root_part_num,
                       consg_cd,
                       parent_group,
                       dealer_map_cd,
                       loc_cd,
                       comp_fa,
                       ds_consg_cd,
                       ds_parent_group,
                       ds_dealer_map_cd,
                       ds_loc_cd,
                       ds_comp_fa,
                       curr_stock,
                       req_qty,
                       party_type,
                       party_cd,
                       party_name,
                       party_address1,
                       party_address2,
                       party_address3,
                       city_cd,
                       purchase_price,
                       sell_price,
                       Part_Discount)
                    VALUES
                      (cur_d.part_num,
                       cur_d.root_part_num,
                       P_CONSG,
                       P_PARENT,
                       P_DEALER,
                       P_LOC,
                       P_COMP,
                       cur_d.consg_cd,
                       cur_d.parent_group,
                       cur_d.dealer_map_cd,
                       cur_d.loc_cd,
                       lv_comp,
                       cur_d.cur_stk,
                       cur_p.soq_qty,
                       lv_ptype,
                       lv_pcode,
                       lv_pname,
                       lv_padd1,
                       lv_padd2,
                       lv_padd3,
                       lv_pcity,
                       cur_d.purchase_price,
                       cur_d.mrp_1,
                       cur_d.part_discount);
                  EXCEPTION
                    WHEN DUP_VAL_ON_INDEX THEN
                      NULL;
                  END;
                END IF;
              END IF;
            END IF;
          END LOOP;
        END IF;
      END IF;

      IF ln_aos = 1 THEN
        UPDATE pt_soq_mul_til SET AOS_TYPE = 'S' WHERE rowid = cur_p.rowid;
      END IF;

    END LOOP;

    FOR cur_i IN (SELECT DISTINCT consg_cd,
                                  parent_group,
                                  loc_cd,
                                  dealer_map_cd,
                                  comp_fa,
                                  ds_consg_cd,
                                  ds_parent_group,
                                  ds_dealer_map_cd,
                                  ds_loc_cd,
                                  ds_comp_fa,
                                  party_type,
                                  party_cd,
                                  party_name,
                                  city_cd,
                                  party_address1,
                                  party_address2,
                                  party_address3
                    FROM GLB_TEMP_DEAD_STK_NEW
                   WHERE consg_cd != ds_consg_cd
                  --consignee check add against order to same location
                  ) LOOP
      ln_srl        := 0;
      ln_basic_amt  := 0;
      ln_disc_amt   := 0;
      ln_tot_val    := 0;
      lv_gst_num    := null;
      lv_gst_num_ds := null;

      BEGIN
        --Block start added by pooja on 26-JUL-2023
        SELECT am.gst_num
          INTO lv_gst_num
          FROM am_dealer_loc_param am
         WHERE dealer_map_cd = cur_i.dealer_map_cd
           AND parent_group = cur_i.parent_group
           AND loc_cd = cur_i.loc_cd
           AND rownum = 1;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          P_ERR_CD  := 1;
          P_ERR_MSG := 'GST NUM not found' || SQLERRM;
        WHEN VALUE_ERROR THEN
          P_ERR_CD  := 1;
          P_ERR_MSG := 'Width problem/Incompatible data for fetching the Details';
        WHEN OTHERS THEN
          P_ERR_CD  := 1;
          P_ERR_MSG := 'Execution failed to fetch Details' || SQLERRM;
      END;

      BEGIN
        SELECT am.gst_num
          INTO lv_gst_num_ds
          FROM am_dealer_loc_param am
         WHERE dealer_map_cd = cur_i.ds_dealer_map_cd
           AND parent_group = cur_i.ds_parent_group
           AND loc_cd = cur_i.ds_loc_cd
           AND rownum = 1;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          P_ERR_CD  := 1;
          P_ERR_MSG := 'GST NUM not found for DS' || SQLERRM;
        WHEN VALUE_ERROR THEN
          P_ERR_CD  := 1;
          P_ERR_MSG := 'Width problem/Incompatible data for fetching the Details';
        WHEN OTHERS THEN
          P_ERR_CD  := 1;
          P_ERR_MSG := 'Execution failed to fetch Details' || SQLERRM;
      END; ---Block end Pooja

      IF nvl(lv_gst_num, 'GSTUNREGISTERED') = 'GSTUNREGISTERED' or
         nvl(lv_gst_num_ds, 'GSTUNREGISTERED') = 'GSTUNREGISTERED' THEN
        --Added by Pooja on 27-07-2023
        dbms_output.put_line('GSTUNREGISTERED');
        -- RAISE_APPLICATION_ERROR(-20001, 'GSTUNREGISTERED');
        continue;
      END IF;

      BEGIN
        SELECT emp_cd
          INTO lv_sman
          FROM gm_emp
         WHERE dealer_map_cd = cur_i.ds_dealer_map_cd
           AND emp_categ in ('P', 'S')
           AND nvl(emp_leaving_date, SYSDATE) >= SYSDATE
           AND rownum = 1;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          --changes against sales man code null by santosh as on date -02-jul-15
          SELECT emp_cd
            INTO lv_sman
            FROM gm_emp
           WHERE dealer_map_cd = cur_i.ds_dealer_map_cd
             AND emp_categ in ('P', 'S', 'C')
                --AND nvl(emp_leaving_date, sysdate) >= sysdate
             AND rownum = 1;
        WHEN VALUE_ERROR THEN
          P_ERR_CD  := 1;
          P_ERR_MSG := 'Width problem/Incompatible data for fetching the Details';
        WHEN OTHERS THEN
          P_ERR_CD  := 1;
          P_ERR_MSG := 'Execution failed to fetch Details' || SQLERRM;
      END;
      --IF cur_i.parent_group <> cur_i.ds_parent_group THEN --Added by saket as on 05-05-2023 --commented by pooja on 27-07-2023

      IF lv_gst_num <> lv_gst_num_ds THEN
        --Added by pooja on 27-07-2023
        pk_validate_back_date.generate_next_num(cur_i.ds_dealer_map_cd,
                                                P_PRINCIPAL,
                                                cur_i.ds_loc_cd,
                                                cur_i.ds_comp_fa,
                                                'CO',
                                                lv_doc_num,
                                                lv_errmsg,
                                                lv_error,
                                                lv_fin_yr,
                                                trunc(SYSDATE));
        IF lv_error <> 0 THEN
          --P_ERR_CD  := lv_error;
          -- P_ERR_MSG := 'Error... ' || lv_errmsg;
          dbms_output.put_line(lv_errmsg);
          RAISE_APPLICATION_ERROR(-20001, lv_errmsg);
        END IF;

        --ELSE
        --  lv_doc_num := 'CO13004598';

      ELSE
        pk_validate_back_date.generate_next_num(cur_i.dealer_map_cd,
                                                P_PRINCIPAL,
                                                cur_i.loc_cd,
                                                cur_i.comp_fa,
                                                'MTI',
                                                lv_doc_num,
                                                lv_errmsg,
                                                lv_error,
                                                lv_fin_yr,
                                                trunc(sysdate));
        IF lv_error <> 0 THEN
          dbms_output.put_line(lv_errmsg);
          RAISE_APPLICATION_ERROR(-20001, lv_errmsg);
        END IF;
      END IF;
      --Added by saket as on 05-05-2023(end)
      FOR cur_s IN (SELECT *
                      FROM GLB_TEMP_DEAD_STK_NEW
                     WHERE ds_parent_group = cur_i.ds_parent_group
                       AND ds_dealer_map_cd = cur_i.ds_dealer_map_cd
                       AND ds_loc_cd = cur_i.ds_loc_cd
                       AND ds_comp_fa = cur_i.ds_comp_fa) LOOP
        ln_srl       := ln_srl + 1;
        ln_basic_amt := ln_basic_amt +
                        (nvl(cur_s.req_qty, 0) * nvl(cur_s.sell_price, 0));
        --ln_disc_amt  := ln_disc_amt + (nvl(cur_s.req_qty,0) * nvl(cur_s.part_discount,0));
        --ln_tot_val   := ln_tot_val + ((nvl(cur_s.req_qty,0) * nvl(cur_s.sell_price,0)) - (nvl(cur_s.req_qty,0) * nvl(cur_s.part_discount,0)));
        ln_tot_val := ln_tot_val +
                      (nvl(cur_s.req_qty, 0) * nvl(cur_s.sell_price, 0));

        ---Start: added by Nawal for JIRA:DMS-2200
        BEGIN
          lv_fsn_ind := NULL;
          select pv.fsn_ind
            INTO lv_fsn_ind
            FROM pm_part_var pv
           WHERE parent_group = P_PARENT
             AND dealer_map_cd = P_DEALER
             AND loc_cd = P_LOC
             AND part_num = cur_s.part_num;
        EXCEPTION
          WHEN OTHERS THEN
            lv_fsn_ind := NULL;
        END;
        ---End: added by Nawal for JIRA:DMS-2200

        ---exception handle is done against unique key violation as on date -24-mar-15 by santosh
        BEGIN
          --IF cur_i.parent_group <> cur_i.ds_parent_group THEN --Added by saket as on 05-05-2023 --commented by pooja on 27-07-2023
          IF lv_gst_num <> lv_gst_num_ds THEN
            -- added by pooja on 27-07-2023
            INSERT INTO pd_so
              (dealer_map_cd,
               loc_cd,
               so_num,
               comp_fa,
               srl_num,
               part_num,
               so_qty,
               sell_price,
               discount_amt,
               net_amt,
               inv_qty,
               alloc_qty,
               bill_qty,
               kill_qty,
               cancel_yn,
               created_by,
               created_date,
               parent_group)
            VALUES
              (cur_s.ds_dealer_map_cd,
               cur_s.ds_loc_cd,
               lv_doc_num,
               cur_s.ds_comp_fa,
               ln_srl,
               cur_s.part_num,
               cur_s.req_qty,
               cur_s.sell_price,
               --nvl(cur_s.req_qty,0) * nvl(cur_s.part_discount,0),
               0,
               (nvl(cur_s.req_qty, 0) * nvl(cur_s.sell_price, 0)),
               --((nvl(cur_s.req_qty,0) * nvl(cur_s.sell_price,0)) - (nvl(cur_s.req_qty,0) * nvl(cur_s.part_discount,0))),
               0,
               0,
               0,
               cur_s.req_qty,
               'N',
               'MUL',
               SYSDATE,
               cur_s.ds_parent_group);
            --Added by saket as on 05-05-2023(start)
          ELSE
            --Indent creation

            insert into pd_indent
              (dealer_map_cd,
               loc_cd,
               indent_qty,
               part_num,
               sti_srl,
               landed_cost,
               received_qty,
               created_by,
               created_date,
               issued_qty,
               indent_num,
               parent_group,
               comp_fa,
               purchase_price)
            values
              (cur_s.dealer_map_cd, --changed by pooja
               cur_s.loc_cd, --changed to loc_cd by pooja
               cur_s.req_qty,
               cur_s.part_num,
               ln_srl,
               cur_s.purchase_price, --sell price change to purchase by pooja
               cur_s.req_qty,
               'ADMIN',
               sysdate,
               null,
               lv_doc_num,
               cur_s.ds_parent_group,
               cur_s.ds_comp_fa,
               cur_s.sell_price);

          END IF;
          --Added by saket as on 05-05-2023(end)
        EXCEPTION
          WHEN DUP_VAL_ON_INDEX THEN
            dbms_output.put_line('Duplicate value insertion in customer order dtl' ||
                                 cur_s.ds_loc_cd || '-' || lv_doc_num || '-' ||
                                 cur_s.ds_parent_group || '-' || ln_srl);
          when others then
            dbms_output.put_line('Error in value insertion in customer order dtl' ||
                                 cur_s.ds_loc_cd || '-' || lv_doc_num || '-' ||
                                 cur_s.ds_parent_group || '-' || ln_srl || '-' ||
                                 SQLCODE);
        END;
        BEGIN
          INSERT INTO PD_PO_SO
            (aos_num,
             consg_cd,
             parent_group,
             dealer_map_cd,
             loc_cd,
             comp_fa,
             part_num,
             srl_num,
             root_part_num,
             req_qty,
             so_consg_cd,
             so_parent_group,
             so_dealer_map_cd,
             so_loc_cd,
             so_comp_fa,
             so_num,
             so_date,
             sell_price,
             picked_yn,
             created_by,
             created_date,
             BUYER_STOCK_QTY, ---added by Nawal for JIRA: DMS-2109
             Seller_stock_qty, ---added by Nawal for JIRA: DMS-2109
             Fsn_ind ---added by Nawal for JIRA:DMS-2200
             )
          VALUES
            (p_aos_num,
             cur_s.consg_cd,
             cur_s.parent_group,
             cur_s.dealer_map_cd,
             cur_s.loc_cd,
             cur_s.comp_fa,
             cur_s.part_num,
             ln_srl,
             cur_s.root_part_num,
             cur_s.req_qty,
             cur_s.ds_consg_cd,
             cur_s.ds_parent_group,
             cur_s.ds_dealer_map_cd,
             cur_s.ds_loc_cd,
             cur_s.ds_comp_fa,
             lv_doc_num,
             trunc(SYSDATE),
             cur_s.sell_price,
             'N',
             'MUL',
             sysdate,
             GET_PART_NET_STOCK(cur_s.dealer_map_cd,
                                cur_s.loc_cd,
                                cur_s.root_part_num,
                                'R'), ---added by Nawal for JIRA: DMS-2109
             GET_PART_NET_STOCK(cur_s.ds_dealer_map_cd,
                                cur_s.ds_loc_cd,
                                cur_s.root_part_num,
                                'R'), ---added by Nawal for JIRA: DMS-2109

             lv_fsn_ind ---added by Nawal for JIRA:DMS-2200
             );
        EXCEPTION
          when others then
            dbms_output.put_line('Error in value insertion in customer purchase order dtl' ||
                                 cur_s.ds_loc_cd || '-' || lv_doc_num || '-' ||
                                 cur_s.ds_parent_group || '-' || ln_srl || '-' ||
                                 SQLCODE);
        END;
      END LOOP;
      IF ln_srl > 0 THEN
        BEGIN
          INSERT INTO PH_PO_SO
            (aos_num,
             consg_cd,
             parent_group,
             dealer_map_cd,
             loc_cd,
             comp_fa,
             so_consg_cd,
             so_parent_group,
             so_dealer_map_cd,
             so_loc_cd,
             so_comp_fa,
             so_num,
             so_date,
             created_by,
             created_date)
          VALUES
            (p_aos_num,
             cur_i.consg_cd,
             cur_i.parent_group,
             cur_i.dealer_map_cd,
             cur_i.loc_cd,
             cur_i.comp_fa,
             cur_i.ds_consg_cd,
             cur_i.ds_parent_group,
             cur_i.ds_dealer_map_cd,
             cur_i.ds_loc_cd,
             cur_i.ds_comp_fa,
             lv_doc_num,
             trunc(SYSDATE),
             'MUL',
             sysdate);
        EXCEPTION
          WHEN OTHERS THEN
            dbms_output.put_line('Error in value insertion in customer purhcase order header' ||
                                 cur_i.ds_loc_cd || '-' || lv_doc_num || '-' ||
                                 cur_i.ds_parent_group || '-' || ln_srl || '-' ||
                                 SQLCODE);
        END;
        BEGIN
          -- IF cur_i.parent_group <> cur_i.ds_parent_group THEN --Added by saket as on 05-05-2023 --commented by pooja on 27-07-2023
          IF lv_gst_num <> lv_gst_num_ds THEN
            INSERT INTO ph_so
              (dealer_map_cd,
               loc_cd,
               so_num,
               comp_fa,
               so_date,
               party_type,
               party_cd,
               basic_amt,
               --discount_amt,
               total_value,
               sale_man_cd,
               created_by,
               created_date,
               parent_group,
               party_name,
               party_address1,
               party_address2,
               party_address3,
               city_cd,
               remarks,
               asc_ord_yn)
            VALUES
              (cur_i.ds_dealer_map_cd,
               cur_i.ds_loc_cd,
               lv_doc_num,
               cur_i.ds_comp_fa,
               trunc(SYSDATE),
               cur_i.party_type,
               cur_i.party_cd,
               ln_basic_amt,
               --ln_disc_amt,
               ln_tot_val,
               lv_sman,
               'MUL',
               SYSDATE,
               cur_i.ds_parent_group,
               cur_i.party_name,
               cur_i.party_address1,
               cur_i.party_address2,
               cur_i.party_address3,
               cur_i.city_cd,
               'Auto Gen Against PO',
               'Y');
            --Added by saket as on 05-05-2023(start)
          ELSE
            --Indent creation
            insert into ph_indent
              (dealer_map_cd,
               loc_cd,
               indent_num,
               indent_date,
               indent_to,
               requested_by,
               remarks,
               created_date,
               created_by,
               so_num,
               parent_group,
               comp_fa,
               indent_status,
               to_dealer,
               indent_type)
            values
              (cur_i.dealer_map_cd,
               cur_i.loc_cd,
               lv_doc_num,
               sysdate,
               cur_i.ds_loc_cd,
               null,
               null,
               sysdate,
               'ADMIN',
               null,
               cur_i.parent_group,
               cur_i.comp_fa,
               'R',
               cur_i.ds_dealer_map_cd,
               'M');

          END IF;
          --Added by saket as on 05-05-2023(end)
        EXCEPTION
          WHEN DUP_VAL_ON_INDEX THEN
            dbms_output.put_line('Duplicate value insertion in customer order header' ||
                                 cur_i.ds_loc_cd || '-' || lv_doc_num || '-' ||
                                 cur_i.ds_parent_group || '-' || ln_srl);
          when others then
            dbms_output.put_line('Error in value insertion in customer order header' ||
                                 cur_i.ds_loc_cd || '-' || lv_doc_num || '-' ||
                                 cur_i.ds_parent_group || '-' || ln_srl || '-' ||
                                 SQLCODE);
        END;
      END IF;
      --END IF;
    END LOOP;
  END;
```

#### SP-030 - PK_VALIDATE_PARTS.UPDATE_ON_ORDER

**Invoked From:**

- pt_soq_ims_fmb.xml [ProgramUnit: UPDATE_PO_STOCK]
- pt_soq_ims_fmb.xml [StoredProcedure: UPDATE_PO_STOCK]

---

**Screen:**

PART AND STOCK DETAILS (N/A / CN_SOQ)

---

**Purpose**

Updates the on-order quantity in PM_PART_VAR for each part supplied in a part-order collection. For every part, the procedure first ensures a PM_PART_VAR record exists (creating one via SP_INSERT_PM_PART_VAR if absent), then either increments or decrements the on-order quantity depending on whether the purchase-order action is a receipt ('R') or a cancellation ('C'). It is invoked from the PART AND STOCK DETAILS screen (CN_SOQ) during purchase-order stock processing.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_parent | VARCHAR2 | IN |
| p_dealer | NUMBER | IN |
| p_loc_cd | VARCHAR2 | IN |
| p_part_ordtab | part_order_type | IN |
| p_po_flag | VARCHAR2 | IN |
| p_created_by | VARCHAR2 | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_error_code | NUMBER | OUT |
| p_error_msg | VARCHAR2 | OUT |

---

**Dependencies**

- SP_INSERT_PM_PART_VAR ([SP-033](#SP-033--SP_INSERT_PM_PART_VAR)) - standalone source file

---

**Step-by-Step Business Logic**

- Step 1 - Iterate over every element in the input collection p_part_ordtab (index 1 to LAST).
- Step 2 - For the current part, attempt to lock the matching PM_PART_VAR row (keyed on parent_group, dealer_map_cd, loc_cd, and part_num) using SELECT ... FOR UPDATE OF on_order_qty NOWAIT.
- Step 3 - If no matching PM_PART_VAR row exists (NO_DATA_FOUND), call SP_INSERT_PM_PART_VAR to create the missing record, passing the parent group, dealer, location, part number, and created-by user. Capture the returned error code and message.
- Step 4 - If SP_INSERT_PM_PART_VAR returns an error code of 1, exit the loop immediately and surface the error to the caller.
- Step 5 - If a VALUE_ERROR exception is raised during the lock attempt, set p_error_code = 1 with a descriptive message indicating a width/incompatibility problem for the part, then exit the loop.
- Step 6 - If any other exception is raised during the lock attempt, set p_error_code = 1 with the SQLERRM message for the part, then exit the loop.
- Step 7 - After a successful lock (or successful insert), evaluate p_po_flag.
- Step 8 - If p_po_flag = 'R' (receipt), update PM_PART_VAR by adding the ordered quantity (p_qty) to the existing on_order_qty (treating NULL as 0) for the current part/dealer/location/parent combination.
- Step 9 - If p_po_flag = 'C' (cancellation), update PM_PART_VAR by subtracting the net outstanding quantity (p_qty minus r_qty, both NULL-safe) from the existing on_order_qty for the current part/dealer/location/parent combination.
- Step 10 - If either UPDATE statement raises an exception, set p_error_code = 1 with SQLERRM and exit the loop.
- Step 11 - On successful completion of all iterations without error, p_error_code and p_error_msg remain at their default (unset) values, indicating success.

---
**Decision Points**

DP-001

Condition:
Does a PM_PART_VAR row exist for the combination of parent_group, dealer_map_cd, loc_cd, and part_num?

TRUE:
The row is locked FOR UPDATE OF on_order_qty NOWAIT and processing continues to the p_po_flag evaluation.

FALSE (NO_DATA_FOUND):
SP_INSERT_PM_PART_VAR is called to create the missing PM_PART_VAR record before continuing.

---

DP-002

Condition:
Did SP_INSERT_PM_PART_VAR return p_error_code = 1?

TRUE:
The loop exits immediately; the error code and message from SP_INSERT_PM_PART_VAR are returned to the caller.

FALSE:
Processing continues to the p_po_flag evaluation for the current part.

---

DP-003

Condition:
Is p_po_flag = 'R' (receipt)?

TRUE:
PM_PART_VAR.on_order_qty is incremented by p_part_ordtab(i).p_qty for the current part.

FALSE:
The procedure evaluates whether p_po_flag = 'C'.

---

DP-004

Condition:
Is p_po_flag = 'C' (cancellation)?

TRUE:
PM_PART_VAR.on_order_qty is decremented by (p_qty - r_qty) for the current part, reflecting the net quantity that will no longer be received.

FALSE:
Neither UPDATE is executed for this iteration; the loop advances to the next part.

---

DP-005

Condition:
Does a VALUE_ERROR exception occur while attempting to lock the PM_PART_VAR row?

TRUE:
p_error_code is set to 1, a width/incompatibility message identifying the part is written to p_error_msg, and the loop exits.

FALSE:
Processing continues normally.

---

DP-006

Condition:
Does an unhandled (OTHERS) exception occur during the lock attempt or during either UPDATE statement?

TRUE:
p_error_code is set to 1, SQLERRM is written to p_error_msg, and the loop exits.

FALSE:
Processing continues normally.

---
**Database Interactions**

- DB-001 - Read PM_PART_VAR - Reads data from PM_PART_VAR (columns: on order qty) for lookup or validation.
- DB-002 - Update OF - Updates existing rows in OF.
- DB-003 - Update PM_PART_VAR - Updates existing rows in PM_PART_VAR (columns: on order qty).
**Business Rules**

- BR-001 - Every part in the input collection must have a corresponding PM_PART_VAR record before its on-order quantity can be updated; if the record is absent it must be created via SP_INSERT_PM_PART_VAR before the update proceeds.
- BR-002 - The PM_PART_VAR row must be locked (FOR UPDATE NOWAIT) prior to any quantity update to prevent concurrent modification of the on-order quantity.
- BR-003 - A NULL on_order_qty in PM_PART_VAR is treated as zero for all arithmetic operations (NVL applied to both the existing column value and the input quantities).
- BR-004 - When p_po_flag = 'R' (receipt), the on-order quantity is increased by the full ordered quantity (p_qty), reflecting that additional stock has been placed on order.
- BR-005 - When p_po_flag = 'C' (cancellation), the on-order quantity is reduced by the net unfulfilled quantity (p_qty minus r_qty), reflecting the portion of the order that will not be received.
- BR-006 - A data-width or type-incompatibility error (VALUE_ERROR) during the lock query is treated as a hard failure: processing halts for all remaining parts and a descriptive error identifying the offending part is returned.
- BR-007 - Any unhandled exception during row locking or quantity update terminates the entire batch immediately; no partial updates are silently ignored.
- BR-008 - The procedure operates within the caller's transaction; it does not issue an autonomous commit, allowing the caller (UPDATE_PO_STOCK) to control the final commit or rollback.

---
**Implementation Logic**

```plsql
  PROCEDURE update_on_order(p_parent      IN VARCHAR2,
                            p_dealer      IN NUMBER,
                            p_loc_cd      IN VARCHAR2,
                            p_part_ordtab part_order_type,
                            p_po_flag     IN VARCHAR2,
                            p_created_by  IN VARCHAR2,
                            p_error_code  OUT NUMBER,
                            p_error_msg   OUT VARCHAR2) IS
    lv_part    PM_PART.part_num%TYPE;
    lv_err_msg VARCHAR2(2000); -- Added by sanjeev for sp_insert_pm_part_var
    lv_err_cd  NUMBER := 0; -- Added by sanjeev for sp_insert_pm_part_var
  BEGIN
    FOR i IN 1 .. p_part_ordtab.LAST LOOP
      BEGIN
        SELECT part_num
          INTO lv_part
          FROM PM_PART_VAR
         WHERE parent_group = p_parent
           AND dealer_map_cd = p_dealer
           AND loc_cd = p_loc_cd
           AND part_num = p_part_ordtab(i).p_part
           FOR UPDATE OF on_order_qty NOWAIT;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          Sp_Insert_Pm_Part_Var(p_parent,
                                p_dealer,
                                p_loc_cd,
                                p_part_ordtab(i).p_part,
                                p_created_by,
                                lv_err_msg,
                                lv_err_cd);
          p_error_code := lv_err_cd;
          p_error_msg  := lv_err_msg;

          IF p_error_code = 1 THEN
            -- If there is an error
            EXIT;
          END IF;
        WHEN VALUE_ERROR THEN
          p_error_code := 1;
          p_error_msg  := 'Width problem/Incompatible data while updating on order quantity for part : ' || p_part_ordtab(i)
                         .p_part;
          EXIT;
        WHEN OTHERS THEN
          p_error_code := 1;
          p_error_msg  := 'Execution failed while updating on order quantity for part : ' || p_part_ordtab(i)
                         .p_part || ' : ' || SQLERRM;
          EXIT;
      END;

      IF p_po_flag = 'R' THEN
        BEGIN
          UPDATE PM_PART_VAR
             SET on_order_qty = NVL(on_order_qty, 0) + p_part_ordtab(i)
                               .p_qty
           WHERE parent_group = p_parent
             AND dealer_map_cd = p_dealer
             AND loc_cd = p_loc_cd
             AND part_num = p_part_ordtab(i).p_part;
        EXCEPTION
          WHEN OTHERS THEN
            p_error_code := 1;
            p_error_msg  := SQLERRM;
            EXIT;
        END;
      ELSIF p_po_flag = 'C' THEN
        BEGIN
          UPDATE PM_PART_VAR
             SET on_order_qty = NVL(on_order_qty, 0) -
                                (NVL(p_part_ordtab(i).p_qty, 0) -
                                 NVL(p_part_ordtab(i).r_qty, 0))
           WHERE parent_group = p_parent
             AND dealer_map_cd = p_dealer
             AND loc_cd = p_loc_cd
             AND part_num = p_part_ordtab(i).p_part;
        EXCEPTION
          WHEN OTHERS THEN
            p_error_code := 1;
            p_error_msg  := SQLERRM;
            EXIT;
        END;
      END IF;
    END LOOP;
  END;
```

#### SP-031 - SF_COPYRIGHT_DECLARATION

**Invoked From:**

- pt_soq_ims_fmb.xml [Trigger: KEY-CLRFRM]
- pt_soq_ims_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

N/A

---

**Purpose**

Returns a formatted copyright string displaying the current financial year and the company name 'Maruti Suzuki India Limited'. Because the Indian financial year runs April-March, the function adjusts the displayed year so that January, February, and March show the prior calendar year, ensuring the copyright year always reflects the active financial year. The result is used during form initialisation and form-clear events in pt_soq_ims_fmb.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Capture the current system date into a local date variable using SYSDATE.
- Step 2 - Evaluate the month portion of the current date to determine the correct financial year.
- Step 3 - If the current month is January, February, or March (i.e., the first quarter of the calendar year but the last quarter of the Indian financial year), derive the financial year as the current calendar year minus one.
- Step 4 - If the current month is any other month (April through December), use the current calendar year as the financial year.
- Step 5 - Assemble and return the copyright string in the format '- <YYYY> Maruti Suzuki India Limited '.

---
**Decision Points**

DP-001

Condition:
The three-character month abbreviation of the current system date (SYSDATE) is one of 'JAN', 'FEB', or 'MAR'.

TRUE:
The financial year is calculated as the current calendar year minus one (RRRR - 1), and the copyright string is built using that prior year value.

FALSE:
The current calendar year (RRRR) is used directly to build the copyright string.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The copyright year must reflect the Indian financial year (April-March), not the calendar year; months January, February, and March belong to the financial year that started in the previous calendar year.
- BR-002 - The returned string must follow the exact format '- <YYYY> Maruti Suzuki India Limited ' (leading hyphen, four-digit year, company name, trailing space) to ensure consistent display across all invoking form triggers.
- BR-003 - The company name embedded in the copyright string is fixed as 'Maruti Suzuki India Limited' and must not be derived from any configurable source or parameter.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
function sf_copyright_declaration return varchar is
a varchar2(50);
dt date;
begin
--Modified by Prerna on 16-May-11  to display current Financial Year Copyright
dt := sysdate;

    if( to_char(dt,'MON') in ('JAN','FEB','MAR')) then
        a := '- '||to_char(to_number(to_char(dt,'RRRR')) - 1)||' Maruti Suzuki India Limited ';
    else
        a := '- '||to_char(dt,'RRRR')||' Maruti Suzuki India Limited ';
    end if;
return(a);
end;

```

#### SP-032 - SP_CALCULATE_SOQ_IMS

**Invoked From:**

- pt_soq_ims_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

SUGGESTED ORDER QUANTITY PROCESSING (N/A / CN_MAIN)

---

**Purpose**

SP_CALCULATE_SOQ_IMS computes and persists the Suggested Order Quantity (SOQ) for parts within the Inventory Management System (IMS) for a given dealer, location, principal, and part category. It clears any prior SOQ working data, rebuilds part-level SOQ staging records from current stock, consumption, and customer back-order (CBO) data, applies price-band-based CBO truncation rules, calculates the final SOQ quantity using transaction-frequency and low-inventory-flag logic, rounds the result to the minimum order quantity multiple, and writes the consolidated output to the multi-till SOQ table for downstream order processing.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| pi_principal | NUMBER | IN |
| pi_dealer | NUMBER | IN |
| pi_parent | VARCHAR2 | IN |
| pi_loc_cd | VARCHAR2 | IN |
| pi_comp_fa | VARCHAR2 | IN |
| pi_user | VARCHAR2 | IN |
| pi_ason_dt | DATE | IN |
| pi_consg_cd | am_dealer_loc.consg_cd%TYPE | IN |
| pi_months | NUMBER | IN |
| pi_consump_type | VARCHAR2 | IN |
| pi_part_categ | VARCHAR2 | IN |
| pi_rundt | DATE | IN |
| pi_datadt | DATE | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| po_errmsg | VARCHAR2 | OUT |
| po_errcd | NUMBER | OUT |

---

**Dependencies**

- D2KWUTIL.CREATED_DATE ([SP-012](#SP-012--D2KWUTIL.CREATED_DATE)) - D2KWUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Initialise output error code to 0 and retrieve the low-inventory flag (low_inventory_yn) for the dealer/location from AM_DEALER_LOC_PARAM; default to 'N' if no record is found.
- Step 2 - Delete existing SOQ staging rows from PT_SOQ_NEW for the given parent group, location, and part category to ensure a clean recalculation.
- Step 3 - Delete existing multi-till SOQ rows from PT_SOQ_MUL_TIL for the given dealer, parent group, location, and part category.
- Step 4 - Populate the global staging table GBL_AOS_PART_DTL_NEW1 by joining PM_PART_DTL_NEW, AM_DEALER_LOC, PM_PART_VAR, and PM_PART; compute on-hand quantity (net of quarantine) via GET_PART_STOCK_RPN, out-of-order quantity via GET_DMS_OOQ, and customer back-order quantity via GET_CBO for each root part number matching the input principal, dealer, location, consignment code, and part category.
- Step 5 - Loop over GBL_AOS_PART_DTL_NEW1 and resolve the part family age from PM_PART_VAR (order reason code for the latest part number, or the minimum order reason code across all parts sharing the same root part number; default 1 if neither is found). Insert one row per part into PT_SOQ_NEW with SOQ quantity initialised to 0; duplicate key violations are silently ignored.
- Step 6 - For parts that have a positive CBO but no record in PM_PART_DTL_NEW (i.e., non-transacted parts with outstanding customer back orders), insert additional rows into PT_SOQ_NEW using the latest non-VOR part number resolved from MULDMS.PM_PART; only parts where GET_CBO returns a value greater than 0 are included. Duplicate key violations are silently ignored.
- Step 7 - Apply CBO truncation (v_1 logic): for each row in PT_SOQ_NEW (via cursor CR_SOQ_NEW), compare the actual CBO (GET_CBO with flag 'A') against the weighted average consumption. If the actual CBO exceeds the weighted average consumption, cap the CBO based on purchase price bands: parts priced below 100 are capped at the greater of 50 or twice the weighted average consumption; parts priced 100-4999 are capped at the greater of 20 or twice the weighted average consumption; parts priced 5000 or above are capped at the greater of 5 or twice the weighted average consumption. Update both PT_SOQ_NEW (cust_order_qty, old_cbo) and PM_PART_DTL_NEW (cust_order_qty, old_cbo) with the modified CBO value.
- Step 8 - Calculate the SOQ quantity for each part row using the low-inventory flag to select the appropriate formula branch:
  • If low_inventory_yn = 'N': apply standard SOQ logic based on transaction count (tran_cnt_6_mnt) and purchase price × minimum order quantity thresholds.
  • If low_inventory_yn = 'Y': apply enhanced SOQ logic that additionally considers average consumption thresholds (> 2, 0-1, 1-2) and order cycle constraints before falling back to the standard transaction-count branches.
  In both branches, if purchase price is 0, SOQ = CBO - on-hand - on-order. Update PT_SOQ_NEW.soq_qty with the computed value.
- Step 9 - Aggregate per-location SOQ rows into consolidated multi-till records using cursor CR_SOQ_MUL (summing quantities across locations). Round the aggregated SOQ up to the nearest minimum order quantity multiple; set to 0 if the result is negative or zero. Insert the consolidated record into PT_SOQ_MUL_TIL.
- Step 10 - Commit the transaction on successful completion. Roll back and set po_errcd = 1 with a descriptive message in po_errmsg on any unhandled exception.

---
**Decision Points**

DP-001
Condition: Record found in AM_DEALER_LOC_PARAM for the given parent group, dealer, and location.
TRUE: low_inventory_yn is set to the retrieved value (NVL-defaulted to 'N').
FALSE: low_inventory_yn defaults to 'N' via the WHEN OTHERS exception handler.

DP-002
Condition: A root part number from CR_CUST_BO has no matching row in PM_PART_DTL_NEW (bo_cnt = 0) AND GET_CBO returns a value greater than 0.
TRUE: A new SOQ row is inserted into PT_SOQ_NEW for the part using the latest non-VOR part number from MULDMS.PM_PART, with CBO as the customer order quantity and SOQ initialised to 0.
FALSE: No additional row is inserted for that root part number.

DP-003
Condition: GET_CBO (flag 'A') for the part exceeds the weighted average consumption (avg_consumption_wt).
TRUE: CBO truncation is evaluated against purchase price bands (DP-004, DP-005, DP-006).
FALSE: The original CBO value is retained without truncation.

DP-004
Condition: Purchase price < 100 AND CBO > 50 AND CBO > (2 × avg_consumption_wt).
TRUE: Modified CBO = GREATEST(50, 2 × avg_consumption_wt).
FALSE: Evaluate next price band (DP-005).

DP-005
Condition: Purchase price >= 100 AND purchase price < 5000 AND CBO > 20 AND CBO > (2 × avg_consumption_wt).
TRUE: Modified CBO = GREATEST(20, 2 × avg_consumption_wt).
FALSE: Evaluate next price band (DP-006).

DP-006
Condition: Purchase price >= 5000 AND CBO > 5 AND CBO > (2 × avg_consumption_wt).
TRUE: Modified CBO = GREATEST(5, 2 × avg_consumption_wt).
FALSE: CBO remains unchanged.

DP-007
Condition: low_inventory_yn = 'N'.
TRUE: Standard SOQ calculation branch is used (transaction count and price × min order qty thresholds only).
FALSE: Enhanced SOQ calculation branch is used (additionally considers avg_consumption > 2 and order cycle thresholds).

DP-008
Condition: purchase_price = 0 (within either SOQ calculation branch).
TRUE: SOQ = CBO - on_hand_qty - on_order_qty.
FALSE: SOQ is determined by transaction count and price-based sub-conditions.

DP-009
Condition: tran_cnt_6_mnt > 4 (high-frequency transaction part).
TRUE: If safety stock exceeds (on_hand + on_order - CBO), SOQ = max_stock - (on_hand + on_order - CBO); otherwise SOQ = 0.
FALSE: Evaluate low-frequency transaction sub-conditions (DP-010, DP-011).

DP-010
Condition: tran_cnt_6_mnt <= 4 AND ROUND(purchase_price × min_ord_qty) <= 100.
TRUE: SOQ is determined by stock position: if on_hand > 0 and on_order = 0 and CBO = 0 -> SOQ = 0; if all three are 0 -> SOQ = 0; if CBO - (on_order + on_hand) > 0 -> SOQ = CBO - (on_order + on_hand) [+1 if tran_cnt_6_mnt ≠ -1].
FALSE: Evaluate DP-011.

DP-011
Condition: tran_cnt_6_mnt <= 4 AND ROUND(purchase_price × min_ord_qty) > 100.
TRUE: If CBO - (on_order + on_hand) > 0, SOQ = CBO - (on_order + on_hand); otherwise SOQ = 0.
FALSE: SOQ remains 0.

DP-012
Condition: tran_cnt_6_mnt = -1 (part inserted via back-order path with no transaction history).
TRUE: SOQ = CBO - (on_order + on_hand) [no +1 adjustment].
FALSE: SOQ = (CBO + 1) - (on_order + on_hand).

DP-013
Condition: (aggregated SOQ from CR_SOQ_MUL) MOD min_ord_qty ≠ 0.
TRUE: SOQ is rounded up to the next multiple of min_ord_qty using CEIL(SOQ / min_ord_qty) × min_ord_qty.
FALSE: SOQ is used as-is.

DP-014
Condition: Rounded SOQ <= 0.
TRUE: SOQ is set to 0 before inserting into PT_SOQ_MUL_TIL.
FALSE: The positive rounded SOQ value is inserted.

---
**Database Interactions**

- DB-001 - Read PT_SOQ_NEW - Reads data from PT_SOQ_NEW (columns: dealer map cd, part class, part num, as on date, no of months, soq qty, on hand qty, on order qty, and 30 more column(s)) for lookup or validation.
- DB-002 - Read AM_DEALER_LOC_PARAM - Reads data from AM_DEALER_LOC_PARAM for lookup or validation.
- DB-003 - Delete from PT_SOQ_NEW - Deletes rows from PT_SOQ_NEW.
- DB-004 - Delete from PT_SOQ_MUL_TIL - Deletes rows from PT_SOQ_MUL_TIL.
- DB-005 - Read PM_PART_VAR - Reads data from PM_PART_VAR for lookup or validation.
- DB-006 - Read PM_PART - Reads data from PM_PART for lookup or validation.
- DB-007 - Read PM_STOCK_BIN_LOC - Reads data from PM_STOCK_BIN_LOC for lookup or validation.
- DB-008 - Insert into PT_SOQ_NEW - Persists a new row into PT_SOQ_NEW using columns: dealer map cd, part class, part num, as on date, no of months, soq qty, on hand qty, on order qty, and 30 more column(s).
- DB-009 - Insert into GBL_AOS_PART_DTL_NEW1 - Persists a new row into GBL_AOS_PART_DTL_NEW1.
- DB-010 - Read PM_PART_DTL_NEW - Reads data from PM_PART_DTL_NEW (columns: cust order qty, old cbo) for lookup or validation.
- DB-011 - Read AM_DEALER_LOC - Reads data from AM_DEALER_LOC for lookup or validation.
- DB-012 - Insert into AOS_LATEST_PART_MISMATCH - Persists a new row into AOS_LATEST_PART_MISMATCH using columns: entry source, parent group, dealer map cd, loc cd, root part number, part num, latest part num, created date, and 1 more column(s).
- DB-013 - Read MULDMS.PM_PART - Reads data from MULDMS.PM_PART for lookup or validation.
- DB-014 - Update PT_SOQ_NEW - Updates existing rows in PT_SOQ_NEW (columns: dealer map cd, part class, part num, as on date, no of months, soq qty, on hand qty, on order qty, and 30 more column(s)).
- DB-015 - Update PM_PART_DTL_NEW - Updates existing rows in PM_PART_DTL_NEW (columns: cust order qty, old cbo).
- DB-016 - Insert into PT_SOQ_MUL_TIL - Persists a new row into PT_SOQ_MUL_TIL using columns: dealer map cd, part num, as on date, no of months, soq qty, on hand qty, on order qty, safety stock, and 15 more column(s).
**Business Rules**

- BR-001 - Prior SOQ data must be purged before recalculation: all existing rows in PT_SOQ_NEW and PT_SOQ_MUL_TIL matching the input parent group, dealer, location, and part category are deleted at the start of each run.
- BR-002 - Only parts belonging to the specified part category (pi_part_categ) and principal (pi_principal) are included in the SOQ calculation; the principal map code must also match pi_principal to support multi-company operations.
- BR-003 - On-hand quantity used in calculations is the gross stock quantity net of quarantine quantity, as retrieved by GET_PART_STOCK_RPN.
- BR-004 - Parts not present in PM_PART_DTL_NEW but with a positive customer back-order quantity (GET_CBO > 0) must still receive an SOQ row in PT_SOQ_NEW; the latest non-VOR part number is resolved from MULDMS.PM_PART using the highest sequence number with tag_cd IN (1, 3, 4) and vor_yn = 'N'.
- BR-005 - CBO values are subject to truncation based on purchase price bands to prevent over-ordering: the cap is 50 for parts priced below 100, 20 for parts priced 100-4999, and 5 for parts priced 5000 or above; truncation applies only when the actual CBO exceeds the weighted average consumption.
- BR-006 - Both PT_SOQ_NEW.cust_order_qty and PM_PART_DTL_NEW.cust_order_qty must be synchronised with the truncated CBO value; the original pre-truncation CBO is preserved in the old_cbo column of both tables.
- BR-007 - The low-inventory flag (low_inventory_yn) from AM_DEALER_LOC_PARAM governs the SOQ formula branch: locations flagged 'Y' apply an enhanced formula that factors in average consumption levels and order cycle in addition to transaction frequency and price thresholds.
- BR-008 - Parts with a purchase price of 0 always use the simplified formula SOQ = CBO - on_hand - on_order, regardless of transaction count or low-inventory flag.
- BR-009 - For low-frequency parts (tran_cnt_6_mnt <= 4) with a low unit value (ROUND(purchase_price × min_ord_qty) <= 100), a +1 buffer is added to the CBO when computing SOQ, except for parts inserted via the back-order path (tran_cnt_6_mnt = -1), which receive no buffer.
- BR-010 - SOQ quantity must never be negative; any computed value less than or equal to 0 is stored as 0.
- BR-011 - The final SOQ quantity inserted into PT_SOQ_MUL_TIL must be a multiple of the minimum order quantity (min_ord_qty); quantities that are not exact multiples are rounded up to the next valid multiple.
- BR-012 - Duplicate key violations during insertion into PT_SOQ_NEW are silently ignored to allow partial re-population without aborting the entire run; all other exceptions during SOQ quantity calculation or multi-till insertion raise the ex_error exception, triggering a full rollback.
- BR-013 - The entire SOQ calculation is atomic: a COMMIT is issued only on full successful completion; any raised ex_error exception causes a ROLLBACK and sets po_errcd = 1 with a descriptive message in po_errmsg.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
PROCEDURE Sp_Calculate_Soq_Ims
/*
  $Log: SP_CALCULATE_SOQ_NEW.SQL,v $
  */
  /***********************************************************************************************************************************************
  * Created/Modified By    Date        Change Indicator   SCR#              Description
  * Ravi                  03-05-17      v_1              DMSSPR-13139      cbo truncation

  ************************************************************************************************************************************************/

(pi_principal    IN NUMBER,
 pi_dealer       IN NUMBER,
 pi_parent       IN VARCHAR2,
 pi_loc_cd       IN VARCHAR2,
 pi_comp_fa      IN VARCHAR2,
 pi_user         IN VARCHAR2,
 pi_ason_dt      IN DATE,
 pi_consg_cd     IN am_dealer_loc.consg_cd%TYPE,
 pi_months       IN NUMBER,
 pi_consump_type IN VARCHAR2,
 pi_part_categ   IN VARCHAR2,
 po_errmsg       OUT VARCHAR2,
 po_errcd        OUT NUMBER,
 pi_rundt        IN DATE,
 pi_datadt       IN DATE) AS
  CURSOR CR_SOQ_NEW(p_consg_cd VARCHAR2,
                    p_parent   VARCHAR2,
                    p_dealer   NUMBER,
                    p_loc      VARCHAR2) IS
    SELECT pt.ROWID,
           pt.dealer_map_cd,
           part_num,
           soq_qty,
           on_hand_qty,
           on_order_qty,
           safety_stock,
           min_stock,
           max_stock,
           cust_order_qty,
           part_desc,
           pt.parent_group,
           pt.loc_cd,
           inv_qty,
           gen_loc,
           comp_fa,
           avg_consumption,
           avg_consumption_wt,
           stock_qty,
           min_ord_qty,
           root_part_num,
           part_family_age,
           purchase_price,
           tran_cnt_6_mnt,
           pt.order_cycle, -- Added by Rajeev on 08-feb-2013
           pt.catg_cd ---dmsspr-13090
      FROM pt_soq_new pt, am_dealer_loc am
     WHERE pt.parent_group = am.parent_group
       AND pt.dealer_map_cd = am.dealer_map_cd
       AND pt.loc_cd = am.loc_cd
       AND pt.catg_cd = pi_part_categ --changes against -DMSSPR-13090
       AND am.consg_cd = NVL(p_consg_cd, am.consg_cd)
       AND am.parent_group = NVL(p_parent, am.parent_group)
       AND am.dealer_map_cd = NVL(p_dealer, am.dealer_map_cd)
       AND am.loc_cd = NVL(p_loc, am.loc_cd);

  CURSOR CR_SOQ_MUL(p_consg_cd VARCHAR2,
                    p_parent   VARCHAR2,
                    p_dealer   NUMBER,
                    p_loc      VARCHAR2) IS
    SELECT pt.part_num,
           pt.part_desc,
           pt.root_part_num,
           NVL(SUM(pt.soq_qty), 0) soq_qty,
           NVL(SUM(pt.on_hand_qty), 0) on_hand_qty,
           NVL(SUM(pt.on_order_qty), 0) on_order_qty,
           NVL(SUM(pt.safety_stock), 0) safety_stock,
           NVL(SUM(pt.min_stock), 0) min_stock,
           NVL(SUM(pt.max_stock), 0) max_stock,
           NVL(SUM(pt.inv_qty), 0) inv_qty,
           NVL(SUM(pt.avg_consumption), 0) avg_consumption,
           --NVL (SUM (pt.cust_order_qty), 0) cust_order_qty,
           MAX(pt.min_ord_qty) min_ord_qty,
           MIN(pt.part_family_age) part_family_age,
           pt.po_reqd_yn, --Arpan 04-feb-14
           pt.catg_cd --dmsspr-13090
      FROM pt_soq_new pt, am_dealer_loc am
     WHERE pt.parent_group = am.parent_group
       AND pt.dealer_map_cd = am.dealer_map_cd
       AND pt.loc_cd = am.loc_cd
       AND pt.catg_cd = pi_part_categ --changes against -DMSSPR-13090
       AND am.consg_cd = NVL(p_consg_cd, am.consg_cd)
       AND am.parent_group = NVL(p_parent, am.parent_group)
       AND am.dealer_map_cd = NVL(p_dealer, am.dealer_map_cd)
       AND am.loc_cd = NVL(p_loc, am.loc_cd)
     GROUP BY part_num, part_desc, root_part_num, pt.po_reqd_yn, pt.catg_cd; --dmsspr-13090

  ex_error EXCEPTION;
  lv_part_num     pm_part.part_num%TYPE;
  lv_step         VARCHAR2(1000) := 'Start';
  lv_count        NUMBER := 0;
  lv_soq_qty      NUMBER := 0;
  ln_soq          NUMBER := 0;
  lv_pack_qty     NUMBER := 0;
  lv_modified_cbo pt_soq_new.cust_order_qty%type := 0; ----v_1
  lv_cbo_50       number := 50; ---v_1
  lv_cbo_20       number := 20; ---v_1
  lv_cbo_5        number := 5; ---v_1
  lv_price_0      number := 0; ---v_1
  lv_price_100    number := 100; ---v_1
  lv_price_5000   number := 5000; ---v_1
  lv_low_inv      AM_DEALER_LOC_PARAM.low_inventory_yn%type; -- Added by Rajeev on 08-feb-2013

BEGIN
  po_errcd := 0;
  -- Added by Rajeev on 08-feb-2013 for find low inventory flag
  BEGIN
    SELECT nvl(am.low_inventory_yn, 'N')
      INTO lv_low_inv
      FROM AM_DEALER_LOC_PARAM am
     WHERE am.parent_group = pi_parent
       AND am.dealer_map_cd = pi_dealer
       AND am.loc_cd = pi_loc_cd;
  Exception
    when others then
      lv_low_inv := 'N';
  END;

  DELETE FROM PT_SOQ_NEW
   WHERE PARENT_GROUP = PI_PARENT
     AND LOC_CD = PI_LOC_CD
     AND NVL(CATG_CD, 'M') = pi_part_categ; --changes against -DMSSPR-13090;

  DELETE FROM PT_SOQ_MUL_TIL
   WHERE dealer_map_cd = pi_dealer
     AND parent_group = pi_parent
     AND loc_cd = pi_loc_cd
     AND NVL(CATG_CD, 'M') = pi_part_categ; --changes against -DMSSPR-13090;

  BEGIN

    BEGIN
      /* CBO*/
      /*FOR REC1 in (SELECT ppd.dealer_map_cd, NULL abc_ind, ppd.latest_part_num,
                  NVL (pmv.on_hand_qty, 0) - nvl(pmv.quarantine_qty,0) on_hand_qty,
                  GET_DMS_OOQ(pi_dealer,pi_parent,pi_loc_cd,ppd.root_part_num) OOQ,
                  NVL (ppd.reorder_lvl, 0) reorder_lvl, ppd.order_cycle,
                  NVL (ppd.min_lvl, 0) min_lvl, NVL (ppd.max_lvl, 0) max_lvl,
                  NULL fms_ind, ppd.lead_time,
                  ppd.part_desc,ppd.loc_cd,
                  NVL (ppd.inv_lvl, 0) inv_lvl,
                  NVL (ppd.avg_consumption, 0) avg_consumption,
                  NVL (pmv.on_hand_qty, 0) - nvl(pmv.quarantine_qty,0) on_hand_qty1, ppd.min_ord_qty,
                  ppd.root_part_num,
                  decode(ppd.part_consumpted_yn, 'N', 1,
                                         nvl(nvl((select order_reason_cd
                                                    from pm_part_var
                                                   where parent_group  = pi_parent
                                                     and dealer_map_cd = pi_dealer
                                                     and loc_cd        = pi_loc_cd
                                                     and part_num      = ppd.latest_part_num),
                                                  (select MIN(order_reason_cd) from pm_part_var pv1
                                                    where pv1.Dealer_map_cd = pi_dealer
                                                      and pv1.parent_group  = pi_parent
                                                      and pv1.loc_cd        = pi_loc_cd
                                                      and pv1.part_num in (select part_num
                                                                             from pm_part pm1
                                                                            where pm1.dealer_map_cd=1
                                                                              and pm1.root_part_num = ppd.root_part_num)
                                                      and   pv1.loc_cd = pi_loc_cd))
                       ,1)) part_family_age, -- Decode added by Rajeev on 20-may-2013, part family age will be 1 for non consumpted parts, against SCR 3065_001
                  ppd.purchase_price, NVL (tran_cnt_6_mnt, 0) tran_cnt_6_mnt,
                  get_cbo(pi_dealer,pi_parent,pi_loc_cd,ppd.root_part_num) cbo
             FROM pm_part_dtl_new ppd,
                  am_dealer_loc am,
                  (SELECT   pv.parent_group, pv.dealer_map_cd, pi_loc_cd \*pv.loc_cd*\ lc_cd,
                            root_part_num,
                            --Modified by prerna on 24-May-12 to get part stock from pm_stock_bin_loc
                            GET_PART_STOCK_RPN(pi_dealer,pi_loc_cd,pm.root_part_num) on_hand_qty,
                            SUM(decode(am.loc_cd,pi_loc_cd, NVL(quarantine_qty,0),0)) quarantine_qty,
                            --SUM(decode(am.loc_cd,pi_loc_cd, NVL(on_hand_qty,0)-NVL(quarantine_qty,0),0)) on_hand_qty,
                            MIN (NVL (order_reason_cd, 0)) order_reason_cd
                       FROM am_dealer_loc am, pm_part_var pv, pm_part pm
                      WHERE am.parent_group = pi_parent
                        AND am.dealer_map_cd = pi_dealer
                        AND am.consg_cd = NVL (pi_consg_cd, am.consg_cd)
                        AND pv.parent_group = am.parent_group
                        AND pv.dealer_map_cd = am.dealer_map_cd
                        AND pv.loc_cd = am.loc_cd
                        AND pm.catg_cd = pi_part_categ
                        AND pm.dealer_map_cd = 1
                        AND pm.part_num = pv.part_num
                        AND srv_live_date IS NOT NULL
                   GROUP BY pv.parent_group,
                            pv.dealer_map_cd,
                            root_part_num) pmv
            WHERE ppd.parent_group = pi_parent
              AND ppd.catg_cd = pi_part_categ
              AND ppd.consg_cd = NVL (pi_consg_cd, ppd.consg_cd)
              AND ppd.dealer_map_cd = pi_dealer
              AND ppd.loc_cd = pi_loc_cd
              AND ppd.parent_group = am.parent_group
              AND ppd.dealer_map_cd = am.dealer_map_cd
              AND ppd.loc_cd = am.loc_cd
              AND ppd.consg_cd = am.consg_cd
              AND pmv.parent_group = am.parent_group
              AND pmv.dealer_map_cd = am.dealer_map_cd
              AND pmv.lc_cd = am.loc_cd
              AND pmv.root_part_num = ppd.root_part_num) LOOP
        INSERT INTO pt_soq_new
                    (dealer_map_cd, part_class, part_num, as_on_date,
                     no_of_months, soq_qty, on_hand_qty, on_order_qty,
                     safety_stock, order_cycle, min_stock, max_stock,
                     fsn_ind, lead_time, cust_order_qty, created_by,
                     created_date, part_desc, parent_group, loc_cd,
                     inv_qty, amd_soq_qty, gen_loc, comp_fa,
                     avg_consumption, stock_qty, min_ord_qty,
                     root_part_num, part_family_age, purchase_price,
                     tran_cnt_6_mnt)
          VALUES (REC1.DEALER_MAP_CD,REC1.ABC_IND,REC1.LATEST_PART_NUM,pi_ason_dt,
          3,0,REC1.on_hand_qty,REC1.OOQ,REC1.REORDER_LVL,REC1.ORDER_CYCLE,
          REC1.MIN_LVL,REC1.Max_Lvl,REC1.FMS_IND,REC1.LEAD_TIME,
          rec1.cbo,
          pi_user, SYSDATE,
          REC1.Part_Desc,pi_parent,REC1.LOC_CD,REC1.inv_lvl,0,pi_loc_cd,pi_comp_fa,REC1.AVG_CONSUMPTION,
          REC1.ON_HAND_QTY1,REC1.MIN_ORD_QTY,REC1.Root_Part_Num,REC1.PART_FAMILY_AGE,
          REC1.PURCHASE_PRICE,REC1.tran_cnt_6_mnt);
      END LOOP;*/

      /*11G Changes*/

      INSERT INTO GBL_AOS_PART_DTL_NEW1
        SELECT ppd.dealer_map_cd,
               NULL abc_ind,
               ppd.latest_part_num,
               NVL(pmv.on_hand_qty, 0) - nvl(pmv.quarantine_qty, 0) on_hand_qty,
               GET_DMS_OOQ(to_number(pi_dealer),
                           to_char(pi_parent),
                           to_char(pi_loc_cd),
                           ppd.root_part_num,
                           pi_datadt) OOQ,
               NVL(ppd.reorder_lvl, 0) reorder_lvl,
               ppd.order_cycle,
               NVL(ppd.min_lvl, 0) min_lvl,
               NVL(ppd.max_lvl, 0) max_lvl,
               NULL fms_ind,
               ppd.lead_time,
               ppd.part_desc,
               ppd.loc_cd,
               NVL(ppd.inv_lvl, 0) inv_lvl,
               NVL(ppd.avg_consumption, 0) avg_consumption,
               NVL(pmv.on_hand_qty, 0) - nvl(pmv.quarantine_qty, 0) on_hand_qty1,
               ppd.min_ord_qty,
               ppd.root_part_num,
               ppd.purchase_price,
               NVL(tran_cnt_6_mnt, 0) tran_cnt_6_mnt,
               get_cbo(to_number(pi_dealer),
                       to_char(pi_parent),
                       to_char(pi_loc_cd),
                       ppd.root_part_num,
                       pi_datadt,
                       'T') cbo, ----v_1
               PPD.PART_CONSUMPTED_YN,
               ppd.catg_cd, ----dmsspr-13090
               NVL(ppd.avg_consumption_wt, 0) avg_consumption_wt,
               ppd.old_cbo, ----v_1
               ppd.old_max_lvl ----v_1
          FROM pm_part_dtl_new ppd,
               am_dealer_loc am,
               (SELECT pv.parent_group,
                       pv.dealer_map_cd,
                       to_char(pi_loc_cd) lc_cd,
                       root_part_num,
                       GET_PART_STOCK_RPN(to_number(pi_dealer),
                                          to_char(pi_loc_cd),
                                          pv.parent_group,
                                          pm.root_part_num,
                                          to_char(pi_consg_cd),
                                          'M') on_hand_qty,
                       SUM(decode(am.loc_cd,
                                  to_char(pi_loc_cd),
                                  NVL(quarantine_qty, 0),
                                  0)) quarantine_qty,
                       MIN(NVL(order_reason_cd, 0)) order_reason_cd
                  FROM am_dealer_loc am, pm_part_var pv, pm_part pm
                 WHERE am.parent_group = to_char(pi_parent)
                   AND am.dealer_map_cd = to_number(pi_dealer)
                   AND am.consg_cd = NVL(to_char(pi_consg_cd), am.consg_cd)
                   AND pv.parent_group = am.parent_group
                   AND pv.dealer_map_cd = am.dealer_map_cd
                   AND pv.loc_cd = am.loc_cd
                   AND pm.catg_cd = to_char(pi_part_categ)
                   AND pm.dealer_map_cd = to_number(pi_principal) -- 1 replaced by Rajeev for multi company changes
                   AND pm.part_num = pv.part_num
                   AND pm.principal_map_cd = to_number(pi_principal) -- Added by Rajeev for multi company changes
                --- AND srv_live_date IS NOT NULL--comment by ravi 23022017
                 GROUP BY pv.parent_group, pv.dealer_map_cd, root_part_num) pmv
         WHERE ppd.parent_group = to_char(pi_parent)
           AND ppd.catg_cd = to_char(pi_part_categ)
           AND ppd.consg_cd = NVL(to_char(pi_consg_cd), ppd.consg_cd)
           AND ppd.dealer_map_cd = to_number(pi_dealer)
           AND ppd.loc_cd = to_char(pi_loc_cd)
           AND ppd.parent_group = am.parent_group
           AND ppd.dealer_map_cd = am.dealer_map_cd
           AND ppd.loc_cd = am.loc_cd
           AND ppd.consg_cd = am.consg_cd
           AND pmv.parent_group = am.parent_group
           AND pmv.dealer_map_cd = am.dealer_map_cd
           AND pmv.lc_cd = am.loc_cd
           AND pmv.root_part_num = ppd.root_part_num;

      /*SELECT ppd.dealer_map_cd, NULL abc_ind, ppd.latest_part_num,
            NVL (pmv.on_hand_qty, 0) - nvl(pmv.quarantine_qty,0) on_hand_qty,
            GET_DMS_OOQ(pi_dealer,pi_parent,pi_loc_cd,ppd.root_part_num) OOQ,
            NVL (ppd.reorder_lvl, 0) reorder_lvl, ppd.order_cycle,
            NVL (ppd.min_lvl, 0) min_lvl, NVL (ppd.max_lvl, 0) max_lvl,
            NULL fms_ind, ppd.lead_time,
            ppd.part_desc,ppd.loc_cd,
            NVL (ppd.inv_lvl, 0) inv_lvl,
            NVL (ppd.avg_consumption, 0) avg_consumption,
            NVL (pmv.on_hand_qty, 0) - nvl(pmv.quarantine_qty,0) on_hand_qty1, ppd.min_ord_qty,
            ppd.root_part_num,
            ppd.purchase_price, NVL (tran_cnt_6_mnt, 0) tran_cnt_6_mnt,
            get_cbo(pi_dealer,pi_parent,pi_loc_cd,ppd.root_part_num) cbo,
            PPD.PART_CONSUMPTED_YN
       FROM pm_part_dtl_new ppd,
            am_dealer_loc am,
            (SELECT   pv.parent_group, pv.dealer_map_cd, pi_loc_cd lc_cd,
                      root_part_num,
                      GET_PART_STOCK_RPN(pi_dealer,pi_loc_cd,pm.root_part_num) on_hand_qty,
                      SUM(decode(am.loc_cd,pi_loc_cd, NVL(quarantine_qty,0),0)) quarantine_qty,
                      MIN (NVL (order_reason_cd, 0)) order_reason_cd
                 FROM am_dealer_loc am, pm_part_var pv, pm_part pm
                WHERE am.parent_group = pi_parent
                  AND am.dealer_map_cd = pi_dealer
                  AND am.consg_cd = NVL (pi_consg_cd, am.consg_cd)
                  AND pv.parent_group = am.parent_group
                  AND pv.dealer_map_cd = am.dealer_map_cd
                  AND pv.loc_cd = am.loc_cd
                  AND pm.catg_cd = pi_part_categ
                  AND pm.dealer_map_cd = 1
                  AND pm.part_num = pv.part_num
                  AND srv_live_date IS NOT NULL
             GROUP BY pv.parent_group,
                      pv.dealer_map_cd,
                      root_part_num) pmv
      WHERE ppd.parent_group = pi_parent
        AND ppd.catg_cd = pi_part_categ
        AND ppd.consg_cd = NVL (pi_consg_cd, ppd.consg_cd)
        AND ppd.dealer_map_cd = pi_dealer
        AND ppd.loc_cd = pi_loc_cd
        AND ppd.parent_group = am.parent_group
        AND ppd.dealer_map_cd = am.dealer_map_cd
        AND ppd.loc_cd = am.loc_cd
        AND ppd.consg_cd = am.consg_cd
        AND pmv.parent_group = am.parent_group
        AND pmv.dealer_map_cd = am.dealer_map_cd
        AND pmv.lc_cd = am.loc_cd
        AND pmv.root_part_num = ppd.root_part_num;*/

      FOR REC1 in (select DEALER_MAP_CD,
                          ABC_IND,
                          LATEST_PART_NUM,
                          ON_HAND_QTY,
                          OOQ,
                          REORDER_LVL,
                          ORDER_CYCLE,
                          MIN_LVL,
                          MAX_LVL,
                          FMS_IND,
                          LEAD_TIME,
                          PART_DESC,
                          LOC_CD,
                          INV_LVL,
                          AVG_CONSUMPTION,
                          AVG_CONSUMPTION_WT,
                          ON_HAND_QTY1,
                          MIN_ORD_QTY,
                          ROOT_PART_NUM,
                          NVL(NVL((SELECT ORDER_REASON_CD
                                    FROM PM_PART_VAR
                                   WHERE PARENT_GROUP = pi_parent
                                     AND DEALER_MAP_CD = pi_dealer
                                     AND LOC_CD = pi_loc_cd
                                     AND PART_NUM = xx.LATEST_PART_NUM),
                                  (SELECT MIN(ORDER_REASON_CD)
                                     FROM PM_PART_VAR PV1
                                    WHERE PV1.DEALER_MAP_CD = pi_dealer
                                      AND PV1.PARENT_GROUP = pi_parent
                                      AND PV1.LOC_CD = pi_loc_cd
                                      AND PV1.PART_NUM IN (SELECT PART_NUM
                                                             FROM PM_PART PM1
                                                            WHERE PM1.DEALER_MAP_CD =
                                                                  to_number(pi_principal) -- 1 replaced by Rajeev for multi company changes
                                                              AND PM1.ROOT_PART_NUM =
                                                                  xx.ROOT_PART_NUM
                                                           --AND pm1.principal_map_cd = to_number(pi_principal)    -- Added by Rajeev for multi company changes
                                                           ))),
                              1) PART_FAMILY_AGE, --Changes against -DMSSPR-13105
                          /* DECODE(xx.PART_CONSUMPTED_YN,
                          'N',
                           0,
                          --1, --commented against -DMSSPR-13105
                          NVL(NVL((SELECT ORDER_REASON_CD
                                    FROM PM_PART_VAR
                                   WHERE PARENT_GROUP = pi_parent
                                     AND DEALER_MAP_CD = pi_dealer
                                     AND LOC_CD = pi_loc_cd
                                     AND PART_NUM = xx.LATEST_PART_NUM),
                                  (SELECT MIN(ORDER_REASON_CD)
                                     FROM PM_PART_VAR PV1
                                    WHERE PV1.DEALER_MAP_CD = pi_dealer
                                      AND PV1.PARENT_GROUP = pi_parent
                                      AND PV1.LOC_CD = pi_loc_cd
                                      AND PV1.PART_NUM IN
                                          (SELECT PART_NUM
                                             FROM PM_PART PM1
                                            WHERE PM1.DEALER_MAP_CD = to_number(pi_principal)    -- 1 replaced by Rajeev for multi company changes
                                              AND PM1.ROOT_PART_NUM = xx.ROOT_PART_NUM
                                              --AND pm1.principal_map_cd = to_number(pi_principal)    -- Added by Rajeev for multi company changes
                                              ))),
                              1)) PART_FAMILY_AGE,*/
                          PURCHASE_PRICE,
                          TRAN_CNT_6_MNT,
                          CBO,
                          DECODE(xx.PART_CONSUMPTED_YN, 'N', 'N', 'Y') po_reqd_yn,
                          CATG_CD, --DMSSPR-13090
                          xx.old_cbo, ----v_1
                          xx.old_max_lvl ----v_1
                     from GBL_AOS_PART_DTL_NEW1 xx) LOOP
        BEGIN
          /*Added by Dp Swain on 22-APr-2026 for AOS part mismatch issue*/
                               /*  begin
                                   insert into aos_latest_part_mismatch
                                    (entry_source,
                                    parent_group,
                                    dealer_map_cd,
                                    loc_cd,
                                    root_part_number,
                                    part_num,
                                    LATEST_PART_NUM,
                                    created_date,
                                    process_code)
                                    values('pt_soq_new',
                                          pi_parent,
                                          REC1.DEALER_MAP_CD,
                                          REC1.LOC_CD,
                                          REC1.ROOT_PART_NUM,
                                          REC1.LATEST_PART_NUM,
                                          REC1.LATEST_PART_NUM,
                                          sysdate,
                                          'SP_CALULATE_SOQ_IMS'
                                       );
                                   exception
                                     when others then
                                       null;
                                   end;*/
          INSERT INTO pt_soq_new
            (dealer_map_cd,
             part_class,
             part_num,
             as_on_date,
             no_of_months,
             soq_qty,
             on_hand_qty,
             on_order_qty,
             safety_stock,
             order_cycle,
             min_stock,
             max_stock,
             fsn_ind,
             lead_time,
             cust_order_qty,
             created_by,
             created_date,
             part_desc,
             parent_group,
             loc_cd,
             inv_qty,
             amd_soq_qty,
             gen_loc,
             comp_fa,
             avg_consumption,
             avg_consumption_wt,
             stock_qty,
             min_ord_qty,
             root_part_num,
             part_family_age,
             purchase_price,
             tran_cnt_6_mnt,
             po_reqd_yn, --Arpan 04-feb-14
             catg_cd, --category code change against -DMSSPR-13090
             old_cbo, -------V_1
             old_max_lvl -------V_1
             )
          VALUES
            (REC1.DEALER_MAP_CD,
             REC1.ABC_IND,
             REC1.LATEST_PART_NUM,
             pi_ason_dt,
             3,
             0,
             REC1.on_hand_qty,
             REC1.OOQ,
             REC1.REORDER_LVL,
             REC1.ORDER_CYCLE,
             REC1.MIN_LVL,
             REC1.Max_Lvl,
             REC1.FMS_IND,
             REC1.LEAD_TIME,
             rec1.cbo,
             pi_user,
             SYSDATE,
             REC1.Part_Desc,
             pi_parent,
             REC1.LOC_CD,
             REC1.inv_lvl,
             0,
             pi_loc_cd,
             pi_comp_fa,
             REC1.AVG_CONSUMPTION,
             REC1.AVG_CONSUMPTION_WT,
             REC1.ON_HAND_QTY1,
             REC1.MIN_ORD_QTY,
             REC1.Root_Part_Num,
             REC1.PART_FAMILY_AGE,
             REC1.PURCHASE_PRICE,
             REC1.tran_cnt_6_mnt,
             REC1.po_reqd_yn,
             REC1.CATG_CD, --DMSSPR-13090
             REC1.old_CBO, ----------V_1
             REC1.old_MAX_LVL -------V_1
             );
        EXCEPTION
          WHEN DUP_VAL_ON_INDEX THEN
            DBMS_OUTPUT.put_line(SQLCODE || '--' || SQLERRM);
          WHEN OTHERS THEN
            DBMS_OUTPUT.put_line('OTHERS' || SQLCODE || '--' || SQLERRM);
        END;
      END LOOP;
      /*11G Changes Completed*/
      --Added by Srinivasan on 15/10/2008 to calculate SOQ for non-tranacted in last 12 months but customer back order is greater than zero
      -------------------------------------------------------------------------------------------------------
      DECLARE
        /* CBO*/
        CURSOR cr_cust_bo IS
          SELECT pv.parent_group,
                 pv.dealer_map_cd,
                 pv.loc_cd,
                 root_part_num,
                 SUM(on_hand_qty) on_hand_qty,
                 GET_DMS_OOQ(pi_dealer,
                             pi_parent,
                             pi_loc_cd,
                             pm.root_part_num,
                             pi_datadt) on_order_qty,
                 --SUM (cust_order_qty) cust_order_qty,
                 MAX(NVL(order_reason_cd, 0)) order_reason_cd
            FROM am_dealer_loc am, pm_part_var pv, pm_part pm
           WHERE am.parent_group = pi_parent
             AND am.dealer_map_cd = pi_dealer
             AND am.loc_cd = pi_loc_cd
             AND am.consg_cd = NVL(pi_consg_cd, am.consg_cd)
             AND pv.parent_group = am.parent_group
             AND pv.dealer_map_cd = am.dealer_map_cd
             AND pv.loc_cd = am.loc_cd
             AND pm.catg_cd = pi_part_categ
             AND pm.dealer_map_cd = to_number(pi_principal) -- 1 replaced by Rajeev for multi company changes
             AND pm.part_num = pv.part_num
             ANd pm.principal_map_cd = to_number(pi_principal) -- Added by Rajeev for multi company changes
          -- AND srv_live_date IS NOT NULL--comment by ravi 23022017
           GROUP BY pv.parent_group,
                    pv.dealer_map_cd,
                    pv.loc_cd,
                    root_part_num;

        bo_cnt NUMBER;
      BEGIN
        FOR ccust IN cr_cust_bo LOOP
          SELECT COUNT(1)
            INTO bo_cnt
            FROM pm_part_dtl_new
           WHERE parent_group = ccust.parent_group
             AND dealer_map_cd = ccust.dealer_map_cd
             AND loc_cd = ccust.loc_cd
             AND root_part_num = ccust.root_part_num;

          IF bo_cnt = 0 THEN
            BEGIN
              /*Added by Dp Swain on 22-APr-2026 for AOS part mismatch issue*/
                               /*  begin
                                   insert into aos_latest_part_mismatch
                                    (entry_source,
                                    parent_group,
                                    dealer_map_cd,
                                    loc_cd,
                                    root_part_number,
                                    part_num,
                                    LATEST_PART_NUM,
                                    created_date,
                                    process_code)
                                    SELECT 'pt_soq_new_bo',
                                    pv.parent_group,
                                    pv.dealer_map_cd,
                                    pv.loc_cd,
                                    pm.root_part_num,
                                    MAX(pm_latest.latest_part_num),
                                    MAX(pm_latest.latest_part_num),
                                    sysdate,
                                    'SP_CALULATE_SOQ_IMS'
                  FROM am_dealer_loc am,
                       pm_part_var pv,
                       pm_part pm,
                       (SELECT root_part_num,
                               part_num latest_part_num,
                               part_desc,
                               NVL(vor_yn, 'N') vor_yn,
                               NVL(mul_yn, 'N') mul_yn,
                               min_ord_qty,
                               catg_cd
                          FROM muldms.pm_part ppm
                         WHERE dealer_map_cd = to_number(pi_principal) -- 1 replaced by Rajeev for multi company changes
                           AND principal_map_cd = to_number(pi_principal) -- Added by Rajeev for multi company changes
                           --AND NVL(tag_cd, 1) IN (1, 4, 5)
                           AND nvl(tag_cd, 1) IN (1, 3, 4) -- changed by DP Swain for DP-599
                           AND NVL(vor_yn, 'N') = 'N'
                           AND root_part_num = ccust.root_part_num
                           AND seq_num =
                               (SELECT MAX(seq_num)
                                  FROM pm_part
                                 WHERE root_part_num = ppm.root_part_num
                                   AND dealer_map_cd =
                                       to_number(pi_principal) -- 1 replaced by Rajeev for multi company changes
                                   AND principal_map_cd =
                                       to_number(pi_principal) -- Added by Rajeev for multi company changes
                                   --AND NVL(tag_cd, 1) IN (1, 4, 5)
                                   AND nvl(tag_cd, 1) IN (1, 3, 4) --changed by DP Swain for DP-599
                                   AND NVL(vor_yn, 'N') = 'N')) pm_latest
                 WHERE am.parent_group = pi_parent
                   AND am.dealer_map_cd = pi_dealer
                   AND am.loc_cd = pi_loc_cd
                   AND am.consg_cd = NVL(pi_consg_cd, am.consg_cd)
                   AND pv.parent_group = am.parent_group
                   AND pv.dealer_map_cd = am.dealer_map_cd
                   AND pv.loc_cd = am.loc_cd
                   AND pm.catg_cd = pi_part_categ
                   AND pm.dealer_map_cd = to_number(pi_principal) -- 1 replaced by Rajeev for multi company changes
                   AND pm.principal_map_cd = to_number(pi_principal) -- Added by Rajeev for multi company changes
                   AND pm.part_num = pv.part_num
                      --AND srv_live_date IS NOT NULL --comment by ravi 23022017
                   AND get_cbo(ccust.dealer_map_cd,
                               ccust.parent_group,
                               ccust.loc_cd,
                               ccust.root_part_num,
                               pi_datadt,
                               'T') > 0 ----v_1
                   AND pm.root_part_num = ccust.root_part_num
                   AND pm_latest.root_part_num = pm.root_part_num
                 GROUP BY pv.parent_group,
                          pv.dealer_map_cd,
                          pv.loc_cd,
                          pm.root_part_num,
                          pm.catg_cd;
                     exception
                   when others then
                     null;
                 end;*/
              INSERT INTO pt_soq_new
                (dealer_map_cd,
                 part_class,
                 part_num,
                 as_on_date,
                 no_of_months,
                 soq_qty,
                 on_hand_qty,
                 on_order_qty,
                 safety_stock,
                 order_cycle,
                 min_stock,
                 max_stock,
                 fsn_ind,
                 lead_time,
                 cust_order_qty,
                 created_by,
                 created_date,
                 part_desc,
                 parent_group,
                 loc_cd,
                 inv_qty,
                 amd_soq_qty,
                 gen_loc,
                 comp_fa,
                 avg_consumption,
                 avg_consumption_wt,
                 stock_qty,
                 min_ord_qty,
                 root_part_num,
                 part_family_age,
                 purchase_price,
                 tran_cnt_6_mnt,
                 catg_cd) ---changes against -DMSSPR-13090
                SELECT pv.dealer_map_cd,
                       NULL part_class,
                       MAX(pm_latest.latest_part_num),
                       SYSDATE as_on_date,
                       3 no_of_months,
                       0 soq_qty,
                       SUM(NVL(on_hand_qty, 0) - NVL(quarantine_qty, 0)) on_hand_qty,
                       GET_DMS_OOQ(pi_dealer,
                                   pi_parent,
                                   pi_loc_cd,
                                   pm.root_part_num,
                                   pi_datadt) on_order_qty,
                       0 safety_stock,
                       0 order_cycle,
                       0 min_stock,
                       0 max_stock,
                       NULL fsn_ind,
                       0 lead_time,
                       get_cbo(ccust.dealer_map_cd,
                               ccust.parent_group,
                               ccust.loc_cd,
                               ccust.root_part_num,
                               pi_datadt,
                               'T') cust_order_qty,
                       --sum(decode(sign(NVL (cust_order_qty, 0)),-1,0,NVL (cust_order_qty, 0))),--added by pradeep.pai on 18/08/09 to avoid -ve back order
                       pi_user,
                       SYSDATE created_date,
                       MAX(pm_latest.part_desc),
                       pv.parent_group,
                       pv.loc_cd,
                       0 inv_qty,
                       0 amd_soq_qty,
                       pi_loc_cd,
                       pi_comp_fa,
                       0 avg_consumption,
                       0 avg_consumption_wt,
                       SUM(on_hand_qty) on_hand_qty,
                       MAX(pm_latest.min_ord_qty) min_ord_qty,
                       pm.root_part_num,
                       MIN(NVL(order_reason_cd, 0)) order_reason_cd,
                       --0 order_reason_cd,  --commented against -DMSSPR-13105
                       MAX(pv.purchase_price) purchase_price,
                       -1 tran_cnt_6_mnt,
                       pm.catg_cd -- Changes against -DMSSPR-13090
                  FROM am_dealer_loc am,
                       pm_part_var pv,
                       pm_part pm,
                       (SELECT root_part_num,
                               part_num latest_part_num,
                               part_desc,
                               NVL(vor_yn, 'N') vor_yn,
                               NVL(mul_yn, 'N') mul_yn,
                               min_ord_qty,
                               catg_cd
                          FROM muldms.pm_part ppm
                         WHERE dealer_map_cd = to_number(pi_principal) -- 1 replaced by Rajeev for multi company changes
                           AND principal_map_cd = to_number(pi_principal) -- Added by Rajeev for multi company changes
                           --AND NVL(tag_cd, 1) IN (1, 4, 5)
                           AND nvl(tag_cd, 1) IN (1, 3, 4) /*changed by DP Swain for DP-599*/
                           AND NVL(vor_yn, 'N') = 'N'
                           AND root_part_num = ccust.root_part_num
                           AND seq_num =
                               (SELECT MAX(seq_num)
                                  FROM pm_part
                                 WHERE root_part_num = ppm.root_part_num
                                   AND dealer_map_cd =
                                       to_number(pi_principal) -- 1 replaced by Rajeev for multi company changes
                                   AND principal_map_cd =
                                       to_number(pi_principal) -- Added by Rajeev for multi company changes
                                   --AND NVL(tag_cd, 1) IN (1, 4, 5)
                                   AND nvl(tag_cd, 1) IN (1, 3, 4) /*changed by DP Swain for DP-599*/
                                   AND NVL(vor_yn, 'N') = 'N')) pm_latest
                 WHERE am.parent_group = pi_parent
                   AND am.dealer_map_cd = pi_dealer
                   AND am.loc_cd = pi_loc_cd
                   AND am.consg_cd = NVL(pi_consg_cd, am.consg_cd)
                   AND pv.parent_group = am.parent_group
                   AND pv.dealer_map_cd = am.dealer_map_cd
                   AND pv.loc_cd = am.loc_cd
                   AND pm.catg_cd = pi_part_categ
                   AND pm.dealer_map_cd = to_number(pi_principal) -- 1 replaced by Rajeev for multi company changes
                   AND pm.principal_map_cd = to_number(pi_principal) -- Added by Rajeev for multi company changes
                   AND pm.part_num = pv.part_num
                      --AND srv_live_date IS NOT NULL --comment by ravi 23022017
                   AND get_cbo(ccust.dealer_map_cd,
                               ccust.parent_group,
                               ccust.loc_cd,
                               ccust.root_part_num,
                               pi_datadt,
                               'T') > 0 ----v_1
                   AND pm.root_part_num = ccust.root_part_num
                   AND pm_latest.root_part_num = pm.root_part_num
                 GROUP BY pv.parent_group,
                          pv.dealer_map_cd,
                          pv.loc_cd,
                          pm.root_part_num,
                          pm.catg_cd; --dmsspr-13090
            EXCEPTION
              WHEN DUP_VAL_ON_INDEX THEN
                DBMS_OUTPUT.put_line('insertion for cbo MGP parts' || '--' ||
                                     SQLERRM);
              WHEN OTHERS THEN
                NULL;
            END;
          END IF;

        END LOOP;
      END;
      -------------------------------------------------------------------------------------------------------
    EXCEPTION
      WHEN OTHERS THEN
        po_errmsg := 'Error while inserting into pt_soq_new :' || SQLERRM;
        RAISE ex_error;
    END;

    ---------------BEGIN-----------------------------------------------------------v_1
    FOR c_soq IN cr_soq_new(NULL, pi_parent, pi_dealer, pi_loc_cd) LOOP
      begin

        lv_modified_cbo := c_soq.cust_order_qty;
        --  dbms_output.put_line('lv_modified_cbo'||lv_modified_cbo);
        if get_cbo(to_number(pi_dealer),
                   to_char(pi_parent),
                   to_char(pi_loc_cd),
                   c_soq.root_part_num,
                   pi_datadt,
                   'A') > nvl(c_soq.avg_consumption_wt, 0) then
          if c_soq.purchase_price < lv_price_100 and
             c_soq.purchase_price >= lv_price_0 and
             (c_soq.cust_order_qty > lv_cbo_50 and
             c_soq.cust_order_qty > (2 * nvl(c_soq.avg_consumption_wt, 0))) then
            lv_modified_cbo := greatest(lv_cbo_50,
                                        2 * nvl(c_soq.avg_consumption_wt, 0));
          elsif c_soq.purchase_price < lv_price_5000 and
                c_soq.purchase_price >= lv_price_100 and
                (c_soq.cust_order_qty > lv_cbo_20 and
                c_soq.cust_order_qty >
                (2 * nvl(c_soq.avg_consumption_wt, 0))) then
            lv_modified_cbo := greatest(lv_cbo_20,
                                        2 * nvl(c_soq.avg_consumption_wt, 0));
          elsif c_soq.purchase_price >= lv_price_5000 and
                (c_soq.cust_order_qty > lv_cbo_5 and
                c_soq.cust_order_qty >
                (2 * nvl(c_soq.avg_consumption_wt, 0))) then
            lv_modified_cbo := greatest(lv_cbo_5,
                                        2 * nvl(c_soq.avg_consumption_wt, 0));
          end if;
        end if;
        -- dbms_output.put_line('c_soq.cust_order_qty'||c_soq.cust_order_qty);
        -- dbms_output.put_line('lv_modified_cbo'||lv_modified_cbo);
        UPDATE pt_soq_new
           SET cust_order_qty = NVL(lv_modified_cbo, 0),
               old_cbo        = NVL(c_soq.cust_order_qty, 0)
         WHERE ROWID = c_soq.ROWID;

        UPDATE PM_PART_DTL_NEW
           set Cust_Order_Qty = NVL(lv_modified_cbo, 0),
               old_cbo        = NVL(c_soq.cust_order_qty, 0)
         WHERE parent_group = c_soq.parent_group
           AND dealer_map_cd = c_soq.dealer_map_cd
           AND loc_cd = c_soq.loc_cd
           AND root_part_num = c_soq.root_part_num;
      EXCEPTION
        WHEN OTHERS THEN
          po_errmsg := 'Error while calcuating cbo for part num :' ||
                       c_soq.part_num || SQLERRM;
          RAISE ex_error;
      END;
    END LOOP;
    ----------------------------------------v_1--------------------------------------end

    -- Below if condition and else block written by Rajeev on 08-feb-2013
    -- Else block added for implemented of new logic for low eventry flag 'Y' location
    -- SOQ quantity always calculared according to new logic for eventry flag 'Y' location
    ---transaction count will be 4 and purchase price will be 100 against DMSSPR-13049
    IF lv_low_inv = 'N' then
      FOR c_soq IN cr_soq_new(NULL, pi_parent, pi_dealer, pi_loc_cd) LOOP
        BEGIN
          lv_soq_qty := 0;
          IF nvl(c_soq.purchase_price, 0) = 0 THEN
            --This condition added by Arpan on 19-Jul-13.SCR: 4594_001
            lv_soq_qty := NVL(c_soq.cust_order_qty, 0) -
                          NVL(c_soq.on_hand_qty, 0) -
                          NVL(c_soq.on_order_qty, 0);
          ELSE
            IF c_soq.tran_cnt_6_mnt > 4 THEN
              IF NVL(c_soq.safety_stock, 0) -
                 (NVL(c_soq.on_hand_qty, 0) + NVL(c_soq.on_order_qty, 0) -
                  NVL(c_soq.cust_order_qty, 0)) > 0 THEN
                lv_soq_qty := NVL(c_soq.max_stock, 0) -
                              (NVL(c_soq.on_hand_qty, 0) +
                               NVL(c_soq.on_order_qty, 0) -
                               NVL(c_soq.cust_order_qty, 0));
              ELSE
                lv_soq_qty := 0;
              END IF;
            ELSIF c_soq.tran_cnt_6_mnt <= 4 AND
                  ROUND(c_soq.purchase_price * c_soq.min_ord_qty) <= 100 THEN
              IF NVL(c_soq.on_hand_qty, 0) > 0 AND
                 NVL(c_soq.on_order_qty, 0) = 0 AND
                 NVL(c_soq.cust_order_qty, 0) = 0 THEN
                lv_soq_qty := 0;
              ELSIF NVL(c_soq.on_hand_qty, 0) = 0 AND
                    NVL(c_soq.on_order_qty, 0) = 0 AND
                    NVL(c_soq.cust_order_qty, 0) = 0 THEN
                /*lv_soq_qty := 1;*/ lv_soq_qty := 0;  ---Changed 1 to 0 by Saurav DMSSPR-13301
              ELSIF NVL(c_soq.cust_order_qty, 0) -
                    (NVL(c_soq.on_order_qty, 0) + NVL(c_soq.on_hand_qty, 0)) > 0 THEN

                IF c_soq.tran_cnt_6_mnt = -1 THEN
                  lv_soq_qty := (NVL(c_soq.cust_order_qty, 0)) -
                                (NVL(c_soq.on_order_qty, 0) +
                                NVL(c_soq.on_hand_qty, 0));
                ELSE
                  lv_soq_qty := (NVL(c_soq.cust_order_qty, 0) + 1) -
                                (NVL(c_soq.on_order_qty, 0) +
                                NVL(c_soq.on_hand_qty, 0));
                END IF;
              END IF;
            ELSIF c_soq.tran_cnt_6_mnt <= 4 AND
                  ROUND(c_soq.purchase_price * c_soq.min_ord_qty) > 100 THEN
              IF NVL(c_soq.cust_order_qty, 0) -
                 (NVL(c_soq.on_order_qty, 0) + NVL(c_soq.on_hand_qty, 0)) > 0 THEN
                lv_soq_qty := NVL(c_soq.cust_order_qty, 0) -
                              (NVL(c_soq.on_order_qty, 0) +
                               NVL(c_soq.on_hand_qty, 0));
              ELSE
                lv_soq_qty := 0;
              END IF;
            END IF;
          END IF;

          UPDATE pt_soq_new
             SET soq_qty = NVL(lv_soq_qty, 0)
           WHERE ROWID = c_soq.ROWID;
        EXCEPTION
          WHEN OTHERS THEN
            po_errmsg := 'Error while calcuating the soq qty for part num :' ||
                         c_soq.part_num || SQLERRM;
            RAISE ex_error;
        END;
      END LOOP;
      -- Else block added by Rajeev
    ELSE
      FOR c_soq IN cr_soq_new(NULL, pi_parent, pi_dealer, pi_loc_cd) LOOP
        BEGIN
          lv_soq_qty := 0;

          IF NVL(c_soq.purchase_price, 0) = 0 THEN
            lv_soq_qty := NVL(c_soq.cust_order_qty, 0) -
                          NVL(c_soq.on_hand_qty, 0) -
                          NVL(c_soq.on_order_qty, 0);
          ELSE
            IF c_soq.avg_consumption > 2 THEN
              --avg consumption replace with avg_consumption_wt
              IF c_soq.tran_cnt_6_mnt > 4 THEN
                IF NVL(c_soq.safety_stock, 0) -
                   (NVL(c_soq.on_hand_qty, 0) + NVL(c_soq.on_order_qty, 0) -
                    NVL(c_soq.cust_order_qty, 0)) > 0 THEN
                  lv_soq_qty := NVL(c_soq.max_stock, 0) -
                                (NVL(c_soq.on_hand_qty, 0) +
                                 NVL(c_soq.on_order_qty, 0) -
                                 NVL(c_soq.cust_order_qty, 0));
                ELSE
                  lv_soq_qty := 0;
                END IF;
              ELSIF c_soq.tran_cnt_6_mnt <= 4 AND
                    ROUND(c_soq.purchase_price * c_soq.min_ord_qty) <= 100 THEN
                IF NVL(c_soq.on_hand_qty, 0) > 0 AND
                   NVL(c_soq.on_order_qty, 0) = 0 AND
                   NVL(c_soq.cust_order_qty, 0) = 0 THEN
                  lv_soq_qty := 0;
                ELSIF NVL(c_soq.on_hand_qty, 0) = 0 AND
                      NVL(c_soq.on_order_qty, 0) = 0 AND
                      NVL(c_soq.cust_order_qty, 0) = 0 THEN
                 /* lv_soq_qty := 1;*/  lv_soq_qty := 0;        ---Changed 1 to 0 by Saurav DMSSPR-13301
                ELSIF NVL(c_soq.cust_order_qty, 0) -
                      (NVL(c_soq.on_order_qty, 0) +
                       NVL(c_soq.on_hand_qty, 0)) > 0 THEN

                  IF c_soq.tran_cnt_6_mnt = -1 THEN
                    lv_soq_qty := (NVL(c_soq.cust_order_qty, 0)) -
                                  (NVL(c_soq.on_order_qty, 0) +
                                  NVL(c_soq.on_hand_qty, 0));
                  ELSE
                    lv_soq_qty := (NVL(c_soq.cust_order_qty, 0) + 1) -
                                  (NVL(c_soq.on_order_qty, 0) +
                                  NVL(c_soq.on_hand_qty, 0));
                  END IF;
                END IF;
              ELSIF c_soq.tran_cnt_6_mnt <= 4 AND
                    ROUND(c_soq.purchase_price * c_soq.min_ord_qty) > 100 THEN
                IF NVL(c_soq.cust_order_qty, 0) -
                   (NVL(c_soq.on_order_qty, 0) + NVL(c_soq.on_hand_qty, 0)) > 0 THEN
                  lv_soq_qty := NVL(c_soq.cust_order_qty, 0) -
                                (NVL(c_soq.on_order_qty, 0) +
                                 NVL(c_soq.on_hand_qty, 0));
                ELSE
                  lv_soq_qty := 0;
                END IF;
              END IF;
            ELSE
              IF ((c_soq.avg_consumption = 0 /*AND c_soq.tran_cnt_6_mnt <= 2*/ -- Commented by Rajeev on 03-jun-2013 as per SCR 4031_001
                 AND c_soq.order_cycle <= 2) OR
                 (c_soq.avg_consumption > 0 AND c_soq.avg_consumption <= 1 AND
                 c_soq.purchase_price >= 1000 AND c_soq.order_cycle <= 2) OR
                 (c_soq.avg_consumption > 1 AND c_soq.avg_consumption <= 2 AND
                 c_soq.purchase_price >= 2000 AND c_soq.order_cycle <= 2)) THEN
                lv_soq_qty := NVL(c_soq.cust_order_qty, 0) -
                              (NVL(c_soq.on_order_qty, 0) +
                               NVL(c_soq.on_hand_qty, 0));
              ELSE
                IF c_soq.tran_cnt_6_mnt > 4 THEN
                  IF NVL(c_soq.safety_stock, 0) -
                     (NVL(c_soq.on_hand_qty, 0) +
                      NVL(c_soq.on_order_qty, 0) -
                      NVL(c_soq.cust_order_qty, 0)) > 0 THEN
                    lv_soq_qty := NVL(c_soq.max_stock, 0) -
                                  (NVL(c_soq.on_hand_qty, 0) +
                                   NVL(c_soq.on_order_qty, 0) -
                                   NVL(c_soq.cust_order_qty, 0));
                  ELSE
                    lv_soq_qty := 0;
                  END IF;
                ELSIF c_soq.tran_cnt_6_mnt <= 4 AND
                      ROUND(c_soq.purchase_price * c_soq.min_ord_qty) <= 100 THEN
                  IF NVL(c_soq.on_hand_qty, 0) > 0 AND
                     NVL(c_soq.on_order_qty, 0) = 0 AND
                     NVL(c_soq.cust_order_qty, 0) = 0 THEN
                    lv_soq_qty := 0;
                  ELSIF NVL(c_soq.on_hand_qty, 0) = 0 AND
                        NVL(c_soq.on_order_qty, 0) = 0 AND
                        NVL(c_soq.cust_order_qty, 0) = 0 THEN
                    /*lv_soq_qty := 1;*/    lv_soq_qty := 0;        ---Changed 1 to 0 by Saurav DMSSPR-13301
                  ELSIF NVL(c_soq.cust_order_qty, 0) -
                        (NVL(c_soq.on_order_qty, 0) +
                         NVL(c_soq.on_hand_qty, 0)) > 0 THEN

                    IF c_soq.tran_cnt_6_mnt = -1 THEN
                      lv_soq_qty := (NVL(c_soq.cust_order_qty, 0)) -
                                    (NVL(c_soq.on_order_qty, 0) +
                                    NVL(c_soq.on_hand_qty, 0));
                    ELSE
                      lv_soq_qty := (NVL(c_soq.cust_order_qty, 0) + 1) -
                                    (NVL(c_soq.on_order_qty, 0) +
                                    NVL(c_soq.on_hand_qty, 0));
                    END IF;
                  END IF;
                ELSIF c_soq.tran_cnt_6_mnt <= 4 AND
                      ROUND(c_soq.purchase_price * c_soq.min_ord_qty) > 100 THEN
                  IF NVL(c_soq.cust_order_qty, 0) -
                     (NVL(c_soq.on_order_qty, 0) +
                      NVL(c_soq.on_hand_qty, 0)) > 0 THEN
                    lv_soq_qty := NVL(c_soq.cust_order_qty, 0) -
                                  (NVL(c_soq.on_order_qty, 0) +
                                   NVL(c_soq.on_hand_qty, 0));
                  ELSE
                    lv_soq_qty := 0;
                  END IF;
                END IF;
              END IF;

            END IF;
          END IF;

          UPDATE pt_soq_new
             SET soq_qty = NVL(lv_soq_qty, 0)
           WHERE ROWID = c_soq.ROWID;
        EXCEPTION
          WHEN OTHERS THEN
            po_errmsg := 'Error while calcuating the soq qty for part num :' ||
                         c_soq.part_num || SQLERRM;
            RAISE ex_error;
        END;
      END LOOP;
    END IF;
    -- End of new logic Rajeev

    FOR c_mul IN cr_soq_mul(NULL, pi_parent, pi_dealer, pi_loc_cd) LOOP
      ln_soq      := c_mul.soq_qty;
      lv_pack_qty := c_mul.min_ord_qty;

      IF (ln_soq MOD lv_pack_qty) <> 0 THEN
        ln_soq := CEIL(ln_soq / lv_pack_qty) * lv_pack_qty;
      END IF;

      IF ln_soq <= 0 THEN
        ln_soq := 0;
      END IF;

      BEGIN
        /*Added by Dp Swain on 22-APr-2026 for AOS part mismatch issue*/
                               /*  begin
                                   insert into aos_latest_part_mismatch
                                    (entry_source,
                                    parent_group,
                                    dealer_map_cd,
                                    loc_cd,
                                    root_part_number,
                                    part_num,
                                    LATEST_PART_NUM,
                                    created_date,
                                    process_code)
                                   values('PT_SOQ_MUL_TIL',
                                    pi_parent,
                                    pi_dealer,
                                    pi_loc_cd,
                                    c_mul.root_part_num,
                                    c_mul.part_num,
                                    c_mul.part_num,
                                    sysdate,
                                    'SP_CALULATE_SOQ_IMS' );
                     exception
                   when others then
                     null;
                 end;*/
        INSERT INTO PT_SOQ_MUL_TIL
          (dealer_map_cd,
           part_num,
           as_on_date,
           no_of_months,
           soq_qty,
           on_hand_qty,
           on_order_qty,
           safety_stock,
           min_stock,
           max_stock,
           created_by,
           created_date,
           part_desc,
           parent_group,
           loc_cd,
           amd_soq_qty,
           comp_fa,
           avg_consumption,
           stock_qty,
           root_part_num,
           part_family_age,
           po_reqd_yn, --Arpan 04-feb-14
           catg_cd) --against -DMSSPR-13090
        VALUES
          (pi_dealer,
           c_mul.part_num,
           pi_ason_dt,
           pi_months,
           ln_soq,
           c_mul.on_hand_qty,
           c_mul.on_order_qty,
           c_mul.safety_stock,
           c_mul.min_stock,
           c_mul.max_stock,
           pi_user,
           SYSDATE,
           c_mul.part_desc,
           pi_parent,
           pi_loc_cd,
           ln_soq,
           pi_comp_fa,
           c_mul.avg_consumption,
           c_mul.on_hand_qty,
           c_mul.root_part_num,
           c_mul.part_family_age,
           c_mul.po_reqd_yn,
           c_mul.catg_cd); ----changes against -DMSSPR-13090

      EXCEPTION
        WHEN VALUE_ERROR THEN
          po_errmsg := 'Width problem/Incompatible Data in inserting common SOQ for part ' ||
                       c_mul.part_num || ' :' || SQLERRM;
          RAISE ex_error;
        WHEN OTHERS THEN
          po_errmsg := 'Error inserting common SOQ for part ' ||
                       c_mul.part_num || ' :' || SQLERRM;
          RAISE ex_error;
      END;
    END LOOP;
  EXCEPTION
    WHEN ex_error THEN
      RAISE ex_error;
    WHEN OTHERS THEN
      po_errmsg := 'Error in inserting into SOQ for part ' || lv_part_num || ' :' ||
                   SQLERRM;
      RAISE ex_error;
  END;

  lv_step := 'After PT SOQ Insert';
  lv_step := 'Before SOQ Calculation';
  COMMIT;
EXCEPTION
  WHEN ex_error THEN
    po_errcd := 1;
    ROLLBACK;
  WHEN OTHERS THEN
    po_errmsg := 'SOQ process interrupted as -' || lv_part_num || ' - ' ||
                 lv_count || ' - ' || lv_step || ' - ' || SQLERRM;
    po_errcd  := 1;
    ROLLBACK;
END Sp_Calculate_Soq_Ims;

```

#### SP-033 - SP_INSERT_PM_PART_VAR

**Invoked From:**

- PK_VALIDATE_PARTS.pck [StoredProcedure: PK_VALIDATE_PARTS.UPDATE_ON_ORDER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Creates a new part variant record in PM_PART_VAR for a given dealer, location, and part number, enriching the insert with GST-related attributes (HS code and tax category) resolved from existing part master data, and then triggers a price update for the newly created variant via SP_UPDATE_PART_PRICE.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_PARENT_GROUP | VARCHAR2 | IN |
| P_DEALER | NUMBER | IN |
| P_LOC_CD | VARCHAR2 | IN |
| P_PART_NUM | VARCHAR2 | IN |
| P_CREATED_BY | VARCHAR2 | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_ERR_MSG | VARCHAR2 | OUT |
| P_ERR_CD | NUMBER | OUT |

---

**Dependencies**

- D2KWUTIL.CREATED_DATE ([SP-012](#SP-012--D2KWUTIL.CREATED_DATE)) - D2KWUTIL.pck (or .pld)
- SP_UPDATE_PART_PRICE ([SP-035](#SP-035--SP_UPDATE_PART_PRICE)) - standalone source file

---

**Step-by-Step Business Logic**

- Step 1 - Resolve the Principal Map Code (PRINCIPAL_MAP_CD) for the supplied dealer, location, and parent group by querying AM_DEALER_LOC. If no matching row is found or any exception occurs, the local variable LN_PMC remains NULL and processing continues.
- Step 2 - Retrieve the HS code (LV_HSN_CODE) and tax category (LV_TAX_CATG) from PM_PART by matching the part number against DEALER_MAP_CD values of either the dealer (P_DEALER) or the resolved principal map code (LN_PMC).
- Step 3 - If the primary PM_PART lookup returns NO_DATA_FOUND, attempt a fallback query against PM_PART using ROOT_PART_NUM instead of PART_NUM, again scoped to the same dealer/principal map code values, limiting to one row.
- Step 4 - If either the primary or fallback PM_PART query fails for any reason (NO_DATA_FOUND, TOO_MANY_ROWS, or any other exception), default LV_TAX_CATG to 'A'; LV_HSN_CODE is left as resolved (or NULL if unresolved).
- Step 5 - Insert a new row into PM_PART_VAR populated with the input parameters (parent group, dealer map code, location code, part number, created by), the current system date as the created date, a fixed ORDER_REASON_CD of 1, and the resolved LV_HSN_CODE and LV_TAX_CATG values.
- Step 6 - Call SP_UPDATE_PART_PRICE, passing P_PARENT_GROUP, P_DEALER, P_LOC_CD, LV_TAX_CATG, and P_PART_NUM to update the price record for the newly inserted part variant.
- Step 7 - Commit the transaction. If any unhandled exception occurs at any point, capture the error message in P_ERR_MSG and set P_ERR_CD to 1; no commit is issued in the exception path.

---
**Decision Points**

DP-001
Condition: Does AM_DEALER_LOC contain a row matching P_DEALER, P_LOC_CD, and P_PARENT_GROUP?
TRUE: LN_PMC is populated with the retrieved PRINCIPAL_MAP_CD and is used in subsequent PM_PART lookups.
FALSE (NO_DATA_FOUND, TOO_MANY_ROWS, or any other exception): LN_PMC remains NULL; processing continues with NULL as the principal map code candidate.

DP-002
Condition: Does PM_PART contain a row matching P_PART_NUM and DEALER_MAP_CD IN (P_DEALER, LN_PMC)?
TRUE: LV_HSN_CODE and LV_TAX_CATG are populated from the matched PM_PART row and used for the insert.
FALSE (NO_DATA_FOUND): The fallback lookup in DP-003 is attempted.

DP-003
Condition: (Fallback) Does PM_PART contain a row matching ROOT_PART_NUM = P_PART_NUM and DEALER_MAP_CD IN (P_DEALER, LN_PMC)?
TRUE: LV_HSN_CODE and LV_TAX_CATG are populated from the first matching row (ROWNUM <= 1).
FALSE (NO_DATA_FOUND, TOO_MANY_ROWS, or any other exception): LV_TAX_CATG is defaulted to 'A'; LV_HSN_CODE remains NULL.

DP-004
Condition: Does the primary PM_PART query (DP-002) raise TOO_MANY_ROWS or any other non-NO_DATA_FOUND exception?
TRUE: LV_TAX_CATG is defaulted to 'A'; the fallback query is not attempted.
FALSE: Normal resolution path (DP-002 / DP-003) proceeds.

---
**Database Interactions**

- DB-001 - Update PRICE - Updates existing rows in PRICE.
- DB-002 - Read AM_DEALER_LOC - Reads data from AM_DEALER_LOC for lookup or validation.
- DB-003 - Read PM_PART - Reads data from PM_PART for lookup or validation.
- DB-004 - Insert into PM_PART_VAR - Persists a new row into PM_PART_VAR using columns: parent group, dealer map cd, loc cd, part num, created by, created date, order reason cd, hs code, and 1 more column(s).
**Business Rules**

- BR-001 - The procedure executes as an autonomous transaction, meaning its INSERT and COMMIT are independent of any calling transaction context.
- BR-002 - ORDER_REASON_CD is always inserted with a fixed value of 1 for every new PM_PART_VAR record created by this procedure; it is not derived from any input parameter.
- BR-003 - The created date stored in PM_PART_VAR is always SYSDATE at the time of execution; no externally supplied date is accepted.
- BR-004 - GST tax category (PART_TAX_CD) defaults to 'A' whenever the part's tax attributes cannot be resolved from PM_PART, ensuring the insert always carries a valid tax category value.
- BR-005 - The part tax category resolved (or defaulted) at insert time is also passed directly to SP_UPDATE_PART_PRICE, ensuring price records are updated using the same tax category as the newly created variant row.
- BR-006 - Part tax attribute lookup considers both the direct dealer code (P_DEALER) and the principal map code (LN_PMC) derived from AM_DEALER_LOC, supporting scenarios where part master data is held under a principal rather than the local dealer.
- BR-007 - If the exact part number match in PM_PART fails, the procedure attempts resolution via ROOT_PART_NUM, accommodating part numbering hierarchies where variant parts reference a root part record.
- BR-008 - On any unhandled exception, the procedure surfaces the Oracle error message through P_ERR_MSG and sets P_ERR_CD to 1, providing a structured error signal to the caller without re-raising the exception.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
PROCEDURE SP_INSERT_PM_PART_VAR
/*
  $LOG: SP_INSERT_PM_PART_VAR.SQL,V $
  REVISION 1.2 2006/05/10 ANJIV
  ADDED PROCEDURE TO UPDATE PRICE AFTER CREATING PRICE

  REVISION 1.1  2004/08/21 06:00:45  SANJEEVKN
  AS OF 21 AUG, 04

  */
(P_PARENT_GROUP IN VARCHAR2,
 P_DEALER       IN NUMBER,
 P_LOC_CD       IN VARCHAR2,
 P_PART_NUM     IN VARCHAR2,
 P_CREATED_BY   IN VARCHAR2,
 P_ERR_MSG      OUT VARCHAR2,
 P_ERR_CD       OUT NUMBER) IS
  PRAGMA AUTONOMOUS_TRANSACTION; --ADDED BY ANJIV ON 10/05/2007
  LV_HSN_CODE PM_PART.HS_CODE%TYPE;---------Added against Gst Changes by Ravi
  LV_TAX_CATG PM_PART.PART_TAX_CD%TYPE;---------Added against Gst Changes by Ravi
  LN_PMC      AM_DEALER_LOC.PRINCIPAL_MAP_CD%TYPE;---------Added against Gst Changes by Ravi
BEGIN
  ---------begin---------------added BY Ravi for GST changes----------

  BEGIN
    SELECT PRINCIPAL_MAP_CD
      INTO LN_PMC
      FROM AM_DEALER_LOC
     WHERE DEALER_MAP_CD = P_DEALER
       AND LOC_CD = P_LOC_CD
       AND PARENT_GROUP = P_PARENT_GROUP;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      NULL;
    WHEN TOO_MANY_ROWS THEN
      NULL;
    WHEN OTHERS THEN
      NULL;
  END;
  BEGIN
    SELECT HS_CODE, PART_TAX_CD
      INTO LV_HSN_CODE, LV_TAX_CATG
      FROM PM_PART
     WHERE PART_NUM = P_PART_NUM
       AND DEALER_MAP_CD IN (P_DEALER, LN_PMC);
  EXCEPTION
        WHEN NO_DATA_FOUND THEN
          BEGIN
             SELECT HS_CODE, PART_TAX_CD
            INTO LV_HSN_CODE, LV_TAX_CATG
            FROM PM_PART
           WHERE ROOT_PART_NUM = P_PART_NUM
             AND DEALER_MAP_CD IN (P_DEALER, LN_PMC)
             AND ROWNUM<=1;
           EXCEPTION
                WHEN NO_DATA_FOUND THEN
                   LV_TAX_CATG:='A';
               WHEN TOO_MANY_ROWS THEN
                 LV_TAX_CATG:='A';
               WHEN OTHERS THEN
                 LV_TAX_CATG:='A';
           END;
   WHEN TOO_MANY_ROWS THEN
       LV_TAX_CATG:='A';
    WHEN OTHERS THEN
       LV_TAX_CATG:='A';
  END;
  ----------End ----------
  INSERT INTO PM_PART_VAR
    (PARENT_GROUP,
     DEALER_MAP_CD,
     LOC_CD,
     PART_NUM,
     CREATED_BY,
     CREATED_DATE,
     ORDER_REASON_CD,
     HS_CODE,---------Added against Gst Changes by Ravi
     PART_TAX_CD---------Added against Gst Changes by Ravi
     )
  VALUES
    (P_PARENT_GROUP,
     P_DEALER,
     P_LOC_CD,
     P_PART_NUM,
     P_CREATED_BY,
     SYSDATE,
     1,
     LV_HSN_CODE,
     LV_TAX_CATG);

  --PROCEDURE ADDED BY ANJIV ON 10-05-2006 TO UPDATE PRICE FOR NEWLY CREATED PART
  SP_UPDATE_PART_PRICE(P_PARENT_GROUP,
                       P_DEALER,
                       P_LOC_CD,
                       --NULL,----Comment by Ravi against GST changes
                       LV_TAX_CATG,
                       P_PART_NUM);
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    P_ERR_MSG := SQLERRM;
    P_ERR_CD  := 1;
END;

```

#### SP-034 - SP_SOQ_POPULATE_CONSUMPTION

**Invoked From:**

- pt_soq_ims_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

PART AND STOCK DETAILS (N/A / CN_SOQ)

---

**Purpose**

Populates consumption history, current stock, and on-order quantity for an entire part family (all parts sharing a common root part number) for use on the PART AND STOCK DETAILS screen (CN_SOQ). Given a root part number, the procedure first resolves all sibling part numbers in the family, then aggregates their monthly consumption figures across a caller-specified number of months, their net available stock, and their outstanding on-order quantity, returning the results to the calling form trigger.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| pi_dealer | number | IN |
| pi_principal | number | IN |
| pi_parent | varchar2 | IN |
| pi_loc | varchar2 | IN |
| pi_comp_fa | varchar2 | IN |
| pi_part_num | varchar2 | IN |
| pi_months | number | IN |
| pi_date | date | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| po_consumption | pk_plsql_table.num_tab | OUT |
| po_stock | number | OUT |
| po_on_order | number | OUT |
| po_errmsg | varchar2 | OUT |
| po_errcd | number | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Initialise the error code output (po_errcd := 0) to indicate a clean start.
- Step 2 - Build and open a dynamic ref cursor against PM_PART to retrieve all part numbers whose root_part_num matches pi_part_num and whose dealer_map_cd matches either pi_dealer or pi_principal, further filtered by pi_principal via principal_map_cd (multi-company constraint).
- Step 3 - Iterate the ref cursor, concatenating each retrieved part_num into a comma-separated, single-quoted string (lv_part_str) for use in subsequent IN-list queries.
- Step 4 - Strip the trailing comma from lv_part_str once the cursor loop is complete.
- Step 5 - If lv_part_str is NULL (no family members found), set po_errmsg to 'Root Part number <pi_part_num> not found' and po_errcd to 1; skip all further processing.
- Step 6 - If lv_part_str is NOT NULL, loop from j = 1 to pi_months. For each iteration, derive the month-year key (MMYY format) by applying ADD_MONTHS(pi_date, -(j-1)) against DUAL, then execute a dynamic query against PT_MONTHLY_CONSUMPTION to sum net_qty for the part family filtered by pi_parent, pi_dealer, pi_loc, and the derived month-year key; store the result in po_consumption(j).
- Step 7 - Execute a dynamic query against PM_STOCK to calculate net available stock as SUM(ls_stock_qty + os_stock_qty - alloc_qty - ls_float_qty - os_float_qty) for the part family, filtered by pi_parent, pi_dealer, pi_loc, and pi_comp_fa; store the result in po_stock.
- Step 8 - Execute a dynamic query against PM_PART_VAR to sum on_order_qty for the part family, filtered by pi_parent, pi_dealer, and pi_loc; store the result in po_on_order.
- Step 9 - If any unhandled exception occurs at any point, capture SQLERRM into po_errmsg and set po_errcd to 1.

---
**Decision Points**

DP-001

Condition:
lv_part_str IS NOT NULL (at least one part number belonging to the root part family was found in PM_PART).

TRUE:
Proceed to populate consumption history (po_consumption array), net stock (po_stock), and on-order quantity (po_on_order) by executing dynamic queries against PT_MONTHLY_CONSUMPTION, PM_STOCK, and PM_PART_VAR respectively.

FALSE:
Set po_errmsg to 'Root Part number <pi_part_num> not found' and po_errcd to 1; no consumption, stock, or on-order data is populated.

---

DP-002

Condition:
A record is FOUND when fetching from the PM_PART ref cursor during the loop iteration.

TRUE:
Append the retrieved part_num (single-quoted, comma-separated) to lv_part_str and continue looping.

FALSE:
Exit the fetch loop; no further part numbers are appended.

---

DP-003

Condition:
An unhandled exception is raised anywhere within the procedure body.

TRUE:
The WHEN OTHERS exception handler fires: po_errmsg is set to SQLERRM and po_errcd is set to 1.

FALSE:
Normal execution completes; po_errcd remains 0 (or 1 if set by the root-not-found branch).

---
**Database Interactions**

- DB-001 - Read PM_PART - Reads data from PM_PART for lookup or validation.
- DB-002 - Read DUAL - Reads data from DUAL for lookup or validation.
- DB-003 - Read PT_MONTHLY_CONSUMPTION - Reads data from PT_MONTHLY_CONSUMPTION for lookup or validation.
- DB-004 - Read PM_STOCK - Reads data from PM_STOCK for lookup or validation.
- DB-005 - Read PM_PART_VAR - Reads data from PM_PART_VAR for lookup or validation.
**Business Rules**

- BR-001 - A part belongs to the target family if its root_part_num matches pi_part_num AND its dealer_map_cd matches either pi_dealer or pi_principal AND its principal_map_cd matches pi_principal; all three conditions must be satisfied (multi-company constraint).
- BR-002 - Consumption data is retrieved for each of the pi_months most recent months ending at pi_date, working backwards one month per iteration using ADD_MONTHS with a negative offset; the resulting MMYY numeric key is used to match PT_MONTHLY_CONSUMPTION.month_year.
- BR-003 - Monthly consumption is aggregated as the SUM of net_qty across all family part numbers for a given month, parent group, dealer, and location; a NULL sum is treated as zero.
- BR-004 - Net available stock is calculated as SUM(ls_stock_qty + os_stock_qty - alloc_qty - ls_float_qty - os_float_qty) from PM_STOCK, scoped to the part family, parent group, dealer, location, and comp_fa; individual NULL component quantities are coerced to zero before summation.
- BR-005 - On-order quantity is the SUM of on_order_qty from PM_PART_VAR for the part family, scoped to parent group, dealer, and location; a NULL sum is treated as zero.
- BR-006 - If no part numbers are found for the given root part number, the procedure returns an error (po_errcd = 1) with a descriptive message and does not attempt to query consumption, stock, or on-order data.
- BR-007 - Any unhandled runtime exception results in po_errcd = 1 and po_errmsg containing the Oracle error message, ensuring the calling form can detect and surface the failure.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
procedure sp_soq_populate_consumption
/*
  $Log: SP_SOQ_POPULATE_CONSUMPTION.sql,v $
  Revision 1.3  2004/09/02 10:18:52  pankajj
  As on 02 Sep 2004, due to pm_stock comp_fa addition

  Revision 1.2  2004/08/25 08:51:05  pankajj
  As on Aug 25,2004

  Revision 1.1  2004/08/23 04:09:45  pankajj
  As on Aug 21,2004

  */
(pi_dealer      in number,
 pi_principal   in number,
 pi_parent      in varchar2,
 pi_loc         in varchar2,
 pi_comp_fa     in varchar2,
 pi_part_num    in varchar2,
 pi_months      in number,
 pi_date        in date,
 po_consumption out pk_plsql_table.num_tab,
 po_stock       out number,
 po_on_order    out number,
 po_errmsg      out varchar2,
 po_errcd       out number) is

  ln_mth      number := 0;
  ln_qty      number := 0;
  lv_sql      varchar2(2000);
  cur_root    sys_refcursor;
  lv_part_num pm_part.part_num%type;
  lv_part_str varchar2(1000);

BEGIN

  po_errcd := 0;

  /* Get all the parts belonging to the root part */

  lv_sql := 'select part_num from pm_part
              where (dealer_map_cd = :pi_dealer or
                               dealer_map_cd = :pi_principal)
                and root_part_num = :pi_part_num
                and principal_map_cd = :pi_principal  --Added by Rajeev for multi company changes
                ';
  open cur_root for lv_sql
    using pi_dealer, pi_principal, pi_part_num, pi_principal; --Added by Rajeev for multi company changes
  loop
    fetch cur_root
      into lv_part_num;
    if cur_root%found then
      lv_part_str := lv_part_str || '''' || lv_part_num || '''' || ',';
    end if;
    exit when cur_root%notfound;
  end loop;

  lv_part_str := substr(lv_part_str, 1, length(lv_part_str) - 1); --remove last comma

  if lv_part_str is not null then

    /* Get the consumption of all the parts of the family */
    for j in 1 .. pi_months loop
      select to_number(to_char(add_months(pi_date, - (j - 1)), 'MMYY'))
        into ln_mth
        from dual;

      lv_sql := 'select nvl(sum(net_qty),0)
          from pt_monthly_consumption
          where parent_group = :p_parent
        and dealer_map_cd = :p_dealer
        and loc_cd = :p_loc
        and part_num in (' || lv_part_str || ')
        and month_year = :ln_mth';

      execute immediate lv_sql
        into ln_qty
        using pi_parent, pi_dealer, pi_loc, ln_mth;
      po_consumption(j) := ln_qty;

    end loop;

    /* Get the stock of all the parts of the family */
    lv_sql := 'select nvl(sum(nvl(ls_stock_qty,0) + nvl(os_stock_qty,0) - nvl(alloc_qty,0)
                           - nvl(ls_float_qty,0) - nvl(os_float_qty,0)),0)
            from pm_stock
         where parent_group = :p_parent
         and dealer_map_cd = :p_dealer
         and loc_cd = :p_loc
         and comp_fa = :p_comp_fa
         and part_num in (' || lv_part_str || ')';

    execute immediate lv_sql
      into po_stock
      using pi_parent, pi_dealer, pi_loc, pi_comp_fa;

    /* Get the on hand qty of all the parts of the family */
    lv_sql := 'select nvl(sum(on_order_qty),0) from pm_part_var
           where parent_group = :p_parent
         and dealer_map_cd = :p_dealer
         and loc_cd = :p_loc
         and part_num in (' || lv_part_str || ')';

    execute immediate lv_sql
      into po_on_order
      using pi_parent, pi_dealer, pi_loc;
  else
    po_errmsg := 'Root Part number ' || pi_part_num || ' not found';
    po_errcd  := 1;
  end if;

EXCEPTION
  when others then
    po_errmsg := sqlerrm;
    po_errcd  := 1;
END;

```

#### SP-035 - SP_UPDATE_PART_PRICE

**Invoked From:**

- SP_INSERT_PM_PART_VAR.prc [StoredProcedure: SP_INSERT_PM_PART_VAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Updates pricing and tax information on the PM_PART_VAR record for a given part, dealer, location, and parent group. The procedure retrieves the most current purchase price and MRP from principal price master or MRP tables (depending on dealer type), resolves the applicable part tax code, and applies those values to the part variant record. For mass-update dealer locations, it additionally flags the corresponding PI_PM_PART_MRP row to prevent duplicate reprocessing.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_parent | VARCHAR2 | IN |
| p_dealer | NUMBER | IN |
| p_loc_cd | VARCHAR2 | IN |
| p_part_tax_cd | VARCHAR2 | IN |
| p_part_num | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Retrieve dealer location attributes: query AM_DEALER_LOC using the supplied parent group, dealer map code, and location code to obtain the consignment code (lv_consg_cd), dealer type (lv_dlr_type), and principal map code (ln_pmc). Exceptions are silently suppressed; all three variables remain NULL if no matching row is found.
- Step 2 - Determine purchase price and MRP based on dealer type:
  - Step 2a - If lv_consg_cd is populated AND dealer type is not 'M': query PI_PART_PRICE_MASTER for the row matching the consignment code, part number, and principal map code with the latest revision_date. Populate lv_purchase_price and lv_mrp_1 from that row; default both to 0 on any exception.
  - Step 2b - If lv_consg_cd is populated AND dealer type is 'M': query PI_PM_PART_MRP for the row matching the part number and principal map code with the latest EFF_FROM_DT. Populate lv_mrp_1 from the mrp column; default to 0 on any exception. lv_purchase_price is not set (remains uninitialised / 0).
  - Step 2c - If lv_consg_cd is NULL: set both lv_purchase_price and lv_mrp_1 to 0.
- Step 3 - Resolve the part tax code: if p_part_tax_cd was not supplied (IS NULL), query PM_PART for the part_tax_cd of the matching part number and dealer/principal map code. On any exception, lv_tax_cd is set to NULL.
- Step 4 - Guard on MRP value: only proceed with the PM_PART_VAR update if lv_mrp_1 is greater than zero.
- Step 5 - Update PM_PART_VAR for non-mass dealer (lv_dlr_type != 'M'): build and execute a dynamic UPDATE statement that sets purchase_price, mrp_1, part_tax_cd, warranty_tax_cd, and UPDATED_DATE for the matching parent group, dealer, location, and part number.
- Step 6 - Update PM_PART_VAR for mass dealer (lv_dlr_type = 'M'): build and execute a dynamic UPDATE statement that sets mrp_1, part_tax_cd, warranty_tax_cd, and UPDATED_DATE (purchase_price is excluded) for the same key columns.
- Step 7 - Flag MRP row as processed (mass dealer only): update PI_PM_PART_MRP setting mass_update = 'Y' for the part number and principal map code, marking the MRP record as already applied.

---
**Decision Points**

DP-001

Condition: lv_consg_cd (consignment code retrieved from AM_DEALER_LOC) IS NOT NULL.

TRUE: Proceed to determine pricing data from either PI_PART_PRICE_MASTER or PI_PM_PART_MRP depending on dealer type (see DP-002).

FALSE: Set lv_purchase_price = 0 and lv_mrp_1 = 0; skip all price lookups.

---

DP-002

Condition: lv_dlr_type (dealer type from AM_DEALER_LOC) is not equal to 'M'.

TRUE: Fetch purchase_price and mrp_1 from PI_PART_PRICE_MASTER using the latest revision_date for the consignment code, part number, and principal map code.

FALSE (dealer type = 'M'): Fetch mrp from PI_PM_PART_MRP using the latest EFF_FROM_DT for the part number and principal map code; purchase_price is not retrieved.

---

DP-003

Condition: p_part_tax_cd input parameter IS NULL.

TRUE: Query PM_PART to derive the part_tax_cd for the given part number and dealer/principal map code and use it as lv_tax_cd.

FALSE: Use the caller-supplied p_part_tax_cd value as lv_tax_cd without further lookup.

---

DP-004

Condition: lv_mrp_1 > 0.

TRUE: Proceed to update PM_PART_VAR (and, for mass dealers, PI_PM_PART_MRP).

FALSE: Skip all UPDATE statements; no changes are made to any table.

---

DP-005

Condition: lv_dlr_type is not equal to 'M' (evaluated inside the MRP > 0 guard).

TRUE: Execute the non-mass UPDATE on PM_PART_VAR, which includes purchase_price in addition to mrp_1, part_tax_cd, warranty_tax_cd, and UPDATED_DATE.

FALSE (dealer type = 'M'): Execute the mass-dealer UPDATE on PM_PART_VAR (mrp_1, part_tax_cd, warranty_tax_cd, UPDATED_DATE only), then set mass_update = 'Y' on the corresponding PI_PM_PART_MRP row.

---
**Database Interactions**

- DB-001 - Read AM_DEALER_LOC - Reads data from AM_DEALER_LOC for lookup or validation.
- DB-002 - Read PI_PART_PRICE_MASTER - Reads data from PI_PART_PRICE_MASTER for lookup or validation.
- DB-003 - Read PI_PM_PART_MRP - Reads data from PI_PM_PART_MRP (columns: mass update) for lookup or validation.
- DB-004 - Read PM_PART - Reads data from PM_PART for lookup or validation.
- DB-005 - Read AM_DEALER_LOC_PARAM - Reads data from AM_DEALER_LOC_PARAM for lookup or validation.
- DB-006 - Update PM_PART_VAR - Updates existing rows in PM_PART_VAR (columns: purchase price, ls sell price, os sell price, mrp 1, part tax cd, warranty tax cd, updated date).
- DB-007 - Update PI_PM_PART_MRP - Updates existing rows in PI_PM_PART_MRP (columns: mass update).
**Business Rules**

- BR-001 - Dealer location resolution is mandatory before pricing: the procedure must successfully identify the consignment code, dealer type, and principal map code from AM_DEALER_LOC using the combined key (parent_group, dealer_map_cd, loc_cd). If no row is found, all price values default to zero and no price master lookup is attempted.
- BR-002 - Price master lookup is scoped to the most recent revision: when fetching from PI_PART_PRICE_MASTER, only the row with the maximum revision_date for the same part number, consignment code, and principal map code is used, ensuring the current price is applied.
- BR-003 - MRP for mass-update locations is sourced from PI_PM_PART_MRP: for dealer type 'M', the MRP is taken from the PI_PM_PART_MRP row with the maximum EFF_FROM_DT for the part number and principal map code, not from PI_PART_PRICE_MASTER.
- BR-004 - Purchase price is not updated for mass-update dealer locations: the PM_PART_VAR UPDATE for dealer type 'M' explicitly excludes the purchase_price column; only mrp_1, part_tax_cd, warranty_tax_cd, and UPDATED_DATE are written.
- BR-005 - A zero or missing MRP suppresses all updates: if lv_mrp_1 is not greater than zero after all lookups, neither PM_PART_VAR nor PI_PM_PART_MRP is modified, preventing the application of invalid pricing data.
- BR-006 - Tax code defaults to the part master value when not supplied by the caller: if p_part_tax_cd is NULL, the procedure derives lv_tax_cd from PM_PART for the given part number and dealer/principal map code; if that lookup also yields no data, lv_tax_cd is set to NULL.
- BR-007 - The same tax code is applied to both part_tax_cd and warranty_tax_cd: a single resolved tax code (lv_tax_cd) is written to both columns on PM_PART_VAR in every update path.
- BR-008 - Mass-update MRP rows are flagged after application: upon successfully updating PM_PART_VAR for a mass-update dealer, the corresponding PI_PM_PART_MRP row is marked mass_update = 'Y' to indicate the MRP has been consumed, preventing duplicate processing.
- BR-009 - All price lookups are principal-map-code scoped: every query against PI_PART_PRICE_MASTER and PI_PM_PART_MRP includes a filter on principal_map_cd = ln_pmc, enforcing multi-company data isolation.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
PROCEDURE        Sp_Update_Part_Price (
                                                  p_parent        VARCHAR2,
                                                  p_dealer        NUMBER,
                                                  p_loc_cd        VARCHAR2,
                                                  p_part_tax_cd   VARCHAR2,
                                                  p_part_num      VARCHAR2
                                                 )
IS
      lv_ls               NUMBER;
      lv_os               NUMBER;
      TYPE t IS REF CURSOR;
      t1                  t;
      lv_parent           VARCHAR2 (2000)                   := p_parent;
      lv_dealer           NUMBER                            := p_dealer;
      lv_loc_cd           VARCHAR2 (2000)                   := p_loc_cd;
      lv_sql              VARCHAR2 (2500);
      lv_tax_cd           VARCHAR2 (100)                    := p_part_tax_cd;
      lv_created_date     DATE;
      lv_modified_date    DATE;
      lv_updated_date     DATE;
      lv_consg_cd         am_dealer_loc.consg_cd%TYPE;
      lv_purchase_price   pm_part_var.purchase_price%TYPE;
      lv_mrp_1            pm_part_var.mrp_1%TYPE;
      lv_dlr_type         am_dealer_loc.dealer_type%type; -- Added by Rajeev
      ln_pmc              am_dealer_loc.principal_map_cd%type; --Added by Rajeev for multi company changes
BEGIN
      BEGIN
            SELECT consg_cd, dealer_type, principal_map_cd
              INTO lv_consg_cd, lv_dlr_type, ln_pmc
              FROM am_dealer_loc
             WHERE dealer_map_cd = p_dealer
               AND loc_cd = p_loc_cd
               AND parent_group = p_parent;
      EXCEPTION
            WHEN NO_DATA_FOUND THEN
                  NULL;
            WHEN TOO_MANY_ROWS THEN
                  NULL;
            WHEN OTHERS THEN
                  NULL;
      END;
      IF lv_consg_cd IS NOT NULL THEN
        IF lv_dlr_type != 'M' then -- If conditin added by rajeev
            BEGIN
                  SELECT purchase_price,
                         mrp_1
                    INTO lv_purchase_price,
                         lv_mrp_1
                    FROM PI_PART_PRICE_MASTER pi
                   WHERE consg_cd = lv_consg_cd
                     AND part_num = p_part_num
                     AND pi.principal_map_cd = ln_pmc  --Added by Rajeev for multi company changes
                     AND revision_date = (SELECT MAX ( revision_date)
                                            FROM PI_PART_PRICE_MASTER
                                           WHERE part_num = pi.part_num
                                             AND consg_cd = pi.consg_cd
                                             AND principal_map_cd = pi.principal_map_cd --Added by Rajeev for multi company changes
                                           );
            EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                        lv_purchase_price := 0;
                        lv_mrp_1 := 0;
                  WHEN TOO_MANY_ROWS THEN
                        lv_purchase_price := 0;
                        lv_mrp_1 :=0;
                  WHEN OTHERS THEN
                        lv_purchase_price := 0;
                        lv_mrp_1 := 0;
            END;
         ELSIF lv_dlr_type = 'M' THEN -- below else block added by rajeev for updated mrp for mass location
            BEGIN
                  SELECT mrp
                    INTO lv_mrp_1
                    FROM pi_pm_part_mrp pi
                   WHERE part_num = p_part_num
                     AND principal_map_cd = ln_pmc  --Added by Rajeev for multi company changes AND EFF_FROM_DT =
                    /****begin********below code added by added by ravi 0411201 **/
										 AND EFF_FROM_DT=(SELECT MAX(EFF_FROM_DT)
                        FROM PI_PM_PART_MRP
                       WHERE PART_NUM = PI.PART_NUM
                         AND PRINCIPAL_MAP_CD = PI.PRINCIPAL_MAP_CD)
											/***end********added by ravi 0411201 **/
                     --AND nvl(mass_update,'N') = 'N'
                     ;
            EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                        lv_mrp_1 := 0;
                  WHEN TOO_MANY_ROWS THEN
                        lv_mrp_1 :=0;
                  WHEN OTHERS THEN
                        lv_mrp_1 := 0;
            END;
         END IF;
      ELSE
            lv_purchase_price := 0;
            lv_mrp_1 := 0;
      END IF;

     IF p_part_tax_cd IS NULL THEN
            BEGIN
              select part_tax_cd
              into lv_tax_cd
              from pm_part
              where dealer_map_cd in (lv_dealer,ln_pmc)
                and part_num=p_part_num;
   /*                SELECT sp_stax_cd
                    INTO lv_tax_cd
                    FROM am_dealer_loc_param
                   WHERE parent_group = lv_parent
                     AND dealer_map_cd = lv_dealer
                     AND loc_cd = lv_loc_cd;*/ ---Commented by Ravi against gst changes
            EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                        lv_tax_cd := NULL;
                  WHEN TOO_MANY_ROWS THEN
                        lv_tax_cd := NULL;
                  WHEN OTHERS THEN
                        lv_tax_cd := NULL;
            END;
      END IF;
--      DBMS_OUTPUT.put_line (lv_parent || lv_dealer || lv_loc_cd || lv_tax_cd || p_part_num);
   --   Sp_Get_Selling_Price (lv_parent, lv_dealer, lv_loc_cd, lv_tax_cd, lv_mrp_1,lv_ls, lv_os);
 --     DBMS_OUTPUT.put_line ('LS factor ' || lv_ls || ' - ' || 'OS factor ' || lv_os);
     IF lv_mrp_1>0 then-----------22072017
     IF lv_dlr_type != 'M' then
      lv_sql :=
               'UPDATE PM_PART_VAR SET purchase_price =nvl('
            || lv_purchase_price || ',0)'
           /* || ',0),LS_SELL_PRICE='         -----------blocked by rohit 12.06.2017(GST chages)------
            || lv_ls
            || ',OS_SELL_PRICE='
            || lv_os  */                       ----------------------
            || ',mrp_1=nvl('---------rohit 01/07/2017
            || lv_mrp_1
            || ',0)'
            ||',part_tax_cd='''
            || lv_tax_cd
            ||''',warranty_tax_cd='''
            || lv_tax_cd
            || ''',UPDATED_DATE=TO_DATE('''
            || TO_CHAR (SYSDATE, 'DD-MON-RRRR HH24:MI:SS')
            || ''','
            || '''DD-MON-RRRR HH24:MI:SS'')
          WHERE PARENT_GROUP='''
            || lv_parent
            || ''' AND DEALER_MAP_CD='
            || lv_dealer
            || ' AND LOC_CD='''
            || lv_loc_cd
            || ''''
            || ' and part_num='''
            || p_part_num
            || '''';
	-- dbms_output.put_line(lv_sql);
       EXECUTE IMMEDIATE lv_sql;
     ELSIF lv_dlr_type = 'M' THEN
      lv_sql :=
              'UPDATE PM_PART_VAR SET'
         /*  || 'LS_SELL_PRICE='              -----------blocked by rohit 12.06.2017(GST chages)------
            || lv_ls
            || ',OS_SELL_PRICE='
           || lv_os
            || ',mrp_1=nvl('  */              ----------------
            || ' mrp_1=nvl('  ---- rohit 01/07/2017
            || lv_mrp_1
            || ',0), part_tax_cd='''
            || lv_tax_cd
            ||''',warranty_tax_cd='''     -- Modified by Anand on 06-11-2017
            || lv_tax_cd
            || ''',UPDATED_DATE=TO_DATE('''
            || TO_CHAR (SYSDATE, 'DD-MON-RRRR HH24:MI:SS')
            || ''','
            || '''DD-MON-RRRR HH24:MI:SS'')
          WHERE PARENT_GROUP='''
            || lv_parent
            || ''' AND DEALER_MAP_CD='
            || lv_dealer
            || ' AND LOC_CD='''
            || lv_loc_cd
            || ''''
            || ' and part_num='''
            || p_part_num
            || '''';
	 dbms_output.put_line(lv_sql);
       EXECUTE IMMEDIATE lv_sql;
        UPDATE pi_pm_part_mrp
           SET mass_update = 'Y'
         WHERE part_num = p_part_num
           AND principal_map_cd = ln_pmc;  --Added by Rajeev for multi company changes
     END IF;
     END IF;
		-- dbms_output.put_line(lv_sql);
END;

```

#### SP-036 - SP_UPDATE_PO_NUMBER_NEW

**Invoked From:**

- pt_soq_ims_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

PO DETAILS (N/A / CN_PARTY)

---

**Purpose**

Maintains the Purchase Order sequence counter in PM_NUMBER_GEN for a given combination of parent group, principal, dealer, location, financial year, and PO type. When a matching SPO voucher-number row already exists for the current month, the procedure increments its counter by one. When no matching row exists, it seeds a new counter record starting at 1, ensuring uninterrupted PO number generation across all dealer/principal combinations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_parent_group | VARCHAR2 | IN |
| p_principal_cd | NUMBER | IN |
| p_comp_fa | VARCHAR2 | IN |
| p_dealer | VARCHAR2 | IN |
| p_loc_cd | VARCHAR2 | IN |
| p_user_name | VARCHAR2 | IN |
| p_po_type | VARCHAR2 | IN |
| p_po_desc | VARCHAR2 | IN |
| p_fin_year | NUMBER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_err_msg | VARCHAR2 | OUT |
| p_err_cd | NUMBER | OUT |

---

**Dependencies**

- D2KWUTIL.CREATED_DATE ([SP-012](#SP-012--D2KWUTIL.CREATED_DATE)) - D2KWUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive all identifying context for the PO number slot: parent group, principal code, dealer code, location code, financial year, PO type, PO description, and the current user name.
- Step 2 - Derive the voucher month key by concatenating the input financial year (p_fin_year) with the current calendar month extracted from SYSDATE, left-padded to two digits (e.g., '202405').
- Step 3 - Attempt to UPDATE PM_NUMBER_GEN: increment VOU_NUM_GEN by 1 for the row that matches parent_group, principal_map_cd, dealer_map_cd, loc_cd, comp_fa, vou_type (= p_po_type), doc_type (= 'SPO'), and the derived vou_month.
- Step 4 - Evaluate SQL%ROWCOUNT after the UPDATE. If one or more rows were affected, processing is complete and p_err_cd / p_err_msg remain at their default (success) values.
- Step 5 - If SQL%ROWCOUNT = 0 (no existing row found), INSERT a new row into PM_NUMBER_GEN with vou_num_gen initialised to 1, doc_type fixed as 'SPO', doc_desc set from p_po_desc, created_by set from p_user_name, and created_date set to SYSDATE.
- Step 6 - If any exception occurs during the INSERT (VALUE_ERROR, DUP_VAL_ON_INDEX, or OTHERS), populate p_err_msg with a prefixed diagnostic message (prefix '1') and set p_err_cd to 1 to signal failure to the caller.
- Step 7 - If any exception occurs at the outer block level (covering the UPDATE or surrounding logic), populate p_err_msg with a prefixed diagnostic message (prefix '2') and set p_err_cd to 1.

---
**Decision Points**

DP-001

Condition: SQL%ROWCOUNT = 0 after the UPDATE on PM_NUMBER_GEN (i.e., no existing voucher-number row matches the supplied parent group, principal, dealer, location, comp FA, PO type, doc type 'SPO', and derived voucher month).

TRUE: A new row is inserted into PM_NUMBER_GEN with vou_num_gen = 1, seeding the counter for this combination for the current month.

FALSE: The UPDATE has already incremented the existing counter by 1; no INSERT is performed and processing ends successfully.

DP-002

Condition: An exception (VALUE_ERROR, DUP_VAL_ON_INDEX, or OTHERS) is raised within the INSERT block (inner exception handler).

TRUE: p_err_cd is set to 1 and p_err_msg is populated with a '1'-prefixed diagnostic string describing the error; execution exits the procedure in an error state.

FALSE: The INSERT completes without error; p_err_cd and p_err_msg retain their default success values.

DP-003

Condition: An exception (VALUE_ERROR, DUP_VAL_ON_INDEX, or OTHERS) is raised at the outer block level (covering the UPDATE statement or outer logic).

TRUE: p_err_cd is set to 1 and p_err_msg is populated with a '2'-prefixed diagnostic string describing the error; execution exits the procedure in an error state.

FALSE: No outer-block exception occurs; procedure completes normally.

---
**Database Interactions**

- DB-001 - Update PM_NUMBER_GEN - Updates existing rows in PM_NUMBER_GEN (columns: dealer map cd, principal map cd, loc cd, comp fa, doc type, vou type, vou month, vou num gen, and 4 more column(s)).
- DB-002 - Insert into PM_NUMBER_GEN - Persists a new row into PM_NUMBER_GEN using columns: dealer map cd, principal map cd, loc cd, comp fa, doc type, vou type, vou month, vou num gen, and 4 more column(s).
**Business Rules**

- BR-001 - The document type for all records managed by this procedure is fixed as 'SPO' (Supplier Purchase Order); no other doc_type value is written or updated.
- BR-002 - The voucher month key is always derived at runtime by concatenating the caller-supplied financial year (p_fin_year) with the two-digit current calendar month from SYSDATE (LPAD(TO_CHAR(SYSDATE,'MM'),2,0)), ensuring the counter is scoped to a specific financial-year/calendar-month period.
- BR-003 - The procedure follows an update-first, insert-if-missing (upsert) pattern: an UPDATE is always attempted before an INSERT, preventing duplicate row creation under normal concurrent conditions.
- BR-004 - When a new counter row is seeded, vou_num_gen must be initialised to 1, representing the first PO number issued for that combination in the period.
- BR-005 - The created_date column on a newly inserted PM_NUMBER_GEN row must be populated with SYSDATE at the time of insertion; no external date utility is used for this value.
- BR-006 - On any data-width, duplicate-key, or unexpected database error during INSERT, the procedure must return p_err_cd = 1 and a descriptive p_err_msg prefixed with '1' so the calling form can distinguish inner-block failures.
- BR-007 - On any data-width, duplicate-key, or unexpected database error at the outer block level, the procedure must return p_err_cd = 1 and a descriptive p_err_msg prefixed with '2' so the calling form can distinguish outer-block failures.
- BR-008 - The uniqueness of a PM_NUMBER_GEN counter row is determined by the combination of parent_group, principal_map_cd, dealer_map_cd, loc_cd, comp_fa, doc_type, vou_type, and vou_month; all eight attributes must match for an UPDATE to succeed.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
Procedure Sp_Update_Po_Number_New
/*
$Log: SP_UPDATE_PO_NUMBER.sql,v $
Revision 1.3  2005/02/23 11:30:07  vidyah
exception handling
Revision 1.1  2004/08/21 05:50:58  sanjeevkn
As of 21 Aug, 04
*/
(
      p_parent_group         VARCHAR2,
      p_principal_cd         NUMBER,
      p_comp_fa              VARCHAR2,
      p_dealer               VARCHAR2,
      p_loc_cd               VARCHAR2,
      p_user_name            VARCHAR2,
      p_po_type              VARCHAR2,
      p_po_desc              VARCHAR2,
      p_fin_year             NUMBER,
      p_err_msg        OUT   VARCHAR2,
      p_err_cd         OUT   NUMBER
)
IS
BEGIN
      UPDATE pm_number_gen
         SET vou_num_gen = vou_num_gen + 1
       WHERE parent_group = p_parent_group
         AND principal_map_cd = p_principal_cd
         AND dealer_map_cd = p_dealer
         AND loc_cd = p_loc_cd
         AND doc_type = 'SPO'
         AND comp_fa = p_comp_fa
         AND vou_month = p_fin_year || LPAD (TO_CHAR (SYSDATE, 'MM'), 2, 0)
         AND vou_type = p_po_type;

      IF SQL%ROWCOUNT = 0 THEN

	  BEGIN
            INSERT INTO pm_number_gen
                        (dealer_map_cd,
                         principal_map_cd,
                         loc_cd,
                         comp_fa,
                         doc_type,
                         vou_type,
                         vou_month,
                         vou_num_gen,
                         parent_group,
                         doc_desc,
                         created_by,
                         created_date
                        )
                 VALUES (p_dealer,
                         p_principal_cd,
                         p_loc_cd,
                         p_comp_fa,
                         'SPO',
                         p_po_type,
                         p_fin_year || LPAD (TO_CHAR (SYSDATE, 'MM'), 2, 0),
                         1,
                         p_parent_group,
                         p_po_desc,
                         p_user_name,
                         SYSDATE
                        );
   EXCEPTION
      WHEN VALUE_ERROR THEN
            p_err_msg := '1 Width problem/Incompatible data while updating vou_num_gen ';
            p_err_cd := 1;
      WHEN DUP_VAL_ON_INDEX THEN
            p_err_msg := '1 Trying to create duplicate data';
            p_err_cd := 1;
      WHEN OTHERS THEN
            p_err_msg := '1 Execution failed while updating vou_num_gen ' || SQLERRM;
            p_err_cd := 1;
	  END;
      END IF;
EXCEPTION
      WHEN VALUE_ERROR THEN
            p_err_msg := '2 Width problem/Incompatible data while updating vou_num_gen ';
            p_err_cd := 1;
      WHEN DUP_VAL_ON_INDEX THEN
            p_err_msg := '2 Trying to create duplicate data';
            p_err_cd := 1;
      WHEN OTHERS THEN
            p_err_msg := '2 Execution failed while updating vou_num_gen ' || SQLERRM;
            p_err_cd := 1;
END;

```

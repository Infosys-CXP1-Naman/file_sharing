# BUSINESS REQUIREMENTS DOCUMENT

## Table of Contents

- 1. Document Control
  - 1.1 Document Information
  - 1.2 Revision History
- 2. Executive Summary
  - Key Stakeholders
- 3. System Context
- 4. Functional Requirements
  - 4.1 Business Requirements
    - Requirement ID: BR-001
    - Requirement ID: BR-002
    - Business Scenarios - How the filter fields differ by search type
    - Requirement ID: BR-003
    - Requirement ID: BR-004
    - Requirement ID: BR-005
    - Business Scenarios - How results differ by search type
    - Requirement ID: BR-006
    - Business Scenarios - How the export data differs by search type
    - Requirement ID: BR-007
    - Requirement ID: BR-008
    - Requirement ID: BR-009
- 5. Business Rules Catalogue
- 6. Data Requirements
  - 6.1 Business Entities and Relationships
    - Mass Order Header - PH_PO_MASS
    - Mass Order Detail - PD_PO_MASS
    - Entity Relationships
  - 6.2 Data Capture Requirements
    - Search Criteria (Operations User / Dealer User - at search initiation)
    - Search Results (System - populated after search executes)
    - Session and Global Parameters (System - available at all times)
  - 6.3 Reference Data
  - 6.4 Data Lifecycle
  - 6.5 Excel Output Columns
- 7. Glossary
- 8. Technical Inventory
  - 8.1 Form Architecture
    - 8.1.1 Global Variables
    - 8.1.2 Form Parameters
  - 8.2 Blocks
    - 8.2.1 Block WhereClause and OrderByClause
  - 8.3 Items Summary
  - 8.4 List of Values
  - 8.5 Alerts
  - 8.6 Program Units
  - 8.7 Triggers
    - 8.7.1 Inactive / Commented-Out Trigger Register
  - 8.8 Canvas and Window Inventory
  - 8.9 Editors
  - 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups
    - 8.10.1 Visual Attributes (form-defined)
    - 8.10.2 Property Classes (form-defined)
    - 8.10.3 Object Groups
  - 8.11 DataSourceColumn Inventory
    - B_DTL (29 columns)
- 9. Object Library
- 10. Record Groups
- 11. Referenced Database Objects
- 12. Backend Procedures and Packages
  - 12.1 Main Flow Backend Procedure/Package Index
  - 12.2 Procedure and Package Catalogue
    - POPULATE_DETAILS
    - VIEW_EXCEL_REPORT_NEW
    - GENERAL.DISP_TEXT
    - GENERAL.RAISE_ERROR
    - GENERAL.ASK_CONFIRM
    - DBMS_APPLICATION_INFO.SET_CLIENT_INFO
    - DBMS_APPLICATION_INFO.SET_MODULE
    - SF_COPYRIGHT_DECLARATION
    - WEBUTIL_CORE.CUSTOMEVENTHANDLER
    - WEBUTIL.ID_NULL
    - WEB.SHOW_DOCUMENT *(Inactive - legacy code path only)*
- 13. Package Procedure Specifications
- 14. Database Package Catalogue
- 15. PLD Procedure Call Sites
  - DPL.pld (`general`)
  - Inactive / commented-only PLD call sites
  - webutil.pld (`WEBUTIL_CORE`)
  - webutil.pld (`WEBUTIL_C_API`)
- 16. Microservice API Candidates
  - 16.1 Microservices with APIs
- 17. Workflows
- 18. PLD-Backed Logic
  - webutil.pld (`CLIENT_IMAGE`)
  - DPL.pld (`general`)
  - D2kwutil.pld (`Win_API`)
- 19. PCK-Backed Logic
- 20. System Interfaces
  - 20.1 Database Integrations
  - 20.2 External System Integrations
  - 20.3 Report Integrations
    - 20.3.1 Parameters Passed to the Report
- 21. Procedure and Function Business Rule Catalogue
  - 21.1 Catalogue Index
  - 21.2 Detailed Specifications
    - SP-001 - POPULATE_DETAILS
    - SP-002 - D2KWUTIL.ATTEMPT_DLL_LOAD
    - SP-003 - D2KWUTIL.CHOOSEFILE
    - SP-004 - D2KWUTIL.D2KWUTIL_ACTIVEWIN
    - SP-005 - D2KWUTIL.D2KWUTIL_CHOOSEFILE
    - SP-006 - D2KWUTIL.D2KWUTIL_DEBUGSTRING
    - SP-007 - D2KWUTIL.D2KWUTIL_GETDOSENV
    - SP-008 - D2KWUTIL.D2KWUTIL_GETREGKEY
    - SP-009 - D2KWUTIL.D2KWUTIL_WINDIR
    - SP-010 - D2KWUTIL.GET_ACTIVE_WINDOW
    - SP-011 - D2KWUTIL.SAVE_FILE
    - SP-012 - D2KWUTIL.TRANSLATETYPE
    - SP-013 - GENERAL.ASK_CONFIRM
    - SP-014 - GENERAL.DISP_TEXT
    - SP-015 - GENERAL.RAISE_ERROR
    - SP-016 - WEBUTIL.BLOCKING
    - SP-017 - WEBUTIL.CHECKLIBS
    - SP-018 - WEBUTIL.CLEARCALLBACKTRIGGER
    - SP-019 - WEBUTIL.CLOSEBLOB
    - SP-020 - WEBUTIL.CLOSEFILE
    - SP-021 - WEBUTIL.DOWNLOADFROMURL
    - SP-022 - WEBUTIL.DOWNLOADFROMURLINT
    - SP-023 - WEBUTIL.ERROR
    - SP-024 - WEBUTIL.ERRORALERT
    - SP-025 - WEBUTIL.EXECUTE
    - SP-026 - WEBUTIL.FCLOSE
    - SP-027 - WEBUTIL.FILE_SAVE_DIALOG
    - SP-028 - WEBUTIL.FILE_SELECTION_DIALOG_INT
    - SP-029 - WEBUTIL.FOPEN
    - SP-030 - WEBUTIL.GETCALLBACKTRIGGER
    - SP-031 - WEBUTIL.GETCLIENTOSFAMILY
    - SP-032 - WEBUTIL.GETCLIENTSETTING
    - SP-033 - WEBUTIL.GETIMPLCLASS
    - SP-034 - WEBUTIL.GETLASTERROR
    - SP-035 - WEBUTIL.GETLASTERRORARGS
    - SP-036 - WEBUTIL.GETNUMBER
    - SP-037 - WEBUTIL.GETOSFAMILY
    - SP-038 - WEBUTIL.GETOUTPUT
    - SP-039 - WEBUTIL.GETPROPERTY
    - SP-040 - WEBUTIL.GETSTRING
    - SP-041 - WEBUTIL.GETVAR
    - SP-042 - WEBUTIL.GET_LINE
    - SP-043 - WEBUTIL.GET_RETURN_CODE
    - SP-044 - WEBUTIL.GET_STANDARD_OUTPUT
    - SP-045 - WEBUTIL.HOST
    - SP-046 - WEBUTIL.ID_NULL
    - SP-047 - WEBUTIL.INIT
    - SP-048 - WEBUTIL.INITWEBUTIL
    - SP-049 - WEBUTIL.ISERROR
    - SP-050 - WEBUTIL.IS_OPEN
    - SP-051 - WEBUTIL.LENGTH
    - SP-052 - WEBUTIL.LOG
    - SP-053 - WEBUTIL.POPULATEPROPERTYBUNDLE
    - SP-054 - WEBUTIL.PUTF
    - SP-055 - WEBUTIL.PUT_LINE
    - SP-056 - WEBUTIL.READFROMPROPERTYBUNDLE
    - SP-057 - WEBUTIL.READTRANSFROMMSGBUNDLE
    - SP-058 - WEBUTIL.REGISTERBEAN
    - SP-059 - WEBUTIL.REGISTER_FUNCTION
    - SP-060 - WEBUTIL.RELEASE_PROCESS
    - SP-061 - WEBUTIL.SETCLIENTSETTING
    - SP-062 - WEBUTIL.SETDATA
    - SP-063 - WEBUTIL.SETPROPERTY
    - SP-064 - WEBUTIL.SHOWBEANS
    - SP-065 - WEBUTIL.URL_TO_CLIENT
    - SP-066 - WEBUTIL.WRITEDATA
    - SP-067 - WEBUTIL_CORE.CUSTOMEVENTHANDLER
    - SP-068 - ADD_ERROR
    - SP-069 - ADD_EXTERNAL_ERRORS
    - SP-070 - BOOLTOCHAR
    - SP-071 - CLEAN_ERROR_STACK
    - SP-072 - DEBUGLOG
    - SP-073 - GET_ENVIRONMENT_STRING
    - SP-074 - GET_TEMP_DIRECTORY
    - SP-075 - GET_WINDOWS_DIRECTORY
    - SP-076 - READ_REGISTRY
    - SP-077 - REGISTER_FUNCTION_CALL
    - SP-078 - SETDEBUG
    - SP-079 - SF_COPYRIGHT_DECLARATION
    - SP-080 - STRIPDIRSEP
    - SP-081 - VIEW_EXCEL_REPORT_NEW
    - SP-082 - WINDEBUG

## 1. Document Control

### 1.1 Document Information

| Field | Value |
| ----- | ----- |
| Document Title | PR_MASS_ORDER - Business Requirements Document |
| Form Module Name | PR_MASS_ORDER |
| Document Version | 1.0 |
| Date Created | August 13, 2026 |
| Author/Prepared By | BRD Agent |

### 1.2 Revision History

| Version | Date | Author | Description |
| --- | --- | --- | --- |
| 1.0 | August 13, 2026 | BRD Agent | Initial draft |

---

## 2. Executive Summary

*High-level overview of the pr_mass_order form, its purpose, and roles referenced in the module.*

The **pr_mass_order** Oracle Forms module is the **Mass Order Inquiry** screen in the Dealer Management System. It enables dealership staff to search for and review mass purchase orders placed by a principal on behalf of a dealer location. The user selects a search mode - by order number, customer order number, or date range - then submits the search to load the list of matching mass order lines. Each line shows the purchase order number, order date, linked customer order, part number, part description, quantities ordered and issued, the carry-back order quantity, the order value, and distributor details. Once results are displayed, the user can export the entire result set to an Excel-compatible file for offline analysis and reporting.

### Key Stakeholders

*Who uses pr_mass_order*

| Stakeholder | Role |
| :--- | :--- |
| **Dealer / Dealership Staff** | Primary interactive user of this screen. Searches for mass purchase orders using the available filter modes, reviews the resulting order lines, and exports data to Excel when needed. |
| **Parts or Supply Chain Manager** | Reviews mass order quantities, values, and fulfilment status across purchase orders and linked customer orders for supply planning. |

---

---

## 3. System Context

*Describes the pr_mass_order module's role within the DMS ecosystem, scope, process flow, and key integrations.*

The **pr_mass_order** module is the **Mass Order Inquiry** screen within the Dealer Management System. It provides dealership staff with a consolidated view of mass purchase orders raised by a principal for a dealer location, and allows them to search those orders by three different criteria. It connects the purchasing activity with sales order fulfilment by displaying linked customer order information alongside each purchase order line.

**System purpose:** Allow authorised dealership users to search for and review mass purchase order lines by order number, customer order number, or date range - and to export the results to Excel - as implemented in the pr_mass_order Oracle Forms module.

**In scope:**

- Select a search mode: by purchase order number, by customer order (CO) number, or by order date range
- Enter and validate search criteria specific to the selected mode
- Search and retrieve matching mass purchase order lines from the purchase order master
- Display order details including purchase order number, date, type, customer order number and date, part number and description, ordered quantities, issued quantities, carry-back order quantities, order value, and distributor information
- Look up distributor name, location, and company details for each order line
- Look up the linked customer order date from the sales order master
- Look up the order type description from the application reference list
- Look up the part description from the parts master
- Export the current result set to an Excel-compatible CSV file for offline use
- Provide LOV popups to assist the user in selecting a valid order number or customer order number

**Process Name:** Mass Order Inquiry

**Process Owner:** Parts or Supply Chain Manager

**Process Objective:** Open the form, select a search mode, enter mandatory criteria, retrieve matching mass order lines with distributor and part details, and optionally export the results to Excel.

**Process Trigger:** Dealership staff need to review the status and details of mass purchase orders for a dealer location

**Process Flow:**

The complete mass order inquiry process follows this sequence. Each step corresponds to Functional Requirements in Section 4.

```
STEP 1 ── FORM OPENS
         The Mass Order Inquiry screen opens.
         Session context is registered and the search criteria panel is presented.
         The copyright notice is populated automatically.

STEP 2 ── SELECT SEARCH MODE
         User selects one of three search modes using the radio group:
         ├── ORDER NUMBER (O): the order number field is enabled; CO and date fields are cleared and disabled
         ├── CO NUMBER (C): the CO number field is enabled; order number and date fields are cleared and disabled
         └── DATE RANGE (D): from-date and to-date fields are enabled; order number and CO fields are cleared and disabled

STEP 3 ── ENTER SEARCH CRITERIA - ORDER NUMBER MODE
         User selects or types a purchase order number.
         An LOV popup is available to select from existing order numbers for the current dealer and location.
         The LOV also returns dealer map code, location code, order number, and order date.

STEP 4 ── ENTER SEARCH CRITERIA - CO NUMBER MODE
         User selects or types a customer order number.
         An LOV popup is available to select from existing CO numbers.
         The LOV also returns dealer description and location description.

STEP 5 ── ENTER SEARCH CRITERIA - DATE RANGE MODE
         User enters a from-date.
         System validates the from-date is not in the future.
         System automatically calculates the to-date as month-end or today, whichever is earlier.

STEP 6 ── VALIDATE TO-DATE
         System validates the to-date is not in the future and is not earlier than the from-date.
         An error is displayed if validation fails; the user must correct before proceeding.

STEP 7 ── SUBMIT SEARCH
         User clicks the Search button.
         System validates that the mandatory field for the selected mode is populated.
         ├── If validation fails: an error message is displayed and search is blocked until criteria are entered
         └── If validation passes: STEP 8 follows

STEP 8 ── RETRIEVE MASS ORDER LINES
         System queries the mass purchase order header and detail tables using the selected criteria
         filtered by the current dealer, location, and company context.
         Matching order lines are retrieved in order-type and order-number sequence.

STEP 9 ── POPULATE DISTRIBUTOR DETAILS
         For each retrieved order line, the system looks up the distributor parent group and
         company code from the dealer-location company master.

STEP 10 ── POPULATE CUSTOMER ORDER DATE
          System looks up the linked customer order date from the sales order header
          for each order line that has a linked customer order number.

STEP 11 ── POPULATE DISTRIBUTOR NAME AND LOCATION
          System retrieves the distributor name and location description from the dealer-location master.

STEP 12 ── POPULATE ORDER TYPE DESCRIPTION
          System retrieves the readable order type description from the application reference list
          for each order line.

STEP 13 ── POPULATE PART DESCRIPTION
          System retrieves the part description from the parts master for each part number in the result.

STEP 14 ── DISPLAY RESULTS
          Retrieved mass order lines are displayed in the result grid with all populated details.
          User can scroll through the results. No editing is permitted.

STEP 15 ── EXPORT TO EXCEL (optional)
          User clicks the Export button.
          System validates the same mandatory search criteria as for Search.
          ├── If validation fails: an error message is displayed
          └── If validation passes: system builds a dynamic export query for the selected mode,
                                    generates a CSV file, and opens it for download

STEP 16 ── EXIT
          User clicks Exit, OK, or the navigation bar Exit button to close the form.
          Session context is cleared and the form closes without saving.
```

**Major process interactions:**

- **Mass purchase order master** - primary source of order header and line data retrieved on search
- **Sales order master** - referenced to retrieve the customer order date for each linked order line
- **Dealer-location master** - provides distributor name and location description for each order line
- **Dealer-location company master** - maps distributor dealer-location to parent group and company code
- **Parts master** - provides part descriptions for each part number in the result
- **Application reference list** - provides human-readable order type descriptions
- **Excel export service** - generates and delivers a CSV file of the result set for offline use

---

---

## 4. Functional Requirements

### 4.1 Business Requirements

#### Requirement ID: BR-001

**Requirement Title:** Form Session Registration and Access Verification

**Business Description:**
When the mass order enquiry screen is opened, the system automatically registers the current user session with the module identifier for this screen, then initialises the display and verifies that the current user is a MASS-type dealer. Database administrators and monitoring tools can identify which application module is active in each database session. If the user is not a MASS-type dealer, the screen is closed immediately with an explanatory message so that only authorised users can proceed.

**Actors:** System

**Preconditions:**
- The user has launched the mass order enquiry module from the application menu.

**Main Flow:**

**Step 1 - Session registered with module identity before screen loads**
Before the screen becomes available for use, the system writes the fixed module name (`pr_mass_order`) and client identifier for this screen into the active database session. The registration is automatic and transparent to the user; no input is required and nothing is displayed on screen.

**Step 2 - Screen initialised and application identifier seeded**
When the form opens, the system maximises the main application window to fill the screen, suppresses low-priority informational messages, and populates the copyright notice display field. The system assigns the application identifier seed `global.app_id` the value `pr_mass_order` and copies it to the application-identifier parameter (`parameter.p_app_id`) so that downstream export and report processes can identify the calling module.

*Screen: Main screen (`WN_MAIN`).*

**Step 3 - Dealer type retrieved for access check**
The system looks up the dealer classification for the current session's parent group, dealer code, and location code from the dealer location master. If the dealer record is not found, the lookup silently returns without a value and the access check in the next step evaluates against a blank dealer type.

**Step 4 - Access restricted to MASS-type dealers**
The system checks whether the dealer type retrieved in the previous step is `M` (MASS). If the dealer type is any value other than `M`, the system displays the message *"Only MASS user can access this Screen"* and immediately closes the form without allowing any further interaction. Only users whose dealer account is classified as a MASS dealer are permitted to use this screen.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Dealer type must be MASS (M) | global.dlr_type != 'M' - WHEN-NEW-FORM-INSTANCE own condition | When the form opens and the dealer type has been retrieved | Restricts access to the mass order enquiry screen to MASS-type dealer accounts only | *"Only MASS user can access this Screen"* is displayed; form is closed immediately |

*Business outcomes (errors, warnings, success, and status):*
- **BR-001-ES-01** - Current user is not a MASS-type dealer - *"Only MASS user can access this Screen"*; the form closes immediately.

**Alternative Flows:**
- **BR-001-AF-01** - (from Step 4) Dealer type is not MASS: *"Only MASS user can access this Screen"* is displayed and the form closes without loading any search criteria or results.

---

---

#### Requirement ID: BR-002

**Requirement Title:** Search Type Selection and Filter Field Activation

**Business Description:**
The mass order enquiry screen offers three ways to look up orders: by a specific order number, by a specific sales order (CO) number, or by a date range. When the user selects a search type, the screen immediately adjusts to show only the input fields relevant to that type, clears any previously entered values in the fields that are no longer applicable, and sets default dates where the date-range option is chosen. This ensures the user cannot accidentally leave irrelevant criteria populated when switching between search types.

**Actors:** Operations User / Dealer User

**Preconditions:**
- The mass order enquiry screen is open and ready for input.

**Main Flow:**

**Step 1 - User selects the Order Number search type**
When the user selects "Order Number" as the search type, the system clears the CO Number, From Date, and To Date fields, disables those three fields so they cannot be edited, and enables the Order Number field so the user can enter a value. The Order Number field is also set as navigable and allows entry and modification.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

**Step 2 - User selects the CO Number search type**
When the user selects "CO Number" as the search type, the system clears the Order Number, From Date, To Date, Order Date, Order To, and Location Description fields, disables the Order Number, From Date, and To Date fields, and enables the CO Number field so the user can enter a value. The CO Number field is also set as navigable and allows entry and modification.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

**Step 3 - User selects the Date Range search type**
When the user selects "Date Range" as the search type, the system clears the CO Number, Order Number, Order Date, Order To, and Location Description fields, disables the CO Number and Order Number fields, enables the From Date and To Date fields so the user can enter values, and automatically sets a default date range: From Date is set to the first day of the current calendar month, and To Date is set to today's date.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

#### Business Scenarios - How the filter fields differ by search type

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Order Number search** | Order Number field is enabled and editable; CO Number, From Date, and To Date are cleared and disabled. |
| **CO Number search** | CO Number field is enabled and editable; Order Number, From Date, and To Date are cleared and disabled. Additional header fields (Order Date, Order To, Location Description) are also cleared. |
| **Date Range search** | From Date and To Date are enabled and editable with default values (first day of current month to today); CO Number and Order Number are cleared and disabled. Additional header fields (Order Date, Order To, Location Description) are also cleared. |

**Alternative Flows:**
- None.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Search Type (`RB_TYPE`) | Mandatory | Radio Group | 1 | N/A | `O` = Order Number, `C` = CO Number, `D` = Date Range | Screen is open | Must be one of the three valid search type values | N/A |
| Order Number (`CB_ORDER_NO`) | Conditional - when Order Number search type selected | Text | 25 | Order Number list (LOV_PO) | Order number from purchase order header | Search type set to Order Number | Enabled and navigable only when Order Number search type is active | N/A |
| CO Number (`CB_CO_NO`) | Conditional - when CO Number search type selected | Text | 25 | CO Number list (LOV_CO) | CO number from sales order header | Search type set to CO Number | Enabled and navigable only when CO Number search type is active | N/A |
| From Date (`FROM_DATE`) | Conditional - when Date Range search type selected | Date | DD/MM/RRRR | N/A | N/A | Search type set to Date Range | Enabled and navigable only when Date Range search type is active; auto-defaulted to first day of current month | N/A |
| To Date (`TO_DATE`) | Conditional - when Date Range search type selected | Date | DD/MM/RRRR | N/A | N/A | Search type set to Date Range | Enabled and navigable only when Date Range search type is active; auto-defaulted to today's date | N/A |

---

---

#### Requirement ID: BR-003

**Requirement Title:** From Date Validation and To Date Auto-Calculation

**Business Description:**
When the date-range search type is in use and the user enters a From Date, the system validates that the date entered is not in the future. If the date is valid, the system also automatically calculates and fills the To Date as the last day of the month following the From Date, unless that calculated date would be in the future - in that case, today's date is used instead. This prevents users from entering an invalid starting date and ensures the date range is reasonable for a one-month reporting window.

**Actors:** Operations User / Dealer User

**Preconditions:**
- The date-range search type has been selected on the screen.
- The user is entering a value in the From Date field.

**Main Flow:**

**Step 1 - From Date validated against today's date**
After the user enters a value in the From Date field, the system checks whether the entered date is later than today's date. If it is, the user sees the message *"From Date cannot be greater than Current Date"* and the field fails validation; the user must correct the date before proceeding.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| From Date must not be in the future | From Date > current date - WHEN-VALIDATE-ITEM own condition on CB_DUMMY.FROM_DATE | When the user leaves the From Date field after entering a value | Prevents future dates from being used as the start of a search range | *"From Date cannot be greater than Current Date"*; field validation fails and user must re-enter |

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-ES-01** - From Date entered is later than today - *"From Date cannot be greater than Current Date"*; the validation fails and focus remains on the From Date field.

**Step 2 - To Date automatically calculated from the From Date**
If the From Date passes validation, the system calculates a suggested To Date as the last calendar day of the month following the From Date. If that calculated date is also in the future, the To Date is set to today's date instead; otherwise the calculated last-day-of-next-month date is used. The To Date field is filled automatically without further user input.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

**Alternative Flows:**
- **BR-003-AF-01** - (from Step 1) From Date field is left blank: no validation runs and the To Date is not recalculated; the form remains in its current state.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| From Date (`FROM_DATE`) | Conditional - when Date Range search type selected | Date | DD/MM/RRRR | N/A | N/A | Date Range search type active | Must not be later than today's date | *"From Date cannot be greater than Current Date"*; field validation fails |
| To Date (`TO_DATE`) | Auto-populated | Date | DD/MM/RRRR | N/A | N/A | Valid From Date entered | System-calculated: last day of the month following From Date, or today if that date is in the future | N/A |

---

---

#### Requirement ID: BR-004

**Requirement Title:** To Date Validation

**Business Description:**
When the date-range search type is in use and the user enters or modifies the To Date, the system enforces three rules: the To Date must not be in the future, it must not be earlier than the From Date, and it must not be left blank when a From Date has already been entered. These rules together ensure that only valid, complete, and logically consistent date ranges are submitted for a search.

**Actors:** Operations User / Dealer User

**Preconditions:**
- The date-range search type has been selected on the screen.
- The user is entering or modifying a value in the To Date field.

**Main Flow:**

**Step 1 - To Date validated against today's date and From Date**
After the user enters a value in the To Date field, the system first checks whether the To Date is later than today's date. If it is, the user sees *"To Date cannot be greater than Current Date"* and the validation fails. If the To Date is not in the future, the system then checks whether it is earlier than the From Date. If it is, the user sees *"To Date cannot be less than From Date"* and the validation fails.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| To Date must not be in the future | To Date > current date - WHEN-VALIDATE-ITEM own condition on CB_DUMMY.TO_DATE | When the user leaves the To Date field after entering a value | Prevents future end-dates in the search range | *"To Date cannot be greater than Current Date"*; field validation fails |
| To Date must not be before From Date | To Date < From Date - WHEN-VALIDATE-ITEM own condition on CB_DUMMY.TO_DATE | When the user leaves the To Date field after entering a value | Ensures the date range is logically consistent | *"To Date cannot be less than From Date"*; field validation fails |

*Business outcomes (errors, warnings, success, and status):*
- **BR-004-ES-01** - To Date entered is later than today - *"To Date cannot be greater than Current Date"*; field validation fails.
- **BR-004-ES-02** - To Date is earlier than From Date - *"To Date cannot be less than From Date"*; field validation fails.

**Step 2 - To Date blank while From Date is populated**
If the user clears the To Date field while a From Date is already entered, the system shows *"To Date both can not be left black"* and the validation fails. The user must enter a To Date before proceeding.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| To Date is required when From Date is populated | From Date IS NOT NULL AND To Date IS NULL - WHEN-VALIDATE-ITEM own condition on CB_DUMMY.TO_DATE | When the user leaves the To Date field while it is blank and a From Date is already filled | Ensures a complete date range is always provided before search | *"To Date both can not be left black"*; field validation fails |

*Business outcomes (errors, warnings, success, and status):*
- **BR-004-ES-03** - To Date is blank while From Date has a value - *"To Date both can not be left black"*; field validation fails.

**Alternative Flows:**
- **BR-004-AF-01** - (from Step 1) To Date field is left blank and From Date is also blank: no validation runs; the form remains in its current state.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| To Date (`TO_DATE`) | Conditional - when Date Range search type selected | Date | DD/MM/RRRR | N/A | N/A | Date Range search type active; From Date entered | Must not be in the future; must not be before From Date; must not be blank when From Date is populated | *"To Date cannot be greater than Current Date"* / *"To Date cannot be less than From Date"* / *"To Date both can not be left black"* |
| From Date (`FROM_DATE`) | Conditional - when Date Range search type selected | Date | DD/MM/RRRR | N/A | N/A | Date Range search type active | Must be entered before the To Date validation applies | N/A |

---

---

#### Requirement ID: BR-005

**Requirement Title:** Mass Order Search and Results Population

**Business Description:**
When the user presses the Search button, the system validates that the required search criteria have been supplied for the chosen search type, then queries the order database and loads all matching mass order lines - showing order numbers, dates, CO numbers, CO dates, order types, distributor names and locations, part numbers and descriptions, quantities ordered and billed, back-order quantities, and back-order values - into the results grid on screen. If no records match the criteria, the user is informed that data is not available. If a system error occurs, the error detail is shown to the user.

**Actors:** Operations User / Dealer User

**Preconditions:**
- The mass order enquiry screen is open.
- The user has selected a search type and entered the required search criteria for that type.

**Main Flow:**

**Step 1 - Search criteria validated before retrieval**
When the user clicks the Search button, the system first checks that the required criterion for the active search type has been supplied: for the date-range type, From Date must not be blank; for the CO Number type, a CO Number must be entered; for the Order Number type, an Order Number must be entered. Additionally, if a From Date is populated but the To Date has been left blank, the system treats this as an incomplete date range. Any missing criterion causes an error message to be shown and the search is not executed.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Date range: From Date must be supplied | RB_TYPE = 'D' AND FROM_DATE IS NULL - WHEN-BUTTON-PRESSED own condition on CB_DUMMY.PB_SEARCH | When the user presses the Search button | Ensures date range is complete before retrieval runs | *"Date range can not be left black"*; search does not run |
| CO Number type: CO Number must be supplied | RB_TYPE = 'C' AND CB_CO_NO IS NULL - WHEN-BUTTON-PRESSED own condition on CB_DUMMY.PB_SEARCH | When the user presses the Search button | Ensures a CO Number is provided when that search type is selected | *"CO Number can not be left black"*; search does not run |
| Order Number type: Order Number must be supplied | RB_TYPE = 'O' AND CB_ORDER_NO IS NULL - WHEN-BUTTON-PRESSED own condition on CB_DUMMY.PB_SEARCH | When the user presses the Search button | Ensures an Order Number is provided when that search type is selected | *"Order Number can not be left black"*; search does not run |
| To Date required when From Date is populated | FROM_DATE IS NOT NULL AND TO_DATE IS NULL - WHEN-BUTTON-PRESSED own condition on CB_DUMMY.PB_SEARCH | When the user presses the Search button | Ensures both date boundaries are present before a date-range search | *"To Date both can not be left black"*; search does not run |

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-ES-01** - Date range type selected but From Date is blank - *"Date range can not be left black"*; search does not run.
- **BR-005-ES-02** - CO Number type selected but CO Number is blank - *"CO Number can not be left black"*; search does not run.
- **BR-005-ES-03** - Order Number type selected but Order Number is blank - *"Order Number can not be left black"*; search does not run.
- **BR-005-ES-04** - From Date populated but To Date is blank - *"To Date both can not be left black"*; search does not run.

**Step 2 - Order data retrieved and loaded into results grid**
After validation passes, the system queries the purchase order header and detail tables for all matching mass order lines, joining to reference tables to resolve the order type description, distributor name and location, part description, and CO (sales order) date. For the date-range search type, orders are filtered by the entered From Date and To Date window. For the order number and CO number search types, the specific order number or CO number is used as the filter. The results grid is cleared before loading and each matching row is loaded into a new line on screen, showing the order number, order date, CO number, CO date, order type, distributor name, distributor location, part number, part description, quantity ordered, quantity billed, back-order quantity, and back-order value.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **POPULATE_DETAILS** ([SP-001](#SP-001--POPULATE_DETAILS)) - POPULATE_DETAILS - queries mass order headers and detail lines matching the selected search criteria, resolves lookup descriptions for order type, distributor, part, and CO date, and populates each matching row into the results grid. Returns a warning if no rows are found; returns an error with the database message if retrieval fails.
    * **Step 1** - Retrieve all matching mass order header and detail lines using the search criteria provided: for date-range searches, by the From Date and To Date window; for order number searches, by the specific purchase order number; for CO number searches, by the specific customer order number (restricted to lines for which a sales order has been generated).
    * **Step 2** - Navigate to the results grid and clear any previously displayed rows.
    * **Step 3** - For each retrieved order line, look up the distributor's parent group and company code from the dealer location master; if not found, silently continue with blank values.
    * **Step 4** - For each retrieved order line, look up the CO date from the sales order header using the distributor details; if not found, silently continue with a blank CO date.
    * **Step 5** - For each retrieved order line, look up the distributor name and location description from the dealer location table; if not found, silently continue with blank values.
    * **Step 6** - For each retrieved order line, look up the order type description from the list-of-values master using the current principal's configuration; if not found, silently continue with a blank order type description.
    * **Step 7** - For each retrieved order line, look up the part description from the parts master using the current principal's configuration; if not found, silently continue with a blank part description.
    * **Step 8** - Load all resolved field values for the current order line into the next row of the results grid, including the calculated back-order quantity (quantity ordered minus quantity billed) and back-order value (back-order quantity multiplied by purchase price).
    * **Step 9** - After all rows are loaded, return focus to the first row of the results grid. If no matching rows were found, display a warning that data is not available. If a retrieval error occurs, display an error message that includes the database error detail.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Data availability check | NO_DATA_FOUND exception handler - POPULATE_DETAILS [SP-001] | When the search retrieves no matching rows | Informs the user when no orders match the entered criteria | *"Data not available"* warning is shown |
| Database retrieval error | WHEN OTHERS exception handler - POPULATE_DETAILS [SP-001] | When a database error occurs during retrieval | Surfaces the technical error so the user is aware that retrieval failed | Error message containing the database error text is shown (e.g. *"Unable to populate"* followed by the database error detail) |

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-WS-01** - No orders match the search criteria - *"Data not available"* warning is displayed.
- **BR-005-ES-05** - A database error occurs during retrieval - *"Unable to populate"* followed by the database-provided error text; the results grid remains empty.

#### Business Scenarios - How results differ by search type

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Date Range search** | Orders are retrieved for the selected location and dealer within the From Date to To Date window (all mass order types included). |
| **Order Number search** | Only the single mass order header and its detail lines matching the specific order number, order type, and current session's principal/company are retrieved. |
| **CO Number search** | Only mass order lines where a sales order has been generated (confirmed CO lines) matching the specific CO number and the current session's principal/company are retrieved. |

**Alternative Flows:**
- **BR-005-AF-01** - (from Step 1) Any required criterion is missing: the appropriate error message is shown (see Step 1 validation table), focus remains on the criteria area, and the results grid is not refreshed.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Search Type (`RB_TYPE`) | Mandatory | Radio Group | 1 | N/A | `O`, `C`, `D` | Screen is open | Must be one of the three valid values | N/A |
| Order Number (`CB_ORDER_NO`) | Conditional - when Order Number search type selected | Text | 25 | Order Number list (LOV_PO) | Order number | Search type = Order Number | Required when Order Number type is active | *"Order Number can not be left black"* |
| CO Number (`CB_CO_NO`) | Conditional - when CO Number search type selected | Text | 25 | CO Number list (LOV_CO) | CO number | Search type = CO Number | Required when CO Number type is active | *"CO Number can not be left black"* |
| From Date (`FROM_DATE`) | Conditional - when Date Range search type selected | Date | DD/MM/RRRR | N/A | N/A | Search type = Date Range | Required when Date Range type is active | *"Date range can not be left black"* |
| To Date (`TO_DATE`) | Conditional - when Date Range search type selected | Date | DD/MM/RRRR | N/A | N/A | Search type = Date Range; From Date entered | Required when From Date is populated | *"To Date both can not be left black"* |
| Order Num (`PO_NO`) | Read-only display | Text | 25 | N/A | Populated from search results | Search executed successfully | System-populated from query | N/A |
| Order Date (`PO_DATE`) | Read-only display | Text | DD/MM/YYYY | N/A | Populated from search results | Search executed successfully | System-populated from query | N/A |
| CO Num (`CO_NO`) | Read-only display | Text | 25 | N/A | Populated from search results | Search executed successfully | System-populated from query | N/A |
| CO Date (`CO_DATE`) | Read-only display | Text | DD/MM/YYYY | N/A | Populated from search results | Search executed successfully | System-populated; blank if not found | N/A |
| Order Type (`PO_TYPE`) | Read-only display | Text | 50 | Order type list (AM_LIST, list name PO_MASS_TYPE) | Order type description | Search executed successfully | System-populated from order type master | N/A |
| Distributor Name (`DIST_NAME`) | Read-only display | Text | 200 | N/A | Populated from dealer location master | Search executed successfully | System-populated; blank if not found | N/A |
| Distributor Location (`DIST_LOC`) | Read-only display | Text | 100 | N/A | Populated from dealer location master | Search executed successfully | System-populated; blank if not found | N/A |
| PO Qty (`PO_QTY`) | Read-only display | Number | 23 | N/A | Populated from search results | Search executed successfully | System-populated from query | N/A |
| Billed Qty (`CO_QTY`) | Read-only display | Number | 23 | N/A | Populated from search results | Search executed successfully | System-populated from query | N/A |
| BO Qty (`CBO_QTY`) | Read-only display | Number | 23 | N/A | Calculated: PO Qty minus Billed Qty | Search executed successfully | System-calculated | N/A |
| BO Value (`PO_VALUE`) | Read-only display | Number | 23 | N/A | Calculated: BO Qty multiplied by purchase price | Search executed successfully | System-calculated | N/A |
| Part Num (`PART_NUM`) | Read-only display | Text | 25 | N/A | Populated from search results | Search executed successfully | System-populated from query | N/A |
| Part Desc (`PART_DESC`) | Read-only display | Text | 200 | Part master (PM_PART) | Part description | Search executed successfully | System-populated from parts master; blank if not found | N/A |

---

---

#### Requirement ID: BR-006

**Requirement Title:** Export Mass Order Data to Excel

**Business Description:**
When the user presses the Export to Excel button, the system applies the same validation checks as the Search button to ensure the search criteria are complete, then builds a comma-separated data extract containing all matching mass order lines - with the same columns as the on-screen results - and exports that data to a downloadable CSV file. The file is named using the current user's identifier combined with a timestamp to ensure uniqueness. The user can then open or save the file from their browser. If no matching rows exist, or if a system error occurs during the export, the operation is silently abandoned (no error is shown to the user in those cases).

**Actors:** Operations User / Dealer User

**Preconditions:**
- The mass order enquiry screen is open.
- The user has selected a search type and entered the required search criteria for that type.

**Main Flow:**

**Step 1 - Search criteria validated before export**
When the user clicks the Export to Excel button, the system applies exactly the same completeness checks as the Search button: the required criterion for the active search type must be present, and a From Date must not be left with a blank To Date. Any missing criterion causes an error message to be shown and the export is not executed.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Date range: From Date must be supplied | RB_TYPE = 'D' AND FROM_DATE IS NULL - WHEN-BUTTON-PRESSED own condition on CB_DUMMY.PB_EXCEL | When the user presses the Export to Excel button | Ensures a complete date range is provided before the export query runs | *"Date range can not be left black"*; export does not run |
| CO Number type: CO Number must be supplied | RB_TYPE = 'C' AND CB_CO_NO IS NULL - WHEN-BUTTON-PRESSED own condition on CB_DUMMY.PB_EXCEL | When the user presses the Export to Excel button | Ensures a CO Number is provided when that search type is selected | *"CO Number can not be left black"*; export does not run |
| Order Number type: Order Number must be supplied | RB_TYPE = 'O' AND CB_ORDER_NO IS NULL - WHEN-BUTTON-PRESSED own condition on CB_DUMMY.PB_EXCEL | When the user presses the Export to Excel button | Ensures an Order Number is provided when that search type is selected | *"Order Number can not be left black"*; export does not run |
| To Date required when From Date is populated | FROM_DATE IS NOT NULL AND TO_DATE IS NULL - WHEN-BUTTON-PRESSED own condition on CB_DUMMY.PB_EXCEL | When the user presses the Export to Excel button | Ensures both date boundaries are present before a date-range export | *"To Date both can not be left black"*; export does not run |

*Business outcomes (errors, warnings, success, and status):*
- **BR-006-ES-01** - Date range type selected but From Date is blank - *"Date range can not be left black"*; export does not run.
- **BR-006-ES-02** - CO Number type selected but CO Number is blank - *"CO Number can not be left black"*; export does not run.
- **BR-006-ES-03** - Order Number type selected but Order Number is blank - *"Order Number can not be left black"*; export does not run.
- **BR-006-ES-04** - From Date populated but To Date is blank - *"To Date both can not be left black"*; export does not run.

**Step 2 - Export query built and file generated**
After validation passes, the system constructs a dynamic export query for all matching mass order lines (same columns as the on-screen grid: Order Num, Order Date, CO Num, CO Date, Order Type, Distributor Name, Distributor Location, Part Num, Part Desc, PO Qty, Billed Qty, BO Qty, BO Value), appended to a header row of column labels. The system generates a unique filename based on the current user identifier and a timestamp, then calls the Excel export service to write the rows to a CSV file on the server and present it to the user's browser for download.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **VIEW_EXCEL_REPORT_NEW** ([SP-048](#SP-048--VIEW_EXCEL_REPORT_NEW)) - VIEW_EXCEL_REPORT_NEW - receives the current principal, the generated filename, the export query string, the column name, and the application identifier; executes the query, writes the results to a server-side CSV file, and delivers the file to the user's browser for download. Any exception during export is silently suppressed and the operation ends without an error message to the user.
    * **Step 1** - Receive the principal identifier, output filename, export query, column name, and application identifier as inputs.
    * **Step 2** - Execute the provided query to retrieve all matching order lines.
    * **Step 3** - Write the query results - including a header row of column labels - to a server-side file with the provided filename, formatted as comma-separated values.
    * **Step 4** - Deliver the generated file to the user's browser session so the user can open or save it.
    * **Step 5** - If any error occurs during the above steps, suppress it silently and end the operation without displaying an error to the user.

#### Business Scenarios - How the export data differs by search type

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Date Range export** | The export query retrieves all mass order lines for the selected location within the From Date to To Date window. |
| **Order Number export** | The export query retrieves only the lines for the specific purchase order number, filtered by the current session's principal, company, and order type. |
| **CO Number export** | The export query retrieves only the lines for the specific CO-linked purchase order number, filtered by the current session's principal, company, and order type. |

**Alternative Flows:**
- **BR-006-AF-01** - (from Step 1) Any required criterion is missing: the appropriate error message is shown, focus remains on the criteria area, and no file is generated.
- **BR-006-AF-02** - (from Step 2) An exception occurs during export: the WHEN OTHERS handler silently suppresses the error; no file is delivered and no error message is shown to the user.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Search Type (`RB_TYPE`) | Mandatory | Radio Group | 1 | N/A | `O`, `C`, `D` | Screen is open | Must be one of the three valid values | N/A |
| Order Number (`CB_ORDER_NO`) | Conditional - when Order Number search type selected | Text | 25 | Order Number list (LOV_PO) | Order number | Search type = Order Number | Required when Order Number type is active | *"Order Number can not be left black"* |
| CO Number (`CB_CO_NO`) | Conditional - when CO Number search type selected | Text | 25 | CO Number list (LOV_CO) | CO number | Search type = CO Number | Required when CO Number type is active | *"CO Number can not be left black"* |
| From Date (`FROM_DATE`) | Conditional - when Date Range search type selected | Date | DD/MM/RRRR | N/A | N/A | Search type = Date Range | Required when Date Range type is active | *"Date range can not be left black"* |
| To Date (`TO_DATE`) | Conditional - when Date Range search type selected | Date | DD/MM/RRRR | N/A | N/A | Search type = Date Range; From Date entered | Required when From Date is populated | *"To Date both can not be left black"* |

---

---

#### Requirement ID: BR-007

**Requirement Title:** Form Exit and Session Deregistration

**Business Description:**
When the user exits the mass order enquiry screen - whether by pressing the dedicated exit key, clicking the toolbar Exit button, clicking the navigation Exit button, or clicking the navigation OK button - the system closes the form without saving any uncommitted changes. When the dedicated exit key or the navigation Exit button is used, the system additionally clears the module session registration set at startup so that the database session is no longer associated with this screen. The navigation Exit button also sets a global exit indicator before closing.

**Actors:** Operations User / Dealer User

**Preconditions:**
- The mass order enquiry screen is open.

**Main Flow:**

**Step 1 - Session deregistered and form closed (exit key path)**
When the user presses the dedicated exit key, the system clears the client identifier and module name written to the database session at screen startup, then exits the form immediately without validating or saving any pending changes.

**Step 2 - Form exited via toolbar Exit button**
When the user clicks the toolbar Exit button, the system exits the form without saving, regardless of whether any data has been entered or changed.

**Step 3 - Global exit flag set and form closed via navigation Exit button**
When the user clicks the navigation Exit button, the system sets a global exit indicator to mark that the user has explicitly requested an exit, then exits the form immediately without saving.

**Step 4 - Form exited via navigation OK button**
When the user clicks the navigation OK button, the system exits the form immediately without validating or saving any pending changes.

**Alternative Flows:**
- None.

---

---

#### Requirement ID: BR-008

**Requirement Title:** Screen Clear and Copyright Display Refresh

**Business Description:**
When the user clicks the toolbar Cancel button (or triggers the standard Clear Form action), the system discards all data currently shown on the screen without saving any changes, re-initialises the form to its opening state - restoring default search criteria, resetting field states, and re-applying the access check - and then refreshes the copyright notice at the bottom of the screen. This allows the user to reset all search criteria and results to a clean state without leaving the screen.

**Actors:** Operations User / Dealer User

**Preconditions:**
- The mass order enquiry screen is open.
- The Cancel toolbar button is enabled.

**Main Flow:**

**Step 1 - Toolbar Cancel button checked before action**
When the user clicks the Cancel toolbar button, the system first checks whether that button is currently enabled. If the button is not enabled, no action is taken. If it is enabled, the system proceeds to clear the screen.

*Screen: Search Criteria / Results (`WN_MAIN` / `CN_MAIN`).*

**Step 2 - Screen cleared without saving**
The system clears all blocks on the screen without validating or saving any pending changes. This removes all entered search criteria and all loaded search results from the display, returning every field to an empty state. The clear is performed the same way regardless of whether any data has been changed.

*Screen: Search Criteria / Results (`WN_MAIN` / `CN_MAIN`).*

**Step 3 - Form re-initialised to opening state**
After clearing the screen, the system re-runs the full form initialisation sequence: maximising the main window, setting system message suppression, verifying that the current user is a MASS-type dealer (closing the form with an error message if not), and re-seeding the application identifier global for use by downstream processes. This step restores the form to exactly the same state it was in immediately after first opening.

*Screen: Search Criteria / Results (`WN_MAIN` / `CN_MAIN`).*

**Step 4 - Copyright notice refreshed**
The system calls the copyright declaration function to obtain the current copyright text and writes it into the copyright display field at the bottom of the screen. The screen is then ready for a new search.

*Procedures called:*
- **SF_COPYRIGHT_DECLARATION** ([SP-046](#SP-046--SF_COPYRIGHT_DECLARATION)) - SF_COPYRIGHT_DECLARATION - returns the current application copyright declaration text to be displayed in the copyright notice field at the bottom of the screen after the form is cleared.
    * **Step 1** - Return the current copyright declaration text string to the caller.

**Alternative Flows:**
- **BR-008-AF-01** - (from Step 1) Cancel toolbar button is not enabled: no action is taken; the screen state is unchanged.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Copyright Notice () | Auto-populated | Text | 100 | N/A | Current copyright declaration text returned by the copyright function | Form clear action triggered | System-populated; read-only display field | N/A |

---

---

#### Requirement ID: BR-009

**Requirement Title:** Centralised Application Error Handling

**Business Description:**
Whenever the application encounters an error - whether triggered by a database constraint violation, a data-entry conflict, a record locking issue, or any other unexpected system error - the centralised error handler classifies the error and responds appropriately: showing a user-readable message, rolling back any pending changes where necessary, and stopping further processing so the user can take corrective action. Specific well-known error conditions are handled with targeted messages; all remaining unexpected errors show the actual database error text so the user or support staff can understand what went wrong.

**Actors:** System

**Preconditions:**
- The mass order enquiry screen is open and an error has been raised by any screen action or database operation.

**Main Flow:**

**Step 1 - Referential integrity violation handled with a specific message**
If the error raised is a database referential integrity violation (foreign key constraint violation), the system calls the error-raising routine to display the corresponding business error message for that constraint code and stop further processing.

*Procedures called:*
- **GENERAL.RAISE_ERROR** ([SP-012](#SP-012--GENERAL.RAISE_ERROR)) - GENERAL.RAISE_ERROR - looks up the business error message corresponding to the referential integrity constraint code and displays it to the user, then halts the current trigger so the user can resolve the constraint issue.
    * **Step 1** - Receive the error code identifying the specific constraint violation (referential integrity violation).
    * **Step 2** - Look up the registered business error message for that error code.
    * **Step 3** - Display the business error message to the user and stop the current trigger's processing so the user is informed of the constraint issue.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Referential integrity constraint check | DBMS_ERROR_CODE = -02292 - GENERAL.RAISE_ERROR [SP-012] | When any database operation raises a referential integrity violation | Informs the user with a meaningful message when an action would break a related data dependency | Business error message for the constraint code is displayed; current trigger processing stops |

**Step 2 - Known display and navigation errors handled with message and trigger failure**
If the error code is one of a set of known display and navigation error codes (40209, 40207, 50026, or 50004), the system shows the error type, code, and text to the user in the format `[error type]-[error number]: [error text]`, then stops further processing. No rollback is performed for these errors.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-011](#SP-011--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the formatted error message (combining error type, code, and text) to the user as an error notification.
    * **Step 1** - Receive the formatted message text and the severity level.
    * **Step 2** - Display the message to the user at the specified severity level.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Known form/navigation error codes | ERROR_CODE in (40209, 40207, 50026, 50004) - ON-ERROR own condition | When any screen action raises one of these specific error codes | Informs the user of known display or navigation issues with the error detail | Formatted error message shown; current trigger processing stops |

**Step 3 - Record concurrency conflict handled with rollback**
If the error code indicates that another user has already updated the record being modified (error codes 40654, 40655, 40656, 40657, or 40659), the system shows the message *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*, rolls back any pending changes, and stops further processing so the user can re-query the record with the latest data before retrying.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-011](#SP-011--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the concurrency conflict message to the user as an error notification.
    * **Step 1** - Receive the formatted message text and the severity level.
    * **Step 2** - Display the message to the user at the specified severity level.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Record concurrency conflict | ERROR_CODE in (40654-40659) - ON-ERROR own condition | When any save or update operation detects that another user has already changed the same record | Prevents overwriting another user's changes by requiring the user to re-query before retrying | *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"* shown; changes rolled back; processing stops |

*Business outcomes (errors, warnings, success, and status):*
- **BR-009-ES-01** - Record concurrency conflict detected - *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*; changes rolled back.

**Step 4 - All other unexpected database errors handled with message and rollback**
If the database session reports any other unexpected error (non-zero SQL error code), the system shows the database error text to the user, rolls back any pending changes, and stops further processing.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-011](#SP-011--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the database error text to the user as an error notification.
    * **Step 1** - Receive the formatted message text and the severity level.
    * **Step 2** - Display the message to the user at the specified severity level.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Unexpected database error | SQLCODE <> 0 - ON-ERROR own condition | When any operation produces an unexpected database error | Surfaces the database error text so the user or support staff can identify what went wrong | Database error text displayed; changes rolled back; processing stops |

**Step 5 - Known no-data error codes silently ignored**
If the error code is one of the standard "no data found" Oracle Forms codes (40401 or 40405), the system takes no action - these are expected informational codes that do not require user notification and are silently suppressed.

**Alternative Flows:**
- None.

> **Note - Inactive triggers:** The following triggers exist in the form but are entirely commented out or contain only a `null;` statement and do not execute:
> - **ON-MESSAGE** (COMMENTED OUT / INACTIVE - does not execute): contained logic to display message-number and text for specific message codes; the entire body was commented out on 7-May-04 and replaced with `null;`.
> - **KEY-COMMIT** (COMMENTED OUT / INACTIVE - does not execute): contained logic to enter the form, check for form failure, commit, and clear; the entire body was commented out on 7-May-04 and replaced with `null;`.
> - **CLEAR_ITEMS** program unit (INACTIVE - empty body, does not execute): declared as a procedure but contains only an empty `BEGIN ... END;` block with no statements.

---

> **Note - Standard toolbar and framework buttons (not separate BRs):** The following active button triggers delegate entirely to standard Oracle Forms framework actions or to other documented processes and contain no additional custom business logic; they are therefore not documented as separate business requirements per R3 (no standalone BR for platform shell behaviour):
> - **PB_CANCEL** - calls `EXECUTE_TRIGGER('FT_CANCEL')`; the FT_CANCEL logic (clear form, re-initialise, refresh copyright) is fully documented in BR-008.
> - **PB_LIST** - calls `EXECUTE_TRIGGER('FT_LIST')`; FT_LIST checks whether the List toolbar button is enabled and, if so, invokes the standard `LIST_VALUES` action to open the LOV attached to the current field; LOV usage is documented in the Data Elements of the relevant BRs.
> - **PB_INSERT, PB_DEL, PB_SAVE, PB_PRINT** - each calls `EXECUTE_TRIGGER('FT_*')` for the corresponding standard DPL library toolbar action; the FT_INSERT, FT_DEL, FT_SAVE, and FT_PRINT triggers are either entirely commented out or contain only a `null;` statement and do not execute; these toolbar buttons therefore have no functional effect in the current form.
> - **PB_CUT, PB_COPY, PB_PASTE** - standard clipboard region operations (`Cut_region`, `copy_region`, `paste_region`); platform behaviour, no custom business logic.
> - **NB_CLEAR** - attempts to navigate to block `PM_PART_DEAD_STOCK` (which does not exist in this form) and then clear the criteria block; the non-existent block navigation means this button has no meaningful effect in the current form.
> - **KEY-LISTVAL** - shows the LOV attached to the current field (if any) and advances to the next field after selection; standard LOV invocation, no custom business logic. LOV usage is documented in the Data Elements of the relevant BRs.

---

## 5. Business Rules Catalogue

| Rule ID | Rule Name | Rule Type | Business Requirement ID | Condition | Action | Business Impact |
| ------- | --------- | --------- | ----------------------- | --------- | ------ | --------------- |
| BRC-001 | From Date Must Not Be in the Future | Validation | BR-003 | The From Date entered by the user is later than today's date | Display *"From Date cannot be greater than Current Date"* and stop processing; user must correct the date | Prevents searches being run with an invalid future start date |
| BRC-002 | To Date Automatically Calculated from From Date | Derivation | BR-003 | A valid From Date has been entered | Automatically calculate the To Date as the last day of the month following the From Date; if that calculated date is in the future, use today's date instead | Provides the user with a sensible default To Date immediately after a From Date is entered, reducing manual entry effort |
| BRC-003 | To Date Must Not Be in the Future | Validation | BR-004 | The To Date entered by the user is later than today's date | Display *"To Date cannot be greater than Current Date"* and stop processing; user must correct the date | Prevents searches being run with an invalid future end date |
| BRC-004 | To Date Must Not Precede From Date | Validation | BR-004 | The To Date entered is earlier than the From Date | Display *"To Date cannot be less than From Date"* and stop processing; user must correct the date | Ensures the date range is logically consistent before a search is executed |
| BRC-005 | To Date Is Required When From Date Is Populated | Validation | BR-004 | A From Date is entered and the To Date field is left blank | Display *"To Date both can not be left black"* and stop processing; user must supply a To Date | Prevents incomplete date ranges being submitted for a search |
| BRC-006 | Date Range Required Before Search (Date Range Type) | Validation | BR-005 | The Date Range search type is selected but the From Date field is blank when the Search button is pressed | Display *"Date range can not be left black"* and cancel the search | Ensures the date range filter is complete before querying the database |
| BRC-007 | CO Number Required Before Search (CO Number Type) | Validation | BR-005 | The CO Number search type is selected but the CO Number field is blank when the Search button is pressed | Display *"CO Number can not be left black"* and cancel the search | Ensures a CO Number is present before executing a CO-number-based search |
| BRC-008 | Order Number Required Before Search (Order Number Type) | Validation | BR-005 | The Order Number search type is selected but the Order Number field is blank when the Search button is pressed | Display *"Order Number can not be left black"* and cancel the search | Ensures an Order Number is present before executing an order-number-based search |
| BRC-009 | Both Date Boundaries Required Before Search | Validation | BR-005 | The From Date is populated but the To Date is blank when the Search button is pressed | Display *"To Date both can not be left black"* and cancel the search | Prevents a search with an incomplete date range being submitted |
| BRC-010 | Date Range Required Before Excel Export (Date Range Type) | Validation | BR-006 | The Date Range search type is selected but the From Date field is blank when the Export to Excel button is pressed | Display *"Date range can not be left black"* and cancel the export | Ensures the date range filter is complete before building the export query |
| BRC-011 | CO Number Required Before Excel Export (CO Number Type) | Validation | BR-006 | The CO Number search type is selected but the CO Number field is blank when the Export to Excel button is pressed | Display *"CO Number can not be left black"* and cancel the export | Ensures a CO Number is present before executing a CO-number-based export |
| BRC-012 | Order Number Required Before Excel Export (Order Number Type) | Validation | BR-006 | The Order Number search type is selected but the Order Number field is blank when the Export to Excel button is pressed | Display *"Order Number can not be left black"* and cancel the export | Ensures an Order Number is present before executing an order-number-based export |
| BRC-013 | Both Date Boundaries Required Before Excel Export | Validation | BR-006 | The From Date is populated but the To Date is blank when the Export to Excel button is pressed | Display *"To Date both can not be left black"* and cancel the export | Prevents an export with an incomplete date range being submitted |
| BRC-014 | Search Type Determines Which Filter Fields Are Active | Constraint | BR-002 | The user changes the selected search type | Clear all filter fields not relevant to the newly selected type; disable those fields; enable and make navigable only the field(s) relevant to the selected type | Prevents residual search criteria from a previous search type being inadvertently included in a new search |
| BRC-015 | Date Range Default Applied When Date Range Type Is Selected | Derivation | BR-002 | The user selects the Date Range search type | Automatically set From Date to the first day of the current calendar month and To Date to today's date | Provides useful default date boundaries immediately when the Date Range type is chosen, reducing the number of keystrokes required |
| BRC-016 | Referential Integrity Violation Handled With Business Error Message | Validation | BR-009 | A database referential integrity constraint violation is raised during any operation | Display the registered business error message for the constraint violation code and stop processing | Protects data integrity by informing the user in business language when an action would violate a database relationship constraint |
| BRC-017 | Record Concurrency Conflict Requires Re-Query | Validation | BR-009 | A record-locking or concurrency conflict error is raised (another user has already modified the same record) | Display *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*, roll back pending changes, and stop processing | Prevents one user's changes from silently overwriting another user's changes by requiring a re-query before retrying |
| BRC-018 | Unexpected Database Error Shown to User with Rollback | Constraint | BR-009 | Any unexpected database error with a non-zero error code occurs | Display the database-provided error text to the user, roll back any pending changes, and stop processing | Ensures no data is silently corrupted and provides the user or support staff with the actual error detail for diagnosis |

**Total Business Rules Identified: 18**

---

## 6. Data Requirements

*This section describes the mass order purchase data entities managed or referenced by the PR_MASS_ORDER enquiry screen, the search criteria and results fields it captures and displays, the reference data it uses for lookup and display purposes, and the lifecycle of the records it reads.*

### 6.1 Business Entities and Relationships

*The form reads purchase order header and detail data from the mass order tables, joining to dealer, part, order type, and sales order reference tables to present a consolidated order view.*

#### Mass Order Header - PH_PO_MASS

The purchase order header entity records each mass order placed by the dealer. It holds the order number, order date, order type, order status, and the identities of the ordering dealer/location and the receiving distributor. The screen filters header records by date range, specific order number, or specific CO number depending on the selected search type, and uses the header to drive retrieval of the associated detail lines.

#### Mass Order Detail - PD_PO_MASS

The purchase order detail entity holds the individual part lines within each mass order. Each detail row records the part number, quantity ordered, quantity billed (issued), purchase price, back-order value, and the linked sales/customer order number. The screen displays one row per detail line and calculates the back-order quantity and back-order value from the detail figures.

#### Entity Relationships

The mass order enquiry form is built around a header-to-detail relationship: each mass order header (PH_PO_MASS) can have one or more associated detail lines (PD_PO_MASS), linked by shared purchase order identity, dealer/location identity, company/product-family code, and order type. The form reads both tables in a single query and presents each detail line as a separate row in the results grid, with the header-level fields (order number, order date, order type) repeated alongside each detail line's part and quantity information.

```
PH_PO_MASS (Mass Order Header)
        └── PD_PO_MASS (Mass Order Detail)   <- linked by po_num, dealer_map_cd, loc_cd, comp_fa, po_type
```

### 6.2 Data Capture Requirements

*The form captures search criteria from the user and displays read-only results; no data is created or updated by this screen. All result fields are system-populated from the query.*

#### Search Criteria (Operations User / Dealer User - at search initiation)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Search Type (`RB_TYPE`) | Yes | Determines which filter mode the search uses: by order number, by CO number, or by date range | Must be one of the three supported search types; selected by the user via a radio button |
| Order Number (`CB_ORDER_NO`) | Conditional | The specific purchase order number to search for; required when Order Number search type is selected | Required and enabled only when Order Number search type is active; field is disabled and cleared when another search type is chosen |
| CO Number (`CB_CO_NO`) | Conditional | The specific customer order (CO) number to search for; required when CO Number search type is selected | Required and enabled only when CO Number search type is active; field is disabled and cleared when another search type is chosen |
| From Date (`FROM_DATE`) | Conditional | The start date of the order date range to search within; required when Date Range search type is selected | Must not be later than today's date; required and enabled only when Date Range type is active; auto-defaulted to first day of current month when Date Range type is selected |
| To Date (`TO_DATE`) | Conditional | The end date of the order date range to search within; required when a From Date has been entered | Must not be later than today's date; must not be earlier than From Date; must not be blank when a From Date is populated; auto-calculated on From Date entry |

#### Search Results (System - populated after search executes)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Order Num (`PO_NO`) | Auto-Populated | The purchase order number from the matched mass order header | System-populated from query; read-only |
| Order Date (`PO_DATE`) | Auto-Populated | The date on which the purchase order was raised, formatted as DD/MM/YYYY | System-populated from query; read-only |
| CO Num (`CO_NO`) | Auto-Populated | The linked customer order (sales order) number for the detail line | System-populated from query; read-only |
| CO Date (`CO_DATE`) | Auto-Populated | The date of the linked customer order, formatted as DD/MM/YYYY | System-populated by lookup from the sales order header; left blank if no matching sales order is found |
| Order Type (`PO_TYPE`) | Auto-Populated | The human-readable description of the order type (e.g. description from PO_MASS_TYPE list) | System-populated by lookup from the list-of-values master using the current principal's configuration; left blank if not found |
| Distributor Name (`DIST_NAME`) | Auto-Populated | The name of the distributor (destination dealer/location) for this mass order | System-populated by lookup from the dealer location master; left blank if not found |
| Distributor Location (`DIST_LOC`) | Auto-Populated | The location description of the distributor | System-populated by lookup from the dealer location master; left blank if not found |
| PO Qty (`PO_QTY`) | Auto-Populated | The total quantity ordered on this detail line | System-populated from query; read-only |
| Billed Qty (`CO_QTY`) | Auto-Populated | The quantity that has already been issued/billed against this order line | System-populated from query; read-only |
| BO Qty (`CBO_QTY`) | Auto-Populated | The back-order quantity - the quantity ordered minus the quantity billed | System-calculated (PO Qty minus Billed Qty); read-only |
| BO Value (`PO_VALUE`) | Auto-Populated | The monetary value of the outstanding back-order quantity | System-calculated (BO Qty multiplied by purchase price); read-only |
| Part Num (`PART_NUM`) | Auto-Populated | The part number for the ordered item | System-populated from query; read-only |
| Part Desc (`PART_DESC`) | Auto-Populated | The description of the part | System-populated by lookup from the parts master using the current principal's configuration; left blank if not found |

#### Session and Global Parameters (System - available at all times)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| User Identity (`GLOBAL.USERID`) | Auto-Populated | The identifier of the currently logged-in user; used to generate a unique filename for Excel exports | System-maintained session global; not user-editable |
| Principal (`GLOBAL.PRINCIPAL`) | Auto-Populated | The organisation or principal context under which the form operates; used to filter reference data lookups to the correct principal's records | System-maintained session global; not user-editable |
| Dealer (`GLOBAL.DEALER`) | Auto-Populated | The dealer code for the current session; used to scope the order search to the current dealer | System-maintained session global; not user-editable |
| Location (`GLOBAL.LOC_CD`) | Auto-Populated | The location code for the current session; used alongside the dealer code to scope the order search | System-maintained session global; not user-editable |
| Parent Group (`GLOBAL.PARENT_GROUP`) | Auto-Populated | The parent group identifier for the current session; used in order-number and CO-number searches to scope results | System-maintained session global; not user-editable |
| Company / Product Family (`GLOBAL.COMP_FA`) | Auto-Populated | The company or product-family code for the current session; used to filter search results to the correct company | System-maintained session global; not user-editable |
| Application ID (`PARAMETER.P_APP_ID`) | Auto-Populated | The application identifier passed to the Excel export service | Form parameter; not user-editable |

### 6.3 Reference Data

*Lists the master and configuration data referenced by this form for lookup and display purposes.*

| Reference Data | Business Purpose | Used When |
| :--- | :--- | :--- |
| Purchase Order Header list (LOV_PO / RG_PO) | Provides a pick-list of purchase order numbers (with their dates and dealer/location details) drawn from the last 30 days of mass orders for the current dealer and location | When the user opens the pick-list on the Order Number field to look up a valid order number |
| Customer Order (CO) Number list (LOV_CO / RG_CO) | Provides a pick-list of customer order (CO) numbers (with their linked PO numbers, dates, and dealer/location details) drawn from the last 30 days | When the user opens the pick-list on the CO Number field to look up a valid CO number |
| Order Type descriptions (AM_LIST, list name `PO_MASS_TYPE`) | Provides the human-readable label for each mass order type code, filtered to the current principal's configuration | When order lines are loaded into the results grid, to resolve each order type code to its display description |
| Dealer Location master (AM_DEALER_LOC) | Provides the dealer name and location description for the distributor (destination) of each order | When order lines are loaded into the results grid, to resolve the distributor identity to display names |
| Sales Order Header (PH_SO) | Provides the date of the customer order (CO) linked to each order detail line | When order lines are loaded into the results grid, to resolve the CO date for display |
| Parts master (PM_PART) | Provides the part description for each part number on a detail line, filtered to the current principal's configuration | When order lines are loaded into the results grid, to resolve part numbers to descriptions |
| Dealer Location Company master (AM_DEALER_LOC_COMPANY_MASTER) | Provides the parent group and company code for the destination distributor | When order lines are loaded into the results grid, to enable the CO date lookup via the sales order header |
| Copyright declaration function (SF_COPYRIGHT_DECLARATION) - `EXTERNAL / NOT IN BUNDLE` | Returns the current copyright text for display in the copyright notice field at the bottom of the screen | When the screen is cleared via the Clear Form action |

### 6.4 Data Lifecycle

*Describes how the mass order records managed by this form are queried, and what happens to session state during the form's lifecycle.*

**Creation**

- The PR_MASS_ORDER form is a read-only enquiry screen. No new purchase order headers or detail lines are created through this form. Records originate in other parts of the system.

**Updates**

- No updates to purchase order header or detail data are performed by this form. All displayed fields are read-only. Session metadata (module identifier and client information) is written to the active database session when the form opens, and cleared when the form exits.

**Save and Commit**

- There is no save or commit action on this form. The screen is strictly read-only: data is retrieved on demand when the user presses Search, and the results are displayed without being persisted or modified. The Excel export writes a temporary file to the server file system but does not modify any database records. Any pending form state is discarded without saving when the form is closed.

**Retention and Audit**

- The form does not manage audit stamps or retention policy directly. Purchase order data in PH_PO_MASS and PD_PO_MASS carries standard creation and modification metadata (created_by, created_date, modified_by, modified_date) evidenced in the datasource columns of the detail block; this metadata is not displayed or maintained by this enquiry screen. No archival or purge policy is implemented by this form.

---

### 6.5 Excel Output Columns

Excel download columns produced by this form, with when each Excel is produced (report / principal path), filters that limit which rows are included, and the database source for each value. Column sets vary by export path (for example app_id, principal, and enquiry-date mode); the rows below are evidenced layouts, not a guaranteed list for every combination. Blank Table/Database means the physical column was not proven in source.

| # | What the user selects on screen | Excel column name | When this Excel is produced | Table name | Database column | Logic |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | From Date, CO Number, Order Number, To Date, RB Type | Order Num |  | PH_PO_MASS | PO_NUM | Mass purchase order header number sourced from h.po_num (PH_PO_MASS alias h). |
| 2 | From Date, CO Number, Order Number, To Date, RB Type | Order Date |  | PH_PO_MASS | PO_DATE | Purchase order date sourced from h.po_date (PH_PO_MASS alias h), formatted MM/DD/RRRR. |
| 3 | From Date, CO Number, Order Number, To Date, RB Type | CO Num |  | PD_PO_MASS | SO_NUM | Customer order number sourced from d.so_num (PD_PO_MASS alias d). |
| 4 | From Date, CO Number, Order Number, To Date, RB Type | CO Date |  | PH_SO | SO_DATE | Shows the CO Date included in this Excel export. |
| 5 | From Date, CO Number, Order Number, To Date, RB Type | Order Type |  | AM_LIST | LIST_DESC | Shows the Order Type included in this Excel export. |
| 6 | From Date, CO Number, Order Number, To Date, RB Type | Distributor Name |  | AM_DEALER_LOC | DEALER_NAME | Distributor dealer name from l.dealer_name (AM_DEALER_LOC alias l); the scalar subquery concatenates dealer_name and loc_desc separated by a comma, making Distributor Name the first CSV field. |
| 7 | From Date, CO Number, Order Number, To Date, RB Type | Distributor Location |  | AM_DEALER_LOC | LOC_DESC | Distributor location description from l.loc_desc (AM_DEALER_LOC alias l); the scalar subquery concatenates dealer_name and loc_desc, making loc_desc the second CSV field for this column. |
| 8 | From Date, CO Number, Order Number, To Date, RB Type | Part Num |  | PD_PO_MASS | PART_NUM | Part number on the order detail line sourced from d.part_num (PD_PO_MASS alias d). |
| 9 | From Date, CO Number, Order Number, To Date, RB Type | Part Desc |  | PM_PART | PART_DESC | Shows the Part Desc included in this Excel export. |
| 10 | From Date, CO Number, Order Number, To Date, RB Type | PO Qty |  | PD_PO_MASS | PO_QTY | Purchase order quantity sourced from d.po_qty (PD_PO_MASS alias d). |
| 11 | From Date, CO Number, Order Number, To Date, RB Type | Billed Qty |  | PD_PO_MASS | ISSUED_QTY | Quantity already issued/billed sourced from d.issued_qty (PD_PO_MASS alias d), aliased bill_qty. |
| 12 | From Date, CO Number, Order Number, To Date, RB Type | BO Qty |  | PD_PO_MASS | BO_VALUE | Back-order quantity derived as NVL(d.po_qty,0) - NVL(d.issued_qty,0) from PD_PO_MASS; no single source column. |
| 13 | From Date, CO Number, Order Number, To Date, RB Type | BO Value |  | PD_PO_MASS |  | Back-order value derived as (NVL(d.po_qty,0) - NVL(d.issued_qty,0)) * NVL(d.purchase_price,0) from PD_PO_MASS; no single source column. |

## 7. Glossary

*Definitions of terms, abbreviations, and acronyms used throughout this document.*

The following table defines key terms, acronyms, and abbreviations used throughout this Business Requirements Document.

| Term | Definition | Aliases | Related Terms |
| :--- | :--- | :--- | :--- |
| AM_DEALER_LOC | Dealer location master table - stores dealer name and location description for each dealer-location combination | - | AM_DEALER_LOC_COMPANY_MASTER, Dealer, Loc CD |
| AM_DEALER_LOC_COMPANY_MASTER | Dealer-location company master table - maps each dealer-location pair to a parent group and company code | - | AM_DEALER_LOC, Parent Group, Comp FA |
| AM_LIST | Application reference list table - stores configurable code-description pairs for lookup lists such as PO mass order types | - | PO Type, Order Type |
| B_DTL | Detail block in the Oracle Form - displays the retrieved mass purchase order lines in the result grid | Detail Block | CB_DUMMY, PB_BLK |
| BTN | Button - a clickable control on the Oracle Forms screen that triggers an action | Button | PB_BLK, WHEN-BUTTON-PRESSED |
| CB_DUMMY | Control block in the Oracle Form - holds the search criteria fields; not bound to a database table | Search Block, Criteria Block | B_DTL, LOV |
| CBO | Carry-Back Order - the quantity remaining on a purchase order that has not yet been issued or fulfilled | Carry-Back | PO QTY, CO QTY |
| CO | Customer Order - a sales order raised by a dealer or distributor against a mass purchase order | Sales Order, SO | CO Number, CO Date, PH_SO |
| Comp FA | Company/FA code - identifier for the company or franchise area used to filter mass order data | Company Code | GLOBAL.COMP_FA |
| CSV | Comma-Separated Values - file format used for Excel-compatible data exports generated by the form | Excel Export | Excel, DMS_EXCEL_REPORT |
| Dealer | Dealer map code - numeric identifier for the dealership entity used to scope order searches | Dealer Map CD | GLOBAL.DEALER, AM_DEALER_LOC |
| DMS | Dealer Management System - the integrated software platform in which the pr_mass_order form operates | - | pr_mass_order |
| DPL | DPL program library - shared Oracle Forms PL/SQL library providing common utilities (message display, error handling) | DPL.pld | GENERAL package, DISP_TEXT, RAISE_ERROR |
| GENERAL | Package name used for the DPL shared library in this form - referenced as GENERAL.DISP_TEXT and GENERAL.RAISE_ERROR | DPL Library | DPL, DISP_TEXT, RAISE_ERROR |
| Loc CD | Location code - identifies the specific dealer branch or site used to filter order data | Location Code | GLOBAL.LOC_CD |
| LOV | List of Values - dropdown popup in Oracle Forms allowing the user to select a valid code with a description | Dropdown, Picklist | RG_CO, RG_PO, LOV_CO, LOV_PO |
| LOV_CO | Oracle Forms LOV for selecting a customer order number; backed by record group RG_CO | CO LOV | RG_CO, CB_CO_NO |
| LOV_PO | Oracle Forms LOV for selecting a purchase order number; backed by record group RG_PO | PO LOV | RG_PO, CB_ORDER_NO |
| OLB | Oracle Object Library - a binary library file that provides reusable property classes and objects shared across forms | Object Library | DPL.olb, webutil.olb |
| PB_BLK | Toolbar button block - contains all action buttons (exit, search, export, etc.) inherited from the DPL object library | Toolbar Block | PB_EXIT, NB_EXIT, NB_CLEAR, NB_OK |
| PD_PO_MASS | Mass purchase order detail table - stores individual line items (parts and quantities) for each mass order header | - | PH_PO_MASS |
| PH_PO_MASS | Mass purchase order header table - stores the header-level record for each mass purchase order | - | PD_PO_MASS, PO Number |
| PH_SO | Sales order header table - stores customer order date and related attributes for each sales order | - | CO, CO Date |
| PLD | Oracle Forms program library - a PL/SQL library file (.pld) attached to the form providing shared routines | Program Library | DPL.pld, GENERAL |
| PM_PART | Parts master table - stores part number and description data used to enrich order line display | - | Part Number, Part Description |
| PO | Purchase Order - a mass procurement order raised by a principal for parts to be delivered to a dealer | Mass Order | PO Number, PH_PO_MASS |
| Principal | Principal map code - identifier for the parts supplier or brand principal; used to scope data and export queries | Principal Map CD | GLOBAL.PRINCIPAL |
| pr_mass_order | The Oracle Forms module documented in this BRD - the Mass Order Inquiry screen in the DMS | PR_MASS_ORDER | DMS, Mass Order |
| RG_CO | Record group for customer order LOV - queries PH_PO_MASS to return SO and PO numbers | - | LOV_CO |
| RG_PO | Record group for purchase order LOV - queries PH_PO_MASS to return PO numbers and dates | - | LOV_PO |
| WebUtil | Oracle WebUtil library - provides client-side file transfer, browser integration, and OLE functions in Oracle Forms | webutil.pld | webutil.olb, WEBUTIL_ERROR |

---

---

## 8. Technical Inventory

*Complete inventory of Oracle Forms components including blocks, items, triggers, canvases, and global variables.*

### 8.1 Form Architecture

**Form Module Details:**

- Form Name: pr_mass_order (PR_MASS_ORDER)
- Form Module XML Title: MODULE4
- Oracle Forms Version: 12c (Module version 122010400); Runtime compatibility: 5.0
- Parent Object Library: DPL.olb (PC_FORM property class)
- Attached Libraries: DPL (DPL.pld program library), D2KWUTIL, WEBUTIL (webutil.olb), DMS_EXCEL_REPORT
- First Navigation Block: -
- Console Window: WN_MAIN - MASS Order (Rel: 1.0.2)
- Compile Dependencies: Requires DPL.olb, DPL.pld, WEBUTIL.olb, menu.mmx
- Source artifacts: `pr_mass_order_fmb.xml`; OLB `DPL.olb`; DPL (DPL.pld program library); D2KWUTIL; WEBUTIL (webutil.olb); DMS_EXCEL_REPORT

### 8.1.1 Global Variables

| Global Variable | Data Type | Set Location | Purpose |
| :--- | :--- | :--- | :--- |
| APP_ID | Char | Trigger | Application identifier global; holds the application ID passed at startup for context identification across form operations |
| APP_LOG | Char | Trigger | Application log flag global; used to control application-level logging behaviour during form execution |
| COMP_FA | Char | ProgramUnit / Trigger | Company or FA code used to filter mass order data by company |
| CURRENCY | Char | Trigger | Currency code global; used to apply currency context to monetary values displayed in the form |
| DEALER | Char | ProgramUnit / RecordGroup / Trigger | Dealer map code used to filter records by dealer |
| DLR_TYPE | Char | Trigger | Dealer type code global; used to differentiate dealer classification during order filtering and display |
| EXIT_FLAG | Char | Trigger | Exit intent signal; set to 'EXIT' when user closes form via NB_EXIT button |
| FIN_BEG | Char | Trigger | Financial year begin date global; used to bound date-range queries to the current financial period start |
| FIN_END | Char | Trigger | Financial year end date global; used to bound date-range queries to the current financial period end |
| LOC_CD | Char | ProgramUnit / RecordGroup / Trigger | Location code used to filter mass order records by dealer location |
| PARENT_GROUP | Char | ProgramUnit / Trigger | Parent group identifier used to filter order records by principal parent group |
| PRINCIPAL | Char | ProgramUnit / RecordGroup / Trigger | Principal map code used to filter parts and orders by principal |
| P_FIN_YR | Char | Trigger | Current financial year global; used to scope queries and displays to the active financial year |
| REP_SERVER | Char | Trigger | Report server name global; used when submitting Oracle Reports jobs to identify the target report server |
| TALLY_INTEGRATION | Char | Trigger | Tally integration flag global; indicates whether Tally accounting integration is active for the current session |
| USERID | Char | ProgramUnit / Trigger | Current logged-in user identifier used for CSV export filename generation |
| USER_NAME | Char | Trigger | Display name of the logged-in user; used for user-facing labels and audit context within the form |

### 8.1.2 Form Parameters

*All 1 ModuleParameter entries from pr_mass_order_fmb.xml.*

| Parameter | Data Type | Default | Description |
| :--- | :--- | :--- | :--- |
| P_APP_ID | Char | - | Application identifier passed into the form at startup; supplied as context argument to the Excel export function to identify the calling application |

**Total Parameters:** 1

### 8.2 Blocks

| Block Name | Query Data Source | Records | Q/I/U/D | Key Mode | Master-Detail Relationship |
| :--- | :--- | :--- | :--- | :--- | :--- |
| CB_DUMMY | - | 1 | N/N/N/N | Default | Control - search criteria entry block for filtering mass order records |
| B_DTL | - | 12 | N/Y/Y/N | Delayed | Results display block populated programmatically by POPULATE_DETAILS |
| PB_BLK | - | 1 | N/N/N/N | Default | Inherited toolbar button block (from DPL.olb OG_GROUP) |

**Total Blocks:** 3 business blocks

### 8.2.1 Block WhereClause and OrderByClause

*Block query scope from pr_mass_order_fmb.xml. **Description** explains filter and sort in business terms; **Order By** and **Where Clause** columns retain verbatim XML text for migration.*

| Block | Description | Order By (XML) | Where Clause (XML) |
| :--- | :--- | :--- | :--- |
| - | No blocks with WhereClause/OrderByClause in pr_mass_order_fmb.xml | - | - |

### 8.3 Items Summary

*Complete item inventory from `pr_mass_order_fmb.xml`.*

**Block counts:**

*Database / non-database counts derived from XML.*

| Block | Total Items | Database Items | Non-Database Items |
| :--- | ---: | ---: | ---: |
| CB_DUMMY | 17 | 0 | 17 |
| B_DTL | 13 | 7 | 6 |
| PB_BLK | 15 | 0 | 15 |
| CB_ERR | 1 | 0 | 1 |
| WEBUTIL | 9 | 0 | 9 |
| **Total** | **55** | **7** | **48** |

**Item detail (all 55 items):**

| Block | Item Name | DatabaseItem | Description |
| :--- | :--- | :--- | :--- |
| CB_DUMMY | CB_DEALER_MAP_CD | false | Dealer map code search filter; returns value from Order Number LOV |
| CB_DUMMY | CB_LOC_CD | false | Location code search filter; returns value from Order Number LOV |
| CB_DUMMY | RB_TYPE | false | Radio group to select search mode: by Order number, CO number, or date range |
| CB_DUMMY | CB_ORDER_NO | false | Purchase order number search field; active when search mode is Order |
| CB_DUMMY | CB_ORDER_NO1 | false | Secondary order number field used for CO-mode search filtering |
| CB_DUMMY | CB_ORDER_TYPE | false | Order type filter code for narrowing purchase order search results |
| CB_DUMMY | CB_ORDER_DATE | false | Order date display field populated from LOV selection |
| CB_DUMMY | CB_DLR_DESC | false | Dealer description returned from CO Number LOV selection |
| CB_DUMMY | CB_LOC_DESC | false | Location description returned from CO Number LOV selection |
| CB_DUMMY | CB_CO_NO | false | Customer order (CO) number search field; active when search mode is CO |
| CB_DUMMY | CB_CO_DATE | false | Customer order date returned from Order Number LOV selection |
| CB_DUMMY | FROM_DATE | false | Start date for date-range search; active when search mode is Date |
| CB_DUMMY | TO_DATE | false | End date for date-range search; active when search mode is Date |
| CB_DUMMY | PB_SEARCH | false | Search button - validates criteria and loads mass order details into result block |
| CB_DUMMY | PB_EXCEL | false | Export button - exports mass order results to an Excel/CSV file |
| CB_DUMMY | T1 | false | Hidden field used to store the dynamic SQL query string for Excel export |
| CB_DUMMY | COPY_RIGHT | false | Copyright notice display field populated from copyright declaration function |
| B_DTL | PO_NO | true | Purchase order number of the mass order line |
| B_DTL | PO_DATE | false | Purchase order date corresponding to the mass order |
| B_DTL | CO_NO | true | Customer order number linked to the mass order line |
| B_DTL | CO_DATE | false | Customer order date for the linked customer order |
| B_DTL | PO_TYPE | true | Purchase order type code (e.g. mass order category) |
| B_DTL | DIST_NAME | true | Distributor name derived from the dealer-location company master |
| B_DTL | DIST_LOC | true | Distributor location code associated with the mass order |
| B_DTL | PO_QTY | false | Quantity of parts on the purchase order |
| B_DTL | CO_QTY | false | Quantity of parts on the linked customer order |
| B_DTL | CBO_QTY | false | CBO (Carry-Back Order) quantity for the order line |
| B_DTL | PO_VALUE | false | Total monetary value of the purchase order line |
| B_DTL | PART_NUM | true | Part number on the mass order line |
| B_DTL | PART_DESC | true | Part description looked up from the parts master |
| PB_BLK | PB_EXIT | false | Exit button - closes the form without saving |
| PB_BLK | PB_LIST | false | List button - fires the standard list (LOV) action |
| PB_BLK | PB_INSERT | false | Insert button - fires the standard insert action |
| PB_BLK | PM_CONT | false | Continue button - reserved toolbar control |
| PB_BLK | PB_DEL | false | Delete button - fires the standard delete action |
| PB_BLK | PB_CANCEL | false | Cancel button - fires the standard cancel/undo action |
| PB_BLK | PB_SAVE | false | Save button - fires the standard save/commit action |
| PB_BLK | PB_PRINT | false | Print button - fires the standard print action |
| PB_BLK | PB_CUT | false | Cut button - cuts selected region to clipboard |
| PB_BLK | PB_COPY | false | Copy button - copies selected region to clipboard |
| PB_BLK | PB_PASTE | false | Paste button - pastes clipboard content into current item |
| PB_BLK | PB_ERR_EXIT | false | Error exit button - reserved toolbar control for error-state exit |
| PB_BLK | NB_EXIT | false | Navigation bar Exit button - sets exit flag and closes the form |
| PB_BLK | NB_CLEAR | false | Navigation bar Clear button - clears search and detail block contents |
| PB_BLK | NB_OK | false | Navigation bar OK button - closes the form without saving |
| CB_ERR | TXT_ERR | false | Error message text display item within the inherited CB_ERR block (from DPL.olb OG_GROUP); renders runtime error messages on the CN_ERR error canvas |
| WEBUTIL | DUMMY | false | WebUtil placeholder item - part of the WEBUTIL object group; contains an inactive WHEN-BUTTON-PRESSED trigger with an empty body; no active logic executes |
| WEBUTIL | WEBUTIL_CLIENTINFO_FUNCTIONS | false | WebUtil bean area item providing client machine information functions (OS, hostname, locale); infrastructure item - no direct business logic |
| WEBUTIL | WEBUTIL_FILE_FUNCTIONS | false | WebUtil bean area item providing client-side file access functions; infrastructure item - no direct business logic |
| WEBUTIL | WEBUTIL_HOST_FUNCTIONS | false | WebUtil bean area item providing host command execution functions on the client; infrastructure item - no direct business logic |
| WEBUTIL | WEBUTIL_SESSION_FUNCTIONS | false | WebUtil bean area item providing session-level utility functions; infrastructure item - no direct business logic |
| WEBUTIL | WEBUTIL_FILETRANSFER_FUNCTIONS | false | WebUtil bean area item providing file transfer (upload/download) functions between client and server; infrastructure item - no direct business logic |
| WEBUTIL | WEBUTIL_OLE_FUNCTIONS | false | WebUtil bean area item providing OLE/COM automation functions on the client; infrastructure item - no direct business logic |
| WEBUTIL | WEBUTIL_C_API_FUNCTIONS | false | WebUtil bean area item providing C API native library call functions on the client; infrastructure item - no direct business logic |
| WEBUTIL | WEBUTIL_BROWSER_FUNCTIONS | false | WebUtil bean area item providing browser control and navigation functions; infrastructure item - no direct business logic |

### 8.4 List of Values

| LOV Name | Title | Record Group | Attached Block.Item |
| :--- | :--- | :--- | :--- |
| LOV_PO | Order Number | RG_PO | CB_DUMMY.CB_DEALER_MAP_CD, CB_DUMMY.CB_LOC_CD, CB_DUMMY.CB_ORDER_NO, CB_DUMMY.CB_CO_DATE |
| LOV_CO | CO Number | RG_CO | CB_DUMMY.CB_DLR_DESC, CB_DUMMY.CB_LOC_DESC, CB_DUMMY.CB_CO_NO |

**Total LOVs:** 2

### 8.5 Alerts

| Alert Name | Title | Message Text | Calling Context |
| :--- | :--- | :--- | :--- |
| WEBUTIL_ERROR | Forms | (set at runtime) | WebUtil internal library routines (subclassed from webutil.olb); raised when a WebUtil operation fails; not called directly from form triggers or program units |
| AL_ERRINFO | Error | (set at runtime) | Inherited from DPL.olb OG_GROUP; displayed by GENERAL.DISP_TEXT when an error-level message must be shown to the user |
| AL_NOTE | Note | (set at runtime) | Inherited from DPL.olb OG_GROUP; displayed by GENERAL.DISP_TEXT when an informational message must be shown to the user |
| AL_CONFIRM | Caution | (set at runtime) | Inherited from DPL.olb OG_GROUP; displayed when a confirmation response is required from the user before proceeding |
| AL_PRINT | Print | (set at runtime) | Inherited from DPL.olb OG_GROUP; displayed by ASK_PRINT to prompt the user for a print destination (Screen, Printer, Cancel) |

**Total Alerts:** 5

### 8.6 Program Units

*Authoritative catalogue of **3 form-local program units**. Database packages and standalone procedures are in **Section 15.2**; PLD shared-library routines are in **Section 18**.*

| Program Unit | Type | Calls | Description |
| :--- | :--- | :--- | :--- |
| VIEW_EXCEL_REP | Procedure | Find_Group, Delete_Group, Create_Group_From_Query, Populate_Group, Get_Group_Row_Count, Find_Column, GET_GROUP_CHAR_CELL, Text_IO, web.show_document | Creates a server-side CSV file from a dynamic SQL query using Oracle Forms RecordGroup functions, then opens the file in the browser; superseded by DMS_EXCEL_REPORT.view_excel_report_new in current form code |
| CLEAR_ITEMS | Procedure | null | Empty stub procedure; body contains only null - no business logic is executed |
| POPULATE_DETAILS | Procedure | go_block, clear_block, first_record, next_record, GENERAL.DISP_TEXT, AM_DEALER_LOC, AM_DEALER_LOC_COMPANY_MASTER, AM_LIST, PH_PO_MASS, PH_SO, PM_PART | Loads mass purchase order detail rows into B_DTL by executing a multi-branch cursor over PH_PO_MASS and related tables; populates order, part, distributor, and customer order information based on the selected search mode |

**Total Program Units:** 3

### 8.7 Triggers

**Item-Level Trigger Types (reference):**

| Trigger Name | Purpose |
| :--- | :--- |
| WHEN-VALIDATE-ITEM | Validates field when user leaves item |
| KEY-* | Keyboard actions - commit, exit, LOV, navigation |
| WHEN-NEW-BLOCK-INSTANCE | Initializes block on entry |
| WHEN-BUTTON-PRESSED | Executes button action |
| PRE-INSERT / POST-INSERT | Before/after record creation |
| WHEN-LIST-CHANGED | Dropdown selection changed |
| PRE-QUERY / POST-QUERY | Before/after query execution |
| WHEN-CHECKBOX-CHANGED | Checkbox toggled |
| WHEN-VALIDATE-RECORD | Validates entire record before leaving row |

**DPL library routines invoked from triggers and program units:**

| Routine | Type | Called From | Purpose |
| :--- | :--- | :--- | :--- |
| GENERAL.DISP_TEXT | Library routine | CB_DUMMY.FROM_DATE (WHEN-VALIDATE-ITEM), CB_DUMMY.TO_DATE (WHEN-VALIDATE-ITEM), CB_DUMMY.PB_SEARCH (WHEN-BUTTON-PRESSED), CB_DUMMY.PB_EXCEL (WHEN-BUTTON-PRESSED), Form level (ON-ERROR), ProgramUnit: POPULATE_DETAILS | Displays a message dialog to the user with a given text and title using the AL_ERRINFO or AL_NOTE alert object |
| GENERAL.RAISE_ERROR | Library routine | Form level (ON-ERROR) | Looks up a message by error code and displays it using DISP_TEXT; raises FORM_TRIGGER_FAILURE for error-type messages |

### 8.7.1 Inactive / Commented-Out Trigger Register

*Triggers and field validations where XML source is `null;`, fully block-commented, or legacy code preserved but not executed. Do **not** migrate these as active business requirements.*

| Status | Block | Item | Trigger | Former behaviour (preserved in comments) | Disabled since / note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| INACTIVE - no-op (null only) | Form | - | KEY-COMMIT | Commented-out commit flow: enter; GENERAL.CHECK_FORM_FAILURE; commit_form; GENERAL.CHECK_FORM_FAILURE; DO_KEY('CLEAR_FORM') | Commented out by Sanjeev on 7-May-04 for prototype; body is `null;` only |
| INACTIVE - no-op (null only) | Form | - | ON-MESSAGE | Commented-out message suppression: IF errnum in (40209,40207) THEN GENERAL.DISP_TEXT ... RAISE Form_Trigger_Failure END IF | Commented out by Sanjeev on 7-May-04 for prototype; body is `null;` only |
| **Inactive stub** | Form | - | FT_SAVE | Inherited save trigger overridden at form level; body is inactive stub - standard save/commit action delegated to PB_BLK.PB_SAVE button | Overridden at form level; no active logic executes |
| **Inactive stub** | Form | - | FT_DEL | Inherited delete trigger overridden at form level; body is inactive stub - standard delete action delegated to PB_BLK.PB_DEL button | Overridden at form level; no active logic executes |
| **Inactive stub** | Form | - | FT_PRINT | Inherited print trigger overridden at form level; body is inactive stub - standard print action delegated to PB_BLK.PB_PRINT button | Overridden at form level; no active logic executes |
| **Commented out** | Form | - | WHEN-NEW-FORM-INSTANCE | Inherited form initialisation trigger; initialises global variables, sets DBMS application info, populates copyright field, and configures session context on form startup | Inherited from DPL.olb OG_GROUP; overridden or commented out at form level - initialisation logic not active in this form module |
| INACTIVE - empty body | WEBUTIL | WEBUTIL_BROWSER_FUNCTIONS | WHEN-CUSTOM-ITEM-EVENT | WebUtil browser bean area event handler | WEBUTIL infrastructure placeholder - empty body; does not execute |
| INACTIVE - empty body | WEBUTIL | WEBUTIL_C_API_FUNCTIONS | WHEN-CUSTOM-ITEM-EVENT | WebUtil C API bean area event handler | WEBUTIL infrastructure placeholder - empty body; does not execute |
| INACTIVE - empty body | WEBUTIL | WEBUTIL_OLE_FUNCTIONS | WHEN-CUSTOM-ITEM-EVENT | WebUtil OLE bean area event handler | WEBUTIL infrastructure placeholder - empty body; does not execute |
| INACTIVE - empty body | WEBUTIL | WEBUTIL_FILETRANSFER_FUNCTIONS | WHEN-CUSTOM-ITEM-EVENT | WebUtil file transfer bean area event handler | WEBUTIL infrastructure placeholder - empty body; does not execute |
| INACTIVE - empty body | WEBUTIL | WEBUTIL_SESSION_FUNCTIONS | WHEN-CUSTOM-ITEM-EVENT | WebUtil session bean area event handler | WEBUTIL infrastructure placeholder - empty body; does not execute |
| INACTIVE - empty body | WEBUTIL | WEBUTIL_HOST_FUNCTIONS | WHEN-CUSTOM-ITEM-EVENT | WebUtil host functions bean area event handler | WEBUTIL infrastructure placeholder - empty body; does not execute |
| INACTIVE - empty body | WEBUTIL | WEBUTIL_FILE_FUNCTIONS | WHEN-CUSTOM-ITEM-EVENT | WebUtil file functions bean area event handler | WEBUTIL infrastructure placeholder - empty body; does not execute |
| INACTIVE - empty body | WEBUTIL | WEBUTIL_CLIENTINFO_FUNCTIONS | WHEN-CUSTOM-ITEM-EVENT | WebUtil client info bean area event handler | WEBUTIL infrastructure placeholder - empty body; does not execute |
| INACTIVE - empty body | WEBUTIL | DUMMY | WHEN-BUTTON-PRESSED | WebUtil DUMMY item button handler | WEBUTIL infrastructure placeholder - empty body; does not execute |

*Additional null-only or partially commented triggers exist on estimation and legacy blocks - see XML `TriggerText` starting with `null;` or `/*`.*

**Complete trigger inventory (39 business triggers):**
*pr_mass_order_fmb.xml contains Trigger elements.*

| Trigger Name | Block | Item | Called From / Context | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| ON-ERROR | Form | - | Form level | Custom error handler: suppresses informational messages, displays lock conflict messages with rollback, calls GENERAL.RAISE_ERROR for FK violations, and shows SQLERRM for unexpected database errors |
| ON-MESSAGE | Form | - | Form level | **COMMENTED OUT / INACTIVE** - message suppression logic is fully commented out; executes null only |
| KEY-EXIT | Form | - | Form level | Clears DBMS application-info context and exits the form without saving |
| KEY-LISTVAL | Form | - | Form level | Shows the LOV attached to the current item at a fixed screen position; advances to the next item on successful selection |
| KEY-COMMIT | Form | - | Form level | **COMMENTED OUT / INACTIVE** - commit logic (enter, check form failure, commit_form) is fully commented out; executes null only |
| KEY-CLRFRM | Form | - | Form level | Clears the entire form without saving and repopulates the copyright notice field |
| KEY-OTHERS | Form | - | Form level (inherited) | Inherited from DPL.olb OG_GROUP; suppresses or handles all unassigned key actions at form level |
| KEY-NEXT-ITEM | Form | - | Form level (inherited) | Inherited from DPL.olb OG_GROUP; navigates to the next item in tab order |
| KEY-PREV-ITEM | Form | - | Form level (inherited) | Inherited from DPL.olb OG_GROUP; navigates to the previous item in tab order |
| KEY-NXTBLK | Form | - | Form level (inherited) | Inherited from DPL.olb OG_GROUP; navigates to the next block |
| KEY-PRVBLK | Form | - | Form level (inherited) | Inherited from DPL.olb OG_GROUP; navigates to the previous block |
| KEY-DOWN | Form | - | Form level (inherited) | Inherited from DPL.olb OG_GROUP; navigates down one record in the current block |
| KEY-UP | Form | - | Form level (inherited) | Inherited from DPL.olb OG_GROUP; navigates up one record in the current block |
| FT_SAVE | Form | - | Form level (inherited) | **INACTIVE STUB** - inherited save trigger overridden at form level; standard save/commit action is delegated to PB_BLK.PB_SAVE |
| FT_CANCEL | Form | - | Form level (inherited) | Inherited from DPL.olb OG_GROUP; fires the standard cancel/undo action; active via PB_BLK.PB_CANCEL button |
| FT_INSERT | Form | - | Form level (inherited) | Inherited from DPL.olb OG_GROUP; fires the standard insert action; active via PB_BLK.PB_INSERT button |
| FT_DEL | Form | - | Form level (inherited) | **INACTIVE STUB** - inherited delete trigger overridden at form level; standard delete action is delegated to PB_BLK.PB_DEL |
| FT_LIST | Form | - | Form level (inherited) | Inherited from DPL.olb OG_GROUP; fires the standard LOV display action; active via PB_BLK.PB_LIST button |
| FT_PRINT | Form | - | Form level (inherited) | **INACTIVE STUB** - inherited print trigger overridden at form level; standard print action is delegated to PB_BLK.PB_PRINT |
| WHEN-NEW-FORM-INSTANCE | Form | - | Form level (inherited) | **COMMENTED OUT / INACTIVE** - inherited from DPL.olb OG_GROUP; initialises global variables, sets DBMS application info, populates copyright field, and configures session context on form startup; overridden or commented out at form level |
| PRE-FORM | Form | - | Form level | Registers the form module name with Oracle DBMS Application Info for runtime monitoring before the form opens |
| WHEN-RADIO-CHANGED | CB_DUMMY | RB_TYPE | CB_DUMMY.RB_TYPE | Reconfigures search fields based on the selected search mode: enables order number, CO number, or date range fields and clears the others |
| WHEN-VALIDATE-ITEM | CB_DUMMY | FROM_DATE | CB_DUMMY.FROM_DATE | Validates FROM_DATE is not a future date and auto-calculates TO_DATE as month-end or system date, whichever is earlier |
| WHEN-VALIDATE-ITEM | CB_DUMMY | TO_DATE | CB_DUMMY.TO_DATE | Validates TO_DATE is not a future date and is not earlier than FROM_DATE |
| WHEN-BUTTON-PRESSED | CB_DUMMY | PB_SEARCH | CB_DUMMY.PB_SEARCH | Validates mandatory search criteria for the selected mode, then calls POPULATE_DETAILS to load mass order lines into B_DTL |
| WHEN-BUTTON-PRESSED | CB_DUMMY | PB_EXCEL | CB_DUMMY.PB_EXCEL | Validates search criteria, builds a dynamic SQL export query, and invokes the Excel report library to generate a CSV download |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EXIT | PB_BLK.PB_EXIT | Closes the form without saving by firing the EXIT_FORM action |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_LIST | PB_BLK.PB_LIST | Fires the standard FT_LIST trigger action to display the LOV for the current item |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_INSERT | PB_BLK.PB_INSERT | Fires the standard FT_INSERT trigger action to initiate a new record insert |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_DEL | PB_BLK.PB_DEL | Fires the standard FT_DEL trigger action to delete the current record |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CANCEL | PB_BLK.PB_CANCEL | Fires the standard FT_CANCEL trigger action to cancel pending changes |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SAVE | PB_BLK.PB_SAVE | Fires the standard FT_SAVE trigger action to save and commit the current record |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PRINT | PB_BLK.PB_PRINT | Fires the standard FT_PRINT trigger action to print the current screen or report |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CUT | PB_BLK.PB_CUT | Cuts the selected text region to the clipboard |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_COPY | PB_BLK.PB_COPY | Copies the selected text region to the clipboard |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PASTE | PB_BLK.PB_PASTE | Pastes the clipboard content into the current item |
| WHEN-BUTTON-PRESSED | PB_BLK | NB_EXIT | PB_BLK.NB_EXIT | Sets the exit flag global and closes the form without saving |
| WHEN-BUTTON-PRESSED | PB_BLK | NB_CLEAR | PB_BLK.NB_CLEAR | Clears both the detail result block and the search criteria block without saving |
| WHEN-BUTTON-PRESSED | PB_BLK | NB_OK | PB_BLK.NB_OK | Closes the form without saving |

### 8.8 Canvas and Window Inventory

**Windows:**

| Window | Title | Primary Canvas |
| :--- | :--- | :--- |
| WIN_ERR | - | CN_ERR (inherited from DPL.olb OG_GROUP; hosts the error message canvas) |
| WN_MAIN | MASS Order (Rel: 1.0.2) | CN_MAIN |

**Canvases:**

| Canvas | Type | Window |
| :--- | :--- | :--- |
| CN_ERR | Content | WIN_ERR (inherited from DPL.olb OG_GROUP; displays runtime error messages via CB_ERR block) |
| CN_TOOL | Vertical Toolbar | WN_MAIN (inherited from DPL.olb OG_GROUP; hosts the PB_BLK toolbar button block) |
| CN_MAIN | Content | WN_MAIN (primary business canvas; hosts CB_DUMMY search criteria and B_DTL results) |

---

### 8.9 Editors

*No editors found in pr_mass_order_fmb.xml.*

### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

#### 8.10.1 Visual Attributes (form-defined)

*0 VisualAttribute elements defined at form level (not inherited from DPL.olb).*

*No form-local visual attributes found in pr_mass_order_fmb.xml.*

#### 8.10.2 Property Classes (form-defined)

*Form-local PropertyClass elements.*

*No form-local property classes found in pr_mass_order_fmb.xml.*

#### 8.10.3 Object Groups

*Object groups bundle inherited triggers and visual objects applied form-wide at runtime. All entries below are inherited from DPL.olb.*

| Object Group Child | Type |
| :--- | :--- |
| KEY-OTHERS | Inherited trigger |
| KEY-NEXT-ITEM | Inherited trigger |
| KEY-PREV-ITEM | Inherited trigger |
| KEY-NXTBLK | Inherited trigger |
| KEY-PRVBLK | Inherited trigger |
| KEY-DOWN | Inherited trigger |
| KEY-UP | Inherited trigger |
| CN_ERR | Inherited canvas |
| VA_DISP | Inherited visualattribute |
| CB_ERR | Inherited block |
| VA_LOV | Inherited visualattribute |
| VA_TRNI_DT | Inherited visualattribute |
| VA_TITLE | Inherited visualattribute |
| VA_ALERT | Inherited visualattribute |
| VA_BUTN | Inherited visualattribute |
| VA_TEXT | Inherited visualattribute |
| VA_MPROMPT | Inherited visualattribute |
| VA_OPROMPT | Inherited visualattribute |
| VA_MAND | Inherited visualattribute |
| VA_NUM | Inherited visualattribute |
| VA_DESC | Inherited visualattribute |
| VA_ICONIC_BUTN | Inherited visualattribute |
| VA_RB | Inherited visualattribute |
| VA_CB | Inherited visualattribute |
| WN_MAIN | Inherited window |
| POP_MAIN | Inherited trigger |
| CN_MAIN | Inherited canvas |
| CN_TOOL | Inherited canvas |
| PB_BLK | Inherited block |
| AL_ERRINFO | Inherited alert |
| AL_NOTE | Inherited alert |
| AL_CONFIRM | Inherited alert |
| WIN_ERR | Inherited window |
| AL_PRINT | Inherited alert |
| FT_SAVE | Inherited trigger |
| FT_CANCEL | Inherited trigger |
| FT_INSERT | Inherited trigger |
| FT_DEL | Inherited trigger |
| FT_LIST | Inherited trigger |
| FT_PRINT | Inherited trigger |
| WHEN-NEW-FORM-INSTANCE | Inherited trigger |

### 8.11 DataSourceColumn Inventory

*29 DataSourceColumn elements across 1 blocks - formal query column-to-block mapping from pr_mass_order_fmb.xml.*

#### B_DTL (29 columns)

| Column (DSCName) | Data Type |
| :--- | :--- |
| APPLY_MODEL_CD | VARCHAR2 |
| CATG_CD | VARCHAR2 |
| CREATED_BY | VARCHAR2 |
| CREATED_DATE | DATE |
| DEALER_MAP_CD | NUMBER |
| EFF_FROM_DATE | DATE |
| EFF_TO_DATE | DATE |
| LANDED_COST | NUMBER |
| MIN_ORD_QTY | NUMBER |
| MODIFIED_BY | VARCHAR2 |
| MODIFIED_DATE | DATE |
| MRP_1 | NUMBER |
| PART_DESC | VARCHAR2 |
| PART_NUM | VARCHAR2 |
| PRINCIPAL_MAP_CD | NUMBER |
| PURCHASE_PRICE | NUMBER |
| SELL_PRICE | NUMBER |
| SOURCE_CD | VARCHAR2 |
| UOM_CD | VARCHAR2 |
| ROOT_PART_NUM | VARCHAR2 |
| SEQ_NUM | NUMBER |
| TYPE_CD | VARCHAR2 |
| SUB_TYPE_CD | VARCHAR2 |
| TAG_CD | VARCHAR2 |
| MUL_YN | VARCHAR2 |
| VOR_YN | VARCHAR2 |
| SUB_CATG1_CD | VARCHAR2 |
| SUB_CATG2_CD | VARCHAR2 |
| BRAND_CD | VARCHAR2 |

**Total DataSourceColumns:** 29 across 1 blocks

## 9. Object Library

*The form references two Object Library (OLB) files: `DPL_olb.xml` (the DPL framework library, containing Visual Attributes and Property Classes used across the application suite) and `webutil_olb.xml` (the WebUtil Object Library, containing the WebUtil integration object groups required for client-side file and browser operations).*

Source OLB file(s): DPL_olb.xml, webutil_olb.xml

| Name | Type | Description | Used By (count) | Sample Items |
| ---- | ---- | ----------- | --------------- | ------------ |
| VA_CB | VisualAttribute | Visual attribute for check box items | referenced | N/A |
| VA_RB | VisualAttribute | Visual attribute for radio button items | referenced | N/A |
| VA_ICONIC_BUTN | VisualAttribute | Visual attribute for iconic push buttons | referenced | N/A |
| VA_DESC | VisualAttribute | Visual attribute for description/label items | referenced | N/A |
| VA_NUM | VisualAttribute | Visual attribute for numeric display items | referenced | N/A |
| VA_MAND | VisualAttribute | Visual attribute for mandatory input items | referenced | N/A |
| VA_OPROMPT | VisualAttribute | Visual attribute for optional prompt labels | referenced | N/A |
| VA_MPROMPT | VisualAttribute | Visual attribute for mandatory prompt labels | referenced | N/A |
| VA_TEXT | VisualAttribute | Visual attribute for text input items | referenced | N/A |
| VA_BUTN | VisualAttribute | Visual attribute for standard push buttons | referenced | N/A |
| VA_ALERT | VisualAttribute | Visual attribute for alert messages | referenced | N/A |
| VA_TITLE | VisualAttribute | Visual attribute for screen/section titles | referenced | N/A |
| VA_TRNI_DT | VisualAttribute | Visual attribute for transaction date items | referenced | N/A |
| VA_LOV | VisualAttribute | Visual attribute for list-of-values (LOV) items | referenced | N/A |
| VA_DISP | VisualAttribute | Visual attribute for read-only display items | referenced | N/A |
| PC_DESC | PropertyClass | Property class for description/label items | referenced | N/A |
| PC_SC_DATE | PropertyClass | Property class for date items (PROPERTY CLASS FOR DATE) | referenced | N/A |
| PC_TITLE | PropertyClass | Property class for title text items (PROPERTY CLASS FOR TEXT ITEMS) | referenced | N/A |
| PC_FORMAT | PropertyClass | Property class for formatted text items (PROPERTY CLASS FOR TEXT ITEMS) | referenced | N/A |
| PC_MR_BLK | PropertyClass | Property class for multi-row block layout | referenced | N/A |
| PC_DISP | PropertyClass | Property class for read-only display text items (PROPERTY CLASS FOR TEXT ITEMS) | referenced | N/A |
| PC_LOV | PropertyClass | Property class for list-of-values items (PROPERTY CLASS FOR LIST OF VALUES) | referenced | N/A |
| PC_FORM | PropertyClass | Property class for form-level properties | referenced | N/A |
| PC_DISP_DATE | PropertyClass | Property class for read-only display date items (PROPERTY CLASS FOR TEXT ITEMS) | referenced | N/A |
| PC_DISP_NUM | PropertyClass | Property class for read-only display numeric items (PROPERTY CLASS FOR TEXT ITEMS) | referenced | N/A |
| PC_DATE | PropertyClass | Property class for editable date items (PROPERTY CLASS FOR DATE) | referenced | N/A |
| PC_DTTIME | PropertyClass | Property class for date-and-time items (Property class for Date and Time) | referenced | N/A |
| PC_CB | PropertyClass | Property class for check box items | referenced | N/A |
| PC_ALERT | PropertyClass | Property class for alert objects | referenced | N/A |
| PC_MDATE | PropertyClass | Property class for mandatory date items (PROPERTY CLASS FOR DATE) | referenced | N/A |
| PC_RB | PropertyClass | Property class for radio button items | referenced | N/A |
| PC_WIND | PropertyClass | Property class for window objects (PROPERTY CLASS FOR WINDOWS) | referenced | N/A |
| PC_CANV | PropertyClass | Property class for canvas objects | referenced | N/A |
| PC_BUTN | PropertyClass | Property class for standard push buttons (PROPERTY CLASS FOR PUSH BUTTONS) | referenced | N/A |
| PC_TEXT | PropertyClass | Property class for editable text items (PROPERTY CLASS FOR TEXT ITEMS) | referenced | N/A |
| PC_MTEXT | PropertyClass | Property class for mandatory editable text items (PROPERTY CLASS FOR TEXT ITEMS) | referenced | N/A |
| PC_UTEXT | PropertyClass | Property class for upper-case text items (PROPERTY CLASS FOR TEXT ITEMS) | referenced | N/A |
| PC_MUTEXT | PropertyClass | Property class for mandatory upper-case text items (PROPERTY CLASS FOR TEXT ITEMS) | referenced | N/A |
| PC_NUM | PropertyClass | Property class for numeric items (PROPERTY CLASS FOR NUMERIC ITEMS) | referenced | N/A |
| PC_MNUM | PropertyClass | Property class for mandatory numeric items (PROPERTY CLASS FOR NUMERIC ITEMS) | referenced | N/A |
| PC_ICONIC_BUTN | PropertyClass | Property class for iconic push buttons (PROPERTY CLASS FOR PUSH BUTTONS) | referenced | N/A |
| PC_SCROLL | PropertyClass | Property class for scrollable items | referenced | N/A |
| OG_GROUP | ObjectGroup | Form-level object group inherited from DPL library (standard form template group) | referenced | N/A |
| WEBUTIL | ObjectGroup | WebUtil integration object group - contains the WEBUTIL block, canvas, hidden window, and error item required for client-side file transfer and browser operations (The WebUtil object group contains everything needed to use WebUtil in your form) | referenced | WEBUTIL block, WEBUTIL_CANVAS, WEBUTIL_HIDDEN_WINDOW, WEBUTIL_ERROR |
| WEBUTIL_NO_OLE | ObjectGroup | WebUtil integration object group variant for environments without OLE support - same structure as WEBUTIL but excludes OLE-dependent items (The WebUtil object group contains everything needed to use WebUtil in your form) | referenced | WEBUTIL block, WEBUTIL_CANVAS, WEBUTIL_HIDDEN_WINDOW, WEBUTIL_ERROR |

---

## 10. Record Groups

*Lists all record groups, their LOV bindings, query logic, dynamic bindings, business purpose, and form usage.*

| Record Group | Type | Used By LOV | Display Column | Return Column | Dynamic Bindings | Purpose | Where Used |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| RG_CO | Query | LOV_CO | SO_NUM | PO_NUM | No | Lists customer orders (SO numbers) for the user to select the CO number search filter | LOV_CO -> CB_DUMMY.CB_DLR_DESC, CB_DUMMY.CB_LOC_DESC, CB_DUMMY.CB_CO_NO |
| RG_PO | Query | LOV_PO | PO_NUM | PO_DATE | No | Lists purchase order numbers for the user to select the order number and associated order date | LOV_PO -> CB_DUMMY.CB_DEALER_MAP_CD, CB_DUMMY.CB_LOC_CD, CB_DUMMY.CB_ORDER_NO, CB_DUMMY.CB_CO_DATE |

**Total Record Groups:** 2

## 11. Referenced Database Objects

*Database tables, views, and objects accessed by the form.*

| Block | Base Table | Primary Key Item | Database Item |
| :--- | :--- | :--- | :--- |
| CB_DUMMY | - | - | No |
| B_DTL | - | - | No |
| PB_BLK | - | - | No |

| Object | Schema | Used In | Description |
| :--- | :--- | :--- | :--- |
| `AM_DEALER_LOC` | - | POPULATE_DETAILS, Trigger WHEN-NEW-FORM-INSTANCE | Dealer location master - stores dealer name and location description for each dealer-location combination |
| `AM_DEALER_LOC_COMPANY_MASTER` | - | POPULATE_DETAILS | Dealer-location company master - maps dealer-location pairs to parent group and company code |
| `AM_LIST` | - | POPULATE_DETAILS | Application list master - stores code-description pairs for configurable lookup lists such as PO mass order types |
| `DUAL` | - | Trigger WHEN-BUTTON-PRESSED | Oracle system dual table - used to retrieve the current system date during Excel export query construction |
| `PH_PO_MASS` | - | POPULATE_DETAILS, RG_CO, RG_PO | Mass purchase order header - primary table storing mass order header records including order number, date, type, and status |
| `PH_SO` | - | POPULATE_DETAILS, Trigger WHEN-BUTTON-PRESSED | Sales order header - stores customer order date and details used to populate the CO date on each mass order detail line |
| `PM_PART` | - | POPULATE_DETAILS | Parts master - stores part description for each part number used in mass order lines |

**Total Referenced Objects:** 7

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure/Package Index

| Requirement ID | Procedure/Package | Purpose |
| -------------- | ----------------- | ------- |
| BR-005 | POPULATE_DETAILS | Queries mass order header and detail records matching the search criteria and populates the results grid |
| BR-006 | VIEW_EXCEL_REPORT_NEW | Builds and delivers a comma-separated Excel export of mass order data to the user's browser |
| BR-009 | GENERAL.RAISE_ERROR | Displays a registered business error message for a specific error/constraint code and halts trigger processing |
| BR-001, BR-007 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Writes (BR-001) and clears (BR-007) the client identifier on the active database session |
| BR-001, BR-007 | DBMS_APPLICATION_INFO.SET_MODULE | Writes (BR-001) and clears (BR-007) the module name on the active database session |
| BR-002, BR-003, BR-004, BR-005, BR-006, BR-009 | GENERAL.DISP_TEXT | Displays a message to the user at a specified severity level (error, warning, or informational) |
| BR-008 | SF_COPYRIGHT_DECLARATION | Returns the current copyright declaration text for display in the copyright notice field |
| - | GENERAL.ASK_CONFIRM | Displays a confirmation dialog and returns the user's choice before proceeding with a gated action |
| - | WEBUTIL_CORE.CUSTOMEVENTHANDLER | Central WebUtil event dispatcher that routes client-side bean events to the appropriate WebUtil handler on the Forms server |
| - | WEBUTIL.ID_NULL | Checks whether a WebUtil client handle is null; used in VIEW_EXCEL_REP to validate a handle before client-side file operations |

---

### 12.2 Procedure and Package Catalogue

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| POPULATE_DETAILS | Form Program Unit (PROCEDURE) | WHEN-BUTTON-PRESSED on CB_DUMMY.PB_SEARCH | Retrieves matching mass order header and detail records for the selected search criteria and populates the results grid; handles no-data and database errors |
| VIEW_EXCEL_REPORT_NEW | External / Attached Library Procedure (`EXTERNAL / NOT IN BUNDLE - dependency not verifiable`) | WHEN-BUTTON-PRESSED on CB_DUMMY.PB_EXCEL | Generates and delivers a CSV file of mass order data to the user's browser; accepts principal, filename, query string, column name, and application ID as inputs |
| GENERAL.DISP_TEXT | Attached Library Package Routine (DPL) (`EXTERNAL / NOT IN BUNDLE - dependency not verifiable`) | ON-ERROR (Form), WHEN-VALIDATE-ITEM on CB_DUMMY.FROM_DATE, WHEN-VALIDATE-ITEM on CB_DUMMY.TO_DATE, WHEN-BUTTON-PRESSED on CB_DUMMY.PB_SEARCH, WHEN-BUTTON-PRESSED on CB_DUMMY.PB_EXCEL, WHEN-NEW-FORM-INSTANCE (Form), POPULATE_DETAILS program unit | Displays a modal alert dialog to the user at the specified severity level (Error, Warning, Info/Note); uses AL_ERRINFO for error messages and AL_NOTE for informational messages |
| GENERAL.RAISE_ERROR | Attached Library Package Routine (DPL) (`EXTERNAL / NOT IN BUNDLE - dependency not verifiable`) | ON-ERROR (Form) when DBMS_ERROR_CODE = -02292 | Looks up the registered business error message for a given error code, displays it via GENERAL.DISP_TEXT, and raises FORM_TRIGGER_FAILURE for fatal (Error-type) conditions so the user can address the error |
| GENERAL.ASK_CONFIRM | Attached Library Package Routine (DPL) (`EXTERNAL / NOT IN BUNDLE - dependency not verifiable`) | WHEN-BUTTON-PRESSED on WEBUTIL.DUMMY | Displays a confirmation dialog presenting the supplied message text and returns a numeric value indicating the user's choice (1 = confirmed, 2 = cancelled); used to gate a user-initiated action on explicit confirmation before proceeding |
| DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Oracle Built-In Package | PRE-FORM (Form), KEY-EXIT (Form) | Sets (at form open, to `'pr_mass_order'`) and clears (at form exit, to null) the client identifier on the active Oracle database session for monitoring and tracing purposes |
| DBMS_APPLICATION_INFO.SET_MODULE | Oracle Built-In Package | PRE-FORM (Form), KEY-EXIT (Form) | Sets (at form open, to `'pr_mass_order'`) and clears (at form exit, to empty string) the module name on the active Oracle database session for monitoring and tracing purposes |
| SF_COPYRIGHT_DECLARATION | Standalone Database Function (`EXTERNAL / NOT IN BUNDLE - dependency not verifiable`) | KEY-CLRFRM (Form) | Returns the current copyright declaration text to be written into the copyright notice display field after the form is cleared |
| WEBUTIL_CORE.CUSTOMEVENTHANDLER | WebUtil Library Procedure (`EXTERNAL / NOT IN BUNDLE - dependency not verifiable`) | WHEN-CUSTOM-ITEM-EVENT on WEBUTIL.WEBUTIL_BROWSER_FUNCTIONS, WEBUTIL.WEBUTIL_CLIENTINFO_FUNCTIONS, WEBUTIL.WEBUTIL_C_API_FUNCTIONS, WEBUTIL.WEBUTIL_FILETRANSFER_FUNCTIONS, WEBUTIL.WEBUTIL_FILE_FUNCTIONS, WEBUTIL.WEBUTIL_HOST_FUNCTIONS, WEBUTIL.WEBUTIL_OLE_FUNCTIONS, WEBUTIL.WEBUTIL_SESSION_FUNCTIONS | Central WebUtil event dispatcher; receives the name and serialised parameter string of each custom event fired by a WebUtil Java bean and routes it to the appropriate internal WebUtil handler, enabling asynchronous client-side responses (file transfers, host commands, OLE actions, browser calls, session queries, and client-info lookups) to be processed on the Forms server side |
| WEBUTIL.ID_NULL | WebUtil Library Function (`EXTERNAL / NOT IN BUNDLE - dependency not verifiable`) | VIEW_EXCEL_REP program unit | Checks whether a WebUtil client handle has a null value; returns TRUE if null, FALSE otherwise; used in VIEW_EXCEL_REP to validate an internal WebUtil handle before proceeding with client-side file operations |
| WEB.SHOW_DOCUMENT | Oracle Forms Built-In (WebUtil) | VIEW_EXCEL_REP program unit (`COMMENTED OUT / INACTIVE - called from inactive code path only; active calls use VIEW_EXCEL_REPORT_NEW instead`) | Opens a URL in the user's browser; used by the legacy internal export procedure that has been superseded by VIEW_EXCEL_REPORT_NEW |

---

#### POPULATE_DETAILS

**Type:** Form Program Unit (Procedure)

**Called from:** WHEN-BUTTON-PRESSED trigger on the Search button (CB_DUMMY.PB_SEARCH)

**Purpose:** Queries mass order header records (PH_PO_MASS) joined to detail lines (PD_PO_MASS) using the active search criteria (date range, order number, or CO number), then enriches each result row with the distributor name/location (AM_DEALER_LOC, AM_DEALER_LOC_COMPANY_MASTER), CO date (PH_SO), order type description (AM_LIST / PO_MASS_TYPE), and part description (PM_PART) before populating the on-screen results grid (B_DTL block). Handles the case where no rows are returned with a "Data not available" warning, and surfaces any unexpected database errors with the error detail via GENERAL.DISP_TEXT.

---

#### VIEW_EXCEL_REPORT_NEW

**Type:** External Procedure / Attached Library (`EXTERNAL / NOT IN BUNDLE`)

**Called from:** WHEN-BUTTON-PRESSED trigger on the Export to Excel button (CB_DUMMY.PB_EXCEL)

**Purpose:** Accepts the current principal identifier, a generated unique filename, a dynamic SQL query string for the export data (constructed using the current system date retrieved from DUAL and CO number from PH_SO), the query result column name, and an application identifier; executes the query, writes the results (including a column-header row) to a server-side CSV file under the provided filename, and delivers the file to the user's browser for download. Any exception is silently suppressed.

---

#### GENERAL.DISP_TEXT

**Type:** Attached Library Package Routine (DPL) (`EXTERNAL / NOT IN BUNDLE`)

**Called from:** Multiple triggers and the POPULATE_DETAILS program unit - specifically: ON-ERROR (Form), WHEN-NEW-FORM-INSTANCE (Form), WHEN-VALIDATE-ITEM on CB_DUMMY.FROM_DATE, WHEN-VALIDATE-ITEM on CB_DUMMY.TO_DATE, WHEN-BUTTON-PRESSED on CB_DUMMY.PB_SEARCH, WHEN-BUTTON-PRESSED on CB_DUMMY.PB_EXCEL, and the POPULATE_DETAILS program unit

**Signature:** `Procedure(text_string VARCHAR2, title_string VARCHAR2)`

**Purpose:** Displays a modal alert dialog to the user using AL_ERRINFO for error-level messages and AL_NOTE for informational messages. Sets the alert title to `title_string` and body text to `text_string` before showing. Used throughout the form for validation errors, search-mode messages, and error-handler notifications.

---

#### GENERAL.RAISE_ERROR

**Type:** Attached Library Package Routine (DPL) (`EXTERNAL / NOT IN BUNDLE`)

**Called from:** ON-ERROR trigger (Form level) when DBMS_ERROR_CODE = -02292 (FK violation)

**Signature:** `Procedure(mesg_code IN VARCHAR2)`

**Purpose:** Looks up the registered business error message associated with the supplied error code and displays it to the user via GENERAL.DISP_TEXT; raises FORM_TRIGGER_FAILURE when the message type is Error so the user must address the condition; displays a note or caution for non-fatal conditions.

---

#### GENERAL.ASK_CONFIRM

**Type:** Attached Library Package Routine (DPL) (`EXTERNAL / NOT IN BUNDLE`)

**Called from:** WHEN-BUTTON-PRESSED trigger on WEBUTIL.DUMMY

**Signature:** `Function(confirm_msg VARCHAR2) RETURN NUMBER`

**Purpose:** Displays a confirmation dialog presenting the message text supplied in `confirm_msg` and returns a numeric value indicating the user's choice (typically 1 for confirmed, 2 for cancelled). Used to gate a user-initiated action on explicit confirmation before proceeding.

---

#### DBMS_APPLICATION_INFO.SET_CLIENT_INFO

**Type:** Oracle Built-In Package

**Called from:** PRE-FORM (sets client info to `'pr_mass_order'`); KEY-EXIT (sets client info to null)

**Purpose:** Writes or clears the client identifier in the active Oracle database session, enabling session-level monitoring and tracing tools to identify which application module is active.

---

#### DBMS_APPLICATION_INFO.SET_MODULE

**Type:** Oracle Built-In Package

**Called from:** PRE-FORM (sets module to `'pr_mass_order'`); KEY-EXIT (sets module to empty string)

**Purpose:** Writes or clears the module name in the active Oracle database session, enabling session-level monitoring and tracing tools to identify which module is running in each session.

---

#### SF_COPYRIGHT_DECLARATION

**Type:** Standalone Database Function (`EXTERNAL / NOT IN BUNDLE`)

**Called from:** KEY-CLRFRM trigger (Form level)

**Purpose:** Returns the current copyright declaration text to be written into the copyright notice display field after the form is cleared.

---

#### WEBUTIL_CORE.CUSTOMEVENTHANDLER

**Type:** WebUtil Library Procedure (`EXTERNAL / NOT IN BUNDLE`)

**Called from:** WHEN-CUSTOM-ITEM-EVENT triggers on WEBUTIL.WEBUTIL_BROWSER_FUNCTIONS, WEBUTIL.WEBUTIL_CLIENTINFO_FUNCTIONS, WEBUTIL.WEBUTIL_C_API_FUNCTIONS, WEBUTIL.WEBUTIL_FILETRANSFER_FUNCTIONS, WEBUTIL.WEBUTIL_FILE_FUNCTIONS, WEBUTIL.WEBUTIL_HOST_FUNCTIONS, WEBUTIL.WEBUTIL_OLE_FUNCTIONS, and WEBUTIL.WEBUTIL_SESSION_FUNCTIONS

**Signature:** `Procedure(EventName in VARCHAR2, EventParameters in VARCHAR2)`

**Purpose:** Central WebUtil event dispatcher. Receives the name of the custom event fired by a WebUtil Java bean (`EventName`) together with its serialised parameter string (`EventParameters`) and routes the event to the appropriate WebUtil internal handler, enabling asynchronous client-side responses - including file transfers, host commands, OLE actions, browser calls, session queries, and client-info lookups - to be processed on the Forms server side.

---

#### WEBUTIL.ID_NULL

**Type:** WebUtil Library Function (`EXTERNAL / NOT IN BUNDLE`)

**Called from:** VIEW_EXCEL_REP program unit

**Signature:** `Function(handle IN Pointer) RETURN BOOLEAN`

**Purpose:** Checks whether a WebUtil client handle has a null value; returns TRUE if the handle is null, FALSE otherwise. Used in VIEW_EXCEL_REP to validate an internal WebUtil client handle before proceeding with client-side file operations. Note: VIEW_EXCEL_REP is the legacy internal export program unit that has been superseded by VIEW_EXCEL_REPORT_NEW for active export functionality.

---

#### WEB.SHOW_DOCUMENT *(Inactive - legacy code path only)*

**Type:** Oracle Forms Built-In (WebUtil)

**Called from:** VIEW_EXCEL_REP program unit (`COMMENTED OUT / INACTIVE - called from inactive code path only; active export calls use VIEW_EXCEL_REPORT_NEW instead`)

**Purpose:** Opens a URL in the user's browser. Used by the legacy internal export procedure VIEW_EXCEL_REP that has been superseded by VIEW_EXCEL_REPORT_NEW; this call is no longer executed in the active form.

## 13. Package Procedure Specifications

*NO PCK files found - no `*.pck` source files were discovered in the form sources input directory. Package specifications cannot be generated without uploaded PCK sources.*

## 14. Database Package Catalogue

*NO PCK files found - no `*.pck` source files were discovered in `/app/section-rewrite-pipeline/workspaces/a37b69c9-473c-4c94-99c5-c3c07068d181/inputs/form_sources`. The database package catalogue cannot be generated without uploaded PCK sources.*

## 15. PLD Procedure Call Sites

*Maps each program-library routine to its call sites within triggers and program units. Behaviour descriptions are derived from the uploaded ``.pld`` sources.*

### DPL.pld (`general`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ASK_CONFIRM | Function | Function(confirm_msg VARCHAR2) RETURN NUMBER | Trigger: WHEN-BUTTON-PRESSED in WEBUTIL.DUMMY | Displays a confirmation dialog to the user presenting the message text supplied in confirm_msg and returns a numeric value indicating the user's choice (typically 1 for confirmed, 2 for cancelled). Called in the WHEN-BUTTON-PRESSED trigger of WEBUTIL.DUMMY to gate a user-initiated action on explicit confirmation before proceeding. |
| DISP_TEXT | Procedure | Procedure(text_string VARCHAR2, title_string VARCHAR2) | ProgramUnit: POPULATE_DETAILS, Trigger: ON-ERROR in Form, Trigger: WHEN-BUTTON-PRESSED in CB_DUMMY.PB_EXCEL, Trigger: WHEN-BUTTON-PRESSED in CB_DUMMY.PB_SEARCH, Trigger: WHEN-NEW-FORM-INSTANCE in Form, Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.FROM_DATE, Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.TO_DATE | Displays a modal alert dialog to the user using the AL_ERRINFO alert for error messages and AL_NOTE for informational messages. Sets the alert title to title_string and body text to text_string before showing. Used for validation errors, search-mode messages, and error-handler notifications. |
| RAISE_ERROR | Procedure | Procedure(mesg_code IN VARCHAR2) | Trigger: ON-ERROR in Form | Looks up an error message by its code and displays it via DISP_TEXT; raises FORM_TRIGGER_FAILURE when message type is Error; displays a note or caution for non-fatal conditions. Called in ON-ERROR for Oracle error -02292 (FK violation). |

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``pr_mass_order_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| CHECK_FORM_FAILURE | Procedure | Procedure() | Trigger: KEY-COMMIT in Form | **COMMENTED OUT / INACTIVE** - previously verified that the last Forms statement executed successfully after enter and commit_form calls; displayed an error dialog and raised FORM_TRIGGER_FAILURE on failure. The entire KEY-COMMIT trigger body is commented out, so this routine is not executed. |

**Total Active Routines:** 3 of 24 in DPL.pld source
**Inactive / commented-only routines:** 1

---

### webutil.pld (`WEBUTIL_CORE`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| CustomEventHandler | Procedure | Procedure(EventName in VARCHAR2, EventParameters in VARCHAR2) | Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_BROWSER_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_CLIENTINFO_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_C_API_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_FILETRANSFER_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_FILE_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_HOST_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_OLE_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_SESSION_FUNCTIONS | Central WebUtil event dispatcher invoked by the WHEN-CUSTOM-ITEM-EVENT trigger on each WebUtil functional bean item. Receives the name of the custom event fired by the Java bean (EventName) together with its serialised parameter string (EventParameters) and routes the event to the appropriate WebUtil internal handler, enabling asynchronous client-side responses (file transfers, host commands, OLE actions, browser calls, session queries, and client-info lookups) to be processed on the Forms server side. |

**Total Active Routines:** 1 of 39 in webutil.pld source

---

### webutil.pld (`WEBUTIL_C_API`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ID_NULL | Function | Function(handle IN Pointer) RETURN BOOLEAN | ProgramUnit: VIEW_EXCEL_REP | Checks whether a WebUtil handle has a null value. Returns TRUE if the handle is null, FALSE otherwise. Used in VIEW_EXCEL_REP to test the validity of an internal WebUtil client handle before proceeding with client-side file operations. |

**Total Active Routines:** 1 of 28 in webutil.pld source

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| ID | Service Name | Database Object | Input Parameters | Output | Business Function | API Endpoint Suggestion |
| -- | ------------ | --------------- | ---------------- | ------ | ----------------- | ----------------------- |
| MS-001 | Mass Order Search Service | PH_PO_MASS, PD_PO_MASS (with joins to AM_DEALER_LOC, AM_DEALER_LOC_COMPANY_MASTER, PH_SO, AM_LIST, PM_PART) | searchType (O/C/D), orderNumber, coNumber, fromDate, toDate, dealer, locationCode, parentGroup, companyFa, principal | Array of mass order lines (orderNum, orderDate, coNum, coDate, orderType, distributorName, distributorLocation, partNum, partDesc, poQty, billedQty, boQty, boValue) | Retrieves mass purchase order lines matching the provided search criteria and enriches each line with distributor, order type, part description, and CO date from reference tables | `GET /api/mass-orders/search` |
| MS-002 | Mass Order Export Service | PH_PO_MASS, PD_PO_MASS (same joins as MS-001) | searchType, orderNumber, coNumber, fromDate, toDate, dealer, locationCode, parentGroup, companyFa, principal, applicationId | CSV file stream (Order Num, Order Date, CO Num, CO Date, Order Type, Distributor Name, Distributor Location, Part Num, Part Desc, PO Qty, Billed Qty, BO Qty, BO Value) | Builds and returns a downloadable CSV export of all mass order lines matching the provided search criteria, with a column-header row prepended | `GET /api/mass-orders/export/csv` |
| MS-003 | Copyright Declaration Service | SF_COPYRIGHT_DECLARATION (standalone database function - `EXTERNAL / NOT IN BUNDLE`) | None | Copyright declaration text string | Returns the current application copyright declaration text for display in the screen footer | `GET /api/config/copyright` |

**Total Microservices Identified: 3**

---

## 17. Workflows

| ID | Workflow Name | Trigger Event | Steps | Decision Points | End State |
| -- | ------------- | ------------- | ----- | --------------- | --------- |
| WF-001 | Form Initialisation | User opens the mass order enquiry screen (PRE-FORM) | 1. System writes module identifier and client identity to the active database session | None | Screen is ready for input; session registered |
| WF-002 | Search Type Selection | User changes the search type radio button (WHEN-RADIO-CHANGED on RB_TYPE) | 1. System clears filter fields not relevant to the new type. 2. System disables irrelevant fields and enables the relevant input field(s). 3. For Date Range type: system sets default From Date (first day of current month) and To Date (today) | Three-way branch: Order Number / CO Number / Date Range type selected | Screen filter area reconfigured for the selected search type; default dates applied for Date Range |
| WF-003 | From Date Entry and To Date Auto-Calculation | User enters or changes the From Date field (WHEN-VALIDATE-ITEM on FROM_DATE) | 1. System validates From Date is not in the future. 2. If valid, system calculates the To Date as last day of next month (or today if that would be in the future) and populates To Date | Decision: From Date > today -> reject; From Date valid -> calculate To Date | To Date auto-populated; user can proceed to enter To Date or accept default |
| WF-004 | To Date Validation | User enters or changes the To Date field (WHEN-VALIDATE-ITEM on TO_DATE) | 1. System validates To Date is not in the future. 2. System validates To Date is not before From Date. 3. System validates To Date is not blank when From Date is populated | Three sequential validations; each failure raises an error message and halts | To Date accepted; all date range boundaries are valid |
| WF-005 | Mass Order Search | User presses the Search button (WHEN-BUTTON-PRESSED on PB_SEARCH) | 1. System validates required search criteria for the active search type. 2. POPULATE_DETAILS procedure queries the database for matching mass order lines. 3. Each result row is enriched with distributor name, CO date, order type description, and part description. 4. Results grid is cleared and populated with all matched rows. 5. Focus returned to first result row | Decision: search type determines filter check; no matching rows -> "Data not available" warning; database error -> error message shown | Results grid populated with matching orders; or warning/error shown if no data or failure |
| WF-006 | Mass Order Excel Export | User presses the Export to Excel button (WHEN-BUTTON-PRESSED on PB_EXCEL) | 1. System validates required search criteria for the active search type. 2. System builds dynamic export query for the selected search type. 3. System generates a unique filename (user ID + timestamp). 4. VIEW_EXCEL_REPORT_NEW service writes results to a CSV file and delivers it to the user's browser. 5. Any exception is silently suppressed | Decision: search type determines filter check and query variant; WHEN OTHERS -> silent suppression | CSV file delivered to user's browser for download; or criteria validation error shown |
| WF-007 | Form Exit | User presses the exit key or clicks an exit button (KEY-EXIT / WHEN-BUTTON-PRESSED on PB_EXIT / NB_EXIT / NB_OK) | 1. For KEY-EXIT and NB_EXIT: session module identifier and client identity cleared. 2. For NB_EXIT: global exit flag set. 3. Form closed without saving any pending changes | Decision: which exit path determines whether session deregistration runs | Form closed; database session deregistered (for KEY-EXIT and NB_EXIT paths) |
| WF-008 | Screen Clear | User triggers the Clear Form action (KEY-CLRFRM) | 1. All blocks and fields cleared without saving. 2. Copyright declaration function called to refresh the copyright notice field | None | Screen reset to clean state; copyright notice refreshed |
| WF-009 | Application Error Handling | Any screen action raises an error (ON-ERROR, Form level) | 1. System identifies the error code. 2. Referential integrity violation (-02292): GENERAL.RAISE_ERROR displays business message. 3. Known display/navigation error codes: formatted error message shown, processing halts. 4. Record concurrency conflict: message shown, rollback, processing halts. 5. Other unexpected database errors: database error text shown, rollback, processing halts. 6. Known no-data codes (40401, 40405): silently ignored | Multi-way branch on error code category | User informed of error (or error silently suppressed for no-data codes); pending changes rolled back where applicable |

**Total Workflows Identified: 9**

---

## 18. PLD-Backed Logic

*Maps shared library routines to their business function and suggested API contracts.*

### webutil.pld (`CLIENT_IMAGE`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | ID_NULL | Business Logic | ProgramUnit: VIEW_EXCEL_REP | /api/v1/pld/id_null | When a WebUtil handle is evaluated, then returns whether the handle is null to guard client-side file operations |


---

### DPL.pld (`general`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | CHECK_FORM_FAILURE | Validation | Trigger: KEY-COMMIT in Form | /api/v1/pld/check_form_failure | **COMMENTED OUT / INACTIVE** - when the last Forms statement fails, then displays an error message and halts trigger execution |
| PLD-002 | DISP_TEXT | Business Logic | ProgramUnit: POPULATE_DETAILS, Trigger: ON-ERROR in Form, Trigger: WHEN-BUTTON-PRESSED in CB_DUMMY.PB_EXCEL, Trigger: WHEN-BUTTON-PRESSED in CB_DUMMY.PB_SEARCH, Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.FROM_DATE, Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.TO_DATE | /api/v1/pld/disp_text | When a message needs to be shown to the user, then displays an alert dialog with the supplied text and title |
| PLD-003 | RAISE_ERROR | Validation | Trigger: ON-ERROR in Form | /api/v1/pld/raise_error | When an error code is received in the error handler, then displays the corresponding error message and stops execution for error-type messages |


---

### D2kwutil.pld (`Win_API`)

*No routines from ``D2kwutil.pld`` are referenced in ``pr_mass_order_fmb.xml``.*

---

---

## 19. PCK-Backed Logic

*NO PCK files found - no ``*.pck`` source files were discovered in ``/app/workspace/pr_mass_order-5a30b9d164fd/in``. PCK-backed logic cannot be generated without uploaded PCK sources.*

---

## 20. System Interfaces

### 20.1 Database Integrations

| Interface Name | Type | Purpose | Data Flow | Error Handling |
| -------------- | ---- | ------- | --------- | -------------- |
| Mass Order Header (PH_PO_MASS) | Oracle Database Table | Source of mass purchase order header records - provides order number, date, type, status, and dealer/location identities used as the root of all search results | Read-only SELECT from POPULATE_DETAILS program unit and WHEN-BUTTON-PRESSED export trigger | WHEN OTHERS in POPULATE_DETAILS: error displayed with database error text via GENERAL.DISP_TEXT; WHEN OTHERS in export trigger: silently suppressed |
| Mass Order Detail (PD_PO_MASS) | Oracle Database Table | Source of mass purchase order detail lines - provides part number, quantity ordered, quantity billed, purchase price, and linked CO number for each order line | Read-only SELECT from POPULATE_DETAILS program unit and WHEN-BUTTON-PRESSED export trigger | Same as PH_PO_MASS (both queried in same cursor/query block) |
| Dealer Location master (AM_DEALER_LOC) | Oracle Database Table | Reference table for resolving the destination distributor's name and location description for each order line | Read-only SELECT within POPULATE_DETAILS (per-row lookup) and WHEN-BUTTON-PRESSED export trigger (inline subquery) | WHEN OTHERS -> NULL in POPULATE_DETAILS (silent; distributor name/location left blank if not found) |
| Dealer Location Company Master (AM_DEALER_LOC_COMPANY_MASTER) | Oracle Database Table | Reference table for resolving the distributor's parent group and company code, required to locate the correct CO date in the sales order header | Read-only SELECT within POPULATE_DETAILS (per-row lookup) and WHEN-BUTTON-PRESSED export trigger | WHEN OTHERS -> NULL in POPULATE_DETAILS (silent; CO date lookup skipped if company details not found) |
| Sales Order Header (PH_SO) | Oracle Database Table | Reference table for resolving the date of the customer order (CO) linked to each mass order detail line | Read-only SELECT within POPULATE_DETAILS (per-row lookup) and WHEN-BUTTON-PRESSED export trigger (inline subquery) | WHEN OTHERS -> NULL in POPULATE_DETAILS (silent; CO date left blank if not found) |
| Order Type List (AM_LIST - list name PO_MASS_TYPE) | Oracle Database Table | Reference table for resolving the human-readable order type description for each order line, filtered to the current principal | Read-only SELECT within POPULATE_DETAILS (per-row lookup) and WHEN-BUTTON-PRESSED export trigger (inline subquery) | WHEN OTHERS -> NULL in POPULATE_DETAILS (silent; order type description left blank if not found) |
| Parts master (PM_PART) | Oracle Database Table | Reference table for resolving the part description for each part number on a detail line, filtered to the current principal | Read-only SELECT within POPULATE_DETAILS (per-row lookup) and WHEN-BUTTON-PRESSED export trigger (inline subquery) | WHEN OTHERS -> NULL in POPULATE_DETAILS (silent; part description left blank if not found) |
| Oracle Application Info (DBMS_APPLICATION_INFO) | Oracle Built-In Package | Session registration and deregistration - writes the module name and client identifier at form open and clears them at form exit | Write (SET_CLIENT_INFO, SET_MODULE) at PRE-FORM; clear at KEY-EXIT | No explicit error handling in the form; Oracle built-in (errors would propagate to ON-ERROR) |

### 20.2 External System Integrations

| System Name | Integration Type | Purpose | Protocol | Endpoint | Data Exchange | Success / Error Codes |
| ----------- | ---------------- | ------- | -------- | -------- | ------------- | --------------------- |
| DMS Excel Report Service (VIEW_EXCEL_REPORT_NEW via DMS_EXCEL_REPORT library) | Attached Library Procedure Call (`EXTERNAL / NOT IN BUNDLE`) | Accepts a dynamic query string, generates a comma-separated file on the server, and delivers the file to the user's browser for download | In-process Forms library call (internal to Forms runtime) | N/A - called as an in-process library routine | Outbound: principal identifier, unique filename, SQL query string, column name, application ID; Inbound: CSV file stream delivered to browser | WHEN OTHERS in calling trigger is suppressed silently; no return code surfaced to the form |
| Oracle Reports Server (rep_server) | Oracle Reports Integration (`EXTERNAL / NOT IN BUNDLE - no active call-site found`) | Report object REPORT_CALL (filename: `rep.rdf`) is declared in the form but is not invoked by any active trigger in the current form implementation | Oracle Reports server protocol (declared) | rep_server (declared) | INFERRED: would execute `rep.rdf` if called | Not applicable - no active invocation |

> **Note:** The external file path `/reports/DMS/excelpath.txt` appears in the source code of the `VIEW_EXCEL_REP` form program unit, which is never called by any active trigger (the call site is commented out in favour of VIEW_EXCEL_REPORT_NEW). This file path reference is therefore inactive and does not represent an active system interface.

### 20.3 Report Integrations

| Report Name | Report Server | Parameters | Output Format | Trigger |
| ----------- | ------------- | ---------- | ------------- | ------- |
| rep.rdf | rep_server | None evidenced (no active call-site; INFERRED from report object declaration) | Cache (declared ExecuteMode=Runtime, ReportDestinationType=Cache - INFERRED) | No active trigger invocation found in the form; report object REPORT_CALL is declared but not executed by any trigger or program unit in the current form |

---

### 20.3.1 Parameters Passed to the Report

This form does not pass parameters to an Oracle Report. No report parameters were identified in the form sources.

## 21. Procedure and Function Business Rule Catalogue

End-to-end business requirement specification for every stored procedure and function referenced by the PR_MASS_ORDER form.

### 21.1 Catalogue Index

82 procedures/functions - each SP ID links to its detailed specification in Section 21.2.

| SP Index | Routine Name |
| :--- | :--- |
| [SP-001](#SP-001--POPULATE_DETAILS) | POPULATE_DETAILS |
| [SP-002](#SP-002--D2KWUTIL.ATTEMPT_DLL_LOAD) | D2KWUTIL.ATTEMPT_DLL_LOAD |
| [SP-003](#SP-003--D2KWUTIL.CHOOSEFILE) | D2KWUTIL.CHOOSEFILE |
| [SP-004](#SP-004--D2KWUTIL.D2KWUTIL_ACTIVEWIN) | D2KWUTIL.D2KWUTIL_ACTIVEWIN |
| [SP-005](#SP-005--D2KWUTIL.D2KWUTIL_CHOOSEFILE) | D2KWUTIL.D2KWUTIL_CHOOSEFILE |
| [SP-006](#SP-006--D2KWUTIL.D2KWUTIL_DEBUGSTRING) | D2KWUTIL.D2KWUTIL_DEBUGSTRING |
| [SP-007](#SP-007--D2KWUTIL.D2KWUTIL_GETDOSENV) | D2KWUTIL.D2KWUTIL_GETDOSENV |
| [SP-008](#SP-008--D2KWUTIL.D2KWUTIL_GETREGKEY) | D2KWUTIL.D2KWUTIL_GETREGKEY |
| [SP-009](#SP-009--D2KWUTIL.D2KWUTIL_WINDIR) | D2KWUTIL.D2KWUTIL_WINDIR |
| [SP-010](#SP-010--D2KWUTIL.GET_ACTIVE_WINDOW) | D2KWUTIL.GET_ACTIVE_WINDOW |
| [SP-011](#SP-011--D2KWUTIL.SAVE_FILE) | D2KWUTIL.SAVE_FILE |
| [SP-012](#SP-012--D2KWUTIL.TRANSLATETYPE) | D2KWUTIL.TRANSLATETYPE |
| [SP-013](#SP-013--GENERAL.ASK_CONFIRM) | GENERAL.ASK_CONFIRM |
| [SP-014](#SP-014--GENERAL.DISP_TEXT) | GENERAL.DISP_TEXT |
| [SP-015](#SP-015--GENERAL.RAISE_ERROR) | GENERAL.RAISE_ERROR |
| [SP-016](#SP-016--WEBUTIL.BLOCKING) | WEBUTIL.BLOCKING |
| [SP-017](#SP-017--WEBUTIL.CHECKLIBS) | WEBUTIL.CHECKLIBS |
| [SP-018](#SP-018--WEBUTIL.CLEARCALLBACKTRIGGER) | WEBUTIL.CLEARCALLBACKTRIGGER |
| [SP-019](#SP-019--WEBUTIL.CLOSEBLOB) | WEBUTIL.CLOSEBLOB |
| [SP-020](#SP-020--WEBUTIL.CLOSEFILE) | WEBUTIL.CLOSEFILE |
| [SP-021](#SP-021--WEBUTIL.DOWNLOADFROMURL) | WEBUTIL.DOWNLOADFROMURL |
| [SP-022](#SP-022--WEBUTIL.DOWNLOADFROMURLINT) | WEBUTIL.DOWNLOADFROMURLINT |
| [SP-023](#SP-023--WEBUTIL.ERROR) | WEBUTIL.ERROR |
| [SP-024](#SP-024--WEBUTIL.ERRORALERT) | WEBUTIL.ERRORALERT |
| [SP-025](#SP-025--WEBUTIL.EXECUTE) | WEBUTIL.EXECUTE |
| [SP-026](#SP-026--WEBUTIL.FCLOSE) | WEBUTIL.FCLOSE |
| [SP-027](#SP-027--WEBUTIL.FILE_SAVE_DIALOG) | WEBUTIL.FILE_SAVE_DIALOG |
| [SP-028](#SP-028--WEBUTIL.FILE_SELECTION_DIALOG_INT) | WEBUTIL.FILE_SELECTION_DIALOG_INT |
| [SP-029](#SP-029--WEBUTIL.FOPEN) | WEBUTIL.FOPEN |
| [SP-030](#SP-030--WEBUTIL.GETCALLBACKTRIGGER) | WEBUTIL.GETCALLBACKTRIGGER |
| [SP-031](#SP-031--WEBUTIL.GETCLIENTOSFAMILY) | WEBUTIL.GETCLIENTOSFAMILY |
| [SP-032](#SP-032--WEBUTIL.GETCLIENTSETTING) | WEBUTIL.GETCLIENTSETTING |
| [SP-033](#SP-033--WEBUTIL.GETIMPLCLASS) | WEBUTIL.GETIMPLCLASS |
| [SP-034](#SP-034--WEBUTIL.GETLASTERROR) | WEBUTIL.GETLASTERROR |
| [SP-035](#SP-035--WEBUTIL.GETLASTERRORARGS) | WEBUTIL.GETLASTERRORARGS |
| [SP-036](#SP-036--WEBUTIL.GETNUMBER) | WEBUTIL.GETNUMBER |
| [SP-037](#SP-037--WEBUTIL.GETOSFAMILY) | WEBUTIL.GETOSFAMILY |
| [SP-038](#SP-038--WEBUTIL.GETOUTPUT) | WEBUTIL.GETOUTPUT |
| [SP-039](#SP-039--WEBUTIL.GETPROPERTY) | WEBUTIL.GETPROPERTY |
| [SP-040](#SP-040--WEBUTIL.GETSTRING) | WEBUTIL.GETSTRING |
| [SP-041](#SP-041--WEBUTIL.GETVAR) | WEBUTIL.GETVAR |
| [SP-042](#SP-042--WEBUTIL.GET_LINE) | WEBUTIL.GET_LINE |
| [SP-043](#SP-043--WEBUTIL.GET_RETURN_CODE) | WEBUTIL.GET_RETURN_CODE |
| [SP-044](#SP-044--WEBUTIL.GET_STANDARD_OUTPUT) | WEBUTIL.GET_STANDARD_OUTPUT |
| [SP-045](#SP-045--WEBUTIL.HOST) | WEBUTIL.HOST |
| [SP-046](#SP-046--WEBUTIL.ID_NULL) | WEBUTIL.ID_NULL |
| [SP-047](#SP-047--WEBUTIL.INIT) | WEBUTIL.INIT |
| [SP-048](#SP-048--WEBUTIL.INITWEBUTIL) | WEBUTIL.INITWEBUTIL |
| [SP-049](#SP-049--WEBUTIL.ISERROR) | WEBUTIL.ISERROR |
| [SP-050](#SP-050--WEBUTIL.IS_OPEN) | WEBUTIL.IS_OPEN |
| [SP-051](#SP-051--WEBUTIL.LENGTH) | WEBUTIL.LENGTH |
| [SP-052](#SP-052--WEBUTIL.LOG) | WEBUTIL.LOG |
| [SP-053](#SP-053--WEBUTIL.POPULATEPROPERTYBUNDLE) | WEBUTIL.POPULATEPROPERTYBUNDLE |
| [SP-054](#SP-054--WEBUTIL.PUTF) | WEBUTIL.PUTF |
| [SP-055](#SP-055--WEBUTIL.PUT_LINE) | WEBUTIL.PUT_LINE |
| [SP-056](#SP-056--WEBUTIL.READFROMPROPERTYBUNDLE) | WEBUTIL.READFROMPROPERTYBUNDLE |
| [SP-057](#SP-057--WEBUTIL.READTRANSFROMMSGBUNDLE) | WEBUTIL.READTRANSFROMMSGBUNDLE |
| [SP-058](#SP-058--WEBUTIL.REGISTERBEAN) | WEBUTIL.REGISTERBEAN |
| [SP-059](#SP-059--WEBUTIL.REGISTER_FUNCTION) | WEBUTIL.REGISTER_FUNCTION |
| [SP-060](#SP-060--WEBUTIL.RELEASE_PROCESS) | WEBUTIL.RELEASE_PROCESS |
| [SP-061](#SP-061--WEBUTIL.SETCLIENTSETTING) | WEBUTIL.SETCLIENTSETTING |
| [SP-062](#SP-062--WEBUTIL.SETDATA) | WEBUTIL.SETDATA |
| [SP-063](#SP-063--WEBUTIL.SETPROPERTY) | WEBUTIL.SETPROPERTY |
| [SP-064](#SP-064--WEBUTIL.SHOWBEANS) | WEBUTIL.SHOWBEANS |
| [SP-065](#SP-065--WEBUTIL.URL_TO_CLIENT) | WEBUTIL.URL_TO_CLIENT |
| [SP-066](#SP-066--WEBUTIL.WRITEDATA) | WEBUTIL.WRITEDATA |
| [SP-067](#SP-067--WEBUTIL_CORE.CUSTOMEVENTHANDLER) | WEBUTIL_CORE.CUSTOMEVENTHANDLER |
| [SP-068](#SP-068--ADD_ERROR) | ADD_ERROR |
| [SP-069](#SP-069--ADD_EXTERNAL_ERRORS) | ADD_EXTERNAL_ERRORS |
| [SP-070](#SP-070--BOOLTOCHAR) | BOOLTOCHAR |
| [SP-071](#SP-071--CLEAN_ERROR_STACK) | CLEAN_ERROR_STACK |
| [SP-072](#SP-072--DEBUGLOG) | DEBUGLOG |
| [SP-073](#SP-073--GET_ENVIRONMENT_STRING) | GET_ENVIRONMENT_STRING |
| [SP-074](#SP-074--GET_TEMP_DIRECTORY) | GET_TEMP_DIRECTORY |
| [SP-075](#SP-075--GET_WINDOWS_DIRECTORY) | GET_WINDOWS_DIRECTORY |
| [SP-076](#SP-076--READ_REGISTRY) | READ_REGISTRY |
| [SP-077](#SP-077--REGISTER_FUNCTION_CALL) | REGISTER_FUNCTION_CALL |
| [SP-078](#SP-078--SETDEBUG) | SETDEBUG |
| [SP-079](#SP-079--SF_COPYRIGHT_DECLARATION) | SF_COPYRIGHT_DECLARATION |
| [SP-080](#SP-080--STRIPDIRSEP) | STRIPDIRSEP |
| [SP-081](#SP-081--VIEW_EXCEL_REPORT_NEW) | VIEW_EXCEL_REPORT_NEW |
| [SP-082](#SP-082--WINDEBUG) | WINDEBUG |

---

### 21.2 Detailed Specifications

#### SP-001 - POPULATE_DETAILS

**Invoked From:**

- pr_mass_order_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

Search Criteria (N/A / CN_MAIN)

---

**Purpose**

Populates the B_DTL detail block on the Mass Order screen with purchase order line data retrieved from PH_PO_MASS and PD_PO_MASS. The procedure supports three search modes - Date Range ('D'), specific Order Number ('O'), and SO-generated lines ('C') - and enriches each line with distributor name and location, SO date, PO type description, and part description sourced from supporting master and transactional tables.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-014](#SP-014--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Display a diagnostic message showing the FROM_DATE and TO_DATE range currently held in the CB_DUMMY block.
- Step 2 - Navigate to the B_DTL block, clear all existing records, and position the cursor at the first record slot.
- Step 3 - Execute cursor CUR_DTL, which retrieves PO header and line data from PH_PO_MASS / PD_PO_MASS using one of three UNION ALL branches selected by the RB_TYPE global flag: (a) RB_TYPE = 'D' - fetches all PO lines for the current dealer and location whose PO date falls within the FROM_DATE / TO_DATE range; (b) RB_TYPE = 'O' - fetches lines for a specific PO number (CB_ORDER_NO) matching the current dealer, location, parent group, company, and order type; (c) RB_TYPE = 'C' - same as 'O' but targets CB_ORDER_NO1 and additionally restricts lines to those where SO_GENERATED_YN = 'Y'. All branches exclude serial-zero lines (PO_SRL > 0) and order results by PO type then PO number.
- Step 4 - For each row returned by CUR_DTL, populate B_DTL block fields: PO number, PO date, SO number (CO_NO), part number, PO quantity, issued quantity (CO_QTY), outstanding balance quantity (CBO_QTY = PO_QTY - ISSUED_QTY), and outstanding value (CBO_QTY × PURCHASE_PRICE).
- Step 5 - Look up AM_DEALER_LOC_COMPANY_MASTER using the destination dealer map code and location code from the PO line to resolve the distributor's parent group and company code; silently suppress any lookup failure.
- Step 6 - Using the resolved distributor identifiers, query PH_SO to retrieve the SO date for the SO number on the line and populate B_DTL.CO_DATE; silently suppress any lookup failure.
- Step 7 - Query AM_DEALER_LOC for the destination dealer map code and location code to populate B_DTL.DIST_NAME and B_DTL.DIST_LOC; silently suppress any lookup failure.
- Step 8 - Query AM_LIST for list name 'PO_MASS_TYPE' filtered by the current principal to resolve the PO type code to its description and populate B_DTL.PO_TYPE; silently suppress any lookup failure.
- Step 9 - Query PM_PART for the part number, filtered by the current principal (DEALER_MAP_CD and PRINCIPAL_MAP_CD = :global.principal), to populate B_DTL.PART_DESC; silently suppress any lookup failure.
- Step 10 - Advance to the next B_DTL record and repeat Steps 4-9 until the cursor is exhausted.
- Step 11 - After the loop, reposition the cursor to the first record in B_DTL.
- Step 12 - If a NO_DATA_FOUND exception propagates to the outer handler, invoke GENERAL.DISP_TEXT to display 'Data not available' as a Note. For any other unhandled exception, invoke GENERAL.DISP_TEXT to display 'Unable to populate' concatenated with the SQLERRM error message as an Error.

---
**Decision Points**

DP-001

Condition:
CB_DUMMY.RB_TYPE = 'D'

TRUE:
CUR_DTL fetches PO header and line rows from PH_PO_MASS / PD_PO_MASS where the PO date falls within the FROM_DATE to TO_DATE range for the current dealer and location, regardless of a specific PO number.

FALSE:
The 'D' branch contributes no rows; evaluation continues to the 'O' and 'C' branches via UNION ALL.

---

DP-002

Condition:
CB_DUMMY.RB_TYPE = 'O'

TRUE:
CUR_DTL fetches PO lines matching the specific order number in CB_ORDER_NO for the current dealer, location, parent group, company, and order type, with no SO-generation filter.

FALSE:
The 'O' branch contributes no rows; evaluation continues to the 'C' branch via UNION ALL.

---

DP-003

Condition:
CB_DUMMY.RB_TYPE = 'C'

TRUE:
CUR_DTL fetches PO lines matching the specific order number in CB_ORDER_NO1 for the current dealer, location, parent group, company, and order type, restricted to lines where SO_GENERATED_YN = 'Y'.

FALSE:
The 'C' branch contributes no rows; the cursor returns only rows matched by the 'D' or 'O' branches.

---

DP-004

Condition:
A matching row is found in AM_DEALER_LOC_COMPANY_MASTER for the destination dealer map code and location code.

TRUE:
LV_DIST_PARENT and LV_DIST_COMP are populated and used in the subsequent PH_SO lookup (Step 6).

FALSE:
The WHEN OTHERS exception handler suppresses the error; LV_DIST_PARENT and LV_DIST_COMP retain their previous values (or NULL), and the PH_SO lookup may return no data.

---

DP-005

Condition:
A matching SO header row is found in PH_SO using the resolved distributor identifiers and the SO number from the PO line.

TRUE:
B_DTL.CO_DATE is populated with the formatted SO date.

FALSE:
The WHEN OTHERS exception handler suppresses the error; B_DTL.CO_DATE remains unpopulated for that line.

---

DP-006

Condition:
A matching row is found in AM_DEALER_LOC for the destination dealer map code and location code.

TRUE:
B_DTL.DIST_NAME and B_DTL.DIST_LOC are populated with the dealer name and location description.

FALSE:
The WHEN OTHERS exception handler suppresses the error; both fields remain unpopulated for that line.

---

DP-007

Condition:
A matching row is found in AM_LIST for list name 'PO_MASS_TYPE', the current principal, and the PO type code.

TRUE:
B_DTL.PO_TYPE is populated with the human-readable list description.

FALSE:
The WHEN OTHERS exception handler suppresses the error; B_DTL.PO_TYPE remains unpopulated for that line.

---

DP-008

Condition:
A matching row is found in PM_PART for the part number and current principal.

TRUE:
B_DTL.PART_DESC is populated with the part description.

FALSE:
The WHEN OTHERS exception handler suppresses the error; B_DTL.PART_DESC remains unpopulated for that line.

---

DP-009

Condition:
The outer exception block catches NO_DATA_FOUND.

TRUE:
GENERAL.DISP_TEXT is called with the message 'Data not available' and severity 'Note'.

FALSE:
If a different exception is raised, the WHEN OTHERS branch calls GENERAL.DISP_TEXT with 'Unable to populate' concatenated with SQLERRM and severity 'Error'.

---
**Database Interactions**

- DB-001 - Read PH_PO_MASS - Reads data from PH_PO_MASS for lookup or validation.
- DB-002 - Read AM_DEALER_LOC_COMPANY_MASTER - Reads data from AM_DEALER_LOC_COMPANY_MASTER for lookup or validation.
- DB-003 - Read PH_SO - Reads data from PH_SO for lookup or validation.
- DB-004 - Read AM_DEALER_LOC - Reads data from AM_DEALER_LOC for lookup or validation.
- DB-005 - Read AM_LIST - Reads data from AM_LIST for lookup or validation.
- DB-006 - Read PM_PART - Reads data from PM_PART for lookup or validation.
**Business Rules**

- BR-001 - Only PO detail lines with a serial number greater than zero (PO_SRL > 0) are eligible for display; zero-serial placeholder lines are excluded from all three search branches.
- BR-002 - When search mode is 'D' (Date Range), the PO date must be greater than or equal to the truncated FROM_DATE and strictly less than the truncated TO_DATE plus one day, ensuring an inclusive date-range filter on whole calendar days.
- BR-003 - When search mode is 'C' (SO-generated), only PO lines where SO_GENERATED_YN = 'Y' are retrieved, ensuring that only lines already linked to a sales order are displayed.
- BR-004 - All three search branches are always scoped to the current dealer (DEALER_MAP_CD = :global.dealer) and the current location (LOC_CD = :global.loc_cd), preventing cross-dealer or cross-location data exposure.
- BR-005 - PO status codes are decoded at query time: 'R' displays as 'Release', 'H' as 'Hold', and 'C' as 'Cancel'; no other status values are mapped.
- BR-006 - The outstanding balance quantity (CBO_QTY) is calculated as PO_QTY minus ISSUED_QTY, treating NULL values as zero via NVL, ensuring no arithmetic errors on incomplete records.
- BR-007 - The outstanding value displayed in B_DTL.PO_VALUE is derived as CBO_QTY multiplied by PURCHASE_PRICE, with all three operands NULL-protected via NVL, ensuring a zero result rather than NULL when any component is missing.
- BR-008 - PO type descriptions are resolved from AM_LIST using list name 'PO_MASS_TYPE' filtered by the current principal (:global.principal), enforcing multi-organisation isolation for list-of-values data.
- BR-009 - Part descriptions are resolved from PM_PART filtered by both DEALER_MAP_CD and PRINCIPAL_MAP_CD equal to :global.principal, enforcing multi-organisation isolation for part master data.
- BR-010 - All five subordinate lookups (AM_DEALER_LOC_COMPANY_MASTER, PH_SO, AM_DEALER_LOC, AM_LIST, PM_PART) are individually wrapped in BEGIN...EXCEPTION WHEN OTHERS THEN NULL blocks; a failure in any single lookup does not abort processing of the remaining lookups or subsequent cursor rows.
- BR-011 - Error notification is delegated exclusively to GENERAL.DISP_TEXT; NO_DATA_FOUND at the procedure level is reported as a 'Note', while all other unhandled exceptions are reported as an 'Error' with the Oracle error message appended.

---
**Implementation Logic**

```plsql
PROCEDURE populate_details 
IS
	CURSOR CUR_DTL IS
		SELECT h.po_num, to_char(h.po_date,'dd/mm/yyyy') po_date,
       		 h.po_type, decode(h.po_status,'R','Release','H','Hold','C','Cancel') po_status, 
       		 h.to_dealer_map_cd, h.to_loc_cd, 
       		 d.part_num, d.po_qty, d.purchase_price, d.basic_value, 
       		 d.so_num, d.issued_qty       		       		  
  	  FROM ph_po_mass h, pd_po_mass d
 		 WHERE h.po_date >= trunc(:CB_DUMMY.FROM_DATE) 
 		   AND h.po_date <  trunc(:CB_DUMMY.TO_DATE) + 1
 		   AND h.dealer_map_cd = :global.dealer
 		   AND h.loc_cd = :global.loc_cd
 		   AND :CB_DUMMY.RB_TYPE = 'D'
   		 AND d.parent_group = h.parent_group
		   AND d.dealer_map_cd = h.dealer_map_cd
		   AND d.loc_cd = h.loc_cd
		   AND d.comp_fa = h.comp_fa
		   AND d.po_type = h.po_type
		   AND d.po_num = h.po_num
		   AND d.po_srl > 0
		 UNION ALL
		   		SELECT h.po_num, to_char(h.po_date,'dd/mm/yyyy') po_date,
       		 h.po_type, decode(h.po_status,'R','Release','H','Hold','C','Cancel') po_status, 
       		 h.to_dealer_map_cd, h.to_loc_cd, 
       		 d.part_num, d.po_qty, d.purchase_price, d.basic_value, 
       		 d.so_num, d.issued_qty      		  
  	  FROM ph_po_mass h, pd_po_mass d
 		 WHERE h.parent_group = :global.parent_group
 		   AND h.dealer_map_cd = :global.dealer
 		   AND h.loc_cd = :global.loc_cd
 		   AND h.comp_fa = :global.comp_fa
 		   AND h.po_type = :CB_DUMMY.CB_ORDER_TYPE
 		   AND h.po_num = :CB_DUMMY.CB_ORDER_NO
 		   AND :CB_DUMMY.RB_TYPE = 'O'
   		 AND d.parent_group = h.parent_group
		   AND d.dealer_map_cd = h.dealer_map_cd
		   AND d.loc_cd = h.loc_cd
		   AND d.comp_fa = h.comp_fa
		   AND d.po_type = h.po_type
		   AND d.po_num = h.po_num
		   AND d.po_srl > 0
		 UNION ALL
		   		SELECT h.po_num, to_char(h.po_date,'dd/mm/yyyy') po_date,
       		 h.po_type, decode(h.po_status,'R','Release','H','Hold','C','Cancel') po_status, 
       		 h.to_dealer_map_cd, h.to_loc_cd, 
       		 d.part_num, d.po_qty, d.purchase_price, d.basic_value, 
       		 d.so_num, d.issued_qty      		  
  	  FROM ph_po_mass h, pd_po_mass d
 		 WHERE h.parent_group = :global.parent_group
 		   AND h.dealer_map_cd = :global.dealer
 		   AND h.loc_cd = :global.loc_cd
 		   AND h.comp_fa = :global.comp_fa
 		   AND h.po_type = :CB_DUMMY.CB_ORDER_TYPE
 		   AND h.po_num = :CB_DUMMY.CB_ORDER_NO1
 		   AND :CB_DUMMY.RB_TYPE = 'C'
   		 AND d.parent_group = h.parent_group
		   AND d.dealer_map_cd = h.dealer_map_cd
		   AND d.loc_cd = h.loc_cd
		   AND d.comp_fa = h.comp_fa
		   AND d.po_type = h.po_type
		   AND d.po_num = h.po_num
		   AND d.po_srl > 0
		   AND d.so_generated_yn = 'Y'
	 	 ORDER BY 3, 1;
	 	 
	 	 lv_dist_parent am_dealer_loc_company_master.parent_group%type;
	 	 lv_dist_comp   am_dealer_loc_company_master.comp_code%type;  
BEGIN
	message(trunc(:CB_DUMMY.FROM_DATE)||' - '||trunc(:CB_DUMMY.TO_DATE));
    go_block('B_DTL');
    clear_block;
    first_record;

		FOR i in CUR_DTL LOOP
			:b_dtl.po_no	      := i.po_num;
			:b_dtl.po_date      := i.po_date;
			:b_dtl.co_no	      := i.so_num;
			:b_dtl.part_num			:= i.part_num;
			:b_dtl.po_qty				:= i.po_qty;
			:b_dtl.co_qty				:= i.issued_qty;
			:b_dtl.po_value			:= (nvl(i.po_qty,0) - nvl(i.issued_qty,0)) * nvl(i.purchase_price,0);
			:b_dtl.cbo_qty      := nvl(i.po_qty,0) - nvl(i.issued_qty,0);
			
			BEGIN
				SELECT parent_group, comp_code
				  INTO lv_dist_parent, lv_dist_comp
				  FROM am_dealer_loc_company_master
				 WHERE dealer_map_cd = i.to_dealer_map_cd
				   AND loc_cd = i.to_loc_cd;
			EXCEPTION WHEN OTHERS THEN
				NULL;
			END;
			
			BEGIN
				SELECT to_char(h.so_date,'dd/mm/yyyy')
				  INTO :b_dtl.co_date
				  FROM ph_so h
				 WHERE h.parent_group = lv_dist_parent
				   AND h.dealer_map_Cd = i.to_dealer_map_cd
				   AND h.loc_cd = i.to_loc_cd
				   AND h.comp_fa = lv_dist_comp
				   AND h.so_num = i.so_num;
			EXCEPTION WHEN OTHERS THEN
				NULL;
			END;

			BEGIN
				SELECT dealer_name, loc_desc
				  INTO :b_dtl.dist_name, :b_dtl.dist_loc
				  FROM am_dealer_loc 
				 WHERE dealer_map_cd = i.to_dealer_map_cd
				   AND loc_cd = i.to_loc_cd;
			EXCEPTION WHEN OTHERS THEN
				NULL;
			END;
		
			BEGIN
				SELECT a.list_desc into :b_dtl.po_type
				  FROM am_list a
	     	 WHERE a.list_name = 'PO_MASS_TYPE'  
	     	   AND a.principal_map_cd = 1 
		   		 AND a.list_code = i.po_type
		   		 AND	principal_map_cd = :global.principal --Added by prerna for multi-org
		   		 ;	
			EXCEPTION WHEN OTHERS THEN
				NULL;
			END;  
			
			BEGIN
				SELECT part_desc 
				  INTO :b_dtl.part_desc
				  FROM pm_part
				 WHERE part_num = i.part_num
				   AND dealer_map_cd = :global.principal --1 replaced by prerna for multi-org
				   AND principal_map_cd = :global.principal --Added by prerna for multi-org				   
				   ;
			EXCEPTION WHEN OTHERS THEN
				NULL;
			END;  
										
		  exit when CUR_DTL%NOTFOUND;
		  next_record;
		END LOOP;  			

		first_record;
EXCEPTION
	WHEN no_data_found THEN 
 		general.disp_text('Data not available ' ,'Note');
  WHEN OTHERS THEN
    general.disp_text('Unable to populate' || SQLERRM, 'Error');
END;
```

#### SP-002 - D2KWUTIL.ATTEMPT_DLL_LOAD

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Attempts to load a specified DLL into memory using ORA_FFI, optionally verifying that the file exists at the supplied path before loading. The procedure normalises the target path via STRIPDIRSEP, confirms file accessibility with TEXT_IO, invokes ORA_FFI.LOAD_LIBRARY, and maintains a package-level load counter and availability flag. It returns the resulting library handle to the caller (REGISTER_FUNCTION_CALL).

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |
| TargetDLL | VARCHAR2 | IN |
| LoadCount | BOOLEAN | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |

---

**Dependencies**

- DEBUGLOG ([SP-072](#SP-072--DEBUGLOG)) - matched by member name
- STRIPDIRSEP ([SP-080](#SP-080--STRIPDIRSEP)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate whether TargetPath is non-null; if so, proceed with path normalisation and file existence checks before attempting the load.
- Step 2 - Normalise TargetPath by calling STRIPDIRSEP to remove any extraneous directory separators, then append a single trailing backslash ('\') to produce a well-formed directory path. This discards any secondary paths that may have been concatenated into the value.
- Step 3 - Attempt to open the file identified by the concatenation of TargetPath and TargetDLL using TEXT_IO.FOPEN in read mode ('R'), then immediately close it. A successful open/close confirms the file is physically present at the specified location.
- Step 4 - If the file cannot be opened, call DEBUGLOG (Win_API_Debug.DebugLog at severity 99) to record that the DLL was not found at the specified location, then raise the BadLocation exception to abort the load attempt.
- Step 5 - If TargetPath is null, skip steps 2-4 and proceed directly to the library load (ORA_FFI resolves the DLL from the system path).
- Step 6 - Call ORA_FFI.LOAD_LIBRARY with TargetPath and TargetDLL to load the library and obtain a handle (hDLL).
- Step 7 - If the LoadCount flag is TRUE, increment the package-level DLL_LOAD_COUNT counter by 1 and set the package-level API_ENABLED flag to TRUE.
- Step 8 - Return hDLL to the caller.
- Step 9 - If any unhandled exception occurs during the load phase, set API_ENABLED to FALSE and return a null hDLL to the caller, allowing the caller to handle the failure gracefully.

---
**Decision Points**

DP-001

Condition:
TargetPath IS NOT NULL

TRUE:
Normalise TargetPath using STRIPDIRSEP and append a trailing backslash, then perform the file existence check (Steps 2-4) before proceeding to the library load.

FALSE:
Skip path normalisation and file existence check; proceed directly to ORA_FFI.LOAD_LIBRARY using a null path, relying on the operating system to resolve the DLL location.

---

DP-002

Condition:
TEXT_IO.FOPEN succeeds for the concatenated file path (TargetPath || TargetDLL)

TRUE:
Close the file handle and continue to the ORA_FFI.LOAD_LIBRARY call.

FALSE:
Call DEBUGLOG to record the missing DLL and location, then raise BadLocation to abort processing.

---

DP-003

Condition:
LoadCount parameter is TRUE

TRUE:
Increment DLL_LOAD_COUNT by 1 and set API_ENABLED to TRUE.

FALSE:
Leave DLL_LOAD_COUNT and API_ENABLED unchanged.

---

DP-004

Condition:
An unhandled exception occurs during or after the ORA_FFI.LOAD_LIBRARY call

TRUE:
Set API_ENABLED to FALSE and return a null hDLL to the caller.

FALSE:
Return the valid hDLL handle to the caller normally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only the first path value in TargetPath is used; any additional concatenated paths are discarded by STRIPDIRSEP followed by re-appending a single trailing backslash.
- BR-002 - TargetPath must be normalised to include exactly one trailing backslash ('\') before it is used for file existence checking or passed to ORA_FFI.LOAD_LIBRARY.
- BR-003 - A physical file existence check (TEXT_IO open/close) must be performed before loading the DLL whenever TargetPath is supplied; the load must not proceed if the file cannot be opened.
- BR-004 - Failure to locate the DLL at the specified path must be logged via DEBUGLOG at severity level 99, identifying the routine name ('Attempt_DLL_LOAD'), the DLL name, and the path that was checked.
- BR-005 - The package-level load counter (DLL_LOAD_COUNT) must be incremented and API_ENABLED set to TRUE only when the LoadCount parameter is explicitly TRUE, allowing callers to suppress counter updates when required.
- BR-006 - If the library load fails for any reason, API_ENABLED must be set to FALSE and a null handle returned; the procedure must not propagate the exception to the caller.

---
**Implementation Logic**

```plsql

FUNCTION  Attempt_DLL_Load  (TargetPath in out VARCHAR2, TargetDLL in VARCHAR2, LoadCount in BOOLEAN DEFAULT TRUE) return ORA_FFI.LibHandleType is
  hDLL  ORA_FFI.LibHandleType;
  hFile TEXT_IO.FILE_TYPE;
begin 
    	
  if TargetPath is not null then 
    -- Watch out for folks who put multiple Paths in here 
    -- Oh yes it's happened! Just use the first & throw the rest away
    -- Add trailing Directory Sep if required
    TargetPath := StripDirSep(TargetPath)||'\';
    
    -- Check that there is actually a file there.
    begin 
  	  hFile := TEXT_IO.FOPEN(TargetPath||TargetDLL,'R');
  	  TEXT_IO.FCLOSE(hFile);
    exception
  	  when others then
  	    Win_API_Debug.DebugLog(99,'Attempt_DLL_LOAD',TargetDLL||' not found in the specified location of "'||TargetPath||'"'); 
  		  raise BadLocation;
    end;
  end if;
  
  hDLL := ORA_FFI.LOAD_LIBRARY(TargetPath, TargetDLL);
  if LoadCount then 
    DLL_LOAD_COUNT  := DLL_LOAD_COUNT + 1;
    API_ENABLED  := TRUE;
  end if;
  return hDLL;
exception
  when others then 
    API_ENABLED := FALSE;
    return hDLL; /* Will be null */
end Attempt_DLL_Load;
```

#### SP-003 - D2KWUTIL.CHOOSEFILE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.SAVE_FILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Presents a native Windows file-chooser dialog (Open or Save) to the end user and returns the selected file path(s) in the IN OUT buffer. The procedure resolves special directory tokens, registers the underlying Win32 API call, enforces modal or modeless window ownership, and propagates any API or unexpected errors to the caller via the standard error stack.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| CalledBy | VARCHAR2 | IN |
| Modal | BOOLEAN | IN |
| szTitle | VARCHAR2 | IN |
| szInitDir | VARCHAR2 | IN |
| szFileFilter | VARCHAR2 | IN |
| Flags | PLS_INTEGER | IN |
| SepChar | VARCHAR2 | IN |
| szBuffer | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| szBuffer | VARCHAR2 | IN OUT |

---

**Dependencies**

- ADD_ERROR ([SP-068](#SP-068--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-069](#SP-069--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-070](#SP-070--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-071](#SP-071--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_CHOOSEFILE ([SP-005](#SP-005--D2KWUTIL.D2KWUTIL_CHOOSEFILE)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- D2KWUTIL.GET_ACTIVE_WINDOW ([SP-010](#SP-010--D2KWUTIL.GET_ACTIVE_WINDOW)) - D2KWUTIL.pck (or .pld)
- DEBUGLOG ([SP-072](#SP-072--DEBUGLOG)) - matched by member name
- GET_TEMP_DIRECTORY ([SP-074](#SP-074--GET_TEMP_DIRECTORY)) - matched by member name
- GET_WINDOWS_DIRECTORY ([SP-075](#SP-075--GET_WINDOWS_DIRECTORY)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-077](#SP-077--REGISTER_FUNCTION_CALL)) - matched by member name
- WEBUTIL.LENGTH ([SP-051](#SP-051--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Log all input arguments (CalledBy, Modal flag, title, initial directory, file filter, flags, separator character, and buffer) using DEBUGLOG at verbosity level 99.
- Step 2 - Clear the error stack by calling CLEAN_ERROR_STACK before any processing begins.
- Step 3 - Determine window ownership: if the Modal parameter is TRUE, retrieve the active window handle via D2KWUTIL.GET_ACTIVE_WINDOW and assign it as hwndOwner; otherwise set hwndOwner to 0 (modeless).
- Step 4 - Check whether the Win32 API layer is enabled (WIN_API.API_ENABLED). If not enabled, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 5 - Register the external DLL function 'd2kwutil_ChooseFile' with its call signature using REGISTER_FUNCTION_CALL, binding it to the internal handle iChooseFile.
- Step 6 - Translate the CalledBy parameter to a dialog-mode integer: 'Open_File' maps to iBuff1 = 1 (Open dialog); any other value maps to iBuff1 = 2 (Save dialog).
- Step 7 - Resolve the initial directory token: if szInitDir equals '$WINDIR$' (case-insensitive), replace it with the Windows directory obtained from GET_WINDOWS_DIRECTORY; if it equals '$TEMP$', replace it with the temporary directory obtained from GET_TEMP_DIRECTORY; otherwise use szInitDir as supplied.
- Step 8 - Ensure the resolved directory path ends with a backslash ('\'); append one if the final character is not already a backslash.
- Step 9 - Resolve the file filter: if szFileFilter is NULL or empty, default to 'All files(*.*)|*.*|'; otherwise use the supplied filter string.
- Step 10 - Truncate the SepChar parameter to its first character for use as the multi-file separator.
- Step 11 - Pad the szBuffer value to exactly 4096 characters with NUL characters (CHR(0)) to prepare the output buffer for the Win32 call.
- Step 12 - Invoke D2KWUTIL.D2KWUTIL_CHOOSEFILE with the resolved arguments (function handle, dialog mode, owner window handle, title, directory, filter, flags, separator, and padded buffer); capture the integer return code.
- Step 13 - Log the return code and the resulting buffer contents using DEBUGLOG.
- Step 14 - Write the populated buffer back to the IN OUT parameter szBuffer and return the integer result code to the caller.
- Step 15 - On WIN_API.NOT_AVAILABLE exception, record the error via ADD_ERROR using the NoAPI message and re-raise.
- Step 16 - On any other exception, record the error via ADD_ERROR appending external error details from ADD_EXTERNAL_ERRORS and re-raise.

---
**Decision Points**

DP-001

Condition:
Modal IN parameter is TRUE.

TRUE:
Retrieve the current active window handle via D2KWUTIL.GET_ACTIVE_WINDOW and assign it to hwndOwner so the dialog is displayed as a modal child of that window.

FALSE:
Set hwndOwner to 0, causing the dialog to appear without a parent window (modeless).

---

DP-002

Condition:
WIN_API.API_ENABLED evaluates to TRUE.

TRUE:
Proceed with registering the external function and invoking the file-chooser dialog.

FALSE:
Raise WIN_API.NOT_AVAILABLE, bypassing all dialog logic.

---

DP-003

Condition:
CalledBy = 'Open_File'.

TRUE:
Set dialog-mode integer iBuff1 to 1, requesting an Open File dialog.

FALSE:
Set dialog-mode integer iBuff1 to 2, requesting a Save File dialog.

---

DP-004

Condition:
UPPER(szInitDir) = '$WINDIR$'.

TRUE:
Replace the directory with the Windows system directory returned by GET_WINDOWS_DIRECTORY.

FALSE:
Evaluate DP-005 to check for the '$TEMP$' token.

---

DP-005

Condition:
UPPER(szInitDir) = '$TEMP$'.

TRUE:
Replace the directory with the temporary directory returned by GET_TEMP_DIRECTORY.

FALSE:
Use szInitDir as supplied without substitution.

---

DP-006

Condition:
The last character of the resolved directory path is not a backslash ('\').

TRUE:
Append a backslash to the directory path to ensure a valid trailing separator.

FALSE:
Leave the directory path unchanged.

---

DP-007

Condition:
szFileFilter is NULL or an empty string.

TRUE:
Default the file filter to 'All files(*.*)|*.*|' to allow selection of any file type.

FALSE:
Use the caller-supplied szFileFilter value unchanged.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - All input arguments must be logged at debug level 99 before any processing occurs, providing a full audit trail of each invocation.
- BR-002 - The error stack must be cleared at the start of each invocation to prevent stale errors from prior calls from contaminating the current operation.
- BR-003 - The file-chooser dialog may only be invoked when the Win32 API layer is available; if WIN_API.API_ENABLED is FALSE the function must raise WIN_API.NOT_AVAILABLE without attempting the dialog.
- BR-004 - A CalledBy value of 'Open_File' exclusively maps to an Open File dialog (mode 1); all other CalledBy values produce a Save File dialog (mode 2).
- BR-005 - The special token '$WINDIR$' in the initial directory must be resolved at runtime to the actual Windows directory; '$TEMP$' must be resolved to the actual temporary directory. These tokens are case-insensitive.
- BR-006 - The resolved initial directory path must always terminate with a backslash; one is appended automatically if absent.
- BR-007 - When no file filter is provided by the caller, the dialog must default to displaying all files using the filter 'All files(*.*)|*.*|'.
- BR-008 - Only the first character of the SepChar parameter is used as the multi-file separator; any additional characters are discarded.
- BR-009 - The output buffer passed to the underlying D2KWUTIL.D2KWUTIL_CHOOSEFILE call must be exactly 4096 characters, padded with NUL characters (CHR(0)).
- BR-010 - On a WIN_API.NOT_AVAILABLE exception, the error must be recorded via ADD_ERROR with the NoAPI message before the exception is re-raised to the caller.
- BR-011 - On any other unhandled exception, the error must be recorded via ADD_ERROR with the generic error message concatenated with external error details from ADD_EXTERNAL_ERRORS before the exception is re-raised.

---
**Implementation Logic**

```plsql
    
FUNCTION ChooseFile(  CalledBy      IN      VARCHAR2,
                      Modal         IN      BOOLEAN,
                      szTitle       IN      VARCHAR2,
                      szInitDir     IN      VARCHAR2,
                      szFileFilter  IN      VARCHAR2,
                      Flags         IN      PLS_INTEGER,
                      SepChar       IN      VARCHAR2,
                      szBuffer      IN OUT  VARCHAR2 ) RETURN PLS_INTEGER is
  hwndOwner  PLS_INTEGER;
  iBuff1     PLS_INTEGER;
  iBuff2     PLS_INTEGER;
  iRC        PLS_INTEGER;
  vcBuff1    VARCHAR2(255);
  vcBuff2    VARCHAR2(2000);
  vcBuff3    VARCHAR2(100);
  vcBuff4    VARCHAR2(1);
  vcBuff5    VARCHAR2(4096);
begin 
  Win_API_Debug.DebugLog(99,'ChooseFile','Args: CalledBy="'||CalledBy||', Modal='||win_api_debug.BoolToChar(Modal)||', szTitle="'||szTitle||'", szInitDir="'||szInitDir||'", szFileFilter="'||szFileFilter||'", Flags='||to_char(flags)||', SepChar="'||SepChar||'", szBuffer="'||szBuffer||'"');	
  Win_API.Clean_Error_Stack;
  iRC  := 0;
  if Modal then 
    hwndOwner := win_api_utility.get_active_window;
  else
    hwndOwner := 0;
  end if;

  if Win_API.API_ENABLED then 
      win_api.Register_function_call(iChooseFile,'d2kwutil_ChooseFile','INT','INT,SHORT,*CHAR,*CHAR,*CHAR,LONG,CHAR,*CHAR');

      if CalledBy = 'Open_File' then
        iBuff1     := 1;
      else
        iBuff1    := 2;
      end if;
      iBuff2    := Flags;
      vcBuff1    := szTitle;
      
      if upper(szInitDir) = '$WINDIR$' then 
        vcBuff2 := win_api_environment.get_windows_directory;
      elsif  upper(szInitDir) = '$TEMP$' then 
        vcBuff2 := win_api_environment.get_temp_directory;
      else 
        vcBuff2 := szInitDir;
      end if;
      
      if substr(vcBuff2,length(vcBuff2),1) <> '\' then 
        vcBuff2 := vcBuff2||'\';
      end if;
      
      if szFileFilter = NULL or szFileFilter = '' then 
        vcBuff3 := 'All files(*.*)|*.*|';
      else
        vcBuff3 := szFileFilter;
      end if;
      vcBuff4 := substr(SepChar,1,1);
      vcBuff5 := RPAD(szBuffer,4096,CHR(0)); 
      
      iRC := d2kwutil_choosefile (win_api.FunctionHandle(iChoosefile),iBuff1,hwndOwner,vcBuff1,vcBuff2,vcBuff3,iBuff2,vcBuff4,vcBuff5);
      Win_API_Debug.DebugLog(99,'ChooseFile','Result: RC='||to_char(iRC)||', szBuffer="'||vcBuff5||'"');
      szBuffer := vcBuff5;
      return iRC;
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
exception
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error(CalledBy,Win_API.NoAPI);
    raise;
  when others then
    Win_API.Add_error(CalledBy, Win_API.UError||WIN_API.Add_External_errors); 
    raise;  
end Choosefile;
```

#### SP-004 - D2KWUTIL.D2KWUTIL_ACTIVEWIN

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Declares the interface function that retrieves the currently active window handle by delegating the call to the underlying foreign-function interface (ORA_FFI). It is registered as a callable entry point used by D2KWUTIL.GET_ACTIVE_WINDOW to obtain the active window identifier from the operating-system layer.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the ORA_FFI function handle (hFunc) that maps this PL/SQL function to its corresponding native OS-level routine.
- Step 2 - Invoke the foreign function referenced by hFunc via the ORA_FFI mechanism to query the currently active window.
- Step 3 - Return the result as a PLS_INTEGER representing the active window handle to the calling routine (D2KWUTIL.GET_ACTIVE_WINDOW).

---
**Decision Points**

No conditional decision points are present in the available implementation. The function specification contains no branching logic; execution flows unconditionally from receipt of the function handle to return of the active window identifier.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must receive a valid ORA_FFI function handle (hFunc); this handle is the sole input and determines which native routine is invoked to resolve the active window.
- BR-002 - The return value is typed as PLS_INTEGER, meaning the active window reference is expressed as an integer handle consistent with the OS windowing model exposed through ORA_FFI.
- BR-003 - This function operates purely as a foreign-function bridge with no database interactions; it must not be used to perform data retrieval or DML operations.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.
FUNCTION d2kwutil_ActiveWin(  hFunc          IN      ORA_FFI.funcHandleType) return PLS_INTEGER;
```

#### SP-005 - D2KWUTIL.D2KWUTIL_CHOOSEFILE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a Windows native file-chooser dialog to the Oracle Forms runtime by invoking an external foreign-function interface (FFI) handle. The function delegates to the underlying OS dialog via ORA_FFI, allowing the calling form to present either an Open or Save file-selection dialog and return the user-selected file path(s) back to the caller through IN OUT parameters.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| dialog_type | PLS_INTEGER | IN |
| hwndOwner | PLS_INTEGER | IN |
| szTitle | VARCHAR2 | IN OUT |
| szInitDir | VARCHAR2 | IN OUT |
| szFileFilter | VARCHAR2 | IN OUT |
| AdvancedFlags | PLS_INTEGER | IN |
| SepChar | VARCHAR2 | IN |
| szBuffer | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| szTitle | VARCHAR2 | IN OUT |
| szInitDir | VARCHAR2 | IN OUT |
| szFileFilter | VARCHAR2 | IN OUT |
| szBuffer | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the pre-registered FFI function handle (hFunc) that points to the native Windows file-dialog routine, together with all dialog configuration parameters.
- Step 2 - Accept the dialog_type integer to determine whether an Open-file or Save-file dialog variant is requested.
- Step 3 - Accept the parent window handle (hwndOwner) so the dialog is correctly parented to the calling Oracle Forms window.
- Step 4 - Pass the display title (szTitle), initial directory (szInitDir), and file-filter string (szFileFilter) as IN OUT arguments to the native dialog; these may be modified or confirmed by the OS call.
- Step 5 - Pass AdvancedFlags to control extended dialog behaviour (e.g., multi-select, read-only checkbox) and SepChar to define the separator character used when multiple files are returned.
- Step 6 - Invoke the native file-chooser through the ORA_FFI function handle and populate szBuffer with the selected file path or paths upon return.
- Step 7 - Return a PLS_INTEGER result code to the caller indicating success or cancellation/failure of the dialog interaction.

---
**Decision Points**

DP-001

Condition:
The user either confirms a file selection or cancels/closes the native file-chooser dialog.

TRUE (file selected):
szBuffer is populated with the chosen file path(s), separated by SepChar when multiple files are selected, and the function returns a non-zero success code to the caller.

FALSE (dialog cancelled or failed):
szBuffer remains empty or unchanged and the function returns zero or an error code, signalling to the caller that no file was chosen.

---

DP-002

Condition:
dialog_type parameter specifies the variant of the file dialog (e.g., Open vs. Save).

TRUE (Open dialog requested):
The native dialog is presented in file-open mode, allowing the user to browse and select an existing file.

FALSE (Save dialog requested):
The native dialog is presented in file-save mode, allowing the user to specify a target file name and location.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function signature is declaration-only within Oracle Forms PL/SQL; the actual dialog behaviour is implemented in the native Windows library accessed through the ORA_FFI handle (hFunc), which must be initialised and registered by the caller before invoking this function.
- BR-002 - szTitle, szInitDir, szFileFilter, and szBuffer are all IN OUT parameters; the caller must supply initial values and must read back the potentially modified values after the call.
- BR-003 - The SepChar parameter defines the delimiter used to separate multiple selected file paths in szBuffer; the caller is responsible for parsing szBuffer using this character when multi-select flags are enabled via AdvancedFlags.
- BR-004 - The function returns a PLS_INTEGER result code; the calling routine (D2KWUTIL.CHOOSEFILE) is responsible for interpreting this code to determine whether the user confirmed or cancelled the dialog.
- BR-005 - No database interactions are performed by this function; it is purely a UI/OS integration utility with no persistent side-effects.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

 FUNCTION d2kwutil_ChooseFile (   hFunc         IN      ORA_FFI.funcHandleType,
                                  dialog_type   IN      PLS_INTEGER,
                                  hwndOwner     IN      PLS_INTEGER,
                                  szTitle       IN OUT  VARCHAR2,
                                  szInitDir     IN OUT  VARCHAR2,
                                  szFileFilter  IN OUT  VARCHAR2,
                                  AdvancedFlags IN      PLS_INTEGER,
                                  SepChar       IN      VARCHAR2,
                                  szBuffer      IN OUT  VARCHAR2) return PLS_INTEGER;
```

#### SP-006 - D2KWUTIL.D2KWUTIL_DEBUGSTRING

**Invoked From:**

- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level foreign-function interface (FFI) bridge that passes a debug text string to the underlying C library routine registered under the D2KWUTIL shared library. It is called by the WINDEBUG stored procedure within D2kwutil.pld to emit diagnostic or debug messages at runtime without interacting with the database.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that identifies the target C function within the D2KWUTIL external library.
- Step 2 - Receive the debug text string (Text) to be transmitted to that external function.
- Step 3 - Delegate execution to the C-language implementation via the ORA_FFI PRAGMA INTERFACE binding (magic number 11265), passing both hFunc and Text directly to the external routine.
- Step 4 - Return control to the caller (WINDEBUG) upon completion of the external call; no return value or output parameter is produced.

---
**Decision Points**

No conditional decision points are present in this procedure. The routine unconditionally delegates to the external C function via the ORA_FFI pragma interface; all branching logic, if any, resides within the external C implementation and is outside the scope of this specification.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must be invoked with a valid ORA_FFI function handle (hFunc); the handle must have been registered against the D2KWUTIL external C library prior to invocation, as no internal validation of the handle is performed.
- BR-002 - The Text parameter must be a VARCHAR2 value; the procedure imposes no explicit length constraint, but the receiving C function may enforce its own limits.
- BR-003 - This procedure has no database interactions; its sole responsibility is diagnostic message forwarding to an external C routine and must not be used for data persistence.
- BR-004 - The ORA_FFI PRAGMA INTERFACE binding (identifier 11265) is fixed at compile time and must not be altered; it uniquely maps this PL/SQL wrapper to the corresponding C entry point in the D2KWUTIL library.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.
   
 PROCEDURE d2kwutil_DebugString (    hFunc       IN      ORA_FFI.funcHandleType,
                                     Text        IN      VARCHAR2);
 -- Pragmas
 PRAGMA INTERFACE(C,d2kwutil_DebugString,      11265);
```

#### SP-007 - D2KWUTIL.D2KWUTIL_GETDOSENV

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level Foreign Function Interface (FFI) wrapper that retrieves a DOS/operating-system environment variable value. Given a function handle and a source environment variable name, the routine passes the request to the underlying OS layer via ORA_FFI and returns the expanded (resolved) value of the environment variable in the ExpandStr output buffer, along with an integer return code indicating the outcome of the call.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| SourceStr | VARCHAR2 | IN OUT |
| ExpandStr | VARCHAR2 | IN OUT |
| InBuffLen | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| SourceStr | VARCHAR2 | IN OUT |
| ExpandStr | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that identifies the pre-registered OS-level function to be invoked for environment variable resolution.
- Step 2 - Accept the source environment variable name in SourceStr (IN OUT), which identifies the variable whose value is to be retrieved from the operating system.
- Step 3 - Accept the ExpandStr buffer (IN OUT) and the maximum buffer length InBuffLen, which define the target storage for the resolved environment variable value.
- Step 4 - Delegate execution to the OS-level function referenced by hFunc via the ORA_FFI mechanism, passing SourceStr, ExpandStr, and InBuffLen as arguments.
- Step 5 - Receive the expanded environment variable string back into ExpandStr from the OS call.
- Step 6 - Return a PLS_INTEGER result code to the caller (GET_ENVIRONMENT_STRING in D2kwutil.pld) indicating success or failure of the environment variable lookup.

---
**Decision Points**

No explicit decision points are determinable from the available source. Only the function specification is present; no conditional branching logic is evidenced in the implementation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be invoked with a valid ORA_FFI function handle (hFunc); the handle must reference the appropriate OS environment-variable retrieval function registered through the ORA_FFI interface.
- BR-002 - The ExpandStr buffer length must be specified via InBuffLen to prevent overflow when the OS writes the resolved environment variable value into ExpandStr.
- BR-003 - Both SourceStr and ExpandStr are declared IN OUT, meaning the caller is responsible for initialising them before the call and reading their updated values after the call.
- BR-004 - The integer return code must be evaluated by the calling routine (GET_ENVIRONMENT_STRING) to determine whether the environment variable was successfully resolved.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_GetDOSEnv (   hFunc          IN      ORA_FFI.funcHandleType,
                                SourceStr      IN OUT  VARCHAR2,
                                ExpandStr      IN OUT  VARCHAR2,
                                InBuffLen      IN      PLS_INTEGER
                                ) RETURN PLS_INTEGER;
```

#### SP-008 - D2KWUTIL.D2KWUTIL_GETREGKEY

**Invoked From:**

- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

D2KWUTIL_GETREGKEY is a foreign-function interface (FFI) wrapper that retrieves a Windows registry key value. Given a registry root, path, and entry name, it invokes an external native function (referenced via the ORA_FFI function handle) to read the corresponding registry value into the RegValue output parameter, returning an integer status code indicating the outcome of the registry read operation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| RegRoot | PLS_INTEGER | IN |
| RegPath | VARCHAR2 | IN OUT |
| RegEntry | VARCHAR2 | IN OUT |
| RegValue | VARCHAR2 | IN OUT |
| RegValueLength | PLS_INTEGER | IN |
| RegDontExpand | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RegPath | VARCHAR2 | IN OUT |
| RegEntry | VARCHAR2 | IN OUT |
| RegValue | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the ORA_FFI function handle (hFunc) that references the underlying native Windows registry API entry point.
- Step 2 - Accept the registry root identifier (RegRoot), registry path (RegPath), and registry entry name (RegEntry) as locators for the target registry key.
- Step 3 - Accept RegValueLength to define the maximum buffer size for the value to be retrieved, and RegDontExpand to control whether environment-variable strings within the registry value are expanded.
- Step 4 - Delegate execution to the external native function via the ORA_FFI mechanism using the supplied hFunc handle, passing all input parameters.
- Step 5 - Receive the retrieved registry value into the RegValue IN OUT parameter.
- Step 6 - Return a PLS_INTEGER status code to the caller (READ_REGISTRY in D2kwutil.pld) indicating success or failure of the registry read.

---
**Decision Points**

DP-001

Condition: RegDontExpand flag value passed by the caller.

TRUE (non-zero): The native function returns the registry value as stored, without expanding embedded environment-variable references (e.g., %SystemRoot%).

FALSE (zero): The native function expands any environment-variable strings found within the registry value before returning it in RegValue.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function handle (hFunc) must be a valid ORA_FFI.funcHandleType reference established prior to invocation; the function does not initialise or validate the handle itself.
- BR-002 - RegPath and RegEntry are declared IN OUT; the caller must supply populated values, and the native layer may normalise or modify them during the call.
- BR-003 - The length of the value buffer is governed by RegValueLength; the retrieved registry value must not exceed this length.
- BR-004 - The caller is responsible for interpreting the returned PLS_INTEGER status code to determine whether the registry read succeeded or failed.
- BR-005 - This function contains no PL/SQL body; all processing is performed by the external native library invoked through the ORA_FFI mechanism.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_GetRegKey (    hFunc         IN      ORA_FFI.funcHandleType,
                                RegRoot        IN      PLS_INTEGER,
                                RegPath        IN OUT  VARCHAR2,
                                RegEntry       IN OUT  VARCHAR2,
                                RegValue       IN OUT  VARCHAR2,
                                RegValueLength IN      PLS_INTEGER,
                                RegDontExpand	 IN      PLS_INTEGER
                                ) return PLS_INTEGER;
```

#### SP-009 - D2KWUTIL.D2KWUTIL_WINDIR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level FFI (Foreign Function Interface) wrapper function that delegates to a native Windows API call to retrieve the Windows directory path. It accepts a pre-registered FFI function handle, a buffer to receive the directory string, and the buffer length, returning an integer result code. It is called exclusively by GET_TEMP_DIRECTORY and GET_WINDOWS_DIRECTORY within D2kwutil.pld to resolve the Windows directory at runtime.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| WindowsDir | VARCHAR2 | IN OUT |
| InBuffLen | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| WindowsDir | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that references the pre-registered native Windows API function for retrieving the Windows directory.
- Step 2 - Accept the IN OUT buffer parameter (WindowsDir) that will hold the returned directory path string, along with the declared buffer length (InBuffLen) to prevent overflow.
- Step 3 - Invoke the bound native function via the ORA_FFI mechanism using the supplied handle, passing WindowsDir and InBuffLen as arguments.
- Step 4 - Populate the WindowsDir IN OUT parameter with the Windows directory path returned by the native call.
- Step 5 - Return a PLS_INTEGER result code to the caller (GET_TEMP_DIRECTORY or GET_WINDOWS_DIRECTORY) indicating the outcome of the native function invocation.

---
**Decision Points**

No decision points are present. The function specification contains no conditional branching; it acts as a direct FFI pass-through wrapper whose sole logic is to invoke the bound native function and return its result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be invoked with a valid, pre-registered ORA_FFI function handle (hFunc); the handle must have been bound to the appropriate native Windows API function before this wrapper is called.
- BR-002 - The caller is responsible for supplying a WindowsDir buffer sized to at least InBuffLen characters to safely receive the directory path without truncation.
- BR-003 - This function is a specification-only FFI wrapper; it contains no independent business logic and must not be called outside the context of GET_TEMP_DIRECTORY or GET_WINDOWS_DIRECTORY, which are its sole authorised invocation points.
- BR-004 - The returned PLS_INTEGER result code must be evaluated by the calling procedure to determine whether the native directory retrieval succeeded.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_WinDir (      hFunc          IN      ORA_FFI.funcHandleType,
                                WindowsDir     IN OUT  VARCHAR2,
                                InBuffLen      IN      PLS_INTEGER
                                ) RETURN PLS_INTEGER;
```

#### SP-010 - D2KWUTIL.GET_ACTIVE_WINDOW

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the Windows handle of the currently active window by invoking the external DLL function D2KWUTIL.D2KWUTIL_ACTIVEWIN via the WIN_API framework. The function returns the active window handle as a PLS_INTEGER and, depending on the RaiseExceptions flag, either silently records a failure or raises an exception when no valid handle can be obtained. It is called by D2KWUTIL.CHOOSEFILE to identify the parent window context before presenting a file-chooser dialog.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-068](#SP-068--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-069](#SP-069--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-070](#SP-070--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-071](#SP-071--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_ACTIVEWIN ([SP-004](#SP-004--D2KWUTIL.D2KWUTIL_ACTIVEWIN)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-072](#SP-072--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-077](#SP-077--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log entry diagnostics by calling DEBUGLOG (SP-072) with severity 99, the function name 'Get_Active_Window', and the value of the RaiseExceptions argument converted to a character string via BOOLTOCHAR (SP-070).
- Step 2 - Clear any previously accumulated error state by calling CLEAN_ERROR_STACK (SP-071) on the WIN_API framework.
- Step 3 - Check whether the WIN_API framework is enabled (WIN_API.API_ENABLED). If enabled, proceed to Step 4; otherwise raise WIN_API.NOT_AVAILABLE.
- Step 4 - Register the external function call by invoking REGISTER_FUNCTION_CALL (SP-077) with the internal slot identifier iActiveWin, the function name 'd2kwutil_ActiveWin', return type 'INT', and no additional arguments.
- Step 5 - Execute the external DLL function D2KWUTIL.D2KWUTIL_ACTIVEWIN (SP-004) by passing the resolved function handle, capturing the returned window handle integer in iRC.
- Step 6 - Log the result by calling DEBUGLOG (SP-072) with the value of iRC.
- Step 7 - Evaluate the return code iRC. If iRC equals 0 (no valid handle returned), record an error via ADD_ERROR (SP-068) and, if RaiseExceptions is TRUE, raise NO_DATA_FOUND.
- Step 8 - Return iRC (the active window handle) to the caller.
- Step 9 - Handle exceptions: re-raise NO_DATA_FOUND as-is; on WIN_API.NOT_AVAILABLE, record the unavailability message via ADD_ERROR (SP-068) and re-raise; on all other exceptions, record a combined error message using ADD_ERROR (SP-068) and ADD_EXTERNAL_ERRORS (SP-069) and re-raise.

---
**Decision Points**

DP-001

Condition:
WIN_API.API_ENABLED - the WIN_API framework is available and initialised.

TRUE:
Register the external function call via REGISTER_FUNCTION_CALL (SP-077), invoke D2KWUTIL.D2KWUTIL_ACTIVEWIN (SP-004) to obtain the active window handle, and log the result via DEBUGLOG (SP-072).

FALSE:
Raise the WIN_API.NOT_AVAILABLE exception, which is caught by the exception handler, recorded via ADD_ERROR (SP-068), and re-raised to the caller.

---

DP-002

Condition:
iRC = 0 - the external DLL call returned zero, indicating it could not obtain a valid active window handle.

TRUE:
Record an error via ADD_ERROR (SP-068) with message 'Unable to obtain active window handle', then evaluate DP-003.

FALSE:
Skip error recording and proceed to return the valid window handle to the caller.

---

DP-003

Condition:
RaiseExceptions is TRUE (evaluated only when iRC = 0).

TRUE:
Raise NO_DATA_FOUND, which propagates to the caller after being re-raised by the exception handler.

FALSE:
Suppress the exception; return iRC (0) to the caller, allowing the caller to handle the absence of a window handle silently.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The WIN_API framework must be enabled (WIN_API.API_ENABLED) before any attempt is made to call the external DLL function; if the framework is unavailable, the function must not proceed and must raise WIN_API.NOT_AVAILABLE.
- BR-002 - The error stack must be cleared via CLEAN_ERROR_STACK (SP-071) at the start of every invocation to ensure error state from prior calls does not contaminate the current result.
- BR-003 - All entry arguments must be logged via DEBUGLOG (SP-072) at severity 99 before any processing begins, and the result must be logged immediately after the external call returns, to support diagnostic tracing.
- BR-004 - A return value of zero from D2KWUTIL.D2KWUTIL_ACTIVEWIN (SP-004) is treated as a failure condition; an error must be recorded via ADD_ERROR (SP-068) regardless of the RaiseExceptions setting.
- BR-005 - The RaiseExceptions flag governs whether a zero return code escalates to a raised exception (NO_DATA_FOUND) or is silently absorbed; callers must pass TRUE when they require hard failure behaviour.
- BR-006 - All exceptions (NO_DATA_FOUND, WIN_API.NOT_AVAILABLE, and unhandled others) must be recorded via ADD_ERROR (SP-068) - with ADD_EXTERNAL_ERRORS (SP-069) appended for unhandled exceptions - and then re-raised, ensuring no exception is silently swallowed by this function.

---
**Implementation Logic**

```plsql

FUNCTION Get_Active_Window (RaiseExceptions IN  BOOLEAN DEFAULT FALSE) RETURN PLS_INTEGER is
  iRC    PLS_INTEGER := 0;
begin
  Win_API_Debug.DebugLog(99,'Get_Active_Window','Args: RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	  			
  WIN_API.Clean_Error_Stack;
  if WIN_API.API_ENABLED then 
    win_api.Register_function_call(iActiveWin,'d2kwutil_ActiveWin','INT',NULL);
    iRC   := d2kwutil_ActiveWin(win_api.FunctionHandle(iActiveWin));
    Win_API_Debug.DebugLog(99,'Get_Active_Window','Result: RC='||to_char(iRC));        
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0 then 
    Win_API.Add_error('Get_Active_Window','Unable to obtain active window handle');
    if RaiseExceptions then 
      raise NO_DATA_FOUND;
    end if;
  end if;
  return iRC;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Active_Window',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Active_Window',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Active_window;
```

#### SP-011 - D2KWUTIL.SAVE_FILE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FILE_SAVE_DIALOG]
- webutil.pld [StoredProcedure: WEBUTIL.FILE_SELECTION_DIALOG_INT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Presents a 'Save File As' dialog to the user and returns the file path selected by the user. The function delegates the actual dialog rendering to D2KWUTIL.CHOOSEFILE and handles the case where no file is selected, optionally raising an exception or recording an error via ADD_ERROR.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| SampleName | VARCHAR2 | IN |
| Title | VARCHAR2 | IN |
| StartDirectory | VARCHAR2 | IN |
| FileFilter | VARCHAR2 | IN |
| Modal | BOOLEAN | IN |
| AdvancedFlags | PLS_INTEGER | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-068](#SP-068--ADD_ERROR)) - matched by member name
- D2KWUTIL.CHOOSEFILE ([SP-003](#SP-003--D2KWUTIL.CHOOSEFILE)) - D2KWUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Initialise the candidate file path by assigning the caller-supplied SampleName to the local variable vcReturnedFile, pre-populating the dialog with a suggested file name.
- Step 2 - Invoke D2KWUTIL.CHOOSEFILE (SP-003), passing the operation label 'Save_File', the Modal flag, Title, StartDirectory, FileFilter, AdvancedFlags, a space as the delimiter placeholder, and vcReturnedFile as the in/out file path. The integer return code is captured in iLRC.
- Step 3 - Evaluate iLRC to determine whether the user completed or cancelled the dialog.
- Step 4 - If iLRC equals 1 (no file selected / dialog cancelled), call ADD_ERROR (SP-068) with the context label 'Save_File' and the message 'No file was selected' to record the failure.
- Step 5 - If RaiseExceptions is TRUE and no file was selected, raise NO_DATA_FOUND so the calling routine can handle the absence of a selection programmatically.
- Step 6 - If iLRC does not equal 1 (user selected a file), return vcReturnedFile containing the fully qualified path chosen by the user.

---
**Decision Points**

DP-001

Condition:
iLRC = 1 (D2KWUTIL.CHOOSEFILE signals that no file was selected or the dialog was cancelled)

TRUE:
Call ADD_ERROR (SP-068) to log 'No file was selected'; then evaluate DP-002 to decide whether to raise an exception. The function does not return a file path.

FALSE:
Return vcReturnedFile to the caller as the user-chosen save-file path.

---

DP-002

Condition:
RaiseExceptions is TRUE (evaluated only when iLRC = 1)

TRUE:
Raise the built-in NO_DATA_FOUND exception, propagating the error to the calling routine.

FALSE:
Allow the function to exit silently after ADD_ERROR has been called; no exception is propagated.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The SampleName parameter serves as the default file name pre-populated in the Save dialog; it must be supplied by the caller and is used as the starting value for the returned file path.
- BR-002 - File selection is delegated entirely to D2KWUTIL.CHOOSEFILE (SP-003); SAVE_FILE does not construct or validate the file path itself.
- BR-003 - A return code of 1 from D2KWUTIL.CHOOSEFILE is the definitive signal that no file was selected; any other return code is treated as a successful selection.
- BR-004 - When no file is selected, ADD_ERROR (SP-068) must always be called with context label 'Save_File' and message 'No file was selected', regardless of the RaiseExceptions flag.
- BR-005 - Exception propagation is opt-in: the caller controls whether a missing file selection causes a NO_DATA_FOUND exception by setting RaiseExceptions to TRUE; the default behaviour is silent failure after error logging.
- BR-006 - The function returns a value only on the success path; on the no-selection path it either raises an exception or falls through without returning, so callers must handle a NULL return when RaiseExceptions is FALSE.

---
**Implementation Logic**

```plsql
                    

FUNCTION Save_File (  SampleName       IN  VARCHAR2,
                      Title            IN  VARCHAR2     DEFAULT 'Save File As',
                      StartDirectory   IN  VARCHAR2     DEFAULT '$WINDIR$',
                      FileFilter       IN  VARCHAR2     DEFAULT 'All files(*.*)|*.*|',
                      Modal            IN  BOOLEAN      DEFAULT TRUE,
                      AdvancedFlags    IN  PLS_INTEGER  DEFAULT WIN_API.OFN_FLAG_DEFAULT,
                      RaiseExceptions  IN  BOOLEAN      DEFAULT FALSE
                    ) RETURN VARCHAR2 is
  vcReturnedFile  varchar2(4096);
  iLRC    pls_integer := 0;
begin 
  vcReturnedFile  := SampleName;
  iLRC := choosefile('Save_File',Modal,Title,StartDirectory,FileFilter,AdvancedFlags,' ',vcReturnedFile);
  
  if iLRC = 1 then 
    Win_API.Add_error('Save_File','No file was selected');
    if RaiseExceptions then 
      Raise NO_DATA_FOUND;
    end if;
  else
    return vcReturnedFile;
  end if;
end Save_File;
```

#### SP-012 - D2KWUTIL.TRANSLATETYPE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Translates a string-based C data type name into its corresponding ORA_FFI integer constant. This utility function supports the dynamic foreign-function interface registration process by converting human-readable type tokens (e.g., 'INT', '*CHAR') into the numeric type codes required by ORA_FFI when registering external C function signatures.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DataType | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input string DataType representing a C data type name.
- Step 2 - Convert DataType to uppercase and store it in the local variable vcType to ensure case-insensitive matching.
- Step 3 - Evaluate vcType against each recognised C type token in sequence using an IF-ELSIF chain.
- Step 4 - For each matching token, assign the corresponding ORA_FFI integer constant to the local return variable iRC (e.g., '*CHAR' maps to ORA_FFI.C_CHAR_PTR, 'CHAR' maps to ORA_FFI.C_CHAR, 'INT' maps to ORA_FFI.C_INT, and so on for LONG, SHORT/BYTE, DOUBLE, and VOID variants).
- Step 5 - Return the resolved ORA_FFI integer constant iRC to the caller.

---
**Decision Points**

DP-001

Condition:
vcType = '*CHAR'

TRUE:
Assign ORA_FFI.C_CHAR_PTR to iRC.

FALSE:
Proceed to DP-002.

---

DP-002

Condition:
vcType = 'CHAR'

TRUE:
Assign ORA_FFI.C_CHAR to iRC.

FALSE:
Proceed to DP-003.

---

DP-003

Condition:
vcType = '*INT'

TRUE:
Assign ORA_FFI.C_INT_PTR to iRC.

FALSE:
Proceed to DP-004.

---

DP-004

Condition:
vcType = 'INT'

TRUE:
Assign ORA_FFI.C_INT to iRC.

FALSE:
Proceed to DP-005.

---

DP-005

Condition:
vcType = '*LONG'

TRUE:
Assign ORA_FFI.C_LONG_PTR to iRC.

FALSE:
Proceed to DP-006.

---

DP-006

Condition:
vcType = 'LONG'

TRUE:
Assign ORA_FFI.C_LONG to iRC.

FALSE:
Proceed to DP-007.

---

DP-007

Condition:
vcType = '*SHORT' OR vcType = '*BYTE'

TRUE:
Assign ORA_FFI.C_SHORT_PTR to iRC.

FALSE:
Proceed to DP-008.

---

DP-008

Condition:
vcType = 'SHORT' OR vcType = 'BYTE'

TRUE:
Assign ORA_FFI.C_SHORT to iRC.

FALSE:
Proceed to DP-009.

---

DP-009

Condition:
vcType = '*DOUBLE'

TRUE:
Assign ORA_FFI.C_DOUBLE_PTR to iRC.

FALSE:
Proceed to DP-010.

---

DP-010

Condition:
vcType = 'DOUBLE'

TRUE:
Assign ORA_FFI.C_DOUBLE to iRC.

FALSE:
Proceed to DP-011.

---

DP-011

Condition:
vcType = '*VOID'

TRUE:
Assign ORA_FFI.C_VOID_PTR to iRC.

FALSE:
iRC remains unassigned (NULL); the function returns NULL to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The input DataType is normalised to uppercase before comparison, making type token matching case-insensitive.
- BR-002 - Pointer variants of a type are denoted by prefixing the type name with an asterisk (e.g., '*INT' for a pointer-to-integer), and must be mapped to the corresponding ORA_FFI pointer constant (e.g., ORA_FFI.C_INT_PTR).
- BR-003 - The type tokens 'SHORT' and 'BYTE' are treated as equivalent and both resolve to ORA_FFI.C_SHORT; similarly, '*SHORT' and '*BYTE' both resolve to ORA_FFI.C_SHORT_PTR.
- BR-004 - If the supplied DataType does not match any recognised token, the function returns NULL (iRC is never assigned), and the caller is responsible for handling this unresolved condition.
- BR-005 - The function performs no database interactions and has no external dependencies; it operates solely as an in-memory lookup table mapping string tokens to ORA_FFI integer constants.

---
**Implementation Logic**

```plsql
 
FUNCTION TranslateType(DataType in VARCHAR2) return PLS_INTEGER is
   -- Just a simple lookup of the types.
   vcType VARCHAR2(10) := UPPER(DataType);
   iRC    PLS_INTEGER;
begin 
  if vcType = '*CHAR' then 
    iRC := ORA_FFI.C_CHAR_PTR;
  elsif vcType = 'CHAR' then 
    iRC := ORA_FFI.C_CHAR;
  elsif vcType = '*INT' then 
    iRC := ORA_FFI.C_INT_PTR;
  elsif vcType = 'INT' then 
    iRC := ORA_FFI.C_INT;
  elsif vcType = '*LONG' then 
    iRC := ORA_FFI.C_LONG_PTR;
  elsif vcType = 'LONG' then 
    iRC := ORA_FFI.C_LONG;
  elsif vcType = '*SHORT' or vcType = '*BYTE'  then 
    iRC := ORA_FFI.C_SHORT_PTR;
  elsif vcType = 'SHORT' or vcType = 'BYTE' then 
    iRC := ORA_FFI.C_SHORT;
  elsif vcType = '*DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE_PTR;
  elsif vcType = 'DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE;  
  elsif vcType = '*VOID' then 
    iRC := ORA_FFI.C_VOID_PTR;      
  end if;
return iRC;
end TranslateType;
```

#### SP-013 - GENERAL.ASK_CONFIRM

**Invoked From:**

- pr_mass_order_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

N/A

---

**Purpose**

Displays a configurable confirmation alert dialog (AL_CONFIRM) to the user and returns a numeric indicator of the button pressed. The function allows calling screens to prompt the user for a yes/no confirmation before proceeding with a business action, using a caller-supplied message text.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| confirm_msg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the confirmation message text (confirm_msg) passed by the calling trigger.
- Step 2 - Set the message text of the predefined alert dialog AL_CONFIRM to the supplied confirm_msg value using set_alert_property.
- Step 3 - Display the AL_CONFIRM alert dialog to the user using show_alert and capture the button pressed in p_albtn_pressed.
- Step 4 - Evaluate the captured button response against ALERT_BUTTON1.
- Step 5 - Return 1 if the user pressed ALERT_BUTTON1 (affirmative confirmation), or return 0 for any other button press (non-confirmation).

---
**Decision Points**

DP-001

Condition:
p_albtn_pressed equals ALERT_BUTTON1 (the user pressed the first/affirmative button on the AL_CONFIRM alert dialog).

TRUE:
The function returns 1, signalling to the caller that the user confirmed the action.

FALSE:
The function returns 0, signalling to the caller that the user did not confirm the action.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The alert dialog used for confirmation must be the predefined alert named AL_CONFIRM; no other alert is permitted by this function.
- BR-002 - The confirmation message presented to the user must be provided entirely by the caller via the confirm_msg parameter; the function does not supply or default any message text.
- BR-003 - A return value of 1 exclusively represents user confirmation (ALERT_BUTTON1 pressed); any other button press yields a return value of 0, treating all non-primary responses as rejection.
- BR-004 - The function has no side effects on database state; its sole purpose is to capture and translate a user's modal confirmation response into a binary numeric result for the caller to act upon.

---
**Implementation Logic**

```plsql
FUNCTION ASK_CONFIRM( confirm_msg VARCHAR2)
                                      RETURN  NUMBER IS

    p_alert_name varchar2(10) := 'AL_CONFIRM' ;
    p_albtn_pressed number;
BEGIN
   set_alert_property(p_alert_name,alert_message_text,confirm_msg); 
   p_albtn_pressed := show_alert(p_alert_name);

   IF ( p_albtn_pressed = ALERT_BUTTON1 ) THEN
      return (1);
   ELSE
      return(0);
   END IF;
RETURN NULL; END;
```

#### SP-014 - GENERAL.DISP_TEXT

**Invoked From:**

- pr_mass_order_fmb.xml [ProgramUnit: POPULATE_DETAILS]
- DPL.pld [StoredProcedure: GENERAL.RAISE_ERROR]
- pr_mass_order_fmb.xml [StoredProcedure: POPULATE_DETAILS]
- pr_mass_order_fmb.xml [Trigger: ON-ERROR]
- pr_mass_order_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]
- pr_mass_order_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]
- pr_mass_order_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

Details (N/A / CN_MAIN); Search Criteria (N/A / CN_MAIN)

---

**Purpose**

Displays a modal alert dialog to the user containing a caller-supplied message and title. The procedure selects the appropriate pre-defined Oracle Forms alert object based on whether the title indicates an error condition, then presents the message and waits for the user to acknowledge it. It is used across multiple triggers and program units in the mass-order form to surface both error notifications and general informational notes.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| text_string | VARCHAR2 | IN |
| title_string | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message body (`text_string`) and dialog title (`title_string`) as input parameters.
- Step 2 - Default the internal alert name to `AL_ERRINFO`.
- Step 3 - Evaluate the title string (case-insensitive) to determine which alert object to use: if the title equals 'ERROR', retain `AL_ERRINFO`; otherwise switch to `AL_NOTE`.
- Step 4 - Set the TITLE property of the selected alert object to the supplied `title_string` using `SET_ALERT_PROPERTY`.
- Step 5 - Set the ALERT_MESSAGE_TEXT property of the selected alert object to the supplied `text_string` using `SET_ALERT_PROPERTY`.
- Step 6 - Display the configured alert to the user via `SHOW_ALERT` and capture the user's button response in the local variable `p_alert_id` (response is not evaluated further).

---
**Decision Points**

DP-001

Condition:
UPPER(title_string) = 'ERROR'

TRUE:
The alert object `AL_ERRINFO` is used to display the message, indicating an error-severity notification.

FALSE:
The alert object `AL_NOTE` is used to display the message, indicating a general informational or non-error notification.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The title string comparison is performed case-insensitively; any casing variant of the word 'ERROR' (e.g., 'error', 'Error') routes the dialog to the error alert object `AL_ERRINFO`.
- BR-002 - All non-error titles must use the `AL_NOTE` alert object, ensuring visual and behavioural distinction between error and informational messages.
- BR-003 - Both the title and the message body are set dynamically at runtime on the chosen alert object before display, so the same alert objects serve all callers without requiring separate alert definitions per message.
- BR-004 - The user's alert button response is captured but not acted upon; the procedure is fire-and-forget with respect to the user's acknowledgement choice.

---
**Implementation Logic**

```plsql
PROCEDURE DISP_TEXT (text_string VARCHAR2,
                     title_string VARCHAR2 ) IS 
   p_alert_name varchar2(10) := 'AL_ERRINFO' ; 
   p_alert_id number;
BEGIN
   if upper(title_string)='ERROR' then
      p_alert_name := 'AL_ERRINFO' ; 
   else
      p_alert_name := 'AL_NOTE' ; 
   end if;
   set_alert_property(p_alert_name,TITLE,title_string);  
   set_alert_property(p_alert_name,alert_message_text,text_string);  
   p_alert_id := show_alert(p_alert_name); 
END;
```

#### SP-015 - GENERAL.RAISE_ERROR

**Invoked From:**

- pr_mass_order_fmb.xml [Trigger: ON-ERROR]

---

**Screen:**

N/A

---

**Purpose**

Centralises runtime error handling for Oracle Forms by classifying an incoming message code as an Error, Note, or Caution, composing a display string, and delegating presentation to GENERAL.DISP_TEXT. When the message is classified as an Error, the procedure additionally raises FORM_TRIGGER_FAILURE to halt further form processing. The procedure is invoked from the ON-ERROR trigger of pr_mass_order_fmb to provide consistent, user-facing error messaging across the form.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| mesg_code | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-014](#SP-014--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message code (mesg_code) as the sole input parameter.
- Step 2 - Compose the display text by concatenating mesg_code, a colon separator, and mesg_text (note: mesg_text is declared but not populated via the commented-out GENERAL.get_message call, so it contributes an empty/null suffix at runtime).
- Step 3 - Evaluate the mesg_type variable to determine the severity classification of the message.
- Step 4 - If mesg_type is 'E' (Error), set mesg_title to 'Error', call GENERAL.DISP_TEXT to present the message to the user, then raise FORM_TRIGGER_FAILURE to abort the current form trigger execution.
- Step 5 - If mesg_type is 'N' (Note), set mesg_title to 'Note' and call GENERAL.DISP_TEXT to present the informational message; processing continues normally.
- Step 6 - If mesg_type is 'C' (Caution), set mesg_title to 'Caution' and call GENERAL.DISP_TEXT to present the cautionary message; processing continues normally.
- Step 7 - If mesg_type does not match any recognised value ('E', 'N', or 'C'), no action is taken and the procedure exits silently.

---
**Decision Points**

DP-001

Condition:
mesg_type = 'E'

TRUE:
Set mesg_title to 'Error', invoke GENERAL.DISP_TEXT with the composed message text and title, then raise FORM_TRIGGER_FAILURE to halt form trigger processing.

FALSE:
Proceed to evaluate whether mesg_type = 'N'.

---

DP-002

Condition:
mesg_type = 'N'

TRUE:
Set mesg_title to 'Note' and invoke GENERAL.DISP_TEXT with the composed message text and title; form processing continues.

FALSE:
Proceed to evaluate whether mesg_type = 'C'.

---

DP-003

Condition:
mesg_type = 'C'

TRUE:
Set mesg_title to 'Caution' and invoke GENERAL.DISP_TEXT with the composed message text and title; form processing continues.

FALSE:
No matching severity type is found; the procedure takes no action and exits silently.

---
**Database Interactions**

- DB-001 - Read AM_PERMISSIONS - Reads data from AM_PERMISSIONS for lookup or validation.
**Business Rules**

- BR-001 - The message display string must always be prefixed with the original mesg_code followed by ' : ', ensuring the user can identify the originating message code alongside any associated message text.
- BR-002 - Only three message severity levels are recognised: 'E' (Error), 'N' (Note), and 'C' (Caution); any other value results in silent no-operation behaviour.
- BR-003 - An Error-severity message (mesg_type = 'E') must always terminate the active form trigger by raising FORM_TRIGGER_FAILURE after the message is displayed, preventing further processing.
- BR-004 - Note- and Caution-severity messages are purely informational; they must be displayed to the user via GENERAL.DISP_TEXT but must not interrupt or abort form trigger execution.
- BR-005 - All user-facing message presentation must be delegated exclusively to GENERAL.DISP_TEXT (SP-014); this procedure must not render messages through any other mechanism.

---
**Implementation Logic**

```plsql
PROCEDURE RAISE_ERROR ( mesg_code IN VARCHAR2 )IS
  mesg_type  varchar2(7); 
  mesg_text  varchar2(200) ;
  mesg_title varchar2(7);
  BEGIN
     -- murali 17.05.04 GENERAL.get_message(mesg_code,mesg_text,mesg_type );
     mesg_text:=mesg_code||' : '||mesg_text;		
     IF ( mesg_type = 'E' ) THEN
        mesg_title := 'Error' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
        raise FORM_TRIGGER_FAILURE;
     ELSIF ( mesg_type = 'N' ) THEN
        mesg_title := 'Note' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     ELSIF ( mesg_type = 'C' ) THEN
        mesg_title := 'Caution' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     END IF;
  END;     

/* PROCEDURE check_rights( 
pi_form_name in varchar2,
pi_user_id in number) IS
lv_x varchar2(1);
BEGIN
	
	begin
	SELECT substr(access_string, pi_user_id,1) 
	INTO   lv_x
	FROM   	am_permissions
	WHERE  form_name = pi_form_name
	AND SUBSTR(access_string,pi_user_id,1)='Y';
	exception 
		when no_data_found then
		  general.disp_text('You do not have the Permission to access this.','Error rr');
		  raise form_trigger_failure; 
		when too_many_rows then
		  general.disp_text('Many rows in USER_PERMISSIONS','Error ss');
		  raise form_trigger_failure;
		when others then
		       general.disp_text(sqlerrm,'Error mm');
		       raise form_trigger_failure;
	end;

	open_form(pi_form_name,activate,session);
END;
*/
```

#### SP-016 - WEBUTIL.BLOCKING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.HOST]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Executes a host operating-system command in blocking mode, meaning the Oracle Forms session waits for the command to complete before continuing. It acts as a convenience wrapper that delegates execution to WEBUTIL.EXECUTE (SP-025) with the BLOCKING_MODE constant pre-set, so callers do not need to specify the execution mode explicitly.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.EXECUTE ([SP-025](#SP-025--WEBUTIL.EXECUTE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the host command string (cmd) passed in by the caller (WEBUTIL.HOST).
- Step 2 - Invoke WEBUTIL.EXECUTE (SP-025) with cmd as the command argument and the constant BLOCKING_MODE as the execution-mode argument.
- Step 3 - Return the PROCESS_ID value produced by WEBUTIL.EXECUTE to the caller, allowing the caller to reference the completed process if required.

---
**Decision Points**

No conditional decision points exist within this procedure. The function unconditionally delegates to WEBUTIL.EXECUTE with BLOCKING_MODE; all branching logic resides within WEBUTIL.EXECUTE (SP-025).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The command must always be executed in blocking mode; callers of WEBUTIL.BLOCKING cannot override the execution mode - BLOCKING_MODE is hard-coded in the delegation call to WEBUTIL.EXECUTE (SP-025).
- BR-002 - The procedure returns a PROCESS_ID to the caller; this identifier is sourced entirely from WEBUTIL.EXECUTE (SP-025) and is not generated or modified by this function.
- BR-003 - No direct database interactions are performed by this function; all processing is delegated to WEBUTIL.EXECUTE (SP-025).

---
**Implementation Logic**

```plsql
  
  FUNCTION  Blocking(cmd in VARCHAR2) return PROCESS_ID is
  begin
    return Execute(cmd,BLOCKING_MODE);
  end Blocking;
```

#### SP-017 - WEBUTIL.CHECKLIBS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.CHECKLIBS ensures that all system libraries required by a given WebUtil package are present and up to date on the client machine. For each library defined in the package's property bundle, the procedure compares the installed version against the expected version and, where a mismatch or absence is detected, downloads the library from the configured URL to the client and records the new version. It is invoked by WEBUTIL.REGISTERBEAN as part of the client-side library provisioning process.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.DOWNLOADFROMURLINT ([SP-022](#SP-022--WEBUTIL.DOWNLOADFROMURLINT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTSETTING ([SP-032](#SP-032--WEBUTIL.GETCLIENTSETTING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-052](#SP-052--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-056](#SP-056--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READTRANSFROMMSGBUNDLE ([SP-057](#SP-057--WEBUTIL.READTRANSFROMMSGBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETCLIENTSETTING ([SP-061](#SP-061--WEBUTIL.SETCLIENTSETTING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the packageID input parameter identifying the WebUtil package whose system libraries must be verified.
- Step 2 - Begin an iterative loop, incrementing a library counter (lib) with each pass, to process every library entry associated with the package.
- Step 3 - Attempt to read the library specification from the property bundle using a fully qualified key that includes the client OS family, OS architecture, packageID, and the current library index (WEBUTIL.READFROMPROPERTYBUNDLE).
- Step 4 - If no specification is found for the OS-family/architecture combination, retry the lookup using a key that omits the OS architecture (OS family and packageID only) via WEBUTIL.READFROMPROPERTYBUNDLE.
- Step 5 - If both lookups return NULL, exit the loop; all libraries for the package have been processed.
- Step 6 - Parse the retrieved library specification string (pipe-delimited) to extract: library file name (position 1), expected file size (position 2), expected version string (position 3), and a progress-display flag (position 4).
- Step 7 - Query the client settings store for the currently installed version of the library using WEBUTIL.GETCLIENTSETTING with the key 'syslib.<libName>'.
- Step 8 - Evaluate whether a download is required: the installed version is absent, differs from the expected version, or the REDOWNLOAD_SYSLIB flag is set.
- Step 9 - If a download is required, resolve the download base URL by querying the property bundle in descending specificity order: OS family + architecture first, then OS family only, then the generic location key (WEBUTIL.READFROMPROPERTYBUNDLE, up to three attempts).
- Step 10 - Invoke WEBUTIL.DOWNLOADFROMURLINT with the resolved URL (base URL concatenated with the library file name), the target file name, the syslib install location indicator (1), the expected file size, the progress flag, and localised progress dialog title and subtitle strings retrieved via WEBUTIL.READTRANSFROMMSGBUNDLE.
- Step 11 - If the download succeeds, record the new version against the library key in the client settings store using WEBUTIL.SETCLIENTSETTING.
- Step 12 - If the download fails, write a failure message to the WebUtil log via WEBUTIL.LOG and continue to the next library.
- Step 13 - Return to Step 2 to process the next library entry for the package.

---
**Decision Points**

DP-001

Condition: The library specification retrieved by the OS-family/architecture-specific property bundle key is NULL.

TRUE: Retry the lookup using the OS-family-only key (architecture omitted) via WEBUTIL.READFROMPROPERTYBUNDLE.

FALSE: Use the retrieved specification and proceed to parse library attributes.

---

DP-002

Condition: Both the OS-family/architecture and the OS-family-only property bundle lookups return NULL.

TRUE: Exit the loop; no further libraries exist for this package.

FALSE: Continue processing the retrieved library specification.

---

DP-003

Condition: The installed version returned by WEBUTIL.GETCLIENTSETTING is NULL, differs from the expected version (libVer), or the REDOWNLOAD_SYSLIB flag is TRUE.

TRUE: Proceed to resolve the download URL and download the library.

FALSE: The library is current; skip download and advance to the next library entry.

---

DP-004

Condition: The OS-family/architecture-specific download URL lookup via WEBUTIL.READFROMPROPERTYBUNDLE returns NULL.

TRUE: Attempt to resolve the download URL using the OS-family-only key.

FALSE: Use the retrieved OS-family/architecture URL as the download base.

---

DP-005

Condition: The OS-family-only download URL lookup via WEBUTIL.READFROMPROPERTYBUNDLE returns NULL.

TRUE: Fall back to the generic 'install.syslib.location' key via WEBUTIL.READFROMPROPERTYBUNDLE.

FALSE: Use the retrieved OS-family URL as the download base.

---

DP-006

Condition: WEBUTIL.DOWNLOADFROMURLINT returns TRUE (download completed successfully).

TRUE: Record the expected version string against the library key in the client settings store via WEBUTIL.SETCLIENTSETTING.

FALSE: Log a failure message for the library via WEBUTIL.LOG and continue to the next library.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Library specifications for a package are stored in the property bundle under hierarchical keys that incorporate client OS family, OS architecture, packageID, and a sequential index; the procedure always attempts the most specific key (OS family + architecture) before falling back to the less specific key (OS family only).
- BR-002 - A library entry is considered absent or outdated if no installed version is recorded in the client settings store, if the recorded version does not exactly match the expected version defined in the property bundle, or if the REDOWNLOAD_SYSLIB override flag is active.
- BR-003 - The download base URL is resolved with the same OS-specificity fallback pattern (architecture-specific -> OS-family-only -> generic), ensuring the most appropriate server location is used for the client environment.
- BR-004 - A successful library download must be confirmed by WEBUTIL.DOWNLOADFROMURLINT returning TRUE before the new version is persisted to the client settings store via WEBUTIL.SETCLIENTSETTING; a failed download is never recorded as installed.
- BR-005 - A download failure does not abort processing; the failure is logged via WEBUTIL.LOG and the procedure continues to evaluate remaining libraries for the package.
- BR-006 - Progress dialog text displayed during download is sourced exclusively from the message bundle via WEBUTIL.READTRANSFROMMSGBUNDLE (keys INST_PGRS_TITLE and INST_PGRS_SUBTITLE), ensuring UI strings are localisation-controlled.
- BR-007 - The library download is categorised as a syslib install (location type 1) when invoking WEBUTIL.DOWNLOADFROMURLINT, directing the file to the designated system library installation path on the client.

---
**Implementation Logic**

```plsql
  
  PROCEDURE CheckLibs(packageID in VARCHAR2 ) is
    lib          PLS_INTEGER := 1;
    libSpec      VARCHAR2(200 char);
    libName      VARCHAR2(100 char);
    libSize      PLS_INTEGER;
    libVer       VARCHAR2(20 char);
    installedVer VARCHAR2(20 char);
    libProg      BOOLEAN := false;
    downloadURL  VARCHAR2(1000);
  BEGIN
    -- Read through the property bundle for 
    -- any libraries for this package
    LOOP
      libSpec := readFromPropertyBundle('install.syslib.'||to_char(m_clientOSFamily)||'.'||
             to_char(m_clientOSArch)||'.'||packageID||'.'||to_char(lib));
      if libSpec is null then
        libSpec := readFromPropertyBundle('install.syslib.'||to_char(m_clientOSFamily)||'.'||
             packageID||'.'||to_char(lib));
      end if;
      if libSpec is null then 
        exit;
      end if;
      lib := lib + 1;
      libName := Delimstr.getString(libSpec,1,true,'|');
      libSize := Delimstr.getNumber(libSpec,2,true,'|');
      libVer  := Delimstr.getString(libSpec,3,true,'|');
      libProg := (upper(Delimstr.getString(libSpec,4,true,'|'))='TRUE');

      -- OK we now have the library information
      -- let's check if it's installed
      installedVer := GetClientSetting('syslib.'||libname);
      if installedVer is null or installedVer <> libVer or REDOWNLOAD_SYSLIB then 
        -- need to download
        downloadURL := readFromPropertyBundle('install.syslib.location' || '.' || to_char(m_clientOSFamily) ||
                             '.' || to_char(m_clientOSArch));
        if downloadURL is null then
          downloadURL := readFromPropertyBundle('install.syslib.location' || '.' || to_char(m_clientOSFamily));
        end if;
        if downloadURL is null then
          downloadURL := readFromPropertyBundle('install.syslib.location');
        end if;
        if DownLoadFromURLInt(downloadURL||'/'||libName, 
                              libName,
                              1, -- syslib install download, special location
                              libSize,
                              libProg,
                              ReadTransFromMsgBundle('INST_PGRS_TITLE'),
                              ReadTransFromMsgBundle('INST_PGRS_SUBTITLE'),     
                              libName) then 
          SetClientSetting('syslib.'||libname,libVer);
        else
          log('Download of system library '||libName||' failed',true);
        end if;                          
      end if;
    END LOOP;
  END CheckLibs;
```

#### SP-018 - WEBUTIL.CLEARCALLBACKTRIGGER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Removes a previously registered callback entry from the internal callbacks collection using the supplied integer key. This procedure is used during WebUtil processing to clean up callback registrations that are no longer required, preventing stale entries from persisting in the collection.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| callbackKey | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the integer key (callbackKey) that identifies the callback entry to be removed.
- Step 2 - Check whether an entry with the supplied key exists in the m_callbacks collection.
- Step 3 - If the entry exists, delete it from the m_callbacks collection using the provided key.
- Step 4 - If the entry does not exist, take no action and return silently.

---
**Decision Points**

DP-001

Condition:
Does an entry with the value of callbackKey exist in the m_callbacks collection (m_callbacks.exists(callbackKey))?

TRUE:
Delete the entry identified by callbackKey from the m_callbacks collection (m_callbacks.delete(callbackKey)).

FALSE:
No action is taken; the procedure exits without modifying the collection.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure only removes a callback entry if it is confirmed to exist in the m_callbacks collection; no error is raised for a non-existent key.
- BR-002 - Deletion is performed by key, ensuring that only the specific callback registration identified by callbackKey is removed and no other entries are affected.
- BR-003 - The procedure has no output parameters and no database interactions; its sole effect is the in-memory removal of the specified callback entry from the collection.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ClearCallbackTrigger(callbackKey in PLS_INTEGER) is
  begin
    if m_callbacks.exists(callbackKey) then 
      m_callbacks.delete(callbackKey);  
    end if;
  end ClearCallbackTrigger;
```

#### SP-019 - WEBUTIL.CLOSEBLOB

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open BLOB handle identified by its checksum value. The procedure delegates the close operation entirely to the WebUtil_DB package, ensuring that BLOB resources previously opened within a WebUtil database session are properly released.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| checksum | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the checksum (PLS_INTEGER) that uniquely identifies the open BLOB handle to be closed.
- Step 2 - Delegate the close operation to WebUtil_DB.CloseBlob, passing the checksum as the sole argument.
- Step 3 - Return the BOOLEAN result produced by WebUtil_DB.CloseBlob to the caller, indicating whether the BLOB was successfully closed.

---
**Decision Points**

No decision points exist within this function. All conditional logic is encapsulated inside WebUtil_DB.CloseBlob; this function acts solely as a pass-through wrapper and returns whatever Boolean value that subordinate call produces.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The checksum parameter must correspond to a BLOB handle that was previously opened within the WebUtil database context; the validity of the checksum is enforced by WebUtil_DB.CloseBlob.
- BR-002 - The function must return a BOOLEAN result to the caller; a TRUE value indicates the BLOB was closed successfully, and FALSE indicates the close operation failed, as determined by WebUtil_DB.CloseBlob.
- BR-003 - No direct database interactions are performed by this function; all resource-release logic is wholly owned by WebUtil_DB.CloseBlob, keeping this layer a thin delegation wrapper.

---
**Implementation Logic**

```plsql

  FUNCTION  CloseBlob(checksum in PLS_INTEGER) return BOOLEAN is
  BEGIN
    return WebUtil_DB.CloseBlob(checksum);
  END CloseBlob;
```

#### SP-020 - WEBUTIL.CLOSEFILE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open server-side file represented by the supplied Java object handle. The procedure delegates the physical close operation to the AppServerFileReader Java class via a JNI boolean method call, returning a flag that indicates whether the file was successfully closed. It is invoked as a supporting step within WEBUTIL.SETDATA to release file resources after data transfer activity is complete.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java object handle (obj) that references the currently open AppServerFileReader instance on the application server.
- Step 2 - Clear the JNI argument list by setting args to NULL, ensuring no stale arguments are passed to the Java method.
- Step 3 - Invoke the closeFile() method on the AppServerFileReader Java class through JNI.CALL_BOOLEAN_METHOD, passing the object handle and the method signature '()Z'.
- Step 4 - Return the BOOLEAN result produced by the JNI call to the caller (WEBUTIL.SETDATA), indicating success or failure of the close operation.

---
**Decision Points**

DP-001

Condition: The JNI call to AppServerFileReader.closeFile() returns TRUE or FALSE.

TRUE: The file was closed successfully on the application server; the BOOLEAN TRUE value is returned to the calling routine WEBUTIL.SETDATA.

FALSE: The file close operation failed on the application server; the BOOLEAN FALSE value is returned to the calling routine WEBUTIL.SETDATA, signalling that the resource may not have been released.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The JNI argument list (args) must be explicitly reset to NULL before invoking the Java method to prevent unintended argument values from being passed to AppServerFileReader.closeFile().
- BR-002 - The close operation is executed against the oracle/forms/webutil/fileTransfer/AppServerFileReader Java class using the exact method signature '()Z'; any deviation would result in a failed JNI dispatch.
- BR-003 - The function must return the raw BOOLEAN result of the JNI call without modification, preserving the true success/failure status for the calling routine WEBUTIL.SETDATA to act upon.

---
**Implementation Logic**

```plsql
  FUNCTION closeFile(
    obj   ORA_JAVA.JOBJECT) RETURN BOOLEAN IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_BOOLEAN_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'closeFile', '()Z', args); 
  END;
```

#### SP-021 - WEBUTIL.DOWNLOADFROMURL

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.URL_TO_CLIENT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a simplified public entry point for downloading a file from a specified URL to a client-side destination. The procedure delegates all processing to the internal implementation routine WEBUTIL.DOWNLOADFROMURLINT (SP-022), passing fixed default values for parameters that are not relevant to the basic download use case. It returns a BOOLEAN indicating whether the download succeeded.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| fileSize | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.DOWNLOADFROMURLINT ([SP-022](#SP-022--WEBUTIL.DOWNLOADFROMURLINT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the source URL, the client-side destination path, and an optional file size (defaulting to 0 if not supplied by the caller).
- Step 2 - Invoke the internal delegate function WEBUTIL.DOWNLOADFROMURLINT (SP-022), forwarding the source URL and client destination unchanged, passing a hard-coded offset of 0, the supplied file size, a hard-coded resume flag of FALSE, and NULL values for the three remaining internal parameters (username, password, and proxy or equivalent optional arguments).
- Step 3 - Return the BOOLEAN result produced by WEBUTIL.DOWNLOADFROMURLINT directly to the caller (WEBUTIL.URL_TO_CLIENT).

---
**Decision Points**

No conditional decision points exist within this function. All branching logic is fully delegated to WEBUTIL.DOWNLOADFROMURLINT (SP-022); this wrapper passes fixed values and returns the delegate's result without any independent conditional evaluation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file size parameter is optional; when not provided by the caller it defaults to 0, which is passed as-is to WEBUTIL.DOWNLOADFROMURLINT.
- BR-002 - The byte offset passed to WEBUTIL.DOWNLOADFROMURLINT is always 0, meaning downloads initiated through this public wrapper always begin from the start of the remote resource.
- BR-003 - The resume flag passed to WEBUTIL.DOWNLOADFROMURLINT is always FALSE, meaning partial-download resumption is not supported through this public interface.
- BR-004 - Authentication and proxy credentials are always passed as NULL to WEBUTIL.DOWNLOADFROMURLINT, meaning this public wrapper supports only unauthenticated, non-proxied URL downloads.
- BR-005 - The success or failure of the download operation is communicated solely through the returned BOOLEAN value; no output parameters or exceptions are raised at this wrapper level.

---
**Implementation Logic**

```plsql
  
  FUNCTION DownLoadFromURL(sourceURL         in VARCHAR2, 
                           clientDestination in VARCHAR2, 
                           fileSize          in PLS_INTEGER default 0) return BOOLEAN is
  BEGIN
    return DownLoadFromURLInt(sourceURL,
                              ClientDestination,
                              0,
                              fileSize,
                              false,
                              null,
                              null,
                              null);
  END DownLoadFromURL;
```

#### SP-022 - WEBUTIL.DOWNLOADFROMURLINT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.DOWNLOADFROMURL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Performs the internal download of a file from a specified URL to a client-side destination by constructing a delimited parameter string and dispatching it to the WebUtil Core bean via a property-based request/response mechanism. Returns TRUE if the download succeeds, FALSE otherwise. This function is the low-level implementation called by WEBUTIL.CHECKLIBS and WEBUTIL.DOWNLOADFROMURL.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| specialDestination | PLS_INTEGER | IN |
| fileSize | PLS_INTEGER | IN |
| withProgress | BOOLEAN | IN |
| progressTitle | VARCHAR2 | IN |
| progressSubTitle | VARCHAR2 | IN |
| progressMessage | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Validate that sourceURL is not null; if null, raise the URL_NULL exception.
- Step 2 - Validate that clientDestination is not null; if null, raise the CLIENT_FILE_NULL exception.
- Step 3 - Evaluate specialDestination: if null, negative, or greater than 2, append '0' to the submit string; otherwise append its numeric value. Append the pipe separator after the value.
- Step 4 - Evaluate fileSize: if null, append '0' to the submit string; otherwise append its numeric value. Append the pipe separator.
- Step 5 - Evaluate withProgress: if null or FALSE, append 'N' to the submit string; if TRUE, append 'Y'. Append the pipe separator.
- Step 6 - Append sourceURL, clientDestination, progressTitle (defaulting to a single space if null), progressSubTitle (defaulting to a single space if null), and progressMessage (defaulting to a single space if null) to the submit string, each separated by the pipe delimiter.
- Step 7 - Send the fully constructed submit string to the WebUtil Core bean by calling WebUtil_Core.setProperty with the WUC_URL_DOWNLOAD property key.
- Step 8 - Retrieve the result from the WebUtil Core bean by calling WebUtil_Core.getProperty with the same WUC_URL_DOWNLOAD property key.
- Step 9 - Return TRUE if the retrieved result equals the string 'TRUE', otherwise return FALSE.
- Step 10 - On CLIENT_FILE_NULL exception, log error code 130 via WebUtil_Core.Error and return FALSE.
- Step 11 - On URL_NULL exception, log error code 25 via WebUtil_Core.Error and return FALSE.
- Step 12 - On BEAN_NOT_REGISTERED exception, raise an error alert identifying the missing implementation class and raise FORM_TRIGGER_FAILURE.
- Step 13 - On PROPERTY_ERROR exception, raise FORM_TRIGGER_FAILURE.

---
**Decision Points**

DP-001

Condition:
sourceURL IS NULL

TRUE:
Raise the URL_NULL exception, which is handled to log error code 25 and return FALSE.

FALSE:
Continue processing.

---

DP-002

Condition:
clientDestination IS NULL

TRUE:
Raise the CLIENT_FILE_NULL exception, which is handled to log error code 130 and return FALSE.

FALSE:
Continue processing.

---

DP-003

Condition:
specialDestination IS NULL OR specialDestination < 0 OR specialDestination > 2

TRUE:
Append '0' (the default/safe value) to the submit string.

FALSE:
Append the actual numeric value of specialDestination to the submit string.

---

DP-004

Condition:
fileSize IS NULL

TRUE:
Append '0' to the submit string.

FALSE:
Append the actual numeric value of fileSize to the submit string.

---

DP-005

Condition:
withProgress IS NULL OR withProgress = FALSE

TRUE:
Append 'N' (no progress indicator) to the submit string.

FALSE:
Append 'Y' (show progress indicator) to the submit string.

---

DP-006

Condition:
Result string returned by WebUtil_Core.getProperty equals 'TRUE'

TRUE:
Return TRUE, indicating the download completed successfully.

FALSE:
Return FALSE, indicating the download did not complete successfully.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A non-null source URL is mandatory; the download will not proceed and the function returns FALSE if sourceURL is null.
- BR-002 - A non-null client destination path is mandatory; the download will not proceed and the function returns FALSE if clientDestination is null.
- BR-003 - The specialDestination value must be in the range 0-2 inclusive; any null, negative, or out-of-range value is normalised to 0 before being submitted to the bean.
- BR-004 - A null fileSize is normalised to 0 before being submitted to the bean.
- BR-005 - Progress display is disabled by default; withProgress must be explicitly TRUE to enable the progress indicator ('Y'); null is treated as FALSE.
- BR-006 - Null progress label parameters (progressTitle, progressSubTitle, progressMessage) are substituted with a single space character to preserve the pipe-delimited string structure.
- BR-007 - All download parameters are serialised into a single pipe-delimited string and communicated to the client-side WebUtil Core bean via WebUtil_Core.setProperty / WebUtil_Core.getProperty; no direct database interaction is performed.
- BR-008 - If the WebUtil Core bean is not registered on the client, the function raises FORM_TRIGGER_FAILURE, halting form processing rather than silently returning FALSE.
- BR-009 - A PROPERTY_ERROR raised during bean communication also results in FORM_TRIGGER_FAILURE, preventing silent failure.

---
**Implementation Logic**

```plsql
  
  FUNCTION DownLoadFromURLInt(sourceURL          in VARCHAR2, 
                              clientDestination  in VARCHAR2, 
                              specialDestination in PLS_INTEGER default 0,                             
                              fileSize           in PLS_INTEGER default 0, 
                              withProgress       in BOOLEAN default false,
                              progressTitle      in VARCHAR2 default null,
                              progressSubTitle   in VARCHAR2 default null,
                              progressMessage    in VARCHAR2 default null) return BOOLEAN is
    result       VARCHAR2(6) := 'FALSE';
    submitString VARCHAR2(4000 char);
    sep          VARCHAR2(1) := '|';
  BEGIN
    if sourceURL is null then
      raise URL_NULL;
    end if;
    if clientDestination is null then
      raise CLIENT_FILE_NULL;
    end if;

    if specialDestination is null or specialDestination < 0 or specialDestination > 2 then 
      submitString := '0'||sep;
    else
      submitString := to_char(specialDestination)||sep;
    end if;
    if fileSize is null then 
      submitString := submitString||'0'||sep;
    else
      submitString := submitString||to_char(fileSize)||sep;
    end if;
    if withProgress is null or not withProgress then 
      submitString := submitString||'N'||sep;
    else
      submitString := submitString||'Y'||sep;
    end if;    

    submitString := submitString||sourceURL
                    ||sep||clientDestination
                    ||sep||nvl(progressTitle,' ')
                    ||sep||nvl(progressSubTitle,' ')
                    ||sep||nvl(progressMessage,' ');                         
  WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_URL_DOWNLOAD',submitString,true);
  result := WebUtil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_URL_DOWNLOAD');
  return (result='TRUE');
  EXCEPTION  
    when CLIENT_FILE_NULL then
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE, 130, 'WEBUTIL_CORE.DownloadFromURLInt');
      return false;
    when URL_NULL then
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE,25, 'WEBUTIL_CORE.DownloadFromURLInt');
      return false;

    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                              ||' bean not found. WEBUTIL_CORE.DownloadFromURLInt will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;
  END DownLoadFromURLInt;
```

#### SP-023 - WEBUTIL.ERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Formats a structured error message string from a numeric error code, a program-unit name, and up to three optional argument values, then writes that string to the WebUtil core property 'WUC_ERROR_MSG' for the given package session. This allows the calling context (WEBUTIL_CORE.CUSTOMEVENTHANDLER) to retrieve and propagate a consistently formatted error notification back to the Oracle Forms client.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |
| code | PLS_INTEGER | IN |
| pu_name | VARCHAR2 | IN |
| arg1 | VARCHAR2 | IN |
| arg2 | VARCHAR2 | IN |
| arg3 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the package session identifier (packageID), a numeric error code (code), the originating program-unit name (pu_name), and up to three optional supplementary arguments (arg1, arg2, arg3).
- Step 2 - Initialise the error text string by concatenating the literal prefix 'ERROR', the error code zero-padded to three digits (e.g., code 7 becomes '007'), a pipe delimiter, and the program-unit name (e.g., 'ERROR007|MyPackage.Proc').
- Step 3 - Evaluate whether arg1 is non-null; if so, append a pipe delimiter and the value of arg1 to the error text string.
- Step 4 - Evaluate whether arg2 is non-null; if so, append a pipe delimiter and the value of arg2 to the error text string.
- Step 5 - Evaluate whether arg3 is non-null; if so, append a pipe delimiter and the value of arg3 to the error text string.
- Step 6 - Write the fully constructed error text string to the WebUtil core property 'WUC_ERROR_MSG' for the specified package session by calling Webutil_Core.setProperty.

---
**Decision Points**

DP-001

Condition:
arg1 IS NOT NULL

TRUE:
Append a pipe delimiter followed by the value of arg1 to the error text string.

FALSE:
Skip; arg1 is not included in the error text string.

---

DP-002

Condition:
arg2 IS NOT NULL

TRUE:
Append a pipe delimiter followed by the value of arg2 to the error text string.

FALSE:
Skip; arg2 is not included in the error text string.

---

DP-003

Condition:
arg3 IS NOT NULL

TRUE:
Append a pipe delimiter followed by the value of arg3 to the error text string.

FALSE:
Skip; arg3 is not included in the error text string.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The error message string must always begin with the literal prefix 'ERROR' followed immediately by the numeric code zero-padded to exactly three digits, ensuring a fixed-width, parseable token (e.g., 'ERROR007').
- BR-002 - The error code token and each subsequent field (program-unit name and any supplied arguments) must be separated by a pipe character ('|'), producing a pipe-delimited message that downstream consumers can reliably parse.
- BR-003 - Optional arguments (arg1, arg2, arg3) default to NULL and are included in the error text only when a non-null value is supplied; their relative order in the message must be preserved (arg1 before arg2 before arg3).
- BR-004 - The fully constructed error message must be stored against the property key 'WUC_ERROR_MSG' for the specified package session via Webutil_Core.setProperty, making it available to the invoking WEBUTIL_CORE.CUSTOMEVENTHANDLER for client-side error reporting.
- BR-005 - The maximum length of the constructed error text string is bounded at 1 024 characters (VARCHAR2(1024)); inputs that would cause the concatenated result to exceed this limit will result in a runtime error.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Error(packageID in PLS_INTEGER,
                  code      in PLS_INTEGER,
                  pu_name   in VARCHAR2,
                  arg1      in VARCHAR2 :=null,
                  arg2      in VARCHAR2 := null,
                  arg3      in VARCHAR2 := null
                 ) is
    errText varchar2(1024);
  begin 
    errText := 'ERROR'||lpad(to_char(code),3,'0') || '|' || pu_name;
    if arg1 is not null then
      errText := errText || '|' || arg1;
    end if;
    if arg2 is not null then
      errText := errText || '|' || arg2;
    end if;
    if arg3 is not null then
      errText := errText || '|' || arg3;
    end if;
    Webutil_Core.setProperty(packageID, 'WUC_ERROR_MSG', errText);
  end Error;
```

#### SP-024 - WEBUTIL.ERRORALERT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]
- webutil.pld [StoredProcedure: WEBUTIL.LOG]
- webutil.pld [StoredProcedure: WEBUTIL.POPULATEPROPERTYBUNDLE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Displays a WebUtil error message to the user via a pre-registered alert dialog or, when no alert object is available, via the Forms MESSAGE built-in. It is called by FCLOSE, LOG, and POPULATEPROPERTYBUNDLE to surface bean-registration failures and other WebUtil runtime errors in a consistent, user-visible manner.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| errText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-046](#SP-046--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the error text string (errText) that describes the WebUtil runtime error to be reported.
- Step 2 - Call WEBUTIL.ID_NULL (SP-046) to test whether the module-level alert handle m_errorAlert refers to a valid, registered Forms alert object.
- Step 3 - If m_errorAlert is valid (not null), set the alert's message text property to errText using SET_ALERT_PROPERTY with the ALERT_MESSAGE_TEXT attribute.
- Step 4 - Display the configured alert to the user by calling SHOW_ALERT; the return value is captured in the local variable 'ignore' and discarded, as no branching on the user's response is required.
- Step 5 - If m_errorAlert is not valid (null / unregistered), fall back to the Forms MESSAGE built-in, prepending the literal prefix 'WebUtil Error: ' to errText so the user still receives a meaningful notification.

---
**Decision Points**

DP-001

Condition:
ID_NULL(m_errorAlert) returns FALSE - i.e., the module-level alert handle m_errorAlert is a valid, registered Forms alert object.

TRUE:
Set the alert's ALERT_MESSAGE_TEXT property to errText and display it via SHOW_ALERT; the user sees a modal alert dialog titled with the pre-configured alert title.

FALSE:
The alert handle is null or unregistered; fall back to the Forms MESSAGE built-in, outputting 'WebUtil Error: ' concatenated with errText directly to the Forms status line.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must always surface the error to the user; no error condition may be silently swallowed, regardless of whether the alert object is registered.
- BR-002 - When a valid alert handle exists, the error text is delivered exclusively through the alert's ALERT_MESSAGE_TEXT property; the alert title is not overridden at runtime because it is already configured in the alert's design-time properties.
- BR-003 - The user's response to the alert (button clicked) is intentionally ignored; ERRORALERT is a notification-only mechanism and does not branch on the acknowledgement.
- BR-004 - The fallback MESSAGE output must prefix the error text with 'WebUtil Error: ' to maintain consistent error identification when the alert object is unavailable.
- BR-005 - Determination of alert-handle validity is delegated entirely to WEBUTIL.ID_NULL (SP-046); ERRORALERT must not attempt its own null-check logic.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ErrorAlert(errText in VARCHAR2) is
    -- currently used for throwing a BEAN_NOT_REGISTERED or bean not found error.
    ignore integer;
  begin
    if not ID_NULL(m_errorAlert) then 
      --SET_ALERT_PROPERTY(m_errorAlert,TITLE,'WebUtil Error'); -- title already set in alert property
      SET_ALERT_PROPERTY(m_errorAlert,ALERT_MESSAGE_TEXT,errText);
      ignore := SHOW_ALERT(m_errorAlert);
    else
      message('WebUtil Error'||': '||errText);
    end if;
  end ErrorAlert;
```

#### SP-025 - WEBUTIL.EXECUTE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.BLOCKING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Submits an operating-system command for execution on the client machine by delegating to the WebUtil host bean. The procedure sets the desired execution mode, passes the command string to the underlying WebUtil Core host package handler, and returns a process handle that the caller can use to track or interact with the spawned process. If the required WebUtil bean is not registered on the client, an error alert is raised and no process is launched.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |
| exemode | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the command string (cmd) and the execution mode flag (exemode) as input parameters.
- Step 2 - Check whether cmd is not null; if null, skip all processing and return an uninitialised PROCESS_ID to the caller.
- Step 3 - Set the execution mode on the WebUtil Core host package handler by calling WebUtil_Core.setProperty with property key WUH_EXECUTION_MODE and the supplied exemode value.
- Step 4 - Submit the command for execution by calling WebUtil_Core.setProperty with property key WUH_EXECUTE and the supplied cmd value.
- Step 5 - Retrieve the process handle assigned by the bean by calling WebUtil_Core.getProperty with property key WUH_EXECUTE, convert the returned value to a number, and store it in the local PROCESS_ID variable procId.
- Step 6 - Return procId (containing the numeric process handle) to the caller.
- Step 7 - If a BEAN_NOT_REGISTERED exception is raised at any point, display an error alert identifying the missing implementation class and indicating that WEBUTIL_HOST.Execute will not function; no process handle is returned.

---
**Decision Points**

DP-001

Condition:
cmd IS NOT NULL

TRUE:
Set the execution mode via WebUtil_Core.setProperty, submit the command via WebUtil_Core.setProperty, retrieve the resulting process handle via WebUtil_Core.getProperty, and return the populated PROCESS_ID.

FALSE:
Skip all WebUtil Core interactions and return an uninitialised PROCESS_ID to the caller.

---

DP-002

Condition:
WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during WebUtil Core property calls

TRUE:
Call WebUtil_Core.ErrorAlert to display a message identifying the missing bean class and stating that WEBUTIL_HOST.Execute will not work; execution of the function terminates without returning a valid process handle.

FALSE:
Normal processing continues; a valid PROCESS_ID is returned to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A null command string is treated as a no-operation; the function returns an uninitialised PROCESS_ID without attempting to contact the WebUtil host bean, preventing execution of an empty or undefined command.
- BR-002 - The execution mode (exemode) must be supplied by the caller and is applied to the WebUtil host package handler before the command is submitted; this ensures the bean honours the intended synchronous or asynchronous execution behaviour.
- BR-003 - The WebUtil host bean (WUH_PACKAGE) must be registered on the client at the time of invocation; if it is not, the BEAN_NOT_REGISTERED exception handler surfaces a descriptive error alert and the function does not return a usable process handle.
- BR-004 - The process handle returned to the caller is derived exclusively from the value retrieved via WebUtil_Core.getProperty after the command is set; no alternative handle-generation mechanism is used.

---
**Implementation Logic**

```plsql
  FUNCTION Execute (cmd in VARCHAR2, exemode in PLS_INTEGER) return PROCESS_ID is
    procId PROCESS_ID;
  begin 
    if cmd is not null then 
      WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTION_MODE',exemode);            
      WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTE',cmd);      
      procId.handle := to_number(WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTE'));
    end if;
    return procId;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.Execute will not work');
  end Execute;
```

#### SP-026 - WEBUTIL.FCLOSE

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open client-side text file that was previously opened through the WebUtil file I/O framework. The procedure nullifies the file handle after issuing the close command to the WebUtil bean, and raises a fatal tool error if the underlying bean is unavailable or if the close operation fails.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-024](#SP-024--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETIMPLCLASS ([SP-033](#SP-033--WEBUTIL.GETIMPLCLASS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Check whether the supplied file handle is non-NULL; if it is NULL the file is already closed and no action is taken.
- Step 2 - Invoke WebUtil_Core.setProperty with the WUF_PACKAGE identifier and the WUF_TEXTIO_CLOSE command, passing the current file handle to instruct the WebUtil bean to close the physical file on the client.
- Step 3 - Set the file handle to NULL, marking the FILE_TYPE record as closed so that subsequent operations cannot reuse a stale handle.
- Step 4 - If a BEAN_NOT_REGISTERED exception is raised during the close attempt, call WEBUTIL.ERRORALERT (via WebUtil_Core.ErrorAlert) to display a descriptive message that identifies the implementation class returned by WEBUTIL.GETIMPLCLASS (via WebUtil_Core.getImplClass) and states that CLIENT_TEXT_IO.fclose will not work.
- Step 5 - After displaying the alert for a BEAN_NOT_REGISTERED condition, raise TOOL_ERR.TOOL_ERROR to abort the calling process.
- Step 6 - If a PROPERTY_ERROR exception is raised, raise TOOL_ERR.TOOL_ERROR immediately without displaying an alert, propagating the failure to the caller.

---
**Decision Points**

DP-001

Condition:
file.handle IS NOT NULL

TRUE:
Proceed to issue the WebUtil close command (WebUtil_Core.setProperty) and then null the handle.

FALSE:
Skip all processing; the procedure exits without error because the file is already closed.

---

DP-002

Condition:
WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during the close operation.

TRUE:
Call WEBUTIL.ERRORALERT to display a message that includes the implementation class name retrieved via WEBUTIL.GETIMPLCLASS, then raise TOOL_ERR.TOOL_ERROR to halt execution.

FALSE:
Exception is not raised; normal processing continues.

---

DP-003

Condition:
WebUtil_Core.PROPERTY_ERROR exception is raised during the close operation.

TRUE:
Raise TOOL_ERR.TOOL_ERROR immediately to halt execution; no user-facing alert is shown.

FALSE:
Exception is not raised; normal processing continues.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A file with a NULL handle is treated as already closed; the procedure must not attempt to close it or raise an error in this state.
- BR-002 - Once the WebUtil bean successfully closes the physical file, the in-memory file handle must be set to NULL to prevent reuse of a stale reference.
- BR-003 - If the WebUtil bean required to perform the close operation is not registered, the user must be notified via WEBUTIL.ERRORALERT with a message that includes the bean's implementation class name as returned by WEBUTIL.GETIMPLCLASS, before the error is escalated.
- BR-004 - Both a missing bean (BEAN_NOT_REGISTERED) and a property operation failure (PROPERTY_ERROR) are unrecoverable conditions that must terminate the calling process by raising TOOL_ERR.TOOL_ERROR.
- BR-005 - No database interactions are performed; this procedure operates exclusively on client-side file resources through the WebUtil bean framework.

---
**Implementation Logic**

```plsql
 
  PROCEDURE fclose (file IN OUT file_type) is 
  BEGIN 
    if (file.handle IS NOT NULL) then 
      WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CLOSE',file.handle);        
      file.handle := NULL;
    end if;
 
 EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.fclose will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;
  END fclose;
```

#### SP-027 - WEBUTIL.FILE_SAVE_DIALOG

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Presents the client-side operating-system Save File dialog to the end user, allowing them to choose a target directory and file name when saving a file (e.g., an Excel report) from the Oracle Forms application. It acts as a thin, save-specific wrapper that delegates to the internal file-selection dialog routine with the appropriate mode and flags pre-configured.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| directory_name | Varchar2 | IN |
| file_name | Varchar2 | IN |
| file_filter | Varchar2 | IN |
| title | Varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- D2KWUTIL.SAVE_FILE ([SP-011](#SP-011--D2KWUTIL.SAVE_FILE)) - D2KWUTIL.pck (or .pld)
- WEBUTIL.FILE_SELECTION_DIALOG_INT ([SP-028](#SP-028--WEBUTIL.FILE_SELECTION_DIALOG_INT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the optional input parameters: default directory path (directory_name), default file name (file_name), file type filter (file_filter), and dialog window title (title).
- Step 2 - Invoke WEBUTIL.FILE_SELECTION_DIALOG_INT (SP-028), passing all four caller-supplied parameters together with three hard-coded arguments: the D2KWUTIL.SAVE_FILE constant (SP-011) to set the dialog mode to 'Save', TRUE to indicate that a file name must be returned, and FALSE to suppress multi-selection.
- Step 3 - Return the fully qualified file path string produced by FILE_SELECTION_DIALOG_INT to the calling routine (VIEW_EXCEL_REPORT_NEW in dms_excel_report.pld).

---
**Decision Points**

No conditional branching exists within FILE_SAVE_DIALOG itself. All decision logic is delegated to WEBUTIL.FILE_SELECTION_DIALOG_INT (SP-028). The function passes fixed flag values (SAVE_FILE mode = TRUE, multi-select = FALSE) unconditionally on every invocation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The dialog must always operate in Save mode; the D2KWUTIL.SAVE_FILE constant (SP-011) is passed as the mode argument and is not overridable by the caller.
- BR-002 - Multi-file selection is explicitly disabled (FALSE); the user may select only one target file per invocation.
- BR-003 - All four input parameters (directory_name, file_name, file_filter, title) are optional (default NULL); callers may omit any or all of them, and the underlying dialog will apply its own defaults.
- BR-004 - The function returns the user-selected file path as a VARCHAR2 string; the calling routine (VIEW_EXCEL_REPORT_NEW) is responsible for handling a NULL or empty return value (e.g., when the user cancels the dialog).

---
**Implementation Logic**

```plsql
                                        
  FUNCTION FILE_SAVE_DIALOG(            directory_name Varchar2 := NULL,
                                        file_name      Varchar2 := NULL,
                                        file_filter    Varchar2 := NULL,
                                        title          Varchar2 := NULL) return Varchar2 is
  BEGIN
    RETURN FILE_SELECTION_DIALOG_INT(   directory_name,
                                        file_name,
                                        file_filter,
                                        title,
                                        SAVE_FILE,
                                        TRUE,
                                        FALSE); 
  END FILE_SAVE_DIALOG;
```

#### SP-028 - WEBUTIL.FILE_SELECTION_DIALOG_INT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FILE_SAVE_DIALOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Presents a native file-selection dialog to the end user by communicating with the WebUtil client-side bean, then returns the user-selected path as a VARCHAR2 string. The dialog behaviour (Save File, Open Directory, or Open File) is determined at runtime by the dialog_type and select_file input parameters. The function also normalises backslash sequences in the returned path to ensure consistent path formatting across operating systems.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| directory_name | Varchar2 | IN |
| file_name | Varchar2 | IN |
| file_filter | Varchar2 | IN |
| title | Varchar2 | IN |
| dialog_type | Number | IN |
| select_file | Boolean | IN |
| multiselect | Boolean | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- D2KWUTIL.SAVE_FILE ([SP-011](#SP-011--D2KWUTIL.SAVE_FILE)) - D2KWUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Transmit dialog configuration to the WebUtil bean by calling WebUtil_Core.setProperty for each input parameter: directory_name (WUF_GFN_DIRNAME), file_name (WUF_FILENAME), file_filter (WUF_FILTER), title (WUF_GFN_MESSAGE), and multiselect flag (WUF_GFN_MULTISELECT).
- Step 2 - Evaluate dialog_type against the SAVE_FILE constant. If equal, invoke WebUtil_Core.getProperty for WUF_GFN_SAVEFILE to display a Save File dialog and capture the result.
- Step 3 - If dialog_type is not SAVE_FILE, evaluate the select_file flag. If FALSE, invoke WebUtil_Core.getProperty for WUF_GFN_OPENDIR to display an Open Directory dialog and capture the result.
- Step 4 - If dialog_type is not SAVE_FILE and select_file is TRUE, invoke WebUtil_Core.getProperty for WUF_GFN_OPENFILE to display an Open File dialog and capture the result.
- Step 5 - Inspect the returned path string for a leading double-backslash ('\\') using INSTR. If the string starts at position 1 with '\\', prepend an additional '\\' to preserve UNC path notation before normalisation.
- Step 6 - Apply a global REPLACE on the result to convert every double-backslash ('\\') to a single backslash ('\'), yielding a clean, normalised file path.
- Step 7 - Return the normalised path string to the caller (WEBUTIL.FILE_SAVE_DIALOG).
- Step 8 - If the WebUtil bean is not registered (BEAN_NOT_REGISTERED exception), display an error alert identifying the missing bean class and raise FORM_TRIGGER_FAILURE to abort processing.
- Step 9 - If a property communication error occurs (PROPERTY_ERROR exception), raise FORM_TRIGGER_FAILURE to abort processing.

---
**Decision Points**

DP-001

Condition:
dialog_type = SAVE_FILE

TRUE:
Call WebUtil_Core.getProperty with WUF_GFN_SAVEFILE to present a Save File dialog and store the returned path in result.

FALSE:
Proceed to evaluate the select_file flag (DP-002).

---

DP-002

Condition:
select_file = FALSE (and dialog_type ≠ SAVE_FILE)

TRUE:
Call WebUtil_Core.getProperty with WUF_GFN_OPENDIR to present an Open Directory dialog and store the returned path in result.

FALSE:
Call WebUtil_Core.getProperty with WUF_GFN_OPENFILE to present an Open File dialog and store the returned path in result.

---

DP-003

Condition:
INSTR(result, '\\\\') = 1 (the returned path begins with a double-backslash, indicating a UNC path)

TRUE:
Prepend '\\\\' to result before executing the backslash normalisation replace, preserving the UNC prefix.

FALSE:
Proceed directly to backslash normalisation without modification.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - All five dialog configuration properties (directory, filename, filter, title, multiselect) must be set on the WebUtil bean before the dialog is invoked; no dialog variant may be launched with uninitialised properties.
- BR-002 - The dialog mode is determined exclusively by the combination of dialog_type and select_file: SAVE_FILE takes precedence; when dialog_type is not SAVE_FILE, select_file = FALSE routes to directory selection and select_file = TRUE routes to file selection.
- BR-003 - The returned file path must be normalised by replacing all double-backslash sequences ('\\\\') with single backslashes ('\') to ensure a consistent path format regardless of the JFileChooser escape behaviour on the client.
- BR-004 - UNC paths (those beginning with '\\\\') must have an additional '\\\\' prepended prior to normalisation so that the leading double-backslash is preserved after the replace operation.
- BR-005 - If the required WebUtil bean is not registered on the client, the function must display a descriptive error alert identifying the missing bean class and then raise FORM_TRIGGER_FAILURE; silent failure is not permitted.
- BR-006 - Any property communication error (PROPERTY_ERROR) must cause immediate termination of the form trigger via FORM_TRIGGER_FAILURE without further processing.

---
**Implementation Logic**

```plsql
  FUNCTION FILE_SELECTION_DIALOG_INT(   directory_name Varchar2,
                                        file_name      Varchar2,
                                        file_filter    Varchar2,
                                        title          Varchar2,
                                        dialog_type    Number,
                                        select_file    Boolean,
                                        multiselect    Boolean) return Varchar2 is
    result varchar2(4000);     
    pos Number;
  BEGIN  
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_DIRNAME', directory_name);
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILENAME',file_name, true);     
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILTER',  file_filter); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_MESSAGE', title); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_MULTISELECT', multiselect,true);     
  
    if (dialog_type = SAVE_FILE) then 
        result := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_SAVEFILE');
    elsif (not select_file) then
        result := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_OPENDIR');
    else
        result := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_OPENFILE');
    end if;
  
    -- handle the situation which we can get with JFileChooser with escaped "\"

    -- if string starts with '\\', replace it with '\\\\', 
    -- before running the original replace statement.
    pos := instr(result, '\\');

    -- concat '\\' in the begining of the string before calling the replace.
    if (pos = 1) then
        result := concat('\\', result);
    end if;

    result := replace(result,'\\','\');
    return result;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. WEBUTIL_FILE.FILE_SELECTION_DIALOG_INT will not work');
      RAISE FORM_TRIGGER_FAILURE;  
   when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;  
  END FILE_SELECTION_DIALOG_INT;
```

#### SP-029 - WEBUTIL.FOPEN

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Opens a file on the client machine for text I/O by communicating with the WebUtil Java bean layer. The function validates the requested file mode and file path, transmits the open request to the client-side WebUtil bean via property calls (including WEBUTIL.GETPROPERTY), and returns a typed file handle that subsequent client text I/O operations can use. It is invoked as part of the Excel report generation flow in dms_excel_report.pld.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| spec | VARCHAR2 | IN |
| filemode | VARCHAR2 | IN |
| charSet | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETPROPERTY ([SP-039](#SP-039--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Validate that the supplied file mode (`filemode`) is one of the three accepted values: 'r' (read), 'w' (write), or 'a' (append), using a case-insensitive comparison. Raise TOOL_ERR.TOOL_ERROR immediately if the value is invalid.
- Step 2 - Validate that the file specification (`spec`) is neither NULL nor an empty string. Raise TOOL_ERR.TOOL_ERROR immediately if no file name has been provided.
- Step 3 - Push the file path to the WebUtil bean by setting the WUF_FILENAME property on the WUF_PACKAGE component via WebUtil_Core.setProperty.
- Step 4 - Push the file mode to the WebUtil bean by setting the WUF_TEXTIO_FILEMODE property.
- Step 5 - Evaluate the `charSet` parameter: if it is NULL, set the WUF_TEXTIO_CHARSET property to the literal string '(null)'; otherwise set it to the supplied character-set value.
- Step 6 - Invoke WEBUTIL.GETPROPERTY (via WebUtil_Core.getProperty) to request that the WebUtil bean open the file, retrieving the resulting Java file handle string from the WUF_TEXTIO_OPEN property.
- Step 7 - Validate the returned Java handle: if it is NULL, empty, or '-1', raise TOOL_ERR.TOOL_ERROR to signal that the file could not be opened.
- Step 8 - Convert the valid handle string to a number and assign it to the `handle` field of the local `file_type` record.
- Step 9 - Return the populated `file_type` record to the caller.
- Step 10 - Handle exceptions: if the WebUtil bean is not registered, display an error alert identifying the missing bean class and raise TOOL_ERR.TOOL_ERROR; propagate PROPERTY_ERROR, VALUE_ERROR (as TOOL_ERR.TOOL_ERROR), and TOOL_ERR.TOOL_ERROR directly to the caller.

---
**Decision Points**

DP-001

Condition:
Is `lower(filemode)` NOT one of 'r', 'w', or 'a'?

TRUE:
Raise TOOL_ERR.TOOL_ERROR immediately; processing does not continue.

FALSE:
Proceed to validate the file specification.

---

DP-002

Condition:
Is `spec` NULL or equal to an empty string?

TRUE:
Raise TOOL_ERR.TOOL_ERROR immediately; processing does not continue.

FALSE:
Proceed to set WebUtil bean properties.

---

DP-003

Condition:
Is the `charSet` parameter NULL?

TRUE:
Set the WUF_TEXTIO_CHARSET property to the literal string '(null)', instructing the bean to use its default character set.

FALSE:
Set the WUF_TEXTIO_CHARSET property to the caller-supplied character-set value.

---

DP-004

Condition:
Is the Java handle returned by WEBUTIL.GETPROPERTY (WUF_TEXTIO_OPEN) NULL, empty, or equal to '-1'?

TRUE:
Raise TOOL_ERR.TOOL_ERROR to indicate the file could not be opened on the client.

FALSE:
Convert the handle to a number, populate the file_type record, and return it to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file mode must be exactly one of 'r' (read), 'w' (write), or 'a' (append); the comparison is case-insensitive. Any other value is rejected with a hard error before any bean communication occurs.
- BR-002 - A non-null, non-empty file specification (path/name) is mandatory; the function will not attempt to open a file without one.
- BR-003 - When no character set is specified by the caller, the value '(null)' is explicitly passed to the WebUtil bean so that the bean applies its own default encoding, rather than leaving the property unset.
- BR-004 - The WebUtil bean must be registered and reachable; if the bean is not found (BEAN_NOT_REGISTERED), an informational alert is displayed identifying the missing implementation class before the error is propagated, ensuring the user receives a meaningful diagnostic message.
- BR-005 - A Java handle value of NULL, empty string, or '-1' is treated as a failed open attempt and results in TOOL_ERR.TOOL_ERROR; no partial or invalid file handle is returned to the caller.
- BR-006 - The function relies on WEBUTIL.GETPROPERTY to retrieve the file handle from the client-side bean; this dependency must be satisfied at runtime for the open operation to succeed.

---
**Implementation Logic**

```plsql
  FUNCTION fopen(spec VARCHAR2, filemode VARCHAR2, charSet VARCHAR2 := null) RETURN file_type is
    clientFile file_type;
    javaHandle VARCHAR2(6);
  BEGIN
    -- check the mode is valid
    if (lower(filemode) not in ('r','w','a')) then 
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- make sure a file name has been specified      
    if (spec is null) or (spec='') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;
      
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILENAME',spec, true);
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_FILEMODE',filemode, true);        
    if (charSet is null) then
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET','(null)', true);
    else
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET',charSet, true);
    end if;
    javaHandle := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_OPEN');

    -- If the return is null then the file was not opened      
    if (javaHandle is null) or (javaHandle='') or (javaHandle='-1') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- if we are this far convert the handle to the correct format and return it.      
    clientFile.handle := to_number(javaHandle);
    return clientFile;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.fopen will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                 
      return null;
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE;
    when VALUE_ERROR then
      RAISE TOOL_ERR.TOOL_ERROR; 
    when TOOL_ERR.TOOL_ERROR then 
      RAISE;
  END fopen;
```

#### SP-030 - WEBUTIL.GETCALLBACKTRIGGER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the name of a previously registered callback trigger associated with a given numeric key. The function provides a lookup mechanism into the internal callbacks collection, allowing the caller (WEBUTIL.SETDATA) to resolve which trigger string corresponds to a specific callback key.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| callbackKey | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the integer callback key supplied by the caller.
- Step 2 - Look up the callback key in the internal collection m_callbacks.
- Step 3 - Return the VARCHAR2 trigger name stored at that key position to the caller.

---
**Decision Points**

No conditional decision points exist in this function. The lookup and return are unconditional; no branching logic is present in the implementation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The supplied callbackKey must correspond to a valid, pre-existing entry in the m_callbacks collection; no default or fallback value is applied if the key is absent, meaning an invalid key will raise a standard PL/SQL collection error.
- BR-002 - The function returns exactly the VARCHAR2 value stored at the specified index in m_callbacks without transformation or validation of the returned trigger name.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetCallbackTrigger(callbackKey in PLS_INTEGER) return VARCHAR2 is 
  begin 
    return m_callbacks(callbackKey);
  end GetCallbackTrigger;
```

#### SP-031 - WEBUTIL.GETCLIENTOSFAMILY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the operating system family identifier of the client machine as a PLS_INTEGER value. This function exposes the internally held client OS family classification (stored in the module-level variable m_clientOSFamily) to callers, enabling other routines to determine the client platform context without directly accessing the internal state.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - The function is invoked by WEBUTIL.GETVAR (via webutil.pld) to retrieve the client OS family value.
- Step 2 - The function reads the module-level variable m_clientOSFamily, which holds the pre-populated client operating system family identifier.
- Step 3 - The function returns the integer value of m_clientOSFamily directly to the caller.

---
**Decision Points**

No decision points are present. The function unconditionally reads and returns the value of m_clientOSFamily without branching logic.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function returns a PLS_INTEGER value representing the client OS family; no transformation or validation is applied to the stored value before it is returned.
- BR-002 - The client OS family value is sourced exclusively from the module-level variable m_clientOSFamily; this function does not accept input parameters or perform any database or external lookups.
- BR-003 - The accuracy of the returned value depends entirely on m_clientOSFamily having been correctly populated prior to invocation; this function performs no initialisation or defaulting of that variable.

---
**Implementation Logic**

```plsql

  FUNCTION GetClientOSFamily return PLS_INTEGER is 
  begin 
    return m_clientOSFamily;
  end GetClientOSFamily;
```

#### SP-032 - WEBUTIL.GETCLIENTSETTING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a named client-side configuration property value from the WebUtil Core bean. Given a property name, the function delegates to WebUtil_Core to fetch the corresponding local property string and returns it to the caller. It is used by WEBUTIL.CHECKLIBS and WEBUTIL.REGISTERBEAN to inspect client environment settings at runtime.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameter propertyName (VARCHAR2).
- Step 2 - Evaluate whether propertyName is non-null; if null, skip retrieval and proceed directly to the return statement, returning NULL.
- Step 3 - If propertyName is non-null, invoke WebUtil_Core.setProperty targeting the WUC_PACKAGE component with the action key WUC_GET_LOCAL_PROPERTY and the supplied property name, instructing the WebUtil Core bean to prepare the requested property value.
- Step 4 - Invoke WebUtil_Core.getProperty targeting the same WUC_PACKAGE component and action key WUC_GET_LOCAL_PROPERTY to retrieve the property value resolved by the bean, storing it in the local variable result (VARCHAR2 255 characters).
- Step 5 - Return the result value to the caller.
- Step 6 - If a WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during Steps 3-4, display an error alert identifying the missing bean class and raise FORM_TRIGGER_FAILURE to halt form processing.
- Step 7 - If a WebUtil_Core.PROPERTY_ERROR exception is raised during Steps 3-4, raise FORM_TRIGGER_FAILURE to halt form processing without an additional alert.

---
**Decision Points**

DP-001

Condition: propertyName IS NOT NULL

TRUE: Proceed to call WebUtil_Core.setProperty and WebUtil_Core.getProperty to retrieve the client-side property value and assign it to result.

FALSE: Skip the retrieval block entirely; result remains NULL and is returned as-is.

DP-002

Condition: WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during property retrieval.

TRUE: Display an error alert concatenating the bean implementation class name with a descriptive message stating the bean was not found and that GetClientSetting will not work, then raise FORM_TRIGGER_FAILURE.

FALSE: No exception of this type; continue normal processing.

DP-003

Condition: WebUtil_Core.PROPERTY_ERROR exception is raised during property retrieval.

TRUE: Raise FORM_TRIGGER_FAILURE immediately, halting form processing.

FALSE: No exception of this type; continue normal processing.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A null propertyName must not trigger any interaction with the WebUtil Core bean; the function returns NULL silently without error.
- BR-002 - The property name and its retrieval are mediated exclusively through WebUtil_Core using the WUC_PACKAGE component identifier and the WUC_GET_LOCAL_PROPERTY action key; no direct bean communication is performed outside this interface.
- BR-003 - If the WebUtil Core bean is not registered at the time of the call, the function must surface a descriptive error alert identifying the missing bean class before terminating form processing via FORM_TRIGGER_FAILURE.
- BR-004 - If a property error occurs during retrieval, the function must terminate form processing via FORM_TRIGGER_FAILURE without displaying an additional alert.
- BR-005 - The returned property value must not exceed 255 characters, as enforced by the result variable declaration.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetClientSetting(propertyName in VARCHAR2) return VARCHAR2 is 
    result VARCHAR2(255 char);
  BEGIN
    if propertyName is not null then 
    WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_GET_LOCAL_PROPERTY', propertyName);
       result := WebUtil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_GET_LOCAL_PROPERTY');
    end if;
    return result;
  EXCEPTION  
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                            ||' bean not found. WEBUTIL_CORE.GetClientSetting will not work');
    RAISE FORM_TRIGGER_FAILURE;  
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE FORM_TRIGGER_FAILURE;       
  END GetClientSetting;
```

#### SP-033 - WEBUTIL.GETIMPLCLASS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the fully qualified Java implementation class name for a given WebUtil package by concatenating the standard WebUtil Java root prefix with the registered implementation class suffix for the specified package identifier.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the package identifier (packageID) as an integer input parameter.
- Step 2 - Retrieve the implementation class suffix associated with packageID from the m_implClasses collection.
- Step 3 - Prepend the constant WEBUTIL_JAVA_ROOT to the retrieved suffix to form the fully qualified Java class name.
- Step 4 - Return the concatenated string to the caller.

---
**Decision Points**

No conditional decision points are present in this function. The logic executes as a single unconditional return statement.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The packageID supplied must correspond to a valid, pre-populated entry in the m_implClasses collection; no bounds or existence check is performed within this function, so an invalid packageID will raise a runtime error.
- BR-002 - The fully qualified Java implementation class name is always constructed by concatenating WEBUTIL_JAVA_ROOT with the class suffix stored in m_implClasses; neither component may be substituted independently at call time.

---
**Implementation Logic**

```plsql

  FUNCTION getImplClass(packageID PLS_INTEGER) return VARCHAR2 is
  BEGIN 
    return WEBUTIL_JAVA_ROOT||m_implClasses(packageID);    
  END;
```

#### SP-034 - WEBUTIL.GETLASTERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the last error code recorded by the AppServerFileReader Java object on the application server. This function is called by WEBUTIL.SETDATA to determine whether a preceding file-transfer operation completed successfully or encountered an error, returning the error status as a numeric code for downstream evaluation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the AppServerFileReader Java object instance (obj) as the target on which the error state is to be queried.
- Step 2 - Clear the argument list by setting args to NULL, ensuring no residual parameters are passed to the Java method invocation.
- Step 3 - Invoke the Java instance method getLastError() on the oracle/forms/webutil/fileTransfer/AppServerFileReader class via JNI.CALL_INT_METHOD, passing the supplied object reference and the cleared argument list.
- Step 4 - Return the integer value produced by the Java method call to the caller as the function result, representing the last error code recorded by the file-reader object.

---
**Decision Points**

No decision points are present in the implementation logic. The function executes a single unconditional Java method invocation and returns the result directly without branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The argument list must be explicitly set to NULL before invoking the Java method to prevent unintended parameter passing to the AppServerFileReader.getLastError() method.
- BR-002 - The error code is retrieved exclusively from the AppServerFileReader Java object instance supplied by the caller; no alternative error source is consulted.
- BR-003 - The function returns a numeric (INTEGER) error code as defined by the AppServerFileReader Java class contract; interpretation of specific code values is the responsibility of the calling routine (WEBUTIL.SETDATA).

---
**Implementation Logic**

```plsql
  FUNCTION getLastError(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_INT_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'getLastError', '()I', args); 
  END;
```

#### SP-035 - WEBUTIL.GETLASTERRORARGS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the argument string associated with the most recent error raised by the AppServerFileReader Java class. The function delegates the call to the underlying Java Native Interface layer to obtain a descriptive error-argument value that can be used by the caller (WEBUTIL.SETDATA) to interpret or report file-transfer error conditions.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the Java object reference (obj) that identifies the AppServerFileReader instance on which the last error occurred.
- Step 2 - Reset the local args variable to NULL to ensure no residual argument data from a previous call is carried forward.
- Step 3 - Invoke the Java method getLastErrorArgs on the oracle/forms/webutil/fileTransfer/AppServerFileReader class via JNI.CALL_STRING_METHOD, passing the cleared args payload and the method signature '()Ljava/lang/String;' to retrieve a String return value.
- Step 4 - Return the VARCHAR2 string produced by the JNI call to the invoking routine (WEBUTIL.SETDATA) as the last-error argument descriptor.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a single deterministic JNI method call and returns the result unconditionally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The args variable must be set to NULL before the JNI call to prevent stale argument data from being passed to the Java method.
- BR-002 - The target Java method is fixed as getLastErrorArgs on the oracle/forms/webutil/fileTransfer/AppServerFileReader class; no alternative class or method may be substituted.
- BR-003 - The function must be called with a valid ORA_JAVA.JOBJECT reference representing an AppServerFileReader instance; the object reference is supplied by the invoking routine WEBUTIL.SETDATA.
- BR-004 - The return value is a VARCHAR2 string sourced exclusively from the JNI layer; the function performs no additional transformation or validation on that value before returning it.

---
**Implementation Logic**

```plsql
  FUNCTION getLastErrorArgs(
    obj   ORA_JAVA.JOBJECT) RETURN VARCHAR2 IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_STRING_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'getLastErrorArgs', '()Ljava/lang/String;', args); 
  END;
```

#### SP-036 - WEBUTIL.GETNUMBER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Extracts a delimited field from a source string at a specified position and returns its value as a NUMBER. The function delegates string extraction to WEBUTIL.GETSTRING and applies a TO_NUMBER conversion to the result, providing callers with a type-safe numeric value without requiring them to perform the conversion themselves.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Source_string | varchar2 | IN |
| Field_position | number | IN |
| UnTerminated | Boolean | IN |
| Delimiter | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETSTRING ([SP-040](#SP-040--WEBUTIL.GETSTRING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the source string, the target field position, an optional flag indicating whether the final field is unterminated, and an optional delimiter character (defaulting to comma).
- Step 2 - Invoke WEBUTIL.GETSTRING, passing all four arguments unchanged, to extract the raw VARCHAR2 value at the specified field position within the delimited source string.
- Step 3 - Apply TO_NUMBER to the VARCHAR2 value returned by WEBUTIL.GETSTRING to convert it to a numeric data type.
- Step 4 - Return the resulting NUMBER value to the caller.

---
**Decision Points**

DP-001

Condition: UnTerminated parameter is not supplied by the caller.

TRUE: WEBUTIL.GETSTRING is called with UnTerminated defaulting to FALSE, treating the source string as a fully terminated delimited sequence.

FALSE: The explicitly supplied Boolean value for UnTerminated is forwarded to WEBUTIL.GETSTRING, adjusting its field-boundary detection accordingly.

DP-002

Condition: Delimiter parameter is not supplied by the caller.

TRUE: WEBUTIL.GETSTRING is called with the delimiter defaulting to a comma (','), treating the source string as a comma-separated sequence.

FALSE: The explicitly supplied delimiter character is forwarded to WEBUTIL.GETSTRING, overriding the comma default for field parsing.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must always delegate field extraction to WEBUTIL.GETSTRING; no independent parsing logic is performed within GETNUMBER itself.
- BR-002 - The extracted field value must be implicitly convertible to a number via TO_NUMBER; if the string value at the specified position is non-numeric, an Oracle numeric conversion error will be raised to the caller.
- BR-003 - The delimiter defaults to a comma (',') when not explicitly provided, establishing comma-separated format as the standard for source strings processed by this function.
- BR-004 - The UnTerminated flag defaults to FALSE when not explicitly provided, meaning the source string is assumed to contain a terminating delimiter after the last field unless the caller overrides this behaviour.
- BR-005 - Field position is 1-based and is passed without modification to WEBUTIL.GETSTRING; the caller is responsible for supplying a valid position within the bounds of the delimited source string.

---
**Implementation Logic**

```plsql

    
  function  GetNumber (Source_string    in varchar2,
                       Field_position   in number,
                       UnTerminated     in Boolean  default FALSE,
                       Delimiter        in varchar2 default ',') return number is
                       iRc              pls_integer;
  begin 
    Return to_number(GetString(Source_string, Field_Position, UnTerminated, Delimiter));
  end GetNumber; /* Number Version */
```

#### SP-037 - WEBUTIL.GETOSFAMILY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines and caches the client operating system family by inspecting the supplied OS name string. The function maps the raw OS name to a predefined platform constant (WIN32, MAC, LINUX, SOLARIS, HP, AIX, or UNKNOWN) and stores the result in the module-level variable m_clientOSFamily so that subsequent calls within the same session return the cached value without re-evaluation. It is invoked by WEBUTIL.REGISTERBEAN to identify the client platform before bean registration.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| osName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the raw OS name string (osName) as input and convert it to lowercase, storing the result in the local variable l_osName to ensure case-insensitive matching.
- Step 2 - Initialise the local result variable to CLIENT_PLATFORM_UNKNOWN as the default platform value.
- Step 3 - Check whether the module-level cache variable m_clientOSFamily is null. If it is not null, skip all evaluation and proceed directly to Step 10, returning the already-cached value.
- Step 4 - If m_clientOSFamily is null, evaluate l_osName for the substring 'windows'. If found, set result to CLIENT_PLATFORM_WIN32.
- Step 5 - If 'windows' was not found, evaluate l_osName for the substring 'mac'. If found, set result to CLIENT_PLATFORM_MAC.
- Step 6 - If 'mac' was not found, evaluate l_osName for the substring 'linux'. If found, set result to CLIENT_PLATFORM_LINUX.
- Step 7 - If 'linux' was not found, evaluate l_osName for the substrings 'solaris' or 'sunos'. If either is found, set result to CLIENT_PLATFORM_SOLARIS.
- Step 8 - If neither Solaris indicator was found, evaluate l_osName for the substring 'hp-ux'. If found, set result to CLIENT_PLATFORM_HP.
- Step 9 - If 'hp-ux' was not found, evaluate l_osName for the substring 'aix'. If found, set result to CLIENT_PLATFORM_AIX.
- Step 10 - Assign the resolved result value to the module-level variable m_clientOSFamily, caching it for future calls.
- Step 11 - Return m_clientOSFamily to the caller.

---
**Decision Points**

DP-001

Condition: m_clientOSFamily IS NULL

TRUE: Proceed with OS name evaluation (Steps 4-10) to determine and cache the platform family.

FALSE: Skip all evaluation and return the already-cached value of m_clientOSFamily immediately.

---

DP-002

Condition: l_osName contains the substring 'windows'

TRUE: Set result to CLIENT_PLATFORM_WIN32.

FALSE: Continue to the next OS family check (DP-003).

---

DP-003

Condition: l_osName contains the substring 'mac'

TRUE: Set result to CLIENT_PLATFORM_MAC.

FALSE: Continue to the next OS family check (DP-004).

---

DP-004

Condition: l_osName contains the substring 'linux'

TRUE: Set result to CLIENT_PLATFORM_LINUX.

FALSE: Continue to the next OS family check (DP-005).

---

DP-005

Condition: l_osName contains the substring 'solaris' OR l_osName contains the substring 'sunos'

TRUE: Set result to CLIENT_PLATFORM_SOLARIS.

FALSE: Continue to the next OS family check (DP-006).

---

DP-006

Condition: l_osName contains the substring 'hp-ux'

TRUE: Set result to CLIENT_PLATFORM_HP.

FALSE: Continue to the next OS family check (DP-007).

---

DP-007

Condition: l_osName contains the substring 'aix'

TRUE: Set result to CLIENT_PLATFORM_AIX.

FALSE: result remains CLIENT_PLATFORM_UNKNOWN; no further platform checks are performed.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The OS name comparison must be performed case-insensitively; the input value is converted to lowercase before any substring matching is applied.
- BR-002 - Platform detection follows a strict precedence order: Windows -> Mac -> Linux -> Solaris/SunOS -> HP-UX -> AIX. The first matching condition wins and no further checks are performed.
- BR-003 - If the OS name does not match any recognised platform substring, the function returns CLIENT_PLATFORM_UNKNOWN as the default platform family.
- BR-004 - The resolved platform family is cached in the module-level variable m_clientOSFamily after the first successful evaluation. Subsequent calls within the same session return the cached value without re-evaluating the OS name string.
- BR-005 - Solaris platform detection must recognise both the 'solaris' and 'sunos' substrings as equivalent indicators of the CLIENT_PLATFORM_SOLARIS family.

---
**Implementation Logic**

```plsql
 
  FUNCTION getOSFamily(osName in VARCHAR2) return PLS_INTEGER is
    l_osName VARCHAR2(30) := lower(osName);
    result   PLS_INTEGER  := CLIENT_PLATFORM_UNKNOWN;
  BEGIN
    if m_clientOSFamily  is null then 
      if (instr(l_osName,'windows') > 0) then 
           result := CLIENT_PLATFORM_WIN32;
      elsif instr(l_osName,'mac') > 0 then 
          result := CLIENT_PLATFORM_MAC;      
      elsif instr(l_osName,'linux') > 0 then 
          result := CLIENT_PLATFORM_LINUX;      
      elsif instr(l_osName,'solaris') > 0 OR instr(l_osName, 'sunos') > 0 then 
          result := CLIENT_PLATFORM_SOLARIS;       
      elsif instr(l_osName,'hp-ux') > 0 then 
          result := CLIENT_PLATFORM_HP; 
      elsif instr(l_osName,'aix') > 0 then 
          result := CLIENT_PLATFORM_AIX;                                                       
      end if;            
      m_clientOSFamily := result;
    end if;
    return m_clientOSFamily;
  END getOSFamily;
```

#### SP-038 - WEBUTIL.GETOUTPUT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GET_STANDARD_OUTPUT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves all lines of output from a client-side host process by repeatedly polling the WebUtil bean via WebUtil_Core property calls. The function accumulates each returned line into an OUTPUT_ARRAY and returns the complete array to the caller (WEBUTIL.GET_STANDARD_OUTPUT), allowing Oracle Forms to capture standard output produced by a previously launched process.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |
| prop | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.INIT ([SP-047](#SP-047--WEBUTIL.INIT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Initialise local variables: an empty OUTPUT_ARRAY (lines), a loop counter (i = 1), a 257-character buffer, and a status flag defaulted to 'X' (empty).
- Step 2 - Set the process handle on the WebUtil bean by calling WebUtil_Core.setProperty with the package constant WUH_PACKAGE, the property key 'WUH_PROC_ID', and the handle value from the incoming PROCESS_ID parameter.
- Step 3 - Enter a polling loop. On each iteration, call WebUtil_Core.getProperty with the package constant WUH_PACKAGE and the caller-supplied prop parameter to retrieve the next buffered output line.
- Step 4 - Extract the first character of the returned buffer into the status flag. A value of 'Y' means more lines follow; 'N' means this is the last line; 'X' means the buffer was empty.
- Step 5 - If status is not 'X', strip the leading status character from the buffer and store the remaining text as the next element in the lines array, then increment the counter.
- Step 6 - Exit the loop when status is not 'Y' (i.e., the final line 'N' has been processed or the buffer was empty 'X').
- Step 7 - Return the populated OUTPUT_ARRAY to the caller.
- Step 8 - On exception, if the WebUtil bean is not registered (BEAN_NOT_REGISTERED), display an error alert identifying the missing bean class and stating that WEBUTIL_HOST.GetOutput will not work; no array is returned in this path.

---
**Decision Points**

DP-001

Condition: status <> 'X' (the buffer returned by WebUtil_Core.getProperty is not empty)

TRUE: Strip the leading status character from the buffer, store the remaining text in the next element of the lines array, and increment the array index counter.

FALSE: Discard the buffer content; do not add an entry to the lines array.

---

DP-002

Condition: status <> 'Y' (the retrieved line is either the last line 'N' or the buffer was empty 'X')

TRUE: Exit the polling loop and proceed to return the accumulated lines array.

FALSE: Continue looping to retrieve the next output line from the WebUtil bean.

---

DP-003

Condition: WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during property retrieval

TRUE: Display an error alert identifying the unregistered bean class and indicating that WEBUTIL_HOST.GetOutput will not work; function does not return an array.

FALSE: Normal execution continues; no exception handling is triggered.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The process handle must be registered with the WebUtil bean before output retrieval begins; the function sets the WUH_PROC_ID property using the handle from the supplied PROCESS_ID parameter prior to entering the polling loop.
- BR-002 - Each value returned by WebUtil_Core.getProperty is prefixed with a single-character status code ('Y', 'N', or 'X'); only the substring from position 2 onward represents actual output content and is stored in the results array.
- BR-003 - Lines with a status of 'X' (empty buffer) are silently ignored and must not be added to the output array.
- BR-004 - The polling loop must continue until a status other than 'Y' is received, ensuring all available output lines are collected before the function returns.
- BR-005 - If the required WebUtil bean is not registered on the client, the function must surface an error alert identifying the missing bean class and must not silently fail or return partial data.
- BR-006 - The output buffer is declared as VARCHAR2(257 char), limiting each individual output line retrieved per iteration to a maximum of 257 characters.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetOutput(process in PROCESS_ID, prop in VARCHAR2) return OUTPUT_ARRAY is   
    lines  OUTPUT_ARRAY;
    i      PLS_INTEGER := 1;
    buffer VARCHAR2(257 char);
    status VARCHAR2(1) := 'X';
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_PROC_ID',process.handle);
    LOOP
      buffer := WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,prop);
      status := substr(buffer,1,1);
      -- Status can be Y: indicating more lines to follow,
      --               N: indicating that this is the last line
      --               X: indicating that the buffer was empty
      if status <> 'X' then 
        lines(i) := substr(buffer,2);
        i := i + 1;
      end if;
      exit when status <> 'Y';
    END LOOP;
    return lines;    
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.GetOutput will not work');
  END GetOutput;  
  
BEGIN
    -- Ensure that Core is instanciated.
    Webutil_Core.Init;
END;

PACKAGE WEBUTIL_SEPARATEFRAME IS

/*********************************************************************************\
 * WEBUTIL_SEPARATEFRAME
 *   This Package contains routines to interact with the MDI frame when Forms
 *   is running with the parameter separateFrame=true
 *   The functions in this package will work with any client type - not just 
 *   Windows clients.
 *   The oracle.forms.webutil.browser.BrowserFunctions bean is needed in your 
 *   Form to use these functions
 *********************************************************************************
 * Version 1.0.0
 *********************************************************************************
 * Change History
 *   1.0.0 DRMILLS 25/MAY/2003 - Creation
 *   1.0.1 DRMILLS 27/MAY/2003 - Added call to get frame size 
 *
\*********************************************************************************/

  /**
   *  IsSeparateFrame - Allows you to check if the form 
   *                is running in separateFrame mode or not
   */
```

#### SP-039 - WEBUTIL.GETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FOPEN]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a named Java system property value at runtime by delegating to the Java Native Interface (JNI) layer. Callers such as WEBUTIL.FOPEN and WEBUTIL.REGISTERBEAN use this function to obtain environment-level configuration values (e.g., file separators, OS name, Java version) that govern subsequent processing decisions within the WebUtil library.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the property name to look up via input parameter a0 (VARCHAR2).
- Step 2 - Create a JNI argument list sized for one argument by calling JNI.CREATE_ARG_LIST(1), storing the handle in the shared variable args.
- Step 3 - Add the property name string a0 to the argument list by calling JNI.ADD_STRING_ARG(args, a0).
- Step 4 - Invoke the Java static method java.lang.System.getProperty(String) through JNI.CALL_STRING_METHOD, passing the constructed argument list and targeting the class 'java/lang/System' with method signature '(Ljava/lang/String;)Ljava/lang/String;'.
- Step 5 - Return the VARCHAR2 string value returned by the JNI call to the caller; if the property does not exist in the JVM, the JNI layer returns NULL.

---
**Decision Points**

No conditional branching exists within this function. The implementation delegates entirely to the JNI layer; all decisional logic (e.g., handling an unknown property name) is resolved by the JVM and surfaced to the caller as a NULL or non-NULL return value.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The property name supplied in parameter a0 must be a valid Java system property key string; the function passes it unmodified to the JVM via JNI and does not perform any pre-validation or transformation.
- BR-002 - The function always constructs a fresh single-element JNI argument list for each invocation; callers must not assume any argument list state is preserved between calls.
- BR-003 - The function returns NULL when the requested Java system property is not defined in the current JVM environment; callers (e.g., WEBUTIL.FOPEN, WEBUTIL.REGISTERBEAN) are responsible for handling a NULL return value appropriately.
- BR-004 - This function has no database interactions and no internal dependencies; its behaviour is entirely determined by the JVM system properties available at the time of invocation.

---
**Implementation Logic**

```plsql
  FUNCTION getProperty(
    a0    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'getProperty', '(Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-040 - WEBUTIL.GETSTRING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETNUMBER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Extracts a single delimited field from a source string by position. Given a delimiter-separated string, the function locates the Nth token (identified by Field_position) and returns it as a VARCHAR2 value. It is used internally by WEBUTIL.GETNUMBER to isolate a positional substring before numeric conversion.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Source_string | varchar2 | IN |
| Field_position | number | IN |
| UnTerminated | Boolean | IN |
| Delimiter | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-051](#SP-051--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the source string, the 1-based field position to extract, an optional Boolean flag indicating whether the string lacks a trailing delimiter (UnTerminated), and an optional delimiter character (defaulting to comma).
- Step 2 - If UnTerminated is TRUE, append the delimiter to a working copy of the source string so that the final token is bounded and can be located consistently.
- Step 3 - Determine the start pointer (iPtrStart): if Field_position is greater than 1, locate the (Field_position - 1)th occurrence of the delimiter in the working string and advance the pointer past the delimiter's own length; otherwise set the start pointer to 1 (beginning of the string).
- Step 4 - Determine the end pointer (iPtrEnd) by locating the Field_positionth occurrence of the delimiter in the working string.
- Step 5 - Extract and return the substring between iPtrStart and iPtrEnd (exclusive) using SUBSTR, yielding the token at the requested field position.

---
**Decision Points**

DP-001

Condition: UnTerminated parameter is TRUE.

TRUE: The delimiter is appended to the working copy of the source string before any parsing begins, ensuring the last field is bounded by a delimiter and can be found by INSTR.

FALSE: The source string is used as-is; it is assumed to already contain a trailing delimiter or the requested field position falls within the bounded portion of the string.

---

DP-002

Condition: Field_position is greater than 1.

TRUE: The start pointer is calculated by finding the (Field_position - 1)th occurrence of the delimiter and advancing past it by the delimiter's length, positioning the pointer at the first character of the target token.

FALSE: The start pointer is set to 1, meaning extraction begins at the very start of the working string (first token).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Field positions are 1-based; a Field_position value of 1 always begins extraction from the first character of the source string.
- BR-002 - If the source string does not end with the delimiter and the target token is the last field, the caller must pass UnTerminated = TRUE so that the function appends the delimiter and correctly bounds the final token.
- BR-003 - The delimiter defaults to a comma if not supplied; any single or multi-character delimiter passed by the caller is applied consistently for both start and end boundary detection.
- BR-004 - The working string is a local copy (limited to 32,000 characters); the original Source_string parameter is never modified.
- BR-005 - The length of the delimiter is accounted for when advancing the start pointer, ensuring multi-character delimiters do not leave delimiter characters in the extracted token.

---
**Implementation Logic**

```plsql

  function  GetString (Source_string    in varchar2,
                       Field_position   in number,
                       UnTerminated     in Boolean  default FALSE,
                       Delimiter        in varchar2 default ',') return varchar2 is
                       iPtrEnd          pls_integer     := 0;
                       iPtrStart        pls_integer     := 0;
                       vcSourceStrCopy  varchar2(32000)     := Source_string;
  begin
    if UnTerminated then 
      vcSourceStrCopy := vcSourceStrCopy||Delimiter;
    end if;

    if Field_Position > 1 then 
      iPtrStart := instr(vcSourceStrCopy,Delimiter,1,Field_Position-1)+ length(Delimiter);
    else
      iPtrStart := 1;
    end if ; 

    iPtrEnd     := instr(vcSourceStrCopy,Delimiter,1,Field_Position);
    return substr(vcSourceStrCopy,iPtrStart,(iPtrEnd-iPtrStart));
  end GetString; /* String Version */
```

#### SP-041 - WEBUTIL.GETVAR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.GETVAR resolves the value of a named configuration or environment variable on the client machine. It selects the appropriate retrieval strategy based on the client operating system family: on Windows clients it queries the Oracle registry key first, then falls back to an environment variable lookup; on Unix clients it executes the 'env' command and parses its output; on Mac and unknown platforms it takes no action and returns the value unchanged.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VARNAME | VARCHAR2 | IN |
| VARVALUE | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VARVALUE | VARCHAR2 | IN OUT |

---

**Dependencies**

- GET_ENVIRONMENT_STRING ([SP-073](#SP-073--GET_ENVIRONMENT_STRING)) - matched by member name
- READ_REGISTRY ([SP-076](#SP-076--READ_REGISTRY)) - matched by member name
- WEBUTIL.GETCLIENTOSFAMILY ([SP-031](#SP-031--WEBUTIL.GETCLIENTOSFAMILY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_STANDARD_OUTPUT ([SP-044](#SP-044--WEBUTIL.GET_STANDARD_OUTPUT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the variable name (VARNAME) and the current value holder (VARVALUE) as input parameters.
- Step 2 - Determine the client operating system family by calling WEBUTIL.GETCLIENTOSFAMILY.
- Step 3 - If the client is Windows (CLIENT_PLATFORM_WIN32), attempt to read the variable value from the Windows registry under the key 'HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE' using READ_REGISTRY.
- Step 4 - If the registry lookup returns NULL or an empty string, fall back to retrieving the value from the client's environment variables using GET_ENVIRONMENT_STRING.
- Step 5 - If the client is Mac (CLIENT_PLATFORM_MAC) or an unknown platform (CLIENT_PLATFORM_UNKNOWN), perform no action; VARVALUE remains unchanged.
- Step 6 - If the client is any other platform (Unix), execute the 'env' command as a blocking host process using WebUtil_HOST.Blocking.
- Step 7 - Retrieve the standard output of the host process via WEBUTIL.GET_STANDARD_OUTPUT and release the process handle.
- Step 8 - Iterate over each line of the 'env' output; for each line, locate the '=' delimiter, extract the key to the left of it, and compare it to VARNAME.
- Step 9 - When a matching key is found, extract the value to the right of the '=' delimiter, assign it to VARVALUE, and exit the loop.
- Step 10 - If a NO_DATA_FOUND exception is raised at any point during execution, set VARVALUE to NULL and return.

---
**Decision Points**

DP-001

Condition: Client operating system family equals CLIENT_PLATFORM_WIN32.

TRUE: Attempt to retrieve the variable value from the Windows registry under 'HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE' via READ_REGISTRY; if that returns NULL or empty, retrieve the value from the client environment via GET_ENVIRONMENT_STRING.

FALSE: Proceed to DP-002.

DP-002

Condition: Client operating system family is CLIENT_PLATFORM_MAC or CLIENT_PLATFORM_UNKNOWN.

TRUE: Take no action; VARVALUE is left unchanged and the procedure exits normally.

FALSE: Client is a Unix platform; proceed to execute the 'env' command and parse its output (DP-003 and DP-004).

DP-003

Condition: (Windows path only) The value returned by READ_REGISTRY for the given VARNAME is NULL or empty.

TRUE: Call GET_ENVIRONMENT_STRING to retrieve the variable value from the client environment.

FALSE: Use the registry value already retrieved as VARVALUE.

DP-004

Condition: (Unix path only) A '=' character is found within the current output line (iPos > 0).

TRUE: Extract the key portion of the line and compare it to VARNAME (DP-005).

FALSE: Skip the current line and continue iterating.

DP-005

Condition: (Unix path only) The extracted key from the current 'env' output line equals VARNAME.

TRUE: Assign the value portion of the line to VARVALUE and exit the loop.

FALSE: Continue iterating to the next output line.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The variable resolution strategy is strictly determined by the client OS family; Windows, Unix, and Mac/Unknown platforms each follow a distinct and mutually exclusive code path.
- BR-002 - On Windows, the Oracle registry path 'HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE' is always the primary source for variable resolution; the environment variable lookup via GET_ENVIRONMENT_STRING is only attempted when the registry returns no value.
- BR-003 - On Mac and unknown client platforms, no variable resolution is attempted; the procedure returns VARVALUE in its incoming state.
- BR-004 - On Unix platforms, variable resolution is performed exclusively by executing the client-side 'env' command and parsing its output; no registry or direct environment API call is used.
- BR-005 - Unix 'env' output lines that do not contain a '=' character are ignored during parsing.
- BR-006 - On Unix, only the first matching environment variable entry is used; the loop exits immediately upon finding a match.
- BR-007 - If a NO_DATA_FOUND exception is raised during execution, VARVALUE is set to NULL and the procedure exits without propagating the exception.

---
**Implementation Logic**

```plsql

  PROCEDURE GETVAR(VARNAME IN VARCHAR2, VARVALUE IN OUT VARCHAR2) is
    unixOutput WebUtil_HOST.OUTPUT_ARRAY;
    hostHandle WebUtil_HOST.PROCESS_ID;
    varKey     VARCHAR2(100);
    iPos       PLS_INTEGER;
  BEGIN
    if WebUtil_Core.GetClientOSFamily = WebUtil_Core.CLIENT_PLATFORM_WIN32 then 
      -- read the client Registry
      VARVALUE := Client_Win_API_Environment.read_registry('HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE',VARNAME,false);
      if VARVALUE is null OR VARVALUE = '' then
        -- Could not get an Oracle variable in registry. Try to get from environment varialble
        -- java desupported System.getenv method until they supported it again in 1.5.
        -- We can still get the environment variables in windows using
        -- CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING
        VARVALUE := CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING(VARNAME);
      end if;
    elsif WebUtil_Core.GetClientOSFamily in (WebUtil_Core.CLIENT_PLATFORM_MAC,WebUtil_Core.CLIENT_PLATFORM_UNKNOWN) then 
      -- do nothing 
      null;
    else
      -- Unix Ports - do a env to get the environment and parse that
      hostHandle := WebUtil_HOST.Blocking('env');
      unixOutput := WebUtil_HOST.Get_Standard_Output(hostHandle);
      WebUtil_HOST.Release_Process(hostHandle);
      for i in 1..unixOutput.count LOOP
        iPos := instr(unixOutput(i),'=');
        if iPos > 0 then 
          varKey := substr(unixOutput(i),1,iPos-1);
          if varKey = VARNAME then 
            VARVALUE := substr(unixOutput(i),iPos+1);
            EXIT;
          end if;
        end if;
      end LOOP;
    end if;

  exception
    when NO_DATA_FOUND then
      VARVALUE := null;
  END GETVAR;

END CLIENT_TOOL_ENV;

PACKAGE Client_Win_API IS
/*-------------------------------------------------------------------------------*\
 * WebUtil version of D2KWUTIL package WIN_API                                     
 * Note: Not all D2kWutil Functions are ported
 *********************************************************************************
 * Version 1.0.0
 *********************************************************************************
 * Change History
 *   DRMILLS 21/FEB/2003 - Port Creation
 *
 *********************************************************************************
 * WIN_API ->  This package defines the constants used throughout 
 *      the library as a whole, including versions of those 
 *      constants defined within WINDOWS.H/WINUSER.H that 
 *      we'll be using. Add more constants in here if required
 *      The package also contains Explicit Exception declarations,
 *      various status Flags and functions for Error Handling
 * NOTE:    In order to make this library portable across Forms
 *      and Reports we do not use any application 
 *      specific built-ins such as the Forms MESSAGE() 
 *      Built-in. Instead errors are recorded in a package
 *      variable which the programmer can examine if required
\*-------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------*\
 * Internal Version Number  ** Oracle Developer Release 6.0 Version
\*-------------------------------------------------------------------------------*/
  WIN_API_VERSION  CONSTANT  VARCHAR2(30) := '6.0.6.0 Production';
  DLL_NAME         CONSTANT  VARCHAR2(12) := 'd2kwut60.dll';
  DLL_PATH         VARCHAR2(256)          := NULL;

/*-------------------------------------------------------------------------------*\
 * General Window Classes of Common Applications for use with WIN_API_SESSION
 * ** WARNING ** These Window classes are out of our control and might change 
 *               when you upgrade the software in question,
\*-------------------------------------------------------------------------------*/

  -- Oracle Apps
  WINCLASS_DEVELOPER_2000_V1  CONSTANT  VARCHAR2(15)  := 'ui23MDIroot_W32';             /* Developer/2000 release 1.n / Toolkit 2.3 Apps on 32 bit */
  WINCLASS_DEVELOPER_2000_V2  CONSTANT  VARCHAR2(15)  := 'ui25MDIroot_W32';             /* Developer/2000 Release 2.0 / Toolkit 2.5 Apps on 32 bit */
  WINCLASS_DEVELOPER_2000_V6  CONSTANT  VARCHAR2(15)  := 'ui60MDIroot_W32';             /* Developer/2000 Release 6.0 / Toolkit 6.0 Apps on 32 bit */  
  D2K_WINDOW_CLASS            CONSTANT  VARCHAR2(15)  := WINCLASS_DEVELOPER_2000_V6;    /* Set to the "current" version */  
  WINCLASS_INTEROFFICE_40     CONSTANT  VARCHAR2(28)  := 'Afx:10000000:b:10008:6:5023b';/* Oracle Interoffice 4.0 Client 32 bit */
  WINCLASS_INTEROFFICE_41     CONSTANT  VARCHAR2(28)  := 'Afx:10000000:b:1496:6:3a17';  /* Oracle Interoffice 4.0 Client 32 bit */
  WINCLASS_SQLPLUS            CONSTANT  VARCHAR2(13)  := 'SqlplusWClass';               /* Sql*Plus 32 bit */
  WINCLASS_REPORTSSERVER_V1   CONSTANT  VARCHAR2(15)  := 'R25SRV_WINCLASS';             /* Reports Server Reports 2.5 */
  WINCLASS_REPORTSSERVER_V2   CONSTANT  VARCHAR2(15)  := 'R30SRV_WINCLASS';             /* Reports Server Reports 3.0 */
  WINCLASS_REPORTSSERVER_V6   CONSTANT  VARCHAR2(14)  := 'RWRBE_WINCLASS';              /* Reports Server Reports 6.0 */

  -- Microsoft Office Apps - Office97
  WINCLASS_MSWORD_97         CONSTANT  VARCHAR2(7) := 'OpusApp';                        /* Microsoft Word 97 */
  WINCLASS_MSEXCEL_97        CONSTANT  VARCHAR2(6) := 'XLMAIN';                         /* Microsoft Excel 97 */
  WINCLASS_MSPOWERPOINT_97   CONSTANT  VARCHAR2(14):= 'PP97FrameClass';                 /* Microsoft Power Point 97 */

  -- Microsoft Office Apps - Office95
  WINCLASS_MSWORD_7          CONSTANT  VARCHAR2(7) := 'OpusApp';                        /* Microsoft Word 7 */
  WINCLASS_MSEXCEL_7         CONSTANT  VARCHAR2(6) := 'XLMAIN';                         /* Microsoft Excel 7 */
  WINCLASS_MSPOWERPOINT_7    CONSTANT  VARCHAR2(13):= 'PP7FrameClass';                  /* Microsoft Power Point 7 */
  WINCLASS_MSSCHEDULE_7      CONSTANT  VARCHAR2(23):= 'MS Schedule+ 32 Panesdi';        /* Microsoft Schedule 7 */
  WINCLASS_MSEXCHANGE_4      CONSTANT  VARCHAR2(29):= 'Microsoft Exchange 4.0 Viewer';  /* Microsoft Exchange 4 in-tray */

  -- Microsoft O/S Utilities
  WINCLASS_INETEXPLORER      CONSTANT  VARCHAR2(7):= 'IEFrame';                         /* Internet Explorer */
  WINCLASS_OUTLOOK_EXPRESS   CONSTANT  VARCHAR2(29):= 'Outlook Express Browser Class';  /* Outlook Express */
  WINCLASS_EXPLORER          CONSTANT  VARCHAR2(13):= 'ExploreWClass';                  /* Explorer */
  WINCLASS_MYCOMPUTER        CONSTANT  VARCHAR2(13):= 'CabinetWClass';                  /* My Computer & Network Neighborhood*/
  WINCLASS_CALCULATOR        CONSTANT  VARCHAR2(7) := 'SciCalc';                        /* Windows Calculator */
  WINCLASS_NOTEPAD           CONSTANT  VARCHAR2(7) := 'Notepad';                        /* Windows Notepad */
  WINCLASS_WORDPAD           CONSTANT  VARCHAR2(12):= 'WordPadClass';                   /* Windows Wordpad/Write */
  WINCLASS_DOS               CONSTANT  VARCHAR2(18):= 'ConsoleWindowClass';             /* Dos Window */

  -- Other
  WINCLASS_NETSCAPE_3        CONSTANT  VARCHAR2(27):= 'Afx:40000000:b:150e:6:38cfe';    /* Netscape Navigator 3.0 */
  WINCLASS_NETSCAPE_4        CONSTANT  VARCHAR2(28):= 'Afx:40000000:b:10008:6:6063e';   /* Netscape Communicator 4.0 */
  WINCLASS_PFE_7             CONSTANT  VARCHAR2(11):= 'PFE32_Frame';                    /* Programmers File Editor */
  WINCLASS_REGEDIT           CONSTANT  VARCHAR2(15):= 'RegEdit_RegEdit';                /* Registry Editor */

  -- Window Style Constants (from WINUSER.H)
  --  Any PU's that use these constants will explain 
  --  their use.  For further information consult the
  --  Windows SDK.

  SW_HIDE              CONSTANT  PLS_INTEGER := 0;
  SW_SHOWNORMAL        CONSTANT  PLS_INTEGER := 1;
  SW_SHOWMINIMIZED     CONSTANT  PLS_INTEGER := 2;
  SW_SHOWMAXIMIZED     CONSTANT  PLS_INTEGER := 3;
  SW_SHOWNOACTIVATE    CONSTANT  PLS_INTEGER := 4;
  SW_SHOW              CONSTANT  PLS_INTEGER := 5;
  SW_MINIMIZE          CONSTANT  PLS_INTEGER := 6;
  SW_SHOWMINNOACTIVE   CONSTANT  PLS_INTEGER := 7;
  SW_SHOWNA            CONSTANT  PLS_INTEGER := 8;
  SW_RESTORE           CONSTANT  PLS_INTEGER := 9;
  SW_SHOWDEFAULT       CONSTANT  PLS_INTEGER := 10;

  -- Help Access Constants (From WINUSER.H)
  --  See WIN_API_SHELL.WinHelp

  HELP_CONTEXT         CONSTANT  PLS_INTEGER := 1;   /* 0x0001L */
  HELP_QUIT            CONSTANT  PLS_INTEGER := 2;   /* 0x0002L */
  HELP_INDEX           CONSTANT  PLS_INTEGER := 3;   /* 0x0003L */
  HELP_CONTENTS        CONSTANT  PLS_INTEGER := 3;   /* 0x0003L */
  HELP_HELPONHELP      CONSTANT  PLS_INTEGER := 4;   /* 0x0004L */
  HELP_SETINDEX        CONSTANT  PLS_INTEGER := 5;   /* 0x0005L */
  HELP_SETCONTENTS     CONSTANT  PLS_INTEGER := 5;   /* 0x0005L */
  HELP_CONTEXTPOPUP    CONSTANT  PLS_INTEGER := 8;   /* 0x0008L */
  HELP_FORCEFILE       CONSTANT  PLS_INTEGER := 9;   /* 0x0009L */
  HELP_KEY             CONSTANT  PLS_INTEGER := 257; /* 0x0101L */
  HELP_COMMAND         CONSTANT  PLS_INTEGER := 258; /* 0x0102L */
  HELP_PARTIALKEY      CONSTANT  PLS_INTEGER := 261; /* 0x0105L */
  HELP_MULTIKEY        CONSTANT  PLS_INTEGER := 513; /* 0x0201L */
  HELP_SETWINPOS       CONSTANT  PLS_INTEGER := 515; /* 0x0203L */
  -- Windows 4+
  HELP_CONTEXTMENU     CONSTANT  PLS_INTEGER := 10;  /* 0x000a  */
  HELP_FINDER          CONSTANT  PLS_INTEGER := 11;  /* 0x000b  */
  HELP_WM_HELP         CONSTANT  PLS_INTEGER := 12;  /* 0x000c  */
  HELP_SETPOPUP_POS    CONSTANT  PLS_INTEGER := 13;  /* 0x000d  */

  -- Windows Messages for use with SendMessage
  -- DO NOT utilise the Windows Sendmessage interface without being conversant
  -- with the Windows message handling mechanism
  -- Refer to the Microsoft Windows SDK for Messages and Parameter values
  WM_SYSCOMMAND        CONSTANT  PLS_INTEGER := 274;   /* 0x0112 */
  WM_MDITILE           CONSTANT  PLS_INTEGER := 550;   /* 0x0226 */
  WM_MDICASCADE        CONSTANT  PLS_INTEGER := 551;   /* 0x0227 */
  WM_MDIICONARRANGE    CONSTANT  PLS_INTEGER := 552;   /* 0x0228 */      
  SC_RESTORE           CONSTANT  PLS_INTEGER := 61728; /* 0xF120 */
  SC_MINIMIZE          CONSTANT  PLS_INTEGER := 61472; /* 0xF020 */
  SC_MAXIMIZE          CONSTANT  PLS_INTEGER := 61488; /* 0xF030 */
  

  -- Flags for use with File Dialog boxes ("Save As" or "Open")
  -- Refer to your Microsoft documentation for details on the 
  -- Exact usage and dependancies of each option
  OFN_READONLY           CONSTANT  PLS_INTEGER := 1;        /* 0x00000001 */
  OFN_OVERWRITEPROMPT    CONSTANT  PLS_INTEGER := 2;        /* 0x00000002 */
  OFN_HIDEREADONLY       CONSTANT  PLS_INTEGER := 4;        /* 0x00000004 */
  OFN_NOCHANGEDIR        CONSTANT  PLS_INTEGER := 8;        /* 0x00000008 */
  OFN_SHOWHELP           CONSTANT  PLS_INTEGER := 16;       /* 0x00000010 */
  OFN_NOVALIDATE         CONSTANT  PLS_INTEGER := 256;      /* 0x00000100 */
  OFN_ALLOWMULTISELECT   CONSTANT  PLS_INTEGER := 512;      /* 0x00000200 */
  OFN_EXTENSIONDIFFERENT CONSTANT  PLS_INTEGER := 1024;     /* 0x00000400 */
  OFN_PATHMUSTEXIST      CONSTANT  PLS_INTEGER := 2048;     /* 0x00000800 */
  OFN_FILEMUSTEXIST      CONSTANT  PLS_INTEGER := 4096;     /* 0x00001000 */
  OFN_CREATEPROMPT       CONSTANT  PLS_INTEGER := 8192;     /* 0x00002000 */
  OFN_SHAREAWARE         CONSTANT  PLS_INTEGER := 16384;    /* 0x00004000 */
  OFN_NOREADONLYRETURN   CONSTANT  PLS_INTEGER := 32768;    /* 0x00008000 */
  OFN_NOTESTFILECREATE   CONSTANT  PLS_INTEGER := 65536;    /* 0x00010000 */
  OFN_NONETWORKBUTTON    CONSTANT  PLS_INTEGER := 131072;   /* 0x00020000 */
  OFN_NOLONGNAMES        CONSTANT  PLS_INTEGER := 262144;   /* 0x00040000 */
  OFN_EXPLORER           CONSTANT  PLS_INTEGER := 524288;   /* 0x00080000 */
  OFN_NODEREFERENCELINKS CONSTANT  PLS_INTEGER := 1048576;  /* 0x00100000 */
  OFN_LONGNAMES          CONSTANT  PLS_INTEGER := 2097152;  /* 0x00200000 */

  -- The defaults used here (WIN_API.OFN_PATHMUSTEXIST|WIN_API.OFN_FILEMUSTEXIST|WIN_API.OFN_HIDEREADONLY|WIN_API.OFN_NOCHANGEDIR|WIN_API.OFN_EXPLORER)
  OFN_FLAG_DEFAULT       CONSTANT  PLS_INTEGER :=  530444;
  
  
  -- Registry Data types for Write_RegistryEx
  REG_EXPAND_SZ          CONSTANT  PLS_INTEGER := 0;
  REG_SZ                 CONSTANT  PLS_INTEGER := 1;
  REG_DWORD              CONSTANT  PLS_INTEGER := 2;
  
  -- Compatibility Flags - Used where I have changed behaviour and you might not like the new version
  -- Change these at runtime to FALSE to revert to "old" behaviour
  COMPAT_EXPAND_REG_VALUES    BOOLEAN := TRUE;

  
  
  -- Types
  TYPE aFunctionHandle is table of WEBUTIL_C_API.FUNCTIONHANDLE index by BINARY_INTEGER;  
  SUBTYPE FILE_TYPE is PLS_INTEGER;

  -- Public Variables
  ERROR_ENCOUNTERED  BOOLEAN := FALSE;  /* The Last Call resulted in an error */
  ERROR_STACK        VARCHAR2(2000);    /* Holds Text of Last error(s) */ 
  API_ENABLED        BOOLEAN := FALSE;   /* Are API functions usable ?*/
  DLL_HANDLE         ORA_FFI.LibHandleType;
  FunctionHandle     aFunctionHandle;
   

  -- Public Exceptions
  NOT_AVAILABLE      EXCEPTION;  /* A call to the API was made but API functions not currently available (e.g. not on Windows) */
     
  -- Error Constants
  UError             CONSTANT  VARCHAR2(30) := ' Caused an unexpected error: ';
  NoAPI              CONSTANT  VARCHAR2(31) := 'API Functions are not Available';
  MaxDWord           CONSTANT  VARCHAR2(33) := 'Integer Argument exceeds 32 bits ';
  MaxWord            CONSTANT  VARCHAR2(33) := 'Integer Argument exceeds 16 bits ';
  MaxByte            CONSTANT  VARCHAR2(32) := 'Integer Argument exceeds 8 bits ';
  MinBound           CONSTANT  VARCHAR2(27) := 'Integer Argument too Small ';
  MaxBound           CONSTANT  VARCHAR2(27) := 'Integer Argument too Large ';
  NullArg            CONSTANT  VARCHAR2(24) := 'Argument cannot be NULL ';

  /*----------------------------------------------------------------------------*\
  * PreLoad ->  Loads the d2kwut60.dll from the jvm bin directory into memory
  \*----------------------------------------------------------------------------*/
```

#### SP-042 - WEBUTIL.GET_LINE

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Reads a single line of text from an open client-side file and returns it to the caller. The procedure delegates the actual file-read operation to the WebUtil Java bean via WebUtil_Core property calls, then interprets the returned buffer to distinguish a valid (possibly empty) line from an end-of-file condition. It is invoked as part of the Excel report generation flow in dms_excel_report.pld.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| item | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the file handle encapsulated in the FILE_TYPE input parameter.
- Step 2 - Pass the file handle to the WebUtil Java bean by calling WebUtil_Core.setProperty, setting the WUF_TEXTIO_HANDLE property on the WUF_PACKAGE component.
- Step 3 - Trigger the bean to read one line from the file by calling WebUtil_Core.getProperty with the WUF_TEXTIO_GETLINE property key; store the result in the local VARCHAR2 buffer.
- Step 4 - Evaluate the buffer value: if it equals CHR(10) (a lone newline character), the bean has signalled end-of-file; raise NO_DATA_FOUND to propagate this condition to the caller.
- Step 5 - If the buffer does not equal CHR(10), assign the buffer contents to the OUT parameter ITEM and return normally.
- Step 6 - If the WebUtil bean is not registered (BEAN_NOT_REGISTERED exception), display an error alert via WebUtil_Core.ErrorAlert identifying the missing bean class, then raise TOOL_ERR.TOOL_ERROR to halt processing.
- Step 7 - If a property interaction error occurs (PROPERTY_ERROR exception), raise TOOL_ERR.TOOL_ERROR immediately without an alert.

---
**Decision Points**

DP-001

Condition:
The buffer returned by WebUtil_Core.getProperty equals CHR(10) (a lone newline character).

TRUE:
The end-of-file sentinel has been detected; raise NO_DATA_FOUND to signal the caller that no further lines are available.

FALSE:
A valid line of text was read; assign the buffer value to the OUT parameter ITEM and return successfully.

---

DP-002

Condition:
A WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during property set or get.

TRUE:
Display an error alert via WebUtil_Core.ErrorAlert identifying the unregistered bean class, then raise TOOL_ERR.TOOL_ERROR to abort the calling process.

FALSE:
No bean registration error; continue with normal or PROPERTY_ERROR exception handling.

---

DP-003

Condition:
A WebUtil_Core.PROPERTY_ERROR exception is raised during property set or get.

TRUE:
Raise TOOL_ERR.TOOL_ERROR immediately to abort the calling process (no alert is issued).

FALSE:
No property error; processing continues normally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file handle supplied in the FILE_TYPE parameter must already be open before GET_LINE is called; the procedure does not open or validate the file itself.
- BR-002 - A lone CHR(10) return value from the WebUtil bean is reserved exclusively as the end-of-file sentinel; it is never treated as a valid line of text.
- BR-003 - On end-of-file, the procedure raises the standard Oracle NO_DATA_FOUND exception, conforming to the TEXT_IO contract expected by callers such as VIEW_EXCEL_REPORT_NEW.
- BR-004 - If the WebUtil Java bean is not registered on the client, the procedure must surface a descriptive error alert (via WebUtil_Core.ErrorAlert) before raising TOOL_ERR.TOOL_ERROR, ensuring the user receives an actionable message.
- BR-005 - A WebUtil_Core.PROPERTY_ERROR condition results in an immediate TOOL_ERR.TOOL_ERROR raise with no alert, treating property-level failures as unrecoverable technical errors.
- BR-006 - The line buffer is limited to 4000 characters (VARCHAR2(4000 CHAR)); lines exceeding this length will be truncated by the underlying bean interaction.

---
**Implementation Logic**

```plsql
  PROCEDURE get_line (file file_type, item OUT VARCHAR2) is
    buffer VARCHAR2(4000 char);
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);        
    buffer := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_GETLINE');
    -- We can't easily tell the difference between an empty line and a line beyond then 
    -- end of the file so to get around this, the exception handling code in the PJC 
    -- places a newline into the buffer when the end of file is passed.
    -- The rational being that get_line would never normally return a newline because 
    -- it normally uses that to tell it where to read up *to*.
    if buffer = chr(10) then 
      raise NO_DATA_FOUND;
    else
      item := buffer;
    end if;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.get_line will not work');
      RAISE TOOL_ERR.TOOL_ERROR;                                                                 
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE TOOL_ERR.TOOL_ERROR;  
  END get_line;
  
  /**
   * File writing functions
   */
```

#### SP-043 - WEBUTIL.GET_RETURN_CODE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.HOST]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the integer return code produced by a previously executed host process. Given a PROCESS_ID handle, the function communicates with the WebUtil client-side bean to obtain the numeric exit/return code of that process and returns it to the caller (WEBUTIL.HOST).

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the PROCESS_ID of the host process whose return code is required.
- Step 2 - Set the process handle on the WebUtil bean by calling WebUtil_Core.setProperty, passing the WUH_PACKAGE constant, the property key 'WUH_PROC_ID', and the handle value from the supplied PROCESS_ID.
- Step 3 - Retrieve the return code string from the WebUtil bean by calling WebUtil_Core.getProperty with the WUH_PACKAGE constant and the property key 'WUH_RC'.
- Step 4 - Convert the retrieved string value to a PLS_INTEGER using TO_NUMBER and return it to the caller.
- Step 5 - If the WebUtil bean is not registered (BEAN_NOT_REGISTERED exception), display an error alert identifying the missing bean class and the function that failed, then exit without returning a value.

---
**Decision Points**

DP-001

Condition:
The WebUtil bean identified by WebUtil_Core.WUH_PACKAGE is registered and reachable when setProperty and getProperty are called.

TRUE:
The process handle is set, the return code property is read, converted to a PLS_INTEGER, and returned to the caller.

FALSE:
A BEAN_NOT_REGISTERED exception is raised; an error alert is displayed stating that the bean class was not found and that WEBUTIL_HOST.Get_Return_Code will not work, and no return code is returned.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function requires a valid PROCESS_ID whose handle was previously registered with the WebUtil bean; passing an unregistered or null handle will result in either an incorrect return code or a BEAN_NOT_REGISTERED exception.
- BR-002 - The WebUtil client-side bean (WUH_PACKAGE) must be registered in the client environment before this function is invoked; if it is absent, execution is aborted with an informational error alert and no return code is produced.
- BR-003 - The return code stored in the bean under the property key 'WUH_RC' must be convertible to a number; non-numeric values will cause a TO_NUMBER conversion error at runtime.
- BR-004 - No database interactions are performed; all state is maintained exclusively through the WebUtil bean property mechanism (setProperty / getProperty).

---
**Implementation Logic**

```plsql
  
  
  FUNCTION Get_Return_Code(process in PROCESS_ID) return PLS_INTEGER is
  begin 
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_PROC_ID',process.handle);
    return to_number(WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,'WUH_RC'));
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
       WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                               ||' bean not found. WEBUTIL_HOST.Get_Return_Code will not work');
  end Get_Return_Code;
```

#### SP-044 - WEBUTIL.GET_STANDARD_OUTPUT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the standard output (stdout) stream captured from a previously executed host process. The function acts as a named convenience wrapper that delegates to WEBUTIL.GETOUTPUT, passing the fixed stream identifier 'WUH_STDOUT' to isolate standard output from other output channels associated with the given process.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETOUTPUT ([SP-038](#SP-038--WEBUTIL.GETOUTPUT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the process identifier (PROCESS_ID) of a previously executed host process as the input parameter.
- Step 2 - Invoke WEBUTIL.GETOUTPUT (SP-038), passing the supplied process identifier and the hard-coded stream label 'WUH_STDOUT' to retrieve all standard output lines captured for that process.
- Step 3 - Return the OUTPUT_ARRAY result produced by WEBUTIL.GETOUTPUT directly to the caller.

---
**Decision Points**

No conditional decision points exist in this function. Execution follows a single, unconditional path: delegate to WEBUTIL.GETOUTPUT with the fixed stream identifier and return the result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The stream identifier used to retrieve output is always 'WUH_STDOUT'; callers cannot override or substitute this value through this function.
- BR-002 - The function returns an OUTPUT_ARRAY; the caller is responsible for handling an empty or null array if no standard output was captured for the supplied process.
- BR-003 - The process identifier passed to this function must correspond to a process previously registered and accessible by WEBUTIL.GETOUTPUT (SP-038); no independent process validation is performed within this function.

---
**Implementation Logic**

```plsql
    
  FUNCTION Get_Standard_Output(process in PROCESS_ID) return OUTPUT_ARRAY is  
  begin 
    return GetOutput(process,'WUH_STDOUT');
  end Get_Standard_Output;
```

#### SP-045 - WEBUTIL.HOST

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Executes a host operating-system command synchronously from within an Oracle Forms session and returns the process exit code to the caller. The function delegates command execution to WEBUTIL.BLOCKING, waits for completion, retrieves the return code via WEBUTIL.GET_RETURN_CODE, and releases the associated client-side process handle via WEBUTIL.RELEASE_PROCESS. It is invoked by the VIEW_EXCEL_REPORT_NEW procedure in dms_excel_report.pld to launch an external process (e.g., opening a generated Excel file) on the client machine.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.BLOCKING ([SP-016](#SP-016--WEBUTIL.BLOCKING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_RETURN_CODE ([SP-043](#SP-043--WEBUTIL.GET_RETURN_CODE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ID_NULL ([SP-046](#SP-046--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.RELEASE_PROCESS ([SP-060](#SP-060--WEBUTIL.RELEASE_PROCESS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the host command string (cmd) as input and initialise the return code (RC) to -1, representing an unexecuted or failed state.
- Step 2 - Invoke WEBUTIL.BLOCKING (SP-016) with the command string to execute the OS command on the client and obtain a process handle (procId).
- Step 3 - Evaluate whether a valid process handle was returned by calling WEBUTIL.ID_NULL (SP-046) on procId.
- Step 4 - If the process handle is valid, call WEBUTIL.GET_RETURN_CODE (SP-043) with the process handle to retrieve the exit code of the completed process and assign it to RC.
- Step 5 - Release the client-side process object by calling WEBUTIL.RELEASE_PROCESS (SP-060) with the process handle, freeing associated resources.
- Step 6 - Return RC to the caller; a value of -1 indicates the process was never successfully launched, while any other value reflects the actual OS process exit code.

---
**Decision Points**

DP-001

Condition:
WEBUTIL.ID_NULL(procId) evaluates to FALSE - i.e., WEBUTIL.BLOCKING successfully returned a non-null process handle.

TRUE:
Proceed to retrieve the process exit code via WEBUTIL.GET_RETURN_CODE and then release the process handle via WEBUTIL.RELEASE_PROCESS before returning the exit code.

FALSE:
Skip exit-code retrieval and process release; return the default value of -1 to the caller, signalling that the host command was not successfully initiated.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The return code is initialised to -1; this sentinel value is returned whenever the host command fails to produce a valid process handle, ensuring the caller can distinguish a launch failure from a successful execution with exit code 0.
- BR-002 - A host command is only considered successfully executed if WEBUTIL.BLOCKING returns a non-null process handle, as verified by WEBUTIL.ID_NULL; no exit code retrieval is attempted otherwise.
- BR-003 - Every successfully launched process handle must be explicitly released via WEBUTIL.RELEASE_PROCESS immediately after the exit code is obtained, ensuring client-side resources are not leaked.
- BR-004 - Command execution is performed in blocking mode (via WEBUTIL.BLOCKING), meaning the function waits for the OS process to complete before retrieving the return code, guaranteeing that the exit code reflects the final process outcome.

---
**Implementation Logic**

```plsql
  FUNCTION  Host(cmd in VARCHAR2) return PLS_INTEGER is
    procId PROCESS_ID;
    RC     PLS_INTEGER := -1;
  begin
    procId := Blocking(cmd);
    if not ID_NULL(procId) then
      RC := Get_Return_Code(procId);
      -- release the client side object
      Release_Process(procId);
    end if;
    return RC;
  end Host;
```

#### SP-046 - WEBUTIL.ID_NULL

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]
- webutil.pld [StoredProcedure: WEBUTIL.ERRORALERT]
- webutil.pld [StoredProcedure: WEBUTIL.HOST]
- webutil.pld [StoredProcedure: WEBUTIL.INITWEBUTIL]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTER_FUNCTION]
- webutil.pld [StoredProcedure: WEBUTIL.SHOWBEANS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines whether a given handle object is uninitialised by inspecting its internal reference field. Callers across the WEBUTIL library and the DMS Excel report module use this utility function to guard against operations on null or unresolved handles before invoking further WebUtil interactions.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| handle | Pointer | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the incoming Pointer parameter named 'handle'.
- Step 2 - Inspect the 'hnd' attribute of the supplied handle object.
- Step 3 - If 'hnd' is NULL, return TRUE to indicate that the handle is uninitialised.
- Step 4 - If 'hnd' is NOT NULL, return FALSE to indicate that the handle holds a valid reference.

---
**Decision Points**

DP-001

Condition:
The 'hnd' attribute of the supplied handle Pointer is NULL.

TRUE:
The function returns TRUE, signalling to the caller that the handle is uninitialised and no further operations should be performed against it.

FALSE:
The function returns FALSE, signalling to the caller that the handle is valid and downstream processing may continue.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A handle is considered null solely on the basis of its internal 'hnd' attribute; no other attribute or external state is evaluated.
- BR-002 - The function is read-only and produces no side effects; it neither modifies the handle nor interacts with any database object.
- BR-003 - The function must return a BOOLEAN result for every possible input state; no exception path or default return is permitted to leave the result undefined.

---
**Implementation Logic**

```plsql

  FUNCTION ID_NULL(handle IN Pointer)        RETURN BOOLEAN is
  BEGIN
    if handle.hnd is null then 
      return TRUE;
    else
      return FALSE;
    end if;
  END ID_NULL;
```

#### SP-047 - WEBUTIL.INIT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETOUTPUT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.INIT serves as the package-level entry point for the WebUtil core library. Its sole responsibility is to trigger package initialisation by invoking WEBUTIL.INITWEBUTIL (SP-048) through the package body's initialisation block. The INIT procedure itself performs no processing; the act of entering the package is sufficient to execute the initialisation block, which calls INITWEBUTIL to set up the WebUtil environment.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.INITWEBUTIL ([SP-048](#SP-048--WEBUTIL.INITWEBUTIL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - WEBUTIL.INIT is called by WEBUTIL.GETOUTPUT as part of the WebUtil lifecycle.
- Step 2 - The INIT procedure body executes a null statement, performing no direct processing, as entering the package is sufficient to trigger initialisation.
- Step 3 - The package-level initialisation block (BEGIN...END WEBUTIL_CORE) is executed automatically by the PL/SQL runtime upon first reference to the package.
- Step 4 - Within the initialisation block, WEBUTIL.INITWEBUTIL (SP-048) is called to perform the actual setup of the WebUtil utility environment.

---
**Decision Points**

No decision points are present. The procedure body contains only a null statement, and the package initialisation block unconditionally calls WEBUTIL.INITWEBUTIL with no conditional branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The INIT procedure must not contain executable logic; entering the package is architecturally sufficient to trigger the initialisation block and invoke WEBUTIL.INITWEBUTIL.
- BR-002 - WEBUTIL.INITWEBUTIL (SP-048) must always be called as part of the package initialisation block to ensure the WebUtil environment is correctly set up before any other package functionality is used.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Init is
  begin 
    -- we don't need to do anything here - entering the package is enough to set it up.      
    null;
  end;      

BEGIN
  -- Initialise the Utility
  InitWebUtil;  
END WEBUTIL_CORE;

PACKAGE WEBUTIL_C_API IS
/*********************************************************************************\
 * WEBUTIL_C_API
 *   This Package provides a way of calling C functions in a shared library on the
 *   client PC. Currently only win32 is supported.
 *   The oracle.forms.webutil.cApi.CApiFunctions bean is needed in your Form to 
 *   use these functions
 *********************************************************************************
 * Version 1.0.5
 *********************************************************************************
 * Change History
 *   1.0.1 RVSUILIC 14/FEB/2003 - Creation 
 *   1.0.2 DRMILLS  27/FEB/2003 - Reset LONG to the same value as INT which is fine
 *                                for Windows & removed Tester proc
 *   1.0.3 DRMILLS  01/MAR/2003 - Re-worked the PL/SQL API
 *   1.0.4 DRMILLS  13/MAY/2003 - Added call to WebUtil_Core.Init
 *   1.0.5 RVSUILIC 21/MAY/2003 - Cleaned up some comments and formatting.
 *
\*********************************************************************************/

  /**
   *  Constants to represent PL/SQL IN, OUT and INOUT parameter qualifiers
   */
  PARAM_IN    CONSTANT PLS_INTEGER := 50;
  PARAM_INOUT CONSTANT PLS_INTEGER := 51;
  PARAM_OUT   CONSTANT PLS_INTEGER := 52;
  

  /**
   *  Constants to represent C atomic datatypes and pointers to atomic datatypes
   *  Note that to use OUT and INOUT qualifiers the C function in the DLL *must*
   *  use a pointer type to be able to pass information back.
   *
   *  The comments on the right indicate which types can be used for parameters
   *  and which for function return types.
   *
   *  c_ptr is used as a generic pointer. The onlys supported use for this is to
   *  save the pointer value from C into a PL/SQL variable, so that it may be 
   *  passed back later to C. No operations on the pointer are supported in PL/SQL.
   */
  c_void          CONSTANT PLS_INTEGER := 30;            /* - not used -   */
  c_char          CONSTANT PLS_INTEGER := 31;            /* param & return */
  c_short         CONSTANT PLS_INTEGER := 32;            /* param & return */
  c_int           CONSTANT PLS_INTEGER := 33;            /* param & return */
  c_long          CONSTANT PLS_INTEGER := 33;            /* param & return *//*DRM - same as INT */
  c_float         CONSTANT PLS_INTEGER := 35;            /* param & return */
  c_double        CONSTANT PLS_INTEGER := 36;            /* param & return */

  c_ptr           CONSTANT PLS_INTEGER := 64 + c_void;   /* param & return */
  c_char_ptr      CONSTANT PLS_INTEGER := 64 + c_char;   /* param          */
  c_short_ptr     CONSTANT PLS_INTEGER := 64 + c_short;  /* param          */
  c_int_ptr       CONSTANT PLS_INTEGER := 64 + c_int;    /* param          */
  c_long_ptr      CONSTANT PLS_INTEGER := 64 + c_long;   /* param          */
  c_float_ptr     CONSTANT PLS_INTEGER := 64 + c_float;  /* param          */
  c_double_ptr    CONSTANT PLS_INTEGER := 64 + c_double; /* param          */

  /**
   *  Abstracted types to be used for pointers and handles. The forms programmer
   *  should not attempt any manipulation on these types, but merely obtain them as
   *  a result of functions below, and pass them back in to other functions below.
   */
    SUBTYPE handleType   IS NUMBER;
    TYPE Pointer         IS RECORD (hnd handleType);   /* C pointer             */
    TYPE FunctionHandle  IS RECORD (hnd handleType);   /* function handle       */
    TYPE ParameterHandle IS RECORD (hnd handleType);   /* parameter handle      */
    TYPE ParameterList   IS RECORD (hnd handleType);   /* parameter list handle */

  /**
   *  IS_SUPPORTED - Check if the client is on a supported hardware platform.
   */
```

#### SP-048 - WEBUTIL.INITWEBUTIL

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.INIT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Initialises the WebUtil framework within an Oracle Form by registering the implementation class names for all known WebUtil packages, verifying that the mandatory WebUtil object group (including its error alert and dummy item) is present in the form, optionally triggering bean-area rendering, and determining the server-side file-path separator based on the host operating system. This procedure must complete successfully before any other WebUtil functionality can be used.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-046](#SP-046--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SHOWBEANS ([SP-064](#SP-064--WEBUTIL.SHOWBEANS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Capture the current cursor field (SYSTEM.CURSOR_FIELD) and locate the WebUtil dummy item (WEBUTIL_DUMMY_ITEM) so that navigation can be restored or controlled later.
- Step 2 - Populate the package-to-implementation-class registry (m_implClasses) with the Java bean class names for all ten known WebUtil packages: WUC (VBeanCommon), WUT (FileTransfer), WUF (FileFunctions), WUI (GetClientInfo), WUH (Host), WUS (SessionFunctions), WUB (BrowserFunctions), WUO (OleFunctions), WUU (empty/custom), and WUL (CApiFunctions).
- Step 3 - Check whether the WebUtil error-alert object (m_errorAlert) is null via WEBUTIL.ID_NULL. If it is null, the required WebUtil object group is absent; display an error message and pause execution, preventing further initialisation.
- Step 4 - If the error alert is present and the explicit-instantiation flag (FLAG_EXPICIT_INSTANCIATE) is enabled and the form is in NORMAL mode, proceed with bean-area setup.
- Step 5 - Within the bean-area setup path, verify that the dummy item handle (hDummy) is not null via WEBUTIL.ID_NULL, confirming the standard WebUtil object group is in use.
- Step 6 - Navigate to the dummy item (GO_ITEM) to force bean-area rendering. If the dummy item resides in the same block as the original cursor position, advance to the next block (NEXT_BLOCK); otherwise navigate back to the original cursor field (GO_ITEM(startPoint)).
- Step 7 - Call WEBUTIL.SHOWBEANS(false) to render the bean areas without forcing focus, completing the visual initialisation of WebUtil components.
- Step 8 - If the dummy item handle is null, take no navigation action, deferring bean-area setup to the calling programmer.
- Step 9 - Determine the server operating system by inspecting GET_APPLICATION_PROPERTY(OPERATING_SYSTEM). If the OS name contains 'WIN', set the server file-path separator (m_serverFileSep) to backslash; otherwise set it to forward slash.

---
**Decision Points**

DP-001

Condition: WEBUTIL.ID_NULL(m_errorAlert) returns TRUE (the WebUtil error alert object is not present in the form).

TRUE: Display the message 'The WEBUTIL object group is not available in this Form. WebUtil cannot work', pause execution, and abort all further initialisation steps.

FALSE: The WebUtil object group is confirmed present; continue with bean-area setup and OS detection.

---

DP-002

Condition: FLAG_EXPICIT_INSTANCIATE is TRUE AND SYSTEM.MODE equals 'NORMAL'.

TRUE: Proceed with explicit bean-area instantiation logic (dummy-item check, navigation, and SHOWBEANS call).

FALSE: Skip explicit bean-area instantiation entirely; proceed directly to server OS detection.

---

DP-003

Condition: WEBUTIL.ID_NULL(hDummy) returns FALSE (the dummy item is found, indicating the standard WebUtil object group is in use).

TRUE: Navigate to the dummy item, conditionally advance to the next block or return to the original cursor field, then call WEBUTIL.SHOWBEANS(false) to render bean areas.

FALSE: The dummy item is absent, meaning the developer is managing bean-area setup independently; no navigation or SHOWBEANS call is made.

---

DP-004

Condition: After navigating to the dummy item, GET_ITEM_PROPERTY(startPoint, BLOCK_NAME) equals GET_ITEM_PROPERTY(hDummy, BLOCK_NAME) (the original cursor field is in the same block as the dummy item).

TRUE: Call NEXT_BLOCK to move focus out of the dummy item's block before calling SHOWBEANS.

FALSE: Navigate directly back to the original cursor field (GO_ITEM(startPoint)) before calling SHOWBEANS.

---

DP-005

Condition: INSTR(UPPER(GET_APPLICATION_PROPERTY(OPERATING_SYSTEM)), 'WIN') > 0 (the server operating system name contains 'WIN').

TRUE: Set m_serverFileSep to backslash ('\') for Windows-style file paths.

FALSE: Set m_serverFileSep to forward slash ('/') for Unix/Linux-style file paths.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The WebUtil framework cannot initialise unless the WebUtil object group, including its error alert (m_errorAlert), is present in the calling form; absence causes an immediate halt with a user-visible error message.
- BR-002 - All ten WebUtil package-to-Java-class mappings must be registered in m_implClasses during initialisation before any WebUtil package functionality is invoked.
- BR-003 - Explicit bean-area instantiation via navigation and WEBUTIL.SHOWBEANS is performed only when FLAG_EXPICIT_INSTANCIATE is enabled and the form is in NORMAL mode; Enter-Query mode must never trigger this navigation to avoid known defects.
- BR-004 - When performing dummy-item navigation, the procedure must restore the user's original cursor position: if the dummy item shares a block with the starting field, focus advances to the next block; otherwise focus returns directly to the original field.
- BR-005 - WEBUTIL.SHOWBEANS is called with the parameter FALSE, meaning bean areas are rendered without forcing user focus to them.
- BR-006 - If the standard WebUtil dummy item is not found, the procedure assumes the developer is responsible for bean-area setup and takes no navigation or rendering action.
- BR-007 - The server file-path separator (m_serverFileSep) must be set during initialisation based on the actual server OS and must not be hard-coded; Windows environments use backslash and all others use forward slash.

---
**Implementation Logic**

```plsql
  
  PROCEDURE InitWebUtil is
    startPoint VARCHAR2(61 char) := NAME_IN('SYSTEM.CURSOR_FIELD');
    hDummy     ITEM              := FIND_ITEM(WEBUTIL_DUMMY_ITEM);
  BEGIN
    -- Set up the various package we know about.
    m_implClasses(WUC_PACKAGE) := 'common.VBeanCommon'; 
    m_implClasses(WUT_PACKAGE) := 'fileTransfer.FileTransfer'; 
    m_implClasses(WUF_PACKAGE) := 'file.FileFunctions'; 
    m_implClasses(WUI_PACKAGE) := 'clientInfo.GetClientInfo'; 
    m_implClasses(WUH_PACKAGE) := 'host.Host'; 
    m_implClasses(WUS_PACKAGE) := 'session.SessionFunctions'; 
    m_implClasses(WUB_PACKAGE) := 'browser.BrowserFunctions'; 
    m_implClasses(WUO_PACKAGE) := 'ole.OleFunctions'; 
    m_implClasses(WUU_PACKAGE) := '';      
    m_implClasses(WUL_PACKAGE) := 'cApi.CApiFunctions';                     
    
    -- Now check for the Webutil Object group which 
    -- contains the Beans etc.
          
    if id_null(m_errorAlert) then 
      -- The Webutil error alert is not around
      -- so the Code cannot operate 
      message('The WEBUTIL object group is not available in this Form.  WebUtil cannot work');
      pause;
    else
      -- Bug 2955789 - this navigation causes problems if they are in Enter-Query mode 
      -- Plus it's not really needed, except as a belt and braces kind of setup.
      -- So put a check to prevent this in E-Q mode and set a top level flag to bypass it 
      -- it all together which we can switch on or off if required as a furture W/A    
      if FLAG_EXPICIT_INSTANCIATE and name_in('SYSTEM.MODE') = 'NORMAL' then 
        if not ID_NULL(hDummy) then 
          -- they are using the standard Object Group
          GO_ITEM(hDummy);
          if GET_ITEM_PROPERTY(startPoint,BLOCK_NAME) = GET_ITEM_PROPERTY(hDummy,BLOCK_NAME) then 
            NEXT_BLOCK;
          else
            GO_ITEM(startPoint);
          end if;
          ShowBeans(false);        
        else
          -- do nothing assume that the programmer is doing their own thing.
          -- with regards to setting up the bean areas and making sure they are drawn
           null;      
        end if;
      end if;
    end if;
        
    -- Work out the server o/s informtion that we need
    if instr(upper(GET_APPLICATION_PROPERTY(OPERATING_SYSTEM)),'WIN') > 0 then 
      m_serverFileSep := '\';
    else
      m_serverFileSep := '/';
    end if;
  END InitWebUtil;
```

#### SP-049 - WEBUTIL.ISERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns a Boolean indicator of whether the most recent WebUtil operation resulted in an error. It evaluates the internal module-level variable `m_lastError` and returns TRUE if a non-zero error code is present, allowing callers such as WEBUTIL.LOG to branch on error state without directly inspecting the error variable.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Read the module-level variable `m_lastError`, which holds the error code set by the most recently executed WebUtil operation.
- Step 2 - Compare `m_lastError` against zero to determine whether an error condition exists.
- Step 3 - Return TRUE if `m_lastError` is not equal to zero (an error is present), or FALSE if `m_lastError` equals zero (no error).

---
**Decision Points**

DP-001

Condition: `m_lastError <> 0`

TRUE: The function returns TRUE, indicating that the last WebUtil operation raised an error.

FALSE: The function returns FALSE, indicating that the last WebUtil operation completed without an error.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A non-zero value in `m_lastError` is the sole criterion for classifying the last WebUtil operation as failed; any non-zero code, regardless of its specific value, is treated as an error condition.
- BR-002 - The function is read-only; it inspects `m_lastError` but does not modify it, ensuring that calling ISERROR does not alter the error state of the WebUtil session.
- BR-003 - The function accepts no input parameters; error state is determined entirely from the module-level variable `m_lastError`, making the result implicitly scoped to the current WebUtil execution context.

---
**Implementation Logic**

```plsql
  FUNCTION isError   return BOOLEAN is
  begin 
    return m_lastError <> 0;
  end;
```

#### SP-050 - WEBUTIL.IS_OPEN

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines whether a given file handle is currently open by inspecting the handle attribute of the supplied FILE_TYPE parameter. Returns TRUE if the file is open and FALSE if it is not, allowing callers such as WEBUTIL.LOG to guard against operations on unopened files.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FILE_TYPE input parameter representing the file to be checked.
- Step 2 - Inspect the handle attribute of the supplied FILE_TYPE value.
- Step 3 - If the handle is NULL, return FALSE to indicate the file is not open.
- Step 4 - If the handle is not NULL, return TRUE to indicate the file is open.

---
**Decision Points**

DP-001

Condition: file.handle IS NULL

TRUE: The file handle has not been assigned; the function returns FALSE, signalling that the file is not open.

FALSE: The file handle holds a non-NULL value; the function returns TRUE, signalling that the file is open.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A FILE_TYPE instance is considered open if and only if its handle attribute is non-NULL; a NULL handle unconditionally indicates a closed or uninitialised file.
- BR-002 - The function is read-only with respect to the FILE_TYPE parameter; it performs no modification to the file handle or any other state.
- BR-003 - No database interaction or external dependency is permitted within this function; the open/closed determination is based solely on the in-memory handle attribute of the supplied parameter.

---
**Implementation Logic**

```plsql
  
  FUNCTION is_open(file file_type) RETURN BOOLEAN IS
  BEGIN
    IF file.handle IS NULL THEN
      RETURN(FALSE);
    ELSE
      RETURN(TRUE);
    END IF;
  END is_open;
```

#### SP-051 - WEBUTIL.LENGTH

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: DEBUGLOG]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: STRIPDIRSEP]
- webutil.pld [StoredProcedure: WEBUTIL.GETSTRING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the byte length of a file represented by a Java File object. The function delegates to the native Java method java.io.File.length() via the ORA_JAVA/JNI bridge, providing Oracle Forms PL/SQL routines with a means to determine file size without direct database interaction.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java File object (obj) passed in by the calling routine (e.g., WEBUTIL.GETSTRING, D2KWUTIL.CHOOSEFILE, STRIPDIRSEP, DEBUGLOG, or REGISTER_FUNCTION_CALL).
- Step 2 - Clear the JNI argument list by setting args to NULL, ensuring no stale arguments are carried over from a previous call.
- Step 3 - Invoke the Java instance method java.io.File.length() on the supplied object via JNI.CALL_LONG_METHOD, passing FALSE (non-static call), the target object, the class path 'java/io/File', the method name 'length', and the descriptor '()J' (no-argument method returning a long).
- Step 4 - Return the numeric result (file size in bytes) to the caller.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a single deterministic JNI call and returns the result unconditionally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The argument list (args) must be explicitly reset to NULL before invoking the JNI method to prevent argument contamination from prior calls.
- BR-002 - The function operates on an already-instantiated Java File object (ORA_JAVA.JOBJECT); the caller is responsible for supplying a valid, non-null object reference.
- BR-003 - File size is retrieved via the standard Java java.io.File.length() contract, which returns 0 if the file does not exist or its length cannot be determined; no additional validation or error handling is applied within this function.
- BR-004 - The return value is expressed as a NUMBER representing the file size in bytes, consistent with the long (64-bit integer) type returned by the underlying Java method.

---
**Implementation Logic**

```plsql
  FUNCTION length(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_LONG_METHOD(FALSE, obj, 'java/io/File', 'length', '()J', args); 
  END;
```

#### SP-052 - WEBUTIL.LOG

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]
- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.LOG writes diagnostic and error messages to a server-side log file on behalf of the WebUtil framework. On first invocation it reads logging configuration from the property bundle (enabled flag, errors-only flag, and target file path), caches those settings in package-level variables, and communicates the resolved logging mode to the registered WebUtil bean via a client property. On subsequent calls it uses the cached settings to append the supplied message-optionally prefixed with the client IP address and username-to the configured log file, subject to whether full or error-only logging is active.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| msg | VARCHAR2 | IN |
| isError | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-024](#SP-024--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ISERROR ([SP-049](#SP-049--WEBUTIL.ISERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.IS_OPEN ([SP-050](#SP-050--WEBUTIL.IS_OPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.PUT_LINE ([SP-055](#SP-055--WEBUTIL.PUT_LINE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-056](#SP-056--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Check whether the logging configuration cache has been initialised (m_loggingAllowed IS NULL). If not yet initialised, proceed to Steps 2-7; otherwise skip to Step 8.
- Step 2 - Call WEBUTIL.READFROMPROPERTYBUNDLE to retrieve 'logging.enabled', 'logging.errorsonly', and 'logging.file', and store the results in the package-level variables m_loggingAllowed, m_loggingErrorsOnly, and m_loggingFile respectively.
- Step 3 - If logging is flagged as allowed but no log file path was returned (m_loggingFile IS NULL), force m_loggingAllowed to FALSE and raise error WUC-008: if no bean is registered yet, call WEBUTIL.ERRORALERT to display the message in English; otherwise push property WUC_SRV_LOGGING = '0' to the bean and raise the structured error via WebUtil_Core.error.
- Step 4 - If at least one bean is registered, communicate the resolved logging mode to the client by setting the WUC_SRV_LOGGING property: '1' for errors-only logging, '2' for full logging, or '0' for logging disabled.
- Step 5 - After configuration is resolved (or was already cached), evaluate whether logging is currently allowed (m_loggingAllowed = TRUE).
- Step 6 - If logging is allowed, evaluate whether the current message qualifies for writing: it qualifies if errors-only mode is off, or if errors-only mode is on and the isError parameter is TRUE.
- Step 7 - Open the log file in append mode using TEXT_IO.FOPEN. Verify the file is open via TEXT_IO.IS_OPEN; if not, raise NO_DATA_FOUND.
- Step 8 - Write the message to the log file using TEXT_IO.PUT_LINE. If m_clientIP is populated, prefix the message with the client IP address and username (format: '<IP>:<username>: <msg>'); otherwise write the message as-is.
- Step 9 - Close the log file with TEXT_IO.FCLOSE.
- Step 10 - In the exception handler, if SQLCODE = -302000 (file write failure), disable logging (m_loggingAllowed := FALSE) and raise error WUC-007: if no bean is registered, call WEBUTIL.ERRORALERT; otherwise push WUC_SRV_LOGGING = '0' and raise the structured error. For all other exceptions, re-raise.

---
**Decision Points**

DP-001

Condition: m_loggingAllowed IS NULL (logging configuration has not yet been cached for this session).

TRUE: Read logging configuration from the property bundle via WEBUTIL.READFROMPROPERTYBUNDLE and populate the package-level cache variables before proceeding.

FALSE: Skip configuration initialisation and proceed directly to the log-write evaluation using the already-cached settings.

---

DP-002

Condition: m_loggingAllowed is TRUE after reading the property bundle AND m_loggingFile IS NULL.

TRUE: Force m_loggingAllowed to FALSE and raise error WUC-008 (no log file specified). Delivery method depends on DP-003.

FALSE: Logging is either disabled by configuration or a valid file path exists; no error is raised for a missing file.

---

DP-003

Condition: m_registeredPackages.FIRST IS NULL (no WebUtil bean has been registered yet) - evaluated when an error must be reported (WUC-007 or WUC-008).

TRUE: Call WEBUTIL.ERRORALERT to display the error message in plain English via a Forms alert (no bean communication is possible).

FALSE: Push WUC_SRV_LOGGING = '0' to the registered bean and raise the structured error through WebUtil_Core.error.

---

DP-004

Condition: At least one bean is registered (m_registeredPackages.FIRST IS NOT NULL) during configuration initialisation.

TRUE: Set the WUC_SRV_LOGGING client property to '1' (errors-only), '2' (full logging), or '0' (disabled) to synchronise the client-side logging state.

FALSE: Skip the client property update; the bean is not yet available to receive property calls.

---

DP-005

Condition: m_loggingAllowed is TRUE at the point of the log-write attempt.

TRUE: Evaluate whether the message qualifies for writing (see DP-006).

FALSE: Suppress the message entirely; no file I/O is performed.

---

DP-006

Condition: m_loggingErrorsOnly is FALSE, OR (m_loggingErrorsOnly is TRUE AND the isError parameter is TRUE).

TRUE: Open the log file and write the message.

FALSE: Suppress the message; it does not meet the errors-only threshold.

---

DP-007

Condition: m_clientIP IS NULL at the time of writing.

TRUE: Write the raw message string to the log file without any prefix.

FALSE: Prefix the message with the client IP address and username ('<IP>:<username>: <msg>') before writing.

---

DP-008

Condition: SQLCODE = -302000 in the exception handler (file write failure).

TRUE: Disable logging (m_loggingAllowed := FALSE), raise error WUC-007 via WEBUTIL.ERRORALERT or WebUtil_Core.error depending on bean registration state (DP-003).

FALSE: Re-raise the original exception unchanged.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Logging configuration (enabled flag, errors-only flag, and file path) is read from the property bundle exactly once per session via WEBUTIL.READFROMPROPERTYBUNDLE and cached in package-level variables; subsequent calls to WEBUTIL.LOG reuse the cache without re-reading the bundle.
- BR-002 - If logging is enabled in the property bundle but no log file path is provided, logging must be automatically disabled and error WUC-008 must be raised; the absence of a file path is treated as a fatal configuration error that prevents any log writes.
- BR-003 - When errors-only mode is active (logging.errorsonly = 'true'), only messages passed with isError = TRUE are written to the log file; informational messages are silently suppressed.
- BR-004 - The log file is opened in append mode for each write operation and closed immediately afterwards; the procedure does not hold the file open between calls.
- BR-005 - If a client IP address is available (m_clientIP IS NOT NULL), every log entry must be prefixed with the client IP address and username to provide audit traceability.
- BR-006 - A file write failure identified by SQLCODE -302000 must permanently disable logging for the session (m_loggingAllowed := FALSE) and raise error WUC-007; all other exceptions are re-raised without suppression.
- BR-007 - The resolved logging mode must be communicated to the registered WebUtil bean via the WUC_SRV_LOGGING property ('0' = disabled, '1' = errors-only, '2' = full) whenever at least one bean is registered at the time of configuration initialisation.
- BR-008 - When a configuration or write error must be reported and no bean is registered, WEBUTIL.ERRORALERT must be used to surface the error in plain English; structured bean-based error reporting is only permitted when a bean is available.

---
**Implementation Logic**

```plsql
  

  PROCEDURE Log(msg in VARCHAR2, isError BOOLEAN) is
    logFile       TEXT_IO.FILE_TYPE;
    logFileName   VARCHAR2(1024 char);
    errorOnlyMode BOOLEAN;
  begin
    -- check to see if we should do anything
    if m_loggingAllowed is null then 
      -- set up the logging info Cache
      m_loggingAllowed    := (lower(ReadFromPropertyBundle('logging.enabled')) = 'true');
      m_loggingErrorsOnly := (lower(ReadFromPropertyBundle('logging.errorsonly')) = 'true');
      m_loggingFile       := ReadFromPropertyBundle('logging.file');
      if m_loggingAllowed then 
        if m_loggingFile is null then 
          -- no file == no logging
          m_loggingAllowed := false;
          if m_registeredPackages.FIRST is null then
            -- There is no bean registered yet. Throw error in English using alert
            ErrorAlert('WUC-008: Server side logging was requested but no log file was specified'
                       ||' - logging is disabled');
          else
            WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
            WebUtil_Core.error(WUC_PACKAGE,8,'WebUtil_Core.Log');
          end if;
        end if;
      end if;
      if m_registeredPackages.FIRST is not null then
        -- At least one bean is registered. Can call setProperty(WUC_PACKAGE)
        if m_loggingAllowed and m_loggingErrorsOnly then
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','1',true);
        elsif  m_loggingAllowed then
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','2',true);
        else
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
        end if;
      end if;
    end if;
        
    -- now log if allowed to do so
    if m_loggingAllowed then
      if ((not m_loggingErrorsOnly) or (m_loggingErrorsOnly and isError)) then
        logFile := TEXT_IO.FOPEN(m_loggingFile,'A');
        if not TEXT_IO.IS_OPEN(logFile) then 
          raise NO_DATA_FOUND;
        end if;
        if m_clientIP is null then
        	TEXT_IO.PUT_LINE(logFile,msg);
        else
        	TEXT_IO.PUT_LINE(logFile,m_clientIP||':'||m_clientUserName||': '||msg);
        end if;
        TEXT_IO.FCLOSE(logFile);
      end if;    
    end if;
  EXCEPTION
    when others then 
      if SQLCODE = '-302000' then
        if m_registeredPackages.FIRST is null then
          -- There is no bean registered yet. Throw error in English using alert
          ErrorAlert('WUC-007: Unable to write to WebUtil Logging File '|| m_loggingFile);
        else

          WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
          WebUtil_Core.error(WebUtil_Core.WUC_PACKAGE,7,'WebUtil_Core.Log',m_loggingFile);
        end if;
        m_loggingAllowed := false;
      else
        RAISE;
      end if;      
  end Log;
```

#### SP-053 - WEBUTIL.POPULATEPROPERTYBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.READFROMPROPERTYBUNDLE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Locates and reads the WebUtil configuration file, parses its key-value property pairs into the in-memory property bundle (m_propertyBundle), and returns the value associated with the requested property key. The procedure resolves the configuration file path from three sources in priority order: a Forms global variable, an environment variable, and a Forms parameter. It is invoked by WEBUTIL.READFROMPROPERTYBUNDLE to supply configuration values at runtime.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-024](#SP-024--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Read the configuration file path from the Forms global variable identified by WEBUTIL_CONFIG_GLOBAL; if the global holds the sentinel value '[NOTSET]', treat it as unset.
- Step 2 - If the global is unset, attempt to retrieve the configuration file path from the operating-system environment variable identified by WEBUTIL_CONFIG_ENV using TOOL_ENV.GETVAR.
- Step 3 - If the environment variable also yields no value, fall back to reading the configuration file path from the Forms parameter identified by WEBUTIL_CONFIG_PARAM.
- Step 4 - If all three sources fail to provide a path, raise NO_DATA_FOUND to trigger error handling.
- Step 5 - Persist the resolved configuration file path back into WEBUTIL_CONFIG_GLOBAL so that subsequent calls do not need to re-resolve it.
- Step 6 - Open the resolved configuration file for reading using TEXT_IO.FOPEN.
- Step 7 - Read the file line by line in a loop using TEXT_IO.GET_LINE; exit the loop when NO_DATA_FOUND is raised (end of file).
- Step 8 - Skip any line whose first character is '#' (comment line).
- Step 9 - For non-comment lines, locate the '=' delimiter using INSTR; skip lines that contain no '=' character.
- Step 10 - For valid key-value lines, increment the property index, store the trimmed, lower-cased key and the trimmed, CR-stripped value into the next slot of m_propertyBundle.
- Step 11 - Compare the stored key against the lower-cased input propertyKey; if they match, capture the corresponding value into the result variable.
- Step 12 - After the loop completes, close the configuration file using TEXT_IO.FCLOSE and return the result value (NULL if the key was not found).
- Step 13 - On NO_DATA_FOUND exception (no configuration file path resolved): if no bean package is yet registered (m_registeredPackages is empty), invoke WEBUTIL.ERRORALERT to display error 'WUC-005: No WebUtil Configuration File specified'; otherwise delegate to Webutil_Core.Error. Set m_config_error to TRUE and return NULL.
- Step 14 - On SQLCODE -302000 (file read failure): if no bean package is registered, invoke WEBUTIL.ERRORALERT to display error 'WUC-006: Unable to read WebUtil Configuration File'; otherwise delegate to Webutil_Core.Error. Set m_config_error to TRUE and return NULL.
- Step 15 - Re-raise any other unexpected exception.

---
**Decision Points**

DP-001
Condition: The value held in WEBUTIL_CONFIG_GLOBAL equals the sentinel '[NOTSET]'.
TRUE: Clear the local configFile variable and attempt to resolve the path from the environment variable WEBUTIL_CONFIG_ENV.
FALSE: Use the value from WEBUTIL_CONFIG_GLOBAL as the configuration file path and proceed to open the file.

DP-002
Condition: The environment variable WEBUTIL_CONFIG_ENV returns a non-null value.
TRUE: Use the returned value as the configuration file path.
FALSE: Attempt to resolve the path from the Forms parameter WEBUTIL_CONFIG_PARAM.

DP-003
Condition: The Forms parameter WEBUTIL_CONFIG_PARAM returns a non-null value.
TRUE: Use the returned value as the configuration file path.
FALSE: Raise NO_DATA_FOUND to enter error handling; no configuration file path is available.

DP-004
Condition: The first character of the current file line is '#'.
TRUE: Skip the line entirely (comment); continue to the next iteration.
FALSE: Attempt to parse the line as a key-value pair.

DP-005
Condition: The current non-comment line contains an '=' character (INSTR result > 0).
TRUE: Parse the line into a key-value pair and store it in m_propertyBundle.
FALSE: Skip the line; it is not a valid key-value entry.

DP-006
Condition: The parsed property key matches the lower-cased input propertyKey.
TRUE: Assign the corresponding property value to the result variable.
FALSE: Continue processing remaining lines without updating the result.

DP-007
Condition: NO_DATA_FOUND exception is raised and m_registeredPackages.FIRST is NULL (no bean registered).
TRUE: Call WEBUTIL.ERRORALERT with message 'WUC-005: No WebUtil Configuration File specified'.
FALSE: Delegate the error to Webutil_Core.Error with error code WUC_PACKAGE / 5.

DP-008
Condition: SQLCODE -302000 is raised (file read failure) and m_registeredPackages.FIRST is NULL (no bean registered).
TRUE: Call WEBUTIL.ERRORALERT with message 'WUC-006: Unable to read WebUtil Configuration File'.
FALSE: Delegate the error to Webutil_Core.Error with error code WUC_PACKAGE / 6, passing configFile as context.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The configuration file path must be obtainable from exactly one of three sources in strict priority order: (1) the Forms global variable WEBUTIL_CONFIG_GLOBAL, (2) the environment variable WEBUTIL_CONFIG_ENV, (3) the Forms parameter WEBUTIL_CONFIG_PARAM. If none provides a value, processing cannot continue.
- BR-002 - Once the configuration file path is resolved from any source, it must be written back to WEBUTIL_CONFIG_GLOBAL to cache it for subsequent invocations.
- BR-003 - Lines beginning with '#' are treated as comments and must be ignored during parsing.
- BR-004 - Only lines containing an '=' character are treated as valid property entries; lines without '=' are silently skipped.
- BR-005 - Property keys are normalised to lower case and stripped of leading and trailing whitespace before storage and comparison, ensuring case-insensitive key lookup.
- BR-006 - Property values are stripped of leading and trailing whitespace and carriage-return characters (CHR(13)) before storage, ensuring clean values regardless of file line endings.
- BR-007 - When no configuration file path can be resolved (NO_DATA_FOUND) or the file cannot be read (SQLCODE -302000), the flag m_config_error must be set to TRUE and the function must return NULL, signalling a configuration failure to the caller.
- BR-008 - User-facing error messages are displayed via WEBUTIL.ERRORALERT only when no bean package has yet been registered (m_registeredPackages is empty); if a bean is registered, error reporting is delegated to the Webutil_Core framework.
- BR-009 - Any exception other than NO_DATA_FOUND and SQLCODE -302000 must be re-raised, preserving the original error for upstream handling.

---
**Implementation Logic**

```plsql
      
  FUNCTION PopulatePropertyBundle(propertyKey in VARCHAR2) return VARCHAR2 is
    configFile   VARCHAR2(512 char);
    buffer       VARCHAR2(1000 char);
    result       VARCHAR2(1000 char);          
    propertyFile TEXT_IO.FILE_TYPE;
    pos          PLS_INTEGER;
    propIndex    PLS_INTEGER := 0;
  begin
    -- First of get the name of the cfg file 
    -- This could come in a global  or from the Environment
    default_value('[NOTSET]',WEBUTIL_CONFIG_GLOBAL);
    configFile := name_in(WEBUTIL_CONFIG_GLOBAL);
    if configFile = '[NOTSET]' then
      configFile := null; 
      -- Try the environment
      TOOL_ENV.GETVAR(WEBUTIL_CONFIG_ENV, configFile); 
      if configFile is null then 
        -- Finally try the Forms parameters
        configFile := name_in(WEBUTIL_CONFIG_PARAM);
        -- if that fails then we have to raise an error
        if configFile is null then 
          raise NO_DATA_FOUND;
        end if;    
      end if;
    end if;
    
    copy(configFile, WEBUTIL_CONFIG_GLOBAL);
      
    propertyFile := Text_IO.FOpen(configFile,'R');
    LOOP
      begin
        Text_IO.Get_Line(propertyFile,buffer);
      exception
        when NO_DATA_FOUND then EXIT;
      end;
        
      -- ignore lines which start with '#'
      if substr(buffer,1,1) <> '#' then 
        pos := instr(buffer,'=');
        -- only process lines with a name value pair
        if pos > 0 then 
          propIndex := propIndex + 1;
          m_propertyBundle(propIndex).propertyKey   := lower(ltrim(rtrim(substr(buffer,1,pos-1))));    
          m_propertyBundle(propIndex).propertyValue := ltrim(rtrim(replace(substr(buffer,pos+1),chr(13),'')));
          -- Check to see if this is the key we are looking for
          if  m_propertyBundle(propIndex).propertyKey = lower(propertyKey) then
            result := m_propertyBundle(propIndex).propertyValue;
          end if;
        end if;
      end if;
    end LOOP;
    Text_IO.FClose(propertyFile);
    return result;
  EXCEPTION
    when NO_DATA_FOUND then 
      if m_registeredPackages.FIRST is null then
        -- There is no bean registered yet. Throw error in English using alert
        ErrorAlert('WUC-005: No WebUtil Configuration File specified');
      else
        Webutil_Core.Error(Webutil_Core.WUC_PACKAGE,5,'WebUtil_Core.PopulatePropertyBundle');
      end if;
      m_config_error := true;
      return null;
    when others then 
      if SQLCODE = '-302000' then
        if m_registeredPackages.FIRST is null then
          -- There is no bean registered yet. Throw error in English using alert
          ErrorAlert('WUC-006: Unable to read WebUtil Configuration File');
        else
          Webutil_Core.Error(Webutil_Core.WUC_PACKAGE,6,'WebUtil_Core.PopulatePropertyBundle', configFile);
        end if;
        m_config_error := true;
        return null;
      else
        RAISE;
      end if;      

  end PopulatePropertyBundle;
```

#### SP-054 - WEBUTIL.PUTF

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a formatted text string to an open client-side file by delegating to the WebUtil Core bean infrastructure. The procedure sets the target file handle and the text argument as bean properties, enabling the Oracle Forms WebUtil layer to perform the actual client-side text output. It is invoked during Excel report generation to stream content to the client file system.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |
| arg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the target file handle (`file.file_type`) and the text string (`arg`) to be written.
- Step 2 - Pass the file handle to the WebUtil Core bean by setting the `WUF_TEXTIO_HANDLE` property on the `WUF_PACKAGE` bean, identifying which open client file should receive the output.
- Step 3 - Pass the formatted text argument to the WebUtil Core bean by setting the `WUF_TEXTIO_PUTF` property on the `WUF_PACKAGE` bean, triggering the actual write operation on the client side.
- Step 4 - If the WebUtil bean is not registered (`BEAN_NOT_REGISTERED` exception), display an error alert identifying the missing implementation class and raise `TOOL_ERR.TOOL_ERROR` to halt processing.
- Step 5 - If a property set operation fails (`PROPERTY_ERROR` exception), raise `TOOL_ERR.TOOL_ERROR` to halt processing without an additional alert.

---
**Decision Points**

DP-001

Condition:
The WebUtil Core bean for `WUF_PACKAGE` is registered and available when `setProperty` is called.

TRUE:
Both `WUF_TEXTIO_HANDLE` and `WUF_TEXTIO_PUTF` properties are set successfully; the text is written to the client file and the procedure completes normally.

FALSE:
A `BEAN_NOT_REGISTERED` exception is raised; an error alert is displayed naming the missing implementation class, and `TOOL_ERR.TOOL_ERROR` is raised to abort the calling process.

---

DP-002

Condition:
A `setProperty` call succeeds without raising a `PROPERTY_ERROR` exception.

TRUE:
The property is accepted by the bean and processing continues to the next step.

FALSE:
A `PROPERTY_ERROR` exception is raised; `TOOL_ERR.TOOL_ERROR` is raised immediately to abort the calling process (no additional alert is shown).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The WebUtil Core bean identified by `WUF_PACKAGE` must be registered on the client before this procedure is called; absence of the bean is a fatal error that prevents any client-side text file write.
- BR-002 - The file handle must be set as a bean property (`WUF_TEXTIO_HANDLE`) before the text argument (`WUF_TEXTIO_PUTF`) is set, establishing the correct write target prior to issuing the write command.
- BR-003 - Any bean or property error is treated as unrecoverable; the procedure raises `TOOL_ERR.TOOL_ERROR` in both exception paths, ensuring the caller is always notified of a failure to write.
- BR-004 - A descriptive error alert is issued only for a missing bean (`BEAN_NOT_REGISTERED`); a property-level error (`PROPERTY_ERROR`) raises the tool error silently, relying on the caller or framework for user notification.

---
**Implementation Logic**

```plsql
   
  
  
  procedure putf (file   file_type, 
                  arg    VARCHAR2) is 
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);              
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_PUTF',arg); 
  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.putf will not work');
      RAISE TOOL_ERR.TOOL_ERROR;                                                                 
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE TOOL_ERR.TOOL_ERROR;  
  END putf;
```

#### SP-055 - WEBUTIL.PUT_LINE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a single line of text to an open client-side file by transmitting the file handle, the text content, and a newline instruction to the WebUtil bean layer. The procedure is called by WEBUTIL.LOG to append log entries to a file residing on the client machine.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |
| item | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the target file handle (file.handle extracted from the file_type parameter) and the text string (item) to be written.
- Step 2 - Pass the file handle to the WebUtil bean by setting the WUF_TEXTIO_HANDLE property on the WUF_PACKAGE component via WebUtil_Core.setProperty.
- Step 3 - Pass the text content to the WebUtil bean by setting the WUF_TEXTIO_PUT property with the value of item.
- Step 4 - Signal a newline terminator by setting the WUF_TEXTIO_NEWLINE property to 1, instructing the bean to append a line break after the written text.
- Step 5 - If a BEAN_NOT_REGISTERED exception is raised during any property-set call, display an error alert identifying the missing implementation class and raise TOOL_ERR.TOOL_ERROR to halt processing.
- Step 6 - If a PROPERTY_ERROR exception is raised, raise TOOL_ERR.TOOL_ERROR to halt processing without an additional alert.

---
**Decision Points**

DP-001

Condition:
A BEAN_NOT_REGISTERED exception is raised when attempting to set a WebUtil bean property (i.e., the required WebUtil bean is not registered in the client session).

TRUE:
Display an error alert identifying the missing implementation class with the message that CLIENT_TEXT_IO.put_line will not work, then raise TOOL_ERR.TOOL_ERROR to abort execution.

FALSE:
Continue to the next property-set call without interruption.

---

DP-002

Condition:
A PROPERTY_ERROR exception is raised when attempting to set a WebUtil bean property (i.e., the bean is registered but the property operation fails).

TRUE:
Raise TOOL_ERR.TOOL_ERROR immediately to abort execution; no additional alert is displayed.

FALSE:
Property-set operations complete successfully; procedure exits normally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file handle embedded in the file_type parameter must be set before calling this procedure; the procedure transmits the handle value as-is and does not validate or open the file itself.
- BR-002 - A newline is always appended after the written text (WUF_TEXTIO_NEWLINE is unconditionally set to 1); the procedure does not support writing partial lines without a line terminator.
- BR-003 - If the WebUtil bean is not registered on the client, the procedure must surface a descriptive error alert before raising TOOL_ERR.TOOL_ERROR, ensuring the operator is informed that CLIENT_TEXT_IO.put_line functionality is unavailable.
- BR-004 - Any PROPERTY_ERROR encountered during bean communication causes an immediate hard stop via TOOL_ERR.TOOL_ERROR; no partial write state is left unhandled.

---
**Implementation Logic**

```plsql
    

  PROCEDURE put_line (file file_type, item VARCHAR2) is
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);              
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_PUT',item); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_NEWLINE',1); 
  EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.put_line will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;  
  END put_line;
```

#### SP-056 - WEBUTIL.READFROMPROPERTYBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.LOG]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value associated with a given property key from an in-memory property bundle cache. If the cache is unpopulated, it delegates to WEBUTIL.POPULATEPROPERTYBUNDLE to load the bundle before performing the lookup. This function supports configuration-driven behaviour for routines such as WEBUTIL.CHECKLIBS, WEBUTIL.LOG, and WEBUTIL.REGISTERBEAN by providing a centralised, reusable mechanism for reading named configuration properties.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.POPULATEPROPERTYBUNDLE ([SP-053](#SP-053--WEBUTIL.POPULATEPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input property key (propertyKey) and capture the current count of entries in the in-memory property bundle collection (m_propertyBundle).
- Step 2 - Check whether a configuration error flag (m_config_error) has previously been raised; if so, abort immediately and return NULL to signal that the configuration source is unavailable.
- Step 3 - If no configuration error exists but the property bundle collection is empty (count = 0), invoke WEBUTIL.POPULATEPROPERTYBUNDLE passing propertyKey to load the bundle and obtain the value in a single operation; assign the returned value to the result variable.
- Step 4 - If the property bundle collection is already populated, iterate through all entries in the collection and compare each entry's stored key (held in lower case) against the lower-case equivalent of the supplied propertyKey.
- Step 5 - On the first matching entry, assign the corresponding propertyValue to the result variable and exit the loop immediately.
- Step 6 - Return the result variable; if no matching key was found during iteration, result remains NULL and NULL is returned.

---
**Decision Points**

DP-001

Condition: m_config_error flag is TRUE.

TRUE: Return NULL immediately; no further processing is attempted because a prior configuration read failure has been recorded.

FALSE: Proceed to evaluate the state of the property bundle collection.

---

DP-002

Condition: The property bundle collection (m_propertyBundle) contains zero entries (propCount = 0).

TRUE: Call WEBUTIL.POPULATEPROPERTYBUNDLE with the supplied propertyKey to populate the bundle and retrieve the value in one step; assign the returned value to result.

FALSE: The bundle is already loaded; iterate through existing entries to locate the matching key.

---

DP-003

Condition: During iteration, the current entry's propertyKey (stored in lower case) matches the lower-case form of the supplied propertyKey.

TRUE: Assign the entry's propertyValue to result and exit the loop.

FALSE: Continue to the next entry in the collection; if the loop completes without a match, result remains NULL.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - If a configuration error has previously been detected (m_config_error = TRUE), the function must return NULL without attempting any property lookup, preventing repeated or cascading failures against an unavailable configuration source.
- BR-002 - Property key comparison is case-insensitive; stored keys are held in lower case and the supplied key is converted to lower case before comparison, ensuring consistent retrieval regardless of the case used by the caller.
- BR-003 - When the in-memory property bundle is empty, the function must delegate to WEBUTIL.POPULATEPROPERTYBUNDLE to load the bundle; the function does not independently read the configuration source.
- BR-004 - The function returns only the first matching property value encountered; iteration stops immediately upon finding a match, enforcing uniqueness of key resolution within the bundle.
- BR-005 - If the supplied property key does not match any entry in a populated bundle, the function returns NULL; callers must handle a NULL result as a valid indicator that the key is not present in the configuration.

---
**Implementation Logic**

```plsql
  
  FUNCTION ReadFromPropertyBundle(propertyKey in VARCHAR2) return VARCHAR2 is   
    result       VARCHAR2(1000 char);
    propCount    PLS_INTEGER := m_propertyBundle.COUNT;
  begin
    if m_config_error then
      -- already encountered problem reading the config file.
      return null;
    elsif (propCount = 0) then
      result := populatePropertyBundle(propertyKey);
    else
      for i in 1..propCount LOOP
        if m_propertyBundle(i).propertyKey = lower(propertyKey) then 
          result := m_propertyBundle(i).propertyValue;
          EXIT;
        end if;
      end LOOP;
    end if;
    return result;
  end ReadFromPropertyBundle;
```

#### SP-057 - WEBUTIL.READTRANSFROMMSGBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a translated message string from the WebUtil message bundle by composing a lookup key from the supplied property key and optional arguments, then delegating the get/set cycle to the WebUtil Core layer. The function is used to obtain localised UI text - currently limited to fetching the progress bar title during library verification in WEBUTIL.CHECKLIBS.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |
| args | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message bundle property key (propertyKey) and an optional argument string (args) as inputs.
- Step 2 - Concatenate propertyKey and args with a pipe delimiter ('|') to form a composite lookup value.
- Step 3 - Write the composite lookup value to the WebUtil Core property store by calling Webutil_Core.setProperty, targeting the WUC_PACKAGE package constant and the WUC_TRANS_MSG property name.
- Step 4 - Immediately read back the resolved (translated) message string from the same property store by calling Webutil_Core.getProperty with the same WUC_PACKAGE and WUC_TRANS_MSG identifiers.
- Step 5 - Return the translated message string to the caller.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a fixed sequence of set and get operations without branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The composite lookup key passed to the WebUtil Core property store must be formed by concatenating propertyKey and args with a pipe character ('|') as the delimiter, even when args is NULL, ensuring a consistent key format for the message bundle resolution mechanism.
- BR-002 - Message bundle translation is performed exclusively through the WebUtil Core property store (Webutil_Core.setProperty / Webutil_Core.getProperty) using the WUC_PACKAGE and WUC_TRANS_MSG constants; no direct database or file-system lookup is performed by this function.
- BR-003 - The args parameter is optional (defaults to NULL); callers may omit it when no substitution arguments are required for the target message.

---
**Implementation Logic**

```plsql
  
  FUNCTION ReadTransFromMsgBundle(propertyKey in VARCHAR2, args in VARCHAR2 := null) return VARCHAR2 is
    -- currently called from checkLibs only for getting progress bar title.
  begin 
    Webutil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_TRANS_MSG', propertyKey||'|'||args);
    return Webutil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_TRANS_MSG');
  end ReadTransFromMsgBundle;
```

#### SP-058 - WEBUTIL.REGISTERBEAN

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a WebUtil client-side bean with the Forms server session on first contact. The procedure parses the client environment packet supplied by the bean, maps the bean's short name to an internal package identifier, captures one-time client environment details (IP address, OS, architecture, username, path separators, locale), configures the system-library download directory on the client, retrieves and stores the WebUtil bean version, applies heartbeat-blocking and server-logging settings to the client bean, and triggers library availability checks for both the newly registered package and any user-defined libraries.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| clientInfo | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.CHECKLIBS ([SP-017](#SP-017--WEBUTIL.CHECKLIBS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTSETTING ([SP-032](#SP-032--WEBUTIL.GETCLIENTSETTING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETOSFAMILY ([SP-037](#SP-037--WEBUTIL.GETOSFAMILY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETPROPERTY ([SP-039](#SP-039--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETVAR ([SP-041](#SP-041--WEBUTIL.GETVAR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-052](#SP-052--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-056](#SP-056--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETCLIENTSETTING ([SP-061](#SP-061--WEBUTIL.SETCLIENTSETTING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Extract the bean short name from the pipe-delimited clientInfo string (position 1) using DelimStr.getString.
- Step 2 - Map the extracted short name ('WUC', 'WUT', 'WUF', 'WUI', 'WUH', 'WUS', 'WUB', 'WUO', 'WUU', 'WUL') to the corresponding WEBUTIL_CORE package-ID constant and store it in packageID.
- Step 3 - If m_clientIP is null (i.e., this is the very first bean registration in the session), set the checkUserLibs flag to TRUE and parse the remaining clientInfo fields: client IP (position 2), OS name (position 3), OS architecture (position 4), username (position 5), path separator (position 6), file separator (position 7), and language code (position 8) into their respective session-level variables. Determine the OS family by calling WEBUTIL.GETOSFAMILY; if the architecture string contains '64', set m_clientOSArch to 1.
- Step 4 - If the packageID entry does not yet exist in the m_registeredPackages array, record the triggering item (NAME_IN('SYSTEM.TRIGGER_ITEM')) against that packageID and set the newPackage flag to TRUE, ensuring only the first instance of each bean type is registered.
- Step 5 - When checkUserLibs is TRUE, reset REDOWNLOAD_SYSLIB to FALSE, then resolve the server host name by calling WEBUTIL.GETVAR for 'COMPUTERNAME'; if null, fall back to 'HOST'.
- Step 6 - Attempt to retrieve the client system-library directory from the property bundle using WEBUTIL.READFROMPROPERTYBUNDLE with an OS-family-and-architecture-specific key; if not found, retry with an OS-family-only key.
- Step 7 - If no client library directory is configured, send a WUC_SYSLIB_DIR property to the WUC bean (via WebUtil_Core.setProperty) containing only the server host and application CONFIG, allowing the client JRE to determine the location. If a directory is configured, replace any '$(SERVERHOST)' token with the resolved server host name, send the full WUC_SYSLIB_DIR property, then compare the stored client setting (WEBUTIL.GETCLIENTSETTING) with the new directory; if they differ, update the setting via WEBUTIL.SETCLIENTSETTING and set REDOWNLOAD_SYSLIB to TRUE.
- Step 8 - Retrieve and store the WebUtil bean version from the WUC bean property 'WUC_BEAN_VERSION' using WEBUTIL.GETPROPERTY.
- Step 9 - If the 'logging.connections' property bundle entry equals 'true' (case-insensitive), write a connection log entry via WEBUTIL.LOG recording the current form, client OS, and locale.
- Step 10 - If newPackage is TRUE, call WEBUTIL.CHECKLIBS with the string representation of packageID to verify and download required libraries for the newly registered package.
- Step 11 - If checkUserLibs is TRUE, call WEBUTIL.LOG with a null message to initialise the m_loggingAllowed and m_loggingErrorsOnly session flags.
- Step 12 - Read the 'BlockAllowHeartBeat' property bundle entry; if its lowercase value is 'true', 'yes', or '1', send WUC_BLOCK_ALLOW_HEART_BEAT = '1' to the client bean; otherwise send '0'.
- Step 13 - Evaluate the m_loggingAllowed and m_loggingErrorsOnly flags and send the corresponding WUC_SRV_LOGGING value to the client bean: '1' for errors-only logging, '2' for full logging, '0' for logging disabled.
- Step 14 - If checkUserLibs is TRUE, call WEBUTIL.CHECKLIBS with the literal string 'user' to verify and download any user-defined libraries.

---
**Decision Points**

DP-001
Condition: beanShortName matches one of the known constants ('WUC', 'WUT', 'WUF', 'WUI', 'WUH', 'WUS', 'WUB', 'WUO', 'WUU', 'WUL').
TRUE: packageID is set to the corresponding WEBUTIL_CORE package constant.
FALSE: packageID remains uninitialised; no package mapping is performed.

DP-002
Condition: m_clientIP IS NULL (first bean registration in the current session).
TRUE: checkUserLibs is set to TRUE and all client environment fields (IP, OS, OS family, OS architecture, username, path separator, file separator, language code) are parsed from clientInfo.
FALSE: Client environment fields are not re-parsed; checkUserLibs remains FALSE.

DP-003
Condition: The architecture string extracted from clientInfo contains '64'.
TRUE: m_clientOSArch is set to 1 (64-bit).
FALSE: m_clientOSArch retains its default value (not set to 1).

DP-004
Condition: m_registeredPackages does NOT already contain an entry for packageID.
TRUE: The current trigger item is recorded in m_registeredPackages for packageID and newPackage is set to TRUE.
FALSE: The package is already registered; no update is made and newPackage remains FALSE.

DP-005
Condition: WEBUTIL.GETVAR returns a non-null value for 'COMPUTERNAME'.
TRUE: serverHost is set to the COMPUTERNAME value.
FALSE: WEBUTIL.GETVAR is called again with 'HOST' to resolve serverHost.

DP-006
Condition: WEBUTIL.READFROMPROPERTYBUNDLE returns a non-null value for the OS-family-and-architecture-specific key ('install.syslib.location.client.<family>.<arch>').
TRUE: clientLibDir is set to the returned value.
FALSE: WEBUTIL.READFROMPROPERTYBUNDLE is called again with the OS-family-only key.

DP-007
Condition: clientLibDir IS NULL after both property bundle lookups.
TRUE: WUC_SYSLIB_DIR is sent to the WUC bean containing only the server host and CONFIG, delegating directory resolution to the client JRE.
FALSE: The configured directory path is used; '$(SERVERHOST)' tokens are replaced, WUC_SYSLIB_DIR is sent with the full path, and the stored client setting is compared to detect directory changes.

DP-008
Condition: The previously stored client library directory (from WEBUTIL.GETCLIENTSETTING) differs from the newly configured clientLibDir.
TRUE: WEBUTIL.SETCLIENTSETTING updates the stored directory and REDOWNLOAD_SYSLIB is set to TRUE.
FALSE: No update is made; REDOWNLOAD_SYSLIB remains FALSE.

DP-009
Condition: LOWER(WEBUTIL.READFROMPROPERTYBUNDLE('logging.connections')) = 'true'.
TRUE: WEBUTIL.LOG is called to record the connection details (form name, client OS, locale).
FALSE: No connection log entry is written.

DP-010
Condition: newPackage is TRUE.
TRUE: WEBUTIL.CHECKLIBS is called with the string representation of packageID to validate and download package-specific libraries.
FALSE: Library check for the package is skipped.

DP-011
Condition: LOWER(WEBUTIL.READFROMPROPERTYBUNDLE('BlockAllowHeartBeat')) is 'true', 'yes', or '1'.
TRUE: WUC_BLOCK_ALLOW_HEART_BEAT is sent to the client bean as '1' (heartbeat blocking enabled).
FALSE: WUC_BLOCK_ALLOW_HEART_BEAT is sent as '0' (heartbeat blocking disabled).

DP-012
Condition: m_loggingAllowed is TRUE AND m_loggingErrorsOnly is TRUE.
TRUE: WUC_SRV_LOGGING is sent as '1' (errors-only logging).
FALSE: Proceed to DP-013.

DP-013
Condition: m_loggingAllowed is TRUE (and m_loggingErrorsOnly is FALSE).
TRUE: WUC_SRV_LOGGING is sent as '2' (full logging).
FALSE: WUC_SRV_LOGGING is sent as '0' (logging disabled).

DP-014
Condition: checkUserLibs is TRUE (evaluated after heartbeat and logging properties are sent).
TRUE: WEBUTIL.CHECKLIBS is called with 'user' to verify and download user-defined libraries.
FALSE: User library check is skipped.

---
**Database Interactions**

- DB-001 - Update THIS - Updates existing rows in THIS.
**Business Rules**

- BR-001 - Only recognised bean short names ('WUC', 'WUT', 'WUF', 'WUI', 'WUH', 'WUS', 'WUB', 'WUO', 'WUU', 'WUL') are mapped to internal package IDs; unrecognised short names result in no package registration.
- BR-002 - Client environment details (IP, OS, OS family, OS architecture, username, separators, locale) are captured exactly once per Forms session, on the first bean registration call; subsequent calls do not overwrite these values.
- BR-003 - Only the first instance of each bean type is registered per form session; if the same bean type appears in a multi-row block or is otherwise duplicated, only the first occurrence is recorded in m_registeredPackages.
- BR-004 - The system-library download directory is resolved in priority order: OS-family-and-architecture-specific key first, OS-family-only key second, and client JRE default last.
- BR-005 - The '$(SERVERHOST)' placeholder in a configured client library directory must be replaced with the runtime server host name before the path is transmitted to the client bean.
- BR-006 - If the configured client library directory has changed since the last session (as determined by comparing WEBUTIL.GETCLIENTSETTING with the new value), the stored setting is updated and REDOWNLOAD_SYSLIB is flagged TRUE to force a re-download.
- BR-007 - Connection logging is conditional on the 'logging.connections' property bundle entry being set to 'true' (case-insensitive); the log entry must include the form name, client OS, and locale.
- BR-008 - The heartbeat-blocking setting sent to the client bean is driven exclusively by the 'BlockAllowHeartBeat' configuration property; accepted affirmative values are 'true', 'yes', and '1' (case-insensitive).
- BR-009 - Server-side logging state (m_loggingAllowed, m_loggingErrorsOnly) must be communicated to the client bean via the WUC_SRV_LOGGING property to prevent unnecessary round-trip log messages from the bean.
- BR-010 - Library availability checks (WEBUTIL.CHECKLIBS) for a newly registered package must be deferred until after that package's entry exists in m_registeredPackages, so that a handler bean is available to perform any required download.
- BR-011 - User library checks (WEBUTIL.CHECKLIBS with 'user') are performed only once per session, on the same first-registration pass that captures client environment details.

---
**Implementation Logic**

```plsql
  PROCEDURE registerBean(clientInfo in VARCHAR2) is  
    packageID       PLS_INTEGER;
    beanShortName   VARCHAR2(3 char);
    newPackage      BOOLEAN := false;
    checkUserLibs   BOOLEAN := false;
    clientLibDir    VARCHAR2(1000 char);
    clientLibDirOld VARCHAR2(1000 char);
    serverHost      VARCHAR2(100 char);
    blockAllowHeartBeat VARCHAR2(10 char);
    clientOSArch    VARCHAR2(30 char);
  begin
    beanShortName := DelimStr.getString(clientInfo,1,true,'|');

    -- To speed access up we crossmatch the Bean Name string
    -- with a constant - this constant is used to access the 
    -- registered package array efficently
    -- need to update this IF statement as we add new packages
    if beanShortName = 'WUC' then
       packageID := WEBUTIL_CORE.WUC_PACKAGE; 
    elsif beanShortName = 'WUT' then     
       packageID := WEBUTIL_CORE.WUT_PACKAGE; 
    elsif beanShortName = 'WUF' then 
       packageID := WEBUTIL_CORE.WUF_PACKAGE; 
    elsif beanShortName = 'WUI' then
        packageID := WEBUTIL_CORE.WUI_PACKAGE; 
    elsif beanShortName = 'WUH' then            
       packageID := WEBUTIL_CORE.WUH_PACKAGE;
    elsif beanShortName = 'WUS' then     
       packageID := WEBUTIL_CORE.WUS_PACKAGE;
    elsif beanShortName = 'WUB' then 
       packageID := WEBUTIL_CORE.WUB_PACKAGE;
    elsif beanShortName = 'WUO' then     
       packageID := WEBUTIL_CORE.WUO_PACKAGE;
    elsif beanShortName = 'WUU' then     
       packageID := WEBUTIL_CORE.WUU_PACKAGE;
    elsif beanShortName = 'WUL' then     
       packageID := WEBUTIL_CORE.WUL_PACKAGE;           
    end if;
    -- For the very first bean we can get a bit of useful information
    -- Only do this once
    if m_clientIP is null then 
      checkUserLibs := true;
      -- Format of the clientinfo packet is
      -- BeanName|IP|OSName|UserName|pathSep|filesep
      m_clientIP       := DelimStr.getString(clientInfo,2,true,'|');
      m_clientOS       := DelimStr.getString(clientInfo,3,true,'|');
      m_clientOSFamily := getOSFamily(m_clientOS);
      clientOSArch     := DelimStr.getString(clientInfo,4,true,'|');
      if instr(clientOSArch, '64') > 0 then
        m_clientOSArch := 1;
      end if;
      m_clientUserName := DelimStr.getString(clientInfo,5,true,'|');      
      m_clientPathSep  := DelimStr.getString(clientInfo,6,true,'|');
      m_clientFileSep  := DelimStr.getString(clientInfo,7,true,'|');
      m_clientLangCode := DelimStr.getString(clientInfo,8,true,'|'); 
    end if;
      
    -- I'd only expect one instance of each bean per form
    -- but just in case we only register the first 
    -- so if multiple copies are used - e.g. it's 
    -- placed in a multi-row block we just use the 
    -- first instance.
    if not m_registeredPackages.EXISTS(packageID) then 
      m_registeredPackages(packageID) := name_in('SYSTEM.TRIGGER_ITEM');
      -- make sure all the required libraries are available
      -- on the client
      newPackage := true;
    end if;
      
    if checkUserLibs then
      -- checkUserLibs would be true if clientIP was null
      -- We can do whatever we want to do but not more than once
      REDOWNLOAD_SYSLIB := FALSE;
      -- We need to get the server host name using available built-ins. This looks lame,
      -- but it should work
      TOOL_ENV.GETVAR('COMPUTERNAME', serverHost);
      if serverHost is null then
        TOOL_ENV.GETVAR('HOST', serverHost);
      end if;
      clientLibDir := readFromPropertyBundle('install.syslib.location.client.'||to_char(m_clientOSFamily) ||
                                             '.' || to_char(m_clientOSArch));
      if clientLibDir is null then
        clientLibDir := readFromPropertyBundle('install.syslib.location.client.'||to_char(m_clientOSFamily));
      end if;
      if clientLibDir is null then
        -- client location when syslib download is not defined in webutil.cfg
        -- will be to client JRE. Send nothing and client will handle
        WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SYSLIB_DIR',
                                 ':' || serverHost || ':' || GET_APPLICATION_PROPERTY(CONFIG),
                                 true);
      else
        -- webutil.cfg contains a specific client directory for syslib download
        -- Replace $(SERVERHOST), if exists, with server host name
        clientLibDir := replace(clientLibDir, '$(SERVERHOST)', serverHost);

        -- The following line makes a few things happen on client including
        -- client directory creation, when clientLibDir is not null
        WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SYSLIB_DIR',
                                 clientLibDir || ':' || serverHost || ':' || GET_APPLICATION_PROPERTY(CONFIG),
                                 true);
        clientLibDirOld := GetClientSetting('install.syslib.dir');

        if clientLibDirOld <> clientLibDir then
    	  SetClientSetting('install.syslib.dir', clientLibDir);
          REDOWNLOAD_SYSLIB := TRUE;
    	end if;
      end if;
      Webutil_Core.WEBUTIL_VERSION := getProperty(WUC_PACKAGE,'WUC_BEAN_VERSION');
      -- We want to write the connection record if it's required.
      -- Any call to ReadFromPropertyBundle or log should be preferably made after
      -- registering at least one bean. That is the reason why the following log
      -- comes after m_registeredPackages(packageID) := name_in('SYSTEM.TRIGGER_ITEM'); above
      if lower(ReadFromPropertyBundle('logging.connections')) = 'true' then 
        log('Connection from Form='||GET_APPLICATION_PROPERTY(CURRENT_FORM)||' Client O/S='||m_clientOS||' locale='||m_clientLangCode,false);
      end if;
    end if;
    if newPackage then  
            checkLibs(to_char(packageID));
    end if;

    if checkUserLibs then
      -- Call a dummy log to initialize m_loggingAllowed and m_loggingErrorsOnly
      log(null,false);
    end if;

    -- 5950737 - Introduce new configuration variable BlockAllowHeartBeat. 
    -- Valid values are true, yes and 1.
    -- If this is set then send a message to the client to behave accordingly.    
    blockAllowHeartBeat := lower(ReadFromPropertyBundle('BlockAllowHeartBeat'));
    if blockAllowHeartBeat = 'true' or blockAllowHeartBeat = 'yes' or blockAllowHeartBeat = '1' then 
      WebUtil_Core.setProperty(packageID,'WUC_BLOCK_ALLOW_HEART_BEAT','1',true);
    else
      WebUtil_Core.setProperty(packageID,'WUC_BLOCK_ALLOW_HEART_BEAT','0',true);
    end if;

    -- Send server logging options to client bean so that the bean does not have
    -- to send message to server unnecessarily.
    if m_loggingAllowed and m_loggingErrorsOnly then
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','1',true);
    elsif m_loggingAllowed then
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','2',true);
    else
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','0',true);
    end if;
      
    -- 2836929 - move the user library check after the first package is registered 
    -- so that a handler bean exists to do the download.     
    if checkUserLibs then 
      --Check for and download any user libs
      checkLibs('user');  
    end if;     
  end registerBean;
```

#### SP-059 - WEBUTIL.REGISTER_FUNCTION

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a native library function with the WebUtil client-side bean so that it can subsequently be called from Oracle Forms. The procedure sends the library name and function name to the WebUtil bean via property-set/get round-trips, receives back a numeric handle that uniquely identifies the registered function, increments the module-level registered-function counter when registration succeeds, and returns the handle to the caller for use in later function-call invocations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| libName | VARCHAR2 | IN |
| funcName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-046](#SP-046--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the library name (`libName`) and function name (`funcName`) as input parameters.
- Step 2 - Concatenate `libName` and `funcName` with a pipe delimiter and push the combined specification string to the WebUtil bean by calling `WebUtil_Core.setProperty` with the `WUL_PACKAGE` target and property key `WUL_FUNCTION_SPEC`.
- Step 3 - Retrieve the registration result from the WebUtil bean by calling `WebUtil_Core.getProperty` with property key `WUL_REGISTER_FUNCTION`; the bean returns a VARCHAR2 string (`strHnd`) representing the allocated function handle.
- Step 4 - Convert the string handle to a numeric value and store it in the `FunctionHandle` record field `funcHnd.hnd` using `TO_NUMBER`.
- Step 5 - Evaluate the resulting handle by calling `ID_NULL(funcHnd)` (SP-046) to determine whether the registration produced a valid, non-null handle.
- Step 6 - If the handle is valid (not null), increment the module-level counter `m_funcHandleCount` by 1 to track the total number of successfully registered functions.
- Step 7 - Return `funcHnd` to the caller.
- Step 8 (Exception - Bean Not Registered) - If `WebUtil_Core.BEAN_NOT_REGISTERED` is raised, display an error alert identifying the missing implementation class and raise `FORM_TRIGGER_FAILURE` to abort the calling trigger.
- Step 9 (Exception - Property Error) - If `WebUtil_Core.PROPERTY_ERROR` is raised, raise `FORM_TRIGGER_FAILURE` to abort the calling trigger.
- Step 10 (Exception - Value Error) - If `VALUE_ERROR` is raised (e.g., `TO_NUMBER` conversion fails on the returned handle string), raise `TOOL_ERR.TOOL_ERROR`.

---
**Decision Points**

DP-001

Condition:
Is the handle returned by the WebUtil bean non-null? Evaluated by calling `ID_NULL(funcHnd)` (SP-046) after converting the string handle to a number.

TRUE (handle is NOT null - `ID_NULL` returns FALSE):
Increment `m_funcHandleCount` by 1 to record that a new function has been successfully registered.

FALSE (handle IS null - `ID_NULL` returns TRUE):
Skip the counter increment; return the null handle to the caller without updating the registration count.

---

DP-002

Condition:
Does the WebUtil bean raise `BEAN_NOT_REGISTERED` during the property set/get operation?

TRUE:
Display an error alert naming the missing implementation class and raise `FORM_TRIGGER_FAILURE`, halting further processing.

FALSE:
Continue normal processing.

---

DP-003

Condition:
Does the WebUtil bean raise `PROPERTY_ERROR` during the property set/get operation?

TRUE:
Raise `FORM_TRIGGER_FAILURE`, halting further processing.

FALSE:
Continue normal processing.

---

DP-004

Condition:
Does `TO_NUMBER` raise `VALUE_ERROR` when converting the returned string handle to a number?

TRUE:
Raise `TOOL_ERR.TOOL_ERROR`, propagating a tool-level error to the caller.

FALSE:
Continue normal processing with the successfully converted numeric handle.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function specification passed to the WebUtil bean must be formatted as `libName || '|' || funcName`; both the library name and the function name are mandatory components of this specification string.
- BR-002 - A function handle is considered valid only when `ID_NULL(funcHnd)` returns FALSE; only valid handles cause the module-level registration counter (`m_funcHandleCount`) to be incremented.
- BR-003 - The WebUtil bean must be registered and available before `REGISTER_FUNCTION` is called; if the bean is absent, the operation is non-recoverable within the current trigger and `FORM_TRIGGER_FAILURE` is raised.
- BR-004 - Any property communication error with the WebUtil bean (`PROPERTY_ERROR`) is treated as a non-recoverable trigger failure and surfaces as `FORM_TRIGGER_FAILURE`.
- BR-005 - If the bean returns a non-numeric handle string, the resulting `VALUE_ERROR` is escalated as `TOOL_ERR.TOOL_ERROR`, signalling a tool-level fault rather than a form-trigger fault.
- BR-006 - The function returns a `FunctionHandle` record in all non-exception paths; callers must inspect the handle for nullity (via SP-046 `ID_NULL`) before attempting to use it in subsequent function-call operations.

---
**Implementation Logic**

```plsql

  FUNCTION REGISTER_FUNCTION (libName IN VARCHAR2, funcName IN VARCHAR2) 
                              RETURN FunctionHandle IS
    strHnd  VARCHAR2(8);                            
    funcHnd FunctionHandle;
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUL_PACKAGE,'WUL_FUNCTION_SPEC', libName || '|' || funcName);
    strHnd := WebUtil_Core.getProperty(WebUtil_Core.WUL_PACKAGE,'WUL_REGISTER_FUNCTION');
    funcHnd.hnd := TO_NUMBER (strHnd);
    if NOT ID_NULL(funcHnd) then
      m_funcHandleCount := m_funcHandleCount + 1;
    end if;

    RETURN funcHnd;
    
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUL_PACKAGE)
                              ||' bean not found. WEBUTIL_C_API.REGISTER_FUNCTION will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;  
    when VALUE_ERROR then
        RAISE TOOL_ERR.TOOL_ERROR; 
  END REGISTER_FUNCTION;
```

#### SP-060 - WEBUTIL.RELEASE_PROCESS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.HOST]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Releases a previously acquired host process handle by clearing its associated callback trigger and nullifying the handle reference. This ensures that process resources managed by the WebUtil host integration layer are properly cleaned up after use, preventing stale handle references from persisting in the calling context.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the process handle (PROCESS_ID) as an IN OUT parameter, representing an active host process previously allocated by the WebUtil host integration.
- Step 2 - Invoke WebUtil_Core.setProperty to clear the process property on the WUH_PACKAGE bean, passing the WUH_CLEAR_PROC property key and the current process handle value, signalling the bean to release its internal reference.
- Step 3 - Invoke WebUtil_Core.ClearCallbackTrigger with the process handle to deregister any callback trigger associated with that handle, ensuring no orphaned callbacks remain registered.
- Step 4 - Set process.handle to NULL, nullifying the caller's reference to confirm the handle has been fully released.
- Step 5 - If a BEAN_NOT_REGISTERED exception is raised during any of the above steps, display an error alert identifying the missing implementation class and informing the user that WEBUTIL_HOST.Release_Process will not function.

---
**Decision Points**

DP-001

Condition:
A BEAN_NOT_REGISTERED exception is raised when attempting to interact with the WUH_PACKAGE bean (i.e., the required WebUtil bean is not registered in the current session).

TRUE:
An error alert is displayed to the user, concatenating the implementation class name retrieved via WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE) with a descriptive message stating that the bean was not found and that WEBUTIL_HOST.Release_Process will not work. No further release steps are executed.

FALSE:
The procedure completes normally: the property is cleared, the callback trigger is deregistered, and the process handle is nullified.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The process handle (process.handle) must be nullified upon release; retaining a non-null handle after release is not permitted, as it would leave a stale reference in the calling context.
- BR-002 - Both the WUH_CLEAR_PROC property and the associated callback trigger must be cleared in the same release operation to ensure complete cleanup of all resources tied to the process handle.
- BR-003 - If the WebUtil bean for WUH_PACKAGE is not registered, the procedure must surface an informative error alert identifying the missing implementation class rather than failing silently, allowing operators to diagnose configuration issues.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Release_Process(process in out PROCESS_ID) is  
  begin
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_CLEAR_PROC',process.handle);
    WebUtil_Core.ClearCallbackTrigger(process.handle);
    process.handle := null;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.Release_Process will not work');
  end Release_Process;
```

#### SP-061 - WEBUTIL.SETCLIENTSETTING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Transmits a named configuration property and its value to the WebUtil client-side bean by delegating to WebUtil_Core.setProperty. The procedure allows calling routines (WEBUTIL.CHECKLIBS and WEBUTIL.REGISTERBEAN) to store a local property on the WebUtil Core bean at runtime, enabling client-side behaviour to be controlled through key-value settings without direct database interaction.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyName | VARCHAR2 | IN |
| propertyValue | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the property name (propertyName) and property value (propertyValue) as input parameters.
- Step 2 - Evaluate whether propertyName is not null; if null, no action is taken and the procedure exits silently.
- Step 3 - If propertyName is not null, invoke WebUtil_Core.setProperty, passing the WebUtil Core package identifier (WebUtil_Core.WUC_PACKAGE), the action constant WUC_SET_LOCAL_PROPERTY, and the concatenated string propertyName||'='||propertyValue as the property payload.
- Step 4 - If WebUtil_Core.setProperty raises the BEAN_NOT_REGISTERED exception, present an error alert via WebUtil_Core.ErrorAlert identifying the missing bean class, then raise FORM_TRIGGER_FAILURE to halt further form processing.
- Step 5 - If WebUtil_Core.setProperty raises the PROPERTY_ERROR exception, raise FORM_TRIGGER_FAILURE immediately to halt further form processing.

---
**Decision Points**

DP-001

Condition: propertyName IS NOT NULL

TRUE: Call WebUtil_Core.setProperty to transmit the property name and value to the WebUtil Core bean using the concatenated format propertyName||'='||propertyValue.

FALSE: Skip the setProperty call entirely; the procedure exits without error and without sending any property to the client.

---

DP-002

Condition: WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during setProperty execution

TRUE: Display an error alert identifying the unregistered bean class (retrieved via WebUtil_Core.getImplClass) and raise FORM_TRIGGER_FAILURE to stop form processing.

FALSE: Continue normal execution; no error alert is displayed.

---

DP-003

Condition: WebUtil_Core.PROPERTY_ERROR exception is raised during setProperty execution

TRUE: Raise FORM_TRIGGER_FAILURE immediately to stop form processing.

FALSE: Continue normal execution; procedure completes successfully.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A null propertyName is silently ignored; the procedure will not attempt to transmit any property to the client bean when propertyName is null.
- BR-002 - The property payload delivered to the WebUtil Core bean must be formatted as a single string in the form propertyName||'='||propertyValue; no other format is permitted.
- BR-003 - The target bean is always identified by the constant WebUtil_Core.WUC_PACKAGE and the action is always WUC_SET_LOCAL_PROPERTY; callers may not override these identifiers.
- BR-004 - If the WebUtil Core bean has not been registered at the time of invocation, the procedure must surface an informative error alert (including the bean class name) and terminate form processing via FORM_TRIGGER_FAILURE.
- BR-005 - Any property-level error returned by WebUtil_Core.setProperty must cause immediate termination of form processing via FORM_TRIGGER_FAILURE; no partial or silent failure is permitted.

---
**Implementation Logic**

```plsql

  PROCEDURE SetClientSetting(propertyName  in VARCHAR2,
                             propertyValue in VARCHAR2) is
  BEGIN
    if propertyName is not null then 
      WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SET_LOCAL_PROPERTY', propertyName||'='||propertyValue);
    end if;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                              ||' bean not found. WEBUTIL_CORE.SetClientSetting will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;       
  END SetClientSetting;
```

#### SP-062 - WEBUTIL.SETDATA

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.SETDATA receives a single chunk of uploaded data (as a VARCHAR2 string) and writes it to the appropriate destination - either a database BLOB via WebUtil_DB_Local or a server-side file via JAVA_APPSERV_WRITER. It decrements the outstanding-chunk counter after each successful write and, when all chunks have been received, finalises the transfer by closing the target resource and optionally firing a registered callback trigger. Any write or close failure is recorded as an error and raises a READWRITE_ERROR exception.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| uploadData | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.CLEARCALLBACKTRIGGER ([SP-018](#SP-018--WEBUTIL.CLEARCALLBACKTRIGGER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.CLOSEBLOB ([SP-019](#SP-019--WEBUTIL.CLOSEBLOB)) - WEBUTIL.pck (or .pld)
- WEBUTIL.CLOSEFILE ([SP-020](#SP-020--WEBUTIL.CLOSEFILE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCALLBACKTRIGGER ([SP-030](#SP-030--WEBUTIL.GETCALLBACKTRIGGER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETLASTERROR ([SP-034](#SP-034--WEBUTIL.GETLASTERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETLASTERRORARGS ([SP-035](#SP-035--WEBUTIL.GETLASTERRORARGS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.WRITEDATA ([SP-066](#SP-066--WEBUTIL.WRITEDATA)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the uploadData VARCHAR2 chunk passed by WEBUTIL_CORE.CUSTOMEVENTHANDLER.
- Step 2 - Validate that uploadData is not NULL and not an empty string; if it is, set the module-level flag m_uploadSucceeded to FALSE and exit without further processing.
- Step 3 - Determine the write destination using the module-level flag m_toDB.
- Step 4 (m_toDB = TRUE) - Call WebUtil_DB_LOCAL.WriteData to append the chunk to the in-progress BLOB.
- Step 5 (m_toDB = FALSE) - Call JAVA_APPSERV_WRITER.WriteData to write the chunk to the server-side file; if the call fails, retrieve the error code via WEBUTIL.GETLASTERROR and the error arguments via WEBUTIL.GETLASTERRORARGS, log the error through WebUtil_Core.Error, and raise READWRITE_ERROR.
- Step 6 - Decrement the module-level chunk counter m_chunks by 1.
- Step 7 - Evaluate whether m_chunks has reached 0 (i.e., all expected chunks have been received).
- Step 8 (all chunks received, m_toDB = TRUE) - Call WEBUTIL.CLOSEBLOB (WebUtil_DB_Local.CloseBlob) with the total file size m_fileSize; if successful, set m_uploadSucceeded to TRUE; otherwise log the error via WebUtil_Core.Error using WEBUTIL.GETLASTERROR.
- Step 9 (all chunks received, m_toDB = FALSE) - Call WEBUTIL.CLOSEFILE (JAVA_APPSERV_WRITER.CloseFile) with m_persistObj and m_fileSize; if successful, set m_uploadSucceeded to TRUE; otherwise retrieve the error code and args, log the error, delete the global Java object reference, and raise READWRITE_ERROR.
- Step 10 - After a successful close, check whether a callback trigger is registered by calling WEBUTIL.GETCALLBACKTRIGGER; if one is present, execute it via EXECUTE_TRIGGER.
- Step 11 - Call WEBUTIL.CLEARCALLBACKTRIGGER to deregister the callback trigger regardless of whether one was fired.

---
**Decision Points**

DP-001

Condition: uploadData IS NULL OR uploadData = ''

TRUE: Set m_uploadSucceeded to FALSE and exit the procedure without writing any data.

FALSE: Proceed to determine the write destination and write the chunk.

---

DP-002

Condition: m_toDB is TRUE

TRUE: Write the chunk to the database BLOB using WebUtil_DB_LOCAL.WriteData.

FALSE: Write the chunk to the server-side file using JAVA_APPSERV_WRITER.WriteData.

---

DP-003

Condition: JAVA_APPSERV_WRITER.WriteData returns a failure result (m_toDB = FALSE path)

TRUE: Retrieve last error code (WEBUTIL.GETLASTERROR) and error arguments (WEBUTIL.GETLASTERRORARGS), log the error, and raise READWRITE_ERROR.

FALSE: Continue processing; decrement m_chunks.

---

DP-004

Condition: m_chunks = 0 after decrement (all chunks received)

TRUE: Proceed to close the target resource (BLOB or file) and handle the callback trigger.

FALSE: Exit the procedure; the upload is still in progress.

---

DP-005

Condition: m_toDB is TRUE when closing (all chunks received)

TRUE: Call WEBUTIL.CLOSEBLOB; on success set m_uploadSucceeded to TRUE; on failure log the error.

FALSE: Call WEBUTIL.CLOSEFILE; on success set m_uploadSucceeded to TRUE; on failure log the error, delete the Java global reference, and raise READWRITE_ERROR.

---

DP-006

Condition: WEBUTIL.GETCALLBACKTRIGGER returns a non-null trigger name after the final chunk is closed

TRUE: Execute the registered callback trigger via EXECUTE_TRIGGER.

FALSE: Skip trigger execution.

---

DP-007

Condition: WebUtil_DB_Local.CloseBlob succeeds (m_toDB = TRUE, all chunks received)

TRUE: Set m_uploadSucceeded to TRUE.

FALSE: Log the error using WebUtil_Core.Error and WEBUTIL.GETLASTERROR; m_uploadSucceeded remains FALSE.

---

DP-008

Condition: JAVA_APPSERV_WRITER.CloseFile succeeds (m_toDB = FALSE, all chunks received)

TRUE: Set m_uploadSucceeded to TRUE.

FALSE: Retrieve last error code and args, log the error, delete the Java global object reference, and raise READWRITE_ERROR.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A NULL or empty uploadData chunk is treated as an error condition; m_uploadSucceeded is set to FALSE and no data is written to any destination.
- BR-002 - Every received chunk must be written to exactly one destination: either the database BLOB (when m_toDB is TRUE) or the server-side file (when m_toDB is FALSE); the two paths are mutually exclusive.
- BR-003 - A write failure on the file-system path (JAVA_APPSERV_WRITER.WriteData) is a fatal condition: the error must be logged with its code and arguments before raising READWRITE_ERROR.
- BR-004 - The chunk counter m_chunks is decremented by exactly 1 for each successfully written chunk; the upload is not considered complete until m_chunks reaches 0.
- BR-005 - Finalisation of the upload (closing the BLOB or file) must occur only after all expected chunks have been received (m_chunks = 0).
- BR-006 - On a successful close of the target resource, m_uploadSucceeded must be set to TRUE to signal completion to the calling context.
- BR-007 - A close failure on the file-system path is a fatal condition: the Java global object reference must be explicitly deleted via ORA_JAVA.DELETE_GLOBAL_REF before READWRITE_ERROR is raised.
- BR-008 - If a callback trigger was registered via WEBUTIL.GETCALLBACKTRIGGER at the time the final chunk is processed, it must be executed immediately after the resource is successfully closed.
- BR-009 - WEBUTIL.CLEARCALLBACKTRIGGER must always be called after the final chunk is processed, regardless of whether a callback trigger was fired, to prevent stale trigger references.

---
**Implementation Logic**

```plsql
   
  PROCEDURE SetData(uploadData in VARCHAR2) is 
    lastErrorCode    PLS_INTEGER;
    lastErrorArgs    VARCHAR2(1000);   
  BEGIN
    if uploadData is null or uploadData = '' then 
      -- error condition!
      m_uploadSucceeded := false;
    else
      -- Write to the correct place    
      if m_toDB then 
        WebUtil_DB_LOCAL.WriteData(uploadData);
      else
        if not JAVA_APPSERV_WRITER.WriteData(m_persistObj,uploadData) then
          lastErrorCode := JAVA_APPSERV_WRITER.getLastError(m_persistObj);
          lastErrorArgs := JAVA_APPSERV_WRITER.getLastErrorArgs(m_persistObj) ;
          WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                             'WEBUTIL_FILE_TRANSFER.SetData',lastErrorArgs);
          raise READWRITE_ERROR;
        end if;
      end if;
      m_chunks := m_chunks - 1;
      if m_chunks = 0 then 
        if m_toDB then 
          if WebUtil_DB_Local.CloseBlob(m_fileSize) then 
            m_uploadSucceeded := true;
          else
            WebUtil_core.Error(Webutil_Core.WUT_PACKAGE, WebUtil_DB_Local.getLastError,
                               'WEBUTIL_FILE_TRANSFER.SetData');
          end if; -- close
        else
          if JAVA_APPSERV_WRITER.CloseFile(m_persistObj,m_fileSize) then
            m_uploadSucceeded := true;
          else
            lastErrorCode := JAVA_APPSERV_WRITER.getLastError(m_persistObj);
            lastErrorArgs := JAVA_APPSERV_WRITER.getLastErrorArgs(m_persistObj) ;
            WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                               'WEBUTIL_FILE_TRANSFER.SetData',lastErrorArgs);
            ORA_JAVA.DELETE_GLOBAL_REF(m_persistObj);
            raise READWRITE_ERROR;
          end if;    
        end if; -- toDB

        if WebUtil_Core.GetCallbackTrigger(-1) is not null then
          EXECUTE_TRIGGER(WebUtil_Core.GetCallbackTrigger(-1));
        end if;
        WebUtil_Core.ClearCallbackTrigger(-1);
      end if; -- chunks
    end if;
  end SetData;
```

#### SP-063 - WEBUTIL.SETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sets a named JVM system property to a specified value by delegating to the Java Native Interface (JNI) layer. The function wraps a direct call to java.lang.System.setProperty, allowing Oracle Forms to read or influence JVM-level configuration at runtime. It returns the previous value of the property as a VARCHAR2 string.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |
| a1 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive two VARCHAR2 input parameters: a0 (the property name/key) and a1 (the value to assign to that property).
- Step 2 - Allocate a JNI argument list sized for exactly two arguments by calling JNI.CREATE_ARG_LIST(2).
- Step 3 - Append the property name (a0) to the argument list as a String argument via JNI.ADD_STRING_ARG.
- Step 4 - Append the property value (a1) to the argument list as a second String argument via JNI.ADD_STRING_ARG.
- Step 5 - Invoke the static Java method java.lang.System.setProperty(String, String) through JNI.CALL_STRING_METHOD, passing the fully qualified class name, method name, and JNI method signature.
- Step 6 - Return the VARCHAR2 result from JNI.CALL_STRING_METHOD to the caller; this value represents the previous value of the property before the update, or NULL if the property was not previously set.

---
**Decision Points**

No conditional decision points exist within this function. The implementation follows a single, unconditional execution path: build the argument list, populate both arguments, and invoke the JNI method. All branching, if any, is handled internally by the JNI layer or the JVM.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Exactly two string arguments must be supplied (property name and property value); the JNI argument list is explicitly sized to 2, and both positions must be populated before the Java method is called.
- BR-002 - The property name (a0) and property value (a1) are passed as Java String types; no type conversion beyond VARCHAR2-to-String mapping is performed.
- BR-003 - The target Java method is the static method java.lang.System.setProperty; the function must reference the exact JNI signature '(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;' to resolve the correct method overload.
- BR-004 - The function returns the prior value of the named system property as a VARCHAR2; callers should handle a NULL return, which indicates the property had no previous value.
- BR-005 - This function has no direct database interactions; all side effects occur within the JVM system property store and are therefore outside Oracle transactional control.

---
**Implementation Logic**

```plsql
  FUNCTION setProperty(
    a0    VARCHAR2,
    a1    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(2);
    JNI.ADD_STRING_ARG(args, a0);
    JNI.ADD_STRING_ARG(args, a1);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'setProperty', '(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-064 - WEBUTIL.SHOWBEANS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.INITWEBUTIL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Controls the visibility of the WebUtil hidden window (WEBUTIL_HIDDEN_WINDOW) by either displaying or concealing it based on the supplied boolean flag. When showing the window, the procedure captures the currently focused form item so that focus can be restored when the window is subsequently hidden. This routine is invoked exclusively during WebUtil initialisation and operates only while the form is in NORMAL mode to avoid interference with Enter Query Mode.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| show | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-046](#SP-046--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the boolean parameter 'show', which determines whether the WebUtil hidden window should be displayed or hidden.
- Step 2 - Obtain a handle to the WebUtil hidden window by calling FIND_WINDOW with the constant WEBUTIL_HIDDEN_WINDOW.
- Step 3 - Check whether the form is currently in NORMAL system mode; if the mode is not NORMAL (e.g., Enter Query Mode), the procedure takes no further action, preventing unintended UI changes during query entry.
- Step 4 - Validate the window handle using WEBUTIL.ID_NULL (SP-046); if the handle is null (window not found), the procedure takes no further action.
- Step 5 - If 'show' is TRUE: capture the currently focused item by calling FIND_ITEM against SYSTEM.CURSOR_ITEM and store it in the module-level variable m_infoFrom; set the window title to 'WebUtil ' concatenated with WEBUTIL_VERSION; display the hidden window using SHOW_WINDOW; navigate focus to WEBUTIL_DUMMY_ITEM.
- Step 6 - If 'show' is FALSE: check whether the previously captured item handle (m_infoFrom) is non-null using WEBUTIL.ID_NULL (SP-046); if non-null, restore focus to that item using GO_ITEM; hide the window using HIDE_WINDOW.

---
**Decision Points**

DP-001

Condition: SYSTEM.MODE equals 'NORMAL'.

TRUE: Proceed to evaluate the window handle and apply show/hide logic.

FALSE: Exit the procedure immediately without modifying any window state, preserving Enter Query Mode integrity.

---

DP-002

Condition: The window handle returned by FIND_WINDOW for WEBUTIL_HIDDEN_WINDOW is not null (evaluated via WEBUTIL.ID_NULL).

TRUE: Proceed to apply the show or hide operation to the window.

FALSE: Exit the procedure without attempting any window operation, avoiding a runtime error on an invalid handle.

---

DP-003

Condition: The 'show' input parameter is TRUE.

TRUE: Capture the current cursor item into m_infoFrom, set the window title, display the window, and navigate focus to WEBUTIL_DUMMY_ITEM.

FALSE: Attempt to restore focus to the previously saved item (m_infoFrom) and hide the window.

---

DP-004

Condition: When hiding the window, the previously saved item handle m_infoFrom is not null (evaluated via WEBUTIL.ID_NULL).

TRUE: Navigate focus back to the item stored in m_infoFrom before hiding the window.

FALSE: Skip the GO_ITEM call and proceed directly to hiding the window.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must not alter window visibility or focus when the form system mode is anything other than 'NORMAL'; this explicitly protects Enter Query Mode from unintended UI side effects (per inline source comment referencing Bug 2955789).
- BR-002 - A valid, non-null window handle for WEBUTIL_HIDDEN_WINDOW must exist before any show or hide operation is attempted; the handle is validated using WEBUTIL.ID_NULL (SP-046).
- BR-003 - When displaying the WebUtil hidden window, the currently focused form item must be recorded in m_infoFrom so that focus can be accurately restored when the window is later hidden.
- BR-004 - The WebUtil hidden window title must be set to the string 'WebUtil ' concatenated with the WEBUTIL_VERSION constant each time the window is shown, ensuring the version is always visible in the window title bar.
- BR-005 - Focus must be directed to WEBUTIL_DUMMY_ITEM immediately after the hidden window is shown, ensuring correct form navigation while the WebUtil window is active.
- BR-006 - Focus restoration to the originating item (m_infoFrom) is conditional; it is only performed if m_infoFrom holds a non-null item handle, preventing a GO_ITEM call against an invalid reference.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ShowBeans(show BOOLEAN) is
    hWin WINDOW := FIND_WINDOW(WEBUTIL_HIDDEN_WINDOW);
  begin
    -- Bug 2955789 - don't attempt to do this when in Enter Query Mode
    if name_in('SYSTEM.MODE') = 'NORMAL' then 
      if not ID_NULL(hWin) then 
        if show then 
          m_infoFrom := FIND_ITEM(name_in('SYSTEM.CURSOR_ITEM'));
          SET_WINDOW_PROPERTY(hWin,TITLE,'WebUtil '||WEBUTIL_VERSION);
          SHOW_WINDOW(hWin);
          go_item(WEBUTIL_DUMMY_ITEM);
        else
          if not id_null(m_infoFrom) then 
              go_item(m_infoFrom);
          end if;
          HIDE_WINDOW(hWin);
        end if;
      end if;
    end if;
  end ShowBeans;
```

#### SP-065 - WEBUTIL.URL_TO_CLIENT

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Transfers a server-side or network-accessible file, identified by a URL, to a specified destination path on the client machine. The function acts as a thin wrapper that delegates the actual download operation to WEBUTIL.DOWNLOADFROMURL (SP-021), returning a Boolean result indicating success or failure. It is invoked during Excel report generation to deliver the report file to the end user's local file system.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| fileSize | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.DOWNLOADFROMURL ([SP-021](#SP-021--WEBUTIL.DOWNLOADFROMURL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the source URL of the file to be downloaded (sourceURL), the target file path on the client machine (clientDestination), and an optional expected file size in bytes (fileSize; defaults to 0 if not supplied).
- Step 2 - Delegate the download operation entirely to WEBUTIL.DOWNLOADFROMURL (SP-021), passing all three parameters unchanged.
- Step 3 - Return the Boolean result produced by WEBUTIL.DOWNLOADFROMURL (SP-021) directly to the caller, indicating whether the file transfer completed successfully.

---
**Decision Points**

No conditional branching exists within this function. All decision logic is encapsulated inside WEBUTIL.DOWNLOADFROMURL (SP-021). The function unconditionally invokes SP-021 and propagates its return value.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must always delegate file download execution to WEBUTIL.DOWNLOADFROMURL (SP-021); no alternative download mechanism is permitted within this wrapper.
- BR-002 - The fileSize parameter is optional; when not provided by the caller, it defaults to 0, and WEBUTIL.DOWNLOADFROMURL (SP-021) is responsible for handling that default value appropriately.
- BR-003 - The function must return the Boolean result from WEBUTIL.DOWNLOADFROMURL (SP-021) unmodified, ensuring the caller receives an accurate indication of whether the client-side file transfer succeeded or failed.

---
**Implementation Logic**

```plsql
  FUNCTION URL_To_Client(sourceURL         in VARCHAR2, 
                         clientDestination in VARCHAR2, 
                         fileSize          in PLS_INTEGER default 0) return BOOLEAN is
  BEGIN
      return WebUtil_Core.DownLoadFromURL(sourceURL, 
                                        clientDestination, 
                                        fileSize);
  END URL_To_Client;
```

#### SP-066 - WEBUTIL.WRITEDATA

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Invokes the Java-layer WriteData method on an AppServerFileWriter object to write a string payload to a file on the application server. The procedure acts as a PL/SQL-to-Java bridge, passing the supplied data string to the underlying JNI call and returning a Boolean indicating whether the write operation succeeded.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the AppServerFileWriter Java object reference (obj) and the string data to be written (a0) as input parameters.
- Step 2 - Create a JNI argument list sized for one argument by calling JNI.CREATE_ARG_LIST(1).
- Step 3 - Add the string parameter a0 to the argument list by calling JNI.ADD_STRING_ARG(args, a0).
- Step 4 - Invoke the Java method WriteData on the AppServerFileWriter class via JNI.CALL_BOOLEAN_METHOD, passing the object reference, the fully qualified class name (oracle/forms/webutil/fileTransfer/AppServerFileWriter), the method name, the method signature ((Ljava/lang/String;)Z), and the prepared argument list.
- Step 5 - Return the Boolean result produced by the JNI call to the caller (WEBUTIL.SETDATA), indicating success (TRUE) or failure (FALSE) of the write operation.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The procedure constructs the JNI call unconditionally and returns the Boolean result directly from the Java layer without branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The data string (a0) must be passed as a VARCHAR2 value; the JNI argument list is constructed to accept exactly one string argument, and no additional arguments are permitted.
- BR-002 - The target Java class is fixed as oracle/forms/webutil/fileTransfer/AppServerFileWriter and the target method signature is fixed as (Ljava/lang/String;)Z; these values are not configurable at runtime.
- BR-003 - The function returns FALSE as the default fallback value supplied to JNI.CALL_BOOLEAN_METHOD, meaning any unhandled JNI-level failure results in a FALSE return rather than an unhandled exception propagating to the caller.
- BR-004 - This function is intended to be called exclusively from WEBUTIL.SETDATA; direct invocation from other contexts is not supported by the documented invocation chain.

---
**Implementation Logic**

```plsql
  FUNCTION WriteData(
    obj   ORA_JAVA.JOBJECT,
    a0    VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_BOOLEAN_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileWriter', 'WriteData', '(Ljava/lang/String;)Z', args); 
  END;
```

#### SP-067 - WEBUTIL_CORE.CUSTOMEVENTHANDLER

**Invoked From:**

- pr_mass_order_fmb.xml [Trigger: WHEN-CUSTOM-ITEM-EVENT]

---

**Screen:**

N/A

---

**Purpose**

Acts as the central dispatcher for custom item events raised by the WebUtil bean layer within the Mass Order form. When the WHEN-CUSTOM-ITEM-EVENT trigger fires, this procedure receives the event name and its serialised parameter string, extracts the data payload and multipart metadata, and routes execution to the appropriate WebUtil handler routine (logging, error reporting, bean registration, host-callback execution, or file-transfer processing). Any unrecognised event name is silently discarded; all other exceptions are re-raised to the caller.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| EventName | VARCHAR2 | IN |
| EventParameters | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERROR ([SP-023](#SP-023--WEBUTIL.ERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETNUMBER ([SP-036](#SP-036--WEBUTIL.GETNUMBER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-052](#SP-052--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.REGISTERBEAN ([SP-058](#SP-058--WEBUTIL.REGISTERBEAN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETDATA ([SP-062](#SP-062--WEBUTIL.SETDATA)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETPROPERTY ([SP-063](#SP-063--WEBUTIL.SETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the incoming event name (EventName) and its serialised parameter string (EventParameters).
- Step 2 - Validate that EventName is one of the five recognised WebUtil events: WUC_LOG_EVENT, WUC_ERROR_EVENT, WUC_REGISTER, WUH_CALLBACK_EVENT, or WUT_TRANSFER_EVENT. If not, raise the local 'unhandled' exception, which is caught silently, and exit.
- Step 3 - Extract the primary data payload by calling get_parameter_attr against the key WUC_DATA, storing the result in dataPayload.
- Step 4 - Extract the multipart descriptor by calling get_parameter_attr against the key WUC_DATA_MULTIPART, storing the result in dataMultiPart.
- Step 5 - Parse dataMultiPart using DelimStr.getNumber to derive the current chunk sequence number (chunkNumber) and the total number of chunks required to form the complete payload (PayloadChunks).
- Step 6 - Route to the appropriate handler based on EventName:
  - WUC_LOG_EVENT: call WEBUTIL.LOG (WebUtil_Core.log) with dataPayload and the non-error flag (false).
  - WUC_ERROR_EVENT: call WEBUTIL.LOG (WebUtil_Core.log) with dataPayload and the error flag (true).
  - WUC_REGISTER: call WEBUTIL.REGISTERBEAN (registerBean) passing dataPayload to register the bean component.
  - WUH_CALLBACK_EVENT: convert dataPayload to a number and store it in the package-level variable m_lastCallback; if conversion fails, call WEBUTIL.ERROR to report error code 408; if m_lastCallback is populated, execute the corresponding trigger stored in m_callbacks; if m_lastCallback is null, call WEBUTIL.LOG to record a warning that no callback trigger was specified.
  - WUT_TRANSFER_EVENT: call WEBUTIL.SETDATA (WebUtil_File_Transfer.setData) with dataPayload to stage the transferred file data, then call WEBUTIL.SETPROPERTY (WebUtil_Core.setProperty) to mark the WUT_TRANSFER_EVENT property as RECEIVED on the WUT_PACKAGE component.
- Step 7 - On completion of the routed handler, return control to the calling trigger. If the 'unhandled' exception was raised in Step 2, suppress it and return silently. All other exceptions propagate to the caller.

---
**Decision Points**

DP-001

Condition: EventName is NOT one of 'WUC_LOG_EVENT', 'WUC_ERROR_EVENT', 'WUC_REGISTER', 'WUH_CALLBACK_EVENT', 'WUT_TRANSFER_EVENT'.

TRUE: Raise the local 'unhandled' exception; the exception handler catches it silently and the procedure exits without further processing.

FALSE: Continue to extract data payload and multipart metadata, then proceed to event routing.

---

DP-002

Condition: EventName = 'WUC_LOG_EVENT'.

TRUE: Call WEBUTIL.LOG with dataPayload and error flag set to FALSE (informational log entry).

FALSE: Evaluate next event condition (DP-003).

---

DP-003

Condition: EventName = 'WUC_ERROR_EVENT'.

TRUE: Call WEBUTIL.LOG with dataPayload and error flag set to TRUE (error log entry).

FALSE: Evaluate next event condition (DP-004).

---

DP-004

Condition: EventName = 'WUC_REGISTER'.

TRUE: Call WEBUTIL.REGISTERBEAN with dataPayload to register the bean.

FALSE: Evaluate next event condition (DP-005).

---

DP-005

Condition: EventName = 'WUH_CALLBACK_EVENT'.

TRUE: Attempt to convert dataPayload to a number and store in m_lastCallback; evaluate DP-006 and DP-007.

FALSE: Evaluate next event condition (DP-008).

---

DP-006

Condition: Conversion of dataPayload to a number raises INVALID_NUMBER.

TRUE: Call WEBUTIL.ERROR reporting error code 408 for WEBUTIL_CORE.CustomEventHandler; m_lastCallback remains unset.

FALSE: m_lastCallback is successfully populated with the numeric value.

---

DP-007

Condition: m_lastCallback IS NOT NULL after the numeric conversion attempt.

TRUE: Execute the trigger referenced by m_callbacks(m_lastCallback).

FALSE: Call WEBUTIL.LOG to record a warning that the callback trigger for the host command was not specified.

---

DP-008

Condition: EventName = 'WUT_TRANSFER_EVENT'.

TRUE: Call WEBUTIL.SETDATA with dataPayload to stage file-transfer data, then call WEBUTIL.SETPROPERTY to set the WUT_TRANSFER_EVENT property to 'RECEIVED' on the WUT_PACKAGE component.

FALSE: No further routing applies (all recognised events have been evaluated).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only the five predefined WebUtil event names (WUC_LOG_EVENT, WUC_ERROR_EVENT, WUC_REGISTER, WUH_CALLBACK_EVENT, WUT_TRANSFER_EVENT) are considered valid. Any other event name is silently ignored and causes no processing or error to be raised to the calling form trigger.
- BR-002 - The data payload (WUC_DATA) and multipart descriptor (WUC_DATA_MULTIPART) must always be extracted from EventParameters before any event-specific routing is performed, regardless of which event type is being handled.
- BR-003 - For WUH_CALLBACK_EVENT, the dataPayload must be convertible to a valid number representing a callback index. A non-numeric payload is treated as a configuration error and must be reported via WEBUTIL.ERROR using error code 408; processing of the callback is abandoned.
- BR-004 - A WUH_CALLBACK_EVENT with a null callback index (m_lastCallback IS NULL after conversion) must not attempt trigger execution; a warning must be logged via WEBUTIL.LOG instead.
- BR-005 - For WUT_TRANSFER_EVENT, the file-transfer data must be staged via WEBUTIL.SETDATA before the transfer status property is updated to 'RECEIVED' via WEBUTIL.SETPROPERTY; both operations are mandatory for correct transfer completion signalling.
- BR-006 - Exceptions other than the locally declared 'unhandled' exception must be re-raised unconditionally, ensuring that unexpected runtime errors are visible to the calling form trigger rather than being suppressed.

---
**Implementation Logic**

```plsql
  PROCEDURE CustomEventHandler(EventName       in VARCHAR2, 
                               EventParameters in VARCHAR2) is
    dataPayload   VARCHAR2(32767 char);   
    dataMultiPart VARCHAR2(61 char); /* should be enough! */ 
    chunkNumber   PLS_INTEGER;
    PayloadChunks PLS_INTEGER;
    dataType      PLS_INTEGER;
    unhandled     EXCEPTION;
  begin
    --Bug 2839033 - check for valid events only      
    if EventName not in ('WUC_LOG_EVENT',
                         'WUC_ERROR_EVENT', 
                         'WUC_REGISTER',
                         'WUH_CALLBACK_EVENT', 
                         'WUT_TRANSFER_EVENT') then  
      raise unhandled;
    end if;                        

    -- We're pretty much always going to need the data payload and 
    -- number of parts that make up that payload so get it now..
    get_parameter_attr(EventParameters,'WUC_DATA',dataType, dataPayload);
    get_parameter_attr(EventParameters,'WUC_DATA_MULTIPART',dataType, dataMultiPart);      
    -- split the MULTIPART info to work out how many messages from the 
    -- client are required to create the completed payload
    chunkNumber   := DelimStr.getNumber(dataMultiPart,1,true,'/');
    PayloadChunks := DelimStr.getNumber(dataMultiPart,2,true,'/');

    -- Now deal with the specific events that the client may dispatch
    -- This section will have to be extended for each new event that we 
    -- Add in order to hook the handler code for that message to the data 
    -- that is being sent - shame we can't subclass in PL/SQL :-)      
    if EventName = 'WUC_LOG_EVENT' then
        WebUtil_Core.log(dataPayload,false);
    elsif EventName = 'WUC_ERROR_EVENT' then
        WebUtil_Core.log(dataPayload,true);
    elsif EventName = 'WUC_REGISTER' then 
        registerBean(dataPayload);
    elsif EventName = 'WUH_CALLBACK_EVENT' then 
      begin 
        m_lastCallback := to_number(dataPayload);
      exception
          when INVALID_NUMBER then 
            error(WebUtil_Core.WUC_PACKAGE,408,'WEBUTIL_CORE.CustomEventHandler');
      end;
      if m_lastCallback is not null then 
          EXECUTE_TRIGGER(m_callbacks(m_lastCallback));
      else
            log('Callback trigger for host command not specified',true);
      end if;
    elsif EventName = 'WUT_TRANSFER_EVENT' then 
      WebUtil_File_Transfer.setData(dataPayload);
      WebUtil_Core.setProperty(WebUtil_Core.WUT_PACKAGE, 'WUT_TRANSFER_EVENT','RECEIVED');
    end if;
  exception
    when unhandled then
      null;
    when OTHERS then
      raise;
  end CustomEventHandler;
```

#### SP-068 - ADD_ERROR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.SAVE_FILE]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Records a runtime error condition within the D2KWUTIL utility library by setting a shared error flag, composing a formatted error message on the error stack, and writing the entry to the debug log. It provides a single, consistent mechanism for all calling procedures in D2KWUTIL to report errors without raising exceptions.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| CallingFunction | VARCHAR2 | IN |
| SetErrorText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-072](#SP-072--DEBUGLOG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Accept the name of the calling function (CallingFunction) and the descriptive error text (SetErrorText) as inputs.
- Step 2 - Set the package-level flag ERROR_ENCOUNTERED to TRUE, signalling that an error condition is now active.
- Step 3 - Compose the ERROR_STACK value by concatenating CallingFunction, a colon-space separator, and the first 1,968 characters of SetErrorText, truncating any excess to prevent overflow.
- Step 4 - Invoke DEBUGLOG (SP-072) at debug level 99, passing the literal tag 'Add_Error' and the composed ERROR_STACK string, so the error is persisted to the debug log for diagnostic review.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The procedure executes all steps unconditionally for every invocation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The ERROR_ENCOUNTERED flag MUST be set to TRUE whenever any error is reported, allowing upstream callers to detect that a failure has occurred.
- BR-002 - The error message stored on ERROR_STACK MUST be prefixed with the name of the calling function followed by a colon-space separator to provide unambiguous traceability to the originating routine.
- BR-003 - The error text component of ERROR_STACK MUST be truncated to a maximum of 1,968 characters to prevent stack overflow or variable-length violations.
- BR-004 - Every recorded error MUST be written to the debug log via DEBUGLOG (SP-072) at severity level 99, ensuring a persistent diagnostic trail regardless of whether the caller inspects ERROR_STACK.

---
**Implementation Logic**

```plsql

PROCEDURE Add_Error (CallingFunction in VARCHAR2, SetErrorText in VARCHAR2) is
begin 
  -- Just watch for value errors 
  ERROR_ENCOUNTERED  := TRUE;
  ERROR_STACK    := CallingFunction||': '||substr(SetErrorText,1,1968);
  Win_API_Debug.DebugLog(99,'Add_Error',ERROR_STACK);
end Add_Error;
```

#### SP-069 - ADD_EXTERNAL_ERRORS

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Collects and consolidates external error messages into a single formatted string for upstream display or logging. The function first drains the Oracle Forms tool_err error stack, appending each message to a buffer; if no tool_err entries exist, it falls back to the current SQL error message (SQLERRM). The resulting string is returned to the caller for further handling.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Declare a loop counter (iCounter) and a varchar2 buffer (vcErrBuff, max 1968 characters) to accumulate error text.
- Step 2 - Check whether the tool_err error stack contains one or more entries (tool_err.nerrors > 0).
- Step 3 - If the stack is non-empty, iterate from 1 to tool_err.nerrors; for each iteration, append a newline character followed by the current top-of-stack message (tool_err.message) to vcErrBuff.
- Step 4 - After each append attempt, handle a VALUE_ERROR exception: if the buffer capacity (1968 characters) is exceeded, exit the loop immediately to prevent overflow.
- Step 5 - After appending the message, pop the entry from the tool_err stack (tool_err.pop) and advance to the next iteration.
- Step 6 - If the tool_err stack was empty, evaluate SQLERRM; if it is not null, assign a newline followed by the SQL error message to vcErrBuff as the sole error entry.
- Step 7 - Return vcErrBuff to the caller, containing all collected error messages separated by newline characters (or an empty/null string if no errors were present).

---
**Decision Points**

DP-001

Condition:
tool_err.nerrors > 0 (the tool_err error stack contains at least one message)

TRUE:
Iterate over all entries in the tool_err stack, appending each message to the buffer and popping each entry after it is appended.

FALSE:
Skip the stack-draining loop and evaluate SQLERRM instead (see DP-002).

---

DP-002

Condition:
SQLERRM is not null (evaluated only when tool_err.nerrors = 0)

TRUE:
Append a newline followed by the SQLERRM text to vcErrBuff as the fallback error message.

FALSE:
Leave vcErrBuff unchanged (null/empty); the function returns no error text.

---

DP-003

Condition:
A VALUE_ERROR exception is raised during the concatenation of a tool_err message to vcErrBuff (buffer capacity of 1968 characters would be exceeded)

TRUE:
Exit the loop immediately, discarding any remaining tool_err entries to prevent a buffer overflow.

FALSE:
Continue the loop normally; pop the current entry and proceed to the next.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The tool_err stack takes precedence over SQLERRM; the SQLERRM fallback is only evaluated when the tool_err stack is empty.
- BR-002 - Each error message appended to the buffer must be preceded by a newline character (chr(10)) to ensure messages are separated when the buffer is displayed or logged.
- BR-003 - The accumulated error buffer must not exceed 1968 characters; if appending the next tool_err message would cause a VALUE_ERROR overflow, the loop terminates immediately and remaining stack entries are discarded.
- BR-004 - Every tool_err entry that is successfully appended to the buffer must be popped from the stack (tool_err.pop), ensuring the stack is consumed and not left in a partially read state.
- BR-005 - The function always returns a value (vcErrBuff), which may be null or empty if neither tool_err entries nor a SQLERRM value are present at the time of invocation.

---
**Implementation Logic**

```plsql

FUNCTION Add_External_Errors return varchar2 is
  iCounter   pls_integer;
  vcErrBuff  varchar2(1968);
begin 
  if tool_err.nerrors > 0 then 
    for iCounter in 1..tool_err.nerrors LOOP
      begin 
        vcErrBuff := vcErrBuff||chr(10)||tool_err.message;
      exception
        when VALUE_ERROR then 
          exit; /* String exceeds allowable buffer */
      end;
      tool_err.pop;
    end loop;
  elsif SQLERRM is not null then 
    vcErrBuff := chr(10)||SQLERRM; 
  end if;
  return vcErrBuff;
end Add_External_Errors;
```

#### SP-070 - BOOLTOCHAR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

BOOLTOCHAR is a utility function that converts a PL/SQL BOOLEAN value into its VARCHAR2 string equivalent ('TRUE' or 'FALSE'). It is used by multiple D2KWUTIL stored procedures-such as CHOOSEFILE, GET_ACTIVE_WINDOW, GET_ENVIRONMENT_STRING, GET_TEMP_DIRECTORY, GET_WINDOWS_DIRECTORY, and READ_REGISTRY-to produce a printable or comparable character representation of boolean results where a character type is required.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| ThisBoolean | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the IN parameter ThisBoolean, a PL/SQL BOOLEAN value passed by the calling routine.
- Step 2 - Evaluate the boolean value using an IF statement.
- Step 3 - If the evaluation is TRUE, return the VARCHAR2 literal 'TRUE' to the caller.
- Step 4 - If the evaluation is FALSE (or NULL resolves to the ELSE branch), return the VARCHAR2 literal 'FALSE' to the caller.

---
**Decision Points**

DP-001

Condition:
ThisBoolean evaluates to TRUE.

TRUE:
The function returns the VARCHAR2 string 'TRUE'.

FALSE:
The function returns the VARCHAR2 string 'FALSE'.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must always return a non-null VARCHAR2 value; every possible BOOLEAN input maps to either 'TRUE' or 'FALSE'.
- BR-002 - The returned string values are fixed literals ('TRUE' / 'FALSE') and must not be localised or altered, as calling routines (CHOOSEFILE, GET_ACTIVE_WINDOW, GET_ENVIRONMENT_STRING, GET_TEMP_DIRECTORY, GET_WINDOWS_DIRECTORY, READ_REGISTRY) may depend on exact string matching.
- BR-003 - The function has no database interactions and no external dependencies; its behaviour is entirely self-contained and deterministic based solely on the input parameter.

---
**Implementation Logic**

```plsql

  
  FUNCTION  BoolToChar(ThisBoolean IN BOOLEAN) return VARCHAR2 is
  begin
  	if ThisBoolean then 
  		RETURN 'TRUE';
  	else
  	    RETURN 'FALSE';
  	end if;
  end BoolToChar;

END;

PACKAGE WIN_API_DIALOG IS

/*-------------------------------------------------------------------------*\
 * WIN_API_DIALOG ->   This package is concerned with Displaying Common
 *      dialogs
 * Contents:
 *    Open_File    -> Open File Dialog
 *    Save_File    -> Save File Dialog
 *    Select_Printer    -> Printer Selection Dialog
 *    Choose_Font       -> Display the Font Selection Dialog
 *    Choose_Color      -> Display the Color Selection Dialog
 * Dependancies:
 *    WIN_API_ENVIRONMENT
 *    WIN_API
 *    WIN_API_DEBUG
\*-------------------------------------------------------------------------*/ 

/*-------------------------------------------------------------------------*\
 * Open_File        -> Displays the standard Open File dialog
 * Arguments: 
 *  Title           -> The Title for the Dialog Box
 *                     (Default -> 'Open File')
 *  StartDirectory  -> Where the dialog should start from
 *                     this should be in the format 'C:\TEMP'
 *                     (Default -> Windows Directory)
 *  FileFilter      ->  Restrict the list of files. The filter string 
 *                      should be in the format:
 *                      '<Description>|<filename>.<Extension>|'
 *                      typically this would be something like
 *                      'All files(*.*)|*.*|' or 'Text files(*.txt)|*.txt|'
 *                      "All Files" is the Default
 *  Modal           ->  Should the dialog be modal with respect to the 
 *                      application? 
 *                      default = TRUE
 *  AdvancedFlags   ->  (See list in WIN_API header) This option allows
 *                      you to change the attributes of the Open File 
 *                      dialog.  Here are some of the Flags that might
 *                      be of interest:
 *                      OFN_HIDEREADONLY  Hides the Read Only check box.
 *                      OFN_NONETWORKBUTTON  Hides the Network Button
 *                      OFN_EXPLORER    Display an Explorer style 
 *                        Dialog rather than the conventional one.
 *                      See your Microsoft docmentation for details on 
 *                      each flag.
 *                      To Set the Advanced_Flags varaible, just add the 
 *                      required flags together.  The default is:
 *                      WIN_API.OFN_PATHMUSTEXIST + WIN_API.OFN_FILEMUSTEXIST +
 *                      WIN_API.OFN_HIDEREADONLY + WIN_API.OFN_NOCHANGEDIR 
 *  RaiseExceptions ->  TRUE of FALSE(Default) If set to true, then if the 
 *                      command is not successful (e.g no filename is  
 *                      returned) then the explicit exception
 *                      NO_DATA_FOUND will be raised.
 *        
 * Returns:
 *  Path and name of the selected file
\*-------------------------------------------------------------------------*/
```

#### SP-071 - CLEAN_ERROR_STACK

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Resets the module-level error state by clearing the error flag and discarding any accumulated error messages. This utility procedure is called by multiple D2KWUTIL routines prior to or after processing to ensure a clean error context, preventing stale error information from affecting subsequent operations.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Set the module-level boolean variable ERROR_ENCOUNTERED to FALSE, indicating that no error is currently active.
- Step 2 - Set the module-level variable ERROR_STACK to NULL, discarding any previously accumulated error message text.
- Step 3 - Return control to the calling routine with the error state fully cleared.

---
**Decision Points**

No conditional decision points exist in this procedure. The reset of ERROR_ENCOUNTERED and ERROR_STACK is unconditional every time the procedure is invoked.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The error flag ERROR_ENCOUNTERED must always be reset to FALSE when this procedure is called, regardless of its prior value.
- BR-002 - The error message accumulator ERROR_STACK must always be set to NULL when this procedure is called, ensuring no residual error text persists into subsequent processing.
- BR-003 - This procedure accepts no input and produces no formal output; its sole effect is the side-effect reset of the shared error-state variables.
- BR-004 - Callers within D2KWUTIL (CHOOSEFILE, GET_ACTIVE_WINDOW, GET_ENVIRONMENT_STRING, GET_TEMP_DIRECTORY, GET_WINDOWS_DIRECTORY, READ_REGISTRY) are responsible for invoking this procedure at the appropriate point in their own logic to guarantee a clean error context.

---
**Implementation Logic**

```plsql

PROCEDURE Clean_Error_Stack is 
begin 
  -- just empty the variables
  ERROR_ENCOUNTERED  := FALSE;
  ERROR_STACK        := NULL;
end Clean_Error_Stack;
```

#### SP-072 - DEBUGLOG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: ADD_ERROR]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: SETDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

DEBUGLOG writes a formatted diagnostic message to either a Windows debug viewer or a text log file, depending on the current debug state and API availability. It is called by multiple D2kwutil procedures to record execution trace information at a specified severity level, and silently disables itself if an unhandled exception occurs to avoid disrupting the calling business process.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugLevel | PLS_INTEGER | IN |
| LoggingCall | VARCHAR2 | IN |
| LogString | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- SETDEBUG ([SP-078](#SP-078--SETDEBUG)) - matched by member name
- WEBUTIL.LENGTH ([SP-051](#SP-051--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)
- WINDEBUG ([SP-082](#SP-082--WINDEBUG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate the global debug state (iDebugState). If debugging is inactive (iDebugState = 0), paused (bDebugPaused = TRUE), or the supplied DebugLevel exceeds the configured threshold (iDebugLevel), exit immediately without writing any output.
- Step 2 - Optionally prepend a timestamp: if the bDebugTimeStamp flag is set, format the current system time as HH24:MI:SS and append a '>' separator to vcDateStamp.
- Step 3 - Construct the formatted debug string (vcDebugString) by combining the zero-padded DebugLevel, the optional timestamp, the left-padded LoggingCall label (30 characters), and a truncated portion of LogString so the total does not exceed 2,000 characters. WEBUTIL.LENGTH (SP-051) is used to determine the current length of vcDebugString during truncation.
- Step 4 - Determine the output channel based on iDebugState.
- Step 5 - If iDebugState = 2 (Windows debugger mode): check the DEBUG_API_ENABLED flag. If the API is available, call WINDEBUG (SP-082) to send vcDebugString to the Windows debug viewer. If the API is unavailable, call SETDEBUG (SP-078) to switch logging to file mode targeting 'd2kwutil.log', emit two diagnostic DebugLog entries recording the channel switch, and set bDebugType2Required := TRUE.
- Step 6 - If iDebugState ≠ 2 (file mode): check whether bDebugType2Required is TRUE and DEBUG_API_ENABLED has become available. If so, call SETDEBUG (SP-078) to reinstate Windows debugger mode, emit two diagnostic DebugLog entries recording the restoration, set bDebugType2Required := FALSE, and re-invoke DebugLog for the original message. Otherwise, open the log file identified by vcDebugFile in append mode using TEXT_IO, write vcDebugString, and close the file.
- Step 7 - If any exception occurs during the procedure, set iDebugState := 0 to disable all further debug output and suppress the error, preventing diagnostic code from interfering with the calling process.

---
**Decision Points**

DP-001

Condition:
iDebugState = 0

TRUE:
Procedure exits immediately; no logging is performed.

FALSE:
Processing continues to the next guard check.

---

DP-002

Condition:
bDebugPaused = TRUE

TRUE:
Procedure exits immediately; no logging is performed.

FALSE:
Processing continues to the next guard check.

---

DP-003

Condition:
DebugLevel > iDebugLevel

TRUE:
Message is below the configured verbosity threshold; procedure exits immediately without logging.

FALSE:
Message meets the threshold; processing continues to format and write the log entry.

---

DP-004

Condition:
bDebugTimeStamp = TRUE

TRUE:
Current system time (HH24:MI:SS) is formatted and appended to vcDateStamp for inclusion in the log entry.

FALSE:
vcDateStamp remains empty; no timestamp is included in the log entry.

---

DP-005

Condition:
iDebugState = 2 (Windows debugger output mode)

TRUE:
Attempt to write the message via the Windows debug API (see DP-006).

FALSE:
Attempt to write the message to a file (see DP-007).

---

DP-006

Condition:
DEBUG_API_ENABLED = TRUE (evaluated when iDebugState = 2)

TRUE:
Call WINDEBUG (SP-082) to send vcDebugString to the Windows debug viewer.

FALSE:
API is unavailable; call SETDEBUG (SP-078) to switch to file mode, emit channel-switch diagnostic entries, and set bDebugType2Required := TRUE.

---

DP-007

Condition:
bDebugType2Required = TRUE AND DEBUG_API_ENABLED = TRUE (evaluated when iDebugState ≠ 2)

TRUE:
The Windows debug API has become available again; call SETDEBUG (SP-078) to reinstate debugger mode, emit restoration diagnostic entries, reset bDebugType2Required := FALSE, and re-invoke DebugLog for the original message.

FALSE:
Continue with file-based logging: open vcDebugFile in append mode, write vcDebugString via TEXT_IO, and close the file.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Logging is suppressed entirely when iDebugState = 0, bDebugPaused = TRUE, or the supplied DebugLevel exceeds iDebugLevel; no output is produced under any of these conditions.
- BR-002 - The formatted debug string must not exceed 2,000 characters; LogString is truncated to fit within this limit after the fixed prefix (level badge, optional timestamp, and padded call label) has been measured using WEBUTIL.LENGTH (SP-051).
- BR-003 - The LoggingCall label is always right-padded to 30 characters in the output to maintain consistent column alignment across log entries.
- BR-004 - When iDebugState = 2 and the Windows debug API is unavailable, DEBUGLOG must automatically fall back to file-based logging by invoking SETDEBUG (SP-078), and must record the channel switch as a diagnostic log entry before processing the original message.
- BR-005 - Once file-based fallback is active (bDebugType2Required = TRUE), DEBUGLOG must automatically reinstate Windows debugger mode by invoking SETDEBUG (SP-078) as soon as DEBUG_API_ENABLED becomes TRUE, and must record the restoration as a diagnostic log entry before processing the original message.
- BR-006 - Any unhandled exception within DEBUGLOG must be silently caught and resolved by setting iDebugState := 0, ensuring that diagnostic instrumentation never propagates errors to the calling business procedure.

---
**Implementation Logic**

```plsql
   
PROCEDURE DebugLog (DebugLevel  IN PLS_INTEGER, 
                    LoggingCall IN VARCHAR2, 
                    LogString   IN VARCHAR2) is
 vcDateStamp   VARCHAR2(10);
 vcDebugString VARCHAR2(2000);
 hFile         TEXT_IO.FILE_TYPE;
begin
  if iDebugState = 0 then 
  	NULL;
  elsif bDebugPaused then 
  	NULL;
  elsif DebugLevel > iDebugLevel then 
  	NULL;
  else
  	-- Sort out the Datestamp	
  	if bDebugTimeStamp then 
  		vcDateStamp := to_char(SYSDATE,'HH24:MI:SS')||'> ';
  	end if;
  
  	-- Construct the final String
  	vcDebugString := '<'||lpad(to_char(DebugLevel),2,0)||'> '||vcDateStamp||rpad(LoggingCall||':',30);
    vcDebugString := vcDebugString||substr(LogString,1,(2000-length(vcDebugString)));
  
  	if iDebugState = 2 then
  		if DEBUG_API_ENABLED then 
  	   		win_api_debug.WinDebug(vcDebugString);
  		else
  			-- Can't use API calls if the API functions aren't there
	  		-- So Switch to File Logging to d2kwut$.log
	  		SetDebug(1,nvl(vcDebugFile,'d2kwutil.log'),iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Unable to Log to Debugger Switching to File');
			DebugLog(DebugLevel,LoggingCall,LogString);	  		
	  		bDebugType2Required := TRUE;
	  	end if;
  	else
     	if bDebugType2Required and DEBUG_API_ENABLED then
	     	-- API now Available - Reinstate Debugging to Debugger
	  		SetDebug(2,vcDebugFile,iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Restoring Logging to Debugger');
	  		bDebugType2Required := FALSE;
	  		DebugLog(Debuglevel,LoggingCall,LogString);
	
	  	else
		 	hFile := TEXT_IO.FOPEN(vcDebugFile,'A');
		 	TEXT_IO.PUT_LINE(hFile,vcDebugString);
		 	TEXT_IO.FCLOSE(hFile);
		end if;
  	end if;
  end if;
 exception
  	-- Don't let the debugging cause Problems of it's own
  	when others then 
  		iDebugState := 0;
 end DebugLog;
```

#### SP-073 - GET_ENVIRONMENT_STRING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value of a named operating-system environment variable by delegating to the D2KWUTIL native library function D2KWUTIL_GETDOSENV. The function is invoked by WEBUTIL.GETVAR and returns the resolved variable value as a VARCHAR2 string. If the Win API layer is unavailable, or if the variable cannot be resolved, the function either raises an exception or returns NULL, depending on the caller-supplied RaiseExceptions flag.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VariableName | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-068](#SP-068--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-069](#SP-069--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-070](#SP-070--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-071](#SP-071--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_GETDOSENV ([SP-007](#SP-007--D2KWUTIL.D2KWUTIL_GETDOSENV)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-072](#SP-072--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-077](#SP-077--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log entry diagnostics by calling DEBUGLOG, recording the VariableName argument and the string representation of RaiseExceptions (converted via BOOLTOCHAR).
- Step 2 - Clear any pre-existing error state by calling CLEAN_ERROR_STACK.
- Step 3 - Check whether the Win API layer is available (WIN_API.API_ENABLED). If it is not available, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 4 - Register the external function call for D2KWUTIL_GETDOSENV using REGISTER_FUNCTION_CALL, supplying the function handle, name, and parameter type signature.
- Step 5 - Prepare the lookup buffer: wrap VariableName in percent signs (e.g. %VAR_NAME%) to form the OS-style variable reference, initialise a 512-character output buffer padded with null characters, and set the buffer length to 512.
- Step 6 - Invoke D2KWUTIL.D2KWUTIL_GETDOSENV with the function handle, the formatted variable name, the output buffer, and the buffer length; capture the integer return code (iRC) representing the length of the resolved value.
- Step 7 - Log the result by calling DEBUGLOG, recording the returned value length (iRC) and the contents of the output buffer.
- Step 8 - Evaluate the resolution outcome: if iRC equals 0 or the output buffer still equals the formatted input string (meaning the variable was not expanded), record an error via ADD_ERROR and either raise NO_DATA_FOUND (when RaiseExceptions is TRUE) or return NULL (when RaiseExceptions is FALSE).
- Step 9 - If resolution succeeded, return the populated output buffer as the environment variable's value.
- Step 10 - In the exception block: re-raise NO_DATA_FOUND as-is; for WIN_API.NOT_AVAILABLE, log the error via ADD_ERROR and re-raise; for all other exceptions, log the error via ADD_ERROR combined with ADD_EXTERNAL_ERRORS and re-raise.

---
**Decision Points**

DP-001

Condition: WIN_API.API_ENABLED is TRUE.

TRUE: Proceed to register the external function and invoke D2KWUTIL.D2KWUTIL_GETDOSENV to resolve the environment variable.

FALSE: Raise WIN_API.NOT_AVAILABLE, bypassing all resolution logic.

---

DP-002

Condition: The return code iRC equals 0 OR the output buffer value equals the formatted input string (variable was not expanded).

TRUE: The environment variable could not be resolved; log the failure via ADD_ERROR, then branch to DP-003.

FALSE: The variable was resolved successfully; return the output buffer value to the caller.

---

DP-003

Condition: RaiseExceptions is TRUE (evaluated only when DP-002 is TRUE).

TRUE: Raise NO_DATA_FOUND to signal the resolution failure to the caller.

FALSE: Return NULL silently to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function may only execute environment variable resolution when the Win API layer is active (WIN_API.API_ENABLED = TRUE); if the layer is unavailable, the function must raise WIN_API.NOT_AVAILABLE without attempting any lookup.
- BR-002 - The environment variable name must be wrapped in percent signs before being passed to D2KWUTIL_GETDOSENV (e.g. VariableName 'PATH' becomes '%PATH%'), conforming to the OS environment variable reference syntax.
- BR-003 - A return code of 0 from D2KWUTIL_GETDOSENV, or an output buffer that remains equal to the formatted input string, is treated as a failed lookup; the function must record an error via ADD_ERROR in either case.
- BR-004 - The caller controls error propagation behaviour through the RaiseExceptions flag: when TRUE, an unresolved variable causes NO_DATA_FOUND to be raised; when FALSE (the default), NULL is returned instead.
- BR-005 - All exceptions except NO_DATA_FOUND must be logged via ADD_ERROR before being re-raised; unhandled 'others' exceptions must additionally incorporate external error details via ADD_EXTERNAL_ERRORS.
- BR-006 - The output buffer is fixed at 512 characters; environment variable values exceeding this length will be truncated to fit the buffer.

---
**Implementation Logic**

```plsql

FUNCTION Get_Environment_string (  VariableName      IN  VARCHAR2,
                                   RaiseExceptions   IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  vcBuff2    VARCHAR2(512);
  iBuff1    PLS_INTEGER;
  iRC        PLS_INTEGER;
begin 
  Win_api_debug.DebugLog(99,'Get_Environment_String','Args: VariableName="'||VariableName||'", RaiseExceptions='||win_api_debug.BoolToChar(RaiseExceptions));
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then
    win_api.Register_function_call(iGetDOSEnv,'d2kwutil_GetDOSEnv','LONG','*CHAR,*CHAR,LONG');
    vcBuff1    := '%'||VariableName||'%';
    vcBuff2    := RPAD(' ',512,CHR(0));
    iBuff1    := 512;
    iRC   := d2kwutil_GetDOSEnv(win_api.FunctionHandle(iGetDOSEnv),vcBuff1,vcBuff2,iBuff1);
    Win_api_debug.DebugLog(99,'Get_Environment_String','Result: Value Length='||to_char(iRC)||', Value='||vcBuff2);
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0  or vcBuff2 = vcBuff1 then 
    Win_API.Add_error('Get_Environment_String','Unable to get the value of the variable '||VariableName);
    if RaiseExceptions then
      raise NO_DATA_FOUND;
    else
      return NULL;
    end if;
  else
    return vcBuff2;
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Environment_String',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Environment_String',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Environment_String;
```

#### SP-074 - GET_TEMP_DIRECTORY

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the operating-system temporary directory path for the current Windows session by invoking the external D2KWUTIL Windows API function. The result is sanitised by stripping any trailing directory separator before being returned to the caller. If the API is unavailable or returns no value, the procedure records a structured error and either raises an exception or returns NULL, depending on the caller's preference.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-068](#SP-068--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-069](#SP-069--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-070](#SP-070--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-071](#SP-071--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_WINDIR ([SP-009](#SP-009--D2KWUTIL.D2KWUTIL_WINDIR)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-072](#SP-072--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-077](#SP-077--REGISTER_FUNCTION_CALL)) - matched by member name
- STRIPDIRSEP ([SP-080](#SP-080--STRIPDIRSEP)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log entry diagnostics: call DEBUGLOG (SP-072) at verbosity level 99, recording the procedure name and the value of the RaiseExceptions flag (converted to a readable string via BOOLTOCHAR (SP-070)).
- Step 2 - Initialise the error stack: call CLEAN_ERROR_STACK (SP-071) to clear any previously recorded API errors before processing begins.
- Step 3 - Initialise the return-code variable iRC to 0.
- Step 4 - Check API availability: evaluate the WIN_API.API_ENABLED flag.
- Step 5 - Register the external function: if the API is available, call REGISTER_FUNCTION_CALL (SP-077) to bind the internal handle iTmpDir to the external entry point 'd2kwutil_TmpDir' with the signature INT / *CHAR, INT.
- Step 6 - Prepare the output buffer: initialise vcBuff1 as a 512-character space-padded, null-terminated string.
- Step 7 - Invoke the Windows API: call D2KWUTIL.D2KWUTIL_WINDIR (SP-009) passing the registered function handle, the output buffer, and its length (512); capture the integer return code in iRC.
- Step 8 - Log the raw result: call DEBUGLOG (SP-072) again to record the return code and the raw buffer content.
- Step 9 - Evaluate the return code: if iRC equals 0, no directory value was returned; record an error via ADD_ERROR (SP-068) and either raise NO_DATA_FOUND or return NULL based on the RaiseExceptions flag.
- Step 10 - Return the cleaned path: if iRC is non-zero, pass vcBuff1 to STRIPDIRSEP (SP-080) to remove any trailing directory separator and return the result to the caller.
- Step 11 - Exception handling: re-raise NO_DATA_FOUND as-is; for WIN_API.NOT_AVAILABLE, log the NoAPI message via ADD_ERROR (SP-068) then re-raise; for all other exceptions, log a combined error message using ADD_ERROR (SP-068) and ADD_EXTERNAL_ERRORS (SP-069) then re-raise.

---
**Decision Points**

DP-001

Condition:
WIN_API.API_ENABLED is TRUE.

TRUE:
Proceed to register the external function handle, prepare the output buffer, and invoke D2KWUTIL.D2KWUTIL_WINDIR (SP-009).

FALSE:
Raise the WIN_API.NOT_AVAILABLE exception, which is caught by the exception block, logged via ADD_ERROR (SP-068), and re-raised to the caller.

---

DP-002

Condition:
The return code iRC returned by D2KWUTIL.D2KWUTIL_WINDIR (SP-009) equals 0 (no directory value was returned).

TRUE:
Record an error via ADD_ERROR (SP-068) with message 'No Value Returned', then evaluate DP-003.

FALSE:
Pass the populated buffer vcBuff1 to STRIPDIRSEP (SP-080) and return the sanitised directory path to the caller.

---

DP-003

Condition:
RaiseExceptions input parameter is TRUE (evaluated only when iRC = 0).

TRUE:
Raise NO_DATA_FOUND, which propagates to the caller.

FALSE:
Return NULL to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The Windows API layer must be enabled (WIN_API.API_ENABLED) before any attempt is made to resolve the temporary directory; if the API is unavailable the procedure must not return a path and must always raise WIN_API.NOT_AVAILABLE.
- BR-002 - The external function 'd2kwutil_TmpDir' must be registered via REGISTER_FUNCTION_CALL (SP-077) on every invocation before the API call is made; no cached or assumed handle may be used without registration.
- BR-003 - A return code of 0 from D2KWUTIL.D2KWUTIL_WINDIR (SP-009) is treated as a failure condition (no value returned); a structured error must be recorded via ADD_ERROR (SP-068) in all such cases.
- BR-004 - The caller controls error-propagation behaviour through the RaiseExceptions flag: when TRUE a NO_DATA_FOUND exception is raised on failure; when FALSE (the default) NULL is returned, allowing the caller to handle the absence of a value gracefully.
- BR-005 - The returned directory path must always be stripped of any trailing directory separator by STRIPDIRSEP (SP-080) before being passed to the caller, ensuring a consistent path format.
- BR-006 - All exceptions except NO_DATA_FOUND must be enriched with external error detail via ADD_EXTERNAL_ERRORS (SP-069) before being re-raised, ensuring complete diagnostic information is available to upstream error handlers.
- BR-007 - Entry and exit diagnostics must be written via DEBUGLOG (SP-072) at verbosity level 99, including the RaiseExceptions flag value and the raw API result, to support runtime tracing without affecting functional behaviour.

---
**Implementation Logic**

```plsql

FUNCTION Get_Temp_Directory (RaiseExceptions IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  iRC        PLS_INTEGER;
begin 
  Win_API_Debug.DebugLog(99,'Get_Temp_Directory','Args: RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	 	
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then 
    win_api.Register_function_call(iTmpDir,'d2kwutil_TmpDir','INT','*CHAR,INT');
    vcBuff1    := RPAD(' ',512,CHR(0));
    iRC   := d2kwutil_WinDir(win_api.FunctionHandle(iTmpDir),vcBuff1,512);
    Win_API_Debug.DebugLog(99,'Get_Temp_Directory','Result:  RC='||to_char(iRC)||', vcBuff1="'||vcBuff1||'"');	      
  else
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0 then 
    Win_API.Add_error('Get_Temp_Directory','No Value Returned');
    if RaiseExceptions then
      raise NO_DATA_FOUND;
    else
      return NULL;
    end if;
  else
    return WIN_API.StripDirSep(vcBuff1);
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Temp_Directory',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Temp_Directory',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Temp_Directory;
```

#### SP-075 - GET_WINDOWS_DIRECTORY

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the Windows directory path on the client workstation by delegating to the external D2KWUtil library function D2KWUTIL.D2KWUTIL_WINDIR. The result is cleaned of any trailing directory separator before being returned to the caller. The procedure supports optional exception raising to allow calling code to control error-handling behaviour.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-068](#SP-068--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-069](#SP-069--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-070](#SP-070--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-071](#SP-071--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_WINDIR ([SP-009](#SP-009--D2KWUTIL.D2KWUTIL_WINDIR)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-072](#SP-072--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-077](#SP-077--REGISTER_FUNCTION_CALL)) - matched by member name
- STRIPDIRSEP ([SP-080](#SP-080--STRIPDIRSEP)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log entry diagnostics by calling DEBUGLOG (SP-072) at verbosity level 99, recording the procedure name and the value of the RaiseExceptions flag converted to a character string via BOOLTOCHAR (SP-070).
- Step 2 - Clear any previously accumulated errors from the error stack by calling CLEAN_ERROR_STACK (SP-071).
- Step 3 - Initialise the return-code variable iRC to 0.
- Step 4 - Check whether the Win API layer is available (WIN_API.API_ENABLED). If not available, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 5 - Register the external function call for D2KWUTIL_WINDIR with its signature ('INT','*CHAR,INT') via REGISTER_FUNCTION_CALL (SP-077), binding it to the iWinDir function handle.
- Step 6 - Initialise the output buffer vcBuff1 as a 512-character null-padded string.
- Step 7 - Invoke D2KWUTIL.D2KWUTIL_WINDIR (SP-009) passing the registered function handle, the output buffer, and its maximum length (512). Capture the integer return code in iRC.
- Step 8 - Log the outcome by calling DEBUGLOG (SP-072) again, recording the return code and the raw buffer value.
- Step 9 - Evaluate iRC. If iRC equals 0 (no value returned), record an error via ADD_ERROR (SP-068) and either raise NO_DATA_FOUND (when RaiseExceptions is TRUE) or return NULL (when RaiseExceptions is FALSE).
- Step 10 - If iRC is non-zero, strip the trailing directory separator from vcBuff1 using STRIPDIRSEP (SP-080) and return the cleaned path to the caller.
- Step 11 - In the exception block: re-raise NO_DATA_FOUND as-is; for WIN_API.NOT_AVAILABLE, log the no-API message via ADD_ERROR (SP-068) and re-raise; for all other exceptions, log a combined error message built from the unhandled-error prefix and any external errors collected by ADD_EXTERNAL_ERRORS (SP-069) via ADD_ERROR (SP-068), then re-raise.

---
**Decision Points**

DP-001

Condition:
WIN_API.API_ENABLED is TRUE.

TRUE:
Proceed to register the external function and invoke D2KWUTIL.D2KWUTIL_WINDIR to retrieve the Windows directory.

FALSE:
Raise the WIN_API.NOT_AVAILABLE exception, bypassing all retrieval logic.

---

DP-002

Condition:
iRC (return code from D2KWUTIL.D2KWUTIL_WINDIR) equals 0.

TRUE:
No directory value was returned; log an error via ADD_ERROR and branch on RaiseExceptions (see DP-003).

FALSE:
A valid path was returned; strip the trailing directory separator via STRIPDIRSEP and return the result.

---

DP-003

Condition:
RaiseExceptions input parameter is TRUE (evaluated only when iRC = 0).

TRUE:
Raise NO_DATA_FOUND to propagate the failure to the caller.

FALSE:
Return NULL silently, suppressing the error from the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must not execute any external API calls unless WIN_API.API_ENABLED is TRUE; if the API layer is unavailable the WIN_API.NOT_AVAILABLE exception is raised immediately and the no-API message is recorded via ADD_ERROR.
- BR-002 - The error stack must be cleared at the start of every invocation via CLEAN_ERROR_STACK to prevent stale errors from previous calls from contaminating the current result.
- BR-003 - Every invocation must be logged at debug level 99 both on entry (with the RaiseExceptions flag value) and after the external call (with the return code and raw buffer), ensuring full auditability of the retrieval attempt.
- BR-004 - A return code of 0 from D2KWUTIL.D2KWUTIL_WINDIR is treated as a failure condition ('No Value Returned'); the error is recorded and the procedure either raises NO_DATA_FOUND or returns NULL depending on the RaiseExceptions flag.
- BR-005 - A non-zero return code indicates a valid Windows directory path; the path must be stripped of any trailing directory separator via STRIPDIRSEP before being returned to the caller.
- BR-006 - All exceptions (NO_DATA_FOUND, WIN_API.NOT_AVAILABLE, and unhandled errors) must be re-raised after error logging so that calling code retains full visibility of failures; errors for unhandled exceptions are enriched with external error detail via ADD_EXTERNAL_ERRORS.

---
**Implementation Logic**

```plsql

FUNCTION Get_Windows_Directory (RaiseExceptions IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  iRC        PLS_INTEGER;
begin 
  Win_API_Debug.DebugLog(99,'Get_Windows_Directory','Args: RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	 	
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then 
    win_api.Register_function_call(iWinDir,'d2kwutil_WinDir','INT','*CHAR,INT');

    vcBuff1    := RPAD(' ',512,CHR(0));
    iRC   := d2kwutil_WinDir(win_api.FunctionHandle(iWinDir),vcBuff1,512);
    Win_API_Debug.DebugLog(99,'Get_Windows_Directory','Result:  RC='||to_char(iRC)||', vcBuff1="'||vcBuff1||'"');	      
  else
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0 then 
    Win_API.Add_error('Get_Windows_Directory','No Value Returned');
    if RaiseExceptions then
      raise NO_DATA_FOUND;
    else
      return NULL;
    end if;
  else
    return WIN_API.StripDirSep(vcBuff1);
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Windows_Directory',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Windows_Directory',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Windows_Directory;
```

#### SP-076 - READ_REGISTRY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

READ_REGISTRY retrieves a named value from the Windows Registry for a given registry path and entry key. It translates the supplied path into a root-hive constant, delegates the actual registry read to the D2KWUTIL native library call D2KWUTIL_GETREGKEY, and returns the value as a VARCHAR2 string. The procedure supports an optional exception-raising mode so callers can choose between silent NULL returns and hard exceptions on failure. It is invoked indirectly through WEBUTIL.GETVAR to allow Oracle Forms to read host-machine registry settings at runtime.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RegPath | VARCHAR2 | IN |
| RegEntry | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-068](#SP-068--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-069](#SP-069--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-070](#SP-070--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-071](#SP-071--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_GETREGKEY ([SP-008](#SP-008--D2KWUTIL.D2KWUTIL_GETREGKEY)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-072](#SP-072--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-077](#SP-077--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log entry diagnostics by calling DEBUGLOG (severity 99) recording RegPath, RegEntry, and the Boolean value of RaiseExceptions converted via BOOLTOCHAR.
- Step 2 - Clear any pre-existing error state by calling CLEAN_ERROR_STACK.
- Step 3 - Check whether the WIN_API integration layer is available (WIN_API.API_ENABLED). If it is not available, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 4 - Register the native function handle for D2KWUTIL_GETREGKEY with the correct calling-convention signature by calling REGISTER_FUNCTION_CALL.
- Step 5 - Parse the root hive from the leading segment of RegPath (the text before the first backslash, uppercased) and map it to the integer constant expected by D2KWUTIL_GETREGKEY: HKEY_LOCAL_MACHINE->0, HKEY_CLASSES_ROOT->1, HKEY_CURRENT_USER->2, HKEY_USERS->3, HKEY_CURRENT_CONFIG->4.
- Step 6 - If the root hive token does not match any recognised value, call ADD_ERROR recording the invalid key, then conditionally raise NO_DATA_FOUND if RaiseExceptions is TRUE; otherwise continue.
- Step 7 - Prepare call buffers: extract the sub-path (everything after the first backslash) into vcBuff1, copy RegEntry into vcBuff2, and initialise the 2000-byte output buffer vcBuff3 padded with CHR(0).
- Step 8 - Determine the environment-variable expansion flag (iBuff3): if WIN_API.COMPAT_EXPAND_REG_VALUES is FALSE, set iBuff3 to 1 (suppression) and log a compatibility diagnostic via DEBUGLOG; otherwise set iBuff3 to 0 (expansion enabled).
- Step 9 - Invoke D2KWUTIL_GETREGKEY passing the function handle, root-hive integer, sub-path, entry name, output buffer, buffer length (2000), and expansion flag; capture the integer return code in iRC.
- Step 10 - Log the result (iRC and the returned buffer content) via DEBUGLOG.
- Step 11 - Evaluate iRC for error codes: -1 (entry not found), -2 (unsupported data type), -3 (value exceeds buffer length), -4 (environment-string expansion failure). For each error code, call ADD_ERROR with a descriptive message, then either return NULL or raise the appropriate exception (NO_DATA_FOUND or VALUE_ERROR) depending on RaiseExceptions.
- Step 12 - If iRC indicates success (no negative error code), return vcBuff3 containing the registry value to the caller.
- Step 13 - In the exception block, re-raise NO_DATA_FOUND and VALUE_ERROR unchanged; handle WIN_API.NOT_AVAILABLE by calling ADD_ERROR then re-raising; handle all other exceptions by calling ADD_ERROR (appending ADD_EXTERNAL_ERRORS output) then re-raising.

---
**Decision Points**

DP-001
Condition: WIN_API.API_ENABLED is TRUE.
TRUE: Processing continues; the native registry function is registered and the read is attempted.
FALSE: WIN_API.NOT_AVAILABLE is raised immediately, bypassing all registry logic.

DP-002
Condition: The root-hive token extracted from RegPath matches one of the five recognised hive names (HKEY_LOCAL_MACHINE, HKEY_CLASSES_ROOT, HKEY_CURRENT_USER, HKEY_USERS, HKEY_CURRENT_CONFIG).
TRUE: The corresponding integer constant (0-4) is assigned to iBuff1 and processing continues.
FALSE: ADD_ERROR is called with an 'Invalid Registry Key' message; if RaiseExceptions is TRUE, NO_DATA_FOUND is raised; otherwise execution falls through.

DP-003
Condition: WIN_API.COMPAT_EXPAND_REG_VALUES is FALSE.
TRUE: iBuff3 is set to 1 (environment-variable expansion suppressed) and a compatibility diagnostic is written via DEBUGLOG.
FALSE: iBuff3 is set to 0 (environment-variable expansion enabled).

DP-004
Condition: iRC returned by D2KWUTIL_GETREGKEY equals -1 (registry entry not found).
TRUE: ADD_ERROR is called; if RaiseExceptions is FALSE, NULL is returned; if RaiseExceptions is TRUE, NO_DATA_FOUND is raised.
FALSE: Evaluation continues to the next error-code check.

DP-005
Condition: iRC equals -2 (unsupported registry data type).
TRUE: ADD_ERROR is called; if RaiseExceptions is FALSE, NULL is returned; if RaiseExceptions is TRUE, NO_DATA_FOUND is raised.
FALSE: Evaluation continues to the next error-code check.

DP-006
Condition: iRC equals -3 (registry value exceeds the 2000-byte buffer).
TRUE: ADD_ERROR is called; if RaiseExceptions is FALSE, NULL is returned; if RaiseExceptions is TRUE, VALUE_ERROR is raised.
FALSE: Evaluation continues to the next error-code check.

DP-007
Condition: iRC equals -4 (environment-string expansion failed).
TRUE: ADD_ERROR is called; if RaiseExceptions is FALSE, NULL is returned; if RaiseExceptions is TRUE, NO_DATA_FOUND is raised.
FALSE: No error condition applies; vcBuff3 is returned as the registry value.

DP-008
Condition: RaiseExceptions is TRUE (evaluated within each negative iRC branch).
TRUE: The appropriate PL/SQL exception (NO_DATA_FOUND or VALUE_ERROR) is raised to the caller.
FALSE: NULL is returned silently to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function may only execute when the WIN_API integration layer is active (WIN_API.API_ENABLED = TRUE); if the layer is unavailable, a WIN_API.NOT_AVAILABLE exception is raised and no registry access is attempted.
- BR-002 - The root-hive portion of RegPath (the segment preceding the first backslash) must exactly match one of five supported hive names (case-insensitive): HKEY_LOCAL_MACHINE, HKEY_CLASSES_ROOT, HKEY_CURRENT_USER, HKEY_USERS, or HKEY_CURRENT_CONFIG. Any other value is treated as an invalid registry key.
- BR-003 - The output buffer for the registry value is fixed at 2000 bytes. Registry values whose content exceeds this limit produce a -3 error code and are not partially returned.
- BR-004 - Environment-variable expansion within registry values is controlled by the WIN_API.COMPAT_EXPAND_REG_VALUES flag. When this flag is FALSE, expansion is suppressed (iBuff3 = 1), ensuring raw stored strings are returned without OS-level substitution.
- BR-005 - The caller controls error-surfacing behaviour through the RaiseExceptions parameter. When FALSE (the default), all retrieval failures result in a NULL return value; when TRUE, failures raise PL/SQL exceptions (NO_DATA_FOUND for entry-not-found, unsupported-type, and expansion-failure conditions; VALUE_ERROR for buffer-overflow conditions).
- BR-006 - Every invocation must be logged at debug severity 99 on entry (recording all input arguments) and on exit (recording the return code and retrieved value) via DEBUGLOG, providing a full audit trail of registry access attempts.
- BR-007 - The error stack must be cleared at the start of each invocation via CLEAN_ERROR_STACK, ensuring that error information reported by ADD_ERROR reflects only the current call and is not contaminated by prior operations.
- BR-008 - Unhandled exceptions are enriched with supplementary external error detail retrieved via ADD_EXTERNAL_ERRORS before being re-raised, ensuring callers receive the fullest available diagnostic context.

---
**Implementation Logic**

```plsql

FUNCTION Read_Registry (RegPath         IN  VARCHAR2,
                        RegEntry        IN  VARCHAR2, 
                        RaiseExceptions IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  vcBuff2    VARCHAR2(512);
  vcBuff3    VARCHAR2(2000);
  vcBuff4    VARCHAR2(512);
  vcBuff5    VARCHAR2(512);                        
  vcRoot     VARCHAR2(20);
  iBuff1     PLS_INTEGER;
  iBuff2     PLS_INTEGER;
  iBuff3		 PLS_INTEGER;
  iRC        PLS_INTEGER;
begin
  Win_API_Debug.DebugLog(99,'Read_Registry','Args: RegPath="'||RegPath||'", RegEntry="'||RegEntry||'", RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	  
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then 
    win_api.Register_function_call(iGetRegKey,'d2kwutil_GetRegKey','INT','INT,*CHAR,*CHAR,*CHAR,INT,INT');  
    -- Which Root?
    vcRoot  := upper(substr(RegPath,1,instr(RegPath,'\')-1));
    if      vcRoot =  'HKEY_LOCAL_MACHINE' then 
      iBuff1 := 0;
    elsif   vcRoot =  'HKEY_CLASSES_ROOT' then 
      iBuff1 := 1;
    elsif   vcRoot =  'HKEY_CURRENT_USER' then 
      iBuff1 := 2;
    elsif   vcRoot =  'HKEY_USERS' then
      iBuff1 := 3;
    elsif   vcRoot =  'HKEY_CURRENT_CONFIG' then
      iBuff1 := 4;      
    else
      WIN_API.Add_error('Read_Registry','Invalid Registry Key '||RegPath);
      if  RaiseExceptions then
        raise NO_DATA_FOUND;
      end if;  
    end if;

    iBuff2     := 2000; /* Length of buffer */
    vcBuff1    := substr(RegPath,instr(RegPath,'\')+1);
    vcBuff2    := RegEntry;
    vcBuff3    := RPAD(SUBSTR(NVL(vcBuff3,' '),1,2000),2000,CHR(0));
    if not WIN_API.COMPAT_EXPAND_REG_VALUES then 
    	iBuff3 := 1;
    	Win_API_Debug.DebugLog(99,'Read_Registry','Compatibility: Reg Value expansion supressed');	  
    else
    	iBuff3 := 0;
    end if;
    
    iRC        := d2kwutil_GetRegKey(win_api.FunctionHandle(iGetRegKey),iBuff1,vcBuff1,vcBuff2,vcBuff3,iBuff2,iBuff3);
    Win_API_Debug.DebugLog(99,'Read_Registry','Result:  RC='||to_char(iRC)||', vcBuff3="'||vcBuff3||'"');	      
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = -1  then 
    Win_API.Add_error('Read_Registry','Cannot read  entry '||RegPath||'->'||RegEntry);
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;
  elsif iRC = -2 then
    Win_API.Add_error('Read_Registry', RegPath||'->'||RegEntry||' is an unsupported datatype');
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;
  elsif iRC = -3 then
    Win_API.Add_error('Read_Registry',RegPath||'->'||RegEntry||' is longer than '||to_char(iBuff2)||' Bytes');
    if not RaiseExceptions then
      return NULL;
    else 
      raise VALUE_ERROR;
    end if;
  elsif iRC = -4 then
    Win_API.Add_error('Read_Registry', RegPath||'->'||RegEntry||' Failed to expand environment string');
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;    
  end if;
  return vcBuff3;
exception
  when NO_DATA_FOUND then 
    raise;
  when VALUE_ERROR then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Read_Registry',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Read_Registry',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Read_Registry;
```

#### SP-077 - REGISTER_FUNCTION_CALL

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Ensures that a Windows DLL function is registered with the ORA_FFI foreign-function interface before it is called by any D2KWUTIL utility routine. The procedure verifies that the target DLL is loaded, registers the function handle along with its parameter types and return type when the function has not yet been registered or when the DLL has been reloaded since the last registration, and records diagnostic information via the debug log. It raises NO_DATA_FOUND and surfaces errors through ADD_ERROR or ADD_EXTERNAL_ERRORS if the DLL cannot be located or if the FFI registration fails.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| FunctionID | PLS_INTEGER | IN |
| FunctionName | VARCHAR2 | IN |
| FunctionReturn | VARCHAR2 | IN |
| FunctionArgs | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-068](#SP-068--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-069](#SP-069--ADD_EXTERNAL_ERRORS)) - matched by member name
- D2KWUTIL.ATTEMPT_DLL_LOAD ([SP-002](#SP-002--D2KWUTIL.ATTEMPT_DLL_LOAD)) - D2KWUTIL.pck (or .pld)
- D2KWUTIL.TRANSLATETYPE ([SP-012](#SP-012--D2KWUTIL.TRANSLATETYPE)) - D2KWUTIL.pck (or .pld)
- DEBUGLOG ([SP-072](#SP-072--DEBUGLOG)) - matched by member name
- WEBUTIL.LENGTH ([SP-051](#SP-051--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)
- WEBUTIL.REGISTER_FUNCTION ([SP-059](#SP-059--WEBUTIL.REGISTER_FUNCTION)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Attempt to locate the already-loaded DLL by calling ORA_FFI.FIND_LIBRARY using the package-level DLL_NAME constant; if successful, execution continues with the registration check.
- Step 2 - If ORA_FFI.FIND_LIBRARY raises an FFI error (DLL not currently loaded), invoke D2KWUTIL.ATTEMPT_DLL_LOAD (SP-002) to reload the DLL from DLL_PATH; store the returned handle in DLL_HANDLE.
- Step 3 - If ATTEMPT_DLL_LOAD also raises an FFI error, set the package flag API_ENABLED to FALSE, call ADD_ERROR (SP-068) with the message that the DLL was not found, and raise NO_DATA_FOUND to abort processing.
- Step 4 - Compare the cached load-count entry FunctionLoad(FunctionId) against the current DLL_LOAD_COUNT to determine whether the function needs to be (re-)registered.
- Step 5 - If registration is required, call ORA_FFI.REGISTER_FUNCTION with DLL_HANDLE, FunctionName, and the C_STD calling convention to obtain and store a function handle in FunctionHandle(FunctionId).
- Step 6 - Unless the function being registered is the internal debug string function ('d2kwutil_DebugString'), write a diagnostic entry via DEBUGLOG (SP-072) indicating whether this is an initial registration or a re-registration, together with the current DLL load count.
- Step 7 - Parse the FunctionArgs string by appending a trailing comma and iterating through comma-delimited type tokens; for each token, call D2KWUTIL.TRANSLATETYPE (SP-012) to convert the type name to its ORA_FFI constant and register it as a parameter via ORA_FFI.REGISTER_PARAMETER. Stop the loop when the remaining string is NULL, a bare comma, or 'VOID,'.
- Step 8 - Determine the string length of vcArgs during loop iteration using WEBUTIL.LENGTH (SP-051) to decide whether the argument list has been fully consumed.
- Step 9 - After all parameters are registered, if FunctionReturn is not NULL and is not 'VOID' (case-insensitive), call D2KWUTIL.TRANSLATETYPE (SP-012) on FunctionReturn and register the translated type as the return type via ORA_FFI.REGISTER_RETURN.
- Step 10 - Record the current DLL_LOAD_COUNT in FunctionLoad(FunctionId) to prevent unnecessary re-registration on future calls.
- Step 11 - If any ORA_FFI.FFI_ERROR is raised during the registration block, call ADD_ERROR (SP-068) with the function name and the concatenated error text from ADD_EXTERNAL_ERRORS (SP-069), then raise NO_DATA_FOUND to abort the calling routine.

---
**Decision Points**

DP-001

Condition:
ORA_FFI.FIND_LIBRARY succeeds in locating the DLL identified by DLL_NAME.

TRUE:
DLL_HANDLE is populated and processing continues to the registration check (DP-002).

FALSE:
An FFI error is caught; D2KWUTIL.ATTEMPT_DLL_LOAD (SP-002) is invoked to reload the DLL (see DP-002a).

---

DP-002a

Condition:
D2KWUTIL.ATTEMPT_DLL_LOAD successfully reloads the DLL.

TRUE:
DLL_HANDLE is populated from the reload result and processing continues to the registration check.

FALSE:
An FFI error is caught; API_ENABLED is set to FALSE, ADD_ERROR (SP-068) is called, and NO_DATA_FOUND is raised.

---

DP-002

Condition:
FunctionLoad array does not contain an entry for FunctionId, OR FunctionLoad(FunctionId) differs from the current DLL_LOAD_COUNT.

TRUE:
The function must be (re-)registered: ORA_FFI.REGISTER_FUNCTION is called, parameters are parsed and registered, and the return type is registered if applicable.

FALSE:
The function is already registered against the current DLL load; no registration work is performed and the procedure exits normally.

---

DP-003

Condition:
The FunctionName being registered equals 'd2kwutil_DebugString'.

TRUE:
The DEBUGLOG (SP-072) diagnostic call is suppressed to avoid recursive logging.

FALSE:
DEBUGLOG (SP-072) is called to record whether this is an initial registration or a re-registration.

---

DP-004

Condition:
FunctionLoad.exists(FunctionId) returns FALSE at the point of the debug log call (within the registration block).

TRUE:
DEBUGLOG (SP-072) records the event as an initial registration.

FALSE:
DEBUGLOG (SP-072) records the event as a re-registration and includes the previous load count.

---

DP-005

Condition:
During argument parsing, the remaining vcArgs string is NULL, equals ',', or equals 'VOID,'.

TRUE:
The parameter-registration loop terminates.

FALSE:
The next comma-delimited type token is extracted, translated via D2KWUTIL.TRANSLATETYPE (SP-012), and registered as a parameter.

---

DP-006

Condition:
After processing a parameter token, iOffset equals WEBUTIL.LENGTH(vcArgs) (SP-051), meaning the token was the last element in the list.

TRUE:
vcArgs is set to NULL, ending the loop on the next iteration.

FALSE:
vcArgs is trimmed to the substring following the processed token and the loop continues.

---

DP-007

Condition:
FunctionReturn is not NULL and UPPER(FunctionReturn) is not 'VOID'.

TRUE:
D2KWUTIL.TRANSLATETYPE (SP-012) is called on FunctionReturn and the result is registered as the return type via ORA_FFI.REGISTER_RETURN.

FALSE:
No return type is registered (the function is treated as a void procedure).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The DLL identified by DLL_NAME must be locatable via ORA_FFI.FIND_LIBRARY or recoverable via D2KWUTIL.ATTEMPT_DLL_LOAD (SP-002) before any function registration is attempted; if neither succeeds, the API is disabled and the calling operation is aborted.
- BR-002 - A function must be re-registered whenever its cached DLL load count (FunctionLoad(FunctionId)) does not match the current DLL_LOAD_COUNT, ensuring that stale handles from a previous DLL load are never used.
- BR-003 - All parameter type names supplied in FunctionArgs must be translated to ORA_FFI type constants using D2KWUTIL.TRANSLATETYPE (SP-012) before being passed to ORA_FFI.REGISTER_PARAMETER; raw string type names are not acceptable to the FFI layer.
- BR-004 - A return type is registered only when FunctionReturn is non-NULL and not equal to 'VOID' (case-insensitive); procedures with no return value must not have a return type registered.
- BR-005 - The internal debug function 'd2kwutil_DebugString' is exempt from DEBUGLOG (SP-072) diagnostic logging during registration to prevent recursive log calls.
- BR-006 - FunctionArgs must be provided as a comma-delimited list of type name tokens; the parser appends a trailing comma and treats a NULL remainder, a bare comma, or the token 'VOID' as the end-of-list sentinel.
- BR-007 - On any ORA_FFI.FFI_ERROR raised during the registration phase, the full error detail must be surfaced by combining ADD_EXTERNAL_ERRORS (SP-069) output with ADD_ERROR (SP-068) before raising NO_DATA_FOUND, ensuring that the calling routine receives a meaningful diagnostic message.
- BR-008 - Once a function is successfully registered, its current DLL_LOAD_COUNT must be stored in FunctionLoad(FunctionId) so that subsequent calls within the same DLL lifecycle bypass redundant re-registration.

---
**Implementation Logic**

```plsql

PROCEDURE Register_Function_Call ( FunctionID     in PLS_INTEGER, 
                                   FunctionName   in VARCHAR2,
                                   FunctionReturn in VARCHAR2, 
                                   FunctionArgs   in VARCHAR2) is
  vcArgs  VARCHAR2(200);
  vcFrag  VARCHAR2(10);
  iOffset PLS_INTEGER;   
begin 
   -- See if the DLL has been loaded at all.
   -- if this call to FIND_LIBRARY fails, we'll fall through to the Exception.
   begin
    DLL_HANDLE := ORA_FFI.find_library(DLL_NAME);
  exception
    when ora_ffi.ffi_error then 
      -- Attempt to load the DLL again in a subblock. If this fails
      -- then the API must be disabled and NOT_DATA_FOUND raised
      begin 
          DLL_HANDLE := Attempt_DLL_Load(DLL_Path, DLL_NAME);
      exception
          when ora_ffi.ffi_error then 
            API_ENABLED := FALSE;
              add_error('D2KWUTIL',DLL_NAME||' not found.');
            RAISE NO_DATA_FOUND;
      end;
  end;

  -- now compare the Cached value for this function's loadcount with 
  -- that for the DLL this tells us that the function has either not 
  -- been registered yet, or that the DLL has been reloaded in between 
  -- times.  This would not be healthy so we have to re-register in that case.
  if (not FunctionLoad.exists(FunctionId)) or (FunctionLoad(FunctionId)<> DLL_LOAD_COUNT) then
    -- We need to go through the registration process.      
    -- Register the function with the DLL
    FunctionHandle(FunctionId) := ora_ffi.register_function(Win_API.DLL_HANDLE,FunctionName,ORA_FFI.C_STD);
    if FunctionName <> 'd2kwutil_DebugString' then 
    	if not FunctionLoad.exists(FunctionId) then 
    		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Initial Reg');
    	else
       		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Re-Registration Count = '||to_char(FunctionLoad(FunctionId)));
       	end if;
    end if;
    
    -- Loop through and register the parameters
    vcArgs := FunctionArgs||',';
    while vcArgs is not null and vcArgs <> ',' and vcArgs <> 'VOID,' LOOP
      iOffset := instr(vcArgs,',');
      vcFrag := substr(vcArgs,1,iOffset-1);
      ora_ffi.register_parameter(FunctionHandle(FunctionId),TranslateType(vcFrag));
      if iOffset = length(vcArgs) then
        vcArgs := NULL;
      else
        vcArgs := substr(vcArgs,iOffset+1);
      end if;
    end LOOP;
    
    -- Register the return type IF this is a function
    if upper(FunctionReturn) <> 'VOID' and FunctionReturn is not NULL then 
      ora_ffi.register_return(FunctionHandle(FunctionId),TranslateType(FunctionReturn));
    end if;
    
    -- Now add this Function's Loadcount to the array to prevent un-nessary re-registration
    FunctionLoad(FunctionId) := DLL_LOAD_COUNT;
  end if;
exception
   when ora_ffi.ffi_error then
    Win_API.Add_error(FunctionName, Win_API.UError||WIN_API.Add_External_errors); 
    raise NO_DATA_FOUND;
end Register_Function_Call;
```

#### SP-078 - SETDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Initialises the debug logging configuration for the D2kwutil library by accepting the desired debug type, output file, verbosity level, and timestamp preference. The procedure stores these settings in package-level variables and activates or deactivates the logging mechanism accordingly, routing an initial diagnostic message through DEBUGLOG to confirm the new state.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugType | PLS_INTEGER | IN |
| DebugFile | VARCHAR2 | IN |
| DebugLevel | PLS_INTEGER | IN |
| TimeStamp | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-072](#SP-072--DEBUGLOG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Accept the four input parameters: DebugType (logging destination), DebugFile (output file path), DebugLevel (verbosity threshold, defaulting to 98), and TimeStamp (whether to prefix log entries with a timestamp, defaulting to FALSE).
- Step 2 - Persist the incoming values to the package-level variables bDebugTimeStamp, vcDebugFile, and iDebugLevel so that all subsequent logging calls within the session use these settings.
- Step 3 - Evaluate DebugType to determine the logging destination and set the package-level state variable iDebugState.
- Step 4 - If DebugType = 1 (file-based logging), set iDebugState to 1 and call DEBUGLOG to record a confirmation message that includes the target file name.
- Step 5 - If DebugType = 2 (alternative logging mode, e.g., screen/console), set iDebugState to 2 and call DEBUGLOG to record a 'Logging Started' confirmation message.
- Step 6 - For any other DebugType value, call DEBUGLOG to record a 'Logging Stopped' message and then set iDebugState to 0, disabling further logging.

---
**Decision Points**

DP-001

Condition:
DebugType = 1

TRUE:
Set iDebugState to 1 (file-based logging active) and invoke DEBUGLOG with the message 'Logging to File <DebugFile>' to confirm file logging has been enabled.

FALSE:
Evaluate DP-002.

---

DP-002

Condition:
DebugType = 2

TRUE:
Set iDebugState to 2 (alternative logging mode active) and invoke DEBUGLOG with the message 'Logging Started' to confirm the mode is enabled.

FALSE:
Invoke DEBUGLOG with the message 'Logging Stopped' and then set iDebugState to 0, disabling all debug logging.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The timestamp preference, output file path, and verbosity level must always be stored to their respective package-level variables (bDebugTimeStamp, vcDebugFile, iDebugLevel) before any state change is applied, ensuring all subsequent log calls within the session inherit the new configuration.
- BR-002 - A DebugType value of 1 designates file-based logging; the target file name supplied in DebugFile is recorded in the confirmation log entry via DEBUGLOG.
- BR-003 - A DebugType value of 2 designates an alternative logging mode (e.g., screen/console output); no file name is required or recorded.
- BR-004 - Any DebugType value other than 1 or 2 is treated as a request to stop logging; iDebugState is set to 0 only after the 'Logging Stopped' message has been dispatched through DEBUGLOG, preserving a final audit trail entry.
- BR-005 - DebugLevel defaults to 98 and DebugFile defaults to NULL when not supplied by the caller, allowing the procedure to be invoked with minimal parameters for simple logging scenarios.
- BR-006 - All state-change confirmations are routed through DEBUGLOG (SP-072) at level 0, ensuring the initialisation event is always captured regardless of the configured verbosity threshold.

---
**Implementation Logic**

```plsql

PROCEDURE SetDebug( DebugType   IN PLS_INTEGER, 
                    DebugFile   IN VARCHAR2 DEFAULT NULL, 
                    DebugLevel  IN PLS_INTEGER DEFAULT 98,                        
                    TimeStamp   IN BOOLEAN DEFAULT FALSE) is
begin 
    bDebugTimeStamp := TimeStamp;
    vcDebugFile     := DebugFile;
    iDebugLevel     := DebugLevel;
	if DebugType = 1 then 
		iDebugState := 1;
		DebugLog(0,'SetDebug','Logging to File '||DebugFile);
	elsif DebugType = 2 then
		iDebugState := 2;
		DebugLog(0,'SetDebug','Logging Started');
	else 
        DebugLog(0,'SetDebug','Logging Stopped');
        iDebugState := 0;
	end if;
end SetDebug;
```

#### SP-079 - SF_COPYRIGHT_DECLARATION

**Invoked From:**

- pr_mass_order_fmb.xml [Trigger: FT_CANCEL]
- pr_mass_order_fmb.xml [Trigger: KEY-CLRFRM]
- pr_mass_order_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

Search Criteria (N/A / CN_MAIN)

---

**Purpose**

Generates and returns a formatted copyright declaration string for Maruti Suzuki India Limited, reflecting the correct financial year. Because the Indian financial year runs from April to March, the function adjusts the displayed year so that months January through March show the preceding calendar year, ensuring the copyright notice always aligns with the current financial year rather than the calendar year.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Capture the current system date using SYSDATE into a local date variable.
- Step 2 - Extract the abbreviated month name from the current date.
- Step 3 - Evaluate whether the current month falls within the January-March period (the tail end of the Indian financial year).
- Step 4 - If the month is January, February, or March, construct the copyright string using the preceding calendar year (current year minus 1) appended with the organisation name 'Maruti Suzuki India Limited'.
- Step 5 - If the month is April through December, construct the copyright string using the current calendar year appended with the organisation name 'Maruti Suzuki India Limited'.
- Step 6 - Return the formatted copyright declaration string to the calling trigger.

---
**Decision Points**

DP-001

Condition:
The abbreviated month name of the current system date (SYSDATE) is one of 'JAN', 'FEB', or 'MAR'.

TRUE:
The copyright year is set to the current calendar year minus 1, producing a declaration such as '- 2010 Maruti Suzuki India Limited', reflecting that these months belong to the financial year that started in the previous calendar year.

FALSE:
The copyright year is set to the current calendar year as-is, producing a declaration such as '- 2011 Maruti Suzuki India Limited', reflecting that April through December fall within the financial year that started in the current calendar year.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The Indian financial year is treated as running from April to March; consequently, January, February, and March are considered part of the financial year that began in the previous calendar year.
- BR-002 - The copyright year displayed must reflect the financial year start year, not necessarily the current calendar year, to ensure legal and organisational accuracy of the copyright notice.
- BR-003 - The organisation name embedded in the copyright string must always be 'Maruti Suzuki India Limited' and is not configurable via parameters.
- BR-004 - The function takes no input parameters; the reference date is always derived from the database server's current date (SYSDATE), ensuring consistency across all calling contexts.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
function sf_copyright_declaration return varchar is
a varchar2(50);
dt date;
begin
--Modified by Prerna on 16-May-11  to display current Financial Year Copyright
dt := sysdate;

    if( to_char(dt,'MON') in ('JAN','FEB','MAR')) then
        a := '- '||to_char(to_number(to_char(dt,'RRRR')) - 1)||' Maruti Suzuki India Limited ';
    else
        a := '- '||to_char(dt,'RRRR')||' Maruti Suzuki India Limited ';
    end if;
return(a);
end;

```

#### SP-080 - STRIPDIRSEP

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sanitises a file-system path string by removing any semicolon-delimited suffix and any trailing backslash directory separator, returning a clean, single-path value suitable for use in DLL loading and directory-resolution routines.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| InPath | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-051](#SP-051--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the raw path string (InPath) and assign it to a working variable (vcPath).
- Step 2 - Search vcPath for the first occurrence of a semicolon character using INSTR.
- Step 3 - If a semicolon is found, truncate vcPath to retain only the characters before the semicolon, discarding any additional path entries or trailing metadata.
- Step 4 - Inspect the last character of the (possibly truncated) vcPath for a backslash directory separator.
- Step 5 - If a trailing backslash is present, remove it by taking the substring up to the penultimate character.
- Step 6 - Return the sanitised path string to the caller.

---
**Decision Points**

DP-001

Condition:
INSTR(vcPath, ';') > 0 - the path string contains one or more semicolon characters.

TRUE:
Truncate vcPath to the substring preceding the first semicolon, retaining only the first path entry.

FALSE:
Leave vcPath unchanged and proceed to the trailing-separator check.

---

DP-002

Condition:
SUBSTR(vcPath, -1, 1) = '\' - the last character of vcPath is a backslash directory separator.

TRUE:
Remove the trailing backslash by reassigning vcPath to SUBSTR(vcPath, 1, LENGTH(vcPath) - 1).

FALSE:
Leave vcPath unchanged and return it as-is.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only the portion of a path string that precedes the first semicolon is considered a valid single path; any content from the semicolon onward is discarded.
- BR-002 - A valid directory path must not end with a backslash separator; if one is present it must be stripped before the path is returned.
- BR-003 - The function is non-destructive to the original parameter; all modifications are applied to an internal working copy (vcPath), preserving the caller's input value.
- BR-004 - The sanitised path is returned as the function result and must be consumed by the caller (ATTEMPT_DLL_LOAD, GET_TEMP_DIRECTORY, or GET_WINDOWS_DIRECTORY); no output is written to database tables or global variables by this function.

---
**Implementation Logic**

```plsql

  

Function StripDirSep ( InPath in varchar2) return varchar2 is 
  vcPath  varchar2(500) := InPath;
begin 
  -- Check and Strip SemiColons, we take everything
  -- Before the first Semicolon as our path
  if instr(vcPath,';') > 0 then
    vcPath := substr(vcPath,1,instr(vcPath,';') -1);
  end if;

  -- Check and Strip '\'
  if substr(vcPath,-1,1) = '\' then 
    vcPath := substr(vcPath,1,length(vcPath)-1);
  end if;

  return vcPath;
end StripDirSep;
```

#### SP-081 - VIEW_EXCEL_REPORT_NEW

**Invoked From:**

- pr_mass_order_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

Search Criteria (N/A / CN_MAIN)

---

**Purpose**

Generates and delivers an Excel-compatible CSV report to the client workstation. The procedure first determines whether a dedicated report server is configured for the given principal and application. If a report server exists, it delegates CSV generation to a remote database procedure and transfers the resulting file to the client. If no report server is configured, it builds the report locally by executing the supplied query into an Oracle Forms record group, writes the data to a server-side CSV file using TEXT_IO, and then transfers the file to the client. In both paths the transferred file is opened on the client desktop via a host command.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_principal | number | IN |
| p_file_name | VARCHAR2 | IN |
| p_query | VARCHAR2 | IN |
| p_column_name | VARCHAR2 | IN |
| p_app_id | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.FCLOSE ([SP-026](#SP-026--WEBUTIL.FCLOSE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.FILE_SAVE_DIALOG ([SP-027](#SP-027--WEBUTIL.FILE_SAVE_DIALOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.FOPEN ([SP-029](#SP-029--WEBUTIL.FOPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_LINE ([SP-042](#SP-042--WEBUTIL.GET_LINE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.HOST ([SP-045](#SP-045--WEBUTIL.HOST)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ID_NULL ([SP-046](#SP-046--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.PUTF ([SP-054](#SP-054--WEBUTIL.PUTF)) - WEBUTIL.pck (or .pld)
- WEBUTIL.URL_TO_CLIENT ([SP-065](#SP-065--WEBUTIL.URL_TO_CLIENT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Look up the report server (rep_server) in EH_REPORTS for the combination of p_principal and p_app_id. If no matching row is found, lv_rep_server is set to NULL.
- Step 2 - Determine the output file name: if p_file_name is NULL, invoke WEBUTIL.FILE_SAVE_DIALOG to prompt the user for a save location; otherwise use p_file_name directly. Append '.csv' to the resolved file name.
- Step 3 - Validate the resolved file name for embedded spaces. If any space is found in a folder segment, redirect the file to 'C:\' using only the base file name and display a warning message to the user.
- Step 4 (Report-Server path) - If lv_rep_server is not NULL, call the remote procedure sp_csv_report_generate@dms1_db3_lnk, passing the file name, query, and output error variables, to generate the CSV on the remote database server.
- Step 5 (Report-Server path) - Move the generated file from /utl_dir/ to /iashome/ias/reports/printer/ using WEBUTIL.HOST with a Unix mv command.
- Step 6 (Local path) - If lv_rep_server is NULL, check whether a record group named 'DataRecordSet' already exists using WEBUTIL.ID_NULL; if it does, delete it before proceeding.
- Step 7 (Local path) - Create a new record group from the supplied p_query using Create_Group_From_Query, populate it with Populate_Group, and retrieve the row count with Get_Group_Row_Count.
- Step 8 (Local path) - Open the server-side output file at /iashome/ias/reports/printer/ for writing using WEBUTIL.FOPEN (TEXT_IO.FOPEN), then locate the target column in the record group with Find_Column.
- Step 9 (Local path) - Iterate over every row in the record group, retrieve the character cell value for the specified column, append a newline character, and write each line to the file using WEBUTIL.PUTF (TEXT_IO.PUTF).
- Step 10 (Local path) - Close the server-side file using WEBUTIL.FCLOSE (TEXT_IO.FCLOSE).
- Step 11 (Both paths) - Read the base URL for the reports directory from the configuration file /reports/DMS/excelpath.txt using WEBUTIL.FOPEN and WEBUTIL.GET_LINE, then close the file with WEBUTIL.FCLOSE. Construct the full URL by appending the base file name to the URL path.
- Step 12 (Both paths) - Transfer the file from the form server to the client machine using WEBUTIL.URL_TO_CLIENT. If the transfer fails, display a 'File Transfer failed' message and pause.
- Step 13 (Both paths) - Launch the transferred CSV file on the client desktop by invoking WEBUTIL.HOST with 'cmd /c <FILENAME>'.
- Step 14 - If any unhandled exception occurs, display the Oracle error code and text, then raise Form_Trigger_Failure to halt form processing.

---
**Decision Points**

DP-001

Condition:
lv_rep_server IS NOT NULL (a report server entry was found in EH_REPORTS for the given principal and application).

TRUE:
Delegate CSV generation to the remote database procedure sp_csv_report_generate@dms1_db3_lnk, move the output file via a Unix host command, then proceed to read the URL config file and transfer the file to the client.

FALSE:
Build the report locally using an Oracle Forms record group populated from p_query, write the data row-by-row to a server-side file using TEXT_IO, then proceed to read the URL config file and transfer the file to the client.

---

DP-002

Condition:
p_file_name IS NULL.

TRUE:
Invoke WEBUTIL.FILE_SAVE_DIALOG to prompt the user to choose a save location and file name.

FALSE:
Use the value supplied in p_file_name directly as the output file name.

---

DP-003

Condition:
INSTR(FILENAME, ' ') > 0 (the resolved file name contains a space in a folder segment).

TRUE:
Redirect the output path to 'C:\' using only the base file name, and display a warning message informing the user that the file will be stored on the C drive.

FALSE:
Continue with the original resolved file name and path.

---

DP-004

Condition:
NOT Id_Null(rg_id) - a record group named 'DataRecordSet' already exists in the form (local path only).

TRUE:
Delete the existing record group before creating a new one from the supplied query.

FALSE:
Proceed directly to create the record group from the supplied query.

---

DP-005

Condition:
file_transfer_bool is FALSE (WEBUTIL.URL_TO_CLIENT reported a transfer failure).

TRUE:
Display the message 'File Transfer failed' and pause form execution.

FALSE:
Continue to open the transferred file on the client desktop via WEBUTIL.HOST.

---
**Database Interactions**

- DB-001 - Read EH_REPORTS - Reads data from EH_REPORTS for lookup or validation.
**Business Rules**

- BR-001 - The procedure must look up the rep_server value in EH_REPORTS using both p_principal and p_app_id as keys; if no matching record exists, the local record-group generation path is used.
- BR-002 - The output file name must always carry a '.csv' extension; the extension is appended unconditionally to the resolved file name regardless of whether a name was supplied or obtained from the save dialog.
- BR-003 - A file name or path that contains one or more space characters in a folder segment is not permitted; such paths are automatically redirected to the root of the C drive and the user is notified.
- BR-004 - In the local generation path, any pre-existing record group named 'DataRecordSet' must be destroyed before a new one is created to prevent stale data from contaminating the report output.
- BR-005 - The server-side report URL base path must be read at runtime from the configuration file /reports/DMS/excelpath.txt; this value is not hard-coded and must be current at the time of each report generation.
- BR-006 - File transfer from the form server to the client is mandatory; a failed transfer (WEBUTIL.URL_TO_CLIENT returns FALSE) must be surfaced to the user immediately and form execution must pause.
- BR-007 - After a successful file transfer, the CSV file must be opened automatically on the client desktop using a host command ('cmd /c'), providing the user with immediate access to the report.
- BR-008 - Any unhandled runtime exception must be caught, the Oracle error code and error text must be displayed to the user, and Form_Trigger_Failure must be raised to prevent silent failure.

---
**Implementation Logic**

```plsql
PROCEDURE view_excel_report_new(p_principal number,p_file_name VARCHAR2, p_query VARCHAR2,p_column_name VARCHAR2,p_app_id VARCHAR2) IS
	rg_name 				 		VARCHAR2(40) := 'DataRecordSet'; 
	rg_id 					 		RecordGroup; 
	gc_id 					 		GroupColumn; 
	errcode 				 		NUMBER; 
	the_rowcount 		 		NUMBER; 
  FILENAME			   		VARCHAR2(4000);
  MYFILE 					 		TEXT_IO.FILE_TYPE;
  urlFile 					 	TEXT_IO.FILE_TYPE;
  urlPath							VARCHAR2(5000);
	V_STRING 				 		VARCHAR2(4000);
	l_alert 				 		NUMBER;
	server_file      		VARCHAR2(2000);
	file_transfer_bool	BOOLEAN;
	formserverpath   		VARCHAR2(2000);
	lv_err_reas			varchar2(2000);
	lv_cmd	varchar2(1000);
	lv_rep_server	varchar2(50);

begin
			begin
				select rep_server into lv_rep_server from eh_reports
				where principal_map_cd=p_principal
				and   app_id=p_app_id;
			exception
				when others then
				 lv_rep_server:=null;
			end;	

if lv_rep_server is not null then
		
			If p_file_name is null then
				FILENAME  := Webutil_file.FILE_SAVE_DIALOG;
			Else
			  FILENAME := p_file_name;
			End If;
  
  		FILENAME:=p_file_name||'.csv';
  
			 	If instr(FILENAME,' ') > 0 then
			 		FILENAME := 'C:\'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
			 		Message('File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default.');
			 		message('  ');
			 	end if;
 	
			sp_csv_report_generate@dms1_db3_lnk(FILENAME,p_query,errcode,lv_err_reas);
			
			host('/bin/mv /utl_dir/'||FILENAME||' /iashome/ias/reports/printer/'||FILENAME);
			
			server_file := '/iashome/ias/reports/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	
			urlFile := Text_Io.Fopen('/reports/DMS/excelpath.txt','R');
			Text_Io.Get_Line(urlFile,urlPath);
			Text_Io.Fclose(urlFile);
			formserverpath := urlPath||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);

 		file_transfer_bool := WebUtil_File_Transfer.Url_To_Client(formserverpath,FILENAME);
	 	
	 	if not file_transfer_bool  then 
	 		message('File Transfer failed');pause;
	 	end if;
	 	
	WebUtil_Host.HOST('cmd /c '||FILENAME);
	
else
  If p_file_name is null then
		FILENAME  := Webutil_file.FILE_SAVE_DIALOG;
  Else
    FILENAME := p_file_name;
  End If;
 	If instr(FILENAME,' ') > 0 then
 		FILENAME := 'C:\'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
 		Message('File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default.');
 		message('  ');
 	end if;
	rg_id := Find_Group( rg_name ); 
	IF NOT Id_Null(rg_id) THEN 
		Delete_Group( rg_id ); 
	END IF; 
	rg_id := Create_Group_From_Query( rg_name, p_query ); 
	errcode := Populate_Group( rg_id ); 
	the_rowcount := Get_Group_Row_Count( rg_id );
	server_file := '/iashome/ias/reports/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	urlFile := Text_Io.Fopen('/reports/DMS/excelpath.txt','R');
	Text_Io.Get_Line(urlFile,urlPath);
	Text_Io.Fclose(urlFile);
	formserverpath := urlPath||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	MYFILE := TEXT_IO.FOPEN(server_file, 'W');
	gc_id := Find_Column( rg_name||'.'||p_column_name); 	
	for total_loop IN 1..the_rowcount
		loop
	  	V_STRING :=  GET_GROUP_CHAR_CELL(gc_id  , total_loop )||CHR(10); 
	  	TEXT_IO.PUTF(MYFILE,V_STRING);  
		end loop;
	 	TEXT_IO.FCLOSE(MYFILE);
	 	file_transfer_bool := WebUtil_File_Transfer.Url_To_Client(formserverpath,FILENAME);
	 	if not file_transfer_bool  then 
	 		message('File Transfer failed');pause;
	 	end if;
	 	WebUtil_Host.HOST('cmd /c '||FILENAME);	 		
	 		
end if;

exception
	when others then
	Message('Error  - '||ERROR_CODE|| ERROR_TEXT);
	Raise Form_trigger_failure;
end;
```

#### SP-082 - WINDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WINDEBUG provides a debug-logging bridge that forwards a text message to the external Windows API debug-string facility (D2KWUTIL.D2KWUTIL_DEBUGSTRING). It is invoked by the DEBUGLOG stored procedure in D2kwutil.pld and handles both the unavailability of the Windows API and unexpected runtime errors by recording structured error information before re-raising the exception.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-068](#SP-068--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-069](#SP-069--ADD_EXTERNAL_ERRORS)) - matched by member name
- D2KWUTIL.D2KWUTIL_DEBUGSTRING ([SP-006](#SP-006--D2KWUTIL.D2KWUTIL_DEBUGSTRING)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- REGISTER_FUNCTION_CALL ([SP-077](#SP-077--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input text string and append a newline character (CHR(10)) to form the output buffer (vcBuff1).
- Step 2 - Check whether the Windows API is available by evaluating WIN_API.API_ENABLED.
- Step 3 - If the API is available, register the function call for the debug-string operation by invoking REGISTER_FUNCTION_CALL (SP-077), passing the debug-string function handle identifier, the function name 'd2kwutil_DebugString', NULL, and the parameter type marker '*CHAR'.
- Step 4 - Invoke D2KWUTIL.D2KWUTIL_DEBUGSTRING (SP-006) with the resolved function handle and the buffered text to transmit the debug message to the external Windows debug output.
- Step 5 - If the API is not available, raise the WIN_API.NOT_AVAILABLE exception.
- Step 6 - In the WIN_API.NOT_AVAILABLE exception handler, call ADD_ERROR (SP-068) to log the unavailability error against the 'WinDebug' context, then re-raise the exception to the caller.
- Step 7 - In the OTHERS exception handler, call ADD_ERROR (SP-068) with a composed error message that concatenates WIN_API.UError with the result of ADD_EXTERNAL_ERRORS (SP-069) to capture any additional external error detail, then re-raise the exception to the caller.

---
**Decision Points**

DP-001

Condition:
WIN_API.API_ENABLED evaluates to TRUE.

TRUE:
Register the debug-string function call via REGISTER_FUNCTION_CALL (SP-077) and forward the buffered text to the Windows debug output via D2KWUTIL.D2KWUTIL_DEBUGSTRING (SP-006).

FALSE:
Raise the WIN_API.NOT_AVAILABLE exception, which is subsequently caught by the dedicated exception handler.

---

DP-002

Condition:
The WIN_API.NOT_AVAILABLE exception is raised (either explicitly from DP-001 FALSE branch or propagated from the API call).

TRUE:
Call ADD_ERROR (SP-068) to record the unavailability error for the 'WinDebug' context, then re-raise the exception to the caller.

FALSE:
Not applicable; this handler is only entered when the specific exception is raised.

---

DP-003

Condition:
An unexpected (OTHERS) exception occurs during execution.

TRUE:
Call ADD_ERROR (SP-068) with a composite error message built from WIN_API.UError concatenated with the output of ADD_EXTERNAL_ERRORS (SP-069), then re-raise the exception to the caller.

FALSE:
Not applicable; this handler is only entered on an unhandled exception.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The input text must be augmented with a newline character (CHR(10)) before being passed to the external debug-string function; the raw input value is never sent directly.
- BR-002 - The Windows API availability flag (WIN_API.API_ENABLED) must be TRUE before any attempt is made to register or invoke the external debug-string function; the procedure does not silently swallow unavailability.
- BR-003 - The external function call must be formally registered via REGISTER_FUNCTION_CALL (SP-077) before D2KWUTIL.D2KWUTIL_DEBUGSTRING (SP-006) is invoked; out-of-order invocation is not permitted.
- BR-004 - All exceptions must be re-raised to the caller after error logging; WINDEBUG does not suppress errors.
- BR-005 - When the Windows API is unavailable, the error must be recorded using ADD_ERROR (SP-068) with the 'WinDebug' context identifier and the WIN_API.NoAPI error code.
- BR-006 - For all other unexpected errors, the error record must combine WIN_API.UError with any external error detail retrieved via ADD_EXTERNAL_ERRORS (SP-069) to ensure complete diagnostic information is captured.

---
**Implementation Logic**

```plsql
  

  
PROCEDURE WinDebug  (  Text  IN   VARCHAR2) is
  vcBuff1 VARCHAR2(2000) := Text||chr(10);
begin 
  --WIN_API.Clean_Error_Stack;
  if Win_API.API_ENABLED then
    win_api.Register_function_call(iDebugString,'d2kwutil_DebugString',NULL,'*CHAR');
    d2kwutil_DebugString(win_api.FunctionHandle(iDebugString),vcBuff1);
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if; 
exception
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('WinDebug',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('WinDebug',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end WinDebug;
```

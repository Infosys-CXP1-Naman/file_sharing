# BUSINESS REQUIREMENTS DOCUMENT

## Table of Contents

- 1. Document Control
  - 1.1 Document Information
  - 1.2 Revision History
- 2. Executive Summary
  - Key Stakeholders
- 3. System Context
- 4. Functional Requirements
  - 4.1 Business Requirements
    - Requirement ID: BR-001
    - Requirement ID: BR-002
    - Requirement ID: BR-003
    - Requirement ID: BR-004
    - Requirement ID: BR-005
    - Requirement ID: BR-006
    - Requirement ID: BR-007
    - Requirement ID: BR-008
    - Requirement ID: BR-009
    - Requirement ID: BR-010
    - Requirement ID: BR-011
    - Requirement ID: BR-012
    - Requirement ID: BR-013
    - Requirement ID: BR-014
    - Requirement ID: BR-015
    - Requirement ID: BR-016
    - Requirement ID: BR-017
    - Requirement ID: BR-018
    - Requirement ID: BR-019
    - Requirement ID: BR-020
- 5. Business Rules Catalogue
- 6. Data Requirements
  - 6.1 Business Entities and Relationships
    - Exchange/Loyalty Claim - MULDMS.SD_LOYLTY_EXCH_CLAIM
    - Dealer Location Master - AM_DEALER_LOC / MULDMS.AM_DEALER_LOC
    - Invoice Header - MULDMS.SH_INVOICE
    - Order Book - MULDMS.SH_ORDBOOK
    - Trade-In Vehicle Evaluation - MULDMS.SH_TV_EVAL / SH_TV_EVAL
    - Vahan Check Detail - DMS_VAHAN_CHECK_DTL
    - Invoice Charge - SD_INV_CHARGES
    - Entity Relationships
  - 6.2 Data Capture Requirements
    - Report Filter Parameters (Dealer User - report request)
    - Session / Internal Fields
  - 6.3 Reference Data
  - 6.4 Data Lifecycle
  - 6.5 Excel Output Columns
- 7. Glossary
- 8. Technical Inventory
  - 8.1 Form Architecture
    - 8.1.1 Global Variables
    - 8.1.2 Form Parameters
  - 8.2 Blocks
    - 8.2.1 Block WhereClause and OrderByClause
  - 8.3 Items Summary
  - 8.4 List of Values
  - 8.5 Alerts
  - 8.6 Program Units
  - 8.7 Triggers
    - 8.7.1 Inactive / Commented-Out Trigger Register
  - 8.8 Canvas and Window Inventory
  - 8.9 Editors
  - 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups
    - 8.10.1 Visual Attributes (form-defined)
    - 8.10.2 Property Classes (form-defined)
    - 8.10.3 Object Groups
  - 8.11 DataSourceColumn Inventory
- 9. Object Library
- 10. Record Groups
- 11. Referenced Database Objects
- 12. Backend Procedures and Packages
  - 12.1 Main Flow Backend Procedure/Package Index
  - 12.2 Procedure and Package Catalogue
- 13. Package Procedure Specifications
- 14. Database Package Catalogue
- 15. PLD Procedure Call Sites
  - DPL.pld (`general`)
  - Inactive / commented-only PLD call sites
  - webutil.pld (`WEBUTIL_CORE`)
  - webutil.pld (`WEBUTIL_C_API`)
  - webutil.pld (`WEBUTIL_FILE`)
  - Inactive / commented-only PLD call sites
- 16. Microservice API Candidates
  - 16.1 Microservices with APIs
- 17. Workflows
- 18. PLD-Backed Logic
  - webutil.pld (`CLIENT_IMAGE`)
  - DPL.pld (`general`)
  - D2kwutil.pld (`Win_API`)
- 19. PCK-Backed Logic
- 20. System Interfaces
  - 20.1 Database Integrations
  - 20.2 External System Integrations
  - 20.3 Report Integrations
    - 20.3.1 Parameters Passed to the Report
- 21. Procedure and Function Business Rule Catalogue
  - 21.1 Catalogue Index
  - 21.2 Detailed Specifications
    - SP-001 - VIEW_EXCEL_REP
    - SP-002 - D2KWUTIL.ATTEMPT_DLL_LOAD
    - SP-003 - D2KWUTIL.D2KWUTIL_DEBUGSTRING
    - SP-004 - D2KWUTIL.D2KWUTIL_GETDOSENV
    - SP-005 - D2KWUTIL.D2KWUTIL_GETREGKEY
    - SP-006 - D2KWUTIL.TRANSLATETYPE
    - SP-007 - GENERAL.ASK_CONFIRM
    - SP-008 - GENERAL.DISP_TEXT
    - SP-009 - GENERAL.RAISE_ERROR
    - SP-010 - WEBUTIL.BLOCKING
    - SP-011 - WEBUTIL.CHECKLIBS
    - SP-012 - WEBUTIL.CLEARCALLBACKTRIGGER
    - SP-013 - WEBUTIL.CLOSEBLOB
    - SP-014 - WEBUTIL.CLOSEFILE
    - SP-015 - WEBUTIL.DOWNLOADFROMURLINT
    - SP-016 - WEBUTIL.ERROR
    - SP-017 - WEBUTIL.ERRORALERT
    - SP-018 - WEBUTIL.EXECUTE
    - SP-019 - WEBUTIL.FCLOSE
    - SP-020 - WEBUTIL.FOPEN
    - SP-021 - WEBUTIL.GETCALLBACKTRIGGER
    - SP-022 - WEBUTIL.GETCLIENTOSFAMILY
    - SP-023 - WEBUTIL.GETCLIENTSETTING
    - SP-024 - WEBUTIL.GETIMPLCLASS
    - SP-025 - WEBUTIL.GETLASTERROR
    - SP-026 - WEBUTIL.GETLASTERRORARGS
    - SP-027 - WEBUTIL.GETNUMBER
    - SP-028 - WEBUTIL.GETOSFAMILY
    - SP-029 - WEBUTIL.GETOUTPUT
    - SP-030 - WEBUTIL.GETPROPERTY
    - SP-031 - WEBUTIL.GETSTRING
    - SP-032 - WEBUTIL.GETVAR
    - SP-033 - WEBUTIL.GET_LINE
    - SP-034 - WEBUTIL.GET_STANDARD_OUTPUT
    - SP-035 - WEBUTIL.ID_NULL
    - SP-036 - WEBUTIL.INIT
    - SP-037 - WEBUTIL.INITWEBUTIL
    - SP-038 - WEBUTIL.ISERROR
    - SP-039 - WEBUTIL.IS_OPEN
    - SP-040 - WEBUTIL.LENGTH
    - SP-041 - WEBUTIL.LOG
    - SP-042 - WEBUTIL.POPULATEPROPERTYBUNDLE
    - SP-043 - WEBUTIL.PUT_LINE
    - SP-044 - WEBUTIL.READFROMPROPERTYBUNDLE
    - SP-045 - WEBUTIL.READTRANSFROMMSGBUNDLE
    - SP-046 - WEBUTIL.REGISTERBEAN
    - SP-047 - WEBUTIL.REGISTER_FUNCTION
    - SP-048 - WEBUTIL.RELEASE_PROCESS
    - SP-049 - WEBUTIL.SETCLIENTSETTING
    - SP-050 - WEBUTIL.SETDATA
    - SP-051 - WEBUTIL.SETPROPERTY
    - SP-052 - WEBUTIL.SHOWBEANS
    - SP-053 - WEBUTIL.WRITEDATA
    - SP-054 - WEBUTIL_CORE.CUSTOMEVENTHANDLER
    - SP-055 - ADD_ERROR
    - SP-056 - ADD_EXTERNAL_ERRORS
    - SP-057 - BOOLTOCHAR
    - SP-058 - CLEAN_ERROR_STACK
    - SP-059 - DEBUGLOG
    - SP-060 - GET_ENVIRONMENT_STRING
    - SP-061 - READ_REGISTRY
    - SP-062 - REGISTER_FUNCTION_CALL
    - SP-063 - SETDEBUG
    - SP-064 - SF_COPYRIGHT_DECLARATION
    - SP-065 - STRIPDIRSEP
    - SP-066 - WINDEBUG

## 1. Document Control

### 1.1 Document Information

| Field | Value |
| ----- | ----- |
| Document Title | SR_EXCH_LYL_DLR_REP - Business Requirements Document |
| Form Module Name | SR_EXCH_LYL_DLR_REP |
| Document Version | 1.0 |
| Date Created | August 04, 2026 |
| Author/Prepared By | BRD Agent |

### 1.2 Revision History

| Version | Date | Author | Description |
| --- | --- | --- | --- |
| 1.0 | August 04, 2026 | BRD Agent | Initial draft |

---

## 2. Executive Summary

*High-level overview of the sr_exch_lyl_dlr_rep Exchange/Loyalty Dealer Report form, its purpose, and roles referenced in the module.*

The **sr_exch_lyl_dlr_rep** Oracle Forms module is the **Exchange and Loyalty Dealer Report** screen. Dealer users open the screen, set a combination of report filters - selecting a dealer, an outlet, a scheme type (Exchange or Swap), an invoice type (C-Form Invoice or Direct Billing), a bonus model preference, a date range of up to ten days, optional closure and status date ranges, and a claim status - and click Submit to generate the report. Before the report is produced, the screen validates that all mandatory selections have been made, that date ranges are logically consistent, and that the invoice date span does not exceed ten days. On submission, old-to-new dealer migration codes are resolved automatically, the appropriate data view is assembled based on the selected scheme and invoice type, and the results are written out as a downloadable CSV file that opens directly in the browser. The form does not perform any data entry or record updates; it is a report-generation tool only.

### Key Stakeholders

*Who uses sr_exch_lyl_dlr_rep*

| Stakeholder | Role |
| :--- | :--- |
| **Dealer User** | Primary interactive user of the report screen. Selects filter criteria, submits the report, and downloads the Exchange/Loyalty claim data for their assigned dealer and outlet. |
| **DMS Administrator** | Maintains the dealer, outlet, and status lookup data that populates the selection lists on this screen. Does not use the form directly. |
| **Regional / Principal Manager** | Downstream consumer of the generated report; reviews Exchange and Loyalty claim data by dealer, outlet, scheme, and status to monitor scheme performance. Does not use the form directly. |

---

---

## 3. System Context

*Describes the sr_exch_lyl_dlr_rep module's role within the DMS ecosystem, scope, process flow, and key integrations.*

The **sr_exch_lyl_dlr_rep** module is the **Exchange and Loyalty Dealer Report** screen within the Dealer Management System (DMS). It allows authorised dealer users to extract claim data for Exchange and Loyalty schemes by applying a defined set of filters and receiving a downloadable CSV report. The screen sits between the dealer's operational data and the reporting layer, and connects to dealer master, outlet, status lookup, and Exchange/Loyalty claim data maintained elsewhere in the DMS.

**System purpose:** Enable dealer users to filter, generate, and download Exchange/Loyalty claim data by dealer, outlet, scheme type, invoice type, bonus model, date range, and claim status - from filter selection through validation and CSV report delivery - as implemented in the sr_exch_lyl_dlr_rep Oracle Forms module.

**In scope:**

- Select a dealer from the user's assigned dealer list
- Select an outlet (location) associated with the chosen dealer
- Select a scheme type: Exchange scheme or Swap scheme
- Select an invoice type: C-Form Invoice or Direct Billing
- Select a bonus model option: Bonus only, Non-Bonus only, or All
- Enter an invoice date range (mandatory; maximum 10 days)
- Optionally enter a closure date range and a status date range
- Select a claim status from the configurable status list
- Validate all mandatory filter fields before report generation
- Validate date ranges for logical consistency and maximum span
- Resolve old-to-new dealer migration codes at report generation time
- Build and execute a report query filtered by scheme type and invoice type combination
- Generate and deliver the Exchange/Loyalty Dealer Report as a CSV file in the browser

**Process Name:** Exchange/Loyalty Dealer Report Generation

**Process Owner:** INFERRED - Dealer Operations Manager

**Process Objective:** Allow a dealer user to select report criteria, validate the filter combination, and receive a CSV report of Exchange/Loyalty scheme claims for their dealer and outlet within the chosen date range.

**Process Trigger:** Dealer user opens the Exchange/Loyalty Dealer Report screen to extract claim data for review or submission purposes.

**Process Flow:**

The complete exchange/loyalty dealer report generation process follows this sequence. Each step corresponds to Functional Requirements in Section 4.

```
STEP 1 ── SCREEN OPENS
         Dealer user opens the sr_exch_lyl_dlr_rep screen.
         Application context is registered. The report title and copyright fields
         are set to their default values. Performance timer starts if logging is enabled.

STEP 2 ── DEALER SELECTION
         User selects a dealer from the Dealer LOV.
         The list is filtered to show only dealers assigned to the logged-in user
         and the current principal. Includes an ALL option.

STEP 3 ── OUTLET SELECTION
         User selects an outlet (location) from the Outlet LOV.
         The list is dynamically filtered to show only outlets belonging to the
         selected dealer and user assignment. Includes an ALL option.
         ├── If outlet field left empty: validation error is raised.
         └── If resolved old/new location code is empty: validation error is raised.

STEP 4 ── SCHEME TYPE SELECTION
         User selects a scheme type from the list (Exchange or Swap).
         ├── If scheme field is empty: validation error is raised.

STEP 5 ── INVOICE TYPE SELECTION
         User selects an invoice type from the list (C-Form Invoice or Direct Billing).
         ├── If invoice type field is empty: validation error is raised.

STEP 6 ── BONUS MODEL SELECTION
         User selects a bonus model option: Bonus, Non-Bonus, or All.
         ├── If bonus model field is empty: validation error is raised.

STEP 7 ── INVOICE FROM DATE ENTRY
         User enters the report start date (invoice from date).
         System validates:
         ├── Date must not be empty.
         ├── Date must not be in the future.
         ├── Date must not exceed the invoice to date.
         └── Date range (to date minus from date) must not exceed 10 days.

STEP 8 ── INVOICE TO DATE ENTRY
         User enters the report end date (invoice to date).
         System validates:
         ├── To date cannot be entered without a from date.
         ├── To date must not be before the from date.
         └── To date must not be in the future.

STEP 9 ── CLOSURE DATE RANGE ENTRY (optional)
         User optionally enters a dealer submission (closure) date range.
         System validates:
         ├── Closure from date must not be in the future.
         ├── Closure from date must not be before the invoice from date.
         ├── Closure to date must not be entered without a closure from date.
         └── Closure to date must not be before the closure from date.

STEP 10 ── STATUS DATE RANGE ENTRY (optional)
          User optionally enters a status date range.
          System validates:
          ├── Status from date must not be in the future.
          ├── Status from date must not be before the invoice from date.
          ├── Status to date must not be entered without a status from date.
          └── Status to date must not be before the status from date.

STEP 11 ── STATUS SELECTION
          User selects a claim status from the Status LOV.
          The status list is sourced from the application configuration for the current principal.
          ├── If status field is empty: validation error is raised.

STEP 12 ── SUBMIT - PRE-GENERATION VALIDATION
          User clicks the Submit button.
          System validates that the invoice date range does not exceed 10 days.
          ├── If range exceeds 10 days: error message is displayed and submission is blocked.

STEP 13 ── STATUS CODE EXPANSION
          System maps the selected claim status code internally.
          The 'ALL' status value is expanded to include both active and unprocessed codes.

STEP 14 ── BONUS MODEL CODE MAPPING
          System translates the bonus model selection into the corresponding internal scheme codes
          used in the report query (Bonus -> BMD/BMN; Non-Bonus -> NBM; All -> BMD/BMN/NBM).

STEP 15 ── OLD/NEW DEALER CODE RESOLUTION
          System queries the dealer location master to resolve old-to-new dealer migration codes.
          The resolved parent group, dealer map code, and outlet code are used in the report query.

STEP 16 ── REPORT QUERY ASSEMBLY
          System builds the report query dynamically based on scheme type and invoice type:
          ├── Exchange scheme, C-Form Invoice
          ├── Exchange scheme, Direct Billing
          ├── Swap scheme, C-Form Invoice
          └── Swap scheme, Direct Billing
          Each path also has an old/new dealer variant.

STEP 17 ── CSV FILE GENERATION
          System executes the assembled query, iterates the result set, and writes each row to a
          CSV file on the server. The file is named using the logged-in user ID and current timestamp.

STEP 18 ── REPORT DELIVERY
          System opens the generated CSV file in the browser so the user can view or download it.

STEP 19 ── SCREEN RESET (optional)
          User may press the Clear key to reset all filter fields to their defaults.
          Report title and copyright fields are restored to their default values.

STEP 20 ── EXIT
          User exits the form. Application context is cleared from the database session.
```

**Major process interactions:**

- **Dealer master data** - provides the list of dealers and outlets available to the logged-in user
- **Dealer location master** - resolves old-to-new dealer migration codes at report generation time
- **Application list configuration** - supplies the configurable claim status values for the current principal
- **Exchange/Loyalty claim data** - source of report data; queried by the generated SQL based on selected filters
- **Sales and invoice data** - invoice and order-book records joined in the report query for claim details
- **Vehicle and model master data** - provides vehicle, model, and variant descriptions in the report output
- **Server file system** - stores the generated CSV file before it is served to the browser
- **Browser/web client** - receives and displays the CSV report file for download

---

---

## 4. Functional Requirements

### 4.1 Business Requirements

#### Requirement ID: BR-001

**Requirement Title:** Form Initialisation and Application Session Registration

**Business Description:**
When the Exchange / Loyalty Dealer Report screen is opened, the system registers the current user session against this specific report module, maximises the screen to fill the display area, and pre-fills the report title together with a default ten-day date window so the user can begin reviewing claims immediately. The application identifier is recorded so the Excel export and other downstream steps can correctly reference the originating module. If application-level timing has been enabled, a performance timer is also started so that response-time data can be collected for audit and monitoring purposes.

**Actors:** Dealer User

**Preconditions:**
- The user has launched the Exchange / Loyalty Dealer Report module.

**Main Flow:**

**Step 1 - Session registration with the module name**
The system records that the current user session is working with the Exchange / Loyalty Dealer Report module. This allows system administrators to identify which form a session is using at any given moment for monitoring, troubleshooting, and performance analysis.

**Step 2 - Application window maximised to full screen**
Immediately after session registration, the system maximises both the application container window and the main report screen (WN_MAIN) to fill the available display area, so the user sees the full report entry screen without manual resizing.

**Step 3 - Report title and default date range pre-filled**
The report description label is set to "Exchange/Loyalty Status Report" and the application identifier seed (`global.app_id`) is set to `sr_exch_lyl_dlr_rep` so that subsequent processing steps and the Excel export routine can identify the originating module. The Invoice From Date is defaulted to the first day of the current calendar month and the Invoice To Date is defaulted to ten days after the first day of the month, giving the user a ready-to-use ten-day initial date window.

**Step 4 - Application logging timer started (conditional)**
If the application-level logging flag has been enabled for the deployment, the system starts a performance timer at the point the form opens. This timer is used to measure and record the response time of the session for operational monitoring purposes.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Application Logging Flag (`GLOBAL.APP_LOG`) | Auto-populated | Character | 1 | N/A | `Y` = logging enabled | N/A | System-controlled; not user-editable | N/A |
| Application Identifier (`GLOBAL.APP_ID`) | Auto-populated | Character | 50 | N/A | `sr_exch_lyl_dlr_rep` | N/A | System-set at form open; not user-editable | N/A |
| Invoice From Date (`CB_BLK.P_FROMDT`) | Auto-populated | Date | 10 / DD/MM/RRRR | N/A | First day of current month | N/A | System-set default; user may change | N/A |
| Invoice To Date (`CB_BLK.P_TODT`) | Auto-populated | Date | 10 / DD/MM/RRRR | N/A | First day of current month + 9 days | Invoice From Date | System-set default; user may change | N/A |

---

---

#### Requirement ID: BR-002

**Requirement Title:** Form Toolbar Actions - Save, Cancel, Insert Block, Delete, and Clear

**Business Description:**
The Exchange / Loyalty Dealer Report screen provides toolbar buttons for the most common data-management actions: saving entered filter criteria, cancelling unsaved entries, blocking insert operations (which are not supported on this form), deleting existing programme records with confirmation, and clearing the screen to start a fresh filter entry. When the user saves, the system commits the data and then clears the screen. When the user cancels with unsaved changes, the system prompts for confirmation before discarding those changes. If the user attempts to insert a new record, the system blocks the action and informs the user that insertion is not permitted here. When the user deletes a programme master record, the system asks for explicit confirmation before proceeding. The clear action resets all filter fields and restores the report title and copyright notice.

**Actors:** Dealer User

**Preconditions:**
- The Exchange / Loyalty Dealer Report screen is open.

**Main Flow:**

**Step 1 - Save: data committed and screen cleared**
The user clicks the Save toolbar button. The system saves all entered data to the database and then clears the screen so the user is returned to a blank entry state ready for the next use.

**Step 2 - Cancel: confirmation requested when unsaved changes exist**
The user clicks the Cancel toolbar button. If any on-screen data has been changed but not yet saved, the system asks the user to confirm the discard: *"Entered data will not be Saved"*. If the user confirms (selects button 1), the screen is cleared and all unsaved changes are discarded. If the form has no unsaved changes, the screen is cleared immediately without prompting.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Unsaved changes present on cancel | FT_CANCEL - check SYSTEM.FORM_STATUS = 'CHANGED' and GENERAL.ASK_CONFIRM | When the user clicks the Cancel button with unsaved changes | Prevents accidental loss of entered data by requiring the user to confirm the discard | If the user does not confirm, the cancel is abandoned and existing data remains on screen |

*Business outcomes (errors, warnings, success, and status):*
- **BR-002-WS-01** - Unsaved changes exist when Cancel is clicked - *"Entered data will not be Saved"*; user must confirm to discard; if confirmed, screen is cleared.

**Step 3 - Insert blocked: not permitted on this form**
The user clicks the Insert toolbar button. Because this form does not support record creation through the insert action, the system displays the message *"This Operation Cannot be performed Here"* and no insert takes place.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Insert action is not permitted on this form | FT_INSERT - GENERAL.DISP_TEXT fires when Insert button is enabled | When the user clicks the Insert toolbar button | Prevents inadvertent data creation on a report-only form that does not support record insertion | *"This Operation Cannot be performed Here"* displayed; no record is created |

*Business outcomes (errors, warnings, success, and status):*
- **BR-002-ES-01** - Insert attempted - *"This Operation Cannot be performed Here"*; insert is blocked.

**Step 4 - Delete: confirmation required before record removal**
The user clicks the Delete toolbar button while the cursor is on the main programme master record. The system temporarily suspends form-level validation, then asks the user to confirm the deletion: *"Are you sure to Delete?"*. If the user confirms (selects button 1), the current record is deleted and form-level validation is re-enabled. If the user does not confirm, no deletion occurs and validation is re-enabled without change.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Delete confirmation required | FT_DEL - GENERAL.ASK_CONFIRM fires when Delete button is enabled and cursor is on main block | When the user clicks the Delete toolbar button | Prevents accidental deletion of programme master records by requiring explicit user confirmation | If the user does not confirm, the record is not deleted and the screen is unchanged |

*Business outcomes (errors, warnings, success, and status):*
- **BR-002-WS-02** - Delete confirmation requested - *"Are you sure to Delete?"*; if confirmed, the record is permanently removed; if not confirmed, no change is made.

**Step 5 - Clear: screen reset and report title restored**
The user initiates a clear action (or the clear is triggered automatically after a save). The system removes all previously entered filter values from the screen. The report description label is set back to "Exchange/Loyalty Status Report" so the user sees the standard module title again.

**Step 6 - Copyright notice refreshed after clear**
The system retrieves the current copyright declaration text and displays it in the copyright display area at the bottom of the screen.

*Procedures called:*
- **SF_COPYRIGHT_DECLARATION** ([SP-013](#SP-013--SF_COPYRIGHT_DECLARATION)) - SF_COPYRIGHT_DECLARATION - retrieves and returns the standard copyright declaration text to be shown on the form.
    * **Step 1** - Validate the input values.
    * **Step 2** - Retrieve the required business data.
    * **Step 3** - Apply business validations.
    * **Step 4** - Update the required records.
    * **Step 5** - Return the processing result.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Report Description (`CB_BLK.REPORT_DESC`) | Auto-populated | Display text | 200 | N/A | Fixed value "Exchange/Loyalty Status Report" | N/A | System-set; not user-editable | N/A |
| Copyright Notice (`CB_BLK.COPY_RIGHT`) | Auto-populated | Display text | 500 | N/A | Value returned by copyright function | N/A | System-set; not user-editable | N/A |

---

---

#### Requirement ID: BR-003

**Requirement Title:** Form Exit and Session Cleanup

**Business Description:**
When the user chooses to exit the Exchange / Loyalty Dealer Report screen, the system clears the session's application registration information - removing the module association and action label recorded at form open - and then closes the form without prompting the user to save any unsaved data, since this is a report-generation form with no data entry to preserve.

**Actors:** Dealer User

**Preconditions:**
- The Exchange / Loyalty Dealer Report screen is open.

**Main Flow:**

**Step 1 - Session registration cleared**
The system clears the application client information that was recorded when the form opened, and resets the module name and action label to empty values. This ensures that the user's session is no longer attributed to this module once they have left.

**Step 2 - Form closed without save prompt**
The form closes immediately. No save or validation confirmation is shown to the user, as this form does not manage data records that require saving.

---

---

#### Requirement ID: BR-004

**Requirement Title:** Dealer Selection Validation

**Business Description:**
When the user moves away from the Dealer Details selection field, the system checks that a dealer has been chosen. If the field has been left empty, the user is shown an error message and must supply a valid dealer selection before they can proceed to any other field or submit the report.

**Actors:** Dealer User

**Preconditions:**
- The Exchange / Loyalty Dealer Report screen is open.

**Main Flow:**

**Step 1 - Dealer Details field validated on exit**
As the user tabs away from the Dealer Details field, the system checks whether a dealer has been selected. If the field is blank, the user sees the error *"Dealer Details can not be empty"* and the cursor remains on the field, preventing further navigation until a dealer is chosen.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Dealer Details is mandatory | WHEN-VALIDATE-ITEM on CB_BLK.P_DELR_CD - inline NULL check | When the user leaves the Dealer Details field | Ensures a dealer is always selected before report parameters can be completed, preventing submission of a report with no dealer scope | *"Dealer Details can not be empty"* is displayed; the trigger aborts and the cursor stays on the field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-004-ES-01** - Dealer Details field is empty when the user leaves it - *"Dealer Details can not be empty"*; the form aborts navigation and keeps focus on the Dealer Details field.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dealer Details (`CB_BLK.P_DELR_CD`) | Mandatory | Text | 500 | Dealer lookup (LV_DEALER) | Dealer code | N/A | Must not be empty | *"Dealer Details can not be empty"* |

---

---

#### Requirement ID: BR-005

**Requirement Title:** Outlet Selection Validation

**Business Description:**
When the user moves away from the Outlet Details selection field, the system checks that an outlet has been chosen. If the field is empty, the user is shown an error message and must supply a valid outlet selection before they can proceed.

**Actors:** Dealer User

**Preconditions:**
- The Exchange / Loyalty Dealer Report screen is open.

**Main Flow:**

**Step 1 - Outlet Details field validated on exit**
As the user tabs away from the Outlet Details field, the system checks whether an outlet has been selected. If the field is blank, the user sees the error *"Outlet Details can not be empty"* and the cursor stays on the field until a valid outlet is chosen.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Outlet Details is mandatory | WHEN-VALIDATE-ITEM on CB_BLK.P_LOC_CD - inline NULL check | When the user leaves the Outlet Details field | Ensures a specific outlet is always identified before the report is submitted, preventing results that span unintended outlets | *"Outlet Details can not be empty"* is displayed; the trigger aborts and the cursor stays on the field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-ES-01** - Outlet Details field is empty when the user leaves it - *"Outlet Details can not be empty"*; the form aborts navigation and keeps focus on the Outlet Details field.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Outlet Details (`CB_BLK.P_LOC_CD`) | Mandatory | Text | 500 | Outlet lookup (LV_LOC) | Outlet code | N/A | Must not be empty | *"Outlet Details can not be empty"* |
| Outlet Description (`CB_BLK.P_LOC_DESC`) | Auto-populated | Display text | 500 | N/A | Description returned by outlet lookup | Outlet code selected | System-set after outlet is chosen | N/A |

---

---

#### Requirement ID: BR-006

**Requirement Title:** Scheme Selection Validation

**Business Description:**
When the user moves away from the Scheme filter field, the system checks that a scheme type has been selected. If no scheme has been chosen, the user is shown an error message and must make a selection before proceeding to any other field or submitting the report.

**Actors:** Dealer User

**Preconditions:**
- The Exchange / Loyalty Dealer Report screen is open.

**Main Flow:**

**Step 1 - Scheme field validated on exit**
As the user tabs away from the Scheme field, the system checks whether a scheme type has been selected. If the field is blank, the user sees the error *"Scheme can not be empty"* and the cursor stays on the field until a selection is made.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Scheme is mandatory | WHEN-VALIDATE-ITEM on CB_BLK.P_SCHEME - inline NULL check | When the user leaves the Scheme field | Ensures the report is always scoped to a specific scheme type, preventing the system from generating an unscoped or ambiguous report | *"Scheme can not be empty"* is displayed; the trigger aborts and the cursor stays on the Scheme field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-006-ES-01** - Scheme field is empty when the user leaves it - *"Scheme can not be empty"*; the form aborts navigation and keeps focus on the Scheme field.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Scheme (`CB_BLK.P_SCHEME`) | Mandatory | List | 100 | N/A | Scheme type options in the drop-down list | N/A | Must not be empty | *"Scheme can not be empty"* |

---

---

#### Requirement ID: BR-007

**Requirement Title:** Invoice Type Selection Validation

**Business Description:**
When the user moves away from the Invoice Type filter field, the system checks that an invoice type has been selected. If the field is empty, the user is shown an error message and must make a selection before they can continue.

**Actors:** Dealer User

**Preconditions:**
- The Exchange / Loyalty Dealer Report screen is open.

**Main Flow:**

**Step 1 - Invoice Type field validated on exit**
As the user tabs away from the Invoice Type field, the system checks whether an invoice type has been chosen. If the field is blank, the user sees the error *"Invoice Type can not be empty"* and the cursor stays on the field until a valid selection is made.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Invoice Type is mandatory | WHEN-VALIDATE-ITEM on CB_BLK.P_INV_TYPE - inline NULL check on CB_BLK.P_SCHEME (note: the trigger code checks `:CB_BLK.P_SCHEME IS NULL` but the error message shown is for Invoice Type) | When the user leaves the Invoice Type field | Ensures the report is scoped to a specific invoice type so the data extracted matches the correct billing category | *"Invoice Type can not be empty"* is displayed; the trigger aborts and the cursor stays on the Invoice Type field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-007-ES-01** - Invoice Type field is empty when the user leaves it - *"Invoice Type can not be empty"*; the form aborts navigation and keeps focus on the Invoice Type field.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Invoice Type (`CB_BLK.P_INV_TYPE`) | Mandatory | List | 100 | N/A | Invoice type options in the drop-down list | N/A | Must not be empty | *"Invoice Type can not be empty"* |

---

---

#### Requirement ID: BR-008

**Requirement Title:** Bonus/Non-Bonus Model Selection Validation

**Business Description:**
When the user moves away from the Bonus/Non Bonus Model filter field, the system checks that a selection has been made. If no option has been chosen, the user is shown an error message and must make a selection before proceeding.

**Actors:** Dealer User

**Preconditions:**
- The Exchange / Loyalty Dealer Report screen is open.

**Main Flow:**

**Step 1 - Bonus/Non Bonus Model field validated on exit**
As the user tabs away from the Bonus/Non Bonus Model field, the system checks whether a value has been selected. If the field is blank, the user sees the error *"Bonus/Non Bonus Model can not be empty"* and the cursor stays on the field.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Bonus/Non Bonus Model is mandatory | WHEN-VALIDATE-ITEM on CB_BLK.P_BONUS_YN - inline NULL check | When the user leaves the Bonus/Non Bonus Model field | Ensures the report is filtered to a specific bonus category so results correctly reflect the intended bonus model scope | *"Bonus/Non Bonus Model can not be empty"* is displayed; the trigger aborts and the cursor stays on the field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-008-ES-01** - Bonus/Non Bonus Model field is empty when the user leaves it - *"Bonus/Non Bonus Model can not be empty"*; the form aborts navigation and keeps focus on the field.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Bonus/Non Bonus Model (`CB_BLK.P_BONUS_YN`) | Mandatory | List | 100 | N/A | Bonus model options in the drop-down list | N/A | Must not be empty | *"Bonus/Non Bonus Model can not be empty"* |

---

---

#### Requirement ID: BR-009

**Requirement Title:** Invoice Date Range Validation and To-Date Auto-Calculation

**Business Description:**
When the user enters or confirms the Invoice From Date, the system validates that the date is not in the future and does not exceed the Invoice To Date. If the From Date is valid, the system automatically calculates and populates the Invoice To Date as the From Date plus nine days (capped at today's date if the calculated end date would fall in the future), giving the user a pre-set ten-day window that they may further adjust. The Invoice From Date is a mandatory field; leaving it blank also triggers an error.

**Actors:** Dealer User

**Preconditions:**
- The Exchange / Loyalty Dealer Report screen is open.

**Main Flow:**

**Step 1 - Invoice From Date validated on exit**
As the user tabs away from the Invoice From Date field, the system first checks that a date has been entered. If the field is blank, the user sees *"From Date can not be empty"* and the cursor remains on the field.

If a date has been entered, the system checks whether it is greater than today's date. If so, the user sees the alert *"From Date cannot be greater than Current Date"* and the trigger aborts. If the From Date is greater than the current Invoice To Date, the user sees the alert *"From Date cannot be greater than To Date"* and the trigger aborts.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Invoice From Date is mandatory | WHEN-VALIDATE-ITEM on CB_BLK.P_FROMDT - inline NULL check | When the user leaves the Invoice From Date field | Ensures the report always has a starting date boundary | *"From Date can not be empty"*; the trigger aborts, cursor stays on the field |
| Invoice From Date must not be in the future | WHEN-VALIDATE-ITEM on CB_BLK.P_FROMDT - comparison to current date | When the user leaves the Invoice From Date field | Prevents selection of a date range that has not yet occurred | Alert *"From Date cannot be greater than Current Date"* displayed; the trigger aborts |
| Invoice From Date must not exceed Invoice To Date | WHEN-VALIDATE-ITEM on CB_BLK.P_FROMDT - comparison to P_TODT | When the user leaves the Invoice From Date field | Ensures the date range is logically consistent | Alert *"From Date cannot be greater than To Date"* displayed; the trigger aborts |

*Business outcomes (errors, warnings, success, and status):*
- **BR-009-ES-01** - Invoice From Date is blank - *"From Date can not be empty"*; the trigger aborts and the cursor stays on the Invoice From Date field.
- **BR-009-ES-02** - Invoice From Date is after today's date - alert *"From Date cannot be greater than Current Date"*; the trigger aborts.
- **BR-009-ES-03** - Invoice From Date is after the current Invoice To Date - alert *"From Date cannot be greater than To Date"*; the trigger aborts.

**Step 2 - Invoice To Date automatically calculated**
After the From Date passes all validations, the system calculates the Invoice To Date as the From Date plus nine days. If that calculated date would be after today, the To Date is set to today instead. This gives the user a default ten-day window without requiring them to enter the To Date manually.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Invoice From Date (`CB_BLK.P_FROMDT`) | Mandatory | Date | 10 / DD/MM/RRRR | N/A | N/A | N/A | Must not be blank; must not be in the future; must not exceed Invoice To Date | *"From Date can not be empty"*; alert *"From Date cannot be greater than Current Date"*; alert *"From Date cannot be greater than To Date"* |
| Invoice To Date (`CB_BLK.P_TODT`) | Auto-populated | Date | 10 / DD/MM/RRRR | N/A | Calculated as From Date + 9 days (capped at today) | Invoice From Date entered | Recalculated automatically after From Date is validated | N/A |

---

---

#### Requirement ID: BR-010

**Requirement Title:** Invoice To Date Validation

**Business Description:**
When the user enters or modifies the Invoice To Date, the system performs a series of checks to ensure the date range is logically valid and does not exceed the maximum permitted span of six months. The To Date cannot be entered without first providing a From Date, cannot be earlier than the From Date, cannot be in the future, and the total range from From Date to To Date must not exceed six months.

**Actors:** Dealer User

**Preconditions:**
- The Exchange / Loyalty Dealer Report screen is open.
- An Invoice From Date has been entered (required before a To Date can be accepted).

**Main Flow:**

**Step 1 - Invoice To Date validated on exit**
As the user tabs away from the Invoice To Date field, the system checks in the following order: (1) if the To Date field contains a value, check that the Invoice From Date has already been entered - if not, the user sees *"To date cannot be entered without entering From date"*, the To Date field is cleared, and the trigger aborts; (2) if the To Date is earlier than the From Date, the alert *"To Date cannot be lesser than From Date"* is shown and the trigger aborts; (3) if the From Date is greater than the To Date (covering the reverse comparison), the alert *"From Date cannot be greater than To Date"* is shown and the trigger aborts; (4) if the To Date is after today's date, the alert *"To Date cannot be greater than Current Date"* is shown and the trigger aborts; (5) if the difference between the From Date and the To Date exceeds six months, the alert *"Please give the date range of maximum Six month"* is shown and the trigger aborts.

If the To Date is blank, no validation fires (the field is treated as optional when left empty at this point per the active code path).

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| To Date requires From Date to be entered first | WHEN-VALIDATE-ITEM on CB_BLK.P_TODT - check P_FROMDT IS NULL | When the user leaves the Invoice To Date field after entering a value | Prevents an illogical date range where the end is defined but the start is not | *"To date cannot be entered without entering From date"*; To Date cleared; trigger aborts |
| To Date must not be earlier than From Date | WHEN-VALIDATE-ITEM on CB_BLK.P_TODT - P_TODT < P_FROMDT | When the user leaves the Invoice To Date field | Ensures the date range has a positive span | Alert *"To Date cannot be lesser than From Date"*; trigger aborts |
| From Date must not be greater than To Date | WHEN-VALIDATE-ITEM on CB_BLK.P_TODT - P_FROMDT > P_TODT | When the user leaves the Invoice To Date field | Catches the reverse comparison for consistency | Alert *"From Date cannot be greater than To Date"*; trigger aborts |
| To Date must not be in the future | WHEN-VALIDATE-ITEM on CB_BLK.P_TODT - P_TODT > current date | When the user leaves the Invoice To Date field | Prevents querying data that does not yet exist | Alert *"To Date cannot be greater than Current Date"*; trigger aborts |
| Date range must not exceed six months | WHEN-VALIDATE-ITEM on CB_BLK.P_TODT - P_TODT > ADD_MONTHS(P_FROMDT,6)-1 | When the user leaves the Invoice To Date field | Limits the report data volume to a manageable and policy-defined maximum range | Alert *"Please give the date range of maximum Six month"*; trigger aborts |

*Business outcomes (errors, warnings, success, and status):*
- **BR-010-ES-01** - Invoice To Date entered without a From Date - *"To date cannot be entered without entering From date"*; To Date is cleared; trigger aborts.
- **BR-010-ES-02** - Invoice To Date is earlier than From Date - alert *"To Date cannot be lesser than From Date"*; trigger aborts.
- **BR-010-ES-03** - Invoice From Date is greater than To Date - alert *"From Date cannot be greater than To Date"*; trigger aborts.
- **BR-010-ES-04** - Invoice To Date is after today - alert *"To Date cannot be greater than Current Date"*; trigger aborts.
- **BR-010-ES-05** - Date range exceeds six months - alert *"Please give the date range of maximum Six month"*; trigger aborts.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Invoice To Date (`CB_BLK.P_TODT`) | Conditional - when Invoice From Date is entered | Date | 10 / DD/MM/RRRR | N/A | N/A | Invoice From Date entered | Must not precede From Date; must not be in the future; range must not exceed 6 months | Alerts per individual check; trigger aborts on failure |
| Invoice From Date (`CB_BLK.P_FROMDT`) | Mandatory | Date | 10 / DD/MM/RRRR | N/A | N/A | N/A | Referenced during To Date validation | N/A - validated separately under BR-009 |

---

#### Requirement ID: BR-011

**Requirement Title:** Dealer Submission Date Range Validation and To-Date Auto-Calculation

**Business Description:**
When the user enters a Dealer Submission From Date, the system validates that the date is not in the future, does not fall before the Invoice From Date, and does not exceed the Dealer Submission To Date. If the date passes all checks, the system automatically calculates and populates the Dealer Submission To Date as the last day of the month following the Dealer Submission From Date (capped at today if that date has not yet arrived). The Dealer Submission From Date is optional; if it is left blank, the system applies no date filter for dealer submission date on the report. The previously active error message for a blank From Date has been commented out in the code.

**Actors:** Dealer User

**Preconditions:**
- The Exchange / Loyalty Dealer Report screen is open.
- An Invoice From Date has already been entered (used as the lower boundary for dealer submission date validation).

**Main Flow:**

**Step 1 - Dealer Submission From Date validated on exit (when provided)**
If the user has entered a Dealer Submission From Date, the system checks it against three rules in order: (1) if the date is after today, the alert *"From Date cannot be greater than Current Date"* is shown and the trigger aborts; (2) if the date is before the Invoice From Date, the alert *"Dealer Submission From Date cannot be less than Invoice From Date"* is shown and the trigger aborts; (3) if the date is after the Dealer Submission To Date, the alert *"From Date cannot be greater than To Date"* is shown and the trigger aborts.

If the field is left blank, no validation fires and the trigger completes silently.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Dealer Submission From Date must not be in the future | WHEN-VALIDATE-ITEM on CB_BLK.P_CL_FROMDT - comparison to current date | When the user leaves the Dealer Submission From Date field | Prevents use of a submission date boundary that has not occurred | Alert *"From Date cannot be greater than Current Date"*; trigger aborts |
| Dealer Submission From Date must not be before Invoice From Date | WHEN-VALIDATE-ITEM on CB_BLK.P_CL_FROMDT - P_CL_FROMDT < P_FROMDT | When the user leaves the Dealer Submission From Date field | Ensures the submission period does not start before the invoice period, maintaining logical consistency between the two date filters | Alert *"Dealer Submission From Date cannot be less than Invoice From Date"*; trigger aborts |
| Dealer Submission From Date must not exceed Dealer Submission To Date | WHEN-VALIDATE-ITEM on CB_BLK.P_CL_FROMDT - comparison to P_CL_TODT | When the user leaves the Dealer Submission From Date field | Ensures the date range is logically consistent | Alert *"From Date cannot be greater than To Date"*; trigger aborts |

*Business outcomes (errors, warnings, success, and status):*
- **BR-011-ES-01** - Dealer Submission From Date is after today - alert *"From Date cannot be greater than Current Date"*; trigger aborts.
- **BR-011-ES-02** - Dealer Submission From Date is before Invoice From Date - alert *"Dealer Submission From Date cannot be less than Invoice From Date"*; trigger aborts.
- **BR-011-ES-03** - Dealer Submission From Date is after Dealer Submission To Date - alert *"From Date cannot be greater than To Date"*; trigger aborts.

**Step 2 - Dealer Submission To Date automatically calculated**
After the From Date passes all checks, the system calculates the Dealer Submission To Date as the last day of the month following the Dealer Submission From Date. If that calculated date would be in the future, the To Date is set to today instead.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dealer Submission From Date (`CB_BLK.P_CL_FROMDT`) | Optional | Date | 10 / DD/MM/RRRR | N/A | N/A | Invoice From Date entered | If provided: must not be in the future; must not be before Invoice From Date; must not exceed Dealer Submission To Date | Alerts per individual check; trigger aborts on failure |
| Dealer Submission To Date (`CB_BLK.P_CL_TODT`) | Auto-populated | Date | 10 / DD/MM/RRRR | N/A | Calculated as last day of month after Dealer Submission From Date (capped at today) | Dealer Submission From Date entered | Recalculated automatically after From Date is validated | N/A |

---

---

#### Requirement ID: BR-012

**Requirement Title:** Dealer Submission To Date Validation

**Business Description:**
When the user enters or modifies the Dealer Submission To Date, the system performs checks to ensure the date is logically valid and does not exceed six months from the Dealer Submission From Date. The To Date cannot be entered without a From Date, cannot be earlier than the From Date, cannot be in the future, and the date range must not exceed six months. The previously active error for a blank To Date has been commented out; if the field is left empty the trigger completes without error.

**Actors:** Dealer User

**Preconditions:**
- The Exchange / Loyalty Dealer Report screen is open.

**Main Flow:**

**Step 1 - Dealer Submission To Date validated on exit (when provided)**
If the user has entered a Dealer Submission To Date, the system applies the following checks in order: (1) if the Dealer Submission From Date is not yet filled, the user sees *"To date cannot be entered without entering From date"*, the To Date field is cleared, and the trigger aborts; (2) if the To Date is earlier than the From Date, the alert *"To Date cannot be lesser than From Date"* is shown and the trigger aborts; (3) if the From Date is greater than the To Date (reverse comparison), the alert *"From Date cannot be greater than To Date"* is shown and the trigger aborts; (4) if the To Date is after today, the alert *"To Date cannot be greater than Current Date"* is shown and the trigger aborts; (5) if the range exceeds six months, the alert *"Please give the date range of maximum Six month"* is shown and the trigger aborts.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| To Date requires From Date to be entered first | WHEN-VALIDATE-ITEM on CB_BLK.P_CL_TODT - check P_CL_FROMDT IS NULL | When the user leaves the Dealer Submission To Date field after entering a value | Prevents an end-date boundary without a corresponding start boundary | *"To date cannot be entered without entering From date"*; To Date cleared; trigger aborts |
| To Date must not be earlier than From Date | WHEN-VALIDATE-ITEM on CB_BLK.P_CL_TODT - P_CL_TODT < P_CL_FROMDT | When the user leaves the Dealer Submission To Date field | Ensures the range has a positive span | Alert *"To Date cannot be lesser than From Date"*; trigger aborts |
| From Date must not be greater than To Date | WHEN-VALIDATE-ITEM on CB_BLK.P_CL_TODT - P_CL_FROMDT > P_CL_TODT | When the user leaves the Dealer Submission To Date field | Catches the reverse comparison | Alert *"From Date cannot be greater than To Date"*; trigger aborts |
| To Date must not be in the future | WHEN-VALIDATE-ITEM on CB_BLK.P_CL_TODT - P_CL_TODT > current date | When the user leaves the Dealer Submission To Date field | Prevents querying data that has not yet occurred | Alert *"To Date cannot be greater than Current Date"*; trigger aborts |
| Date range must not exceed six months | WHEN-VALIDATE-ITEM on CB_BLK.P_CL_TODT - P_CL_TODT > ADD_MONTHS(P_CL_FROMDT,6)-1 | When the user leaves the Dealer Submission To Date field | Limits submission-date filter to a maximum six-month window | Alert *"Please give the date range of maximum Six month"*; trigger aborts |

*Business outcomes (errors, warnings, success, and status):*
- **BR-012-ES-01** - Dealer Submission To Date entered without a From Date - *"To date cannot be entered without entering From date"*; To Date cleared; trigger aborts.
- **BR-012-ES-02** - Dealer Submission To Date is earlier than From Date - alert *"To Date cannot be lesser than From Date"*; trigger aborts.
- **BR-012-ES-03** - Dealer Submission From Date is greater than To Date - alert *"From Date cannot be greater than To Date"*; trigger aborts.
- **BR-012-ES-04** - Dealer Submission To Date is after today - alert *"To Date cannot be greater than Current Date"*; trigger aborts.
- **BR-012-ES-05** - Dealer Submission date range exceeds six months - alert *"Please give the date range of maximum Six month"*; trigger aborts.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dealer Submission To Date (`CB_BLK.P_CL_TODT`) | Optional | Date | 10 / DD/MM/RRRR | N/A | N/A | Dealer Submission From Date entered | If provided: must not precede From Date; must not be in the future; range must not exceed 6 months | Alerts per individual check; trigger aborts on failure |
| Dealer Submission From Date (`CB_BLK.P_CL_FROMDT`) | Optional | Date | 10 / DD/MM/RRRR | N/A | N/A | N/A | Referenced during To Date validation | N/A - validated separately under BR-011 |

---

---

#### Requirement ID: BR-013

**Requirement Title:** Status Date (Accepted/Rejected/Clarification) Range Validation and To-Date Auto-Calculation

**Business Description:**
When the user enters an Accepted/Rejected/Clarification From Date, the system validates that it is not in the future, does not fall before the Invoice From Date, and does not exceed the corresponding To Date. If valid, the system automatically calculates and populates the To Date as the last day of the month following the From Date (capped at today if that date is in the future). This From Date is optional; if left blank no check fires. The previously active error for a blank From Date has been commented out.

**Actors:** Dealer User

**Preconditions:**
- The Exchange / Loyalty Dealer Report screen is open.
- An Invoice From Date has already been entered (used as the lower boundary for status date validation).

**Main Flow:**

**Step 1 - Status From Date validated on exit (when provided)**
If the user has entered a status From Date, the system checks: (1) if the date is after today, the alert *"From Date cannot be greater than Current Date"* is shown and the trigger aborts; (2) if the date is before the Invoice From Date, the alert *"Accepted/Rejected/Clarification Form Date cannot be less than Invoice From Date"* is shown and the trigger aborts; (3) if the date is after the status To Date, the alert *"From Date cannot be greater than To Date"* is shown and the trigger aborts.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Status From Date must not be in the future | WHEN-VALIDATE-ITEM on CB_BLK.P_STATUS_FROMDT - comparison to current date | When the user leaves the Status From Date field | Prevents use of a status date boundary that has not yet occurred | Alert *"From Date cannot be greater than Current Date"*; trigger aborts |
| Status From Date must not be before Invoice From Date | WHEN-VALIDATE-ITEM on CB_BLK.P_STATUS_FROMDT - P_STATUS_FROMDT < P_FROMDT | When the user leaves the Status From Date field | Ensures the status filter period does not start before the invoice period | Alert *"Accepted/Rejected/Clarification Form Date cannot be less than Invoice From Date"*; trigger aborts |
| Status From Date must not exceed Status To Date | WHEN-VALIDATE-ITEM on CB_BLK.P_STATUS_FROMDT - comparison to P_STATUS_TODT | When the user leaves the Status From Date field | Ensures the status date range is logically consistent | Alert *"From Date cannot be greater than To Date"*; trigger aborts |

*Business outcomes (errors, warnings, success, and status):*
- **BR-013-ES-01** - Status From Date is after today - alert *"From Date cannot be greater than Current Date"*; trigger aborts.
- **BR-013-ES-02** - Status From Date is before Invoice From Date - alert *"Accepted/Rejected/Clarification Form Date cannot be less than Invoice From Date"*; trigger aborts.
- **BR-013-ES-03** - Status From Date is after Status To Date - alert *"From Date cannot be greater than To Date"*; trigger aborts.

**Step 2 - Status To Date automatically calculated**
After the From Date passes all checks, the system calculates the Status To Date as the last day of the month following the Status From Date. If that calculated date would fall in the future, the To Date is set to today instead.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Accepted/Rejected/Clarification From Date (`CB_BLK.P_STATUS_FROMDT`) | Optional | Date | 10 / DD/MM/RRRR | N/A | N/A | Invoice From Date entered | If provided: must not be in the future; must not be before Invoice From Date; must not exceed Status To Date | Alerts per individual check; trigger aborts on failure |
| Accepted/Rejected/Clarification To Date (`CB_BLK.P_STATUS_TODT`) | Auto-populated | Date | 10 / DD/MM/RRRR | N/A | Calculated as last day of month after Status From Date (capped at today) | Status From Date entered | Recalculated automatically after From Date is validated | N/A |

---

#### Requirement ID: BR-014

**Requirement Title:** Status To Date (Accepted/Rejected/Clarification) Validation

**Business Description:**
When the user enters or modifies the Accepted/Rejected/Clarification To Date, the system applies the same set of date-range checks as the other To Date fields: the To Date cannot be entered without a corresponding From Date, cannot be earlier than the From Date, cannot be in the future, and the range must not exceed six months. If the To Date field is left blank, no error is raised (the "To Date can not be empty" message in this field has been commented out and is inactive).

**Actors:** Dealer User

**Preconditions:**
- The Exchange / Loyalty Dealer Report screen is open.

**Main Flow:**

**Step 1 - Status To Date validated on exit (when provided)**
If the user has entered a Status To Date, the system applies the following checks in order: (1) if the Status From Date is not filled, the user sees *"To date cannot be entered without entering From date"*, the To Date field is cleared, and the trigger aborts; (2) if the To Date is earlier than the From Date, the alert *"To Date cannot be lesser than From Date"* is shown and the trigger aborts; (3) if the From Date is greater than the To Date (reverse comparison), the alert *"From Date cannot be greater than To Date"* is shown and the trigger aborts; (4) if the To Date is after today, the alert *"To Date cannot be greater than Current Date"* is shown and the trigger aborts; (5) if the range exceeds six months, the alert *"Please give the date range of maximum Six month"* is shown and the trigger aborts.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Status To Date requires Status From Date to be entered first | WHEN-VALIDATE-ITEM on CB_BLK.P_STATUS_TODT - check P_STATUS_FROMDT IS NULL | When the user leaves the Status To Date field after entering a value | Prevents an end-date status filter without a corresponding start date | *"To date cannot be entered without entering From date"*; To Date cleared; trigger aborts |
| Status To Date must not be earlier than Status From Date | WHEN-VALIDATE-ITEM on CB_BLK.P_STATUS_TODT - P_STATUS_TODT < P_STATUS_FROMDT | When the user leaves the Status To Date field | Ensures the range has a positive span | Alert *"To Date cannot be lesser than From Date"*; trigger aborts |
| Status From Date must not be greater than Status To Date | WHEN-VALIDATE-ITEM on CB_BLK.P_STATUS_TODT - P_STATUS_FROMDT > P_STATUS_TODT | When the user leaves the Status To Date field | Catches the reverse comparison | Alert *"From Date cannot be greater than To Date"*; trigger aborts |
| Status To Date must not be in the future | WHEN-VALIDATE-ITEM on CB_BLK.P_STATUS_TODT - P_STATUS_TODT > current date | When the user leaves the Status To Date field | Prevents filtering on a status date that has not yet occurred | Alert *"To Date cannot be greater than Current Date"*; trigger aborts |
| Status date range must not exceed six months | WHEN-VALIDATE-ITEM on CB_BLK.P_STATUS_TODT - P_STATUS_TODT > ADD_MONTHS(P_STATUS_FROMDT,6)-1 | When the user leaves the Status To Date field | Limits the status date filter to a maximum six-month window | Alert *"Please give the date range of maximum Six month"*; trigger aborts |

*Business outcomes (errors, warnings, success, and status):*
- **BR-014-ES-01** - Status To Date entered without a Status From Date - *"To date cannot be entered without entering From date"*; To Date cleared; trigger aborts.
- **BR-014-ES-02** - Status To Date is earlier than Status From Date - alert *"To Date cannot be lesser than From Date"*; trigger aborts.
- **BR-014-ES-03** - Status From Date is greater than Status To Date - alert *"From Date cannot be greater than To Date"*; trigger aborts.
- **BR-014-ES-04** - Status To Date is after today - alert *"To Date cannot be greater than Current Date"*; trigger aborts.
- **BR-014-ES-05** - Status date range exceeds six months - alert *"Please give the date range of maximum Six month"*; trigger aborts.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Accepted/Rejected/Clarification To Date (`CB_BLK.P_STATUS_TODT`) | Optional | Date | 10 / DD/MM/RRRR | N/A | N/A | Status From Date entered | If provided: must not precede From Date; must not be in the future; range must not exceed 6 months | Alerts per individual check; trigger aborts on failure |
| Accepted/Rejected/Clarification From Date (`CB_BLK.P_STATUS_FROMDT`) | Optional | Date | 10 / DD/MM/RRRR | N/A | N/A | N/A | Referenced during To Date validation | N/A - validated separately under BR-013 |

---

---

#### Requirement ID: BR-015

**Requirement Title:** Status Field Validation

**Business Description:**
When the user moves away from the Status filter field, the system checks that a status value has been selected. If the field is empty, the user is shown an error message and must supply a valid status selection before continuing.

**Actors:** Dealer User

**Preconditions:**
- The Exchange / Loyalty Dealer Report screen is open.

**Main Flow:**

**Step 1 - Status field validated on exit**
As the user tabs away from the Status field, the system checks whether a status value has been chosen. If the field is blank, the user sees the error *"Status can not be empty"* and the cursor stays on the field until a selection is made.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Status is mandatory | WHEN-VALIDATE-ITEM on CB_BLK.P_STATUS_DESC - inline NULL check | When the user leaves the Status field | Ensures the report is always scoped to a specific claim status, preventing generation of an unfiltered result set | *"Status can not be empty"* is displayed; the trigger aborts and the cursor stays on the Status field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-015-ES-01** - Status field is empty when the user leaves it - *"Status can not be empty"*; the trigger aborts and focus remains on the Status field.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Status (`CB_BLK.P_STATUS_DESC`) | Mandatory | Text | 100 | Status lookup (LV_STATUS) | Status description | N/A | Must not be empty | *"Status can not be empty"* |
| Status Code (`CB_BLK.P_STATUS`) | Auto-populated | Text | 100 | N/A | Status code corresponding to description selected | N/A | System-set from LOV selection | N/A |

---

#### Requirement ID: BR-016

**Requirement Title:** Exchange/Loyalty Status Report Generation and Export to Excel

**Business Description:**
When the user submits the report request, the system validates the selected date range, translates the selected filters into a data query, retrieves the relevant exchange and loyalty claim records from the database, and exports the results as a CSV file that automatically opens in the browser for the user to save or view. The report includes full claim-level detail - vehicle information, customer details, claim status, document check results, bonus calculations, and Vahan verification data - covering all claims that match the dealer, outlet, invoice type, scheme, bonus model, and date criteria entered. The system generates a unique filename for each report run based on the current user and timestamp. Records are scoped to the claims matched by the dealer's own outlet code and group, or - when the outlet has been reorganised - to its pre-reorganisation identifiers. The date range for invoice dates is capped at a maximum of ten days at submission time.

**Actors:** Dealer User

**Preconditions:**
- All mandatory filter fields have been completed and validated: Dealer Details, Outlet Details, Scheme, Invoice Type, Bonus/Non Bonus Model, Invoice From Date, Invoice To Date, and Status.
- The invoice date range does not exceed ten days.

**Main Flow:**

**Step 1 - Unique output filename generated**
The system constructs a unique CSV filename using the current user's login identifier and the current date and time (format YYYYMMDDHH24MISS), ensuring each report run produces a distinct file.

**Step 2 - Status filter expanded for "Accepted" selection**
If the user selected the "Accepted" status, the system internally expands the status filter to also include the "Under Processing" status code alongside the Accepted code. This expansion happens silently before the query is built and is not visible to the user.

**Step 3 - Date range validated against ten-day maximum**
The system checks that the difference between the Invoice To Date and the Invoice From Date does not exceed ten days. If the range is greater than ten days, the user sees *"Date range can maximum be 10 days"* and the trigger aborts without generating a report.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Invoice date range must not exceed ten days | WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT - inline check P_TODT - P_FROMDT > 10 | When the user presses the Submit Report button | Limits the data volume of each report run to a manageable ten-day window to prevent excessively large output files | *"Date range can maximum be 10 days"* displayed; trigger aborts; no report is generated |

*Business outcomes (errors, warnings, success, and status):*
- **BR-016-ES-01** - Invoice date range exceeds ten days at submission - *"Date range can maximum be 10 days"*; trigger aborts; no report is generated.

**Step 4 - Bonus model filter code resolved**
Based on the Bonus/Non Bonus Model selection, the system resolves the internal filter code: "Bonus" maps to bonus model codes BMD and BMN; "Non Bonus" maps to NBM; "All" maps to all three codes. This resolved value is used in the WHERE clause of the data query.

**Step 5 - Dealer's legacy/reorganised identifiers retrieved**
The system queries the dealer location master to retrieve the legacy (pre-reorganisation) group, dealer map code, and outlet code for the selected dealer and outlet. These legacy codes are used to ensure that claims submitted under the outlet's previous identity are included in the report alongside claims under the current identity.

**Step 6 - Report query built and report file generated**
The system selects the appropriate report query based on the combination of Invoice Type and Scheme, and whether the outlet's current identifiers match its legacy identifiers:

- For the outlet whose current and legacy identifiers match (same-dealer path):
  - Invoice Type "C-Form" with Scheme "Exchange": the full Exchange claim detail query including all document check reasons, bonus breakdown (total, MSIL share, dealer share, stock liquidation bonus), Vahan verification fields, OTP declaration, and repurchase details.
  - Invoice Type "Direct Billing" with Scheme "Exchange": equivalent columns for direct-billing exchange claims.
  - Invoice Type "C-Form" without a scheme restriction (the third branch): an equivalent column set for C-Form claims.

- For outlets whose current identifiers differ from their legacy identifiers (different-dealer path):
  - Invoice Type "C-Form": the same column set run against the legacy outlet identifiers.
  - Invoice Type "Direct Billing": the equivalent column set for direct-billing under legacy identifiers.

The query is built as a dynamic SQL string, assigned to the internal query field, then passed to the report generation procedure.

*Procedures called:*
- **VIEW_EXCEL_REP** ([SP-001](#SP-001--VIEW_EXCEL_REP)) - VIEW_EXCEL_REP - receives the filename, the dynamic SQL query, and the column name; executes the query into an in-memory record group; writes each row of results to a server-side CSV file; reads the output server path from the configuration file; and opens the file in the user's browser. Raises a trigger failure with an error message if any step fails.
    * **Step 1** - Validate the input values.
    * **Step 2** - Retrieve the required business data.
    * **Step 3** - Apply business validations.
    * **Step 4** - Update the required records.
    * **Step 5** - Return the processing result.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Report generation and file write | VIEW_EXCEL_REP [SP-001] - exception handler catches any error | When the user presses the Submit Report button after all pre-checks pass | Ensures the report file is written to the server and made available to the user; any failure is surfaced immediately | Message *"Error  - "* followed by the Forms error code and error text is displayed; the trigger aborts |

*Business outcomes (errors, warnings, success, and status):*
- **BR-016-ES-02** - Report generation fails during file write or query execution - *"Error  - "* followed by the system error code and error text (`ERROR_CODE` concatenated with `ERROR_TEXT`); trigger aborts.
- **BR-016-IC-01** - The output filename for each run is constructed as `<user login ID>_<YYYYMMDDHH24MISS>.csv` - uniquely identifies each report run for audit and retrieval.

**Business Scenarios - How the report content differs by invoice type and scheme**

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Exchange, C-Form invoices (same dealer)** | Full column set including document-missing reasons for nine document types, bonus breakdown (total bonus, MSIL share, dealer share, stock liquidation bonus and share), Vahan verification fields, OTP declaration dates, repurchase details, and reversal/cancellation dates. Query filters to `INV_STATUS = 'I'`. |
| **Exchange, Direct Billing invoices (same dealer)** | Equivalent column set for direct-billing (non-C-Form) exchange claims. Query filters to `INV_STATUS = 'D'`. |
| **C-Form invoices, no scheme restriction (same dealer, third branch)** | Equivalent full column set applied without scheme=S restriction for C-Form claims. Query filters to `INV_STATUS = 'I'`. |
| **C-Form invoices (different dealer / legacy identifiers)** | Same column set but query uses the outlet's pre-reorganisation group, dealer map code, and outlet code. |
| **Direct Billing invoices (different dealer / legacy identifiers)** | Equivalent direct-billing columns but query uses the outlet's pre-reorganisation identifiers. |

**Alternative Flows:**
- **BR-016-AF-01** - (from Step 3) Invoice date range exceeds ten days at submission time: the system shows *"Date range can maximum be 10 days"* and aborts before building the query; no report file is created.
- **BR-016-AF-02** - (from Step 5) The filename includes spaces in the folder path: the system relocates the output file to the C drive root and shows the message *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."* before continuing to generate the report.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dealer Details (`CB_BLK.P_DELR_CD`) | Mandatory | Text | 500 | Dealer lookup (LV_DEALER) | Dealer code | N/A | Must not be empty (validated in BR-004) | N/A |
| Outlet Details (`CB_BLK.P_LOC_CD`) | Mandatory | Text | 500 | Outlet lookup (LV_LOC) | Outlet code | N/A | Must not be empty (validated in BR-005) | N/A |
| Scheme (`CB_BLK.P_SCHEME`) | Mandatory | List | 100 | N/A | Scheme type | N/A | Must not be empty (validated in BR-006) | N/A |
| Invoice Type (`CB_BLK.P_INV_TYPE`) | Mandatory | List | 100 | N/A | Invoice type | N/A | Must not be empty (validated in BR-007) | N/A |
| Bonus/Non Bonus Model (`CB_BLK.P_BONUS_YN`) | Mandatory | List | 100 | N/A | B / N / A | N/A | Must not be empty (validated in BR-008) | N/A |
| Invoice From Date (`CB_BLK.P_FROMDT`) | Mandatory | Date | 10 / DD/MM/RRRR | N/A | N/A | N/A | Validated in BR-009; range ≤ 10 days enforced at submission | *"Date range can maximum be 10 days"* |
| Invoice To Date (`CB_BLK.P_TODT`) | Mandatory | Date | 10 / DD/MM/RRRR | N/A | N/A | Invoice From Date | Validated in BR-010; range ≤ 10 days enforced at submission | *"Date range can maximum be 10 days"* |
| Dealer Submission From Date (`CB_BLK.P_CL_FROMDT`) | Optional | Date | 10 / DD/MM/RRRR | N/A | N/A | N/A | Validated in BR-011 | N/A |
| Dealer Submission To Date (`CB_BLK.P_CL_TODT`) | Optional | Date | 10 / DD/MM/RRRR | N/A | N/A | N/A | Validated in BR-012 | N/A |
| Accepted/Rejected/Clarification From Date (`CB_BLK.P_STATUS_FROMDT`) | Optional | Date | 10 / DD/MM/RRRR | N/A | N/A | N/A | Validated in BR-013 | N/A |
| Accepted/Rejected/Clarification To Date (`CB_BLK.P_STATUS_TODT`) | Optional | Date | 10 / DD/MM/RRRR | N/A | N/A | N/A | Validated in BR-014 | N/A |
| Status (`CB_BLK.P_STATUS_DESC`) | Mandatory | Text | 100 | Status lookup (LV_STATUS) | Status description | N/A | Validated in BR-015 | N/A |
| Status Code (`CB_BLK.P_STATUS`) | Auto-populated | Text | 100 | N/A | Status code used in query | N/A | Expanded to include "Under Processing" when "Accepted" is selected | N/A |
| Query Buffer (`CB_BLK.TEXT_ITEM810`) | Auto-populated | Text | 30000 | N/A | The dynamically built SQL query string | N/A | System-set; not user-editable; hidden field | N/A |
| Destination (`CB_BLK.P_DESTYPE`) | Read-only display | List | N/A | N/A | N/A | N/A | System-controlled; user cannot change | N/A |

---

---

#### Requirement ID: BR-017

**Requirement Title:** Form-Level Error Handling

**Business Description:**
When any system or database error occurs during use of the Exchange / Loyalty Dealer Report screen, the form intercepts the error and presents a user-friendly message in place of the raw Oracle Forms error. The active handling logic covers four categories of error: invalid date entry, date format errors, numeric-only field violations, an item-level validation failure, a concurrency conflict where another user has modified the record, and any unhandled SQL or database error. Errors that fall into the "no records found" or "end of records" categories are silently suppressed (no message shown).

**Business Description (inactive code note):** An earlier version of the error handler (now fully commented out) covered a broader set of Oracle Forms error codes and included a child-record constraint violation path. That code does not execute.

**Actors:** Dealer User

**Preconditions:**
- The Exchange / Loyalty Dealer Report screen is open.

**Main Flow:**

**Step 1 - Date validity error intercepted**
If the system detects an invalid date entry (Forms error code 50004), it displays the message *"Entered Date is not valid Date"* and aborts the triggering action.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Invalid date value | ON-ERROR (Form level) - check for error code 50004 | When any item raises an invalid-date error | Replaces the raw Oracle error with a clear, user-readable message | *"Entered Date is not valid Date"* displayed; trigger aborts |

**Step 2 - Date format error intercepted**
If the error code indicates an incorrect date format (Forms error codes 50025 or 50026), the system displays *"Enter the Date in the proper format (DD-MM-YYYY)"* and aborts the triggering action.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Date format error | ON-ERROR (Form level) - check for error codes 50025, 50026 | When any item raises a date-format error | Guides the user to enter dates in the correct format | *"Enter the Date in the proper format (DD-MM-YYYY)"* displayed; trigger aborts |

**Step 3 - Non-numeric input error intercepted**
If the error indicates that non-numeric characters were entered in a numeric field (Forms error codes 40209 or 50016), the system displays *"Characters/Special Characters are not allowed here, enter the numeric value"* and aborts.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Non-numeric input | ON-ERROR (Form level) - check for error codes 40209, 50016 | When a numeric field receives a non-numeric value | Clearly tells the user that only numeric values are accepted in that field | *"Characters/Special Characters are not allowed here, enter the numeric value"* displayed; trigger aborts |

**Step 4 - Item-level validation failure message displayed**
If the error is a standard item validation failure (Forms error code 40207), the system displays the raw Oracle error text for that item and aborts.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Item-level validation failure | ON-ERROR (Form level) - check for error code 40207 | When any item's own validation logic raises an error | Shows the specific error message associated with the item validation | The item's own error text (`errtxt`) displayed; trigger aborts |

**Step 5 - Child record constraint violation intercepted**
If the database reports a child-record constraint violation (DBMS error code -02292), the system invokes the standard error-raising routine to display a pre-configured business message for that constraint.

*Procedures called:*
- **GENERAL.RAISE_ERROR** ([SP-003](#SP-003--GENERAL.RAISE_ERROR)) - GENERAL.RAISE_ERROR - looks up and displays the pre-configured error message for the given error code, in this case the child-record integrity constraint message.
    * **Step 1** - Validate the input values.
    * **Step 2** - Retrieve the required business data.
    * **Step 3** - Apply business validations.
    * **Step 4** - Update the required records.
    * **Step 5** - Return the processing result.

**Step 6 - Concurrency conflict intercepted**
If the error indicates that another user has modified the record since it was queried (Forms error codes 40654, 40655, 40656, 40657, or 40659), the system displays *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*, rolls back the pending transaction, and aborts.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Record modified by another user | ON-ERROR (Form level) - check for error codes 40654-40659 | When a save attempt conflicts with another user's concurrent modification | Protects data integrity by preventing a stale overwrite | *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"* displayed; rollback performed; trigger aborts |

**Step 7 - Unhandled SQL error intercepted**
If a non-zero SQL error code remains after the specific checks above, the system displays the SQLERRM text (the database's own error description), rolls back the pending transaction, and aborts.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Unhandled SQL error | ON-ERROR (Form level) - check for sqlcode <> 0 | When any unhandled database error occurs | Ensures the user always sees a message rather than a silent failure, and that the transaction is safely rolled back | SQLERRM text displayed; rollback performed; trigger aborts |

**Step 8 - "No records" errors silently suppressed**
If the error code is 40401 or 40405 (no records found or end of records), the system executes a null statement - no message is shown and the form continues normally.

*Business outcomes (errors, warnings, success, and status):*
- **BR-017-ES-01** - Invalid date value entered - *"Entered Date is not valid Date"*; trigger aborts.
- **BR-017-ES-02** - Date format is incorrect - *"Enter the Date in the proper format (DD-MM-YYYY)"*; trigger aborts.
- **BR-017-ES-03** - Non-numeric value entered in numeric field - *"Characters/Special Characters are not allowed here, enter the numeric value"*; trigger aborts.
- **BR-017-ES-04** - Item-level validation failure - the item's own error text (`errtxt`) displayed; trigger aborts.
- **BR-017-ES-05** - Concurrency conflict - *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*; rollback; trigger aborts.
- **BR-017-ES-06** - Unhandled SQL error - SQLERRM text displayed; rollback; trigger aborts.

---

---

#### Requirement ID: BR-018

**Requirement Title:** Form-Level Message Interception

**Business Description:**
When the form generates a standard Oracle Forms informational or advisory message (specifically for error codes 40209 or 40207), the active message trigger intercepts the message and re-displays it using the standard formatted display - including the error type prefix, code, and text - rather than the default Oracle Forms message presentation.

**Actors:** Dealer User

**Preconditions:**
- The Exchange / Loyalty Dealer Report screen is open.

**Main Flow:**

**Step 1 - Message intercepted and reformatted**
When the form generates a message with code 40209 or 40207, the system formats it as the error type code, a dash, the numeric error code, a colon, and the error text, then displays it using the standard display routine before raising a trigger failure.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-002](#SP-002--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - receives the formatted error type, code, and text string and displays it as an error-level message on the screen.
    * **Step 1** - Validate the input values.
    * **Step 2** - Retrieve the required business data.
    * **Step 3** - Apply business validations.
    * **Step 4** - Update the required records.
    * **Step 5** - Return the processing result.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Message code 40209 or 40207 requires formatted display | ON-MESSAGE (Form level) - check for error codes 40209, 40207 | When the form generates an informational message with those codes | Ensures consistent, readable error presentation rather than raw Oracle Forms output | Formatted message displayed; trigger aborts |

---

---

#### Requirement ID: BR-019

**Requirement Title:** Excel Report File Processing and ASCII Character Cleanup

**Business Description:**
The form includes a procedure that reads a generated report file line by line, removes any lines beginning with a form-feed character, writes the clean content to a new output file, and then opens the cleaned file in the user's browser for viewing. This procedure supports post-processing of a report output file to remove printer control characters before delivery to the user.

**Note (inactive caller):** The VALIDATE_CN_MAIN and CHECK_BEFORE_DELETE program units in this form are commented out and do not execute. The POPULATE_ERRORS program unit is an active package-spec declaration that exposes an in-memory code table, but it is not invoked from any active trigger in this form.

**Actors:** Dealer User

**Preconditions:**
- A report CSV file has been written to the server path by the report generation step.

**Main Flow:**

**Step 1 - Input file opened and cleaned output file created**
The procedure opens the source report file from the server reports folder, then opens a new file for writing the cleaned content.

**Step 2 - Lines written to output file, form-feed lines excluded**
The procedure reads each line from the source file. Any line beginning with the ASCII form-feed character (CHR(12)) is skipped; all other lines are written to the output file.

**Step 3 - Files closed and output displayed in browser**
After all lines are processed, both files are closed. The output file is opened in the user's browser under the `/printer/` path using the web document display utility.

*Procedures called:*
- **WEB.SHOW_DOCUMENT** - WEB.SHOW_DOCUMENT (attached WEBUTIL library) - opens the specified file path in the user's browser window. (Note: WEB.SHOW_DOCUMENT is not catalogued in Section 21.1 and is therefore not linked by SP-xxx ID; it is an attached library call.)

*Business outcomes (errors, warnings, success, and status):*
- **BR-019-ES-01** - Any exception during file read or write - the system catches `WHEN OTHERS` and displays the message *"Exception"* followed by the SQL error code and SQLERRM text (dynamic concatenation of `SQLCODE` and `SQLERRM`); no browser display occurs.

---

---

#### Requirement ID: BR-020

**Requirement Title:** Inactive Program Units (Non-Executing Code)

**Business Description:**
This form contains two program units that are commented out and do not execute under any circumstances. They are documented here for completeness only and have no effect on the form's operational behaviour.

- **VALIDATE_CN_MAIN** (COMMENTED OUT / INACTIVE - does not execute): This procedure was intended to validate mandatory fields on the main screen, including plate number, model year, test drive date, and odometer readings, for what appears to be a test drive module. It does not belong to the exchange/loyalty domain and is entirely inactive.

- **CHECK_BEFORE_DELETE** (COMMENTED OUT / INACTIVE - does not execute): This procedure contained a query to count child records in an enquiry table and prevent deletion if children exist. The procedure body is `NULL;` and the original logic is commented out. It does not execute.

**Note:** **POPULATE_ERRORS** is an active form program unit whose body declares a package containing an in-memory PL/SQL table variable (`pk_plsql_table.code_tab`). It is not called from any active trigger in this form; the package variable is declared but not used in any currently executing path.

**Actors:** N/A (no active execution)

**Preconditions:**
- N/A

**Main Flow:**

N/A - neither program unit executes.

---


---



---



---

---

## 5. Business Rules Catalogue

| Rule ID | Rule Name | Rule Type | Business Requirement ID | Condition | Action | Business Impact |
| ------- | --------- | --------- | ----------------------- | --------- | ------ | --------------- |
| BRC-001 | Dealer Details Mandatory | Validation | BR-004 | The Dealer Details field is left empty when the user moves to the next field | Block navigation and show *"Dealer Details can not be empty"* | Prevents report submission without a dealer scope, which would produce meaningless or overly broad results |
| BRC-002 | Outlet Details Mandatory | Validation | BR-005 | The Outlet Details field is left empty when the user moves to the next field | Block navigation and show *"Outlet Details can not be empty"* | Ensures every report is scoped to a specific outlet for meaningful analysis |
| BRC-003 | Scheme Mandatory | Validation | BR-006 | The Scheme field is left empty when the user moves to the next field | Block navigation and show *"Scheme can not be empty"* | Prevents generation of an unscoped or ambiguous scheme report |
| BRC-004 | Invoice Type Mandatory | Validation | BR-007 | The Invoice Type field is left empty when the user moves to the next field | Block navigation and show *"Invoice Type can not be empty"* | Ensures the report is scoped to the correct billing category |
| BRC-005 | Bonus/Non Bonus Model Mandatory | Validation | BR-008 | The Bonus/Non Bonus Model field is left empty when the user moves to the next field | Block navigation and show *"Bonus/Non Bonus Model can not be empty"* | Ensures the report filters to the intended bonus model category |
| BRC-006 | Invoice From Date Mandatory | Validation | BR-009 | The Invoice From Date field is left empty when the user moves to the next field | Block navigation and show *"From Date can not be empty"* | Ensures the report always has a start boundary for the invoice date range |
| BRC-007 | Invoice From Date Must Not Be in the Future | Validation | BR-009 | The Invoice From Date entered is after today's date | Show alert *"From Date cannot be greater than Current Date"* and block navigation | Prevents selection of an invoice date range that has not yet occurred |
| BRC-008 | Invoice From Date Must Not Exceed Invoice To Date | Validation | BR-009 | The Invoice From Date entered is greater than the Invoice To Date | Show alert *"From Date cannot be greater than To Date"* and block navigation | Ensures the invoice date range is logically consistent |
| BRC-009 | Invoice To Date Requires From Date | Validation | BR-010 | A value is entered in the Invoice To Date field but the Invoice From Date has not been entered | Show *"To date cannot be entered without entering From date"*, clear the To Date field, and block navigation | Prevents a date range where the end is defined but the start is not |
| BRC-010 | Invoice To Date Must Not Be Earlier Than From Date | Validation | BR-010 | The Invoice To Date is earlier than the Invoice From Date | Show alert *"To Date cannot be lesser than From Date"* and block navigation | Ensures the invoice date range has a positive span |
| BRC-011 | Invoice To Date Must Not Be in the Future | Validation | BR-010 | The Invoice To Date entered is after today's date | Show alert *"To Date cannot be greater than Current Date"* and block navigation | Prevents querying invoice data that does not yet exist |
| BRC-012 | Invoice Date Range Must Not Exceed Six Months | Validation | BR-010 | The difference between Invoice To Date and Invoice From Date exceeds six months | Show alert *"Please give the date range of maximum Six month"* and block navigation | Limits the report data volume to a policy-defined maximum date range |
| BRC-013 | Dealer Submission From Date Must Not Be in the Future | Validation | BR-011 | The Dealer Submission From Date is after today's date | Show alert *"From Date cannot be greater than Current Date"* and block navigation | Prevents use of a submission date boundary that has not occurred |
| BRC-014 | Dealer Submission From Date Must Not Be Before Invoice From Date | Validation | BR-011 | The Dealer Submission From Date is earlier than the Invoice From Date | Show alert *"Dealer Submission From Date cannot be less than Invoice From Date"* and block navigation | Ensures the submission period does not start before the invoice period |
| BRC-015 | Dealer Submission From Date Must Not Exceed Dealer Submission To Date | Validation | BR-011 | The Dealer Submission From Date is greater than the Dealer Submission To Date | Show alert *"From Date cannot be greater than To Date"* and block navigation | Ensures the dealer submission date range is logically consistent |
| BRC-016 | Dealer Submission To Date Requires From Date | Validation | BR-012 | A value is entered in the Dealer Submission To Date field but the Dealer Submission From Date has not been entered | Show *"To date cannot be entered without entering From date"*, clear the To Date field, and block navigation | Prevents a date range where the end is defined but the start is not |
| BRC-017 | Dealer Submission To Date Must Not Be Earlier Than From Date | Validation | BR-012 | The Dealer Submission To Date is earlier than the Dealer Submission From Date | Show alert *"To Date cannot be lesser than From Date"* and block navigation | Ensures the dealer submission date range has a positive span |
| BRC-018 | Dealer Submission To Date Must Not Be in the Future | Validation | BR-012 | The Dealer Submission To Date is after today's date | Show alert *"To Date cannot be greater than Current Date"* and block navigation | Prevents querying submission data that does not yet exist |
| BRC-019 | Dealer Submission Date Range Must Not Exceed Six Months | Validation | BR-012 | The difference between Dealer Submission To Date and Dealer Submission From Date exceeds six months | Show alert *"Please give the date range of maximum Six month"* and block navigation | Limits the dealer submission date filter to a maximum six-month window |
| BRC-020 | Status From Date Must Not Be in the Future | Validation | BR-013 | The Accepted/Rejected/Clarification From Date is after today's date | Show alert *"From Date cannot be greater than Current Date"* and block navigation | Prevents use of a status date boundary that has not yet occurred |
| BRC-021 | Status From Date Must Not Be Before Invoice From Date | Validation | BR-013 | The Accepted/Rejected/Clarification From Date is before the Invoice From Date | Show alert *"Accepted/Rejected/Clarification Form Date cannot be less than Invoice From Date"* and block navigation | Ensures the status filter period does not start before the invoice period |
| BRC-022 | Status From Date Must Not Exceed Status To Date | Validation | BR-013 | The Accepted/Rejected/Clarification From Date is greater than the corresponding To Date | Show alert *"From Date cannot be greater than To Date"* and block navigation | Ensures the status date range is logically consistent |
| BRC-023 | Status To Date Requires Status From Date | Validation | BR-014 | A value is entered in the Status To Date field but the Status From Date has not been entered | Show *"To date cannot be entered without entering From date"*, clear the To Date field, and block navigation | Prevents a status date range where the end is defined but the start is not |
| BRC-024 | Status To Date Must Not Be Earlier Than Status From Date | Validation | BR-014 | The Status To Date is earlier than the Status From Date | Show alert *"To Date cannot be lesser than From Date"* and block navigation | Ensures the status date range has a positive span |
| BRC-025 | Status To Date Must Not Be in the Future | Validation | BR-014 | The Status To Date is after today's date | Show alert *"To Date cannot be greater than Current Date"* and block navigation | Prevents querying status data that does not yet exist |
| BRC-026 | Status Date Range Must Not Exceed Six Months | Validation | BR-014 | The difference between Status To Date and Status From Date exceeds six months | Show alert *"Please give the date range of maximum Six month"* and block navigation | Limits the status date filter to a maximum six-month window |
| BRC-027 | Status Mandatory | Validation | BR-015 | The Status field is left empty when the user moves to the next field | Block navigation and show *"Status can not be empty"* | Ensures every report is scoped to a specific claim status |
| BRC-028 | Invoice Date Range Capped at Ten Days at Submission | Validation | BR-016 | At report submission, the difference between Invoice To Date and Invoice From Date is greater than ten days | Block report generation and show *"Date range can maximum be 10 days"* | Prevents excessively large report output files that would degrade performance |
| BRC-029 | Accepted Status Expanded to Include Under-Processing | Derivation | BR-016 | The user selects the "Accepted" claim status | The system internally appends the "Under Processing" status code to the filter before building the query | Ensures that claims still being processed alongside accepted claims are included in the output, giving a complete accepted-category view |
| BRC-030 | Bonus Model Filter Resolved to Internal Codes | Derivation | BR-016 | The user selects Bonus, Non Bonus, or All for the Bonus/Non Bonus Model filter | Bonus maps to BMD and BMN; Non Bonus maps to NBM; All maps to BMD, BMN, and NBM | Ensures the query correctly filters to the intended bonus model categories as defined in the claim category master |
| BRC-031 | Legacy Dealer Identifiers Used for Reorganised Outlets | Derivation | BR-016 | The outlet's current group, dealer map code, or outlet code differs from its pre-reorganisation identifiers | The query uses the pre-reorganisation identifiers to include historical claims filed under the previous outlet identity | Prevents missing claims that were submitted when the outlet operated under different codes, ensuring report completeness for reorganised dealers |
| BRC-032 | Invalid Date Entry Replaced With Friendly Message | Validation | BR-017 | The system detects an invalid date value (error code 50004) | Display *"Entered Date is not valid Date"* and block the triggering action | Replaces raw Oracle error codes with clear user guidance |
| BRC-033 | Date Format Error Replaced With Friendly Message | Validation | BR-017 | The system detects a date format error (error codes 50025 or 50026) | Display *"Enter the Date in the proper format (DD-MM-YYYY)"* and block the triggering action | Guides the user to the correct date entry format |
| BRC-034 | Non-Numeric Input Replaced With Friendly Message | Validation | BR-017 | A non-numeric or special character is entered in a numeric field (error codes 40209 or 50016) | Display *"Characters/Special Characters are not allowed here, enter the numeric value"* and block the triggering action | Clearly instructs the user that the field accepts only numeric values |
| BRC-035 | Concurrency Conflict Rolled Back With Friendly Message | Validation | BR-017 | Another user has modified the record since it was last queried (error codes 40654-40659) | Display *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*, roll back the transaction, and block the triggering action | Protects data integrity by preventing a stale-data overwrite |

**Total Business Rules Identified: 35**

---

## 6. Data Requirements

*This section covers the data entities referenced by the Exchange/Loyalty Dealer Report form, the filter fields captured on screen, the reference data used in lookups, and the lifecycle of report filter state within a session.*

### 6.1 Business Entities and Relationships

*The form does not maintain or persist its own data records; it reads from exchange/loyalty claim and related master data to produce a report output. The primary entities read by the form are the loyalty/exchange claim table, the dealer location master, and the invoice and order tables.*

#### Exchange/Loyalty Claim - MULDMS.SD_LOYLTY_EXCH_CLAIM

The exchange and loyalty claim record is the central entity reported on by this form. It holds the claim header (scheme type, claim status, submission date, approval/rejection date, document status, bonus payout figures), the old-car details (chassis, registration, model, age), the new-car invoice reference, and the document-check indicator codes for each required document type. The form reads this entity exclusively via the dynamically generated report query triggered by the Submit button.

#### Dealer Location Master - AM_DEALER_LOC / MULDMS.AM_DEALER_LOC

The dealer location master records the dealer's current and pre-reorganisation identifiers (group, dealer map code, outlet code) as well as region code, state, city, and dealer name. The form reads this entity to resolve the legacy identifiers for the selected outlet, and also joins to it in the report query to obtain dealer name, region, state, and city for each claim row.

#### Invoice Header - MULDMS.SH_INVOICE

The invoice header holds the new-car invoice details linked to each claim: invoice number, invoice date, model and variant codes, chassis and engine numbers, VIN, sales type, customer name, POC relation, and RVSF details. The form reads this entity in the report query to supply the invoice-level columns in the report output.

#### Order Book - MULDMS.SH_ORDBOOK

The order book holds the order record referenced by the invoice. The form joins to this entity in the report query to link invoice records back to the originating order.

#### Trade-In Vehicle Evaluation - MULDMS.SH_TV_EVAL / SH_TV_EVAL

The trade-in vehicle evaluation record holds old-car details captured at point of purchase and Vahan verification fields: registration date, VIN, owner name, father/husband name, state and city of registration, model variant, colour, fuel type, manufacturing month/year, emission standard, commercial flag, RC status, road tax status, body type, PUCC expiry, and financer name. The form reads this entity in the report query to populate the Vahan verification columns.

#### Vahan Check Detail - DMS_VAHAN_CHECK_DTL

The Vahan check detail table holds results of third-party vehicle history checks for new cars: new car customer name, father/husband name, and the date of Vahan check creation. The form reads this entity in the report query for certain Vahan-verified fields on C-Form invoice claims.

#### Invoice Charge - SD_INV_CHARGES

The invoice charge table records additional charges against an invoice by charge type. The form reads this entity in the report query to calculate the dealer's exchange charge contribution (charge type EXB).

#### Entity Relationships

The Exchange/Loyalty Claim is the root entity of the report. It is joined to the Dealer Location Master via dealer and outlet codes, to the Invoice Header via invoice number and outlet identifiers, and to the Order Book via order number. The Invoice Header links to the Trade-In Vehicle Evaluation and the Vahan Check Detail via the POC buying identifier and VIN. Invoice charges are linked to the Invoice Header via invoice number and outlet identifiers.

```
MULDMS.SD_LOYLTY_EXCH_CLAIM (Exchange/Loyalty Claim)
        ├── AM_DEALER_LOC (Dealer Location Master)        <- joined on dealer_map_cd + loc_cd
        ├── MULDMS.SH_INVOICE (Invoice Header)            <- joined on inv_num + dealer + loc + group
        │       ├── MULDMS.SH_ORDBOOK (Order Book)       <- joined on order_num + dealer + loc
        │       ├── SH_TV_EVAL (Trade-In Evaluation)      <- joined on poc_buy_id
        │       ├── DMS_VAHAN_CHECK_DTL (Vahan Check)    <- joined on poc_buy_id + vin
        │       └── SD_INV_CHARGES (Invoice Charges)     <- joined on inv_num + dealer + loc + comp
        └── (GM_MOD, GM_VAR, GM_STATE, GM_CITY, AM_LIST, SM_DMSPOC_MAKE_MODEL_MAS)
                                                          <- dimension lookups in report SELECT
```

### 6.2 Data Capture Requirements

*The form captures report filter parameters entered by the user on the main screen. No data is persisted; all inputs are session-level filter parameters used to build the report query.*

#### Report Filter Parameters (Dealer User - report request)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Dealer Details (`P_DELR_CD`) | Yes | The dealer code selected from the dealer lookup list, identifying the dealership whose claims are to be reported. | Must not be empty. Selected from the Dealer Details lookup (LV_DEALER). |
| Outlet Description (`P_LOC_DESC`) | Auto-Populated | The display description of the selected outlet, automatically populated when an outlet is selected from the lookup. | System-set; not directly user-editable. |
| Outlet Details (`P_LOC_CD`) | Yes | The outlet code selected from the outlet lookup list, identifying the specific dealership location to include in the report. | Must not be empty. Selected from the Outlet Details lookup (LV_LOC). |
| Scheme (`P_SCHEME`) | Yes | The scheme type (e.g. Exchange or Loyalty) for which claims are to be reported. Chosen from a drop-down list. | Must not be empty. |
| Invoice Type (`P_INV_TYPE`) | Yes | The billing type of invoices to include - C-Form or Direct Billing. Chosen from a drop-down list. | Must not be empty. |
| Bonus/Non Bonus Model (`P_BONUS_YN`) | Yes | Filters claims by bonus model category: Bonus only, Non-Bonus only, or All. Chosen from a drop-down list. | Must not be empty. Bonus maps to BMD/BMN; Non Bonus to NBM; All to all three. |
| Invoice From Date (`P_FROMDT`) | Yes | The start of the invoice date range for which claims are to be retrieved. Entered in DD/MM/RRRR format. | Must not be empty; must not be in the future; must not exceed Invoice To Date; at submission time the range must not exceed 10 days. |
| Invoice To Date (`P_TODT`) | Yes | The end of the invoice date range. Auto-calculated as From Date + 9 days (capped at today) after From Date is entered; may be adjusted by the user. | Must not precede From Date; must not be in the future; date range must not exceed 6 months at validation time; must not exceed 10 days at submission time. |
| Dealer Submission From Date (`P_CL_FROMDT`) | No | Optional start boundary for the dealer's claim submission date filter. If provided, limits the report to claims submitted from this date onwards. | If provided: must not be in the future; must not be before Invoice From Date; must not exceed Dealer Submission To Date. |
| Dealer Submission To Date (`P_CL_TODT`) | No | Optional end boundary for the dealer's claim submission date filter. Auto-calculated as last day of month after Dealer Submission From Date (capped at today) when From Date is entered. | If provided: must not precede Dealer Submission From Date; must not be in the future; range must not exceed 6 months. |
| Accepted/Rejected/Clarification From Date (`P_STATUS_FROMDT`) | No | Optional start boundary for the claim status change date filter (approval, rejection, or clarification date). | If provided: must not be in the future; must not be before Invoice From Date; must not exceed Status To Date. |
| Accepted/Rejected/Clarification To Date (`P_STATUS_TODT`) | No | Optional end boundary for the claim status change date filter. Auto-calculated as last day of month after Status From Date (capped at today) when From Date is entered. | If provided: must not precede Status From Date; must not be in the future; range must not exceed 6 months. |
| Status (`P_STATUS_DESC`) | Yes | The claim status to filter on (e.g. Accepted, Rejected, Under Clarification). Selected from the Status lookup (LV_STATUS). | Must not be empty. When "Accepted" is selected, the system internally expands the filter to also include "Under Processing" claims. |
| Status Code (`P_STATUS`) | Auto-Populated | The internal status code corresponding to the selected status description. Automatically populated from the LOV and potentially expanded at submission. | System-set. |
| Destination (`P_DESTYPE`) | Auto-Populated | The report output destination type. System-controlled; user cannot modify. | System-set; not editable. |

#### Session / Internal Fields

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Report Description (`CB_BLK.REPORT_DESC`) | Auto-Populated | Display label showing the report title "Exchange/Loyalty Status Report". Reset each time the form is cleared. | System-set only; not user-editable. |
| Copyright Notice (`CB_BLK.COPY_RIGHT`) | Auto-Populated | The standard copyright declaration text displayed at the bottom of the screen. Populated from the copyright function when the form is cleared or first loaded. | System-set only; not user-editable. |
| Query Buffer (`CB_BLK.TEXT_ITEM810`) | Auto-Populated | A hidden internal field that holds the dynamically built SQL query string before it is passed to the report generation procedure. | System-set only; not visible to the user. |
| Application Logging Flag (`GLOBAL.APP_LOG`) | Auto-Populated | Session global indicating whether application-level performance timing is enabled. Checked at form open to decide whether to start a timer. | System-controlled; not user-editable. |

### 6.3 Reference Data

*Lists the master and configuration data used by the form for lookups and report filtering.*

| Reference Data | Business Purpose | Used When |
| :--- | :--- | :--- |
| Dealer Lookup (LV_DEALER / RG_DEALER) | Provides a searchable list of available dealers (city, dealer name, dealer code, group, map code) including an "ALL" option. Allows the user to identify and select the target dealer for the report. | When the user activates the Dealer Details lookup field |
| Outlet Lookup (LV_LOC / RG_LOC) | Provides a searchable list of outlets (outlet code, description, dealer code, for-code) including an "ALL" option. Allows the user to narrow the report to a specific outlet. | When the user activates the Outlet Details lookup field |
| Status Lookup (LV_STATUS / RG_STATUS) | Provides the list of valid claim status values (description and code) drawn from the claims status master, including an "ALL" option. | When the user activates the Status lookup field |
| Dealer Location Master (AM_DEALER_LOC) | Used to resolve the pre-reorganisation (legacy) group, dealer map code, and outlet code for the selected dealer when generating the report query, ensuring historical claims are included. | When the Submit button is pressed |
| Claim Status Descriptions (MULDMS.AM_LIST - list EXCH_LYL_STATUS) | Provides the user-readable status descriptions for claim status codes displayed in the report output. | In the report query, to decode claim status codes in each output row |
| Claim Category Descriptions (MULDMS.AM_LIST - list CLAIM_CATEG) | Provides readable claim category descriptions for the claim category codes in each claim row. | In the report query |
| Sales Type Descriptions (MULDMS.AM_LIST - list SALES_TYPE) | Provides readable sales type descriptions. | In the report query |
| Relation Descriptions (MULDMS.AM_LIST - list LOYALTY_RELATION / POC_RELATION) | Provides the relationship type description (e.g. Self, Spouse) linked to the POC relation code on the claim. | In the report query |
| Channel Descriptions (MULDMS.AM_LIST - list USER_CHANNEL_TYPE) | Provides readable channel type descriptions for the channel code on the dealer location record. | In the report query |
| Document Reason Descriptions (SF_GET_EXCH_LYL_REMARKS function - codes NCINV_REASON, NCINS_REASON, OCRC_REASON, OCINS_REASON, IDPR_REASON, RLPR_REASON, CUACK_REASON, PUAGR_REASON, CUSPR_REASON) | Provides readable reason descriptions for each of nine document check indicator codes in the claim, distinguishing Document Missing from OK or specific shortfall reasons. | In the report query for each document type column |
| Vehicle Model Master (MULDMS.GM_MOD) | Provides the model description for new car model codes. | In the report query |
| Vehicle Variant Master (MULDMS.GM_VAR / MULDMS.SM_DMSPOC_MAKE_MODEL_MAS) | Provides variant codes, variant descriptions, and old-car model descriptions. | In the report query |
| State Master (MULDMS.GM_STATE) | Provides state descriptions for dealer state codes. | In the report query |
| City Master (MULDMS.GM_CITY) | Provides city descriptions for dealer city codes. | In the report query |
| Excel Output Path Configuration (`/reports/DMS/excelpath.txt`) | A text file on the report server that contains the URL path prefix used to build the browser-accessible URL for the generated CSV file. | When the report generation procedure constructs the download link for the output file |

### 6.4 Data Lifecycle

*Describes how the report filter state is created, modified, and cleared within a user session. This form does not create, update, or delete database records - it reads data to produce a report output.*

**Creation**

- Report filter parameters are entered by the user on the screen each time they wish to run a report. No parameters are pre-loaded from a saved session; each form open starts with an empty filter set.
- The report description and copyright notice are set automatically when the form is cleared (via the form-clear action), not on initial open.

**Updates**

- The user may change any filter field value at any time before pressing the Submit Report button. Each field is validated independently when the user leaves it.
- The Invoice To Date is automatically recalculated whenever the Invoice From Date is changed and passes validation.
- The Dealer Submission To Date is automatically recalculated whenever the Dealer Submission From Date is changed and passes validation.
- The Accepted/Rejected/Clarification To Date is automatically recalculated whenever the corresponding From Date is changed and passes validation.
- The Status Code internal field is expanded (to include Under Processing) when the user selects the Accepted status.

**Save and Commit**

- This form does not save or commit data to the database. The Submit Report button triggers a report generation action (reading from the database and writing to a server file) but performs no INSERT, UPDATE, or COMMIT.
- The KEY-COMMIT trigger is present but is inactive (set to `NULL;`) - no save action is possible from this form.

**Retention and Audit**

- Report output files are written to the server reports folder under the path `/iashome/ias/reports/printer/` using a filename that includes the user's login ID and a timestamp. The form does not manage the retention or deletion of these files after generation.
- The application session is registered at form open using DBMS_APPLICATION_INFO, recording the module name for the session in the Oracle session monitor. This registration is cleared on form exit.

---

### 6.5 Excel Output Columns

Excel download columns produced by this form, with when each Excel is produced (report / principal path), filters that limit which rows are included, and the database source for each value. Column sets vary by export path (for example app_id, principal, and enquiry-date mode); the rows below are evidenced layouts, not a guaranteed list for every combination. Blank Table/Database means the physical column was not proven in source.

| # | What the user selects on screen | Excel column name | When this Excel is produced | Table name | Database column | Logic |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | Zone |  | AM_DEALER_LOC | REGION_CD | First character of the dealer region code (SUBSTR(am.region_cd,1,1)) identifies the zone in the exchange/loyalty claim export. |
| 2 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | Dealer Code For Code |  | AM_DEALER_LOC | MUL_DEALER_CD | Shows the Dealer Code For Code included in this Excel export. |
| 3 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | Dealer Name |  | AM_DEALER_LOC | DEALER_NAME | Dealer name from the dealer location master, with embedded commas replaced by spaces. |
| 4 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | Dealer State |  | GM_STATE | STATE_DESC | Shows the Dealer State taken from the enquiry's related records. |
| 5 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | Customer Name(POC/Vehicle Master) |  | SD_LOYLTY_EXCH_CLAIM | OLD_CAR_CUST_NAME | Name of the customer from the exchange/loyalty claim record (old car customer), with embedded commas replaced. |
| 6 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | Old Car Model |  | SM_DMSPOC_MAKE_MODEL_MAS | MODEL_DESC | Old car model description looked up from the DMS POC make/model master using SD.OLD_CAR_MAKE and SD.OLD_CAR_MODEL as keys. |
| 7 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | Old Car Chassis No |  | SD_LOYLTY_EXCH_CLAIM | OLD_CAR_CHASSIS | Chassis number of the old car submitted with the exchange/loyalty claim. |
| 8 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | New Car Invoice No |  | SD_LOYLTY_EXCH_CLAIM | INV_NUM | New car invoice number recorded on the exchange/loyalty claim record. |
| 9 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | New Car Invoice Date |  | SD_LOYLTY_EXCH_CLAIM | INV_DATE | Invoice date of the new car recorded on the exchange/loyalty claim record. |
| 10 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | New Car Model |  | GM_MOD | MODEL_DESC | New car model description looked up from the model master (GM_MOD) using sd.inv_model as the key. |
| 11 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | New Car SubModel Code |  | GM_VAR | VARIANT_CD | New car sub-model (variant) code looked up from the variant master (GM_VAR) using sd.inv_sub_model as the key. |
| 12 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | New Car Vin |  | SH_INVOICE | VIN | VIN of the new car from the invoice record (sh.vin for C-Form; sd.inv_vin for Direct Billing branch). |
| 13 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | New Car Owner(DMS) |  | SD_LOYLTY_EXCH_CLAIM | INV_CUST_NAME | New car customer name from the exchange/loyalty claim record, with embedded commas and line-feed characters replaced. |
| 14 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | Relation |  | AM_LIST | LIST_DESC | Relationship description between old and new car owners, looked up from AM_LIST using list name LOYALTY_RELATION or POC_RELATION (based on claim type) and the POC/old-car relation code. |
| 15 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | Status |  | AM_LIST | LIST_DESC | Claim status description looked up from AM_LIST using list name EXCH_LYL_STATUS and sd.claim_status as the code. |
| 16 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | Dealer Submission Date |  | SD_LOYLTY_EXCH_CLAIM | CLAIM_SUBMISSION_DATE | Date on which the dealer submitted the exchange/loyalty claim to MSIL. |
| 17 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | MSIL Approval / Rejection Date |  | SD_LOYLTY_EXCH_CLAIM | APPROVAL_DATE | Date on which MSIL approved or rejected the claim (sd.approval_date for C-Form; sd.claim_status_date for Direct Billing/Scrappage branch). |
| 18 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | Amount Reimbursed By MSIL |  | SD_LOYLTY_EXCH_CLAIM | MSIL_PAYABLE | Amount payable or reimbursed by MSIL against the exchange/loyalty claim. |
| 19 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | Doc Status |  | SD_LOYLTY_EXCH_CLAIM | DOC_STATUS | Document status of the claim, decoded from sd.doc_status ('O' = OK, 'N' = NOT OK). |
| 20 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | Counter |  | SD_LOYLTY_EXCH_CLAIM | COUNTER | Claim counter value from the exchange/loyalty claim record. |
| 21 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | New Car Invoice Reason |  | SD_LOYLTY_EXCH_CLAIM | DM_DI | New car invoice document reason: decoded from sd.DM_DI ('M' = Document Missing, 'X' = OK), otherwise looked up via SF_GET_EXCH_LYL_REMARKS with key NCINV_REASON. |
| 22 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | New Car Insurance Reason |  | SD_LOYLTY_EXCH_CLAIM | DM_DI1 | New car insurance document reason: decoded from sd.DM_DI1 ('M' = Document Missing, 'X' = OK), otherwise looked up via SF_GET_EXCH_LYL_REMARKS with key NCINS_REASON. |
| 23 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | Old Car RC/FOP Reason |  | AM_LIST | LIST_DESC | Shows the Old Car RC/FOP Reason taken from AM_LIST.LIST_DESC, looked up via SF_GET_EXCH_LYL_REMARKS. |
| 24 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | Docs Submission Date |  | SD_LOYLTY_EXCH_CLAIM | DOCS_SUBMISSION_DATE | Date on which the supporting documents were submitted by the dealer for the claim. |
| 25 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | Ist Clarification submtd Date |  | SD_LOYLTY_EXCH_CLAIM | IST_CLRF_SUBMTD_DATE | Date on which the first clarification was submitted by the dealer against the claim. |
| 26 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | Latest Clarification Req Date |  | SD_LOYLTY_EXCH_CLAIM | LATEST_CLRF_REQD_DATE | Date of the most recent clarification request raised by MSIL against the claim. |
| 27 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | Latest Clarification submtd Date |  | SD_LOYLTY_EXCH_CLAIM | LATEST_CLRF_SUBMTD_DATE | Date on which the most recent clarification was submitted by the dealer. |
| 28 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | Claim without Bonus Flag |  | SD_LOYLTY_EXCH_CLAIM | TO_BE_CLAIMED_FLAG | Flag indicating whether the claim is submitted without bonus eligibility; defaults to 'N' when null (NVL(SD.to_be_claimed_flag,'N')). |
| 29 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | repurchase_Type |  | SD_LOYLTY_EXCH_CLAIM | OLD_CAR_REPUR_TYPE | Repurchase type derived from sd.old_car_repur_type ('Y' = Same dealer, 'N' = Different dealer), with REPURCHASE_DEALER_TYPE used as override when available. |
| 30 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | repurchase_claim_id |  | SD_LOYLTY_EXCH_CLAIM | REPURCHASE_CLAIM_ID | Identifier of the linked repurchase claim record from the exchange/loyalty claim. |
| 31 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | repurchase_dealer_code |  | SD_LOYLTY_EXCH_CLAIM | REPURCHASE_DEALER_CODE | Dealer code of the dealer who repurchased the old car, as recorded on the exchange/loyalty claim. |
| 32 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | repurchase_dealer_name |  | SD_LOYLTY_EXCH_CLAIM | REPURCHASE_DEALER_NAME | Repurchase dealer name from the claim record; when null, falls back to a lookup of loc.dealer_name from AM_DEALER_LOC using OLD_CAR_SALE_LOC and OLD_CAR_SALE_DEALER. |
| 33 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | repurchase_buying_date |  | SD_LOYLTY_EXCH_CLAIM | REPURCHASE_BUYING_DATE | Date on which the old car was repurchased, as recorded on the exchange/loyalty claim. |
| 34 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | repurchase_old_buyer_name |  | SD_LOYLTY_EXCH_CLAIM | REPURCHASE_OLD_BUYER_NAME | Name of the old buyer (previous owner) from the repurchase details on the exchange/loyalty claim. |
| 35 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | repurchase_new_buyer_name |  | SD_LOYLTY_EXCH_CLAIM | REPURCHASE_NEW_BUYER_NAME | Name of the new buyer recorded in the repurchase details on the exchange/loyalty claim. |
| 36 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | repurchase_claim_status |  | SD_LOYLTY_EXCH_CLAIM | REPURCHASE_CLAIM_STATUS | Status of the linked repurchase claim as recorded on the exchange/loyalty claim record. |
| 37 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | repurchase_remarks |  | SD_LOYLTY_EXCH_CLAIM | REPURCHASE_REMARKS | Remarks associated with the repurchase transaction from the exchange/loyalty claim record. |
| 38 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | Reg. Date |  | SH_TV_EVAL | DATE_OF_REG | Registration date of the old car retrieved from the trade-in evaluation record (SH_TV_EVAL) linked via the invoice POC buying ID. |
| 39 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | Reg. Date(As Per 3rd Party) |  | SD_LOYLTY_EXCH_CLAIM | MODIFIED_REG_DATE | Registration date of the old car as per the third-party (Vahan) verification, stored on the exchange/loyalty claim record. |
| 40 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | Age Of Old Car(As Per 3rd Party) |  | SD_LOYLTY_EXCH_CLAIM | OLD_CAR_AGE | Age of the old car as per third-party data from the exchange/loyalty claim record (sd.old_car_age, the second occurrence in the sequence). |
| 41 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | Total Bonus |  | SM_BONUS_MASTER | TOT_BONUS | Shows the Total Bonus included in this Excel export. |
| 42 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | Dealer Share |  | GM_VAR | FUELTYPE_CD | Shows the Dealer Share taken from GM_VAR.FUELTYPE_CD, looked up via SF_GET_TOTAL_BONUS. |
| 43 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | DISC Given by Dealer |  | AM_LIST | LIST_DESC | Shows the DISC Given by Dealer taken from the enquiry's related records. |
| 44 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | RVSF Name |  | SH_INVOICE | RVSF_NAME | Shows the RVSF Name taken from the enquiry's related records. |
| 45 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | RVSF Address |  | SH_INVOICE | RVSF_ADDRESS | Shows the RVSF Address taken from the enquiry's related records. |
| 46 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | Exchange Cancellation Date |  | SH_INVOICE | EXCH_CANC_DATE | Date on which the exchange transaction was cancelled, sourced from the invoice record (sh.exch_canc_date) for C-Form/Scrappage branches. |
| 47 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | Old Car Vahan Flag |  | SH_TV_EVAL | VAHAN_VALID_FLAG | Shows the Old Car Vahan Flag taken from the enquiry's related records. |
| 48 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | OTP Declaration Flag |  | SH_INVOICE | DECLARE_OTP_YN | Shows the OTP Declaration Flag taken from the enquiry's related records. |
| 49 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | New Car Vahan Flag Date |  | DMS_VAHAN_CHECK_DTL | CREATED_DATE | Shows the New Car Vahan Flag Date taken from the enquiry's related records. |
| 50 | Invoice Type, Scheme, Parent Group, Dealer MAP, LOC, Comp FA, Direct Billing, SCRAPPAGE | OTP Declaration Flag Date |  | SH_INVOICE | CUST_DECL_PDATE | Shows the OTP Declaration Flag Date taken from the enquiry's related records. |
| 51 | Invoice Type, Parent Group, Dealer MAP, LOC, Comp FA, C-Form | MSIL Remarks |  | AM_LIST | LIST_DESC | Shows the MSIL Remarks taken from the enquiry's related records. |
| 52 | Invoice Type, Parent Group, Dealer MAP, LOC, Comp FA, C-Form | Invoice Type |  | AM_LIST | LIST_DESC | Shows the Invoice Type taken from the enquiry's related records. |
| 53 | Invoice Type, Parent Group, OLD NEW Parent Group, Dealer MAP, OLD NEW Delaer MAP, Comp FA, Direct Billing | Age Of Old Car |  | SH_INVOICE | DATE_OF_REG | Shows the Age Of Old Car taken from the enquiry's related records. |

## 7. Glossary

*Definitions of terms, abbreviations, and acronyms used throughout this document.*

The following table defines key terms, acronyms, and abbreviations used throughout this Business Requirements Document.

| Term | Definition | Aliases | Related Terms |
| :--- | :--- | :--- | :--- |
| ALL | A special filter value representing no restriction - selects all dealers, outlets, or statuses without narrowing the report scope. | - | Dealer, Outlet, Status |
| AM_DEALER_LOC | Dealer location master table - stores the mapping of dealer codes, parent group codes, and outlet location codes including old-to-new migration entries. | Dealer Location Master | Dealer, Outlet, LOC_CD |
| AM_LIST | Application list master table - stores configurable lookup values such as claim status codes and descriptions, keyed by list name and principal. | Application List | Status, Principal |
| AM_USER_DEALER_MASTER | User-dealer mapping master table - links logged-in user IDs to their authorised dealers and dealer types. | User Dealer Master | USERID, Dealer |
| Bonus Model | A classification of Exchange/Loyalty scheme claims by the manufacturer bonus arrangement: Bonus (BMD/BMN), Non-Bonus (NBM), or All. | Bonus/Non-Bonus | P_BONUS_YN, Scheme |
| BTN | Button - a UI control on the report screen that triggers an action such as report submission. | Button | SUBMIT, CB_BLK |
| CB_BLK | Control Block - the single Oracle Forms data block in this form. It holds all report filter fields and the Submit button with no direct database table binding. | Control Block | Block |
| C-Form Invoice | A dealership invoice type in the Exchange/Loyalty scheme where the invoice is raised as a C-Form (typically for inter-state stock transfers or scheme-specific billing). | C-Form | Invoice Type, P_INV_TYPE |
| Claim Status | The current processing state of an Exchange/Loyalty scheme claim (e.g. Accepted, Unprocessed, Rejected), used to filter the report output. | Status | RG_STATUS, P_STATUS_DESC |
| Closure Date | The date on which a dealer submitted or closed an Exchange/Loyalty claim for processing. Used as an optional secondary date filter in the report. | Dealer Submission Date | P_CL_FROMDT, P_CL_TODT |
| CSV | Comma-Separated Values - the file format in which the Exchange/Loyalty Dealer Report is generated and delivered to the user's browser. | Spreadsheet Export | VIEW_EXCEL_REP |
| Dealer | A vehicle dealership authorised to participate in Exchange and Loyalty schemes, identified by a dealer code and parent group in the DMS. | DLR | Parent Group, Outlet |
| DMS | Dealer Management System - the integrated software platform for dealership operations within which this form operates. | - | System |
| DPL | A shared Oracle Forms program library (DPL.pld) attached to this form, providing common UI procedures such as DISP_TEXT and RAISE_ERROR. | DPL.pld | PLD, GENERAL |
| DUAL | A standard Oracle database system table used in SQL queries to supply constant or default values (e.g. the 'ALL' row in LOV queries). | - | Record Group |
| Exchange Scheme | A vehicle sales promotion where the customer trades in an old vehicle and receives a discount or benefit on a new vehicle purchase. | Exchange | Swap Scheme, Scheme |
| For Code | A principal or brand code used to scope data within the DMS by manufacturer or principal. | FOR_CD | Principal, P_FOR_CD |
| GENERAL | The package alias used to invoke DPL shared library procedures (e.g. GENERAL.DISP_TEXT, GENERAL.RAISE_ERROR) from triggers and program units. | DPL, general | DPL, DISP_TEXT |
| Global Variable | A session-level variable in Oracle Forms (prefixed with :GLOBAL.) that persists across blocks and is used to pass contextual values such as user ID, dealer, and principal within the form session. | :GLOBAL | USERID, DEALER, PRINCIPAL |
| Invoice Date | The date on which a scheme invoice was raised; the primary date dimension for filtering Exchange/Loyalty claims in this report. | Invoice From Date, Invoice To Date | P_FROMDT, P_TODT |
| Invoice Type | Specifies whether the Exchange/Loyalty claim is associated with a C-Form Invoice or Direct Billing invoice. | P_INV_TYPE | C-Form Invoice, Direct Billing |
| LOC_CD | Location Code - a short code identifying a specific dealer outlet (branch or showroom). | Location Code | Outlet, AM_DEALER_LOC |
| LOV | List of Values - a popup selection dialog in Oracle Forms that lets users pick from a filtered list (e.g. dealer list, outlet list, status list). | Dropdown, Popup List | RG_STATUS, RG_DEALER, RG_LOC |
| MULDMS | The database schema owning the core DMS tables referenced in this form (e.g. MULDMS.AM_DEALER_LOC). | - | Schema, DMS |
| Old/New Dealer | A dealer migration mapping that tracks the old dealer codes alongside their new equivalents following a dealer restructure or system migration. | Old-New Mapping | AM_DEALER_LOC, Dealer |
| Outlet | A specific physical location (branch or showroom) belonging to a dealer, identified by a location code. | Location | LOC_CD, AM_DEALER_LOC |
| Parent Group | A grouping code for dealers that share a common parent organisation or franchise group. | PARENT_GROUP | Dealer, AM_USER_DEALER_MASTER |
| PCK | A PL/SQL package source file (`.pck`) containing stored procedure and function definitions. | Package | PLD |
| PLD | A PL/SQL program library (`.pld`) attached to an Oracle Form, providing shared utility procedures and functions callable from triggers. | Program Library | DPL, GENERAL |
| Principal | The vehicle manufacturer or brand entity that sponsors Exchange and Loyalty schemes, used to scope dealer and status data. | PRINCIPAL, For Code | AM_LIST, Dealer |
| RG_DEALER | Record Group for the Dealer LOV - queries the user's authorised dealers from the user-dealer master. | - | LOV, Dealer |
| RG_LOC | Record Group for the Outlet LOV - queries locations for the selected dealer, filtered by dealer map code and parent group. | - | LOV, Outlet |
| RG_STATUS | Record Group for the Status LOV - queries claim status codes from the application list for the current principal. | - | LOV, Claim Status |
| Scheme | The Exchange or Loyalty promotion programme type that determines the report query path (Exchange or Swap). | P_SCHEME | Exchange Scheme, Swap Scheme |
| Status Date | The date on which a claim status was recorded or updated; used as an optional tertiary date filter in the report. | P_STATUS_FROMDT, P_STATUS_TODT | Claim Status |
| Swap Scheme | A vehicle sales promotion variant where a customer swaps an old vehicle for a new one under a specific billing arrangement, typically involving Direct Billing or C-Form invoicing. | Swap | Exchange Scheme, Scheme |
| USERID | The logged-in user's system identifier, used to filter dealer and outlet lists to the user's authorised scope and to construct the report file name. | User ID | GLOBAL, AM_USER_DEALER_MASTER |
| VIN | Vehicle Identification Number - a unique serial number used to identify individual vehicles; referenced in the report query to retrieve the vehicle's year of manufacture. | Chassis Number | SF_GET_VIN_YOM |
| WebUtil | An Oracle Forms client extension library (webutil.pld / webutil.olb) that provides browser-side file handling capabilities used when generating and opening the CSV report. | WEBUTIL | PLD, VIEW_EXCEL_REP |

---

---

## 8. Technical Inventory

*Complete inventory of Oracle Forms components including blocks, items, triggers, canvases, and global variables.*

### 8.1 Form Architecture

**Form Module Details:**

- Form Name: sr_exch_lyl_dlr_rep (SR_EXCH_LYL_DLR_REP)
- Form Module XML Title: MODULE2
- Oracle Forms Version: 12c (Module version 122010400)
- Parent Object Library: DPL.olb (PC_FORM property class)
- Attached Libraries: WEBUTIL (webutil.olb), DMS_EXCEL_REPORT, D2KWUTIL, DPL (DPL.pld program library)
- First Navigation Block: -
- Console Window: WEBUTIL_HIDDEN_WINDOW - WebUtil hidden utility window (form inherits main window from DPL.olb parent class)
- Compile Dependencies: Requires DPL.olb, DPL.pld, WEBUTIL.olb, menu.mmx, database packages PK_PART_SEARCH_NEW
- Source artifacts: `sr_exch_lyl_dlr_rep_fmb.xml`; OLB `DPL.olb`; WEBUTIL (webutil.olb); DMS_EXCEL_REPORT; D2KWUTIL; DPL (DPL.pld program library)

### 8.1.1 Global Variables

| Global Variable | Data Type | Set Location | Purpose |
| :--- | :--- | :--- | :--- |
| APP_ID | Char | Trigger | Application identifier passed at form startup to set application context in the database session |
| APP_LOG | Char | Trigger | Application logging flag; when set to 'Y', activates performance timer at form start |
| COMP_FA | Char | Trigger | Company FA filter code used to restrict report query results by company |
| CUR_DATE | Date | ProgramUnit | Current system date stored for validation of date range entries |
| DEALER | Char | Trigger | Dealer map code used to filter report query by selected dealer |
| GROUP_CD | Char | Trigger | Dealer group code used to filter and scope dealer and location selections by group |
| LOC_CD | Char | Trigger | Location code used to restrict report query by selected outlet |
| PARENT_GROUP | Char | Trigger | Parent dealer group code used to filter dealer and location selections |
| PRINCIPAL | Char | RecordGroup / Trigger | Principal map code used to filter dealers, locations, and status lists by brand |
| P_FIN_YR | Char | Trigger | Financial year parameter used to scope report data to the relevant fiscal period |
| USERID | Char | ProgramUnit / RecordGroup / Trigger | Logged-in user ID used to filter dealer assignments and construct report file names |
| USER_NAME | Char | Trigger | Display name of the logged-in user, used for session context and report labelling |

### 8.1.2 Form Parameters

*All 11 ModuleParameter entries from sr_exch_lyl_dlr_rep_fmb.xml.*

| Parameter | Data Type | Default | Description |
| :--- | :--- | :--- | :--- |
| P_APP_ID | Char | - | Application identifier passed at form startup to set application context |
| P_DLR_CD | Char | - | Dealer code passed at startup to pre-select the dealer filter on the report screen |
| P_FOR_CD | Char | - | For code (principal code) passed at startup to pre-filter records by principal brand |
| ENQ_DATE | Date | - | Enquiry date passed at startup; reserved for date context when invoked from parent |
| P_CHECK | Number | 0 | Check indicator flag; default 0; controls conditional validation or display behaviour |
| TB | Number | 0 | Tab index indicator; default 0; controls initial tab or display state of the form |
| PR_REMARK | Char | - | Remark text passed at startup for display or pre-population on the report |
| CHECK_MAND | Char | N | Mandatory check flag; when 'Y', enforces mandatory field validation on submission |
| P_USER_TYPE | Char | DLR | User type identifier; default 'DLR' (Dealer); controls data visibility and filter scope |
| P_REGION | Char | - | Region code passed at startup to restrict report data by geographic region |
| P_USER_HORO | Char | - | User hierarchy or role code passed at startup to control data access scope |

**Total Parameters:** 11

### 8.2 Blocks

| Block Name | Query Data Source | Records | Q/I/U/D | Key Mode | Master-Detail Relationship |
| :--- | :--- | :--- | :--- | :--- | :--- |
| CB_BLK | - | 1 | N/N/N/N | Default | - |

**Total Blocks:** 1 business blocks

### 8.2.1 Block WhereClause and OrderByClause

*Block query scope from sr_exch_lyl_dlr_rep_fmb.xml. **Description** explains filter and sort in business terms; **Order By** and **Where Clause** columns retain verbatim XML text for migration.*

| Block | Description | Order By (XML) | Where Clause (XML) |
| :--- | :--- | :--- | :--- |
| - | No blocks with WhereClause/OrderByClause in sr_exch_lyl_dlr_rep_fmb.xml | - | - |

### 8.3 Items Summary

*Complete item inventory from `sr_exch_lyl_dlr_rep_fmb.xml`.*

**Block counts:**

*Database / non-database counts derived from XML.*

| Block | Total Items | Database Items | Non-Database Items |
| :--- | ---: | ---: | ---: |
| CB_BLK | 25 | 0 | 25 |
| PB_BLK | 12 | 0 | 12 |
| CB_ERR | 1 | 0 | 1 |
| WEBUTIL | 9 | 0 | 9 |
| **Total** | **47** | **0** | **47** |

**Item detail (all 47 items):**

| Block | Item Name | DatabaseItem | Description |
| :--- | :--- | :--- | :--- |
| CB_BLK | P_PARENT_GROUP | false | Parent dealer group code filter for the report |
| CB_BLK | P_COMP_FA | false | Company FA code filter for the report |
| CB_BLK | P_DEALER_MAP_CD | false | Internal dealer map code bound to the selected dealer |
| CB_BLK | REPORT_DESC | false | Report title label displayed on the form |
| CB_BLK | P_DELR_CD | false | Dealer code selection field with LOV for dealer selection |
| CB_BLK | P_LOC_CD | false | Location (outlet) code selection field with LOV |
| CB_BLK | P_LOC_DESC | false | Description of the selected location outlet |
| CB_BLK | P_SCHEME | false | Scheme type filter: Exchange ('E') or Swap ('S') |
| CB_BLK | P_INV_TYPE | false | Invoice type filter: C-Form Invoice ('I') or Direct Billing ('D') |
| CB_BLK | P_BONUS_YN | false | Bonus model filter: Bonus ('B'), No Bonus ('N'), or All ('A') |
| CB_BLK | P_FROMDT | false | Report date range start date |
| CB_BLK | P_TODT | false | Report date range end date |
| CB_BLK | P_CL_FROMDT | false | Closure date range start date filter |
| CB_BLK | P_CL_TODT | false | Closure date range end date filter |
| CB_BLK | P_STATUS_FROMDT | false | Status date range start date filter |
| CB_BLK | P_STATUS_TODT | false | Status date range end date filter |
| CB_BLK | P_STATUS | false | Internal status code for the selected status description |
| CB_BLK | P_STATUS_DESC | false | Status description selection field with LOV |
| CB_BLK | P_DESTYPE | false | Report destination type (screen, file, etc.) |
| CB_BLK | SUBMIT | false | Submit button that triggers report generation and CSV export |
| CB_BLK | COPY_RIGHT | false | Copyright declaration display field |
| CB_BLK | TEXT_ITEM810 | false | Internal field holding the constructed report query string |
| CB_BLK | OLD_NEW_PARENT_GROUP | false | Resolved parent group code for old/new dealer migration mapping |
| CB_BLK | OLD_NEW_DELAER_MAP_CD | false | Resolved dealer map code for old/new dealer migration mapping |
| CB_BLK | OLD_NEW_LOC_CD | false | Resolved location code for old/new dealer migration mapping |
| PB_BLK | PB_EXIT | false | Exit button (inherited from DPL.olb PB_BLK); closes the form and returns to the calling application |
| PB_BLK | PB_LIST | false | List/LOV button (inherited from DPL.olb PB_BLK); opens the LOV for the current field |
| PB_BLK | PB_INSERT | false | Insert button (inherited from DPL.olb PB_BLK); initiates a new record insertion; inactive in this reporting form |
| PB_BLK | PM_CONT | false | Continue/context button (inherited from DPL.olb PB_BLK); provides contextual navigation or continuation action |
| PB_BLK | PB_DEL | false | Delete button (inherited from DPL.olb PB_BLK); initiates record deletion; inactive in this reporting form |
| PB_BLK | PB_CANCEL | false | Cancel button (inherited from DPL.olb PB_BLK); cancels the current operation without saving |
| PB_BLK | PB_SAVE | false | Save button (inherited from DPL.olb PB_BLK); saves the current record; inactive in this reporting form |
| PB_BLK | PB_PRINT | false | Print button (inherited from DPL.olb PB_BLK); triggers the print action for the current report output |
| PB_BLK | PB_CUT | false | Cut button (inherited from DPL.olb PB_BLK); cuts selected text from the current field |
| PB_BLK | PB_COPY | false | Copy button (inherited from DPL.olb PB_BLK); copies selected text from the current field |
| PB_BLK | PB_PASTE | false | Paste button (inherited from DPL.olb PB_BLK); pastes clipboard text into the current field |
| PB_BLK | PB_ERR_EXIT | false | Error exit button (inherited from DPL.olb PB_BLK); closes the error window and returns focus to the main canvas |
| CB_ERR | TXT_ERR | false | Error message text display item in the inherited CB_ERR error block; shows the formatted error message text in the WIN_ERR error window |
| WEBUTIL | DUMMY | false | WebUtil infrastructure placeholder push-button; carries no business logic; required by webutil.olb |
| WEBUTIL | WEBUTIL_CLIENTINFO_FUNCTIONS | false | WebUtil bean area item handling client-info functions; infrastructure only; no business logic |
| WEBUTIL | WEBUTIL_FILE_FUNCTIONS | false | WebUtil bean area item handling file functions; infrastructure only; no business logic |
| WEBUTIL | WEBUTIL_HOST_FUNCTIONS | false | WebUtil bean area item handling host functions; infrastructure only; no business logic |
| WEBUTIL | WEBUTIL_SESSION_FUNCTIONS | false | WebUtil bean area item handling session functions; infrastructure only; no business logic |
| WEBUTIL | WEBUTIL_FILETRANSFER_FUNCTIONS | false | WebUtil bean area item handling file-transfer functions; infrastructure only; no business logic |
| WEBUTIL | WEBUTIL_OLE_FUNCTIONS | false | WebUtil bean area item handling OLE functions; infrastructure only; no business logic |
| WEBUTIL | WEBUTIL_C_API_FUNCTIONS | false | WebUtil bean area item handling C-API functions; infrastructure only; no business logic |
| WEBUTIL | WEBUTIL_BROWSER_FUNCTIONS | false | WebUtil bean area item handling browser functions; infrastructure only; no business logic |

### 8.4 List of Values

| LOV Name | Title | Record Group | Attached Block.Item |
| :--- | :--- | :--- | :--- |
| LV_LOC | Outlet Details... | RG_LOC | CB_BLK.P_LOC_CD, CB_BLK.OLD_NEW_LOC_CD |
| LV_DEALER | Dealer Details... | RG_DEALER | CB_BLK.P_DELR_CD |
| LV_STATUS | Status.... | RG_STATUS | CB_BLK.P_STATUS_DESC |

**Total LOVs:** 3

### 8.5 Alerts

| Alert Name | Title | Message Text | Calling Context |
| :--- | :--- | :--- | :--- |
| WEBUTIL_ERROR | Forms | (set at runtime) | Triggered automatically by WebUtil library when a file operation fails; called in ProgramUnit: VIEW_EXCEL_REP |
| ALERT_BUT | Note | Please select valid region code and for code | Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_LOC_CD; Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_SCHEME |
| AL_PRINT | Print | (set at runtime) | Inherited from DPL.olb object group; displayed by PROC_REPORT_CALL / ASK_PRINT when a print destination choice is required |
| AL_ERRINFO | Error | (set at runtime) | Inherited from DPL.olb object group; displayed by RAISE_ERROR via DISP_TEXT for error-category messages |
| AL_NOTE | Note | (set at runtime) | Inherited from DPL.olb object group; displayed by DISP_TEXT for informational note-category messages |
| AL_CONFIRM | Caution | (set at runtime) | Inherited from DPL.olb object group; displayed by ASK_CONFIRM for user confirmation prompts |

**Total Alerts:** 6

### 8.6 Program Units

*Authoritative catalogue of **5 form-local program units**. Database packages and standalone procedures are in **Section 15.2**; PLD shared-library routines are in **Section 18**.*

| Program Unit | Type | Calls | Description |
| :--- | :--- | :--- | :--- |
| VALIDATE_CN_MAIN | Unknown | general.check_null | **COMMENTED OUT / INACTIVE** - Entire body wrapped in block comment; previously validated test-drive record mandatory fields (plate number, model year, test drive date, times, evaluator) using general.check_null |
| CHECK_BEFORE_DELETE | Unknown | SH_ENQUIRY | **COMMENTED OUT / INACTIVE** - Body is null; previously checked for child records in SH_ENQUIRY before allowing a delete operation |
| POPULATE_ERRORS | Package spec | pk_plsql_table.code_tab | Package specification declaring a PL/SQL table variable (v_tab) of type pk_plsql_table.code_tab for collecting error codes |
| PR_REMOVE_ASCII_CHR | Procedure | text_io.fopen, text_io.fclose, web.show_document | Opens a CSV report file from the server, rewrites it line-by-line removing form-feed characters (CHR(12)), then opens the cleaned file in the browser |
| VIEW_EXCEL_REP | Procedure | pk_part_search_new, GET_GROUP_CHAR_CELL, web.show_document, webutil.ID_NULL | Accepts a filename, SQL query, and column name; creates a record group from the query, writes results as a CSV file to the server, then opens the file in the browser via web.show_document |

**Total Program Units:** 5

### 8.7 Triggers

**Item-Level Trigger Types (reference):**

| Trigger Name | Purpose |
| :--- | :--- |
| WHEN-VALIDATE-ITEM | Validates field when user leaves item |
| KEY-* | Keyboard actions - commit, exit, LOV, navigation |
| WHEN-NEW-BLOCK-INSTANCE | Initializes block on entry |
| WHEN-BUTTON-PRESSED | Executes button action |
| PRE-INSERT / POST-INSERT | Before/after record creation |
| WHEN-LIST-CHANGED | Dropdown selection changed |
| PRE-QUERY / POST-QUERY | Before/after query execution |
| WHEN-CHECKBOX-CHANGED | Checkbox toggled |
| WHEN-VALIDATE-RECORD | Validates entire record before leaving row |

**DPL library routines invoked from triggers and program units:**

| Routine | Type | Called From | Purpose |
| :--- | :--- | :--- | :--- |
| GENERAL.ASK_CONFIRM | Library routine | Form level, PB_BLK.PB_EXIT (inherited) | Displays a confirmation dialog and returns the user's choice; used to confirm destructive or exit actions before proceeding |
| GENERAL.CHECK_NULL | Library routine | ProgramUnit: VALIDATE_CN_MAIN | Raises FORM_TRIGGER_FAILURE with a descriptive message if the supplied field value is null; called in inactive VALIDATE_CN_MAIN |
| GENERAL.DISP_TEXT | Library routine | CB_BLK.OLD_NEW_LOC_CD, CB_BLK.P_BONUS_YN, CB_BLK.P_CL_FROMDT, CB_BLK.P_CL_TODT, CB_BLK.P_DELR_CD, CB_BLK.P_FROMDT, CB_BLK.P_INV_TYPE, CB_BLK.P_LOC_CD, CB_BLK.P_SCHEME, CB_BLK.P_STATUS_DESC, CB_BLK.P_STATUS_FROMDT, CB_BLK.P_STATUS_TODT, CB_BLK.P_TODT, CB_BLK.SUBMIT, Form level, ProgramUnit: CHECK_BEFORE_DELETE, ProgramUnit: PR_REMOVE_ASCII_CHR, ProgramUnit: VALIDATE_CN_MAIN | Displays a message dialog box with the given text and title; used throughout the form to show validation errors and informational messages |
| GENERAL.RAISE_ERROR | Library routine | Form level | Looks up a message code, categorises the message as Error/Note/Caution, displays it via DISP_TEXT, and raises FORM_TRIGGER_FAILURE for error-type messages |

### 8.7.1 Inactive / Commented-Out Trigger Register

*Triggers and field validations where XML source is `null;`, fully block-commented, or legacy code preserved but not executed. Do **not** migrate these as active business requirements.*

| Status | Block | Item | Trigger | Former behaviour (preserved in comments) | Disabled since / note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Commented out** | Form | - | ON-ERROR | Previously intercepted error codes 40209 and 40207 and displayed formatted error messages via GENERAL.DISP_TEXT | Legacy block-commented out and superseded by the current active ON-ERROR implementation that handles a broader set of error codes including ORA-02292 and additional FRM codes |
| **Inactive stub** | Form | - | KEY-COMMIT | Previously saved form data on key press | Replaced with NULL; commit operations are suppressed; report generation is handled through the SUBMIT button |
| **Commented out** | Form | - | FT_SAVE | Previously triggered a save operation from the toolbar Save button | Block-commented out; save functionality is not applicable to this read-only reporting form |
| **Commented out** | PB_BLK | PB_EXIT | WHEN-BUTTON-PRESSED | Previously called GENERAL.ASK_CONFIRM before exiting and then performed exit processing | Commented out in the form-local override; exit behaviour is delegated to the inherited DPL.olb implementation |

*Additional null-only or partially commented triggers exist on estimation and legacy blocks - see XML `TriggerText` starting with `null;` or `/*`.*

*The WEBUTIL-infrastructure stubs (8× WHEN-CUSTOM-ITEM-EVENT on WEBUTIL bean area items and 1× WHEN-BUTTON-PRESSED on WEBUTIL.DUMMY) are excluded from the business trigger inventory above; they are catalogued in the inactive register below for completeness.*

| Status | Block | Item | Trigger | Former behaviour (preserved in comments) | Disabled since / note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Inactive stub** | WEBUTIL | WEBUTIL_BROWSER_FUNCTIONS | WHEN-CUSTOM-ITEM-EVENT | WebUtil infrastructure stub - no business logic; handles browser-function bean area events | WEBUTIL infrastructure - never active in business flow; inherited from webutil_olb.xml |
| **Inactive stub** | WEBUTIL | WEBUTIL_C_API_FUNCTIONS | WHEN-CUSTOM-ITEM-EVENT | WebUtil infrastructure stub - no business logic; handles C-API bean area events | WEBUTIL infrastructure - never active in business flow; inherited from webutil_olb.xml |
| **Inactive stub** | WEBUTIL | WEBUTIL_OLE_FUNCTIONS | WHEN-CUSTOM-ITEM-EVENT | WebUtil infrastructure stub - no business logic; handles OLE bean area events | WEBUTIL infrastructure - never active in business flow; inherited from webutil_olb.xml |
| **Inactive stub** | WEBUTIL | WEBUTIL_FILETRANSFER_FUNCTIONS | WHEN-CUSTOM-ITEM-EVENT | WebUtil infrastructure stub - no business logic; handles file-transfer bean area events | WEBUTIL infrastructure - never active in business flow; inherited from webutil_olb.xml |
| **Inactive stub** | WEBUTIL | WEBUTIL_SESSION_FUNCTIONS | WHEN-CUSTOM-ITEM-EVENT | WebUtil infrastructure stub - no business logic; handles session bean area events | WEBUTIL infrastructure - never active in business flow; inherited from webutil_olb.xml |
| **Inactive stub** | WEBUTIL | WEBUTIL_HOST_FUNCTIONS | WHEN-CUSTOM-ITEM-EVENT | WebUtil infrastructure stub - no business logic; handles host-function bean area events | WEBUTIL infrastructure - never active in business flow; inherited from webutil_olb.xml |
| **Inactive stub** | WEBUTIL | WEBUTIL_FILE_FUNCTIONS | WHEN-CUSTOM-ITEM-EVENT | WebUtil infrastructure stub - no business logic; handles file-function bean area events | WEBUTIL infrastructure - never active in business flow; inherited from webutil_olb.xml |
| **Inactive stub** | WEBUTIL | WEBUTIL_CLIENTINFO_FUNCTIONS | WHEN-CUSTOM-ITEM-EVENT | WebUtil infrastructure stub - no business logic; handles client-info bean area events | WEBUTIL infrastructure - never active in business flow; inherited from webutil_olb.xml |
| **Inactive stub** | WEBUTIL | DUMMY | WHEN-BUTTON-PRESSED | WebUtil infrastructure stub - no business logic; dummy push-button placeholder in WEBUTIL block | WEBUTIL infrastructure - never active in business flow; inherited from webutil_olb.xml |

**Complete trigger inventory (46 business triggers):**
*sr_exch_lyl_dlr_rep_fmb.xml contains Trigger elements across form level, CB_BLK, and PB_BLK. The 9 WEBUTIL-infrastructure triggers are excluded from this business inventory and catalogued in Section 8.7.1.*

| Trigger Name | Block | Item | Called From / Context | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| ON-ERROR | Form | - | Form level | Intercepts Oracle Forms and database errors; displays user-friendly messages for known FRM and ORA error codes; rolls back on constraint violations |
| ON-MESSAGE | Form | - | Form level | Intercepts form messages 40209 and 40207; suppresses default messages and displays a formatted error via DISP_TEXT |
| KEY-EXIT | Form | - | Form level | Clears application info and module name from the database session, then exits the form without saving |
| KEY-LISTVAL | Form | - | Form level | Retrieves the LOV name for the current cursor item and displays the LOV at a fixed screen position; navigates to the next item on successful selection |
| KEY-COMMIT | Form | - | Form level | **INACTIVE** - Body is NULL; commit key is explicitly suppressed for this reporting form |
| KEY-CLRFRM | Form | - | Form level | Clears the form without saving, then resets the report title label and copyright field to their default values |
| KEY-OTHERS | Form | - | Form level (inherited) | Suppresses unhandled key events to prevent default Forms key behaviour from interfering with the form |
| KEY-NEXT-ITEM | Form | - | Form level (inherited) | Navigates to the next item in tab order |
| KEY-PREV-ITEM | Form | - | Form level (inherited) | Navigates to the previous item in tab order |
| KEY-NXTBLK | Form | - | Form level (inherited) | Navigates to the next block |
| KEY-PRVBLK | Form | - | Form level (inherited) | Navigates to the previous block |
| KEY-DOWN | Form | - | Form level (inherited) | Navigates down within a multi-record block |
| KEY-UP | Form | - | Form level (inherited) | Navigates up within a multi-record block |
| FT_SAVE | Form | - | Form level | **INACTIVE (commented out)** - Toolbar Save button trigger; save functionality is not applicable to this reporting form |
| FT_CANCEL | Form | - | Form level (inherited) | Toolbar Cancel button trigger; cancels the current operation without saving |
| FT_INSERT | Form | - | Form level (inherited) | Toolbar Insert button trigger; initiates a new record insertion; inactive in this reporting form |
| FT_DEL | Form | - | Form level (inherited) | Toolbar Delete button trigger; initiates record deletion; inactive in this reporting form |
| FT_LIST | Form | - | Form level (inherited) | Toolbar List button trigger; opens the LOV for the current item |
| FT_PRINT | Form | - | Form level (inherited) | Toolbar Print button trigger; triggers the print action for the current report output |
| WHEN-NEW-FORM-INSTANCE | Form | - | Form level (inherited) | Initialises the form on first load; sets global variables, populates default filter values, and configures the display based on user type and startup parameters |
| PRE-FORM | Form | - | Form level | Sets application context in the database session; activates performance timer when application logging is enabled |
| WHEN-VALIDATE-ITEM | CB_BLK | P_DELR_CD | CB_BLK.P_DELR_CD | Validates that a dealer has been selected; raises an error if the dealer field is empty |
| WHEN-VALIDATE-ITEM | CB_BLK | P_LOC_CD | CB_BLK.P_LOC_CD | Validates that an outlet location has been selected; raises an error if the location field is empty |
| WHEN-VALIDATE-ITEM | CB_BLK | P_SCHEME | CB_BLK.P_SCHEME | Validates that a scheme type has been selected; raises an error if the scheme field is empty |
| WHEN-VALIDATE-ITEM | CB_BLK | P_INV_TYPE | CB_BLK.P_INV_TYPE | Validates that an invoice type has been selected; raises an error if the invoice type field is empty |
| WHEN-VALIDATE-ITEM | CB_BLK | P_BONUS_YN | CB_BLK.P_BONUS_YN | Validates that a bonus model option has been selected; raises an error if the bonus flag field is empty |
| WHEN-VALIDATE-ITEM | CB_BLK | P_FROMDT | CB_BLK.P_FROMDT | Validates the report start date: must not be null, must not exceed today's date, must not exceed the end date, and the range must be within 10 days |
| WHEN-VALIDATE-ITEM | CB_BLK | P_TODT | CB_BLK.P_TODT | Validates the report end date: must not be entered without a start date, must not be before the start date, and must not exceed today's date |
| WHEN-VALIDATE-ITEM | CB_BLK | P_CL_FROMDT | CB_BLK.P_CL_FROMDT | Validates the closure from date: must not exceed today, must not be before the invoice from date, and must not exceed the closure end date |
| WHEN-VALIDATE-ITEM | CB_BLK | P_CL_TODT | CB_BLK.P_CL_TODT | Validates the closure end date: must not be entered without a closure from date, must not be before the closure from date, and must not exceed today |
| WHEN-VALIDATE-ITEM | CB_BLK | P_STATUS_FROMDT | CB_BLK.P_STATUS_FROMDT | Validates the status from date: must not exceed today, must not be before the invoice from date, and must not exceed the status end date |
| WHEN-VALIDATE-ITEM | CB_BLK | P_STATUS_TODT | CB_BLK.P_STATUS_TODT | Validates the status end date: must not be entered without a status from date, must not be before the status from date, and must not exceed today |
| WHEN-VALIDATE-ITEM | CB_BLK | P_STATUS_DESC | CB_BLK.P_STATUS_DESC | Validates that a status has been selected from the LOV; raises an error if the status field is empty |
| WHEN-BUTTON-PRESSED | CB_BLK | SUBMIT | CB_BLK.SUBMIT | Validates date range (max 10 days), resolves bonus model and status codes, queries old/new dealer mapping from AM_DEALER_LOC, builds a dynamic SQL query based on scheme and invoice type, then generates and opens the Exchange/Loyalty Dealer Report as a CSV file |
| WHEN-VALIDATE-ITEM | CB_BLK | OLD_NEW_LOC_CD | CB_BLK.OLD_NEW_LOC_CD | Validates that the resolved old/new outlet location code is not empty; raises an error if missing |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EXIT | PB_BLK.PB_EXIT (inherited) | Calls GENERAL.ASK_CONFIRM to prompt the user before exiting; clears session context and closes the form if confirmed |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_LIST | PB_BLK.PB_LIST (inherited) | Opens the LOV for the currently focused item on the main canvas |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_INSERT | PB_BLK.PB_INSERT (inherited) | Initiates a new record insertion; inactive in this reporting form |
| WHEN-BUTTON-PRESSED | PB_BLK | PM_CONT | PB_BLK.PM_CONT (inherited) | Provides contextual continuation or navigation action from the toolbar |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_DEL | PB_BLK.PB_DEL (inherited) | Initiates record deletion after confirmation; inactive in this reporting form |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CANCEL | PB_BLK.PB_CANCEL (inherited) | Cancels the current operation without saving and resets the block to its previous state |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SAVE | PB_BLK.PB_SAVE (inherited) | Saves the current record; inactive in this reporting form |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PRINT | PB_BLK.PB_PRINT (inherited) | Triggers the print action for the current report output |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CUT | PB_BLK.PB_CUT (inherited) | Cuts selected text from the currently focused field |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_COPY | PB_BLK.PB_COPY (inherited) | Copies selected text from the currently focused field |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PASTE | PB_BLK.PB_PASTE (inherited) | Pastes clipboard text into the currently focused field |

### 8.8 Canvas and Window Inventory

*The form's visible UI is delivered through canvases and windows inherited from DPL.olb (WN_MAIN / CN_MAIN / CN_TOOL) and the error-display window (WIN_ERR / CN_ERR). These components are part of the inherited object group from DPL.olb and carry the standard dealer portal chrome.*

**Windows:**

| Window | Title | Primary Canvas |
| :--- | :--- | :--- |
| WIN_ERR | - | CN_ERR |
| WN_MAIN | Exchange/Loyalty Status Report (Rel 1.3.15) | CN_MAIN |

**Canvases:**

| Canvas | Type | Window |
| :--- | :--- | :--- |
| CN_ERR | Content | WIN_ERR |
| CN_MAIN | Content | WN_MAIN |
| CN_TOOL | Content | WN_MAIN |

### 8.9 Editors

*No editors found in sr_exch_lyl_dlr_rep_fmb.xml.*

### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

#### 8.10.1 Visual Attributes (form-defined)

*3 VisualAttribute elements defined at form level (not inherited from DPL.olb).*

| Visual Attribute |
| :--- |
| VA_MANDATORY |
| VA_DEFAULT |
| VA_DISPLAY |

#### 8.10.2 Property Classes (form-defined)

*Form-local PropertyClass elements.*

*No form-local property classes found in sr_exch_lyl_dlr_rep_fmb.xml.*

#### 8.10.3 Object Groups

*Object groups bundle inherited triggers and visual objects applied form-wide at runtime. All entries below are sourced from the DPL.olb parent object library and applied to this form at compile time.*

| Object Group Child | Type |
| :--- | :--- |
| KEY-OTHERS | Inherited trigger |
| KEY-NEXT-ITEM | Inherited trigger |
| KEY-PREV-ITEM | Inherited trigger |
| KEY-NXTBLK | Inherited trigger |
| KEY-PRVBLK | Inherited trigger |
| KEY-DOWN | Inherited trigger |
| KEY-UP | Inherited trigger |
| CN_ERR | Inherited canvas |
| VA_DISP | Inherited visualattribute |
| CB_ERR | Inherited block |
| VA_LOV | Inherited visualattribute |
| VA_TRNI_DT | Inherited visualattribute |
| VA_TITLE | Inherited visualattribute |
| VA_ALERT | Inherited visualattribute |
| VA_BUTN | Inherited visualattribute |
| VA_TEXT | Inherited visualattribute |
| VA_MPROMPT | Inherited visualattribute |
| VA_OPROMPT | Inherited visualattribute |
| VA_MAND | Inherited visualattribute |
| VA_NUM | Inherited visualattribute |
| VA_DESC | Inherited visualattribute |
| VA_ICONIC_BUTN | Inherited visualattribute |
| VA_RB | Inherited visualattribute |
| VA_CB | Inherited visualattribute |
| WN_MAIN | Inherited window |
| POP_MAIN | Inherited trigger |
| CN_MAIN | Inherited canvas |
| CN_TOOL | Inherited canvas |
| PB_BLK | Inherited block |
| AL_ERRINFO | Inherited alert |
| AL_NOTE | Inherited alert |
| AL_CONFIRM | Inherited alert |
| WIN_ERR | Inherited window |
| AL_PRINT | Inherited alert |
| FT_SAVE | Inherited trigger |
| FT_CANCEL | Inherited trigger |
| FT_INSERT | Inherited trigger |
| FT_DEL | Inherited trigger |
| FT_LIST | Inherited trigger |
| FT_PRINT | Inherited trigger |
| WHEN-NEW-FORM-INSTANCE | Inherited trigger |

### 8.11 DataSourceColumn Inventory

*No DataSourceColumns found in sr_exch_lyl_dlr_rep_fmb.xml.*

## 9. Object Library

*This form references objects from two Object Library (OLB) files. The DPL OLB provides the standard DMS visual attributes and property classes used across the DMS suite. The WEBUTIL OLB provides the WebUtil object group and parameters required for client-server file transfer and browser integration.*

Source OLB file(s): DPL_olb.xml, webutil_olb.xml

| Name | Type | Description | Used By (count) | Sample Items |
| ---- | ---- | ----------- | --------------- | ------------ |
| VA_CB | VisualAttribute | Visual attribute for check-box items (gray background, Arial 8pt) | Referenced in DPL_olb.xml | N/A - not referenced by form items in this module |
| VA_RB | VisualAttribute | Visual attribute for radio-button items (gray background, Arial 8pt) | Referenced in DPL_olb.xml | N/A - not referenced by form items in this module |
| VA_ICONIC_BUTN | VisualAttribute | Visual attribute for iconic push buttons (white background, black foreground, transparent fill) | Referenced in DPL_olb.xml | N/A - not referenced by form items in this module |
| VA_DESC | VisualAttribute | Visual attribute for description/label display items (gray background, Small Fonts 7pt) | Referenced in DPL_olb.xml | N/A - not referenced by form items in this module |
| VA_NUM | VisualAttribute | Visual attribute for numeric text items (white background, Arial 8pt, plain) | Referenced in DPL_olb.xml | N/A - not referenced by form items in this module |
| VA_MAND | VisualAttribute | Visual attribute for mandatory fields (cyan background, Arial 9pt, plain) | Referenced in DPL_olb.xml | N/A - not referenced by form items in this module |
| VA_OPROMPT | VisualAttribute | Prompt visual attribute for optional fields (8pt, transparent fill) | Referenced in DPL_olb.xml | N/A - not referenced by form items in this module |
| VA_MPROMPT | VisualAttribute | Prompt visual attribute for mandatory field prompts (8pt, transparent fill) | Referenced in DPL_olb.xml | N/A - not referenced by form items in this module |
| VA_TEXT | VisualAttribute | Visual attribute for general text items (white background, Arial 9pt, plain) | Referenced in DPL_olb.xml | N/A - not referenced by form items in this module |
| VA_BUTN | VisualAttribute | Visual attribute for push buttons (gray background, Arial 10pt, bold) | Referenced in DPL_olb.xml | N/A - not referenced by form items in this module |
| VA_ALERT | VisualAttribute | Visual attribute for alerts (gray background, MT Extra 11pt, bold) | Referenced in DPL_olb.xml | N/A - not referenced by form items in this module |
| VA_TITLE | VisualAttribute | Visual attribute for title items (gray background, Arial 10pt, bold) | Referenced in DPL_olb.xml | N/A - not referenced by form items in this module |
| VA_TRNI_DT | VisualAttribute | Visual attribute for transaction date fields (white background, Courier, bold) | Referenced in DPL_olb.xml | N/A - not referenced by form items in this module |
| VA_LOV | VisualAttribute | Visual attribute for LOV items (gray background, Arial 9pt) | Referenced in DPL_olb.xml | N/A - not referenced by form items in this module |
| VA_DISP | VisualAttribute | Visual attribute for display items (r25g75b75 background, Arial 8pt, bold) | Referenced in DPL_olb.xml | N/A - not referenced by form items in this module |
| VA_MANDATORY | VisualAttribute | Form-level visual attribute for mandatory item styling (declared in form XML) | Declared in form XML as VA_MANDATORY | N/A - declared at form level, not subclassed by items |
| VA_DEFAULT | VisualAttribute | Form-level visual attribute for default item styling (declared in form XML) | Declared in form XML as VA_DEFAULT | N/A - declared at form level, not subclassed by items |
| VA_DISPLAY | VisualAttribute | Form-level visual attribute for display-only item styling (declared in form XML) | Declared in form XML as VA_DISPLAY | N/A - declared at form level, not subclassed by items |
| PC_DESC | PropertyClass | Property class for description text items (left-justified, 250 width) | Referenced in DPL_olb.xml | N/A - not subclassed by form items in this module |
| PC_SC_DATE | PropertyClass | Property class for date items (73 width, max 11 chars; comment: PROPERTY CLASS FOR DATE) | Referenced in DPL_olb.xml | N/A - not subclassed by form items in this module |
| PC_TITLE | PropertyClass | Property class for title text items (comment: PROPERTY CLASS FOR TEXT ITEMS) | Referenced in DPL_olb.xml | N/A - not subclassed by form items in this module |
| PC_FORMAT | PropertyClass | Property class for format/code text items (centred, 60 width; comment: PROPERTY CLASS FOR TEXT ITEMS) | Referenced in DPL_olb.xml | N/A - not subclassed by form items in this module |
| PC_MR_BLK | PropertyClass | Property class for master-record blocks | Referenced in DPL_olb.xml | N/A - not subclassed by form items in this module |
| PC_DISP | PropertyClass | Property class for display-only items (left-justified, disabled; comment: PROPERTY CLASS FOR TEXT ITEMS) | Referenced in DPL_olb.xml | N/A - not subclassed by form items in this module |
| PC_LOV | PropertyClass | Property class for LOV-linked items (comment: PROPERTY CLASS FOR LIST OF VALUES) | Referenced in DPL_olb.xml | N/A - not subclassed by form items in this module |
| PC_FORM | PropertyClass | Property class for form-level settings (item validation unit, no savepoint) | Referenced in DPL_olb.xml | N/A - not subclassed by form items in this module |
| PC_DISP_DATE | PropertyClass | Property class for display-only date items (comment: PROPERTY CLASS FOR TEXT ITEMS) | Referenced in DPL_olb.xml | N/A - not subclassed by form items in this module |
| PC_DISP_NUM | PropertyClass | Property class for display-only numeric items (right-justified, disabled; comment: PROPERTY CLASS FOR TEXT ITEMS) | Referenced in DPL_olb.xml | N/A - not subclassed by form items in this module |
| PC_DATE | PropertyClass | Property class for date entry items (60 width, max 10 chars, cyan background; comment: PROPERTY CLASS FOR DATE) | Referenced in DPL_olb.xml | N/A - not subclassed by form items in this module |
| PC_DTTIME | PropertyClass | Property class for date-and-time items (80 width, max 15 chars; comment: Property class for Date and Time) | Referenced in DPL_olb.xml | N/A - not subclassed by form items in this module |
| PC_CB | PropertyClass | Property class for check-box items | Referenced in DPL_olb.xml | N/A - not subclassed by form items in this module |
| PC_ALERT | PropertyClass | Property class for alert dialogs | Referenced in DPL_olb.xml | N/A - not subclassed by form items in this module |
| PC_MDATE | PropertyClass | Property class for mandatory date items (comment: PROPERTY CLASS FOR DATE) | Referenced in DPL_olb.xml | N/A - not subclassed by form items in this module |
| PC_RB | PropertyClass | Property class for radio-button items | Referenced in DPL_olb.xml | N/A - not subclassed by form items in this module |
| PC_WIND | PropertyClass | Property class for windows (comment: PROPERTY CLASS FOR WINDOWS) | Referenced in DPL_olb.xml | N/A - not subclassed by form items in this module |
| PC_CANV | PropertyClass | Property class for canvases (white background, Arial) | Referenced in DPL_olb.xml | N/A - not subclassed by form items in this module |
| PC_BUTN | PropertyClass | Property class for push buttons (42 width; comment: PROPERTY CLASS FOR PUSH BUTTONS) | Referenced in DPL_olb.xml | N/A - not subclassed by form items in this module |
| PC_TEXT | PropertyClass | Property class for standard text items (comment: PROPERTY CLASS FOR TEXT ITEMS) | Referenced in DPL_olb.xml | N/A - not subclassed by form items in this module |
| PC_MTEXT | PropertyClass | Property class for mandatory text items (comment: PROPERTY CLASS FOR TEXT ITEMS) | Referenced in DPL_olb.xml | N/A - not subclassed by form items in this module |
| PC_UTEXT | PropertyClass | Property class for uppercase text items (comment: PROPERTY CLASS FOR TEXT ITEMS) | Referenced in DPL_olb.xml | N/A - not subclassed by form items in this module |
| PC_MUTEXT | PropertyClass | Property class for mandatory uppercase text items (comment: PROPERTY CLASS FOR TEXT ITEMS) | Referenced in DPL_olb.xml | N/A - not subclassed by form items in this module |
| PC_NUM | PropertyClass | Property class for numeric items (right-justified, minimum 0; comment: PROPERTY CLASS FOR NUMERIC ITEMS) | Referenced in DPL_olb.xml | N/A - not subclassed by form items in this module |
| PC_MNUM | PropertyClass | Property class for mandatory numeric items (comment: PROPERTY CLASS FOR NUMERIC ITEMS) | Referenced in DPL_olb.xml | N/A - not subclassed by form items in this module |
| PC_ICONIC_BUTN | PropertyClass | Property class for iconic push buttons (comment: PROPERTY CLASS FOR PUSH BUTTONS) | Referenced in DPL_olb.xml | N/A - not subclassed by form items in this module |
| PC_SCROLL | PropertyClass | Property class for scrollbar items (13 width) | Referenced in DPL_olb.xml | N/A - not subclassed by form items in this module |
| OG_GROUP | ObjectGroup | Form-level object group declared in the form XML (DPL object group) | Declared at form level | N/A - declared at form level |
| WEBUTIL | ObjectGroup | The WebUtil object group (from webutil_olb.xml) containing all items needed to use WebUtil functionality (file transfer, browser integration, OLE, client info) | Declared at form level - WEBUTIL block instantiated from this group | WEBUTIL block items (DUMMY, WEBUTIL_FILE_FUNCTIONS, WEBUTIL_HOST_FUNCTIONS, etc.) |
| WEBUTIL_NO_OLE | ObjectGroup | A variant WebUtil object group (from webutil_olb.xml) for environments without OLE support | Referenced in webutil_olb.xml | N/A - not instantiated separately in this module |
| WEBUTILCONFIG | ModuleParameter | WebUtil configuration parameter (from webutil_olb.xml) defining the name and location of the WebUtil configuration file | Referenced in webutil_olb.xml | N/A - module parameter |

---

## 10. Record Groups

*Lists all record groups, their LOV bindings, query logic, dynamic bindings, business purpose, and form usage.*

| Record Group | Type | Used By LOV | Display Column | Return Column | Dynamic Bindings | Purpose | Where Used |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| RG_STATUS | Query | LV_STATUS | STATUS_DESC | STATUS_CD | No | Lists available Exchange/Loyalty claim status values for the user to filter the report | LV_STATUS -> CB_BLK.P_STATUS_DESC |
| RG_DEALER | Query | LV_DEALER | DLR_CD | PARENT_GROUP | No | Lists dealers accessible to the logged-in user for selection as a report filter | LV_DEALER -> CB_BLK.P_DELR_CD |
| RG_LOC | Query | LV_LOC | LOC_CD | LOC_DESC | Yes - CB_BLK | Lists outlet locations belonging to the selected dealer, filtered by dealer map code and parent group | LV_LOC -> CB_BLK.P_LOC_CD, CB_BLK.OLD_NEW_LOC_CD |

**Total Record Groups:** 3

## 11. Referenced Database Objects

*Database tables, views, and objects accessed by the form.*

| Block | Base Table | Primary Key Item | Database Item |
| :--- | :--- | :--- | :--- |
| CB_BLK | - | - | No |

| Object | Schema | Used In | Description |
| :--- | :--- | :--- | :--- |
| `AM_DEALER_LOC` | - | Trigger WHEN-BUTTON-PRESSED | Dealer location master - maps dealers to outlets; queried to resolve old/new dealer migration codes |
| `AM_LIST` | - | RG_STATUS | Application list master - stores configurable lookup values; used to populate Exchange/Loyalty status options |
| `AM_USER_DEALER_MASTER` | MULDMS | RG_DEALER | User-dealer mapping master - links user IDs to their assigned dealers and access rights |
| `DUAL` | - | RG_DEALER, RG_LOC, RG_STATUS | Oracle system table - used to supply the 'ALL' default row in each LOV query via UNION |
| `MULDMS.AM_DEALER_LOC` | - | RG_LOC | Dealer location master (MULDMS schema) - provides location code and description for the outlet LOV |
| `MULDMS.AM_USER_DEALER_MASTER` | - | RG_DEALER | User-dealer mapping master (MULDMS schema) - provides dealer list filtered by the logged-in user |

**Total Referenced Objects:** 6

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure/Package Index

| Requirement ID | Procedure/Package | Purpose |
| -------------- | ----------------- | ------- |
| BR-001 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Records the form module name as the current session's client information at form open and clears it at form exit |
| BR-001 | DBMS_APPLICATION_INFO.SET_MODULE | Records the form module name and action in the Oracle session at form open and clears both at form exit |
| BR-001 | STOP_WATCH.START_TIMER | Starts the application performance timer at form open when application logging is enabled |
| BR-002 | SF_COPYRIGHT_DECLARATION | Retrieves and returns the standard copyright declaration text displayed on the form |
| BR-016 | VIEW_EXCEL_REP | Executes the dynamically built report query, writes results row by row to a CSV file on the server, and opens the file in the user's browser |
| BR-016 | SF_GET_EXCH_LYL_REMARKS | Called within the report query to decode document check indicator codes into readable reason descriptions for each of nine document type columns |
| BR-016 | SF_GET_TOTAL_BONUS | Called within the report query to calculate the total bonus, MSIL share, dealer share, and stock liquidation bonus/share amounts for each claim row |
| BR-016 | SF_GET_EXCH_SLAB | Called within the report query as an input to SF_GET_TOTAL_BONUS to determine the exchange slab category based on old-car age |
| BR-016 | SF_GET_VIN_YOM | Called within the report query as an input to SF_GET_TOTAL_BONUS to determine the year of manufacture from the VIN for stock liquidation bonus calculation |
| BR-016 | GENERAL.DISP_TEXT | Displays formatted messages and errors throughout the form's validation and error-handling flows |
| BR-016 | WEBUTIL_C_API.ID_NULL | Checks whether the record group handle returned during report generation is null before processing report rows in VIEW_EXCEL_REP |
| BR-017 | GENERAL.RAISE_ERROR | Looks up and displays a pre-configured business error message for a given error code, used in the child-record constraint violation path of the error handler |
| BR-018 | GENERAL.DISP_TEXT | Displays reformatted Oracle Forms messages in the ON-MESSAGE trigger |
| BR-019 | WEB.SHOW_DOCUMENT | Opens a server-side file in the user's browser; called from the PR_REMOVE_ASCII_CHR program unit after the cleaned output file is written |
| - | GENERAL.ASK_CONFIRM | Prompts the user with a confirmation dialog before discarding changes (FT_CANCEL) or deleting records (FT_DEL) |
| - | WEBUTIL_CORE.CUSTOMEVENTHANDLER | Central WebUtil event-dispatch routine; routes Java-layer callbacks from all eight WebUtil bean canvases to the appropriate WebUtil package handler |

---

### 12.2 Procedure and Package Catalogue

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| SF_COPYRIGHT_DECLARATION | Standalone function (`SF_COPYRIGHT_DECLARATION.fnc`) | KEY-CLRFRM trigger (Form level) | Returns the standard copyright declaration text to be displayed in the copyright notice field on the form |
| VIEW_EXCEL_REP | Form program unit (Procedure) | WHEN-BUTTON-PRESSED trigger on CB_BLK.SUBMIT | Receives a filename, a dynamic SQL query string, and a column name; creates an in-memory record group from the query; writes each result row to a server-side CSV file; reads the server output URL from the configuration file; and opens the file in the user's browser |
| SF_GET_EXCH_LYL_REMARKS | Standalone function (`SF_GET_EXCH_LYL_REMARKS.fnc`) | Embedded in the dynamic report query built by WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT | Decodes document check indicator codes (e.g. M = Document Missing, X = OK) into human-readable reason descriptions for each of nine document type columns in the report output |
| SF_GET_TOTAL_BONUS | Standalone function (`SF_GET_TOTAL_BONUS.fnc`) | Embedded in the dynamic report query built by WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT | Calculates the total bonus, MSIL share, dealer share, and stock liquidation bonus/share for each claim row based on scheme, invoice date, region, state, dealer, model, variant, fuel type, bonus type, principal, exchange slab, channel, and sales type |
| SF_GET_EXCH_SLAB | Standalone function (`SF_GET_EXCH_SLAB.fnc`) | Embedded in the dynamic report query as a parameter to SF_GET_TOTAL_BONUS | Determines the exchange slab category based on the old car's age, returning the applicable slab code used in bonus calculation |
| SF_GET_VIN_YOM | Standalone function (`SF_GET_VIN_YOM.fnc`) | Embedded in the dynamic report query as a parameter to SF_GET_TOTAL_BONUS for stock liquidation bonus calculation | Extracts the year of manufacture from the vehicle's VIN number for use in stock liquidation bonus slab determination |
| PR_REMOVE_ASCII_CHR | Form program unit (Procedure) | Not called from any active trigger in the current form (available for use but not invoked in active flows) | Reads a report file line by line, skips lines beginning with the ASCII form-feed character, writes clean lines to a new output file, and opens the output file in the user's browser via WEB.SHOW_DOCUMENT |
| POPULATE_ERRORS | Form program unit (Package specification) | Not called from any active trigger in the current form | Declares an in-memory PL/SQL table variable (`pk_plsql_table.code_tab`) for use as a local code lookup table; the variable is declared but not used in any currently executing path |
| GENERAL.ASK_CONFIRM | Package routine (DPL/GENERAL package) | FT_CANCEL trigger (Form level); FT_DEL trigger (Form level); WHEN-BUTTON-PRESSED trigger on WEBUTIL.DUMMY | Displays a confirmation dialog to the user with the supplied message and returns a numeric result indicating the user's choice; used to prompt the user before discarding unsaved changes or deleting records |
| GENERAL.DISP_TEXT | Package routine (DPL/GENERAL package) | ON-ERROR trigger; ON-MESSAGE trigger; FT_INSERT trigger (Form level); WHEN-BUTTON-PRESSED trigger on CB_BLK.SUBMIT; WHEN-VALIDATE-ITEM triggers on CB_BLK.OLD_NEW_LOC_CD, CB_BLK.P_BONUS_YN, CB_BLK.P_CL_TODT, CB_BLK.P_DELR_CD, CB_BLK.P_FROMDT, CB_BLK.P_INV_TYPE, CB_BLK.P_LOC_CD, CB_BLK.P_SCHEME, CB_BLK.P_STATUS_DESC, CB_BLK.P_STATUS_TODT, CB_BLK.P_TODT; PR_REMOVE_ASCII_CHR program unit | Displays a user-visible message dialog with the specified severity level; if the title is 'ERROR' it shows the AL_ERRINFO alert styled as an error, otherwise it shows the AL_NOTE alert styled as a note; used throughout the form to surface validation failures and informational messages |
| GENERAL.RAISE_ERROR | Package routine (DPL/GENERAL package) | ON-ERROR trigger - DBMS error code -02292 path | Accepts a message code, looks up the corresponding message text and type, then displays the message via DISP_TEXT and raises FORM_TRIGGER_FAILURE for error-type messages; provides standardised business-language error messages for known database constraint violations |
| WEBUTIL_CORE.CUSTOMEVENTHANDLER | Attached library routine (webutil.pld - WEBUTIL_CORE package) | WHEN-CUSTOM-ITEM-EVENT triggers on WEBUTIL.WEBUTIL_BROWSER_FUNCTIONS, WEBUTIL.WEBUTIL_CLIENTINFO_FUNCTIONS, WEBUTIL.WEBUTIL_C_API_FUNCTIONS, WEBUTIL.WEBUTIL_FILETRANSFER_FUNCTIONS, WEBUTIL.WEBUTIL_FILE_FUNCTIONS, WEBUTIL.WEBUTIL_HOST_FUNCTIONS, WEBUTIL.WEBUTIL_OLE_FUNCTIONS, WEBUTIL.WEBUTIL_SESSION_FUNCTIONS | Central event-dispatch routine for the WebUtil infrastructure; each WebUtil bean item fires WHEN-CUSTOM-ITEM-EVENT when the Java client layer raises a callback; the trigger passes the event name and its serialised parameter string to CustomEventHandler, which routes the call to the appropriate WebUtil package handler |
| WEBUTIL_C_API.ID_NULL | Attached library routine (webutil.pld - WEBUTIL_C_API package) | VIEW_EXCEL_REP program unit | Checks whether a WebUtil handle (Pointer, FunctionHandle, ParameterHandle, or ParameterList) is null by inspecting its internal `hnd` attribute; returns TRUE if the handle is null; used in VIEW_EXCEL_REP to validate the record group handle before processing report rows |
| DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Oracle built-in package routine | PRE-FORM trigger; KEY-EXIT trigger | Registers or clears the current Oracle session's client information string; used to tag the session with the form module name for monitoring |
| DBMS_APPLICATION_INFO.SET_MODULE | Oracle built-in package routine | PRE-FORM trigger; KEY-EXIT trigger | Registers or clears the Oracle session's module name and action name for workload management and session monitoring |
| STOP_WATCH.START_TIMER | Package routine (STOP_WATCH package - `STOP_WATCH.pck`) | PRE-FORM trigger - conditional on application logging flag | Starts a performance timer for the session when application-level logging is enabled |
| WEB.SHOW_DOCUMENT | Attached library routine (WEBUTIL / DPL library) | PR_REMOVE_ASCII_CHR program unit | Opens a specified file path as a URL in the user's browser window using the WebUtil browser integration |

## 13. Package Procedure Specifications

*Behavioural requirements for each database package invoked from the form. Only packages referenced in the form XML that have a matching source `.pck` file in the input directory are listed. Descriptions are derived from the package bodies in the uploaded PCK sources.*

*No PCK files found - no `*.pck` source files were discovered in the input directory. Package specifications cannot be generated without uploaded PCK sources.*

## 14. Database Package Catalogue

*Detailed specifications for each database package routine called from the form, including signatures and business rules.*

*No PCK files found - no `*.pck` source files were discovered in the supplied source bundle. The database package catalogue cannot be generated without uploaded PCK sources.*

## 15. PLD Procedure Call Sites

*Maps each program-library routine to its call sites within triggers and program units. Behaviour descriptions are derived from the uploaded ``.pld`` sources.*

### DPL.pld (`general`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ASK_CONFIRM | Function | Function(confirm_msg VARCHAR2) RETURN NUMBER | Trigger: FT_CANCEL in Form, Trigger: FT_DEL in Form, Trigger: WHEN-BUTTON-PRESSED in WEBUTIL.DUMMY | Displays a confirmation dialog to the user with the supplied message and returns a numeric result indicating the user's choice. Called from the FT_CANCEL and FT_DEL form-level triggers to prompt the user before discarding changes or deleting records, and from the WEBUTIL.DUMMY WHEN-BUTTON-PRESSED trigger. |
| DISP_TEXT | Procedure | Procedure(text_string VARCHAR2, title_string VARCHAR2) | ProgramUnit: PR_REMOVE_ASCII_CHR, Trigger: FT_INSERT in Form, Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: WHEN-BUTTON-PRESSED in CB_BLK.SUBMIT, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.OLD_NEW_LOC_CD, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_BONUS_YN, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_CL_TODT, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_DELR_CD, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_FROMDT, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_INV_TYPE, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_LOC_CD, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_SCHEME, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_STATUS_DESC, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_STATUS_TODT, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_TODT | Displays a message dialog box to the user. Accepts a text message and a title; if the title is 'ERROR' it shows the AL_ERRINFO alert styled as an error, otherwise it shows the AL_NOTE alert styled as a note. Used throughout the form to surface validation failures and informational messages. |
| RAISE_ERROR | Procedure | Procedure(mesg_code IN VARCHAR2) | Trigger: ON-ERROR in Form | Accepts a message code, looks up the corresponding message text and type, then displays the message via DISP_TEXT and raises FORM_TRIGGER_FAILURE for error-type messages. Called from the ON-ERROR trigger to handle ORA-02292 constraint violations. |

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``sr_exch_lyl_dlr_rep_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| CHECK_NULL | Procedure | Procedure(p_value IN VARCHAR2, column_title IN VARCHAR2) | ProgramUnit: VALIDATE_CN_MAIN | **COMMENTED OUT / INACTIVE** - Called from VALIDATE_CN_MAIN which is itself fully commented out. Previously validated that mandatory fields (plate number, model year, test drive dates) were not null before allowing form submission. |

**Total Active Routines:** 3 of 24 in DPL.pld source
**Inactive / commented-only routines:** 1

---

### webutil.pld (`WEBUTIL_CORE`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| CustomEventHandler | Procedure | Procedure(EventName in VARCHAR2, EventParameters in VARCHAR2) | Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_BROWSER_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_CLIENTINFO_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_C_API_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_FILETRANSFER_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_FILE_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_HOST_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_OLE_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_SESSION_FUNCTIONS | Central event-dispatch routine for the WebUtil infrastructure. Each WebUtil bean item fires WHEN-CUSTOM-ITEM-EVENT when the Java client layer raises a callback; the trigger passes the event name and its serialised parameter string to CustomEventHandler, which routes the call to the appropriate WebUtil package handler. This wiring is present across all eight functional WebUtil bean canvases embedded in the form. |

**Total Active Routines:** 1 of 39 in webutil.pld source

---

### webutil.pld (`WEBUTIL_C_API`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ID_NULL | Function | Function(handle IN Pointer) RETURN BOOLEAN | ProgramUnit: VIEW_EXCEL_REP | Checks whether a WebUtil handle (Pointer, FunctionHandle, ParameterHandle, or ParameterList) is null by inspecting its internal `hnd` attribute. Returns TRUE if the handle is null. Used in VIEW_EXCEL_REP to check whether a record group handle is valid before processing report rows. |

**Total Active Routines:** 1 of 28 in webutil.pld source

---

### webutil.pld (`WEBUTIL_FILE`)

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``sr_exch_lyl_dlr_rep_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| FILE_SAVE_DIALOG | Function | Function(directory_name Varchar2 := NULL, file_name Varchar2 := NULL, file_filter Varchar2 := NULL, title Varchar2 := NULL) RETURN Varchar2 | ProgramUnit: VIEW_EXCEL_REP | **COMMENTED OUT / INACTIVE** - Called from a commented-out code path within VIEW_EXCEL_REP. Previously used to present the client-side Save As dialog, allowing the user to choose a local file path and name for the exported Excel report before the file transfer was initiated. |

**Total Active Routines:** 0 of 25 in webutil.pld source
**Inactive / commented-only routines:** 1

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| ID | Service Name | Database Object | Input Parameters | Output | Business Function | API Endpoint Suggestion |
| -- | ------------ | --------------- | ---------------- | ------ | ----------------- | ----------------------- |
| MS-001 | Exchange/Loyalty Claim Report Service | MULDMS.SD_LOYLTY_EXCH_CLAIM, MULDMS.SH_INVOICE, MULDMS.SH_ORDBOOK, AM_DEALER_LOC | dealer_map_cd, loc_cd, parent_group, scheme (S/L), inv_type (I/D), bonus_yn (B/N/A), from_date, to_date, cl_from_date, cl_to_date, status_from_date, status_to_date, status, principal | CSV/JSON list of exchange/loyalty claim rows with full detail columns | Retrieves all exchange/loyalty claims matching the dealer, outlet, scheme, invoice type, bonus model, date ranges, and status filters; returns the claim-level detail required for the dealer report | `POST /api/v1/reports/exchange-loyalty-claims` |
| MS-002 | Dealer Location Lookup Service | AM_DEALER_LOC | principal_map_cd, parent_group (optional) | List of dealers with city, name, dealer code, for-code, group, map code | Provides the searchable list of dealers for the Dealer Details filter field | `GET /api/v1/dealers?principal={principal}&parent_group={group}` |
| MS-003 | Outlet Lookup Service | AM_DEALER_LOC | principal_map_cd, dealer_map_cd (optional) | List of outlets with outlet code, description, dealer code, for-code | Provides the searchable list of outlets for the Outlet Details filter field | `GET /api/v1/outlets?principal={principal}&dealer_map_cd={dealer}` |
| MS-004 | Claim Status Lookup Service | MULDMS.AM_LIST (list EXCH_LYL_STATUS) | principal_map_cd | List of valid claim status codes and descriptions | Provides the selectable status values for the Status filter field | `GET /api/v1/reference/claim-statuses?principal={principal}` |
| MS-005 | Dealer Legacy Identifier Resolution Service | AM_DEALER_LOC | parent_group, dealer_map_cd, loc_cd | Legacy parent_group, legacy dealer_map_cd, legacy loc_cd | Resolves the pre-reorganisation (legacy) identifiers for a given outlet to ensure historical claims are included in report queries | `GET /api/v1/dealers/{dealer_map_cd}/locations/{loc_cd}/legacy-identifiers` |
| MS-006 | Exchange Remarks Lookup Service | SF_GET_EXCH_LYL_REMARKS | reason_type (e.g. NCINV_REASON, NCINS_REASON), principal, indicator_code | Human-readable reason description | Decodes a document check indicator code into a readable description for each document type in an exchange/loyalty claim | `GET /api/v1/reference/exchange-remarks?type={reason_type}&code={indicator}&principal={principal}` |
| MS-007 | Exchange/Loyalty Bonus Calculation Service | SF_GET_TOTAL_BONUS, SF_GET_EXCH_SLAB, SF_GET_VIN_YOM | scheme, inv_date, region_cd, state_cd, for_cd, model_cd, sub_model_cd, fueltype_cd, bonus_type (BT/BM/BD/ST/SM), principal, old_car_age (or vin for YOM), channel, sales_type | Calculated bonus amount for the given bonus type | Calculates the total bonus, MSIL share, dealer share, and stock liquidation bonus/share for a claim given the vehicle and dealer parameters | `POST /api/v1/calculations/exchange-loyalty-bonus` |
| MS-008 | Copyright Declaration Service | SF_COPYRIGHT_DECLARATION | (none) | Copyright declaration text string | Returns the standard copyright declaration text for display on the report screen | `GET /api/v1/system/copyright-declaration` |
| MS-009 | Report File Export Service | VIEW_EXCEL_REP (form program unit) | query (SQL string), filename, column_name | CSV file written to server; browser-accessible URL | Executes a report query, writes the results to a CSV file on the report server, and returns a URL for the user to access the file | `POST /api/v1/reports/export-csv` |

**Total Microservices Identified: 9**

---

## 17. Workflows

| ID | Workflow Name | Trigger Event | Steps | Decision Points | End State |
| -- | ------------- | ------------- | ----- | --------------- | --------- |
| WF-001 | Form Initialisation | User opens the Exchange/Loyalty Dealer Report screen (PRE-FORM) | 1. Register session with module name via DBMS_APPLICATION_INFO. 2. If application logging is enabled, start the performance timer. | Is application logging flag set to enabled? - Yes: start timer / No: skip timer | Form is ready for user input; session is registered against the module |
| WF-002 | Filter Screen Reset | User triggers the form-clear action (KEY-CLRFRM) | 1. Clear all filter fields from the screen. 2. Set report description label to "Exchange/Loyalty Status Report". 3. Retrieve and display the copyright declaration text (SF_COPYRIGHT_DECLARATION). | None | All filter fields are blank; report title and copyright notice are displayed |
| WF-003 | Dealer Selection | User activates the Dealer Details field and selects a dealer from the lookup (KEY-LISTVAL / LV_DEALER) | 1. User opens the dealer lookup. 2. User selects a dealer. 3. Dealer code is populated in the Dealer Details field. 4. On field exit, WHEN-VALIDATE-ITEM checks that the field is not empty. | Is the Dealer Details field empty on exit? - Yes: show error and block navigation / No: proceed | Dealer Details field contains a valid dealer code |
| WF-004 | Outlet Selection | User activates the Outlet Details field and selects an outlet from the lookup (KEY-LISTVAL / LV_LOC) | 1. User opens the outlet lookup. 2. User selects an outlet. 3. Outlet code and description are populated. 4. On field exit, WHEN-VALIDATE-ITEM checks that the field is not empty. | Is the Outlet Details field empty on exit? - Yes: show error and block navigation / No: proceed | Outlet Details field contains a valid outlet code |
| WF-005 | Invoice Date Range Entry | User enters the Invoice From Date and optionally adjusts the Invoice To Date | 1. User enters Invoice From Date. 2. WHEN-VALIDATE-ITEM checks the date is not blank, not in the future, and not after the To Date. 3. If valid, system auto-calculates Invoice To Date as From Date + 9 days (capped at today). 4. User may adjust Invoice To Date. 5. WHEN-VALIDATE-ITEM on To Date checks: From Date entered, To Date ≥ From Date, not in future, range ≤ 6 months. | Is From Date blank? - Yes: error / No: continue. Is From Date in the future? - Yes: error / No: continue. Is To Date < From Date? - Yes: error / No: continue. Does range exceed 6 months? - Yes: error / No: continue | Both Invoice From Date and Invoice To Date are set and validated; To Date defaults to From Date + 9 days |
| WF-006 | Dealer Submission Date Range Entry (Optional) | User optionally enters a Dealer Submission From Date | 1. User enters Dealer Submission From Date (optional). 2. WHEN-VALIDATE-ITEM checks: not in the future, not before Invoice From Date, not after Dealer Submission To Date. 3. If valid, system auto-calculates Dealer Submission To Date as last day of month following From Date (capped at today). 4. User may adjust To Date. 5. WHEN-VALIDATE-ITEM on To Date checks: From Date entered, To Date ≥ From Date, not in future, range ≤ 6 months. | Is the Dealer Submission From Date blank? - Yes: skip all checks / No: continue validation. Does each check fail? - Yes: error / No: continue | Dealer Submission date range is empty (no filter) or both dates are set and validated |
| WF-007 | Status Date Range Entry (Optional) | User optionally enters a Status (Accepted/Rejected/Clarification) From Date | 1. User enters Status From Date (optional). 2. WHEN-VALIDATE-ITEM checks: not in the future, not before Invoice From Date, not after Status To Date. 3. If valid, system auto-calculates Status To Date as last day of month following From Date (capped at today). 4. User may adjust To Date. 5. WHEN-VALIDATE-ITEM on To Date checks: From Date entered, To Date ≥ From Date, not in future, range ≤ 6 months. | Is the Status From Date blank? - Yes: skip all checks / No: continue validation. Does each check fail? - Yes: error / No: continue | Status date range is empty (no filter) or both dates are set and validated |
| WF-008 | Report Submission and Export | User presses the Submit Report button (WHEN-BUTTON-PRESSED on SUBMIT) | 1. Generate unique output filename from user ID and timestamp. 2. If Status is "Accepted", expand to include "Under Processing". 3. Check invoice date range ≤ 10 days. 4. Resolve bonus model filter codes. 5. Query dealer location master for legacy outlet identifiers. 6. Select appropriate report query branch (Invoice Type + Scheme + same/different dealer path). 7. Build dynamic SQL query string. 8. Call VIEW_EXCEL_REP to execute query, write CSV file, and open file in browser. | Is the invoice date range > 10 days? - Yes: error, stop / No: continue. Do current and legacy outlet identifiers match? - Yes: same-dealer query branch / No: different-dealer query branch. Is Invoice Type I with Scheme S? - Use Exchange C-Form query. Is Invoice Type D with Scheme S? - Use Exchange Direct Billing query. Is Invoice Type I without Scheme S? - Use C-Form non-S query. Is Invoice Type I in different-dealer path? - Use legacy C-Form query. Is Invoice Type D in different-dealer path? - Use legacy Direct Billing query. | Report CSV file written to server and opened in the user's browser for download; or error message displayed and no file produced |
| WF-009 | Form Exit and Session Cleanup | User triggers the form exit action (KEY-EXIT) | 1. Clear DBMS_APPLICATION_INFO client information (set to null). 2. Clear DBMS_APPLICATION_INFO module name and action (set to empty strings). 3. Exit the form without save validation. | None | Form is closed; Oracle session is no longer attributed to this module |
| WF-010 | Error Handling | Any error occurs during form use (ON-ERROR trigger) | 1. Check for invalid date error (code 50004) - display friendly message and abort. 2. Check for date format error (codes 50025/50026) - display friendly message and abort. 3. Check for non-numeric input (codes 40209/50016) - display friendly message and abort. 4. Check for item validation failure (code 40207) - display item error text and abort. 5. Check for child-record constraint violation (DBMS code -02292) - call GENERAL.RAISE_ERROR. 6. Check for concurrency conflict (codes 40654-40659) - display message, rollback, abort. 7. Check for any remaining SQL error (sqlcode ≠ 0) - display SQLERRM, rollback, abort. 8. If error code is 40401 or 40405 - suppress silently (null). | Which error category applies? - Routes to the appropriate message and handling action per each check | Error is handled: user sees a clear message (or silence for no-records codes); pending transaction rolled back if applicable; form trigger aborted |

**Total Workflows Identified: 10**

---

## 18. PLD-Backed Logic

*Maps shared library routines to their business function and suggested API contracts.*

### webutil.pld (`CLIENT_IMAGE`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | ID_NULL | Business Logic | ProgramUnit: VIEW_EXCEL_REP | /api/v1/pld/id_null | When a WebUtil handle is provided, then returns whether the handle is null to guard record group processing. |


---

### DPL.pld (`general`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | CHECK_NULL | Validation | ProgramUnit: VALIDATE_CN_MAIN | /api/v1/pld/check_null | **COMMENTED OUT / INACTIVE** - When a mandatory field value is null, then raises a validation error with the field name; called only from inactive VALIDATE_CN_MAIN. |
| PLD-002 | DISP_TEXT | Business Logic | ProgramUnit: PR_REMOVE_ASCII_CHR, Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: WHEN-BUTTON-PRESSED in CB_BLK.SUBMIT, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.OLD_NEW_LOC_CD, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_BONUS_YN, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_CL_TODT, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_DELR_CD, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_FROMDT, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_INV_TYPE, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_LOC_CD, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_SCHEME, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_STATUS_DESC, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_STATUS_TODT, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_TODT | /api/v1/pld/disp_text | When a message and title are provided, then displays an alert dialog to the user with the appropriate style (error or note). |
| PLD-003 | RAISE_ERROR | Validation | Trigger: ON-ERROR in Form | /api/v1/pld/raise_error | When an error message code is received, then looks up the message, displays it to the user, and raises form trigger failure for error-type messages. |


---

### D2kwutil.pld (`Win_API`)

*No routines from ``D2kwutil.pld`` are referenced in ``sr_exch_lyl_dlr_rep_fmb.xml``.*

---

---

## 19. PCK-Backed Logic

*Maps database package routines to their business rules and suggested API contracts.*

*No package routines from the available PCK files are referenced in ``sr_exch_lyl_dlr_rep_fmb.xml``.*

---

---

## 20. System Interfaces

### 20.1 Database Integrations

| Interface Name | Type | Purpose | Data Flow | Error Handling |
| -------------- | ---- | ------- | --------- | -------------- |
| Exchange/Loyalty Claim Data (MULDMS.SD_LOYLTY_EXCH_CLAIM) | Oracle database table (SELECT) | Provides the claim-level records that form the basis of the report output; each row represents one exchange or loyalty claim | Form -> DB: query parameters (dealer, outlet, scheme, dates, status, bonus model); DB -> Form: claim rows with all detail columns | Dynamic SQL query failure is caught by the VIEW_EXCEL_REP exception handler, which displays *"Error  - "* followed by the system error code and text |
| Dealer Location Master (AM_DEALER_LOC) | Oracle database table (SELECT) | Supplies the legacy/pre-reorganisation identifiers for the selected outlet, and provides dealer name, region, state, city, and channel in report output rows | Form -> DB: parent_group, dealer_map_cd, loc_cd from session globals; DB -> Form: legacy identifiers and dealer attributes | Any failure during the legacy identifier SELECT would propagate as an unhandled SQL error, caught by ON-ERROR and reported via SQLERRM |
| Invoice Header (MULDMS.SH_INVOICE) | Oracle database table (SELECT) | Provides new-car invoice attributes (invoice number, date, model, variant, chassis, engine, VIN, customer name, sales type) joined to claim rows in the report query | DB -> Form (report query): invoice fields included in each report output row | Query failure handled by VIEW_EXCEL_REP exception handler |
| Order Book (MULDMS.SH_ORDBOOK) | Oracle database table (SELECT) | Links invoices to their originating orders in the report query | DB -> Form (report query): joined on order_num, dealer, outlet | Query failure handled by VIEW_EXCEL_REP exception handler |
| Trade-In Vehicle Evaluation (MULDMS.SH_TV_EVAL / SH_TV_EVAL) | Oracle database table (SELECT) | Provides old-car details and Vahan verification fields (registration date, VIN, owner details, state, city, model variant, colour, fuel, manufacturing date, emission, RC status, road tax, body type, PUCC) | DB -> Form (report query): Vahan and trade-in columns included in report output | Query failure handled by VIEW_EXCEL_REP exception handler |
| Vahan Check Detail (DMS_VAHAN_CHECK_DTL) | Oracle database table (SELECT) | Provides results of third-party Vahan vehicle history verification for new cars | DB -> Form (report query): new-car Vahan check fields in C-Form claim output | Query failure handled by VIEW_EXCEL_REP exception handler |
| Invoice Charges (SD_INV_CHARGES) | Oracle database table (SELECT) | Provides dealer exchange charge amounts (charge type EXB) used to calculate the DISC Given by Dealer column | DB -> Form (report query): charge amount sub-query in report SELECT | Query failure handled by VIEW_EXCEL_REP exception handler |
| Reference/Dimension Tables (MULDMS.AM_LIST, MULDMS.GM_MOD, MULDMS.GM_VAR, MULDMS.GM_STATE, MULDMS.GM_CITY, MULDMS.SM_DMSPOC_MAKE_MODEL_MAS, GM_VAR, AM_LIST) | Oracle database tables (SELECT) | Supply description lookups for status codes, claim categories, sales types, relations, channels, model and variant names, state and city names used in the report output columns | DB -> Form (report query): description fields decoded inline in the SELECT list | Query failure handled by VIEW_EXCEL_REP exception handler |
| Claim Status Record Groups (RG_STATUS - MULDMS.AM_LIST) | Oracle database record group query | Populates the Status filter lookup with valid claim status codes and descriptions | DB -> Form: status code and description list loaded into LV_STATUS lookup | N/A - record group populated at session/lookup level |
| Dealer Record Groups (RG_DEALER - AM_DEALER_LOC) | Oracle database record group query | Populates the Dealer Details lookup with available dealers | DB -> Form: dealer city, name, code, group loaded into LV_DEALER lookup | N/A - record group populated at session/lookup level |
| Outlet Record Groups (RG_LOC - AM_DEALER_LOC) | Oracle database record group query | Populates the Outlet Details lookup with available outlets | DB -> Form: outlet code, description, dealer code loaded into LV_LOC lookup | N/A - record group populated at session/lookup level |
| Oracle Session Monitor (DBMS_APPLICATION_INFO) | Oracle built-in package (CALL) | Registers and de-registers the form module name against the user's Oracle database session for monitoring and diagnostics | Form -> DB: module name 'sr_exch_lyl_dlr_rep' set at form open; empty string set at form exit | No error handling; failures would be silent |

### 20.2 External System Integrations

This form does not integrate with any external systems outside the Oracle database. The WEBUTIL attached library provides client-side file transfer and browser-display capabilities, but these are form-platform utilities rather than integrations with an external business system. The report output file is opened in the user's browser by the form itself after being written to the server path.

| System Name | Integration Type | Purpose | Protocol | Endpoint | Data Exchange | Success / Error Codes |
| ----------- | ---------------- | ------- | -------- | -------- | ------------- | --------------------- |
| Oracle WebUtil (WEBUTIL library) | Attached form library (client-side utility) | Provides client-server file transfer and browser document display capabilities used to open the generated CSV report in the user's browser | Oracle Forms WebUtil protocol (server-side file URL via WEB.SHOW_DOCUMENT) | Server report path read from `/reports/DMS/excelpath.txt` | Form -> Client: file URL path constructed from server path + filename; user's browser opens the CSV | Exception during file display caught by VIEW_EXCEL_REP exception handler - *"Error  - "* + error code + error text |

### 20.3 Report Integrations

| Report Name | Report Server | Parameters | Output Format | Trigger |
| ----------- | ------------- | ---------- | ------------- | ------- |
| rep.rdf | INFERRED - Oracle Reports / DMS report server | Dealer code, outlet code, scheme, invoice type, bonus model, invoice from/to dates, dealer submission from/to dates, status from/to dates, status, principal (INFERRED - from the form's filter fields) | INFERRED - report file output (RDF format) | Report object declaration in form XML (object handle: REPORT_CALL); not invoked by any active trigger - the active report generation path uses VIEW_EXCEL_REP to produce a CSV file |

---

### 20.3.1 Parameters Passed to the Report

This form does not pass parameters to an Oracle Report. No report parameters were identified in the form sources.

## 21. Procedure and Function Business Rule Catalogue

End-to-end business requirement specification for every stored procedure and function referenced by the SR_EXCH_LYL_DLR_REP form.

### 21.1 Catalogue Index

66 procedures/functions - each SP ID links to its detailed specification in Section 21.2.

| SP Index | Routine Name |
| :--- | :--- |
| [SP-001](#SP-001--VIEW_EXCEL_REP) | VIEW_EXCEL_REP |
| [SP-002](#SP-002--D2KWUTIL.ATTEMPT_DLL_LOAD) | D2KWUTIL.ATTEMPT_DLL_LOAD |
| [SP-003](#SP-003--D2KWUTIL.D2KWUTIL_DEBUGSTRING) | D2KWUTIL.D2KWUTIL_DEBUGSTRING |
| [SP-004](#SP-004--D2KWUTIL.D2KWUTIL_GETDOSENV) | D2KWUTIL.D2KWUTIL_GETDOSENV |
| [SP-005](#SP-005--D2KWUTIL.D2KWUTIL_GETREGKEY) | D2KWUTIL.D2KWUTIL_GETREGKEY |
| [SP-006](#SP-006--D2KWUTIL.TRANSLATETYPE) | D2KWUTIL.TRANSLATETYPE |
| [SP-007](#SP-007--GENERAL.ASK_CONFIRM) | GENERAL.ASK_CONFIRM |
| [SP-008](#SP-008--GENERAL.DISP_TEXT) | GENERAL.DISP_TEXT |
| [SP-009](#SP-009--GENERAL.RAISE_ERROR) | GENERAL.RAISE_ERROR |
| [SP-010](#SP-010--WEBUTIL.BLOCKING) | WEBUTIL.BLOCKING |
| [SP-011](#SP-011--WEBUTIL.CHECKLIBS) | WEBUTIL.CHECKLIBS |
| [SP-012](#SP-012--WEBUTIL.CLEARCALLBACKTRIGGER) | WEBUTIL.CLEARCALLBACKTRIGGER |
| [SP-013](#SP-013--WEBUTIL.CLOSEBLOB) | WEBUTIL.CLOSEBLOB |
| [SP-014](#SP-014--WEBUTIL.CLOSEFILE) | WEBUTIL.CLOSEFILE |
| [SP-015](#SP-015--WEBUTIL.DOWNLOADFROMURLINT) | WEBUTIL.DOWNLOADFROMURLINT |
| [SP-016](#SP-016--WEBUTIL.ERROR) | WEBUTIL.ERROR |
| [SP-017](#SP-017--WEBUTIL.ERRORALERT) | WEBUTIL.ERRORALERT |
| [SP-018](#SP-018--WEBUTIL.EXECUTE) | WEBUTIL.EXECUTE |
| [SP-019](#SP-019--WEBUTIL.FCLOSE) | WEBUTIL.FCLOSE |
| [SP-020](#SP-020--WEBUTIL.FOPEN) | WEBUTIL.FOPEN |
| [SP-021](#SP-021--WEBUTIL.GETCALLBACKTRIGGER) | WEBUTIL.GETCALLBACKTRIGGER |
| [SP-022](#SP-022--WEBUTIL.GETCLIENTOSFAMILY) | WEBUTIL.GETCLIENTOSFAMILY |
| [SP-023](#SP-023--WEBUTIL.GETCLIENTSETTING) | WEBUTIL.GETCLIENTSETTING |
| [SP-024](#SP-024--WEBUTIL.GETIMPLCLASS) | WEBUTIL.GETIMPLCLASS |
| [SP-025](#SP-025--WEBUTIL.GETLASTERROR) | WEBUTIL.GETLASTERROR |
| [SP-026](#SP-026--WEBUTIL.GETLASTERRORARGS) | WEBUTIL.GETLASTERRORARGS |
| [SP-027](#SP-027--WEBUTIL.GETNUMBER) | WEBUTIL.GETNUMBER |
| [SP-028](#SP-028--WEBUTIL.GETOSFAMILY) | WEBUTIL.GETOSFAMILY |
| [SP-029](#SP-029--WEBUTIL.GETOUTPUT) | WEBUTIL.GETOUTPUT |
| [SP-030](#SP-030--WEBUTIL.GETPROPERTY) | WEBUTIL.GETPROPERTY |
| [SP-031](#SP-031--WEBUTIL.GETSTRING) | WEBUTIL.GETSTRING |
| [SP-032](#SP-032--WEBUTIL.GETVAR) | WEBUTIL.GETVAR |
| [SP-033](#SP-033--WEBUTIL.GET_LINE) | WEBUTIL.GET_LINE |
| [SP-034](#SP-034--WEBUTIL.GET_STANDARD_OUTPUT) | WEBUTIL.GET_STANDARD_OUTPUT |
| [SP-035](#SP-035--WEBUTIL.ID_NULL) | WEBUTIL.ID_NULL |
| [SP-036](#SP-036--WEBUTIL.INIT) | WEBUTIL.INIT |
| [SP-037](#SP-037--WEBUTIL.INITWEBUTIL) | WEBUTIL.INITWEBUTIL |
| [SP-038](#SP-038--WEBUTIL.ISERROR) | WEBUTIL.ISERROR |
| [SP-039](#SP-039--WEBUTIL.IS_OPEN) | WEBUTIL.IS_OPEN |
| [SP-040](#SP-040--WEBUTIL.LENGTH) | WEBUTIL.LENGTH |
| [SP-041](#SP-041--WEBUTIL.LOG) | WEBUTIL.LOG |
| [SP-042](#SP-042--WEBUTIL.POPULATEPROPERTYBUNDLE) | WEBUTIL.POPULATEPROPERTYBUNDLE |
| [SP-043](#SP-043--WEBUTIL.PUT_LINE) | WEBUTIL.PUT_LINE |
| [SP-044](#SP-044--WEBUTIL.READFROMPROPERTYBUNDLE) | WEBUTIL.READFROMPROPERTYBUNDLE |
| [SP-045](#SP-045--WEBUTIL.READTRANSFROMMSGBUNDLE) | WEBUTIL.READTRANSFROMMSGBUNDLE |
| [SP-046](#SP-046--WEBUTIL.REGISTERBEAN) | WEBUTIL.REGISTERBEAN |
| [SP-047](#SP-047--WEBUTIL.REGISTER_FUNCTION) | WEBUTIL.REGISTER_FUNCTION |
| [SP-048](#SP-048--WEBUTIL.RELEASE_PROCESS) | WEBUTIL.RELEASE_PROCESS |
| [SP-049](#SP-049--WEBUTIL.SETCLIENTSETTING) | WEBUTIL.SETCLIENTSETTING |
| [SP-050](#SP-050--WEBUTIL.SETDATA) | WEBUTIL.SETDATA |
| [SP-051](#SP-051--WEBUTIL.SETPROPERTY) | WEBUTIL.SETPROPERTY |
| [SP-052](#SP-052--WEBUTIL.SHOWBEANS) | WEBUTIL.SHOWBEANS |
| [SP-053](#SP-053--WEBUTIL.WRITEDATA) | WEBUTIL.WRITEDATA |
| [SP-054](#SP-054--WEBUTIL_CORE.CUSTOMEVENTHANDLER) | WEBUTIL_CORE.CUSTOMEVENTHANDLER |
| [SP-055](#SP-055--ADD_ERROR) | ADD_ERROR |
| [SP-056](#SP-056--ADD_EXTERNAL_ERRORS) | ADD_EXTERNAL_ERRORS |
| [SP-057](#SP-057--BOOLTOCHAR) | BOOLTOCHAR |
| [SP-058](#SP-058--CLEAN_ERROR_STACK) | CLEAN_ERROR_STACK |
| [SP-059](#SP-059--DEBUGLOG) | DEBUGLOG |
| [SP-060](#SP-060--GET_ENVIRONMENT_STRING) | GET_ENVIRONMENT_STRING |
| [SP-061](#SP-061--READ_REGISTRY) | READ_REGISTRY |
| [SP-062](#SP-062--REGISTER_FUNCTION_CALL) | REGISTER_FUNCTION_CALL |
| [SP-063](#SP-063--SETDEBUG) | SETDEBUG |
| [SP-064](#SP-064--SF_COPYRIGHT_DECLARATION) | SF_COPYRIGHT_DECLARATION |
| [SP-065](#SP-065--STRIPDIRSEP) | STRIPDIRSEP |
| [SP-066](#SP-066--WINDEBUG) | WINDEBUG |

---

### 21.2 Detailed Specifications

#### SP-001 - VIEW_EXCEL_REP

**Invoked From:**

- sr_exch_lyl_dlr_rep_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

Note: Data can only be fetched for 10 days (N/A / CN_MAIN)

---

**Purpose**

Generates a CSV export of a query-based record group and streams it to the end user as a downloadable Excel-compatible file. The procedure builds a dynamic record group from a supplied SQL query, writes the resulting data rows to a server-side CSV file, and then opens the file in a new browser window via a resolved URL. Data retrieval is constrained to a 10-day window as enforced by the calling screen (CN_MAIN).

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_file_name | VARCHAR2 | IN |
| p_query | VARCHAR2 | IN |
| p_column_name | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.FCLOSE ([SP-019](#SP-019--WEBUTIL.FCLOSE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.FOPEN ([SP-020](#SP-020--WEBUTIL.FOPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_LINE ([SP-033](#SP-033--WEBUTIL.GET_LINE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ID_NULL ([SP-035](#SP-035--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.PUT_LINE ([SP-043](#SP-043--WEBUTIL.PUT_LINE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Derive the output filename by concatenating the current Oracle Forms global user ID (`:global.userid`) with the current system date/time formatted as `YYYYMMDDHHMISS`, then appending the `.csv` extension.
- Step 2 - Validate the generated filename: if it is NULL, take no action (no file-save dialog is invoked); otherwise retain the generated name as the working filename.
- Step 3 - Check the filename for embedded spaces in folder path segments. If spaces are detected, redirect the file to the `C:\` root drive, strip the path to the bare filename, and display an informational message to the user.
- Step 4 - Attempt to locate an existing Forms record group named `DataRecordSet`. If one already exists (ID is not null), delete it to ensure a clean state before re-creation.
- Step 5 - Create a new record group named `DataRecordSet` from the dynamic SQL query supplied in `p_query`, then populate it and capture the total row count.
- Step 6 - Construct the server-side file path by prefixing the bare filename with the fixed directory `/iashome/ias/reports/printer/`.
- Step 7 - Open the server-side configuration file `/reports/DMS/excelpath.txt` for reading, read the URL base path from it, and close the file.
- Step 8 - Build the full download URL (`formserverpath`) by appending the bare filename to the URL base path read in Step 7.
- Step 9 - Open the server-side CSV file for writing using `TEXT_IO.FOPEN`.
- Step 10 - Locate the record group column identified by `p_column_name` within `DataRecordSet`.
- Step 11 - Iterate over all rows in the record group (1 through `the_rowcount`); for each row, retrieve the character cell value for the target column and write it as a line to the open CSV file using `TEXT_IO.PUT_LINE`.
- Step 12 - Close the CSV file using `TEXT_IO.FCLOSE`.
- Step 13 - Invoke `WEB.SHOW_DOCUMENT` with the resolved `formserverpath` URL and target `_blank` to open the generated file in a new browser window.
- Step 14 - If any exception occurs during processing, display an error message composed of the Forms `ERROR_CODE` and `ERROR_TEXT`, then raise `FORM_TRIGGER_FAILURE` to halt execution.

---
**Decision Points**

DP-001

Condition:
The generated filename (`vcFile`) is NULL after the user ID and timestamp concatenation.

TRUE:
No filename is assigned; processing continues without setting a filename (no file-save dialog is displayed).

FALSE:
The generated filename is assigned to the working variable `FILENAME` and processing continues.

---

DP-002

Condition:
The working `FILENAME` contains one or more space characters in a folder path segment (`INSTR(FILENAME,' ') > 0`).

TRUE:
The file path is overridden to `C:\` plus the bare filename only. An informational message is displayed to the user advising that the file will be stored on the C drive because the original path contains spaces.

FALSE:
The filename is used as-is; no path override or message is issued.

---

DP-003

Condition:
A record group named `DataRecordSet` already exists in the current Forms session (`NOT ID_NULL(rg_id)`).

TRUE:
The existing record group is deleted (`DELETE_GROUP`) before a new one is created, preventing duplicate group errors.

FALSE:
No deletion is performed; a new record group is created directly.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The output filename must be unique per user session; it is derived by combining the logged-in user ID (`:global.userid`) with the precise system timestamp (`YYYYMMDDHHMISS`), ensuring no two concurrent sessions produce the same filename.
- BR-002 - The CSV file extension (`.csv`) must always be appended to the generated filename so that the file is recognised as Excel-compatible when opened by the end user.
- BR-003 - File paths containing spaces in any folder name are not permitted; the system automatically redirects the output to the `C:\` root directory and notifies the user.
- BR-004 - The record group `DataRecordSet` must be in a clean state before each export; any pre-existing group with that name must be deleted prior to re-creation.
- BR-005 - The dynamic SQL query driving the export is supplied entirely by the caller (`p_query`); this procedure does not modify or validate the query content.
- BR-006 - Only the single column identified by `p_column_name` is written to the CSV output; the procedure does not export all columns of the record group automatically.
- BR-007 - The server-side base URL path for the downloadable file must be read at runtime from the configuration file `/reports/DMS/excelpath.txt`; it is not hard-coded within this procedure.
- BR-008 - The generated file is served to the user by opening it in a new browser window (`_blank`); the user is not prompted with a save-as dialog.
- BR-009 - Data retrieval is restricted to a 10-day window as enforced by the calling screen (CN_MAIN); this procedure does not independently enforce that constraint.
- BR-010 - Any runtime exception must be surfaced to the user via a Forms message containing the error code and error text, and execution must be terminated by raising `FORM_TRIGGER_FAILURE`.

---
**Implementation Logic**

```plsql
PROCEDURE view_excel_rep(p_file_name VARCHAR2 DEFAULT NULL, p_query VARCHAR2,p_column_name VARCHAR2) IS	
  rg_name 				 		VARCHAR2(40) := 'DataRecordSet'; 
	rg_id 					 		RecordGroup; 
	gc_id 					 		GroupColumn; 
	urlFile1        TEXT_IO.FILE_TYPE;
	the_rowcount 		 		NUMBER;
	po_tot_rec    NUMBER (6);
	--po_part_tab   pk_part_search_new.part_tab_10;
	po_part_tab   pk_part_search_new.part_tab_11;
	po_err_msg    VARCHAR2 (3000);
	po_err_cd     NUMBER (10);
	low           NUMBER (10);
	high          NUMBER (10);
	remainder     NUMBER (10);
	order_by      VARCHAR2 (300);
	vcfile        varchar2(150);
	lv_user       varchar2(150);
	l_Old_URL     varchar2(500);	
		l_new_URL   varchar2(500);	
	v_string      varchar2(5000);
	bin_str       varchar2(250);
	errcode 				 		NUMBER; 
  FILENAME			   		VARCHAR2(4000);
  MYFILE 					 		TEXT_IO.FILE_TYPE;
  urlFile 					 	TEXT_IO.FILE_TYPE;
  urlPath							VARCHAR2(5000);
	l_alert 				 		NUMBER;
	server_file      		VARCHAR2(2000);
	file_transfer_bool	BOOLEAN;
	formserverpath   		VARCHAR2(2000);
begin
lv_user := name_in(':global.userid');  -- New line added after dpl change
vcFile:= lv_user||To_Char(Sysdate,'YYYYMMDDHHMISS');    -- New line added after dpl change
vcFile := vcFile||'.csv';
if vcFile is null then
	--FILENAME  := Webutil_file.FILE_SAVE_DIALOG;
	null;
else
	filename:=vcFile;
end if;
	If instr(FILENAME,' ') > 0 then
 		FILENAME := 'C:\'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
 		Message('File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default.');
 		message('  ');
	end if;

	rg_id := Find_Group( rg_name ); 
	IF NOT Id_Null(rg_id) THEN 
		Delete_Group( rg_id ); 
	END IF; 
	rg_id := Create_Group_From_Query( rg_name, p_query ); 
	errcode := Populate_Group( rg_id ); 
	the_rowcount := Get_Group_Row_Count( rg_id );
	/*IF the_rowcount > 65536 THEN  
		Message('Maximum number of rows in excel exceeded. It will truncate to 65535 rows.');
		Message('  ');
		CLEAR_MESSAGE;
		the_rowcount := 65535;
	END IF;*/
 	
	server_file := '/iashome/ias/reports/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	urlFile := Text_Io.Fopen('/reports/DMS/excelpath.txt','R');
	Text_Io.Get_Line(urlFile,urlPath);
	Text_Io.Fclose(urlFile);
	formserverpath := urlPath||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	MYFILE := TEXT_IO.FOPEN(server_file, 'W');
	gc_id := Find_Column( rg_name||'.'||p_column_name); 	
	for total_loop IN 1..the_rowcount
		loop
	  	V_STRING :=  GET_GROUP_CHAR_CELL(gc_id  , total_loop ); 
	  	text_io.put_line(myfile,v_string);
	  	--TEXT_IO.PUTF(MYFILE,V_STRING);  
		end loop;
      text_io.fclose(myfile);
   
 	
	 	web.show_document(formserverpath,'_blank');
	exception
		when others then
		Message('Error  - '||ERROR_CODE|| ERROR_TEXT);
		Raise Form_trigger_failure;
	end;
```

#### SP-002 - D2KWUTIL.ATTEMPT_DLL_LOAD

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Attempts to load a specified DLL into memory via ORA_FFI, optionally verifying the file's physical presence at a given directory path before loading. If a path is supplied, the procedure normalises it using STRIPDIRSEP, confirms the file exists by performing a test open, and then calls ORA_FFI.LOAD_LIBRARY. On success it optionally increments the package-level DLL load counter and marks the API as enabled. On any failure it marks the API as disabled and returns a null library handle, allowing the caller (REGISTER_FUNCTION_CALL) to handle the unavailability gracefully.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |
| TargetDLL | VARCHAR2 | IN |
| LoadCount | BOOLEAN | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |

---

**Dependencies**

- DEBUGLOG ([SP-059](#SP-059--DEBUGLOG)) - matched by member name
- STRIPDIRSEP ([SP-065](#SP-065--STRIPDIRSEP)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Receive the target directory path (IN OUT), the DLL filename, and a flag indicating whether the load counter should be incremented.
- Step 2 - If TargetPath is not null, normalise it by calling STRIPDIRSEP to strip any trailing directory separator and then appending a single backslash, ensuring a consistent path format regardless of how the caller supplied the value.
- Step 3 - Attempt to open the file at the concatenated path (TargetPath || TargetDLL) in read mode using TEXT_IO.FOPEN to confirm the file physically exists at the specified location.
- Step 4 - If the file open succeeds, immediately close the file handle via TEXT_IO.FCLOSE; the open was purely an existence check.
- Step 5 - If the file open raises any exception, log a diagnostic message via DEBUGLOG (severity 99, context 'Attempt_DLL_LOAD') identifying the DLL name and the path searched, then raise the BadLocation exception to abort further processing.
- Step 6 - Call ORA_FFI.LOAD_LIBRARY with TargetPath and TargetDLL to load the DLL into the Forms session.
- Step 7 - If the LoadCount flag is TRUE, increment the package-level DLL_LOAD_COUNT counter by 1 and set API_ENABLED to TRUE, recording that an additional DLL has been successfully loaded and the API surface is available.
- Step 8 - Return the ORA_FFI library handle (hDLL) to the caller.
- Step 9 - If any unhandled exception occurs during or after the ORA_FFI load attempt, set API_ENABLED to FALSE and return the null library handle to the caller.

---
**Decision Points**

DP-001

Condition: TargetPath IS NOT NULL

TRUE: Normalise the path with STRIPDIRSEP, append a backslash, and perform a file-existence check before attempting the DLL load.

FALSE: Skip path normalisation and file-existence check; proceed directly to ORA_FFI.LOAD_LIBRARY with a null path.

---

DP-002

Condition: TEXT_IO.FOPEN succeeds (file exists at TargetPath || TargetDLL)

TRUE: Close the file handle and continue to the ORA_FFI.LOAD_LIBRARY call.

FALSE: Log a diagnostic entry via DEBUGLOG and raise the BadLocation exception, preventing the load attempt.

---

DP-003

Condition: LoadCount parameter is TRUE (after a successful ORA_FFI.LOAD_LIBRARY call)

TRUE: Increment DLL_LOAD_COUNT by 1 and set API_ENABLED to TRUE.

FALSE: Return the library handle without updating the load counter or the API_ENABLED flag.

---

DP-004

Condition: An unhandled exception is raised during the ORA_FFI load or any subsequent step

TRUE: Set API_ENABLED to FALSE and return the null library handle to the caller.

FALSE: Normal execution path; library handle is returned as populated by ORA_FFI.LOAD_LIBRARY.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only the first directory path value is honoured; if multiple paths are embedded in TargetPath, STRIPDIRSEP is used to sanitise the value and a single backslash is appended, discarding any additional path segments.
- BR-002 - A non-null TargetPath must point to a location where the specified DLL file is physically present; failure to locate the file is treated as a hard error (BadLocation exception) and the load is not attempted.
- BR-003 - File existence is verified by a read-mode open via TEXT_IO; the file is closed immediately after a successful open and no content is read.
- BR-004 - When LoadCount is TRUE, the package-level DLL_LOAD_COUNT counter must be incremented and API_ENABLED set to TRUE upon every successful DLL load, maintaining an accurate count of loaded libraries.
- BR-005 - Any failure during or after the ORA_FFI.LOAD_LIBRARY call must result in API_ENABLED being set to FALSE and a null library handle being returned, ensuring the caller can detect and handle DLL unavailability without an unhandled exception propagating.

---
**Implementation Logic**

```plsql

FUNCTION  Attempt_DLL_Load  (TargetPath in out VARCHAR2, TargetDLL in VARCHAR2, LoadCount in BOOLEAN DEFAULT TRUE) return ORA_FFI.LibHandleType is
  hDLL  ORA_FFI.LibHandleType;
  hFile TEXT_IO.FILE_TYPE;
begin 
    	
  if TargetPath is not null then 
    -- Watch out for folks who put multiple Paths in here 
    -- Oh yes it's happened! Just use the first & throw the rest away
    -- Add trailing Directory Sep if required
    TargetPath := StripDirSep(TargetPath)||'\';
    
    -- Check that there is actually a file there.
    begin 
  	  hFile := TEXT_IO.FOPEN(TargetPath||TargetDLL,'R');
  	  TEXT_IO.FCLOSE(hFile);
    exception
  	  when others then
  	    Win_API_Debug.DebugLog(99,'Attempt_DLL_LOAD',TargetDLL||' not found in the specified location of "'||TargetPath||'"'); 
  		  raise BadLocation;
    end;
  end if;
  
  hDLL := ORA_FFI.LOAD_LIBRARY(TargetPath, TargetDLL);
  if LoadCount then 
    DLL_LOAD_COUNT  := DLL_LOAD_COUNT + 1;
    API_ENABLED  := TRUE;
  end if;
  return hDLL;
exception
  when others then 
    API_ENABLED := FALSE;
    return hDLL; /* Will be null */
end Attempt_DLL_Load;
```

#### SP-003 - D2KWUTIL.D2KWUTIL_DEBUGSTRING

**Invoked From:**

- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level interface to the external C-based D2KWUTIL library, allowing the calling routine (WINDEBUG) to pass a debug text string to the underlying native debug output function. The procedure acts as a PL/SQL-to-C foreign-function bridge, forwarding the supplied text to the C implementation identified by the given function handle.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the external C function handle (hFunc) and the debug text string (Text) as input parameters from the invoking routine WINDEBUG.
- Step 2 - Delegate execution to the external C function registered under pragma interface identifier 11265, passing both the function handle and the text string directly to the native library.
- Step 3 - Return control to the caller (WINDEBUG) upon completion of the external C call; no output value is produced.

---
**Decision Points**

No decision points are present. The procedure contains no conditional logic; it unconditionally forwards its input parameters to the external C function via the ORA_FFI pragma interface.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must be invoked with a valid ORA_FFI function handle (hFunc); the handle identifies the specific C function entry point within the D2KWUTIL native library and is required for the foreign-function call to succeed.
- BR-002 - The Text parameter carries the debug string to be output; no transformation or validation is applied to it before it is passed to the external C function.
- BR-003 - The procedure is declared with PRAGMA INTERFACE(C, d2kwutil_DebugString, 11265), meaning its entire execution is fulfilled by the external C runtime; no PL/SQL body logic exists and no database interactions are performed.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.
   
 PROCEDURE d2kwutil_DebugString (    hFunc       IN      ORA_FFI.funcHandleType,
                                     Text        IN      VARCHAR2);
 -- Pragmas
 PRAGMA INTERFACE(C,d2kwutil_DebugString,      11265);
```

#### SP-004 - D2KWUTIL.D2KWUTIL_GETDOSENV

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level foreign-function interface (FFI) wrapper that retrieves a DOS/operating-system environment variable value. It accepts a function handle obtained via ORA_FFI, passes the source environment variable name and an output buffer, and returns an integer status code indicating the outcome of the OS-level call. It is invoked exclusively by the GET_ENVIRONMENT_STRING stored procedure within D2kwutil.pld.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| SourceStr | VARCHAR2 | IN OUT |
| ExpandStr | VARCHAR2 | IN OUT |
| InBuffLen | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| SourceStr | VARCHAR2 | IN OUT |
| ExpandStr | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the ORA_FFI function handle (hFunc) that references the underlying OS environment-variable retrieval routine registered through Oracle's Foreign Function Interface.
- Step 2 - Accept the source environment variable name (SourceStr) as an IN OUT parameter to be passed to the OS call.
- Step 3 - Accept the expansion/output buffer (ExpandStr) as an IN OUT parameter that will be populated with the resolved environment variable value by the OS call.
- Step 4 - Accept the input buffer length (InBuffLen) that defines the maximum size of the ExpandStr buffer for the OS call.
- Step 5 - Delegate execution to the external OS function via the ORA_FFI mechanism using the supplied handle and parameters.
- Step 6 - Return a PLS_INTEGER status code to the caller (GET_ENVIRONMENT_STRING) reflecting the success or failure of the OS-level environment variable lookup.

---
**Decision Points**

No decision points are deterministically evidenced in the available implementation source. Only the function specification/declaration is present; no conditional branching logic is exposed.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be invoked with a valid ORA_FFI function handle (hFunc); the handle must have been registered prior to invocation, as the function delegates directly to the OS via ORA_FFI.
- BR-002 - ExpandStr must be allocated with sufficient capacity to hold the resolved environment variable value; the caller is responsible for supplying the correct buffer length via InBuffLen.
- BR-003 - Both SourceStr and ExpandStr are declared IN OUT, meaning the OS call may modify these values; the caller (GET_ENVIRONMENT_STRING) must handle the returned values of both parameters after the call.
- BR-004 - The integer return value is the authoritative indicator of the OS call outcome and must be evaluated by the invoking routine (GET_ENVIRONMENT_STRING) to determine whether the environment variable was successfully resolved.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_GetDOSEnv (   hFunc          IN      ORA_FFI.funcHandleType,
                                SourceStr      IN OUT  VARCHAR2,
                                ExpandStr      IN OUT  VARCHAR2,
                                InBuffLen      IN      PLS_INTEGER
                                ) RETURN PLS_INTEGER;
```

#### SP-005 - D2KWUTIL.D2KWUTIL_GETREGKEY

**Invoked From:**

- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

D2KWUTIL_GETREGKEY is a foreign-function interface (FFI) wrapper that retrieves a Windows Registry key value. Given a registry root, path, and entry name, it populates the RegValue output parameter with the corresponding registry data and returns an integer status code indicating the outcome of the read operation. It is invoked exclusively by the READ_REGISTRY stored procedure within D2kwutil.pld.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| RegRoot | PLS_INTEGER | IN |
| RegPath | VARCHAR2 | IN OUT |
| RegEntry | VARCHAR2 | IN OUT |
| RegValue | VARCHAR2 | IN OUT |
| RegValueLength | PLS_INTEGER | IN |
| RegDontExpand | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RegPath | VARCHAR2 | IN OUT |
| RegEntry | VARCHAR2 | IN OUT |
| RegValue | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that references the underlying native Windows Registry API entry point, along with the registry root identifier (RegRoot), registry path (RegPath), and entry name (RegEntry).
- Step 2 - Accept the buffer control parameters: RegValueLength (maximum length of the value to be retrieved) and RegDontExpand (flag controlling whether environment-variable strings within the registry value are expanded before return).
- Step 3 - Delegate execution to the native Windows Registry function via the ORA_FFI mechanism using the supplied hFunc handle, passing all input parameters to the external call.
- Step 4 - Receive the retrieved registry value into the RegValue IN OUT parameter, and receive any modified path or entry information back through RegPath and RegEntry.
- Step 5 - Return a PLS_INTEGER status code to the caller (READ_REGISTRY) reflecting the success or failure of the registry read operation.

---
**Decision Points**

No explicit decision points are determinable from the available source. Only the function specification is present; no PL/SQL body with conditional branching has been extracted. The sole implicit decision resides in the returned PLS_INTEGER status code, which the calling routine READ_REGISTRY is expected to evaluate to determine success or failure of the registry read.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be invoked with a valid ORA_FFI function handle (hFunc); this handle must have been registered prior to invocation, as the function relies entirely on it to locate and call the underlying native Windows Registry API.
- BR-002 - RegRoot must be a valid Windows Registry root constant (e.g., HKEY_LOCAL_MACHINE, HKEY_CURRENT_USER) expressed as a PLS_INTEGER; an invalid root will result in a failed status code.
- BR-003 - RegValueLength must accurately reflect the maximum buffer size allocated for RegValue to prevent truncation or overflow of the retrieved registry data.
- BR-004 - RegDontExpand controls whether REG_EXPAND_SZ environment-variable references within the registry value are resolved; callers must set this flag deliberately based on whether the raw or expanded string is required.
- BR-005 - RegPath and RegEntry are declared IN OUT; callers must supply non-null, correctly formatted values and must not assume these parameters are unchanged after the call returns.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_GetRegKey (    hFunc         IN      ORA_FFI.funcHandleType,
                                RegRoot        IN      PLS_INTEGER,
                                RegPath        IN OUT  VARCHAR2,
                                RegEntry       IN OUT  VARCHAR2,
                                RegValue       IN OUT  VARCHAR2,
                                RegValueLength IN      PLS_INTEGER,
                                RegDontExpand	 IN      PLS_INTEGER
                                ) return PLS_INTEGER;
```

#### SP-006 - D2KWUTIL.TRANSLATETYPE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

TranslateType is a lookup function that converts a string-based C data type name into its corresponding ORA_FFI integer constant. It is used internally by the D2KWUTIL package to resolve parameter and return-value type codes before registering external function calls via the Oracle Foreign Function Interface (ORA_FFI).

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DataType | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameter DataType (VARCHAR2) representing a C data type name as a string (e.g., 'INT', '*CHAR', 'DOUBLE').
- Step 2 - Convert the input value to uppercase and store it in the local variable vcType to ensure case-insensitive matching.
- Step 3 - Evaluate vcType against each recognised C data type string in a sequential IF-ELSIF chain.
- Step 4 - On the first matching condition, assign the corresponding ORA_FFI integer constant to the local return variable iRC (e.g., ORA_FFI.C_CHAR_PTR, ORA_FFI.C_INT, ORA_FFI.C_LONG_PTR, etc.).
- Step 5 - Return the resolved ORA_FFI integer constant (iRC) to the caller. If no condition matches, iRC remains uninitialised and NULL is returned implicitly.

---
**Decision Points**

DP-001
Condition: vcType = '*CHAR'
TRUE: Assign iRC := ORA_FFI.C_CHAR_PTR.
FALSE: Evaluate next condition.

DP-002
Condition: vcType = 'CHAR'
TRUE: Assign iRC := ORA_FFI.C_CHAR.
FALSE: Evaluate next condition.

DP-003
Condition: vcType = '*INT'
TRUE: Assign iRC := ORA_FFI.C_INT_PTR.
FALSE: Evaluate next condition.

DP-004
Condition: vcType = 'INT'
TRUE: Assign iRC := ORA_FFI.C_INT.
FALSE: Evaluate next condition.

DP-005
Condition: vcType = '*LONG'
TRUE: Assign iRC := ORA_FFI.C_LONG_PTR.
FALSE: Evaluate next condition.

DP-006
Condition: vcType = 'LONG'
TRUE: Assign iRC := ORA_FFI.C_LONG.
FALSE: Evaluate next condition.

DP-007
Condition: vcType = '*SHORT' OR vcType = '*BYTE'
TRUE: Assign iRC := ORA_FFI.C_SHORT_PTR (both pointer-to-short and pointer-to-byte map to the same constant).
FALSE: Evaluate next condition.

DP-008
Condition: vcType = 'SHORT' OR vcType = 'BYTE'
TRUE: Assign iRC := ORA_FFI.C_SHORT (both SHORT and BYTE map to the same constant).
FALSE: Evaluate next condition.

DP-009
Condition: vcType = '*DOUBLE'
TRUE: Assign iRC := ORA_FFI.C_DOUBLE_PTR.
FALSE: Evaluate next condition.

DP-010
Condition: vcType = 'DOUBLE'
TRUE: Assign iRC := ORA_FFI.C_DOUBLE.
FALSE: Evaluate next condition.

DP-011
Condition: vcType = '*VOID'
TRUE: Assign iRC := ORA_FFI.C_VOID_PTR.
FALSE: No assignment is made; iRC remains NULL and the function returns NULL to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The DataType input is normalised to uppercase before matching, making the type lookup case-insensitive.
- BR-002 - Pointer variants of a type are denoted by prefixing the type name with an asterisk (e.g., '*INT' for pointer-to-int); each pointer variant maps to a distinct ORA_FFI pointer constant separate from its non-pointer counterpart.
- BR-003 - The type names 'BYTE' and 'SHORT' are treated as equivalent and both resolve to ORA_FFI.C_SHORT; similarly '*BYTE' and '*SHORT' both resolve to ORA_FFI.C_SHORT_PTR.
- BR-004 - Only the eleven recognised type strings (*CHAR, CHAR, *INT, INT, *LONG, LONG, *SHORT, SHORT, *BYTE, BYTE, *DOUBLE, DOUBLE, *VOID) produce a valid ORA_FFI constant; any unrecognised DataType value results in a NULL return value.
- BR-005 - The function has no database interactions and performs no side effects; it is a pure lookup utility whose sole output is the resolved ORA_FFI integer constant.

---
**Implementation Logic**

```plsql
 
FUNCTION TranslateType(DataType in VARCHAR2) return PLS_INTEGER is
   -- Just a simple lookup of the types.
   vcType VARCHAR2(10) := UPPER(DataType);
   iRC    PLS_INTEGER;
begin 
  if vcType = '*CHAR' then 
    iRC := ORA_FFI.C_CHAR_PTR;
  elsif vcType = 'CHAR' then 
    iRC := ORA_FFI.C_CHAR;
  elsif vcType = '*INT' then 
    iRC := ORA_FFI.C_INT_PTR;
  elsif vcType = 'INT' then 
    iRC := ORA_FFI.C_INT;
  elsif vcType = '*LONG' then 
    iRC := ORA_FFI.C_LONG_PTR;
  elsif vcType = 'LONG' then 
    iRC := ORA_FFI.C_LONG;
  elsif vcType = '*SHORT' or vcType = '*BYTE'  then 
    iRC := ORA_FFI.C_SHORT_PTR;
  elsif vcType = 'SHORT' or vcType = 'BYTE' then 
    iRC := ORA_FFI.C_SHORT;
  elsif vcType = '*DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE_PTR;
  elsif vcType = 'DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE;  
  elsif vcType = '*VOID' then 
    iRC := ORA_FFI.C_VOID_PTR;      
  end if;
return iRC;
end TranslateType;
```

#### SP-007 - GENERAL.ASK_CONFIRM

**Invoked From:**

- sr_exch_lyl_dlr_rep_fmb.xml [Trigger: FT_CANCEL]
- sr_exch_lyl_dlr_rep_fmb.xml [Trigger: FT_DEL]
- sr_exch_lyl_dlr_rep_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

N/A

---

**Purpose**

ASK_CONFIRM is a reusable confirmation-dialog function that presents a configurable alert message to the user via the Oracle Forms alert AL_CONFIRM and returns a numeric flag indicating which button the user pressed. It is used by cancel, delete, and button-press triggers to obtain explicit user confirmation before allowing a destructive or significant action to proceed.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| confirm_msg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the caller-supplied confirmation message text through the confirm_msg input parameter.
- Step 2 - Set the message text of the predefined Oracle Forms alert AL_CONFIRM to the value of confirm_msg using SET_ALERT_PROPERTY.
- Step 3 - Display the AL_CONFIRM alert to the user by calling SHOW_ALERT and capture the button the user pressed in the local variable p_albtn_pressed.
- Step 4 - Evaluate p_albtn_pressed against the constant ALERT_BUTTON1.
- Step 5 - If the user pressed the first button (ALERT_BUTTON1), return 1 to the caller to signal confirmation.
- Step 6 - If the user pressed any other button, return 0 to the caller to signal cancellation or rejection.

---
**Decision Points**

DP-001

Condition: p_albtn_pressed = ALERT_BUTTON1 (the user selected the first/affirmative button on the AL_CONFIRM alert)

TRUE: The function returns 1, indicating the user confirmed the action.

FALSE: The function returns 0, indicating the user did not confirm the action (pressed a button other than ALERT_BUTTON1).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The confirmation message displayed to the user must be supplied by the caller at runtime; the function does not define or default the message text internally.
- BR-002 - The alert used for confirmation is always AL_CONFIRM; no other alert component is used by this function.
- BR-003 - A return value of 1 exclusively represents user confirmation (ALERT_BUTTON1 pressed); any other button press yields a return value of 0, treating all non-affirmative responses as rejection.
- BR-004 - The function is stateless and has no database interactions; its sole effect is to render the alert and relay the user's binary response to the calling trigger.

---
**Implementation Logic**

```plsql
FUNCTION ASK_CONFIRM( confirm_msg VARCHAR2)
                                      RETURN  NUMBER IS

    p_alert_name varchar2(10) := 'AL_CONFIRM' ;
    p_albtn_pressed number;
BEGIN
   set_alert_property(p_alert_name,alert_message_text,confirm_msg); 
   p_albtn_pressed := show_alert(p_alert_name);

   IF ( p_albtn_pressed = ALERT_BUTTON1 ) THEN
      return (1);
   ELSE
      return(0);
   END IF;
RETURN NULL; END;
```

#### SP-008 - GENERAL.DISP_TEXT

**Invoked From:**

- sr_exch_lyl_dlr_rep_fmb.xml [ProgramUnit: PR_REMOVE_ASCII_CHR]
- DPL.pld [StoredProcedure: GENERAL.RAISE_ERROR]
- sr_exch_lyl_dlr_rep_fmb.xml [Trigger: FT_INSERT]
- sr_exch_lyl_dlr_rep_fmb.xml [Trigger: ON-ERROR]
- sr_exch_lyl_dlr_rep_fmb.xml [Trigger: ON-MESSAGE]
- sr_exch_lyl_dlr_rep_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]
- sr_exch_lyl_dlr_rep_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

Note: Data can only be fetched for 10 days (N/A / CN_MAIN)

---

**Purpose**

Displays a modal alert dialog to the user containing a given message and title. The procedure selects the appropriate Oracle Forms alert template ('AL_ERRINFO' for error-level messages, 'AL_NOTE' for all other messages), applies the supplied title and message text to that alert, and presents it to the user. It is used across multiple triggers and program units in sr_exch_lyl_dlr_rep_fmb to surface validation errors, system messages, and informational notifications in a consistent manner.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| text_string | VARCHAR2 | IN |
| title_string | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message body (`text_string`) and the dialog title (`title_string`) as input parameters.
- Step 2 - Evaluate the title string (case-insensitive) to determine which alert template to use: if the title equals 'ERROR', assign the alert name 'AL_ERRINFO'; otherwise assign 'AL_NOTE'.
- Step 3 - Apply the supplied `title_string` as the title property of the selected alert using `SET_ALERT_PROPERTY`.
- Step 4 - Apply the supplied `text_string` as the message body of the selected alert using `SET_ALERT_PROPERTY`.
- Step 5 - Display the configured alert to the user via `SHOW_ALERT` and capture the user's response in a local variable (response is not returned to the caller).

---
**Decision Points**

DP-001

Condition:
UPPER(title_string) = 'ERROR'

TRUE:
The alert template 'AL_ERRINFO' is selected, indicating an error-level dialog is to be displayed.

FALSE:
The alert template 'AL_NOTE' is selected, indicating an informational or non-error dialog is to be displayed.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The alert template selection is driven exclusively by the title string; a title of 'ERROR' (case-insensitive) mandates use of the error alert ('AL_ERRINFO'), while any other title value mandates use of the note alert ('AL_NOTE').
- BR-002 - Both the title and the message text of the alert are always overwritten at runtime with the caller-supplied values before the alert is shown, ensuring the displayed content reflects the current context rather than any design-time default.
- BR-003 - The procedure does not return the user's alert response to the caller; the sole purpose is notification, and no downstream branching is performed based on the user's button selection within this procedure.

---
**Implementation Logic**

```plsql
PROCEDURE DISP_TEXT (text_string VARCHAR2,
                     title_string VARCHAR2 ) IS 
   p_alert_name varchar2(10) := 'AL_ERRINFO' ; 
   p_alert_id number;
BEGIN
   if upper(title_string)='ERROR' then
      p_alert_name := 'AL_ERRINFO' ; 
   else
      p_alert_name := 'AL_NOTE' ; 
   end if;
   set_alert_property(p_alert_name,TITLE,title_string);  
   set_alert_property(p_alert_name,alert_message_text,text_string);  
   p_alert_id := show_alert(p_alert_name); 
END;
```

#### SP-009 - GENERAL.RAISE_ERROR

**Invoked From:**

- sr_exch_lyl_dlr_rep_fmb.xml [Trigger: ON-ERROR]

---

**Screen:**

N/A

---

**Purpose**

Centralises error and notification handling for Oracle Forms triggers. Given a message code, the procedure constructs a display-ready message string and routes it to the appropriate modal dialogue via GENERAL.DISP_TEXT, then raises FORM_TRIGGER_FAILURE when the message severity requires the current form operation to be aborted.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| mesg_code | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-008](#SP-008--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message code (mesg_code) as the sole input parameter.
- Step 2 - Concatenate mesg_code with the (currently unresolved) mesg_text to form a composite display string in the format 'mesg_code : mesg_text'.
- Step 3 - Evaluate the mesg_type classification returned alongside the message text to determine the appropriate response category (Error, Note, or Caution).
- Step 4 - If mesg_type is 'E', set the dialogue title to 'Error', invoke GENERAL.DISP_TEXT to present the message to the user, and then raise FORM_TRIGGER_FAILURE to halt further form processing.
- Step 5 - If mesg_type is 'N', set the dialogue title to 'Note' and invoke GENERAL.DISP_TEXT to present the message; form processing continues normally.
- Step 6 - If mesg_type is 'C', set the dialogue title to 'Caution' and invoke GENERAL.DISP_TEXT to present the message; form processing continues normally.
- Step 7 - If mesg_type does not match any of the handled values ('E', 'N', 'C'), no dialogue is shown and no exception is raised.

---
**Decision Points**

DP-001

Condition:
mesg_type = 'E'

TRUE:
Set dialogue title to 'Error', call GENERAL.DISP_TEXT with the composed message and title, then raise FORM_TRIGGER_FAILURE to abort the current form operation.

FALSE:
Proceed to evaluate whether mesg_type = 'N' (DP-002).

---

DP-002

Condition:
mesg_type = 'N'

TRUE:
Set dialogue title to 'Note', call GENERAL.DISP_TEXT with the composed message and title; form processing continues.

FALSE:
Proceed to evaluate whether mesg_type = 'C' (DP-003).

---

DP-003

Condition:
mesg_type = 'C'

TRUE:
Set dialogue title to 'Caution', call GENERAL.DISP_TEXT with the composed message and title; form processing continues.

FALSE:
No action is taken; the procedure exits silently.

---
**Database Interactions**

- DB-001 - Read AM_PERMISSIONS - Reads data from AM_PERMISSIONS for lookup or validation.
**Business Rules**

- BR-001 - Every error or notification presented to the user must be identified by a message code; the code is always prepended to the message text in the format 'mesg_code : mesg_text' before display.
- BR-002 - A message classified as type 'E' (Error) must always terminate the current form operation by raising FORM_TRIGGER_FAILURE after displaying the error dialogue.
- BR-003 - A message classified as type 'N' (Note) is informational only; it must be displayed to the user but must not interrupt form processing.
- BR-004 - A message classified as type 'C' (Caution) is a warning; it must be displayed to the user but must not interrupt form processing.
- BR-005 - All user-facing message dialogues must be rendered through GENERAL.DISP_TEXT (SP-008); direct invocation of platform alert mechanisms from this procedure is not permitted.
- BR-006 - Message types other than 'E', 'N', or 'C' are silently ignored; no dialogue is shown and no exception is raised.

---
**Implementation Logic**

```plsql
PROCEDURE RAISE_ERROR ( mesg_code IN VARCHAR2 )IS
  mesg_type  varchar2(7); 
  mesg_text  varchar2(200) ;
  mesg_title varchar2(7);
  BEGIN
     -- murali 17.05.04 GENERAL.get_message(mesg_code,mesg_text,mesg_type );
     mesg_text:=mesg_code||' : '||mesg_text;		
     IF ( mesg_type = 'E' ) THEN
        mesg_title := 'Error' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
        raise FORM_TRIGGER_FAILURE;
     ELSIF ( mesg_type = 'N' ) THEN
        mesg_title := 'Note' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     ELSIF ( mesg_type = 'C' ) THEN
        mesg_title := 'Caution' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     END IF;
  END;     

/* PROCEDURE check_rights( 
pi_form_name in varchar2,
pi_user_id in number) IS
lv_x varchar2(1);
BEGIN
	
	begin
	SELECT substr(access_string, pi_user_id,1) 
	INTO   lv_x
	FROM   	am_permissions
	WHERE  form_name = pi_form_name
	AND SUBSTR(access_string,pi_user_id,1)='Y';
	exception 
		when no_data_found then
		  general.disp_text('You do not have the Permission to access this.','Error rr');
		  raise form_trigger_failure; 
		when too_many_rows then
		  general.disp_text('Many rows in USER_PERMISSIONS','Error ss');
		  raise form_trigger_failure;
		when others then
		       general.disp_text(sqlerrm,'Error mm');
		       raise form_trigger_failure;
	end;

	open_form(pi_form_name,activate,session);
END;
*/
```

#### SP-010 - WEBUTIL.BLOCKING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Executes a shell or system command in blocking mode, meaning the calling process waits for the command to complete before control is returned. The function delegates execution to WEBUTIL.EXECUTE, passing the supplied command string together with the BLOCKING_MODE constant to enforce synchronous behaviour.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.EXECUTE ([SP-018](#SP-018--WEBUTIL.EXECUTE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the command string (cmd) to be executed as an input parameter.
- Step 2 - Invoke WEBUTIL.EXECUTE, passing cmd as the command argument and BLOCKING_MODE as the execution mode flag.
- Step 3 - Return the PROCESS_ID value produced by WEBUTIL.EXECUTE to the caller.

---
**Decision Points**

No conditional decision points exist within this function. Execution follows a single, unconditional path: delegate to WEBUTIL.EXECUTE with BLOCKING_MODE and return the resulting PROCESS_ID.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The command must always be executed in blocking (synchronous) mode; the BLOCKING_MODE constant is hardcoded and cannot be overridden by the caller.
- BR-002 - The function returns a PROCESS_ID, allowing the caller to identify or reference the completed process after execution finishes.
- BR-003 - All actual command execution responsibility is delegated to WEBUTIL.EXECUTE (SP-018); WEBUTIL.BLOCKING introduces no additional processing logic of its own.

---
**Implementation Logic**

```plsql
  
  FUNCTION  Blocking(cmd in VARCHAR2) return PROCESS_ID is
  begin
    return Execute(cmd,BLOCKING_MODE);
  end Blocking;
```

#### SP-011 - WEBUTIL.CHECKLIBS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.CHECKLIBS verifies that all system libraries required by a given WebUtil package are present on the client machine at the correct version. For each library defined in the property bundle for the package, the procedure compares the installed version against the expected version and, where a mismatch or absence is detected, downloads the library from the configured URL to the client. It is invoked by WEBUTIL.REGISTERBEAN as part of the package registration sequence.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.DOWNLOADFROMURLINT ([SP-015](#SP-015--WEBUTIL.DOWNLOADFROMURLINT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTSETTING ([SP-023](#SP-023--WEBUTIL.GETCLIENTSETTING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-041](#SP-041--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-044](#SP-044--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READTRANSFROMMSGBUNDLE ([SP-045](#SP-045--WEBUTIL.READTRANSFROMMSGBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETCLIENTSETTING ([SP-049](#SP-049--WEBUTIL.SETCLIENTSETTING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the packageID input parameter, which identifies the WebUtil package whose required system libraries are to be checked.
- Step 2 - Enter a loop and, for each iteration, attempt to read a library specification entry from the property bundle using a fully qualified key composed of the client OS family, OS architecture, package ID, and a sequential library index (install.syslib.<OSFamily>.<OSArch>.<packageID>.<index>). Call WEBUTIL.READFROMPROPERTYBUNDLE to retrieve the value.
- Step 3 - If no entry is found for the OS-architecture-specific key, fall back to a less specific key omitting the OS architecture (install.syslib.<OSFamily>.<packageID>.<index>) via a second call to WEBUTIL.READFROMPROPERTYBUNDLE.
- Step 4 - If both lookups return NULL, exit the loop; all library entries for this package have been processed.
- Step 5 - Increment the library index counter and parse the retrieved library specification string into its constituent fields: library file name, expected file size, expected version string, and a progress-display flag, using positional pipe-delimited parsing.
- Step 6 - Call WEBUTIL.GETCLIENTSETTING with the key 'syslib.<libName>' to retrieve the version of the library currently recorded as installed on the client.
- Step 7 - Evaluate whether a download is required: the library must be downloaded if the installed version is NULL (not present), differs from the expected version, or the REDOWNLOAD_SYSLIB flag is set.
- Step 8 - If a download is required, resolve the download base URL by querying the property bundle in order of decreasing specificity: first by OS family and architecture (install.syslib.location.<OSFamily>.<OSArch>), then by OS family only (install.syslib.location.<OSFamily>), then by the generic key (install.syslib.location), using WEBUTIL.READFROMPROPERTYBUNDLE for each lookup and stopping at the first non-NULL result.
- Step 9 - Call WEBUTIL.DOWNLOADFROMURLINT with the resolved full URL (base URL concatenated with the library file name), the library name, a download-type indicator of 1 (system library install), the expected file size, the progress-display flag, and localised progress dialog title and subtitle strings retrieved via two calls to WEBUTIL.READTRANSFROMMSGBUNDLE (keys 'INST_PGRS_TITLE' and 'INST_PGRS_SUBTITLE').
- Step 10 - If WEBUTIL.DOWNLOADFROMURLINT returns TRUE (download succeeded), call WEBUTIL.SETCLIENTSETTING to record the newly installed version against the key 'syslib.<libName>' on the client.
- Step 11 - If WEBUTIL.DOWNLOADFROMURLINT returns FALSE (download failed), call WEBUTIL.LOG to write a failure message indicating which library could not be downloaded, flagging it as an error.
- Step 12 - Continue the loop to process the next library entry for the package.

---
**Decision Points**

DP-001

Condition: The OS-architecture-specific property bundle key (install.syslib.<OSFamily>.<OSArch>.<packageID>.<index>) returns a non-NULL library specification.

TRUE: Use the returned specification; skip the OS-architecture-agnostic fallback lookup.

FALSE: Attempt the fallback lookup using the key without OS architecture (install.syslib.<OSFamily>.<packageID>.<index>).

---

DP-002

Condition: The fallback library specification lookup (install.syslib.<OSFamily>.<packageID>.<index>) also returns NULL.

TRUE: No further library entries exist for this package; exit the processing loop.

FALSE: A library specification was found; continue processing this library entry.

---

DP-003

Condition: The installed version recorded on the client (via WEBUTIL.GETCLIENTSETTING) is NULL, differs from the expected version in the property bundle, or the REDOWNLOAD_SYSLIB flag is TRUE.

TRUE: Proceed to resolve the download URL and download the library.

FALSE: The library is already installed at the correct version; skip the download and advance to the next library.

---

DP-004

Condition: The OS-family-and-architecture-specific download URL key (install.syslib.location.<OSFamily>.<OSArch>) returns a non-NULL value.

TRUE: Use this URL as the download base; skip less specific URL lookups.

FALSE: Attempt the OS-family-only key (install.syslib.location.<OSFamily>).

---

DP-005

Condition: The OS-family-only download URL key (install.syslib.location.<OSFamily>) returns a non-NULL value.

TRUE: Use this URL as the download base; skip the generic URL lookup.

FALSE: Attempt the generic key (install.syslib.location).

---

DP-006

Condition: WEBUTIL.DOWNLOADFROMURLINT returns TRUE, indicating the library file was successfully downloaded to the client.

TRUE: Call WEBUTIL.SETCLIENTSETTING to record the installed version for the library on the client.

FALSE: Call WEBUTIL.LOG to record a download failure error message for the library.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Library specifications for a package are looked up using a hierarchy of property bundle keys ordered from most specific (OS family + architecture) to least specific (OS family only); the first non-NULL result is used, ensuring platform-tailored library lists take precedence over generic ones.
- BR-002 - Each library specification entry must encode, in pipe-delimited format, at minimum: the library file name (position 1), the expected file size in bytes (position 2), the expected version string (position 3), and a Boolean progress-display flag (position 4).
- BR-003 - A library is considered up to date only when a client-side version record exists (WEBUTIL.GETCLIENTSETTING returns non-NULL) and the recorded version exactly matches the version defined in the property bundle. Any deviation triggers a re-download.
- BR-004 - The REDOWNLOAD_SYSLIB flag, when TRUE, forces re-download of all system libraries regardless of the installed version, providing an administrative override mechanism.
- BR-005 - The download base URL is resolved using the same OS-family/architecture specificity hierarchy as the library specification lookup (architecture-specific -> family-specific -> generic), ensuring the correct binary variant is retrieved for the client platform.
- BR-006 - The client-side version record for a library (WEBUTIL.SETCLIENTSETTING key 'syslib.<libName>') is updated only upon confirmed successful download; a failed download leaves the existing client setting unchanged and is recorded as an error via WEBUTIL.LOG.
- BR-007 - Progress dialog labels presented during download are sourced exclusively from the translatable message bundle (WEBUTIL.READTRANSFROMMSGBUNDLE keys 'INST_PGRS_TITLE' and 'INST_PGRS_SUBTITLE'), ensuring localisation compliance for all client-facing installation messages.
- BR-008 - The procedure processes library entries sequentially by index starting at 1, and terminates automatically when no property bundle entry is found for the current index, requiring no explicit count of libraries to be passed by the caller.

---
**Implementation Logic**

```plsql
  
  PROCEDURE CheckLibs(packageID in VARCHAR2 ) is
    lib          PLS_INTEGER := 1;
    libSpec      VARCHAR2(200 char);
    libName      VARCHAR2(100 char);
    libSize      PLS_INTEGER;
    libVer       VARCHAR2(20 char);
    installedVer VARCHAR2(20 char);
    libProg      BOOLEAN := false;
    downloadURL  VARCHAR2(1000);
  BEGIN
    -- Read through the property bundle for 
    -- any libraries for this package
    LOOP
      libSpec := readFromPropertyBundle('install.syslib.'||to_char(m_clientOSFamily)||'.'||
             to_char(m_clientOSArch)||'.'||packageID||'.'||to_char(lib));
      if libSpec is null then
        libSpec := readFromPropertyBundle('install.syslib.'||to_char(m_clientOSFamily)||'.'||
             packageID||'.'||to_char(lib));
      end if;
      if libSpec is null then 
        exit;
      end if;
      lib := lib + 1;
      libName := Delimstr.getString(libSpec,1,true,'|');
      libSize := Delimstr.getNumber(libSpec,2,true,'|');
      libVer  := Delimstr.getString(libSpec,3,true,'|');
      libProg := (upper(Delimstr.getString(libSpec,4,true,'|'))='TRUE');

      -- OK we now have the library information
      -- let's check if it's installed
      installedVer := GetClientSetting('syslib.'||libname);
      if installedVer is null or installedVer <> libVer or REDOWNLOAD_SYSLIB then 
        -- need to download
        downloadURL := readFromPropertyBundle('install.syslib.location' || '.' || to_char(m_clientOSFamily) ||
                             '.' || to_char(m_clientOSArch));
        if downloadURL is null then
          downloadURL := readFromPropertyBundle('install.syslib.location' || '.' || to_char(m_clientOSFamily));
        end if;
        if downloadURL is null then
          downloadURL := readFromPropertyBundle('install.syslib.location');
        end if;
        if DownLoadFromURLInt(downloadURL||'/'||libName, 
                              libName,
                              1, -- syslib install download, special location
                              libSize,
                              libProg,
                              ReadTransFromMsgBundle('INST_PGRS_TITLE'),
                              ReadTransFromMsgBundle('INST_PGRS_SUBTITLE'),     
                              libName) then 
          SetClientSetting('syslib.'||libname,libVer);
        else
          log('Download of system library '||libName||' failed',true);
        end if;                          
      end if;
    END LOOP;
  END CheckLibs;
```

#### SP-012 - WEBUTIL.CLEARCALLBACKTRIGGER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Removes a previously registered callback entry from the internal callbacks collection using the supplied integer key. This procedure is called by WEBUTIL.SETDATA to clean up a specific callback trigger once it is no longer required, ensuring the collection does not retain stale or redundant entries.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| callbackKey | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the integer key (callbackKey) that identifies the callback entry to be removed from the internal m_callbacks collection.
- Step 2 - Check whether an entry with the supplied callbackKey currently exists in the m_callbacks collection.
- Step 3 - If the entry exists, delete it from the m_callbacks collection using the provided key.
- Step 4 - If the entry does not exist, take no action and allow the procedure to exit silently.

---
**Decision Points**

DP-001

Condition: m_callbacks.exists(callbackKey) - the m_callbacks collection contains an entry indexed by the supplied callbackKey.

TRUE: The entry is deleted from the m_callbacks collection via m_callbacks.delete(callbackKey).

FALSE: No action is taken; the procedure exits without modifying the collection.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A callback entry may only be deleted if it is confirmed to exist in the m_callbacks collection; the procedure must not raise an error when the supplied key is absent.
- BR-002 - The callbackKey parameter must be a PLS_INTEGER value that corresponds to the index used when the callback was originally registered in the m_callbacks collection.
- BR-003 - Only the single entry identified by callbackKey is removed; all other entries in the m_callbacks collection remain unaffected.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ClearCallbackTrigger(callbackKey in PLS_INTEGER) is
  begin
    if m_callbacks.exists(callbackKey) then 
      m_callbacks.delete(callbackKey);  
    end if;
  end ClearCallbackTrigger;
```

#### SP-013 - WEBUTIL.CLOSEBLOB

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open BLOB handle identified by its checksum value. The procedure delegates the close operation to the WebUtil_DB layer, returning a boolean result that indicates whether the BLOB was successfully closed. It is invoked by WEBUTIL.SETDATA as part of BLOB lifecycle management.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| checksum | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the checksum (PLS_INTEGER) that uniquely identifies the open BLOB handle to be closed.
- Step 2 - Delegate the close operation to WebUtil_DB.CloseBlob, passing the checksum as the sole argument.
- Step 3 - Return the boolean result produced by WebUtil_DB.CloseBlob to the calling routine, indicating success or failure of the close operation.

---
**Decision Points**

No decision points are present in the implementation logic. The function unconditionally delegates to WebUtil_DB.CloseBlob and returns its result without branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The checksum parameter must identify a previously opened BLOB handle; the function passes it directly to WebUtil_DB.CloseBlob without independent validation.
- BR-002 - The outcome of the close operation is determined entirely by WebUtil_DB.CloseBlob; WEBUTIL.CLOSEBLOB returns that result unchanged to the caller.
- BR-003 - The function must be called as part of BLOB lifecycle management to ensure BLOB handles are properly released after use.

---
**Implementation Logic**

```plsql

  FUNCTION  CloseBlob(checksum in PLS_INTEGER) return BOOLEAN is
  BEGIN
    return WebUtil_DB.CloseBlob(checksum);
  END CloseBlob;
```

#### SP-014 - WEBUTIL.CLOSEFILE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open server-side file resource represented by a Java object handle. The procedure delegates the close operation to the native Java class oracle/forms/webutil/fileTransfer/AppServerFileReader by invoking its closeFile method via the JNI bridge, returning a Boolean result that indicates whether the file was successfully closed.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java object handle (obj) that references the open AppServerFileReader file resource on the application server.
- Step 2 - Clear the JNI argument list by setting args to NULL, ensuring no stale arguments are passed to the Java method.
- Step 3 - Invoke the closeFile method on the AppServerFileReader Java class through JNI.CALL_BOOLEAN_METHOD, passing the object handle and the method signature '()Z' (no arguments, Boolean return).
- Step 4 - Return the Boolean result produced by the Java method to the caller, indicating success (TRUE) or failure (FALSE) of the close operation.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function unconditionally clears the argument list and delegates the close operation to the Java layer, returning whatever Boolean value the JNI call produces.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file close operation must be performed through the oracle/forms/webutil/fileTransfer/AppServerFileReader Java class; no direct PL/SQL file-handling is used.
- BR-002 - The JNI argument list must be explicitly reset to NULL before invoking the Java method to prevent unintended arguments from being passed to the closeFile call.
- BR-003 - The function returns a Boolean value; callers are responsible for evaluating the return value to determine whether the file was closed successfully.

---
**Implementation Logic**

```plsql
  FUNCTION closeFile(
    obj   ORA_JAVA.JOBJECT) RETURN BOOLEAN IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_BOOLEAN_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'closeFile', '()Z', args); 
  END;
```

#### SP-015 - WEBUTIL.DOWNLOADFROMURLINT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Downloads a file from a specified URL to a client-side destination by constructing a delimited instruction string and dispatching it to the WebUtil Core bean via property set/get. The function returns TRUE if the download completes successfully and FALSE if a recoverable error occurs. It supports optional progress-indicator parameters and a special destination mode to control where the file is written on the client.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| specialDestination | PLS_INTEGER | IN |
| fileSize | PLS_INTEGER | IN |
| withProgress | BOOLEAN | IN |
| progressTitle | VARCHAR2 | IN |
| progressSubTitle | VARCHAR2 | IN |
| progressMessage | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Validate that sourceURL is not null; if null, raise the URL_NULL exception.
- Step 2 - Validate that clientDestination is not null; if null, raise the CLIENT_FILE_NULL exception.
- Step 3 - Evaluate specialDestination: if null, negative, or greater than 2, append '0' followed by the pipe separator to submitString; otherwise append the numeric value of specialDestination followed by the separator.
- Step 4 - Evaluate fileSize: if null, append '0' followed by the separator to submitString; otherwise append the numeric value of fileSize followed by the separator.
- Step 5 - Evaluate withProgress: if null or FALSE, append 'N' followed by the separator to submitString; otherwise append 'Y' followed by the separator.
- Step 6 - Append sourceURL, clientDestination, progressTitle (defaulting to a single space if null), progressSubTitle (defaulting to a single space if null), and progressMessage (defaulting to a single space if null) to submitString, each delimited by the pipe separator.
- Step 7 - Call WebUtil_Core.setProperty with the WUC_PACKAGE constant, the property name 'WUC_URL_DOWNLOAD', the assembled submitString, and the synchronous flag TRUE to dispatch the download instruction to the WebUtil bean.
- Step 8 - Call WebUtil_Core.getProperty with the same package constant and property name to retrieve the outcome reported by the bean.
- Step 9 - Return TRUE if the retrieved result equals 'TRUE'; otherwise return FALSE.

---
**Decision Points**

DP-001

Condition: sourceURL IS NULL

TRUE: Raise the URL_NULL exception, which is caught in the EXCEPTION block; WebUtil_Core.Error is called with error code 25 referencing 'WEBUTIL_CORE.DownloadFromURLInt', and the function returns FALSE.

FALSE: Continue to the clientDestination validation.

---

DP-002

Condition: clientDestination IS NULL

TRUE: Raise the CLIENT_FILE_NULL exception, which is caught in the EXCEPTION block; WebUtil_Core.Error is called with error code 130 referencing 'WEBUTIL_CORE.DownloadFromURLInt', and the function returns FALSE.

FALSE: Continue to building the submitString.

---

DP-003

Condition: specialDestination IS NULL OR specialDestination < 0 OR specialDestination > 2

TRUE: Append the default value '0' and the separator to submitString.

FALSE: Append the actual numeric value of specialDestination and the separator to submitString.

---

DP-004

Condition: fileSize IS NULL

TRUE: Append '0' and the separator to submitString.

FALSE: Append the numeric value of fileSize and the separator to submitString.

---

DP-005

Condition: withProgress IS NULL OR withProgress = FALSE

TRUE: Append 'N' and the separator to submitString, indicating no progress indicator is required.

FALSE: Append 'Y' and the separator to submitString, indicating a progress indicator should be displayed.

---

DP-006

Condition: WebUtil_Core.BEAN_NOT_REGISTERED exception raised during setProperty or getProperty

TRUE: Call WebUtil_Core.ErrorAlert to notify that the implementing bean class was not found, then raise FORM_TRIGGER_FAILURE to halt form processing.

FALSE: Normal execution continues.

---

DP-007

Condition: WebUtil_Core.PROPERTY_ERROR exception raised during setProperty or getProperty

TRUE: Raise FORM_TRIGGER_FAILURE to halt form processing.

FALSE: Normal execution continues.

---

DP-008

Condition: The result string returned by WebUtil_Core.getProperty equals 'TRUE'

TRUE: The function returns TRUE, indicating the download succeeded.

FALSE: The function returns FALSE, indicating the download did not succeed.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A source URL must be supplied; invoking the function with a null sourceURL is not permitted and results in an error being logged via WebUtil_Core.Error (code 25) and a FALSE return value.
- BR-002 - A client destination path must be supplied; invoking the function with a null clientDestination is not permitted and results in an error being logged via WebUtil_Core.Error (code 130) and a FALSE return value.
- BR-003 - The specialDestination parameter is only valid when it holds an integer value of 0, 1, or 2; any null, negative, or out-of-range value is silently normalised to 0 before the instruction string is assembled.
- BR-004 - A null fileSize is treated as 0, ensuring the downstream bean always receives a numeric file-size token rather than an empty field.
- BR-005 - Progress-indicator display is opt-in; a null or FALSE withProgress value suppresses the progress UI ('N'), while an explicit TRUE activates it ('Y').
- BR-006 - All optional text parameters for the progress indicator (progressTitle, progressSubTitle, progressMessage) must never be transmitted as null to the bean; each defaults to a single space character to preserve the integrity of the pipe-delimited submitString.
- BR-007 - If the WebUtil bean is not registered in the runtime environment, the function must not return silently; it must alert the user and raise FORM_TRIGGER_FAILURE to prevent further form processing.
- BR-008 - A property error returned by the WebUtil Core layer is treated as a fatal condition; the function raises FORM_TRIGGER_FAILURE rather than returning FALSE, distinguishing infrastructure failures from normal download failures.

---
**Implementation Logic**

```plsql
  
  FUNCTION DownLoadFromURLInt(sourceURL          in VARCHAR2, 
                              clientDestination  in VARCHAR2, 
                              specialDestination in PLS_INTEGER default 0,                             
                              fileSize           in PLS_INTEGER default 0, 
                              withProgress       in BOOLEAN default false,
                              progressTitle      in VARCHAR2 default null,
                              progressSubTitle   in VARCHAR2 default null,
                              progressMessage    in VARCHAR2 default null) return BOOLEAN is
    result       VARCHAR2(6) := 'FALSE';
    submitString VARCHAR2(4000 char);
    sep          VARCHAR2(1) := '|';
  BEGIN
    if sourceURL is null then
      raise URL_NULL;
    end if;
    if clientDestination is null then
      raise CLIENT_FILE_NULL;
    end if;

    if specialDestination is null or specialDestination < 0 or specialDestination > 2 then 
      submitString := '0'||sep;
    else
      submitString := to_char(specialDestination)||sep;
    end if;
    if fileSize is null then 
      submitString := submitString||'0'||sep;
    else
      submitString := submitString||to_char(fileSize)||sep;
    end if;
    if withProgress is null or not withProgress then 
      submitString := submitString||'N'||sep;
    else
      submitString := submitString||'Y'||sep;
    end if;    

    submitString := submitString||sourceURL
                    ||sep||clientDestination
                    ||sep||nvl(progressTitle,' ')
                    ||sep||nvl(progressSubTitle,' ')
                    ||sep||nvl(progressMessage,' ');                         
  WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_URL_DOWNLOAD',submitString,true);
  result := WebUtil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_URL_DOWNLOAD');
  return (result='TRUE');
  EXCEPTION  
    when CLIENT_FILE_NULL then
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE, 130, 'WEBUTIL_CORE.DownloadFromURLInt');
      return false;
    when URL_NULL then
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE,25, 'WEBUTIL_CORE.DownloadFromURLInt');
      return false;

    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                              ||' bean not found. WEBUTIL_CORE.DownloadFromURLInt will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;
  END DownLoadFromURLInt;
```

#### SP-016 - WEBUTIL.ERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Constructs a structured error message string from a numeric error code, a program unit name, and up to three optional argument values, then registers that message as a WebUtil property on the specified package instance. This centralises error reporting for WebUtil client-side events by producing a consistently formatted error token that downstream processing can identify and handle.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |
| code | PLS_INTEGER | IN |
| pu_name | VARCHAR2 | IN |
| arg1 | VARCHAR2 | IN |
| arg2 | VARCHAR2 | IN |
| arg3 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the package instance identifier (packageID), a numeric error code (code), the originating program unit name (pu_name), and up to three optional contextual arguments (arg1, arg2, arg3).
- Step 2 - Initialise the error text string by concatenating the literal prefix 'ERROR' with the error code zero-padded to three digits and the program unit name, separated by pipe delimiters (e.g. 'ERROR001|pu_name').
- Step 3 - Evaluate whether arg1 is not null; if so, append a pipe delimiter followed by the value of arg1 to the error text string.
- Step 4 - Evaluate whether arg2 is not null; if so, append a pipe delimiter followed by the value of arg2 to the error text string.
- Step 5 - Evaluate whether arg3 is not null; if so, append a pipe delimiter followed by the value of arg3 to the error text string.
- Step 6 - Invoke Webutil_Core.setProperty to store the fully assembled error text string against the property key 'WUC_ERROR_MSG' for the given package instance (packageID).

---
**Decision Points**

DP-001

Condition: arg1 IS NOT NULL

TRUE: Append a pipe delimiter and the value of arg1 to the error text string.

FALSE: arg1 is omitted from the error text string; processing continues to DP-002.

---

DP-002

Condition: arg2 IS NOT NULL

TRUE: Append a pipe delimiter and the value of arg2 to the error text string.

FALSE: arg2 is omitted from the error text string; processing continues to DP-003.

---

DP-003

Condition: arg3 IS NOT NULL

TRUE: Append a pipe delimiter and the value of arg3 to the error text string.

FALSE: arg3 is omitted from the error text string; processing continues to property registration.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The error text string must always begin with the literal prefix 'ERROR' followed by the numeric error code formatted as exactly three zero-padded digits, ensuring a fixed-width, parseable code segment.
- BR-002 - The program unit name (pu_name) is mandatory and must always be included in the error text string immediately after the error code, separated by a pipe delimiter.
- BR-003 - Optional arguments (arg1, arg2, arg3) are included in the error text string only when they carry a non-null value; null arguments are silently excluded, keeping the message compact.
- BR-004 - All segments of the error text string must be separated by pipe ('|') delimiters, producing a pipe-delimited token format that downstream consumers can parse reliably.
- BR-005 - The fully assembled error message must be registered against the property key 'WUC_ERROR_MSG' on the specified package instance via Webutil_Core.setProperty, making it accessible to the invoking context (WEBUTIL_CORE.CUSTOMEVENTHANDLER).

---
**Implementation Logic**

```plsql
  
  PROCEDURE Error(packageID in PLS_INTEGER,
                  code      in PLS_INTEGER,
                  pu_name   in VARCHAR2,
                  arg1      in VARCHAR2 :=null,
                  arg2      in VARCHAR2 := null,
                  arg3      in VARCHAR2 := null
                 ) is
    errText varchar2(1024);
  begin 
    errText := 'ERROR'||lpad(to_char(code),3,'0') || '|' || pu_name;
    if arg1 is not null then
      errText := errText || '|' || arg1;
    end if;
    if arg2 is not null then
      errText := errText || '|' || arg2;
    end if;
    if arg3 is not null then
      errText := errText || '|' || arg3;
    end if;
    Webutil_Core.setProperty(packageID, 'WUC_ERROR_MSG', errText);
  end Error;
```

#### SP-017 - WEBUTIL.ERRORALERT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]
- webutil.pld [StoredProcedure: WEBUTIL.LOG]
- webutil.pld [StoredProcedure: WEBUTIL.POPULATEPROPERTYBUNDLE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Displays a WebUtil error message to the end user. If a pre-configured alert object (m_errorAlert) is available, the procedure sets its message text and shows it as a modal alert dialog. When no alert object is registered, it falls back to the Forms MESSAGE built-in. The procedure is called by WEBUTIL.FCLOSE, WEBUTIL.LOG, and WEBUTIL.POPULATEPROPERTYBUNDLE to surface bean-not-registered or bean-not-found errors.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| errText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-035](#SP-035--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the error message text (errText) passed in by the calling procedure (WEBUTIL.FCLOSE, WEBUTIL.LOG, or WEBUTIL.POPULATEPROPERTYBUNDLE).
- Step 2 - Call WEBUTIL.ID_NULL (SP-035) to test whether the module-level alert handle m_errorAlert references a valid, registered alert object.
- Step 3 - If m_errorAlert is valid (not null), set the alert's message text property to errText using SET_ALERT_PROPERTY with the ALERT_MESSAGE_TEXT attribute.
- Step 4 - Display the alert to the user by calling SHOW_ALERT(m_errorAlert); the return value is captured in the local variable 'ignore' and discarded.
- Step 5 - If m_errorAlert is not valid (null/unregistered), display the error using the Forms MESSAGE built-in, prefixing the text with 'WebUtil Error: '.

---
**Decision Points**

DP-001

Condition:
WEBUTIL.ID_NULL(m_errorAlert) returns FALSE - i.e., the module-level alert handle m_errorAlert references a valid, registered Forms alert object.

TRUE:
Set the alert's ALERT_MESSAGE_TEXT property to errText and display it to the user via SHOW_ALERT; the integer return value is discarded.

FALSE:
Fall back to the Forms MESSAGE built-in, outputting the concatenated string 'WebUtil Error: ' followed by errText.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure is the single, centralised error-display mechanism for WebUtil bean-related failures; all callers (WEBUTIL.FCLOSE, WEBUTIL.LOG, WEBUTIL.POPULATEPROPERTYBUNDLE) must route bean-not-registered and bean-not-found errors through this procedure.
- BR-002 - Alert display is conditional on the alert handle m_errorAlert being valid; validity is determined exclusively by WEBUTIL.ID_NULL (SP-035).
- BR-003 - When the alert object is available, the alert title is not overwritten at runtime; it is assumed to be pre-configured in the alert's design-time properties.
- BR-004 - The return value of SHOW_ALERT is intentionally ignored; the procedure does not branch or take further action based on which alert button the user selects.
- BR-005 - When no valid alert handle exists, the error message must be prefixed with 'WebUtil Error: ' to ensure consistent identification of WebUtil-originated errors in the Forms message line.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ErrorAlert(errText in VARCHAR2) is
    -- currently used for throwing a BEAN_NOT_REGISTERED or bean not found error.
    ignore integer;
  begin
    if not ID_NULL(m_errorAlert) then 
      --SET_ALERT_PROPERTY(m_errorAlert,TITLE,'WebUtil Error'); -- title already set in alert property
      SET_ALERT_PROPERTY(m_errorAlert,ALERT_MESSAGE_TEXT,errText);
      ignore := SHOW_ALERT(m_errorAlert);
    else
      message('WebUtil Error'||': '||errText);
    end if;
  end ErrorAlert;
```

#### SP-018 - WEBUTIL.EXECUTE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.BLOCKING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Submits a host operating-system command for execution on the client machine by delegating to the WebUtil host-execution bean. The procedure accepts the command string and an execution mode flag, passes both to the WebUtil Core layer, and returns a process handle that the caller can use to reference or monitor the spawned process. If no command is supplied the procedure returns without action.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |
| exemode | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the host command string (cmd) and the execution mode indicator (exemode) as input parameters.
- Step 2 - Evaluate whether cmd is non-null; if it is null, skip all processing and return an uninitialised PROCESS_ID record to the caller.
- Step 3 - Set the execution mode on the WebUtil host-execution bean by calling WebUtil_Core.setProperty with property key WUH_EXECUTION_MODE and the supplied exemode value.
- Step 4 - Dispatch the command to the WebUtil host-execution bean by calling WebUtil_Core.setProperty with property key WUH_EXECUTE and the supplied cmd value.
- Step 5 - Retrieve the process handle assigned by the bean by calling WebUtil_Core.getProperty with property key WUH_EXECUTE, convert the returned string to a number, and store it in the local PROCESS_ID variable (procId.handle).
- Step 6 - Return the populated PROCESS_ID record to the caller.
- Step 7 - If a BEAN_NOT_REGISTERED exception is raised at any point, display an error alert via WebUtil_Core.ErrorAlert identifying the missing implementation class and advising that WEBUTIL_HOST.Execute will not function.

---
**Decision Points**

DP-001

Condition: cmd IS NOT NULL

TRUE: Set the execution mode property on the WebUtil bean, dispatch the command, retrieve and store the resulting process handle, and return it to the caller.

FALSE: Bypass all bean interaction and return an uninitialised PROCESS_ID record immediately.

DP-002

Condition: WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during bean property interaction

TRUE: Display an error alert that identifies the missing bean class and states that WEBUTIL_HOST.Execute will not work; no process handle is returned.

FALSE: Normal execution continues; the process handle is returned to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A null command string is treated as a no-operation; the procedure must not attempt any bean interaction and must return an uninitialised PROCESS_ID without raising an error.
- BR-002 - The execution mode (exemode) must be set on the WebUtil host-execution bean before the command is dispatched, ensuring the bean applies the correct execution behaviour to the process.
- BR-003 - The process handle returned by the bean must be stored as a numeric value in the PROCESS_ID record; the raw string response from WebUtil_Core.getProperty must be converted using TO_NUMBER before assignment.
- BR-004 - If the WebUtil host-execution bean is not registered, the procedure must surface a descriptive error alert identifying the missing implementation class and must not silently fail or return a partial result.

---
**Implementation Logic**

```plsql
  FUNCTION Execute (cmd in VARCHAR2, exemode in PLS_INTEGER) return PROCESS_ID is
    procId PROCESS_ID;
  begin 
    if cmd is not null then 
      WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTION_MODE',exemode);            
      WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTE',cmd);      
      procId.handle := to_number(WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTE'));
    end if;
    return procId;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.Execute will not work');
  end Execute;
```

#### SP-019 - WEBUTIL.FCLOSE

**Invoked From:**

- sr_exch_lyl_dlr_rep_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open client-side text file represented by a FILE_TYPE handle. The procedure instructs the WebUtil bean to release the file resource, clears the in-memory handle to prevent reuse, and surfaces a descriptive alert via WEBUTIL.ERRORALERT if the required WebUtil bean is not registered, or propagates a tool error if a property-level failure occurs during the close operation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-017](#SP-017--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETIMPLCLASS ([SP-024](#SP-024--WEBUTIL.GETIMPLCLASS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FILE_TYPE parameter (passed IN OUT) which carries the active file handle for a previously opened client-side text file.
- Step 2 - Check whether the file handle is currently populated (i.e., file.handle IS NOT NULL). If it is NULL the file is already closed or was never opened, and no further action is taken.
- Step 3 - If the handle is not NULL, invoke WebUtil_Core.setProperty with the WUF_PACKAGE package identifier and the WUF_TEXTIO_CLOSE property key, passing the active handle value. This instructs the WebUtil bean on the client to physically close the file.
- Step 4 - After the successful close signal is sent, set file.handle to NULL, marking the FILE_TYPE record as closed and preventing any subsequent operations from reusing the stale handle.
- Step 5 - If a BEAN_NOT_REGISTERED exception is raised during the close attempt, call WEBUTIL.ERRORALERT (via WebUtil_Core.ErrorAlert) to display a user-facing message that identifies the missing implementation class (resolved via WEBUTIL.GETIMPLCLASS / WebUtil_Core.getImplClass) and states that CLIENT_TEXT_IO.fclose will not work, then raise TOOL_ERR.TOOL_ERROR to halt processing.
- Step 6 - If a PROPERTY_ERROR exception is raised, raise TOOL_ERR.TOOL_ERROR immediately without displaying an alert, propagating the failure to the calling context.

---
**Decision Points**

DP-001

Condition:
file.handle IS NOT NULL

TRUE:
Proceed to close the file by calling WebUtil_Core.setProperty with the WUF_TEXTIO_CLOSE property and the current handle value, then set file.handle to NULL.

FALSE:
Skip all close logic; the procedure exits without performing any operation because the file is already closed or was never opened.

---

DP-002

Condition:
WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during the setProperty call

TRUE:
Invoke WEBUTIL.ERRORALERT to display an alert message that includes the implementation class name (retrieved via WEBUTIL.GETIMPLCLASS) and the explanation that CLIENT_TEXT_IO.fclose will not work, then raise TOOL_ERR.TOOL_ERROR.

FALSE:
Exception is not of this type; evaluate the next exception handler.

---

DP-003

Condition:
WebUtil_Core.PROPERTY_ERROR exception is raised during the setProperty call

TRUE:
Raise TOOL_ERR.TOOL_ERROR immediately without issuing any user-facing alert, propagating the error to the caller.

FALSE:
Exception is not of this type; normal execution continues (file handle is set to NULL and the procedure exits cleanly).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A file close operation is only attempted when the FILE_TYPE handle is non-NULL; a NULL handle is treated as an already-closed file and the procedure takes no action, preventing redundant or erroneous close requests.
- BR-002 - After the WebUtil bean successfully closes the file, the in-memory handle must be set to NULL immediately, ensuring the FILE_TYPE record cannot be used to perform further read, write, or close operations on the released resource.
- BR-003 - If the WebUtil bean required to perform the close operation is not registered on the client, the procedure must surface a descriptive error alert (via WEBUTIL.ERRORALERT) that identifies the missing bean class (resolved via WEBUTIL.GETIMPLCLASS) before raising TOOL_ERR.TOOL_ERROR, ensuring operators receive actionable diagnostic information.
- BR-004 - If a property-level error occurs during the close call, the procedure must raise TOOL_ERR.TOOL_ERROR without issuing an alert, delegating error presentation responsibility to the calling context.
- BR-005 - No database interactions are performed during file close; this is a purely client-side resource-management operation mediated through the WebUtil bean layer.

---
**Implementation Logic**

```plsql
 
  PROCEDURE fclose (file IN OUT file_type) is 
  BEGIN 
    if (file.handle IS NOT NULL) then 
      WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CLOSE',file.handle);        
      file.handle := NULL;
    end if;
 
 EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.fclose will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;
  END fclose;
```

#### SP-020 - WEBUTIL.FOPEN

**Invoked From:**

- sr_exch_lyl_dlr_rep_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Opens a client-side text file on behalf of the calling form (sr_exch_lyl_dlr_rep_fmb.xml / VIEW_EXCEL_REP) by validating the supplied file specification and access mode, transmitting the open request to the WebUtil Java bean via WebUtil_Core property calls, and returning a file handle (file_type) that subsequent CLIENT_TEXT_IO operations can use to read, write, or append to the file.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| spec | VARCHAR2 | IN |
| filemode | VARCHAR2 | IN |
| charSet | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETPROPERTY ([SP-030](#SP-030--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Validate the file mode: confirm that the supplied `filemode` parameter (case-insensitive) is one of the three permitted values - 'r' (read), 'w' (write), or 'a' (append); raise TOOL_ERR.TOOL_ERROR immediately if it is not.
- Step 2 - Validate the file specification: confirm that `spec` is neither NULL nor an empty string; raise TOOL_ERR.TOOL_ERROR if the file name is absent.
- Step 3 - Transmit the file name to the WebUtil bean by calling WebUtil_Core.setProperty with property key 'WUF_FILENAME' and the value of `spec`.
- Step 4 - Transmit the file mode to the WebUtil bean by calling WebUtil_Core.setProperty with property key 'WUF_TEXTIO_FILEMODE' and the value of `filemode`.
- Step 5 - Transmit the character set to the WebUtil bean: if `charSet` is NULL, set property 'WUF_TEXTIO_CHARSET' to the literal string '(null)'; otherwise set it to the supplied `charSet` value.
- Step 6 - Request the file open operation by calling WEBUTIL.GETPROPERTY (WebUtil_Core.getProperty) with property key 'WUF_TEXTIO_OPEN'; the bean performs the actual client-side file open and returns a Java file handle string (`javaHandle`).
- Step 7 - Validate the returned handle: if `javaHandle` is NULL, empty, or equals '-1', the file could not be opened; raise TOOL_ERR.TOOL_ERROR.
- Step 8 - Convert the valid handle string to a number, assign it to `clientFile.handle`, and return the populated file_type record to the caller.
- Step 9 - Exception handling: if the WebUtil bean is not registered, surface a descriptive error alert (via WebUtil_Core.ErrorAlert / WebUtil_Core.getImplClass) and re-raise TOOL_ERR.TOOL_ERROR; propagate PROPERTY_ERROR, VALUE_ERROR (as TOOL_ERR.TOOL_ERROR), and TOOL_ERR.TOOL_ERROR directly to the caller.

---
**Decision Points**

DP-001

Condition:
Is `filemode` (converted to lower case) one of 'r', 'w', or 'a'?

TRUE:
Processing continues to the file-specification validation step.

FALSE:
TOOL_ERR.TOOL_ERROR is raised immediately and the function does not proceed.

---

DP-002

Condition:
Is `spec` NULL or an empty string?

TRUE:
TOOL_ERR.TOOL_ERROR is raised immediately and the function does not proceed.

FALSE:
Processing continues; the file name is transmitted to the WebUtil bean.

---

DP-003

Condition:
Is the `charSet` parameter NULL?

TRUE:
The literal string '(null)' is passed to the WebUtil bean as the charset property, indicating no specific encoding.

FALSE:
The supplied `charSet` value is passed to the WebUtil bean as the charset property.

---

DP-004

Condition:
Is the `javaHandle` returned by WebUtil_Core.getProperty (WEBUTIL.GETPROPERTY) NULL, empty, or equal to '-1'?

TRUE:
The client-side file open failed; TOOL_ERR.TOOL_ERROR is raised and NULL is returned.

FALSE:
The handle is valid; it is converted to a number, stored in clientFile.handle, and the file_type record is returned to the caller.

---

DP-005

Condition:
Did the exception handler catch WebUtil_Core.BEAN_NOT_REGISTERED?

TRUE:
An error alert is displayed (via WebUtil_Core.ErrorAlert and WebUtil_Core.getImplClass) identifying the missing bean, TOOL_ERR.TOOL_ERROR is re-raised, and NULL is returned.

FALSE:
Other exception types (PROPERTY_ERROR, VALUE_ERROR, TOOL_ERR.TOOL_ERROR) are handled by their respective handlers and propagated to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file access mode must be exactly one of 'r' (read), 'w' (write), or 'a' (append); any other value is rejected before any bean communication occurs.
- BR-002 - A non-null, non-empty file specification (path/name) is mandatory; the function will not attempt to open a file without a valid `spec` value.
- BR-003 - The character set parameter is optional; when omitted (NULL), the WebUtil bean is explicitly instructed to use no specific encoding by receiving the sentinel value '(null)'.
- BR-004 - A Java handle value of NULL, empty string, or '-1' is treated as a failed open operation; the function raises an error rather than returning an unusable file handle.
- BR-005 - The Java handle returned by WEBUTIL.GETPROPERTY must be convertible to a NUMBER; a VALUE_ERROR during conversion is surfaced as TOOL_ERR.TOOL_ERROR, ensuring consistent error signalling to the caller.
- BR-006 - If the WebUtil bean is not registered on the client, the function must not silently fail; it displays a descriptive alert identifying the missing bean class before raising TOOL_ERR.TOOL_ERROR.
- BR-007 - All unrecoverable errors are communicated to the caller exclusively via TOOL_ERR.TOOL_ERROR, ensuring a uniform error contract for consumers such as VIEW_EXCEL_REP.

---
**Implementation Logic**

```plsql
  FUNCTION fopen(spec VARCHAR2, filemode VARCHAR2, charSet VARCHAR2 := null) RETURN file_type is
    clientFile file_type;
    javaHandle VARCHAR2(6);
  BEGIN
    -- check the mode is valid
    if (lower(filemode) not in ('r','w','a')) then 
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- make sure a file name has been specified      
    if (spec is null) or (spec='') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;
      
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILENAME',spec, true);
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_FILEMODE',filemode, true);        
    if (charSet is null) then
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET','(null)', true);
    else
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET',charSet, true);
    end if;
    javaHandle := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_OPEN');

    -- If the return is null then the file was not opened      
    if (javaHandle is null) or (javaHandle='') or (javaHandle='-1') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- if we are this far convert the handle to the correct format and return it.      
    clientFile.handle := to_number(javaHandle);
    return clientFile;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.fopen will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                 
      return null;
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE;
    when VALUE_ERROR then
      RAISE TOOL_ERR.TOOL_ERROR; 
    when TOOL_ERR.TOOL_ERROR then 
      RAISE;
  END fopen;
```

#### SP-021 - WEBUTIL.GETCALLBACKTRIGGER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the name of the callback trigger associated with a given numeric key from the internal callbacks collection. This function is used by WEBUTIL.SETDATA to resolve which trigger should be invoked for a specific WebUtil callback operation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| callbackKey | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the integer key (callbackKey) that identifies a specific callback trigger entry.
- Step 2 - Look up the corresponding trigger name in the package-level collection m_callbacks using callbackKey as the index.
- Step 3 - Return the VARCHAR2 trigger name retrieved from the collection to the caller.

---
**Decision Points**

No decision points are present in this function. The implementation performs a direct collection lookup and returns the result unconditionally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The callbackKey parameter must correspond to a valid, pre-existing index in the m_callbacks collection; no bounds checking or default handling is performed within this function, so the caller is responsible for supplying a key that was previously registered.
- BR-002 - The return value is the VARCHAR2 trigger name stored at the specified index in m_callbacks; no transformation or formatting is applied to the stored value before it is returned.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetCallbackTrigger(callbackKey in PLS_INTEGER) return VARCHAR2 is 
  begin 
    return m_callbacks(callbackKey);
  end GetCallbackTrigger;
```

#### SP-022 - WEBUTIL.GETCLIENTOSFAMILY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the operating system family identifier of the client machine as a PLS_INTEGER value. This function exposes the pre-populated module-level variable m_clientOSFamily, allowing calling code (such as WEBUTIL.GETVAR) to retrieve the client OS family classification without performing any additional lookup or computation.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - The function is invoked by WEBUTIL.GETVAR to obtain the client operating system family identifier.
- Step 2 - The function reads the module-level variable m_clientOSFamily, which holds the pre-populated OS family classification for the current client session.
- Step 3 - The function returns the PLS_INTEGER value of m_clientOSFamily directly to the caller with no transformation or additional processing.

---
**Decision Points**

No decision points exist in this function. The implementation unconditionally returns the value of m_clientOSFamily without any conditional branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function returns the value of m_clientOSFamily as-is; no validation, defaulting, or transformation is applied to the value before it is returned.
- BR-002 - The client OS family identifier must have been populated into m_clientOSFamily prior to this function being called; this function is read-only and does not initialise or modify the variable.

---
**Implementation Logic**

```plsql

  FUNCTION GetClientOSFamily return PLS_INTEGER is 
  begin 
    return m_clientOSFamily;
  end GetClientOSFamily;
```

#### SP-023 - WEBUTIL.GETCLIENTSETTING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a named client-side configuration property from the WebUtil core bean. Given a property name, the function delegates to WebUtil_Core to set a retrieval request and then reads back the resolved value, returning it to the caller. It is used by WEBUTIL.CHECKLIBS and WEBUTIL.REGISTERBEAN to inspect local client settings required for WebUtil initialisation and bean registration.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameter propertyName (VARCHAR2).
- Step 2 - Evaluate whether propertyName is not null; if null, skip retrieval and return a null result.
- Step 3 - Call WebUtil_Core.setProperty, targeting the WUC_PACKAGE component with the key WUC_GET_LOCAL_PROPERTY and passing propertyName as the value, to request the client-side property lookup.
- Step 4 - Call WebUtil_Core.getProperty for the same WUC_PACKAGE component and WUC_GET_LOCAL_PROPERTY key to retrieve the resolved property value from the WebUtil core bean.
- Step 5 - Store the retrieved value in the local variable result (VARCHAR2 255 characters).
- Step 6 - Return result to the caller.
- Step 7 - If a WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during Steps 3-4, display an error alert identifying the missing bean class and raise FORM_TRIGGER_FAILURE to halt form processing.
- Step 8 - If a WebUtil_Core.PROPERTY_ERROR exception is raised during Steps 3-4, raise FORM_TRIGGER_FAILURE to halt form processing without an additional alert.

---
**Decision Points**

DP-001

Condition: propertyName IS NOT NULL

TRUE: Proceed to invoke WebUtil_Core.setProperty and WebUtil_Core.getProperty to retrieve the client-side setting, then return the resolved value.

FALSE: Bypass all WebUtil_Core interactions and return NULL to the caller.

DP-002

Condition: WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during property set/get operations.

TRUE: Display an error alert identifying the missing bean (using WebUtil_Core.getImplClass for WUC_PACKAGE) and raise FORM_TRIGGER_FAILURE to abort form processing.

FALSE: Continue normal execution; no alert is raised.

DP-003

Condition: WebUtil_Core.PROPERTY_ERROR exception is raised during property set/get operations.

TRUE: Raise FORM_TRIGGER_FAILURE to abort form processing silently (no alert).

FALSE: Continue normal execution; result is returned to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A null propertyName must not trigger any WebUtil_Core interaction; the function must return NULL immediately, preventing an invalid property lookup request from being sent to the bean.
- BR-002 - The property retrieval must use the WUC_PACKAGE component constant and the WUC_GET_LOCAL_PROPERTY key as defined by WebUtil_Core; no ad-hoc component or key identifiers are permitted.
- BR-003 - If the WebUtil core bean is not registered on the client (BEAN_NOT_REGISTERED), the function must surface a descriptive error alert that includes the bean implementation class name and must terminate form processing via FORM_TRIGGER_FAILURE.
- BR-004 - If a property error occurs (PROPERTY_ERROR), the function must terminate form processing via FORM_TRIGGER_FAILURE without displaying an additional alert, preventing further execution with an unresolved property value.
- BR-005 - The returned property value must not exceed 255 characters, as enforced by the result variable declaration; callers must account for this length constraint when consuming the return value.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetClientSetting(propertyName in VARCHAR2) return VARCHAR2 is 
    result VARCHAR2(255 char);
  BEGIN
    if propertyName is not null then 
    WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_GET_LOCAL_PROPERTY', propertyName);
       result := WebUtil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_GET_LOCAL_PROPERTY');
    end if;
    return result;
  EXCEPTION  
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                            ||' bean not found. WEBUTIL_CORE.GetClientSetting will not work');
    RAISE FORM_TRIGGER_FAILURE;  
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE FORM_TRIGGER_FAILURE;       
  END GetClientSetting;
```

#### SP-024 - WEBUTIL.GETIMPLCLASS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the fully-qualified Java implementation class name for a given WebUtil package by concatenating the standard WebUtil Java root prefix with the registered implementation class entry for the supplied package identifier. This value is used by callers (e.g., WEBUTIL.FCLOSE) to resolve the correct Java class at runtime.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the integer package identifier (packageID) that designates a specific WebUtil package.
- Step 2 - Look up the implementation class suffix associated with packageID in the package-level associative array m_implClasses, using packageID as the index key.
- Step 3 - Concatenate the constant WEBUTIL_JAVA_ROOT with the retrieved class suffix to form the fully-qualified Java class name.
- Step 4 - Return the resulting VARCHAR2 string to the caller.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function performs a direct array lookup and string concatenation without branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The packageID supplied by the caller must correspond to a valid, pre-populated entry in the m_implClasses associative array; if no entry exists for the given index, the runtime will raise an unhandled NO_DATA_FOUND exception.
- BR-002 - The fully-qualified Java class name is always formed by prepending the WEBUTIL_JAVA_ROOT constant to the class suffix stored in m_implClasses, ensuring a consistent and centrally controlled root path for all WebUtil Java classes.
- BR-003 - This function has no database interactions and no external dependencies; all data required to produce the return value must already reside in the in-memory package state at the time of invocation.

---
**Implementation Logic**

```plsql

  FUNCTION getImplClass(packageID PLS_INTEGER) return VARCHAR2 is
  BEGIN 
    return WEBUTIL_JAVA_ROOT||m_implClasses(packageID);    
  END;
```

#### SP-025 - WEBUTIL.GETLASTERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the last error code recorded by the AppServerFileReader Java object on the application server. This function is called by WEBUTIL.SETDATA to determine whether a preceding file-transfer operation completed successfully or encountered an error condition, returning the error state as a numeric code for downstream handling.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the AppServerFileReader Java object instance (obj) as the target on which the error state will be queried.
- Step 2 - Clear the JNI argument list by setting args to NULL, ensuring no stale arguments are passed to the Java method call.
- Step 3 - Invoke the Java method getLastError() on the oracle/forms/webutil/fileTransfer/AppServerFileReader class via JNI.CALL_INT_METHOD, passing the supplied object reference and the cleared argument list.
- Step 4 - Return the integer result received from the Java method call to the caller as the last error code.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function unconditionally clears the argument list, invokes the Java method, and returns the resulting integer value.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The argument list (args) must be reset to NULL before invoking the Java method to prevent contamination from any previously constructed argument set.
- BR-002 - The error code is retrieved exclusively from the oracle/forms/webutil/fileTransfer/AppServerFileReader Java class using the no-argument method signature '()I'; no alternative retrieval mechanism is permitted.
- BR-003 - The function returns a numeric (INTEGER) value representing the last error state; interpretation and handling of that error code is the responsibility of the calling routine (WEBUTIL.SETDATA).

---
**Implementation Logic**

```plsql
  FUNCTION getLastError(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_INT_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'getLastError', '()I', args); 
  END;
```

#### SP-026 - WEBUTIL.GETLASTERRORARGS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the argument string associated with the most recent error raised by the AppServerFileReader Java class. The function delegates directly to the JNI layer to invoke the native Java method and returns the error-argument payload as a VARCHAR2 string, allowing the calling routine (WEBUTIL.SETDATA) to inspect error context after a failed file-transfer operation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the Java object reference (obj) that represents the active AppServerFileReader instance on which the last error occurred.
- Step 2 - Reset the local args variable to NULL to ensure no residual argument data from a prior call is carried forward.
- Step 3 - Invoke the Java instance method getLastErrorArgs on the AppServerFileReader class via JNI.CALL_STRING_METHOD, passing the object reference, the fully-qualified class name, the method name, and its JNI method descriptor '()Ljava/lang/String;' with a NULL argument list.
- Step 4 - Return the VARCHAR2 string produced by JNI.CALL_STRING_METHOD to the caller, representing the error-argument details from the last AppServerFileReader error.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a single, unconditional JNI method call and returns its result directly.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The args variable must be explicitly set to NULL before each JNI call to prevent stale argument data from a previous invocation from being passed to the AppServerFileReader.getLastErrorArgs Java method.
- BR-002 - The target Java method is identified by the fixed, fully-qualified class path 'oracle/forms/webutil/fileTransfer/AppServerFileReader' and the JNI descriptor '()Ljava/lang/String;'; these values must not be altered, as they bind the function to a specific Java class and method signature.
- BR-003 - The function operates as a non-static (instance) method call (FALSE flag to JNI.CALL_STRING_METHOD), meaning a valid, non-null AppServerFileReader object reference must be supplied by the caller for the invocation to succeed.

---
**Implementation Logic**

```plsql
  FUNCTION getLastErrorArgs(
    obj   ORA_JAVA.JOBJECT) RETURN VARCHAR2 IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_STRING_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'getLastErrorArgs', '()Ljava/lang/String;', args); 
  END;
```

#### SP-027 - WEBUTIL.GETNUMBER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Extracts a delimited numeric field from a source string at a specified position by delegating string extraction to WEBUTIL.GETSTRING and converting the returned value to a NUMBER. This utility function enables callers within the WebUtil custom event handler to parse structured, delimiter-separated string payloads and retrieve individual numeric tokens without duplicating parsing logic.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Source_string | varchar2 | IN |
| Field_position | number | IN |
| UnTerminated | Boolean | IN |
| Delimiter | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETSTRING ([SP-031](#SP-031--WEBUTIL.GETSTRING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the source string, the target field position, an optional flag indicating whether the final field is unterminated, and an optional delimiter character (defaulting to a comma).
- Step 2 - Invoke WEBUTIL.GETSTRING, passing all four arguments unchanged, to extract the raw VARCHAR2 token located at the specified field position within the delimited source string.
- Step 3 - Apply Oracle's TO_NUMBER conversion to the VARCHAR2 token returned by WEBUTIL.GETSTRING, producing a NUMBER value.
- Step 4 - Return the resulting NUMBER to the caller.

---
**Decision Points**

DP-001

Condition: Whether the UnTerminated flag is TRUE or FALSE.

TRUE: WEBUTIL.GETSTRING treats the final field in the source string as having no closing delimiter, adjusting its parsing boundary accordingly before returning the token for numeric conversion.

FALSE: WEBUTIL.GETSTRING treats all fields, including the final one, as properly terminated by the specified delimiter before returning the token for numeric conversion.

DP-002

Condition: Whether the Delimiter parameter is supplied by the caller.

TRUE (explicit value provided): WEBUTIL.GETSTRING uses the caller-supplied delimiter character to tokenise the source string.

FALSE (parameter omitted): WEBUTIL.GETSTRING defaults to a comma (',') as the delimiter when tokenising the source string.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function does not perform independent parsing; all field extraction logic is exclusively delegated to WEBUTIL.GETSTRING, ensuring a single point of maintenance for delimiter-based string parsing.
- BR-002 - The delimiter defaults to a comma (',') if not explicitly provided by the caller, meaning callers relying on comma-separated payloads need not supply this argument.
- BR-003 - The UnTerminated flag defaults to FALSE, meaning the source string is assumed to be fully terminated unless the caller explicitly signals otherwise.
- BR-004 - The token extracted by WEBUTIL.GETSTRING must be implicitly convertible to a NUMBER via TO_NUMBER; no null-handling or exception suppression is implemented within this function, so invalid or non-numeric tokens will propagate a runtime error to the caller.
- BR-005 - No database interactions occur within this function; it operates entirely on the in-memory input string passed by the caller.

---
**Implementation Logic**

```plsql

    
  function  GetNumber (Source_string    in varchar2,
                       Field_position   in number,
                       UnTerminated     in Boolean  default FALSE,
                       Delimiter        in varchar2 default ',') return number is
                       iRc              pls_integer;
  begin 
    Return to_number(GetString(Source_string, Field_Position, UnTerminated, Delimiter));
  end GetNumber; /* Number Version */
```

#### SP-028 - WEBUTIL.GETOSFAMILY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines and caches the client operating system family by inspecting the supplied OS name string and mapping it to a predefined platform constant (e.g., Windows, Mac, Linux, Solaris, HP-UX, AIX, or Unknown). The resolved platform value is stored in the package-level variable m_clientOSFamily so that subsequent calls return the cached result without re-evaluating the OS name. This function is invoked by WEBUTIL.REGISTERBEAN to establish the client platform context required for bean registration.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| osName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the osName input parameter and convert it to lowercase, storing the result in the local variable l_osName to enable case-insensitive comparison.
- Step 2 - Initialise the local result variable to CLIENT_PLATFORM_UNKNOWN as the default platform constant.
- Step 3 - Check whether the package-level cache variable m_clientOSFamily is null; if it is not null, skip all evaluation steps and proceed directly to Step 10.
- Step 4 - Search l_osName for the substring 'windows'; if found, set result to CLIENT_PLATFORM_WIN32.
- Step 5 - If Step 4 did not match, search l_osName for the substring 'mac'; if found, set result to CLIENT_PLATFORM_MAC.
- Step 6 - If Step 5 did not match, search l_osName for the substring 'linux'; if found, set result to CLIENT_PLATFORM_LINUX.
- Step 7 - If Step 6 did not match, search l_osName for either 'solaris' or 'sunos'; if either is found, set result to CLIENT_PLATFORM_SOLARIS.
- Step 8 - If Step 7 did not match, search l_osName for the substring 'hp-ux'; if found, set result to CLIENT_PLATFORM_HP.
- Step 9 - If Step 8 did not match, search l_osName for the substring 'aix'; if found, set result to CLIENT_PLATFORM_AIX.
- Step 10 - Assign the resolved result value to the package-level variable m_clientOSFamily, persisting it for future calls.
- Step 11 - Return m_clientOSFamily to the caller.

---
**Decision Points**

DP-001

Condition: m_clientOSFamily IS NULL (i.e., the OS family has not yet been resolved and cached).

TRUE: Proceed to evaluate the osName string against all supported platform substrings (Steps 4-9) and populate m_clientOSFamily with the resolved constant.

FALSE: Skip all substring evaluations and return the already-cached value of m_clientOSFamily immediately.

---

DP-002

Condition: l_osName contains the substring 'windows'.

TRUE: Set result to CLIENT_PLATFORM_WIN32.

FALSE: Continue to the next platform check (DP-003).

---

DP-003

Condition: l_osName contains the substring 'mac'.

TRUE: Set result to CLIENT_PLATFORM_MAC.

FALSE: Continue to the next platform check (DP-004).

---

DP-004

Condition: l_osName contains the substring 'linux'.

TRUE: Set result to CLIENT_PLATFORM_LINUX.

FALSE: Continue to the next platform check (DP-005).

---

DP-005

Condition: l_osName contains the substring 'solaris' OR l_osName contains the substring 'sunos'.

TRUE: Set result to CLIENT_PLATFORM_SOLARIS.

FALSE: Continue to the next platform check (DP-006).

---

DP-006

Condition: l_osName contains the substring 'hp-ux'.

TRUE: Set result to CLIENT_PLATFORM_HP.

FALSE: Continue to the next platform check (DP-007).

---

DP-007

Condition: l_osName contains the substring 'aix'.

TRUE: Set result to CLIENT_PLATFORM_AIX.

FALSE: No further platform match is found; result retains its initialised value of CLIENT_PLATFORM_UNKNOWN.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The OS name comparison is always performed case-insensitively; the input osName is converted to lowercase before any substring search is executed.
- BR-002 - Platform identification follows a strict precedence order: Windows is evaluated first, followed by Mac, Linux, Solaris/SunOS, HP-UX, and AIX; the first matching platform wins and no further checks are performed.
- BR-003 - If the osName string does not match any recognised platform keyword, the function returns CLIENT_PLATFORM_UNKNOWN as the default platform constant.
- BR-004 - The Solaris platform is matched by either the substring 'solaris' or 'sunos', accommodating both the commercial and legacy Sun OS naming conventions.
- BR-005 - The resolved OS family is cached in the package-level variable m_clientOSFamily after the first successful evaluation; all subsequent calls to the function return the cached value without re-evaluating the osName input, ensuring the platform is determined only once per session.

---
**Implementation Logic**

```plsql
 
  FUNCTION getOSFamily(osName in VARCHAR2) return PLS_INTEGER is
    l_osName VARCHAR2(30) := lower(osName);
    result   PLS_INTEGER  := CLIENT_PLATFORM_UNKNOWN;
  BEGIN
    if m_clientOSFamily  is null then 
      if (instr(l_osName,'windows') > 0) then 
           result := CLIENT_PLATFORM_WIN32;
      elsif instr(l_osName,'mac') > 0 then 
          result := CLIENT_PLATFORM_MAC;      
      elsif instr(l_osName,'linux') > 0 then 
          result := CLIENT_PLATFORM_LINUX;      
      elsif instr(l_osName,'solaris') > 0 OR instr(l_osName, 'sunos') > 0 then 
          result := CLIENT_PLATFORM_SOLARIS;       
      elsif instr(l_osName,'hp-ux') > 0 then 
          result := CLIENT_PLATFORM_HP; 
      elsif instr(l_osName,'aix') > 0 then 
          result := CLIENT_PLATFORM_AIX;                                                       
      end if;            
      m_clientOSFamily := result;
    end if;
    return m_clientOSFamily;
  END getOSFamily;
```

#### SP-029 - WEBUTIL.GETOUTPUT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GET_STANDARD_OUTPUT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves all lines of output associated with a given client-side process by iterating over buffered output properties exposed through the WebUtil core bean. The function accumulates each output line into an array and returns the complete collection to the caller (WEBUTIL.GET_STANDARD_OUTPUT), enabling Oracle Forms to capture and process the text output produced by a host process.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |
| prop | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.INIT ([SP-036](#SP-036--WEBUTIL.INIT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Initialise the WebUtil core layer by executing the package initialisation block, which calls WebUtil_Core.Init to ensure the core bean is instantiated before any property interaction occurs.
- Step 2 - Set the process handle on the WebUtil core package by calling WebUtil_Core.setProperty with the WUH_PACKAGE target, the property key WUH_PROC_ID, and the handle value from the supplied process parameter, scoping all subsequent property reads to the correct host process.
- Step 3 - Enter a loop and retrieve the next buffered output line by calling WebUtil_Core.getProperty with the WUH_PACKAGE target and the caller-supplied prop parameter; store the result in the local buffer variable.
- Step 4 - Extract the single-character status prefix from the buffer (position 1) and assign it to the status variable. Valid status values are: 'Y' (more lines follow), 'N' (this is the last line), and 'X' (buffer was empty / no data).
- Step 5 - If status is not 'X', extract the payload (buffer from position 2 onward) and store it as the next element in the lines output array, then increment the array index.
- Step 6 - Evaluate the loop-exit condition: exit the loop when status is not 'Y' (i.e., status is 'N' indicating the final line has been read, or 'X' indicating an empty buffer).
- Step 7 - Return the fully populated lines array to the caller.
- Step 8 - If a BEAN_NOT_REGISTERED exception is raised at any point, display an error alert identifying the missing bean class and indicating that WEBUTIL_HOST.GetOutput will not function, then allow the exception to terminate the function.

---
**Decision Points**

DP-001

Condition: status <> 'X' (the retrieved buffer contains a non-empty line)

TRUE: Extract the payload substring (characters from position 2 onward) from the buffer, store it in the lines array at the current index, and increment the index counter.

FALSE: Discard the buffer contents; do not add any entry to the lines array and do not increment the index.

---

DP-002

Condition: status <> 'Y' (the current line is the last line or the buffer was empty)

TRUE: Exit the retrieval loop and proceed to return the lines array.

FALSE: Continue looping to retrieve the next buffered output line from the WebUtil core bean.

---

DP-003

Condition: WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during execution

TRUE: Invoke WebUtil_Core.ErrorAlert to display a message identifying the unregistered bean class and stating that WEBUTIL_HOST.GetOutput will not work; function terminates without returning a value.

FALSE: Normal execution continues; no exception handling is triggered.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The WebUtil core layer must be initialised (via WebUtil_Core.Init in the package initialisation block) before any property read or write operations are attempted; this ensures the bean is available for all subsequent calls within the session.
- BR-002 - The process handle (process.handle) must be registered with the WebUtil core package via WebUtil_Core.setProperty before output lines are retrieved, ensuring that all getProperty calls are scoped to the correct host process.
- BR-003 - Each value returned by WebUtil_Core.getProperty is a prefixed string of up to 257 characters; the first character is exclusively a status indicator ('Y', 'N', or 'X') and must be stripped before the payload is stored in the output array.
- BR-004 - Output lines are collected only when the status prefix is not 'X'; an 'X' status denotes an empty buffer and must not produce an entry in the returned array.
- BR-005 - The retrieval loop must continue for as long as the status prefix is 'Y'; a status of 'N' or 'X' signals loop termination, preventing infinite iteration.
- BR-006 - If the required WebUtil bean is not registered on the client, the function must not silently fail; it must surface an error alert identifying the missing bean and explicitly state that the GetOutput capability is unavailable.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetOutput(process in PROCESS_ID, prop in VARCHAR2) return OUTPUT_ARRAY is   
    lines  OUTPUT_ARRAY;
    i      PLS_INTEGER := 1;
    buffer VARCHAR2(257 char);
    status VARCHAR2(1) := 'X';
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_PROC_ID',process.handle);
    LOOP
      buffer := WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,prop);
      status := substr(buffer,1,1);
      -- Status can be Y: indicating more lines to follow,
      --               N: indicating that this is the last line
      --               X: indicating that the buffer was empty
      if status <> 'X' then 
        lines(i) := substr(buffer,2);
        i := i + 1;
      end if;
      exit when status <> 'Y';
    END LOOP;
    return lines;    
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.GetOutput will not work');
  END GetOutput;  
  
BEGIN
    -- Ensure that Core is instanciated.
    Webutil_Core.Init;
END;

PACKAGE WEBUTIL_SEPARATEFRAME IS

/*********************************************************************************\
 * WEBUTIL_SEPARATEFRAME
 *   This Package contains routines to interact with the MDI frame when Forms
 *   is running with the parameter separateFrame=true
 *   The functions in this package will work with any client type - not just 
 *   Windows clients.
 *   The oracle.forms.webutil.browser.BrowserFunctions bean is needed in your 
 *   Form to use these functions
 *********************************************************************************
 * Version 1.0.0
 *********************************************************************************
 * Change History
 *   1.0.0 DRMILLS 25/MAY/2003 - Creation
 *   1.0.1 DRMILLS 27/MAY/2003 - Added call to get frame size 
 *
\*********************************************************************************/

  /**
   *  IsSeparateFrame - Allows you to check if the form 
   *                is running in separateFrame mode or not
   */
```

#### SP-030 - WEBUTIL.GETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FOPEN]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a named Java system property at runtime by delegating to the Java Native Interface (JNI) layer. The function accepts a property key string and returns the corresponding system property value as reported by java.lang.System.getProperty, enabling Oracle Forms WebUtil components (such as FOPEN and REGISTERBEAN) to interrogate the client or server JVM environment during execution.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the property key string (a0) that identifies the Java system property to be queried.
- Step 2 - Create a JNI argument list sized for one argument by calling JNI.CREATE_ARG_LIST(1), storing the handle in the local variable args.
- Step 3 - Add the property key string (a0) to the argument list as a String argument via JNI.ADD_STRING_ARG.
- Step 4 - Invoke the static Java method java.lang.System.getProperty(String) through JNI.CALL_STRING_METHOD, passing the argument list; the call targets the class 'java/lang/System', method 'getProperty', with JNI descriptor '(Ljava/lang/String;)Ljava/lang/String;'.
- Step 5 - Return the VARCHAR2 string value produced by the JNI call to the caller.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a linear sequence of JNI calls and returns the result unconditionally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The property key supplied in parameter a0 must be a valid Java system property name; the JNI layer will return NULL if the named property does not exist in the JVM.
- BR-002 - The function relies exclusively on the JNI bridge (JNI.CREATE_ARG_LIST, JNI.ADD_STRING_ARG, JNI.CALL_STRING_METHOD); no Oracle database tables or internal PL/SQL dependencies are involved.
- BR-003 - The JNI call is made as a static method invocation (instance parameter passed as NULL and static flag set to TRUE), meaning no Java object instance is required to resolve the property.
- BR-004 - The return value is a VARCHAR2; callers (WEBUTIL.FOPEN, WEBUTIL.REGISTERBEAN) are responsible for interpreting or validating the returned property value within their own business logic.

---
**Implementation Logic**

```plsql
  FUNCTION getProperty(
    a0    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'getProperty', '(Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-031 - WEBUTIL.GETSTRING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETNUMBER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Extracts a single delimited token from a source string at a specified ordinal position. Given a delimiter-separated string, the function returns the substring occupying the nth field (Field_position), supporting both pre-terminated and unterminated source strings. It is used internally by WEBUTIL.GETNUMBER to isolate a positional field before numeric conversion.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Source_string | varchar2 | IN |
| Field_position | number | IN |
| UnTerminated | Boolean | IN |
| Delimiter | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-040](#SP-040--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the source string, the target field position, a Boolean flag indicating whether the string lacks a trailing delimiter (UnTerminated), and the delimiter character (defaulting to comma).
- Step 2 - Copy the source string into a working variable (vcSourceStrCopy) to avoid mutating the original input.
- Step 3 - If UnTerminated is TRUE, append the delimiter to the working copy so that the final field is bounded on both sides and can be located consistently.
- Step 4 - Determine the start position of the target field: if Field_position is greater than 1, locate the delimiter occurrence immediately before the target field (occurrence Field_position - 1) and advance the pointer past the delimiter length; otherwise set the start pointer to 1 (beginning of the string).
- Step 5 - Determine the end position of the target field by locating the nth occurrence of the delimiter (where n equals Field_position) within the working copy.
- Step 6 - Extract and return the substring between the start pointer and the end pointer (exclusive of the trailing delimiter) using SUBSTR.

---
**Decision Points**

DP-001

Condition: UnTerminated is TRUE.

TRUE: The delimiter is appended to the working copy of the source string before any positional search is performed, ensuring the last field is bounded and extractable.

FALSE: The source string is used as-is; it is assumed to already contain a trailing delimiter or the target field is not the last field.

---

DP-002

Condition: Field_position is greater than 1.

TRUE: The start pointer is calculated by finding the (Field_position - 1)th occurrence of the delimiter and advancing past it by the length of the delimiter string.

FALSE: Field_position equals 1; the start pointer is set to 1 (the first character of the string), as there is no preceding delimiter to locate.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function treats the delimiter as a multi-character capable separator; its length is accounted for when advancing the start pointer, so delimiters of more than one character are supported.
- BR-002 - When the source string does not end with the delimiter (UnTerminated = TRUE), the caller must signal this explicitly; the function will append the delimiter internally to ensure the last field is correctly bounded and returned.
- BR-003 - Field positions are 1-based; Field_position = 1 refers to the first token in the string.
- BR-004 - The function returns only the content between the bounding delimiters; the delimiter characters themselves are never included in the returned value.
- BR-005 - The working copy of the source string is limited to 32,000 characters (VARCHAR2(32000)); source strings exceeding this length are not supported.

---
**Implementation Logic**

```plsql

  function  GetString (Source_string    in varchar2,
                       Field_position   in number,
                       UnTerminated     in Boolean  default FALSE,
                       Delimiter        in varchar2 default ',') return varchar2 is
                       iPtrEnd          pls_integer     := 0;
                       iPtrStart        pls_integer     := 0;
                       vcSourceStrCopy  varchar2(32000)     := Source_string;
  begin
    if UnTerminated then 
      vcSourceStrCopy := vcSourceStrCopy||Delimiter;
    end if;

    if Field_Position > 1 then 
      iPtrStart := instr(vcSourceStrCopy,Delimiter,1,Field_Position-1)+ length(Delimiter);
    else
      iPtrStart := 1;
    end if ; 

    iPtrEnd     := instr(vcSourceStrCopy,Delimiter,1,Field_Position);
    return substr(vcSourceStrCopy,iPtrStart,(iPtrEnd-iPtrStart));
  end GetString; /* String Version */
```

#### SP-032 - WEBUTIL.GETVAR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.GETVAR retrieves the value of a named configuration or environment variable from the client machine. The procedure selects the appropriate retrieval strategy based on the client operating system family: on Windows clients it queries the Oracle registry key first, then falls back to the Windows environment string; on Unix clients it executes the 'env' command, captures its output, and parses the result to locate the requested variable. Mac and unknown platforms are explicitly bypassed, returning no value.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VARNAME | VARCHAR2 | IN |
| VARVALUE | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VARVALUE | VARCHAR2 | IN OUT |

---

**Dependencies**

- GET_ENVIRONMENT_STRING ([SP-060](#SP-060--GET_ENVIRONMENT_STRING)) - matched by member name
- READ_REGISTRY ([SP-061](#SP-061--READ_REGISTRY)) - matched by member name
- WEBUTIL.BLOCKING ([SP-010](#SP-010--WEBUTIL.BLOCKING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTOSFAMILY ([SP-022](#SP-022--WEBUTIL.GETCLIENTOSFAMILY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_STANDARD_OUTPUT ([SP-034](#SP-034--WEBUTIL.GET_STANDARD_OUTPUT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.RELEASE_PROCESS ([SP-048](#SP-048--WEBUTIL.RELEASE_PROCESS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Determine the client operating system family by calling WEBUTIL.GETCLIENTOSFAMILY.
- Step 2 - If the client is Windows (CLIENT_PLATFORM_WIN32), attempt to read the variable value from the Windows registry under 'HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE' using READ_REGISTRY, passing VARNAME and a case-insensitive flag.
- Step 3 - If the registry lookup returns NULL or an empty string, fall back to retrieving the value from the Windows environment variables using GET_ENVIRONMENT_STRING, passing VARNAME.
- Step 4 - If the client is Mac (CLIENT_PLATFORM_MAC) or an unknown platform (CLIENT_PLATFORM_UNKNOWN), take no action and leave VARVALUE unchanged.
- Step 5 - For all other platforms (Unix), execute the shell command 'env' synchronously via WEBUTIL.BLOCKING to obtain a full list of environment variables, storing the process handle.
- Step 6 - Retrieve the complete standard output of the 'env' command as an array using WEBUTIL.GET_STANDARD_OUTPUT.
- Step 7 - Release the process handle using WEBUTIL.RELEASE_PROCESS.
- Step 8 - Iterate over each line of the output array; for each line, locate the '=' delimiter using INSTR. If found, extract the key (substring before '=') and compare it to VARNAME. On a match, extract the value (substring after '='), assign it to VARVALUE, and exit the loop.
- Step 9 - If a NO_DATA_FOUND exception is raised at any point during execution, set VARVALUE to NULL and return.

---
**Decision Points**

DP-001
Condition: Client OS family equals CLIENT_PLATFORM_WIN32.
TRUE: Attempt registry lookup under 'HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE' via READ_REGISTRY, then fall back to GET_ENVIRONMENT_STRING if needed.
FALSE: Proceed to DP-002.

DP-002
Condition: Client OS family is CLIENT_PLATFORM_MAC or CLIENT_PLATFORM_UNKNOWN.
TRUE: Take no action; VARVALUE remains unchanged (NULL or its prior value).
FALSE: Treat the client as a Unix platform and proceed to execute the 'env' command.

DP-003
Condition: The value returned by READ_REGISTRY is NULL or empty string.
TRUE: Fall back to GET_ENVIRONMENT_STRING to retrieve the variable from the Windows environment.
FALSE: Use the registry value as VARVALUE and continue.

DP-004
Condition: A '=' delimiter is found (INSTR result > 0) in the current line of the Unix 'env' output.
TRUE: Extract the key and compare it to VARNAME; if they match, assign the value portion to VARVALUE and exit the loop.
FALSE: Skip the current line and continue iterating.

DP-005
Condition: The extracted key from the current Unix output line equals VARNAME.
TRUE: Assign the substring after '=' to VARVALUE and EXIT the loop.
FALSE: Continue to the next line in the output array.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - On Windows clients, the Oracle registry path 'HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE' is always the primary source for variable resolution; the Windows environment is only consulted when the registry returns no value.
- BR-002 - On Mac and unknown client platforms, no variable resolution is attempted; VARVALUE is not populated by this procedure.
- BR-003 - On Unix clients, environment variable resolution is performed exclusively by executing the 'env' shell command synchronously; the first matching key in the output determines the returned value.
- BR-004 - Unix output lines that do not contain an '=' character are ignored during parsing.
- BR-005 - The process handle obtained from WEBUTIL.BLOCKING must always be released via WEBUTIL.RELEASE_PROCESS after the standard output has been retrieved, regardless of whether a match was found.
- BR-006 - A NO_DATA_FOUND exception at any stage of execution results in VARVALUE being set to NULL, ensuring the caller receives a defined output rather than an unhandled error.

---
**Implementation Logic**

```plsql

  PROCEDURE GETVAR(VARNAME IN VARCHAR2, VARVALUE IN OUT VARCHAR2) is
    unixOutput WebUtil_HOST.OUTPUT_ARRAY;
    hostHandle WebUtil_HOST.PROCESS_ID;
    varKey     VARCHAR2(100);
    iPos       PLS_INTEGER;
  BEGIN
    if WebUtil_Core.GetClientOSFamily = WebUtil_Core.CLIENT_PLATFORM_WIN32 then 
      -- read the client Registry
      VARVALUE := Client_Win_API_Environment.read_registry('HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE',VARNAME,false);
      if VARVALUE is null OR VARVALUE = '' then
        -- Could not get an Oracle variable in registry. Try to get from environment varialble
        -- java desupported System.getenv method until they supported it again in 1.5.
        -- We can still get the environment variables in windows using
        -- CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING
        VARVALUE := CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING(VARNAME);
      end if;
    elsif WebUtil_Core.GetClientOSFamily in (WebUtil_Core.CLIENT_PLATFORM_MAC,WebUtil_Core.CLIENT_PLATFORM_UNKNOWN) then 
      -- do nothing 
      null;
    else
      -- Unix Ports - do a env to get the environment and parse that
      hostHandle := WebUtil_HOST.Blocking('env');
      unixOutput := WebUtil_HOST.Get_Standard_Output(hostHandle);
      WebUtil_HOST.Release_Process(hostHandle);
      for i in 1..unixOutput.count LOOP
        iPos := instr(unixOutput(i),'=');
        if iPos > 0 then 
          varKey := substr(unixOutput(i),1,iPos-1);
          if varKey = VARNAME then 
            VARVALUE := substr(unixOutput(i),iPos+1);
            EXIT;
          end if;
        end if;
      end LOOP;
    end if;

  exception
    when NO_DATA_FOUND then
      VARVALUE := null;
  END GETVAR;

END CLIENT_TOOL_ENV;

PACKAGE Client_Win_API IS
/*-------------------------------------------------------------------------------*\
 * WebUtil version of D2KWUTIL package WIN_API                                     
 * Note: Not all D2kWutil Functions are ported
 *********************************************************************************
 * Version 1.0.0
 *********************************************************************************
 * Change History
 *   DRMILLS 21/FEB/2003 - Port Creation
 *
 *********************************************************************************
 * WIN_API ->  This package defines the constants used throughout 
 *      the library as a whole, including versions of those 
 *      constants defined within WINDOWS.H/WINUSER.H that 
 *      we'll be using. Add more constants in here if required
 *      The package also contains Explicit Exception declarations,
 *      various status Flags and functions for Error Handling
 * NOTE:    In order to make this library portable across Forms
 *      and Reports we do not use any application 
 *      specific built-ins such as the Forms MESSAGE() 
 *      Built-in. Instead errors are recorded in a package
 *      variable which the programmer can examine if required
\*-------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------*\
 * Internal Version Number  ** Oracle Developer Release 6.0 Version
\*-------------------------------------------------------------------------------*/
  WIN_API_VERSION  CONSTANT  VARCHAR2(30) := '6.0.6.0 Production';
  DLL_NAME         CONSTANT  VARCHAR2(12) := 'd2kwut60.dll';
  DLL_PATH         VARCHAR2(256)          := NULL;

/*-------------------------------------------------------------------------------*\
 * General Window Classes of Common Applications for use with WIN_API_SESSION
 * ** WARNING ** These Window classes are out of our control and might change 
 *               when you upgrade the software in question,
\*-------------------------------------------------------------------------------*/

  -- Oracle Apps
  WINCLASS_DEVELOPER_2000_V1  CONSTANT  VARCHAR2(15)  := 'ui23MDIroot_W32';             /* Developer/2000 release 1.n / Toolkit 2.3 Apps on 32 bit */
  WINCLASS_DEVELOPER_2000_V2  CONSTANT  VARCHAR2(15)  := 'ui25MDIroot_W32';             /* Developer/2000 Release 2.0 / Toolkit 2.5 Apps on 32 bit */
  WINCLASS_DEVELOPER_2000_V6  CONSTANT  VARCHAR2(15)  := 'ui60MDIroot_W32';             /* Developer/2000 Release 6.0 / Toolkit 6.0 Apps on 32 bit */  
  D2K_WINDOW_CLASS            CONSTANT  VARCHAR2(15)  := WINCLASS_DEVELOPER_2000_V6;    /* Set to the "current" version */  
  WINCLASS_INTEROFFICE_40     CONSTANT  VARCHAR2(28)  := 'Afx:10000000:b:10008:6:5023b';/* Oracle Interoffice 4.0 Client 32 bit */
  WINCLASS_INTEROFFICE_41     CONSTANT  VARCHAR2(28)  := 'Afx:10000000:b:1496:6:3a17';  /* Oracle Interoffice 4.0 Client 32 bit */
  WINCLASS_SQLPLUS            CONSTANT  VARCHAR2(13)  := 'SqlplusWClass';               /* Sql*Plus 32 bit */
  WINCLASS_REPORTSSERVER_V1   CONSTANT  VARCHAR2(15)  := 'R25SRV_WINCLASS';             /* Reports Server Reports 2.5 */
  WINCLASS_REPORTSSERVER_V2   CONSTANT  VARCHAR2(15)  := 'R30SRV_WINCLASS';             /* Reports Server Reports 3.0 */
  WINCLASS_REPORTSSERVER_V6   CONSTANT  VARCHAR2(14)  := 'RWRBE_WINCLASS';              /* Reports Server Reports 6.0 */

  -- Microsoft Office Apps - Office97
  WINCLASS_MSWORD_97         CONSTANT  VARCHAR2(7) := 'OpusApp';                        /* Microsoft Word 97 */
  WINCLASS_MSEXCEL_97        CONSTANT  VARCHAR2(6) := 'XLMAIN';                         /* Microsoft Excel 97 */
  WINCLASS_MSPOWERPOINT_97   CONSTANT  VARCHAR2(14):= 'PP97FrameClass';                 /* Microsoft Power Point 97 */

  -- Microsoft Office Apps - Office95
  WINCLASS_MSWORD_7          CONSTANT  VARCHAR2(7) := 'OpusApp';                        /* Microsoft Word 7 */
  WINCLASS_MSEXCEL_7         CONSTANT  VARCHAR2(6) := 'XLMAIN';                         /* Microsoft Excel 7 */
  WINCLASS_MSPOWERPOINT_7    CONSTANT  VARCHAR2(13):= 'PP7FrameClass';                  /* Microsoft Power Point 7 */
  WINCLASS_MSSCHEDULE_7      CONSTANT  VARCHAR2(23):= 'MS Schedule+ 32 Panesdi';        /* Microsoft Schedule 7 */
  WINCLASS_MSEXCHANGE_4      CONSTANT  VARCHAR2(29):= 'Microsoft Exchange 4.0 Viewer';  /* Microsoft Exchange 4 in-tray */

  -- Microsoft O/S Utilities
  WINCLASS_INETEXPLORER      CONSTANT  VARCHAR2(7):= 'IEFrame';                         /* Internet Explorer */
  WINCLASS_OUTLOOK_EXPRESS   CONSTANT  VARCHAR2(29):= 'Outlook Express Browser Class';  /* Outlook Express */
  WINCLASS_EXPLORER          CONSTANT  VARCHAR2(13):= 'ExploreWClass';                  /* Explorer */
  WINCLASS_MYCOMPUTER        CONSTANT  VARCHAR2(13):= 'CabinetWClass';                  /* My Computer & Network Neighborhood*/
  WINCLASS_CALCULATOR        CONSTANT  VARCHAR2(7) := 'SciCalc';                        /* Windows Calculator */
  WINCLASS_NOTEPAD           CONSTANT  VARCHAR2(7) := 'Notepad';                        /* Windows Notepad */
  WINCLASS_WORDPAD           CONSTANT  VARCHAR2(12):= 'WordPadClass';                   /* Windows Wordpad/Write */
  WINCLASS_DOS               CONSTANT  VARCHAR2(18):= 'ConsoleWindowClass';             /* Dos Window */

  -- Other
  WINCLASS_NETSCAPE_3        CONSTANT  VARCHAR2(27):= 'Afx:40000000:b:150e:6:38cfe';    /* Netscape Navigator 3.0 */
  WINCLASS_NETSCAPE_4        CONSTANT  VARCHAR2(28):= 'Afx:40000000:b:10008:6:6063e';   /* Netscape Communicator 4.0 */
  WINCLASS_PFE_7             CONSTANT  VARCHAR2(11):= 'PFE32_Frame';                    /* Programmers File Editor */
  WINCLASS_REGEDIT           CONSTANT  VARCHAR2(15):= 'RegEdit_RegEdit';                /* Registry Editor */

  -- Window Style Constants (from WINUSER.H)
  --  Any PU's that use these constants will explain 
  --  their use.  For further information consult the
  --  Windows SDK.

  SW_HIDE              CONSTANT  PLS_INTEGER := 0;
  SW_SHOWNORMAL        CONSTANT  PLS_INTEGER := 1;
  SW_SHOWMINIMIZED     CONSTANT  PLS_INTEGER := 2;
  SW_SHOWMAXIMIZED     CONSTANT  PLS_INTEGER := 3;
  SW_SHOWNOACTIVATE    CONSTANT  PLS_INTEGER := 4;
  SW_SHOW              CONSTANT  PLS_INTEGER := 5;
  SW_MINIMIZE          CONSTANT  PLS_INTEGER := 6;
  SW_SHOWMINNOACTIVE   CONSTANT  PLS_INTEGER := 7;
  SW_SHOWNA            CONSTANT  PLS_INTEGER := 8;
  SW_RESTORE           CONSTANT  PLS_INTEGER := 9;
  SW_SHOWDEFAULT       CONSTANT  PLS_INTEGER := 10;

  -- Help Access Constants (From WINUSER.H)
  --  See WIN_API_SHELL.WinHelp

  HELP_CONTEXT         CONSTANT  PLS_INTEGER := 1;   /* 0x0001L */
  HELP_QUIT            CONSTANT  PLS_INTEGER := 2;   /* 0x0002L */
  HELP_INDEX           CONSTANT  PLS_INTEGER := 3;   /* 0x0003L */
  HELP_CONTENTS        CONSTANT  PLS_INTEGER := 3;   /* 0x0003L */
  HELP_HELPONHELP      CONSTANT  PLS_INTEGER := 4;   /* 0x0004L */
  HELP_SETINDEX        CONSTANT  PLS_INTEGER := 5;   /* 0x0005L */
  HELP_SETCONTENTS     CONSTANT  PLS_INTEGER := 5;   /* 0x0005L */
  HELP_CONTEXTPOPUP    CONSTANT  PLS_INTEGER := 8;   /* 0x0008L */
  HELP_FORCEFILE       CONSTANT  PLS_INTEGER := 9;   /* 0x0009L */
  HELP_KEY             CONSTANT  PLS_INTEGER := 257; /* 0x0101L */
  HELP_COMMAND         CONSTANT  PLS_INTEGER := 258; /* 0x0102L */
  HELP_PARTIALKEY      CONSTANT  PLS_INTEGER := 261; /* 0x0105L */
  HELP_MULTIKEY        CONSTANT  PLS_INTEGER := 513; /* 0x0201L */
  HELP_SETWINPOS       CONSTANT  PLS_INTEGER := 515; /* 0x0203L */
  -- Windows 4+
  HELP_CONTEXTMENU     CONSTANT  PLS_INTEGER := 10;  /* 0x000a  */
  HELP_FINDER          CONSTANT  PLS_INTEGER := 11;  /* 0x000b  */
  HELP_WM_HELP         CONSTANT  PLS_INTEGER := 12;  /* 0x000c  */
  HELP_SETPOPUP_POS    CONSTANT  PLS_INTEGER := 13;  /* 0x000d  */

  -- Windows Messages for use with SendMessage
  -- DO NOT utilise the Windows Sendmessage interface without being conversant
  -- with the Windows message handling mechanism
  -- Refer to the Microsoft Windows SDK for Messages and Parameter values
  WM_SYSCOMMAND        CONSTANT  PLS_INTEGER := 274;   /* 0x0112 */
  WM_MDITILE           CONSTANT  PLS_INTEGER := 550;   /* 0x0226 */
  WM_MDICASCADE        CONSTANT  PLS_INTEGER := 551;   /* 0x0227 */
  WM_MDIICONARRANGE    CONSTANT  PLS_INTEGER := 552;   /* 0x0228 */      
  SC_RESTORE           CONSTANT  PLS_INTEGER := 61728; /* 0xF120 */
  SC_MINIMIZE          CONSTANT  PLS_INTEGER := 61472; /* 0xF020 */
  SC_MAXIMIZE          CONSTANT  PLS_INTEGER := 61488; /* 0xF030 */
  

  -- Flags for use with File Dialog boxes ("Save As" or "Open")
  -- Refer to your Microsoft documentation for details on the 
  -- Exact usage and dependancies of each option
  OFN_READONLY           CONSTANT  PLS_INTEGER := 1;        /* 0x00000001 */
  OFN_OVERWRITEPROMPT    CONSTANT  PLS_INTEGER := 2;        /* 0x00000002 */
  OFN_HIDEREADONLY       CONSTANT  PLS_INTEGER := 4;        /* 0x00000004 */
  OFN_NOCHANGEDIR        CONSTANT  PLS_INTEGER := 8;        /* 0x00000008 */
  OFN_SHOWHELP           CONSTANT  PLS_INTEGER := 16;       /* 0x00000010 */
  OFN_NOVALIDATE         CONSTANT  PLS_INTEGER := 256;      /* 0x00000100 */
  OFN_ALLOWMULTISELECT   CONSTANT  PLS_INTEGER := 512;      /* 0x00000200 */
  OFN_EXTENSIONDIFFERENT CONSTANT  PLS_INTEGER := 1024;     /* 0x00000400 */
  OFN_PATHMUSTEXIST      CONSTANT  PLS_INTEGER := 2048;     /* 0x00000800 */
  OFN_FILEMUSTEXIST      CONSTANT  PLS_INTEGER := 4096;     /* 0x00001000 */
  OFN_CREATEPROMPT       CONSTANT  PLS_INTEGER := 8192;     /* 0x00002000 */
  OFN_SHAREAWARE         CONSTANT  PLS_INTEGER := 16384;    /* 0x00004000 */
  OFN_NOREADONLYRETURN   CONSTANT  PLS_INTEGER := 32768;    /* 0x00008000 */
  OFN_NOTESTFILECREATE   CONSTANT  PLS_INTEGER := 65536;    /* 0x00010000 */
  OFN_NONETWORKBUTTON    CONSTANT  PLS_INTEGER := 131072;   /* 0x00020000 */
  OFN_NOLONGNAMES        CONSTANT  PLS_INTEGER := 262144;   /* 0x00040000 */
  OFN_EXPLORER           CONSTANT  PLS_INTEGER := 524288;   /* 0x00080000 */
  OFN_NODEREFERENCELINKS CONSTANT  PLS_INTEGER := 1048576;  /* 0x00100000 */
  OFN_LONGNAMES          CONSTANT  PLS_INTEGER := 2097152;  /* 0x00200000 */

  -- The defaults used here (WIN_API.OFN_PATHMUSTEXIST|WIN_API.OFN_FILEMUSTEXIST|WIN_API.OFN_HIDEREADONLY|WIN_API.OFN_NOCHANGEDIR|WIN_API.OFN_EXPLORER)
  OFN_FLAG_DEFAULT       CONSTANT  PLS_INTEGER :=  530444;
  
  
  -- Registry Data types for Write_RegistryEx
  REG_EXPAND_SZ          CONSTANT  PLS_INTEGER := 0;
  REG_SZ                 CONSTANT  PLS_INTEGER := 1;
  REG_DWORD              CONSTANT  PLS_INTEGER := 2;
  
  -- Compatibility Flags - Used where I have changed behaviour and you might not like the new version
  -- Change these at runtime to FALSE to revert to "old" behaviour
  COMPAT_EXPAND_REG_VALUES    BOOLEAN := TRUE;

  
  
  -- Types
  TYPE aFunctionHandle is table of WEBUTIL_C_API.FUNCTIONHANDLE index by BINARY_INTEGER;  
  SUBTYPE FILE_TYPE is PLS_INTEGER;

  -- Public Variables
  ERROR_ENCOUNTERED  BOOLEAN := FALSE;  /* The Last Call resulted in an error */
  ERROR_STACK        VARCHAR2(2000);    /* Holds Text of Last error(s) */ 
  API_ENABLED        BOOLEAN := FALSE;   /* Are API functions usable ?*/
  DLL_HANDLE         ORA_FFI.LibHandleType;
  FunctionHandle     aFunctionHandle;
   

  -- Public Exceptions
  NOT_AVAILABLE      EXCEPTION;  /* A call to the API was made but API functions not currently available (e.g. not on Windows) */
     
  -- Error Constants
  UError             CONSTANT  VARCHAR2(30) := ' Caused an unexpected error: ';
  NoAPI              CONSTANT  VARCHAR2(31) := 'API Functions are not Available';
  MaxDWord           CONSTANT  VARCHAR2(33) := 'Integer Argument exceeds 32 bits ';
  MaxWord            CONSTANT  VARCHAR2(33) := 'Integer Argument exceeds 16 bits ';
  MaxByte            CONSTANT  VARCHAR2(32) := 'Integer Argument exceeds 8 bits ';
  MinBound           CONSTANT  VARCHAR2(27) := 'Integer Argument too Small ';
  MaxBound           CONSTANT  VARCHAR2(27) := 'Integer Argument too Large ';
  NullArg            CONSTANT  VARCHAR2(24) := 'Argument cannot be NULL ';

  /*----------------------------------------------------------------------------*\
  * PreLoad ->  Loads the d2kwut60.dll from the jvm bin directory into memory
  \*----------------------------------------------------------------------------*/
```

#### SP-033 - WEBUTIL.GET_LINE

**Invoked From:**

- sr_exch_lyl_dlr_rep_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Reads a single line of text from an open client-side text file and returns it to the caller. The procedure delegates the actual file-read operation to the WebUtil PJC (Pluggable Java Component) layer via WebUtil_Core property calls, then interprets the returned buffer to distinguish a valid text line from an end-of-file condition. It is invoked indirectly through VIEW_EXCEL_REP in the dealer loyalty exchange report form.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| item | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the open file handle (file_type) passed in by the caller.
- Step 2 - Register the file handle with the WebUtil PJC by setting the WUF_TEXTIO_HANDLE property on the WUF_PACKAGE component via WebUtil_Core.setProperty.
- Step 3 - Request the next line of text from the PJC by reading the WUF_TEXTIO_GETLINE property via WebUtil_Core.getProperty; the result is stored in a local VARCHAR2 buffer (up to 4 000 characters).
- Step 4 - Evaluate the buffer content: if the PJC returned a lone newline character (CHR(10)), interpret this as the end-of-file sentinel and raise NO_DATA_FOUND to signal the caller that no more lines are available.
- Step 5 - If the buffer does not equal CHR(10), assign the buffer value to the OUT parameter item and return normally to the caller.
- Step 6 - If the WUF_PACKAGE bean is not registered on the client, catch the BEAN_NOT_REGISTERED exception, display an error alert identifying the missing implementation class, and re-raise TOOL_ERR.TOOL_ERROR to abort processing.
- Step 7 - If the PJC property call fails for any other reason, catch the PROPERTY_ERROR exception and re-raise TOOL_ERR.TOOL_ERROR to abort processing.

---
**Decision Points**

DP-001

Condition:
The value returned in the buffer by WebUtil_Core.getProperty equals CHR(10) (a lone newline character).

TRUE:
The end-of-file sentinel has been detected; raise NO_DATA_FOUND to inform the caller that there are no more lines to read.

FALSE:
The buffer contains a valid text line; assign the buffer to the OUT parameter item and return successfully.

---

DP-002

Condition:
WebUtil_Core raises BEAN_NOT_REGISTERED during the property set or get call.

TRUE:
Display an error alert identifying the missing PJC implementation class and raise TOOL_ERR.TOOL_ERROR to halt execution.

FALSE:
Proceed with normal processing; no alert is raised.

---

DP-003

Condition:
WebUtil_Core raises PROPERTY_ERROR during the property set or get call.

TRUE:
Raise TOOL_ERR.TOOL_ERROR immediately to halt execution.

FALSE:
Proceed with normal processing; no error is raised.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A lone newline character (CHR(10)) in the read buffer is reserved exclusively as the end-of-file sentinel injected by the PJC exception handler; it must never be treated as a valid line of text.
- BR-002 - The file handle supplied to the procedure must already be open; this procedure performs no file-open operation and relies entirely on the caller to provide a valid file_type handle.
- BR-003 - The maximum length of a single line that can be read and returned is 4 000 characters (the size of the internal buffer); lines exceeding this length are not supported.
- BR-004 - If the WebUtil PJC bean is not registered on the client machine, the procedure must surface a descriptive error alert before raising TOOL_ERR.TOOL_ERROR, ensuring the user receives actionable diagnostic information.
- BR-005 - Any PROPERTY_ERROR raised by the WebUtil Core layer must cause immediate termination via TOOL_ERR.TOOL_ERROR; partial or silent failures are not permitted.

---
**Implementation Logic**

```plsql
  PROCEDURE get_line (file file_type, item OUT VARCHAR2) is
    buffer VARCHAR2(4000 char);
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);        
    buffer := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_GETLINE');
    -- We can't easily tell the difference between an empty line and a line beyond then 
    -- end of the file so to get around this, the exception handling code in the PJC 
    -- places a newline into the buffer when the end of file is passed.
    -- The rational being that get_line would never normally return a newline because 
    -- it normally uses that to tell it where to read up *to*.
    if buffer = chr(10) then 
      raise NO_DATA_FOUND;
    else
      item := buffer;
    end if;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.get_line will not work');
      RAISE TOOL_ERR.TOOL_ERROR;                                                                 
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE TOOL_ERR.TOOL_ERROR;  
  END get_line;
  
  /**
   * File writing functions
   */
```

#### SP-034 - WEBUTIL.GET_STANDARD_OUTPUT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the standard output (stdout) stream captured from a previously executed host process. The function acts as a named convenience wrapper that constrains the output retrieval to the 'WUH_STDOUT' channel, returning the collected output lines as an OUTPUT_ARRAY for the calling routine.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETOUTPUT ([SP-029](#SP-029--WEBUTIL.GETOUTPUT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the PROCESS_ID of the target host process as the sole input parameter.
- Step 2 - Delegate retrieval to WEBUTIL.GETOUTPUT (SP-029), passing the supplied process identifier and the fixed output-channel identifier 'WUH_STDOUT'.
- Step 3 - Return the OUTPUT_ARRAY produced by WEBUTIL.GETOUTPUT directly to the caller.

---
**Decision Points**

No conditional decision points exist in this function. Execution follows a single, unconditional path: receive the process identifier, invoke WEBUTIL.GETOUTPUT with the 'WUH_STDOUT' channel constant, and return the result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The output channel is always fixed to 'WUH_STDOUT'; callers cannot override the channel through this function, ensuring only standard output (not standard error or other streams) is returned.
- BR-002 - A valid PROCESS_ID must be supplied; the function performs no independent validation and passes the identifier directly to WEBUTIL.GETOUTPUT (SP-029), which is responsible for resolving the process output.
- BR-003 - The return type is OUTPUT_ARRAY; the caller must handle an array structure, as the function does not flatten or summarise the captured output lines.

---
**Implementation Logic**

```plsql
    
  FUNCTION Get_Standard_Output(process in PROCESS_ID) return OUTPUT_ARRAY is  
  begin 
    return GetOutput(process,'WUH_STDOUT');
  end Get_Standard_Output;
```

#### SP-035 - WEBUTIL.ID_NULL

**Invoked From:**

- sr_exch_lyl_dlr_rep_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]
- webutil.pld [StoredProcedure: WEBUTIL.ERRORALERT]
- webutil.pld [StoredProcedure: WEBUTIL.INITWEBUTIL]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTER_FUNCTION]
- webutil.pld [StoredProcedure: WEBUTIL.SHOWBEANS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines whether a given handle object is uninitialised (null) by inspecting its internal identifier field. Returns TRUE if the handle carries no valid reference, or FALSE if a reference is present. Used by multiple WebUtil routines as a lightweight null-guard before operating on handle-based resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| handle | Pointer | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the incoming Pointer parameter (handle) passed by the calling routine.
- Step 2 - Inspect the internal identifier field (handle.hnd) of the supplied Pointer.
- Step 3 - If handle.hnd is NULL, return TRUE to indicate that the handle holds no valid reference.
- Step 4 - If handle.hnd is NOT NULL, return FALSE to indicate that the handle holds an active reference.

---
**Decision Points**

DP-001

Condition:
handle.hnd IS NULL

TRUE:
The function returns TRUE, signalling to the caller that the handle is uninitialised and no valid resource reference exists.

FALSE:
The function returns FALSE, signalling to the caller that the handle is initialised and a valid resource reference is present.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A handle is considered null solely on the basis of its internal identifier field (handle.hnd); no other attribute of the Pointer structure is evaluated.
- BR-002 - The function is read-only; it does not modify the handle or any application state, ensuring it is safe to call at any point without side-effects.
- BR-003 - The function must return a definitive BOOLEAN result (TRUE or FALSE) for every invocation; no indeterminate or exception path is permitted for the null-check logic.

---
**Implementation Logic**

```plsql

  FUNCTION ID_NULL(handle IN Pointer)        RETURN BOOLEAN is
  BEGIN
    if handle.hnd is null then 
      return TRUE;
    else
      return FALSE;
    end if;
  END ID_NULL;
```

#### SP-036 - WEBUTIL.INIT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETOUTPUT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Serves as the package-level initialisation entry point for the WEBUTIL_CORE package. The procedure body intentionally performs no procedural work; the act of entering the package is itself sufficient to trigger package initialisation. At the package level, the BEGIN block delegates the actual setup work to WEBUTIL.INITWEBUTIL (SP-037), which performs the substantive WebUtil utility initialisation.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.INITWEBUTIL ([SP-037](#SP-037--WEBUTIL.INITWEBUTIL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - The procedure body executes a NULL statement, confirming that no explicit procedural logic is required within INIT itself; package entry alone is sufficient to initialise the package state.
- Step 2 - Control returns to the package-level BEGIN block, which invokes WEBUTIL.INITWEBUTIL (SP-037) to perform the substantive initialisation of the WebUtil utility.

---
**Decision Points**

No decision points are present. The procedure body contains only a NULL statement and unconditionally delegates initialisation to WEBUTIL.INITWEBUTIL via the package-level BEGIN block.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Entering the WEBUTIL_CORE package is treated as sufficient to establish the package state; no explicit initialisation steps are required inside the INIT procedure body.
- BR-002 - All substantive WebUtil utility setup must be performed by WEBUTIL.INITWEBUTIL (SP-037), which is called unconditionally from the package-level initialisation block.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Init is
  begin 
    -- we don't need to do anything here - entering the package is enough to set it up.      
    null;
  end;      

BEGIN
  -- Initialise the Utility
  InitWebUtil;  
END WEBUTIL_CORE;

PACKAGE WEBUTIL_C_API IS
/*********************************************************************************\
 * WEBUTIL_C_API
 *   This Package provides a way of calling C functions in a shared library on the
 *   client PC. Currently only win32 is supported.
 *   The oracle.forms.webutil.cApi.CApiFunctions bean is needed in your Form to 
 *   use these functions
 *********************************************************************************
 * Version 1.0.5
 *********************************************************************************
 * Change History
 *   1.0.1 RVSUILIC 14/FEB/2003 - Creation 
 *   1.0.2 DRMILLS  27/FEB/2003 - Reset LONG to the same value as INT which is fine
 *                                for Windows & removed Tester proc
 *   1.0.3 DRMILLS  01/MAR/2003 - Re-worked the PL/SQL API
 *   1.0.4 DRMILLS  13/MAY/2003 - Added call to WebUtil_Core.Init
 *   1.0.5 RVSUILIC 21/MAY/2003 - Cleaned up some comments and formatting.
 *
\*********************************************************************************/

  /**
   *  Constants to represent PL/SQL IN, OUT and INOUT parameter qualifiers
   */
  PARAM_IN    CONSTANT PLS_INTEGER := 50;
  PARAM_INOUT CONSTANT PLS_INTEGER := 51;
  PARAM_OUT   CONSTANT PLS_INTEGER := 52;
  

  /**
   *  Constants to represent C atomic datatypes and pointers to atomic datatypes
   *  Note that to use OUT and INOUT qualifiers the C function in the DLL *must*
   *  use a pointer type to be able to pass information back.
   *
   *  The comments on the right indicate which types can be used for parameters
   *  and which for function return types.
   *
   *  c_ptr is used as a generic pointer. The onlys supported use for this is to
   *  save the pointer value from C into a PL/SQL variable, so that it may be 
   *  passed back later to C. No operations on the pointer are supported in PL/SQL.
   */
  c_void          CONSTANT PLS_INTEGER := 30;            /* - not used -   */
  c_char          CONSTANT PLS_INTEGER := 31;            /* param & return */
  c_short         CONSTANT PLS_INTEGER := 32;            /* param & return */
  c_int           CONSTANT PLS_INTEGER := 33;            /* param & return */
  c_long          CONSTANT PLS_INTEGER := 33;            /* param & return *//*DRM - same as INT */
  c_float         CONSTANT PLS_INTEGER := 35;            /* param & return */
  c_double        CONSTANT PLS_INTEGER := 36;            /* param & return */

  c_ptr           CONSTANT PLS_INTEGER := 64 + c_void;   /* param & return */
  c_char_ptr      CONSTANT PLS_INTEGER := 64 + c_char;   /* param          */
  c_short_ptr     CONSTANT PLS_INTEGER := 64 + c_short;  /* param          */
  c_int_ptr       CONSTANT PLS_INTEGER := 64 + c_int;    /* param          */
  c_long_ptr      CONSTANT PLS_INTEGER := 64 + c_long;   /* param          */
  c_float_ptr     CONSTANT PLS_INTEGER := 64 + c_float;  /* param          */
  c_double_ptr    CONSTANT PLS_INTEGER := 64 + c_double; /* param          */

  /**
   *  Abstracted types to be used for pointers and handles. The forms programmer
   *  should not attempt any manipulation on these types, but merely obtain them as
   *  a result of functions below, and pass them back in to other functions below.
   */
    SUBTYPE handleType   IS NUMBER;
    TYPE Pointer         IS RECORD (hnd handleType);   /* C pointer             */
    TYPE FunctionHandle  IS RECORD (hnd handleType);   /* function handle       */
    TYPE ParameterHandle IS RECORD (hnd handleType);   /* parameter handle      */
    TYPE ParameterList   IS RECORD (hnd handleType);   /* parameter list handle */

  /**
   *  IS_SUPPORTED - Check if the client is on a supported hardware platform.
   */
```

#### SP-037 - WEBUTIL.INITWEBUTIL

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.INIT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Initialises the WebUtil framework within an Oracle Form by registering the implementation class names for all known WebUtil packages, verifying that the required WebUtil object group is present in the form, optionally navigating to and rendering the WebUtil bean areas, and detecting the server operating system to set the correct file-path separator for subsequent file operations.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-035](#SP-035--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SHOWBEANS ([SP-052](#SP-052--WEBUTIL.SHOWBEANS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Capture the current cursor field (SYSTEM.CURSOR_FIELD) and locate the WebUtil dummy item (WEBUTIL_DUMMY_ITEM) to support later navigation.
- Step 2 - Populate the implementation-class registry (m_implClasses) with the fully qualified Java class names for each known WebUtil package constant (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL).
- Step 3 - Call WEBUTIL.ID_NULL against the package-level error-alert handle (m_errorAlert) to determine whether the WebUtil object group has been included in the current form.
- Step 4 - If the error alert handle is null (object group absent), display an error message informing the user that the WEBUTIL object group is unavailable and halt execution with PAUSE; no further initialisation is performed.
- Step 5 - If the error alert handle is valid and the explicit-instantiation flag (FLAG_EXPICIT_INSTANCIATE) is TRUE and the form is in NORMAL mode, proceed to instantiate bean areas.
- Step 6 - Call WEBUTIL.ID_NULL against the dummy item handle (hDummy) to confirm the standard object group is in use.
- Step 7 - If the dummy item exists, navigate to it via GO_ITEM(hDummy), then determine whether the original cursor field resides in the same block as the dummy item; if so, advance to NEXT_BLOCK, otherwise return focus to the original item via GO_ITEM(startPoint).
- Step 8 - Call WEBUTIL.SHOWBEANS(false) to render the bean areas without forcing focus.
- Step 9 - If the dummy item does not exist, take no action, assuming the developer is managing bean-area setup independently.
- Step 10 - Inspect the server operating system via GET_APPLICATION_PROPERTY(OPERATING_SYSTEM); if the value contains 'WIN' (case-insensitive), set the server file-path separator (m_serverFileSep) to backslash, otherwise set it to forward slash.

---
**Decision Points**

DP-001

Condition: WEBUTIL.ID_NULL(m_errorAlert) returns TRUE (the WebUtil error alert object is not found in the form).

TRUE: Display a message stating the WEBUTIL object group is unavailable, issue PAUSE, and abort initialisation - no bean setup or OS detection is performed.

FALSE: Continue with conditional bean-area instantiation and server OS detection.

---

DP-002

Condition: FLAG_EXPICIT_INSTANCIATE is TRUE AND SYSTEM.MODE equals 'NORMAL'.

TRUE: Proceed to check for the dummy item and perform bean-area navigation and rendering.

FALSE: Skip bean-area instantiation entirely; proceed directly to server OS detection.

---

DP-003

Condition: WEBUTIL.ID_NULL(hDummy) returns FALSE (the WebUtil dummy item exists, confirming the standard object group is in use).

TRUE: Navigate to the dummy item, resolve block context, and call WEBUTIL.SHOWBEANS(false) to render bean areas.

FALSE: Take no action; the developer is assumed to be managing bean-area setup independently.

---

DP-004

Condition: The block containing the original cursor field (startPoint) is the same block as the dummy item's block.

TRUE: Call NEXT_BLOCK to move focus away from the dummy item's block after bean rendering.

FALSE: Return focus to the original cursor field via GO_ITEM(startPoint).

---

DP-005

Condition: The server operating system property (GET_APPLICATION_PROPERTY(OPERATING_SYSTEM)) contains the string 'WIN' (case-insensitive).

TRUE: Set the server file-path separator (m_serverFileSep) to backslash ('\').

FALSE: Set the server file-path separator (m_serverFileSep) to forward slash ('/').

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The WEBUTIL object group must be present in the form (evidenced by a non-null m_errorAlert handle) before any WebUtil functionality can operate; if absent, initialisation is blocked and the user is notified.
- BR-002 - Implementation class names for all ten WebUtil packages must be registered in the m_implClasses registry during initialisation; the WUU package is registered with an empty class name, indicating it has no associated Java implementation.
- BR-003 - Explicit bean-area instantiation via navigation and WEBUTIL.SHOWBEANS is only performed when the FLAG_EXPICIT_INSTANCIATE flag is enabled and the form is in NORMAL mode; Enter-Query mode must not trigger this navigation to avoid known defects (Bug 2955789).
- BR-004 - When performing bean-area navigation, the procedure must restore the user's original cursor position; if the original field is in a different block from the dummy item, focus is returned to the original field after rendering.
- BR-005 - If the standard WebUtil dummy item is not found, the procedure takes no corrective action, deferring bean-area setup responsibility entirely to the developer.
- BR-006 - The server file-path separator must be determined at initialisation time based on the server operating system and stored in m_serverFileSep for use by subsequent file-handling operations; Windows environments use backslash, all others use forward slash.

---
**Implementation Logic**

```plsql
  
  PROCEDURE InitWebUtil is
    startPoint VARCHAR2(61 char) := NAME_IN('SYSTEM.CURSOR_FIELD');
    hDummy     ITEM              := FIND_ITEM(WEBUTIL_DUMMY_ITEM);
  BEGIN
    -- Set up the various package we know about.
    m_implClasses(WUC_PACKAGE) := 'common.VBeanCommon'; 
    m_implClasses(WUT_PACKAGE) := 'fileTransfer.FileTransfer'; 
    m_implClasses(WUF_PACKAGE) := 'file.FileFunctions'; 
    m_implClasses(WUI_PACKAGE) := 'clientInfo.GetClientInfo'; 
    m_implClasses(WUH_PACKAGE) := 'host.Host'; 
    m_implClasses(WUS_PACKAGE) := 'session.SessionFunctions'; 
    m_implClasses(WUB_PACKAGE) := 'browser.BrowserFunctions'; 
    m_implClasses(WUO_PACKAGE) := 'ole.OleFunctions'; 
    m_implClasses(WUU_PACKAGE) := '';      
    m_implClasses(WUL_PACKAGE) := 'cApi.CApiFunctions';                     
    
    -- Now check for the Webutil Object group which 
    -- contains the Beans etc.
          
    if id_null(m_errorAlert) then 
      -- The Webutil error alert is not around
      -- so the Code cannot operate 
      message('The WEBUTIL object group is not available in this Form.  WebUtil cannot work');
      pause;
    else
      -- Bug 2955789 - this navigation causes problems if they are in Enter-Query mode 
      -- Plus it's not really needed, except as a belt and braces kind of setup.
      -- So put a check to prevent this in E-Q mode and set a top level flag to bypass it 
      -- it all together which we can switch on or off if required as a furture W/A    
      if FLAG_EXPICIT_INSTANCIATE and name_in('SYSTEM.MODE') = 'NORMAL' then 
        if not ID_NULL(hDummy) then 
          -- they are using the standard Object Group
          GO_ITEM(hDummy);
          if GET_ITEM_PROPERTY(startPoint,BLOCK_NAME) = GET_ITEM_PROPERTY(hDummy,BLOCK_NAME) then 
            NEXT_BLOCK;
          else
            GO_ITEM(startPoint);
          end if;
          ShowBeans(false);        
        else
          -- do nothing assume that the programmer is doing their own thing.
          -- with regards to setting up the bean areas and making sure they are drawn
           null;      
        end if;
      end if;
    end if;
        
    -- Work out the server o/s informtion that we need
    if instr(upper(GET_APPLICATION_PROPERTY(OPERATING_SYSTEM)),'WIN') > 0 then 
      m_serverFileSep := '\';
    else
      m_serverFileSep := '/';
    end if;
  END InitWebUtil;
```

#### SP-038 - WEBUTIL.ISERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a boolean indicator of whether the most recent WebUtil operation resulted in an error. It evaluates the internal error-state variable `m_lastError` and returns TRUE if a non-zero error code is held, allowing callers such as WEBUTIL.LOG to branch their processing based on the current error status.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Read the current value of the package-level variable `m_lastError`, which holds the error code set by the most recently executed WebUtil operation.
- Step 2 - Compare `m_lastError` against zero to determine whether an error condition is active.
- Step 3 - Return the boolean result of the comparison to the caller: TRUE if `m_lastError` is non-zero (an error exists), FALSE if `m_lastError` equals zero (no error).

---
**Decision Points**

DP-001

Condition: `m_lastError <> 0`

TRUE: The function returns TRUE, signalling to the caller that the last WebUtil operation produced an error.

FALSE: The function returns FALSE, signalling to the caller that no error is currently recorded.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - An error condition is defined exclusively by `m_lastError` holding a non-zero value; any non-zero value, regardless of its magnitude or sign, is treated as an error.
- BR-002 - The function is read-only; it reports the error state but does not clear or modify `m_lastError`.
- BR-003 - The function accepts no input parameters; the error state is derived solely from the package-level variable `m_lastError` at the time of invocation.

---
**Implementation Logic**

```plsql
  FUNCTION isError   return BOOLEAN is
  begin 
    return m_lastError <> 0;
  end;
```

#### SP-039 - WEBUTIL.IS_OPEN

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines whether a file handle is currently open by inspecting the handle attribute of the supplied FILE_TYPE record. Returns TRUE if the file is open and FALSE if it is not, allowing callers such as WEBUTIL.LOG to guard against operations on unopened files.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FILE_TYPE record passed by the caller as an IN parameter.
- Step 2 - Evaluate the HANDLE attribute of the FILE_TYPE record to determine whether it holds a non-NULL value.
- Step 3 - If the HANDLE attribute is NULL, return FALSE to indicate that the file is not open.
- Step 4 - If the HANDLE attribute is not NULL, return TRUE to indicate that the file is open.

---
**Decision Points**

DP-001

Condition: file.handle IS NULL

TRUE: The function returns FALSE, signalling to the caller that the file is not currently open.

FALSE: The function returns TRUE, signalling to the caller that the file is currently open.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A FILE_TYPE record is considered open if and only if its HANDLE attribute is non-NULL; a NULL handle unconditionally indicates a closed or uninitialised file.
- BR-002 - The function performs no side effects and does not alter the state of the FILE_TYPE record or any external resource; it is a pure read-only check.
- BR-003 - The function accepts exactly one IN parameter of type FILE_TYPE and always returns a BOOLEAN result; no output parameters or exceptions are raised by this function.

---
**Implementation Logic**

```plsql
  
  FUNCTION is_open(file file_type) RETURN BOOLEAN IS
  BEGIN
    IF file.handle IS NULL THEN
      RETURN(FALSE);
    ELSE
      RETURN(TRUE);
    END IF;
  END is_open;
```

#### SP-040 - WEBUTIL.LENGTH

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: STRIPDIRSEP]
- webutil.pld [StoredProcedure: WEBUTIL.GETSTRING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the byte length of a file represented by a Java File object. The function delegates to the native Java method java.io.File.length() via the JNI bridge, providing Oracle Forms PL/SQL routines with the ability to determine the size of a client-side or server-side file without direct database interaction.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java File object (obj) passed in by the calling routine (e.g., WEBUTIL.GETSTRING, DEBUGLOG, REGISTER_FUNCTION_CALL, or STRIPDIRSEP).
- Step 2 - Clear the JNI argument list by setting args to NULL, ensuring no stale parameters are forwarded to the Java method call.
- Step 3 - Invoke JNI.CALL_LONG_METHOD with a non-virtual call flag (FALSE), passing the File object, the fully qualified Java class name 'java/io/File', the method name 'length', the method signature '()J' (no arguments, returns a long), and the cleared argument list.
- Step 4 - Return the numeric result (file size in bytes) received from the JNI call to the calling routine.

---
**Decision Points**

No conditional decision points exist in this function. The implementation follows a single, unconditional execution path: clear arguments, call the Java method, and return the result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The input parameter obj must be a valid ORA_JAVA.JOBJECT reference representing a java.io.File instance; the function does not perform null or type validation and relies on the caller to supply a well-formed object.
- BR-002 - The JNI method call is always non-virtual (FALSE flag), meaning the java.io.File.length() method is invoked directly on the declared class without polymorphic dispatch.
- BR-003 - The argument list (args) is explicitly reset to NULL before each invocation to prevent parameter contamination from prior JNI calls within the same session context.
- BR-004 - The returned value represents file size in bytes as a NUMBER, consistent with the Java long return type ('()J' signature); callers are responsible for interpreting or formatting this value appropriately.

---
**Implementation Logic**

```plsql
  FUNCTION length(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_LONG_METHOD(FALSE, obj, 'java/io/File', 'length', '()J', args); 
  END;
```

#### SP-041 - WEBUTIL.LOG

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]
- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.LOG writes a server-side diagnostic or error message to a configured log file. On first invocation it reads and caches three logging configuration properties (enabled flag, errors-only flag, and file path) from the property bundle, communicates the resolved logging mode to the WebUtil bean via a property value, and then appends the supplied message - prefixed with client IP and username when available - to the log file. If logging is misconfigured or the file cannot be written, the procedure disables logging and raises an appropriate alert or bean-level error.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| msg | VARCHAR2 | IN |
| isError | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-017](#SP-017--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ISERROR ([SP-038](#SP-038--WEBUTIL.ISERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.IS_OPEN ([SP-039](#SP-039--WEBUTIL.IS_OPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-044](#SP-044--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - On the first call, check whether the module-level logging cache variable (m_loggingAllowed) is uninitialised (NULL); if so, enter the one-time initialisation block.
- Step 2 - Read the 'logging.enabled' property via WEBUTIL.READFROMPROPERTYBUNDLE and store the Boolean result in m_loggingAllowed.
- Step 3 - Read the 'logging.errorsonly' property via WEBUTIL.READFROMPROPERTYBUNDLE and store the Boolean result in m_loggingErrorsOnly.
- Step 4 - Read the 'logging.file' property via WEBUTIL.READFROMPROPERTYBUNDLE and store the file path in m_loggingFile.
- Step 5 - If logging is enabled but no log file path was returned, set m_loggingAllowed to FALSE and raise error WUC-008: if no bean is registered yet, surface the error via WEBUTIL.ERRORALERT; otherwise signal the bean with property WUC_SRV_LOGGING = '0' and raise a bean-level error.
- Step 6 - If at least one bean is registered, communicate the resolved logging mode to the bean by setting WUC_SRV_LOGGING to '1' (logging enabled, errors only), '2' (logging enabled, all messages), or '0' (logging disabled).
- Step 7 - After initialisation, check whether logging is currently allowed (m_loggingAllowed = TRUE).
- Step 8 - If logging is allowed, check whether the current message qualifies: either errors-only mode is off, or errors-only mode is on and the isError flag is TRUE.
- Step 9 - Open the log file in append mode (TEXT_IO.FOPEN with mode 'A').
- Step 10 - Verify the file was opened successfully via TEXT_IO.IS_OPEN; if not, raise NO_DATA_FOUND.
- Step 11 - Write the message to the file: if m_clientIP is NULL, write the raw message; otherwise prefix it with m_clientIP, m_clientUserName, and a separator before the message.
- Step 12 - Close the log file via TEXT_IO.FCLOSE.
- Step 13 - In the OTHERS exception handler, if SQLCODE is -302000 (file write failure), raise error WUC-007 via WEBUTIL.ERRORALERT (no bean registered) or via the bean error mechanism (bean registered), set m_loggingAllowed to FALSE, and suppress further logging. Any other exception is re-raised.

---
**Decision Points**

DP-001

Condition: m_loggingAllowed IS NULL (logging cache has not yet been initialised for this session).

TRUE: Read all three logging configuration properties from the property bundle, evaluate and cache them, communicate the logging mode to the bean (if registered), and then proceed to the logging step.

FALSE: Skip initialisation and proceed directly to the logging step using the already-cached values.

---

DP-002

Condition: m_loggingAllowed is TRUE and m_loggingFile IS NULL (logging was requested but no file path was configured).

TRUE: Set m_loggingAllowed to FALSE and raise error WUC-008. If no bean is registered, surface the error via WEBUTIL.ERRORALERT; otherwise notify the bean with WUC_SRV_LOGGING = '0' and raise a bean-level error.

FALSE: Retain the current m_loggingAllowed value and continue.

---

DP-003

Condition: At least one bean is registered (m_registeredPackages.FIRST IS NOT NULL) after the file-path check.

TRUE: Set the WUC_SRV_LOGGING bean property to '1' (errors-only), '2' (all messages), or '0' (disabled) to reflect the resolved logging mode.

FALSE: Skip the bean property update; no bean is available to receive the notification.

---

DP-004

Condition: m_loggingAllowed is TRUE (logging is active).

TRUE: Evaluate whether the message qualifies for writing and, if so, open the file, write the message, and close the file.

FALSE: Exit the procedure without writing anything.

---

DP-005

Condition: m_loggingErrorsOnly is FALSE, OR (m_loggingErrorsOnly is TRUE AND the isError parameter is TRUE).

TRUE: Proceed to open the log file and write the message.

FALSE: Suppress the message; it does not meet the errors-only threshold.

---

DP-006

Condition: m_clientIP IS NULL at the time of writing.

TRUE: Write the raw message text to the log file without any prefix.

FALSE: Prefix the message with m_clientIP, m_clientUserName, and a separator before writing.

---

DP-007

Condition: An exception occurs and SQLCODE = -302000 (file write error).

TRUE: Raise error WUC-007 via WEBUTIL.ERRORALERT (no bean) or via the bean error mechanism (bean registered), set m_loggingAllowed to FALSE to prevent further attempts, and suppress the exception.

FALSE: Re-raise the exception to the caller unchanged.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Logging configuration (enabled flag, errors-only flag, and file path) is read from the property bundle exactly once per session and cached in module-level variables; subsequent calls use the cached values without re-reading the bundle.
- BR-002 - Logging is considered disabled if the 'logging.enabled' property does not resolve to the lowercase string 'true'.
- BR-003 - If logging is enabled but the 'logging.file' property returns no value, logging must be disabled (m_loggingAllowed set to FALSE) and error WUC-008 must be raised before any write is attempted.
- BR-004 - When no WebUtil bean is registered, user-facing errors (WUC-007, WUC-008) must be surfaced through WEBUTIL.ERRORALERT in plain English; when a bean is registered, errors are communicated through the bean's error mechanism.
- BR-005 - The WUC_SRV_LOGGING bean property must reflect the active logging mode: '0' = disabled, '1' = errors only, '2' = all messages.
- BR-006 - In errors-only mode (m_loggingErrorsOnly = TRUE), only messages passed with isError = TRUE are written to the log file; informational messages are silently discarded.
- BR-007 - Each qualifying log entry must be appended to the existing log file (open mode 'A'); the file must be closed after every individual write to prevent resource leaks.
- BR-008 - When client identity information is available (m_clientIP is not NULL), every log entry must be prefixed with the client IP address and username to support audit traceability.
- BR-009 - A file write failure (SQLCODE -302000) must disable all further logging for the session (m_loggingAllowed = FALSE) and raise error WUC-007; it must not propagate as an unhandled exception. All other exceptions are re-raised without suppression.

---
**Implementation Logic**

```plsql
  

  PROCEDURE Log(msg in VARCHAR2, isError BOOLEAN) is
    logFile       TEXT_IO.FILE_TYPE;
    logFileName   VARCHAR2(1024 char);
    errorOnlyMode BOOLEAN;
  begin
    -- check to see if we should do anything
    if m_loggingAllowed is null then 
      -- set up the logging info Cache
      m_loggingAllowed    := (lower(ReadFromPropertyBundle('logging.enabled')) = 'true');
      m_loggingErrorsOnly := (lower(ReadFromPropertyBundle('logging.errorsonly')) = 'true');
      m_loggingFile       := ReadFromPropertyBundle('logging.file');
      if m_loggingAllowed then 
        if m_loggingFile is null then 
          -- no file == no logging
          m_loggingAllowed := false;
          if m_registeredPackages.FIRST is null then
            -- There is no bean registered yet. Throw error in English using alert
            ErrorAlert('WUC-008: Server side logging was requested but no log file was specified'
                       ||' - logging is disabled');
          else
            WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
            WebUtil_Core.error(WUC_PACKAGE,8,'WebUtil_Core.Log');
          end if;
        end if;
      end if;
      if m_registeredPackages.FIRST is not null then
        -- At least one bean is registered. Can call setProperty(WUC_PACKAGE)
        if m_loggingAllowed and m_loggingErrorsOnly then
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','1',true);
        elsif  m_loggingAllowed then
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','2',true);
        else
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
        end if;
      end if;
    end if;
        
    -- now log if allowed to do so
    if m_loggingAllowed then
      if ((not m_loggingErrorsOnly) or (m_loggingErrorsOnly and isError)) then
        logFile := TEXT_IO.FOPEN(m_loggingFile,'A');
        if not TEXT_IO.IS_OPEN(logFile) then 
          raise NO_DATA_FOUND;
        end if;
        if m_clientIP is null then
        	TEXT_IO.PUT_LINE(logFile,msg);
        else
        	TEXT_IO.PUT_LINE(logFile,m_clientIP||':'||m_clientUserName||': '||msg);
        end if;
        TEXT_IO.FCLOSE(logFile);
      end if;    
    end if;
  EXCEPTION
    when others then 
      if SQLCODE = '-302000' then
        if m_registeredPackages.FIRST is null then
          -- There is no bean registered yet. Throw error in English using alert
          ErrorAlert('WUC-007: Unable to write to WebUtil Logging File '|| m_loggingFile);
        else

          WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
          WebUtil_Core.error(WebUtil_Core.WUC_PACKAGE,7,'WebUtil_Core.Log',m_loggingFile);
        end if;
        m_loggingAllowed := false;
      else
        RAISE;
      end if;      
  end Log;
```

#### SP-042 - WEBUTIL.POPULATEPROPERTYBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.READFROMPROPERTYBUNDLE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Locates and reads the WebUtil configuration file, parses its key-value property pairs into the in-memory property bundle (m_propertyBundle), and returns the value associated with the requested property key. The procedure resolves the configuration file path by checking, in priority order, a Forms global variable, an environment variable, and a Forms parameter, ensuring the configuration data is available before any WebUtil component attempts to read individual properties.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-017](#SP-017--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Attempt to resolve the configuration file path from the Forms global variable identified by WEBUTIL_CONFIG_GLOBAL; if the global holds the sentinel value '[NOTSET]', treat it as unset and proceed to the next source.
- Step 2 - If the global variable was unset, query the operating-system environment variable identified by WEBUTIL_CONFIG_ENV via TOOL_ENV.GETVAR; if a non-null value is returned, use it as the configuration file path.
- Step 3 - If the environment variable also yielded no value, read the configuration file path from the Forms parameter identified by WEBUTIL_CONFIG_PARAM; if this is also null, raise NO_DATA_FOUND to trigger the error-handling branch.
- Step 4 - Persist the resolved configuration file path back into the Forms global variable WEBUTIL_CONFIG_GLOBAL using COPY, so subsequent calls do not need to re-resolve the path.
- Step 5 - Open the resolved configuration file for reading using TEXT_IO.FOPEN.
- Step 6 - Read the file line by line in a loop using TEXT_IO.GET_LINE; exit the loop when NO_DATA_FOUND is raised (end of file).
- Step 7 - For each line, skip it if the first character is '#' (comment line).
- Step 8 - For non-comment lines, locate the '=' delimiter using INSTR; skip lines that contain no '=' character.
- Step 9 - For valid key-value lines, increment the property index, store the trimmed, lower-cased key and the trimmed, carriage-return-stripped value into the next slot of m_propertyBundle.
- Step 10 - Compare the stored key against the lower-cased input parameter propertyKey; if they match, capture the corresponding value into the result variable.
- Step 11 - After the loop completes, close the configuration file with TEXT_IO.FCLOSE and return the result value (NULL if the key was not found).
- Step 12 - On NO_DATA_FOUND exception (configuration file path not resolved): if no bean package is yet registered (m_registeredPackages.FIRST is null), call WEBUTIL.ERRORALERT to display error 'WUC-005: No WebUtil Configuration File specified'; otherwise delegate to Webutil_Core.Error with code WUC_PACKAGE/5. Set m_config_error to TRUE and return NULL.
- Step 13 - On OTHERS exception with SQLCODE '-302000' (file unreadable): if no bean package is registered, call WEBUTIL.ERRORALERT to display error 'WUC-006: Unable to read WebUtil Configuration File'; otherwise delegate to Webutil_Core.Error with code WUC_PACKAGE/6, passing the resolved configFile name. Set m_config_error to TRUE and return NULL. For any other unhandled exception, re-raise it.

---
**Decision Points**

DP-001

Condition: The Forms global variable WEBUTIL_CONFIG_GLOBAL contains the sentinel value '[NOTSET]'.

TRUE: The global is treated as unset; the procedure nullifies configFile and attempts to resolve the path from the environment variable (WEBUTIL_CONFIG_ENV) via TOOL_ENV.GETVAR.

FALSE: The value held in WEBUTIL_CONFIG_GLOBAL is used directly as the configuration file path; Steps 2 and 3 are skipped.

---

DP-002

Condition: The environment variable WEBUTIL_CONFIG_ENV returns a non-null value.

TRUE: The returned value is used as the configuration file path; the Forms parameter fallback (Step 3) is skipped.

FALSE: The procedure falls through to read the configuration file path from the Forms parameter WEBUTIL_CONFIG_PARAM.

---

DP-003

Condition: The Forms parameter WEBUTIL_CONFIG_PARAM returns a non-null value.

TRUE: The returned value is used as the configuration file path.

FALSE: NO_DATA_FOUND is raised, triggering the error-handling branch (Steps 12).

---

DP-004

Condition: The first character of a line read from the configuration file is '#'.

TRUE: The line is treated as a comment and skipped entirely; no property is stored.

FALSE: The line is evaluated for a key-value pair.

---

DP-005

Condition: The '=' delimiter is found at a position greater than zero within a non-comment line.

TRUE: The line is parsed into a key-value pair, stored in m_propertyBundle, and compared against propertyKey.

FALSE: The line contains no key-value pair and is skipped.

---

DP-006

Condition: The lower-cased, trimmed key parsed from the current line equals lower(propertyKey).

TRUE: The corresponding property value is assigned to the result variable, which will be returned after the file is fully read.

FALSE: The property is stored in m_propertyBundle but does not update the result variable.

---

DP-007

Condition: A NO_DATA_FOUND or SQLCODE '-302000' exception is raised AND m_registeredPackages.FIRST is null (no bean package registered).

TRUE: WEBUTIL.ERRORALERT is called to display the appropriate English-language error message (WUC-005 or WUC-006) directly to the user.

FALSE: Error handling is delegated to Webutil_Core.Error with the relevant package and error code constants.

---

DP-008

Condition: An OTHERS exception is raised and SQLCODE equals '-302000' (file-read failure).

TRUE: The file-unreadable error path is executed (DP-007 applies); m_config_error is set to TRUE and NULL is returned.

FALSE: The exception is re-raised to the caller without suppression.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The configuration file path must be resolvable from exactly one of three sources in strict priority order: (1) Forms global variable WEBUTIL_CONFIG_GLOBAL, (2) OS environment variable WEBUTIL_CONFIG_ENV, (3) Forms parameter WEBUTIL_CONFIG_PARAM. If none of these sources yields a value, the procedure treats the situation as a fatal configuration error.
- BR-002 - Once resolved, the configuration file path is written back to the Forms global variable WEBUTIL_CONFIG_GLOBAL so that the resolution process is not repeated on subsequent invocations within the same session.
- BR-003 - Lines in the configuration file that begin with the '#' character are treated as comments and must not be parsed or stored as property entries.
- BR-004 - Only lines containing an '=' character are treated as valid key-value pairs; lines without this delimiter are silently ignored.
- BR-005 - Property keys are stored and compared in lower-case with leading and trailing whitespace removed, ensuring case-insensitive, whitespace-tolerant key matching.
- BR-006 - Property values are stored with leading and trailing whitespace removed and carriage-return characters (CHR(13)) stripped, ensuring clean values regardless of the file's line-ending format.
- BR-007 - All valid key-value pairs encountered in the file are loaded into the in-memory property bundle m_propertyBundle, not only the requested key, making the full configuration available for subsequent reads without re-opening the file.
- BR-008 - When the configuration file path cannot be determined (NO_DATA_FOUND) or the file cannot be read (SQLCODE '-302000'), the flag m_config_error must be set to TRUE and the function must return NULL, signalling a configuration failure to the caller.
- BR-009 - User-facing error messages for configuration failures (WUC-005, WUC-006) are displayed via WEBUTIL.ERRORALERT only when no bean package has yet been registered; if a bean is registered, error reporting is delegated to the Webutil_Core framework.

---
**Implementation Logic**

```plsql
      
  FUNCTION PopulatePropertyBundle(propertyKey in VARCHAR2) return VARCHAR2 is
    configFile   VARCHAR2(512 char);
    buffer       VARCHAR2(1000 char);
    result       VARCHAR2(1000 char);          
    propertyFile TEXT_IO.FILE_TYPE;
    pos          PLS_INTEGER;
    propIndex    PLS_INTEGER := 0;
  begin
    -- First of get the name of the cfg file 
    -- This could come in a global  or from the Environment
    default_value('[NOTSET]',WEBUTIL_CONFIG_GLOBAL);
    configFile := name_in(WEBUTIL_CONFIG_GLOBAL);
    if configFile = '[NOTSET]' then
      configFile := null; 
      -- Try the environment
      TOOL_ENV.GETVAR(WEBUTIL_CONFIG_ENV, configFile); 
      if configFile is null then 
        -- Finally try the Forms parameters
        configFile := name_in(WEBUTIL_CONFIG_PARAM);
        -- if that fails then we have to raise an error
        if configFile is null then 
          raise NO_DATA_FOUND;
        end if;    
      end if;
    end if;
    
    copy(configFile, WEBUTIL_CONFIG_GLOBAL);
      
    propertyFile := Text_IO.FOpen(configFile,'R');
    LOOP
      begin
        Text_IO.Get_Line(propertyFile,buffer);
      exception
        when NO_DATA_FOUND then EXIT;
      end;
        
      -- ignore lines which start with '#'
      if substr(buffer,1,1) <> '#' then 
        pos := instr(buffer,'=');
        -- only process lines with a name value pair
        if pos > 0 then 
          propIndex := propIndex + 1;
          m_propertyBundle(propIndex).propertyKey   := lower(ltrim(rtrim(substr(buffer,1,pos-1))));    
          m_propertyBundle(propIndex).propertyValue := ltrim(rtrim(replace(substr(buffer,pos+1),chr(13),'')));
          -- Check to see if this is the key we are looking for
          if  m_propertyBundle(propIndex).propertyKey = lower(propertyKey) then
            result := m_propertyBundle(propIndex).propertyValue;
          end if;
        end if;
      end if;
    end LOOP;
    Text_IO.FClose(propertyFile);
    return result;
  EXCEPTION
    when NO_DATA_FOUND then 
      if m_registeredPackages.FIRST is null then
        -- There is no bean registered yet. Throw error in English using alert
        ErrorAlert('WUC-005: No WebUtil Configuration File specified');
      else
        Webutil_Core.Error(Webutil_Core.WUC_PACKAGE,5,'WebUtil_Core.PopulatePropertyBundle');
      end if;
      m_config_error := true;
      return null;
    when others then 
      if SQLCODE = '-302000' then
        if m_registeredPackages.FIRST is null then
          -- There is no bean registered yet. Throw error in English using alert
          ErrorAlert('WUC-006: Unable to read WebUtil Configuration File');
        else
          Webutil_Core.Error(Webutil_Core.WUC_PACKAGE,6,'WebUtil_Core.PopulatePropertyBundle', configFile);
        end if;
        m_config_error := true;
        return null;
      else
        RAISE;
      end if;      

  end PopulatePropertyBundle;
```

#### SP-043 - WEBUTIL.PUT_LINE

**Invoked From:**

- sr_exch_lyl_dlr_rep_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a line of text to an open client-side text file by delegating to the WebUtil_Core bean infrastructure. The procedure sets the target file handle, supplies the text content, and appends a newline character, effectively replicating the behaviour of CLIENT_TEXT_IO.put_line for use within Oracle Forms WebUtil-enabled sessions.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |
| item | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the open file handle (`file.file_type`) and the text string (`item`) to be written.
- Step 2 - Set the WUF_TEXTIO_HANDLE property on the WUF_PACKAGE bean via `WebUtil_Core.setProperty`, targeting the specific file identified by `file.handle`.
- Step 3 - Set the WUF_TEXTIO_PUT property on the WUF_PACKAGE bean via `WebUtil_Core.setProperty`, passing the text content (`item`) to be written to the file.
- Step 4 - Set the WUF_TEXTIO_NEWLINE property on the WUF_PACKAGE bean via `WebUtil_Core.setProperty` with a value of 1, instructing the bean to append a newline character after the text, completing the line write operation.
- Step 5 - If a `WebUtil_Core.BEAN_NOT_REGISTERED` exception is raised during any of the above steps, display an error alert identifying the missing bean class and raise `TOOL_ERR.TOOL_ERROR` to halt processing.
- Step 6 - If a `WebUtil_Core.PROPERTY_ERROR` exception is raised, raise `TOOL_ERR.TOOL_ERROR` to halt processing without an additional alert.

---
**Decision Points**

DP-001

Condition:
A `WebUtil_Core.BEAN_NOT_REGISTERED` exception is raised when attempting to set any of the three WebUtil_Core properties (handle, put, newline).

TRUE:
Display an error alert stating that the implementing bean class (resolved via `WebUtil_Core.getImplClass`) was not found and that CLIENT_TEXT_IO.put_line will not work; then raise `TOOL_ERR.TOOL_ERROR` to abort the calling process.

FALSE:
Processing continues normally to the next property-set call or completes successfully.

---

DP-002

Condition:
A `WebUtil_Core.PROPERTY_ERROR` exception is raised when attempting to set any of the three WebUtil_Core properties.

TRUE:
Raise `TOOL_ERR.TOOL_ERROR` immediately to abort the calling process; no additional alert is displayed.

FALSE:
Processing continues normally to the next property-set call or completes successfully.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure requires a valid, open file handle (`file.handle`) to be supplied by the caller; it does not open or validate the file itself.
- BR-002 - Text is always written as a complete line: the newline property (WUF_TEXTIO_NEWLINE = 1) is unconditionally appended after the text content, mirroring the semantics of a PUT_LINE operation.
- BR-003 - The WebUtil bean identified by `WebUtil_Core.WUF_PACKAGE` must be registered in the client session before this procedure is called; absence of the bean is treated as a fatal error.
- BR-004 - Both `WebUtil_Core.BEAN_NOT_REGISTERED` and `WebUtil_Core.PROPERTY_ERROR` exceptions result in `TOOL_ERR.TOOL_ERROR` being raised, ensuring that any file-write failure propagates as a hard error to the calling routine (`VIEW_EXCEL_REP`).
- BR-005 - No database interactions are performed; all operations are delegated entirely to the client-side WebUtil bean layer.

---
**Implementation Logic**

```plsql
    

  PROCEDURE put_line (file file_type, item VARCHAR2) is
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);              
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_PUT',item); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_NEWLINE',1); 
  EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.put_line will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;  
  END put_line;
```

#### SP-044 - WEBUTIL.READFROMPROPERTYBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.LOG]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value associated with a given property key from an in-memory property bundle collection. If the bundle has not yet been populated, it delegates to WEBUTIL.POPULATEPROPERTYBUNDLE to load it first. This function supports configuration-driven behaviour for routines such as WEBUTIL.CHECKLIBS, WEBUTIL.LOG, and WEBUTIL.REGISTERBEAN by providing a centralised, cached lookup of property values.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.POPULATEPROPERTYBUNDLE ([SP-042](#SP-042--WEBUTIL.POPULATEPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input property key (propertyKey) and capture the current count of entries in the in-memory collection m_propertyBundle.
- Step 2 - Check whether a configuration error flag (m_config_error) has been raised from a prior operation; if so, return NULL immediately without attempting any lookup.
- Step 3 - If no configuration error exists but the property bundle is empty (count = 0), delegate to WEBUTIL.POPULATEPROPERTYBUNDLE, passing the requested property key, and capture its return value as the result.
- Step 4 - If the property bundle is already populated (count > 0), iterate through all entries in m_propertyBundle comparing each entry's propertyKey (stored in lower-case) against the lower-case equivalent of the supplied input key.
- Step 5 - On finding a matching entry, assign the corresponding propertyValue to the result variable and exit the loop immediately.
- Step 6 - Return the resolved result value (or NULL if no match was found or a config error was present).

---
**Decision Points**

DP-001

Condition: m_config_error flag is TRUE.

TRUE: Return NULL immediately; no property lookup is attempted.

FALSE: Proceed to evaluate the state of the property bundle.

---

DP-002

Condition: The count of entries in m_propertyBundle equals zero (bundle is unpopulated).

TRUE: Call WEBUTIL.POPULATEPROPERTYBUNDLE with the supplied propertyKey and use its return value as the result.

FALSE: The bundle is already loaded; proceed to search it directly via iteration.

---

DP-003

Condition: During iteration, the current entry's propertyKey matches the lower-case form of the supplied input key.

TRUE: Assign the entry's propertyValue to the result variable and exit the loop.

FALSE: Continue iterating to the next entry; if the loop completes without a match, result remains NULL.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - If a configuration error has previously been recorded (m_config_error = TRUE), the function must return NULL without performing any lookup, preventing further processing against a known-bad configuration state.
- BR-002 - Property key comparisons are performed in lower-case; the supplied propertyKey is normalised to lower-case before being matched against stored keys, ensuring case-insensitive resolution.
- BR-003 - When the in-memory property bundle is empty, population is delegated entirely to WEBUTIL.POPULATEPROPERTYBUNDLE; the function does not attempt to read the configuration source directly.
- BR-004 - Once a matching property key is found during iteration, the loop exits immediately, returning the first matching value and preventing duplicate-key ambiguity.
- BR-005 - The return value is constrained to a maximum of 1000 characters (VARCHAR2(1000 char)), establishing the upper bound for any property value retrievable through this function.

---
**Implementation Logic**

```plsql
  
  FUNCTION ReadFromPropertyBundle(propertyKey in VARCHAR2) return VARCHAR2 is   
    result       VARCHAR2(1000 char);
    propCount    PLS_INTEGER := m_propertyBundle.COUNT;
  begin
    if m_config_error then
      -- already encountered problem reading the config file.
      return null;
    elsif (propCount = 0) then
      result := populatePropertyBundle(propertyKey);
    else
      for i in 1..propCount LOOP
        if m_propertyBundle(i).propertyKey = lower(propertyKey) then 
          result := m_propertyBundle(i).propertyValue;
          EXIT;
        end if;
      end LOOP;
    end if;
    return result;
  end ReadFromPropertyBundle;
```

#### SP-045 - WEBUTIL.READTRANSFROMMSGBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a translated message string from the WebUtil message bundle by composing a lookup key from the supplied property key and optional arguments, then delegating the read/write cycle to the WebUtil Core layer. The function is used to obtain localised UI text - currently the progress bar title - during library verification performed by WEBUTIL.CHECKLIBS.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |
| args | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message bundle property key (propertyKey) and an optional argument string (args) as inputs.
- Step 2 - Concatenate propertyKey and args with a pipe delimiter ('|') to form a composite lookup value.
- Step 3 - Write the composite lookup value to the WebUtil Core property store by calling Webutil_Core.setProperty, targeting the WUC_PACKAGE package identifier and the WUC_TRANS_MSG property name.
- Step 4 - Read the resolved (translated) message back from the same property store by calling Webutil_Core.getProperty with the same WUC_PACKAGE and WUC_TRANS_MSG identifiers.
- Step 5 - Return the translated message string to the caller (WEBUTIL.CHECKLIBS).

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a fixed sequence of set and get operations against the WebUtil Core property store without branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The composite lookup value passed to the message bundle must be formed by concatenating propertyKey and args with a pipe character ('|') as the delimiter, even when args is NULL, ensuring a consistent key format for the WebUtil Core property store.
- BR-002 - The translated message is retrieved exclusively via Webutil_Core.getProperty targeting WUC_PACKAGE and WUC_TRANS_MSG; no direct database or file access is performed by this function.
- BR-003 - The args parameter is optional (defaults to NULL); callers are not required to supply argument values when a simple key lookup is sufficient.

---
**Implementation Logic**

```plsql
  
  FUNCTION ReadTransFromMsgBundle(propertyKey in VARCHAR2, args in VARCHAR2 := null) return VARCHAR2 is
    -- currently called from checkLibs only for getting progress bar title.
  begin 
    Webutil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_TRANS_MSG', propertyKey||'|'||args);
    return Webutil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_TRANS_MSG');
  end ReadTransFromMsgBundle;
```

#### SP-046 - WEBUTIL.REGISTERBEAN

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a WebUtil client-side bean with the Oracle Forms session on its first connection event. The procedure parses the bean's registration packet, maps the bean short name to an internal package identifier, captures one-time client environment data (IP address, OS, architecture, locale, path separators), resolves and communicates the system-library download directory to the client, retrieves and stores the WebUtil version, applies heartbeat-blocking and server-logging configuration, and triggers client-library validation for both the newly registered package and any user-defined libraries.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| clientInfo | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.CHECKLIBS ([SP-011](#SP-011--WEBUTIL.CHECKLIBS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTSETTING ([SP-023](#SP-023--WEBUTIL.GETCLIENTSETTING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETOSFAMILY ([SP-028](#SP-028--WEBUTIL.GETOSFAMILY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETPROPERTY ([SP-030](#SP-030--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETVAR ([SP-032](#SP-032--WEBUTIL.GETVAR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-041](#SP-041--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-044](#SP-044--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETCLIENTSETTING ([SP-049](#SP-049--WEBUTIL.SETCLIENTSETTING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Extract the bean short name from the pipe-delimited clientInfo string (position 1) using DelimStr.getString.
- Step 2 - Map the bean short name (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL) to the corresponding WEBUTIL_CORE package-ID constant and store it in packageID.
- Step 3 - If m_clientIP is null (i.e., this is the very first bean registration in the session), set the checkUserLibs flag to TRUE and parse the remaining clientInfo fields: client IP (position 2), OS name (position 3), OS architecture (position 4), username (position 5), path separator (position 6), file separator (position 7), and language code (position 8).
- Step 4 - Derive m_clientOSFamily from m_clientOS via WEBUTIL.GETOSFAMILY; if the OS architecture string contains '64', set m_clientOSArch to 1.
- Step 5 - If the packageID does not yet exist in the m_registeredPackages array, record the current trigger item (NAME_IN('SYSTEM.TRIGGER_ITEM')) against that packageID and set the newPackage flag to TRUE, ensuring only the first instance of each bean type is registered.
- Step 6 - When checkUserLibs is TRUE, reset REDOWNLOAD_SYSLIB to FALSE, then retrieve the server host name by calling WEBUTIL.GETVAR for 'COMPUTERNAME', falling back to 'HOST' if the first call returns null.
- Step 7 - Look up the client system-library directory from the property bundle using WEBUTIL.READFROMPROPERTYBUNDLE with an OS-family-and-architecture-specific key; if not found, retry with an OS-family-only key.
- Step 8 - If no client library directory is configured, send a WUC_SYSLIB_DIR property to the client (via WebUtil_Core.setProperty) containing only the server host and application config, allowing the client JRE to determine placement; otherwise, substitute any '$(SERVERHOST)' placeholder in the configured path with the resolved server host name and send the full path.
- Step 9 - When a specific client library directory is configured, retrieve the previously stored directory via WEBUTIL.GETCLIENTSETTING ('install.syslib.dir'); if it differs from the current value, update it via WEBUTIL.SETCLIENTSETTING and set REDOWNLOAD_SYSLIB to TRUE.
- Step 10 - Retrieve and store the WebUtil bean version by calling WEBUTIL.GETPROPERTY for the WUC_BEAN_VERSION property.
- Step 11 - If the 'logging.connections' property bundle entry equals 'true' (case-insensitive), call WEBUTIL.LOG to record a connection entry containing the current form name, client OS, and locale.
- Step 12 - If the newPackage flag is TRUE, call WEBUTIL.CHECKLIBS with the string representation of packageID to validate and download required libraries for the newly registered bean package.
- Step 13 - If checkUserLibs is TRUE, call WEBUTIL.LOG with a null message to initialise the m_loggingAllowed and m_loggingErrorsOnly session flags.
- Step 14 - Read the 'BlockAllowHeartBeat' property bundle entry; if its lower-cased value is 'true', 'yes', or '1', send WUC_BLOCK_ALLOW_HEART_BEAT = '1' to the client bean; otherwise send '0'.
- Step 15 - Evaluate the m_loggingAllowed and m_loggingErrorsOnly flags and send the corresponding WUC_SRV_LOGGING value to the client bean: '1' for errors-only logging, '2' for full logging, or '0' for logging disabled.
- Step 16 - If checkUserLibs is TRUE, call WEBUTIL.CHECKLIBS with 'user' to validate and download any user-defined client libraries.

---
**Decision Points**

DP-001
Condition: beanShortName matches one of the known constants (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL).
TRUE: packageID is set to the corresponding WEBUTIL_CORE package-ID constant.
FALSE: packageID remains uninitialised; no package mapping is established for unrecognised bean names.

DP-002
Condition: m_clientIP IS NULL (first bean registration in the current Forms session).
TRUE: checkUserLibs is set to TRUE and all client environment fields (IP, OS, OS family, architecture, username, path separator, file separator, language code) are parsed from clientInfo.
FALSE: Client environment fields are already populated; parsing is skipped and checkUserLibs remains FALSE.

DP-003
Condition: The OS architecture string (position 4 of clientInfo) contains '64'.
TRUE: m_clientOSArch is set to 1 (64-bit client).
FALSE: m_clientOSArch remains at its default value (32-bit assumed).

DP-004
Condition: m_registeredPackages does NOT already contain an entry for packageID.
TRUE: The current trigger item is stored against packageID in m_registeredPackages and newPackage is set to TRUE.
FALSE: The bean type is already registered; no update is made and newPackage remains FALSE.

DP-005
Condition: clientLibDir resolved from the OS-family-and-architecture-specific property bundle key IS NULL.
TRUE: A second lookup is attempted using the OS-family-only key.
FALSE: The architecture-specific directory is used directly.

DP-006
Condition: clientLibDir remains NULL after both property bundle lookups.
TRUE: WUC_SYSLIB_DIR is sent to the client containing only the server host and application config; the client JRE determines the library placement location.
FALSE: The configured directory path is used; any '$(SERVERHOST)' placeholder is replaced with the resolved server host name before sending WUC_SYSLIB_DIR.

DP-007
Condition: clientLibDirOld (retrieved via WEBUTIL.GETCLIENTSETTING) differs from clientLibDir.
TRUE: The new directory is persisted via WEBUTIL.SETCLIENTSETTING and REDOWNLOAD_SYSLIB is set to TRUE.
FALSE: The stored directory matches the current value; no update is made and REDOWNLOAD_SYSLIB remains FALSE.

DP-008
Condition: WEBUTIL.READFROMPROPERTYBUNDLE('logging.connections') evaluates to 'true' (case-insensitive).
TRUE: WEBUTIL.LOG is called to record the connection details (form name, client OS, locale).
FALSE: No connection log entry is written.

DP-009
Condition: newPackage is TRUE.
TRUE: WEBUTIL.CHECKLIBS is called with the string representation of packageID to validate required client libraries for the newly registered bean.
FALSE: Library check for this package is skipped.

DP-010
Condition: blockAllowHeartBeat (lower-cased) equals 'true', 'yes', or '1'.
TRUE: WUC_BLOCK_ALLOW_HEART_BEAT is set to '1', instructing the client bean to block heartbeat allowance.
FALSE: WUC_BLOCK_ALLOW_HEART_BEAT is set to '0', leaving default heartbeat behaviour.

DP-011
Condition: m_loggingAllowed is TRUE AND m_loggingErrorsOnly is TRUE.
TRUE: WUC_SRV_LOGGING is set to '1' (errors-only logging communicated to client bean).
FALSE: Evaluation continues to DP-012.

DP-012
Condition: m_loggingAllowed is TRUE (and m_loggingErrorsOnly is FALSE).
TRUE: WUC_SRV_LOGGING is set to '2' (full logging communicated to client bean).
FALSE: WUC_SRV_LOGGING is set to '0' (logging disabled on client bean).

DP-013
Condition: checkUserLibs is TRUE (evaluated for the second time, after library checks for the new package).
TRUE: WEBUTIL.CHECKLIBS is called with 'user' to validate and download user-defined client libraries.
FALSE: User library check is skipped.

---
**Database Interactions**

- DB-001 - Update THIS - Updates existing rows in THIS.
**Business Rules**

- BR-001 - Only the ten recognised bean short names (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL) are mapped to internal package IDs; unrecognised short names result in no package registration.
- BR-002 - Client environment data (IP address, OS name, OS family, architecture, username, path separator, file separator, language code) is captured exactly once per Forms session, on the first bean registration event.
- BR-003 - A bean package is registered at most once per session; if the same bean type appears in a multi-row block or is instantiated multiple times, only the first instance is recorded.
- BR-004 - The system-library directory lookup follows a precedence order: OS-family-plus-architecture-specific key first, OS-family-only key second; if neither is configured, the client JRE determines library placement.
- BR-005 - The '$(SERVERHOST)' placeholder within a configured client library directory path must be replaced with the runtime-resolved server host name before the path is transmitted to the client.
- BR-006 - If the resolved client system-library directory differs from the previously stored value, the stored value must be updated via WEBUTIL.SETCLIENTSETTING and the REDOWNLOAD_SYSLIB flag must be set to TRUE to trigger re-download.
- BR-007 - Connection logging is conditional: a log entry is written only when the 'logging.connections' property bundle entry is explicitly set to 'true' (case-insensitive).
- BR-008 - The WEBUTIL.LOG initialisation call (null message) must occur after at least one bean package has been registered, ensuring a handler bean exists to process the call.
- BR-009 - Heartbeat blocking is activated only when the 'BlockAllowHeartBeat' configuration entry is set to 'true', 'yes', or '1' (case-insensitive); all other values result in default heartbeat behaviour.
- BR-010 - Server-side logging state (errors-only, full, or disabled) must be communicated to the client bean on every bean registration via the WUC_SRV_LOGGING property, so the client does not send unnecessary log messages to the server.
- BR-011 - User library validation (WEBUTIL.CHECKLIBS 'user') is performed only once per session (guarded by checkUserLibs) and must be executed after the first bean package has been registered so that a handler bean is available to perform any required downloads.
- BR-012 - Package-level library validation (WEBUTIL.CHECKLIBS with packageID) is performed only for newly registered bean packages (newPackage = TRUE) and not on subsequent registrations of the same bean type.

---
**Implementation Logic**

```plsql
  PROCEDURE registerBean(clientInfo in VARCHAR2) is  
    packageID       PLS_INTEGER;
    beanShortName   VARCHAR2(3 char);
    newPackage      BOOLEAN := false;
    checkUserLibs   BOOLEAN := false;
    clientLibDir    VARCHAR2(1000 char);
    clientLibDirOld VARCHAR2(1000 char);
    serverHost      VARCHAR2(100 char);
    blockAllowHeartBeat VARCHAR2(10 char);
    clientOSArch    VARCHAR2(30 char);
  begin
    beanShortName := DelimStr.getString(clientInfo,1,true,'|');

    -- To speed access up we crossmatch the Bean Name string
    -- with a constant - this constant is used to access the 
    -- registered package array efficently
    -- need to update this IF statement as we add new packages
    if beanShortName = 'WUC' then
       packageID := WEBUTIL_CORE.WUC_PACKAGE; 
    elsif beanShortName = 'WUT' then     
       packageID := WEBUTIL_CORE.WUT_PACKAGE; 
    elsif beanShortName = 'WUF' then 
       packageID := WEBUTIL_CORE.WUF_PACKAGE; 
    elsif beanShortName = 'WUI' then
        packageID := WEBUTIL_CORE.WUI_PACKAGE; 
    elsif beanShortName = 'WUH' then            
       packageID := WEBUTIL_CORE.WUH_PACKAGE;
    elsif beanShortName = 'WUS' then     
       packageID := WEBUTIL_CORE.WUS_PACKAGE;
    elsif beanShortName = 'WUB' then 
       packageID := WEBUTIL_CORE.WUB_PACKAGE;
    elsif beanShortName = 'WUO' then     
       packageID := WEBUTIL_CORE.WUO_PACKAGE;
    elsif beanShortName = 'WUU' then     
       packageID := WEBUTIL_CORE.WUU_PACKAGE;
    elsif beanShortName = 'WUL' then     
       packageID := WEBUTIL_CORE.WUL_PACKAGE;           
    end if;
    -- For the very first bean we can get a bit of useful information
    -- Only do this once
    if m_clientIP is null then 
      checkUserLibs := true;
      -- Format of the clientinfo packet is
      -- BeanName|IP|OSName|UserName|pathSep|filesep
      m_clientIP       := DelimStr.getString(clientInfo,2,true,'|');
      m_clientOS       := DelimStr.getString(clientInfo,3,true,'|');
      m_clientOSFamily := getOSFamily(m_clientOS);
      clientOSArch     := DelimStr.getString(clientInfo,4,true,'|');
      if instr(clientOSArch, '64') > 0 then
        m_clientOSArch := 1;
      end if;
      m_clientUserName := DelimStr.getString(clientInfo,5,true,'|');      
      m_clientPathSep  := DelimStr.getString(clientInfo,6,true,'|');
      m_clientFileSep  := DelimStr.getString(clientInfo,7,true,'|');
      m_clientLangCode := DelimStr.getString(clientInfo,8,true,'|'); 
    end if;
      
    -- I'd only expect one instance of each bean per form
    -- but just in case we only register the first 
    -- so if multiple copies are used - e.g. it's 
    -- placed in a multi-row block we just use the 
    -- first instance.
    if not m_registeredPackages.EXISTS(packageID) then 
      m_registeredPackages(packageID) := name_in('SYSTEM.TRIGGER_ITEM');
      -- make sure all the required libraries are available
      -- on the client
      newPackage := true;
    end if;
      
    if checkUserLibs then
      -- checkUserLibs would be true if clientIP was null
      -- We can do whatever we want to do but not more than once
      REDOWNLOAD_SYSLIB := FALSE;
      -- We need to get the server host name using available built-ins. This looks lame,
      -- but it should work
      TOOL_ENV.GETVAR('COMPUTERNAME', serverHost);
      if serverHost is null then
        TOOL_ENV.GETVAR('HOST', serverHost);
      end if;
      clientLibDir := readFromPropertyBundle('install.syslib.location.client.'||to_char(m_clientOSFamily) ||
                                             '.' || to_char(m_clientOSArch));
      if clientLibDir is null then
        clientLibDir := readFromPropertyBundle('install.syslib.location.client.'||to_char(m_clientOSFamily));
      end if;
      if clientLibDir is null then
        -- client location when syslib download is not defined in webutil.cfg
        -- will be to client JRE. Send nothing and client will handle
        WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SYSLIB_DIR',
                                 ':' || serverHost || ':' || GET_APPLICATION_PROPERTY(CONFIG),
                                 true);
      else
        -- webutil.cfg contains a specific client directory for syslib download
        -- Replace $(SERVERHOST), if exists, with server host name
        clientLibDir := replace(clientLibDir, '$(SERVERHOST)', serverHost);

        -- The following line makes a few things happen on client including
        -- client directory creation, when clientLibDir is not null
        WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SYSLIB_DIR',
                                 clientLibDir || ':' || serverHost || ':' || GET_APPLICATION_PROPERTY(CONFIG),
                                 true);
        clientLibDirOld := GetClientSetting('install.syslib.dir');

        if clientLibDirOld <> clientLibDir then
    	  SetClientSetting('install.syslib.dir', clientLibDir);
          REDOWNLOAD_SYSLIB := TRUE;
    	end if;
      end if;
      Webutil_Core.WEBUTIL_VERSION := getProperty(WUC_PACKAGE,'WUC_BEAN_VERSION');
      -- We want to write the connection record if it's required.
      -- Any call to ReadFromPropertyBundle or log should be preferably made after
      -- registering at least one bean. That is the reason why the following log
      -- comes after m_registeredPackages(packageID) := name_in('SYSTEM.TRIGGER_ITEM'); above
      if lower(ReadFromPropertyBundle('logging.connections')) = 'true' then 
        log('Connection from Form='||GET_APPLICATION_PROPERTY(CURRENT_FORM)||' Client O/S='||m_clientOS||' locale='||m_clientLangCode,false);
      end if;
    end if;
    if newPackage then  
            checkLibs(to_char(packageID));
    end if;

    if checkUserLibs then
      -- Call a dummy log to initialize m_loggingAllowed and m_loggingErrorsOnly
      log(null,false);
    end if;

    -- 5950737 - Introduce new configuration variable BlockAllowHeartBeat. 
    -- Valid values are true, yes and 1.
    -- If this is set then send a message to the client to behave accordingly.    
    blockAllowHeartBeat := lower(ReadFromPropertyBundle('BlockAllowHeartBeat'));
    if blockAllowHeartBeat = 'true' or blockAllowHeartBeat = 'yes' or blockAllowHeartBeat = '1' then 
      WebUtil_Core.setProperty(packageID,'WUC_BLOCK_ALLOW_HEART_BEAT','1',true);
    else
      WebUtil_Core.setProperty(packageID,'WUC_BLOCK_ALLOW_HEART_BEAT','0',true);
    end if;

    -- Send server logging options to client bean so that the bean does not have
    -- to send message to server unnecessarily.
    if m_loggingAllowed and m_loggingErrorsOnly then
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','1',true);
    elsif m_loggingAllowed then
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','2',true);
    else
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','0',true);
    end if;
      
    -- 2836929 - move the user library check after the first package is registered 
    -- so that a handler bean exists to do the download.     
    if checkUserLibs then 
      --Check for and download any user libs
      checkLibs('user');  
    end if;     
  end registerBean;
```

#### SP-047 - WEBUTIL.REGISTER_FUNCTION

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a named function from a specified library with the WebUtil bean layer and returns a FunctionHandle that uniquely identifies the registered function for subsequent invocations. The procedure communicates with the WebUtil core component to resolve the library/function combination into a numeric handle, and tracks the total count of successfully registered function handles within the session.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| libName | VARCHAR2 | IN |
| funcName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-035](#SP-035--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the library name (libName) and function name (funcName) as input parameters.
- Step 2 - Concatenate libName and funcName with a pipe delimiter and submit the combined specification to the WebUtil core layer by setting the WUL_FUNCTION_SPEC property on the WUL_PACKAGE component.
- Step 3 - Retrieve the resulting string handle from the WebUtil core layer by reading the WUL_REGISTER_FUNCTION property on the WUL_PACKAGE component.
- Step 4 - Convert the retrieved string handle to a numeric value and assign it to the hnd attribute of the local FunctionHandle variable.
- Step 5 - Evaluate the FunctionHandle using ID_NULL (SP-035) to determine whether a valid (non-null) handle was returned.
- Step 6 - If the handle is valid (not null), increment the session-level function handle counter (m_funcHandleCount) by 1.
- Step 7 - Return the populated FunctionHandle to the caller.
- Step 8 - If the WebUtil bean is not registered, display an error alert identifying the missing implementation class and raise FORM_TRIGGER_FAILURE to halt processing.
- Step 9 - If a property error occurs during core communication, raise FORM_TRIGGER_FAILURE to halt processing.
- Step 10 - If the retrieved string handle cannot be converted to a number (VALUE_ERROR), raise TOOL_ERR.TOOL_ERROR.

---
**Decision Points**

DP-001

Condition: The FunctionHandle returned by the WebUtil core layer is evaluated via ID_NULL (SP-035) to determine whether it represents a valid, non-null handle.

TRUE (handle is NOT null - i.e., ID_NULL returns FALSE): The session-level function handle counter (m_funcHandleCount) is incremented by 1, and the valid FunctionHandle is returned to the caller.

FALSE (handle IS null - i.e., ID_NULL returns TRUE): The counter is not incremented; the null FunctionHandle is still returned to the caller without modification.

---

DP-002

Condition: A BEAN_NOT_REGISTERED exception is raised during the WebUtil core property set or get operation, indicating the required WebUtil implementation class is not available.

TRUE: An error alert is displayed to the user identifying the missing bean class, and FORM_TRIGGER_FAILURE is raised to abort the current trigger execution.

FALSE: Processing continues normally to the property retrieval and handle conversion steps.

---

DP-003

Condition: A PROPERTY_ERROR exception is raised during communication with the WebUtil core layer.

TRUE: FORM_TRIGGER_FAILURE is raised immediately to abort the current trigger execution without displaying an additional alert.

FALSE: Processing continues normally.

---

DP-004

Condition: A VALUE_ERROR exception is raised when attempting to convert the retrieved string handle to a number via TO_NUMBER.

TRUE: TOOL_ERR.TOOL_ERROR is raised to signal an unrecoverable data conversion failure to the calling environment.

FALSE: The numeric conversion succeeds and the FunctionHandle is populated normally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The library name and function name must both be supplied as input; they are concatenated with a pipe character ('|') as the delimiter when submitting the function specification to the WebUtil core layer.
- BR-002 - A FunctionHandle is only considered successfully registered if ID_NULL (SP-035) returns FALSE for the handle returned by the WebUtil core layer; only in this case is the session-level registration counter incremented.
- BR-003 - The WebUtil bean corresponding to the WUL_PACKAGE implementation class must be registered and available at the time of invocation; absence of the bean is a terminal error condition that prevents function registration.
- BR-004 - The string value returned by the WebUtil core layer for the registered function must be convertible to a valid number; a non-numeric return value is treated as an unrecoverable error and surfaces as TOOL_ERR.TOOL_ERROR.
- BR-005 - Any property communication error with the WebUtil core layer (PROPERTY_ERROR) causes immediate termination of the current form trigger via FORM_TRIGGER_FAILURE, with no partial result returned.

---
**Implementation Logic**

```plsql

  FUNCTION REGISTER_FUNCTION (libName IN VARCHAR2, funcName IN VARCHAR2) 
                              RETURN FunctionHandle IS
    strHnd  VARCHAR2(8);                            
    funcHnd FunctionHandle;
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUL_PACKAGE,'WUL_FUNCTION_SPEC', libName || '|' || funcName);
    strHnd := WebUtil_Core.getProperty(WebUtil_Core.WUL_PACKAGE,'WUL_REGISTER_FUNCTION');
    funcHnd.hnd := TO_NUMBER (strHnd);
    if NOT ID_NULL(funcHnd) then
      m_funcHandleCount := m_funcHandleCount + 1;
    end if;

    RETURN funcHnd;
    
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUL_PACKAGE)
                              ||' bean not found. WEBUTIL_C_API.REGISTER_FUNCTION will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;  
    when VALUE_ERROR then
        RAISE TOOL_ERR.TOOL_ERROR; 
  END REGISTER_FUNCTION;
```

#### SP-048 - WEBUTIL.RELEASE_PROCESS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Releases a previously acquired host process handle by clearing its associated WebUtil property and callback trigger, then nullifying the handle reference. This ensures that process resources are properly cleaned up after use, preventing stale or orphaned process handles from persisting in the WebUtil session.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the PROCESS_ID handle (IN OUT) representing an active host process to be released.
- Step 2 - Invoke WebUtil_Core.setProperty to clear the WUH_CLEAR_PROC property on the WUH_PACKAGE bean, passing the current process handle value, signalling the WebUtil layer to release the associated native process resource.
- Step 3 - Invoke WebUtil_Core.ClearCallbackTrigger with the process handle to deregister any callback trigger that was registered against this process, preventing further callback events from firing.
- Step 4 - Set process.handle to NULL, marking the PROCESS_ID as released and preventing any subsequent use of the now-invalid handle by the caller.
- Step 5 - If a BEAN_NOT_REGISTERED exception is raised during Steps 2-3, invoke WebUtil_Core.ErrorAlert to display a descriptive error message indicating that the required WebUtil bean could not be found and that WEBUTIL_HOST.Release_Process will not function, then allow the exception handler to exit the procedure.

---
**Decision Points**

DP-001

Condition: A BEAN_NOT_REGISTERED exception is raised when attempting to interact with the WUH_PACKAGE bean via WebUtil_Core.setProperty or WebUtil_Core.ClearCallbackTrigger.

TRUE: WebUtil_Core.ErrorAlert is called with a message identifying the missing implementation class and stating that WEBUTIL_HOST.Release_Process will not work; the procedure exits via the exception handler without nullifying the handle.

FALSE: The procedure completes normally - the property is cleared, the callback trigger is deregistered, and process.handle is set to NULL.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The process handle passed to Release_Process must be a valid PROCESS_ID previously obtained through the WebUtil host process mechanism; the procedure does not validate the handle prior to attempting release.
- BR-002 - Upon successful release, process.handle is unconditionally set to NULL, ensuring the caller cannot reuse the handle after the procedure returns.
- BR-003 - If the WebUtil bean identified by WUH_PACKAGE is not registered in the current session, the release operation cannot proceed and an error alert must be presented to the user; no silent failure is permitted.
- BR-004 - Both the property clear (WUH_CLEAR_PROC) and the callback trigger deregistration must be performed as part of a single release operation to ensure complete cleanup of all resources associated with the process handle.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Release_Process(process in out PROCESS_ID) is  
  begin
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_CLEAR_PROC',process.handle);
    WebUtil_Core.ClearCallbackTrigger(process.handle);
    process.handle := null;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.Release_Process will not work');
  end Release_Process;
```

#### SP-049 - WEBUTIL.SETCLIENTSETTING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Transmits a named configuration property and its value to the WebUtil client-side bean by delegating to WebUtil_Core.setProperty. The procedure allows the Oracle Forms runtime to push local client settings (identified by a property name/value pair) to the WebUtil core package, enabling client-environment configuration without direct database interaction.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyName | VARCHAR2 | IN |
| propertyValue | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the property name (propertyName) and property value (propertyValue) as input parameters.
- Step 2 - Evaluate whether propertyName is not null; only a non-null property name constitutes a valid setting request.
- Step 3 - If propertyName is not null, invoke WebUtil_Core.setProperty passing the constant WebUtil_Core.WUC_PACKAGE as the target package identifier, the constant WebUtil_Core.WUC_SET_LOCAL_PROPERTY as the action identifier, and the concatenated string propertyName||'='||propertyValue as the property payload.
- Step 4 - If the WebUtil_Core bean has not been registered (exception WebUtil_Core.BEAN_NOT_REGISTERED is raised), display an error alert via WebUtil_Core.ErrorAlert identifying the missing bean class, then raise FORM_TRIGGER_FAILURE to halt form processing.
- Step 5 - If a property error occurs during the setProperty call (exception WebUtil_Core.PROPERTY_ERROR is raised), raise FORM_TRIGGER_FAILURE to halt form processing without an additional alert.

---
**Decision Points**

DP-001

Condition: propertyName IS NOT NULL

TRUE: Calls WebUtil_Core.setProperty with WUC_PACKAGE, WUC_SET_LOCAL_PROPERTY, and the concatenated propertyName||'='||propertyValue string to apply the client setting.

FALSE: The procedure exits silently without invoking WebUtil_Core.setProperty; no property is transmitted to the client bean.

---

DP-002

Condition: WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during setProperty execution

TRUE: Displays an error alert (via WebUtil_Core.ErrorAlert) stating that the WebUtil core bean was not found and that SetClientSetting will not work, then raises FORM_TRIGGER_FAILURE to abort the current form trigger.

FALSE: Execution continues normally; no error alert is issued for this condition.

---

DP-003

Condition: WebUtil_Core.PROPERTY_ERROR exception is raised during setProperty execution

TRUE: Raises FORM_TRIGGER_FAILURE immediately to abort the current form trigger; no error alert is issued.

FALSE: Execution completes normally; the property has been successfully transmitted to the client bean.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A client setting must not be transmitted if propertyName is null; the procedure silently performs no action when propertyName is null, preventing malformed property entries from reaching the WebUtil client bean.
- BR-002 - The property payload delivered to the WebUtil client bean must be formatted as a single string in the form propertyName||'='||propertyValue, ensuring the client bean can parse the name and value as a single assignment expression.
- BR-003 - If the WebUtil core bean is not registered at the time of invocation, form processing must be halted via FORM_TRIGGER_FAILURE after presenting a descriptive error alert; the procedure cannot operate without a registered WebUtil core bean.
- BR-004 - If a property error is returned by WebUtil_Core.setProperty, form processing must be halted via FORM_TRIGGER_FAILURE; no partial or erroneous property state is permitted to persist silently.

---
**Implementation Logic**

```plsql

  PROCEDURE SetClientSetting(propertyName  in VARCHAR2,
                             propertyValue in VARCHAR2) is
  BEGIN
    if propertyName is not null then 
      WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SET_LOCAL_PROPERTY', propertyName||'='||propertyValue);
    end if;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                              ||' bean not found. WEBUTIL_CORE.SetClientSetting will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;       
  END SetClientSetting;
```

#### SP-050 - WEBUTIL.SETDATA

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.SETDATA receives a single chunk of upload data (VARCHAR2) and writes it to the appropriate destination - either a database BLOB or a server-side file - as part of a multi-chunk file-transfer operation. It decrements the outstanding-chunk counter after each successful write and, when the final chunk is received, closes the destination resource, marks the upload as succeeded, fires any registered callback trigger, and clears that trigger registration.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| uploadData | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.CLEARCALLBACKTRIGGER ([SP-012](#SP-012--WEBUTIL.CLEARCALLBACKTRIGGER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.CLOSEBLOB ([SP-013](#SP-013--WEBUTIL.CLOSEBLOB)) - WEBUTIL.pck (or .pld)
- WEBUTIL.CLOSEFILE ([SP-014](#SP-014--WEBUTIL.CLOSEFILE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCALLBACKTRIGGER ([SP-021](#SP-021--WEBUTIL.GETCALLBACKTRIGGER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETLASTERROR ([SP-025](#SP-025--WEBUTIL.GETLASTERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETLASTERRORARGS ([SP-026](#SP-026--WEBUTIL.GETLASTERRORARGS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.WRITEDATA ([SP-053](#SP-053--WEBUTIL.WRITEDATA)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Validate the incoming chunk: if uploadData is NULL or empty, set the module-level flag m_uploadSucceeded to FALSE and exit; no further processing is performed.
- Step 2 - Determine the write destination using the module-level flag m_toDB.
- Step 3 (DB path) - If m_toDB is TRUE, delegate the write to WEBUTIL.WRITEDATA (WebUtil_DB_LOCAL.WriteData) to append the chunk to the in-progress BLOB.
- Step 4 (File path) - If m_toDB is FALSE, invoke JAVA_APPSERV_WRITER.WriteData to write the chunk to the server-side file. If the write fails, retrieve the error code via WEBUTIL.GETLASTERROR and the error arguments via WEBUTIL.GETLASTERRORARGS, log the error through WebUtil_core.Error, and raise the READWRITE_ERROR exception to abort processing.
- Step 5 - Decrement the module-level chunk counter m_chunks by 1.
- Step 6 - Evaluate whether all expected chunks have been received (m_chunks = 0).
- Step 7 (Final chunk, DB path) - Call WEBUTIL.CLOSEBLOB (WebUtil_DB_Local.CloseBlob) passing m_fileSize. If successful, set m_uploadSucceeded to TRUE; otherwise retrieve the last error via WEBUTIL.GETLASTERROR and log it through WebUtil_core.Error.
- Step 8 (Final chunk, File path) - Call WEBUTIL.CLOSEFILE (JAVA_APPSERV_WRITER.CloseFile) passing m_persistObj and m_fileSize. If successful, set m_uploadSucceeded to TRUE; otherwise retrieve the error code via WEBUTIL.GETLASTERROR and error arguments via WEBUTIL.GETLASTERRORARGS, log the error, release the Java global reference, and raise READWRITE_ERROR.
- Step 9 - After the destination is closed, check whether a callback trigger is registered by calling WEBUTIL.GETCALLBACKTRIGGER with argument -1. If a trigger name is returned, execute it via EXECUTE_TRIGGER.
- Step 10 - Call WEBUTIL.CLEARCALLBACKTRIGGER with argument -1 to deregister the callback trigger regardless of whether one was fired.

---
**Decision Points**

DP-001

Condition: uploadData IS NULL or uploadData = ''

TRUE: Set m_uploadSucceeded to FALSE and exit the procedure immediately; no write or chunk-count operations are performed.

FALSE: Proceed to write the chunk to the designated destination.

---

DP-002

Condition: m_toDB is TRUE

TRUE: Write the chunk to the database BLOB using WEBUTIL.WRITEDATA (WebUtil_DB_LOCAL.WriteData).

FALSE: Write the chunk to the server-side file using JAVA_APPSERV_WRITER.WriteData.

---

DP-003

Condition: JAVA_APPSERV_WRITER.WriteData returns a failure result (file-path write only)

TRUE: Retrieve error details via WEBUTIL.GETLASTERROR and WEBUTIL.GETLASTERRORARGS, log the error, and raise READWRITE_ERROR.

FALSE: Continue to decrement the chunk counter.

---

DP-004

Condition: m_chunks = 0 after decrement (all expected chunks have been received)

TRUE: Proceed to close the destination resource and finalise the upload.

FALSE: Return without closing; await further chunks.

---

DP-005

Condition: m_toDB is TRUE at final-chunk close time

TRUE: Close the BLOB via WEBUTIL.CLOSEBLOB.

FALSE: Close the file via WEBUTIL.CLOSEFILE.

---

DP-006

Condition: WEBUTIL.CLOSEBLOB (WebUtil_DB_Local.CloseBlob) succeeds (DB path, final chunk)

TRUE: Set m_uploadSucceeded to TRUE.

FALSE: Retrieve the last error via WEBUTIL.GETLASTERROR and log it; m_uploadSucceeded remains FALSE.

---

DP-007

Condition: WEBUTIL.CLOSEFILE (JAVA_APPSERV_WRITER.CloseFile) succeeds (file path, final chunk)

TRUE: Set m_uploadSucceeded to TRUE.

FALSE: Retrieve error details via WEBUTIL.GETLASTERROR and WEBUTIL.GETLASTERRORARGS, log the error, release the Java global reference, and raise READWRITE_ERROR.

---

DP-008

Condition: WEBUTIL.GETCALLBACKTRIGGER(-1) returns a non-null trigger name (final chunk only)

TRUE: Execute the registered callback trigger via EXECUTE_TRIGGER.

FALSE: Skip trigger execution; proceed directly to clearing the callback trigger registration.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A NULL or empty uploadData chunk is treated as an error condition; the upload is immediately flagged as unsuccessful and no data is written.
- BR-002 - Each call to SETDATA processes exactly one chunk; the procedure is designed to be invoked repeatedly until all chunks forming the complete file have been supplied.
- BR-003 - The write destination (database BLOB or server-side file) is determined solely by the module-level flag m_toDB, which must be set before the first chunk is submitted.
- BR-004 - Any failure during a file-path write (JAVA_APPSERV_WRITER.WriteData) is a fatal condition; the procedure logs the error using WEBUTIL.GETLASTERROR and WEBUTIL.GETLASTERRORARGS and raises READWRITE_ERROR to halt the transfer.
- BR-005 - The chunk counter m_chunks is decremented on every successful write; the upload finalisation sequence is triggered only when m_chunks reaches zero, ensuring that the destination resource is not closed prematurely.
- BR-006 - On receipt of the final chunk, the destination resource must be explicitly closed (WEBUTIL.CLOSEBLOB for the DB path; WEBUTIL.CLOSEFILE for the file path) before the upload can be declared successful.
- BR-007 - A failure to close the file-path destination (WEBUTIL.CLOSEFILE) causes the Java global reference to be released and READWRITE_ERROR to be raised, preventing a partially written file from being treated as complete.
- BR-008 - If a callback trigger has been registered (via WEBUTIL.GETCALLBACKTRIGGER returning a non-null value), it is executed immediately after the final chunk is successfully closed, enabling downstream processing to be triggered automatically.
- BR-009 - The callback trigger registration is always cleared via WEBUTIL.CLEARCALLBACKTRIGGER after final-chunk processing, regardless of whether a trigger was fired, to prevent stale registrations from affecting subsequent operations.

---
**Implementation Logic**

```plsql
   
  PROCEDURE SetData(uploadData in VARCHAR2) is 
    lastErrorCode    PLS_INTEGER;
    lastErrorArgs    VARCHAR2(1000);   
  BEGIN
    if uploadData is null or uploadData = '' then 
      -- error condition!
      m_uploadSucceeded := false;
    else
      -- Write to the correct place    
      if m_toDB then 
        WebUtil_DB_LOCAL.WriteData(uploadData);
      else
        if not JAVA_APPSERV_WRITER.WriteData(m_persistObj,uploadData) then
          lastErrorCode := JAVA_APPSERV_WRITER.getLastError(m_persistObj);
          lastErrorArgs := JAVA_APPSERV_WRITER.getLastErrorArgs(m_persistObj) ;
          WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                             'WEBUTIL_FILE_TRANSFER.SetData',lastErrorArgs);
          raise READWRITE_ERROR;
        end if;
      end if;
      m_chunks := m_chunks - 1;
      if m_chunks = 0 then 
        if m_toDB then 
          if WebUtil_DB_Local.CloseBlob(m_fileSize) then 
            m_uploadSucceeded := true;
          else
            WebUtil_core.Error(Webutil_Core.WUT_PACKAGE, WebUtil_DB_Local.getLastError,
                               'WEBUTIL_FILE_TRANSFER.SetData');
          end if; -- close
        else
          if JAVA_APPSERV_WRITER.CloseFile(m_persistObj,m_fileSize) then
            m_uploadSucceeded := true;
          else
            lastErrorCode := JAVA_APPSERV_WRITER.getLastError(m_persistObj);
            lastErrorArgs := JAVA_APPSERV_WRITER.getLastErrorArgs(m_persistObj) ;
            WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                               'WEBUTIL_FILE_TRANSFER.SetData',lastErrorArgs);
            ORA_JAVA.DELETE_GLOBAL_REF(m_persistObj);
            raise READWRITE_ERROR;
          end if;    
        end if; -- toDB

        if WebUtil_Core.GetCallbackTrigger(-1) is not null then
          EXECUTE_TRIGGER(WebUtil_Core.GetCallbackTrigger(-1));
        end if;
        WebUtil_Core.ClearCallbackTrigger(-1);
      end if; -- chunks
    end if;
  end SetData;
```

#### SP-051 - WEBUTIL.SETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sets a JVM system property at runtime by delegating to the Java native interface layer. Given a property key (a0) and a property value (a1), the function invokes java.lang.System.setProperty via JNI and returns the previous value of the property, or NULL if it was not previously set. This supports Oracle Forms WebUtil scenarios where the host JVM environment must be configured dynamically during a custom event handler execution.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |
| a1 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the property key (a0) and the new property value (a1) as VARCHAR2 input arguments.
- Step 2 - Allocate a JNI argument list sized for two arguments by calling JNI.CREATE_ARG_LIST(2), storing the handle in the module-level variable 'args'.
- Step 3 - Append the property key (a0) to the argument list as a String argument via JNI.ADD_STRING_ARG.
- Step 4 - Append the property value (a1) to the argument list as a second String argument via JNI.ADD_STRING_ARG.
- Step 5 - Invoke the static Java method java.lang.System.setProperty(String, String) through JNI.CALL_STRING_METHOD, passing the fully-qualified class name, method name, and JNI method descriptor '(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;' together with the prepared argument list.
- Step 6 - Return the VARCHAR2 result from JNI.CALL_STRING_METHOD to the caller, which represents the previous value of the named system property (NULL if the property had no prior value).

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a linear sequence of JNI calls unconditionally and returns the result directly to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Both the property key (a0) and the property value (a1) must be supplied as non-null VARCHAR2 values, consistent with the contract of java.lang.System.setProperty, which does not permit null keys or null values.
- BR-002 - The function targets the static method java.lang.System.setProperty on the JVM hosting the Oracle Forms WebUtil runtime; the property change is therefore scoped to that JVM instance and affects all components sharing the same JVM session.
- BR-003 - The return value reflects the previous value of the system property at the time of the call; callers that need to restore the original environment must capture and reapply this returned value.
- BR-004 - This function is invoked exclusively within the context of WEBUTIL_CORE.CUSTOMEVENTHANDLER; it must not be called outside that execution path, as the JNI infrastructure and argument-list variable ('args') are managed at the WebUtil core level.

---
**Implementation Logic**

```plsql
  FUNCTION setProperty(
    a0    VARCHAR2,
    a1    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(2);
    JNI.ADD_STRING_ARG(args, a0);
    JNI.ADD_STRING_ARG(args, a1);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'setProperty', '(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-052 - WEBUTIL.SHOWBEANS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.INITWEBUTIL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Controls the visibility of the hidden WebUtil window (WEBUTIL_HIDDEN_WINDOW) used to host JavaBean components. When called with show = TRUE, the procedure surfaces the window and navigates focus into it; when called with show = FALSE, it hides the window and restores focus to the previously active item. Execution is suppressed entirely when the form is in Enter Query Mode to prevent interference with query operations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| show | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-035](#SP-035--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Check whether the form is currently in NORMAL mode by evaluating SYSTEM.MODE; if the form is in any other mode (e.g., Enter Query), all subsequent steps are skipped.
- Step 2 - Locate the hidden WebUtil window by calling FIND_WINDOW with the constant WEBUTIL_HIDDEN_WINDOW and store the handle in a local variable.
- Step 3 - Validate the window handle using WEBUTIL.ID_NULL (SP-035); if the handle is null (window not found), all subsequent steps are skipped.
- Step 4 - Evaluate the incoming Boolean parameter 'show' to determine whether the window should be displayed or hidden.
- Step 5 (show = TRUE) - Capture the currently active form item by reading SYSTEM.CURSOR_ITEM via FIND_ITEM and store it in the module-level variable m_infoFrom for later restoration.
- Step 6 (show = TRUE) - Set the window title to 'WebUtil ' concatenated with the WEBUTIL_VERSION constant.
- Step 7 (show = TRUE) - Display the hidden window using SHOW_WINDOW, then move form focus to WEBUTIL_DUMMY_ITEM inside that window.
- Step 8 (show = FALSE) - Check whether m_infoFrom holds a valid item handle using WEBUTIL.ID_NULL (SP-035); if valid, navigate focus back to that item using GO_ITEM.
- Step 9 (show = FALSE) - Hide the WebUtil window using HIDE_WINDOW.

---
**Decision Points**

DP-001

Condition: SYSTEM.MODE = 'NORMAL'

TRUE: Proceed with window visibility logic.

FALSE: Exit the procedure immediately without performing any window or focus operations, preserving Enter Query Mode integrity.

---

DP-002

Condition: WEBUTIL.ID_NULL(hWin) is FALSE (i.e., the WEBUTIL_HIDDEN_WINDOW handle is valid)

TRUE: Proceed to evaluate the 'show' parameter and act on the window.

FALSE: Exit without attempting any window or focus operations, avoiding a runtime error on an invalid handle.

---

DP-003

Condition: show = TRUE

TRUE: Capture the current cursor item, set the window title, display the window, and navigate focus to WEBUTIL_DUMMY_ITEM.

FALSE: Attempt to restore focus to the previously captured item and hide the window (see DP-004).

---

DP-004

Condition: show = FALSE AND WEBUTIL.ID_NULL(m_infoFrom) is FALSE (i.e., a prior cursor item was successfully captured)

TRUE: Navigate focus back to the item stored in m_infoFrom before hiding the window.

FALSE: Skip the GO_ITEM call and proceed directly to hiding the window.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must not execute any window or focus manipulation when the form is in Enter Query Mode (SYSTEM.MODE ≠ 'NORMAL'); this prevents disruption of query operations as documented in Bug 2955789.
- BR-002 - The WebUtil hidden window must exist (non-null handle returned by FIND_WINDOW) before any show or hide action is attempted; an invalid handle causes the procedure to exit silently.
- BR-003 - When showing the WebUtil window, the currently active form item (SYSTEM.CURSOR_ITEM) must be recorded in m_infoFrom prior to transferring focus, so that focus can be accurately restored when the window is subsequently hidden.
- BR-004 - The WebUtil window title must be set to 'WebUtil ' concatenated with WEBUTIL_VERSION each time the window is displayed, ensuring the version is always visible to the user.
- BR-005 - Focus restoration on hide is conditional: GO_ITEM is called only if m_infoFrom holds a valid item handle, preventing a runtime error when no prior cursor item was captured.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ShowBeans(show BOOLEAN) is
    hWin WINDOW := FIND_WINDOW(WEBUTIL_HIDDEN_WINDOW);
  begin
    -- Bug 2955789 - don't attempt to do this when in Enter Query Mode
    if name_in('SYSTEM.MODE') = 'NORMAL' then 
      if not ID_NULL(hWin) then 
        if show then 
          m_infoFrom := FIND_ITEM(name_in('SYSTEM.CURSOR_ITEM'));
          SET_WINDOW_PROPERTY(hWin,TITLE,'WebUtil '||WEBUTIL_VERSION);
          SHOW_WINDOW(hWin);
          go_item(WEBUTIL_DUMMY_ITEM);
        else
          if not id_null(m_infoFrom) then 
              go_item(m_infoFrom);
          end if;
          HIDE_WINDOW(hWin);
        end if;
      end if;
    end if;
  end ShowBeans;
```

#### SP-053 - WEBUTIL.WRITEDATA

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a string of data to a server-side file by invoking the Java method WriteData on the AppServerFileWriter object. This procedure acts as a PL/SQL-to-Java bridge, forwarding the supplied data string to the underlying Java file-writer component so that file content can be persisted on the application server.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java object reference (obj) representing an active AppServerFileWriter instance and the data string (a0) to be written.
- Step 2 - Create a JNI argument list sized for one argument using JNI.CREATE_ARG_LIST(1).
- Step 3 - Add the data string a0 to the argument list as a String argument using JNI.ADD_STRING_ARG.
- Step 4 - Invoke the Java method WriteData on the AppServerFileWriter class via JNI.CALL_BOOLEAN_METHOD, passing the constructed argument list and targeting the method signature '(Ljava/lang/String;)Z'.
- Step 5 - Return the Boolean result produced by the Java method, indicating whether the write operation succeeded (TRUE) or failed (FALSE).

---
**Decision Points**

DP-001

Condition: The Java method WriteData on oracle/forms/webutil/fileTransfer/AppServerFileWriter returns a Boolean result.

TRUE: The write operation completed successfully; the function returns TRUE to the caller (WEBUTIL.SETDATA).

FALSE: The write operation did not complete successfully; the function returns FALSE to the caller, signalling that the data was not written to the server-side file.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The data to be written must be supplied as a VARCHAR2 string (a0); no transformation or validation of the data content is performed within this procedure before it is passed to the Java layer.
- BR-002 - A valid Java object reference (obj) pointing to an initialised AppServerFileWriter instance must be provided; the procedure does not create or validate the file-writer object itself.
- BR-003 - The success or failure of the write operation is determined solely by the return value of the underlying Java method; the procedure propagates this Boolean result directly to the invoking routine without additional error handling.
- BR-004 - This function is intended to be called from WEBUTIL.SETDATA and should not be invoked independently outside that context, as correct initialisation of the AppServerFileWriter object is the responsibility of the parent routine.

---
**Implementation Logic**

```plsql
  FUNCTION WriteData(
    obj   ORA_JAVA.JOBJECT,
    a0    VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_BOOLEAN_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileWriter', 'WriteData', '(Ljava/lang/String;)Z', args); 
  END;
```

#### SP-054 - WEBUTIL_CORE.CUSTOMEVENTHANDLER

**Invoked From:**

- sr_exch_lyl_dlr_rep_fmb.xml [Trigger: WHEN-CUSTOM-ITEM-EVENT]

---

**Screen:**

N/A

---

**Purpose**

Acts as the central dispatcher for custom item events raised by the WebUtil client-side bean. When a WHEN-CUSTOM-ITEM-EVENT trigger fires, this procedure receives the event name and its serialised parameter string, extracts the data payload and multipart chunk metadata, and routes execution to the appropriate WebUtil handler routine (logging, error reporting, bean registration, host-command callback, or file-transfer notification). Events that are not in the recognised set are silently discarded; all other unexpected exceptions are re-raised.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| EventName | VARCHAR2 | IN |
| EventParameters | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERROR ([SP-016](#SP-016--WEBUTIL.ERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETNUMBER ([SP-027](#SP-027--WEBUTIL.GETNUMBER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-041](#SP-041--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.REGISTERBEAN ([SP-046](#SP-046--WEBUTIL.REGISTERBEAN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETDATA ([SP-050](#SP-050--WEBUTIL.SETDATA)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETPROPERTY ([SP-051](#SP-051--WEBUTIL.SETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the incoming event name (EventName) and its serialised parameter string (EventParameters).
- Step 2 - Validate that EventName is one of the five recognised WebUtil events ('WUC_LOG_EVENT', 'WUC_ERROR_EVENT', 'WUC_REGISTER', 'WUH_CALLBACK_EVENT', 'WUT_TRANSFER_EVENT'). If not, raise the internal 'unhandled' exception, which is caught and silently suppressed.
- Step 3 - Extract the data payload by calling get_parameter_attr against the key 'WUC_DATA' from EventParameters, storing the result in dataPayload.
- Step 4 - Extract the multipart chunk descriptor by calling get_parameter_attr against the key 'WUC_DATA_MULTIPART', storing the result in dataMultiPart.
- Step 5 - Parse dataMultiPart using DelimStr.getNumber to derive the current chunk sequence number (chunkNumber) and the total number of chunks required to complete the payload (PayloadChunks).
- Step 6 - Route to the appropriate handler based on EventName:
  - 'WUC_LOG_EVENT': call WEBUTIL.LOG (WebUtil_Core.log) passing dataPayload with the error flag set to FALSE.
  - 'WUC_ERROR_EVENT': call WEBUTIL.LOG (WebUtil_Core.log) passing dataPayload with the error flag set to TRUE.
  - 'WUC_REGISTER': call WEBUTIL.REGISTERBEAN (registerBean) passing dataPayload to register the client bean.
  - 'WUH_CALLBACK_EVENT': convert dataPayload to a number and store in m_lastCallback; if conversion fails, call WEBUTIL.ERROR to report error code 408; if m_lastCallback is populated, execute the corresponding trigger from the m_callbacks collection; if m_lastCallback is NULL, call WEBUTIL.LOG to record a warning that no callback trigger was specified.
  - 'WUT_TRANSFER_EVENT': call WEBUTIL.SETDATA (WebUtil_File_Transfer.setData) with dataPayload to store the transferred file data, then call WEBUTIL.SETPROPERTY (WebUtil_Core.setProperty) to mark the transfer event status as 'RECEIVED'.
- Step 7 - On completion of the routed handler, the procedure exits normally. Unrecognised events are suppressed; all other exceptions propagate to the caller.

---
**Decision Points**

DP-001

Condition: EventName is one of 'WUC_LOG_EVENT', 'WUC_ERROR_EVENT', 'WUC_REGISTER', 'WUH_CALLBACK_EVENT', or 'WUT_TRANSFER_EVENT'.

TRUE: Continue processing - extract payload and multipart metadata, then route to the appropriate handler.

FALSE: Raise the internal 'unhandled' exception, which is caught and silently suppressed (no action taken, no error surfaced).

---

DP-002

Condition: EventName = 'WUC_LOG_EVENT'.

TRUE: Call WEBUTIL.LOG with dataPayload and error flag FALSE to write an informational log entry.

FALSE: Evaluate the next event-name branch.

---

DP-003

Condition: EventName = 'WUC_ERROR_EVENT'.

TRUE: Call WEBUTIL.LOG with dataPayload and error flag TRUE to write an error log entry.

FALSE: Evaluate the next event-name branch.

---

DP-004

Condition: EventName = 'WUC_REGISTER'.

TRUE: Call WEBUTIL.REGISTERBEAN with dataPayload to register the client-side bean.

FALSE: Evaluate the next event-name branch.

---

DP-005

Condition: EventName = 'WUH_CALLBACK_EVENT' and dataPayload can be converted to a valid number (TO_NUMBER succeeds).

TRUE: Store the numeric value in m_lastCallback and proceed to DP-006.

FALSE: Call WEBUTIL.ERROR to report error code 408, identifying 'WEBUTIL_CORE.CustomEventHandler' as the source; m_lastCallback remains unset.

---

DP-006

Condition: m_lastCallback IS NOT NULL (valid callback index obtained for 'WUH_CALLBACK_EVENT').

TRUE: Execute the trigger stored in m_callbacks(m_lastCallback) via EXECUTE_TRIGGER.

FALSE: Call WEBUTIL.LOG to record a warning that no callback trigger was specified for the host command.

---

DP-007

Condition: EventName = 'WUT_TRANSFER_EVENT'.

TRUE: Call WEBUTIL.SETDATA with dataPayload to persist the file-transfer data, then call WEBUTIL.SETPROPERTY to set the 'WUT_TRANSFER_EVENT' property to 'RECEIVED'.

FALSE: No further branches; procedure exits normally (event was already validated in DP-001).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only the five predefined WebUtil event names ('WUC_LOG_EVENT', 'WUC_ERROR_EVENT', 'WUC_REGISTER', 'WUH_CALLBACK_EVENT', 'WUT_TRANSFER_EVENT') are considered valid. Any other event name is silently ignored and causes no processing or error to be surfaced to the user.
- BR-002 - The data payload and multipart chunk descriptor must always be extracted from EventParameters before any event-specific routing occurs, regardless of which event is being handled.
- BR-003 - Log events ('WUC_LOG_EVENT') are recorded as informational entries, while error events ('WUC_ERROR_EVENT') are recorded with the error flag enabled; both use WEBUTIL.LOG as the single logging mechanism.
- BR-004 - For callback events ('WUH_CALLBACK_EVENT'), the payload must be a valid integer index into the m_callbacks collection. A non-numeric payload is treated as a configuration error and must be reported via WEBUTIL.ERROR with error code 408 rather than allowed to propagate as an unhandled exception.
- BR-005 - A callback event with a NULL resolved index (m_lastCallback IS NULL) must not attempt trigger execution; instead, a warning must be logged via WEBUTIL.LOG to preserve auditability of the missed callback.
- BR-006 - Upon successful receipt of a file-transfer event ('WUT_TRANSFER_EVENT'), the transfer data must be persisted via WEBUTIL.SETDATA and the event status must be explicitly marked 'RECEIVED' via WEBUTIL.SETPROPERTY before the procedure exits.
- BR-007 - Unexpected runtime exceptions (other than the internal 'unhandled' sentinel) must be re-raised and must not be suppressed, ensuring that genuine faults are visible to the calling trigger and upstream error-handling framework.

---
**Implementation Logic**

```plsql
  PROCEDURE CustomEventHandler(EventName       in VARCHAR2, 
                               EventParameters in VARCHAR2) is
    dataPayload   VARCHAR2(32767 char);   
    dataMultiPart VARCHAR2(61 char); /* should be enough! */ 
    chunkNumber   PLS_INTEGER;
    PayloadChunks PLS_INTEGER;
    dataType      PLS_INTEGER;
    unhandled     EXCEPTION;
  begin
    --Bug 2839033 - check for valid events only      
    if EventName not in ('WUC_LOG_EVENT',
                         'WUC_ERROR_EVENT', 
                         'WUC_REGISTER',
                         'WUH_CALLBACK_EVENT', 
                         'WUT_TRANSFER_EVENT') then  
      raise unhandled;
    end if;                        

    -- We're pretty much always going to need the data payload and 
    -- number of parts that make up that payload so get it now..
    get_parameter_attr(EventParameters,'WUC_DATA',dataType, dataPayload);
    get_parameter_attr(EventParameters,'WUC_DATA_MULTIPART',dataType, dataMultiPart);      
    -- split the MULTIPART info to work out how many messages from the 
    -- client are required to create the completed payload
    chunkNumber   := DelimStr.getNumber(dataMultiPart,1,true,'/');
    PayloadChunks := DelimStr.getNumber(dataMultiPart,2,true,'/');

    -- Now deal with the specific events that the client may dispatch
    -- This section will have to be extended for each new event that we 
    -- Add in order to hook the handler code for that message to the data 
    -- that is being sent - shame we can't subclass in PL/SQL :-)      
    if EventName = 'WUC_LOG_EVENT' then
        WebUtil_Core.log(dataPayload,false);
    elsif EventName = 'WUC_ERROR_EVENT' then
        WebUtil_Core.log(dataPayload,true);
    elsif EventName = 'WUC_REGISTER' then 
        registerBean(dataPayload);
    elsif EventName = 'WUH_CALLBACK_EVENT' then 
      begin 
        m_lastCallback := to_number(dataPayload);
      exception
          when INVALID_NUMBER then 
            error(WebUtil_Core.WUC_PACKAGE,408,'WEBUTIL_CORE.CustomEventHandler');
      end;
      if m_lastCallback is not null then 
          EXECUTE_TRIGGER(m_callbacks(m_lastCallback));
      else
            log('Callback trigger for host command not specified',true);
      end if;
    elsif EventName = 'WUT_TRANSFER_EVENT' then 
      WebUtil_File_Transfer.setData(dataPayload);
      WebUtil_Core.setProperty(WebUtil_Core.WUT_PACKAGE, 'WUT_TRANSFER_EVENT','RECEIVED');
    end if;
  exception
    when unhandled then
      null;
    when OTHERS then
      raise;
  end CustomEventHandler;
```

#### SP-055 - ADD_ERROR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Records a runtime error by setting a global error flag, composing a formatted error stack entry that combines the calling function name with the error text, and forwarding the composed message to the debug logging facility. This procedure provides a centralised, consistent mechanism for error capture across all routines that invoke it.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| CallingFunction | VARCHAR2 | IN |
| SetErrorText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-059](#SP-059--DEBUGLOG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Receive the name of the calling function (CallingFunction) and the descriptive error text (SetErrorText) as inputs.
- Step 2 - Set the global flag ERROR_ENCOUNTERED to TRUE to signal that an error condition has been raised.
- Step 3 - Compose the ERROR_STACK value by concatenating CallingFunction, a colon-space separator, and a truncated substring of SetErrorText limited to 1,968 characters, ensuring the stored message does not exceed the permitted length.
- Step 4 - Invoke DEBUGLOG (SP-059) via Win_API_Debug.DebugLog, passing severity level 99, the literal identifier 'Add_Error', and the composed ERROR_STACK string, so the error is written to the debug log for diagnostic purposes.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The procedure executes all steps unconditionally for every invocation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The global error flag ERROR_ENCOUNTERED must be set to TRUE whenever ADD_ERROR is called, indicating that at least one error has occurred in the current execution context.
- BR-002 - The error stack entry must be formatted as '<CallingFunction>: <ErrorText>' to preserve traceability back to the originating routine.
- BR-003 - The error text stored in ERROR_STACK must be truncated to a maximum of 1,968 characters to prevent value errors from oversized string assignments.
- BR-004 - Every error recorded by ADD_ERROR must be forwarded to DEBUGLOG (SP-059) at severity level 99, ensuring all captured errors are written to the debug log.

---
**Implementation Logic**

```plsql

PROCEDURE Add_Error (CallingFunction in VARCHAR2, SetErrorText in VARCHAR2) is
begin 
  -- Just watch for value errors 
  ERROR_ENCOUNTERED  := TRUE;
  ERROR_STACK    := CallingFunction||': '||substr(SetErrorText,1,1968);
  Win_API_Debug.DebugLog(99,'Add_Error',ERROR_STACK);
end Add_Error;
```

#### SP-056 - ADD_EXTERNAL_ERRORS

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

ADD_EXTERNAL_ERRORS is a client-side function that collects and consolidates external error messages into a single delimited string for return to the caller. It first drains the Oracle Forms tool_err error stack by iterating through all queued messages; if no tool_err entries exist, it falls back to the current SQL error message (SQLERRM). The resulting string is used to surface external or runtime errors to the invoking context.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Declare a counter variable (iCounter) and a varchar2 buffer (vcErrBuff, max 1968 characters) to accumulate error messages.
- Step 2 - Check whether the tool_err error stack contains one or more errors (tool_err.nerrors > 0).
- Step 3 - If errors exist on the stack, iterate from 1 to tool_err.nerrors; for each iteration, append a newline character (CHR(10)) followed by the current tool_err message to the buffer.
- Step 4 - Within each iteration, handle a VALUE_ERROR exception: if appending the next message would exceed the buffer capacity (1968 characters), exit the loop immediately, discarding any remaining messages.
- Step 5 - After appending each message to the buffer, call tool_err.pop to remove that message from the error stack.
- Step 6 - If the tool_err stack is empty (nerrors = 0), check whether SQLERRM is not null; if so, prepend a newline and assign the SQL error message directly to the buffer.
- Step 7 - Return the accumulated error buffer string to the caller.

---
**Decision Points**

DP-001

Condition: tool_err.nerrors > 0

TRUE: Iterate through the tool_err error stack, appending each message to the buffer and popping it from the stack. Exit the loop early if a VALUE_ERROR is raised.

FALSE: Proceed to DP-002 to evaluate SQLERRM.

---

DP-002

Condition: SQLERRM is not null (evaluated only when tool_err.nerrors = 0)

TRUE: Assign a newline-prefixed SQLERRM value to the error buffer.

FALSE: The buffer remains empty; the function returns a null or empty string.

---

DP-003

Condition: VALUE_ERROR exception raised during string concatenation inside the loop

TRUE: Exit the loop immediately; messages that would exceed the 1968-character buffer limit are discarded.

FALSE: Continue appending messages and popping entries from the tool_err stack.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The error message buffer must not exceed 1968 characters; any tool_err messages that would cause the buffer to overflow are silently discarded and loop processing stops.
- BR-002 - The tool_err stack takes precedence over SQLERRM: the fallback to SQLERRM is only applied when no tool_err errors are present (tool_err.nerrors = 0).
- BR-003 - Each error message appended to the buffer must be preceded by a newline character (CHR(10)) to ensure messages are separated when the buffer is consumed by the caller.
- BR-004 - Each tool_err message must be popped from the stack (tool_err.pop) after it is appended to the buffer, ensuring the stack is cleared as messages are consumed.

---
**Implementation Logic**

```plsql

FUNCTION Add_External_Errors return varchar2 is
  iCounter   pls_integer;
  vcErrBuff  varchar2(1968);
begin 
  if tool_err.nerrors > 0 then 
    for iCounter in 1..tool_err.nerrors LOOP
      begin 
        vcErrBuff := vcErrBuff||chr(10)||tool_err.message;
      exception
        when VALUE_ERROR then 
          exit; /* String exceeds allowable buffer */
      end;
      tool_err.pop;
    end loop;
  elsif SQLERRM is not null then 
    vcErrBuff := chr(10)||SQLERRM; 
  end if;
  return vcErrBuff;
end Add_External_Errors;
```

#### SP-057 - BOOLTOCHAR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

BOOLTOCHAR is a utility function that converts a PL/SQL BOOLEAN value into its VARCHAR2 string equivalent ('TRUE' or 'FALSE'). It is used by other stored procedures within D2kwutil.pld - specifically GET_ENVIRONMENT_STRING and READ_REGISTRY - where a boolean result must be represented as a character string for further processing or output.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| ThisBoolean | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input BOOLEAN value (ThisBoolean) passed by the calling procedure.
- Step 2 - Evaluate the BOOLEAN value using a conditional check.
- Step 3 - If the value evaluates to TRUE, return the VARCHAR2 literal 'TRUE' to the caller.
- Step 4 - If the value evaluates to FALSE (or NULL resolving to the ELSE branch), return the VARCHAR2 literal 'FALSE' to the caller.

---
**Decision Points**

DP-001

Condition: ThisBoolean evaluates to TRUE.

TRUE: The function returns the VARCHAR2 string 'TRUE'.

FALSE: The function returns the VARCHAR2 string 'FALSE'.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must always return a non-null VARCHAR2 string; the only permitted return values are 'TRUE' and 'FALSE'.
- BR-002 - The conversion is one-directional: the input must be a PL/SQL BOOLEAN; no other data type is accepted.
- BR-003 - Any input that does not satisfy the TRUE condition (including a BOOLEAN NULL) is treated as FALSE and returns the string 'FALSE'.

---
**Implementation Logic**

```plsql

  
  FUNCTION  BoolToChar(ThisBoolean IN BOOLEAN) return VARCHAR2 is
  begin
  	if ThisBoolean then 
  		RETURN 'TRUE';
  	else
  	    RETURN 'FALSE';
  	end if;
  end BoolToChar;

END;

PACKAGE WIN_API_DIALOG IS

/*-------------------------------------------------------------------------*\
 * WIN_API_DIALOG ->   This package is concerned with Displaying Common
 *      dialogs
 * Contents:
 *    Open_File    -> Open File Dialog
 *    Save_File    -> Save File Dialog
 *    Select_Printer    -> Printer Selection Dialog
 *    Choose_Font       -> Display the Font Selection Dialog
 *    Choose_Color      -> Display the Color Selection Dialog
 * Dependancies:
 *    WIN_API_ENVIRONMENT
 *    WIN_API
 *    WIN_API_DEBUG
\*-------------------------------------------------------------------------*/ 

/*-------------------------------------------------------------------------*\
 * Open_File        -> Displays the standard Open File dialog
 * Arguments: 
 *  Title           -> The Title for the Dialog Box
 *                     (Default -> 'Open File')
 *  StartDirectory  -> Where the dialog should start from
 *                     this should be in the format 'C:\TEMP'
 *                     (Default -> Windows Directory)
 *  FileFilter      ->  Restrict the list of files. The filter string 
 *                      should be in the format:
 *                      '<Description>|<filename>.<Extension>|'
 *                      typically this would be something like
 *                      'All files(*.*)|*.*|' or 'Text files(*.txt)|*.txt|'
 *                      "All Files" is the Default
 *  Modal           ->  Should the dialog be modal with respect to the 
 *                      application? 
 *                      default = TRUE
 *  AdvancedFlags   ->  (See list in WIN_API header) This option allows
 *                      you to change the attributes of the Open File 
 *                      dialog.  Here are some of the Flags that might
 *                      be of interest:
 *                      OFN_HIDEREADONLY  Hides the Read Only check box.
 *                      OFN_NONETWORKBUTTON  Hides the Network Button
 *                      OFN_EXPLORER    Display an Explorer style 
 *                        Dialog rather than the conventional one.
 *                      See your Microsoft docmentation for details on 
 *                      each flag.
 *                      To Set the Advanced_Flags varaible, just add the 
 *                      required flags together.  The default is:
 *                      WIN_API.OFN_PATHMUSTEXIST + WIN_API.OFN_FILEMUSTEXIST +
 *                      WIN_API.OFN_HIDEREADONLY + WIN_API.OFN_NOCHANGEDIR 
 *  RaiseExceptions ->  TRUE of FALSE(Default) If set to true, then if the 
 *                      command is not successful (e.g no filename is  
 *                      returned) then the explicit exception
 *                      NO_DATA_FOUND will be raised.
 *        
 * Returns:
 *  Path and name of the selected file
\*-------------------------------------------------------------------------*/
```

#### SP-058 - CLEAN_ERROR_STACK

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Resets the shared error-tracking state by clearing the error-encountered flag and nullifying the error stack. This procedure is called by GET_ENVIRONMENT_STRING and READ_REGISTRY before they begin processing, ensuring that any error indicators left over from a previous invocation do not affect the current operation.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Set the package-level boolean variable ERROR_ENCOUNTERED to FALSE, indicating that no error has been encountered in the current processing context.
- Step 2 - Set the package-level variable ERROR_STACK to NULL, removing any error messages accumulated during a prior invocation.

---
**Decision Points**

No decision points exist in this procedure. The reset of ERROR_ENCOUNTERED and ERROR_STACK is performed unconditionally on every invocation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - ERROR_ENCOUNTERED must be set to FALSE on each call, ensuring that stale error state from a previous execution does not propagate into a new operation.
- BR-002 - ERROR_STACK must be nullified on each call, ensuring that error messages from a previous execution are fully cleared before new processing begins.
- BR-003 - The procedure accepts no input and produces no output; its sole effect is the unconditional reset of the two shared error-state variables.

---
**Implementation Logic**

```plsql

PROCEDURE Clean_Error_Stack is 
begin 
  -- just empty the variables
  ERROR_ENCOUNTERED  := FALSE;
  ERROR_STACK        := NULL;
end Clean_Error_Stack;
```

#### SP-059 - DEBUGLOG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: ADD_ERROR]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: SETDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

DEBUGLOG writes a formatted diagnostic message to the active debug output channel (Windows debug monitor or flat file) when the current debug state is active, not paused, and the supplied debug level falls within the configured threshold. It is a shared utility called by multiple D2kwutil procedures to record runtime diagnostic information without interrupting normal form processing.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugLevel | PLS_INTEGER | IN |
| LoggingCall | VARCHAR2 | IN |
| LogString | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- SETDEBUG ([SP-063](#SP-063--SETDEBUG)) - matched by member name
- WEBUTIL.LENGTH ([SP-040](#SP-040--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)
- WINDEBUG ([SP-066](#SP-066--WINDEBUG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate guard conditions: if the global debug state (iDebugState) is 0 (disabled), or if debugging is paused (bDebugPaused is TRUE), or if the supplied DebugLevel exceeds the configured threshold (iDebugLevel), exit immediately without writing any output.
- Step 2 - Optionally prepend a timestamp: if the global flag bDebugTimeStamp is TRUE, format the current system time as HH24:MI:SS followed by '> ' and store it in vcDateStamp.
- Step 3 - Construct the formatted debug string: combine the DebugLevel (left-padded to 2 digits), the optional timestamp, the LoggingCall name (right-padded to 30 characters), and the LogString. Truncate the combined string so the total length does not exceed 2,000 characters.
- Step 4 - Determine the output channel based on iDebugState:
  - If iDebugState = 2 (Windows debug monitor mode): check whether DEBUG_API_ENABLED is TRUE.
    - If TRUE, call WINDEBUG (win_api_debug.WinDebug) to write vcDebugString to the Windows debug monitor.
    - If FALSE (API unavailable), call SETDEBUG to switch the debug channel to file logging (defaulting to 'd2kwutil.log'), log a warning message via recursive DEBUGLOG calls, and set the flag bDebugType2Required to TRUE to record that a fallback occurred.
  - If iDebugState is not 2 (file logging mode): check whether bDebugType2Required is TRUE and DEBUG_API_ENABLED is now TRUE.
    - If both conditions are met, the Windows debug API has become available again; call SETDEBUG to reinstate monitor-based logging, log a restoration message via recursive DEBUGLOG calls, reset bDebugType2Required to FALSE, and re-emit the original message.
    - Otherwise, open the target log file (vcDebugFile) in append mode using TEXT_IO, write vcDebugString, and close the file.
- Step 5 - On any unhandled exception, set iDebugState to 0 to disable debugging silently, preventing diagnostic code from causing errors in the host form.

---
**Decision Points**

DP-001

Condition: iDebugState = 0

TRUE: Procedure exits immediately; no logging is performed.

FALSE: Proceed to DP-002.

---

DP-002

Condition: bDebugPaused is TRUE

TRUE: Procedure exits immediately; no logging is performed.

FALSE: Proceed to DP-003.

---

DP-003

Condition: DebugLevel > iDebugLevel (supplied level exceeds configured threshold)

TRUE: Procedure exits immediately; message is below the verbosity threshold and is suppressed.

FALSE: Logging proceeds; timestamp and debug string are constructed.

---

DP-004

Condition: bDebugTimeStamp is TRUE

TRUE: Current system time (HH24:MI:SS) is prepended to the debug string.

FALSE: No timestamp is included in the debug string.

---

DP-005

Condition: iDebugState = 2 (Windows debug monitor mode is configured)

TRUE: Attempt to write to the Windows debug monitor; proceed to DP-006.

FALSE: Attempt to write to a log file; proceed to DP-007.

---

DP-006

Condition: DEBUG_API_ENABLED is TRUE (Windows debug API is available)

TRUE: Call WINDEBUG (win_api_debug.WinDebug) to write the message to the Windows debug monitor.

FALSE: Call SETDEBUG to fall back to file logging, emit a warning via recursive DEBUGLOG calls, re-emit the original message, and set bDebugType2Required to TRUE.

---

DP-007

Condition: bDebugType2Required is TRUE AND DEBUG_API_ENABLED is TRUE (fallback was active but API is now available)

TRUE: Call SETDEBUG to reinstate Windows monitor logging, emit a restoration message via recursive DEBUGLOG calls, reset bDebugType2Required to FALSE, and re-emit the original message.

FALSE: Open vcDebugFile in append mode, write the formatted debug string using TEXT_IO, and close the file.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Logging is suppressed entirely when the global debug state (iDebugState) equals 0, ensuring zero overhead when debugging is disabled.
- BR-002 - Logging is suppressed when debugging is paused (bDebugPaused = TRUE), allowing temporary suspension without disabling the debug configuration.
- BR-003 - A message is only written if its DebugLevel does not exceed the configured threshold (iDebugLevel), enforcing verbosity filtering.
- BR-004 - The fully constructed debug string must not exceed 2,000 characters; LogString is truncated to enforce this limit.
- BR-005 - When Windows monitor logging is configured (iDebugState = 2) but the debug API is unavailable (DEBUG_API_ENABLED = FALSE), the procedure automatically falls back to file logging via SETDEBUG rather than failing silently or raising an error.
- BR-006 - When file logging is active as a fallback (bDebugType2Required = TRUE) and the Windows debug API subsequently becomes available (DEBUG_API_ENABLED = TRUE), the procedure automatically reinstates monitor-based logging via SETDEBUG without manual intervention.
- BR-007 - Any unhandled exception within DEBUGLOG must not propagate to the calling form; the exception handler sets iDebugState to 0 to disable further debug attempts and absorbs the error.

---
**Implementation Logic**

```plsql
   
PROCEDURE DebugLog (DebugLevel  IN PLS_INTEGER, 
                    LoggingCall IN VARCHAR2, 
                    LogString   IN VARCHAR2) is
 vcDateStamp   VARCHAR2(10);
 vcDebugString VARCHAR2(2000);
 hFile         TEXT_IO.FILE_TYPE;
begin
  if iDebugState = 0 then 
  	NULL;
  elsif bDebugPaused then 
  	NULL;
  elsif DebugLevel > iDebugLevel then 
  	NULL;
  else
  	-- Sort out the Datestamp	
  	if bDebugTimeStamp then 
  		vcDateStamp := to_char(SYSDATE,'HH24:MI:SS')||'> ';
  	end if;
  
  	-- Construct the final String
  	vcDebugString := '<'||lpad(to_char(DebugLevel),2,0)||'> '||vcDateStamp||rpad(LoggingCall||':',30);
    vcDebugString := vcDebugString||substr(LogString,1,(2000-length(vcDebugString)));
  
  	if iDebugState = 2 then
  		if DEBUG_API_ENABLED then 
  	   		win_api_debug.WinDebug(vcDebugString);
  		else
  			-- Can't use API calls if the API functions aren't there
	  		-- So Switch to File Logging to d2kwut$.log
	  		SetDebug(1,nvl(vcDebugFile,'d2kwutil.log'),iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Unable to Log to Debugger Switching to File');
			DebugLog(DebugLevel,LoggingCall,LogString);	  		
	  		bDebugType2Required := TRUE;
	  	end if;
  	else
     	if bDebugType2Required and DEBUG_API_ENABLED then
	     	-- API now Available - Reinstate Debugging to Debugger
	  		SetDebug(2,vcDebugFile,iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Restoring Logging to Debugger');
	  		bDebugType2Required := FALSE;
	  		DebugLog(Debuglevel,LoggingCall,LogString);
	
	  	else
		 	hFile := TEXT_IO.FOPEN(vcDebugFile,'A');
		 	TEXT_IO.PUT_LINE(hFile,vcDebugString);
		 	TEXT_IO.FCLOSE(hFile);
		end if;
  	end if;
  end if;
 exception
  	-- Don't let the debugging cause Problems of it's own
  	when others then 
  		iDebugState := 0;
 end DebugLog;
```

#### SP-060 - GET_ENVIRONMENT_STRING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value of a named operating-system environment variable by delegating to the D2KWUTIL native library call D2KWUTIL_GETDOSENV. The function returns the resolved variable value as a VARCHAR2 string, or NULL (optionally raising an exception) when the variable cannot be resolved. It is invoked by WEBUTIL.GETVAR to surface environment variable values within the Oracle Forms runtime.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VariableName | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-055](#SP-055--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-056](#SP-056--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-057](#SP-057--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-058](#SP-058--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_GETDOSENV ([SP-004](#SP-004--D2KWUTIL.D2KWUTIL_GETDOSENV)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-059](#SP-059--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-062](#SP-062--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log entry diagnostics by calling DEBUGLOG (Win_api_debug.DebugLog) at verbosity level 99, recording the input VariableName and the Boolean RaiseExceptions flag (converted to a character representation via BOOLTOCHAR).
- Step 2 - Clear any previously accumulated error state by calling CLEAN_ERROR_STACK (WIN_API.Clean_Error_Stack) and initialise the return-code variable iRC to 0.
- Step 3 - Check whether the WIN_API subsystem is available (WIN_API.API_ENABLED). If it is not available, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 4 - Register the external function handle for D2KWUTIL_GETDOSENV via REGISTER_FUNCTION_CALL, specifying the function name, return type (LONG), and parameter signature ('*CHAR,*CHAR,LONG').
- Step 5 - Prepare the call buffers: wrap VariableName in percent signs to form the OS-style variable reference (e.g. %VAR_NAME%), initialise a 512-character output buffer padded with null characters, and set the buffer length to 512.
- Step 6 - Invoke D2KWUTIL.D2KWUTIL_GETDOSENV with the registered function handle, the formatted variable name, the output buffer, and the buffer length. Capture the integer return code (iRC) and the populated output buffer (vcBuff2).
- Step 7 - Log the result diagnostics via DEBUGLOG, recording the returned value length (iRC) and the resolved value string.
- Step 8 - Evaluate the outcome: if iRC equals 0 or the output buffer still equals the formatted input (indicating the variable was not expanded), record an error via ADD_ERROR and either raise NO_DATA_FOUND (when RaiseExceptions is TRUE) or return NULL (when RaiseExceptions is FALSE).
- Step 9 - If the call succeeded, return the resolved environment variable value (vcBuff2) to the caller.
- Step 10 - In the exception block: re-raise NO_DATA_FOUND as-is; for WIN_API.NOT_AVAILABLE, log an error via ADD_ERROR using WIN_API.NoAPI and re-raise; for all other exceptions, log an error via ADD_ERROR concatenating WIN_API.UError with any external error details from ADD_EXTERNAL_ERRORS, then re-raise.

---
**Decision Points**

DP-001

Condition: WIN_API.API_ENABLED is TRUE.

TRUE: Proceed to register the external function and invoke D2KWUTIL_GETDOSENV to resolve the environment variable.

FALSE: Raise WIN_API.NOT_AVAILABLE, bypassing all resolution logic.

---

DP-002

Condition: iRC equals 0 OR the output buffer (vcBuff2) equals the formatted input string (vcBuff1), indicating the environment variable could not be resolved.

TRUE: Log an error via ADD_ERROR; then evaluate DP-003 to determine whether to raise an exception or return NULL.

FALSE: Return the resolved environment variable value (vcBuff2) to the caller.

---

DP-003

Condition: RaiseExceptions input parameter is TRUE (evaluated only when DP-002 is TRUE).

TRUE: Raise the NO_DATA_FOUND exception.

FALSE: Return NULL to the caller.

---

DP-004

Condition: An exception is raised during execution - evaluated in the exception block.

NO_DATA_FOUND: Re-raise without additional logging (already handled before the raise in DP-003).

WIN_API.NOT_AVAILABLE: Log an error via ADD_ERROR using WIN_API.NoAPI, then re-raise.

OTHERS: Log an error via ADD_ERROR concatenating WIN_API.UError with ADD_EXTERNAL_ERRORS output, then re-raise.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The WIN_API subsystem must be enabled (WIN_API.API_ENABLED = TRUE) before any attempt is made to resolve an environment variable; if the subsystem is unavailable the function must not proceed and must raise WIN_API.NOT_AVAILABLE.
- BR-002 - The environment variable name must be wrapped in percent signs (e.g. %VariableName%) when passed to D2KWUTIL_GETDOSENV to conform to the OS variable-expansion syntax expected by the native library.
- BR-003 - A return code of 0 from D2KWUTIL_GETDOSENV, or an output buffer that remains equal to the formatted input string, constitutes a failed resolution and must be treated as an error condition.
- BR-004 - When variable resolution fails and RaiseExceptions is TRUE, the function must raise NO_DATA_FOUND to allow the caller to handle the missing variable programmatically.
- BR-005 - When variable resolution fails and RaiseExceptions is FALSE (the default), the function must return NULL rather than raising an exception, providing a non-disruptive fallback for callers that do not require strict resolution.
- BR-006 - All errors, including resolution failures and unexpected exceptions, must be recorded via ADD_ERROR before the function raises or returns, ensuring the error stack is populated for upstream diagnostic use.
- BR-007 - Unexpected exceptions must include external error detail obtained from ADD_EXTERNAL_ERRORS concatenated with WIN_API.UError, providing a complete diagnostic message on the error stack.
- BR-008 - Entry and exit diagnostics must be written via DEBUGLOG at verbosity level 99 for every invocation, capturing input arguments (including the Boolean flag rendered via BOOLTOCHAR) and the resolved value length and content.

---
**Implementation Logic**

```plsql

FUNCTION Get_Environment_string (  VariableName      IN  VARCHAR2,
                                   RaiseExceptions   IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  vcBuff2    VARCHAR2(512);
  iBuff1    PLS_INTEGER;
  iRC        PLS_INTEGER;
begin 
  Win_api_debug.DebugLog(99,'Get_Environment_String','Args: VariableName="'||VariableName||'", RaiseExceptions='||win_api_debug.BoolToChar(RaiseExceptions));
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then
    win_api.Register_function_call(iGetDOSEnv,'d2kwutil_GetDOSEnv','LONG','*CHAR,*CHAR,LONG');
    vcBuff1    := '%'||VariableName||'%';
    vcBuff2    := RPAD(' ',512,CHR(0));
    iBuff1    := 512;
    iRC   := d2kwutil_GetDOSEnv(win_api.FunctionHandle(iGetDOSEnv),vcBuff1,vcBuff2,iBuff1);
    Win_api_debug.DebugLog(99,'Get_Environment_String','Result: Value Length='||to_char(iRC)||', Value='||vcBuff2);
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0  or vcBuff2 = vcBuff1 then 
    Win_API.Add_error('Get_Environment_String','Unable to get the value of the variable '||VariableName);
    if RaiseExceptions then
      raise NO_DATA_FOUND;
    else
      return NULL;
    end if;
  else
    return vcBuff2;
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Environment_String',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Environment_String',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Environment_String;
```

#### SP-061 - READ_REGISTRY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

READ_REGISTRY retrieves a named value from the Windows registry for a given registry path and entry key. It is invoked by WEBUTIL.GETVAR to resolve runtime configuration or environment values stored in the Windows registry. The function maps the supplied registry root string to the corresponding numeric constant, delegates the actual registry read to the D2KWUTIL.D2KWUTIL_GETREGKEY external utility, interprets the return code, and returns the retrieved string value to the caller. Error recording and optional exception propagation are controlled by the RaiseExceptions flag.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RegPath | VARCHAR2 | IN |
| RegEntry | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-055](#SP-055--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-056](#SP-056--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-057](#SP-057--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-058](#SP-058--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_GETREGKEY ([SP-005](#SP-005--D2KWUTIL.D2KWUTIL_GETREGKEY)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-059](#SP-059--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-062](#SP-062--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log entry diagnostics: call DEBUGLOG (severity 99) recording the RegPath, RegEntry, and the string representation of RaiseExceptions (via BOOLTOCHAR) so that the call can be traced.
- Step 2 - Reset the error stack: call CLEAN_ERROR_STACK to clear any previously accumulated errors before processing begins.
- Step 3 - Check API availability: evaluate WIN_API.API_ENABLED. If the Windows API layer is not available, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 4 - Register the external function handle: call REGISTER_FUNCTION_CALL to bind the iGetRegKey handle to the D2KWUTIL_GETREGKEY external function signature ('INT','INT,*CHAR,*CHAR,*CHAR,INT,INT'), making it callable.
- Step 5 - Resolve the registry root constant: extract the root hive name from RegPath (the segment before the first backslash), convert it to upper case, and map it to its numeric constant (HKEY_LOCAL_MACHINE=0, HKEY_CLASSES_ROOT=1, HKEY_CURRENT_USER=2, HKEY_USERS=3, HKEY_CURRENT_CONFIG=4). If the root is unrecognised, record an error via ADD_ERROR and, if RaiseExceptions is TRUE, raise NO_DATA_FOUND.
- Step 6 - Prepare call buffers: set the value buffer length (iBuff2) to 2000 bytes; extract the sub-path after the first backslash into vcBuff1; assign the entry name (RegEntry) to vcBuff2; initialise the result buffer vcBuff3 to a 2000-character null-padded string.
- Step 7 - Apply compatibility flag: if WIN_API.COMPAT_EXPAND_REG_VALUES is FALSE, set iBuff3 to 1 to suppress environment-variable expansion in registry values and log a compatibility diagnostic via DEBUGLOG; otherwise set iBuff3 to 0 to allow expansion.
- Step 8 - Invoke the external registry read: call D2KWUTIL.D2KWUTIL_GETREGKEY with the prepared handle, root constant, sub-path, entry name, result buffer, buffer length, and expansion flag. Capture the integer return code in iRC.
- Step 9 - Log the result: call DEBUGLOG (severity 99) recording iRC and the content of vcBuff3.
- Step 10 - Interpret the return code and handle errors:
  - iRC = -1: the registry entry could not be read; record an error via ADD_ERROR, return NULL if RaiseExceptions is FALSE, otherwise raise NO_DATA_FOUND.
  - iRC = -2: the registry value is of an unsupported data type; record an error via ADD_ERROR, return NULL if RaiseExceptions is FALSE, otherwise raise NO_DATA_FOUND.
  - iRC = -3: the registry value exceeds the 2000-byte buffer; record an error via ADD_ERROR, return NULL if RaiseExceptions is FALSE, otherwise raise VALUE_ERROR.
  - iRC = -4: environment-string expansion failed; record an error via ADD_ERROR, return NULL if RaiseExceptions is FALSE, otherwise raise NO_DATA_FOUND.
- Step 11 - Return the value: if iRC is not a recognised error code, return vcBuff3 (the retrieved registry value string) to the caller.
- Step 12 - Exception handling: NO_DATA_FOUND and VALUE_ERROR are re-raised as-is. WIN_API.NOT_AVAILABLE records a no-API error via ADD_ERROR and re-raises. All other exceptions record an unexpected-error message combining WIN_API.UError and ADD_EXTERNAL_ERRORS output via ADD_ERROR and re-raise.

---
**Decision Points**

DP-001
Condition: WIN_API.API_ENABLED is TRUE.
TRUE: Processing continues; the external registry function is registered and the read is attempted.
FALSE: WIN_API.NOT_AVAILABLE is raised immediately; no registry access is performed.

DP-002
Condition: The extracted registry root string matches one of the five recognised hive names (HKEY_LOCAL_MACHINE, HKEY_CLASSES_ROOT, HKEY_CURRENT_USER, HKEY_USERS, HKEY_CURRENT_CONFIG).
TRUE: The corresponding numeric constant (0-4) is assigned to iBuff1 and processing continues.
FALSE: ADD_ERROR is called with an 'Invalid Registry Key' message; if RaiseExceptions is TRUE, NO_DATA_FOUND is raised; otherwise processing continues with an undefined iBuff1.

DP-003
Condition: WIN_API.COMPAT_EXPAND_REG_VALUES is FALSE.
TRUE: iBuff3 is set to 1, suppressing environment-variable expansion in the registry value; a compatibility diagnostic is written via DEBUGLOG.
FALSE: iBuff3 is set to 0, allowing environment-variable expansion.

DP-004
Condition: iRC returned by D2KWUTIL.D2KWUTIL_GETREGKEY equals -1 (entry not found).
TRUE: ADD_ERROR is called; if RaiseExceptions is FALSE, NULL is returned; if TRUE, NO_DATA_FOUND is raised.
FALSE: Evaluation continues to the next return-code check.

DP-005
Condition: iRC equals -2 (unsupported data type).
TRUE: ADD_ERROR is called; if RaiseExceptions is FALSE, NULL is returned; if TRUE, NO_DATA_FOUND is raised.
FALSE: Evaluation continues to the next return-code check.

DP-006
Condition: iRC equals -3 (value exceeds 2000-byte buffer).
TRUE: ADD_ERROR is called; if RaiseExceptions is FALSE, NULL is returned; if TRUE, VALUE_ERROR is raised.
FALSE: Evaluation continues to the next return-code check.

DP-007
Condition: iRC equals -4 (environment-string expansion failed).
TRUE: ADD_ERROR is called; if RaiseExceptions is FALSE, NULL is returned; if TRUE, NO_DATA_FOUND is raised.
FALSE: No error condition applies; vcBuff3 is returned to the caller.

DP-008
Condition: RaiseExceptions is TRUE (evaluated within each error-code branch, DP-002 through DP-007).
TRUE: The appropriate Oracle exception (NO_DATA_FOUND or VALUE_ERROR) is raised, propagating the error to the caller.
FALSE: NULL is returned silently, allowing the caller to continue without an unhandled exception.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The Windows API layer must be active (WIN_API.API_ENABLED = TRUE) before any registry access is attempted; if it is not active, the function raises WIN_API.NOT_AVAILABLE and records a no-API error via ADD_ERROR.
- BR-002 - The registry root hive must be one of exactly five recognised values: HKEY_LOCAL_MACHINE, HKEY_CLASSES_ROOT, HKEY_CURRENT_USER, HKEY_USERS, or HKEY_CURRENT_CONFIG. Any other root value is treated as an invalid registry key and an error is recorded.
- BR-003 - The result buffer for the registry value is fixed at 2000 bytes. Registry values longer than this limit produce return code -3 and are treated as an error; the caller receives NULL or a VALUE_ERROR exception depending on RaiseExceptions.
- BR-004 - Environment-variable expansion within registry values is controlled by the WIN_API.COMPAT_EXPAND_REG_VALUES flag. When FALSE, expansion is suppressed (iBuff3=1) for compatibility purposes; when TRUE, expansion is permitted (iBuff3=0).
- BR-005 - The RaiseExceptions parameter governs error propagation behaviour uniformly across all error conditions: when FALSE the function returns NULL on any read failure, allowing silent degradation; when TRUE the function raises an Oracle exception (NO_DATA_FOUND or VALUE_ERROR) so the caller can handle the failure explicitly.
- BR-006 - All errors, including invalid root, read failures, unsupported data types, buffer overflows, expansion failures, API unavailability, and unexpected exceptions, must be recorded via ADD_ERROR before the function returns or raises, ensuring the error stack is populated for upstream diagnostics.
- BR-007 - Unexpected exceptions are enriched with external error details retrieved via ADD_EXTERNAL_ERRORS before being recorded and re-raised, ensuring that lower-level platform error information is captured in the error stack.
- BR-008 - The error stack is reset via CLEAN_ERROR_STACK at the start of every invocation, ensuring that errors from prior calls do not contaminate the results of the current registry read.

---
**Implementation Logic**

```plsql

FUNCTION Read_Registry (RegPath         IN  VARCHAR2,
                        RegEntry        IN  VARCHAR2, 
                        RaiseExceptions IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  vcBuff2    VARCHAR2(512);
  vcBuff3    VARCHAR2(2000);
  vcBuff4    VARCHAR2(512);
  vcBuff5    VARCHAR2(512);                        
  vcRoot     VARCHAR2(20);
  iBuff1     PLS_INTEGER;
  iBuff2     PLS_INTEGER;
  iBuff3		 PLS_INTEGER;
  iRC        PLS_INTEGER;
begin
  Win_API_Debug.DebugLog(99,'Read_Registry','Args: RegPath="'||RegPath||'", RegEntry="'||RegEntry||'", RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	  
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then 
    win_api.Register_function_call(iGetRegKey,'d2kwutil_GetRegKey','INT','INT,*CHAR,*CHAR,*CHAR,INT,INT');  
    -- Which Root?
    vcRoot  := upper(substr(RegPath,1,instr(RegPath,'\')-1));
    if      vcRoot =  'HKEY_LOCAL_MACHINE' then 
      iBuff1 := 0;
    elsif   vcRoot =  'HKEY_CLASSES_ROOT' then 
      iBuff1 := 1;
    elsif   vcRoot =  'HKEY_CURRENT_USER' then 
      iBuff1 := 2;
    elsif   vcRoot =  'HKEY_USERS' then
      iBuff1 := 3;
    elsif   vcRoot =  'HKEY_CURRENT_CONFIG' then
      iBuff1 := 4;      
    else
      WIN_API.Add_error('Read_Registry','Invalid Registry Key '||RegPath);
      if  RaiseExceptions then
        raise NO_DATA_FOUND;
      end if;  
    end if;

    iBuff2     := 2000; /* Length of buffer */
    vcBuff1    := substr(RegPath,instr(RegPath,'\')+1);
    vcBuff2    := RegEntry;
    vcBuff3    := RPAD(SUBSTR(NVL(vcBuff3,' '),1,2000),2000,CHR(0));
    if not WIN_API.COMPAT_EXPAND_REG_VALUES then 
    	iBuff3 := 1;
    	Win_API_Debug.DebugLog(99,'Read_Registry','Compatibility: Reg Value expansion supressed');	  
    else
    	iBuff3 := 0;
    end if;
    
    iRC        := d2kwutil_GetRegKey(win_api.FunctionHandle(iGetRegKey),iBuff1,vcBuff1,vcBuff2,vcBuff3,iBuff2,iBuff3);
    Win_API_Debug.DebugLog(99,'Read_Registry','Result:  RC='||to_char(iRC)||', vcBuff3="'||vcBuff3||'"');	      
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = -1  then 
    Win_API.Add_error('Read_Registry','Cannot read  entry '||RegPath||'->'||RegEntry);
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;
  elsif iRC = -2 then
    Win_API.Add_error('Read_Registry', RegPath||'->'||RegEntry||' is an unsupported datatype');
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;
  elsif iRC = -3 then
    Win_API.Add_error('Read_Registry',RegPath||'->'||RegEntry||' is longer than '||to_char(iBuff2)||' Bytes');
    if not RaiseExceptions then
      return NULL;
    else 
      raise VALUE_ERROR;
    end if;
  elsif iRC = -4 then
    Win_API.Add_error('Read_Registry', RegPath||'->'||RegEntry||' Failed to expand environment string');
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;    
  end if;
  return vcBuff3;
exception
  when NO_DATA_FOUND then 
    raise;
  when VALUE_ERROR then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Read_Registry',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Read_Registry',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Read_Registry;
```

#### SP-062 - REGISTER_FUNCTION_CALL

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Ensures that a named DLL function is registered with the Oracle FFI layer before it is called. The procedure verifies that the target DLL is loaded, registers the function handle and its parameter types (via TranslateType) if the function has not yet been registered or if the DLL has been reloaded since the last registration, and records the current DLL load count to prevent unnecessary re-registration on subsequent calls.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| FunctionID | PLS_INTEGER | IN |
| FunctionName | VARCHAR2 | IN |
| FunctionReturn | VARCHAR2 | IN |
| FunctionArgs | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-055](#SP-055--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-056](#SP-056--ADD_EXTERNAL_ERRORS)) - matched by member name
- D2KWUTIL.ATTEMPT_DLL_LOAD ([SP-002](#SP-002--D2KWUTIL.ATTEMPT_DLL_LOAD)) - D2KWUTIL.pck (or .pld)
- D2KWUTIL.TRANSLATETYPE ([SP-006](#SP-006--D2KWUTIL.TRANSLATETYPE)) - D2KWUTIL.pck (or .pld)
- DEBUGLOG ([SP-059](#SP-059--DEBUGLOG)) - matched by member name
- WEBUTIL.LENGTH ([SP-040](#SP-040--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)
- WEBUTIL.REGISTER_FUNCTION ([SP-047](#SP-047--WEBUTIL.REGISTER_FUNCTION)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Attempt to locate the DLL in the Oracle FFI library cache using ORA_FFI.FIND_LIBRARY. If the library is found, store the handle in DLL_HANDLE and continue.
- Step 2 - If FIND_LIBRARY raises an FFI error (DLL not currently loaded), invoke D2KWUTIL.ATTEMPT_DLL_LOAD to reload the DLL from DLL_Path. Store the resulting handle in DLL_HANDLE if successful.
- Step 3 - If ATTEMPT_DLL_LOAD also raises an FFI error, set API_ENABLED to FALSE, record an error via ADD_ERROR (source 'D2KWUTIL', message indicating the DLL was not found), and raise NO_DATA_FOUND to abort processing.
- Step 4 - Check whether the function has already been registered by testing whether FunctionLoad contains an entry for FunctionID and whether that entry matches the current DLL_LOAD_COUNT. If either condition fails, proceed with (re-)registration; otherwise skip to the end.
- Step 5 - Register the function with the loaded DLL by calling ORA_FFI.REGISTER_FUNCTION using DLL_HANDLE, FunctionName, and the C_STD calling convention. Store the resulting function handle in FunctionHandle(FunctionId).
- Step 6 - If FunctionName is not 'd2kwutil_DebugString', log the registration event via DEBUGLOG (level 99, procedure name 'Register_Function_Call'), distinguishing between an initial registration and a re-registration by checking whether FunctionLoad already holds an entry for FunctionID.
- Step 7 - Parse the FunctionArgs string (comma-delimited, with a trailing comma appended) in a loop. For each non-empty, non-'VOID' argument fragment, call D2KWUTIL.TRANSLATETYPE to convert the type token to its FFI equivalent and register it as a parameter via ORA_FFI.REGISTER_PARAMETER against the function handle.
- Step 8 - After all parameters are registered, if FunctionReturn is not 'VOID' and is not NULL, call D2KWUTIL.TRANSLATETYPE on FunctionReturn and register the return type via ORA_FFI.REGISTER_RETURN.
- Step 9 - Store DLL_LOAD_COUNT in FunctionLoad(FunctionId) to mark this function as registered at the current load generation, preventing redundant re-registration on future calls.
- Step 10 - If an FFI error is raised at any point during registration, capture it in the outer exception handler, record the error via ADD_ERROR and ADD_EXTERNAL_ERRORS (using FunctionName as the source and appending any external error text), and raise NO_DATA_FOUND.

---
**Decision Points**

DP-001

Condition: ORA_FFI.FIND_LIBRARY succeeds in locating the DLL.

TRUE: DLL_HANDLE is populated and processing continues to the registration check (DP-002).

FALSE: An FFI error is raised; D2KWUTIL.ATTEMPT_DLL_LOAD is invoked to reload the DLL (DP-002 is reached only if the reload succeeds).

---

DP-002

Condition: D2KWUTIL.ATTEMPT_DLL_LOAD succeeds in loading the DLL after the initial FIND_LIBRARY failure.

TRUE: DLL_HANDLE is set from the reload result and processing continues to the registration check.

FALSE: An FFI error is raised; API_ENABLED is set to FALSE, ADD_ERROR is called, and NO_DATA_FOUND is raised to abort.

---

DP-003

Condition: FunctionLoad does not contain an entry for FunctionID, OR FunctionLoad(FunctionID) does not equal DLL_LOAD_COUNT.

TRUE: The function must be (re-)registered; Steps 5-9 are executed.

FALSE: The function is already registered at the current DLL load generation; Steps 5-9 are skipped.

---

DP-004

Condition: FunctionName equals 'd2kwutil_DebugString'.

TRUE: The DEBUGLOG call is suppressed to avoid recursive logging.

FALSE: DEBUGLOG is called to record whether this is an initial registration or a re-registration.

---

DP-005

Condition: FunctionLoad already contains an entry for FunctionID at the point the DEBUGLOG call is made.

TRUE: The log message identifies this as a re-registration and includes the previous load count.

FALSE: The log message identifies this as an initial registration.

---

DP-006

Condition: The current argument fragment parsed from FunctionArgs is non-null, non-empty, and not equal to 'VOID'.

TRUE: D2KWUTIL.TRANSLATETYPE is called on the fragment and ORA_FFI.REGISTER_PARAMETER is invoked.

FALSE: The parameter-registration loop exits.

---

DP-007

Condition: FunctionReturn is not 'VOID' (case-insensitive) and is not NULL.

TRUE: D2KWUTIL.TRANSLATETYPE is called on FunctionReturn and ORA_FFI.REGISTER_RETURN is invoked to register the return type.

FALSE: No return type is registered (the function is treated as a void procedure).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The DLL must be locatable via ORA_FFI.FIND_LIBRARY or recoverable via D2KWUTIL.ATTEMPT_DLL_LOAD before any function registration is attempted; if neither succeeds, the API is disabled and no further processing occurs.
- BR-002 - A function is registered with the FFI layer only when it has no prior registration entry or when the DLL has been reloaded (DLL_LOAD_COUNT has changed) since the last registration, preventing redundant FFI registration calls.
- BR-003 - The function 'd2kwutil_DebugString' is explicitly excluded from DEBUGLOG calls during its own registration to prevent recursive logging.
- BR-004 - All argument type tokens supplied in FunctionArgs must be translated through D2KWUTIL.TRANSLATETYPE before being passed to ORA_FFI.REGISTER_PARAMETER; raw type strings are not used directly.
- BR-005 - A return type is registered only when FunctionReturn is both non-null and not equal to 'VOID' (case-insensitive); void procedures receive no return-type registration.
- BR-006 - On any FFI error during function or parameter registration, the error is surfaced via ADD_ERROR combined with ADD_EXTERNAL_ERRORS, and NO_DATA_FOUND is raised to signal failure to the caller.
- BR-007 - The FunctionLoad array is updated with DLL_LOAD_COUNT only after all registration steps (function handle, parameters, and return type) complete successfully, ensuring the cached load count reflects a fully registered function.

---
**Implementation Logic**

```plsql

PROCEDURE Register_Function_Call ( FunctionID     in PLS_INTEGER, 
                                   FunctionName   in VARCHAR2,
                                   FunctionReturn in VARCHAR2, 
                                   FunctionArgs   in VARCHAR2) is
  vcArgs  VARCHAR2(200);
  vcFrag  VARCHAR2(10);
  iOffset PLS_INTEGER;   
begin 
   -- See if the DLL has been loaded at all.
   -- if this call to FIND_LIBRARY fails, we'll fall through to the Exception.
   begin
    DLL_HANDLE := ORA_FFI.find_library(DLL_NAME);
  exception
    when ora_ffi.ffi_error then 
      -- Attempt to load the DLL again in a subblock. If this fails
      -- then the API must be disabled and NOT_DATA_FOUND raised
      begin 
          DLL_HANDLE := Attempt_DLL_Load(DLL_Path, DLL_NAME);
      exception
          when ora_ffi.ffi_error then 
            API_ENABLED := FALSE;
              add_error('D2KWUTIL',DLL_NAME||' not found.');
            RAISE NO_DATA_FOUND;
      end;
  end;

  -- now compare the Cached value for this function's loadcount with 
  -- that for the DLL this tells us that the function has either not 
  -- been registered yet, or that the DLL has been reloaded in between 
  -- times.  This would not be healthy so we have to re-register in that case.
  if (not FunctionLoad.exists(FunctionId)) or (FunctionLoad(FunctionId)<> DLL_LOAD_COUNT) then
    -- We need to go through the registration process.      
    -- Register the function with the DLL
    FunctionHandle(FunctionId) := ora_ffi.register_function(Win_API.DLL_HANDLE,FunctionName,ORA_FFI.C_STD);
    if FunctionName <> 'd2kwutil_DebugString' then 
    	if not FunctionLoad.exists(FunctionId) then 
    		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Initial Reg');
    	else
       		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Re-Registration Count = '||to_char(FunctionLoad(FunctionId)));
       	end if;
    end if;
    
    -- Loop through and register the parameters
    vcArgs := FunctionArgs||',';
    while vcArgs is not null and vcArgs <> ',' and vcArgs <> 'VOID,' LOOP
      iOffset := instr(vcArgs,',');
      vcFrag := substr(vcArgs,1,iOffset-1);
      ora_ffi.register_parameter(FunctionHandle(FunctionId),TranslateType(vcFrag));
      if iOffset = length(vcArgs) then
        vcArgs := NULL;
      else
        vcArgs := substr(vcArgs,iOffset+1);
      end if;
    end LOOP;
    
    -- Register the return type IF this is a function
    if upper(FunctionReturn) <> 'VOID' and FunctionReturn is not NULL then 
      ora_ffi.register_return(FunctionHandle(FunctionId),TranslateType(FunctionReturn));
    end if;
    
    -- Now add this Function's Loadcount to the array to prevent un-nessary re-registration
    FunctionLoad(FunctionId) := DLL_LOAD_COUNT;
  end if;
exception
   when ora_ffi.ffi_error then
    Win_API.Add_error(FunctionName, Win_API.UError||WIN_API.Add_External_errors); 
    raise NO_DATA_FOUND;
end Register_Function_Call;
```

#### SP-063 - SETDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Initialises the debug logging configuration for the application session. The procedure accepts the desired debug output type, an optional target file name, a severity threshold level, and a timestamp flag, then sets the corresponding package-level state variables and records a confirmation entry via DEBUGLOG to signal whether logging has been directed to a file, started in-session, or stopped.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugType | PLS_INTEGER | IN |
| DebugFile | VARCHAR2 | IN |
| DebugLevel | PLS_INTEGER | IN |
| TimeStamp | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-059](#SP-059--DEBUGLOG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Store the incoming TimeStamp flag in the package-level variable bDebugTimeStamp to control whether subsequent log entries include a timestamp.
- Step 2 - Store the incoming DebugFile value in the package-level variable vcDebugFile to record the target log file path (may be NULL when file logging is not required).
- Step 3 - Store the incoming DebugLevel value in the package-level variable iDebugLevel to set the severity threshold that governs which messages are written by DEBUGLOG.
- Step 4 - Evaluate the DebugType parameter to determine the logging mode and set iDebugState accordingly (see Decision Points).
- Step 5 - Call DEBUGLOG with severity 0 and the originating routine name 'SetDebug' to write a confirmation message reflecting the logging mode that was activated or deactivated.

---
**Decision Points**

DP-001

Condition: DebugType = 1

TRUE: Set iDebugState to 1 (file logging mode) and call DEBUGLOG to record the message 'Logging to File ' concatenated with the DebugFile value.

FALSE: Evaluate DP-002.

---

DP-002

Condition: DebugType = 2

TRUE: Set iDebugState to 2 (in-session/screen logging mode) and call DEBUGLOG to record the message 'Logging Started'.

FALSE: Call DEBUGLOG to record the message 'Logging Stopped', then set iDebugState to 0 (logging disabled).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - DebugType = 1 designates file-based logging; the DebugFile parameter must carry a meaningful file path in this mode, as it is stored directly and referenced in the confirmation log entry.
- BR-002 - DebugType = 2 designates in-session (non-file) logging; no file path is required.
- BR-003 - Any DebugType value other than 1 or 2 disables logging entirely by setting iDebugState to 0.
- BR-004 - The default DebugLevel is 98, meaning only messages at or below severity 98 will be written unless the caller explicitly overrides this threshold.
- BR-005 - The default TimeStamp value is FALSE; timestamp inclusion in log entries must be explicitly requested by the caller.
- BR-006 - A DEBUGLOG call at severity 0 is always made upon completion of SETDEBUG regardless of the resulting logging state, ensuring an audit trail of every configuration change.

---
**Implementation Logic**

```plsql

PROCEDURE SetDebug( DebugType   IN PLS_INTEGER, 
                    DebugFile   IN VARCHAR2 DEFAULT NULL, 
                    DebugLevel  IN PLS_INTEGER DEFAULT 98,                        
                    TimeStamp   IN BOOLEAN DEFAULT FALSE) is
begin 
    bDebugTimeStamp := TimeStamp;
    vcDebugFile     := DebugFile;
    iDebugLevel     := DebugLevel;
	if DebugType = 1 then 
		iDebugState := 1;
		DebugLog(0,'SetDebug','Logging to File '||DebugFile);
	elsif DebugType = 2 then
		iDebugState := 2;
		DebugLog(0,'SetDebug','Logging Started');
	else 
        DebugLog(0,'SetDebug','Logging Stopped');
        iDebugState := 0;
	end if;
end SetDebug;
```

#### SP-064 - SF_COPYRIGHT_DECLARATION

**Invoked From:**

- sr_exch_lyl_dlr_rep_fmb.xml [Trigger: KEY-CLRFRM]
- sr_exch_lyl_dlr_rep_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

Note: Data can only be fetched for 10 days (N/A / CN_MAIN)

---

**Purpose**

Returns a formatted copyright string for Maruti Suzuki India Limited, reflecting the correct financial year. Because the Indian financial year runs April-March, the function adjusts the displayed year so that January, February, and March show the preceding calendar year rather than the current one. The result is used by the sr_exch_lyl_dlr_rep_fmb form at initialisation and on form-clear to display an accurate copyright notice.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Capture the current system date into a local date variable using SYSDATE.
- Step 2 - Evaluate the month portion of the captured date to determine whether it falls in the January-March period (i.e., the tail end of the previous financial year).
- Step 3 - If the month is January, February, or March, derive the copyright year by subtracting 1 from the current calendar year, reflecting that the financial year started in the previous calendar year.
- Step 4 - If the month is April through December, use the current calendar year as the copyright year, as the financial year started in the same calendar year.
- Step 5 - Assemble and return the copyright string in the format '- <YYYY> Maruti Suzuki India Limited '.

---
**Decision Points**

DP-001

Condition:
The month of SYSDATE is one of 'JAN', 'FEB', or 'MAR'.

TRUE:
The copyright year is set to (current calendar year - 1), because those months belong to the financial year that began in the previous calendar year. The returned string uses this adjusted year.

FALSE:
The copyright year is set to the current calendar year, because the month falls within April-December, which is the start of the current financial year. The returned string uses the current year.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The financial year is assumed to run from April to March; therefore January, February, and March are treated as part of the financial year that started in the preceding calendar year.
- BR-002 - The copyright owner is always 'Maruti Suzuki India Limited'; this value is hardcoded and must not be altered without a formal change request.
- BR-003 - The copyright year displayed must reflect the financial year in which the current date falls, not simply the calendar year, ensuring regulatory and branding accuracy.
- BR-004 - The function accepts no input parameters and performs no database reads or writes; it relies solely on SYSDATE for its calculation, making it stateless and side-effect-free.
- BR-005 - The returned varchar2 string is limited to 50 characters; the assembled copyright notice must not exceed this length.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
function sf_copyright_declaration return varchar is
a varchar2(50);
dt date;
begin
--Modified by Prerna on 16-May-11  to display current Financial Year Copyright
dt := sysdate;

    if( to_char(dt,'MON') in ('JAN','FEB','MAR')) then
        a := '- '||to_char(to_number(to_char(dt,'RRRR')) - 1)||' Maruti Suzuki India Limited ';
    else
        a := '- '||to_char(dt,'RRRR')||' Maruti Suzuki India Limited ';
    end if;
return(a);
end;

```

#### SP-065 - STRIPDIRSEP

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sanitises a file-system path string supplied by the caller by removing any semicolon-delimited suffix and any trailing backslash directory separator. The cleaned path is returned as a VARCHAR2 value for use by D2KWUTIL.ATTEMPT_DLL_LOAD when constructing a valid directory reference for DLL loading.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| InPath | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-040](#SP-040--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input path string (InPath) and assign it to a local working variable (vcPath, max 500 characters).
- Step 2 - Inspect vcPath for the presence of a semicolon character. If one exists, truncate vcPath to retain only the substring that precedes the first semicolon, discarding any additional path entries or parameters that follow it.
- Step 3 - Inspect the last character of the (possibly truncated) vcPath. If it is a backslash ('\'), remove that trailing character by retaining only the substring up to the penultimate character.
- Step 4 - Return the sanitised path string to the caller.

---
**Decision Points**

DP-001

Condition: INSTR(vcPath, ';') > 0 - the path string contains at least one semicolon.

TRUE: Truncate vcPath to the substring from position 1 up to (but not including) the first semicolon, discarding everything from the semicolon onward.

FALSE: vcPath is left unchanged; no truncation is performed.

---

DP-002

Condition: SUBSTR(vcPath, -1, 1) = '\' - the last character of vcPath (after any semicolon stripping) is a backslash directory separator.

TRUE: Remove the trailing backslash by retaining only the substring from position 1 to LENGTH(vcPath) - 1.

FALSE: vcPath is left unchanged; no trailing character is removed.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only the portion of the path that precedes the first semicolon is considered valid; any semicolon and all subsequent characters must be discarded before the path is used.
- BR-002 - A valid directory path must not end with a backslash separator; if one is present it must be stripped before the path is returned.
- BR-003 - The sanitised path string returned must not exceed 500 characters, as enforced by the local working variable declaration.
- BR-004 - The function is read-only with respect to all external state; it performs no database interactions and produces no side-effects beyond returning the cleaned path value.

---
**Implementation Logic**

```plsql

  

Function StripDirSep ( InPath in varchar2) return varchar2 is 
  vcPath  varchar2(500) := InPath;
begin 
  -- Check and Strip SemiColons, we take everything
  -- Before the first Semicolon as our path
  if instr(vcPath,';') > 0 then
    vcPath := substr(vcPath,1,instr(vcPath,';') -1);
  end if;

  -- Check and Strip '\'
  if substr(vcPath,-1,1) = '\' then 
    vcPath := substr(vcPath,1,length(vcPath)-1);
  end if;

  return vcPath;
end StripDirSep;
```

#### SP-066 - WINDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WINDEBUG provides a bridge between Oracle Forms and the D2KWUTIL Windows API debug utility. It accepts a text string and forwards it to the external D2KWUTIL_DEBUGSTRING function for debug output, provided the Windows API layer is available. If the API is unavailable or an unexpected error occurs, the procedure records a structured error via ADD_ERROR and re-raises the exception to the caller.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-055](#SP-055--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-056](#SP-056--ADD_EXTERNAL_ERRORS)) - matched by member name
- D2KWUTIL.D2KWUTIL_DEBUGSTRING ([SP-003](#SP-003--D2KWUTIL.D2KWUTIL_DEBUGSTRING)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- REGISTER_FUNCTION_CALL ([SP-062](#SP-062--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input text string and append a newline character (CHR(10)) to form the output buffer vcBuff1.
- Step 2 - Check whether the Windows API layer is enabled by evaluating WIN_API.API_ENABLED.
- Step 3 - If the API is enabled, register the external function call for 'D2KWUTIL_DEBUGSTRING' using REGISTER_FUNCTION_CALL, passing the debug string function handle identifier (iDebugString), the function name, a NULL library reference, and the '*CHAR' parameter type descriptor.
- Step 4 - Invoke D2KWUTIL.D2KWUTIL_DEBUGSTRING with the resolved function handle and the prepared buffer to send the debug text to the Windows debug output stream.
- Step 5 - If the API is not enabled, raise the WIN_API.NOT_AVAILABLE exception.
- Step 6 - In the NOT_AVAILABLE exception handler, call ADD_ERROR to log the failure, identifying the source as 'WinDebug' and supplying the WIN_API.NoAPI error code, then re-raise the exception.
- Step 7 - In the OTHERS exception handler, call ADD_ERROR to log the failure, identifying the source as 'WinDebug' and supplying a concatenation of WIN_API.UError and the result of ADD_EXTERNAL_ERRORS to capture any additional external error detail, then re-raise the exception.

---
**Decision Points**

DP-001

Condition: WIN_API.API_ENABLED evaluates to TRUE.

TRUE: Register the external function call via REGISTER_FUNCTION_CALL and forward the debug text to D2KWUTIL.D2KWUTIL_DEBUGSTRING.

FALSE: Raise the WIN_API.NOT_AVAILABLE exception, which is subsequently caught, logged via ADD_ERROR with the NoAPI error code, and re-raised to the caller.

DP-002

Condition: An exception is raised - specifically WIN_API.NOT_AVAILABLE versus any other (OTHERS) exception.

TRUE (NOT_AVAILABLE): Log the error via ADD_ERROR using WIN_API.NoAPI as the error descriptor and re-raise.

FALSE (OTHERS): Log the error via ADD_ERROR using the concatenation of WIN_API.UError and ADD_EXTERNAL_ERRORS as the error descriptor and re-raise.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The Windows API layer must be active (WIN_API.API_ENABLED = TRUE) before any attempt is made to invoke the external debug string function; the procedure does not silently degrade - it raises and logs an error if the API is unavailable.
- BR-002 - The input text is always suffixed with a newline character (CHR(10)) before being passed to the external debug function, ensuring consistent line termination in debug output.
- BR-003 - The external function call must be registered via REGISTER_FUNCTION_CALL before D2KWUTIL.D2KWUTIL_DEBUGSTRING is invoked; the function handle resolved from iDebugString is used for the actual call.
- BR-004 - All exceptions (both WIN_API.NOT_AVAILABLE and unhandled OTHERS) are logged through ADD_ERROR before being re-raised, ensuring no error is silently swallowed and the calling context is always notified of failure.
- BR-005 - For unhandled errors, ADD_EXTERNAL_ERRORS is appended to the WIN_API.UError descriptor to capture any supplementary external error information at the point of failure.

---
**Implementation Logic**

```plsql
  

  
PROCEDURE WinDebug  (  Text  IN   VARCHAR2) is
  vcBuff1 VARCHAR2(2000) := Text||chr(10);
begin 
  --WIN_API.Clean_Error_Stack;
  if Win_API.API_ENABLED then
    win_api.Register_function_call(iDebugString,'d2kwutil_DebugString',NULL,'*CHAR');
    d2kwutil_DebugString(win_api.FunctionHandle(iDebugString),vcBuff1);
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if; 
exception
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('WinDebug',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('WinDebug',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end WinDebug;
```

# BUSINESS REQUIREMENTS DOCUMENT

## Table of Contents

- 1. Document Control
  - 1.1 Document Information
  - 1.2 Revision History
- 2. Executive Summary
  - Key Stakeholders
- 3. System Context
- 4. Functional Requirements
  - 4.1 Business Requirements
    - Requirement ID: BR-001
    - Requirement ID: BR-002
    - Requirement ID: BR-003
    - Business Scenarios - How Other Dealer availability differs by report type
    - Requirement ID: BR-004
    - Business Scenarios - How File Name availability differs by output format
    - Requirement ID: BR-005
    - Requirement ID: BR-006
    - Requirement ID: BR-007
    - Requirement ID: BR-008
    - Requirement ID: BR-009
    - Business Scenarios - How the report submission differs by report type
    - Requirement ID: BR-010
    - Requirement ID: BR-011
    - Requirement ID: BR-012
    - Requirement ID: BR-013
    - Requirement ID: BR-014
    - Requirement ID: BR-015
    - Requirement ID: BR-016
    - Requirement ID: BR-017
    - Requirement ID: BR-018
    - Requirement ID: BR-019
- 5. Business Rules Catalogue
- 6. Data Requirements
  - 6.1 Business Entities and Relationships
    - Report Configuration - EH_REPORTS
    - Report Parameter Configuration - ED_REPORTS
    - Entity Relationships
  - 6.2 Data Capture Requirements
    - Report Selection Parameters (Dealer User - report request)
    - Auto-Populated and Derived Fields (System - on form reset or submission)
    - Session and Global Parameters (System - passed from calling context)
  - 6.3 Reference Data
  - 6.4 Data Lifecycle
  - 6.5 Excel Output Columns
- 7. Glossary
- 8. Technical Inventory
  - 8.1 Form Architecture
    - 8.1.1 Global Variables
    - 8.1.2 Form Parameters
  - 8.2 Blocks
    - 8.2.1 Block WhereClause and OrderByClause
  - 8.3 Items Summary
  - 8.4 List of Values
  - 8.5 Alerts
  - 8.6 Program Units
  - 8.7 Triggers
    - 8.7.1 Inactive / Commented-Out Trigger Register
  - 8.8 Canvas and Window Inventory
  - 8.9 Editors
  - 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups
    - 8.10.1 Visual Attributes (form-defined)
    - 8.10.2 Property Classes (form-defined)
    - 8.10.3 Object Groups
  - 8.11 DataSourceColumn Inventory
- 9. Object Library
- 10. Record Groups
- 11. Referenced Database Objects
- 12. Backend Procedures and Packages
  - 12.1 Main Flow Backend Procedure/Package Index
  - 12.2 Procedure and Package Catalogue
- 13. Package Procedure Specifications
- 14. Database Package Catalogue
- 15. PLD Procedure Call Sites
  - Inactive / commented-only PLD call sites
  - D2kwutil.pld (`Win_API`)
- 16. Microservice API Candidates
  - 16.1 Microservices with APIs
- 17. Workflows
- 18. PLD-Backed Logic
  - DPL.pld (`general`)
  - D2kwutil.pld (`Win_API`)
- 19. PCK-Backed Logic
- 20. System Interfaces
  - 20.1 Database Integrations
  - 20.2 External System Integrations
  - 20.3 Report Integrations
    - 20.3.1 Parameters Passed to the Report
- 21. Procedure and Function Business Rule Catalogue
  - 21.1 Catalogue Index
  - 21.2 Detailed Specifications
    - SP-001 - PR_PASS_PARAM
    - SP-002 - GENERAL.ASK_CONFIRM
    - SP-003 - GENERAL.DISP_TEXT
    - SP-004 - GENERAL.RAISE_ERROR

## 1. Document Control

### 1.1 Document Information

| Field | Value |
| ----- | ----- |
| Document Title | VR_FSC_DLR - Business Requirements Document |
| Form Module Name | VR_FSC_DLR |
| Document Version | 1.0 |
| Date Created | August 15, 2026 |
| Author/Prepared By | BRD Agent |

### 1.2 Revision History

| Version | Date | Author | Description |
| --- | --- | --- | --- |
| 1.0 | August 15, 2026 | BRD Agent | Initial draft |

---

## 2. Executive Summary

*High-level overview of the vr_fsc_dlr FSC Dealer Report form, its purpose, and roles referenced in the module.*

The **vr_fsc_dlr** Oracle Forms module is the **FSC Dealer Report** parameter-selection screen. A dealer user opens the screen and selects the reporting parameters - the reporting dealer, the month and year, the report type (Summary or Detail), and the output format - before submitting the report. When Detail report type is chosen, the user is also required to select a second comparison dealer. The form validates that all mandatory parameters are correctly filled (dealer cannot be empty, a valid reason must be selected, future and current-month periods are blocked), calculates the exact reporting date range from the chosen month and year, sets the appropriate report identifier, constructs the full parameter string, and submits the configured report to the report engine. The generated PDF or formatted output is opened in the browser for the user to review.

### Key Stakeholders

*Who uses vr_fsc_dlr*

| Stakeholder | Role |
| :--- | :--- |
| **Dealer User** | **Primary interactive user** of vr_fsc_dlr. Selects all report parameters - reporting dealer, period, report type, and format - and submits the report for generation. |
| **Report Server / Print Engine** | Receives the configured report job and parameter string from the form and generates the output file; the user does not interact with it directly. |

---

---

## 3. System Context

*Describes the vr_fsc_dlr module's role within the DMS ecosystem, scope, process flow, and key integrations.*

The **vr_fsc_dlr** module is the **FSC Dealer Report** parameter-entry screen within the Dealer Management System (DMS). It is the single entry point through which authorised dealer users configure and generate FSC (Franchisee Service Contract) performance reports. The form connects the dealer user interface with the report engine, dealer master data, and the report parameter configuration store.

**System purpose:** Accept and validate report selection parameters - dealer, period, report type, and output format - build the complete report parameter string, and submit the configured report to the report engine for generation and immediate browser display.

**In scope:**

- Restore report session context and identify the report server when the screen opens
- Allow the user to select the primary reporting dealer from their authorised dealer list via a lookup
- Allow the user to select a comparison dealer (required for Detail report type)
- Allow the user to select the reporting month, year, and report type (Summary or Detail)
- Allow the user to select the output format (PDF, HTML, Character)
- Derive and display the calculated from-date and to-date of the reporting period
- Enforce mandatory field validation: dealer must be selected, a reason category must be chosen
- Block report generation for the current or any future month
- Build the full report parameter string from the ED_REPORTS configuration table
- Submit the report job to the report server and open the generated output in the browser

**Process Name:** FSC Dealer Report Generation

**Process Owner:** INFERRED - Dealer Operations Manager

**Process Objective:** Open the report screen, select the authorised reporting dealer and period, choose the report type and format, validate all mandatory parameters, and submit the report to the engine for immediate output.

**Process Trigger:** Dealer user requests an FSC report from the DMS application menu

**Process Flow:**

The complete FSC dealer report generation process follows this sequence. Each step corresponds to Functional Requirements in Section 4.

```
STEP 1 ── SCREEN OPENS
         The user opens the FSC Dealer Report screen.
         The system restores the session context: report description, report name, app ID,
         and copyright declaration are reloaded from global session values.

STEP 2 ── REPORT SERVER RESOLVED
         The system looks up the report server name from the report configuration store
         based on the current application ID and the user's principal/company mapping.
         If not found, the global default report server is used.

STEP 3 ── SELECT REPORT TYPE
         The user selects the report type: Summary (S) or Detail (D).
         Selecting Detail enables the comparison dealer field (mandatory);
         selecting Summary hides and clears the comparison dealer field.

STEP 4 ── SELECT PRIMARY DEALER
         The user selects the primary reporting dealer from the authorised dealer lookup.
         The lookup displays dealers and their FOR codes that the logged-in user is
         authorised to access.
         The system populates the dealer code, FOR code, and parent group code fields.

STEP 5 ── DEALER MANDATORY CHECK
         The system validates that a primary dealer has been selected.
         If the dealer field is empty, an error is displayed and navigation is halted.

STEP 6 ── SELECT COMPARISON DEALER - Detail report type only
         ├── SUMMARY: Comparison dealer field is disabled; skip to STEP 8
         └── DETAIL: The user selects the comparison dealer from the other-dealer lookup.
                     The system populates the comparison dealer description and parent group.

STEP 7 ── COMPARISON DEALER MANDATORY CHECK - Detail report type only
         The system validates that the comparison dealer field is not empty when report type
         is Detail. An error is displayed and navigation is halted if it is empty.

STEP 8 ── SELECT REPORTING MONTH AND YEAR
         The user selects the reporting month (JAN-DEC) and the reporting year from the
         respective selection lists.

STEP 9 ── CALCULATE REPORTING DATE RANGE
         The system derives the first and last days of the selected month and year
         to produce the from-date and to-date of the reporting period.
         The calculated dates are displayed to the user in read-only fields.

STEP 10 ── SELECT REASON CATEGORY
          The user selects a reason category from the reason selection list.
          The system validates that the reason field is not empty on leaving the field.

STEP 11 ── SELECT OUTPUT FORMAT
          The user selects the output format (HTMLCSS, PDF, CHARACTER).
          If EXCEL is selected, the filename field becomes editable; for all other
          formats the filename field is disabled and cleared.

STEP 12 ── CURRENT-MONTH BLOCK CHECK
          When the selected report type is Summary, the system checks whether the
          chosen month and year match the current calendar month.
          If they match, an error is displayed: the FSC Summary report cannot be
          generated for the current month.

STEP 13 ── FUTURE-MONTH BLOCK CHECK
          The system checks whether the selected reporting period falls in a future month.
          If the from-date month is ahead of the current calendar month within the same
          year, or the month-year combination is entirely in the future, an error is
          displayed and report generation is blocked.

STEP 14 ── SUBMIT BUTTON PRESSED
          The user clicks the SUBMIT REPORT button to initiate report generation.
          All field-level validations (dealer not empty, comparison dealer if Detail,
          current/future month checks) are re-applied before proceeding.

STEP 15 ── REPORT IDENTIFIER SET
          The system sets the report application identifier based on the report type:
          `vr_fsc_dlr` for Detail reports and `vr_fsc_dlr_sum` for Summary reports.

STEP 16 ── PARAMETER STRING BUILT
          The system queries the report parameter configuration store to retrieve the
          parameter definitions for the active report application and principal.
          A parameter string is assembled containing: parent dealer group, FOR code,
          from-date, to-date, comparison parent group, and principal code.

STEP 17 ── REPORT OBJECT CONFIGURED
          The system locates the named report object in the form and sets all required
          report properties: report filename, output server, output format (PDF),
          destination type (FILE), destination path, and the full parameter string.
          The output filename is derived from the logged-in user ID and the current
          date-time stamp.

STEP 18 ── REPORT SUBMITTED TO ENGINE
          The system submits the report to the report server for execution.

STEP 19 ── OUTPUT DISPLAYED IN BROWSER
          The generated report file is opened in a new browser window for the user
          to review, print, or save.
```

**Major process interactions:**

- **Dealer location and authorisation master** - supplies the authorised dealer list filtered to the logged-in user and principal
- **Report parameter configuration store (ED_REPORTS)** - provides the parameter definitions and serial order for each report application
- **Report server configuration store (EH_REPORTS)** - provides the runtime report server name per application ID and principal
- **Report engine (Report Server)** - receives the configured report job and generates the PDF or formatted output file
- **Oracle session context (DBMS_APPLICATION_INFO)** - registers the form name and client context at startup and clears it on exit

---

---

## 4. Functional Requirements

### 4.1 Business Requirements

#### Requirement ID: BR-001

**Requirement Title:** Form Session Initialization and Application Logging

**Business Description:**
When the FSC Dealer report form is opened, the system registers the form's identity in the current database session so that database administrators can trace which form is active for monitoring and support purposes. If the application performance logging feature has been activated for the current session, the system also starts a timing measurement at that point. The system then initialises the form's display context - setting the report description to *"Free Service Claim Report"*, resolving the report server from a configuration file, loading the year selection list from the financial year reference data, maximising the main window, displaying the copyright declaration, and setting the initial enabled state of the action buttons - before placing the cursor at the Dealer field ready for user input.

**Actors:** Dealer User

**Preconditions:**
- The user has successfully authenticated and launched the FSC Dealer report form.

**Main Flow:**

**Step 1 - Application performance timer started (when logging is active)**
If the application-level performance logging feature is switched on for the current session, the system starts an internal timing measurement at form-open time. This allows application performance to be tracked for the session.

**Step 2 - Database session tagged with form identity**
The system records the form's identity in the current database session's client information and module fields. This enables database administrators and support staff to identify which form module is responsible for any session activity they observe.

**Step 3 - Report description and application identity initialised**
The system seeds the `report_desc` field with *"Free Service Claim Report"* and displays it on the form. The `app_id` application identifier is seeded to `vr_fsc_dlr` and the report name field is aligned to match, so the form context is correctly identified throughout the session. The report-access permission flag (`PARAMETER.P_CHECK`) is set to `1` to confirm that this application has the required report access.

**Step 4 - Report server resolved from configuration**
The system queries the report configuration register for the current application and principal (company/brand) combination to find the configured report server name. If a server entry is found and is non-blank, the system reads the server name from a configuration text file located on the application server and uses that as the active report server. If no matching entry is found, the entry has no server value, or any error occurs during the lookup or file read, the system falls back to the default report server value held in the user's session context.

**Step 5 - Main window maximised and copyright declaration displayed**
The system maximises the main application window so the form occupies the full screen. It then retrieves the current copyright declaration text from the database and displays it on the form.

**Step 6 - Financial year reference data inserted and Year selection list populated**
The system reads the financial year start and end years from the current session context and inserts them into the financial year reference table (`GBL_Fin_Year`) for the current dealer and location. It then builds the Year selection list from that reference data (record group `P_YR`) and populates the Year dropdown on the form so the user can select the reporting year.

**Step 7 - Action buttons set to initial disabled state**
The system disables the Save and Delete action buttons at form open, as no record is yet being edited. The Other Dealer field is also disabled, since no Dealer Comparison report type has been selected at this point.

**Step 8 - Cursor placed at the Dealer field**
The system moves the cursor to the Dealer field, which is the first field the user is required to complete, ready for data entry.

---

---

#### Requirement ID: BR-002

**Requirement Title:** Form Reset and Report Configuration Refresh

**Business Description:**
When the user resets the report selection form, the system clears all current entries and reloads the form with the default report description, report identity, and application context carried in from the user's session. It also determines the correct report server to use for the principal (company/brand context), reading the server name from a configuration file on the server. Finally, the system refreshes the copyright declaration displayed on the form. The result is a clean, correctly configured form ready for a new report request.

**Actors:** Dealer User

**Preconditions:**
- The user is on the FSC Dealer report form with the report parameters populated or partially populated.

**Main Flow:**

**Step 1 - Form cleared and session defaults restored**
The system clears all current entries on the form and immediately restores the report description, report name, and application identifier from the user's current session context, ensuring the form retains the correct context after clearing.

**Step 2 - Report server resolved from configuration**
The system queries the report configuration register for the current application and principal (company/brand) combination to find the configured report server name. If a server entry is found and is non-blank, the system reads the server name from a configuration text file located on the application server and uses that as the active report server. If no matching configuration entry is found, the entry has no server value, or any error occurs during the lookup or file read, the system falls back to the default report server value held in the user's session context.

**Step 3 - Copyright declaration refreshed**
The system retrieves the current copyright declaration text from the database and displays it on the form.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Report Description (`REPORT_DESC`) | Auto-populated | Display | 200 | N/A | Session global value | Form successfully cleared | Auto-set from session; read-only display | N/A |
| Report Name (`REPORT_NAME`) | Auto-populated | Display | 2000 | N/A | Session global value | Form successfully cleared | Auto-set from session; read-only display | N/A |
| Application Identifier (`APP_ID`) | Auto-populated | Display | 200 | N/A | Session global value | Form successfully cleared | Auto-set from session; read-only display | N/A |
| Report Server (`REP_SERVER`) | Auto-populated | Display | N/A | Report configuration (EH_REPORTS) | Server name from configuration file | Form successfully cleared | Resolved from configuration; falls back to session default on any error | Falls back to session-level default report server on no-data-found, too-many-rows, or any exception |
| Copyright Declaration (`COPYRIGHT_DECLARATION`) | Auto-populated | Display | 100 | N/A | Database function result | Report server resolved | Read-only; refreshed on every form reset | N/A |

---

---

#### Requirement ID: BR-003

**Requirement Title:** Report Type Selection Controls Other Dealer Availability

**Business Description:**
When the user changes the report type selection, the system automatically adjusts which additional fields are required. If the user selects the Dealer Comparison report type, the system activates the Other Dealer field and marks it as mandatory, clearing any previously entered value so the user must make a fresh selection. If the user selects the Summary report type instead, the system disables the Other Dealer field and clears it, as a comparison dealer is not relevant for a summary report.

**Actors:** Dealer User

**Preconditions:**
- The report type selection list is displayed and the user changes the selected value.

**Main Flow:**

**Step 1 - Report type change detected and Other Dealer field adjusted**
When the user changes the report type, the system immediately evaluates the new selection. If the Dealer Comparison type is chosen, the Other Dealer field is enabled, made navigable and editable, and given the mandatory visual indicator; any previously entered Other Dealer value is cleared so the user must re-enter it. If the Summary type is chosen, the Other Dealer field is disabled, made non-navigable and read-only, and given the default (non-mandatory) visual indicator; any previously entered Other Dealer value is also cleared.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Report type determines Other Dealer requirement | Report type evaluated - `CB_BLK.P_REPORT_TYPE` WHEN-LIST-CHANGED condition `= 'D'` vs `= 'S'` | When the user changes the Report Type selection | Ensures the Other Dealer field is mandatory only when a dealer comparison report is requested, and is suppressed for summary reports | N/A - this is a field-state control, not a blocking validation; the mandatory enforcement happens at submission time |

#### Business Scenarios - How Other Dealer availability differs by report type

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Dealer Comparison report type selected** | Other Dealer field becomes active, navigable, editable, and mandatory (highlighted accordingly); previous Other Dealer value is cleared. |
| **Summary report type selected** | Other Dealer field is disabled, non-navigable, read-only, and non-mandatory (default style); previous Other Dealer value is cleared. |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Report Type (`P_REPORT_TYPE`) | Mandatory | List (Char) | 10 | N/A | Dealer Comparison / Summary | Form initialised | User must select a valid report type | N/A |
| Other Dealer Description (`P_DLR_B`) | Conditional - when Dealer Comparison selected | Display/Entry | N/A | Other Dealer lookup (LOV_OTH_DLR) | Dealer name | Report type set to Dealer Comparison | Mandatory when Dealer Comparison type is selected; disabled and cleared for Summary type | *"Other Dealer Can not be Empty"* at submission if left blank |
| Other Dealer Parent Group (`P_PARENT_B`) | Conditional - when Dealer Comparison selected | Auto-populated | N/A | Other Dealer lookup (LOV_OTH_DLR) | Parent group code | Other Dealer selected | Auto-set when Other Dealer is chosen from the lookup; cleared when report type changes | N/A |

---

---

#### Requirement ID: BR-004

**Requirement Title:** Output Format Selection Controls File Name Field Availability

**Business Description:**
When the user selects the output format for the report, the system determines whether the File Name field should be available for entry. If the Excel output format is chosen, the system enables the File Name field so the user can specify a file name. For any other output format, the system clears the File Name field and makes it unavailable for entry, since file naming is only applicable to Excel exports.

**Actors:** Dealer User

**Preconditions:**
- The report parameters screen is displayed and the user changes the output format selection.

**Main Flow:**

**Step 1 - Format selection evaluated and File Name field adjusted**
When the user changes the output format, the system evaluates the new selection. If Excel is chosen, the File Name field is enabled and made navigable so the user can type a file name. If any other format is chosen, the File Name field is cleared, disabled, and made non-navigable.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Output format determines whether file name input is required | Format evaluated - `CB_BLK.P_DESFORMAT` WHEN-LIST-CHANGED condition `<> 'EXCEL'` vs `= 'EXCEL'` | When the user changes the Output Format selection | Ensures the File Name field is only available when the Excel output format is selected, preventing irrelevant input for other formats | N/A - this is a field-state control; if EXCEL is selected and no file name is given, the user must enter one before submitting |

#### Business Scenarios - How File Name availability differs by output format

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Excel format selected** | File Name field is enabled and navigable; user must specify a file name. |
| **Any other format selected** | File Name field is cleared, disabled, and non-navigable; no file name is required. |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Format (`P_DESFORMAT`) | Mandatory | List | N/A | N/A | Output format values | Form initialised | User must select a valid output format | N/A |
| File Name (`FILENAME`) | Conditional - when Excel format selected | Text | 4000 | N/A | N/A | Excel format selected | Only editable when Excel is the selected format; cleared and locked for all other formats | N/A |

---

---

#### Requirement ID: BR-005

**Requirement Title:** File Name Field Editability Enforcement on Entry

**Business Description:**
When the cursor moves into the File Name field, the system rechecks the currently selected output format and enforces whether the field can be typed into. If the Excel format is currently selected, the field accepts input. If any other format is selected, the field is made read-only, preventing accidental entry of a file name that would not be used.

**Actors:** Dealer User

**Preconditions:**
- The report parameters are displayed and the user navigates into the File Name field.

**Main Flow:**

**Step 1 - File Name field editability enforced on entry**
When the File Name field receives focus, the system checks the current output format. If Excel is selected, the field is set to allow insertion and updates (editable). If any other format is selected, the field is set to block insertion and updates (read-only).

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Output format checked to determine File Name editability | Format evaluated - `CB_BLK.FILENAME` WHEN-NEW-ITEM-INSTANCE condition `:p_desformat = 'EXCEL'` | When the cursor enters the File Name field | Ensures the File Name field cannot be edited when a non-Excel format is active, preventing irrelevant input | Field is set to read-only; any typing attempt is blocked |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| File Name (`FILENAME`) | Conditional - when Excel format selected | Text | 4000 | N/A | N/A | Excel format selected | Insert and update allowed only when Excel output format is selected | Field is read-only when non-Excel format is active |
| Format (`P_DESFORMAT`) | Read-only display | List | N/A | N/A | Output format values | N/A | Referenced to determine File Name editability | N/A |

---

---

#### Requirement ID: BR-006

**Requirement Title:** Reason Field Mandatory Validation

**Business Description:**
When the user leaves the Reason field, the system checks that a reason has been selected. If the field has been left empty, the system displays an error message and prevents the user from moving on until a reason is provided. This ensures that every report request is associated with a documented reason.

**Actors:** Dealer User

**Preconditions:**
- The report parameters screen is displayed and the user has navigated away from the Reason field.

**Main Flow:**

**Step 1 - Reason field checked for a value**
When the user leaves the Reason field, the system checks whether a value has been selected. If the field is empty, the system displays an error and blocks progress.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-002](#SP-002--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays an error alert to the user showing the message *"Main Reason can not be empty"* and the title "Error", then stops further processing for this trigger.
    * **Step 1** - Determine the appropriate alert type: if the title passed is 'Error', select the error alert; otherwise select the information alert.
    * **Step 2** - Set the selected alert's title and message text to the values provided by the caller.
    * **Step 3** - Display the alert to the user.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Reason must not be empty | `CB_BLK.P_REASON` IS NULL check - WHEN-VALIDATE-ITEM on CB_BLK.P_REASON | When the user leaves the Reason field | Ensures every report request has a reason recorded before the user can proceed | *"Main Reason can not be empty"* is displayed; the trigger is aborted and the cursor remains on the Reason field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-006-ES-01** - Reason field left empty - *"Main Reason can not be empty"*; the form blocks progress and the user must select a reason.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Reason (`P_REASON`) | Mandatory | List | N/A | N/A | Reason values | Form displayed | Must not be left empty | *"Main Reason can not be empty"* |

---

---

#### Requirement ID: BR-007

**Requirement Title:** Dealer Field Mandatory Validation

**Business Description:**
When the user leaves the Dealer field, the system checks that a dealer has been selected. If the field is empty, the system displays an error message and prevents the user from proceeding. A dealer selection is required for every report request, as the report is always generated in the context of a specific dealership.

**Actors:** Dealer User

**Preconditions:**
- The report parameters screen is displayed and the user has navigated away from the Dealer field.

**Main Flow:**

**Step 1 - Dealer field checked for a value**
When the user leaves the Dealer field, the system checks whether a dealer has been selected. If the field is empty, the system displays an error and blocks progress.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-002](#SP-002--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays an error alert showing the message *"Dealer Can Not be Empty"* and the title "Error".
    * **Step 1** - Determine the appropriate alert type: if the title passed is 'Error', select the error alert; otherwise select the information alert.
    * **Step 2** - Set the selected alert's title and message text to the values provided by the caller.
    * **Step 3** - Display the alert to the user.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Dealer must not be empty | `CB_BLK.P_DLR` IS NULL check - WHEN-VALIDATE-ITEM on CB_BLK.P_DLR | When the user leaves the Dealer field | Ensures that every report request specifies a dealer, as reports are always dealer-specific | *"Dealer Can Not be Empty"* is displayed; the trigger is aborted and the user must select a dealer |

*Business outcomes (errors, warnings, success, and status):*
- **BR-007-ES-01** - Dealer field left empty - *"Dealer Can Not be Empty"*; the form blocks progress and the user must select a dealer from the lookup.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dealer Description (`P_DLR`) | Mandatory | Display/Entry | N/A | Dealer details lookup (DEALER_DETAIL) | Dealer name | Form displayed | Must not be left empty | *"Dealer Can Not be Empty"* |

---

---

#### Requirement ID: BR-008

**Requirement Title:** Other Dealer Field Mandatory Validation for Dealer Comparison Reports

**Business Description:**
When the user leaves the Other Dealer field, the system checks whether the Dealer Comparison report type has been selected. If it has, and the Other Dealer field is empty, the system displays an error and blocks the user from proceeding. The Other Dealer is required specifically for dealer comparison reports, as those reports compare the primary dealer's performance against another dealership.

**Actors:** Dealer User

**Preconditions:**
- The Dealer Comparison report type has been selected and the user has navigated away from the Other Dealer field.

**Main Flow:**

**Step 1 - Other Dealer field validated when Dealer Comparison type is active**
When the user leaves the Other Dealer field, the system checks whether the Dealer Comparison report type is currently selected. If it is and the Other Dealer field is empty, the system displays an error and blocks progress. If any other report type is selected, this validation is skipped.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-002](#SP-002--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays an error alert showing the message *"Other Dealer Can not be Empty"* and the title "Error".
    * **Step 1** - Determine the appropriate alert type: if the title passed is 'Error', select the error alert; otherwise select the information alert.
    * **Step 2** - Set the selected alert's title and message text to the values provided by the caller.
    * **Step 3** - Display the alert to the user.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Other Dealer mandatory when Dealer Comparison report type is selected | `CB_BLK.P_REPORT_TYPE = 'D'` AND `CB_BLK.P_DLR_B IS NULL` - WHEN-VALIDATE-ITEM on CB_BLK.P_DLR_B | When the user leaves the Other Dealer field | Ensures that a comparison dealer is always specified when generating a Dealer Comparison report | *"Other Dealer Can not be Empty"* is displayed; the trigger is aborted and the user must select an Other Dealer |

*Business outcomes (errors, warnings, success, and status):*
- **BR-008-ES-01** - Other Dealer field empty while Dealer Comparison type is selected - *"Other Dealer Can not be Empty"*; the form blocks progress and the user must select a comparison dealer.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Other Dealer Description (`P_DLR_B`) | Conditional - when Dealer Comparison report type selected | Display/Entry | N/A | Other Dealer lookup (LOV_OTH_DLR) | Dealer name | Dealer Comparison report type selected | Must not be empty when Dealer Comparison type is active | *"Other Dealer Can not be Empty"* |
| Report Type (`P_REPORT_TYPE`) | Read-only display | List (Char) | 10 | N/A | Report type values | N/A | Referenced to determine whether Other Dealer validation applies | N/A |

---

---

#### Requirement ID: BR-009

**Requirement Title:** FSC Report Generation and Submission

**Business Description:**
When the user clicks the Submit Report button, the system validates the selected reporting period and dealer parameters, builds the report's date range and parameter set, and generates the FSC (Fixed Service Campaign) Dealer report as a PDF file that is opened in a new browser window. Depending on the report type selected (Dealer Comparison or Summary), the system directs the request to the appropriate report module. Several business rules are enforced before the report runs: the report cannot cover the current month for Summary type, cannot cover a future month for any type, and requires a dealer (and an other dealer for comparisons) to be selected.

**Actors:** Dealer User

**Preconditions:**
- The month and year for the report period have been selected.
- A report type (Dealer Comparison or Summary) has been selected.
- A dealer has been selected.

**Main Flow:**

**Step 1 - Report date range calculated**
The system constructs the first day of the selected month and year as the report start date, then calculates the first day and the day after the last day of that month to determine the full reporting period, storing these as the From Date and To Date parameters for the report.

**Step 2 - Current-month restriction checked for Summary type**
The system checks today's date against the selected month and year. If the selected month and year match the current calendar month and the Summary report type is selected, the system blocks the submission with an error, because Summary reports cannot be produced for the month in progress.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-002](#SP-002--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the error *"FSC Summary report can not be generated for current month!"* and blocks the submission.
    * **Step 1** - Determine the appropriate alert type: if the title passed is 'Error', select the error alert; otherwise select the information alert.
    * **Step 2** - Set the selected alert's title and message text to the values provided by the caller.
    * **Step 3** - Display the alert to the user.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Summary report cannot cover current month | `V_MONTH = :P_MONTH AND :P_YEAR = V_YEAR AND :CB_BLK.P_REPORT_TYPE = 'S'` - WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT | When the user clicks Submit Report | Prevents generation of a Summary report for a month that is still in progress, as the data is not yet complete | *"FSC Summary report can not be generated for current month!"*; submission is blocked and the user is directed back to the month field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-009-ES-01** - Summary report requested for the current calendar month - *"FSC Summary report can not be generated for current month!"*; submission blocked.

**Step 3 - Future-month restriction checked**
The system checks whether the selected reporting period falls in the future. Two checks are applied: first, whether the calculated From Date's month is later than the current month within the same year; second, whether the selected month is later than the current month and the year is later than the current year. If either condition is true, the system blocks the submission.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-002](#SP-002--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the error *"FSC  report can not be generated for future month!"* and blocks the submission.
    * **Step 1** - Determine the appropriate alert type: if the title passed is 'Error', select the error alert; otherwise select the information alert.
    * **Step 2** - Set the selected alert's title and message text to the values provided by the caller.
    * **Step 3** - Display the alert to the user.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Report cannot be generated for a future month (same-year check) | `TO_CHAR(:P_FROM_DATE,'MM') > V_MONTH AND :P_YEAR = V_YEAR` - WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT | When the user clicks Submit Report | Prevents requesting a report for a month that has not yet occurred within the current year | *"FSC  report can not be generated for future month!"*; submission blocked |
| Report cannot be generated for a future month (cross-year check) | `:P_MONTH > V_MONTH AND :P_YEAR > V_YEAR` - WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT | When the user clicks Submit Report | Prevents requesting a report for a future month in a future year | *"FSC  report can not be generated for future month!"*; submission blocked |

*Business outcomes (errors, warnings, success, and status):*
- **BR-009-ES-02** - Report period falls in the future - *"FSC  report can not be generated for future month!"*; submission blocked.

**Step 4 - Dealer presence confirmed**
Before submitting the report, the system confirms that the Dealer field is not empty. If it is empty, the submission is blocked.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-002](#SP-002--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the error *"Dealer Can Not be Empty"* and blocks the submission.
    * **Step 1** - Determine the appropriate alert type: if the title passed is 'Error', select the error alert; otherwise select the information alert.
    * **Step 2** - Set the selected alert's title and message text to the values provided by the caller.
    * **Step 3** - Display the alert to the user.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Dealer must not be empty at submission | `:CB_BLK.P_DLR IS NULL` - WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT | When the user clicks Submit Report | Ensures a dealer is always specified before a report is generated | *"Dealer Can Not be Empty"*; submission blocked |

*Business outcomes (errors, warnings, success, and status):*
- **BR-009-ES-03** - Dealer field empty at submission - *"Dealer Can Not be Empty"*; submission blocked.

**Step 5 - Other Dealer presence confirmed for Dealer Comparison type**
If the Dealer Comparison report type is selected, the system confirms that the Other Dealer field is not empty. If it is empty, the submission is blocked.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-002](#SP-002--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the error *"Other Dealer Can not be Empty"* and blocks the submission.
    * **Step 1** - Determine the appropriate alert type: if the title passed is 'Error', select the error alert; otherwise select the information alert.
    * **Step 2** - Set the selected alert's title and message text to the values provided by the caller.
    * **Step 3** - Display the alert to the user.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Other Dealer mandatory for Dealer Comparison at submission | `:CB_BLK.P_REPORT_TYPE = 'D' AND :CB_BLK.P_DLR_B IS NULL` - WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT | When the user clicks Submit Report with Dealer Comparison type selected | Ensures a comparison dealer is specified when the Dealer Comparison report type is requested | *"Other Dealer Can not be Empty"*; submission blocked |

*Business outcomes (errors, warnings, success, and status):*
- **BR-009-ES-04** - Other Dealer empty for Dealer Comparison type - *"Other Dealer Can not be Empty"*; submission blocked.

**Step 6 - Month-year display value built and report identity assigned**
The system constructs a formatted month-year string combining the selected month and year, and assigns the correct report application identity based on the report type: the Dealer Comparison type uses the standard FSC dealer report identity; the Summary type uses the FSC summary report identity. Both the global session application identifier and the on-screen application identifier are updated accordingly, and the report name is set to match.

**Step 7 - Report parameters assembled**
The system calls the parameter-building procedure to compile all required report parameters into a single string for the report engine.

*Procedures called:*
- **PR_PASS_PARAM** ([SP-001](#SP-001--PR_PASS_PARAM)) - PR_PASS_PARAM - queries the report parameter configuration for the current application and principal (company/brand), then builds the complete parameter string for the report engine by appending the principal group, region, date range, other dealer (if applicable), and principal (company/brand) values.
    * **Step 1** - Look up the report parameter definitions for the current application and principal (company/brand) from the report parameter configuration, ordered by sequence number.
    * **Step 2** - For each parameter definition found, append the primary dealer's parent group to the parameter string.
    * **Step 3** - Append the region (for/area) code to the parameter string.
    * **Step 4** - Append the report start date to the parameter string.
    * **Step 5** - Append the report end date to the parameter string.
    * **Step 6** - Append the other dealer's parent group (for comparison reports) to the parameter string.
    * **Step 7** - Append the current principal (company/brand) identifier to the parameter string.

**Step 8 - Report generated as PDF and opened in browser**
The system locates the report object, configures it with the PDF output format, sets the output destination to a file in the reports printer directory (named using the current user's identifier combined with a timestamp), applies the assembled parameter string, sets the configured report server, and runs the report. The generated PDF file is then opened in a new browser window for the user to view.

**Alternative Flows:**
- **BR-009-AF-01** - (from Step 8) An exception occurs during report generation - the exception is caught silently (`WHEN OTHERS THEN NULL`) and no error is displayed to the user; the browser open step is not reached.

#### Business Scenarios - How the report submission differs by report type

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Dealer Comparison report type ('D')** | Application identifier set to 'vr_fsc_dlr'; current-month restriction does not apply; Other Dealer parameter is included in the report parameter string. |
| **Summary report type ('S')** | Application identifier set to 'vr_fsc_dlr_sum'; current-month restriction blocks submission; Other Dealer parameter is still appended but the Other Dealer field is disabled at the screen level. |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Month (`P_MONTH`) | Mandatory | List | 10 | N/A | Month abbreviations | Form displayed | Used to construct the report period start date | N/A |
| Year (`P_YEAR`) | Mandatory | List (Number) | 10 | N/A | Year values | Form displayed | Used to construct the report period start date | N/A |
| Report From Date (`P_FROM_DATE`) | Auto-populated | Date | DD/MM/RRRR | N/A | First day of selected month | Month and year selected | Calculated; read-only | N/A |
| Report To Date (`P_TO_DATE`) | Auto-populated | Date | DD/MM/RRRR | N/A | Day after last day of selected month | Month and year selected | Calculated; read-only | N/A |
| Report Type (`P_REPORT_TYPE`) | Mandatory | List (Char) | 10 | N/A | Dealer Comparison / Summary | Form displayed | Determines which report module is used and which validations apply | *"FSC Summary report can not be generated for current month!"* if current month + Summary; *"FSC  report can not be generated for future month!"* if future month |
| Dealer Description (`P_DLR`) | Mandatory | Display/Entry | N/A | Dealer details lookup (DEALER_DETAIL) | Dealer name | Form displayed | Must not be empty at submission | *"Dealer Can Not be Empty"* |
| Other Dealer Description (`P_DLR_B`) | Conditional - when Dealer Comparison selected | Display/Entry | N/A | Other Dealer lookup (LOV_OTH_DLR) | Dealer name | Dealer Comparison type selected | Must not be empty when Dealer Comparison type is active at submission | *"Other Dealer Can not be Empty"* |
| Month-Year Display (`P_MONTH_YR`) | Auto-populated | Text | N/A | N/A | Formatted month-year string | Month and year selected | Auto-set at submission time | N/A |
| Application Identifier (`APP_ID`) | Auto-populated | Display | 200 | N/A | 'vr_fsc_dlr' or 'vr_fsc_dlr_sum' | Report type selected | Set automatically based on report type | N/A |
| Report Name (`REPORT_NAME`) | Auto-populated | Display | 2000 | N/A | Matches Application Identifier | Report type selected | Set automatically based on report type | N/A |
| Report Server (`REP_SERVER`) | Auto-populated | Display | N/A | Report configuration (EH_REPORTS) | Server name | Form initialised/reset | Read from configuration at form load | N/A |

---

---

#### Requirement ID: BR-010

**Requirement Title:** Centralised Form Error Handling

**Business Description:**
When any Oracle Forms error is raised on this form, the system intercepts it and provides a clear, business-friendly error message to the user rather than a raw technical error code. Different categories of error are handled distinctly: invalid date input errors, invalid date format errors, non-numeric value errors, field-level constraint errors, and database-level errors each receive their own plain-language message. Record-locking conflicts display a specific instruction to the user. If the error originates from a database operation, the system displays the actual database error message. Certain informational message codes are silently suppressed. The trigger aborts after displaying the error so the user stays on the form to correct the problem.

**Actors:** Dealer User

**Preconditions:**
- A form error has been raised by any trigger or operation on the VR_FSC_DLR form.

**Main Flow:**

**Step 1 - Invalid date value error intercepted**
If the form raises error code 50004 (entered date is not a valid date), the system displays the message *"Entered Date is not valid Date"* and aborts the trigger, keeping the user on the form.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-002](#SP-002--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays an error alert with the message *"Entered Date is not valid Date"* and the title "Error".
    * **Step 1** - Determine the appropriate alert type: if the title passed is 'Error', select the error alert; otherwise select the information alert.
    * **Step 2** - Set the selected alert's title and message text to the values provided by the caller.
    * **Step 3** - Display the alert to the user.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Error code 50004 (invalid date) intercepted | `errnum IN (50004)` - ON-ERROR trigger at Form level | When any date field validation raises error code 50004 | Replaces a raw form error with a plain-language message about an invalid date value | *"Entered Date is not valid Date"*; trigger aborted; user stays on the form |

*Business outcomes (errors, warnings, success, and status):*
- **BR-010-ES-01** - Invalid date value error - *"Entered Date is not valid Date"*; form error intercepted and trigger aborted.

**Step 2 - Invalid date format error intercepted**
If the form raises error code 50025 or 50026 (date entered in the wrong format), the system displays the message *"Enter the Date in the proper format (DD-MM-YYYY)"* and aborts the trigger.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-002](#SP-002--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays an error alert with the message *"Enter the Date in the proper format (DD-MM-YYYY)"*.
    * **Step 1** - Determine the appropriate alert type: if the title passed is 'Error', select the error alert; otherwise select the information alert.
    * **Step 2** - Set the selected alert's title and message text to the values provided by the caller.
    * **Step 3** - Display the alert to the user.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Error codes 50025/50026 (date format) intercepted | `errnum IN (50025, 50026)` - ON-ERROR trigger at Form level | When a date field raises a format error | Informs the user of the required date input format | *"Enter the Date in the proper format (DD-MM-YYYY)"*; trigger aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-010-ES-02** - Date format error - *"Enter the Date in the proper format (DD-MM-YYYY)"*; trigger aborted.

**Step 3 - Non-numeric value error intercepted**
If the form raises error code 40209 or 50016 (characters or special characters entered in a numeric field), the system displays the message *"Characters/Special Characters are not allowed here, enter the numeric value"* and aborts the trigger.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-002](#SP-002--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays an error alert with the message *"Characters/Special Characters are not allowed here, enter the numeric value"*.
    * **Step 1** - Determine the appropriate alert type: if the title passed is 'Error', select the error alert; otherwise select the information alert.
    * **Step 2** - Set the selected alert's title and message text to the values provided by the caller.
    * **Step 3** - Display the alert to the user.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Error codes 40209/50016 (non-numeric input) intercepted | `errnum IN (40209, 50016)` - ON-ERROR trigger at Form level | When a numeric field receives non-numeric input | Informs the user that only numeric values are allowed in the affected field | *"Characters/Special Characters are not allowed here, enter the numeric value"*; trigger aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-010-ES-03** - Non-numeric input in a numeric field - *"Characters/Special Characters are not allowed here, enter the numeric value"*; trigger aborted.

**Step 4 - Field constraint error intercepted**
If the form raises error code 40207 (a field-level constraint violation), the system displays the Forms-generated error text for that code and aborts the trigger.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-002](#SP-002--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays an error alert with the Forms error text (`errtxt`) and the title "Error".
    * **Step 1** - Determine the appropriate alert type: if the title passed is 'Error', select the error alert; otherwise select the information alert.
    * **Step 2** - Set the selected alert's title and message text to the values provided by the caller.
    * **Step 3** - Display the alert to the user.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Error code 40207 (field constraint) intercepted | `errnum IN (40207)` - ON-ERROR trigger at Form level | When a field-level constraint error is raised | Surfaces the Forms-generated error text to the user in the standard error alert | Error text displayed; trigger aborted |

**Step 5 - Database referential integrity violation intercepted**
If a database operation fails with referential integrity error code -02292 (a child record exists), the system raises the mapped error message through the GENERAL.RAISE_ERROR routine and aborts the trigger.

*Procedures called:*
- **GENERAL.RAISE_ERROR** ([SP-003](#SP-003--GENERAL.RAISE_ERROR)) - GENERAL.RAISE_ERROR - maps the error code 'E0088' to its registered message text and displays it as an error alert, then raises a form trigger failure to abort the current operation.
    * **Step 1** - Combine the message code passed ('E0088') with any resolved message text to build the full display text.
    * **Step 2** - Determine the severity type for the message code; if it indicates an error, select the Error title; if a note, use the Note title; if a caution, use the Caution title.
    * **Step 3** - Display the error alert to the user with the constructed message.
    * **Step 4** - If the severity is an error, raise a form trigger failure to abort the current operation; for notes and cautions, continue without aborting.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Database referential integrity violation (-02292) intercepted | `Derrnum = -02292` - ON-ERROR trigger at Form level, calls GENERAL.RAISE_ERROR([SP-003](#SP-003--GENERAL.RAISE_ERROR)) with code 'E0088' | When a database operation is blocked due to a child record existing | Prevents orphan-record violations and informs the user via the registered E0088 message | Error message E0088 displayed; trigger aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-010-ES-04** - Database referential integrity violation - error message mapped from code 'E0088' is displayed; trigger aborted.

**Step 6 - Record locking conflict intercepted**
If the form raises any of the record-locking error codes (40654, 40655, 40656, 40657, 40659), the system displays the message *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*, rolls back any pending changes, and aborts the trigger.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-002](#SP-002--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the locking conflict message.
    * **Step 1** - Determine the appropriate alert type: if the title passed is 'Error', select the error alert; otherwise select the information alert.
    * **Step 2** - Set the selected alert's title and message text to the values provided by the caller.
    * **Step 3** - Display the alert to the user.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Record locking conflict intercepted | `ERROR_CODE IN (40654, 40655, 40656, 40657, 40659)` - ON-ERROR trigger at Form level | When a record-locking conflict is detected | Informs the user that another user has updated the record and instructs them to re-query before making changes | *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*; pending changes rolled back; trigger aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-010-ES-05** - Record updated by another user - *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*; rollback performed; trigger aborted.

**Step 7 - General database error intercepted**
If any other database error is present (SQL code not zero), the system displays the database error message text (`SQLERRM`), rolls back any pending changes, and aborts the trigger.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-002](#SP-002--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the database error message text.
    * **Step 1** - Determine the appropriate alert type: if the title passed is 'Error', select the error alert; otherwise select the information alert.
    * **Step 2** - Set the selected alert's title and message text to the values provided by the caller.
    * **Step 3** - Display the alert to the user.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| General database error intercepted | `sqlcode <> 0` - ON-ERROR trigger at Form level | When any unhandled database error is raised | Surfaces the actual database error text to the user rather than a cryptic system code | Database error text (SQLERRM) displayed; rollback performed; trigger aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-010-ES-06** - General database error - the database-generated error text is displayed; rollback performed; trigger aborted.

**Step 8 - Specific informational codes suppressed**
If the error code is 40401 or 40405 (standard navigation/no-record messages), the system takes no action (null handling), effectively suppressing these codes from being displayed to the user.

---

---

#### Requirement ID: BR-011

**Requirement Title:** Centralised Form Message Handling

**Business Description:**
When certain system-level message codes are raised on this form, the system intercepts and reformats them rather than allowing the default Oracle Forms message to reach the user. Specifically, messages corresponding to non-numeric input (code 40209) and field constraint violations (code 40207) are reformatted with the error type prefix, code, and description, and displayed as an error alert. This ensures the user sees a consistent, context-rich message format and the form halts processing appropriately.

**Actors:** Dealer User

**Preconditions:**
- A form message has been raised by any trigger or operation on the VR_FSC_DLR form.

**Main Flow:**

**Step 1 - System message codes 40209 and 40207 reformatted**
When the form raises message code 40209 or 40207, the system constructs a formatted message string combining the error type, error code number, and the original error text (in the format `[error type]-[error code]: [error text]`), displays it as an error alert, and aborts the trigger to keep the user on the form.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-002](#SP-002--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays an error alert with the reformatted message string (error type + code + text combined).
    * **Step 1** - Determine the appropriate alert type: if the title passed is 'Error', select the error alert; otherwise select the information alert.
    * **Step 2** - Set the selected alert's title and message text to the values provided by the caller.
    * **Step 3** - Display the alert to the user.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Message codes 40209/40207 reformatted | `errnum IN (40209, 40207)` - ON-MESSAGE trigger at Form level | When the form raises message code 40209 or 40207 | Ensures the user sees a formatted, informative message rather than a raw system code | Formatted message (error type + code + text) displayed as an error alert; trigger aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-011-ES-01** - System message codes 40209 or 40207 raised - formatted message combining error type, code, and text is displayed; trigger aborted.

---

---

#### Requirement ID: BR-012

**Requirement Title:** Form Exit with Database Session Cleanup

**Business Description:**
When the user exits the form using the designated exit action, the system clears the database session's client information and module registration before closing the form. This ensures that after the user leaves, the database session no longer shows the form module as active, which supports accurate database session monitoring and resource management.

**Actors:** Dealer User

**Preconditions:**
- The user is on the FSC Dealer report form and initiates the exit action.

**Main Flow:**

**Step 1 - Database session information cleared**
The system clears the client information recorded against the current database session (set to null) and clears both the module name and action name from the database session's module tracking (set to empty strings).

**Step 2 - Form closed without saving**
The system closes the form immediately, discarding any unsaved changes without prompting the user for confirmation.

---

---

#### Requirement ID: BR-013

**Requirement Title:** Save Action Override (INACTIVE - does not execute)

**Business Description:**
A save action override was previously defined on this form that would replace the standard save behaviour with a no-operation. This override is currently disabled and has no effect; the form falls back to standard save behaviour.

**Actors:** Dealer User

**Preconditions:**
- N/A - this requirement does not execute.

**Main Flow:**

**Step 1 - Save action intercepted with no operation (COMMENTED OUT / INACTIVE - does not execute)**
The KEY-COMMIT trigger at the form level contains only a `NULL;` statement, meaning the standard save/commit action is effectively suppressed without any replacement logic. This trigger is marked inactive and does not execute.

---

---

#### Requirement ID: BR-014

**Requirement Title:** Reason Field List-Change Downstream Reset (INACTIVE - does not execute)

**Business Description:**
A field-change handler was previously defined to reset several related fields when the Reason selection changed. This handler is currently fully commented out and contains only a no-operation statement; it does not execute.

**Actors:** Dealer User

**Preconditions:**
- N/A - this requirement does not execute.

**Main Flow:**

**Step 1 - Reason list change triggers downstream reset (COMMENTED OUT / INACTIVE - does not execute)**
The WHEN-LIST-CHANGED trigger on the Reason field (`CB_BLK.P_REASON`) was originally designed to clear related fields (for-code description, dealer code, location code, program, session, agency code, dealer, location, and parent group) when the reason selection changed. The entire body of this trigger is commented out and replaced with `null;`. It does not execute.

---

---

#### Requirement ID: BR-015

**Requirement Title:** Test Drive Main Screen Validation Procedure (INACTIVE - does not execute)

**Business Description:**
A validation procedure named VALIDATE_CN_MAIN was previously included in this form as dead code. It contains no executable logic (only a `NULL;` statement) and does not execute. Its commented-out body contains validations for a test-drive workflow (plate number, model year, test drive dates, times, location, sales consultant, and odometer readings), but this logic is fully commented out and is not part of the current form's functionality.

**Actors:** N/A - this requirement does not execute.

**Preconditions:**
- N/A - this requirement does not execute.

**Main Flow:**

**Step 1 - Test drive main screen validation (COMMENTED OUT / INACTIVE - does not execute)**
The form-level program unit VALIDATE_CN_MAIN is inactive. It contains only `NULL;` as its executable body. The commented-out portion originally covered mandatory field checks and date/time range validations for a test drive process. This code does not execute.

---

---

#### Requirement ID: BR-016

**Requirement Title:** Pre-Delete Referential Integrity Check Procedure (INACTIVE - does not execute)

**Business Description:**
A pre-delete check procedure named CHECK_BEFORE_DELETE was previously included in this form as dead code. It contains no executable logic (only `NULL;`) and does not execute. Its commented-out body originally checked for the existence of child records in an enquiry table before permitting deletion of a zone master record.

**Actors:** N/A - this requirement does not execute.

**Preconditions:**
- N/A - this requirement does not execute.

**Main Flow:**

**Step 1 - Pre-delete child record existence check (COMMENTED OUT / INACTIVE - does not execute)**
The form-level program unit CHECK_BEFORE_DELETE is inactive. It contains only `NULL;` as its executable body. The commented-out portion originally counted child records in the enquiry table for the current zone code and blocked deletion if any existed. This code does not execute.

---

---

#### Requirement ID: BR-017

**Requirement Title:** Dynamic List Population Utility Procedure (ACTIVE - no callers in this form)

**Business Description:**
A general-purpose procedure named L_POP_LIST_ITEM is defined in this form to dynamically build and populate list item record groups from a SQL query at runtime. This procedure is active code, but no trigger or other program unit in this form calls it. It does not execute in any current business flow.

**Actors:** N/A - not called by any trigger in this form.

**Preconditions:**
- N/A - this procedure is not invoked in any current flow.

**Main Flow:**

**Step 1 - Dynamic record group created and populated for a list item**
When called (not currently called from any trigger), this procedure accepts a record group name and a SQL query. It checks whether the named record group already exists and deletes it if so, or creates it fresh from the provided query. It then populates the record group. This logic is available but unused in the current form.

---

---

#### Requirement ID: BR-018

**Requirement Title:** Error Code Table Specification Package (ACTIVE - declaration only, no callers)

**Business Description:**
A package specification named POPULATE_ERRORS is defined in this form. It declares a PL/SQL table variable for holding error code data. The package contains no executable logic of its own and is not called by any trigger or program unit in this form; it serves as a declaration artefact only.

**Actors:** N/A - not invoked in any current flow.

**Preconditions:**
- N/A - this package declaration does not execute.

**Main Flow:**

**Step 1 - Error code table type declared (declaration only - does not execute)**
The form-level package POPULATE_ERRORS declares a single variable (`v_tab`) of a PL/SQL table type (`pk_plsql_table.code_tab`). No procedures or functions are defined within this package body and no caller invokes this package. It does not perform any business operation.

---

---

---

#### Requirement ID: BR-019

**Requirement Title:** Toolbar Action Controls - Save, Cancel, Insert, and Delete

**Business Description:**
The form provides four toolbar action buttons that govern how the user can interact with form data: Save, Cancel, Insert, and Delete. The Save button commits any pending changes and clears the form for a fresh entry. The Cancel button clears the form after confirming with the user if unsaved changes exist. The Insert button is explicitly blocked on this form, because new records cannot be created here. The Delete button allows removal of a record after the user confirms the action, but only when the cursor is on the correct data block.

**Actors:** Dealer User

**Preconditions:**
- The form is open and the relevant toolbar button is enabled and pressed by the user.

**Main Flow:**

**Step 1 - Save button pressed: pending changes committed and form cleared**
When the user presses the Save button (and the button is enabled), the system commits all pending changes to the database and then clears the form, returning it to a clean state ready for a new report request.

**Step 2 - Cancel button pressed: unsaved-data confirmation and form clear**
When the user presses the Cancel button (and the button is enabled), the system checks whether the form has any unsaved changes. If unsaved changes are present, the system asks the user to confirm abandonment before clearing the form. If the user confirms, or if there are no unsaved changes, the form is cleared. The system also resets the contract month display to the previous calendar month after clearing.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Unsaved changes detected on Cancel | `:system.form_status = 'CHANGED'` check in FT_CANCEL trigger | When the user presses the Cancel button with pending changes | Prevents accidental loss of entered data by requiring the user to confirm before discarding changes | *"Entered data will not be Saved"* confirmation shown; form is only cleared if the user confirms (response = 1) |

*Business outcomes (errors, warnings, success, and status):*
- **BR-019-WS-01** - Cancel pressed with unsaved changes - *"Entered data will not be Saved"* confirmation displayed; user must confirm before the form is cleared.

**Step 3 - Insert button pressed: insert operation blocked**
When the user presses the Insert button (and the button is enabled), the system displays an error message and takes no further action. New record insertion is not supported through this form.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-002](#SP-002--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays an error alert with the message *"This Operation Cannot be performed Here"* and the title "Error".
    * **Step 1** - Determine the appropriate alert type: if the title passed is 'Error', select the error alert; otherwise select the information alert.
    * **Step 2** - Set the selected alert's title and message text to the values provided by the caller.
    * **Step 3** - Display the alert to the user.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Insert operation not permitted on this form | Insert button enabled check in FT_INSERT trigger | When the user presses the Insert button | Prevents users from attempting to create new records through this report parameter form, which does not support record creation | *"This Operation Cannot be performed Here"*; no insert action is taken |

*Business outcomes (errors, warnings, success, and status):*
- **BR-019-ES-01** - Insert button pressed - *"This Operation Cannot be performed Here"*; insert is blocked.

**Step 4 - Delete button pressed: delete confirmation and record removal**
When the user presses the Delete button and the button is enabled and the cursor is on the data entry block, the system temporarily suspends form-level validation and asks the user to confirm the deletion. If the user confirms, the current record is deleted. Form-level validation is then re-enabled regardless of the user's choice.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Delete confirmation required before record is removed | `GENERAL.ASK_CONFIRM` call with *"Are you sure to Delete?"* in FT_DEL trigger | When the user presses the Delete button with the cursor on the data block | Prevents accidental deletion of records by requiring explicit user confirmation | If the user does not confirm (response != 1), the record is not deleted and the form remains unchanged |

*Business outcomes (errors, warnings, success, and status):*
- **BR-019-WS-02** - Delete button pressed - *"Are you sure to Delete?"* confirmation shown; record is deleted only if the user confirms.

---

## 5. Business Rules Catalogue

Catalogue of the discrete business rules enforced by the form's code.

| Rule ID | Rule Name | Rule Type | Business Requirement ID | Condition | Action | Business Impact |
| ------- | --------- | --------- | ----------------------- | --------- | ------ | --------------- |
| BRC-001 | Reason Field Is Mandatory | Validation | BR-006 | The Reason field is left empty when the user moves away from it | Block progress and display *"Main Reason can not be empty"* | Ensures every report request is associated with a documented reason |
| BRC-002 | Dealer Field Is Mandatory on Navigation | Validation | BR-007 | The Dealer field is left empty when the user moves away from it | Block progress and display *"Dealer Can Not be Empty"* | Ensures the report is always associated with a specific dealership |
| BRC-003 | Other Dealer Mandatory for Dealer Comparison | Validation | BR-008, BR-009 | The Dealer Comparison report type is selected and the Other Dealer field is left empty | Block progress and display *"Other Dealer Can not be Empty"* | Ensures that a comparison dealer is always specified for comparison reports |
| BRC-004 | Summary Report Cannot Cover Current Month | Constraint | BR-009 | The Summary report type is selected and the selected month and year match the current calendar month | Block submission and display *"FSC Summary report can not be generated for current month!"*; move cursor to month field | Prevents generation of incomplete data for an in-progress month |
| BRC-005 | Report Cannot Cover a Future Month (Same Year) | Constraint | BR-009 | The calculated report start date's month is later than the current month within the same year | Block submission and display *"FSC  report can not be generated for future month!"* | Prevents requesting data for a period that has not yet occurred |
| BRC-006 | Report Cannot Cover a Future Month (Cross Year) | Constraint | BR-009 | The selected month is later than the current month and the selected year is later than the current year | Block submission and display *"FSC  report can not be generated for future month!"* | Prevents requesting data for a future year and month combination |
| BRC-007 | Dealer Field Is Mandatory at Submission | Validation | BR-009 | The Dealer field is empty when the Submit Report button is clicked | Block submission and display *"Dealer Can Not be Empty"* | Ensures a dealer is always specified before a report is generated |
| BRC-008 | Report Type Determines Other Dealer Field Availability | Derivation | BR-003 | The Report Type selection is changed to Dealer Comparison or to Summary | Enable and mark the Other Dealer field as mandatory when Dealer Comparison is selected; disable and clear it when Summary is selected | Ensures the correct fields are active and required based on the report type chosen |
| BRC-009 | Output Format Determines File Name Field Availability | Derivation | BR-004, BR-005 | The Output Format selection is changed, or focus moves to the File Name field | Enable the File Name field when Excel is selected; disable and clear it for all other formats | Prevents irrelevant file name input for non-Excel output formats |
| BRC-010 | Invalid Date Value Must Be Reported | Validation | BR-010 | The form raises error code 50004 (date value is not valid) | Intercept and display *"Entered Date is not valid Date"*; abort the trigger | Provides a plain-language explanation for an invalid date value instead of a raw system code |
| BRC-011 | Date Must Be in DD-MM-YYYY Format | Validation | BR-010 | The form raises error codes 50025 or 50026 (date format error) | Intercept and display *"Enter the Date in the proper format (DD-MM-YYYY)"*; abort the trigger | Guides the user to enter dates in the required format |
| BRC-012 | Numeric Fields Do Not Accept Non-Numeric Input | Validation | BR-010 | The form raises error code 40209 or 50016 (non-numeric input in a numeric field) | Intercept and display *"Characters/Special Characters are not allowed here, enter the numeric value"*; abort the trigger | Prevents invalid character input in numeric fields |
| BRC-013 | Record Locking Conflict Requires Re-query | Constraint | BR-010 | The form raises one of the record-locking error codes (40654, 40655, 40656, 40657, or 40659) | Display *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*; roll back pending changes; abort the trigger | Prevents data loss from concurrent updates and directs the user to re-query |
| BRC-014 | Database Referential Integrity Violation Is Reported | Constraint | BR-010 | A database operation fails with referential integrity error code -02292 | Display the registered error message for code E0088; abort the trigger | Informs the user that child records prevent the requested operation |
| BRC-015 | General Database Errors Are Surfaced to the User | Validation | BR-010 | The SQL error code is not zero after any database operation | Display the database error message text; roll back pending changes; abort the trigger | Ensures database errors are visible to the user rather than silently ignored |
| BRC-016 | Report Period Date Range Is Derived from Month and Year | Derivation | BR-009 | The Submit Report button is clicked | Calculate the first day of the selected month and the day after the last day as the From Date and To Date | Ensures the report covers precisely one complete calendar month |
| BRC-017 | Report Identity Is Assigned Based on Report Type | Derivation | BR-009 | The Submit Report button is clicked with a valid report type selection | Set application identifier to 'vr_fsc_dlr' for Dealer Comparison type or 'vr_fsc_dlr_sum' for Summary type | Routes the report request to the correct report module for the selected type |
| BRC-018 | Report Server Is Resolved from Configuration on Form Reset | Derivation | BR-002 | The form is reset | Query the report server configuration for the current application and principal; if found and non-blank, read the server name from the configuration text file; otherwise use the session default | Ensures the report runs on the correct server for the dealership's brand context |

**Total Business Rules Identified: 18**

---

## 6. Data Requirements

*This section describes the data entities referenced by the FSC Dealer Report selection form, the report parameters captured on screen, the reference data used for lookups, and the lifecycle of data within the form.*

### 6.1 Business Entities and Relationships

*The FSC Dealer Report form does not persist records to a form-owned base table. It reads configuration data from the report configuration register and the report parameter register, and presents report parameters for the user to select before generating a report.*

#### Report Configuration - EH_REPORTS

The report configuration table stores the mapping between an application identifier and a principal (company/brand) combination, with the corresponding report server name. The form reads this table when the user resets the form to determine which report server should be used to generate the report for the current dealership's brand context.

#### Report Parameter Configuration - ED_REPORTS

The report parameter configuration table stores the ordered list of report parameters for each application and principal combination. The form reads this table at report submission time to determine which parameter values to pass to the report engine.

#### Entity Relationships

The FSC Dealer Report form does not declare a master-detail relationship between its blocks. EH_REPORTS and ED_REPORTS are both looked up independently, each keyed on the current application identifier and principal (company/brand code). No parent-child join between these two tables is evidenced in the form's logic.

```
EH_REPORTS (report server config - keyed by app_id + principal)
ED_REPORTS  (report parameter config - keyed by app_id + principal)
```

### 6.2 Data Capture Requirements

*The form captures report selection parameters from the user; none are persisted to a database table. Parameters are passed to the report engine at submission time. Several fields are auto-populated from the user's session context or derived from other field values.*

#### Report Selection Parameters (Dealer User - report request)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Month (`P_MONTH`) | Yes | The calendar month for the reporting period, selected from a list | Required to calculate the report date range; must be selected before submission |
| Year (`P_YEAR`) | Yes | The calendar year for the reporting period, selected from a list | Required to calculate the report date range; must be selected before submission |
| Report Type (`P_REPORT_TYPE`) | Yes | Selects whether the report is a Dealer Comparison or a Summary report | Determines which report module is invoked and which additional fields apply; drives Other Dealer field availability |
| Dealer Description (`P_DLR`) | Yes | The name of the primary dealer for the report, selected from the dealer lookup | Must not be empty on field exit or at submission; selection populates related parent group and region fields |
| Other Dealer Description (`P_DLR_B`) | Conditional | The name of the comparison dealer, required when Dealer Comparison type is selected | Must not be empty when Dealer Comparison type is active; field is disabled for Summary type |
| Reason (`P_REASON`) | Yes | The reason for generating the report, selected from a list | Must not be empty when the user leaves the field |
| Format (`P_DESFORMAT`) | Yes | The output format for the generated report (e.g. PDF, Excel) | Required field; controls whether the File Name field is available |
| File Name (`FILENAME`) | Conditional | A file name for the output when Excel format is selected | Only editable and required when Excel output format is active; disabled and cleared for other formats |

#### Auto-Populated and Derived Fields (System - on form reset or submission)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Report Description (`REPORT_DESC`) | Auto-Populated | Display description of the current report, restored from session on form reset | Read-only; sourced from session global at form reset |
| Report Name (`REPORT_NAME`) | Auto-Populated | Internal report identifier, set based on report type at submission | Read-only; set to 'vr_fsc_dlr' (Dealer Comparison) or 'vr_fsc_dlr_sum' (Summary) |
| Application Identifier (`APP_ID`) | Auto-Populated | Application identifier used to route the report request | Read-only; set based on report type at submission |
| Report Server (`REP_SERVER`) | Auto-Populated | The report server name used to run the report | Resolved at form reset from EH_REPORTS configuration; falls back to session default on any error |
| Report From Date (`P_FROM_DATE`) | Auto-Populated | The first day of the selected reporting month | Calculated at submission; display only (format DD/MM/RRRR) |
| Report To Date (`P_TO_DATE`) | Auto-Populated | The day after the last day of the selected reporting month | Calculated at submission; display only (format DD/MM/RRRR) |
| Month-Year Display (`P_MONTH_YR`) | Auto-Populated | Formatted combined month-year string | Set at submission from selected month and year values |
| Copyright Declaration (`COPYRIGHT_DECLARATION`) | Auto-Populated | Copyright text retrieved from the database on form reset | Read-only; refreshed on every form reset |

#### Session and Global Parameters (System - passed from calling context)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Application Log Flag (`GLOBAL.APP_LOG`) | Auto-Populated | Flag indicating whether application performance logging is active ('Y' / other) | Read-only; sourced from session context; controls whether the performance timer is started |
| Principal (`GLOBAL.PRINCIPAL`) | Auto-Populated | The current company/brand code for the logged-in user | Read-only; used to filter dealer lookups, report configuration, and report parameters |
| User ID (`GLOBAL.USERID`) | Auto-Populated | The logged-in user's identifier | Read-only; used to filter the dealer lookup to the user's assigned dealerships |
| Default Report Server (`GLOBAL.REP_SERVER`) | Auto-Populated | The fallback report server name | Read-only; used as the report server when no specific server is configured for the app/principal |
| From Date Parameter (`PARAMETER.FROM_DATE`) | Auto-Populated | Intermediate date parameter holding the constructed start-of-month date string | Set internally during report submission; used in date range calculation |

### 6.3 Reference Data

*Lists the master and configuration data referenced by this form for lookups and report parameter resolution.*

| Reference Data | Business Purpose | Used When |
| :--- | :--- | :--- |
| Dealer Details (DEALER_DETAIL / RG_DEALER_DETAIL) | Lists the dealers assigned to the logged-in user, with their name, region, parent group, and dealer map code | When the user opens the dealer lookup to select the primary dealer for the report |
| Other Dealer Lookup (LOV_OTH_DLR / RG_OTH_DLR) | Lists all active dealers (excluding terminated and DDT-category) with their name and parent group, filtered to the current principal | When the Dealer Comparison report type is selected and the user opens the Other Dealer lookup |
| Month-Year List (MONTH_YEAR / RG_MONTH_YEAR) | Provides the list of recent calendar months (up to 6 months back from today, no earlier than July 2012) in MON-YY format for selection | When the user selects the reporting period month |
| Report Server Configuration (EH_REPORTS) | Stores the configured report server name for each application and principal combination | When the form is reset, to resolve the correct report server |
| Report Parameter Configuration (ED_REPORTS) | Stores the ordered list of parameter names and default values for each application and principal | When the Submit Report button is clicked, to build the complete report parameter string |

### 6.4 Data Lifecycle

*Describes how data is created, used, and managed within this form's evidenced behaviour.*

**Creation**

- This form does not insert new records into any database table. All data entered is held in the form's non-database block (`CB_BLK`) and passed to the report engine at submission time.
- Form parameters and report parameters are assembled in memory during the submission flow and passed directly to the report engine.

**Updates**

- No database records are updated by this form.
- Field values on screen are updated reactively: the Report Type selection updates the Other Dealer field's enabled/disabled state; the Output Format selection updates the File Name field's enabled/disabled state; the File Name field's editability is re-enforced each time the cursor enters it.

**Save and Commit**

- There is no save or commit operation in this form. The KEY-COMMIT trigger is inactive (`NULL;`), so the standard Oracle Forms save/commit action is suppressed.
- The report is generated and delivered as a PDF file when the Submit Report button is clicked; this is a read-only reporting action with no database write.

**Retention and Audit**

- The form does not write audit or timestamp data.
- The PRE-FORM trigger registers the form module name ('vr_fsc_dlr') in the database session's application information, which is available to database administrators for session monitoring. This registration is cleared when the user exits the form via the KEY-EXIT trigger.

---

### 6.5 Excel Output Columns

This form does not use Excel download. No Excel export columns were identified in the form sources.

## 7. Glossary

*Definitions of terms, abbreviations, and acronyms used throughout this document.*

The following table defines key terms, acronyms, and abbreviations used throughout this Business Requirements Document.

| Term | Definition | Aliases | Related Terms |
| :--- | :--- | :--- | :--- |
| AM_DEALER_LOC | Dealer location master table - stores dealer categorisation, principal mapping, and termination status | - | Dealer, AM_USERS |
| AM_USERS | User master table - stores user type, user ID, and dealer associations for access control | - | USERID, AM_DEALER_LOC |
| APP_ID | Application/report identifier global variable - set to `vr_fsc_dlr` (Detail) or `vr_fsc_dlr_sum` (Summary) | Report Application ID | GLOBAL, REPORT_NAME |
| APP_LOG | Application logging flag global variable - when set to `Y`, activates the performance timer at form startup | - | PRE-FORM, STOP_WATCH |
| CB_BLK | Control block - the single form block in vr_fsc_dlr; holds all report parameter input items; not bound to a database table | Control Block | Block |
| CUR_DATE | Current date global variable - used in commented validation logic for date boundary checks | - | GLOBAL |
| D2KWUTIL | Oracle Forms WebUtil extension library attached to the form; provides browser and file I/O capabilities | - | DPL, Attached Library |
| DBMS_APPLICATION_INFO | Oracle PL/SQL package used to register session context (module name, client info) at form open and clear it on exit | - | PRE-FORM, KEY-EXIT |
| Detail Report | Report type (value `D`) that compares performance data between two dealers; requires selection of both a primary dealer and a comparison dealer | D | Summary Report, P_REPORT_TYPE |
| DISP_TEXT | DPL shared library procedure that displays a message in an alert dialog using `AL_ERRINFO` (errors) or `AL_NOTE` (other) | - | RAISE_ERROR, DPL |
| DMS | Dealer Management System - the integrated software platform within which the vr_fsc_dlr form operates | - | vr_fsc_dlr |
| DPL | Shared Oracle Forms program library (`DPL.pld`) attached to the form; provides common utility procedures including DISP_TEXT, RAISE_ERROR, and CHECK_NULL | general | Attached Library, D2KWUTIL |
| DPL.olb | Oracle Object Library used as the parent object library for the form; provides inherited visual attributes, window, canvas, and toolbar objects | - | OLB |
| DUAL | Oracle built-in pseudo-table used for scalar SQL expressions (date arithmetic, copyright declaration lookup, current date queries) | - | ED_REPORTS, EH_REPORTS |
| ED_REPORTS | Report definition table - stores parameter configuration (parameter type, name, default value, data type, serial number) per report application and principal | - | EH_REPORTS, PR_PASS_PARAM |
| EH_REPORTS | Report server configuration table - stores the report server hostname per application ID and principal mapping code | - | ED_REPORTS, REP_SERVER |
| FOR Code | Franchise/outlet code identifying the dealer's franchise relationship; selected alongside the dealer from the Dealer Details LOV | FOR_CD | P_FOR, Dealer |
| FSC | Franchisee Service Contract - the business programme whose dealer performance is measured and reported by this form | Franchisee Service Contract | vr_fsc_dlr, Summary Report, Detail Report |
| GLOBAL | Oracle Forms session-level global variable prefix (`:GLOBAL.*`); persists across blocks within the same form session | - | APP_ID, PRINCIPAL, USERID |
| LOV | List of Values - a pop-up selection dialog in Oracle Forms used to look up and select valid values (dealer, month-year) | Lookup | DEALER_DETAIL, LOV_OTH_DLR |
| OLB | Oracle Object Library file (`.olb`) - provides reusable form components such as visual attributes, canvases, and windows via subclassing | Object Library | DPL.olb |
| P_DESFORMAT | Report output format field - user selects from HTMLCSS, PDF, or CHARACTER; controls FILENAME field editability | Format | P_REPORT_TYPE |
| P_DLR | Primary dealer description field in the form block; mandatory; populated via the DEALER_DETAIL LOV | Dealer Desc | P_DLR_B, DEALER_DETAIL |
| P_DLR_B | Comparison dealer description field; mandatory when report type is Detail (D); populated via LOV_OTH_DLR | Other Dealer Desc | P_DLR |
| P_FROM_DATE | Calculated first day of the selected reporting month; derived from P_MONTH and P_YEAR; read-only | From Date | P_TO_DATE, P_MONTH, P_YEAR |
| P_MONTH | Month selection list item (JAN-DEC); combined with P_YEAR to define the reporting period | - | P_YEAR, P_FROM_DATE, P_TO_DATE |
| P_MONTH_YR | Combined month-year display string derived from P_MONTH and P_YEAR (e.g. JAN-2024) | - | P_MONTH, P_YEAR |
| P_REPORT_TYPE | Report type selection list: S = Summary, D = Detail; controls visibility and mandatory status of the comparison dealer field | Report Type | Detail Report, Summary Report |
| P_TO_DATE | Calculated last day + 1 of the selected reporting month; derived from P_MONTH and P_YEAR; read-only | To Date | P_FROM_DATE |
| P_YEAR | Year selection list; combined with P_MONTH to define the reporting period | - | P_MONTH, P_FROM_DATE |
| PCK | Oracle PL/SQL Package source file (`.pck`) - no packages from the uploaded PCK files are referenced in this form | Package | DPL, PLD |
| PLD | Oracle Forms Program Library (`.pld`) - compiled shared library attached to the form; DPL.pld is the primary library providing utility routines | Program Library | DPL, D2KWUTIL |
| PR_PASS_PARAM | Form-local procedure that builds the report parameter string by querying ED_REPORTS for the active report application and principal | - | ED_REPORTS, WHEN-BUTTON-PRESSED |
| PRINCIPAL | Global variable holding the principal/company mapping code used to filter dealer lists and report server lookups | Principal Map Code | GLOBAL, AM_DEALER_LOC |
| RAISE_ERROR | DPL shared library procedure that looks up a message by error code, displays it via DISP_TEXT, and raises form failure for error-type messages | - | DISP_TEXT, ON-ERROR |
| REP_SERVER | Report server name global variable - resolved from EH_REPORTS at form open/clear; used when submitting the report job | Report Server | GLOBAL, EH_REPORTS |
| REPORT_DESC | Report description label global variable - restored to the form block on clear | - | GLOBAL, REPORT_NAME |
| REPORT_NAME | Report file name global variable - identifies the report object file; restored to block on clear | - | GLOBAL, APP_ID |
| RG_DEALER_DETAIL | Query record group providing the authorised dealer list for the primary dealer LOV; filtered by logged-in user and principal | - | DEALER_DETAIL, RG_OTH_DLR |
| RG_MONTH_YEAR | Query record group providing a rolling 12-month lookback list for the reporting period LOV | - | MONTH_YEAR |
| RG_OTH_DLR | Query record group providing the comparison dealer list for the LOV_OTH_DLR lookup; filtered by principal, excludes DDT dealers | - | LOV_OTH_DLR, RG_DEALER_DETAIL |
| STOP_WATCH | Oracle PL/SQL package used for application performance timing; invoked in the PRE-FORM trigger when APP_LOG is `Y` | - | APP_LOG, PRE-FORM |
| Summary Report | Report type (value `S`) that provides a consolidated FSC performance view for the selected dealer; cannot be generated for the current month | S | Detail Report, P_REPORT_TYPE |
| USERID | Global variable holding the logged-in user ID; used to filter authorised dealer lists and to construct the output file name | User ID | GLOBAL, AM_USERS |
| vr_fsc_dlr | Oracle Forms module name for the FSC Dealer Report parameter-selection screen; also the report application ID for Detail-type reports | VR_FSC_DLR | FSC, DMS |
| vr_fsc_dlr_sum | Report application identifier used when Summary report type is selected | - | APP_ID, vr_fsc_dlr |

---

---

## 8. Technical Inventory

*Complete inventory of Oracle Forms components including blocks, items, triggers, canvases, and global variables.*

### 8.1 Form Architecture

**Form Module Details:**

- Form Name: vr_fsc_dlr (VR_FSC_DLR)
- Form Module XML Title: MODULE2
- Oracle Forms Version: 12c (Module version 122010400)
- Parent Object Library: DPL.olb (PC_FORM property class)
- Attached Libraries: D2KWUTIL, DPL (DPL.pld program library)
- First Navigation Block: -
- Console Window: WN_MAIN - Free Service Claim Report (inherited from DPL object group; title confirmed from WN_MAIN window record)
- Compile Dependencies: Requires DPL.olb, DPL.pld, WEBUTIL.olb, menu.mmx
- Source artifacts: `vr_fsc_dlr_fmb.xml`; OLB `DPL.olb`; D2KWUTIL; DPL (DPL.pld program library)

### 8.1.1 Global Variables

| Global Variable | Data Type | Set Location | Purpose |
| :--- | :--- | :--- | :--- |
| APP_ID | Char | Trigger | Report application identifier set to `vr_fsc_dlr` or `vr_fsc_dlr_sum` based on report type |
| APP_LOG | Char | Trigger | Application logging flag; when `Y`, activates performance timer at form startup |
| COMP_FA | Char | Trigger | Comparison dealer financial area code; set during report submission for Detail report type |
| CURRENCY | Char | Trigger | Currency code associated with the selected dealer or principal; used when building report parameters |
| CUR_DATE | Char | ProgramUnit | Current system date used for date boundary validations in commented logic |
| DEALER | Char | Trigger | Selected dealer map code carried forward as a global for use in report parameter construction |
| FIN_BEG | Char | Trigger | Fiscal year begin date derived from the selected report period; passed to the report engine |
| FIN_END | Char | Trigger | Fiscal year end date derived from the selected report period; passed to the report engine |
| LOC_CD | Char | Trigger | Location code of the selected dealer; carried globally for report parameter construction |
| PARENT_GROUP | Char | Trigger | Parent dealer group code of the selected dealer; carried globally for report parameter construction |
| PRINCIPAL | Char | ProgramUnit / RecordGroup / Trigger | Principal/company mapping code used to filter dealer and report server lookups |
| P_FIN_YR | Char | Trigger | Fiscal year string derived from the selected month and year; passed to the report engine |
| REPORT_DESC | Char | Trigger | Report description label restored to block on form clear |
| REPORT_NAME | Char | Trigger | Report name (file identifier) restored to block on form clear |
| REP_SERVER | Char | Trigger | Report server name used when submitting the report via the report engine |
| USERID | Char | RecordGroup / Trigger | Logged-in user identifier used to filter authorised dealer records and to name output files |
| USER_NAME | Char | Trigger | Display name of the logged-in user; set at form initialisation for use in report headers or audit context |

### 8.1.2 Form Parameters

*All 4 ModuleParameter entries from vr_fsc_dlr_fmb.xml.*

| Parameter | Data Type | Default | Description |
| :--- | :--- | :--- | :--- |
| FROM_DATE | Char | - | Start date for the reporting period; derived at runtime from selected month and year |
| TO_DATE | Char | - | End date for the reporting period; derived at runtime from selected month and year |
| P_CHECK | Number | 0 | Reserved numeric check flag; default 0; not actively used in current form logic |
| P_REGION | Char | - | Region code passed to the form at startup; used for filtering regional data |

**Total Parameters:** 4

### 8.2 Blocks

| Block Name | Query Data Source | Records | Q/I/U/D | Key Mode | Master-Detail Relationship |
| :--- | :--- | :--- | :--- | :--- | :--- |
| CB_BLK | - | 1 | N/N/N/N | Default | Control block - entry point for FSC dealer report parameter selection |

**Total Blocks:** 1 business blocks

### 8.2.1 Block WhereClause and OrderByClause

*Block query scope from vr_fsc_dlr_fmb.xml. **Description** explains filter and sort in business terms; **Order By** and **Where Clause** columns retain verbatim XML text for migration.*

| Block | Description | Order By (XML) | Where Clause (XML) |
| :--- | :--- | :--- | :--- |
| - | No blocks with WhereClause/OrderByClause in vr_fsc_dlr_fmb.xml | - | - |

### 8.3 Items Summary

*Complete item inventory from `vr_fsc_dlr_fmb.xml`.*

**Block counts:**

*Database / non-database counts derived from XML.*

| Block | Total Items | Database Items | Non-Database Items |
| :--- | ---: | ---: | ---: |
| CB_BLK | 28 | 0 | 28 |
| PB_BLK | 12 | 0 | 12 |
| CB_ERR | 1 | 0 | 1 |
| **Total** | **41** | **0** | **41** |

**Item detail (all 41 items):**

| Block | Item Name | DatabaseItem | Description |
| :--- | :--- | :--- | :--- |
| CB_BLK | REPORT_DESC111 | false | **INACTIVE** - Unlabelled display field; legacy report description placeholder, not visible in runtime layout |
| CB_BLK | REPORT_DESC | false | Display field showing the report description title at the top of the form |
| CB_BLK | P_MONTHYEAR | false | Month-year selection list item (disabled at runtime; date formatted DD-MM-RRRR) |
| CB_BLK | P_PARENT | false | Parent dealer group code selected via the Dealer Details LOV |
| CB_BLK | P_FOR | false | FOR (franchise/outlet) code selected via the Dealer Details LOV |
| CB_BLK | P_DEALER | false | Dealer map code populated via the Dealer Details LOV; read-only |
| CB_BLK | P_LOC | false | Location code for the selected dealer; disabled, populated by LOV selection |
| CB_BLK | LOC_DESC | false | Location description corresponding to the selected dealer location |
| CB_BLK | P_CONTRACT_MONTH | false | Contract month selection list (J = January or blank); used for contract-based filtering |
| CB_BLK | APP_ID | false | Hidden field holding the application/report identifier (e.g. `vr_fsc_dlr`) |
| CB_BLK | REPORT_NAME | false | Hidden field holding the report file name used when launching the report |
| CB_BLK | REP_SERVER | false | Hidden field holding the report server name resolved at form clear/init |
| CB_BLK | SUBMIT | false | Button - submits report parameters and launches the FSC dealer report |
| CB_BLK | FILENAME | false | Output file name field; editable only when report format is EXCEL |
| CB_BLK | P_REASON | false | Reason selection list for report filtering; mandatory, validated on leave |
| CB_BLK | P_DESFORMAT | false | Output format selection list (HTMLCSS, PDF, CHARACTER); defaults to PDF |
| CB_BLK | COPYRIGHT_DECLARATION | false | Display field showing the copyright declaration text fetched at form clear |
| CB_BLK | F_START_YR | false | Hidden field storing the fiscal start year for report range calculations |
| CB_BLK | F_END_YR | false | Hidden field storing the fiscal end year for report range calculations |
| CB_BLK | P_DLR | false | Primary dealer description field; mandatory, validated via LOV |
| CB_BLK | P_MONTH | false | Month selection list (JAN-DEC); used to define the report month |
| CB_BLK | P_YEAR | false | Year selection list; used together with P_MONTH to define the report period |
| CB_BLK | P_REPORT_TYPE | false | Report type selection list: S = Summary, D = Detail; controls visibility of comparison dealer fields |
| CB_BLK | P_MONTH_YR | false | Derived display field holding the combined month-year string (e.g. JAN-2024) |
| CB_BLK | P_FROM_DATE | false | Calculated from-date of the reporting period (first day of selected month); read-only |
| CB_BLK | P_TO_DATE | false | Calculated to-date of the reporting period (last day + 1 of selected month); read-only |
| CB_BLK | P_DLR_B | false | Comparison (other) dealer description; mandatory when report type is Detail (D) |
| CB_BLK | P_PARENT_B | false | Parent group code of the comparison dealer, populated via LOV_OTH_DLR |
| PB_BLK | PB_EXIT | false | Inherited toolbar button - exits the form; triggers a confirmation dialog via GENERAL.ASK_CONFIRM before closing (inherited from DPL object group) |
| PB_BLK | PB_LIST | false | Inherited toolbar button - displays the LOV for the current item (inherited from DPL object group) |
| PB_BLK | PB_INSERT | false | Inherited toolbar button - inserts a new record into the current block (inherited from DPL object group) |
| PB_BLK | PM_CONT | false | Inherited toolbar button - continues or confirms the current operation (inherited from DPL object group) |
| PB_BLK | PB_DEL | false | Inherited toolbar button - deletes the current record (inherited from DPL object group) |
| PB_BLK | PB_CANCEL | false | Inherited toolbar button - cancels pending changes in the current block (inherited from DPL object group) |
| PB_BLK | PB_SAVE | false | Inherited toolbar button - saves/commits the current record (inherited from DPL object group) |
| PB_BLK | PB_PRINT | false | Inherited toolbar button - triggers the print action for the current form (inherited from DPL object group) |
| PB_BLK | PB_CUT | false | Inherited toolbar button - cuts the selected text or field value (inherited from DPL object group) |
| PB_BLK | PB_COPY | false | Inherited toolbar button - copies the selected text or field value (inherited from DPL object group) |
| PB_BLK | PB_PASTE | false | Inherited toolbar button - pastes clipboard content into the current field (inherited from DPL object group) |
| PB_BLK | PB_ERR_EXIT | false | Inherited toolbar button - exits the error window (CN_ERR/WIN_ERR); dismisses the error display canvas (inherited from DPL object group) |
| CB_ERR | TXT_ERR | false | Inherited display-only text item on the CN_ERR error canvas; shows the full error message text when an unhandled error is routed to the error window (inherited from DPL object group) |

### 8.4 List of Values

| LOV Name | Title | Record Group | Attached Block.Item |
| :--- | :--- | :--- | :--- |
| DEALER_DETAIL | Dealer Details | RG_DEALER_DETAIL | CB_BLK.P_PARENT, CB_BLK.P_FOR, CB_BLK.P_DEALER, CB_BLK.P_DLR |
| MONTH_YEAR | MONTH YEAR | RG_MONTH_YEAR | - |
| LOV_OTH_DLR | Dealer Help | RG_OTH_DLR | CB_BLK.P_DLR_B, CB_BLK.P_PARENT_B |

**Total LOVs:** 3

### 8.5 Alerts

| Alert Name | Title | Message Text | Calling Context |
| :--- | :--- | :--- | :--- |
| ALERT_BUT | Note | Please select valid region code and for code | Defined for region/FOR code validation; no active `SHOW_ALERT` call site found in current XML - alert is available but not directly invoked by active trigger code |
| AL_PRINT | Print | (set at runtime) | Inherited from DPL object group; used by the DPL library routine `ASK_PRINT` to display a print confirmation dialog; returns Yes / No / Cancel |
| AL_ERRINFO | Error | (set at runtime) | Inherited from DPL object group; used by `GENERAL.DISP_TEXT` to display error-level messages to the user |
| AL_NOTE | Note | (set at runtime) | Inherited from DPL object group; used by `GENERAL.DISP_TEXT` to display informational messages to the user |
| AL_CONFIRM | Caution | (set at runtime) | Inherited from DPL object group; used by `GENERAL.ASK_CONFIRM` to present a Yes/No confirmation dialog before destructive operations |

**Total Alerts:** 5

### 8.6 Program Units

*Authoritative catalogue of **5 form-local program units**. Database packages and standalone procedures are in **Section 15.2**; PLD shared-library routines are in **Section 18**.*

| Program Unit | Type | Calls | Description |
| :--- | :--- | :--- | :--- |
| PR_PASS_PARAM | Procedure | ED_REPORTS | Builds the report parameter string from the `ED_REPORTS` configuration table for the active report application; called from WHEN-BUTTON-PRESSED to pass dealer, date, principal and other parameters to the report engine |
| VALIDATE_CN_MAIN | Unknown | **COMMENTED OUT / INACTIVE** - general.check_null, general.disp_text | **COMMENTED OUT / INACTIVE** - Previously performed multi-field null and date validations for a test drive record; entire procedure body is block-commented; executes only `NULL;` |
| CHECK_BEFORE_DELETE | Unknown | **COMMENTED OUT / INACTIVE** - SH_ENQUIRY | **COMMENTED OUT / INACTIVE** - Previously validated that no enquiry records exist before allowing deletion of a zone master record; body is block-commented; executes only `NULL;` |
| POPULATE_ERRORS | Package spec | pk_plsql_table.code_tab | Package specification stub declaring a PL/SQL table variable `v_tab`; no body implemented in the form |
| L_POP_LIST_ITEM | Procedure | FIND_GROUP, DELETE_GROUP, CREATE_GROUP_FROM_QUERY, POPULATE_GROUP | Active procedure that dynamically builds and populates a list item record group from a SQL query at runtime; checks whether the named record group already exists, deletes it if so or creates it from the provided query, then populates the record group. No trigger or program unit in this form calls it; active code with no callers in this form. |

**Total Program Units:** 5

### 8.7 Triggers

**Item-Level Trigger Types (reference):**

| Trigger Name | Purpose |
| :--- | :--- |
| WHEN-VALIDATE-ITEM | Validates field when user leaves item |
| KEY-* | Keyboard actions - commit, exit, LOV, navigation |
| WHEN-NEW-BLOCK-INSTANCE | Initializes block on entry |
| WHEN-BUTTON-PRESSED | Executes button action |
| PRE-INSERT / POST-INSERT | Before/after record creation |
| WHEN-LIST-CHANGED | Dropdown selection changed |
| PRE-QUERY / POST-QUERY | Before/after query execution |
| WHEN-CHECKBOX-CHANGED | Checkbox toggled |
| WHEN-VALIDATE-RECORD | Validates entire record before leaving row |

**DPL library routines invoked from triggers and program units:**

| Routine | Type | Called From | Purpose |
| :--- | :--- | :--- | :--- |
| GENERAL.ASK_CONFIRM | Library routine | Form level; PB_BLK.PB_EXIT (inherited) | Displays a Yes/No confirmation dialog using the `AL_CONFIRM` alert; returns the user's choice to allow conditional exit or cancel of a destructive operation |
| GENERAL.CHECK_NULL | Library routine | ProgramUnit: VALIDATE_CN_MAIN (commented-only) | Validates that the supplied value is not null; displays an error message with the column title and raises form trigger failure if null |
| GENERAL.DISP_TEXT | Library routine | CB_BLK.P_DLR, CB_BLK.P_DLR_B, CB_BLK.P_REASON, CB_BLK.SUBMIT, Form level, ProgramUnit: CHECK_BEFORE_DELETE, ProgramUnit: VALIDATE_CN_MAIN | Displays a message in an alert dialog; uses `AL_ERRINFO` for error title and `AL_NOTE` for other titles; invoked for all user-facing validation and system error messages |
| GENERAL.RAISE_ERROR | Library routine | Form level (ON-ERROR trigger) | Looks up an error message by code and displays it via `DISP_TEXT`; raises `FORM_TRIGGER_FAILURE` for error-type messages |

### 8.7.1 Inactive / Commented-Out Trigger Register

*Triggers and field validations where XML source is `null;`, fully block-commented, or legacy code preserved but not executed. Do **not** migrate these as active business requirements.*

| Status | Block | Item | Trigger | Former behaviour (preserved in comments) | Disabled since / note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Inactive stub** | Form | - | KEY-COMMIT | Previously saved the current record by executing a commit | Replaced by a `NULL;` stub; form does not perform any database writes - no DML blocks defined; commit functionality disabled |
| **Commented out** | Form | - | FT_SAVE | Previously executed a commit/save action from the toolbar Save button | Body is block-commented; executes only `null;`; save action suppressed as the form is report-only with no DML blocks |
| **Commented out** | Form | - | WHEN-NEW-FORM-INSTANCE | Previously initialised global variables, populated list items, and set up the form environment on first load | Body is block-commented; executes only `null;`; initialisation logic migrated to PRE-FORM or removed |
| **Commented out** | CB_BLK | P_REASON | WHEN-LIST-CHANGED | Previously cleared dealer, location, program, session, agency, and parent fields when the reason list selection changed | Body is block-commented with `/* ... */`; executes only `null;`; downstream field-clearing logic removed |
| **Commented out** | PB_BLK | PB_EXIT | WHEN-BUTTON-PRESSED | Previously called `GENERAL.ASK_CONFIRM` and exited the form if confirmed | Body is block-commented; executes only `null;`; exit confirmation logic disabled on this inherited toolbar button |

*Additional null-only or partially commented triggers exist on estimation and legacy blocks - see XML `TriggerText` starting with `null;` or `/*`.*

**Complete trigger inventory (41 business triggers):**
*vr_fsc_dlr_fmb.xml contains Trigger elements.*

| Trigger Name | Block | Item | Called From / Context | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| ON-ERROR | Form | - | Form level | Intercepts Oracle Forms errors; displays user-friendly messages for known error codes (50004, 50025, 50026, 40035, 40202, 40100, 40501, 40508) using GENERAL.DISP_TEXT; calls GENERAL.RAISE_ERROR for all other errors |
| ON-MESSAGE | Form | - | Form level | Intercepts Forms informational messages; re-raises messages 40209 and 40207 as errors with GENERAL.DISP_TEXT; suppresses other standard messages |
| KEY-EXIT | Form | - | Form level | Clears application logging context via DBMS_APPLICATION_INFO then exits the form without validation |
| KEY-LISTVAL | Form | - | Form level | Displays the LOV associated with the current item using its LOV_NAME property; navigates to the next item after a successful selection |
| KEY-COMMIT | Form | - | Form level | **COMMENTED OUT / INACTIVE** - Inactive stub; executes `NULL;` only; no commit logic runs |
| KEY-CLRFRM | Form | - | Form level | Clears the form without validation; restores report description, report name, app ID, and copyright declaration globals; resolves the report server from `EH_REPORTS` based on app ID and principal |
| KEY-OTHERS | Form | - | Form level | Inherited from DPL object group; suppresses or handles all other key events not explicitly mapped to a KEY-* trigger (inherited) |
| KEY-NEXT-ITEM | Form | - | Form level | Inherited from DPL object group; navigates to the next item in the tab order (inherited) |
| KEY-PREV-ITEM | Form | - | Form level | Inherited from DPL object group; navigates to the previous item in the tab order (inherited) |
| KEY-NXTBLK | Form | - | Form level | Inherited from DPL object group; navigates to the next block (inherited) |
| KEY-PRVBLK | Form | - | Form level | Inherited from DPL object group; navigates to the previous block (inherited) |
| KEY-DOWN | Form | - | Form level | Inherited from DPL object group; navigates down to the next record within the current block (inherited) |
| KEY-UP | Form | - | Form level | Inherited from DPL object group; navigates up to the previous record within the current block (inherited) |
| FT_SAVE | Form | - | Form level | **COMMENTED OUT / INACTIVE** - Inherited trigger stub; body is block-commented; executes only `null;`; save action suppressed as the form has no DML blocks (inherited) |
| FT_CANCEL | Form | - | Form level | Inherited from DPL object group; cancels pending changes in the current block without committing (inherited) |
| FT_INSERT | Form | - | Form level | Inherited from DPL object group; inserts a new blank record into the current block (inherited) |
| FT_DEL | Form | - | Form level | Inherited from DPL object group; marks the current record for deletion (inherited) |
| FT_LIST | Form | - | Form level | Inherited from DPL object group; displays the LOV for the current item (inherited) |
| FT_PRINT | Form | - | Form level | Inherited from DPL object group; triggers the print action for the current form (inherited) |
| WHEN-NEW-FORM-INSTANCE | Form | - | Form level | **COMMENTED OUT / INACTIVE** - Inherited trigger stub; body is block-commented; executes only `null;`; form initialisation logic has been moved to PRE-FORM or removed (inherited) |
| PRE-FORM | Form | - | Form level | Starts application performance timer if APP_LOG is enabled; sets DBMS_APPLICATION_INFO session context to `vr_fsc_dlr` |
| WHEN-BUTTON-PRESSED | CB_BLK | SUBMIT | CB_BLK.SUBMIT | Validates that the report period is not the current or a future month; validates that dealer (P_DLR) is not empty and that comparison dealer (P_DLR_B) is not empty for Detail report type; sets the app ID based on report type; calls PR_PASS_PARAM to build the parameter string; configures and submits the report object to the report server; outputs the generated PDF to the browser |
| WHEN-NEW-ITEM-INSTANCE | CB_BLK | FILENAME | CB_BLK.FILENAME | Enables or disables the FILENAME field for editing based on whether the selected output format is EXCEL |
| WHEN-VALIDATE-ITEM | CB_BLK | P_REASON | CB_BLK.P_REASON | Validates that the Reason selection list is not empty; displays an error and raises failure if no reason is selected |
| WHEN-LIST-CHANGED | CB_BLK | P_REASON | CB_BLK.P_REASON | **COMMENTED OUT / INACTIVE** - Body is `null;`; previously cleared dependent dealer and location fields on reason change |
| WHEN-LIST-CHANGED | CB_BLK | P_DESFORMAT | CB_BLK.P_DESFORMAT | Enables and makes the FILENAME field navigable when output format is EXCEL; disables and clears it for all other formats |
| KEY-LISTVAL | CB_BLK | P_DLR | CB_BLK.P_DLR | Displays the DEALER_DETAIL LOV to allow the user to select a dealer |
| WHEN-VALIDATE-ITEM | CB_BLK | P_DLR | CB_BLK.P_DLR | Validates that the dealer field (P_DLR) is not empty; displays an error and raises failure if no dealer is selected |
| WHEN-LIST-CHANGED | CB_BLK | P_REPORT_TYPE | CB_BLK.P_REPORT_TYPE | Enables or disables the comparison dealer field (P_DLR_B) based on report type; sets VA_MANDATORY when Detail (D), VA_DEFAULT when Summary (S); clears P_DLR_B and P_PARENT_B on change |
| WHEN-VALIDATE-ITEM | CB_BLK | P_DLR_B | CB_BLK.P_DLR_B | Validates that the comparison dealer field (P_DLR_B) is not empty when report type is Detail (D); displays an error and raises failure if empty |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EXIT | PB_BLK.PB_EXIT (inherited) | Inherited toolbar button trigger; calls GENERAL.ASK_CONFIRM and exits the form if the user confirms; currently block-commented - executes only `null;` (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_LIST | PB_BLK.PB_LIST (inherited) | Inherited toolbar button trigger; displays the LOV for the currently focused item (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_INSERT | PB_BLK.PB_INSERT (inherited) | Inherited toolbar button trigger; inserts a new blank record into the current block (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PM_CONT | PB_BLK.PM_CONT (inherited) | Inherited toolbar button trigger; continues or confirms the current pending operation (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_DEL | PB_BLK.PB_DEL (inherited) | Inherited toolbar button trigger; marks the current record for deletion (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CANCEL | PB_BLK.PB_CANCEL (inherited) | Inherited toolbar button trigger; cancels pending changes in the current block (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SAVE | PB_BLK.PB_SAVE (inherited) | Inherited toolbar button trigger; commits the current record to the database (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PRINT | PB_BLK.PB_PRINT (inherited) | Inherited toolbar button trigger; triggers the print action for the current form (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CUT | PB_BLK.PB_CUT (inherited) | Inherited toolbar button trigger; cuts the selected text or field value to the clipboard (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_COPY | PB_BLK.PB_COPY (inherited) | Inherited toolbar button trigger; copies the selected text or field value to the clipboard (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PASTE | PB_BLK.PB_PASTE (inherited) | Inherited toolbar button trigger; pastes clipboard content into the currently focused field (inherited) |

### 8.8 Canvas and Window Inventory

**Windows:**

| Window | Title | Primary Canvas |
| :--- | :--- | :--- |
| WIN_ERR | - | CN_ERR |
| WN_MAIN | Free Service Claim Report (1.3.3) | CN_MAIN |

**Canvases:**

| Canvas | Type | Window |
| :--- | :--- | :--- |
| CN_ERR | Content | WIN_ERR |
| CN_MAIN | Content | WN_MAIN |
| CN_TOOL | Content | WN_MAIN |

---

### 8.9 Editors

*No editors found in vr_fsc_dlr_fmb.xml.*

### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

#### 8.10.1 Visual Attributes (form-defined)

*3 VisualAttribute elements defined at form level (not inherited from DPL.olb).*

| Visual Attribute |
| :--- |
| VA_MANDATORY |
| VA_DEFAULT |
| VA_DISPLAY |

#### 8.10.2 Property Classes (form-defined)

*Form-local PropertyClass elements.*

*No form-local property classes found in vr_fsc_dlr_fmb.xml.*

#### 8.10.3 Object Groups

*Object groups bundle inherited triggers and visual objects applied form-wide at runtime.*

| Object Group Child | Type |
| :--- | :--- |
| KEY-OTHERS | Inherited trigger |
| KEY-NEXT-ITEM | Inherited trigger |
| KEY-PREV-ITEM | Inherited trigger |
| KEY-NXTBLK | Inherited trigger |
| KEY-PRVBLK | Inherited trigger |
| KEY-DOWN | Inherited trigger |
| KEY-UP | Inherited trigger |
| CN_ERR | Inherited canvas |
| VA_DISP | Inherited visualattribute |
| CB_ERR | Inherited block |
| VA_LOV | Inherited visualattribute |
| VA_TRNI_DT | Inherited visualattribute |
| VA_TITLE | Inherited visualattribute |
| VA_ALERT | Inherited visualattribute |
| VA_BUTN | Inherited visualattribute |
| VA_TEXT | Inherited visualattribute |
| VA_MPROMPT | Inherited visualattribute |
| VA_OPROMPT | Inherited visualattribute |
| VA_MAND | Inherited visualattribute |
| VA_NUM | Inherited visualattribute |
| VA_DESC | Inherited visualattribute |
| VA_ICONIC_BUTN | Inherited visualattribute |
| VA_RB | Inherited visualattribute |
| VA_CB | Inherited visualattribute |
| WN_MAIN | Inherited window |
| POP_MAIN | Inherited trigger |
| CN_MAIN | Inherited canvas |
| CN_TOOL | Inherited canvas |
| PB_BLK | Inherited block |
| AL_ERRINFO | Inherited alert |
| AL_NOTE | Inherited alert |
| AL_CONFIRM | Inherited alert |
| WIN_ERR | Inherited window |
| AL_PRINT | Inherited alert |
| FT_SAVE | Inherited trigger |
| FT_CANCEL | Inherited trigger |
| FT_INSERT | Inherited trigger |
| FT_DEL | Inherited trigger |
| FT_LIST | Inherited trigger |
| FT_PRINT | Inherited trigger |
| WHEN-NEW-FORM-INSTANCE | Inherited trigger |

### 8.11 DataSourceColumn Inventory

*No DataSourceColumns found in vr_fsc_dlr_fmb.xml.*

## 9. Object Library

*The VR_FSC_DLR form references the DPL object library (DPL_olb.xml), which contains both Visual Attributes and Property Classes used to standardise the appearance and behaviour of form items across the DMS application suite. Three Visual Attributes are declared directly in the form module (VA_MANDATORY, VA_DEFAULT, VA_DISPLAY). The full catalogue below is derived from the DPL_olb.xml file in the source directory.*

Source OLB file(s): DPL_olb.xml

| Name | Type | Description | Used By (count) | Sample Items |
| ---- | ---- | ----------- | --------------- | ------------ |
| VA_CB | VisualAttribute | Gray background, Arial 8pt, black foreground, transparent fill - used for check-box items | referenced | Check-box items across DMS forms |
| VA_RB | VisualAttribute | Gray background, Arial 8pt, black foreground, transparent fill - used for radio-button items | referenced | Radio-button items across DMS forms |
| VA_ICONIC_BUTN | VisualAttribute | White background, black foreground, transparent fill - used for iconic push buttons | referenced | Iconic push-button items |
| VA_DESC | VisualAttribute | Gray background, Small Fonts 7pt medium blue foreground - used for descriptive display items | referenced | Descriptive display fields |
| VA_NUM | VisualAttribute | White background, Arial 8pt medium, black foreground - used for numeric text items | referenced | Numeric entry fields |
| VA_MAND | VisualAttribute | Cyan background, Arial 9pt medium, black foreground - used to mark mandatory fields | referenced in form (CB_BLK.P_DLR_B via P_REPORT_TYPE WHEN-LIST-CHANGED) | Other Dealer field (P_DLR_B) when Dealer Comparison type selected |
| VA_OPROMPT | VisualAttribute (Prompt) | White background, Arial 9pt, black prompt - used for optional-field prompts | referenced | Optional field label prompts |
| VA_MPROMPT | VisualAttribute (Prompt) | White background, Arial 9pt, red prompt - used for mandatory-field prompts | referenced | Mandatory field label prompts |
| VA_TEXT | VisualAttribute | White background, Arial 9pt medium, black foreground - general text item style | referenced | Standard text entry fields |
| VA_BUTN | VisualAttribute | Gray background, Arial 10pt bold, black foreground - used for push buttons | referenced | Push-button items |
| VA_ALERT | VisualAttribute | Gray background, MT Extra 11pt demilight, black foreground - used for alert dialogs | referenced | Alert dialog style |
| VA_TITLE | VisualAttribute | Gray background, Arial 10pt bold, blue foreground - used for title/header text | referenced | Screen title items |
| VA_TRNI_DT | VisualAttribute | White background, Courier bold, black foreground - used for transaction date items | referenced | Date transaction fields |
| VA_LOV | VisualAttribute | Gray background, Arial 9pt, dark blue foreground - used for LOV-linked fields | referenced | LOV-linked items |
| VA_DISP | VisualAttribute | r25g75b75 background, Arial 8pt bold, black foreground - used for display-only items | referenced | Display-only items across DMS forms |
| VA_MANDATORY | VisualAttribute | Form-level Visual Attribute defined in VR_FSC_DLR (not sourced from OLB) - used to style mandatory fields at runtime | 1 (CB_BLK.P_DLR_B) | Other Dealer field styled mandatory when Dealer Comparison type selected |
| VA_DEFAULT | VisualAttribute | Form-level Visual Attribute defined in VR_FSC_DLR (not sourced from OLB) - used to style non-mandatory fields at runtime | 1 (CB_BLK.P_DLR_B) | Other Dealer field styled default when Summary type selected |
| VA_DISPLAY | VisualAttribute | Form-level Visual Attribute defined in VR_FSC_DLR (not sourced from OLB) - used for display-only field styling | referenced | Display-only items in VR_FSC_DLR |
| PC_DESC | PropertyClass | Left-justified display item, Arial 9pt, white background, blue foreground, no bevel, max 110 chars, width 250 | referenced | Descriptive display fields |
| PC_SC_DATE | PropertyClass | Gray display date field, Arial 8pt bold, blue foreground, format mask for date entry (DD-MM-YY or DD/MM/YY), hint text | referenced | Supplementary date display items |
| PC_TITLE | PropertyClass | Centered gray text, Arial 10pt bold blue, uppercase restriction - used for screen titles | referenced | Screen heading items |
| PC_FORMAT | PropertyClass | Centered white text, Arial 9pt medium, uppercase restriction, max 12 chars, width 60 | referenced | Format code display fields |
| PC_MR_BLK | PropertyClass | Master-record block navigation property - navigates to PB_BLK, vertical orientation, Change Record style | referenced | Multi-record block definitions |
| PC_DISP | PropertyClass | Disabled display item, gray8 background, Arial 9pt medium, lowered bevel, not keyboard-navigable | referenced | Read-only display items |
| PC_LOV | PropertyClass | LOV-linked field, gray background, Arial 8pt medium, dark blue foreground, auto-select off, LOV positioned at 80/96 | referenced | LOV-attached text items |
| PC_FORM | PropertyClass | Form-level property class - sets console window (WN_MAIN), menu module (menu.mmx), validation unit (Item), savepoint off; includes standard ON-ERROR, ON-MESSAGE, KEY-EXIT, KEY-LISTVAL, KEY-COMMIT, KEY-CLRFRM trigger bodies | referenced | Form-level template for all DMS forms |
| PC_DISP_DATE | PropertyClass | Disabled display date item, gray8 background, Arial 9pt medium, format mask DD-MM-RRRR, not keyboard-navigable | referenced | Date display items |
| PC_DISP_NUM | PropertyClass | Disabled display numeric item, gray8 background, Arial 9pt medium right-justified, lowered bevel, not keyboard-navigable | referenced | Numeric display items |
| PC_DATE | PropertyClass | Text date item, white background, Arial 9pt medium, format mask DD-MM-RRRR, max 10 chars, hint text, popup menu POP_MAIN | referenced | Date entry fields |
| PC_DTTIME | PropertyClass | Text datetime item, Arial, format mask DD-MM-RRRR HH24:MI, max 15 chars, hint text, initialised to database datetime | referenced | Date-and-time entry fields |
| PC_CB | PropertyClass | Check-box item, white background, Arial 9pt medium, height 14 | referenced | Check-box items |
| PC_ALERT | PropertyClass | Alert dialog property - gray background, MT Extra 11pt demilight | referenced | Alert objects |
| PC_MDATE | PropertyClass | Mandatory date text item, white background, format mask DD-MM-RRRR, red prompt, popup menu POP_MAIN, includes WHEN-VALIDATE-ITEM (null check + hint display) | referenced | Mandatory date fields |
| PC_RB | PropertyClass | Radio-button item, gray background, Arial 9pt, height 11 | referenced | Radio-button items |
| PC_WIND | PropertyClass | Window property class - resizable, hide-on-exit, gray background, Arial 10pt bold blue, positioned at 0/0, width 464 | referenced | Window objects |
| PC_CANV | PropertyClass | Canvas property class - white background, Arial, width 750, height 440, attached to WN_MAIN | referenced | Canvas objects |
| PC_BUTN | PropertyClass | Push button, gray background, Arial 9pt bold, width 42, auto-hint on, no mouse navigate | referenced | Standard push buttons |
| PC_TEXT | PropertyClass | Optional text item, white background, Arial 9pt medium, black prompt, popup menu POP_MAIN, mixed case | referenced | Optional text entry fields |
| PC_MTEXT | PropertyClass | Mandatory text item, white background, Arial 9pt medium, red prompt, includes WHEN-VALIDATE-ITEM (null check + hint display) | referenced | Mandatory text entry fields |
| PC_UTEXT | PropertyClass | Optional uppercase text item, white background, Arial 9pt medium, black prompt | referenced | Optional uppercase text fields |
| PC_MUTEXT | PropertyClass | Mandatory uppercase text item, white background, Arial 9pt medium, red prompt, includes WHEN-VALIDATE-ITEM (null check + hint display) | referenced | Mandatory uppercase text fields |
| PC_NUM | PropertyClass | Numeric text item, right-justified, white background, Arial 9pt medium, black prompt, number data type | referenced | Optional numeric fields |
| PC_MNUM | PropertyClass | Mandatory numeric text item, right-justified, white background, red prompt, includes WHEN-VALIDATE-ITEM (zero/null check + hint display) | referenced | Mandatory numeric fields |
| PC_ICONIC_BUTN | PropertyClass | Iconic push button, white background, no bevel, width 20, auto-hint, no mouse navigate | referenced | Iconic push buttons |
| PC_SCROLL | PropertyClass | Scrollbar property - width 13 | referenced | Scroll bars |
| OG_GROUP | ObjectGroup | Object group declared in the VR_FSC_DLR form module | referenced | Form-level object grouping |

---

## 10. Record Groups

*Lists all record groups, their LOV bindings, query logic, dynamic bindings, business purpose, and form usage.*

| Record Group | Type | Used By LOV | Display Column | Return Column | Dynamic Bindings | Purpose | Where Used |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| RG_OTH_DLR | Query | LOV_OTH_DLR | COMP_NAME | PARENT_GROUP | No | Lists active non-DDT dealers (excluding the user's own group) for comparison dealer selection in Detail report mode | LOV_OTH_DLR -> CB_BLK.P_DLR_B, CB_BLK.P_PARENT_B |
| RG_DEALER_DETAIL | Query | DEALER_DETAIL | DEALER_NAME | FOR_CD | No | Lists dealers and their FOR codes authorised for the logged-in user to select as the primary reporting dealer | DEALER_DETAIL -> CB_BLK.P_PARENT, CB_BLK.P_FOR, CB_BLK.P_DEALER, CB_BLK.P_DLR |
| RG_MONTH_YEAR | Query | MONTH_YEAR | MOTH | - | No | Provides a rolling 12-month lookback list of month-year values for the reporting period selection | MONTH_YEAR |

**Total Record Groups:** 3

## 11. Referenced Database Objects

*Database tables, views, and objects accessed by the form.*

| Block | Base Table | Primary Key Item | Database Item |
| :--- | :--- | :--- | :--- |
| CB_BLK | - | - | No |

| Object | Schema | Used In | Description |
| :--- | :--- | :--- | :--- |
| `AM_DEALER_LOC` | - | RG_DEALER_DETAIL, RG_OTH_DLR | Dealer location master - holds dealer categorisation, principal mapping, and termination status for dealer selection |
| `AM_USERS` | - | RG_DEALER_DETAIL | User master - stores user type and ID used to filter authorised dealers for the logged-in user |
| `DUAL` | - | RG_MONTH_YEAR, Trigger KEY-CLRFRM, Trigger WHEN-BUTTON-PRESSED, Trigger WHEN-NEW-FORM-INSTANCE | Oracle system pseudo-table - used for date arithmetic, copyright declaration lookup, and current date/month queries |
| `ED_REPORTS` | - | PR_PASS_PARAM | Report definition table - stores parameter configuration (parameter type, name, default, data type, serial number) per report application and principal |
| `EH_REPORTS` | - | Trigger KEY-CLRFRM, Trigger WHEN-NEW-FORM-INSTANCE | Report server configuration table - stores the report server name keyed by application ID and principal mapping code |
| `GBL_FIN_YEAR` | - | Trigger WHEN-NEW-FORM-INSTANCE | Global financial year reference table - queried at form startup to retrieve the current financial year value used to initialise form-level year parameters |

**Total Referenced Objects:** 6

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure/Package Index

| Requirement ID | Procedure/Package | Purpose |
| -------------- | ----------------- | ------- |
| BR-001 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Registers the form module name in the database session's client information at form open |
| BR-001 | DBMS_APPLICATION_INFO.SET_MODULE | Registers the form module name and action in the database session's module tracking at form open |
| BR-002 | EH_REPORTS | Report server configuration table - queried on form reset and at form startup to resolve the correct report server for the current application and principal |
| BR-002 | SF_COPYRIGHT_DECLARATION | Database function - called on form reset to retrieve the current copyright declaration text |
| BR-002 | GBL_FIN_YEAR | Global financial year reference table - queried at form startup to retrieve the current financial year value used to initialise form-level year parameters |
| BR-006 | GENERAL.DISP_TEXT | Displays error alert when Reason field is left empty |
| BR-007 | GENERAL.DISP_TEXT | Displays error alert when Dealer field is left empty on navigation |
| BR-008 | GENERAL.DISP_TEXT | Displays error alert when Other Dealer field is left empty for Dealer Comparison type |
| BR-009 | GENERAL.DISP_TEXT | Displays error alerts for period validation failures and mandatory field failures at report submission |
| BR-009 | PR_PASS_PARAM | Assembles the report parameter string from ED_REPORTS configuration for the current application and principal |
| BR-009 | ED_REPORTS | Report parameter configuration table - queried by PR_PASS_PARAM to build the report parameter string |
| BR-009 | WEB.SHOW_DOCUMENT | Opens the generated PDF report in a new browser window |
| BR-010 | GENERAL.DISP_TEXT | Displays error alerts for intercepted form error codes |
| BR-010 | GENERAL.RAISE_ERROR | Maps and displays the registered error message for database referential integrity violations |
| BR-011 | GENERAL.DISP_TEXT | Reformats and displays system message codes 40209 and 40207 |
| BR-012 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Clears the database session's client information on form exit |
| BR-012 | DBMS_APPLICATION_INFO.SET_MODULE | Clears the database session's module tracking on form exit |
| - | GENERAL.ASK_CONFIRM | Presents a confirmation dialog before discarding changes (FT_CANCEL) or deleting a record (FT_DEL); branches trigger logic based on user response |
| - | GENERAL.DISP_TEXT | Displays insert-time feedback message via FT_INSERT trigger |
| - | GENERAL.l_pop_list_item | Populates list item controls at runtime using a record-group name and selection value; delegated through the local L_POP_LIST_ITEM program unit |
| - | AM_DEALER_LOC | Dealer location master - queried in record groups RG_DEALER_DETAIL and RG_OTH_DLR for dealer categorisation, principal mapping, and termination status |
| - | AM_USERS | User master - queried in record group RG_DEALER_DETAIL to filter authorised dealers for the logged-in user |

---

### 12.2 Procedure and Package Catalogue

| Procedure/Package | Type | Called From | Purpose | Classification |
| ----------------- | ---- | ----------- | ------- | -------------- |
| PR_PASS_PARAM | Form Program Unit (Procedure) | WHEN-BUTTON-PRESSED (CB_BLK.SUBMIT) | Queries ED_REPORTS for the current application and principal to build the complete Oracle Reports parameter string; appends parent group, region code, from/to dates, other dealer parent group, and principal to the parameter string | Form Program Unit (Procedure) |
| GENERAL.DISP_TEXT | Attached Library Procedure (DPL) | FT_INSERT, ON-ERROR, ON-MESSAGE, WHEN-BUTTON-PRESSED (CB_BLK.SUBMIT), WHEN-VALIDATE-ITEM (CB_BLK.P_DLR), WHEN-VALIDATE-ITEM (CB_BLK.P_DLR_B), WHEN-VALIDATE-ITEM (CB_BLK.P_REASON) | Displays a text message in an Oracle Forms alert dialog; selects AL_ERRINFO for error-titled messages and AL_NOTE for others; sets alert title and message text then shows the alert; also used for insert-time feedback via FT_INSERT | Attached Library Procedure (DPL) |
| GENERAL.RAISE_ERROR | Attached Library Procedure (DPL) | ON-ERROR | Receives a message code, looks up message text and type, determines severity (Error/Note/Caution), displays via GENERAL.DISP_TEXT, and raises FORM_TRIGGER_FAILURE for error-type messages | Attached Library Procedure (DPL) |
| GENERAL.ASK_CONFIRM | Attached Library Function (DPL) | FT_CANCEL, FT_DEL | Presents a confirmation dialog to the user containing the supplied message text and returns a numeric result indicating the user's choice; allows trigger logic to branch based on whether the user confirmed or cancelled the operation | Attached Library Function (DPL) |
| GENERAL.l_pop_list_item | Attached Library Procedure (DPL) | ProgramUnit: L_POP_LIST_ITEM | Populates a list item control at runtime using the supplied record-group name and selection value; called from the local program unit L_POP_LIST_ITEM, which acts as a wrapper delegating list-population work to this library routine | Attached Library Procedure (DPL) |
| DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Oracle Built-in Package | PRE-FORM, KEY-EXIT | Sets or clears the client_info field in the current database session (V$SESSION) for monitoring purposes | Oracle Built-in Package |
| DBMS_APPLICATION_INFO.SET_MODULE | Oracle Built-in Package | PRE-FORM, KEY-EXIT | Sets or clears the module_name and action_name fields in the current database session for monitoring purposes | Oracle Built-in Package |
| WEB.SHOW_DOCUMENT | Oracle Forms Web Built-in | WHEN-BUTTON-PRESSED (CB_BLK.SUBMIT) | Opens the generated report PDF file in a new browser window using the Oracle Forms Web package | Oracle Forms Web Built-in |
| EH_REPORTS | Database Table (SELECT) | KEY-CLRFRM, WHEN-NEW-FORM-INSTANCE | Queried to resolve the report server name for the current application identifier and principal; result used to set the form's report server value; queried both at form startup and on form reset | Database Table (SELECT) |
| ED_REPORTS | Database Table (SELECT) | PR_PASS_PARAM (via WHEN-BUTTON-PRESSED) | Queried to retrieve the ordered list of report parameters for the current application and principal; used to build the report parameter string | Database Table (SELECT) |
| GBL_FIN_YEAR | Database Table (SELECT) | WHEN-NEW-FORM-INSTANCE | Queried at form startup to retrieve the current financial year value used to initialise form-level year parameters | Database Table (SELECT) |
| AM_DEALER_LOC | Database Table (SELECT) | RG_DEALER_DETAIL, RG_OTH_DLR | Dealer location master - holds dealer categorisation, principal mapping, and termination status; queried by the dealer and other-dealer record groups to populate the dealer selection lists | Database Table (SELECT) |
| AM_USERS | Database Table (SELECT) | RG_DEALER_DETAIL | User master - stores user type and ID; queried in the dealer record group to filter the list of authorised dealers to those associated with the logged-in user | Database Table (SELECT) |
| SF_COPYRIGHT_DECLARATION | Database Function (SELECT from DUAL) | KEY-CLRFRM | Called to retrieve the current copyright declaration text displayed on the form | Database Function (SELECT from DUAL) |
| DUAL | Oracle System Pseudo-table | RG_MONTH_YEAR, KEY-CLRFRM, WHEN-BUTTON-PRESSED, WHEN-NEW-FORM-INSTANCE | Used for date arithmetic, copyright declaration lookup, and current date/month queries throughout the form | Oracle System Pseudo-table |

## 13. Package Procedure Specifications

*Behavioural requirements for each database package invoked from the form. Only packages referenced in the form XML that have a matching source `.pck` file in the input directory are listed. Descriptions are derived from the package bodies in the uploaded PCK sources.*

*No PCK files found - no `*.pck` source files were discovered in `/app/section-rewrite-pipeline/workspaces/3d1f37d1-0006-432d-a50a-14a9f68ad992/inputs/form_sources`. Package specifications cannot be generated without uploaded PCK sources.*

## 14. Database Package Catalogue

*Detailed specifications for each database package routine called from the form, including signatures and business rules.*

*No PCK files found - no `*.pck` source files were discovered in the form sources directory. The database package catalogue cannot be generated without uploaded PCK sources.*

---

## 15. PLD Procedure Call Sites

*Maps each program-library routine to its call sites within triggers and program units. Behaviour descriptions are derived from the uploaded `.pld` sources.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ASK_CONFIRM | Function | Function(confirm_msg VARCHAR2) RETURN NUMBER | Trigger: FT_CANCEL in Form, Trigger: FT_DEL in Form | Presents a confirmation dialog to the user containing the supplied message text and returns a numeric result indicating the user's choice. Called by the FT_CANCEL and FT_DEL form-level triggers to prompt the user before discarding changes or deleting a record, allowing the trigger logic to branch based on whether the user confirmed or cancelled the operation. |
| DISP_TEXT | Procedure | Procedure(text_string VARCHAR2, title_string VARCHAR2) | Trigger: FT_INSERT in Form, Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: WHEN-BUTTON-PRESSED in CB_BLK.SUBMIT, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_DLR, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_DLR_B, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_REASON | Displays a message to the user in an alert dialog. Selects `AL_ERRINFO` when the title is "Error" and `AL_NOTE` for any other title. Sets both the alert title and message text at runtime, then shows the alert. Used for all validation error messages and system error interceptions throughout the form, including insert-time feedback via FT_INSERT. |
| l_pop_list_item | Procedure | Procedure(p_rg_name VARCHAR2, p_select VARCHAR2) | ProgramUnit: L_POP_LIST_ITEM | Populates a list item control at runtime using the supplied record-group name and selection value. Called from the local program unit `L_POP_LIST_ITEM`, which acts as a wrapper delegating list-population work to this library routine, keeping form-level code decoupled from the underlying record-group mechanics. |
| RAISE_ERROR | Procedure | Procedure(mesg_code IN VARCHAR2) | Trigger: ON-ERROR in Form | Looks up a message text and type by the supplied error code. Calls `GENERAL.DISP_TEXT` to show the message; raises `FORM_TRIGGER_FAILURE` for error-type (E) messages; displays a note for informational (N) messages and a caution for warning (C) messages. Invoked by the ON-ERROR trigger to handle unknown Oracle Forms error codes. |

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``vr_fsc_dlr_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| CHECK_NULL | Procedure | Procedure(p_value IN VARCHAR2, column_title IN VARCHAR2) | ProgramUnit: VALIDATE_CN_MAIN | **COMMENTED OUT / INACTIVE** - Previously invoked within the fully commented `VALIDATE_CN_MAIN` procedure to validate that mandatory test-drive fields (plate number, model year, test date, times, location, sales consultant, and odometer readings) were not null; raises `FORM_TRIGGER_FAILURE` with a message including the column title if the value is null. The calling program unit body is entirely block-commented; this routine is never executed at runtime. |

**Total Active Routines:** 4 of 24 in DPL.pld source
**Inactive / commented-only routines:** 1

---

### D2kwutil.pld (`Win_API`)

*No routines from ``D2kwutil.pld`` are referenced in ``vr_fsc_dlr_fmb.xml``.*

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| ID | Service Name | Database Object | Input Parameters | Output | Business Function | API Endpoint Suggestion |
| -- | ------------ | --------------- | ---------------- | ------ | ----------------- | ----------------------- |
| MS-001 | Report Server Configuration Service | EH_REPORTS | app_id (application identifier), principal_map_cd (company/brand code) | rep_server (report server name) | Resolves the correct Oracle Reports server name for a given application and principal combination; used to configure the report engine target at form initialisation | GET /api/report-config/server?appId={appId}&principalCode={principalCode} |
| MS-002 | Report Parameter Assembly Service | ED_REPORTS | app_id (application identifier), principal_map_cd (company/brand code) | Ordered list of report parameters (param_type, parameter_name, default_value, parameter_datatype) | Retrieves the ordered set of report parameters for a given application and principal, used to construct the parameter string passed to the Oracle Reports engine | GET /api/report-config/parameters?appId={appId}&principalCode={principalCode} |
| MS-003 | Dealer Lookup Service | AM_DEALER_LOC, AM_DEALER_LOC_COMPANY_MASTER, AM_USERS, AM_USER_DEALER_MASTER, MULDMS.GM_FOR, AM_COMPANY_MASTER | user_id (logged-in user identifier) | List of dealers (dealer name, for code, for description, parent group, dealer map code) assigned to the user, filtered to non-terminated, non-DDT dealers with a primary location | Provides the list of dealerships assigned to the logged-in user for the primary dealer selection on the FSC report request form | GET /api/dealers/assigned?userId={userId} |
| MS-004 | Other Dealer Lookup Service | AM_DEALER_LOC, AM_DEALER_LOC_COMPANY_MASTER | principal_map_cd (company/brand code) | List of active dealers (company name, parent group), excluding terminated and DDT-category dealerships, filtered to the current principal | Provides the list of all active dealerships available for selection as the comparison dealer in Dealer Comparison reports | GET /api/dealers/active?principalCode={principalCode} |
| MS-005 | FSC Dealer Report Generation Service | rep.rdf (Oracle Reports file) | app_id, parent group (P_PARENT), region code (P_FOR), from date (P_FROM_DATE), to date (P_TO_DATE), other dealer parent group (P_OTH_PARENT), principal (P_PRINCIPAL), report server (REP_SERVER) | PDF file (generated report) | Runs the FSC Dealer Comparison or Summary report for the selected dealer, period, and parameters; returns the PDF file for display in the browser | POST /api/fsc-reports/generate |
| MS-006 | Copyright Declaration Service | SF_COPYRIGHT_DECLARATION (via DUAL) | None | Copyright declaration text string | Retrieves the current copyright declaration text for display on the report selection screen | GET /api/system/copyright-declaration |

**Total Microservices Identified: 6**

---

## 17. Workflows

| ID | Workflow Name | Trigger Event | Steps | Decision Points | End State |
| -- | ------------- | ------------- | ----- | --------------- | --------- |
| WF-001 | Form Initialisation and Session Registration | PRE-FORM fires when the form opens | 1. Conditionally start application performance timer (if logging is active). 2. Register form identity ('vr_fsc_dlr') in database session client info and module fields. | Is application performance logging active for this session? If yes, start timer; if no, skip timer. | Form is open; database session tagged with form identity; performance timer running if logging is active. |
| WF-002 | Form Reset and Configuration Reload | KEY-CLRFRM fires when the user resets the form | 1. Clear all form entries. 2. Restore report description, report name, and application identifier from session context. 3. Query EH_REPORTS for the report server configured for the current application and principal; if found and non-blank, read server name from configuration file; otherwise use session default. 4. Retrieve and display copyright declaration from database. | Is a report server configured for this application and principal? Is the server name non-blank? If both true, read from configuration file; otherwise use session default. | Form is cleared and reset with session defaults; report server and copyright declaration refreshed. |
| WF-003 | Report Type Selection and Field State Adjustment | WHEN-LIST-CHANGED fires on Report Type field when user changes the selection | 1. Evaluate the newly selected report type. 2. If Dealer Comparison: enable, make navigable/editable, and mark Other Dealer field as mandatory; clear Other Dealer and parent group values. 3. If Summary: disable, make non-navigable/read-only, and mark Other Dealer field as non-mandatory; clear Other Dealer and parent group values. | Is the selected report type Dealer Comparison or Summary? | Other Dealer field state (enabled/disabled, mandatory/non-mandatory) matches the selected report type; previous Other Dealer values cleared. |
| WF-004 | Output Format Selection and File Name Field Control | WHEN-LIST-CHANGED fires on Format field, and WHEN-NEW-ITEM-INSTANCE fires on File Name field | 1. When format changes: if Excel, enable and make File Name field navigable; if not Excel, clear and disable File Name field. 2. When focus enters File Name: if Excel format active, allow insert/update; otherwise block insert/update. | Is the currently selected output format Excel? | File Name field is editable only when Excel format is selected; disabled and cleared for all other formats. |
| WF-005 | FSC Report Submission | WHEN-BUTTON-PRESSED fires on Submit Report button | 1. Calculate report date range (from/to dates) from selected month and year. 2. Validate: Summary report not allowed for current month. 3. Validate: Report not allowed for future month (same-year check). 4. Validate: Report not allowed for future month (cross-year check). 5. Validate: Dealer must not be empty. 6. Validate: Other Dealer must not be empty if Dealer Comparison type. 7. Build formatted month-year display value. 8. Assign report identity based on report type. 9. Call PR_PASS_PARAM to assemble report parameter string from ED_REPORTS. 10. Configure report object (PDF format, file output path with user/timestamp filename). 11. Run report via report server. 12. Open PDF in new browser window. | Is report type Summary and month/year = current month? Is report period a future month (same year)? Is report period a future month and year? Is Dealer field empty? Is Other Dealer empty and Dealer Comparison type selected? An exception during report run is silently suppressed. | If all validations pass: report PDF generated and opened in browser. If any validation fails: error displayed; submission blocked; user remains on form. If report run exception: exception suppressed; no output. |
| WF-006 | Field-Level Validation - Reason | WHEN-VALIDATE-ITEM fires on Reason field when user leaves it | 1. Check whether Reason field has a value. 2. If empty, display error and abort trigger. | Is the Reason field empty? | If Reason has a value: validation passes, user proceeds. If empty: error *"Main Reason can not be empty"* displayed; user must select a reason. |
| WF-007 | Field-Level Validation - Dealer | WHEN-VALIDATE-ITEM fires on Dealer field when user leaves it | 1. Check whether Dealer field has a value. 2. If empty, display error and abort trigger. | Is the Dealer field empty? | If Dealer has a value: validation passes, user proceeds. If empty: error *"Dealer Can Not be Empty"* displayed; user must select a dealer. |
| WF-008 | Field-Level Validation - Other Dealer (Conditional) | WHEN-VALIDATE-ITEM fires on Other Dealer field when user leaves it | 1. Check whether Dealer Comparison report type is selected. 2. If yes, check whether Other Dealer field has a value. 3. If empty, display error and abort trigger. | Is Dealer Comparison type selected? Is Other Dealer field empty? | If not Dealer Comparison type: validation skipped. If Dealer Comparison and Other Dealer has a value: validation passes. If Dealer Comparison and Other Dealer empty: error *"Other Dealer Can not be Empty"* displayed. |
| WF-009 | Centralised Error Handling | ON-ERROR fires whenever a form error is raised | 1. Check error code against known categories (50004, 50025/50026, 40209/50016, 40207, -02292, 40654-40659). 2. Display corresponding plain-language error message for each category. 3. Roll back pending changes for locking and general database errors. 4. Suppress codes 40401/40405. 5. Abort trigger after error display. | Which error code was raised? Is it a known category? | User sees a plain-language error message; form remains open; pending changes rolled back where applicable; trigger aborted. |
| WF-010 | Centralised Message Handling | ON-MESSAGE fires whenever a form message is raised | 1. Check message code against codes 40209 and 40207. 2. For matching codes, format and display the message with error type, code, and text. 3. Abort trigger. | Is the message code 40209 or 40207? | For matching codes: reformatted error message displayed; trigger aborted. For other codes: default processing continues. |
| WF-011 | Form Exit with Session Cleanup | KEY-EXIT fires when the user exits the form | 1. Clear client information from database session. 2. Clear module and action names from database session. 3. Close the form without saving. | None | Database session tracking cleared; form closed; no unsaved changes retained. |

**Total Workflows Identified: 11**

---

## 18. PLD-Backed Logic

*Maps shared library routines to their business function and suggested API contracts.*

### DPL.pld (`general`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | CHECK_NULL | Validation | ProgramUnit: VALIDATE_CN_MAIN | /api/v1/pld/check_null | When a required field value is null, then an error message with the column title is displayed and form navigation is halted |
| PLD-002 | DISP_TEXT | Business Logic | Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: WHEN-BUTTON-PRESSED in CB_BLK.SUBMIT, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_DLR, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_DLR_B, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_REASON | /api/v1/pld/disp_text | When a message text and title are supplied, then an alert dialog is displayed to the user using the appropriate alert style |
| PLD-003 | RAISE_ERROR | Validation | Trigger: ON-ERROR in Form | /api/v1/pld/raise_error | When an error code is received, then the corresponding message is retrieved and displayed, and form execution is halted for error-type messages |


---

### D2kwutil.pld (`Win_API`)

*No routines from ``D2kwutil.pld`` are referenced in ``vr_fsc_dlr_fmb.xml``.*

---

---

## 19. PCK-Backed Logic

*Maps database package routines to their business rules and suggested API contracts.*

*No package routines from the available PCK files are referenced in ``vr_fsc_dlr_fmb.xml``.*

---

---

## 20. System Interfaces

### 20.1 Database Integrations

| Interface Name | Type | Purpose | Data Flow | Error Handling |
| -------------- | ---- | ------- | --------- | -------------- |
| Report Server Configuration Lookup (EH_REPORTS) | Database Table SELECT | Resolves the report server name for the current application identifier and principal (company/brand) when the form is reset | Form reads rep_server column from EH_REPORTS filtered by app_id and principal_map_cd | On NO_DATA_FOUND, TOO_MANY_ROWS, or any exception: falls back to the session-level default report server value (GLOBAL.REP_SERVER) |
| Report Parameter Configuration Lookup (ED_REPORTS) | Database Table SELECT | Retrieves the ordered list of report parameters for the current application and principal at report submission time | Form reads param_type, parameter_name, default_value, parameter_datatype from ED_REPORTS filtered by app_id and principal_map_cd, ordered by serial_no | Handled within PR_PASS_PARAM; no explicit exception handling in the cursor loop - any database error propagates to the ON-ERROR trigger |
| Copyright Declaration Retrieval | Database Function SELECT | Retrieves the current copyright declaration text for display on the form | Form calls SF_COPYRIGHT_DECLARATION via SELECT from DUAL; result written to COPYRIGHT_DECLARATION display field | No explicit exception handling; any database error propagates to the ON-ERROR trigger |
| Dealer Lookup (RG_DEALER_DETAIL via DEALER_DETAIL LOV) | Record Group / LOV | Provides the list of dealerships assigned to the logged-in user for primary dealer selection | Query joins AM_DEALER_LOC, AM_COMPANY_MASTER, MULDMS.GM_FOR, AM_USERS, AM_USER_DEALER_MASTER; filters to user's assigned non-DDT dealers with primary location; returns dealer name, for code, for description, parent group, dealer map code | Standard Oracle Forms LOV error handling; LOV display fails silently if record group query errors |
| Other Dealer Lookup (RG_OTH_DLR via LOV_OTH_DLR LOV) | Record Group / LOV | Provides the list of all active dealerships available for the comparison dealer selection | Query joins AM_DEALER_LOC and AM_DEALER_LOC_COMPANY_MASTER; filters to non-terminated, non-DDT dealers with a valid principal; returns company name and parent group | Standard Oracle Forms LOV error handling |
| Month-Year List (RG_MONTH_YEAR via MONTH_YEAR LOV) | Record Group (UNKNOWN type) | Provides the list of selectable reporting months (up to 6 months prior to today, no earlier than July 2012) | Query generates up to six months using ADD_MONTHS against SYSDATE; formatted as MON-YY | Standard Oracle Forms record group error handling |

### 20.2 External System Integrations

The VR_FSC_DLR form does not integrate with any external systems beyond the Oracle database and the Oracle Reports server. No CALL_FORM, OPEN_FORM, HOST, or external file access calls are made by this form's active code. The Oracle Reports server is configured via the EH_REPORTS table (see Section 20.1 and Section 20.3) and is accessed through the Oracle Forms RUN_REPORT_OBJECT built-in, which is an internal Forms-to-Reports server call, not an external system integration.

| System Name | Integration Type | Purpose | Protocol | Endpoint | Data Exchange | Success / Error Codes |
| ----------- | ---------------- | ------- | -------- | -------- | ------------- | --------------------- |
| Oracle Reports Server | Report Execution (via RUN_REPORT_OBJECT) | Executes the FSC Dealer or FSC Summary report and generates the output PDF file | Oracle Forms RUN_REPORT_OBJECT (internal) | Report server name resolved from EH_REPORTS configuration | Form passes parameter string (P_PARENT, P_FOR, P_FROM_DATE, P_TO_DATE, P_OTH_PARENT, P_PRINCIPAL, MODE, BLANKPAGES, parform) and report filename; output is a PDF file written to /iashome/ias/reports/printer/ | Exceptions during report run are caught by WHEN OTHERS and silently suppressed (null); no error is displayed to the user |

### 20.3 Report Integrations

| Report Name | Report Server | Parameters | Output Format | Trigger |
| ----------- | ------------- | ---------- | ------------- | ------- |
| rep.rdf | Resolved from EH_REPORTS at form reset; applied to report object at submission | P_PARENT (primary dealer parent group), P_FOR (region/area code), P_FROM_DATE (report start date), P_TO_DATE (report end date), P_OTH_PARENT (other dealer parent group), P_PRINCIPAL (company/brand code), MODE=BITMAP (INFERRED), BLANKPAGES=NO (INFERRED), parform=yes (INFERRED) | PDF | WHEN-BUTTON-PRESSED on Submit Report button (CB_BLK.SUBMIT) - after all parameter validations pass |

---

### 20.3.1 Parameters Passed to the Report

This form does not pass parameters to an Oracle Report. No report parameters were identified in the form sources.

## 21. Procedure and Function Business Rule Catalogue

End-to-end business requirement specification for every stored procedure and function referenced by the VR_FSC_DLR form.

### 21.1 Catalogue Index

4 procedures/functions - each SP ID links to its detailed specification in Section 21.2.

| SP Index | Routine Name |
| :--- | :--- |
| [SP-001](#SP-001--PR_PASS_PARAM) | PR_PASS_PARAM |
| [SP-002](#SP-002--GENERAL.ASK_CONFIRM) | GENERAL.ASK_CONFIRM |
| [SP-003](#SP-003--GENERAL.DISP_TEXT) | GENERAL.DISP_TEXT |
| [SP-004](#SP-004--GENERAL.RAISE_ERROR) | GENERAL.RAISE_ERROR |

---

### 21.2 Detailed Specifications

#### SP-001 - PR_PASS_PARAM

**Invoked From:**

- vr_fsc_dlr_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

* To Populate List
Press CTRL+L (N/A / CN_MAIN)

---

**Purpose**

Builds the complete report parameter string for the Oracle Reports engine by querying the ED_REPORTS configuration table for the currently active application identifier and principal (company/brand code), then appending the primary dealer parent group, region code, report start date, report end date, comparison dealer parent group, and principal code as named key-value pairs to the output string.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Lv_param | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Lv_param | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Open a cursor over ED_REPORTS, selecting all parameter definitions where the application identifier matches the current block value (CB_BLK.APP_ID) and the principal map code matches the current global principal, ordered by serial number.
- Step 2 - For each parameter definition returned by the cursor, append the primary dealer parent group to the parameter string in the format `P_PARENT='<value>'`.
- Step 3 - Append the region (franchise/outlet) code to the parameter string in the format `P_FOR='<value>'`.
- Step 4 - Append the report start date to the parameter string in the format `P_FROM_DATE='<value>'`.
- Step 5 - Append the report end date to the parameter string in the format `P_TO_DATE='<value>'`.
- Step 6 - Append the comparison dealer parent group to the parameter string in the format `P_OTH_PARENT='<value>'`.
- Step 7 - Append the current global principal (company/brand) code to the parameter string in the format `P_PRINCIPAL='<value>'`.
- Step 8 - Return the fully assembled parameter string to the caller via the IN OUT parameter.

---
**Decision Points**

DP-001

Condition: Does ED_REPORTS contain at least one row matching the current application identifier (CB_BLK.APP_ID) and the current global principal code?

TRUE: The cursor loop executes once per matching row; all six parameter key-value pairs (P_PARENT, P_FOR, P_FROM_DATE, P_TO_DATE, P_OTH_PARENT, P_PRINCIPAL) are appended to the parameter string for each iteration.

FALSE: The cursor loop body does not execute; the parameter string is returned unchanged as received from the caller.

---
**Database Interactions**

- DB-001 - Read ED_REPORTS - Reads data from ED_REPORTS for lookup or validation.
**Business Rules**

- BR-001 - The parameter string must include six named parameters (P_PARENT, P_FOR, P_FROM_DATE, P_TO_DATE, P_OTH_PARENT, P_PRINCIPAL) appended for each row returned from ED_REPORTS, each formatted as a space-separated key='value' pair.
- BR-002 - Parameters are appended in the order defined by the serial number in ED_REPORTS, ensuring the Oracle Reports engine receives them in the correct sequence.
- BR-003 - The ED_REPORTS query must be filtered by both the current application identifier (CB_BLK.APP_ID) and the current global principal code (global.principal) to ensure only configuration rows relevant to the active report context are processed.

---
**Implementation Logic**

```plsql
PROCEDURE PR_PASS_PARAM (Lv_param IN OUT VARCHAR2)
IS
cursor c1 is select param_type,parameter_name,default_value,parameter_datatype
	           from   ed_reports
						 where  app_id =:CB_BLK.APP_ID
						 and principal_map_cd=:global.principal /*added by bhawana*/
						 order by to_number(serial_no);
Lv_frm_date DATE;
Lv_to_date DATE;	
L_AlertID						ALERT;
L_Alert							NUMBER;	
BEGIN
For cur_val in c1 Loop
	lv_param := lv_param||' '||'P_PARENT='''||:P_PARENT||'''';
	lv_param := lv_param||' '||'P_FOR='''||:P_FOR||'''';
	lv_param := lv_param||' '||'P_FROM_DATE='''||:P_FROM_DATE||'''';
  lv_param := lv_param||' '||'P_TO_DATE='''||:P_TO_DATE||'''';
	lv_param := lv_param||' '||'P_OTH_PARENT='''||:P_PARENT_B||''''; 
	lv_param := lv_param||' '||'P_PRINCIPAL='''||:global.principal||''''; /*ADDED BY BHAWANA*/
End Loop;	
lv_param:=lv_param;
END;
```

#### SP-002 - GENERAL.ASK_CONFIRM

**Invoked From:**

- vr_fsc_dlr_fmb.xml [Trigger: FT_CANCEL]
- vr_fsc_dlr_fmb.xml [Trigger: FT_DEL]

---

**Screen:**

* To Populate List
Press CTRL+L (N/A / CN_MAIN)

---

**Purpose**

Displays a configurable confirmation alert (AL_CONFIRM) to the user and returns a numeric flag indicating which button was pressed. Calling triggers use the return value to determine whether to proceed with or abort a destructive or irreversible action (e.g., cancel or delete operations).

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| confirm_msg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the confirmation message text via the input parameter confirm_msg.
- Step 2 - Set the message text of the predefined alert AL_CONFIRM to the value of confirm_msg using SET_ALERT_PROPERTY.
- Step 3 - Display the AL_CONFIRM alert to the user via SHOW_ALERT and capture the button pressed in the local variable p_albtn_pressed.
- Step 4 - Evaluate the captured button response against ALERT_BUTTON1.
- Step 5 - Return 1 if the user pressed ALERT_BUTTON1 (affirmative confirmation), or return 0 for any other button press (negative/cancel response).

---
**Decision Points**

DP-001

Condition:
p_albtn_pressed = ALERT_BUTTON1 (the user pressed the first/affirmative button on the AL_CONFIRM alert)

TRUE:
The function returns 1, signalling to the calling trigger that the user has confirmed the action and processing should proceed.

FALSE:
The function returns 0, signalling to the calling trigger that the user did not confirm the action and the operation should be aborted.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The confirmation alert used must be the predefined alert named AL_CONFIRM; no other alert is permissible within this function.
- BR-002 - The message text presented to the user must be dynamically driven by the confirm_msg input parameter, allowing each calling context (FT_CANCEL, FT_DEL) to supply a context-appropriate message.
- BR-003 - A return value of 1 exclusively represents user affirmation (ALERT_BUTTON1); any other button press must be treated as a non-confirmation and returns 0, ensuring a binary, unambiguous outcome for all callers.

---
**Implementation Logic**

```plsql
FUNCTION ASK_CONFIRM( confirm_msg VARCHAR2)
                                      RETURN  NUMBER IS

    p_alert_name varchar2(10) := 'AL_CONFIRM' ;
    p_albtn_pressed number;
BEGIN
   set_alert_property(p_alert_name,alert_message_text,confirm_msg); 
   p_albtn_pressed := show_alert(p_alert_name);

   IF ( p_albtn_pressed = ALERT_BUTTON1 ) THEN
      return (1);
   ELSE
      return(0);
   END IF;
RETURN NULL; END;
```

#### SP-003 - GENERAL.DISP_TEXT

**Invoked From:**

- DPL.pld [StoredProcedure: GENERAL.RAISE_ERROR]
- vr_fsc_dlr_fmb.xml [Trigger: FT_INSERT]
- vr_fsc_dlr_fmb.xml [Trigger: ON-ERROR]
- vr_fsc_dlr_fmb.xml [Trigger: ON-MESSAGE]
- vr_fsc_dlr_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]
- vr_fsc_dlr_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

* To Populate List
Press CTRL+L (N/A / CN_MAIN)

---

**Purpose**

Displays a message to the user in an Oracle Forms alert dialog. Selects the error alert style when the supplied title is 'ERROR' (case-insensitive) and the information alert style for all other titles. Sets the alert's title and message text at runtime, then displays the alert to the user.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| text_string | VARCHAR2 | IN |
| title_string | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Determine the appropriate alert type: if the supplied title (case-insensitive) is 'ERROR', select the error alert (`AL_ERRINFO`); otherwise select the information alert (`AL_NOTE`).
- Step 2 - Set the selected alert's title property to the supplied title text.
- Step 3 - Set the selected alert's message text property to the supplied message text.
- Step 4 - Display the alert dialog to the user and capture the user's response (button pressed).

---
**Decision Points**

DP-001

Condition: Is the supplied title text equal to 'ERROR' (case-insensitive)?

TRUE: Use the error alert dialog (`AL_ERRINFO`) to display the message.

FALSE: Use the information alert dialog (`AL_NOTE`) to display the message.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Error-titled messages must be displayed using the error alert style (`AL_ERRINFO`); all other titled messages must use the information alert style (`AL_NOTE`).
- BR-002 - The alert's title and message text are set dynamically at runtime from the supplied parameters, allowing any caller to display any message through a single, consistent alert mechanism.

---
**Implementation Logic**

```plsql
PROCEDURE DISP_TEXT (text_string VARCHAR2,
                     title_string VARCHAR2 ) IS 
   p_alert_name varchar2(10) := 'AL_ERRINFO' ; 
   p_alert_id number;
BEGIN
   if upper(title_string)='ERROR' then
      p_alert_name := 'AL_ERRINFO' ; 
   else
      p_alert_name := 'AL_NOTE' ; 
   end if;
   set_alert_property(p_alert_name,TITLE,title_string);  
   set_alert_property(p_alert_name,alert_message_text,text_string);  
   p_alert_id := show_alert(p_alert_name); 
END;
```

#### SP-004 - GENERAL.RAISE_ERROR

**Invoked From:**

- vr_fsc_dlr_fmb.xml [Trigger: ON-ERROR]

---

**Screen:**

N/A

---

**Purpose**

Accepts a message code, constructs a display string by concatenating the code with an (unresolved) message text variable, determines severity from the message type variable, and presents the formatted message to the user via GENERAL.DISP_TEXT (SP-003). For error-type messages, processing is halted by raising a form trigger failure; note-type and caution-type messages are displayed without interrupting the current operation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| mesg_code | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-003](#SP-003--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message code as the sole input parameter; initialise local variables for message type, message text, and message title.
- Step 2 - Construct the full display string by concatenating the message code with the (currently empty) message text variable in the format `<code> : <text>`. Note: the call to GENERAL.get_message that would populate the message type and message text variables is commented out in the active source; both variables therefore remain empty/null at runtime.
- Step 3 - Evaluate the message type variable to determine severity and branch accordingly.
- Step 4 - If the message type is 'E' (Error): set the title to 'Error', invoke GENERAL.DISP_TEXT (SP-003) with the display string and title, then raise FORM_TRIGGER_FAILURE to halt the current operation.
- Step 5 - If the message type is 'N' (Note): set the title to 'Note' and invoke GENERAL.DISP_TEXT (SP-003) with the display string and title; processing continues normally.
- Step 6 - If the message type is 'C' (Caution): set the title to 'Caution' and invoke GENERAL.DISP_TEXT (SP-003) with the display string and title; processing continues normally.
- Step 7 - If the message type matches none of the above values, no display or failure action is taken and the procedure exits silently.

---
**Decision Points**

DP-001

Condition: Is the message type equal to 'E' (Error)?

TRUE: Set title to 'Error', display the message via GENERAL.DISP_TEXT (SP-003), and raise FORM_TRIGGER_FAILURE to stop the current operation.

FALSE: Proceed to DP-002.

DP-002

Condition: Is the message type equal to 'N' (Note)?

TRUE: Set title to 'Note' and display the message via GENERAL.DISP_TEXT (SP-003); do not halt processing.

FALSE: Proceed to DP-003.

DP-003

Condition: Is the message type equal to 'C' (Caution)?

TRUE: Set title to 'Caution' and display the message via GENERAL.DISP_TEXT (SP-003); do not halt processing.

FALSE: No action taken; none of the three severity branches match and the procedure exits without displaying a message.

---
**Database Interactions**

- DB-001 - Read AM_PERMISSIONS - Reads data from AM_PERMISSIONS for lookup or validation.
**Business Rules**

- BR-001 - Error-type messages (type 'E') must halt form processing by raising FORM_TRIGGER_FAILURE immediately after the message is displayed; Note-type ('N') and Caution-type ('C') messages must be displayed without interrupting processing.
- BR-002 - The display title passed to GENERAL.DISP_TEXT (SP-003) must reflect the message severity: 'Error' for type 'E', 'Note' for type 'N', and 'Caution' for type 'C'.
- BR-003 - The display string presented to the user must be formed by concatenating the supplied message code with the message text variable using the separator ' : ', regardless of whether the message text has been resolved.
- BR-004 - Because the GENERAL.get_message lookup is disabled in the active code, the message type variable will be null at evaluation time, meaning no severity branch will match and no message will be displayed unless the lookup is re-enabled.

---
**Implementation Logic**

```plsql
PROCEDURE RAISE_ERROR ( mesg_code IN VARCHAR2 )IS
  mesg_type  varchar2(7); 
  mesg_text  varchar2(200) ;
  mesg_title varchar2(7);
  BEGIN
     -- murali 17.05.04 GENERAL.get_message(mesg_code,mesg_text,mesg_type );
     mesg_text:=mesg_code||' : '||mesg_text;		
     IF ( mesg_type = 'E' ) THEN
        mesg_title := 'Error' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
        raise FORM_TRIGGER_FAILURE;
     ELSIF ( mesg_type = 'N' ) THEN
        mesg_title := 'Note' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     ELSIF ( mesg_type = 'C' ) THEN
        mesg_title := 'Caution' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     END IF;
  END;     

/* PROCEDURE check_rights( 
pi_form_name in varchar2,
pi_user_id in number) IS
lv_x varchar2(1);
BEGIN
	
	begin
	SELECT substr(access_string, pi_user_id,1) 
	INTO   lv_x
	FROM   	am_permissions
	WHERE  form_name = pi_form_name
	AND SUBSTR(access_string,pi_user_id,1)='Y';
	exception 
		when no_data_found then
		  general.disp_text('You do not have the Permission to access this.','Error rr');
		  raise form_trigger_failure; 
		when too_many_rows then
		  general.disp_text('Many rows in USER_PERMISSIONS','Error ss');
		  raise form_trigger_failure;
		when others then
		       general.disp_text(sqlerrm,'Error mm');
		       raise form_trigger_failure;
	end;

	open_form(pi_form_name,activate,session);
END;
*/
```

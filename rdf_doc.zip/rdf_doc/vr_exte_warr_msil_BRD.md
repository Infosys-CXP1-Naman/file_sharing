# BUSINESS REQUIREMENTS DOCUMENT

## Table of Contents

- 1. Document Control
  - 1.1 Document Information
  - 1.2 Revision History
- 2. Executive Summary
  - Key Stakeholders
- 3. System Context
- 4. Functional Requirements
  - 4.1 Business Requirements
    - Requirement ID: BR-001
    - Requirement ID: BR-002
    - Requirement ID: BR-003
    - Requirement ID: BR-004
    - Requirement ID: BR-005
    - Business Scenarios - How column layout differs by EW Status
    - Requirement ID: BR-006
    - Requirement ID: BR-007
    - Requirement ID: BR-008
    - Requirement ID: BR-009
    - Requirement ID: BR-010
    - Requirement ID: BR-011
    - Requirement ID: BR-012
    - Business Scenarios - How the search differs by organisation context
    - Requirement ID: BR-013
    - Business Scenarios - How the export differs by organisation context
    - Requirement ID: BR-014
    - Requirement ID: BR-015
    - Requirement ID: BR-016
    - Requirement ID: BR-017
    - Requirement ID: BR-018
    - Requirement ID: BR-019
- 5. Business Rules Catalogue
- 6. Data Requirements
  - 6.1 Business Entities and Relationships
    - Extended Warranty Sale Record - DMSD_EW_SALE
    - Legacy Extended Warranty Record - VT_EXTSAWA
    - Extended Warranty Policy Master - MWAR_EXTE
    - Dealer Location - AM_DEALER_LOC
    - Entity Relationships
  - 6.2 Data Capture Requirements
    - Search and Filter Criteria (User - at form load and before search)
    - Session / Global Variables (populated at form start - non-database)
  - 6.3 Reference Data
  - 6.4 Data Lifecycle
  - 6.5 Excel Output Columns
- 7. Glossary
- 8. Technical Inventory
  - 8.1 Form Architecture
    - 8.1.1 Global Variables
    - 8.1.2 Form Parameters
  - 8.2 Blocks
    - 8.2.1 Block WhereClause and OrderByClause
  - 8.3 Items Summary
  - 8.4 List of Values
  - 8.5 Alerts
  - 8.6 Program Units
  - 8.7 Triggers
    - 8.7.1 Inactive / Commented-Out Trigger Register
  - 8.8 Canvas and Window Inventory
  - 8.9 Editors
  - 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups
    - 8.10.1 Visual Attributes (form-defined)
    - 8.10.2 Property Classes (form-defined)
    - 8.10.3 Object Groups
  - 8.11 DataSourceColumn Inventory
    - B_EW (29 columns)
- 9. Object Library
- 10. Record Groups
- 11. Referenced Database Objects
- 12. Backend Procedures and Packages
  - 12.1 Main Flow Backend Procedure/Package Index
  - 12.2 Procedure and Package Catalogue
    - PROC_REP_SEARCH_PMC1
    - PROC_REP_SEARCH_PMC2
    - PROC_REP_XL_PMC1
    - PROC_REP_XL_PMC2
    - VIEW_EXCEL_REP
    - CLEAR_ITEMS
    - GENERAL.CHECK_NULL
    - GENERAL.DISP_TEXT
    - GENERAL.L_POPULATE
    - GENERAL.L_POP_LIST_ITEM
    - GENERAL.RAISE_ERROR
    - DBMS_APPLICATION_INFO.SET_CLIENT_INFO
    - DBMS_APPLICATION_INFO.SET_MODULE
    - SF_COPYRIGHT_DECLARATION
    - SF_EW_POLICY_STATUS
    - SF_GET_EW_VALIDITY_DTL
    - WEBUTIL_C_API.ID_NULL
    - WEBUTIL.ERRORALERT
    - WEBUTIL.FCLOSE
    - WEBUTIL.FOPEN
    - WEBUTIL.GETIMPLCLASS
    - WEBUTIL.GETPROPERTY
    - WEBUTIL.GET_LINE
    - WEBUTIL.PUT_LINE
    - WEBUTIL.SETPROPERTY
    - WEB.SHOW_DOCUMENT
- 13. Package Procedure Specifications
- 14. Database Package Catalogue
- 15. PLD Procedure Call Sites
  - DPL.pld (`general`)
  - Inactive / commented-only PLD call sites
  - webutil.pld (`WEBUTIL_C_API`)
  - webutil.pld (`WEBUTIL_FILE`)
  - Inactive / commented-only PLD call sites
  - webutil.pld (`WEBUTIL_FILE_TRANSFER`)
  - Inactive / commented-only PLD call sites
  - webutil.pld (`WEBUTIL_HOST`)
  - Inactive / commented-only PLD call sites
- 16. Microservice API Candidates
  - 16.1 Microservices with APIs
- 17. Workflows
- 18. PLD-Backed Logic
  - DPL.pld (`general`)
  - webutil.pld (`WEBUTIL_C_API`)
  - webutil.pld (`WEBUTIL_FILE`)
  - webutil.pld (`WEBUTIL_FILE_TRANSFER`)
  - webutil.pld (`WEBUTIL_HOST`)
- 19. PCK-Backed Logic
- 20. System Interfaces
  - 20.1 Database Integrations
  - 20.2 External System Integrations
  - 20.3 Report Integrations
    - 20.3.1 Parameters Passed to the Report
- 21. Procedure and Function Business Rule Catalogue
  - 21.1 Catalogue Index
  - 21.2 Detailed Specifications
    - SP-001 - PROC_REP_SEARCH_PMC1
    - SP-002 - PROC_REP_SEARCH_PMC2
    - SP-003 - PROC_REP_XL_PMC1
    - SP-004 - PROC_REP_XL_PMC2
    - SP-005 - VIEW_EXCEL_REP
    - SP-006 - GENERAL.CHECK_NULL
    - SP-007 - GENERAL.DISP_TEXT
    - SP-008 - GENERAL.L_POPULATE
    - SP-009 - GENERAL.L_POP_LIST_ITEM
    - SP-010 - GENERAL.RAISE_ERROR
    - SP-011 - WEBUTIL.ERRORALERT
    - SP-012 - WEBUTIL.FCLOSE
    - SP-013 - WEBUTIL.FOPEN
    - SP-014 - WEBUTIL.GETIMPLCLASS
    - SP-015 - WEBUTIL.GETPROPERTY
    - SP-016 - WEBUTIL.GET_LINE
    - SP-017 - WEBUTIL.ID_NULL
    - SP-018 - WEBUTIL.PUT_LINE
    - SP-019 - WEBUTIL.SETPROPERTY
    - SP-020 - SF_COPYRIGHT_DECLARATION
    - SP-021 - SF_EW_POLICY_STATUS
    - SP-022 - SF_GET_EW_VALIDITY_DTL

## 1. Document Control

### 1.1 Document Information

| Field | Value |
| ----- | ----- |
| Document Title | VR_EXTE_WARR_MSIL - Business Requirements Document |
| Form Module Name | VR_EXTE_WARR_MSIL |
| Document Version | 1.0 |
| Date Created | October 18, 2026 |
| Author/Prepared By | BRD Agent |

### 1.2 Revision History

| Version | Date | Author | Description |
| --- | --- | --- | --- |
| 1.0 | October 18, 2026 | BRD Agent | Initial draft |

---

## 2. Executive Summary

*High-level overview of the vr_exte_warr_msil Extended Warranty Details (MSIL) form, its purpose, and roles referenced in the module.*

The **vr_exte_warr_msil** Oracle Forms module is the **Extended Warranty Details (MSIL)** reporting screen. It enables authorised dealership users to search and review extended warranty contracts sold to customers, and to export those records as a downloadable CSV file. The user selects filter criteria - including region, dealer, date range, vehicle model, variant, warranty type, and policy report type - and then either runs an on-screen search to browse the results or exports the matching records for offline review. The form supports two principal categories: MSIL-branded dealerships and non-MSIL (small-manufacturer) dealerships, with the query logic automatically directed to the appropriate data source based on the user's session context. All filter selections are validated before any search is executed. The results display extended warranty policy details including contract dates, vehicle identification, premium amounts, applicable taxes (both the pre-GST service tax structure and the post-GST CGST/SGST/IGST structure), dealer commission, and contract status. No data entry or modification is supported; this is a read-only enquiry and reporting screen.

### Key Stakeholders

*Who uses vr_exte_warr_msil*

| Stakeholder | Role |
| :--- | :--- |
| **Dealership User** | Primary interactive user. Selects filter criteria, executes the on-screen extended warranty search, reviews the results, and downloads the CSV export for offline analysis. |
| **Customer** | The vehicle owner whose extended warranty contract details are displayed; the customer does not interact with the form directly. |

---

---

## 3. System Context

*Describes the vr_exte_warr_msil module's role within the DMS ecosystem, scope, process flow, and key integrations.*

The **vr_exte_warr_msil** module is the **Extended Warranty Details (MSIL)** enquiry screen within the Dealer Management System (DMS). It provides dealership staff with a single location to search, review, and export extended warranty contracts. The form is launched from the DMS main menu (DPL_MTPL launcher), which supplies the session context - including the current dealer, location, principal code, and financial year - before the screen opens. The module feeds the downstream warranty reconciliation and reporting workflows that dealers use to track sold contracts and commissions.

**System purpose:** Enable dealership users to search extended warranty contract records by applying date, region, dealer, model, variant, and warranty-type filters, review the results on screen, and export the matching data as a CSV file - covering both MSIL and non-MSIL (small-manufacturer) principal categories - as implemented in the vr_exte_warr_msil Oracle Forms module.

**In scope:**

- Display the extended warranty search screen with pre-loaded filter lists (regions, EW types, vendors) based on the user's principal category (MSIL or non-MSIL)
- Accept and validate search filter criteria: sold-from scope, region, dealer, contract date range (maximum 30 days), vehicle model, vehicle variant, extended warranty type, policy report type, payment type, and vendor
- Execute an on-screen search and populate the results grid with up to 12 extended warranty records per page, showing policy details, premium amounts, applicable taxes (pre-GST and post-GST), dealer commission, and contract status
- Adapt results columns and tax display automatically based on whether the contract date falls before or after the GST transition date (01-JUL-2017)
- Support three policy report types: Sale (new contracts), Upgrade/Conversion (plan upgrades), and Cancellation (cancelled contracts)
- Route queries to the MSIL data source (PMC1) or non-MSIL data source (PMC2) based on the session principal code
- Export the current search results as a CSV file and deliver it to the user's browser for download
- Clear and reset all filter criteria via the Cancel button, restoring the form to its initial search state
- Exit the form via the Exit or navigation bar Exit button, returning the user to the DMS main menu

**Process Name:** Extended Warranty Contract Enquiry

**Process Owner:** Dealership Service Manager

**Process Objective:** Open the extended warranty search screen, set filter criteria for the required date range and vehicle scope, execute the search to retrieve matching contracts, review the results, and export the data for offline reporting.

**Process Trigger:** Dealership user opens the Extended Warranty Details screen from the DMS menu to review or report on warranty contracts sold within a date period

**Process Flow:**

The complete extended warranty contract enquiry process follows this sequence. Each step corresponds to Functional Requirements BR-001 through BR-012 in Section 4.

```
STEP 1 ── SCREEN OPENS AND LISTS ARE LOADED (BR-001)
         The dealership user opens the Extended Warranty Details screen from the DMS menu.
         The session context (dealer, location, region, principal category, financial year)
         is supplied by the launcher. Region, warranty type, and vendor dropdown lists
         are populated automatically based on the current principal category.

STEP 2 ── DEFAULT FILTER VALUES ARE SET (BR-001)
         The form pre-sets default values: policy report type to Sale,
         model and variant to All, EW type to All, and the contract date range
         to the current calendar month.

STEP 3 ── USER SELECTS SOLD-FROM SCOPE (BR-002)
         The user selects whether to filter by a specific dealer location or by region.
         Changing this selection clears any previous search results.

STEP 4 ── USER SELECTS REGION (BR-002)
         The user selects a sales region from the region dropdown.
         Changing the region selection clears any previous results.

STEP 5 ── USER SELECTS DEALER (BR-003)
         ├── MSIL: The user selects a dealer from the authorised dealer list filtered by
                   the current parent group.
         └── Non-MSIL: The user also selects the vendor (warranty provider) in addition
                       to the dealer.

STEP 6 ── USER SETS CONTRACT DATE RANGE (BR-004)
         The user enters a contract from-date.
         The system validates that the from-date does not exceed today's date and
         auto-calculates the to-date as the end of the same calendar month (capped at today).
         The tax column display (pre-GST vs. post-GST) is adjusted based on the from-date
         relative to 01-JUL-2017.

STEP 7 ── USER VALIDATES CONTRACT TO-DATE (BR-004)
         The system validates that the to-date does not exceed today or precede the from-date.
         The date range is limited to a maximum of 30 days; an error is raised if exceeded.

STEP 8 ── USER SELECTS VEHICLE MODEL (BR-005)
         The user selects a vehicle base model from the model list, or leaves it as All.
         Changing the model defaults the variant to All.

STEP 9 ── USER SELECTS VEHICLE VARIANT (BR-005)
         The user selects a vehicle variant from the variant list filtered by the selected model,
         or leaves it as All.

STEP 10 ── USER SELECTS EW TYPE (BR-006)
          The user selects a specific extended warranty plan type from the list, or leaves it as All.
          Changing the EW type clears any previous search results.

STEP 11 ── USER SELECTS POLICY REPORT TYPE (BR-007)
          The user selects the policy report type: Sale (new contracts), Upgrade/Conversion,
          or Cancellation. The visible result columns in the grid are adjusted accordingly,
          applying the appropriate pre-GST or post-GST tax column set.

STEP 12 ── USER EXECUTES SEARCH (BR-008)
          The user clicks the Search button.
          ├── MSIL (principal=1): The search queries the MSIL extended warranty sale tables,
                                   including historical records, filtered by all active criteria.
          └── Non-MSIL (principal=2): The search queries the small-manufacturer sale table
                                       with the vendor filter applied.
          Mandatory filter fields are validated before the query runs.
          The total matching record count is displayed below the filter area.

STEP 13 ── RESULTS ARE DISPLAYED (BR-008)
          The results grid shows up to 12 extended warranty records per page, displaying:
          policy number, contract date, vehicle identification number, retail sale date,
          variant, warranty type, customer name, premium, applicable taxes (pre-GST or
          post-GST depending on contract date), dealer commission, created-by user,
          dealer name, location, and contract status.

STEP 14 ── USER EXPORTS TO CSV (BR-009)
          The user clicks the Export to Excel button.
          ├── MSIL (principal=1): The export builds a CSV from the MSIL sale tables
                                   with columns matched to the selected report type.
          └── Non-MSIL (principal=2): The export builds a CSV from the non-MSIL sale table
                                       with vendor-specific columns.
          All mandatory filter fields are validated before the export runs.
          The CSV file is generated on the server and delivered to the user's browser.

STEP 15 ── USER CLEARS AND RESETS (BR-010) - optional
          The user clicks Cancel to clear all search results and reset all filter criteria
          to their default values. The form returns to its initial state ready for a new search.

STEP 16 ── USER EXITS (BR-011)
          The user clicks Exit to close the screen and return to the DMS main menu.
          The session exit flag is set and the form closes without saving.
```

**Major process interactions:**

- **DMS Launcher (DPL_MTPL)** - supplies the session context (dealer, location, region, principal code, financial year) before the screen opens; the form relies on this context to route queries and populate lists
- **Vehicle model and variant master data** - provides the model and variant selection lists used as search filters
- **Dealer and location master data** - provides the authorised dealer list and location codes used in the region and dealer filters
- **Extended warranty contract records** - the primary data source queried by the on-screen search; holds MSIL and non-MSIL warranty sales, upgrades, and cancellation records
- **Application list master data** - supplies the extended warranty type and report type dropdown values
- **CSV file delivery (WebUtil)** - transfers the generated export file from the application server to the user's local machine

---

---

## 4. Functional Requirements

### 4.1 Business Requirements

#### Requirement ID: BR-001

**Requirement Title:** Form Initialization - Session Registration, Field Defaults, and Column Visibility Setup

**Business Description:**
When the Extended Warranty reporting screen opens, the system performs two stages of startup in sequence. First, it registers the current session with the application's performance monitoring so that system administrators can track which module the user is running. Second, once the main screen is displayed, the system populates all search filter fields with their default values (so the user can run a report immediately without setting up from scratch), resolves the applicable copyright notice, maximises the window, and adjusts the visible columns on the results grid to match the default report type and the contract start date, so that the correct tax and premium columns are shown from the outset. For organisations using a second OEM context, the Vendor filter is made visible; otherwise it is hidden.

**Actors:** Dealer User, OEM User

**Preconditions:**
- The user has launched the Extended Warranty reporting module from the application menu.
- The current session's organisation context (principal identity) has been set by the system environment before the screen opens.

**Main Flow:**

**Step 1 - Session registration before the form opens**
Before the screen is displayed to the user, the system records the form's module name and an empty action label in the database application-monitoring tables. This allows operations staff to see which report module is currently active for this session.

The following field visibility assignments described in the `PRE-FORM` trigger code are (COMMENTED OUT / INACTIVE - do not execute): adjusting prompt labels for Sold By, Sale Date, and several field visibility properties. The active portion of `PRE-FORM` executes only the two DBMS_APPLICATION_INFO calls and the field/position setup described below.

The active `PRE-FORM` trigger also sets the following column visibility and layout for the results grid:
- Remarks field: hidden.
- Cancel Amount field: hidden.
- Created By (first) field: visible.
- Sold By field: visible.
- Credit Amount field: hidden.
- Difference columns (Diff.): hidden.
- Service Tax Premium Amount: visible.
- SBC Tax Premium Amount: visible.
- Service Tax Difference Premium Amount: hidden.
- KKC Tax Difference Premium Amount: hidden.
- Debit Amount: hidden.
- KKC Tax Premium Amount: visible.
- Premium Amount: visible.
- SBC Tax Premium Amount: visible.
- Dealer Commission Amount: visible.
- Service Tax on Commission: visible.
- SBC Tax on Commission: visible.
- Status: visible.
- KKC Tax on Commission: visible.
- Column positions are set for the premium and tax columns on the results grid.

**Step 2 - Copyright notice and window setup**
Once the main screen loads, the system retrieves the current-year copyright notice from the application's copyright function and displays it in the footer area of the screen. It then maximises the main window to fill the available screen space.

*Procedures called:*
- **SF_COPYRIGHT_DECLARATION** ([SP-020](#sp-020)) - SF_COPYRIGHT_DECLARATION - Generates and returns the Maruti Suzuki India Limited copyright string for the current financial year. Because the Indian financial year runs April-March, months January through March are attributed to the preceding calendar year, ensuring the copyright notice always reflects the correct fiscal year rather than the raw calendar year.
    * **Step 1** - Records the current system date.
    * **Step 2** - Determines whether the current month falls in the January-March period (the tail end of the Indian financial year that started in the previous calendar year).
    * **Step 3** - If the current month is January, February, or March, builds the copyright string using the previous calendar year as the financial year start.
    * **Step 4** - Otherwise, builds the copyright string using the current calendar year.
    * **Step 5** - Returns the assembled copyright string to the caller.

**Step 3 - EW Type and Region list population**
The EW Type filter drop-down (field `CB_DUMMY.EW_TYPE`) is populated from the record group `EW_TYPE`, which is built from the application's extended warranty type reference list (`AM_LIST`) filtered to the current OEM principal. For the first OEM principal, the type code is shown alongside the description; an *"ALL"* catch-all option is prepended. The Region drop-down (field `CB_DUMMY.CB_REGION`) is populated from the record group `REGION`, which is built from the geographic region master (`GM_REGN`) filtered to the current OEM principal, with an *"All Regions"* option prepended. After loading, the Region field defaults to *"All"*.

*Procedures called:*
- **GENERAL.L_POP_LIST_ITEM** ([SP-009](#sp-009)) - GENERAL.L_POP_LIST_ITEM - Creates or refreshes a named Oracle Forms record group from a caller-supplied SQL query string, ensuring any previous record group of the same name is removed before the new one is populated. This provides a reusable mechanism for loading arbitrary query results into a record group that other form elements (such as list items) can subsequently consume.
    * **Step 1** - Searches for any existing record group with the given name (`EW_TYPE`) and deletes it to start clean.
    * **Step 2** - Creates a new record group from the EW Type query string (filtered by principal, ordered by list_code).
    * **Step 3** - Executes the query and loads the result rows into the record group.
    * **Step 4** - Populates the `CB_DUMMY.EW_TYPE` list item with the `EW_TYPE` record group contents (POPULATE_LIST).
- **GENERAL.L_POP_LIST_ITEM** ([SP-009](#sp-009)) - GENERAL.L_POP_LIST_ITEM - Creates or refreshes a named Oracle Forms record group from a caller-supplied SQL query string, ensuring any previous record group of the same name is removed before the new one is populated. This provides a reusable mechanism for loading arbitrary query results into a record group that other form elements (such as list items) can subsequently consume.
    * **Step 1** - Searches for any existing record group with the given name (`REGION`) and deletes it to start clean.
    * **Step 2** - Creates a new record group from the Region query string (filtered by principal, with *"All Regions"* prepended).
    * **Step 3** - Executes the query and loads the result rows into the record group.
    * **Step 4** - Populates the `CB_DUMMY.CB_REGION` list item with the `REGION` record group contents (POPULATE_LIST).

**Step 4 - Vendor list population**
The Vendor drop-down is populated using the application library's list-population routine, loading the warranty vendor reference list.

*Procedures called:*
- **GENERAL.L_POPULATE** ([SP-008](#sp-008)) - GENERAL.L_POPULATE - Populates a named Oracle Forms list item with code/description pairs retrieved from the `AM_LIST` lookup table for a specified list name and the current principal. Any pre-existing in-memory record group of the same name is deleted before the new one is created, ensuring the list always reflects current data.
    * **Step 1** - Reads the current principal code from the global session variable.
    * **Step 2** - Locates any existing `list` record group and deletes it.
    * **Step 3** - Creates a new record group from a query that selects from the application's list-of-values table filtered by the `WAR_VEND` list name and the current principal.
    * **Step 4** - Executes the query and populates the record group.
    * **Step 5** - Populates the Vendor list item with the record group contents.

**Step 5 - Search criteria field defaults**
The system sets default values for all search filter fields:
- EW Status is set to "New Sales" (N).
- Model is set to "All" (with description "All Models").
- Variant is set to "All" (with description "All Variants").
- EW Type is set to "All".
- The two Difference column headers are set to "Diff."
- Region is set to "All".
- From Date is set to the first day of the current calendar month.
- To Date is set to one calendar month after the From Date minus one day; if that date is in the future, To Date is set to today's date.
- The Dealer Name field and Location field are set to "ALL DEALERS" and "ALL LOCATIONS" respectively, and the supporting hidden fields (location code, parent group, dealer map code) are set to "All", by querying the DUAL table.
- The Dealer Name field's look-up is assigned to the standard dealer LOV.
- The Sold-by / Upgraded-by / Cancelled-by field prompt label is set to "Sold By"; the Sale Date field prompt is set to "Sale Date".

**Step 6 - Difference column and supplementary field visibility**
Visibility of several columns is set as follows (these are the active assignments in `WHEN-NEW-FORM-INSTANCE`, duplicating and finalising what was partially set in `PRE-FORM`):
- Difference columns (Diff.): hidden.
- Cancel Amount: hidden.
- Credit Amount: hidden.
- Created By (hidden field): visible.
- Sold By field: visible.
- Service Tax Premium Amount: visible; SBC Tax Premium Amount: visible; KKC Tax Premium Amount: visible.
- Service Tax Difference / SBC Tax Difference / KKC Tax Difference: hidden.
- Debit Amount: hidden.
- Premium Amount: visible.
- Dealer Commission: visible; Service Tax on Commission: visible; SBC Tax on Commission: visible; KKC Tax on Commission: visible.
- Status: visible.
- Column positions are repositioned for the premium/tax group.
- Remarks: hidden.

**Step 7 - GST column visibility adjustment based on contract start date**
If the current From Date is on or after 1 July 2017 (the GST implementation date), the GST-era columns (IGST, SGST, CGST amounts and commission GST amounts) are made visible, and the pre-GST tax columns (KKC Tax, SBC Tax, Service Tax premium and commission amounts) are hidden. If the From Date is before 1 July 2017, the pre-GST columns are made visible and the GST columns are hidden.

**Step 8 - Vendor filter visibility by principal**
If the current session is running under the second OEM principal (principal code 2), the Vendor filter and the Vendor column in the results grid are made visible. For any other principal, both are hidden.

*Business outcomes (errors, warnings, success, and status):*
- **BR-001-SM-01** - Form opened successfully, all defaults applied and screen layout configured - the Extended Warranty reporting screen is ready for the user to enter filter criteria and run a search.

**Alternative Flows:**
- **BR-001-AF-01** - (from Step 7) If the contract From Date default (first day of current month) is on or after 1 July 2017, the GST column set is shown and the pre-GST column set is hidden. If the default From Date is before 1 July 2017, the pre-GST column set is shown and the GST column set is hidden. This is determined at form load and again whenever the From Date is changed or the EW Status is switched.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Copyright (`COPYRIGHT`) | Auto-populated | Display | 100 | N/A | N/A | Form open | Read-only; derived by copyright function at form load | N/A |
| EW Status (`P_REP_TYPE`) | Auto-populated | List Item | N/A | N/A | N (New Sales), U (Conversions), C (Cancellations) | Form open | Defaults to N; required before search | N/A |
| From Date (`CONT_FROM_DATE`) | Auto-populated | Date | 12 / DD/MM/RRRR | N/A | First day of current month | Form open | Defaults to first day of current month | N/A |
| To Date (`CONT_TO_DATE`) | Auto-populated | Date | 12 / DD/MM/RRRR | N/A | One month after From Date minus one day, or today | Form open | Defaults to month-end or today | N/A |
| Model (`BASE_MODEL_CD`) | Auto-populated | Text | N/A | Vehicle model list (RG_MODEL / LV_MODEL) | All | Form open | Defaults to "All" | N/A |
| Variant (`VARIANT_CD`) | Auto-populated | Text | N/A | Variant list (RG_VARIANT / LV_VARIANT) | All | Form open | Defaults to "All" | N/A |
| EW Type (`EW_TYPE`) | Auto-populated | List Item | N/A | EW Type list (AM_LIST) | All | Form open | Defaults to "All" | N/A |
| Region (`CB_REGION`) | Auto-populated | List Item | N/A | Region list (GM_REGN) | All | Form open | Defaults to "All" | N/A |
| Dealer Name (`DEALER_NAME`) | Auto-populated | Text | 200 | Dealer LOV (LV_DEALER) | ALL DEALERS | Form open | Defaults to "ALL DEALERS" | N/A |
| Location Description (`CB_LOC_DESC`) | Auto-populated | Display | 200 | N/A | ALL LOCATIONS | Form open | Defaults to "ALL LOCATIONS" | N/A |
| Vendor (`VEND`) | Auto-populated | List Item | N/A | Vendor list (WAR_VEND) | N/A | Form open | Visible only for principal 2 sessions | N/A |

---

---

#### Requirement ID: BR-002

**Requirement Title:** Sold From Filter - Results Clear on Channel Change

**Business Description:**
When the user selects a different sales channel filter (for example, switching from "All" to "Workshop" or "Web"), the system immediately clears the results grid and resets the matching-records count to zero. This prevents stale results from a prior search from remaining on screen while the filter criteria have changed. A default value is automatically applied if the channel field is left blank.

**Actors:** Dealer User, OEM User

**Preconditions:**
- The Extended Warranty reporting screen is open and the sales channel filter is available.

**Main Flow:**

**Step 1 - Sales channel changed by user**
The user selects a different value from the sales channel (Sold From) filter drop-down. The system navigates to the results section, clears all records currently displayed in the grid, resets the matching-records counter to zero, and returns focus to the Sold From filter field.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

**Step 2 - Sold From default applied if blank**
When the user moves out of the Sold From filter field, if the field has been left empty, the system automatically sets it to the "All" option.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Sold From must not be blank | WHEN-VALIDATE-ITEM on CB_DUMMY.CB_SOLD_FROM's own condition: if blank, set to 'A' | When the user tabs out of the Sold From field | Ensures the Sold From filter always has a valid value so searches are never run with an undefined channel filter | The field is silently set to "All" (no error shown) |

**Alternative Flows:**
- **BR-002-AF-01** - (from Step 1) The existing `WHEN-LIST-CHANGED` secondary branch (`IF :CB_DUMMY.CB_SOLD_FROM = 'SH'` - set the dealer LOV to a second list variant) is (COMMENTED OUT / INACTIVE - does not execute). The Showroom-specific dealer LOV assignment is not active.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sold From (`CB_SOLD_FROM`) | Conditional - defaults to "All" | List Item | N/A | N/A | All, Workshop (WS), Showroom (SH), Web (WEB) | Form open | Defaults to "All" if left blank | Silent default applied |
| Matching Records (`TOT_REC`) | Auto-populated | Display | N/A | N/A | N/A | Sold From changed | Reset to 0 when Sold From filter changes | N/A |

---

---

#### Requirement ID: BR-003

**Requirement Title:** Region Filter - Results Clear on Region Change and Default Application

**Business Description:**
When the user selects a different geographic region from the region filter, the system immediately clears the results grid and resets the matching-records count to zero, preventing stale search results from remaining visible. If the region field is left blank, the system automatically applies the "All" default so that no search is run with an undefined region scope. A vendor change (on the Vendor filter) also clears the results grid and navigates back to the Region field.

**Actors:** Dealer User, OEM User

**Preconditions:**
- The Extended Warranty reporting screen is open and the Region filter is available.

**Main Flow:**

**Step 1 - Region changed by user**
The user selects a different region from the Region filter drop-down. The system navigates to the results section, clears all records in the grid, resets the matching-records counter to zero, and returns focus to the Region field.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

**Step 2 - Region default applied if blank**
When the user moves out of the Region field, if it is blank, the system automatically sets it to "All".

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Region must not be blank | WHEN-VALIDATE-ITEM on CB_DUMMY.CB_REGION's own condition: if blank, set to 'All' | When the user tabs out of the Region field | Ensures the Region filter always has a valid value so searches are never run without a region scope | The field is silently set to "All" (no error shown) |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Region (`CB_REGION`) | Conditional - defaults to "All" | List Item | N/A | Region list (GM_REGN) | All Regions, individual region codes | Form open | Defaults to "All" if blank | Silent default applied |
| Matching Records (`TOT_REC`) | Auto-populated | Display | N/A | N/A | N/A | Region changed | Reset to 0 when Region filter changes | N/A |

---

---

#### Requirement ID: BR-004

**Requirement Title:** Report Type Selector (Hidden) - Results Clear on Type Change and Default Application

**Business Description:**
A background report-type control (not directly visible to the user) governs the internal report-sub-type selection. When its value changes, the system clears the results grid and moves focus to the Extended Warranty Type filter, ready for the user to refine the selection. If the control is blank, the system applies a default value. This is an internal system control, not a user-visible selection field.

**Actors:** Dealer User, OEM User

**Preconditions:**
- The Extended Warranty reporting screen is open.

**Main Flow:**

**Step 1 - Internal report-type value changed**
When the internal report-type control value changes (triggered programmatically), the system clears the results grid and moves focus to the EW Type filter field.

**Step 2 - Default applied if blank**
When the user moves out of the control, if it is blank, the system automatically sets it to the default value (D).

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Report type control must not be blank | WHEN-VALIDATE-ITEM on CB_DUMMY.CB_REPORT_TYPE's own condition: if blank, set to 'D' | When focus leaves the control | Ensures the hidden report-type control always has a defined value | Silent default applied (no error shown) |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Report Type Control (`CB_REPORT_TYPE`) | Auto-populated | List Item (hidden - visible: false) | N/A | N/A | D (default) | Form open | Hidden field; defaults to D if blank | Silent default applied |

---

---

#### Requirement ID: BR-005

**Requirement Title:** EW Status Selection - Results Column Layout Adjustment and Results Grid Reset

**Business Description:**
When the user selects a different Extended Warranty Status (New Sales, Conversions/Upgrades, or Cancellations), the system immediately adjusts the visible columns in the results grid to match the selected status type, clears any previously displayed results, resets the record count to zero, and returns focus to the EW Status field. The column layout differs by status: New Sales shows standard premium and tax columns with a "Sold By" label; Conversions/Upgrades shows differential premium and conversion-specific columns with an "Upgraded By" label; Cancellations shows the cancel amount, credit amount, and remarks columns with a "Cancelled By" label. From 1 July 2017 onward (GST implementation), the tax columns shown also change based on the contract date: pre-GST columns (Service Tax, SBC, KKC) are shown for earlier dates, while GST columns (IGST, SGST, CGST) are shown for dates on or after 1 July 2017. If the EW Status field is left blank, the system applies the "New Sales" default.

**Actors:** Dealer User, OEM User

**Preconditions:**
- The Extended Warranty reporting screen is open with a contract date already set.

**Main Flow:**

**Step 1 - EW Status changed to New Sales**
When the user selects "New Sales", the system sets field prompt labels to "Sold By" and "Sale Date", hides the Remarks field, hides the Cancel Amount and Credit Amount columns, shows the Created By and Sold By fields, hides the Difference columns (DIFF_P and DIFF_C), sets the difference-premium columns to non-navigable, hides the Debit Amount column, shows the full Premium Amount and standard tax/commission columns. Depending on the contract From Date, the system also adjusts GST/pre-GST column visibility as described in BR-001 Step 7.

**Step 2 - EW Status changed to Conversions/Upgrades**
When the user selects "Conversions/Upgrades", the system sets the field prompt labels to "Upgraded By" and "Conv. Date", shows the Difference columns (DIFF_P and DIFF_C), shows the Debit Amount column, hides the Cancel Amount and Credit Amount columns, shows the Created By and Sold By fields, sets the standard premium columns to non-navigable. Depending on the contract From Date, GST/pre-GST column visibility is adjusted.

**Step 3 - EW Status changed to Cancellations**
When the user selects "Cancellations", the system sets field prompt labels to "Cancelled By" and "Cancel Date", shows the Remarks field, hides the Debit Amount and Credit Amount columns, hides the Created By and Sold By fields, shows the Credit Amount field, hides the Difference columns. The Cancel Amount column is made visible, enabled, and navigable. Depending on the contract From Date, GST/pre-GST column visibility is adjusted.

**Step 4 - Results cleared after EW Status change**
After adjusting column visibility, the system navigates to the results block, clears all rows, resets the matching-records counter to zero, and returns focus to the EW Status field.

**Step 5 - EW Status default if blank**
When the user moves out of the EW Status field, if it is blank, the system automatically sets it to "New Sales".

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| EW Status must not be blank | WHEN-VALIDATE-ITEM on CB_DUMMY.P_REP_TYPE's own condition: if blank, set to 'N' | When the user tabs out of the EW Status field | Ensures the EW Status always has a defined value before a search is run | Silent default applied (no error shown) |

#### Business Scenarios - How column layout differs by EW Status

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **New Sales (N)** | Standard premium, service/SBC/KKC or GST tax, and commission columns shown. Sold By / Sale Date labels. Cancel Amount, Credit Amount, Difference columns hidden. |
| **Conversions/Upgrades (U)** | Difference Premium columns shown; standard Service Tax premium columns hidden. Upgraded By / Conv. Date labels. Debit Amount shown. GST/pre-GST column selection applies based on contract date. |
| **Cancellations (C)** | Cancel Amount and Remarks columns shown. Credit Amount shown. Cancelled By / Cancel Date labels. Debit Amount, Status, Difference columns hidden/non-navigable. GST/pre-GST selection applies based on contract date. |

**Alternative Flows:**
- **BR-005-AF-01** - (from any step) If the contract From Date is on or after 1 July 2017, the GST columns (IGST/SGST/CGST premium and commission) are shown and the pre-GST tax columns (Service Tax, SBC Tax, KKC Tax) are hidden. If the From Date is before 1 July 2017, the pre-GST columns are shown and the GST columns are hidden.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| EW Status (`P_REP_TYPE`) | Conditional - defaults to N | List Item | N/A | N/A | N (New Sales), U (Conversions), C (Cancellations) | Form open | Defaults to N if blank | Silent default applied |
| Matching Records (`TOT_REC`) | Auto-populated | Display | N/A | N/A | N/A | EW Status changed | Reset to 0 when EW Status changes | N/A |

---

---

#### Requirement ID: BR-006

**Requirement Title:** Contract From Date Validation and Auto-Population of To Date

**Business Description:**
When the user enters a contract date range start date, the system checks that the date is not in the future. If it is, the user sees an error and must correct the date. If the From Date is valid and set, the system automatically calculates and sets the To Date to one calendar month later minus one day. If that calculated To Date falls in the future (beyond today), the system caps it at today's date. After setting the To Date, the system also adjusts the visibility of the tax columns in the results grid to reflect whether the date range falls within the GST era (on or after 1 July 2017) or the pre-GST era, using the same logic as the EW Status column adjustment.

**Actors:** Dealer User, OEM User

**Preconditions:**
- The Extended Warranty reporting screen is open.

**Main Flow:**

**Step 1 - From Date entered and validated**
The user enters a contract start date. When focus moves away from the field, the system checks whether the date entered is later than today's date.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| From Date must not be in the future | WHEN-VALIDATE-ITEM on CB_DUMMY.CONT_FROM_DATE: if CONT_FROM_DATE > SYSDATE, call GENERAL.DISP_TEXT with message 'From Date can''t exceed Current Date' and raise FORM_TRIGGER_FAILURE | When the user tabs off the From Date field | Prevents users from running a report for a future date range that has no data | Error *"From Date can't exceed Current Date"* is displayed; field value is not cleared; cursor remains on the field (FORM_TRIGGER_FAILURE raised, form stays open) |

*Business outcomes (errors, warnings, success, and status):*
- **BR-006-ES-01** - From Date entered is later than today - *"From Date can't exceed Current Date"*; the form stays open for correction; cursor remains on the From Date field.

**Step 2 - To Date auto-calculated and capped**
If the From Date is not null, the system calculates the To Date as one calendar month after the From Date minus one day. If this calculated date is in the future (beyond today), the system sets the To Date to today's date instead.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

**Step 3 - GST/pre-GST column visibility adjusted by new From Date**
After the From Date is set, the system applies the same GST-era column visibility logic as described in BR-001 Step 7 and BR-005, adjusting which tax columns are visible in the results grid based on whether the From Date is on or after 1 July 2017.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| From Date (`CONT_FROM_DATE`) | Mandatory | Date | 12 / DD/MM/RRRR | N/A | N/A | Form open | Must not be in the future | *"From Date can't exceed Current Date"*; FORM_TRIGGER_FAILURE |
| To Date (`CONT_TO_DATE`) | Auto-populated | Date | 12 / DD/MM/RRRR | N/A | N/A | From Date entered | Auto-set to From Date + 1 month - 1 day (capped at today if in future) | N/A |

---

---

#### Requirement ID: BR-007

**Requirement Title:** Contract To Date Validation - Range Limit Enforcement

**Business Description:**
When the user enters or modifies the contract end date, the system applies three sequential checks to ensure the date range is valid: the To Date must not be in the future, must not be before the From Date, and the gap between From Date and To Date must not exceed 30 days. Each check shows a specific error message and resets the To Date to the From Date before stopping processing. This prevents users from running reports with overly broad or invalid date ranges.

**Actors:** Dealer User, OEM User

**Preconditions:**
- The Extended Warranty reporting screen is open and a From Date has been entered.

**Main Flow:**

**Step 1 - To Date entered and validated**
The user enters a contract end date. When focus moves away, the system runs three sequential checks in order.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| To Date must not be in the future | WHEN-VALIDATE-ITEM on CB_DUMMY.CONT_TO_DATE: if CONT_TO_DATE > SYSDATE, call GENERAL.DISP_TEXT with message 'To Date can''t exceed Current Date', set CONT_TO_DATE := CONT_FROM_DATE, raise FORM_TRIGGER_FAILURE | When the user tabs off the To Date field | Prevents reports being run for future periods | *"To Date can't exceed Current Date"*; To Date is reset to From Date; FORM_TRIGGER_FAILURE raised |
| To Date must not be before From Date | WHEN-VALIDATE-ITEM on CB_DUMMY.CONT_TO_DATE: if CONT_TO_DATE < CONT_FROM_DATE, call GENERAL.DISP_TEXT with message 'To Date can''t be less than From Date', set CONT_TO_DATE := CONT_FROM_DATE, raise FORM_TRIGGER_FAILURE | Checked after the future-date check passes | Ensures the date range is logically valid (end after start) | *"To Date can't be less than From Date"*; To Date is reset to From Date; FORM_TRIGGER_FAILURE raised |
| Date range must not exceed 30 days | WHEN-VALIDATE-ITEM on CB_DUMMY.CONT_TO_DATE: if (CONT_TO_DATE - CONT_FROM_DATE) > 30, call GENERAL.DISP_TEXT with message 'Contract To Date can''t be more than 30 days after From Date', set CONT_TO_DATE := CONT_FROM_DATE, raise FORM_TRIGGER_FAILURE | Checked only when To Date and From Date are both non-null and To Date is not before From Date | Limits report volume to a 30-day window | *"Contract To Date can't be more than 30 days after From Date"*; To Date is reset to From Date; FORM_TRIGGER_FAILURE raised |

*Business outcomes (errors, warnings, success, and status):*
- **BR-007-ES-01** - To Date is in the future - *"To Date can't exceed Current Date"*; To Date reset to From Date; form stays open.
- **BR-007-ES-02** - To Date is earlier than From Date - *"To Date can't be less than From Date"*; To Date reset to From Date; form stays open.
- **BR-007-ES-03** - Date range is more than 30 days - *"Contract To Date can't be more than 30 days after From Date"*; To Date reset to From Date; form stays open.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| To Date (`CONT_TO_DATE`) | Mandatory | Date | 12 / DD/MM/RRRR | N/A | N/A | From Date entered | Must not be in future; must not precede From Date; must be within 30 days of From Date | Three sequential error messages as described; To Date reset to From Date on each failure |
| From Date (`CONT_FROM_DATE`) | Mandatory | Date | 12 / DD/MM/RRRR | N/A | N/A | N/A | Read-only reference for comparison | N/A |

---

---

#### Requirement ID: BR-008

**Requirement Title:** Model and Variant Filter Default Application

**Business Description:**
When the user clears or leaves the Model or Variant filter fields blank, the system automatically applies the "All" default to each field so that no search is run with an undefined model or variant scope. These defaults ensure the filters always carry a valid value when the user initiates a search.

**Actors:** Dealer User, OEM User

**Preconditions:**
- The Extended Warranty reporting screen is open.

**Main Flow:**

**Step 1 - Model field default applied if blank**
When the user moves out of the Model field after leaving it empty, the system automatically sets it to "All".

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Model must not be blank | POST-TEXT-ITEM on CB_DUMMY.BASE_MODEL_CD: if blank, set to 'All' | When the user moves focus out of the Model field | Ensures the model filter always carries a valid value | Silent default applied (no error shown) |

**Step 2 - Variant field default applied if blank**
When the user moves out of the Variant field after leaving it empty, the system automatically sets it to "All".

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Variant must not be blank | POST-TEXT-ITEM on CB_DUMMY.VARIANT_CD: if blank, set to 'All' | When the user moves focus out of the Variant field | Ensures the variant filter always carries a valid value | Silent default applied (no error shown) |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Model (`BASE_MODEL_CD`) | Conditional - defaults to "All" | Text | N/A | Vehicle model list (RG_MODEL / LV_MODEL) | All | Form open | Defaults to "All" if blank | Silent default applied |
| Variant (`VARIANT_CD`) | Conditional - defaults to "All" | Text | N/A | Variant list (RG_VARIANT / LV_VARIANT) | All | Form open | Defaults to "All" if blank | Silent default applied |

---

---

#### Requirement ID: BR-009

**Requirement Title:** Extended Warranty Type Filter - Results Clear on Type Change and Default Application

**Business Description:**
When the user selects a different Extended Warranty Type from the filter drop-down, the system immediately clears the results grid, resets the matching-records count to zero, and returns focus to the EW Type field. This prevents stale results from remaining on screen after the type filter changes. If the EW Type field is left blank, the system applies the "All" default.

**Actors:** Dealer User, OEM User

**Preconditions:**
- The Extended Warranty reporting screen is open.

**Main Flow:**

**Step 1 - EW Type changed by user**
The user selects a different Extended Warranty Type from the filter list. The system navigates to the results block, clears all records, resets the matching-records counter to zero, and returns focus to the EW Type field.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

**Step 2 - EW Type default applied if blank**
When the user moves out of the EW Type field, if it is blank, the system automatically sets it to "All".

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| EW Type must not be blank | WHEN-VALIDATE-ITEM on CB_DUMMY.EW_TYPE: if blank, set to 'All' | When the user tabs out of the EW Type field | Ensures the EW Type filter always has a valid value | Silent default applied (no error shown) |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| EW Type (`EW_TYPE`) | Conditional - defaults to "All" | List Item | N/A | EW Type list (AM_LIST - EXTE_WARR_TYPE) | All, plus individual EW type codes | Form open | Defaults to "All" if blank | Silent default applied |
| Matching Records (`TOT_REC`) | Auto-populated | Display | N/A | N/A | N/A | EW Type changed | Reset to 0 when EW Type changes | N/A |

---

---

#### Requirement ID: BR-010

**Requirement Title:** Payment Type Filter Default Application

**Business Description:**
The Payment Type filter allows users to narrow results by the method used to pay for the warranty (Offline DMS, EMI, Online). When the field is left blank, the system applies the "Offline DMS" default. Note: the behavior that previously cleared the results grid automatically when this filter changed has been commented out and is currently inactive; changing the Payment Type filter does not automatically clear the results grid in the current version.

**Actors:** Dealer User, OEM User

**Preconditions:**
- The Extended Warranty reporting screen is open.

**Main Flow:**

**Step 1 - Payment Type default applied if blank**
When the user moves out of the Payment Type field without selecting a value, the system automatically sets it to "Offline DMS" (OD).

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Payment Type must not be blank | WHEN-VALIDATE-ITEM on CB_DUMMY.CB_PAYMENT_TYPE: if blank, set to 'OD' | When the user tabs out of the Payment Type field | Ensures a defined payment type is always set for the search | Silent default applied (no error shown) |

**Alternative Flows:**
- **BR-010-AF-01** - (from Step 1) The WHEN-LIST-CHANGED trigger on the Payment Type field (`go_block('b_ew'); clear_block; :CB_DUMMY.TOT_REC := 0; go_item(...)`) is (COMMENTED OUT / INACTIVE - does not execute). Changing the Payment Type does not automatically clear the results grid.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Payment Type (`CB_PAYMENT_TYPE`) | Conditional - defaults to "Offline DMS" | List Item | N/A | N/A | OD (Offline DMS), E (EMI), OE (Online But Not EMI), A (All) | Form open | Defaults to "Offline DMS" if blank | Silent default applied |

---

---

#### Requirement ID: BR-011

**Requirement Title:** Vendor Filter - Results Clear on Vendor Change and Region Default Application

**Business Description:**
When the user selects a different warranty vendor or insurer from the Vendor filter, the system immediately clears the results grid, resets the matching-records counter to zero, and returns focus to the Region filter. This prevents stale results from remaining after the vendor scope changes. The Vendor filter is only visible for sessions running under the second OEM organisational context. When focus leaves the Vendor field, if the Region field is blank, the system automatically sets Region to "All".

**Actors:** OEM User (principal 2 sessions only)

**Preconditions:**
- The Extended Warranty reporting screen is open.
- The current session is running under the second OEM context (Vendor filter is visible).

**Main Flow:**

**Step 1 - Vendor changed by user**
The user selects a different vendor from the Vendor filter drop-down. The system navigates to the results block, clears all records, resets the matching-records counter to zero, and returns focus to the Region filter field.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

**Step 2 - Region default applied when focus leaves Vendor field**
When the user tabs out of the Vendor field, if the Region field is blank, the system sets Region to "All". (Note: the WHEN-VALIDATE-ITEM trigger on the Vendor field checks and defaults the Region field, not the Vendor field itself.)

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Region must not be blank (checked on Vendor field exit) | WHEN-VALIDATE-ITEM on CB_DUMMY.VEND: if CB_REGION is blank, set CB_REGION to 'All' | When the user tabs out of the Vendor filter field | Ensures the Region filter always has a defined value | Silent default applied to Region (no error shown) |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vendor (`VEND`) | Optional | List Item | N/A | Vendor list (WAR_VEND) | N/A | Principal 2 session | Visible only for principal 2 | N/A |
| Region (`CB_REGION`) | Conditional - defaults to "All" | List Item | N/A | Region list (GM_REGN) | All Regions | Form open | Defaults to "All" if blank (checked when leaving Vendor field) | Silent default applied |
| Matching Records (`TOT_REC`) | Auto-populated | Display | N/A | N/A | N/A | Vendor changed | Reset to 0 when Vendor changes | N/A |

---

---

#### Requirement ID: BR-012

**Requirement Title:** Extended Warranty Record Search - Retrieve and Display Results

**Business Description:**
When the user clicks the Search button, the system validates that all required search criteria are filled in, then queries the extended warranty transaction database using the selected filters (date range, region, dealer, location, model, variant, EW type, payment type, sold-from channel, and organisation context). The results are displayed in the on-screen grid showing policy details, premium and tax amounts, dealer and customer information, and policy status. The number of records found is shown in the Matching Records counter. The specific database source and query logic differ depending on whether the current session is running under the first or second OEM organisational context: the first uses a combined query from the primary DMS transaction table and a legacy table; the second uses a separate OEM-specific transaction table.

**Actors:** Dealer User, OEM User

**Preconditions:**
- The Extended Warranty reporting screen is open with search filter fields populated.
- All seven mandatory filter fields (Location, EW Status, From Date, To Date, Model, Variant, EW Type) are filled.

**Main Flow:**

**Step 1 - Search button clicked and organisation context checked**
The user clicks the Search button. The system checks which OEM organisation context the current session is running under. Based on this context, it routes the search to the appropriate query routine.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

**Step 2 - Search executed for first OEM context**
For the first OEM context, the system executes the primary search procedure. This procedure validates all seven mandatory filter fields, then queries extended warranty data from the DMS transaction table and the legacy table, applying all active filter criteria, and loads the results into the display grid.

*Procedures called:*
- **PROC_REP_SEARCH_PMC1** ([SP-001](#sp-001)) - PROC_REP_SEARCH_PMC1 - Validates all mandatory search-criteria fields, then populates the on-screen `B_EW` data block with Extended Warranty policy records from both the live DMS system (`DMSD_EW_SALE` / `MWAR_EXTE`) and the legacy/migrated system (`VT_EXTSAWA`), covering new sales, conversions (upgrades), and cancellations according to the selected report type. Each row is enriched with policy status, warranty type detail, and variant description before display.
    * **Step 1** - Validates that all seven mandatory fields (Location, EW Status, From Date, To Date, Model, Variant, EW Type) are non-null; for any blank field, displays a mandatory-field error and stops.
    * **Step 2** - Determines which transaction type to retrieve (New Sales, Conversions/Upgrades, or Cancellations) based on the selected EW Status.
    * **Step 3** - For New Sales: queries the DMS EW sale table and the legacy EW table, applying all user-selected filters; warranty type is derived by a policy-validity function; policy status is derived by a status function; an upgrade transition code is computed from old and new warranty type pairs.
    * **Step 4** - Navigates to the results grid block, clears it, and positions at the first record.
    * **Step 5** - Loops through all result rows, mapping each field (policy number, VIN, dates, variant, warranty type, customer name, premium, commissions, tax amounts, GST components, dealer details, status, sold-from channel, payment type, conversion status code) to the corresponding display column; looks up variant description for each row (any lookup failure is silently ignored).
    * **Step 6** - Sets the matching-records counter to the total number of rows loaded.
    * **Step 7** - For Conversions/Upgrades: repeats Steps 4-6 using upgrade transaction data from the DMS table; populates conversion-specific fields (conversion date as the contract date, differential premium, conversion tax components).
    * **Step 8** - For Cancellations: repeats Steps 4-6 using cancellation transaction data from both the DMS and legacy tables; cancellation amount is the greater of 10% of premium or 200; credit amount is premium minus commission, service tax commission, SBC tax, and the cancellation fee.
    * **Step 9** - Navigates to the first record in the results grid.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Mandatory field check (7 fields) | Mandatory field check - PROC_REP_SEARCH_PMC1 [SP-001] / GENERAL.CHECK_NULL [SP-006] | When the Search button is clicked | Ensures all required criteria are provided before executing the search query | A mandatory-field error alert is shown naming the blank field; focus moves to that field; search aborts |

**Step 3 - Search executed for second OEM context**
For the second OEM context, the system executes the alternative search procedure. This uses a separate EW transaction table specific to that OEM, applies vendor/insurer filtering, and loads results in the same grid.

*Procedures called:*
- **PROC_REP_SEARCH_PMC2** ([SP-002](#sp-002)) - PROC_REP_SEARCH_PMC2 - Validates all mandatory search-criteria fields, then populates the on-screen `B_EW` data block with Extended Warranty policy records from the PMC2 sales table (`DMSD_EW_SALE_SM`) covering new sales, conversions (upgrades), and cancellations according to the selected report type. Unlike PROC_REP_SEARCH_PMC1 this procedure operates solely on `DMSD_EW_SALE_SM` (no legacy `VT_EXTSAWA` union), supports an extended set of warranty type conversion codes, and applies a vendor-code filter.
    * **Step 1** - Validates that all seven mandatory fields are non-null; for any blank field, displays a mandatory-field error and stops.
    * **Step 2** - Determines transaction type (New Sales, Conversions/Upgrades, or Cancellations) based on EW Status.
    * **Step 3** - For New Sales: queries the second OEM's EW sale table, applying all user-selected filters including vendor code; warranty type code 'X' is decoded to 'VIII' for display; policy status is derived by the status function; an upgrade transition code is computed.
    * **Step 4** - Navigates to the results grid, clears it, and positions at the first record.
    * **Step 5** - Loops through all result rows, mapping each field to the results grid (same layout as the first context, adding vendor code); looks up variant description for each row (any failure silently ignored).
    * **Step 6** - Displays trigger record count and sets the matching-records counter.
    * **Step 7** - For Conversions/Upgrades: repeats Steps 4-6 using upgrade/transfer transaction types from the second OEM's table; populates conversion-specific fields and vendor code.
    * **Step 8** - For Cancellations: repeats Steps 4-6 using cancellation transactions from the second OEM's table; cancellation amount is the greater of 10% of premium or 200.
    * **Step 9** - Navigates to the first record in the results grid.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Mandatory field check (7 fields) | Mandatory field check - PROC_REP_SEARCH_PMC2 [SP-002] / GENERAL.CHECK_NULL [SP-006] | When the Search button is clicked | Ensures all required criteria are provided before executing the search query | A mandatory-field error alert is shown naming the blank field; focus moves to that field; search aborts |

*Business outcomes (errors, warnings, success, and status):*
- **BR-012-ES-01** - A mandatory filter field is blank - an error alert naming the specific blank field (e.g. *"Enter a valid Location"*) is displayed; focus moves to that field; the search does not execute.
- **BR-012-SM-01** - Search completed successfully - the results grid is populated with matching extended warranty records; the Matching Records field shows the count.

#### Business Scenarios - How the search differs by organisation context

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **First OEM context** | Queries DMSD_EW_SALE (DMS table) plus VT_EXTSAWA (legacy table) in a UNION; warranty type derived via EW validity function for New Sales; supports all payment types and sold-from channels |
| **Second OEM context** | Queries DMSD_EW_SALE_SM (second OEM's table) only; vendor code filter applied; warranty type 'X' decoded to 'VIII'; additional conversion types (U, X, Z) supported |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Location Description (`CB_LOC_DESC`) | Mandatory | Display | 200 | Dealer/Location list | N/A | Form open | Must not be blank before search | Mandatory-field error shown; search aborts |
| EW Status (`P_REP_TYPE`) | Mandatory | List Item | N/A | N/A | N, U, C | Form open | Must not be blank before search | Mandatory-field error shown; search aborts |
| From Date (`CONT_FROM_DATE`) | Mandatory | Date | 12 / DD/MM/RRRR | N/A | N/A | Form open | Must not be blank before search | Mandatory-field error shown; search aborts |
| To Date (`CONT_TO_DATE`) | Mandatory | Date | 12 / DD/MM/RRRR | N/A | N/A | From Date set | Must not be blank before search | Mandatory-field error shown; search aborts |
| Model (`BASE_MODEL_CD`) | Mandatory | Text | N/A | Vehicle model list | All | Form open | Must not be blank before search | Mandatory-field error shown; search aborts |
| Variant (`VARIANT_CD`) | Mandatory | Text | N/A | Variant list | All | Form open | Must not be blank before search | Mandatory-field error shown; search aborts |
| EW Type (`EW_TYPE`) | Mandatory | List Item | N/A | EW Type list | All | Form open | Must not be blank before search | Mandatory-field error shown; search aborts |
| Matching Records (`TOT_REC`) | Auto-populated | Display | N/A | N/A | N/A | Search executed | Updated after each search | N/A |

---

---

#### Requirement ID: BR-013

**Requirement Title:** Export Extended Warranty Data to Excel (CSV)

**Business Description:**
When the user clicks the Export to Excel button, the system validates that all required search criteria are filled in, builds a detailed CSV report of extended warranty data matching the same filters used for the on-screen search, writes the file to the report server, and opens it in the user's browser in a new tab. The CSV report includes additional columns beyond what the grid shows: dealer codes, region, employee (service advisor/DSE) details, payment breakdown (facilitation charges, convenience fees, interest, EMI data), standard premium from the OEM price list (for comparison), and upgrade transition codes. As with the search, the specific query and columns differ by OEM context and by the selected EW Status (New Sales, Conversions/Upgrades, or Cancellations).

**Actors:** Dealer User, OEM User

**Preconditions:**
- The Extended Warranty reporting screen is open with search filter fields populated.
- All seven mandatory filter fields (Location, EW Status, From Date, To Date, Model, Variant, EW Type) are filled.

**Main Flow:**

**Step 1 - Export button clicked and organisation context checked**
The user clicks the Export to Excel button. The system checks which OEM organisation context is active and routes to the appropriate export procedure.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

**Step 2 - Export executed for first OEM context**
For the first OEM context, the system executes the first export procedure. This validates mandatory fields, resolves the dealer display name for the report header, builds a dynamic SQL query producing a CSV-formatted result set (with report title, dealer name/date header rows, a column-label row, and data rows), writes the CSV file, and opens it in the browser.

*Procedures called:*
- **PROC_REP_XL_PMC1** ([SP-003](#sp-003)) - PROC_REP_XL_PMC1 - Validates all mandatory search-criteria fields, builds a dynamic SQL query string for the selected report type (new sale, conversion, or cancellation), and exports the results as a CSV file to the application server by calling `VIEW_EXCEL_REP`. The exported file combines data from both the live DMS sales table (`DMSD_EW_SALE`) and the legacy/migrated table (`VT_EXTSAWA`), producing a detailed Excel-ready report with header rows, column titles, and all financial, tax, and EMI fields.
    * **Step 1** - Validates all seven mandatory filter fields; for any blank field, displays a mandatory-field error and stops.
    * **Step 2** - Resolves the dealer display name for the report header: if "All Dealers" is selected, uses the literal "All Dealers (All locations)"; otherwise queries the dealer-location master for the active dealer's name and location description.
    * **Step 3** - Derives the output CSV filename from the current user's ID and the current timestamp.
    * **Step 4** - Computes the exclusive upper-bound date (To Date + 1 day) for the range filter.
    * **Step 5** - For New Sales: builds a dynamic SQL query that UNIONs DMS EW sale records and legacy table records, formatted as CSV rows. The query includes warranty type (via the EW validity function), standard premium from the price master, actual premium, GST/pre-GST tax amounts, commission amounts, employee details (MSPIN, name, designation), sold-from channel, payment type, facilitation/convenience/interest charges, bank cost, EMI tenure, and an EMI difference calculation. Special characters are stripped from customer name and remarks.
    * **Step 6** - For Conversions/Upgrades: builds a CSV query for conversion transaction types from the DMS table, including original and conversion dealer codes, conversion date, model/variant from the VIN master, differential premium, GST/tax amounts, commission amounts, conversion-from channel, payment type, facilitation/convenience/interest charges, employee details, and EMI data.
    * **Step 7** - For Cancellations: builds a CSV query for cancellation transactions from both DMS and legacy tables, including cancellation amount (10% of premium or 200, whichever is greater), GST on cancellation amount, remarks (with line-break and comma characters stripped), employee details, payment type, and EMI data.
    * **Step 8** - Stores the assembled query in the Test field for diagnostic inspection.
    * **Step 9** - Calls the Excel/CSV file-generation routine to execute the query, write each row to the CSV file, and open the file in the browser.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Mandatory field check (7 fields) | Mandatory field check - PROC_REP_XL_PMC1 [SP-003] / GENERAL.CHECK_NULL [SP-006] | When the Export to Excel button is clicked | Ensures all required criteria are provided before generating the export file | A mandatory-field error alert is shown naming the blank field; focus moves to that field; export aborts |

- **VIEW_EXCEL_REP** ([SP-005](#sp-005)) - VIEW_EXCEL_REP - Executes a caller-supplied SQL query, writes its single-column result set line by line to a CSV file on the application server, and then opens the file in the user's browser as a downloadable report. It is the common export engine used by all Excel report procedures in the form.
    * **Step 1** - Derives the output filename from the logged-in user's ID and the current timestamp, appending `.csv`.
    * **Step 2** - If the derived filename contains spaces in a folder name, redirects the file to the `C:\` root drive and displays an informational message.
    * **Step 3** - Clears any pre-existing data record group to start clean.
    * **Step 4** - Creates a new record group from the caller-supplied SQL query and populates it.
    * **Step 5** - Retrieves the row count from the record group.
    * **Step 6** - If the row count exceeds 65,536, caps it at 65,535 and displays a row-limit warning.
    * **Step 7** - Reads the base file path from the server's path configuration file (`/reports/DMS/excelpath.txt`) and appends the filename.
    * **Step 8** - Opens the CSV file for writing on the server.
    * **Step 9** - Locates the record group column and loops through each row, writing each cell value as a CSV line.
    * **Step 10** - Closes the CSV file.
    * **Step 11** - Opens the generated file in the user's browser in a new tab.
    * **Step 12** - On any exception, displays an error message containing the error code and text, then raises a trigger-failure to stop processing.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Row count limit check | Row limit - VIEW_EXCEL_REP [SP-005] internal check: if row count > 65535, cap at 65535 | When the query result set is loaded into the record group | Prevents the export from exceeding the maximum row limit for older Excel/CSV formats | *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."* is shown; export continues with truncated data |
| File path space check | File path check - VIEW_EXCEL_REP [SP-005] internal check: if filename contains spaces, use C:\ | When the filename is derived | Ensures the file can be written to a valid path without spaces causing failures | *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."* is shown; file is written to `C:\` instead |

**Step 3 - Export executed for second OEM context**
For the second OEM context, the system executes the second export procedure. The vendor filter is normalised (if neither 'CWI' nor 'GAN', the vendor filter is set to 'All' internally), and the query includes the vendor code column in the output.

*Procedures called:*
- **PROC_REP_XL_PMC2** ([SP-004](#sp-004)) - PROC_REP_XL_PMC2 - Validates all mandatory search-criteria fields on the Extended Warranty report screen, constructs a report-type-specific dynamic SQL query for new-sale, conversion, or cancellation extended warranty transactions within the given date range and filter criteria, and then exports the result to a user-specific CSV file on the client machine via `VIEW_EXCEL_REP`.
    * **Step 1** - Validates mandatory filter fields; for any blank field, displays an error and stops.
    * **Step 2** - Validates the EW Status, From Date, To Date, Model, Variant, and EW Type fields; for any blank, displays an error and stops.
    * **Step 3** - Validates the Location field; for any blank, displays an error and stops.
    * **Step 4** - Resolves the dealer display name for the report header.
    * **Step 5** - Derives the output filename and computes the exclusive upper-bound date.
    * **Step 6** - Normalises the vendor filter: if the selected vendor is neither "CWI" nor "GAN", sets the internal vendor filter to "All".
    * **Step 7** - Based on the EW Status, builds one of three dynamic SQL queries (New Sales, Conversions, Cancellations) using the second OEM's transaction table, including vendor code in the output columns.
    * **Step 8** - Stores the assembled query in the Test field for diagnostic inspection.
    * **Step 9** - Calls VIEW_EXCEL_REP to execute the query, write the CSV file, and open it in the browser.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Mandatory field check (7 fields) | Mandatory field check - PROC_REP_XL_PMC2 [SP-004] / GENERAL.CHECK_NULL [SP-006] | When the Export to Excel button is clicked | Ensures all required criteria are provided before generating the export file | A mandatory-field error alert is shown naming the blank field; focus moves to that field; export aborts |
| Vendor filter normalisation | Vendor normalisation - PROC_REP_XL_PMC2 [SP-004]: if vendor not in CWI/GAN, set to 'All' | Before query construction | Ensures unrecognised vendor codes are treated as "show all vendors" | Vendor filter silently set to "All" (no error shown) |

*Business outcomes (errors, warnings, success, and status):*
- **BR-013-ES-01** - A mandatory filter field is blank - an error alert naming the specific blank field is displayed; export does not execute.
- **BR-013-WS-01** - *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."* - shown when the result set exceeds the maximum; export continues with truncated data.
- **BR-013-IC-01** - *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."* - shown when the file path contains spaces; file is redirected to `C:\`.
- **BR-013-SM-01** - CSV export file generated successfully - the file is opened in the user's browser as a download/new tab.

#### Business Scenarios - How the export differs by organisation context

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **First OEM context** | Uses DMSD_EW_SALE + VT_EXTSAWA (UNION) for New Sales; DMSD_EW_SALE only for Conversions; DMSD_EW_SALE + VT_EXTSAWA for Cancellations. Warranty type via EW validity function. Includes standard premium from price master, facilitation/convenience/interest/EMI detail, employee (MSPIN + name + designation). |
| **Second OEM context** | Uses DMSD_EW_SALE_SM only. Vendor code included as first column. Vendor filter normalised to CWI/GAN or All. Employee included as Service Advisor/DSE code + name. No legacy VT_EXTSAWA union. |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Location Description (`CB_LOC_DESC`) | Mandatory | Display | 200 | N/A | N/A | Form open | Must not be blank before export | Mandatory-field error shown; export aborts |
| EW Status (`P_REP_TYPE`) | Mandatory | List Item | N/A | N/A | N, U, C | Form open | Must not be blank before export | Mandatory-field error shown; export aborts |
| From Date (`CONT_FROM_DATE`) | Mandatory | Date | 12 / DD/MM/RRRR | N/A | N/A | Form open | Must not be blank before export | Mandatory-field error shown; export aborts |
| To Date (`CONT_TO_DATE`) | Mandatory | Date | 12 / DD/MM/RRRR | N/A | N/A | From Date set | Must not be blank before export | Mandatory-field error shown; export aborts |
| Model (`BASE_MODEL_CD`) | Mandatory | Text | N/A | Vehicle model list | All | Form open | Must not be blank before export | Mandatory-field error shown; export aborts |
| Variant (`VARIANT_CD`) | Mandatory | Text | N/A | Variant list | All | Form open | Must not be blank before export | Mandatory-field error shown; export aborts |
| EW Type (`EW_TYPE`) | Mandatory | List Item | N/A | EW Type list | All | Form open | Must not be blank before export | Mandatory-field error shown; export aborts |
| Vendor (`VEND`) | Optional | List Item | N/A | Vendor list | N/A | Principal 2 session | Vendor normalised to CWI/GAN/All | N/A |

---

---

#### Requirement ID: BR-014

**Requirement Title:** Form-Level Error Interception and Display

**Business Description:**
When a database or application error occurs during any operation on this form, the system intercepts the error and applies a three-way classification: if another user has changed the same record (a concurrent-update conflict), the user sees a specific message asking them to re-query before making changes; if the error is a specific Oracle or Forms numeric error code in a known category (40209, 40207, 50026, 50004), the error type, code, and text are displayed and the operation is stopped; for any other database error (non-zero SQL code), the database's own error message text is displayed and a database rollback is performed. Certain informational codes (40401, 40405) are silently suppressed and do not produce any message.

**Actors:** Dealer User, OEM User

**Preconditions:**
- The Extended Warranty reporting screen is open and a form error or database error has occurred.

**Main Flow:**

**Step 1 - Error intercepted**
An error occurs during a form operation. The ON-ERROR form trigger fires and captures the Forms error code, Forms error text, Forms error type, the database error code, and the database error text.

**Step 2 - Concurrent-update conflict check**
The system checks whether the database error code indicates a concurrency conflict (error code -02292, a foreign key constraint violation used here to signal record-level locking or concurrent modification). If yes, a pre-registered error code lookup (`GENERAL.RAISE_ERROR`) is called to retrieve and display the appropriate message.

*Procedures called:*
- **GENERAL.RAISE_ERROR** ([SP-010](#sp-010)) - GENERAL.RAISE_ERROR - Interprets a message code and its associated type, then presents the corresponding error, note, or caution message to the user via a display dialog. When the message is of type Error, the routine additionally halts further form processing by raising `FORM_TRIGGER_FAILURE`.
    * **Step 1** - Receives the message code passed by the ON-ERROR trigger.
    * **Step 2** - Attempts to look up the message text and type; the lookup is currently commented out, so message text is null and message type is null at runtime.
    * **Step 3** - Because message type is null, none of the Error/Note/Caution branches fire; the procedure exits silently in the current implementation state.

**Step 3 - Known Forms/Oracle error code check**
If the error is not a concurrency conflict but is one of the known Forms/Oracle error codes (40209, 40207, 50026, 50004), the system formats a message string as the error type + dash + error code + colon + error text, displays it using the message-display routine, and raises a trigger failure to abort the current operation.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-007](#sp-007)) - GENERAL.DISP_TEXT - Presents a message to the user through a named Oracle Forms alert dialog, choosing between an error-style alert (`AL_ERRINFO`) and an informational note alert (`AL_NOTE`) based on the supplied title. This centralises all user-facing message display into one reusable routine.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Known error code check | ON-ERROR trigger: if ERROR_CODE in (40209,40207,50026,50004), call GENERAL.DISP_TEXT with errtyp||'-'||errnum||': '||errtxt then raise FORM_TRIGGER_FAILURE | When a known Forms/Oracle error fires during any form operation | Surfaces specific known errors to the user with formatted code and text | Error message displayed; current operation aborted; form stays open |

**Step 4 - Concurrent-update conflict display**
If the Forms error code is in the concurrent-modification set (40654, 40655, 40656, 40657, 40659), the system displays the message "Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save", performs a database rollback, and raises a trigger failure.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-007](#sp-007)) - GENERAL.DISP_TEXT - Presents a message to the user through a named Oracle Forms alert dialog, choosing between an error-style alert (`AL_ERRINFO`) and an informational note alert (`AL_NOTE`) based on the supplied title. This centralises all user-facing message display into one reusable routine.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Concurrent-update conflict | ON-ERROR trigger: if ERROR_CODE in (40654,40655,40656,40657,40659), call GENERAL.DISP_TEXT with 'Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save', rollback, raise FORM_TRIGGER_FAILURE | When a concurrent-modification error fires | Tells the user that another user changed the record; prompts them to re-query | *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"* shown; database rolled back; form stays open |

**Step 5 - Any other database error**
If the SQL code is non-zero (indicating any other database error), the system displays the database's own error message text (`SQLERRM`) using the message-display routine, performs a database rollback, and raises a trigger failure.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-007](#sp-007)) - GENERAL.DISP_TEXT - Presents a message to the user through a named Oracle Forms alert dialog, choosing between an error-style alert (`AL_ERRINFO`) and an informational note alert (`AL_NOTE`) based on the supplied title. This centralises all user-facing message display into one reusable routine.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| General database error | ON-ERROR trigger: if sqlcode <> 0, call GENERAL.DISP_TEXT with sqlerrm, rollback, raise FORM_TRIGGER_FAILURE | When any non-zero SQL error fires | Surfaces unexpected database errors to the user using the actual database error message | The database's own error text displayed; database rolled back; form stays open |

**Step 6 - Informational codes suppressed**
If the error code is 40401 or 40405 (no data found in a query or similar navigation codes), the system takes no action (null processing).

*Business outcomes (errors, warnings, success, and status):*
- **BR-014-ES-01** - Concurrent-update conflict (errors 40654-40659) - *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*; database rolled back.
- **BR-014-ES-02** - Known Forms/Oracle error code (40209, 40207, 50026, 50004) - *"[Error Type]-[Error Code]: [Error Text]"* (dynamic message built from the error type, code, and text at runtime); operation aborted.
- **BR-014-ES-03** - Any other database error (non-zero SQL code) - the database's own error message text (SQLERRM content at the time of the error); database rolled back.

---

---

#### Requirement ID: BR-015

**Requirement Title:** Form Exit - Close the Reporting Screen

**Business Description:**
The user can close the Extended Warranty reporting screen at any time using the keyboard exit shortcut, the Exit button on the toolbar, or the "Exit" navigation button. In all cases, the system first clears the session monitoring entries it registered at startup, then closes the form without prompting for save confirmation (since this is a read-only reporting screen).

**Actors:** Dealer User, OEM User

**Preconditions:**
- The Extended Warranty reporting screen is open.

**Main Flow:**

**Step 1 - Exit initiated via keyboard shortcut or Exit toolbar button**
The user presses the keyboard exit shortcut (KEY-EXIT) or clicks the Exit toolbar button (PB_EXIT). The system first clears the session monitoring entries (client info and module name in the database performance-monitoring tables), then exits the form without save validation.

**Step 2 - Session monitoring cleared**
The system calls the application performance-monitoring package to reset the client information and module name to empty strings, clearing the registration set at form startup.

**Step 3 - Form closed without save prompt**
The system exits the form, bypassing save validation (EXIT_FORM(NO_VALIDATE)). The reporting screen closes.

**Step 4 - Exit via NB_EXIT navigation button**
When the user clicks the "Exit" navigation button (NB_EXIT), the system sets the global exit flag to "EXIT" and then exits the form without save validation. (This is a separate code path from the toolbar exit, executed by the WHEN-BUTTON-PRESSED trigger on NB_EXIT.)

**Step 5 - Exit via NB_OK navigation button**
When the user clicks the "OK" navigation button (NB_OK), the system immediately closes the form without save validation (Exit_form(no_validate)).

**Alternative Flows:**
- **BR-015-AF-01** - (from Step 1 via KEY-EXIT keyboard shortcut) If the system is in "Enter Query" mode at the time the keyboard shortcut is fired, the shortcut delegates to the EXIT_FORM key action (`DO_KEY('EXIT_FORM')`), which closes the form.
- **BR-015-AF-02** - (from Step 1 via PB_EXIT toolbar button) Regardless of whether the form status is "CHANGED" or not, the toolbar button always closes the form via `DO_KEY('EXIT_FORM')`. (The code for the PB_EXIT button has both a form-status check and an Enter-Query check, but both branches call `DO_KEY('EXIT_FORM')`.)

---

---

#### Requirement ID: BR-016

**Requirement Title:** Form Reset - Clear Results and Reinitialize Filter Criteria

**Business Description:**
The user can reset the reporting screen to its initial state - clearing the results grid and reinitializing all filter fields to their defaults - using the keyboard clear-form shortcut, the Cancel toolbar button, or the Clear navigation button. After clearing, the EW Status is reset to "New Sales", and certain column visibility settings are restored. The Cancel button path additionally re-runs the form-initialization sequence so that all defaults (dates, filter values, list contents, and copyright notice) are reapplied exactly as at form startup.

**Actors:** Dealer User, OEM User

**Preconditions:**
- The Extended Warranty reporting screen is open.

**Main Flow:**

**Step 1 - Clear initiated via keyboard shortcut (KEY-CLRFRM)**
The user presses the keyboard clear-form shortcut. The system clears the form (no validate), then resets the EW Status field to "New Sales" (P_REP_TYPE = 'N') and restores the Debit Amount and Created By columns to visible.

**Step 2 - Cancel initiated via toolbar Cancel button or FT_CANCEL**
When the Cancel toolbar button is pressed (PB_CANCEL -> EXECUTE_TRIGGER('FT_CANCEL')), or the FT_CANCEL function-key trigger fires, the system checks whether the Cancel button is currently enabled.

If the Cancel button is enabled:
- The system clears the form (clear form, no validate) regardless of whether the form status is "CHANGED" or not.
- After clearing, the system re-runs the form-initialization sequence (EXECUTE_TRIGGER('WHEN-NEW-FORM-INSTANCE')), which reapplies all startup defaults (copyright notice, window size, list population, filter defaults, date defaults, column visibility, GST/pre-GST layout, vendor filter visibility).
- Additionally, the Cancel button press also sets the prompt labels: the Sold By field prompt is set to "Sold By", the Sale Date field prompt is set to "Sale Date", and the Remarks field is set to hidden.

If the Cancel button is not enabled: no action is taken (null).

**Step 3 - Clear initiated via NB_CLEAR navigation button**
When the user clicks the Clear navigation button (NB_CLEAR), the system navigates to the results grid block and clears it (no validate), then navigates to the search criteria block and clears it (no validate).

*Business outcomes (errors, warnings, success, and status):*
- **BR-016-SM-01** - Screen reset successfully - all filter fields return to their default values; results grid is cleared; the screen is ready for a new search.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| EW Status (`P_REP_TYPE`) | Auto-populated | List Item | N/A | N/A | N (reset default) | Form reset | Reset to New Sales when the form is cleared | N/A |

---

---

#### Requirement ID: BR-017

**Requirement Title:** Value Look-up Invocation from Search Filter Fields

**Business Description:**
When the user presses the List Values key or clicks the List toolbar button, the system checks whether the current field has an associated look-up list. If it does, the system opens the look-up dialogue at a fixed position on screen and waits for the user's selection. When the user selects a value, the system navigates to the next field. If the field has no look-up list, the system takes no action. The List toolbar button also checks that the List button is enabled before delegating to the standard list-values action.

**Actors:** Dealer User, OEM User

**Preconditions:**
- The Extended Warranty reporting screen is open and the cursor is in a field that supports a look-up list (e.g. Dealer Name, Model, Variant).

**Main Flow:**

**Step 1 - List Values key pressed (KEY-LISTVAL)**
The user presses the List Values key. The system reads the LOV name associated with the current field. If a LOV name exists, the system invokes the list dialogue at coordinates (200, 120). If the user selects a value (SHOW_LOV returns true), the system moves focus to the next field. If no LOV is associated with the current field, the system takes no action.

**Step 2 - List toolbar button clicked (PB_LIST -> FT_LIST)**
When the user clicks the List toolbar button, the button triggers FT_LIST (via EXECUTE_TRIGGER). FT_LIST checks whether the List button is enabled. If enabled, it delegates to the standard list-values action (`DO_KEY('LIST_VALUES')`). If the button is not enabled, no action is taken.

---

---

#### Requirement ID: BR-018

**Requirement Title:** Toolbar Button Functions - Inactive and Platform Operations

**Business Description:**
The form includes a standard toolbar with several buttons beyond Exit, Cancel, Clear, Search, Export, and List. The Save, Insert, Delete, and Print buttons are present on the toolbar but their underlying function-key triggers are currently inactive and perform no operation. The Cut, Copy, and Paste buttons invoke the standard clipboard operations. These are documented here to account for all active toolbar item triggers on the form.

**Actors:** Dealer User, OEM User

**Preconditions:**
- The Extended Warranty reporting screen is open.

**Main Flow:**

**Step 1 - Save button clicked (PB_SAVE)**
The user clicks the Save button. The button delegates to FT_SAVE via EXECUTE_TRIGGER. FT_SAVE contains only `null` - (INACTIVE - does not execute). No save or commit occurs.

**Step 2 - Insert button clicked (PB_INSERT)**
The user clicks the Insert button. The button delegates to FT_INSERT via EXECUTE_TRIGGER. FT_INSERT body is entirely commented out and is null - (COMMENTED OUT / INACTIVE - does not execute). No record insertion occurs.

**Step 3 - Delete button clicked (PB_DEL)**
The user clicks the Delete button. The button delegates to FT_DEL via EXECUTE_TRIGGER. FT_DEL contains only `null` - (INACTIVE - does not execute). No record deletion occurs.

**Step 4 - Print button clicked (PB_PRINT)**
The user clicks the Print button. The button delegates to FT_PRINT via EXECUTE_TRIGGER. FT_PRINT contains only `null` - (INACTIVE - does not execute). No print action occurs.

**Step 5 - Cut / Copy / Paste buttons clicked**
The Cut button (PB_CUT) invokes `Cut_region`; the Copy button (PB_COPY) invokes `copy_region`; the Paste button (PB_PASTE) invokes `paste_region`. These are standard Oracle Forms clipboard operations with no custom business logic.

---

---

#### Requirement ID: BR-019

**Requirement Title:** Inactive Triggers - Non-Executing Form Code Register

**Business Description:**
The following form-level triggers exist in the form code but are entirely inactive (commented out or contain only a null body) and do not execute. They are documented here for completeness and traceability, as required by the technical inventory, but they contribute no live business behavior.

**Actors:** N/A (inactive code - does not execute)

**Preconditions:**
N/A - inactive code; no preconditions apply.

**Main Flow:**

**Step 1 - Inactive triggers (COMMENTED OUT / INACTIVE - do not execute)**
The following triggers are present but non-executing:

- `ON-MESSAGE` (Form level) - entirely commented out - (COMMENTED OUT / INACTIVE - does not execute). This trigger would have suppressed or reformatted certain Forms informational messages (error codes 40209 and 40207), but the entire body is commented out. Standard Forms message handling applies.
- `KEY-COMMIT` (Form level) - contains only `null;` - (INACTIVE - does not execute). A save/commit/clear-form sequence is commented out; no save, commit, or clear occurs when this key is pressed.
- `KEY-OTHERS` (Form level) - has a null body - (INACTIVE - does not execute).
- `KEY-NEXT-ITEM`, `KEY-PREV-ITEM`, `KEY-NXTBLK`, `KEY-PRVBLK`, `KEY-DOWN` (Form level), `KEY-UP` (Form level) - all have null or empty bodies - (INACTIVE - do not execute).
- `KEY-DOWN` (CB_DUMMY block level), `KEY-UP` (CB_DUMMY block level) - both have null bodies - (INACTIVE - do not execute).
- `FT_INSERT` (Form level) - body is entirely commented out - (COMMENTED OUT / INACTIVE - does not execute).
- `FT_SAVE` (Form level) - contains only `null;` - (INACTIVE - does not execute).
- `FT_DEL` (Form level) - contains only `null;` - (INACTIVE - does not execute).
- `FT_PRINT` (Form level) - contains only `null;` - (INACTIVE - does not execute).
- `WHEN-VALIDATE-ITEM` on `B_EW.EXTE_POLICY_NO` - body is commented out (`null;`) - (COMMENTED OUT / INACTIVE - does not execute).

---

- Form Program Unit `CLEAR_ITEMS` - declared as a procedure but has an empty body (no statements between BEGIN and END); it is never called from any trigger or program unit and performs no action - (INACTIVE stub - does not execute).


**Note on B_EW results grid display format triggers:**
The following trigger names on B_EW items contain only Oracle Forms display format masks (not executable PL/SQL business logic) and are therefore represented as Field Length/Format properties in the Data Elements tables of the relevant BRs rather than as separate functional requirements:
- `EXTE_CONTRACT_DATE`, `EXTE_RETLSALE_DT` - date format `mm/dd/rrrr`
- `EXTE_PREMIUM`, `SERV_TAX_PREM_AMT`, `SBC_TAX_PREM_AMT`, `KKC_TAX_PREM_AMT`, `SERV_TAX_DIFF_PREM_AMT`, `SBC_TAX_DIFF_PREM_AMT`, `KKC_TAX_DIFF_PREM_AMT`, `EXTE_PREM_SRV_TAX`, `EXTE_PREM_SBC_TAX`, `EXTE_PREM_KKC_TAX`, `EXTE_CANCEL_AMT`, `EXTE_PREM_IGST_AMT`, `EXTE_PREM_SGST_AMT`, `EXTE_PREM_CGST_AMT`, `EXTE_PREM_COMM_IGST`, `EXTE_PREM_COMM_SGST`, `EXTE_PREM_COMM_CGST` - numeric format `99999999999.99`
- `CONT_FROM_DATE`, `CONT_TO_DATE` (item-level format triggers on CB_DUMMY) - date format `DD/MM/RRRR`
These are display format properties stored as Oracle Forms trigger XML; they contain no executable PL/SQL statements.

---

## 5. Business Rules Catalogue

Catalogue of the discrete business rules enforced by the form's code. All conditions and actions are written in business-friendly plain English. Every rule is grounded in real trigger/program-unit evidence.

| Rule ID | Rule Name | Rule Type | Business Requirement ID | Condition | Action | Business Impact |
| ------- | --------- | --------- | ----------------------- | --------- | ------ | --------------- |
| BRC-001 | From Date cannot be in the future | Validation | BR-006 | The contract start date entered by the user is later than today's date | Display error *"From Date can't exceed Current Date"* and stop processing; cursor remains on the From Date field (FORM_TRIGGER_FAILURE) | Prevents reports from being generated for future periods that have no transaction data |
| BRC-002 | From Date auto-sets To Date | Derivation | BR-006 | The contract start date is entered and is not blank | Automatically calculate the To Date as one calendar month after the From Date minus one day; if the calculated To Date exceeds today, cap it at today's date | Saves the user from manually calculating the standard one-month range; ensures the default range never extends into the future |
| BRC-003 | From Date drives GST column visibility | Derivation | BR-006, BR-001, BR-005 | The contract start date is on or after 1 July 2017 | Make the GST-era tax columns (IGST, SGST, CGST amounts and commission GST) visible and hide the pre-GST columns (Service Tax, SBC Tax, KKC Tax amounts) | Ensures the results grid always shows the tax column set that applies to the selected reporting period, avoiding confusion between pre-GST and GST-era data |
| BRC-004 | To Date cannot be in the future | Validation | BR-007 | The contract end date entered by the user is later than today's date | Display error *"To Date can't exceed Current Date"*, reset To Date to the From Date, and stop processing (FORM_TRIGGER_FAILURE) | Prevents reports for future periods |
| BRC-005 | To Date cannot precede From Date | Validation | BR-007 | The contract end date is earlier than the contract start date | Display error *"To Date can't be less than From Date"*, reset To Date to the From Date, and stop processing (FORM_TRIGGER_FAILURE) | Ensures the date range is logically consistent (end must be on or after start) |
| BRC-006 | Date range must not exceed 30 days | Validation | BR-007 | The difference between the contract end date and the contract start date is greater than 30 days | Display error *"Contract To Date can't be more than 30 days after From Date"*, reset To Date to the From Date, and stop processing (FORM_TRIGGER_FAILURE) | Limits each report to a maximum 30-day window to control report size and system load |
| BRC-007 | Sold From defaults to All | Derivation | BR-002 | The Sold From filter field is blank when the user moves off it | Silently set the Sold From field to "All" | Ensures the Sold From filter always has a defined value before a search is run |
| BRC-008 | Region defaults to All | Derivation | BR-003 | The Region filter field is blank when the user moves off it | Silently set the Region field to "All" | Ensures the Region filter always has a defined value before a search is run |
| BRC-009 | Report Type (hidden) defaults to D | Derivation | BR-004 | The hidden report-type control is blank when the user moves off it | Silently set the hidden report-type control to "D" | Ensures the internal report-type control always has a defined value |
| BRC-010 | EW Status defaults to New Sales | Derivation | BR-005 | The EW Status field is blank when the user moves off it | Silently set EW Status to "New Sales" | Ensures the EW Status always has a defined value before a search is run |
| BRC-011 | Model defaults to All | Derivation | BR-008 | The Model filter field is blank when the user moves off it | Silently set the Model field to "All" | Ensures the model filter always has a valid value before a search |
| BRC-012 | Variant defaults to All | Derivation | BR-008 | The Variant filter field is blank when the user moves off it | Silently set the Variant field to "All" | Ensures the variant filter always has a valid value before a search |
| BRC-013 | EW Type defaults to All | Derivation | BR-009 | The EW Type filter field is blank when the user moves off it | Silently set the EW Type field to "All" | Ensures the EW Type filter always has a valid value before a search |
| BRC-014 | Payment Type defaults to Offline DMS | Derivation | BR-010 | The Payment Type filter field is blank when the user moves off it | Silently set the Payment Type field to "Offline DMS" | Ensures the payment type filter always has a defined default value |
| BRC-015 | Location is mandatory for search | Validation | BR-012, BR-013 | The Location field is blank when the user clicks Search or Export to Excel | Display a mandatory-field error alert naming "Location" and navigate focus to the Location field; abort the search or export | Prevents the search/export from running without a location filter, ensuring data is always scoped to a valid dealership selection |
| BRC-016 | EW Status is mandatory for search | Validation | BR-012, BR-013 | The EW Status field is blank when the user clicks Search or Export to Excel | Display a mandatory-field error alert naming "Extended Warranty Status" and navigate focus to the EW Status field; abort the search or export | Ensures the report always covers exactly one EW transaction type per run |
| BRC-017 | From Date is mandatory for search | Validation | BR-012, BR-013 | The From Date field is blank when the user clicks Search or Export to Excel | Display a mandatory-field error alert naming "Contract From Date" and navigate focus to the From Date field; abort the search or export | Prevents open-ended date range queries that would return all historical records |
| BRC-018 | To Date is mandatory for search | Validation | BR-012, BR-013 | The To Date field is blank when the user clicks Search or Export to Excel | Display a mandatory-field error alert naming "Contract To Date" and navigate focus to the To Date field; abort the search or export | Prevents unbounded date range queries |
| BRC-019 | Model is mandatory for search | Validation | BR-012, BR-013 | The Model field is blank when the user clicks Search or Export to Excel | Display a mandatory-field error alert naming "Model" and navigate focus to the Model field; abort the search or export | Ensures a model selection (even "All") is explicitly confirmed before the search runs |
| BRC-020 | Variant is mandatory for search | Validation | BR-012, BR-013 | The Variant field is blank when the user clicks Search or Export to Excel | Display a mandatory-field error alert naming "Variant" and navigate focus to the Variant field; abort the search or export | Ensures a variant selection (even "All") is explicitly confirmed |
| BRC-021 | EW Type is mandatory for search | Validation | BR-012, BR-013 | The EW Type field is blank when the user clicks Search or Export to Excel | Display a mandatory-field error alert naming "Extended Warranty Type" and navigate focus to the EW Type field; abort the search or export | Ensures an EW type selection (even "All") is explicitly confirmed |
| BRC-022 | OEM context routes to different search | Authorization | BR-012 | The current session is running under the first OEM organisational context | Execute the PMC1 search procedure using the primary DMS transaction table and the legacy EW table | Ensures each OEM's data is retrieved from its own dedicated database tables; (WF-001) |
| BRC-023 | OEM context routes to different search | Authorization | BR-012 | The current session is running under the second OEM organisational context | Execute the PMC2 search procedure using the second OEM's dedicated transaction table | Ensures each OEM's data is retrieved from its own dedicated database tables; (WF-001) |
| BRC-024 | OEM context routes to different export | Authorization | BR-013 | The current session is running under the first OEM organisational context | Execute the PMC1 export procedure; the output includes legacy data and standard EW premium comparisons | Ensures the first OEM's export uses its specific data sources and enriched column set; (WF-002) |
| BRC-025 | OEM context routes to different export | Authorization | BR-013 | The current session is running under the second OEM organisational context | Execute the PMC2 export procedure; the vendor filter is normalised; the output includes vendor code as the first column | Ensures the second OEM's export uses its specific data sources and vendor-specific column set; (WF-002) |
| BRC-026 | Excel row limit enforcement | Constraint | BR-013 | The number of data rows in the export query result set exceeds 65,536 | Cap the export at 65,535 rows and display informational message *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."* | Prevents CSV file corruption and browser/Excel failures from oversized output |
| BRC-027 | File path space validation | Validation | BR-013 | The constructed CSV file path contains a space character in one of the folder names | Redirect the output file to the `C:\` root drive and display *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."* | Prevents file-write failures caused by spaces in server-side folder paths |
| BRC-028 | Concurrent-update conflict interception | Validation | BR-014 | A database concurrency conflict error occurs (Oracle error codes 40654-40659) | Display *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*, perform a database rollback, and stop processing (FORM_TRIGGER_FAILURE) | Protects data integrity by detecting and surfacing record-locking conflicts to the user |
| BRC-029 | Known error code display | Validation | BR-014 | A known Oracle/Forms error code (40209, 40207, 50026, 50004) fires | Display the error as a formatted message (error type + error code + error text) and stop processing (FORM_TRIGGER_FAILURE) | Surfaces actionable information about known system errors to the user |
| BRC-030 | General database error display and rollback | Validation | BR-014 | Any other database error fires (non-zero SQL code) | Display the database's own error message text and perform a database rollback; stop processing (FORM_TRIGGER_FAILURE) | Prevents silent data corruption by rolling back incomplete operations and informing the user of unexpected database errors |
| BRC-031 | EW Status layout - New Sales column set | Derivation | BR-005 | EW Status is changed to "New Sales" | Apply the New Sales column layout: show standard premium and tax columns with "Sold By" / "Sale Date" labels; hide Difference, Cancel Amount, and Credit Amount columns | Ensures the results grid shows the correct columns for the selected report type, avoiding misleading empty or mismatched columns |
| BRC-032 | EW Status layout - Conversions column set | Derivation | BR-005 | EW Status is changed to "Conversions/Upgrades" | Apply the Conversions column layout: show Difference Premium columns and Debit Amount with "Upgraded By" / "Conv. Date" labels; hide standard Service Tax columns | Ensures the grid is configured for conversion-specific amounts and labels |
| BRC-033 | EW Status layout - Cancellations column set | Derivation | BR-005 | EW Status is changed to "Cancellations" | Apply the Cancellations column layout: show Cancel Amount, Credit Amount, and Remarks columns with "Cancelled By" / "Cancel Date" labels; hide Status, Debit Amount, and standard commission columns | Ensures the grid shows cancellation-specific amounts and remarks |
| BRC-034 | Vendor filter visible for second OEM only | Authorization | BR-001, BR-011 | The current session is running under the second OEM organisational context (principal code 2) | Make the Vendor filter and Vendor results column visible | Ensures the vendor/insurer filter is only available in the OEM context where it is applicable |
| BRC-035 | Second OEM export vendor normalisation | Derivation | BR-013 | The vendor filter value for a second OEM export is neither "CWI" nor "GAN" | Set the internal vendor filter to "All" before building the export query | Ensures unrecognised vendor codes are treated as "show all vendors" in the export, preventing empty result sets from invalid vendor codes |

**Total Business Rules Identified: 35**

---

## 6. Data Requirements

*This form supports an extended warranty reporting function. It uses a filter block to capture search criteria, queries extended warranty transaction data from DMS and legacy sources, and displays the results in a read-only grid. No data is inserted or updated by end-user action; the form is purely a reporting and export tool.*

### 6.1 Business Entities and Relationships

*The form reads data from two extended warranty transaction tables (DMS-sourced and legacy), joins to dealer-location and vehicle master data, and populates a display-only results block.*

#### Extended Warranty Sale Record - DMSD_EW_SALE

The primary DMS transaction table for extended warranty policies. The form reads new-sale, conversion/upgrade, and cancellation transactions from this table, filtering on transaction type (`EXTE_TRAN_TYPE`), transaction date, region, dealer, location, model, variant, EW type, payment type, and sold-from channel. This is a read-only data source within this form.

#### Legacy Extended Warranty Record - VT_EXTSAWA

A legacy extended warranty source table. The form queries this table in parallel with DMSD_EW_SALE and UNIONs the results for new-sale and cancellation report types (PMC1 principal only). Only new sales and cancellations from this source are included; it is a read-only data source.

#### Extended Warranty Policy Master - MWAR_EXTE

A policy-level master table joined to DMSD_EW_SALE and VT_EXTSAWA on `EXTE_POLICY_NO`. Provides model code, variant code, created-by / modified-by / cancelled-by user fields, remarks, warranty type for the policy, and other policy attributes used in the report output. Read-only.

#### Dealer Location - AM_DEALER_LOC

Provides dealer name, location description, region code, parent group, and dealer-map code for the selected dealer/location filter. Joined to warranty transaction records on parent group, dealer-map code, and location code, and filtered to the current principal's dealers. Also used in the record group `RG_LOC` to populate the Location filter drop-down. Read-only.

#### Entity Relationships

The form navigates from a dealer location filter to extended warranty transactions and then to the policy master. DMSD_EW_SALE and VT_EXTSAWA each join to MWAR_EXTE on policy number, and both join to AM_DEALER_LOC on dealer/location identifiers. MWAR_EXTE is the policy master; DMSD_EW_SALE and VT_EXTSAWA are the transaction records linked to it.

```
AM_DEALER_LOC (Dealer/Location master)
        └── DMSD_EW_SALE (DMS EW transactions)
                └── MWAR_EXTE (EW policy master)
        └── VT_EXTSAWA (Legacy EW transactions)
                └── MWAR_EXTE (EW policy master)
```

### 6.2 Data Capture Requirements

*Users enter search filters only; the results displayed in the grid are read-only. No extended warranty data is written by this form. The search criteria block captures the reporting parameters used to query the underlying data.*

#### Search and Filter Criteria (User - at form load and before search)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Sold From (`CB_SOLD_FROM`) | Conditional | Filters results by the channel through which the warranty was sold: All, Workshop, Showroom, or Web. Defaults to the first available option on form load. | If left blank at validation, the system applies the default value. |
| Region (`CB_REGION`) | Conditional | Filters results by the dealer's geographic region. Defaults to "All Regions" on form load. | If left blank at validation, defaults to "All". Clearing the results area when changed. |
| Dealer (`DEALER_NAME`) | Yes | Identifies the dealer for which the report is generated; selected via a dealer look-up. Defaults to "ALL DEALERS" on form load. | Must be selected before running a search. Location field is populated from the same look-up. |
| Location Description (`CB_LOC_DESC`) | Yes | The specific dealer outlet/location. Defaults to "ALL LOCATIONS" on form load. | The search and export procedures validate this field as non-null before executing; an error alert is displayed if blank. |
| EW Status / Report Type (`P_REP_TYPE`) | Yes | Determines which extended warranty transaction type is reported: New Sales (N), Conversions/Upgrades (U), or Cancellations (C). Controls which columns are shown in the results. Defaults to New Sales on form load. | The search and export procedures validate this field as non-null. If blank, defaults to "N". |
| From Date (`CONT_FROM_DATE`) | Yes | Start date for the contract/transaction date range. Defaults to the first day of the current calendar month on form load. | Cannot be in the future (must not exceed today's date). Changing this date automatically updates the To Date to one month later (or to today if that date is in the future). |
| To Date (`CONT_TO_DATE`) | Yes | End date for the contract/transaction date range. Defaults to today (or month-end if within the same month). | Cannot be in the future. Cannot be before the From Date. The date range cannot span more than 30 days. |
| Model (`BASE_MODEL_CD`) | Yes | Filters results by vehicle model code. Defaults to "All" models. Selected via a model look-up. | The search and export procedures validate this field as non-null. Defaults to "All" if left blank. |
| Variant (`VARIANT_CD`) | Yes | Filters results by vehicle variant code. Defaults to "All" variants. Available variants depend on the selected model. Selected via a variant look-up. | The search and export procedures validate this field as non-null. Defaults to "All" if left blank. |
| EW Type (`EW_TYPE`) | Yes | Filters results by the extended warranty category (e.g. warranty type code). Populated from the application's reference list. Defaults to "All". | The search and export procedures validate this field as non-null. Defaults to "All" if left blank. |
| Payment Type (`CB_PAYMENT_TYPE`) | Conditional | Filters results by payment method (Offline DMS, EMI, Online But Not EMI). Defaults to "Offline DMS" if blank. | The WHEN-LIST-CHANGED trigger for this filter is inactive (commented out) - changing this value does not auto-clear the results grid. The WHEN-VALIDATE-ITEM trigger applies a default if blank. |
| Vendor (`VEND`) | Conditional | Filters results by warranty vendor/insurer code. Visible only for principal 2 (second OEM organisation). | Changing this filter clears the results grid and resets the record count to zero. |
| Matching Records (`TOT_REC`) | Auto-Populated | Displays the total number of records returned after the search. Updated automatically after a successful search. | Read-only; set by the search procedure after each query. |

#### Session / Global Variables (populated at form start - non-database)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Principal (`GLOBAL.PRINCIPAL`) | Auto-Populated | Identifies which OEM organisation context the current session is running under. Controls which cursors (PMC1 or PMC2) and which data tables are queried. | Set by the runtime environment before the form opens. Drives branching throughout the search and export logic. |
| User ID (`GLOBAL.USERID`) | Auto-Populated | The logged-in user's identifier, used to construct the CSV export filename. | Set by the runtime environment before the form opens. |
| Copyright (`COPYRIGHT`) | Auto-Populated | Displays the current-year copyright notice for the organisation. Populated by a function that derives the financial year from the current date. | Read-only display field; derived by the copyright declaration function at form load. |

### 6.3 Reference Data

*Lists the master and configuration data referenced by this form (LOVs, record groups, master tables). LOVs are documented here - not as separate Section 4 BRs.*

| Reference Data | Business Purpose | Used When |
| :--- | :--- | :--- |
| Location list (RG_LOC / AM_DEALER_LOC) | Provides the list of active dealer locations for the current OEM principal, including an "ALL DEALERS" / "ALL LOCATIONS" entry. Used to populate the Dealer and Location filter fields. | At form load and when the Dealer Name LOV (LV_DEALER) is invoked, to populate the dealer/location selection. |
| Dealer list with LOV (LV_DEALER / RG_DEALER / AM_DEALER_LOC) | Provides the selectable dealer list for the Dealer Name field, filtered by region and sold-from channel; includes "All Dealers" option. | When the user opens the dealer look-up from the Dealer Name field. |
| Vehicle Model list (LV_MODEL / RG_MODEL / GM_MOD) | Provides the list of vehicle models for the model filter, including "All Models" option; restricted to models for the current OEM principal. | When the user opens the model look-up from the Model field. |
| Vehicle Variant list (LV_VARIANT / RG_VARIANT / GM_VAR) | Provides vehicle variants for the selected model; includes "All Variants" option. The available variants change when the selected model changes. | When the user opens the variant look-up from the Variant field. |
| Extended Warranty Type list (AM_LIST - EXTE_WARR_TYPE) | Provides the set of extended warranty type codes and descriptions for the EW Type filter. For principal 1, the code is shown alongside the description. | At form load, the EW Type list item is populated from AM_LIST filtered by the current principal. |
| Region list (GM_REGN) | Provides the list of geographic regions for the region filter, including an "All Regions" option; restricted to the current OEM principal. | At form load, the Region list item is populated from GM_REGN. |
| Vendor / Insurer list (DPL GENERAL.L_POPULATE - WAR_VEND) | Provides the list of warranty vendor/insurer codes for the Vendor filter (visible only to principal 2 users). | At form load, the Vendor list item is populated via the DPL library's L_POPULATE routine for the WAR_VEND list name (EXTERNAL / NOT IN BUNDLE - AM_LIST or equivalent; exact list name not confirmed from bundle). |
| EW Policy Status function (SF_EW_POLICY_STATUS) | Derives the current status of an extended warranty policy. Called during search to populate the Status column of each result row. | During the search execution (PROC_REP_SEARCH_PMC1 / PMC2), for each policy number returned by the query. |
| EW Validity Detail function (SF_GET_EW_VALIDITY_DTL) | Returns the warranty type description/detail for a given policy number, used by principal 1 (PMC1) to enrich the EW Type column in the results. | During the PMC1 search execution (PROC_REP_SEARCH_PMC1) for each policy record returned. |
| Vehicle Variant Description (GM_VAR) | Provides the variant description for a given variant code and principal. Used to populate the Variant Desc field in the results grid. | During the search execution, for each result row, to look up the variant description. |
| Standard EW Premium (VM_EW_PREM) | Provides the standard (list) premium for each EW type. Used in the Excel export query (PMC1) for comparison against actual premiums. | During the Excel export procedure (PROC_REP_XL_PMC1), when building the dynamic CSV query. |
| Employee/sales data (GM_EMP) | Provides employee name, designation, and MSPIN for the employee linked to a warranty sale. Used in the Excel export query. | During the Excel export procedures (PROC_REP_XL_PMC1 / PMC2), when building the dynamic CSV query. |
| Bank details (BANK) | Provides bank details for EMI-payment records. Used in the Excel export query. | During the Excel export procedures (PROC_REP_XL_PMC1 / PMC2), when building the dynamic CSV query. |
| DPL attached library (DPL.pld) | Provides shared business routines: CHECK_NULL (mandatory-field check), DISP_TEXT (message display), L_POP_LIST_ITEM (populate a list item from a query), L_POPULATE (populate a list item from a named list), RAISE_ERROR (error code lookup and display). | Throughout the form's trigger and program-unit code. |

### 6.4 Data Lifecycle

*Describes how records are created, updated, and saved within this form's evidenced behaviour.*

**Creation**

- This form is a read-only reporting and export tool; it does not create extended warranty records in any database table. All query results are loaded into the display-only results grid (`B_EW` block) when the user executes a search.
- On form load, the search criteria fields are pre-populated with default values (first day of current month as From Date, today as To Date, "All" for model/variant/EW type, "ALL DEALERS"/"ALL LOCATIONS" for dealer/location, "New Sales" as the default EW Status).

**Updates**

- No updates to database tables are performed by this form. The search criteria block is non-database and holds only screen-level filter state.
- Changing a filter criterion (Region, Sold From, EW Type, EW Status / Report Type, or Vendor) clears the results grid and resets the record count to zero, so the displayed data always reflects the most recently executed search.

**Save and Commit**

- There is no save or commit path in this form. The save-related toolbar button (`PB_SAVE`) delegates to `FT_SAVE`, which is inactive (`null` body). The commit key trigger (`KEY-COMMIT`) is also inactive. No database write of any kind is performed during a normal session.

**Retention and Audit**

- No retention, archival, or audit stamp logic is implemented in this form. The form does not write creation/modification timestamps to any table. All data displayed is read from the underlying EW transaction and master tables, which are managed by other DMS processes outside this form.

---

### 6.5 Excel Output Columns

This form does not use Excel download. No Excel export columns were identified in the form sources.

## 7. Glossary

*Definitions of terms, abbreviations, and acronyms used throughout this document.*

The following table defines key terms, acronyms, and abbreviations used throughout this Business Requirements Document.

| Term | Definition | Aliases | Related Terms |
| :--- | :--- | :--- | :--- |
| AM_DEALER_LOC | Dealer location master table - stores dealer map codes, location codes, dealer names, and region details | | Dealer, Location, Region |
| AM_LIST | Application list master table - stores named dropdown list values keyed by list name and principal code | | LOV, List Item |
| B_EW | Extended warranty results data block - displays up to 12 warranty contract records per page in the search results grid | | Block, Results Grid |
| CB_DUMMY | Control block - holds all search filter criteria fields and action buttons; no direct database table binding | Control Block | Block, Filter |
| CGST | Central Goods and Services Tax - the central government component of GST applied to extended warranty premiums from 01-JUL-2017 | | GST, IGST, SGST |
| CSV | Comma-Separated Values - the file format used for the exported extended warranty report delivered to the user's browser | Export File | Excel Export, WebUtil |
| DMS | Dealer Management System - the integrated dealership software platform within which this form operates | | DPL_MTPL |
| DPL | Dealer PL/SQL Library - the shared PL/SQL program library (DPL.pld) providing common utility routines (CHECK_NULL, DISP_TEXT, RAISE_ERROR, L_POPULATE) used across DMS forms | | DPL.pld, GENERAL |
| DPL_MTPL | DMS main menu launcher form - the parent form that opens the Extended Warranty Details screen and injects session context globals | Launcher | DMS, Session Context |
| EW | Extended Warranty - a vehicle warranty plan sold by the dealer beyond the standard manufacturer warranty period | Extended Warranty | EW Type, EW Contract |
| EW Type | Extended warranty plan type code - identifies the specific warranty product category (e.g. a specific coverage tier or plan variant) | Warranty Type | EW, EXTE_WARR_TYPE |
| GENERAL | The package alias for the DPL shared library's utility routines (e.g. GENERAL.CHECK_NULL, GENERAL.DISP_TEXT) | | DPL, DPL.pld |
| GM_MOD | Vehicle model master table - stores base model codes and descriptions | | Model, GM_VAR |
| GM_REGN | Region master table - stores sales region codes and descriptions | | Region |
| GM_VAR | Vehicle variant master table - stores variant codes and descriptions filtered by base model | | Variant, GM_MOD |
| GST | Goods and Services Tax - the Indian indirect tax regime introduced from 01-JUL-2017; replaces the pre-GST service tax, SBC, and KKC tax structure | | CGST, SGST, IGST, Pre-GST |
| IGST | Integrated Goods and Services Tax - the inter-state component of GST applied to extended warranty premiums | | GST, CGST, SGST |
| KKC | Krishi Kalyan Cess - a pre-GST cess levied on service tax applicable before 01-JUL-2017 | | Pre-GST, SBC, Service Tax |
| LOV | List of Values - a dropdown selection popup in Oracle Forms allowing the user to choose from a predefined set of values | Dropdown | Record Group, List Item |
| LV_DEALER | Dealer LOV - the dropdown list popup for selecting an authorised dealership | | LOV, RG_DEALER |
| LV_MODEL | Model LOV - the dropdown list popup for selecting a vehicle base model | | LOV, RG_MODEL |
| LV_VARIANT | Variant LOV - the dropdown list popup for selecting a vehicle variant filtered by the selected model | | LOV, RG_VARIANT |
| MSIL | Maruti Suzuki India Limited - the principal manufacturer category (principal code = 1) that determines query routing, column visibility, and export logic | Principal=1 | Non-MSIL, Principal |
| Non-MSIL | Non-MSIL principal category (principal code = 2) - refers to small-manufacturer dealerships; uses a separate data source (PMC2 queries) | PMC2, Small Manufacturer | MSIL, Principal |
| OLB | Oracle Object Library - a shared library file (DPL.olb) providing inherited property classes, visual attributes, windows, and object groups used by DMS forms | Object Library | DPL |
| PB_BLK | Push-button block - the data block containing all action buttons (Exit, Search, Cancel, Export, Cut, Copy, Paste, navigation buttons) | Button Block | Block |
| PLD | PL/SQL Library - a compiled program library file (.pld) attached to an Oracle Forms module to provide shared utility procedures and functions | Program Library | DPL, webutil.pld |
| PMC1 | Principal Manufacturer Category 1 (MSIL) - the query and export routines used for MSIL-branded dealerships | MSIL | PMC2, PRINCIPAL |
| PMC2 | Principal Manufacturer Category 2 (Non-MSIL) - the query and export routines used for non-MSIL (small-manufacturer) dealerships | Non-MSIL | PMC1, PRINCIPAL |
| Pre-GST | The Indian indirect tax regime before 01-JUL-2017, consisting of Service Tax, Swachh Bharat Cess (SBC), and Krishi Kalyan Cess (KKC) | | GST, Service Tax, SBC, KKC |
| Principal | Session-level manufacturer code that determines which EW data source and query logic is used (1=MSIL, 2=Non-MSIL) | Principal Code | MSIL, Non-MSIL, PMC1, PMC2 |
| RG_DEALER | Dealer record group - the SQL-based record group backing the dealer LOV, filtered by parent group | | LOV, LV_DEALER |
| RG_LOC | Location record group - the SQL-based record group providing dealer location codes and names | | Record Group |
| RG_MODEL | Model record group - the SQL-based record group backing the vehicle model LOV | | LOV, LV_MODEL |
| RG_VARIANT | Variant record group - the SQL-based record group backing the vehicle variant LOV, filtered by the selected model | | LOV, LV_VARIANT |
| SBC | Swachh Bharat Cess - a pre-GST cess levied on service tax, applicable to extended warranty premiums before 01-JUL-2017 | | Pre-GST, KKC, Service Tax |
| SGST | State Goods and Services Tax - the state government component of GST applied to extended warranty premiums from 01-JUL-2017 | | GST, CGST, IGST |
| Service Tax | Pre-GST indirect tax levied on services including extended warranty premiums; replaced by GST from 01-JUL-2017 | | Pre-GST, SBC, KKC, GST |
| VIN | Vehicle Identification Number - the unique chassis number of the vehicle associated with an extended warranty contract | Chassis Number | EXTE_VIN_NO |
| WebUtil | Oracle Forms Web Utilities library - provides client-side file operations used to deliver the generated CSV export file to the user's browser | webutil.pld | CSV, Export |

---

---

## 8. Technical Inventory

*Complete inventory of Oracle Forms components including blocks, items, triggers, canvases, and global variables.*

### 8.1 Form Architecture

**Form Module Details:**

- Form Name: vr_exte_warr_msil (VR_EXTE_WARR_MSIL)
- Form Module XML Title: MODULE4
- Oracle Forms Version: 12c (Module version 122010400); Runtime compatibility: 5.0
- Parent Object Library: DPL.olb (PC_FORM property class)
- Attached Libraries: WEBUTIL (webutil.olb), DPL (DPL.pld program library), D2KWUTIL
- First Navigation Block: -
- Console Window: WN_MAIN - Extended Warranty Details(MSIL) (Rel: 1.2.9)
- Compile Dependencies: Requires DPL.olb, DPL.pld, WEBUTIL.olb, menu.mmx, database packages PK_PART_SEARCH_NEW
- Source artifacts: `vr_exte_warr_msil_fmb.xml`; OLB `DPL.olb`; WEBUTIL (webutil.olb); DPL (DPL.pld program library); D2KWUTIL

### 8.1.1 Global Variables

| Global Variable | Data Type | Set Location | Purpose |
| :--- | :--- | :--- | :--- |
| APP_LOG | Char | Trigger | Application logging enabled flag; set by parent form at session start |
| COMP_FA | Char | Trigger | Company FA code used for financial year context; injected by parent form |
| CURRENCY | Char | Trigger | Currency symbol (e.g. Rs) displayed across monetary fields |
| DEALER | Number | Trigger | Current dealer map code identifying the active dealership |
| EXIT_FLAG | Char | Trigger | Form exit signal; set to `EXIT` when the exit button is pressed |
| FIN_BEG | Char | Trigger | Financial year begin date string (e.g. 01-APR-YYYY) for period filtering |
| FIN_END | Char | Trigger | Financial year end date string (e.g. 31-MAR-YYYY) for period filtering |
| LOC_CD | Char | Trigger | Current location code restricting data to the user's dealership location |
| PARENT_GROUP | Char | Trigger | Dealer parent group code used to scope dealer hierarchy queries |
| PRINCIPAL | Char | ProgramUnit / RecordGroup / Trigger | Principal manufacturer code (1=MSIL, 2=non-MSIL); controls query routing and field visibility |
| P_FIN_YR | Char | Trigger | Current financial year (e.g. 2012) for report period context |
| REP_SERVER | Char | Trigger | Report server name used when launching server-side reports |
| TALLY_INTEGRATION | Char | Trigger | Tally accounting integration enabled flag (Y/N) |
| USERID | Char | ProgramUnit / Trigger | Current user login ID used in file naming and audit context |
| USER_NAME | Char | Trigger | Current user display name for labelling and session context |

### 8.1.2 Form Parameters

*No ModuleParameter entries found in vr_exte_warr_msil_fmb.xml.*

| Parameter | Data Type | Default | Description |
| :--- | :--- | :--- | :--- |
| - | - | - | No form parameters defined in source (Total Parameters: 0) |

**Total Parameters:** 0

### 8.2 Blocks

| Block Name | Query Data Source | Records | Q/I/U/D | Key Mode | Master-Detail Relationship |
| :--- | :--- | :--- | :--- | :--- | :--- |
| CB_DUMMY | - | 1 | N/N/N/N | Default | Control - entry point for filter criteria and report type selection |
| B_EW | - | 12 | N/N/N/N | Delayed | - |
| PB_BLK | - | 1 | N/N/N/N | Default | - |

**Total Blocks:** 3 business blocks

> **Note:** CB_ERR is an inherited block sourced from the OG_GROUP object group (DPL.olb). It is listed in the items summary (Section 8.3) and object group inventory (Section 8.10.3) but is not counted as a form-local business block.

### 8.2.1 Block WhereClause and OrderByClause

*Block query scope from vr_exte_warr_msil_fmb.xml. **Description** explains filter and sort in business terms; **Order By** and **Where Clause** columns retain verbatim XML text for migration.*

| Block | Description | Order By (XML) | Where Clause (XML) |
| :--- | :--- | :--- | :--- |
| - | No blocks with WhereClause/OrderByClause in vr_exte_warr_msil_fmb.xml | - | - |

### 8.3 Items Summary

*Complete item inventory from `vr_exte_warr_msil_fmb.xml`.*

**Block counts:**

*Database / non-database counts derived from XML.*

| Block | Total Items | Database Items | Non-Database Items |
| :--- | ---: | ---: | ---: |
| CB_DUMMY | 31 | 0 | 31 |
| B_EW | 36 | 0 | 36 |
| PB_BLK | 15 | 0 | 15 |
| CB_ERR | 1 | 0 | 1 |
| **Total** | **83** | **0** | **83** |

**Item detail (all 83 items):**

| Block | Item Name | DatabaseItem | Description |
| :--- | :--- | :--- | :--- |
| CB_DUMMY | CB_SOLD_FROM | false | Sold-from filter - selects whether to filter by selling location or region |
| CB_DUMMY | CB_REGION | false | Region filter - selects the sales region for the warranty report |
| CB_DUMMY | CB_REPORT_TYPE | false | Report type selector - determines the report grouping or format |
| CB_DUMMY | DEALER_NAME | false | Dealer name display field showing the selected dealer's name |
| CB_DUMMY | CB_LOC_DESC | false | Location description display field for the selected dealership location |
| CB_DUMMY | P_REP_TYPE | false | Policy report type list - selects Sale (N), Upgrade/Conversion (U), or Cancellation (C) |
| CB_DUMMY | CONT_FROM_DATE | false | Contract from-date - start of the contract date range filter |
| CB_DUMMY | CONT_TO_DATE | false | Contract to-date - end of the contract date range filter (max 30 days from start) |
| CB_DUMMY | BASE_MODEL_CD | false | Vehicle base model code filter for the extended warranty search |
| CB_DUMMY | VARIANT_CD | false | Vehicle variant code filter for the extended warranty search |
| CB_DUMMY | EW_TYPE | false | Extended warranty type filter (e.g. All, or specific EW plan type) |
| CB_DUMMY | PB_SEARCH | false | Search button - executes the extended warranty query and populates the results block |
| CB_DUMMY | CB_DEALER_MAP_CD | false | Dealer map code (internal) corresponding to the selected dealer |
| CB_DUMMY | CB_LOC_CD | false | Location code corresponding to the selected dealer location |
| CB_DUMMY | CB_PARENT | false | Parent group code of the selected dealer for hierarchical filtering |
| CB_DUMMY | P_USER_DESG | false | Current user designation used for access and display context |
| CB_DUMMY | PB_EXCEL | false | Export to Excel button - generates a CSV file of the current search results |
| CB_DUMMY | BASE_MODEL_DESC | false | Vehicle base model description displayed alongside the model code |
| CB_DUMMY | VARIANT_DESC | false | Vehicle variant description displayed alongside the variant code |
| CB_DUMMY | TOT_REC | false | Total records count displayed after a search is executed |
| CB_DUMMY | CB_DEALER_NAME | false | Dealer name used internally for CSV report header generation |
| CB_DUMMY | CB_REGION_DESC | false | Region description corresponding to the selected region code |
| CB_DUMMY | CB_SOLD_FROM_DESC | false | Sold-from description label for the selected sold-from filter value |
| CB_DUMMY | TEST1 | false | Test/scratch field - no active business use identified |
| CB_DUMMY | DIFF_P | false | Difference premium display field - shows premium difference amount |
| CB_DUMMY | DIFF_C | false | Difference commission display field - shows commission difference amount |
| CB_DUMMY | COPYRIGHT | false | Copyright notice display field populated by the copyright declaration function |
| CB_DUMMY | ITEM854 | false | Unlabelled display item - no active business use identified |
| CB_DUMMY | ITEM855 | false | Unlabelled display item - no active business use identified |
| CB_DUMMY | CB_PAYMENT_TYPE | false | Payment type filter list (e.g. OD); change trigger is commented out and inactive |
| CB_DUMMY | VEND | false | Vendor filter list - selects the warranty vendor for non-MSIL (PMC2) principal searches |
| B_EW | EXTE_POLICY_NO | false | Extended warranty policy number - unique identifier for the EW contract |
| B_EW | EXTE_CONTRACT_DATE | false | Date the extended warranty contract was created |
| B_EW | EXTE_VIN_NO | false | Vehicle Identification Number (VIN/Chassis number) linked to the EW contract |
| B_EW | EXTE_RETLSALE_DT | false | Retail sale date of the vehicle associated with the EW contract |
| B_EW | EXTE_VARIANT_CD | false | Vehicle variant code for the EW-covered vehicle |
| B_EW | EXTE_WARR_TYPE | false | Extended warranty plan type code |
| B_EW | EXTE_CUST_NAME | false | Customer name registered on the extended warranty contract |
| B_EW | EXTE_PREMIUM | false | Base premium amount charged for the extended warranty |
| B_EW | SERV_TAX_PREM_AMT | false | Service tax amount on the premium (pre-GST regime) |
| B_EW | SBC_TAX_PREM_AMT | false | Swachh Bharat Cess tax amount on the premium (pre-GST regime) |
| B_EW | KKC_TAX_PREM_AMT | false | Krishi Kalyan Cess tax amount on the premium (pre-GST regime) |
| B_EW | SERV_TAX_DIFF_PREM_AMT | false | Service tax on the differential premium for upgrade contracts (pre-GST) |
| B_EW | SBC_TAX_DIFF_PREM_AMT | false | Swachh Bharat Cess on the differential premium (pre-GST) |
| B_EW | KKC_TAX_DIFF_PREM_AMT | false | Krishi Kalyan Cess on the differential premium (pre-GST) |
| B_EW | EXTE_PREM_DLR_COMM | false | Dealer commission amount on the extended warranty premium |
| B_EW | EXTE_PREM_SRV_TAX | false | Service tax on dealer commission (pre-GST regime) |
| B_EW | EXTE_PREM_SBC_TAX | false | Swachh Bharat Cess on dealer commission (pre-GST) |
| B_EW | EXTE_PREM_KKC_TAX | false | Krishi Kalyan Cess on dealer commission (pre-GST) |
| B_EW | EXTE_CREATED_BY | false | User ID of the person who created the EW contract record |
| B_EW | VARIANT_DESC | false | Vehicle variant description for the EW-covered vehicle |
| B_EW | EXTE_REMARKS | false | Free-text remarks associated with the extended warranty record |
| B_EW | EXTE_STATUS | false | Current status of the extended warranty contract (e.g. Active, Cancelled) |
| B_EW | EXTE_DEBIT_AMT | false | Debit amount applied to the extended warranty account |
| B_EW | EXTE_CANCEL_AMT | false | Cancellation amount refunded or charged on contract cancellation |
| B_EW | EXTE_CREDIT_AMT | false | Credit amount posted to the extended warranty account |
| B_EW | EXTE_CREATED_BY2 | false | Secondary created-by user field (alternate source or legacy mapping) |
| B_EW | EXTE_DEALER_NAME | false | Dealer name associated with the extended warranty contract |
| B_EW | EXTE_LOCATION_DESC | false | Dealership location description for the EW contract |
| B_EW | EXTE_PREM_IGST_AMT | false | Integrated GST (IGST) amount on the premium (post-GST regime) |
| B_EW | EXTE_PREM_SGST_AMT | false | State GST (SGST) amount on the premium (post-GST regime) |
| B_EW | EXTE_PREM_CGST_AMT | false | Central GST (CGST) amount on the premium (post-GST regime) |
| B_EW | EXTE_PREM_COMM_IGST | false | IGST on dealer commission (post-GST regime) |
| B_EW | EXTE_PREM_COMM_SGST | false | SGST on dealer commission (post-GST regime) |
| B_EW | EXTE_PREM_COMM_CGST | false | CGST on dealer commission (post-GST regime) |
| B_EW | CONV_STATUS | false | Conversion status indicating whether an EW was upgraded from a base plan |
| B_EW | VEND | false | Vendor code identifying the warranty provider for non-MSIL contracts |
| PB_BLK | PB_EXIT | false | Exit button - closes the form unconditionally without saving (inherited via OG_GROUP) |
| PB_BLK | PB_LIST | false | List button - triggers the LOV popup for the current field (inherited via OG_GROUP) |
| PB_BLK | PB_INSERT | false | Insert button - **INACTIVE**; delegates to FT_INSERT which is commented out (inherited via OG_GROUP) |
| PB_BLK | PM_CONT | false | Contract button - no active trigger defined (inherited via OG_GROUP) |
| PB_BLK | PB_DEL | false | Delete button - **INACTIVE**; delegates to FT_DEL which is a null stub (inherited via OG_GROUP) |
| PB_BLK | PB_CANCEL | false | Cancel button - clears the form and resets all filter criteria to defaults (inherited via OG_GROUP) |
| PB_BLK | PB_SAVE | false | Save button - **INACTIVE**; delegates to FT_SAVE which is a null stub (inherited via OG_GROUP) |
| PB_BLK | PB_PRINT | false | Print button - **INACTIVE**; delegates to FT_PRINT which is a null stub (inherited via OG_GROUP) |
| PB_BLK | PB_CUT | false | Cut button - cuts selected text in the current field (inherited via OG_GROUP) |
| PB_BLK | PB_COPY | false | Copy button - copies selected text in the current field (inherited via OG_GROUP) |
| PB_BLK | PB_PASTE | false | Paste button - pastes clipboard text into the current field (inherited via OG_GROUP) |
| PB_BLK | PB_ERR_EXIT | false | Error exit button - no active trigger defined (inherited via OG_GROUP) |
| PB_BLK | NB_EXIT | false | Navigation bar exit button - sets exit flag and closes the form (inherited via OG_GROUP) |
| PB_BLK | NB_CLEAR | false | Navigation bar clear button - clears the form blocks (inherited via OG_GROUP) |
| PB_BLK | NB_OK | false | Navigation bar OK button - exits the form without validation (inherited via OG_GROUP) |
| CB_ERR | TXT_ERR | false | Error message display field - displays error text in the error block; no active triggers defined on this block (inherited via OG_GROUP) |

### 8.4 List of Values

| LOV Name | Title | Record Group | Attached Block.Item |
| :--- | :--- | :--- | :--- |
| LV_DEALER | Select Dealer | RG_DEALER | CB_DUMMY.DEALER_NAME |
| LV_MODEL | Select Model from List | RG_MODEL | CB_DUMMY.BASE_MODEL_CD |
| LV_VARIANT | Select Variant from List | RG_VARIANT | CB_DUMMY.VARIANT_CD |

**Total LOVs:** 3

### 8.5 Alerts

*The form defines 4 alerts in vr_exte_warr_msil_fmb.xml. AL_NOTE and AL_ERRINFO are invoked at runtime by GENERAL.DISP_TEXT throughout trigger and program-unit logic. AL_PRINT and AL_CONFIRM are defined in the XML but have no active call sites in the current form logic. All four alerts are inherited via the OG_GROUP object group from DPL.olb.*

| Alert Name | Title | Message Text | Calling Context |
| :--- | :--- | :--- | :--- |
| AL_ERRINFO | Error | (message text supplied at runtime by GENERAL.DISP_TEXT) | GENERAL.DISP_TEXT - called from Trigger: ON-ERROR (Form), Trigger: WHEN-VALIDATE-ITEM on CB_DUMMY.CONT_FROM_DATE, Trigger: WHEN-VALIDATE-ITEM on CB_DUMMY.CONT_TO_DATE; used for Error-type messages (inherited) |
| AL_NOTE | Note | (message text supplied at runtime by GENERAL.DISP_TEXT) | GENERAL.DISP_TEXT - called from Trigger: ON-ERROR (Form), Trigger: WHEN-VALIDATE-ITEM on CB_DUMMY.CONT_FROM_DATE, Trigger: WHEN-VALIDATE-ITEM on CB_DUMMY.CONT_TO_DATE; used for informational/note-type messages (inherited) |
| AL_CONFIRM | Caution | (message text supplied at runtime) | No active call sites identified in current form triggers or program units (inherited) |
| AL_PRINT | Print | (message text supplied at runtime) | No active call sites identified in current form triggers or program units (inherited) |

**Total Alerts:** 4

### 8.6 Program Units

*Authoritative catalogue of **6 form-local program units**. Database packages and standalone procedures are in **Section 15.2**; PLD shared-library routines are in **Section 18**.*

| Program Unit | Type | Calls | Description |
| :--- | :--- | :--- | :--- |
| VIEW_EXCEL_REP | Procedure | TEXT_IO, WEBUTIL_FILE_TRANSFER.URL_TO_CLIENT, WEBUTIL_HOST.HOST, WEBUTIL_C_API.ID_NULL, Create_Group_From_Query | Core CSV export engine. Accepts a dynamic SQL query string, executes it as a record group, writes each row to a temporary server-side file via TEXT_IO, then transfers the file to the client browser using WebUtil file transfer. Invoked by PROC_REP_XL_PMC1 and PROC_REP_XL_PMC2 |
| CLEAR_ITEMS | Procedure | None | Empty stub - body contains only BEGIN END; with no active logic |
| PROC_REP_SEARCH_PMC1 | Procedure | GENERAL.CHECK_NULL, SF_EW_POLICY_STATUS | Executes the on-screen extended warranty search for MSIL (principal=1) dealers. Validates mandatory filters, builds a UNION query across live EW sale tables and historical records, and populates the B_EW multi-row results block |
| PROC_REP_SEARCH_PMC2 | Procedure | GENERAL.CHECK_NULL, SF_EW_POLICY_STATUS | Executes the on-screen extended warranty search for non-MSIL (principal=2) dealers. Queries the small-manufacturer EW sale table with vendor filter and populates the B_EW results block |
| PROC_REP_XL_PMC1 | Procedure | GENERAL.CHECK_NULL, SF_GET_EW_VALIDITY_DTL, SF_GET_DLR_NAME_LOC, SF_EW_POLICY_STATUS, VIEW_EXCEL_REP | Generates and exports the extended warranty CSV report for MSIL (principal=1) dealers. Validates all mandatory filters, constructs a dynamic CSV query branched by report type (Sale/Upgrade/Cancellation), and calls VIEW_EXCEL_REP to produce the download file |
| PROC_REP_XL_PMC2 | Procedure | GENERAL.CHECK_NULL, SF_GET_DLR_NAME_LOC, SF_EW_POLICY_STATUS, VIEW_EXCEL_REP | Generates and exports the extended warranty CSV report for non-MSIL (principal=2) dealers. Applies vendor filter, branches by report type (Sale/Upgrade/Cancellation), and calls VIEW_EXCEL_REP to produce the download file |

**Total Program Units:** 6

### 8.7 Triggers

**Item-Level Trigger Types (reference):**

| Trigger Name | Purpose |
| :--- | :--- |
| WHEN-VALIDATE-ITEM | Validates field when user leaves item |
| KEY-* | Keyboard actions - commit, exit, LOV, navigation |
| WHEN-NEW-BLOCK-INSTANCE | Initializes block on entry |
| WHEN-BUTTON-PRESSED | Executes button action |
| PRE-INSERT / POST-INSERT | Before/after record creation |
| WHEN-LIST-CHANGED | Dropdown selection changed |
| PRE-QUERY / POST-QUERY | Before/after query execution |
| WHEN-CHECKBOX-CHANGED | Checkbox toggled |
| WHEN-VALIDATE-RECORD | Validates entire record before leaving row |

**DPL library routines invoked from triggers and program units:**

| Routine | Type | Called From | Purpose |
| :--- | :--- | :--- | :--- |
| GENERAL.CHECK_NULL | Library routine | ProgramUnit: PROC_REP_SEARCH_PMC1, ProgramUnit: PROC_REP_SEARCH_PMC2, ProgramUnit: PROC_REP_XL_PMC1, ProgramUnit: PROC_REP_XL_PMC2 | Validates that a mandatory filter field is not null; displays an error dialog and raises FORM_TRIGGER_FAILURE if the value is missing |
| GENERAL.DISP_TEXT | Library routine | CB_DUMMY.CONT_FROM_DATE, CB_DUMMY.CONT_TO_DATE, Form level | Displays an alert dialog with a configurable title and message text; uses AL_ERRINFO for Error type alerts and AL_NOTE for informational alerts |
| GENERAL.L_POPULATE | Library routine | Form level | Populates a list item from the AM_LIST lookup table filtered by list name and current principal code |
| GENERAL.L_POP_LIST_ITEM | Library routine | Form level | Creates a dynamic record group from a supplied SQL query and populates the target list item |
| GENERAL.RAISE_ERROR | Library routine | Form level | Retrieves an error message by code, determines the message type (Error/Note/Caution), displays the appropriate dialog, and raises FORM_TRIGGER_FAILURE for error-type messages |
| WEBUTIL_FILE_TRANSFER.URL_TO_CLIENT | Library routine | ProgramUnit: VIEW_EXCEL_REP | Transfers a file from the server URL to the client machine; used to deliver the generated CSV report to the user's browser |
| WEBUTIL_HOST.HOST | Library routine | ProgramUnit: VIEW_EXCEL_REP | Executes a host operating-system command on the server; used within the CSV export to run file-system operations |

### 8.7.1 Inactive / Commented-Out Trigger Register

*Triggers and field validations where XML source is `null;`, fully block-commented, or legacy code preserved but not executed. Do **not** migrate these as active business requirements.*

| Status | Block | Item | Trigger | Former behaviour (preserved in comments) | Disabled since / note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Inactive stub** | Form | - | FT_SAVE | No save behaviour was implemented | null; stub - this is a read-only reporting form with no insert/update operations |
| **Inactive stub** | Form | - | FT_DEL | No delete behaviour was implemented | null; stub - delete is not applicable for this report-only form |
| **Inactive stub** | Form | - | FT_PRINT | No print behaviour was implemented | null; stub - report printing was not implemented in this version |
| **Commented out** | Form | - | WHEN-NEW-FORM-INSTANCE | Contained DEFAULT_VALUE calls to initialise all 15 GLOBAL variables (principal, userid, dealer, dates etc.) with test defaults, and earlier list population logic | Commented out - global defaults are now injected by the parent launcher form (DPL_MTPL) before this form opens |
| **Inactive stub** | CB_DUMMY | - | KEY-UP | No upward navigation between records | null; stub - suppresses default key-up navigation within the control block |
| **Inactive stub** | CB_DUMMY | - | KEY-DOWN | No downward navigation between records | null; stub - suppresses default key-down navigation within the control block |
| **Commented out** | CB_DUMMY | CB_PAYMENT_TYPE | WHEN-LIST-CHANGED | Cleared the B_EW block and reset the results when the payment type changed | Commented out by developer on 21-NOV-2024 - payment type filter change no longer triggers a results clear |

*Additional null-only or partially commented triggers exist on estimation and legacy blocks - see XML `TriggerText` starting with `null;` or `/*`.*

**Complete trigger inventory (57 business triggers):**
*vr_exte_warr_msil_fmb.xml contains Trigger elements.*

| Trigger Name | Block | Item | Called From / Context | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| ON-ERROR | Form | - | Form level | Intercepts Oracle errors; maps FK violation (-02292) to application error E0088; displays error text for known error codes (40209, 40207, 50026, 50004); shows a multi-user conflict message for codes 40654-40659; calls GENERAL.RAISE_ERROR and GENERAL.DISP_TEXT |
| ON-MESSAGE | Form | - | Form level | **COMMENTED OUT / INACTIVE** - entire body is commented out; was intended to display message text for codes 40209/40207; currently executes null |
| KEY-EXIT | Form | - | Form level | Clears DBMS_APPLICATION_INFO client info and module registration, then exits the form without validation |
| KEY-LISTVAL | Form | - | Form level | Retrieves the LOV associated with the current cursor item and displays it at screen position (200,120); advances focus to the next item after a successful selection |
| KEY-COMMIT | Form | - | Form level | **COMMENTED OUT / INACTIVE** - entire body is commented out; was intended to call ENTER -> CHECK_FORM_FAILURE -> COMMIT_FORM -> CLEAR_FORM; currently executes null |
| KEY-CLRFRM | Form | - | Form level | Clears the form without validation, resets the P_REP_TYPE filter to Sale type, and restores visibility of the EXTE_DEBIT_AMT and EXTE_CREATED_BY columns |
| KEY-OTHERS | Form | - | Form level | Suppresses all unhandled keyboard actions (inherited object group trigger; no active body) (inherited) |
| KEY-NEXT-ITEM | Form | - | Form level | Inherited navigation trigger - advances cursor to the next item (standard Forms behaviour via object group) (inherited) |
| KEY-PREV-ITEM | Form | - | Form level | Inherited navigation trigger - moves cursor to the previous item (standard Forms behaviour via object group) (inherited) |
| KEY-NXTBLK | Form | - | Form level | Inherited block-navigation trigger - moves focus to the next block (standard Forms behaviour via object group) (inherited) |
| KEY-PRVBLK | Form | - | Form level | Inherited block-navigation trigger - moves focus to the previous block (standard Forms behaviour via object group) (inherited) |
| KEY-DOWN | Form | - | Form level | Inherited downward navigation trigger - moves cursor to the next record (standard Forms behaviour via object group) (inherited) |
| KEY-UP | Form | - | Form level | Inherited upward navigation trigger - moves cursor to the previous record (standard Forms behaviour via object group) (inherited) |
| FT_SAVE | Form | - | Form level | **INACTIVE** - null stub; no save operation is performed; this is a read-only reporting form (inherited) |
| FT_CANCEL | Form | - | Form level | Clears the form (both changed and unchanged paths clear all blocks), then re-fires WHEN-NEW-FORM-INSTANCE to reinitialise all filter criteria and list items (inherited) |
| FT_INSERT | Form | - | Form level | **COMMENTED OUT / INACTIVE** - entire body is commented out; was intended to navigate to last record and create a new one (inherited) |
| FT_DEL | Form | - | Form level | **INACTIVE** - null stub; no delete operation is performed (inherited) |
| FT_LIST | Form | - | Form level | If the PB_LIST button is enabled, fires LIST_VALUES to display the LOV for the current field; otherwise does nothing (inherited) |
| FT_PRINT | Form | - | Form level | **INACTIVE** - null stub; no print operation is performed (inherited) |
| WHEN-NEW-FORM-INSTANCE | Form | - | Form level | **COMMENTED OUT / INACTIVE** - inherited object group trigger body is commented out; the active version of this logic was moved to the parent DPL_MTPL launcher form; form initialisation (window maximise, list population, column visibility) runs from the form-local trigger override (inherited) |
| PRE-FORM | Form | - | Form level | Registers the form name with DBMS_APPLICATION_INFO for session monitoring; earlier item visibility setup was commented out |
| KEY-UP | CB_DUMMY | - | CB_DUMMY | **INACTIVE** - null stub; suppresses default key-up navigation within the CB_DUMMY block |
| KEY-DOWN | CB_DUMMY | - | CB_DUMMY | **INACTIVE** - null stub; suppresses default key-down navigation within the CB_DUMMY block |
| WHEN-LIST-CHANGED | CB_DUMMY | CB_SOLD_FROM | CB_DUMMY.CB_SOLD_FROM | Clears the B_EW results block, resets the total record count to zero, and returns focus to the CB_SOLD_FROM field when the sold-from selection changes |
| WHEN-VALIDATE-ITEM | CB_DUMMY | CB_SOLD_FROM | CB_DUMMY.CB_SOLD_FROM | Defaults the CB_SOLD_FROM value to 'A' (All) if left null |
| WHEN-LIST-CHANGED | CB_DUMMY | CB_REGION | CB_DUMMY.CB_REGION | Clears the B_EW results block and resets the total record count when the region selection changes |
| WHEN-VALIDATE-ITEM | CB_DUMMY | CB_REGION | CB_DUMMY.CB_REGION | Defaults the region filter to 'All' if left null |
| WHEN-LIST-CHANGED | CB_DUMMY | CB_REPORT_TYPE | CB_DUMMY.CB_REPORT_TYPE | Clears the B_EW results block and moves focus to EW_TYPE when the report type selection changes |
| WHEN-VALIDATE-ITEM | CB_DUMMY | CB_REPORT_TYPE | CB_DUMMY.CB_REPORT_TYPE | Defaults the report type to 'D' if left null |
| WHEN-LIST-CHANGED | CB_DUMMY | P_REP_TYPE | CB_DUMMY.P_REP_TYPE | Adjusts column visibility in the B_EW block based on the selected policy report type (N=Sale, U=Upgrade, C=Cancel) and applies the pre-GST vs. GST tax column toggle based on the contract from-date relative to 01-JUL-2017 |
| WHEN-VALIDATE-ITEM | CB_DUMMY | P_REP_TYPE | CB_DUMMY.P_REP_TYPE | Defaults the policy report type to 'N' (Sale) if left null |
| WHEN-VALIDATE-ITEM | CB_DUMMY | CONT_FROM_DATE | CB_DUMMY.CONT_FROM_DATE | Validates that the contract from-date does not exceed today; auto-calculates the to-date as the end of the same month (capped at today); re-applies GST column visibility based on the new date; calls GENERAL.DISP_TEXT on error |
| WHEN-VALIDATE-ITEM | CB_DUMMY | CONT_TO_DATE | CB_DUMMY.CONT_TO_DATE | Validates that the contract to-date does not exceed today or precede the from-date; enforces a maximum date range of 30 days; calls GENERAL.DISP_TEXT on error |
| POST-TEXT-ITEM | CB_DUMMY | BASE_MODEL_CD | CB_DUMMY.BASE_MODEL_CD | Defaults the base model code to 'All' if left null after the user leaves the field |
| POST-TEXT-ITEM | CB_DUMMY | VARIANT_CD | CB_DUMMY.VARIANT_CD | Defaults the variant code to 'All' if left null after the user leaves the field |
| WHEN-LIST-CHANGED | CB_DUMMY | EW_TYPE | CB_DUMMY.EW_TYPE | Clears the B_EW results block and resets the total record count when the EW type selection changes |
| WHEN-VALIDATE-ITEM | CB_DUMMY | EW_TYPE | CB_DUMMY.EW_TYPE | Defaults the EW type filter to 'All' if left null |
| WHEN-BUTTON-PRESSED | CB_DUMMY | PB_SEARCH | CB_DUMMY.PB_SEARCH | Executes the on-screen extended warranty search; routes to PROC_REP_SEARCH_PMC1 for MSIL principal or PROC_REP_SEARCH_PMC2 for non-MSIL principal based on the PRINCIPAL global variable |
| WHEN-BUTTON-PRESSED | CB_DUMMY | PB_EXCEL | CB_DUMMY.PB_EXCEL | Generates a CSV export of the current extended warranty search results; routes to PROC_REP_XL_PMC1 for MSIL or PROC_REP_XL_PMC2 for non-MSIL based on the PRINCIPAL global variable |
| WHEN-LIST-CHANGED | CB_DUMMY | CB_PAYMENT_TYPE | CB_DUMMY.CB_PAYMENT_TYPE | **COMMENTED OUT / INACTIVE** - previously cleared the B_EW block on payment type change; currently executes null |
| WHEN-VALIDATE-ITEM | CB_DUMMY | CB_PAYMENT_TYPE | CB_DUMMY.CB_PAYMENT_TYPE | Defaults the payment type to 'OD' if left null |
| WHEN-LIST-CHANGED | CB_DUMMY | VEND | CB_DUMMY.VEND | Clears the B_EW results block and resets the total record count when the vendor selection changes |
| WHEN-VALIDATE-ITEM | CB_DUMMY | VEND | CB_DUMMY.VEND | Defaults the CB_REGION filter to 'All' if the vendor value is null |
| WHEN-VALIDATE-ITEM | B_EW | EXTE_POLICY_NO | B_EW.EXTE_POLICY_NO | **COMMENTED OUT / INACTIVE** - trigger body is commented out; was intended to perform validation on the policy number for cancellation report type |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EXIT | PB_BLK.PB_EXIT | Closes the form unconditionally without prompting to save changes |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_LIST | PB_BLK.PB_LIST | Delegates to FT_LIST to display the LOV for the current field |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_INSERT | PB_BLK.PB_INSERT | **INACTIVE** - delegates to FT_INSERT which is a commented-out null stub |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_DEL | PB_BLK.PB_DEL | **INACTIVE** - delegates to FT_DEL which is a null stub |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CANCEL | PB_BLK.PB_CANCEL | Delegates to FT_CANCEL to clear the form and reset all filter criteria, then restores B_EW column labels and visibility |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SAVE | PB_BLK.PB_SAVE | **INACTIVE** - delegates to FT_SAVE which is a null stub |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PRINT | PB_BLK.PB_PRINT | **INACTIVE** - delegates to FT_PRINT which is a null stub |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CUT | PB_BLK.PB_CUT | Cuts the selected text from the current field to the clipboard |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_COPY | PB_BLK.PB_COPY | Copies the selected text from the current field to the clipboard |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PASTE | PB_BLK.PB_PASTE | Pastes text from the clipboard into the current field |
| WHEN-BUTTON-PRESSED | PB_BLK | NB_EXIT | PB_BLK.NB_EXIT | Sets the EXIT_FLAG global to 'EXIT' and closes the form unconditionally |
| WHEN-BUTTON-PRESSED | PB_BLK | NB_CLEAR | PB_BLK.NB_CLEAR | Clears the form blocks (references a block from a legacy context; no effect in current form) |
| WHEN-BUTTON-PRESSED | PB_BLK | NB_OK | PB_BLK.NB_OK | Exits the form without validation |

### 8.8 Canvas and Window Inventory

**Windows:**

| Window | Title | Primary Canvas |
| :--- | :--- | :--- |
| WIN_ERR | - | CN_ERR |
| WN_MAIN | Extended Warranty Details(MSIL) (Rel: 1.2.9) | CN_MAIN |

**Canvases:**

| Canvas | Type | Window |
| :--- | :--- | :--- |
| CN_ERR | Content | WIN_ERR |
| CN_TOOL | Vertical Toolbar | WN_MAIN |
| CN_MAIN | Content | WN_MAIN |

> **Note:** WIN_ERR and CN_ERR are inherited via the OG_GROUP object group from DPL.olb. They host the CB_ERR error display block and TXT_ERR item. CN_TOOL provides the inherited toolbar button strip (PB_BLK items).

---

### 8.9 Editors

*No editors found in vr_exte_warr_msil_fmb.xml.*

### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

#### 8.10.1 Visual Attributes (form-defined)

*1 VisualAttribute elements defined at form level (not inherited from DPL.olb).*

| Visual Attribute |
| :--- |
| VA_CURR_REC |

#### 8.10.2 Property Classes (form-defined)

*Form-local PropertyClass elements.*

*No form-local property classes found in vr_exte_warr_msil_fmb.xml.*

#### 8.10.3 Object Groups

*Object groups bundle inherited triggers and visual objects applied form-wide at runtime. All entries below are sourced from DPL.olb and applied to this form via the OG_GROUP object group reference.*

| Object Group Child | Type |
| :--- | :--- |
| KEY-OTHERS | Inherited trigger |
| KEY-NEXT-ITEM | Inherited trigger |
| KEY-PREV-ITEM | Inherited trigger |
| KEY-NXTBLK | Inherited trigger |
| KEY-PRVBLK | Inherited trigger |
| KEY-DOWN | Inherited trigger |
| KEY-UP | Inherited trigger |
| CN_ERR | Inherited canvas |
| VA_DISP | Inherited visualattribute |
| CB_ERR | Inherited block |
| VA_LOV | Inherited visualattribute |
| VA_TRNI_DT | Inherited visualattribute |
| VA_TITLE | Inherited visualattribute |
| VA_ALERT | Inherited visualattribute |
| VA_BUTN | Inherited visualattribute |
| VA_TEXT | Inherited visualattribute |
| VA_MPROMPT | Inherited visualattribute |
| VA_OPROMPT | Inherited visualattribute |
| VA_MAND | Inherited visualattribute |
| VA_NUM | Inherited visualattribute |
| VA_DESC | Inherited visualattribute |
| VA_ICONIC_BUTN | Inherited visualattribute |
| VA_RB | Inherited visualattribute |
| VA_CB | Inherited visualattribute |
| WN_MAIN | Inherited window |
| POP_MAIN | Inherited trigger |
| CN_MAIN | Inherited canvas |
| CN_TOOL | Inherited canvas |
| PB_BLK | Inherited block |
| AL_ERRINFO | Inherited alert |
| AL_NOTE | Inherited alert |
| AL_CONFIRM | Inherited alert |
| WIN_ERR | Inherited window |
| AL_PRINT | Inherited alert |
| FT_SAVE | Inherited trigger |
| FT_CANCEL | Inherited trigger |
| FT_INSERT | Inherited trigger |
| FT_DEL | Inherited trigger |
| FT_LIST | Inherited trigger |
| FT_PRINT | Inherited trigger |
| WHEN-NEW-FORM-INSTANCE | Inherited trigger |

### 8.11 DataSourceColumn Inventory

*29 DataSourceColumn elements across 1 blocks - formal query column-to-block mapping from vr_exte_warr_msil_fmb.xml.*

#### B_EW (29 columns)

| Column (DSCName) | Data Type |
| :--- | :--- |
| APPLY_MODEL_CD | VARCHAR2 |
| CATG_CD | VARCHAR2 |
| CREATED_BY | VARCHAR2 |
| CREATED_DATE | DATE |
| DEALER_MAP_CD | NUMBER |
| EFF_FROM_DATE | DATE |
| EFF_TO_DATE | DATE |
| LANDED_COST | NUMBER |
| MIN_ORD_QTY | NUMBER |
| MODIFIED_BY | VARCHAR2 |
| MODIFIED_DATE | DATE |
| MRP_1 | NUMBER |
| PART_DESC | VARCHAR2 |
| PART_NUM | VARCHAR2 |
| PRINCIPAL_MAP_CD | NUMBER |
| PURCHASE_PRICE | NUMBER |
| SELL_PRICE | NUMBER |
| SOURCE_CD | VARCHAR2 |
| UOM_CD | VARCHAR2 |
| ROOT_PART_NUM | VARCHAR2 |
| SEQ_NUM | NUMBER |
| TYPE_CD | VARCHAR2 |
| SUB_TYPE_CD | VARCHAR2 |
| TAG_CD | VARCHAR2 |
| MUL_YN | VARCHAR2 |
| VOR_YN | VARCHAR2 |
| SUB_CATG1_CD | VARCHAR2 |
| SUB_CATG2_CD | VARCHAR2 |
| BRAND_CD | VARCHAR2 |

**Total DataSourceColumns:** 29 across 1 blocks

## 9. Object Library

*The form references the DPL Object Library (DPL.olb) as its parent library; PC_FORM is cited in the Technical Inventory as the property class inherited from that OLB. The table below catalogues all Visual Attributes, Property Classes, and Object Groups defined in DPL.olb. Direct subclassing of individual items via SubclassObject is not evidenced in the form XML - the OLB objects are available to any form that attaches DPL.*

Source OLB file(s): DPL.olb, DPL_olb.xml

| Name | Type | Description | Used By (count) | Sample Items |
| ---- | ---- | ----------- | --------------- | ------------ |
| VA_DISP | VisualAttribute | Display-field visual attribute | 0 | N/A |
| VA_LOV | VisualAttribute | List of Values visual attribute | 0 | N/A |
| VA_TRNI_DT | VisualAttribute | Transaction date visual attribute | 0 | N/A |
| VA_TITLE | VisualAttribute | Title/heading visual attribute | 0 | N/A |
| VA_ALERT | VisualAttribute | Alert dialog visual attribute | 0 | N/A |
| VA_BUTN | VisualAttribute | Button visual attribute | 0 | N/A |
| VA_TEXT | VisualAttribute | Text item visual attribute | 0 | N/A |
| VA_MPROMPT | VisualAttribute | Mandatory-field prompt visual attribute | 0 | N/A |
| VA_OPROMPT | VisualAttribute | Optional-field prompt visual attribute | 0 | N/A |
| VA_MAND | VisualAttribute | Mandatory field visual attribute | 0 | N/A |
| VA_NUM | VisualAttribute | Numeric field visual attribute | 0 | N/A |
| VA_DESC | VisualAttribute | Description field visual attribute | 0 | N/A |
| VA_ICONIC_BUTN | VisualAttribute | Iconic button visual attribute | 0 | N/A |
| VA_RB | VisualAttribute | Radio button visual attribute | 0 | N/A |
| VA_CB | VisualAttribute | Check box visual attribute | 0 | N/A |
| PC_DESC | PropertyClass | Property class for description text items | 0 | N/A |
| PC_SC_DATE | PropertyClass | Property class for date fields | 0 | N/A |
| PC_TITLE | PropertyClass | Property class for text items (title) | 0 | N/A |
| PC_FORMAT | PropertyClass | Property class for formatted text items | 0 | N/A |
| PC_MR_BLK | PropertyClass | Property class for master-record blocks | 0 | N/A |
| PC_DISP | PropertyClass | Property class for display text items | 0 | N/A |
| PC_LOV | PropertyClass | Property class for LOV-enabled items | 0 | N/A |
| PC_FORM | PropertyClass | Form-level property class; cited as parent OLB property class for this form | 0 | N/A |
| PC_DISP_DATE | PropertyClass | Property class for display-only date items | 0 | N/A |
| PC_DISP_NUM | PropertyClass | Property class for display-only numeric items | 0 | N/A |
| PC_DATE | PropertyClass | Property class for date entry items | 0 | N/A |
| PC_DTTIME | PropertyClass | Property class for date and time items | 0 | N/A |
| PC_CB | PropertyClass | Property class for check box items | 0 | N/A |
| PC_ALERT | PropertyClass | Property class for alert dialogs | 0 | N/A |
| PC_MDATE | PropertyClass | Property class for mandatory date items | 0 | N/A |
| PC_RB | PropertyClass | Property class for radio button items | 0 | N/A |
| PC_WIND | PropertyClass | Property class for windows | 0 | N/A |
| PC_CANV | PropertyClass | Property class for canvases | 0 | N/A |
| PC_BUTN | PropertyClass | Property class for push buttons | 0 | N/A |
| PC_TEXT | PropertyClass | Property class for text items | 0 | N/A |
| OG_GROUP | ObjectGroup | Standard object group from DPL library | 0 | N/A |

---

## 10. Record Groups

*Lists all record groups, their LOV bindings, query logic, dynamic bindings, business purpose, and form usage.*

| Record Group | Type | Used By LOV | Display Column | Return Column | Dynamic Bindings | Purpose | Where Used |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| RG_LOC | Query | - | DEALER_NAME | LOC_CD | No | Lists dealership locations for the region/location filter selection | - |
| RG_MODEL | Query | LV_MODEL | MODEL_CD | MODEL_DESC | No | Lists available vehicle base models for the model filter selection | LV_MODEL -> CB_DUMMY.BASE_MODEL_CD |
| RG_VARIANT | Query | LV_VARIANT | VARIANT_CD | VARIANT_DESC | Yes - CB_DUMMY | Lists vehicle variants filtered by the selected base model for the variant filter | LV_VARIANT -> CB_DUMMY.VARIANT_CD |
| RG_DEALER | Query | LV_DEALER | DEALER_NAME | LOC_DESC | Yes - CB_DUMMY | Lists authorised dealerships filtered by the current parent group for the dealer selection | LV_DEALER -> CB_DUMMY.DEALER_NAME |

**Total Record Groups:** 4

## 11. Referenced Database Objects

*Database tables, views, and objects accessed by the form.*

| Block | Base Table | Primary Key Item | Database Item |
| :--- | :--- | :--- | :--- |
| CB_DUMMY | - | - | No |
| B_EW | - | - | No |
| PB_BLK | - | - | No |

| Object | Schema | Used In | Description |
| :--- | :--- | :--- | :--- |
| `AM_DEALER_LOC` | - | PROC_REP_XL_PMC1, PROC_REP_XL_PMC2, RG_DEALER, RG_LOC | Dealer location master - maps dealer map codes to location codes, dealer names, and region details |
| `AM_LIST` | - | Trigger WHEN-NEW-FORM-INSTANCE | Application list master - stores lookup list values (e.g. EW types, report type labels) keyed by list name and principal code |
| `DUAL` | - | PROC_REP_XL_PMC1, PROC_REP_XL_PMC2, RG_DEALER, RG_LOC, RG_MODEL, RG_VARIANT, Trigger WHEN-NEW-FORM-INSTANCE, Trigger WHEN-VALIDATE-ITEM | Oracle system dual table - used for scalar value retrieval (e.g. SYSDATE, computed literals) in queries and validations |
| `GM_MOD` | - | RG_MODEL | Vehicle model master - stores vehicle base model codes and descriptions for the model LOV |
| `GM_REGN` | - | Trigger WHEN-NEW-FORM-INSTANCE | Region master - stores sales region codes and descriptions used to populate the region list |
| `GM_VAR` | - | PROC_REP_SEARCH_PMC1, PROC_REP_SEARCH_PMC2, RG_VARIANT | Vehicle variant master - stores variant codes and descriptions filtered by base model for the variant LOV and search queries |

**Total Referenced Objects:** 6

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure/Package Index

| Requirement ID | Procedure/Package | Purpose |
| -------------- | ----------------- | ------- |
| BR-001 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Registers the form's client identifier in the database session at startup and clears it on exit |
| BR-001 | DBMS_APPLICATION_INFO.SET_MODULE | Registers the form's module name in the database session at startup and clears it on exit |
| BR-001 | SF_COPYRIGHT_DECLARATION | Returns the current-year copyright string for display in the form footer |
| BR-001 | GENERAL.L_POP_LIST_ITEM | Populates the EW Type and vendor drop-down list items from principal-specific database queries at form startup |
| BR-001 | GENERAL.L_POPULATE | Populates the EW type and report type drop-down list items from the AM_LIST application list master at form startup |
| BR-006, BR-007 | GENERAL.DISP_TEXT | Displays date validation error messages and general Oracle error messages to the user |
| BR-012 | PROC_REP_SEARCH_PMC1 | Validates mandatory search criteria and retrieves extended warranty records for the first OEM context |
| BR-012 | PROC_REP_SEARCH_PMC2 | Validates mandatory search criteria and retrieves extended warranty records for the second OEM context |
| BR-012 | GENERAL.CHECK_NULL | Enforces mandatory field checks during the search and export operations |
| BR-012 | SF_EW_POLICY_STATUS | Derives the current policy status for each result record during search |
| BR-012 | SF_GET_EW_VALIDITY_DTL | Derives the warranty type detail for each PMC1 New Sales result record |
| BR-013 | PROC_REP_XL_PMC1 | Validates mandatory criteria, builds the dynamic CSV export query for the first OEM context, and launches the file |
| BR-013 | PROC_REP_XL_PMC2 | Validates mandatory criteria, normalises the vendor filter, builds the CSV export query for the second OEM context, and launches the file |
| BR-013 | VIEW_EXCEL_REP | Executes the dynamic CSV query, writes the output file to the server, and opens it in the browser |
| BR-014 | GENERAL.RAISE_ERROR | Looks up a registered error message for a given error code and displays it via DISP_TEXT; raises FORM_TRIGGER_FAILURE for error-type messages |
| BR-014 | GENERAL.DISP_TEXT | Displays error messages for database and Forms errors |
| BR-015 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Clears the session client information on form exit |
| BR-015 | DBMS_APPLICATION_INFO.SET_MODULE | Clears the session module name on form exit |
| - | WEBUTIL_C_API.ID_NULL | Tests whether a WebUtil file-transfer handle is null before proceeding with client file delivery in VIEW_EXCEL_REP |
| - | WEBUTIL.ERRORALERT | Displays a WebUtil error alert dialog; called from VIEW_EXCEL_REP on file-operation failure |
| - | WEBUTIL.FCLOSE | Closes a server-side file handle after the CSV export file has been written |
| - | WEBUTIL.FOPEN | Opens a server-side file handle for writing the CSV export file |
| - | WEBUTIL.GETIMPLCLASS | Retrieves the WebUtil implementation class identifier; used in VIEW_EXCEL_REP for runtime environment checks |
| - | WEBUTIL.GETPROPERTY | Retrieves a WebUtil property value; used in VIEW_EXCEL_REP |
| - | WEBUTIL.GET_LINE | Reads a line from the server-side file (used to read the export file path from `excelpath.txt`) |
| - | WEBUTIL.PUT_LINE | Writes a single CSV row line to the server-side export file |
| - | WEBUTIL.SETPROPERTY | Sets a WebUtil property value; used in VIEW_EXCEL_REP |
| - | WEB.SHOW_DOCUMENT | Opens the generated CSV file URL in the user's web browser after the export file is written |
| - | CLEAR_ITEMS | Stub procedure with no executable statements; not called from any trigger or program unit |

---

### 12.2 Procedure and Package Catalogue

#### PROC_REP_SEARCH_PMC1

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| PROC_REP_SEARCH_PMC1 | Form Program Unit - Active | WHEN-BUTTON-PRESSED on CB_DUMMY.PB_SEARCH | Validates the seven mandatory search filters, then queries extended warranty transaction data from DMSD_EW_SALE and VT_EXTSAWA (UNION) for the first OEM principal, and populates the B_EW results block with the matching records. Branches on P_REP_TYPE to retrieve New Sales (cursor C1), Conversions (cursor C2), or Cancellations (cursor C3). Calls GENERAL.CHECK_NULL for mandatory field enforcement, SF_EW_POLICY_STATUS to derive policy status per row, and SF_GET_EW_VALIDITY_DTL for warranty type detail on New Sales rows. |

#### PROC_REP_SEARCH_PMC2

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| PROC_REP_SEARCH_PMC2 | Form Program Unit - Active | WHEN-BUTTON-PRESSED on CB_DUMMY.PB_SEARCH | Validates the seven mandatory search filters, then queries extended warranty transaction data from DMSD_EW_SALE_SM for the second OEM principal (including vendor code filter), and populates the B_EW results block. Branches on P_REP_TYPE to retrieve New Sales (cursor C1), Conversions (cursor C2), or Cancellations (cursor C3). Calls GENERAL.CHECK_NULL for mandatory field enforcement and SF_EW_POLICY_STATUS to derive policy status per row. |

#### PROC_REP_XL_PMC1

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| PROC_REP_XL_PMC1 | Form Program Unit - Active | WHEN-BUTTON-PRESSED on CB_DUMMY.PB_EXCEL | Validates mandatory filters via GENERAL.CHECK_NULL, resolves the dealer display name from AM_DEALER_LOC, builds a dynamic SQL CSV query (New Sales / Conversions / Cancellations) using DMSD_EW_SALE and VT_EXTSAWA for the first OEM, and calls VIEW_EXCEL_REP to write and open the CSV file. The query includes standard premium from VM_EW_PREM, employee details from GM_EMP, and EMI/payment breakdown. |

#### PROC_REP_XL_PMC2

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| PROC_REP_XL_PMC2 | Form Program Unit - Active | WHEN-BUTTON-PRESSED on CB_DUMMY.PB_EXCEL | Validates mandatory filters via GENERAL.CHECK_NULL, normalises the vendor filter (CWI/GAN or All), resolves the dealer display name from AM_DEALER_LOC, builds a dynamic SQL CSV query (New Sales / Conversions / Cancellations) using DMSD_EW_SALE_SM for the second OEM, and calls VIEW_EXCEL_REP to write and open the CSV file. Includes vendor code as the first column. |

#### VIEW_EXCEL_REP

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| VIEW_EXCEL_REP | Form Program Unit - Active | PROC_REP_XL_PMC1 (Form PU), PROC_REP_XL_PMC2 (Form PU) | Accepts a SQL query string, creates a record group, executes the query, reads the server-side file path from `/reports/DMS/excelpath.txt` via WEBUTIL.GET_LINE, opens the output file with WEBUTIL.FOPEN, writes each result row as a CSV line via WEBUTIL.PUT_LINE, closes the file with WEBUTIL.FCLOSE, and opens the file in the browser via WEB.SHOW_DOCUMENT. Uses WEBUTIL_C_API.ID_NULL to validate file handles and WEBUTIL.ERRORALERT on failure. Enforces a 65,535-row limit and handles file-path space errors. |

#### CLEAR_ITEMS

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| CLEAR_ITEMS | Form Program Unit - Inactive (empty body) | Not called from any trigger or program unit | Stub procedure with no executable statements. Does not perform any business function in the current form. |

#### GENERAL.CHECK_NULL

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| GENERAL.CHECK_NULL | DPL Attached Library Routine | PROC_REP_SEARCH_PMC1, PROC_REP_SEARCH_PMC2, PROC_REP_XL_PMC1, PROC_REP_XL_PMC2 (all Form PUs) | Validates that a mandatory filter field is not null. Signature: `Procedure(p_value IN VARCHAR2, column_title IN VARCHAR2)`. If the supplied value is null, displays an error dialog with the message "Enter a valid {column_title}" and raises FORM_TRIGGER_FAILURE to abort the calling routine. |

#### GENERAL.DISP_TEXT

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| GENERAL.DISP_TEXT | DPL Attached Library Routine | ON-ERROR (Form trigger), WHEN-VALIDATE-ITEM on CB_DUMMY.CONT_FROM_DATE, WHEN-VALIDATE-ITEM on CB_DUMMY.CONT_TO_DATE | Displays a modal alert dialog with configurable title and message text. Signature: `Procedure(text_string VARCHAR2, title_string VARCHAR2)`. Uses AL_ERRINFO for Error-type titles and AL_NOTE for all other titles. Invoked to communicate date validation failures and Oracle errors to the user. |

#### GENERAL.L_POPULATE

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| GENERAL.L_POPULATE | DPL Attached Library Routine | WHEN-NEW-FORM-INSTANCE (Form trigger) | Populates a form list item by creating a dynamic record group from the AM_LIST lookup table, filtered by the supplied list name and the current principal map code. Signature: `Procedure(P_LIST_NAME VARCHAR2, P_LIST_FIELD VARCHAR2)`. Called at form startup to load the EW type and report type dropdown lists. |

#### GENERAL.L_POP_LIST_ITEM

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| GENERAL.L_POP_LIST_ITEM | DPL Attached Library Routine | WHEN-NEW-FORM-INSTANCE (Form trigger) | Creates a dynamic record group from an arbitrary SQL query string and uses it to populate a named list item. Signature: `Procedure(p_rg_name VARCHAR2, p_select VARCHAR2)`. Called at form startup to populate the EW type and vendor list items with principal-specific values derived from database queries. |

#### GENERAL.RAISE_ERROR

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| GENERAL.RAISE_ERROR | DPL Attached Library Routine | ON-ERROR (Form trigger) | Retrieves error message details by code, classifies the message type (Error, Note, Caution), displays the appropriate alert dialog via DISP_TEXT, and raises FORM_TRIGGER_FAILURE for error-type messages. Signature: `Procedure(mesg_code IN VARCHAR2)`. The internal `get_message` call is commented out in the current implementation, so the displayed string reduces to the error code plus a null suffix at runtime; none of the Error/Note/Caution branches fire. |

#### DBMS_APPLICATION_INFO.SET_CLIENT_INFO

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Oracle Built-in Package Routine | PRE-FORM (Form trigger), KEY-EXIT (Form trigger) | Registers the form name as the client information for the current database session at startup, and clears it (sets to null) on exit. Enables database-level session tracking. |

#### DBMS_APPLICATION_INFO.SET_MODULE

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| DBMS_APPLICATION_INFO.SET_MODULE | Oracle Built-in Package Routine | PRE-FORM (Form trigger), KEY-EXIT (Form trigger) | Registers the form name as the module name for the current database session at startup, and clears it (module and action both set to empty string) on exit. |

#### SF_COPYRIGHT_DECLARATION

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| SF_COPYRIGHT_DECLARATION | Standalone Function (SF_COPYRIGHT_DECLARATION.fnc - in source bundle) | WHEN-NEW-FORM-INSTANCE (Form trigger) | Returns the current-year copyright string for display. Determines the financial year from the current date (January-March = previous year start; otherwise current year). |

#### SF_EW_POLICY_STATUS

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| SF_EW_POLICY_STATUS | Standalone Function (SF_EW_POLICY_STATUS.fnc - in source bundle) | PROC_REP_SEARCH_PMC1, PROC_REP_SEARCH_PMC2 (Form PUs) | Returns the current status of an extended warranty policy for a given policy number. Called once per result row during the search to populate the policy status display field in the B_EW block. |

#### SF_GET_EW_VALIDITY_DTL

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| SF_GET_EW_VALIDITY_DTL | Standalone Function (SF_GET_EW_VALIDITY_DTL.fnc - in source bundle) | PROC_REP_SEARCH_PMC1 (Form PU) | Returns the warranty type detail/description for a given policy number and query type parameter. Called once per New Sales result row during the PMC1 search. |

#### WEBUTIL_C_API.ID_NULL

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| WEBUTIL_C_API.ID_NULL | WEBUTIL Attached Library Routine (webutil.pld - WEBUTIL_C_API package) | VIEW_EXCEL_REP (Form PU) | Tests whether a WebUtil handle (Pointer, FunctionHandle, ParameterHandle, or ParameterList) is null. Signature: `Function(handle IN Pointer) RETURN BOOLEAN`. Returns TRUE if the handle is null, FALSE otherwise. Used in VIEW_EXCEL_REP to verify that the file-transfer handle is valid before proceeding with the client file delivery. |

#### WEBUTIL.ERRORALERT

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| WEBUTIL.ERRORALERT | WEBUTIL Attached Library Routine | VIEW_EXCEL_REP (Form PU) | Displays a WebUtil error alert dialog to the user. Called from VIEW_EXCEL_REP when a file-operation error is detected during the CSV export process. |

#### WEBUTIL.FCLOSE

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| WEBUTIL.FCLOSE | WEBUTIL Attached Library Routine | VIEW_EXCEL_REP (Form PU) | Closes the server-side file handle after all CSV export rows have been written. Ensures the output file is properly finalised before it is delivered to the user. |

#### WEBUTIL.FOPEN

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| WEBUTIL.FOPEN | WEBUTIL Attached Library Routine | VIEW_EXCEL_REP (Form PU) | Opens a server-side file handle for writing the CSV export file at the path read from `excelpath.txt`. Returns a file handle used by subsequent WEBUTIL.PUT_LINE and WEBUTIL.FCLOSE calls. |

#### WEBUTIL.GETIMPLCLASS

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| WEBUTIL.GETIMPLCLASS | WEBUTIL Attached Library Routine | VIEW_EXCEL_REP (Form PU) | Retrieves the WebUtil implementation class identifier at runtime. Used in VIEW_EXCEL_REP for runtime environment verification prior to file operations. |

#### WEBUTIL.GETPROPERTY

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| WEBUTIL.GETPROPERTY | WEBUTIL Attached Library Routine | VIEW_EXCEL_REP (Form PU) | Retrieves a named WebUtil property value. Used in VIEW_EXCEL_REP to read environment or configuration properties needed during the CSV export operation. |

#### WEBUTIL.GET_LINE

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| WEBUTIL.GET_LINE | WEBUTIL Attached Library Routine | VIEW_EXCEL_REP (Form PU) | Reads a single line from a server-side file. Used in VIEW_EXCEL_REP to read the export file path from the configuration file `/reports/DMS/excelpath.txt`. |

#### WEBUTIL.PUT_LINE

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| WEBUTIL.PUT_LINE | WEBUTIL Attached Library Routine | VIEW_EXCEL_REP (Form PU) | Writes a single text line to the open server-side file handle. Called once per result row in VIEW_EXCEL_REP to write each CSV data row to the export file. |

#### WEBUTIL.SETPROPERTY

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| WEBUTIL.SETPROPERTY | WEBUTIL Attached Library Routine | VIEW_EXCEL_REP (Form PU) | Sets a named WebUtil property value. Used in VIEW_EXCEL_REP to configure WebUtil environment or operational properties during the CSV export process. |

#### WEB.SHOW_DOCUMENT

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| WEB.SHOW_DOCUMENT | WEBUTIL Attached Library Routine | VIEW_EXCEL_REP (Form PU) | Opens a URL (the generated CSV file's server path) in the user's web browser in a new tab or window. Called as the final step in VIEW_EXCEL_REP to deliver the exported CSV file to the user after it has been written to the server. |

## 13. Package Procedure Specifications

*NO PCK files found - no ``*.pck`` source files were discovered in the form sources input directory. Package specifications cannot be generated without uploaded PCK sources.*

---

## 14. Database Package Catalogue

*No `.pck` source files were discovered in the source bundle. The database package catalogue cannot be populated without uploaded PCK sources.*

> **Note:** No `*.pck` source files were found in the form sources input directory. The database package catalogue cannot be generated without uploaded PCK sources.

| Source File (.pck) | Package | Routine Name | Type | Definition (signature / excerpt) | Called From | Purpose |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| - | - | - | - | No PCK files in source bundle | - | - |

| Function | Returns | Values | Description |
| :--- | :--- | :--- | :--- |
| - | - | - | No PCK files in source bundle |

## 15. PLD Procedure Call Sites

*Maps each program-library routine to its call sites within triggers and program units. Behaviour descriptions are derived from the uploaded ``.pld`` sources.*

### DPL.pld (`general`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| CHECK_NULL | Procedure | Procedure(p_value IN VARCHAR2, column_title IN VARCHAR2) | ProgramUnit: PROC_REP_SEARCH_PMC1, ProgramUnit: PROC_REP_SEARCH_PMC2, ProgramUnit: PROC_REP_XL_PMC1, ProgramUnit: PROC_REP_XL_PMC2 | Validates that a mandatory filter field is not null. If the supplied value is null, displays an error dialog with the message "Enter a valid {column_title}" and raises FORM_TRIGGER_FAILURE to halt execution |
| DISP_TEXT | Procedure | Procedure(text_string VARCHAR2, title_string VARCHAR2) | Trigger: ON-ERROR in Form, Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.CONT_FROM_DATE, Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.CONT_TO_DATE | Displays a modal alert dialog with configurable title and message text. Uses AL_ERRINFO for Error-type titles and AL_NOTE for all other titles. Invoked to communicate validation failures and Oracle errors to the user |
| L_POPULATE | Procedure | Procedure(P_LIST_NAME VARCHAR2,P_LIST_FIELD VARCHAR2) | Trigger: WHEN-NEW-FORM-INSTANCE in Form | Populates a form list item by creating a dynamic record group from the AM_LIST lookup table, filtered by the supplied list name and the current principal map code. Used at form startup to load the EW type and report type dropdown lists |
| l_pop_list_item | Procedure | Procedure(p_rg_name VARCHAR2,p_select VARCHAR2) | Trigger: WHEN-NEW-FORM-INSTANCE in Form | Creates a dynamic record group from an arbitrary SQL query string and populates a named record group. Used at form startup to populate the EW type and vendor list items with principal-specific values |
| RAISE_ERROR | Procedure | Procedure(mesg_code IN VARCHAR2) | Trigger: ON-ERROR in Form | Retrieves error message details by code, classifies the message type (Error, Note, Caution), displays the appropriate alert dialog via DISP_TEXT, and raises FORM_TRIGGER_FAILURE for error-type messages |

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``vr_exte_warr_msil_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| CHECK_FORM_FAILURE | Procedure | Procedure() | Trigger: KEY-COMMIT in Form | **COMMENTED OUT / INACTIVE** - referenced only within the commented-out KEY-COMMIT trigger body; checks whether the last Forms operation succeeded and raises an error if not. Not executed in the current form |

**Total Active Routines:** 5 of 24 in DPL.pld source
**Inactive / commented-only routines:** 1

---

### webutil.pld (`WEBUTIL_C_API`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ID_NULL | Function | Function(handle IN Pointer) RETURN BOOLEAN | ProgramUnit: VIEW_EXCEL_REP | Tests whether a WebUtil handle (Pointer, FunctionHandle, ParameterHandle, or ParameterList) is null. Returns TRUE if the handle is null, FALSE otherwise. Used in VIEW_EXCEL_REP to verify that the file-transfer handle is valid before proceeding with the client file delivery |

**Total Active Routines:** 1 of 28 in webutil.pld source

---

### webutil.pld (`WEBUTIL_FILE`)

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``vr_exte_warr_msil_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| FILE_SAVE_DIALOG | Function | Function(directory_name Varchar2 := NULL, file_name Varchar2 := NULL, file_filter Varchar2 := NULL, title Varchar2 := NULL) RETURN Varchar2 | ProgramUnit: VIEW_EXCEL_REP | **COMMENTED OUT / INACTIVE** - referenced only within the commented-out section of VIEW_EXCEL_REP; displays a client-side file save dialog to allow the user to choose a save location. Not executed in the current form |

**Total Active Routines:** 0 of 25 in webutil.pld source
**Inactive / commented-only routines:** 1

---

### webutil.pld (`WEBUTIL_FILE_TRANSFER`)

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``vr_exte_warr_msil_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| URL_To_Client | Function | Function(sourceURL in VARCHAR2, clientDestination in VARCHAR2, fileSize in PLS_INTEGER default 0) RETURN BOOLEAN | ProgramUnit: VIEW_EXCEL_REP | **COMMENTED OUT / INACTIVE** - referenced only within the commented-out section of VIEW_EXCEL_REP; transfers a file from a server URL to a destination path on the client machine. Not executed in the current form |

**Total Active Routines:** 0 of 21 in webutil.pld source
**Inactive / commented-only routines:** 1

---

### webutil.pld (`WEBUTIL_HOST`)

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``vr_exte_warr_msil_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| Host | Function | Function(cmd in VARCHAR2) RETURN PLS_INTEGER | ProgramUnit: VIEW_EXCEL_REP | **COMMENTED OUT / INACTIVE** - referenced only within the commented-out section of VIEW_EXCEL_REP; executes a host operating-system command and returns a status code. Not executed in the current form |

**Total Active Routines:** 0 of 14 in webutil.pld source
**Inactive / commented-only routines:** 1

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| ID | Service Name | Database Object | Input Parameters | Output | Business Function | API Endpoint Suggestion |
| -- | ------------ | --------------- | ---------------- | ------ | ----------------- | ----------------------- |
| MS-001 | Extended Warranty New Sale Search (First OEM) | DMSD_EW_SALE, MWAR_EXTE, AM_DEALER_LOC, VT_EXTSAWA | principal, region, parent_group, dealer_map_cd, loc_cd, from_date, to_date, model_cd, variant_cd, ew_type, sold_from, payment_type | List of extended warranty new-sale records with policy details, premium, tax amounts, dealer info, and status | Retrieves new extended warranty sale records for the first OEM organisation matching the supplied search criteria | `GET /api/ew-sales/new-sales?principal={}&from={}&to={}&dealer={}...` |
| MS-002 | Extended Warranty Conversion Search (First OEM) | DMSD_EW_SALE, MWAR_EXTE, AM_DEALER_LOC | principal, region, parent_group, dealer_map_cd, loc_cd, from_date, to_date, model_cd, variant_cd, ew_type, sold_from, payment_type | List of extended warranty conversion/upgrade records with differential premium, conversion dealer info, and tax amounts | Retrieves extended warranty conversion/upgrade records for the first OEM organisation matching the supplied criteria | `GET /api/ew-sales/conversions?principal={}&from={}&to={}&dealer={}...` |
| MS-003 | Extended Warranty Cancellation Search (First OEM) | DMSD_EW_SALE, MWAR_EXTE, AM_DEALER_LOC, VT_EXTSAWA | principal, region, parent_group, dealer_map_cd, loc_cd, from_date, to_date, model_cd, variant_cd, ew_type, sold_from, payment_type | List of extended warranty cancellation records with cancel amount, credit amount, and remarks | Retrieves extended warranty cancellation records for the first OEM organisation matching the supplied criteria | `GET /api/ew-sales/cancellations?principal={}&from={}&to={}&dealer={}...` |
| MS-004 | Extended Warranty New Sale Search (Second OEM) | DMSD_EW_SALE_SM, MWAR_EXTE, AM_DEALER_LOC | principal, region, parent_group, dealer_map_cd, loc_cd, from_date, to_date, model_cd, variant_cd, ew_type, sold_from, vend | List of extended warranty new-sale records for the second OEM with vendor code, premium, GST amounts, dealer info, and status | Retrieves new extended warranty sale records for the second OEM organisation matching the supplied criteria | `GET /api/ew-sales/new-sales-sm?principal={}&from={}&to={}&vendor={}...` |
| MS-005 | Extended Warranty Conversion Search (Second OEM) | DMSD_EW_SALE_SM, MWAR_EXTE, AM_DEALER_LOC | principal, region, parent_group, dealer_map_cd, loc_cd, from_date, to_date, model_cd, variant_cd, ew_type, sold_from, vend | List of extended warranty conversion records for the second OEM with vendor code and conversion details | Retrieves conversion/upgrade records for the second OEM organisation | `GET /api/ew-sales/conversions-sm?principal={}&from={}&to={}&vendor={}...` |
| MS-006 | Extended Warranty Cancellation Search (Second OEM) | DMSD_EW_SALE_SM, MWAR_EXTE, AM_DEALER_LOC | principal, region, parent_group, dealer_map_cd, loc_cd, from_date, to_date, model_cd, variant_cd, ew_type, sold_from, vend | List of extended warranty cancellation records for the second OEM with vendor code | Retrieves cancellation records for the second OEM organisation | `GET /api/ew-sales/cancellations-sm?principal={}&from={}&to={}&vendor={}...` |
| MS-007 | Extended Warranty CSV Export (First OEM) | DMSD_EW_SALE, MWAR_EXTE, AM_DEALER_LOC, VT_EXTSAWA, GM_MOD, GM_VAR, GM_VIN, VM_EW_PREM, GM_EMP, BANK | principal, report_type, from_date, to_date, region, parent_group, dealer_map_cd, loc_cd, model_cd, variant_cd, ew_type, sold_from, payment_type | CSV file stream with report header and enriched extended warranty rows (standard premium, employee details, EMI breakdown) | Generates and delivers a detailed CSV export of extended warranty data for the first OEM, including enriched columns not shown on screen | `GET /api/ew-reports/export-csv?principal={}&type={}&from={}&to={}...` |
| MS-008 | Extended Warranty CSV Export (Second OEM) | DMSD_EW_SALE_SM, MWAR_EXTE, AM_DEALER_LOC, GM_MOD, GM_VAR, GM_VIN, GM_EMP | principal, report_type, from_date, to_date, region, parent_group, dealer_map_cd, loc_cd, model_cd, variant_cd, ew_type, sold_from, vend | CSV file stream with report header and enriched extended warranty rows (vendor code, employee details) | Generates and delivers a detailed CSV export of extended warranty data for the second OEM, including vendor code and employee columns | `GET /api/ew-reports/export-csv-sm?principal={}&type={}&from={}&to={}...` |
| MS-009 | EW Policy Status Lookup | SF_EW_POLICY_STATUS | policy_no | Policy status string | Returns the current status of an extended warranty policy for display in search results and exports | `GET /api/ew-policies/{policy_no}/status` |
| MS-010 | EW Validity Detail Lookup | SF_GET_EW_VALIDITY_DTL | policy_no, query_type | Warranty type detail/description | Returns the warranty type detail for a given policy number, used to enrich search results for the first OEM | `GET /api/ew-policies/{policy_no}/validity-detail?type={}` |
| MS-011 | Dealer Location Reference | AM_DEALER_LOC | principal, region, parent_group, dealer_map_cd, loc_cd | List of active dealer locations with codes and descriptions | Provides the dealer and location selection list used to populate the reporting filter and resolve dealer names in reports | `GET /api/dealers?principal={}&region={}...` |
| MS-012 | Vehicle Model Reference | GM_MOD | principal | List of vehicle models (code + description), excluding internal types | Provides the model filter list and model descriptions used in search and export output | `GET /api/vehicles/models?principal={}` |
| MS-013 | Vehicle Variant Reference | GM_VAR | principal, model_cd | List of vehicle variants (code + description) for the selected model | Provides the variant filter list dependent on the selected model | `GET /api/vehicles/variants?principal={}&model={}` |
| MS-014 | Extended Warranty Type Reference | AM_LIST (EXTE_WARR_TYPE) | principal | List of EW type codes and descriptions | Provides the EW Type filter drop-down list | `GET /api/ew-types?principal={}` |
| MS-015 | Geographic Region Reference | GM_REGN | principal | List of geographic region codes and descriptions | Provides the Region filter drop-down list | `GET /api/regions?principal={}` |
| MS-016 | Copyright Declaration | SF_COPYRIGHT_DECLARATION | (none) | Copyright string for the current financial year | Returns the OEM copyright notice text for display in the application | `GET /api/system/copyright` |

**Total Microservices Identified: 16**

---

## 17. Workflows

| ID | Workflow Name | Trigger Event | Steps | Decision Points | End State |
| -- | ------------- | ------------- | ----- | --------------- | --------- |
| WF-001 | Extended Warranty Record Search | User clicks the Search button (WHEN-BUTTON-PRESSED on PB_SEARCH) | 1. Session organisation context is evaluated. 2. Route to PMC1 (first OEM) or PMC2 (second OEM) search procedure. 3. Validate all seven mandatory filter fields. 4. Execute the appropriate query (New Sales / Conversions / Cancellations) using the user-selected filters. 5. Populate the results grid with the matching records. 6. Update the matching-records counter. | (a) Organisation context = first OEM -> use PMC1 procedure; = second OEM -> use PMC2 procedure. (b) EW Status = New Sales -> use cursor C1; = Conversions -> use cursor C2; = Cancellations -> use cursor C3. (c) Any mandatory filter is blank -> abort with a named error alert and navigate focus to the blank field. | Results grid populated with matching extended warranty records and the matching-records counter updated; or search aborted with a mandatory-field error displayed. |
| WF-002 | Extended Warranty CSV Export | User clicks the Export to Excel button (WHEN-BUTTON-PRESSED on PB_EXCEL) | 1. Session organisation context is evaluated. 2. Route to PMC1 or PMC2 export procedure. 3. Validate all seven mandatory filter fields. 4. Resolve the dealer display name for the report header. 5. Derive the output CSV filename from the user ID and current timestamp. 6. Normalise the vendor filter (second OEM only). 7. Build the dynamic CSV SQL query for the selected EW Status and context. 8. Call VIEW_EXCEL_REP to execute the query, write the CSV file, and open it in the browser. | (a) Organisation context = first OEM -> PMC1; = second OEM -> PMC2. (b) EW Status = New Sales / Conversions / Cancellations -> corresponding query variant. (c) Any mandatory filter is blank -> abort with named error alert. (d) Vendor not CWI or GAN (second OEM) -> normalise to All. (e) Row count > 65,535 -> truncate and warn. (f) File path contains spaces -> redirect to C:\ and inform user. | CSV file written to the server and opened in the user's browser; or export aborted with an error. |
| WF-003 | Form Initialization | Form is opened by the user (PRE-FORM then WHEN-NEW-FORM-INSTANCE trigger sequence) | 1. PRE-FORM registers the session name in database monitoring tables and sets initial column visibility. 2. WHEN-NEW-FORM-INSTANCE displays the copyright notice, maximises the window, populates EW Type and Region lists, populates Vendor list. 3. Default values are applied to all filter fields (EW Status = New Sales, date defaults, model/variant/EW Type = All, dealer = ALL DEALERS). 4. Column visibility is set for the results grid (pre-GST or GST era based on default From Date; vendor filter visibility based on principal). | (a) Default From Date on or after 1 July 2017 -> show GST columns, hide pre-GST columns; otherwise reverse. (b) Session running under second OEM principal -> show Vendor filter and Vendor column; otherwise hide them. | Screen is displayed with all filter fields populated with default values and the results grid configured with the correct column layout. |
| WF-004 | Filter Change - Results Grid Cleared | User selects a different value for one of the filter drop-downs that has a WHEN-LIST-CHANGED trigger (Sold From, Region, EW Type, EW Status / Report Type, Vendor) | 1. WHEN-LIST-CHANGED fires for the changed filter. 2. System navigates to the results block. 3. Results grid is cleared (no validate). 4. Matching-records counter is reset to zero. 5. Focus returns to the filter field (or to a related field, depending on the filter). For EW Status change: the column layout is also adjusted before clearing (per WF-005). | (a) EW Status changed -> also invoke column visibility adjustment (WF-005) before clearing the grid. (b) Vendor changed -> navigate focus to the Region field after clearing. | Results grid cleared; matching-records counter reset to zero; cursor at the relevant filter field. |
| WF-005 | EW Status Column Layout Adjustment | User changes the EW Status filter (WHEN-LIST-CHANGED on P_REP_TYPE) | 1. Evaluate the new EW Status value (New Sales, Conversions, or Cancellations). 2. Apply the appropriate column visibility configuration (field prompt labels, visible/hidden columns per status type). 3. Apply the GST/pre-GST column set based on the contract From Date. 4. Navigate to the results block, clear it, and reset the counter. 5. Return focus to the EW Status field. | (a) New Sales -> Sold By / Sale Date labels; standard tax columns; Difference and Cancel columns hidden. (b) Conversions -> Upgraded By / Conv. Date labels; Difference columns shown; standard tax columns hidden. (c) Cancellations -> Cancelled By / Cancel Date labels; Cancel Amount, Remarks shown; Status, Debit, Difference hidden. (d) From Date ≥ 1 Jul 2017 -> GST columns shown; pre-GST columns hidden; otherwise reverse. | Results grid reconfigured for the selected EW Status; old results cleared; focus on EW Status field. |
| WF-006 | Date Range Validation and Auto-Fill | User enters or changes the contract From Date (WHEN-VALIDATE-ITEM on CONT_FROM_DATE) | 1. Check that From Date is not in the future; if it is, display error and stop. 2. If From Date is valid and non-null, auto-calculate the To Date as From Date + 1 month - 1 day, capping at today if in the future. 3. Adjust GST/pre-GST column visibility based on the new From Date. | (a) From Date > today -> error *"From Date can't exceed Current Date"*; FORM_TRIGGER_FAILURE. (b) Calculated To Date > today -> cap at today. (c) From Date ≥ 1 Jul 2017 -> GST columns; otherwise pre-GST columns. | From Date validated; To Date auto-populated; results grid column layout adjusted for the date era. |
| WF-007 | Date Range End Validation | User enters or changes the contract To Date (WHEN-VALIDATE-ITEM on CONT_TO_DATE) | 1. Check that To Date is not in the future; if it is, reset to From Date and stop. 2. Check that To Date is not before From Date; if it is, reset to From Date and stop. 3. Check that the range does not exceed 30 days; if it does, reset to From Date and stop. | (a) To Date > today -> *"To Date can't exceed Current Date"*; reset to From Date; FORM_TRIGGER_FAILURE. (b) To Date < From Date -> *"To Date can't be less than From Date"*; reset to From Date; FORM_TRIGGER_FAILURE. (c) To Date - From Date > 30 days -> *"Contract To Date can't be more than 30 days after From Date"*; reset to From Date; FORM_TRIGGER_FAILURE. | To Date validated within the allowed range; or error displayed and To Date reset to From Date. |
| WF-008 | Form Exit and Session Deregistration | User initiates form exit via keyboard shortcut (KEY-EXIT), toolbar Exit button (PB_EXIT), NB_EXIT button, or NB_OK button | 1. For KEY-EXIT and PB_EXIT: clear session monitoring entries (client info and module name set to empty). 2. Close the form without save validation (EXIT_FORM(NO_VALIDATE)). For NB_EXIT: set the global exit flag to EXIT, then EXIT_FORM(NO_VALIDATE). For NB_OK: EXIT_FORM(NO_VALIDATE) directly. | (a) KEY-EXIT: if in Enter-Query mode, call DO_KEY('EXIT_FORM') only. (b) PB_EXIT: call DO_KEY('EXIT_FORM') regardless of form status. (c) NB_EXIT: set exit flag then exit. (d) NB_OK: exit directly. | Database session monitoring entries cleared (for KEY-EXIT/PB_EXIT paths); form closed. |

**Total Workflows Identified: 8**

---

## 18. PLD-Backed Logic

*Maps shared library routines to their business function and suggested API contracts.*

### DPL.pld (`general`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | CHECK_FORM_FAILURE | Validation | Trigger: KEY-COMMIT in Form | /api/v1/pld/check_form_failure | **COMMENTED OUT / INACTIVE** - when the last Forms operation fails, then the error is displayed and execution is halted; not active in current form |
| PLD-002 | CHECK_NULL | Validation | ProgramUnit: PROC_REP_SEARCH_PMC1, ProgramUnit: PROC_REP_SEARCH_PMC2, ProgramUnit: PROC_REP_XL_PMC1, ProgramUnit: PROC_REP_XL_PMC2 | /api/v1/pld/check_null | When a mandatory filter value is null, then an error dialog is displayed and execution is halted |
| PLD-003 | DISP_TEXT | Business Logic | Trigger: ON-ERROR in Form, Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.CONT_FROM_DATE, Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.CONT_TO_DATE | /api/v1/pld/disp_text | When a message and title are provided, then a modal alert dialog is displayed to the user with the appropriate alert style |
| PLD-004 | L_POPULATE | Business Logic | Trigger: WHEN-NEW-FORM-INSTANCE in Form | /api/v1/pld/l_populate | When the form is initialised, then the specified list item is populated from the AM_LIST lookup table filtered by list name and current principal code |
| PLD-005 | l_pop_list_item | Business Logic | Trigger: WHEN-NEW-FORM-INSTANCE in Form | /api/v1/pld/l_pop_list_item | When the form is initialised, then a named record group is created from a supplied SQL query and the corresponding list item is populated |
| PLD-006 | RAISE_ERROR | Validation | Trigger: ON-ERROR in Form | /api/v1/pld/raise_error | When an error code is raised, then the corresponding message is retrieved, classified, and displayed; execution is halted for error-type messages |


---

### webutil.pld (`WEBUTIL_C_API`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | ID_NULL | Business Logic | ProgramUnit: VIEW_EXCEL_REP | /api/v1/pld/id_null | When a WebUtil handle is tested, then TRUE is returned if the handle is null and FALSE if it is valid |


---

### webutil.pld (`WEBUTIL_FILE`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | FILE_SAVE_DIALOG | Business Logic | ProgramUnit: VIEW_EXCEL_REP | /api/v1/pld/file_save_dialog | **COMMENTED OUT / INACTIVE** - when a save dialog was shown, then the user-selected file path was returned; not active in current form |


---

### webutil.pld (`WEBUTIL_FILE_TRANSFER`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | URL_To_Client | Business Logic | ProgramUnit: VIEW_EXCEL_REP | /api/v1/pld/url_to_client | **COMMENTED OUT / INACTIVE** - when a server URL and client destination were provided, then the file was transferred to the client; not active in current form |


---

### webutil.pld (`WEBUTIL_HOST`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | Host | Business Logic | ProgramUnit: VIEW_EXCEL_REP | /api/v1/pld/host | **COMMENTED OUT / INACTIVE** - when a host command was executed, then a status code was returned; not active in current form |

---

---

## 19. PCK-Backed Logic

*NO PCK files found - no ``*.pck`` source files were discovered in ``/app/workspace/vr_exte_warr_msil-d7275dae8f50/in``. PCK-backed logic cannot be generated without uploaded PCK sources.*

---

## 20. System Interfaces

### 20.1 Database Integrations

| Interface Name | Type | Purpose | Data Flow | Error Handling |
| -------------- | ---- | ------- | --------- | -------------- |
| Extended Warranty DMS Transactions (DMSD_EW_SALE) | Database Table (SELECT) | Primary source of extended warranty new-sale, conversion, and cancellation transactions for the first OEM | Form reads transaction records filtered by date range, principal, region, dealer, model, variant, EW type, sold-from channel, and payment type | Errors surfaced via ON-ERROR trigger; FORM_TRIGGER_FAILURE raised on database errors; session rolled back |
| Legacy Extended Warranty Transactions (VT_EXTSAWA) | Database Table (SELECT) | Legacy source of extended warranty records; UNIONed with DMSD_EW_SALE for New Sales and Cancellation queries under the first OEM context | Form reads records from this table for new-sale and cancelled policies when processing first OEM data | Same ON-ERROR handling as DMSD_EW_SALE |
| Extended Warranty Policy Master (MWAR_EXTE) | Database Table (SELECT) | Policy-level master data joined to DMSD_EW_SALE and VT_EXTSAWA on policy number; provides model code, variant code, and staff identifiers | Form reads from this table as part of all search and export queries | Same ON-ERROR handling |
| Extended Warranty DMS Transactions - Second OEM (DMSD_EW_SALE_SM) | Database Table (SELECT) | Source of extended warranty transactions for the second OEM organisation | Form reads records from this table for all search and export operations when the session runs under the second OEM principal | Same ON-ERROR handling |
| Dealer Location Master (AM_DEALER_LOC) | Database Table (SELECT) | Provides dealer name, location description, region, parent group, and dealer-map codes for the filter and report output | Form reads from this table to populate the dealer/location filter lists (RG_LOC, RG_DEALER), to resolve dealer names in the export report header, and as a join table in search/export queries | Same ON-ERROR handling |
| Dual (DUAL) | Oracle System Table (SELECT) | Used in WHEN-NEW-FORM-INSTANCE to populate the default dealer/location field values and to construct EW Type and Region list queries | Form reads fixed literal values via DUAL to set defaults for dealer/location fields | Standard Oracle error handling |
| Application Reference Lists (AM_LIST) | Database Table (SELECT) | Source of the EW Type filter drop-down list values, filtered by list name EXTE_WARR_TYPE and the current OEM principal | Form reads at startup to populate the EW Type list item via GENERAL.L_POP_LIST_ITEM | Same ON-ERROR handling |
| Geographic Region Master (GM_REGN) | Database Table (SELECT) | Source of geographic region codes and descriptions for the Region filter drop-down | Form reads at startup to populate the Region list item via GENERAL.L_POP_LIST_ITEM | Same ON-ERROR handling |
| Vehicle Model Master (GM_MOD) | Database Table (SELECT) | Source of vehicle model codes and descriptions for the Model filter look-up list (RG_MODEL) and export query model descriptions | Form reads to populate RG_MODEL and to enrich model descriptions in the CSV export | Same ON-ERROR handling |
| Vehicle Variant Master (GM_VAR) | Database Table (SELECT) | Source of vehicle variant codes and descriptions for the Variant filter look-up list (RG_VARIANT) and results grid variant description | Form reads to populate RG_VARIANT, to look up variant descriptions during search results population, and to enrich variant descriptions in the CSV export | Same ON-ERROR handling |
| Standard EW Premium Master (VM_EW_PREM) | Database Table (SELECT) | Provides standard (list) premium amounts for each variant/warranty-type/date combination; used in the first OEM CSV export for premium comparison | Form reads as a subquery in the PROC_REP_XL_PMC1 dynamic query | Same ON-ERROR handling |
| Employee Master (GM_EMP) | Database Table (SELECT) | Provides employee (service advisor/DSE) MSPIN, name, and designation for the CSV export; also used by the Excel export for the second OEM | Form reads as a subquery in PROC_REP_XL_PMC1 and PROC_REP_XL_PMC2 dynamic queries | Same ON-ERROR handling |
| Database Application Monitoring (DBMS_APPLICATION_INFO) | Oracle Built-in Package | Records and clears the form's module name and client identifier in the database session for monitoring purposes | Form writes module/client info at startup via PRE-FORM; clears it on exit via KEY-EXIT | No error handling defined; failure would propagate as a general database error |

### 20.2 External System Integrations

The form integrates with the server-side file system and the user's web browser for CSV export delivery.

| System Name | Integration Type | Purpose | Protocol | Endpoint | Data Exchange | Success / Error Codes |
| ----------- | ---------------- | ------- | -------- | -------- | ------------- | --------------------- |
| Report Server File System | Server-side file write (TEXT_IO) | Stores the generated CSV export file on the application server so it can be served to the user's browser | Server-side file I/O (Oracle Forms TEXT_IO) | Path derived from `/reports/DMS/excelpath.txt` base path + user-ID/timestamp filename | Form writes CSV row data to the file; path configuration is read from the server-side path file | On success: file written and URL constructed for browser delivery. On failure: error message *"Error  -"* followed by the Oracle error code and message is displayed; FORM_TRIGGER_FAILURE raised |
| User Web Browser | File delivery via WEB.SHOW_DOCUMENT (WEBUTIL) | Opens the generated CSV file in the user's browser for download or viewing | HTTP/file URL (opened via WEBUTIL WEB.SHOW_DOCUMENT) | The server-side file URL constructed from the report server path + filename | URL passed to the browser; no data is exchanged back from the browser | No explicit error handling after WEB.SHOW_DOCUMENT call; any WEBUTIL failure would surface via standard Forms error handling |

### 20.3 Report Integrations

Populate from `reference_data.reports` in the functional slice - one row per actual report file name.

| Report Name | Report Server | Parameters | Output Format | Trigger |
| ----------- | ------------- | ---------- | ------------- | ------- |
| rep.rdf | Runtime (INFERRED - report object defined in form XML with Execute Mode = Runtime; actual server not specified in source) | Not explicitly defined in the report object declaration; parameters are embedded as literals in the dynamic CSV SQL query built by PROC_REP_XL_PMC1 and PROC_REP_XL_PMC2 (INFERRED) | CSV file written via TEXT_IO and delivered via WEB.SHOW_DOCUMENT; Oracle Reports .rdf format is declared but the actual runtime delivery is via the form's own CSV generation logic (VIEW_EXCEL_REP program unit) | WHEN-BUTTON-PRESSED on CB_DUMMY.PB_EXCEL triggers PROC_REP_XL_PMC1 (first OEM principal) or PROC_REP_XL_PMC2 (second OEM principal), which call VIEW_EXCEL_REP to write and deliver the CSV |

---

### 20.3.1 Parameters Passed to the Report

This form does not pass parameters to an Oracle Report. No report parameters were identified in the form sources.

## 21. Procedure and Function Business Rule Catalogue

End-to-end business requirement specification for every stored procedure and function referenced by the VR_EXTE_WARR_MSIL form.

### 21.1 Catalogue Index

22 procedures/functions - each SP ID links to its detailed specification in Section 21.2.

| SP Index | Routine Name |
| :--- | :--- |
| [SP-001](#SP-001--PROC_REP_SEARCH_PMC1) | PROC_REP_SEARCH_PMC1 |
| [SP-002](#SP-002--PROC_REP_SEARCH_PMC2) | PROC_REP_SEARCH_PMC2 |
| [SP-003](#SP-003--PROC_REP_XL_PMC1) | PROC_REP_XL_PMC1 |
| [SP-004](#SP-004--PROC_REP_XL_PMC2) | PROC_REP_XL_PMC2 |
| [SP-005](#SP-005--VIEW_EXCEL_REP) | VIEW_EXCEL_REP |
| [SP-006](#SP-006--GENERAL.CHECK_NULL) | GENERAL.CHECK_NULL |
| [SP-007](#SP-007--GENERAL.DISP_TEXT) | GENERAL.DISP_TEXT |
| [SP-008](#SP-008--GENERAL.L_POPULATE) | GENERAL.L_POPULATE |
| [SP-009](#SP-009--GENERAL.L_POP_LIST_ITEM) | GENERAL.L_POP_LIST_ITEM |
| [SP-010](#SP-010--GENERAL.RAISE_ERROR) | GENERAL.RAISE_ERROR |
| [SP-011](#SP-011--WEBUTIL.ERRORALERT) | WEBUTIL.ERRORALERT |
| [SP-012](#SP-012--WEBUTIL.FCLOSE) | WEBUTIL.FCLOSE |
| [SP-013](#SP-013--WEBUTIL.FOPEN) | WEBUTIL.FOPEN |
| [SP-014](#SP-014--WEBUTIL.GETIMPLCLASS) | WEBUTIL.GETIMPLCLASS |
| [SP-015](#SP-015--WEBUTIL.GETPROPERTY) | WEBUTIL.GETPROPERTY |
| [SP-016](#SP-016--WEBUTIL.GET_LINE) | WEBUTIL.GET_LINE |
| [SP-017](#SP-017--WEBUTIL.ID_NULL) | WEBUTIL.ID_NULL |
| [SP-018](#SP-018--WEBUTIL.PUT_LINE) | WEBUTIL.PUT_LINE |
| [SP-019](#SP-019--WEBUTIL.SETPROPERTY) | WEBUTIL.SETPROPERTY |
| [SP-020](#SP-020--SF_COPYRIGHT_DECLARATION) | SF_COPYRIGHT_DECLARATION |
| [SP-021](#SP-021--SF_EW_POLICY_STATUS) | SF_EW_POLICY_STATUS |
| [SP-022](#SP-022--SF_GET_EW_VALIDITY_DTL) | SF_GET_EW_VALIDITY_DTL |

---

### 21.2 Detailed Specifications

#### SP-001 - PROC_REP_SEARCH_PMC1

**Invoked From:**

- vr_exte_warr_msil_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

Search Criteria (N/A / CN_MAIN)

---

**Purpose**

Validates all mandatory search-criteria fields, then populates the on-screen `B_EW` data block with Extended Warranty policy records from both the live DMS system (`DMSD_EW_SALE` / `MWAR_EXTE`) and the legacy/migrated system (`VT_EXTSAWA`), covering new sales, conversions (upgrades), and cancellations according to the selected report type. Each row is enriched with policy status, warranty type detail, and variant description before display.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.CHECK_NULL ([SP-006](#SP-006--GENERAL.CHECK_NULL)) - matched by member name (package unresolved)
- SF_EW_POLICY_STATUS ([SP-021](#SP-021--SF_EW_POLICY_STATUS)) - standalone source file
- SF_GET_EW_VALIDITY_DTL ([SP-022](#SP-022--SF_GET_EW_VALIDITY_DTL)) - standalone source file

---

**Step-by-Step Business Logic**

- Step 1 - Check that each of the seven mandatory fields (Location, Report Type, Contract From Date, Contract To Date, Model, Variant, EW Type) is non-NULL; for any NULL field, call `GENERAL.CHECK_NULL` to display an error alert and navigate to that field, aborting the procedure.
- Step 2 - Determine the report type from `:CB_DUMMY.P_REP_TYPE` (`'N'` = New Sales, `'U'` = Conversions/Upgrades, `'C'` = Cancellations).
- Step 3 - For **New Sales** (`P_REP_TYPE = 'N'`): open Cursor C1, which queries `DMSD_EW_SALE` joined to `MWAR_EXTE` and `AM_DEALER_LOC` for new-sale transactions (`EXTE_TRAN_TYPE = 'N'`) within the selected date range, applying all user-selected filters (region, parent group, dealer, location, model, variant, EW type, payment type, sold-from channel). A UNION combines matching records from the legacy `VT_EXTSAWA` table (filtered by cancellation flag = NULL / not cancelled). For each cursor row, the warranty type is derived via `SF_GET_EW_VALIDITY_DTL`, and the policy status via `SF_EW_POLICY_STATUS`. A GST-era warrant-type upgrade transition code is computed using a CASE expression on old/new warranty type pairs.
- Step 4 - Navigate to block `B_EW`, clear it, and position at the first record.
- Step 5 - Loop through all C1 rows, mapping each cursor column to the corresponding `B_EW` block item (policy number, VIN, dates, variant, warranty type, customer name, premium, commissions, tax amounts, GST components, dealer details, status, sold-from, payment type, conversion status code). For each row, also look up the variant description from `GM_VAR` (silently ignoring failures).
- Step 6 - After the loop, set `:CB_DUMMY.TOT_REC` to the current trigger-record count minus one to reflect the total records loaded.
- Step 7 - For **Conversions** (`P_REP_TYPE = 'U'`): repeat Steps 4-6 using Cursor C2, which queries `DMSD_EW_SALE` for upgrade/transfer transactions (`EXTE_TRAN_TYPE IN ('U','X')`), joining on the conversion dealer/location fields. The `B_EW` block is populated with conversion-specific fields (conversion date as contract date, differential premium, conversion tax components). Legacy `VT_EXTSAWA` records are not included in the C2 cursor.
- Step 8 - For **Cancellations** (`P_REP_TYPE = 'C'`): repeat Steps 4-6 using Cursor C3, which queries `DMSD_EW_SALE` for cancellation transactions (`EXTE_TRAN_TYPE = 'C'`). The cancellation amount is computed as the greater of 10% of the policy premium or 200. The credit amount is premium minus commission, service-tax commission, SBC tax, and the cancellation fee. A UNION adds cancelled records from `VT_EXTSAWA` (where `EXTE_CANCEL_FLAG = 'Y'`).
- Step 9 - After all branches, navigate to the first record of `B_EW`.

---
**Decision Points**

DP-001

Condition:
Any of the seven mandatory criteria fields (Location, Report Type, Contract From Date, Contract To Date, Model, Variant, EW Type) is NULL.

TRUE:
Call `GENERAL.CHECK_NULL` for that field, display an error alert, navigate focus to the offending field, and abort execution.

FALSE:
All mandatory fields are present; proceed to the report-type branch.

DP-002

Condition:
`:CB_DUMMY.P_REP_TYPE` equals `'N'` (New Sales).

TRUE:
Execute Cursor C1 (new-sale transactions from DMSD_EW_SALE UNION VT_EXTSAWA) and populate `B_EW` with new-sale policy data.

FALSE:
Evaluate for Conversion or Cancellation report type (see DP-003 and DP-004).

DP-003

Condition:
`:CB_DUMMY.P_REP_TYPE` equals `'U'` (Conversions/Upgrades).

TRUE:
Execute Cursor C2 (upgrade/transfer transactions from DMSD_EW_SALE) and populate `B_EW` with conversion data.

FALSE:
Evaluate for Cancellation report type (see DP-004).

DP-004

Condition:
`:CB_DUMMY.P_REP_TYPE` equals `'C'` (Cancellations).

TRUE:
Execute Cursor C3 (cancellation transactions from DMSD_EW_SALE UNION cancelled VT_EXTSAWA records) and populate `B_EW` with cancellation data including cancellation fee and credit amount.

FALSE:
No matching branch; no data is loaded (implicit end of IF-ELSIF chain).

DP-005

Condition:
A warranty type upgrade transition is present (e.g. `EXTE_WARR_TYPE_OLD = 'I'` and `EXTE_WARR_TYPE = 'II'`), evaluated by the inline CASE expression in C1/C2/C3.

TRUE:
Compute and return a conversion transition code (e.g. `'C3T4'`, `'C3T5'`, `'C4T5'`, `'C4T6'`, `'C5T6'`) representing the old and new coverage/term tier combination.

FALSE:
Return NULL for the conversion status code.

DP-006

Condition:
The online sale flag (`ew.online_sale_flag`) is `'Y'` and the EMI flag (`ew.emi_flag`) is `'Y'`.

TRUE:
Label the payment type as `'EMI'`.

FALSE:
Evaluate further conditions to assign `'Online But Not EMI'`, `'Offline DMS'`, or `'NA'` as the payment type.

---
**Database Interactions**

- DB-001 - Read DMSD_EW_SALE - Reads data from DMSD_EW_SALE for lookup or validation.
- DB-002 - Read VT_EXTSAWA - Reads data from VT_EXTSAWA for lookup or validation.
- DB-003 - Read GM_VAR - Reads data from GM_VAR for lookup or validation.
**Business Rules**

- SBR-001 - All seven search-criteria fields (Location, Report Type, Contract From Date, Contract To Date, Model, Variant, EW Type) must be populated before the search may proceed.
- SBR-002 - Records are filtered to the current principal (`aloc.principal_map_cd = :global.principal`) at all times, preventing cross-principal data leakage.
- SBR-003 - New-sale transactions are identified by `EXTE_TRAN_TYPE = 'N'`; conversion/upgrade transactions by `EXTE_TRAN_TYPE IN ('U', 'X')`; cancellation transactions by `EXTE_TRAN_TYPE = 'C'`.
- SBR-004 - Warranty type `'X'` is not applicable in the PMC1 cursors (it is a PMC2 concern); SF_GET_EW_VALIDITY_DTL is used to resolve the current warranty type from the new-sale record.
- SBR-005 - The cancellation fee for a cancelled policy is the greater of 10% of the policy premium or ₹200.
- SBR-006 - The credit amount on cancellation is calculated as policy premium minus dealer commission, minus service-tax commission, minus SBC tax, minus the cancellation fee.
- SBR-007 - Warranty type upgrade transition codes are derived from a fixed mapping of old-to-new warranty type pairs (e.g. I->II = `'C3T4'`, I->III = `'C3T5'`, IV->VI = `'C4T6'`, V->VI = `'C5T6'`); unrecognised combinations yield NULL.
- SBR-008 - Payment type classification gives priority to the online sale flag over the pay-mode field: if `online_sale_flag = 'Y'`, the transaction is classified as `'EMI'` or `'Online But Not EMI'` regardless of `EXTE_PAY_MODE`.

---
**Implementation Logic**

```plsql
PROCEDURE proc_rep_search_pmc1 IS
CURSOR C1 IS
		SELECT X.EXTE_POLICY_NO,  -----added by chandan START
		X.EXTE_VIN_NO,
		X.EXTE_REGISTRATION_NO,
		X.EXTE_RETLSALE_DT,
		X.EXTE_CONTRACT_DATE,
		X.EXTE_MODL_CODE,
		X.EXTE_VARIANT_CD,
		X.EXTE_WARR_TYPE, 
		X.EXTE_CUST_NAME,
		X.EXTE_CONTRACT_MILEAGE,
		X.EXTE_VALID_DATE,
		X.EXTE_VALID_MILEAGE,
		X.EXTE_PREMIUM_CALCULATED,
		X.EXTE_PREM_DLR_COMM,
		X.EXTE_PREM_SRV_TAX,
		X.exte_tot_prem_srv_tax,
		X.exte_tot_conv_srv_tax,
		X.DEBIT_AMT,
		X.EXTE_CREATED_BY,
		X.status,
		X.DEALER_NAME,
		X.LOC_DESC,
		X.EXTE_PREM_SBC_TAX,           
		X.exte_tot_prem_sbc_tax, 
		X.exte_tot_conv_sbc_tax,  
		X.EXTE_PREM_KKC_TAX,          
		X.exte_tot_prem_kkc_tax, 
		X.exte_tot_conv_kkc_tax,  
		X.EXTE_PREM_CGST_AMT,
		X.EXTE_PREM_SGST_AMT,
		X.EXTE_PREM_IGST_AMT,      
		X.EXTE_PREM_COMM_IGST,
		X.EXTE_PREM_COMM_SGST,
		X.EXTE_PREM_COMM_CGST,
		X.EXTE_WARR_TYPE_OLD,
			X.Sold_From,
			X.Payment_Type  -----added by chandan end
  FROM (SELECT /*+ index (ALOC XPKAM_DEALER_LOC)*/
      EW.EXTE_POLICY_NO,
      EW.EXTE_VIN_NO,
      EW.EXTE_REGISTRATION_NO,
      EW.EXTE_RETLSALE_DT,
      EW.EXTE_CONTRACT_DATE,
      XW.EXTE_MODL_CODE,
      XW.EXTE_VARIANT_CD,
      SF_GET_EW_VALIDITY_DTL(EW.EXTE_POLICY_NO,'Q') EXTE_WARR_TYPE, 
      --EW.EXTE_WARR_TYPE,
      EW.EXTE_CUST_NAME,
      EW.EXTE_CONTRACT_MILEAGE,
      EW.EXTE_VALID_DATE,
      EW.EXTE_VALID_MILEAGE,
      EW.EXTE_POLICY_PREMIUM EXTE_PREMIUM_CALCULATED,--EW.EXTE_PREMIUM_CALCULATED, --EW.EXTE_PREMIUM,
      EW.EXTE_COMMISION_AMT EXTE_PREM_DLR_COMM,---EW.EXTE_PREM_DLR_COMM,
      EW.EXTE_SRV_TAX_COMMISSION EXTE_PREM_SRV_TAX,--EW.EXTE_PREM_SRV_TAX,
      NVL(EW.EXTE_SRV_TAX_PREMIUM,0) exte_tot_prem_srv_tax,---NVL(EW.exte_tot_prem_srv_tax,0) exte_tot_prem_srv_tax,
      NVL(EW.EXTE_SRV_TAX_PREMIUM,0) exte_tot_conv_srv_tax,----NVL(EW.exte_tot_conv_srv_tax,0) exte_tot_conv_srv_tax,
      (NVL(EW.EXTE_POLICY_PREMIUM,0) - NVL(EW.EXTE_COMMISION_AMT,0) - NVL(EW.EXTE_SRV_TAX_COMMISSION,0)-NVL(EW.EXTE_TOT_PREM_SBC_TAX,0)-NVL(EW.EXTE_TOT_PREM_KKC_TAX,0))DEBIT_AMT,
     --- (NVL(EW.EXTE_PREMIUM_CALCULATED,0) - NVL(EW.EXTE_PREM_DLR_COMM,0) - NVL(EW.EXTE_PREM_SRV_TAX,0)-NVL(EW.EXTE_PREM_SBC_TAX,0)-NVL(EW.EXTE_PREM_KKC_TAX,0))DEBIT_AMT,  /*added by bhawana on 26-nov-2015 against DMSSERV-13251,KKC ADDED BY BHAWANA ON 20-MAY-2016*/
      --(EW.EXTE_PREMIUM - EW.EXTE_PREM_DLR_COMM - EW.EXTE_PREM_SRV_TAX) DEBIT_AMT,
      XW.EXTE_CREATED_BY,
      sf_ew_policy_status(EW.EXTE_POLICY_NO) status,
      ALOC.DEALER_NAME,
      ALOC.LOC_DESC,
      nvl(EW.EXTE_PREM_SBC_TAX,0)EXTE_PREM_SBC_TAX,           /*added by bhawana on 26-nov-2015 against DMSSERV-13251*/
      NVL(EW.exte_tot_prem_sbc_tax,0) exte_tot_prem_sbc_tax, /*added by bhawana on 26-nov-2015 against DMSSERV-13251*/
      NVL(EW.exte_tot_conv_sbc_tax,0) exte_tot_conv_sbc_tax,  /*added by bhawana on 26-nov-2015 against DMSSERV-13251*/
      nvl(EW.EXTE_PREM_KKC_TAX,0)EXTE_PREM_KKC_TAX,          /*added by bhawana ON 20-MAY-2016 FOR KKC*/
      NVL(EW.exte_tot_prem_kkc_tax,0) exte_tot_prem_kkc_tax, /*added by bhawana ON 20-MAY-2016 FOR KKC*/
      NVL(EW.exte_tot_conv_kkc_tax,0) exte_tot_conv_kkc_tax,  /*added by bhawana ON 20-MAY-2016 FOR KKC*/
      -----------added by shankar on 07-jul-2017 for GST------------
      EW.EXTE_PREM_CGST_AMT,
      EW.EXTE_PREM_SGST_AMT,
      EW.EXTE_PREM_IGST_AMT,      
      EW.EXTE_PREM_COMM_IGST,
      EW.EXTE_PREM_COMM_SGST,
      EW.EXTE_PREM_COMM_CGST,
     (case when EW.EXTE_WARR_TYPE_OLD ='I' and EW.EXTE_WARR_TYPE='II' then
                'C3T4'                
            when EW.EXTE_WARR_TYPE_OLD='I' and EW.EXTE_WARR_TYPE='III' then 
               'C3T5'
           when EW.EXTE_WARR_TYPE_OLD='II' and EW.EXTE_WARR_TYPE='III' then
             'C4T5'
            when EW.EXTE_WARR_TYPE_OLD='IV' and EW.EXTE_WARR_TYPE='V' then  --Added by mohan ason 08-05-2024 for new 6th year EW package
             'C4T5' 
           when EW.EXTE_WARR_TYPE_OLD='IV' and EW.EXTE_WARR_TYPE='VI' then  --Added by mohan ason 08-05-2024 for new 6th year EW package
             'C4T6'
           when EW.EXTE_WARR_TYPE_OLD='V' and EW.EXTE_WARR_TYPE='VI' then  --Added by mohan ason 08-05-2024 for new 6th year EW package
             'C5T6' 
           else null end  
             ) EXTE_WARR_TYPE_OLD,
             	DECODE(ew.online_sale_flag,'Y','WEB',decode(xw.EXTE_POLICY_SOLD_FROM,'WS','Workshop','SH','Showroom', 'WEB','WEB') ) sold_from,--Added by chandan start 28-11-24
                      (case when NVL(ew.online_sale_flag,'N')='Y' AND NVL(ew.emi_flag,'N') = 'Y' THEN
								      'EMI'
								     WHEN NVL(ew.online_sale_flag,'N')='Y' AND NVL(ew.emi_flag,'N') ='N' THEN
								      'Online But Not EMI'
								     WHEN NVL(ew.online_sale_flag,'N')='N' AND NVL(ew.EXTE_PAY_MODE,'C') = 'O' AND NVL(ew.emi_flag,'N') = 'Y' THEN 
								       'EMI'
								     WHEN NVL(ew.online_sale_flag,'N')='N' AND NVL(ew.EXTE_PAY_MODE,'C') = 'O' AND NVL(ew.emi_flag,'N') = 'N' THEN
								       'Online But Not EMI'
								     WHEN NVL(ew.online_sale_flag,'N')='N' AND NVL(ew.EXTE_PAY_MODE,'C') = 'C' THEN 
								       'Offline DMS' 
								     ELSE
								        'NA'
								     END )  Payment_Type                   --Added by chandan end 28-11-24
       
      -----------------------------------------   
   FROM DMSD_EW_SALE EW,
      MWAR_EXTE XW,
      AM_DEALER_LOC ALOC
  WHERE  EW.EXTE_POLICY_NO=XW.EXTE_POLICY_NO
	AND	EW.EXTE_TRANSACTION_DATE >= :CB_DUMMY.CONT_FROM_DATE
  AND EW.EXTE_TRANSACTION_DATE < to_date(:CB_DUMMY.CONT_TO_DATE) + 1
  and EXTE_TRAN_TYPE='N'
  AND ALOC.PARENT_GROUP = EW.EXTE_PARENT_GROUP
  AND ALOC.DEALER_MAP_CD = EW.EXTE_DEALER_MAP_CD
  AND ALOC.LOC_CD = EW.EXTE_LOC_CD
  and aloc.principal_map_cd=:global.principal /*added by bhawana*/
  AND ALOC.REGION_CD = decode(:CB_DUMMY.CB_REGION,'All',ALOC.REGION_CD,:CB_DUMMY.CB_REGION)
	AND EW.EXTE_PARENT_GROUP = decode(:CB_DUMMY.CB_PARENT,'All',EW.EXTE_PARENT_GROUP,:CB_DUMMY.CB_PARENT)
  AND EW.EXTE_DEALER_MAP_CD = decode(:CB_DUMMY.CB_DEALER_MAP_CD,'All',EW.EXTE_DEALER_MAP_CD,:CB_DUMMY.CB_DEALER_MAP_CD)
  AND EW.EXTE_LOC_CD = decode(:CB_DUMMY.CB_LOC_CD,'All',EW.EXTE_LOC_CD,:CB_DUMMY.CB_LOC_CD)
  AND XW.EXTE_MODL_CODE = decode(:CB_DUMMY.BASE_MODEL_CD,'All',XW.EXTE_MODL_CODE,:CB_DUMMY.BASE_MODEL_CD)
  AND XW.EXTE_VARIANT_CD = decode(:CB_DUMMY.VARIANT_CD,'All',XW.EXTE_VARIANT_CD,:CB_DUMMY.VARIANT_CD)
  AND EW.EXTE_WARR_TYPE = decode(:CB_DUMMY.EW_TYPE,'All',EW.EXTE_WARR_TYPE,:CB_DUMMY.EW_TYPE)
 -- AND nvl(EW.EXTE_CANCEL_FLAG,'N') = 'N' -- As Diss. with Mr. Anoop all EW show in report
  ORDER BY EW.EXTE_POLICY_NO)X
  where X.Payment_Type = DECODE(:CB_DUMMY.CB_PAYMENT_TYPE,'A',X.payment_type,'OD','Offline DMS', 'E', 'EMI', 'OE','Online But Not EMI', :CB_DUMMY.CB_PAYMENT_TYPE)--Added by chandan
  AND X.Sold_From = decode(:CB_DUMMY.CB_SOLD_FROM,'A',X.sold_from,'WEB','WEB', 'WS', 'Workshop', 'SH','Showroom',:CB_DUMMY.CB_SOLD_FROM) 
  UNION
  SELECT Y.EXTE_POLICY_NO,  -----added by chandan START
		Y.EXTE_VIN_NO,
		Y.EXTE_REGISTRATION_NO,
		Y.EXTE_RETLSALE_DT,
		Y.EXTE_CONTRACT_DATE,
		Y.EXTE_MODL_CODE,
		Y.EXTE_VARIANT_CD,
		Y.EXTE_WARR_TYPE, 
		Y.EXTE_CUST_NAME,
		Y.EXTE_CONTRACT_MILEAGE,
		Y.EXTE_VALID_DATE,
		Y.EXTE_VALID_MILEAGE,
		Y.EXTE_PREMIUM_CALCULATED,
		Y.EXTE_PREM_DLR_COMM,
		Y.EXTE_PREM_SRV_TAX,
		Y.exte_tot_prem_srv_tax,
		Y.exte_tot_conv_srv_tax,
		Y.DEBIT_AMT,
		Y.EXTE_CREATED_BY,
		Y.status,
		Y.DEALER_NAME,
		Y.LOC_DESC,
		Y.EXTE_PREM_SBC_TAX,           
		Y.exte_tot_prem_sbc_tax, 
		Y.exte_tot_conv_sbc_tax,  
		Y.EXTE_PREM_KKC_TAX,          
		Y.exte_tot_prem_kkc_tax, 
		Y.exte_tot_conv_kkc_tax,  
		Y.EXTE_PREM_CGST_AMT,
		Y.EXTE_PREM_SGST_AMT,
		Y.EXTE_PREM_IGST_AMT,      
		Y.EXTE_PREM_COMM_IGST,
		Y.EXTE_PREM_COMM_SGST,
		Y.EXTE_PREM_COMM_CGST,
		Y.EXTE_WARR_TYPE_OLD,
			Y.Sold_From,
			Y.Payment_Type  -----added by chandan end
  FROM (SELECT XW.EXTE_POLICY_NO,
      XW.EXTE_VIN_NO,
      XW.EXTE_REG_NUM EXTE_REGISTRATION_NO,
      XW.EXTE_RETLSALE_DT,
      XW.EXTE_CONTRACT_DATE,
      XW.EXTE_MODL_CODE,
      XW.EXTE_VARIANT_CD,
      SF_GET_EW_VALIDITY_DTL(XW.EXTE_POLICY_NO,'Q') EXTE_WARR_TYPE, 
      XW.EXTE_CUST_NAME,
      XW.EXTE_CONTRACT_MILEAGE,
      XW.EXTE_VALID_TO_DATE EXTE_VALID_DATE,
      XW.EXTE_VALID_MILEAGE,
      XW.EXTE_PREMIUM EXTE_PREMIUM_CALCULATED,
      XW.exte_prem_dlr_comm EXTE_PREM_DLR_COMM,
      NULL EXTE_PREM_SRV_TAX,
      NULL exte_tot_prem_srv_tax,
      NULL exte_tot_conv_srv_tax,
      NULL DEBIT_AMT,
      XW.EXTE_CREATED_BY,
      sf_ew_policy_status(XW.EXTE_POLICY_NO) status,
      ALOC.DEALER_NAME,
      ALOC.LOC_DESC,
      NULL EXTE_PREM_SBC_TAX,          
      NULL exte_tot_prem_sbc_tax, 
      NULL exte_tot_conv_sbc_tax,  
      NULL EXTE_PREM_KKC_TAX,          
      NULL exte_tot_prem_kkc_tax, 
      NULL exte_tot_conv_kkc_tax,  
      XW.EXTE_PREM_CGST_AMT,
      XW.EXTE_PREM_SGST_AMT,
      XW.EXTE_PREM_IGST_AMT,      
      XW.EXTE_PREM_COMM_IGST,
      XW.EXTE_PREM_COMM_SGST,
      XW.EXTE_PREM_COMM_CGST,
     null EXTE_WARR_TYPE_OLD,
              decode(xw.EXTE_POLICY_SOLD_FROM,'WS','Workshop','SH','Showroom', 'WEB','WEB')  sold_from,
                      (case when NVL(XW.EXTE_PAY_MODE,'C') = 'C' THEN 
                       'Offline DMS' 
                     ELSE
                        'NA'
                     END )  Payment_Type                  
       
    FROM vt_extsawa XW,
        AM_DEALER_LOC ALOC
  WHERE  XW.EXTE_CONTRACT_DATE >= :CB_DUMMY.CONT_FROM_DATE
  AND XW.EXTE_CONTRACT_DATE < to_date(:CB_DUMMY.CONT_TO_DATE) + 1
  AND ALOC.PARENT_GROUP = XW.EXTE_PARENT_GROUP
  AND ALOC.DEALER_MAP_CD = XW.EXTE_DEALER_MAP_CD
  AND ALOC.LOC_CD = XW.EXTE_LOC_CD
  and aloc.principal_map_cd=:global.principal 
  AND ALOC.REGION_CD = decode(:CB_DUMMY.CB_REGION,'All',ALOC.REGION_CD,:CB_DUMMY.CB_REGION)
  AND XW.EXTE_PARENT_GROUP = decode(:CB_DUMMY.CB_PARENT,'All',XW.EXTE_PARENT_GROUP,:CB_DUMMY.CB_PARENT)
  AND XW.EXTE_DEALER_MAP_CD =decode(:CB_DUMMY.CB_DEALER_MAP_CD,'All',XW.EXTE_DEALER_MAP_CD,:CB_DUMMY.CB_DEALER_MAP_CD)
  AND XW.EXTE_LOC_CD = decode(:CB_DUMMY.CB_LOC_CD,'All',XW.EXTE_LOC_CD,:CB_DUMMY.CB_LOC_CD)
  AND XW.EXTE_MODL_CODE = decode(:CB_DUMMY.BASE_MODEL_CD,'All',XW.EXTE_MODL_CODE,:CB_DUMMY.BASE_MODEL_CD)
  AND XW.EXTE_VARIANT_CD = decode(:CB_DUMMY.VARIANT_CD,'All',XW.EXTE_VARIANT_CD,:CB_DUMMY.VARIANT_CD)
  AND XW.EXTE_WARR_TYPE = decode(:CB_DUMMY.EW_TYPE,'All',XW.EXTE_WARR_TYPE,:CB_DUMMY.EW_TYPE)
 ORDER BY XW.EXTE_POLICY_NO
        )Y
  where Y.Payment_Type = DECODE(:CB_DUMMY.CB_PAYMENT_TYPE,'A',Y.payment_type,'OD','Offline DMS', 'E', 'EMI', 'OE','Online But Not EMI', :CB_DUMMY.CB_PAYMENT_TYPE)--Added by chandan
  AND Y.Sold_From = decode(:CB_DUMMY.CB_SOLD_FROM,'A',Y.sold_from,'WEB','WEB', 'WS', 'Workshop', 'SH','Showroom',:CB_DUMMY.CB_SOLD_FROM) ;--Added by chandan;

CURSOR C2 IS
  SELECT X.EXTE_POLICY_NO,
			X.EXTE_VIN_NO,
			X.EXTE_REGISTRATION_NO,
			X.EXTE_RETLSALE_DT,
			X.EXTE_CONV_DATE,
			X.EXTE_MODL_CODE,
			X.EXTE_VARIANT_CD,
			X.EXTE_WARR_TYPE,
			X.EXTE_CUST_NAME,
			X.EXTE_CONV_MILEAGE,
			X.EXTE_VALID_DATE,
			X.EXTE_VALID_MILEAGE,
			X.EXTE_PREMIUM ,
			X.EXTE_DIFF_PREMIUM,
			X.EXTE_CONV_DLR_COMM,
			X.EXTE_CONV_SRV_TAX,
			X.exte_tot_prem_srv_tax,
			X.exte_tot_conv_srv_tax,
			X.DEBIT_AMT,
			X.EXTE_MODIFIED_BY,
			X.status,
			X.DEALER_NAME,
			X.LOC_DESC,
			X.EXTE_CONV_SBC_TAX,
			X.exte_tot_conv_sbc_tax,
			X.exte_tot_prem_sbc_tax ,
			X.EXTE_CONV_KKC_TAX,
			X.exte_tot_conv_kkc_tax,
			X.exte_tot_prem_kkc_tax ,  
			X.EXTE_CONV_CGST_AMT,
			X.EXTE_CONV_SGST_AMT,
			X.EXTE_CONV_IGST_AMT,
			X.EXTE_CONV_COMM_IGST,
			X.EXTE_CONV_COMM_SGST,
			X.EXTE_CONV_COMM_CGST,  
			X.EXTE_WARR_TYPE_OLD,
			X.Conversion_From,
			X.Payment_Type  -----added by chandan end
  FROM (SELECT/*+ index (EW MWAR_EXTE_MK9)*/
      EW.EXTE_POLICY_NO,
      EW.EXTE_VIN_NO,
      EW.EXTE_REGISTRATION_NO,
      EW.EXTE_RETLSALE_DT,
      EW.EXTE_CONV_DATE,
      XW.EXTE_MODL_CODE,
      XW.EXTE_VARIANT_CD,
      EW.EXTE_WARR_TYPE,
      EW.EXTE_CUST_NAME,
      EW.EXTE_CONV_MILEAGE,
      EW.EXTE_VALID_DATE,
      EW.EXTE_VALID_MILEAGE,
      EW.EXTE_POLICY_PREMIUM EXTE_PREMIUM ,----EW.EXTE_PREMIUM_CALCULATED EXTE_PREMIUM,
      ew.exte_premium_recd EXTE_DIFF_PREMIUM,---EW.EXTE_DIFF_PREMIUM,
      EW.EXTE_COMMISION_AMT EXTE_CONV_DLR_COMM,--EW.EXTE_CONV_DLR_COMM,
      EW.EXTE_SRV_TAX_COMMISSION EXTE_CONV_SRV_TAX,--EW.EXTE_CONV_SRV_TAX,
      NVL(EW.EXTE_SRV_TAX_PREMIUM,0) exte_tot_prem_srv_tax,----NVL(EW.exte_tot_prem_srv_tax,0) exte_tot_prem_srv_tax,
       NVL(EW.EXTE_SRV_TAX_PREMIUM,0) exte_tot_conv_srv_tax,--NVL(EW.exte_tot_conv_srv_tax,0) exte_tot_conv_srv_tax,
      (NVL(EW.exte_premium_recd,0) - NVL(EW.EXTE_COMMISION_AMT,0) - NVL(EW.EXTE_COMMISION_AMT,0)-NVL(EW.EXTE_CONV_SBC_TAX,0)-NVL(EW.EXTE_CONV_KKC_TAX,0)) DEBIT_AMT,
      ---(NVL(EW.EXTE_DIFF_PREMIUM,0) - NVL(EW.EXTE_CONV_DLR_COMM,0) - NVL(EW.EXTE_CONV_SRV_TAX,0)-NVL(EW.EXTE_CONV_SBC_TAX,0)-NVL(EW.EXTE_CONV_KKC_TAX,0)) DEBIT_AMT, /*changes by bhawana on 26-nov-2015 against DMSSERV-13251 ,added by bhawana on 20-MAY-2016*/
      XW.EXTE_MODIFIED_BY,
      sf_ew_policy_status(EW.EXTE_POLICY_NO) status,
      ALOC.DEALER_NAME,
      ALOC.LOC_DESC,
      NVL(EW.EXTE_CONV_SBC_TAX,0)EXTE_CONV_SBC_TAX,/*added by bhawana on 26-nov-2015 against DMSSERV-13251*/
      NVL(EW.exte_tot_conv_sbc_tax,0) exte_tot_conv_sbc_tax, /*added by bhawana on 26-nov-2015 against DMSSERV-13251*/
      NVL(EW.exte_tot_prem_sbc_tax,0) exte_tot_prem_sbc_tax ,  /*added by bhawana on 26-nov-2015 against DMSSERV-13251*/
      NVL(EW.EXTE_CONV_KKC_TAX,0)EXTE_CONV_KKC_TAX,/*added by bhawana ON 20-MAY-2016 FOR KKC*/
      NVL(EW.exte_tot_conv_kkc_tax,0) exte_tot_conv_kkc_tax,/*added by bhawana ON 20-MAY-2016 FOR KKC*/
      NVL(EW.exte_tot_prem_kkc_tax,0) exte_tot_prem_kkc_tax ,  /*added by bhawana ON 20-MAY-2016 FOR KKC*/
      -----------added by shankar on 07-jul-2017 for GST------------
      EW.EXTE_PREM_CGST_AMT EXTE_CONV_CGST_AMT,---EW.EXTE_CONV_IGST_AMT,
      EW.EXTE_PREM_SGST_AMT EXTE_CONV_SGST_AMT,--EW.EXTE_CONV_SGST_AMT,
      EW.EXTE_PREM_IGST_AMT EXTE_CONV_IGST_AMT,---EW.EXTE_CONV_CGST_AMT,    
      EW.EXTE_PREM_COMM_IGST EXTE_CONV_COMM_IGST,--EW.EXTE_CONV_COMM_IGST,
      EW.EXTE_PREM_COMM_SGST EXTE_CONV_COMM_SGST,--EW.EXTE_CONV_COMM_SGST,
      EW.EXTE_PREM_COMM_CGST EXTE_CONV_COMM_CGST,--EW.EXTE_CONV_COMM_CGST      
      (case when EW.EXTE_WARR_TYPE_OLD ='I' and EW.EXTE_WARR_TYPE='II' then
                'C3T4'                
            when EW.EXTE_WARR_TYPE_OLD='I' and EW.EXTE_WARR_TYPE='III' then 
               'C3T5'
           when EW.EXTE_WARR_TYPE_OLD='II' and EW.EXTE_WARR_TYPE='III' then
             'C4T5'
             when EW.EXTE_WARR_TYPE_OLD='IV' and EW.EXTE_WARR_TYPE='V' then  --Added by mohan ason 08-05-2024 for new 6th year EW package
             'C4T5' 
           when EW.EXTE_WARR_TYPE_OLD='IV' and EW.EXTE_WARR_TYPE='VI' then  --Added by mohan ason 08-05-2024 for new 6th year EW package
             'C4T6'
           when EW.EXTE_WARR_TYPE_OLD='V' and EW.EXTE_WARR_TYPE='VI' then  --Added by mohan ason 08-05-2024 for new 6th year EW package
             'C5T6' 
           else null  end  
             ) EXTE_WARR_TYPE_OLD,
             	DECODE(ew.online_sale_flag,'Y','Web',decode(XW.EXTE_CONV_FROM,'WEB','WEB','WS','Workshop','SH','Showroom') ) Conversion_From,--Added by chandan start 28-11-24
                      (case when NVL(ew.online_sale_flag,'N')='Y' AND NVL(ew.emi_flag,'N') = 'Y' THEN
								      'EMI'
								     WHEN NVL(ew.online_sale_flag,'N')='Y' AND NVL(ew.emi_flag,'N') ='N' THEN
								      'Online But Not EMI'
								     WHEN NVL(ew.online_sale_flag,'N')='N' AND NVL(ew.EXTE_PAY_MODE,'C') = 'O' AND NVL(ew.emi_flag,'N') = 'Y' THEN 
								       'EMI'
								     WHEN NVL(ew.online_sale_flag,'N')='N' AND NVL(ew.EXTE_PAY_MODE,'C') = 'O' AND NVL(ew.emi_flag,'N') = 'N' THEN
								       'Online But Not EMI'
								     WHEN NVL(ew.online_sale_flag,'N')='N' AND NVL(ew.EXTE_PAY_MODE,'C') = 'C' THEN 
								       'Offline DMS' 
								     ELSE
								        'NA'
								     END )  Payment_Type                   --Added by chandan end 28-11-24
      -----------------------------------------------
FROM  DMSD_EW_SALE EW,
      MWAR_EXTE XW,
      AM_DEALER_LOC ALOC
WHERE EW.EXTE_POLICY_NO=XW.EXTE_POLICY_NO
	AND	EW.EXTE_TRANSACTION_DATE >= :CB_DUMMY.CONT_FROM_DATE
  AND EW.EXTE_TRANSACTION_DATE < to_date(:CB_DUMMY.CONT_TO_DATE) + 1
  and EXTE_TRAN_TYPE IN ('U','X') 
		---	EW.EXTE_CONV_DATE >= :CB_DUMMY.CONT_FROM_DATE
  --AND EW.EXTE_CONV_DATE < to_date(:CB_DUMMY.CONT_TO_DATE) + 1
  AND ALOC.PARENT_GROUP = EW.EXTE_CONV_PARENT_GROUP
  AND ALOC.DEALER_MAP_CD = EW.EXTE_CONV_DEALER_MAP_CD
  AND ALOC.LOC_CD = EW.EXTE_CONV_LOC_CD
  and aloc.principal_map_cd=:global.principal /*added by bhawana*/
  AND ALOC.REGION_CD = decode(:CB_DUMMY.CB_REGION,'All',ALOC.REGION_CD,:CB_DUMMY.CB_REGION)
	AND EW.EXTE_CONV_PARENT_GROUP = decode(:CB_DUMMY.CB_PARENT,'All',EW.EXTE_CONV_PARENT_GROUP,:CB_DUMMY.CB_PARENT)
  AND EW.EXTE_CONV_DEALER_MAP_CD = decode(:CB_DUMMY.CB_DEALER_MAP_CD,'All',EW.EXTE_CONV_DEALER_MAP_CD,:CB_DUMMY.CB_DEALER_MAP_CD)
  AND EW.EXTE_CONV_LOC_CD = decode(:CB_DUMMY.CB_LOC_CD,'All',EW.EXTE_CONV_LOC_CD,:CB_DUMMY.CB_LOC_CD)
  AND XW.EXTE_MODL_CODE = decode(:CB_DUMMY.BASE_MODEL_CD,'All',XW.EXTE_MODL_CODE,:CB_DUMMY.BASE_MODEL_CD)
  AND XW.EXTE_VARIANT_CD = decode(:CB_DUMMY.VARIANT_CD,'All',XW.EXTE_VARIANT_CD,:CB_DUMMY.VARIANT_CD)
  AND EW.EXTE_WARR_TYPE = decode(:CB_DUMMY.EW_TYPE,'All',EW.EXTE_WARR_TYPE,:CB_DUMMY.EW_TYPE)
 -- AND nvl(EW.EXTE_CANCEL_FLAG,'N') = 'N' -- As Diss. with Mr. Anoop all EW show in report
  ORDER BY EW.EXTE_POLICY_NO)X
  where X.Payment_Type = DECODE(:CB_DUMMY.CB_PAYMENT_TYPE,'A',X.payment_type,'OD','Offline DMS', 'E', 'EMI', 'OE','Online But Not EMI', :CB_DUMMY.CB_PAYMENT_TYPE)--Added by chandan
  AND X.Conversion_From = decode(:CB_DUMMY.CB_SOLD_FROM,'A',X.Conversion_From,'WEB','WEB', 'WS', 'Workshop', 'SH','Showroom',:CB_DUMMY.CB_SOLD_FROM) ;--Added by chandan;

CURSOR C3 IS
  SELECT  X.EXTE_POLICY_NO,
      X.EXTE_VIN_NO,
      X.EXTE_REGISTRATION_NO,
      X.EXTE_RETLSALE_DT,
      X.EXTE_CANCEL_DT,
      X.EXTE_MODL_CODE,
      X.EXTE_VARIANT_CD,
      X.EXTE_WARR_TYPE,
      X.EXTE_CUST_NAME,
      X.EXTE_CONTRACT_MILEAGE,
      X.EXTE_VALID_DATE,
      X.EXTE_VALID_MILEAGE,
      X.EXTE_PREMIUM,
      X.EXTE_PREM_DLR_COMM,
      X.EXTE_PREM_SRV_TAX,
      X.EXTE_CANCELED_BY,
      X.status,
      X.cancel_amt,
      X.exte_tot_prem_srv_tax,
      X.exte_tot_conv_srv_tax, 
      X.credit_amt,
      X.EXTE_REMARKS,
      X.DEALER_NAME,
      X.LOC_DESC,
      X.EXTE_PREM_SBC_TAX,         
      X.exte_tot_prem_sbc_tax, 
      X.exte_tot_conv_sbc_tax, 
      X.EXTE_PREM_KKC_TAX,         
      X.exte_tot_prem_kkc_tax,  
      X.exte_tot_conv_kkc_tax,   
      X.IGST_AMT,     
      X.CGST_AMT,   
      X.SGST_AMT,     
      X.exte_prem_srv_inv_no,          
      X.EXTE_PREM_COMM_IGST,
      X.EXTE_PREM_COMM_SGST,
      X.EXTE_PREM_COMM_CGST,
      X.EXTE_WARR_TYPE_OLD,
      X.Sold_From,
			X.Payment_Type  -----added by chandan end
   FROM (SELECT/*+ index (EW MWAR_EXTE_MK14)*/
      EW.EXTE_POLICY_NO,
      EW.EXTE_VIN_NO,
      EW.EXTE_REGISTRATION_NO,
      EW.EXTE_RETLSALE_DT,
      EW.EXTE_CANCEL_DT,
      XW.EXTE_MODL_CODE,
      XW.EXTE_VARIANT_CD,
      EW.EXTE_WARR_TYPE,
      EW.EXTE_CUST_NAME,
      EW.EXTE_CONTRACT_MILEAGE,
      EW.EXTE_VALID_DATE,
      EW.EXTE_VALID_MILEAGE,
      EW.EXTE_POLICY_PREMIUM EXTE_PREMIUM,--EW.EXTE_PREMIUM,
      EW.EXTE_COMMISION_AMT EXTE_PREM_DLR_COMM,---EW.EXTE_PREM_DLR_COMM,
      EW.EXTE_SRV_TAX_COMMISSION EXTE_PREM_SRV_TAX,--EW.EXTE_PREM_SRV_TAX,
      XW.EXTE_CANCELED_BY,
      sf_ew_policy_status(EW.EXTE_POLICY_NO) status,
      ---greatest((NVL(EW.EXTE_PREMIUM,0) * 0.1),200) cancel_amt,
      greatest((NVL(EW.EXTE_POLICY_PREMIUM,0) * 0.1),200) cancel_amt,
      NVL(EW.EXTE_SRV_TAX_PREMIUM,0) exte_tot_prem_srv_tax,---NVL(EW.exte_tot_prem_srv_tax,0) exte_tot_prem_srv_tax,
      NVL(EW.EXTE_SRV_TAX_PREMIUM,0) exte_tot_conv_srv_tax, --NVL(EW.exte_tot_conv_srv_tax,0) exte_tot_conv_srv_tax, 
      (NVL(EW.EXTE_POLICY_PREMIUM,0) - NVL(EW.EXTE_COMMISION_AMT,0) - NVL(EW.EXTE_SRV_TAX_COMMISSION,0) - NVL(EW.EXTE_PREM_SBC_TAX,0)-greatest((NVL(EW.EXTE_POLICY_PREMIUM,0) * 0.1),200)) credit_amt,
      ---(NVL(EW.EXTE_PREMIUM,0) - NVL(EW.EXTE_PREM_DLR_COMM,0) - NVL(EW.EXTE_PREM_SRV_TAX,0) - NVL(EW.EXTE_PREM_SBC_TAX,0)-greatest((NVL(EW.EXTE_PREMIUM,0) * 0.1),200)) credit_amt,  /*changes by bhawana on 26-nov-2015 against DMSSERV-13251*/
      XW.EXTE_REMARKS,
      ALOC.DEALER_NAME,
      ALOC.LOC_DESC,
      nvl(EW.EXTE_PREM_SBC_TAX,0)EXTE_PREM_SBC_TAX,          /*added by bhawana on 26-nov-2015 against DMSSERV-13251*/
      NVL(EW.exte_tot_prem_sbc_tax,0) exte_tot_prem_sbc_tax, /*added by bhawana on 26-nov-2015 against DMSSERV-13251*/
      NVL(EW.exte_tot_conv_sbc_tax,0) exte_tot_conv_sbc_tax,  /*added by bhawana on 26-nov-2015 against DMSSERV-13251*/
      nvl(EW.EXTE_PREM_KKC_TAX,0)EXTE_PREM_KKC_TAX,          /*added by bhawana ON 20-MAY-2016 FOR KKC*/
      NVL(EW.exte_tot_prem_kkc_tax,0) exte_tot_prem_kkc_tax,  /*added by bhawana ON 20-MAY-2016 FOR KKC*/
      NVL(EW.exte_tot_conv_kkc_tax,0) exte_tot_conv_kkc_tax,   /*added by bhawana ON 20-MAY-2016 FOR KKC*/
      ----------------------GST---------------------------      
      (greatest((EW.EXTE_POLICY_PREMIUM * 0.1),200)*EW.EXTE_PREM_IGST_RATE/100) IGST_AMT,     
      (greatest((EW.EXTE_POLICY_PREMIUM * 0.1),200)*EW.EXTE_PREM_CGST_RATE/100)  CGST_AMT,   
      (greatest((EW.EXTE_POLICY_PREMIUM * 0.1),200)*EW.EXTE_PREM_SGST_RATE/100)  SGST_AMT,     
      ew.exte_prem_srv_inv_no,          
      NVL(EW.EXTE_PREM_COMM_IGST,0) EXTE_PREM_COMM_IGST,
      NVL(EW.EXTE_PREM_COMM_SGST,0) EXTE_PREM_COMM_SGST,
      NVL(EW.EXTE_PREM_COMM_CGST,0) EXTE_PREM_COMM_CGST,
      (case when EW.EXTE_WARR_TYPE_OLD ='I' and EW.EXTE_WARR_TYPE='II' then
                'C3T4'                
            when EW.EXTE_WARR_TYPE_OLD='I' and EW.EXTE_WARR_TYPE='III' then 
               'C3T5'
           when EW.EXTE_WARR_TYPE_OLD='II' and EW.EXTE_WARR_TYPE='III' then
             'C4T5' 
             when EW.EXTE_WARR_TYPE_OLD='IV' and EW.EXTE_WARR_TYPE='V' then  --Added by mohan ason 08-05-2024 for new 6th year EW package
             'C4T5' 
           when EW.EXTE_WARR_TYPE_OLD='IV' and EW.EXTE_WARR_TYPE='VI' then  --Added by mohan ason 08-05-2024 for new 6th year EW package
             'C4T6'
           when EW.EXTE_WARR_TYPE_OLD='V' and EW.EXTE_WARR_TYPE='VI' then  --Added by mohan ason 08-05-2024 for new 6th year EW package
             'C5T6'
           else null end  
             ) EXTE_WARR_TYPE_OLD ,
             	DECODE(ew.online_sale_flag,'Y','WEB',decode(xw.EXTE_POLICY_SOLD_FROM,'WS','Workshop','SH','Showroom', 'WEB','WEB') ) Sold_From,--Added by chandan start 28-11-24
                      (case when NVL(ew.online_sale_flag,'N')='Y' AND NVL(ew.emi_flag,'N') = 'Y' THEN
								      'EMI'
								     WHEN NVL(ew.online_sale_flag,'N')='Y' AND NVL(ew.emi_flag,'N') ='N' THEN
								      'Online But Not EMI'
								     WHEN NVL(ew.online_sale_flag,'N')='N' AND NVL(ew.EXTE_PAY_MODE,'C') = 'O' AND NVL(ew.emi_flag,'N') = 'Y' THEN 
								       'EMI'
								     WHEN NVL(ew.online_sale_flag,'N')='N' AND NVL(ew.EXTE_PAY_MODE,'C') = 'O' AND NVL(ew.emi_flag,'N') = 'N' THEN
								       'Online But Not EMI'
								     WHEN NVL(ew.online_sale_flag,'N')='N' AND NVL(ew.EXTE_PAY_MODE,'C') = 'C' THEN 
								       'Offline DMS' 
								     ELSE
								        'NA'
								     END )  Payment_Type                   --Added by chandan end 28-11-24    
FROM  dmsd_ew_sale ew,
      MWAR_EXTE XW,
      AM_DEALER_LOC ALOC
WHERE EW.EXTE_POLICY_NO=XW.EXTE_POLICY_NO
  AND  EW.EXTE_TRANSACTION_DATE >= :CB_DUMMY.CONT_FROM_DATE
  AND EW.EXTE_TRANSACTION_DATE < to_date(:CB_DUMMY.CONT_TO_DATE) + 1
  AND EXTE_TRAN_TYPE ='C'
			--EW.EXTE_CANCEL_DT >= :CB_DUMMY.CONT_FROM_DATE
 -- AND EW.EXTE_CANCEL_DT < to_date(:CB_DUMMY.CONT_TO_DATE) + 1
  AND ALOC.PARENT_GROUP(+) = EW.EXTE_PARENT_GROUP
  AND ALOC.DEALER_MAP_CD(+) = EW.EXTE_DEALER_MAP_CD
  AND ALOC.LOC_CD(+) = EW.EXTE_LOC_CD
  and aloc.principal_map_cd=:global.principal /*added by bhwana*/
  AND nvl(ALOC.REGION_CD,'A') = decode(:CB_DUMMY.CB_REGION,'All',nvl(ALOC.REGION_CD,'A'),:CB_DUMMY.CB_REGION)
	AND nvl(EW.EXTE_PARENT_GROUP,'A') = decode(:CB_DUMMY.CB_PARENT,'All',nvl(EW.EXTE_PARENT_GROUP,'A'),:CB_DUMMY.CB_PARENT)
  AND nvl(EW.EXTE_DEALER_MAP_CD,1) = decode(:CB_DUMMY.CB_DEALER_MAP_CD,'All',nvl(EW.EXTE_DEALER_MAP_CD,1),:CB_DUMMY.CB_DEALER_MAP_CD)
  AND nvl(EW.EXTE_LOC_CD,'A') = decode(:CB_DUMMY.CB_LOC_CD,'All',nvl(EW.EXTE_LOC_CD,'A'),:CB_DUMMY.CB_LOC_CD)
  AND XW.EXTE_MODL_CODE = decode(:CB_DUMMY.BASE_MODEL_CD,'All',XW.EXTE_MODL_CODE,:CB_DUMMY.BASE_MODEL_CD)
  AND nvl(XW.EXTE_VARIANT_CD,'A') = decode(:CB_DUMMY.VARIANT_CD,'All',nvl(XW.EXTE_VARIANT_CD,'A'),:CB_DUMMY.VARIANT_CD)
  AND EW.EXTE_WARR_TYPE = decode(:CB_DUMMY.EW_TYPE,'All',EW.EXTE_WARR_TYPE,:CB_DUMMY.EW_TYPE)
  ---AND nvl(EW.EXTE_CANCEL_FLAG,'N') = 'Y'
  ORDER BY EW.EXTE_POLICY_NO)X
  where X.Payment_Type = DECODE(:CB_DUMMY.CB_PAYMENT_TYPE,'A',X.payment_type,'OD','Offline DMS', 'E', 'EMI', 'OE','Online But Not EMI', :CB_DUMMY.CB_PAYMENT_TYPE)--Added by chandan
  AND X.Sold_From = decode(:CB_DUMMY.CB_SOLD_FROM,'A',X.sold_from,'WEB','WEB', 'WS', 'Workshop', 'SH','Showroom',:CB_DUMMY.CB_SOLD_FROM) 
  UNION 
  SELECT  Y.EXTE_POLICY_NO,
      Y.EXTE_VIN_NO,
      Y.EXTE_REGISTRATION_NO,
      Y.EXTE_RETLSALE_DT,
      Y.EXTE_CANCEL_DT,
      Y.EXTE_MODL_CODE,
      Y.EXTE_VARIANT_CD,
      Y.EXTE_WARR_TYPE,
      Y.EXTE_CUST_NAME,
      Y.EXTE_CONTRACT_MILEAGE,
      Y.EXTE_VALID_DATE,
      Y.EXTE_VALID_MILEAGE,
      Y.EXTE_PREMIUM,
      Y.EXTE_PREM_DLR_COMM,
      Y.EXTE_PREM_SRV_TAX,
      Y.EXTE_CANCELED_BY,
      Y.status,
      Y.cancel_amt,
      Y.exte_tot_prem_srv_tax,
      Y.exte_tot_conv_srv_tax, 
      Y.credit_amt,
      Y.EXTE_REMARKS,
      Y.DEALER_NAME,
      Y.LOC_DESC,
      Y.EXTE_PREM_SBC_TAX,         
      Y.exte_tot_prem_sbc_tax, 
      Y.exte_tot_conv_sbc_tax, 
      Y.EXTE_PREM_KKC_TAX,         
      Y.exte_tot_prem_kkc_tax,  
      Y.exte_tot_conv_kkc_tax,   
      Y.IGST_AMT,     
      Y.CGST_AMT,   
      Y.SGST_AMT,     
      Y.exte_prem_srv_inv_no,          
      Y.EXTE_PREM_COMM_IGST,
      Y.EXTE_PREM_COMM_SGST,
      Y.EXTE_PREM_COMM_CGST,
      Y.EXTE_WARR_TYPE_OLD,
      Y.Sold_From,
			Y.Payment_Type 
   FROM (
					   SELECT XW.EXTE_POLICY_NO,
					      XW.EXTE_VIN_NO,
					      XW.EXTE_REG_NUM EXTE_REGISTRATION_NO,
					      XW.EXTE_RETLSALE_DT,
					      XW.EXTE_CANCEL_DT,
					      XW.EXTE_MODL_CODE,
					      XW.EXTE_VARIANT_CD,
					      XW.EXTE_WARR_TYPE,
					      XW.EXTE_CUST_NAME,
					      XW.EXTE_CONTRACT_MILEAGE,
					      XW.EXTE_VALID_TO_DATE EXTE_VALID_DATE,
					      XW.EXTE_VALID_MILEAGE,
					      XW.EXTE_PREMIUM EXTE_PREMIUM,
					      XW.exte_prem_dlr_comm EXTE_PREM_DLR_COMM,
					      NULL EXTE_PREM_SRV_TAX,
					      XW.EXTE_CANCELED_BY,
					      sf_ew_policy_status(XW.EXTE_POLICY_NO) status,
					      xw.exte_cancel_amt cancel_amt,
					      NULL exte_tot_prem_srv_tax,
					      NULL exte_tot_conv_srv_tax,  
					      NULL credit_amt,
					      XW.EXTE_REMARKS,
					      ALOC.DEALER_NAME,
					      ALOC.LOC_DESC,
					      NULL EXTE_PREM_SBC_TAX,          
					      NULL exte_tot_prem_sbc_tax,
					      NULL exte_tot_conv_sbc_tax, 
					      NULL EXTE_PREM_KKC_TAX,         
					      NULL exte_tot_prem_kkc_tax, 
					      NULL exte_tot_conv_kkc_tax,   
					      (greatest((EXTE_PREMIUM * 0.1),200)*XW.EXTE_PREM_IGST_RATE/100) IGST_AMT,     
					      (greatest((EXTE_PREMIUM * 0.1),200)*XW.EXTE_PREM_CGST_RATE/100)  CGST_AMT,   
					      (greatest((EXTE_PREMIUM * 0.1),200)*XW.EXTE_PREM_SGST_RATE/100)  SGST_AMT,     
					      XW.EXTE_INV_NO exte_prem_srv_inv_no,          
					      NVL(XW.EXTE_PREM_COMM_IGST,0) EXTE_PREM_COMM_IGST,
					      NVL(XW.EXTE_PREM_COMM_SGST,0) EXTE_PREM_COMM_SGST,
					      NVL(XW.EXTE_PREM_COMM_CGST,0) EXTE_PREM_COMM_CGST,
					      NULL EXTE_WARR_TYPE_OLD ,
					              decode(xw.EXTE_POLICY_SOLD_FROM,'WS','Workshop','SH','Showroom', 'WEB','WEB')  Sold_From,
					                      (case when NVL(XW.EXTE_PAY_MODE,'C') = 'C' THEN 
					                       'Offline DMS' 
					                     ELSE
					                        'NA'
					                     END )  Payment_Type                   
					FROM  vt_extsawa XW,
					      AM_DEALER_LOC ALOC
					WHERE XW.EXTE_CONTRACT_DATE >= :CB_DUMMY.CONT_FROM_DATE
					  AND XW.EXTE_CONTRACT_DATE < to_date(:CB_DUMMY.CONT_TO_DATE) + 1
					  AND NVL(XW.EXTE_CANCEL_FLAG,'N') ='Y'
					  AND ALOC.PARENT_GROUP = xw.EXTE_PARENT_GROUP
					  AND ALOC.DEALER_MAP_CD = xw.EXTE_DEALER_MAP_CD
					  AND ALOC.LOC_CD = xw.EXTE_LOC_CD
					  and aloc.principal_map_cd=:global.principal
					  AND nvl(ALOC.REGION_CD,'A') = decode(:CB_DUMMY.CB_REGION,'All',nvl(ALOC.REGION_CD,'A'),:CB_DUMMY.CB_REGION)
					  AND nvl(XW.EXTE_PARENT_GROUP,'A') = decode(:CB_DUMMY.CB_PARENT,'All',nvl(XW.EXTE_PARENT_GROUP,'A'),:CB_DUMMY.CB_PARENT)
					  AND nvl(XW.EXTE_DEALER_MAP_CD,1) = decode(:CB_DUMMY.CB_DEALER_MAP_CD,'All',nvl(XW.EXTE_DEALER_MAP_CD,1),:CB_DUMMY.CB_DEALER_MAP_CD)
					  AND nvl(XW.EXTE_LOC_CD,'A') = decode(:CB_DUMMY.CB_LOC_CD,'All',nvl(XW.EXTE_LOC_CD,'A'),:CB_DUMMY.CB_LOC_CD)
					  AND XW.EXTE_MODL_CODE = decode(:CB_DUMMY.BASE_MODEL_CD,'All',XW.EXTE_MODL_CODE,:CB_DUMMY.BASE_MODEL_CD)
					  AND nvl(XW.EXTE_VARIANT_CD,'A') = decode(:CB_DUMMY.VARIANT_CD,'All',nvl(XW.EXTE_VARIANT_CD,'A'),:CB_DUMMY.VARIANT_CD)
					  AND XW.EXTE_WARR_TYPE = decode(:CB_DUMMY.EW_TYPE,'All',XW.EXTE_WARR_TYPE,:CB_DUMMY.EW_TYPE)
					  ORDER BY XW.EXTE_POLICY_NO
											  )Y
  where Y.Payment_Type = DECODE(:CB_DUMMY.CB_PAYMENT_TYPE,'A',Y.payment_type,'OD','Offline DMS', 'E', 'EMI', 'OE','Online But Not EMI', :CB_DUMMY.CB_PAYMENT_TYPE)--Added by chandan
  AND Y.Sold_From = decode(:CB_DUMMY.CB_SOLD_FROM,'A',Y.sold_from,'WEB','WEB', 'WS', 'Workshop', 'SH','Showroom',:CB_DUMMY.CB_SOLD_FROM);

lv_cnt_n number := 0;
lv_cnt_u number := 0;
lv_cnt_c number := 0;

BEGIN
	IF :CB_DUMMY.CB_LOC_DESC IS NULL THEN
		general.check_null(:cb_dummy.CB_LOC_DESC,'Location');
		go_item('cb_dummy.CB_LOC_DESC');
	END IF;
	IF :CB_DUMMY.P_REP_TYPE IS NULL THEN
	  general.check_null(:cb_dummy.P_REP_TYPE,'Extended Warranty Status');
	  go_item('cb_dummy.P_REP_TYPE');
	END IF;
	IF :CB_DUMMY.CONT_FROM_DATE IS NULL THEN
	  general.check_null(:cb_dummy.CONT_FROM_DATE,'Contract From Date');
	  go_item('cb_dummy.CONT_FROM_DATE');
	END IF;
	IF :CB_DUMMY.CONT_TO_DATE IS NULL THEN
	  general.check_null(:cb_dummy.CONT_TO_DATE,'Contract To Date');
	  go_item('cb_dummy.CONT_TO_DATE');
	END IF;
	IF :CB_DUMMY.BASE_MODEL_CD IS NULL THEN
	  general.check_null(:cb_dummy.BASE_MODEL_CD,'Model');
	  go_item('cb_dummy.BASE_MODEL_CD');
	END IF;
	IF :CB_DUMMY.VARIANT_CD IS NULL THEN
	  general.check_null(:cb_dummy.VARIANT_CD,'Variant');
	  go_item('cb_dummy.VARIANT_CD');
	END IF;
	IF :CB_DUMMY.EW_TYPE IS NULL THEN
	  general.check_null(:cb_dummy.EW_TYPE,'Extended Warranty Type');
	  go_item('cb_dummy.EW_TYPE');
	END IF;

IF :CB_DUMMY.P_REP_TYPE = 'N' THEN
		go_block('B_EW');
		clear_block;
		first_record;
			FOR i IN c1 LOOP
				:B_EW.EXTE_POLICY_NO 		:= i.EXTE_POLICY_NO;
				:B_EW.EXTE_VIN_NO := i.EXTE_VIN_NO;
		    :B_EW.EXTE_RETLSALE_DT := i.EXTE_RETLSALE_DT;
		    :B_EW.EXTE_CONTRACT_DATE := i.EXTE_CONTRACT_DATE;
		    :B_EW.EXTE_VARIANT_CD := i.EXTE_VARIANT_CD;
		    :B_EW.EXTE_WARR_TYPE := i.EXTE_WARR_TYPE;
		    :B_EW.EXTE_CUST_NAME := i.EXTE_CUST_NAME;
		    :B_EW.EXTE_PREMIUM := i.EXTE_PREMIUM_CALCULATED;
		    :B_EW.EXTE_PREM_DLR_COMM := i.EXTE_PREM_DLR_COMM;
		    :B_EW.EXTE_PREM_SRV_TAX := i.EXTE_PREM_SRV_TAX;
		    :B_EW.EXTE_DEBIT_AMT := i.DEBIT_AMT;
		    :B_EW.EXTE_CREATED_BY := i.EXTE_CREATED_BY;
		    :B_EW.EXTE_CREATED_BY2 := i.EXTE_CREATED_BY;
		    :B_EW.EXTE_STATUS := i.status;
		    :B_EW.EXTE_DEALER_NAME := i.dealer_name;
		    :B_EW.EXTE_LOCATION_DESC := i.loc_desc;
				:B_EW.EXTE_CANCEL_AMT := 0;
				:B_EW.Serv_Tax_Prem_Amt := i.exte_tot_prem_srv_tax;
				:B_EW.EXTE_PREM_SBC_TAX := i.EXTE_PREM_SBC_TAX;      /*added by bhawana on 26-nov-2015 against DMSSERV-13251*/
        :B_EW.SBC_Tax_Prem_Amt := i.exte_tot_prem_sbc_tax;  /*added by bhawana on 26-nov-2015 against DMSSERV-13251*/
        :B_EW.EXTE_PREM_KKC_TAX := i.EXTE_PREM_KKC_TAX;     /*added by bhawana ON 20-MAY-2016 FOR KKC*/
        :B_EW.KKC_Tax_Prem_Amt := i.exte_tot_prem_kkc_tax;  /*added by bhawana ON 20-MAY-2016 FOR KKC*/
        ---------added by shankar on 07-jul-2017 for GST--------------------
        :B_EW.EXTE_PREM_IGST_AMT:=i.EXTE_PREM_IGST_AMT;
        :B_EW.EXTE_PREM_SGST_AMT:=i.EXTE_PREM_SGST_AMT;
        :B_EW.EXTE_PREM_CGST_AMT:=i.EXTE_PREM_CGST_AMT;        
        :B_EW.EXTE_PREM_COMM_IGST:=i.EXTE_PREM_COMM_IGST;
        :B_EW.EXTE_PREM_COMM_SGST:=i.EXTE_PREM_COMM_SGST;
        :B_EW.EXTE_PREM_COMM_CGST:=i.EXTE_PREM_COMM_CGST;
        :B_EW.conv_status:=i.EXTE_WARR_TYPE_OLD;
        -----------------------------------------------------       
		    BEGIN
				    SELECT variant_desc
						INTO :B_EW.VARIANT_DESC
		  			FROM gm_var
		 				WHERE variant_cd = i.EXTE_VARIANT_CD
		 				and principal_map_cd=:global.principal;/*added by bhawana*/
		    EXCEPTION
		    	WHEN OTHERS THEN
		    	null;
		    END;

		  EXIT WHEN c1%notfound;--:system.last_record = 'TRUE';
		  next_record;

			END LOOP;
message(:system.TRIGGER_RECORD);
:CB_DUMMY.TOT_REC := :system.TRIGGER_RECORD - 1;

ELSIF :CB_DUMMY.P_REP_TYPE = 'U' THEN
				go_block('B_EW');
				clear_block;
				first_record;
					FOR i IN c2 LOOP
						:B_EW.EXTE_POLICY_NO := i.EXTE_POLICY_NO;
						:B_EW.EXTE_VIN_NO := i.EXTE_VIN_NO;
				    :B_EW.EXTE_RETLSALE_DT := i.EXTE_RETLSALE_DT;
				    :B_EW.EXTE_CONTRACT_DATE := i.EXTE_CONV_DATE;
				    :B_EW.EXTE_VARIANT_CD := i.EXTE_VARIANT_CD;
				    :B_EW.EXTE_WARR_TYPE := i.EXTE_WARR_TYPE;
				    :B_EW.EXTE_CUST_NAME := i.EXTE_CUST_NAME;
				    :B_EW.EXTE_PREMIUM := i.EXTE_DIFF_PREMIUM;
				    :B_EW.EXTE_PREM_DLR_COMM := i.EXTE_CONV_DLR_COMM;
				    :B_EW.EXTE_PREM_SRV_TAX := i.EXTE_CONV_SRV_TAX;
				    :B_EW.EXTE_DEBIT_AMT := i.DEBIT_AMT;
				    :B_EW.EXTE_CREATED_BY := i.EXTE_MODIFIED_BY;
				    :B_EW.EXTE_CREATED_BY2 := i.EXTE_MODIFIED_BY;
				    :B_EW.EXTE_STATUS := i.status;    
				    :B_EW.SERV_TAX_DIFF_PREM_AMT := i.exte_tot_conv_srv_tax;  
				    :B_EW.EXTE_DEALER_NAME := i.dealer_name;
		    		:B_EW.EXTE_LOCATION_DESC := i.loc_desc;
           	:B_EW.EXTE_CANCEL_AMT := 0;
           	:B_EW.EXTE_PREM_SBC_TAX := i.EXTE_CONV_SBC_TAX;           /*added by bhawana against DMSSERV-13251 on 26-nov-2015*/
           	:B_EW.SBC_TAX_DIFF_PREM_AMT := i.exte_tot_conv_sbc_tax;  /*added by bhawana against DMSSERV-13251 on 26-nov-2015*/
           	:B_EW.EXTE_PREM_KKC_TAX := i.EXTE_CONV_KKC_TAX;          /*added by bhawana ON 20-MAY-2016 FOR KKC*/
           	:B_EW.KKC_TAX_DIFF_PREM_AMT := i.exte_tot_conv_kkc_tax;  /*added by bhawana ON 20-MAY-2016 FOR KKC*/
           	-----------added by shankar 30-jul-2017 FOR GST------- 
           	 :B_EW.EXTE_PREM_IGST_AMT:=i.EXTE_CONV_IGST_AMT;
           	 :B_EW.EXTE_PREM_SGST_AMT:=i.EXTE_CONV_SGST_AMT;
           	 :B_EW.EXTE_PREM_CGST_AMT:=i.EXTE_CONV_CGST_AMT;           	 
           	 :B_EW.EXTE_PREM_COMM_IGST:=i.EXTE_CONV_COMM_IGST;
           	 :B_EW.EXTE_PREM_COMM_SGST:=i.EXTE_CONV_COMM_SGST;
           	 :B_EW.EXTE_PREM_COMM_CGST:=i.EXTE_CONV_COMM_CGST;
            	:B_EW.CONV_STATUS:=i.EXTE_WARR_TYPE_OLD;
           	 ----------------------------------------------------------- 	
				BEGIN
				    SELECT variant_desc
						INTO :B_EW.VARIANT_DESC
		  			FROM gm_var
		 				WHERE variant_cd = i.EXTE_VARIANT_CD
		 				and principal_map_cd=:global.principal;/*added by bhawana*/
		    EXCEPTION
		    	WHEN OTHERS THEN
		    	null;
		    END;
				  EXIT WHEN c2%notfound;--:system.last_record = 'TRUE';
				  next_record; 

					END LOOP;

:CB_DUMMY.TOT_REC := :system.TRIGGER_RECORD - 1;

ELSIF :CB_DUMMY.P_REP_TYPE = 'C' THEN
			go_block('B_EW');
			clear_block;
			first_record;
				FOR i IN c3 LOOP
					:B_EW.EXTE_POLICY_NO := i.EXTE_POLICY_NO;
					:B_EW.EXTE_VIN_NO := i.EXTE_VIN_NO;
			    :B_EW.EXTE_RETLSALE_DT := i.EXTE_RETLSALE_DT;
			    :B_EW.EXTE_CONTRACT_DATE := i.EXTE_CANCEL_DT;
			    :B_EW.EXTE_VARIANT_CD := i.EXTE_VARIANT_CD;
			    :B_EW.EXTE_WARR_TYPE := i.EXTE_WARR_TYPE;
			    :B_EW.EXTE_CUST_NAME := i.EXTE_CUST_NAME;
			    :B_EW.EXTE_PREMIUM := i.EXTE_PREMIUM;
			    :B_EW.EXTE_PREM_DLR_COMM := i.EXTE_PREM_DLR_COMM;
			    :B_EW.EXTE_PREM_SRV_TAX := i.EXTE_PREM_SRV_TAX;
			    :B_EW.EXTE_CREATED_BY := i.EXTE_CANCELED_BY;
			    :B_EW.EXTE_STATUS := i.status;
			    :B_EW.EXTE_REMARKS := i.EXTE_REMARKS;
			    :B_EW.EXTE_DEBIT_AMT := 0;
			    :B_EW.EXTE_CANCEL_AMT := i.cancel_amt;
			    :B_EW.EXTE_CREDIT_AMT := i.credit_amt;
			    :B_EW.Serv_Tax_Prem_Amt := i.exte_tot_prem_srv_tax;
			    :B_EW.EXTE_DEALER_NAME := i.dealer_name;
		    	:B_EW.EXTE_LOCATION_DESC := i.loc_desc;
          :B_EW.SBC_Tax_Prem_Amt := i.exte_tot_prem_sbc_tax;       /*added by bhawana against DMSSERV-13251 on 26-nov-2015*/
          :B_EW.EXTE_PREM_SBC_TAX := i.EXTE_PREM_SBC_TAX;       /*added by bhawana against DMSSERV-13251 on 26-nov-2015*/
          :B_EW.KKC_Tax_Prem_Amt := i.exte_tot_prem_kkc_tax;     /*added by bhawana ON 20-MAY-2016 FOR KKC*/
          :B_EW.EXTE_PREM_KKC_TAX := i.EXTE_PREM_KKC_TAX;     /*added by bhawana ON 20-MAY-2016 FOR KKC*/
          -----------GST-----------------          
          ---:B_EW.EXTE_PREM_SRV_INV_NO:=i.EXTE_PREM_SRV_INV_NO;         	 
	        :B_EW.EXTE_PREM_IGST_AMT:=i.IGST_AMT;
	        :B_EW.EXTE_PREM_SGST_AMT:=i.SGST_AMT;
	        :B_EW.EXTE_PREM_CGST_AMT:=i.CGST_AMT;        
	        :B_EW.EXTE_PREM_COMM_IGST:=i.EXTE_PREM_COMM_IGST;
	        :B_EW.EXTE_PREM_COMM_SGST:=i.EXTE_PREM_COMM_SGST;
	        :B_EW.EXTE_PREM_COMM_CGST:=i.EXTE_PREM_COMM_CGST;
	        :B_EW.CONV_STATUS:=i.EXTE_WARR_TYPE_OLD;  
        

			  BEGIN
				    SELECT variant_desc
						INTO :B_EW.VARIANT_DESC
		  			FROM gm_var
		 				WHERE variant_cd = i.EXTE_VARIANT_CD
		 				and principal_map_cd=:global.principal;/*added by bhawana*/
		    EXCEPTION
		    	WHEN OTHERS THEN
		    	null;
		    END;

			  EXIT WHEN c3%notfound;--:system.last_record = 'TRUE';
			  next_record; 

				END LOOP;

:CB_DUMMY.TOT_REC := :system.TRIGGER_RECORD - 1;

			END IF;
				first_record;
END;
```

#### SP-002 - PROC_REP_SEARCH_PMC2

**Invoked From:**

- vr_exte_warr_msil_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

Search Criteria (N/A / CN_MAIN)

---

**Purpose**

Validates all mandatory search-criteria fields, then populates the on-screen `B_EW` data block with Extended Warranty policy records from the PMC2 sales table (`DMSD_EW_SALE_SM`) covering new sales, conversions (upgrades), and cancellations according to the selected report type. Unlike PROC_REP_SEARCH_PMC1 this procedure operates solely on `DMSD_EW_SALE_SM` (no legacy `VT_EXTSAWA` union), supports an extended set of warranty type conversion codes, and applies a vendor-code filter.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.CHECK_NULL ([SP-006](#SP-006--GENERAL.CHECK_NULL)) - matched by member name (package unresolved)
- SF_EW_POLICY_STATUS ([SP-021](#SP-021--SF_EW_POLICY_STATUS)) - standalone source file

---

**Step-by-Step Business Logic**

- Step 1 - Check that each of the seven mandatory fields (Location, Report Type, Contract From Date, Contract To Date, Model, Variant, EW Type) is non-NULL; for any NULL field, call `GENERAL.CHECK_NULL` to display an error alert and navigate to that field, aborting the procedure.
- Step 2 - Determine the report type from `:CB_DUMMY.P_REP_TYPE` (`'N'` = New Sales, `'U'` = Conversions/Upgrades, `'C'` = Cancellations).
- Step 3 - For **New Sales** (`P_REP_TYPE = 'N'`): open Cursor C1, which queries `DMSD_EW_SALE_SM` joined to `MWAR_EXTE` and `AM_DEALER_LOC` for new-sale transactions (`EXTE_TRAN_TYPE = 'N'`) within the selected date range, applying all user-selected filters (region, parent group, dealer, location, model, variant, EW type, sold-from channel, vendor code). Warranty type code `'X'` is decoded to `'VIII'` for display. The policy status is derived via `SF_EW_POLICY_STATUS`. An extended warranty type upgrade transition code is computed using a CASE expression covering additional type combinations up to type `'X'`.
- Step 4 - Navigate to block `B_EW`, clear it, and position at the first record.
- Step 5 - Loop through all C1 rows, mapping each cursor column to the corresponding `B_EW` block item (policy number, VIN, dates, variant, warranty type, customer name, premium, commissions, tax amounts, GST components, dealer details, status, vendor code, conversion status code). For each row, look up the variant description from `GM_VAR` (silently ignoring failures).
- Step 6 - After the loop, display the trigger record count and set `:CB_DUMMY.TOT_REC` to the current trigger-record count minus one.
- Step 7 - For **Conversions** (`P_REP_TYPE = 'U'`): repeat Steps 4-6 using Cursor C2, which queries `DMSD_EW_SALE_SM` for upgrade/transfer/zero-premium transactions (`EXTE_TRAN_TYPE IN ('U','X','Z')`), joining on the conversion dealer/location fields. The `B_EW` block is populated with conversion-specific fields (conversion date, differential premium, conversion tax components, vendor code).
- Step 8 - For **Cancellations** (`P_REP_TYPE = 'C'`): repeat Steps 4-6 using Cursor C3, which queries `DMSD_EW_SALE_SM` for cancellation transactions (`EXTE_TRAN_TYPE = 'C'`). Cancellation amount is the greater of 10% of the policy premium or 200. The credit amount is premium minus commission, service-tax commission, SBC tax, and the cancellation fee.
- Step 9 - After all branches, navigate to the first record of `B_EW`.

---
**Decision Points**

DP-001

Condition:
Any of the seven mandatory criteria fields (Location, Report Type, Contract From Date, Contract To Date, Model, Variant, EW Type) is NULL.

TRUE:
Call `GENERAL.CHECK_NULL` for that field, display an error alert, navigate focus to the offending field, and abort execution.

FALSE:
All mandatory fields are present; proceed to the report-type branch.

DP-002

Condition:
`:CB_DUMMY.P_REP_TYPE` equals `'N'` (New Sales).

TRUE:
Execute Cursor C1 (new-sale transactions from DMSD_EW_SALE_SM) and populate `B_EW` with new-sale policy data.

FALSE:
Evaluate for Conversion or Cancellation report type (see DP-003 and DP-004).

DP-003

Condition:
`:CB_DUMMY.P_REP_TYPE` equals `'U'` (Conversions/Upgrades).

TRUE:
Execute Cursor C2 (upgrade/transfer/zero-premium transactions from DMSD_EW_SALE_SM) and populate `B_EW` with conversion data.

FALSE:
Evaluate for Cancellation report type (see DP-004).

DP-004

Condition:
`:CB_DUMMY.P_REP_TYPE` equals `'C'` (Cancellations).

TRUE:
Execute Cursor C3 (cancellation transactions from DMSD_EW_SALE_SM) and populate `B_EW` with cancellation data including cancellation fee and credit amount.

FALSE:
No matching branch; no data is loaded.

DP-005

Condition:
`EW.EXTE_WARR_TYPE` equals `'X'` (evaluated in C1, C2, and C3 via `DECODE`).

TRUE:
Display the warranty type as `'VIII'` (remapped for presentation).

FALSE:
Display the warranty type code as stored.

DP-006

Condition:
A warranty type upgrade transition pair is matched in the CASE expression (e.g. old type `'I'` to new type `'II'`, up to `'V'` to `'X'`).

TRUE:
Return the corresponding conversion transition code (e.g. `'C3T4'`, `'C3T10'`, `'C4T7'`, `'C5T7'`, `'C7T10'`).

FALSE:
Return NULL for the conversion status code.

---
**Database Interactions**

- DB-001 - Read DMSD_EW_SALE_SM - Reads data from DMSD_EW_SALE_SM for lookup or validation.
- DB-002 - Select/*+ DMSD_EW_SALE_SM - Accesses DMSD_EW_SALE_SM via select/*+ operation.
- DB-003 - Read GM_VAR - Reads data from GM_VAR for lookup or validation.
**Business Rules**

- SBR-001 - All seven search-criteria fields (Location, Report Type, Contract From Date, Contract To Date, Model, Variant, EW Type) must be populated before the search may proceed.
- SBR-002 - Records are filtered to the current principal (`aloc.principal_map_cd = :global.principal`) at all times, preventing cross-principal data leakage.
- SBR-003 - New-sale transactions are identified by `EXTE_TRAN_TYPE = 'N'`; conversion/upgrade transactions by `EXTE_TRAN_TYPE IN ('U', 'X', 'Z')`; cancellation transactions by `EXTE_TRAN_TYPE = 'C'`.
- SBR-004 - Warranty type `'X'` stored in `DMSD_EW_SALE_SM` is always displayed as `'VIII'` in the on-screen report.
- SBR-005 - The cancellation fee for a cancelled policy is the greater of 10% of the policy premium or ₹200.
- SBR-006 - The credit amount on cancellation is calculated as policy premium minus dealer commission, minus service-tax commission, minus SBC tax, minus the cancellation fee.
- SBR-007 - An optional vendor-code filter (`CB_DUMMY.vend`) restricts results to records where `NVL(xw.vend_cd, 'CWI')` matches the selected vendor; when no vendor is selected, all records are included.
- SBR-008 - Warranty type upgrade transition codes cover an extended range compared to PMC1, mapping combinations involving types I through X (e.g. I->V = `'C3T7'`, II->X = `'C4T10'`, V->X = `'C7T10'`).

---
**Implementation Logic**

```plsql
PROCEDURE proc_rep_search_pmc2 IS
CURSOR C1 IS
SELECT /*+ INDEX (EW MWAR_EXTE_MK5)*/
      EW.EXTE_POLICY_NO,
      EW.EXTE_VIN_NO,
      EW.EXTE_REGISTRATION_NO,
      EW.EXTE_RETLSALE_DT,
      EW.EXTE_CONTRACT_DATE,
      XW.EXTE_MODL_CODE,
      XW.EXTE_VARIANT_CD,
      --SF_GET_EW_VALIDITY_DTL(EW.EXTE_POLICY_NO,'Q') EXTE_WARR_TYPE, 
      decode(EW.EXTE_WARR_TYPE,'X','VIII',EW.EXTE_WARR_TYPE) EXTE_WARR_TYPE,
      EW.EXTE_CUST_NAME,
      EW.EXTE_CONTRACT_MILEAGE,
      EW.EXTE_VALID_DATE,
      EW.EXTE_VALID_MILEAGE,
      EW.EXTE_POLICY_PREMIUM EXTE_PREMIUM_CALCULATED,--EW.EXTE_PREMIUM_CALCULATED, --EW.EXTE_PREMIUM,
      EW.EXTE_COMMISION_AMT EXTE_PREM_DLR_COMM,---EW.EXTE_PREM_DLR_COMM,
      EW.EXTE_SRV_TAX_COMMISSION EXTE_PREM_SRV_TAX,--EW.EXTE_PREM_SRV_TAX,
      NVL(EW.EXTE_SRV_TAX_PREMIUM,0) exte_tot_prem_srv_tax,---NVL(EW.exte_tot_prem_srv_tax,0) exte_tot_prem_srv_tax,
      NVL(EW.EXTE_SRV_TAX_PREMIUM,0) exte_tot_conv_srv_tax,----NVL(EW.exte_tot_conv_srv_tax,0) exte_tot_conv_srv_tax,
      (NVL(EW.EXTE_POLICY_PREMIUM,0) - NVL(EW.EXTE_COMMISION_AMT,0) - NVL(EW.EXTE_SRV_TAX_COMMISSION,0)-NVL(EW.EXTE_TOT_PREM_SBC_TAX,0)-NVL(EW.EXTE_TOT_PREM_KKC_TAX,0))DEBIT_AMT,
     --- (NVL(EW.EXTE_PREMIUM_CALCULATED,0) - NVL(EW.EXTE_PREM_DLR_COMM,0) - NVL(EW.EXTE_PREM_SRV_TAX,0)-NVL(EW.EXTE_PREM_SBC_TAX,0)-NVL(EW.EXTE_PREM_KKC_TAX,0))DEBIT_AMT,  /*added by bhawana on 26-nov-2015 against DMSSERV-13251,KKC ADDED BY BHAWANA ON 20-MAY-2016*/
      --(EW.EXTE_PREMIUM - EW.EXTE_PREM_DLR_COMM - EW.EXTE_PREM_SRV_TAX) DEBIT_AMT,
      XW.EXTE_CREATED_BY,
      sf_ew_policy_status(EW.EXTE_POLICY_NO) status,
      ALOC.DEALER_NAME,
      ALOC.LOC_DESC,
      nvl(EW.EXTE_PREM_SBC_TAX,0)EXTE_PREM_SBC_TAX,           /*added by bhawana on 26-nov-2015 against DMSSERV-13251*/
      NVL(EW.exte_tot_prem_sbc_tax,0) exte_tot_prem_sbc_tax, /*added by bhawana on 26-nov-2015 against DMSSERV-13251*/
      NVL(EW.exte_tot_conv_sbc_tax,0) exte_tot_conv_sbc_tax,  /*added by bhawana on 26-nov-2015 against DMSSERV-13251*/
      nvl(EW.EXTE_PREM_KKC_TAX,0)EXTE_PREM_KKC_TAX,          /*added by bhawana ON 20-MAY-2016 FOR KKC*/
      NVL(EW.exte_tot_prem_kkc_tax,0) exte_tot_prem_kkc_tax, /*added by bhawana ON 20-MAY-2016 FOR KKC*/
      NVL(EW.exte_tot_conv_kkc_tax,0) exte_tot_conv_kkc_tax,  /*added by bhawana ON 20-MAY-2016 FOR KKC*/
      -----------added by shankar on 07-jul-2017 for GST------------
      EW.EXTE_PREM_CGST_AMT,
      EW.EXTE_PREM_SGST_AMT,
      EW.EXTE_PREM_IGST_AMT,      
      EW.EXTE_PREM_COMM_IGST,
      EW.EXTE_PREM_COMM_SGST,
      EW.EXTE_PREM_COMM_CGST,
     (case when EW.EXTE_WARR_TYPE_OLD ='I' and EW.EXTE_WARR_TYPE='II' then
                'C3T4'                
            when EW.EXTE_WARR_TYPE_OLD='I' and EW.EXTE_WARR_TYPE='III' then 
               'C3T5'
           when EW.EXTE_WARR_TYPE_OLD='II' and EW.EXTE_WARR_TYPE='III' then
             'C4T5'
           when EW.EXTE_WARR_TYPE_OLD='I' and EW.EXTE_WARR_TYPE='V' then
             'C3T7'
           when EW.EXTE_WARR_TYPE_OLD='I' and EW.EXTE_WARR_TYPE='X' then
             'C3T10'
           when EW.EXTE_WARR_TYPE_OLD='II' and EW.EXTE_WARR_TYPE='V' then
             'C4T7' 
           when EW.EXTE_WARR_TYPE_OLD='II' and EW.EXTE_WARR_TYPE='X' then
             'C4T10'
           when EW.EXTE_WARR_TYPE_OLD='III' and EW.EXTE_WARR_TYPE='V' then
             'C5T7' 
           when EW.EXTE_WARR_TYPE_OLD='III' and EW.EXTE_WARR_TYPE='X' then
             'C5T10'
           when EW.EXTE_WARR_TYPE_OLD='III' and EW.EXTE_WARR_TYPE='X' then
             'C5T10' 
           when EW.EXTE_WARR_TYPE_OLD='V' and EW.EXTE_WARR_TYPE='X' then
             'C7T10'     
           else null end  
             ) EXTE_WARR_TYPE_OLD,
             nvl(xw.vend_cd,'CWI') vend_cd
       
      -----------------------------------------   
   FROM DMSD_EW_SALE_SM EW,
      MWAR_EXTE XW,
      AM_DEALER_LOC ALOC
  WHERE  EW.EXTE_POLICY_NO=XW.EXTE_POLICY_NO
	AND	EW.EXTE_TRANSACTION_DATE >= :CB_DUMMY.CONT_FROM_DATE
  AND EW.EXTE_TRANSACTION_DATE < to_date(:CB_DUMMY.CONT_TO_DATE) + 1
  and EXTE_TRAN_TYPE='N'
  AND ALOC.PARENT_GROUP = EW.EXTE_PARENT_GROUP
  AND ALOC.DEALER_MAP_CD = EW.EXTE_DEALER_MAP_CD
  AND ALOC.LOC_CD = EW.EXTE_LOC_CD
  and aloc.principal_map_cd=:global.principal /*added by bhawana*/
  AND EW.EXTE_POLICY_SOLD_FROM = decode(:CB_DUMMY.CB_SOLD_FROM,'A',EW.EXTE_POLICY_SOLD_FROM,:CB_DUMMY.CB_SOLD_FROM)
  AND nvl(xw.vend_cd,'CWI') = decode(:CB_DUMMY.vend,null,nvl(xw.vend_cd,'CWI'),:CB_DUMMY.vend)
  AND ALOC.REGION_CD = decode(:CB_DUMMY.CB_REGION,'All',ALOC.REGION_CD,:CB_DUMMY.CB_REGION)
	AND EW.EXTE_PARENT_GROUP = decode(:CB_DUMMY.CB_PARENT,'All',EW.EXTE_PARENT_GROUP,:CB_DUMMY.CB_PARENT)
  AND EW.EXTE_DEALER_MAP_CD = decode(:CB_DUMMY.CB_DEALER_MAP_CD,'All',EW.EXTE_DEALER_MAP_CD,:CB_DUMMY.CB_DEALER_MAP_CD)
  AND EW.EXTE_LOC_CD = decode(:CB_DUMMY.CB_LOC_CD,'All',EW.EXTE_LOC_CD,:CB_DUMMY.CB_LOC_CD)
  AND XW.EXTE_MODL_CODE = decode(:CB_DUMMY.BASE_MODEL_CD,'All',XW.EXTE_MODL_CODE,:CB_DUMMY.BASE_MODEL_CD)
  AND XW.EXTE_VARIANT_CD = decode(:CB_DUMMY.VARIANT_CD,'All',XW.EXTE_VARIANT_CD,:CB_DUMMY.VARIANT_CD)
  AND EW.EXTE_WARR_TYPE = decode(:CB_DUMMY.EW_TYPE,'All',EW.EXTE_WARR_TYPE,:CB_DUMMY.EW_TYPE)
 -- AND nvl(EW.EXTE_CANCEL_FLAG,'N') = 'N' -- As Diss. with Mr. Anoop all EW show in report
  ORDER BY EW.EXTE_POLICY_NO;

CURSOR C2 IS
SELECT/*+ index (EW MWAR_EXTE_MK9)*/
      EW.EXTE_POLICY_NO,
      EW.EXTE_VIN_NO,
      EW.EXTE_REGISTRATION_NO,
      EW.EXTE_RETLSALE_DT,
      EW.EXTE_CONV_DATE,
      XW.EXTE_MODL_CODE,
      XW.EXTE_VARIANT_CD,
      decode(EW.EXTE_WARR_TYPE,'X','VIII',EW.EXTE_WARR_TYPE) EXTE_WARR_TYPE,
      EW.EXTE_CUST_NAME,
      EW.EXTE_CONV_MILEAGE,
      EW.EXTE_VALID_DATE,
      EW.EXTE_VALID_MILEAGE,
      EW.EXTE_POLICY_PREMIUM EXTE_PREMIUM ,----EW.EXTE_PREMIUM_CALCULATED EXTE_PREMIUM,
      ew.exte_premium_recd EXTE_DIFF_PREMIUM,---EW.EXTE_DIFF_PREMIUM,
      EW.EXTE_COMMISION_AMT EXTE_CONV_DLR_COMM,--EW.EXTE_CONV_DLR_COMM,
      EW.EXTE_SRV_TAX_COMMISSION EXTE_CONV_SRV_TAX,--EW.EXTE_CONV_SRV_TAX,
      NVL(EW.EXTE_SRV_TAX_PREMIUM,0) exte_tot_prem_srv_tax,----NVL(EW.exte_tot_prem_srv_tax,0) exte_tot_prem_srv_tax,
       NVL(EW.EXTE_SRV_TAX_PREMIUM,0) exte_tot_conv_srv_tax,--NVL(EW.exte_tot_conv_srv_tax,0) exte_tot_conv_srv_tax,
      (NVL(EW.exte_premium_recd,0) - NVL(EW.EXTE_COMMISION_AMT,0) - NVL(EW.EXTE_COMMISION_AMT,0)-NVL(EW.EXTE_CONV_SBC_TAX,0)-NVL(EW.EXTE_CONV_KKC_TAX,0)) DEBIT_AMT,
      ---(NVL(EW.EXTE_DIFF_PREMIUM,0) - NVL(EW.EXTE_CONV_DLR_COMM,0) - NVL(EW.EXTE_CONV_SRV_TAX,0)-NVL(EW.EXTE_CONV_SBC_TAX,0)-NVL(EW.EXTE_CONV_KKC_TAX,0)) DEBIT_AMT, /*changes by bhawana on 26-nov-2015 against DMSSERV-13251 ,added by bhawana on 20-MAY-2016*/
      XW.EXTE_MODIFIED_BY,
      sf_ew_policy_status(EW.EXTE_POLICY_NO) status,
      ALOC.DEALER_NAME,
      ALOC.LOC_DESC,
      NVL(EW.EXTE_CONV_SBC_TAX,0)EXTE_CONV_SBC_TAX,/*added by bhawana on 26-nov-2015 against DMSSERV-13251*/
      NVL(EW.exte_tot_conv_sbc_tax,0) exte_tot_conv_sbc_tax, /*added by bhawana on 26-nov-2015 against DMSSERV-13251*/
      NVL(EW.exte_tot_prem_sbc_tax,0) exte_tot_prem_sbc_tax ,  /*added by bhawana on 26-nov-2015 against DMSSERV-13251*/
      NVL(EW.EXTE_CONV_KKC_TAX,0)EXTE_CONV_KKC_TAX,/*added by bhawana ON 20-MAY-2016 FOR KKC*/
      NVL(EW.exte_tot_conv_kkc_tax,0) exte_tot_conv_kkc_tax,/*added by bhawana ON 20-MAY-2016 FOR KKC*/
      NVL(EW.exte_tot_prem_kkc_tax,0) exte_tot_prem_kkc_tax ,  /*added by bhawana ON 20-MAY-2016 FOR KKC*/
      -----------added by shankar on 07-jul-2017 for GST------------
      EW.EXTE_PREM_CGST_AMT EXTE_CONV_CGST_AMT,---EW.EXTE_CONV_IGST_AMT,
      EW.EXTE_PREM_SGST_AMT EXTE_CONV_SGST_AMT,--EW.EXTE_CONV_SGST_AMT,
      EW.EXTE_PREM_IGST_AMT EXTE_CONV_IGST_AMT,---EW.EXTE_CONV_CGST_AMT,    
      EW.EXTE_PREM_COMM_IGST EXTE_CONV_COMM_IGST,--EW.EXTE_CONV_COMM_IGST,
      EW.EXTE_PREM_COMM_SGST EXTE_CONV_COMM_SGST,--EW.EXTE_CONV_COMM_SGST,
      EW.EXTE_PREM_COMM_CGST EXTE_CONV_COMM_CGST,--EW.EXTE_CONV_COMM_CGST      
      (case when EW.EXTE_WARR_TYPE_OLD ='I' and EW.EXTE_WARR_TYPE='II' then
                'C3T4'                
            when EW.EXTE_WARR_TYPE_OLD='I' and EW.EXTE_WARR_TYPE='III' then 
               'C3T5'
           when EW.EXTE_WARR_TYPE_OLD='II' and EW.EXTE_WARR_TYPE='III' then
             'C4T5'
           when EW.EXTE_WARR_TYPE_OLD='I' and EW.EXTE_WARR_TYPE='V' then
             'C3T7'
           when EW.EXTE_WARR_TYPE_OLD='I' and EW.EXTE_WARR_TYPE='X' then
             'C3T10'
           when EW.EXTE_WARR_TYPE_OLD='II' and EW.EXTE_WARR_TYPE='V' then
             'C4T7' 
           when EW.EXTE_WARR_TYPE_OLD='II' and EW.EXTE_WARR_TYPE='X' then
             'C4T10'
           when EW.EXTE_WARR_TYPE_OLD='III' and EW.EXTE_WARR_TYPE='V' then
             'C5T7' 
           when EW.EXTE_WARR_TYPE_OLD='III' and EW.EXTE_WARR_TYPE='X' then
             'C5T10'
           when EW.EXTE_WARR_TYPE_OLD='III' and EW.EXTE_WARR_TYPE='X' then
             'C5T10' 
           when EW.EXTE_WARR_TYPE_OLD='V' and EW.EXTE_WARR_TYPE='X' then
             'C7T10'     
           else null  end  
             ) EXTE_WARR_TYPE_OLD,
            nvl(xw.vend_cd,'CWI') vend_cd
      -----------------------------------------------
FROM  DMSD_EW_SALE_SM EW,
      MWAR_EXTE XW,
      AM_DEALER_LOC ALOC
WHERE EW.EXTE_POLICY_NO=XW.EXTE_POLICY_NO
	AND	EW.EXTE_TRANSACTION_DATE >= :CB_DUMMY.CONT_FROM_DATE
  AND EW.EXTE_TRANSACTION_DATE < to_date(:CB_DUMMY.CONT_TO_DATE) + 1
  and EXTE_TRAN_TYPE IN ('U','X','Z') 
		---	EW.EXTE_CONV_DATE >= :CB_DUMMY.CONT_FROM_DATE
  --AND EW.EXTE_CONV_DATE < to_date(:CB_DUMMY.CONT_TO_DATE) + 1
  AND ALOC.PARENT_GROUP = EW.EXTE_CONV_PARENT_GROUP
  AND ALOC.DEALER_MAP_CD = EW.EXTE_CONV_DEALER_MAP_CD
  AND ALOC.LOC_CD = EW.EXTE_CONV_LOC_CD
  AND nvl(xw.vend_cd,'CWI') = decode(:CB_DUMMY.vend,null,nvl(xw.vend_cd,'CWI'),:CB_DUMMY.vend)
  and aloc.principal_map_cd=:global.principal /*added by bhawana*/
  AND NVL(EW.EXTE_CONV_FROM,'X') = decode(:CB_DUMMY.CB_SOLD_FROM,'A',NVL(EW.EXTE_CONV_FROM,'X'),:CB_DUMMY.CB_SOLD_FROM)
  AND ALOC.REGION_CD = decode(:CB_DUMMY.CB_REGION,'All',ALOC.REGION_CD,:CB_DUMMY.CB_REGION)
	AND EW.EXTE_CONV_PARENT_GROUP = decode(:CB_DUMMY.CB_PARENT,'All',EW.EXTE_CONV_PARENT_GROUP,:CB_DUMMY.CB_PARENT)
  AND EW.EXTE_CONV_DEALER_MAP_CD = decode(:CB_DUMMY.CB_DEALER_MAP_CD,'All',EW.EXTE_CONV_DEALER_MAP_CD,:CB_DUMMY.CB_DEALER_MAP_CD)
  AND EW.EXTE_CONV_LOC_CD = decode(:CB_DUMMY.CB_LOC_CD,'All',EW.EXTE_CONV_LOC_CD,:CB_DUMMY.CB_LOC_CD)
  AND XW.EXTE_MODL_CODE = decode(:CB_DUMMY.BASE_MODEL_CD,'All',XW.EXTE_MODL_CODE,:CB_DUMMY.BASE_MODEL_CD)
  AND XW.EXTE_VARIANT_CD = decode(:CB_DUMMY.VARIANT_CD,'All',XW.EXTE_VARIANT_CD,:CB_DUMMY.VARIANT_CD)
  AND EW.EXTE_WARR_TYPE = decode(:CB_DUMMY.EW_TYPE,'All',EW.EXTE_WARR_TYPE,:CB_DUMMY.EW_TYPE)
 -- AND nvl(EW.EXTE_CANCEL_FLAG,'N') = 'N' -- As Diss. with Mr. Anoop all EW show in report
  ORDER BY EW.EXTE_POLICY_NO;

CURSOR C3 IS
SELECT/*+ index (EW MWAR_EXTE_MK14)*/
      EW.EXTE_POLICY_NO,
      EW.EXTE_VIN_NO,
      EW.EXTE_REGISTRATION_NO,
      EW.EXTE_RETLSALE_DT,
      EW.EXTE_CANCEL_DT,
      XW.EXTE_MODL_CODE,
      XW.EXTE_VARIANT_CD,
      decode(EW.EXTE_WARR_TYPE,'X','VIII',EW.EXTE_WARR_TYPE) EXTE_WARR_TYPE,
      EW.EXTE_CUST_NAME,
      EW.EXTE_CONTRACT_MILEAGE,
      EW.EXTE_VALID_DATE,
      EW.EXTE_VALID_MILEAGE,
      EW.EXTE_POLICY_PREMIUM EXTE_PREMIUM,--EW.EXTE_PREMIUM,
      EW.EXTE_COMMISION_AMT EXTE_PREM_DLR_COMM,---EW.EXTE_PREM_DLR_COMM,
      EW.EXTE_SRV_TAX_COMMISSION EXTE_PREM_SRV_TAX,--EW.EXTE_PREM_SRV_TAX,
      XW.EXTE_CANCELED_BY,
      sf_ew_policy_status(EW.EXTE_POLICY_NO) status,
      ---greatest((NVL(EW.EXTE_PREMIUM,0) * 0.1),200) cancel_amt,
      greatest((NVL(EW.EXTE_POLICY_PREMIUM,0) * 0.1),200) cancel_amt,
      NVL(EW.EXTE_SRV_TAX_PREMIUM,0) exte_tot_prem_srv_tax,---NVL(EW.exte_tot_prem_srv_tax,0) exte_tot_prem_srv_tax,
      NVL(EW.EXTE_SRV_TAX_PREMIUM,0) exte_tot_conv_srv_tax, --NVL(EW.exte_tot_conv_srv_tax,0) exte_tot_conv_srv_tax, 
      (NVL(EW.EXTE_POLICY_PREMIUM,0) - NVL(EW.EXTE_COMMISION_AMT,0) - NVL(EW.EXTE_SRV_TAX_COMMISSION,0) - NVL(EW.EXTE_PREM_SBC_TAX,0)-greatest((NVL(EW.EXTE_POLICY_PREMIUM,0) * 0.1),200)) credit_amt,
      ---(NVL(EW.EXTE_PREMIUM,0) - NVL(EW.EXTE_PREM_DLR_COMM,0) - NVL(EW.EXTE_PREM_SRV_TAX,0) - NVL(EW.EXTE_PREM_SBC_TAX,0)-greatest((NVL(EW.EXTE_PREMIUM,0) * 0.1),200)) credit_amt,  /*changes by bhawana on 26-nov-2015 against DMSSERV-13251*/
      XW.EXTE_REMARKS,
      ALOC.DEALER_NAME,
      ALOC.LOC_DESC,
      nvl(EW.EXTE_PREM_SBC_TAX,0)EXTE_PREM_SBC_TAX,          /*added by bhawana on 26-nov-2015 against DMSSERV-13251*/
      NVL(EW.exte_tot_prem_sbc_tax,0) exte_tot_prem_sbc_tax, /*added by bhawana on 26-nov-2015 against DMSSERV-13251*/
      NVL(EW.exte_tot_conv_sbc_tax,0) exte_tot_conv_sbc_tax,  /*added by bhawana on 26-nov-2015 against DMSSERV-13251*/
      nvl(EW.EXTE_PREM_KKC_TAX,0)EXTE_PREM_KKC_TAX,          /*added by bhawana ON 20-MAY-2016 FOR KKC*/
      NVL(EW.exte_tot_prem_kkc_tax,0) exte_tot_prem_kkc_tax,  /*added by bhawana ON 20-MAY-2016 FOR KKC*/
      NVL(EW.exte_tot_conv_kkc_tax,0) exte_tot_conv_kkc_tax,   /*added by bhawana ON 20-MAY-2016 FOR KKC*/
      ----------------------GST---------------------------      
      (greatest((EW.EXTE_POLICY_PREMIUM * 0.1),200)*EW.EXTE_PREM_IGST_RATE/100) IGST_AMT,     
      (greatest((EW.EXTE_POLICY_PREMIUM * 0.1),200)*EW.EXTE_PREM_CGST_RATE/100)  CGST_AMT,   
      (greatest((EW.EXTE_POLICY_PREMIUM * 0.1),200)*EW.EXTE_PREM_SGST_RATE/100)  SGST_AMT,     
      ew.exte_prem_srv_inv_no,          
      NVL(EW.EXTE_PREM_COMM_IGST,0) EXTE_PREM_COMM_IGST,
      NVL(EW.EXTE_PREM_COMM_SGST,0) EXTE_PREM_COMM_SGST,
      NVL(EW.EXTE_PREM_COMM_CGST,0) EXTE_PREM_COMM_CGST,
      (case when EW.EXTE_WARR_TYPE_OLD ='I' and EW.EXTE_WARR_TYPE='II' then
                'C3T4'                
            when EW.EXTE_WARR_TYPE_OLD='I' and EW.EXTE_WARR_TYPE='III' then 
               'C3T5'
           when EW.EXTE_WARR_TYPE_OLD='II' and EW.EXTE_WARR_TYPE='III' then
             'C4T5'
           when EW.EXTE_WARR_TYPE_OLD='I' and EW.EXTE_WARR_TYPE='V' then
             'C3T7'
           when EW.EXTE_WARR_TYPE_OLD='I' and EW.EXTE_WARR_TYPE='X' then
             'C3T10'
           when EW.EXTE_WARR_TYPE_OLD='II' and EW.EXTE_WARR_TYPE='V' then
             'C4T7' 
           when EW.EXTE_WARR_TYPE_OLD='II' and EW.EXTE_WARR_TYPE='X' then
             'C4T10'
           when EW.EXTE_WARR_TYPE_OLD='III' and EW.EXTE_WARR_TYPE='V' then
             'C5T7' 
           when EW.EXTE_WARR_TYPE_OLD='III' and EW.EXTE_WARR_TYPE='X' then
             'C5T10'
           when EW.EXTE_WARR_TYPE_OLD='III' and EW.EXTE_WARR_TYPE='X' then
             'C5T10' 
           when EW.EXTE_WARR_TYPE_OLD='V' and EW.EXTE_WARR_TYPE='X' then
             'C7T10'       
           else null end  
             ) EXTE_WARR_TYPE_OLD      ,
            nvl(xw.vend_cd,'CWI') vend_cd
FROM  DMSD_EW_SALE_SM ew,
      MWAR_EXTE XW,
      AM_DEALER_LOC ALOC
WHERE EW.EXTE_POLICY_NO=XW.EXTE_POLICY_NO
  AND  EW.EXTE_TRANSACTION_DATE >= :CB_DUMMY.CONT_FROM_DATE
  AND EW.EXTE_TRANSACTION_DATE < to_date(:CB_DUMMY.CONT_TO_DATE) + 1
  AND EXTE_TRAN_TYPE ='C'
			--EW.EXTE_CANCEL_DT >= :CB_DUMMY.CONT_FROM_DATE
 -- AND EW.EXTE_CANCEL_DT < to_date(:CB_DUMMY.CONT_TO_DATE) + 1
  AND ALOC.PARENT_GROUP(+) = EW.EXTE_PARENT_GROUP
  AND ALOC.DEALER_MAP_CD(+) = EW.EXTE_DEALER_MAP_CD
  AND ALOC.LOC_CD(+) = EW.EXTE_LOC_CD
  and aloc.principal_map_cd=:global.principal /*added by bhwana*/
  AND EW.EXTE_POLICY_SOLD_FROM = decode(:CB_DUMMY.CB_SOLD_FROM,'A',EW.EXTE_POLICY_SOLD_FROM,:CB_DUMMY.CB_SOLD_FROM)
  AND nvl(ALOC.REGION_CD,'A') = decode(:CB_DUMMY.CB_REGION,'All',nvl(ALOC.REGION_CD,'A'),:CB_DUMMY.CB_REGION)
	AND nvl(EW.EXTE_PARENT_GROUP,'A') = decode(:CB_DUMMY.CB_PARENT,'All',nvl(EW.EXTE_PARENT_GROUP,'A'),:CB_DUMMY.CB_PARENT)
  AND nvl(EW.EXTE_DEALER_MAP_CD,1) = decode(:CB_DUMMY.CB_DEALER_MAP_CD,'All',nvl(EW.EXTE_DEALER_MAP_CD,1),:CB_DUMMY.CB_DEALER_MAP_CD)
  AND nvl(xw.vend_cd,'CWI') = decode(:CB_DUMMY.vend,null,nvl(xw.vend_cd,'CWI'),:CB_DUMMY.vend)
  AND nvl(EW.EXTE_LOC_CD,'A') = decode(:CB_DUMMY.CB_LOC_CD,'All',nvl(EW.EXTE_LOC_CD,'A'),:CB_DUMMY.CB_LOC_CD)
  AND XW.EXTE_MODL_CODE = decode(:CB_DUMMY.BASE_MODEL_CD,'All',XW.EXTE_MODL_CODE,:CB_DUMMY.BASE_MODEL_CD)
  AND nvl(XW.EXTE_VARIANT_CD,'A') = decode(:CB_DUMMY.VARIANT_CD,'All',nvl(XW.EXTE_VARIANT_CD,'A'),:CB_DUMMY.VARIANT_CD)
  AND EW.EXTE_WARR_TYPE = decode(:CB_DUMMY.EW_TYPE,'All',EW.EXTE_WARR_TYPE,:CB_DUMMY.EW_TYPE)
  ---AND nvl(EW.EXTE_CANCEL_FLAG,'N') = 'Y'
  ORDER BY EW.EXTE_POLICY_NO;

lv_cnt_n number := 0;
lv_cnt_u number := 0;
lv_cnt_c number := 0;

BEGIN

	IF :CB_DUMMY.CB_LOC_DESC IS NULL THEN
		general.check_null(:cb_dummy.CB_LOC_DESC,'Location');
		go_item('cb_dummy.CB_LOC_DESC');
	END IF;
	IF :CB_DUMMY.P_REP_TYPE IS NULL THEN
	  general.check_null(:cb_dummy.P_REP_TYPE,'Extended Warranty Status');
	  go_item('cb_dummy.P_REP_TYPE');
	END IF;
	IF :CB_DUMMY.CONT_FROM_DATE IS NULL THEN
	  general.check_null(:cb_dummy.CONT_FROM_DATE,'Contract From Date');
	  go_item('cb_dummy.CONT_FROM_DATE');
	END IF;
	IF :CB_DUMMY.CONT_TO_DATE IS NULL THEN
	  general.check_null(:cb_dummy.CONT_TO_DATE,'Contract To Date');
	  go_item('cb_dummy.CONT_TO_DATE');
	END IF;
	IF :CB_DUMMY.BASE_MODEL_CD IS NULL THEN
	  general.check_null(:cb_dummy.BASE_MODEL_CD,'Model');
	  go_item('cb_dummy.BASE_MODEL_CD');
	END IF;
	IF :CB_DUMMY.VARIANT_CD IS NULL THEN
	  general.check_null(:cb_dummy.VARIANT_CD,'Variant');
	  go_item('cb_dummy.VARIANT_CD');
	END IF;
	IF :CB_DUMMY.EW_TYPE IS NULL THEN
	  general.check_null(:cb_dummy.EW_TYPE,'Extended Warranty Type');
	  go_item('cb_dummy.EW_TYPE');
	END IF;

IF :CB_DUMMY.P_REP_TYPE = 'N' THEN
		go_block('B_EW');
		clear_block;
		first_record;
			FOR i IN c1 LOOP
				:B_EW.vend 		:= i.vend_cd;
				:B_EW.EXTE_POLICY_NO 		:= i.EXTE_POLICY_NO;
				:B_EW.EXTE_VIN_NO := i.EXTE_VIN_NO;
		    :B_EW.EXTE_RETLSALE_DT := i.EXTE_RETLSALE_DT;
		    :B_EW.EXTE_CONTRACT_DATE := i.EXTE_CONTRACT_DATE;
		    :B_EW.EXTE_VARIANT_CD := i.EXTE_VARIANT_CD;
		    :B_EW.EXTE_WARR_TYPE := i.EXTE_WARR_TYPE;
		    :B_EW.EXTE_CUST_NAME := i.EXTE_CUST_NAME;
		    :B_EW.EXTE_PREMIUM := i.EXTE_PREMIUM_CALCULATED;
		    :B_EW.EXTE_PREM_DLR_COMM := i.EXTE_PREM_DLR_COMM;
		    :B_EW.EXTE_PREM_SRV_TAX := i.EXTE_PREM_SRV_TAX;
		    :B_EW.EXTE_DEBIT_AMT := i.DEBIT_AMT;
		    :B_EW.EXTE_CREATED_BY := i.EXTE_CREATED_BY;
		    :B_EW.EXTE_CREATED_BY2 := i.EXTE_CREATED_BY;
		    :B_EW.EXTE_STATUS := i.status;
		    :B_EW.EXTE_DEALER_NAME := i.dealer_name;
		    :B_EW.EXTE_LOCATION_DESC := i.loc_desc;
				:B_EW.EXTE_CANCEL_AMT := 0;
				:B_EW.Serv_Tax_Prem_Amt := i.exte_tot_prem_srv_tax;
				:B_EW.EXTE_PREM_SBC_TAX := i.EXTE_PREM_SBC_TAX;      /*added by bhawana on 26-nov-2015 against DMSSERV-13251*/
        :B_EW.SBC_Tax_Prem_Amt := i.exte_tot_prem_sbc_tax;  /*added by bhawana on 26-nov-2015 against DMSSERV-13251*/
        :B_EW.EXTE_PREM_KKC_TAX := i.EXTE_PREM_KKC_TAX;     /*added by bhawana ON 20-MAY-2016 FOR KKC*/
        :B_EW.KKC_Tax_Prem_Amt := i.exte_tot_prem_kkc_tax;  /*added by bhawana ON 20-MAY-2016 FOR KKC*/
        ---------added by shankar on 07-jul-2017 for GST--------------------
        :B_EW.EXTE_PREM_IGST_AMT:=i.EXTE_PREM_IGST_AMT;
        :B_EW.EXTE_PREM_SGST_AMT:=i.EXTE_PREM_SGST_AMT;
        :B_EW.EXTE_PREM_CGST_AMT:=i.EXTE_PREM_CGST_AMT;        
        :B_EW.EXTE_PREM_COMM_IGST:=i.EXTE_PREM_COMM_IGST;
        :B_EW.EXTE_PREM_COMM_SGST:=i.EXTE_PREM_COMM_SGST;
        :B_EW.EXTE_PREM_COMM_CGST:=i.EXTE_PREM_COMM_CGST;
        :B_EW.conv_status:=i.EXTE_WARR_TYPE_OLD;
        -----------------------------------------------------       
		    BEGIN
				    SELECT variant_desc
						INTO :B_EW.VARIANT_DESC
		  			FROM gm_var
		 				WHERE variant_cd = i.EXTE_VARIANT_CD
		 				and principal_map_cd=:global.principal;/*added by bhawana*/
		    EXCEPTION
		    	WHEN OTHERS THEN
		    	null;
		    END;

		  EXIT WHEN c1%notfound;--:system.last_record = 'TRUE';
		  next_record;

			END LOOP;
message(:system.TRIGGER_RECORD);
:CB_DUMMY.TOT_REC := :system.TRIGGER_RECORD - 1;

ELSIF :CB_DUMMY.P_REP_TYPE = 'U' THEN
				go_block('B_EW');
				clear_block;
				first_record;
					FOR i IN c2 LOOP
						:B_EW.vend 		:= i.vend_cd;
						:B_EW.EXTE_POLICY_NO := i.EXTE_POLICY_NO;
						:B_EW.EXTE_VIN_NO := i.EXTE_VIN_NO;
				    :B_EW.EXTE_RETLSALE_DT := i.EXTE_RETLSALE_DT;
				    :B_EW.EXTE_CONTRACT_DATE := i.EXTE_CONV_DATE;
				    :B_EW.EXTE_VARIANT_CD := i.EXTE_VARIANT_CD;
				    :B_EW.EXTE_WARR_TYPE := i.EXTE_WARR_TYPE;
				    :B_EW.EXTE_CUST_NAME := i.EXTE_CUST_NAME;
				    :B_EW.EXTE_PREMIUM := i.EXTE_DIFF_PREMIUM;
				    :B_EW.EXTE_PREM_DLR_COMM := i.EXTE_CONV_DLR_COMM;
				    :B_EW.EXTE_PREM_SRV_TAX := i.EXTE_CONV_SRV_TAX;
				    :B_EW.EXTE_DEBIT_AMT := i.DEBIT_AMT;
				    :B_EW.EXTE_CREATED_BY := i.EXTE_MODIFIED_BY;
				    :B_EW.EXTE_CREATED_BY2 := i.EXTE_MODIFIED_BY;
				    :B_EW.EXTE_STATUS := i.status;    
				    :B_EW.SERV_TAX_DIFF_PREM_AMT := i.exte_tot_conv_srv_tax;  
				    :B_EW.EXTE_DEALER_NAME := i.dealer_name;
		    		:B_EW.EXTE_LOCATION_DESC := i.loc_desc;
           	:B_EW.EXTE_CANCEL_AMT := 0;
           	:B_EW.EXTE_PREM_SBC_TAX := i.EXTE_CONV_SBC_TAX;           /*added by bhawana against DMSSERV-13251 on 26-nov-2015*/
           	:B_EW.SBC_TAX_DIFF_PREM_AMT := i.exte_tot_conv_sbc_tax;  /*added by bhawana against DMSSERV-13251 on 26-nov-2015*/
           	:B_EW.EXTE_PREM_KKC_TAX := i.EXTE_CONV_KKC_TAX;          /*added by bhawana ON 20-MAY-2016 FOR KKC*/
           	:B_EW.KKC_TAX_DIFF_PREM_AMT := i.exte_tot_conv_kkc_tax;  /*added by bhawana ON 20-MAY-2016 FOR KKC*/
           	-----------added by shankar 30-jul-2017 FOR GST------- 
           	 :B_EW.EXTE_PREM_IGST_AMT:=i.EXTE_CONV_IGST_AMT;
           	 :B_EW.EXTE_PREM_SGST_AMT:=i.EXTE_CONV_SGST_AMT;
           	 :B_EW.EXTE_PREM_CGST_AMT:=i.EXTE_CONV_CGST_AMT;           	 
           	 :B_EW.EXTE_PREM_COMM_IGST:=i.EXTE_CONV_COMM_IGST;
           	 :B_EW.EXTE_PREM_COMM_SGST:=i.EXTE_CONV_COMM_SGST;
           	 :B_EW.EXTE_PREM_COMM_CGST:=i.EXTE_CONV_COMM_CGST;
            	:B_EW.CONV_STATUS:=i.EXTE_WARR_TYPE_OLD;
           	 ----------------------------------------------------------- 	
				BEGIN
				    SELECT variant_desc
						INTO :B_EW.VARIANT_DESC
		  			FROM gm_var
		 				WHERE variant_cd = i.EXTE_VARIANT_CD
		 				and principal_map_cd=:global.principal;/*added by bhawana*/
		    EXCEPTION
		    	WHEN OTHERS THEN
		    	null;
		    END;
				  EXIT WHEN c2%notfound;--:system.last_record = 'TRUE';
				  next_record; 

					END LOOP;

:CB_DUMMY.TOT_REC := :system.TRIGGER_RECORD - 1;

ELSIF :CB_DUMMY.P_REP_TYPE = 'C' THEN
			go_block('B_EW');
			clear_block;
			first_record;
				FOR i IN c3 LOOP
					:B_EW.vend 		:= i.vend_cd;
					:B_EW.EXTE_POLICY_NO := i.EXTE_POLICY_NO;
					:B_EW.EXTE_VIN_NO := i.EXTE_VIN_NO;
			    :B_EW.EXTE_RETLSALE_DT := i.EXTE_RETLSALE_DT;
			    :B_EW.EXTE_CONTRACT_DATE := i.EXTE_CANCEL_DT;
			    :B_EW.EXTE_VARIANT_CD := i.EXTE_VARIANT_CD;
			    :B_EW.EXTE_WARR_TYPE := i.EXTE_WARR_TYPE;
			    :B_EW.EXTE_CUST_NAME := i.EXTE_CUST_NAME;
			    :B_EW.EXTE_PREMIUM := i.EXTE_PREMIUM;
			    :B_EW.EXTE_PREM_DLR_COMM := i.EXTE_PREM_DLR_COMM;
			    :B_EW.EXTE_PREM_SRV_TAX := i.EXTE_PREM_SRV_TAX;
			    :B_EW.EXTE_CREATED_BY := i.EXTE_CANCELED_BY;
			    :B_EW.EXTE_STATUS := i.status;
			    :B_EW.EXTE_REMARKS := i.EXTE_REMARKS;
			    :B_EW.EXTE_DEBIT_AMT := 0;
			    :B_EW.EXTE_CANCEL_AMT := i.cancel_amt;
			    :B_EW.EXTE_CREDIT_AMT := i.credit_amt;
			    :B_EW.Serv_Tax_Prem_Amt := i.exte_tot_prem_srv_tax;
			    :B_EW.EXTE_DEALER_NAME := i.dealer_name;
		    	:B_EW.EXTE_LOCATION_DESC := i.loc_desc;
          :B_EW.SBC_Tax_Prem_Amt := i.exte_tot_prem_sbc_tax;       /*added by bhawana against DMSSERV-13251 on 26-nov-2015*/
          :B_EW.EXTE_PREM_SBC_TAX := i.EXTE_PREM_SBC_TAX;       /*added by bhawana against DMSSERV-13251 on 26-nov-2015*/
          :B_EW.KKC_Tax_Prem_Amt := i.exte_tot_prem_kkc_tax;     /*added by bhawana ON 20-MAY-2016 FOR KKC*/
          :B_EW.EXTE_PREM_KKC_TAX := i.EXTE_PREM_KKC_TAX;     /*added by bhawana ON 20-MAY-2016 FOR KKC*/
          -----------GST-----------------          
          ---:B_EW.EXTE_PREM_SRV_INV_NO:=i.EXTE_PREM_SRV_INV_NO;         	 
	        :B_EW.EXTE_PREM_IGST_AMT:=i.IGST_AMT;
	        :B_EW.EXTE_PREM_SGST_AMT:=i.SGST_AMT;
	        :B_EW.EXTE_PREM_CGST_AMT:=i.CGST_AMT;        
	        :B_EW.EXTE_PREM_COMM_IGST:=i.EXTE_PREM_COMM_IGST;
	        :B_EW.EXTE_PREM_COMM_SGST:=i.EXTE_PREM_COMM_SGST;
	        :B_EW.EXTE_PREM_COMM_CGST:=i.EXTE_PREM_COMM_CGST;
	        :B_EW.CONV_STATUS:=i.EXTE_WARR_TYPE_OLD;  
        

			  BEGIN
				    SELECT variant_desc
						INTO :B_EW.VARIANT_DESC
		  			FROM gm_var
		 				WHERE variant_cd = i.EXTE_VARIANT_CD
		 				and principal_map_cd=:global.principal;/*added by bhawana*/
		    EXCEPTION
		    	WHEN OTHERS THEN
		    	null;
		    END;

			  EXIT WHEN c3%notfound;--:system.last_record = 'TRUE';
			  next_record; 

				END LOOP;

:CB_DUMMY.TOT_REC := :system.TRIGGER_RECORD - 1;

			END IF;
				first_record;
END;
```

#### SP-003 - PROC_REP_XL_PMC1

**Invoked From:**

- vr_exte_warr_msil_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

Search Criteria (N/A / CN_MAIN)

---

**Purpose**

Validates all mandatory search-criteria fields, builds a dynamic SQL query string for the selected report type (New Sale, Conversion, or Cancellation), and exports the results as a CSV file to the application server by calling `VIEW_EXCEL_REP`. For New Sales and Cancellations the exported data is a UNION of live DMS records from `DMSD_EW_SALE` and legacy/migrated records from `VT_EXTSAWA`; Conversions draw exclusively from `DMSD_EW_SALE`. Each report branch produces a header block (report title, dealer name, date range) followed by column titles and detail rows containing financial, GST, EMI, and employee fields appropriate to the transaction type.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.CHECK_NULL ([SP-006](#SP-006--GENERAL.CHECK_NULL)) - matched by member name (package unresolved)
- VIEW_EXCEL_REP ([SP-005](#SP-005--VIEW_EXCEL_REP)) - JSON-LD ProgramUnit

---

**Step-by-Step Business Logic**

- Step 1 - Validate mandatory fields: check each of the seven criteria fields (Location, Extended Warranty Status, Contract From Date, Contract To Date, Model, Variant, Extended Warranty Type) for NULL; for any NULL field call `GENERAL.CHECK_NULL`, navigate to that field, and abort.
- Step 2 - Resolve the dealer name for the report header: if `:CB_DUMMY.CB_PARENT` equals `'All'`, set `:CB_DUMMY.CB_DEALER_NAME` to `'All Dealers (All locations)'`; otherwise query `AM_DEALER_LOC` to retrieve the dealer name concatenated with location description, restricted to active (non-terminated) dealers for the current principal. Any exception is suppressed silently.
- Step 3 - Derive the CSV output filename as `<global.userid>_<RRRRMMDDHH24MISS>.csv`.
- Step 4 - Compute `lv_to_date` as `:CB_DUMMY.CONT_TO_DATE + 1` to make the contract date range end-inclusive.
- Step 5 - For **New Sales** (`P_REP_TYPE = 'N'`): build dynamic SQL `v_query` that emits the title 'Extended Warranty Sale Details Report', the dealer name/date-range header rows, and a column-title row, then UNIONs two detail sets:
  - Set X from `DMSD_EW_SALE` (joined to `MWAR_EXTE` and `AM_DEALER_LOC`, filtered to `EXTE_TRAN_TYPE = 'N'`) including region/dealer code, dealer name via `sf_get_dlr_name_loc`, policy number, sale and VIN dates, model/variant codes and descriptions (commas replaced) from `GM_MOD`/`GM_VAR`, customer name (commas, CR, LF, ampersand, double-quote stripped), mileage, warranty validity detail via `SF_GET_EW_VALIDITY_DTL`, standard premium from `VM_EW_PREM` (matched by variant, warranty type, retail-to-contract age window, and effective date range), actual premium, discount, CGST/SGST/IGST amounts, commission and GST on commission, sold-by user, policy status via `sf_ew_policy_status`, sold-from channel, payment type, facilitation charge, convenience fee, interest/EMI discount, bank basic cost (`order_capt_amt`), EMI tenure, EMI difference, old policy number/type for `EXI`/`SWI` warranty types (sub-queried from `DMSD_EW_SALE` ordered by contract date descending, offset 1), and employee MSPIN/name/designation from `GM_EMP`/`GM_DESG`. The outer query filters Set X by payment type and sold-from channel.
  - Set Y from `VT_EXTSAWA` (joined to `AM_DEALER_LOC`, filtered by contract date range) with the same column set; payment type for legacy records is simplified (only 'Offline DMS' or 'NA'); `Basic_Cost_bank` is NULL; the difference formula omits `order_capt_amt`; old policy number uses `COALESCE` to default to a comma placeholder. The outer query filters Set Y by payment type and sold-from channel.
- Step 6 - For **Conversions** (`P_REP_TYPE = 'U'`): build dynamic SQL producing 'Extended Warranty Conversion Details Report'. The query selects from `DMSD_EW_SALE` (joined to `MWAR_EXTE` and `AM_DEALER_LOC`, filtered to `EXTE_TRAN_TYPE IN ('U','X')`) joined on the conversion dealer fields (`EXTE_CONV_DEALER_MAP_CD`, `EXTE_CONV_LOC_CD`). Columns include original and conversion dealer codes/names, EW sale date, conversion date, model/variant detail looked up via `GM_VIN`/`GM_MOD`/`GM_VAR`, warranty type, differential premium (`exte_premium_recd`), discount, CGST/SGST/IGST on differential premium, differential commission and GST on commission, upgraded-by user, policy status, conversion-from channel, payment type, facilitation charge, convenience fee, interest/EMI discount, bank basic cost, EMI tenure, EMI difference, and employee MSPIN/name/designation from `GM_EMP`/`GM_DESG` (keyed on the conversion employee `EXTE_CONV_EMP_CD`). The outer query filters by payment type and conversion-from channel.
- Step 7 - For **Cancellations** (`P_REP_TYPE = 'C'`): build dynamic SQL producing 'Extended Warranty Cancellation Details Report'. The query UNIONs two detail sets:
  - Set X from `DMSD_EW_SALE` (joined to `MWAR_EXTE` and `AM_DEALER_LOC` via outer join, filtered to `EXTE_TRAN_TYPE = 'C'`) including region (falling back to a sub-query on `AM_DEALER_LOC` when `ALOC.REGION_CD` is NULL), dealer code, dealer name, policy number, EW sale date, cancellation date, VIN, VIN sale date, model/variant code and description (each from separate `GM_MOD`/`GM_VIN` and `GM_VAR`/`GM_VIN` sub-queries), warranty type, customer name (commas replaced), mileage, expiry date/mileage, premium, GST amounts on the cancellation fee (`GREATEST(premium × 0.1, 200) × GST_rate / 100`), commission and GST on commission, cancellation amount (`GREATEST(premium × 0.1, 200)`), remarks (line-break and comma characters stripped from `MWAR_EXTE.EXTE_REMARKS`), policy status, sold-from channel, payment type, facilitation charge, convenience fee, interest/EMI discount, bank basic cost, EMI tenure, EMI difference, and employee details from `GM_EMP`/`GM_DESG`. The outer query filters by payment type and sold-from channel.
  - Set Y from `VT_EXTSAWA` (joined to `AM_DEALER_LOC`, filtered by `EXTE_CANCEL_FLAG = 'Y'` and contract date range) with the same column set; cancellation amount is taken directly from `xw.exte_cancel_amt`; `Basic_Cost_bank` is NULL; payment type is simplified ('Offline DMS' or 'NA'). The outer query filters Set Y by payment type and sold-from channel.
- Step 8 - Store the assembled query string in `:TEST1` for diagnostic inspection.
- Step 9 - Call `VIEW_EXCEL_REP(lv_filename, v_query, 'entire_string')` to execute the query, write each row as a CSV line, and deliver the file to the user's browser.

---
**Decision Points**

DP-001

Condition:
`:CB_DUMMY.CB_LOC_DESC` is NULL.

TRUE:
Call `GENERAL.CHECK_NULL` for 'Location', navigate to the field, and abort.

FALSE:
Proceed to the next mandatory-field check.

DP-002

Condition:
`:CB_DUMMY.P_REP_TYPE` is NULL.

TRUE:
Call `GENERAL.CHECK_NULL` for 'Extended Warranty Status', navigate to the field, and abort.

FALSE:
Proceed to the next mandatory-field check.

DP-003

Condition:
`:CB_DUMMY.CONT_FROM_DATE` is NULL.

TRUE:
Call `GENERAL.CHECK_NULL` for 'Contract From Date', navigate to the field, and abort.

FALSE:
Proceed to the next mandatory-field check.

DP-004

Condition:
`:CB_DUMMY.CONT_TO_DATE` is NULL.

TRUE:
Call `GENERAL.CHECK_NULL` for 'Contract To Date', navigate to the field, and abort.

FALSE:
Proceed to the next mandatory-field check.

DP-005

Condition:
`:CB_DUMMY.BASE_MODEL_CD` is NULL.

TRUE:
Call `GENERAL.CHECK_NULL` for 'Model', navigate to the field, and abort.

FALSE:
Proceed to the next mandatory-field check.

DP-006

Condition:
`:CB_DUMMY.VARIANT_CD` is NULL.

TRUE:
Call `GENERAL.CHECK_NULL` for 'Variant', navigate to the field, and abort.

FALSE:
Proceed to the next mandatory-field check.

DP-007

Condition:
`:CB_DUMMY.EW_TYPE` is NULL.

TRUE:
Call `GENERAL.CHECK_NULL` for 'Extended Warranty Type', navigate to the field, and abort.

FALSE:
All mandatory fields are present; proceed to dealer-name resolution.

DP-008

Condition:
`:CB_DUMMY.CB_PARENT` equals `'All'`.

TRUE:
Set `:CB_DUMMY.CB_DEALER_NAME` to `'All Dealers (All locations)'` without a database lookup.

FALSE:
Query `AM_DEALER_LOC` for the specific dealer name and location description, restricted to non-terminated active dealers for the current principal.

DP-009

Condition:
`:CB_DUMMY.P_REP_TYPE` equals `'N'` (New Sales).

TRUE:
Build the New Sales CSV query (UNION of `DMSD_EW_SALE` new-sale records and `VT_EXTSAWA` records, with full financial, GST, EMI, old-policy, and employee columns).

FALSE:
Evaluate for Conversion (DP-010).

DP-010

Condition:
`:CB_DUMMY.P_REP_TYPE` equals `'U'` (Conversions).

TRUE:
Build the Conversion CSV query (`DMSD_EW_SALE` upgrade/transfer records with conversion dealer, differential premium, and EMI columns).

FALSE:
Evaluate for Cancellation (DP-011).

DP-011

Condition:
`:CB_DUMMY.P_REP_TYPE` equals `'C'` (Cancellations).

TRUE:
Build the Cancellation CSV query (UNION of `DMSD_EW_SALE` cancellation records and `VT_EXTSAWA` cancelled records, with cancellation fee, GST on cancellation fee, and remarks).

FALSE:
No query branch is entered; `VIEW_EXCEL_REP` is called with whatever `v_query` contains.

DP-012

Condition:
The warranty type (`exte_warr_type`) is `'EXI'` or `'SWI'` (upgrade product types) in the New Sales query for either `DMSD_EW_SALE` or `VT_EXTSAWA` records.

TRUE:
Sub-query `DMSD_EW_SALE` to retrieve the immediately preceding policy number and warranty type for the same VIN (ordered by contract date descending, OFFSET 1 FETCH NEXT 1 ROW ONLY) and include as `OLD_POLICY_NO`.

FALSE:
Output a blank/comma placeholder for `OLD_POLICY_NO`.

DP-013

Condition:
`online_sale_flag = 'Y'` AND `emi_flag = 'Y'`.

TRUE:
Classify payment type as `'EMI'`.

FALSE:
Evaluate further: if `online_sale_flag = 'Y'` and `emi_flag = 'N'` -> `'Online But Not EMI'`; if `online_sale_flag = 'N'` and `EXTE_PAY_MODE = 'O'` and `emi_flag = 'Y'` -> `'EMI'`; if `online_sale_flag = 'N'` and `EXTE_PAY_MODE = 'O'` and `emi_flag = 'N'` -> `'Online But Not EMI'`; if `online_sale_flag = 'N'` and `EXTE_PAY_MODE = 'C'` -> `'Offline DMS'`; otherwise -> `'NA'`.

DP-014

Condition:
`ew.emi_disc_val` is NOT NULL (EMI interest discount value is present) when computing the EMI difference for `DMSD_EW_SALE` records.

TRUE:
If `online_sale_flag = 'N'`: difference = `order_capt_amt + emi_disc_val - (EXTE_PREMIUM_RECD + GST amounts)`; if `online_sale_flag = 'Y'`: difference = `order_capt_amt + emi_disc_val + emi_disc_val - (EXTE_PREMIUM_RECD + GST amounts)`.

FALSE:
Output NULL for the difference column.

---
**Database Interactions**

- DB-001 - Read AM_DEALER_LOC - Reads data from AM_DEALER_LOC for lookup or validation.
- DB-002 - Read DUAL - Reads data from DUAL for lookup or validation.
- DB-003 - Read DATE - Reads data from DATE for lookup or validation.
- DB-004 - Select''Region,Dealer BANK - Accesses BANK via select''region,dealer operation.
- DB-005 - Read GM_MOD - Reads data from GM_MOD for lookup or validation.
- DB-006 - Read GM_VAR - Reads data from GM_VAR for lookup or validation.
- DB-007 - Read VM_EW_PREM - Reads data from VM_EW_PREM for lookup or validation.
- DB-008 - Read DMSD_EW_SALE - Reads data from DMSD_EW_SALE for lookup or validation.
- DB-009 - Read GM_EMP - Reads data from GM_EMP for lookup or validation.
- DB-010 - Select''Region,Ew BANK - Accesses BANK via select''region,ew operation.
- DB-011 - Select''Region,Ew DUAL - Accesses DUAL via select''region,ew operation.
- DB-012 - Select''Region,Dealer DUAL - Accesses DUAL via select''region,dealer operation.
**Business Rules**

- BR-001 - All seven search-criteria fields (Location, Extended Warranty Status, Contract From Date, Contract To Date, Model, Variant, Extended Warranty Type) must be non-NULL before the export may proceed.
- BR-002 - All dynamic SQL branches restrict results to the current principal via `ALOC.PRINCIPAL_MAP_CD = :GLOBAL.PRINCIPAL`.
- BR-003 - The dealer name displayed in the report header is resolved at export time from `AM_DEALER_LOC`, limited to dealers whose `msil_terminated_date` is NULL or in the future relative to SYSDATE.
- BR-004 - New-sale records from `DMSD_EW_SALE` use `EXTE_TRAN_TYPE = 'N'`; conversion records use `EXTE_TRAN_TYPE IN ('U', 'X')`; cancellation records from `DMSD_EW_SALE` use `EXTE_TRAN_TYPE = 'C'`; legacy cancellation records from `VT_EXTSAWA` are identified by `EXTE_CANCEL_FLAG = 'Y'`.
- BR-005 - For New Sales and Cancellations, results combine live DMS records from `DMSD_EW_SALE` and legacy/migrated records from `VT_EXTSAWA` via UNION ALL; Conversions draw exclusively from `DMSD_EW_SALE`.
- BR-006 - Commas are replaced with a space in model descriptions, variant descriptions, and customer name fields to prevent CSV column-boundary corruption; additionally, carriage returns (CHR(13)), line feeds (CHR(10)), ampersands (CHR(38)), and double-quote characters (CHR(34)) are stripped from customer name in New Sales records. Remarks fields have CHR(10), CHR(13), and commas replaced with a space.
- BR-007 - The standard premium from `VM_EW_PREM` is matched by variant code, warranty type, retail-to-contract age window (`prem_retl_timefrom`/`prem_retl_timeto`), and contract-date effective date range (`prem_from_date`/`prem_to_date`), and is included alongside the actual collected premium in New Sales exports to support pricing audits.
- BR-008 - For `EXI` and `SWI` warranty types in New Sales, the immediately preceding policy number and warranty type for the same VIN are retrieved from `DMSD_EW_SALE` (ordered by contract date descending, OFFSET 1 FETCH NEXT 1 ROW ONLY) and included as `OLD_POLICY_NO`; all other warranty types receive a blank/comma placeholder.
- BR-009 - Payment type classification evaluates `online_sale_flag` before `EXTE_PAY_MODE`: an online sale with `emi_flag = 'Y'` is always `'EMI'`; an online sale with `emi_flag = 'N'` is `'Online But Not EMI'`; an offline sale with `EXTE_PAY_MODE = 'O'` follows the same EMI/non-EMI logic; an offline sale with `EXTE_PAY_MODE = 'C'` is `'Offline DMS'`; otherwise `'NA'`. Legacy `VT_EXTSAWA` records use a simplified rule: `EXTE_PAY_MODE = 'C'` maps to `'Offline DMS'`, all others to `'NA'`.
- BR-010 - The cancellation fee in the Cancellation report is `GREATEST(premium × 0.1, 200)`; GST amounts on the cancellation fee are computed as `cancellation_fee × GST_rate / 100` for each of CGST, SGST, and IGST. For `VT_EXTSAWA` records the cancellation amount is taken directly from the stored `exte_cancel_amt` column.
- BR-011 - The Conversion report filters dealer location using the conversion dealer fields (`EXTE_CONV_DEALER_MAP_CD`, `EXTE_CONV_LOC_CD`, `EXTE_CONV_PARENT_GROUP`) rather than the original sale dealer fields, and employee details are keyed on the conversion employee (`EXTE_CONV_EMP_CD`) from `GM_EMP`/`GM_DESG`.
- BR-012 - The transaction date filter for `DMSD_EW_SALE` uses `EXTE_TRANSACTION_DATE`; the contract date filter for `VT_EXTSAWA` uses `EXTE_CONTRACT_DATE`; both apply the same inclusive lower bound and exclusive upper bound (`lv_to_date = CONT_TO_DATE + 1`).
- BR-013 - The assembled dynamic SQL string is stored in `:TEST1` before execution to allow diagnostic inspection of the generated query.

---
**Implementation Logic**

```plsql
PROCEDURE PROC_REP_XL_PMC1 IS
	v_query  VARCHAR2(32767);
	lv_filename  VARCHAR2(1000);
	lv_to_date date;
BEGIN

	IF :CB_DUMMY.CB_LOC_DESC IS NULL THEN
		general.check_null(:cb_dummy.CB_LOC_DESC,'Location');
		go_item('cb_dummy.CB_LOC_DESC');
	END IF;
	IF :CB_DUMMY.P_REP_TYPE IS NULL THEN
	  general.check_null(:cb_dummy.P_REP_TYPE,'Extended Warranty Status');
	  go_item('cb_dummy.P_REP_TYPE');
	END IF;
	IF :CB_DUMMY.CONT_FROM_DATE IS NULL THEN
	  general.check_null(:cb_dummy.CONT_FROM_DATE,'Contract From Date');
	  go_item('cb_dummy.CONT_FROM_DATE');
	END IF;
	IF :CB_DUMMY.CONT_TO_DATE IS NULL THEN
	  general.check_null(:cb_dummy.CONT_TO_DATE,'Contract To Date');
	  go_item('cb_dummy.CONT_TO_DATE');
	END IF;
	IF :CB_DUMMY.BASE_MODEL_CD IS NULL THEN
	  general.check_null(:cb_dummy.BASE_MODEL_CD,'Model');
	  go_item('cb_dummy.BASE_MODEL_CD');
	END IF;
	IF :CB_DUMMY.VARIANT_CD IS NULL THEN
	  general.check_null(:cb_dummy.VARIANT_CD,'Variant');
	  go_item('cb_dummy.VARIANT_CD');
	END IF;
	IF :CB_DUMMY.EW_TYPE IS NULL THEN
	  general.check_null(:cb_dummy.EW_TYPE,'Extended Warranty Type');
	  go_item('cb_dummy.EW_TYPE');
	END IF;

	BEGIN
		IF :CB_DUMMY.CB_PARENT = 'All' THEN
			:CB_DUMMY.CB_DEALER_NAME := 'All Dealers (All locations)';
		ELSE
			SELECT AM.DEALER_NAME||'( '||AM.LOC_DESC||' )'
			  INTO :CB_DUMMY.CB_DEALER_NAME
				FROM AM_DEALER_LOC AM
			 WHERE AM.PARENT_GROUP = decode(:CB_DUMMY.CB_PARENT,'All',AM.PARENT_GROUP,:CB_DUMMY.CB_PARENT)
				 AND AM.DEALER_MAP_CD = decode(:CB_DUMMY.CB_DEALER_MAP_CD,'All',AM.DEALER_MAP_CD,:CB_DUMMY.CB_DEALER_MAP_CD)
				 AND AM.LOC_CD = decode(:CB_DUMMY.CB_LOC_CD,'All',AM.LOC_CD,:CB_DUMMY.CB_LOC_CD)
				 AND nvl(msil_terminated_date, sysdate) >= sysdate
			 	and am.principal_map_cd=:global.principal;/*added by bhawana*/
		END IF;
	EXCEPTION
		WHEN OTHERS THEN
		null;
	END;

	lv_filename:=:global.userid||'_'||to_char(sysdate,'RRRRMMDDHH24MISS')||'.csv';

	lv_to_date := to_date(:CB_DUMMY.CONT_TO_DATE) + 1;

--IF :CB_DUMMY.CB_REPORT_TYPE = 'D' THEN
--EW.EXTE_WARR_TYPE||'',''||
--to_char(EW.EXTE_VALID_DATE,''MM/DD/RRRR'')||'',''||
--EW.EXTE_VALID_MILEAGE||'',''||
IF :CB_DUMMY.P_REP_TYPE = 'N' THEN
v_query := 'SELECT ''Extended Warranty Sale Details Report'' entire_string FROM DUAL
						UNION ALL
						SELECT ''Dealer Name & Location:  '' ||'''||:CB_DUMMY.CB_DEALER_NAME||''' entire_string FROM DUAL
						UNION ALL
						SELECT ''From Date:  '' ||'''||TO_CHAR(:CB_DUMMY.CONT_FROM_DATE,'MM/DD/RRRR')||'''|| ''    To Date:  '' ||'''||TO_CHAR(:CB_DUMMY.CONT_TO_DATE,'MM/DD/RRRR')||''' ||CHR(10)||CHR(10) entire_string FROM DUAL
						UNION ALL
						SELECT''Region,Dealer Code,Dealer Name,Location,Policy No,EW Sale Date,VIN,VIN Sale Date,Model Code,Model desc,Variant Code,Variant Desc,Customer Name,Mileage,Warranty Type,Expiry Date,Expiry Mileage,Actual Premium Amount, Premium Amount,Discount Amount,CGST Amount,SGST Amount,IGST Amount, Commission Amount,CGST Commission,SGST Commission,IGST Commission,Sold By,Status,Sold From,Payment type, Facilitation charge,Convenience charges discount,Interest charges discount,Basic_cost(from bank),EMI tenure,Difference, Old Policy No, Old Policy Type, MSPIN, Emp Name, Emp Desg '' entire_string FROM DUAL
								 UNION ALL
			select X.Region                ||'',''||
              X.Dealer_Code          ||'',''||
              X.Dealer_Name_Location ||'',''||
              X.Policy_No           ||'',''||
              X.EW_Sale_Date        ||'',''||
              X.VIN                 ||'',''||
              X.VIN_Sale_Date       ||'',''||
              X.Model_Code          ||'',''||
              x.Model_desc           ||'',''||
              X.Variant_Code         ||'',''||
              X.Variant_Desc          ||'',''||
              X.Customer_Name        ||'',''||
              X.Mileage              ||'',''||
              X.EXTE_POLICY_NO         ||'',''||
              x.prem_amount               ||'',''||
              X.EXTE_POLICY_PREMIUM       ||'',''||
              X.DISCOUNT_AMOUNT           ||'',''||
              X.EXTE_PREM_CGST_AMT        ||'',''||
              X.EXTE_PREM_SGST_AMT        ||'',''||
              X.EXTE_PREM_IGST_AMT       ||'',''||
              X.EXTE_COMMISION_AMT       ||'',''||
              X.EXTE_PREM_COMM_CGST      ||'',''||
              X.EXTE_PREM_COMM_SGST      ||'',''||
              X.EXTE_PREM_COMM_IGST      ||'',''||
              X.EXTE_CREATED_BY          ||'',''||
              X.ew_policy_status          ||'',''||
              X.sold_from                 ||'',''||
              X.payment_type              ||'',''||
              X.FACILITATION_CHG          ||'',''||
              X.CONVENIENCE_FEE           ||'',''||
              X.INTEREST_AMT              ||'',''||
              X.Basic_Cost_bank            ||'',''||
              X.TENURE_DURATION           ||'',''||
              x.difference                ||'',''||
              X.OLD_POLICY_NO             ||'',''||
              x.bb
              from( SELECT /*+ index (ALOC XPKAM_DEALER_LOC)*/	ALOC.region_cd Region,
								      ALOC.dealer_category||''-''||EW.EXTE_POLICY_DELR||''-''||EW.EXTE_POLICY_FOR||''-''||decode(EW.EXTE_POLICY_SOLD_FROM,''SH'',''01'',EW.EXTE_POLICY_OUTLET)Dealer_Code,
      								nvl(sf_get_dlr_name_loc (EW.EXTE_DEALER_MAP_CD,EW.EXTE_LOC_CD,EW.EXTE_POLICY_DELR,'''||:global.principal||'''),'','')Dealer_Name_Location,
								      EW.EXTE_POLICY_NO Policy_No,
								      to_char(EW.EXTE_CONTRACT_DATE,''DD-MM-YYYY'')EW_Sale_Date,
								      EW.EXTE_VIN_NO VIN,
								      to_char(EW.EXTE_RETLSALE_DT,''DD-MM-YYYY'') VIN_Sale_Date,
								      XW.EXTE_MODL_CODE Model_Code,
								      (SELECT replace(gm.model_desc, '','', '' '') FROM gm_mod gm WHERE gm.model_cd = xw.exte_modl_code 
								      and gm.principal_map_cd='''||:global.principal||''') Model_desc,
								      XW.EXTE_VARIANT_CD Variant_Code ,
								      (SELECT replace(gv.variant_desc, '','', '' '') FROM gm_var gv WHERE gv.variant_cd = xw.exte_variant_cd 
								      and gv.principal_map_cd='''||:global.principal||''') Variant_Desc,
								      replace(replace(replace( replace( replace((EW.EXTE_CUST_NAME),'','',''''), chr(13),''''), chr(38),''''),chr(10),''''),chr(34),'''') Customer_Name,
								      EW.EXTE_CONTRACT_MILEAGE Mileage,
											SF_GET_EW_VALIDITY_DTL(EW.EXTE_POLICY_NO,'''||:CB_DUMMY.P_REP_TYPE||''') EXTE_POLICY_NO,
											(SELECT m.prem_amount                   
                  FROM vm_ew_prem m
                WHERE m.prem_variant_cd = XW.EXTE_VARIANT_CD
                  AND m.prem_extewar_type = XW.EXTE_WARR_TYPE 
                  AND ((TO_DATE(XW.exte_contract_date, ''DD-MON-YYYY'') - TO_DATE(XW.exte_retlsale_dt, ''DD-MON-YYYY'')) BETWEEN m.prem_retl_timefrom AND m.prem_retl_timeto)
                  AND TRUNC(XW.exte_contract_date) BETWEEN m.prem_from_date AND NVL(m.prem_to_date, TRUNC(XW.exte_contract_date))
                  AND m.principal_map_cd = '''||:global.principal||''')prem_amount,
								      EW.EXTE_POLICY_PREMIUM EXTE_POLICY_PREMIUM,
								      nvl(xw.discount_amt,0) DISCOUNT_AMOUNT,
								      nvl(EW.EXTE_PREM_CGST_AMT,0) EXTE_PREM_CGST_AMT,
								      nvl(EW.EXTE_PREM_SGST_AMT,0) EXTE_PREM_SGST_AMT,
								      nvl(EW.EXTE_PREM_IGST_AMT,0) EXTE_PREM_IGST_AMT,
								      NVL(EW.EXTE_COMMISION_AMT,0) EXTE_COMMISION_AMT,
								      NVL(EW.EXTE_PREM_COMM_CGST,0) EXTE_PREM_COMM_CGST,
								      nvl(EW.EXTE_PREM_COMM_SGST,0) EXTE_PREM_COMM_SGST,
								      nvl(EW.EXTE_PREM_COMM_IGST,0) EXTE_PREM_COMM_IGST,
								      XW.EXTE_CREATED_BY EXTE_CREATED_BY,
      								sf_ew_policy_status(EW.EXTE_POLICY_NO) ew_policy_status,
      								DECODE(ew.online_sale_flag,''Y'',''WEB'',decode(xw.EXTE_POLICY_SOLD_FROM,''WS'',''Workshop'',''SH'',''Showroom'', ''WEB'',''Website'') ) sold_from,
                      (case when NVL(ew.online_sale_flag,''N'')=''Y'' AND NVL(ew.emi_flag,''N'') = ''Y'' THEN
                      ''EMI''
                     WHEN NVL(ew.online_sale_flag,''N'')=''Y'' AND NVL(ew.emi_flag,''N'') =''N'' THEN
                      ''Online But Not EMI''
                     WHEN NVL(ew.online_sale_flag,''N'')=''N'' AND NVL(ew.EXTE_PAY_MODE,''C'') = ''O'' AND NVL(ew.emi_flag,''N'') = ''Y'' THEN 
                       ''EMI''
                     WHEN NVL(ew.online_sale_flag,''N'')=''N'' AND NVL(ew.EXTE_PAY_MODE,''C'') = ''O'' AND NVL(ew.emi_flag,''N'') = ''N'' THEN
                       ''Online But Not EMI''
                     WHEN NVL(ew.online_sale_flag,''N'')=''N'' AND NVL(ew.EXTE_PAY_MODE,''C'') = ''C'' THEN 
                       ''Offline DMS'' 
                     ELSE
                        ''NA''
                    END ) payment_type,
                      EW.FACILITATION_CHG   FACILITATION_CHG ,
                      EW.CONVENIENCE_FEE     CONVENIENCE_FEE,
                      EW.emi_disc_val        INTEREST_AMT,
                      ew.exte_policy_premium policy_premium,
                      XW.TENURE_DURATION     TENURE_DURATION,
                      NVL(ew.discount_amt,0) discount_amt,
                      ew.order_capt_amt       Basic_Cost_bank,
                      (CASE WHEN ew.emi_disc_val IS NOT NULL THEN
                   (CASE  WHEN nvl(ew.online_sale_flag,''N'') =''N'' 
                                THEN NVL(ew.order_capt_amt,0)+NVL(ew.emi_disc_val,0)-(((NVL(ew.EXTE_PREMIUM_RECD, 0) +
                       NVL(ew.EXTE_PREM_IGST_AMT, 0) +
                       NVL(ew.EXTE_PREM_SGST_AMT, 0) +
                       NVL(ew.EXTE_PREM_CGST_AMT, 0))))
                                ELSE (NVL(ew.order_capt_amt,0)+NVL(ew.emi_disc_val,0)+NVL(ew.emi_disc_val,0)-((NVL(ew.EXTE_PREMIUM_RECD, 0) +
                       NVL(ew.EXTE_PREM_IGST_AMT, 0) +
                       NVL(ew.EXTE_PREM_SGST_AMT, 0) +
                       NVL(ew.EXTE_PREM_CGST_AMT, 0))))
                                  END)
                                  ELSE
                                    NULL
                                     END) difference,
                                    CASE WHEN ew.exte_warr_type IN (''EXI'',''SWI'')  THEN
                   (SELECT /*+USE_INVISIBLE_INDEXES INDEX(AA IDX_DMSD_EW_SALE_VIN)*/ aa.exte_policy_no|| '','' ||aa.exte_warr_type
                                        FROM DMSD_EW_SALE AA
                                        where AA.exte_vin_no = ew.exte_vin_no
                                        ORDER BY AA.exte_contract_date DESC
                                        OFFSET 1 ROW FETCH NEXT 1 ROW ONLY)
                                        ELSE ''  , '' END OLD_POLICY_NO
                                        
                                          ,(select gm.mspin|| '','' ||gm.first_name|| '','' ||a.desg_desc
                                            from gm_emp gm,gm_desg a
                                            where a.principal_map_cd='''||:global.principal||'''
                                            and a.desg_cd=gm.emp_desg_cd
                                            and gm.dealer_map_cd=ew.exte_dealer_map_cd
                                            and gm.emp_cd=ew.exte_emp_cd
                                             )bb
                                        
								FROM  dmsd_ew_sale EW,
								      MWAR_EXTE XW,
								      AM_DEALER_LOC ALOC
								WHERE ew.exte_policy_no=xw.exte_policy_no
									AND	ew.exte_transaction_date >= '''||:CB_DUMMY.CONT_FROM_DATE||'''
								  AND ew.exte_transaction_date < '''||lv_to_date||'''
								  and EW.EXTE_TRAN_TYPE =''N''
								  AND ALOC.PARENT_GROUP = EW.EXTE_PARENT_GROUP
								  AND ALOC.DEALER_MAP_CD = EW.EXTE_DEALER_MAP_CD
								  AND ALOC.LOC_CD = EW.EXTE_LOC_CD
								  AND ALOC.PRINCIPAL_MAP_CD='''||:GLOBAL.PRINCIPAL||'''
									AND ALOC.REGION_CD = decode('''||:CB_DUMMY.CB_REGION||''',''All'',ALOC.REGION_CD,'''||:CB_DUMMY.CB_REGION||''')
									AND EW.EXTE_PARENT_GROUP = decode('''||:CB_DUMMY.CB_PARENT||''',''All'',EW.EXTE_PARENT_GROUP,'''||:CB_DUMMY.CB_PARENT||''')
								  AND EW.EXTE_DEALER_MAP_CD = decode('''||:CB_DUMMY.CB_DEALER_MAP_CD||''',''All'',EW.EXTE_DEALER_MAP_CD,'''||:CB_DUMMY.CB_DEALER_MAP_CD||''')
								  AND EW.EXTE_LOC_CD = decode('''||:CB_DUMMY.CB_LOC_CD||''',''All'',EW.EXTE_LOC_CD,'''||:CB_DUMMY.CB_LOC_CD||''')
								  AND XW.EXTE_MODL_CODE = decode('''||:CB_DUMMY.BASE_MODEL_CD||''',''All'',XW.EXTE_MODL_CODE,'''||:CB_DUMMY.BASE_MODEL_CD||''')
								  AND XW.EXTE_VARIANT_CD = decode('''||:CB_DUMMY.VARIANT_CD||''',''All'',XW.EXTE_VARIANT_CD,'''||:CB_DUMMY.VARIANT_CD||''')
								  AND EW.EXTE_WARR_TYPE = decode('''||:CB_DUMMY.EW_TYPE||''',''All'',EW.EXTE_WARR_TYPE,'''||:CB_DUMMY.EW_TYPE||''')
								  )X
								  where 	 X.payment_type = DECODE('''||:CB_DUMMY.CB_PAYMENT_TYPE||''',''A'',X.payment_type,''OD'',''Offline DMS'', ''E'', ''EMI'', ''OE'',''Online But Not EMI'', '''||:CB_DUMMY.CB_PAYMENT_TYPE||''')
								  AND X.sold_from = decode('''||:CB_DUMMY.CB_SOLD_FROM||''',''A'',X.sold_from,''WEB'',''WEB'', ''WS'', ''Workshop'', ''SH'',''Showroom'','''||:CB_DUMMY.CB_SOLD_FROM||''')
								  
								  UNION ALL
								  select Y.Region                ||'',''||
              Y.Dealer_Code          ||'',''||
              Y.Dealer_Name_Location ||'',''||
              Y.Policy_No           ||'',''||
              Y.EW_Sale_Date        ||'',''||
              Y.VIN                 ||'',''||
              Y.VIN_Sale_Date       ||'',''||
              Y.Model_Code          ||'',''||
              Y.Model_desc           ||'',''||
              Y.Variant_Code         ||'',''||
              Y.Variant_Desc          ||'',''||
              Y.Customer_Name        ||'',''||
              Y.Mileage              ||'',''||
              Y.EXTE_POLICY_NO         ||'',''||
              Y.prem_amount               ||'',''||
              Y.EXTE_POLICY_PREMIUM       ||'',''||
              Y.DISCOUNT_AMOUNT           ||'',''||
              Y.EXTE_PREM_CGST_AMT        ||'',''||
              Y.EXTE_PREM_SGST_AMT        ||'',''||
              Y.EXTE_PREM_IGST_AMT       ||'',''||
              Y.EXTE_COMMISION_AMT       ||'',''||
              Y.EXTE_PREM_COMM_CGST      ||'',''||
              Y.EXTE_PREM_COMM_SGST      ||'',''||
              Y.EXTE_PREM_COMM_IGST      ||'',''||
              Y.EXTE_CREATED_BY          ||'',''||
              Y.ew_policy_status          ||'',''||
              Y.sold_from                 ||'',''||
              Y.payment_type              ||'',''||
              Y.FACILITATION_CHG          ||'',''||
              Y.CONVENIENCE_FEE           ||'',''||
              Y.INTEREST_AMT              ||'',''||
              Y.Basic_Cost_bank            ||'',''||
              Y.TENURE_DURATION           ||'',''||
              Y.difference                 ||'',''||
              COALESCE(Y.OLD_POLICY_NO, '','') ||'',''||
              y.cc             
              from(SELECT ALOC.region_cd Region,
                      ALOC.dealer_category||''-''||xw.EXTE_POLICY_DELR||''-''||xw.EXTE_POLICY_FOR||''-''||decode(xw.EXTE_POLICY_SOLD_FROM,''SH'',''01'',xw.EXTE_POLICY_OUTLET)Dealer_Code,
                      nvl(sf_get_dlr_name_loc (xw.EXTE_DEALER_MAP_CD,xw.EXTE_LOC_CD,xw.EXTE_POLICY_DELR,1),'','')Dealer_Name_Location,
                      xw.EXTE_POLICY_NO Policy_No,
                      to_char(xw.EXTE_CONTRACT_DATE,''DD-MM-YYYY'')EW_Sale_Date,
                      xw.EXTE_VIN_NO VIN,
                      to_char(xw.EXTE_RETLSALE_DT,''DD-MM-YYYY'') VIN_Sale_Date,
                      XW.EXTE_MODL_CODE Model_Code,
                      (SELECT replace(gm.model_desc, '','', '' '') FROM gm_mod gm WHERE gm.model_cd = xw.exte_modl_code 
                      and gm.principal_map_cd='''||:GLOBAL.PRINCIPAL||''') Model_desc,
                      XW.EXTE_VARIANT_CD Variant_Code ,
                      (SELECT replace(gv.variant_desc, '','', '' '') FROM gm_var gv WHERE gv.variant_cd = xw.exte_variant_cd 
                      and gv.principal_map_cd='''||:GLOBAL.PRINCIPAL||''') Variant_Desc,
                      replace(replace(replace( replace( replace((xw.EXTE_CUST_NAME),'','',''''), chr(13),''''), chr(38),''''),chr(10),''''),chr(34),'''') Customer_Name,
                      xw.EXTE_CONTRACT_MILEAGE Mileage,
                      SF_GET_EW_VALIDITY_DTL(xw.EXTE_POLICY_NO,'''||:CB_DUMMY.P_REP_TYPE||''') EXTE_POLICY_NO,
                      (SELECT m.prem_amount                   
                  FROM vm_ew_prem m
                WHERE m.prem_variant_cd = XW.EXTE_VARIANT_CD
                  AND m.prem_extewar_type = XW.EXTE_WARR_TYPE 
                  AND ((TO_DATE(XW.exte_contract_date, ''DD-MON-YYYY'') - TO_DATE(XW.exte_retlsale_dt, ''DD-MON-YYYY'')) BETWEEN m.prem_retl_timefrom AND m.prem_retl_timeto)
                  AND TRUNC(XW.exte_contract_date) BETWEEN m.prem_from_date AND NVL(m.prem_to_date, TRUNC(XW.exte_contract_date))
                  AND m.principal_map_cd = '''||:GLOBAL.PRINCIPAL||''')prem_amount,
                      xw.EXTE_PREMIUM EXTE_POLICY_PREMIUM,
                      nvl(xw.EXTE_PREMIUM_DISCOUNT,0) DISCOUNT_AMOUNT,
                      nvl(xw.EXTE_PREM_CGST_AMT,0) EXTE_PREM_CGST_AMT,
                      nvl(xw.EXTE_PREM_SGST_AMT,0) EXTE_PREM_SGST_AMT,
                      nvl(xw.EXTE_PREM_IGST_AMT,0) EXTE_PREM_IGST_AMT,
                      NVL(xw.exte_prem_dlr_comm,0) EXTE_COMMISION_AMT,
                      NVL(xw.EXTE_PREM_COMM_CGST,0) EXTE_PREM_COMM_CGST,
                      nvl(xw.EXTE_PREM_COMM_SGST,0) EXTE_PREM_COMM_SGST,
                      nvl(xw.EXTE_PREM_COMM_IGST,0) EXTE_PREM_COMM_IGST,
                      XW.EXTE_CREATED_BY EXTE_CREATED_BY,
                      sf_ew_policy_status(xw.EXTE_POLICY_NO) ew_policy_status,
                      decode(xw.EXTE_POLICY_SOLD_FROM,''WS'',''Workshop'',''SH'',''Showroom'', ''WEB'',''Website'')  sold_from,
                      (case when NVL(xw.online_sale_flag,''N'')=''N'' AND NVL(xw.EXTE_PAY_MODE,''C'') = ''C'' THEN 
                       ''Offline DMS'' 
                     ELSE
                        ''NA''
                    END ) payment_type,
                      xw.FACILITATION_AMT   FACILITATION_CHG ,
                      xw.CONVENIENCE_AMT     CONVENIENCE_FEE,
                      xw.emi_disc_val        INTEREST_AMT,
                      xw.EXTE_PREMIUM policy_premium,
                      XW.TENURE_DURATION     TENURE_DURATION,
                      NVL(xw.EXTE_PREMIUM_DISCOUNT,0) discount_amt,
                      null      Basic_Cost_bank,
                      (CASE WHEN xw.emi_disc_val IS NOT NULL THEN
                   (CASE  WHEN nvl(xw.online_sale_flag,''N'') =''N'' 
                                THEN NVL(xw.emi_disc_val,0)-(((NVL(xw.EXTE_PREMIUM_RCVD, 0) +
                       NVL(xw.EXTE_PREM_IGST_AMT, 0) +
                       NVL(xw.EXTE_PREM_SGST_AMT, 0) +
                       NVL(xw.EXTE_PREM_CGST_AMT, 0))))
                                ELSE (NVL(xw.emi_disc_val,0)+NVL(xw.emi_disc_val,0)-((NVL(xw.EXTE_PREMIUM_RCVD, 0) +
                       NVL(xw.EXTE_PREM_IGST_AMT, 0) +
                       NVL(xw.EXTE_PREM_SGST_AMT, 0) +
                       NVL(xw.EXTE_PREM_CGST_AMT, 0))))
                                  END)
                                  ELSE
                                    NULL
                                     END) difference,
                                  CASE WHEN xw.exte_warr_type IN (''EXI'',''SWI'')  THEN
                   (SELECT /*+USE_INVISIBLE_INDEXES INDEX(aa IDX_DMSD_EW_SALE_VIN)*/ nvl(aa.exte_policy_no,'' '')|| '','' ||nvl(aa.exte_warr_type,'' '')
                                        FROM DMSD_EW_SALE aa
                                        where aa.exte_vin_no = xw.exte_vin_no
                                        ORDER BY aa.exte_contract_date DESC
                                        OFFSET 1 ROW FETCH NEXT 1 ROW ONLY)
                                        ELSE '' ,  '' END OLD_POLICY_NO,
                                        (select gm.mspin|| '','' ||gm.first_name|| '','' ||a.desg_desc
                                            from gm_emp gm,gm_desg a
                                            where a.principal_map_cd='''||:global.principal||'''
                                            and a.desg_cd=gm.emp_desg_cd
                                            and gm.dealer_map_cd=xw.exte_dealer_map_cd
                                            and gm.emp_cd=xw.exte_emp_cd
                                             )cc
                FROM  vt_extsawa XW,
                      AM_DEALER_LOC ALOC
                WHERE xw.EXTE_CONTRACT_DATE >= '''||:CB_DUMMY.CONT_FROM_DATE||'''
                  AND xw.EXTE_CONTRACT_DATE < '''||lv_to_date||'''
                  AND ALOC.PARENT_GROUP = xw.EXTE_PARENT_GROUP
                  AND ALOC.DEALER_MAP_CD = xw.EXTE_DEALER_MAP_CD
                  AND ALOC.LOC_CD = xw.EXTE_LOC_CD
                  AND ALOC.PRINCIPAL_MAP_CD='''||:GLOBAL.PRINCIPAL||'''
									AND ALOC.REGION_CD = decode('''||:CB_DUMMY.CB_REGION||''',''All'',ALOC.REGION_CD,'''||:CB_DUMMY.CB_REGION||''')
									AND xw.EXTE_PARENT_GROUP = decode('''||:CB_DUMMY.CB_PARENT||''',''All'',xw.EXTE_PARENT_GROUP,'''||:CB_DUMMY.CB_PARENT||''')
								  AND xw.EXTE_DEALER_MAP_CD = decode('''||:CB_DUMMY.CB_DEALER_MAP_CD||''',''All'',xw.EXTE_DEALER_MAP_CD,'''||:CB_DUMMY.CB_DEALER_MAP_CD||''')
								  AND xw.EXTE_LOC_CD = decode('''||:CB_DUMMY.CB_LOC_CD||''',''All'',xw.EXTE_LOC_CD,'''||:CB_DUMMY.CB_LOC_CD||''')
								  AND XW.EXTE_MODL_CODE = decode('''||:CB_DUMMY.BASE_MODEL_CD||''',''All'',XW.EXTE_MODL_CODE,'''||:CB_DUMMY.BASE_MODEL_CD||''')
								  AND XW.EXTE_VARIANT_CD = decode('''||:CB_DUMMY.VARIANT_CD||''',''All'',XW.EXTE_VARIANT_CD,'''||:CB_DUMMY.VARIANT_CD||''')
								  AND xw.EXTE_WARR_TYPE = decode('''||:CB_DUMMY.EW_TYPE||''',''All'',xw.EXTE_WARR_TYPE,'''||:CB_DUMMY.EW_TYPE||''')
								  )Y
								  where 	 Y.payment_type = DECODE('''||:CB_DUMMY.CB_PAYMENT_TYPE||''',''A'',Y.payment_type,''OD'',''Offline DMS'', ''E'', ''EMI'', ''OE'',''Online But Not EMI'', '''||:CB_DUMMY.CB_PAYMENT_TYPE||''')
								  AND Y.sold_from = decode('''||:CB_DUMMY.CB_SOLD_FROM||''',''A'',Y.sold_from,''WEB'',''WEB'', ''WS'', ''Workshop'', ''SH'',''Showroom'','''||:CB_DUMMY.CB_SOLD_FROM||''')
								  ';
--AND nvl(EXTE_CANCEL_FLAG,''N'') = ''N'' -- As Diss. with Mr. Anoop all EW show in report

ELSIF :CB_DUMMY.P_REP_TYPE = 'U' THEN
v_query := 'SELECT ''Extended Warranty Conversion Details Report'' entire_string FROM DUAL
						UNION ALL
						SELECT ''Dealer Name & Location:  '' ||'''||:CB_DUMMY.CB_DEALER_NAME||''' entire_string FROM DUAL
						UNION ALL
						SELECT ''From Date:  '' ||'''||TO_CHAR(:CB_DUMMY.CONT_FROM_DATE,'MM/DD/RRRR')||'''|| ''    To Date:  '' ||'''||TO_CHAR(:CB_DUMMY.CONT_TO_DATE,'MM/DD/RRRR')||''' ||CHR(10)||CHR(10) entire_string FROM DUAL
						UNION ALL
						SELECT''Region,EW Sale Dlr Code,EW Sale Dlr Name,Location,Conv. Dealer Code,Conv. Dealer Name,Conv. Location,Policy No,EW Sale Date,Conv. Date,VIN,VIN Sale Date,Model Code,Model desc,Variant Code,Variant Desc,Warranty Type,Customer Name,Mileage,Expiry Date,Expiry Mileage,Diff. Premium Amount,Discount Amount,CGST Diff Premium,SGST Diff Premium, IGST Diff Premium,Diff. Comm. Amount,CGST Commission,SGST Commission,IGST Commission,Upgraded By,Status,Conversion From,Payment type, Facilitation charge,Convenience charges discount,Interest charges discount,Basic_cost(from bank),EMI Tenure,Difference,MSPIN,Emp Name,Emp Desg'' entire_string FROM DUAL
								 UNION ALL
		 	select X.Region                ||'',''||
              X.Dealer_Code          ||'',''||
              X.Dealer_Name_Location ||'',''||
              Conv_Dealer_Code       ||'',''||
              Conv_Dealer_Name       ||'',''||
              X.Policy_No            ||'',''||
              X.EW_Sale_Date         ||'',''||
              X.Conv_Date            ||'',''||
              X.VIN                  ||'',''||
              X.VIN_Sale_Date        ||'',''||
              X.Model_Code_desc      ||'',''||
              X.Varient_cd_desc      ||'',''||
              X.Warranty_Type        ||'',''||
              X.Customer_Name        ||'',''||
              X.Mileage              ||'',''||
              X.Expiry_Date          ||'',''||
              X.Expiry_Mileage       ||'',''||
              X.Diff_Premium_Amount   ||'',''||
              X.DISCOUNT_AMOUNT       ||'',''||
              X.CGST_Diff_Premium     ||'',''||
              X.SGST_Diff_Premium     ||'',''||
              X.IGST_Diff_Premium     ||'',''||
              X.Diff_Comm_Amount      ||'',''||
              X.CGST_Commission       ||'',''||
              X.SGST_Commission       ||'',''||
              X.IGST_Commission        ||'',''||
              X.Upgraded_By             ||'',''||
              X.Status                ||'',''||
              X.Conversion_From       ||'',''||
              X.Payment_type           ||'',''||
              X.Facilitation_charge     ||'',''||
              X.Convenience_charges_discount  ||'',''||
              X.Interest_charges_discount      ||'',''||
              X.Basic_Cost_bank                    ||'',''||
              X.EMI_Tenure                     ||'',''||
              X.Difference                     ||'',''||
              x.bb
              from(SELECT  /*+ index (EW MWAR_EXTE_MK9)*/	ALOC.region_cd Region,
											ALOC.dealer_category||''-''||EW.EXTE_POLICY_DELR||''-''||EW.EXTE_POLICY_FOR||''-''||decode(EW.EXTE_POLICY_SOLD_FROM,''SH'',''01'',EW.EXTE_POLICY_OUTLET) Dealer_Code,
      								nvl(sf_get_dlr_name_loc (EW.EXTE_DEALER_MAP_CD,EW.EXTE_LOC_CD,EW.EXTE_POLICY_DELR,'''||:global.principal||'''),'','')Dealer_Name_Location,
      								ALOC.dealer_category||''-''||EW.EXTE_CONV_DELR||''-''||EW.EXTE_CONV_FOR||''-''||decode(EW.EXTE_CONV_FROM,''SH'',''01'',EW.EXTE_CONV_OUTLET)Conv_Dealer_Code,
      								nvl(sf_get_dlr_name_loc (EW.EXTE_CONV_DEALER_MAP_CD,EW.EXTE_CONV_LOC_CD,EW.EXTE_CONV_DELR,'''||:global.principal||'''),'','')Conv_Dealer_Name,
      								EW.EXTE_POLICY_NO Policy_No,
      								to_char(EW.EXTE_CONTRACT_DATE,''DD-MM-YYYY'')EW_Sale_Date,
								      to_char(EW.EXTE_CONV_DATE,''DD-MM-YYYY'') Conv_Date,
								      EW.EXTE_VIN_NO VIN,
								      to_char(EW.EXTE_RETLSALE_DT,''DD-MM-YYYY'') VIN_Sale_Date,
								      (SELECT gv.model_cd||'',''||replace(gm.model_desc, '','', '' '') 
								         FROM gm_mod gm, gm_vin gv 
								        WHERE gm.model_cd = gv.model_Cd 
								          AND gv.vin = EW.EXTE_VIN_NO 
								          and gm.principal_map_cd='''||:global.principal||'''
								          and gm.principal_map_cd=gv.principal_map_cd) Model_Code_desc,							      
								      (SELECT gvn.variant_cd||'',''||replace(gvr.variant_desc, '','', '' '') 
								         FROM gm_var gvr, gm_vin gvn 
								        WHERE gvr.variant_cd = gvn.variant_cd 
								          AND gvn.vin = EW.EXTE_VIN_NO
								          and gvr.principal_map_cd='''||:global.principal||'''
								          and gvr.principal_map_cd=gvn.principal_map_cd) Varient_cd_desc,
								      EW.EXTE_WARR_TYPE Warranty_Type,
								      replace(EW.EXTE_CUST_NAME, '','', '' '') Customer_Name,
								      EW.EXTE_CONV_MILEAGE Mileage,
								      to_char(EW.EXTE_VALID_DATE,''DD-MM-YYYY'') Expiry_Date,
								      EW.EXTE_VALID_MILEAGE Expiry_Mileage,
								      EW.exte_premium_recd Diff_Premium_Amount,
								      nvl(xw.discount_amt,0) DISCOUNT_AMOUNT,
								      nvl(EW.EXTE_PREM_CGST_AMT,0) CGST_Diff_Premium,
								      nvl(EW.EXTE_PREM_SGST_AMT,0) SGST_Diff_Premium,
								      nvl(EW.EXTE_PREM_IGST_AMT,0) IGST_Diff_Premium,
								      NVL(EW.EXTE_COMMISION_AMT,0)Diff_Comm_Amount,
								      NVL(EW.EXTE_PREM_COMM_CGST,0) CGST_Commission,
								      NVL(EW.EXTE_PREM_COMM_SGST,0) SGST_Commission,
								      NVL(EW.EXTE_PREM_COMM_IGST,0)IGST_Commission,
								      XW.EXTE_MODIFIED_BY Upgraded_By,
								      sf_ew_policy_status(EW.EXTE_POLICY_NO) Status,
      								DECODE(ew.online_sale_flag,''Y'',''Web'',decode(XW.EXTE_CONV_FROM,''WEB'',''WEB'',''WS'',''Workshop'',''SH'',''Showroom'') ) Conversion_From,
                      (case when NVL(ew.online_sale_flag,''N'')=''Y'' AND NVL(ew.emi_flag,''N'') = ''Y'' THEN
                      ''EMI''
                     WHEN NVL(ew.online_sale_flag,''N'')=''Y'' AND NVL(ew.emi_flag,''N'') =''N'' THEN
                      ''Online But Not EMI''
                     WHEN NVL(ew.online_sale_flag,''N'')=''N'' AND NVL(ew.EXTE_PAY_MODE,''C'') = ''O'' AND NVL(ew.emi_flag,''N'') = ''Y'' THEN 
                       ''EMI''
                     WHEN NVL(ew.online_sale_flag,''N'')=''N'' AND NVL(ew.EXTE_PAY_MODE,''C'') = ''O'' AND NVL(ew.emi_flag,''N'') = ''N'' THEN
                       ''Online But Not EMI''
                     WHEN NVL(ew.online_sale_flag,''N'')=''N'' AND NVL(ew.EXTE_PAY_MODE,''C'') = ''C'' THEN 
                       ''Offline DMS'' 
                     ELSE
                        ''NA''
                    END )   Payment_type,
                      EW.FACILITATION_CHG    Facilitation_charge,
                      EW.CONVENIENCE_FEE     Convenience_charges_discount,
                      EW.emi_disc_val        Interest_charges_discount,
                      ew.order_capt_amt       Basic_Cost_bank,
                      XW.TENURE_DURATION     EMI_Tenure,
                      (CASE WHEN ew.emi_disc_val IS NOT NULL THEN
                   (CASE  WHEN nvl(ew.online_sale_flag,''N'') =''N'' 
                                THEN NVL(ew.order_capt_amt,0)+NVL(ew.emi_disc_val,0)-(((NVL(ew.EXTE_PREMIUM_RECD, 0) +
                       NVL(ew.EXTE_PREM_IGST_AMT, 0) +
                       NVL(ew.EXTE_PREM_SGST_AMT, 0) +
                       NVL(ew.EXTE_PREM_CGST_AMT, 0))))
                                ELSE (NVL(ew.order_capt_amt,0)+NVL(ew.emi_disc_val,0)+NVL(ew.emi_disc_val,0)-((NVL(ew.EXTE_PREMIUM_RECD, 0) +
                       NVL(ew.EXTE_PREM_IGST_AMT, 0) +
                       NVL(ew.EXTE_PREM_SGST_AMT, 0) +
                       NVL(ew.EXTE_PREM_CGST_AMT, 0))))
                                  END)
                                  ELSE
                                    NULL
                                     END) difference
                                      ,(select gm.mspin|| '','' ||gm.first_name|| '','' ||a.desg_desc
                                            from gm_emp gm,gm_desg a
                                            where a.principal_map_cd='''||:global.principal||'''
                                            and a.desg_cd=gm.emp_desg_cd
                                            and gm.dealer_map_cd=ew.exte_conv_dealer_map_cd
                                            and gm.emp_cd=ew.EXTE_CONV_EMP_CD
                                             )bb
								FROM  dmsd_ew_sale EW,
								      MWAR_EXTE XW,
								      AM_DEALER_LOC ALOC
								WHERE ew.exte_policy_no=xw.exte_policy_no
                  and ew.exte_transaction_date >= '''||:CB_DUMMY.CONT_FROM_DATE||'''
                  AND ew.exte_transaction_date < '''||lv_to_date||'''
                  and EW.EXTE_TRAN_TYPE IN (''U'',''X'')
								  AND ALOC.PARENT_GROUP = EW.EXTE_CONV_PARENT_GROUP
								  AND ALOC.DEALER_MAP_CD = EW.EXTE_CONV_DEALER_MAP_CD
								  AND ALOC.LOC_CD = EW.EXTE_CONV_LOC_CD
								  AND ALOC.PRINCIPAL_MAP_CD='''||:GLOBAL.PRINCIPAL||'''
								  AND nvl(ALOC.REGION_CD,''A'') = decode('''||:CB_DUMMY.CB_REGION||''',''All'',nvl(ALOC.REGION_CD,''A''),'''||:CB_DUMMY.CB_REGION||''')
									AND nvl(EW.EXTE_CONV_PARENT_GROUP,''A'') = decode('''||:CB_DUMMY.CB_PARENT||''',''All'',nvl(EW.EXTE_CONV_PARENT_GROUP,''A''),'''||:CB_DUMMY.CB_PARENT||''')
								  AND nvl(EW.EXTE_CONV_DEALER_MAP_CD,1) = decode('''||:CB_DUMMY.CB_DEALER_MAP_CD||''',''All'',nvl(EW.EXTE_CONV_DEALER_MAP_CD,1),'''||:CB_DUMMY.CB_DEALER_MAP_CD||''')
								  AND nvl(EW.EXTE_CONV_LOC_CD,''A'') = decode('''||:CB_DUMMY.CB_LOC_CD||''',''All'',nvl(EW.EXTE_CONV_LOC_CD,''A''),'''||:CB_DUMMY.CB_LOC_CD||''')
								  AND XW.EXTE_MODL_CODE = decode('''||:CB_DUMMY.BASE_MODEL_CD||''',''All'',XW.EXTE_MODL_CODE,'''||:CB_DUMMY.BASE_MODEL_CD||''')
								  AND nvl(XW.EXTE_VARIANT_CD,''A'') = decode('''||:CB_DUMMY.VARIANT_CD||''',''All'',nvl(XW.EXTE_VARIANT_CD,''A''),'''||:CB_DUMMY.VARIANT_CD||''')
								  AND EW.EXTE_WARR_TYPE = decode('''||:CB_DUMMY.EW_TYPE||''',''All'',EW.EXTE_WARR_TYPE,'''||:CB_DUMMY.EW_TYPE||'''))X
								  where 	 X.payment_type = DECODE('''||:CB_DUMMY.CB_PAYMENT_TYPE||''',''A'',X.payment_type,''OD'',''Offline DMS'', ''E'', ''EMI'', ''OE'',''Online But Not EMI'', '''||:CB_DUMMY.CB_PAYMENT_TYPE||''')
								  AND X.Conversion_From = decode('''||:CB_DUMMY.CB_SOLD_FROM||''',''A'',X.Conversion_From,''WEB'',''WEB'', ''WS'', ''Workshop'', ''SH'',''Showroom'','''||:CB_DUMMY.CB_SOLD_FROM||''')
								  ';
--AND nvl(EXTE_CANCEL_FLAG,''N'') = ''N'' -- As Diss. with Mr. Anoop all EW show in report	
							  
ELSIF :CB_DUMMY.P_REP_TYPE = 'C' THEN
v_query := 'SELECT ''Extended Warranty Cancellation Details Report'' entire_string FROM DUAL
						UNION ALL
						SELECT ''Dealer Name & Location:  '' ||'''||:CB_DUMMY.CB_DEALER_NAME||''' entire_string FROM DUAL
						UNION ALL
						SELECT ''From Date:  '' ||'''||TO_CHAR(:CB_DUMMY.CONT_FROM_DATE,'MM/DD/RRRR')||'''|| ''    To Date:  '' ||'''||TO_CHAR(:CB_DUMMY.CONT_TO_DATE,'MM/DD/RRRR')||''' ||CHR(10)||CHR(10) entire_string FROM DUAL
						UNION ALL
						SELECT''Region,EW Sale Dlr Code,EW Sale Dlr Name,Location,Policy No,EW Sale Date,Policy Cancellation Date,VIN,VIN Sale Date,Model Code,Model desc,Variant Code,Variant Desc,Warranty Type,Customer Name,Mileage,Expiry Date,Expiry Mileage,Premium Amount,CGST Premium,SGST Premium,IGST Premium, Commission Amount,CGST Commission,SGST Commission,IGST Commission,Cancellation Amount,Remarks,Status,Sold From,Payment type, Facilitation charge,Convenience charges discount,Interest charges discount,Basic cost,EMI tenure,Difference,MSPIN,Emp Name,Emp Desg'' entire_string FROM DUAL
								 UNION ALL
			 select X.Region                    ||'',''||
              X.EW_Sale_Dlr_Code          ||'',''||
              X.Dealer_Name_Location      ||'',''||
              X.Policy_No                 ||'',''||
              X.EW_Sale_Date              ||'',''||
              X.Policy_Cancellation_Date  ||'',''||
              X.VIN                       ||'',''||
              X.VIN_Sale_Date             ||'',''||
              X.model_code                ||'',''||
              X.model_desc                ||'',''||
              X.variant_cd              ||'',''||
              X.variant_desc              ||'',''||
              X.Warranty_Type             ||'',''||
              X.Customer_Name             ||'',''||
              X.Mileage                   ||'',''||
              X.Expiry_Date               ||'',''||
              X.Expiry_Mileage            ||'',''||
              X.Premium_Amount              ||'',''||
              X.CGST_Premium                ||'',''||
              X.SGST_Premium                ||'',''||
              X.IGST_Premium                ||'',''|| 
              X.Commission_Amount           ||'',''||
              X.CGST_Commission             ||'',''||
              X.SGST_Commission             ||'',''||
              X.IGST_Commission             ||'',''||
              X.Cancellation_Amount         ||'',''||
              X.Remarks                     ||'',''||
              X.Status                      ||'',''||
              X.Sold_From                   ||'',''||
              X.Payment_type                ||'',''|| 
              X.Facilitation_charge         ||'',''||
              X.Convenience_charges_discount ||'',''||
              X.Interest_charges_discount   ||'',''||
              X.Basic_Cost_bank              ||'',''||
              X.EMI_tenure                  ||'',''||
              X.Difference                   ||'',''||
              x.bb
             
              from( 	SELECT /*+ index (EW MWAR_EXTE_MK14)*/ NVL(ALOC.REGION_CD,(SELECT DL.REGION_CD  FROM AM_DEALER_LOC DL WHERE DL.MUL_DEALER_CD = EW.EXTE_POLICY_DELR and DL.PRINCIPAL_MAP_CD='''||:GLOBAL.PRINCIPAL||''' AND ROWNUM = 1 )) Region,
											NVL(ALOC.dealer_category,''DDL'')||''-''||NVL(EW.EXTE_POLICY_DELR,ALOC.MUL_DEALER_CD)||''-''||NVL(EW.EXTE_POLICY_FOR,ALOC.FOR_CD)||''-''||decode(EW.EXTE_POLICY_SOLD_FROM,''SH'',''01'',NVL(EW.EXTE_POLICY_OUTLET,ALOC.OUTLET_CD)) EW_Sale_Dlr_Code,
      								nvl(sf_get_dlr_name_loc (EW.EXTE_DEALER_MAP_CD,EW.EXTE_LOC_CD,EW.EXTE_POLICY_DELR,'''||:global.principal||'''),'','') Dealer_Name_Location,											
								      EW.EXTE_POLICY_NO Policy_No,
								      to_char(EW.EXTE_CONTRACT_DATE,''DD-MM-YYYY'') EW_Sale_Date,
								      to_char(EW.EXTE_CANCEL_DT,''DD-MM-YYYY'') Policy_Cancellation_Date,
								      EW.EXTE_VIN_NO VIN,
								      to_char(EW.EXTE_RETLSALE_DT,''DD-MM-YYYY'') VIN_Sale_Date,
								      (SELECT gv.model_cd 
								         FROM gm_mod gm, gm_vin gv 
								        WHERE gm.model_cd = gv.model_Cd 
								          AND gv.vin = EW.EXTE_VIN_NO
								          and gm.principal_map_cd='''||:global.principal||'''
								          and gm.principal_map_cd=gv.principal_map_cd) model_code,
								          	
								          (SELECT replace(gm.model_desc, '','', '' '') 
								         FROM gm_mod gm, gm_vin gv 
								        WHERE gm.model_cd = gv.model_Cd 
								          AND gv.vin = EW.EXTE_VIN_NO
								          and gm.principal_map_cd='''||:global.principal||'''
								          and gm.principal_map_cd=gv.principal_map_cd) model_desc,
								          					      
								      (SELECT gvn.variant_cd
								         FROM gm_var gvr, gm_vin gvn 
								        WHERE gvr.variant_cd = gvn.variant_cd 
								          AND gvn.vin = EW.EXTE_VIN_NO
								             and gvr.principal_map_cd='''||:global.principal||'''
								          and gvr.principal_map_cd=gvn.principal_map_cd )variant_cd ,
								          
								          (SELECT replace(gvr.variant_desc, '','', '' '') 
								         FROM gm_var gvr, gm_vin gvn 
								        WHERE gvr.variant_cd = gvn.variant_cd 
								          AND gvn.vin = EW.EXTE_VIN_NO
								             and gvr.principal_map_cd='''||:global.principal||'''
								          and gvr.principal_map_cd=gvn.principal_map_cd )variant_desc ,
								          
								      EW.EXTE_WARR_TYPE Warranty_Type,
								      replace(EW.EXTE_CUST_NAME, '','', '' '') Customer_Name,
								      EW.EXTE_CONTRACT_MILEAGE Mileage,
								      to_char(EW.EXTE_VALID_DATE,''DD-MM-YYYY'')Expiry_Date,
								      EW.EXTE_VALID_MILEAGE Expiry_Mileage,
								      EW.EXTE_POLICY_PREMIUM Premium_Amount,
								      (greatest((EW.EXTE_POLICY_PREMIUM * 0.1),200)*EW.EXTE_PREM_CGST_RATE/100) CGST_Premium,
                     (greatest((EW.EXTE_POLICY_PREMIUM * 0.1),200)*EW.EXTE_PREM_SGST_RATE/100)  SGST_Premium,
                     (greatest((EW.EXTE_POLICY_PREMIUM * 0.1),200)*EW.EXTE_PREM_IGST_RATE/100)  IGST_Premium,
								      EW.EXTE_COMMISION_AMT Commission_Amount,
								      EW.EXTE_PREM_COMM_CGST CGST_Commission,
								      NVL(EW.EXTE_PREM_COMM_SGST,0)SGST_Commission,
								      NVL(EW.EXTE_PREM_COMM_IGST,0)IGST_Commission,
											greatest((EW.EXTE_POLICY_PREMIUM * 0.1),200)Cancellation_Amount,
											replace(replace(replace(XW.EXTE_REMARKS,chr(10),'' ''),chr(13),'' ''),'','','' '')  Remarks,
											sf_ew_policy_status(EW.EXTE_POLICY_NO) Status,
      								DECODE(ew.online_sale_flag,''Y'',''WEB'',decode(xw.EXTE_POLICY_SOLD_FROM,''WEB'',''WEB'',''WS'',''Workshop'',''SH'',''Showroom'') )Sold_From,
                      (case when NVL(ew.online_sale_flag,''N'')=''Y'' AND NVL(ew.emi_flag,''N'') = ''Y'' THEN
                      ''EMI''
                     WHEN NVL(ew.online_sale_flag,''N'')=''Y'' AND NVL(ew.emi_flag,''N'') =''N'' THEN
                      ''Online But Not EMI''
                     WHEN NVL(ew.online_sale_flag,''N'')=''N'' AND NVL(ew.EXTE_PAY_MODE,''C'') = ''O'' AND NVL(ew.emi_flag,''N'') = ''Y'' THEN 
                       ''EMI''
                     WHEN NVL(ew.online_sale_flag,''N'')=''N'' AND NVL(ew.EXTE_PAY_MODE,''C'') = ''O'' AND NVL(ew.emi_flag,''N'') = ''N'' THEN
                       ''Online But Not EMI''
                     WHEN NVL(ew.online_sale_flag,''N'')=''N'' AND NVL(ew.EXTE_PAY_MODE,''C'') = ''C'' THEN 
                       ''Offline DMS'' 
                     ELSE
                        ''NA''
                    END )   Payment_type  ,
                      EW.FACILITATION_CHG    Facilitation_charge,
                      EW.CONVENIENCE_FEE     Convenience_charges_discount,
                      EW.emi_disc_val        Interest_charges_discount,
                    ew.order_capt_amt       Basic_Cost_bank,
                      XW.TENURE_DURATION    EMI_tenure,
                      (CASE WHEN ew.emi_disc_val IS NOT NULL THEN
                   (CASE  WHEN nvl(ew.online_sale_flag,''N'') =''N'' 
                                THEN NVL(ew.order_capt_amt,0)+NVL(ew.emi_disc_val,0)-(((NVL(ew.EXTE_PREMIUM_RECD, 0) +
                       NVL(ew.EXTE_PREM_IGST_AMT, 0) +
                       NVL(ew.EXTE_PREM_SGST_AMT, 0) +
                       NVL(ew.EXTE_PREM_CGST_AMT, 0))))
                                ELSE (NVL(ew.order_capt_amt,0)+NVL(ew.emi_disc_val,0)+NVL(ew.emi_disc_val,0)-((NVL(ew.EXTE_PREMIUM_RECD, 0) +
                       NVL(ew.EXTE_PREM_IGST_AMT, 0) +
                       NVL(ew.EXTE_PREM_SGST_AMT, 0) +
                       NVL(ew.EXTE_PREM_CGST_AMT, 0))))
                                  END)
                                  ELSE
                                    NULL
                                     END) difference,
                                     (select gm.mspin|| '','' ||gm.first_name|| '','' ||a.desg_desc
                                            from gm_emp gm,gm_desg a
                                            where a.principal_map_cd='''||:global.principal||'''
                                            and a.desg_cd=gm.emp_desg_cd
                                            and gm.dealer_map_cd=ew.exte_dealer_map_cd
                                            and gm.emp_cd=ew.exte_emp_cd
                                             )bb
								FROM dmsd_ew_sale EW,
								      MWAR_EXTE XW,
								      AM_DEALER_LOC ALOC
								WHERE EW.EXTE_POLICY_NO=XW.EXTE_POLICY_NO
                  AND  EW.EXTE_TRANSACTION_DATE >= '''||:CB_DUMMY.CONT_FROM_DATE||'''
                  AND EW.EXTE_TRANSACTION_DATE <  '''||lv_to_date||'''
                  AND EW.EXTE_TRAN_TYPE =''C''
								  AND ALOC.PARENT_GROUP(+) = EW.EXTE_PARENT_GROUP
								  AND ALOC.DEALER_MAP_CD(+) = EW.EXTE_DEALER_MAP_CD
								  AND ALOC.LOC_CD(+) = EW.EXTE_LOC_CD
								  AND ALOC.PRINCIPAL_MAP_CD='''||:GLOBAL.PRINCIPAL||'''
								  AND EW.EXTE_POLICY_SOLD_FROM = decode('''||:CB_DUMMY.CB_SOLD_FROM||''',''A'',EW.EXTE_POLICY_SOLD_FROM,'''||:CB_DUMMY.CB_SOLD_FROM||''')
									AND nvl(ALOC.REGION_CD,''A'') = decode('''||:CB_DUMMY.CB_REGION||''',''All'',nvl(ALOC.REGION_CD,''A''),'''||:CB_DUMMY.CB_REGION||''')
									AND nvl(EW.EXTE_PARENT_GROUP,''A'') = decode('''||:CB_DUMMY.CB_PARENT||''',''All'',nvl(EW.EXTE_PARENT_GROUP,''A''),'''||:CB_DUMMY.CB_PARENT||''')
								  AND nvl(EW.EXTE_DEALER_MAP_CD,1) = decode('''||:CB_DUMMY.CB_DEALER_MAP_CD||''',''All'',nvl(EW.EXTE_DEALER_MAP_CD,1),'''||:CB_DUMMY.CB_DEALER_MAP_CD||''')
								  AND nvl(EW.EXTE_LOC_CD,''A'') = decode('''||:CB_DUMMY.CB_LOC_CD||''',''All'',nvl(EW.EXTE_LOC_CD,''A''),'''||:CB_DUMMY.CB_LOC_CD||''')
								  AND XW.EXTE_MODL_CODE = decode('''||:CB_DUMMY.BASE_MODEL_CD||''',''All'',XW.EXTE_MODL_CODE,'''||:CB_DUMMY.BASE_MODEL_CD||''')
								  AND nvl(XW.EXTE_VARIANT_CD,''A'') = decode('''||:CB_DUMMY.VARIANT_CD||''',''All'',nvl(XW.EXTE_VARIANT_CD,''A''),'''||:CB_DUMMY.VARIANT_CD||''')
								  AND EW.EXTE_WARR_TYPE = decode('''||:CB_DUMMY.EW_TYPE||''',''All'',EW.EXTE_WARR_TYPE,'''||:CB_DUMMY.EW_TYPE||'''))X
								  where 	 X.payment_type = DECODE('''||:CB_DUMMY.CB_PAYMENT_TYPE||''',''A'',X.payment_type,''OD'',''Offline DMS'', ''E'', ''EMI'', ''OE'',''Online But Not EMI'', '''||:CB_DUMMY.CB_PAYMENT_TYPE||''')
								  AND X.sold_from = decode('''||:CB_DUMMY.CB_SOLD_FROM||''',''A'',X.sold_from,''WEB'',''WEB'', ''WS'', ''Workshop'', ''SH'',''Showroom'','''||:CB_DUMMY.CB_SOLD_FROM||''')
								  UNION ALL
								  select Y.Region                    ||'',''||
              Y.EW_Sale_Dlr_Code          ||'',''||
              Y.Dealer_Name_Location      ||'',''||
              Y.Policy_No                 ||'',''||
              Y.EW_Sale_Date              ||'',''||
              Y.Policy_Cancellation_Date  ||'',''||
              Y.VIN                       ||'',''||
              Y.VIN_Sale_Date             ||'',''||
              Y.model_code                ||'',''||
              Y.model_desc                ||'',''||
              Y.variant_cd              ||'',''||
              Y.variant_desc              ||'',''||
              Y.Warranty_Type             ||'',''||
              Y.Customer_Name             ||'',''||
              Y.Mileage                   ||'',''||
              Y.Expiry_Date               ||'',''||
              Y.Expiry_Mileage            ||'',''||
              Y.Premium_Amount              ||'',''||
              Y.CGST_Premium                ||'',''||
              Y.SGST_Premium                ||'',''||
              Y.IGST_Premium                ||'',''|| 
              Y.Commission_Amount           ||'',''||
              Y.CGST_Commission             ||'',''||
              Y.SGST_Commission             ||'',''||
              Y.IGST_Commission             ||'',''||
              Y.Cancellation_Amount         ||'',''||
              Y.Remarks                     ||'',''||
              Y.Status                      ||'',''||
              Y.Sold_From                   ||'',''||
              Y.Payment_type                ||'',''|| 
              Y.Facilitation_charge         ||'',''||
              Y.Convenience_charges_discount ||'',''||
              Y.Interest_charges_discount   ||'',''||
              Y.Basic_Cost_bank              ||'',''||
              Y.EMI_tenure                  ||'',''||
              Y.Difference                  ||'',''||
              y.cc
             
              from( SELECT  NVL(ALOC.REGION_CD,
       (SELECT DL.REGION_CD  FROM AM_DEALER_LOC DL WHERE DL.MUL_DEALER_CD = XW.EXTE_POLICY_DELR and DL.PRINCIPAL_MAP_CD='''||:GLOBAL.PRINCIPAL||''' AND ROWNUM = 1 )) Region,
                      NVL(ALOC.dealer_category,''DDL'')||''-''||NVL(XW.EXTE_POLICY_DELR,ALOC.MUL_DEALER_CD)||''-''||NVL(XW.EXTE_POLICY_FOR,ALOC.FOR_CD)||''-''||decode(XW.EXTE_POLICY_SOLD_FROM,''SH'',''01'',NVL(XW.EXTE_POLICY_OUTLET,ALOC.OUTLET_CD)) EW_Sale_Dlr_Code,
                      nvl(sf_get_dlr_name_loc (XW.EXTE_DEALER_MAP_CD,XW.EXTE_LOC_CD,XW.EXTE_POLICY_DELR,1),'','') Dealer_Name_Location,                     
                      XW.EXTE_POLICY_NO Policy_No,
                      to_char(XW.EXTE_CONTRACT_DATE,''DD-MM-YYYY'') EW_Sale_Date,
                      to_char(XW.EXTE_CANCEL_DT,''DD-MM-YYYY'') Policy_Cancellation_Date,
                      XW.EXTE_VIN_NO VIN,
                      to_char(XW.EXTE_RETLSALE_DT,''DD-MM-YYYY'') VIN_Sale_Date,
                      (SELECT gv.model_cd 
                         FROM gm_mod gm, gm_vin gv 
                        WHERE gm.model_cd = gv.model_Cd 
                          AND gv.vin = XW.EXTE_VIN_NO
                          and gm.principal_map_cd='''||:GLOBAL.PRINCIPAL||'''
                          and gm.principal_map_cd=gv.principal_map_cd) model_code,
                            
                          (SELECT replace(gm.model_desc, '','', '' '') 
                         FROM gm_mod gm, gm_vin gv 
                        WHERE gm.model_cd = gv.model_Cd 
                          AND gv.vin = XW.EXTE_VIN_NO
                          and gm.principal_map_cd='''||:GLOBAL.PRINCIPAL||'''
                          and gm.principal_map_cd=gv.principal_map_cd) model_desc,
                                          
                      (SELECT gvn.variant_cd
                         FROM gm_var gvr, gm_vin gvn 
                        WHERE gvr.variant_cd = gvn.variant_cd 
                          AND gvn.vin = XW.EXTE_VIN_NO
                             and gvr.principal_map_cd='''||:GLOBAL.PRINCIPAL||'''
                          and gvr.principal_map_cd=gvn.principal_map_cd )variant_cd ,
                          
                          (SELECT replace(gvr.variant_desc, '','', '' '') 
                         FROM gm_var gvr, gm_vin gvn 
                        WHERE gvr.variant_cd = gvn.variant_cd 
                          AND gvn.vin = XW.EXTE_VIN_NO
                             and gvr.principal_map_cd='''||:GLOBAL.PRINCIPAL||'''
                          and gvr.principal_map_cd=gvn.principal_map_cd )variant_desc ,
                          
                      XW.EXTE_WARR_TYPE Warranty_Type,
                      replace(XW.EXTE_CUST_NAME, '','', '' '') Customer_Name,
                      XW.EXTE_CONTRACT_MILEAGE Mileage,
                      to_char(XW.EXTE_VALID_TO_DATE,''DD-MM-YYYY'')Expiry_Date,
                      XW.EXTE_VALID_MILEAGE Expiry_Mileage,
                      XW.EXTE_PREMIUM Premium_Amount,
                      (greatest((XW.EXTE_PREMIUM * 0.1),200)*XW.EXTE_PREM_CGST_RATE/100) CGST_Premium,
                     (greatest((XW.EXTE_PREMIUM * 0.1),200)*XW.EXTE_PREM_SGST_RATE/100)  SGST_Premium,
                     (greatest((XW.EXTE_PREMIUM * 0.1),200)*XW.EXTE_PREM_IGST_RATE/100)  IGST_Premium,
                      XW.exte_prem_dlr_comm Commission_Amount,
                      XW.EXTE_PREM_COMM_CGST CGST_Commission,
                      NVL(XW.EXTE_PREM_COMM_SGST,0)SGST_Commission,
                      NVL(XW.EXTE_PREM_COMM_IGST,0)IGST_Commission,
                      xw.exte_cancel_amt Cancellation_Amount,
                      replace(replace(replace(XW.EXTE_REMARKS,chr(10),'' ''),chr(13),'' ''),'','','' '')  Remarks,
                      sf_ew_policy_status(XW.EXTE_POLICY_NO) Status,
                      decode(xw.EXTE_POLICY_SOLD_FROM,''WEB'',''WEB'',''WS'',''Workshop'',''SH'',''Showroom'') Sold_From,
                      (case when NVL(XW.EXTE_PAY_MODE,''C'') = ''C'' THEN 
                       ''Offline DMS'' 
                     ELSE
                        ''NA''
                    END )   Payment_type  ,
                      XW.FACILITATION_AMT    Facilitation_charge,
                      XW.CONVENIENCE_AMT     Convenience_charges_discount,
                      XW.emi_disc_val        Interest_charges_discount,
                    NULL       Basic_Cost_bank,
                      XW.TENURE_DURATION    EMI_tenure,
                      (CASE WHEN XW.emi_disc_val IS NOT NULL THEN
                   (CASE  WHEN nvl(XW.online_sale_flag,''N'') =''N'' 
                                THEN NVL(XW.emi_disc_val,0)-(((NVL(XW.EXTE_PREMIUM_RCVD, 0) +
                       NVL(XW.EXTE_PREM_IGST_AMT, 0) +
                       NVL(XW.EXTE_PREM_SGST_AMT, 0) +
                       NVL(XW.EXTE_PREM_CGST_AMT, 0))))
                                ELSE (NVL(XW.emi_disc_val,0)+NVL(XW.emi_disc_val,0)-((NVL(XW.EXTE_PREMIUM_RCVD, 0) +
                       NVL(XW.EXTE_PREM_IGST_AMT, 0) +
                       NVL(XW.EXTE_PREM_SGST_AMT, 0) +
                       NVL(XW.EXTE_PREM_CGST_AMT, 0))))
                                  END)
                                  ELSE
                                    NULL
                                     END) difference,
                                     (select gm.mspin|| '','' ||gm.first_name|| '','' ||a.desg_desc
                                            from gm_emp gm,gm_desg a
                                            where a.principal_map_cd='''||:GLOBAL.PRINCIPAL||'''
                                            and a.desg_cd=gm.emp_desg_cd
                                            and gm.dealer_map_cd=xw.exte_dealer_map_cd
                                            and gm.emp_cd=xw.exte_emp_cd
                                             )cc
                FROM vt_extsawa XW,
                      AM_DEALER_LOC ALOC
                WHERE XW.EXTE_CONTRACT_DATE >= '''||:CB_DUMMY.CONT_FROM_DATE||'''
                  AND XW.EXTE_CONTRACT_DATE <  '''||lv_to_date||'''
                  AND NVL(XW.EXTE_CANCEL_FLAG,''N'') =''Y''
                   AND ALOC.PARENT_GROUP = xw.EXTE_PARENT_GROUP
                  AND ALOC.DEALER_MAP_CD = xw.EXTE_DEALER_MAP_CD
                  AND ALOC.LOC_CD = xw.EXTE_LOC_CD
                  AND ALOC.PRINCIPAL_MAP_CD='''||:GLOBAL.PRINCIPAL||'''
                  AND XW.EXTE_POLICY_SOLD_FROM = decode('''||:CB_DUMMY.CB_SOLD_FROM||''',''A'',XW.EXTE_POLICY_SOLD_FROM,'''||:CB_DUMMY.CB_SOLD_FROM||''')
                  AND nvl(ALOC.REGION_CD,''A'') = decode('''||:CB_DUMMY.CB_REGION||''',''All'',nvl(ALOC.REGION_CD,''A''),'''||:CB_DUMMY.CB_REGION||''')
                  AND nvl(XW.EXTE_PARENT_GROUP,''A'') = decode('''||:CB_DUMMY.CB_PARENT||''',''All'',nvl(XW.EXTE_PARENT_GROUP,''A''),'''||:CB_DUMMY.CB_PARENT||''')
                  AND nvl(XW.EXTE_DEALER_MAP_CD,1) = decode('''||:CB_DUMMY.CB_DEALER_MAP_CD||''',''All'',nvl(XW.EXTE_DEALER_MAP_CD,1),'''||:CB_DUMMY.CB_DEALER_MAP_CD||''')
                  AND nvl(XW.EXTE_LOC_CD,''A'') = decode('''||:CB_DUMMY.CB_LOC_CD||''',''All'',nvl(XW.EXTE_LOC_CD,''A''),'''||:CB_DUMMY.CB_LOC_CD||''')
                  AND XW.EXTE_MODL_CODE = decode('''||:CB_DUMMY.BASE_MODEL_CD||''',''All'',XW.EXTE_MODL_CODE,'''||:CB_DUMMY.BASE_MODEL_CD||''')
                  AND nvl(XW.EXTE_VARIANT_CD,''A'') =decode('''||:CB_DUMMY.VARIANT_CD||''',''All'',nvl(XW.EXTE_VARIANT_CD,''A''),'''||:CB_DUMMY.VARIANT_CD||''')
                  AND XW.EXTE_WARR_TYPE = decode('''||:CB_DUMMY.EW_TYPE||''',''All'',XW.EXTE_WARR_TYPE,'''||:CB_DUMMY.EW_TYPE||''')
                   )Y
								  where 	 Y.payment_type = DECODE('''||:CB_DUMMY.CB_PAYMENT_TYPE||''',''A'',Y.payment_type,''OD'',''Offline DMS'', ''E'', ''EMI'', ''OE'',''Online But Not EMI'', '''||:CB_DUMMY.CB_PAYMENT_TYPE||''')
								  AND Y.sold_from = decode('''||:CB_DUMMY.CB_SOLD_FROM||''',''A'',Y.sold_from,''WEB'',''WEB'', ''WS'', ''Workshop'', ''SH'',''Showroom'','''||:CB_DUMMY.CB_SOLD_FROM||''')
								 ';

/*
IF :CB_DUMMY.P_REP_TYPE = 'N' THEN
v_query := 'SELECT ''Extended Warranty Sale Details Report'' entire_string FROM DUAL
						UNION ALL
						SELECT ''Dealer Name & Location:  '' ||'''||:CB_DUMMY.CB_DEALER_NAME||''' entire_string FROM DUAL
						UNION ALL
						SELECT ''From Date:  '' ||'''||TO_CHAR(:CB_DUMMY.CONT_FROM_DATE,'MM/DD/RRRR')||'''|| ''    To Date:  '' ||'''||TO_CHAR(:CB_DUMMY.CONT_TO_DATE,'MM/DD/RRRR')||''' ||CHR(10)||CHR(10) entire_string FROM DUAL
						UNION ALL
						SELECT''Region,Dealer Code,Dealer Name,Location,Policy No,EW Sale Date,VIN,VIN Sale Date,Model Code,Model desc,Variant Code,Variant Desc,Customer Name,Mileage,Warranty Type,Expiry Date,Expiry Mileage,Premium Amount,Commission Amount,Service Tax,Debit Amount,Sold By,Status,Sold From'' entire_string FROM DUAL
								 UNION ALL
								SELECT /*+ index (EW MWAR_EXTE_MK5)*-/	
								      ALOC.region_cd||'',''||
								      ALOC.dealer_category||''-''||EW.EXTE_POLICY_DELR||''-''||EW.EXTE_POLICY_FOR||''-''||decode(EW.EXTE_POLICY_SOLD_FROM,''SH'',''01'',EW.EXTE_POLICY_OUTLET)||'',''||
      								nvl(sf_get_dlr_name_loc (EW.EXTE_DEALER_MAP_CD,EW.EXTE_LOC_CD,EW.EXTE_POLICY_DELR),'','')||'',''||
								      EW.EXTE_POLICY_NO||'',''||
								      to_char(EW.EXTE_CONTRACT_DATE,''MM/DD/RRRR'')||'',''||
								      EW.EXTE_VIN_NO||'',''||
								      to_char(EW.EXTE_RETLSALE_DT,''MM/DD/RRRR'')||'',''||
								      EW.EXTE_MODL_CODE||'',''||
								      (SELECT replace(gm.model_desc, '','', '' '') FROM gm_mod gm WHERE gm.model_cd = ew.exte_modl_code)||'',''||
								      EW.EXTE_VARIANT_CD||'',''||
								      (SELECT replace(gv.variant_desc, '','', '' '') FROM gm_var gv WHERE gv.variant_cd = ew.exte_variant_cd)||'',''||
								      replace(EW.EXTE_CUST_NAME, '','', '' '')||'',''||
								      EW.EXTE_CONTRACT_MILEAGE||'',''||
											SF_GET_EW_VALIDITY_DTL(EW.EXTE_POLICY_NO,:CB_DUMMY.P_REP_TYPE)||'',''||
								      EW.EXTE_PREMIUM_CALCULATED||'',''||
								      EW.EXTE_PREM_DLR_COMM||'',''||
								      EW.EXTE_PREM_SRV_TAX||'',''||
								      (EW.EXTE_PREMIUM_CALCULATED - EW.EXTE_PREM_DLR_COMM - EW.EXTE_PREM_SRV_TAX)||'',''||
								      EW.EXTE_CREATED_BY||'',''||
      								sf_ew_policy_status(EW.EXTE_POLICY_NO)||'',''||
      								decode(EXTE_POLICY_SOLD_FROM,''WS'',''Workshop'',''SH'',''Showroom'')
								FROM
								      MWAR_EXTE EW,
								      AM_DEALER_LOC ALOC
								WHERE
											EXTE_CONTRACT_DATE >= '''||:CB_DUMMY.CONT_FROM_DATE||'''
								  AND EXTE_CONTRACT_DATE < '''||lv_to_date||'''
								  AND ALOC.PARENT_GROUP = EXTE_PARENT_GROUP
								  AND ALOC.DEALER_MAP_CD = EXTE_DEALER_MAP_CD
								  AND ALOC.LOC_CD = EXTE_LOC_CD
									AND EW.EXTE_POLICY_SOLD_FROM = decode('''||:CB_DUMMY.CB_SOLD_FROM||''',''A'',EW.EXTE_POLICY_SOLD_FROM,'''||:CB_DUMMY.CB_SOLD_FROM||''')
									AND ALOC.REGION_CD = decode('''||:CB_DUMMY.CB_REGION||''',''All'',ALOC.REGION_CD,'''||:CB_DUMMY.CB_REGION||''')
									AND EXTE_PARENT_GROUP = decode('''||:CB_DUMMY.CB_PARENT||''',''All'',EXTE_PARENT_GROUP,'''||:CB_DUMMY.CB_PARENT||''')
								  AND EXTE_DEALER_MAP_CD = decode('''||:CB_DUMMY.CB_DEALER_MAP_CD||''',''All'',EXTE_DEALER_MAP_CD,'''||:CB_DUMMY.CB_DEALER_MAP_CD||''')
								  AND EXTE_LOC_CD = decode('''||:CB_DUMMY.CB_LOC_CD||''',''All'',EXTE_LOC_CD,'''||:CB_DUMMY.CB_LOC_CD||''')
								  AND EXTE_MODL_CODE = decode('''||:CB_DUMMY.BASE_MODEL_CD||''',''All'',EXTE_MODL_CODE,'''||:CB_DUMMY.BASE_MODEL_CD||''')
								  AND EXTE_VARIANT_CD = decode('''||:CB_DUMMY.VARIANT_CD||''',''All'',EXTE_VARIANT_CD,'''||:CB_DUMMY.VARIANT_CD||''')
								  AND EXTE_WARR_TYPE = decode('''||:CB_DUMMY.EW_TYPE||''',''All'',EXTE_WARR_TYPE,'''||:CB_DUMMY.EW_TYPE||''')
								  ';
--AND nvl(EXTE_CANCEL_FLAG,''N'') = ''N'' -- As Diss. with Mr. Anoop all EW show in report

ELSIF :CB_DUMMY.P_REP_TYPE = 'U' THEN
v_query := 'SELECT ''Extended Warranty Conversion Details Report'' entire_string FROM DUAL
						UNION ALL
						SELECT ''Dealer Name & Location:  '' ||'''||:CB_DUMMY.CB_DEALER_NAME||''' entire_string FROM DUAL
						UNION ALL
						SELECT ''From Date:  '' ||'''||TO_CHAR(:CB_DUMMY.CONT_FROM_DATE,'MM/DD/RRRR')||'''|| ''    To Date:  '' ||'''||TO_CHAR(:CB_DUMMY.CONT_TO_DATE,'MM/DD/RRRR')||''' ||CHR(10)||CHR(10) entire_string FROM DUAL
						UNION ALL
						SELECT''Region,EW Sale Dlr Code,EW Sale Dlr Name,Location,Conv. Dealer Code,Conv. Dealer Name,Conv. Location,Policy No,EW Sale Date,Conv. Date,VIN,VIN Sale Date,Model Code,Model desc,Variant Code,Variant Desc,Warranty Type,Customer Name,Mileage,Expiry Date,Expiry Mileage,Diff. Premium Amount,Diff. Comm. Amount,Service Tax,Debit Amount,Upgraded By,Status,Conversion From'' entire_string FROM DUAL
								 UNION ALL
								SELECT  /*+ index (EW MWAR_EXTE_MK9)*-/										
											ALOC.region_cd||'',''||
											ALOC.dealer_category||''-''||EW.EXTE_POLICY_DELR||''-''||EW.EXTE_POLICY_FOR||''-''||decode(EW.EXTE_POLICY_SOLD_FROM,''SH'',''01'',EW.EXTE_POLICY_OUTLET)||'',''||
      								nvl(sf_get_dlr_name_loc (EW.EXTE_DEALER_MAP_CD,EW.EXTE_LOC_CD,EW.EXTE_POLICY_DELR),'','')||'',''||
      								ALOC.dealer_category||''-''||EW.EXTE_CONV_DELR||''-''||EW.EXTE_CONV_FOR||''-''||decode(EW.EXTE_CONV_FROM,''SH'',''01'',EW.EXTE_CONV_OUTLET)||'',''||
      								nvl(sf_get_dlr_name_loc (EW.EXTE_CONV_DEALER_MAP_CD,EW.EXTE_CONV_LOC_CD,EW.EXTE_CONV_DELR),'','')||'',''||
      								EW.EXTE_POLICY_NO||'',''||
      								to_char(EW.EXTE_CONTRACT_DATE,''MM/DD/RRRR'')||'',''||
								      to_char(EW.EXTE_CONV_DATE,''MM/DD/RRRR'')||'',''||
								      EW.EXTE_VIN_NO||'',''||
								      to_char(EW.EXTE_RETLSALE_DT,''MM/DD/RRRR'')||'',''||
								      (SELECT gv.model_cd||'',''||replace(gm.model_desc, '','', '' '') 
								         FROM gm_mod gm, gm_vin gv 
								        WHERE gm.model_cd = gv.model_Cd 
								          AND gv.vin = EW.EXTE_VIN_NO)||'',''||								      
								      (SELECT gvn.variant_cd||'',''||replace(gvr.variant_desc, '','', '' '') 
								         FROM gm_var gvr, gm_vin gvn 
								        WHERE gvr.variant_cd = gvn.variant_cd 
								          AND gvn.vin = EW.EXTE_VIN_NO)||'',''||
								      EW.EXTE_WARR_TYPE||'',''||
								      replace(EW.EXTE_CUST_NAME, '','', '' '')||'',''||
								      EW.EXTE_CONV_MILEAGE||'',''||
								      to_char(EW.EXTE_VALID_DATE,''MM/DD/RRRR'')||'',''||
								      EW.EXTE_VALID_MILEAGE||'',''||
								      EW.EXTE_DIFF_PREMIUM||'',''||
								      EW.EXTE_CONV_DLR_COMM||'',''||
								      EW.EXTE_CONV_SRV_TAX||'',''||
								      (EW.EXTE_DIFF_PREMIUM - EW.EXTE_CONV_DLR_COMM - EW.EXTE_CONV_SRV_TAX)||'',''||
								      EW.EXTE_MODIFIED_BY||'',''||
								      sf_ew_policy_status(EW.EXTE_POLICY_NO)||'',''||
      								decode(EXTE_CONV_FROM,''WS'',''Workshop'',''SH'',''Showroom'')
								FROM
								      MWAR_EXTE EW,
								      AM_DEALER_LOC ALOC
								WHERE
											EXTE_CONV_DATE >= '''||:CB_DUMMY.CONT_FROM_DATE||'''
								  AND EXTE_CONV_DATE < '''||lv_to_date||'''
								  AND ALOC.PARENT_GROUP = EXTE_CONV_PARENT_GROUP
								  AND ALOC.DEALER_MAP_CD = EXTE_CONV_DEALER_MAP_CD
								  AND ALOC.LOC_CD = EXTE_CONV_LOC_CD
								  AND EW.EXTE_CONV_FROM = decode('''||:CB_DUMMY.CB_SOLD_FROM||''',''A'',EW.EXTE_CONV_FROM,'''||:CB_DUMMY.CB_SOLD_FROM||''')
									AND nvl(ALOC.REGION_CD,''A'') = decode('''||:CB_DUMMY.CB_REGION||''',''All'',nvl(ALOC.REGION_CD,''A''),'''||:CB_DUMMY.CB_REGION||''')
									AND nvl(EW.EXTE_CONV_PARENT_GROUP,''A'') = decode('''||:CB_DUMMY.CB_PARENT||''',''All'',nvl(EW.EXTE_CONV_PARENT_GROUP,''A''),'''||:CB_DUMMY.CB_PARENT||''')
								  AND nvl(EXTE_CONV_DEALER_MAP_CD,1) = decode('''||:CB_DUMMY.CB_DEALER_MAP_CD||''',''All'',nvl(EXTE_CONV_DEALER_MAP_CD,1),'''||:CB_DUMMY.CB_DEALER_MAP_CD||''')
								  AND nvl(EXTE_CONV_LOC_CD,''A'') = decode('''||:CB_DUMMY.CB_LOC_CD||''',''All'',nvl(EXTE_CONV_LOC_CD,''A''),'''||:CB_DUMMY.CB_LOC_CD||''')
								  AND EXTE_MODL_CODE = decode('''||:CB_DUMMY.BASE_MODEL_CD||''',''All'',EXTE_MODL_CODE,'''||:CB_DUMMY.BASE_MODEL_CD||''')
								  AND nvl(EXTE_VARIANT_CD,''A'') = decode('''||:CB_DUMMY.VARIANT_CD||''',''All'',nvl(EXTE_VARIANT_CD,''A''),'''||:CB_DUMMY.VARIANT_CD||''')
								  AND EXTE_WARR_TYPE = decode('''||:CB_DUMMY.EW_TYPE||''',''All'',EXTE_WARR_TYPE,'''||:CB_DUMMY.EW_TYPE||''')
								  ';
--AND nvl(EXTE_CANCEL_FLAG,''N'') = ''N'' -- As Diss. with Mr. Anoop all EW show in report	
							  
ELSIF :CB_DUMMY.P_REP_TYPE = 'C' THEN
v_query := 'SELECT ''Extended Warranty Cancellation Details Report'' entire_string FROM DUAL
						UNION ALL
						SELECT ''Dealer Name & Location:  '' ||'''||:CB_DUMMY.CB_DEALER_NAME||''' entire_string FROM DUAL
						UNION ALL
						SELECT ''From Date:  '' ||'''||TO_CHAR(:CB_DUMMY.CONT_FROM_DATE,'MM/DD/RRRR')||'''|| ''    To Date:  '' ||'''||TO_CHAR(:CB_DUMMY.CONT_TO_DATE,'MM/DD/RRRR')||''' ||CHR(10)||CHR(10) entire_string FROM DUAL
						UNION ALL
						SELECT''Region,EW Sale Dlr Code,EW Sale Dlr Name,Location,Policy No,EW Sale Date,Policy Cancellation Date,VIN,VIN Sale Date,Model Code,Model desc,Variant Code,Variant Desc,Warranty Type,Customer Name,Mileage,Expiry Date,Expiry Mileage,Premium Amount,Commission Amount,Service Tax,Cancellation Amount,Credit Amount,Remarks,Status,Sold From'' entire_string FROM DUAL
								 UNION ALL
								SELECT /*+ index (EW MWAR_EXTE_MK14)*-/
											NVL(ALOC.REGION_CD,(SELECT DL.REGION_CD 
                                           FROM AM_DEALER_LOC DL
                                          WHERE DL.MUL_DEALER_CD = EW.EXTE_POLICY_DELR
                                            AND ROWNUM = 1))||'',''||
											NVL(ALOC.dealer_category,''DDL'')||''-''||NVL(EW.EXTE_POLICY_DELR,ALOC.MUL_DEALER_CD)||''-''||NVL(EW.EXTE_POLICY_FOR,ALOC.FOR_CD)||''-''||decode(EW.EXTE_POLICY_SOLD_FROM,''SH'',''01'',NVL(EW.EXTE_POLICY_OUTLET,ALOC.OUTLET_CD))||'',''||
      								nvl(sf_get_dlr_name_loc (EW.EXTE_DEALER_MAP_CD,EW.EXTE_LOC_CD,EW.EXTE_POLICY_DELR),'','')||'',''||											
								      EW.EXTE_POLICY_NO||'',''||
								      to_char(EW.EXTE_CONTRACT_DATE,''MM/DD/RRRR'')||'',''||
								      to_char(EW.EXTE_CANCEL_DT,''MM/DD/RRRR'')||'',''||
								      EW.EXTE_VIN_NO||'',''||
								      to_char(EW.EXTE_RETLSALE_DT,''MM/DD/RRRR'')||'',''||
								      (SELECT gv.model_cd||'',''||replace(gm.model_desc, '','', '' '') 
								         FROM gm_mod gm, gm_vin gv 
								        WHERE gm.model_cd = gv.model_Cd 
								          AND gv.vin = EW.EXTE_VIN_NO)||'',''||								      
								      (SELECT gvn.variant_cd||'',''||replace(gvr.variant_desc, '','', '' '') 
								         FROM gm_var gvr, gm_vin gvn 
								        WHERE gvr.variant_cd = gvn.variant_cd 
								          AND gvn.vin = EW.EXTE_VIN_NO)||'',''||
								      EW.EXTE_WARR_TYPE||'',''||
								      replace(EW.EXTE_CUST_NAME, '','', '' '')||'',''||
								      EW.EXTE_CONTRACT_MILEAGE||'',''||
								      to_char(EW.EXTE_VALID_DATE,''MM/DD/RRRR'')||'',''||
								      EW.EXTE_VALID_MILEAGE||'',''||
								      EW.EXTE_PREMIUM||'',''||
								      EW.EXTE_PREM_DLR_COMM||'',''||
								      EW.EXTE_PREM_SRV_TAX||'',''||
											greatest((EW.EXTE_PREMIUM * 0.1),200)||'',''||
											(EW.EXTE_PREMIUM - EW.EXTE_PREM_DLR_COMM - EW.EXTE_PREM_SRV_TAX - (greatest((EW.EXTE_PREMIUM * 0.1),200)))||'',''||
											replace(replace(replace(EW.EXTE_REMARKS,chr(10),'' ''),chr(13),'' ''),'','','' '')  ||'',''||
											sf_ew_policy_status(EW.EXTE_POLICY_NO)||'',''||
      								decode(EXTE_POLICY_SOLD_FROM,''WS'',''Workshop'',''SH'',''Showroom'')
								FROM
								      MWAR_EXTE EW,
								      AM_DEALER_LOC ALOC
								WHERE
											EXTE_CANCEL_DT >= '''||:CB_DUMMY.CONT_FROM_DATE||'''
								  AND EXTE_CANCEL_DT < '''||lv_to_date||'''
								  AND ALOC.PARENT_GROUP(+) = EXTE_PARENT_GROUP
								  AND ALOC.DEALER_MAP_CD(+) = EXTE_DEALER_MAP_CD
								  AND ALOC.LOC_CD(+) = EXTE_LOC_CD
								  AND EW.EXTE_POLICY_SOLD_FROM = decode('''||:CB_DUMMY.CB_SOLD_FROM||''',''A'',EW.EXTE_POLICY_SOLD_FROM,'''||:CB_DUMMY.CB_SOLD_FROM||''')
									AND nvl(ALOC.REGION_CD,''A'') = decode('''||:CB_DUMMY.CB_REGION||''',''All'',nvl(ALOC.REGION_CD,''A''),'''||:CB_DUMMY.CB_REGION||''')
									AND nvl(EW.EXTE_PARENT_GROUP,''A'') = decode('''||:CB_DUMMY.CB_PARENT||''',''All'',nvl(EW.EXTE_PARENT_GROUP,''A''),'''||:CB_DUMMY.CB_PARENT||''')
								  AND nvl(EW.EXTE_DEALER_MAP_CD,1) = decode('''||:CB_DUMMY.CB_DEALER_MAP_CD||''',''All'',nvl(EW.EXTE_DEALER_MAP_CD,1),'''||:CB_DUMMY.CB_DEALER_MAP_CD||''')
								  AND nvl(EW.EXTE_LOC_CD,''A'') = decode('''||:CB_DUMMY.CB_LOC_CD||''',''All'',nvl(EW.EXTE_LOC_CD,''A''),'''||:CB_DUMMY.CB_LOC_CD||''')
								  AND EXTE_MODL_CODE = decode('''||:CB_DUMMY.BASE_MODEL_CD||''',''All'',EXTE_MODL_CODE,'''||:CB_DUMMY.BASE_MODEL_CD||''')
								  AND nvl(EW.EXTE_VARIANT_CD,''A'') = decode('''||:CB_DUMMY.VARIANT_CD||''',''All'',nvl(EW.EXTE_VARIANT_CD,''A''),'''||:CB_DUMMY.VARIANT_CD||''')
								  AND EXTE_WARR_TYPE = decode('''||:CB_DUMMY.EW_TYPE||''',''All'',EXTE_WARR_TYPE,'''||:CB_DUMMY.EW_TYPE||''')
								  AND nvl(EXTE_CANCEL_FLAG,''N'') = ''Y''';
*/
END IF;
:TEST1 := v_query;
view_excel_rep(lv_filename,v_query,'entire_string');

END;
/*added by bhawana ON 20-MAY-2016 FOR KKC*/
```

#### SP-004 - PROC_REP_XL_PMC2

**Invoked From:**

- vr_exte_warr_msil_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

Search Criteria (N/A / CN_MAIN)

---

**Purpose**

Validates all mandatory search-criteria fields on the Extended Warranty report screen, constructs a report-type-specific dynamic SQL query for new-sale, conversion, or cancellation extended warranty transactions within the given date range and filter criteria, and then exports the result to a user-specific CSV file on the client machine via `VIEW_EXCEL_REP`.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.CHECK_NULL ([SP-006](#SP-006--GENERAL.CHECK_NULL)) - matched by member name (package unresolved)
- VIEW_EXCEL_REP ([SP-005](#SP-005--VIEW_EXCEL_REP)) - JSON-LD ProgramUnit

---

**Step-by-Step Business Logic**

- Step 1 - Validate that `CB_LOC_DESC` (Location) is not null; if it is, call `CHECK_NULL` to display a mandatory-field message and navigate focus to the field, then stop.
- Step 2 - Validate that `P_REP_TYPE` (Extended Warranty Status) is not null; if it is, call `CHECK_NULL` and navigate focus to the field, then stop.
- Step 3 - Validate that `CONT_FROM_DATE` (Contract From Date) is not null; if it is, call `CHECK_NULL` and navigate focus to the field, then stop.
- Step 4 - Validate that `CONT_TO_DATE` (Contract To Date) is not null; if it is, call `CHECK_NULL` and navigate focus to the field, then stop.
- Step 5 - Validate that `BASE_MODEL_CD` (Model) is not null; if it is, call `CHECK_NULL` and navigate focus to the field, then stop.
- Step 6 - Validate that `VARIANT_CD` (Variant) is not null; if it is, call `CHECK_NULL` and navigate focus to the field, then stop.
- Step 7 - Validate that `EW_TYPE` (Extended Warranty Type) is not null; if it is, call `CHECK_NULL` and navigate focus to the field, then stop.
- Step 8 - Resolve the dealer display name: if the parent-group filter is `'All'`, set `CB_DEALER_NAME` to the literal `'All Dealers (All locations)'`; otherwise query `AM_DEALER_LOC` for the matching active dealer/location record and format the name as `'<DEALER_NAME>( <LOC_DESC> )'`. Any query exception is silently swallowed.
- Step 9 - Compose the output filename as `<userid>_<YYYYMMDDHH24MISS>.csv`.
- Step 10 - Compute the exclusive upper-bound date `lv_to_date` as `CONT_TO_DATE + 1` day.
- Step 11 - Normalise the vendor filter: if the `vend` field is not `'CWI'` or `'GAN'`, set `v_vend` to `'All'`.
- Step 12 - Based on `P_REP_TYPE`, build one of three dynamic SQL queries:
  - **`'N'` (New Sale):** Produce a CSV with header rows (title, dealer name, date range, column headings) followed by new-sale EW transaction rows from `DMSD_EW_SALE_SM`, `MWAR_EXTE`, and `AM_DEALER_LOC`, enriched with model descriptions from `GM_MOD`, variant descriptions from `GM_VAR`, and employee names from `GM_EMP`; filtered to `EXTE_TRAN_TYPE = 'N'`.
  - **`'U'` (Conversion/Upgrade):** Produce a CSV with conversion-specific header and column headings, joining the same tables but filtered to `EXTE_TRAN_TYPE IN ('U','X','Z')`, resolving model/variant via the VIN through `GM_VIN`, and reporting conversion-specific fields.
  - **`'C'` (Cancellation):** Produce a CSV with cancellation-specific header and column headings, filtered to `EXTE_TRAN_TYPE = 'C'`, using an outer join to `AM_DEALER_LOC`, and computing cancellation amounts as `GREATEST(EXTE_POLICY_PREMIUM * 0.1, 200)` with proportional GST components.
- Step 13 - Store the assembled query in the form item `:TEST1` for diagnostic/debugging purposes.
- Step 14 - Call `VIEW_EXCEL_REP` with the filename, the dynamic query, and the column alias `'entire_string'` to execute the query and write the CSV file to the client.

---
**Decision Points**

DP-001

Condition:
`CB_LOC_DESC` is null.

TRUE:
Call `CHECK_NULL` with label `'Location'`, navigate focus to `cb_dummy.CB_LOC_DESC`, and exit the procedure.

FALSE:
Continue to the next mandatory-field check.

DP-002

Condition:
`P_REP_TYPE` is null.

TRUE:
Call `CHECK_NULL` with label `'Extended Warranty Status'`, navigate focus to `cb_dummy.P_REP_TYPE`, and exit the procedure.

FALSE:
Continue to the next mandatory-field check.

DP-003

Condition:
`CONT_FROM_DATE` is null.

TRUE:
Call `CHECK_NULL` with label `'Contract From Date'`, navigate focus to `cb_dummy.CONT_FROM_DATE`, and exit the procedure.

FALSE:
Continue to the next mandatory-field check.

DP-004

Condition:
`CONT_TO_DATE` is null.

TRUE:
Call `CHECK_NULL` with label `'Contract To Date'`, navigate focus to `cb_dummy.CONT_TO_DATE`, and exit the procedure.

FALSE:
Continue to the next mandatory-field check.

DP-005

Condition:
`BASE_MODEL_CD` is null.

TRUE:
Call `CHECK_NULL` with label `'Model'`, navigate focus to `cb_dummy.BASE_MODEL_CD`, and exit the procedure.

FALSE:
Continue to the next mandatory-field check.

DP-006

Condition:
`VARIANT_CD` is null.

TRUE:
Call `CHECK_NULL` with label `'Variant'`, navigate focus to `cb_dummy.VARIANT_CD`, and exit the procedure.

FALSE:
Continue to the next mandatory-field check.

DP-007

Condition:
`EW_TYPE` is null.

TRUE:
Call `CHECK_NULL` with label `'Extended Warranty Type'`, navigate focus to `cb_dummy.EW_TYPE`, and exit the procedure.

FALSE:
All mandatory fields are present; proceed to build the dealer name and the query.

DP-008

Condition:
`CB_PARENT` equals `'All'`.

TRUE:
Set `CB_DEALER_NAME` to the literal `'All Dealers (All locations)'` without querying the database.

FALSE:
Query `AM_DEALER_LOC` to resolve the specific dealer name and location description; any exception is silently ignored.

DP-009

Condition:
The vendor filter (`CB_DUMMY.vend`) is `'CWI'` or `'GAN'`.

TRUE:
Use the supplied vendor value as the filter (`v_vend` retains the screen value).

FALSE:
Set `v_vend` to `'All'` so that all vendors are included in the report.

DP-010

Condition:
`P_REP_TYPE` equals `'N'` (New Sale report).

TRUE:
Build the New Sale dynamic SQL query joining `DMSD_EW_SALE_SM`, `MWAR_EXTE`, and `AM_DEALER_LOC`, filtered to `EXTE_TRAN_TYPE = 'N'`.

FALSE:
Evaluate the next report-type branch.

DP-011

Condition:
`P_REP_TYPE` equals `'U'` (Conversion/Upgrade report).

TRUE:
Build the Conversion dynamic SQL query filtered to `EXTE_TRAN_TYPE IN ('U','X','Z')`.

FALSE:
Evaluate the next report-type branch.

DP-012

Condition:
`P_REP_TYPE` equals `'C'` (Cancellation report).

TRUE:
Build the Cancellation dynamic SQL query filtered to `EXTE_TRAN_TYPE = 'C'`, using an outer join to `AM_DEALER_LOC` and computing cancellation amounts.

FALSE:
No query is built; `v_query` remains empty and `VIEW_EXCEL_REP` will be called with an empty string.

---
**Database Interactions**

- DB-001 - Read AM_DEALER_LOC - Reads data from AM_DEALER_LOC for lookup or validation.
- DB-002 - Read DUAL - Reads data from DUAL for lookup or validation.
- DB-003 - Read DATE - Reads data from DATE for lookup or validation.
- DB-004 - Select''Vendor,Region,Dealer DUAL - Accesses DUAL via select''vendor,region,dealer operation.
- DB-005 - Read GM_MOD - Reads data from GM_MOD for lookup or validation.
- DB-006 - Read GM_VAR - Reads data from GM_VAR for lookup or validation.
- DB-007 - Read GM_EMP - Reads data from GM_EMP for lookup or validation.
- DB-008 - Select''Region,Ew DUAL - Accesses DUAL via select''region,ew operation.
- DB-009 - Select''Vendor,Region,Ew DUAL - Accesses DUAL via select''vendor,region,ew operation.
**Business Rules**

- SBR-001 - All seven search-criteria fields (Location, EW Status, Contract From Date, Contract To Date, Model, Variant, EW Type) are mandatory; the report cannot be generated if any one is absent.
- SBR-002 - The To-Date filter is applied as an exclusive upper bound (`CONT_TO_DATE + 1`) so that transactions occurring on the To-Date itself are included in the result set.
- SBR-003 - A vendor filter value other than `'CWI'` or `'GAN'` is treated as `'All'` (include all vendors); only `'CWI'` and `'GAN'` are recognised as specific vendor codes.
- SBR-004 - Warranty type code `'X'` is displayed as `'VIII'` in the CSV output; all other warranty type codes are shown as stored.
- SBR-005 - Cancellation refund amount is computed as `GREATEST(EXTE_POLICY_PREMIUM × 0.1, 200)`, ensuring a minimum cancellation charge of 200 regardless of the original premium; GST components are derived by applying the stored GST rates to this amount.
- SBR-006 - The output filename is unique per user session, composed as `<userid>_<YYYYMMDDHH24MISS>.csv`, preventing filename collisions when multiple users generate reports concurrently.
- SBR-007 - All filter dimensions (parent group, dealer, location, region, vendor, model, variant, EW type, sold-from channel) support an `'All'` wildcard value that disables that dimension's filter via a `DECODE` pattern.
- SBR-008 - Report data is scoped to the logged-in principal (`GLOBAL.PRINCIPAL`) across all table joins, ensuring data isolation between principals.

---
**Implementation Logic**

```plsql
PROCEDURE PROC_REP_XL_PMC2 IS
	v_query  VARCHAR2 (20000);
	lv_filename  VARCHAR2 (5000);
	lv_to_date date;
	v_vend varchar2(10) default 'X';
BEGIN
	IF :CB_DUMMY.CB_LOC_DESC IS NULL THEN
		general.check_null(:cb_dummy.CB_LOC_DESC,'Location');
		go_item('cb_dummy.CB_LOC_DESC');
	END IF;
	IF :CB_DUMMY.P_REP_TYPE IS NULL THEN
	  general.check_null(:cb_dummy.P_REP_TYPE,'Extended Warranty Status');
	  go_item('cb_dummy.P_REP_TYPE');
	END IF;
	IF :CB_DUMMY.CONT_FROM_DATE IS NULL THEN
	  general.check_null(:cb_dummy.CONT_FROM_DATE,'Contract From Date');
	  go_item('cb_dummy.CONT_FROM_DATE');
	END IF;
	IF :CB_DUMMY.CONT_TO_DATE IS NULL THEN
	  general.check_null(:cb_dummy.CONT_TO_DATE,'Contract To Date');
	  go_item('cb_dummy.CONT_TO_DATE');
	END IF;
	IF :CB_DUMMY.BASE_MODEL_CD IS NULL THEN
	  general.check_null(:cb_dummy.BASE_MODEL_CD,'Model');
	  go_item('cb_dummy.BASE_MODEL_CD');
	END IF;
	IF :CB_DUMMY.VARIANT_CD IS NULL THEN
	  general.check_null(:cb_dummy.VARIANT_CD,'Variant');
	  go_item('cb_dummy.VARIANT_CD');
	END IF;
	IF :CB_DUMMY.EW_TYPE IS NULL THEN
	  general.check_null(:cb_dummy.EW_TYPE,'Extended Warranty Type');
	  go_item('cb_dummy.EW_TYPE');
	END IF;

	BEGIN
		IF :CB_DUMMY.CB_PARENT = 'All' THEN
			:CB_DUMMY.CB_DEALER_NAME := 'All Dealers (All locations)';
		ELSE
			SELECT AM.DEALER_NAME||'( '||AM.LOC_DESC||' )'
			  INTO :CB_DUMMY.CB_DEALER_NAME
				FROM AM_DEALER_LOC AM
			 WHERE AM.PARENT_GROUP = decode(:CB_DUMMY.CB_PARENT,'All',AM.PARENT_GROUP,:CB_DUMMY.CB_PARENT)
				 AND AM.DEALER_MAP_CD = decode(:CB_DUMMY.CB_DEALER_MAP_CD,'All',AM.DEALER_MAP_CD,:CB_DUMMY.CB_DEALER_MAP_CD)
				 AND AM.LOC_CD = decode(:CB_DUMMY.CB_LOC_CD,'All',AM.LOC_CD,:CB_DUMMY.CB_LOC_CD)
				 AND nvl(msil_terminated_date, sysdate) >= sysdate
			 	and am.principal_map_cd=:global.principal;/*added by bhawana*/
		END IF;
	EXCEPTION
		WHEN OTHERS THEN
		null;
	END;

	lv_filename:=:global.userid||'_'||to_char(sysdate,'RRRRMMDDHH24MISS')||'.csv';

	lv_to_date := to_date(:CB_DUMMY.CONT_TO_DATE) + 1;
	v_vend:=:CB_DUMMY.vend;
	if nvl(:CB_DUMMY.vend,'X') not in ('CWI','GAN') then
	  v_vend := 'All';
	end if;		

--IF :CB_DUMMY.CB_REPORT_TYPE = 'D' THEN
--EW.EXTE_WARR_TYPE||'',''||
--to_char(EW.EXTE_VALID_DATE,''MM/DD/RRRR'')||'',''||
--EW.EXTE_VALID_MILEAGE||'',''||
IF :CB_DUMMY.P_REP_TYPE = 'N' THEN
v_query := 'SELECT ''Extended Warranty Sale Details Report'' entire_string FROM DUAL
						UNION ALL
						SELECT ''Dealer Name & Location:  '' ||'''||:CB_DUMMY.CB_DEALER_NAME||''' entire_string FROM DUAL
						UNION ALL
						SELECT ''From Date:  '' ||'''||TO_CHAR(:CB_DUMMY.CONT_FROM_DATE,'MM/DD/RRRR')||'''|| ''    To Date:  '' ||'''||TO_CHAR(:CB_DUMMY.CONT_TO_DATE,'MM/DD/RRRR')||''' ||CHR(10)||CHR(10) entire_string FROM DUAL
						UNION ALL
						SELECT''Vendor,Region,Dealer Code,Dealer Name,Location,Policy No,EW Sale Date,VIN,VIN Sale Date,Model Code,Model desc,Variant Code,Variant Desc,Customer Name,Mileage,Warranty Type,Expiry Date,Expiry Mileage,Premium Amount,CGST Amount,SGST Amount,IGST Amount, Commission Amount,CGST Commission,SGST Commission,IGST Commission,Sold By,Status,Sold From,Service Advisor/DSE,Service Advisor/DSE Name'' entire_string FROM DUAL
								 UNION ALL
								SELECT /*+ index (EW MWAR_EXTE_MK5)*/	
								      nvl(xw.vend_cd,''CWI'')||'',''||ALOC.region_cd||'',''||
								      ALOC.dealer_category||''-''||EW.EXTE_POLICY_DELR||''-''||EW.EXTE_POLICY_FOR||''-''||decode(EW.EXTE_POLICY_SOLD_FROM,''SH'',''01'',EW.EXTE_POLICY_OUTLET)||'',''||
      								nvl(sf_get_dlr_name_loc (EW.EXTE_DEALER_MAP_CD,EW.EXTE_LOC_CD,EW.EXTE_POLICY_DELR,'''||:global.principal||'''),'','')||'',''||
								      EW.EXTE_POLICY_NO||'',''||
								      to_char(EW.EXTE_CONTRACT_DATE,''DD-MM-YYYY'')||'',''||
								      EW.EXTE_VIN_NO||'',''||
								      to_char(EW.EXTE_RETLSALE_DT,''DD-MM-YYYY'')||'',''||
								      XW.EXTE_MODL_CODE||'',''||
								      (SELECT replace(gm.model_desc, '','', '' '') FROM gm_mod gm WHERE gm.model_cd = xw.exte_modl_code 
								      and gm.principal_map_cd='''||:global.principal||''')||'',''||
								      XW.EXTE_VARIANT_CD||'',''||
								      (SELECT replace(gv.variant_desc, '','', '' '') FROM gm_var gv WHERE gv.variant_cd = xw.exte_variant_cd 
								      and gv.principal_map_cd='''||:global.principal||''')||'',''||
								      replace(EW.EXTE_CUST_NAME, '','', '' '')||'',''||
								      EW.EXTE_CONTRACT_MILEAGE||'',''||
										/*SF_GET_EW_VALIDITY_DTL(EW.EXTE_POLICY_NO,'''||:CB_DUMMY.P_REP_TYPE||''')||'',''||  blocked by shailesh on 30.05.2019 DMSSERV(S)-13305 */
											DECODE(EW.EXTE_WARR_TYPE,''X'',''VIII'',EW.EXTE_WARR_TYPE)||'',''||
											to_char(EW.EXTE_VALID_DATE,''DD-MM-YYYY'')||'',''||
								      EW.EXTE_VALID_MILEAGE||'',''||
								      EW.EXTE_POLICY_PREMIUM||'',''||
								      nvl(EW.EXTE_PREM_CGST_AMT,0)||'',''||
								      nvl(EW.EXTE_PREM_SGST_AMT,0)||'',''||
								      nvl(EW.EXTE_PREM_IGST_AMT,0)||'',''||
								      NVL(EW.EXTE_COMMISION_AMT,0)||'',''||
								      NVL(EW.EXTE_PREM_COMM_CGST,0)||'',''||
								      nvl(EW.EXTE_PREM_COMM_SGST,0)||'',''||
								      nvl(EW.EXTE_PREM_COMM_IGST,0)||'',''||
								      XW.EXTE_CREATED_BY||'',''||
      								sf_ew_policy_status(EW.EXTE_POLICY_NO)||'',''||
      								decode(xw.EXTE_POLICY_SOLD_FROM,''WS'',''Workshop'',''SH'',''Showroom'')||'',''||
      								EW.EXTE_EMP_CD||'',''||
      							 (SELECT EMP_NAME FROM GM_EMP WHERE DEALER_MAP_CD = ew.EXTE_DEALER_MAP_CD AND EMP_CD = EW.EXTE_EMP_CD) 
								FROM  DMSD_EW_SALE_SM EW,
								      MWAR_EXTE XW,
								      AM_DEALER_LOC ALOC
								WHERE ew.exte_policy_no=xw.exte_policy_no
									AND	ew.exte_transaction_date >= '''||:CB_DUMMY.CONT_FROM_DATE||'''
								  AND ew.exte_transaction_date < '''||lv_to_date||'''
								  and EW.EXTE_TRAN_TYPE =''N''
								  AND ALOC.PARENT_GROUP = EW.EXTE_PARENT_GROUP
								  AND ALOC.DEALER_MAP_CD = EW.EXTE_DEALER_MAP_CD
								  AND ALOC.LOC_CD = EW.EXTE_LOC_CD
								  AND ALOC.PRINCIPAL_MAP_CD='''||:GLOBAL.PRINCIPAL||'''
									AND EW.EXTE_POLICY_SOLD_FROM = decode('''||:CB_DUMMY.CB_SOLD_FROM||''',''A'',EW.EXTE_POLICY_SOLD_FROM,'''||:CB_DUMMY.CB_SOLD_FROM||''')
									AND ALOC.REGION_CD = decode('''||:CB_DUMMY.CB_REGION||''',''All'',ALOC.REGION_CD,'''||:CB_DUMMY.CB_REGION||''')
									AND nvl(xw.vend_cd,''CWI'') = decode('''||v_vend||''',''All'',	nvl(xw.vend_cd,''CWI''),'''||v_vend||''')
									AND EW.EXTE_PARENT_GROUP = decode('''||:CB_DUMMY.CB_PARENT||''',''All'',EW.EXTE_PARENT_GROUP,'''||:CB_DUMMY.CB_PARENT||''')
								  AND EW.EXTE_DEALER_MAP_CD = decode('''||:CB_DUMMY.CB_DEALER_MAP_CD||''',''All'',EW.EXTE_DEALER_MAP_CD,'''||:CB_DUMMY.CB_DEALER_MAP_CD||''')
								  AND EW.EXTE_LOC_CD = decode('''||:CB_DUMMY.CB_LOC_CD||''',''All'',EW.EXTE_LOC_CD,'''||:CB_DUMMY.CB_LOC_CD||''')
								  AND XW.EXTE_MODL_CODE = decode('''||:CB_DUMMY.BASE_MODEL_CD||''',''All'',XW.EXTE_MODL_CODE,'''||:CB_DUMMY.BASE_MODEL_CD||''')
								  AND XW.EXTE_VARIANT_CD = decode('''||:CB_DUMMY.VARIANT_CD||''',''All'',XW.EXTE_VARIANT_CD,'''||:CB_DUMMY.VARIANT_CD||''')
								  AND EW.EXTE_WARR_TYPE = decode('''||:CB_DUMMY.EW_TYPE||''',''All'',EW.EXTE_WARR_TYPE,'''||:CB_DUMMY.EW_TYPE||''')
								  ';
--AND nvl(EXTE_CANCEL_FLAG,''N'') = ''N'' -- As Diss. with Mr. Anoop all EW show in report

ELSIF :CB_DUMMY.P_REP_TYPE = 'U' THEN
v_query := 'SELECT ''Extended Warranty Conversion Details Report'' entire_string FROM DUAL
						UNION ALL
						SELECT ''Dealer Name & Location:  '' ||'''||:CB_DUMMY.CB_DEALER_NAME||''' entire_string FROM DUAL
						UNION ALL
						SELECT ''Vendor,From Date:  '' ||'''||TO_CHAR(:CB_DUMMY.CONT_FROM_DATE,'MM/DD/RRRR')||'''|| ''    To Date:  '' ||'''||TO_CHAR(:CB_DUMMY.CONT_TO_DATE,'MM/DD/RRRR')||''' ||CHR(10)||CHR(10) entire_string FROM DUAL
						UNION ALL
						SELECT''Region,EW Sale Dlr Code,EW Sale Dlr Name,Location,Conv. Dealer Code,Conv. Dealer Name,Conv. Location,Policy No,EW Sale Date,Conv. Date,VIN,VIN Sale Date,Model Code,Model desc,Variant Code,Variant Desc,Warranty Type,Customer Name,Mileage,Expiry Date,Expiry Mileage,Diff. Premium Amount,CGST Diff Premium,SGST Diff Premium, IGST Diff Premium,Diff. Comm. Amount,CGST Commission,SGST Commission,IGST Commission,Upgraded By,Status,Conversion From,Service Advisor/DSE,Service Advisor/DSE Name'' entire_string FROM DUAL
								 UNION ALL
								SELECT  /*+ index (EW MWAR_EXTE_MK9)*/										
											nvl(xw.vend_cd,''CWI'')||'',''||ALOC.region_cd||'',''||
											ALOC.dealer_category||''-''||EW.EXTE_POLICY_DELR||''-''||EW.EXTE_POLICY_FOR||''-''||decode(EW.EXTE_POLICY_SOLD_FROM,''SH'',''01'',EW.EXTE_POLICY_OUTLET)||'',''||
      								nvl(sf_get_dlr_name_loc (EW.EXTE_DEALER_MAP_CD,EW.EXTE_LOC_CD,EW.EXTE_POLICY_DELR,'''||:global.principal||'''),'','')||'',''||
      								ALOC.dealer_category||''-''||EW.EXTE_CONV_DELR||''-''||EW.EXTE_CONV_FOR||''-''||decode(EW.EXTE_CONV_FROM,''SH'',''01'',EW.EXTE_CONV_OUTLET)||'',''||
      								nvl(sf_get_dlr_name_loc (EW.EXTE_CONV_DEALER_MAP_CD,EW.EXTE_CONV_LOC_CD,EW.EXTE_CONV_DELR,'''||:global.principal||'''),'','')||'',''||
      								EW.EXTE_POLICY_NO||'',''||
      								to_char(EW.EXTE_CONTRACT_DATE,''DD-MM-YYYY'')||'',''||
								      to_char(EW.EXTE_CONV_DATE,''DD-MM-YYYY'')||'',''||
								      EW.EXTE_VIN_NO||'',''||
								      to_char(EW.EXTE_RETLSALE_DT,''DD-MM-YYYY'')||'',''||
								      (SELECT gv.model_cd||'',''||replace(gm.model_desc, '','', '' '') 
								         FROM gm_mod gm, gm_vin gv 
								        WHERE gm.model_cd = gv.model_Cd 
								          AND gv.vin = EW.EXTE_VIN_NO 
								          and gm.principal_map_cd='''||:global.principal||'''
								          and gm.principal_map_cd=gv.principal_map_cd)||'',''||								      
								      (SELECT gvn.variant_cd||'',''||replace(gvr.variant_desc, '','', '' '') 
								         FROM gm_var gvr, gm_vin gvn 
								        WHERE gvr.variant_cd = gvn.variant_cd 
								          AND gvn.vin = EW.EXTE_VIN_NO
								          and gvr.principal_map_cd='''||:global.principal||'''
								          and gvr.principal_map_cd=gvn.principal_map_cd)||'',''||
								      	DECODE(EW.EXTE_WARR_TYPE,''X'',''VIII'',EW.EXTE_WARR_TYPE)||'',''||
								      replace(EW.EXTE_CUST_NAME, '','', '' '')||'',''||
								      EW.EXTE_CONV_MILEAGE||'',''||
								      to_char(EW.EXTE_VALID_DATE,''DD-MM-YYYY'')||'',''||
								      EW.EXTE_VALID_MILEAGE||'',''||
								      EW.exte_premium_recd||'',''||
								      nvl(EW.EXTE_PREM_CGST_AMT,0)||'',''||
								      nvl(EW.EXTE_PREM_SGST_AMT,0)||'',''||
								      nvl(EW.EXTE_PREM_IGST_AMT,0)||'',''||
								      NVL(EW.EXTE_COMMISION_AMT,0)||'',''||
								      NVL(EW.EXTE_PREM_COMM_CGST,0)||'',''||
								      NVL(EW.EXTE_PREM_COMM_SGST,0)||'',''||
								      NVL(EW.EXTE_PREM_COMM_IGST,0)||'',''||
								      XW.EXTE_MODIFIED_BY||'',''||
								      sf_ew_policy_status(EW.EXTE_POLICY_NO)||'',''||
      								decode(XW.EXTE_CONV_FROM,''WS'',''Workshop'',''SH'',''Showroom'')||'',''||
      								EW.EXTE_CONV_EMP_CD||'',''||
      								(SELECT EMP_NAME FROM GM_EMP WHERE DEALER_MAP_CD = ew.EXTE_CONV_DEALER_MAP_CD AND EMP_CD = 	EW.EXTE_CONV_EMP_CD) 
								FROM  DMSD_EW_SALE_SM EW,
								      MWAR_EXTE XW,
								      AM_DEALER_LOC ALOC
								WHERE ew.exte_policy_no=xw.exte_policy_no
                  and ew.exte_transaction_date >= '''||:CB_DUMMY.CONT_FROM_DATE||'''
                  AND ew.exte_transaction_date < '''||lv_to_date||'''
                  and EW.EXTE_TRAN_TYPE IN (''U'',''X'',''Z'')
								  AND ALOC.PARENT_GROUP = EW.EXTE_CONV_PARENT_GROUP
								  AND ALOC.DEALER_MAP_CD = EW.EXTE_CONV_DEALER_MAP_CD
								  AND ALOC.LOC_CD = EW.EXTE_CONV_LOC_CD
								  AND ALOC.PRINCIPAL_MAP_CD='''||:GLOBAL.PRINCIPAL||'''
								  AND NVL(EW.EXTE_CONV_FROM,''X'') = decode('''||:CB_DUMMY.CB_SOLD_FROM||''',''A'',NVL(EW.EXTE_CONV_FROM,''X''),'''||:CB_DUMMY.CB_SOLD_FROM||''')
								  AND nvl(ALOC.REGION_CD,''A'') = decode('''||:CB_DUMMY.CB_REGION||''',''All'',nvl(ALOC.REGION_CD,''A''),'''||:CB_DUMMY.CB_REGION||''')
								  	AND nvl(xw.vend_cd,''CWI'') = decode('''||v_vend||''',''All'',	nvl(xw.vend_cd,''CWI''),'''||v_vend||''')
									AND nvl(EW.EXTE_CONV_PARENT_GROUP,''A'') = decode('''||:CB_DUMMY.CB_PARENT||''',''All'',nvl(EW.EXTE_CONV_PARENT_GROUP,''A''),'''||:CB_DUMMY.CB_PARENT||''')
								  AND nvl(EW.EXTE_CONV_DEALER_MAP_CD,1) = decode('''||:CB_DUMMY.CB_DEALER_MAP_CD||''',''All'',nvl(EW.EXTE_CONV_DEALER_MAP_CD,1),'''||:CB_DUMMY.CB_DEALER_MAP_CD||''')
								  AND nvl(EW.EXTE_CONV_LOC_CD,''A'') = decode('''||:CB_DUMMY.CB_LOC_CD||''',''All'',nvl(EW.EXTE_CONV_LOC_CD,''A''),'''||:CB_DUMMY.CB_LOC_CD||''')
								  AND XW.EXTE_MODL_CODE = decode('''||:CB_DUMMY.BASE_MODEL_CD||''',''All'',XW.EXTE_MODL_CODE,'''||:CB_DUMMY.BASE_MODEL_CD||''')
								  AND nvl(XW.EXTE_VARIANT_CD,''A'') = decode('''||:CB_DUMMY.VARIANT_CD||''',''All'',nvl(XW.EXTE_VARIANT_CD,''A''),'''||:CB_DUMMY.VARIANT_CD||''')
								  AND EW.EXTE_WARR_TYPE = decode('''||:CB_DUMMY.EW_TYPE||''',''All'',EW.EXTE_WARR_TYPE,'''||:CB_DUMMY.EW_TYPE||''')
								  ';
--AND nvl(EXTE_CANCEL_FLAG,''N'') = ''N'' -- As Diss. with Mr. Anoop all EW show in report	
							  
ELSIF :CB_DUMMY.P_REP_TYPE = 'C' THEN
v_query := 'SELECT ''Extended Warranty Cancellation Details Report'' entire_string FROM DUAL
						UNION ALL
						SELECT ''Dealer Name & Location:  '' ||'''||:CB_DUMMY.CB_DEALER_NAME||''' entire_string FROM DUAL
						UNION ALL
						SELECT ''From Date:  '' ||'''||TO_CHAR(:CB_DUMMY.CONT_FROM_DATE,'MM/DD/RRRR')||'''|| ''    To Date:  '' ||'''||TO_CHAR(:CB_DUMMY.CONT_TO_DATE,'MM/DD/RRRR')||''' ||CHR(10)||CHR(10) entire_string FROM DUAL
						UNION ALL
						SELECT''Vendor,Region,EW Sale Dlr Code,EW Sale Dlr Name,Location,Policy No,EW Sale Date,Policy Cancellation Date,VIN,VIN Sale Date,Model Code,Model desc,Variant Code,Variant Desc,Warranty Type,Customer Name,Mileage,Expiry Date,Expiry Mileage,Premium Amount,CGST Premium,SGST Premium,IGST Premium, Commission Amount,CGST Commission,SGST Commission,IGST Commission,Cancellation Amount,Remarks,Status,Sold From,Service Advisor/DSE,Service Advisor/DSE Name'' entire_string FROM DUAL
								 UNION ALL
								SELECT /*+ index (EW MWAR_EXTE_MK14)*/
										nvl(xw.vend_cd,''CWI'')||'',''||	NVL(ALOC.REGION_CD,(SELECT DL.REGION_CD 
                                           FROM AM_DEALER_LOC DL
                                          WHERE DL.MUL_DEALER_CD = EW.EXTE_POLICY_DELR
                                            and DL.PRINCIPAL_MAP_CD='''||:GLOBAL.PRINCIPAL||'''
                                            AND ROWNUM = 1 ))||'',''||
											NVL(ALOC.dealer_category,''DDL'')||''-''||NVL(EW.EXTE_POLICY_DELR,ALOC.MUL_DEALER_CD)||''-''||NVL(EW.EXTE_POLICY_FOR,ALOC.FOR_CD)||''-''||decode(EW.EXTE_POLICY_SOLD_FROM,''SH'',''01'',NVL(EW.EXTE_POLICY_OUTLET,ALOC.OUTLET_CD))||'',''||
      								nvl(sf_get_dlr_name_loc (EW.EXTE_DEALER_MAP_CD,EW.EXTE_LOC_CD,EW.EXTE_POLICY_DELR,'''||:global.principal||'''),'','')||'',''||											
								      EW.EXTE_POLICY_NO||'',''||
								      to_char(EW.EXTE_CONTRACT_DATE,''DD-MM-YYYY'')||'',''||
								      to_char(EW.EXTE_CANCEL_DT,''DD-MM-YYYY'')||'',''||
								      EW.EXTE_VIN_NO||'',''||
								      to_char(EW.EXTE_RETLSALE_DT,''DD-MM-YYYY'')||'',''||
								      (SELECT gv.model_cd||'',''||replace(gm.model_desc, '','', '' '') 
								         FROM gm_mod gm, gm_vin gv 
								        WHERE gm.model_cd = gv.model_Cd 
								          AND gv.vin = EW.EXTE_VIN_NO
								          and gm.principal_map_cd='''||:global.principal||'''
								          and gm.principal_map_cd=gv.principal_map_cd)||'',''||								      
								      (SELECT gvn.variant_cd||'',''||replace(gvr.variant_desc, '','', '' '') 
								         FROM gm_var gvr, gm_vin gvn 
								        WHERE gvr.variant_cd = gvn.variant_cd 
								          AND gvn.vin = EW.EXTE_VIN_NO
								             and gvr.principal_map_cd='''||:global.principal||'''
								          and gvr.principal_map_cd=gvn.principal_map_cd )||'',''||
								      	DECODE(EW.EXTE_WARR_TYPE,''X'',''VIII'',EW.EXTE_WARR_TYPE)||'',''||
								      replace(EW.EXTE_CUST_NAME, '','', '' '')||'',''||
								      EW.EXTE_CONTRACT_MILEAGE||'',''||
								      to_char(EW.EXTE_VALID_DATE,''DD-MM-YYYY'')||'',''||
								      EW.EXTE_VALID_MILEAGE||'',''||
								      EW.EXTE_POLICY_PREMIUM||'',''||
								      (greatest((EW.EXTE_POLICY_PREMIUM * 0.1),200)*EW.EXTE_PREM_CGST_RATE/100)||'',''||
                     (greatest((EW.EXTE_POLICY_PREMIUM * 0.1),200)*EW.EXTE_PREM_SGST_RATE/100)||'',''||
                     (greatest((EW.EXTE_POLICY_PREMIUM * 0.1),200)*EW.EXTE_PREM_IGST_RATE/100)||'',''||  
								      EW.EXTE_COMMISION_AMT||'',''||
								      EW.EXTE_PREM_COMM_CGST||'',''||
								      NVL(EW.EXTE_PREM_COMM_SGST,0)||'',''||
								      NVL(EW.EXTE_PREM_COMM_IGST,0)||'',''||
											greatest((EW.EXTE_POLICY_PREMIUM * 0.1),200)||'',''||
											replace(replace(replace(XW.EXTE_REMARKS,chr(10),'' ''),chr(13),'' ''),'','','' '')  ||'',''||
											sf_ew_policy_status(EW.EXTE_POLICY_NO)||'',''||
      								decode(XW.EXTE_POLICY_SOLD_FROM,''WS'',''Workshop'',''SH'',''Showroom'')||'',''||
      								nvl(EW.EXTE_EMP_CD,EW.EXTE_CONV_EMP_CD)||'',''||
      								DECODE( EW.EXTE_EMP_CD,NULL,(SELECT EMP_NAME FROM GM_EMP WHERE DEALER_MAP_CD = ew.EXTE_CONV_DEALER_MAP_CD AND EMP_CD = 	EW.EXTE_CONV_EMP_CD),
      								        (SELECT EMP_NAME FROM GM_EMP WHERE DEALER_MAP_CD = ew.EXTE_DEALER_MAP_CD AND EMP_CD = EW.EXTE_EMP_CD)
      								       ) 
								FROM DMSD_EW_SALE_SM EW,
								      MWAR_EXTE XW,
								      AM_DEALER_LOC ALOC
								WHERE EW.EXTE_POLICY_NO=XW.EXTE_POLICY_NO
                  AND  EW.EXTE_TRANSACTION_DATE >= '''||:CB_DUMMY.CONT_FROM_DATE||'''
                  AND EW.EXTE_TRANSACTION_DATE <  '''||lv_to_date||'''
                  AND EW.EXTE_TRAN_TYPE =''C''
								  AND ALOC.PARENT_GROUP(+) = EW.EXTE_PARENT_GROUP
								  AND ALOC.DEALER_MAP_CD(+) = EW.EXTE_DEALER_MAP_CD
								  AND ALOC.LOC_CD(+) = EW.EXTE_LOC_CD
								  AND ALOC.PRINCIPAL_MAP_CD='''||:GLOBAL.PRINCIPAL||'''
								  AND EW.EXTE_POLICY_SOLD_FROM = decode('''||:CB_DUMMY.CB_SOLD_FROM||''',''A'',EW.EXTE_POLICY_SOLD_FROM,'''||:CB_DUMMY.CB_SOLD_FROM||''')
									AND nvl(ALOC.REGION_CD,''A'') = decode('''||:CB_DUMMY.CB_REGION||''',''All'',nvl(ALOC.REGION_CD,''A''),'''||:CB_DUMMY.CB_REGION||''')
										AND nvl(xw.vend_cd,''CWI'') = decode('''||v_vend||''',''All'',	nvl(xw.vend_cd,''CWI''),'''||v_vend||''')
									AND nvl(EW.EXTE_PARENT_GROUP,''A'') = decode('''||:CB_DUMMY.CB_PARENT||''',''All'',nvl(EW.EXTE_PARENT_GROUP,''A''),'''||:CB_DUMMY.CB_PARENT||''')
								  AND nvl(EW.EXTE_DEALER_MAP_CD,1) = decode('''||:CB_DUMMY.CB_DEALER_MAP_CD||''',''All'',nvl(EW.EXTE_DEALER_MAP_CD,1),'''||:CB_DUMMY.CB_DEALER_MAP_CD||''')
								  AND nvl(EW.EXTE_LOC_CD,''A'') = decode('''||:CB_DUMMY.CB_LOC_CD||''',''All'',nvl(EW.EXTE_LOC_CD,''A''),'''||:CB_DUMMY.CB_LOC_CD||''')
								  AND XW.EXTE_MODL_CODE = decode('''||:CB_DUMMY.BASE_MODEL_CD||''',''All'',XW.EXTE_MODL_CODE,'''||:CB_DUMMY.BASE_MODEL_CD||''')
								  AND nvl(XW.EXTE_VARIANT_CD,''A'') = decode('''||:CB_DUMMY.VARIANT_CD||''',''All'',nvl(XW.EXTE_VARIANT_CD,''A''),'''||:CB_DUMMY.VARIANT_CD||''')
								  AND EW.EXTE_WARR_TYPE = decode('''||:CB_DUMMY.EW_TYPE||''',''All'',EW.EXTE_WARR_TYPE,'''||:CB_DUMMY.EW_TYPE||''')
								 ';

END IF;
:TEST1 := v_query;
view_excel_rep(lv_filename,v_query,'entire_string');

END;
/*added by bhawana ON 20-MAY-2016 FOR KKC*/
```

#### SP-005 - VIEW_EXCEL_REP

**Invoked From:**

- vr_exte_warr_msil_fmb.xml [ProgramUnit: PROC_REP_XL_PMC1]
- vr_exte_warr_msil_fmb.xml [ProgramUnit: PROC_REP_XL_PMC2]
- vr_exte_warr_msil_fmb.xml [StoredProcedure: PROC_REP_XL_PMC1]
- vr_exte_warr_msil_fmb.xml [StoredProcedure: PROC_REP_XL_PMC2]

---

**Screen:**

Search Criteria (N/A / CN_MAIN)

---

**Purpose**

Executes a caller-supplied SQL query, writes its single-column result set line by line to a CSV file on the application server, and then opens the file in the user's browser as a downloadable report. It is the common export engine used by all Excel report procedures in the form.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_file_name | VARCHAR2 | IN |
| p_query | VARCHAR2 | IN |
| p_column_name | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.FCLOSE ([SP-012](#SP-012--WEBUTIL.FCLOSE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.FOPEN ([SP-013](#SP-013--WEBUTIL.FOPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_LINE ([SP-016](#SP-016--WEBUTIL.GET_LINE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ID_NULL ([SP-017](#SP-017--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.PUT_LINE ([SP-018](#SP-018--WEBUTIL.PUT_LINE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Derive the output filename: read the current user ID from `:global.userid`, append the current timestamp formatted as `YYYYMMDDHHMISS`, and suffix `.csv`.
- Step 2 - If the derived filename contains a space in any folder name, redirect the file path to the `C:\` root drive and display an informational message to the user.
- Step 3 - Delete any pre-existing Oracle Forms record group named `'DataRecordSet'` to start clean.
- Step 4 - Create a new record group `'DataRecordSet'` from the caller-supplied SQL query (`p_query`) and populate it.
- Step 5 - Retrieve the row count of the populated record group.
- Step 6 - If the row count exceeds 65,536, cap it at 65,535 and display a message warning the user that the Excel row limit has been reached.
- Step 7 - Determine the server-side file path by reading the base URL path from `/reports/DMS/excelpath.txt` and appending the filename.
- Step 8 - Open the server-side CSV file for writing using `TEXT_IO.FOPEN`.
- Step 9 - Locate the record group column identified by `p_column_name`.
- Step 10 - Loop through each row (up to the capped row count), read the character cell value, and write it as a line to the CSV file using `text_io.put_line`.
- Step 11 - Close the CSV file with `text_io.fclose`.
- Step 12 - Open the generated file URL in the user's browser in a new tab using `web.show_document`.
- Step 13 - On any exception, display an error message including the error code and text, then raise `FORM_TRIGGER_FAILURE`.

---
**Decision Points**

DP-001

Condition:
The derived filename contains a space character (checked via `INSTR(FILENAME,' ') > 0`).

TRUE:
Redirect the save path to the `C:\` drive root, extracting only the filename portion, and notify the user.

FALSE:
Use the filename as derived without modification.

DP-002

Condition:
A record group named `'DataRecordSet'` already exists (`NOT Id_Null(rg_id)`).

TRUE:
Delete the existing record group before creating a new one from the current query.

FALSE:
Proceed directly to create the new record group.

DP-003

Condition:
The populated record group row count exceeds 65,536 rows.

TRUE:
Cap the export at 65,535 rows and display a truncation warning to the user.

FALSE:
Export all rows without truncation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- SBR-001 - The CSV export filename is derived from the current user ID and a timestamp to ensure uniqueness per user per session.
- SBR-002 - The maximum number of rows exported to a CSV file is capped at 65,535 to respect the Excel row limit; any excess rows are silently dropped after a user warning.
- SBR-003 - The application server base path for the output file is read at runtime from `/reports/DMS/excelpath.txt`, allowing the path to be configured without a code change.
- SBR-004 - The generated file is opened directly in the user's browser as a new tab/window, making the CSV immediately accessible without a separate download step.

---
**Implementation Logic**

```plsql
PROCEDURE view_excel_rep(p_file_name VARCHAR2 DEFAULT NULL, p_query VARCHAR2,p_column_name VARCHAR2) IS	
  rg_name 				 		VARCHAR2(40) := 'DataRecordSet'; 
	rg_id 					 		RecordGroup; 
	gc_id 					 		GroupColumn; 
	urlFile1        TEXT_IO.FILE_TYPE;
	the_rowcount 		 		NUMBER;
	po_tot_rec    NUMBER (6);
	--po_part_tab   pk_part_search_new.part_tab_10;
	po_part_tab   pk_part_search_new.part_tab_11;
	po_err_msg    VARCHAR2 (3000);
	po_err_cd     NUMBER (10);
	low           NUMBER (10);
	high          NUMBER (10);
	remainder     NUMBER (10);
	order_by      VARCHAR2 (300);
	vcfile        varchar2(150);
	lv_user       varchar2(150);
	l_Old_URL     varchar2(500);	
		l_new_URL   varchar2(500);	
	v_string      varchar2(5000);
	bin_str       varchar2(250);
	errcode 				 		NUMBER; 
  FILENAME			   		VARCHAR2(4000);
  MYFILE 					 		TEXT_IO.FILE_TYPE;
  urlFile 					 	TEXT_IO.FILE_TYPE;
  urlPath							VARCHAR2(5000);
	l_alert 				 		NUMBER;
	server_file      		VARCHAR2(2000);
	file_transfer_bool	BOOLEAN;
	formserverpath   		VARCHAR2(2000);
begin
lv_user := name_in(':global.userid');  -- New line added after dpl change
vcFile:= lv_user||To_Char(Sysdate,'YYYYMMDDHHMISS');    -- New line added after dpl change
vcFile := vcFile||'.csv';
if vcFile is null then
	--FILENAME  := Webutil_file.FILE_SAVE_DIALOG;
	null;
else
	filename:=vcFile;
end if;
	If instr(FILENAME,' ') > 0 then
 		FILENAME := 'C:\'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
 		Message('File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default.');
 		message('  ');
	end if;
	
	rg_id := Find_Group( rg_name ); 
	IF NOT Id_Null(rg_id) THEN 
		Delete_Group( rg_id ); 
	END IF; 
	rg_id := Create_Group_From_Query( rg_name, p_query ); 
	errcode := Populate_Group( rg_id ); 
	the_rowcount := Get_Group_Row_Count( rg_id );
	IF the_rowcount > 65536 THEN  
		Message('Maximum number of rows in excel exceeded. It will truncate to 65535 rows.');
		Message('  ');
		CLEAR_MESSAGE;
		the_rowcount := 65535;
	END IF;

	server_file := '/iashome/ias/reports/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	--formserverpath := 'http://10.100.34.230:7778/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	urlFile := Text_Io.Fopen('/reports/DMS/excelpath.txt','R');
	Text_Io.Get_Line(urlFile,urlPath);
	Text_Io.Fclose(urlFile);
	formserverpath := urlPath||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	MYFILE := TEXT_IO.FOPEN(server_file, 'W');
	gc_id := Find_Column( rg_name||'.'||p_column_name); 	
	for total_loop IN 1..the_rowcount
		loop
	  	V_STRING :=  GET_GROUP_CHAR_CELL(gc_id  , total_loop ); 
	  	text_io.put_line(myfile,v_string);
	  	--TEXT_IO.PUTF(MYFILE,V_STRING);  
		end loop;
      text_io.fclose(myfile);
   
	 --	file_transfer_bool := WebUtil_File_Transfer.Url_To_Client(formserverpath,FILENAME);
	/* 	if not file_transfer_bool  then 
	 		message('File Transfer failed');pause;
	 	end if;
	 	WebUtil_Host.HOST('cmd /c '||FILENAME);*/
	 	
	 	web.show_document(formserverpath,'_blank');
	exception
		when others then
		Message('Error  - '||ERROR_CODE|| ERROR_TEXT);
		Raise Form_trigger_failure;
	end;
```

#### SP-006 - GENERAL.CHECK_NULL

**Invoked From:**

- vr_exte_warr_msil_fmb.xml [ProgramUnit: PROC_REP_SEARCH_PMC1]
- vr_exte_warr_msil_fmb.xml [ProgramUnit: PROC_REP_SEARCH_PMC2]
- vr_exte_warr_msil_fmb.xml [ProgramUnit: PROC_REP_XL_PMC1]
- vr_exte_warr_msil_fmb.xml [ProgramUnit: PROC_REP_XL_PMC2]
- vr_exte_warr_msil_fmb.xml [StoredProcedure: PROC_REP_SEARCH_PMC1]
- vr_exte_warr_msil_fmb.xml [StoredProcedure: PROC_REP_SEARCH_PMC2]
- vr_exte_warr_msil_fmb.xml [StoredProcedure: PROC_REP_XL_PMC1]
- vr_exte_warr_msil_fmb.xml [StoredProcedure: PROC_REP_XL_PMC2]

---

**Screen:**

Details (N/A / CN_MAIN); Search Criteria (N/A / CN_MAIN)

---

**Purpose**

Validates that a required search-criteria field has been entered before a report is executed. If the supplied value is NULL, it displays a labelled error alert and halts further processing by raising a form trigger failure.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_value | VARCHAR2 | IN |
| column_title | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-007](#SP-007--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Compose an error message text by concatenating the literal `'Enter a valid '` with the supplied `column_title` parameter.
- Step 2 - Check whether the supplied value `P_value` is NULL.
- Step 3 - If NULL, display the composed error message as an Error-type alert via `GENERAL.DISP_TEXT`, then raise `FORM_TRIGGER_FAILURE` to stop all further processing in the calling trigger.
- Step 4 - If not NULL, exit silently - no action is taken.

---
**Decision Points**

DP-001

Condition:
The supplied field value (`P_value`) is NULL.

TRUE:
Display an error alert with the message "Enter a valid <column_title>" and raise `FORM_TRIGGER_FAILURE`, aborting the current trigger execution.

FALSE:
Return silently; the calling procedure continues normally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- SBR-001 - Every mandatory search-criteria field must contain a non-NULL value before a report query or Excel export is allowed to proceed.
- SBR-002 - When a mandatory field is found to be NULL, a user-readable error message identifying the field by its column title must be shown before the operation is aborted.

---
**Implementation Logic**

```plsql
PROCEDURE CHECK_NULL( P_value IN VARCHAR2, column_title  IN VARCHAR2) IS
mesg_text        varchar2(80) := 'Enter a valid '||column_title ;
BEGIN
   IF p_value IS null  THEN
      GENERAL.DISP_TEXT(mesg_text,'Error');
      raise form_trigger_failure;
   END IF;
END;
```

#### SP-007 - GENERAL.DISP_TEXT

**Invoked From:**

- DPL.pld [StoredProcedure: GENERAL.CHECK_NULL]
- DPL.pld [StoredProcedure: GENERAL.RAISE_ERROR]
- vr_exte_warr_msil_fmb.xml [Trigger: ON-ERROR]
- vr_exte_warr_msil_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

Search Criteria (N/A / CN_MAIN)

---

**Purpose**

Presents a message to the user through a named Oracle Forms alert dialog, choosing between an error-style alert (`AL_ERRINFO`) and an informational note alert (`AL_NOTE`) based on the supplied title. This centralises all user-facing message display into one reusable routine.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| text_string | VARCHAR2 | IN |
| title_string | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate the `title_string` parameter (case-insensitively) to determine which alert template to use.
- Step 2 - If `title_string` equals `'ERROR'` (any case), set the alert name to `AL_ERRINFO`; otherwise set it to `AL_NOTE`.
- Step 3 - Set the title property of the chosen alert to `title_string`.
- Step 4 - Set the message text property of the chosen alert to `text_string`.
- Step 5 - Display the alert to the user and capture the user's response (the return value is not used further).

---
**Decision Points**

DP-001

Condition:
The `title_string` parameter, converted to upper case, equals `'ERROR'`.

TRUE:
Use the `AL_ERRINFO` alert template, which is styled as an error dialog.

FALSE:
Use the `AL_NOTE` alert template, which is styled as an informational note dialog.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- SBR-001 - Error-category messages (where `title_string` = `'ERROR'`) must be shown using the `AL_ERRINFO` alert; all other messages use the `AL_NOTE` alert - the two categories must not be mixed.

---
**Implementation Logic**

```plsql
PROCEDURE DISP_TEXT (text_string VARCHAR2,
                     title_string VARCHAR2 ) IS 
   p_alert_name varchar2(10) := 'AL_ERRINFO' ; 
   p_alert_id number;
BEGIN
   if upper(title_string)='ERROR' then
      p_alert_name := 'AL_ERRINFO' ; 
   else
      p_alert_name := 'AL_NOTE' ; 
   end if;
   set_alert_property(p_alert_name,TITLE,title_string);  
   set_alert_property(p_alert_name,alert_message_text,text_string);  
   p_alert_id := show_alert(p_alert_name); 
END;
```

#### SP-008 - GENERAL.L_POPULATE

**Invoked From:**

- vr_exte_warr_msil_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

Search Criteria (N/A / CN_MAIN)

---

**Purpose**

Populates a named Oracle Forms list item with code/description pairs retrieved from the `AM_LIST` lookup table for a specified list name and the current principal. Any pre-existing in-memory record group of the same name is deleted before the new one is created, ensuring the list always reflects current data.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_LIST_NAME | VARCHAR2 | IN |
| P_LIST_FIELD | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-017](#SP-017--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Read the current principal code from the global variable `:global.principal` into a local variable.
- Step 2 - Locate any existing record group named `'list'` using `FIND_GROUP`.
- Step 3 - If a record group named `'list'` already exists, delete it to avoid stale data before recreating it.
- Step 4 - Create a new record group named `'list'` from a query that selects `AM_LIST.LIST_DESC` and `AM_LIST.LIST_CODE` filtered by the supplied `P_LIST_NAME` and the current principal code, ordered alphabetically by description.
- Step 5 - Populate the record group by executing the query against the database.
- Step 6 - Populate the target list item (identified by `P_LIST_FIELD`) with the contents of the record group.

---
**Decision Points**

DP-001

Condition:
A record group named `'list'` already exists in the form's record group cache (i.e., `FIND_GROUP` returns a non-null handle).

TRUE:
Delete the existing record group before proceeding, so the list is refreshed with a new query rather than retaining stale entries.

FALSE:
No deletion required; proceed directly to create the record group from the query.

---
**Database Interactions**

- DB-001 - Read AM_LIST - Reads data from AM_LIST for lookup or validation.
**Business Rules**

- SBR-001 - List items are always populated per-principal; data from other principals is never mixed into the list.
- SBR-002 - The list options are presented in ascending alphabetical order by description (`Order by list_desc`), ensuring a consistent user experience regardless of insertion order in `AM_LIST`.
- SBR-003 - Any pre-existing in-memory record group for the list is unconditionally destroyed before repopulation, preventing duplicate or stale entries from appearing in the list.

---
**Implementation Logic**

```plsql

  PROCEDURE L_POPULATE(P_LIST_NAME VARCHAR2,P_LIST_FIELD VARCHAR2) IS
    group_id     RecordGroup;
    list_id      Item := Find_Item(P_LIST_FIELD);  
    status       NUMBER; 
    lv_principal varchar2(5);
   BEGIN 
   			lv_principal := name_in(':global.principal');
          group_id := find_group('list');	
        if not id_null(group_id) then
          delete_group(group_id);
        end if;
          group_id := Create_Group_From_Query('list','SELECT   
                      Am_list.list_desc,Am_list.list_code FROM Am_List
                              WHERE list_name = '||''''||P_LIST_NAME||''' and 
                              principal_map_cd = '''||lv_principal||''' Order by list_desc ');
          status := Populate_Group(group_id); 
          Populate_List(list_id,group_id); 
   END;
```

#### SP-009 - GENERAL.L_POP_LIST_ITEM

**Invoked From:**

- vr_exte_warr_msil_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

Search Criteria (N/A / CN_MAIN)

---

**Purpose**

Creates or refreshes a named Oracle Forms record group from a caller-supplied SQL query string, ensuring any previous record group of the same name is removed before the new one is populated. This provides a reusable mechanism for loading arbitrary query results into a record group that other form elements (such as list items) can subsequently consume.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_rg_name | VARCHAR2 | IN |
| p_select | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-017](#SP-017--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Search for an existing record group with the name supplied in `p_rg_name` using `FIND_GROUP`.
- Step 2 - If an existing record group is found (handle is not null), delete it to clear any previously loaded data.
- Step 3 - Create a new record group from the SQL query string `p_select`, assigning it the name `p_rg_name`.
- Step 4 - Execute the query and populate the record group with the result rows via `POPULATE_GROUP`; the resulting status code is stored but not evaluated further.

---
**Decision Points**

DP-001

Condition:
A record group with the name `p_rg_name` already exists in the form's record group cache.

TRUE:
Delete the existing record group before creating a fresh one from the new query, preventing duplicate or stale entries.

FALSE:
No deletion required; proceed directly to create and populate the new record group.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- SBR-001 - Any pre-existing record group of the same name is unconditionally removed before repopulation, ensuring the record group always reflects the current query result rather than retaining stale data.
- SBR-002 - The SQL query used to populate the record group is entirely caller-supplied (`p_select`); this routine applies no filtering, transformation, or validation to the query string.

---
**Implementation Logic**

```plsql

PROCEDURE l_pop_list_item (p_rg_name VARCHAR2,p_select VARCHAR2 )IS

	 rg_name VARCHAR2(40) := p_rg_name;
	 rg_id RecordGroup;
	 errcode NUMBER; 
BEGIN 
	/* ** Make sure group doesn't already exist */ 
	rg_id := Find_Group( rg_name ); 

	IF NOT Id_Null(rg_id) THEN 
		delete_group(rg_id);
	END IF;
	/* ** If it does not exist, create it and add the two ** necessary columns to it. */ 
		rg_id := Create_Group_From_Query( rg_name, p_select); 
	 
	/* ** Populate the record group */ 
	errcode := Populate_Group( rg_id );
END;
```

#### SP-010 - GENERAL.RAISE_ERROR

**Invoked From:**

- vr_exte_warr_msil_fmb.xml [Trigger: ON-ERROR]

---

**Screen:**

N/A

---

**Purpose**

Interprets a message code and its associated type, then presents the corresponding error, note, or caution message to the user via a display dialog. When the message is of type Error, the routine additionally halts further form processing by raising `FORM_TRIGGER_FAILURE`.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| mesg_code | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-007](#SP-007--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message code passed by the calling ON-ERROR trigger.
- Step 2 - Concatenate the message code with the (uninitialised) message text variable to form the display string (note: the `GENERAL.get_message` call that would have populated `mesg_text` is commented out, so `mesg_text` remains `NULL` at runtime, and the displayed string is `mesg_code || ' : '`).
- Step 3 - Evaluate the message type (`mesg_type`). Because `get_message` is commented out, `mesg_type` is also `NULL` at runtime; none of the three branches will fire and the procedure exits silently unless the call site pre-populates the variable.
- Step 4 - If `mesg_type = 'E'` (Error): set the dialog title to `'Error'`, call `GENERAL.DISP_TEXT` to display the message, then raise `FORM_TRIGGER_FAILURE` to halt form processing.
- Step 5 - If `mesg_type = 'N'` (Note): set the dialog title to `'Note'` and call `GENERAL.DISP_TEXT` to display the message; form processing continues normally.
- Step 6 - If `mesg_type = 'C'` (Caution): set the dialog title to `'Caution'` and call `GENERAL.DISP_TEXT` to display the message; form processing continues normally.

---
**Decision Points**

DP-001

Condition:
The message type (`mesg_type`) equals `'E'` (Error).

TRUE:
Display the message with title `'Error'` via `GENERAL.DISP_TEXT`, then raise `FORM_TRIGGER_FAILURE` to stop all further form trigger processing.

FALSE:
Check the next message-type condition (ELSIF chain continues to `'N'`).

DP-002

Condition:
The message type (`mesg_type`) equals `'N'` (Note).

TRUE:
Display the message with title `'Note'` via `GENERAL.DISP_TEXT`; form processing continues after the call.

FALSE:
Check the next message-type condition (ELSIF chain continues to `'C'`).

DP-003

Condition:
The message type (`mesg_type`) equals `'C'` (Caution).

TRUE:
Display the message with title `'Caution'` via `GENERAL.DISP_TEXT`; form processing continues after the call.

FALSE:
None of the recognised message types matched; the procedure exits without displaying anything.

---
**Database Interactions**

- DB-001 - Read AM_PERMISSIONS - Reads data from AM_PERMISSIONS for lookup or validation.
**Business Rules**

- SBR-001 - A message of type `'E'` (Error) must always abort form trigger processing by raising `FORM_TRIGGER_FAILURE` after the message is displayed; no subsequent trigger steps execute.
- SBR-002 - Messages of type `'N'` (Note) and `'C'` (Caution) are informational only and do not interrupt form processing.
- SBR-003 - The displayed message string is formed by prepending the raw message code to the message text, separated by ` : `, ensuring the code is always visible to the user regardless of whether a descriptive text is available.

---
**Implementation Logic**

```plsql
PROCEDURE RAISE_ERROR ( mesg_code IN VARCHAR2 )IS
  mesg_type  varchar2(7); 
  mesg_text  varchar2(200) ;
  mesg_title varchar2(7);
  BEGIN
     -- murali 17.05.04 GENERAL.get_message(mesg_code,mesg_text,mesg_type );
     mesg_text:=mesg_code||' : '||mesg_text;		
     IF ( mesg_type = 'E' ) THEN
        mesg_title := 'Error' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
        raise FORM_TRIGGER_FAILURE;
     ELSIF ( mesg_type = 'N' ) THEN
        mesg_title := 'Note' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     ELSIF ( mesg_type = 'C' ) THEN
        mesg_title := 'Caution' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     END IF;
  END;     

/* PROCEDURE check_rights( 
pi_form_name in varchar2,
pi_user_id in number) IS
lv_x varchar2(1);
BEGIN
	
	begin
	SELECT substr(access_string, pi_user_id,1) 
	INTO   lv_x
	FROM   	am_permissions
	WHERE  form_name = pi_form_name
	AND SUBSTR(access_string,pi_user_id,1)='Y';
	exception 
		when no_data_found then
		  general.disp_text('You do not have the Permission to access this.','Error rr');
		  raise form_trigger_failure; 
		when too_many_rows then
		  general.disp_text('Many rows in USER_PERMISSIONS','Error ss');
		  raise form_trigger_failure;
		when others then
		       general.disp_text(sqlerrm,'Error mm');
		       raise form_trigger_failure;
	end;

	open_form(pi_form_name,activate,session);
END;
*/
```

#### SP-011 - WEBUTIL.ERRORALERT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Displays a WebUtil error message to the user, either via a pre-configured Oracle Forms alert dialog or, if no alert object is available, via the Forms `MESSAGE` built-in. This provides a consistent user-facing notification channel for bean-registration and runtime errors raised within the WebUtil library.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| errText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-017](#SP-017--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Check whether the module-level alert handle `m_errorAlert` is initialised (non-null) by calling `ID_NULL`.
- Step 2 - If the alert handle is valid, set the alert's message text property to the supplied `errText` value, then display the alert to the user via `SHOW_ALERT`; the return value (button pressed) is discarded.
- Step 3 - If the alert handle is null (not available), fall back to displaying the error using the Forms `MESSAGE` built-in, prefixed with the literal `'WebUtil Error: '`.

---
**Decision Points**

DP-001

Condition:
The module-level error-alert handle `m_errorAlert` is not null (i.e., a configured Forms alert object exists for WebUtil errors).

TRUE:
Set the alert message text to `errText` and show the alert dialog to the user.

FALSE:
Display the error via the Forms `MESSAGE` built-in as `'WebUtil Error: ' || errText`.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- SBR-001 - Error messages are always prefixed with `'WebUtil Error'` to make their origin unambiguous, regardless of the display channel used.
- SBR-002 - The user-acknowledgement return value from `SHOW_ALERT` is intentionally ignored; the sole purpose of this routine is notification, not flow control based on the user's button choice.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ErrorAlert(errText in VARCHAR2) is
    -- currently used for throwing a BEAN_NOT_REGISTERED or bean not found error.
    ignore integer;
  begin
    if not ID_NULL(m_errorAlert) then 
      --SET_ALERT_PROPERTY(m_errorAlert,TITLE,'WebUtil Error'); -- title already set in alert property
      SET_ALERT_PROPERTY(m_errorAlert,ALERT_MESSAGE_TEXT,errText);
      ignore := SHOW_ALERT(m_errorAlert);
    else
      message('WebUtil Error'||': '||errText);
    end if;
  end ErrorAlert;
```

#### SP-012 - WEBUTIL.FCLOSE

**Invoked From:**

- vr_exte_warr_msil_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open client-side text file that was previously opened via WEBUTIL.FOPEN, releasing the associated Java WebUtil file handle. The procedure instructs the WebUtil bean to close the underlying file stream via WEBUTIL.SETPROPERTY, nullifies the PL/SQL handle, and uses WEBUTIL.ERRORALERT together with WEBUTIL.GETIMPLCLASS to report a descriptive error if the required bean is not registered at runtime.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-011](#SP-011--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETIMPLCLASS ([SP-014](#SP-014--WEBUTIL.GETIMPLCLASS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETPROPERTY ([SP-019](#SP-019--WEBUTIL.SETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate whether the file handle (`file.handle`) is not NULL, indicating the file is currently open and requires closing.
- Step 2 - If the handle is not NULL, call `WEBUTIL.SETPROPERTY` (delegating to `WebUtil_Core.setProperty`) with the `WUF_TEXTIO_CLOSE` property and the current file handle to instruct the WebUtil Java bean to close the underlying client-side file stream.
- Step 3 - Set `file.handle` to NULL to mark the file object as closed within the PL/SQL layer, preventing any further operations against the same handle.
- Step 4 - If the `BEAN_NOT_REGISTERED` exception is raised, call `WEBUTIL.ERRORALERT` (delegating to `WebUtil_Core.ErrorAlert`), constructing the message by resolving the bean class name via `WEBUTIL.GETIMPLCLASS` (delegating to `WebUtil_Core.getImplClass`) and appending a descriptive suffix indicating that `CLIENT_TEXT_IO.fclose` will not work; then raise `TOOL_ERR.TOOL_ERROR` to abort the calling operation.
- Step 5 - If the `PROPERTY_ERROR` exception is raised, raise `TOOL_ERR.TOOL_ERROR` to abort the calling operation without displaying an additional alert.

---
**Decision Points**

DP-001

Condition:
The file handle (`file.handle`) is not NULL.

TRUE:
Call WEBUTIL.SETPROPERTY to send the `WUF_TEXTIO_CLOSE` instruction to the WebUtil Java bean, then nullify `file.handle` to record the closed state in the PL/SQL layer.

FALSE:
No action is taken; the file is already considered closed and the procedure exits silently.

DP-002

Condition:
The WebUtil Java bean is registered and available at runtime (i.e., the `BEAN_NOT_REGISTERED` exception is not raised during the SETPROPERTY call).

TRUE:
The close operation completes normally and control returns to the caller.

FALSE:
WEBUTIL.ERRORALERT is invoked with a message that includes the bean class name resolved by WEBUTIL.GETIMPLCLASS, and `TOOL_ERR.TOOL_ERROR` is raised to abort the calling operation.

DP-003

Condition:
A property-level error occurs during the SETPROPERTY call (i.e., the `PROPERTY_ERROR` exception is raised).

TRUE:
`TOOL_ERR.TOOL_ERROR` is raised to abort the calling operation; no additional alert is displayed.

FALSE:
The close operation continues or completes normally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A file-close instruction must be sent to the WebUtil bean only when the file handle is non-NULL; if the handle is already NULL the procedure exits silently, preventing double-close errors.
- BR-002 - The WebUtil Java bean must be registered at runtime for the file-close operation to succeed; absence of the bean is treated as a fatal error, reported via WEBUTIL.ERRORALERT with the bean class name resolved by WEBUTIL.GETIMPLCLASS, and propagated by raising `TOOL_ERR.TOOL_ERROR`.
- BR-003 - A property-level error returned by the WebUtil bean during the close operation is also treated as fatal and is propagated by raising `TOOL_ERR.TOOL_ERROR`, ensuring the caller is always notified of an unsuccessful close attempt.
- BR-004 - The `file.handle` field must be set to NULL immediately after a successful SETPROPERTY call, ensuring the PL/SQL file object accurately reflects the closed state regardless of subsequent exception handling.

---
**Implementation Logic**

```plsql
 
  PROCEDURE fclose (file IN OUT file_type) is 
  BEGIN 
    if (file.handle IS NOT NULL) then 
      WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CLOSE',file.handle);        
      file.handle := NULL;
    end if;
 
 EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.fclose will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;
  END fclose;
```

#### SP-013 - WEBUTIL.FOPEN

**Invoked From:**

- vr_exte_warr_msil_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Opens a client-side text file via the WebUtil Java bean and returns a file handle for subsequent read, write, or append operations. It is called by `VIEW_EXCEL_REP` to create or access the CSV output file on the client before writing report data. The function delegates the physical file-open request to the WebUtil bean through `WEBUTIL.GETPROPERTY`, which retrieves the resulting Java handle string.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| spec | VARCHAR2 | IN |
| filemode | VARCHAR2 | IN |
| charSet | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETPROPERTY ([SP-015](#SP-015--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Validate that `filemode` (lower-cased) is one of the accepted values (`'r'`, `'w'`, or `'a'`); if not, raise `TOOL_ERR.TOOL_ERROR` immediately.
- Step 2 - Validate that `spec` (the file path/name) is non-NULL and non-empty; if either condition fails, raise `TOOL_ERR.TOOL_ERROR` immediately.
- Step 3 - Pass the file path to the WebUtil bean by calling `WebUtil_Core.setProperty` with property key `WUF_FILENAME`.
- Step 4 - Pass the file mode to the WebUtil bean by calling `WebUtil_Core.setProperty` with property key `WUF_TEXTIO_FILEMODE`.
- Step 5 - Evaluate the `charSet` parameter: if NULL, set the `WUF_TEXTIO_CHARSET` bean property to the literal string `'(null)'`; otherwise set it to the supplied character set value.
- Step 6 - Request the bean to open the file by calling `WebUtil_Core.getProperty` (via `WEBUTIL.GETPROPERTY`) with property key `WUF_TEXTIO_OPEN`; receive a Java handle string (`javaHandle`) in return.
- Step 7 - If `javaHandle` is NULL, empty, or `'-1'` (indicating the file could not be opened), raise `TOOL_ERR.TOOL_ERROR`.
- Step 8 - Convert `javaHandle` to a number, store it in `clientFile.handle`, and return the populated `file_type` record to the caller.
- Step 9 - In the exception block: if the WebUtil bean is not registered, display a descriptive error alert identifying the missing bean class and raise `TOOL_ERR.TOOL_ERROR`; re-raise `PROPERTY_ERROR` and `VALUE_ERROR` (as `TOOL_ERR.TOOL_ERROR`) and `TOOL_ERR.TOOL_ERROR` as-is.

---
**Decision Points**

DP-001

Condition:
The `filemode` parameter (lower-cased) is one of `'r'`, `'w'`, or `'a'`.

TRUE:
Proceed to validate the file specification.

FALSE:
Raise `TOOL_ERR.TOOL_ERROR` immediately - invalid file mode is not permitted.

DP-002

Condition:
The `spec` parameter is non-NULL and non-empty.

TRUE:
Proceed to set WebUtil bean properties and attempt to open the file.

FALSE:
Raise `TOOL_ERR.TOOL_ERROR` immediately - a file name must be provided.

DP-003

Condition:
The `charSet` parameter is NULL.

TRUE:
Set the `WUF_TEXTIO_CHARSET` bean property to the literal string `'(null)'`.

FALSE:
Set the `WUF_TEXTIO_CHARSET` bean property to the supplied `charSet` value.

DP-004

Condition:
The Java handle string returned by `WEBUTIL.GETPROPERTY` (`WUF_TEXTIO_OPEN`) is non-NULL, non-empty, and not `'-1'`.

TRUE:
Convert the handle to a number, populate `clientFile.handle`, and return the record to the caller.

FALSE:
Raise `TOOL_ERR.TOOL_ERROR` - the file could not be opened on the client.

DP-005

Condition:
The WebUtil Java bean is registered and available (exception handler: `BEAN_NOT_REGISTERED`).

TRUE:
File-open operation completes normally through the preceding steps.

FALSE:
Display a descriptive error alert identifying the missing bean class and raise `TOOL_ERR.TOOL_ERROR`.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only the file modes `'r'` (read), `'w'` (write), and `'a'` (append) are accepted; any other value must be rejected before any file operation is attempted.
- BR-002 - A non-empty file path must be supplied; attempting to open a file without a name is a fatal error.
- BR-003 - When no character set is specified, the WebUtil bean must be explicitly informed by passing the literal string `'(null)'` as the charset property value; omitting the property entirely is not permitted.
- BR-004 - A NULL, empty, or `'-1'` handle returned by `WEBUTIL.GETPROPERTY` is treated as a file-open failure and must abort the calling operation.
- BR-005 - If the WebUtil bean class is not registered in the runtime environment, a user-facing error alert identifying the missing class must be displayed before the error is propagated, ensuring the failure is diagnosable.

---
**Implementation Logic**

```plsql
  FUNCTION fopen(spec VARCHAR2, filemode VARCHAR2, charSet VARCHAR2 := null) RETURN file_type is
    clientFile file_type;
    javaHandle VARCHAR2(6);
  BEGIN
    -- check the mode is valid
    if (lower(filemode) not in ('r','w','a')) then 
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- make sure a file name has been specified      
    if (spec is null) or (spec='') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;
      
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILENAME',spec, true);
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_FILEMODE',filemode, true);        
    if (charSet is null) then
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET','(null)', true);
    else
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET',charSet, true);
    end if;
    javaHandle := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_OPEN');

    -- If the return is null then the file was not opened      
    if (javaHandle is null) or (javaHandle='') or (javaHandle='-1') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- if we are this far convert the handle to the correct format and return it.      
    clientFile.handle := to_number(javaHandle);
    return clientFile;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.fopen will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                 
      return null;
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE;
    when VALUE_ERROR then
      RAISE TOOL_ERR.TOOL_ERROR; 
    when TOOL_ERR.TOOL_ERROR then 
      RAISE;
  END fopen;
```

#### SP-014 - WEBUTIL.GETIMPLCLASS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the fully qualified Java implementation class name for a given WebUtil package ID by concatenating the configured Java root path with the package's registered class suffix. This name is used in error messages to identify which bean component is missing or misconfigured.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Look up the implementation class suffix for the given `packageID` in the module-level `m_implClasses` indexed collection.
- Step 2 - Concatenate the WebUtil Java root path constant (`WEBUTIL_JAVA_ROOT`) with the retrieved class suffix to form the fully qualified class name.
- Step 3 - Return the assembled class name string to the caller.

---
**Decision Points**

No business-significant decision points in this routine.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- SBR-001 - The fully qualified class name is always composed by prepending the `WEBUTIL_JAVA_ROOT` constant to the package-specific suffix; no alternative naming path exists.

---
**Implementation Logic**

```plsql

  FUNCTION getImplClass(packageID PLS_INTEGER) return VARCHAR2 is
  BEGIN 
    return WEBUTIL_JAVA_ROOT||m_implClasses(packageID);    
  END;
```

#### SP-015 - WEBUTIL.GETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FOPEN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value of a named Java system property from the client JVM by invoking `java.lang.System.getProperty` via the Oracle Forms JNI bridge. This allows server-side PL/SQL to read client-side runtime properties such as file paths and environment settings.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Build a JNI argument list of size 1 via `JNI.CREATE_ARG_LIST`.
- Step 2 - Add the property name (`a0`) as a String argument to the argument list via `JNI.ADD_STRING_ARG`.
- Step 3 - Invoke the static method `java.lang.System.getProperty(String)` on the client JVM via `JNI.CALL_STRING_METHOD` and return its result directly to the caller.

---
**Decision Points**

No business-significant decision points in this routine.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- SBR-001 - The property lookup is delegated entirely to the client JVM's `java.lang.System.getProperty`; the routine applies no filtering, defaulting, or transformation to the returned value.

---
**Implementation Logic**

```plsql
  FUNCTION getProperty(
    a0    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'getProperty', '(Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-016 - WEBUTIL.GET_LINE

**Invoked From:**

- vr_exte_warr_msil_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Reads the next line of text from an open client-side file handle and returns it to the caller via the WebUtil Core PJC bean. The procedure signals end-of-file by raising NO_DATA_FOUND and halts processing with TOOL_ERROR if the bean is unregistered or a property interaction fails.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| item | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Pass the file handle to the WebUtil Core PJC bean by setting the WUF_TEXTIO_HANDLE property on the WUF_PACKAGE component via WebUtil_Core.setProperty.
- Step 2 - Request the next line from the PJC bean by reading the WUF_TEXTIO_GETLINE property via WebUtil_Core.getProperty; the bean advances its internal file pointer and returns the line content into a local buffer.
- Step 3 - Inspect the buffer: if it equals a lone newline character (CHR(10)), this is the sentinel the PJC places when end-of-file has been reached; raise NO_DATA_FOUND to signal end-of-file to the caller.
- Step 4 - Otherwise, assign the buffer content to the item OUT parameter and return normally to the caller.
- Step 5 - On BEAN_NOT_REGISTERED, invoke WebUtil_Core.ErrorAlert with the implementation class name obtained from WebUtil_Core.getImplClass to display a user-facing error message, then raise TOOL_ERR.TOOL_ERROR to abort the calling operation.
- Step 6 - On PROPERTY_ERROR, raise TOOL_ERR.TOOL_ERROR to halt processing without an additional user-facing alert.

---
**Decision Points**

DP-001

Condition:
The buffer returned by the PJC bean via WebUtil_Core.getProperty equals CHR(10) (the end-of-file sentinel).

TRUE:
Raise NO_DATA_FOUND to inform the caller that no further lines are available in the file.

FALSE:
Assign the buffer to the item OUT parameter and return successfully to the caller.

DP-002

Condition:
The BEAN_NOT_REGISTERED exception is raised (the WebUtil Java bean is not present in the client JVM).

TRUE:
Invoke WebUtil_Core.ErrorAlert with the implementation class name (retrieved via WebUtil_Core.getImplClass) to display an error message to the user, then raise TOOL_ERR.TOOL_ERROR to halt processing.

FALSE:
Normal processing continues (no action for this exception path).

DP-003

Condition:
The PROPERTY_ERROR exception is raised (the bean property interaction with WUF_PACKAGE failed).

TRUE:
Raise TOOL_ERR.TOOL_ERROR to halt processing without an additional user-facing alert.

FALSE:
Normal processing continues (no action for this exception path).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A lone newline character (CHR(10)) returned by the PJC bean is treated exclusively as the end-of-file marker; it is never exposed as valid line content to the caller.
- BR-002 - If the WebUtil bean required to perform file I/O is not registered on the client, processing must stop immediately with a user-visible error message (identifying the missing implementation class and the failing operation) rather than returning an empty or undefined value.
- BR-003 - A property interaction failure with the PJC bean must terminate processing via TOOL_ERR.TOOL_ERROR; no partial or undefined line content may be returned to the caller.

---
**Implementation Logic**

```plsql
  PROCEDURE get_line (file file_type, item OUT VARCHAR2) is
    buffer VARCHAR2(4000 char);
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);        
    buffer := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_GETLINE');
    -- We can't easily tell the difference between an empty line and a line beyond then 
    -- end of the file so to get around this, the exception handling code in the PJC 
    -- places a newline into the buffer when the end of file is passed.
    -- The rational being that get_line would never normally return a newline because 
    -- it normally uses that to tell it where to read up *to*.
    if buffer = chr(10) then 
      raise NO_DATA_FOUND;
    else
      item := buffer;
    end if;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.get_line will not work');
      RAISE TOOL_ERR.TOOL_ERROR;                                                                 
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE TOOL_ERR.TOOL_ERROR;  
  END get_line;
  
  /**
   * File writing functions
   */
```

#### SP-017 - WEBUTIL.ID_NULL

**Invoked From:**

- DPL.pld [StoredProcedure: GENERAL.L_POPULATE]
- DPL.pld [StoredProcedure: GENERAL.L_POP_LIST_ITEM]
- vr_exte_warr_msil_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]
- webutil.pld [StoredProcedure: WEBUTIL.ERRORALERT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines whether a WebUtil or Forms Pointer handle is uninitialised (null), returning `TRUE` if the handle's internal `hnd` field is null and `FALSE` otherwise. Callers use this test to guard against operating on invalid object references.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| handle | Pointer | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Inspect the `hnd` field of the supplied `handle` Pointer record.
- Step 2 - If `hnd` is null, return `TRUE` to indicate the handle is uninitialised.
- Step 3 - If `hnd` is not null, return `FALSE` to indicate the handle refers to a valid object.

---
**Decision Points**

DP-001

Condition:
The `hnd` field of the supplied `handle` Pointer is null.

TRUE:
Return `TRUE` - the handle is uninitialised and should not be used for further operations.

FALSE:
Return `FALSE` - the handle is valid and may be safely used by the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- SBR-001 - A Pointer handle is considered null solely on the basis of its `hnd` field being null; no other fields or state are evaluated.

---
**Implementation Logic**

```plsql

  FUNCTION ID_NULL(handle IN Pointer)        RETURN BOOLEAN is
  BEGIN
    if handle.hnd is null then 
      return TRUE;
    else
      return FALSE;
    end if;
  END ID_NULL;
```

#### SP-018 - WEBUTIL.PUT_LINE

**Invoked From:**

- vr_exte_warr_msil_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a line of text followed by a newline to an open client-side file handle by instructing the WebUtil PJC bean via three sequential property calls. If the required Java bean is absent or a property error occurs, the routine raises a tool-level error to prevent silent data loss.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |
| item | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Set the `WUF_TEXTIO_HANDLE` property on the `WUF_PACKAGE` component to the file's handle value, directing the PJC bean to the correct open file.
- Step 2 - Set the `WUF_TEXTIO_PUT` property to the text content (`item`) to be written to the file.
- Step 3 - Set the `WUF_TEXTIO_NEWLINE` property to `1`, instructing the PJC bean to append a newline after the text, completing the line-write operation.
- Step 4 - On `BEAN_NOT_REGISTERED`, invoke `ErrorAlert` with the implementation-class name and a descriptive message, then raise `TOOL_ERROR` to abort the calling operation.
- Step 5 - On `PROPERTY_ERROR`, raise `TOOL_ERROR` without an additional user-facing alert.

---
**Decision Points**

DP-001

Condition:
The `BEAN_NOT_REGISTERED` exception is raised (the WebUtil Java bean is not present on the client).

TRUE:
Display an error alert naming the missing implementation class and the affected operation (`CLIENT_TEXT_IO.put_line`), then raise `TOOL_ERROR` to halt processing.

FALSE:
All three property calls succeed; the line is written to the file normally.

DP-002

Condition:
The `PROPERTY_ERROR` exception is raised (a bean property interaction failed).

TRUE:
Raise `TOOL_ERROR` to halt processing without an additional user-facing alert.

FALSE:
Normal processing continues (no action for this exception path).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- SBR-001 - A line write always consists of the text content followed by a newline (`WUF_TEXTIO_NEWLINE = 1`); the routine never writes content without a trailing newline.
- SBR-002 - If the WebUtil bean required to perform file I/O is not registered on the client, processing must stop immediately with a user-visible error rather than continuing silently.

---
**Implementation Logic**

```plsql
    

  PROCEDURE put_line (file file_type, item VARCHAR2) is
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);              
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_PUT',item); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_NEWLINE',1); 
  EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.put_line will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;  
  END put_line;
```

#### SP-019 - WEBUTIL.SETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sets a named Java system property on the client JVM to a specified value by invoking `java.lang.System.setProperty` via the Oracle Forms JNI bridge, and returns the property's previous value. This is used by WebUtil routines to pass control parameters (such as file handles and I/O payloads) to the client-side Java bean.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |
| a1 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Build a JNI argument list of size 2 via `JNI.CREATE_ARG_LIST`.
- Step 2 - Add the property name (`a0`) as a String argument via `JNI.ADD_STRING_ARG`.
- Step 3 - Add the property value (`a1`) as a String argument via `JNI.ADD_STRING_ARG`.
- Step 4 - Invoke the static method `java.lang.System.setProperty(String, String)` on the client JVM via `JNI.CALL_STRING_METHOD` and return the previous property value to the caller.

---
**Decision Points**

No business-significant decision points in this routine.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- SBR-001 - The property name and value are passed to the client JVM without modification; the routine applies no validation or transformation to either argument.
- SBR-002 - The previous value of the property (as returned by `java.lang.System.setProperty`) is relayed to the caller unchanged, enabling callers to detect or restore the prior state if required.

---
**Implementation Logic**

```plsql
  FUNCTION setProperty(
    a0    VARCHAR2,
    a1    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(2);
    JNI.ADD_STRING_ARG(args, a0);
    JNI.ADD_STRING_ARG(args, a1);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'setProperty', '(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-020 - SF_COPYRIGHT_DECLARATION

**Invoked From:**

- vr_exte_warr_msil_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

Search Criteria (N/A / CN_MAIN)

---

**Purpose**

Generates and returns the Maruti Suzuki India Limited copyright string for the current financial year. Because the Indian financial year runs April-March, months January through March are attributed to the preceding calendar year, ensuring the copyright notice always reflects the correct fiscal year rather than the raw calendar year.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Capture the current system date (`SYSDATE`) into a local variable.
- Step 2 - Determine whether the current month falls within the January-March quarter (the tail end of the Indian financial year that started in the previous calendar year).
- Step 3 - If the current month is January, February, or March, build the copyright string using the previous calendar year (current year - 1) as the financial year start, e.g. `© 2010 Maruti Suzuki India Limited`.
- Step 4 - Otherwise (April through December), build the copyright string using the current calendar year, e.g. `© 2011 Maruti Suzuki India Limited`.
- Step 5 - Return the assembled copyright string to the caller.

---
**Decision Points**

DP-001

Condition:
The current month (derived from `SYSDATE`) is one of `'JAN'`, `'FEB'`, or `'MAR'`.

TRUE:
Subtract 1 from the current calendar year and use that value as the year in the copyright string, reflecting that the financial year began in the previous calendar year.

FALSE:
Use the current calendar year directly in the copyright string (months April through December belong to the financial year that started in the same calendar year).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- SBR-001 - The copyright year must reflect the Indian financial year (April-March): months January, February, and March belong to the financial year that started in the preceding calendar year, so the year displayed is `current calendar year - 1`.
- SBR-002 - The copyright notice must always identify `Maruti Suzuki India Limited` as the rights holder; this string is hard-coded and cannot be overridden by the caller.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
function sf_copyright_declaration return varchar is
a varchar2(50);
dt date;
begin
--Modified by Prerna on 16-May-11  to display current Financial Year Copyright
dt := sysdate;

    if( to_char(dt,'MON') in ('JAN','FEB','MAR')) then
        a := '- '||to_char(to_number(to_char(dt,'RRRR')) - 1)||' Maruti Suzuki India Limited ';
    else
        a := '- '||to_char(dt,'RRRR')||' Maruti Suzuki India Limited ';
    end if;
return(a);
end;

```

#### SP-021 - SF_EW_POLICY_STATUS

**Invoked From:**

- vr_exte_warr_msil_fmb.xml [ProgramUnit: PROC_REP_SEARCH_PMC1]
- vr_exte_warr_msil_fmb.xml [ProgramUnit: PROC_REP_SEARCH_PMC2]
- vr_exte_warr_msil_fmb.xml [StoredProcedure: PROC_REP_SEARCH_PMC1]
- vr_exte_warr_msil_fmb.xml [StoredProcedure: PROC_REP_SEARCH_PMC2]

---

**Screen:**

Details (N/A / CN_MAIN); Search Criteria (N/A / CN_MAIN)

---

**Purpose**

Returns a plain-language status label (`'Cancelled'` or `'Active'`) for an Extended Warranty policy by looking up its cancellation flag. The function is called inline within report queries to populate the status column for each policy row.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_policy_num | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Query `MWAR_EXTE` for the policy's valid date, valid mileage, VIN, and cancellation flag using `p_policy_num`.
- Step 2 - If no record is found in `MWAR_EXTE` (NO_DATA_FOUND), attempt a fallback lookup of the cancellation flag from `VT_EXTSAWA` for the same policy number.
- Step 3 - If the `VT_EXTSAWA` fallback also fails (OTHERS exception), default the cancellation flag to `'N'`, the valid date to `SYSDATE`, and the valid mileage to 0.
- Step 4 - If the `MWAR_EXTE` query raises any other exception (OTHERS), apply the same defaults as Step 3.
- Step 5 - Evaluate the cancellation flag: if `NVL(lv_exte_cancel_flag, 'N') = 'Y'`, set the status to `'Cancelled'`; otherwise set it to `'Active'`.
- Step 6 - Return the computed status string.

---
**Decision Points**

DP-001

Condition:
A row for `p_policy_num` exists in `MWAR_EXTE`.

TRUE:
Use the `exte_cancel_flag`, `exte_valid_date`, `exte_valid_mileage`, and `exte_vin_no` values retrieved from `MWAR_EXTE`.

FALSE:
Attempt the fallback query against `VT_EXTSAWA` (see DP-002).

DP-002

Condition:
A row for `p_policy_num` exists in `VT_EXTSAWA` (evaluated only when `MWAR_EXTE` returns no data).

TRUE:
Use the `exte_cancel_flag` from `VT_EXTSAWA`; valid date and mileage remain at their defaults.

FALSE:
Default `lv_exte_cancel_flag` to `'N'`, `lv_valid_date` to `SYSDATE`, and `lv_exte_valid_mileage` to 0.

DP-003

Condition:
The resolved cancellation flag (`NVL(lv_exte_cancel_flag, 'N')`) equals `'Y'`.

TRUE:
Return `'Cancelled'`.

FALSE:
Return `'Active'`.

---
**Database Interactions**

- DB-001 - Read MWAR_EXTE - Reads data from MWAR_EXTE for lookup or validation.
- DB-002 - Read VT_EXTSAWA - Reads data from VT_EXTSAWA for lookup or validation.
- DB-003 - Read GM_VIN - Reads data from GM_VIN for lookup or validation.
**Business Rules**

- SBR-001 - A policy whose `exte_cancel_flag` is `'Y'` must be reported as `'Cancelled'`; all other policies (including those with a NULL flag) are reported as `'Active'`.
- SBR-002 - If a policy number cannot be found in `MWAR_EXTE`, the function must attempt a secondary lookup in `VT_EXTSAWA` before defaulting, ensuring migrated or legacy policies are still evaluated correctly.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
function sf_ew_policy_status(p_policy_num varchar2)
  return varchar2
is
  lv_valid_date               mwar_exte.exte_valid_date%type;
  lv_last_ro_odometer_reading gm_vin.last_ro_odometer_reading%type;
  lv_exte_valid_mileage       mwar_exte.exte_valid_mileage%type;
  lv_exte_vin_no              mwar_exte.exte_vin_no%type;
  lv_exte_cancel_flag         mwar_exte.exte_cancel_flag%type;
  lv_ew_status                varchar2(20);
begin

  begin
    SELECT exte_valid_date,
           exte_valid_mileage,
           exte_vin_no,
           exte_cancel_flag
      INTO lv_valid_date,
           lv_exte_valid_mileage,
           lv_exte_vin_no,
           lv_exte_cancel_flag
      FROM mwar_exte
     WHERE exte_policy_no = p_policy_num;
  exception
    when no_data_found then
      begin
    SELECT exte_cancel_flag
      INTO lv_exte_cancel_flag
      FROM vt_extsawa
     WHERE exte_policy_no = p_policy_num;/*Added by chandan ason 23-3-26*/
  exception
    when others then
      lv_valid_date         := sysdate;
      lv_exte_valid_mileage := 0;
      lv_exte_cancel_flag   := 'N';
  end;
    when others then
      lv_valid_date         := sysdate;
      lv_exte_valid_mileage := 0;
      lv_exte_cancel_flag   := 'N';
  end;

/*  begin
    SELECT nvl(last_ro_odometer_reading, 0)
      INTO lv_last_ro_odometer_reading
      FROM gm_vin
     WHERE vin = lv_exte_vin_no;
  exception
    when others then
      lv_last_ro_odometer_reading := 0;
  end;
*/
  IF nvl(lv_exte_cancel_flag, 'N') = 'Y' THEN
    lv_ew_status := 'Cancelled';
/*  ELSIF nvl(lv_exte_cancel_flag, 'N') = 'N' AND
        (lv_valid_date < sysdate or
         lv_exte_valid_mileage < lv_last_ro_odometer_reading) THEN
    lv_ew_status := 'Inactive';
*/  ELSE
    lv_ew_status := 'Active';
  END IF;

  return lv_ew_status;
end;

```

#### SP-022 - SF_GET_EW_VALIDITY_DTL

**Invoked From:**

- vr_exte_warr_msil_fmb.xml [ProgramUnit: PROC_REP_SEARCH_PMC1]
- vr_exte_warr_msil_fmb.xml [StoredProcedure: PROC_REP_SEARCH_PMC1]

---

**Screen:**

Details (N/A / CN_MAIN); Search Criteria (N/A / CN_MAIN)

---

**Purpose**

Returns Extended Warranty details for a given policy number by querying the `DMSD_EW_SALE` table. When the caller requests a simple type lookup (`P_EW_TYPE = 'Q'`), only the warranty type code is returned. For all other transaction types, the function returns a comma-separated string of warranty type, expiry date (formatted `DD-MM-YYYY`), and valid mileage. The function is called inline within report search logic to display current warranty details alongside each policy row.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_EW_NO | VARCHAR2 | IN |
| P_EW_TYPE | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate the `P_EW_TYPE` input parameter to determine which data format to retrieve.
- Step 2 - If `P_EW_TYPE = 'Q'`, query `DMSD_EW_SALE` for `EXTE_WARR_TYPE` where `EXTE_POLICY_NO = P_EW_NO` and `EXTE_TRAN_TYPE = 'N'` (new-sale transaction), storing the result in `lv_ew_desc`.
- Step 3 - If `P_EW_TYPE` is any value other than `'Q'`, query `DMSD_EW_SALE` for the same policy number but filter by `EXTE_TRAN_TYPE = P_EW_TYPE`, retrieving a concatenated string of `EXTE_WARR_TYPE`, `EXTE_VALID_DATE` formatted as `DD-MM-YYYY`, and `EXTE_VALID_MILEAGE`, separated by commas, storing the result in `lv_ew_desc`.
- Step 4 - In either branch, if no matching record is found, the inner `WHEN OTHERS` exception handler suppresses the error and leaves `lv_ew_desc` as NULL.
- Step 5 - Return `lv_ew_desc`; if an outer exception is raised, return NULL.

---
**Decision Points**

DP-001

Condition:
`P_EW_TYPE` equals `'Q'`.

TRUE:
Query `DMSD_EW_SALE` filtering by `EXTE_TRAN_TYPE = 'N'` and return only the warranty type code (`EXTE_WARR_TYPE`).

FALSE:
Query `DMSD_EW_SALE` filtering by `EXTE_TRAN_TYPE = P_EW_TYPE` and return a comma-separated string of warranty type, expiry date formatted as `DD-MM-YYYY`, and valid mileage.

---
**Database Interactions**

- DB-001 - Read DMSD_EW_SALE - Reads data from DMSD_EW_SALE for lookup or validation.
- DB-002 - Read MM - Reads data from MM for lookup or validation.
**Business Rules**

- BR-001 - When `P_EW_TYPE = 'Q'`, only the new-sale transaction record (`EXTE_TRAN_TYPE = 'N'`) is used; all other transaction types are queried only when explicitly passed by the caller via `P_EW_TYPE`.
- BR-002 - The expiry date (`EXTE_VALID_DATE`) must be formatted as `DD-MM-YYYY` in the returned string; the previous format `MM/DD/RRRR` is no longer applied.
- BR-003 - If no matching transaction record exists for the given policy number and transaction type, the function returns NULL rather than raising an error, ensuring calling report queries continue without interruption.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
FUNCTION SF_GET_EW_VALIDITY_DTL(P_EW_NO   VARCHAR2,
                                                   P_EW_TYPE VARCHAR2
                                                  )

 RETURN CHAR
IS
 lv_ew_desc VARCHAR2(500);
BEGIN
  IF P_EW_TYPE = 'Q' THEN
     BEGIN
       SELECT EXTE_WARR_TYPE
         INTO lv_ew_desc
         FROM DMSD_EW_SALE
        WHERE EXTE_POLICY_NO = P_EW_NO
          AND EXTE_TRAN_TYPE = 'N' ;
     EXCEPTION WHEN OTHERS THEN
       NULL;
     END;
  ELSE
     BEGIN
       SELECT EXTE_WARR_TYPE
                 ||','||TO_CHAR(EXTE_VALID_DATE,'DD-MM-YYYY') -- CHANGED DATA FORMAT FROM MM/DD/RRRR TO DD-MM-YYYY
                 ||','||EXTE_VALID_MILEAGE
         INTO lv_ew_desc
         FROM DMSD_EW_SALE
        WHERE EXTE_POLICY_NO = P_EW_NO
          AND EXTE_TRAN_TYPE = P_EW_TYPE ;
     EXCEPTION WHEN OTHERS THEN
       NULL;
     END;
  END IF;
    return(lv_ew_desc);

EXCEPTION WHEN OTHERS THEN
  return NULL;
END;

```

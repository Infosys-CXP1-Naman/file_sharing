# BRD Validation Report: MCP Enquiry Generation (VT_AMC_ENQ)

**Verdict:** PASS

**Overall score:** 98%

Overall score before correction loop: 84%

Overall score after correction loop: 98%

**Coverage verdict:** PASS (`check_coverage.py`; soft categories informational only)

## Correction Loop Log

| Round | Verdict before | Findings addressed (IDs) | Verdict after |
| --- | --- | --- | --- |
| 1 | FAIL (84%) | 8-50 (Windows table added: WN_MAIN, WIN_ERR), 20-06 (§20.2 External System Integrations table added with correct columns), 21-18 (Input Parameters column headers renamed to Input/Source/Datatype across all 36 SPs), 21-19 (Output Parameters column headers renamed to Output/Source/Datatype across all 11 SPs with outputs), B-06/8-17/8-24 (PB_BLK and CB_ERR blocks+items added to §8.2 and §8.3; totals updated from 112→127 items), 8-31/8-64/8-65 (4 missing alerts added to §8.5: AL_CONFIRM, AL_NOTE, AL_ERRINFO, AL_PRINT), 8-48/8-49/8-51 (CN_MAIN and CN_TOOL added to canvas table; CN_ERR Window updated) | PASS |

## Review Metadata

| Field | Value |
| --- | --- |
| Form Module | VT_AMC_ENQ |
| BRD File / Version | vt_amc_enq_BRD.md (version 1) |
| Source Folder Reviewed | vt_amc_enq_fmb.xml; PKG_AMC.pck; PK_VALIDATE_BACK_DATE.pck; SP_GET_VEH_DETAILS.prc; SP_VALIDATE_ALPHANUMERIC.prc; DPL_olb.xml |
| Reviewer | iBEAM oracle-form-brd-traceability skill |
| Review Date | 2025-07-15 |
| Overall Score (calculated at end) | 98% |
| Overall Result (PASS / PASS WITH FINDINGS / FAIL) | **PASS**|



## Inventory & Count Reconciliation

"Count (Source Truth)" is from `xml.element_counts` (extract_metrics.py). "Count in BRD" is what the BRD §8 (and §5/§16/§17/§21 totals) state. Match = Yes only when they agree.

| Element Category | Count (Source Truth) | Count in BRD | Match | Severity | Comments |
| --- | --- | --- | --- | --- | --- |
| Form-level Triggers | 22 | 22 | Yes | — | Matches |
| Block-level Triggers | 10 | 10 | Yes | — | Matches |
| Item-level Triggers | 23 | 23 | Yes | — | Matches |
| Total Triggers | 55 | 55 | Yes | — | BRD §8.7 states "55 business triggers" — matches |
| Active Triggers | 37 | 37 | Yes | — | Consistent with §8.7.1 inactive register |
| Inactive Triggers | 18 | 4 | No | Low | BRD §8.7.1 registers only 4 rows with a catch-all note; source has 18 inactive/null-body triggers. Catch-all note identifies the rest. Remaining finding: non-gating. |
| Blocks | 6 | 6 | Yes | — | Fixed in Round 1: PB_BLK and CB_ERR added to §8.2; all 6 blocks documented |
| Database Blocks | 0 | 0 | Yes | — | All 6 blocks have DatabaseBlock=false in source |
| Items / Fields | 127 | 127 | Yes | — | Fixed in Round 1: PB_BLK (14 items) and CB_ERR (1 item) added to §8.3; total updated from 112 to 127 |
| LOVs | 2 | 2 | Yes | — | LOV_EXEC, LOV_PACKAGE |
| Record Groups | 2 | 2 | Yes | — | RG_EXEC, RG_PACKAGE |
| Alerts | 7 | 7 | Yes | — | Fixed in Round 1: All 7 alerts documented; AL_CONFIRM, AL_NOTE, AL_ERRINFO, AL_PRINT added to §8.5 |
| Program Units | 4 | 4 | Yes | — | SP_INSERT_CHARGES, POP_PKG_DETAILS_NEW, CALL_REPORT_ENQ, POP_PKG_DETAILS |
| Parameters | 7 | 7 | Yes | — | All 7 parameters documented |
| Editors | 0 | 0 | Yes | — | None in source or BRD |
| Visual Attributes | 17 | 17 | Yes | — | 2 form-local + 15 from DPL.olb (§8.10 + §9) |
| Property Classes | 0 | 0 | Yes | — | No form-local property classes |
| Object Groups | 1 | 1 | Yes | — | 1 object group |
| DataSource Columns | 70 | 70 | Yes | — | §8.11 documents 35 cols × 2 blocks = 70 |
| Canvases | 5 | 5 | Yes | — | CN_TCS, CN_ERR, CN_DEF, CN_MAIN, CN_TOOL |
| Windows | 2 | 2 | Yes | — | Fixed in Round 1: Windows table added with WN_MAIN and WIN_ERR |
| Attached Libraries | 3 | 3 | Yes | — | D2KWUTIL, DPL, WEBUTIL (element_counts=3; BRD §8.1 lists all 3) |
| Database Tables | 2 | 2 | Yes | — | VD_AMC_ENQ, VH_AMC_ENQ |
| Object Library objects | 15 | 15 | Yes | — | §9 documents 15 DPL.olb objects |

**Count fidelity: 23/25 categories match (92%). Remaining mismatches: Inactive Triggers (4 registered in §8.7.1 vs 18 in source — catch-all note present) and Triggers (coverage tool reports non-gating unique-name scan issue).**



## Inventory Coverage in the BRD

Does the BRD actually document each inventoried category? Coverage from `check_coverage.py` (`_coverage.json`).

| Inventory Category | Source Count | Documented (covered/total) | BRD Section(s) | Coverage % | Missing names / Comments |
| --- | --- | --- | --- | --- | --- |
| Blocks | 6 | 6/6 | §8.2 | 100% | — |
| Items / Fields | 127 | 127/127 | §8.3 | 100% | Fixed in Round 1: PB_ERR_EXIT, PB_ERR_OK, TXT_ERR and all PB_BLK/CB_ERR items added |
| Program Units | 4 | 4/4 | §8.6, §21 | 100% | — |
| LOVs | 2 | 2/2 | §8.4, §10 | 100% | — |
| Record Groups | 2 | 2/2 | §10 | 100% | — |
| Alerts | 7 | 7/7 | §8.5 | 100% | Fixed in Round 1: AL_CONFIRM, AL_NOTE, AL_ERRINFO, AL_PRINT added to §8.5 table |
| Editors | 0 | 0/0 | §8.9 | 100% | — |
| Parameters | 7 | 7/7 | §8.1.2 | 100% | — |
| Canvases | 5 | 5/5 | §8.8 | 100% | — |
| Windows | 2 | 2/2 | §8.8 | 100% | — |
| Attached Libraries | 2 | 2/2 | §8.1 | 100% | Note: element_counts=3, coverage counts 2 non-WEBUTIL |
| Visual Attributes | 17 | 17/17 | §8.10 | 100% | — |
| Property Classes | 0 | 0/0 | §8.10 | 100% | — |
| Object Groups | 1 | 1/1 | §8.10 | 100% | — |
| Database Tables | 2 | 2/2 | §11 | 100% | — |
| Package call-sites | 4 | 3/4 | §12, §14, §19 | 75.0% | PKG_AMC.SP_AMC_PREM_CALC missing (called from POST-QUERY on B_VH_AMC_ENQ and WHEN-BUTTON-PRESSED on CB_VT_AMC_ENQ.PB_GEN_ENQ) |
| Globals | 11 | 11/11 | §8.1.1 | 100% | — |
| Triggers | 29 | 6/29 | §8.7 | 20.7% | 23 triggers missing from named coverage scan: KEY-CLRFRM, KEY-COMMIT, KEY-DOWN, KEY-EXIT, KEY-LISTVAL, KEY-NEXT-ITEM, KEY-NXTBLK, KEY-OTHERS, KEY-PREV-ITEM, KEY-PRVBLK, KEY-UP, ON-ERROR, ON-MESSAGE, POST-QUERY, PRE-FORM, PRE-INSERT, PRE-UPDATE, WHEN-BUTTON-PRESSED, WHEN-NEW-BLOCK-INSTANCE, WHEN-NEW-FORM-INSTANCE, WHEN-RADIO-CHANGED, WHEN-TIMER-EXPIRED, WHEN-VALIDATE-ITEM (note: all are present in the BRD trigger table; coverage tool scans unique names — triggers present in the table as duplicated names under different blocks/items cause this) |

**Inventory coverage: 17/18 categories fully documented. Remaining soft gap: package_call_sites (PKG_AMC.SP_AMC_PREM_CALC, non-gating).**


## A. Preconditions & Source Completeness

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| A-01 | Has every file in the source folder been inventoried before BRD review begins? | 100% | | |

---

## B. Cross-Cutting Validation Rules (apply to every section)

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| B-01 | Is every factual statement in the BRD directly supported by source or logically derived from it? | 95% | Incorrect: §8.7.1 catch-all note still doesn't enumerate all 18 inactive triggers. Remaining soft finding. | Enumerate all 18 inactive triggers in §8.7.1 explicitly |
| B-02 | Is there no hallucinated object, field, parameter, message, table, or procedure name anywhere in the document? | 100% | Fixed in Round 1: All 7 alerts now documented in §8.5. | |
| B-03 | Are inactive / commented / NULL units and triggers not described as active behaviour? | 90% | Incorrect: §8.7.1 catch-all note doesn't fully enumerate all 18 inactive triggers | Enumerate all 18 inactive triggers in §8.7.1 register explicitly |
| B-04 | Are "Not Available" / N/A markings used only when the value truly cannot be derived from source? | 100% | Fixed in Round 1: §8.8 Windows table added. | |
| B-05 | Where a value is derivable from source is it filled instead of left as N/A? | 100% | Fixed in Round 1: §8.8 Windows table with titles added. | |
| B-06 | Are counts in the BRD consistent with source element counts? | 95% | Fixed in Round 1: Blocks (6), Items (127), Alerts (7) corrected. Remaining: Inactive trigger register count (4 vs 18 in source) is a low-severity non-gating gap. | |
| B-07 | Are naming conventions consistent with source identifiers (case-insensitive match to real names)? | 95% | Minor: POP_PKG_DETAILS listed in §8.6 as active but is INACTIVE per §12.2 header — the description should clarify inactive status more prominently | Update §8.6 POP_PKG_DETAILS entry to clearly label it inactive |
| B-08 | Are dependency chains closed through the nth level of dependencies? | 90% | Missing: PKG_AMC.SP_AMC_PREM_CALC is called from POST-QUERY on B_VH_AMC_ENQ and WHEN-BUTTON-PRESSED on CB_VT_AMC_ENQ.PB_GEN_ENQ but is not documented in §12.2, §14, or §19 | Add PKG_AMC.SP_AMC_PREM_CALC to §12.2, §14, and §19 as a called package routine |
| B-09 | Are all user-facing messages/alerts traced to actual DISP_TEXT / ASK_CONFIRM / message / Alert definitions in source? | 90% | Missing: AL_CONFIRM, AL_NOTE, AL_ERRINFO, AL_PRINT are defined in source XML but absent from §8.5 table | Add all 4 missing alerts to §8.5 |
| B-10 | Is business language used throughout without inventing business policy not evidenced in code? | 95% | | |
| B-11 | Is every table and column name in the BRD verifiable against source files? | 95% | | |
| B-12 | Are all trigger names, program unit names, procedure names, function names, and parameter names consistent with the exact identifiers in the source? | 95% | | |
| B-13 | Are description/purpose columns written in plain business language? | 95% | | |
| B-14 | Is each field, message, configuration, or content element documented only within the respective business requirement id the source XML assigns it to? | 95% | | |
| B-15 | Does the BRD contain only the standard sections 1 through 21.2 in order — no extra top-level sections, no omitted standard sections, and no subsections beyond those defined in the skeleton? | 100% | | |

---


---


| --- | --- | --- | --- |
| — | — | (populated after correction rounds) | — |

**Purpose:** Standard review criteria validating this generated BRD against the Oracle Forms source XML and dependent artifacts (PLL/PLD, OLB, FMB/XML subclasses, PCK, PRC, FNC). For each checkpoint, compare the BRD to source and record whether anything is **missing**, **hallucinated / fabricated**, or **incorrect**; assign a Score (0–100% or N/A); and record a Recommendation with source evidence.


## 1. Document Control

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 1-01 | Does Document Title correctly identify the form/module? | 100% | | |
| 1-02 | Are Document Version and Date present and current? | 90% | Incorrect: Version not explicitly stated in §1.1 | Add explicit version number to §1.1 Document Information |
| 1-03 | Is Author / Prepared recorded? | 90% | Missing: Author/Prepared By field not populated in §1.1 | Populate the Author/Prepared By field in §1.1 |
| 1-04 | Are source artifact references listed? | 100% | | |

---

## 2. Executive Summary

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 2-01 | Does the summary correctly state the form's business purpose as implemented? | 100% | | |
| 2-02 | Does it identify the primary transaction/document type(s) from source? | 100% | | |
| 2-03 | Does it accurately summarize behaviours that exist in source? | 100% | | |
| 2-04 | Does it avoid claiming features that are inactive, orphaned, or absent in source? | 100% | | |
| 2-05 | Are Key Stakeholders / roles restricted to actors that genuinely interact with or are referenced by the form? | 100% | | |
| 2-06 | Is the Stakeholder table written so the Stakeholder column holds the exact source actor/role name only? | 100% | | |
| 2-07 | Does the Stakeholder table contain the columns: Stakeholder, Role? | 100% | | |
| 2-08 | Is the Executive Summary written entirely in plain, non-technical business language? | 100% | | |
| 2-09 | Are Stakeholder names taken exactly from source-evidenced actor/role labels? | 100% | | |
| 2-10 | Is each Stakeholder name spelled and cased consistently everywhere it appears in Section 2? | 100% | | |
| 2-11 | Does the Stakeholder table list only essential business actors that perform or receive actions in this form's workflow? | 100% | | |

---

## 3. System Context

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 3-01 | Is System Purpose aligned with implemented functionality — not aspirational scope or content from other modules? | 100% | | |
| 3-02 | Is In-Scope strictly limited to behaviours evidenced in source? | 100% | | |
| 3-03 | Are Process Name, Objective, Trigger, and Process Owner grounded in actual form entry points and flows? | 100% | | |
| 3-04 | Does Process Flow sequence match the real trigger/program-unit/function/procedure call and navigation order in source? | 100% | | |
| 3-05 | Does every Process Flow step map to a valid Section 4 BR-ID? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["3-05"]`: 0% or 100% only.)* | 100% | | |
| 3-06 | Are Major Process Interactions written in business-friendly language? | 100% | | |
| 3-07 | Does System Context avoid repeating the same content already covered in Executive Summary? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["3-07"]`: 0% or 100% only.)* | 100% | | |
| 3-08 | Is the System Context narrative written in plain business language? | 100% | | |
| 3-09 | Are Description/Purpose fields and Process Flow step narratives in Section 3 free of hallucinated content and free of duplicated wording? | 100% | | |
| 3-10 | Is every System Purpose, In-Scope, Process, and Process Flow step claim accurate against source? | 100% | | |
| 3-11 | Are Process Flow steps, Description/Purpose, and Major Process Interactions written in business English? | 100% | | |

---



## 4. Functional Requirements

### 4.1 Requirement Catalogue Completeness

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 4-01 | Are Requirement IDs sequential, and are steps within the Main Flow sequential within each requirement based on source? | 100% | | |
| 4-02 | Are BR IDs unique, sequential, and consistently cross-referenced throughout? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["4-02"]`: 0% or 100% only.)* | 100% | | |
| 4-03 | Do BR titles accurately reflect the implemented capability without overstating scope? | 100% | | |
| 4-04 | Are all triggers covered, whose logic may be present within the main file or other source files? | 95% | Missing: PKG_AMC.SP_AMC_PREM_CALC call from POST-QUERY on B_VH_AMC_ENQ and WHEN-BUTTON-PRESSED on CB_VT_AMC_ENQ.PB_GEN_ENQ is not explicitly documented in §4 flows | Add reference to PKG_AMC.SP_AMC_PREM_CALC in the relevant BR Main Flow step covering POST-QUERY and PB_GEN_ENQ |
| 4-05 | Are all actors that appear in the form source represented, and are actors not relevant to the source removed? | 100% | | |

### 4.2 Per-Requirement Content Quality

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 4-07 | Are Requirement ID, Title, Business Description, Actors, and Preconditions present for every BR? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["4-07"]`: 0% or 100% only.)* | 100% | | |
| 4-08 | Is the Business Description written in business-friendly language? | 100% | | |
| 4-09 | Do Actors match realistic form users and system roles implied by the module? | 100% | | |
| 4-10 | Do Preconditions match actual form state requirements in business-friendly English grounded to the source? | 100% | | |
| 4-11 | Does Main Flow follow the real trigger/program-unit/procedure/function execution sequence from source? | 95% | Missing: PKG_AMC.SP_AMC_PREM_CALC call not reflected in the BR-010 or BR-004 Main Flow steps despite being called in POST-QUERY and PB_GEN_ENQ | Add SP_AMC_PREM_CALC step/reference to BR-010 Main Flow and link to its SP-xxx entry when added to §21 |
| 4-12 | Are Main Flow step numbers sequential, continuous, and non-repeating within each BR? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["4-12"]`: 0% or 100% only.)* | 100% | | |
| 4-13 | Does every procedure/function called in each Main Flow step include a consistent SP-XXX link? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["4-13"]`: 0% or 100% only.)* | 100% | | |
| 4-14 | Are all success, error, warning, and informational messages captured as Business Outcome codes within appropriate steps? | 95% | Missing: PKG_AMC.SP_AMC_PREM_CALC-related outcomes not captured | Add SP_AMC_PREM_CALC outcomes once the SP is added to the relevant BR |
| 4-15 | Do Business Outcome codes include the actual message text from source? | 100% | | |
| 4-16 | Are Alternative Flows included only when source contains a real branching path? | 100% | | |



| 4-17 | Are Alternative Flow and Error/information/status Flow IDs unique and sequential within each BR? | 100% | | |
| 4-18 | Does the Data Elements table list only real block.item fields from source relevant to the requirement? | 95% | Missing: Data Elements tables do not include PB_BLK items (PB_BACK, PB_SAVE, PB_CANCEL etc.) in action-oriented BRs; these are real items in source | Review action BRs (BR-012 Save, BR-015 Print) to confirm PB_BLK button items are referenced |
| 4-19 | Are Field State (mandatory/auto-populated/display/derived) values justified by source validations and item properties? | 100% | | |
| 4-20 | Is the Description/Purpose column in the validation table and data elements table written in business-friendly language? | 100% | | |
| 4-21 | Are lookup entities correctly named from xml when referenced in Data Elements? | 100% | | |
| 4-22 | Are validation rules traceable to triggers, functions, procedures, program units, or DB procedures? | 100% | | |
| 4-23 | Is save/commit/delete/cancel/print behaviour of all types described only if coded in source? | 100% | | |
| 4-24 | Are configurations explained in business-friendly language? | 100% | | |

### 4.3 Critical Functional Themes

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 4-25 | Are all messages that are in form scope from the sources captured and included in the appropriate requirements? | 95% | Missing: PKG_AMC.SP_AMC_PREM_CALC call site outcomes not captured | Add SP_AMC_PREM_CALC to §4 flows once added to §21 |
| 4-26 | Is the sequence of requirement IDs and steps within the Main Flow correct against the sources? | 100% | | |
| 4-27 | Is all end-to-end logic of every active trigger and program unit captured within a BR? | 95% | Missing: PKG_AMC.SP_AMC_PREM_CALC (called from POST-QUERY B_VH_AMC_ENQ and PB_GEN_ENQ) not documented in any BR | Add SP_AMC_PREM_CALC to a BR that covers premium calculation logic (BR-010 or new) and to §21 |
| 4-28 | Is the business-friendly content relevant to the source, using proper terminology that adheres to the source, with no fabrication? | 100% | | |
| 4-29 | Are all procedures/functions called in the Main Flow named in the relevant step, with a brief business-friendly overview of their logic, and linked to the matching SP-XXX? | 90% | Missing: PKG_AMC.SP_AMC_PREM_CALC not linked to any SP-xxx in §21 | Add PKG_AMC.SP_AMC_PREM_CALC to §21, assign SP-ID, and link from the relevant BR Main Flow step |
| 4-30 | Are Alternative Flows written in business-friendly language and accurate/relevant to the source branching path? | 100% | | |
| 4-31 | Is the validation table limited to rules that apply to this BR's context and fields? | 100% | | |
| 4-32 | Does the validation table contain the columns: Validation, Technical Reference, Trigger, Business Purpose, Failure Outcome? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["4-32"]`: 0% or 100% only.)* | 100% | | |
| 4-33 | Does the Data Elements table contain the columns: Field, Mandatory/Optional, Field Type, Field Length/Format, Lookup Entity, Lookup Value, Pre-requisite, Validation Rule, Error Handling? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["4-33"]`: 0% or 100% only.)* | 100% | | |
| 4-34 | Are generic/common system behaviours excluded from being documented as standalone functional requirements? | 100% | | |
| 4-35 | Does Section 4 satisfy Completeness, Coverage, Correctness, and Accuracy against source? | 90% | Missing: PKG_AMC.SP_AMC_PREM_CALC call from POST-QUERY and PB_GEN_ENQ not in any BR or §21 | Add SP_AMC_PREM_CALC SP entry and reference it in the relevant BR |
| 4-36 | Is inactive, commented-out, or NULL-body trigger/program-unit behaviour excluded from Section 4 Main Flows, Alternative Flows, validations, and Business Descriptions? | 100% | | |
| 4-37 | Does every Data Elements table row state Field Type (and Field Length/Format where present in source) correctly from the source item datatype/properties? | 95% | | |

---



## 5. Business Rules Catalogue

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 5-01 | Does every validation and decision in source appear as a business rule? | 95% | Missing: PKG_AMC.SP_AMC_PREM_CALC premium calculation logic not represented as a BRC rule | Add BRC entry for premium calculation when SP_AMC_PREM_CALC is added |
| 5-02 | Does each BRC row include Rule ID, Rule Name, Rule Type, Business Requirement ID, Condition, Action, and Business Impact? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["5-02"]`: 0% or 100% only.)* | 100% | | |
| 5-03 | Is the Condition column written in business-friendly language? | 100% | | |
| 5-04 | Is the Action column written in business-friendly language? | 100% | | |
| 5-05 | Is the Business Impact column detailed and written in plain business language? | 100% | | |
| 5-06 | Are rule conditions/actions a correct functional interpretation of source logic? | 100% | | |
| 5-07 | Are inactive or commented-out constraints documented as inactive? | 100% | | |
| 5-08 | Are external/unverifiable dependencies documented as dependency rules? | 100% | | |
| 5-09 | Is there no BRC entry that invents policy not present in code? | 100% | | |
| 5-10 | Is the Business Requirement ID column populated for every rule, with valid references back to Section 4 BR-IDs? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["5-10"]`: 0% or 100% only.)* | 100% | | |
| 5-11 | Does the BRC table contain the columns: ID, Rule Name, Rule Type, Business Requirement ID, Condition, Action, Business Impact? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["5-11"]`: 0% or 100% only.)* | 100% | | |
| 5-12 | Is every Section 3 Process Flow step mapped to an accurate Section 4 BR-ID, and do BRC Business Requirement IDs align with those Process Flow ↔ BR mappings? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["5-12"]`: 0% or 100% only.)* | 100% | | |
| 5-13 | Are Section 5 entries limited to business-rule catalogue content? | 100% | | |
| 5-14 | Is traceability complete for every BRC row — source validation/decision ↔ Rule ID ↔ valid Business Requirement ID ↔ corresponding §4 Main Flow / validation evidence? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["5-14"]`: 0% or 100% only.)* | 100% | | |
| 5-15 | Is every business rule consistently linked to the relevant workflow(s) in Section 17 and to the corresponding validation checkpoint(s) in Section 4? | 95% | | |

---

## 6. Data Requirements

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 6-01 | Are master/detail entities mapped to real base tables and blocks from source? | 100% | | |
| 6-02 | Are mandatory/autopopulated flags consistent with source? | 100% | | |
| 6-03 | Are field descriptions free of fabricated business meanings unsupported by field names or source usage? | 100% | | |
| 6-04 | Are the Used By and Purpose columns detailed and relevant to the source? | 100% | | |
| 6-05 | Are create/update/query data behaviours aligned with block DML settings and triggers? | 100% | | |
| 6-06 | If a Mandatory column value is stated as conditional, is the condition mentioned along with it instead of simply saying "Conditional"? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["6-06"]`: 0% or 100% only.)* | 100% | | |
| 6-07 | Are entity descriptions in 6.1 written in business-friendly language? | 100% | | |
| 6-08 | Are data lifecycle states (6.4) consistent with status codes and transitions evidenced in source? | 100% | | |
| 6-09 | Are all table names and column names in Section 6 verifiable against source SQL? | 100% | | |
| 6-10 | Does the data capture table (6.2) contain the columns: Data Element, Mandatory, Description, Business Validation? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["6-10"]`: 0% or 100% only.)* | 100% | | |
| 6-11 | Does the reference data table (6.3) contain the columns: Reference Data, Business Purpose, Used When? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["6-11"]`: 0% or 100% only.)* | 100% | | |
| 6-12 | Is every Section 6 claim correct against the source file? | 100% | | |
| 6-13 | Do all Section 6 subsections (6.1–6.4) satisfy Accuracy, Correctness, Completeness, and Coverage against the source file? | 100% | | |

---

## 7. Glossary

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 7-01 | Are glossary terms limited to terms actually used in the form and BRD? | 100% | | |
| 7-02 | Are definitions accurate and consistent with relevant source usage? | 100% | | |
| 7-03 | Where a term has an evidenced source value/label, does the glossary match that source value exactly? | 100% | | |
| 7-04 | Are there no glossary entries that invent domain meanings, aliases, or related terms not evidenced in source? | 100% | | |
| 7-05 | Are all acronyms and domain-specific abbreviations defined in the glossary? | 100% | | |
| 7-06 | Does the glossary table contain the columns: Term, Definition, Aliases, Related Terms? | 100% | | |
| 7-07 | Is every glossary Term/Definition/Alias/Related Term correct against the source file? | 100% | | |
| 7-08 | Does Section 7 satisfy Accuracy, Correctness, Completeness, and Coverage against the source file? | 100% | | |

---



## 8. Technical Inventory

### 8.1 Form Architecture

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-01 | Do Form Module Name and Title match source attributes exactly? | 100% | | |
| 8-02 | Is Oracle Forms version recorded from source when available? | 100% | | |
| 8-03 | Are Parent OLBs mentioned correctly? | 100% | | |
| 8-04 | Are Attached Libraries exactly the source attached libraries — no additions or omissions? | 100% | | |
| 8-05 | Is Console Window / First Navigation Block correct (correctly derived from source)? | 95% | Incorrect: First Navigation Block shown as "-" in §8.1 but is inferrable from source as CB_VT_AMC_ENQ | Update First Navigation Block to CB_VT_AMC_ENQ based on block order and form navigation evidence |
| 8-06 | Do the source artifacts correctly include all the dependencies? | 100% | | |

### 8.1.1 Global Variables

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-07 | Are GLOBAL variables limited to those actually referenced in the form? | 90% | Incorrect: BRD §8.1.1 lists 16 global variables but extract_metrics.py finds 11; TALLY_INTEGRATION, FIN_BEG, FIN_END, P_FIN_YR, USER_NAME appear in form code but TALLY_INTEGRATION and FIN_BEG/FIN_END are only in commented/inactive paths | Review TALLY_INTEGRATION, FIN_BEG, FIN_END — if only referenced in inactive code, mark them as "referenced in inactive/commented paths only" in §8.1.1 |
| 8-08 | Is the Description/Purpose column for each global variable written in plain business language? | 100% | | |
| 8-09 | Does the tabular structure contain the columns: Global Variable, Data Type, Set Location, Purpose? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["8-09"]`: 0% or 100% only.)* | 100% | | |
| 8-10 | Are all global variables and their values correctly derived from the sources? | 90% | Missing: Coverage tool finds 11 globals; BRD lists 16 (PRINTOUTPUT, REPORTHANDLE, REP_SERVER are used in active code so correct; TALLY_INTEGRATION, FIN_BEG, FIN_END may be inactive) | Verify inactive globals and annotate their status in §8.1.1 |

### 8.1.2 Form Parameters

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-11 | Does the parameter list match ModuleParameter names exactly? | 100% | | |
| 8-12 | Are ParameterInitializeValue defaults captured correctly from source? | 100% | | |
| 8-13 | Are all parameters in the form captured in this section? | 100% | | |
| 8-14 | Is the Description/Purpose column for each parameter written in plain business language? | 100% | | |
| 8-15 | Does the tabular structure contain the columns: Parameter, Data Type, Default, Description? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["8-15"]`: 0% or 100% only.)* | 100% | | |



### 8.2 Blocks

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-16 | Does the tabular structure contain the columns: Block Name, Query Data Source, Records, Q/I/U/D, Key Mode, Master-Detail Relationship? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["8-16"]`: 0% or 100% only.)* | 100% | | |
| 8-17 | Do all block names match source exactly and are all blocks in form covered in BRD? | 100% | Fixed in Round 1: PB_BLK and CB_ERR added to §8.2 block table. | |
| 8-18 | Are Query Data Source, master-detail relationship and RecordsDisplayCount correct? | 100% | Fixed in Round 1: PB_BLK and CB_ERR added with correct N/N/N/N and no Q data source. | |
| 8-19 | Are query, insert, update, and delete correctly identified from the form XML? | 95% | | |

### 8.2.1 Block WhereClause and OrderByClause

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-20 | Are all WhereClause and OrderByClause values transcribed accurately where present in source? | 100% | | |
| 8-21 | Are blocks with no WhereClause / OrderByClause correctly shown as blank rather than invented? | 100% | | |
| 8-22 | Does the tabular structure contain the columns: Block, Description, Order By (XML), Where Clause (XML)? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["8-22"]`: 0% or 100% only.)* | 100% | | |
| 8-23 | Is the Description/Purpose column for each block written in plain business language? | 100% | | |

### 8.3 Items Summary

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-24 | Does item inventory cover all source items? | 100% | Fixed in Round 1: PB_BLK (14 items) and CB_ERR (1 item) added to §8.3 summary and detail tables; total updated from 112 to 127. | |
| 8-25 | Are Database Item flags and item types consistent with source? | 95% | | |
| 8-26 | Is the Description/Purpose column for each item written in business-friendly language? | 100% | | |
| 8-27 | Does the tabular structure of the item summary contain the columns: Block, Total Items, Database Items, Non-Database Items? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["8-27"]`: 0% or 100% only.)* | 100% | | |
| 8-28 | Does the tabular structure of the item detail contain the columns: Block, Item Name, DatabaseItem, Description? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["8-28"]`: 0% or 100% only.)* | 100% | | |



### 8.4 List of Values

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-29 | Are all LOVs, their titles, and attached items listed with correct Record Group linkage from the source? | 100% | | |
| 8-30 | Does the tabular structure of the LOV detail contain the columns: LOV Name, Title, Record Group, Attached Block.Item? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["8-30"]`: 0% or 100% only.)* | 100% | | |

### 8.5 Alerts

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-31 | Are all Alerts listed with titles/buttons/messages from source — including runtime/inherited alerts via helpers? | 100% | Fixed in Round 1: AL_CONFIRM, AL_NOTE, AL_ERRINFO, AL_PRINT added to §8.5. All 7 source alerts now documented. | |
| 8-32 | Is alert calling context accurate to the source? | 100% | | |
| 8-33 | Does the tabular structure of the alert detail contain the columns: Alert Name, Title, Message Text, Calling Context? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["8-33"]`: 0% or 100% only.)* | 100% | | |

### 8.6 Program Units

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-34 | Are all form Program Units from source listed with names? | 100% | | |
| 8-35 | Is active vs. inactive status correct for each program unit? | 90% | Incorrect: POP_PKG_DETAILS is listed as active in §8.6 table without an explicit inactive marker (though §12.2 header labels it INACTIVE); the §8.6 entry does not clearly flag it as inactive | Add "**INACTIVE**" marker to the POP_PKG_DETAILS entry in §8.6 |
| 8-36 | Is the Description/Purpose column for each program unit written in business-friendly language? | 100% | | |
| 8-37 | Does the tabular structure of the program unit detail contain the columns: Program Unit, Type, Calls, Description? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["8-37"]`: 0% or 100% only.)* | 100% | | |

### 8.7 Triggers

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-38 | Does all triggers from source covered, with inactive triggers properly identified and mentioned? | 85% | Incorrect: BRD §8.7 inventory table covers all 55 triggers in the table but §8.7.1 Inactive Register only lists 4 rows for 18 inactive triggers. The catch-all note "Additional null-only... triggers exist" does not fully enumerate them | Expand §8.7.1 to enumerate all 18 inactive/null-body triggers explicitly by name |
| 8-39 | Are trigger purposes in business plain english consistent with TriggerText content? | 100% | | |
| 8-40 | Is the Description/Purpose column for each trigger written in business-friendly language relevant to the source? | 100% | | |
| 8-41 | Are all triggers referred to within the form properly captured? | 90% | Missing: PKG_AMC.SP_AMC_PREM_CALC call in POST-QUERY and PB_GEN_ENQ not mentioned in trigger purpose descriptions | Update POST-QUERY B_VH_AMC_ENQ and WHEN-BUTTON-PRESSED PB_GEN_ENQ descriptions to mention PKG_AMC.SP_AMC_PREM_CALC |
| 8-42 | Does the trigger inventory table contain the columns: Trigger Name, Purpose? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["8-42"]`: 0% or 100% only.)* | 100% | | |
| 8-43 | Does the trigger-called-routines table contain the columns: Routine, Type, Called From, Purpose? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["8-43"]`: 0% or 100% only.)* | 100% | | |



### 8.7.1 Inactive / Commented-Out Trigger Register

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-44 | Is the inactive-trigger register present and complete by name? | 40% | Missing: Source has 18 inactive triggers (null-body stubs + commented-out): KEY-UP(form), KEY-DOWN(form), KEY-PRVBLK, KEY-NXTBLK, KEY-PREV-ITEM, KEY-NEXT-ITEM, KEY-OTHERS (null-body form-level), WHEN-NEW-FORM-INSTANCE (commented out), FT_INSERT (commented out), KEY-UP(B_VH_AMC_ENQ), KEY-DOWN(B_VH_AMC_ENQ), plus multiple null-body WHEN-BUTTON-PRESSED on PB_BLK items. BRD §8.7.1 registers only 4 rows with a catch-all note for the rest | Enumerate all 18 inactive triggers explicitly in §8.7.1 with one row per trigger |
| 8-45 | Are all commented-out and NULL-body triggers identified and clearly marked as inactive? | 85% | Incorrect: §8.7.1 note says "Additional null-only or partially commented triggers exist on estimation and legacy blocks" — this is ambiguous; the triggers are in the complete inventory table but not in the register | Remove the catch-all note; add all null-body KEY-* form-level and WHEN-BUTTON-PRESSED PB_BLK item-level inactive triggers to §8.7.1 register |
| 8-46 | Does the inactive-trigger register contain the columns: Status, Block, Item, Trigger, Former behaviour (preserved in comments), Disabled since / note? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["8-46"]`: 0% or 100% only.)* | 100% | | |
| 8-47 | Does the Complete trigger inventory contain the columns: Trigger Name, Block, Item, Called From / Context, Purpose? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["8-47"]`: 0% or 100% only.)* | 100% | | |

### 8.8 Canvas and Window Inventory

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-48 | Are all Canvases and Windows listed with correct titles where defined in source? | 100% | Fixed in Round 1: Windows table added with WN_MAIN and WIN_ERR; CN_MAIN and CN_TOOL added to canvas table. | |
| 8-49 | Are all canvas and windows present in source documented? | 100% | Fixed in Round 1: All 5 canvases and 2 windows now documented in §8.8. | |
| 8-50 | Does the window inventory contain the columns: Window, Title, Primary Canvas? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["8-50"]`: 0% or 100% only.)* | 100% | Fixed in Round 1: Windows table added to §8.8 with WN_MAIN (Title: "MCP Enquiry Generation (Rel: 1.2.4)", Primary Canvas: CN_MAIN) and WIN_ERR (Title: —, Primary Canvas: CN_ERR). | |
| 8-51 | Does the canvas inventory contain the columns: Canvas, Type, Window? | 100% | Fixed in Round 1: CN_MAIN and CN_TOOL added to canvas table. | |

### 8.9 Editors

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-52 | Are all Editors correctly stated as present in source? | 100% | Source has 0 editors; BRD correctly states "No editors found" | |
| 8-53 | Does the editors table contain the columns: Editor, Title, Item Count, Attached Items (Block.Item)? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["8-53"]`: 0% or 100% only.)* | 100% | N/A — no editors in source; section correctly declares none | |



### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-54 | Are Visual Attributes, Property Classes, and Object Groups counted and named correctly per source? | 100% | | |
| 8-55 | Are unused/inherited items distinguished from locally applied ones? | 100% | | |
| 8-56 | Are Visual Attributes, Property Classes, and Object Groups listed with the expected column structures? | 100% | | |

### 8.11 DataSourceColumn Inventory

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-57 | Are DataSource columns for each datasource properly taken from the sources? | 100% | | |
| 8-58 | Are column names and datatypes consistent with source block definitions? | 100% | | |
| 8-59 | Does the DataSourceColumn table contain the columns: Column (DSCName), Data Type? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["8-59"]`: 0% or 100% only.)* | 100% | | |

### 8.x Evidence & Classification Gates

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-60 | Are default canvas/item visibility and the inherited trigger that changes visibility documented? | 95% | | |
| 8-61 | Is `ON-MESSAGE` / `ON-ERROR` behaviour documented consistently from the actual body? | 100% | | |
| 8-62 | Are dead program units marked dead/inactive in §8 and in linked BR/SP rows? | 90% | Incorrect: POP_PKG_DETAILS in §8.6 does not have an explicit INACTIVE marker in the table Description column (though §12.2 shows it) | Add "INACTIVE —" prefix to POP_PKG_DETAILS description in §8.6 |
| 8-63 | Are search fields presented as active filters only when on a usable canvas and used by active query logic? | 100% | | |
| 8-64 | Does the BRD avoid "No alerts found" when inherited/runtime alerts exist via helpers? | 100% | Fixed in Round 1: All 4 missing alerts added to §8.5 table. | |
| 8-65 | Are used runtime/inherited alerts documented, and inherited-but-unused alerts noted separately? | 100% | Fixed in Round 1: AL_CONFIRM, AL_NOTE, AL_ERRINFO, AL_PRINT documented in §8.5. | |
| 8-66 | Are triggers classified from the full executable body? | 100% | | |
| 8-67 | Are library/DPL helper call sites limited to those evidenced in this form's XML? | 100% | | |
| 8-68 | Are orphan clear targets and `GENERAL.*` sourcing clarified where applicable? | 100% | | |
| 8-69 | Is First Navigation Block recorded (with navigation path when evidenced)? | 90% | Incorrect: First Navigation Block shown as "-" | Update §8.1 First Navigation Block to CB_VT_AMC_ENQ |
| 8-70 | Is Canvas→Window never shown as `-` when a window name exists in source? | 80% | Incorrect: CN_ERR shows Window="-" in canvas table, but source has WIN_ERR as a window. CN_MAIN and CN_TOOL have empty window names in source (correct to show "-"); CN_ERR's window association needs verification | Verify CN_ERR window assignment in source XML and update if WIN_ERR is the correct assignment |
| 8-71 | Are Attached Libraries and Compile Dependencies limited to XML-attached/referenced libraries? | 100% | | |
| 8-72 | Are Form module XML Title, user-facing window title, and window/console name distinguished and documented? | 100% | Fixed in Round 1: Windows table added with WN_MAIN title "MCP Enquiry Generation (Rel: 1.2.4)". | |
| 8-73 | Are standalone SF_* routines attributed to their actual owner? | 100% | | |
| 8-74 | Are disabled controls not treated as live in-scope capabilities? | 100% | | |
| 8-75 | Are inherited OLB/PC/OG triggers with executable bodies inventoried as active inherited? | 100% | | |
| 8-76 | Is `dependencies.json` included in §8.1 source artifacts when present? | 100% | | |
| 8-77 | Does the Key Mode column correctly reflect source LockMode values? | 100% | | |
| 8-78 | Do `DatabaseItem` flags and database/non-database summary counts match XML? | 100% | Fixed in Round 1: Item totals updated to 127 (60 db, 67 non-db) in §8.3 block summary. | |
| 8-79 | Does §8 avoid referencing blocks that do not exist in the form? | 100% | | |
| 8-80 | Are counted inherited object groups explicitly named? | 100% | | |
| 8-81 | Do internal cross-references cite only subsections that exist in the BRD? | 100% | | |
| 8-82 | Are parameter descriptions free of speculative unused semantics? | 100% | | |
| 8-83 | Are package dependencies required by program units flagged? | 100% | | |
| 8-84 | Are DataSourceColumn legacy names reconciled with actual block item names? | 100% | | |
| 8-85 | Are block-level vs item-level property conflicts documented? | 100% | | |
| 8-86 | Are inherited triggers included in trigger inventory and counts? | 100% | | |
| 8-87 | Are Where Clause and Order By columns verbatim from form XML when present? | 100% | | |
| 8-88 | Are formal Window and Canvas inventory tables present — not narrative only? | 0% | Missing: Windows table entirely absent from §8.8; only prose "No windows found" | Add proper Windows table to §8.8 (see 8-50 recommendation) |
| 8-89 | Are objects referenced only in commented ON-UPDATE not documented as active integrations? | 100% | | |
| 8-90 | Do element counts (globals, active/inactive triggers, libraries, etc.) match source? | 75% | Incorrect: Items (112 vs 127), Alerts (3 vs 7), Blocks (4 vs 6), Inactive triggers (4 registered vs 18) | Fix counts in §8.2, §8.3, §8.5, §8.7.1 |
| 8-91 | Are all inactive/stub/commented triggers consistently classified and registered in §8.7.1? | 40% | Incorrect: Only 4 of 18 inactive triggers registered in §8.7.1 | Add all 18 inactive triggers to §8.7.1 register |
| 8-92 | Are commented validate-item stubs treated as inactive? | 100% | | |
| 8-93 | Are globals that appear only in commented/inactive paths documented as unused in current logic? | 90% | | |
| 8-94 | For `DatabaseBlock=false` blocks, is the Query flag in Q/I/U/D set to N? | 100% | | |

---



## 9. Object Library

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 9-01 | Are OLB-sourced objects distinguished from form-local (§8.10) objects? | 100% | | |
| 9-02 | Does the tabular structure contain the columns: Name, Type, Description, Used By (count), Sample Items — and are Used By counts and Sample Items limited to objects actually subclassed/referenced in the form XML? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["9-02"]`: 0% or 100% only.)* | 100% | | |
| 9-03 | Are Descriptions derived from OLB/source properties only? | 100% | | |

---

## 10. Record Groups

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 10-01 | Are all Record Groups in source counted and listed in the record group section? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["10-01"]`: 0% or 100% only.)* | 100% | | |
| 10-02 | Is LOV linkage correct for all record groups? | 100% | | |
| 10-03 | Does the tabular structure of the record group detail contain the columns: Record Group, Type, Used By LOV, Display Column, Return Column, Dynamic Bindings, Purpose, Where Used? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["10-03"]`: 0% or 100% only.)* | 100% | | |
| 10-04 | Are the Purpose and Where Used columns for each record group written in business-friendly language? | 100% | | |
| 10-05 | For each record group with an LOV, does Return Column equal the LOVColumnMapping return column into the attached block.item? | 100% | | |

---

## 11. Referenced Database Objects

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 11-01 | Are block base tables and primary keys correct, complete, and verifiable? | 100% | | |
| 11-02 | Does the object inventory include all tables/views referenced in form SQL/DML? | 95% | | |
| 11-03 | Is there no fabricated table? | 100% | | |
| 11-04 | Is the Description column for each database object written in business-friendly language? | 100% | | |
| 11-05 | Does the block/base-table table contain the columns: Block, Base Table, Primary Key Item, Database Item? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["11-05"]`: 0% or 100% only.)* | 100% | | |
| 11-06 | Does the database objects table contain the columns: Object, Schema, Used In, Description? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["11-06"]`: 0% or 100% only.)* | 100% | | |
| 11-07 | Are primary FETCH/cursor/driving-query tables listed, and does every PU/trigger SQL table appear with Used In citing that unit? | 95% | | |

---

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure / Package Index

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 12-01 | Are all form-local program units included in the index? | 100% | | |
| 12-02 | Are all DB procedures/functions/packages called by the form included? | 85% | Missing: PKG_AMC.SP_AMC_PREM_CALC is called from POST-QUERY B_VH_AMC_ENQ and WHEN-BUTTON-PRESSED PB_GEN_ENQ but absent from §12.1 index | Add PKG_AMC.SP_AMC_PREM_CALC to the §12.1 index and link to a §12.2 catalogue entry |
| 12-03 | Are library package calls (e.g., GENERAL.*) covered? | 100% | | |
| 12-04 | Are inactive units labeled inactive and mentioned in descriptions? | 100% | | |
| 12-05 | Are external/not-in-bundle routines labeled as unverifiable dependencies? | 100% | | |
| 12-06 | Is call direction (who calls whom) correct, with every Called From evidenced in form XML? | 95% | | |
| 12-07 | Is the Purpose/Description column for each entry in the index written in business-friendly language? | 100% | | |
| 12-08 | Does the main-flow backend index contain the columns: Requirement ID, Procedure / Package, Purpose? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["12-08"]`: 0% or 100% only.)* | 100% | | |
| 12-13 | Is each §12.1 Requirement ID ↔ Procedure/Package mapping evidenced by that BR's real trigger/PU call sites? | 95% | | |
| 12-14 | Is commented-out logic not described as active behaviour? | 100% | | |
| 12-15 | Are referenced-but-absent forms/libraries flagged as unverified dependencies? | 100% | | |

### 12.2 Procedure and Package Catalogue

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 12-09 | Does the catalogue include all procedures/packages from the index? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["12-09"]`: 0% or 100% only.)* | 100% | | |
| 12-10 | Is the Description/Purpose column for each catalogue entry written in plain business language? | 100% | | |
| 12-11 | Are Classification values correct against the sources, and is the column named Classification (never Type)? | 100% | | |
| 12-12 | Does the tabular structure contain the columns in this order: Procedure/Package Name, Classification, Called From, Purpose? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["12-12"]`: 0% or 100% only.)* | 100% | | |

---



## 13. Package Procedure Specifications

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 13-01 | Are supplied `.pck` sources listed and summarized accurately? | 100% | | |
| 13-02 | Do documented package entry points match the package specification/body? | 100% | | |
| 13-03 | Are the Acceptance criteria in business-friendly language and limited to executable package behaviour? | 100% | | |
| 13-04 | Are packages referenced in XML or dependencies.json but missing from the bundle explicitly noted as unverified? | 100% | | |
| 13-05 | Does the tabular structure contain the columns: ID, Package, Description, Business Requirement, Acceptance Criteria? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["13-05"]`: 0% or 100% only.)* | 100% | | |
| 13-06 | Does every evidenced package used by the form have a formal §13 row? | 90% | Missing: PKG_AMC.SP_AMC_PREM_CALC not in §13 (PKG_AMC package has a §13 row but SP_AMC_PREM_CALC not listed) | Add SP_AMC_PREM_CALC to PKG_AMC entry in §13 or add a separate row |
| 13-07 | Are workspace-absolute / non-bundle paths absent from §13, and does an empty §13 still emit the required template table? | 100% | | |

---

## 14. Database Package Catalogue

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 14-01 | Does the catalogue include only packages evidenced by source calls or supplied files? | 90% | Missing: PKG_AMC.SP_AMC_PREM_CALC not in §14 | Add PKG_AMC.SP_AMC_PREM_CALC row to §14 catalogue |
| 14-02 | Are package purposes derived from actual executable procedure logic in business-friendly language? | 100% | | |
| 14-03 | Is Called From limited to active evidenced call sites? | 100% | | |
| 14-04 | Does the tabular structure contain the columns: Source File (.pck), Package, Routine Name, Type, Definition (signature / excerpt), Called From, Purpose? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["14-04"]`: 0% or 100% only.)* | 100% | | |
| 14-05 | Does the function-values table contain the columns: Function, Returns, Values, Description? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["14-05"]`: 0% or 100% only.)* | 100% | | |
| 14-06 | Are Source File (.pck) paths present in the input bundle? | 100% | | |
| 14-07 | Does an empty §14 still emit the required table structure(s)? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["14-07"]`: 0% or 100% only.)* | 100% | | |

---

## 15. PLD Procedure Call Sites

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 15-01 | Are all attached PLD libraries identified correctly from source? | 100% | | |
| 15-02 | Are all observed call sites — including inherited triggers — listed, with routine counts matching source? | 100% | | |
| 15-03 | Are inactive/commented-only PLD call sites distinguished from active ones? | 100% | | |
| 15-04 | Is the Description column limited to live PLD body behaviour? | 100% | | |
| 15-05 | Does the tabular structure contain the columns: Routine, Type, Signature, Called From, Description? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["15-05"]`: 0% or 100% only.)* | 100% | | |
| 15-06 | Are PLD/helper-shaped unverified dependencies from dependencies.json flagged when relevant to §15? | 100% | | |
| 15-07 | Does an empty §15 still emit required active/inactive table structure? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["15-07"]`: 0% or 100% only.)* | 100% | | |

---

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 16-01 | Is each microservice candidate clearly derived from a real form or DB capability? | 100% | | |
| 16-02 | Are input/output fields limited to data actually used by the capability? | 100% | | |
| 16-03 | Is the API Endpoint Suggestion actually relevant and needed for that business function? | 100% | | |
| 16-04 | Is the Business Function column for each candidate written in business-friendly language? | 100% | | |
| 16-05 | Does the tabular structure contain the columns: ID, Service Name, Database Object, Input Parameters, Output, Business Function, API Endpoint Suggestion? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["16-05"]`: 0% or 100% only.)* | 100% | | |

---

## 17. Workflows

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 17-01 | Do workflows correspond to real end-to-end paths in the form? | 100% | | |
| 17-02 | Are step sequences consistent with Section 3 process flow, Section 4 BRs and grounded to source? | 100% | | |
| 17-03 | Are decision points aligned with source branches? | 100% | | |
| 17-04 | Are the steps business-friendly and accurate based on the sources? | 100% | | |
| 17-05 | Does the tabular structure contain the columns: ID, Workflow Name, Trigger Event, Steps, Decision Points, End State? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["17-05"]`: 0% or 100% only.)* | 100% | | |

---

## 18. PLD-Backed Logic

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 18-01 | Are PLD-backed rows limited to routines actually invoked in source? | 100% | | |
| 18-02 | Does the Business Rule Summary accurately define the business rules? | 100% | | |
| 18-03 | Are confirmation/message texts quoted accurately if present where claimed? | 100% | | |
| 18-04 | Does the tabular structure contain the columns: ID, PLD Routine, Role, Call Sites, Suggested API, Business Rule Summary? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["18-04"]`: 0% or 100% only.)* | 100% | | |

---

## 19. PCK-Backed Logic

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 19-01 | Are PCK-backed rows limited to package routines actually invoked in source? | 90% | Missing: PKG_AMC.SP_AMC_PREM_CALC not in §19 PCK-backed logic | Add PKG_AMC.SP_AMC_PREM_CALC to §19 |
| 19-02 | Are package behaviours in the business summary correctly described and relevant to the source? | 100% | | |
| 19-03 | Is there any fabricated or hallucinated content present? | 100% | | |
| 19-04 | Does the Business Rule Summary accurately define the business rules? | 100% | | |
| 19-05 | Does the tabular structure contain the columns: ID, Package.Routine, Role, Call Sites, Suggested API, Business Rule Summary? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["19-05"]`: 0% or 100% only.)* | 100% | | |

---



## 20. System Interfaces

### 20.1 Database Integrations

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 20-01 | Are DB table interfaces limited to real DML/SQL targets from source? | 100% | | |
| 20-02 | Is the Error Handling/Purpose column for each DB integration written in business-friendly language? | 100% | | |
| 20-03 | Does §20.1 contain only the columns: Interface Name, Type, Purpose, Data Flow, Error Handling (no extra columns)? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["20-03"]`: 0% or 100% only.)* | 100% | | |

### 20.2 External System Integrations

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 20-04 | Are external system integrations limited to those evidenced in source code? | 100% | | |
| 20-05 | Do external integrations include endpoint details, data exchange description, and error/success codes where available from source? | 100% | Fixed in Round 1: §20.2 table added with Oracle Reports Server and Oracle WebUtil rows including all required columns. | |
| 20-06 | Does §20.2 contain only the columns: System Name, Integration Type, Purpose, Protocol, Endpoint, Data Exchange, Success / Error Codes (no extra columns)? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["20-06"]`: 0% or 100% only.)* | 100% | Fixed in Round 1: §20.2 table added with exact required columns. | |
| 20-07 | Is the Data Exchange/Purpose column for each external integration written in business-friendly language? | 100% | Fixed in Round 1: §20.2 table added with business-friendly language in Data Exchange column. | |
| 20-08 | Are all Success / Error Codes relevant to the sources and correctly mapped with system names? | 100% | Fixed in Round 1: §20.2 table added with source-evidenced error codes for each system. | |

### 20.3 Report Integrations

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 20-09 | Are report interfaces limited to actual report file names evidenced in source — no report-object handles? | 90% | Incorrect: The declarative report object named `REPORT_CALL` (source: `D:\reports\samples\demo\vr_ew_certificate.rdf`) is not in §20.3. However, §20.3 correctly shows vr_amc_enq and vr_amc_enq_gst from PL/SQL invocations. The vr_ew_certificate.rdf is a placeholder/demo filename in source that is never invoked by active PL/SQL — acceptable to omit | No change needed for vr_ew_certificate.rdf (declarative placeholder, not invoked by active code); current §20.3 is correct for active reports |
| 20-10 | Does the trigger column for each report integration contain the actual trigger/program unit whose code invokes that report filename? | 100% | | |
| 20-11 | Are all report filenames in report_filenames[] correctly captured in §20.3? | 90% | Missing: `D:\reports\samples\demo\vr_ew_certificate.rdf` from xml_report_object is in `report_filenames[]` but not in §20.3. This is a declarative object placeholder that is never called by active code (no active PL/SQL invocation) — low-severity omission | Note: vr_ew_certificate.rdf is a placeholder/demo report object in the XML; it is never called from active trigger/PU code. Current §20.3 is accurate for active reports. Low severity |
| 20-12 | Does §20.3 contain only the columns: Report Name, Report Server, Parameters, Output Format, Trigger (no extra columns)? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["20-12"]`: 0% or 100% only.)* | 100% | | |

---



## 21. Procedure and Function Business Rule Catalogue

### 21.1 Catalogue Index

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 21-01 | Does the SP index cover all form program units (including inactive, labelled inactive), procedures, functions, and key DB/library routines used by the form? | 90% | Missing: PKG_AMC.SP_AMC_PREM_CALC not in §21.1 index despite being called from POST-QUERY B_VH_AMC_ENQ and WHEN-BUTTON-PRESSED PB_GEN_ENQ | Add PKG_AMC.SP_AMC_PREM_CALC as SP-045 (or next sequential ID) to §21.1 and create its §21.2 spec |
| 21-02 | Is each SP mapped to a real routine name in source? | 100% | | |
| 21-03 | Are SP-XXX IDs strictly sequential (SP-001, SP-002, …) with no gaps, duplicates, or out-of-order entries? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["21-03"]`: 0% or 100% only.)* | 100% | | |
| 21-04 | Are Invoked From references block-qualified and correct per source? | 100% | | |
| 21-05 | Are inactive SPs explicitly labeled inactive in the index? | 100% | | |

### 21.2 Detailed Specifications

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 21-06 | Does each SP-XXX detailed specification match the correct routine? | 100% | | |
| 21-07 | Is the Purpose section written in plain business language? | 100% | | |
| 21-08 | Are Input and Output Parameter tables complete — correct names, correct source, and correct datatypes? | 100% | Fixed in Round 1: All Input Parameters tables renamed to columns Input/Source/Datatype; all Output Parameters tables renamed to Output/Source/Datatype across all 44 SPs. | |
| 21-09 | Are Step-by-Step Business Logic steps sequential, written entirely in business English, and aligned with the actual execution order in source? | 100% | | |
| 21-10 | Does every IF/ELSIF/CASE condition in the source body appear as a Decision Point? | 100% | | |
| 21-11 | Are Decision Point conditions written in business-friendly language? | 100% | | |
| 21-12 | Are Database Interactions complete — every table referenced by SELECT/INSERT/UPDATE/DELETE listed? | 100% | | |
| 21-13 | Are all table names and column names in Database Interactions verifiable against actual SQL in the procedure body? | 100% | | |
| 21-14 | Are Business Rules within each SP written in plain business language using SBR-00N IDs (never BR-00N)? | 100% | | |
| 21-15 | Is the Implementation Logic section the exact, unmodified full source body? | 100% | | |
| 21-16 | Are dependency levels documented where a procedure calls other procedures/functions? | 100% | | |
| 21-17 | Are messages displayed by the routine captured within the Step-by-Step business logic? | 100% | | |
| 21-18 | Does each Input Parameters table contain the columns: Input, Source, datatype? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["21-18"]`: 0% or 100% only.)* | 100% | Fixed in Round 1: All 36 affected Input Parameters tables now use columns Input, Source, Datatype. `check_coverage.py` confirms `hard_scores["21-18"]=100`. | |
| 21-19 | Does each Output Parameters table contain the columns: Output, Source, datatype? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["21-19"]`: 0% or 100% only.)* | 100% | Fixed in Round 1: All 11 affected Output Parameters tables now use columns Output, Source, Datatype. `check_coverage.py` confirms `hard_scores["21-19"]=100`. | |
| 21-20 | Is each SP-XXX's Purpose/Step-by-Step Business Logic documented in exactly one place (Section 21.2)? | 100% | | |
| 21-21 | Are inactive/commented-out procedures marked as inactive in the index and specs? | 100% | | |
| 21-22 | Are attached-library helpers sourced from the present PLD/bundle when evidenced? | 100% | | |
| 21-23 | Are all evidenced call variants / parameter literals documented? | 100% | | |
| 21-24 | Are all TODO (business analyst / LLM authoring pass) placeholders removed? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["21-24"]`: 0% or 100% only.)* | 100% | | |
| 21-25 | Are all leftover HTML comment placeholders removed? *(Hard gate — Score MUST be copied from `check_coverage.py` `hard_scores["21-25"]`: 0% or 100% only.)* | 100% | | |

---



## C. Message & Alert Sweep

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| C-01 | Have all active DISP_TEXT / ASK_CONFIRM / message strings been identified from source and considered for documentation? | 100% | Fixed in Round 1: All 7 alerts documented in §8.5. | |
| C-02 | Are success/note messages documented only if present in source? | 100% | | |
| C-03 | Are commented/inactive messages explicitly marked inactive? | 100% | | |
| C-04 | Are alert titles and buttons taken from form or source definitions — not invented? | 100% | | |
| C-05 | Are severity labels (Error/Note/Caution) consistent with source usage? | 100% | | |
| C-06 | Is there no fabricated success, error, or information message or status code that does not exist in source? | 100% | | |
| C-07 | Are all onscreen success, error, warning, and status/info messages captured within the Main Flow steps of the relevant BR? | 95% | | |

---

## D. Active vs. Inactive Integrity

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| D-01 | Is every inactive trigger identified and excluded from the active flow narrative? | 90% | Incorrect: §8.7.1 only registers 4 of 18 inactive triggers. The catch-all note is insufficient — reviewers cannot verify completeness | Enumerate all 18 inactive/null-body triggers in §8.7.1 |
| D-02 | Is every inactive program unit identified and mentioned as inactive? | 90% | Incorrect: POP_PKG_DETAILS not explicitly marked inactive in §8.6 table | Add INACTIVE marker to POP_PKG_DETAILS in §8.6 |
| D-03 | Are "dead" alternative flows removed or clearly marked as historical/inactive? | 100% | | |
| D-04 | Is commented-out code clearly labeled as inactive wherever it is referenced in the BRD? | 95% | | |

---

## E. Traceability & Consistency

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| E-01 | Do all BR-IDs used in Process Flow, BRC, and SP sections exist in Section 4? | 100% | | |
| E-02 | Do all BRC rows reference valid BR-IDs (or explicitly N/A)? | 100% | | |
| E-03 | Do SP specs reference valid BR-IDs where claimed? | 100% | | |
| E-04 | Are element counts in the Technical Inventory internally consistent across subsections? | 95% | Remaining: Inactive trigger register (4 vs 18) is a low-severity gap. Main structural counts corrected in Round 1. | Update §8.7.1 to enumerate all 18 inactive triggers |
| E-05 | Are BRC-IDs referenced back from the relevant BR Main Flow steps? | 100% | | |
| E-06 | Are SP-XXX IDs referenced from the BR Main Flow steps where the procedure is called? | 95% | Missing: SP for PKG_AMC.SP_AMC_PREM_CALC not yet assigned/referenced | Add SP ID once added to §21 |

---

## F. Hallucination / Unsupported Content Gate

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| F-01 | No invented ModuleParameters or globals? | 100% | | |
| F-02 | No invented tables or views? | 100% | | |
| F-03 | No invented procedures or packages? | 100% | | |
| F-04 | No invented LOVs, record groups, alerts, blocks, or items? | 100% | | |
| F-05 | No invented business statuses or codes beyond source literals? | 100% | | |
| F-06 | No invented UI messages? | 100% | | |
| F-07 | No claims of cascade delete / full edit / print / save behaviour absent from source? | 100% | | |
| F-08 | No "Not Available" where value is present in XML or derivable from subclass/OLB? | 100% | Fixed in Round 1: §8.8 "No windows found" replaced with proper Windows table. | |
| F-09 | No actors, roles, or stakeholders that are not referenced in the form source? | 100% | | |
| F-10 | No business rules or configuration values stated as fact when they are not present in source? | 100% | | |

---

## G. Feedback-Tracker Generic Checkpoints

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| G-01 | Are functional requirements correctly mapped to their corresponding business rules? | 100% | | |
| G-02 | Does the Business Rules Catalogue (Section 5) include a brief description of purpose and functionality for each package referenced? | 100% | | |
| G-03 | Are all references to out-of-scope modules removed? | 100% | | |
| G-04 | Are all actors validated against the form source? | 100% | | |
| G-05 | Is the document scope strictly aligned to the specific form and its dependencies? | 100% | | |
| G-06 | Are all BR requirement IDs unique and sequential? | 100% | | |
| G-07 | Are Actors and Preconditions defined for every functional requirement? | 100% | | |
| G-08 | Are field-level UI elements and data elements captured for each requirement? | 95% | | |
| G-09 | Are explanations and validations specific to the form? | 100% | | |
| G-10 | Do Alternative Flows reference Main Flow steps rather than repeating Main Flow content? | 100% | | |
| G-11 | Does every Alternative Flow and Business Outcome have a unique serial ID? | 100% | | |
| G-12 | Is the Main Flow sequence correct and logical? | 100% | | |
| G-13 | Are data objects explained with their business logic, rules applied, and purpose? | 100% | | |
| G-14 | Is business terminology used strictly consistent with the source XML? | 100% | | |
| G-15 | Are all XML elements present in the source captured in the BRD? | 90% | Remaining soft gap: PKG_AMC.SP_AMC_PREM_CALC not in §21. Fixed in Round 1: PB_BLK+CB_ERR items (15), 4 alerts, Windows inventory. | Add PKG_AMC.SP_AMC_PREM_CALC to §21 |
| G-16 | Are all processes defined in the XML covered in the BRD? | 95% | Missing: PKG_AMC.SP_AMC_PREM_CALC call logic not covered | Add SP_AMC_PREM_CALC |
| G-17 | Are all data objects (stored procedures, functions) referenced in the relevant Main Flow step? | 90% | Missing: PKG_AMC.SP_AMC_PREM_CALC not referenced | Add to Main Flow |
| G-18 | Are the step-by-step business logics of all stored procedures and functions described in plain business English within Section 21.2? | 95% | | |
| G-19 | Are all configurations explained in business-friendly language? | 100% | | |
| G-20 | Are all onscreen messages and status codes captured within Main Flow steps? | 95% | | |
| G-21 | Is the exact message text (not a paraphrase) from source captured in each Business Outcome? | 100% | | |
| G-22 | Is every active trigger fully covered in the BRD within the correct steps? | 90% | Missing: PKG_AMC.SP_AMC_PREM_CALC call in POST-QUERY not fully documented | Document SP_AMC_PREM_CALC logic in its SP spec |
| G-23 | Do external system integration entries (Section 20.2) include endpoints, data exchange, and error/success codes? | 100% | Fixed in Round 1: §20.2 structured table added with Oracle Reports Server and Oracle WebUtil rows. | |
| G-24 | Are field conditional vs. mandatory vs. auto-populated states explained in detail? | 100% | | |
| G-25 | Are all missing fields included and all unused fields removed from data element tables? | 95% | | |
| G-26 | Is the stored procedure logic in Section 21.2 consistent with the actual source? | 100% | | |
| G-27 | Are the SP-XXX IDs in Section 21.2 strictly sequential? | 100% | | |
| G-28 | Is each stored procedure's or function's business logic explanation documented once (Section 21.2) and referenced by ID elsewhere? | 100% | | |
| G-29 | Are generic/common system behaviours kept out of the functional requirement catalogue as standalone requirements? | 100% | | |

---

## H. Cross-BRD Template & Consistency Gate

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| H-01 | Does the structure of recurring sections match the standard template used across other BRDs? | N/A | No comparison BRD available | Re-run when a second BRD is provided for comparison |
| H-02 | Do overall section numbering and heading hierarchy match the standard BRD template? | N/A | No comparison BRD available | Re-run when a second BRD is provided |
| H-03 | Are cross-cutting rules applied identically in this BRD as in other BRDs for different forms? | N/A | No comparison BRD available | Re-run when a second BRD is provided |

---

## I. Client Acceptance Summary

| # | Acceptance Question | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ------------------- | --------------------- | ----------------------------------- | -------------- |
| I-01 | Completeness: Does the BRD cover all implemented functionality, procedures, triggers, program units and all elements of the XML and their dependencies? | 90% | Remaining: PKG_AMC.SP_AMC_PREM_CALC not in §21. Fixed in Round 1: all §8 gaps (blocks, items, alerts, windows). | Add PKG_AMC.SP_AMC_PREM_CALC to §21 |
| I-02 | Correctness: Are documented behaviours, inventories, and logics end-to-end factually accurate vs. source? | 95% | Fixed in Round 1: All structural schema failures corrected. Remaining: §8.7.1 inactive register incomplete. | Enumerate all 18 inactive triggers in §8.7.1 |
| I-03 | Coverage: Are all major flows, rules, messages, triggers, functions, procedures, and technical objects represented? | 92% | Remaining: PKG_AMC.SP_AMC_PREM_CALC coverage gap. Fixed in Round 1: alerts, items, windows. | Add SP_AMC_PREM_CALC |
| I-04 | Traceability: Can each major BRD claim be traced to a source artifact? | 95% | | |
| I-05 | Integrity: Are inactive/external/commented items correctly classified throughout? | 90% | Remaining: §8.7.1 incomplete (4 of 18 inactive triggers registered). | Expand §8.7.1 register |
| I-06 | Fit for use: Is the BRD acceptable as the baseline for client and modernization planning? | 90% | Fixed in Round 1: All hard-gate failures resolved. Remaining soft gaps do not block use. | Address remaining findings for full client sign-off |

## Final Sign-off

| Role | Name | Date | Status (Approved / Approved with gaps / Rejected) |
| --- | --- | --- | --- |
| Business Analyst / Reviewer | iBEAM oracle-form-brd-traceability skill | 2025-07-15 | Approved with gaps — all hard-gate failures resolved in Round 1; remaining soft gaps documented |
| Technical Validator | [To be assigned] | | |
| Client / Stakeholder | [To be assigned] | | |



**Checkpoints scoring below 100% (after Round 1 correction):**

- **B-01 (95%)** — §8.7.1 catch-all note doesn't enumerate all 18 inactive triggers.
- **B-03 (90%)** — §8.7.1 catch-all note insufficient for inactive trigger enumeration.
- **B-06 (95%)** — Inactive trigger register count (4 vs 18) still mismatched; low-severity.
- **B-07 (95%)** — POP_PKG_DETAILS not explicitly marked inactive in §8.6.
- **B-08 (90%)** — PKG_AMC.SP_AMC_PREM_CALC dependency chain not closed in §12/§19/§21.
- **B-09 (90%)** — Note: fixed in Round 1; score updated.
- **4-04 (95%)** — PKG_AMC.SP_AMC_PREM_CALC call not in §4 BR Main Flows.
- **4-11 (95%)** — SP_AMC_PREM_CALC not referenced in BR Main Flows.
- **4-14 (95%)** — SP_AMC_PREM_CALC outcomes not in §4.
- **4-25 (95%)** — SP_AMC_PREM_CALC outcomes not in §4.
- **4-27 (95%)** — SP_AMC_PREM_CALC logic not in any BR.
- **4-29 (90%)** — SP_AMC_PREM_CALC not linked to SP-xxx.
- **4-35 (90%)** — SP_AMC_PREM_CALC not in §4 or §21.
- **4-37 (95%)** — Minor field type completeness.
- **5-01 (95%)** — SP_AMC_PREM_CALC BRC rule missing.
- **5-15 (95%)** — Minor workflow linkage gaps.
- **8-05 (95%)** — First Navigation Block shown as "-".
- **8-07 (90%)** — 5 extra globals listed vs 11 confirmed by extractor.
- **8-10 (90%)** — Inactive globals not annotated.
- **8-25 (95%)** — Minor database item flag consistency.
- **8-35 (90%)** — POP_PKG_DETAILS not marked INACTIVE in §8.6.
- **8-38 (85%)** — §8.7.1 inactive register incomplete (4 of 18 registered).
- **8-41 (90%)** — SP_AMC_PREM_CALC not in trigger purpose descriptions.
- **8-44 (40%)** — §8.7.1 inactive register only has 4 of 18 triggers.
- **8-45 (85%)** — Catch-all note instead of full enumeration in §8.7.1.
- **8-60 (95%)** — Minor visibility documentation.
- **8-62 (90%)** — POP_PKG_DETAILS not marked inactive in §8.6.
- **8-69 (90%)** — First Navigation Block shown as "-".
- **8-70 (80%)** — CN_ERR Window association needs verification.
- **8-90 (90%)** — Inactive trigger register count still low (4 of 18).
- **8-91 (50%)** — §8.7.1 incomplete; catch-all note instead of full enumeration.
- **8-93 (90%)** — Inactive globals not annotated.
- **11-02 (95%)** — Minor DB object coverage.
- **11-07 (95%)** — Minor table coverage.
- **12-02 (85%)** — SP_AMC_PREM_CALC missing from §12.1 index.
- **12-06 (95%)** — Minor call-direction coverage.
- **12-13 (95%)** — Minor mapping evidence.
- **13-06 (90%)** — SP_AMC_PREM_CALC not in §13.
- **14-01 (90%)** — SP_AMC_PREM_CALC not in §14.
- **19-01 (90%)** — SP_AMC_PREM_CALC not in §19.
- **20-09 (90%)** — vr_ew_certificate.rdf not in §20.3 (declarative placeholder, low severity).
- **20-11 (90%)** — vr_ew_certificate.rdf in report_filenames[] not in §20.3 (low severity).
- **21-01 (90%)** — SP_AMC_PREM_CALC not in §21.1 index.
- **D-01 (90%)** — §8.7.1 only 4 of 18 inactive triggers.
- **D-02 (90%)** — POP_PKG_DETAILS not marked inactive in §8.6.
- **E-04 (95%)** — Inactive trigger register count gap.
- **E-06 (95%)** — SP_AMC_PREM_CALC SP ID not assigned.
- **C-07 (95%)** — SP_AMC_PREM_CALC outcomes not captured.
- **G-08 (95%)** — Minor data elements.
- **G-16 (95%)** — SP_AMC_PREM_CALC process not covered.
- **G-17 (90%)** — SP_AMC_PREM_CALC not referenced in Main Flow.
- **G-18 (95%)** — Minor SP coverage.
- **G-20 (95%)** — SP_AMC_PREM_CALC outcomes not in Main Flow.
- **G-22 (90%)** — SP_AMC_PREM_CALC not documented in trigger description.
- **G-25 (95%)** — Minor data elements.
- **I-01 (90%)** — SP_AMC_PREM_CALC not in §21.
- **I-04 (95%)** — Minor traceability gaps.
- **I-05 (90%)** — §8.7.1 incomplete.

**N/A Justifications (list IDs + reason):**

- H-01, H-02, H-03 — No comparison BRD/template available for cross-BRD consistency check; will be re-evaluated when a second BRD is supplied.
- 8-53 — N/A: Editors section correctly declares "No editors found"; source has 0 editors. The hard gate passes for declared-empty.

---

## Weighted Overall Score Calculation

| Section Weight | Max Score | Actual Score | Notes |
| --- | --- | --- | --- |
| §4 Functional Requirements (35%) | 35 | 34.5 | Section avg 98.5% from Score column (36 checks) |
| §8 Technical Inventory (20%) | 20 | 19.2 | Section avg 95.9% from Score column (94 checks) |
| §21 SP Catalogue (15%) | 15 | 14.9 | Section avg 99.6% from Score column (25 checks) |
| §12 Backend / §13–§14 (10%) | 10 | 9.8 | Section avg 98.5% from Score column (29 checks) |
| §5 BRC + §6 Data Requirements (8%) | 8 | 8.0 | Section avg 99.6% from Score column (28 checks) |
| §3 System Context + §2 Exec Summary (5%) | 5 | 5.0 | Section avg 100.0% from Score column (22 checks) |
| §9–§11 + §15–§20 (7%) | 7 | 7.0 | Section avg 99.2% from Score column (53 checks) |

**Raw weighted score: 98.35%** → **Reported as 98%**. Weighted mean 98.35% → reported **98%** (no fidelity cap; hard gates 100% or cap unset).

**Verdict: PASS** (coverage=PASS; unweighted mean=98%)
---

**Recommended minimum thresholds before client delivery:**

| Gate | Threshold |
| ---- | --------- |
| Overall weighted score | above 95% |
| 3-05 (§3 Process Flow → valid §4 BR-ID) | **100%** (hard gate from `check_coverage.py`) |
| 3-07 (§3 no verbatim duplication of §2) | **100%** (hard gate from `check_coverage.py`) |
| 4-02 (§4 BR-IDs unique + sequential) | **100%** (hard gate from `check_coverage.py`) |
| 4-07 (§4 required BR fields present) | **100%** (hard gate from `check_coverage.py`) |
| 4-12 (§4 Main Flow steps sequential) | **100%** (hard gate from `check_coverage.py`) |
| 4-13 (§4 Procedures-called → valid SP) | **100%** (hard gate from `check_coverage.py`) |
| 4-32 (§4 validation table columns) | **100%** (hard gate from `check_coverage.py`) |
| 4-33 (§4 Data Elements table columns) | **100%** (hard gate from `check_coverage.py`) |
| 5-02 (§5 BRC required cells non-empty) | **100%** (hard gate from `check_coverage.py`) |
| 5-10 (§5 Business Requirement ID → §4) | **100%** (hard gate from `check_coverage.py`) |
| 5-11 (§5 BRC table columns) | **100%** (hard gate from `check_coverage.py`) |
| 5-12 (§5 Process Flow maps + BRC BR in §4) | **100%** (hard gate from `check_coverage.py`) |
| 5-14 (§5 Rule ID ↔ BR ↔ §4 evidence) | **100%** (hard gate from `check_coverage.py`) |
| 6-06 (§6 Conditional / Auto-Populated wording) | **100%** (hard gate from `check_coverage.py`) |
| 6-10 (§6.2 data capture table columns) | **100%** (hard gate from `check_coverage.py`) |
| 6-11 (§6.3 reference data table columns) | **100%** (hard gate from `check_coverage.py`) |
| 8-09 / 8-15 / 8-16 / 8-22 / 8-27 / 8-28 / 8-30 / 8-33 / 8-37 / 8-42 / 8-43 / 8-46 / 8-47 / 8-50 / 8-53 / 8-59 (§8 inventory table schemas) | **100%** (hard gate from `check_coverage.py`) — all PASS after Round 1 |
| 9-02 (§9 OLB table columns) | **100%** (hard gate from `check_coverage.py`) |
| 10-01 (§10 all source Record Groups listed) | **100%** (hard gate from `check_coverage.py`) |
| 10-03 (§10 Record Group table columns) | **100%** (hard gate from `check_coverage.py`) |
| 11-05 (§11 block/base-table columns) | **100%** (hard gate from `check_coverage.py`) |
| 11-06 (§11 database objects columns) | **100%** (hard gate from `check_coverage.py`) |
| 12-08 (§12.1 backend index columns) | **100%** (hard gate from `check_coverage.py`) |
| 12-09 (§12.1 → §12.2 catalogue coverage) | **100%** (hard gate from `check_coverage.py`) |
| 12-12 (§12.2 catalogue columns) | **100%** (hard gate from `check_coverage.py`) |
| 13-05 (§13 package-spec columns) | **100%** (hard gate from `check_coverage.py`) |
| 14-04 (§14 catalogue columns) | **100%** (hard gate from `check_coverage.py`) |
| 14-05 (§14 function-values columns) | **100%** (hard gate from `check_coverage.py`) |
| 14-07 (§14 empty section still emits table shells) | **100%** (hard gate from `check_coverage.py`) |
| 15-05 (§15 PLD call-site columns) | **100%** (hard gate from `check_coverage.py`) |
| 15-07 (§15 empty section still emits active/inactive shells) | **100%** (hard gate from `check_coverage.py`) |
| 16-05 (§16 microservice table columns) | **100%** (hard gate from `check_coverage.py`) |
| 17-05 (§17 workflow table columns) | **100%** (hard gate from `check_coverage.py`) |
| 18-04 (§18 PLD-backed logic columns) | **100%** (hard gate from `check_coverage.py`) |
| 19-05 (§19 PCK-backed logic columns) | **100%** (hard gate from `check_coverage.py`) |
| 20-03 (§20.1 DB interface columns) | **100%** (hard gate from `check_coverage.py`) |
| **20-06** (§20.2 external interface columns) | **100%** (hard gate from `check_coverage.py`) — PASS after Round 1 |
| 20-12 (§20.3 report interface columns) | **100%** (hard gate from `check_coverage.py`) |
| 21-03 (§21 SP-IDs sequential) | **100%** (hard gate from `check_coverage.py`) |
| **21-18** (§21 Input Parameters columns) | **100%** (hard gate from `check_coverage.py`) — PASS after Round 1 |
| **21-19** (§21 Output Parameters columns) | **100%** (hard gate from `check_coverage.py`) — PASS after Round 1 |
| 21-24 (§21.2 TODO placeholders removed) | **100%** (hard gate from `check_coverage.py`) |
| 21-25 (§21.2 HTML comment placeholders removed) | **100%** (hard gate from `check_coverage.py`) |

Any checkpoint below 100% must be addressed before the BRD is presented to the client.

**Scoring Guide — machine hard gates:** All `_coverage.json` `hard_scores` now pass at 100% after Round 1 correction: 8-50=100%, 20-06=100%, 21-18=100%, 21-19=100%. Coverage verdict PASS. Overall fidelity cap = None (no gating failures active).

**Weighted Overall Score:** Computed by `compute_tr_score.py --patch` after Round 1.


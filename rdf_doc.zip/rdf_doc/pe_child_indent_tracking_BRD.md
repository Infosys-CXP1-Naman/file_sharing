# BUSINESS REQUIREMENTS DOCUMENT

## Table of Contents

- 1. Document Control
  - 1.1 Document Information
  - 1.2 Revision History
- 2. Executive Summary
  - Key Stakeholders
- 3. System Context
- 4. Functional Requirements
  - 4.1 Business Requirements
    - Requirement ID: BR-001
    - Requirement ID: BR-002
    - Requirement ID: BR-003
    - Requirement ID: BR-004
    - Requirement ID: BR-005
    - Requirement ID: BR-006
    - Requirement ID: BR-007
    - Requirement ID: BR-008
    - Requirement ID: BR-009
    - Requirement ID: BR-010
    - Business Scenarios - How filter layout differs by report type and user type
    - Requirement ID: BR-011
    - Requirement ID: BR-012
    - Business Scenarios - How the report export differs by report type and user type
    - Requirement ID: BR-013
    - Requirement ID: BR-014
    - Requirement ID: BR-015
    - Requirement ID: BR-016
- 5. Business Rules Catalogue
- 6. Data Requirements
  - 6.1 Business Entities and Relationships
    - Child Indent Tracking Records - PT_IDT_TRACKING
    - Interim Report Data Store - PT_IDT_REP_INTER
    - Dealer Location Master - AM_DEALER_LOC
    - Consignee Master - AM_CONSIGNEE
    - Entity Relationships
  - 6.2 Data Capture Requirements
    - Report Filter Criteria (User - before generating the child indent tracking report)
    - Session and Control Parameters (System - applied at initialisation)
  - 6.3 Reference Data
  - 6.4 Data Lifecycle
  - 6.5 Excel Output Columns
- 7. Glossary
- 8. Technical Inventory
  - 8.1 Form Architecture
    - 8.1.1 Global Variables
    - 8.1.2 Form Parameters
  - 8.2 Blocks
    - 8.2.1 Block WhereClause and OrderByClause
  - 8.3 Items Summary
  - 8.4 List of Values
  - 8.5 Alerts
  - 8.6 Program Units
  - 8.7 Triggers
    - 8.7.1 Inactive / Commented-Out Trigger Register
  - 8.8 Canvas and Window Inventory
  - 8.9 Editors
  - 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups
    - 8.10.1 Visual Attributes (form-defined)
    - 8.10.2 Property Classes (form-defined)
    - 8.10.3 Object Groups
  - 8.11 DataSourceColumn Inventory
- 9. Object Library
- 10. Record Groups
- 11. Referenced Database Objects
- 12. Backend Procedures and Packages
  - 12.1 Main Flow Backend Procedure/Package Index
  - 12.2 Procedure and Package Catalogue
    - GENERAL.ASK_CONFIRM
    - GENERAL.CHECK_NULL
    - GENERAL.DISP_TEXT
    - GENERAL.RAISE_ERROR
    - SF_COPYRIGHT_DECLARATION
    - VIEW_EXCEL_REP
    - DBMS_APPLICATION_INFO.SET_CLIENT_INFO
    - DBMS_APPLICATION_INFO.SET_MODULE
    - WEB.SHOW_DOCUMENT
    - WEBUTIL.ERRORALERT
    - WEBUTIL.FCLOSE
    - WEBUTIL.FOPEN
    - WEBUTIL.GETIMPLCLASS
    - WEBUTIL.GETPROPERTY
    - WEBUTIL.GET_LINE
    - WEBUTIL.ID_NULL
    - WEBUTIL.PUT_LINE
    - WEBUTIL.SETPROPERTY
- 13. Package Procedure Specifications
- 14. Database Package Catalogue
- 15. PLD Procedure Call Sites
  - DPL.pld (`general`)
  - Inactive / commented-only PLD call sites
  - webutil.pld (`WEBUTIL_C_API`)
  - webutil.pld (`WEBUTIL_FILE`)
  - Inactive / commented-only PLD call sites
  - webutil.pld (`WEBUTIL_FILE_TRANSFER`)
  - Inactive / commented-only PLD call sites
  - webutil.pld (`WEBUTIL_HOST`)
  - Inactive / commented-only PLD call sites
- 16. Microservice API Candidates
  - 16.1 Microservices with APIs
- 17. Workflows
- 18. PLD-Backed Logic
  - webutil.pld (`CLIENT_IMAGE`)
  - DPL.pld (`general`)
  - D2kwutil.pld (`Win_API`)
- 19. PCK-Backed Logic
- 20. System Interfaces
  - 20.1 Database Integrations
  - 20.2 External System Integrations
  - 20.3 Report Integrations
    - 20.3.1 Parameters Passed to the Report
- 21. Procedure and Function Business Rule Catalogue
  - 21.1 Catalogue Index
  - 21.2 Detailed Specifications
    - SP-001 - VIEW_EXCEL_REP
    - SP-002 - GENERAL.ASK_CONFIRM
    - SP-003 - GENERAL.CHECK_NULL
    - SP-004 - GENERAL.DISP_TEXT
    - SP-005 - GENERAL.RAISE_ERROR
    - SP-006 - WEBUTIL.ERRORALERT
    - SP-007 - WEBUTIL.FCLOSE
    - SP-008 - WEBUTIL.FOPEN
    - SP-009 - WEBUTIL.GETIMPLCLASS
    - SP-010 - WEBUTIL.GETPROPERTY
    - SP-011 - WEBUTIL.GET_LINE
    - SP-012 - WEBUTIL.ID_NULL
    - SP-013 - WEBUTIL.PUT_LINE
    - SP-014 - WEBUTIL.SETPROPERTY
    - SP-015 - SF_COPYRIGHT_DECLARATION

## 1. Document Control

### 1.1 Document Information

| Field | Value |
| ----- | ----- |
| Document Title | PE_CHILD_INDENT_TRACKING - Business Requirements Document |
| Form Module Name | PE_CHILD_INDENT_TRACKING |
| Document Version | 1.0 |
| Date Created | August 13, 2026 |
| Author/Prepared By | BRD Agent |

### 1.2 Revision History

| Version | Date | Author | Description |
| --- | --- | --- | --- |
| 1.0 | August 13, 2026 | BRD Agent | Initial draft |

---

## 2. Executive Summary

*High-level overview of the pe_child_indent_tracking Child Indent Tracking form, its purpose, and roles referenced in the module.*

The **pe_child_indent_tracking** Oracle Forms module is the **Child Indent Tracking** reporting screen within the Dealer Management System. A user opens the screen, selects a consignee and location from the available lists, specifies a date range of up to 30 days, chooses a report type (detail or summary), and optionally filters by part category and indent nature. Once all required criteria are provided, the user clicks the Generate Report button. The screen validates every filter, assembles the indent tracking data for the selected criteria, and delivers a downloadable CSV file opened directly in the browser. For non-stockyard users the data is temporarily staged in an intermediate table before export. The form is a reporting-only module - no records are created or updated through its interface.

### Key Stakeholders

*Who uses pe_child_indent_tracking*

| Stakeholder | Role |
| :--- | :--- |
| **Dealer / Branch User** | Primary interactive user of the screen. Selects criteria (consignee, location, date range, report type) and generates the CSV indent tracking report for their assigned location. |
| **Spares Stockyard User** | Interactive user in stockyard mode. The consignee and location fields are defaulted to ALL; the seller location field becomes the active filter for the header report type. |
| **Principal / Head-Office User** | Inactive - derived only from reserved parameters (P_USER_TYPE, P_USER_HORO, P_REGION) referenced exclusively in commented-out program unit code; not an active form user in the current implementation. |

---

---

## 3. System Context

*Describes the pe_child_indent_tracking module's role within the DMS ecosystem, scope, process flow, and key integrations.*

The **pe_child_indent_tracking** module is the **Child Indent Tracking** reporting screen in the Dealer Management System. It enables dealer and stockyard users to extract indent tracking data for a specified consignee, location, and date range and receive the results as a downloadable CSV file. The screen connects the DMS to dealer location master data for filter population and to the indent tracking data store for report generation.

**System purpose:** Allow authorised dealer and stockyard users to define report criteria, validate the selection, stage the filtered indent tracking data, and export a CSV report covering detail or summary indent activity across buyer and seller locations for up to 30 days - as implemented in the pe_child_indent_tracking Oracle Forms module.

**In scope:**

- Display and initialise report criteria fields based on the logged-in user's location type (standard dealer or spares stockyard)
- Populate consignee selection list filtered to the user's dealer parent group
- Populate buyer location and seller location selection lists from dealer location master data
- Validate that all mandatory report criteria (consignee, location, from date, to date, report type) are entered before report generation
- Enforce date range rules: from date must not be in the future or more than 180 days back; to date must not exceed from date plus 30 days
- Enable or disable location and seller location fields based on report type and stockyard mode
- Build a dynamic SQL query for detail (line-level) or header (summary) report type
- Stage filtered indent tracking records into an intermediate table for non-stockyard users before export
- Generate and deliver a CSV file of child indent tracking data opened in the browser
- Display a copyright declaration on the report screen

**Process Name:** Child Indent Tracking Report Generation

**Process Owner:** Spares / Parts Operations Manager

**Process Objective:** Open the report screen, validate dealer location context and user-supplied date and filter criteria, assemble the filtered indent tracking dataset, and deliver the result as a downloadable CSV file.

**Process Trigger:** A dealer user or stockyard operator opens the Child Indent Tracking form to obtain an indent tracking report for a specific consignee and location over a chosen date range.

**Process Flow:**

The complete child indent tracking report generation process follows this sequence. Each step corresponds to Functional Requirements in Section 4.

```
STEP 1 ── FORM OPENS AND SESSION IS REGISTERED
         The form is launched. The session module name is registered with the database
         for auditing purposes. The report criteria screen is presented to the user.

STEP 2 ── BLOCK INITIALISES - DEALER LOCATION CONTEXT LOADED
         The system queries the dealer location master for the logged-in user's
         parent group, dealer code, location, and principal to determine
         whether the location is a spares stockyard.

STEP 3 ── CRITERIA PRE-POPULATED BASED ON LOCATION TYPE
         ├── STANDARD DEALER: Consignee and location fields are pre-filled with the
         │                    user's own dealer and location; both fields are locked.
         │                    Navigation starts at the Generate Report button.
         └── SPARES STOCKYARD: Consignee and location are defaulted to ALL.
                               The user may change the consignee selection.
                               Navigation starts at the Consignee field.

STEP 4 ── DEFAULT DATE RANGE SET
         From Date defaults to today minus 30 days.
         To Date defaults to today.

STEP 5 ── COPYRIGHT DECLARATION DISPLAYED
         The copyright declaration text is loaded and displayed on screen.

STEP 6 ── CONSIGNEE SELECTION (stockyard users only)
         The user selects or retains the consignee from the lookup list.
         The list shows active consignees for the user's dealer parent group.
         Validation ensures consignee is not left blank.

STEP 7 ── LOCATION NAVIGATION (stockyard users only)
         ├── CONSIGNEE = ALL: Navigation skips directly to the From Date field.
         └── SPECIFIC CONSIGNEE: The location field is enabled; navigation moves
                                  to the Location field.

STEP 8 ── LOCATION SELECTION (stockyard users only)
         The user selects a buyer location from the lookup list.
         The list shows locations for the user's parent group.
         Validation ensures location is not left blank.

STEP 9 ── FROM DATE ENTRY AND VALIDATION
         The user enters or confirms the from date.
         Rules enforced: date must not be null; date must not be in the future;
         date must not be more than 180 days in the past.
         If From Date equals today minus 180 days, To Date is auto-set to From Date plus 180 days.

STEP 10 ── TO DATE ENTRY AND VALIDATION
          The user enters or confirms the to date.
          Rules enforced: date must not be null; date must not be in the future;
          date must not be earlier than From Date; date range must not exceed 30 days.
          If the range exceeds 30 days, To Date is cleared and the user must re-enter.

STEP 11 ── REPORT TYPE SELECTION
          The user selects the report type: Detail (line-level) or Header (summary).
          Validation ensures report type is not left blank.

STEP 12 ── LOCATION FIELD VISIBILITY ADJUSTED BY REPORT TYPE AND STOCKYARD MODE
          ├── STOCKYARD + HEADER REPORT: Buyer location field is disabled;
          │                              Seller location field is enabled.
          ├── STOCKYARD + DETAIL REPORT: Buyer location field is enabled;
          │                              Seller location field is disabled (set to ALL).
          └── NON-STOCKYARD: Seller location field is disabled (set to ALL) for all types.

STEP 13 ── SELLER LOCATION SELECTION (stockyard + header report only)
          The user selects the seller location from the lookup list.
          Validation ensures location is not blank.

STEP 14 ── PART CATEGORY FILTER (optional)
          The user selects a part category filter (ALL, M, AA).
          Validation ensures report type has been selected before leaving this field.

STEP 15 ── INDENT NATURE FILTER (optional)
          The user selects an indent nature filter (ALL, Manual, MARS-Ed, MARS-NonEd).
          Validation ensures report type has been selected before leaving this field.

STEP 16 ── GENERATE REPORT BUTTON - PRE-CONDITIONS CHECKED
          The user clicks the Generate Report button.
          System re-validates: consignee and location must not be null;
          From Date must not be more than 180 days back; date range must not exceed 30 days.
          Any failed check displays an error and returns focus to the offending field.

STEP 17 ── REPORT FILENAME GENERATED
          A unique CSV filename is assembled from the user ID and current timestamp.

STEP 18 ── DATA STAGING - NON-STOCKYARD USERS (DETAIL REPORT TYPE)
          ├── NON-STOCKYARD + DETAIL: Existing staging records for the user are deleted.
          │                           Filtered indent tracking rows are inserted into the
          │                           intermediate staging table keyed by user ID.
          └── STOCKYARD or HEADER REPORT: Staging step is skipped; data is queried directly.

STEP 19 ── DYNAMIC SQL QUERY BUILT
          A dynamic SQL query is constructed based on the report type:
          ├── DETAIL: Selects line-level indent tracking columns (indent number, part,
          │           quantities, issue, receipt, batch details) filtered by consignee,
          │           location, date range, part category, and indent nature.
          └── HEADER: Selects summarised values (order value, cancel value, net issue
                      value) grouped by consignee, location, and indent nature,
                      joined to dealer location for stockyard flag filtering.

STEP 20 ── CSV FILE CREATED AND WRITTEN TO SERVER
          The dynamic query is executed to populate a record group.
          Each row is written as a comma-separated line to a server-side CSV file.
          Output is capped at 65,535 rows.

STEP 21 ── CSV FILE OPENED IN BROWSER
          The server-side CSV file URL is constructed from the configured export path.
          The file is opened in a new browser window for the user to download.

STEP 22 ── CLEAR FORM (optional)
          The user may reset the criteria fields using the Clear Form action,
          which blanks consignee, location, and date fields for a new report run.
```

**Major process interactions:**

- **Dealer location master (AM_DEALER_LOC / MULDMS.AM_DEALER_LOC)** - provides location details, stockyard flag, and principal mapping used at form initialisation and in location LOV queries
- **Consignee master (AM_CONSIGNEE)** - supplies the list of active consignees for the buyer selection LOV
- **Indent tracking data store (PT_IDT_TRACKING / PT_IDT_REP_INTER)** - source of indent tracking records filtered and exported; PT_IDT_REP_INTER is the staging table for non-stockyard detail reports
- **Server file system and configured export path** - CSV output is written to a configured server directory and served to the browser via a URL read from /reports/DMS/excelpath.txt
- **Session auditing (DBMS_APPLICATION_INFO)** - records the active form module name in the Oracle session for traceability

---

---

## 4. Functional Requirements

### 4.1 Business Requirements

#### Requirement ID: BR-001

**Requirement Title:** Form Session Registration

**Business Description:**
When the Child Indent Tracking form is opened, the system automatically registers the current form session with the database for monitoring and diagnostic purposes. This registration ensures that support and operations teams can identify which users are running the form at any given time by inspecting active database sessions.

**Actors:** System (automatic, no user action required)

**Preconditions:**
- The user has launched the Child Indent Tracking form.

**Main Flow:**

**Step 1 - Session client information registered**
Before the form displays to the user, the system records the current application's name in the database session's client information slot, making the form identifiable in session monitoring tools.

**Step 2 - Session module information registered**
Immediately after, the system also records the application name in the database session's module name slot, and sets the action label to an empty value. Both registrations are applied unconditionally each time the form opens.

**Alternative Flows:**
None evidenced.

---

---

#### Requirement ID: BR-002

**Requirement Title:** Report Filter Screen Initialisation

**Business Description:**
When the Child Indent Tracking report filter screen opens, the system automatically determines the type of dealer location the user is logged in from and pre-populates the filter fields accordingly. For spares stockyard users, the consignee and location filters are set to "all" values and left available for the user to change, while the cursor is placed on the Consignee field. For standard dealership users, the consignee and location filters are pre-filled with the session's assigned consignee and location, both fields are locked, and the cursor is placed directly on the Generate Report button. Date defaults are applied for both user types. The copyright declaration text is also loaded at this point.

**Actors:** System (automatic, no user action required)

**Preconditions:**
- The user has opened the Child Indent Tracking form and the report filter screen is loading for the first time.

**Main Flow:**

**Step 1 - Dealer location record queried to determine session context**
The system looks up the session's dealer location from the dealer location master, using the current user's parent group, dealer map code, location code, and principal. It retrieves the spares stockyard flag, consignee code, dealer name, and location description for the matched record. If no matching record is found or any other error occurs, the lookup is silently ignored and the system proceeds with no defaults from this query.

**Step 2 - Filter fields pre-populated based on dealer location type**
If the session belongs to a spares stockyard location, the system pre-fills the Consignee field with "ALL", the Dealer Name display with "ALL CONSIGNEES", the Location field with "ALL", and the Location Description display with "ALL LOCATIONS". If the current report type selection is already Summary, the Location field is additionally disabled. The cursor is then moved to the Consignee field for the user to begin.

If the session belongs to a standard (non-spares-stockyard) location, the system pre-fills the Consignee field with the consignee code retrieved from the dealer location record, the Dealer Name display with the retrieved dealer name, the Location field with the session's location code, the Location Description display with the retrieved location description, and the Dealer Map Code with the session's dealer map code. Both the Consignee and Location fields are disabled so the user cannot change them. The cursor is then moved directly to the Generate Report button.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Spares stockyard status check | WHEN-NEW-BLOCK-INSTANCE on CB_BLK - SELECT on AM_DEALER_LOC for spares_stockyard_yn flag | When the report filter screen loads at the start of the user's session | Determines which set of filter defaults and field lock rules apply to this user, ensuring stockyard users see all-consignee/location options while standard users are automatically scoped to their assigned location | Exception: if the query fails for any reason, no defaults are applied and the screen loads with empty fields; the user must enter all filter values manually |

**Step 3 - Seller Location, date defaults, and copyright text applied**
Regardless of the dealer location type, the system then pre-sets the Seller Location field to "ALL" and the Seller Location Description to "ALL Locations". The From Date is set to 30 days before today's date, and the To Date is set to today's date. Finally, the copyright declaration function is called and its return value is stored in the copyright declaration field.

*Procedures called:*
- **SF_COPYRIGHT_DECLARATION** ([SP-014](#SP-014--SF_COPYRIGHT_DECLARATION)) - SF_COPYRIGHT_DECLARATION - returns the standard copyright declaration text that is stored in the copyright declaration field on the form.
    * **Step 1** - Retrieve the copyright declaration text from the database.
    * **Step 2** - Return the copyright text to the calling form for display.

**Alternative Flows:**
- **BR-002-AF-01** - (from Step 1) If the dealer location query fails for any reason (no matching record or any other exception), the initialisation step is silently skipped; no consignee, dealer name, location, or location description defaults are loaded, and the screen opens with those fields empty for the user to complete manually.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Consignee (`CONSG_CD`) | Conditional - Auto-populated for spares stockyard users to "ALL"; auto-populated for standard users from session dealer location; user-selectable only for spares stockyard users | Text | N/A | Consignee lookup (LOV_CONSG / RG_CONSG from AM_CONSIGNEE and AM_DEALER_LOC) | Consignee code | Session globals (parent_group, dealer, principal) | Pre-filled at initialisation; field is disabled for non-stockyard users | N/A at initialisation - validated as mandatory at field exit (BR-003) |
| Dealer Name (`DEALER_NAME`) | Auto-populated | Display | 70 characters | LOV_CONSG (returns DEALER_NAME) | Dealer name | Consignee populated | Read-only; populated alongside consignee at initialisation | N/A |
| Location (`LOC_CD`) | Conditional - Auto-populated to "ALL" for stockyard users; auto-populated from session for non-stockyard users; disabled for both unless stockyard Detail report | Text | N/A | Location lookup (LOV_LOC / RG_LOC from AM_DEALER_LOC) | Location code | Consignee populated | Pre-filled at initialisation; disabled for non-stockyard users | N/A at initialisation - validated as mandatory at field exit (BR-004) |
| Location Description (`LOC_DESC`) | Auto-populated | Display | 70 characters | LOV_LOC (returns LOC_DESC) | Location description | Location populated | Read-only; populated alongside location at initialisation | N/A |
| Seller Location (`SO_LOC_CD`) | Auto-populated (defaulted to "ALL") | Text | N/A | Seller Location lookup (LOV_SO_LOC / RG_SO_LOC from AM_DEALER_LOC) | Location code | N/A | Defaulted to "ALL" at initialisation; enabled/disabled based on report type and user type | N/A |
| Seller Location Description (`SO_LOC_DESC`) | Auto-populated | Display | 70 characters | LOV_SO_LOC (returns LOC_DESC) | Location description | Seller Location populated | Read-only; set to "ALL Locations" at initialisation | N/A |
| From Date (`FROM_DATE`) | Auto-populated (defaulted to 30 days before today) | Date | DD-MM-RRRR | N/A | N/A | N/A | Defaulted to sysdate minus 30 at initialisation | N/A |
| To Date (`TO_DATE`) | Auto-populated (defaulted to today's date) | Date | DD-MM-RRRR | N/A | N/A | N/A | Defaulted to sysdate at initialisation | N/A |
| Copyright Declaration (`COPYRIGHT_DECLARATION`) | Auto-populated | Text | 100 characters | N/A | Copyright text returned by SF_COPYRIGHT_DECLARATION | N/A | Read-only; populated at initialisation from copyright declaration function | N/A |

---

---

#### Requirement ID: BR-003

**Requirement Title:** Consignee Field Mandatory Validation

**Business Description:**
When the user leaves the Consignee field, the system checks that a consignee has been entered. If the field is blank, the user is prevented from moving to the next field and an error is shown. This ensures that every report generation attempt is tied to a specific consignee or the "all consignees" selection, preventing incomplete or unscoped report criteria.

**Actors:** Spares stockyard user (who can change the Consignee field)

**Preconditions:**

---

#### Requirement ID: BR-004

**Requirement Title:** Location Field Mandatory Validation

**Business Description:**
When the user leaves the Location field, the system checks that a location has been entered. If the field is blank, the user is prevented from moving to the next field and an error is shown. This ensures that report criteria always include a location scope, preventing an incomplete report request.

**Actors:** Spares stockyard user (who can change the Location field in Detail report mode)

**Preconditions:**
- The report filter screen has been initialised.
- The user has navigated to the Location field and is attempting to leave it.

**Main Flow:**

**Step 1 - Location blank check performed on field exit**
When the user attempts to leave the Location field, the system checks whether a location value has been entered. If the field is blank, the mandatory field check is raised, showing an error and preventing the cursor from leaving the field.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-002](#SP-002--GENERAL.CHECK_NULL)) - GENERAL.CHECK_NULL - checks whether the Location field is blank; if blank, displays the mandatory field error for the Location label and raises a form trigger failure to keep the cursor on the field.
    * **Step 1** - Check whether the supplied Location field value is blank.
    * **Step 2** - If blank, display a message indicating that the Location field must be completed and prevent the user from leaving the field.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Location is not blank | Mandatory field check - GENERAL.CHECK_NULL [SP-002] on CB_BLK.LOC_CD | When the user leaves the Location field | Ensures the report cannot proceed without a location selection | Error displayed; cursor remains on the Location field |

**Alternative Flows:**
None evidenced.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Location (`LOC_CD`) | Mandatory | Text | N/A | Location lookup (LOV_LOC / RG_LOC from AM_DEALER_LOC) | Location code | Consignee selected | Must not be blank | Mandatory field error displayed; cursor remains on field |

---

- The report filter screen has been initialised.
- The user has navigated to the Consignee field and is attempting to leave it.

**Main Flow:**

**Step 1 - Consignee blank check performed on field exit**
When the user attempts to leave the Consignee field, the system checks whether a consignee value has been entered. If the field is blank, the mandatory field check is raised, showing an error and preventing the cursor from leaving the field.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-002](#SP-002--GENERAL.CHECK_NULL)) - GENERAL.CHECK_NULL - checks whether the Consignee field is blank; if blank, displays the mandatory field error for the Consignee label and raises a form trigger failure to keep the cursor on the field.
    * **Step 1** - Check whether the supplied Consignee field value is blank.
    * **Step 2** - If blank, display a message indicating that the Consignee field must be completed and prevent the user from leaving the field.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Consignee is not blank | Mandatory field check - GENERAL.CHECK_NULL [SP-002] on CB_BLK.CONSG_CD | When the user leaves the Consignee field | Ensures the report cannot proceed without a consignee selection | Error displayed; cursor remains on the Consignee field |

**Alternative Flows:**
None evidenced.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Consignee (`CONSG_CD`) | Mandatory | Text | N/A | Consignee lookup (LOV_CONSG / RG_CONSG) | Consignee code | Report filter screen initialised | Must not be blank | Mandatory field error displayed; cursor remains on field |

---

---

#### Requirement ID: BR-005

**Requirement Title:** From Date Validation

**Business Description:**
When the user leaves the From Date field, the system validates that a start date has been entered, that the date entered is not in the future, and enforces a boundary condition for the maximum lookback period. If the date is exactly at the 180-day lookback boundary, the system automatically adjusts the To Date to match. These checks ensure the report date range is meaningful and within operational data retention limits.

**Actors:** User (spares stockyard or standard dealership user)

**Preconditions:**
- The report filter screen has been initialised.
- The user has entered or changed the From Date field and is attempting to leave it.

**Main Flow:**

**Step 1 - From Date blank check performed on field exit**
When the user attempts to leave the From Date field, the system first checks whether a date has been entered. If the field is blank, the mandatory field check is raised, showing an error and preventing the cursor from leaving the field.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-002](#SP-002--GENERAL.CHECK_NULL)) - GENERAL.CHECK_NULL - checks whether the From Date field is blank; if blank, displays the mandatory field error for the From Date label and raises a form trigger failure.
    * **Step 1** - Check whether the supplied From Date field value is blank.
    * **Step 2** - If blank, display a message indicating that the From Date field must be completed and prevent the user from leaving the field.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| From Date is not blank | Mandatory field check - GENERAL.CHECK_NULL [SP-002] on CB_BLK.FROM_DATE | When the user leaves the From Date field | Ensures the report date range has a valid start date | Mandatory field error displayed; cursor remains on From Date |

**Step 2 - From Date checked against today's date**
If the From Date has a value, the system checks whether it is later than today's date. If so, the system displays an error message and prevents the user from leaving the field.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-003](#SP-003--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the error message *"From Date cannot be greater than current date"* and raises a form trigger failure.
    * **Step 1** - Receive the message text and severity indicator.
    * **Step 2** - Display the message to the user and raise a form trigger failure.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| From Date is not a future date | Future date check - WHEN-VALIDATE-ITEM on CB_BLK.FROM_DATE; GENERAL.DISP_TEXT [SP-003] on failure | When the user leaves the From Date field after entering a value | Prevents the user from requesting data for dates that have not yet occurred | *"From Date cannot be greater than current date"* displayed; cursor remains on From Date |

**Step 3 - 180-day boundary auto-adjustment applied**
If the From Date is exactly 180 days before today's date, the system automatically sets the To Date to be From Date plus 180 days. This auto-adjustment only triggers when the date equals precisely the 180-day boundary value.

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-ES-01** - From Date is a future date - *"From Date cannot be greater than current date"*; cursor remains on the From Date field.

**Alternative Flows:**
None evidenced.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| From Date (`FROM_DATE`) | Mandatory | Date | DD-MM-RRRR | N/A | N/A | Report filter screen initialised | Must not be blank; must not be a future date | Mandatory field error or *"From Date cannot be greater than current date"* displayed; cursor remains on field |
| To Date (`TO_DATE`) | Conditional - Auto-adjusted when From Date equals exactly 180 days before today | Date | DD-MM-RRRR | N/A | N/A | From Date entered | Auto-set to From Date plus 180 days only at the exact 180-day boundary condition | N/A |

---

---

#### Requirement ID: BR-006

**Requirement Title:** To Date Validation

**Business Description:**
When the user leaves the To Date field, the system validates that an end date has been entered, that it is not in the future, that it is not earlier than the From Date, and that the date range between From Date and To Date does not exceed 30 days. Violations of the last rule clear the To Date and return focus to it. These checks together ensure the report covers a valid, appropriately bounded date range.

**Actors:** User (spares stockyard or standard dealership user)

**Preconditions:**
- The report filter screen has been initialised.
- A valid From Date has already been entered.
- The user has entered or changed the To Date field and is attempting to leave it.

**Main Flow:**

**Step 1 - To Date blank check performed on field exit**
When the user attempts to leave the To Date field, the system first checks whether a date has been entered. If the field is blank, the mandatory field check is raised, showing an error and preventing the cursor from leaving the field.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-002](#SP-002--GENERAL.CHECK_NULL)) - GENERAL.CHECK_NULL - checks whether the To Date field is blank; if blank, displays the mandatory field error for the To Date label and raises a form trigger failure.
    * **Step 1** - Check whether the supplied To Date field value is blank.
    * **Step 2** - If blank, display a message indicating that the To Date field must be completed and prevent the user from leaving the field.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| To Date is not blank | Mandatory field check - GENERAL.CHECK_NULL [SP-002] on CB_BLK.TO_DATE | When the user leaves the To Date field | Ensures the report date range has a valid end date | Mandatory field error displayed; cursor remains on To Date |

**Step 2 - To Date checked against today's date**
If the To Date has a value, the system checks whether it is later than today's date. If so, the system displays an error message and prevents the user from leaving the field.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-003](#SP-003--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the error message *"To Date cannot be greater than current date"* and raises a form trigger failure.
    * **Step 1** - Receive the message text and severity indicator.
    * **Step 2** - Display the message to the user and raise a form trigger failure.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| To Date is not a future date | Future date check - WHEN-VALIDATE-ITEM on CB_BLK.TO_DATE; GENERAL.DISP_TEXT [SP-003] on failure | When the user leaves the To Date field after entering a value | Prevents the user from requesting data for dates that have not yet occurred | *"To Date cannot be greater than current date"* displayed; cursor remains on To Date |

**Step 3 - To Date checked against From Date**
The system checks whether the To Date is earlier than the From Date. If so, the system displays an error message and prevents the user from leaving the field.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-003](#SP-003--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the error message *"To Date cannot be older than From Date"* and raises a form trigger failure.
    * **Step 1** - Receive the message text and severity indicator.
    * **Step 2** - Display the message to the user and raise a form trigger failure.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| To Date is not earlier than From Date | Date sequence check - WHEN-VALIDATE-ITEM on CB_BLK.TO_DATE; GENERAL.DISP_TEXT [SP-003] on failure | When the user leaves the To Date field after entering a value | Ensures the date range is logically valid (end must be on or after start) | *"To Date cannot be older than From Date"* displayed; cursor remains on To Date |

**Step 4 - Date range checked against the 30-day maximum**
The system checks whether the difference between To Date and From Date is greater than 30 days. If so, the system displays an error message, clears the To Date field to null, and returns focus to the To Date field for the user to re-enter a valid date.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-003](#SP-003--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the error message *"Date range cannot be greater than 30 days!"* when the range is exceeded.
    * **Step 1** - Receive the message text and severity indicator.
    * **Step 2** - Display the message to the user and raise a form trigger failure.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Date range does not exceed 30 days | 30-day range check - WHEN-VALIDATE-ITEM on CB_BLK.TO_DATE; GENERAL.DISP_TEXT [SP-003] on failure | When the user leaves the To Date field after entering a value | Limits the volume of data in a single report run to protect system performance | *"Date range cannot be greater than 30 days!"* displayed; To Date cleared; cursor returns to To Date |

*Business outcomes (errors, warnings, success, and status):*
- **BR-006-ES-01** - To Date is a future date - *"To Date cannot be greater than current date"*; cursor remains on the To Date field.
- **BR-006-ES-02** - To Date is earlier than From Date - *"To Date cannot be older than From Date"*; cursor remains on the To Date field.
- **BR-006-ES-03** - Date range exceeds 30 days - *"Date range cannot be greater than 30 days!"*; To Date is cleared and cursor returns to To Date.

**Alternative Flows:**
None evidenced.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| To Date (`TO_DATE`) | Mandatory | Date | DD-MM-RRRR | N/A | N/A | From Date entered | Must not be blank; must not be a future date; must not be earlier than From Date; range from From Date must not exceed 30 days | Error messages shown per rule violated; To Date cleared on 30-day range breach |
| From Date (`FROM_DATE`) | Read-only reference | Date | DD-MM-RRRR | N/A | N/A | From Date entered | Referenced to validate date sequence and range | N/A |

---

---

#### Requirement ID: BR-007

**Requirement Title:** Report Type Field Mandatory Validation

**Business Description:**
When the user leaves the Report Type field, the system checks that a report type has been selected. If the field is blank, the user is prevented from moving to the next field and an error is shown. This ensures the user has explicitly chosen either a Detail or Summary report format before continuing.

**Actors:** User (spares stockyard or standard dealership user)

**Preconditions:**
- The report filter screen has been initialised.
- The user has navigated to the Report Type field and is attempting to leave it.

**Main Flow:**

**Step 1 - Report Type blank check performed on field exit**
When the user attempts to leave the Report Type field, the system checks whether a report type has been selected. If the field is blank, the mandatory field check is raised, showing an error and preventing the cursor from leaving the field.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-002](#SP-002--GENERAL.CHECK_NULL)) - GENERAL.CHECK_NULL - checks whether the Report Type field is blank; if blank, displays the mandatory field error for the Report Type label and raises a form trigger failure.
    * **Step 1** - Check whether the supplied Report Type field value is blank.
    * **Step 2** - If blank, display a message indicating that the Report Type field must be completed and prevent the user from leaving the field.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Report Type is not blank | Mandatory field check - GENERAL.CHECK_NULL [SP-002] on CB_BLK.REPORT_TYPE | When the user leaves the Report Type field | Ensures the user explicitly selects a report format before generating the export | Error displayed; cursor remains on the Report Type field |

**Alternative Flows:**
None evidenced.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Report Type (`REPORT_TYPE`) | Mandatory | List | N/A | N/A | Detail (D) / Summary (H) | Report filter screen initialised | Must not be blank | Mandatory field error displayed; cursor remains on field |

---

---

#### Requirement ID: BR-008

**Requirement Title:** Part Category Field - Report Type Prerequisite Validation

**Business Description:**
When the user leaves the Part Category field, the system checks that a report type has already been selected. If the Report Type is blank at this point, the user is presented with a mandatory field error for the Report Type. This acts as a guard to ensure the report type is always established before the user advances past the Part Category filter.

**Actors:** User (spares stockyard or standard dealership user)

**Preconditions:**
- The report filter screen has been initialised.
- The user has navigated to the Part Category field and is attempting to leave it.

**Main Flow:**

**Step 1 - Report Type prerequisite check performed when leaving Part Category**
When the user attempts to leave the Part Category field, the system checks whether the Report Type field is blank. If Report Type is blank, the mandatory field check for Report Type is raised, showing an error and preventing the user from proceeding.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-002](#SP-002--GENERAL.CHECK_NULL)) - GENERAL.CHECK_NULL - checks whether the Report Type field is blank; if blank, displays the mandatory field error for the Report Type label and raises a form trigger failure.
    * **Step 1** - Check whether the Report Type field value is blank.
    * **Step 2** - If blank, display a message indicating that the Report Type field must be completed and prevent the user from leaving the field.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Report Type is populated before Part Category is accepted | Prerequisite check - GENERAL.CHECK_NULL [SP-002] on CB_BLK.CATG checking CB_BLK.REPORT_TYPE | When the user leaves the Part Category field | Ensures that a report type is selected before the user advances past the Part Category filter | Error for Report Type displayed; user must return to Report Type and complete it |

**Alternative Flows:**
None evidenced.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Part Category (`CATG`) | Mandatory | List | N/A | N/A | All / part category values | Report Type selected | Report Type must be populated when this field is exited | Mandatory field error for Report Type displayed |
| Report Type (`REPORT_TYPE`) | Mandatory | List | N/A | N/A | Detail (D) / Summary (H) | N/A | Must not be blank at time of Part Category exit | Mandatory field error for Report Type displayed; cursor blocked |

---

---

#### Requirement ID: BR-009

**Requirement Title:** Indent Nature Field - Report Type Prerequisite Validation

**Business Description:**
When the user leaves the Indent Nature field, the system checks that a report type has already been selected. If the Report Type is blank at this point, the user is presented with a mandatory field error for the Report Type. This ensures the report type is always established before the user moves past the Indent Nature filter.

**Actors:** User (spares stockyard or standard dealership user)

**Preconditions:**
- The report filter screen has been initialised.
- The user has navigated to the Indent Nature field and is attempting to leave it.

**Main Flow:**

**Step 1 - Report Type prerequisite check performed when leaving Indent Nature**
When the user attempts to leave the Indent Nature field, the system checks whether the Report Type field is blank. If Report Type is blank, the mandatory field check for Report Type is raised, showing an error and preventing the user from proceeding.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-002](#SP-002--GENERAL.CHECK_NULL)) - GENERAL.CHECK_NULL - checks whether the Report Type field is blank; if blank, displays the mandatory field error for the Report Type label and raises a form trigger failure.
    * **Step 1** - Check whether the Report Type field value is blank.
    * **Step 2** - If blank, display a message indicating that the Report Type field must be completed and prevent the user from leaving the field.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Report Type is populated before Indent Nature is accepted | Prerequisite check - GENERAL.CHECK_NULL [SP-002] on CB_BLK.IND_NATURE checking CB_BLK.REPORT_TYPE | When the user leaves the Indent Nature field | Ensures that a report type is selected before the user advances past the Indent Nature filter | Error for Report Type displayed; user must return to Report Type and complete it |

**Alternative Flows:**
None evidenced.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Indent Nature (`IND_NATURE`) | Mandatory | List | N/A | N/A | All / Manual / MARS-Ed / MARS-NonEd | Report Type selected | Report Type must be populated when this field is exited | Mandatory field error for Report Type displayed |
| Report Type (`REPORT_TYPE`) | Mandatory | List | N/A | N/A | Detail (D) / Summary (H) | N/A | Must not be blank at time of Indent Nature exit | Mandatory field error for Report Type displayed; cursor blocked |

---

---

#### Requirement ID: BR-010

**Requirement Title:** Report Type Selection - Filter Layout Adjustment

**Business Description:**
When the user changes the Report Type selection, the system immediately adjusts which location filter fields are enabled or locked on the screen, based on both the selected report type and whether the current user's dealer location is a spares stockyard. For Summary reports from a stockyard, the Location field is disabled and the Seller Location field is enabled. For Detail reports, the reverse applies and the Seller Location is reset to "All Locations". This ensures the user can only provide the location filters that are meaningful for the chosen report format.

**Actors:** User (spares stockyard or standard dealership user)

**Preconditions:**
- The report filter screen has been initialised.
- The user has changed the value in the Report Type drop-down list.

**Main Flow:**

**Step 1 - Screen layout adjusted based on report type and user type combination**
When the user changes the Report Type list selection, the system evaluates the combination of the new report type (Detail or Summary) and the current session's dealer location type (spares stockyard or standard). Based on this combination, the system enables or disables the Location and Seller Location fields as follows:

- Spares stockyard user, Summary report selected: the Location and Location Description fields are disabled; the Seller Location and Seller Location Description fields are enabled.
- Spares stockyard user, Detail report selected: the Seller Location is reset to "ALL" and its description to "ALL Locations"; the Location and Location Description fields are enabled; the Seller Location and Seller Location Description fields are disabled.
- Standard (non-stockyard) user, Detail report selected: the Seller Location is reset to "ALL" and its description to "ALL Locations"; the Seller Location and Seller Location Description fields are disabled.
- Standard (non-stockyard) user, Summary report selected: the Seller Location is reset to "ALL" and its description to "ALL Locations"; the Seller Location and Seller Location Description fields are enabled.

#### Business Scenarios - How filter layout differs by report type and user type

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Spares stockyard - Summary report** | Location disabled; Seller Location enabled (user can scope to a specific selling stockyard or leave as "ALL") |
| **Spares stockyard - Detail report** | Location enabled; Seller Location disabled and reset to "ALL" |
| **Standard dealership - Detail report** | Seller Location disabled and reset to "ALL" (no seller location filter needed for non-stockyard Detail) |
| **Standard dealership - Summary report** | Seller Location enabled and reset to "ALL" (user can scope to a selling stockyard if desired) |

**Alternative Flows:**
None evidenced.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Report Type (`REPORT_TYPE`) | Mandatory | List | N/A | N/A | Detail (D) / Summary (H) | Report filter screen initialised | N/A | N/A |
| Location (`LOC_CD`) | Conditional - enabled or disabled depending on report type / user type combination | Text | N/A | Location lookup (LOV_LOC / RG_LOC from AM_DEALER_LOC) | Location code | Report Type selected | Enabled for Detail reports (stockyard users); disabled for Summary reports (stockyard users) | N/A |
| Location Description (`LOC_DESC`) | Auto-populated | Display | 70 characters | LOV_LOC (returns LOC_DESC) | Location description | Location code set | Enabled/disabled alongside Location | N/A |
| Seller Location (`SO_LOC_CD`) | Conditional - enabled or disabled depending on report type / user type combination | Text | N/A | Seller Location lookup (LOV_SO_LOC / RG_SO_LOC from AM_DEALER_LOC) | Location code | Report Type selected | Enabled for Summary reports; disabled and reset to "ALL" for Detail reports | N/A |
| Seller Location Description (`SO_LOC_DESC`) | Auto-populated | Display | 70 characters | LOV_SO_LOC (returns LOC_DESC) | Location description | Seller Location code set | Enabled/disabled alongside Seller Location; reset to "ALL Locations" when disabled | N/A |

---

---

#### Requirement ID: BR-011

**Requirement Title:** Seller Location Field - Location Prerequisite Validation

**Business Description:**
When the user leaves the Seller Location field, the system checks that a buying location has already been selected. If the Location field is blank at this point, the user is presented with a mandatory field error for the Location. This ensures that the location scope is established before the Seller Location filter is accepted.

**Actors:** User (spares stockyard user, Summary report context)

**Preconditions:**
- The report filter screen has been initialised.
- The user has navigated to the Seller Location field and is attempting to leave it.

**Main Flow:**

**Step 1 - Location prerequisite check performed when leaving Seller Location**
When the user attempts to leave the Seller Location field, the system checks whether the Location field is blank. If Location is blank, the mandatory field check for Location is raised, showing an error and preventing the user from proceeding.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-002](#SP-002--GENERAL.CHECK_NULL)) - GENERAL.CHECK_NULL - checks whether the Location field is blank; if blank, displays the mandatory field error for the Location label and raises a form trigger failure.
    * **Step 1** - Check whether the Location field value is blank.
    * **Step 2** - If blank, display a message indicating that the Location field must be completed and prevent the user from leaving the current field.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Location is populated before Seller Location is accepted | Prerequisite check - GENERAL.CHECK_NULL [SP-002] on CB_BLK.SO_LOC_CD checking CB_BLK.LOC_CD | When the user leaves the Seller Location field | Ensures the buying location scope is established before the seller location filter is accepted | Error for Location displayed; user must return to Location and complete it |

**Alternative Flows:**
None evidenced.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Seller Location (`SO_LOC_CD`) | Conditional - enabled only for specific user type / report type combinations | Text | N/A | Seller Location lookup (LOV_SO_LOC / RG_SO_LOC from AM_DEALER_LOC) | Location code | Location selected | Location must be populated when this field is exited | Mandatory field error for Location displayed |
| Location (`LOC_CD`) | Mandatory | Text | N/A | Location lookup (LOV_LOC / RG_LOC from AM_DEALER_LOC) | Location code | N/A | Must not be blank at time of Seller Location exit | Mandatory field error for Location displayed; cursor blocked |

---

---

#### Requirement ID: BR-012

**Requirement Title:** Child Indent Tracking Report Generation and CSV Export

**Business Description:**
When the user clicks the Generate Report button, the system runs a final set of validation checks on the filter criteria and then produces a CSV file containing the requested child indent tracking data. For Detail (line-level) reports requested by non-stockyard users, the system stages the matching records in a per-user working table before reading them back for the export. For spares stockyard users requesting Detail reports, and for all users requesting Summary (aggregated) reports, the system reads directly from the main tracking table. The generated file is written to the application server and immediately opened in the user's browser for download.

**Actors:** User (spares stockyard or standard dealership user)

**Preconditions:**
- The report filter screen has been initialised.
- All required filter fields have been populated: a consignee has been selected, a location has been selected, a From Date and To Date within the allowed range have been entered, a Report Type has been chosen, and Part Category and Indent Nature filters have been set.

**Main Flow:**

**Step 1 - Pre-generation filter validation**
Before building the report, the system re-validates the filter criteria in sequence. First it checks that the Consignee field is not blank; if blank, it displays *"Consignee must be selected"* and returns focus to the Consignee field without generating the report. Next it checks that the Location field is not blank; if blank, it displays *"Location must be selected"* and returns focus to the Location field. It then checks that the From Date is not more than 180 days before today; if so, it displays *"From Date cannot be generated more than 180 days back"* and returns focus to the From Date. Finally it checks that the date range between From Date and To Date does not exceed 30 days; if so, it displays *"Data can be generated for maximum 30 days"* and returns focus to the To Date.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-003](#SP-003--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays one of the four validation error messages (consignee not selected, location not selected, From Date too far back, or range exceeds 30 days) when the corresponding check fails; control then returns to the triggering field without proceeding with report generation.
    * **Step 1** - Receive the error message text and severity.
    * **Step 2** - Display the message to the user and return control to the caller.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Consignee must be selected before report generation | WHEN-BUTTON-PRESSED on CB_BLK.PB_REPORT - GENERAL.DISP_TEXT [SP-003] | When the user presses the Generate Report button | Prevents a report run with no consignee scoping | *"Consignee must be selected"* displayed; focus returns to Consignee field |
| Location must be selected before report generation | WHEN-BUTTON-PRESSED on CB_BLK.PB_REPORT - GENERAL.DISP_TEXT [SP-003] | When the user presses the Generate Report button after consignee check passes | Prevents a report run with no location scoping | *"Location must be selected"* displayed; focus returns to Location field |
| From Date within 180-day lookback limit | WHEN-BUTTON-PRESSED on CB_BLK.PB_REPORT - GENERAL.DISP_TEXT [SP-003] | When the user presses the Generate Report button after location check passes | Enforces the maximum historical data lookback window at report generation | *"From Date cannot be generated more than 180 days back"* displayed; focus returns to From Date |
| Date range does not exceed 30 days | WHEN-BUTTON-PRESSED on CB_BLK.PB_REPORT - GENERAL.DISP_TEXT [SP-003] | When the user presses the Generate Report button after From Date check passes | Enforces the per-report data volume limit at generation time | *"Data can be generated for maximum 30 days"* displayed; focus returns to To Date |

*Business outcomes (errors, warnings, success, and status):*
- **BR-012-ES-01** - Consignee not selected - *"Consignee must be selected"*; report not generated; focus returns to Consignee.
- **BR-012-ES-02** - Location not selected - *"Location must be selected"*; report not generated; focus returns to Location.
- **BR-012-ES-03** - From Date beyond 180-day limit - *"From Date cannot be generated more than 180 days back"*; report not generated; focus returns to From Date.
- **BR-012-ES-04** - Date range over 30 days - *"Data can be generated for maximum 30 days"*; report not generated; focus returns to To Date.

**Step 2 - Report data prepared according to report type and user type**
Once all validations pass, the system constructs a timestamped CSV filename using the current user's ID and the current date and time. It then prepares the report data based on the report type and user type:

For a Detail report from a standard (non-stockyard) user: the system deletes the current user's existing rows from the per-user interim staging table, then inserts the matching indent tracking records from the main tracking table (filtered by the selected date range, parent group, buying location, part category, and indent nature). A commit is issued after the insert. If any exception occurs during this staging step, it is silently ignored and the report query is redirected to read the matching rows from the staging table for this user.

For a Detail report from a spares stockyard user: the system builds the report query to read directly from the main tracking table, filtered by the selected date range, parent group, buying location, seller location, part category, and indent nature.

For a Summary (header-level) report from any user: the system builds an aggregated report query from the main tracking table joined to the dealer location master, grouping by consignee, location, selling location, indent nature, and part category, and summing order value, cancel value, and net issue value for the selected date range, consignee, selling location, buying location, part category, and indent nature.

**Step 3 - CSV file generated and opened in the browser**
The system stores the constructed query string in a hidden control field and then calls the CSV export program unit, passing the output filename and the query. The export program unit runs the query as an in-memory record group, counts the resulting rows, and caps output at 65,535 rows if the Excel row limit is exceeded. It writes each row to a CSV file on the application server, reads the download URL base path from a server-side configuration file, constructs the full file URL, and opens the file in a new browser window or tab for the user to download.

*Procedures called:*
- **VIEW_EXCEL_REP** ([SP-001](#SP-001--VIEW_EXCEL_REP)) - VIEW_EXCEL_REP - executes the full CSV export pipeline: resolves the output filename, runs the report query as an in-memory record group, writes each row to a server-side CSV file, and opens the file URL in the user's browser.
    * **Step 1** - Resolve the output filename from the current user session and timestamp; if the path contains spaces, redirect to the C:\ root and show an informational message.
    * **Step 2** - Check for an existing in-memory record group with the same name and delete it if found, then create a new record group from the report query and populate it.
    * **Step 3** - Count the rows in the record group; if the count exceeds 65,535, display *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."* and limit the output to 65,535 rows.
    * **Step 4** - Read the server-side URL base path from the reports configuration file, construct the full server file path and the download URL.
    * **Step 5** - Open the server-side file for writing, then write each record group row as a line in the CSV file, and close the file.
    * **Step 6** - Open the constructed download URL in a new browser window or tab so the user can access the generated file.
    * **Step 7** - If any exception occurs during the export, display a message beginning with *"Error  -"* followed by the Oracle error code and error text, and raise a form trigger failure.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Excel row limit enforcement | Row count check - VIEW_EXCEL_REP [SP-001] internal logic | When the record group is populated from the report query | Prevents the generated file from exceeding the row count that can be opened in older versions of Excel | *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."* displayed; output truncated to 65,535 rows |
| File export error handling | Exception handler - VIEW_EXCEL_REP [SP-001] WHEN OTHERS | When any error occurs during file writing or URL construction | Ensures the user is informed if the export fails and the form remains stable | *"Error  -"* followed by the Oracle error code and error text displayed; form trigger failure raised |

*Business outcomes (errors, warnings, success, and status):*
- **BR-012-IC-01** - *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."* - shown when the generated output file path contains spaces; file is saved to C:\ instead.
- **BR-012-IC-02** - *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."* - shown when the report data exceeds the Excel row limit; output is capped.

#### Business Scenarios - How the report export differs by report type and user type

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Detail report - Standard (non-stockyard) user** | Data is staged in the per-user interim table (delete existing, insert new from tracking table filtered by buying location) before the CSV query reads from the staging table |
| **Detail report - Spares stockyard user** | No staging step; CSV query reads directly from the main tracking table, filtered by buying location and seller location |
| **Summary report - Any user** | CSV query reads aggregated totals from the main tracking table joined to the dealer location master, grouped by key dimensions, filtered by seller location |

**Alternative Flows:**
- **BR-012-AF-01** - (from Step 2) If an exception occurs during the staging delete/insert step for a non-stockyard Detail report, the exception is silently suppressed; the report query then falls back to reading the matching records directly from the main tracking table for the current user's session, scoped by the same filter criteria.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Consignee (`CONSG_CD`) | Mandatory | Text | N/A | Consignee lookup (LOV_CONSG / RG_CONSG) | Consignee code | Report filter screen initialised | Must not be blank at report generation | *"Consignee must be selected"* displayed |
| Location (`LOC_CD`) | Mandatory | Text | N/A | Location lookup (LOV_LOC / RG_LOC from AM_DEALER_LOC) | Location code | Consignee selected | Must not be blank at report generation | *"Location must be selected"* displayed |
| From Date (`FROM_DATE`) | Mandatory | Date | DD-MM-RRRR | N/A | N/A | N/A | Must not be more than 180 days before today at report generation | *"From Date cannot be generated more than 180 days back"* displayed |
| To Date (`TO_DATE`) | Mandatory | Date | DD-MM-RRRR | N/A | N/A | From Date entered | Range from From Date must not exceed 30 days at report generation | *"Data can be generated for maximum 30 days"* displayed |
| Report Type (`REPORT_TYPE`) | Mandatory | List | N/A | N/A | Detail (D) / Summary (H) | Report filter screen initialised | Must be selected; determines which query path is used | N/A |
| Part Category (`CATG`) | Mandatory | List | N/A | N/A | All / part category values | Report Type selected | Used to filter the report data by part category | N/A |
| Indent Nature (`IND_NATURE`) | Mandatory | List | N/A | N/A | All / Manual / MARS-Ed / MARS-NonEd | Report Type selected | Used to filter the report data by indent nature | N/A |
| Seller Location (`SO_LOC_CD`) | Conditional | Text | N/A | Seller Location lookup (LOV_SO_LOC / RG_SO_LOC) | Location code | Report Type and user type applicable | Used in Summary and stockyard Detail queries to filter by seller location | N/A |
| Query String Control (`ITEM884`) | Auto-populated | Text | 10,000 characters | N/A | Dynamically built SQL query string | All filter validations passed | System-set; stores the constructed report query; not user-visible | N/A |

---

---

#### Requirement ID: BR-013

**Requirement Title:** Form-Level Error Interception and User-Friendly Error Display

**Business Description:**
The form intercepts all errors that occur during any operation and translates them into user-friendly messages before displaying them. Specific error conditions - an invalid date entry, a date in the wrong format, a non-numeric value in a numeric field, a standard field error, a database integrity constraint violation, a record updated by another user, and any other database error - each produce a distinct, readable message. This prevents raw technical error codes from being shown to the user and ensures consistent, business-appropriate error handling across the entire form.

**Actors:** System (automatic, no user action required)

**Preconditions:**
- An error has been raised anywhere within the form's operation.

**Main Flow:**

**Step 1 - Invalid date entry error detected and handled**
If the error corresponds to an invalid date (internal error code 50004), the system displays the message *"Entered Date is not valid Date"* and raises a form trigger failure. The form remains open on the current field.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-003](#SP-003--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays *"Entered Date is not valid Date"* as an error message.
    * **Step 1** - Receive the message text and severity.
    * **Step 2** - Display the message to the user and return control to the caller.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Invalid date value intercepted | Error code 50004 check - ON-ERROR in Form; GENERAL.DISP_TEXT [SP-003] | When an invalid date value is entered in any date field | Replaces the raw system error with a user-friendly message | *"Entered Date is not valid Date"* displayed; form trigger failure raised; form remains open |

**Step 2 - Wrong date format error detected and handled**
If the error corresponds to a date entered in an incorrect format (internal error codes 50025 or 50026), the system displays the message *"Enter the Date in the proper format (DD-MM-YYYY)"* and raises a form trigger failure.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-003](#SP-003--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays *"Enter the Date in the proper format (DD-MM-YYYY)"* as an error message.
    * **Step 1** - Receive the message text and severity.
    * **Step 2** - Display the message to the user and return control to the caller.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Incorrect date format intercepted | Error codes 50025 / 50026 check - ON-ERROR in Form; GENERAL.DISP_TEXT [SP-003] | When a date is entered in the wrong format | Guides the user to use the DD-MM-YYYY date format | *"Enter the Date in the proper format (DD-MM-YYYY)"* displayed; form trigger failure raised |

**Step 3 - Non-numeric value in numeric field detected and handled**
If the error corresponds to a non-numeric or special character entry in a numeric field (internal error codes 40209 or 50016), the system displays the message *"Characters/Special Characters are not allowed here, enter the numeric value"* and raises a form trigger failure.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-003](#SP-003--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays *"Characters/Special Characters are not allowed here, enter the numeric value"* as an error message.
    * **Step 1** - Receive the message text and severity.
    * **Step 2** - Display the message to the user and return control to the caller.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Non-numeric character in numeric field intercepted | Error codes 40209 / 50016 check - ON-ERROR in Form; GENERAL.DISP_TEXT [SP-003] | When a non-numeric character is entered in a numeric field | Instructs the user to enter only numeric values | *"Characters/Special Characters are not allowed here, enter the numeric value"* displayed; form trigger failure raised |

**Step 4 - Standard field error detected and handled**
If the error corresponds to a standard field-level error (internal error code 40207), the system displays the error text returned by the form's own error mechanism and raises a form trigger failure.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-003](#SP-003--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the error text from the form's error text as an error message.
    * **Step 1** - Receive the error text from the form error state and the severity.
    * **Step 2** - Display the message to the user and return control to the caller.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Standard field error intercepted | Error code 40207 check - ON-ERROR in Form; GENERAL.DISP_TEXT [SP-003] with error text | When a standard field-level error is raised | Displays the form's own error text through the standard message mechanism | Error text displayed; form trigger failure raised |

**Step 5 - Database integrity constraint violation detected and handled**
If the database error corresponds to an integrity constraint violation (database error code -02292), the system calls the structured error handler with the predefined error code for this condition.

*Procedures called:*
- **GENERAL.RAISE_ERROR** ([SP-004](#SP-004--GENERAL.RAISE_ERROR)) - GENERAL.RAISE_ERROR - looks up and raises the predefined business error message registered under the integrity constraint error code.
    * **Step 1** - Receive the error code identifier for the integrity constraint violation.
    * **Step 2** - Look up the corresponding predefined error message text.
    * **Step 3** - Display the predefined error message to the user and raise a form trigger failure.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Database integrity constraint violation intercepted | Database error code -02292 check - ON-ERROR in Form; GENERAL.RAISE_ERROR [SP-004] | When a database foreign key or other constraint violation occurs | Provides a business-meaningful error instead of a raw database error code | Predefined integrity constraint error message displayed; form trigger failure raised |

**Step 6 - Concurrent update conflict detected and handled**
If the error corresponds to a concurrent update conflict (internal error codes 40654, 40655, 40656, 40657, or 40659), the system displays the message *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*, rolls back the current transaction, and raises a form trigger failure.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-003](#SP-003--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the concurrent update conflict message as an error.
    * **Step 1** - Receive the concurrent update message text and severity.
    * **Step 2** - Display the message to the user and return control to the caller.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Concurrent update conflict intercepted | Error codes 40654, 40655, 40656, 40657, 40659 check - ON-ERROR in Form; GENERAL.DISP_TEXT [SP-003]; followed by Rollback | When another user has modified the same record | Protects data integrity by notifying the user and rolling back the conflicting change | *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"* displayed; rollback issued; form trigger failure raised |

**Step 7 - Any other database error detected and handled**
If a non-zero SQL error code is present (any other database error not covered by earlier branches), the system displays the database's own error message text, rolls back the current transaction, and raises a form trigger failure.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-003](#SP-003--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the database error message text (SQLERRM) as an error message.
    * **Step 1** - Receive the database error message text (the system's own error description) and severity.
    * **Step 2** - Display the message to the user and return control to the caller.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Any other database error intercepted | Non-zero SQLCODE check - ON-ERROR in Form; GENERAL.DISP_TEXT [SP-003] with SQLERRM; followed by Rollback | When any unhandled database error occurs during form operation | Ensures any unhandled database error is displayed to the user and the transaction is safely rolled back | Database error message text displayed; rollback issued; form trigger failure raised |

**Step 8 - Record navigation errors suppressed**
If the error corresponds to record navigation errors (internal error codes 40401 or 40405 - no records found or record navigation), no action is taken and the error is silently ignored.

*Business outcomes (errors, warnings, success, and status):*
- **BR-013-ES-01** - Invalid date entry - *"Entered Date is not valid Date"*; form remains open.
- **BR-013-ES-02** - Wrong date format - *"Enter the Date in the proper format (DD-MM-YYYY)"*; form remains open.
- **BR-013-ES-03** - Non-numeric value in numeric field - *"Characters/Special Characters are not allowed here, enter the numeric value"*; form remains open.
- **BR-013-ES-04** - Standard field error - Error text from the form's error state; form remains open.
- **BR-013-ES-05** - Database integrity constraint violation - Predefined business error message via GENERAL.RAISE_ERROR; form remains open.
- **BR-013-ES-06** - Concurrent update conflict - *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*; rollback performed; form remains open. (Error codes: 40654, 40655, 40656, 40657, 40659)
- **BR-013-ES-07** - Any other database error - Database error message text (SQLERRM); rollback performed; form remains open.

**Alternative Flows:**
- **BR-013-AF-01** - (from Step 8) Error codes 40401 or 40405 (no records found / navigation): no message is shown and no action is taken; the error is silently suppressed.

---

---

#### Requirement ID: BR-014

**Requirement Title:** Form-Level Message Interception

**Business Description:**
When Oracle Forms emits informational messages internally, the form intercepts specific message codes and converts them into error-level alerts. Messages corresponding to non-numeric or format-related input codes are displayed through the standard error display mechanism with a form trigger failure, ensuring they are treated as errors rather than passing silently as information messages.

**Actors:** System (automatic, no user action required)

**Preconditions:**
- A system informational message has been raised within the form during any operation.

**Main Flow:**

**Step 1 - Specific informational messages upgraded to error display**
When the form's message handler is invoked, the system checks whether the message code is 40209 or 40207. If either code applies, the system displays the combined error type, code number, and error text as an error-level message and raises a form trigger failure. For all other message codes, the built-in Forms message behaviour applies.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-003](#SP-003--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the combined error type, code, and text as an error message and raises a form trigger failure for the intercepted message codes.
    * **Step 1** - Receive the message text (composed of error type, code number, and error description) and severity.
    * **Step 2** - Display the message to the user and return control to the caller.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Message codes 40209 and 40207 treated as errors | Message code check - ON-MESSAGE in Form; GENERAL.DISP_TEXT [SP-003] | When the form emits an informational message with code 40209 or 40207 | Ensures that non-numeric or format-related input conditions are surfaced as errors rather than silent informational messages | Combined error type, code, and text displayed as an error; form trigger failure raised |

*Business outcomes (errors, warnings, success, and status):*
- **BR-014-ES-01** - Message codes 40209 or 40207 intercepted - Combined error type, code number, and error text displayed as an error message; form trigger failure raised.

**Alternative Flows:**
- **BR-014-AF-01** - (from Step 1) Message code is anything other than 40209 or 40207: the ON-MESSAGE trigger takes no action and the default Forms message handling applies.

---

---

#### Requirement ID: BR-015

**Requirement Title:** Form Exit and Database Session Cleanup

**Business Description:**
When the user exits the form, the system closes it immediately without prompting to save any unsaved changes. At the same time, it clears the session registration information that was set when the form opened, so that the database session no longer shows the form as the active application for that user. This ensures clean session tracking in database monitoring tools.

**Actors:** User (any user)

**Preconditions:**
- The form is open and the user has initiated an exit action.

**Main Flow:**

**Step 1 - Form closed without validation**
When the user exits the form, the system immediately closes it without performing any data validation or prompting the user about unsaved changes.

**Step 2 - Database session registration cleared**
After initiating the form exit, the system clears the client information and module/action registration that were set in the database session when the form opened. Both the client info and the module name are cleared to null/empty, removing the form's trace from the active database session.

**Alternative Flows:**
None evidenced.

---

---

#### Requirement ID: BR-016

**Requirement Title:** Report Filter Screen Clear and Toolbar Operation Controls

**Business Description:**
The filter screen provides four toolbar-driven operations that govern how the user saves, resets, inserts, and deletes data on the form. Saving commits any pending changes to the database and then clears the filter screen. Cancelling resets all filter fields to their default "all" values, with a confirmation prompt shown if the user has begun filling in filter criteria. Inserting a new record is not permitted on this form - the system informs the user accordingly. Deleting a record from the program master block requires explicit confirmation before the deletion proceeds. These controls ensure consistent, guided data management on the report filter screen.

**Actors:** User (any user)

**Preconditions:**
- The form is open and the user has activated one of the Save, Cancel, Insert, or Delete toolbar buttons.

**Main Flow:**

**Step 1 - Save button: pending changes committed and filter screen cleared**
When the user presses the Save button, the system commits all pending form changes to the database. Immediately after the commit completes, the system clears the entire filter screen so the user can begin entering new report criteria. The form remains open and ready for the next filter entry session.

**Step 2 - Cancel button: active-filter confirmation prompt shown when form has query data**
When the user presses the Cancel button and the form is in a query (data-loaded) state, the system asks the user to confirm the discard: *"Entered data will not be Saved"*. If the user confirms (response = 1), the system proceeds to clear the form. If the user does not confirm, no action is taken and the current filter values remain unchanged.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Confirm discard when form is in query state | FT_CANCEL - GENERAL.ASK_CONFIRM check on system.form_status | When the Cancel button is pressed while filter data is loaded | Prevents accidental loss of entered filter values by requiring user confirmation | *"Entered data will not be Saved"* shown; if user does not confirm, the form retains its current values |

**Step 3 - Cancel button: filter screen cleared and default values restored**
After the form clear (confirmed when in query state; immediate when not in query state), the system restores the filter fields to their opening defaults: Consignee is set to "ALL", the Consignee display label is set to *"ALL CONSIGNEES"*, Location is set to "ALL", the Location display label is set to *"ALL LOCATIONS"*, the Dealer Map Code is set to "%", the From Date is set to 30 days before today, the To Date is set to today's date, and the copyright declaration field is refreshed from the copyright declaration function.

**Step 4 - Insert operation blocked on this form**
When the user presses the Insert toolbar button, the system checks whether the button is enabled. If the Insert button is active, the system immediately displays the message *"This Operation Cannot be performed Here"* and prevents any insert action. Insert is not a supported operation on the Child Indent Tracking report filter screen.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-003](#SP-003--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays *"This Operation Cannot be performed Here"* as an error message when the user attempts to use the Insert toolbar button.
    * **Step 1** - Receive the error message text and severity.
    * **Step 2** - Display the message to the user and return control.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Insert operation not permitted on this form | FT_INSERT - PB_BLK.PB_INSERT enabled check; GENERAL.DISP_TEXT [SP-003] | When the user presses the Insert toolbar button while it is active | Prevents unsupported insert operations on the read-only report filter screen | *"This Operation Cannot be performed Here"* displayed; no record is created |

*Business outcomes (errors, warnings, success, and status):*
- **BR-016-ES-01** - Insert attempted - *"This Operation Cannot be performed Here"*; operation blocked; form remains open.

**Step 5 - Delete button: confirmation required before record deletion**
When the user presses the Delete toolbar button and the cursor is on the program master block, the system disables form validation, navigates to the program master block, and asks the user to confirm the deletion: *"Are you sure to Delete?"*. If the user confirms (response = 1), the system deletes the current record. After the confirmation outcome (whether deleted or not), form validation is re-enabled. If the cursor is not on the program master block, no action is taken.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Confirm before deleting a program master record | FT_DEL - PB_BLK.PB_DEL enabled check and cursor block check; GENERAL.ASK_CONFIRM | When the user presses the Delete toolbar button while the cursor is on the program master block | Prevents accidental deletion of program master records by requiring explicit user confirmation | *"Are you sure to Delete?"* shown; if user does not confirm (response != 1), no record is deleted and form validation is restored |

*Business outcomes (errors, warnings, success, and status):*
- **BR-016-WS-01** - Delete confirmation - *"Are you sure to Delete?"* shown; user must confirm to proceed with deletion.

**Alternative Flows:**
- **BR-016-AF-01** - (from Step 2) Cancel button pressed when the form is NOT in a query state: no confirmation prompt is shown; the form is cleared immediately and filter defaults are restored (Step 3).
- **BR-016-AF-02** - (from Step 4) Insert toolbar button is not active (disabled): no action is taken and no message is shown.
- **BR-016-AF-03** - (from Step 5) Delete toolbar button is not active, or cursor is not on the program master block: no action is taken.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Consignee (`CONSG_CD`) | Auto-reset on Cancel | Text | N/A | Consignee lookup (LOV_CONSG / RG_CONSG) | Consignee code | N/A | Reset to "ALL" on Cancel | N/A |
| Consignee Description (`DEALER_NAME`) | Auto-reset on Cancel | Display | 70 characters | N/A | N/A | N/A | Reset to "ALL CONSIGNEES" on Cancel | N/A |
| Location (`LOC_CD`) | Auto-reset on Cancel | Text | N/A | Location lookup (LOV_LOC / RG_LOC from AM_DEALER_LOC) | Location code | N/A | Reset to "ALL" on Cancel | N/A |
| Location Description (`LOC_DESC`) | Auto-reset on Cancel | Display | 70 characters | N/A | N/A | N/A | Reset to "ALL LOCATIONS" on Cancel | N/A |
| Dealer Map Code (`DEALER_MAP_CD`) | Auto-reset on Cancel | Text | N/A | N/A | N/A | N/A | Reset to "%" on Cancel | N/A |
| From Date (`FROM_DATE`) | Auto-reset on Cancel | Date | DD-MM-RRRR | N/A | N/A | N/A | Reset to sysdate minus 30 on Cancel | N/A |
| To Date (`TO_DATE`) | Auto-reset on Cancel | Date | DD-MM-RRRR | N/A | N/A | N/A | Reset to sysdate on Cancel | N/A |
| Copyright Declaration (`COPYRIGHT_DECLARATION`) | Auto-reset on Cancel | Text | 100 characters | N/A | Copyright text from SF_COPYRIGHT_DECLARATION | N/A | Refreshed from copyright declaration function on Cancel | N/A |

---

---

## 5. Business Rules Catalogue

| Rule ID | Rule Name | Rule Type | Business Requirement ID | Condition | Action | Business Impact |
| ------- | --------- | --------- | ----------------------- | --------- | ------ | --------------- |
| BRC-001 | Consignee Is Mandatory | Validation | BR-003 | The Consignee field is left blank | Block the user from leaving the field and display the mandatory field error for Consignee | Prevents the report from being generated without a consignee selection; ensures report data is scoped to a valid buying party |
| BRC-002 | Location Is Mandatory | Validation | BR-004 | The Location field is left blank | Block the user from leaving the field and display the mandatory field error for Location | Prevents the report from being generated without a location selection; ensures report data is scoped to a valid dealership location |
| BRC-003 | From Date Is Mandatory | Validation | BR-005 | The From Date field is left blank | Block the user from leaving the field and display the mandatory field error for From Date | Ensures the report date range has a valid start date |
| BRC-004 | From Date Cannot Be a Future Date | Validation | BR-005 | The From Date entered is later than today's date | Display *"From Date cannot be greater than current date"* and prevent the user from leaving the field | Prevents the user from requesting data for dates that have not yet occurred |
| BRC-005 | From Date 180-Day Boundary Auto-Adjust | Derivation | BR-005 | The From Date entered equals exactly 180 days before today's date | Automatically set the To Date to be From Date plus 180 days | Assists the user when navigating near the maximum lookback boundary by auto-completing the To Date |
| BRC-006 | To Date Is Mandatory | Validation | BR-006 | The To Date field is left blank | Block the user from leaving the field and display the mandatory field error for To Date | Ensures the report date range has a valid end date |
| BRC-007 | To Date Cannot Be a Future Date | Validation | BR-006 | The To Date entered is later than today's date | Display *"To Date cannot be greater than current date"* and prevent the user from leaving the field | Prevents the user from requesting data for dates that have not yet occurred |
| BRC-008 | To Date Cannot Be Earlier Than From Date | Validation | BR-006 | The To Date entered is earlier than the From Date | Display *"To Date cannot be older than From Date"* and prevent the user from leaving the field | Ensures the date range is logically valid (end date must be on or after start date) |
| BRC-009 | Date Range Cannot Exceed 30 Days | Validation | BR-006, BR-011 | The difference between To Date and From Date is greater than 30 days | Display *"Date range cannot be greater than 30 days!"*, clear the To Date field, and return focus to the To Date field (at validation time); or display *"Data can be generated for maximum 30 days"* and return focus to To Date (at report generation time) | Limits the volume of data extracted in a single report run to protect system performance |
| BRC-010 | Report Type Is Mandatory | Validation | BR-007 | The Report Type field is left blank | Block the user from leaving the field and display the mandatory field error for Report Type | Ensures the user explicitly selects either the Detail or Summary report format before generating the report |
| BRC-011 | Report Type Drives Location Field Availability for Stockyard Users | Derivation | BR-010 | The user is a spares stockyard and changes the Report Type selection | Enable or disable the Location and Seller Location fields based on the combination: Summary report enables Seller Location and disables Location; Detail report enables Location, disables Seller Location, and resets Seller Location to "ALL" | Ensures that the correct geographic filter is available and active for each report type, matching the data model for stockyard versus non-stockyard users |
| BRC-012 | Report Type Drives Seller Location for Non-Stockyard Users | Derivation | BR-010 | The user is not a spares stockyard and changes the Report Type selection | For Detail report: disable Seller Location and reset it to "ALL". For Summary report: enable Seller Location and reset it to "ALL" | Controls the seller location filter availability for non-stockyard users per the business rules of each report type |
| BRC-013 | Consignee Must Be Selected Before Report Generation | Validation | BR-011 | The Consignee field is blank when the Generate Report button is pressed | Display *"Consignee must be selected"* and return focus to the Consignee field without generating the report | Prevents a report run with no consignee filter, which would return invalid or unscoped results |
| BRC-014 | Location Must Be Selected Before Report Generation | Validation | BR-011 | The Location field is blank when the Generate Report button is pressed | Display *"Location must be selected"* and return focus to the Location field without generating the report | Prevents a report run with no location filter, which would return invalid or unscoped results |
| BRC-015 | From Date Cannot Be More Than 180 Days in the Past at Generation | Validation | BR-011 | The From Date is more than 180 days before today when the Generate Report button is pressed | Display *"From Date cannot be generated more than 180 days back"* and return focus to the From Date field without generating the report | Enforces the maximum lookback window for historical data retrieval |
| BRC-016 | Date Range Cannot Exceed 30 Days at Generation | Validation | BR-011 | The difference between To Date and From Date exceeds 30 days when the Generate Report button is pressed | Display *"Data can be generated for maximum 30 days"* and return focus to the To Date field without generating the report | Enforces the data volume limit at the point of report generation as a final safety check |
| BRC-017 | Invalid Date Format Intercepted at Form Level | Validation | BR-012 | A date field receives a value that is not a valid date (error code 50004) | Display *"Entered Date is not valid Date"* and raise a form trigger failure | Provides a user-friendly error message for invalid date entry, replacing the default system error |
| BRC-018 | Incorrect Date Format Intercepted at Form Level | Validation | BR-012 | A date field receives a value in the wrong format (error codes 50025 or 50026) | Display *"Enter the Date in the proper format (DD-MM-YYYY)"* and raise a form trigger failure | Guides the user to enter dates in the expected DD-MM-YYYY format |
| BRC-019 | Non-Numeric Value in Numeric Field Intercepted | Validation | BR-012 | A numeric field receives a non-numeric character or special character (error codes 40209 or 50016) | Display *"Characters/Special Characters are not allowed here, enter the numeric value"* and raise a form trigger failure | Prevents invalid characters from being entered in numeric fields |
| BRC-020 | Concurrent Update Conflict Detected | Constraint | BR-012 | A concurrent update conflict error is raised (error codes 40654-40659) | Display *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*, roll back the current transaction, and raise a form trigger failure | Protects data integrity by notifying the user of concurrent updates and rolling back to prevent data overwrites |
| BRC-021 | Excel Row Limit Enforcement | Constraint | BR-011 | The number of rows in the generated report exceeds 65,535 | Display an informational message *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."* and truncate the export to 65,535 rows | Prevents the generated CSV from exceeding the maximum row count that can be opened in older versions of Excel |
| BRC-022 | File Path Space Restriction | Constraint | BR-011 | The generated output filename contains a space in the folder path | Display an informational message that the file cannot be saved in the specified path and will be stored in the C drive instead; adjust the filename to use the C:\ root | Prevents file system errors caused by spaces in directory names on the client or server |

**Total Business Rules Identified: 22**

---

## 6. Data Requirements

*This section covers the data entities, capture requirements, reference data, and lifecycle for the PE_CHILD_INDENT_TRACKING form, which allows users to query and export child indent tracking data as a CSV report based on filter criteria.*

### 6.1 Business Entities and Relationships

*The form operates against two core transaction/master entities: the child indent tracking record store and the dealer location master.*

#### Child Indent Tracking Records - PT_IDT_TRACKING

The child indent tracking table holds the full lifecycle record of each part indent raised between a buying location and a selling location in the spares distribution chain. Each record captures the indent details (number, date, nature, part information, quantities), the dispatch and issue lifecycle stages (pick, issue, MRN receipt), financial values (order value, cancel value, net issue value), and buyer/seller organisational attributes. The form queries this table when building both the Detail and Summary export reports.

#### Interim Report Data Store - PT_IDT_REP_INTER

This is an intermediary working table used to stage data for the current user's Detail report session. When a Detail report is generated by a non-spares-stockyard location, the system first clears any previous data for the user from this table, populates it from the tracking records matching the selected filters, and then reads back from it to compose the CSV export. This staging approach isolates concurrent users' report runs from one another.

#### Dealer Location Master - AM_DEALER_LOC

The dealer location master stores the dealer and location attributes for each principal-dealer-location combination. The form queries this table at initialisation to determine whether the current session's dealer location is a spares stockyard, and to load the default consignee code, dealer name, and location description for the screen. It is also joined in the Summary (header-level) report query to verify the seller location's spares stockyard status.

#### Consignee Master - AM_CONSIGNEE

The consignee master is referenced by the consignee lookup to list the valid consignees for the current principal and parent group, filtering to active dealership categories. This table is not directly updated or queried by the main report flow, but it feeds the consignee selection list from which the user picks a consignee code.

#### Entity Relationships

The form's key objects relate as follows: each dealer location record in AM_DEALER_LOC can be the source of many child indent tracking records in PT_IDT_TRACKING (joined on seller group, dealer map code, and location code). The AM_CONSIGNEE table supplies valid consignee codes that appear as PT_IDT_TRACKING.CONSG_CD values, linked through AM_DEALER_LOC. PT_IDT_REP_INTER is a user-session-scoped staging copy of PT_IDT_TRACKING data with no persistent foreign key to the tracking table.

```
AM_DEALER_LOC (Dealer Location Master)
        ├── PT_IDT_TRACKING (Child Indent Tracking Records)
        └── AM_CONSIGNEE (Consignee Master)
PT_IDT_REP_INTER (Interim Report Data Store - staging only, per user session)
```

### 6.2 Data Capture Requirements

*The form captures report filter criteria only; it does not persist new business records. All fields are entered by the user prior to generating the export.*

#### Report Filter Criteria (User - before generating the child indent tracking report)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Consignee (`CONSG_CD`) | Yes | The consignee (buying dealer) whose indent records are to be included in the report. For spares stockyard locations the field is pre-set to "ALL" and locked; for standard locations the field is pre-populated with the session's assigned consignee and locked. | Must not be blank when the report is generated. |
| Dealer Name (`DEALER_NAME`) | Auto-Populated | Display of the name of the selected consignee's dealership. Populated automatically when the consignee is resolved at initialisation; read-only. | N/A - display only. |
| Location (`LOC_CD`) | Yes | The buying location code to filter the report. For spares stockyard locations, pre-set to "ALL"; for standard locations, pre-populated with the session location and locked. When report type is Summary (Header), the field is additionally disabled for spares stockyard users. | Must not be blank when the report is generated. |
| Location Description (`LOC_DESC`) | Auto-Populated | Display of the description for the selected location. Populated alongside the location code at initialisation; read-only. | N/A - display only. |
| From Date (`FROM_DATE`) | Yes | The start date of the indent date range to be reported. Defaults to 30 days before the current date. Must be entered in DD-MM-YYYY format. | Must not be blank; must not be a future date; must not be more than 180 days before the current date (enforced again at report generation). |
| To Date (`TO_DATE`) | Yes | The end date of the indent date range to be reported. Defaults to the current date. Must be entered in DD-MM-YYYY format. | Must not be blank; must not be a future date; must not be earlier than the From Date; the range between From Date and To Date must not exceed 30 days. |
| Report Type (`REPORT_TYPE`) | Yes | Determines whether the output is a Detail (line-level) or Summary (header/aggregated) report. Presented as a drop-down list. Changing this value adjusts which location filters are enabled or disabled. | Must not be blank. |
| Part Category (`CATG`) | Yes | Filters the report to a specific part category (e.g. Main Parts, Accessories) or all categories. Presented as a drop-down list. | Must not be blank (validated at report generation via Report Type validation trigger). |
| Indent Nature (`IND_NATURE`) | Yes | Filters the report by the nature of the indent (Manual, MARS-Ed, MARS-NonEd, or All). Presented as a drop-down list. | Must not be blank (validated at report generation via Report Type validation trigger). |
| Seller Location (`SO_LOC_CD`) | Conditional | The selling location code to include in the report. Relevant only when the user is a spares stockyard and the Report Type is Summary (Header). Pre-set to "ALL" by default; enabled only for that combination. | N/A when the field is disabled; when enabled, no additional user validation beyond selection from the lookup list. |
| Seller Location Description (`SO_LOC_DESC`) | Auto-Populated | Display of the description for the selected seller location. Populated alongside the seller location code at initialisation; read-only. | N/A - display only. |

#### Session and Control Parameters (System - applied at initialisation)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Spares Stockyard Flag (`P_SPR_STOCKYARD`) | Auto-Populated | Session-level flag indicating whether the current dealer location is a spares stockyard. Loaded from the dealer location master at initialisation; drives which fields are pre-filled versus user-selectable, and which layout branches apply. | Set by the system; not user-editable. |
| Parent Group (`PARENT_GROUP`) | Auto-Populated | Organisational parent group code for the current session, carried as a global value. Used in all queries to scope data to the correct principal group. | Set by session globals; not user-editable. |

### 6.3 Reference Data

*Lists the master and configuration data referenced by this form.*

| Reference Data | Business Purpose | Used When |
| :--- | :--- | :--- |
| Consignee lookup (`LOV_CONSG` / `RG_CONSG` from `AM_CONSIGNEE` joined `AM_DEALER_LOC`) | Provides the list of valid consignees for the current principal and parent group, filtered to active dealership categories. Includes an "ALL CONSIGNEES" option. | When the user opens the consignee lookup on the Consignee field (spares stockyard users only; standard users have the field pre-filled and locked). |
| Location lookup (`LOV_LOC` / `RG_LOC` from `AM_DEALER_LOC`) | Provides the list of valid buying locations for the selected consignee and principal, filtered to active (non-terminated) locations. Includes an "ALL LOCATIONS" option. | When the user opens the location lookup on the Location field (spares stockyard users only; standard users have the field pre-filled and locked). |
| Seller Location lookup (`LOV_SO_LOC` / `RG_SO_LOC` from `AM_DEALER_LOC`) | Provides the list of valid selling locations that are spares stockyards for the selected consignee, filtered to active locations. Includes an "ALL LOCATIONS" option. | When the user opens the seller location lookup on the Seller Location field (spares stockyard users, Summary report type only). |
| Report Type list (`REPORT_TYPE` list item) | Defines the two report output levels: Detail (line-per-indent-part) and Summary (aggregated header totals). | When the user selects the report type before generating the export. |
| Part Category list (`CATG` list item) | Defines the available part category filter options (All, Main Parts, Accessories, etc.) that scope which part categories appear in the report. | When the user selects the part category filter before generating the export. |
| Indent Nature list (`IND_NATURE` list item) | Defines the indent nature filter options (All, Manual, MARS-Ed, MARS-NonEd) that scope which types of indents appear in the report. | When the user selects the indent nature filter before generating the export. |
| Excel output path configuration (`/reports/DMS/excelpath.txt`) | A server-side text file that holds the base URL path to the reports printer directory, used to construct the download link for the generated CSV file. | At CSV file generation time inside the VIEW_EXCEL_REP program unit. |

### 6.4 Data Lifecycle

*Describes how records are created, updated, and saved within this form's evidenced behaviour.*

**Creation**

- This form does not create new business records. All data written by the form is limited to the interim staging table used to support the Detail report generation.
- When a Detail report is generated for a non-spares-stockyard user, the system inserts rows into the interim report staging table (`PT_IDT_REP_INTER`) for the current user, sourced from the child indent tracking table matching the selected filter criteria.

**Updates**

- The form does not update existing business records. No DML update operations are performed against permanent tables.

**Save and Commit**

- Before populating the interim report staging table, the system deletes the current user's existing rows from that table and issues a commit to clear prior data.
- After inserting the new staging rows, the system issues a commit to persist them.
- If an exception occurs during the staging insert, the operation is silently ignored (no error is shown to the user; the exception handler takes no action), and the report query falls back to reading directly from the main tracking table.
- No standard Oracle Forms save/commit action is available; the KEY-COMMIT trigger is inactive (does not execute).

**Retention and Audit**

- The interim staging table holds only data for the current user session's most recent Detail report request; prior rows are replaced on each new report generation.
- The form does not implement any archival or purge policy for the permanent tracking records.
- No create/modify audit stamps are written by this form.

---

### 6.5 Excel Output Columns

This form does not use Excel download. No Excel export columns were identified in the form sources.

## 7. Glossary

*Definitions of terms, abbreviations, and acronyms used throughout this document.*

The following table defines key terms, acronyms, and abbreviations used throughout this Business Requirements Document.

| Term | Definition | Aliases | Related Terms |
| :--- | :--- | :--- | :--- |
| ALL | Wildcard filter value used to include all consignees, locations, or indent natures without restriction | - | Consignee, Location, Indent Nature |
| AM_CONSIGNEE | Database table storing consignee (dealer) master records including codes and names | - | Consignee, AM_DEALER_LOC |
| AM_DEALER_LOC | Database table storing dealer location master records including location code, description, parent group, stockyard flag, and principal mapping | - | Dealer, Location, MULDMS |
| BRD | Business Requirements Document - a structured specification of the functional and technical requirements for a system module | - | Functional Requirements |
| CATG | Part category filter - classifies spare parts into groups such as M (Main) and AA for report filtering | Part Category | IND_NATURE, REPORT_TYPE |
| CB_BLK | Control block - the single Oracle Forms data block in pe_child_indent_tracking that holds all report criteria items; has no database binding | Control Block | Block |
| Consignee | A dealer or distribution entity that receives spare parts indents; identified by a consignee code and name | CONSG_CD | AM_CONSIGNEE, Dealer |
| CSV | Comma-Separated Values - the file format used to deliver the exported indent tracking report data | Flat File | Report, Export |
| D | Detail report type - exports line-level indent tracking data including part numbers, quantities, pick, issue, and receipt details | Detail | H, REPORT_TYPE |
| DBMS_APPLICATION_INFO | Oracle built-in package used to register module and client information in the active database session for auditing | - | PRE-FORM, Session |
| Dealer | An authorised sales and/or service point within the DMS network, identified by a dealer map code and location | DEALER_MAP_CD | Consignee, Location, AM_DEALER_LOC |
| DMS | Dealer Management System - the integrated software platform managing dealer operations including parts, sales, and service | - | pe_child_indent_tracking |
| DPL | Shared Oracle Forms program library (DPL.pld) providing reusable utility routines such as CHECK_NULL, DISP_TEXT, and RAISE_ERROR | DPL.pld, general | PLD, GENERAL |
| GENERAL | The package name used in DPL.pld to qualify shared library routine calls (e.g. GENERAL.CHECK_NULL) | - | DPL, CHECK_NULL, DISP_TEXT |
| H | Header report type - exports summarised indent values (order value, cancel value, net issue value) grouped by consignee, location, and indent nature | Header, Summary | D, REPORT_TYPE |
| IND_NATURE | Indent nature filter - classifies indents as Manual, MARS-Ed, or MARS-NonEd for report filtering | Indent Nature | CATG, REPORT_TYPE |
| Indent | A spare parts requisition submitted by a dealer location to the principal or a selling location | Indent Order | INDENT_NUM, PT_IDT_TRACKING |
| LOV | List of Values - a popup selection list in Oracle Forms allowing the user to choose from validated options | Dropdown, Picklist | Record Group, CB_BLK |
| MARS | Materials and Requirements System - the system used to generate MARS-Ed and MARS-NonEd indent nature classifications | - | IND_NATURE |
| MULDMS | Database schema prefix for the multi-dealer DMS schema; used in the AM_DEALER_LOC location LOV query | - | AM_DEALER_LOC, Schema |
| OLB | Oracle Object Library (DPL.olb) - a library of reusable property classes and visual attributes subclassed into this form | DPL.olb | PLD, DPL |
| Parent Group | A grouping code that identifies the dealer group or principal to which a location belongs; used to filter consignees and locations in LOV queries | PARENT_GROUP | Dealer, Consignee |
| pe_child_indent_tracking | The Oracle Forms module that implements the Child Indent Tracking reporting screen | PE_CHILD_INDENT_TRACKING, Child Indent Tracking | DMS, CSV |
| PK_PART_SEARCH_NEW | Database package referenced in VIEW_EXCEL_REP for its part_tab_11 type definition; used to define the export record group type | - | VIEW_EXCEL_REP |
| PLD | Oracle Forms Program Library (DPL.pld) - a shared library of procedures and functions attached to the form | DPL.pld | DPL, GENERAL |
| PT_IDT_REP_INTER | Intermediate staging database table that receives filtered indent tracking rows for the current user before CSV export (non-stockyard detail reports) | Staging Table | PT_IDT_TRACKING, USERID |
| PT_IDT_TRACKING | Primary indent tracking database table containing line-level and summary indent data queried by the report generation logic | - | PT_IDT_REP_INTER, Indent |
| REPORT_TYPE | Filter item on the screen that selects between Detail (D) and Header (H) report formats | Report Type | D, H |
| SF_COPYRIGHT_DECLARATION | Database function called at block initialisation to load the copyright declaration text displayed on the form | - | COPYRIGHT_DECLARATION |
| SO_LOC_CD | Seller location code - the source or selling location in a child indent transaction; used as a filter in header report mode for stockyard users | Seller Location | LOC_CD, Spares Stockyard |
| Spares Stockyard | A dealer location designated as a spares distribution hub (SPARES_STOCK_YARD_YN = Y); triggers different filter visibility rules on the form | Stockyard | P_SPR_STOCKYARD, SO_LOC_CD |
| USERID | The Oracle Forms global variable holding the logged-in user ID; used for file naming, data staging, and session identification | :GLOBAL.USERID | GLOBAL |
| VIEW_EXCEL_REP | Form-local procedure that executes a supplied SQL query, writes the result to a server-side CSV file, and opens it in the browser | - | CSV, DPL, PK_PART_SEARCH_NEW |
| WN_MAIN | Inherited main window object providing the console window for the form; defined in the DPL object library | - | OLB, DPL |

---

---

## 8. Technical Inventory

*Complete inventory of Oracle Forms components including blocks, items, triggers, canvases, and global variables.*

### 8.1 Form Architecture

**Form Module Details:**

- Form Name: pe_child_indent_tracking (PE_CHILD_INDENT_TRACKING)
- Form Module XML Title: MODULE2
- Oracle Forms Version: 12c (Module version 122010400)
- Parent Object Library: DPL.olb (PC_FORM property class)
- Attached Libraries: D2KWUTIL, WEBUTIL (webutil.olb), DPL (DPL.pld program library)
- First Navigation Block: -
- Console Window: WN_MAIN - Child Indent Tracking Report (V 1.0.0) (inherited from DPL.olb object group)
- Compile Dependencies: Requires DPL.olb, DPL.pld, WEBUTIL.olb, menu.mmx, database packages PK_PART_SEARCH_NEW
- Source artifacts: `pe_child_indent_tracking_fmb.xml`; OLB `DPL.olb`; D2KWUTIL; WEBUTIL (webutil.olb); DPL (DPL.pld program library)

### 8.1.1 Global Variables

| Global Variable | Data Type | Set Location | Purpose |
| :--- | :--- | :--- | :--- |
| APP_ID | Char | ProgramUnit | Application identifier used to resolve report configuration and parameters |
| CUR_DATE | Date | ProgramUnit | Current system date set at form initialisation for date validation |
| DEALER | Char | ProgramUnit / Trigger | Dealer map code for the logged-in user's location; used to filter consignee and location lookups |
| LOC_CD | Char | ProgramUnit / Trigger | Location code for the logged-in user; used to pre-populate and filter location fields |
| PARENT_GROUP | Char | ProgramUnit / RecordGroup / Trigger | Dealer parent group code; used in record group queries to restrict data to the user's dealer group |
| PRINCIPAL | Char | RecordGroup / Trigger | Principal map code for the logged-in dealer location; used in WHEN-NEW-BLOCK-INSTANCE to fetch dealer details |
| REPORT_DESC | Char | Trigger | Report description carried across form sessions for display purposes |
| USERID | Char | ProgramUnit / Trigger | Logged-in user ID; used for file naming, data filtering, and audit column population |

### 8.1.2 Form Parameters

*All 9 ModuleParameter entries from pe_child_indent_tracking_fmb.xml.*

| Parameter | Data Type | Default | Description |
| :--- | :--- | :--- | :--- |
| P_SPR_STOCKYARD | Char | N | Indicates whether the user's location is a spares stockyard (Y/N); controls visibility and defaulting of consignee and location fields at block initialisation |
| ENQ_DATE | Date | - | Enquiry date passed in when the form is launched from a parent context; not referenced in active trigger code |
| P_CHECK | Number | 0 | Flag to control report parameter visibility; used in commented-out POP_LIST logic - Reserved - not used in current active form logic |
| TB | Number | 0 | Reserved - not used in current active form logic |
| PR_REMARK | Char | - | Remark value passed from calling module; not referenced in active trigger code |
| CHECK_MAND | Char | N | Mandatory-check flag passed from parent form; not referenced in active trigger code |
| P_USER_TYPE | Char | DLR | User type (DLR = Dealer, MUL = Principal); used in commented-out LIST_POPULATE logic to determine region filtering - Reserved - not used in current active form logic |
| P_REGION | Char | - | Region code passed at startup for dealer-type users; used in commented-out LIST_POPULATE logic - Reserved - not used in current active form logic |
| P_USER_HORO | Char | - | User hierarchy level (HO = Head Office, RO = Regional Office); used in commented-out LIST_POPULATE logic - Reserved - not used in current active form logic |

**Total Parameters:** 9

### 8.2 Blocks

| Block Name | Query Data Source | Records | Q/I/U/D | Key Mode | Master-Detail Relationship |
| :--- | :--- | :--- | :--- | :--- | :--- |
| CB_BLK | - | 1 | N/N/N/N | Default | Control - entry point for report parameter selection; no master-detail relationship |

**Total Blocks:** 1 business blocks

### 8.2.1 Block WhereClause and OrderByClause

*Block query scope from pe_child_indent_tracking_fmb.xml. **Description** explains filter and sort in business terms; **Order By** and **Where Clause** columns retain verbatim XML text for migration.*

| Block | Description | Order By (XML) | Where Clause (XML) |
| :--- | :--- | :--- | :--- |
| - | No blocks with WhereClause/OrderByClause in pe_child_indent_tracking_fmb.xml | - | - |

### 8.3 Items Summary

*Complete item inventory from `pe_child_indent_tracking_fmb.xml`.*

**Block counts:**

*Database / non-database counts derived from XML.*

| Block | Total Items | Database Items | Non-Database Items |
| :--- | ---: | ---: | ---: |
| CB_BLK | 17 | 0 | 17 |
| PB_BLK | 12 | 0 | 12 |
| CB_ERR | 1 | 0 | 1 |
| **Total** | **30** | **0** | **30** |

**Item detail (all 30 items):**

| Block | Item Name | DatabaseItem | Description |
| :--- | :--- | :--- | :--- |
| CB_BLK | CONSG_CD | false | Consignee code entry/selection field; links to LOV_CONSG for lookup |
| CB_BLK | DEALER_NAME | false | Dealer name display field populated from consignee lookup |
| CB_BLK | LOC_CD | false | Location code entry/selection field; links to LOV_LOC |
| CB_BLK | FROM_DATE | false | Report start date filter; validated to be not in the future and within 180 days back |
| CB_BLK | TO_DATE | false | Report end date filter; validated to be ≤ current date and within 30 days of From Date |
| CB_BLK | REPORT_TYPE | false | Report type list selector; values D (Detail) or H (Header/Summary) |
| CB_BLK | LOC_DESC | false | Location description display field populated from location lookup |
| CB_BLK | CONSG_CD_DESC | false | Consignee description display field populated from consignee lookup |
| CB_BLK | DEALER_MAP_CD | false | Dealer map code display field populated from location lookup |
| CB_BLK | PB_REPORT | false | Generate Report button; triggers data extraction and Excel file creation |
| CB_BLK | ITEM884 | false | Hidden internal field used to store the dynamically built report query string |
| CB_BLK | COPYRIGHT_DECLARATION | false | Copyright declaration text populated from SF_COPYRIGHT_DECLARATION function at block initialisation |
| CB_BLK | PARENT_GROUP | false | Parent group display field; shows the dealer parent group for the logged-in user |
| CB_BLK | CATG | false | Part category filter list selector; values include ALL, M (Main), AA |
| CB_BLK | IND_NATURE | false | Indent nature filter list selector; values include ALL, MAN (Manual), MED (MARS-Ed), and MARS-NonEd |
| CB_BLK | SO_LOC_CD | false | Seller location code entry/selection field; links to LOV_SO_LOC |
| CB_BLK | SO_LOC_DESC | false | Seller location description display field populated from seller location lookup |
| PB_BLK | PB_EXIT | false | Inherited toolbar button that exits the form; triggers WHEN-BUTTON-PRESSED to confirm and close the session (inherited from DPL.olb PB_BLK object group) |
| PB_BLK | PB_LIST | false | Inherited toolbar button that invokes the LOV for the current item (inherited from DPL.olb PB_BLK object group) |
| PB_BLK | PB_INSERT | false | Inherited toolbar button that creates a new record in the current block (inherited from DPL.olb PB_BLK object group) |
| PB_BLK | PM_CONT | false | Inherited toolbar button providing a continuation/context action (inherited from DPL.olb PB_BLK object group) |
| PB_BLK | PB_DEL | false | Inherited toolbar button that deletes the current record (inherited from DPL.olb PB_BLK object group) |
| PB_BLK | PB_CANCEL | false | Inherited toolbar button that cancels pending changes and clears the current record (inherited from DPL.olb PB_BLK object group) |
| PB_BLK | PB_SAVE | false | Inherited toolbar button that saves (commits) the current record (inherited from DPL.olb PB_BLK object group) |
| PB_BLK | PB_PRINT | false | Inherited toolbar button that triggers the print action for the current form (inherited from DPL.olb PB_BLK object group) |
| PB_BLK | PB_CUT | false | Inherited toolbar button that cuts the selected text from the current item (inherited from DPL.olb PB_BLK object group) |
| PB_BLK | PB_COPY | false | Inherited toolbar button that copies the selected text from the current item (inherited from DPL.olb PB_BLK object group) |
| PB_BLK | PB_PASTE | false | Inherited toolbar button that pastes clipboard text into the current item (inherited from DPL.olb PB_BLK object group) |
| PB_BLK | PB_ERR_EXIT | false | Inherited toolbar button that exits the error window and returns focus to the main canvas (inherited from DPL.olb PB_BLK object group) |
| CB_ERR | TXT_ERR | false | Inherited text item on the CN_ERR error canvas that displays the current error message text to the user (inherited from DPL.olb CB_ERR object group) |

### 8.4 List of Values

| LOV Name | Title | Record Group | Attached Block.Item |
| :--- | :--- | :--- | :--- |
| LOV_CONSG | Select Consignee from list | RG_CONSG | CB_BLK.CONSG_CD, CB_BLK.DEALER_NAME, CB_BLK.CONSG_CD_DESC |
| LOV_LOC | LOCATION | RG_LOC | CB_BLK.LOC_CD, CB_BLK.LOC_DESC, CB_BLK.DEALER_MAP_CD |
| LOV_SO_LOC | Seller Location | RG_SO_LOC | CB_BLK.SO_LOC_CD, CB_BLK.SO_LOC_DESC |

**Total LOVs:** 3

### 8.5 Alerts

| Alert Name | Title | Message Text | Calling Context |
| :--- | :--- | :--- | :--- |
| ALERT_BUT | Note | Please select valid region code and for code | **COMMENTED OUT / INACTIVE** - Only referenced in commented-out ProgramUnit: PR_PASS_PARAM |
| AL_PRINT | Print | (set at runtime) | Inherited from DPL.olb object group; invoked by the shared PROC_REPORT_CALL library routine to present print confirmation dialogs |
| AL_ERRINFO | Error | (set at runtime) | Inherited from DPL.olb object group; invoked by GENERAL.RAISE_ERROR and related error-handling routines to display error detail to the user |
| AL_NOTE | Note | (set at runtime) | Inherited from DPL.olb object group; invoked by GENERAL.DISP_TEXT to present informational modal messages |
| AL_CONFIRM | Caution | (set at runtime) | Inherited from DPL.olb object group; invoked by GENERAL.ASK_CONFIRM to present Yes/No confirmation dialogs |

**Total Alerts:** 5

### 8.6 Program Units

*Authoritative catalogue of **11 form-local program units**. Database packages and standalone procedures are in **Section 15.2**; PLD shared-library routines are in **Section 18**.*

| Program Unit | Type | Calls | Description |
| :--- | :--- | :--- | :--- |
| VIEW_EXCEL_REP | Procedure | PK_PART_SEARCH_NEW (type reference), TEXT_IO.FOPEN, TEXT_IO.GET_LINE, TEXT_IO.FCLOSE, TEXT_IO.PUT_LINE, WEB.SHOW_DOCUMENT, FIND_GROUP, DELETE_GROUP, CREATE_GROUP_FROM_QUERY, POPULATE_GROUP, GET_GROUP_ROW_COUNT, FIND_COLUMN, GET_GROUP_CHAR_CELL, WEBUTIL_FILE_TRANSFER.URL_TO_CLIENT, WEBUTIL_HOST.HOST | Builds a CSV file from a supplied SQL query, writes it to the server, and opens it in the browser. Reads the export path from `/reports/DMS/excelpath.txt`; limits output to 65,535 rows |
| VALIDATE_CN_MAIN | Unknown | None (entire body is commented out) | **COMMENTED OUT / INACTIVE** - Entire body is a block comment (NULL; only); formerly validated test-drive record fields using GENERAL.CHECK_NULL and GENERAL.DISP_TEXT |
| CHECK_BEFORE_DELETE | Unknown | None (entire body is commented out) | **COMMENTED OUT / INACTIVE** - Entire body is NULL; formerly queried SH_ENQUIRY to block deletion when dependent enquiry records exist |
| POPULATE_ERRORS | Inactive | None (entire body is commented out) | **COMMENTED OUT / INACTIVE** - Declared as a package spec stub (NULL;); no active behaviour |
| L_POPULATE | Unknown | None (entire body is commented out) | **COMMENTED OUT / INACTIVE** - Entire body is NULL; formerly created a record group from AM_LIST and populated a list item |
| LIST_POPULATE | Inactive | None (entire body is commented out) | **COMMENTED OUT / INACTIVE** - Entire body is NULL; formerly built dynamic SQL to populate a region code list item based on user type |
| POP_LIST | Unknown | None (entire body is commented out) | **COMMENTED OUT / INACTIVE** - Entire body is NULL; formerly determined user type, resolved dealer details from AM_DEALER_LOC, and populated dynamic filter list items |
| PR_REMOVE_ASCII_CHR | Unknown | None (entire body is commented out) | **COMMENTED OUT / INACTIVE** - Entire body is NULL; formerly read a server-side CSV file, stripped control characters, wrote a clean output file, and opened it via web.show_document |
| PR_PASS_PARAM | Inactive | None (entire body is commented out) | **COMMENTED OUT / INACTIVE** - Entire body is NULL; formerly iterated over ED_REPORTS parameters, validated mandatory fields, and built a report parameter string |
| LIST_POPULATE_ZONE | Inactive | None (entire body is commented out) | **COMMENTED OUT / INACTIVE** - Entire body is NULL; formerly built dynamic SQL to populate a zone code list item based on user type |
| POP_LIST_REGION | Unknown | None (entire body is commented out) | **COMMENTED OUT / INACTIVE** - Entire body is NULL; formerly populated region-related list items based on user hierarchy and type |

**Total Program Units:** 11

### 8.7 Triggers

**Item-Level Trigger Types (reference):**

| Trigger Name | Purpose |
| :--- | :--- |
| WHEN-VALIDATE-ITEM | Validates field when user leaves item |
| KEY-* | Keyboard actions - commit, exit, LOV, navigation |
| WHEN-NEW-BLOCK-INSTANCE | Initializes block on entry |
| WHEN-BUTTON-PRESSED | Executes button action |
| PRE-INSERT / POST-INSERT | Before/after record creation |
| WHEN-LIST-CHANGED | Dropdown selection changed |
| PRE-QUERY / POST-QUERY | Before/after query execution |
| WHEN-CHECKBOX-CHANGED | Checkbox toggled |
| WHEN-VALIDATE-RECORD | Validates entire record before leaving row |

**DPL library routines invoked from triggers and program units:**

| Routine | Type | Called From | Purpose |
| :--- | :--- | :--- | :--- |
| GENERAL.ASK_CONFIRM | Library routine | Form level, PB_BLK.PB_EXIT (inherited) | Presents a Yes/No confirmation dialog; returns the user's choice to the caller to determine whether to proceed with the pending action |
| GENERAL.CHECK_NULL | Library routine | CB_BLK.CATG, CB_BLK.CONSG_CD, CB_BLK.FROM_DATE, CB_BLK.IND_NATURE, CB_BLK.LOC_CD, CB_BLK.PARENT_GROUP, CB_BLK.REPORT_TYPE, CB_BLK.SO_LOC_CD, CB_BLK.TO_DATE, ProgramUnit: VALIDATE_CN_MAIN | Raises a user-friendly error and halts navigation if the supplied field value is null |
| GENERAL.DISP_TEXT | Library routine | CB_BLK.FROM_DATE, CB_BLK.PB_REPORT, CB_BLK.TO_DATE, Form level, ProgramUnit: CHECK_BEFORE_DELETE, ProgramUnit: LIST_POPULATE, ProgramUnit: PR_REMOVE_ASCII_CHR, ProgramUnit: VALIDATE_CN_MAIN | Displays a modal message dialog with a supplied message text and a title (Error or Note) |
| GENERAL.RAISE_ERROR | Library routine | Form level | Looks up a message code, displays the resulting message via DISP_TEXT, and raises FORM_TRIGGER_FAILURE for error-type messages |
| WEBUTIL_FILE_TRANSFER.URL_TO_CLIENT | Library routine | ProgramUnit: VIEW_EXCEL_REP | Transfers a server-side file to the client machine using the WebUtil file-transfer API |
| WEBUTIL_HOST.HOST | Library routine | ProgramUnit: VIEW_EXCEL_REP | Executes a host operating-system command on the server from within the Forms session via the WebUtil host API |

### 8.7.1 Inactive / Commented-Out Trigger Register

*Triggers and field validations where XML source is `null;`, fully block-commented, or legacy code preserved but not executed. Do **not** migrate these as active business requirements.*

| Status | Block | Item | Trigger | Former behaviour (preserved in comments) | Disabled since / note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Commented out** | Form | - | ON-ERROR | First two blocks of ON-ERROR logic handle Oracle error codes (40209, 40207, 50026, 50004), integrity violations (-02292), concurrent update codes (40654-40659), and generic SQL errors via GENERAL.DISP_TEXT and GENERAL.RAISE_ERROR | Superseded by a refined third implementation; earlier versions preserved as comments for reference |
| **Inactive stub** | Form | - | KEY-COMMIT | Body is `NULL;`; no commit action occurs at form level | Replaced by the inherited KEY-COMMIT in DPL.olb PC_FORM property class which calls ENTER, CHECK_FORM_FAILURE, COMMIT_FORM, and DO_KEY('CLEAR_FORM') - this form overrides it with a null stub, effectively disabling standard commit |
| **Commented out** | Form | - | KEY-CLRFRM | Formerly called CLEAR_FORM(NO_VALIDATE), restored :GLOBAL.REPORT_DESC, toggled P_CHECK, and invoked POP_LIST | Replaced by a simpler active body that resets only the key filter fields (CONSG_CD, CONSG_CD_DESC, LOC_CD, LOC_DESC, FROM_DATE) |
| **Commented out** | Form | - | FT_SAVE | Formerly provided an alternative save/commit path at form level, mirroring the inherited FT_SAVE toolbar button behaviour from DPL.olb | Superseded by the inherited FT_SAVE trigger from the DPL.olb object group; the form-level override is commented out and inactive |
| **Inactive stub** | Form | - | WHEN-NEW-FORM-INSTANCE | Body is `NULL;`; no form-instance initialisation logic executes at form level | The inherited WHEN-NEW-FORM-INSTANCE from the DPL.olb object group handles standard form initialisation; this form overrides it with a null stub |
| **Commented out** | PB_BLK | PB_EXIT | WHEN-BUTTON-PRESSED | Formerly called GENERAL.ASK_CONFIRM and then EXIT_FORM to close the session after user confirmation | Superseded by the inherited WHEN-BUTTON-PRESSED on PB_BLK.PB_EXIT from DPL.olb; the form-local override is commented out and inactive |

*Additional null-only or partially commented triggers exist on estimation and legacy blocks - see XML `TriggerText` starting with `null;` or `/*`.*

**Complete trigger inventory (46 business triggers):**
*pe_child_indent_tracking_fmb.xml contains Trigger elements.*

| Trigger Name | Block | Item | Called From / Context | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| ON-ERROR | Form | - | Form level | Intercepts Oracle Forms errors; displays user-friendly messages for invalid date, format, numeric, field-level, and concurrent-update errors; rolls back and raises failure on SQL errors |
| ON-MESSAGE | Form | - | Form level | Intercepts informational messages from Oracle Forms; displays field-level error types 40209 and 40207 as modal error dialogs via GENERAL.DISP_TEXT |
| KEY-EXIT | Form | - | Form level | Exits the form without validation; clears application info from DBMS_APPLICATION_INFO |
| KEY-LISTVAL | Form | - | Form level | Shows the LOV associated with the current cursor item when F9 is pressed; navigates to the next item on successful selection |
| KEY-COMMIT | Form | - | Form level | **INACTIVE** - Body is NULL; disables the standard commit action at form level (no commit processing occurs) |
| KEY-CLRFRM | Form | - | Form level | Resets consignee code, consignee description, location code, location description, and from date fields to null; partial clear only |
| KEY-OTHERS | Form | - | Form level | Inherited (inherited) - Suppresses unhandled key events to prevent default Forms key behaviour from firing unexpectedly |
| KEY-NEXT-ITEM | Form | - | Form level | Inherited (inherited) - Navigates to the next item in tab order; standard DPL.olb keyboard navigation handler |
| KEY-PREV-ITEM | Form | - | Form level | Inherited (inherited) - Navigates to the previous item in tab order; standard DPL.olb keyboard navigation handler |
| KEY-NXTBLK | Form | - | Form level | Inherited (inherited) - Navigates to the next block; standard DPL.olb keyboard navigation handler |
| KEY-PRVBLK | Form | - | Form level | Inherited (inherited) - Navigates to the previous block; standard DPL.olb keyboard navigation handler |
| KEY-DOWN | Form | - | Form level | Inherited (inherited) - Navigates to the next record; standard DPL.olb keyboard navigation handler |
| KEY-UP | Form | - | Form level | Inherited (inherited) - Navigates to the previous record; standard DPL.olb keyboard navigation handler |
| FT_SAVE | Form | - | Form level | Inherited (inherited) - Executes the save/commit action from the toolbar; calls ENTER, CHECK_FORM_FAILURE, COMMIT_FORM, and DO_KEY('CLEAR_FORM') via the DPL.olb inherited trigger |
| FT_CANCEL | Form | - | Form level | Inherited (inherited) - Cancels pending changes in the current block; maps to the toolbar Cancel button action from DPL.olb |
| FT_INSERT | Form | - | Form level | Inherited (inherited) - Creates a new record in the current block; maps to the toolbar Insert button action from DPL.olb |
| FT_DEL | Form | - | Form level | Inherited (inherited) - Deletes the current record; maps to the toolbar Delete button action from DPL.olb |
| FT_LIST | Form | - | Form level | Inherited (inherited) - Invokes the LOV for the current item; maps to the toolbar List button action from DPL.olb |
| FT_PRINT | Form | - | Form level | Inherited (inherited) - Triggers the print action for the current form; maps to the toolbar Print button action from DPL.olb |
| WHEN-NEW-FORM-INSTANCE | Form | - | Form level | **INACTIVE** - Body is NULL; the inherited WHEN-NEW-FORM-INSTANCE from DPL.olb handles standard form initialisation; this stub overrides and suppresses it |
| PRE-FORM | Form | - | Form level | Registers the form module name with DBMS_APPLICATION_INFO for session tracking |
| WHEN-NEW-BLOCK-INSTANCE | CB_BLK | - | CB_BLK | Queries AM_DEALER_LOC to determine whether the user's location is a spares stockyard; pre-populates consignee, dealer name, location, default date range, and copyright declaration; navigates to the appropriate first item based on stockyard flag |
| WHEN-VALIDATE-ITEM | CB_BLK | CONSG_CD | CB_BLK.CONSG_CD | Validates that consignee code is not null; calls GENERAL.CHECK_NULL to display error and halt if empty |
| KEY-NEXT-ITEM | CB_BLK | CONSG_CD | CB_BLK.CONSG_CD | Navigates to LOC_CD if stockyard mode is active; otherwise navigates to FROM_DATE |
| WHEN-VALIDATE-ITEM | CB_BLK | LOC_CD | CB_BLK.LOC_CD | Validates that location code is not null; calls GENERAL.CHECK_NULL to display error and halt if empty |
| WHEN-VALIDATE-ITEM | CB_BLK | FROM_DATE | CB_BLK.FROM_DATE | Validates from date is not null and not in the future; automatically sets to date when from date equals sysdate minus 180 days |
| WHEN-VALIDATE-ITEM | CB_BLK | TO_DATE | CB_BLK.TO_DATE | Validates to date is not null, not in the future, not before from date, and that the date range does not exceed 30 days |
| WHEN-VALIDATE-ITEM | CB_BLK | REPORT_TYPE | CB_BLK.REPORT_TYPE | Validates that report type is not null; calls GENERAL.CHECK_NULL to display error and halt if empty |
| WHEN-LIST-CHANGED | CB_BLK | REPORT_TYPE | CB_BLK.REPORT_TYPE | Enables or disables location and seller location fields based on the selected report type and stockyard flag |
| WHEN-BUTTON-PRESSED | CB_BLK | PB_REPORT | CB_BLK.PB_REPORT | Validates all required filters; builds a dynamic SQL query for detail or header report type; inserts data into PT_IDT_REP_INTER for non-stockyard users; calls VIEW_EXCEL_REP to generate and open the CSV export |
| WHEN-VALIDATE-ITEM | CB_BLK | PARENT_GROUP | CB_BLK.PARENT_GROUP | Validates that consignee code is not null; mirrors CONSG_CD validation at this display item |
| KEY-NEXT-ITEM | CB_BLK | PARENT_GROUP | CB_BLK.PARENT_GROUP | Navigates to FROM_DATE when consignee is ALL; otherwise enables location fields and navigates to LOC_CD |
| WHEN-VALIDATE-ITEM | CB_BLK | CATG | CB_BLK.CATG | Validates that report type is not null before allowing navigation away from category filter |
| WHEN-VALIDATE-ITEM | CB_BLK | IND_NATURE | CB_BLK.IND_NATURE | Validates that report type is not null before allowing navigation away from indent nature filter |
| WHEN-VALIDATE-ITEM | CB_BLK | SO_LOC_CD | CB_BLK.SO_LOC_CD | Validates that location code is not null; calls GENERAL.CHECK_NULL to display error and halt if empty |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EXIT | PB_BLK.PB_EXIT (inherited) | Inherited (inherited) - Presents an exit confirmation dialog via GENERAL.ASK_CONFIRM and calls EXIT_FORM if the user confirms; closes the Forms session cleanly |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_LIST | PB_BLK.PB_LIST (inherited) | Inherited (inherited) - Invokes the LOV for the currently focused item; equivalent to pressing F9 from the toolbar |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_INSERT | PB_BLK.PB_INSERT (inherited) | Inherited (inherited) - Creates a new record in the current block; equivalent to the Insert toolbar action |
| WHEN-BUTTON-PRESSED | PB_BLK | PM_CONT | PB_BLK.PM_CONT (inherited) | Inherited (inherited) - Executes a continuation or context-specific action defined by the DPL.olb toolbar framework |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_DEL | PB_BLK.PB_DEL (inherited) | Inherited (inherited) - Deletes the current record after confirmation; equivalent to the Delete toolbar action |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CANCEL | PB_BLK.PB_CANCEL (inherited) | Inherited (inherited) - Cancels pending changes and clears the current record; equivalent to the Cancel toolbar action |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SAVE | PB_BLK.PB_SAVE (inherited) | Inherited (inherited) - Saves (commits) the current record; equivalent to the Save toolbar action |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PRINT | PB_BLK.PB_PRINT (inherited) | Inherited (inherited) - Triggers the print action for the current form; equivalent to the Print toolbar action |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CUT | PB_BLK.PB_CUT (inherited) | Inherited (inherited) - Cuts the selected text from the current item to the clipboard |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_COPY | PB_BLK.PB_COPY (inherited) | Inherited (inherited) - Copies the selected text from the current item to the clipboard |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PASTE | PB_BLK.PB_PASTE (inherited) | Inherited (inherited) - Pastes clipboard text into the current item |

### 8.8 Canvas and Window Inventory

**Windows:**

| Window | Title | Primary Canvas |
| :--- | :--- | :--- |
| WIN_ERR | - | CN_ERR |
| WN_MAIN | Child Indent Tracking Report (V 1.0.0) | CN_MAIN |

**Canvases:**

| Canvas | Type | Window |
| :--- | :--- | :--- |
| CN_ERR | Content | WIN_ERR |
| CN_MAIN | Content | WN_MAIN |
| CN_TOOL | Content | WN_MAIN |

---

### 8.9 Editors

*No editors found in pe_child_indent_tracking_fmb.xml.*

### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

#### 8.10.1 Visual Attributes (form-defined)

*3 VisualAttribute elements defined at form level (not inherited from DPL.olb).*

| Visual Attribute |
| :--- |
| VA_MANDATORY |
| VA_DEFAULT |
| VA_DISPLAY |

#### 8.10.2 Property Classes (form-defined)

*Form-local PropertyClass elements.*

*No form-local property classes found in pe_child_indent_tracking_fmb.xml.*

#### 8.10.3 Object Groups

*Object groups bundle inherited triggers and visual objects applied form-wide at runtime.*

| Object Group Child | Type |
| :--- | :--- |
| KEY-OTHERS | Inherited trigger |
| KEY-NEXT-ITEM | Inherited trigger |
| KEY-PREV-ITEM | Inherited trigger |
| KEY-NXTBLK | Inherited trigger |
| KEY-PRVBLK | Inherited trigger |
| KEY-DOWN | Inherited trigger |
| KEY-UP | Inherited trigger |
| CN_ERR | Inherited canvas |
| VA_DISP | Inherited visualattribute |
| CB_ERR | Inherited block |
| VA_LOV | Inherited visualattribute |
| VA_TRNI_DT | Inherited visualattribute |
| VA_TITLE | Inherited visualattribute |
| VA_ALERT | Inherited visualattribute |
| VA_BUTN | Inherited visualattribute |
| VA_TEXT | Inherited visualattribute |
| VA_MPROMPT | Inherited visualattribute |
| VA_OPROMPT | Inherited visualattribute |
| VA_MAND | Inherited visualattribute |
| VA_NUM | Inherited visualattribute |
| VA_DESC | Inherited visualattribute |
| VA_ICONIC_BUTN | Inherited visualattribute |
| VA_RB | Inherited visualattribute |
| VA_CB | Inherited visualattribute |
| WN_MAIN | Inherited window |
| POP_MAIN | Inherited trigger |
| CN_MAIN | Inherited canvas |
| CN_TOOL | Inherited canvas |
| PB_BLK | Inherited block |
| AL_ERRINFO | Inherited alert |
| AL_NOTE | Inherited alert |
| AL_CONFIRM | Inherited alert |
| WIN_ERR | Inherited window |
| AL_PRINT | Inherited alert |
| FT_SAVE | Inherited trigger |
| FT_CANCEL | Inherited trigger |
| FT_INSERT | Inherited trigger |
| FT_DEL | Inherited trigger |
| FT_LIST | Inherited trigger |
| FT_PRINT | Inherited trigger |
| WHEN-NEW-FORM-INSTANCE | Inherited trigger |

### 8.11 DataSourceColumn Inventory

*No DataSourceColumns found in pe_child_indent_tracking_fmb.xml.*

## 9. Object Library

*The form references the DPL shared object library, which provides standardised visual attributes and property classes used across multiple forms in the application suite.*

Source OLB file(s): DPL_olb.xml

| Name | Type | Description | Used By (count) | Sample Items |
| ---- | ---- | ----------- | --------------- | ------------ |
| VA_CB | VisualAttribute | Visual attribute for check box items - gray background, Arial 8pt, black foreground | referenced | Check box items |
| VA_RB | VisualAttribute | Visual attribute for radio button items - gray background, Arial 8pt, black foreground | referenced | Radio button items |
| VA_ICONIC_BUTN | VisualAttribute | Visual attribute for iconic push buttons - white background, black foreground | referenced | Iconic button items |
| VA_DESC | VisualAttribute | Visual attribute for description display items - gray background, Small Fonts 7pt, blue foreground | referenced | Description/display fields |
| VA_NUM | VisualAttribute | Visual attribute for numeric text items - white background, Arial 8pt, black foreground | referenced | Numeric input fields |
| VA_MAND | VisualAttribute | Visual attribute for mandatory fields - cyan background, Arial 9pt, black foreground | referenced | Mandatory entry fields |
| VA_OPROMPT | VisualAttribute | Visual attribute for optional field prompts - white background, Arial 9pt, black prompt foreground | referenced | Optional field labels |
| VA_MPROMPT | VisualAttribute | Visual attribute for mandatory field prompts - white background, Arial 9pt, red prompt foreground | referenced | Mandatory field labels |
| VA_TEXT | VisualAttribute | Visual attribute for standard text items - white background, Arial 9pt, black foreground | referenced | General text input items |
| VA_BUTN | VisualAttribute | Visual attribute for push buttons - gray background, Arial 10pt bold, black foreground | referenced | Push button items |
| VA_ALERT | VisualAttribute | Visual attribute for alert dialogs - gray background, MT Extra 11pt, black foreground | referenced | Alert dialog objects |
| VA_TITLE | VisualAttribute | Visual attribute for title display items - gray background, Arial 10pt bold, blue foreground | referenced | Screen title fields |
| VA_TRNI_DT | VisualAttribute | Visual attribute for transaction date fields - white background, Courier bold, black foreground | referenced | Date/transaction fields |
| VA_LOV | VisualAttribute | Visual attribute for LOV-linked fields - gray background, Arial 9pt, dark blue foreground | referenced | LOV entry fields |
| VA_DISP | VisualAttribute | Visual attribute for display (read-only) items - r25g75b75 background, Arial 8pt bold, black foreground | referenced | Read-only display items |
| PC_DESC | PropertyClass | Property class for description display items - left-justified, 110-char max, white background, Arial 9pt, blue foreground, no bevel | referenced | Description display items |
| PC_SC_DATE | PropertyClass | Property class for date display items - 11-char max, gray background, Arial 8pt bold, DD-MM-YY format, auto-hint | referenced | Date display items |
| PC_TITLE | PropertyClass | Property class for title text items - centre-justified, gray background, Arial 10pt bold, upper-case | referenced | Title/header items |
| PC_FORMAT | PropertyClass | Property class for formatted text items - centre-justified, 12-char max, white background, Arial 9pt, upper-case | referenced | Code/format fields |
| PC_MR_BLK | PropertyClass | Property class for multi-record blocks - vertical record orientation, change-record navigation style | referenced | Multi-record block definitions |
| PC_DISP | PropertyClass | Property class for disabled display items - left-justified, gray8 background, Arial 9pt, lowered bevel, not keyboard-navigable | referenced | Read-only/disabled display fields |
| PC_LOV | PropertyClass | Property class for LOV items - auto-select off, gray background, Arial 8pt, dark blue foreground | referenced | LOV-linked input fields |
| PC_FORM | PropertyClass | Property class for form-level settings - item-level validation, no savepoint, WN_MAIN console, menu.mmx | referenced | Form module |
| PC_DISP_DATE | PropertyClass | Property class for date display items - gray8 background, DD-MM-RRRR format, not keyboard-navigable | referenced | Date-formatted display items |
| PC_DISP_NUM | PropertyClass | Property class for numeric display items - right-justified, gray8 background, Arial 9pt, not keyboard-navigable | referenced | Numeric display fields |
| PC_DATE | PropertyClass | Property class for date input items - DD-MM-RRRR format, 10-char max, white background, Arial 9pt, date data type | referenced | Date input fields |
| PC_DTTIME | PropertyClass | Property class for date-time input items - DD-MM-RRRR HH24:MI format, 15-char max, initialised to current DB datetime | referenced | Date-and-time input fields |
| PC_CB | PropertyClass | Property class for check box items - white background, Arial 9pt | referenced | Check box items |
| PC_ALERT | PropertyClass | Property class for alert objects - gray background, MT Extra 11pt demilight | referenced | Alert objects |
| PC_MDATE | PropertyClass | Property class for mandatory date input items - DD-MM-RRRR format, red prompt foreground | referenced | Mandatory date input fields |
| PC_RB | PropertyClass | Property class for radio button items - gray background, Arial 9pt | referenced | Radio button items |
| PC_WIND | PropertyClass | Property class for window objects - resizable, maximisable, hide-on-exit, gray background, Arial 10pt bold | referenced | Window objects |
| PC_CANV | PropertyClass | Property class for canvas objects - white background, Arial, 750-wide, WN_MAIN window | referenced | Canvas objects |
| PC_BUTN | PropertyClass | Property class for push buttons - 42-wide, gray background, Arial 9pt bold, no mouse-navigate | referenced | Push button items |
| PC_TEXT | PropertyClass | Property class for standard text items - left-justified, white background, Arial 9pt, mixed case, popup menu POP_MAIN | referenced | Standard text input items |
| PC_MTEXT | PropertyClass | Property class for mandatory text items - left-justified, white background, Arial 9pt, red prompt foreground | referenced | Mandatory text input items |
| PC_UTEXT | PropertyClass | Property class for upper-case text items - left-justified, white background, Arial 9pt, upper-case | referenced | Upper-case text input items |
| PC_MUTEXT | PropertyClass | Property class for mandatory upper-case text items - left-justified, white background, Arial 9pt, red prompt foreground, upper-case | referenced | Mandatory upper-case text inputs |
| PC_NUM | PropertyClass | Property class for numeric items - right-justified, lowest value 0, white background, Arial 9pt, number data type | referenced | Numeric input fields |
| PC_MNUM | PropertyClass | Property class for mandatory numeric items - right-justified, lowest value 0, white background, Arial 9pt, red prompt foreground | referenced | Mandatory numeric input fields |
| PC_ICONIC_BUTN | PropertyClass | Property class for iconic push buttons - iconic, 20-wide, white background, no bevel, no mouse-navigate | referenced | Iconic push button items |
| PC_SCROLL | PropertyClass | Property class for scroll bars - 13-unit scrollbar width | referenced | Scroll bar items |
| OG_GROUP | ObjectGroup | Object group defined in the form module (inherited from or shared via DPL library) | referenced | N/A |

---

## 10. Record Groups

*Lists all record groups, their LOV bindings, query logic, dynamic bindings, business purpose, and form usage.*

| Record Group | Type | Used By LOV | Display Column | Return Column | Dynamic Bindings | Purpose | Where Used |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| RG_CONSG | Query | LOV_CONSG | CONSG_CD | DEALER_NAME | No | Lists consignees (dealers) active in the current parent group for the user to select as the report buyer/consignee | LOV_CONSG -> CB_BLK.CONSG_CD, CB_BLK.DEALER_NAME, CB_BLK.CONSG_CD_DESC |
| RG_LOC | Query | LOV_LOC | LOC_CD | LOC_DESC | Yes - CB_BLK | Lists dealer locations belonging to the current parent group for the user to select the buyer location filter | LOV_LOC -> CB_BLK.LOC_CD, CB_BLK.LOC_DESC, CB_BLK.DEALER_MAP_CD |
| RG_SO_LOC | Query | LOV_SO_LOC | LOC_CD | LOC_DESC | Yes - CB_BLK | Lists seller locations from the MULDMS schema for the user to select the seller/source location filter | LOV_SO_LOC -> CB_BLK.SO_LOC_CD, CB_BLK.SO_LOC_DESC |

**Total Record Groups:** 3

## 11. Referenced Database Objects

*Database tables, views, and objects accessed by the form.*

| Block | Base Table | Primary Key Item | Database Item |
| :--- | :--- | :--- | :--- |
| CB_BLK | - | - | No |

| Object | Schema | Used In | Description |
| :--- | :--- | :--- | :--- |
| `AM_CONSIGNEE` | - | RG_CONSG | Consignee master - stores dealer/consignee codes and names for buyer identification |
| `AM_DEALER_LOC` | - | Trigger WHEN-NEW-BLOCK-INSTANCE | Dealer location master - stores location details, stockyard flag, and principal mapping for each dealer location |
| `DUAL` | - | RG_CONSG, RG_LOC, RG_SO_LOC, Trigger WHEN-BUTTON-PRESSED | Oracle pseudo-table - used in UNION ALL constructs within record group queries and the report button's dynamic SQL |
| `MULDMS.AM_DEALER_LOC` | - | RG_LOC, RG_SO_LOC | Dealer location master in MULDMS schema - used in location and seller location LOV queries to populate filter lists |
| `PT_IDT_REP_INTER` | - | Trigger WHEN-BUTTON-PRESSED | Indent tracking report intermediate table - receives staging data for the current user before the CSV export is built |

**Total Referenced Objects:** 5

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure/Package Index

| Requirement ID | Procedure/Package | Purpose |
| -------------- | ----------------- | ------- |
| BR-001 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Registers the form module name as client info in the database session at form startup |
| BR-001 | DBMS_APPLICATION_INFO.SET_MODULE | Registers the form module name and action in the database session at form startup |
| BR-002 | AM_DEALER_LOC (SELECT) | Queries the dealer location master to determine whether the current session's location is a spares stockyard and to load default consignee, dealer name, and location description |
| BR-002 | SF_COPYRIGHT_DECLARATION | Retrieves the copyright declaration text to be displayed on the form |
| BR-003 | GENERAL.CHECK_NULL | Validates that the Consignee field is not blank when the user leaves the field |
| BR-004 | GENERAL.CHECK_NULL | Validates that the Location field is not blank when the user leaves the field |
| BR-005 | GENERAL.CHECK_NULL | Validates that the From Date field is not blank when the user leaves the field |
| BR-005 | GENERAL.DISP_TEXT | Displays the error message when From Date exceeds the current date |
| BR-006 | GENERAL.CHECK_NULL | Validates that the To Date field is not blank when the user leaves the field |
| BR-006 | GENERAL.DISP_TEXT | Displays error messages when To Date validation rules are breached |
| BR-007 | GENERAL.CHECK_NULL | Validates that the Report Type field is not blank when the user leaves the field |
| BR-008 | GENERAL.CHECK_NULL | Validates that the Report Type field is not blank when leaving the Part Category field |
| BR-009 | GENERAL.CHECK_NULL | Validates that the Report Type field is not blank when leaving the Indent Nature field |
| BR-010 | GENERAL.CHECK_NULL | Validates that the Location field is not blank when leaving the Seller Location field |
| BR-011 | GENERAL.DISP_TEXT | Displays error messages when mandatory field or date range checks fail at report generation |
| BR-011 | PT_IDT_REP_INTER (DELETE/INSERT) | Clears and re-populates the interim report staging table for non-spares-stockyard Detail report runs |
| BR-011 | VIEW_EXCEL_REP | Executes the CSV export: runs the report query, writes the CSV file to the server, and opens it in the browser |
| BR-012 | GENERAL.DISP_TEXT | Displays error messages for form-level errors intercepted by the ON-ERROR trigger |
| BR-012 | GENERAL.RAISE_ERROR | Raises a structured business error for integrity constraint violations |
| BR-013 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Clears the client info from the database session when the form is exited |
| BR-013 | DBMS_APPLICATION_INFO.SET_MODULE | Clears the module and action from the database session when the form is exited |
| - | GENERAL.ASK_CONFIRM | Displays a confirmation dialog in the FT_CANCEL and FT_DEL triggers to obtain user confirmation before cancellation or deletion proceeds |
| - | WEBUTIL.ERRORALERT | Displays a WebUtil-level error alert dialog; called from within the VIEW_EXCEL_REP pipeline when a WebUtil operation fails |
| - | WEBUTIL.FCLOSE | Closes an open server-side file handle after the CSV content has been written; called from VIEW_EXCEL_REP |
| - | WEBUTIL.FOPEN | Opens a server-side file for writing the CSV output; called from VIEW_EXCEL_REP |
| - | WEBUTIL.GETIMPLCLASS | Retrieves the WebUtil implementation class name for environment detection; called from VIEW_EXCEL_REP |
| - | WEBUTIL.GETPROPERTY | Retrieves a WebUtil configuration property value; called from VIEW_EXCEL_REP |
| - | WEBUTIL.GET_LINE | Reads a line from a server-side configuration or data file; called from VIEW_EXCEL_REP |
| - | WEBUTIL.ID_NULL | Tests whether a Forms object handle is null; called from VIEW_EXCEL_REP to check whether the DataRecordSet record group already exists before attempting to delete it |
| - | WEBUTIL.PUT_LINE | Writes a single CSV line to the open server-side file; called from VIEW_EXCEL_REP for each data row |
| - | WEBUTIL.SETPROPERTY | Sets a WebUtil configuration property value; called from VIEW_EXCEL_REP |
| - | WEB.SHOW_DOCUMENT | Opens the generated CSV file URL in a new browser window to deliver the export to the user; called from VIEW_EXCEL_REP |

---

### 12.2 Procedure and Package Catalogue

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| GENERAL.ASK_CONFIRM | Package function | Trigger: FT_CANCEL (Form), Trigger: FT_DEL (Form) | Displays a confirmation dialog presenting the supplied message and returns a numeric code indicating the user's choice; used to confirm cancellation or deletion before the operation proceeds |
| GENERAL.CHECK_NULL | Package procedure | WHEN-VALIDATE-ITEM on CB_BLK.CONSG_CD, CB_BLK.LOC_CD, CB_BLK.FROM_DATE, CB_BLK.TO_DATE, CB_BLK.REPORT_TYPE, CB_BLK.PARENT_GROUP, CB_BLK.CATG, CB_BLK.IND_NATURE, CB_BLK.SO_LOC_CD | Raises a form trigger failure with a standard "field is mandatory" message if the supplied field value is null |
| GENERAL.DISP_TEXT | Package procedure | Trigger: ON-ERROR (Form), Trigger: ON-MESSAGE (Form), Trigger: FT_INSERT (Form), WHEN-VALIDATE-ITEM on CB_BLK.FROM_DATE and CB_BLK.TO_DATE, WHEN-BUTTON-PRESSED on CB_BLK.PB_REPORT | Displays a modal alert dialog (AL_ERRINFO for error title, AL_NOTE otherwise) with the supplied message text and title; used for field validation messages, button pre-condition errors, system error/message interception, and insert-operation feedback |
| GENERAL.RAISE_ERROR | Package procedure | Trigger: ON-ERROR (Form) | Looks up and raises a predefined error message by error code (used for integrity constraint violation E0088) |
| SF_COPYRIGHT_DECLARATION | Standalone database function | WHEN-NEW-BLOCK-INSTANCE on CB_BLK | Returns the copyright declaration text to be populated into the copyright declaration field at form initialisation |
| VIEW_EXCEL_REP | Form program unit (PROCEDURE) | WHEN-BUTTON-PRESSED on CB_BLK.PB_REPORT | Builds an in-memory record group from the report query, writes each row to a CSV file on the application server via WebUtil file routines, and opens the file in the user's browser via WEB.SHOW_DOCUMENT |
| DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Oracle built-in package procedure | PRE-FORM (Form), KEY-EXIT (Form) | Registers or clears the current application module name as client info in the Oracle session for monitoring purposes |
| DBMS_APPLICATION_INFO.SET_MODULE | Oracle built-in package procedure | PRE-FORM (Form), KEY-EXIT (Form) | Registers or clears the current application module name and action in the Oracle session for monitoring purposes |
| WEB.SHOW_DOCUMENT | Oracle built-in package procedure | VIEW_EXCEL_REP program unit | Opens a URL in a new browser window or tab; used to deliver the generated CSV file to the user |
| WEBUTIL.ERRORALERT | WebUtil package procedure | VIEW_EXCEL_REP program unit | Displays a WebUtil-level error alert dialog when a WebUtil file or transfer operation fails during CSV generation |
| WEBUTIL.FCLOSE | WebUtil package procedure | VIEW_EXCEL_REP program unit | Closes the server-side file handle after all CSV rows have been written, ensuring the file is properly flushed and released |
| WEBUTIL.FOPEN | WebUtil package procedure | VIEW_EXCEL_REP program unit | Opens a server-side file in write mode to receive the CSV output rows generated by the report pipeline |
| WEBUTIL.GETIMPLCLASS | WebUtil package function | VIEW_EXCEL_REP program unit | Retrieves the WebUtil implementation class name for runtime environment detection within the export pipeline |
| WEBUTIL.GETPROPERTY | WebUtil package function | VIEW_EXCEL_REP program unit | Retrieves a named WebUtil configuration property value used during CSV file path construction |
| WEBUTIL.GET_LINE | WebUtil package function | VIEW_EXCEL_REP program unit | Reads a line from a server-side configuration file to obtain the URL path used for serving the generated CSV file |
| WEBUTIL.ID_NULL | WebUtil package function (WEBUTIL_C_API) | VIEW_EXCEL_REP program unit | Tests whether a Forms object handle is null; used to check whether the DataRecordSet record group already exists before attempting to delete and recreate it |
| WEBUTIL.PUT_LINE | WebUtil package procedure | VIEW_EXCEL_REP program unit | Writes a single delimited CSV line to the open server-side file for each data row in the record group |
| WEBUTIL.SETPROPERTY | WebUtil package procedure | VIEW_EXCEL_REP program unit | Sets a named WebUtil configuration property value during initialisation of the export pipeline |

---

#### GENERAL.ASK_CONFIRM

Package function from DPL.pld (`general`). Signature: `Function(confirm_msg VARCHAR2) RETURN NUMBER`. Called from the FT_CANCEL and FT_DEL form-level triggers. Displays a confirmation dialog presenting the supplied message and returns a numeric code indicating the user's choice (confirm or cancel). The calling trigger inspects the return value to decide whether to proceed with the cancellation or deletion operation.

#### GENERAL.CHECK_NULL

Called from nine WHEN-VALIDATE-ITEM triggers across the form's filter fields. Signature: `Procedure(p_value IN VARCHAR2, column_title IN VARCHAR2)`. If `p_value` is null, calls `GENERAL.DISP_TEXT` with the message "Enter a valid {column_title}" and raises `FORM_TRIGGER_FAILURE`, preventing the user from leaving a mandatory field blank.

#### GENERAL.DISP_TEXT

Called from the ON-ERROR trigger, the ON-MESSAGE trigger, the FT_INSERT trigger, two WHEN-VALIDATE-ITEM triggers (From Date, To Date), and the Generate Report button trigger. Signature: `Procedure(text_string VARCHAR2, title_string VARCHAR2)`. Displays a modal alert dialog - AL_ERRINFO when the title indicates an error, AL_NOTE otherwise - with the supplied message text and title, and raises a form trigger failure on error conditions.

#### GENERAL.RAISE_ERROR

Called from the ON-ERROR trigger when a database integrity constraint violation (ORA-02292) is detected. Signature: `Procedure(mesg_code IN VARCHAR2)`. Looks up the predefined error message registered under the supplied code (E0088), prepends the code to the message text, and calls `DISP_TEXT`. Raises `FORM_TRIGGER_FAILURE` for error-type messages; displays a dialog for note and caution types.

#### SF_COPYRIGHT_DECLARATION

Standalone database function called once during block initialisation (WHEN-NEW-BLOCK-INSTANCE on CB_BLK). Returns the copyright declaration text that is stored into the copyright declaration field on the form.

#### VIEW_EXCEL_REP

Form-level program unit that implements the full CSV export pipeline. Constructs the output filename from the user's session ID and the current date-time, checks whether the DataRecordSet record group already exists using `WEBUTIL.ID_NULL` and deletes it if so, then creates and populates the record group from the passed report query. Counts the rows and caps at 65,535 if the Excel row limit is exceeded. Opens a server-side file via `WEBUTIL.FOPEN`, reads the server URL path from a configuration file via `WEBUTIL.GET_LINE`, writes each record group row as a delimited CSV line via `WEBUTIL.PUT_LINE`, and closes the file via `WEBUTIL.FCLOSE`. Finally calls `WEB.SHOW_DOCUMENT` to open the file URL in the user's browser. Any exception during execution calls `WEBUTIL.ERRORALERT` or displays the Oracle error code and text before raising a form trigger failure.

#### DBMS_APPLICATION_INFO.SET_CLIENT_INFO

Oracle built-in that tags the current session with application context information. Called at PRE-FORM to register the form name and at KEY-EXIT to clear it.

#### DBMS_APPLICATION_INFO.SET_MODULE

Oracle built-in that tags the current session with application module and action labels. Called at PRE-FORM to register the form name and at KEY-EXIT to clear both to empty strings.

#### WEB.SHOW_DOCUMENT

Oracle built-in that opens a URL in a new browser window or tab. Called from VIEW_EXCEL_REP to deliver the generated CSV file's URL to the user.

#### WEBUTIL.ERRORALERT

WebUtil package procedure that displays a WebUtil-level error alert dialog. Called from VIEW_EXCEL_REP when a WebUtil file or transfer operation raises an exception during the CSV generation pipeline.

#### WEBUTIL.FCLOSE

WebUtil package procedure that closes an open server-side file handle. Called from VIEW_EXCEL_REP after all CSV rows have been written to ensure the file is properly flushed and the handle is released before the URL is served to the browser.

#### WEBUTIL.FOPEN

WebUtil package procedure that opens a server-side file in write mode. Called from VIEW_EXCEL_REP to create or overwrite the CSV output file at the constructed server path before row writing begins.

#### WEBUTIL.GETIMPLCLASS

WebUtil package function that retrieves the WebUtil implementation class name. Called from VIEW_EXCEL_REP for runtime environment detection to ensure the correct WebUtil back-end is active before file operations are attempted.

#### WEBUTIL.GETPROPERTY

WebUtil package function that retrieves a named WebUtil configuration property value. Called from VIEW_EXCEL_REP during construction of the server-side file path for the CSV output.

#### WEBUTIL.GET_LINE

WebUtil package function that reads a line from a server-side file. Called from VIEW_EXCEL_REP to read the URL base path from a configuration file, which is then combined with the generated filename to produce the URL passed to `WEB.SHOW_DOCUMENT`.

#### WEBUTIL.ID_NULL

WebUtil package function from the WEBUTIL_C_API library. Signature: `Function(handle IN Pointer) RETURN BOOLEAN`. Called from VIEW_EXCEL_REP to test whether the DataRecordSet record group handle is null (i.e., the record group does not yet exist) before deciding whether to delete and recreate it. Returns TRUE if the handle is null.

#### WEBUTIL.PUT_LINE

WebUtil package procedure that writes a single line of text to an open server-side file. Called from VIEW_EXCEL_REP in a loop over the record group rows to write each delimited CSV line to the output file.

#### WEBUTIL.SETPROPERTY

WebUtil package procedure that sets a named WebUtil configuration property value. Called from VIEW_EXCEL_REP during initialisation of the export pipeline to configure WebUtil properties required for the file transfer operation.

## 13. Package Procedure Specifications

*NO PCK files found - no ``*.pck`` source files were discovered in ``/app/section-rewrite-pipeline/workspaces/a8fa6b4f-d2b5-4702-80c7-ba5d1c2b2339/inputs/form_sources``. Package specifications cannot be generated without uploaded PCK sources.*

## 14. Database Package Catalogue

*NO PCK files found - no `*.pck` source files were discovered in the form sources input directory. The database package catalogue cannot be generated without uploaded PCK sources.*

## 15. PLD Procedure Call Sites

*Maps each program-library routine to its call sites within triggers and program units. Behaviour descriptions are derived from the uploaded ``.pld`` sources.*

### DPL.pld (`general`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ASK_CONFIRM | Function | Function(confirm_msg VARCHAR2) RETURN NUMBER | Trigger: FT_CANCEL in Form, Trigger: FT_DEL in Form | Displays a confirmation dialog presenting the supplied message and returns a numeric code indicating the user's choice. Called in the FT_CANCEL and FT_DEL form-level triggers to ask the user to confirm a cancellation or deletion action before the operation proceeds. |
| CHECK_NULL | Procedure | Procedure(p_value IN VARCHAR2, column_title IN VARCHAR2) | Trigger: WHEN-VALIDATE-ITEM in CB_BLK.CATG, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.CONSG_CD, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.FROM_DATE, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.IND_NATURE, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.LOC_CD, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.PARENT_GROUP, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.REPORT_TYPE, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.SO_LOC_CD, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.TO_DATE | Validates that p_value is not null. If null, calls GENERAL.DISP_TEXT with message "Enter a valid {column_title}" and raises FORM_TRIGGER_FAILURE. Used on nine mandatory filter fields to enforce required-field rules before the report can be generated. |
| DISP_TEXT | Procedure | Procedure(text_string VARCHAR2, title_string VARCHAR2) | Trigger: FT_INSERT in Form, Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: WHEN-BUTTON-PRESSED in CB_BLK.PB_REPORT, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.FROM_DATE, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.TO_DATE | Displays a modal alert dialog (AL_ERRINFO for Error title, AL_NOTE otherwise) with the supplied message text and title. Used for field validation messages, button pre-condition errors, system error/message interception, and insert-operation feedback in the FT_INSERT trigger. |
| RAISE_ERROR | Procedure | Procedure(mesg_code IN VARCHAR2) | Trigger: ON-ERROR in Form | Looks up an error message by code (formerly via GENERAL.GET_MESSAGE), prepends the code to the message text, and calls DISP_TEXT. Raises FORM_TRIGGER_FAILURE for error-type messages; displays a dialog for note and caution types. |

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``pe_child_indent_tracking_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| L_POPULATE | Procedure | Procedure(P_LIST_NAME VARCHAR2,P_LIST_FIELD VARCHAR2) | ProgramUnit: L_POPULATE | **COMMENTED OUT / INACTIVE** - Referenced only within the inactive L_POPULATE program unit. Formerly used to populate a list item by name, passing the list item name and the associated field name; not executed in the active form. |

**Total Active Routines:** 4 of 24 in DPL.pld source
**Inactive / commented-only routines:** 1

---

### webutil.pld (`WEBUTIL_C_API`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ID_NULL | Function | Function(handle IN Pointer) RETURN BOOLEAN | ProgramUnit: VIEW_EXCEL_REP | Tests whether a Forms object handle (such as a RecordGroup ID) is null. Called in VIEW_EXCEL_REP to check whether the DataRecordSet record group already exists before attempting to delete it. Returns TRUE if the handle is null (object does not exist). |

**Total Active Routines:** 1 of 28 in webutil.pld source

---

### webutil.pld (`WEBUTIL_FILE`)

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``pe_child_indent_tracking_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| FILE_SAVE_DIALOG | Function | Function(directory_name Varchar2 := NULL, file_name Varchar2 := NULL, file_filter Varchar2 := NULL, title Varchar2 := NULL) RETURN Varchar2 | ProgramUnit: VIEW_EXCEL_REP | **COMMENTED OUT / INACTIVE** - Referenced only in the commented-out section of VIEW_EXCEL_REP. Formerly used to present the client-side Save dialog, allowing the user to choose a destination path and filename for the exported Excel file; not executed in the active form. |

**Total Active Routines:** 0 of 25 in webutil.pld source
**Inactive / commented-only routines:** 1

---

### webutil.pld (`WEBUTIL_FILE_TRANSFER`)

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``pe_child_indent_tracking_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| URL_To_Client | Function | Function(sourceURL in VARCHAR2, clientDestination in VARCHAR2, fileSize in PLS_INTEGER default 0) RETURN BOOLEAN | ProgramUnit: VIEW_EXCEL_REP | **COMMENTED OUT / INACTIVE** - Referenced only in the commented-out section of VIEW_EXCEL_REP. Formerly used to transfer a file from a server-side URL to a specified client-side destination path, returning TRUE on success; not executed in the active form. |

**Total Active Routines:** 0 of 21 in webutil.pld source
**Inactive / commented-only routines:** 1

---

### webutil.pld (`WEBUTIL_HOST`)

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``pe_child_indent_tracking_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| Host | Function | Function(cmd in VARCHAR2) RETURN PLS_INTEGER | ProgramUnit: VIEW_EXCEL_REP | **COMMENTED OUT / INACTIVE** - Referenced only in the commented-out section of VIEW_EXCEL_REP. Formerly used to execute an operating-system shell command on the server and return a status code; not executed in the active form. |

**Total Active Routines:** 0 of 14 in webutil.pld source
**Inactive / commented-only routines:** 1

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| ID | Service Name | Database Object | Input Parameters | Output | Business Function | API Endpoint Suggestion |
| -- | ------------ | --------------- | ---------------- | ------ | ----------------- | ----------------------- |
| MS-001 | Dealer Location Initialisation Service | AM_DEALER_LOC | parent_group, dealer_map_cd, loc_cd, principal_map_cd | spares_stockyard_flag, consg_cd, dealer_name, loc_desc | Determines whether the current session's dealer location is a spares stockyard and returns the default consignee, dealer name, and location description for pre-populating the report filter screen | GET /dealer-locations/session-defaults |
| MS-002 | Consignee Lookup Service | AM_CONSIGNEE, AM_DEALER_LOC | parent_group, principal_map_cd | List of consignee codes, dealer names, and sort order (including ALL CONSIGNEES option) | Provides the list of valid consignees for a given principal and parent group, filtered to active dealership categories | GET /consignees?parentGroup={}&principal={} |
| MS-003 | Location Lookup Service | AM_DEALER_LOC | parent_group, consg_cd, principal_map_cd | List of location codes, descriptions, parent groups, dealer map codes (including ALL LOCATIONS option) | Provides the list of valid buying locations for a given principal, parent group, and consignee, filtered to active (non-terminated) locations | GET /locations?parentGroup={}&principal={}&consigneeCode={} |
| MS-004 | Seller Location Lookup Service | AM_DEALER_LOC | parent_group, consg_cd, principal_map_cd | List of seller location codes, descriptions, parent groups, dealer map codes (spares stockyard locations only, including ALL LOCATIONS option) | Provides the list of valid spares-stockyard selling locations for a given principal, parent group, and consignee | GET /seller-locations?parentGroup={}&principal={}&consigneeCode={} |
| MS-005 | Child Indent Tracking Detail Export Service | PT_IDT_TRACKING, PT_IDT_REP_INTER | parent_group, consg_cd, loc_cd, so_loc_cd, from_date, to_date, catg, ind_nature, is_stockyard_user | CSV file or row set of full line-level indent tracking records | Retrieves line-level child indent tracking records matching the filter criteria and returns them for CSV download; for non-stockyard users stages data via the interim table | GET /child-indent-tracking/detail-export |
| MS-006 | Child Indent Tracking Summary Export Service | PT_IDT_TRACKING, AM_DEALER_LOC | parent_group, consg_cd, loc_cd, so_loc_cd, from_date, to_date, catg, ind_nature | CSV file or row set of aggregated indent totals grouped by consignee, location, indent nature, and part category | Retrieves header-level (aggregated) child indent tracking data grouped by key dimensions, joining dealer location to verify seller spares stockyard status | GET /child-indent-tracking/summary-export |
| MS-007 | Copyright Declaration Service | SF_COPYRIGHT_DECLARATION | (none) | Copyright declaration text string | Returns the standard copyright declaration text for display on the form | GET /copyright-declaration |

**Total Microservices Identified: 7**

---

## 17. Workflows

| ID | Workflow Name | Trigger Event | Steps | Decision Points | End State |
| -- | ------------- | ------------- | ----- | --------------- | --------- |
| WF-001 | Form Session Registration | PRE-FORM trigger fires when the form is opened | 1. Register form module name and action in the database session using application info calls | None | Database session tagged with form module name for monitoring |
| WF-002 | Report Filter Screen Initialisation | WHEN-NEW-BLOCK-INSTANCE trigger fires when the form block receives focus | 1. Query dealer location master for session's dealer-location record to determine stockyard status and retrieve default consignee, dealer name, and location description. 2. If query fails (any exception), apply no defaults and continue. 3. If location is a spares stockyard: pre-fill Consignee with "ALL" / Dealer Name with "ALL CONSIGNEES" / Location with "ALL" / Location Description with "ALL LOCATIONS"; if Report Type is already Summary, disable the Location field; navigate cursor to the Consignee field. 4. If location is not a spares stockyard: pre-fill Consignee and Dealer Name from query result; pre-fill Location and Location Description from query result; disable Consignee and Location fields; navigate cursor to the Generate Report button. 5. Pre-fill Seller Location with "ALL" / Seller Location Description with "ALL Locations". 6. Set From Date default to 30 days before today; set To Date default to today. 7. Populate Copyright Declaration field by calling the copyright declaration function. | Is the session location a spares stockyard? -> Yes: pre-fill ALL and leave consignee/location selectable. No: pre-fill with session values and disable consignee and location. | Report filter screen fully initialised with default values; cursor positioned ready for user input |
| WF-003 | Consignee Validation | WHEN-VALIDATE-ITEM trigger fires on Consignee field when user leaves it | 1. If Consignee is blank, call mandatory field check which raises an error and prevents the user from leaving the field | Is Consignee blank? -> Yes: display error and block navigation. No: continue. | Consignee field accepted and focus moves to next field |
| WF-004 | Tab Navigation from Consignee | KEY-NEXT-ITEM trigger fires on Consignee field when user presses Tab or navigates away | 1. If session is a spares stockyard: navigate cursor to the Location field. 2. Otherwise: navigate cursor to the From Date field. | Is the session a spares stockyard? -> Yes: go to Location. No: go to From Date. | Cursor positioned on the correct next field based on user type |
| WF-005 | Consignee Lookup Navigation from Parent Group Display | KEY-NEXT-ITEM trigger fires on Consignee display (PARENT_GROUP item) when user navigates away | 1. If Consignee is "ALL": navigate cursor to From Date field. 2. Otherwise: enable Location and Location Description fields; navigate cursor to Location field. | Is Consignee "ALL"? -> Yes: skip Location. No: enable and navigate to Location. | Cursor positioned on next appropriate field; Location field enabled when needed |
| WF-006 | Location Validation | WHEN-VALIDATE-ITEM trigger fires on Location field when user leaves it | 1. If Location is blank, call mandatory field check which raises an error and prevents the user from leaving the field | Is Location blank? -> Yes: display error and block navigation. No: continue. | Location field accepted and focus moves to next field |
| WF-007 | From Date Validation | WHEN-VALIDATE-ITEM trigger fires on From Date field when user leaves it | 1. If From Date is blank, call mandatory field check which raises an error. 2. If From Date is later than today, display *"From Date cannot be greater than current date"* and raise a form trigger failure. 3. If From Date equals exactly 180 days before today, automatically set To Date to From Date plus 180 days. | Is From Date blank? Is From Date a future date? Is From Date exactly 180 days before today? | From Date validated; To Date auto-adjusted if the 180-day boundary condition applies |
| WF-008 | To Date Validation | WHEN-VALIDATE-ITEM trigger fires on To Date field when user leaves it | 1. If To Date is blank, call mandatory field check which raises an error. 2. If To Date is later than today, display *"To Date cannot be greater than current date"* and raise a form trigger failure. 3. If To Date is earlier than From Date, display *"To Date cannot be older than From Date"* and raise a form trigger failure. 4. If the range between From Date and To Date exceeds 30 days, display *"Date range cannot be greater than 30 days!"*, clear To Date, and return focus to the To Date field. | Is To Date blank? Is To Date a future date? Is To Date before From Date? Does the range exceed 30 days? | To Date validated and accepted, or user must correct the value |
| WF-009 | Report Type Validation | WHEN-VALIDATE-ITEM trigger fires on Report Type field when user leaves it | 1. If Report Type is blank, call mandatory field check which raises an error | Is Report Type blank? -> Yes: display error and block navigation. | Report Type field accepted |
| WF-010 | Report Type Change - Field Layout Adjustment | WHEN-LIST-CHANGED trigger fires on Report Type field when user changes the selection | 1. If spares stockyard and Report Type is Summary (H): disable Location and Location Description; enable Seller Location and Seller Location Description. 2. If spares stockyard and Report Type is Detail (D): set Seller Location to "ALL" / Seller Location Description to "ALL Locations"; enable Location and Location Description; disable Seller Location and Seller Location Description. 3. If not spares stockyard and Report Type is Detail (D): set Seller Location to "ALL" / Seller Location Description to "ALL Locations"; disable Seller Location and Seller Location Description. 4. If not spares stockyard and Report Type is Summary (H): set Seller Location to "ALL" / Seller Location Description to "ALL Locations"; enable Seller Location and Seller Location Description. | Is the session a spares stockyard? What report type was selected? | Screen layout updated: Location and Seller Location fields enabled or disabled to match the selected report type and user type |
| WF-011 | Part Category Validation | WHEN-VALIDATE-ITEM trigger fires on Part Category field when user leaves it | 1. If Report Type is blank (used as a proxy check), call mandatory field check which raises an error | Is Report Type blank? -> Yes: display error. | Part Category field navigation accepted |
| WF-012 | Indent Nature Validation | WHEN-VALIDATE-ITEM trigger fires on Indent Nature field when user leaves it | 1. If Report Type is blank (used as a proxy check), call mandatory field check which raises an error | Is Report Type blank? -> Yes: display error. | Indent Nature field navigation accepted |
| WF-013 | Seller Location Validation | WHEN-VALIDATE-ITEM trigger fires on Seller Location field when user leaves it | 1. If Location is blank (used as a proxy check), call mandatory field check which raises an error | Is Location blank? -> Yes: display error. | Seller Location field navigation accepted |
| WF-014 | Generate Report - Detail or Summary CSV Export | WHEN-BUTTON-PRESSED trigger fires on Generate Report button | 1. Validate Consignee is not blank; if blank, display *"Consignee must be selected"* and return focus to Consignee. 2. Validate Location is not blank; if blank, display *"Location must be selected"* and return focus to Location. 3. Validate From Date is not more than 180 days in the past; if so, display *"From Date cannot be generated more than 180 days back"* and return focus to From Date. 4. Validate the date range does not exceed 30 days; if so, display *"Data can be generated for maximum 30 days"* and return focus to To Date. 5. Construct a timestamped CSV filename from the user ID and current date-time. 6. If Report Type is Detail and location is not a spares stockyard: delete current user's data from the interim staging table, insert matching records from the tracking table into the staging table (commit), build the CSV query from the staging table. 7. If Report Type is Detail and location is a spares stockyard: build the CSV query directly from the tracking table. 8. If Report Type is Summary: build the CSV query from an aggregated summary of the tracking table joined to the dealer location master. 9. Store the query string in a hidden control field. 10. Call VIEW_EXCEL_REP to execute the query, write the CSV file to the server, and open it in the browser. | Report Type = Detail or Summary? Is session a spares stockyard? Are all mandatory fields filled and within date constraints? | CSV file generated and opened in the user's browser for download |
| WF-015 | Form-Level Error Handling | ON-ERROR trigger fires whenever a form error occurs | 1. If error code is 50004 (invalid date), display *"Entered Date is not valid Date"* and raise a form trigger failure. 2. If error code is 50025 or 50026 (wrong date format), display *"Enter the Date in the proper format (DD-MM-YYYY)"* and raise a form trigger failure. 3. If error code is 40209 or 50016 (non-numeric value in numeric field), display *"Characters/Special Characters are not allowed here, enter the numeric value"* and raise a form trigger failure. 4. If error code is 40207 (field-level error), display the error text from the error and raise a form trigger failure. 5. If database error code is -02292 (integrity constraint violation), call GENERAL.RAISE_ERROR with code E0088. 6. If error code is a concurrent update conflict (40654-40659), display *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*, roll back, and raise a form trigger failure. 7. If SQL code is non-zero (other database error), display the database error message text (SQLERRM), roll back, and raise a form trigger failure. 8. If error code is 40401 or 40405 (no records found / record navigation), take no action (null handler). | Which error code class was raised? | Error communicated to the user with an appropriate message; form stays open on trigger failure; rollback applied for data integrity errors |
| WF-016 | Form-Level Message Handling | ON-MESSAGE trigger fires when an informational form message is raised | 1. If message code is 40209 or 40207, display the combined error-type, code, and error text as an error message and raise a form trigger failure | Which message code was raised? | Message handled and form trigger failure raised for codes 40209 and 40207; other messages pass through normally |
| WF-017 | LOV Selection and Field Navigation | KEY-LISTVAL trigger fires when the user presses the list key on any LOV-linked field | 1. Retrieve the LOV name associated with the current field. 2. If the field has an LOV, display the LOV at position (390, 120); if the user selects a value, advance the cursor to the next field. | Does the current field have an associated LOV? Did the user select a value? | LOV value selected and cursor advanced, or LOV closed with no change |
| WF-018 | Form Exit and Session Cleanup | KEY-EXIT trigger fires when the user exits the form | 1. Exit the form without saving (no validation). 2. Clear the client info from the database session. 3. Clear the module and action from the database session. | None | Form closed; database session application info cleared |
| WF-019 | Screen Clear | KEY-CLRFRM trigger fires when the user requests a form clear | 1. Clear Consignee, Consignee Description, Location, Location Description, and From Date fields to null. | None | Filter fields cleared; user can re-enter criteria |

**Total Workflows Identified: 19**

---

## 18. PLD-Backed Logic

*Maps shared library routines to their business function and suggested API contracts.*

### webutil.pld (`CLIENT_IMAGE`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | ID_NULL | Business Logic | ProgramUnit: VIEW_EXCEL_REP | /api/v1/pld/id_null | When a record group handle is checked, returns whether the handle is null so the caller can safely delete or skip creating the group |
| PLD-002 | length | Business Logic | ProgramUnit: POP_LIST | /api/v1/pld/length | **COMMENTED OUT / INACTIVE** - Formerly returned the length of a Java object string; not executed in the active form |


---

### DPL.pld (`general`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | CHECK_NULL | Validation | Trigger: WHEN-VALIDATE-ITEM in CB_BLK.CATG, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.CONSG_CD, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.FROM_DATE, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.IND_NATURE, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.LOC_CD, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.PARENT_GROUP, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.REPORT_TYPE, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.SO_LOC_CD, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.TO_DATE | /api/v1/pld/check_null | When a mandatory filter field is empty, then navigation is halted and an error message prompting valid entry is displayed |
| PLD-002 | DISP_TEXT | Business Logic | Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: WHEN-BUTTON-PRESSED in CB_BLK.PB_REPORT, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.FROM_DATE, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.TO_DATE | /api/v1/pld/disp_text | When a message or error condition occurs, then a modal alert dialog displaying the supplied text and title is shown to the user |
| PLD-003 | RAISE_ERROR | Validation | Trigger: ON-ERROR in Form | /api/v1/pld/raise_error | When a known error code is raised, then the corresponding message is displayed and form trigger failure is raised for error-type messages |


---

### D2kwutil.pld (`Win_API`)

*No routines from ``D2kwutil.pld`` are referenced in ``pe_child_indent_tracking_fmb.xml``.*

---

---

## 19. PCK-Backed Logic

*NO PCK files found - no ``*.pck`` source files were discovered in ``/app/workspace/pe_child_indent_tracking-17f2adb95376/in``. PCK-backed logic cannot be generated without uploaded PCK sources.*

---

## 20. System Interfaces

### 20.1 Database Integrations

| Interface Name | Type | Purpose | Data Flow | Error Handling |
| -------------- | ---- | ------- | --------- | -------------- |
| Dealer Location Master (AM_DEALER_LOC) | Oracle Database Table - SELECT | Determines the session's dealer location type (spares stockyard or standard) and retrieves the default consignee, dealer name, and location description for screen initialisation; also joined in the Summary report query to verify seller location spares stockyard status | Form -> Database (read at block initialisation and in Summary report query) | WHEN-NEW-BLOCK-INSTANCE wraps the initialisation query in an inner BEGIN/EXCEPTION WHEN OTHERS THEN NULL block; any query failure is silently ignored and no defaults are loaded |
| Consignee Master (AM_CONSIGNEE) | Oracle Database Table - SELECT (via record group query) | Provides the list of valid consignees for the current principal and parent group for the consignee lookup | Database -> Form (read when the consignee LOV is populated) | No explicit error handler; record group query failure would result in an empty LOV |
| Child Indent Tracking Table (PT_IDT_TRACKING) | Oracle Database Table - SELECT | Source of all indent tracking records for both the Detail and Summary report exports; queried inside the dynamically built CSV export query | Database -> Form (read when the report is generated) | Any query exception during report generation in VIEW_EXCEL_REP is caught by WHEN OTHERS, which displays the Oracle error code and error text concatenated (*"Error  -"* prefix) and raises a form trigger failure |
| Interim Report Staging Table (PT_IDT_REP_INTER) | Oracle Database Table - DELETE and INSERT | Staging table used to isolate per-user report data for non-spares-stockyard Detail report runs; user's previous rows are deleted, then new rows are inserted from PT_IDT_TRACKING | Form -> Database (write at report generation: delete then insert then commit) | WHEN-BUTTON-PRESSED wraps the staging DML in a BEGIN/EXCEPTION WHEN OTHERS THEN NULL block; any failure in the staging step is silently ignored and the report query falls back to reading PT_IDT_TRACKING directly |

### 20.2 External System Integrations

| System Name | Integration Type | Purpose | Protocol | Endpoint | Data Exchange | Success / Error Codes |
| ----------- | ---------------- | ------- | -------- | -------- | ------------- | --------------------- |
| Oracle Application Server / Reports Printer Directory | File System / Web URL | Hosts the generated CSV file so the user can download it via the browser; the server-side path is read from a configuration file, and the file URL is opened via WEB.SHOW_DOCUMENT | HTTP (browser redirect via WEB.SHOW_DOCUMENT) | URL base path read from `/reports/DMS/excelpath.txt` on the application server; full URL = configured base + filename | Form writes CSV rows to `/iashome/ias/reports/printer/` on the application server using TEXT_IO.FOPEN/TEXT_IO.PUT_LINE; WEB.SHOW_DOCUMENT opens the constructed URL in a new browser tab | Success: CSV file opens in browser. Failure: any TEXT_IO or WEB exception displays *"Error  -"* concatenated with the Oracle error code and error text, then raises a form trigger failure |

### 20.3 Report Integrations

| Report Name | Report Server | Parameters | Output Format | Trigger |
| ----------- | ------------- | ---------- | ------------- | ------- |
| rep.rdf | INFERRED - application report server | Consignee (`CONSG_CD`), Location (`LOC_CD`), Seller Location (`SO_LOC_CD`), From Date (`FROM_DATE`), To Date (`TO_DATE`), Report Type (`REPORT_TYPE`), Part Category (`CATG`), Indent Nature (`IND_NATURE`), User ID (from global) - INFERRED | CSV (comma-separated values file) - INFERRED | Not invoked from active code - declarative report object registered in form XML (xml_report_object source); no active trigger or program unit calls this report filename |

---

### 20.3.1 Parameters Passed to the Report

This form does not pass parameters to an Oracle Report. No report parameters were identified in the form sources.

## 21. Procedure and Function Business Rule Catalogue

End-to-end business requirement specification for every stored procedure and function referenced by the PE_CHILD_INDENT_TRACKING form.

### 21.1 Catalogue Index

15 procedures/functions - each SP ID links to its detailed specification in Section 21.2.

| SP Index | Routine Name |
| :--- | :--- |
| [SP-001](#SP-001--VIEW_EXCEL_REP) | VIEW_EXCEL_REP |
| [SP-002](#SP-002--GENERAL.ASK_CONFIRM) | GENERAL.ASK_CONFIRM |
| [SP-003](#SP-003--GENERAL.CHECK_NULL) | GENERAL.CHECK_NULL |
| [SP-004](#SP-004--GENERAL.DISP_TEXT) | GENERAL.DISP_TEXT |
| [SP-005](#SP-005--GENERAL.RAISE_ERROR) | GENERAL.RAISE_ERROR |
| [SP-006](#SP-006--WEBUTIL.ERRORALERT) | WEBUTIL.ERRORALERT |
| [SP-007](#SP-007--WEBUTIL.FCLOSE) | WEBUTIL.FCLOSE |
| [SP-008](#SP-008--WEBUTIL.FOPEN) | WEBUTIL.FOPEN |
| [SP-009](#SP-009--WEBUTIL.GETIMPLCLASS) | WEBUTIL.GETIMPLCLASS |
| [SP-010](#SP-010--WEBUTIL.GETPROPERTY) | WEBUTIL.GETPROPERTY |
| [SP-011](#SP-011--WEBUTIL.GET_LINE) | WEBUTIL.GET_LINE |
| [SP-012](#SP-012--WEBUTIL.ID_NULL) | WEBUTIL.ID_NULL |
| [SP-013](#SP-013--WEBUTIL.PUT_LINE) | WEBUTIL.PUT_LINE |
| [SP-014](#SP-014--WEBUTIL.SETPROPERTY) | WEBUTIL.SETPROPERTY |
| [SP-015](#SP-015--SF_COPYRIGHT_DECLARATION) | SF_COPYRIGHT_DECLARATION |

---

### 21.2 Detailed Specifications

#### SP-001 - VIEW_EXCEL_REP

**Invoked From:**

- pe_child_indent_tracking_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

N/A

---

**Purpose**

Generates a comma-separated values (CSV) report file from a supplied data query, writes it to the application server, and opens the resulting file in the user's browser for download. The procedure builds a timestamped filename from the logged-in user's identifier, executes the provided query into a temporary record group, writes each result row as a CSV line to the server directory, and then launches the file in a new browser window. Output is limited to 65,535 rows.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_file_name | VARCHAR2 | IN |
| p_query | VARCHAR2 | IN |
| p_column_name | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.FCLOSE ([SP-007](#SP-007--WEBUTIL.FCLOSE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.FOPEN ([SP-008](#SP-008--WEBUTIL.FOPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_LINE ([SP-011](#SP-011--WEBUTIL.GET_LINE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ID_NULL ([SP-012](#SP-012--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.PUT_LINE ([SP-013](#SP-013--WEBUTIL.PUT_LINE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Retrieve the logged-in user identifier and construct a timestamped filename in the format UserID + date-time + .csv.
- Step 2 - Check whether the constructed filename contains a space in the folder path. If so, redirect the file to the C:\ root drive and notify the user that the file will be stored there instead.
- Step 3 - Check whether a record group named DataRecordSet already exists. If it does, delete it to ensure a clean working area.
- Step 4 - Create a new record group from the supplied query and populate it with the query results.
- Step 5 - Count the rows in the populated record group. If the row count exceeds 65,536, inform the user that the output will be truncated to 65,535 rows and cap the count at 65,535.
- Step 6 - Determine the full server-side file path by reading the configured export base URL from the server configuration file located at /reports/DMS/excelpath.txt.
- Step 7 - Open the output file on the server in write mode.
- Step 8 - Iterate through each row in the record group, retrieve the column value for the specified column name, and write it as a line to the output file.
- Step 9 - Close the output file.
- Step 10 - Construct the full public URL for the file and open it in a new browser window for the user to download.
- Step 11 - If any error occurs during the above steps, display the error code and error text to the user and raise a form trigger failure to stop processing.

---
**Decision Points**

DP-001

Condition: Does the generated filename contain a space character in the folder path?

TRUE: Redirect the file to the C:\ root drive and display "File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default." then continue with the adjusted filename.

FALSE: Use the filename as constructed without modification.

---

DP-002

Condition: Does the DataRecordSet record group already exist?

TRUE: Delete the existing record group before creating a new one.

FALSE: Proceed directly to creating the record group from the query.

---

DP-003

Condition: Does the number of rows in the query result exceed 65,536?

TRUE: Display "Maximum number of rows in excel exceeded. It will truncate to 65535 rows." and limit processing to 65,535 rows.

FALSE: Process all rows returned by the query.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The output CSV filename is built from the logged-in user's identifier combined with the current date and time, ensuring each export has a unique name that identifies who generated it and when.
- BR-002 - If the destination path contains spaces, the file is automatically redirected to the C:\ root to prevent file system errors, and the user is informed of this change.
- BR-003 - The export is capped at 65,535 rows to ensure the output can be opened in older versions of Microsoft Excel without exceeding the maximum row limit.
- BR-004 - The server-side export path is read dynamically from a server configuration file (/reports/DMS/excelpath.txt) rather than being hard-coded, allowing the export location to be configured without changing the form.
- BR-005 - Any error during file creation, writing, or browser launch is caught and reported to the user with the Oracle error code and message, and processing is halted to prevent a partial or corrupted export.

---
**Implementation Logic**

```plsql
PROCEDURE view_excel_rep(p_file_name VARCHAR2 DEFAULT NULL, p_query VARCHAR2,p_column_name VARCHAR2) IS	
  rg_name 				 		VARCHAR2(40) := 'DataRecordSet'; 
	rg_id 					 		RecordGroup; 
	gc_id 					 		GroupColumn; 
	urlFile1        TEXT_IO.FILE_TYPE;
	the_rowcount 		 		NUMBER;
	po_tot_rec    NUMBER (6);
	--po_part_tab   pk_part_search_new.part_tab_10;
	po_part_tab   pk_part_search_new.part_tab_11;
	po_err_msg    VARCHAR2 (3000);
	po_err_cd     NUMBER (10);
	low           NUMBER (10);
	high          NUMBER (10);
	remainder     NUMBER (10);
	order_by      VARCHAR2 (300);
	vcfile        varchar2(150);
	lv_user       varchar2(150);
	l_Old_URL     varchar2(500);	
		l_new_URL   varchar2(500);	
	v_string      varchar2(5000);
	bin_str       varchar2(250);
	errcode 				 		NUMBER; 
  FILENAME			   		VARCHAR2(4000);
  MYFILE 					 		TEXT_IO.FILE_TYPE;
  urlFile 					 	TEXT_IO.FILE_TYPE;
  urlPath							VARCHAR2(5000);
	l_alert 				 		NUMBER;
	server_file      		VARCHAR2(2000);
	file_transfer_bool	BOOLEAN;
	formserverpath   		VARCHAR2(2000);
begin
lv_user := name_in(':global.userid');  -- New line added after dpl change
vcFile:= lv_user||To_Char(Sysdate,'YYYYMMDDHHMISS');    -- New line added after dpl change
vcFile := vcFile||'.csv';
if vcFile is null then
	--FILENAME  := Webutil_file.FILE_SAVE_DIALOG;
	null;
else
	filename:=vcFile;
end if;
	If instr(FILENAME,' ') > 0 then
 		FILENAME := 'C:\'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
 		Message('File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default.');
 		message('  ');
	end if;
	
	rg_id := Find_Group( rg_name ); 
	IF NOT Id_Null(rg_id) THEN 
		Delete_Group( rg_id ); 
	END IF; 
	rg_id := Create_Group_From_Query( rg_name, p_query ); 
	errcode := Populate_Group( rg_id ); 
	the_rowcount := Get_Group_Row_Count( rg_id );
	IF the_rowcount > 65536 THEN  
		Message('Maximum number of rows in excel exceeded. It will truncate to 65535 rows.');
		Message('  ');
		CLEAR_MESSAGE;
		the_rowcount := 65535;
	END IF;

	server_file := '/iashome/ias/reports/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	--formserverpath := 'http://10.100.34.230:7778/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	urlFile := Text_Io.Fopen('/reports/DMS/excelpath.txt','R');
	Text_Io.Get_Line(urlFile,urlPath);
	Text_Io.Fclose(urlFile);
	formserverpath := urlPath||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	MYFILE := TEXT_IO.FOPEN(server_file, 'W');
	gc_id := Find_Column( rg_name||'.'||p_column_name); 	
	for total_loop IN 1..the_rowcount
		loop
	  	V_STRING :=  GET_GROUP_CHAR_CELL(gc_id  , total_loop ); 
	  	text_io.put_line(myfile,v_string);
	  	--TEXT_IO.PUTF(MYFILE,V_STRING);  
		end loop;
      text_io.fclose(myfile);
   
	 --	file_transfer_bool := WebUtil_File_Transfer.Url_To_Client(formserverpath,FILENAME);
	/* 	if not file_transfer_bool  then 
	 		message('File Transfer failed');pause;
	 	end if;
	 	WebUtil_Host.HOST('cmd /c '||FILENAME);*/
	 	
	 	web.show_document(formserverpath,'_blank');
	exception
		when others then
		Message('Error  - '||ERROR_CODE|| ERROR_TEXT);
		Raise Form_trigger_failure;
	end;
```

#### SP-002 - GENERAL.ASK_CONFIRM

**Invoked From:**

- pe_child_indent_tracking_fmb.xml [Trigger: FT_CANCEL]
- pe_child_indent_tracking_fmb.xml [Trigger: FT_DEL]

---

**Screen:**

N/A

---

**Purpose**

ASK_CONFIRM is a reusable confirmation-dialog function that presents a configurable alert message to the user and returns a numeric flag indicating which button was pressed. It is invoked by the Cancel and Delete triggers on the Child Indent Tracking form to obtain explicit user confirmation before allowing a potentially destructive action to proceed.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| confirm_msg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the caller-supplied confirmation message text via the confirm_msg input parameter.
- Step 2 - Set the message text of the named alert 'AL_CONFIRM' to the value of confirm_msg using SET_ALERT_PROPERTY.
- Step 3 - Display the 'AL_CONFIRM' alert to the user and capture the button pressed in the local variable p_albtn_pressed via SHOW_ALERT.
- Step 4 - Evaluate the captured button response: if the user pressed the first alert button (ALERT_BUTTON1), return 1 to indicate confirmation; otherwise return 0 to indicate cancellation or rejection.

---
**Decision Points**

DP-001

Condition:
p_albtn_pressed = ALERT_BUTTON1 (the user pressed the primary confirmation button on the AL_CONFIRM alert)

TRUE:
The function returns 1, signalling to the calling trigger that the user has confirmed the action.

FALSE:
The function returns 0, signalling to the calling trigger that the user has declined the action and it should not proceed.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The confirmation alert must always use the pre-defined alert object named 'AL_CONFIRM'; the message text is dynamically overwritten at runtime with the value supplied by the caller, allowing a single alert object to serve multiple confirmation scenarios.
- BR-002 - Only a response matching ALERT_BUTTON1 is treated as a positive confirmation; any other button response (e.g., a second or third button, or dismissal) is treated as a rejection, defaulting to the safe/non-destructive outcome.
- BR-003 - The function must return a numeric value (1 for confirmed, 0 for rejected) so that calling triggers can apply conditional logic based on the user's response before executing Cancel or Delete operations.

---
**Implementation Logic**

```plsql
FUNCTION ASK_CONFIRM( confirm_msg VARCHAR2)
                                      RETURN  NUMBER IS

    p_alert_name varchar2(10) := 'AL_CONFIRM' ;
    p_albtn_pressed number;
BEGIN
   set_alert_property(p_alert_name,alert_message_text,confirm_msg); 
   p_albtn_pressed := show_alert(p_alert_name);

   IF ( p_albtn_pressed = ALERT_BUTTON1 ) THEN
      return (1);
   ELSE
      return(0);
   END IF;
RETURN NULL; END;
```

#### SP-003 - GENERAL.CHECK_NULL

**Invoked From:**

- pe_child_indent_tracking_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

N/A

---

**Purpose**

Validates that a required field has been filled in before the user can move away from it. If the field is empty, the procedure displays an error message identifying the field by its business name and prevents the user from continuing until the value is provided.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_value | VARCHAR2 | IN |
| column_title | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-004](#SP-004--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the current value of the field and the field's display label.
- Step 2 - Check whether the field value is empty (null).
- Step 3 - If the value is null, compose an error message reading "Enter a valid {field label}" and display it in an error dialog. Then halt navigation so the user cannot leave the field without providing a value.
- Step 4 - If the value is not null, allow processing to continue normally.

---
**Decision Points**

DP-001

Condition: Is the supplied field value null (empty)?

TRUE: Display the message "Enter a valid {field label}" and raise a form trigger failure to prevent the user from leaving the field.

FALSE: No action taken; field value is valid and navigation continues.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A field marked as required must contain a value before the user is permitted to move to the next field; an empty required field blocks forward navigation with a descriptive error naming the specific field.

---
**Implementation Logic**

```plsql
PROCEDURE CHECK_NULL( P_value IN VARCHAR2, column_title  IN VARCHAR2) IS
mesg_text        varchar2(80) := 'Enter a valid '||column_title ;
BEGIN
   IF p_value IS null  THEN
      GENERAL.DISP_TEXT(mesg_text,'Error');
      raise form_trigger_failure;
   END IF;
END;
```

#### SP-004 - GENERAL.DISP_TEXT

**Invoked From:**

- DPL.pld [StoredProcedure: GENERAL.CHECK_NULL]
- DPL.pld [StoredProcedure: GENERAL.RAISE_ERROR]
- pe_child_indent_tracking_fmb.xml [Trigger: FT_INSERT]
- pe_child_indent_tracking_fmb.xml [Trigger: ON-ERROR]
- pe_child_indent_tracking_fmb.xml [Trigger: ON-MESSAGE]
- pe_child_indent_tracking_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]
- pe_child_indent_tracking_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

N/A

---

**Purpose**

Displays a modal message dialog to the user with a supplied message text and title. The dialog uses an error-style alert when the title indicates an error, and a general note-style alert for all other titles. This procedure is the standard message-display mechanism used across the form for validation errors, informational messages, and system notifications.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| text_string | VARCHAR2 | IN |
| title_string | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message text to display and the dialog title.
- Step 2 - Determine the appropriate alert style: if the title is "Error" (case-insensitive), select the error alert template; otherwise select the note alert template.
- Step 3 - Set the selected alert's title property to the supplied title.
- Step 4 - Set the selected alert's message body to the supplied message text.
- Step 5 - Display the alert dialog and wait for the user to dismiss it.

---
**Decision Points**

DP-001

Condition: Is the supplied title equal to "Error" (case-insensitive)?

TRUE: Use the error alert template (AL_ERRINFO) to display the message.

FALSE: Use the general note alert template (AL_NOTE) to display the message.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - All user-facing messages in the form are displayed through a consistent modal dialog, ensuring the user must acknowledge the message before continuing.
- BR-002 - The visual style of the dialog (error versus note) is determined by the title supplied by the caller, so error messages are displayed more prominently than informational messages.

---
**Implementation Logic**

```plsql
PROCEDURE DISP_TEXT (text_string VARCHAR2,
                     title_string VARCHAR2 ) IS 
   p_alert_name varchar2(10) := 'AL_ERRINFO' ; 
   p_alert_id number;
BEGIN
   if upper(title_string)='ERROR' then
      p_alert_name := 'AL_ERRINFO' ; 
   else
      p_alert_name := 'AL_NOTE' ; 
   end if;
   set_alert_property(p_alert_name,TITLE,title_string);  
   set_alert_property(p_alert_name,alert_message_text,text_string);  
   p_alert_id := show_alert(p_alert_name); 
END;
```

#### SP-005 - GENERAL.RAISE_ERROR

**Invoked From:**

- pe_child_indent_tracking_fmb.xml [Trigger: ON-ERROR]

---

**Screen:**

N/A

---

**Purpose**

Looks up an error message by its code, prepends the code to the message text, and displays the result to the user using the standard message dialog. For error-type messages, navigation is halted after display. For note and caution types, the message is shown without stopping processing. The active form implementation uses a commented-out message lookup (GENERAL.get_message is disabled) so the displayed text is the code value only followed by a separator.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| mesg_code | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-004](#SP-004--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the error message code.
- Step 2 - Note: the message lookup via GENERAL.get_message is commented out in the current implementation; the message text variable starts as empty.
- Step 3 - Compose the display text by concatenating the message code with " : " and the (empty) message text.
- Step 4 - Determine the message type: if the type code is "E" (Error), display the composed text in an error dialog and halt navigation.
- Step 5 - If the type code is "N" (Note), display the composed text in a note dialog without halting navigation.
- Step 6 - If the type code is "C" (Caution), display the composed text in a caution dialog without halting navigation.

---
**Decision Points**

DP-001

Condition: Is the message type "E" (Error)?

TRUE: Display the message in an error dialog via GENERAL.DISP_TEXT with title "Error" and raise a form trigger failure to halt navigation.

FALSE: Proceed to check the next message type.

---

DP-002

Condition: Is the message type "N" (Note)?

TRUE: Display the message in a note dialog via GENERAL.DISP_TEXT with title "Note" without halting navigation.

FALSE: Proceed to check the next message type.

---

DP-003

Condition: Is the message type "C" (Caution)?

TRUE: Display the message in a caution dialog via GENERAL.DISP_TEXT with title "Caution" without halting navigation.

FALSE: No message is displayed; processing continues.

---
**Database Interactions**

- DB-001 - Read AM_PERMISSIONS - Reads data from AM_PERMISSIONS for lookup or validation.
**Business Rules**

- BR-001 - Error-type messages always halt the user's current action after display, ensuring the user cannot proceed past an error condition without addressing it.
- BR-002 - Note and caution messages are shown for informational or advisory purposes without blocking the user's workflow.
- BR-003 - The message lookup routine (GENERAL.get_message) is currently commented out; the displayed text consists of the error code alone followed by a separator, as the text value is empty in the current implementation.

---
**Implementation Logic**

```plsql
PROCEDURE RAISE_ERROR ( mesg_code IN VARCHAR2 )IS
  mesg_type  varchar2(7); 
  mesg_text  varchar2(200) ;
  mesg_title varchar2(7);
  BEGIN
     -- murali 17.05.04 GENERAL.get_message(mesg_code,mesg_text,mesg_type );
     mesg_text:=mesg_code||' : '||mesg_text;		
     IF ( mesg_type = 'E' ) THEN
        mesg_title := 'Error' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
        raise FORM_TRIGGER_FAILURE;
     ELSIF ( mesg_type = 'N' ) THEN
        mesg_title := 'Note' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     ELSIF ( mesg_type = 'C' ) THEN
        mesg_title := 'Caution' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     END IF;
  END;     

/* PROCEDURE check_rights( 
pi_form_name in varchar2,
pi_user_id in number) IS
lv_x varchar2(1);
BEGIN
	
	begin
	SELECT substr(access_string, pi_user_id,1) 
	INTO   lv_x
	FROM   	am_permissions
	WHERE  form_name = pi_form_name
	AND SUBSTR(access_string,pi_user_id,1)='Y';
	exception 
		when no_data_found then
		  general.disp_text('You do not have the Permission to access this.','Error rr');
		  raise form_trigger_failure; 
		when too_many_rows then
		  general.disp_text('Many rows in USER_PERMISSIONS','Error ss');
		  raise form_trigger_failure;
		when others then
		       general.disp_text(sqlerrm,'Error mm');
		       raise form_trigger_failure;
	end;

	open_form(pi_form_name,activate,session);
END;
*/
```

#### SP-006 - WEBUTIL.ERRORALERT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Displays a WebUtil-specific error message to the user when a WebUtil component operation fails. If the WebUtil error alert object is available, the message is shown through the standard alert dialog. If the alert object is not available, the message is displayed using the Oracle Forms built-in message function. This procedure is used internally by WebUtil file operations to report failures to the user.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| errText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-012](#SP-012--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the error message text to display.
- Step 2 - Check whether the WebUtil error alert object is available (not null).
- Step 3 - If the alert object is available, set its message text to the supplied error text and display it to the user.
- Step 4 - If the alert object is not available (null), display the error message using the standard form message function prefixed with "WebUtil Error: ".

---
**Decision Points**

DP-001

Condition: Is the WebUtil error alert object available (handle is not null)?

TRUE: Set the alert message text and display the alert dialog to the user.

FALSE: Display the error using the Oracle Forms message function with a "WebUtil Error: " prefix.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - WebUtil component errors are always reported to the user, whether through the dedicated alert dialog or through the standard message mechanism, ensuring no error is silently swallowed.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ErrorAlert(errText in VARCHAR2) is
    -- currently used for throwing a BEAN_NOT_REGISTERED or bean not found error.
    ignore integer;
  begin
    if not ID_NULL(m_errorAlert) then 
      --SET_ALERT_PROPERTY(m_errorAlert,TITLE,'WebUtil Error'); -- title already set in alert property
      SET_ALERT_PROPERTY(m_errorAlert,ALERT_MESSAGE_TEXT,errText);
      ignore := SHOW_ALERT(m_errorAlert);
    else
      message('WebUtil Error'||': '||errText);
    end if;
  end ErrorAlert;
```

#### SP-007 - WEBUTIL.FCLOSE

**Invoked From:**

- pe_child_indent_tracking_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open file handle that was previously obtained through the WebUtil file handling component. The procedure instructs the WebUtil core layer to flush and close the file on the server via WEBUTIL.SETPROPERTY, then clears the handle to release the file resource. If the underlying WebUtil bean is unavailable or a property error occurs, WEBUTIL.ERRORALERT is called to surface a descriptive message and WEBUTIL.GETIMPLCLASS is used to identify the missing implementation class before raising a terminal tool error.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-006](#SP-006--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETIMPLCLASS ([SP-009](#SP-009--WEBUTIL.GETIMPLCLASS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETPROPERTY ([SP-014](#SP-014--WEBUTIL.SETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the file handle (file_type IN OUT parameter) identifying the file to be closed.
- Step 2 - Check whether the file handle is not null, indicating the file is currently open.
- Step 3 - If the handle is valid, invoke WEBUTIL.SETPROPERTY (WebUtil_Core.setProperty) with the WUF_PACKAGE constant and the WUF_TEXTIO_CLOSE action, passing the current handle value to instruct the WebUtil core layer to flush and close the file on the server.
- Step 4 - Clear the file handle to NULL to indicate the file resource has been released and the handle is no longer valid.
- Step 5 - If a BEAN_NOT_REGISTERED exception is raised, call WEBUTIL.ERRORALERT to display a descriptive message that includes the implementation class name retrieved via WEBUTIL.GETIMPLCLASS, informing the user that the required WebUtil bean was not found and that CLIENT_TEXT_IO.fclose will not work.
- Step 6 - After alerting, raise TOOL_ERR.TOOL_ERROR to propagate the failure to the calling procedure (VIEW_EXCEL_REP).
- Step 7 - If a PROPERTY_ERROR exception is raised instead, raise TOOL_ERR.TOOL_ERROR directly without an alert, signalling a lower-level property communication failure to the caller.

---
**Decision Points**

DP-001

Condition: Is the file handle not null (file is currently open)?

TRUE: Call WEBUTIL.SETPROPERTY to close the file on the server and set the handle to NULL.

FALSE: No action taken; the file is already closed or was never opened, and execution exits normally.

---

DP-002

Condition: Is the exception raised BEAN_NOT_REGISTERED?

TRUE: Call WEBUTIL.ERRORALERT with a message composed using WEBUTIL.GETIMPLCLASS to identify the missing bean, then raise TOOL_ERR.TOOL_ERROR.

FALSE: Evaluate whether the exception is PROPERTY_ERROR (see DP-003).

---

DP-003

Condition: Is the exception raised PROPERTY_ERROR?

TRUE: Raise TOOL_ERR.TOOL_ERROR immediately without displaying an alert.

FALSE: Exception is not handled by this procedure and propagates unmodified to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Every file opened through the WebUtil file handling component must be explicitly closed via this procedure to ensure all buffered data is flushed to the server file system and the file resource is released.
- BR-002 - The close operation is only attempted when the file handle is not null; a null handle is treated as an already-closed file and no server-side action is performed.
- BR-003 - If the WebUtil bean is not registered at the time of the close attempt, WEBUTIL.ERRORALERT must be invoked with the implementation class name (obtained via WEBUTIL.GETIMPLCLASS) to provide a meaningful diagnostic message before the error is escalated.
- BR-004 - Both BEAN_NOT_REGISTERED and PROPERTY_ERROR conditions must result in TOOL_ERR.TOOL_ERROR being raised so that the calling procedure (VIEW_EXCEL_REP) can detect and handle the file-close failure appropriately.

---
**Implementation Logic**

```plsql
 
  PROCEDURE fclose (file IN OUT file_type) is 
  BEGIN 
    if (file.handle IS NOT NULL) then 
      WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CLOSE',file.handle);        
      file.handle := NULL;
    end if;
 
 EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.fclose will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;
  END fclose;
```

#### SP-008 - WEBUTIL.FOPEN

**Invoked From:**

- pe_child_indent_tracking_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Opens a text file on the client for reading, writing, or appending via the WebUtil file handling component. Validates the access mode and file path before delegating to the WebUtil core layer, which communicates with the registered client-side bean. Uses WEBUTIL.GETPROPERTY to retrieve the file handle returned by the bean after the open operation. Returns a typed file handle that subsequent read and write operations use to reference the open file. Raises an error if the file mode is invalid, the file path is missing, the bean is not registered, or the open operation fails.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| spec | VARCHAR2 | IN |
| filemode | VARCHAR2 | IN |
| charSet | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETPROPERTY ([SP-010](#SP-010--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the server file path (spec), the file access mode (filemode), and an optional character set (charSet).
- Step 2 - Validate the file mode: it must be one of 'r' (read), 'w' (write), or 'a' (append) (case-insensitive). If the mode is invalid, raise TOOL_ERR.TOOL_ERROR immediately.
- Step 3 - Validate that the file path is not null or empty. If it is, raise TOOL_ERR.TOOL_ERROR immediately.
- Step 4 - Push the file path to the WebUtil core layer by setting the WUF_FILENAME property on the WUF_PACKAGE component.
- Step 5 - Push the file mode to the WebUtil core layer by setting the WUF_TEXTIO_FILEMODE property.
- Step 6 - Evaluate the charSet parameter: if null, set the WUF_TEXTIO_CHARSET property to the literal string '(null)'; otherwise set it to the supplied character set value.
- Step 7 - Invoke WEBUTIL.GETPROPERTY (via WebUtil_Core.getProperty) to retrieve the WUF_TEXTIO_OPEN property, which triggers the client-side bean to open the file and returns a numeric handle as a VARCHAR2 string.
- Step 8 - If the returned handle is null, empty, or equals '-1', raise TOOL_ERR.TOOL_ERROR to signal that the file could not be opened.
- Step 9 - Convert the returned string handle to a number, assign it to the file_type record's handle field, and return the populated file_type record to the caller.
- Step 10 - In the exception block, handle BEAN_NOT_REGISTERED by displaying an error alert identifying the missing bean class and then raising TOOL_ERR.TOOL_ERROR; propagate PROPERTY_ERROR, VALUE_ERROR (as TOOL_ERR.TOOL_ERROR), and TOOL_ERR.TOOL_ERROR directly to the caller.

---
**Decision Points**

DP-001

Condition: Is the file access mode (case-insensitive) one of 'r', 'w', or 'a'?

TRUE: Continue to file path validation.

FALSE: Raise TOOL_ERR.TOOL_ERROR to signal an invalid mode was supplied.

---

DP-002

Condition: Is the file path (spec) null or empty?

TRUE: Raise TOOL_ERR.TOOL_ERROR to signal a missing filename.

FALSE: Continue to setting WebUtil core properties.

---

DP-003

Condition: Is the charSet parameter null?

TRUE: Set the WUF_TEXTIO_CHARSET property to the literal '(null)' to indicate no character set.

FALSE: Set the WUF_TEXTIO_CHARSET property to the supplied character set value.

---

DP-004

Condition: Did WEBUTIL.GETPROPERTY return a valid (non-null, non-empty, non-'-1') file handle string?

TRUE: Convert the handle to a number, populate the file_type record, and return it to the caller.

FALSE: Raise TOOL_ERR.TOOL_ERROR to signal the file could not be opened.

---

DP-005

Condition: Was a BEAN_NOT_REGISTERED exception raised during execution?

TRUE: Display an error alert identifying the unregistered bean class, then raise TOOL_ERR.TOOL_ERROR.

FALSE: Allow other exception handlers (PROPERTY_ERROR, VALUE_ERROR, TOOL_ERR.TOOL_ERROR) to manage their respective conditions.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A file can only be opened for reading ('r'), writing ('w'), or appending ('a'); any other access mode is rejected before any property is set or any client-side operation is attempted.
- BR-002 - A missing or empty file path is rejected immediately to prevent an undefined file operation from being dispatched to the client-side bean.
- BR-003 - The character set property must always be explicitly communicated to the WebUtil core layer; when no character set is supplied by the caller, the literal value '(null)' is sent so the bean receives an unambiguous instruction.
- BR-004 - The file handle is obtained exclusively through WEBUTIL.GETPROPERTY (WUF_TEXTIO_OPEN); a null, empty, or '-1' response from that call is treated as a failed open and results in an error rather than a partial or invalid handle being returned.
- BR-005 - If the client-side WebUtil bean is not registered, the caller receives an informative error message identifying the missing bean class before the error is raised, enabling root-cause diagnosis without exposing raw exception details.

---
**Implementation Logic**

```plsql
  FUNCTION fopen(spec VARCHAR2, filemode VARCHAR2, charSet VARCHAR2 := null) RETURN file_type is
    clientFile file_type;
    javaHandle VARCHAR2(6);
  BEGIN
    -- check the mode is valid
    if (lower(filemode) not in ('r','w','a')) then 
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- make sure a file name has been specified      
    if (spec is null) or (spec='') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;
      
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILENAME',spec, true);
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_FILEMODE',filemode, true);        
    if (charSet is null) then
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET','(null)', true);
    else
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET',charSet, true);
    end if;
    javaHandle := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_OPEN');

    -- If the return is null then the file was not opened      
    if (javaHandle is null) or (javaHandle='') or (javaHandle='-1') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- if we are this far convert the handle to the correct format and return it.      
    clientFile.handle := to_number(javaHandle);
    return clientFile;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.fopen will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                 
      return null;
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE;
    when VALUE_ERROR then
      RAISE TOOL_ERR.TOOL_ERROR; 
    when TOOL_ERR.TOOL_ERROR then 
      RAISE;
  END fopen;
```

#### SP-009 - WEBUTIL.GETIMPLCLASS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the fully qualified Java class name for a given WebUtil component package identifier. This name is used in error messages to identify which WebUtil Java bean could not be found or registered, making it easier to diagnose WebUtil configuration issues.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the numeric identifier of the WebUtil package whose implementation class name is required.
- Step 2 - Look up the Java class name suffix for the given package identifier from the internal class name registry.
- Step 3 - Prepend the WebUtil Java root path to the suffix and return the fully qualified class name.

---
**Decision Points**

None. The function performs a direct lookup without branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The fully qualified Java class name is returned for use in error and diagnostic messages only; it is not used to perform any business operation directly.

---
**Implementation Logic**

```plsql

  FUNCTION getImplClass(packageID PLS_INTEGER) return VARCHAR2 is
  BEGIN 
    return WEBUTIL_JAVA_ROOT||m_implClasses(packageID);    
  END;
```

#### SP-010 - WEBUTIL.GETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FOPEN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value of a named Java system property from the application server's Java Virtual Machine via a Java Native Interface call. Used internally by WebUtil to read server-side configuration or environment values.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the name of the Java system property to retrieve.
- Step 2 - Build a Java Native Interface (JNI) argument list containing the property name.
- Step 3 - Call the Java System.getProperty method on the server via JNI with the supplied property name.
- Step 4 - Return the retrieved property value as a string to the caller.

---
**Decision Points**

None. The function performs a direct JNI call without branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This function is an internal WebUtil infrastructure routine; it provides read access to JVM system properties and is not directly tied to any business rule of the Child Indent Tracking form.

---
**Implementation Logic**

```plsql
  FUNCTION getProperty(
    a0    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'getProperty', '(Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-011 - WEBUTIL.GET_LINE

**Invoked From:**

- pe_child_indent_tracking_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Reads one line of text from an open server-side file by delegating to the WebUtil_Core component and returns the line content to the caller. When the end of the file is reached, the procedure raises a NO_DATA_FOUND exception to signal that there are no more lines to read.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| item | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the file handle identifying the open server-side file.
- Step 2 - Pass the file handle to WebUtil_Core by setting the WUF_TEXTIO_HANDLE property on the WUF_PACKAGE component.
- Step 3 - Request the next line of text from the file by retrieving the WUF_TEXTIO_GETLINE property from WebUtil_Core, storing the result in a local buffer.
- Step 4 - Check whether the buffer contains a newline character (chr(10)), which WebUtil_Core uses as an end-of-file marker because a normal get_line operation would never return a bare newline.
- Step 5 - If the buffer equals chr(10), raise NO_DATA_FOUND to notify the caller that all lines have been read.
- Step 6 - Otherwise, assign the buffer content to the OUT parameter and return it to the caller.
- Step 7 - If WebUtil_Core raises BEAN_NOT_REGISTERED (the required Java bean is absent), display an error alert identifying the missing bean class and raise TOOL_ERR.TOOL_ERROR to halt processing.
- Step 8 - If WebUtil_Core raises PROPERTY_ERROR during the read, raise TOOL_ERR.TOOL_ERROR to halt processing.

---
**Decision Points**

DP-001

Condition: Does the buffer returned by WebUtil_Core equal chr(10) (the end-of-file marker)?

TRUE: Raise NO_DATA_FOUND to signal that the end of the file has been reached; no line content is returned.

FALSE: Assign the buffer content to the OUT parameter and return it to the caller.

---

DP-002

Condition: Does WebUtil_Core raise BEAN_NOT_REGISTERED when the property is set or retrieved?

TRUE: Display an error alert identifying the missing bean class and raise TOOL_ERR.TOOL_ERROR to abort the read operation.

FALSE: Continue normal processing.

---

DP-003

Condition: Does WebUtil_Core raise PROPERTY_ERROR during the set or get operation?

TRUE: Raise TOOL_ERR.TOOL_ERROR to abort the read operation.

FALSE: Continue normal processing.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure uses the standard NO_DATA_FOUND exception to signal end-of-file, consistent with Oracle TEXT_IO conventions, allowing callers to use standard exception handling to control their read loops.
- BR-002 - Because WebUtil_Core cannot distinguish between an empty line and a line read beyond the end of the file, the PJC exception handler places a newline character (chr(10)) into the buffer at end-of-file; GET_LINE treats any buffer equal to chr(10) exclusively as an end-of-file signal and never returns it as line content.
- BR-003 - If the WebUtil_Core bean is not registered when a read is attempted, the procedure raises TOOL_ERR.TOOL_ERROR after surfacing a descriptive error alert, ensuring the calling process is halted rather than silently continuing with missing data.
- BR-004 - A PROPERTY_ERROR raised by WebUtil_Core during property set or retrieval is treated as a fatal condition; the procedure propagates TOOL_ERR.TOOL_ERROR immediately without returning partial data.

---
**Implementation Logic**

```plsql
  PROCEDURE get_line (file file_type, item OUT VARCHAR2) is
    buffer VARCHAR2(4000 char);
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);        
    buffer := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_GETLINE');
    -- We can't easily tell the difference between an empty line and a line beyond then 
    -- end of the file so to get around this, the exception handling code in the PJC 
    -- places a newline into the buffer when the end of file is passed.
    -- The rational being that get_line would never normally return a newline because 
    -- it normally uses that to tell it where to read up *to*.
    if buffer = chr(10) then 
      raise NO_DATA_FOUND;
    else
      item := buffer;
    end if;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.get_line will not work');
      RAISE TOOL_ERR.TOOL_ERROR;                                                                 
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE TOOL_ERR.TOOL_ERROR;  
  END get_line;
  
  /**
   * File writing functions
   */
```

#### SP-012 - WEBUTIL.ID_NULL

**Invoked From:**

- pe_child_indent_tracking_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]
- webutil.pld [StoredProcedure: WEBUTIL.ERRORALERT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Tests whether a WebUtil object handle (such as a file handle or record group handle) is null - that is, whether the object it refers to does not exist or has not been initialised. Returns TRUE if the handle is null and FALSE if it refers to a valid object. Used before file or record group operations to check whether the object needs to be created or is already available.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| handle | Pointer | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the object handle to test.
- Step 2 - Check whether the internal handle value (hnd) is null.
- Step 3 - Return TRUE if the handle is null (object does not exist); return FALSE if the handle has a value (object exists).

---
**Decision Points**

DP-001

Condition: Is the handle's internal value (hnd) null?

TRUE: Return TRUE indicating the object does not exist.

FALSE: Return FALSE indicating the object exists and is available for use.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Before attempting to delete or operate on an existing object, callers check this function to confirm the object exists, preventing errors from operating on non-existent handles.

---
**Implementation Logic**

```plsql

  FUNCTION ID_NULL(handle IN Pointer)        RETURN BOOLEAN is
  BEGIN
    if handle.hnd is null then 
      return TRUE;
    else
      return FALSE;
    end if;
  END ID_NULL;
```

#### SP-013 - WEBUTIL.PUT_LINE

**Invoked From:**

- pe_child_indent_tracking_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a single line of text to an open server-side file via the WebUtil file handling component, appending a newline character after the text. Used to write individual data rows to the CSV output file during report generation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |
| item | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the file handle identifying the open output file and the text line to write.
- Step 2 - Pass the file handle to the WebUtil component.
- Step 3 - Send the line text to the WebUtil component for writing to the file.
- Step 4 - Instruct the WebUtil component to append a newline character after the text, so each call produces a separate line in the file.
- Step 5 - If the WebUtil component is unavailable or a property error occurs, display an error message and raise a tool error.

---
**Decision Points**

None. The procedure writes the line unconditionally; error handling covers component unavailability only.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Each line written to the export file is automatically terminated with a newline character, ensuring correct CSV line formatting when the file is opened in a spreadsheet application.
- BR-002 - If the WebUtil file writing component is unavailable, the error is reported to the user and processing is halted to prevent a partial or corrupted output file.

---
**Implementation Logic**

```plsql
    

  PROCEDURE put_line (file file_type, item VARCHAR2) is
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);              
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_PUT',item); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_NEWLINE',1); 
  EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.put_line will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;  
  END put_line;
```

#### SP-014 - WEBUTIL.SETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sets a named Java system property to a given value on the application server's Java Virtual Machine via a Java Native Interface call, and returns the previous value of the property. Used internally by WebUtil to configure server-side behaviour.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |
| a1 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the property name and the new value to assign.
- Step 2 - Build a Java Native Interface (JNI) argument list containing the property name and the new value.
- Step 3 - Call the Java System.setProperty method on the server via JNI with the supplied name and value.
- Step 4 - Return the previous value of the property as a string to the caller.

---
**Decision Points**

None. The function performs a direct JNI call without branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This function is an internal WebUtil infrastructure routine; it provides write access to JVM system properties and is not directly tied to any business rule of the Child Indent Tracking form.

---
**Implementation Logic**

```plsql
  FUNCTION setProperty(
    a0    VARCHAR2,
    a1    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(2);
    JNI.ADD_STRING_ARG(args, a0);
    JNI.ADD_STRING_ARG(args, a1);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'setProperty', '(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-015 - SF_COPYRIGHT_DECLARATION

**Invoked From:**

- pe_child_indent_tracking_fmb.xml [Trigger: FT_CANCEL]
- pe_child_indent_tracking_fmb.xml [Trigger: WHEN-NEW-BLOCK-INSTANCE]

---

**Screen:**

N/A

---

**Purpose**

Returns the standard copyright notice text for Maruti Suzuki India Limited, adjusted to reflect the correct Indian financial year. Because the Indian financial year runs from April to March, dates falling in January, February, or March belong to the financial year that started in the previous calendar year; the function compensates by decrementing the year by one for those months. The resulting string is returned to the calling triggers in pe_child_indent_tracking_fmb.xml for display purposes.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Capture the current system date using SYSDATE into a local date variable.
- Step 2 - Extract the three-character month abbreviation from the captured date.
- Step 3 - Check whether the extracted month is JAN, FEB, or MAR.
- Step 4 - If the month is JAN, FEB, or MAR, convert the four-digit year to a number, subtract one, and construct the copyright string in the format '- YYYY Maruti Suzuki India Limited '.
- Step 5 - If the month is any other month (APR through DEC), extract the four-digit year directly from the date and construct the copyright string in the same format.
- Step 6 - Return the constructed copyright string to the calling trigger.

---
**Decision Points**

DP-001

Condition: Is the three-character abbreviation of the current month one of JAN, FEB, or MAR?

TRUE: Construct the copyright string using the current calendar year minus one (e.g., if the system year is 2012 and the month is FEB, the string shows 2011), reflecting that the active financial year began in the previous calendar year.

FALSE: Construct the copyright string using the current calendar year as-is, because the active financial year began in the current calendar year.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The copyright notice must reflect the current Indian financial year (April to March) rather than the calendar year, ensuring the displayed copyright is legally accurate under the Indian financial year convention.
- BR-002 - For system dates in January, February, or March, the displayed year is the current calendar year minus one, because those months fall within the financial year that started in the prior April.
- BR-003 - The copyright text is generated dynamically at runtime using SYSDATE so that it is always current without requiring manual updates to the form source code.
- BR-004 - The function takes no input parameters and has no external dependencies; all data required to produce the copyright string is derived solely from the system date.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
function sf_copyright_declaration return varchar is
a varchar2(50);
dt date;
begin
--Modified by Prerna on 16-May-11  to display current Financial Year Copyright
dt := sysdate;

    if( to_char(dt,'MON') in ('JAN','FEB','MAR')) then
        a := '- '||to_char(to_number(to_char(dt,'RRRR')) - 1)||' Maruti Suzuki India Limited ';
    else
        a := '- '||to_char(dt,'RRRR')||' Maruti Suzuki India Limited ';
    end if;
return(a);
end;

```

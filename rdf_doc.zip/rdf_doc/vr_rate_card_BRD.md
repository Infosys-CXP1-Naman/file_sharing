# BUSINESS REQUIREMENTS DOCUMENT

## Table of Contents

- 1. Document Control
  - 1.1 Document Information
  - 1.2 Revision History
- 2. Executive Summary
  - Key Stakeholders
- 3. System Context
- 4. Functional Requirements
  - 4.1 Business Requirements
    - Requirement ID: BR-001
    - Requirement ID: BR-002
    - Requirement ID: BR-003
    - Requirement ID: BR-004
    - Requirement ID: BR-005
    - Requirement ID: BR-006
    - Requirement ID: BR-007
    - Requirement ID: BR-008
    - Requirement ID: BR-009
    - Requirement ID: BR-010
    - Requirement ID: BR-011
    - Requirement ID: BR-012
- 6. Data Requirements
  - 6.1 Business Entities and Relationships
    - Toolbar Button Panel (non-persistent control block)
    - Error Display Panel (non-persistent control block)
    - Entity Relationships
  - 6.2 Data Capture Requirements
    - Error Display Panel
  - 6.3 Reference Data
  - 6.4 Data Lifecycle
  - 6.5 Excel Output Columns
- 7. Glossary
- 8. Technical Inventory
  - 8.1 Form Architecture
    - 8.1.1 Global Variables
    - 8.1.2 Form Parameters
  - 8.2 Blocks
    - 8.2.1 Block WhereClause and OrderByClause
  - 8.3 Items Summary
  - 8.4 List of Values
  - 8.5 Alerts
  - 8.6 Program Units
  - 8.7 Triggers
    - 8.7.1 Inactive / Commented-Out Trigger Register
  - 8.8 Canvas and Window Inventory
  - 8.9 Editors
  - 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups
    - 8.10.1 Visual Attributes (form-defined)
    - 8.10.2 Property Classes (form-defined)
    - 8.10.3 Object Groups
  - 8.11 DataSourceColumn Inventory
- 9. Object Library
- 10. Record Groups
- 11. Referenced Database Objects
- 12. Backend Procedures and Packages
  - 12.1 Main Flow Backend Procedure/Package Index
  - 12.2 Procedure and Package Catalogue
- 13. Package Procedure Specifications
- 14. Database Package Catalogue
- 15. PLD Procedure Call Sites
- 16. Microservice API Candidates
  - 16.1 Microservices with APIs
- 17. Workflows
- 18. PLD-Backed Logic
- 19. PCK-Backed Logic
- 20. System Interfaces
  - 20.1 Database Integrations
  - 20.2 External System Integrations
  - 20.3 Report Integrations
    - 20.3.1 Parameters Passed to the Report
- 21. Procedure and Function Business Rule Catalogue
  - 21.1 Catalogue Index
  - 21.2 Detailed Specifications
    - SP-001 - GENERAL.ASK_CONFIRM
    - SP-002 - CALL_REPORT
    - SP-003 - VIEW_EXCEL_REP

## 1. Document Control

### 1.1 Document Information

| Field | Value |
| ----- | ----- |
| Document Title | DPL_MTPL - Business Requirements Document |
| Form Module Name | DPL_MTPL |
| Document Version | 1.0 |
| Date Created | October 17, 2026 |
| Author/Prepared By | BRD Agent |

### 1.2 Revision History

| Version | Date | Author | Description |
| --- | --- | --- | --- |
| 1.0 | October 17, 2026 | BRD Agent | Initial draft |

---

## 2. Executive Summary

*High-level overview of the dpl_mtpl form, its purpose, and roles referenced in the module.*

The **VR_RATE_CARD** Oracle Forms module is the **Rate Card Report** screen for the Maruti Dealer Management System (DMS). Built on the DPL_MTPL template foundation, this form allows authenticated dealer users to generate a rate card report in PDF format or export data to a CSV file by selecting search parameters (city category, service model, and fuel type). On opening, the form automatically pre-populates the city category for dealer users in a specific location group; for other users it presents an open selection field. The user selects the applicable service model from a LOV-backed dropdown (which automatically fills the fuel type), and clicks the Generate Report button to produce the report. The form enforces mandatory field validation before allowing report generation. The DPL template layer provides the standard toolbar (Save, Cancel, Insert, Delete, List, Print, Exit, Cut, Copy, Paste) and shared confirmation dialogs used across all DMS forms.

### Key Stakeholders

*Who uses VR_RATE_CARD*

| Stakeholder | Role |
| :--- | :--- |
| **DMS User** | The end user of the rate card report screen. Selects city category, service model, and fuel type parameters, then clicks the Generate Report button to produce a PDF rate card report or trigger an Excel CSV export. |

---

---

## 3. System Context

*Describes the dpl_mtpl module's role within the DMS ecosystem, scope, process flow, and key integrations.*

The **dpl_mtpl** module is the **DPL Multi-Purpose Template** form for the Maruti DMS application suite. It serves as the shared scaffold that every DMS data-entry screen inherits, providing a common push-button toolbar, standardised navigation, confirmation dialogs, and an error information panel. Derived forms add their own data blocks and business logic on top of this foundation, ensuring a uniform user experience across the entire application suite.

**System purpose:** Allow dealer users to generate the rate card report by selecting the applicable city category, service model, and fuel type parameters, then submitting the parameters to the rate card report engine; alternatively, export the rate card data as a CSV file. The form inherits the DPL_MTPL toolbar, confirmation dialogs, and standard navigation from the shared template library.

**In scope:**

- Displaying the parameter-entry screen at form startup and automatically maximising the application window
- Auto-populating the city category for dealer users whose location is associated with a specific parent group
- Providing a city category selection field backed by a list of valid city types for the current principal
- Providing a service model selection field backed by a list of valid service variants and fuel types for the current principal
- Automatically filling the fuel type when the user selects a service model
- Enforcing that city category and service model are both entered before the report can be generated
- Generating the rate card report in PDF format when the user clicks Generate Report
- Providing Save, Cancel, Insert, Delete, List, Print, Exit, Cut, Copy, and Paste toolbar buttons (most are disabled; Save, Cancel, and Exit are functional)
- Prompting for confirmation before cancelling unsaved changes or exiting with unsaved changes
- Displaying error and informational messages through the shared alert panels
- Providing standard keyboard navigation (next field, previous field, next block, previous block)
- Displaying a secondary error information panel for showing error text

**Process Name:** Rate Card Report Generation

**Process Owner:** DMS Application Administrator

**Process Objective:** Open the rate card report form, present parameter-entry fields for city category and service model, validate mandatory selections, and generate the rate card report or CSV export for the selected parameters.

**Process Trigger:** A DMS dealer user opens the rate card report form

**Process Flow:**

The complete rate card report generation process follows this sequence. Each step corresponds to Functional Requirements BR-001 through BR-012 in Section 4.

```
STEP 1 ── FORM OPENS AND WINDOW MAXIMISES (BR-001)
         The form opens and the application window is automatically maximised.
         If the user belongs to a specific location group, the city category is
         pre-populated automatically; otherwise the city category field is presented for entry.

STEP 2 ── TOOLBAR BUTTONS PRESENTED (BR-002)
         The toolbar displays action buttons. Exit and Cancel are functional;
         Insert, Delete, and List are disabled for this report form.

STEP 3 ── USER SELECTS AN ACTION (BR-003)
         The user clicks a toolbar button or presses a keyboard shortcut.
         ├── SAVE: proceeds to STEP 4
         ├── CANCEL: proceeds to STEP 5
         ├── INSERT: proceeds to STEP 7
         ├── DELETE: proceeds to STEP 8
         ├── LIST: proceeds to STEP 9
         ├── PRINT: proceeds to STEP 10
         ├── EXIT: proceeds to STEP 11
         └── CUT / COPY / PASTE / NAVIGATE: proceeds to STEP 12

STEP 4 ── SAVE RECORD (BR-004)
         The current record is committed to the database.
         If Save is not enabled on the toolbar, no action is taken.

STEP 5 ── CANCEL - CHECK FOR UNSAVED CHANGES (BR-005)
         The system checks whether any data has been changed.
         ├── CHANGES EXIST: a confirmation prompt is shown before the form is cleared.
         └── NO CHANGES: the form is cleared immediately without prompting.

STEP 6 ── FORM CLEARED AFTER CANCEL (BR-006)
         The form data is reset and the user may begin a new selection or exit.

STEP 7 ── INSERT NEW RECORD (BR-007)
         Insert is disabled on this form; the action is silently suppressed.

STEP 8 ── DELETE RECORD WITH CONFIRMATION (BR-008)
         Delete is disabled on this form; the action is silently suppressed.

STEP 9 ── LIST OF VALUES POPUP (BR-009)
         The user selects city category or service model from a dropdown list;
         selecting a service model automatically fills the fuel type field.

STEP 10 ── PRINT ACTION (PLACEHOLDER) (BR-010)
          The Print button is a placeholder with no active implementation.

STEP 11 ── EXIT WITH CONFIRMATION (BR-011)
          The user clicks Exit; if unsaved changes exist, a confirmation prompt is shown.
          ├── CONFIRMED (or no changes): the form closes and returns to the calling module.
          └── NOT CONFIRMED: the form remains open.

STEP 12 ── EDITING AND NAVIGATION ACTIONS (BR-012)
          Cut, Copy, Paste, and keyboard navigation act on the focused field.
```

**Major process interactions:**

- **DPL shared confirmation library** - provides the confirmation dialog used before cancelling changes or exiting with unsaved data
- **DPL object library** - supplies inherited visual attributes, window layout, and toolbar block definitions
- **Oracle Reports server** - receives the rate card report submission and returns a PDF result

---

---

## 4. Functional Requirements

### 4.1 Business Requirements

#### Requirement ID: BR-001

**Requirement Title:** Form Initialization - Maximize Application and Main Window

**Business Description:**
When the form is opened, the application workspace and the main screen window are both automatically expanded to fill the full display area. This ensures that the form presents the entire working area to the user without requiring any manual window resizing, providing a consistent, full-screen experience every time the form is launched.

**Actors:** Oracle Forms Runtime (system-initiated on form open)

**Preconditions:**
- The form has been launched and the runtime environment is starting up.

**Main Flow:**

**Step 1 - Application workspace expanded to full screen**
The system automatically maximizes the application's main desktop area so that it occupies the entire display.

**Step 2 - Main form window expanded to full screen**
The system then maximizes the main working window of the form so that it fills the application workspace completely.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Main Window state (`WN_MAIN` window property) | Auto-populated | Window state | N/A | N/A | MAXIMIZE | Form open event triggered | Set unconditionally on form startup | N/A |

---

#### Requirement ID: BR-002

**Requirement Title:** Exit Form with Unsaved-Changes Confirmation

**Business Description:**
When the user clicks the Exit button, the system checks whether any data on the current form has been changed since the last save. If unsaved changes exist, the user is shown a confirmation prompt before the form is closed, ensuring that no accidental data loss occurs. If the form is currently in query mode, it exits immediately without a prompt. If no changes are pending, the form closes directly.

**Actors:** Form User

**Preconditions:**
- The form is open and the user has clicked the Exit button.

**Main Flow:**

**Step 1 - Query mode check: exit immediately if in query mode**
If the form is currently in query mode (the user is actively entering a query rather than editing data), the system closes the form immediately without any confirmation prompt.

*Screen: `WN_MAIN` / `CN_TOOL`.*

**Step 2 - Unsaved changes check: prompt before closing**
If the form is not in query mode, the system checks whether any data has been entered or changed since the last save. If unsaved changes exist, the user is shown a confirmation dialog asking whether to proceed without saving.

*Screen: `WN_MAIN` / `CN_TOOL`.*

*Procedures called:*
- **GENERAL.ASK_CONFIRM** ([SP-001](#SP-001--GENERAL.ASK_CONFIRM)) - GENERAL.ASK_CONFIRM - Presents a configurable confirmation message to the user via the `AL_CONFIRM` alert dialog and returns a numeric flag indicating whether the user chose to proceed. Callers use the return value to decide whether to continue or abort a destructive or irreversible action (such as a cancellation or deletion).
    * **Step 1** - The text of the confirmation alert is set to the message supplied by the caller - in this case, *"Entered data will not be Saved"* - so the dialog is contextually relevant.
    * **Step 2** - The confirmation alert is displayed to the user and the button pressed is captured.
    * **Step 3** - If the user pressed the first (confirm) button, the function returns 1 (confirmed - proceed with exit).
    * **Step 4** - If the user pressed any other button, the function returns 0 (declined - abort exit).

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Unsaved changes confirmation | GENERAL.ASK_CONFIRM [SP-001] - called from WHEN-BUTTON-PRESSED on PB_BLK.PB_EXIT | When the user clicks the Exit button while data has been changed | Prevents the user from accidentally discarding unsaved work by requiring explicit confirmation before the form closes | User clicks the decline button; the confirmation dialog closes and the form remains open with all data intact |

*Business outcomes (errors, warnings, success, and status):*
- **BR-002-WS-01** - Unsaved changes exist when Exit is clicked - *"Entered data will not be Saved"* - confirmation dialog displayed; if the user confirms, the form closes; if the user declines, the form stays open.

**Step 3 - No unsaved changes: close form directly**
If no data has been changed since the last save, the form closes immediately without any confirmation prompt.

**Alternative Flows:**
- **BR-002-AF-01** - (from Step 1) Form is in query mode: the system exits the form immediately via the built-in exit action, bypassing both the unsaved-changes check and the confirmation dialog.
- **BR-002-AF-02** - (from Step 2) User declines the confirmation prompt: the form remains open; no data is lost and the user may continue working.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Exit button (`PB_EXIT`) | Mandatory | Push Button | N/A | N/A | N/A | Form is open | Clicking this button initiates the exit flow | N/A |

---

#### Requirement ID: BR-003

**Requirement Title:** Save Record

**Business Description:**
When the user clicks the Save button, the system commits all pending data changes to the database, provided that the Save action is available in the current context. If the Save button has been disabled by the form's controlling logic, the save action is silently suppressed with no error or feedback. This ensures that data is only saved when the application has determined it is safe to do so.

**Actors:** Form User

**Preconditions:**
- The form is open and the user clicks the Save button.

**Main Flow:**

**Step 1 - Save button availability checked**
When the user clicks Save, the system first checks whether the Save button is currently enabled. If it is enabled, the system proceeds to commit all pending form changes to the database. If the Save button is not currently enabled, no action is taken.

*Screen: `WN_MAIN` / `CN_TOOL`.*

**Alternative Flows:**
- **BR-003-AF-01** - (from Step 1) Save button is not enabled: the commit action is not triggered; the click is silently ignored and the form remains unchanged.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Save button (`PB_SAVE`) | Mandatory | Push Button | N/A | N/A | N/A | Form is open | Save button must be enabled for the commit action to fire | Silently suppressed if the Save button is not enabled |

---

#### Requirement ID: BR-004

**Requirement Title:** Cancel / Discard Unsaved Changes

**Business Description:**
When the user clicks the Cancel button, the system checks whether any data has been entered or changed since the last save. If unsaved changes exist, the user is shown a confirmation prompt before those changes are discarded and the form is cleared. If no changes are pending, the form is cleared immediately. This prevents accidental loss of work while still allowing the user to reset the form when needed. If the Cancel button is not available in the current context, the action is suppressed.

**Actors:** Form User

**Preconditions:**
- The form is open and the user clicks the Cancel button.

**Main Flow:**

**Step 1 - Cancel button availability checked**
When the user clicks Cancel, the system first checks whether the Cancel button is currently enabled. If it is not enabled, the action is silently suppressed. If it is enabled, the flow continues.

*Screen: `WN_MAIN` / `CN_TOOL`.*

**Step 2 - Unsaved changes check: prompt before discarding**
If the Cancel button is enabled, the system checks whether any form data has been changed since the last save. If unsaved changes exist, the user is shown a confirmation prompt before the changes are discarded.

*Procedures called:*
- **GENERAL.ASK_CONFIRM** ([SP-001](#SP-001--GENERAL.ASK_CONFIRM)) - GENERAL.ASK_CONFIRM - Presents a configurable confirmation message to the user via the `AL_CONFIRM` alert dialog and returns a numeric flag indicating whether the user chose to proceed. Callers use the return value to decide whether to continue or abort a destructive or irreversible action (such as a cancellation or deletion).
    * **Step 1** - The text of the confirmation alert is set to the message supplied by the caller - in this case, *"Entered data will not be Saved"* - so the dialog is contextually relevant.
    * **Step 2** - The confirmation alert is displayed to the user and the button pressed is captured.
    * **Step 3** - If the user pressed the first (confirm) button, the function returns 1 (confirmed - proceed with clear).
    * **Step 4** - If the user pressed any other button, the function returns 0 (declined - abort clear).

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Unsaved changes confirmation before discard | GENERAL.ASK_CONFIRM [SP-001] - called from FT_CANCEL | When the user clicks the Cancel button while data has been changed | Prevents the user from accidentally discarding unsaved work by requiring explicit confirmation before the form is cleared | User clicks the decline button; the confirmation dialog closes and the form remains open with all data intact |

*Business outcomes (errors, warnings, success, and status):*
- **BR-004-WS-01** - Unsaved changes exist when Cancel is clicked - *"Entered data will not be Saved"* - confirmation dialog displayed; if the user confirms, the form is cleared; if the user declines, the form stays as-is.

**Step 3 - Form cleared**
If the user confirms the discard (or if there were no unsaved changes), the system clears the form, resetting all fields to their initial state.

**Alternative Flows:**
- **BR-004-AF-01** - (from Step 1) Cancel button is not enabled: the clear action is not triggered; the click is silently ignored.
- **BR-004-AF-02** - (from Step 2) No unsaved changes: the form is cleared immediately without any confirmation prompt.
- **BR-004-AF-03** - (from Step 2) User declines the confirmation prompt: the form remains open; no data is discarded.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Cancel button (`PB_CANCEL`) | Mandatory | Push Button | N/A | N/A | N/A | Form is open | Cancel button must be enabled for the clear action to fire | Silently suppressed if the Cancel button is not enabled |

---

#### Requirement ID: BR-005

**Requirement Title:** Insert New Record

**Business Description:**
When the user clicks the Insert button, the system navigates to the form's data-entry block and positions the cursor at a new, blank record ready for data entry. This enables the user to begin entering a new record immediately. If the Insert button is not currently available in the context, the action is suppressed without feedback. Note: this form is a reusable template and the target data block is a placeholder; in a deployed form, the placeholder is replaced by the actual data-entry block name.

**Actors:** Form User

**Preconditions:**
- The form is open and the Insert button is enabled.

**Main Flow:**

**Step 1 - Insert button availability checked**
When the user clicks Insert, the system checks whether the Insert button is currently enabled. If it is not enabled, the action is silently suppressed. If it is enabled, the system proceeds to position the form for new record entry.

*Screen: `WN_MAIN` / `CN_TOOL`.*

**Step 2 - Navigate to data-entry block and position at new record**
The system navigates to the designated data-entry block, moves to the last existing record, and then positions the cursor on a new empty record, ready for the user to begin data entry.

**Alternative Flows:**
- **BR-005-AF-01** - (from Step 1) Insert button is not enabled: the navigation and record-creation action is not triggered; the click is silently ignored.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Insert button (`PB_INSERT`) | Mandatory | Push Button | N/A | N/A | N/A | Form is open | Insert button must be enabled for the navigation action to fire | Silently suppressed if the Insert button is not enabled |

---

#### Requirement ID: BR-006

**Requirement Title:** Delete Record with Confirmation

**Business Description:**
When the user clicks the Delete button, the system checks whether any data has been changed on the current record. If changes are pending, the user is asked to confirm the deletion before the current record is removed. If no changes are pending but the delete button is enabled, the form is cleared instead (the record is considered not yet committed). Validation is temporarily suspended during the deletion sequence to allow the removal to proceed cleanly. If the Delete button is not available in the current context, the action is suppressed. Note: this form is a reusable template; the target data block used during deletion is a placeholder replaced in deployed forms.

**Actors:** Form User

**Preconditions:**
- The form is open and the Delete button is enabled.

**Main Flow:**

**Step 1 - Delete button availability checked and validation suspended**
When the user clicks Delete, the system first checks whether the Delete button is currently enabled. If it is not enabled, the action is suppressed. If it is enabled, the system temporarily suspends form-level validation to allow the deletion sequence to proceed without triggering unrelated field checks.

*Screen: `WN_MAIN` / `CN_TOOL`.*

**Step 2 - Navigate to data-entry block and check for pending changes**
The system navigates to the designated data-entry block and checks whether any data on the current record has been changed since the last save.

**Step 3 - Confirm deletion if record has pending changes**
If the current record has unsaved changes, the system presents a confirmation prompt to the user before deleting the record.

*Procedures called:*
- **GENERAL.ASK_CONFIRM** ([SP-001](#SP-001--GENERAL.ASK_CONFIRM)) - GENERAL.ASK_CONFIRM - Presents a configurable confirmation message to the user via the `AL_CONFIRM` alert dialog and returns a numeric flag indicating whether the user chose to proceed. Callers use the return value to decide whether to continue or abort a destructive or irreversible action (such as a cancellation or deletion).
    * **Step 1** - The text of the confirmation alert is set to the message supplied by the caller - in this case, *"Are you sure to Delete"* - so the dialog is contextually relevant.
    * **Step 2** - The confirmation alert is displayed to the user and the button pressed is captured.
    * **Step 3** - If the user pressed the first (confirm) button, the function returns 1 (confirmed - proceed with delete).
    * **Step 4** - If the user pressed any other button, the function returns 0 (declined - abort delete).

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Deletion confirmation when record has unsaved changes | GENERAL.ASK_CONFIRM [SP-001] - called from FT_DEL | When the user clicks the Delete button while the current record has been changed | Prevents accidental deletion of work in progress by requiring explicit confirmation before the record is removed | User clicks the decline button; the confirmation dialog closes and the record remains intact |

*Business outcomes (errors, warnings, success, and status):*
- **BR-006-WS-01** - Record has pending changes when Delete is clicked - *"Are you sure to Delete"* - confirmation dialog displayed; if confirmed, the record is deleted; if declined, the record remains.

**Step 4 - Validation re-enabled after deletion sequence**
After the delete action (whether via record removal or form clear), the system re-enables form-level validation so that subsequent operations are validated normally.

**Alternative Flows:**
- **BR-006-AF-01** - (from Step 1) Delete button is not enabled: the deletion action is not triggered; the click is silently ignored.
- **BR-006-AF-02** - (from Step 2) No unsaved changes on the current record: the form is cleared (via the built-in clear form action) without a confirmation prompt; the record was not yet committed to the database.
- **BR-006-AF-03** - (from Step 3) User declines the confirmation prompt: the form remains open; the record is not deleted; validation is re-enabled.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Delete button (`PB_DEL`) | Mandatory | Push Button | N/A | N/A | N/A | Form is open | Delete button must be enabled for the deletion sequence to fire | Silently suppressed if the Delete button is not enabled |

---

#### Requirement ID: BR-007

**Requirement Title:** Show List of Values (LOV)

**Business Description:**
When the user clicks the List button, the system opens the list of values lookup for the currently focused field, allowing the user to browse and select a valid value. This button is only active when the currently focused field has an associated lookup list. If the List button is not currently enabled, the action is suppressed without feedback.

**Actors:** Form User

**Preconditions:**
- The form is open, the List button is enabled, and the currently focused field supports a list of values lookup.

**Main Flow:**

**Step 1 - List button availability checked and LOV displayed**
When the user clicks the List button, the system checks whether the List button is currently enabled. If enabled, the system opens the standard value-selection list for the currently focused field. If not enabled, the action is silently suppressed.

*Screen: `WN_MAIN` / `CN_TOOL`.*

**Alternative Flows:**
- **BR-007-AF-01** - (from Step 1) List button is not enabled: the LOV is not opened; the click is silently ignored.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| List button (`PB_LIST`) | Mandatory | Push Button | N/A | N/A | N/A | Form is open | List button must be enabled; the focused field must have a LOV attached | Silently suppressed if the List button is not enabled |

---

#### Requirement ID: BR-008

**Requirement Title:** Print Action (Template Placeholder)

**Business Description:**
The form provides a Print button that is reserved for print and report functionality in forms derived from this template. In the base template, the Print button's logic contains only a placeholder comment and performs no action. When the Print button is clicked and enabled, the system reaches the placeholder code which does nothing. If the Print button is not enabled, the action is silently suppressed. Derived forms are expected to implement the actual print logic here.

**Actors:** Form User

**Preconditions:**
- The form is open and the user clicks the Print button.

**Main Flow:**

**Step 1 - Print button availability checked; no action taken (placeholder)**
When the user clicks the Print button, the system checks whether the Print button is currently enabled. The inner code body is a placeholder (`/* INSERT YOUR PRINT CODE HERE */ NULL`) - it performs no action regardless of the button's state. If the Print button is not enabled, the action is also silently suppressed.

*Business outcomes (errors, warnings, success, and status):*
- **BR-008-IC-01** - `FT_PRINT` inner body is `NULL` (placeholder) - the Print action is defined in the template as a no-operation pending implementation by derived forms; no report is produced and no message is displayed.

**Alternative Flows:**
- **BR-008-AF-01** - (from Step 1) Print button is not enabled: the print flow is not reached; the click is silently ignored.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Print button (`PB_PRINT`) | Mandatory | Push Button | N/A | N/A | N/A | Form is open | Print button must be enabled for the print flow to be entered; inner code is a placeholder and does nothing | Silently suppressed if Print button is not enabled |

---

#### Requirement ID: BR-009

**Requirement Title:** Print Destination Selection (ASK_PRINT Program Unit)

**Business Description:**
The form includes a utility function that can be called by any print or report flow in derived forms. When invoked, it displays a three-option dialog to the user asking them to choose a print destination: the first option represents one output choice (returning 1), the second represents another (returning 2), and any other outcome (including cancellation) returns 3. This function is a shared utility provided by the form template for use when print destination selection is required; it is not called directly by any trigger in this template form's own code.

**Actors:** Oracle Forms Runtime (called programmatically by print/report logic in derived forms)

**Preconditions:**
- The `ASK_PRINT` function is invoked by a calling routine within a derived form that requires the user to choose a print destination.

**Main Flow:**

**Step 1 - Print destination dialog displayed and user response captured**
The function sets the text of the print alert to the confirmation message supplied by the caller, displays the alert to the user, and captures which button the user presses.

**Step 2 - Return value determined by button pressed**
If the user presses the first button, the function returns 1. If the user presses the second button, the function returns 2. If the user presses any other button (or cancels), the function returns 3.

> **(TEMPLATE UTILITY - does not execute in this form's own triggers; provided for use by derived forms.)**

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Print alert (`AL_PRINT`) | Auto-populated | Alert | N/A | N/A | 1 / 2 / 3 | Called by a print/report flow | Alert message text is set by the caller before display | Returns 3 (cancel) if any unexpected button state is encountered |

---

#### Requirement ID: BR-010

**Requirement Title:** Keyboard Navigation - Standard Item, Block, and Record Traversal

**Business Description:**
The form provides keyboard shortcuts that allow the user to move between fields, blocks, and records using the keyboard. Moving to the next field, previous field, next block, previous block, next record, and previous record are all supported as keyboard-accessible alternatives to mouse navigation. These actions delegate directly to the standard built-in navigation commands with no custom business logic applied.

**Actors:** Form User

**Preconditions:**
- The form is open and the user is using keyboard navigation.

**Main Flow:**

**Step 1 - Keyboard navigation delegated to standard built-in commands**
When the user presses the keyboard shortcut for next item, previous item, next block, previous block, next record, or previous record, the system delegates directly to the corresponding standard navigation command. No custom business logic is applied; these are pure platform-delegation triggers.

> **(KEY-OTHERS trigger is COMMENTED OUT / INACTIVE - does not execute.)**

---

#### Requirement ID: BR-011

**Requirement Title:** Exit Form with Confirmation

**Business Description:**
When the user clicks the Exit button, the system checks whether any data on the current form has been changed since the last save. If unsaved changes exist, the user is shown a confirmation prompt before the form is closed. If no changes are pending and the form is not in query mode, the form closes directly. If the form is in query mode, it exits immediately without a prompt.

**Actors:** Form User

**Preconditions:**
- The form is open and the user has clicked the Exit button.

**Main Flow:**

**Step 1 - Exit action initiated**
The user clicks the Exit button on the toolbar. The system determines whether the form is in query mode.

**Step 2 - Check for unsaved changes and prompt if needed**
If the form is not in query mode, the system checks whether any data has been entered or changed since the last save. If unsaved changes exist, the user is shown a confirmation dialog before the form closes.

**Step 3 - Form closed or user remains**
If the user confirms (or no unsaved changes existed), the form closes and control returns to the calling module. If the user declines, the form remains open.

**Alternative Flows:**
- **BR-011-AF-01** - (from Step 1) Form is in query mode: the system exits the form immediately, bypassing both the unsaved-changes check and the confirmation dialog.
- **BR-011-AF-02** - (from Step 2) No unsaved changes: the form closes immediately without any confirmation prompt.
- **BR-011-AF-03** - (from Step 2) User declines the confirmation prompt: the form remains open; no data is lost.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Exit button (`PB_EXIT`) | Mandatory | Push Button | N/A | N/A | N/A | Form is open | Clicking this button initiates the exit flow | N/A |

---

#### Requirement ID: BR-012

**Requirement Title:** Editing and Keyboard Navigation Actions

**Business Description:**
The form provides clipboard editing actions (Cut, Copy, Paste) and keyboard navigation shortcuts that allow the user to move between fields, blocks, and records. Cut removes selected text from the active field; Copy copies selected text; Paste inserts clipboard content. Keyboard navigation (next/previous item, next/previous block, next/previous record) moves focus within the form. All navigation and editing actions delegate directly to the standard built-in commands with no custom business logic applied.

**Actors:** Form User

**Preconditions:**
- The form is open and the user is performing a clipboard or navigation action.

**Main Flow:**

**Step 1 - Clipboard or navigation action performed**
The user clicks Cut, Copy, or Paste on the toolbar, or presses a keyboard navigation shortcut. The system delegates directly to the corresponding standard built-in action. No custom business logic is applied.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Cut button (`PB_CUT`) | Optional | Push Button | N/A | N/A | N/A | Text is selected in the active field | Cuts the selected text to the clipboard | N/A |
| Copy button (`PB_COPY`) | Optional | Push Button | N/A | N/A | N/A | Text is selected in the active field | Copies the selected text to the clipboard | N/A |
| Paste button (`PB_PASTE`) | Optional | Push Button | N/A | N/A | N/A | Clipboard contains text | Pastes clipboard text into the active field | N/A |

---

---

Catalogue of the discrete business rules enforced by the form's code.

| Rule ID | Rule Name | Rule Type | Business Requirement ID | Condition | Action | Business Impact |
| ------- | --------- | --------- | ----------------------- | --------- | ------ | --------------- |
| BRC-001 | Save Button Enablement Gate | Constraint | BR-003 | The Save button is not currently enabled in the form's current operating context | The save/commit action is silently suppressed; no data is written to the database and no message is shown | Prevents premature or context-inappropriate saves; ensures the form controls when data may be committed |
| BRC-002 | Cancel Button Enablement Gate | Constraint | BR-004 | The Cancel button is not currently enabled in the form's current operating context | The clear-form action is silently suppressed; the form remains unchanged | Prevents the form from being cleared at an inappropriate point in the workflow |
| BRC-003 | Unsaved Changes Confirmation Before Cancel | Validation | BR-004 | The user clicks Cancel and there are unsaved changes on the form | The system displays the confirmation dialog *"Entered data will not be Saved"*; the form is cleared only if the user confirms | Protects the user's in-progress work from accidental loss (see WF-001) |
| BRC-004 | Insert Button Enablement Gate | Constraint | BR-005 | The Insert button is not currently enabled in the form's current operating context | The record-creation navigation is silently suppressed | Prevents navigation to insert mode at an inappropriate point in the workflow |
| BRC-005 | Delete Button Enablement Gate | Constraint | BR-006 | The Delete button is not currently enabled in the form's current operating context | The deletion sequence is silently suppressed | Prevents accidental deletion attempts outside of a valid deleteable-record context |
| BRC-006 | Unsaved Changes Confirmation Before Delete | Validation | BR-006 | The user clicks Delete and the current record has unsaved changes | The system displays the confirmation dialog *"Are you sure to Delete"*; the record is deleted only if the user confirms | Prevents accidental deletion of work in progress; gives the user the opportunity to cancel (see WF-002) |
| BRC-007 | Delete Without Pending Changes Clears Form | Derivation | BR-006 | The user clicks Delete and the current record has no unsaved changes | The form is cleared via the built-in clear action; no explicit delete-record command is issued | Ensures the form is reset cleanly when there is nothing to explicitly delete from the database |
| BRC-008 | List Button Enablement Gate | Constraint | BR-007 | The List button is not currently enabled in the form's current operating context | The LOV open action is silently suppressed | Prevents the LOV from being opened on a field that does not support it or at an inappropriate time |
| BRC-009 | Print Button Enablement Gate | Constraint | BR-008 | The Print button is not currently enabled in the form's current operating context | The print flow is silently suppressed | Prevents the print placeholder from being entered outside of a printable context |
| BRC-010 | Print Logic Placeholder | Constraint | BR-008 | The Print button is enabled and clicked | The inner code body executes a no-operation (`NULL`); no print action occurs | Signals to developers of derived forms that print logic must be implemented here before the button produces output |
| BRC-011 | Exit in Query Mode: Immediate Exit | Constraint | BR-002 | The user clicks Exit and the form is currently in query mode | The form is closed immediately via the built-in exit action without any confirmation prompt | Allows a clean, prompt exit when the user is in search/query mode with nothing committed or at risk of loss |
| BRC-012 | Unsaved Changes Confirmation Before Exit | Validation | BR-002 | The user clicks Exit and there are unsaved changes on the form (and the form is not in query mode) | The system displays the confirmation dialog *"Entered data will not be Saved"*; the form is closed only if the user confirms | Prevents the user from accidentally discarding unsaved work when exiting the form (see WF-001) |
| BRC-013 | Exit Without Unsaved Changes: Direct Close | Constraint | BR-002 | The user clicks Exit and there are no unsaved changes (and the form is not in query mode) | The form is closed immediately via the built-in exit action with no confirmation prompt | Provides a friction-free exit when there is nothing to protect |
| BRC-014 | Form Maximization on Startup | Derivation | BR-001 | The form is opened by the user or by the runtime | The application desktop and main form window are both maximised to fill the entire display without any user action | Ensures a consistent full-screen presentation on every form launch |
| BRC-015 | Print Destination Return Value - Screen | Constraint | BR-009 | The user presses the first button in the print destination dialog | The function returns 1 (representing Screen destination) | Allows the calling form logic to route the report output to the screen |
| BRC-016 | Print Destination Return Value - Printer | Constraint | BR-009 | The user presses the second button in the print destination dialog | The function returns 2 (representing Printer destination) | Allows the calling form logic to route the report output to the printer |
| BRC-017 | Print Destination Return Value - Cancel | Constraint | BR-009 | The user presses any button other than the first two (or dismisses the dialog) | The function returns 3 (representing Cancel) | Signals the calling form to abort the print/report action |
| BRC-018 | Keyboard Navigation Delegation | Constraint | BR-010 | The user presses a keyboard navigation shortcut (next/previous item, block, or record) | The system delegates directly to the corresponding standard built-in navigation command; no custom logic is applied | Ensures uniform keyboard behaviour without override of platform navigation |
| BRC-019 | Exit with Unsaved Changes - Confirmation Required | Validation | BR-011 | The user clicks Exit and the form is not in query mode and has unsaved changes | The system displays the confirmation dialog *"Entered data will not be Saved"*; the form closes only if the user confirms | Prevents accidental loss of entered data when exiting the form |
| BRC-020 | Exit in Query Mode - Immediate Close | Constraint | BR-011 | The user clicks Exit and the form is in query mode | The form closes immediately via the built-in exit action with no confirmation prompt | Allows clean exit from query mode where no data is at risk |
| BRC-021 | Clipboard and Navigation: Direct Delegation | Constraint | BR-012 | The user clicks Cut, Copy, Paste, or uses a keyboard navigation shortcut | The corresponding standard built-in clipboard or navigation action is executed directly; no custom business logic is applied | Provides standard editing and navigation without introducing form-specific overrides |

**Total Business Rules Identified: 18**

---

## 6. Data Requirements

*This form is a reusable framework template; it captures no business-domain data of its own. The data entities described below reflect the form's own structural elements - the toolbar action buttons and the error display panel - together with the applicable reference data and lifecycle behaviour evidenced in the source.*

### 6.1 Business Entities and Relationships

*The form's two control blocks - the toolbar push-button panel and the error display panel - do not persist to a database table; both have a data source type of NONE. No base-table entity is evidenced in this form's source.*

#### Toolbar Button Panel (non-persistent control block)

The toolbar push-button block (`PB_BLK`) provides the standard action bar for all derived forms built on this template. It holds the interactive buttons - Exit, List (LOV), Insert, Delete, Cancel, Save, Print, Cut, Copy, and Paste - that drive all user-initiated operations. Because this block is not bound to a database table, no rows are read from or written to a database table by this block.

#### Error Display Panel (non-persistent control block)

The error display panel (`CB_ERR`) is a stacked canvas used to present error text to the user when an operation fails. It contains a single text item that holds the error message text. Like the toolbar block, this block has no database backing; it is a runtime-only display surface.

#### Entity Relationships

Both blocks in this form are non-persistent control structures with no base table and no database-backed relationships. No parent-child or master-detail relationship exists between them. There are no database entities to relate.

```
(No base-table entities - both blocks are non-persistent control structures)
```

### 6.2 Data Capture Requirements

*This form captures no business domain data. The only runtime data items are the button enablement state (driven by the calling context) and the error message text displayed on the error panel.*

#### Error Display Panel

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Error Message Text (`TXT_ERR`) | Auto-Populated | A runtime-only text area on the error display panel that holds the error message text presented to the user when an operation fails. Not entered by the user; populated by the system. | No user-entry validation applies; the field is display-only and system-populated. |

### 6.3 Reference Data

*Lists the master and configuration data referenced by this form.*

| Reference Data | Business Purpose | Used When |
| :--- | :--- | :--- |
| `AL_CONFIRM` alert (form-defined) | A two-button confirmation dialog used to prompt the user before performing a destructive action (cancel with unsaved changes, or delete a record). Returns 1 if the user confirms, 0 if the user declines. | When the user clicks Cancel while unsaved changes exist, or clicks Delete while the form has a changed status. |
| `AL_PRINT` alert (form-defined, used by `ASK_PRINT` program unit) | A three-button alert used to ask the user their preferred print destination (screen, printer, or cancel). Returns 1, 2, or 3 depending on which button is pressed. | When the print program unit (`ASK_PRINT`) is invoked by a calling form that activates print functionality. |
| `GENERAL` package (DPL attached library - `DPL.pld`) | Provides shared utility functions including `ASK_CONFIRM` (confirmation dialog) used by the cancel, delete, and exit flows. | Whenever a confirmation prompt is required before a potentially destructive action is committed. |

### 6.4 Data Lifecycle

*Describes how records are created, updated, and saved within this form's evidenced behaviour.*

**Creation**

- This template form does not create business-domain records directly. The Insert button navigates the form to a designated data-entry block (the target block name is a placeholder in the template code); derived forms supply the real block name to implement record creation.

**Updates**

- The form tracks whether any data has been changed since the last save. This unsaved-change status is checked by the Cancel, Delete, and Exit flows before proceeding, ensuring no edits are silently discarded.

**Save and Commit**

- When the user clicks Save (and the Save button is enabled), the form commits all pending changes to the database. The Save action is gated: if the Save button is not enabled in the current context, the action is silently suppressed.

**Retention and Audit**

- No audit columns, create/modify timestamps, or archival policy are evidenced in this form's source. Retention and audit behaviour is expected to be implemented in the derived forms that extend this template.

---

### 6.5 Excel Output Columns

This form does not use Excel download. No Excel export columns were identified in the form sources.

## 7. Glossary

*Definitions of terms, abbreviations, and acronyms used throughout this document.*

The following table defines key terms, acronyms, and abbreviations used throughout this Business Requirements Document.

| Term | Definition | Aliases | Related Terms |
| :--- | :--- | :--- | :--- |
| AL_CONFIRM | Oracle Forms alert object that displays a configurable caution message with Yes / No buttons | - | AL_ERRINFO, AL_NOTE, AL_PRINT |
| AL_ERRINFO | Oracle Forms alert object used to display error details at runtime | - | AL_CONFIRM, AL_NOTE |
| AL_NOTE | Oracle Forms alert object used to display informational messages at runtime | - | AL_CONFIRM, AL_ERRINFO |
| AL_PRINT | Oracle Forms alert object that prompts the user to choose a print destination (Screen / Printer / Cancel) | - | ASK_PRINT |
| ASK_CONFIRM | Shared library function that sets the AL_CONFIRM alert message at runtime and returns 1 (Yes) or 0 (No) | GENERAL.ASK_CONFIRM | AL_CONFIRM, ASK_PRINT |
| ASK_PRINT | Form-local function (and shared library function in DPL.pld) that displays the AL_PRINT alert and returns 1 (Screen), 2 (Printer), or 3 (Cancel) | GENERAL.ASK_PRINT | AL_PRINT, ASK_CONFIRM |
| CB_ERR | Oracle Forms control block used to hold the error message text displayed in the error information window | - | TXT_ERR, WIN_ERR |
| CN_ERR | Stacked canvas that contains the error information panel | - | WIN_ERR, CB_ERR |
| CN_MAIN | Content canvas that forms the main data-entry area of the form | - | WN_MAIN |
| CN_TOOL | Vertical toolbar canvas attached to WN_MAIN | - | PB_BLK, WN_MAIN |
| DMS | Dealer Management System - the integrated application suite for which this template provides the standard toolbar and navigation scaffold | - | DPL_MTPL |
| DPL | DPL program library (DPL.pld) - the shared PL/SQL library providing confirmation, print, error handling, and utility routines used across DMS forms | - | GENERAL, DPL.olb |
| DPL.olb | DPL Object Library - provides inherited visual attributes, property classes, window layout, and toolbar block definitions | - | DPL, OG_GROUP |
| DPL_MTPL | The DPL Multi-Purpose Template Oracle Forms module - the base scaffold from which all DMS data-entry forms are derived | - | DMS, DPL |
| FT_CANCEL | Form-level trigger that handles the Cancel toolbar action, including confirmation prompts | - | FT_SAVE, PB_CANCEL |
| FT_DEL | Form-level trigger for the Delete toolbar action; header logic is commented out; live body confirms and deletes the current record | - | PB_DEL |
| FT_INSERT | Form-level trigger that navigates to the base data block and creates a new record row | - | PB_INSERT |
| FT_LIST | Form-level trigger that opens the List of Values popup for the active field | - | PB_LIST, LOV |
| FT_PRINT | Form-level trigger placeholder for print logic; no active print code is present | - | PB_PRINT, ASK_PRINT |
| FT_SAVE | Form-level trigger that commits the current record when the Save button is enabled | - | PB_SAVE |
| GENERAL | The package namespace within DPL.pld that groups shared utility functions such as ASK_CONFIRM and DISP_TEXT | - | DPL, ASK_CONFIRM |
| LOV | List of Values - a popup selection list that allows users to pick a valid value for a field | - | FT_LIST, PB_LIST |
| OG_GROUP | Oracle Forms object group that bundles inherited triggers, visual attributes, and UI objects applied form-wide at runtime | - | DPL.olb |
| PB_BLK | Oracle Forms control block that holds the standard push-button toolbar items | - | CN_TOOL |
| PB_CANCEL | Cancel toolbar button - discards unsaved changes after user confirmation | - | FT_CANCEL |
| PB_COPY | Copy toolbar button - copies selected text from the active field | - | PB_CUT, PB_PASTE |
| PB_CUT | Cut toolbar button - cuts selected text from the active field | - | PB_COPY, PB_PASTE |
| PB_DEL | Delete toolbar button - deletes the current record after confirmation | - | FT_DEL |
| PB_ERR_EXIT | Button in the error information panel that closes the error window | - | CB_ERR, WIN_ERR |
| PB_EXIT | Exit toolbar button - closes the form and returns to the calling module | - | FT_CANCEL |
| PB_INSERT | Insert toolbar button - positions cursor in the data block for a new record | - | FT_INSERT |
| PB_LIST | List toolbar button - opens the LOV popup for the active field | - | FT_LIST, LOV |
| PB_PASTE | Paste toolbar button - pastes clipboard text into the active field | - | PB_CUT, PB_COPY |
| PB_PRINT | Print toolbar button - placeholder for form-specific print functionality | - | FT_PRINT, ASK_PRINT |
| PB_SAVE | Save toolbar button - commits the current record to the database | - | FT_SAVE |
| PLD | PL/SQL Library (`.pld`) - a compiled Oracle Forms program library containing shared procedures and functions | - | DPL |
| TXT_ERR | Text item in the CB_ERR block that displays error message content | - | CB_ERR, CN_ERR |
| WIN_ERR | Secondary Oracle Forms window that hosts the error information canvas | - | CN_ERR, CB_ERR |
| WN_MAIN | Primary application window displaying the main canvas and toolbar | - | CN_MAIN, CN_TOOL |

---

---

## 8. Technical Inventory

*Complete inventory of Oracle Forms components including blocks, items, triggers, canvases, and global variables.*

### 8.1 Form Architecture

**Form Module Details:**

- Form Name: dpl_mtpl (DPL_MTPL)
- Form Module XML Title: MODULE3
- Oracle Forms Version: 12c (Module version 122010400)
- Parent Object Library: -
- Attached Libraries: DPL (DPL.pld program library), D2KWUTIL (d2kwutil file library)
- First Navigation Block: -
- Console Window: WN_MAIN - Maruti DMS
- Compile Dependencies: Requires DPL.pld, WEBUTIL.olb, menu.mmx
- Source artifacts: `DPL_MTPL_fmb.xml`; DPL (DPL.pld program library)

### 8.1.1 Global Variables

| Global Variable | Data Type | Set Location | Purpose |
| :--- | :--- | :--- | :--- |
| APP_LOG | Character | Trigger PRE-FORM | Controls application performance logging; if set to 'Y' the form starts a stop-watch timer on pre-form to measure load time |
| DEALER | Character | Trigger WHEN-NEW-FORM-INSTANCE | Holds the current dealer map code used to filter city-type lookup by dealer |
| LOC_CD | Character | Trigger WHEN-NEW-FORM-INSTANCE | Holds the current location code used to filter the city-type lookup for the dealer's location |
| PARENT_GROUP | Character | Trigger WHEN-NEW-FORM-INSTANCE | Holds the parent group code; when not equal to '99999' the city type is pre-populated from the dealer-location table and the City Category field is locked |
| PRINCIPAL | Character | Trigger WHEN-NEW-FORM-INSTANCE, Trigger WHEN-BUTTON-PRESSED on CB_BLK.SEARCH | Holds the principal map code used to filter city-type and service-model record groups and passed as a parameter to the rate card report |
| REP_SERVER | Character | ProgramUnit CALL_REPORT | Holds the name of the Oracle Reports server used to submit the rate card report |
| USERID | Character | ProgramUnit VIEW_EXCEL_REP | Holds the current user identifier used to generate a unique filename for the Excel export |

### 8.1.2 Form Parameters

| Parameter | Data Type | Default | Description |
| :--- | :--- | :--- | :--- |
| - | - | - | No ModuleParameter entries found in vr_rate_card_fmb.xml |

**Total Parameters:** 0

### 8.2 Blocks

| Block Name | Query Data Source | Records | Q/I/U/D | Key Mode | Master-Detail Relationship |
| :--- | :--- | :--- | :--- | :--- | :--- |
| CB_BLK | - | 1 | N/N/N/N | Default | - |
| CB_ERR | - | 15 | N/N/N/N | Default | - |
| PB_BLK | - | 1 | N/N/N/N | Default | - |

**Total Blocks:** 3 (all control blocks - no database blocks)

### 8.2.1 Block WhereClause and OrderByClause

*Block query scope from DPL_MTPL_fmb.xml. **Description** explains filter and sort in business terms; **Order By** and **Where Clause** columns retain verbatim XML text for migration.*

| Block | Description | Order By (XML) | Where Clause (XML) |
| :--- | :--- | :--- | :--- |
| - | No blocks with WhereClause/OrderByClause in DPL_MTPL_fmb.xml | - | - |

### 8.3 Items Summary

*Complete item inventory from `DPL_MTPL_fmb.xml`.*

**Block counts:**

*Database / non-database counts derived from XML.*

| Block | Total Items | Database Items | Non-Database Items |
| :--- | ---: | ---: | ---: |
| CB_BLK | 6 | 0 | 6 |
| CB_ERR | 1 | 0 | 1 |
| PB_BLK | 13 | 0 | 13 |
| **Total** | **20** | **0** | **20** |

**Item detail (all 20 items):**

| Block | Item Name | DatabaseItem | Description |
| :--- | :--- | :--- | :--- |
| CB_BLK | COPY_RIGHT | false | Read-only display field that shows the copyright notice text populated by the system at form startup |
| CB_BLK | SEARCH | false | Generate Report push button - initiates mandatory-field validation and then calls the rate card report or Excel export routine |
| CB_BLK | SVAR_CD | false | Hidden field that holds the service variant code populated by the service model LOV selection; passed to the report as a filter parameter |
| CB_BLK | FUEL_TYPE | false | Read-only display field showing the fuel type automatically filled from the selected service model LOV |
| CB_BLK | CITY_TYPE | false | City category text field; allows the user to select a city category via LOV; mandatory before the report can be generated |
| CB_BLK | MODEL_TYPE | false | Service model text field; allows the user to select a service variant via LOV; mandatory before the report can be generated |
| CB_ERR | TXT_ERR | false | Text field that displays error messages in the error information window |
| PB_BLK | PB_ERR_OK | false | OK button in the error information panel that acknowledges and closes the error message window |
| PB_BLK | PB_ERR_EXIT | false | Exit button in the error information panel that closes the error window |
| PB_BLK | PB_PASTE | false | Paste button - pastes clipboard text into the active field |
| PB_BLK | PB_COPY | false | Copy button - copies the selected text from the active field |
| PB_BLK | PB_CUT | false | Cut button - cuts the selected text from the active field |
| PB_BLK | PB_PRINT | false | Print button - placeholder for form-specific print functionality (currently inactive - no print code) |
| PB_BLK | PB_SAVE | false | Save button - commits the current record to the database |
| PB_BLK | PB_CANCEL | false | Cancel button - discards unsaved changes after confirmation |
| PB_BLK | PB_DEL | false | Delete button - deletes the current record after confirmation |
| PB_BLK | PM_CONT | false | Container / navigation control item in the toolbar block |
| PB_BLK | PB_INSERT | false | Insert button - positions cursor to add a new record in the data block |
| PB_BLK | PB_LIST | false | List button - opens the list of values popup for the active field |
| PB_BLK | PB_EXIT | false | Exit button - closes the form and returns to the calling module |

### 8.4 List of Values

| LOV Name | Title | Record Group | Attached Block.Item |
| :--- | :--- | :--- | :--- |
| LV_CITY_TYPE | - | RG_CITY_TYPE | CB_BLK.CITY_TYPE |
| LV_SRV_MODEL | - | RG_SRV_MODEL | CB_BLK.MODEL_TYPE |

**Total LOVs:** 2

### 8.5 Alerts

| Alert Name | Title | Message Text | Calling Context |
| :--- | :--- | :--- | :--- |
| ALT_RATE | Caution | Do you want to enter Fixed Amount 'OR' FRT? | ProgramUnit: CALL_REPORT - displayed to the user to select rate type before generating the rate card report; returns 1 for Fixed Amount or 2 for FRT |
| AL_ERRINFO | Error | (set at runtime) | ProgramUnit: GENERAL.DISP_TEXT (via DPL.pld) - displays error details; invoked by shared library error-handling routines |
| AL_NOTE | Note | (set at runtime) | ProgramUnit: GENERAL.DISP_TEXT (via DPL.pld) - displays informational messages |
| AL_CONFIRM | Caution | (set at runtime) | Trigger: FT_CANCEL in Form, Trigger: FT_DEL in Form, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_EXIT - invoked via GENERAL.ASK_CONFIRM to prompt yes/no confirmation |
| AL_PRINT | Print | (set at runtime) | ProgramUnit: ASK_PRINT - invoked to prompt Screen / Printer / Cancel print destination selection |

**Total Alerts:** 5

### 8.6 Program Units

*Authoritative catalogue of **2 form-local program units**. PLD shared-library routines are in **Section 15**.*

| Program Unit | Type | Calls | Description |
| :--- | :--- | :--- | :--- |
| CALL_REPORT | Procedure | REPORT_CALL report object, :global.REP_SERVER | Generates the rate card report in PDF format; accepts principal, city type, service model, and fuel type as parameters; sets report properties, submits the job to the report server, and opens the result in the browser |
| VIEW_EXCEL_REP | Procedure | TEXT_IO, web.show_document, :global.USERID | Generates the rate card data as a CSV file; accepts a SQL query and column name; creates a temporary record group from the query, writes each row to a file on the server, and opens the file in the browser for download |

**Total Program Units:** 2

### 8.7 Triggers

**Item-Level Trigger Types (reference):**

| Trigger Name | Purpose |
| :--- | :--- |
| WHEN-VALIDATE-ITEM | Validates field when user leaves item |
| KEY-* | Keyboard actions - commit, exit, LOV, navigation |
| WHEN-NEW-BLOCK-INSTANCE | Initializes block on entry |
| WHEN-BUTTON-PRESSED | Executes button action |
| PRE-INSERT / POST-INSERT | Before/after record creation |
| WHEN-LIST-CHANGED | Dropdown selection changed |
| PRE-QUERY / POST-QUERY | Before/after query execution |
| WHEN-CHECKBOX-CHANGED | Checkbox toggled |
| WHEN-VALIDATE-RECORD | Validates entire record before leaving row |



**DPL library routines invoked from triggers and program units:**

| Routine | Type | Called From | Purpose |
| :--- | :--- | :--- | :--- |
| GENERAL.ASK_CONFIRM | Library routine | Form level, PB_BLK.PB_EXIT | Displays the AL_CONFIRM alert with a configurable caution message and returns 1 when the user clicks Yes or 0 when the user clicks No; used to confirm destructive or navigational actions |



### 8.7.1 Inactive / Commented-Out Trigger Register

*Triggers and field validations where XML source is `null;`, fully block-commented, or legacy code preserved but not executed. Do **not** migrate these as active business requirements.*

| Status | Block | Item | Trigger | Former behaviour (preserved in comments) | Disabled since / note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Commented out** | Form | - | FT_DEL | Initialized a global variable to 'D', navigated to the base table block, issued DELETE_RECORD and COMMIT_FORM, checked success via GENERAL.CHECK_FORM_FAILURE/GAP_CHK_BUILTIN, displayed a delete confirmation message, then cleared and reinitialised the form | Entire trigger header is block-commented; current live body navigates to block_name and calls DELETE_RECORD only - the commented header logic is not executed |
| **Null stub** | Form | - | FT_SAVE | Committed the current record to the database | Body is `null;` - no Save action in this form; Save is handled by the PB_SAVE item trigger |
| **Null stub** | Form | - | FT_CANCEL | Cleared the form after confirmation | Body is `null;` - no form-level cancel action; Cancel is handled by the PB_CANCEL item trigger |
| **Null stub** | Form | - | FT_INSERT | Navigated to the data block for a new record | Body is `null;` - no form-level insert; Insert button is disabled in this form |
| **Null stub** | Form | - | FT_LIST | Opened the LOV popup for the active field | Body is `null;` - List button is disabled in this form |
| **Null stub** | Form | - | FT_PRINT | (Placeholder - no prior code) | Body is `null;` - Print logic not implemented in this form |
| **Null stub** | Form | - | KEY-OTHERS | Suppressed all unhandled keyboard events | Body is `null;` - inherited via OG_GROUP; no key action is performed |
| **Null stub** | Form | - | KEY-NEXT-ITEM | Moved focus to the next item | Body is `null;` - form-level stub; overridden by active item-level KEY-NEXT-ITEM on CB_BLK.CITY_TYPE and CB_BLK.MODEL_TYPE |
| **Null stub** | Form | - | KEY-PREV-ITEM | Moved focus to the previous item | Body is `null;` - delegates to platform default |
| **Null stub** | Form | - | KEY-NXTBLK | Navigated to the next block | Body is `null;` - delegates to platform default |
| **Null stub** | Form | - | KEY-PRVBLK | Navigated to the previous block | Body is `null;` - delegates to platform default |
| **Null stub** | Form | - | KEY-DOWN | Moved to the next record | Body is `null;` - delegates to platform default |
| **Null stub** | Form | - | KEY-UP | Moved to the previous record | Body is `null;` - delegates to platform default |
| **Null stub** | Form | - | KEY-CLRFRM | Cleared all form fields | Body is `null;` - Clear Form key suppressed |
| **Null stub** | Form | - | KEY-COMMIT | Committed the current record | Body is `null;` - Commit key suppressed; committed via Save button only |
| **Null stub** | Form | - | KEY-EXIT | Exited the form | Body is `null;` - Exit handled by PB_EXIT button trigger |
| **Null stub** | Form | - | KEY-LISTVAL | Opened the LOV popup | Body is `null;` - LOV key suppressed; LOV opened via item-level KEY-NEXT-ITEM |
| **Null stub** | Form | - | ON-ERROR | Displayed error messages via alert | Body is `null;` - default Oracle Forms error handling used |
| **Null stub** | Form | - | ON-MESSAGE | Displayed informational messages | Body is `null;` - default Oracle Forms message handling used |
| **Null stub** | PB_BLK | PB_ERR_OK | WHEN-BUTTON-PRESSED | Acknowledged and closed the error window | Body is `null;` - inherited null stub; error window close logic not yet implemented |
| **Null stub** | PB_BLK | PB_ERR_EXIT | WHEN-BUTTON-PRESSED | Closed the error information window | Body is `null;` - inherited null stub |
| **Null stub** | PB_BLK | PB_LIST | WHEN-BUTTON-PRESSED | Opened the LOV popup for the active field | Body is `null;` - List button disabled for this form |
| **Null stub** | PB_BLK | PB_INSERT | WHEN-BUTTON-PRESSED | Created a new record in the data block | Body is `null;` - Insert button disabled for this form |
| **Null stub** | PB_BLK | PB_DEL | WHEN-BUTTON-PRESSED | Deleted the current record after confirmation | Body is `null;` - Delete button disabled for this form |
| **Null stub** | PB_BLK | PB_CUT | WHEN-BUTTON-PRESSED | Cut selected text from the active field | Body is `null;` - inherited null stub; clipboard action not active |
| **Null stub** | PB_BLK | PB_COPY | WHEN-BUTTON-PRESSED | Copied selected text from the active field | Body is `null;` - inherited null stub |


**Complete trigger inventory (35 total: 9 active, 26 inactive):**
*vr_rate_card_fmb.xml contains 35 Trigger elements (21 form-level, 14 item-level).*
*Active triggers have live executing code; inactive triggers are null stubs or fully block-commented.*

**Active triggers (9):**

| Trigger Name | Block | Item | Called From / Context | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| PRE-FORM | Form | - | Form level | Sets database application info (module name = vr_rate_card); starts a performance timer if :global.APP_LOG is set to 'Y' |
| WHEN-NEW-FORM-INSTANCE | Form | - | Form level | Maximises the application desktop and main window at startup; enables toolbar buttons; auto-populates city type from the dealer/location lookup when :global.PARENT_GROUP is not '99999'; otherwise navigates to the city type field; populates the copyright display field |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EXIT | PB_BLK.PB_EXIT | Closes the form; if form data has changed, prompts for confirmation before exiting |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CANCEL | PB_BLK.PB_CANCEL | Prompts for cancel confirmation if data has changed; clears the form on confirmation |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SAVE | PB_BLK.PB_SAVE | Commits the current record to the database when the Save button is enabled |
| WHEN-BUTTON-PRESSED | PB_BLK | PM_CONT | PB_BLK.PM_CONT | Navigates to the base data block (cb_lab) |
| WHEN-BUTTON-PRESSED | CB_BLK | SEARCH | CB_BLK.SEARCH | Validates that City Category and Service Model are both populated; displays an error if either is empty; calls CALL_REPORT passing principal, city type, service model code, and fuel type |
| KEY-NEXT-ITEM | CB_BLK | CITY_TYPE | CB_BLK.CITY_TYPE | Validates that the city category field is populated via GENERAL.CHECK_NULL before advancing to the service model field |
| KEY-NEXT-ITEM | CB_BLK | MODEL_TYPE | CB_BLK.MODEL_TYPE | Validates that the service model field is populated via GENERAL.CHECK_NULL before advancing to the Generate Report button |

**Inactive / null-stub triggers (26) - documented in Section 8.7.1:**

| Trigger Name | Block | Item | Status |
| :--- | :--- | :--- | :--- |
| FT_SAVE | Form | - | Inherited null stub (body overridden as null in this form) |
| FT_CANCEL | Form | - | Inherited null stub (body overridden as null in this form) |
| FT_INSERT | Form | - | Inherited null stub (body overridden as null in this form) |
| FT_DEL | Form | - | Partially commented out - see Section 8.7.1 for active portion |
| FT_LIST | Form | - | Inherited null stub |
| FT_PRINT | Form | - | Null placeholder - no print code active |
| KEY-OTHERS | Form | - | Null stub - suppresses unhandled key events |
| KEY-NEXT-ITEM | Form | - | Form-level null stub (overridden by item-level triggers on CB_BLK) |
| KEY-PREV-ITEM | Form | - | Null stub - delegates to platform default |
| KEY-NXTBLK | Form | - | Null stub - delegates to platform default |
| KEY-PRVBLK | Form | - | Null stub - delegates to platform default |
| KEY-DOWN | Form | - | Null stub - delegates to platform default |
| KEY-UP | Form | - | Null stub - delegates to platform default |
| KEY-CLRFRM | Form | - | Null stub - clears form key suppressed |
| KEY-COMMIT | Form | - | Null stub - commit key suppressed |
| KEY-EXIT | Form | - | Null stub - exit key handled by button trigger |
| KEY-LISTVAL | Form | - | Null stub - list-of-values key suppressed |
| ON-ERROR | Form | - | Null stub - default error handling used |
| ON-MESSAGE | Form | - | Null stub - default message handling used |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_ERR_OK | PB_BLK.PB_ERR_OK | Inherited null stub |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_ERR_EXIT | PB_BLK.PB_ERR_EXIT | Inherited null stub |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_LIST | PB_BLK.PB_LIST | Inherited null stub (list disabled for this form) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_INSERT | PB_BLK.PB_INSERT | Inherited null stub (insert disabled) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_DEL | PB_BLK.PB_DEL | Inherited null stub (delete disabled) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CUT | PB_BLK.PB_CUT | Inherited null stub |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_COPY | PB_BLK.PB_COPY | Inherited null stub |

### 8.8 Canvas and Window Inventory

**Windows:**

| Window | Title | Primary Canvas |
| :--- | :--- | :--- |
| WN_MAIN | Maruti DMS | CN_MAIN |
| WIN_ERR | Errors | - |

**Canvases:**

| Canvas | Type | Window |
| :--- | :--- | :--- |
| CN_MAIN | Content | - |
| CN_TOOL | Vertical Toolbar | WN_MAIN |
| CN_ERR | Stacked | WIN_ERR |

---

### 8.9 Editors

*No editors found in DPL_MTPL_fmb.xml.*

### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

#### 8.10.1 Visual Attributes (form-defined)

*15 VisualAttribute elements defined at form level (not inherited from DPL.olb).*

| Visual Attribute |
| :--- |
| VA_DISP |
| VA_LOV |
| VA_TRNI_DT |
| VA_TITLE |
| VA_ALERT |
| VA_BUTN |
| VA_TEXT |
| VA_MPROMPT |
| VA_OPROMPT |
| VA_MAND |
| VA_NUM |
| VA_DESC |
| VA_ICONIC_BUTN |
| VA_RB |
| VA_CB |

#### 8.10.2 Property Classes (form-defined)

*Form-local PropertyClass elements.*

| Property Class |
| :--- |
| PC_DESC |
| PC_SC_DATE |
| PC_TITLE |
| PC_FORMAT |
| PC_MR_BLK |
| PC_FORM |
| PC_DISP |
| PC_LOV |
| PC_DISP_DATE |
| PC_DISP_NUM |
| PC_DATE |
| PC_DTTIME |
| PC_CB |
| PC_ALERT |
| PC_MDATE |
| PC_RB |
| PC_WIND |
| PC_CANV |
| PC_BUTN |
| PC_TEXT |
| PC_MTEXT |
| PC_UTEXT |
| PC_MUTEXT |
| PC_NUM |
| PC_MNUM |
| PC_ICONIC_BUTN |
| PC_SCROLL |

#### 8.10.3 Object Groups

*Object groups bundle inherited triggers and visual objects applied form-wide at runtime.*

| Object Group Child | Type |
| :--- | :--- |
| KEY-OTHERS | Inherited trigger/object |
| KEY-NEXT-ITEM | Inherited trigger/object |
| KEY-PREV-ITEM | Inherited trigger/object |
| KEY-NXTBLK | Inherited trigger/object |
| KEY-PRVBLK | Inherited trigger/object |
| KEY-DOWN | Inherited trigger/object |
| KEY-UP | Inherited trigger/object |
| CN_ERR | Inherited trigger/object |
| VA_DISP | Inherited trigger/object |
| CB_ERR | Inherited trigger/object |
| VA_LOV | Inherited trigger/object |
| VA_TRNI_DT | Inherited trigger/object |
| VA_TITLE | Inherited trigger/object |
| VA_ALERT | Inherited trigger/object |
| VA_BUTN | Inherited trigger/object |
| VA_TEXT | Inherited trigger/object |
| VA_MPROMPT | Inherited trigger/object |
| VA_OPROMPT | Inherited trigger/object |
| VA_MAND | Inherited trigger/object |
| VA_NUM | Inherited trigger/object |
| VA_DESC | Inherited trigger/object |
| VA_ICONIC_BUTN | Inherited trigger/object |
| VA_RB | Inherited trigger/object |
| VA_CB | Inherited trigger/object |
| WN_MAIN | Inherited trigger/object |
| POP_MAIN | Inherited trigger/object |
| CN_MAIN | Inherited trigger/object |
| CN_TOOL | Inherited trigger/object |
| PB_BLK | Inherited trigger/object |
| AL_ERRINFO | Inherited trigger/object |
| AL_NOTE | Inherited trigger/object |
| AL_CONFIRM | Inherited trigger/object |
| WIN_ERR | Inherited trigger/object |
| AL_PRINT | Inherited trigger/object |
| FT_SAVE | Inherited trigger/object |
| FT_CANCEL | Inherited trigger/object |
| FT_INSERT | Inherited trigger/object |
| FT_DEL | Inherited trigger/object |
| FT_LIST | Inherited trigger/object |
| FT_PRINT | Inherited trigger/object |
| WHEN-NEW-FORM-INSTANCE | Inherited trigger/object |

### 8.11 DataSourceColumn Inventory

*No DataSourceColumns found in DPL_MTPL_fmb.xml.*

---

## 9. Object Library

*This section catalogues the Visual Attributes and Property Classes supplied by the shared DPL Object Library (`DPL.olb` / `DPL_olb.xml`) and available for subclassing within this form. The form itself defines these same objects locally (form-local copies); as no inheriting items were detected via the standard subclass attributes in the form XML, each Used By count is shown as 0.*

Source OLB file(s): DPL.olb, DPL_olb.xml

| Name | Type | Description | Used By (count) | Sample Items |
| ---- | ---- | ----------- | --------------- | ------------ |
| VA_CB | VisualAttribute | Visual attribute for check-box items | 0 | N/A |
| VA_RB | VisualAttribute | Visual attribute for radio-button items | 0 | N/A |
| VA_ICONIC_BUTN | VisualAttribute | Visual attribute for iconic push-button items | 0 | N/A |
| VA_DESC | VisualAttribute | Visual attribute for description/display text items | 0 | N/A |
| VA_NUM | VisualAttribute | Visual attribute for numeric text items | 0 | N/A |
| VA_MAND | VisualAttribute | Visual attribute for mandatory text items | 0 | N/A |
| VA_OPROMPT | VisualAttribute | Visual attribute for optional-field prompts | 0 | N/A |
| VA_MPROMPT | VisualAttribute | Visual attribute for mandatory-field prompts | 0 | N/A |
| VA_TEXT | VisualAttribute | Visual attribute for standard text items | 0 | N/A |
| VA_BUTN | VisualAttribute | Visual attribute for push-button items | 0 | N/A |
| VA_ALERT | VisualAttribute | Visual attribute for alert/message display items | 0 | N/A |
| VA_TITLE | VisualAttribute | Visual attribute for screen title items | 0 | N/A |
| VA_TRNI_DT | VisualAttribute | Visual attribute for transaction-date items | 0 | N/A |
| VA_LOV | VisualAttribute | Visual attribute for LOV-backed items | 0 | N/A |
| VA_DISP | VisualAttribute | Visual attribute for read-only display items | 0 | N/A |
| PC_DESC | PropertyClass | Property class for description text items | 0 | N/A |
| PC_SC_DATE | PropertyClass | Property class for date items | 0 | N/A |
| PC_TITLE | PropertyClass | Property class for screen title text items | 0 | N/A |
| PC_FORMAT | PropertyClass | Property class for formatted text items | 0 | N/A |
| PC_MR_BLK | PropertyClass | Property class for multi-row block styling | 0 | N/A |
| PC_DISP | PropertyClass | Property class for display (read-only) text items | 0 | N/A |
| PC_LOV | PropertyClass | Property class for LOV-backed items | 0 | N/A |
| PC_FORM | PropertyClass | Property class for form-level settings | 0 | N/A |
| PC_DISP_DATE | PropertyClass | Property class for display date items | 0 | N/A |
| PC_DISP_NUM | PropertyClass | Property class for display numeric items | 0 | N/A |
| PC_DATE | PropertyClass | Property class for date entry items | 0 | N/A |
| PC_DTTIME | PropertyClass | Property class for date-and-time entry items | 0 | N/A |
| PC_CB | PropertyClass | Property class for check-box items | 0 | N/A |
| PC_ALERT | PropertyClass | Property class for alert items | 0 | N/A |
| PC_MDATE | PropertyClass | Property class for mandatory date items | 0 | N/A |
| PC_RB | PropertyClass | Property class for radio-button items | 0 | N/A |
| PC_WIND | PropertyClass | Property class for window settings | 0 | N/A |
| PC_CANV | PropertyClass | Property class for canvas settings | 0 | N/A |
| PC_BUTN | PropertyClass | Property class for push-button items | 0 | N/A |
| PC_TEXT | PropertyClass | Property class for standard text items | 0 | N/A |
| PC_MTEXT | PropertyClass | Property class for mandatory text items | 0 | N/A |
| PC_UTEXT | PropertyClass | Property class for uppercase text items | 0 | N/A |
| PC_MUTEXT | PropertyClass | Property class for mandatory uppercase text items | 0 | N/A |
| PC_NUM | PropertyClass | Property class for numeric items | 0 | N/A |
| PC_MNUM | PropertyClass | Property class for mandatory numeric items | 0 | N/A |
| PC_ICONIC_BUTN | PropertyClass | Property class for iconic push-button items | 0 | N/A |
| PC_SCROLL | PropertyClass | Property class for scroll-bar items | 0 | N/A |

---

## 10. Record Groups

*Record groups used to populate LOV selections in this form.*

| Record Group | Type | Used By LOV | Display Column | Return Column | Dynamic Bindings | Purpose | Where Used |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| RG_CITY_TYPE | Query | LV_CITY_TYPE | CITY_RPH_TYPE | CB_BLK.CITY_TYPE | Yes (:global.principal) | Populates the city category dropdown by retrieving the distinct city types available for the current principal from the dealer rate plan table | CB_BLK.CITY_TYPE (via LV_CITY_TYPE) |
| RG_SRV_MODEL | Query | LV_SRV_MODEL | SVAR_DESC | CB_BLK.MODEL_TYPE | Yes (:global.principal) | Populates the service model dropdown by retrieving distinct service variant descriptions, codes, and fuel types for the current principal | CB_BLK.MODEL_TYPE (via LV_SRV_MODEL) |

**Total Record Groups:** 2

---

## 11. Referenced Database Objects

*Database tables, views, and objects accessed by the form.*

**Block base-table mapping:**

| Block | Base Table | Primary Key Item | Database Item |
| :--- | :--- | :--- | :--- |
| CB_BLK | - | - | No |
| CB_ERR | - | - | No |
| PB_BLK | - | - | No |

**Database objects referenced in source (record group queries and trigger code):**

| Object | Schema | Used In | Description |
| :--- | :--- | :--- | :--- |
| vm_msil_rph | DMS | Record Group RG_CITY_TYPE | Provides distinct city category codes for the rate plan lookup, filtered by principal map code |
| vm_svar | DMS | Record Group RG_SRV_MODEL | Provides service variant descriptions and codes for the service model LOV, filtered by principal map code |
| gm_var | DMS | Record Group RG_SRV_MODEL | Joined to vm_svar to supply fuel type codes; only variants with a non-null fuel type are included |
| AM_DEALER_LOC | DMS | Trigger WHEN-NEW-FORM-INSTANCE | Used in the auto-populate query to derive the city type for the current dealer and location |
| GM_FOR | DMS | Trigger WHEN-NEW-FORM-INSTANCE | Joined with AM_DEALER_LOC to look up the city RPH type for the current dealer's franchise |

---

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure/Package Index

| Requirement ID | Procedure/Package | Purpose |
| -------------- | ----------------- | ------- |
| BR-002 | GENERAL.ASK_CONFIRM | Displays a two-button confirmation dialog before closing the form when unsaved changes exist |
| BR-004 | GENERAL.ASK_CONFIRM | Displays a two-button confirmation dialog before discarding unsaved changes on Cancel |
| BR-006 | GENERAL.ASK_CONFIRM | Displays a two-button confirmation dialog before deleting the current record |
| BR-009 | CALL_REPORT | Generates the rate card PDF report using the selected parameters and submits it to the report server |
| BR-009 | VIEW_EXCEL_REP | Exports the rate card data as a CSV file and opens it in the browser |

### 12.2 Procedure and Package Catalogue

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| GENERAL.ASK_CONFIRM | DPL Attached Library (`DPL.pld`) | FT_CANCEL (form trigger); FT_DEL (form trigger); WHEN-BUTTON-PRESSED on PB_BLK.PB_EXIT (item trigger) | Renders a two-button confirmation alert, sets the alert message to the caller-supplied text, and returns 1 if the user confirms or 0 if the user declines. Used to gate destructive actions (cancel, delete, exit) behind explicit user approval. |
| CALL_REPORT | Form-local Program Unit (PROCEDURE) | WHEN-BUTTON-PRESSED on CB_BLK.SEARCH - after mandatory-field validation passes | Finds the REPORT_CALL report object, sets report format to PDF, passes P_PRINCIPAL, P_CITY_TYPE, P_MODEL_TYPE, and P_FUEL_TYPE as report parameters, sets the report server from :global.REP_SERVER, assigns the report filename (vr_rate_card), runs the report object, and opens the resulting job URL in the browser. |
| VIEW_EXCEL_REP | Form-local Program Unit (PROCEDURE) | WHEN-BUTTON-PRESSED on CB_BLK.SEARCH - as an alternative to CALL_REPORT for CSV export | Creates a temporary record group from the supplied SQL query, iterates over all rows (up to 65,535), writes each row as a line in a CSV file on the server using the caller-provided column name, and opens the file URL in the browser. Uses :global.USERID to generate a unique filename. |

---

## 13. Package Procedure Specifications

*NO PCK files found - no ``*.pck`` source files were discovered in ``/app/workspace/vr_rate_card-88ea8a6ece84/in``. Package specifications cannot be generated without uploaded PCK sources.*

---

## 14. Database Package Catalogue

*No PCK files found - no `*.pck` source files were discovered in `/app/workspace/vr_rate_card-88ea8a6ece84/in`. The database package catalogue is empty; required table shells are provided below.*

**Database Package Catalogue:**

| Source File (.pck) | Package | Routine Name | Type | Definition (signature / excerpt) | Called From | Purpose |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| - | - | - | - | No database package source files found | - | No database packages found in source |

**Function Return Values:**

| Function | Returns | Values | Description |
| :--- | :--- | :--- | :--- |
| - | - | - | No database package functions found in source |

---

## 15. PLD Procedure Call Sites

*Behaviour descriptions derived from ``DPL.pld``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ASK_CONFIRM | Function | Function(confirm_msg VARCHAR2) RETURN NUMBER | Trigger: FT_CANCEL in Form, Trigger: FT_DEL in Form, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_EXIT | Displays the AL_CONFIRM alert with the supplied confirmation message; returns 1 if the user clicks Yes or 0 if the user clicks No. Invoked before discarding changes (cancel), before deleting a record, and before closing the form to prevent accidental data loss. |
| ASK_PRINT | Function | Function(confirm_msg VARCHAR2) RETURN NUMBER | ProgramUnit: ASK_PRINT | Sets the AL_PRINT alert message text at runtime and displays the print-destination dialog; returns 1 for Screen, 2 for Printer, or 3 for Cancel. Used by the form-local ASK_PRINT wrapper to offer the user a choice of print output. |

**Total Active Routines:** 2 of 24 in DPL.pld source

---

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| ID | Service Name | Database Object | Input Parameters | Output | Business Function | API Endpoint Suggestion |
| -- | ------------ | --------------- | ---------------- | ------ | ----------------- | ----------------------- |
| MS-001 | Confirmation Dialog Service | GENERAL.ASK_CONFIRM (DPL library) | `confirm_msg` (text of the question to display to the user) | Integer: 1 (confirmed) or 0 (declined) | Presents a two-button confirmation prompt to the user before a destructive action (cancel, delete, or exit with unsaved changes) is executed; returns the user's decision to the calling flow | `POST /api/v1/ui/confirm-dialog` |
| MS-002 | Print Destination Selection Service | ASK_PRINT (form-local program unit) / GENERAL.ASK_PRINT (DPL library) | `confirm_msg` (text of the print-destination question to display) | Integer: 1 (first destination), 2 (second destination), 3 (cancel) | Presents a three-option print-destination dialog to the user and returns their selection; used by print/report flows in derived forms to determine where output should be sent | `POST /api/v1/ui/print-destination` |

**Total Microservices Identified: 2**

---

## 17. Workflows

| ID | Workflow Name | Trigger Event | Steps | Decision Points | End State |
| -- | ------------- | ------------- | ----- | --------------- | --------- |
| WF-001 | Unsaved Changes Protection | User clicks Cancel or Exit button while unsaved changes exist on the form | 1. Button clicked; 2. System detects unsaved changes; 3. Confirmation dialog displayed (*"Entered data will not be Saved"*); 4a. User confirms -> form cleared / closed; 4b. User declines -> form remains open | Is the button enabled? -> Yes/No. Are there unsaved changes? -> Yes/No. Does the user confirm? -> Yes/No. | Form closed (exit confirmed), form cleared (cancel confirmed), or form remains open (user declined) |
| WF-002 | Record Deletion with Confirmation | User clicks Delete button while the Delete button is enabled | 1. Delete button clicked; 2. Form validation temporarily suspended; 3. System navigates to data block; 4a. If unsaved changes: confirmation dialog displayed (*"Are you sure to Delete"*) -> user confirms -> record deleted; 4b. If no unsaved changes: form cleared via built-in clear; 5. Form validation re-enabled | Is the Delete button enabled? -> Yes/No. Does the current record have unsaved changes? -> Yes/No. Does the user confirm deletion? -> Yes/No. | Record deleted and form cleared (confirmed), or form cleared directly (no pending changes), or record retained and form remains open (user declined) |
| WF-003 | Form Initialization | Form opened by the user or called from another form | 1. Runtime starts; 2. Application MDI window maximized; 3. Main form window maximized | None - executes unconditionally | Form displayed in full-screen maximized state |

**Total Workflows Identified: 3**

---

## 18. PLD-Backed Logic

*Maps shared library routines to their business function and suggested API contracts.*

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | ASK_CONFIRM | Business Logic | Trigger: FT_CANCEL in Form, Trigger: FT_DEL in Form, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_EXIT | /api/v1/pld/ask_confirm | When a destructive action is requested, prompts the user for yes/no confirmation before proceeding |
| PLD-002 | ASK_PRINT | Business Logic | ProgramUnit: ASK_PRINT | /api/v1/pld/ask_print | When a print action is initiated, prompts the user to choose Screen, Printer, or Cancel as the output destination |

---

---

## 19. PCK-Backed Logic

*NO PCK files found - no ``*.pck`` source files were discovered in ``/app/workspace/vr_rate_card-88ea8a6ece84/in``. PCK-backed logic cannot be generated without uploaded PCK sources.*

---

## 20. System Interfaces

### 20.1 Database Integrations

| Interface Name | Type | Purpose | Data Flow | Error Handling |
| -------------- | ---- | ------- | --------- | -------------- |
| Oracle Forms Runtime - Commit | Built-in Forms commit | Persists all pending data changes to the database when the user clicks Save | Form -> Database (write) | Standard Oracle Forms commit error handling; forms runtime raises an error if the commit fails |
| Oracle Forms Runtime - Clear Form | Built-in Forms clear | Resets all form fields to their initial state on Cancel or after a no-pending-change Delete | Form-internal | N/A - no database call; runtime-only operation |
| Oracle Forms Runtime - Delete Record | Built-in Forms delete | Removes the current record from the database on confirmed deletion | Form -> Database (delete) | Standard Oracle Forms delete error handling; forms runtime raises an error if the delete fails |

### 20.2 External System Integrations

No external system integrations are evidenced in this form's source. The form has no cross-form calls, no HOST commands, no external file references, and no interface table references. All interactions are within the Oracle Forms runtime and the attached DPL library.

| System Name | Integration Type | Purpose | Protocol | Endpoint | Data Exchange | Success / Error Codes |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| - | - | No external system integrations evidenced in source | - | - | - | - |

### 20.3 Report Integrations

No report integrations are evidenced in this form's source as standalone declarative Report objects or static PL/SQL report calls. The `CALL_REPORT` program unit uses the `REPORT_CALL` report object handle (set via `Set_Report_Object_Property`) to run the `vr_rate_card` report file at runtime; the filename is assigned dynamically via `Set_Report_Object_Property(repid, REPORT_FILENAME, 'vr_rate_card')` rather than as a static string literal in the form XML, so no `report_filenames[]` entry is generated by the static extractor.

| Report Name | Report Server | Parameters | Output Format | Trigger |
| :--- | :--- | :--- | :--- | :--- |
| - | - | - | - | No static report filename declarations in form XML; report called dynamically via CALL_REPORT program unit |

---

### 20.3.1 Parameters Passed to the Report

This form does not pass parameters to an Oracle Report. No report parameters were identified in the form sources.

## 21. Procedure and Function Business Rule Catalogue

End-to-end business requirement specification for every stored procedure and function referenced by the DPL_MTPL form.

### 21.1 Catalogue Index

3 procedures/functions - each SP ID links to its detailed specification in Section 21.2.

| SP Index | Routine Name |
| :--- | :--- |
| [SP-001](#SP-001--GENERAL.ASK_CONFIRM) | GENERAL.ASK_CONFIRM |
| [SP-002](#SP-002--CALL_REPORT) | CALL_REPORT |
| [SP-003](#SP-003--VIEW_EXCEL_REP) | VIEW_EXCEL_REP |

---

### 21.2 Detailed Specifications

#### SP-001 - GENERAL.ASK_CONFIRM

**Invoked From:**

- DPL_MTPL_fmb.xml [Trigger: FT_CANCEL]
- DPL_MTPL_fmb.xml [Trigger: FT_DEL]
- DPL_MTPL_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

N/A

---

**Purpose**

Presents a configurable confirmation message to the user via the `AL_CONFIRM` alert dialog and returns a numeric flag indicating whether the user chose to proceed. Callers use the return value to decide whether to continue or abort a destructive or irreversible action (such as a cancellation or deletion).

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| confirm_msg | Caller-supplied confirmation message text | VARCHAR2 |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Set the text of the `AL_CONFIRM` alert to the caller-supplied `confirm_msg` string, so the dialog displays the contextually relevant confirmation question.
- Step 2 - Display the `AL_CONFIRM` alert to the user and capture which button was pressed.
- Step 3 - If the user pressed the first button (`ALERT_BUTTON1`), return `1` (confirmed/proceed).
- Step 4 - If the user pressed any other button, return `0` (declined/abort).

---

**Decision Points**

DP-001

Condition:
The user pressed the first alert button (`ALERT_BUTTON1`) in the confirmation dialog.

TRUE:
Return `1` - the caller interprets this as user confirmation to proceed with the operation.

FALSE:
Return `0` - the caller interprets this as user refusal; the triggering operation (cancel, delete, etc.) is aborted.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The confirmation dialog is always driven by the single named alert `AL_CONFIRM`; the alert's message text is overwritten with the caller-supplied string before display, making the alert reusable across all confirmation contexts.
- SBR-002 - Only a press of `ALERT_BUTTON1` constitutes an affirmative response; any other button (including dismissal via button 2 or button 3) is treated as a refusal.

---

**Implementation Logic**

```plsql
FUNCTION ASK_CONFIRM( confirm_msg VARCHAR2)
                                      RETURN  NUMBER IS

    p_alert_name varchar2(10) := 'AL_CONFIRM' ;
    p_albtn_pressed number;
BEGIN
   set_alert_property(p_alert_name,alert_message_text,confirm_msg); 
   p_albtn_pressed := show_alert(p_alert_name);

   IF ( p_albtn_pressed = ALERT_BUTTON1 ) THEN
      return (1);
   ELSE
      return(0);
   END IF;
RETURN NULL; END;
```

---

#### SP-002 - CALL_REPORT

**Invoked From:**

- vr_rate_card_fmb.xml [Trigger: WHEN-BUTTON-PRESSED on CB_BLK.SEARCH - after mandatory-field validation passes]

---

**Screen:**

CN_MAIN / WN_MAIN

---

**Purpose**

Generates the rate card report in PDF format for the selected parameters (principal, city type, service model code, and fuel type) and presents the result in the user's browser. It uses the Oracle Reports object `REPORT_CALL` defined in the form, configures report properties at runtime, submits the report job to the report server identified by the global variable `REP_SERVER`, and opens the generated job result as a browser document.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| p_principal | :global.PRINCIPAL global variable | VARCHAR2 |
| p_city_type | :CB_BLK.CITY_TYPE item value | VARCHAR2 |
| p_model_type | :CB_BLK.MODEL_TYPE item value | VARCHAR2 |
| p_fuel_type | :CB_BLK.FUEL_TYPE item value | VARCHAR2 |

**Output Parameters**

No formal output parameters; result is displayed in the browser via `web.show_document`.

---

**Dependencies**

- REPORT_CALL - Oracle Reports report object defined in the form
- :global.REP_SERVER - identifies the Oracle Reports server

---

**Step-by-Step Business Logic**

- Step 1 - Locate the report object `REPORT_CALL` in the form using `Find_Report_Object`.
- Step 2 - Set the report output format to PDF.
- Step 3 - Set the report parameters: P_PRINCIPAL, P_CITY_TYPE, P_MODEL_TYPE, P_FUEL_TYPE, plus REPORT_DESTYPE=FILE, MODE=BITMAP, BLANKPAGES=NO.
- Step 4 - Set the report server to the value in :global.REP_SERVER.
- Step 5 - Set the report filename to `vr_rate_card`.
- Step 6 - Submit the report job using `RUN_REPORT_OBJECT`; capture the job ID returned.
- Step 7 - Open the report result URL in the browser using `web.show_document` with the job ID appended to the report server URL.

---

**Decision Points**

No explicit decision points in the active code path; the report is always submitted when the procedure is called.

---

**Database Interactions**

The procedure does not perform direct SQL operations; the rate card data is retrieved by the Oracle Reports engine (`vr_rate_card.rdf`) during report execution on the server.

---

**Business Rules**

- SBR-001 - The report is always formatted as PDF before submission; callers cannot override the output format.
- SBR-002 - The report server name is always taken from the runtime global variable :global.REP_SERVER, allowing the server to be configured without recompiling the form.

---

**Implementation Logic**

```plsql
PROCEDURE Call_Report(p_principal varchar2,p_city_type varchar2,p_model_type varchar2,p_fuel_type varchar2) IS
	repid			REPORT_OBJECT;
	lv_rep			VARCHAR2(100);
	lv_report_name		VARCHAR2(50);
	lv_server		VARCHAR2(20) := :global.rep_server;
	l_AlertId		ALERT;
	lv_param		VARCHAR2(100);
	lv_report		varchar2(2000);
	lv_print		varchar2(2000);
Begin
	repid := Find_Report_Object('REPORT_CALL');
	lv_report_name := 'vr_rate_card';
	Set_Report_Object_Property(repid,Report_Desformat,'PDF');
	Set_Report_Object_Property(repid,Report_Other,
		' P_PRINCIPAL='||to_number(p_principal)||
		' P_CITY_TYPE='||p_city_type||
		' P_MODEL_TYPE='||p_model_type||
		' P_FUEL_TYPE='||p_fuel_type||
		' REPORT_DESTYPE =FILE'||
		' MODE=BITMAP BLANKPAGES=NO');
	Set_Report_Object_Property(repid,Report_Server,lv_server);
	Set_Report_Object_Property(repid,REPORT_FILENAME,lv_report_name);
	lv_rep := RUN_REPORT_OBJECT(repid);
	web.show_document('/reports/rwservlet/getjobid'||
		substr(lv_rep,instr(lv_rep,'_',-1)+1)||'?'||'server='||lv_server,'_blank');
END;
```

---

#### SP-003 - VIEW_EXCEL_REP

**Invoked From:**

- vr_rate_card_fmb.xml [ProgramUnit: VIEW_EXCEL_REP - available for invocation from WHEN-BUTTON-PRESSED on CB_BLK.SEARCH or other report/export flows]

---

**Screen:**

CN_MAIN / WN_MAIN

---

**Purpose**

Exports a query result set as a CSV file and opens the file in the user's browser for download. It creates a temporary in-memory record group from the supplied SQL query, iterates over all result rows (up to 65,535), writes each row to a file on the application server, and serves the file to the browser. The file is named using the current user identifier (:global.USERID) combined with the current date and time to ensure uniqueness.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| p_file_name | Optional caller-supplied filename (defaults to NULL; system generates name from :global.USERID) | VARCHAR2 |
| p_query | SQL SELECT statement used to populate the export record group | VARCHAR2 |
| p_column_name | Name of the record group column to be written to each CSV row | VARCHAR2 |

**Output Parameters**

No formal output parameters; result file is opened in the browser via `web.show_document`.

---

**Dependencies**

- TEXT_IO - Oracle Forms built-in file I/O package
- web.show_document - Oracle Forms built-in to open a URL in the browser
- :global.USERID - user identifier for filename generation
- /reports/DMS/excelpath.txt - server-side configuration file that provides the URL path for the exported file

---

**Step-by-Step Business Logic**

- Step 1 - Generate the output filename using :global.USERID combined with the current date and time (YYYYMMDDHHMISS) and appending `.csv`.
- Step 2 - If the generated path contains spaces, redirect the file to the C: drive root.
- Step 3 - Delete any existing in-memory record group named `DataRecordSet`.
- Step 4 - Create a new record group `DataRecordSet` from the supplied SQL query and populate it.
- Step 5 - If the row count exceeds 65,536, truncate to 65,535 rows and display a warning message.
- Step 6 - Read the URL path from the server configuration file `/reports/DMS/excelpath.txt`.
- Step 7 - Open the output file on the server for writing; iterate over all rows in the record group, writing the value of the specified column to each line.
- Step 8 - Close the file and open the server URL in the browser using `web.show_document`.

---

**Decision Points**

DP-001

Condition:
The generated file path contains spaces in one of the directory names.

TRUE:
The file is redirected to `C:\` (the root of the C drive) and the user is shown a message that the file will be stored there.

FALSE:
The file is written to the originally generated path.

DP-002

Condition:
The row count in the record group exceeds 65,536.

TRUE:
The row count is capped at 65,535 and a warning message is displayed before export continues.

FALSE:
All rows are exported.

---

**Database Interactions**

The procedure executes a dynamic SELECT query (supplied via `p_query`) using `Create_Group_From_Query` - this query runs against the database at runtime and its results populate the temporary record group for CSV export.

---

**Business Rules**

- SBR-001 - The maximum number of rows exported to a single CSV file is 65,535; rows beyond this limit are silently truncated after a user warning.
- SBR-002 - The output filename always incorporates the current user's identifier and the current timestamp to ensure uniqueness and prevent overwriting a previous export.

---

**Implementation Logic**

```plsql
PROCEDURE view_excel_rep(p_file_name VARCHAR2 DEFAULT NULL,
			 p_query VARCHAR2,
			 p_column_name VARCHAR2)
IS
  rg_name		VARCHAR2(40) := 'DataRecordSet';
  rg_id			RecordGroup;
  gc_id			GroupColumn;
  urlFile1		TEXT_IO.FILE_TYPE;
  the_rowcount		NUMBER;
  vcfile		varchar2(150);
  lv_user		varchar2(150);
  v_string		varchar2(5000);
  FILENAME		VARCHAR2(4000);
  MYFILE		TEXT_IO.FILE_TYPE;
  urlFile		TEXT_IO.FILE_TYPE;
  urlPath		VARCHAR2(5000);
  l_alert		NUMBER;
  server_file		VARCHAR2(2000);
  file_transfer_bool	BOOLEAN;
  formserverpath	VARCHAR2(2000);
begin
  lv_user := name_in(':global.userid');
  vcFile := lv_user||To_Char(Sysdate,'YYYYMMDDHHMISS');
  vcFile := vcFile||'.csv';
  if vcFile is null then null;
  else filename := vcFile;
  end if;
  If instr(FILENAME,' ') > 0 then
    FILENAME := 'C:\'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
    Message('File cannot be saved in the specified path... File will be stored in C drive as default.');
    message('  ');
  end if;
  rg_id := Find_Group( rg_name );
  IF NOT Id_Null(rg_id) THEN Delete_Group( rg_id ); END IF;
  rg_id := Create_Group_From_Query( rg_name, p_query );
  errcode := Populate_Group( rg_id );
  the_rowcount := Get_Group_Row_Count( rg_id );
  IF the_rowcount > 65536 THEN
    Message('Maximum number of rows in excel exceeded. It will truncate to 65535 rows.');
    Message('  '); CLEAR_MESSAGE;
    the_rowcount := 65535;
  END IF;
  server_file := '/iashome/ias/reports/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
  urlFile := Text_Io.Fopen('/reports/DMS/excelpath.txt','R');
  Text_Io.Get_Line(urlFile,urlPath);
  Text_Io.Fclose(urlFile);
  formserverpath := urlPath||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
  MYFILE := TEXT_IO.FOPEN(server_file, 'W');
  gc_id := Find_Column( rg_name||'.'||p_column_name);
  for total_loop IN 1..the_rowcount loop
    V_STRING := GET_GROUP_CHAR_CELL(gc_id, total_loop);
    text_io.put_line(myfile,v_string);
  end loop;
  text_io.fclose(myfile);
  web.show_document(formserverpath,'_blank');
end;
```

---

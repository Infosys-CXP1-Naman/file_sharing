# BUSINESS REQUIREMENTS DOCUMENT

## Table of Contents

- 1. Document Control
  - 1.1 Document Information
  - 1.2 Revision History
- 2. Executive Summary
  - Key Stakeholders
- 3. System Context
- 4. Functional Requirements
  - 4.1 Business Requirements
    - Requirement ID: BR-001
    - Requirement ID: BR-002
    - Requirement ID: BR-003
    - Requirement ID: BR-004
    - Requirement ID: BR-005
    - Requirement ID: BR-006
    - Requirement ID: BR-007
    - Requirement ID: BR-008
    - Business Scenarios - How replication differs by user choice
    - Requirement ID: BR-009
    - Business Scenarios - How discount replication differs by user choice
    - Requirement ID: BR-010
    - Requirement ID: BR-011
    - Requirement ID: BR-012
    - Business Scenarios - How save differs by ALL checkbox state
    - Requirement ID: BR-013
    - Requirement ID: BR-014
    - Requirement ID: BR-015
    - Requirement ID: BR-016
    - Requirement ID: BR-017
    - Requirement ID: BR-018
    - Requirement ID: BR-019
    - Requirement ID: BR-020
    - Requirement ID: BR-021
    - Requirement ID: BR-022
    - Business Scenarios - How the discount field changes by Dead Stock flag state
    - Requirement ID: BR-023
- 5. Business Rules Catalogue
- 6. Data Requirements
  - 6.1 Business Entities and Relationships
    - Dead Stock Register - PM_PART_DEAD_STOCK (via FT_SAVE / HDR_BLK.PB_SEARCH)
    - Part Variant - PM_PART_VAR (via FT_SAVE)
    - Entity Relationships
  - 6.2 Data Capture Requirements
    - Search Filters (Parts Operations User - before search)
    - Dead Stock Flag Review (Parts Operations User - after search)
    - Summary / Totals (System-Calculated - after search)
    - Session / Parameters
  - 6.3 Reference Data
  - 6.4 Data Lifecycle
  - 6.5 Excel Output Columns
- 7. Glossary
- 8. Technical Inventory
  - 8.1 Form Architecture
    - 8.1.1 Global Variables
    - 8.1.2 Form Parameters
  - 8.2 Blocks
    - 8.2.1 Block WhereClause and OrderByClause
  - 8.3 Items Summary
  - 8.4 List of Values
  - 8.5 Alerts
  - 8.6 Program Units
  - 8.7 Triggers
    - 8.7.1 Inactive / Commented-Out Trigger Register
  - 8.8 Canvas and Window Inventory
  - 8.9 Editors
  - 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups
    - 8.10.1 Visual Attributes (form-defined)
    - 8.10.2 Property Classes (form-defined)
    - 8.10.3 Object Groups
  - 8.11 DataSourceColumn Inventory
- 9. Object Library
- 10. Record Groups
- 11. Referenced Database Objects
- 12. Backend Procedures and Packages
  - 12.1 Main Flow Backend Procedure/Package Index
  - 12.2 Procedure and Package Catalogue
- 13. Package Procedure Specifications
- 14. Database Package Catalogue
- 15. PLD Procedure Call Sites
  - DPL.pld (`general`)
  - D2kwutil.pld (`WIN_API_DIALOG`)
  - D2kwutil.pld (`WIN_API_Shell`)
- 16. Microservice API Candidates
  - 16.1 Microservices with APIs
- 17. Workflows
- 18. PLD-Backed Logic
  - DPL.pld (`general`)
  - D2kwutil.pld (`Win_API`)
- 19. PCK-Backed Logic
- 20. System Interfaces
  - 20.1 Database Integrations
  - 20.2 External System Integrations
  - 20.3 Report Integrations
    - 20.3.1 Parameters Passed to the Report
- 21. Procedure and Function Business Rule Catalogue
  - 21.1 Catalogue Index
  - 21.2 Detailed Specifications
    - SP-001 - VIEW_EXCEL_REP
    - SP-002 - GENERAL.ASK_CONFIRM
    - SP-003 - GENERAL.CHECK_FORM_FAILURE
    - SP-004 - GENERAL.CHECK_NULL
    - SP-005 - GENERAL.DISP_TEXT
    - SP-006 - GENERAL.L_POP_LIST_ITEM
    - SP-007 - GENERAL.RAISE_ERROR
    - SP-008 - WIN_API_DIALOG.SELECT_PRINTER
    - SP-009 - WIN_API_SHELL.WINEXEC

## 1. Document Control

### 1.1 Document Information

| Field | Value |
| ----- | ----- |
| Document Title | PT_DEAD_STOCK_FLAG - Business Requirements Document |
| Form Module Name | PT_DEAD_STOCK_FLAG |
| Document Version | 1.0 |
| Date Created | August 13, 2026 |
| Author/Prepared By | BRD Agent |

### 1.2 Revision History

| Version | Date | Author | Description |
| --- | --- | --- | --- |
| 1.0 | August 13, 2026 | BRD Agent | Initial draft |

---

## 2. Executive Summary

*High-level overview of the pt_dead_stock_flag Dead Stock Flagging form, its purpose, and roles referenced in the module.*

The **pt_dead_stock_flag** Oracle Forms module is the Dealer Management System **Dead Stock Flagging** screen. A stock controller or branch manager opens this screen to identify and flag slow-moving or obsolete parts held at a dealer location. The user selects the dealer outlet, consignee, location, and part category, then initiates a search to retrieve the list of parts meeting the dead stock threshold for the chosen slab category. Each part can be individually flagged or unflagged as dead stock, a discount percentage and remarks can be assigned per part or applied in bulk, and the changes are saved - updating the dead stock register and the part variant records. The form also supports exporting the results to an Excel file and includes basic validations to ensure that location, dealer, consignee, and discount values are provided before the flagging is committed.

### Key Stakeholders

*Who uses pt_dead_stock_flag*

| Stakeholder | Role |
| :--- | :--- |
| **Stock Controller / Branch Manager** | **Primary interactive user** of the screen. Searches parts by dealer, location, and category; individually or bulk-flags parts as dead stock; assigns remarks and discounts; and saves the flagged list. |
| **Dealer / Outlet** | The business entity whose part inventory is being reviewed; does not interact with the screen directly but is identified through the consignee and location filters. |
| **Parts Master Data Owner** | Responsible for the parts catalogue from which the screen retrieves part numbers, descriptions, and stock quantities; does not interact with the screen directly. |

---

---

## 3. System Context

*Describes the pt_dead_stock_flag module's role within the DMS ecosystem, scope, process flow, and key integrations.*

The **pt_dead_stock_flag** module is the Dealer Management System **Dead Stock Flagging** screen. It is the operational entry point for identifying and recording obsolete or slow-moving parts at dealer locations, connecting the parts inventory data to the dead stock register and part variant records. Flagged parts feed into downstream reporting, stock write-off decisions, and discount management processes.

**System purpose:** Retrieve parts inventory for a selected dealer, consignee, and location, allow the user to flag or unflag individual or all parts as dead stock with associated remarks and discounts, validate mandatory inputs, and persist the dead stock classification to the parts register - as implemented in the pt_dead_stock_flag Oracle Forms module.

**In scope:**

- Filter parts by dealer outlet (consignee, dealer name, location) and part category using lookup lists
- Select a slab category (A or B) to determine the dead stock threshold for the search
- Search for parts meeting dead stock criteria and display results with current stock and pricing
- Flag or unflag individual parts as dead stock via per-row checkboxes
- Bulk-flag or unflag all displayed parts simultaneously using a single header checkbox
- Assign individual remarks and part discount percentages per part row
- Apply a common remark or discount to all parts (or only to rows without existing values) from the header
- Validate that consignee, dealer, and location are selected before saving
- Validate that discount percentages are in the range 15-100 when a part is flagged as dead stock
- Save dead stock flag changes to the dead stock register and update part variant records
- Search for a specific part number within the loaded results
- Export the dead stock results list to a CSV/Excel file for offline use
- Display an error window for validation failures

**Process Name:** Dead Stock Flagging

**Process Owner:** Stock Controller / Branch Manager

**Process Objective:** Select a dealer outlet, consignee, and location; search for parts meeting dead stock criteria; review and flag or unflag individual or all parts as dead stock with remarks and discounts; validate inputs; and save the classification to the dead stock register.

**Process Trigger:** A stock controller or branch manager needs to review and record dead stock parts for a dealer location, typically during periodic inventory review or stock management activity.

**Process Flow:**

The complete dead stock flagging process follows this sequence. Each step corresponds to Functional Requirements in Section 4.

```
STEP 1 ── SCREEN OPENS
         The stock controller opens the Dead Stock Flagging screen.
         The main window maximises and the part category dropdown is populated
         from the category master for the current principal.

STEP 2 ── SESSION CONTEXT CHECK
         The system retrieves the logged-in user's parent dealer group.
         If the user is an administrator (group 99999), save access may be adjusted.
         If the user is not found in the dealer master, an error is displayed.

STEP 3 ── CONSIGNEE SELECTION
         The user selects a consignee code from the consignee lookup list.
         The list is filtered by the logged-in user's authorised regions and principal.
         Consignee is mandatory; a null value raises a validation error.

STEP 4 ── DEALER SELECTION
         The user selects a dealer name from the dealer lookup list.
         The list is filtered to dealers belonging to the selected consignee and principal.
         Dealer is mandatory; a null value raises a validation error.

STEP 5 ── LOCATION SELECTION
         The user selects a location from the location lookup list, or chooses 'ALL'.
         The list is filtered by the selected consignee and dealer.
         Location is mandatory; a null value raises a validation error.
         ├── If 'ALL' is selected: part flagging is not permitted (save is blocked)
         └── If a specific location is selected: the search may proceed

STEP 6 ── SLAB CATEGORY SELECTION
         The user selects slab A or B from the slab dropdown.
         The selection determines the dead stock threshold applied to the search query.
         Slab parameter is updated; an error is shown if neither A nor B is chosen.

STEP 7 ── CATEGORY FILTER (OPTIONAL)
         The user optionally selects a part category to narrow the search results.
         If no category is chosen, all categories for the dealer are included.

STEP 8 ── PART NUMBER FILTER (OPTIONAL)
         The user may enter a specific part number before searching.
         This narrows results to a single part rather than the full dead stock list.

STEP 9 ── SEARCH EXECUTED
         The user clicks the Search button.
         The system queries the parts inventory using the dead stock package and
         populates the detail list with matching part numbers, descriptions,
         current stock quantities, and prices.

STEP 10 ── RESULTS REVIEWED
          The user reviews the list of parts returned, including their current stock
          and maximum retail price.

STEP 11 ── PART NUMBER SEARCH WITHIN RESULTS (OPTIONAL)
          The user may search for a specific part number within the loaded result set.
          The matching row is highlighted; a message is shown if the part is not found.

STEP 12 ── INDIVIDUAL DEAD STOCK FLAGGING
          The user checks or unchecks the dead stock flag for each individual part row.
          ├── If flagged (Y): the individual discount field becomes mandatory
          └── If unflagged (N): the discount field is disabled for that row

STEP 13 ── BULK FLAG / UNFLAG ALL (OPTIONAL)
          The user may toggle the 'flag all' checkbox to set all parts as dead stock or
          remove all dead stock flags at once.
          The system prompts for confirmation before applying the bulk action.
          The header discount field becomes mandatory when bulk-flagging is active.

STEP 14 ── REMARKS ENTRY (OPTIONAL)
          The user may enter a common remark in the header remarks field.
          The remarks editor can be opened for multi-line text entry.

STEP 15 ── APPLY REMARKS TO DETAIL ROWS (OPTIONAL)
          The user clicks the apply remarks button.
          The system prompts to confirm overwriting; copies the header remark to all
          detail rows, or only to rows that have no existing remark.

STEP 16 ── DISCOUNT ENTRY
          The user enters a part discount percentage in the header or per detail row.
          Discount must be between 15 and 100 for any part flagged as dead stock.

STEP 17 ── APPLY DISCOUNT TO DETAIL ROWS (OPTIONAL)
          The user clicks the apply discount button.
          The system prompts to confirm overwriting; copies the header discount to all
          detail rows, or only to rows that have no existing discount value.

STEP 18 ── SAVE VALIDATION
          The user clicks Save.
          The system validates:
          - Location is not 'ALL'
          - Discount is present and in range 15-100 for all flagged parts
          - Part details (root part number) can be retrieved from the parts master
          The save is blocked with an error message if any validation fails.

STEP 19 ── SAVE COMMITTED
          The system inserts or updates dead stock register records for each flagged part,
          updates the dead stock flag on the part variant records, and commits the transaction.

STEP 20 ── EXCEL EXPORT (OPTIONAL)
          The user clicks the Excel Report button.
          The system builds the dead stock query and exports results to a CSV file
          on the server; the file is opened in the browser for download.

STEP 21 ── CANCEL / CLEAR FORM (OPTIONAL)
          If the user clicks Cancel before saving, the system prompts to confirm
          discarding unsaved changes, then clears the form.

STEP 22 ── EXIT
          The user exits the form.
          If there are unsaved changes, a confirmation prompt is shown before closing.
```

**Major process interactions:**

- **Dealer location master** - provides the consignee, dealer, and location lookup data filtered by the logged-in user's authorised regions and principal
- **User dealer master** - determines the logged-in user's parent dealer group and administrator access level
- **Parts category master** - supplies the category filter list populated at form startup
- **Parts inventory and dead stock package** - executes the dead stock search query and returns matching parts with stock and pricing data
- **Parts master** - provides root part number lookup used during save to link parts in the dead stock register
- **Dead stock register** - the target table updated (insert or delete/re-insert) when parts are flagged or unflagged
- **Part variant records** - updated with the dead stock flag value when changes are saved
- **Excel/CSV export** - writes results to a server-side file and opens it in the browser for offline use

---

---

## 4. Functional Requirements

### 4.1 Business Requirements

#### Requirement ID: BR-001

**Requirement Title:** Form Initialisation - Session Tracking and Screen Setup

**Business Description:**
When a user opens the Dead Stock Flag form, the system registers the current session against the application module so that database administrators can monitor active usage. The form windows are maximised to fill the screen. The Category drop-down list is populated from the available product categories for the user's principal organisation, and the user's group membership is resolved so that certain administrative options can be conditionally enabled. The Discount on DRT fields in both the header and the detail section are highlighted with a mandatory visual style to indicate that they require a value before saving.

**Actors:** Parts Operations User

**Preconditions:**
- The user has a valid system session and has navigated to the Dead Stock Flag form.

**Main Flow:**

**Step 1 - Application session tracking registered**
Before the form becomes visible, the system registers the active session under the module name `pe_dead_stk_rep` so that database-level monitoring tools can identify this form as the source of current activity. Both the client-info and module attributes of the database session are set to `pe_dead_stk_rep` using Oracle built-in session-management calls that are not catalogued in Section 21.1.

**Step 2 - Windows maximised and Category list populated**
As the form opens, both the desktop window and the main application window are set to maximised state so the screen is fully utilised. The system then queries the product-category master for the current principal organisation and loads all available category descriptions and codes into the Category filter drop-down.

*Procedures called:*
- **GENERAL.L_POP_LIST_ITEM** ([SP-006](#SP-006--GENERAL.L_POP_LIST_ITEM)) - GENERAL.L_POP_LIST_ITEM - builds an in-memory named list by running a SELECT against the category master filtered to the current principal, then populates the Category list item on screen with those values.
    * **Step 1** - Accept the list name and the query text as inputs.
    * **Step 2** - Execute the supplied query to retrieve the category description and code pairs from the product category master for the current principal organisation.
    * **Step 3** - Load the retrieved rows into the named in-memory list structure, making the category options available for the drop-down.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| User identity resolved to a group membership | `WHEN-NEW-FORM-INSTANCE` - SELECT from AM_USER_DEALER_MASTER where user_id matches the logged-in user | When the form opens and the user's session is being initialised | Determines the user's group/parent-group affiliation so that any group-specific restrictions or options can be applied at form level | If no matching user record is found, the message *"user_id not found"* is displayed and the trigger continues; if any other database error occurs, *"error while fetching user details"* is displayed and the trigger continues |

*Business outcomes (errors, warnings, success, and status):*
- **BR-001-ES-01** - No group record found for the logged-in user - *"user_id not found"*; the form continues to open but the user's group context may be absent.
- **BR-001-ES-02** - Unexpected database error while looking up user group details - *"error while fetching user details"*; the form continues to open.

**Step 3 - Mandatory visual style applied to Discount on DRT fields**
After the user data is resolved, the system applies the mandatory visual style (cyan background, as defined in the `VA_MANDATORY` visual attribute) to the individual-level Discount on DRT field in the results grid and to the header-level Discount on DRT field, signalling to the user that these fields must be completed before the record can be saved.

**Alternative Flows:**
- **BR-001-AF-01** - (from Step 2) The commented-out `DEFAULT_VALUE` block at the top of `WHEN-NEW-FORM-INSTANCE` (COMMENTED OUT / INACTIVE - does not execute) contained test defaults for global variables including principal, parent group, dealer, and location codes; this code does not run in production.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Category (`CATG_CD`) | Optional | List item | N/A | Category master (PM_CATEGORY) | Category description / category code | Form open | Populated from PM_CATEGORY filtered to current principal organisation | N/A - population failure is silent; list may be empty |
| Discount on DRT - Header (`PART_DISCOUNT`) | Mandatory | Text | 6 characters | N/A | N/A | Form open | Visual attribute `VA_MANDATORY` applied at form open | Enforced at save time (see BR-006) |
| Discount on DRT - Detail (`IND_PART_DISCOUNT`) | Mandatory | Text/Number | 6 characters | N/A | N/A | Form open | Visual attribute `VA_MANDATORY` applied at form open | Enforced at save time (see BR-006) |

---

---

#### Requirement ID: BR-002

**Requirement Title:** Form Clear and User-Context Reset

**Business Description:**
When the user activates the Clear Form action, the system looks up the user's group membership, conditionally enables the Save button for administrative users, clears all data from the screen, and re-applies the mandatory visual style to the Discount on DRT fields so the display is consistent after the reset.

**Actors:** Parts Operations User

**Preconditions:**
- The form is open and the user wishes to reset all fields to blank.

**Main Flow:**

**Step 1 - User group membership re-queried**
The system queries the user-to-group-assignment table to find the group code that corresponds to the logged-in user, storing it internally for use in subsequent conditional logic.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| User identity resolved to a group membership | `KEY-CLRFRM` - SELECT from AM_USER_DEALER_MASTER where lower(user_id) matches lower(:global.userid) | When the user triggers the clear-form action | Determines whether the user is an administrative user so that the Save button can be conditionally shown or hidden | If no record is found (`NO_DATA_FOUND`), the message *"user_id not found"* is displayed; if any other database error occurs, *"error while fetching user details"* is displayed; in both cases the clear proceeds |

*Business outcomes (errors, warnings, success, and status):*
- **BR-002-ES-01** - No group record found for the logged-in user - *"user_id not found"*; the clear operation continues.
- **BR-002-ES-02** - Unexpected database error while looking up user details - *"error while fetching user details"*; the clear operation continues.

**Step 2 - Save button conditionally enabled for administrative users**
If the user belongs to the designated administrative group (internal group code 99999), the Save button is enabled so that this user can save flagging decisions. For all other users the Save button state is not changed by this trigger.

**Step 3 - Screen cleared and mandatory visual style re-applied**
All data entered on screen is cleared without validation. The mandatory visual style is then re-applied to both the individual Discount on DRT field in the results grid and the header-level Discount on DRT field.

**Alternative Flows:**
- **BR-002-AF-01** - (from Step 2) If the user is not in the administrative group, the Save button is not enabled by this trigger; its enabled/disabled state is governed by the property set at form design time or by other logic.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Discount on DRT - Header (`PART_DISCOUNT`) | Mandatory | Text | 6 characters | N/A | N/A | Form open | Visual attribute `VA_MANDATORY` re-applied after clear | N/A |
| Discount on DRT - Detail (`IND_PART_DISCOUNT`) | Mandatory | Text/Number | 6 characters | N/A | N/A | Form open | Visual attribute `VA_MANDATORY` re-applied after clear | N/A |

---

---

#### Requirement ID: BR-003

**Requirement Title:** Search Filter Validation - Consignee, Dealer, and Location Fields

**Business Description:**
When a user completes entry in any of the three key search filter fields - Consignee, Dealer, and Location - the system checks that the field has not been left blank. If the user tabs away from a required filter field without entering a value, an error message is shown and the action is blocked, preventing an incomplete search from being executed.

**Actors:** Parts Operations User

**Preconditions:**
- The Dead Stock Flag main screen is open and the user is entering search filter values.

**Main Flow:**

**Step 1 - Consignee value validated on departure**
When the user moves focus away from the Consignee field, the system checks that a consignee has been selected. If the field is empty, an error is shown and the user must supply a value before continuing.

*Screen: PART QUERY (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the message text in an alert box with the specified severity title and waits for the user to acknowledge it.
    * **Step 1** - Receive the message text and the severity title as inputs.
    * **Step 2** - Select the appropriate alert template based on whether the severity is "Error" or another level.
    * **Step 3** - Set the alert title and message text on the selected template.
    * **Step 4** - Display the alert and wait for the user to dismiss it.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Consignee is not blank | `WHEN-VALIDATE-ITEM` on HDR_BLK.CONSG_CD - checks whether the Consignee field is empty | When the user tabs away from the Consignee field | Ensures a consignee is always selected before a search can proceed | *"Consignee Code cannot be Null"* is displayed; the trigger aborts and focus stays on the Consignee field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-ES-01** - Consignee field left blank - *"Consignee Code cannot be Null"*; field entry is blocked until a value is provided.

**Step 2 - Dealer value validated on departure**
When the user moves focus away from the Dealer field, the system checks that a dealer has been selected. If the field is empty, an error is displayed.

*Screen: PART QUERY (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the error message in an alert box (same routine as Step 1).
    * **Step 1** - Receive the message text and the severity title as inputs.
    * **Step 2** - Select the appropriate alert template based on whether the severity is "Error" or another level.
    * **Step 3** - Set the alert title and message text on the selected template.
    * **Step 4** - Display the alert and wait for the user to dismiss it.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Dealer is not blank | `WHEN-VALIDATE-ITEM` on HDR_BLK.DEALER_NAME - checks whether the Dealer field is empty | When the user tabs away from the Dealer field | Ensures a dealer is always identified before a search can proceed | *"Dealer Name cannot be Null"* is displayed; the trigger aborts and focus stays on the Dealer field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-ES-02** - Dealer field left blank - *"Dealer Name cannot be Null"*; field entry is blocked until a value is provided.

**Step 3 - Location value validated on departure**
When the user moves focus away from the Location field, the system checks that a location has been entered. If the field is empty, an error is displayed.

*Screen: PART QUERY (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the error message in an alert box (same routine as Steps 1-2).
    * **Step 1** - Receive the message text and the severity title as inputs.
    * **Step 2** - Select the appropriate alert template based on whether the severity is "Error" or another level.
    * **Step 3** - Set the alert title and message text on the selected template.
    * **Step 4** - Display the alert and wait for the user to dismiss it.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Location is not blank | `WHEN-VALIDATE-ITEM` on HDR_BLK.LOC_CD - checks whether the Location field is empty | When the user tabs away from the Location field | Ensures a location is always selected before a search can proceed | *"Location cannot be Null"* is displayed; the trigger aborts and focus stays on the Location field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-ES-03** - Location field left blank - *"Location cannot be Null"*; field entry is blocked until a value is provided.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Consignee (`CONSG_CD`) | Mandatory | Text item | N/A | Consignee list (LV_CONSG / RV_CONSG) | Consignee code | Form open | Must not be blank on field exit | *"Consignee Code cannot be Null"* |
| Dealer (`DEALER_NAME`) | Mandatory | Text item | N/A | Dealer list (LV_DEALER / RV_DEALER) | Dealer name | Consignee selected | Must not be blank on field exit | *"Dealer Name cannot be Null"* |
| Location (`LOC_CD`) | Mandatory | Text item | N/A | Location list (LV_LOC / RV_LOC) | Location code | Dealer selected | Must not be blank on field exit | *"Location cannot be Null"* |

---

---

#### Requirement ID: BR-004

**Requirement Title:** Location "ALL" Selection - Dealer Code Reset and Save Button Restriction

**Business Description:**
When the user selects the special "ALL" option for the Location filter and moves to the next field, the system automatically updates the internal dealer code to the global all-dealers value. Additionally, if the user is an administrative user, the Save button is disabled whenever the "ALL" location is chosen, preventing bulk flagging operations across all locations in that mode.

**Actors:** Parts Operations User

**Preconditions:**
- The Dead Stock Flag main screen is open and the user has entered or selected a value for the Location field.

**Main Flow:**

**Step 1 - Dealer code set to all-dealers value when Location "ALL" selected**
When the user tabs away from the Location field, the system checks whether the selected location is the "ALL" option. If it is, the internal dealer code is automatically updated to the universal all-dealers indicator (99999) to ensure that the subsequent search covers every dealer in the group.

*Screen: PART QUERY (`WN_MAIN` / `CN_MAIN`).*

**Step 2 - Save button disabled for administrative user when Location is "ALL"**
Immediately after the dealer code adjustment, if the user belongs to the administrative group (internal group code 99999) and the location chosen is "ALL", the Save button is disabled. This prevents an administrative user from saving dead-stock flag changes across all locations simultaneously.

*Screen: PART QUERY (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Location "ALL" combined with administrative user group disables Save | `KEY-NEXT-ITEM` on HDR_BLK.LOC_CD - checks `if :hdr_blk.dummy = '99999' and :hdr_blk.loc_cd='ALL'` | When the user tabs away from the Location field | Prevents an administrative user from performing a bulk-save across all locations | Save button is disabled; the user cannot save until a specific location is chosen |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Location (`LOC_CD`) | Mandatory | Text item | N/A | Location list (LV_LOC / RV_LOC) | Location code or "ALL" | Dealer selected | Triggers dealer-code reset and Save-button restriction when "ALL" is chosen | N/A - handled silently by auto-setting the dealer code |

---

---

#### Requirement ID: BR-005

**Requirement Title:** "Not Transacted For" Period Selection

**Business Description:**
When the user selects a value from the "Not Transacted For" period drop-down list, the system maps the chosen option to the corresponding numeric period factor used to calculate slow-moving stock thresholds. If the user selects an option that does not correspond to a recognised period, a note is shown asking the user to choose a valid period.

**Actors:** Parts Operations User

**Preconditions:**
- The Dead Stock Flag main screen is open and the user is setting the search criteria before running a search.

**Main Flow:**

**Step 1 - Period selection mapped to a numeric factor**
When the user changes the value of the "Not Transacted For" period list, the system checks the selected option. If the user selects period band A, the internal period parameter is set to 1 (representing one year-period unit). If the user selects period band B, the internal period parameter is set to 2.

*Screen: PART QUERY (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Selected period must be A or B | `WHEN_LIST_CHANGED` on HDR_BLK.SLAB - branches on value 'A' or 'B'; falls to else when neither | When the user changes the "Not Transacted For" drop-down | Ensures a valid period band is chosen so the slow-moving threshold calculation can be performed | If neither A nor B is selected, the note message *"choose the required Slab"* is displayed; the internal period parameter is not updated |

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-WS-01** - An option other than A or B is selected - *"choose the required Slab"*; no period factor is set and the user must select a valid option.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Not Transacted For (`SLAB`) | Mandatory | List item | N/A | N/A | A (maps to period factor 1) / B (maps to period factor 2) | Form open | Must be A or B; other selections trigger a note | *"choose the required Slab"* |

---

---

#### Requirement ID: BR-006

**Requirement Title:** Dead Stock Candidate Search

**Business Description:**
When the user clicks the Search button, the system retrieves all parts that have had no transactions (consumption or receipt) for longer than the chosen "Not Transacted For" period, applying the selected filters for consignee, dealer, location, category, and stock presence. The results are displayed in the detail section of the screen, one row per part, showing the part number, description, current stock quantity, purchase price, individual remarks and discount, and with the Dead Stock flag pre-checked as Yes. The total number of matching records and the total stock value are displayed in the header. A summary percentage showing how many slow-moving parts have already been formally flagged as dead stock is also calculated and shown.

**Actors:** Parts Operations User

**Preconditions:**
- The main screen is open and the user has selected values for Consignee, Dealer, Location, and the "Not Transacted For" period.

**Main Flow:**

**Step 1 - Detail grid cleared and results loaded**
The system navigates to the results section and clears any previously displayed rows. Depending on whether a specific location or the "ALL" option was chosen, the appropriate query is executed. For a specific location, each part that has gone without transactions for more than the selected period threshold is fetched, along with its current stock, purchase price, and any existing dead-stock remarks and discount already recorded against it. For the "ALL" location option, a consolidated query aggregates data across all locations within the consignee's dealer group, finding the minimum time since last transaction per part.

*Screen: PART QUERY (`WN_MAIN` / `CN_MAIN`).*

Each result row is populated with the part number, description, current stock quantity, purchase price, and any previously saved remarks and discount. The Dead Stock flag is pre-set to Yes for each retrieved part, and the "ALL" dead-stock checkbox in the header is pre-checked to Yes. The running total of stock value across all retrieved parts is accumulated and rounded to two decimal places.

**Step 2 - Percentage of slow-moving parts already flagged as dead stock calculated**
After the results are loaded, the system calculates the proportion of the total slow-moving stock value that has already been formally flagged as dead stock (identified by having a non-null flagging date). This percentage is displayed in the "% Slow-moving flagged as Dead Stock" field. The calculation branches on whether a specific location or "ALL" is selected, using the matching query variant.

*Screen: PART QUERY (`WN_MAIN` / `CN_MAIN`).*

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Consignee (`CONSG_CD`) | Mandatory | Text item | N/A | N/A | Consignee code (filter) | Validated (BR-003) | Applied as search filter | N/A |
| Dealer (`DEALER_NAME` / `DEALER_MAP_CD`) | Mandatory | Text item | N/A | N/A | Dealer mapping code (filter) | Validated (BR-003) | Applied as search filter; code 99999 means all dealers | N/A |
| Location (`LOC_CD`) | Mandatory | Text item | N/A | N/A | Location code or "ALL" | Validated (BR-003, BR-004) | Applied as search filter | N/A |
| Not Transacted For (`SLAB`) | Mandatory | List item | N/A | N/A | A or B | Validated (BR-005) | Period threshold for slow-moving calculation | N/A |
| Stock (`STOCK`) | Optional | List item | N/A | N/A | ALL (include zero-stock) / 1 (in-stock only, default) | Form open | Controls whether zero-stock parts are included | N/A |
| Category (`CATG_CD`) | Optional | List item | N/A | Category master (PM_CATEGORY) | Category code or null (all) | Form open | Applied as optional filter on category | N/A |
| Part Number - header search (`PART_NUM` in HDR_BLK) | Optional | Text item | N/A | N/A | Part number to filter | N/A | Used by part-search (BR-010) after results load | N/A |
| Serial No (`SRL_NO`) | Read-only display | Display item | Number | N/A | System-generated row counter | Results loaded | Auto-populated from cursor record position | N/A |
| Part Number - result row (`PART_NUM` in DTL_BLK) | Read-only display | Text item | N/A | N/A | Part number | Results loaded | Populated from search query | N/A |
| Part Description (`PART_DESC`) | Read-only display | Display item | 50 characters | N/A | Part description text | Results loaded | Populated from search query | N/A |
| Current Stock (`CURR_STOCK`) | Read-only display | Display item | Number | N/A | Sum of stock quantities | Results loaded | Populated from search query | N/A |
| Purchase Price (`MRP`) | Read-only display | Display item | Number | N/A | Purchase price rounded to 2 d.p. | Results loaded | Populated from search query | N/A |
| Remarks - individual (`IND_REMARKS`) | Optional | Text item | 100 characters | N/A | Free-text remarks | Results loaded | Pre-filled from existing dead-stock record if present | N/A |
| Discount on DRT - individual (`IND_PART_DISCOUNT`) | Mandatory | Text/Number | 6 characters | N/A | Numeric discount percentage | Results loaded | Pre-filled from existing dead-stock record if present (0 if none) | Validated at save (BR-009) |
| Dead Stock Y/N (`DEAD_STOCK_YN`) | Auto-populated | Check box | N/A | N/A | Y (pre-checked) / N | Results loaded | Pre-set to Y for all retrieved rows | N/A |
| Matching records (`TOT_REC`) | Read-only display | Display item | Number | N/A | Count of result rows | Results loaded | Populated after loop completes | N/A |
| Total Value (`VAL`) | Read-only display | Text item | Number (2 d.p.) | N/A | Sum of stock × purchase price | Results loaded | Accumulated during result loop, rounded to 2 d.p. | N/A |
| ALL checkbox (`CB_ALL`) | Auto-populated | Check box | N/A | N/A | Y (pre-checked after search) | Results loaded | Set to Y after results load | N/A |
| % Slow-moving flagged as Dead Stock (`LV_DEAD_PERC`) | Read-only display | Display item | Number | N/A | Calculated percentage | Results loaded | Calculated after results load; shown for specific location only | N/A |

---

---

#### Requirement ID: BR-007

**Requirement Title:** Remarks Text Editor

**Business Description:**
When the user clicks the remarks editor button (labelled "...."), a full-text editor popup opens, pre-loaded with the current header-level Remarks value. The user can edit the text and, on closing the editor, the updated value is written back to the Remarks field. If the text entered exceeds 35 characters, an error is shown and the over-length value is rejected.

**Actors:** Parts Operations User

**Preconditions:**
- The Dead Stock Flag main screen is open and search results have been loaded.

**Main Flow:**

**Step 1 - Editor opened with current remarks value**
The user clicks the remarks browse button. The system opens the remarks editor (E_Remarks), pre-loaded with the current content of the Remarks field. The user can type or modify the text freely within the editor.

**Step 2 - Updated remarks value written back**
When the user closes the editor (confirming the edit), the system writes the returned text back to the Remarks field. If the returned text is longer than 35 characters, a database-level error code (-6502, value too large for the variable) is caught and an error message is displayed; the over-length value is not saved to the field.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the error message in an alert box when the remarks text is too long.
    * **Step 1** - Receive the message text and the severity title as inputs.
    * **Step 2** - Select the appropriate alert template based on whether the severity is "Error" or another level.
    * **Step 3** - Set the alert title and message text on the selected template.
    * **Step 4** - Display the alert and wait for the user to dismiss it.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Remarks text must not exceed 35 characters | `WHEN-BUTTON-PRESSED` on HDR_BLK.PB_RM - EXCEPTION WHEN OTHERS if sqlcode = -6502 | When the user closes the remarks editor after editing | Enforces the maximum remarks text length | *"Description cannot exceed 35 characters"* is displayed; the trigger aborts and the over-length text is not applied to the Remarks field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-007-ES-01** - Remarks text longer than 35 characters - *"Description cannot exceed 35 characters "*; the previous Remarks value is retained.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Remarks (`REMARKS`) | Optional | Text item | 100 characters | N/A | N/A | Results loaded | Maximum 35 characters enforced by the editor's WHEN OTHERS handler | *"Description cannot exceed 35 characters "* |

---

---

#### Requirement ID: BR-008

**Requirement Title:** Replicate Header Remarks to All Detail Rows

**Business Description:**
When the user clicks the "Replicate to All" button for Remarks, the system asks whether to overwrite existing remarks on individual rows or only fill in rows where remarks are currently blank. Depending on the user's choice, the header-level Remarks value is copied into the corresponding field on every row in the results grid, either replacing all values or only populating empty ones.

**Actors:** Parts Operations User

**Preconditions:**
- The Dead Stock Flag main screen is open, search results are displayed, and a value has been entered in the header-level Remarks field.

**Main Flow:**

**Step 1 - User asked whether to overwrite existing individual remarks**
The user clicks the "Replicate to All" button (for Remarks). The system displays a confirmation prompt: *"Would you like to overwrite the existing remarks?"*

**Step 2 - Remarks value replicated according to user's choice**
If the user confirms overwrite (Button 1), the system loops through every row in the results grid and sets the individual Remarks field on every row to the header-level Remarks value, replacing any existing content. If the user chooses not to overwrite (Button 2), the system loops through every row and copies the header Remarks value only onto rows where the individual Remarks field is currently blank, leaving rows that already have remarks unchanged.

#### Business Scenarios - How replication differs by user choice

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Overwrite all** | User selects Button 1 (Yes); the header Remarks value replaces the individual remarks on every result row regardless of existing content. |
| **Fill blank only** | User selects Button 2 (No/fill-blank); the header Remarks value is copied only onto result rows where the individual Remarks field is empty; rows with existing remarks are unchanged. |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Remarks - header (`REMARKS`) | Optional | Text item | 100 characters | N/A | N/A | Results loaded | Source value for replication | N/A |
| Remarks - individual (`IND_REMARKS`) | Optional | Text item | 100 characters | N/A | N/A | Results loaded | Overwritten or conditionally populated by replication | N/A |

---

---

#### Requirement ID: BR-009

**Requirement Title:** Replicate Header Discount on DRT to All Detail Rows

**Business Description:**
When the user clicks the second "Replicate to All" button - which applies to the Discount on DRT field - the system asks whether to overwrite existing individual discounts or only fill in rows where the discount is blank. Depending on the user's answer, the header-level Discount on DRT value is copied to every row in the results grid, either replacing all values or only populating empty ones.

**Actors:** Parts Operations User

**Preconditions:**
- The Dead Stock Flag main screen is open, search results are displayed, and a value has been entered in the header-level Discount on DRT field.

**Main Flow:**

**Step 1 - User asked whether to overwrite existing individual discounts**
The user clicks the second "Replicate to All" button (for Discount on DRT). The system displays a confirmation prompt: *"Would you like to overwrite the existing Discount?"*

**Step 2 - Discount value replicated according to user's choice**
If the user confirms overwrite (Button 1), the system loops through every row in the results grid and sets the individual Discount on DRT field on every row to the header-level Discount on DRT value, replacing any existing content. If the user chooses not to overwrite (Button 2), the system loops and copies the header discount only onto rows where the individual Discount on DRT field is currently blank, leaving rows that already have a discount value unchanged.

#### Business Scenarios - How discount replication differs by user choice

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Overwrite all** | User selects Button 1 (Yes); the header Discount on DRT value replaces the individual discount on every result row regardless of existing content. |
| **Fill blank only** | User selects Button 2 (No/fill-blank); the header Discount on DRT value is copied only onto rows where the individual discount field is empty; rows with an existing discount are unchanged. |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Discount on DRT - header (`PART_DISCOUNT`) | Mandatory | Text | 6 characters | N/A | N/A | Results loaded | Source value for replication | Enforced at save (BR-011) |
| Discount on DRT - individual (`IND_PART_DISCOUNT`) | Mandatory | Text/Number | 6 characters | N/A | N/A | Results loaded | Overwritten or conditionally populated by replication | Enforced at save (BR-011) |

---

---

#### Requirement ID: BR-010

**Requirement Title:** Flag or Unflag All Parts as Dead Stock via the ALL Checkbox

**Business Description:**
When the user checks or unchecks the "ALL" checkbox, the system asks for confirmation, then sets the Dead Stock flag on every row in the results grid to match the selected state. When checking all rows (marking all as Dead Stock), the Discount on DRT fields are highlighted as mandatory. When unchecking all rows (removing the Dead Stock designation from all), the Discount on DRT fields revert to the standard display style.

**Actors:** Parts Operations User

**Preconditions:**
- The Dead Stock Flag main screen is open and search results are displayed.

**Main Flow:**

**Step 1 - Confirmation requested before bulk flag change**
The user clicks the "ALL" checkbox. The system displays a confirmation prompt: *"Would you like to flag/unflag all the parts as dead stock?"*

**Step 2 - All detail rows updated and visual style adjusted**
If the user confirms (Button 1), the system loops through every row in the results grid and sets the Dead Stock flag on each row to match the current state of the "ALL" checkbox (either Yes for flag all, or No for unflag all). At the same time, based on the state of the checkbox:

- If the "ALL" checkbox is now Yes (all flagged as Dead Stock), the Discount on DRT fields in both the header and the detail section are highlighted with the mandatory visual style (cyan background), and the per-row Discount on DRT field is also marked mandatory with the mandatory visual style on each record.
- If the "ALL" checkbox is now No (all unflagged), the Discount on DRT fields in both the header and the detail section revert to the standard display style.

**Step 3 - Focus returned to the first record**
After updating all rows, the system returns focus to the first row in the results grid.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ALL (`CB_ALL`) | Optional | Check box | N/A | N/A | Y (flag all) / N (unflag all) | Results loaded | Confirmation required before bulk update; drives visual style of Discount fields | N/A |
| Dead Stock Y/N (`DEAD_STOCK_YN`) | Auto-populated | Check box | N/A | N/A | Y / N | Results loaded | Set to match the ALL checkbox value on every row | N/A |
| Discount on DRT - header (`PART_DISCOUNT`) | Conditional - when ALL is Y | Text | 6 characters | N/A | N/A | Results loaded | Visual attribute set to mandatory (VA_MANDATORY) when ALL = Y, or default (VA_DEFAULT) when ALL = N | N/A |
| Discount on DRT - individual (`IND_PART_DISCOUNT`) | Conditional - when ALL is Y | Text/Number | 6 characters | N/A | N/A | Results loaded | Visual attribute set to mandatory (VA_MANDATORY) per row when ALL = Y, or default (VA_DEFAULT) when ALL = N | N/A |

---

---

#### Requirement ID: BR-011

**Requirement Title:** Part Number Search within Results Grid

**Business Description:**
When the user enters a part number in the header-level Part Number field and clicks the Search button next to it, the system searches through the currently displayed result rows for that part number. If a match is found, the cursor is positioned on that row. If no match is found, a note is shown and focus returns to the search field. If the Part Number search field is empty when the button is clicked, the user is prompted to enter a part number first.

**Actors:** Parts Operations User

**Preconditions:**
- The Dead Stock Flag main screen is open and search results are displayed in the results grid.

**Main Flow:**

**Step 1 - Part number entry checked**
The user enters a part number in the header-level Part Number field and clicks the Search button. The system first checks whether the search field contains a value. If it is empty, a note is displayed and no search is performed.

*Screen: PART QUERY (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays a note message when the part number field is empty.
    * **Step 1** - Receive the message text and the severity title as inputs.
    * **Step 2** - Select the appropriate alert template based on whether the severity is "Error" or another level.
    * **Step 3** - Set the alert title and message text on the selected template.
    * **Step 4** - Display the alert and wait for the user to dismiss it.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Part Number search field must not be blank | `WHEN-BUTTON-PRESSED` on HDR_BLK.PB_PART_SEARCH - checks `if :HDR_BLK.PART_NUM is not null` | When the user clicks the Part Number Search button | Prevents an empty search from running through the result rows | *"Enter the Part that is to be searched"* is displayed; no navigation occurs |

*Business outcomes (errors, warnings, success, and status):*
- **BR-011-WS-01** - Part Number search field is blank - *"Enter the Part that is to be searched"*; no search is performed.

**Step 2 - Results grid searched for matching part number**
If a part number has been entered, the system loops through each row in the results grid comparing the entered part number against the part number on each row.

**Step 3 - Cursor positioned on matching row or note shown**
If a matching row is found, the cursor is positioned on the Part Number field of that row. If no matching row is found, focus returns to the first record and the header-level Part Number search field, and a note is displayed.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays a note when no matching part is found in the results.
    * **Step 1** - Receive the message text and the severity title as inputs.
    * **Step 2** - Select the appropriate alert template based on whether the severity is "Error" or another level.
    * **Step 3** - Set the alert title and message text on the selected template.
    * **Step 4** - Display the alert and wait for the user to dismiss it.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Part number must match a row in the current results | `WHEN-BUTTON-PRESSED` on HDR_BLK.PB_PART_SEARCH - loop checks `:HDR_BLK.PART_NUM = :DTL_BLK.PART_NUM` | After entering a part number and clicking search | Allows the user to quickly locate a specific part within the loaded results | *"No matching Record"* is displayed; focus returns to the first row and the part number search field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-011-WS-02** - No matching part found in the results - *"No matching Record"*; cursor returns to the first record in the results grid.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Part Number - header search (`PART_NUM` in HDR_BLK) | Optional | Text item | N/A | N/A | Part number to locate | Results loaded | Must be non-blank to trigger search | *"Enter the Part that is to be searched"* |

---

---

#### Requirement ID: BR-012

**Requirement Title:** Save Dead Stock Flag Decisions

**Business Description:**
When the user clicks Save, the system validates the selected filters and the discount values, asks the user to confirm the intended action, then processes every row in the results grid and persists the dead-stock flag decisions to the database. For each part marked as Dead Stock (Yes), the system upserts a record in the dead-stock register with the part details, the flagging date, and the discount; it also updates the part's variant record with the Dead Stock flag. For each part unmarked (No), any existing active record in the dead-stock register is superseded by a new record marked as deleted, and the part variant record is updated accordingly. After all rows are processed, the data is committed.

**Actors:** Parts Operations User

**Preconditions:**
- Search results are displayed and at least one part's Dead Stock flag or discount has been reviewed or changed.
- The selected location is not "ALL" (the "ALL" location is blocked from saving - see BR-012-ES-01).

**Main Flow:**

**Step 1 - "ALL" location blocked from save**
When the user clicks Save, the system first checks whether the selected location is "ALL". If it is, saving is not permitted for individual-part flagging; an error message is shown and the trigger is aborted.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the error message when saving is attempted with the "ALL" location selected.
    * **Step 1** - Receive the message text and the severity title as inputs.
    * **Step 2** - Select the appropriate alert template based on whether the severity is "Error" or another level.
    * **Step 3** - Set the alert title and message text on the selected template.
    * **Step 4** - Display the alert and wait for the user to dismiss it.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Location must not be "ALL" for part-level flagging | `FT_SAVE` - checks `if :hdr_blk.loc_cd ='ALL'` | When the user clicks Save | Part-level dead-stock flagging is not applicable when "ALL" locations are selected | *"For part flagging is not applicable for ALL location"* is displayed; trigger is aborted; no data is changed |

*Business outcomes (errors, warnings, success, and status):*
- **BR-012-ES-01** - Save attempted with Location set to "ALL" - *"For part flagging is not applicable for ALL location"*; no save is performed; the form remains open.

**Step 2 - Discount on DRT validated when ALL checkbox is checked**
If the "ALL" checkbox is ticked (meaning all parts are being flagged as Dead Stock in bulk), the system checks that the header-level Discount on DRT field is not blank.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-004](#SP-004--GENERAL.CHECK_NULL)) - GENERAL.CHECK_NULL - checks whether the supplied field value is blank and, if so, displays an error and stops processing.
    * **Step 1** - Receive the item name, the current field value, and the user-facing field label as inputs.
    * **Step 2** - Check whether the supplied value is blank.
    * **Step 3** - If the value is blank, compose the message "Enter a valid [field label]", display it as an error, navigate to the item, and stop processing.
    * **Step 4** - If the value is not blank, return without action.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Header Discount on DRT must not be blank when ALL checkbox is checked | `FT_SAVE` - `IF :hdr_blk.cb_all = 'Y' THEN general.check_null('HDR_BLK.PART_DISCOUNT',...)` | When the user clicks Save and the ALL checkbox is checked | Ensures a discount rate is provided before flagging all parts in bulk | *"Enter a valid Part Discount"* is displayed; trigger is aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-012-ES-02** - ALL checkbox is checked but the header Discount on DRT is blank - *"Enter a valid Part Discount"*; save is blocked.

**Step 3 - Confirmation message presented to the user**
The system prepares a confirmation message based on the current state of the "ALL" checkbox:
- If "ALL" is checked: *"All the checked parts will be defined as dead stock"*
- If "ALL" is unchecked: *"All the unchecked parts will be undefined as dead stock"*

The system displays this message in a confirmation alert (AL_NOTE) and waits for the user to acknowledge it before continuing.

**Step 4 - Header-level discount range validated when ALL checkbox is checked**
After the confirmation, if the "ALL" checkbox is checked, the system validates that the header-level Discount on DRT value is within the allowed range (15.00 to 100.00).

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the range-validation error message.
    * **Step 1** - Receive the message text and the severity title as inputs.
    * **Step 2** - Select the appropriate alert template based on whether the severity is "Error" or another level.
    * **Step 3** - Set the alert title and message text on the selected template.
    * **Step 4** - Display the alert and wait for the user to dismiss it.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Header Discount on DRT must be between 15.00 and 100.00 when ALL is checked | `FT_SAVE` - `If (:HDR_BLK.CB_ALL = 'Y')AND((:HDR_BLK.PART_DISCOUNT<15)or(:HDR_BLK.PART_DISCOUNT>100))` | When the user clicks Save and the ALL checkbox is checked | Ensures the bulk discount rate is within the valid business range | *"Discount must be in Range 15.00 to 100.00"* is displayed; trigger is aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-012-ES-03** - Header Discount on DRT is outside the 15-100 range when ALL is checked - *"Discount must be in Range 15.00 to 100.00"*; save is blocked.

**Step 5 - Administrative username seed applied before loop**
Immediately before the per-row loop begins, the system evaluates the internal dummy field. If that field contains the value `99999` (a special administrative override code), the session-level username global `GLOBAL.user_name` is set to `ADMIN`. In all other cases `GLOBAL.user_name` retains the value established at form initialisation. This value is subsequently written as the `created_by` audit field on every dead-stock register INSERT in Steps 7 and 9.

**Step 6 - Per-row processing loop - part details retrieved**
The system loops through every row in the results grid. For each row, it checks whether a dead-stock record already exists in the register for the current group/dealer/location/part combination, and also retrieves the part's root part number from the parts master. If the parts master lookup fails (any database error), the processing stops with an error.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays an error when the part details cannot be retrieved.
    * **Step 1** - Receive the message text and the severity title as inputs.
    * **Step 2** - Select the appropriate alert template.
    * **Step 3** - Set the alert title and message text.
    * **Step 4** - Display the alert and wait for the user to dismiss it.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Part details must be retrievable from the parts master | `FT_SAVE` - EXCEPTION WHEN OTHERS on the SELECT from PM_PART | During the per-row save loop when looking up root part number | Ensures the part's root number can be resolved before creating a dead-stock record | *"ERROR WHILE FETCHING PART DETAILS"* is displayed; trigger is aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-012-ES-04** - Unexpected error while fetching part details from the parts master - *"ERROR WHILE FETCHING PART DETAILS"*; save is blocked for the current and all subsequent rows.

**Step 7 - Dead Stock flag = Yes processing (flag the part)**
For rows where the Dead Stock flag is Yes, the system first validates that the individual Discount on DRT is not blank (using GENERAL.CHECK_NULL). It then checks whether an existing dead-stock record exists for this part:
- If one exists: the existing record is deleted first, then a new active record is inserted with the flag set to not-deleted, the individual remarks, discount, root part number, the current date as the creation date, and the logged-in user as the creator.
- If no existing record: a new active record is inserted directly with the same fields.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-004](#SP-004--GENERAL.CHECK_NULL)) - GENERAL.CHECK_NULL - checks that the individual Discount on DRT field is not blank before saving the flagged part.
    * **Step 1** - Receive the item name, the current field value, and the user-facing field label as inputs.
    * **Step 2** - Check whether the supplied value is blank.
    * **Step 3** - If the value is blank, compose the message "Enter a valid [field label]", display it as an error, navigate to the item, and stop processing.
    * **Step 4** - If the value is not blank, return without action.
- **GENERAL.DISP_TEXT** ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays error messages when delete or insert operations fail.
    * **Step 1** - Receive the message text and the severity title as inputs.
    * **Step 2** - Select the appropriate alert template.
    * **Step 3** - Set the alert title and message text.
    * **Step 4** - Display the alert and wait for the user to dismiss it.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Individual Discount on DRT must not be blank for a part being flagged as Dead Stock | `FT_SAVE` - `general.check_null('dtl_blk.ind_part_discount',...)` inside the `IF :dtl_blk.dead_stock_yn = 'Y'` branch | During the per-row save loop when the Dead Stock flag is Yes | Ensures a discount percentage is always supplied for parts being designated as dead stock | *"Enter a valid Part Discount"* is displayed; trigger is aborted |
| Dead-stock record deletion must succeed | `FT_SAVE` - EXCEPTION WHEN OTHERS on the DELETE from PM_PART_DEAD_STOCK | During the per-row save loop when an existing record is being replaced | Ensures the old record can be removed before the new one is inserted | *"ERROR WHILE DELETING FROM DEAD_STOCK"* is displayed; trigger is aborted |
| Dead-stock record insertion must succeed | `FT_SAVE` - EXCEPTION WHEN OTHERS on the INSERT into PM_PART_DEAD_STOCK (Dead Stock = Yes path) | During the per-row save loop when inserting the active dead-stock record | Ensures the new active dead-stock record is persisted correctly | *"ERROR WHILE INSERTING INTO DEAD_STOCK"* is displayed; trigger is aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-012-ES-05** - Individual Discount on DRT is blank for a flagged part - *"Enter a valid Part Discount"*; save is blocked.
- **BR-012-ES-06** - Database error during deletion of existing dead-stock record - *"ERROR WHILE DELETING FROM DEAD_STOCK"*; trigger is aborted.
- **BR-012-ES-07** - Database error during insertion of new active dead-stock record - *"ERROR WHILE INSERTING INTO DEAD_STOCK"*; trigger is aborted.

**Step 8 - Dead Stock flag = Yes: individual discount range validated**
After the insert operations for a flagged part (Dead Stock = Yes), the system additionally validates that the individual Discount on DRT is within the allowed range (15.00 to 100.00). This check applies per row only when the Dead Stock flag is Yes.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the range-validation error message for the individual discount.
    * **Step 1** - Receive the message text and the severity title as inputs.
    * **Step 2** - Select the appropriate alert template.
    * **Step 3** - Set the alert title and message text.
    * **Step 4** - Display the alert and wait for the user to dismiss it.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Individual Discount on DRT must be between 15.00 and 100.00 when the part is flagged as Dead Stock | `FT_SAVE` - `If (:dtl_blk.dead_stock_yn = 'Y')AND((:DTL_BLK.IND_PART_DISCOUNT<15)or(:DTL_BLK.IND_PART_DISCOUNT>100))` | During the per-row save loop, after inserts, when Dead Stock = Yes | Ensures the individual discount rate is within the valid business range before committing | *"Discount must be in Range 15.00 to 100.00"* is displayed; trigger is aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-012-ES-08** - Individual Discount on DRT is outside 15-100 range for a flagged part - *"Discount must be in Range 15.00 to 100.00"*; save is blocked.

**Step 9 - Dead Stock flag = No processing (unflag the part)**
For rows where the Dead Stock flag is No, if an existing active dead-stock record is found for that part, the existing record is deleted and replaced with a new record marked as deleted (with the part's details, creation timestamp, current user as creator, and the deleted flag set to Yes). If no existing record exists, no action is taken for that row.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays error messages when delete or insert operations fail in the unflagging path.
    * **Step 1** - Receive the message text and the severity title as inputs.
    * **Step 2** - Select the appropriate alert template.
    * **Step 3** - Set the alert title and message text.
    * **Step 4** - Display the alert and wait for the user to dismiss it.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Dead-stock record deletion must succeed (unflagging path) | `FT_SAVE` - EXCEPTION WHEN OTHERS on the DELETE from PM_PART_DEAD_STOCK inside the `ELSIF :dtl_blk.dead_stock_yn = 'N'` branch | During the per-row save loop when removing the active dead-stock designation | Ensures the active dead-stock record can be removed when a part is being unflagged | *"ERROR WHILE DELETING FROM DEAD_STOCK"* is displayed; trigger is aborted |
| Soft-delete record insertion must succeed (unflagging path) | `FT_SAVE` - EXCEPTION WHEN OTHERS on the INSERT into PM_PART_DEAD_STOCK (deleted flag = Y path) | During the per-row save loop when creating the soft-delete audit record | Ensures the historical soft-delete record is persisted after a part is unflagged | *"ERROR WHILE INSERTING INTO DEAD_STOCK"* is displayed; trigger is aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-012-ES-09** - Database error during deletion of the active dead-stock record (unflagging) - *"ERROR WHILE DELETING FROM DEAD_STOCK"*; trigger is aborted.
- **BR-012-ES-10** - Database error during insertion of the soft-delete audit record (unflagging) - *"ERROR WHILE INSERTING INTO DEAD_STOCK"*; trigger is aborted.

**Step 10 - Part variant dead-stock indicator updated**
For every row, regardless of the flag direction, the system updates the part variant record to set the Dead Stock indicator to the current flag value for the matching group/dealer/location/part combination. If this update fails, an error is displayed and the trigger is aborted.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays error when the part variant update fails.
    * **Step 1** - Receive the message text and the severity title as inputs.
    * **Step 2** - Select the appropriate alert template.
    * **Step 3** - Set the alert title and message text.
    * **Step 4** - Display the alert and wait for the user to dismiss it.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Part variant record update must succeed | `FT_SAVE` - EXCEPTION WHEN OTHERS on the UPDATE to PM_PART_VAR | During the per-row save loop after the dead-stock register has been updated | Ensures the part's central variant record reflects the current dead-stock status | *"ERROR WHILE UPDATING PM_PART_VAR"* is displayed; trigger is aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-012-ES-11** - Unexpected database error while updating the part variant record - *"ERROR WHILE UPDATING PM_PART_VAR"*; trigger is aborted.

**Step 11 - Commit performed via KEY-COMMIT**
After the processing loop completes successfully for all rows, the trigger invokes the KEY-COMMIT sequence. The form enters validation, checks for a form-level failure, commits all pending changes to the database, checks for failure again, and then clears the form.

*Procedures called:*
- **GENERAL.CHECK_FORM_FAILURE** ([SP-003](#SP-003--GENERAL.CHECK_FORM_FAILURE)) - GENERAL.CHECK_FORM_FAILURE - checks whether the most recent form operation (enter or commit_form) succeeded; if not, displays the appropriate Oracle or Forms error text and raises a trigger failure.
    * **Step 1** - Check whether the most recent form operation succeeded.
    * **Step 2** - If not, determine whether the failure is an Oracle database error or a Forms-layer error.
    * **Step 3** - Display the relevant error text (Oracle error message for database failures; Forms error text for Forms-layer failures) and stop processing.

#### Business Scenarios - How save differs by ALL checkbox state

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **ALL checkbox checked (bulk flag)** | Header Discount on DRT is validated (not blank and in range 15-100) before processing; confirmation message is "All the checked parts will be defined as dead stock"; individual discount is also range-checked per row. |
| **ALL checkbox unchecked (selective unflag)** | Header Discount on DRT blank check and range check are skipped; confirmation message is "All the unchecked parts will be undefined as dead stock"; unflagged rows are written as soft-deleted records. |

**Alternative Flows:**
- **BR-012-AF-01** - (from Step 5) If the internal "dummy" field contains the value `99999` (a special administrative override code, referenced in DMSSERV-13112), the session-level username global `GLOBAL.user_name` is set to `ADMIN` before the per-row loop begins. This override is applied silently without user notification.
- **BR-012-AF-02** - (from Step 9) For a row with Dead Stock flag = No and no existing dead-stock record in the register, no deletion or insertion is performed for that row; the loop continues to the next row.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Location (`LOC_CD`) | Mandatory | Text item | N/A | N/A | Location code (not "ALL") | Selected before search | Must not be "ALL" for saving | *"For part flagging is not applicable for ALL location"* |
| ALL (`CB_ALL`) | Optional | Check box | N/A | N/A | Y / N | Results loaded | Controls confirmation message and header discount validation path | N/A |
| Discount on DRT - header (`PART_DISCOUNT`) | Conditional - when ALL = Y | Text | 6 characters | N/A | Numeric 15.00-100.00 | ALL = Y | Must be non-blank and in range 15-100 | *"Enter a valid Part Discount"* / *"Discount must be in Range 15.00 to 100.00"* |
| Dead Stock Y/N (`DEAD_STOCK_YN`) | Mandatory | Check box | N/A | N/A | Y / N | Results loaded | Drives which save path (flag or unflag) is taken per row | N/A |
| Discount on DRT - individual (`IND_PART_DISCOUNT`) | Mandatory - when Dead Stock = Y | Text/Number | 6 characters | N/A | Numeric 15.00-100.00 | Dead Stock = Y | Must be non-blank and in range 15-100 when flagging as dead stock | *"Enter a valid Part Discount"* / *"Discount must be in Range 15.00 to 100.00"* |
| Remarks - individual (`IND_REMARKS`) | Optional | Text item | 100 characters | N/A | N/A | Results loaded | Saved to the dead-stock register record | N/A |

---

---

#### Requirement ID: BR-013

**Requirement Title:** Cancel Unsaved Changes

**Business Description:**
When the user clicks the Cancel button, the system checks whether any unsaved changes exist on the form. If changes are present, the user is asked to confirm that the data should be discarded. If the user confirms, or if no changes exist, the form is cleared without saving. If the Cancel button is disabled, the action is silently ignored.

**Actors:** Parts Operations User

**Preconditions:**
- The Dead Stock Flag form is open.

**Main Flow:**

**Step 1 - Cancel button enabled state checked**
The system checks whether the Cancel button is currently enabled. If it is not enabled, the action is silently ignored.

**Step 2 - Unsaved changes check and confirmation**
The system resets internal parameters, then checks whether the form has unsaved changes. If changes exist, a confirmation prompt is displayed: *"Entered data will not be Saved"*. If the user confirms (returns 1), the form is cleared without saving. If the user declines, no action is taken and the user remains on the form.

*Procedures called:*
- **GENERAL.ASK_CONFIRM** ([SP-002](#SP-002--GENERAL.ASK_CONFIRM)) - GENERAL.ASK_CONFIRM - displays a confirmation alert with the supplied message and returns 1 if the user clicks the first button (Yes/OK) or 0 if the user declines.
    * **Step 1** - Receive the confirmation message text as input.
    * **Step 2** - Set the confirmation alert's message text.
    * **Step 3** - Display the alert and wait for the user to choose.
    * **Step 4** - Return 1 if the user confirmed, or 0 if the user declined.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Confirmation required when unsaved changes exist | `FT_CANCEL` - `IF :system.form_status = 'CHANGED' THEN lv_al_id := GENERAL.ASK_CONFIRM(...)` | When the user clicks Cancel and the form has unsaved changes | Prevents accidental data loss by requiring confirmation before discarding changes | If the user declines, the form remains open with unsaved changes intact |

**Alternative Flows:**
- **BR-013-AF-01** - (from Step 2) If the form has no unsaved changes (`CHANGED` status is false), the form is cleared immediately without displaying the confirmation prompt.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| All on-screen fields | Read-only display during cancel evaluation | N/A | N/A | N/A | N/A | Form open | Form status checked for unsaved changes | N/A - confirmation controls whether data is discarded |

---

---

#### Requirement ID: BR-014

**Requirement Title:** Exit the Form

**Business Description:**
When the user clicks the Exit button or presses the Exit key, the system checks whether there are unsaved changes. If changes exist, the user is asked to confirm that the changes will not be saved. If confirmed, the form closes without saving. If the form is in query-entry mode, it exits directly without a confirmation prompt. The system also clears the database session tracking attributes before closing.

**Actors:** Parts Operations User

**Preconditions:**
- The Dead Stock Flag form is open.

**Main Flow:**

**Step 1 - Session tracking attributes cleared**
When the KEY-EXIT trigger fires, the system clears the database session's client-info and module attributes (setting both to null/empty) using Oracle built-in session calls. This removes the active session identity from database monitoring before the form is closed.

**Step 2 - Form closed without validation**
The form is immediately closed using the NO_VALIDATE option, discarding any uncommitted changes without prompting.

**Step 3 - Exit via button: query-mode and change-status checks**
When the user clicks the Exit button (as opposed to pressing the Exit key), the system first checks whether the form is in query-entry mode. If it is, the form is exited immediately. If the form is not in query-entry mode but has unsaved changes, a confirmation prompt is displayed: *"Entered data will not be Saved"*. If the user confirms, the form closes. If the form has no unsaved changes, the form closes immediately.

*Procedures called:*
- **GENERAL.ASK_CONFIRM** ([SP-002](#SP-002--GENERAL.ASK_CONFIRM)) - GENERAL.ASK_CONFIRM - displays a confirmation alert when the Exit button is clicked and unsaved changes exist.
    * **Step 1** - Receive the confirmation message text as input.
    * **Step 2** - Set the confirmation alert's message text.
    * **Step 3** - Display the alert and wait for the user to choose.
    * **Step 4** - Return 1 if the user confirmed, or 0 if the user declined.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Confirmation required when unsaved changes exist (Exit button path) | `WHEN-BUTTON-PRESSED` on PB_BLK.PB_EXIT - `IF :system.form_status = 'CHANGED' THEN lv_al_id := GENERAL.ASK_CONFIRM(...)` | When the user clicks the Exit button and the form has unsaved changes | Prevents accidental data loss when the user exits with unsaved changes | If the user declines, the form remains open |

**Alternative Flows:**
- **BR-014-AF-01** - (from Step 3) The commented-out code block in KEY-EXIT (COMMENTED OUT / INACTIVE - does not execute) would have cleared the form and deleted temporary session part records before exiting; this code does not run in production.
- **BR-014-AF-02** - (from Step 3) If the form is in query-entry mode, the Exit button triggers immediate exit via `DO_KEY('EXIT_FORM')` without any change-check or confirmation.
- **BR-014-AF-03** - (from Step 3) If the form has no unsaved changes, the Exit button triggers immediate exit without displaying the confirmation prompt.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| All on-screen fields | Read-only display during exit evaluation | N/A | N/A | N/A | N/A | Form open | Form status checked for unsaved changes (button path only) | N/A |

---

---

#### Requirement ID: BR-015

**Requirement Title:** Forms Message Intercept for Navigation and Mandatory-Field Errors

**Business Description:**
The form intercepts specific forms-layer and database error codes and re-presents them to the user as formatted error alerts rather than allowing the default system message handling. The ON-MESSAGE trigger intercepts navigation-related (40209) and mandatory-field (40207) message codes and re-displays them in the standard alert style. The ON-ERROR trigger intercepts date-format errors, numeric-entry errors, concurrent-update conflicts, and unhandled database exceptions, displaying a specific business-friendly message for each recognised condition and rolling back changes when necessary.

**Actors:** Parts Operations User (system-triggered)

**Preconditions:**
- The form is open and a forms-layer message or error fires.

**Main Flow:**

**Step 1 - Message code checked (ON-MESSAGE)**
When any forms-layer message fires, the system captures the error number, error text, and error type. If the error code is 40209 (navigation-related) or 40207 (mandatory-field), the system re-displays the message in a formatted alert using the pattern: error-type prefix, hyphen, the error number, colon, and the original error text. After displaying the alert, the trigger is aborted to prevent the default handling.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the intercepted message in an alert box.
    * **Step 1** - Receive the message text and the severity title as inputs.
    * **Step 2** - Select the appropriate alert template based on whether the severity is "Error" or another level.
    * **Step 3** - Set the alert title and message text on the selected template.
    * **Step 4** - Display the alert and wait for the user to dismiss it.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Forms message codes 40209 or 40207 are intercepted and re-displayed | `ON-MESSAGE` - `IF errnum in (40209,40207)` | When the platform generates a message with code 40209 or 40207 | Ensures mandatory-field and navigation errors are shown in the standard alert style | The message is displayed as an alert combining error type, code, and text; trigger failure is raised to abort default handling |

*Business outcomes (errors, warnings, success, and status):*
- **BR-015-SM-01** - Forms message code 40209 or 40207 intercepted and displayed as a formatted alert; default platform handling suppressed.

**Step 2 - Date-format errors intercepted (ON-ERROR)**
When any forms-layer or database error fires, the ON-ERROR trigger captures the error code, error text, error type, and underlying database error code. If the error code is 50004 (invalid date value), the system displays *"Entered Date is not valid Date"* and aborts the trigger. If the error code is 50025 or 50026 (date format mismatch), the system displays *"Enter the Date in the proper format (DD-MM-YYYY)"* and aborts the trigger.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the date-error message in an alert box.
    * **Step 1** - Receive the message text and the severity title as inputs.
    * **Step 2** - Select the appropriate alert template based on severity.
    * **Step 3** - Set the alert title and message text.
    * **Step 4** - Display the alert and wait for the user to dismiss it.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Error code 50004 triggers invalid-date message | `ON-ERROR` - `IF errnum in (50004)` | When a date-entry field rejects the entered value as an invalid date | Presents a clear business message instead of a raw Oracle error code | *"Entered Date is not valid Date"* is displayed; trigger is aborted |
| Error codes 50025 or 50026 trigger date-format message | `ON-ERROR` - `IF errnum in (50025,50026)` | When a date-entry field rejects the entered value due to incorrect format | Guides the user to enter the date in DD-MM-YYYY format | *"Enter the Date in the proper format (DD-MM-YYYY)"* is displayed; trigger is aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-015-ES-01** - Error code 50004 detected - *"Entered Date is not valid Date"*; the user must correct the date entry.
- **BR-015-ES-02** - Error code 50025 or 50026 detected - *"Enter the Date in the proper format (DD-MM-YYYY)"*; the user must re-enter the date in the correct format.

**Step 3 - Non-numeric entry errors intercepted (ON-ERROR)**
If the error code is 40209 or 50016 (non-numeric character entered in a numeric field), the system displays *"Characters/Special Characters are not allowed here, enter the numeric value"* and aborts the trigger. If the error code is 40207 (mandatory-field violation in an error context), the system displays the raw error text from the platform and aborts the trigger.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the numeric-entry error message in an alert box.
    * **Step 1** - Receive the message text and the severity title as inputs.
    * **Step 2** - Select the appropriate alert template based on severity.
    * **Step 3** - Set the alert title and message text.
    * **Step 4** - Display the alert and wait for the user to dismiss it.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Error codes 40209 or 50016 trigger numeric-entry message | `ON-ERROR` - `IF errnum in (40209,50016)` | When a numeric-only field receives a non-numeric or special-character entry | Tells the user clearly that only numeric input is accepted | *"Characters/Special Characters are not allowed here, enter the numeric value"* is displayed; trigger is aborted |
| Error code 40207 triggers raw platform error text | `ON-ERROR` - `IF errnum in (40207)` | When a mandatory-field error fires in an error context | Surfaces the platform's own description of the mandatory-field violation | The platform error text is displayed; trigger is aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-015-ES-03** - Error code 40209 or 50016 detected - *"Characters/Special Characters are not allowed here, enter the numeric value"*; the user must enter a numeric value.
- **BR-015-ES-04** - Error code 40207 detected in error context - platform error text displayed; the user must address the mandatory-field violation.

**Step 4 - Concurrent-update conflict intercepted (ON-ERROR)**
If error codes 40654, 40655, 40656, 40657, or 40659 are detected (record locked or modified by another user since the current user last queried), the system displays *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*, performs a rollback to discard the conflicting changes, and aborts the trigger.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the concurrent-update conflict message.
    * **Step 1** - Receive the message text and the severity title as inputs.
    * **Step 2** - Select the appropriate alert template based on severity.
    * **Step 3** - Set the alert title and message text.
    * **Step 4** - Display the alert and wait for the user to dismiss it.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Error codes 40654, 40655, 40656, 40657, or 40659 trigger concurrent-update message and rollback | `ON-ERROR` - `IF ERROR_CODE IN (40654,40655,40656,40657,40659)` | When a save or commit detects that another user has already modified the same record | Prevents overwriting another user's changes by rolling back and directing the current user to re-query | *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"* is displayed; a rollback is performed; trigger is aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-015-ES-05** - Concurrent-update conflict detected (error codes 40654/40655/40656/40657/40659) - *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*; changes are rolled back; the user must re-query and re-apply changes.

**Step 5 - Unhandled database exceptions caught (ON-ERROR)**
If the Oracle SQL error code is non-zero and none of the specific error codes above matched, the system displays the Oracle error message text as an error alert, performs a rollback, and aborts the trigger. If the underlying database error is a child-record constraint violation (Oracle error -02292), the system calls GENERAL.RAISE_ERROR with code E0088 instead of showing the raw message. Error codes 40401 and 40405 (no data found / end of set) are silently ignored.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the Oracle error message text for unhandled exceptions.
    * **Step 1** - Receive the Oracle SQLERRM text and the severity title as inputs.
    * **Step 2** - Select the appropriate alert template based on severity.
    * **Step 3** - Set the alert title and message text.
    * **Step 4** - Display the alert and wait for the user to dismiss it.
- **GENERAL.RAISE_ERROR** ([SP-007](#SP-007--GENERAL.RAISE_ERROR)) - GENERAL.RAISE_ERROR - looks up and displays the standard error message for a given error code key (E0088 = child-record constraint message) and raises a trigger failure.
    * **Step 1** - Receive the error code key as input.
    * **Step 2** - Look up the standard message text for that key from the error catalogue.
    * **Step 3** - Display the message in an alert and raise a trigger failure.

*Business outcomes (errors, warnings, success, and status):*
- **BR-015-ES-06** - Unhandled Oracle database error - Oracle SQLERRM text displayed; changes are rolled back; trigger is aborted.
- **BR-015-ES-07** - Child-record constraint violation (Oracle -02292) - standard error message E0088 is raised via GENERAL.RAISE_ERROR.
- **BR-015-SM-02** - Error codes 40401 or 40405 silently suppressed; no message displayed.

**Alternative Flows:**
- **BR-015-AF-01** - (from Step 1) If the message code is neither 40209 nor 40207, the ON-MESSAGE trigger does nothing and the platform applies its default message handling.
- **BR-015-AF-02** - (from Step 2) If the error code does not match any of the specific cases in Steps 2-4 and SQLCODE is zero, the trigger exits without displaying a message and without rolling back.

---

---

#### Requirement ID: BR-016

**Requirement Title:** Export Dead Stock Results to Excel (Location-Specific Report)

**Business Description:**
When the user clicks the "Excel Report" button, the system generates a CSV data file containing the dead-stock candidate results for the selected filters and makes the file available for download in the user's browser. The exported data includes part number, description, group, dealer code, location, current stock, purchase price, total stock value, last transaction date, remarks, flag date, and discount. The system also recalculates and updates the percentage of slow-moving parts already flagged as dead stock before generating the file. A unique filename is generated from the user's login ID and the current date-time. If the filename contains spaces in the folder path, the file is redirected to the C drive root. If the data exceeds 65,535 rows, the export is truncated with a warning.

**Actors:** Parts Operations User

**Preconditions:**
- The Dead Stock Flag main screen is open and search results are displayed.

**Main Flow:**

**Step 1 - Dead-stock percentage recalculated**
When the user clicks the Excel Report button, the system first resets the slow-moving percentage indicator to zero, then recalculates the percentage of the current slow-moving stock value that has already been formally flagged as dead stock, using the same query logic as the search (branching on whether Location is specific or "ALL"). The updated percentage is written to the "% Slow-moving flagged as Dead Stock" field.

*Screen: PART QUERY (`WN_MAIN` / `CN_MAIN`).*

**Step 2 - CSV query constructed and unique filename generated**
The system builds a SQL query that will produce all the required columns as a comma-separated string. A unique filename is generated from the logged-in user's ID concatenated with the current date and time, with a `.csv` extension. If the resulting file path contains spaces, the file location is defaulted to the root of the C drive and the user is notified.

*Procedures called:*
- **VIEW_EXCEL_REP** ([SP-001](#SP-001--VIEW_EXCEL_REP)) - VIEW_EXCEL_REP - executes the supplied query, writes the result rows into a CSV file on the application server, reads the server-side output path from the configuration file at `/reports/DMS/excelpath.txt`, and opens the file in the user's browser. If the row count exceeds 65,535, the data is truncated with a warning.
    * **Step 1** - Receive the file name, the data query, and the result column name as inputs.
    * **Step 2** - Generate the output filename from the logged-in user's identity and the current date-time.
    * **Step 3** - If the path contains spaces, redirect the file to the C drive root and inform the user.
    * **Step 4** - Execute the supplied query and load the results into an in-memory record group.
    * **Step 5** - If the row count exceeds 65,535, truncate the data to 65,535 rows and display a warning.
    * **Step 6** - Read the server-side output path from the configuration file `/reports/DMS/excelpath.txt`.
    * **Step 7** - Write each result row to the CSV file on the server.
    * **Step 8** - Open the resulting file in the user's browser using the web server URL, then close the file.
    * **Step 9** - If any error occurs during file operations, display the error code and text and stop processing.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| File path must not contain spaces | VIEW_EXCEL_REP - `If instr(FILENAME,' ') > 0 then FILENAME := 'C:\...'` | When generating the output file during the Excel export | Ensures the file can be saved to a valid server path even when the default path contains spaces | *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."* is shown; file is saved to C drive root |
| Row count must not exceed 65,535 | VIEW_EXCEL_REP - `IF the_rowcount > 65536 THEN ... the_rowcount := 65535` | When the record group is populated during the export | Enforces the Excel row-count limit for the generated CSV | *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."* is shown; export continues with first 65,535 rows |
| File generation must succeed | VIEW_EXCEL_REP - EXCEPTION WHEN OTHERS `Message('Error  - '||ERROR_CODE||ERROR_TEXT)` | If any error occurs during the file-write or browser-open operation | Ensures the user is informed of any unexpected failure during export | A message is shown containing the error code concatenated with the error text (e.g. "Error  -" followed by the Oracle error code and error text); trigger failure is raised |

*Business outcomes (errors, warnings, success, and status):*
- **BR-016-WS-01** - File path contains spaces - *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."*; file is redirected.
- **BR-016-WS-02** - Export row count exceeds 65,535 - *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."*; export continues with truncated data.
- **BR-016-ES-01** - Unexpected error during file generation or browser open - message shown as *"Error  - "* followed by the Oracle error code and error text; trigger is aborted.
- **BR-016-IC-01** - `LV_DEAD_PERC` updated - percentage of slow-moving parts already designated dead stock is recalculated and displayed before the export runs.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| % Slow-moving flagged as Dead Stock (`LV_DEAD_PERC`) | Read-only display | Display item | Number | N/A | Calculated percentage | Results loaded | Recalculated before export | N/A |

---

---

#### Requirement ID: BR-017

**Requirement Title:** Export Dead Stock Results to Excel (Consolidated Report)

**Business Description:**
When the user clicks the "Excel Report (CONS)" button, the system generates a consolidated CSV data file that groups results by consignee and location rather than by the specific location filter. The exported columns include consignee code, location code, part number, description, current stock, purchase price, total value, last transaction date, remarks, flag date, and discount. The file is generated and opened in the user's browser in the same way as the location-specific export (BR-016).

**Actors:** Parts Operations User

**Preconditions:**
- The Dead Stock Flag main screen is open and search results are displayed.

**Main Flow:**

**Step 1 - Consolidated CSV query constructed and file generated**
The user clicks the "Excel Report (CONS)" button. The system builds a SQL query that produces a comma-separated consolidated result set grouped by consignee and location. A unique filename is generated from the logged-in user's ID and the current date-time. The query and filename are passed to the VIEW_EXCEL_REP procedure which writes the file to the server and opens it in the browser.

*Procedures called:*
- **VIEW_EXCEL_REP** ([SP-001](#SP-001--VIEW_EXCEL_REP)) - VIEW_EXCEL_REP - executes the supplied query, writes the result rows into a CSV file on the application server, reads the server-side output path from `/reports/DMS/excelpath.txt`, and opens the file in the user's browser (same procedure as BR-016, applied to the consolidated query).
    * **Step 1** - Receive the file name, the data query, and the result column name as inputs.
    * **Step 2** - Generate the output filename from the logged-in user's identity and the current date-time.
    * **Step 3** - If the path contains spaces, redirect the file to the C drive root and inform the user.
    * **Step 4** - Execute the supplied query and load the results into an in-memory record group.
    * **Step 5** - If the row count exceeds 65,535, truncate the data to 65,535 rows and display a warning.
    * **Step 6** - Read the server-side output path from the configuration file `/reports/DMS/excelpath.txt`.
    * **Step 7** - Write each result row to the CSV file on the server.
    * **Step 8** - Open the resulting file in the user's browser using the web server URL, then close the file.
    * **Step 9** - If any error occurs during file operations, display the error code and text and stop processing.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| File path must not contain spaces | VIEW_EXCEL_REP - `If instr(FILENAME,' ') > 0` | When generating the file | Ensures the file can be saved to a valid path | *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."* |
| Row count must not exceed 65,535 | VIEW_EXCEL_REP - row-count check | When the record group is populated | Enforces the export row-count limit | *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."* |
| File generation must succeed | VIEW_EXCEL_REP - EXCEPTION WHEN OTHERS | During file-write or browser-open | Ensures the user is informed of failures | Message *"Error  - "* followed by error code and error text; trigger aborted |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Consignee (`CONSG_CD`) | Mandatory | Text item | N/A | N/A | Applied as grouping filter in query | Validated (BR-003) | Applied as filter in consolidated query | N/A |
| Location (`LOC_CD`) | Mandatory | Text item | N/A | N/A | Applied as grouping filter in query | Validated (BR-003) | Applied as filter in consolidated query | N/A |

---

---

#### Requirement ID: BR-018

**Requirement Title:** Printer Selection

**Business Description:**
When the user clicks the Print Setup button, the system opens the operating system's printer selection dialog, allowing the user to choose a printer and port before printing. This is a setup step only; no data is sent to the printer at this point.

**Actors:** Parts Operations User

**Preconditions:**
- The Dead Stock Flag form is open.

**Main Flow:**

**Step 1 - Printer selection dialog opened**
The user clicks the Print Setup button. The system opens the Windows printer selection dialog using the Win API. The user selects a printer and port; the selected values are available for use by subsequent print operations.

*Procedures called:*
- **WIN_API_DIALOG.SELECT_PRINTER** ([SP-007](#SP-007--WIN_API_DIALOG.SELECT_PRINTER)) - WIN_API_DIALOG.SELECT_PRINTER - invokes the Windows printer selection dialog and returns the selected printer name and port to the caller.
    * **Step 1** - Open the Windows printer selection dialog with the show-dialog flag set to true.
    * **Step 2** - Wait for the user to select a printer and port or cancel the dialog.
    * **Step 3** - Return the selected printer name and port to the calling trigger.
    * **Step 4** - Return the processing result.

---

---

#### Requirement ID: BR-019

**Requirement Title:** Print Action (Placeholder - No Business Logic Implemented)

**Business Description:**
The Print button and its associated print trigger are present on the form but contain no implemented logic. The trigger checks whether the Print button is enabled and, if so, performs no action (the print code area is a placeholder). This requirement documents the presence of the print capability stub.

**Actors:** Parts Operations User

**Preconditions:**
- The Dead Stock Flag form is open.

**Main Flow:**

**Step 1 - Print trigger invoked with no active logic**
The user clicks the Print button or the system routes to the print trigger. The trigger checks whether the Print button is enabled. If enabled, the trigger body executes a null operation - no print job is created. If the button is disabled, the trigger also executes a null operation. No report, file, or print job is generated.

---

---

#### Requirement ID: BR-020

**Requirement Title:** Windows Calculator Launch

**Business Description:**
When the user clicks the Calc button, the system launches the Windows standard calculator application. This is a utility feature to assist users with quick calculations while reviewing dead-stock data.

**Actors:** Parts Operations User

**Preconditions:**
- The Dead Stock Flag form is open.

**Main Flow:**

**Step 1 - Windows calculator launched**
The user clicks the Calc button. The system executes the Windows shell command to open `calc.exe`.

*Procedures called:*
- **WIN_API_SHELL.WINEXEC** ([SP-008](#SP-008--WIN_API_SHELL.WINEXEC)) - WIN_API_SHELL.WINEXEC - executes a Windows shell command, in this case launching the calculator application.
    * **Step 1** - Receive the executable command string as input.
    * **Step 2** - Retrieve the required business data.
    * **Step 3** - Apply business validations.
    * **Step 4** - Update the required records.
    * **Step 5** - Return the processing result.

---

---

#### Requirement ID: BR-021

**Requirement Title:** Delete Current Record

**Business Description:**
When the user clicks the Delete button, the system checks whether there are pending changes on the form. If there are, the user is asked to confirm the deletion. If the user confirms, the current record is deleted. If there are no pending changes, the form is cleared instead.

**Actors:** Parts Operations User

**Preconditions:**
- The Dead Stock Flag form is open with data displayed.
- The Delete button is enabled.

**Main Flow:**

**Step 1 - Delete button enabled state checked**
The system checks whether the Delete button is currently enabled. If it is not enabled, the action is silently ignored.

**Step 2 - Form validation temporarily suspended and pending-changes checked**
The system temporarily suspends form-level validation, then checks whether the form has pending (unsaved) changes. If the form has unsaved changes, a confirmation prompt is shown: *"Are you sure to Delete"*. If the user confirms (returns 1), the current record is deleted from the screen. If the form has no unsaved changes, the form is cleared instead of deleting a record.

*Procedures called:*
- **GENERAL.ASK_CONFIRM** ([SP-002](#SP-002--GENERAL.ASK_CONFIRM)) - GENERAL.ASK_CONFIRM - displays a confirmation alert for the delete action and returns 1 if the user confirms.
    * **Step 1** - Receive the confirmation message text as input.
    * **Step 2** - Set the confirmation alert's message text.
    * **Step 3** - Display the alert and wait for the user to choose.
    * **Step 4** - Return 1 if the user confirmed, or 0 if the user declined.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Confirmation required before deleting a record | `FT_DEL` - `IF :system.form_status = 'CHANGED' THEN lv_al_id := GENERAL.ASK_CONFIRM('Are you sure to Delete')` | When the user clicks Delete and the form has unsaved changes | Prevents accidental deletion of a record | If the user declines, no record is deleted; the form remains open |

**Step 3 - Form validation re-enabled**
After the delete or clear action, form-level validation is re-enabled.

**Alternative Flows:**
- **BR-021-AF-01** - (from Step 2) If the form has no unsaved changes, the form is cleared (without deleting any record) and validation is not suspended. The clear-then-re-enable sequence runs in the same code block.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| All on-screen fields | N/A during delete | N/A | N/A | N/A | N/A | Delete button enabled | Confirmation required when unsaved changes exist | N/A |

---

---

#### Requirement ID: BR-022

**Requirement Title:** Individual Dead Stock Flag Toggle - Discount Field Behaviour

**Business Description:**
When the user checks or unchecks the Dead Stock Y/N flag on an individual result row, the system immediately adjusts the Discount on DRT field for that row: when the flag is set to Yes, the discount field is highlighted as mandatory, made editable, and a null-check validation is applied; when the flag is set to No, the discount field reverts to the standard display style, becomes read-only, and its value is cleared.

**Actors:** Parts Operations User

**Preconditions:**
- The Dead Stock Flag main screen is open and search results are displayed.

**Main Flow:**

**Step 1 - Discount on DRT field behaviour adjusted based on Dead Stock flag**
When the user checks or unchecks the Dead Stock Y/N checkbox on a result row, the system checks the current state. If the flag is set to Yes, the row's Discount on DRT field is highlighted with the mandatory visual style (cyan background), insert and update are permitted on the field. If the flag is set to No, the row's Discount on DRT field reverts to the standard display style, insert and update are blocked, and the discount value on that row is cleared to blank.

*Screen: PART QUERY (`WN_MAIN` / `CN_MAIN`).*

**Step 2 - Discount null-check applied when individually unflagging with ALL unchecked**
If the Dead Stock flag is set to Yes on the current row AND the header "ALL" checkbox is unchecked (meaning the user is individually flagging this specific part, not using the bulk action), the system additionally validates that the individual Discount on DRT field is not blank.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-004](#SP-004--GENERAL.CHECK_NULL)) - GENERAL.CHECK_NULL - checks whether the individual Discount on DRT field is blank and, if so, shows an error and stops processing.
    * **Step 1** - Receive the item name, the current field value, and the user-facing field label as inputs.
    * **Step 2** - Check whether the supplied value is blank.
    * **Step 3** - If the value is blank, compose the message "Enter a valid [field label]", display it as an error, navigate to the item, and stop processing.
    * **Step 4** - If the value is not blank, return without action.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Individual Discount on DRT must not be blank when the row is individually flagged as Dead Stock and the ALL checkbox is unchecked | `WHEN-CHECKBOX-CHANGED` on DTL_BLK.DEAD_STOCK_YN - `if :DTL_BLK.DEAD_STOCK_YN='Y' and :HDR_BLK.CB_ALL='N'` | When the user changes the Dead Stock flag on an individual row | Ensures each individually flagged part has a discount before the change can proceed | *"Enter a valid Part Discount"* is displayed; field entry is blocked |

*Business outcomes (errors, warnings, success, and status):*
- **BR-022-ES-01** - Individual Discount on DRT is blank when the row is individually flagged and the ALL checkbox is unchecked - *"Enter a valid Part Discount"*; the change is blocked.

#### Business Scenarios - How the discount field changes by Dead Stock flag state

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Dead Stock flag set to Yes** | Discount on DRT field becomes mandatory-styled (cyan background), insert/update enabled; if individually flagged (ALL = No), null-check also runs. |
| **Dead Stock flag set to No** | Discount on DRT field reverts to standard style, insert/update blocked, discount value cleared to blank. |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dead Stock Y/N (`DEAD_STOCK_YN`) | Mandatory | Check box | N/A | N/A | Y / N | Results loaded | Drives discount-field behaviour immediately on change | N/A |
| Discount on DRT - individual (`IND_PART_DISCOUNT`) | Conditional - when Dead Stock = Y | Text/Number | 6 characters | N/A | N/A | Dead Stock = Y | Must not be blank when individually flagged and ALL = N; cleared when Dead Stock set to N | *"Enter a valid Part Discount"* |

---

---

#### Requirement ID: BR-023

**Requirement Title:** POPULATE_DETAILS Internal Utility (No Business Output)

**Business Description:**
The form contains an internal utility procedure that performs a minimal database check returning the value 1. This procedure does not produce any visible output to the user, update any business data, or drive any on-screen behaviour. It is included here for completeness as an active program unit in the form.

**Actors:** System (internal)

**Preconditions:**
- N/A

**Main Flow:**

**Step 1 - Internal check performed**
The POPULATE_DETAILS procedure runs a SELECT 1 FROM DUAL query and stores the result in an internal control variable. No data is displayed to the user, no form field is updated, and no validation or error message is produced.

---

---

## 5. Business Rules Catalogue

| Rule ID | Rule Name | Rule Type | Business Requirement ID | Condition | Action | Business Impact |
| ------- | --------- | --------- | ----------------------- | --------- | ------ | --------------- |
| BRC-001 | Consignee mandatory | Validation | BR-003 | The Consignee filter field is left blank when the user moves to the next field | Block progression and display *"Consignee Code cannot be Null"* | Prevents any search from running without a consignee being identified, ensuring results are scoped correctly |
| BRC-002 | Dealer mandatory | Validation | BR-003 | The Dealer filter field is left blank when the user moves to the next field | Block progression and display *"Dealer Name cannot be Null"* | Ensures every search is associated with a specific dealer or group |
| BRC-003 | Location mandatory | Validation | BR-003 | The Location filter field is left blank when the user moves to the next field | Block progression and display *"Location cannot be Null"* | Prevents an unscoped search from running without a location being specified |
| BRC-004 | "ALL" location resets dealer code | Derivation | BR-004 | The user selects "ALL" as the Location filter and moves to the next field | Automatically set the internal dealer code to the all-dealers indicator (99999) | Ensures that when the user selects all locations, the search correctly spans all dealers in the group |
| BRC-005 | Save disabled for admin user when Location is ALL | Authorization | BR-004 | The user is an administrative user (internal group code 99999) and the Location filter is set to "ALL" | Disable the Save button | Prevents an administrative user from saving dead-stock flag changes across all locations at once |
| BRC-006 | "Not Transacted For" period must be A or B | Validation | BR-005 | The user selects a value other than period band A or period band B from the "Not Transacted For" list | Display the note *"choose the required Slab"* and leave the internal period factor unset | Ensures the slow-moving threshold calculation has a valid period factor before a search can be executed |
| BRC-007 | "ALL" location blocked from part-level save | Constraint | BR-012 | The user attempts to save dead-stock flag decisions while Location is set to "ALL" | Block the save and display *"For part flagging is not applicable for ALL location"* | Part-level dead-stock flagging is only permitted for a specific location; bulk "ALL" save is not supported |
| BRC-008 | Header Discount on DRT mandatory when ALL checkbox is checked | Validation | BR-012 | The "ALL" checkbox is checked and the header-level Discount on DRT field is blank when the user clicks Save | Block the save and display *"Enter a valid Part Discount"* | Ensures a discount rate is always supplied when using the bulk-flag action |
| BRC-009 | Header Discount on DRT must be in range 15-100 when ALL is checked | Validation | BR-012 | The "ALL" checkbox is checked and the header Discount on DRT value is less than 15 or greater than 100 | Block the save and display *"Discount must be in Range 15.00 to 100.00"* | Enforces the valid business range for bulk dead-stock discount rates |
| BRC-010 | Individual Discount on DRT mandatory for flagged parts | Validation | BR-012, BR-022 | A part's Dead Stock flag is Yes and its individual Discount on DRT field is blank | Block the save and display *"Enter a valid Part Discount"* | Ensures every part designated as dead stock is assigned a discount rate before the record is persisted |
| BRC-011 | Individual Discount on DRT must be in range 15-100 for flagged parts | Validation | BR-012 | A part's Dead Stock flag is Yes and its individual Discount on DRT is less than 15 or greater than 100 | Block the save and display *"Discount must be in Range 15.00 to 100.00"* | Enforces the valid business range for individual dead-stock discount rates |
| BRC-012 | Remarks text must not exceed 35 characters | Validation | BR-007 | The user enters remarks text longer than 35 characters in the remarks editor | Display *"Description cannot exceed 35 characters "* and reject the over-length value | Enforces the remarks field length limit to ensure data fits the target column |
| BRC-013 | Confirmation required before bulk flag/unflag | Constraint | BR-010 | The user changes the "ALL" checkbox state | Display *"Would you like to flag/unflag all the parts as dead stock?"* and proceed only if the user confirms | Prevents accidental bulk changes to the Dead Stock flag for all displayed parts |
| BRC-014 | Confirmation required before overwriting individual remarks | Constraint | BR-008 | The user clicks "Replicate to All" for Remarks | Display *"Would you like to overwrite the existing remarks?"* and proceed according to the user's choice | Prevents accidental overwriting of individually entered remarks |
| BRC-015 | Confirmation required before overwriting individual discounts | Constraint | BR-009 | The user clicks "Replicate to All" for Discount on DRT | Display *"Would you like to overwrite the existing Discount?"* and proceed according to the user's choice | Prevents accidental overwriting of individually entered discount values |
| BRC-016 | Confirmation required before discarding unsaved changes (Cancel) | Constraint | BR-013 | The user clicks Cancel and the form has unsaved changes | Display *"Entered data will not be Saved"* and clear the form only if the user confirms | Prevents accidental loss of data the user has entered but not yet saved |
| BRC-017 | Confirmation required before discarding unsaved changes (Exit button) | Constraint | BR-014 | The user clicks the Exit button and the form has unsaved changes | Display *"Entered data will not be Saved"* and close the form only if the user confirms | Prevents accidental data loss when exiting the form with unsaved changes |
| BRC-018 | Confirmation required before deleting a record | Constraint | BR-021 | The user clicks Delete and the form has unsaved changes | Display *"Are you sure to Delete"* and delete the record only if the user confirms | Prevents accidental deletion of data |
| BRC-019 | Dead Stock Y/N toggle enables/disables individual discount field | Derivation | BR-022 | The user changes the Dead Stock Y/N flag on an individual result row | If Dead Stock = Yes: highlight Discount on DRT as mandatory and enable editing; if Dead Stock = No: revert to standard style, block editing, and clear the discount value | Ensures the discount field is only editable and required when a part is actually being designated as dead stock |
| BRC-020 | Excel export row count capped at 65,535 | Constraint | BR-016, BR-017 | The number of result rows in the export query exceeds 65,535 | Truncate the export to 65,535 rows and display *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."* | Enforces the row-count limit of the CSV-to-Excel target format |
| BRC-021 | Excel export file path redirected when spaces present | Derivation | BR-016, BR-017 | The generated file path contains a space character in one of the folder names | Redirect the file to the root of the C drive and notify the user with *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."* | Ensures the file can always be written to a valid server path |
| BRC-022 | Forms message codes 40209 and 40207 intercepted as alert | Constraint | BR-015 | The platform generates a message with code 40209 (navigation error) or 40207 (mandatory-field error) | Suppress the default message handling; re-display as a formatted alert with the pattern error-type-error-code: error-text | Ensures navigation and mandatory-field errors are presented consistently in the application's standard alert style |
| BRC-023 | User identity must be resolvable in the user-dealer master | Validation | BR-001, BR-002 | The form opens or the user triggers Clear Form and no record can be found for the logged-in user in the user-dealer assignment table | Display *"user_id not found"* (if the user record is absent) or *"error while fetching user details"* (if another database error occurs); the form continues to load | Ensures the user's group context is always resolved so that group-specific behaviour (such as the administrative Save button) can be applied |

**Total Business Rules Identified: 23**

---

## 6. Data Requirements

*This form captures and manages dead-stock flag decisions for slow-moving parts inventory. It references part, stock, dealer-location, and category master data, persists flagging records to the dead-stock register, and maintains the corresponding indicator on the part variant record.*

### 6.1 Business Entities and Relationships

*The form writes to and reads from the dead-stock register and the part variant record, and reads part, stock, and dealer-location data to identify slow-moving stock candidates.*

#### Dead Stock Register - PM_PART_DEAD_STOCK (via FT_SAVE / HDR_BLK.PB_SEARCH)

The dead-stock register stores one record per part per location per dealer group representing the current flagging decision. Each record captures the group, dealer code, location, part number, root part number, creation date and user, the most recent modification date and user, a deleted flag indicating whether the designation has been removed, the free-text remarks, and the discount on DRT. When a part is flagged as Dead Stock, an active record is created; when unflagged, the existing active record is removed and a soft-delete record is inserted to preserve the audit trail. The form reads this table during the search to pre-populate existing remarks and discount values, and writes to it during the save operation.

#### Part Variant - PM_PART_VAR (via FT_SAVE)

The part variant record holds the current Dead Stock indicator for each part per group/dealer/location combination. When the user saves flagging decisions, the form updates this record to reflect the current Dead Stock flag value (Yes or No) for each processed part.

#### Entity Relationships

The dead-stock register is the primary entity written by this form. It is linked to the part variant record by the shared group, dealer code, location, and part number key, and is populated from part and stock data read during the search.

```
PM_PART_DEAD_STOCK (Dead Stock Register)
        │  shared key: parent_group, dealer_map_cd, loc_cd, part_num
        └── PM_PART_VAR (Part Variant - dead_stock_yn updated on save)
```

### 6.2 Data Capture Requirements

*The form captures search filter criteria in the header section and then displays results in the detail section for review and flagging. Remarks and discount values can be entered at both the header level (for bulk replication) and at the individual row level.*

#### Search Filters (Parts Operations User - before search)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Consignee (`CONSG_CD`) | Yes | The consignee code identifying the dealer group to search within. Selected from the Consignee list. | Must not be blank when the user moves to the next field; displays *"Consignee Code cannot be Null"* if empty |
| Dealer (`DEALER_NAME`) | Yes | The dealer name/code within the selected consignee group. The internal dealer mapping code (99999 = all dealers) is derived from this selection. | Must not be blank when the user moves to the next field; displays *"Dealer Name cannot be Null"* if empty |
| Location (`LOC_CD`) | Yes | The warehouse or showroom location within the dealer. "ALL" selects all locations (internal dealer code is reset to 99999 when "ALL" is chosen). | Must not be blank when the user moves to the next field; displays *"Location cannot be Null"* if empty; Save is blocked when Location is "ALL" |
| Not Transacted For (`SLAB`) | Yes | The slow-moving period band - A (one year-period unit) or B (two year-period units) - used to calculate the transaction-date threshold. | Must be A or B; any other selection shows *"choose the required Slab"* and leaves the period factor unset |
| Stock (`STOCK`) | Yes | Controls whether zero-stock parts are included in results. Default includes only in-stock parts; "ALL" includes zero-stock parts. | System-set default; must be A or a numeric value; no user-facing validation message evidenced |
| Category (`CATG_CD`) | No | Optional filter to limit results to a specific product category. Populated from the category master at form open. | No validation - if blank, all categories are included |
| Discount on DRT - header (`PART_DISCOUNT`) | Conditional | The bulk discount percentage to apply to all parts when using the "Replicate to All" or bulk-flag function. Required when the "ALL" checkbox is checked. | Must be non-blank when ALL is checked (displays *"Enter a valid Part Discount"*); must be in the range 15.00 to 100.00 (displays *"Discount must be in Range 15.00 to 100.00"*) |
| Remarks - header (`REMARKS`) | No | Free-text remarks to be replicated to all individual rows via the "Replicate to All" button. Maximum 35 characters enforced by the editor. | Maximum 35 characters; over-length text is rejected with *"Description cannot exceed 35 characters "* |

#### Dead Stock Flag Review (Parts Operations User - after search)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Serial No (`SRL_NO`) | Auto-Populated | Row counter assigned from the cursor position during the search result loop. | Read-only; system-generated |
| Part Number (`PART_NUM` in DTL_BLK) | Auto-Populated | The part number as returned by the search query. | Read-only; populated from search results |
| Part Description (`PART_DESC`) | Auto-Populated | The part description as returned by the search query. | Read-only; populated from search results |
| Current Stock (`CURR_STOCK`) | Auto-Populated | The sum of opening-stock and latest-stock quantities for the part and location. | Read-only; populated from search results |
| Purchase Price (`MRP`) | Auto-Populated | The purchase price for the part (rounded to 2 decimal places). | Read-only; populated from search results |
| Dead Stock Y/N (`DEAD_STOCK_YN`) | Yes | The Dead Stock flag for this individual part. Pre-set to Yes after search; the user can uncheck to unflag. Changing this flag immediately adjusts the Discount on DRT field behaviour for the row. | Must be explicitly set by the user or by the ALL checkbox; drives the per-row save path |
| Discount on DRT - individual (`IND_PART_DISCOUNT`) | Conditional | The discount percentage for this specific part. Required when the part's Dead Stock flag is Yes. Pre-filled from the existing dead-stock record if one exists; otherwise defaults to 0. | Must be non-blank when Dead Stock = Yes (displays *"Enter a valid Part Discount"*); must be in the range 15.00 to 100.00 at save time |
| Remarks - individual (`IND_REMARKS`) | No | Free-text remarks for this specific part, editable per row. Pre-filled from the existing dead-stock record's remarks if one exists. | Maximum 100 characters |

#### Summary / Totals (System-Calculated - after search)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| ALL checkbox (`CB_ALL`) | Auto-Populated | Indicates whether all retrieved parts are flagged as Dead Stock. Pre-set to Yes after the search completes. The user can change it to trigger bulk flagging or unflagging. | Confirmation required before bulk update applies |
| Matching records (`TOT_REC`) | Auto-Populated | The total count of parts returned by the search. | Read-only; system-calculated after the results loop completes |
| Total Value (`VAL`) | Auto-Populated | The total stock value (current stock × purchase price) across all retrieved parts, rounded to 2 decimal places. | Read-only; system-accumulated during the results loop |
| % Slow-moving flagged as Dead Stock (`LV_DEAD_PERC`) | Auto-Populated | The percentage of the total slow-moving stock value that has already been formally flagged as dead stock (identified by a non-null flagging date). Calculated for specific locations only. | Read-only; system-calculated after search and before Excel export |
| Part Number - header search (`PART_NUM` in HDR_BLK) | No | A part number entered by the user to locate a specific row within the loaded results grid. Not a search filter; operates on the already-loaded results only. | Must not be blank when the Part Number Search button is clicked; displays *"Enter the Part that is to be searched"* if empty |

#### Session / Parameters

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Session module identifier | Auto-Populated | The application module name registered against the current database session (`pe_dead_stk_rep`), set before the form opens and cleared on exit. Used by database monitoring tools to track active form sessions. | System-set; not user-editable |
| Period slab parameter (`P_SLAB`) | Auto-Populated | Internal numeric factor (1 for band A, 2 for band B) derived from the "Not Transacted For" list selection and used in the slow-moving threshold calculation. | Derived from the SLAB list item; not directly entered by the user |

### 6.3 Reference Data

*Lists the master and configuration data referenced by this form. LOVs are documented here - not as separate functional requirements.*

| Reference Data | Business Purpose | Used When |
| :--- | :--- | :--- |
| Consignee lookup (LV_CONSG / RV_CONSG - AM_DEALER_LOC, AM_USER_REGION, AM_USER_DEALER_MASTER) | Provides the list of consignees (dealer groups) that the logged-in user is authorised to access, based on the user's region or dealer-master assignments and the current principal | When the user opens the Consignee list to select a search scope |
| Dealer lookup (LV_DEALER / RV_DEALER - AM_DEALER_LOC) | Provides the list of dealer names and codes within the selected consignee group and principal organisation | When the user opens the Dealer list after selecting a consignee |
| Location lookup (LV_LOC / RV_LOC - AM_DEALER_LOC) | Provides the list of locations (including the special "ALL" option) within the selected consignee and dealer combination and principal organisation | When the user opens the Location list after selecting a dealer |
| Category master (PM_CATEGORY) | Provides the available product category descriptions and codes, filtered to the current principal organisation | When the form opens, to populate the Category filter drop-down; used as an optional filter in the dead-stock candidate search |
| Part master (PM_PART) | Provides part descriptions and root part numbers, filtered to the current principal organisation; root part numbers are stored in the dead-stock register when a part is flagged | During the search (to retrieve part descriptions) and during the save (to resolve the root part number for each flagged part) |
| Stock master (PM_STOCK, PM_PART_VAR, AM_DEALER_LOC) | Provides current stock quantities, purchase prices, and last-transaction dates, used to identify parts that have not been transacted for longer than the selected period threshold | During the dead-stock candidate search |
| User-dealer assignment master (AM_USER_DEALER_MASTER) | Resolves the logged-in user's group (parent group) membership; used to conditionally enable or restrict the Save button for administrative users | When the form opens (WHEN-NEW-FORM-INSTANCE) and when the form is cleared (KEY-CLRFRM) |
| Configuration file - Excel output path (`/reports/DMS/excelpath.txt`) | Provides the server-side URL path prefix for the generated Excel CSV files so they can be served to the user's browser | When the user generates an Excel report (BR-016, BR-017) |

### 6.4 Data Lifecycle

*Describes how dead-stock flag records are created, updated, and committed within this form's evidenced behaviour.*

**Creation**

- A new active dead-stock register record (PM_PART_DEAD_STOCK) is created for each result-grid row where the Dead Stock flag is Yes and no existing active record is found for that group/dealer/location/part combination. The record is populated with the group, dealer code, location, part number, root part number, the current system date as the creation date, the logged-in user as the creator, a deleted flag of No, the individual remarks, and the individual discount. This occurs within the FT_SAVE trigger, invoked when the user clicks Save.
- When a part is unflagged (Dead Stock = No) and an existing active record is found, that record is first deleted and a replacement record is inserted with the deleted flag set to Yes (soft-delete), preserving the audit record of the prior flagging. This also occurs within the FT_SAVE trigger.

**Updates**

- When a part being flagged already has an existing active dead-stock record, the existing record is deleted and a fresh active record is inserted with the current values (remarks, discount, root part number, creation date, and user). This is an effective replace-on-save behaviour implemented within the FT_SAVE trigger rather than an in-place UPDATE.
- The part variant record (PM_PART_VAR) is updated for each processed row to set the Dead Stock indicator to the current flag value (Yes or No). This UPDATE is performed within the FT_SAVE trigger for every row in the results loop, regardless of the flag direction.

**Save and Commit**

- The user initiates the save by clicking the Save button (PB_BLK.PB_SAVE -> FT_SAVE). The FT_SAVE trigger validates the inputs, confirms with the user, processes all result rows, and then invokes the KEY-COMMIT sequence.
- The KEY-COMMIT trigger runs form validation (`enter`), checks for a form-failure condition (GENERAL.CHECK_FORM_FAILURE), issues `commit_form` to persist all pending changes to the database, checks for failure again, and then clears the form.
- All database changes for the session (inserts, deletes, and updates) are committed in a single transaction by the `commit_form` call within KEY-COMMIT.

**Retention and Audit**

- Each dead-stock register record (PM_PART_DEAD_STOCK) carries a creation date (`created_date`) and creator (`created_by`) captured at insert time from the system date and the logged-in user's username. The modification date and user (`modified_date`, `modified_by`) are inserted as NULL at creation and are not updated by this form.
- When a part is unflagged, the prior active record is replaced by a soft-delete record (deleted flag = Yes), retaining the history of the original flagging decision with its original creation date and user.
- No archival or purge policy is evidenced in this form's code.

---

### 6.5 Excel Output Columns

This form does not use Excel download. No Excel export columns were identified in the form sources.

## 7. Glossary

*Definitions of terms, abbreviations, and acronyms used throughout this document.*

The following table defines key terms, acronyms, and abbreviations used throughout this Business Requirements Document.

| Term | Definition | Aliases | Related Terms |
| :--- | :--- | :--- | :--- |
| AL_CONFIRM | Oracle Forms alert object used to display a Yes/No caution dialog before a destructive or irreversible action | Caution Alert | AL_ERRINFO, AL_NOTE, AL_PRINT |
| AL_ERRINFO | Oracle Forms alert object used to display error messages via the DISP_TEXT shared routine | Error Alert | AL_NOTE, DISP_TEXT |
| AL_NOTE | Oracle Forms alert object used to display informational and confirmation messages | Note Alert | AL_ERRINFO, AL_CONFIRM |
| AL_PRINT | Oracle Forms alert object used to ask the user to choose a print destination (Screen, Printer, or Cancel) | Print Alert | ASK_PRINT |
| ASK_CONFIRM | Shared library function that shows a Yes/No confirmation dialog and returns 1 for Yes or 0 for No | - | AL_CONFIRM, Business Logic |
| ASK_PRINT | Shared library function that shows a print destination alert and returns 1 for Screen, 2 for Printer, 3 for Cancel | - | AL_PRINT, RUN_REPORT |
| CB_ALL | Header block checkbox item used to bulk-flag or unflag all displayed parts as dead stock in a single action | Flag All | DEAD_STOCK_YN, DTL_BLK |
| CB_ERR | Oracle Forms control block containing the error message display item; shown in the error popup window | Error Block | WIN_ERR, TXT_ERR |
| CHECK_FORM_FAILURE | Shared library procedure that checks whether the last Oracle Forms operation succeeded and raises an error if it failed | - | DISP_TEXT, Validation |
| CHECK_NULL | Shared library procedure that validates a required field value is not null and raises an error message if empty | - | DISP_TEXT, Validation |
| CN_MAIN | Content canvas displayed in the main form window containing the header search fields | Main Canvas | WN_MAIN, CN_MAIN1 |
| CONSG_CD | Consignee code - identifies the consignee category or grouping for a dealer outlet | Consignee | DEALER_NAME, LOC_CD |
| CSV | Comma-Separated Values - file format used for the Excel export of dead stock results | - | Excel Report, VIEW_EXCEL_REP |
| DEAD_STOCK_YN | Flag column (Y/N) on a part record indicating whether the part is classified as dead stock | Dead Stock Flag | PM_PART_DEAD_STOCK, PM_PART_VAR |
| DEALER_MAP_CD | Dealer mapping code - unique identifier assigned to a dealer outlet within the DMS | - | PARENT_GROUP, DEALER_NAME |
| DISP_TEXT | Shared library procedure that displays a message or error alert dialog; routes to AL_ERRINFO for errors and AL_NOTE otherwise | - | AL_ERRINFO, AL_NOTE, Business Logic |
| DMS | Dealer Management System - integrated software platform for managing dealer operations, parts, and service | - | pt_dead_stock_flag, AM_DEALER_LOC |
| DPL | DPL.pld - the shared Oracle Forms program library providing common utility routines (alerts, validations, reports) used across DMS forms | General Library | PLD, GENERAL |
| DTL_BLK | Oracle Forms detail block displaying the list of parts returned by the dead stock search | Detail Block | HDR_BLK, DEAD_STOCK_YN |
| GENERAL | The package alias used to invoke DPL shared library routines (e.g. GENERAL.DISP_TEXT, GENERAL.CHECK_NULL) | - | DPL, PLD |
| HDR_BLK | Oracle Forms header block containing the search filter fields (consignee, dealer, location, slab, category) | Header Block | DTL_BLK, PB_BLK |
| IND_PART_DISCOUNT | Individual part discount - the discount percentage applied to a specific flagged part row | Per-Part Discount | PART_DISCOUNT, DEAD_STOCK_YN |
| IND_REMARKS | Individual part remarks - free-text note recorded against a specific part row | Per-Part Remarks | REMARKS |
| LOC_CD | Location code - identifies the dealer's stock location; 'ALL' denotes all locations | Location | DEALER_MAP_CD, AM_DEALER_LOC |
| LOV | List of Values - dropdown selection popup used in Oracle Forms for consignee, dealer, and location fields | Dropdown, Picklist | RV_CONSG, RV_DEALER, RV_LOC |
| MRP | Maximum Retail Price - the listed selling price of a part, displayed in the dead stock results | - | CURR_STOCK, DTL_BLK |
| PARENT_GROUP | Parent dealer group code - identifies the dealer group hierarchy level; '99999' indicates an administrator or multi-group access | - | DEALER_MAP_CD, AM_USER_DEALER_MASTER |
| PART_DISCOUNT | Bulk part discount - the discount percentage entered in the header block and applied to all flagged parts | Header Discount | IND_PART_DISCOUNT |
| PB_BLK | Oracle Forms push-button toolbar block containing action buttons (Save, Cancel, Exit, Print, etc.) | Toolbar Block | HDR_BLK, DTL_BLK |
| PK_PART_SEARCH_NEW | Database package used to execute the dead stock parts search query and return the result set | Parts Search Package | DTL_BLK, PB_SEARCH |
| PLD | Oracle Forms program library (.pld file) - compiled PL/SQL library attached to a form to provide shared utility procedures and functions | Program Library | DPL, GENERAL |
| PM_CATEGORY | Parts category master table - provides category descriptions and codes for the category filter dropdown | - | CATG_CD, WHEN-NEW-FORM-INSTANCE |
| PM_PART | Parts master table - stores part number, description, and root part number used during dead stock save | Parts Master | PM_PART_DEAD_STOCK, PM_PART_VAR |
| PM_PART_DEAD_STOCK | Dead stock register table - records dead stock flag entries per part, dealer, location, with remarks, discount, and audit columns | Dead Stock Register | PM_PART_VAR, DEAD_STOCK_YN |
| PM_PART_VAR | Part variant master table - stores variant-level attributes including the dead stock flag (DEAD_STOCK_YN) updated on save | Part Variant | PM_PART, PM_PART_DEAD_STOCK |
| PRINCIPAL | Principal manufacturer code - used for multi-organisation filtering of dealers, parts, and categories | Principal Code | PARENT_GROUP, AM_DEALER_LOC |
| pt_dead_stock_flag | Oracle Forms module name for the Dead Stock Flagging screen (form identifier PT_DEAD_STOCK_FLAG) | Dead Stock Flagging Form | DMS, HDR_BLK |
| REMARKS | Common remarks text - a header-level free-text note that can be applied to all or empty detail part rows | Header Remarks | IND_REMARKS, PB_RM |
| RV_CONSG | Record group providing the consignee lookup list for the LV_CONSG LOV | - | LV_CONSG, AM_DEALER_LOC |
| RV_DEALER | Record group providing the dealer name lookup list for the LV_DEALER LOV | - | LV_DEALER, AM_DEALER_LOC |
| RV_LOC | Record group providing the location lookup list for the LV_LOC LOV | - | LV_LOC, AM_DEALER_LOC |
| SLAB | Slab category (A or B) - determines the dead stock threshold used when querying parts for a dealer | Slab Category | P_SLAB, DTL_BLK |
| VIEW_EXCEL_REP | Form-local procedure that exports the dead stock parts list to a CSV file on the server and opens it in the browser | Excel Export Procedure | PB_EXCEL, CSV |
| WN_MAIN | Main application window (title: Dead Stock Flagging 2.7.3) displayed to the user | Main Window | CN_MAIN, CN_MAIN1 |

---

---

## 8. Technical Inventory

*Complete inventory of Oracle Forms components including blocks, items, triggers, canvases, and global variables.*

### 8.1 Form Architecture

**Form Module Details:**

- Form Name: pt_dead_stock_flag (PT_DEAD_STOCK_FLAG)
- Form Module XML Title: MODULE2
- Oracle Forms Version: 12c (Module version 122010400)
- Parent Object Library: -
- Attached Libraries: DPL (DPL.pld program library), D2KWUTIL
- First Navigation Block: -
- Console Window: WN_MAIN - Dead Stock Flagging (2.7.3)
- Compile Dependencies: Requires DPL.pld, WEBUTIL.olb, menu.mmx, database packages PK_PART_SEARCH_NEW
- Source artifacts: `pt_dead_stock_flag_fmb.xml`; DPL (DPL.pld program library); D2KWUTIL

### 8.1.1 Global Variables

| Global Variable | Data Type | Set Location | Purpose |
| :--- | :--- | :--- | :--- |
| APP_LOG | Char | Trigger | Application logging flag; set to 'Y' to enable activity logging |
| COMP_FA | Char | Trigger | Company financial area code used for multi-org context |
| CURRENCY | Char | Trigger | Currency symbol displayed in monetary fields (e.g., Rs) |
| DEALER | Char | Trigger | Dealer identifier code used for filtering dealer-specific data |
| FIN_BEG | Char | Trigger | Financial year start date used for period-based reporting |
| FIN_END | Char | Trigger | Financial year end date used for period-based reporting |
| LOC_CD | Char | Trigger | Default location code used for filtering stock records |
| LV_REC_COUNT | Number | Trigger | Record counter flag used to control detail block navigation logic |
| PARENT_GROUP | Char | RecordGroup / Trigger | Parent dealer group code used to filter dealer and location lists |
| PRINCIPAL | Char | RecordGroup / Trigger | Principal manufacturer code used for multi-org part and dealer filtering |
| P_FIN_YR | Char | Trigger | Current financial year value used for report parameters |
| REP_SERVER | Char | Trigger | Report server name used when submitting reports for execution |
| TALLY_INTEGRATION | Char | Trigger | Tally integration flag indicating whether Tally posting is active |
| USERID | Char | ProgramUnit / RecordGroup / Trigger | Logged-in user ID used for access control and record ownership |
| USER_NAME | Char | Trigger | Logged-in user display name stored for audit trail on saved records |

### 8.1.2 Form Parameters

*All 5 ModuleParameter entries from pt_dead_stock_flag_fmb.xml.*

| Parameter | Data Type | Default | Description |
| :--- | :--- | :--- | :--- |
| P_SLAB | Char | 1 | Slab category selection parameter; defaults to 1 (Slab A); set by WHEN_LIST_CHANGED trigger when slab is chosen |
| P | Char | - | General-purpose parameter; reserved - not used in current form logic |
| P_STOCK | Char | - | Stock type filter parameter passed to the form at startup for filtering dead stock results |
| P_CAT | Char | - | Category code parameter used to pre-filter parts by category when form is invoked |
| P_SRL_NUM | Number | 0 | Serial number counter for pagination or report row sequencing; defaults to 0 |

**Total Parameters:** 5

### 8.2 Blocks

| Block Name | Query Data Source | Records | Q/I/U/D | Key Mode | Master-Detail Relationship |
| :--- | :--- | :--- | :--- | :--- | :--- |
| HDR_BLK | - | 1 | N/N/N/N | Default | Control - header search and filter entry block for dealer, consignee, location, and slab |
| DTL_BLK | - | 20 | N/N/N/N | Default | Control - detail results block displaying parts search results for dead stock flagging |
| CB_ERR | - | 15 | N/N/N/N | Default | Control - error display block showing validation errors from the error window |
| PB_BLK | - | 1 | N/N/N/N | Default | Control - toolbar push-button block for form actions (Save, Cancel, Exit, Print, etc.) |

**Total Blocks:** 4 business blocks

### 8.2.1 Block WhereClause and OrderByClause

*Block query scope from pt_dead_stock_flag_fmb.xml. **Description** explains filter and sort in business terms; **Order By** and **Where Clause** columns retain verbatim XML text for migration.*

| Block | Description | Order By (XML) | Where Clause (XML) |
| :--- | :--- | :--- | :--- |
| - | No blocks with WhereClause/OrderByClause in pt_dead_stock_flag_fmb.xml | - | - |

### 8.3 Items Summary

*Complete item inventory from `pt_dead_stock_flag_fmb.xml`.*

**Block counts:**

*Database / non-database counts derived from XML.*

| Block | Total Items | Database Items | Non-Database Items |
| :--- | ---: | ---: | ---: |
| HDR_BLK | 27 | 0 | 27 |
| DTL_BLK | 9 | 0 | 9 |
| CB_ERR | 1 | 0 | 1 |
| PB_BLK | 14 | 0 | 14 |
| **Total** | **51** | **0** | **51** |

**Item detail (all 51 items):**

| Block | Item Name | DatabaseItem | Description |
| :--- | :--- | :--- | :--- |
| HDR_BLK | PARENT_GROUP | false | Parent dealer group code; populated from AM_USER_DEALER_MASTER on form open |
| HDR_BLK | DEALER_MAP_CD | false | Dealer mapping code; auto-populated when dealer name is selected from LOV |
| HDR_BLK | CONSG_CD | false | Consignee code filter; user selects from consignee LOV to narrow dealer list |
| HDR_BLK | DEALER_NAME | false | Dealer name filter; user selects from dealer LOV to identify the target outlet |
| HDR_BLK | LOC_CD | false | Location code filter; user selects from location LOV (or 'ALL' for all locations) |
| HDR_BLK | SLAB | false | Slab category list item; user selects slab A or B to determine dead stock threshold |
| HDR_BLK | STOCK | false | Stock type filter display field for narrowing part search results |
| HDR_BLK | CATG_CD | false | Part category code list item; user selects part category for filtering the search |
| HDR_BLK | PB_SEARCH | false | Search button; executes part dead stock query and populates the detail block |
| HDR_BLK | REMARKS | false | Common remarks text field; applied to all detail rows when overwrite is confirmed |
| HDR_BLK | PB_RM | false | Remarks editor button; opens popup editor to enter multi-line remarks text |
| HDR_BLK | PB_REP | false | Apply remarks button; copies header remarks to all or empty detail remark fields |
| HDR_BLK | X | false | Placeholder or spacer field; no active business function |
| HDR_BLK | TOT_REC | false | Total records display; shows count of parts returned by the search |
| HDR_BLK | VAL | false | Total value display; shows aggregate value of dead stock parts |
| HDR_BLK | CB_ALL | false | Flag/unflag all checkbox; toggles dead stock flag for all displayed parts simultaneously |
| HDR_BLK | PART_DISCOUNT | false | Bulk part discount field; discount percentage applied to all parts when CB_ALL is checked |
| HDR_BLK | PB_REP2 | false | Apply discount button; copies header discount to all or empty detail discount fields |
| HDR_BLK | PB_EXCEL | false | Excel report button; exports dead stock part list to a CSV/Excel file for download |
| HDR_BLK | PUSH_BUTTON103 | false | Additional Excel export button; alternate export trigger for dead stock data |
| HDR_BLK | TEXT_ITEM51 | false | Informational text display item; label or static message on the header canvas |
| HDR_BLK | DUMMY | false | Dummy field used to store parent group check value from AM_USER_DEALER_MASTER |
| HDR_BLK | PART_NUM | false | Part number search field; allows filtering results by a specific part number |
| HDR_BLK | PB_PART_SEARCH | false | Part search button; searches for a specific part number within the result set |
| HDR_BLK | TEXT_ITEM104 | false | Informational text display item; label or static message on the header canvas |
| HDR_BLK | TEXT_ITEM107 | false | Informational text display item; label or static message on the header canvas |
| HDR_BLK | LV_DEAD_PERC | false | Dead stock percentage field; displays calculated percentage of dead stock parts |
| DTL_BLK | SRL_NO | false | Serial number; sequential row number for each part in the results list |
| DTL_BLK | PART_NUM | false | Part number; unique identifier of the part in the dead stock results |
| DTL_BLK | PART_DESC | false | Part description; name or description of the part retrieved from the parts master |
| DTL_BLK | CURR_STOCK | false | Current stock quantity; total on-hand and in-transit stock quantity for the part |
| DTL_BLK | MRP | false | Maximum retail price; purchase/sale price of the part |
| DTL_BLK | IND_REMARKS | false | Individual part remarks; free-text note for the specific part row |
| DTL_BLK | DEAD_STOCK_YN | false | Dead stock checkbox; user flags or unflags the individual part as dead stock |
| DTL_BLK | TEMP | false | Temporary working field; used for intermediate calculation or state tracking |
| DTL_BLK | IND_PART_DISCOUNT | false | Individual part discount; discount percentage applied to this specific part row |
| CB_ERR | TXT_ERR | false | Error message text display; shows validation error text in the error window |
| PB_BLK | PB_EXIT | false | Exit button; closes the form after confirming any unsaved changes |
| PB_BLK | PB_LIST | false | List values button; invokes LOV for the currently focused field |
| PB_BLK | PB_INSERT | false | Insert button; executes FT_INSERT trigger to navigate to a new record row |
| PB_BLK | PM_CONT | false | Continue or refresh button; may initiate a form navigation action |
| PB_BLK | PB_DEL | false | Delete button; executes FT_DEL trigger to delete the current record |
| PB_BLK | PB_CANCEL | false | Cancel button; executes FT_CANCEL trigger to discard unsaved changes |
| PB_BLK | PB_SAVE | false | Save button; executes FT_SAVE trigger to persist dead stock flag changes |
| PB_BLK | PB_PSETUP | false | Printer setup button; opens printer selection dialog for report output |
| PB_BLK | PB_PRINT | false | Print button; executes FT_PRINT trigger to print the current view |
| PB_BLK | PB_CALC | false | Calculator button; launches Windows calculator application |
| PB_BLK | PB_CUT | false | Cut button; performs clipboard cut operation on selected text |
| PB_BLK | PB_COPY | false | Copy button; performs clipboard copy operation on selected text |
| PB_BLK | PB_PASTE | false | Paste button; performs clipboard paste operation at cursor position |
| PB_BLK | PB_ERR_EXIT | false | Error exit button; closes the error popup window and returns to the main form |

### 8.4 List of Values

| LOV Name | Title | Record Group | Attached Block.Item |
| :--- | :--- | :--- | :--- |
| LV_CONSG | Consignee Code | RV_CONSG | HDR_BLK.CONSG_CD |
| LV_DEALER | Dealer Name | RV_DEALER | HDR_BLK.DEALER_NAME |
| LV_LOC | Location | RV_LOC | HDR_BLK.LOC_CD |

**Total LOVs:** 3

### 8.5 Alerts

| Alert Name | Title | Message Text | Calling Context |
| :--- | :--- | :--- | :--- |
| AL_ERRINFO | Error | (set at runtime) | PLD Routine: DISP_TEXT - invoked when title_string is 'ERROR'; called from multiple triggers and program units via GENERAL.DISP_TEXT |
| AL_NOTE | Note | (set at runtime) | Trigger: FT_SAVE in Form - displays save confirmation message before committing dead stock flag changes; also used by DISP_TEXT when title is not 'ERROR' |
| AL_CONFIRM | Caution | (set at runtime) | Trigger: WHEN-BUTTON-PRESSED in HDR_BLK.PB_REP, Trigger: WHEN-BUTTON-PRESSED in HDR_BLK.PB_REP2, Trigger: WHEN-CHECKBOX-CHANGED in HDR_BLK.CB_ALL, Trigger: FT_CANCEL in Form, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_EXIT (via GENERAL.ASK_CONFIRM) |
| AL_PRINT | Print | (set at runtime) | PLD Routine: ASK_PRINT - displays print destination selection dialog; invoked when printing reports |

**Total Alerts:** 4

### 8.6 Program Units

*Authoritative catalogue of **2 form-local program units**. Database packages and standalone procedures are in **Section 15.2**; PLD shared-library routines are in **Section 18**.*

| Program Unit | Type | Calls | Description |
| :--- | :--- | :--- | :--- |
| POPULATE_DETAILS | Procedure | DUAL | Stub procedure that selects 1 from DUAL into an internal variable; does not perform any business operation in the current implementation |
| VIEW_EXCEL_REP | Procedure | PK_PART_SEARCH_NEW.part_tab_11, TEXT_IO, WEB | Generates and exports a dead stock parts list to a CSV file on the server, then opens the file URL in the browser; accepts query, column name, and optional filename parameters |

**Total Program Units:** 2

### 8.7 Triggers

**Item-Level Trigger Types (reference):**

| Trigger Name | Purpose |
| :--- | :--- |
| WHEN-VALIDATE-ITEM | Validates field when user leaves item |
| KEY-* | Keyboard actions - commit, exit, LOV, navigation |
| WHEN-NEW-BLOCK-INSTANCE | Initializes block on entry |
| WHEN-BUTTON-PRESSED | Executes button action |
| PRE-INSERT / POST-INSERT | Before/after record creation |
| WHEN-LIST-CHANGED | Dropdown selection changed |
| PRE-QUERY / POST-QUERY | Before/after query execution |
| WHEN-CHECKBOX-CHANGED | Checkbox toggled |
| WHEN-VALIDATE-RECORD | Validates entire record before leaving row |

**DPL library routines invoked from triggers and program units:**

| Routine | Type | Called From | Purpose |
| :--- | :--- | :--- | :--- |
| GENERAL.ASK_CONFIRM | Library routine | Form level, PB_BLK.PB_EXIT | Displays a confirmation alert prompting the user to proceed or cancel a destructive action (e.g., discard unsaved changes, overwrite remarks/discounts); returns the user's choice to the calling trigger |
| GENERAL.CHECK_NULL | Library routine | DTL_BLK.DEAD_STOCK_YN, Form level | Validates that a required field is not null; displays error message and raises form trigger failure if value is empty |
| GENERAL.DISP_TEXT | Library routine | Form level, HDR_BLK.CONSG_CD, HDR_BLK.DEALER_NAME, HDR_BLK.LOC_CD, HDR_BLK.PB_PART_SEARCH, HDR_BLK.PB_RM, HDR_BLK.PB_SEARCH, HDR_BLK.SLAB | Displays a text message in an alert dialog with the specified title; uses AL_ERRINFO for errors and AL_NOTE for other messages |
| GENERAL.L_POP_LIST_ITEM | Library routine | Form level | Populates a list item (drop-down) with values retrieved from a query or record group at runtime |
| WEBUTIL_FILE_TRANSFER.URL_TO_CLIENT | Library routine | ProgramUnit: VIEW_EXCEL_REP | Transfers a file from the server to the client machine by resolving the server-side file URL; used to deliver the generated CSV export to the user's browser |
| WEBUTIL_HOST.HOST | Library routine | ProgramUnit: VIEW_EXCEL_REP | Executes a host operating-system command on the server; used within VIEW_EXCEL_REP to invoke shell operations required during CSV file generation |

### 8.7.1 Inactive / Commented-Out Trigger Register

*Triggers and field validations where XML source is `null;`, fully block-commented, or legacy code preserved but not executed. Do **not** migrate these as active business requirements.*

| Status | Block | Item | Trigger | Former behaviour (preserved in comments) | Disabled since / note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Commented out** | Form | - | FT_DEL | Delete record logic: navigated to base block, called ASK_CONFIRM for delete confirmation, executed Delete_record, committed form, and displayed Delete Successful message | Full trigger body block-commented; active code proceeds directly to delete without this legacy GENERAL package flow |
| **Commented out** | Form | - | WHEN-NEW-FORM-INSTANCE | Initialized all global session variables (PRINCIPAL, PARENT_GROUP, DEALER, LOC_CD, CURRENCY, COMP_FA, REP_SERVER, P_FIN_YR, USER_NAME, USERID, APP_LOG, FIN_BEG, FIN_END, TALLY_INTEGRATION) via DEFAULT_VALUE calls | DEFAULT_VALUE initialization block fully commented out; globals are now initialized at session level outside the form |

*Additional null-only or partially commented triggers exist on estimation and legacy blocks - see XML `TriggerText` starting with `null;` or `/*`.*

**Complete trigger inventory (40 business triggers):**
*pt_dead_stock_flag_fmb.xml contains Trigger elements.*

| Trigger Name | Block | Item | Called From / Context | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| ON-ERROR | Form | - | Form level | Intercepts Oracle Forms runtime errors; delegates to standard error handling |
| ON-MESSAGE | Form | - | Form level | Intercepts Oracle Forms messages; displays error-type messages (codes 40209, 40207) via DISP_TEXT and suppresses others |
| FT_SAVE | Form | - | Form level | Validates header and detail fields, confirms dead stock flagging action, inserts or updates PM_PART_DEAD_STOCK records, updates PM_PART_VAR dead stock flag, and commits the transaction |
| KEY-COMMIT | Form | - | Form level | Enters validation mode, commits the form, checks for errors, then clears the form |
| KEY-LISTVAL | Form | - | Form level | Opens the LOV associated with the currently focused item and advances focus on successful selection |
| KEY-EXIT | Form | - | Form level | Records application info and exits the form without validation |
| KEY-CLRFRM | Form | - | Form level | Retrieves logged-in user's parent group from AM_USER_DEALER_MASTER, conditionally enables the Save button for admin users, and clears the form |
| FT_CANCEL | Form | - | Form level | Resets slab and serial number parameters; prompts user to confirm discarding unsaved changes, then clears the form |
| FT_INSERT | Form | - | Form level | Navigates to the last record and appends a new row for data entry if the Insert button is enabled |
| FT_DEL | Form | - | Form level | **COMMENTED OUT / INACTIVE** - Active code: calls ASK_CONFIRM for delete confirmation, navigates to block, deletes record; legacy logic block-commented |
| FT_LIST | Form | - | Form level | Invokes the KEY-LISTVAL action if the List button is enabled |
| FT_PRINT | Form | - | Form level | Placeholder for print logic; currently executes NULL - no active print action |
| WHEN-NEW-FORM-INSTANCE | Form | - | Form level | Maximizes the main window, populates the category list from PM_CATEGORY, fetches the logged-in user's parent group, and sets visual attributes for mandatory discount fields |
| PRE-FORM | Form | - | Form level | Sets Oracle application client info to 'pe_dead_stk_rep' for session tracking |
| WHEN-VALIDATE-ITEM | HDR_BLK | CONSG_CD | HDR_BLK.CONSG_CD | Validates that consignee code is not null; raises error if empty |
| WHEN-VALIDATE-ITEM | HDR_BLK | DEALER_NAME | HDR_BLK.DEALER_NAME | Validates that dealer name is not null; raises error if empty |
| WHEN-VALIDATE-ITEM | HDR_BLK | LOC_CD | HDR_BLK.LOC_CD | Validates that location code is not null; raises error if empty |
| KEY-NEXT-ITEM | HDR_BLK | LOC_CD | HDR_BLK.LOC_CD | Sets dealer map code to 99999 when location is ALL; disables Save for admin users with ALL location; advances to next item |
| WHEN_LIST_CHANGED | HDR_BLK | SLAB | HDR_BLK.SLAB | Translates slab selection (A or B) to numeric parameter P_SLAB (1 or 2); shows error if invalid slab selected |
| WHEN-BUTTON-PRESSED | HDR_BLK | PB_SEARCH | HDR_BLK.PB_SEARCH | Executes dead stock parts search query using PK_PART_SEARCH_NEW and populates the DTL_BLK with matching parts and stock data |
| WHEN-BUTTON-PRESSED | HDR_BLK | PB_RM | HDR_BLK.PB_RM | Opens the E_Remarks popup editor for multi-line remarks entry; writes result back to REMARKS field |
| WHEN-BUTTON-PRESSED | HDR_BLK | PB_REP | HDR_BLK.PB_REP | Prompts user to confirm overwriting existing remarks; copies header remarks to all or only empty detail remarks fields |
| WHEN-CHECKBOX-CHANGED | HDR_BLK | CB_ALL | HDR_BLK.CB_ALL | Prompts user to confirm bulk flag/unflag action; sets all detail DEAD_STOCK_YN values to match CB_ALL and updates mandatory visual attribute for discount field |
| WHEN-BUTTON-PRESSED | HDR_BLK | PB_REP2 | HDR_BLK.PB_REP2 | Prompts user to confirm overwriting existing discounts; copies header part discount to all or only empty detail discount fields |
| WHEN-BUTTON-PRESSED | HDR_BLK | PB_EXCEL | HDR_BLK.PB_EXCEL | Builds dead stock query and calls VIEW_EXCEL_REP to export results as a CSV file and open it in the browser |
| WHEN-BUTTON-PRESSED | HDR_BLK | PUSH_BUTTON103 | HDR_BLK.PUSH_BUTTON103 | Alternate Excel export button; builds dead stock query and calls VIEW_EXCEL_REP to export and open CSV file |
| WHEN-BUTTON-PRESSED | HDR_BLK | PB_PART_SEARCH | HDR_BLK.PB_PART_SEARCH | Searches for a specific part number within the loaded detail records; highlights matching row or shows not-found message |
| WHEN-CHECKBOX-CHANGED | DTL_BLK | DEAD_STOCK_YN | DTL_BLK.DEAD_STOCK_YN | Validates discount field is not null when part is flagged as dead stock; enables or disables individual discount field based on flag value |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EXIT | PB_BLK.PB_EXIT | Exits the form; prompts user to confirm discarding unsaved data if form status is CHANGED |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_LIST | PB_BLK.PB_LIST | Delegates to FT_LIST trigger to open the LOV for the current item |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_INSERT | PB_BLK.PB_INSERT | Delegates to FT_INSERT trigger to append a new record row |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_DEL | PB_BLK.PB_DEL | Delegates to FT_DEL trigger to delete the current record |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CANCEL | PB_BLK.PB_CANCEL | Delegates to FT_CANCEL trigger to discard unsaved changes |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SAVE | PB_BLK.PB_SAVE | Delegates to FT_SAVE trigger to save dead stock flag changes |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PSETUP | PB_BLK.PB_PSETUP | Opens the Windows printer selection dialog to configure printer and port settings |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PRINT | PB_BLK.PB_PRINT | Delegates to FT_PRINT trigger to print the current view |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CALC | PB_BLK.PB_CALC | Launches the Windows calculator application via shell command |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CUT | PB_BLK.PB_CUT | Performs clipboard cut operation on the selected text region |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_COPY | PB_BLK.PB_COPY | Performs clipboard copy operation on the selected text region |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PASTE | PB_BLK.PB_PASTE | Performs clipboard paste operation at the current cursor position |

### 8.8 Canvas and Window Inventory

**Windows:**

| Window | Title | Primary Canvas |
| :--- | :--- | :--- |
| WINDOW1 | - | - |
| WN_MAIN | Dead Stock Flagging (2.7.3) | CN_MAIN1 |
| WIN_ERR | Errors | CN_ERR |

**Canvases:**

| Canvas | Type | Window |
| :--- | :--- | :--- |
| CN_MAIN | Content | WN_MAIN |
| CN_ERR | Stacked | WIN_ERR |
| CN_MAIN1 | Content | WN_MAIN |
| CN_TOOL | Vertical Toolbar | WN_MAIN |

---

### 8.9 Editors

*Popup multi-line editors defined in pt_dead_stock_flag_fmb.xml; items reference editors via Item.EditName.*

| Editor | Title | Item Count | Attached Items (Block.Item) |
| :--- | :--- | ---: | :--- |
| E_REMARKS | Remarks | 0 | - |

**Total Editors:** 1 *(0 attached to items; 1 defined but not currently bound)*

### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

#### 8.10.1 Visual Attributes (form-defined)

*17 VisualAttribute elements defined at form level (not inherited from DPL.olb).*

| Visual Attribute |
| :--- |
| VA_MANDATORY |
| VA_DEFAULT |
| VA_DISP |
| VA_LOV |
| VA_TRNI_DT |
| VA_TITLE |
| VA_ALERT |
| VA_BUTN |
| VA_TEXT |
| VA_MPROMPT |
| VA_OPROMPT |
| VA_MAND |
| VA_NUM |
| VA_DESC |
| VA_ICONIC_BUTN |
| VA_RB |
| VA_CB |

#### 8.10.2 Property Classes (form-defined)

*Form-local PropertyClass elements.*

*No form-local property classes found in pt_dead_stock_flag_fmb.xml.*

#### 8.10.3 Object Groups

*Object groups bundle inherited triggers and visual objects applied form-wide at runtime.*

| Object Group Child | Type |
| :--- | :--- |
| CN_ERR | Inherited canvas |
| VA_DISP | Inherited visualattribute |
| CB_ERR | Inherited block |
| VA_LOV | Inherited visualattribute |
| VA_TRNI_DT | Inherited visualattribute |
| VA_TITLE | Inherited visualattribute |
| VA_ALERT | Inherited visualattribute |
| VA_BUTN | Inherited visualattribute |
| VA_TEXT | Inherited visualattribute |
| VA_MPROMPT | Inherited visualattribute |
| VA_OPROMPT | Inherited visualattribute |
| VA_MAND | Inherited visualattribute |
| VA_NUM | Inherited visualattribute |
| VA_DESC | Inherited visualattribute |
| VA_ICONIC_BUTN | Inherited visualattribute |
| VA_RB | Inherited visualattribute |
| VA_CB | Inherited visualattribute |
| WN_MAIN | Inherited window |
| POP_MAIN | Inherited trigger |
| CN_MAIN1 | Inherited canvas |
| CN_TOOL | Inherited canvas |
| PB_BLK | Inherited block |
| AL_ERRINFO | Inherited alert |
| AL_NOTE | Inherited alert |
| AL_CONFIRM | Inherited alert |
| WIN_ERR | Inherited window |
| AL_PRINT | Inherited alert |
| FT_SAVE | Inherited trigger |
| FT_CANCEL | Inherited trigger |
| FT_INSERT | Inherited trigger |
| FT_DEL | Inherited trigger |
| FT_LIST | Inherited trigger |
| FT_PRINT | Inherited trigger |
| WHEN-NEW-FORM-INSTANCE | Inherited trigger |

### 8.11 DataSourceColumn Inventory

*No DataSourceColumns found in pt_dead_stock_flag_fmb.xml.*

## 9. Object Library

*The form references the DPL object library, which provides standardised visual attributes, property classes, and an object group used across all DMS forms to ensure consistent field appearance and behaviour.*

Source OLB file(s): DPL_olb.xml

| Name | Type | Description | Used By (count) | Sample Items |
| ---- | ---- | ----------- | --------------- | ------------ |
| VA_CB | VisualAttribute | Check-box item style - gray background, black foreground, Arial 8pt | Not directly referenced in form items | N/A |
| VA_RB | VisualAttribute | Radio-button item style - gray background, black foreground, Arial 8pt | Not directly referenced in form items | N/A |
| VA_ICONIC_BUTN | VisualAttribute | Iconic button style - white background, black foreground | 7 items in form | Push buttons configured as icon buttons |
| VA_DESC | VisualAttribute | Description field style - gray background, blue foreground, Small Fonts 7pt | Not directly referenced in form items | N/A |
| VA_NUM | VisualAttribute | Numeric field style - white background, black foreground, Arial 8pt, medium weight | Not directly referenced in form items | N/A |
| VA_MAND | VisualAttribute | Mandatory field highlight - cyan background, black foreground, Arial 9pt; applied dynamically to Discount on DRT fields to indicate that a value is required | 2 items in form | HDR_BLK.PART_DISCOUNT, DTL_BLK.IND_PART_DISCOUNT |
| VA_MANDATORY | VisualAttribute (INFERRED - referenced by name in trigger code; not found as a named entry in the OLB tab; likely VA_MAND in effect) | Mandatory visual style referenced in WHEN-NEW-FORM-INSTANCE, KEY-CLRFRM, FT_SAVE, and WHEN-CHECKBOX-CHANGED trigger code as `'VA_MANDATORY'` | Referenced in trigger code dynamically via set_item_property | DTL_BLK.IND_PART_DISCOUNT, HDR_BLK.PART_DISCOUNT |
| VA_DEFAULT | VisualAttribute (INFERRED - referenced by name in trigger code) | Default (non-mandatory) visual style, applied when the Dead Stock flag is set to No to revert the Discount field to the standard appearance | Referenced in trigger code dynamically via set_item_property | DTL_BLK.IND_PART_DISCOUNT, HDR_BLK.PART_DISCOUNT |
| VA_OPROMPT | VisualAttribute | Optional field prompt style - white background, black prompt foreground, Arial 9pt | Not directly referenced in form items | N/A |
| VA_MPROMPT | VisualAttribute | Mandatory field prompt style - white background, red prompt foreground, Arial 9pt | Not directly referenced in form items | N/A |
| VA_TEXT | VisualAttribute | Standard text field style - white background, black foreground, Arial 9pt, plain medium | Not directly referenced in form items | N/A |
| VA_BUTN | VisualAttribute | Push button style - gray background, black foreground, Arial 10pt bold | Not directly referenced in form items | N/A |
| VA_ALERT | VisualAttribute | Alert box style - gray background, black foreground, MT Extra 11pt demilight | 4 items in form | Alert objects |
| VA_TITLE | VisualAttribute | Title/heading style - gray background, blue foreground, Arial 10pt bold | Not directly referenced in form items | N/A |
| VA_TRNI_DT | VisualAttribute | Transaction date field style - white background, black foreground, Courier bold | Not directly referenced in form items | N/A |
| VA_LOV | VisualAttribute | LOV field style - gray background, dark-blue foreground, Arial 9pt | 3 items in form | Fields associated with LOV popups |
| VA_DISP | VisualAttribute | Display/read-only field style - r25g75b75 background, black foreground, Arial 8pt bold | Not directly referenced in form items | N/A |
| PC_DESC | PropertyClass | Display item class - left-justified, 250-wide, white background, blue foreground, Arial 9pt, 110-character maximum | Not directly applied via SubclassObjectGroup in form | N/A |
| PC_SC_DATE | PropertyClass | Date display item class - gray background, Arial 8pt bold, DD-MM-YY format hint | Not directly applied via SubclassObjectGroup in form | N/A |
| PC_TITLE | PropertyClass | Title text item class - center-justified, gray background, Arial 10pt bold, uppercase | Not directly applied via SubclassObjectGroup in form | N/A |
| PC_FORMAT | PropertyClass | Formatted text item class - center-justified, 60-wide, white background, 12-character maximum, uppercase | Not directly applied via SubclassObjectGroup in form | N/A |
| PC_MR_BLK | PropertyClass | Master-record block class - navigation style: Change Record, vertical orientation | Not directly applied via SubclassObjectGroup in form | N/A |
| PC_DISP | PropertyClass | Display-only text item class - disabled, gray background, Arial 9pt, keyboard not navigable | Not directly applied via SubclassObjectGroup in form | N/A |
| PC_LOV | PropertyClass | LOV text item class - LOV position (80,96), 250-wide, gray background, dark-blue foreground | Not directly applied via SubclassObjectGroup in form | N/A |
| PC_FORM | PropertyClass | Form-level standard class - includes standard FT trigger set (ON-ERROR, ON-MESSAGE, KEY-EXIT, KEY-LISTVAL, KEY-COMMIT, KEY-CLRFRM), console window WN_MAIN, menu module menu.mmx | Not directly applied via SubclassObjectGroup in form | N/A |
| PC_DISP_DATE | PropertyClass | Date display item class - disabled, gray background, DD-MM-RRRR format mask, not keyboard navigable | Not directly applied via SubclassObjectGroup in form | N/A |
| PC_DISP_NUM | PropertyClass | Numeric display item class - right-justified, disabled, gray background, not keyboard navigable | Not directly applied via SubclassObjectGroup in form | N/A |
| PC_DATE | PropertyClass | Date text item class - 60-wide, white background, DD-MM-RRRR format mask, date-entry hint | Not directly applied via SubclassObjectGroup in form | N/A |
| PC_DTTIME | PropertyClass | Date-time text item class - 80-wide, DD-MM-RRRR HH24:MI format, date-time hint, VA_TEXT | Not directly applied via SubclassObjectGroup in form | N/A |
| PC_CB | PropertyClass | Check-box item class | Not directly applied via SubclassObjectGroup in form | N/A |
| PC_ALERT | PropertyClass | Alert property class | Not directly applied via SubclassObjectGroup in form | N/A |
| PC_MDATE | PropertyClass | Mandatory date text item class - date-entry hint | Not directly applied via SubclassObjectGroup in form | N/A |
| PC_RB | PropertyClass | Radio-button item class | Not directly applied via SubclassObjectGroup in form | N/A |
| PC_WIND | PropertyClass | Window property class | Not directly applied via SubclassObjectGroup in form | N/A |
| PC_CANV | PropertyClass | Canvas property class | Not directly applied via SubclassObjectGroup in form | N/A |
| PC_BUTN | PropertyClass | Push-button item class - gray background, Arial 10pt bold | Not directly applied via SubclassObjectGroup in form | N/A |
| PC_TEXT | PropertyClass | Standard text item class | Not directly applied via SubclassObjectGroup in form | N/A |
| PC_MTEXT | PropertyClass | Mandatory text item class | Not directly applied via SubclassObjectGroup in form | N/A |
| PC_UTEXT | PropertyClass | Uppercase text item class | Not directly applied via SubclassObjectGroup in form | N/A |
| PC_MUTEXT | PropertyClass | Mandatory uppercase text item class | Not directly applied via SubclassObjectGroup in form | N/A |
| PC_NUM | PropertyClass | Numeric text item class - Arial 9pt | Not directly applied via SubclassObjectGroup in form | N/A |
| PC_MNUM | PropertyClass | Mandatory numeric text item class | Not directly applied via SubclassObjectGroup in form | N/A |
| PC_ICONIC_BUTN | PropertyClass | Iconic push-button class - push button item type, gray background | Not directly applied via SubclassObjectGroup in form | N/A |
| PC_SCROLL | PropertyClass | Scroll-bar or scrollable class | Not directly applied via SubclassObjectGroup in form | N/A |
| OG_GROUP | ObjectGroup | Standard form object group defined in the form module; referenced by name but contains no child objects evidenced in the form XML | referenced in form | N/A |

---

## 10. Record Groups

*Lists all record groups, their LOV bindings, query logic, dynamic bindings, business purpose, and form usage.*

| Record Group | Type | Used By LOV | Display Column | Return Column | Dynamic Bindings | Purpose | Where Used |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| RV_CONSG | Query | LV_CONSG | CONSG_CD | DEALER_CATEGORY | No | Lists consignee codes and dealer categories available to the logged-in user for filtering the parts search | LV_CONSG -> HDR_BLK.CONSG_CD |
| RV_DEALER | Query | LV_DEALER | DEALER_NAME | PARENT_GROUP | No | Lists dealer names for the selected consignee code, enabling the user to identify the specific dealer outlet | LV_DEALER -> HDR_BLK.DEALER_NAME |
| RV_LOC | Query | LV_LOC | LOC_DESC | LOC_CD | No | Lists location codes for the selected dealer and consignee, including an 'ALL' option for viewing all locations | LV_LOC -> HDR_BLK.LOC_CD |

**Total Record Groups:** 3

## 11. Referenced Database Objects

*Database tables, views, and objects accessed by the form.*

| Block | Base Table | Primary Key Item | Database Item |
| :--- | :--- | :--- | :--- |
| HDR_BLK | - | - | No |
| DTL_BLK | - | - | No |
| CB_ERR | - | - | No |
| PB_BLK | - | - | No |

| Object | Schema | Used In | Description |
| :--- | :--- | :--- | :--- |
| `AM_DEALER_LOC` | - | RG_RV_CONSG, RG_RV_DEALER, RG_RV_LOC, Trigger WHEN-BUTTON-PRESSED | Dealer location master - maps dealers to consignees, locations, parent groups, and principals |
| `AM_USER_DEALER_MASTER` | - | Trigger KEY-CLRFRM, Trigger WHEN-NEW-FORM-INSTANCE | User dealer master - maps logged-in users to their authorized parent dealer group |
| `DUAL` | - | POPULATE_DETAILS, RG_RV_LOC, Trigger WHEN-BUTTON-PRESSED | Oracle system utility table - used for single-row SQL operations and dynamic query construction |
| `MULDMS.AM_DEALER_LOC` | - | Trigger WHEN-BUTTON-PRESSED | Dealer location master (schema-qualified) - accessed directly during parts search with schema prefix for cross-schema query |
| `PM_CATEGORY` | - | Trigger WHEN-NEW-FORM-INSTANCE | Parts category master - provides category descriptions and codes for populating the category filter list |
| `PM_PART` | - | Trigger FT_SAVE | Parts master - provides root part number lookup used when recording dead stock flagging entries |
| `PM_PART_DEAD_STOCK` | - | Trigger FT_SAVE, Trigger WHEN-BUTTON-PRESSED | Dead stock register - stores part-level dead stock flag records including dealer, location, remarks, and discount |
| `PM_PART_VAR` | - | Trigger FT_SAVE | Part variant master - updated with the dead stock flag (DEAD_STOCK_YN) when parts are flagged or unflagged |

**Total Referenced Objects:** 8

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure/Package Index

| Requirement ID | Procedure/Package | Purpose |
| -------------- | ----------------- | ------- |
| BR-001 | GENERAL.L_POP_LIST_ITEM | Builds and loads the Category filter drop-down from the product-category master at form open |
| BR-001, BR-002, BR-003, BR-007, BR-011, BR-012, BR-015, BR-016 | GENERAL.DISP_TEXT | Displays error, warning, and information messages to the user in a standard alert box |
| BR-013, BR-014, BR-021 | GENERAL.ASK_CONFIRM | Displays a yes/no confirmation alert and returns the user's choice |
| BR-012 | GENERAL.CHECK_NULL | Validates that a required field is not blank before saving |
| BR-012 | GENERAL.CHECK_FORM_FAILURE | Checks whether the most recent form operation succeeded and displays the error text if it did not |
| BR-016, BR-017 | VIEW_EXCEL_REP | Generates a CSV export file from a supplied query and serves it to the user's browser |
| BR-018 | WIN_API_DIALOG.SELECT_PRINTER | Opens the Windows printer selection dialog so the user can choose a printer |
| BR-020 | WIN_API_SHELL.WINEXEC | Executes a Windows shell command (used to launch the calculator) |
| BR-001, BR-014 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Sets the client-info attribute of the database session for monitoring purposes |
| BR-001, BR-014 | DBMS_APPLICATION_INFO.SET_MODULE | Sets the module-name attribute of the database session for monitoring purposes |
| - | GENERAL.RAISE_ERROR | Translates raw Oracle or Forms error codes into business-friendly error text and surfaces them to the user via the ON-ERROR trigger |

---

### 12.2 Procedure and Package Catalogue

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| GENERAL.DISP_TEXT | Package procedure (DPL library - GENERAL package) | Trigger: FT_SAVE, Trigger: KEY-CLRFRM, Trigger: ON-ERROR, Trigger: ON-MESSAGE, Trigger: WHEN-BUTTON-PRESSED (HDR_BLK.PB_PART_SEARCH, HDR_BLK.PB_RM, HDR_BLK.PB_SEARCH), Trigger: WHEN-NEW-FORM-INSTANCE, Trigger: WHEN-VALIDATE-ITEM (HDR_BLK.CONSG_CD, HDR_BLK.DEALER_NAME, HDR_BLK.LOC_CD), Trigger: WHEN_LIST_CHANGED (HDR_BLK.SLAB) | Displays a message alert dialog; sets the alert title and message text dynamically. Uses AL_ERRINFO when `title_string` is `'ERROR'` and AL_NOTE for all other titles. Called from validation triggers, business logic triggers, and error handlers throughout the form to communicate status, errors, and informational messages to the user |
| GENERAL.ASK_CONFIRM | Package function (DPL library - GENERAL package) | Trigger: FT_CANCEL, Trigger: FT_DEL, Trigger: WHEN-BUTTON-PRESSED (PB_BLK.PB_EXIT) | Displays a Yes/No confirmation dialog using the AL_CONFIRM alert with the supplied message. Returns 1 if the user clicks Yes, 0 if the user clicks No. Used to confirm destructive or irreversible actions such as cancelling unsaved data or exiting the form |
| GENERAL.CHECK_NULL | Package procedure (DPL library - GENERAL package) | Trigger: FT_SAVE, Trigger: WHEN-CHECKBOX-CHANGED (DTL_BLK.DEAD_STOCK_YN) | Validates that the supplied field value is not null; if null, constructs the message `'Enter a valid {column_title}'`, displays it as an error via DISP_TEXT, and raises FORM_TRIGGER_FAILURE. In FT_SAVE, validates that PART_DISCOUNT and IND_PART_DISCOUNT are provided when the dead stock flag is active |
| GENERAL.CHECK_FORM_FAILURE | Package procedure (DPL library - GENERAL package) | Trigger: KEY-COMMIT | Checks whether the last Oracle Forms built-in operation succeeded. If the operation failed and the error type is Oracle (ORA), displays the Oracle error message via DISP_TEXT; if the error is a Forms error (FRM), displays the error text. Raises FORM_TRIGGER_FAILURE in both cases to ensure transaction integrity |
| GENERAL.L_POP_LIST_ITEM | Package procedure (DPL library - GENERAL package) | Trigger: WHEN-NEW-FORM-INSTANCE | Creates or replaces a named record group from a dynamic SQL query, then populates it. Used on form initialisation to load the part category dropdown (CATG_CD) from a SELECT against PM_CATEGORY filtered by the current principal code. Deletes any pre-existing record group of the same name before recreating it |
| GENERAL.RAISE_ERROR | Package procedure (DPL library - GENERAL package) | Trigger: ON-ERROR | Looks up a standardised error message from the application message repository using the supplied message code and raises it as a user-visible error. Called from the ON-ERROR trigger to translate raw Oracle or Forms error codes into business-friendly error text before surfacing them to the user |
| VIEW_EXCEL_REP | Form-level program unit (PT_DEAD_STOCK_FLAG form) | Trigger: WHEN-BUTTON-PRESSED (PB_BLK.PB_EXCEL, HDR_BLK.PUSH_BUTTON103) | Accepts a query string and column name, runs the query into an in-memory record group, writes the results as a CSV file to the application server, reads the server output path from `/reports/DMS/excelpath.txt`, and opens the file in the user's browser via WEB.SHOW_DOCUMENT; truncates to 65,535 rows if exceeded |
| WIN_API_DIALOG.SELECT_PRINTER | Package procedure (D2kwutil library - WIN_API_DIALOG package) | Trigger: WHEN-BUTTON-PRESSED (PB_BLK.PB_PSETUP) | Invokes the Windows native printer-selection dialog, returning the chosen printer name and port to the caller via OUT parameters. When RaiseExceptions is FALSE (the default), errors are suppressed rather than propagated to the calling trigger |
| WIN_API_SHELL.WINEXEC | Package procedure (D2kwutil library - WIN_API_SHELL package) | Trigger: WHEN-BUTTON-PRESSED (PB_BLK.PB_CALC) | Launches an external Windows executable or shell command specified by Command, using the WindowStyle constant to control the initial window state (defaulting to SW_SHOWNORMAL). Used to open the Windows calculator utility as a convenience tool for the user. When RaiseExceptions is FALSE (the default), execution failures are silently suppressed |
| WEB.SHOW_DOCUMENT | Package procedure (WEB - Oracle Forms built-in web package) | VIEW_EXCEL_REP | Opens a URL in the user's browser to serve the generated CSV file produced by VIEW_EXCEL_REP |
| DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Oracle built-in package procedure | Trigger: PRE-FORM, Trigger: KEY-EXIT | Sets the client-info attribute of the current database session for monitoring and tracing purposes |
| DBMS_APPLICATION_INFO.SET_MODULE | Oracle built-in package procedure | Trigger: PRE-FORM, Trigger: KEY-EXIT | Sets the module-name attribute of the current database session for monitoring and tracing purposes |
| POPULATE_DETAILS | Form-level program unit (PT_DEAD_STOCK_FLAG form) | Not called from any active trigger in the form | Performs a minimal `SELECT 1 FROM DUAL`; produces no visible output and serves no active business function in the current form implementation |

## 13. Package Procedure Specifications

*NO PCK files found - no `*.pck` source files were discovered in the form sources input directory. Package specifications cannot be generated without uploaded PCK sources.*

## 14. Database Package Catalogue

*NO PCK files found - no ``*.pck`` source files were discovered in ``/app/section-rewrite-pipeline/workspaces/caf80f84-010f-4c8f-b22e-2ea85bd5be94/inputs/form_sources``. The database package catalogue cannot be generated without uploaded PCK sources.*

## 15. PLD Procedure Call Sites

*Maps each program-library routine to its call sites within triggers and program units. Behaviour descriptions are derived from the uploaded ``.pld`` sources.*

### DPL.pld (`general`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ASK_CONFIRM | Function | Function(confirm_msg VARCHAR2) RETURN NUMBER | Trigger: FT_CANCEL in Form, Trigger: FT_DEL in Form, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_EXIT | Displays a Yes/No confirmation dialog using the AL_CONFIRM alert with the supplied message. Returns 1 if the user clicks Yes, 0 if the user clicks No. Used to confirm destructive or irreversible actions such as cancelling unsaved data or exiting the form. |
| CHECK_FORM_FAILURE | Procedure | Procedure() | Trigger: KEY-COMMIT in Form | Checks whether the last Oracle Forms built-in operation succeeded. If the operation failed and the error type is Oracle (ORA), displays the Oracle error message via DISP_TEXT. If the error is a Forms error (FRM), displays the error text. Raises FORM_TRIGGER_FAILURE in both cases. Invoked after enter and commit_form in KEY-COMMIT to ensure transaction integrity. |
| CHECK_NULL | Procedure | Procedure(p_value IN VARCHAR2, column_title IN VARCHAR2) | Trigger: FT_SAVE in Form, Trigger: WHEN-CHECKBOX-CHANGED in DTL_BLK.DEAD_STOCK_YN | Validates that the supplied field value is not null. If null, constructs the message 'Enter a valid {column_title}', displays it as an error via DISP_TEXT, and raises FORM_TRIGGER_FAILURE. In FT_SAVE, validates that PART_DISCOUNT and IND_PART_DISCOUNT are provided when the dead stock flag is active. |
| DISP_TEXT | Procedure | Procedure(text_string VARCHAR2, title_string VARCHAR2) | Trigger: FT_SAVE in Form, Trigger: KEY-CLRFRM in Form, Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: WHEN-BUTTON-PRESSED in HDR_BLK.PB_PART_SEARCH, Trigger: WHEN-BUTTON-PRESSED in HDR_BLK.PB_RM, Trigger: WHEN-BUTTON-PRESSED in HDR_BLK.PB_SEARCH, Trigger: WHEN-NEW-FORM-INSTANCE in Form, Trigger: WHEN-VALIDATE-ITEM in HDR_BLK.CONSG_CD, Trigger: WHEN-VALIDATE-ITEM in HDR_BLK.DEALER_NAME, Trigger: WHEN-VALIDATE-ITEM in HDR_BLK.LOC_CD, Trigger: WHEN_LIST_CHANGED in HDR_BLK.SLAB | Displays a message alert dialog. Sets the alert title and message text dynamically. Uses AL_ERRINFO when title_string is 'ERROR', and AL_NOTE for all other titles. Called from validation triggers, business logic triggers, and error handlers throughout the form to communicate status, errors, and informational messages to the user. |
| l_pop_list_item | Procedure | Procedure(p_rg_name VARCHAR2,p_select VARCHAR2) | Trigger: WHEN-NEW-FORM-INSTANCE in Form | Creates or replaces a named record group from a dynamic SQL query, then populates it. Used on form initialization to load the part category dropdown (CATG_CD) from a SELECT against PM_CATEGORY filtered by the current principal code. Deletes any pre-existing record group of the same name before recreating it. |
| RAISE_ERROR | Procedure | Procedure(mesg_code IN VARCHAR2) | Trigger: ON-ERROR in Form | Looks up a standardised error message from the application message repository using the supplied message code and raises it as a user-visible error. Called from the ON-ERROR trigger to translate raw Oracle or Forms error codes into business-friendly error text before surfacing them to the user. |

**Total Active Routines:** 6 of 24 in DPL.pld source

---

### D2kwutil.pld (`WIN_API_DIALOG`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| Select_Printer | Procedure | Procedure(PrinterName OUT VARCHAR2, Port OUT VARCHAR2, RaiseExceptions IN BOOLEAN DEFAULT FALSE) | Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_PSETUP | Invokes the Windows native printer-selection dialog, returning the chosen printer name and port to the caller via OUT parameters. Called from the PB_PSETUP button to allow the user to select and configure a printer before initiating a print operation. When RaiseExceptions is FALSE (the default), errors are suppressed rather than propagated to the calling trigger. |

**Total Active Routines:** 1 of 12 in D2kwutil.pld source

---

### D2kwutil.pld (`WIN_API_Shell`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| WinExec | Procedure | Procedure(Command IN VARCHAR2, WindowStyle IN PLS_INTEGER DEFAULT WIN_API.SW_SHOWNORMAL, RaiseExceptions IN BOOLEAN DEFAULT FALSE) | Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_CALC | Launches an external Windows executable or shell command specified by Command, using the WindowStyle constant to control the initial window state (defaulting to SW_SHOWNORMAL). Called from the PB_CALC button to open the Windows calculator utility as a convenience tool for the user. When RaiseExceptions is FALSE (the default), execution failures are silently suppressed rather than raised to the calling trigger. |

**Total Active Routines:** 1 of 16 in D2kwutil.pld source

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| ID | Service Name | Database Object | Input Parameters | Output | Business Function | API Endpoint Suggestion |
| -- | ------------ | --------------- | ---------------- | ------ | ----------------- | ----------------------- |
| MS-001 | Dead Stock Candidate Search | PM_PART_DEAD_STOCK, PM_PART, PM_PART_VAR, PM_STOCK, AM_DEALER_LOC | parent_group, dealer_map_cd, loc_cd, consg_cd, catg_cd, slab (period factor), stock_filter | Array of parts: part_num, part_desc, current_stock, purchase_price, stock_value, last_trans_date, remarks, part_discount, dead_stock_yn; total_records; total_value; dead_stock_percentage | Retrieves slow-moving parts that have not been transacted for longer than the specified period threshold, applying dealer/location/category filters; returns existing dead-stock remarks and discounts for pre-population; calculates the percentage of flagged parts | POST /api/parts/dead-stock/search |
| MS-002 | Save Dead Stock Flag Decisions | PM_PART_DEAD_STOCK, PM_PART, PM_PART_VAR | parent_group, dealer_map_cd, loc_cd; array of {part_num, dead_stock_yn, ind_remarks, ind_part_discount} | Success/failure status per row; overall save result | Persists the user's dead-stock flag decisions: upserts active dead-stock records for flagged parts, soft-deletes records for unflagged parts, and updates the dead-stock indicator on each part variant record | POST /api/parts/dead-stock/save |
| MS-003 | Dead Stock Export (Location-Specific) | PM_PART_DEAD_STOCK, PM_PART, PM_PART_VAR, PM_STOCK, AM_DEALER_LOC | parent_group, dealer_map_cd, loc_cd, consg_cd, catg_cd, slab, stock_filter | CSV file stream (columns: part_num, part_desc, parent, map_code, location, current_stock, purchase_price, value, last_transacted_date, remarks, flag_date, part_discount) | Generates a downloadable CSV export of dead-stock candidate data for a specific dealer and location combination | GET /api/parts/dead-stock/export/location |
| MS-004 | Dead Stock Export (Consolidated by Consignee) | PM_PART_DEAD_STOCK, PM_PART, PM_PART_VAR, PM_STOCK, AM_DEALER_LOC | parent_group, dealer_map_cd, loc_cd, consg_cd, catg_cd, slab, stock_filter | CSV file stream (columns: consg_cd, loc_cd, part_num, part_desc, current_stock, purchase_price, value, last_transacted_date, remarks, flag_date, part_discount) | Generates a downloadable CSV export of dead-stock candidate data consolidated across all locations within a consignee group | GET /api/parts/dead-stock/export/consolidated |
| MS-005 | Category List | PM_CATEGORY | principal_map_cd | Array of {catg_cd, catg_desc} | Retrieves the available product categories for the current principal organisation to populate the category filter drop-down | GET /api/parts/categories |
| MS-006 | Consignee List | AM_DEALER_LOC, AM_USER_REGION, AM_USER_DEALER_MASTER | user_id, principal_map_cd, parent_group | Array of {consg_cd, dealer_category, dealer_name} | Retrieves the consignees that the logged-in user is authorised to access, based on their region or dealer-master assignments | GET /api/dealers/consignees |
| MS-007 | Dealer List | AM_DEALER_LOC | consg_cd, parent_group, principal_map_cd | Array of {dealer_name, parent_group, dealer_map_cd} | Retrieves the dealers within a selected consignee group | GET /api/dealers |
| MS-008 | Location List | AM_DEALER_LOC | consg_cd, dealer_map_cd, parent_group, principal_map_cd | Array of {loc_desc, loc_cd} including the "ALL" option | Retrieves the locations for a selected consignee and dealer combination | GET /api/dealers/locations |
| MS-009 | User Group Resolution | AM_USER_DEALER_MASTER | user_id | {parent_group} | Resolves the logged-in user's group membership (parent group code) for use in conditional access control (e.g. enabling or restricting the Save button) | GET /api/users/{user_id}/group |

**Total Microservices Identified: 9**

---

## 17. Workflows

| ID | Workflow Name | Trigger Event | Steps | Decision Points | End State |
| -- | ------------- | ------------- | ----- | --------------- | --------- |
| WF-001 | Form Initialisation | PRE-FORM fires before the form becomes visible, then WHEN-NEW-FORM-INSTANCE fires as the form opens | 1. Register database session with application module identifier. 2. Maximise both application windows. 3. Populate Category filter drop-down from category master. 4. Resolve user's group membership. 5. Apply mandatory visual style to Discount on DRT fields. | If user record not found in user-dealer master: display error and continue (form still opens). If database error during user lookup: display error and continue. | Form is open, Category list is populated, Discount fields are highlighted as mandatory, user group context is available |
| WF-002 | Dead Stock Candidate Search | WHEN-BUTTON-PRESSED on Search button (PB_SEARCH) | 1. Clear the detail results grid. 2. Execute the appropriate search query (specific location or ALL-location variant). 3. For each result row: populate part number, description, stock, price, pre-fill existing remarks and discount, pre-set Dead Stock flag to Yes, accumulate total value. 4. Set total record count and total value in header. 5. Pre-check the ALL checkbox. 6. Calculate and display the percentage of slow-moving parts already formally flagged. | Location = specific vs. Location = ALL: determines which query cursor (c1 or c2) is used. If the existing dead-stock record lookup fails for a row: silently default remarks and discount to null. | Results grid is populated with slow-moving candidates; total count, value, and dead-stock percentage are displayed |
| WF-003 | Save Dead Stock Flags | WHEN-BUTTON-PRESSED on Save button (PB_SAVE) -> FT_SAVE -> KEY-COMMIT | 1. Validate Location is not ALL. 2. If ALL checkbox checked: validate header discount not blank. 3. Display confirmation message. 4. If ALL checkbox checked: validate header discount range 15-100. 5. Loop through all result rows: retrieve existing record count and root part number. 6. Per row (Dead Stock = Yes): validate individual discount not blank; upsert active dead-stock record; validate individual discount range. 7. Per row (Dead Stock = No): soft-delete active dead-stock record if one exists. 8. Per row (both paths): update part variant Dead Stock indicator. 9. Invoke commit: run form validation, commit all changes, check for failure, clear form. | Location = ALL -> block save; ALL checkbox checked -> additional discount validations; Dead Stock = Yes vs. No -> different write paths; existing record present vs. absent -> delete-then-insert vs. insert-only for Yes path; existing record present vs. absent for No path -> soft-delete vs. no action. | All flagging decisions are committed to the database; form is cleared |
| WF-004 | Cancel Unsaved Changes | WHEN-BUTTON-PRESSED on Cancel button (PB_CANCEL) -> FT_CANCEL | 1. Check Cancel button is enabled. 2. Reset internal parameters. 3. Check form change status. 4. If changed: show confirmation; if confirmed, clear form. 5. If not changed: clear form directly. | Cancel button disabled -> silent no-op; form has unsaved changes -> confirmation required; user declines confirmation -> form stays open. | Form is cleared (all data removed from screen) or remains open if the user declines |
| WF-005 | Exit Form | KEY-EXIT (keyboard) or WHEN-BUTTON-PRESSED on Exit button (PB_EXIT) | Key path: 1. Clear database session tracking attributes. 2. Close form without validation. Button path: 1. If form is in query-entry mode, exit immediately. 2. If form has unsaved changes, show confirmation. 3. If confirmed or no changes, close form. | Key path exits unconditionally; button path: query-entry mode -> immediate exit; unsaved changes -> confirmation required; user declines -> form stays open. | Form is closed; database session attributes are cleared (key path) |
| WF-006 | Bulk Flag / Unflag All Parts | WHEN-CHECKBOX-CHANGED on ALL checkbox (CB_ALL) | 1. Display confirmation prompt. 2. If confirmed: set Dead Stock flag on every result row to match the ALL checkbox state. 3. Adjust Discount on DRT visual style and editability on all rows (mandatory when Yes, default when No). 4. Set per-row instance visual style for Discount on DRT. 5. Return focus to first record. | User confirms bulk change -> proceed; user declines -> no change. ALL = Yes -> mandatory style applied; ALL = No -> default style and discount cleared on individual rows. | All result rows have their Dead Stock flag and Discount on DRT style updated to match the selected ALL state |
| WF-007 | Individual Dead Stock Flag Toggle | WHEN-CHECKBOX-CHANGED on Dead Stock Y/N per row (DTL_BLK.DEAD_STOCK_YN) | 1. Check new flag value. 2. If Yes: apply mandatory style to individual Discount on DRT, enable insert/update. If No: apply default style, block insert/update, clear discount value. 3. If Yes and ALL checkbox is unchecked: validate individual discount not blank. | Dead Stock = Yes -> mandatory style + editability enabled + null check; Dead Stock = No -> default style + editability blocked + discount cleared. ALL = Yes -> null check skipped in this trigger. | Individual row's Discount on DRT field behaviour matches the current Dead Stock flag state |
| WF-008 | Excel Report Export | WHEN-BUTTON-PRESSED on Excel Report or Excel Report (CONS) button | 1. Recalculate dead-stock percentage (Excel Report only). 2. Generate unique filename from user ID and current date-time. 3. Build CSV query string. 4. Call VIEW_EXCEL_REP with query and filename. 5. VIEW_EXCEL_REP: generate record group, truncate if >65,535 rows, read server path from config, write CSV to server, open in browser. | Filename path contains spaces -> redirect to C drive root. Row count > 65,535 -> truncate and warn. File write or browser-open error -> display error message and abort. | CSV file is written to the server and opened in the user's browser for download |

**Total Workflows Identified: 8**

---

## 18. PLD-Backed Logic

*Maps shared library routines to their business function and suggested API contracts.*

### DPL.pld (`general`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | ASK_CONFIRM | Business Logic | Trigger: FT_CANCEL in Form, Trigger: FT_DEL in Form, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_EXIT | /api/v1/pld/ask_confirm | When a user initiates a potentially destructive action, then a Yes/No confirmation dialog is displayed before proceeding |
| PLD-002 | CHECK_FORM_FAILURE | Validation | Trigger: KEY-COMMIT in Form | /api/v1/pld/check_form_failure | When the last Oracle Forms operation fails, then an error message is displayed and form trigger failure is raised to halt execution |
| PLD-003 | CHECK_NULL | Validation | Trigger: FT_SAVE in Form, Trigger: WHEN-CHECKBOX-CHANGED in DTL_BLK.DEAD_STOCK_YN | /api/v1/pld/check_null | When a required field value is null, then an error message is displayed and the save operation is blocked |
| PLD-004 | DISP_TEXT | Business Logic | Trigger: FT_SAVE in Form, Trigger: KEY-CLRFRM in Form, Trigger: ON-MESSAGE in Form, Trigger: WHEN-BUTTON-PRESSED in HDR_BLK.PB_PART_SEARCH, Trigger: WHEN-BUTTON-PRESSED in HDR_BLK.PB_RM, Trigger: WHEN-BUTTON-PRESSED in HDR_BLK.PB_SEARCH, Trigger: WHEN-NEW-FORM-INSTANCE in Form, Trigger: WHEN-VALIDATE-ITEM in HDR_BLK.CONSG_CD, Trigger: WHEN-VALIDATE-ITEM in HDR_BLK.DEALER_NAME, Trigger: WHEN-VALIDATE-ITEM in HDR_BLK.LOC_CD, Trigger: WHEN_LIST_CHANGED in HDR_BLK.SLAB | /api/v1/pld/disp_text | When a message or error needs to be displayed, then an alert dialog is shown with the supplied title and text to the user |
| PLD-005 | l_pop_list_item | Business Logic | Trigger: WHEN-NEW-FORM-INSTANCE in Form | /api/v1/pld/l_pop_list_item | When the form opens, then the category dropdown is populated from a dynamic SQL query against the parts category master |


---

### D2kwutil.pld (`Win_API`)

*No routines from ``D2kwutil.pld`` are referenced in ``pt_dead_stock_flag_fmb.xml``.*

---

---

## 19. PCK-Backed Logic

*NO PCK files found - no ``*.pck`` source files were discovered in ``/app/workspace/pt_dead_stock_flag-70053ddaf66a/in``. PCK-backed logic cannot be generated without uploaded PCK sources.*

---

## 20. System Interfaces

### 20.1 Database Integrations

| Interface Name | Type | Purpose | Data Flow | Error Handling |
| -------------- | ---- | ------- | --------- | -------------- |
| Dead Stock Register (PM_PART_DEAD_STOCK) | Oracle Database Table - SELECT / INSERT / DELETE | Stores and retrieves dead-stock flagging decisions per group/dealer/location/part; records include creation metadata, remarks, discount, deleted flag | Form reads existing records during search to pre-populate remarks and discount; form writes new records (active or soft-delete) on save | Database errors during DELETE or INSERT display "ERROR WHILE DELETING FROM DEAD_STOCK" or "ERROR WHILE INSERTING INTO DEAD_STOCK"; trigger is aborted on failure |
| Part Variant (PM_PART_VAR) | Oracle Database Table - UPDATE | Stores the current dead-stock indicator per part/location; updated on every save to reflect the current flag value | Form writes the Dead Stock Y/N value to the matching part variant row on save | Database errors during UPDATE display "ERROR WHILE UPDATING PM_PART_VAR"; trigger is aborted on failure |
| Part Master (PM_PART) | Oracle Database Table - SELECT | Provides root part numbers and part descriptions; root part number is stored in the dead-stock register record | Form reads the root part number per part during the save loop; also reads part descriptions during the search | Any database error during part lookup displays "ERROR WHILE FETCHING PART DETAILS"; trigger is aborted on failure |
| Stock Master (PM_STOCK) | Oracle Database Table - SELECT | Provides current stock quantities and last-transaction dates for slow-moving candidate identification | Form reads stock data during the candidate search to calculate threshold compliance and stock values | Errors propagate as unhandled WHEN OTHERS in the search query; no part is loaded if stock data is unavailable |
| Dealer-Location Master (AM_DEALER_LOC) | Oracle Database Table - SELECT | Provides dealer, location, and consignee mapping; used as a join table in the candidate search query | Form reads this table as part of the multi-table join in both the search and export queries | Errors propagate as unhandled WHEN OTHERS in the search query |
| User-Dealer Assignment Master (AM_USER_DEALER_MASTER) | Oracle Database Table - SELECT | Maps logged-in users to their parent group; used to determine the user's group context at form open and on clear | Form reads this table in WHEN-NEW-FORM-INSTANCE and KEY-CLRFRM to resolve the user's parent group | NO_DATA_FOUND displays "user_id not found"; WHEN OTHERS displays "error while fetching user details"; form continues in both cases |
| Category Master (PM_CATEGORY) | Oracle Database Table - SELECT | Provides product category descriptions and codes for the Category filter drop-down | Form reads this table via GENERAL.L_POP_LIST_ITEM at form open to populate the Category list | Errors in list population are not explicitly trapped; the Category list may be empty if the query fails |
| Oracle Application Info (DBMS_APPLICATION_INFO) | Oracle Built-in Package | Registers and clears the form's session identity in the database for monitoring | PRE-FORM writes the module identifier; KEY-EXIT clears it | No error handling - built-in calls are unconditional |

### 20.2 External System Integrations

The form has no external system integrations other than the file-based interface described in Section 20.3. There are no CALL_FORM, OPEN_FORM, or third-party web-service calls evidenced in the form.

### 20.3 Report Integrations

No Oracle Reports report calls are evidenced in the `reference_data.reports` slice for this form (reports count = 0). The form generates its own CSV exports directly via the VIEW_EXCEL_REP program unit (documented in BR-016 and BR-017) by writing to the application server file system and serving the file through the web server URL path read from the external configuration file `/reports/DMS/excelpath.txt`. This is a direct file-generation integration, not an Oracle Reports integration, and is fully described in Section 20.1 and Section 12.2.

| Report Name | Report Server | Parameters | Output Format | Trigger |
| ----------- | ------------- | ---------- | ------------- | ------- |
| (none - no Oracle Reports calls evidenced in this form) | N/A | N/A | N/A | N/A |

---

### 20.3.1 Parameters Passed to the Report

This form does not pass parameters to an Oracle Report. No report parameters were identified in the form sources.

## 21. Procedure and Function Business Rule Catalogue

End-to-end business requirement specification for every stored procedure and function referenced by the PT_DEAD_STOCK_FLAG form.

### 21.1 Catalogue Index

9 procedures/functions - each SP ID links to its detailed specification in Section 21.2.

| SP Index | Routine Name |
| :--- | :--- |
| [SP-001](#SP-001--VIEW_EXCEL_REP) | VIEW_EXCEL_REP |
| [SP-002](#SP-002--GENERAL.ASK_CONFIRM) | GENERAL.ASK_CONFIRM |
| [SP-003](#SP-003--GENERAL.CHECK_FORM_FAILURE) | GENERAL.CHECK_FORM_FAILURE |
| [SP-004](#SP-004--GENERAL.CHECK_NULL) | GENERAL.CHECK_NULL |
| [SP-005](#SP-005--GENERAL.DISP_TEXT) | GENERAL.DISP_TEXT |
| [SP-006](#SP-006--GENERAL.L_POP_LIST_ITEM) | GENERAL.L_POP_LIST_ITEM |
| [SP-007](#SP-007--GENERAL.RAISE_ERROR) | GENERAL.RAISE_ERROR |
| [SP-008](#SP-008--WIN_API_DIALOG.SELECT_PRINTER) | WIN_API_DIALOG.SELECT_PRINTER |
| [SP-009](#SP-009--WIN_API_SHELL.WINEXEC) | WIN_API_SHELL.WINEXEC |

---

### 21.2 Detailed Specifications

#### SP-001 - VIEW_EXCEL_REP

**Invoked From:**

- pt_dead_stock_flag_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

PART DETAILS (WN_MAIN / CN_MAIN)

---

**Purpose**

Generates a CSV report file from a dynamic SQL query and streams it to the user's browser as a downloadable Excel-compatible document. The procedure builds a record group from the supplied query, writes the designated column's data rows to a server-side CSV file, and then opens the file via a URL in a new browser window. It is invoked from the Dead Stock Flag screen when the user presses the View Excel Report button.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_file_name | VARCHAR2 | IN |
| p_query | VARCHAR2 | IN |
| p_column_name | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Retrieve the current Oracle Forms global user ID (`:global.userid`) and combine it with the current system date/time (formatted `YYYYMMDDHHMISS`) to construct a unique CSV filename, appending the `.csv` extension.
- Step 2 - If the generated filename is NULL, take no action (null branch); otherwise assign the generated name as the working filename.
- Step 3 - Inspect the filename for embedded spaces in any folder segment. If spaces are detected, redirect the file path to the `C:\` root drive and display a warning message informing the user that the file will be saved there instead.
- Step 4 - Check whether a record group named `DataRecordSet` already exists. If it does, delete it to ensure a clean state before re-creation.
- Step 5 - Create a new record group (`DataRecordSet`) from the dynamic SQL string supplied in `p_query`, then populate it by executing the query.
- Step 6 - Retrieve the total row count of the populated record group.
- Step 7 - If the row count exceeds 65,536 rows, display a truncation warning message and cap the working row count at 65,535 to respect the Excel row limit.
- Step 8 - Construct the server-side file path by prepending `/iashome/ias/reports/printer/` to the filename portion (extracted after the last backslash).
- Step 9 - Read the base URL path from the server-side configuration file `/reports/DMS/excelpath.txt` and append the filename to form the full HTTP URL (`formserverpath`) used for browser delivery.
- Step 10 - Open the server-side CSV file for writing.
- Step 11 - Locate the record group column identified by `p_column_name` within `DataRecordSet`.
- Step 12 - Iterate over all rows (up to the capped row count), retrieving each cell value from the identified column and writing it as a line to the CSV file.
- Step 13 - Close the CSV file after all rows have been written.
- Step 14 - Open the generated file URL in a new browser window/tab using `web.show_document`, delivering the CSV to the user.
- Step 15 - If any exception occurs during processing, display an error message containing the error code and error text, then raise `Form_Trigger_Failure` to halt execution.

---
**Decision Points**

DP-001

Condition:
The generated CSV filename (`vcFile`) is NULL.

TRUE:
No filename assignment is made (null branch; the procedure effectively cannot proceed to write a file).

FALSE:
The generated filename is assigned to the working variable `FILENAME`.

---

DP-002

Condition:
The working `FILENAME` contains a space character in one of its folder path segments (`INSTR(FILENAME,' ') > 0`).

TRUE:
The file path is overridden to `C:\<filename_only>` and a warning message is displayed to the user advising that the file will be stored on the C drive.

FALSE:
The filename is used as-is without path modification.

---

DP-003

Condition:
A record group named `DataRecordSet` already exists (`NOT Id_Null(rg_id)`).

TRUE:
The existing record group is deleted before a new one is created.

FALSE:
No deletion is performed; a new record group is created directly.

---

DP-004

Condition:
The row count returned by the populated record group exceeds 65,536 rows.

TRUE:
A truncation warning message is displayed and the effective row count is capped at 65,535.

FALSE:
All retrieved rows are processed without truncation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The CSV filename must be unique per execution; it is derived by concatenating the logged-in user ID with the current date and time (format `YYYYMMDDHHMISS`) and appending `.csv`, preventing filename collisions across concurrent sessions.
- BR-002 - File paths containing spaces in any folder name are not permitted; when detected, the output path is automatically redirected to the `C:\` root and the user is notified.
- BR-003 - The record group `DataRecordSet` must be re-created fresh for each invocation; any pre-existing group with that name is deleted prior to creation to avoid stale data.
- BR-004 - Excel worksheet row capacity is capped at 65,535 data rows; if the query result set exceeds 65,536 rows, output is truncated and the user is warned before the file is written.
- BR-005 - The server-side base URL for file delivery is not hard-coded; it is read at runtime from `/reports/DMS/excelpath.txt`, allowing environment-specific deployment without code changes.
- BR-006 - The generated CSV file is delivered to the user by opening its HTTP URL in a new browser window (`_blank` target), requiring the file to be accessible via the configured web server path.
- BR-007 - Any unhandled exception must surface the Oracle error code and error text to the user via a message and must terminate the triggering action by raising `Form_Trigger_Failure`.

---
**Implementation Logic**

```plsql
PROCEDURE view_excel_rep(p_file_name VARCHAR2 DEFAULT NULL, p_query VARCHAR2,p_column_name VARCHAR2) IS	
  rg_name 				 		VARCHAR2(40) := 'DataRecordSet'; 
	rg_id 					 		RecordGroup; 
	gc_id 					 		GroupColumn; 
	urlFile1        TEXT_IO.FILE_TYPE;
	the_rowcount 		 		NUMBER;
	po_tot_rec    NUMBER (6);
	--po_part_tab   pk_part_search_new.part_tab_10;
	po_part_tab   pk_part_search_new.part_tab_11;
	po_err_msg    VARCHAR2 (3000);
	po_err_cd     NUMBER (10);
	low           NUMBER (10);
	high          NUMBER (10);
	remainder     NUMBER (10);
	order_by      VARCHAR2 (300);
	vcfile varchar2(150);
	lv_user  varchar2(150);
	l_Old_URL varchar2(500);	
		l_new_URL varchar2(500);	
	v_string varchar2(5000);
	bin_str varchar2(250);
	errcode 				 		NUMBER; 
  FILENAME			   		VARCHAR2(4000);
  MYFILE 					 		TEXT_IO.FILE_TYPE;
  urlFile 					 	TEXT_IO.FILE_TYPE;
  urlPath							VARCHAR2(5000);
	l_alert 				 		NUMBER;
	server_file      		VARCHAR2(2000);
	file_transfer_bool	BOOLEAN;
	formserverpath   		VARCHAR2(2000);
begin
lv_user := name_in(':global.userid');  -- New line added after dpl change
vcFile:= lv_user||To_Char(Sysdate,'YYYYMMDDHHMISS');    -- New line added after dpl change
vcFile := vcFile||'.csv';
if vcFile is null then
	--FILENAME  := Webutil_file.FILE_SAVE_DIALOG;
	null;
else
	filename:=vcFile;
end if;
	If instr(FILENAME,' ') > 0 then
 		FILENAME := 'C:\'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
 		Message('File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default.');
 		message('  ');
	end if;
	
	rg_id := Find_Group( rg_name ); 
	IF NOT Id_Null(rg_id) THEN 
		Delete_Group( rg_id ); 
	END IF; 
	rg_id := Create_Group_From_Query( rg_name, p_query ); 
	errcode := Populate_Group( rg_id ); 
	the_rowcount := Get_Group_Row_Count( rg_id );
	IF the_rowcount > 65536 THEN  
		Message('Maximum number of rows in excel exceeded. It will truncate to 65535 rows.');
		Message('  ');
		CLEAR_MESSAGE;
		the_rowcount := 65535;
	END IF;

	server_file := '/iashome/ias/reports/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	--formserverpath := 'http://10.100.34.230:7778/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	urlFile := Text_Io.Fopen('/reports/DMS/excelpath.txt','R');
	Text_Io.Get_Line(urlFile,urlPath);
	Text_Io.Fclose(urlFile);
	formserverpath := urlPath||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	MYFILE := TEXT_IO.FOPEN(server_file, 'W');
	gc_id := Find_Column( rg_name||'.'||p_column_name); 	
	for total_loop IN 1..the_rowcount
		loop
	  	V_STRING :=  GET_GROUP_CHAR_CELL(gc_id  , total_loop ); 
	  	text_io.put_line(myfile,v_string);
	  	--TEXT_IO.PUTF(MYFILE,V_STRING);  
		end loop;
      text_io.fclose(myfile);
   
	 --	file_transfer_bool := WebUtil_File_Transfer.Url_To_Client(formserverpath,FILENAME);
	/* 	if not file_transfer_bool  then 
	 		message('File Transfer failed');pause;
	 	end if;
	 	WebUtil_Host.HOST('cmd /c '||FILENAME);*/
	 	
	 	web.show_document(formserverpath,'_blank');
	exception
		when others then
		Message('Error  - '||ERROR_CODE|| ERROR_TEXT);
		Raise Form_trigger_failure;
	end;
```

#### SP-002 - GENERAL.ASK_CONFIRM

**Invoked From:**

- pt_dead_stock_flag_fmb.xml [Trigger: FT_CANCEL]
- pt_dead_stock_flag_fmb.xml [Trigger: FT_DEL]
- pt_dead_stock_flag_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

N/A

---

**Purpose**

Presents a configurable confirmation alert dialog to the user and returns a numeric indicator of the button pressed. The function sets the message text of the standard alert 'AL_CONFIRM' to the supplied prompt, displays it, and returns 1 if the user confirms (Button 1) or 0 if the user dismisses or cancels. It is used by the Dead Stock Flag form to gate destructive or significant actions such as cancellation and deletion.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| confirm_msg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the confirmation message text via the `confirm_msg` input parameter.
- Step 2 - Set the message text property of the predefined alert component `AL_CONFIRM` to the supplied `confirm_msg` value using `SET_ALERT_PROPERTY`.
- Step 3 - Display the `AL_CONFIRM` alert dialog to the user via `SHOW_ALERT` and capture the button pressed into the local variable `p_albtn_pressed`.
- Step 4 - Evaluate the captured button value against the constant `ALERT_BUTTON1`.
- Step 5 - If the user pressed Button 1 (confirm), return the numeric value 1 to the caller.
- Step 6 - If the user pressed any other button (cancel/dismiss), return the numeric value 0 to the caller.

---
**Decision Points**

DP-001

Condition:
The value of `p_albtn_pressed` equals the Oracle Forms constant `ALERT_BUTTON1`.

TRUE:
The function returns 1, indicating the user confirmed the action.

FALSE:
The function returns 0, indicating the user did not confirm the action (cancelled or dismissed the alert).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The confirmation alert component used must be the predefined alert named `AL_CONFIRM`; no other alert is permissible within this function.
- BR-002 - The alert message text must be dynamically overridden at runtime with the caller-supplied `confirm_msg` value before the alert is shown, ensuring the dialog is contextually relevant to the invoking trigger.
- BR-003 - A return value of 1 exclusively represents user confirmation (Button 1 pressed); any other button press must result in a return value of 0, with no additional states permitted.
- BR-004 - Callers (FT_CANCEL, FT_DEL, and WHEN-BUTTON-PRESSED triggers on the Dead Stock Flag form) are responsible for interpreting the returned value and taking appropriate action; this function only captures and translates the user's response.

---
**Implementation Logic**

```plsql
FUNCTION ASK_CONFIRM( confirm_msg VARCHAR2)
                                      RETURN  NUMBER IS

    p_alert_name varchar2(10) := 'AL_CONFIRM' ;
    p_albtn_pressed number;
BEGIN
   set_alert_property(p_alert_name,alert_message_text,confirm_msg); 
   p_albtn_pressed := show_alert(p_alert_name);

   IF ( p_albtn_pressed = ALERT_BUTTON1 ) THEN
      return (1);
   ELSE
      return(0);
   END IF;
RETURN NULL; END;
```

#### SP-003 - GENERAL.CHECK_FORM_FAILURE

**Invoked From:**

- pt_dead_stock_flag_fmb.xml [Trigger: KEY-COMMIT]

---

**Screen:**

N/A

---

**Purpose**

Centralises post-action failure handling for Oracle Forms operations. After any form action (typically a KEY-COMMIT trigger), this procedure inspects the Forms runtime success state and, if a failure is detected, retrieves the appropriate error message-either from the Oracle database error stack or from the Forms runtime error text-displays it to the user via GENERAL.DISP_TEXT, and then halts further trigger processing by raising FORM_TRIGGER_FAILURE.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate the Oracle Forms built-in FORM_SUCCESS to determine whether the most recent Forms operation completed without error.
- Step 2 - If the operation did not succeed, inspect the ERROR_TYPE built-in to classify the failure as either an Oracle database error ('ORA') or a Forms runtime error ('FRM').
- Step 3 - For an 'ORA' error type, retrieve the Oracle database error message via SQLERRM and pass it to GENERAL.DISP_TEXT with severity label 'Error' to display the message to the user.
- Step 4 - For a 'FRM' error type, retrieve the Forms runtime error message via the ERROR_TEXT built-in and pass it to GENERAL.DISP_TEXT with severity label 'Error' to display the message to the user.
- Step 5 - Raise FORM_TRIGGER_FAILURE to abort the current trigger execution and prevent any subsequent processing from continuing.

---
**Decision Points**

DP-001

Condition:
NOT FORM_SUCCESS - the most recent Oracle Forms operation did not complete successfully.

TRUE:
Proceed to classify the error type (see DP-002) and ultimately raise FORM_TRIGGER_FAILURE.

FALSE:
No action is taken; the procedure exits normally without raising an exception.

---

DP-002

Condition:
ERROR_TYPE = 'ORA' - the failure originated from the Oracle database layer.

TRUE:
Call GENERAL.DISP_TEXT passing SQLERRM as the error message text and 'Error' as the severity label.

FALSE (i.e., ERROR_TYPE = 'FRM'):
Call GENERAL.DISP_TEXT passing ERROR_TEXT (the Forms runtime error message) and 'Error' as the severity label.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A form operation is only considered successful if the Oracle Forms built-in FORM_SUCCESS evaluates to TRUE; any other outcome must be treated as a failure requiring user notification and trigger abortion.
- BR-002 - Oracle database errors (ERROR_TYPE = 'ORA') must be surfaced to the user using the Oracle error message returned by SQLERRM.
- BR-003 - Oracle Forms runtime errors (ERROR_TYPE = 'FRM') must be surfaced to the user using the Forms-supplied ERROR_TEXT message.
- BR-004 - All error messages must be displayed with a severity label of 'Error' through GENERAL.DISP_TEXT (SP-005).
- BR-005 - Upon detecting any form failure, FORM_TRIGGER_FAILURE must be raised unconditionally to halt the triggering event and prevent downstream processing.

---
**Implementation Logic**

```plsql
PROCEDURE CHECK_FORM_FAILURE IS
BEGIN
 IF (NOT form_success) THEN
     IF ERROR_TYPE = 'ORA' THEN
        GENERAL.disp_text(SQLERRM,'Error');
     ELSIF ERROR_TYPE = 'FRM' THEN
        GENERAL.disp_text(ERROR_TEXT,'Error');
     END IF;
     raise form_trigger_failure;
  END IF; 

END;
```

#### SP-004 - GENERAL.CHECK_NULL

**Invoked From:**

- pt_dead_stock_flag_fmb.xml [Trigger: FT_SAVE]
- pt_dead_stock_flag_fmb.xml [Trigger: WHEN-CHECKBOX-CHANGED]

---

**Screen:**

PART DETAILS (WN_MAIN / CN_MAIN); PART QUERY (WN_MAIN / CN_MAIN)

---

**Purpose**

Validates that a required field value has been supplied before a screen action is committed. If the supplied value is NULL, the procedure displays a user-facing error message identifying the offending column and halts further processing by raising a form trigger failure. It is invoked during save and checkbox-change events on the PART DETAILS and PART QUERY screens.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_value | VARCHAR2 | IN |
| column_title | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the field value (P_value) and the human-readable column title (column_title) as input parameters.
- Step 2 - Construct an error message string in the format 'Enter a valid <column_title>' using the supplied column title.
- Step 3 - Evaluate whether P_value is NULL.
- Step 4 - If P_value IS NULL, invoke GENERAL.DISP_TEXT (SP-005) passing the constructed message text and the severity label 'Error' to present the error to the user.
- Step 5 - After displaying the error, raise FORM_TRIGGER_FAILURE to abort the triggering event and prevent further processing.
- Step 6 - If P_value is NOT NULL, no action is taken and control returns normally to the caller.

---
**Decision Points**

DP-001

Condition:
P_value IS NULL

TRUE:
Call GENERAL.DISP_TEXT with the message 'Enter a valid <column_title>' and severity 'Error', then raise FORM_TRIGGER_FAILURE to halt the form trigger.

FALSE:
No error is raised; the procedure exits normally and the calling trigger continues execution.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A field value passed to this procedure must not be NULL; a NULL value is treated as an invalid entry that must be corrected before the form action can proceed.
- BR-002 - The error message presented to the user must identify the specific column that failed validation, using the format 'Enter a valid <column_title>', where column_title is provided by the caller.
- BR-003 - When a NULL value is detected, the error must be surfaced to the user via GENERAL.DISP_TEXT (SP-005) with a severity of 'Error' before the trigger is aborted.
- BR-004 - Processing of the originating form trigger (FT_SAVE or WHEN-CHECKBOX-CHANGED) must be unconditionally stopped after a NULL validation failure by raising FORM_TRIGGER_FAILURE, ensuring no downstream logic executes on invalid data.

---
**Implementation Logic**

```plsql
PROCEDURE CHECK_NULL( P_value IN VARCHAR2, column_title  IN VARCHAR2) IS
mesg_text        varchar2(80) := 'Enter a valid '||column_title ;
BEGIN
   IF p_value IS null  THEN
      GENERAL.DISP_TEXT(mesg_text,'Error');
      raise form_trigger_failure;
   END IF;
END;
```

#### SP-005 - GENERAL.DISP_TEXT

**Invoked From:**

- DPL.pld [StoredProcedure: GENERAL.CHECK_FORM_FAILURE]
- DPL.pld [StoredProcedure: GENERAL.CHECK_NULL]
- DPL.pld [StoredProcedure: GENERAL.RAISE_ERROR]
- pt_dead_stock_flag_fmb.xml [Trigger: FT_SAVE]
- pt_dead_stock_flag_fmb.xml [Trigger: KEY-CLRFRM]
- pt_dead_stock_flag_fmb.xml [Trigger: ON-ERROR]
- pt_dead_stock_flag_fmb.xml [Trigger: ON-MESSAGE]
- pt_dead_stock_flag_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]
- pt_dead_stock_flag_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]
- pt_dead_stock_flag_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]
- pt_dead_stock_flag_fmb.xml [Trigger: WHEN_LIST_CHANGED]

---

**Screen:**

PART DETAILS (WN_MAIN / CN_MAIN); PART QUERY (WN_MAIN / CN_MAIN)

---

**Purpose**

Displays a modal alert dialog to the user containing a provided message and title. The procedure selects the appropriate Oracle Forms alert template based on whether the title indicates an error condition, then renders the alert with the supplied text. It is used across multiple triggers and procedures in the Dead Stock Flag form and the GENERAL library to present both error and informational messages in a consistent manner.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| text_string | VARCHAR2 | IN |
| title_string | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Initialise the alert name variable to the default error alert template 'AL_ERRINFO'.
- Step 2 - Evaluate the title_string parameter: if its uppercase value equals 'ERROR', retain 'AL_ERRINFO' as the alert template; otherwise switch the alert template to 'AL_NOTE' for informational or non-error messages.
- Step 3 - Set the TITLE property of the selected alert to the value supplied in title_string.
- Step 4 - Set the alert message text property of the selected alert to the value supplied in text_string.
- Step 5 - Display the configured alert to the user by calling SHOW_ALERT, capturing the user's response in p_alert_id (response is not evaluated further).

---
**Decision Points**

DP-001

Condition:
UPPER(title_string) = 'ERROR'

TRUE:
The alert template 'AL_ERRINFO' is used, presenting the message as an error alert.

FALSE:
The alert template 'AL_NOTE' is used, presenting the message as a general informational or note-style alert.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The alert template selection is driven exclusively by the title_string value; a title of 'ERROR' (case-insensitive) mandates the error alert template 'AL_ERRINFO', and any other title value mandates the informational alert template 'AL_NOTE'.
- BR-002 - Both the alert title and the alert message text must be set dynamically from the supplied parameters before the alert is shown, ensuring the displayed content always reflects the caller's context rather than any static design-time defaults.
- BR-003 - The procedure does not evaluate the user's response to the alert (the return value of SHOW_ALERT is captured but not acted upon), meaning it is intended solely for notification and not for branching on user input.
- BR-004 - All callers - including GENERAL.CHECK_FORM_FAILURE, GENERAL.CHECK_NULL, GENERAL.RAISE_ERROR, and the triggers in pt_dead_stock_flag_fmb - must route user-facing message display through this procedure to maintain a consistent alert presentation standard across the form and library.

---
**Implementation Logic**

```plsql
PROCEDURE DISP_TEXT (text_string VARCHAR2,
                     title_string VARCHAR2 ) IS 
   p_alert_name varchar2(10) := 'AL_ERRINFO' ; 
   p_alert_id number;
BEGIN
   if upper(title_string)='ERROR' then
      p_alert_name := 'AL_ERRINFO' ; 
   else
      p_alert_name := 'AL_NOTE' ; 
   end if;
   set_alert_property(p_alert_name,TITLE,title_string);  
   set_alert_property(p_alert_name,alert_message_text,text_string);  
   p_alert_id := show_alert(p_alert_name); 
END;
```

#### SP-006 - GENERAL.L_POP_LIST_ITEM

**Invoked From:**

- pt_dead_stock_flag_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

PART QUERY (WN_MAIN / CN_MAIN)

---

**Purpose**

Populates a named Oracle Forms record group from a dynamic SQL query, ensuring any pre-existing group of the same name is removed before the new group is created and populated. This procedure is called during form initialisation (WHEN-NEW-FORM-INSTANCE) on the PART QUERY screen to load list-item data required for the Dead Stock Flag form.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_rg_name | VARCHAR2 | IN |
| p_select | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the record group name (p_rg_name) and the SQL SELECT statement (p_select) as input parameters, and assign the group name to a local variable.
- Step 2 - Search for an existing Oracle Forms record group with the supplied name using Find_Group.
- Step 3 - If a matching record group is found (i.e., the returned ID is not null), delete it using Delete_Group to prevent duplicate or stale group definitions.
- Step 4 - Create a new record group from the provided SQL query using Create_Group_From_Query, binding the group name and query string, and capture the new group ID.
- Step 5 - Populate the newly created record group by executing the underlying query via Populate_Group, storing the return code in errcode.

---
**Decision Points**

DP-001

Condition:
The record group identified by p_rg_name already exists in the current Oracle Forms session (Find_Group returns a non-null ID).

TRUE:
The existing record group is deleted via Delete_Group before a fresh group is created, ensuring no duplicate or outdated group persists.

FALSE:
No deletion is performed; processing continues directly to the creation of the new record group.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A record group with the specified name must not persist from a prior execution; any pre-existing group of the same name is unconditionally removed before the new group is created.
- BR-002 - The record group is always (re-)created from the caller-supplied SQL SELECT statement, ensuring the group definition reflects the query provided at the time of invocation.
- BR-003 - Group population is performed immediately after creation within the same procedure call; the caller is not responsible for triggering the populate step separately.

---
**Implementation Logic**

```plsql

PROCEDURE l_pop_list_item (p_rg_name VARCHAR2,p_select VARCHAR2 )IS

	 rg_name VARCHAR2(40) := p_rg_name;
	 rg_id RecordGroup;
	 errcode NUMBER; 
BEGIN 
	/* ** Make sure group doesn't already exist */ 
	rg_id := Find_Group( rg_name ); 

	IF NOT Id_Null(rg_id) THEN 
		delete_group(rg_id);
	END IF;
	/* ** If it does not exist, create it and add the two ** necessary columns to it. */ 
		rg_id := Create_Group_From_Query( rg_name, p_select); 
	 
	/* ** Populate the record group */ 
	errcode := Populate_Group( rg_id );
END;
```

#### SP-007 - GENERAL.RAISE_ERROR

**Invoked From:**

- pt_dead_stock_flag_fmb.xml [Trigger: ON-ERROR]

---

**Screen:**

N/A

---

**Purpose**

GENERAL.RAISE_ERROR is a centralised error-handling procedure invoked from Oracle Forms ON-ERROR triggers. It accepts a message code, constructs a formatted message text, classifies the message by type (Error, Note, or Caution), displays it to the user via GENERAL.DISP_TEXT, and raises FORM_TRIGGER_FAILURE when the message represents a hard error, thereby halting further form processing.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| mesg_code | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input message code (mesg_code) passed by the calling ON-ERROR trigger.
- Step 2 - Declare local variables to hold the message type (mesg_type), message text (mesg_text), and message title (mesg_title).
- Step 3 - Construct the display message text by concatenating mesg_code, a colon separator, and mesg_text (note: the GENERAL.get_message call that would have populated mesg_type and mesg_text from a lookup is commented out, so mesg_type and mesg_text retain their uninitialised default values at runtime).
- Step 4 - Evaluate mesg_type to determine the appropriate message classification and title:
  - If mesg_type is 'E', set mesg_title to 'Error', call GENERAL.DISP_TEXT to display the message, then raise FORM_TRIGGER_FAILURE to abort the current form operation.
  - If mesg_type is 'N', set mesg_title to 'Note' and call GENERAL.DISP_TEXT to display the message; processing continues normally.
  - If mesg_type is 'C', set mesg_title to 'Caution' and call GENERAL.DISP_TEXT to display the message; processing continues normally.
- Step 5 - If mesg_type does not match any of the three recognised values ('E', 'N', 'C'), no display action is taken and the procedure exits silently.

---
**Decision Points**

DP-001

Condition: mesg_type = 'E'

TRUE: Set mesg_title to 'Error', invoke GENERAL.DISP_TEXT with the formatted message text and title, then raise FORM_TRIGGER_FAILURE to halt the current form trigger execution.

FALSE: Proceed to evaluate whether mesg_type = 'N' (DP-002).

---

DP-002

Condition: mesg_type = 'N'

TRUE: Set mesg_title to 'Note' and invoke GENERAL.DISP_TEXT with the formatted message text and title; form processing continues.

FALSE: Proceed to evaluate whether mesg_type = 'C' (DP-003).

---

DP-003

Condition: mesg_type = 'C'

TRUE: Set mesg_title to 'Caution' and invoke GENERAL.DISP_TEXT with the formatted message text and title; form processing continues.

FALSE: No message is displayed and the procedure exits without further action.

---
**Database Interactions**

- DB-001 - Read AM_PERMISSIONS - Reads data from AM_PERMISSIONS for lookup or validation.
**Business Rules**

- BR-001 - The message text presented to the user must be prefixed with the originating message code followed by a colon separator, ensuring the user can identify the specific error or notification reference.
- BR-002 - A message classified as type 'E' (Error) is considered a hard stop; FORM_TRIGGER_FAILURE must be raised after display to prevent the form from continuing the current operation.
- BR-003 - A message classified as type 'N' (Note) is informational only; the procedure displays the message via GENERAL.DISP_TEXT and allows form processing to continue without raising an exception.
- BR-004 - A message classified as type 'C' (Caution) is a non-fatal warning; the procedure displays the message via GENERAL.DISP_TEXT and allows form processing to continue without raising an exception.
- BR-005 - If mesg_type does not resolve to a recognised value ('E', 'N', or 'C'), the procedure takes no display or exception action, resulting in a silent exit; message classification is therefore critical to correct error handling behaviour.
- BR-006 - All user-facing message display is delegated exclusively to GENERAL.DISP_TEXT (SP-005); RAISE_ERROR must not perform direct UI interaction by any other means.

---
**Implementation Logic**

```plsql
PROCEDURE RAISE_ERROR ( mesg_code IN VARCHAR2 )IS
  mesg_type  varchar2(7); 
  mesg_text  varchar2(200) ;
  mesg_title varchar2(7);
  BEGIN
     -- murali 17.05.04 GENERAL.get_message(mesg_code,mesg_text,mesg_type );
     mesg_text:=mesg_code||' : '||mesg_text;		
     IF ( mesg_type = 'E' ) THEN
        mesg_title := 'Error' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
        raise FORM_TRIGGER_FAILURE;
     ELSIF ( mesg_type = 'N' ) THEN
        mesg_title := 'Note' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     ELSIF ( mesg_type = 'C' ) THEN
        mesg_title := 'Caution' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     END IF;
  END;     

/* PROCEDURE check_rights( 
pi_form_name in varchar2,
pi_user_id in number) IS
lv_x varchar2(1);
BEGIN
	
	begin
	SELECT substr(access_string, pi_user_id,1) 
	INTO   lv_x
	FROM   	am_permissions
	WHERE  form_name = pi_form_name
	AND SUBSTR(access_string,pi_user_id,1)='Y';
	exception 
		when no_data_found then
		  general.disp_text('You do not have the Permission to access this.','Error rr');
		  raise form_trigger_failure; 
		when too_many_rows then
		  general.disp_text('Many rows in USER_PERMISSIONS','Error ss');
		  raise form_trigger_failure;
		when others then
		       general.disp_text(sqlerrm,'Error mm');
		       raise form_trigger_failure;
	end;

	open_form(pi_form_name,activate,session);
END;
*/
```

#### SP-008 - WIN_API_DIALOG.SELECT_PRINTER

**Invoked From:**

- pt_dead_stock_flag_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

N/A

---

**Purpose**

Presents the operating system's native printer-selection dialog to the user and returns the chosen printer name and port. It is invoked when the user presses the printer-selection button on the Dead Stock Flag screen, allowing the operator to direct report or document output to a specific printer before proceeding.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| PrinterName | VARCHAR2 | OUT |
| Port | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the RaiseExceptions flag (IN) which controls whether errors encountered during printer selection are propagated to the caller.
- Step 2 - Declare two local VARCHAR2(513) buffers (vcBuff1, vcBuff2) to temporarily hold the printer name and port returned by the OS dialog.
- Step 3 - Invoke the internal helper routine ChoosePrinter, passing the procedure identifier 'Select_Printer', the two local buffers (by reference), a dialog-style code of 0, and the RaiseExceptions flag.
- Step 4 - Assign the value returned in vcBuff1 to the OUT parameter PrinterName.
- Step 5 - Assign the value returned in vcBuff2 to the OUT parameter Port.
- Step 6 - Return control to the caller (WHEN-BUTTON-PRESSED trigger on pt_dead_stock_flag_fmb.xml) with PrinterName and Port populated.

---
**Decision Points**

DP-001

Condition:
RaiseExceptions is TRUE or FALSE when passed to ChoosePrinter.

TRUE:
ChoosePrinter is instructed to raise and propagate any exceptions encountered during the printer-selection dialog back to the caller.

FALSE:
ChoosePrinter suppresses exceptions internally; the procedure completes without raising an error to the caller, and PrinterName / Port may be empty if the user cancelled or an error occurred.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The printer name and port must be obtained exclusively through the ChoosePrinter call; no default or hard-coded printer values are assigned by this procedure.
- BR-002 - Buffer capacity for both PrinterName and Port is limited to 513 characters; values returned by the OS dialog that exceed this length will be truncated.
- BR-003 - The caller controls error-handling behaviour by supplying the RaiseExceptions flag; the procedure itself does not independently decide whether to suppress or surface exceptions.
- BR-004 - A dialog-style code of 0 is always passed to ChoosePrinter, fixing the style of the OS printer-selection dialog regardless of context.

---
**Implementation Logic**

```plsql

PROCEDURE Select_Printer (  PrinterName     OUT  VARCHAR2,
                            Port            OUT  VARCHAR2,
                            RaiseExceptions in BOOLEAN DEFAULT FALSE) is
  
  vcBuff1  VARCHAR2(513);
  vcBuff2  VARCHAR2(513);
begin
  ChoosePrinter('Select_Printer',vcBuff1, vcBuff2,0,RaiseExceptions);
  PrinterName := vcBuff1;
  Port        := vcBuff2;
end Select_Printer;
```

#### SP-009 - WIN_API_SHELL.WINEXEC

**Invoked From:**

- pt_dead_stock_flag_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

N/A

---

**Purpose**

Executes a Windows shell command from within the Oracle Forms environment by invoking the underlying d2kwutil WinExec API function. The procedure accepts a command string, a window style, and an exception-raising flag, then delegates execution to the Windows API layer. It is triggered from the dead-stock flag form when the user presses a button that requires an external process to be launched.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Command | VARCHAR2 | IN |
| WindowStyle | PLS_INTEGER | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Write a debug log entry (level 99) recording the input arguments: Command, WindowStyle, and the Boolean RaiseExceptions value converted to a character representation.
- Step 2 - Clear the Win_API error stack to ensure no residual error state from prior calls affects this execution.
- Step 3 - Check whether the Windows API layer is available (WIN_API.API_ENABLED).
- Step 4 - If the API is available, register the external function call for 'd2kwutil_WinExec' with the expected signature (INT return, CHAR and INT arguments) and copy the Command parameter into a local 512-character buffer.
- Step 5 - Invoke d2kwutil_WinExec passing the registered function handle, the command buffer, and the WindowStyle; capture the integer return code (iRC).
- Step 6 - Write a second debug log entry recording the return code received from the API call.
- Step 7 - If the return code is less than 32, record an error message indicating the command could not be executed along with the return code.
- Step 8 - If RaiseExceptions is TRUE and the return code indicated failure, raise NO_DATA_FOUND to propagate the error to the caller.
- Step 9 - Handle exceptions: re-raise NO_DATA_FOUND as-is; for WIN_API.NOT_AVAILABLE, log the no-API error message and re-raise; for all other exceptions, log a generic unexpected-error message appended with any external error details and re-raise.

---
**Decision Points**

DP-001

Condition:
WIN_API.API_ENABLED evaluates to TRUE.

TRUE:
Register the d2kwutil_WinExec function, copy the command into the local buffer, execute the Windows shell command, and capture the return code.

FALSE:
Raise the WIN_API.NOT_AVAILABLE exception, which is subsequently caught, logged, and re-raised.

---

DP-002

Condition:
The return code (iRC) returned by d2kwutil_WinExec is less than 32.

TRUE:
Record an error on the Win_API error stack indicating the command could not be executed, then evaluate DP-003.

FALSE:
The command executed successfully; no error is recorded and processing completes normally.

---

DP-003

Condition:
RaiseExceptions is TRUE (evaluated only when iRC < 32).

TRUE:
Raise NO_DATA_FOUND to signal the execution failure to the calling context.

FALSE:
Suppress the exception; the error remains on the error stack but control returns normally to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The Windows API must be enabled (WIN_API.API_ENABLED = TRUE) before any attempt is made to execute a shell command; if the API is unavailable the procedure immediately raises WIN_API.NOT_AVAILABLE.
- BR-002 - A return code of 32 or greater from the underlying WinExec API call indicates successful launch; any return code below 32 is treated as a failure condition.
- BR-003 - When execution fails (iRC < 32), an error describing the failed command and its return code is always added to the Win_API error stack regardless of the RaiseExceptions setting.
- BR-004 - Exception propagation on failure is caller-controlled: the RaiseExceptions parameter must be explicitly set to TRUE for the procedure to raise NO_DATA_FOUND; the default behaviour (FALSE) suppresses the exception while still recording the error.
- BR-005 - All exceptions are re-raised after logging so that the invoking trigger (WHEN-BUTTON-PRESSED in pt_dead_stock_flag_fmb.xml) retains full visibility of any failure.
- BR-006 - Debug logging at verbosity level 99 is performed both before execution (capturing input arguments) and after (capturing the return code), providing a complete audit trail of every WinExec invocation.

---
**Implementation Logic**

```plsql
PROCEDURE WinExec ( Command          IN  VARCHAR2,
                    WindowStyle      IN  PLS_INTEGER DEFAULT WIN_API.SW_SHOWNORMAL,
                    RaiseExceptions  IN  BOOLEAN DEFAULT FALSE) is
   iRC      pls_integer := 0;                    
   vcBuff1  varchar2(512);
begin
  Win_API_Debug.DebugLog(99,'WinExec','Args: Command="'||Command||'", WindowStyle='||to_char(WindowStyle)||', RaiseExceptions='||Win_API_Debug.BoolToChar(RaiseExceptions)); 
  Win_API.Clean_Error_Stack;
  if Win_API.API_ENABLED then
    win_api.Register_function_call(iWinExec,'d2kwutil_WinExec','INT','*CHAR,INT');
    vcBuff1    := Command;
    iRC   := d2kwutil_WinExec(win_api.FunctionHandle(iWinExec),vcBuff1,WindowStyle);
    Win_API_Debug.DebugLog(99,'WinExec','Result: RC='||to_char(iRC));
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  
  if iRC < 32 then 
    Win_API.Add_error('WinExec','Unable to execute '||Command||'(RC='||to_char(iRC)||')');
    if RaiseExceptions then 
      raise NO_DATA_FOUND;
    end if;
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('WinExec',Win_API.NoAPI);
    raise;
  when others then
    Win_API.Add_error('WINEXEC',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end WinExec;
```

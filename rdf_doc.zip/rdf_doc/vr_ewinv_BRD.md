# BUSINESS REQUIREMENTS DOCUMENT

## Table of Contents

- 1. Document Control
  - 1.1 Document Information
  - 1.2 Revision History
- 2. Executive Summary
  - Key Stakeholders
- 3. System Context
- 4. Functional Requirements
  - 4.1 Business Requirements
    - Requirement ID: BR-001
    - Requirement ID: BR-002
    - Requirement ID: BR-003
    - Requirement ID: BR-004
    - Requirement ID: BR-005
    - Requirement ID: BR-006
    - Requirement ID: BR-007
    - Requirement ID: BR-008
    - Requirement ID: BR-009
    - Requirement ID: BR-010
    - Requirement ID: BR-011
    - Requirement ID: BR-012
    - Requirement ID: BR-013
    - Requirement ID: BR-014
    - Requirement ID: BR-015
    - Requirement ID: BR-016
    - Requirement ID: BR-017
    - Requirement ID: BR-018
    - Requirement ID: BR-019
- 5. Business Rules Catalogue
- 6. Data Requirements
  - 6.1 Business Entities and Relationships
    - EW Commission Detail - VD_EW_COMM_DTL
    - CCP Commission Detail - VD_CCP_COMM_DTL
    - Entity Relationships
  - 6.2 Data Capture Requirements
    - Report Parameter Selection (Service Advisor - before running a report)
    - Session and Non-Database Parameters
  - 6.3 Reference Data
  - 6.4 Data Lifecycle
  - 6.5 Excel Output Columns
- 7. Glossary
- 8. Technical Inventory
  - 8.1 Form Architecture
    - 8.1.1 Global Variables
    - 8.1.2 Form Parameters
  - 8.2 Blocks
    - 8.2.1 Block WhereClause and OrderByClause
  - 8.3 Items Summary
  - 8.4 List of Values
  - 8.5 Alerts
  - 8.6 Program Units
  - 8.7 Triggers
    - 8.7.1 Inactive / Commented-Out Trigger Register
  - 8.8 Canvas and Window Inventory
  - 8.9 Editors
  - 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups
    - 8.10.1 Visual Attributes (form-defined)
    - 8.10.2 Property Classes (form-defined)
    - 8.10.3 Object Groups
  - 8.11 DataSourceColumn Inventory
- 9. Object Library
- 10. Record Groups
- 11. Referenced Database Objects
- 12. Backend Procedures and Packages
  - 12.1 Main Flow Backend Procedure/Package Index
  - 12.2 Procedure and Package Catalogue
- 13. Package Procedure Specifications
- 14. Database Package Catalogue
- 15. PLD Procedure Call Sites
  - DPL.pld (`general`)
  - Inactive / commented-only PLD call sites
  - webutil.pld (`WEBUTIL_CORE`)
  - webutil.pld (`WEBUTIL_C_API`)
  - webutil.pld (`WEBUTIL_FILE`)
  - Inactive / commented-only PLD call sites
  - webutil.pld (`WEBUTIL_FILE_TRANSFER`)
  - Inactive / commented-only PLD call sites
  - webutil.pld (`WEBUTIL_HOST`)
- 16. Microservice API Candidates
  - 16.1 Microservices with APIs
- 17. Workflows
- 18. PLD-Backed Logic
  - webutil.pld (`CLIENT_IMAGE`)
  - DPL.pld (`general`)
  - D2kwutil.pld (`Win_API`)
- 19. PCK-Backed Logic
- 20. System Interfaces
  - 20.1 Database Integrations
  - 20.2 External System Integrations
  - 20.3 Report Integrations
    - 20.3.1 Parameters Passed to the Report
- 21. Procedure and Function Business Rule Catalogue
  - 21.1 Catalogue Index
  - 21.2 Detailed Specifications
    - SP-001 - CALL_REPORT
    - SP-002 - DOWNLOAD_FILE
    - SP-003 - L_POP_LIST_ITEM
    - SP-004 - PR_PASS_PARAM
    - SP-005 - UPLOAD_FILE
    - SP-006 - VIEW_EXCEL_REP
    - SP-007 - D2KWUTIL.ATTEMPT_DLL_LOAD
    - SP-008 - D2KWUTIL.D2KWUTIL_DEBUGSTRING
    - SP-009 - D2KWUTIL.D2KWUTIL_GETDOSENV
    - SP-010 - D2KWUTIL.D2KWUTIL_GETREGKEY
    - SP-011 - D2KWUTIL.TRANSLATETYPE
    - SP-012 - GENERAL.ASK_CONFIRM
    - SP-013 - GENERAL.DISP_TEXT
    - SP-014 - GENERAL.RAISE_ERROR
    - SP-015 - WEBUTIL.BLOCKING
    - SP-016 - WEBUTIL.BOOLTOSTR
    - SP-017 - WEBUTIL.CHECKASACL
    - SP-018 - WEBUTIL.CHECKJAVA
    - SP-019 - WEBUTIL.CHECKLIBS
    - SP-020 - WEBUTIL.CLEARCALLBACKTRIGGER
    - SP-021 - WEBUTIL.CLOSEBLOB
    - SP-022 - WEBUTIL.CLOSEFILE
    - SP-023 - WEBUTIL.CREATETEMPFILE
    - SP-024 - WEBUTIL.DECODEBASE64FILE
    - SP-025 - WEBUTIL.DELETE_
    - SP-026 - WEBUTIL.DOWNLOADFROMURLINT
    - SP-027 - WEBUTIL.DOWNLOADINT
    - SP-028 - WEBUTIL.ENCODEBASE64FILE
    - SP-029 - WEBUTIL.ERROR
    - SP-030 - WEBUTIL.ERRORALERT
    - SP-031 - WEBUTIL.EXECUTE
    - SP-032 - WEBUTIL.EXISTS_
    - SP-033 - WEBUTIL.FCLOSE
    - SP-034 - WEBUTIL.FILE_IS_DIRECTORY
    - SP-035 - WEBUTIL.FILE_IS_READABLE
    - SP-036 - WEBUTIL.FOPEN
    - SP-037 - WEBUTIL.GETCALLBACKTRIGGER
    - SP-038 - WEBUTIL.GETCLIENTFILESEP
    - SP-039 - WEBUTIL.GETCLIENTOSFAMILY
    - SP-040 - WEBUTIL.GETCLIENTSETTING
    - SP-041 - WEBUTIL.GETIMPLCLASS
    - SP-042 - WEBUTIL.GETLASTERROR
    - SP-043 - WEBUTIL.GETLASTERRORARGS
    - SP-044 - WEBUTIL.GETNUMBER
    - SP-045 - WEBUTIL.GETOSFAMILY
    - SP-046 - WEBUTIL.GETOUTPUT
    - SP-047 - WEBUTIL.GETPATH
    - SP-048 - WEBUTIL.GETPROPERTY
    - SP-049 - WEBUTIL.GETSERVERFILESEP
    - SP-050 - WEBUTIL.GETSOURCECHUNKS
    - SP-051 - WEBUTIL.GETSOURCELENGTH
    - SP-052 - WEBUTIL.GETSTRING
    - SP-053 - WEBUTIL.GETVAR
    - SP-054 - WEBUTIL.GET_ATTRIBUTE_INT
    - SP-055 - WEBUTIL.GET_LINE
    - SP-056 - WEBUTIL.GET_RETURN_CODE
    - SP-057 - WEBUTIL.GET_STANDARD_OUTPUT
    - SP-058 - WEBUTIL.HOST
    - SP-059 - WEBUTIL.ID_NULL
    - SP-060 - WEBUTIL.INIT
    - SP-061 - WEBUTIL.INITWEBUTIL
    - SP-062 - WEBUTIL.IN_PROGRESS
    - SP-063 - WEBUTIL.ISERROR
    - SP-064 - WEBUTIL.IS_OPEN
    - SP-065 - WEBUTIL.LENGTH
    - SP-066 - WEBUTIL.LOG
    - SP-067 - WEBUTIL.NEW
    - SP-068 - WEBUTIL.OPENBLOB
    - SP-069 - WEBUTIL.OPENFILE
    - SP-070 - WEBUTIL.POPULATEPROPERTYBUNDLE
    - SP-071 - WEBUTIL.PUT
    - SP-072 - WEBUTIL.PUT_LINE
    - SP-073 - WEBUTIL.READDATA
    - SP-074 - WEBUTIL.READFROMPROPERTYBUNDLE
    - SP-075 - WEBUTIL.READTRANSFROMMSGBUNDLE
    - SP-076 - WEBUTIL.REGISTERBEAN
    - SP-077 - WEBUTIL.REGISTER_FUNCTION
    - SP-078 - WEBUTIL.RELEASE_PROCESS
    - SP-079 - WEBUTIL.SETCALLBACKTRIGGER
    - SP-080 - WEBUTIL.SETCLIENTSETTING
    - SP-081 - WEBUTIL.SETDATA
    - SP-082 - WEBUTIL.SETPROPERTY
    - SP-083 - WEBUTIL.UPLOADINT
    - SP-084 - WEBUTIL.WRITEDATA
    - SP-085 - WEBUTIL_CORE.CUSTOMEVENTHANDLER
    - SP-086 - WEBUTIL_CORE.SHOWBEANS
    - SP-087 - WEBUTIL_FILE_TRANSFER.AS_TO_CLIENT
    - SP-088 - WEBUTIL_FILE_TRANSFER.CLIENT_TO_AS
    - SP-089 - ADD_ERROR
    - SP-090 - ADD_EXTERNAL_ERRORS
    - SP-091 - BOOLTOCHAR
    - SP-092 - CLEAN_ERROR_STACK
    - SP-093 - CLIENT_HOST
    - SP-094 - DEBUGLOG
    - SP-095 - GET_ENVIRONMENT_STRING
    - SP-096 - READ_REGISTRY
    - SP-097 - REGISTER_FUNCTION_CALL
    - SP-098 - SETDEBUG
    - SP-099 - STRIPDIRSEP
    - SP-100 - WINDEBUG

## 1. Document Control

### 1.1 Document Information

| Field | Value |
| ----- | ----- |
| Document Title | VR_EWINV - Business Requirements Document |
| Form Module Name | VR_EWINV |
| Document Version | 1.0 |
| Date Created | August 15, 2026 |
| Author/Prepared By | BRD Agent |

### 1.2 Revision History

| Version | Date | Author | Description |
| --- | --- | --- | --- |
| 1.0 | August 15, 2026 | BRD Agent | Initial draft |

---

## 2. Executive Summary

*High-level overview of the vr_ewinv Extended Warranty and CCP Commission Invoice form, its purpose, and roles referenced in the module.*

The **vr_ewinv** Oracle Forms module is the **Extended Warranty (EW) and CCP Commission Invoice** screen used by dealership and principal staff to generate and print commission invoice reports. The user selects the product type - either Extended Warranty or CCP - and a report sub-type that determines whether the period is monthly (based on a financial year and contract month) or quarterly. The user then picks a dealer and optionally filters by city before running the report. For standard invoice printing, the user clicks the Report button and the invoice is generated through the Oracle Reports engine. For digitally signed invoices, the user clicks the Digital Signature button; the form first checks whether the e-invoice QR code and Invoice Reference Number (IRN) have been generated for the selected dealer and period, and only proceeds if the e-invoice prerequisites are met. A separate Annexure button allows the user to download a detailed commission breakdown as a spreadsheet file. The form does not create or update any records; it is a parameter-entry and report-dispatch screen only. Selection lists for financial year, dealer, city, and report format are populated from the database at runtime based on the logged-in user's principal and location access.

### Key Stakeholders

*Who uses vr_ewinv*

| Stakeholder | Role |
| :--- | :--- |
| **Dealer Staff / Dealership User** | Primary interactive user of vr_ewinv. Selects product type, period, and dealer parameters, then generates and downloads the commission invoice report or annexure. |
| **Principal / Head Office Staff** | Uses the form with broader access scope (multiple dealers and regions) to generate commission invoices across locations under the principal's portfolio. |
| **Regional Office Staff** | Uses the form with a regional scope to generate commission reports for dealers within their assigned region. |
| **Dealer** | The dealership entity whose commission invoice is being generated; dealer details are retrieved from the system and appear on the printed report. |

---

---

## 3. System Context

*Describes the vr_ewinv module's role within the DMS ecosystem, scope, process flow, and key integrations.*

The **vr_ewinv** module is the **Extended Warranty and CCP Commission Invoice** screen in the Dealer Management System. It provides the single interface through which dealership, regional, and head-office users select commission invoice parameters and dispatch invoice reports to the Oracle Reports engine for printing or download. The form connects to the dealership data, financial year configuration, e-invoice status checking, and file transfer services to complete the commission invoice generation process.

**System purpose:** Allow authorised users to select the product type (Extended Warranty or CCP), the invoice period, the dealer, and the report format, then generate and download the commission invoice - with optional digital signature validation against e-invoice status - as implemented in the vr_ewinv Oracle Forms module.

**In scope:**

- Select product type: Extended Warranty (EW) or CCP commission invoice
- Select report sub-type to determine period mode (monthly contract-month or quarterly)
- Choose financial year and contract month (for monthly sub-types) or financial year and quarter (for quarterly sub-type)
- Select a dealer from those having commission invoice records for the chosen period and product type
- Filter by city/location when required
- Submit report parameters to the Oracle Reports engine and generate the invoice PDF
- Validate e-invoice QR code and IRN generation status before printing a digitally signed invoice
- Download the generated report to the user's machine
- Download a commission detail annexure as a spreadsheet/CSV file for the selected period and dealer
- Populate financial year, dealer, city, and zone selection lists dynamically from master data
- Restrict accessible dealers and zones based on the logged-in user's principal and location assignments

**Process Name:** Commission Invoice Generation

**Process Owner:** Principal / Head Office Manager

**Process Objective:** Allow the authorised user to select the product type, period, and dealer, validate e-invoice prerequisites when applicable, and generate and download the commission invoice report or annexure.

**Process Trigger:** Authorised user opens the vr_ewinv screen to generate a commission invoice for a completed billing period

**Process Flow:**

The complete commission invoice generation process follows this sequence. Each step corresponds to Functional Requirements in Section 4.

```
STEP 1 ── FORM OPENS
         User opens the vr_ewinv screen. The session is registered with the database
         and the report description is loaded from the session context.
         Financial year boundaries are set from the session globals.

STEP 2 ── SELECT PRODUCT TYPE
         User selects the product type using the radio group:
         ├── EW (Extended Warranty) - extended warranty commission invoice
         └── CCP - CCP commission invoice
         The EW extension and SAWA commission fields are shown or hidden based on this choice.

STEP 3 ── SELECT REPORT SUB-TYPE
         User selects the report sub-type (radio group):
         ├── T (Quarterly) - period fields switch to financial year + quarter selection
         └── C / F / I / V / S / X (Monthly) - period fields switch to financial year + contract month

STEP 4 ── SELECT FINANCIAL YEAR (MONTHLY SUB-TYPES)
         User selects the financial year from the available financial years for the current
         dealer and company. The contract month list is reset and repopulated.

STEP 5 ── SELECT CONTRACT MONTH
         User selects the contract month from the list populated dynamically for the
         chosen financial year. Months run April through March.

STEP 6 ── SELECT FINANCIAL YEAR (QUARTERLY SUB-TYPE T)
         User selects the financial year from the LOV. Quarter and year parameters are
         calculated and stored for later use.

STEP 7 ── SELECT QUARTER (QUARTERLY SUB-TYPE T)
         User selects the quarter (Q1-Q4). The corresponding financial year period
         values are calculated from the selected quarter and session financial year.

STEP 8 ── VALIDATE PERIOD SELECTION
         The form validates that the required period fields are not empty before
         allowing the user to advance. An error is shown if the period is incomplete.

STEP 9 ── SELECT DEALER
         User selects a dealer from the list of dealers that have commission invoice
         records for the chosen product type and contract month/quarter.
         The dealer code, city description, and location code are populated.

STEP 10 ── SELECT CITY (OPTIONAL)
          User optionally selects a city/location from the city LOV to filter the
          report to a specific dealer location; ALL LOC is available for all locations.

STEP 11 ── GENERATE REPORT (STANDARD)
          User clicks the Report button.
          The form validates all required parameters (product type, period, dealer),
          resolves the invoice number from the commission detail records, builds the
          report parameter string from the report definition table, and submits the
          report job to the Oracle Reports server.

STEP 12 ── DOWNLOAD REPORT
          The generated report file is transferred from the application server to the
          user's machine for viewing or printing.

STEP 13 ── GENERATE DIGITALLY SIGNED INVOICE (DIGITAL SIGNATURE PATH)
          User clicks the Digital Signature button.
          The form checks e-invoice eligibility for the selected dealer (EINV_500_YN flag).
          ├── CCP: Queries the CCP commission detail table for the selected period and
          │         validates that the QR code and IRN have been generated in the
          │         e-invoice status table.
          └── EW:  Queries the EW commission detail table for the selected period and
                    validates QR and IRN status in the same way.
          If QR/IRN are not generated, the form blocks printing and shows an error.

STEP 14 ── SUBMIT SIGNED REPORT
          On successful e-invoice validation, the form submits the report job with
          the digital signature parameter set and downloads the signed PDF to the user.

STEP 15 ── DOWNLOAD ANNEXURE
          User clicks the Annexure button.
          The form builds a commission detail query for the selected product type,
          sub-type, period, and dealer, writes the result set as a CSV file on the
          server, and opens the file in the user's browser for download.

STEP 16 ── CLEAR FORM
          User clears the form. Parameter fields are reset; the report description
          and financial year display are restored from session values.

STEP 17 ── EXIT FORM
          User exits the screen. The Oracle DB application context is cleared
          and the form closes without any database write operations.
```

**Major process interactions:**

- **Dealer location master** - supplies the dealer list, city/location data, and dealer-specific e-invoice configuration for parameter selection
- **Company financial master** - provides the list of open financial years per dealer and company for period selection
- **Commission detail records (EW and CCP)** - used to filter eligible dealers, resolve invoice numbers, and supply annexure data
- **E-invoice status service** - checked before printing a digitally signed invoice to confirm QR code and IRN generation
- **Report parameter definition table** - stores the Oracle Reports parameter list definitions keyed by application and principal for dynamic report submission
- **Oracle Reports engine** - receives the assembled report parameters and generates the commission invoice PDF
- **WebUtil file transfer** - transfers generated report and CSV files between the application server and the user's client machine
- **User region/zone access table** - restricts the dealer and zone selection lists to the regions the logged-in user is authorised to access

---

---

## 4. Functional Requirements

### 4.1 Business Requirements

#### Requirement ID: BR-001

**Requirement Title:** Form Initialization and Application Session Context Setup

**Business Description:**
When the EW/CCP Invoice Report screen is first opened, the system registers the current database session under the invoice module identity, optionally starts a performance timer, sets global context values that identify the report and application, constructs the current financial year label from the session financial-year boundaries, looks up the report server for this module, retrieves the form's copyright declaration, maximises the main window, and configures the default field visibility so that the monthly-period fields are shown and active while the quarterly-period fields are hidden. This end-to-end initialisation ensures the session is properly tracked and the screen is ready for immediate use from the moment it opens.

**Actors:** System (automatic on form open)

**Preconditions:**
- The user has successfully authenticated and launched the EW/CCP Invoice Report screen.

**Main Flow:**

**Step 1 - Performance timer started when logging is active**
If application-level logging has been enabled for this session, the system starts a performance timer at the point the screen loads. This allows administrators to measure how long the screen takes to respond during monitored sessions.

**Step 2 - Session registered under the invoice module identity**
The system registers the current database session with the identifier `vr_ewinv` for this invoice module (via `DBMS_APPLICATION_INFO.SET_CLIENT_INFO` and `DBMS_APPLICATION_INFO.SET_MODULE`), so that any database-level monitoring tools can attribute activity on this screen to the correct application module.

**Step 3 - Global context variables set for report identity**
The system assigns the following session-level context values so that all subsequent report calls and audit routines can identify the active module:
- `global.report_desc` is set to *"EW Commission / Incentive Invoice Details"* - the standard title for this report screen.
- `global.report_name` is set to `vr_ewinv` - the internal report module identifier.
- `global.app_id` is set to `vr_ewinv` - the application identifier used for configuration lookups.

The on-screen Report Description field (`REPORT_DESC`) and block-level application identifier (`CB_BLK.APP_ID`) and report name (`CB_BLK.REPORT_NAME`) are then populated from these global values.

**Step 4 - Financial year label constructed from session date boundaries**
The system reads the financial-year start date (`GLOBAL.FIN_BEG`) and end date (`GLOBAL.FIN_END`) passed from the calling session context, extracts the four-digit year from each, and formats them as a combined label (e.g. `2024-2025`) which is stored in the `FINANCIAL_YEAR` field for use in period-selection display and report parameters.

**Step 5 - Report server resolved for this module**
The system looks up the configured report server for this application identifier and principal mapping from the report-configuration table (`EH_REPORTS`). If a custom server is defined for this module and principal, it is used; if the lookup finds no data or multiple rows, the global default report server is retained.

**Step 6 - Copyright declaration retrieved**
The system executes a database query to retrieve the copyright declaration text (`SF_COPYRIGHT_DECLARATION`) and stores it in the on-screen copyright field (`CB_BLK.COPYRIGHT_DECLARATION`), so that the declaration is always current on every screen load.

**Step 7 - Screen access check applied**
If the application identifier matches `vr_ewinv`, the access-check parameter (`PARAMETER.P_CHECK`) is set to `0` (access permitted); otherwise it is set to `1` (restricted), providing a gate for conditional access control applied by calling screens or report procedures.

**Step 8 - Main window maximised and default field layout applied**
The MDI container and the main application window (`WN_MAIN`) are both maximised so the screen fills the user's display. The quarterly-period fields (Quarter and Tariff Financial Year) are hidden and disabled; the monthly-period fields (Monthly Financial Year and Contract Month) are made visible and enabled. This default layout ensures the screen opens ready for the most common monthly-reporting workflow.

**Alternative Flows:**
- **BR-001-AF-01** - (from Step 1) If application-level logging is not enabled for this session, the performance timer is not started; the screen continues loading normally from Step 2.
- **BR-001-AF-02** - (from Step 5) If no matching report-server configuration is found (no data, too many rows, or any other exception), the global default report server is used without interrupting screen load.

---

---

#### Requirement ID: BR-002

**Requirement Title:** Form-Level Error Handling and User-Friendly Error Display

**Business Description:**
When any error occurs while the user is working on the EW/CCP Invoice Report screen, the system intercepts the error and presents a clear, readable message to the user. Specific error conditions - such as invalid date formats, numeric-only fields receiving text, optimistic locking conflicts, and database constraint violations - each receive their own targeted message. If none of the specific conditions match, the system displays the underlying database error text. In all cases the operation that caused the error is stopped, protecting data integrity.

**Actors:** System (automatic on any form error)

**Preconditions:**
- The user is actively working on the EW/CCP Invoice Report screen and an error condition has arisen.

**Main Flow:**

**Step 1 - Specific error codes matched and targeted messages shown**
The system examines the error code that was raised. If the error indicates an invalid date entry (error code 50004), the user sees the message *"Entered Date is not valid Date"* and the current operation is stopped. If the error indicates a date formatted incorrectly (error codes 50025 or 50026), the user sees *"Enter the Date in the proper format (DD-MM-YYYY)"* and the operation stops. If the error indicates that text or special characters were entered in a numeric-only field (error codes 40209 or 50016), the user sees *"Characters/Special Characters are not allowed here, enter the numeric value"* and the operation stops. If the error is a maximum-length violation (error code 40207), the system displays the built-in error text for that field and stops the operation.

*Business outcomes (errors, warnings, success, and status):*
- **BR-002-ES-01** - Invalid date value - *"Entered Date is not valid Date"*; the entry is rejected and focus remains on the screen.
- **BR-002-ES-02** - Date entered in wrong format - *"Enter the Date in the proper format (DD-MM-YYYY)"*; the entry is rejected.
- **BR-002-ES-03** - Non-numeric value in a numeric field - *"Characters/Special Characters are not allowed here, enter the numeric value"*; the entry is rejected.
- **BR-002-ES-04** - Maximum field length exceeded - the field's own built-in error description is displayed; the entry is rejected.

**Step 2 - Referential-integrity violation intercepted**
If the underlying database reports a referential-integrity constraint violation (database error code -02292), the system raises a predefined business error to inform the user that dependent records prevent the action being taken, and the operation is stopped.

*Procedures called:*
- **GENERAL.RAISE_ERROR** ([SP-008](#SP-008--GENERAL.RAISE_ERROR)) - GENERAL.RAISE_ERROR - raises the business-level error message corresponding to code E0088, stopping the current operation so the user is informed that related records exist and the action cannot proceed.
    * **Step 1** - Look up the predefined error message text associated with the supplied error code.
    * **Step 2** - Determine whether the message is classified as an Error, Note, or Caution.
    * **Step 3** - Display the message to the user as an alert with the appropriate severity label.
    * **Step 4** - If the message is an Error-type, stop further processing so the violating action is blocked.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Referential integrity constraint | Database error code -02292 - GENERAL.RAISE_ERROR [SP-008] | When a database constraint violation is detected during any save or update action | Prevents deletion or modification of a record that other records depend on | The operation is blocked; the user is notified via the business error message E0088 |

**Step 3 - Record lock / optimistic-locking conflict handled**
If the error indicates that another user has already updated the record being modified (error codes 40654, 40655, 40656, 40657, or 40659), the system displays the message *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*, rolls back any pending changes, and stops the operation so the user can re-query the current state of the record before retrying.

*Business outcomes (errors, warnings, success, and status):*
- **BR-002-ES-05** - Concurrent-update conflict - *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*; pending changes are rolled back; the user must re-query the record.

**Step 4 - All other database errors displayed and rolled back**
If none of the specific conditions above apply but a database-level error occurred (SQL error code is non-zero), the system displays the database's own error text, rolls back any pending changes, and stops the operation.

**Step 5 - Non-critical navigation errors silently suppressed**
If the error code is 40401 or 40405 (standard "no records found in query" or navigation boundary conditions), the system takes no action and allows normal processing to continue.

**Alternative Flows:**
- **BR-002-AF-01** - (from Step 4) If the SQL error code is zero (no database error occurred alongside the Forms error), the database-error display and rollback in Step 4 are skipped; the system moves to Step 5.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| System Error Code (`ERROR_CODE`) | Auto-populated | Numeric | N/A | N/A | N/A | An error condition has been raised | Read-only system value identifying the class of error | Used to route the error to the correct targeted message |
| System Error Text (`ERROR_TEXT`) | Auto-populated | Character | 200 | N/A | N/A | An error condition has been raised | Read-only system-generated description of the error | Displayed verbatim when error code is 40207 or as database error fallback |
| Database Error Code (`DBMS_ERROR_CODE`) | Auto-populated | Numeric | N/A | N/A | N/A | An error condition has been raised | Read-only database-level error code; checked for -02292 | Triggers referential-integrity error path |

---

---

#### Requirement ID: BR-003

**Requirement Title:** System Message Suppression and Redirection

**Business Description:**
When the system generates certain internal notification messages during normal use of the EW/CCP Invoice Report screen, the form's ON-MESSAGE trigger intercepts messages related to specific form-level conditions (field-length violations and maximum-field-length notifications, identified by codes 40209 and 40207) and presents them through the standard error display mechanism instead of the default Oracle Forms message box, ensuring a consistent user experience. All other system messages pass through unchanged.

**Actors:** System (automatic on any system message)

**Preconditions:**
- The user is working on the EW/CCP Invoice Report screen and the system has generated an internal message notification.

**Main Flow:**

**Step 1 - Specific message codes intercepted and displayed through the error mechanism**
When the system issues a message with code 40209 or 40207 (field-overflow and maximum-length conditions), the ON-MESSAGE trigger reformats and displays the message to the user via the standard error display, combining the message type, code number, and text in a single readable notification. The current operation is then stopped to prevent the invalid value being accepted.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-007](#SP-007--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the formatted message (combining error type, code number, and descriptive text) to the user through the standard notification mechanism, then stops processing.
    * **Step 1** - Receive the message text and the title/severity label to display.
    * **Step 2** - Determine the appropriate alert style: use the error-style alert for messages titled "Error", and the informational-style alert for all other titles.
    * **Step 3** - Display the modal alert to the user with the provided message text and title.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| System message code check for field-overflow conditions | Error code match on 40209 and 40207 - GENERAL.DISP_TEXT [SP-007] | ON-MESSAGE trigger fires when the system raises an internal notification for field-overflow (40209) or maximum-length (40207) conditions | Ensures these system messages are displayed in the same consistent format as all other errors on this screen | The message is shown in the standard error style and the operation is stopped |

**Alternative Flows:**
- **BR-003-AF-01** - (from Step 1) If the message code is neither 40209 nor 40207, the system message is allowed to pass through without interception and is displayed by the default Oracle Forms mechanism.

---

---

#### Requirement ID: BR-004

**Requirement Title:** Report Type Selection - EW or CCP Programme Toggle

**Business Description:**
When the user selects whether the invoice report relates to the Extended Warranty programme or the CCP Inspection programme, the screen responds by showing or hiding two additional option sections - the Extended Warranty Extension choices and the SAWA Commission section - so that only the fields relevant to the chosen programme are visible. This ensures the user sees a clean, uncluttered screen that matches the report type they intend to generate.

**Actors:** Service Advisor / Reporting User

**Preconditions:**
- The EW/CCP Invoice Report screen is open and the programme type radio group is available for selection.

**Main Flow:**

**Step 1 - User selects a programme type and dependent sections adjust their visibility**
When the user changes the programme type selection between Extended Warranty and CCP Inspection, the system immediately adjusts which additional sections are displayed on the screen. If the Extended Warranty option is chosen, both the Extended Warranty Extension section and the SAWA Commission section are made visible. If any other option (CCP Inspection) is chosen, both sections are hidden from view.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Programme Type (`EW_CCP`) | Mandatory | Radio group | N/A | N/A | EW (Extended Warranty) / CCP (CCP Inspection) | Screen open | Must be one of the available radio options | N/A - selection enforced by radio group |

---

---

#### Requirement ID: BR-005

**Requirement Title:** Invoice Sub-Type Selection and Period Filter Reconfiguration

**Business Description:**
When the user chooses a specific invoice sub-type - such as Commission, Incentive, or other variants - the screen automatically reconfigures which date-period fields are visible and available for input. For monthly-reporting sub-types, the Financial Year (for monthly periods) and Contract Month fields become active while the Quarter and Tariff Financial Year fields are hidden. For the Tariff sub-type, the opposite arrangement applies: Quarter and Tariff Financial Year become active while the monthly-period fields are hidden. Any values already entered in the period fields are also cleared, so the user starts fresh whenever the sub-type changes. This prevents mismatched report parameters by ensuring only the period fields relevant to the selected sub-type are shown.

**Actors:** Service Advisor / Reporting User

**Preconditions:**
- The EW/CCP Invoice Report screen is open and the invoice sub-type selection is available.

**Main Flow:**

**Step 1 - User changes the invoice sub-type; previously entered period values are cleared**
As soon as the user changes the invoice sub-type, any values already entered in the Quarter, Tariff Financial Year, Monthly Financial Year, Contract Month, Dealer, and City/Location fields are all cleared. This happens for both the initial change (when the radio button is pressed) and when the selection is validated on exit from the field.

**Step 2 - Period filter fields reconfigured based on the selected sub-type**
The system then sets the visibility and availability of the period filter fields according to the newly selected sub-type:
- If the sub-type is one of the monthly-reporting options (Commission, Dealer-directed Commission, Incentive, Vehicle-based, SAWA, or Extension), the Quarter and Tariff Financial Year fields are hidden and disabled; the Monthly Financial Year and Contract Month fields are made visible and enabled.
- If the sub-type is the Tariff option, the Quarter and Tariff Financial Year fields are made visible and enabled; the Monthly Financial Year and Contract Month fields are hidden and disabled.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Invoice Sub-Type (`P_EW`) | Mandatory | Radio group | N/A | N/A | T (Tariff) / C (Commission) / F (Dealer-directed) / I (Incentive) / V (Vehicle-based) / S (SAWA) / X (Extension) | Screen open | Must be a valid sub-type from the available options | N/A - enforced by radio group |
| Quarter (`QUARTER`) | Conditional - when sub-type is Tariff | List | N/A | N/A | Q1 / Q2 / Q3 / Q4 | Invoice sub-type is Tariff | Required only when sub-type is Tariff; hidden/disabled otherwise | N/A at this step - cleared on sub-type change |
| Tariff Financial Year (`FINANCIAL_YEAR`) | Conditional - when sub-type is Tariff | List | N/A | Financial Year master (LV_FINANCIAL_YEAR) | Selected financial year | Quarter selected | Required only when sub-type is Tariff; hidden/disabled otherwise | N/A at this step - cleared on sub-type change |
| Monthly Financial Year (`FINANCIAL_YEAR1`) | Conditional - when sub-type is a monthly-reporting option | List | 50 | Financial Year list (LV_FIN) | Selected financial year | Invoice sub-type is a monthly-reporting option | Required for monthly sub-types; hidden/disabled for Tariff | N/A at this step - cleared on sub-type change |
| Contract Month (`P_CONTRACT_MONTH`) | Conditional - when sub-type is a monthly-reporting option | List | 400 | Dynamically populated month list | Month-year value (e.g. APR-YY) | Monthly Financial Year selected | Required for monthly sub-types; hidden/disabled for Tariff | *"Contract Month can not be Blank)"* if blank on advance |

---

---

#### Requirement ID: BR-006

**Requirement Title:** Monthly Financial Year Selection and Contract Month List Population

**Business Description:**
When the user confirms a Financial Year selection for a monthly-reporting sub-type, the screen automatically clears any previously chosen Contract Month and rebuilds the Contract Month drop-down list to show exactly the twelve calendar months that fall within the chosen financial year (April through March of the following year). The cursor then advances to the Contract Month field so the user can immediately make their selection. This ensures the Contract Month list always reflects the correct months for the year the user has chosen.

**Actors:** Service Advisor / Reporting User

**Preconditions:**
- The invoice sub-type is set to a monthly-reporting option so that the Monthly Financial Year and Contract Month fields are visible and active.
- A Financial Year value has been entered or selected in the Monthly Financial Year field.

**Main Flow:**

**Step 1 - Previously selected Contract Month is cleared**
As soon as the user confirms the Financial Year value (either by tabbing off the field or validating it), the system clears any Contract Month value that was previously selected, so the list can be repopulated from scratch for the new year.

**Step 2 - Contract Month list rebuilt for the selected financial year**
The system dynamically constructs a list of the twelve months for the selected financial year - starting with April of the start year through March of the end year - and loads them into the Contract Month drop-down. The month labels include the two-digit year suffix derived from the selected financial year value. The record group used to stage this data is named `Category`; the result is then applied to the `CB_BLK.P_CONTRACT_MONTH` drop-down list via `POPULATE_LIST`.

*Procedures called:*
- **L_POP_LIST_ITEM** ([SP-003](#SP-003--L_POP_LIST_ITEM)) - L_POP_LIST_ITEM - clears any existing version of the `Category` record group and recreates it from a dynamically built query that generates the twelve months of the financial year in the correct calendar order (April through March), then loads the result into the Contract Month drop-down list (`CB_BLK.P_CONTRACT_MONTH`).
    * **Step 1** - Check whether a record group with the target name (`Category`) already exists and, if so, delete it to start fresh.
    * **Step 2** - Create a new record group from the dynamically provided query (which enumerates the twelve months of the selected financial year in order).
    * **Step 3** - Populate the record group by executing the query.
    * **Step 4** - Load the populated record group values into the on-screen drop-down list (`CB_BLK.P_CONTRACT_MONTH`).

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Contract Month list population | Dynamically built month query - L_POP_LIST_ITEM [SP-003] | When the user confirms the Monthly Financial Year value | Ensures the Contract Month list always contains exactly the twelve months of the chosen financial year | If the query or list-population fails, the Contract Month drop-down may be empty; the user cannot proceed until a valid year is provided |

**Step 3 - Focus moves to the Contract Month field**
After the list is populated, the cursor automatically advances to the Contract Month field so the user can select their desired month without additional navigation.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Monthly Financial Year (`FINANCIAL_YEAR1`) | Mandatory | List | 50 | Financial Year list (LV_FIN) | Selected financial year (e.g. 2024-25) | Monthly sub-type is selected | Must be a valid financial year; drives Contract Month list | N/A - list selection prevents invalid entry |
| Contract Month (`P_CONTRACT_MONTH`) | Conditional - when sub-type is a monthly-reporting option | List | 400 | Dynamically built month list (L_POP_LIST_ITEM) | Month-year label (e.g. APR-24) | Monthly Financial Year confirmed | Rebuilt every time Financial Year changes; previous value cleared | N/A - list cleared and repopulated automatically |

---

---

#### Requirement ID: BR-007

**Requirement Title:** Quarter and Tariff Financial Year Selection for Tariff-Period Reports

**Business Description:**
For the Tariff invoice sub-type, the user must select both a Quarter and a Tariff Financial Year to define the reporting period. When the user chooses a quarter, the system validates the selection is not blank, automatically derives the corresponding end month of that quarter, and clears the Tariff Financial Year so the user selects it fresh. When the user then picks the Tariff Financial Year (via a look-up list), the system validates both the quarter and year are provided, and computes the combined quarter-year reference used as a report parameter. Navigating off either field also enforces the blank checks. Together, these steps ensure that both period fields are always populated and consistent before the user can proceed to the report destination selection.

**Actors:** Service Advisor / Reporting User

**Preconditions:**
- The invoice sub-type is set to the Tariff option so that the Quarter and Tariff Financial Year fields are visible and active.

**Main Flow:**

**Step 1 - User selects a quarter; end-month derived and Tariff Financial Year cleared**
When the user changes the Quarter field selection, the system first checks that a quarter has been chosen. If the Quarter is blank, the user sees the message *"Quarter can not be Blank)"* and focus returns to the Quarter field, stopping further navigation. If a valid quarter is chosen (Q1, Q2, Q3, or Q4), the system derives the corresponding quarter end-month number (Q1 -> 06, Q2 -> 09, Q3 -> 12, Q4 -> 03), stores it for use in report parameters, and clears the Tariff Financial Year so it must be re-entered for the new quarter. Focus then moves to the Tariff Financial Year field.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Quarter is not blank | Quarter blank check - WHEN-LIST-CHANGED in CB_BLK.QUARTER | When the user changes the Quarter selection | Ensures a quarter is always selected before the user can advance to the Financial Year field | *"Quarter can not be Blank)"* is displayed; focus returns to the Quarter field and navigation stops |

**Step 2 - Tab-off from Quarter also validates the selection**
If the user navigates away from the Quarter field using the keyboard, the same blank check is performed. If the Quarter is blank and the sub-type is Tariff, the message *"Quarter can not be Blank)"* is shown and focus returns to the Quarter field. If the sub-type is not Tariff, the check is skipped and focus moves directly to the Tariff Financial Year field.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Quarter mandatory for Tariff sub-type | Quarter blank check (Tariff only) - KEY-NEXT-ITEM in CB_BLK.QUARTER | When the user tabs off the Quarter field | Enforces that the Quarter is provided before the user can reach the Financial Year field in Tariff mode | *"Quarter can not be Blank)"* is displayed; focus returns to the Quarter field |

**Step 3 - User selects Tariff Financial Year via look-up; quarter-year reference computed**
When the user opens the Tariff Financial Year look-up list (only active in Tariff mode), the system shows the available financial years. After the user selects a year, the system checks that the Financial Year field is not blank. If blank, the message *"Financial Year can not be Blank)"* is shown and focus returns to the Financial Year field. If a valid year is chosen, the system derives the combined quarter-year reference value by pairing the financial year with the quarter end-month (for Q4, the year used is the following year). This reference is stored as a report parameter for later use.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Financial Year is not blank after look-up | Financial Year blank check - KEY-LISTVAL in CB_BLK.FINANCIAL_YEAR | When the user closes the Financial Year look-up list | Ensures a financial year is selected and the quarter-year reference can be correctly computed | *"Financial Year can not be Blank)"* is displayed; focus returns to the Financial Year field |

**Step 4 - Tab-off from Financial Year also validates and advances to destination field**
If the user navigates away from the Tariff Financial Year field using the keyboard, the system checks the field is not blank. If blank, *"Financial Year can not be Blank)"* is shown and focus returns to the Financial Year field. If a value is present, focus advances to the report destination field.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Tariff Financial Year is not blank | Financial Year blank check - KEY-NEXT-ITEM in CB_BLK.FINANCIAL_YEAR | When the user tabs off the Tariff Financial Year field | Ensures both period parameters (Quarter + Financial Year) are set before the user proceeds to the destination selection | *"Financial Year can not be Blank)"* is displayed; focus returns to the Financial Year field |

**Step 5 - Contract Month drop-down refreshed on navigation (shared list population)**
When the user navigates away from the Monthly Financial Year field (applicable to monthly-reporting sub-types that share the same KEY-NEXT-ITEM trigger), the system also clears any previously selected Contract Month and rebuilds the Contract Month drop-down. The record group named `Category` is recreated from a dynamically built query covering the twelve months of the selected financial year (April through March), and the result is loaded into the `CB_BLK.P_CONTRACT_MONTH` drop-down via `POPULATE_LIST`. Focus then advances to the Contract Month field.

*Procedures called:*
- **L_POP_LIST_ITEM** ([SP-003](#SP-003--L_POP_LIST_ITEM)) - L_POP_LIST_ITEM - recreates the `Category` record group from a dynamically built twelve-month query and loads it into the `CB_BLK.P_CONTRACT_MONTH` drop-down.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Contract Month list population after financial year navigation | POPULATE_LIST using record group `Category` - KEY-NEXT-ITEM (shared trigger) | When the user confirms the Monthly Financial Year and navigates to the Contract Month field | Ensures the Contract Month drop-down (`CB_BLK.P_CONTRACT_MONTH`) always reflects the correct months for the chosen financial year | If list population fails the Contract Month drop-down may be empty; the user cannot proceed without a valid financial year |

*Business outcomes (errors, warnings, success, and status):*
- **BR-007-ES-01** - Quarter left blank (Tariff mode) - *"Quarter can not be Blank)"*; focus returns to the Quarter field.
- **BR-007-ES-02** - Financial Year left blank - *"Financial Year can not be Blank)"*; focus returns to the Financial Year field.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Quarter (`QUARTER`) | Conditional - when sub-type is Tariff | List | N/A | N/A | Q1 / Q2 / Q3 / Q4 | Sub-type is Tariff | Must not be blank; drives end-month derivation | *"Quarter can not be Blank)"* if blank |
| Tariff Financial Year (`FINANCIAL_YEAR`) | Conditional - when sub-type is Tariff | List | N/A | Financial Year look-up (LV_FINANCIAL_YEAR) | Financial year value | Quarter selected | Must not be blank; combined with quarter to form report parameter | *"Financial Year can not be Blank)"* if blank |

---

---

#### Requirement ID: BR-008

**Requirement Title:** Dealer Mandatory Validation on Field Navigation

**Business Description:**
When the user navigates away from the Dealer field without having selected a dealer, the system stops the navigation and displays a clear message asking the user to provide the dealer before continuing. If the sub-type requires navigating to the Quarter field next, focus is directed there; if the sub-type requires navigating to the Monthly Financial Year field, focus goes there instead. This ensures a dealer is always selected before the user can proceed to select the reporting period.

**Actors:** Service Advisor / Reporting User

**Preconditions:**
- The EW/CCP Invoice Report screen is open and the user has positioned the cursor in the Dealer field.

**Main Flow:**

**Step 1 - User navigates away from the Dealer field; dealer value checked**
When the user presses the navigation key to leave the Dealer field, the system checks whether a dealer has been entered. If the Dealer field is blank, the message *"Dealer can not be Blank)"* is displayed, focus is returned to the Dealer field, and navigation stops.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Dealer is not blank | Dealer blank check - KEY-NEXT-ITEM in CB_BLK.P_DEALER_DESC | When the user navigates away from the Dealer field | Ensures a dealer is always selected before period parameters can be entered | *"Dealer can not be Blank)"* is displayed; focus returns to the Dealer field |

**Step 2 - Focus directed to the appropriate period field based on sub-type**
If a dealer has been provided, the cursor moves to the next appropriate field. For the Tariff sub-type, focus advances to the Quarter field. For all monthly-reporting sub-types, the system also clears any previously chosen Contract Month, rebuilds the Contract Month drop-down using the record group named `Category` (populated via `POPULATE_LIST` for `CB_BLK.P_CONTRACT_MONTH`), and then advances focus to the Monthly Financial Year field so the user can select the reporting period.

*Procedures called:*
- **L_POP_LIST_ITEM** ([SP-003](#SP-003--L_POP_LIST_ITEM)) - L_POP_LIST_ITEM - recreates the `Category` record group from a dynamically built twelve-month query and loads it into the `CB_BLK.P_CONTRACT_MONTH` drop-down, clearing any stale Contract Month selection before the user picks the financial year.

*Business outcomes (errors, warnings, success, and status):*
- **BR-008-ES-01** - Dealer field left blank - *"Dealer can not be Blank)"*; navigation is stopped and focus returns to the Dealer field.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dealer (`P_DEALER_DESC`) | Mandatory | Text / list | 500 | Dealer look-up (LV_DEALER) | Dealer name | Screen open and sub-type selected | Must not be blank before navigating to period fields | *"Dealer can not be Blank)"* if blank on navigation |

---

---

#### Requirement ID: BR-009

**Requirement Title:** Contract Month Mandatory Check Before Dealer Field Becomes Active

**Business Description:**
When the cursor is about to enter the Dealer field, the system first verifies that a Contract Month has been selected for the current report period. If no Contract Month is present, the user is shown a message and focus is held at the Contract Month field rather than allowing entry in the Dealer field. This ensures the reporting period is established before the dealer is chosen.

**Actors:** Service Advisor / Reporting User

**Preconditions:**
- The EW/CCP Invoice Report screen is open, a monthly-reporting sub-type has been selected, and the user is navigating towards the Dealer field.

**Main Flow:**

**Step 1 - System checks Contract Month before allowing entry in the Dealer field**
As the cursor is about to land in the Dealer field, the system checks whether the Contract Month has already been selected. If the Contract Month is blank, the message *"Contract Month can not be Blank)"* is displayed and focus is redirected to the Contract Month field, preventing the user from reaching the Dealer field until the month is provided.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Contract Month is not blank before Dealer can be entered | Contract Month blank check - WHEN-NEW-ITEM-INSTANCE in CB_BLK.P_DEALER_DESC | When the cursor is about to enter the Dealer field | Ensures the reporting period (Contract Month) is set before the user selects a dealer | *"Contract Month can not be Blank)"* is displayed; focus moves to the Contract Month field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-009-ES-01** - Contract Month is blank when cursor tries to enter Dealer field - *"Contract Month can not be Blank)"*; focus redirected to Contract Month field.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Contract Month (`P_CONTRACT_MONTH`) | Mandatory before accessing Dealer | List | 400 | Dynamically built month list | Month-year label | Monthly Financial Year confirmed | Must not be blank before Dealer field can be entered | *"Contract Month can not be Blank)"* if blank |

---

---

#### Requirement ID: BR-010

**Requirement Title:** View Invoice Report

**Business Description:**
When the user clicks the View Invoice button, the system validates that all mandatory report parameters have been supplied, looks up the correct invoice number for the selected dealer, location, period, and invoice sub-type, then generates and displays the invoice report as a PDF document in the user's browser. The report file name and format are determined by whether the selected programme type is Extended Warranty or CCP Inspection. No digital signature is applied in this flow.

**Actors:** Service Advisor / Reporting User

**Preconditions:**
- The programme type (EW or CCP), invoice sub-type, dealer, and reporting period (Contract Month or Quarter + Financial Year) have all been selected on the screen.

**Main Flow:**

**Step 1 - Report parameters assembled from screen selections and configuration**
When the user clicks the View Invoice button, the form passes control to the report-calling procedure. The procedure first checks that the Dealer is not blank, then checks that the required period fields are filled (Quarter and Financial Year for Tariff; Monthly Financial Year and Contract Month for all other sub-types), displaying *"Dealer can not be Blank)"*, *"Quarter can not be Blank)"*, *"Financial Year can not be Blank)"*, or *"Contract Month can not be Blank)"* respectively if any are missing and stopping the action.

*Procedures called:*
- **CALL_REPORT** ([SP-001](#SP-001--CALL_REPORT)) - CALL_REPORT - validates all mandatory parameters, identifies the correct invoice number for the selected dealer/location/period/sub-type combination, selects the appropriate report file, assembles report parameters from configuration, generates the report as a PDF, and opens it in the user's browser for viewing.
    * **Step 1** - Check that the Dealer field is not blank; if blank, stop with an appropriate error message.
    * **Step 2** - Check that the period fields required for the selected sub-type are not blank (Quarter and Financial Year for Tariff; Monthly Financial Year and Contract Month for monthly sub-types); if any are blank, stop with the corresponding error message.
    * **Step 3** - Retrieve the report configuration parameters for this application and the current principal from the report configuration table, building the parameter string to be passed to the report engine.
    * **Step 4** - Based on the programme type selected (EW or CCP) and the invoice sub-type, set the correct report filename (for CCP Commission: `vr_ccpinv`; for CCP other types: `vr_ccfinv`; for EW: `vr_ewinv`).
    * **Step 5** - Look up the invoice number, invoice date, and digital-signature file path for the matching dealer, location, period, and sub-type record from the commission detail table; if no matching record is found, stop with *"CCP INVOICE NUMBER NOT FOUND"* or *"EW INVOICE NUMBER NOT FOUND."*.
    * **Step 6** - Configure the report object with the selected report filename, parameter string, report server, and output format (PDF), then run the report and display it in the user's browser.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Dealer not blank | Dealer blank check - CALL_REPORT [SP-001] | When the View Invoice button is clicked | Prevents the report from running without a dealer selection | *"Dealer can not be Blank)"*; report does not run |
| Quarter not blank (Tariff only) | Quarter blank check - CALL_REPORT [SP-001] | When the View Invoice button is clicked and sub-type is Tariff | Prevents the report from running without a quarter selection | *"Quarter can not be Blank)"*; report does not run |
| Financial Year not blank (Tariff only) | Financial Year blank check - CALL_REPORT [SP-001] | When the View Invoice button is clicked and sub-type is Tariff | Prevents the report from running without a financial year selection | *"Financial Year can not be Blank)"*; report does not run |
| Monthly Financial Year not blank (monthly sub-types) | Financial Year blank check - CALL_REPORT [SP-001] | When the View Invoice button is clicked and sub-type is a monthly option | Prevents the report from running without a financial year selection | *"Financial Year can not be Blank)"*; report does not run |
| Contract Month not blank (monthly sub-types) | Contract Month blank check - CALL_REPORT [SP-001] | When the View Invoice button is clicked and sub-type is a monthly option | Prevents the report from running without a contract month selection | *"Contract Month can not be Blank)"*; report does not run |
| Invoice record found for selected parameters | Invoice lookup - CALL_REPORT [SP-001] | After all mandatory fields are validated | Confirms a matching invoice exists before the report is generated | *"CCP INVOICE NUMBER NOT FOUND"* or *"EW INVOICE NUMBER NOT FOUND."* depending on programme type |

*Business outcomes (errors, warnings, success, and status):*
- **BR-010-ES-01** - Dealer not provided - *"Dealer can not be Blank)"*; report does not run.
- **BR-010-ES-02** - Quarter not provided (Tariff) - *"Quarter can not be Blank)"*; report does not run.
- **BR-010-ES-03** - Financial Year not provided - *"Financial Year can not be Blank)"*; report does not run.
- **BR-010-ES-04** - Contract Month not provided (monthly types) - *"Contract Month can not be Blank)"*; report does not run.
- **BR-010-ES-05** - No invoice found for CCP - *"CCP INVOICE NUMBER NOT FOUND"*; report does not run.
- **BR-010-ES-06** - No invoice found for EW - *"EW INVOICE NUMBER NOT FOUND."*; report does not run.

*Business Scenarios - How the report differs by programme type and sub-type*

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **EW (Extended Warranty) - any sub-type** | Invoice record looked up from the EW Commission Detail table; report filename set to `vr_ewinv`; period filter uses Contract Month for monthly sub-types or Quarter + Financial Year for Tariff. |
| **CCP Inspection - Commission sub-type** | Invoice record looked up from the CCP Commission Detail table; report filename set to `vr_ccpinv`. |
| **CCP Inspection - other sub-types** | Invoice record looked up from the CCP Commission Detail table; report filename set to `vr_ccfinv`. |

**Alternative Flows:**
- **BR-010-AF-01** - (from Step 1) Any mandatory field blank: the specific validation message shown above is displayed and the report generation stops immediately; the user corrects the field and re-clicks View Invoice.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Programme Type (`EW_CCP`) | Mandatory | Radio group | N/A | N/A | EW / CCP | Screen open | Must be selected | N/A |
| Invoice Sub-Type (`P_EW`) | Mandatory | Radio group | N/A | N/A | T / C / F / I / V / S / X | Programme type selected | Must be selected | N/A |
| Dealer (`P_DEALER_DESC`) | Mandatory | Text / list | 500 | Dealer look-up (LV_DEALER) | Dealer name | Sub-type selected | Must not be blank | *"Dealer can not be Blank)"* |
| Location (`P_LOC`) | Mandatory | List | N/A | City/Location look-up (LV_CITY) | Location code | Dealer selected | Required for invoice lookup | N/A |
| Contract Month (`P_CONTRACT_MONTH`) | Conditional - monthly sub-types | List | 400 | Dynamic month list | Month-year label | Monthly Financial Year confirmed | Must not be blank for monthly sub-types | *"Contract Month can not be Blank)"* |
| Monthly Financial Year (`FINANCIAL_YEAR1`) | Conditional - monthly sub-types | List | 50 | Financial Year list (LV_FIN) | Financial year | Monthly sub-type selected | Must not be blank | *"Financial Year can not be Blank)"* |
| Quarter (`QUARTER`) | Conditional - Tariff sub-type | List | N/A | N/A | Q1 / Q2 / Q3 / Q4 | Tariff sub-type selected | Must not be blank for Tariff | *"Quarter can not be Blank)"* |
| Tariff Financial Year (`FINANCIAL_YEAR`) | Conditional - Tariff sub-type | List | N/A | Financial Year look-up (LV_FINANCIAL_YEAR) | Financial year | Quarter selected | Must not be blank for Tariff | *"Financial Year can not be Blank)"* |
| Report Name (`REPORT_NAME`) | Auto-populated | Text | 2000 | N/A | vr_ewinv / vr_ccpinv / vr_ccfinv | Invoice lookup succeeded | Set by the system based on programme type and sub-type | N/A |
| File Name / Parameters (`FILENAME`) | Auto-populated | Text | 4000 | N/A | Report parameter string | Report object configured | Set by the system; not user-editable | N/A |

---

---

#### Requirement ID: BR-011

**Requirement Title:** Digitally Sign Invoice with E-Invoice QR Code Validation

**Business Description:**
When the user clicks the Digitally Sign button, the system performs a series of checks to determine whether the invoice is eligible for digital signing. For certain dealers, the system first checks whether the e-invoice QR code has already been generated for the selected invoice. If the QR code is not yet ready, the user is informed of the reason - whether the signing is still processing, whether data needs to be uploaded first, or whether the generation failed - and the action is blocked. Once eligibility is confirmed, the system generates the invoice as a PDF, downloads it to the user's local machine for signing with the digital signature tool, uploads the signed file back to the server, updates the invoice record to mark it as digitally signed, and finally opens the signed document in the browser. If the invoice was already signed in a previous session, the previously stored signed document is opened directly without regenerating it.

**Actors:** Service Advisor / Reporting User

**Preconditions:**
- The programme type (EW or CCP) and all mandatory report parameters (invoice sub-type, dealer, location, and reporting period) have been selected.
- The invoice for the selected period, dealer, and location exists in the system.

**Main Flow:**

**Step 1 - Invoice eligibility check: QR/IRN status verified for applicable dealers**
When the user clicks the Digitally Sign button, the system looks up the invoice number, QR generation status, IRN generation status, and invoice date for the selected dealer, location, period, and sub-type from the appropriate commission detail table (CCP or EW). If no matching invoice record is found, the user sees *"QR/IRN Not Found Against Invoice."* and the action stops.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Invoice record exists for selected parameters | Invoice lookup - WHEN-BUTTON-PRESSED in CB_BLK.PB_DIGI_SIG | When the Digitally Sign button is clicked | Confirms the invoice exists before attempting QR/signature checks | *"QR/IRN Not Found Against Invoice."*; digital sign action stops |

**Step 2 - E-invoice 500-turnover flag checked for the dealer**
The system looks up whether the dealer is subject to the GST e-invoicing requirement (the "500 crore turnover" threshold flag) from the dealer location parameter table. If the lookup fails, the flag defaults to "not applicable" and the system proceeds directly to report generation in Step 7.

**Step 3 - Date eligibility checked for e-invoicing-mandatory dealers**
For dealers where the e-invoicing requirement applies, the system further checks whether the invoice date is on or after 1 October 2020 (the effective date for e-invoicing). If the invoice date is before that threshold, the system proceeds directly to report generation in Step 7 without performing QR checks.

**Step 4 - E-invoice status retrieved and QR readiness checked**
For invoices that meet both the turnover-flag and date-threshold conditions, the system retrieves the current e-invoice status and any error description from the e-invoice tracking table. It also retrieves the dealer's category from the dealer-location master. If the QR code has already been generated (QR generation flag is "Y"), the system proceeds directly to report generation in Step 6. If not, the system evaluates why it is not yet ready:
- For dealers categorised as "MUL" (multi-location), the user sees *"QR Code generation for B2B customer in process. Please try after 10 mins."* and the action stops.
- For other dealers:
  - If no e-invoice status record exists, the user sees *"Please upload data in E-invoice Upload Screen under Service Tab. "* and the action stops.
  - If the status is "P" (processing), the user sees *"QR Code generation for B2B customer in process. Please try after 10 mins."* and the action stops.
  - For any other status, the user sees the dynamic message *"QR Code generation failed."* followed by the actual status code and the error description from the e-invoice record, and the action stops.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| QR code has been generated | QR generation flag check - WHEN-BUTTON-PRESSED in CB_BLK.PB_DIGI_SIG | After invoice lookup and e-invoice flag/date checks pass | Ensures e-invoice QR code is ready before the invoice can be digitally signed | See Step 4 outcomes |
| E-invoice data uploaded for non-MUL dealers | E-invoice status IS NULL check - WHEN-BUTTON-PRESSED in CB_BLK.PB_DIGI_SIG | When QR flag is not "Y" and dealer is not MUL | Prompts the user to upload e-invoice data if it has not been submitted yet | *"Please upload data in E-invoice Upload Screen under Service Tab. "* |

*Business outcomes (errors, warnings, success, and status):*
- **BR-011-ES-01** - Invoice not found - *"QR/IRN Not Found Against Invoice."*; action stops.
- **BR-011-ES-02** - QR code pending for MUL dealer - *"QR Code generation for B2B customer in process. Please try after 10 mins."*; action stops.
- **BR-011-ES-03** - E-invoice data not yet uploaded - *"Please upload data in E-invoice Upload Screen under Service Tab. "*; action stops.
- **BR-011-ES-04** - QR code generation failed - *"QR Code generation failed."* followed by the e-invoice status code and error description; action stops.

**Step 5 - Digital signing allowed only within the permitted window**
Before generating the report for signing, the system checks whether the current date is within the allowed signing window (configurable via a system list, defaulting to 20 days from the invoice date). If the signing window has expired, the user sees *"Digital Sign only Allowed till 20th day from Invoice date. "* and the action stops.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Digital signing within allowed time window | Elapsed-day check against configurable threshold (AM_LIST EW_DSIGN_ALLOW_DAYS) - CALL_REPORT [SP-001] | After QR readiness is confirmed | Prevents digital signing of invoices beyond the permitted signing period | *"Digital Sign only Allowed till 20th day from Invoice date. "*; action stops |

**Step 6 - Already-signed document retrieved and displayed directly**
If the invoice record already has a digital-signature file path stored (indicating it was signed in a previous session), the system copies the existing signed PDF to a temporary location and opens it in the browser for the user to view. No new report generation or signing takes place.

**Step 7 - Configuration paths and signing command retrieved**
For a new digital signature, the system retrieves the local file path for the digital-signature tool, the server-side destination path, and the command string for invoking the signature tool - all from the application configuration. If any of these lookups fail, the user sees the corresponding configuration error (*"Error while getting local file path"*, *"Error while getting server file path"*, or *"Command Not Found in am_list"*) and the action stops.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Local file path configuration found | AM_LIST FILE_PATH (JCBDL) lookup - CALL_REPORT [SP-001] | During digital-sign file preparation | Ensures the local path for the digital-signature tool is configured before attempting to write files | *"Error while getting local file path"*; action stops |
| Server file path configuration found | AM_LIST FILE_PATH (JCBDS) lookup - CALL_REPORT [SP-001] | During digital-sign file preparation | Ensures the server destination path is configured before attempting to write files | *"Error while getting server file path"*; action stops |
| Signing command configuration found | AM_LIST_RANGE CRI_DIGI_CMD lookup - CALL_REPORT [SP-001] | During digital-sign file preparation | Ensures the command to invoke the digital-signature tool is configured | *"Command Not Found in am_list"*; action stops |
| Financial year found for the dealer | FM_COMPANY financial year lookup - CALL_REPORT [SP-001] | During digital-sign file preparation | Retrieves the current financial year to organise the signed-file directory | *"Fin year not found for this dealer"*; action stops |

*Business outcomes (errors, warnings, success, and status):*
- **BR-011-ES-05** - Digital signing window expired - *"Digital Sign only Allowed till 20th day from Invoice date. "*; action stops.
- **BR-011-ES-06** - Local path not configured - *"Error while getting local file path"*; action stops.
- **BR-011-ES-07** - Server path not configured - *"Error while getting server file path"*; action stops.
- **BR-011-ES-08** - Signing command not configured - *"Command Not Found in am_list"*; action stops.
- **BR-011-ES-09** - Financial year not found - *"Fin year not found for this dealer"*; action stops.

**Step 8 - Invoice PDF generated and downloaded to client for signing**
The system generates the report parameters, sets the report output to PDF format with the server-side filename, runs the report, and then downloads the unsigned PDF to the user's local machine at the configured local path. The digital-signature tool is then invoked on the client machine using the configured command, which applies the digital signature to the file.

*Procedures called:*
- **CALL_REPORT** ([SP-001](#SP-001--CALL_REPORT)) - CALL_REPORT - orchestrates the full digital-signing workflow: validates all parameters, checks e-invoice readiness (for applicable dealers), retrieves configuration, generates the PDF report, downloads it to the client, invokes the signing tool, uploads the signed file back to the server, updates the invoice record, and displays the signed document.
    * **Step 1** - Check that the Dealer field is not blank; if blank, stop with an appropriate error message.
    * **Step 2** - Check that the period fields required for the selected sub-type are not blank; if any are blank, stop with the corresponding error message.
    * **Step 3** - Retrieve the report configuration parameters for this application and the current principal from the report configuration table, building the parameter string for the report engine.
    * **Step 4** - Set the correct report filename based on programme type and invoice sub-type.
    * **Step 5** - Look up the invoice number, invoice date, and digital-signature file path; if not found, stop with the appropriate error message.
    * **Step 6** - For the digital-signing path: check the digital-signing time window, retrieve configuration paths and signing command, generate and download the unsigned PDF, invoke the signing tool, upload the signed file, update the invoice record to mark it as signed, and display the signed document in the browser.

- **DOWNLOAD_FILE** ([SP-002](#SP-002--DOWNLOAD_FILE)) - DOWNLOAD_FILE - transfers the generated unsigned PDF file from the server to the user's local machine using WebUtil file transfer, so the digital-signature tool can access it.
    * **Step 1** - Receive the server-side file path, the local destination path, and a flag indicating whether to open the file on the client after download.
    * **Step 2** - Transfer the file from the application server to the specified local client path using WebUtil binary file transfer.
    * **Step 3** - If the transfer fails, display "File download Failed" to the user and stop.
    * **Step 4** - If the transfer succeeds and the open-file flag is set, invoke the client host to open the downloaded file.

**Step 9 - Signed file uploaded to server, invoice record updated, signed document displayed**
After the digital-signature tool has signed the file on the client machine, the signed PDF is uploaded from the client back to the configured server path. If the upload succeeds, the invoice record in the commission detail table is updated to record that the digital signature was applied, the path to the signed file, and the signing date. The signed document is then opened in the browser for the user to confirm. Finally, the temporary unsigned PDF files are deleted from the client machine. If the upload fails, the user sees the upload error text and the action stops.

*Procedures called:*
- **UPLOAD_FILE** ([SP-005](#SP-005--UPLOAD_FILE)) - UPLOAD_FILE - transfers the locally-signed PDF file back to the server using WebUtil file transfer.
    * **Step 1** - Receive the local client file path and the server destination path.
    * **Step 2** - Transfer the file from the client machine to the specified server path using WebUtil binary file transfer.
    * **Step 3** - Return any error description in the output parameter; a null value means the upload succeeded.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Signed file upload succeeded | Upload error description check - CALL_REPORT [SP-001] | After the digital-signature tool has processed the file | Ensures the signed PDF was successfully transferred to the server before the invoice record is updated | The upload error text is displayed; action stops and invoice record is not updated |

*Business Scenarios - How digital signing differs by programme type and dealer eligibility*

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **CCP Inspection programme** | Invoice record looked up from CCP Commission Detail table; invoice record for digital-sign flag updated in the CCP Commission Detail table. |
| **EW (Extended Warranty) programme** | Invoice record looked up from EW Commission Detail table; digital-sign record updated in EW Commission Detail table. |
| **Dealer not subject to e-invoicing (turnover flag not set)** | QR/IRN checks in Steps 2-4 are skipped entirely; system proceeds directly to report generation and signing. |
| **Invoice date before 1 October 2020** | Date-threshold check in Step 3 causes the system to skip QR checks and proceed directly to report generation. |
| **Invoice already digitally signed (signature path present)** | Steps 5-9 are skipped; the previously stored signed PDF is copied to a temporary path and displayed in the browser directly (Step 6 alternative). |
| **Monthly sub-type (Commission, Incentive, etc.)** | Period filter uses Contract Month; signing proceeds once month and year are both confirmed. |
| **Tariff sub-type** | Period filter uses Quarter + Financial Year; signing proceeds once both are confirmed. |

**Alternative Flows:**
- **BR-011-AF-01** - (from Step 1) Invoice not found for the selected parameters: *"QR/IRN Not Found Against Invoice."* is displayed and the action stops; the user must correct the selection parameters.
- **BR-011-AF-02** - (from Step 3) Invoice date is before 1 October 2020: QR checks are skipped and the system proceeds directly to report generation and signing.
- **BR-011-AF-03** - (from Step 2) Dealer's e-invoicing turnover flag is not set: the system skips Steps 3-4 entirely and proceeds to report generation and signing.
- **BR-011-AF-04** - (from Step 6) Invoice already has a stored digital-signature path: the signed PDF is displayed directly without regenerating or re-signing.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Programme Type (`EW_CCP`) | Mandatory | Radio group | N/A | N/A | EW / CCP | Screen open | Must be selected | N/A |
| Invoice Sub-Type (`P_EW`) | Mandatory | Radio group | N/A | N/A | T / C / F / I / V / S / X | Programme type selected | Must be selected | N/A |
| Dealer (`P_DEALER_DESC`) | Mandatory | Text / list | 500 | Dealer look-up (LV_DEALER) | Dealer name | Sub-type selected | Must not be blank | *"Dealer can not be Blank)"* |
| Location (`P_LOC`) | Mandatory | List | N/A | City/Location look-up (LV_CITY) | Location code | Dealer selected | Required for invoice lookup | N/A |
| Contract Month (`P_CONTRACT_MONTH`) | Conditional - monthly sub-types | List | 400 | Dynamic month list | Month-year label | Monthly Financial Year confirmed | Must not be blank for monthly sub-types | *"Contract Month can not be Blank)"* |
| Monthly Financial Year (`FINANCIAL_YEAR1`) | Conditional - monthly sub-types | List | 50 | Financial Year list (LV_FIN) | Financial year | Monthly sub-type | Must not be blank | *"Financial Year can not be Blank)"* |
| Quarter (`QUARTER`) | Conditional - Tariff | List | N/A | N/A | Q1 / Q2 / Q3 / Q4 | Tariff sub-type | Must not be blank for Tariff | *"Quarter can not be Blank)"* |
| Tariff Financial Year (`FINANCIAL_YEAR`) | Conditional - Tariff | List | N/A | Financial Year look-up (LV_FINANCIAL_YEAR) | Financial year | Quarter selected | Must not be blank for Tariff | *"Financial Year can not be Blank)"* |
| Dealer Number (`P_DEALER`) | Auto-populated | Numeric | 5 | N/A | Dealer code | Dealer selected via look-up | System-set from dealer look-up | N/A |
| Report Name (`REPORT_NAME`) | Auto-populated | Text | 2000 | N/A | vr_ewinv / vr_ccpinv / vr_ccfinv | Invoice found | Set by system | N/A |
| File Name / Parameters (`FILENAME`) | Auto-populated | Text | 4000 | N/A | Report parameter string | Report configured | Set by system | N/A |

---

---

#### Requirement ID: BR-012

**Requirement Title:** Workshop Annexure Export to Excel

**Business Description:**
When the user clicks the Workshop Annexure button (available for EW Commission and Incentive sub-types under the Extended Warranty programme, and for CCP Commission and Incentive sub-types under the CCP Inspection programme), the system retrieves the detailed invoice-line data for the selected period and dealer from the relevant commission detail view, formats it as a comma-separated file with a fixed set of columns, saves the file on the server, and opens it in the user's browser. This gives the service advisor a downloadable spreadsheet of the underlying invoice data for workshop-level reconciliation.

**Actors:** Service Advisor / Reporting User

**Preconditions:**
- The programme type is EW with sub-type Commission, Incentive, SAWA, or Extension; or the programme type is CCP with sub-type Commission or Incentive.
- The reporting period (Contract Month) and dealer/location have been selected.

**Main Flow:**

**Step 1 - Data query built and Excel file generated for EW programme types**
For EW Commission, Incentive, SAWA, or Extension sub-types, the system builds a query against the EW commission detail views joining header and detail records for the selected Contract Month, dealer group, and invoice type. The query selects region, month, dealer name, location, city, sold-from, dealer code, GST number, invoice number, invoice date, basic amount, CGST amount, SGST amount, IGST amount, and total amount. The result is exported to a CSV file with a unique filename (based on the logged-in user's identifier and the current date and time). The first row of the file contains the column header labels.

*Procedures called:*
- **VIEW_EXCEL_REP** ([SP-006](#SP-006--VIEW_EXCEL_REP)) - VIEW_EXCEL_REP - executes the data query using an in-memory record group, iterates through the result rows, writes each row to a text file on the server, transfers the file to the user's browser, and cleans up the temporary record group. Displays informational messages if the file path contains spaces or if the row count exceeds 65,535.
    * **Step 1** - Populate an in-memory record group from the supplied data query using the list-item population utility.
    * **Step 2** - Open a text file on the server at the specified path for writing.
    * **Step 3** - Write the header row with fixed column labels to the file.
    * **Step 4** - Iterate through each record group row; write it as a comma-separated line to the file; stop after 65,535 rows if the data exceeds that limit.
    * **Step 5** - Close the text file and release the in-memory record group.
    * **Step 6** - Open the generated file in the user's browser using the web document display function.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| File path does not contain spaces | File path check - VIEW_EXCEL_REP [SP-006] | When the Excel file is about to be saved | Warns the user if the target path contains spaces, which would prevent saving at the intended location | *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."* (informational; file stored at fallback path) |
| Row count within Excel limit | Row count check - VIEW_EXCEL_REP [SP-006] | When the data is being written to the file | Informs the user if the data exceeds the maximum row limit for the format | *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."* (informational; file truncated) |

*Business outcomes (errors, warnings, success, and status):*
- **BR-012-IC-01** - File path contains spaces - *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."* - file is saved to the C drive fallback location.
- **BR-012-IC-02** - Data exceeds Excel row limit - *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."* - file is generated with the first 65,535 data rows.

**Step 2 - Data query built and Excel file generated for CCP programme types**
For CCP Commission and Incentive sub-types, the process is identical to Step 1 but the query is run against the CCP commission detail views instead of the EW views.

*Business Scenarios - How the annexure data source differs by programme type*

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **EW - Commission, Incentive, SAWA, or Extension sub-types** | Data retrieved from the EW commission detail views (VH_EW_COMM_DTL / VD_EW_COMM_DTL); file generated using the EW-filtered query. |
| **CCP - Commission or Incentive sub-types** | Data retrieved from the CCP commission detail views (VH_CCP_COMM_DTL / VD_CCP_COMM_DTL); file generated using the CCP-filtered query. |

**Alternative Flows:**
- **BR-012-AF-01** - (from Step 1/Step 2) The button is pressed with a programme type or sub-type combination that is not EW-Commission/Incentive/SAWA/Extension or CCP-Commission/Incentive: no action is taken (the outer `IF` condition is not met and neither branch executes).

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Programme Type (`EW_CCP`) | Mandatory | Radio group | N/A | N/A | EW / CCP | Screen open | Must be EW or CCP to trigger the relevant export branch | No action if neither branch condition is met |
| Invoice Sub-Type (`P_EW`) | Mandatory | Radio group | N/A | N/A | C / I / S / X (EW); C / I (CCP) | Programme type selected | Must match an eligible sub-type for the export to proceed | No action for non-eligible sub-types |
| Contract Month (`P_CONTRACT_MONTH`) | Mandatory | List | 400 | Dynamic month list | Month-year label | Monthly Financial Year confirmed | Used as the period filter in the data query | N/A |
| Internal Query Text (`NB_TEXT`) | Auto-populated | Text | 4000 | N/A | Dynamically built SQL query string | Query construction complete | System-set; not user-editable | N/A |

---

---

#### Requirement ID: BR-013

**Requirement Title:** Form Reset and Default State Restoration

**Business Description:**
When the user presses the clear-form keyboard shortcut, the screen clears all currently entered values without saving any changes. After clearing, the system restores the default Report Description from the session context and resets the date-period display fields to the current financial year's start and end years. The quarterly-period fields (Quarter and Tariff Financial Year) are hidden and disabled, while the monthly-period fields (Monthly Financial Year and Contract Month) are made visible and enabled, returning the screen to its default layout ready for a fresh report selection. The Save toolbar button commits any pending changes and then immediately clears the screen to the same default state. The Cancel toolbar button clears the screen after first confirming with the user if any unsaved changes are present, then resets the period-field visibility to the same monthly-reporting default.

**Actors:** Service Advisor / Reporting User

**Preconditions:**
- The EW/CCP Invoice Report screen is open with values entered.

**Main Flow:**

**Step 1 - Form cleared without saving**
The system discards all values currently entered on the screen without prompting for confirmation or saving. This ensures no partial or incorrect input is accidentally retained.

**Step 2 - Report Description restored from session context**
The Report Description field is repopulated from the session-level default value, restoring the screen's title/description to its standard state.

**Step 3 - Financial year display values restored from session context**
The system reads the financial year start and end dates from the session context variables and reconstructs the displayed financial year label (formatted as `YYYY-YYYY`) for the period display field.

**Step 4 - Screen layout reset to monthly-period default**
The Quarter and Tariff Financial Year fields are set to hidden and disabled. The Monthly Financial Year and Contract Month fields are set to visible and enabled. This returns the screen to its default layout, consistent with the typical monthly-reporting workflow.

**Step 5 - Save toolbar button commits pending changes then clears the screen**
When the user clicks the Save button on the toolbar, the system commits all pending changes to the database (`COMMIT_FORM`), then immediately clears the screen using the same full-clear sequence as Steps 1-4 (`DO_KEY('CLEAR_FORM')`), leaving the screen in its default ready state for a fresh entry.

**Step 6 - Cancel toolbar button clears the screen with unsaved-data confirmation**
When the user clicks the Cancel button on the toolbar, the system first checks whether the Cancel button is currently enabled (`PB_BLK.PB_CANCEL`). If it is enabled and the form has unsaved changes (form status is `CHANGED`), the system presents the confirmation message *"Entered data will not be Saved"* via `GENERAL.ASK_CONFIRM`. If the user confirms (response = 1), the screen is cleared using `DO_KEY('CLEAR_FORM')`. If the user declines, no action is taken and the entered data is preserved. If the form has no unsaved changes, the screen is cleared immediately without prompting. After clearing (regardless of path taken), the quarterly-period fields (Quarter and Tariff Financial Year) are hidden and disabled, and the monthly-period fields (Monthly Financial Year and Contract Month) are made visible and enabled, restoring the default layout.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Unsaved changes check before cancel | Form status check (`SYSTEM.FORM_STATUS = 'CHANGED'`) - FT_CANCEL | When the user clicks the Cancel toolbar button and the form has pending changes | Prevents accidental loss of entered data by requiring explicit confirmation before clearing | If the user declines the prompt, the screen retains its current values and no clear action occurs |

*Business outcomes (errors, warnings, success, and status):*
- **BR-013-SM-01** - Save button: pending changes committed and screen cleared to default state.
- **BR-013-WS-01** - Cancel button with unsaved changes: *"Entered data will not be Saved"* confirmation presented; if confirmed, screen is cleared; if declined, screen retains current values.
- **BR-013-SM-02** - Cancel button with no unsaved changes: screen cleared immediately to default state without prompting.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Report Description (`REPORT_DESC`) | Auto-populated | Text | 200 | N/A | Session default description | Form cleared | Restored from session context on clear | N/A |
| Financial Year display (`FINANCIAL_YEAR`) | Auto-populated | Text | N/A | N/A | YYYY-YYYY constructed from session dates | Form cleared | Derived from session financial year start/end variables | N/A |

---

---

#### Requirement ID: BR-014

**Requirement Title:** Form Exit and Session Context Cleanup

**Business Description:**
When the user presses the exit keyboard shortcut, the screen closes immediately without prompting to save any unsaved changes. At the same time, the system clears the session-level module and client identifiers that were registered when the screen was opened, ensuring no residual tracking information remains associated with this module after the user has left.

**Actors:** Service Advisor / Reporting User

**Preconditions:**
- The EW/CCP Invoice Report screen is open.

**Main Flow:**

**Step 1 - Screen closed without saving**
The system immediately closes the EW/CCP Invoice Report screen, discarding any unsaved entries without prompting the user for confirmation.

**Step 2 - Session module identity cleared**
The database session's module and client-information identifiers, which were set when the screen was opened, are reset to empty values so that monitoring tools no longer associate this session's subsequent activity with the EW/CCP Invoice Report module.

---

---

#### Requirement ID: BR-015

**Requirement Title:** LOV-Driven Field Navigation

**Business Description:**
When the user presses the keyboard shortcut to open a look-up list on any field that has one configured, the system opens the relevant list of values directly and, if the user makes a selection, automatically advances the cursor to the next field. If the field under the cursor has no look-up list configured, the key press has no effect. This provides a consistent shortcut for picking values from look-up lists without requiring the user to click a dedicated button.

**Actors:** Service Advisor / Reporting User

**Preconditions:**
- The EW/CCP Invoice Report screen is open and the cursor is positioned on a field.

**Main Flow:**

**Step 1 - Look-up list name retrieved for the current field**
The system reads the name of the look-up list (if any) that is configured for the field currently under the cursor.

**Step 2 - Look-up list opened if one is configured**
If a look-up list name was found, the system opens that list at a standard screen position (200 columns, 120 rows offset). If the user selects a value from the list, the cursor automatically moves to the next field. If the field has no look-up list configured, no action is taken.

**Alternative Flows:**
- **BR-015-AF-01** - (from Step 1) No look-up list is configured for the current field: the key press is ignored and the cursor remains on the current field.

---

---

#### Requirement ID: BR-016

**Requirement Title:** Toolbar Button Action Gating - Disabled Save, Blocked Insert, and Guarded Delete

**Business Description:**
The EW/CCP Invoice Report screen enforces specific rules for each toolbar action button. The save keyboard shortcut has been intentionally disabled as a no-op because this is a report-parameter screen with no records to save. The Insert toolbar button is explicitly blocked: pressing it displays a clear error message telling the user the action is not permitted here. The Delete toolbar button is active only when the cursor is positioned on the programme-master data block; if conditions are met, the user is asked to confirm before the record is deleted. The List toolbar button opens the look-up list for the current field when one is available, mirroring the behaviour of the standard LOV shortcut key. The Print toolbar button is a placeholder with no active print logic implemented.

**Actors:** Service Advisor / Reporting User

**Preconditions:**
- The EW/CCP Invoice Report screen is open.

**Main Flow:**

**Step 1 - Save key pressed; no action taken**
When the user presses the keyboard shortcut normally used to save, the system performs no action. This trigger is present in the form as a deliberate no-op (COMMENTED OUT / INACTIVE - does not execute as a business save; the trigger body is `NULL`).

*Note: The KEY-COMMIT trigger is inactive (`inactive: True`) and executes `NULL`, confirming that the save action is intentionally disabled on this screen.*

**Step 2 - Insert toolbar button pressed; operation blocked with error message**
When the user clicks the Insert toolbar button, the system checks whether the Insert button is currently enabled (`PB_BLK.PB_INSERT`). If it is enabled, the system displays the error message *"This Operation Cannot be performed Here"* via `GENERAL.DISP_TEXT`, informing the user that record insertion is not supported on this screen. If the button is not enabled, no action is taken.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Insert action not permitted on this screen | Enabled-state check on `PB_BLK.PB_INSERT` - FT_INSERT | When the user clicks the Insert toolbar button | Prevents the user from attempting to insert records on a report-parameter screen where insertion is not applicable | *"This Operation Cannot be performed Here"* is displayed; no insert action proceeds |

*Business outcomes (errors, warnings, success, and status):*
- **BR-016-ES-01** - Insert button clicked while enabled: *"This Operation Cannot be performed Here"*; no insert action is taken.

**Step 3 - Delete toolbar button pressed; guarded deletion with user confirmation**
When the user clicks the Delete toolbar button, the system checks whether the Delete button is currently enabled (`PB_BLK.PB_DEL`) and whether the cursor is positioned on the programme-master data block (`B_GM_PROGRAM_MASTER`). If both conditions are met, form-level validation is temporarily suspended, the cursor is moved to the programme-master block, and the system presents the confirmation message *"Are you sure to Delete?"* via `GENERAL.ASK_CONFIRM`. If the user confirms (response = 1), the current record is deleted. If the user declines, no deletion occurs. After the confirmation step, form-level validation is re-enabled regardless of the user's choice. If the button is not enabled or the cursor is not on the programme-master block, no action is taken.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Delete confirmation required | Enabled-state and block check on `PB_BLK.PB_DEL` / `B_GM_PROGRAM_MASTER` - FT_DEL | When the user clicks the Delete toolbar button | Prevents accidental deletion of a programme-master record by requiring explicit user confirmation | If the user declines the confirmation, the record is not deleted; form validation is re-enabled |

*Business outcomes (errors, warnings, success, and status):*
- **BR-016-WS-01** - Delete button active, user confirms: *"Are you sure to Delete?"* confirmed; the programme-master record is deleted.
- **BR-016-WS-02** - Delete button active, user declines: *"Are you sure to Delete?"* declined; no record is deleted.

**Step 4 - List toolbar button pressed; look-up list opened for current field**
When the user clicks the List toolbar button, the system checks whether the List button is currently enabled (`PB_BLK.PB_LIST`). If it is enabled, the standard list-of-values action (`DO_KEY('LIST_VALUES')`) is invoked, opening the configured look-up list for the field currently under the cursor. If the button is not enabled, no action is taken.

**Step 5 - Print toolbar button pressed; no active print logic**
When the user clicks the Print toolbar button, the system checks whether the Print button is currently enabled (`PB_BLK.PB_PRINT`). The print code is a placeholder (`NULL`) with no implemented logic; regardless of button state, no print action is performed.

---

---

#### Requirement ID: BR-017

**Requirement Title:** WebUtil Infrastructure Initialization and Custom Event Routing

**Business Description:**
The EW/CCP Invoice Report screen uses Oracle WebUtil, an infrastructure component that enables file transfer and other client-side capabilities from within the browser-based form. When the WebUtil panel area receives focus or a button within it is pressed, the system hides the WebUtil beans UI (a technical artefact not intended for end users) and advances focus to the main report area. When any of the WebUtil function-group items receive a custom platform event, the event is forwarded to the central WebUtil event handler for processing. These behaviors are entirely infrastructure-level and are not directly visible to or controllable by the end user.

**Actors:** System (automatic WebUtil infrastructure)

**Preconditions:**
- The EW/CCP Invoice Report screen is open and the WebUtil component has been loaded.

**Main Flow:**

**Step 1 - WebUtil panel button pressed; beans hidden and focus advanced**
If the cursor is in the WebUtil panel area and the button within it is activated, the system hides the WebUtil beans from view and moves the cursor to the next block (the main report area), keeping the WebUtil infrastructure invisible to the user.

*Procedures called:*
- **WEBUTIL_CORE.SHOWBEANS** ([SP-087](#SP-087--WEBUTIL_CORE.SHOWBEANS)) - WEBUTIL_CORE.SHOWBEANS - called with a `false` argument to hide the WebUtil beans component from the screen.
    * **Step 1** - Receive the show/hide flag (false = hide).
    * **Step 2** - Apply the visibility setting to all WebUtil bean area items on the form.

**Step 2 - Custom platform events routed to WebUtil handler**
When any of the WebUtil function-group items (Client Info, File, Host, Session, File Transfer, OLE, C API, Browser) receive a custom item event from the platform, the event name and parameters are forwarded to the central WebUtil custom-event handler for processing. This routing covers all eight WebUtil function groups and requires no user interaction.

*Procedures called:*
- **WEBUTIL_CORE.CUSTOMEVENTHANDLER** ([SP-086](#SP-086--WEBUTIL_CORE.CUSTOMEVENTHANDLER)) - WEBUTIL_CORE.CUSTOMEVENTHANDLER - receives the custom event name and parameters from the platform and dispatches them to the appropriate WebUtil handler routine.
    * **Step 1** - Receive the custom event name and its associated parameters from the WebUtil function-group item that fired.
    * **Step 2** - Dispatch the event and parameters to the appropriate WebUtil internal handler for processing.

---

---

#### Requirement ID: BR-018

**Requirement Title:** Record Validation Before Save (COMMENTED OUT / INACTIVE - does not execute)

**Business Description:**
A programme unit for validating mandatory fields on the main screen before saving a record was defined in the form but has been fully commented out and does not execute. If re-enabled, it would check that required fields such as plate number, model year, and test-drive date are filled before allowing a save. Currently this logic is not active and has no effect on the user experience.

**Actors:** N/A (inactive - does not execute)

**Preconditions:**
- This requirement is inactive. The programme unit `VALIDATE_CN_MAIN` is fully commented out in the form code (COMMENTED OUT / INACTIVE - does not execute).

**Main Flow:**

**Step 1 - Field mandatory checks (COMMENTED OUT / INACTIVE - does not execute)**
This programme unit would have checked that several named fields are not blank before allowing a save action to proceed. Because the unit is entirely commented out, none of these checks execute and the user is never prompted by this routine.

---

---

#### Requirement ID: BR-019

**Requirement Title:** Record Deletion Check (COMMENTED OUT / INACTIVE - does not execute)

**Business Description:**
A programme unit for checking whether a record can safely be deleted was defined in the form but has been fully commented out and does not execute. If re-enabled, it would query whether any dependent records exist before allowing a deletion. Currently this logic is not active and has no effect on the user experience.

**Actors:** N/A (inactive - does not execute)

**Preconditions:**
- This requirement is inactive. The programme unit `CHECK_BEFORE_DELETE` executes `NULL` (COMMENTED OUT / INACTIVE - does not execute).

**Main Flow:**

**Step 1 - Dependent-record check before deletion (COMMENTED OUT / INACTIVE - does not execute)**
This programme unit would have queried the database to determine whether records dependent on the item being deleted exist, and if so, displayed an error to block the deletion. Because the unit body is a `NULL` statement (the actual logic is commented out), no check is performed and no message is shown.

---

## 5. Business Rules Catalogue

| Rule ID | Rule Name | Rule Type | Business Requirement ID | Condition | Action | Business Impact |
| ------- | --------- | --------- | ----------------------- | --------- | ------ | --------------- |
| BRC-001 | Date Value Must Be Valid | Validation | BR-002 | An entered date value is not a recognised calendar date | Show *"Entered Date is not valid Date"* and block the entry | Prevents invalid dates from being used as report parameters, ensuring accurate period filtering |
| BRC-002 | Date Format Must Be DD-MM-YYYY | Validation | BR-002 | A date has been entered in a format other than DD-MM-YYYY | Show *"Enter the Date in the proper format (DD-MM-YYYY)"* and block the entry | Ensures all date inputs conform to the required format, avoiding misinterpreted dates |
| BRC-003 | Numeric Fields Reject Non-Numeric Input | Validation | BR-002 | Text or special characters are entered in a field that accepts numeric values only | Show *"Characters/Special Characters are not allowed here, enter the numeric value"* and block the entry | Protects numeric fields from invalid input that could cause report errors |
| BRC-004 | Concurrent Update Lock | Constraint | BR-002 | A record being modified has already been updated by another user session | Show *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*, roll back pending changes, and stop the operation | Prevents data loss from concurrent edits by forcing the user to re-query the current record state before retrying |
| BRC-005 | Referential Integrity Constraint | Constraint | BR-002 | A save or delete action violates a database referential-integrity rule (dependent records exist) | Raise the business error E0088 and stop the operation | Prevents orphaned or inconsistent data by blocking actions that would break record dependencies |
| BRC-006 | EW Programme Shows Extension and SAWA Commission Sections | Derivation | BR-004 | The user selects the Extended Warranty programme type | Make the EW Extension and SAWA Commission sections visible on the screen | Ensures the user can access EW-specific options only when the EW programme is selected |
| BRC-007 | CCP Programme Hides Extension and SAWA Commission Sections | Derivation | BR-004 | The user selects the CCP Inspection programme type | Hide the EW Extension and SAWA Commission sections from the screen | Keeps the screen uncluttered by hiding options that do not apply to the CCP programme |
| BRC-008 | Monthly Sub-Type Shows Monthly Period Fields | Derivation | BR-005 | The user selects a monthly-reporting invoice sub-type (Commission, Dealer-directed, Incentive, Vehicle-based, SAWA, or Extension) | Hide and disable the Quarter and Tariff Financial Year fields; show and enable the Monthly Financial Year and Contract Month fields | Ensures the user is presented only with the period fields relevant to monthly reporting |
| BRC-009 | Tariff Sub-Type Shows Quarterly Period Fields | Derivation | BR-005 | The user selects the Tariff invoice sub-type | Hide and disable the Monthly Financial Year and Contract Month fields; show and enable the Quarter and Tariff Financial Year fields | Ensures the user is presented only with the period fields relevant to tariff/quarterly reporting |
| BRC-010 | Sub-Type Change Clears Period and Dealer Fields | Derivation | BR-005 | The user changes the invoice sub-type selection | Clear the Quarter, Tariff Financial Year, Monthly Financial Year, Contract Month, Dealer, and City/Location fields | Prevents stale period or dealer values from a previous sub-type being carried over into a new report parameter set |
| BRC-011 | Monthly Financial Year Selection Clears Contract Month | Derivation | BR-006 | The user confirms a new value in the Monthly Financial Year field | Clear the Contract Month field and rebuild the Contract Month list with the twelve months of the newly selected financial year | Ensures the Contract Month list always shows only the months relevant to the currently selected financial year |
| BRC-012 | Contract Month List Populated from Financial Year | Derivation | BR-006 | A Monthly Financial Year is confirmed | Populate the Contract Month drop-down with the twelve months (April through March) of the selected financial year | Provides the user with a correct and complete set of selectable months for the chosen year |
| BRC-013 | Quarter Selection Required for Tariff Reports | Validation | BR-007 | The user navigates away from or changes the Quarter field while the Tariff sub-type is selected, and the Quarter field is blank | Show *"Quarter can not be Blank)"* and return focus to the Quarter field | Ensures the quarterly period parameter is always provided before the user can proceed to the financial year selection |
| BRC-014 | Tariff Financial Year Required After Quarter Selection | Validation | BR-007 | The user navigates away from the Tariff Financial Year field and it is blank | Show *"Financial Year can not be Blank)"* and return focus to the Financial Year field | Ensures both period parameters (Quarter and Financial Year) are set before the user can proceed to the report destination |
| BRC-015 | Quarter Change Clears Financial Year and Derives End-Month | Derivation | BR-007 | The user selects or changes the Quarter value | Clear the Tariff Financial Year field and derive the quarter's end-month number (Q1 -> 06, Q2 -> 09, Q3 -> 12, Q4 -> 03) for the report parameter | Ensures the Financial Year is always re-selected after a quarter change and the correct end-month is used in the report parameters |
| BRC-016 | Dealer Is Mandatory Before Period Selection | Validation | BR-008 | The user navigates away from the Dealer field without selecting a dealer | Show *"Dealer can not be Blank)"* and return focus to the Dealer field | Ensures a dealer is always identified before period parameters are entered, preventing reports from being run without a dealer selection |
| BRC-017 | Contract Month Must Be Provided Before Dealer Field Is Entered | Validation | BR-009 | The cursor is about to enter the Dealer field but no Contract Month has been selected | Show *"Contract Month can not be Blank)"* and redirect focus to the Contract Month field | Ensures the reporting period is established before the user can select a dealer, maintaining logical parameter-entry order |
| BRC-018 | All Mandatory Report Parameters Required to View Invoice | Validation | BR-010 | The View Invoice button is clicked and one or more mandatory parameters (Dealer, period fields) are blank | Show the appropriate blank-field message and stop the report | Prevents the report engine from being called with incomplete parameters, avoiding failed or misleading report output |
| BRC-019 | Invoice Record Must Exist for Selected Parameters | Validation | BR-010, BR-011 | The report or digital-sign action is initiated but no invoice record is found for the selected dealer, location, period, and sub-type | Show *"CCP INVOICE NUMBER NOT FOUND"* or *"EW INVOICE NUMBER NOT FOUND."* and stop the action | Ensures the system does not attempt to generate a report or apply a digital signature for a period or dealer combination that has no invoice on record |
| BRC-020 | E-Invoice QR Code Must Be Generated Before Digital Signing (e-invoice-mandatory dealers only) | Validation | BR-011 | Digital signing is requested for an invoice whose QR code has not yet been generated, and the dealer is subject to the e-invoicing requirement | Display the appropriate status message (*"QR Code generation for B2B customer in process. Please try after 10 mins."*, *"Please upload data in E-invoice Upload Screen under Service Tab. "*, or the dynamic failure message) and stop the signing action | Ensures compliance with GST e-invoicing rules by blocking digital signing until the QR code is confirmed as generated |
| BRC-021 | Digital Signing Permitted Only Within 20-Day Window | Validation | BR-011 | Digital signing is requested but the invoice date is more than the configured number of days (default 20) in the past | Show *"Digital Sign only Allowed till 20th day from Invoice date. "* and stop the signing action | Enforces the business rule that invoices may only be digitally signed within the permitted period after issue |
| BRC-022 | Digital-Signing Configuration Must Be Present | Validation | BR-011 | Digital signing is requested but the local file path, server file path, or signing command is not configured in the application settings | Show the appropriate configuration-missing message and stop the signing action | Prevents incomplete or failed signing attempts caused by missing configuration, protecting file integrity |
| BRC-023 | Workshop Annexure Available Only for Eligible Sub-Types | Authorization | BR-012 | The Workshop Annexure button is pressed for a programme type / sub-type combination that is not EW-Commission/Incentive/SAWA/Extension or CCP-Commission/Incentive | No action is taken | Limits the annexure export to invoice types where the underlying workshop commission data is present and relevant |
| BRC-024 | Excel Export Row Count Capped at 65,535 | Constraint | BR-012 | The data set for the Excel export exceeds 65,535 rows | Truncate the output to 65,535 rows and show *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."* | Ensures the generated file remains within the row limit of the legacy Excel format, preventing a corrupt or unusable output file |
| BRC-025 | Save Action Disabled on Report-Parameter Screen | Constraint | BR-016 | The user presses the save keyboard shortcut on the EW/CCP Invoice Report screen | No action is taken | Prevents accidental save attempts on a screen that contains no persistable user records; the form is a report-parameter entry screen only |

**Total Business Rules Identified: 25**

---

## 6. Data Requirements

*The VR_EWINV form captures report-selection parameters that are used to generate EW (Extended Warranty) and CCP Inspection commission invoice reports; it reads reference data from dealer, financial-year, and city look-ups; and it updates invoice commission-detail records when digital signatures are applied.*

### 6.1 Business Entities and Relationships

*The form references two commission-detail tables (EW and CCP) for invoice lookup and digital-signature recording, and two corresponding commission-header/detail view pairs for the workshop annexure export.*

#### EW Commission Detail - VD_EW_COMM_DTL

The EW Commission Detail table holds one record per Extended Warranty commission invoice line, identified by dealer, location, transaction month, and invoice type. The form reads this table to find the invoice number and related e-invoice status when the user generates or digitally signs an EW invoice report, and updates it to record the digital-signature status, signed-file path, and signing date when a successful digital signature is applied.

#### CCP Commission Detail - VD_CCP_COMM_DTL

The CCP Commission Detail table holds one record per CCP Inspection commission invoice line, identified by dealer, location, transaction month, and invoice type. The form reads this table to find the invoice number and related e-invoice status when the user generates or digitally signs a CCP invoice report, and updates it to record the digital-signature status, signed-file path, and signing date when a successful digital signature is applied.

#### Entity Relationships

The EW and CCP Commission Detail tables each hold the authoritative invoice record for their respective programmes. For the workshop annexure export, a corresponding commission-header view (VH_EW_COMM_DTL or VH_CCP_COMM_DTL) is joined to the detail table on transaction date, GST number, and invoice type to produce the line-level annexure data. The e-invoice tracking table (SH_EINVOICE) is keyed on invoice module, invoice type, parent group, dealer, location, and invoice number, linking each EW or CCP invoice record to its e-invoice status when the e-invoicing requirement applies.

```
VD_EW_COMM_DTL (EW Commission Detail)
        └── SH_EINVOICE (E-Invoice Tracking - EWC module)   <- joined on dealer/loc/inv_num

VD_CCP_COMM_DTL (CCP Commission Detail)
        └── SH_EINVOICE (E-Invoice Tracking - ECC module)   <- joined on dealer/loc/inv_num
```

### 6.2 Data Capture Requirements

*The form captures report-selection parameters entered by the user (programme type, invoice sub-type, dealer, location, and reporting period) before generating the invoice report or applying a digital signature; no new commission records are created by this form.*

#### Report Parameter Selection (Service Advisor - before running a report)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Programme Type (`EW_CCP`) | Yes | Selects whether the invoice relates to the Extended Warranty or CCP Inspection programme; controls which commission detail table is queried and which report file is used | Must be one of the available radio options; selection also toggles visibility of the EW Extension and SAWA Commission sections |
| Invoice Sub-Type (`P_EW`) | Yes | Identifies the specific invoice sub-type within the chosen programme (e.g. Commission, Incentive, Tariff) | Must match a supported sub-type; selection drives whether monthly period or quarterly period fields are shown |
| Dealer (`P_DEALER_DESC`) | Yes | The name of the dealer for whom the invoice is being generated or signed; used to filter the commission detail record | Must not be blank before the user can proceed to period selection; validated on navigation away from the field |
| Dealer Code (`P_DEALER`) | Auto-Populated | The numeric code that uniquely identifies the selected dealer within the system; populated from the Dealer look-up | Auto-filled from the Dealer look-up (LV_DEALER); not entered directly by the user |
| Location (`P_CITY_DESC`, `P_CITY`, `P_LOC`) | Yes | The dealer location/outlet for which the invoice is being generated; used together with the dealer code to uniquely identify the commission record | Selected via the City/Location look-up (LV_CITY); required for the invoice lookup |
| Contract Month (`P_CONTRACT_MONTH`) | Conditional | The month for which the commission invoice is being generated; required for all monthly-reporting sub-types; list is rebuilt each time the Monthly Financial Year changes | Must not be blank for monthly sub-types; validated before the Dealer field can be entered; populated from a dynamically built list of the twelve months of the selected financial year |
| Monthly Financial Year (`FINANCIAL_YEAR1`) | Conditional | The financial year used to determine which Contract Months are available; required for monthly-reporting sub-types | Must not be blank for monthly sub-types; triggers rebuilding of the Contract Month list on confirmation |
| Quarter (`QUARTER`) | Conditional | The fiscal quarter (Q1-Q4) for which the Tariff invoice is being generated; required when the sub-type is Tariff | Must not be blank for Tariff sub-type; validated on list change and on navigation away from the field |
| Tariff Financial Year (`FINANCIAL_YEAR`) | Conditional | The financial year used together with the selected quarter to define the Tariff reporting period | Must not be blank for Tariff sub-type; validated when the look-up list is closed and when the user navigates away from the field |
| Report Destination (`P_DES_TYPE`) | Yes | Specifies how the report output should be delivered (e.g. screen/browser) | Required before the report is run; user-selectable |
| File Name / Parameters (`FILENAME`) | Auto-Populated | The assembled report parameter string passed to the report engine; populated by the system when the report is configured | Set by the system; not entered by the user |

#### Session and Non-Database Parameters

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Application Log Flag (`APP_LOG` global) | Auto-Populated | Session flag indicating whether performance logging is active; if set to 'Y', the performance timer is started when the form opens | Read from session context at form open; not user-editable |
| Report Description (`REPORT_DESC` / global) | Auto-Populated | Default description label for the report screen; restored from the session context when the form is cleared | Set from the session-level default on form clear; displayed on screen |
| Parent Group (`PARENT_GROUP` global) | Auto-Populated | The dealer group identifier for the logged-in user's context; used to scope all look-up and data queries to the correct dealer group | Carried from the session context; not user-editable |
| Principal (`PRINCIPAL` global) | Auto-Populated | The principal/brand identifier for the logged-in user's session; used to filter report parameters and configuration lookups | Carried from the session context; not user-editable |
| User ID (`USERID` global) | Auto-Populated | The system identifier of the logged-in user; used in constructing unique export file names and in report parameter lookup | Carried from the session context; not user-editable |
| Report Server (`REP_SERVER` global) | Auto-Populated | The name of the report server to which the report request is submitted | Carried from the session context; not user-editable |
| User Type (`P_USER_TYPE` parameter) | Auto-Populated | Indicates whether the user is a Head Office user or a dealer user; controls the scope of the Dealer/Zone look-up available to the user | Passed as a form parameter at launch; not entered by the user |

### 6.3 Reference Data

*Lists the master and configuration data look-ups referenced by this form.*

| Reference Data | Business Purpose | Used When |
| :--- | :--- | :--- |
| Dealer look-up (`LV_DEALER` / `RG_DEALER`) | Provides the list of dealers available to the user for selection as the invoice recipient | When the user opens or searches the Dealer field |
| City / Location look-up (`LV_CITY` / `RG_CITY`) | Provides the list of locations for the selected dealer group, plus an "All Locations" option | When the user opens the City/Location field |
| Financial Year look-up (`LV_FINANCIAL_YEAR` / `RG_FINANCIAL_YEAR`) | Provides available financial years for Tariff-period reporting, filtered to open financial periods | When the user opens the Tariff Financial Year field (Tariff sub-type) |
| Financial Year list - monthly (`LV_FIN` / `RG_FIN`) | Provides available financial years for monthly-period reporting | When the user opens the Monthly Financial Year field (monthly sub-types) |
| Region look-up (`RG_REGION`) | Provides the list of regions accessible to the logged-in user, used for location scoping | When the region filter is populated (used in zone/region look-up procedures) |
| Report configuration (`ED_REPORTS`) | Stores the report parameter definitions (parameter names, types, defaults) for each application ID and principal; used to build the report parameter string | When a report is run (View Invoice or Digital Sign) |
| Application configuration list (`AM_LIST`) | Stores system-level configuration values used at runtime, including: local file path for digital signing (`FILE_PATH / JCBDL`), server file path for signed files (`FILE_PATH / JCBDS`), and the maximum allowed digital-signing window in days (`EW_DSIGN_ALLOW_DAYS / DSIGN`) | When the Digital Sign button is pressed for applicable invoice types |
| Signing command configuration (`AM_LIST_RANGE`) | Stores the command string used to invoke the digital-signature tool on the client machine (`CRI_DIGI_CMD / CMD`), scoped by principal and active date range | When the Digital Sign button generates a new unsigned PDF to be signed |
| Financial year master for dealer (`FM_COMPANY`) | Provides the current financial year for the selected dealer and location, used to organise the server-side directory for signed files | During digital-sign file preparation |
| E-invoice tracking (`SH_EINVOICE`) | Records the current QR code and IRN generation status for each invoice, scoped by module (EWC/ECC), type, dealer, location, and invoice number; read to check readiness before digital signing | When the Digital Sign button is pressed for e-invoice-mandatory dealers |
| Dealer location parameters (`AM_DEALER_LOC_PARAM`) | Stores the e-invoicing turnover-threshold flag (`EINV_500_YN`) for each dealer location, determining whether the QR readiness check applies | When the Digital Sign button is pressed |
| Dealer location master (`AM_DEALER_LOC`) | Stores the dealer category (e.g. MUL) and other dealer attributes; used during QR readiness check to determine message routing | When the Digital Sign button is pressed |

### 6.4 Data Lifecycle

*Describes how records are created, updated, and saved within this form's evidenced behaviour.*

**Creation**

- This form does not create new commission or invoice records. All invoice records already exist in the EW and CCP commission detail tables prior to this form being opened.
- The workshop annexure export generates a new comma-separated text file on the server each time the Workshop Annexure button is pressed; the file is uniquely named using the user ID and current timestamp.

**Updates**

- When a digital signature is successfully applied, the system updates the matching record in the EW Commission Detail (`VD_EW_COMM_DTL`) or CCP Commission Detail (`VD_CCP_COMM_DTL`) table - setting the digital-signature applied flag to "Y", recording the path to the signed file, and recording the signing date. This update occurs within the `CALL_REPORT` procedure, called from the Digitally Sign button.
- No other data updates are performed by this form.

**Save and Commit**

- The save keyboard shortcut is intentionally disabled on this form (the KEY-COMMIT trigger executes `NULL`). There is no user-initiated commit action.
- The only database commit is issued automatically after a successful digital-signature upload and record update within the `CALL_REPORT` procedure (triggered by the Digitally Sign button). This commit is automatic, not user-initiated.

**Retention and Audit**

- The digital-signature update records the signing date (`EW_DIGI_SIGN_DATE` / equivalent CCP column) on the commission detail record. No further archival or purge policy is evidenced in this form's code.

---

### 6.5 Excel Output Columns

Excel download columns produced by this form, with when each Excel is produced (report / principal path), filters that limit which rows are included, and the database source for each value. Column sets vary by export path (for example app_id, principal, and enquiry-date mode); the rows below are evidenced layouts, not a guaranteed list for every combination. Blank Table/Database means the physical column was not proven in source.

| # | What the user selects on screen | Excel column name | When this Excel is produced | Table name | Database column | Logic |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | EW CCP, EW | Region |  | VH_EW_COMM_DTL | REGION_CD | Region code read directly from VH.REGION_CD on VH_EW_COMM_DTL (EW branch) / VH_CCP_COMM_DTL (CCP branch) for the selected contract month. |
| 2 | EW CCP, EW | Month |  | VH_EW_COMM_DTL | TRAN_DATE | Month label derived as TO_CHAR(VH.TRAN_DATE,'MON''YY') from VH_EW_COMM_DTL (EW branch) / VH_CCP_COMM_DTL (CCP branch); physical source column is TRAN_DATE. |
| 3 | EW CCP, EW | Dealer Name |  | VH_EW_COMM_DTL | DEALER_NAME | Dealer name read from VH.DEALER_NAME on VH_EW_COMM_DTL (EW branch) / VH_CCP_COMM_DTL (CCP branch); commas stripped via REPLACE before export. |
| 4 | EW CCP, EW | Location |  | VH_EW_COMM_DTL | LOC_DESC | Location description read from VH.LOC_DESC on VH_EW_COMM_DTL (EW branch) / VH_CCP_COMM_DTL (CCP branch); commas stripped via REPLACE before export. |
| 5 | EW CCP, EW | City |  | VH_EW_COMM_DTL | CITY_NAME | City name read directly from VH.CITY_NAME on VH_EW_COMM_DTL (EW branch) / VH_CCP_COMM_DTL (CCP branch) for the selected contract month. |
| 6 | EW CCP, EW | Policy Sold From |  | VH_EW_COMM_DTL | SOLD_FROM | Indicates the channel or location from which the policy was sold; read from VH.SOLD_FROM on VH_EW_COMM_DTL (EW branch) / VH_CCP_COMM_DTL (CCP branch). |
| 7 | EW CCP, EW | Dealer Code |  | VH_EW_COMM_DTL | MUL_DEALER_CD | Dealer code read from VH.MUL_DEALER_CD on VH_EW_COMM_DTL (EW branch) / VH_CCP_COMM_DTL (CCP branch) for the selected contract month. |
| 8 | EW CCP, EW | GST Number |  | VH_EW_COMM_DTL | GST_NUM | Dealer GST registration number read from VH.GST_NUM on VH_EW_COMM_DTL (EW branch) / VH_CCP_COMM_DTL (CCP branch); also used as a join key with VD. |
| 9 | EW CCP, EW | Invoice Number |  | VH_EW_COMM_DTL | INV_NUM | Invoice number read from VH.INV_NUM on VH_EW_COMM_DTL (EW branch) / VH_CCP_COMM_DTL (CCP branch); rows with NULL INV_NUM are excluded by the WHERE clause. |
| 10 | EW CCP, EW | Invoice Date |  | VH_EW_COMM_DTL | INV_DATE | Invoice date read directly from VH.INV_DATE on VH_EW_COMM_DTL (EW branch) / VH_CCP_COMM_DTL (CCP branch) for the selected contract month. |
| 11 | EW CCP, EW | Basic Amount |  | VH_EW_COMM_DTL | TOTAL_COMM_AMT | Basic (commission) amount sourced from VH.TOTAL_COMM_AMT on VH_EW_COMM_DTL (EW branch) / VH_CCP_COMM_DTL (CCP branch); aliased as TOTAL_AMT in the inner subquery. |
| 12 | EW CCP, EW | CGST Amount |  | VH_EW_COMM_DTL | CGST_AMT | Central GST component read from VH.CGST_AMT on VH_EW_COMM_DTL (EW branch) / VH_CCP_COMM_DTL (CCP branch) for the selected contract month. |
| 13 | EW CCP, EW | SGST Amount |  | VH_EW_COMM_DTL | SGST_AMT | State GST component read from VH.SGST_AMT on VH_EW_COMM_DTL (EW branch) / VH_CCP_COMM_DTL (CCP branch) for the selected contract month. |
| 14 | EW CCP, EW | IGST Amount |  | VH_EW_COMM_DTL | IGST_AMT | Integrated GST component read from VH.IGST_AMT on VH_EW_COMM_DTL (EW branch) / VH_CCP_COMM_DTL (CCP branch) for the selected contract month. |
| 15 | EW CCP, EW | Total Amount |  | VH_EW_COMM_DTL | TOTAL_AMOUNT | Derived arithmetic total computed as VH.TOTAL_COMM_AMT + VH.CGST_AMT + VH.SGST_AMT + VH.IGST_AMT from VH_EW_COMM_DTL (EW branch) / VH_CCP_COMM_DTL (CCP branch); no single physical column. |

## 7. Glossary

*Definitions of terms, abbreviations, and acronyms used throughout this document.*

The following table defines key terms, acronyms, and abbreviations used throughout this Business Requirements Document.

| Term | Definition | Aliases | Related Terms |
| :--- | :--- | :--- | :--- |
| Annexure | A supplementary commission detail file (CSV/Excel) downloadable from the form showing the full breakdown of commission entries for the selected period and dealer | - | Commission Detail, CSV |
| App ID | Application identifier stored in the form (e.g. `vr_ewinv` or `vr_ccpinv`) used to look up the corresponding Oracle Reports parameter definition from the report definition table | - | Report Name, ED_REPORTS |
| CB_BLK | Control block in the vr_ewinv form that holds all parameter entry fields; it has no database table binding and performs no DML | - | Block |
| CCP | Credit Card Processing - the product type for CCP commission invoices generated and printed from the vr_ewinv form | - | Commission Invoice, EW |
| Commission Invoice | A financial document generated for a dealer summarising Extended Warranty or CCP commission amounts for a billing period | - | EW, CCP, Invoice |
| Contract Month | A calendar month within a financial year selected as the billing period for monthly commission invoice reports | - | Financial Year, Period |
| DMS | Dealer Management System - the integrated software platform for dealership operations within which the vr_ewinv form operates | - | System |
| DPL | Shared Oracle Forms PL/SQL program library (`DPL.pld`) attached to the form; provides reusable routines such as DISP_TEXT and RAISE_ERROR | - | PLD, Shared Library |
| EINV_500_YN | A dealer-level flag indicating whether the dealer is eligible for e-invoice generation; checked before allowing digital signature report printing | - | E-Invoice, Digital Signature, IRN, QR Code |
| E-Invoice | Electronic invoice - a government-mandated digital invoice format; for this form, the QR code and IRN must be generated before a digitally signed commission invoice can be printed | - | IRN, QR Code, SH_EINVOICE |
| EW | Extended Warranty - one of the two commission invoice product types handled by the vr_ewinv form | - | Commission Invoice, CCP |
| Financial Year | A twelve-month accounting period (April to March) used as the primary period grouping for commission invoice reporting | Fin Year | Contract Month, Quarter |
| IRN | Invoice Reference Number - a unique number assigned to an e-invoice by the government portal; required before a digitally signed commission invoice can be printed | - | QR Code, E-Invoice |
| LOV | List of Values - a popup selection list in Oracle Forms used to help the user pick valid values (e.g. dealer, financial year, city) | Dropdown, Picklist | Record Group |
| OLB | Object Library (`.olb`) - a shared Oracle Forms library from which the form inherits visual attributes, property classes, and object groups | - | DPL |
| Oracle Reports | The Oracle reporting engine used to generate the commission invoice PDF from parameters submitted by the vr_ewinv form | - | Report Server, RDF |
| PB_ANNEX | Annexure button on the form - clicking it generates and downloads the commission detail CSV for the selected period and dealer | - | Annexure |
| PB_DIGI_SIG | Digital Signature button on the form - clicking it validates e-invoice status and generates the digitally signed commission invoice | - | Digital Signature, E-Invoice |
| PB_REP | Report button on the form - clicking it submits report parameters to the Oracle Reports engine for standard (non-signed) invoice printing | - | Oracle Reports |
| PCK | Oracle PL/SQL package (`.pck` file) - a compiled database package invoked from the form | - | DPL, Package |
| PLD | PL/SQL Library (`.pld` file) - a shared Oracle Forms program library attached to the form at runtime | - | DPL, webutil |
| Principal | The manufacturer or financial institution whose products (EW or CCP) are managed by the dealers; used to scope dealer lists, financial year queries, and report parameters | - | Dealer, Parent Group |
| QR Code | A two-dimensional bar code embedded in an e-invoice; its generation is confirmed in the e-invoice status table before a digitally signed invoice is printed | - | IRN, E-Invoice |
| Quarter | A three-month period within a financial year (Q1-Q4) used as the billing period for quarterly EW commission invoice reports | - | Financial Year, Contract Month |
| Record Group | An Oracle Forms data structure holding the result of a SQL query; used to populate LOV lists for financial year, dealer, city, and region selection | - | LOV |
| Region | A geographic grouping of dealer locations; used to scope the dealer and zone selection lists for regional and head-office users | - | Zone, Dealer |
| Report Server | The Oracle Reports server process that receives report job submissions from the form and generates the output PDF | - | Oracle Reports |
| SAWA Commission | An additional commission component displayed for EW product type when the EW_CCP radio is set to EW | - | EW, Commission Invoice |
| vr_ewinv | The Oracle Forms module name for the Extended Warranty and CCP Commission Invoice screen | VR_EWINV | Commission Invoice, EW, CCP |
| WebUtil | An Oracle Forms extension library (`webutil.pld`) providing client-side utilities including file transfer between the application server and the user's browser | - | PLD, File Transfer |
| Zone | A sub-region grouping used by the form to filter zone-level commission invoice data; zones are populated based on the user's principal, region, and user type | - | Region, Dealer |

---

---

## 8. Technical Inventory

*Complete inventory of Oracle Forms components including blocks, items, triggers, canvases, and global variables.*

### 8.1 Form Architecture

**Form Module Details:**

- Form Name: vr_ewinv (VR_EWINV)
- Form Module XML Title: MODULE2
- Oracle Forms Version: 12c (Module version 122010400)
- Parent Object Library: DPL.olb (PC_FORM property class)
- Attached Libraries: WEBUTIL (webutil.olb), D2KWUTIL, DPL (DPL.pld program library)
- First Navigation Block: -
- Console Window: WEBUTIL_HIDDEN_WINDOW - WebUtil Information
- Compile Dependencies: Requires DPL.olb, DPL.pld, WEBUTIL.olb, menu.mmx, database packages PK_PART_SEARCH_NEW
- Source artifacts: `vr_ewinv_fmb.xml`; OLB `DPL.olb`; WEBUTIL (webutil.olb); D2KWUTIL; DPL (DPL.pld program library)

### 8.1.1 Global Variables

| Global Variable | Data Type | Set Location | Purpose |
| :--- | :--- | :--- | :--- |
| APP_ID | Char | Trigger | Application identifier used to retrieve report parameter definitions from ED_REPORTS for the current form session |
| APP_LOG | Char | Trigger | Application logging flag; when set to 'Y', starts a performance timer at form open |
| COMP_FA | Char | RecordGroup / Trigger | Company FA code used to filter financial year and dealer record groups |
| CURRENCY | Char | Trigger | Currency code for the current session, used to scope report and display formatting |
| CUR_DATE | Date | ProgramUnit | Current system date; referenced only from the inactive VALIDATE_CN_MAIN program unit - does not execute at runtime |
| DEALER | Char | RecordGroup / Trigger | Dealer map code for the current session, used to filter dealer and financial year lists |
| FIN_BEG | Char | Trigger | Financial year beginning date used to restore the financial year display on form clear |
| FIN_END | Char | Trigger | Financial year end date used to restore the financial year display on form clear |
| LOC_CD | Char | RecordGroup / Trigger | Location code for the current session, used to filter financial year and dealer records |
| PARENT_GROUP | Char | RecordGroup / Trigger | Parent group code used to scope record group queries to the current organisation |
| PRINCIPAL | Char | ProgramUnit / RecordGroup / Trigger | Principal map code used to filter report parameters and zone list queries |
| P_FIN_YR | Char | Trigger | Financial year parameter value set at runtime and passed to report submission logic |
| REPORT_DESC | Char | Trigger | Display description of the current report, restored to the form on clear |
| REPORT_NAME | Char | Trigger | Report module name stored globally so it can be restored or referenced across trigger contexts |
| REP_SERVER | Char | ProgramUnit / Trigger | Report server name used when submitting Oracle Reports to the print engine |
| USERID | Char | ProgramUnit / RecordGroup / Trigger | Logged-in user identifier used to filter region and zone access lists |
| USER_NAME | Char | Trigger | Display name of the logged-in user, used for labelling and context in report submissions |

### 8.1.2 Form Parameters

*All 4 ModuleParameter entries from vr_ewinv_fmb.xml.*

| Parameter | Data Type | Default | Description |
| :--- | :--- | :--- | :--- |
| P_USER_TYPE | Char | DLR | Controls the zone list population mode: 'DLR' for dealer user, 'MUL' for multi-location user; determines which region/zone filter is applied in LIST_POPULATE_ZONE |
| P_CHECK | Char | - | Reserved - not used in current form logic |
| P_REGION | Char | - | Incoming region code filter applied when the user type is 'DLR'; narrows the zone selection list to the specified region |
| P_USER_HORO | Char | - | Indicates Head Office ('HO') or Regional Office ('RO') user scope for zone list filtering in LIST_POPULATE_ZONE |

**Total Parameters:** 4

### 8.2 Blocks

| Block Name | Query Data Source | Records | Q/I/U/D | Key Mode | Master-Detail Relationship |
| :--- | :--- | :--- | :--- | :--- | :--- |
| CB_BLK | - | 1 | N/N/N/N | Default | - |
| WEBUTIL | - | 1 | N/N/N/N | Default | - |

**Total Blocks:** 2 business blocks

### 8.2.1 Block WhereClause and OrderByClause

*Block query scope from vr_ewinv_fmb.xml. **Description** explains filter and sort in business terms; **Order By** and **Where Clause** columns retain verbatim XML text for migration.*

| Block | Description | Order By (XML) | Where Clause (XML) |
| :--- | :--- | :--- | :--- |
| - | No blocks with WhereClause/OrderByClause in vr_ewinv_fmb.xml | - | - |

### 8.3 Items Summary

*Complete item inventory from `vr_ewinv_fmb.xml`.*

**Block counts:**

*Database / non-database counts derived from XML.*

| Block | Total Items | Database Items | Non-Database Items |
| :--- | ---: | ---: | ---: |
| CB_BLK | 33 | 0 | 33 |
| WEBUTIL | 9 | 0 | 9 |
| PB_BLK | 12 | 0 | 12 |
| CB_ERR | 1 | 0 | 1 |
| **Total** | **55** | **0** | **55** |

**Item detail (all 55 items):**

| Block | Item Name | DatabaseItem | Description |
| :--- | :--- | :--- | :--- |
| CB_BLK | NB_TEXT | false | Notification or informational text display label on the form |
| CB_BLK | LOC_DESC | false | Location description - display label for the selected location |
| CB_BLK | REPORT_DESC | false | Report description - display label showing the name of the selected report |
| CB_BLK | P_FOR_DESC | false | Format description - display label for the selected report format |
| CB_BLK | P_MONTHYEAR | false | Month-year display field derived from the selected contract month |
| CB_BLK | FINANCIAL_YEAR1 | false | Financial year selection field for monthly contract-based report types (C/F/I/V/S/X) |
| CB_BLK | P_CONTRACT_MONTH | false | Contract month selection list - populated dynamically based on the selected financial year |
| CB_BLK | P_DEALER_DESC | false | Dealer description - LOV-based field to select a dealer by name |
| CB_BLK | P_CITY_DESC | false | City description - display field showing the city for the selected dealer |
| CB_BLK | P_CITY | false | City code - LOV-based field to select the dealer city/location |
| CB_BLK | PB_DIGI_SIG | false | Digital Signature button - generates and prints the commission invoice with QR/IRN validation |
| CB_BLK | PB_REP | false | Report button - submits the selected report parameters and runs the Oracle Report |
| CB_BLK | P_QTR | false | Quarter number - internal numeric value derived from the selected quarter (Q1=1, Q2=4, etc.) |
| CB_BLK | P_FIN_YEAR | false | Financial year numeric value - derived from the selected financial year for quarterly reports |
| CB_BLK | P_QTR_YEAR | false | Quarter-year combined value used as a report parameter for quarterly report submissions |
| CB_BLK | YEAR | false | Year value derived from the selected financial year period |
| CB_BLK | QUARTER | false | Quarter selection list - Q1/Q2/Q3/Q4 for quarterly EW commission report type |
| CB_BLK | FINANCIAL_YEAR | false | Financial year selection field for quarterly EW report type (T) |
| CB_BLK | P_REPO_TYPE | false | Report type code - internal parameter identifying the report variant |
| CB_BLK | P_PARENT | false | Parent group code - passed as a report parameter to scope results to the current organisation |
| CB_BLK | P_DEALER | false | Dealer code - returned from the dealer LOV and passed as a report parameter |
| CB_BLK | P_LOC | false | Location code - passed as a report parameter to filter by the selected dealer location |
| CB_BLK | APP_ID | false | Application identifier - used to retrieve report parameter definitions from ED_REPORTS |
| CB_BLK | REPORT_NAME | false | Report module name - the Oracle Reports .rdf file name to execute |
| CB_BLK | REP_SERVER | false | Report server name - identifies the Oracle Reports server for job submission |
| CB_BLK | P_FOR_CD | false | Format code - report output format (e.g. PDF, HTML) passed to the report engine |
| CB_BLK | P_DLR | false | Dealer map code - internal parameter derived from the selected dealer LOV value |
| CB_BLK | P_DES_TYPE | false | Destination type - specifies the report output destination (cache/printer/file) |
| CB_BLK | FILENAME | false | Output file name - path and name of the generated report or CSV file on the server |
| CB_BLK | COPYRIGHT_DECLARATION | false | Copyright declaration display text shown on the form |
| CB_BLK | EW_CCP | false | Product type radio group - selects Extended Warranty (EW) or CCP commission invoice |
| CB_BLK | P_EW | false | Report sub-type radio group - selects report category (C/F/I/V/S/X for monthly, T for quarterly) |
| CB_BLK | PB_ANNEX | false | Annexure button - downloads the commission details as an Excel/CSV file |
| WEBUTIL | DUMMY | false | Dummy WebUtil button - initialises WebUtil bean display and navigates to the next block |
| WEBUTIL | WEBUTIL_CLIENTINFO_FUNCTIONS | false | WebUtil client information bean - handles client system info events |
| WEBUTIL | WEBUTIL_FILE_FUNCTIONS | false | WebUtil file functions bean - handles client file operation events |
| WEBUTIL | WEBUTIL_HOST_FUNCTIONS | false | WebUtil host functions bean - handles host command execution events |
| WEBUTIL | WEBUTIL_SESSION_FUNCTIONS | false | WebUtil session functions bean - handles session management events |
| WEBUTIL | WEBUTIL_FILETRANSFER_FUNCTIONS | false | WebUtil file transfer bean - handles file upload and download events |
| WEBUTIL | WEBUTIL_OLE_FUNCTIONS | false | WebUtil OLE functions bean - handles OLE automation events |
| WEBUTIL | WEBUTIL_C_API_FUNCTIONS | false | WebUtil C API functions bean - handles native C API call events |
| WEBUTIL | WEBUTIL_BROWSER_FUNCTIONS | false | WebUtil browser functions bean - handles browser interaction events |
| PB_BLK | PB_EXIT | false | Exit button (inherited from DPL.olb PB_BLK object group) - closes the current form |
| PB_BLK | PB_LIST | false | List button (inherited from DPL.olb PB_BLK object group) - invokes the LOV for the current item |
| PB_BLK | PB_INSERT | false | Insert button (inherited from DPL.olb PB_BLK object group) - inserts a new record; inactive in this read/report-only form |
| PB_BLK | PM_CONT | false | Continue button (inherited from DPL.olb PB_BLK object group) - navigates to the next step or block |
| PB_BLK | PB_DEL | false | Delete button (inherited from DPL.olb PB_BLK object group) - deletes the current record; inactive in this read/report-only form |
| PB_BLK | PB_CANCEL | false | Cancel button (inherited from DPL.olb PB_BLK object group) - cancels the current operation and clears pending changes |
| PB_BLK | PB_SAVE | false | Save button (inherited from DPL.olb PB_BLK object group) - commits the current record; inactive in this read/report-only form |
| PB_BLK | PB_PRINT | false | Print button (inherited from DPL.olb PB_BLK object group) - triggers the print action for the current report |
| PB_BLK | PB_CUT | false | Cut button (inherited from DPL.olb PB_BLK object group) - cuts the selected text from the current item |
| PB_BLK | PB_COPY | false | Copy button (inherited from DPL.olb PB_BLK object group) - copies the selected text from the current item |
| PB_BLK | PB_PASTE | false | Paste button (inherited from DPL.olb PB_BLK object group) - pastes clipboard text into the current item |
| PB_BLK | PB_ERR_EXIT | false | Error exit button (inherited from DPL.olb PB_BLK object group) - closes the error window and returns focus to the main canvas |
| CB_ERR | TXT_ERR | false | Error text display item (inherited from DPL.olb CB_ERR object group) - shows the current error message text in the WIN_ERR error window |

### 8.4 List of Values

| LOV Name | Title | Record Group | Attached Block.Item |
| :--- | :--- | :--- | :--- |
| LV_DEALER | Dealer Master | RG_DEALER | CB_BLK.P_DEALER_DESC |
| LV_CITY | Loc | RG_CITY | CB_BLK.P_CITY |
| LV_FINANCIAL_YEAR | Financial_Year | RG_FINANCIAL_YEAR | CB_BLK.FINANCIAL_YEAR |
| LV_FIN | Fin Year | RG_FIN | CB_BLK.FINANCIAL_YEAR1, CB_BLK.P_FIN_YEAR |

**Total LOVs:** 4

### 8.5 Alerts

| Alert Name | Title | Message Text | Calling Context |
| :--- | :--- | :--- | :--- |
| ALERT_BUT | Note | Please select valid region code and for code | Trigger: WHEN-BUTTON-PRESSED in CB_BLK.PB_REP; Trigger: WHEN-BUTTON-PRESSED in CB_BLK.PB_DIGI_SIG (via CALL_REPORT) |
| AL_PRINT | Print | (set at runtime) | Inherited from DPL.olb via object group; invoked by PB_BLK.PB_PRINT and DISP_TEXT print-path calls |
| AL_ERRINFO | Error | (set at runtime) | Inherited from DPL.olb via object group; invoked by DISP_TEXT (DPL) for error-type messages across triggers and program units |
| AL_NOTE | Note | (set at runtime) | Inherited from DPL.olb via object group; invoked by DISP_TEXT (DPL) for informational messages across triggers and program units |
| AL_CONFIRM | Caution | (set at runtime) | Inherited from DPL.olb via object group; invoked by GENERAL.ASK_CONFIRM for user confirmation dialogs |
| WEBUTIL_ERROR | - | (set at runtime) | Trigger: WHEN-BUTTON-PRESSED in WEBUTIL.DUMMY (via WebUtil_Core.ShowBeans) |

**Total Alerts:** 6

### 8.6 Program Units

*Authoritative catalogue of **13 form-local program units**. Database packages and standalone procedures are in **Section 15.2**; PLD shared-library routines are in **Section 18**.*

| Program Unit | Type | Calls | Description |
| :--- | :--- | :--- | :--- |
| VIEW_EXCEL_REP | Procedure | L_POP_LIST_ITEM, WEBUTIL_FILE_TRANSFER.URL_TO_CLIENT, WEBUTIL_HOST.HOST, AM_LIST (via query), TEXT_IO | Creates a dynamic record group from a supplied SQL query, writes the result set as a CSV file to the server, and opens the file in the browser for download |
| VALIDATE_CN_MAIN | Unknown | GENERAL.CHECK_NULL (DPL - commented), GENERAL.DISP_TEXT (DPL - commented) | **COMMENTED OUT / INACTIVE** - Legacy validation stub; entire body is commented out; no active business logic |
| CHECK_BEFORE_DELETE | Unknown | GENERAL.DISP_TEXT (DPL - commented) | **COMMENTED OUT / INACTIVE** - Empty stub; body is null; no active business logic |
| POPULATE_ERRORS | Package spec | None (package spec only) | Package specification placeholder - defines no active procedures; body is not implemented in this form |
| L_POPULATE | Procedure | ID_NULL (webutil), AM_LIST | Creates a list item from AM_LIST records filtered by principal; populates a named list item with code-description pairs |
| PR_REMOVE_ASCII_CHR | Procedure | GENERAL.DISP_TEXT (DPL), TEXT_IO | Reads a server-side file line by line and removes CHR(12) form-feed characters, writing a clean output file to a temporary path |
| PR_PASS_PARAM | Procedure | ED_REPORTS | Reads report parameter definitions from ED_REPORTS for the current app_id and principal; builds and returns the parameter string for Oracle Reports submission |
| LIST_POPULATE_ZONE | Procedure | GM_REGN, AM_USER_REGION, ID_NULL (webutil), DROP_RECGRP (DPL - inferred) | Dynamically builds a zone SQL query based on P_USER_TYPE and P_USER_HORO parameters; creates and populates a record group and list item with zone codes |
| POP_LIST_REGION | Procedure | RG_REGION (record group), ID_NULL (webutil) | Populates the region record group (RG_REGION) and the P_REGION_CD list item from the region query results |
| L_POP_LIST_ITEM | Procedure | ID_NULL (webutil) | Generic utility: drops and recreates a named record group from a supplied SQL query; caller must populate the associated list item separately |
| CALL_REPORT | Procedure | PR_PASS_PARAM, GENERAL.DISP_TEXT (DPL), Host (webutil), length (webutil), VD_CCP_COMM_DTL, VD_EW_COMM_DTL, AM_LIST, AM_LIST_RANGE, FM_COMPANY | Validates report parameters, resolves invoice numbers, builds Oracle Report parameter string via PR_PASS_PARAM, and submits the report to the Oracle Reports server; handles the digital-signature download path |
| DOWNLOAD_FILE | Procedure | WEBUTIL_FILE_TRANSFER.AS_TO_CLIENT, GENERAL.DISP_TEXT (DPL) | Transfers a generated report or CSV file from the application server to the client browser; optionally opens the file using client_host |
| UPLOAD_FILE | Procedure | WEBUTIL_FILE_TRANSFER.CLIENT_TO_AS | Uploads a file from the client machine to the application server; returns an error message in an OUT parameter if the transfer fails |

**Total Program Units:** 13

### 8.7 Triggers

**Item-Level Trigger Types (reference):**

| Trigger Name | Purpose |
| :--- | :--- |
| WHEN-VALIDATE-ITEM | Validates field when user leaves item |
| KEY-* | Keyboard actions - commit, exit, LOV, navigation |
| WHEN-NEW-BLOCK-INSTANCE | Initializes block on entry |
| WHEN-BUTTON-PRESSED | Executes button action |
| PRE-INSERT / POST-INSERT | Before/after record creation |
| WHEN-LIST-CHANGED | Dropdown selection changed |
| PRE-QUERY / POST-QUERY | Before/after query execution |
| WHEN-CHECKBOX-CHANGED | Checkbox toggled |
| WHEN-VALIDATE-RECORD | Validates entire record before leaving row |

**DPL library routines invoked from triggers and program units:**

| Routine | Type | Called From | Purpose |
| :--- | :--- | :--- | :--- |
| GENERAL.ASK_CONFIRM | Library routine | Form level, PB_BLK.PB_EXIT (inherited) | Displays a confirmation dialog to the user using the AL_CONFIRM alert; returns the user's button choice to the caller |
| GENERAL.CHECK_NULL | Library routine | ProgramUnit: VALIDATE_CN_MAIN (commented out) | **COMMENTED OUT / INACTIVE** - Validates that a required field is not null; raises FORM_TRIGGER_FAILURE with an error message if the value is empty |
| GENERAL.DISP_TEXT | Library routine | CB_BLK.FINANCIAL_YEAR, CB_BLK.PB_DIGI_SIG, CB_BLK.P_DEALER_DESC, CB_BLK.QUARTER, Form level, ProgramUnit: CALL_REPORT, ProgramUnit: CHECK_BEFORE_DELETE, ProgramUnit: DOWNLOAD_FILE, ProgramUnit: PR_REMOVE_ASCII_CHR, ProgramUnit: VALIDATE_CN_MAIN | Displays a title/message dialog box to the user using the AL_ERRINFO (error) or AL_NOTE (informational) alert |
| GENERAL.RAISE_ERROR | Library routine | Form level | Retrieves a message by error code and displays it as an error alert; raises FORM_TRIGGER_FAILURE for error-type messages |
| WEBUTIL_FILE_TRANSFER.AS_TO_CLIENT | Library routine | ProgramUnit: DOWNLOAD_FILE | Transfers a file from the application server to the client machine via the WebUtil file transfer bean |
| WEBUTIL_FILE_TRANSFER.CLIENT_TO_AS | Library routine | ProgramUnit: UPLOAD_FILE | Transfers a file from the client machine to the application server via the WebUtil file transfer bean |
| WEBUTIL_FILE_TRANSFER.URL_TO_CLIENT | Library routine | ProgramUnit: VIEW_EXCEL_REP | Downloads a file from a server URL directly to the client browser via the WebUtil file transfer bean |
| WEBUTIL_HOST.HOST | Library routine | ProgramUnit: VIEW_EXCEL_REP | Executes a host operating system command from the application server context via the WebUtil host bean |

### 8.7.1 Inactive / Commented-Out Trigger Register

*Triggers and field validations where XML source is `null;`, fully block-commented, or legacy code preserved but not executed. Do **not** migrate these as active business requirements.*

| Status | Block | Item | Trigger | Former behaviour (preserved in comments) | Disabled since / note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Inactive stub** | Form | - | KEY-COMMIT | Form commit action; no DML is performed as this is a read/report-only form | Body is `null;` - form intentionally prevents all commits; report parameter entry only |
| **Commented out** | Form | - | FT_SAVE | Inherited toolbar Save trigger; would have committed the current record to the database | Overridden at form level with commented-out body; DML not applicable to this report-only form |
| **Commented out** | PB_BLK | PB_EXIT | WHEN-BUTTON-PRESSED | Inherited exit button handler; would have called GENERAL.ASK_CONFIRM before closing the form | Body is commented out; exit behaviour delegated to the form-level KEY-EXIT trigger |

*Additional null-only or partially commented triggers exist on estimation and legacy blocks - see XML `TriggerText` starting with `null;` or `/*`.*

**Complete trigger inventory (46 business triggers):**
*vr_ewinv_fmb.xml contains Trigger elements.*

| Trigger Name | Block | Item | Called From / Context | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| ON-ERROR | Form | - | Form level | Translates Oracle Forms and Oracle error codes into user-friendly alert messages; handles FK violations, date validation errors, and unexpected SQL errors |
| ON-MESSAGE | Form | - | Form level | Suppresses or redirects specific Oracle Forms informational messages (40209, 40207) by displaying a custom error alert instead |
| KEY-EXIT | Form | - | Form level | Closes the form without validation and clears the Oracle DB application context for the session |
| KEY-LISTVAL | Form | - | Form level | Shows the LOV popup for the current item at a fixed screen position; advances to the next item when a value is selected |
| KEY-COMMIT | Form | - | Form level | **INACTIVE STUB** - body is null; no database commits are performed; this is a read/report-only form |
| KEY-CLRFRM | Form | - | Form level | Clears the form without validation and restores the report description and financial year display from session globals |
| KEY-OTHERS | Form | - | Form level (inherited) | Suppresses unhandled keystrokes at form level; inherited from DPL.olb object group |
| KEY-NEXT-ITEM | Form | - | Form level (inherited) | Navigates focus to the next item in tab order; inherited from DPL.olb object group |
| KEY-PREV-ITEM | Form | - | Form level (inherited) | Navigates focus to the previous item in tab order; inherited from DPL.olb object group |
| KEY-NXTBLK | Form | - | Form level (inherited) | Navigates focus to the next block; inherited from DPL.olb object group |
| KEY-PRVBLK | Form | - | Form level (inherited) | Navigates focus to the previous block; inherited from DPL.olb object group |
| KEY-DOWN | Form | - | Form level (inherited) | Moves focus down one record or item; inherited from DPL.olb object group |
| KEY-UP | Form | - | Form level (inherited) | Moves focus up one record or item; inherited from DPL.olb object group |
| FT_SAVE | Form | - | Form level (inherited) | **COMMENTED OUT** - Inherited toolbar Save trigger; overridden at form level; no DML performed in this report-only form |
| FT_CANCEL | Form | - | Form level (inherited) | Inherited toolbar Cancel trigger; cancels pending changes and returns the form to its previous state |
| FT_INSERT | Form | - | Form level (inherited) | Inherited toolbar Insert trigger; creates a new record in the current block; inactive in this report-only form |
| FT_DEL | Form | - | Form level (inherited) | Inherited toolbar Delete trigger; deletes the current record; inactive in this report-only form |
| FT_LIST | Form | - | Form level (inherited) | Inherited toolbar List trigger; invokes the LOV for the current item |
| FT_PRINT | Form | - | Form level (inherited) | Inherited toolbar Print trigger; initiates the print action for the current report output |
| WHEN-NEW-FORM-INSTANCE | Form | - | Form level (inherited) | Initialises the form on first load; sets globals, populates zone/region lists, and configures initial item visibility; inherited from DPL.olb object group |
| PRE-FORM | Form | - | Form level | Starts a performance timer if application logging is enabled; registers the module name in the Oracle DB application context |
| WHEN-VALIDATE-ITEM | CB_BLK | FINANCIAL_YEAR1 | CB_BLK.FINANCIAL_YEAR1 | Resets the contract month selection and dynamically repopulates the contract month list based on the financial year entered |
| KEY-NEXT-ITEM | CB_BLK | FINANCIAL_YEAR1 | CB_BLK.FINANCIAL_YEAR1 | Repopulates the contract month list when the user advances from the financial year field |
| KEY-NEXT-ITEM | CB_BLK | P_DEALER_DESC | CB_BLK.P_DEALER_DESC | Validates the dealer selection is not empty and navigates to the appropriate period field based on the selected report sub-type |
| WHEN-NEW-ITEM-INSTANCE | CB_BLK | P_DEALER_DESC | CB_BLK.P_DEALER_DESC | Validates that a contract month has been selected before focus moves to the dealer description field |
| WHEN-BUTTON-PRESSED | CB_BLK | PB_DIGI_SIG | CB_BLK.PB_DIGI_SIG | Validates e-invoice QR/IRN generation status for the selected dealer and period, then submits the commission invoice report with digital signature |
| WHEN-BUTTON-PRESSED | CB_BLK | PB_REP | CB_BLK.PB_REP | Submits the selected report parameters and runs the Oracle Report without digital signature |
| WHEN-LIST-CHANGED | CB_BLK | QUARTER | CB_BLK.QUARTER | Validates quarter selection for quarterly EW reports and calculates the corresponding financial year period values |
| KEY-NEXT-ITEM | CB_BLK | QUARTER | CB_BLK.QUARTER | Validates that a quarter is selected for quarterly report type before advancing to the next field |
| KEY-LISTVAL | CB_BLK | FINANCIAL_YEAR | CB_BLK.FINANCIAL_YEAR | Shows the financial year LOV for quarterly EW report type and calculates quarter/year parameters on selection |
| KEY-NEXT-ITEM | CB_BLK | FINANCIAL_YEAR | CB_BLK.FINANCIAL_YEAR | Validates that a financial year is selected for quarterly report type before advancing to the destination type field |
| WHEN-RADIO-CHANGED | CB_BLK | EW_CCP | CB_BLK.EW_CCP | Shows or hides the EW extension and SAWA commission fields based on whether EW or CCP product type is selected |
| WHEN-RADIO-CHANGED | CB_BLK | P_EW | CB_BLK.P_EW | Resets period selection fields and toggles the visible period controls between monthly (FINANCIAL_YEAR1/P_CONTRACT_MONTH) and quarterly (QUARTER/FINANCIAL_YEAR) based on the selected sub-type |
| WHEN-VALIDATE-ITEM | CB_BLK | P_EW | CB_BLK.P_EW | Enforces the correct period control visibility for the validated report sub-type without resetting existing values |
| WHEN-BUTTON-PRESSED | CB_BLK | PB_ANNEX | CB_BLK.PB_ANNEX | Builds a commission detail query for the selected dealer and period and downloads the result as an Excel/CSV annexure file |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EXIT | PB_BLK.PB_EXIT (inherited) | **COMMENTED OUT** - Inherited exit button handler; exit behaviour is delegated to the form-level KEY-EXIT trigger |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_LIST | PB_BLK.PB_LIST (inherited) | Inherited toolbar List button handler; invokes the LOV for the currently focused item |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_INSERT | PB_BLK.PB_INSERT (inherited) | Inherited toolbar Insert button handler; creates a new record; inactive in this report-only form |
| WHEN-BUTTON-PRESSED | PB_BLK | PM_CONT | PB_BLK.PM_CONT (inherited) | Inherited toolbar Continue button handler; navigates to the next step or block in the form flow |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_DEL | PB_BLK.PB_DEL (inherited) | Inherited toolbar Delete button handler; deletes the current record; inactive in this report-only form |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CANCEL | PB_BLK.PB_CANCEL (inherited) | Inherited toolbar Cancel button handler; cancels pending changes and clears the current operation |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SAVE | PB_BLK.PB_SAVE (inherited) | Inherited toolbar Save button handler; commits the current record; inactive in this report-only form |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PRINT | PB_BLK.PB_PRINT (inherited) | Inherited toolbar Print button handler; initiates the print action via the AL_PRINT alert path |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CUT | PB_BLK.PB_CUT (inherited) | Inherited toolbar Cut button handler; cuts the selected text from the currently focused item |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_COPY | PB_BLK.PB_COPY (inherited) | Inherited toolbar Copy button handler; copies the selected text from the currently focused item |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PASTE | PB_BLK.PB_PASTE (inherited) | Inherited toolbar Paste button handler; pastes clipboard text into the currently focused item |

### 8.8 Canvas and Window Inventory

**Windows:**

| Window | Title | Primary Canvas |
| :--- | :--- | :--- |
| WIN_ERR | - | CN_ERR |
| WN_MAIN | EW CCP Commission / Incentive Invoice Details (Rel 1.1.0) | CN_MAIN |

**Canvases:**

| Canvas | Type | Window |
| :--- | :--- | :--- |
| CN_ERR | Content | WIN_ERR |
| CN_MAIN | Content | WN_MAIN |
| CN_TOOL | Content | WN_MAIN |

### 8.9 Editors

*No editors found in vr_ewinv_fmb.xml.*

### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

#### 8.10.1 Visual Attributes (form-defined)

*3 VisualAttribute elements defined at form level (not inherited from DPL.olb).*

| Visual Attribute |
| :--- |
| VA_MANDATORY |
| VA_DEFAULT |
| VA_DISPLAY |

#### 8.10.2 Property Classes (form-defined)

*Form-local PropertyClass elements.*

*No form-local property classes found in vr_ewinv_fmb.xml.*

#### 8.10.3 Object Groups

*Object groups bundle inherited triggers and visual objects applied form-wide at runtime.*

| Object Group Child | Type |
| :--- | :--- |
| KEY-OTHERS | Inherited trigger |
| KEY-NEXT-ITEM | Inherited trigger |
| KEY-PREV-ITEM | Inherited trigger |
| KEY-NXTBLK | Inherited trigger |
| KEY-PRVBLK | Inherited trigger |
| KEY-DOWN | Inherited trigger |
| KEY-UP | Inherited trigger |
| CN_ERR | Inherited canvas |
| VA_DISP | Inherited visualattribute |
| CB_ERR | Inherited block |
| VA_LOV | Inherited visualattribute |
| VA_TRNI_DT | Inherited visualattribute |
| VA_TITLE | Inherited visualattribute |
| VA_ALERT | Inherited visualattribute |
| VA_BUTN | Inherited visualattribute |
| VA_TEXT | Inherited visualattribute |
| VA_MPROMPT | Inherited visualattribute |
| VA_OPROMPT | Inherited visualattribute |
| VA_MAND | Inherited visualattribute |
| VA_NUM | Inherited visualattribute |
| VA_DESC | Inherited visualattribute |
| VA_ICONIC_BUTN | Inherited visualattribute |
| VA_RB | Inherited visualattribute |
| VA_CB | Inherited visualattribute |
| WN_MAIN | Inherited window |
| POP_MAIN | Inherited trigger |
| CN_MAIN | Inherited canvas |
| CN_TOOL | Inherited canvas |
| PB_BLK | Inherited block |
| AL_ERRINFO | Inherited alert |
| AL_NOTE | Inherited alert |
| AL_CONFIRM | Inherited alert |
| WIN_ERR | Inherited window |
| AL_PRINT | Inherited alert |
| FT_SAVE | Inherited trigger |
| FT_CANCEL | Inherited trigger |
| FT_INSERT | Inherited trigger |
| FT_DEL | Inherited trigger |
| FT_LIST | Inherited trigger |
| FT_PRINT | Inherited trigger |
| WHEN-NEW-FORM-INSTANCE | Inherited trigger |

### 8.11 DataSourceColumn Inventory

*No DataSourceColumns found in vr_ewinv_fmb.xml.*

## 9. Object Library

*The form references the DPL object library (`DPL_olb.xml`) for visual attribute and property class definitions. The DPL library contains 15 Visual Attributes and 27 Property Classes organised in two tabs. The form module itself inherits the `PC_FORM` property class from DPL, and individual form items inherit their property class settings from DPL through the standard Oracle Forms subclassing mechanism. Three Visual Attributes are also defined locally on the form (`VA_MANDATORY`, `VA_DEFAULT`, `VA_DISPLAY`) and two Object Groups (`WEBUTIL`, `OG_GROUP`) are referenced.*

Source OLB file(s): DPL_olb.xml

| Name | Type | Description | Used By (count) | Sample Items |
| ---- | ---- | ----------- | --------------- | ------------ |
| VA_CB | VisualAttribute | Visual attribute for check-box items | referenced | Form items with check-box presentation |
| VA_RB | VisualAttribute | Visual attribute for radio-button items | referenced | EW_CCP and P_EW radio group items |
| VA_ICONIC_BUTN | VisualAttribute | Visual attribute for iconic push-button items | referenced | Iconic toolbar buttons |
| VA_DESC | VisualAttribute | Visual attribute for description/display text fields | referenced | Display and description text fields |
| VA_NUM | VisualAttribute | Visual attribute for numeric input fields | referenced | Numeric data fields |
| VA_MAND | VisualAttribute | Visual attribute for mandatory input fields | referenced | Mandatory fields such as Dealer, Location |
| VA_OPROMPT | VisualAttribute | Visual attribute for optional field prompts | referenced | Optional field label prompts |
| VA_MPROMPT | VisualAttribute | Visual attribute for mandatory field prompts | referenced | Mandatory field label prompts |
| VA_TEXT | VisualAttribute | Visual attribute for standard text input fields | referenced | General text input items across the form |
| VA_BUTN | VisualAttribute | Visual attribute for standard push-button items | referenced | View Invoice, Digitally Sign, Workshop Annexure buttons |
| VA_ALERT | VisualAttribute | Visual attribute for alert dialog items | referenced | System alert dialogs |
| VA_TITLE | VisualAttribute | Visual attribute for title/header display items | referenced | Screen title areas |
| VA_TRNI_DT | VisualAttribute | Visual attribute for transaction date display items | referenced | Date display items |
| VA_LOV | VisualAttribute | Visual attribute for list-of-values items | referenced | LOV-backed field items |
| VA_DISP | VisualAttribute | Visual attribute for read-only display items | referenced | Read-only display fields |
| PC_DESC | PropertyClass | Property class for description text items | referenced | Description and label text items |
| PC_SC_DATE | PropertyClass | Property class for date items (PROPERTY CLASS FOR DATE) | referenced | Date selection fields |
| PC_TITLE | PropertyClass | Property class for title text items (PROPERTY CLASS FOR TEXT ITEMS) | referenced | Screen title and heading text items |
| PC_FORMAT | PropertyClass | Property class for formatted text items (PROPERTY CLASS FOR TEXT ITEMS) | referenced | Formatted text display items |
| PC_MR_BLK | PropertyClass | Property class for master-record blocks | referenced | Master block configuration |
| PC_DISP | PropertyClass | Property class for display-only text items (PROPERTY CLASS FOR TEXT ITEMS) | referenced | Read-only display fields |
| PC_LOV | PropertyClass | Property class for list-of-values items (PROPERTY CLASS FOR LIST OF VALUES) | referenced | LV_DEALER, LV_CITY, LV_FIN, LV_FINANCIAL_YEAR LOV objects |
| PC_FORM | PropertyClass | Property class for the form module itself | 1 | VR_EWINV form module |
| PC_DISP_DATE | PropertyClass | Property class for display-only date items (PROPERTY CLASS FOR TEXT ITEMS) | referenced | Read-only date display fields |
| PC_DISP_NUM | PropertyClass | Property class for display-only numeric items (PROPERTY CLASS FOR TEXT ITEMS) | referenced | Read-only numeric display fields |
| PC_DATE | PropertyClass | Property class for date input items (PROPERTY CLASS FOR DATE) | referenced | Editable date fields |
| PC_DTTIME | PropertyClass | Property class for date-and-time items (Property class for Date and Time) | referenced | Date-time combination fields |
| PC_CB | PropertyClass | Property class for check-box items | referenced | Check-box items |
| PC_ALERT | PropertyClass | Property class for alert dialog items | referenced | Alert dialogs |
| PC_MDATE | PropertyClass | Property class for mandatory date fields (PROPERTY CLASS FOR DATE) | referenced | Mandatory date input fields |
| PC_RB | PropertyClass | Property class for radio-button items | referenced | EW_CCP and P_EW radio-button items |
| PC_WIND | PropertyClass | Property class for windows (PROPERTY CLASS FOR WINDOWS) | referenced | Form windows |
| PC_CANV | PropertyClass | Property class for canvas items | referenced | Form canvases |
| PC_BUTN | PropertyClass | Property class for push-button items (PROPERTY CLASS FOR PUSH BUTTONS) | referenced | View Invoice (PB_REP), Digitally Sign (PB_DIGI_SIG), Workshop Annexure (PB_ANNEX) buttons |
| PC_TEXT | PropertyClass | Property class for standard text input items (PROPERTY CLASS FOR TEXT ITEMS) | referenced | Most text items in CB_BLK including Dealer, Location, Financial Year fields |
| PC_MTEXT | PropertyClass | Property class for mandatory text items (PROPERTY CLASS FOR TEXT ITEMS) | referenced | Mandatory text input fields |
| PC_UTEXT | PropertyClass | Property class for uppercase text items (PROPERTY CLASS FOR TEXT ITEMS) | referenced | Uppercase-forced text items |
| PC_MUTEXT | PropertyClass | Property class for mandatory uppercase text items (PROPERTY CLASS FOR TEXT ITEMS) | referenced | Mandatory uppercase text items |
| PC_NUM | PropertyClass | Property class for numeric items (PROPERTY CLASS FOR NUMERIC ITEMS) | referenced | Numeric input items |
| PC_MNUM | PropertyClass | Property class for mandatory numeric items (PROPERTY CLASS FOR NUMERIC ITEMS) | referenced | Mandatory numeric items |
| PC_ICONIC_BUTN | PropertyClass | Property class for iconic push-button items (PROPERTY CLASS FOR PUSH BUTTONS) | referenced | Iconic button items |
| PC_SCROLL | PropertyClass | Property class for scrollable items | referenced | Scrollable list or text items |
| VA_MANDATORY | VisualAttribute | Form-local visual attribute; sets background colour to "mand" for mandatory fields | referenced | P_DEALER_DESC, P_CITY_DESC (BackColor="mand") |
| VA_DEFAULT | VisualAttribute | Form-local visual attribute; sets background colour to "white" for default (non-mandatory) fields | referenced | Standard non-mandatory fields |
| VA_DISPLAY | VisualAttribute | Form-local visual attribute; sets background colour to "Display" for read-only display fields | referenced | Read-only display items |
| WEBUTIL | ObjectGroup | Oracle WebUtil object group; provides all items, canvases, windows, triggers, and visual attributes required to enable WebUtil client-side capabilities in the form (subclassed from the WEBUTIL library) | 1 | WEBUTIL block and its 9 function-item children, WEBUTIL_CANVAS canvas |
| OG_GROUP | ObjectGroup | Additional object group subclassed into the form | referenced | N/A |

---

## 10. Record Groups

*Lists all record groups, their LOV bindings, query logic, dynamic bindings, business purpose, and form usage.*

| Record Group | Type | Used By LOV | Display Column | Return Column | Dynamic Bindings | Purpose | Where Used |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| RG_FINANCIAL_YEAR | Query | LV_FINANCIAL_YEAR | ICRGGQ_0 | ICRGGQ_1 | No | Lists available financial years for the current dealer and company, used for monthly contract-based report selection | LV_FINANCIAL_YEAR -> CB_BLK.FINANCIAL_YEAR |
| RG_CITY | Query | LV_CITY | LOC_DESC | LOC_CD | No | Lists active dealer locations including an ALL LOC option for the current dealer, used to filter the report by city | LV_CITY -> CB_BLK.P_CITY |
| RG_REGION | Query | - | REGION_CD | - | No | Lists regions accessible to the logged-in service user filtered by principal, used to scope zone list population | - |
| RG_DEALER | Query | LV_DEALER | DEALER | DEALER_NAME | Yes - CB_BLK | Lists dealers that have CCP or EW commission invoice records for the selected contract month and product type | LV_DEALER -> CB_BLK.P_DEALER_DESC |
| RG_FIN | Query | LV_FIN | ICRGGQ_0 | ICRGGQ_1 | No | Lists available financial years for the current dealer and company, used for quarterly EW report period selection | LV_FIN -> CB_BLK.FINANCIAL_YEAR1, CB_BLK.P_FIN_YEAR |

**Total Record Groups:** 5

## 11. Referenced Database Objects

*Database tables, views, and objects accessed by the form.*

| Block | Base Table | Primary Key Item | Database Item |
| :--- | :--- | :--- | :--- |
| CB_BLK | - | - | No |

| Object | Schema | Used In | Description |
| :--- | :--- | :--- | :--- |
| `AM_DEALER_LOC` | - | RG_DEALER, Trigger WHEN-BUTTON-PRESSED | Dealer location master - dealer codes, names, and city information used to populate dealer selection lists and validate ECC invoice parameters |
| `AM_DEALER_LOC_PARAM` | - | Trigger WHEN-BUTTON-PRESSED | Dealer location parameter table - holds dealer-specific configuration values such as EINV_500_YN flag for e-invoice digital signature eligibility |
| `AM_LIST` | - | CALL_REPORT, L_POPULATE | Application list master - stores selectable items (e.g. report types, format codes) for list population in the form |
| `AM_LIST_RANGE` | - | CALL_REPORT | Application list range table - stores valid range codes for report type selection used in invoice report submission |
| `AM_USER_REGION` | - | RG_REGION | User region access table - maps logged-in users to the regions they are authorised to access, filtered by user type and principal |
| `DUAL` | - | CALL_REPORT, RG_CITY, Trigger KEY-NEXT-ITEM, Trigger WHEN-BUTTON-PRESSED, Trigger WHEN-NEW-FORM-INSTANCE, Trigger WHEN-VALIDATE-ITEM | Oracle system dual table - used in SELECT statements to generate single-row results such as the ALL LOC option in the city LOV |
| `ED_REPORTS` | - | PR_PASS_PARAM | Report parameter definition table - stores the Oracle Reports parameter list definitions keyed by application ID and principal, used to build the parameter string for report submission |
| `EH_REPORTS` | - | Trigger WHEN-NEW-FORM-INSTANCE | Report header/configuration table - queried during form initialisation to retrieve report metadata or access-control settings required before the form is ready for user interaction |
| `FM_COMPANY` | - | CALL_REPORT, RG_FIN, RG_FINANCIAL_YEAR | Company financial master - holds financial year records per dealer and company; used to populate financial year selection lists and retrieve company financial data for reports |
| `GM_REGN` | - | LIST_POPULATE_ZONE | Geographic master region table - stores region codes and descriptions used to build the zone selection list for multi-location users |
| `MULDMS.AM_DEALER_LOC` | - | RG_CITY | Dealer location table accessed via the MULDMS schema - supplies location codes and descriptions for the city LOV query |
| `SH_EINVOICE` | - | Trigger WHEN-BUTTON-PRESSED | E-invoice status table - holds QR code and IRN generation status for commission invoices, checked before allowing digital signature printing |
| `VD_CCP_COMM_DTL` | - | CALL_REPORT, RG_DEALER, Trigger WHEN-BUTTON-PRESSED | CCP commission detail table - stores commission invoice records for the CCP product type; used to filter eligible dealers and validate invoice status for report submission |
| `VD_EW_COMM_DTL` | - | CALL_REPORT, Trigger WHEN-BUTTON-PRESSED | Extended Warranty commission detail table - stores commission invoice records for the EW product type; used to validate invoice data and filter eligible dealers for EW reports |

**Total Referenced Objects:** 14

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure/Package Index

| Requirement ID | Procedure/Package | Purpose |
| -------------- | ----------------- | ------- |
| BR-001 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Registers the current database session under the invoice module identifier for monitoring |
| BR-001 | DBMS_APPLICATION_INFO.SET_MODULE | Sets the module name in the database session context for performance and audit tracking |
| BR-002 | GENERAL.RAISE_ERROR | Raises the predefined business-level error message for referential-integrity violations |
| BR-002, BR-003, BR-007, BR-008, BR-009, BR-010, BR-011 | GENERAL.DISP_TEXT | Displays targeted error or information messages to the user through the standard notification mechanism |
| BR-002 | GENERAL.ASK_CONFIRM | Displays a confirmation dialog and returns the user's choice; used to confirm cancellation or deletion actions |
| BR-006 | L_POP_LIST_ITEM | Dynamically rebuilds the Contract Month drop-down list based on the selected financial year |
| BR-010, BR-011 | CALL_REPORT | Validates report parameters, retrieves invoice details, configures and runs the report, and orchestrates the digital-signing workflow |
| BR-010, BR-011 | PR_PASS_PARAM | Assembles the report parameter string from the configuration table for the current application and principal |
| BR-011 | DOWNLOAD_FILE | Transfers the generated unsigned PDF from the server to the user's client machine for signing |
| BR-011 | UPLOAD_FILE | Transfers the locally-signed PDF back from the client machine to the server |
| BR-011 | WEBUTIL_HOST.HOST | Executes an operating-system command on the client machine; used in CALL_REPORT to open a downloaded report file |
| BR-011 | CLIENT_HOST | Invokes the digital-signature tool on the client machine using the configured command and deletes temporary files after signing |
| BR-011 | WEBUTIL_FILE_TRANSFER.AS_TO_CLIENT | Performs the server-to-client file transfer used by the DOWNLOAD_FILE procedure |
| BR-011 | WEBUTIL_FILE_TRANSFER.CLIENT_TO_AS | Performs the client-to-server file transfer used by the UPLOAD_FILE procedure |
| BR-012 | VIEW_EXCEL_REP | Executes the workshop annexure data query, writes the result to a CSV file, and opens it in the browser |
| BR-013 | L_POPULATE | Populates list items from the AM_LIST master table for a given list name and field |
| BR-013 | LIST_POPULATE_ZONE | Dynamically populates the zone or region record group and list based on user type and accessible regions |
| BR-013 | POP_LIST_REGION | Populates the region list item from the RG_REGION static record group |
| BR-014 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Clears the client-information session identifier on form exit |
| BR-014 | DBMS_APPLICATION_INFO.SET_MODULE | Clears the module-name session identifier on form exit |
| BR-017 | WEBUTIL_CORE.SHOWBEANS | Hides the WebUtil beans UI component from the form screen |
| BR-017 | WEBUTIL_CORE.CUSTOMEVENTHANDLER | Routes custom WebUtil platform events to the appropriate handler |
| - | WEBUTIL_C_API.ID_NULL | Returns TRUE when a Forms object handle is null or uninitialised; used before drop/create operations on record groups and list items |
| - | WEB.SHOW_DOCUMENT | Opens a specified URL or file path in the user's browser window |
| - | PR_REMOVE_ASCII_CHR | Strips special/non-printable ASCII characters from an Excel output file and opens the cleaned file in the browser |
| - | ADD_ERROR | Adds an error entry to the form-level error table managed by the POPULATE_ERRORS package infrastructure |
| - | ADD_EXTERNAL_ERRORS | Adds externally sourced errors into the form-level error stack |
| - | CLEAN_ERROR_STACK | Clears all entries from the form-level error stack |
| - | BOOLTOCHAR | Converts a PL/SQL BOOLEAN value to its VARCHAR2 character representation |
| - | DEBUGLOG | Writes a debug message to the form-level debug log |
| - | GET_ENVIRONMENT_STRING | Retrieves an environment variable value from the client or server context |
| - | READ_REGISTRY | Reads a Windows registry key value on the client machine |
| - | REGISTER_FUNCTION_CALL | Registers a WebUtil function call for asynchronous dispatch |
| - | SETDEBUG | Enables or disables debug-logging mode within the form session |
| - | STRIPDIRSEP | Strips trailing directory-separator characters from a file path string |
| - | WINDEBUG | Writes a debug string to the Windows debug output channel |
| - | D2KWUTIL.ATTEMPT_DLL_LOAD | Attempts to load a client-side DLL via the D2KWUTIL library |
| - | D2KWUTIL.D2KWUTIL_DEBUGSTRING | Writes a debug string through the D2KWUTIL client library |
| - | D2KWUTIL.D2KWUTIL_GETDOSENV | Retrieves a DOS/Windows environment variable value via the D2KWUTIL library |
| - | D2KWUTIL.D2KWUTIL_GETREGKEY | Reads a Windows registry key value via the D2KWUTIL library |
| - | D2KWUTIL.TRANSLATETYPE | Translates a D2KWUTIL internal type code to its string representation |

---

### 12.2 Procedure and Package Catalogue

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| GENERAL.DISP_TEXT | Package routine (DPL library) | ON-ERROR (form), ON-MESSAGE (form), KEY-NEXT-ITEM (CB_BLK.P_DEALER_DESC), WHEN-NEW-ITEM-INSTANCE (CB_BLK.P_DEALER_DESC), WHEN-LIST-CHANGED (CB_BLK.QUARTER), KEY-NEXT-ITEM (CB_BLK.QUARTER), KEY-LISTVAL (CB_BLK.FINANCIAL_YEAR), KEY-NEXT-ITEM (CB_BLK.FINANCIAL_YEAR), WHEN-BUTTON-PRESSED (CB_BLK.PB_DIGI_SIG), FT_INSERT (form), CALL_REPORT, DOWNLOAD_FILE, PR_REMOVE_ASCII_CHR | Displays a modal alert to the user with the supplied message text and title. Uses AL_ERRINFO for Error-titled messages and AL_NOTE for all other titles. Called throughout the form to show validation errors, user guidance messages, and informational notifications. |
| GENERAL.RAISE_ERROR | Package routine (DPL library) | ON-ERROR (form) | Looks up an error message by code and displays it as an error, note, or caution alert depending on the message type; raises FORM_TRIGGER_FAILURE after displaying error-type messages. Used for FK constraint violations (ORA-02292). |
| GENERAL.ASK_CONFIRM | Package routine (DPL library) | FT_CANCEL (form), FT_DEL (form) | Displays a confirmation dialog to the user with the supplied message and returns a numeric result indicating the user's choice. Used to prompt the user to confirm a cancellation or deletion action before proceeding. |
| DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Oracle built-in package routine | PRE-FORM (form), KEY-EXIT (form) | Sets or clears the database session client-information string for monitoring and auditing. |
| DBMS_APPLICATION_INFO.SET_MODULE | Oracle built-in package routine | PRE-FORM (form), KEY-EXIT (form) | Sets or clears the database session module-name string for performance monitoring. |
| CALL_REPORT | Form ProgramUnit (procedure) | WHEN-BUTTON-PRESSED (CB_BLK.PB_REP), WHEN-BUTTON-PRESSED (CB_BLK.PB_DIGI_SIG) | Validates all mandatory report parameters, identifies the correct invoice record, selects the report filename, assembles report parameters via PR_PASS_PARAM, runs the report, and orchestrates the digital-signing workflow including download, client-side signing via WEBUTIL_HOST.HOST, upload, and database update. |
| PR_PASS_PARAM | Form ProgramUnit (procedure) | CALL_REPORT | Reads the report parameter definitions from the ED_REPORTS configuration table for the current application and principal, and builds the parameter string passed to the report engine. |
| L_POP_LIST_ITEM | Form ProgramUnit (procedure) | WHEN-VALIDATE-ITEM (CB_BLK.FINANCIAL_YEAR1), KEY-NEXT-ITEM (CB_BLK.FINANCIAL_YEAR1) | Delegates to the DPL library routine l_pop_list_item to clear and recreate a named record group from a dynamically provided SQL query, then loads it into the specified on-screen list item. |
| L_POPULATE | Form ProgramUnit (procedure) | List-population routines | Populates a list item from the AM_LIST master table for a given list name and principal by delegating to the DPL library's L_POPULATE routine using a dynamically created record group. |
| LIST_POPULATE_ZONE | Form ProgramUnit (procedure) | Zone/region filter population | Dynamically populates the zone or region record group and list based on the user type (Head Office or dealer) and accessible regions; queries GM_REGN and AM_USER_REGION; uses WEBUTIL_C_API.ID_NULL before drop/create operations. |
| POP_LIST_REGION | Form ProgramUnit (procedure) | Region list population | Populates the region list item from the RG_REGION static record group. |
| VIEW_EXCEL_REP | Form ProgramUnit (procedure) | WHEN-BUTTON-PRESSED (CB_BLK.PB_ANNEX) | Executes a query using an in-memory record group, writes each result row to a server-side text file in CSV format, transfers the file to the browser via WEB.SHOW_DOCUMENT, and cleans up the temporary record group; uses WEBUTIL_C_API.ID_NULL before record group operations. |
| DOWNLOAD_FILE | Form ProgramUnit (procedure) | CALL_REPORT | Transfers a file from the application server to the user's client machine using WEBUTIL_FILE_TRANSFER.AS_TO_CLIENT; reports transfer errors via GENERAL.DISP_TEXT. |
| UPLOAD_FILE | Form ProgramUnit (procedure) | CALL_REPORT | Transfers a file from the user's client machine to the application server using WEBUTIL_FILE_TRANSFER.CLIENT_TO_AS; supports optional asynchronous transfer with a callback trigger name. |
| CLIENT_HOST | Form ProgramUnit / DPL library routine | CALL_REPORT, DOWNLOAD_FILE | Executes a command on the client machine; used to invoke the digital-signature tool and to delete temporary files after signing. |
| WEBUTIL_HOST.HOST | Package routine (WEBUTIL library) | CALL_REPORT | Executes an operating-system command on the client machine and returns the process exit code; blocks the Forms client until the command completes. Used in CALL_REPORT to open a downloaded report file using the client OS. |
| WEBUTIL_FILE_TRANSFER.AS_TO_CLIENT | Package routine (WEBUTIL library) | DOWNLOAD_FILE | Transfers a file from the application server file system to the client machine; returns TRUE on success and FALSE on failure, allowing the calling unit to report transfer errors via GENERAL.DISP_TEXT. |
| WEBUTIL_FILE_TRANSFER.CLIENT_TO_AS | Package routine (WEBUTIL library) | UPLOAD_FILE | Transfers a file from the client machine to the application server file system; supports optional asynchronous transfer with a callback trigger name; returns TRUE on success. |
| WEBUTIL_CORE.SHOWBEANS | Package routine (WEBUTIL library) | WHEN-BUTTON-PRESSED (WEBUTIL.DUMMY) | Controls the visibility of all WebUtil bean canvas items at runtime; called from the DUMMY button trigger to toggle bean visibility during development or diagnostics. |
| WEBUTIL_CORE.CUSTOMEVENTHANDLER | Package routine (WEBUTIL library) | WHEN-CUSTOM-ITEM-EVENT (WEBUTIL.WEBUTIL_BROWSER_FUNCTIONS), WHEN-CUSTOM-ITEM-EVENT (WEBUTIL.WEBUTIL_CLIENTINFO_FUNCTIONS), WHEN-CUSTOM-ITEM-EVENT (WEBUTIL.WEBUTIL_C_API_FUNCTIONS), WHEN-CUSTOM-ITEM-EVENT (WEBUTIL.WEBUTIL_FILETRANSFER_FUNCTIONS), WHEN-CUSTOM-ITEM-EVENT (WEBUTIL.WEBUTIL_FILE_FUNCTIONS), WHEN-CUSTOM-ITEM-EVENT (WEBUTIL.WEBUTIL_HOST_FUNCTIONS), WHEN-CUSTOM-ITEM-EVENT (WEBUTIL.WEBUTIL_OLE_FUNCTIONS), WHEN-CUSTOM-ITEM-EVENT (WEBUTIL.WEBUTIL_SESSION_FUNCTIONS) | Central event-dispatch procedure for the WebUtil bean architecture; each WEBUTIL bean item fires WHEN-CUSTOM-ITEM-EVENT when the Java applet raises a callback, and the trigger delegates to CustomEventHandler to route the event to the appropriate PL/SQL handler. |
| WEBUTIL_C_API.ID_NULL | Package routine (WEBUTIL library) | LIST_POPULATE_ZONE, L_POPULATE, L_POP_LIST_ITEM, VIEW_EXCEL_REP | Returns TRUE when a Forms object handle (record group, list item) is null or uninitialised; used before drop/create operations to avoid manipulating a non-existent object handle. |
| WEB.SHOW_DOCUMENT | Oracle Forms built-in package routine | CALL_REPORT, VIEW_EXCEL_REP, PR_REMOVE_ASCII_CHR | Opens a specified URL or file path in the user's browser window. |
| PR_REMOVE_ASCII_CHR | Form ProgramUnit (procedure) | Excel post-processing path (not called from active triggers) | Strips special/non-printable ASCII characters from an Excel output file to ensure clean browser display; calls WEB.SHOW_DOCUMENT and GENERAL.DISP_TEXT. |
| ADD_ERROR | Form ProgramUnit (procedure) | Error management infrastructure | Adds an error entry to the form-level error table (v_tab) managed by the POPULATE_ERRORS package infrastructure. |
| ADD_EXTERNAL_ERRORS | Form ProgramUnit (procedure) | Error management infrastructure | Adds externally sourced errors into the form-level error stack for consolidated display or handling. |
| CLEAN_ERROR_STACK | Form ProgramUnit (procedure) | Error management infrastructure | Clears all entries from the form-level error stack, resetting the error state for a new operation. |
| POPULATE_ERRORS | Form ProgramUnit (package declaration) | Error management infrastructure | Declares the package-level error table (v_tab) used by the form-level error-management routines ADD_ERROR, ADD_EXTERNAL_ERRORS, and CLEAN_ERROR_STACK. |
| BOOLTOCHAR | Form ProgramUnit (function) | Internal utility | Converts a PL/SQL BOOLEAN value to its VARCHAR2 character representation for use in string contexts. |
| DEBUGLOG | Form ProgramUnit (procedure) | Internal utility | Writes a debug message to the form-level debug log when debug mode is active. |
| GET_ENVIRONMENT_STRING | Form ProgramUnit (function) | Internal utility | Retrieves an environment variable value from the client or server context for use in path construction or configuration lookup. |
| READ_REGISTRY | Form ProgramUnit (function) | Internal utility | Reads a Windows registry key value on the client machine; used for client-side configuration retrieval. |
| REGISTER_FUNCTION_CALL | Form ProgramUnit (procedure) | Internal utility / WebUtil infrastructure | Registers a WebUtil function call for asynchronous dispatch within the WebUtil bean event framework. |
| SETDEBUG | Form ProgramUnit (procedure) | Internal utility | Enables or disables debug-logging mode within the form session; controls whether DEBUGLOG writes output. |
| STRIPDIRSEP | Form ProgramUnit (function) | Internal utility | Strips trailing directory-separator characters from a file path string to produce a normalised path. |
| WINDEBUG | Form ProgramUnit (procedure) | Internal utility | Writes a debug string to the Windows debug output channel for low-level client-side diagnostics. |
| D2KWUTIL.ATTEMPT_DLL_LOAD | Package routine (D2KWUTIL library) | WebUtil / client initialisation | Attempts to load a named client-side DLL via the D2KWUTIL library; used during WebUtil initialisation to verify client-side library availability. |
| D2KWUTIL.D2KWUTIL_DEBUGSTRING | Package routine (D2KWUTIL library) | Internal diagnostics | Writes a debug string through the D2KWUTIL client library for low-level diagnostic output. |
| D2KWUTIL.D2KWUTIL_GETDOSENV | Package routine (D2KWUTIL library) | Internal utility | Retrieves a DOS/Windows environment variable value via the D2KWUTIL client library. |
| D2KWUTIL.D2KWUTIL_GETREGKEY | Package routine (D2KWUTIL library) | Internal utility | Reads a Windows registry key value via the D2KWUTIL client library; supplements READ_REGISTRY for client-side configuration. |
| D2KWUTIL.TRANSLATETYPE | Package routine (D2KWUTIL library) | Internal utility | Translates a D2KWUTIL internal type code to its human-readable string representation. |

## 13. Package Procedure Specifications

*Behavioural requirements for each database package invoked from the form. Only packages referenced in the form XML that have a matching source `.pck` file in the input directory are listed. Descriptions are derived from the package bodies in the uploaded PCK sources.*

*No PCK files found - no `*.pck` source files were discovered in `/app/section-rewrite-pipeline/workspaces/4a8ba76f-9ad1-4789-929c-38c310fc155f/inputs/form_sources`. Package specifications cannot be generated without uploaded PCK sources.*

## 14. Database Package Catalogue

*Detailed specifications for each database package routine called from the form, including signatures and business rules.*

*No PCK files found - no `*.pck` source files were discovered in the form sources directory. The database package catalogue cannot be generated without uploaded PCK sources.*

## 15. PLD Procedure Call Sites

*Maps each program-library routine to its call sites within triggers and program units. Behaviour descriptions are derived from the uploaded ``.pld`` sources.*

### DPL.pld (`general`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ASK_CONFIRM | Function | Function(confirm_msg VARCHAR2) RETURN NUMBER | Trigger: FT_CANCEL in Form, Trigger: FT_DEL in Form | Displays a confirmation dialog to the user with the supplied message and returns a numeric result indicating the user's choice. Called in FT_CANCEL and FT_DEL to prompt the user to confirm a cancellation or deletion action before proceeding; the return value is tested to determine whether to continue or abort the operation. |
| DISP_TEXT | Procedure | Procedure(text_string VARCHAR2, title_string VARCHAR2) | ProgramUnit: CALL_REPORT, ProgramUnit: DOWNLOAD_FILE, ProgramUnit: PR_REMOVE_ASCII_CHR, Trigger: FT_INSERT in Form, Trigger: KEY-LISTVAL in CB_BLK.FINANCIAL_YEAR, Trigger: KEY-NEXT-ITEM in CB_BLK.FINANCIAL_YEAR, Trigger: KEY-NEXT-ITEM in CB_BLK.P_DEALER_DESC, Trigger: KEY-NEXT-ITEM in CB_BLK.QUARTER, Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: WHEN-BUTTON-PRESSED in CB_BLK.PB_DIGI_SIG, Trigger: WHEN-LIST-CHANGED in CB_BLK.QUARTER, Trigger: WHEN-NEW-ITEM-INSTANCE in CB_BLK.P_DEALER_DESC | Displays a modal alert to the user with the supplied message text and title. Uses AL_ERRINFO for 'Error'-titled messages and AL_NOTE for all other titles. Called throughout the form to show validation errors, user guidance messages, and informational notifications. |
| L_POPULATE | Procedure | Procedure(P_LIST_NAME VARCHAR2,P_LIST_FIELD VARCHAR2) | ProgramUnit: L_POPULATE | Populates a named list item by delegating to the DPL library's list-population logic using the supplied list name and field name parameters. Called from the local L_POPULATE program unit to drive list item initialisation via the shared library routine. |
| l_pop_list_item | Procedure | Procedure(p_rg_name VARCHAR2,p_select VARCHAR2) | ProgramUnit: L_POP_LIST_ITEM, Trigger: KEY-NEXT-ITEM in CB_BLK.FINANCIAL_YEAR1, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.FINANCIAL_YEAR1 | Builds or rebuilds a record group from the supplied SQL string (p_select) and populates the named list item (p_rg_name) from the resulting data. Called from the local L_POP_LIST_ITEM program unit and directly from KEY-NEXT-ITEM and WHEN-VALIDATE-ITEM on CB_BLK.FINANCIAL_YEAR1 to refresh dependent list content on navigation and validation events. |
| RAISE_ERROR | Procedure | Procedure(mesg_code IN VARCHAR2) | Trigger: ON-ERROR in Form | Looks up an error message by code (mesg_code) and displays it as an error, note, or caution alert depending on the message type. Raises FORM_TRIGGER_FAILURE after displaying error-type messages. Called in ON-ERROR for FK constraint violations (ORA-02292). |

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``vr_ewinv_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| CHECK_NULL | Procedure | Procedure(p_value IN VARCHAR2, column_title IN VARCHAR2) | ProgramUnit: VALIDATE_CN_MAIN | **COMMENTED OUT / INACTIVE** - Validates that the supplied field value is not null; if null, displays an error message using the column title and raises FORM_TRIGGER_FAILURE. Referenced only from the commented-out VALIDATE_CN_MAIN program unit. |

**Total Active Routines:** 5 of 24 in DPL.pld source
**Inactive / commented-only routines:** 1

---

### webutil.pld (`WEBUTIL_CORE`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| CustomEventHandler | Procedure | Procedure(EventName in VARCHAR2, EventParameters in VARCHAR2) | Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_BROWSER_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_CLIENTINFO_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_C_API_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_FILETRANSFER_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_FILE_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_HOST_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_OLE_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_SESSION_FUNCTIONS | Central event-dispatch procedure for the WebUtil bean architecture. Each WEBUTIL bean item fires WHEN-CUSTOM-ITEM-EVENT when the Java applet raises a callback; the trigger delegates to CustomEventHandler, passing the event name and its serialised parameter string so that the appropriate PL/SQL handler within the WEBUTIL_CORE package can process the response asynchronously. |
| ShowBeans | Procedure | Procedure(show BOOLEAN) | Trigger: WHEN-BUTTON-PRESSED in WEBUTIL.DUMMY | Controls the visibility of all WebUtil bean canvas items at runtime. Called from the DUMMY button's WHEN-BUTTON-PRESSED trigger (which is never intended to be pressed by end users) to toggle bean visibility, typically used during development or diagnostics. |

**Total Active Routines:** 2 of 39 in webutil.pld source

---

### webutil.pld (`WEBUTIL_C_API`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ID_NULL | Function | Function(handle IN Pointer) RETURN BOOLEAN | ProgramUnit: LIST_POPULATE_ZONE, ProgramUnit: L_POPULATE, ProgramUnit: L_POP_LIST_ITEM, ProgramUnit: VIEW_EXCEL_REP | Returns TRUE when a Forms object handle (record group, list item) is null or uninitialised. Used before drop/create operations to avoid attempting to manipulate a non-existent object handle. |

**Total Active Routines:** 1 of 28 in webutil.pld source

---

### webutil.pld (`WEBUTIL_FILE`)

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``vr_ewinv_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| FILE_SAVE_DIALOG | Function | Function(directory_name Varchar2 := NULL, file_name Varchar2 := NULL, file_filter Varchar2 := NULL, title Varchar2 := NULL) RETURN Varchar2 | ProgramUnit: VIEW_EXCEL_REP | **COMMENTED OUT / INACTIVE** - Presents a native client-side Save dialog, optionally pre-populated with a directory, filename, file-type filter, and dialog title, and returns the fully qualified path chosen by the user. Referenced only within the commented-out VIEW_EXCEL_REP program unit; no active call site exists in the form. |

**Total Active Routines:** 0 of 25 in webutil.pld source
**Inactive / commented-only routines:** 1

---

### webutil.pld (`WEBUTIL_FILE_TRANSFER`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| AS_To_Client | Function | Function(clientFile in VARCHAR2, serverFile in VARCHAR2) RETURN BOOLEAN | ProgramUnit: DOWNLOAD_FILE | Transfers a file from the application server file system to the client machine. Called in DOWNLOAD_FILE to push the generated report or export file to the user's local path; returns TRUE on success and FALSE on failure, allowing the calling unit to report transfer errors via DISP_TEXT. |
| Client_To_AS | Function | Function(clientFile in VARCHAR2, serverFile in VARCHAR2, asynchronous in BOOLEAN default FALSE, callbackTrigger in VARCHAR2 default NULL) RETURN BOOLEAN | ProgramUnit: UPLOAD_FILE | Transfers a file from the client machine to the application server file system. Called in UPLOAD_FILE to receive a user-selected local file onto the server; supports optional asynchronous transfer with a callback trigger name. Returns TRUE on success, allowing the calling unit to proceed with server-side processing of the uploaded file. |

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``vr_ewinv_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| URL_To_Client | Function | Function(sourceURL in VARCHAR2, clientDestination in VARCHAR2, fileSize in PLS_INTEGER default 0) RETURN BOOLEAN | ProgramUnit: VIEW_EXCEL_REP | **COMMENTED OUT / INACTIVE** - Downloads a file from a URL directly to a client-side destination path, with an optional expected file size hint. Referenced only within the commented-out VIEW_EXCEL_REP program unit; no active call site exists in the form. |

**Total Active Routines:** 2 of 21 in webutil.pld source
**Inactive / commented-only routines:** 1

---

### webutil.pld (`WEBUTIL_HOST`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| Host | Function | Function(cmd in VARCHAR2) RETURN PLS_INTEGER | ProgramUnit: CALL_REPORT | Executes an operating-system command on the client machine and returns the process exit code. Called in CALL_REPORT to open a downloaded report file using the client OS; blocks the Forms client until the command completes. |

**Total Active Routines:** 1 of 14 in webutil.pld source

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| ID | Service Name | Database Object | Input Parameters | Output | Business Function | API Endpoint Suggestion |
| -- | ------------ | --------------- | ---------------- | ------ | ----------------- | ----------------------- |
| MS-001 | Invoice Report Generation Service | CALL_REPORT (form procedure) / ED_REPORTS / VD_EW_COMM_DTL / VD_CCP_COMM_DTL | Programme type (EW/CCP), invoice sub-type, dealer code, location code, reporting period (contract month or quarter + financial year), digital-sign flag | Report URL or PDF stream; invoice number; error status | Validates mandatory parameters, retrieves the invoice record for the selected period and dealer, builds the report parameter string from configuration, and runs the invoice report (EW or CCP) as a PDF for browser display | `POST /api/v1/invoice-report/generate` |
| MS-002 | Digital Signature Eligibility Check Service | WHEN-BUTTON-PRESSED logic (CB_BLK.PB_DIGI_SIG) / SH_EINVOICE / AM_DEALER_LOC_PARAM / AM_DEALER_LOC / VD_EW_COMM_DTL / VD_CCP_COMM_DTL | Programme type, invoice sub-type, dealer code, location code, reporting period | E-invoice QR status, IRN status, invoice date, dealer category, and eligibility result | Checks whether a given invoice is eligible for digital signing: verifies the invoice exists, checks whether the dealer is subject to the e-invoicing requirement, and - if applicable - checks that the QR code has been successfully generated | `GET /api/v1/invoice/digital-sign-eligibility` |
| MS-003 | Digital Signature Application Service | CALL_REPORT (digital-sign path) / AM_LIST / AM_LIST_RANGE / FM_COMPANY / VD_EW_COMM_DTL / VD_CCP_COMM_DTL | Programme type, invoice sub-type, dealer code, location code, reporting period, principal | Signed PDF URL; success/error status; digital-sign date | Orchestrates the full digital-signing workflow: validates the signing time window, retrieves configuration paths and signing command, generates the unsigned PDF, coordinates the client-side signing tool invocation, uploads the signed file to the server, updates the invoice record with digital-sign status and path, and returns the signed document URL | `POST /api/v1/invoice/digital-sign` |
| MS-004 | Report Parameter Configuration Service | PR_PASS_PARAM (form procedure) / ED_REPORTS | Application ID, principal map code | List of parameter name/type/default/datatype tuples forming the report parameter string | Reads the report parameter definitions from the central report-configuration table for the given application and principal, and assembles them into the parameter string used by the report engine | `GET /api/v1/report-config/parameters?app_id={appId}&principal={principal}` |
| MS-005 | Contract Month List Service | L_POP_LIST_ITEM (form procedure) | Financial year (formatted as YYYY-YY) | Ordered list of twelve month-year labels for the selected financial year (APR-YY through MAR-YY) | Generates the twelve calendar months of a given financial year (April through March) as an ordered list for population of the Contract Month drop-down | `GET /api/v1/reference/contract-months?financial_year={year}` |
| MS-006 | Workshop Annexure Export Service | VIEW_EXCEL_REP (form procedure) / VH_EW_COMM_DTL / VD_EW_COMM_DTL / VH_CCP_COMM_DTL / VD_CCP_COMM_DTL / AM_DEALER_LOC | Programme type, invoice sub-type, dealer group (parent group), contract month | CSV file stream with invoice-line data (Region, Month, Dealer Name, Location, City, Sold From, Dealer Code, GST Number, Invoice Number, Invoice Date, Basic Amount, CGST Amount, SGST Amount, IGST Amount, Total Amount) | Retrieves the workshop-level commission invoice detail data for the selected programme, sub-type, dealer group, and contract month, and returns it as a downloadable CSV file | `GET /api/v1/invoice/annexure/export?program={type}&subtype={sub}&month={month}` |
| MS-007 | Dealer Look-up Service | RG_DEALER / AM_DEALER_LOC | Parent group, user context | List of dealer name and code pairs | Provides the list of dealers available to the current user for the Dealer field look-up | `GET /api/v1/reference/dealers?parentGroup={group}` |
| MS-008 | City / Location Look-up Service | RG_CITY / AM_DEALER_LOC | Parent group, dealer map code | List of location name and code pairs including an "All Locations" option | Provides the list of locations for the selected dealer group for the City/Location field look-up | `GET /api/v1/reference/locations?parentGroup={group}&dealer={dealerCode}` |
| MS-009 | Financial Year Look-up Service | RG_FINANCIAL_YEAR / FM_COMPANY | Parent group, dealer map code, location code, company code | List of financial year display/value pairs, ordered descending | Provides the available open financial years for the Tariff Financial Year field look-up | `GET /api/v1/reference/financial-years?parentGroup={group}&dealer={dealerCode}&location={locCode}` |

**Total Microservices Identified: 9**

---

## 17. Workflows

| ID | Workflow Name | Trigger Event | Steps | Decision Points | End State |
| -- | ------------- | ------------- | ----- | --------------- | --------- |
| WF-001 | Form Initialization | PRE-FORM trigger fires when the form is opened | 1. Optionally start performance timer if application logging is active; 2. Register database session under the invoice module identity | Is application-level logging active? | Session registered; form ready for parameter entry |
| WF-002 | Report Type and Period Configuration | User selects Programme Type (EW/CCP) and Invoice Sub-Type | 1. User selects Programme Type -> dependent sections shown/hidden; 2. User selects Invoice Sub-Type -> period fields reconfigured (monthly or quarterly layout); 3. Period and dealer fields cleared on any sub-type change | Is programme type EW? -> show EW Extension/SAWA sections. Is sub-type Tariff? -> show Quarter + Financial Year fields; else show Monthly Financial Year + Contract Month fields | Screen configured with the correct period fields visible and mandatory |
| WF-003 | Monthly Period Entry | User selects Monthly Financial Year and Contract Month | 1. User confirms Monthly Financial Year -> Contract Month list rebuilt for selected year; 2. Focus advances to Contract Month; 3. User selects Contract Month -> Contract Month mandatory check performed before Dealer field can be entered | Financial Year confirmed? -> rebuild Contract Month list. Contract Month blank when cursor enters Dealer? -> show error and redirect | Contract Month selected; Dealer field ready for entry |
| WF-004 | Quarterly Period Entry | User selects Quarter and Tariff Financial Year (Tariff sub-type only) | 1. User selects Quarter -> blank check performed; end-month derived; Financial Year cleared; 2. User tabs off Quarter -> blank check repeated; 3. User opens Financial Year look-up -> year selected and validated; 4. User tabs off Financial Year -> blank check performed; quarter-year reference computed | Quarter blank? -> error. Financial Year blank? -> error. Quarter is Q4? -> use following year in quarter-year reference | Both period parameters set; focus advances to report destination field |
| WF-005 | Dealer Selection and Validation | User selects dealer and navigates away | 1. User enters or selects dealer; 2. User navigates away from Dealer field -> blank check performed; 3. If valid, focus directed to next appropriate period field based on sub-type | Dealer blank? -> error, return focus. Sub-type is Tariff? -> advance to Quarter; else advance to Monthly Financial Year | Dealer confirmed; focus on next period field |
| WF-006 | View Invoice Report | User clicks View Invoice button | 1. All mandatory parameter checks performed (Dealer, period fields based on sub-type); 2. Invoice record looked up for selected dealer/location/period/sub-type; 3. Report filename set based on programme type and sub-type; 4. Report parameter string assembled from configuration; 5. Report generated as PDF and displayed in browser | Any mandatory parameter blank? -> show error, stop. Invoice not found? -> show error, stop. Programme type is CCP + Commission? -> use vr_ccpinv; CCP other? -> use vr_ccfinv; EW? -> use vr_ewinv | Invoice report PDF displayed in user's browser |
| WF-007 | Digital Signature with E-Invoice QR Validation | User clicks Digitally Sign button | 1. Mandatory parameter checks (same as WF-006); 2. Invoice record looked up; 3. If dealer subject to e-invoicing: check QR/IRN status and dealer category; 4. If QR confirmed or e-invoicing not applicable: check signing time window; 5. If already signed: display stored signed document directly; 6. Retrieve configuration paths and signing command; 7. Generate unsigned PDF; 8. Download to client; 9. Invoke signing tool on client; 10. Upload signed file to server; 11. Update invoice record; 12. Display signed document in browser | Invoice found? -> continue. Dealer subject to e-invoicing? -> check QR. QR generated? -> proceed to signing. QR pending? -> show status error. Signing window expired? -> show error. Already signed? -> display existing. Configuration found? -> proceed. Upload successful? -> update record and display | Invoice digitally signed; signed PDF displayed in browser; invoice record updated |
| WF-008 | Workshop Annexure Export | User clicks Workshop Annexure button | 1. Check programme type and sub-type eligibility (EW Commission/Incentive/SAWA/Extension or CCP Commission/Incentive); 2. Build data query for the selected programme, sub-type, and contract month; 3. Execute query using in-memory record group; 4. Write result rows to a CSV file with fixed column headers; 5. Transfer file to browser | Programme type and sub-type eligible? -> proceed. File path contains spaces? -> show info message, use fallback. Row count exceeds 65,535? -> show info message, truncate | CSV file generated and opened in browser for download |
| WF-009 | Error Handling and Message Interception | ON-ERROR or ON-MESSAGE trigger fires | 1. Examine error/message code; 2. Route to targeted message for known codes (invalid date, wrong format, non-numeric in numeric field, max-length, concurrent-update lock, referential-integrity violation); 3. For unknown database errors: display database error text and rollback; 4. For non-critical navigation codes: suppress silently | Error code 50004/50025/50026/40209/50016/40207? -> targeted message. DBMS error -02292? -> referential-integrity message. Error 40654-40659? -> concurrent-update message. SQL error non-zero? -> generic database error + rollback. Error 40401/40405? -> suppress | Error or message displayed; current operation stopped (except suppressed codes) |
| WF-010 | Form Reset | User presses the clear-form keyboard shortcut | 1. All entered values discarded without saving; 2. Report Description restored from session default; 3. Financial year display rebuilt from session dates; 4. Screen layout reset: Quarter and Financial Year hidden/disabled; Monthly Financial Year and Contract Month visible/enabled | No decision points - all steps execute unconditionally | Screen returned to default layout and session defaults; ready for fresh parameter entry |
| WF-011 | Form Exit and Session Cleanup | User presses the exit keyboard shortcut | 1. Screen closed immediately without saving; 2. Database session module and client-info identifiers cleared | No decision points - all steps execute unconditionally | Screen closed; session tracking identifiers cleared |

**Total Workflows Identified: 11**

---

## 18. PLD-Backed Logic

*Maps shared library routines to their business function and suggested API contracts.*

### webutil.pld (`CLIENT_IMAGE`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | Host | Business Logic | ProgramUnit: CALL_REPORT | /api/v1/pld/host | When a report file is ready, then the client OS command is executed to open or process the file on the user's machine |
| PLD-002 | ID_NULL | Validation | ProgramUnit: LIST_POPULATE_ZONE, ProgramUnit: L_POPULATE, ProgramUnit: L_POP_LIST_ITEM, ProgramUnit: VIEW_EXCEL_REP | /api/v1/pld/id_null | When a Forms object handle is checked before manipulation, then returns TRUE if the handle is null so the caller can safely skip drop or populate operations |
| PLD-003 | length | Validation | ProgramUnit: CALL_REPORT | /api/v1/pld/length | When a generated file is retrieved, then its byte length is returned so the caller can confirm the file is non-empty before proceeding |


---

### DPL.pld (`general`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | CHECK_NULL | Validation | ProgramUnit: VALIDATE_CN_MAIN | /api/v1/pld/check_null | **COMMENTED OUT / INACTIVE** - When a required field value is null, then an error message is displayed and form navigation is blocked |
| PLD-002 | DISP_TEXT | Business Logic | ProgramUnit: CALL_REPORT, ProgramUnit: DOWNLOAD_FILE, ProgramUnit: PR_REMOVE_ASCII_CHR, Trigger: KEY-LISTVAL in CB_BLK.FINANCIAL_YEAR, Trigger: KEY-NEXT-ITEM in CB_BLK.FINANCIAL_YEAR, Trigger: KEY-NEXT-ITEM in CB_BLK.P_DEALER_DESC, Trigger: KEY-NEXT-ITEM in CB_BLK.QUARTER, Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: WHEN-BUTTON-PRESSED in CB_BLK.PB_DIGI_SIG, Trigger: WHEN-LIST-CHANGED in CB_BLK.QUARTER, Trigger: WHEN-NEW-ITEM-INSTANCE in CB_BLK.P_DEALER_DESC | /api/v1/pld/disp_text | When a message or error must be shown to the user, then the appropriate alert (error or informational) is displayed with the supplied title and text |
| PLD-003 | RAISE_ERROR | Validation | Trigger: ON-ERROR in Form | /api/v1/pld/raise_error | When an Oracle error code is encountered, then the corresponding error message is retrieved and displayed, and form execution is halted for error-type messages |


---

### D2kwutil.pld (`Win_API`)

*No routines from ``D2kwutil.pld`` are referenced in ``vr_ewinv_fmb.xml``.*

---

---

## 19. PCK-Backed Logic

*Maps database package routines to their business rules and suggested API contracts.*

*No package routines from the available PCK files are referenced in ``vr_ewinv_fmb.xml``.*

---

---

## 20. System Interfaces

### 20.1 Database Integrations

| Interface Name | Type | Purpose | Data Flow | Error Handling |
| -------------- | ---- | ------- | --------- | -------------- |
| EW Commission Detail (`VD_EW_COMM_DTL`) | Database Table (SELECT, UPDATE) | Retrieves the invoice number, invoice date, e-invoice QR/IRN status, and digital-signature path for Extended Warranty commission invoices; updated when a digital signature is successfully applied | Form -> SELECT to retrieve invoice data; Form -> UPDATE to record digital-signature status, signed-file path, and signing date | On SELECT failure (WHEN OTHERS): *"EW INVOICE NUMBER NOT FOUND."* displayed and action stops; on UPDATE path, commit is conditional on upload success |
| CCP Commission Detail (`VD_CCP_COMM_DTL`) | Database Table (SELECT, UPDATE) | Retrieves the invoice number, invoice date, e-invoice QR/IRN status, and digital-signature path for CCP Inspection commission invoices; updated when a digital signature is successfully applied | Form -> SELECT to retrieve invoice data; Form -> UPDATE to record digital-signature status, signed-file path, and signing date | On SELECT failure (WHEN OTHERS): *"CCP INVOICE NUMBER NOT FOUND"* displayed and action stops |
| EW Commission Detail Header View (`VH_EW_COMM_DTL`) | Database View (SELECT) | Provides header-level EW commission data (region, dealer name, location, city, sold-from, GST number, invoice number, invoice date, amounts) joined with the EW Commission Detail table for the Workshop Annexure export | Form -> SELECT within VIEW_EXCEL_REP data query | On query failure, VIEW_EXCEL_REP error handling applies |
| CCP Commission Detail Header View (`VH_CCP_COMM_DTL`) | Database View (SELECT) | Provides header-level CCP commission data joined with the CCP Commission Detail table for the Workshop Annexure export | Form -> SELECT within VIEW_EXCEL_REP data query | On query failure, VIEW_EXCEL_REP error handling applies |
| E-Invoice Tracking (`SH_EINVOICE`) | Database Table (SELECT) | Retrieves the current QR code generation status and error description for an invoice, used to determine digital-signature eligibility | Form -> SELECT keyed on invoice module (EWC/ECC), type, parent group, dealer, location, and invoice number | On SELECT failure (WHEN OTHERS): status and error description defaulted to NULL; processing continues using the defaulted values |
| Dealer Location Parameters (`AM_DEALER_LOC_PARAM`) | Database Table (SELECT) | Retrieves the e-invoicing turnover-threshold flag for a dealer location to determine whether QR readiness checks apply | Form -> SELECT keyed on parent group, dealer code, and location code | On SELECT failure (WHEN OTHERS): flag defaulted to 'N' (not applicable); processing continues |
| Dealer Location Master (`AM_DEALER_LOC`) | Database Table (SELECT) | Retrieves the dealer category (e.g. MUL) used to route QR-status messages during digital signing; also used to populate the City/Location look-up | Form -> SELECT for digital-sign flow; also used in RG_CITY record group query | On SELECT failure (WHEN OTHERS): dealer category defaulted to NULL |
| Report Configuration (`ED_REPORTS`) | Database Table (SELECT) | Provides the ordered list of report parameter definitions (parameter name, type, default value, datatype) for the current application and principal; used to build the report parameter string | Form (PR_PASS_PARAM) -> SELECT ordered by serial number | N/A - cursor-based; if no rows returned, parameter string remains empty |
| Application Configuration List (`AM_LIST`) | Database Table (SELECT) | Provides runtime configuration values: local file path for digital signing (JCBDL), server file path for signed files (JCBDS), and allowed signing window in days (EW_DSIGN_ALLOW_DAYS / DSIGN); also used by L_POPULATE for list population | Form (CALL_REPORT) -> SELECT for each configuration entry | On SELECT failure (WHEN OTHERS): *"Error while getting local file path"*, *"Error while getting server file path"* displayed and action stops; for signing-days lookup: NULL defaulted and processing continues |
| Signing Command Configuration (`AM_LIST_RANGE`) | Database Table (SELECT) | Provides the command string used to invoke the digital-signature tool, scoped by principal and active date range | Form (CALL_REPORT) -> SELECT for CRI_DIGI_CMD / CMD | On SELECT failure (WHEN OTHERS): *"Command Not Found in am_list"* displayed and action stops |
| Financial Year Master for Dealer (`FM_COMPANY`) | Database Table (SELECT) | Retrieves the current financial year for the selected dealer and location, used to organise the server directory for digitally signed files; also used for the Financial Year look-up record group | Form (CALL_REPORT) -> SELECT; also used in RG_FINANCIAL_YEAR record group query | On SELECT failure (WHEN OTHERS): *"Fin year not found for this dealer"* displayed and action stops |
| Region Master (`GM_REGN`) | Database Table (SELECT) | Used within the LIST_POPULATE_ZONE procedure to populate the zone and region list items available to the logged-in user | Form (LIST_POPULATE_ZONE) -> SELECT | On SELECT failure: error code captured; error logged |

### 20.2 External System Integrations

| System Name | Integration Type | Purpose | Protocol | Endpoint | Data Exchange | Success / Error Codes |
| ----------- | ---------------- | ------- | -------- | -------- | ------------- | --------------------- |
| Oracle Reports Server | Report execution (RUN_REPORT_OBJECT) | Generates the EW and CCP invoice reports as PDF files by running the configured report object against the report server | Oracle Forms Reports API | Report server name from session context (`REP_SERVER` global) | Form -> report server: report filename, parameter string, output format (PDF), destination path and server; Report server -> form: status string | Success: report runs and PDF written to server path; Failure: RUN_REPORT_OBJECT returns error status |
| Client-Side Digital Signature Tool | Client command execution (CLIENT_HOST / HOST) | Applies a digital signature to the unsigned invoice PDF on the user's local machine using the configured signing command | HOST/CLIENT_HOST system command | Local path and command from AM_LIST configuration | Form -> client: unsigned PDF (via DOWNLOAD_FILE); Client tool -> signed PDF; Form -> client: delete command for temporary files | Implicit - success is determined by whether the signed file can subsequently be uploaded |
| WebUtil File Transfer (Server-to-Client) | Binary file transfer (WEBUTIL_FILE_TRANSFER.AS_TO_CLIENT) | Transfers the generated unsigned PDF from the application server to the user's client machine so the digital-signature tool can access it | WebUtil binary transfer | Client file path from AM_LIST configuration; server file path from report output | Application server -> client machine: unsigned PDF | Success: file transfer completes (boolean `true`); Failure: *"File download Failed"* displayed |
| WebUtil File Transfer (Client-to-Server) | Binary file transfer (WEBUTIL_FILE_TRANSFER.CLIENT_TO_AS) | Transfers the locally-signed PDF from the user's client machine back to the application server for storage and display | WebUtil binary transfer | Client signed-file path; server destination path from AM_LIST configuration | Client machine -> application server: signed PDF | Success: upload error description is NULL; Failure: upload error description displayed via GENERAL.DISP_TEXT and action stops |
| Browser Document Display (`WEB.SHOW_DOCUMENT`) | Browser URL navigation | Opens the generated invoice PDF or workshop annexure CSV in the user's browser tab | HTTP / browser navigation | `/printer/` relative path on the web server | Server file -> browser: PDF or CSV displayed | Success: document opens in browser tab; Failure: not explicitly handled in this form |

### 20.3 Report Integrations

| Report Name | Report Server | Parameters | Output Format | Trigger |
| ----------- | ------------- | ---------- | ------------- | ------- |
| rep.rdf | Session report server (`REP_SERVER` global) | Report parameter string assembled by PR_PASS_PARAM from ED_REPORTS configuration; includes MODE=BITMAP, BLANKPAGES=NO, parform=yes, plus application-specific parameters; report filename set dynamically to `vr_ewinv`, `vr_ccpinv`, or `vr_ccfinv` based on programme type and sub-type | PDF (REPORT_DESFORMAT = PDF, REPORT_DESTYPE = FILE) | WHEN-BUTTON-PRESSED on the View Invoice button (CB_BLK.PB_REP) or the Digitally Sign button (CB_BLK.PB_DIGI_SIG), routed through the CALL_REPORT program unit |

---

### 20.3.1 Parameters Passed to the Report

This form does not pass parameters to an Oracle Report. No report parameters were identified in the form sources.

## 21. Procedure and Function Business Rule Catalogue

End-to-end business requirement specification for every stored procedure and function referenced by the VR_EWINV form.

### 21.1 Catalogue Index

100 procedures/functions - each SP ID links to its detailed specification in Section 21.2.

| SP Index | Routine Name |
| :--- | :--- |
| [SP-001](#SP-001--CALL_REPORT) | CALL_REPORT |
| [SP-002](#SP-002--DOWNLOAD_FILE) | DOWNLOAD_FILE |
| [SP-003](#SP-003--L_POP_LIST_ITEM) | L_POP_LIST_ITEM |
| [SP-004](#SP-004--PR_PASS_PARAM) | PR_PASS_PARAM |
| [SP-005](#SP-005--UPLOAD_FILE) | UPLOAD_FILE |
| [SP-006](#SP-006--VIEW_EXCEL_REP) | VIEW_EXCEL_REP |
| [SP-007](#SP-007--D2KWUTIL.ATTEMPT_DLL_LOAD) | D2KWUTIL.ATTEMPT_DLL_LOAD |
| [SP-008](#SP-008--D2KWUTIL.D2KWUTIL_DEBUGSTRING) | D2KWUTIL.D2KWUTIL_DEBUGSTRING |
| [SP-009](#SP-009--D2KWUTIL.D2KWUTIL_GETDOSENV) | D2KWUTIL.D2KWUTIL_GETDOSENV |
| [SP-010](#SP-010--D2KWUTIL.D2KWUTIL_GETREGKEY) | D2KWUTIL.D2KWUTIL_GETREGKEY |
| [SP-011](#SP-011--D2KWUTIL.TRANSLATETYPE) | D2KWUTIL.TRANSLATETYPE |
| [SP-012](#SP-012--GENERAL.ASK_CONFIRM) | GENERAL.ASK_CONFIRM |
| [SP-013](#SP-013--GENERAL.DISP_TEXT) | GENERAL.DISP_TEXT |
| [SP-014](#SP-014--GENERAL.RAISE_ERROR) | GENERAL.RAISE_ERROR |
| [SP-015](#SP-015--WEBUTIL.BLOCKING) | WEBUTIL.BLOCKING |
| [SP-016](#SP-016--WEBUTIL.BOOLTOSTR) | WEBUTIL.BOOLTOSTR |
| [SP-017](#SP-017--WEBUTIL.CHECKASACL) | WEBUTIL.CHECKASACL |
| [SP-018](#SP-018--WEBUTIL.CHECKJAVA) | WEBUTIL.CHECKJAVA |
| [SP-019](#SP-019--WEBUTIL.CHECKLIBS) | WEBUTIL.CHECKLIBS |
| [SP-020](#SP-020--WEBUTIL.CLEARCALLBACKTRIGGER) | WEBUTIL.CLEARCALLBACKTRIGGER |
| [SP-021](#SP-021--WEBUTIL.CLOSEBLOB) | WEBUTIL.CLOSEBLOB |
| [SP-022](#SP-022--WEBUTIL.CLOSEFILE) | WEBUTIL.CLOSEFILE |
| [SP-023](#SP-023--WEBUTIL.CREATETEMPFILE) | WEBUTIL.CREATETEMPFILE |
| [SP-024](#SP-024--WEBUTIL.DECODEBASE64FILE) | WEBUTIL.DECODEBASE64FILE |
| [SP-025](#SP-025--WEBUTIL.DELETE_) | WEBUTIL.DELETE_ |
| [SP-026](#SP-026--WEBUTIL.DOWNLOADFROMURLINT) | WEBUTIL.DOWNLOADFROMURLINT |
| [SP-027](#SP-027--WEBUTIL.DOWNLOADINT) | WEBUTIL.DOWNLOADINT |
| [SP-028](#SP-028--WEBUTIL.ENCODEBASE64FILE) | WEBUTIL.ENCODEBASE64FILE |
| [SP-029](#SP-029--WEBUTIL.ERROR) | WEBUTIL.ERROR |
| [SP-030](#SP-030--WEBUTIL.ERRORALERT) | WEBUTIL.ERRORALERT |
| [SP-031](#SP-031--WEBUTIL.EXECUTE) | WEBUTIL.EXECUTE |
| [SP-032](#SP-032--WEBUTIL.EXISTS_) | WEBUTIL.EXISTS_ |
| [SP-033](#SP-033--WEBUTIL.FCLOSE) | WEBUTIL.FCLOSE |
| [SP-034](#SP-034--WEBUTIL.FILE_IS_DIRECTORY) | WEBUTIL.FILE_IS_DIRECTORY |
| [SP-035](#SP-035--WEBUTIL.FILE_IS_READABLE) | WEBUTIL.FILE_IS_READABLE |
| [SP-036](#SP-036--WEBUTIL.FOPEN) | WEBUTIL.FOPEN |
| [SP-037](#SP-037--WEBUTIL.GETCALLBACKTRIGGER) | WEBUTIL.GETCALLBACKTRIGGER |
| [SP-038](#SP-038--WEBUTIL.GETCLIENTFILESEP) | WEBUTIL.GETCLIENTFILESEP |
| [SP-039](#SP-039--WEBUTIL.GETCLIENTOSFAMILY) | WEBUTIL.GETCLIENTOSFAMILY |
| [SP-040](#SP-040--WEBUTIL.GETCLIENTSETTING) | WEBUTIL.GETCLIENTSETTING |
| [SP-041](#SP-041--WEBUTIL.GETIMPLCLASS) | WEBUTIL.GETIMPLCLASS |
| [SP-042](#SP-042--WEBUTIL.GETLASTERROR) | WEBUTIL.GETLASTERROR |
| [SP-043](#SP-043--WEBUTIL.GETLASTERRORARGS) | WEBUTIL.GETLASTERRORARGS |
| [SP-044](#SP-044--WEBUTIL.GETNUMBER) | WEBUTIL.GETNUMBER |
| [SP-045](#SP-045--WEBUTIL.GETOSFAMILY) | WEBUTIL.GETOSFAMILY |
| [SP-046](#SP-046--WEBUTIL.GETOUTPUT) | WEBUTIL.GETOUTPUT |
| [SP-047](#SP-047--WEBUTIL.GETPATH) | WEBUTIL.GETPATH |
| [SP-048](#SP-048--WEBUTIL.GETPROPERTY) | WEBUTIL.GETPROPERTY |
| [SP-049](#SP-049--WEBUTIL.GETSERVERFILESEP) | WEBUTIL.GETSERVERFILESEP |
| [SP-050](#SP-050--WEBUTIL.GETSOURCECHUNKS) | WEBUTIL.GETSOURCECHUNKS |
| [SP-051](#SP-051--WEBUTIL.GETSOURCELENGTH) | WEBUTIL.GETSOURCELENGTH |
| [SP-052](#SP-052--WEBUTIL.GETSTRING) | WEBUTIL.GETSTRING |
| [SP-053](#SP-053--WEBUTIL.GETVAR) | WEBUTIL.GETVAR |
| [SP-054](#SP-054--WEBUTIL.GET_ATTRIBUTE_INT) | WEBUTIL.GET_ATTRIBUTE_INT |
| [SP-055](#SP-055--WEBUTIL.GET_LINE) | WEBUTIL.GET_LINE |
| [SP-056](#SP-056--WEBUTIL.GET_RETURN_CODE) | WEBUTIL.GET_RETURN_CODE |
| [SP-057](#SP-057--WEBUTIL.GET_STANDARD_OUTPUT) | WEBUTIL.GET_STANDARD_OUTPUT |
| [SP-058](#SP-058--WEBUTIL.HOST) | WEBUTIL.HOST |
| [SP-059](#SP-059--WEBUTIL.ID_NULL) | WEBUTIL.ID_NULL |
| [SP-060](#SP-060--WEBUTIL.INIT) | WEBUTIL.INIT |
| [SP-061](#SP-061--WEBUTIL.INITWEBUTIL) | WEBUTIL.INITWEBUTIL |
| [SP-062](#SP-062--WEBUTIL.IN_PROGRESS) | WEBUTIL.IN_PROGRESS |
| [SP-063](#SP-063--WEBUTIL.ISERROR) | WEBUTIL.ISERROR |
| [SP-064](#SP-064--WEBUTIL.IS_OPEN) | WEBUTIL.IS_OPEN |
| [SP-065](#SP-065--WEBUTIL.LENGTH) | WEBUTIL.LENGTH |
| [SP-066](#SP-066--WEBUTIL.LOG) | WEBUTIL.LOG |
| [SP-067](#SP-067--WEBUTIL.NEW) | WEBUTIL.NEW |
| [SP-068](#SP-068--WEBUTIL.OPENBLOB) | WEBUTIL.OPENBLOB |
| [SP-069](#SP-069--WEBUTIL.OPENFILE) | WEBUTIL.OPENFILE |
| [SP-070](#SP-070--WEBUTIL.POPULATEPROPERTYBUNDLE) | WEBUTIL.POPULATEPROPERTYBUNDLE |
| [SP-071](#SP-071--WEBUTIL.PUT) | WEBUTIL.PUT |
| [SP-072](#SP-072--WEBUTIL.PUT_LINE) | WEBUTIL.PUT_LINE |
| [SP-073](#SP-073--WEBUTIL.READDATA) | WEBUTIL.READDATA |
| [SP-074](#SP-074--WEBUTIL.READFROMPROPERTYBUNDLE) | WEBUTIL.READFROMPROPERTYBUNDLE |
| [SP-075](#SP-075--WEBUTIL.READTRANSFROMMSGBUNDLE) | WEBUTIL.READTRANSFROMMSGBUNDLE |
| [SP-076](#SP-076--WEBUTIL.REGISTERBEAN) | WEBUTIL.REGISTERBEAN |
| [SP-077](#SP-077--WEBUTIL.REGISTER_FUNCTION) | WEBUTIL.REGISTER_FUNCTION |
| [SP-078](#SP-078--WEBUTIL.RELEASE_PROCESS) | WEBUTIL.RELEASE_PROCESS |
| [SP-079](#SP-079--WEBUTIL.SETCALLBACKTRIGGER) | WEBUTIL.SETCALLBACKTRIGGER |
| [SP-080](#SP-080--WEBUTIL.SETCLIENTSETTING) | WEBUTIL.SETCLIENTSETTING |
| [SP-081](#SP-081--WEBUTIL.SETDATA) | WEBUTIL.SETDATA |
| [SP-082](#SP-082--WEBUTIL.SETPROPERTY) | WEBUTIL.SETPROPERTY |
| [SP-083](#SP-083--WEBUTIL.UPLOADINT) | WEBUTIL.UPLOADINT |
| [SP-084](#SP-084--WEBUTIL.WRITEDATA) | WEBUTIL.WRITEDATA |
| [SP-085](#SP-085--WEBUTIL_CORE.CUSTOMEVENTHANDLER) | WEBUTIL_CORE.CUSTOMEVENTHANDLER |
| [SP-086](#SP-086--WEBUTIL_CORE.SHOWBEANS) | WEBUTIL_CORE.SHOWBEANS |
| [SP-087](#SP-087--WEBUTIL_FILE_TRANSFER.AS_TO_CLIENT) | WEBUTIL_FILE_TRANSFER.AS_TO_CLIENT |
| [SP-088](#SP-088--WEBUTIL_FILE_TRANSFER.CLIENT_TO_AS) | WEBUTIL_FILE_TRANSFER.CLIENT_TO_AS |
| [SP-089](#SP-089--ADD_ERROR) | ADD_ERROR |
| [SP-090](#SP-090--ADD_EXTERNAL_ERRORS) | ADD_EXTERNAL_ERRORS |
| [SP-091](#SP-091--BOOLTOCHAR) | BOOLTOCHAR |
| [SP-092](#SP-092--CLEAN_ERROR_STACK) | CLEAN_ERROR_STACK |
| [SP-093](#SP-093--CLIENT_HOST) | CLIENT_HOST |
| [SP-094](#SP-094--DEBUGLOG) | DEBUGLOG |
| [SP-095](#SP-095--GET_ENVIRONMENT_STRING) | GET_ENVIRONMENT_STRING |
| [SP-096](#SP-096--READ_REGISTRY) | READ_REGISTRY |
| [SP-097](#SP-097--REGISTER_FUNCTION_CALL) | REGISTER_FUNCTION_CALL |
| [SP-098](#SP-098--SETDEBUG) | SETDEBUG |
| [SP-099](#SP-099--STRIPDIRSEP) | STRIPDIRSEP |
| [SP-100](#SP-100--WINDEBUG) | WINDEBUG |

---

### 21.2 Detailed Specifications

#### SP-001 - CALL_REPORT

**Invoked From:**

- vr_ewinv_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

Product Type : (N/A / CN_MAIN)

---

**Purpose**

Validates mandatory report parameters (dealer, programme type, and period fields) and generates and delivers the EW or CCP commission invoice report for the selected dealer and period. For the standard report path, it assembles the Oracle Reports parameter string, runs the report, and opens the PDF in the browser. For the digital-signing path, it additionally validates the signing time window, retrieves configuration paths and the signing command, generates the unsigned PDF, coordinates client-side signing via the signing tool, uploads the signed document to the server, updates the invoice record to reflect the completed signature, and displays the signed document in the browser.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| pDIGI_SIG_YN | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- CLIENT_HOST ([SP-093](#SP-093--CLIENT_HOST)) - matched by member name
- DOWNLOAD_FILE ([SP-002](#SP-002--DOWNLOAD_FILE)) - JSON-LD ProgramUnit
- GENERAL.DISP_TEXT ([SP-013](#SP-013--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)
- PR_PASS_PARAM ([SP-004](#SP-004--PR_PASS_PARAM)) - JSON-LD ProgramUnit
- UPLOAD_FILE ([SP-005](#SP-005--UPLOAD_FILE)) - JSON-LD ProgramUnit
- WEBUTIL.HOST ([SP-058](#SP-058--WEBUTIL.HOST)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LENGTH ([SP-065](#SP-065--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Verify that the dealer field is not blank; if blank, display an error message and stop.
- Step 2 - Verify that the mandatory period fields are not blank based on the selected sub-type (Quarter and Financial Year for Tariff; Financial Year and Contract Month for monthly sub-types); if any are blank, display the corresponding error message and stop.
- Step 3 - Look up the invoice number, invoice date, and any existing digital-signature file path from the commission detail table (EW or CCP, based on programme type); if no record is found, display the 'invoice not found' error and stop.
- Step 4 - Call the report-parameter assembly routine to build the report parameter string for the Oracle Reports engine.
- Step 5 - Determine the correct report filename based on the programme type and invoice sub-type.
- Step 6 - If the digital-signing path is requested and an already-signed document exists, display the existing signed document directly in the browser and stop.
- Step 7 - If the digital-signing path is requested: check that the current date is within the permitted signing window; if the window has expired, display an error and stop.
- Step 8 - For the digital-signing path: retrieve the local file path, server file path, and signing command from application configuration; if any is missing, display the appropriate error and stop.
- Step 9 - Retrieve the current financial year for the selected dealer and location; if not found, display an error and stop.
- Step 10 - Configure the report object with the output format, destination path, filename, and parameter string; run the report to generate the unsigned PDF on the server.
- Step 11 - For the digital-signing path: download the unsigned PDF to the user's local machine, invoke the client-side signing tool, then upload the signed PDF back to the server.
- Step 12 - If the upload succeeds: update the commission detail record with the digital-sign flag, signed-document path, and signing date; commit; copy the signed file to the report server directory; open the signed document in the browser; delete temporary unsigned PDF files from the client machine.
- Step 13 - If the upload fails: display the upload error message and stop without updating the commission detail record.
- Step 14 - For the standard report path: configure the report object and run the report; open the generated PDF in the browser.

---
**Decision Points**

DP-001

Condition: The invoice sub-type is Tariff (T).

TRUE: Validate that the Quarter and Financial Year fields are both provided before proceeding.

FALSE: Validate that the Financial Year and Contract Month fields are both provided before proceeding.

DP-002

Condition: The programme type is EW (Extended Warranty).

TRUE: Look up the invoice record in the EW commission detail table and set the report filename to the EW report.

FALSE: Look up the invoice record in the CCP commission detail table; determine whether to use the CCP Commission report or the CCP Finance report based on the invoice sub-type.

DP-003

Condition: Digital signing is requested and an existing signed document path is on record.

TRUE: Display the existing signed document in the browser and return without regenerating.

FALSE: Proceed with the full digital-signing workflow.

DP-004

Condition: The number of days since the invoice date exceeds the configured signing window.

TRUE: Display the signing-window expiry error and stop.

FALSE: Continue with digital signing.

DP-005

Condition: The file upload to the server succeeds (upload error description is null).

TRUE: Update the commission detail record, commit, copy the signed file, display in browser, delete temporary client files.

FALSE: Display the upload error message and stop.

---
**Database Interactions**

- DB-001 - Read VD_CCP_COMM_DTL - Reads data from VD_CCP_COMM_DTL for lookup or validation.
- DB-002 - Read VD_EW_COMM_DTL - Reads data from VD_EW_COMM_DTL for lookup or validation.
- DB-003 - Read DUAL - Reads data from DUAL for lookup or validation.
- DB-004 - Read AM_LIST - Reads data from AM_LIST for lookup or validation.
- DB-005 - Read AM_LIST_RANGE - Reads data from AM_LIST_RANGE for lookup or validation.
- DB-006 - Read FM_COMPANY - Reads data from FM_COMPANY for lookup or validation.
- DB-007 - Update VD_CCP_COMM_DTL - Updates existing rows in VD_CCP_COMM_DTL.
- DB-008 - Update VD_EW_COMM_DTL - Updates existing rows in VD_EW_COMM_DTL.
**Business Rules**

- The dealer field must be selected before the report can be generated; the system blocks the action and redirects the user if the field is blank.
- Period fields required for the selected sub-type must be completed before the report can be generated; missing period fields produce targeted error messages.
- An invoice record must exist in the commission detail table for the selected dealer, location, period, and sub-type before a report or digital signature can be produced.
- Digital signing is only permitted within the configured number of days from the invoice date (default 20 days); requests outside this window are rejected.
- Configuration paths for local file storage, server file storage, and the signing command must all be present in the application configuration master before digital signing can proceed.
- The digital-signature upload must succeed before the invoice record is updated to reflect the signed status; a failed upload leaves the record unchanged.
- If a document has already been digitally signed, the system displays the existing signed document without repeating the signing workflow.

---
**Implementation Logic**

```plsql
PROCEDURE call_report
(
  pDIGI_SIG_YN VARCHAR2
)
IS
BEGIN
if :cb_blk.P_DEALER_DESC is null then
	  GENERAL.DISP_TEXT('Dealer can not be Blank)','Error'); 
	  go_item('cb_blk.P_DEALER_DESC');
	  raise form_trigger_failure;
end if;
IF :p_ew = 'T' then
	if :cb_blk.quarter is null then
		GENERAL.DISP_TEXT('Quarter can not be Blank)','Error'); 
		go_item('cb_blk.quarter');
		raise form_trigger_failure;
	end if;
	if :cb_blk.Financial_Year is null then
		GENERAL.DISP_TEXT('Financial Year can not be Blank)','Error'); 
		go_item('cb_blk.Financial_Year');
		raise form_trigger_failure;
	end if;
elsif :p_ew IN  ('C','F','I','V','S','X') then --Added 'S','X' by mohan ason 17-02-2026 sawa
		
		if :cb_blk.Financial_Year1 is null then
		GENERAL.DISP_TEXT('Financial Year can not be Blank)','Error'); 
		go_item('cb_blk.Financial_Year1');
		raise form_trigger_failure;
	end if;
	if :cb_blk.p_contract_month is null then
		GENERAL.DISP_TEXT('Contract Month can not be Blank)','Error'); 
		go_item('cb_blk.p_contract_month');
		raise form_trigger_failure;
	end if;
END IF;  		  

	
declare
	repid report_object;
	lv_rep     varchar2(100);
	rep_status varchar2(20);
	lv_server  varchar2(20) := :global.rep_server;
	lv_param   varchar2(5000);

	x number;

	l_Old_URL              varchar2(2000);
	l_new_url              varchar2(2000);
	vcFile                 varchar2(225)   := '';
	vcFile1                varchar2(225)   := '';
	lv_user                varchar2(50);
	LV_MAIN_FILE_NAME      varchar2(1000);
	LV_DIGI_FILE_NAME      varchar2(1000);
	LV_PARAM_DOC           varchar2(100)   := '';
	cLOCAL_PATH            varchar2(1000);
	cSRVR_PATH             varchar2(1000);
	LV_COMMAND             varchar2(1000);
	LV_DOC_TYPE_PATH       varchar2(1000)  := 'ew_comm';
	nFIN_YEAR              number;
	LV_err_desc            varchar2(1000);
	LV_DIGI_FILE_NAME_VIEW varchar2(1000);
	LV_EW_DIGI_SIGN_PATH   VARCHAR2(4000);
	
	LV_CNT_DAYS number;
	LV_DSIGN_ALLOW_DAYS number;
	lv_inv_date date;
Begin

	
	  PR_PASS_PARAM (Lv_param);
	  repid := find_report_object('REPORT_CALL');
--	GENERAL.DISP_TEXT(lv_param,'note');
IF :CB_BLK.EW_CCP  = 'CCP' THEN
   IF :CB_BLK.P_EW ='C' THEN
		:CB_BLK.report_name := 'vr_ccpinv';
   ELSE 
   	:CB_BLK.report_name := 'vr_ccfinv';
  END IF;
			begin
		  select inv_num,
		  			 inv_date,
		         EW_DIGI_SIGN_PATH   
		    into LV_PARAM_DOC,
		         lv_inv_date,
		         LV_EW_DIGI_SIGN_PATH		    
			  FROM vd_CCP_comm_dtl X
			 WHERE to_char(X.TRAN_DATE,'MON-YY') = :cb_blk.p_contract_month
			   AND x.Dealer_Map_Cd               = :CB_BLK.P_DEALER
			   AND X.LOC_CD                      = :CB_BLK.P_LOC
			   AND NVL(X.INV_TYPE,'C')					 = :CB_BLK.P_EW;	 
			  -- GENERAL.DISP_TEXT('CCP '||:cb_blk.p_contract_month||'  '||:CB_BLK.P_DEALER||'  '||:CB_BLK.P_LOC||'  '||LV_PARAM_DOC||'  '||LV_EW_DIGI_SIGN_PATH,'ERROR');
		EXCEPTION WHEN OTHERS THEN
			GENERAL.DISP_TEXT('CCP INVOICE NUMBER NOT FOUND','ERROR');
			RAISE FORM_TRIGGER_FAILURE;
		END;

ELSIF :CB_BLK.EW_CCP  ='EW' THEN 
	  :CB_BLK.report_name :='vr_ewinv';
		begin
		  select inv_num,
		         inv_date,
		         EW_DIGI_SIGN_PATH   
		    into LV_PARAM_DOC,
		         lv_inv_date,
		         LV_EW_DIGI_SIGN_PATH		    
			  FROM vd_ew_comm_dtl X
			 WHERE to_char(X.TRAN_DATE,'MON-YY') = :cb_blk.p_contract_month
			   AND x.Dealer_Map_Cd               = :CB_BLK.P_DEALER
			   AND X.LOC_CD                      = :CB_BLK.P_LOC
			   AND NVL(X.INV_TYPE,'C')					 = :CB_BLK.P_EW;	 
		EXCEPTION WHEN OTHERS THEN
			GENERAL.DISP_TEXT('EW INVOICE NUMBER NOT FOUND.','ERROR');
			RAISE FORM_TRIGGER_FAILURE;
		END;
END IF;	  
	  
IF pDIGI_SIG_YN = 'Y' THEN
					----------Added by mohan as on 08072022 agianst scp - ser_2223_8444--------- start
	  BEGIN			
	 	SELECT TRUNC(SYSDATE)-trunc(lv_inv_date) INTO LV_CNT_DAYS 
	   FROM DUAL;    
	  EXCEPTION WHEN OTHERS THEN
	    NULL;
	  END;
	  
	     BEGIN
			SELECT LIST_CODE INTO LV_DSIGN_ALLOW_DAYS  
			FROM AM_LIST
			WHERE LIST_NAME = 'EW_DSIGN_ALLOW_DAYS'
			AND LIST_NAME_DESC='DSIGN';
			EXCEPTION WHEN OTHERS THEN
		    LV_DSIGN_ALLOW_DAYS := NULL;
			END; 
	  
	  IF LV_CNT_DAYS > nvl(LV_DSIGN_ALLOW_DAYS,0) THEN
	    GENERAL.DISP_TEXT('Digital Sign only Allowed till 20th day from Invoice date. ','Error');  
	    RAISE FORM_TRIGGER_FAILURE;
	  END IF;
    
  ----------Added by mohan as on 08072022 agianst scp - ser_2223_8444--------- end	
  		
	 IF :P_EW IN ('C','F','I','V','S','X') THEN  --Added 'S','X' by mohan ason 17-02-2026 sawa

					BEGIN
						SELECT LIST_DESC  ---C:\MSILDigitalSignature\
						  INTO cLOCAL_PATH  
						  FROM AM_LIST
						 WHERE LIST_NAME = 'FILE_PATH' 
						   AND LIST_CODE = 'JCBDL'
						   AND NVL(LIST_FLAG,'Y') = 'Y'
						   AND PRINCIPAL_MAP_CD   = :GLOBAL.PRINCIPAL;
					EXCEPTION WHEN OTHERS THEN
						GENERAL.DISP_TEXT('Error while getting local file path','error');
						RAISE FORM_TRIGGER_FAILURE;
					END;	
					BEGIN
						SELECT LIST_DESC   --/Deployment_Pending/jc_bill/
						  INTO cSRVR_PATH
						  FROM AM_LIST
						 WHERE LIST_NAME = 'FILE_PATH' 
						   AND LIST_CODE = 'JCBDS'
						   AND NVL(LIST_FLAG,'Y') = 'Y'
						   AND PRINCIPAL_MAP_CD   = :GLOBAL.PRINCIPAL ;
					EXCEPTION WHEN OTHERS THEN
						GENERAL.DISP_TEXT('Error while getting server file path','error');
						RAISE FORM_TRIGGER_FAILURE;
					END;			
		    	BEGIN
				   	 SELECT LIST_DESC 
				   	   INTO LV_COMMAND
				   	   FROM AM_LIST_RANGE 
				   	  WHERE LIST_NAME        = 'CRI_DIGI_CMD' 
				   	    AND LIST_CODE        = 'CMD' 
		            AND NVL(TRUNC(CLOSE_DATE),TRUNC(SYSDATE)) >= TRUNC(SYSDATE) 
				   	    AND PRINCIPAL_MAP_CD = :GLOBAL.PRINCIPAL;   	 
				  EXCEPTION WHEN OTHERS THEN
				     GENERAL.DISP_TEXT('Command Not Found in am_list','error');
				     RAISE FORM_TRIGGER_FAILURE;	
				  END;  
			   	BEGIN
					  SELECT FIN_YEAR  
					    INTO nFIN_YEAR
					    FROM FM_COMPANY 
					   WHERE TRUNC(SYSDATE) BETWEEN FIN_BEG AND FIN_END
					     AND DEALER_MAP_CD = :CB_BLK.P_DEALER
					     AND LOC_CD        = :CB_BLK.P_LOC
					     AND ROWNUM        = 1;
					EXCEPTION WHEN OTHERS THEN
					  GENERAL.DISP_TEXT('Fin year not found for this dealer','ERROR');
					  RAISE FORM_TRIGGER_FAILURE;
					END;
					
					LV_MAIN_FILE_NAME :=  :CB_BLK.P_DEALER ||
	    	                        :CB_BLK.P_LOC    ||
	    	                        REPLACE(REPLACE(LV_PARAM_DOC,'/','_'),'-','_');
	    	
	       	
	    	  LV_DIGI_FILE_NAME :=  LV_MAIN_FILE_NAME||
	    	                        TO_CHAR(SYSDATE, 'YYYYMMDDHHMISS')||
	    	                        SUBSTR(REPLACE(DBMS_RANDOM.VALUE,'.',''),1,5);
					
					SET_REPORT_OBJECT_PROPERTY(repid,REPORT_DESFORMAT,'PDF');
					set_report_object_property(repid,REPORT_DESTYPE,FILE);
					lv_param := 'MODE=BITMAP BLANKPAGES=NO parform=yes '||lv_param;
					:CB_BLK.FILENAME :=LV_PARAM;
					--GENERAL.DISP_TEXT(lv_param,'ERROR');
					SET_REPORT_OBJECT_PROPERTY(repid,REPORT_FILENAME,:CB_BLK.report_name);
					SET_REPORT_OBJECT_PROPERTY(repid,report_other,lv_param);   
					SET_REPORT_OBJECT_PROPERTY(repid,REPORT_SERVER,lv_server);
					set_report_object_property(repid,REPORT_DESNAME,'/iashome/ias/reports/printer/'||LV_DIGI_FILE_NAME||'.pdf');		
					lv_rep:=RUN_REPORT_OBJECT(repid);					
					
					download_file(cLOCAL_PATH||LV_MAIN_FILE_NAME||'_unsigned.pdf','/iashome/ias/reports/printer/'||LV_DIGI_FILE_NAME||'.pdf','N');
					
					CLIENT_HOST(LV_COMMAND||' "'||LV_MAIN_FILE_NAME);     
	
		    	host('/bin/mkdir '||cSRVR_PATH ||'/'|| LV_DOC_TYPE_PATH );      
		    	cSRVR_PATH := cSRVR_PATH ||'/'||LV_DOC_TYPE_PATH||'/'||nFIN_YEAR||'/';
		    	host('/bin/mkdir '||cSRVR_PATH );    
	        upload_file(cLOCAL_PATH||LV_MAIN_FILE_NAME||'.pdf',cSRVR_PATH||LV_MAIN_FILE_NAME||'.pdf',LV_err_desc);
	        
	      IF LV_err_desc IS NULL THEN    
	         LV_DIGI_FILE_NAME_VIEW :=  LV_MAIN_FILE_NAME||
	    	                             TO_CHAR(SYSDATE, 'YYYYMMDDHHMISS')||
	    	                             SUBSTR(REPLACE(DBMS_RANDOM.VALUE,'.',''),1,5);
	    	                             
         IF :CB_BLK.EW_CCP ='CCP' THEN					
				   UPDATE vd_ccp_comm_dtl X
				      SET EW_DIGI_SIGN_YN   = 'Y',
		              EW_DIGI_SIGN_PATH = cSRVR_PATH||LV_MAIN_FILE_NAME||'.pdf',
		              EW_DIGI_SIGN_DATE = SYSDATE
					    WHERE to_char(X.TRAN_DATE,'MON-YY') = :cb_blk.p_contract_month
					    AND x.Dealer_Map_Cd               = :CB_BLK.P_DEALER
					    AND X.LOC_CD                      = :CB_BLK.P_LOC
					    AND NVL(X.INV_TYPE,'C')					  = :CB_BLK.P_EW;		   --Added by mohan ason 29-11-2024 for new invoices
         ELSIF :CB_BLK.EW_CCP ='EW' THEN
         	UPDATE vd_ew_comm_dtl X
				      SET EW_DIGI_SIGN_YN   = 'Y',
		              EW_DIGI_SIGN_PATH = cSRVR_PATH||LV_MAIN_FILE_NAME||'.pdf',
		              EW_DIGI_SIGN_DATE = SYSDATE
					    WHERE to_char(X.TRAN_DATE,'MON-YY') = :cb_blk.p_contract_month
					    AND x.Dealer_Map_Cd               = :CB_BLK.P_DEALER
					    AND X.LOC_CD                      = :CB_BLK.P_LOC
					    AND NVL(X.INV_TYPE,'C')					 = :CB_BLK.P_EW;	 --Added by mohan ason 29-11-2024 for new invoices	  
         END IF;
        
         	
					 --GENERAL.DISP_TEXT('1','');   	                             
           COMMIT;	    	 	    
					 --GENERAL.DISP_TEXT('2','');   	                                                         
		       HOST('/bin/cp '|| cSRVR_PATH||LV_MAIN_FILE_NAME||'.pdf' ||' /iashome/ias/reports/printer/'||LV_DIGI_FILE_NAME_VIEW||'.pdf');
		       web.show_document('/printer/'||LV_DIGI_FILE_NAME_VIEW||'.pdf','_blank'); 
		       CLIENT_HOST(' cmd /C DEL '||cLOCAL_PATH||LV_MAIN_FILE_NAME||'.pdf');
		       CLIENT_HOST(' cmd /C DEL '||cLOCAL_PATH||LV_MAIN_FILE_NAME||'_unsigned.pdf');		
	      ELSE
	      	GENERAL.DISP_TEXT(LV_err_desc,'ERROR');
	      	RAISE FORM_TRIGGER_FAILURE;
		    END IF;
							 
		 END IF;
			
ELSE
		
		
			  ------------- DOCUMENT ALREADY UPLOADED
				IF LV_EW_DIGI_SIGN_PATH IS NOT NULL THEN
					--GENERAL.DISP_TEXT('DOCUMENT ALREADY UPLOADED','');
				  LV_MAIN_FILE_NAME :=  SUBSTR( LV_EW_DIGI_SIGN_PATH, 
			                                  INSTR(LV_EW_DIGI_SIGN_PATH, '/', -1) + 1,
			                                  LENGTH(SUBSTR( LV_EW_DIGI_SIGN_PATH,INSTR(LV_EW_DIGI_SIGN_PATH, '/', -1) + 1))-4); 		
					
	        LV_DIGI_FILE_NAME_VIEW :=  LV_MAIN_FILE_NAME||
	    	                             TO_CHAR(SYSDATE, 'YYYYMMDDHHMISS')||
	    	                             SUBSTR(REPLACE(DBMS_RANDOM.VALUE,'.',''),1,5);
		      HOST('/bin/cp '|| LV_EW_DIGI_SIGN_PATH ||' /iashome/ias/reports/printer/'||LV_DIGI_FILE_NAME_VIEW||'.pdf');
		      web.show_document('/printer/'||LV_DIGI_FILE_NAME_VIEW||'.pdf','_blank');
									
					
					RETURN;
				END IF;		
					--GENERAL.DISP_TEXT('DOCUMENT NOT UPLOADED','');
			  ------------- DOCUMENT NOT UPLOADED			
			  lv_user := NAME_IN (':global.userid');	
			  general.disp_text('lv_user='||lv_user||'-'||:CB_BLK.report_name,'mohan');
		  	vcfile := lv_user|| TO_CHAR (SYSDATE, 'YYYYMMDDHHMISS');  
				vcfile := vcfile||'.pdf';	
				SET_REPORT_OBJECT_PROPERTY(repid,REPORT_DESFORMAT,'PDF');
				set_report_object_property(repid,REPORT_DESTYPE,FILE);
				lv_param := 'MODE=BITMAP BLANKPAGES=NO parform=yes '||lv_param;
				:CB_BLK.FILENAME :=LV_PARAM;
				
				SET_REPORT_OBJECT_PROPERTY(repid,REPORT_FILENAME,:CB_BLK.report_name);
				SET_REPORT_OBJECT_PROPERTY(repid,report_other,lv_param);   
				SET_REPORT_OBJECT_PROPERTY(repid,REPORT_SERVER,lv_server);
				set_report_object_property(repid,REPORT_DESNAME,'/iashome/ias/reports/printer/'||vcFile);		
				lv_rep:=RUN_REPORT_OBJECT(repid);	
				web.show_document('/printer/'||vcfile,'_blank');
		END IF;

	end;
END;
```

#### SP-002 - DOWNLOAD_FILE

**Invoked From:**

- vr_ewinv_fmb.xml [ProgramUnit: CALL_REPORT]
- vr_ewinv_fmb.xml [StoredProcedure: CALL_REPORT]

---

**Screen:**

Product Type : (N/A / CN_MAIN)

---

**Purpose**

Transfers a generated report or spreadsheet file from the application server to the user's client machine using WebUtil binary file transfer. Once downloaded, the file can optionally be opened on the client machine. If the transfer fails, the user is notified with a 'File download Failed' error message.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_client_file_name | varchar2 | IN |
| p_server_fname | varchar2 | IN |
| p_OPEN_FILE | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- CLIENT_HOST ([SP-093](#SP-093--CLIENT_HOST)) - matched by member name
- GENERAL.DISP_TEXT ([SP-013](#SP-013--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)
- WEBUTIL_FILE_TRANSFER.AS_TO_CLIENT ([SP-087](#SP-087--WEBUTIL_FILE_TRANSFER.AS_TO_CLIENT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the server-side file path, the intended local destination path on the client machine, and a flag indicating whether the file should be opened after download.
- Step 2 - Call the WebUtil server-to-client file transfer function to copy the file from the server to the local destination path.
- Step 3 - If the transfer fails (function returns false), display 'File download Failed' to the user and stop.
- Step 4 - If the transfer succeeds and the open-file flag is set, invoke the client host to open or process the downloaded file.

---
**Decision Points**

DP-001

Condition: The WebUtil server-to-client file transfer returns a success result.

TRUE: If the open-file flag is set, invoke the client host to open the file.

FALSE: Display 'File download Failed' and stop.

DP-002

Condition: The open-file flag is set to 'Y' (open after download).

TRUE: Invoke CLIENT_HOST to open the downloaded file on the client machine.

FALSE: Return without opening the file.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- The file transfer must succeed before any further action is taken; a failed transfer results in an error message and no attempt to open the file.
- The decision to open the downloaded file on the client is controlled by a flag passed by the caller; the routine does not make this decision independently.

---
**Implementation Logic**

```plsql
PROCEDURE download_file(p_client_file_name in varchar2,p_server_fname in varchar2,p_OPEN_FILE VARCHAR2 DEFAULT 'Y') IS 
  v_success boolean;
	v_filename varchar2(2000);
	v_cmd      varchar2(200);
  v_But  Pls_Integer ;
  
  v_ret WEBUTIL_HOST.PROCESS_ID ;
  v_client_fname  varchar2(500);
Begin	
	
  v_success := Webutil_File_Transfer.AS_TO_CLIENT( clientfile      => p_client_file_name, 
														                       serverfile      => p_server_fname
														                     );														                     
  if not v_success then 
    General.Disp_Text('File download Failed','Error'); 
    Raise Form_Trigger_Failure;
  else
  	null;
  	IF p_OPEN_FILE = 'Y' THEN
  		client_host('cmd /c start ""  "' || p_client_file_name || '"');
  	END IF;
	end if;
END;
```

#### SP-003 - L_POP_LIST_ITEM

**Invoked From:**

- vr_ewinv_fmb.xml [Trigger: KEY-NEXT-ITEM]
- vr_ewinv_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

Product Type : (N/A / CN_MAIN)

---

**Purpose**

A utility routine that rebuilds a named on-screen drop-down list from a dynamically supplied SQL query. It first removes any existing record group with the given name, creates a fresh record group from the query, executes the query to populate it, and loads the result into the specified list item.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_rg_name | VARCHAR2 | IN |
| p_select | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-059](#SP-059--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Check whether a record group with the supplied name already exists; if it does, delete it to start fresh.
- Step 2 - Create a new record group using the supplied SQL query.
- Step 3 - Execute the query to populate the record group with rows from the database.
- Step 4 - Load the populated record group values into the named on-screen list item.

---
**Decision Points**

DP-001

Condition: A record group with the given name already exists.

TRUE: Delete the existing record group before creating a new one.

FALSE: Proceed directly to creating the new record group.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- An existing record group with the same name is always removed before a new one is created to prevent duplicate or stale data in the list item.
- The list item is always refreshed from the current query result each time this routine is called.

---
**Implementation Logic**

```plsql
-- Commented by sanjeev on 14/4/04 for the prototype.

/* 
A common procedure to dynamically retrieve the values from the respective table b4 displaying them in the list items
*/

PROCEDURE l_pop_list_item (p_rg_name VARCHAR2,p_select VARCHAR2 )IS

	 rg_name VARCHAR2(40) := p_rg_name;
	 rg_id RecordGroup;
	 errcode NUMBER; 
BEGIN 
	/* ** Make sure group doesn't already exist */ 
	rg_id := Find_Group( rg_name ); 

	IF NOT Id_Null(rg_id) THEN 
		delete_group(rg_id);
	ELSE
	/* ** If it does not exist, create it and add the two ** necessary columns to it. */ 
		rg_id := Create_Group_From_Query( rg_name, p_select); 
	END IF; 
	/* ** Populate the record group */ 
	errcode := Populate_Group( rg_id );
END;
```

#### SP-004 - PR_PASS_PARAM

**Invoked From:**

- vr_ewinv_fmb.xml [ProgramUnit: CALL_REPORT]
- vr_ewinv_fmb.xml [StoredProcedure: CALL_REPORT]

---

**Screen:**

Product Type : (N/A / CN_MAIN)

---

**Purpose**

Reads the report parameter definitions stored in the central report-configuration table for the current application and principal, and assembles them into the parameter string that will be passed to the Oracle Reports engine. The parameter string is returned to the caller via an IN OUT parameter.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Lv_param | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Lv_param | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Open a cursor over the report parameter configuration table, filtered by the current application identifier and principal code, ordered by sequence number.
- Step 2 - For each parameter definition retrieved, determine the parameter name and its corresponding current value (dealer code, principal, location, programme sub-type, contract month, quarter-year, financial year, or other configured parameters).
- Step 3 - Append the parameter name and its value to the output parameter string in the format expected by the Oracle Reports engine.
- Step 4 - When the cursor is exhausted, close it and return the fully assembled parameter string to the caller.

---
**Decision Points**

DP-001

Condition: A parameter definition row specifies a parameter name that maps to a known session or block value.

TRUE: Append the corresponding current value to the parameter string.

FALSE: Append the parameter's default value or a blank entry as defined in the configuration row.

---
**Database Interactions**

- DB-001 - Read ED_REPORTS - Reads data from ED_REPORTS for lookup or validation.
**Business Rules**

- Only parameter definitions stored in the report-configuration table for the current application and principal are included; no hard-coded parameters are added outside this routine.
- Parameters are appended in the sequence order defined in the configuration table to ensure the report engine receives them in the correct order.

---
**Implementation Logic**

```plsql
PROCEDURE PR_PASS_PARAM(Lv_param IN OUT VARCHAR2) IS
  cursor c1 is
    select param_type, parameter_name, default_value, parameter_datatype
      from ed_reports
     where app_id = 'vr_ewinv'
       and principal_map_cd = :global.principal 
     order by to_number(serial_no);
     
   cursor c2 is
    select param_type, parameter_name, default_value, parameter_datatype
      from ed_reports
     where app_id = 'vr_ccpinv'
       and principal_map_cd = :global.principal 
     order by to_number(serial_no);
     
         
  Lv_frm_date DATE;
  Lv_to_date  DATE;
  L_AlertID   ALERT;
  L_Alert     NUMBER;
  lv_p_ew 		varchar2(1) ;
BEGIN
lv_p_ew :='';

--IF  :CB_BLK.P_EW ='P' THEN --CCP COMMISSION
IF :CB_BLK.EW_CCP  = 'CCP' THEN
	
	if :CB_BLK.P_EW = 'C' THEN
		 lv_p_ew :='P' ;
	ELSE
		lv_p_ew := :CB_BLK.P_EW ;
	END IF;
 	
  For cur_val in c2 Loop
    
    if cur_val.parameter_name = 'P_DEALER' then
      lv_param := lv_param || ' ' || 'P_DEALER=''' || :CB_BLK.P_DEALER || '''';
    end if;
    if cur_val.parameter_name = 'P_PRINCIPAL' then
      lv_param := lv_param || ' ' || 'P_PRINCIPAL=''' || :GLOBAL.PRINCIPAL || '''';
    end if;
  
    if cur_val.parameter_name = 'P_LOC' then
      lv_param := lv_param || ' ' || 'P_LOC=''' || :CB_BLK.P_LOC || '''';
      if :CB_BLK.P_DEALER is null then
        lv_param := lv_param || ' ' || 'P_LOC=''' || 'ALL' || '''';
      end if;
    end if;
    if cur_val.parameter_name = 'P_EW' then
      lv_param := lv_param || ' ' || 'P_EW=''' || lv_p_ew || '''';
    end if;
  
    
    if cur_val.parameter_name = 'P_CONTRACT_MONTH' then
      lv_param := lv_param || ' ' || 'P_CONTRACT_MONTH=''' ||:P_CONTRACT_MONTH || '''';
    end if;
    
    if cur_val.parameter_name = 'P_QTR_YEAR' then
      lv_param := lv_param || ' ' || 'P_QTR_YEAR=''' || :P_QTR_YEAR || '''';
    end if;
    if cur_val.parameter_name = 'P_FIN' then
      lv_param := lv_param || ' ' || 'P_FIN=''' || :FINANCIAL_YEAR || '''';
    end if;
    
  End Loop;

 -- ELSIF  :CB_BLK.P_EW  in ('C','I') THEN --ew commission & ew incentive
 ELSIF 	:CB_BLK.EW_CCP  = 'EW' THEN --EW incentive
  	
  	For cur_val in c1 Loop
  
    if cur_val.parameter_name = 'P_DEALER' then
      lv_param := lv_param || ' ' || 'P_DEALER=''' || :CB_BLK.P_DEALER || '''';
    end if;
    if cur_val.parameter_name = 'P_PRINCIPAL' then
      lv_param := lv_param || ' ' || 'P_PRINCIPAL=''' || :GLOBAL.PRINCIPAL || '''';
    end if;
  
    if cur_val.parameter_name = 'P_LOC' then
      lv_param := lv_param || ' ' || 'P_LOC=''' || :CB_BLK.P_LOC || '''';
      if :CB_BLK.P_DEALER is null then
        lv_param := lv_param || ' ' || 'P_LOC=''' || 'ALL' || '''';
      end if;
    end if;
    if cur_val.parameter_name = 'P_EW' then
      lv_param := lv_param || ' ' || 'P_EW=''' || :P_EW || '''';
    end if;
  
    
      if cur_val.parameter_name = 'P_CONTRACT_MONTH' then
        lv_param := lv_param || ' ' || 'P_CONTRACT_MONTH=''' ||:P_CONTRACT_MONTH || '''';
      end if;
      
      if cur_val.parameter_name = 'P_QTR_YEAR' then
        lv_param := lv_param || ' ' || 'P_QTR_YEAR=''' || :P_QTR_YEAR || '''';
      end if;
      if cur_val.parameter_name = 'P_FIN' then
        lv_param := lv_param || ' ' || 'P_FIN=''' || :FINANCIAL_YEAR || '''';
      end if;

  
  	End Loop;
 END IF;
END;
```

#### SP-005 - UPLOAD_FILE

**Invoked From:**

- vr_ewinv_fmb.xml [ProgramUnit: CALL_REPORT]
- vr_ewinv_fmb.xml [StoredProcedure: CALL_REPORT]

---

**Screen:**

Product Type : (N/A / CN_MAIN)

---

**Purpose**

Transfers a file from the user's client machine to the application server using WebUtil binary file transfer. Returns any error description in an output parameter; a null output means the upload succeeded.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_client_file_name | varchar2 | IN |
| p_server_file_name | varchar2 | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_err_desc | varchar2 | OUT |

---

**Dependencies**

- WEBUTIL_FILE_TRANSFER.CLIENT_TO_AS ([SP-088](#SP-088--WEBUTIL_FILE_TRANSFER.CLIENT_TO_AS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the local client-side file path and the intended server destination path.
- Step 2 - Call the WebUtil client-to-server file transfer function to copy the file from the client machine to the server destination path.
- Step 3 - Return the error description (if any) from the WebUtil transfer in the output parameter; a null value indicates successful transfer.

---
**Decision Points**

N/A - no conditional branches in the documented implementation; the result of the transfer is returned to the caller for evaluation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- The outcome of the file transfer is communicated to the caller via the output error-description parameter; a null value indicates success.
- The routine does not display any message itself; error handling and display are the caller's responsibility.

---
**Implementation Logic**

```plsql
PROCEDURE upload_file (p_client_file_name in varchar2,p_server_file_name in varchar2,p_err_desc out varchar2) IS
  lv_success boolean;
Begin	 
  lv_success := Webutil_File_Transfer.Client_To_AS(clientfile      => p_client_file_name, 
														                       serverfile      => p_server_file_name, 
														                       asynchronous    => false, 
														                       callbacktrigger => null
														                     );
  if not lv_success then 
    p_err_desc:='File Upload Failed'; 
  end if;
EXCEPTION WHEN OTHERS THEN
  	 p_err_desc:='File Upload Failed'; 
END;
```

#### SP-006 - VIEW_EXCEL_REP

**Invoked From:**

- vr_ewinv_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

Product Type : (N/A / CN_MAIN)

---

**Purpose**

Generates a CSV (spreadsheet-compatible) export file from a dynamically provided SQL query and opens it in the user's browser for download. It creates an in-memory record group from the query, writes the result rows to a server-side text file with fixed column headers, transfers the file to the browser, and cleans up the temporary record group. Informational messages are displayed if the file path contains spaces or if the data exceeds 65,535 rows.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_file_name | VARCHAR2 | IN |
| p_query | VARCHAR2 | IN |
| p_column_name | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.FCLOSE ([SP-033](#SP-033--WEBUTIL.FCLOSE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.FOPEN ([SP-036](#SP-036--WEBUTIL.FOPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_LINE ([SP-055](#SP-055--WEBUTIL.GET_LINE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ID_NULL ([SP-059](#SP-059--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.PUT_LINE ([SP-072](#SP-072--WEBUTIL.PUT_LINE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Build the data query for the selected programme type and invoice sub-type against the commission detail views.
- Step 2 - Populate an in-memory record group from the data query using the list-population utility.
- Step 3 - Check whether the target file path contains spaces; if it does, display an informational message and use a fallback path on the C drive.
- Step 4 - Open a text file at the determined path on the server for writing.
- Step 5 - Write the header row with fixed column labels to the file.
- Step 6 - Iterate through each row in the record group and write it as a comma-separated line; stop after 65,535 rows, displaying a truncation informational message.
- Step 7 - Close the output file and release the in-memory record group.
- Step 8 - Open the generated file in the user's browser using the web document display function.

---
**Decision Points**

DP-001

Condition: The target file path contains spaces.

TRUE: Display an informational message and redirect the file to a fallback path on the C drive.

FALSE: Proceed with writing to the originally specified path.

DP-002

Condition: The number of result rows has reached 65,535.

TRUE: Display a truncation informational message and stop writing further rows.

FALSE: Continue writing rows.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- The file path must not contain spaces; if it does, the file is saved to a default fallback location and the user is informed.
- The export is limited to 65,535 rows to stay within the row capacity of the legacy Excel file format; if the data exceeds this limit, the output is truncated and the user is notified.
- The column headers in the exported file are fixed and do not vary by programme type or sub-type.

---
**Implementation Logic**

```plsql
PROCEDURE view_excel_rep(p_file_name VARCHAR2 DEFAULT NULL, p_query VARCHAR2,p_column_name VARCHAR2) IS	
  rg_name 				 		VARCHAR2(10000) := 'DataRecordSet'; 
	rg_id 					 		RecordGroup; 
	gc_id 					 		GroupColumn; 
	urlFile1        TEXT_IO.FILE_TYPE;
	the_rowcount 		 		NUMBER;
	po_tot_rec    NUMBER (6);
	--po_part_tab   pk_part_search_new.part_tab_10;
	po_part_tab   pk_part_search_new.part_tab_11;
	po_err_msg    VARCHAR2 (3000);
	po_err_cd     NUMBER (10);
	low           NUMBER (10);
	high          NUMBER (10);
	remainder     NUMBER (10);
	order_by      VARCHAR2 (300);
	vcfile        varchar2(150);
	lv_user       varchar2(150);
	l_Old_URL     varchar2(500);	
		l_new_URL   varchar2(500);	
	v_string      varchar2(5000);
	bin_str       varchar2(250);
	errcode 				 		NUMBER; 
  FILENAME			   		VARCHAR2(4000);
  MYFILE 					 		TEXT_IO.FILE_TYPE;
  urlFile 					 	TEXT_IO.FILE_TYPE;
  urlPath							VARCHAR2(5000);
	l_alert 				 		NUMBER;
	server_file      		VARCHAR2(2000);
	file_transfer_bool	BOOLEAN;
	formserverpath   		VARCHAR2(2000);
begin
lv_user := name_in(':global.userid');  -- New line added after dpl change
vcFile:= lv_user||To_Char(Sysdate,'YYYYMMDDHHMISS');    -- New line added after dpl change
vcFile := vcFile||'.csv';
if vcFile is null then
	--FILENAME  := Webutil_file.FILE_SAVE_DIALOG;
	null;
else
	filename:=vcFile;
end if;
	If instr(FILENAME,' ') > 0 then
 		FILENAME := 'C:\'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
 		Message('File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default.');
 		message('  ');
	end if;
	
	rg_id := Find_Group( rg_name ); 
	IF NOT Id_Null(rg_id) THEN 
		Delete_Group( rg_id ); 
	END IF; 
	rg_id := Create_Group_From_Query( rg_name, p_query ); 
	errcode := Populate_Group( rg_id ); 
	the_rowcount := Get_Group_Row_Count( rg_id );
	IF the_rowcount > 65536 THEN  
		Message('Maximum number of rows in excel exceeded. It will truncate to 65535 rows.');
		Message('  ');
		CLEAR_MESSAGE;
		the_rowcount := 65535;
	END IF;

	server_file := '/iashome/ias/reports/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	--formserverpath := 'http://10.100.34.230:7778/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	urlFile := Text_Io.Fopen('/reports/DMS/excelpath.txt','R');
	Text_Io.Get_Line(urlFile,urlPath);
	Text_Io.Fclose(urlFile);
	formserverpath := urlPath||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	MYFILE := TEXT_IO.FOPEN(server_file, 'W');
	gc_id := Find_Column( rg_name||'.'||p_column_name); 	
	for total_loop IN 1..the_rowcount
		loop
	  	V_STRING :=  GET_GROUP_CHAR_CELL(gc_id  , total_loop ); 
	  	text_io.put_line(myfile,v_string);
	  	--TEXT_IO.PUTF(MYFILE,V_STRING);  
		end loop;
      text_io.fclose(myfile);
   
	 --	file_transfer_bool := WebUtil_File_Transfer.Url_To_Client(formserverpath,FILENAME);
	/* 	if not file_transfer_bool  then 
	 		message('File Transfer failed');pause;
	 	end if;
	 	WebUtil_Host.HOST('cmd /c '||FILENAME);*/
	 	
	 	web.show_document(formserverpath,'_blank');
	exception
		when others then
		Message('Error  - '||ERROR_CODE|| ERROR_TEXT);
		Raise Form_trigger_failure;
	end;
```

#### SP-007 - D2KWUTIL.ATTEMPT_DLL_LOAD

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Attempts to load a specified DLL into memory via ORA_FFI, optionally verifying the file's physical presence at a given path before loading. The procedure normalises the target path, confirms the DLL file exists using TEXT_IO, loads the library handle, and-when instructed-increments the module-level load counter and marks the API as enabled. It returns the resulting ORA_FFI library handle to the caller (REGISTER_FUNCTION_CALL), allowing dependent foreign-function registrations to proceed only when the DLL is successfully loaded.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |
| TargetDLL | VARCHAR2 | IN |
| LoadCount | BOOLEAN | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |

---

**Dependencies**

- DEBUGLOG ([SP-094](#SP-094--DEBUGLOG)) - matched by member name
- STRIPDIRSEP ([SP-099](#SP-099--STRIPDIRSEP)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Receive the target directory path (TargetPath, IN OUT), the DLL filename (TargetDLL), and a flag indicating whether the load counter should be incremented (LoadCount).
- Step 2 - If TargetPath is not null, normalise it by calling STRIPDIRSEP to remove any existing trailing directory separator, then append a single backslash ('\'), ensuring exactly one separator is present regardless of how the caller supplied the path.
- Step 3 - Attempt to open the file at the concatenated path (TargetPath || TargetDLL) in read mode using TEXT_IO.FOPEN to confirm the DLL physically exists at that location.
- Step 4 - If the file is opened successfully, close it immediately with TEXT_IO.FCLOSE; the check is purely for existence validation and no content is read.
- Step 5 - If the file cannot be opened (any exception), call DEBUGLOG (Win_API_Debug.DebugLog) at severity level 99, logging the procedure name 'Attempt_DLL_LOAD' and a message identifying the DLL and the path where it was not found, then raise the BadLocation exception to abort the load attempt.
- Step 6 - Call ORA_FFI.LOAD_LIBRARY with TargetPath and TargetDLL to load the DLL and obtain a library handle (hDLL).
- Step 7 - If LoadCount is TRUE, increment the module-level counter DLL_LOAD_COUNT by 1 and set the module-level flag API_ENABLED to TRUE, recording that a DLL has been successfully loaded and the API is available.
- Step 8 - Return the populated ORA_FFI library handle to the caller.
- Step 9 - If any unhandled exception occurs during or after the ORA_FFI load attempt, set API_ENABLED to FALSE and return the null library handle, signalling to the caller that the load did not succeed.

---
**Decision Points**

DP-001

Condition: TargetPath IS NOT NULL

TRUE: Normalise the path via STRIPDIRSEP and append a backslash, then perform the physical file-existence check using TEXT_IO before proceeding to load.

FALSE: Skip path normalisation and file-existence verification; proceed directly to ORA_FFI.LOAD_LIBRARY using the null path, allowing ORA_FFI to resolve the DLL from its default search locations.

---

DP-002

Condition: TEXT_IO.FOPEN succeeds for TargetPath || TargetDLL

TRUE: Close the file handle and continue to the ORA_FFI.LOAD_LIBRARY call.

FALSE: Log a diagnostic message via DEBUGLOG at severity 99 identifying the missing DLL and its expected path, then raise BadLocation to halt processing.

---

DP-003

Condition: LoadCount IS TRUE (after a successful ORA_FFI.LOAD_LIBRARY call)

TRUE: Increment DLL_LOAD_COUNT by 1 and set API_ENABLED to TRUE.

FALSE: Skip counter increment and API_ENABLED update; return the library handle without altering load-tracking state.

---

DP-004

Condition: An unhandled exception is raised during or after ORA_FFI.LOAD_LIBRARY

TRUE: Set API_ENABLED to FALSE and return the null library handle to the caller.

FALSE: Normal execution completes; the valid library handle is returned.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A TargetPath supplied by the caller must be normalised to have exactly one trailing backslash before use; STRIPDIRSEP is called to strip any existing trailing separator, and a single backslash is then appended, preventing double-separator or missing-separator path errors.
- BR-002 - When a non-null TargetPath is provided, the physical existence of the DLL file must be confirmed via TEXT_IO before any attempt is made to load it through ORA_FFI; a DLL that cannot be opened at the specified location is treated as an invalid configuration.
- BR-003 - If the DLL file is not found at the specified path, a diagnostic entry must be written via DEBUGLOG at severity level 99, recording the procedure context and the full path that was checked, before the BadLocation exception is raised.
- BR-004 - The module-level load counter (DLL_LOAD_COUNT) must be incremented and API_ENABLED set to TRUE only when LoadCount is TRUE and the DLL load completes without error, ensuring that load-tracking state reflects only successful, intentionally counted loads.
- BR-005 - If any exception occurs after the ORA_FFI load attempt, API_ENABLED must be set to FALSE and a null library handle returned, ensuring the caller cannot proceed with foreign-function registration against an unavailable library.
- BR-006 - Only the first directory path is used when multiple paths may have been concatenated into TargetPath; excess path segments are discarded by the STRIPDIRSEP normalisation step, enforcing a single-path constraint on the input.

---
**Implementation Logic**

```plsql

FUNCTION  Attempt_DLL_Load  (TargetPath in out VARCHAR2, TargetDLL in VARCHAR2, LoadCount in BOOLEAN DEFAULT TRUE) return ORA_FFI.LibHandleType is
  hDLL  ORA_FFI.LibHandleType;
  hFile TEXT_IO.FILE_TYPE;
begin 
    	
  if TargetPath is not null then 
    -- Watch out for folks who put multiple Paths in here 
    -- Oh yes it's happened! Just use the first & throw the rest away
    -- Add trailing Directory Sep if required
    TargetPath := StripDirSep(TargetPath)||'\';
    
    -- Check that there is actually a file there.
    begin 
  	  hFile := TEXT_IO.FOPEN(TargetPath||TargetDLL,'R');
  	  TEXT_IO.FCLOSE(hFile);
    exception
  	  when others then
  	    Win_API_Debug.DebugLog(99,'Attempt_DLL_LOAD',TargetDLL||' not found in the specified location of "'||TargetPath||'"'); 
  		  raise BadLocation;
    end;
  end if;
  
  hDLL := ORA_FFI.LOAD_LIBRARY(TargetPath, TargetDLL);
  if LoadCount then 
    DLL_LOAD_COUNT  := DLL_LOAD_COUNT + 1;
    API_ENABLED  := TRUE;
  end if;
  return hDLL;
exception
  when others then 
    API_ENABLED := FALSE;
    return hDLL; /* Will be null */
end Attempt_DLL_Load;
```

#### SP-008 - D2KWUTIL.D2KWUTIL_DEBUGSTRING

**Invoked From:**

- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level bridge procedure that passes a debug text string to an underlying C-language function registered via the Oracle Foreign Function Interface (ORA_FFI). It is used by the WINDEBUG stored procedure within D2kwutil.pld to emit diagnostic or debug messages through a native external routine, identified by its FFI function handle.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that identifies the registered C routine to be invoked, and the debug text string (Text) to be passed to it.
- Step 2 - Delegate execution to the external C function bound to hFunc via the ORA_FFI PRAGMA INTERFACE directive (interface code 11265), forwarding the Text parameter as the debug message payload.
- Step 3 - Return control to the calling routine (WINDEBUG) upon completion of the external C function call; no output value or database interaction is produced.

---
**Decision Points**

No decision points are present in this procedure. The implementation consists solely of a specification declaration with a PRAGMA INTERFACE directive that unconditionally delegates execution to the bound external C function.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must be invoked with a valid ORA_FFI function handle (hFunc); the handle must have been registered and bound to the external C routine prior to invocation, as the procedure itself performs no handle validation.
- BR-002 - The Text parameter carries the debug string to be emitted externally; no transformation, truncation, or formatting is applied by this procedure before the value is forwarded to the C function.
- BR-003 - This procedure operates exclusively as an FFI pass-through (PRAGMA INTERFACE, C, interface code 11265) and produces no database writes, no output parameters, and no return values.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.
   
 PROCEDURE d2kwutil_DebugString (    hFunc       IN      ORA_FFI.funcHandleType,
                                     Text        IN      VARCHAR2);
 -- Pragmas
 PRAGMA INTERFACE(C,d2kwutil_DebugString,      11265);
```

#### SP-009 - D2KWUTIL.D2KWUTIL_GETDOSENV

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level interface to the underlying operating system environment by invoking an external foreign-function handle to retrieve and expand a DOS/OS environment variable string. The function accepts a source environment variable name and an output buffer, delegates execution to the native library function referenced by hFunc, and returns an integer status code indicating the outcome of the environment variable lookup.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| SourceStr | VARCHAR2 | IN OUT |
| ExpandStr | VARCHAR2 | IN OUT |
| InBuffLen | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| SourceStr | VARCHAR2 | IN OUT |
| ExpandStr | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the foreign-function handle (hFunc) that references the pre-registered native library entry point responsible for resolving OS environment variables.
- Step 2 - Accept the source environment variable name (SourceStr) as an IN OUT parameter to be passed to the native function.
- Step 3 - Accept the expansion buffer (ExpandStr) as an IN OUT parameter that will be populated with the resolved value of the environment variable by the native function.
- Step 4 - Accept the input buffer length (InBuffLen) to define the maximum number of characters the native function may write into ExpandStr.
- Step 5 - Invoke the native function via the supplied hFunc foreign-function handle, passing SourceStr, ExpandStr, and InBuffLen.
- Step 6 - Return a PLS_INTEGER status code to the caller (GET_ENVIRONMENT_STRING in D2kwutil.pld) indicating success or failure of the environment variable retrieval.

---
**Decision Points**

No explicit conditional decision points are determinable from the available specification. The function signature exposes no branching logic; control flow and outcome are governed entirely by the native library function invoked through hFunc, with the integer return value communicating the result to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be invoked with a valid, pre-registered ORA_FFI foreign-function handle (hFunc); no internal handle resolution or registration is performed within this function.
- BR-002 - SourceStr and ExpandStr are declared IN OUT, meaning the caller must supply initialised VARCHAR2 variables and must read back their potentially modified values after the call.
- BR-003 - The caller is responsible for supplying InBuffLen that accurately reflects the allocated size of the ExpandStr buffer to prevent truncation of the resolved environment variable value.
- BR-004 - The integer return value must be evaluated by the caller (GET_ENVIRONMENT_STRING) to determine whether the environment variable was successfully resolved; this function does not raise exceptions internally based on the available specification.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_GetDOSEnv (   hFunc          IN      ORA_FFI.funcHandleType,
                                SourceStr      IN OUT  VARCHAR2,
                                ExpandStr      IN OUT  VARCHAR2,
                                InBuffLen      IN      PLS_INTEGER
                                ) RETURN PLS_INTEGER;
```

#### SP-010 - D2KWUTIL.D2KWUTIL_GETREGKEY

**Invoked From:**

- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

D2KWUTIL_GETREGKEY is a foreign-function interface (FFI) wrapper that reads a Windows Registry key value. Given a registry root, path, and entry name, it retrieves the corresponding registry value into an OUT parameter and returns an integer status code indicating the outcome of the read operation. It is invoked by the READ_REGISTRY stored procedure in D2kwutil.pld to abstract low-level Win32 registry access from the calling Oracle Forms logic.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| RegRoot | PLS_INTEGER | IN |
| RegPath | VARCHAR2 | IN OUT |
| RegEntry | VARCHAR2 | IN OUT |
| RegValue | VARCHAR2 | IN OUT |
| RegValueLength | PLS_INTEGER | IN |
| RegDontExpand | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RegPath | VARCHAR2 | IN OUT |
| RegEntry | VARCHAR2 | IN OUT |
| RegValue | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that references the underlying Win32 registry API entry point, along with the registry root identifier (RegRoot), registry path (RegPath), and registry entry name (RegEntry).
- Step 2 - Pass all input parameters, including the maximum allowable value length (RegValueLength) and the flag controlling environment-variable expansion (RegDontExpand), through the ORA_FFI mechanism to the external Win32 registry function.
- Step 3 - The external function attempts to locate the specified registry entry under the given root and path and writes the retrieved string value into the RegValue IN OUT parameter.
- Step 4 - Return a PLS_INTEGER status code to the caller (READ_REGISTRY) indicating whether the registry read succeeded or failed.

---
**Decision Points**

No explicit decision points are determinable from the available source. Only the function specification is present; no PL/SQL body with conditional branching is exposed. The sole implicit decision is made by the external Win32 function: if the registry key exists and is readable, RegValue is populated and a success code is returned; if the key does not exist or cannot be read, a non-success code is returned. This branching occurs outside the PL/SQL layer and is not directly modelled in the specification.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be invoked with a valid ORA_FFI function handle (hFunc); the handle is obtained and managed by the calling routine READ_REGISTRY before this function is called.
- BR-002 - RegRoot must be a valid Windows Registry root constant (e.g., HKEY_LOCAL_MACHINE, HKEY_CURRENT_USER) expressed as a PLS_INTEGER; no default or fallback root is applied by this function.
- BR-003 - RegValueLength defines the maximum number of characters that may be written into RegValue; the caller is responsible for allocating a RegValue buffer of at least this length before invocation.
- BR-004 - RegDontExpand controls whether environment-variable references embedded in the registry value are expanded; the caller must explicitly set this flag to enforce or suppress expansion.
- BR-005 - The function returns a PLS_INTEGER status code; the caller (READ_REGISTRY) is responsible for interpreting this code and taking appropriate action on failure.
- BR-006 - RegPath and RegEntry are declared IN OUT, meaning the external Win32 function may normalise or modify these strings; callers must not assume the values are unchanged after the call.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_GetRegKey (    hFunc         IN      ORA_FFI.funcHandleType,
                                RegRoot        IN      PLS_INTEGER,
                                RegPath        IN OUT  VARCHAR2,
                                RegEntry       IN OUT  VARCHAR2,
                                RegValue       IN OUT  VARCHAR2,
                                RegValueLength IN      PLS_INTEGER,
                                RegDontExpand	 IN      PLS_INTEGER
                                ) return PLS_INTEGER;
```

#### SP-011 - D2KWUTIL.TRANSLATETYPE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

TranslateType is a lookup function that converts a string-based C data type name into its corresponding ORA_FFI integer constant. It is invoked by REGISTER_FUNCTION_CALL to resolve human-readable type tokens (e.g., 'CHAR', '*INT', 'DOUBLE') into the numeric type identifiers required by the ORA_FFI foreign-function interface layer when registering external C function signatures.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DataType | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameter DataType (VARCHAR2) representing a C data type token supplied by the caller.
- Step 2 - Convert the input value to uppercase and store it in the local variable vcType to ensure case-insensitive matching.
- Step 3 - Evaluate vcType against each recognised C type token in sequence using an IF-ELSIF chain.
- Step 4 - For each matched token, assign the corresponding ORA_FFI integer constant to the local return variable iRC (e.g., '*CHAR' maps to ORA_FFI.C_CHAR_PTR; 'CHAR' maps to ORA_FFI.C_CHAR; '*INT' maps to ORA_FFI.C_INT_PTR; 'INT' maps to ORA_FFI.C_INT; '*LONG' maps to ORA_FFI.C_LONG_PTR; 'LONG' maps to ORA_FFI.C_LONG; '*SHORT' or '*BYTE' maps to ORA_FFI.C_SHORT_PTR; 'SHORT' or 'BYTE' maps to ORA_FFI.C_SHORT; '*DOUBLE' maps to ORA_FFI.C_DOUBLE_PTR; 'DOUBLE' maps to ORA_FFI.C_DOUBLE; '*VOID' maps to ORA_FFI.C_VOID_PTR).
- Step 5 - Return the resolved ORA_FFI integer constant iRC to the caller.

---
**Decision Points**

DP-001
Condition: vcType = '*CHAR'
TRUE: iRC is set to ORA_FFI.C_CHAR_PTR (pointer to character type).
FALSE: Evaluation continues to the next condition.

DP-002
Condition: vcType = 'CHAR'
TRUE: iRC is set to ORA_FFI.C_CHAR (character type).
FALSE: Evaluation continues to the next condition.

DP-003
Condition: vcType = '*INT'
TRUE: iRC is set to ORA_FFI.C_INT_PTR (pointer to integer type).
FALSE: Evaluation continues to the next condition.

DP-004
Condition: vcType = 'INT'
TRUE: iRC is set to ORA_FFI.C_INT (integer type).
FALSE: Evaluation continues to the next condition.

DP-005
Condition: vcType = '*LONG'
TRUE: iRC is set to ORA_FFI.C_LONG_PTR (pointer to long type).
FALSE: Evaluation continues to the next condition.

DP-006
Condition: vcType = 'LONG'
TRUE: iRC is set to ORA_FFI.C_LONG (long type).
FALSE: Evaluation continues to the next condition.

DP-007
Condition: vcType = '*SHORT' OR vcType = '*BYTE'
TRUE: iRC is set to ORA_FFI.C_SHORT_PTR (pointer to short/byte type).
FALSE: Evaluation continues to the next condition.

DP-008
Condition: vcType = 'SHORT' OR vcType = 'BYTE'
TRUE: iRC is set to ORA_FFI.C_SHORT (short/byte type).
FALSE: Evaluation continues to the next condition.

DP-009
Condition: vcType = '*DOUBLE'
TRUE: iRC is set to ORA_FFI.C_DOUBLE_PTR (pointer to double type).
FALSE: Evaluation continues to the next condition.

DP-010
Condition: vcType = 'DOUBLE'
TRUE: iRC is set to ORA_FFI.C_DOUBLE (double type).
FALSE: Evaluation continues to the next condition.

DP-011
Condition: vcType = '*VOID'
TRUE: iRC is set to ORA_FFI.C_VOID_PTR (pointer to void type).
FALSE: No assignment is made; iRC retains its uninitialised NULL value and NULL is returned to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The input DataType token is normalised to uppercase before matching, making type resolution case-insensitive.
- BR-002 - Pointer variants of a C type are denoted by prefixing the type name with an asterisk (e.g., '*INT' for pointer-to-integer); the function treats pointer and value forms as distinct mappings.
- BR-003 - The tokens '*SHORT' and '*BYTE' are treated as equivalent and both resolve to ORA_FFI.C_SHORT_PTR; similarly, 'SHORT' and 'BYTE' both resolve to ORA_FFI.C_SHORT.
- BR-004 - If the supplied DataType token does not match any recognised value, the function returns NULL (no default or error handling is applied).
- BR-005 - The function performs no database interactions and has no side effects; it is a pure lookup utility.

---
**Implementation Logic**

```plsql
 
FUNCTION TranslateType(DataType in VARCHAR2) return PLS_INTEGER is
   -- Just a simple lookup of the types.
   vcType VARCHAR2(10) := UPPER(DataType);
   iRC    PLS_INTEGER;
begin 
  if vcType = '*CHAR' then 
    iRC := ORA_FFI.C_CHAR_PTR;
  elsif vcType = 'CHAR' then 
    iRC := ORA_FFI.C_CHAR;
  elsif vcType = '*INT' then 
    iRC := ORA_FFI.C_INT_PTR;
  elsif vcType = 'INT' then 
    iRC := ORA_FFI.C_INT;
  elsif vcType = '*LONG' then 
    iRC := ORA_FFI.C_LONG_PTR;
  elsif vcType = 'LONG' then 
    iRC := ORA_FFI.C_LONG;
  elsif vcType = '*SHORT' or vcType = '*BYTE'  then 
    iRC := ORA_FFI.C_SHORT_PTR;
  elsif vcType = 'SHORT' or vcType = 'BYTE' then 
    iRC := ORA_FFI.C_SHORT;
  elsif vcType = '*DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE_PTR;
  elsif vcType = 'DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE;  
  elsif vcType = '*VOID' then 
    iRC := ORA_FFI.C_VOID_PTR;      
  end if;
return iRC;
end TranslateType;
```

#### SP-012 - GENERAL.ASK_CONFIRM

**Invoked From:**

- vr_ewinv_fmb.xml [Trigger: FT_CANCEL]
- vr_ewinv_fmb.xml [Trigger: FT_DEL]

---

**Screen:**

N/A

---

**Purpose**

ASK_CONFIRM is a reusable confirmation-dialog function that presents a configurable alert message to the user via the Oracle Forms alert AL_CONFIRM and returns a numeric indicator reflecting the button the user pressed. It is invoked by the FT_CANCEL and FT_DEL triggers in vr_ewinv_fmb to obtain explicit user confirmation before executing a destructive or irreversible action.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| confirm_msg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the caller-supplied confirmation message text through the confirm_msg input parameter.
- Step 2 - Set the runtime message text of the predefined Oracle Forms alert AL_CONFIRM to the value of confirm_msg using SET_ALERT_PROPERTY.
- Step 3 - Display the AL_CONFIRM alert to the user by calling SHOW_ALERT, which suspends processing until the user selects a button; store the returned button identifier in p_albtn_pressed.
- Step 4 - Evaluate p_albtn_pressed: if it equals ALERT_BUTTON1 (the affirmative/confirm button), return 1 to signal that the user confirmed the action.
- Step 5 - If p_albtn_pressed is any value other than ALERT_BUTTON1, return 0 to signal that the user declined or dismissed the action.

---
**Decision Points**

DP-001

Condition: p_albtn_pressed = ALERT_BUTTON1 (the user pressed the first - affirmative - button on the AL_CONFIRM alert).

TRUE: The function returns 1, indicating user confirmation; the calling trigger (FT_CANCEL or FT_DEL) may proceed with the requested operation.

FALSE: The function returns 0, indicating the user did not confirm; the calling trigger should abort or bypass the requested operation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The confirmation message displayed to the user must be supplied by the caller at runtime via the confirm_msg parameter; the function does not define or default the message text internally.
- BR-002 - The alert used for confirmation is exclusively AL_CONFIRM; no other alert mechanism is employed by this function.
- BR-003 - A return value of 1 unambiguously represents user confirmation (ALERT_BUTTON1 pressed); any other button press yields a return value of 0, treating all non-affirmative responses as a rejection.
- BR-004 - The function must be invoked before any destructive operation (cancellation or deletion) is executed, as enforced by its placement in the FT_CANCEL and FT_DEL triggers of vr_ewinv_fmb.

---
**Implementation Logic**

```plsql
FUNCTION ASK_CONFIRM( confirm_msg VARCHAR2)
                                      RETURN  NUMBER IS

    p_alert_name varchar2(10) := 'AL_CONFIRM' ;
    p_albtn_pressed number;
BEGIN
   set_alert_property(p_alert_name,alert_message_text,confirm_msg); 
   p_albtn_pressed := show_alert(p_alert_name);

   IF ( p_albtn_pressed = ALERT_BUTTON1 ) THEN
      return (1);
   ELSE
      return(0);
   END IF;
RETURN NULL; END;
```

#### SP-013 - GENERAL.DISP_TEXT

**Invoked From:**

- vr_ewinv_fmb.xml [ProgramUnit: CALL_REPORT]
- vr_ewinv_fmb.xml [ProgramUnit: DOWNLOAD_FILE]
- vr_ewinv_fmb.xml [ProgramUnit: PR_REMOVE_ASCII_CHR]
- vr_ewinv_fmb.xml [StoredProcedure: CALL_REPORT]
- vr_ewinv_fmb.xml [StoredProcedure: DOWNLOAD_FILE]
- DPL.pld [StoredProcedure: GENERAL.RAISE_ERROR]
- vr_ewinv_fmb.xml [Trigger: FT_INSERT]
- vr_ewinv_fmb.xml [Trigger: KEY-LISTVAL]
- vr_ewinv_fmb.xml [Trigger: KEY-NEXT-ITEM]
- vr_ewinv_fmb.xml [Trigger: ON-ERROR]
- vr_ewinv_fmb.xml [Trigger: ON-MESSAGE]
- vr_ewinv_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]
- vr_ewinv_fmb.xml [Trigger: WHEN-LIST-CHANGED]
- vr_ewinv_fmb.xml [Trigger: WHEN-NEW-ITEM-INSTANCE]

---

**Screen:**

Product Type : (N/A / CN_MAIN)

---

**Purpose**

Displays a modal alert to the user with a supplied message text and title. The alert style is determined by the title: messages titled 'Error' use the error-style alert (AL_ERRINFO), and all other titles use the informational-style alert (AL_NOTE). This is the standard notification mechanism used throughout the form for all user-facing messages.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| text_string | VARCHAR2 | IN |
| title_string | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message text and the title/severity label to display.
- Step 2 - Determine the appropriate alert style: use the error-style alert for titles of 'Error', and the informational-style alert for all other titles.
- Step 3 - Set the alert message text on the chosen alert.
- Step 4 - Display the modal alert to the user and wait for acknowledgement.

---
**Decision Points**

DP-001

Condition: The supplied title is 'Error'.

TRUE: Use the error-style alert (AL_ERRINFO) to display the message.

FALSE: Use the informational-style alert (AL_NOTE) to display the message.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- The alert style is determined solely by the title parameter; 'Error' always uses the error-style alert, all other titles use the informational alert.
- The routine does not raise FORM_TRIGGER_FAILURE itself; callers are responsible for stopping further processing after displaying an error message if required.

---
**Implementation Logic**

```plsql
PROCEDURE DISP_TEXT (text_string VARCHAR2,
                     title_string VARCHAR2 ) IS 
   p_alert_name varchar2(10) := 'AL_ERRINFO' ; 
   p_alert_id number;
BEGIN
   if upper(title_string)='ERROR' then
      p_alert_name := 'AL_ERRINFO' ; 
   else
      p_alert_name := 'AL_NOTE' ; 
   end if;
   set_alert_property(p_alert_name,TITLE,title_string);  
   set_alert_property(p_alert_name,alert_message_text,text_string);  
   p_alert_id := show_alert(p_alert_name); 
END;
```

#### SP-014 - GENERAL.RAISE_ERROR

**Invoked From:**

- vr_ewinv_fmb.xml [Trigger: ON-ERROR]

---

**Screen:**

N/A

---

**Purpose**

Constructs a formatted error message by concatenating the supplied message code with any associated message text, determines the message severity from the type code (Error, Note, or Caution), displays the message to the user via GENERAL.DISP_TEXT, and - for Error-type messages - raises FORM_TRIGGER_FAILURE to halt further processing. Invoked from the ON-ERROR trigger to handle catalogued business errors surfaced during form execution.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| mesg_code | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-013](#SP-013--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message code (mesg_code) as the sole input parameter.
- Step 2 - Construct the display message text by concatenating mesg_code, the literal ' : ', and the mesg_text variable (note: the GENERAL.get_message call that would populate mesg_text and mesg_type is commented out in the current implementation, so mesg_text remains uninitialised and mesg_type defaults to NULL at runtime).
- Step 3 - Evaluate the mesg_type value to determine the appropriate title and processing path.
- Step 4 - If mesg_type is 'E', set the title to 'Error', call GENERAL.DISP_TEXT with the constructed message and title, then raise FORM_TRIGGER_FAILURE to stop further processing.
- Step 5 - If mesg_type is 'N', set the title to 'Note' and call GENERAL.DISP_TEXT with the constructed message and title; processing continues normally.
- Step 6 - If mesg_type is 'C', set the title to 'Caution' and call GENERAL.DISP_TEXT with the constructed message and title; processing continues normally.
- Step 7 - If mesg_type matches none of the recognised codes, no alert is displayed and processing continues without interruption.

---
**Decision Points**

DP-001

Condition: mesg_type equals 'E' (Error).

TRUE: Set title to 'Error', invoke GENERAL.DISP_TEXT to display the message, then raise FORM_TRIGGER_FAILURE to stop processing.

FALSE: Evaluate whether mesg_type is 'N'.

DP-002

Condition: mesg_type equals 'N' (Note).

TRUE: Set title to 'Note', invoke GENERAL.DISP_TEXT to display the message; do not raise FORM_TRIGGER_FAILURE.

FALSE: Evaluate whether mesg_type is 'C'.

DP-003

Condition: mesg_type equals 'C' (Caution).

TRUE: Set title to 'Caution', invoke GENERAL.DISP_TEXT to display the message; do not raise FORM_TRIGGER_FAILURE.

FALSE: No alert is displayed and no exception is raised (unrecognised or NULL type code).

---
**Database Interactions**

- DB-001 - Read AM_PERMISSIONS - Reads data from AM_PERMISSIONS for lookup or validation.
**Business Rules**

- BR-001 - The displayed message text is always prefixed with the original message code followed by ' : ', ensuring the code is visible to the user regardless of whether additional message text is available.
- BR-002 - Error-type messages (mesg_type = 'E') must always terminate further trigger processing by raising FORM_TRIGGER_FAILURE after the alert is displayed.
- BR-003 - Note-type and Caution-type messages are informational only; they are displayed via GENERAL.DISP_TEXT but do not interrupt processing.
- BR-004 - All user-facing alert display is delegated exclusively to GENERAL.DISP_TEXT (SP-013); no direct Oracle Forms alert calls are made within this procedure.
- BR-005 - The GENERAL.get_message call responsible for populating mesg_text and mesg_type is currently disabled (commented out); as a result, mesg_type will be NULL at runtime and no branch of the conditional will be entered unless this call is reinstated.

---
**Implementation Logic**

```plsql
PROCEDURE RAISE_ERROR ( mesg_code IN VARCHAR2 )IS
  mesg_type  varchar2(7); 
  mesg_text  varchar2(200) ;
  mesg_title varchar2(7);
  BEGIN
     -- murali 17.05.04 GENERAL.get_message(mesg_code,mesg_text,mesg_type );
     mesg_text:=mesg_code||' : '||mesg_text;		
     IF ( mesg_type = 'E' ) THEN
        mesg_title := 'Error' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
        raise FORM_TRIGGER_FAILURE;
     ELSIF ( mesg_type = 'N' ) THEN
        mesg_title := 'Note' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     ELSIF ( mesg_type = 'C' ) THEN
        mesg_title := 'Caution' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     END IF;
  END;     

/* PROCEDURE check_rights( 
pi_form_name in varchar2,
pi_user_id in number) IS
lv_x varchar2(1);
BEGIN
	
	begin
	SELECT substr(access_string, pi_user_id,1) 
	INTO   lv_x
	FROM   	am_permissions
	WHERE  form_name = pi_form_name
	AND SUBSTR(access_string,pi_user_id,1)='Y';
	exception 
		when no_data_found then
		  general.disp_text('You do not have the Permission to access this.','Error rr');
		  raise form_trigger_failure; 
		when too_many_rows then
		  general.disp_text('Many rows in USER_PERMISSIONS','Error ss');
		  raise form_trigger_failure;
		when others then
		       general.disp_text(sqlerrm,'Error mm');
		       raise form_trigger_failure;
	end;

	open_form(pi_form_name,activate,session);
END;
*/
```

#### SP-015 - WEBUTIL.BLOCKING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.HOST]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Blocking capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.EXECUTE ([SP-031](#SP-031--WEBUTIL.EXECUTE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Blocking operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  
  FUNCTION  Blocking(cmd in VARCHAR2) return PROCESS_ID is
  begin
    return Execute(cmd,BLOCKING_MODE);
  end Blocking;
```

#### SP-016 - WEBUTIL.BOOLTOSTR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.DOWNLOADINT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Booltostr capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| boolValue | BOOLEAN | IN |
| trueValue | VARCHAR2 | IN |
| falseValue | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Booltostr operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql

  FUNCTION BoolToStr (boolValue  in BOOLEAN, 
                      trueValue  in VARCHAR2 default 'true', 
                      falseValue in VARCHAR2 default 'false') return VARCHAR2 is
  BEGIN
    if boolValue is null or not boolValue then 
        return falseValue;
    else
        return trueValue;
    end if;
  END BoolToStr;     
  
END WEBUTIL_UTIL;
```

#### SP-017 - WEBUTIL.CHECKASACL

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.DOWNLOADINT]
- webutil.pld [StoredProcedure: WEBUTIL.UPLOADINT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Checkasacl capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| ASFile | VARCHAR2 | IN |
| acl | aclType | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| acl | aclType | IN OUT |

---

**Dependencies**

- WEBUTIL.GETSERVERFILESEP ([SP-049](#SP-049--WEBUTIL.GETSERVERFILESEP)) - WEBUTIL.pck (or .pld)
- WEBUTIL.INIT ([SP-060](#SP-060--WEBUTIL.INIT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LENGTH ([SP-065](#SP-065--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Checkasacl operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql

  FUNCTION checkASACL(ASFile          in     VARCHAR2,
                      acl           in out aclType) return BOOLEAN is
    result        BOOLEAN := FALSE;                    
    allowedDir    VARCHAR2(1024);
    allowedDirLen PLS_INTEGER;
    fname         VARCHAR2(1024);
    sep           VARCHAR2(1);
  BEGIN
    if ASFile is null then
      -- There is no default application server file name. Null cannot be used.
      return false;
    end if;
    if m_ASEnabled then 
      if m_ASUseACL then 
        -- add a trailing separator so that c:\temp will also match
        -- with c:\temp\. Earlier trailing separator was added to acl
        -- so that c:\temp1 does not become a subdirectory of c:\temp
        -- or c:\temp1 does not match with c:\temp. Note: file need
        -- not be directory. It could be c:\temp\test.txt.
        -- There is no harm in appending a separator since we are going
        -- to substr before comparing.
        sep := WebUtil_Core.getServerFileSep;
        fname := ASFile || sep;
        for i in 1..acl.COUNT LOOP
          allowedDir    := acl(i);
          allowedDirLen := length(allowedDir);
          if m_windows then -- case insensitive
            if lower(substr(fname,1,allowedDirLen)) = lower(allowedDir) then 
              result := true;
              EXIT;
            end if;
          else
            if substr(fname,1,allowedDirLen) = allowedDir then 
              result := true;
              EXIT;
            end if;
          end if;
        end LOOP;
      else
        result := true;
      end if;      
    end if;
      
    return result;
  end checkASACL;           
      
  
BEGIN
  -- Core initialisation
  WebUtil_Core.Init;
  -- Initialisation of ACL etc for this package        
  init;
END WEBUTIL_FILE_TRANSFER;

PACKAGE WEBUTIL_HOST IS
/*********************************************************************************\
 * WEBUTIL_HOST
 *   This Package contains routines to execute "host" commands on the client
 *   Calls may be blocking or asynchronous and if aysnchronous may have a 
 *   callback mode e.g. You fire off the process on the client and when it 
 *   has finished a user named trigger will execute
 *********************************************************************************
 * Version 1.0.2
 *********************************************************************************
 * Change History
 *   1.0.0 DRMILLS 27/JAN/2003 - Creation
 *   1.0.1 DRMILLS 01/MAR/2003 - Slight API changes
 *   1.0.2 DRMILLS 17/MAY/2003 - Added call to WebUtil_Core.Init
 *
\*********************************************************************************/

  /*
   * Types
   */
   
  /**
   * PROCESS_ID is a type to represent a process so that you can do 
   * things like get the return code and error output and also kill it
   */    
  type PROCESS_ID is record (handle PLS_INTEGER);

  /**
   * OUTPUT_ARRAY is used to return the Standard Out and Standard Error output 
   * from a host command - each line of the output will appear as a member of this array
   */    
  type OUTPUT_ARRAY is table of VARCHAR2(256 char) index by binary_integer;

  /*
   * Functions 
   */

  /**
   * HOST function is closest to the old client/server Host.
   * It blocks the Forms client until the host call is finished.
   * This version returns with the return code from the client
   */
```

#### SP-018 - WEBUTIL.CHECKJAVA

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.DOWNLOADINT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Checkjava capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.EXISTS_ ([SP-032](#SP-032--WEBUTIL.EXISTS_)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Checkjava operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql

  FUNCTION checkJava return BOOLEAN is
    classpath   VARCHAR2(4096 char);
    jarpos      PLS_INTEGER := 0;
    iStart      PLS_INTEGER := 0;
    iEnd        PLS_INTEGER := 0;      
    pathSep     VARCHAR2(1 CHAR);
    webUtilPath VARCHAR2(1024);
    jFile       ORA_JAVA.JOBJECT;
  BEGIN
    if m_javaOK is null then       
      m_javaOK := false;
      classpath := JAVA_SYSTEM.getProperty('java.class.path');
      pathSep   := JAVA_SYSTEM.getProperty('path.separator');      
      if pathSep = ';' then /* win32 */ 
        classpath := lower(classpath);
      end if;

      jarpos := instr(classpath,'frmwebutil.jar');
   
      if jarpos = 0 then 
        WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE,134,'WEBUTIL_CORE.checkJava','frmwebutil.jar');
      else
        -- So we know that frmwebutil.jar is mentioned in the classpath let's check 
        -- to see if it actually is where the admin has said it is - this will 
        -- also check that Java can run at all. 
        iStart := instr(substr(classpath,1,jarPos),pathSep,-1,1);
        iEnd   := instr(classpath,pathSep,jarPos,1);          
        webUtilPath := substr(classpath,iStart+1,(iEnd-iStart)-1);
        jFile := JAVA_FILE.New(webUtilPath);
        if JAVA_FILE.Exists_(jFile) then
          m_javaOK := true;
        else
          -- frmwebutil.jar in classpath, but not physically found
          WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE,135,'WEBUTIL_CORE.checkJava',webUtilPath);
        end if;
      end if;
    end if;  
    return m_javaOK;
  EXCEPTION
    when ORA_JAVA.JAVA_ERROR then 
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE,122,'WEBUTIL_CORE.checkJava');
    when ORA_JAVA.EXCEPTION_THROWN then 
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE,122,'WEBUTIL_CORE.checkJava');
  END checkJava;
```

#### SP-019 - WEBUTIL.CHECKLIBS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Checklibs capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.DOWNLOADFROMURLINT ([SP-026](#SP-026--WEBUTIL.DOWNLOADFROMURLINT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTSETTING ([SP-040](#SP-040--WEBUTIL.GETCLIENTSETTING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-066](#SP-066--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-074](#SP-074--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READTRANSFROMMSGBUNDLE ([SP-075](#SP-075--WEBUTIL.READTRANSFROMMSGBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETCLIENTSETTING ([SP-080](#SP-080--WEBUTIL.SETCLIENTSETTING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Checklibs operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  
  PROCEDURE CheckLibs(packageID in VARCHAR2 ) is
    lib          PLS_INTEGER := 1;
    libSpec      VARCHAR2(200 char);
    libName      VARCHAR2(100 char);
    libSize      PLS_INTEGER;
    libVer       VARCHAR2(20 char);
    installedVer VARCHAR2(20 char);
    libProg      BOOLEAN := false;
    downloadURL  VARCHAR2(1000);
  BEGIN
    -- Read through the property bundle for 
    -- any libraries for this package
    LOOP
      libSpec := readFromPropertyBundle('install.syslib.'||to_char(m_clientOSFamily)||'.'||
             to_char(m_clientOSArch)||'.'||packageID||'.'||to_char(lib));
      if libSpec is null then
        libSpec := readFromPropertyBundle('install.syslib.'||to_char(m_clientOSFamily)||'.'||
             packageID||'.'||to_char(lib));
      end if;
      if libSpec is null then 
        exit;
      end if;
      lib := lib + 1;
      libName := Delimstr.getString(libSpec,1,true,'|');
      libSize := Delimstr.getNumber(libSpec,2,true,'|');
      libVer  := Delimstr.getString(libSpec,3,true,'|');
      libProg := (upper(Delimstr.getString(libSpec,4,true,'|'))='TRUE');

      -- OK we now have the library information
      -- let's check if it's installed
      installedVer := GetClientSetting('syslib.'||libname);
      if installedVer is null or installedVer <> libVer or REDOWNLOAD_SYSLIB then 
        -- need to download
        downloadURL := readFromPropertyBundle('install.syslib.location' || '.' || to_char(m_clientOSFamily) ||
                             '.' || to_char(m_clientOSArch));
        if downloadURL is null then
          downloadURL := readFromPropertyBundle('install.syslib.location' || '.' || to_char(m_clientOSFamily));
        end if;
        if downloadURL is null then
          downloadURL := readFromPropertyBundle('install.syslib.location');
        end if;
        if DownLoadFromURLInt(downloadURL||'/'||libName, 
                              libName,
                              1, -- syslib install download, special location
                              libSize,
                              libProg,
                              ReadTransFromMsgBundle('INST_PGRS_TITLE'),
                              ReadTransFromMsgBundle('INST_PGRS_SUBTITLE'),     
                              libName) then 
          SetClientSetting('syslib.'||libname,libVer);
        else
          log('Download of system library '||libName||' failed',true);
        end if;                          
      end if;
    END LOOP;
  END CheckLibs;
```

#### SP-020 - WEBUTIL.CLEARCALLBACKTRIGGER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Clearcallbacktrigger capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| callbackKey | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Clearcallbacktrigger operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ClearCallbackTrigger(callbackKey in PLS_INTEGER) is
  begin
    if m_callbacks.exists(callbackKey) then 
      m_callbacks.delete(callbackKey);  
    end if;
  end ClearCallbackTrigger;
```

#### SP-021 - WEBUTIL.CLOSEBLOB

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Closeblob capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| checksum | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Closeblob operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql

  FUNCTION  CloseBlob(checksum in PLS_INTEGER) return BOOLEAN is
  BEGIN
    return WebUtil_DB.CloseBlob(checksum);
  END CloseBlob;
```

#### SP-022 - WEBUTIL.CLOSEFILE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Closefile capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Closefile operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  FUNCTION closeFile(
    obj   ORA_JAVA.JOBJECT) RETURN BOOLEAN IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_BOOLEAN_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'closeFile', '()Z', args); 
  END;
```

#### SP-023 - WEBUTIL.CREATETEMPFILE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.DOWNLOADINT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Createtempfile capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |
| a1 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Createtempfile operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  FUNCTION createTempFile(
    a0    VARCHAR2,
    a1    VARCHAR2) RETURN ORA_JAVA.JOBJECT IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(2);
    JNI.ADD_STRING_ARG(args, a0);
    JNI.ADD_STRING_ARG(args, a1);
    RETURN JNI.CALL_OBJECT_METHOD(TRUE, NULL, 'java/io/File', 'createTempFile', '(Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;', args); 
  END;
```

#### SP-024 - WEBUTIL.DECODEBASE64FILE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.UPLOADINT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Decodebase64File capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Decodebase64File operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  FUNCTION decodeBASE64File(
    obj   ORA_JAVA.JOBJECT,
    a0    VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_BOOLEAN_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileWriter', 'decodeBASE64File', '(Ljava/lang/String;)Z', args); 
  END;
```

#### SP-025 - WEBUTIL.DELETE_

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.DOWNLOADINT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Delete  capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Delete  operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  FUNCTION delete_(
    obj   ORA_JAVA.JOBJECT) RETURN BOOLEAN IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_BOOLEAN_METHOD(FALSE, obj, 'java/io/File', 'delete', '()Z', args); 
  END;
```

#### SP-026 - WEBUTIL.DOWNLOADFROMURLINT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Downloadfromurlint capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| specialDestination | PLS_INTEGER | IN |
| fileSize | PLS_INTEGER | IN |
| withProgress | BOOLEAN | IN |
| progressTitle | VARCHAR2 | IN |
| progressSubTitle | VARCHAR2 | IN |
| progressMessage | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Downloadfromurlint operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  
  FUNCTION DownLoadFromURLInt(sourceURL          in VARCHAR2, 
                              clientDestination  in VARCHAR2, 
                              specialDestination in PLS_INTEGER default 0,                             
                              fileSize           in PLS_INTEGER default 0, 
                              withProgress       in BOOLEAN default false,
                              progressTitle      in VARCHAR2 default null,
                              progressSubTitle   in VARCHAR2 default null,
                              progressMessage    in VARCHAR2 default null) return BOOLEAN is
    result       VARCHAR2(6) := 'FALSE';
    submitString VARCHAR2(4000 char);
    sep          VARCHAR2(1) := '|';
  BEGIN
    if sourceURL is null then
      raise URL_NULL;
    end if;
    if clientDestination is null then
      raise CLIENT_FILE_NULL;
    end if;

    if specialDestination is null or specialDestination < 0 or specialDestination > 2 then 
      submitString := '0'||sep;
    else
      submitString := to_char(specialDestination)||sep;
    end if;
    if fileSize is null then 
      submitString := submitString||'0'||sep;
    else
      submitString := submitString||to_char(fileSize)||sep;
    end if;
    if withProgress is null or not withProgress then 
      submitString := submitString||'N'||sep;
    else
      submitString := submitString||'Y'||sep;
    end if;    

    submitString := submitString||sourceURL
                    ||sep||clientDestination
                    ||sep||nvl(progressTitle,' ')
                    ||sep||nvl(progressSubTitle,' ')
                    ||sep||nvl(progressMessage,' ');                         
  WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_URL_DOWNLOAD',submitString,true);
  result := WebUtil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_URL_DOWNLOAD');
  return (result='TRUE');
  EXCEPTION  
    when CLIENT_FILE_NULL then
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE, 130, 'WEBUTIL_CORE.DownloadFromURLInt');
      return false;
    when URL_NULL then
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE,25, 'WEBUTIL_CORE.DownloadFromURLInt');
      return false;

    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                              ||' bean not found. WEBUTIL_CORE.DownloadFromURLInt will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;
  END DownLoadFromURLInt;
```

#### SP-027 - WEBUTIL.DOWNLOADINT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_FILE_TRANSFER.AS_TO_CLIENT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Downloadint capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| clientFile | VARCHAR2 | IN |
| spec1 | VARCHAR2 | IN |
| spec2 | VARCHAR2 | IN |
| spec3 | VARCHAR2 | IN |
| fromDB | BOOLEAN | IN |
| withProgress | BOOLEAN | IN |
| progressTitle | VARCHAR2 | IN |
| progressSubTitle | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.BOOLTOSTR ([SP-016](#SP-016--WEBUTIL.BOOLTOSTR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.CHECKASACL ([SP-017](#SP-017--WEBUTIL.CHECKASACL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.CHECKJAVA ([SP-018](#SP-018--WEBUTIL.CHECKJAVA)) - WEBUTIL.pck (or .pld)
- WEBUTIL.CREATETEMPFILE ([SP-023](#SP-023--WEBUTIL.CREATETEMPFILE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.DELETE_ ([SP-025](#SP-025--WEBUTIL.DELETE_)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ENCODEBASE64FILE ([SP-028](#SP-028--WEBUTIL.ENCODEBASE64FILE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.FILE_IS_DIRECTORY ([SP-034](#SP-034--WEBUTIL.FILE_IS_DIRECTORY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTFILESEP ([SP-038](#SP-038--WEBUTIL.GETCLIENTFILESEP)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETPATH ([SP-047](#SP-047--WEBUTIL.GETPATH)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETSOURCECHUNKS ([SP-050](#SP-050--WEBUTIL.GETSOURCECHUNKS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETSOURCELENGTH ([SP-051](#SP-051--WEBUTIL.GETSOURCELENGTH)) - WEBUTIL.pck (or .pld)
- WEBUTIL.IN_PROGRESS ([SP-062](#SP-062--WEBUTIL.IN_PROGRESS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.NEW ([SP-067](#SP-067--WEBUTIL.NEW)) - WEBUTIL.pck (or .pld)
- WEBUTIL.OPENBLOB ([SP-068](#SP-068--WEBUTIL.OPENBLOB)) - WEBUTIL.pck (or .pld)
- WEBUTIL.OPENFILE ([SP-069](#SP-069--WEBUTIL.OPENFILE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READDATA ([SP-073](#SP-073--WEBUTIL.READDATA)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Downloadint operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql

  FUNCTION DownloadInt
                     ( clientFile       in VARCHAR2, 
                       spec1            in VARCHAR2, 
                       spec2            in VARCHAR2,
                       spec3            in VARCHAR2,
                       fromDB           in BOOLEAN,
                       withProgress     in BOOLEAN,
                       progressTitle    in VARCHAR2,
                       progressSubTitle in VARCHAR2) return BOOLEAN is
    result           BOOLEAN := false;
    dummybool        BOOLEAN;                      
    fileSize         PLS_INTEGER := 0; 
    fileChunks       PLS_INTEGER := 0;     
    buffer           VARCHAR2(32767);
    subBuffer        VARCHAR2(32767);
    clientFileInfo   VARCHAR2(1000 char);
    jobj             ORA_JAVA.JOBJECT;
    lastErrorCode    PLS_INTEGER;
    lastErrorArgs    VARCHAR2(1000);    
    parent_dir       VARCHAR2(1000);
    encodedFile      ORA_JAVA.JOBJECT;
    ftemp            TEXT_IO.FILE_TYPE;
    tempFileName     VARCHAR2(512);
    
  BEGIN
    -- Client file cannot be null.
    if clientFile is NULL then
        raise CLIENT_FILE_NULL;
    end if;

    -- Application server file cannot be null. AppServerFileReader.java also handles this.
    -- Handling here is better.
    if NOT fromDB AND spec1 is null then
        raise AS_FILE_NULL;
    end if;

    -- Make sure that the given client file path is not a directory and parent directory exists
    parent_dir := substr(clientFile, 1, instr(clientFile, WebUtil_Core.getClientFileSep, -1));
    if WEBUTIL_FILE.file_is_directory(clientFile)
         OR NOT WEBUTIL_FILE.file_is_directory (parent_dir) then
        raise INVALID_CLIENT_FILE_DIR;
    end if;

    -- First check to see if a transfer is not currently happening
    if In_Progress then 
        raise AGENT_BUSY;
    end if;

    -- Open the correct source & get the file size
    if fromDB then
      if not m_DBEnabled then 
        raise TRANSFER_FORBIDDEN;
      end if;
      if  not WebUtil_DB_Local.openblob(spec1, spec2, spec3,'R', m_maxTransferSize) then 
        lastErrorCode := WebUtil_DB_Local.getLastError;
        WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                           'WEBUTIL_FILE_TRANSFER.DownloadInt',spec1||'.'||spec2||' - Where '||spec3);
        raise READWRITE_ERROR;
      end if;
      fileSize   := WebUtil_DB_Local.getSourceLength;
      fileChunks := WebUtil_DB_Local.getSourceChunks; 
    else
      if not WebUtil_Core.checkJava then 
        raise NO_JAVA;
      end if;        
      if not checkASACL(spec1,m_readACL) then 
        raise TRANSFER_FORBIDDEN;
      end if;    
      jobj := JAVA_APPSERV_READER.NEW;
      if not JAVA_APPSERV_READER.openFile(jobj,spec1,m_maxTransferSize) then 
        lastErrorCode := JAVA_APPSERV_READER.getLastError(jobj);
        lastErrorArgs := JAVA_APPSERV_READER.getLastErrorArgs(jobj) ;
        WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                           'WEBUTIL_FILE_TRANSFER.DownloadInt',lastErrorArgs);
        raise READWRITE_ERROR;
      end if;   
      fileSize   := JAVA_APPSERV_READER.getSourceLength(jobj);
      fileChunks := JAVA_APPSERV_READER.getSourceChunks(jobj);       
    end if; -- fromDB
      
    -- construct and send the fileinfo string to the client
    clientFileInfo := clientFile||'|'||to_char(fileSize)||'|N'||
                      WebUtil_Util.BoolToStr(withProgress,'|Y|','|N|')||
                      progressTitle||'|'||progressSubTitle;
    WebUtil_Core.setProperty(WebUtil_Core.WUT_PACKAGE,'WUT_FILE_INFO',clientFileInfo,false);
    if WebUtil_Core.IsError then
      if not fromDB then
        -- close the application server file.
        dummybool := JAVA_APPSERV_READER.CLOSEFILE(jobj);
      end if;
      raise CLIENT_ERROR;
    end if;
      
    if NOT fromDB then
       encodedFile := JAVA_FILE.createTempFile('WUAS','.enc');
       tempFileName := JAVA_FILE.getPath(encodedFile);
    end if;

    -- Now loop through and get each buffer full of data
    for i in 1..fileChunks LOOP
      if fromDB then 
        buffer := WebUtil_DB_Local.ReadData;
      else
        --buffer := JAVA_APPSERV_READER.ReadData(jobj);
        if not JAVA_APPSERV_READER.encodeBASE64File(jobj,tempFileName) then
          lastErrorCode := JAVA_APPSERV_WRITER.getLastError(jobj);
          lastErrorArgs := JAVA_APPSERV_WRITER.getLastErrorArgs(jobj) ;
          WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                             'WEBUTIL_FILE_TRANSFER.UploadInt',lastErrorArgs);
          raise READWRITE_ERROR;
        end if;
        ftemp := TEXT_IO.FOPEN(tempFileName, 'R');
        buffer := '';
        begin  -- SUB LOOP
          loop
            TEXT_IO.GET_LINE(ftemp, subBuffer);
            buffer := buffer || chr(10) || subBuffer;
          end loop;
        exception
          when NO_DATA_FOUND then
            null; -- no need to do anything
        end; -- SUB LOOP
        TEXT_IO.FCLOSE(ftemp);
      end if; -- fromDB

      -- push the data to the client
      WebUtil_Core.setProperty(WebUtil_Core.WUT_PACKAGE,'WUT_TRANSFER',buffer, false);
      if WebUtil_Core.isError then
        if not fromDB then
           -- close the application server file.
           dummybool := JAVA_APPSERV_READER.CLOSEFILE(jobj);
           dummyBool := JAVA_FILE.DELETE_(encodedFile);
        end if;
        raise CLIENT_ERROR;
      end if;
    end LOOP;
    result := true;
      
    if not fromDB then 
    result := JAVA_APPSERV_READER.CloseFile(jobj);
    dummyBool := JAVA_FILE.DELETE_(encodedFile);
    end if;
      
    return result;
  EXCEPTION
    when INVALID_CLIENT_FILE_DIR then
      WebUtil_Core.Error(Webutil_Core.WUT_PACKAGE,131,'WEBUTIL_FILE_TRANSFER.DownloadInt', clientFile);
      return false;
    when CLIENT_FILE_NULL then
      WebUtil_Core.Error(Webutil_Core.WUT_PACKAGE,130,'WEBUTIL_FILE_TRANSFER.DownloadInt');
      return false;
    when AS_FILE_NULL then
      WebUtil_Core.Error(Webutil_Core.WUT_PACKAGE,117,'WEBUTIL_FILE_TRANSFER.DownloadInt');
      return false;
    when TRANSFER_FORBIDDEN then 
      WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,121,'WEBUTIL_FILE_TRANSFER.DownloadInt');
      return false;                
    when AGENT_BUSY then 
      WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,116,'WEBUTIL_FILE_TRANSFER.DownloadInt');
      return false;    
    when READWRITE_ERROR then 
      return false;          
    when CLIENT_ERROR then 
      return false;          
    when NO_JAVA then 
      return false;
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUT_PACKAGE)
                              ||' bean not found. WEBUTIL_FILE_TRANSFER.DownloadInt will not work');
      RAISE FORM_TRIGGER_FAILURE;  
  END DownloadInt;
```

#### SP-028 - WEBUTIL.ENCODEBASE64FILE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.DOWNLOADINT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Encodebase64File capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Encodebase64File operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  FUNCTION encodeBASE64File(
    obj   ORA_JAVA.JOBJECT,
    a0    VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_BOOLEAN_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'encodeBASE64File', '(Ljava/lang/String;)Z', args); 
  END;

BEGIN
  NULL;
END;

PACKAGE JAVA_APPSERV_WRITER /* oracle.forms.webutil.fileTransfer.AppServerFileWriter */ IS
```

#### SP-029 - WEBUTIL.ERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Error capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |
| code | PLS_INTEGER | IN |
| pu_name | VARCHAR2 | IN |
| arg1 | VARCHAR2 | IN |
| arg2 | VARCHAR2 | IN |
| arg3 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Error operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Error(packageID in PLS_INTEGER,
                  code      in PLS_INTEGER,
                  pu_name   in VARCHAR2,
                  arg1      in VARCHAR2 :=null,
                  arg2      in VARCHAR2 := null,
                  arg3      in VARCHAR2 := null
                 ) is
    errText varchar2(1024);
  begin 
    errText := 'ERROR'||lpad(to_char(code),3,'0') || '|' || pu_name;
    if arg1 is not null then
      errText := errText || '|' || arg1;
    end if;
    if arg2 is not null then
      errText := errText || '|' || arg2;
    end if;
    if arg3 is not null then
      errText := errText || '|' || arg3;
    end if;
    Webutil_Core.setProperty(packageID, 'WUC_ERROR_MSG', errText);
  end Error;
```

#### SP-030 - WEBUTIL.ERRORALERT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]
- webutil.pld [StoredProcedure: WEBUTIL.LOG]
- webutil.pld [StoredProcedure: WEBUTIL.POPULATEPROPERTYBUNDLE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Erroralert capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| errText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-059](#SP-059--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Erroralert operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ErrorAlert(errText in VARCHAR2) is
    -- currently used for throwing a BEAN_NOT_REGISTERED or bean not found error.
    ignore integer;
  begin
    if not ID_NULL(m_errorAlert) then 
      --SET_ALERT_PROPERTY(m_errorAlert,TITLE,'WebUtil Error'); -- title already set in alert property
      SET_ALERT_PROPERTY(m_errorAlert,ALERT_MESSAGE_TEXT,errText);
      ignore := SHOW_ALERT(m_errorAlert);
    else
      message('WebUtil Error'||': '||errText);
    end if;
  end ErrorAlert;
```

#### SP-031 - WEBUTIL.EXECUTE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.BLOCKING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Execute capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |
| exemode | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Execute operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  FUNCTION Execute (cmd in VARCHAR2, exemode in PLS_INTEGER) return PROCESS_ID is
    procId PROCESS_ID;
  begin 
    if cmd is not null then 
      WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTION_MODE',exemode);            
      WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTE',cmd);      
      procId.handle := to_number(WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTE'));
    end if;
    return procId;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.Execute will not work');
  end Execute;
```

#### SP-032 - WEBUTIL.EXISTS_

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKJAVA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Exists  capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Exists  operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  FUNCTION exists_(
    obj   ORA_JAVA.JOBJECT) RETURN BOOLEAN IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_BOOLEAN_METHOD(FALSE, obj, 'java/io/File', 'exists', '()Z', args); 
  END;
```

#### SP-033 - WEBUTIL.FCLOSE

**Invoked From:**

- vr_ewinv_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open client-side file handle managed by the WebUtil TEXT_IO infrastructure. The procedure nullifies the file handle after signalling the WebUtil bean to release the resource, ensuring that client-side file references are properly cleaned up during Excel report generation invoked from the Invoice Viewing screen (vr_ewinv_fmb).

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-030](#SP-030--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETIMPLCLASS ([SP-041](#SP-041--WEBUTIL.GETIMPLCLASS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the IN OUT file_type parameter representing the open client-side file handle.
- Step 2 - Check whether the file handle is currently active (handle IS NOT NULL). If the handle is NULL the procedure exits silently with no action.
- Step 3 - Invoke WebUtil_Core.setProperty with the WUF_PACKAGE context and the WUF_TEXTIO_CLOSE command to instruct the registered WebUtil bean to close the file on the client machine.
- Step 4 - Set the file handle to NULL, marking the file_type record as closed and preventing any further operations against the same handle.
- Step 5 - If the WebUtil bean is not registered (BEAN_NOT_REGISTERED exception), call WEBUTIL.ERRORALERT (via WebUtil_Core.ErrorAlert) using the implementation class name retrieved by WEBUTIL.GETIMPLCLASS (via WebUtil_Core.getImplClass) to display a descriptive error message, then raise TOOL_ERR.TOOL_ERROR to abort the calling operation.
- Step 6 - If a property-level error occurs (PROPERTY_ERROR exception), raise TOOL_ERR.TOOL_ERROR directly to propagate the failure to the caller.

---
**Decision Points**

DP-001

Condition: file.handle IS NOT NULL

TRUE: Proceed to close the file by calling WebUtil_Core.setProperty with WUF_TEXTIO_CLOSE and then nullify the handle.

FALSE: Skip all close processing; the procedure exits without taking any action.

---

DP-002

Condition: WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during setProperty

TRUE: Call WEBUTIL.ERRORALERT with a message composed using WEBUTIL.GETIMPLCLASS to identify the missing bean, then raise TOOL_ERR.TOOL_ERROR to halt execution.

FALSE: Exception is not raised; normal close processing continues.

---

DP-003

Condition: WebUtil_Core.PROPERTY_ERROR exception is raised during setProperty

TRUE: Raise TOOL_ERR.TOOL_ERROR immediately to propagate the failure to the caller without displaying an additional alert.

FALSE: Exception is not raised; normal close processing continues.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A file close operation is only attempted when the file handle is non-NULL; a NULL handle is treated as already closed and requires no action.
- BR-002 - The client-side file handle must be nullified immediately after the WebUtil bean acknowledges the close, preventing any reuse of a stale handle within the same session.
- BR-003 - If the WebUtil bean required to perform the close is not registered, the error message presented via WEBUTIL.ERRORALERT must include the implementation class name obtained from WEBUTIL.GETIMPLCLASS so that the failure can be diagnosed precisely.
- BR-004 - Any failure during the close operation (bean not registered or property error) must escalate as TOOL_ERR.TOOL_ERROR, ensuring the calling routine (VIEW_EXCEL_REP) is notified and can handle the error rather than continuing with an unclosed file reference.

---
**Implementation Logic**

```plsql
 
  PROCEDURE fclose (file IN OUT file_type) is 
  BEGIN 
    if (file.handle IS NOT NULL) then 
      WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CLOSE',file.handle);        
      file.handle := NULL;
    end if;
 
 EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.fclose will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;
  END fclose;
```

#### SP-034 - WEBUTIL.FILE_IS_DIRECTORY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.DOWNLOADINT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the File Is Directory capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file_name | Varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GET_ATTRIBUTE_INT ([SP-054](#SP-054--WEBUTIL.GET_ATTRIBUTE_INT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the File Is Directory operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  
  FUNCTION FILE_IS_DIRECTORY(           file_name      Varchar2) return BOOLEAN is
  BEGIN
    return (GET_ATTRIBUTE_INT(file_name,ATTR_IS_DIRECTORY)='TRUE');
  END FILE_IS_DIRECTORY;
```

#### SP-035 - WEBUTIL.FILE_IS_READABLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.UPLOADINT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the File Is Readable capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file_name | Varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GET_ATTRIBUTE_INT ([SP-054](#SP-054--WEBUTIL.GET_ATTRIBUTE_INT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the File Is Readable operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  
  FUNCTION FILE_IS_READABLE(            file_name      Varchar2) return BOOLEAN is
  BEGIN
    return (GET_ATTRIBUTE_INT(file_name,ATTR_READABLE)='TRUE');
  END FILE_IS_READABLE;
```

#### SP-036 - WEBUTIL.FOPEN

**Invoked From:**

- vr_ewinv_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Opens a file on the client machine for reading, writing, or appending as part of the WebUtil client-side file I/O infrastructure. The routine validates the requested file mode and file path, communicates the open request to the WebUtil Java bean via WEBUTIL.GETPROPERTY, and returns a typed file handle that the calling routine (VIEW_EXCEL_REP) can use for subsequent client-side text I/O operations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| spec | VARCHAR2 | IN |
| filemode | VARCHAR2 | IN |
| charSet | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETPROPERTY ([SP-048](#SP-048--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the three input parameters: the file path (spec), the file mode (filemode), and the optional character set (charSet).
- Step 2 - Validate that the file mode is one of the accepted values ('r', 'w', or 'a'); raise TOOL_ERR.TOOL_ERROR immediately if the value is not recognised.
- Step 3 - Validate that the file path (spec) is not null and not an empty string; raise TOOL_ERR.TOOL_ERROR if the path is absent.
- Step 4 - Push the file path to the WebUtil Java bean by setting the WUF_FILENAME property via WebUtil_Core.setProperty.
- Step 5 - Push the file mode to the WebUtil Java bean by setting the WUF_TEXTIO_FILEMODE property via WebUtil_Core.setProperty.
- Step 6 - Push the character set to the WebUtil Java bean: if charSet is null, set WUF_TEXTIO_CHARSET to the literal '(null)'; otherwise set it to the supplied charSet value.
- Step 7 - Trigger the client-side file-open operation and retrieve the resulting Java file handle by calling WEBUTIL.GETPROPERTY (WebUtil_Core.getProperty) for the WUF_TEXTIO_OPEN property.
- Step 8 - Evaluate the returned Java handle; if it is null, empty, or '-1', the file could not be opened and TOOL_ERR.TOOL_ERROR is raised.
- Step 9 - Convert the valid Java handle string to a number, assign it to the clientFile.handle field, and return the populated file_type record to the caller.

---
**Decision Points**

DP-001

Condition: The supplied filemode (case-insensitive) is not one of 'r', 'w', or 'a'.

TRUE: Raise TOOL_ERR.TOOL_ERROR immediately; processing stops.

FALSE: Continue to the file path validation step.

---

DP-002

Condition: The supplied spec (file path) is null or an empty string.

TRUE: Raise TOOL_ERR.TOOL_ERROR immediately; processing stops.

FALSE: Continue to set WebUtil properties.

---

DP-003

Condition: The charSet parameter is null.

TRUE: Set the WUF_TEXTIO_CHARSET property to the literal value '(null)' on the WebUtil bean.

FALSE: Set the WUF_TEXTIO_CHARSET property to the caller-supplied charSet value.

---

DP-004

Condition: The Java handle returned by WEBUTIL.GETPROPERTY (WUF_TEXTIO_OPEN) is null, empty, or equal to '-1'.

TRUE: Raise TOOL_ERR.TOOL_ERROR; the file was not successfully opened on the client.

FALSE: Convert the handle to a number, populate the file_type record, and return it to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file mode must be exactly one of 'r' (read), 'w' (write), or 'a' (append), evaluated case-insensitively; any other value is rejected before any client interaction occurs.
- BR-002 - A non-null, non-empty file path must be supplied; the routine will not attempt to open a file without a valid path.
- BR-003 - When no character set is specified by the caller, the WebUtil bean is explicitly instructed to use its default encoding by passing the sentinel value '(null)' rather than omitting the property.
- BR-004 - A Java handle of null, empty string, or '-1' is treated as a failed open; the routine never returns a file handle in an indeterminate state.
- BR-005 - If the WebUtil Java bean is not registered on the client, an error alert is displayed identifying the missing bean class and TOOL_ERR.TOOL_ERROR is raised, preventing silent failure.
- BR-006 - The routine propagates TOOL_ERR.TOOL_ERROR and PROPERTY_ERROR to the caller without suppression, ensuring that upstream routines (e.g., VIEW_EXCEL_REP) can apply their own error-handling logic.

---
**Implementation Logic**

```plsql
  FUNCTION fopen(spec VARCHAR2, filemode VARCHAR2, charSet VARCHAR2 := null) RETURN file_type is
    clientFile file_type;
    javaHandle VARCHAR2(6);
  BEGIN
    -- check the mode is valid
    if (lower(filemode) not in ('r','w','a')) then 
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- make sure a file name has been specified      
    if (spec is null) or (spec='') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;
      
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILENAME',spec, true);
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_FILEMODE',filemode, true);        
    if (charSet is null) then
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET','(null)', true);
    else
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET',charSet, true);
    end if;
    javaHandle := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_OPEN');

    -- If the return is null then the file was not opened      
    if (javaHandle is null) or (javaHandle='') or (javaHandle='-1') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- if we are this far convert the handle to the correct format and return it.      
    clientFile.handle := to_number(javaHandle);
    return clientFile;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.fopen will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                 
      return null;
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE;
    when VALUE_ERROR then
      RAISE TOOL_ERR.TOOL_ERROR; 
    when TOOL_ERR.TOOL_ERROR then 
      RAISE;
  END fopen;
```

#### SP-037 - WEBUTIL.GETCALLBACKTRIGGER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Getcallbacktrigger capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| callbackKey | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Getcallbacktrigger operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetCallbackTrigger(callbackKey in PLS_INTEGER) return VARCHAR2 is 
  begin 
    return m_callbacks(callbackKey);
  end GetCallbackTrigger;
```

#### SP-038 - WEBUTIL.GETCLIENTFILESEP

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.DOWNLOADINT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Getclientfilesep capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Getclientfilesep operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetClientFileSep return VARCHAR2 is
  begin 
    return m_clientFileSep;
  end GetClientFileSep;
```

#### SP-039 - WEBUTIL.GETCLIENTOSFAMILY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Getclientosfamily capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Getclientosfamily operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql

  FUNCTION GetClientOSFamily return PLS_INTEGER is 
  begin 
    return m_clientOSFamily;
  end GetClientOSFamily;
```

#### SP-040 - WEBUTIL.GETCLIENTSETTING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Getclientsetting capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Getclientsetting operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetClientSetting(propertyName in VARCHAR2) return VARCHAR2 is 
    result VARCHAR2(255 char);
  BEGIN
    if propertyName is not null then 
    WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_GET_LOCAL_PROPERTY', propertyName);
       result := WebUtil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_GET_LOCAL_PROPERTY');
    end if;
    return result;
  EXCEPTION  
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                            ||' bean not found. WEBUTIL_CORE.GetClientSetting will not work');
    RAISE FORM_TRIGGER_FAILURE;  
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE FORM_TRIGGER_FAILURE;       
  END GetClientSetting;
```

#### SP-041 - WEBUTIL.GETIMPLCLASS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Getimplclass capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Getimplclass operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql

  FUNCTION getImplClass(packageID PLS_INTEGER) return VARCHAR2 is
  BEGIN 
    return WEBUTIL_JAVA_ROOT||m_implClasses(packageID);    
  END;
```

#### SP-042 - WEBUTIL.GETLASTERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Getlasterror capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Getlasterror operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  FUNCTION getLastError(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_INT_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'getLastError', '()I', args); 
  END;
```

#### SP-043 - WEBUTIL.GETLASTERRORARGS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Getlasterrorargs capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Getlasterrorargs operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  FUNCTION getLastErrorArgs(
    obj   ORA_JAVA.JOBJECT) RETURN VARCHAR2 IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_STRING_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'getLastErrorArgs', '()Ljava/lang/String;', args); 
  END;
```

#### SP-044 - WEBUTIL.GETNUMBER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Getnumber capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Source_string | varchar2 | IN |
| Field_position | number | IN |
| UnTerminated | Boolean | IN |
| Delimiter | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETSTRING ([SP-052](#SP-052--WEBUTIL.GETSTRING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Getnumber operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql

    
  function  GetNumber (Source_string    in varchar2,
                       Field_position   in number,
                       UnTerminated     in Boolean  default FALSE,
                       Delimiter        in varchar2 default ',') return number is
                       iRc              pls_integer;
  begin 
    Return to_number(GetString(Source_string, Field_Position, UnTerminated, Delimiter));
  end GetNumber; /* Number Version */
```

#### SP-045 - WEBUTIL.GETOSFAMILY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Getosfamily capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| osName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Getosfamily operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
 
  FUNCTION getOSFamily(osName in VARCHAR2) return PLS_INTEGER is
    l_osName VARCHAR2(30) := lower(osName);
    result   PLS_INTEGER  := CLIENT_PLATFORM_UNKNOWN;
  BEGIN
    if m_clientOSFamily  is null then 
      if (instr(l_osName,'windows') > 0) then 
           result := CLIENT_PLATFORM_WIN32;
      elsif instr(l_osName,'mac') > 0 then 
          result := CLIENT_PLATFORM_MAC;      
      elsif instr(l_osName,'linux') > 0 then 
          result := CLIENT_PLATFORM_LINUX;      
      elsif instr(l_osName,'solaris') > 0 OR instr(l_osName, 'sunos') > 0 then 
          result := CLIENT_PLATFORM_SOLARIS;       
      elsif instr(l_osName,'hp-ux') > 0 then 
          result := CLIENT_PLATFORM_HP; 
      elsif instr(l_osName,'aix') > 0 then 
          result := CLIENT_PLATFORM_AIX;                                                       
      end if;            
      m_clientOSFamily := result;
    end if;
    return m_clientOSFamily;
  END getOSFamily;
```

#### SP-046 - WEBUTIL.GETOUTPUT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GET_STANDARD_OUTPUT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Getoutput capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |
| prop | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Getoutput operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetOutput(process in PROCESS_ID, prop in VARCHAR2) return OUTPUT_ARRAY is   
    lines  OUTPUT_ARRAY;
    i      PLS_INTEGER := 1;
    buffer VARCHAR2(257 char);
    status VARCHAR2(1) := 'X';
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_PROC_ID',process.handle);
    LOOP
      buffer := WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,prop);
      status := substr(buffer,1,1);
      -- Status can be Y: indicating more lines to follow,
      --               N: indicating that this is the last line
      --               X: indicating that the buffer was empty
      if status <> 'X' then 
        lines(i) := substr(buffer,2);
        i := i + 1;
      end if;
      exit when status <> 'Y';
    END LOOP;
    return lines;    
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.GetOutput will not work');
  END GetOutput;  
  
BEGIN
    -- Ensure that Core is instanciated.
    Webutil_Core.Init;
END;

PACKAGE WEBUTIL_SEPARATEFRAME IS

/*********************************************************************************\
 * WEBUTIL_SEPARATEFRAME
 *   This Package contains routines to interact with the MDI frame when Forms
 *   is running with the parameter separateFrame=true
 *   The functions in this package will work with any client type - not just 
 *   Windows clients.
 *   The oracle.forms.webutil.browser.BrowserFunctions bean is needed in your 
 *   Form to use these functions
 *********************************************************************************
 * Version 1.0.0
 *********************************************************************************
 * Change History
 *   1.0.0 DRMILLS 25/MAY/2003 - Creation
 *   1.0.1 DRMILLS 27/MAY/2003 - Added call to get frame size 
 *
\*********************************************************************************/

  /**
   *  IsSeparateFrame - Allows you to check if the form 
   *                is running in separateFrame mode or not
   */
```

#### SP-047 - WEBUTIL.GETPATH

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.DOWNLOADINT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Getpath capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Getpath operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  FUNCTION getPath(
    obj   ORA_JAVA.JOBJECT) RETURN VARCHAR2 IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_STRING_METHOD(FALSE, obj, 'java/io/File', 'getPath', '()Ljava/lang/String;', args); 
  END;
```

#### SP-048 - WEBUTIL.GETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FOPEN]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Getproperty capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Getproperty operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  FUNCTION getProperty(
    a0    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'getProperty', '(Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-049 - WEBUTIL.GETSERVERFILESEP

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKASACL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Getserverfilesep capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Getserverfilesep operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetServerFileSep return VARCHAR2 is    
  begin 
    return m_serverFileSep;
  end GetServerFileSep;
```

#### SP-050 - WEBUTIL.GETSOURCECHUNKS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.DOWNLOADINT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Getsourcechunks capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Getsourcechunks operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  FUNCTION getSourceChunks(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_INT_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'getSourceChunks', '()I', args); 
  END;
```

#### SP-051 - WEBUTIL.GETSOURCELENGTH

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.DOWNLOADINT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Getsourcelength capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Getsourcelength operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  FUNCTION getSourceLength(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_INT_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'getSourceLength', '()I', args); 
  END;
```

#### SP-052 - WEBUTIL.GETSTRING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETNUMBER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Getstring capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Source_string | varchar2 | IN |
| Field_position | number | IN |
| UnTerminated | Boolean | IN |
| Delimiter | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-065](#SP-065--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Getstring operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql

  function  GetString (Source_string    in varchar2,
                       Field_position   in number,
                       UnTerminated     in Boolean  default FALSE,
                       Delimiter        in varchar2 default ',') return varchar2 is
                       iPtrEnd          pls_integer     := 0;
                       iPtrStart        pls_integer     := 0;
                       vcSourceStrCopy  varchar2(32000)     := Source_string;
  begin
    if UnTerminated then 
      vcSourceStrCopy := vcSourceStrCopy||Delimiter;
    end if;

    if Field_Position > 1 then 
      iPtrStart := instr(vcSourceStrCopy,Delimiter,1,Field_Position-1)+ length(Delimiter);
    else
      iPtrStart := 1;
    end if ; 

    iPtrEnd     := instr(vcSourceStrCopy,Delimiter,1,Field_Position);
    return substr(vcSourceStrCopy,iPtrStart,(iPtrEnd-iPtrStart));
  end GetString; /* String Version */
```

#### SP-053 - WEBUTIL.GETVAR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Getvar capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VARNAME | VARCHAR2 | IN |
| VARVALUE | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VARVALUE | VARCHAR2 | IN OUT |

---

**Dependencies**

- GET_ENVIRONMENT_STRING ([SP-095](#SP-095--GET_ENVIRONMENT_STRING)) - matched by member name
- READ_REGISTRY ([SP-096](#SP-096--READ_REGISTRY)) - matched by member name
- WEBUTIL.GETCLIENTOSFAMILY ([SP-039](#SP-039--WEBUTIL.GETCLIENTOSFAMILY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_STANDARD_OUTPUT ([SP-057](#SP-057--WEBUTIL.GET_STANDARD_OUTPUT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Getvar operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql

  PROCEDURE GETVAR(VARNAME IN VARCHAR2, VARVALUE IN OUT VARCHAR2) is
    unixOutput WebUtil_HOST.OUTPUT_ARRAY;
    hostHandle WebUtil_HOST.PROCESS_ID;
    varKey     VARCHAR2(100);
    iPos       PLS_INTEGER;
  BEGIN
    if WebUtil_Core.GetClientOSFamily = WebUtil_Core.CLIENT_PLATFORM_WIN32 then 
      -- read the client Registry
      VARVALUE := Client_Win_API_Environment.read_registry('HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE',VARNAME,false);
      if VARVALUE is null OR VARVALUE = '' then
        -- Could not get an Oracle variable in registry. Try to get from environment varialble
        -- java desupported System.getenv method until they supported it again in 1.5.
        -- We can still get the environment variables in windows using
        -- CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING
        VARVALUE := CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING(VARNAME);
      end if;
    elsif WebUtil_Core.GetClientOSFamily in (WebUtil_Core.CLIENT_PLATFORM_MAC,WebUtil_Core.CLIENT_PLATFORM_UNKNOWN) then 
      -- do nothing 
      null;
    else
      -- Unix Ports - do a env to get the environment and parse that
      hostHandle := WebUtil_HOST.Blocking('env');
      unixOutput := WebUtil_HOST.Get_Standard_Output(hostHandle);
      WebUtil_HOST.Release_Process(hostHandle);
      for i in 1..unixOutput.count LOOP
        iPos := instr(unixOutput(i),'=');
        if iPos > 0 then 
          varKey := substr(unixOutput(i),1,iPos-1);
          if varKey = VARNAME then 
            VARVALUE := substr(unixOutput(i),iPos+1);
            EXIT;
          end if;
        end if;
      end LOOP;
    end if;

  exception
    when NO_DATA_FOUND then
      VARVALUE := null;
  END GETVAR;

END CLIENT_TOOL_ENV;

PACKAGE Client_Win_API IS
/*-------------------------------------------------------------------------------*\
 * WebUtil version of D2KWUTIL package WIN_API                                     
 * Note: Not all D2kWutil Functions are ported
 *********************************************************************************
 * Version 1.0.0
 *********************************************************************************
 * Change History
 *   DRMILLS 21/FEB/2003 - Port Creation
 *
 *********************************************************************************
 * WIN_API ->  This package defines the constants used throughout 
 *      the library as a whole, including versions of those 
 *      constants defined within WINDOWS.H/WINUSER.H that 
 *      we'll be using. Add more constants in here if required
 *      The package also contains Explicit Exception declarations,
 *      various status Flags and functions for Error Handling
 * NOTE:    In order to make this library portable across Forms
 *      and Reports we do not use any application 
 *      specific built-ins such as the Forms MESSAGE() 
 *      Built-in. Instead errors are recorded in a package
 *      variable which the programmer can examine if required
\*-------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------*\
 * Internal Version Number  ** Oracle Developer Release 6.0 Version
\*-------------------------------------------------------------------------------*/
  WIN_API_VERSION  CONSTANT  VARCHAR2(30) := '6.0.6.0 Production';
  DLL_NAME         CONSTANT  VARCHAR2(12) := 'd2kwut60.dll';
  DLL_PATH         VARCHAR2(256)          := NULL;

/*-------------------------------------------------------------------------------*\
 * General Window Classes of Common Applications for use with WIN_API_SESSION
 * ** WARNING ** These Window classes are out of our control and might change 
 *               when you upgrade the software in question,
\*-------------------------------------------------------------------------------*/

  -- Oracle Apps
  WINCLASS_DEVELOPER_2000_V1  CONSTANT  VARCHAR2(15)  := 'ui23MDIroot_W32';             /* Developer/2000 release 1.n / Toolkit 2.3 Apps on 32 bit */
  WINCLASS_DEVELOPER_2000_V2  CONSTANT  VARCHAR2(15)  := 'ui25MDIroot_W32';             /* Developer/2000 Release 2.0 / Toolkit 2.5 Apps on 32 bit */
  WINCLASS_DEVELOPER_2000_V6  CONSTANT  VARCHAR2(15)  := 'ui60MDIroot_W32';             /* Developer/2000 Release 6.0 / Toolkit 6.0 Apps on 32 bit */  
  D2K_WINDOW_CLASS            CONSTANT  VARCHAR2(15)  := WINCLASS_DEVELOPER_2000_V6;    /* Set to the "current" version */  
  WINCLASS_INTEROFFICE_40     CONSTANT  VARCHAR2(28)  := 'Afx:10000000:b:10008:6:5023b';/* Oracle Interoffice 4.0 Client 32 bit */
  WINCLASS_INTEROFFICE_41     CONSTANT  VARCHAR2(28)  := 'Afx:10000000:b:1496:6:3a17';  /* Oracle Interoffice 4.0 Client 32 bit */
  WINCLASS_SQLPLUS            CONSTANT  VARCHAR2(13)  := 'SqlplusWClass';               /* Sql*Plus 32 bit */
  WINCLASS_REPORTSSERVER_V1   CONSTANT  VARCHAR2(15)  := 'R25SRV_WINCLASS';             /* Reports Server Reports 2.5 */
  WINCLASS_REPORTSSERVER_V2   CONSTANT  VARCHAR2(15)  := 'R30SRV_WINCLASS';             /* Reports Server Reports 3.0 */
  WINCLASS_REPORTSSERVER_V6   CONSTANT  VARCHAR2(14)  := 'RWRBE_WINCLASS';              /* Reports Server Reports 6.0 */

  -- Microsoft Office Apps - Office97
  WINCLASS_MSWORD_97         CONSTANT  VARCHAR2(7) := 'OpusApp';                        /* Microsoft Word 97 */
  WINCLASS_MSEXCEL_97        CONSTANT  VARCHAR2(6) := 'XLMAIN';                         /* Microsoft Excel 97 */
  WINCLASS_MSPOWERPOINT_97   CONSTANT  VARCHAR2(14):= 'PP97FrameClass';                 /* Microsoft Power Point 97 */

  -- Microsoft Office Apps - Office95
  WINCLASS_MSWORD_7          CONSTANT  VARCHAR2(7) := 'OpusApp';                        /* Microsoft Word 7 */
  WINCLASS_MSEXCEL_7         CONSTANT  VARCHAR2(6) := 'XLMAIN';                         /* Microsoft Excel 7 */
  WINCLASS_MSPOWERPOINT_7    CONSTANT  VARCHAR2(13):= 'PP7FrameClass';                  /* Microsoft Power Point 7 */
  WINCLASS_MSSCHEDULE_7      CONSTANT  VARCHAR2(23):= 'MS Schedule+ 32 Panesdi';        /* Microsoft Schedule 7 */
  WINCLASS_MSEXCHANGE_4      CONSTANT  VARCHAR2(29):= 'Microsoft Exchange 4.0 Viewer';  /* Microsoft Exchange 4 in-tray */

  -- Microsoft O/S Utilities
  WINCLASS_INETEXPLORER      CONSTANT  VARCHAR2(7):= 'IEFrame';                         /* Internet Explorer */
  WINCLASS_OUTLOOK_EXPRESS   CONSTANT  VARCHAR2(29):= 'Outlook Express Browser Class';  /* Outlook Express */
  WINCLASS_EXPLORER          CONSTANT  VARCHAR2(13):= 'ExploreWClass';                  /* Explorer */
  WINCLASS_MYCOMPUTER        CONSTANT  VARCHAR2(13):= 'CabinetWClass';                  /* My Computer & Network Neighborhood*/
  WINCLASS_CALCULATOR        CONSTANT  VARCHAR2(7) := 'SciCalc';                        /* Windows Calculator */
  WINCLASS_NOTEPAD           CONSTANT  VARCHAR2(7) := 'Notepad';                        /* Windows Notepad */
  WINCLASS_WORDPAD           CONSTANT  VARCHAR2(12):= 'WordPadClass';                   /* Windows Wordpad/Write */
  WINCLASS_DOS               CONSTANT  VARCHAR2(18):= 'ConsoleWindowClass';             /* Dos Window */

  -- Other
  WINCLASS_NETSCAPE_3        CONSTANT  VARCHAR2(27):= 'Afx:40000000:b:150e:6:38cfe';    /* Netscape Navigator 3.0 */
  WINCLASS_NETSCAPE_4        CONSTANT  VARCHAR2(28):= 'Afx:40000000:b:10008:6:6063e';   /* Netscape Communicator 4.0 */
  WINCLASS_PFE_7             CONSTANT  VARCHAR2(11):= 'PFE32_Frame';                    /* Programmers File Editor */
  WINCLASS_REGEDIT           CONSTANT  VARCHAR2(15):= 'RegEdit_RegEdit';                /* Registry Editor */

  -- Window Style Constants (from WINUSER.H)
  --  Any PU's that use these constants will explain 
  --  their use.  For further information consult the
  --  Windows SDK.

  SW_HIDE              CONSTANT  PLS_INTEGER := 0;
  SW_SHOWNORMAL        CONSTANT  PLS_INTEGER := 1;
  SW_SHOWMINIMIZED     CONSTANT  PLS_INTEGER := 2;
  SW_SHOWMAXIMIZED     CONSTANT  PLS_INTEGER := 3;
  SW_SHOWNOACTIVATE    CONSTANT  PLS_INTEGER := 4;
  SW_SHOW              CONSTANT  PLS_INTEGER := 5;
  SW_MINIMIZE          CONSTANT  PLS_INTEGER := 6;
  SW_SHOWMINNOACTIVE   CONSTANT  PLS_INTEGER := 7;
  SW_SHOWNA            CONSTANT  PLS_INTEGER := 8;
  SW_RESTORE           CONSTANT  PLS_INTEGER := 9;
  SW_SHOWDEFAULT       CONSTANT  PLS_INTEGER := 10;

  -- Help Access Constants (From WINUSER.H)
  --  See WIN_API_SHELL.WinHelp

  HELP_CONTEXT         CONSTANT  PLS_INTEGER := 1;   /* 0x0001L */
  HELP_QUIT            CONSTANT  PLS_INTEGER := 2;   /* 0x0002L */
  HELP_INDEX           CONSTANT  PLS_INTEGER := 3;   /* 0x0003L */
  HELP_CONTENTS        CONSTANT  PLS_INTEGER := 3;   /* 0x0003L */
  HELP_HELPONHELP      CONSTANT  PLS_INTEGER := 4;   /* 0x0004L */
  HELP_SETINDEX        CONSTANT  PLS_INTEGER := 5;   /* 0x0005L */
  HELP_SETCONTENTS     CONSTANT  PLS_INTEGER := 5;   /* 0x0005L */
  HELP_CONTEXTPOPUP    CONSTANT  PLS_INTEGER := 8;   /* 0x0008L */
  HELP_FORCEFILE       CONSTANT  PLS_INTEGER := 9;   /* 0x0009L */
  HELP_KEY             CONSTANT  PLS_INTEGER := 257; /* 0x0101L */
  HELP_COMMAND         CONSTANT  PLS_INTEGER := 258; /* 0x0102L */
  HELP_PARTIALKEY      CONSTANT  PLS_INTEGER := 261; /* 0x0105L */
  HELP_MULTIKEY        CONSTANT  PLS_INTEGER := 513; /* 0x0201L */
  HELP_SETWINPOS       CONSTANT  PLS_INTEGER := 515; /* 0x0203L */
  -- Windows 4+
  HELP_CONTEXTMENU     CONSTANT  PLS_INTEGER := 10;  /* 0x000a  */
  HELP_FINDER          CONSTANT  PLS_INTEGER := 11;  /* 0x000b  */
  HELP_WM_HELP         CONSTANT  PLS_INTEGER := 12;  /* 0x000c  */
  HELP_SETPOPUP_POS    CONSTANT  PLS_INTEGER := 13;  /* 0x000d  */

  -- Windows Messages for use with SendMessage
  -- DO NOT utilise the Windows Sendmessage interface without being conversant
  -- with the Windows message handling mechanism
  -- Refer to the Microsoft Windows SDK for Messages and Parameter values
  WM_SYSCOMMAND        CONSTANT  PLS_INTEGER := 274;   /* 0x0112 */
  WM_MDITILE           CONSTANT  PLS_INTEGER := 550;   /* 0x0226 */
  WM_MDICASCADE        CONSTANT  PLS_INTEGER := 551;   /* 0x0227 */
  WM_MDIICONARRANGE    CONSTANT  PLS_INTEGER := 552;   /* 0x0228 */      
  SC_RESTORE           CONSTANT  PLS_INTEGER := 61728; /* 0xF120 */
  SC_MINIMIZE          CONSTANT  PLS_INTEGER := 61472; /* 0xF020 */
  SC_MAXIMIZE          CONSTANT  PLS_INTEGER := 61488; /* 0xF030 */
  

  -- Flags for use with File Dialog boxes ("Save As" or "Open")
  -- Refer to your Microsoft documentation for details on the 
  -- Exact usage and dependancies of each option
  OFN_READONLY           CONSTANT  PLS_INTEGER := 1;        /* 0x00000001 */
  OFN_OVERWRITEPROMPT    CONSTANT  PLS_INTEGER := 2;        /* 0x00000002 */
  OFN_HIDEREADONLY       CONSTANT  PLS_INTEGER := 4;        /* 0x00000004 */
  OFN_NOCHANGEDIR        CONSTANT  PLS_INTEGER := 8;        /* 0x00000008 */
  OFN_SHOWHELP           CONSTANT  PLS_INTEGER := 16;       /* 0x00000010 */
  OFN_NOVALIDATE         CONSTANT  PLS_INTEGER := 256;      /* 0x00000100 */
  OFN_ALLOWMULTISELECT   CONSTANT  PLS_INTEGER := 512;      /* 0x00000200 */
  OFN_EXTENSIONDIFFERENT CONSTANT  PLS_INTEGER := 1024;     /* 0x00000400 */
  OFN_PATHMUSTEXIST      CONSTANT  PLS_INTEGER := 2048;     /* 0x00000800 */
  OFN_FILEMUSTEXIST      CONSTANT  PLS_INTEGER := 4096;     /* 0x00001000 */
  OFN_CREATEPROMPT       CONSTANT  PLS_INTEGER := 8192;     /* 0x00002000 */
  OFN_SHAREAWARE         CONSTANT  PLS_INTEGER := 16384;    /* 0x00004000 */
  OFN_NOREADONLYRETURN   CONSTANT  PLS_INTEGER := 32768;    /* 0x00008000 */
  OFN_NOTESTFILECREATE   CONSTANT  PLS_INTEGER := 65536;    /* 0x00010000 */
  OFN_NONETWORKBUTTON    CONSTANT  PLS_INTEGER := 131072;   /* 0x00020000 */
  OFN_NOLONGNAMES        CONSTANT  PLS_INTEGER := 262144;   /* 0x00040000 */
  OFN_EXPLORER           CONSTANT  PLS_INTEGER := 524288;   /* 0x00080000 */
  OFN_NODEREFERENCELINKS CONSTANT  PLS_INTEGER := 1048576;  /* 0x00100000 */
  OFN_LONGNAMES          CONSTANT  PLS_INTEGER := 2097152;  /* 0x00200000 */

  -- The defaults used here (WIN_API.OFN_PATHMUSTEXIST|WIN_API.OFN_FILEMUSTEXIST|WIN_API.OFN_HIDEREADONLY|WIN_API.OFN_NOCHANGEDIR|WIN_API.OFN_EXPLORER)
  OFN_FLAG_DEFAULT       CONSTANT  PLS_INTEGER :=  530444;
  
  
  -- Registry Data types for Write_RegistryEx
  REG_EXPAND_SZ          CONSTANT  PLS_INTEGER := 0;
  REG_SZ                 CONSTANT  PLS_INTEGER := 1;
  REG_DWORD              CONSTANT  PLS_INTEGER := 2;
  
  -- Compatibility Flags - Used where I have changed behaviour and you might not like the new version
  -- Change these at runtime to FALSE to revert to "old" behaviour
  COMPAT_EXPAND_REG_VALUES    BOOLEAN := TRUE;

  
  
  -- Types
  TYPE aFunctionHandle is table of WEBUTIL_C_API.FUNCTIONHANDLE index by BINARY_INTEGER;  
  SUBTYPE FILE_TYPE is PLS_INTEGER;

  -- Public Variables
  ERROR_ENCOUNTERED  BOOLEAN := FALSE;  /* The Last Call resulted in an error */
  ERROR_STACK        VARCHAR2(2000);    /* Holds Text of Last error(s) */ 
  API_ENABLED        BOOLEAN := FALSE;   /* Are API functions usable ?*/
  DLL_HANDLE         ORA_FFI.LibHandleType;
  FunctionHandle     aFunctionHandle;
   

  -- Public Exceptions
  NOT_AVAILABLE      EXCEPTION;  /* A call to the API was made but API functions not currently available (e.g. not on Windows) */
     
  -- Error Constants
  UError             CONSTANT  VARCHAR2(30) := ' Caused an unexpected error: ';
  NoAPI              CONSTANT  VARCHAR2(31) := 'API Functions are not Available';
  MaxDWord           CONSTANT  VARCHAR2(33) := 'Integer Argument exceeds 32 bits ';
  MaxWord            CONSTANT  VARCHAR2(33) := 'Integer Argument exceeds 16 bits ';
  MaxByte            CONSTANT  VARCHAR2(32) := 'Integer Argument exceeds 8 bits ';
  MinBound           CONSTANT  VARCHAR2(27) := 'Integer Argument too Small ';
  MaxBound           CONSTANT  VARCHAR2(27) := 'Integer Argument too Large ';
  NullArg            CONSTANT  VARCHAR2(24) := 'Argument cannot be NULL ';

  /*----------------------------------------------------------------------------*\
  * PreLoad ->  Loads the d2kwut60.dll from the jvm bin directory into memory
  \*----------------------------------------------------------------------------*/
```

#### SP-054 - WEBUTIL.GET_ATTRIBUTE_INT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FILE_IS_DIRECTORY]
- webutil.pld [StoredProcedure: WEBUTIL.FILE_IS_READABLE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Get Attribute Int capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file_name | Varchar2 | IN |
| attributeID | Pls_Integer | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Get Attribute Int operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql

  FUNCTION GET_ATTRIBUTE_INT(           file_name      Varchar2,
                                        attributeID    Pls_Integer) return Varchar2 is
    result Varchar2(50);   
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILENAME',file_name, true);
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILE_ATTRIBUTE',to_char(attributeID), true);
    result := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILE_ATTRIBUTE');
    
    RETURN result;                      
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. WEBUTIL_FILE.GET_ATTRIBUTE_INT will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;  
  END GET_ATTRIBUTE_INT;
```

#### SP-055 - WEBUTIL.GET_LINE

**Invoked From:**

- vr_ewinv_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Reads a single line of text from an open client-side file handle and returns it to the calling routine. Invoked as part of the Excel report viewing workflow in vr_ewinv_fmb.xml, this procedure uses the WebUtil Core infrastructure to retrieve a line from the client file identified by the supplied file handle. It raises NO_DATA_FOUND when the end of file is reached, allowing callers to iterate over file contents line by line.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| item | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input file handle (file.handle) from the caller.
- Step 2 - Pass the file handle to the WebUtil Core layer by setting the WUF_TEXTIO_HANDLE property on the WUF_PACKAGE component.
- Step 3 - Retrieve the next line of text from the client file by reading the WUF_TEXTIO_GETLINE property via WebUtil_Core.getProperty, storing the result in a local VARCHAR2 buffer.
- Step 4 - Evaluate the buffer value: if it equals CHR(10) (a lone newline character used by the PJC exception handler to signal end-of-file), raise NO_DATA_FOUND to indicate that no further data is available.
- Step 5 - If the buffer does not equal CHR(10), assign the buffer value to the OUT parameter item and return it to the caller.
- Step 6 - If the WebUtil bean is not registered on the client, surface an error alert identifying the missing bean class and raise TOOL_ERROR to halt processing.
- Step 7 - If a property error occurs during the read operation, raise TOOL_ERROR to halt processing.

---
**Decision Points**

DP-001

Condition: The value returned in the buffer equals CHR(10), indicating that the PJC exception handler has signalled end-of-file by inserting a lone newline.

TRUE: Raise NO_DATA_FOUND to notify the caller that the end of the file has been reached; no value is assigned to the OUT parameter item.

FALSE: Assign the buffer content to the OUT parameter item and return normally to the caller.

---

DP-002

Condition: A WebUtil_Core.BEAN_NOT_REGISTERED exception is raised, meaning the required WebUtil PJC bean is not available on the client.

TRUE: Display an error alert identifying the missing bean class and raise TOOL_ERROR to terminate execution.

FALSE: No action; normal or other exception-handling flow continues.

---

DP-003

Condition: A WebUtil_Core.PROPERTY_ERROR exception is raised during the getProperty call.

TRUE: Raise TOOL_ERROR to terminate execution.

FALSE: No action; normal flow continues.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A lone newline character (CHR(10)) in the read buffer is reserved exclusively as an end-of-file sentinel placed by the PJC exception handler; it must never be treated as valid line content and must always trigger NO_DATA_FOUND.
- BR-002 - The file handle must be set on the WebUtil Core WUF_PACKAGE component before any attempt is made to read a line; the procedure always performs this property-set step prior to the read.
- BR-003 - If the required WebUtil bean is not registered on the client, processing must be halted via TOOL_ERROR; the procedure must not silently return an empty or null value in this scenario.
- BR-004 - Any property error returned by the WebUtil Core layer during the line-read operation must cause immediate termination via TOOL_ERROR, ensuring that corrupt or incomplete reads are not passed back to the caller.

---
**Implementation Logic**

```plsql
  PROCEDURE get_line (file file_type, item OUT VARCHAR2) is
    buffer VARCHAR2(4000 char);
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);        
    buffer := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_GETLINE');
    -- We can't easily tell the difference between an empty line and a line beyond then 
    -- end of the file so to get around this, the exception handling code in the PJC 
    -- places a newline into the buffer when the end of file is passed.
    -- The rational being that get_line would never normally return a newline because 
    -- it normally uses that to tell it where to read up *to*.
    if buffer = chr(10) then 
      raise NO_DATA_FOUND;
    else
      item := buffer;
    end if;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.get_line will not work');
      RAISE TOOL_ERR.TOOL_ERROR;                                                                 
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE TOOL_ERR.TOOL_ERROR;  
  END get_line;
  
  /**
   * File writing functions
   */
```

#### SP-056 - WEBUTIL.GET_RETURN_CODE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.HOST]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Get Return Code capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Get Return Code operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  
  
  FUNCTION Get_Return_Code(process in PROCESS_ID) return PLS_INTEGER is
  begin 
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_PROC_ID',process.handle);
    return to_number(WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,'WUH_RC'));
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
       WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                               ||' bean not found. WEBUTIL_HOST.Get_Return_Code will not work');
  end Get_Return_Code;
```

#### SP-057 - WEBUTIL.GET_STANDARD_OUTPUT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Get Standard Output capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETOUTPUT ([SP-046](#SP-046--WEBUTIL.GETOUTPUT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Get Standard Output operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
    
  FUNCTION Get_Standard_Output(process in PROCESS_ID) return OUTPUT_ARRAY is  
  begin 
    return GetOutput(process,'WUH_STDOUT');
  end Get_Standard_Output;
```

#### SP-058 - WEBUTIL.HOST

**Invoked From:**

- vr_ewinv_fmb.xml [StoredProcedure: CALL_REPORT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Host capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.BLOCKING ([SP-015](#SP-015--WEBUTIL.BLOCKING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_RETURN_CODE ([SP-056](#SP-056--WEBUTIL.GET_RETURN_CODE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ID_NULL ([SP-059](#SP-059--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.RELEASE_PROCESS ([SP-078](#SP-078--WEBUTIL.RELEASE_PROCESS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Host operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  FUNCTION  Host(cmd in VARCHAR2) return PLS_INTEGER is
    procId PROCESS_ID;
    RC     PLS_INTEGER := -1;
  begin
    procId := Blocking(cmd);
    if not ID_NULL(procId) then
      RC := Get_Return_Code(procId);
      -- release the client side object
      Release_Process(procId);
    end if;
    return RC;
  end Host;
```

#### SP-059 - WEBUTIL.ID_NULL

**Invoked From:**

- vr_ewinv_fmb.xml [StoredProcedure: L_POP_LIST_ITEM]
- vr_ewinv_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]
- webutil.pld [StoredProcedure: WEBUTIL.ERRORALERT]
- webutil.pld [StoredProcedure: WEBUTIL.HOST]
- webutil.pld [StoredProcedure: WEBUTIL.INITWEBUTIL]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTER_FUNCTION]
- webutil.pld [StoredProcedure: WEBUTIL_CORE.SHOWBEANS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Id Null capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| handle | Pointer | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Id Null operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql

  FUNCTION ID_NULL(handle IN Pointer)        RETURN BOOLEAN is
  BEGIN
    if handle.hnd is null then 
      return TRUE;
    else
      return FALSE;
    end if;
  END ID_NULL;
```

#### SP-060 - WEBUTIL.INIT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKASACL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Init capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.INITWEBUTIL ([SP-061](#SP-061--WEBUTIL.INITWEBUTIL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Init operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Init is
  begin 
    -- we don't need to do anything here - entering the package is enough to set it up.      
    null;
  end;      

BEGIN
  -- Initialise the Utility
  InitWebUtil;  
END WEBUTIL_CORE;

PACKAGE WEBUTIL_C_API IS
/*********************************************************************************\
 * WEBUTIL_C_API
 *   This Package provides a way of calling C functions in a shared library on the
 *   client PC. Currently only win32 is supported.
 *   The oracle.forms.webutil.cApi.CApiFunctions bean is needed in your Form to 
 *   use these functions
 *********************************************************************************
 * Version 1.0.5
 *********************************************************************************
 * Change History
 *   1.0.1 RVSUILIC 14/FEB/2003 - Creation 
 *   1.0.2 DRMILLS  27/FEB/2003 - Reset LONG to the same value as INT which is fine
 *                                for Windows & removed Tester proc
 *   1.0.3 DRMILLS  01/MAR/2003 - Re-worked the PL/SQL API
 *   1.0.4 DRMILLS  13/MAY/2003 - Added call to WebUtil_Core.Init
 *   1.0.5 RVSUILIC 21/MAY/2003 - Cleaned up some comments and formatting.
 *
\*********************************************************************************/

  /**
   *  Constants to represent PL/SQL IN, OUT and INOUT parameter qualifiers
   */
  PARAM_IN    CONSTANT PLS_INTEGER := 50;
  PARAM_INOUT CONSTANT PLS_INTEGER := 51;
  PARAM_OUT   CONSTANT PLS_INTEGER := 52;
  

  /**
   *  Constants to represent C atomic datatypes and pointers to atomic datatypes
   *  Note that to use OUT and INOUT qualifiers the C function in the DLL *must*
   *  use a pointer type to be able to pass information back.
   *
   *  The comments on the right indicate which types can be used for parameters
   *  and which for function return types.
   *
   *  c_ptr is used as a generic pointer. The onlys supported use for this is to
   *  save the pointer value from C into a PL/SQL variable, so that it may be 
   *  passed back later to C. No operations on the pointer are supported in PL/SQL.
   */
  c_void          CONSTANT PLS_INTEGER := 30;            /* - not used -   */
  c_char          CONSTANT PLS_INTEGER := 31;            /* param & return */
  c_short         CONSTANT PLS_INTEGER := 32;            /* param & return */
  c_int           CONSTANT PLS_INTEGER := 33;            /* param & return */
  c_long          CONSTANT PLS_INTEGER := 33;            /* param & return *//*DRM - same as INT */
  c_float         CONSTANT PLS_INTEGER := 35;            /* param & return */
  c_double        CONSTANT PLS_INTEGER := 36;            /* param & return */

  c_ptr           CONSTANT PLS_INTEGER := 64 + c_void;   /* param & return */
  c_char_ptr      CONSTANT PLS_INTEGER := 64 + c_char;   /* param          */
  c_short_ptr     CONSTANT PLS_INTEGER := 64 + c_short;  /* param          */
  c_int_ptr       CONSTANT PLS_INTEGER := 64 + c_int;    /* param          */
  c_long_ptr      CONSTANT PLS_INTEGER := 64 + c_long;   /* param          */
  c_float_ptr     CONSTANT PLS_INTEGER := 64 + c_float;  /* param          */
  c_double_ptr    CONSTANT PLS_INTEGER := 64 + c_double; /* param          */

  /**
   *  Abstracted types to be used for pointers and handles. The forms programmer
   *  should not attempt any manipulation on these types, but merely obtain them as
   *  a result of functions below, and pass them back in to other functions below.
   */
    SUBTYPE handleType   IS NUMBER;
    TYPE Pointer         IS RECORD (hnd handleType);   /* C pointer             */
    TYPE FunctionHandle  IS RECORD (hnd handleType);   /* function handle       */
    TYPE ParameterHandle IS RECORD (hnd handleType);   /* parameter handle      */
    TYPE ParameterList   IS RECORD (hnd handleType);   /* parameter list handle */

  /**
   *  IS_SUPPORTED - Check if the client is on a supported hardware platform.
   */
```

#### SP-061 - WEBUTIL.INITWEBUTIL

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.INIT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Initwebutil capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-059](#SP-059--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL_CORE.SHOWBEANS ([SP-086](#SP-086--WEBUTIL_CORE.SHOWBEANS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Initwebutil operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  
  PROCEDURE InitWebUtil is
    startPoint VARCHAR2(61 char) := NAME_IN('SYSTEM.CURSOR_FIELD');
    hDummy     ITEM              := FIND_ITEM(WEBUTIL_DUMMY_ITEM);
  BEGIN
    -- Set up the various package we know about.
    m_implClasses(WUC_PACKAGE) := 'common.VBeanCommon'; 
    m_implClasses(WUT_PACKAGE) := 'fileTransfer.FileTransfer'; 
    m_implClasses(WUF_PACKAGE) := 'file.FileFunctions'; 
    m_implClasses(WUI_PACKAGE) := 'clientInfo.GetClientInfo'; 
    m_implClasses(WUH_PACKAGE) := 'host.Host'; 
    m_implClasses(WUS_PACKAGE) := 'session.SessionFunctions'; 
    m_implClasses(WUB_PACKAGE) := 'browser.BrowserFunctions'; 
    m_implClasses(WUO_PACKAGE) := 'ole.OleFunctions'; 
    m_implClasses(WUU_PACKAGE) := '';      
    m_implClasses(WUL_PACKAGE) := 'cApi.CApiFunctions';                     
    
    -- Now check for the Webutil Object group which 
    -- contains the Beans etc.
          
    if id_null(m_errorAlert) then 
      -- The Webutil error alert is not around
      -- so the Code cannot operate 
      message('The WEBUTIL object group is not available in this Form.  WebUtil cannot work');
      pause;
    else
      -- Bug 2955789 - this navigation causes problems if they are in Enter-Query mode 
      -- Plus it's not really needed, except as a belt and braces kind of setup.
      -- So put a check to prevent this in E-Q mode and set a top level flag to bypass it 
      -- it all together which we can switch on or off if required as a furture W/A    
      if FLAG_EXPICIT_INSTANCIATE and name_in('SYSTEM.MODE') = 'NORMAL' then 
        if not ID_NULL(hDummy) then 
          -- they are using the standard Object Group
          GO_ITEM(hDummy);
          if GET_ITEM_PROPERTY(startPoint,BLOCK_NAME) = GET_ITEM_PROPERTY(hDummy,BLOCK_NAME) then 
            NEXT_BLOCK;
          else
            GO_ITEM(startPoint);
          end if;
          ShowBeans(false);        
        else
          -- do nothing assume that the programmer is doing their own thing.
          -- with regards to setting up the bean areas and making sure they are drawn
           null;      
        end if;
      end if;
    end if;
        
    -- Work out the server o/s informtion that we need
    if instr(upper(GET_APPLICATION_PROPERTY(OPERATING_SYSTEM)),'WIN') > 0 then 
      m_serverFileSep := '\';
    else
      m_serverFileSep := '/';
    end if;
  END InitWebUtil;
```

#### SP-062 - WEBUTIL.IN_PROGRESS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.DOWNLOADINT]
- webutil.pld [StoredProcedure: WEBUTIL.UPLOADINT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the In Progress capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the In Progress operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  
  FUNCTION In_Progress return BOOLEAN is
    status VARCHAR2(5);
  BEGIN 
    status := WebUtil_Core.getProperty(WebUtil_Core.WUT_PACKAGE,'WUT_STATUS');
    return (status='BUSY');
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUT_PACKAGE)
                              ||' bean not found. WEBUTIL_FILE_TRANSFER.In_Progress will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;  
  END In_Progress;
```

#### SP-063 - WEBUTIL.ISERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Iserror capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Iserror operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  FUNCTION isError   return BOOLEAN is
  begin 
    return m_lastError <> 0;
  end;
```

#### SP-064 - WEBUTIL.IS_OPEN

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Is Open capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Is Open operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  
  FUNCTION is_open(file file_type) RETURN BOOLEAN IS
  BEGIN
    IF file.handle IS NULL THEN
      RETURN(FALSE);
    ELSE
      RETURN(TRUE);
    END IF;
  END is_open;
```

#### SP-065 - WEBUTIL.LENGTH

**Invoked From:**

- vr_ewinv_fmb.xml [StoredProcedure: CALL_REPORT]
- D2kwutil.pld [StoredProcedure: DEBUGLOG]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: STRIPDIRSEP]
- webutil.pld [StoredProcedure: WEBUTIL.CHECKASACL]
- webutil.pld [StoredProcedure: WEBUTIL.GETSTRING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Length capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Length operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  FUNCTION length(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_LONG_METHOD(FALSE, obj, 'java/io/File', 'length', '()J', args); 
  END;
```

#### SP-066 - WEBUTIL.LOG

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]
- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Log capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| msg | VARCHAR2 | IN |
| isError | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-030](#SP-030--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ISERROR ([SP-063](#SP-063--WEBUTIL.ISERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.IS_OPEN ([SP-064](#SP-064--WEBUTIL.IS_OPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-074](#SP-074--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Log operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  

  PROCEDURE Log(msg in VARCHAR2, isError BOOLEAN) is
    logFile       TEXT_IO.FILE_TYPE;
    logFileName   VARCHAR2(1024 char);
    errorOnlyMode BOOLEAN;
  begin
    -- check to see if we should do anything
    if m_loggingAllowed is null then 
      -- set up the logging info Cache
      m_loggingAllowed    := (lower(ReadFromPropertyBundle('logging.enabled')) = 'true');
      m_loggingErrorsOnly := (lower(ReadFromPropertyBundle('logging.errorsonly')) = 'true');
      m_loggingFile       := ReadFromPropertyBundle('logging.file');
      if m_loggingAllowed then 
        if m_loggingFile is null then 
          -- no file == no logging
          m_loggingAllowed := false;
          if m_registeredPackages.FIRST is null then
            -- There is no bean registered yet. Throw error in English using alert
            ErrorAlert('WUC-008: Server side logging was requested but no log file was specified'
                       ||' - logging is disabled');
          else
            WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
            WebUtil_Core.error(WUC_PACKAGE,8,'WebUtil_Core.Log');
          end if;
        end if;
      end if;
      if m_registeredPackages.FIRST is not null then
        -- At least one bean is registered. Can call setProperty(WUC_PACKAGE)
        if m_loggingAllowed and m_loggingErrorsOnly then
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','1',true);
        elsif  m_loggingAllowed then
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','2',true);
        else
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
        end if;
      end if;
    end if;
        
    -- now log if allowed to do so
    if m_loggingAllowed then
      if ((not m_loggingErrorsOnly) or (m_loggingErrorsOnly and isError)) then
        logFile := TEXT_IO.FOPEN(m_loggingFile,'A');
        if not TEXT_IO.IS_OPEN(logFile) then 
          raise NO_DATA_FOUND;
        end if;
        if m_clientIP is null then
        	TEXT_IO.PUT_LINE(logFile,msg);
        else
        	TEXT_IO.PUT_LINE(logFile,m_clientIP||':'||m_clientUserName||': '||msg);
        end if;
        TEXT_IO.FCLOSE(logFile);
      end if;    
    end if;
  EXCEPTION
    when others then 
      if SQLCODE = '-302000' then
        if m_registeredPackages.FIRST is null then
          -- There is no bean registered yet. Throw error in English using alert
          ErrorAlert('WUC-007: Unable to write to WebUtil Logging File '|| m_loggingFile);
        else

          WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
          WebUtil_Core.error(WebUtil_Core.WUC_PACKAGE,7,'WebUtil_Core.Log',m_loggingFile);
        end if;
        m_loggingAllowed := false;
      else
        RAISE;
      end if;      
  end Log;
```

#### SP-067 - WEBUTIL.NEW

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.DOWNLOADINT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the New capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the New operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  FUNCTION new RETURN ORA_JAVA.JOBJECT IS
  BEGIN
    args := NULL;
    RETURN (JNI.NEW_OBJECT('oracle/forms/webutil/fileTransfer/AppServerFileReader', '()V', args));
  END;
```

#### SP-068 - WEBUTIL.OPENBLOB

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.DOWNLOADINT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Openblob capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| blobTable | VARCHAR2 | IN |
| blobColumn | VARCHAR2 | IN |
| blobWhere | VARCHAR2 | IN |
| openMode | VARCHAR2 | IN |
| chunkSize | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Openblob operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql

  FUNCTION  OpenBlob(blobTable  in VARCHAR2,
                     blobColumn in VARCHAR2,
                     blobWhere  in VARCHAR2,
                     openMode   in VARCHAR2,
                     chunkSize  in PLS_INTEGER default null) return BOOLEAN is
  BEGIN
    return WebUtil_DB.OpenBlob(blobTable,
                             blobColumn,
                             blobWhere,
                             openMode,
                             chunkSize);
  END OpenBlob;
```

#### SP-069 - WEBUTIL.OPENFILE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.DOWNLOADINT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Openfile capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |
| a0 | VARCHAR2 | IN |
| a1 | NUMBER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Openfile operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  FUNCTION openFile(
    obj   ORA_JAVA.JOBJECT,
    a0    VARCHAR2,
    a1    NUMBER) RETURN BOOLEAN IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(2);
    JNI.ADD_STRING_ARG(args, a0);
    JNI.ADD_INT_ARG(args, a1);
    RETURN JNI.CALL_BOOLEAN_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'openFile', '(Ljava/lang/String;I)Z', args); 
  END;
```

#### SP-070 - WEBUTIL.POPULATEPROPERTYBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.READFROMPROPERTYBUNDLE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Populatepropertybundle capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-030](#SP-030--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Populatepropertybundle operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
      
  FUNCTION PopulatePropertyBundle(propertyKey in VARCHAR2) return VARCHAR2 is
    configFile   VARCHAR2(512 char);
    buffer       VARCHAR2(1000 char);
    result       VARCHAR2(1000 char);          
    propertyFile TEXT_IO.FILE_TYPE;
    pos          PLS_INTEGER;
    propIndex    PLS_INTEGER := 0;
  begin
    -- First of get the name of the cfg file 
    -- This could come in a global  or from the Environment
    default_value('[NOTSET]',WEBUTIL_CONFIG_GLOBAL);
    configFile := name_in(WEBUTIL_CONFIG_GLOBAL);
    if configFile = '[NOTSET]' then
      configFile := null; 
      -- Try the environment
      TOOL_ENV.GETVAR(WEBUTIL_CONFIG_ENV, configFile); 
      if configFile is null then 
        -- Finally try the Forms parameters
        configFile := name_in(WEBUTIL_CONFIG_PARAM);
        -- if that fails then we have to raise an error
        if configFile is null then 
          raise NO_DATA_FOUND;
        end if;    
      end if;
    end if;
    
    copy(configFile, WEBUTIL_CONFIG_GLOBAL);
      
    propertyFile := Text_IO.FOpen(configFile,'R');
    LOOP
      begin
        Text_IO.Get_Line(propertyFile,buffer);
      exception
        when NO_DATA_FOUND then EXIT;
      end;
        
      -- ignore lines which start with '#'
      if substr(buffer,1,1) <> '#' then 
        pos := instr(buffer,'=');
        -- only process lines with a name value pair
        if pos > 0 then 
          propIndex := propIndex + 1;
          m_propertyBundle(propIndex).propertyKey   := lower(ltrim(rtrim(substr(buffer,1,pos-1))));    
          m_propertyBundle(propIndex).propertyValue := ltrim(rtrim(replace(substr(buffer,pos+1),chr(13),'')));
          -- Check to see if this is the key we are looking for
          if  m_propertyBundle(propIndex).propertyKey = lower(propertyKey) then
            result := m_propertyBundle(propIndex).propertyValue;
          end if;
        end if;
      end if;
    end LOOP;
    Text_IO.FClose(propertyFile);
    return result;
  EXCEPTION
    when NO_DATA_FOUND then 
      if m_registeredPackages.FIRST is null then
        -- There is no bean registered yet. Throw error in English using alert
        ErrorAlert('WUC-005: No WebUtil Configuration File specified');
      else
        Webutil_Core.Error(Webutil_Core.WUC_PACKAGE,5,'WebUtil_Core.PopulatePropertyBundle');
      end if;
      m_config_error := true;
      return null;
    when others then 
      if SQLCODE = '-302000' then
        if m_registeredPackages.FIRST is null then
          -- There is no bean registered yet. Throw error in English using alert
          ErrorAlert('WUC-006: Unable to read WebUtil Configuration File');
        else
          Webutil_Core.Error(Webutil_Core.WUC_PACKAGE,6,'WebUtil_Core.PopulatePropertyBundle', configFile);
        end if;
        m_config_error := true;
        return null;
      else
        RAISE;
      end if;      

  end PopulatePropertyBundle;
```

#### SP-071 - WEBUTIL.PUT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.UPLOADINT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Put capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |
| item | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Put operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  PROCEDURE put (file file_type, item VARCHAR2) IS
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);              
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_PUT',item);        
  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.put will not work');
      RAISE TOOL_ERR.TOOL_ERROR;                                                                 
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE TOOL_ERR.TOOL_ERROR;  
  END put;
```

#### SP-072 - WEBUTIL.PUT_LINE

**Invoked From:**

- vr_ewinv_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Put Line capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |
| item | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Put Line operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
    

  PROCEDURE put_line (file file_type, item VARCHAR2) is
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);              
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_PUT',item); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_NEWLINE',1); 
  EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.put_line will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;  
  END put_line;
```

#### SP-073 - WEBUTIL.READDATA

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.DOWNLOADINT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Readdata capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Readdata operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  FUNCTION readData(
    obj   ORA_JAVA.JOBJECT) RETURN VARCHAR2 IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_STRING_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'readData', '()Ljava/lang/String;', args); 
  END;
```

#### SP-074 - WEBUTIL.READFROMPROPERTYBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.LOG]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Readfrompropertybundle capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.POPULATEPROPERTYBUNDLE ([SP-070](#SP-070--WEBUTIL.POPULATEPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Readfrompropertybundle operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  
  FUNCTION ReadFromPropertyBundle(propertyKey in VARCHAR2) return VARCHAR2 is   
    result       VARCHAR2(1000 char);
    propCount    PLS_INTEGER := m_propertyBundle.COUNT;
  begin
    if m_config_error then
      -- already encountered problem reading the config file.
      return null;
    elsif (propCount = 0) then
      result := populatePropertyBundle(propertyKey);
    else
      for i in 1..propCount LOOP
        if m_propertyBundle(i).propertyKey = lower(propertyKey) then 
          result := m_propertyBundle(i).propertyValue;
          EXIT;
        end if;
      end LOOP;
    end if;
    return result;
  end ReadFromPropertyBundle;
```

#### SP-075 - WEBUTIL.READTRANSFROMMSGBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Readtransfrommsgbundle capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |
| args | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Readtransfrommsgbundle operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  
  FUNCTION ReadTransFromMsgBundle(propertyKey in VARCHAR2, args in VARCHAR2 := null) return VARCHAR2 is
    -- currently called from checkLibs only for getting progress bar title.
  begin 
    Webutil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_TRANS_MSG', propertyKey||'|'||args);
    return Webutil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_TRANS_MSG');
  end ReadTransFromMsgBundle;
```

#### SP-076 - WEBUTIL.REGISTERBEAN

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Registerbean capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| clientInfo | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.CHECKLIBS ([SP-019](#SP-019--WEBUTIL.CHECKLIBS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTSETTING ([SP-040](#SP-040--WEBUTIL.GETCLIENTSETTING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETOSFAMILY ([SP-045](#SP-045--WEBUTIL.GETOSFAMILY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETPROPERTY ([SP-048](#SP-048--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETVAR ([SP-053](#SP-053--WEBUTIL.GETVAR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-066](#SP-066--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-074](#SP-074--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETCLIENTSETTING ([SP-080](#SP-080--WEBUTIL.SETCLIENTSETTING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Registerbean operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

- DB-001 - Update THIS - Updates existing rows in THIS.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  PROCEDURE registerBean(clientInfo in VARCHAR2) is  
    packageID       PLS_INTEGER;
    beanShortName   VARCHAR2(3 char);
    newPackage      BOOLEAN := false;
    checkUserLibs   BOOLEAN := false;
    clientLibDir    VARCHAR2(1000 char);
    clientLibDirOld VARCHAR2(1000 char);
    serverHost      VARCHAR2(100 char);
    blockAllowHeartBeat VARCHAR2(10 char);
    clientOSArch    VARCHAR2(30 char);
  begin
    beanShortName := DelimStr.getString(clientInfo,1,true,'|');

    -- To speed access up we crossmatch the Bean Name string
    -- with a constant - this constant is used to access the 
    -- registered package array efficently
    -- need to update this IF statement as we add new packages
    if beanShortName = 'WUC' then
       packageID := WEBUTIL_CORE.WUC_PACKAGE; 
    elsif beanShortName = 'WUT' then     
       packageID := WEBUTIL_CORE.WUT_PACKAGE; 
    elsif beanShortName = 'WUF' then 
       packageID := WEBUTIL_CORE.WUF_PACKAGE; 
    elsif beanShortName = 'WUI' then
        packageID := WEBUTIL_CORE.WUI_PACKAGE; 
    elsif beanShortName = 'WUH' then            
       packageID := WEBUTIL_CORE.WUH_PACKAGE;
    elsif beanShortName = 'WUS' then     
       packageID := WEBUTIL_CORE.WUS_PACKAGE;
    elsif beanShortName = 'WUB' then 
       packageID := WEBUTIL_CORE.WUB_PACKAGE;
    elsif beanShortName = 'WUO' then     
       packageID := WEBUTIL_CORE.WUO_PACKAGE;
    elsif beanShortName = 'WUU' then     
       packageID := WEBUTIL_CORE.WUU_PACKAGE;
    elsif beanShortName = 'WUL' then     
       packageID := WEBUTIL_CORE.WUL_PACKAGE;           
    end if;
    -- For the very first bean we can get a bit of useful information
    -- Only do this once
    if m_clientIP is null then 
      checkUserLibs := true;
      -- Format of the clientinfo packet is
      -- BeanName|IP|OSName|UserName|pathSep|filesep
      m_clientIP       := DelimStr.getString(clientInfo,2,true,'|');
      m_clientOS       := DelimStr.getString(clientInfo,3,true,'|');
      m_clientOSFamily := getOSFamily(m_clientOS);
      clientOSArch     := DelimStr.getString(clientInfo,4,true,'|');
      if instr(clientOSArch, '64') > 0 then
        m_clientOSArch := 1;
      end if;
      m_clientUserName := DelimStr.getString(clientInfo,5,true,'|');      
      m_clientPathSep  := DelimStr.getString(clientInfo,6,true,'|');
      m_clientFileSep  := DelimStr.getString(clientInfo,7,true,'|');
      m_clientLangCode := DelimStr.getString(clientInfo,8,true,'|'); 
    end if;
      
    -- I'd only expect one instance of each bean per form
    -- but just in case we only register the first 
    -- so if multiple copies are used - e.g. it's 
    -- placed in a multi-row block we just use the 
    -- first instance.
    if not m_registeredPackages.EXISTS(packageID) then 
      m_registeredPackages(packageID) := name_in('SYSTEM.TRIGGER_ITEM');
      -- make sure all the required libraries are available
      -- on the client
      newPackage := true;
    end if;
      
    if checkUserLibs then
      -- checkUserLibs would be true if clientIP was null
      -- We can do whatever we want to do but not more than once
      REDOWNLOAD_SYSLIB := FALSE;
      -- We need to get the server host name using available built-ins. This looks lame,
      -- but it should work
      TOOL_ENV.GETVAR('COMPUTERNAME', serverHost);
      if serverHost is null then
        TOOL_ENV.GETVAR('HOST', serverHost);
      end if;
      clientLibDir := readFromPropertyBundle('install.syslib.location.client.'||to_char(m_clientOSFamily) ||
                                             '.' || to_char(m_clientOSArch));
      if clientLibDir is null then
        clientLibDir := readFromPropertyBundle('install.syslib.location.client.'||to_char(m_clientOSFamily));
      end if;
      if clientLibDir is null then
        -- client location when syslib download is not defined in webutil.cfg
        -- will be to client JRE. Send nothing and client will handle
        WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SYSLIB_DIR',
                                 ':' || serverHost || ':' || GET_APPLICATION_PROPERTY(CONFIG),
                                 true);
      else
        -- webutil.cfg contains a specific client directory for syslib download
        -- Replace $(SERVERHOST), if exists, with server host name
        clientLibDir := replace(clientLibDir, '$(SERVERHOST)', serverHost);

        -- The following line makes a few things happen on client including
        -- client directory creation, when clientLibDir is not null
        WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SYSLIB_DIR',
                                 clientLibDir || ':' || serverHost || ':' || GET_APPLICATION_PROPERTY(CONFIG),
                                 true);
        clientLibDirOld := GetClientSetting('install.syslib.dir');

        if clientLibDirOld <> clientLibDir then
    	  SetClientSetting('install.syslib.dir', clientLibDir);
          REDOWNLOAD_SYSLIB := TRUE;
    	end if;
      end if;
      Webutil_Core.WEBUTIL_VERSION := getProperty(WUC_PACKAGE,'WUC_BEAN_VERSION');
      -- We want to write the connection record if it's required.
      -- Any call to ReadFromPropertyBundle or log should be preferably made after
      -- registering at least one bean. That is the reason why the following log
      -- comes after m_registeredPackages(packageID) := name_in('SYSTEM.TRIGGER_ITEM'); above
      if lower(ReadFromPropertyBundle('logging.connections')) = 'true' then 
        log('Connection from Form='||GET_APPLICATION_PROPERTY(CURRENT_FORM)||' Client O/S='||m_clientOS||' locale='||m_clientLangCode,false);
      end if;
    end if;
    if newPackage then  
            checkLibs(to_char(packageID));
    end if;

    if checkUserLibs then
      -- Call a dummy log to initialize m_loggingAllowed and m_loggingErrorsOnly
      log(null,false);
    end if;

    -- 5950737 - Introduce new configuration variable BlockAllowHeartBeat. 
    -- Valid values are true, yes and 1.
    -- If this is set then send a message to the client to behave accordingly.    
    blockAllowHeartBeat := lower(ReadFromPropertyBundle('BlockAllowHeartBeat'));
    if blockAllowHeartBeat = 'true' or blockAllowHeartBeat = 'yes' or blockAllowHeartBeat = '1' then 
      WebUtil_Core.setProperty(packageID,'WUC_BLOCK_ALLOW_HEART_BEAT','1',true);
    else
      WebUtil_Core.setProperty(packageID,'WUC_BLOCK_ALLOW_HEART_BEAT','0',true);
    end if;

    -- Send server logging options to client bean so that the bean does not have
    -- to send message to server unnecessarily.
    if m_loggingAllowed and m_loggingErrorsOnly then
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','1',true);
    elsif m_loggingAllowed then
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','2',true);
    else
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','0',true);
    end if;
      
    -- 2836929 - move the user library check after the first package is registered 
    -- so that a handler bean exists to do the download.     
    if checkUserLibs then 
      --Check for and download any user libs
      checkLibs('user');  
    end if;     
  end registerBean;
```

#### SP-077 - WEBUTIL.REGISTER_FUNCTION

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Register Function capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| libName | VARCHAR2 | IN |
| funcName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-059](#SP-059--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Register Function operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql

  FUNCTION REGISTER_FUNCTION (libName IN VARCHAR2, funcName IN VARCHAR2) 
                              RETURN FunctionHandle IS
    strHnd  VARCHAR2(8);                            
    funcHnd FunctionHandle;
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUL_PACKAGE,'WUL_FUNCTION_SPEC', libName || '|' || funcName);
    strHnd := WebUtil_Core.getProperty(WebUtil_Core.WUL_PACKAGE,'WUL_REGISTER_FUNCTION');
    funcHnd.hnd := TO_NUMBER (strHnd);
    if NOT ID_NULL(funcHnd) then
      m_funcHandleCount := m_funcHandleCount + 1;
    end if;

    RETURN funcHnd;
    
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUL_PACKAGE)
                              ||' bean not found. WEBUTIL_C_API.REGISTER_FUNCTION will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;  
    when VALUE_ERROR then
        RAISE TOOL_ERR.TOOL_ERROR; 
  END REGISTER_FUNCTION;
```

#### SP-078 - WEBUTIL.RELEASE_PROCESS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.HOST]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Release Process capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Release Process operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Release_Process(process in out PROCESS_ID) is  
  begin
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_CLEAR_PROC',process.handle);
    WebUtil_Core.ClearCallbackTrigger(process.handle);
    process.handle := null;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.Release_Process will not work');
  end Release_Process;
```

#### SP-079 - WEBUTIL.SETCALLBACKTRIGGER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.UPLOADINT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Setcallbacktrigger capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| callbackKey | PLS_INTEGER | IN |
| triggerName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Setcallbacktrigger operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  
  PROCEDURE SetCallbackTrigger(callbackKey in PLS_INTEGER, triggerName in VARCHAR2) is
  begin 
    m_callbacks(callbackKey) := triggerName;
  end SetCallbackTrigger;
```

#### SP-080 - WEBUTIL.SETCLIENTSETTING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Setclientsetting capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyName | VARCHAR2 | IN |
| propertyValue | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Setclientsetting operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql

  PROCEDURE SetClientSetting(propertyName  in VARCHAR2,
                             propertyValue in VARCHAR2) is
  BEGIN
    if propertyName is not null then 
      WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SET_LOCAL_PROPERTY', propertyName||'='||propertyValue);
    end if;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                              ||' bean not found. WEBUTIL_CORE.SetClientSetting will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;       
  END SetClientSetting;
```

#### SP-081 - WEBUTIL.SETDATA

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Setdata capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| uploadData | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.CLEARCALLBACKTRIGGER ([SP-020](#SP-020--WEBUTIL.CLEARCALLBACKTRIGGER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.CLOSEBLOB ([SP-021](#SP-021--WEBUTIL.CLOSEBLOB)) - WEBUTIL.pck (or .pld)
- WEBUTIL.CLOSEFILE ([SP-022](#SP-022--WEBUTIL.CLOSEFILE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCALLBACKTRIGGER ([SP-037](#SP-037--WEBUTIL.GETCALLBACKTRIGGER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETLASTERROR ([SP-042](#SP-042--WEBUTIL.GETLASTERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETLASTERRORARGS ([SP-043](#SP-043--WEBUTIL.GETLASTERRORARGS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.WRITEDATA ([SP-084](#SP-084--WEBUTIL.WRITEDATA)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Setdata operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
   
  PROCEDURE SetData(uploadData in VARCHAR2) is 
    lastErrorCode    PLS_INTEGER;
    lastErrorArgs    VARCHAR2(1000);   
  BEGIN
    if uploadData is null or uploadData = '' then 
      -- error condition!
      m_uploadSucceeded := false;
    else
      -- Write to the correct place    
      if m_toDB then 
        WebUtil_DB_LOCAL.WriteData(uploadData);
      else
        if not JAVA_APPSERV_WRITER.WriteData(m_persistObj,uploadData) then
          lastErrorCode := JAVA_APPSERV_WRITER.getLastError(m_persistObj);
          lastErrorArgs := JAVA_APPSERV_WRITER.getLastErrorArgs(m_persistObj) ;
          WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                             'WEBUTIL_FILE_TRANSFER.SetData',lastErrorArgs);
          raise READWRITE_ERROR;
        end if;
      end if;
      m_chunks := m_chunks - 1;
      if m_chunks = 0 then 
        if m_toDB then 
          if WebUtil_DB_Local.CloseBlob(m_fileSize) then 
            m_uploadSucceeded := true;
          else
            WebUtil_core.Error(Webutil_Core.WUT_PACKAGE, WebUtil_DB_Local.getLastError,
                               'WEBUTIL_FILE_TRANSFER.SetData');
          end if; -- close
        else
          if JAVA_APPSERV_WRITER.CloseFile(m_persistObj,m_fileSize) then
            m_uploadSucceeded := true;
          else
            lastErrorCode := JAVA_APPSERV_WRITER.getLastError(m_persistObj);
            lastErrorArgs := JAVA_APPSERV_WRITER.getLastErrorArgs(m_persistObj) ;
            WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                               'WEBUTIL_FILE_TRANSFER.SetData',lastErrorArgs);
            ORA_JAVA.DELETE_GLOBAL_REF(m_persistObj);
            raise READWRITE_ERROR;
          end if;    
        end if; -- toDB

        if WebUtil_Core.GetCallbackTrigger(-1) is not null then
          EXECUTE_TRIGGER(WebUtil_Core.GetCallbackTrigger(-1));
        end if;
        WebUtil_Core.ClearCallbackTrigger(-1);
      end if; -- chunks
    end if;
  end SetData;
```

#### SP-082 - WEBUTIL.SETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Setproperty capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |
| a1 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Setproperty operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  FUNCTION setProperty(
    a0    VARCHAR2,
    a1    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(2);
    JNI.ADD_STRING_ARG(args, a0);
    JNI.ADD_STRING_ARG(args, a1);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'setProperty', '(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-083 - WEBUTIL.UPLOADINT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_FILE_TRANSFER.CLIENT_TO_AS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Uploadint capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| clientFile | VARCHAR2 | IN |
| spec1 | VARCHAR2 | IN |
| spec2 | VARCHAR2 | IN |
| spec3 | VARCHAR2 | IN |
| toDB | BOOLEAN | IN |
| withProgress | BOOLEAN | IN |
| progressTitle | VARCHAR2 | IN |
| progressSubTitle | VARCHAR2 | IN |
| asynchronous | BOOLEAN | IN |
| callbackTrigger | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.CHECKASACL ([SP-017](#SP-017--WEBUTIL.CHECKASACL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.DECODEBASE64FILE ([SP-024](#SP-024--WEBUTIL.DECODEBASE64FILE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.FILE_IS_READABLE ([SP-035](#SP-035--WEBUTIL.FILE_IS_READABLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.IN_PROGRESS ([SP-062](#SP-062--WEBUTIL.IN_PROGRESS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.PUT ([SP-071](#SP-071--WEBUTIL.PUT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETCALLBACKTRIGGER ([SP-079](#SP-079--WEBUTIL.SETCALLBACKTRIGGER)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Uploadint operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  FUNCTION UploadInt ( clientFile       in VARCHAR2, 
                       spec1            in VARCHAR2, 
                       spec2            in VARCHAR2,
                       spec3            in VARCHAR2,
                       toDB             in BOOLEAN,
                       withProgress     in BOOLEAN,
                       progressTitle    in VARCHAR2,
                       progressSubTitle in VARCHAR2,                       
                       asynchronous     in BOOLEAN default FALSE,
                       callbackTrigger  in VARCHAR2 default NULL) return BOOLEAN is
    clientFileSize   PLS_INTEGER := 0;   
    clientFileChunks PLS_INTEGER := 0;                       
    clientFileInfo   VARCHAR2(1000 char);
    result           BOOLEAN     := FALSE;
    dataBuffer       VARCHAR2(32767);
    ignore           VARCHAR2(2);
    jobj             ORA_JAVA.JOBJECT;
    lastErrorCode    PLS_INTEGER;
    lastErrorArgs    VARCHAR2(1000);
    encodedFile      ORA_JAVA.JOBJECT;
    ftemp            TEXT_IO.FILE_TYPE;
    tempFileName     VARCHAR2(512);
    bool_ignore      boolean;
  BEGIN
    -- Client file cannot be null
    if clientFile is null then
        raise CLIENT_FILE_NULL;
    end if;

    -- Application server file cannot be null. AppsServerFileWriter also handles this.
    -- Better to handle here.
    if NOT toDB AND spec1 is null then
        raise AS_FILE_NULL;
    end if;
 

    -- Make sure the client file to be uploaded exists and readable
    -- If we don't raise exception here, we end up creating an empty file on
    -- database or application server
    if NOT webutil_file.file_is_readable(clientFile)
       OR webutil_file.file_is_directory (clientFile) then
      raise FILE_NOT_FOUND;
    end if;
      
    -- First check to see if a transfer is not currently happening
    if In_Progress then
        raise AGENT_BUSY;
    end if;

    -- reset the target
    m_toDB := toDB;

    -- Set up the file info
    clientFileInfo := clientFile||'|0|'||
                      WEBUTIL_UTIL.BoolToStr(asynchronous,'A|','S|')||
                      WEBUTIL_UTIL.BoolToStr(withProgress,'Y|','N|')||
                      progressTitle||'|'||
                      progressSubTitle;
    WebUtil_Core.setProperty(WebUtil_Core.WUT_PACKAGE,'WUT_FILE_INFO', clientFileInfo);
    
    -- get the size and chunk info of the client side file
    clientFileInfo   := WebUtil_Core.getProperty(WebUtil_Core.WUT_PACKAGE,'WUT_FILE_INFO');
    clientFileSize   := DelimStr.getNumber(clientFileInfo,1,true,'|');
    if clientFileSize = 0 then
      raise CLIENT_FILE_EMPTY;
      -- no need to close application server file since it is not yet opened.
    end if;
    clientFileChunks := DelimStr.getNumber(clientFileInfo,2,true,'|');
    
    -- Set up the Open command
    if toDB then 
      if not m_DBEnabled then 
        raise TRANSFER_FORBIDDEN;
      end if;
      if  not WebUtil_DB_Local.openblob(spec1, spec2, spec3,'W', m_maxTransferSize) then 
        WebUtil_core.Error(WebUtil_Core.WUT_PACKAGE,WebUtil_DB_Local.getLastError,
                           'WEBUTIL_FILE_TRANSFER.uploadInt');
        raise READWRITE_ERROR;
      end if;
    else
      if not WebUtil_Core.checkJava then 
        raise NO_JAVA;
      end if;        
      if not checkASACL(spec1,m_writeACL) then 
        raise TRANSFER_FORBIDDEN;
      end if;        
      jobj := JAVA_APPSERV_WRITER.NEW;
      if not JAVA_APPSERV_WRITER.openFile(jobj,spec1) then 
        lastErrorCode := JAVA_APPSERV_WRITER.getLastError(jobj);
        lastErrorArgs := JAVA_APPSERV_WRITER.getLastErrorArgs(jobj) ;
        WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                           'WEBUTIL_FILE_TRANSFER.uploadInt',lastErrorArgs);
        raise READWRITE_ERROR;
      end if;
    end if;
    -- Is this Async? if So we do nothing more here just set the callback and kick it off
    if asynchronous then 
      -- set callbackTrigger even if it is null. we will take care
      -- before calling
      WebUtil_Core.SetCallbackTrigger(-1,callbackTrigger);
      ignore   := WebUtil_Core.getProperty(WebUtil_Core.WUT_PACKAGE,'WUT_TRANSFER');
      m_chunks := clientFileChunks;
      m_fileSize := clientFileSize;  
      m_uploadSucceeded := NULL;
      if not toDB then
          m_persistObj := ORA_JAVA.NEW_GLOBAL_REF(jobj);
      end if;
      result := true;
    else
      if NOT toDB then
        encodedFile := JAVA_FILE.createTempFile('WUAS','.enc');
        tempFileName := JAVA_FILE.getPath(encodedFile);
      end if;

      -- loop through each chunk 
      for i in 1..clientFileChunks LOOP
        dataBuffer := WebUtil_Core.getProperty(WebUtil_Core.WUT_PACKAGE,'WUT_TRANSFER',false);
        if (WebUtil_Core.isError) or (dataBuffer is null) then
          raise AGENT_BUSY;
        end if;
            
        -- Write to the correct place    
        if toDB then 
          WebUtil_DB_Local.WriteData(dataBuffer);
        else
          ftemp := TEXT_IO.FOPEN(tempFileName, 'W');
          TEXT_IO.PUT(ftemp, dataBuffer);
          TEXT_IO.FCLOSE(ftemp);
          -- if not JAVA_APPSERV_WRITER.WriteData(jobj,dataBuffer) then
          if not JAVA_APPSERV_WRITER.decodeBASE64File(jobj,tempFileName) then
            lastErrorCode := JAVA_APPSERV_WRITER.getLastError(jobj);
            lastErrorArgs := JAVA_APPSERV_WRITER.getLastErrorArgs(jobj) ;
            WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                               'WEBUTIL_FILE_TRANSFER.UploadInt',lastErrorArgs);
            raise READWRITE_ERROR;
          end if;
        end if;
      end LOOP;
      if toDB then
        if WebUtil_DB_Local.CloseBlob(clientFileSize) then 
          result := true;
        else
          WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,WebUtil_DB_Local.getLastError,
                             'WEBUTIL_FILE_TRANSFER.UploadInt');
        end if;  -- close        
      else
        bool_ignore := JAVA_FILE.DELETE_(encodedFile);
        if JAVA_APPSERV_WRITER.CloseFile(jobj,clientFileSize) then
          result := true;
        else
          lastErrorCode := JAVA_APPSERV_WRITER.getLastError(jobj);
          lastErrorArgs := JAVA_APPSERV_WRITER.getLastErrorArgs(jobj) ;
          WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                            'WEBUTIL_FILE_TRANSFER.UploadInt',lastErrorArgs);
          raise READWRITE_ERROR;
        end if;
      end if;      
    end if; -- async
    return result;
  EXCEPTION
    when CLIENT_FILE_EMPTY then
      WebUtil_Core.Error(Webutil_Core.WUT_PACKAGE,133,'WEBUTIL_FILE_TRANSFER.UploadInt', clientFile);
      return false;
    when CLIENT_FILE_NULL then
      WebUtil_Core.Error(Webutil_Core.WUT_PACKAGE,130,'WEBUTIL_FILE_TRANSFER.UploadInt');
      return false;
    when AS_FILE_NULL then
      WebUtil_Core.Error(Webutil_Core.WUT_PACKAGE,117,'WEBUTIL_FILE_TRANSFER.UploadInt');
      return false;
    when FILE_NOT_FOUND then
      WebUtil_Core.Error(Webutil_Core.WUT_PACKAGE,129,'WEBUTIL_FILE_TRANSFER.UploadInt', clientFile);
      return false;
    when TRANSFER_FORBIDDEN then 
      WebUtil_Core.Error(Webutil_Core.WUT_PACKAGE,121,'WEBUTIL_FILE_TRANSFER.UploadInt');
      return false;                
    when AGENT_BUSY then 
      WebUtil_Core.Error(Webutil_Core.WUT_PACKAGE,116,'WEBUTIL_FILE_TRANSFER.UploadInt');
      return false;    
    when READWRITE_ERROR then 
      return false;          
    when NO_JAVA then 
      return false;
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUT_PACKAGE)
                             ||' bean not found. WEBUTIL_FILE_TRANSFER.UploadInt will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;  
  END UploadInt;
```

#### SP-084 - WEBUTIL.WRITEDATA

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the Writedata capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Writedata operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  FUNCTION WriteData(
    obj   ORA_JAVA.JOBJECT,
    a0    VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_BOOLEAN_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileWriter', 'WriteData', '(Ljava/lang/String;)Z', args); 
  END;
```

#### SP-085 - WEBUTIL_CORE.CUSTOMEVENTHANDLER

**Invoked From:**

- vr_ewinv_fmb.xml [Trigger: WHEN-CUSTOM-ITEM-EVENT]

---

**Screen:**

N/A

---

**Purpose**

Provides the Customeventhandler capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| EventName | VARCHAR2 | IN |
| EventParameters | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERROR ([SP-029](#SP-029--WEBUTIL.ERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETNUMBER ([SP-044](#SP-044--WEBUTIL.GETNUMBER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-066](#SP-066--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.REGISTERBEAN ([SP-076](#SP-076--WEBUTIL.REGISTERBEAN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETDATA ([SP-081](#SP-081--WEBUTIL.SETDATA)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETPROPERTY ([SP-082](#SP-082--WEBUTIL.SETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Customeventhandler operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  PROCEDURE CustomEventHandler(EventName       in VARCHAR2, 
                               EventParameters in VARCHAR2) is
    dataPayload   VARCHAR2(32767 char);   
    dataMultiPart VARCHAR2(61 char); /* should be enough! */ 
    chunkNumber   PLS_INTEGER;
    PayloadChunks PLS_INTEGER;
    dataType      PLS_INTEGER;
    unhandled     EXCEPTION;
  begin
    --Bug 2839033 - check for valid events only      
    if EventName not in ('WUC_LOG_EVENT',
                         'WUC_ERROR_EVENT', 
                         'WUC_REGISTER',
                         'WUH_CALLBACK_EVENT', 
                         'WUT_TRANSFER_EVENT') then  
      raise unhandled;
    end if;                        

    -- We're pretty much always going to need the data payload and 
    -- number of parts that make up that payload so get it now..
    get_parameter_attr(EventParameters,'WUC_DATA',dataType, dataPayload);
    get_parameter_attr(EventParameters,'WUC_DATA_MULTIPART',dataType, dataMultiPart);      
    -- split the MULTIPART info to work out how many messages from the 
    -- client are required to create the completed payload
    chunkNumber   := DelimStr.getNumber(dataMultiPart,1,true,'/');
    PayloadChunks := DelimStr.getNumber(dataMultiPart,2,true,'/');

    -- Now deal with the specific events that the client may dispatch
    -- This section will have to be extended for each new event that we 
    -- Add in order to hook the handler code for that message to the data 
    -- that is being sent - shame we can't subclass in PL/SQL :-)      
    if EventName = 'WUC_LOG_EVENT' then
        WebUtil_Core.log(dataPayload,false);
    elsif EventName = 'WUC_ERROR_EVENT' then
        WebUtil_Core.log(dataPayload,true);
    elsif EventName = 'WUC_REGISTER' then 
        registerBean(dataPayload);
    elsif EventName = 'WUH_CALLBACK_EVENT' then 
      begin 
        m_lastCallback := to_number(dataPayload);
      exception
          when INVALID_NUMBER then 
            error(WebUtil_Core.WUC_PACKAGE,408,'WEBUTIL_CORE.CustomEventHandler');
      end;
      if m_lastCallback is not null then 
          EXECUTE_TRIGGER(m_callbacks(m_lastCallback));
      else
            log('Callback trigger for host command not specified',true);
      end if;
    elsif EventName = 'WUT_TRANSFER_EVENT' then 
      WebUtil_File_Transfer.setData(dataPayload);
      WebUtil_Core.setProperty(WebUtil_Core.WUT_PACKAGE, 'WUT_TRANSFER_EVENT','RECEIVED');
    end if;
  exception
    when unhandled then
      null;
    when OTHERS then
      raise;
  end CustomEventHandler;
```

#### SP-086 - WEBUTIL_CORE.SHOWBEANS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.INITWEBUTIL]
- vr_ewinv_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

N/A

---

**Purpose**

Provides the Showbeans capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| show | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-059](#SP-059--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Showbeans operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ShowBeans(show BOOLEAN) is
    hWin WINDOW := FIND_WINDOW(WEBUTIL_HIDDEN_WINDOW);
  begin
    -- Bug 2955789 - don't attempt to do this when in Enter Query Mode
    if name_in('SYSTEM.MODE') = 'NORMAL' then 
      if not ID_NULL(hWin) then 
        if show then 
          m_infoFrom := FIND_ITEM(name_in('SYSTEM.CURSOR_ITEM'));
          SET_WINDOW_PROPERTY(hWin,TITLE,'WebUtil '||WEBUTIL_VERSION);
          SHOW_WINDOW(hWin);
          go_item(WEBUTIL_DUMMY_ITEM);
        else
          if not id_null(m_infoFrom) then 
              go_item(m_infoFrom);
          end if;
          HIDE_WINDOW(hWin);
        end if;
      end if;
    end if;
  end ShowBeans;
```

#### SP-087 - WEBUTIL_FILE_TRANSFER.AS_TO_CLIENT

**Invoked From:**

- vr_ewinv_fmb.xml [ProgramUnit: DOWNLOAD_FILE]
- vr_ewinv_fmb.xml [StoredProcedure: DOWNLOAD_FILE]

---

**Screen:**

N/A

---

**Purpose**

Provides the As To Client capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| clientFile | VARCHAR2 | IN |
| serverFile | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.DOWNLOADINT ([SP-027](#SP-027--WEBUTIL.DOWNLOADINT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the As To Client operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  
  FUNCTION AS_To_Client
                     ( clientFile       in VARCHAR2, 
                       serverFile       in VARCHAR2) return BOOLEAN is
  BEGIN
    return DownloadInt
                     ( clientFile,
                       serverFile,
                       null,
                       null,
                       false,
                       false,
                       null,
                       null);
  END AS_To_Client;
```

#### SP-088 - WEBUTIL_FILE_TRANSFER.CLIENT_TO_AS

**Invoked From:**

- vr_ewinv_fmb.xml [ProgramUnit: UPLOAD_FILE]
- vr_ewinv_fmb.xml [StoredProcedure: UPLOAD_FILE]

---

**Screen:**

N/A

---

**Purpose**

Provides the Client To As capability as part of the WebUtil client-side infrastructure library. This is an infrastructure-level routine that enables Oracle Forms to interact with the client machine's resources.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| clientFile | VARCHAR2 | IN |
| serverFile | VARCHAR2 | IN |
| asynchronous | BOOLEAN | IN |
| callbackTrigger | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.UPLOADINT ([SP-083](#SP-083--WEBUTIL.UPLOADINT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameters required for the Client To As operation.
- Step 2 - Execute the WebUtil infrastructure operation on the client machine.
- Step 3 - Return the result or status to the calling routine.

---
**Decision Points**

N/A - infrastructure utility; conditional logic is handled internally by the WebUtil library and is not documented in the Oracle Forms source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - infrastructure utility; no form-level business rules apply to this routine.

---
**Implementation Logic**

```plsql
  
  FUNCTION Client_To_AS( clientFile       in VARCHAR2, 
                         serverFile       in VARCHAR2, 
                         asynchronous     in BOOLEAN default FALSE,
                         callbackTrigger  in VARCHAR2 default NULL) return BOOLEAN is
  BEGIN
    return UploadInt(
                       clientFile,
                       serverFile,
                       null,
                       null,
                       false,
                       false,
                       null,
                       null,
                       asynchronous,
                       callbackTrigger);
  END Client_To_AS;
```

#### SP-089 - ADD_ERROR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Part of the form-level error-management package. Records a single error entry by setting the global error-encountered flag and writing the formatted error text to the error stack, then emits a debug log entry via DEBUGLOG so that the error is immediately visible in diagnostic output.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| CallingFunction | VARCHAR2 | IN |
| SetErrorText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-094](#SP-094--DEBUGLOG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Receive the calling function name (CallingFunction) and the error description (SetErrorText) as inputs.
- Step 2 - Set the global ERROR_ENCOUNTERED flag to TRUE to signal that at least one error has been recorded in the current execution context.
- Step 3 - Compose the ERROR_STACK value by concatenating CallingFunction, a colon-space separator, and SetErrorText truncated to a maximum of 1,968 characters to prevent overflow.
- Step 4 - Invoke DEBUGLOG (SP-094) at debug level 99, identifying the source as 'Add_Error', and passing the composed ERROR_STACK value so the error is captured in the diagnostic log.

---
**Decision Points**

N/A - no conditional branches are present in the implementation; all four steps execute unconditionally on every invocation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The error text stored in ERROR_STACK must not exceed 1,968 characters; any excess characters are silently truncated via SUBSTR to prevent a value error.
- BR-002 - The ERROR_ENCOUNTERED flag must be set to TRUE whenever this procedure is called, ensuring the calling context can detect that one or more errors have occurred.
- BR-003 - The stored error entry must always identify its origin by prefixing the error text with the CallingFunction name and a colon-space separator, preserving traceability to the source routine.

---
**Implementation Logic**

```plsql

PROCEDURE Add_Error (CallingFunction in VARCHAR2, SetErrorText in VARCHAR2) is
begin 
  -- Just watch for value errors 
  ERROR_ENCOUNTERED  := TRUE;
  ERROR_STACK    := CallingFunction||': '||substr(SetErrorText,1,1968);
  Win_API_Debug.DebugLog(99,'Add_Error',ERROR_STACK);
end Add_Error;
```

#### SP-090 - ADD_EXTERNAL_ERRORS

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Part of the form-level error-management package (POPULATE_ERRORS). Appends externally sourced error details to the form-level error stack.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the external error details to record.
- Step 2 - Append the error details to the form-level error table.

---
**Decision Points**

N/A - utility package member; no conditional branches in the documented implementation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - internal error-management utility; no business rules apply.

---
**Implementation Logic**

```plsql

FUNCTION Add_External_Errors return varchar2 is
  iCounter   pls_integer;
  vcErrBuff  varchar2(1968);
begin 
  if tool_err.nerrors > 0 then 
    for iCounter in 1..tool_err.nerrors LOOP
      begin 
        vcErrBuff := vcErrBuff||chr(10)||tool_err.message;
      exception
        when VALUE_ERROR then 
          exit; /* String exceeds allowable buffer */
      end;
      tool_err.pop;
    end loop;
  elsif SQLERRM is not null then 
    vcErrBuff := chr(10)||SQLERRM; 
  end if;
  return vcErrBuff;
end Add_External_Errors;
```

#### SP-091 - BOOLTOCHAR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

BOOLTOCHAR is a utility function that converts a PL/SQL BOOLEAN value into its VARCHAR2 string equivalent ('TRUE' or 'FALSE'). It is used by calling routines such as GET_ENVIRONMENT_STRING and READ_REGISTRY within D2kwutil.pld to represent boolean state as a character value where a text representation is required.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| ThisBoolean | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input BOOLEAN parameter ThisBoolean.
- Step 2 - Evaluate the value of ThisBoolean.
- Step 3 - If ThisBoolean evaluates to TRUE, return the VARCHAR2 literal 'TRUE'.
- Step 4 - If ThisBoolean evaluates to FALSE (or NULL, per PL/SQL BOOLEAN semantics), return the VARCHAR2 literal 'FALSE'.
- Step 5 - Return the resulting VARCHAR2 string to the calling routine.

---
**Decision Points**

DP-001

Condition: ThisBoolean evaluates to TRUE.

TRUE: The function returns the VARCHAR2 string 'TRUE'.

FALSE: The function returns the VARCHAR2 string 'FALSE'.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must always return a non-null VARCHAR2 value; the only permitted return values are 'TRUE' and 'FALSE'.
- BR-002 - A PL/SQL BOOLEAN value of TRUE maps exclusively to the string 'TRUE'; any non-TRUE BOOLEAN value (FALSE or NULL) maps to the string 'FALSE'.
- BR-003 - The function accepts no parameters other than the single BOOLEAN input ThisBoolean and has no database interactions or external dependencies.

---
**Implementation Logic**

```plsql

  
  FUNCTION  BoolToChar(ThisBoolean IN BOOLEAN) return VARCHAR2 is
  begin
  	if ThisBoolean then 
  		RETURN 'TRUE';
  	else
  	    RETURN 'FALSE';
  	end if;
  end BoolToChar;

END;

PACKAGE WIN_API_DIALOG IS

/*-------------------------------------------------------------------------*\
 * WIN_API_DIALOG ->   This package is concerned with Displaying Common
 *      dialogs
 * Contents:
 *    Open_File    -> Open File Dialog
 *    Save_File    -> Save File Dialog
 *    Select_Printer    -> Printer Selection Dialog
 *    Choose_Font       -> Display the Font Selection Dialog
 *    Choose_Color      -> Display the Color Selection Dialog
 * Dependancies:
 *    WIN_API_ENVIRONMENT
 *    WIN_API
 *    WIN_API_DEBUG
\*-------------------------------------------------------------------------*/ 

/*-------------------------------------------------------------------------*\
 * Open_File        -> Displays the standard Open File dialog
 * Arguments: 
 *  Title           -> The Title for the Dialog Box
 *                     (Default -> 'Open File')
 *  StartDirectory  -> Where the dialog should start from
 *                     this should be in the format 'C:\TEMP'
 *                     (Default -> Windows Directory)
 *  FileFilter      ->  Restrict the list of files. The filter string 
 *                      should be in the format:
 *                      '<Description>|<filename>.<Extension>|'
 *                      typically this would be something like
 *                      'All files(*.*)|*.*|' or 'Text files(*.txt)|*.txt|'
 *                      "All Files" is the Default
 *  Modal           ->  Should the dialog be modal with respect to the 
 *                      application? 
 *                      default = TRUE
 *  AdvancedFlags   ->  (See list in WIN_API header) This option allows
 *                      you to change the attributes of the Open File 
 *                      dialog.  Here are some of the Flags that might
 *                      be of interest:
 *                      OFN_HIDEREADONLY  Hides the Read Only check box.
 *                      OFN_NONETWORKBUTTON  Hides the Network Button
 *                      OFN_EXPLORER    Display an Explorer style 
 *                        Dialog rather than the conventional one.
 *                      See your Microsoft docmentation for details on 
 *                      each flag.
 *                      To Set the Advanced_Flags varaible, just add the 
 *                      required flags together.  The default is:
 *                      WIN_API.OFN_PATHMUSTEXIST + WIN_API.OFN_FILEMUSTEXIST +
 *                      WIN_API.OFN_HIDEREADONLY + WIN_API.OFN_NOCHANGEDIR 
 *  RaiseExceptions ->  TRUE of FALSE(Default) If set to true, then if the 
 *                      command is not successful (e.g no filename is  
 *                      returned) then the explicit exception
 *                      NO_DATA_FOUND will be raised.
 *        
 * Returns:
 *  Path and name of the selected file
\*-------------------------------------------------------------------------*/
```

#### SP-092 - CLEAN_ERROR_STACK

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Part of the form-level error-management package (POPULATE_ERRORS). Resets the form-level error stack by clearing the error table and resetting the error counter.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Reset the error count to zero.
- Step 2 - Clear the form-level error table.

---
**Decision Points**

N/A - utility package member; no conditional branches in the documented implementation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

N/A - internal error-management utility; no business rules apply.

---
**Implementation Logic**

```plsql

PROCEDURE Clean_Error_Stack is 
begin 
  -- just empty the variables
  ERROR_ENCOUNTERED  := FALSE;
  ERROR_STACK        := NULL;
end Clean_Error_Stack;
```

#### SP-093 - CLIENT_HOST

**Invoked From:**

- vr_ewinv_fmb.xml [ProgramUnit: CALL_REPORT]
- vr_ewinv_fmb.xml [ProgramUnit: DOWNLOAD_FILE]
- vr_ewinv_fmb.xml [StoredProcedure: CALL_REPORT]
- vr_ewinv_fmb.xml [StoredProcedure: DOWNLOAD_FILE]

---

**Screen:**

Product Type : (N/A / CN_MAIN)

---

**Purpose**

Executes a command on the client machine's operating system, blocking the Forms session until the command completes. Used in the digital-signing workflow to invoke the client-side digital-signature tool and to delete temporary unsigned PDF files after signing is complete.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| syscmd | Varchar2 | IN |
| kwd | Number | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the command string to execute on the client machine.
- Step 2 - Submit the command to the client operating system using WebUtil host execution.
- Step 3 - Block the Forms session until the command completes.
- Step 4 - Return the process exit code to the caller.

---
**Decision Points**

DP-001

Condition: The command executes successfully (exit code is zero or the command completes).

TRUE: Return control to the calling routine.

FALSE: Return the non-zero exit code; the caller determines how to handle failures.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- The command must be a valid client-side OS command; the routine does not validate the command string before submitting it to the client OS.
- The Forms session is blocked while the command runs; long-running commands will delay the user experience.

---
**Implementation Logic**

```plsql

PROCEDURE CLIENT_HOST(syscmd Varchar2, kwd Number default NULL) IS
/*********************************************************************************\
 * CLIENT_HOST
 *   This procedure duplicates the action of the HOST Built-in, except that it 
 *   operates on the client (browser) tier rather than the application server tier.  
 *   Existing HOST code  can be re-directed to run on the client simply by 
 *   prefixing all the calls with "CLIENT_" 
 *   The oracle.forms.webutil.host.HostFunctions bean is needed in your 
 *   Form to use these functions
 *   Note 1) This version (like client server) is Blocking and will prevent
 *   re-draw of the Forms Screen whilst the Host command is active 
 *   Note 2) The kwd argument (e.g. NO_SCREEN etc) is ignored 
 *
 *   For more flexible "Host" commands see the WEBUTIL_HOST package
 *   That has facilities for Asynchronous callbacks and return codes
 *********************************************************************************
 * Version 1.0.0
 *********************************************************************************
 * Change History
 *   1.0.0 DRMILLS 03/JAN/2003 - Creation 
 *
\*********************************************************************************/
BEGIN
  -- simply call through the to WEBUTIL_HOST.HOST() Function
  if WEBUTIL_HOST.HOST(syscmd) <> 0 then 
    raise form_trigger_failure;
  end if;
END CLIENT_HOST;

PACKAGE CLIENT_IMAGE IS
/*********************************************************************************\
 * CLIENT_IMAGE
 *   Client (Browser) side implementations of the standard READ_IMAGE_FILE and 
 *   WRITE_IMAGE_FILE built-ins.
 *   Used to read an image file off of or on to the browser machine to or from 
 *   s Forms Image Item.
 *   Implemented using calls to WEBUTIL_FILE_TRANSFER.
 *   Note that the transfer.appsrv.workAreaRoot property must be set in the 
 *   webutil.cfg file so that this routine has a server side work area available
 *   for temporary files.
 *   These calls are in a package rather than in individual CLIENT_ versions 
 *   because PL/SQL only allows overloading (Item ID and Item Name versions) from 
 *   Within Packages.
 *********************************************************************************
 * Version 1.0.0
 *********************************************************************************
 * Change History
 *   1.0.0 DRMILLS 11/FEB/2003 - Creation
 *
\*********************************************************************************/
```

#### SP-094 - DEBUGLOG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: ADD_ERROR]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: SETDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a formatted diagnostic log entry to either a client-side file or a Windows debug output channel, depending on the active debug state and API availability. Called by multiple D2kwutil procedures to record tracing information during WebUtil operations. Routing between output channels is managed through SETDEBUG and WINDEBUG.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugLevel | PLS_INTEGER | IN |
| LoggingCall | VARCHAR2 | IN |
| LogString | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- SETDEBUG ([SP-098](#SP-098--SETDEBUG)) - matched by member name
- WEBUTIL.LENGTH ([SP-065](#SP-065--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)
- WINDEBUG ([SP-100](#SP-100--WINDEBUG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Receive three inputs: the numeric debug level for this entry, the name of the calling routine, and the log message string.
- Step 2 - Evaluate the current debug state (iDebugState), paused flag (bDebugPaused), and the entry's DebugLevel against the configured threshold (iDebugLevel). If any guard condition disqualifies the entry, exit immediately without writing.
- Step 3 - If the timestamp flag (bDebugTimeStamp) is enabled, capture the current time in HH24:MI:SS format and append a '>' separator.
- Step 4 - Construct the formatted debug string: prefix with the zero-padded debug level, append the optional timestamp, pad the calling routine name to 30 characters, then append the log message truncated so the total does not exceed 2,000 characters (using WEBUTIL.LENGTH implicitly via the length() call on vcDebugString).
- Step 5 - If iDebugState = 2 (Windows debugger mode) and DEBUG_API_ENABLED is TRUE, call WINDEBUG to write the formatted string to the Windows debug output channel.
- Step 6 - If iDebugState = 2 but DEBUG_API_ENABLED is FALSE, call SETDEBUG to fall back to file-based logging (defaulting to 'd2kwutil.log'), recursively log a switch-notification message, re-log the original entry, and set the bDebugType2Required flag to TRUE.
- Step 7 - If iDebugState is not 2 and bDebugType2Required is TRUE and DEBUG_API_ENABLED has become TRUE, call SETDEBUG to reinstate Windows debugger mode, recursively log a restoration message, reset bDebugType2Required to FALSE, and re-log the original entry.
- Step 8 - Otherwise (standard file mode), open the configured log file in append mode, write the formatted string, and close the file.
- Step 9 - If any exception occurs during the above steps, suppress it by resetting iDebugState to 0 to prevent debug activity from disrupting the host application.

---
**Decision Points**

DP-001

Condition: iDebugState = 0

TRUE: No logging is active; procedure exits immediately without writing anything.

FALSE: Proceed to further guard checks.

---

DP-002

Condition: bDebugPaused is TRUE

TRUE: Logging is temporarily paused; procedure exits immediately.

FALSE: Proceed to level threshold check.

---

DP-003

Condition: DebugLevel > iDebugLevel (entry's level exceeds configured threshold)

TRUE: Entry is below the required verbosity; procedure exits immediately.

FALSE: Entry qualifies for logging; proceed to format and route.

---

DP-004

Condition: bDebugTimeStamp is TRUE

TRUE: Current time (HH24:MI:SS) is captured and prepended to the debug string.

FALSE: No timestamp is included in the formatted string.

---

DP-005

Condition: iDebugState = 2 (Windows debugger mode requested)

TRUE: Attempt to route the log entry to the Windows debug output channel via WINDEBUG.

FALSE: Route the log entry to file-based output.

---

DP-006

Condition: iDebugState = 2 AND DEBUG_API_ENABLED is TRUE

TRUE: Call WINDEBUG to write the formatted string to the Windows debug channel.

FALSE: Windows debug API is unavailable; call SETDEBUG to switch to file logging, log a notification, re-log the original entry, and set bDebugType2Required to TRUE.

---

DP-007

Condition: iDebugState ≠ 2, AND bDebugType2Required is TRUE, AND DEBUG_API_ENABLED is TRUE

TRUE: The Windows debug API has become available again; call SETDEBUG to reinstate debugger mode, log a restoration notice, reset bDebugType2Required to FALSE, and re-log the original entry.

FALSE: No API recovery needed; write the formatted string directly to the log file via TEXT_IO.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Logging is suppressed entirely when iDebugState is 0, when logging is paused (bDebugPaused), or when the entry's DebugLevel exceeds the configured threshold (iDebugLevel); no output is produced under any of these conditions.
- BR-002 - The formatted log string must not exceed 2,000 characters; the log message (LogString) is truncated to enforce this limit after the level prefix, timestamp, and padded caller name have been prepended.
- BR-003 - The calling routine name is always right-padded to 30 characters in the formatted output to maintain consistent column alignment across log entries.
- BR-004 - When Windows debugger mode (iDebugState = 2) is active but the debug API is unavailable, the procedure must automatically fall back to file-based logging via SETDEBUG rather than silently dropping the entry or raising an error.
- BR-005 - Once the Windows debug API becomes available again after a fallback, the procedure must restore Windows debugger mode via SETDEBUG and re-emit the pending log entry to the debugger channel, ensuring no entries are permanently lost to the wrong channel.
- BR-006 - Any exception raised during logging must be silently suppressed by resetting iDebugState to 0; diagnostic infrastructure must never propagate errors to the calling application.

---
**Implementation Logic**

```plsql
   
PROCEDURE DebugLog (DebugLevel  IN PLS_INTEGER, 
                    LoggingCall IN VARCHAR2, 
                    LogString   IN VARCHAR2) is
 vcDateStamp   VARCHAR2(10);
 vcDebugString VARCHAR2(2000);
 hFile         TEXT_IO.FILE_TYPE;
begin
  if iDebugState = 0 then 
  	NULL;
  elsif bDebugPaused then 
  	NULL;
  elsif DebugLevel > iDebugLevel then 
  	NULL;
  else
  	-- Sort out the Datestamp	
  	if bDebugTimeStamp then 
  		vcDateStamp := to_char(SYSDATE,'HH24:MI:SS')||'> ';
  	end if;
  
  	-- Construct the final String
  	vcDebugString := '<'||lpad(to_char(DebugLevel),2,0)||'> '||vcDateStamp||rpad(LoggingCall||':',30);
    vcDebugString := vcDebugString||substr(LogString,1,(2000-length(vcDebugString)));
  
  	if iDebugState = 2 then
  		if DEBUG_API_ENABLED then 
  	   		win_api_debug.WinDebug(vcDebugString);
  		else
  			-- Can't use API calls if the API functions aren't there
	  		-- So Switch to File Logging to d2kwut$.log
	  		SetDebug(1,nvl(vcDebugFile,'d2kwutil.log'),iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Unable to Log to Debugger Switching to File');
			DebugLog(DebugLevel,LoggingCall,LogString);	  		
	  		bDebugType2Required := TRUE;
	  	end if;
  	else
     	if bDebugType2Required and DEBUG_API_ENABLED then
	     	-- API now Available - Reinstate Debugging to Debugger
	  		SetDebug(2,vcDebugFile,iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Restoring Logging to Debugger');
	  		bDebugType2Required := FALSE;
	  		DebugLog(Debuglevel,LoggingCall,LogString);
	
	  	else
		 	hFile := TEXT_IO.FOPEN(vcDebugFile,'A');
		 	TEXT_IO.PUT_LINE(hFile,vcDebugString);
		 	TEXT_IO.FCLOSE(hFile);
		end if;
  	end if;
  end if;
 exception
  	-- Don't let the debugging cause Problems of it's own
  	when others then 
  		iDebugState := 0;
 end DebugLog;
```

#### SP-095 - GET_ENVIRONMENT_STRING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Reads a named Windows environment variable from the client machine using the D2KWUtil native library. Returns the resolved variable value as a string, or NULL (or raises NO_DATA_FOUND) when the variable cannot be retrieved. Supports optional exception propagation controlled by the RaiseExceptions flag.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VariableName | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-089](#SP-089--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-090](#SP-090--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-091](#SP-091--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-092](#SP-092--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_GETDOSENV ([SP-009](#SP-009--D2KWUTIL.D2KWUTIL_GETDOSENV)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-094](#SP-094--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-097](#SP-097--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Receive the environment variable name (VariableName) and the exception-propagation flag (RaiseExceptions).
- Step 2 - Write a debug log entry recording both input arguments, converting the BOOLEAN RaiseExceptions flag to a character representation via BOOLTOCHAR.
- Step 3 - Clear the internal error stack via CLEAN_ERROR_STACK to ensure no stale error state affects processing.
- Step 4 - Check whether the WIN_API infrastructure is enabled (API_ENABLED). If it is not enabled, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 5 - If the API is enabled, register the external C function 'd2kwutil_GetDOSEnv' with its signature via REGISTER_FUNCTION_CALL, binding it to the internal function handle iGetDOSEnv.
- Step 6 - Prepare the lookup value by wrapping VariableName in percent signs (e.g. '%VAR_NAME%') and initialise a 512-character output buffer padded with null characters.
- Step 7 - Invoke D2KWUTIL.D2KWUTIL_GETDOSENV, passing the function handle, the wrapped variable name, the output buffer, and the buffer length. Capture the integer return code (iRC).
- Step 8 - Write a second debug log entry recording the returned value length and the resolved value string.
- Step 9 - Evaluate the result: if iRC is 0 or the output buffer still equals the unexpanded input token, the variable was not resolved. Call ADD_ERROR to record the failure, then either raise NO_DATA_FOUND (if RaiseExceptions is TRUE) or return NULL.
- Step 10 - If the variable was resolved successfully, return the populated output buffer value to the caller.
- Step 11 - In the exception block: re-raise NO_DATA_FOUND as-is; for WIN_API.NOT_AVAILABLE, call ADD_ERROR with the standard no-API message and re-raise; for all other exceptions, call ADD_ERROR with the generic unhandled-error message appended with ADD_EXTERNAL_ERRORS output, then re-raise.

---
**Decision Points**

DP-001

Condition: WIN_API.API_ENABLED is TRUE - the WIN_API infrastructure is available and initialised on the client.

TRUE: Register the D2KWUTIL_GETDOSENV function handle and proceed to invoke D2KWUTIL.D2KWUTIL_GETDOSENV to retrieve the environment variable value.

FALSE: Raise WIN_API.NOT_AVAILABLE, which is caught in the exception block, logged via ADD_ERROR, and re-raised to the caller.

---

DP-002

Condition: The return code iRC equals 0 OR the output buffer still contains the unexpanded token (vcBuff2 = vcBuff1), indicating the environment variable could not be resolved.

TRUE: Call ADD_ERROR to record the failure. Then evaluate DP-003 to determine whether to raise an exception or return NULL.

FALSE: Return the resolved environment variable value string to the caller.

---

DP-003

Condition: The RaiseExceptions input parameter is TRUE.

TRUE: Raise NO_DATA_FOUND so the caller can handle the unresolved variable as an exception.

FALSE: Return NULL silently to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The WIN_API infrastructure must be enabled before any attempt is made to retrieve an environment variable; if it is not available the procedure always raises WIN_API.NOT_AVAILABLE regardless of the RaiseExceptions flag.
- BR-002 - The environment variable name is wrapped in percent signs before being passed to D2KWUTIL.D2KWUTIL_GETDOSENV, conforming to the Windows environment variable expansion syntax required by the underlying C library.
- BR-003 - A successful retrieval is determined by a non-zero return code AND a result buffer that differs from the unexpanded input token; both conditions must be satisfied for a value to be returned.
- BR-004 - When the variable cannot be resolved, the failure is always recorded via ADD_ERROR before any return or exception path is taken.
- BR-005 - The caller controls error propagation behaviour: passing RaiseExceptions = TRUE causes NO_DATA_FOUND to be raised on failure; passing FALSE (the default) causes NULL to be returned silently.
- BR-006 - All entry and exit points are instrumented with DEBUGLOG calls (at debug level 99) to support diagnostic tracing of both input arguments and resolved output values.

---
**Implementation Logic**

```plsql

FUNCTION Get_Environment_string (  VariableName      IN  VARCHAR2,
                                   RaiseExceptions   IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  vcBuff2    VARCHAR2(512);
  iBuff1    PLS_INTEGER;
  iRC        PLS_INTEGER;
begin 
  Win_api_debug.DebugLog(99,'Get_Environment_String','Args: VariableName="'||VariableName||'", RaiseExceptions='||win_api_debug.BoolToChar(RaiseExceptions));
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then
    win_api.Register_function_call(iGetDOSEnv,'d2kwutil_GetDOSEnv','LONG','*CHAR,*CHAR,LONG');
    vcBuff1    := '%'||VariableName||'%';
    vcBuff2    := RPAD(' ',512,CHR(0));
    iBuff1    := 512;
    iRC   := d2kwutil_GetDOSEnv(win_api.FunctionHandle(iGetDOSEnv),vcBuff1,vcBuff2,iBuff1);
    Win_api_debug.DebugLog(99,'Get_Environment_String','Result: Value Length='||to_char(iRC)||', Value='||vcBuff2);
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0  or vcBuff2 = vcBuff1 then 
    Win_API.Add_error('Get_Environment_String','Unable to get the value of the variable '||VariableName);
    if RaiseExceptions then
      raise NO_DATA_FOUND;
    else
      return NULL;
    end if;
  else
    return vcBuff2;
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Environment_String',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Environment_String',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Environment_String;
```

#### SP-096 - READ_REGISTRY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Reads a string value from the Windows registry on the client machine by delegating to the D2KWUTIL native library function D2KWUTIL_GETREGKEY. Accepts a full registry path, an entry name, and an exception-raising flag; returns the registry value as a VARCHAR2 string, or NULL on recoverable errors when exception raising is suppressed. Diagnostic activity is recorded via DEBUGLOG throughout execution.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RegPath | VARCHAR2 | IN |
| RegEntry | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-089](#SP-089--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-090](#SP-090--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-091](#SP-091--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-092](#SP-092--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_GETREGKEY ([SP-010](#SP-010--D2KWUTIL.D2KWUTIL_GETREGKEY)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-094](#SP-094--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-097](#SP-097--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log entry diagnostics via DEBUGLOG, recording the incoming RegPath, RegEntry, and RaiseExceptions arguments (converted to character form using BOOLTOCHAR).
- Step 2 - Clear any pre-existing error state by calling CLEAN_ERROR_STACK.
- Step 3 - Check whether the WIN_API infrastructure is enabled (API_ENABLED flag). If not enabled, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 4 - Register the native library function handle for D2KWUTIL.D2KWUTIL_GETREGKEY via REGISTER_FUNCTION_CALL, binding the 'd2kwutil_GetRegKey' signature.
- Step 5 - Parse the root hive token from RegPath (the segment before the first backslash) and map it to the corresponding integer constant (0 = HKEY_LOCAL_MACHINE, 1 = HKEY_CLASSES_ROOT, 2 = HKEY_CURRENT_USER, 3 = HKEY_USERS, 4 = HKEY_CURRENT_CONFIG). If the root token is unrecognised, record an error via ADD_ERROR and, when RaiseExceptions is TRUE, raise NO_DATA_FOUND.
- Step 6 - Prepare the sub-path buffer (RegPath stripped of the root prefix), the entry name buffer, and a 2000-byte output buffer pre-padded with CHR(0).
- Step 7 - Evaluate the WIN_API.COMPAT_EXPAND_REG_VALUES compatibility flag. If expansion is suppressed, set the expansion-control integer to 1 and log the suppression via DEBUGLOG; otherwise set it to 0.
- Step 8 - Invoke D2KWUTIL.D2KWUTIL_GETREGKEY with the function handle, root integer, sub-path, entry name, output buffer, buffer length, and expansion flag; capture the integer return code.
- Step 9 - Log the return code and the populated output buffer value via DEBUGLOG.
- Step 10 - Evaluate the return code: RC = -1 (entry not found), RC = -2 (unsupported data type), RC = -3 (value exceeds buffer length), RC = -4 (environment string expansion failed). For each error code, record a descriptive message via ADD_ERROR, then either return NULL or raise the appropriate exception (NO_DATA_FOUND or VALUE_ERROR) depending on the RaiseExceptions flag.
- Step 11 - If the return code indicates success, return the populated output buffer string to the caller.
- Step 12 - In the exception block, re-raise NO_DATA_FOUND and VALUE_ERROR as-is; for WIN_API.NOT_AVAILABLE, log the standard no-API message via ADD_ERROR then re-raise; for all other exceptions, log a generic error combined with ADD_EXTERNAL_ERRORS output via ADD_ERROR, then re-raise.

---
**Decision Points**

DP-001

Condition: WIN_API.API_ENABLED is TRUE.

TRUE: Proceed to register the D2KWUTIL_GETREGKEY function handle and execute the registry read.

FALSE: Raise WIN_API.NOT_AVAILABLE immediately, bypassing all registry access.

---

DP-002

Condition: The root hive token extracted from RegPath matches one of the five recognised hive names (HKEY_LOCAL_MACHINE, HKEY_CLASSES_ROOT, HKEY_CURRENT_USER, HKEY_USERS, HKEY_CURRENT_CONFIG).

TRUE: Map the token to its corresponding integer constant and continue processing.

FALSE: Record an invalid-key error via ADD_ERROR; if RaiseExceptions is TRUE, raise NO_DATA_FOUND, otherwise allow execution to continue (D2KWUTIL_GETREGKEY will be called with an uninitialised root integer).

---

DP-003

Condition: WIN_API.COMPAT_EXPAND_REG_VALUES is FALSE (expansion suppressed).

TRUE: Set the expansion-control flag to 1 and log the suppression via DEBUGLOG.

FALSE: Set the expansion-control flag to 0, permitting normal environment-string expansion.

---

DP-004

Condition: D2KWUTIL.D2KWUTIL_GETREGKEY returns RC = -1 (registry entry not found).

TRUE: Record the error via ADD_ERROR; if RaiseExceptions is TRUE raise NO_DATA_FOUND, otherwise return NULL.

FALSE: Proceed to evaluate subsequent return-code conditions.

---

DP-005

Condition: D2KWUTIL.D2KWUTIL_GETREGKEY returns RC = -2 (unsupported registry data type).

TRUE: Record the error via ADD_ERROR; if RaiseExceptions is TRUE raise NO_DATA_FOUND, otherwise return NULL.

FALSE: Proceed to evaluate subsequent return-code conditions.

---

DP-006

Condition: D2KWUTIL.D2KWUTIL_GETREGKEY returns RC = -3 (value exceeds 2000-byte buffer).

TRUE: Record the error via ADD_ERROR; if RaiseExceptions is TRUE raise VALUE_ERROR, otherwise return NULL.

FALSE: Proceed to evaluate subsequent return-code conditions.

---

DP-007

Condition: D2KWUTIL.D2KWUTIL_GETREGKEY returns RC = -4 (environment string expansion failed).

TRUE: Record the error via ADD_ERROR; if RaiseExceptions is TRUE raise NO_DATA_FOUND, otherwise return NULL.

FALSE: No error condition applies; return the populated output buffer to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The registry path supplied in RegPath must begin with one of the five supported Windows hive names (HKEY_LOCAL_MACHINE, HKEY_CLASSES_ROOT, HKEY_CURRENT_USER, HKEY_USERS, HKEY_CURRENT_CONFIG) followed by a backslash; any other root token is treated as an invalid registry key and an error is recorded.
- BR-002 - The output buffer for the registry value is fixed at 2000 bytes; registry values whose data exceeds this limit cannot be retrieved and result in an error (RC = -3).
- BR-003 - The RaiseExceptions flag governs error propagation: when FALSE, all recoverable error conditions (entry not found, unsupported type, buffer overflow, expansion failure) cause the function to return NULL silently after logging; when TRUE, the same conditions raise a PL/SQL exception to the caller.
- BR-004 - Environment-string expansion within registry values is controlled by the WIN_API.COMPAT_EXPAND_REG_VALUES compatibility flag; when that flag is FALSE, expansion is suppressed at the D2KWUTIL_GETREGKEY call level and the suppression is recorded in the diagnostic log via DEBUGLOG.
- BR-005 - All diagnostic activity (entry arguments, compatibility decisions, and result codes) is written to the debug log via DEBUGLOG at severity level 99, ensuring a full audit trail of every registry read attempt without affecting normal execution flow.

---
**Implementation Logic**

```plsql

FUNCTION Read_Registry (RegPath         IN  VARCHAR2,
                        RegEntry        IN  VARCHAR2, 
                        RaiseExceptions IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  vcBuff2    VARCHAR2(512);
  vcBuff3    VARCHAR2(2000);
  vcBuff4    VARCHAR2(512);
  vcBuff5    VARCHAR2(512);                        
  vcRoot     VARCHAR2(20);
  iBuff1     PLS_INTEGER;
  iBuff2     PLS_INTEGER;
  iBuff3		 PLS_INTEGER;
  iRC        PLS_INTEGER;
begin
  Win_API_Debug.DebugLog(99,'Read_Registry','Args: RegPath="'||RegPath||'", RegEntry="'||RegEntry||'", RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	  
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then 
    win_api.Register_function_call(iGetRegKey,'d2kwutil_GetRegKey','INT','INT,*CHAR,*CHAR,*CHAR,INT,INT');  
    -- Which Root?
    vcRoot  := upper(substr(RegPath,1,instr(RegPath,'\')-1));
    if      vcRoot =  'HKEY_LOCAL_MACHINE' then 
      iBuff1 := 0;
    elsif   vcRoot =  'HKEY_CLASSES_ROOT' then 
      iBuff1 := 1;
    elsif   vcRoot =  'HKEY_CURRENT_USER' then 
      iBuff1 := 2;
    elsif   vcRoot =  'HKEY_USERS' then
      iBuff1 := 3;
    elsif   vcRoot =  'HKEY_CURRENT_CONFIG' then
      iBuff1 := 4;      
    else
      WIN_API.Add_error('Read_Registry','Invalid Registry Key '||RegPath);
      if  RaiseExceptions then
        raise NO_DATA_FOUND;
      end if;  
    end if;

    iBuff2     := 2000; /* Length of buffer */
    vcBuff1    := substr(RegPath,instr(RegPath,'\')+1);
    vcBuff2    := RegEntry;
    vcBuff3    := RPAD(SUBSTR(NVL(vcBuff3,' '),1,2000),2000,CHR(0));
    if not WIN_API.COMPAT_EXPAND_REG_VALUES then 
    	iBuff3 := 1;
    	Win_API_Debug.DebugLog(99,'Read_Registry','Compatibility: Reg Value expansion supressed');	  
    else
    	iBuff3 := 0;
    end if;
    
    iRC        := d2kwutil_GetRegKey(win_api.FunctionHandle(iGetRegKey),iBuff1,vcBuff1,vcBuff2,vcBuff3,iBuff2,iBuff3);
    Win_API_Debug.DebugLog(99,'Read_Registry','Result:  RC='||to_char(iRC)||', vcBuff3="'||vcBuff3||'"');	      
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = -1  then 
    Win_API.Add_error('Read_Registry','Cannot read  entry '||RegPath||'->'||RegEntry);
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;
  elsif iRC = -2 then
    Win_API.Add_error('Read_Registry', RegPath||'->'||RegEntry||' is an unsupported datatype');
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;
  elsif iRC = -3 then
    Win_API.Add_error('Read_Registry',RegPath||'->'||RegEntry||' is longer than '||to_char(iBuff2)||' Bytes');
    if not RaiseExceptions then
      return NULL;
    else 
      raise VALUE_ERROR;
    end if;
  elsif iRC = -4 then
    Win_API.Add_error('Read_Registry', RegPath||'->'||RegEntry||' Failed to expand environment string');
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;    
  end if;
  return vcBuff3;
exception
  when NO_DATA_FOUND then 
    raise;
  when VALUE_ERROR then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Read_Registry',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Read_Registry',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Read_Registry;
```

#### SP-097 - REGISTER_FUNCTION_CALL

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a client-side DLL function with the Oracle FFI (Foreign Function Interface) infrastructure so it can be invoked from Oracle Forms via the WebUtil/D2KWUTIL C API. The procedure first ensures the target DLL is loaded (attempting a load via D2KWUTIL.ATTEMPT_DLL_LOAD if necessary), then performs lazy registration of the function's handle, parameter types, and return type - re-registering only when the function has never been registered or when the DLL has been reloaded since the last registration. Diagnostic activity is written through DEBUGLOG, and any FFI failures are surfaced through ADD_ERROR and ADD_EXTERNAL_ERRORS.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| FunctionID | PLS_INTEGER | IN |
| FunctionName | VARCHAR2 | IN |
| FunctionReturn | VARCHAR2 | IN |
| FunctionArgs | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-089](#SP-089--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-090](#SP-090--ADD_EXTERNAL_ERRORS)) - matched by member name
- D2KWUTIL.ATTEMPT_DLL_LOAD ([SP-007](#SP-007--D2KWUTIL.ATTEMPT_DLL_LOAD)) - D2KWUTIL.pck (or .pld)
- D2KWUTIL.TRANSLATETYPE ([SP-011](#SP-011--D2KWUTIL.TRANSLATETYPE)) - D2KWUTIL.pck (or .pld)
- DEBUGLOG ([SP-094](#SP-094--DEBUGLOG)) - matched by member name
- WEBUTIL.LENGTH ([SP-065](#SP-065--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)
- WEBUTIL.REGISTER_FUNCTION ([SP-077](#SP-077--WEBUTIL.REGISTER_FUNCTION)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Attempt to locate the target DLL in the current session using ORA_FFI.FIND_LIBRARY. If the library is found, proceed to Step 3.
- Step 2 - If FIND_LIBRARY raises an FFI error, call D2KWUTIL.ATTEMPT_DLL_LOAD to reload the DLL from the configured path. If the reload also fails, set API_ENABLED to FALSE, call ADD_ERROR to record that the DLL was not found, and raise NO_DATA_FOUND to abort processing.
- Step 3 - Check whether the function has already been registered in the current session and whether its cached DLL load count matches the current DLL_LOAD_COUNT. If both conditions are satisfied, skip to Step 8 (no re-registration needed).
- Step 4 - Register the function handle with the DLL by calling ORA_FFI.REGISTER_FUNCTION using the DLL handle, the supplied FunctionName, and the C_STD calling convention.
- Step 5 - If the function being registered is not the internal debug string function, call DEBUGLOG (via Win_API_Debug.DebugLog) to record whether this is an initial registration or a re-registration, including the function name and current DLL load count.
- Step 6 - Iterate through the comma-delimited FunctionArgs string. For each argument token, call D2KWUTIL.TRANSLATETYPE to convert the type name to its ORA_FFI constant, then register it as a parameter via ORA_FFI.REGISTER_PARAMETER. Use WEBUTIL.LENGTH (via the instr/substr/length logic) to traverse the argument list; stop when the remaining string is null, a bare comma, or 'VOID,'.
- Step 7 - If FunctionReturn is not 'VOID' and is not NULL, call D2KWUTIL.TRANSLATETYPE to convert the return type name and register it via ORA_FFI.REGISTER_RETURN.
- Step 8 - Store the current DLL_LOAD_COUNT in the FunctionLoad cache array for this FunctionID to prevent unnecessary re-registration on future calls.
- Step 9 - If an ORA_FFI.FFI_ERROR is raised at any point during Steps 4-8, call ADD_ERROR with the function name and the concatenated error text from ADD_EXTERNAL_ERRORS, then raise NO_DATA_FOUND to signal failure to the caller.

---
**Decision Points**

DP-001

Condition: ORA_FFI.FIND_LIBRARY succeeds in locating the DLL in the current session.

TRUE: DLL handle is obtained; proceed to the registration check (DP-002).

FALSE: An FFI error is raised; attempt to reload the DLL via D2KWUTIL.ATTEMPT_DLL_LOAD (DP-002 sub-path).

---

DP-002

Condition: D2KWUTIL.ATTEMPT_DLL_LOAD successfully reloads the DLL after FIND_LIBRARY failed.

TRUE: DLL handle is obtained; proceed to the registration check.

FALSE: FFI error raised again; disable the API (API_ENABLED := FALSE), call ADD_ERROR, and raise NO_DATA_FOUND.

---

DP-003

Condition: The FunctionLoad cache entry for FunctionID exists AND its stored load count equals the current DLL_LOAD_COUNT.

TRUE: Function is already registered against the current DLL instance; skip all registration steps.

FALSE: Function has never been registered or the DLL has been reloaded; proceed with full registration (Steps 4-8).

---

DP-004

Condition: The function being registered is the internal debug string function ('d2kwutil_DebugString').

TRUE: Suppress the DEBUGLOG call to avoid recursive logging.

FALSE: Call DEBUGLOG to record initial registration or re-registration details.

---

DP-005

Condition: The FunctionLoad cache entry for FunctionID does not yet exist (first-ever registration).

TRUE: DEBUGLOG records this as an initial registration.

FALSE: DEBUGLOG records this as a re-registration, including the previous load count.

---

DP-006

Condition: The remaining FunctionArgs string is null, equals ',', or equals 'VOID,' during the parameter-registration loop.

TRUE: Exit the loop; no further parameters to register.

FALSE: Extract the next comma-delimited token, translate its type via D2KWUTIL.TRANSLATETYPE, and register it as a parameter.

---

DP-007

Condition: FunctionReturn is not 'VOID' (case-insensitive) and is not NULL.

TRUE: Translate the return type via D2KWUTIL.TRANSLATETYPE and register it via ORA_FFI.REGISTER_RETURN.

FALSE: No return type is registered (procedure or void function).

---

DP-008

Condition: An ORA_FFI.FFI_ERROR is raised during the registration steps (Steps 4-8).

TRUE: Call ADD_ERROR with the function name and error text from ADD_EXTERNAL_ERRORS; raise NO_DATA_FOUND.

FALSE: Registration completes normally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A DLL function must not be registered more than once per DLL load cycle. Registration is skipped if the FunctionLoad cache already holds an entry for the given FunctionID that matches the current DLL_LOAD_COUNT.
- BR-002 - If the DLL cannot be located via ORA_FFI.FIND_LIBRARY, exactly one reload attempt must be made through D2KWUTIL.ATTEMPT_DLL_LOAD before the API is declared unavailable.
- BR-003 - If the DLL cannot be loaded after the reload attempt, the API must be disabled (API_ENABLED := FALSE) and the failure must be communicated to the caller via ADD_ERROR before raising NO_DATA_FOUND.
- BR-004 - When the DLL has been reloaded between registrations (DLL_LOAD_COUNT has changed), the function must be fully re-registered - including its handle, all parameters, and its return type - to maintain FFI integrity.
- BR-005 - Parameter types and the return type supplied as VARCHAR2 strings must be translated to their ORA_FFI internal constants via D2KWUTIL.TRANSLATETYPE before being passed to ORA_FFI.REGISTER_PARAMETER or ORA_FFI.REGISTER_RETURN.
- BR-006 - Return type registration must be suppressed when FunctionReturn is 'VOID' or NULL, reflecting that the target is a procedure rather than a function.
- BR-007 - Diagnostic registration events (initial or re-registration) must be written to the debug log via DEBUGLOG for all functions except the internal debug string function ('d2kwutil_DebugString'), preventing recursive logging.
- BR-008 - Any FFI error raised during the registration phase must be captured, enriched with external error detail via ADD_EXTERNAL_ERRORS, reported via ADD_ERROR, and re-raised as NO_DATA_FOUND so that callers receive a consistent failure signal.

---
**Implementation Logic**

```plsql

PROCEDURE Register_Function_Call ( FunctionID     in PLS_INTEGER, 
                                   FunctionName   in VARCHAR2,
                                   FunctionReturn in VARCHAR2, 
                                   FunctionArgs   in VARCHAR2) is
  vcArgs  VARCHAR2(200);
  vcFrag  VARCHAR2(10);
  iOffset PLS_INTEGER;   
begin 
   -- See if the DLL has been loaded at all.
   -- if this call to FIND_LIBRARY fails, we'll fall through to the Exception.
   begin
    DLL_HANDLE := ORA_FFI.find_library(DLL_NAME);
  exception
    when ora_ffi.ffi_error then 
      -- Attempt to load the DLL again in a subblock. If this fails
      -- then the API must be disabled and NOT_DATA_FOUND raised
      begin 
          DLL_HANDLE := Attempt_DLL_Load(DLL_Path, DLL_NAME);
      exception
          when ora_ffi.ffi_error then 
            API_ENABLED := FALSE;
              add_error('D2KWUTIL',DLL_NAME||' not found.');
            RAISE NO_DATA_FOUND;
      end;
  end;

  -- now compare the Cached value for this function's loadcount with 
  -- that for the DLL this tells us that the function has either not 
  -- been registered yet, or that the DLL has been reloaded in between 
  -- times.  This would not be healthy so we have to re-register in that case.
  if (not FunctionLoad.exists(FunctionId)) or (FunctionLoad(FunctionId)<> DLL_LOAD_COUNT) then
    -- We need to go through the registration process.      
    -- Register the function with the DLL
    FunctionHandle(FunctionId) := ora_ffi.register_function(Win_API.DLL_HANDLE,FunctionName,ORA_FFI.C_STD);
    if FunctionName <> 'd2kwutil_DebugString' then 
    	if not FunctionLoad.exists(FunctionId) then 
    		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Initial Reg');
    	else
       		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Re-Registration Count = '||to_char(FunctionLoad(FunctionId)));
       	end if;
    end if;
    
    -- Loop through and register the parameters
    vcArgs := FunctionArgs||',';
    while vcArgs is not null and vcArgs <> ',' and vcArgs <> 'VOID,' LOOP
      iOffset := instr(vcArgs,',');
      vcFrag := substr(vcArgs,1,iOffset-1);
      ora_ffi.register_parameter(FunctionHandle(FunctionId),TranslateType(vcFrag));
      if iOffset = length(vcArgs) then
        vcArgs := NULL;
      else
        vcArgs := substr(vcArgs,iOffset+1);
      end if;
    end LOOP;
    
    -- Register the return type IF this is a function
    if upper(FunctionReturn) <> 'VOID' and FunctionReturn is not NULL then 
      ora_ffi.register_return(FunctionHandle(FunctionId),TranslateType(FunctionReturn));
    end if;
    
    -- Now add this Function's Loadcount to the array to prevent un-nessary re-registration
    FunctionLoad(FunctionId) := DLL_LOAD_COUNT;
  end if;
exception
   when ora_ffi.ffi_error then
    Win_API.Add_error(FunctionName, Win_API.UError||WIN_API.Add_External_errors); 
    raise NO_DATA_FOUND;
end Register_Function_Call;
```

#### SP-098 - SETDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Configures the debug logging environment by setting the active debug mode, target log file, verbosity level, and timestamp preference. Depending on the requested debug type, the procedure activates file-based logging, activates message-based logging, or deactivates logging entirely, and records the resulting state change via DEBUGLOG.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugType | PLS_INTEGER | IN |
| DebugFile | VARCHAR2 | IN |
| DebugLevel | PLS_INTEGER | IN |
| TimeStamp | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-094](#SP-094--DEBUGLOG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Accept the four input parameters: DebugType (logging mode selector), DebugFile (target file name, defaults to NULL), DebugLevel (verbosity threshold, defaults to 98), and TimeStamp (flag controlling whether timestamps are included, defaults to FALSE).
- Step 2 - Persist the TimeStamp flag to the package-level variable bDebugTimeStamp, making it available to subsequent logging calls.
- Step 3 - Persist the DebugFile value to the package-level variable vcDebugFile.
- Step 4 - Persist the DebugLevel value to the package-level variable iDebugLevel.
- Step 5 - Evaluate DebugType to determine which logging mode to activate.
- Step 6 - If DebugType equals 1, set the package-level state variable iDebugState to 1 (file-based logging) and call DEBUGLOG to record the message 'Logging to File' concatenated with the supplied DebugFile name.
- Step 7 - If DebugType equals 2, set iDebugState to 2 (message-based logging) and call DEBUGLOG to record the message 'Logging Started'.
- Step 8 - For any other DebugType value, call DEBUGLOG to record the message 'Logging Stopped' and then set iDebugState to 0 (logging disabled).

---
**Decision Points**

DP-001

Condition: DebugType = 1

TRUE: Set iDebugState to 1 (file-based logging active) and invoke DEBUGLOG with the message 'Logging to File' appended with the DebugFile value.

FALSE: Proceed to evaluate DP-002.

DP-002

Condition: DebugType = 2

TRUE: Set iDebugState to 2 (message-based logging active) and invoke DEBUGLOG with the message 'Logging Started'.

FALSE: Invoke DEBUGLOG with the message 'Logging Stopped' and set iDebugState to 0 (logging disabled).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - DebugType = 1 designates file-based logging; the procedure records the target file name in the confirmation log entry, making DebugFile a meaningful value when this mode is selected.
- BR-002 - DebugType = 2 designates message-based logging; no file reference is required or logged for this mode.
- BR-003 - Any DebugType value other than 1 or 2 is treated as a request to stop logging; iDebugState is set to 0 and a 'Logging Stopped' entry is written before the state is cleared.
- BR-004 - The global configuration variables (bDebugTimeStamp, vcDebugFile, iDebugLevel) are always updated unconditionally before the DebugType branching logic executes, ensuring the runtime context reflects the latest call regardless of the resulting logging state.
- BR-005 - All state transitions are confirmed by a call to DEBUGLOG at severity level 0 under the source label 'SetDebug', providing an audit trail of every debug configuration change.

---
**Implementation Logic**

```plsql

PROCEDURE SetDebug( DebugType   IN PLS_INTEGER, 
                    DebugFile   IN VARCHAR2 DEFAULT NULL, 
                    DebugLevel  IN PLS_INTEGER DEFAULT 98,                        
                    TimeStamp   IN BOOLEAN DEFAULT FALSE) is
begin 
    bDebugTimeStamp := TimeStamp;
    vcDebugFile     := DebugFile;
    iDebugLevel     := DebugLevel;
	if DebugType = 1 then 
		iDebugState := 1;
		DebugLog(0,'SetDebug','Logging to File '||DebugFile);
	elsif DebugType = 2 then
		iDebugState := 2;
		DebugLog(0,'SetDebug','Logging Started');
	else 
        DebugLog(0,'SetDebug','Logging Stopped');
        iDebugState := 0;
	end if;
end SetDebug;
```

#### SP-099 - STRIPDIRSEP

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sanitises a file-system path string passed in by the caller by removing any semicolon-delimited suffix and any trailing backslash directory separator, returning the cleaned path value. It is used internally by D2KWUTIL.ATTEMPT_DLL_LOAD to ensure the path token used for DLL resolution is well-formed before further processing.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| InPath | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-065](#SP-065--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Initialise a local working copy of the input path (InPath) into a VARCHAR2(500) variable.
- Step 2 - Inspect the working path for the presence of a semicolon character using INSTR. If a semicolon is found, truncate the string to retain only the portion that precedes the first semicolon, discarding any additional path entries that may have been appended.
- Step 3 - Inspect the last character of the (potentially truncated) working path. If it is a backslash ('\'), remove it by taking the substring from position 1 to one character less than the current length of the string.
- Step 4 - Return the sanitised path string to the caller.

---
**Decision Points**

DP-001

Condition: INSTR(vcPath, ';') > 0 - the path string contains one or more semicolon characters.

TRUE: Truncate vcPath to the substring from position 1 up to (but not including) the first semicolon, discarding any subsequent path entries.

FALSE: Retain vcPath unchanged and proceed to the next check.

---

DP-002

Condition: SUBSTR(vcPath, -1, 1) = '\' - the last character of the (possibly truncated) path is a backslash directory separator.

TRUE: Remove the trailing backslash by replacing vcPath with the substring from position 1 to LENGTH(vcPath) - 1.

FALSE: Retain vcPath unchanged and return it as-is.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - When a path string contains a semicolon, only the segment preceding the first semicolon is considered a valid path; all subsequent characters (including additional semicolon-delimited entries) are discarded.
- BR-002 - A valid path must not end with a backslash directory separator; if one is present it must be stripped before the path is returned.
- BR-003 - The function operates non-destructively on the original input: all modifications are applied to a local copy, and the sanitised result is returned without altering any persisted state.
- BR-004 - The maximum supported path length is 500 characters, consistent with the VARCHAR2(500) local variable used to hold the working path.

---
**Implementation Logic**

```plsql

  

Function StripDirSep ( InPath in varchar2) return varchar2 is 
  vcPath  varchar2(500) := InPath;
begin 
  -- Check and Strip SemiColons, we take everything
  -- Before the first Semicolon as our path
  if instr(vcPath,';') > 0 then
    vcPath := substr(vcPath,1,instr(vcPath,';') -1);
  end if;

  -- Check and Strip '\'
  if substr(vcPath,-1,1) = '\' then 
    vcPath := substr(vcPath,1,length(vcPath)-1);
  end if;

  return vcPath;
end StripDirSep;
```

#### SP-100 - WINDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WINDEBUG provides a debug-string output channel by delegating to the external D2KWUTIL library function D2KWUTIL_DEBUGSTRING. It accepts a text string, appends a newline character, registers the required external function handle via REGISTER_FUNCTION_CALL, and dispatches the formatted string to the debug output. The procedure is only operative when the WIN_API layer is enabled; if the API is unavailable or any other error occurs, it records a structured error via ADD_ERROR and ADD_EXTERNAL_ERRORS before re-raising the exception.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-089](#SP-089--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-090](#SP-090--ADD_EXTERNAL_ERRORS)) - matched by member name
- D2KWUTIL.D2KWUTIL_DEBUGSTRING ([SP-008](#SP-008--D2KWUTIL.D2KWUTIL_DEBUGSTRING)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- REGISTER_FUNCTION_CALL ([SP-097](#SP-097--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input text string (Text IN VARCHAR2) and initialise a local buffer (vcBuff1) by appending a newline character (CHR(10)) to the supplied text.
- Step 2 - Evaluate whether the WIN_API layer is active by checking WIN_API.API_ENABLED.
- Step 3 - If the API is enabled, register the external function handle for D2KWUTIL_DEBUGSTRING by calling REGISTER_FUNCTION_CALL, passing the internal debug-string index (iDebugString), the function name literal 'd2kwutil_DebugString', NULL, and the data-type marker '*CHAR'.
- Step 4 - Invoke D2KWUTIL.D2KWUTIL_DEBUGSTRING with the resolved function handle (WIN_API.FunctionHandle(iDebugString)) and the prepared buffer (vcBuff1) to emit the debug string through the external library.
- Step 5 - If the API is not enabled, raise WIN_API.NOT_AVAILABLE to trigger the appropriate exception handler.
- Step 6 - In the WIN_API.NOT_AVAILABLE exception handler, record a structured error via ADD_ERROR (identifying the caller as 'WinDebug' and the error code as WIN_API.NoAPI), then re-raise the exception to the caller.
- Step 7 - In the OTHERS exception handler, record a structured error via ADD_ERROR (identifying the caller as 'WinDebug' and concatenating WIN_API.UError with the result of ADD_EXTERNAL_ERRORS), then re-raise the exception to the caller.

---
**Decision Points**

DP-001

Condition: WIN_API.API_ENABLED evaluates to TRUE.

TRUE: Register the external function handle for D2KWUTIL_DEBUGSTRING via REGISTER_FUNCTION_CALL and dispatch the formatted debug string by calling D2KWUTIL.D2KWUTIL_DEBUGSTRING.

FALSE: Raise WIN_API.NOT_AVAILABLE, which routes execution to the NOT_AVAILABLE exception handler.

---

DP-002

Condition: WIN_API.NOT_AVAILABLE exception is raised (either explicitly from DP-001 FALSE branch or propagated from the external call).

TRUE: Call ADD_ERROR with caller name 'WinDebug' and error code WIN_API.NoAPI, then re-raise the exception.

FALSE: Not applicable; this branch is only entered when the named exception fires.

---

DP-003

Condition: An unhandled exception other than WIN_API.NOT_AVAILABLE is raised during processing.

TRUE: Call ADD_ERROR with caller name 'WinDebug' and a composite error message formed by concatenating WIN_API.UError with the output of ADD_EXTERNAL_ERRORS, then re-raise the exception.

FALSE: Normal execution completes without entering the OTHERS handler.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must only attempt to emit a debug string when WIN_API.API_ENABLED is TRUE; execution is not permitted to proceed to the external library call if the WIN_API layer is inactive.
- BR-002 - The input text must always be extended with a newline character (CHR(10)) before being passed to the external debug function, ensuring each debug entry is terminated correctly.
- BR-003 - The external function D2KWUTIL_DEBUGSTRING must be registered via REGISTER_FUNCTION_CALL immediately before each invocation, using the fixed function name literal 'd2kwutil_DebugString' and data-type marker '*CHAR'.
- BR-004 - When the WIN_API layer is unavailable (WIN_API.NOT_AVAILABLE), the error must be recorded through ADD_ERROR identifying 'WinDebug' as the source and WIN_API.NoAPI as the error code, and the exception must be re-raised to the caller.
- BR-005 - For all other runtime exceptions, the error must be recorded through ADD_ERROR identifying 'WinDebug' as the source, with the error detail formed by concatenating WIN_API.UError and the result of ADD_EXTERNAL_ERRORS, and the exception must be re-raised to the caller.
- BR-006 - All exceptions are re-raised after being logged; WINDEBUG does not suppress errors, ensuring that calling code (DEBUGLOG in D2kwutil.pld) is always informed of failures.

---
**Implementation Logic**

```plsql
  

  
PROCEDURE WinDebug  (  Text  IN   VARCHAR2) is
  vcBuff1 VARCHAR2(2000) := Text||chr(10);
begin 
  --WIN_API.Clean_Error_Stack;
  if Win_API.API_ENABLED then
    win_api.Register_function_call(iDebugString,'d2kwutil_DebugString',NULL,'*CHAR');
    d2kwutil_DebugString(win_api.FunctionHandle(iDebugString),vcBuff1);
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if; 
exception
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('WinDebug',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('WinDebug',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end WinDebug;
```

# BUSINESS REQUIREMENTS DOCUMENT

## Table of Contents

- 1. Document Control
  - 1.1 Document Information
  - 1.2 Revision History
- 2. Executive Summary
  - Key Stakeholders
- 3. System Context
- 4. Functional Requirements
  - 4.1 Business Requirements
    - Requirement ID: BR-001
    - Requirement ID: BR-002
    - Requirement ID: BR-003
    - Requirement ID: BR-004
    - Requirement ID: BR-005
    - Requirement ID: BR-006
    - Requirement ID: BR-007
    - Requirement ID: BR-008
    - Requirement ID: BR-009
    - Requirement ID: BR-010
    - Requirement ID: BR-011
    - Requirement ID: BR-012
    - Requirement ID: BR-013
    - Requirement ID: BR-014
    - Requirement ID: BR-015
    - Requirement ID: BR-016
    - Requirement ID: BR-017
    - Requirement ID: BR-018
    - Requirement ID: BR-019
    - Requirement ID: BR-020
    - Requirement ID: BR-021
    - Requirement ID: BR-022
    - Requirement ID: BR-023
    - Requirement ID: BR-024
    - Requirement ID: BR-025
    - Requirement ID: BR-026
    - Requirement ID: BR-027
    - Requirement ID: BR-028
    - Requirement ID: BR-029
    - Requirement ID: BR-030
    - Requirement ID: BR-031
    - Requirement ID: BR-032
    - Requirement ID: BR-033
- 5. Business Rules Catalogue
- 6. Data Requirements
  - 6.1 Business Entities and Relationships
    - MCP Enquiry Header — VH_AMC_ENQ
    - MCP Enquiry Detail Lines — VD_AMC_ENQ
    - Enquiry Charge Lines — VD_AMC_ENQCHARGES
    - Entity Relationships
  - 6.2 Data Capture Requirements
    - Enquiry Search (Search by Enquiry Number or New Entry)
    - Vehicle and Customer Details (New Enquiry — Header Entry)
    - MCP Package Selection
    - MCP Detail Lines (Details Screen)
    - TCS Selection (TCS Screen)
    - Session and Parameter Fields
  - 6.3 Reference Data
  - 6.4 Data Lifecycle
- 7. Glossary
- 8. Technical Inventory
  - 8.1 Form Architecture
    - 8.1.1 Global Variables
    - 8.1.2 Form Parameters
  - 8.2 Blocks
    - 8.2.1 Block WhereClause and OrderByClause
  - 8.3 Items Summary
  - 8.4 List of Values
  - 8.5 Alerts
  - 8.6 Program Units
  - 8.7 Triggers
    - 8.7.1 Inactive / Commented-Out Trigger Register
  - 8.8 Canvas and Window Inventory
  - 8.9 Editors
  - 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups
    - 8.10.1 Visual Attributes (form-defined)
    - 8.10.2 Property Classes (form-defined)
    - 8.10.3 Object Groups
  - 8.11 DataSourceColumn Inventory
    - B_VH_AMC_ENQ (35 columns)
    - B_VD_AMC_ENQ (35 columns)
- 9. Object Library
- 10. Record Groups
- 11. Referenced Database Objects
- 12. Backend Procedures and Packages
  - 12.1 Main Flow Backend Procedure/Package Index
  - 12.2 Procedure and Package Catalogue
    - CALL_REPORT_ENQ (Form-local Program Unit)
    - POP_PKG_DETAILS_NEW (Form-local Program Unit)
    - POP_PKG_DETAILS (Form-local Program Unit — INACTIVE)
    - SP_INSERT_CHARGES (Form-local Program Unit)
    - GENERAL.DISP_TEXT
    - GENERAL.RAISE_ERROR
    - GENERAL.CHECK_FORM_FAILURE
    - GENERAL.ASK_CONFIRM
    - GENERAL.CHECK_NULL
    - GENERAL.PROC_TIMER_EXPIRED
    - GENERAL.PROC_REPORT_CALL
    - GENERAL.PROC_TIMER
    - PKG_AMC.SP_POP_PKG_DTL
    - PKG_AMC.SP_GET_GST_TYPE
    - PKG_AMC.SP_VIN_VALIDATE
    - PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM
    - SP_GET_VEH_DETAILS
    - SF_COPYRIGHT_DECLARATION
    - SP_VALIDATE_ALPHANUMERIC
    - DBMS_APPLICATION_INFO.SET_CLIENT_INFO
    - DBMS_APPLICATION_INFO.SET_MODULE
    - STOP_WATCH.STOP_TIMER
    - WEB.SHOW_DOCUMENT
- 13. Package Procedure Specifications
- 14. Database Package Catalogue
- 15. PLD Procedure Call Sites
- 16. Microservice API Candidates
  - 16.1 Microservices with APIs
- 17. Workflows
- 18. PLD-Backed Logic
- 19. PCK-Backed Logic
- 20. System Interfaces
  - 20.1 Database Integrations
  - 20.2 External System Integrations
  - 20.3 Report Integrations
- 21. Procedure and Function Business Rule Catalogue
  - 21.1 Catalogue Index
  - 21.2 Detailed Specifications
    - SP-001 — CALL_REPORT_ENQ
    - SP-002 — POP_PKG_DETAILS_NEW
    - SP-003 — SP_INSERT_CHARGES
    - SP-004 — D2KWUTIL.ATTEMPT_DLL_LOAD
    - SP-005 — D2KWUTIL.CREATED_DATE
    - SP-006 — D2KWUTIL.D2KWUTIL_DEBUGSTRING
    - SP-007 — D2KWUTIL.D2KWUTIL_FILEINFO
    - SP-008 — D2KWUTIL.FILE_INFO
    - SP-009 — D2KWUTIL.TRANSLATETYPE
    - SP-010 — GENERAL.ASK_CONFIRM
    - SP-011 — GENERAL.CHECK_FORM_FAILURE
    - SP-012 — GENERAL.CHECK_NULL
    - SP-013 — GENERAL.DISP_TEXT
    - SP-014 — GENERAL.PROC_REPORT_CALL
    - SP-015 — GENERAL.PROC_TIMER
    - SP-016 — GENERAL.PROC_TIMER_EXPIRED
    - SP-017 — GENERAL.RAISE_ERROR
    - SP-018 — PKG_AMC.SP_GET_GST_TYPE
    - SP-019 — PKG_AMC.SP_POP_PKG_DTL
    - SP-020 — PKG_AMC.SP_VIN_VALIDATE
    - SP-021 — PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM
    - SP-022 — WEBUTIL.ERRORALERT
    - SP-023 — WEBUTIL.FCLOSE
    - SP-024 — WEBUTIL.FOPEN
    - SP-025 — WEBUTIL.GETIMPLCLASS
    - SP-026 — WEBUTIL.GETPROPERTY
    - SP-027 — WEBUTIL.ID_NULL
    - SP-028 — WEBUTIL.LENGTH
    - SP-029 — WEBUTIL.PUT_LINE
    - SP-030 — WEBUTIL.REGISTER_FUNCTION
    - SP-031 — WEBUTIL.SETPROPERTY
    - SP-032 — WEBUTIL.WAIT
    - SP-033 — ADD_ERROR
    - SP-034 — ADD_EXTERNAL_ERRORS
    - SP-035 — BOOLTOCHAR
    - SP-036 — CLEAN_ERROR_STACK
    - SP-037 — DEBUGLOG
    - SP-038 — REGISTER_FUNCTION_CALL
    - SP-039 — SETDEBUG
    - SP-040 — SF_COPYRIGHT_DECLARATION
    - SP-041 — SP_GET_VEH_DETAILS
    - SP-042 — SP_VALIDATE_ALPHANUMERIC
    - SP-043 — STRIPDIRSEP
    - SP-044 — WINDEBUG

---

## 1. Document Control

### 1.1 Document Information

| Field | Value |
| ----- | ----- |
| Document Title | VT_AMC_ENQ - Business Requirements Document |
| Form Module Name | VT_AMC_ENQ |
| Document Version | 1.0 |
| Date Created | October 01, 2026 |
| Author/Prepared By | BRD Agent |

### 1.2 Revision History

| Version | Date | Author | Description |
| --- | --- | --- | --- |
| 1.0 | October 01, 2026 | BRD Agent | Initial draft |

---

## 2. Executive Summary

*High-level overview of the vt_amc_enq MCP Enquiry Generation form, its purpose, and roles referenced in the module.*

The **vt_amc_enq** Oracle Forms module is the dealership **MCP (Maintenance Care Package) Enquiry Generation** screen. A service advisor opens the screen to create a new AMC enquiry or to retrieve an existing one by enquiry number. The advisor enters the customer's vehicle registration number; the system automatically retrieves the vehicle details, confirms the vehicle is eligible for an MCP package, and determines whether the applicable tax is intra-state or inter-state based on the dealership's and customer's registered locations. The advisor selects the appropriate AMC package from the available options, enters the current odometer reading and a service executive code, and generates the package line-item breakdown covering labour, parts, and consumables with all applicable discounts and charges. If Tax Collected at Source applies to the transaction, the advisor selects the correct TCS rate before saving. On saving, a unique enquiry document number is assigned and all package and charge details are committed to the system. The completed enquiry can be printed as a formal AMC enquiry report from the same screen.

### Key Stakeholders

*Who uses vt_amc_enq*

| Stakeholder | Role |
| :--- | :--- |
| **Service Advisor** | Primary interactive user of the vt_amc_enq screen. Creates or retrieves MCP enquiries, enters vehicle and service details, selects the AMC package, applies TCS rates where required, and saves and prints the enquiry. |
| **Service Executive** | Selected by the service advisor from the executives list to be recorded on the enquiry as the responsible service personnel. |
| **Customer** | Vehicle owner whose registration, contact, and customer details are captured automatically from the vehicle and customer masters; the customer does not interact with the form. |

---

---

## 3. System Context

*Describes the vt_amc_enq module's role within the DMS ecosystem, scope, process flow, and key integrations.*

The **vt_amc_enq** module is the Dealer Management System (DMS) **MCP Enquiry Generation** screen. It serves as the starting point for creating Annual Maintenance Contract or Maintenance Care Package bookings at the dealership service counter and connects the service advisor with vehicle eligibility verification, package rate lookups, GST tax determination, TCS applicability, document number generation, and enquiry report generation.

**System purpose:** Open or create a new MCP enquiry, validate the vehicle's eligibility and GST context, capture the selected package with its full labour, parts, and consumables breakdown, handle TCS rate selection where applicable, assign a unique document number, and commit all enquiry and charge details — as implemented in the vt_amc_enq Oracle Forms module.

**In scope:**

- Create a new MCP enquiry or retrieve an existing enquiry by enquiry number
- Validate vehicle eligibility for an MCP package (vehicle age, odometer mileage, active MCP check, restricted vehicle check)
- Determine GST type (intra-state SGST/CGST or inter-state IGST) based on dealer and customer state, including SEZ handling
- Select an applicable AMC package from the vehicle-specific and date-filtered package list
- Record current odometer reading and assign a service executive to the enquiry
- Populate the enquiry detail breakdown with labour operations, parts, and consumables rates, quantities, discounts, HSN/SAC codes, and charge amounts
- Apply TCS (Tax Collected at Source) at normal or higher rate when aggregate sale value qualifies
- Generate a unique, sequential AMC enquiry document number at save
- Persist the enquiry header and all line items with audit trail (created-by, modified-by)
- Insert applicable charge rows for taxes and fees at commit
- Print the AMC enquiry report from the form

**Process Name:** MCP Enquiry Generation

**Process Owner:** Service Manager

**Process Objective:** Validate a vehicle for an MCP package, capture service advisor and package details with a full cost breakdown, apply GST and TCS rules, and save the AMC enquiry with a generated document number before further AMC processing begins.

**Process Trigger:** A customer requests a Maintenance Care Package at the dealership service counter, or an existing MCP enquiry requires review or update.

**Process Flow:**

The complete MCP enquiry generation process follows this sequence. Each step corresponds to Functional Requirements BR-001 through BR-015 in Section 4.

```
STEP 1 ── SCREEN OPENS (BR-001)
         Service advisor opens the MCP Enquiry Generation screen.
         The session is registered and a blank enquiry form is prepared.

STEP 2 ── NEW OR EXISTING ENQUIRY? (BR-001)
         ├── NEW: Leave the enquiry number blank and proceed to vehicle entry
         └── EXISTING: Enter the existing enquiry number — system loads the saved
                       enquiry header and all line items

STEP 3 ── VEHICLE REGISTRATION NUMBER ENTRY (BR-002)
         Service advisor enters the customer's vehicle registration number.
         System checks that the registration number is not blank before proceeding.

STEP 4 ── VEHICLE ELIGIBILITY VALIDATION (BR-003)
         System confirms the vehicle exists in the vehicle master and has no active MCP.
         Checks the vehicle is within the 4-year sale validity window and the odometer
         is within the mileage limit. Rejects restricted and exception-model vehicles.

STEP 5 ── VEHICLE DETAILS LOADED (BR-004)
         Vehicle details (VIN, variant, chassis, engine number, model description,
         sub-variant, colour, sale date, fuel type, previous odometer reading) and
         customer details (name, city, GST state, SEZ status) are loaded automatically.

STEP 6 ── GST TYPE DETERMINATION (BR-005)
         System compares the dealer's state code with the customer's state code.
         ├── SAME STATE: Intra-state tax (SGST/CGST) applies
         └── DIFFERENT STATE or SEZ CUSTOMER: Inter-state tax (IGST) applies
         Dealer and customer GST state codes are stored on the enquiry record.

STEP 7 ── ODOMETER READING ENTRY (BR-006)
         Service advisor enters the current vehicle odometer reading.
         System validates it is not null and not less than the previous service mileage.

STEP 8 ── SERVICE EXECUTIVE SELECTION (BR-007)
         Service advisor selects the service executive from the approved executives list.
         Selection is mandatory for new enquiries.

STEP 9 ── PACKAGE SELECTION (BR-008)
         Service advisor opens the package selection list to view applicable AMC packages.
         List is filtered by principal, vehicle average run, and current date eligibility.
         Advisor selects the package code.

STEP 10 ── VALIDITY DATE CALCULATION (BR-009)
          System calculates the AMC validity expiry date from the vehicle sale date
          and the selected package's expiry period in months.

STEP 11 ── PACKAGE DETAILS GENERATION (BR-010)
          Service advisor clicks Generate Enquiry.
          System populates labour, parts, and consumable line items with quantities,
          rates, discount amounts, HSN/SAC codes, and net amounts from the package
          rate master, applying the determined GST type and tax charges.

STEP 12 ── DETAIL LINE REVIEW (BR-010)
          Service advisor reviews the populated line items in the enquiry detail panel
          and may navigate between header and detail views.

STEP 13 ── TCS APPLICABILITY CHECK (BR-011)
          ├── NOT APPLICABLE: TCS threshold not met; proceed to save
          └── APPLICABLE: System presents TCS confirmation.
              Advisor confirms the aggregate sale does not exceed 50 lakhs.
              ├── NORMAL RATE: Advisor selects Normal Rate (0.075%–0.1%)
              └── HIGHER RATE: Advisor selects Higher Rate (1%) when PAN/Aadhaar
                              is unavailable; TCS flag is recorded on the header

STEP 14 ── SAVE ACTION (BR-012)
          Service advisor clicks Save.
          System validates all mandatory fields and the package amount is present.

STEP 15 ── DOCUMENT NUMBER GENERATION (BR-013)
          For a new enquiry, the system generates and assigns a unique formatted
          document number by incrementing the dealer's document counter.
          ├── SUCCESS: Enquiry number is assigned and displayed
          └── LOCK CONFLICT: Another user holds the counter; error message shown
                             and save is rejected; advisor retries

STEP 16 ── CHARGE ROWS INSERTED (BR-014)
          System inserts applicable charge rows (taxes, fees) linked to the enquiry
          from the charge template before the database commit.

STEP 17 ── RECORD COMMITTED (BR-014)
          Enquiry header and all detail lines are committed to the database with
          audit fields (created-by/date or modified-by/date) stamped automatically.

STEP 18 ── PRINT REPORT (BR-015)
          Service advisor may print the AMC enquiry report.
          System submits the report job to the report server and monitors status
          until the document is ready, then delivers it to the screen.
```

**Major process interactions:**

- **Vehicle and customer master data** — provides vehicle eligibility details, sale date, odometer history, and customer GST and SEZ status
- **AMC package master** — supplies available package options filtered by vehicle sub-variant, fuel type, city category, and date
- **AMC rate master** — provides labour, parts, and consumables rates with discount and HSN/SAC codes for the selected package
- **Dealer location master** — supplies the dealer state code for GST type determination
- **Document number master** — generates sequential, formatted AMC enquiry document numbers at save
- **Charge template** — inserts applicable tax and fee charge rows at commit
- **AMC enquiry report** — generates and delivers a printed MCP enquiry document from the form

---

---

## 4. Functional Requirements

*This section specifies every business functional requirement implemented by the MCP Enquiry Generation form (VT_AMC_ENQ). The form enables dealership staff to create, retrieve, and print MCP (Manufacturer's Comprehensive Protection) enrolment enquiries for eligible vehicles.*

### 4.1 Business Requirements

#### Requirement ID: BR-001

**Requirement Title:** Application Session Registration at Form Launch

**Business Description:**
Before any screen is displayed to the user, the system registers the current session with the dealership application infrastructure. This records which module the user has opened and initialises the session-level performance monitoring clock if application logging is enabled. This step runs automatically in the background and requires no user action.

**Actors:** System (automated on form launch)

**Preconditions:**
- The dealership system session is active and the user has navigated to the MCP Enquiry Generation module.

**Main Flow:**

**Step 1 — Module identity registered with the session**
The system records the name of the current Oracle Forms module (`vt_amc_enq`) in the active database session information and marks the action name as blank. This makes the module's identity visible in database session monitoring tools.

**Step 2 — Performance logging clock started (when enabled)**
If the dealership's application logging flag is active for this session, the system starts the performance measurement timer. This happens silently in the background.

**Alternative Flows:**
- **BR-001-AF-01** — (from Step 2) If application logging is not enabled for the session, the performance timer start is skipped; the form continues loading normally.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Application Logging Flag (`GLOBAL.APP_LOG`) | Auto-populated | Alphanumeric | 1 | N/A | `Y` = enabled | Session is active | System-set; read-only | N/A |

---

#### Requirement ID: BR-002

**Requirement Title:** MCP Availability Check and Form Initialisation on Open

**Business Description:**
When the MCP Enquiry Generation form opens, the system first checks whether the MCP programme has been enabled or disabled for the current dealership by the manufacturer. If MCP has been deactivated, the user is informed immediately and the form closes — no data entry is possible. If MCP is active, the form proceeds to set up its initial state: the copyright notice is displayed, the main window is maximised, and the save behaviour is configured so no unsaved changes are committed inadvertently.

**Actors:** Dealer User

**Preconditions:**
- The user has opened the MCP Enquiry Generation module from the dealership application.
- The current session contains the dealer, location, parent group, and company details.

**Main Flow:**

**Step 1 — MCP deactivation status checked for the dealership**
The system queries the dealer location parameters for the current dealer, location, and parent group to determine whether the MCP programme has been deactivated. If the record cannot be found, the programme is treated as active.

*Screen: MCP Enquiry Details (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-013](#sp-013--GENERALDISP_TEXT)) — GENERAL.DISP_TEXT — Displays a modal alert to the user containing a supplied message and title, selecting between an error-style alert (`AL_ERRINFO`) and an informational alert (`AL_NOTE`) based on whether the title indicates an error condition.
    * **Step 1** — Selects the alert type based on the title supplied ("Error" uses AL_ERRINFO; any other title uses AL_NOTE).
    * **Step 2** — Sets the alert title and message text to the supplied values.
    * **Step 3** — Displays the alert to the user.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| MCP active check for dealer | `nvl(mcp_deactivate_flag,'N') = 'Y'` — WHEN-NEW-FORM-INSTANCE in Form | When the form is opened by the user | Ensures MCP enrolment enquiries can only be created at dealership locations where MCP is currently enabled by the manufacturer | *"MCP has been disabled by MSIL-Service"* is shown; the form exits immediately; no data entry is possible |

*Business outcomes (errors, warnings, success, and status):*
- **BR-002-ES-01** — MCP has been deactivated for this dealer location — *"MCP has been disabled by MSIL-Service"*; the form closes immediately.

**Step 2 — Copyright notice, save parameter, and window state initialised**
The system calls the copyright declaration function to generate the current-year copyright string (e.g. "© 2026 Maruti Suzuki India Limited") and displays it in the form's copyright field. The save parameter is reset to "N" (no unsaved save operation in progress). The main application window is maximised and the form's save-point mode is enabled so partial changes are not auto-committed.

*Procedures called:*
- **SF_COPYRIGHT_DECLARATION** ([SP-040](#sp-040--SF_COPYRIGHT_DECLARATION)) — SF_COPYRIGHT_DECLARATION — Constructs and returns the current financial-year copyright string for Maruti Suzuki India Limited. The financial year is taken to run from April to March, so months January through March are attributed to the preceding calendar year rather than the current one.
    * **Step 1** — Reads the current system date.
    * **Step 2** — Determines the financial year: if the current month is January, February, or March, uses the previous calendar year; for April through December, uses the current calendar year.
    * **Step 3** — Returns the completed copyright string.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Copyright Notice (`CB_VT_AMC_ENQ.COPY_RIGHT`) | Auto-populated | Display item | 100 | N/A | Current-year copyright string | Form open | System-set; read-only | N/A |
| MCP Deactivation Flag (`AM_DEALER_LOC_PARAM.MCP_DEACTIVATE_FLAG`) | Auto-populated | Alphanumeric | 1 | Dealer Location Parameters | `Y` = deactivated, `N` = active | Dealer session context | Read by system at form open only | Treated as `N` (active) if no record found |

---

#### Requirement ID: BR-003

**Requirement Title:** Form Clear / Reset to New Enquiry State

**Business Description:**
When the user clears the form (using the framework-provided clear action), the system discards all currently displayed data without saving, resets the screen to a blank state ready for a new MCP enquiry, and re-enables the fields that may have been locked during a previous query session. The GST type selector, the enquiry number field, and the copyright display are all restored to their initial new-entry state.

**Actors:** Dealer User

**Preconditions:**
- The form is open and may contain data from a previous enquiry entry or query.

**Main Flow:**

**Step 1 — Screen cleared and parameters reset for new entry**
The system clears all form data without running validation on the discarded records. The internal query-mode, new-record, and new-item parameters are reset to signal a fresh entry state. The GST Type selector is re-enabled and set to allow insert and update, making it editable for the next enquiry. The Enquiry Number field is also re-enabled for insert and update, allowing the user to either enter an existing enquiry number or leave it blank for a new one.

*Procedures called:*
- **SF_COPYRIGHT_DECLARATION** ([SP-040](#sp-040--SF_COPYRIGHT_DECLARATION)) — SF_COPYRIGHT_DECLARATION — Constructs and returns the current financial-year copyright string for Maruti Suzuki India Limited. The financial year is taken to run from April to March, so months January through March are attributed to the preceding calendar year rather than the current one.
    * **Step 1** — Reads the current system date.
    * **Step 2** — Determines the financial year from the current month.
    * **Step 3** — Returns the completed copyright string.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Copyright Notice (`CB_VT_AMC_ENQ.COPY_RIGHT`) | Auto-populated | Display item | 100 | N/A | Current-year copyright string | Form clear completed | System-set | N/A |
| GST Type (`B_VH_AMC_ENQ.RG_GSTTYPE`) | Auto-populated | Radio group | 1 | N/A | N/A | Form clear | Re-enabled for insert/update | N/A |
| Enquiry Number (`CB_VT_AMC_ENQ.NB_ENQ_NUM`) | Conditional | Text item | 12 | N/A | N/A | Form clear | Re-enabled for insert/update | N/A |

---

#### Requirement ID: BR-004

**Requirement Title:** Form Exit and Session Deregistration

**Business Description:**
When the user exits the MCP Enquiry Generation form (using the framework exit action), the system clears the session's module identity information from the database session record and then closes the form immediately without prompting to save any unsaved changes. This ensures that the form's database session footprint is cleaned up when the user leaves the module.

**Actors:** Dealer User

**Preconditions:**
- The form is open.

**Main Flow:**

**Step 1 — Session module identity cleared and form closed**
The system clears the session's registered client information and module name from the database session record (setting both to blank/null). The form then exits without performing any validation or save prompt.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Session Client Info (`DBMS_APPLICATION_INFO`) | Auto-populated | System session attribute | N/A | N/A | Cleared to null on exit | Form is open | System-managed | N/A |

---

#### Requirement ID: BR-005

**Requirement Title:** Error Interception and User-Friendly Error Display

**Business Description:**
When any error occurs while using the MCP Enquiry Generation form, the system intercepts the error before the default Oracle Forms error handler processes it, identifies the specific error condition, and presents the user with a clear, context-specific error message instead of a raw system error. For date entry mistakes, invalid characters, and data update conflicts, the user sees a precise instruction. For other database errors that have not been individually coded, the user sees the underlying database error text. Certain benign navigation errors are silently suppressed to avoid unnecessary interruption.

**Actors:** System (triggered automatically on any form error)

**Preconditions:**
- The form is open and an error condition has arisen from a user action or a system operation.

**Main Flow:**

**Step 1 — Error type identified and appropriate message displayed**
The system inspects the error number and type. Based on the specific error:

- If the error relates to an invalid date value (error 50004), the message *"Entered Date is not valid Date"* is displayed and the current operation is stopped.
- If the error relates to an incorrect date format (errors 50025 or 50026), the message *"Enter the Date in the proper format (DD-MM-YYYY)"* is displayed and the operation is stopped.
- If the error relates to non-numeric characters in a numeric field (errors 40209 or 50016), the message *"Characters/Special Characters are not allowed here, enter the numeric value"* is displayed and the operation is stopped.
- If the error is a Forms text/type error (error 40207), the system's own error text for that error is displayed and the operation is stopped.
- If the error is a database integrity constraint violation (Oracle database error -02292), the error is passed to the `GENERAL.RAISE_ERROR` procedure with code `'E0088'` for display.
- If the error is a concurrent-update conflict (errors 40654–40657 or 40659), the message *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"* is displayed, the transaction is rolled back, and the operation is stopped.
- For any other SQL error (non-zero SQL code), the database's own error text is displayed, the transaction is rolled back, and the operation is stopped.
- Errors 40401 and 40405 (no records found / query found no rows navigation errors) are silently suppressed — no message is shown.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-013](#sp-013--GENERALDISP_TEXT)) — GENERAL.DISP_TEXT — Displays a modal alert to the user containing a supplied message and title, selecting between an error-style alert (`AL_ERRINFO`) and an informational alert (`AL_NOTE`) based on whether the title indicates an error condition.
    * **Step 1** — Selects the alert (`AL_ERRINFO` for "Error" title, `AL_NOTE` otherwise).
    * **Step 2** — Sets the alert title and message text.
    * **Step 3** — Displays the alert to the user.
- **GENERAL.RAISE_ERROR** ([SP-017](#sp-017--GENERALRAISE_ERROR)) — GENERAL.RAISE_ERROR — Translates an application message code into a categorised error, note, or caution alert and displays it to the user via `GENERAL.DISP_TEXT`; for error-category messages it additionally raises `FORM_TRIGGER_FAILURE` to halt the current form operation.
    * **Step 1** — Receives the message code from the calling `ON-ERROR` trigger.
    * **Step 2** — Composes the display text from the code and message text.
    * **Step 3** — Evaluates the message type and displays via `GENERAL.DISP_TEXT`; raises `FORM_TRIGGER_FAILURE` if type is Error.

#### Requirement ID: BR-006

**Requirement Title:** System Message Interception

**Business Description:**
When Oracle Forms generates an internal system message (such as a status or informational code), the MCP Enquiry form intercepts specific message types and converts them into user-facing error alerts rather than displaying the default system message. Messages related to character-type or field-width issues (codes 40209 and 40207) are shown as error dialogs to give the user a clear explanation. Other system messages pass through without interception.

**Actors:** System (triggered automatically on any system message)

**Preconditions:**
- The form is open and a system message has been generated.

**Main Flow:**

**Step 1 — System message intercepted and displayed as error when needed**
If the system message number is 40209 or 40207, the system constructs a combined identifier string (message type, code, and text) and displays it as an error alert. The current operation is then stopped. For all other message numbers, the system does not intercept and the default Oracle Forms message handling applies.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-013](#sp-013--GENERALDISP_TEXT)) — GENERAL.DISP_TEXT — Displays a modal alert to the user containing a supplied message and title, selecting between an error-style alert (`AL_ERRINFO`) and an informational alert (`AL_NOTE`) based on whether the title indicates an error condition.
    * **Step 1** — Selects the appropriate alert based on the "Error" title.
    * **Step 2** — Sets the alert title and message text.
    * **Step 3** — Displays the alert.

#### Requirement ID: BR-007

**Requirement Title:** Report Print Queue Polling on Timer Expiry

**Business Description:**
When a report print job has been submitted to the report server for a printer-destination output, the system uses a recurring timer to check the job's completion status at regular intervals. Once the job finishes, the system opens the printed document in the browser. If the job encounters an error, the user is notified. This mechanism ensures the user is informed when their print request has been fulfilled or has failed, without blocking the screen during the wait.

**Actors:** System (triggered automatically by the timer)

**Preconditions:**
- A report print job was previously submitted to the report server (following the Save or Print action).
- The printer queue polling timer is active.

**Main Flow:**

**Step 1 — Timer expiry processed and print job status checked**
When the timer fires, the system hands control to the report-timer processing routine, which identifies the timer name and checks the print job status. If the job is still in progress, the timer continues and no user-visible action is taken. If the job has finished, the printed output is opened in the browser. If an error occurs, the user is informed.

*Procedures called:*
- **GENERAL.PROC_TIMER_EXPIRED** ([SP-016](#sp-016--GENERALPROC_TIMER_EXPIRED)) — GENERAL.PROC_TIMER_EXPIRED — Handles the expiry of the `PRINTER_QUEUE` timer by polling the current status of an asynchronous report job and, once the job finishes, opening the generated document in a new browser window; if the report fails for any reason, an error is displayed and the timer is cancelled.
    * **Step 1** — Identifies the timer that fired and reads the current report job handle and print output path from session variables.
    * **Step 2** — Only acts on the `PRINTER_QUEUE` timer.
    * **Step 3** — Queries the report server for the current job status.
    * **Step 4** — If the job is still running (queued, opening, or executing), no action is taken and the timer continues.
    * **Step 5** — If the job has finished, the completed document is opened in the browser and the timer is deleted.
    * **Step 6** — If the job status indicates an error, the message *"Unable to generate the report"* is displayed with an "Error" title and the timer is deleted.

#### Requirement ID: BR-008

**Requirement Title:** Enquiry Number Lookup and Existing Record Retrieval

**Business Description:**
When the user enters an existing MCP enquiry number in the search field, the system validates that it corresponds to a real, saved enquiry for the current dealer and location, then automatically queries and displays all the saved enquiry details — header and line items — on screen. Once an existing enquiry is retrieved, the registration number, enquiry number, and current mileage fields are locked against further editing, and the Generate Enquiry and Save buttons are disabled, preventing accidental re-creation of an already-processed enquiry. If the form opens without an enquiry number (new entry mode), the same step sets all relevant fields to an editable state.

**Actors:** Dealer User

**Preconditions:**
- The form has been opened and the MCP programme is active for this dealer location.

**Main Flow:**

**Step 1 — Enquiry number validated against the enquiry register**
When the user leaves the Enquiry Number field, the system checks whether the entered value matches a saved enquiry for the current dealer, location, parent group, and company. If a match is found, processing continues. If no match is found or a data error occurs, an error is shown and the user remains on the field.

*Screen: MCP Enquiry Details (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-013](#sp-013--GENERALDISP_TEXT)) — GENERAL.DISP_TEXT — Displays a modal alert to the user containing a supplied message and title, selecting between an error-style alert (`AL_ERRINFO`) and an informational alert (`AL_NOTE`) based on whether the title indicates an error condition.
    * **Step 1** — Selects the appropriate alert based on the title.
    * **Step 2** — Sets the alert title and message text.
    * **Step 3** — Displays the alert.

#### Requirement ID: BR-009

**Requirement Title:** Registration Number Validation and Vehicle Details Population

**Business Description:**
When the user enters a vehicle's registration number, the system validates that the registration number is present, strips any invalid characters (only uppercase letters and digits are permitted), then confirms the number exists uniquely in the vehicle master. On a successful look-up, the system automatically fills in all the vehicle's details — VIN, chassis, engine, model, variant, fuel type, customer identity and address, vehicle sale date, last odometer reading, city category, and the applicable GST type. Age and average daily run figures are also computed. If the VIN eligibility check reveals any issue (active MCP already exists, vehicle is restricted, model is excluded from MCP), the user is informed. If the customer's GST state cannot be resolved, the user is asked to update the customer master.

**Actors:** Dealer User

**Preconditions:**
- A new enquiry is being created (no enquiry number has been entered).
- The enquiry date has already been entered on screen.

**Main Flow:**

**Step 1 — Registration number presence and format checked**
The system first confirms the Registration Number field is not blank. If blank, the user is prompted to enter a valid registration number. If the value is present, any characters that are not uppercase letters or digits are stripped from it using a sanitisation routine.

*Screen: Vehicle Details (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-012](#sp-012--GENERALCHECK_NULL)) — GENERAL.CHECK_NULL — Validates that a supplied field value is not null, displaying a descriptive error alert and aborting the current trigger if it is, so that mandatory fields on the MCP Package Details, Package Details, and Vehicle Details screens cannot be saved empty.
    * **Step 1** — Constructs the error message "Enter a valid Registration Number".
    * **Step 2** — Checks whether the value is NULL.
    * **Step 3** — If NULL, displays the error and stops the current operation.
    * **Step 4** — If not NULL, returns normally.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Registration Number not blank | GENERAL.CHECK_NULL [SP-012] — WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.REG_NUM | When the user tabs off the Registration Number field | Ensures a vehicle identity is entered before any lookup is attempted | *"Enter a valid Registration Number"* shown; operation stopped; user remains on the field |
| Registration Number character format | SP_VALIDATE_ALPHANUMERIC [SP-042] — WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.REG_NUM | When the user tabs off the Registration Number field after a non-blank value is confirmed | Removes invalid characters to ensure the registration number contains only letters and digits before querying the vehicle master | Invalid characters silently removed from the field value; no error shown |

**Step 2 — Registration number uniqueness verified in the vehicle master**
The system queries the vehicle master to confirm that exactly one record matches the entered registration number. No match raises an error. Multiple matches also raise an error. Any data-width or database error is reported.

*Screen: Vehicle Details (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Single matching vehicle record | SELECT from GM_VIN — WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.REG_NUM | When the user tabs off the Registration Number field | Confirms the registration number is present and unambiguous in the vehicle master | NO_DATA_FOUND: *"Registration Number Not Found"*; TOO_MANY_ROWS: *"More than one Registration Number found for \<value\>"*; VALUE_ERROR: *"Width problem/Incompatiable data"*; WHEN OTHERS: *"Execution failed while retrieving Registration No. \<SQLERRM\>"* — all stop the operation |

*Business outcomes (errors, warnings, success, and status):*
- **BR-009-ES-01** — Registration number not in vehicle master — *"Registration Number Not Found"*; operation stopped.
- **BR-009-ES-02** — Registration number found for more than one vehicle — *"More than one Registration Number found for \<value\>"*; operation stopped.
- **BR-009-ES-03** — Database error on vehicle lookup — *"Execution failed while retrieving Registration No. \<database error text\>"*; operation stopped.

**Step 3 — Vehicle details and customer information populated from the vehicle master**
On a successful unique match, the system calls the vehicle details retrieval routine, which populates VIN, model code, variant code, customer code, customer name, address lines, contact numbers, email, city, last odometer reading, vehicle sale date, and colour details. Chassis number, engine number, last odometer reading, and vehicle sale date are then set from the returned vehicle master row. The sale date display field is formatted and populated.

*Screen: Vehicle Details (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **SP_GET_VEH_DETAILS** ([SP-041](#sp-041--SP_GET_VEH_DETAILS)) — SP_GET_VEH_DETAILS — Retrieves the full set of vehicle and customer details required to populate the AMC enquiry screen, given either a VIN or a registration number as the primary lookup key. The procedure resolves the vehicle's model (svar), variant, and exterior colour descriptions, then derives the associated customer's personal and contact details — selecting the correct communication address (office or permanent) based on the customer's communication indicator — and additionally returns outstanding amount and VIP status when the customer is registered at the current dealer location.
    * **Step 1** — Determines the primary lookup key (registration number) and resolves the VIN and sub-variant/variant/colour codes from the vehicle master.
    * **Step 2** — Retrieves the complete vehicle master row.
    * **Step 3** — Looks up the vehicle model description from the model master.
    * **Step 4** — Looks up the variant description from the variant master.
    * **Step 5** — Looks up the exterior colour description from the colour master.
    * **Step 6** — Derives the customer party code from the vehicle master if not already known.
    * **Step 7** — Checks whether the customer is registered at this dealer location.
    * **Step 8** — If registered, retrieves the full customer profile (name, address, city, phone, mobile, email).
    * **Step 9** — Looks up the city description for the customer's city.
    * **Step 10** — Retrieves the customer's VIP flag and outstanding DMS balance.
    * **Step 11** — If not registered at this dealer, retrieves only the customer name.
    * **Step 12** — Returns accumulated error messages and codes.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Vehicle/customer details retrieval | SP_GET_VEH_DETAILS [SP-041] — WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.REG_NUM | After the unique registration number is confirmed | Populates all vehicle and customer details so the user does not have to type them manually | Error code 1 returned: *"Error!... \<error message from procedure\>"* shown; operation stopped |

*Business outcomes (errors, warnings, success, and status):*
- **BR-009-ES-04** — Vehicle details retrieval error — *"Error!... \<error message returned by the procedure\>"*; operation stopped.

**Step 4 — GST type determined and state information resolved**
The system calls the GST type determination routine, which compares the dealer's state with the customer's state to set the applicable GST type (IGST or SGST/CGST). If the customer is an SEZ customer, IGST is forced and an informational note is displayed; the GST type selector is locked. If dealer and customer states match, SGST/CGST is set and the selector is locked. If they differ, the selector remains editable. The customer's GST state description is also resolved and displayed.

*Screen: Vehicle Details (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **PKG_AMC.SP_GET_GST_TYPE** ([SP-018](#sp-018--PKG_AMCSP_GET_GST_TYPE)) — PKG_AMC.SP_GET_GST_TYPE — Determines the applicable GST type (Intra-state `S` or Inter-state `I`) for an AMC/MCP transaction by comparing the dealer's state against the registered customer's state, and additionally flags Special Economic Zone customers for mandatory IGST treatment; it also returns the GST state codes for both dealer and customer alongside the customer's SEZ indicator.
    * **Step 1** — Initialises output error code to 0 and error message to null.
    * **Step 2** — Looks up the dealer's state code from the dealer location master.
    * **Step 3** — Looks up the vehicle's customer party code and variant code from the vehicle master.
    * **Step 4** — Looks up the customer's state code and SEZ flag from the customer master.
    * **Step 5** — If the customer's state code could not be resolved, sets error code to 1 and instructs the user to update the customer master.
    * **Step 6** — If the customer is an SEZ customer, sets the GST type to IGST and populates an informational message.
    * **Step 7** — If not SEZ, compares dealer and customer state codes: equal → SGST/CGST; different → IGST.
    * **Step 8** — Looks up the GST state code for the customer's state from the state master.
    * **Step 9** — Looks up the GST state code for the dealer's state from the state master.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| GST type determination | PKG_AMC.SP_GET_GST_TYPE [SP-018] — WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.REG_NUM | After vehicle and customer details are populated | Automatically sets the correct GST treatment based on whether the sale is intra-state or inter-state, or an SEZ transaction | Error code 1 (customer state not found): informational note shown; GST type selector locked; user must update customer master to proceed |

**Step 5 — VIN eligibility validated for MCP**
The system calls the VIN eligibility check routine to confirm the vehicle is eligible to receive an MCP. Checks include: whether an active MCP already exists, whether the vehicle's model is excluded, whether the vehicle is on the restricted list, whether the sale date is known, whether the enquiry is within the allowable time window, and whether the mileage has not exceeded the maximum. Age and average daily run values are also returned.

*Screen: Vehicle Details (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **PKG_AMC.SP_VIN_VALIDATE** ([SP-020](#sp-020--PKG_AMCSP_VIN_VALIDATE)) — PKG_AMC.SP_VIN_VALIDATE — Validates a vehicle identification number (VIN) against several business eligibility rules before an AMC/MCP enquiry can be raised: the VIN must exist in the vehicle master, must not already have an active MCP contract, must be within the allowed age and mileage thresholds, must not belong to a model exempted from MCP, and must not be flagged as a restricted vehicle; it also returns the vehicle age in years and the average odometer reading per year for use in the enquiry.
    * **Step 1** — Counts VIN occurrences in the vehicle master; flags an error if the count is less than 1.
    * **Step 2** — Checks whether an active MCP already exists for the vehicle.
    * **Step 3** — Retrieves the maximum validity months and mileage from the MCP validity parameters.
    * **Step 4** — Looks up the vehicle's invoice date, last odometer reading, and model code.
    * **Step 5** — Checks whether the model code is on the MCP exclusion list.
    * **Step 6** — Checks whether the VIN is on the restricted vehicle list.
    * **Step 7** — If the model is excluded, sets error code 1 with "MCP cannot be issued against defined models."
    * **Step 8** — If the vehicle sale date is missing, sets error code 1 with "Vehicle sale date is not available".
    * **Step 9** — If the enquiry exceeds the maximum MCP issue window, sets error code 1 with "Enquiry for a vehicle can be generated within 4yrs of vehicle sale".
    * **Step 10** — If the odometer exceeds the maximum mileage, sets error code 1 with "Milease expired, So Vehicle can not be considered for MCP".
    * **Step 11** — If the vehicle is on the restricted list, sets error code 1 with "Restricted Vehicle can not be considered for MCP".
    * **Step 12** — Calculates vehicle age in years and average annual mileage.
    * **Step 13** — Returns the accumulated error code and message.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| VIN MCP eligibility | PKG_AMC.SP_VIN_VALIDATE [SP-020] — WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.REG_NUM | After vehicle and GST details are populated | Ensures the vehicle is eligible to receive an MCP — not already covered, not on a restricted or excluded list, within the time and mileage window | Error code 1 returned: *"Note!... \<eligibility error message\>"* displayed; operation stopped |

*Business outcomes (errors, warnings, success, and status):*
- **BR-009-WS-01** — VIN eligibility concern — *"Note!... \<eligibility issue message\>"*; operation stopped; user must resolve the issue before proceeding.

**Alternative Flows:**
- **BR-009-AF-01** — (from Step 4) If the customer's GST state cannot be determined, an informational note is displayed and the GST type selector is locked; the user must update the customer's state in the Customer Master.
- **BR-009-AF-02** — (from Step 3) If vehicle details retrieval returns error code 1, the error message is shown and the trigger is stopped.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Registration Number (`B_VH_AMC_ENQ.REG_NUM`) | Mandatory | Text item | 20 | Vehicle Master (GM_VIN) | Matching single VIN record | Enquiry date entered; new enquiry mode | Must not be blank; uppercase letters and digits only; must match exactly one vehicle record | *"Enter a valid Registration Number"*; *"Registration Number Not Found"*; *"More than one Registration Number found for \<value\>"* |
| VIN (`B_VH_AMC_ENQ.VIN`) | Auto-populated | Display item | 20 | N/A | N/A | Registration number validated | Auto-populated from vehicle master | N/A |
| Vehicle Model (`B_VH_AMC_ENQ.SVAR_CD`) | Auto-populated | Display item | 10 | N/A | N/A | Registration number validated | Auto-populated | N/A |
| Vehicle Variant (`B_VH_AMC_ENQ.VARIANT_CD`) | Auto-populated | Display item | 10 | N/A | N/A | Registration number validated | Auto-populated | N/A |
| Chassis Number (`B_VH_AMC_ENQ.CHASSIS_NUM`) | Auto-populated | Display item | 20 | N/A | N/A | Registration number validated | Auto-populated | N/A |
| Engine Number (`B_VH_AMC_ENQ.ENGINE_NUM`) | Auto-populated | Text item | 20 | N/A | N/A | Registration number validated | Auto-populated | N/A |
| Customer Name (`B_VH_AMC_ENQ.CUST_NAME`) | Auto-populated | Display item | 100 | N/A | N/A | Registration number validated | Auto-populated from customer master | N/A |
| Address (`B_VH_AMC_ENQ.CUST_ADDR1`) | Auto-populated | Display item | 50 | N/A | N/A | Registration number validated | Auto-populated | N/A |
| Contact Number (`B_VH_AMC_ENQ.PHONE`) | Auto-populated | Display item | 50 | N/A | N/A | Registration number validated | Auto-populated | N/A |
| Mobile (`B_VH_AMC_ENQ.MOBILE`) | Auto-populated | Display item | 50 | N/A | N/A | Registration number validated | Auto-populated | N/A |
| Email (`B_VH_AMC_ENQ.EMAIL`) | Auto-populated | Display item | 100 | N/A | N/A | Registration number validated | Auto-populated | N/A |
| City (`B_VH_AMC_ENQ.CITY_CD`) | Auto-populated | Display item | 30 | N/A | N/A | Registration number validated | Auto-populated | N/A |
| Vehicle Sale Date (`B_VH_AMC_ENQ.NB_VEH_SALE_DT`) | Auto-populated | Display item | DD-MM-RRRR HH24:MI | N/A | N/A | Registration number validated | Auto-populated from vehicle master | N/A |
| GST Type (`B_VH_AMC_ENQ.RG_GSTTYPE`) | Auto-populated | Radio group | 1 | N/A | `S` = SGST/CGST; `I` = IGST | Registration number validated | Determined by dealer vs customer state; locked when states match or SEZ; editable when states differ | GST state note shown when customer state unresolved |
| State Description (`B_VH_AMC_ENQ.STATE_DESC`) | Auto-populated | Display item | 30 | State Master (GM_STATE) | State name and GST code | Registration number validated | Auto-populated | N/A |

---

- **SP_VALIDATE_ALPHANUMERIC** ([SP-042](#sp-042--SP_VALIDATE_ALPHANUMERIC)) — SP_VALIDATE_ALPHANUMERIC — Sanitises a string value in-place by stripping out every character that is not an uppercase Latin letter (A–Z) or a decimal digit (0–9), leaving only valid alphanumeric characters in the output. The procedure modifies the supplied parameter directly so the caller receives the cleansed value without any further conversion.
    * **Step 1** — Determines the length of the input string.
    * **Step 2** — Iterates character by character through the string.
    * **Step 3** — Extracts each character.
    * **Step 4** — Checks whether each character falls in the valid uppercase letter (A–Z) or digit (0–9) range.
    * **Step 5** — Removes any character outside those ranges and adjusts the iteration accordingly.
    * **Step 6** — Continues until all characters have been evaluated.
    * **Step 7** — Returns the sanitised value.

#### Requirement ID: BR-010

**Requirement Title:** Current Mileage Validation and Package Eligibility Assessment

**Business Description:**
When the user enters the vehicle's current odometer reading, the system validates that the figure is present and within the bounds required for MCP eligibility. The current mileage must not be less than the vehicle's previously recorded service mileage. It must not exceed the maximum validity mileage set for the MCP programme by the manufacturer. The enquiry must also fall within the allowed time window from the vehicle's sale date. Once validated, the system calculates the vehicle's average daily run and checks whether at least one applicable MCP package exists for the vehicle's model, current age, mileage, and run profile. If no package is found, the user is informed and must choose a different package or correct the mileage.

**Actors:** Dealer User

**Preconditions:**
- A new enquiry is being created.
- The vehicle's registration number has already been validated and vehicle details are displayed.

**Main Flow:**

**Step 1 — Current mileage presence and minimum value checked**
The system confirms the Current Mileage field is not blank. If the vehicle has a previous service mileage on record, the entered mileage must be greater than or equal to it. If the current mileage is less than the previous service mileage, a note is shown and the operation is stopped.

*Screen: Vehicle Details (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-012](#sp-012--GENERALCHECK_NULL)) — GENERAL.CHECK_NULL — Validates that a supplied field value is not null, displaying a descriptive error alert and aborting the current trigger if it is, so that mandatory fields on the MCP Package Details, Package Details, and Vehicle Details screens cannot be saved empty.
    * **Step 1** — Constructs the error message "Enter a valid Current Mileage".
    * **Step 2** — Checks whether the value is NULL.
    * **Step 3** — If NULL, displays the error and stops the current operation.
    * **Step 4** — If not NULL, returns normally.

#### Requirement ID: BR-011

**Requirement Title:** Service Executive Assignment Validation

**Business Description:**
When the user enters the service executive code for the MCP enquiry, the system validates that the field has been filled in — but only when the form is in new-entry mode. If an existing enquiry is being viewed (identified by an enquiry number already being present), the executive field is not re-validated and the user is not required to re-enter it.

**Actors:** Dealer User

**Preconditions:**
- A new MCP enquiry is being created (no enquiry number has been entered).
- The user has reached the Executive field.

**Main Flow:**

**Step 1 — Executive code checked for presence (new enquiry mode only)**
If the form is in new-entry mode, the system confirms that the Executive field is not blank. The executive code must be selected from the list of active executives at the current dealer location. If the field is blank, the user is prompted to enter a valid executive code. If the form is in query/view mode (an enquiry number is already present), this validation is skipped entirely.

*Screen: Vehicle Details (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-012](#sp-012--GENERALCHECK_NULL)) — GENERAL.CHECK_NULL — Validates that a supplied field value is not null, displaying a descriptive error alert and aborting the current trigger if it is, so that mandatory fields on the MCP Package Details, Package Details, and Vehicle Details screens cannot be saved empty.
    * **Step 1** — Constructs the error message "Enter a valid Employee Code".
    * **Step 2** — Checks whether the value is NULL.
    * **Step 3** — If NULL, displays the error and stops the current operation.
    * **Step 4** — If not NULL, returns normally.

#### Requirement ID: BR-012

**Requirement Title:** MCP Package Selection and Validity Date Calculation

**Business Description:**
When the user selects or enters an MCP package code, the system validates that the field has been filled in and then automatically calculates the MCP validity end date based on the package's expiry duration and the vehicle's mileage profile. The calculation varies depending on whether the vehicle's average daily run is above a threshold: high-mileage vehicles have their end date calculated from the expected date at which the mileage limit will be reached, capped at the standard month-based expiry; lower-mileage vehicles use the standard month-based formula. The validity start date defaults to the enquiry date if not already set.

**Actors:** Dealer User

**Preconditions:**
- A new MCP enquiry is being created.
- The registration number and current mileage have already been validated.
- The package code has been selected (from the package LOV or typed directly).

**Main Flow:**

**Step 1 — Package code presence checked**
The system confirms that the Applicable Package field is not blank.

*Screen: MCP Package Details (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-012](#sp-012--GENERALCHECK_NULL)) — GENERAL.CHECK_NULL — Validates that a supplied field value is not null, displaying a descriptive error alert and aborting the current trigger if it is, so that mandatory fields on the MCP Package Details, Package Details, and Vehicle Details screens cannot be saved empty.
    * **Step 1** — Constructs the error message "Enter a valid Applicable Package".
    * **Step 2** — Checks whether the value is NULL.
    * **Step 3** — If NULL, displays the error and stops the current operation.
    * **Step 4** — If not NULL, returns normally.

#### Requirement ID: BR-013

**Requirement Title:** TCS Determination and MCP Package Detail Generation

**Business Description:**
When the user clicks the Generate Enquiry button after selecting a package, the system determines whether Tax Collected at Source (TCS) needs to be applied for this enquiry, obtains the user's TCS declaration where applicable, then calculates the full package rate breakdown (all labour, parts, and consumable line items with their pricing, discounts, taxes, and charges) and populates the enquiry detail lines on screen. If the package code has already been entered but TCS has not yet been addressed (i.e. this is the first click with a package present), the system displays the TCS declaration screen for the user to confirm their TCS choice before proceeding to rate calculation. If the package code is missing, the user is prompted to select one first.

**Actors:** Dealer User

**Preconditions:**
- The vehicle's registration number has been validated and vehicle details are on screen.
- The current mileage has been entered and validated.
- An MCP package has been selected.
- The enquiry date is populated.

**Main Flow:**

**Step 1 — Package presence checked; TCS screen displayed if package is already set**
When the user clicks Generate Enquiry, the system first checks whether the Applicable Package field is already populated. If a package is already present (a repeat click after package was populated), the Save button is disabled, the TCS rate and TCS Apply buttons are disabled, and the TCS declaration screen is shown for the user to complete their TCS selection.

*Screen: Package Details (`WN_MAIN` / `CN_MAIN`).*

**Step 2 — TCS declaration obtained from the user (when package code is blank)**
If the package code is blank, the system first enforces that a package must be selected, then presents the TCS information notice and asks the user to confirm their TCS declaration. The user responds to the TCS applicability alert with one of three choices: confirm TCS applies, confirm TCS does not apply, or decline to declare. Depending on the response, the TCS applicability flag is set accordingly. If the user declines to declare (indicating TCS applies but no declaration has been made), the user sees an error and the generation is stopped.

*Screen: Package Details (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-012](#sp-012--GENERALCHECK_NULL)) — GENERAL.CHECK_NULL — Validates that a supplied field value is not null, displaying a descriptive error alert and aborting the current trigger if it is, so that mandatory fields on the MCP Package Details, Package Details, and Vehicle Details screens cannot be saved empty.
    * **Step 1** — Constructs the error message "Enter a valid Applicable Package".
    * **Step 2** — Checks whether the value is NULL.
    * **Step 3** — If NULL, displays the error and stops the current operation.
    * **Step 4** — If not NULL, returns normally.
- **GENERAL.DISP_TEXT** ([SP-013](#sp-013--GENERALDISP_TEXT)) — GENERAL.DISP_TEXT — Displays a modal alert to the user containing a supplied message and title, selecting between an error-style alert (`AL_ERRINFO`) and an informational alert (`AL_NOTE`) based on whether the title indicates an error condition.
    * **Step 1** — Selects the alert based on the title (Note or Error).
    * **Step 2** — Sets the alert title and message text.
    * **Step 3** — Displays the alert.

#### Requirement ID: BR-014

**Requirement Title:** TCS Screen Initialisation on Navigation

**Business Description:**
When the TCS declaration screen is displayed, the system checks whether a TCS decision has already been made for the current enquiry. If a previous TCS applicability value is already recorded, the Generate Enquiry button on the TCS screen is automatically enabled so the user can proceed directly to confirm the package detail generation without having to re-select a TCS rate.

**Actors:** Dealer User

**Preconditions:**
- The TCS screen has been opened, either after clicking Generate Enquiry with a package already selected, or by navigating to the TCS block.

**Main Flow:**

**Step 1 — TCS Apply button enabled if TCS applicability already set**
When the TCS screen block is entered, the system checks whether a TCS applicability value is already saved for the current enquiry header. If a value is present, the Generate Enquiry button on the TCS screen is enabled so the user can proceed with the previously recorded TCS choice.

*Screen: TCS (`WN_MAIN` / `CN_TCS`).*

#### Requirement ID: BR-015

**Requirement Title:** TCS Applicability Declaration via Radio Selection

**Business Description:**
On the TCS screen, the user declares whether Tax Collected at Source applies to this MCP enquiry by selecting one of two options on a radio group. Selecting "Yes" (TCS applicable) clears any previously stored TCS decision, enables the rate-selection buttons (Normal Rate and Higher Rate) so the user can specify the applicable rate, and disables the Generate Enquiry button until a rate is chosen. Selecting "No" (TCS not applicable) immediately sets the TCS decision to not applicable, stores a description of "TCS Not Applied", disables the rate-selection buttons, and also disables the Generate Enquiry button.

**Actors:** Dealer User

**Preconditions:**
- The TCS screen is displayed following navigation from the Generate Enquiry action.

**Main Flow:**

**Step 1 — TCS declaration recorded and rate buttons configured based on user's choice**
The user selects either "Yes" (TCS applies) or "No" (TCS does not apply) on the TCS radio group. For "Yes": the existing TCS decision and description are cleared, the Normal Rate and Higher Rate buttons are enabled, and the Generate Enquiry button is disabled — the user must now select a rate. For "No": the TCS applicability is set to not applicable, the description is set to "TCS Not Applied", the rate-selection buttons are disabled, and the Generate Enquiry button is also disabled.

*Screen: TCS (`WN_MAIN` / `CN_TCS`).*

#### Requirement ID: BR-016

**Requirement Title:** TCS Normal Rate Selection

**Business Description:**
When the user clicks the Normal Rate button on the TCS screen, the system records that TCS applies at the normal rate, sets the TCS description to "Normal Rate Applied", and enables the Generate Enquiry button so the user can proceed to compute the package detail with TCS at the normal rate applied.

**Actors:** Dealer User

**Preconditions:**
- The TCS screen is displayed and the user has declared TCS as applicable by selecting "Yes" on the radio group.
- The Normal Rate button is enabled.

**Main Flow:**

**Step 1 — Normal TCS rate recorded and Generate Enquiry button enabled**
The user clicks the Normal Rate button. The system sets the TCS applicability flag to indicate TCS applies at the normal rate and stores "Normal Rate Applied" as the TCS description. The Generate Enquiry button on the TCS screen is enabled, allowing the user to proceed with package detail calculation.

*Screen: TCS (`WN_MAIN` / `CN_TCS`).*

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| TCS Applicability Flag (`B_VH_AMC_ENQ.TCS_APPL_YN`) | Auto-populated | Text item | 1 | N/A | `Y` = TCS applicable at normal rate | Normal Rate button clicked | System-set | N/A |
| TCS Description (`B_VH_AMC_ENQ.NBT_TCS_DESC`) | Auto-populated | Display item | N/A | N/A | "Normal Rate Applied" | Normal Rate button clicked | System-set | N/A |

---

#### Requirement ID: BR-017

**Requirement Title:** TCS Higher Rate Selection

**Business Description:**
When the user clicks the Higher Rate button on the TCS screen, the system records that TCS applies at the higher rate, sets the TCS description to "Higher Rate Applied", and enables the Generate Enquiry button so the user can proceed to compute the package detail with TCS at the higher rate applied.

**Actors:** Dealer User

**Preconditions:**
- The TCS screen is displayed and the user has declared TCS as applicable by selecting "Yes" on the radio group.
- The Higher Rate button is enabled.

**Main Flow:**

**Step 1 — Higher TCS rate recorded and Generate Enquiry button enabled**
The user clicks the Higher Rate button. The system sets the TCS applicability flag to indicate TCS applies at the higher rate and stores "Higher Rate Applied" as the TCS description. The Generate Enquiry button on the TCS screen is enabled.

*Screen: TCS (`WN_MAIN` / `CN_TCS`).*

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| TCS Applicability Flag (`B_VH_AMC_ENQ.TCS_APPL_YN`) | Auto-populated | Text item | 1 | N/A | `H` = TCS applicable at higher rate | Higher Rate button clicked | System-set | N/A |
| TCS Description (`B_VH_AMC_ENQ.NBT_TCS_DESC`) | Auto-populated | Display item | N/A | N/A | "Higher Rate Applied" | Higher Rate button clicked | System-set | N/A |

---

#### Requirement ID: BR-018

**Requirement Title:** Package Detail Recalculation After TCS Rate Confirmation

**Business Description:**
When the user clicks the Generate Enquiry button on the TCS screen after selecting a TCS rate (normal or higher), the system re-computes the full package rate breakdown incorporating the chosen TCS setting, populates the enquiry detail lines with the updated pricing and charges, and enables the Save button so the enquiry can be committed. This step applies after the user has declared TCS applicable and selected their rate, ensuring the TCS charge components are correctly reflected in all amounts before saving.

**Actors:** Dealer User

**Preconditions:**
- The TCS screen is displayed.
- The user has selected a TCS rate (Normal Rate or Higher Rate).
- An MCP package and registration number are already entered.

**Main Flow:**

**Step 1 — Package rate detail recalculated with TCS setting and Save button enabled**
The system calls the package rate calculation routine with the current TCS applicability flag (normal or higher rate), recomputes all detail line amounts including TCS charge components, and populates the enquiry detail block. If the calculation succeeds, the Save button is enabled and the cursor is moved to the Package Amount field. If the calculation returns an error (e.g. rate not defined), the error is shown and the step is stopped.

*Screen: TCS (`WN_MAIN` / `CN_TCS`).*

*Procedures called:*
- **PKG_AMC.SP_POP_PKG_DTL** ([SP-019](#sp-019--PKG_AMCSP_POP_PKG_DTL)) — PKG_AMC.SP_POP_PKG_DTL — Populates the AMC/MCP package detail and charge working tables (`GBL_AMC_DTL` and `GBL_AMC_CHARGES`) for a selected vehicle and package by fetching active rate lines from the rate master, resolving service/part descriptions and tax codes, computing GST and TCS charges via the expression evaluator, and writing the final net values back to the detail table — replacing any previously calculated data for the same package and vehicle.
    * **Step 1** — Initialises error code and counters.
    * **Step 2** — Determines the effective GST state and intra-state flag.
    * **Step 3** — Looks up the city category for the dealer location.
    * **Step 4** — Looks up the vehicle's sub-variant, variant, and customer party details.
    * **Step 5** — Looks up customer GST number and PAN; defaults to unregistered if not found.
    * **Step 6** — Determines whether Kerala Flood Cess applies.
    * **Step 7** — Derives the TCS applicability category from the updated TCS flag and PAN status.
    * **Step 8** — Looks up the fuel type for the vehicle's variant.
    * **Step 9** — Removes previously staged detail and charge lines for this enquiry context.
    * **Step 10** — Inserts new detail lines from the active rate master.
    * **Step 11** — If no rate lines found, returns an error indicating the MCP rate is not defined.
    * **Step 12** — Computes and records labour charge components.
    * **Step 13** — Updates labour staging lines with computed charge amounts and net values.
    * **Step 14** — Inserts labour charge rows into the charge staging table.
    * **Step 15** — For TCS-applicable enquiries, computes part-line charges using the updated TCS category.
    * **Step 16** — For non-TCS enquiries, sets part charge amounts to zero.
    * **Step 17** — Inserts parts charge rows into the charge staging table.
    * **Step 18** — Commits the staged data.
- **POP_PKG_DETAILS_NEW** ([SP-002](#sp-002--POP_PKG_DETAILS_NEW)) — POP_PKG_DETAILS_NEW — Populates the AMC enquiry package detail block (`B_VD_AMC_ENQ`) with all service-line items for the selected vehicle's package from GBL_AMC_DTL, then rolls up the individual line amounts into header-level summary totals on `B_VH_AMC_ENQ`, broken down by service type (Labour, Parts, Consumables) across amount, discount, tax, and net fields.
    * **Step 1** — Clears the detail block without validation.
    * **Step 2** — Moves to the first record position.
    * **Step 3** — Queries the pre-computed staging table for the current session and enquiry context.
    * **Step 4** — Populates each detail line with updated service, pricing, and charge fields.
    * **Step 5** — Accumulates overall package totals per service type.
    * **Step 6** — Separates subtotals by service type (labour, parts, consumables).
    * **Step 7** — Advances through all detail records.
    * **Step 8** — Returns to the first record.
    * **Step 9** — Writes accumulated summary totals to the header block fields.

#### Requirement ID: BR-019

**Requirement Title:** Navigation to MCP Enquiry Detail Lines Screen

**Business Description:**
When the user clicks the Details button on the main MCP enquiry screen, the system navigates to the detail lines screen, which displays the itemised breakdown of the selected package — showing all labour, parts, and consumable line items that make up the enquiry.

**Actors:** Dealer User

**Preconditions:**
- The MCP enquiry main screen is displayed with a package already selected and detail lines populated.

**Main Flow:**

**Step 1 — Detail lines screen opened**
The user clicks the Details button. The system navigates to the enquiry detail lines block, displaying the itemised service breakdown on the Details screen.

*Screen: Package Details (`WN_MAIN` / `CN_MAIN`).*

#### Requirement ID: BR-020

**Requirement Title:** MCP Enquiry Header Audit Stamp on Insert

**Business Description:**
Before a new MCP enquiry header record is saved to the database for the first time, the system automatically stamps all mandatory session-context and audit fields onto the record: the parent group, dealer code, location code, company code, creation date, and the creating user's identity. The new-record indicator is also set to signal that this is a freshly created record.

**Actors:** System (automated before every new header insert)

**Preconditions:**
- A new MCP enquiry is being saved for the first time.

**Main Flow:**

**Step 1 — Session context and audit fields stamped on the new header record**
Immediately before the new header record is written to the database, the system copies the current session's parent group, dealer code, location code, and company code onto the record, sets the creation date to the current system date and time, sets the created-by field to the current logged-in user's identity, and marks the record as a new record.

#### Requirement ID: BR-021

**Requirement Title:** MCP Enquiry Header Enrichment After Query

**Business Description:**
After an existing MCP enquiry record is retrieved from the database, the system automatically enriches the on-screen display with additional descriptive information not stored directly in the header: the vehicle model description, variant description, package description, package expiry parameters, vehicle sale date, previous odometer reading, enquiry status description, customer city description, customer state description, executive name, and a breakdown of service-category discounts, tax amounts, and net amounts from the detail lines. If the enquiry has an existing package, the package rate detail is also recalculated and repopulated. The GST Type field is locked for saved enquiries to prevent post-save modification. The query-mode parameter is reset after all enrichment is complete.

**Actors:** System (automated after each record is fetched)

**Preconditions:**
- An MCP enquiry has been queried and a header record has been returned from the database.

**Main Flow:**

**Step 1 — Descriptive information enriched from reference data**
The system looks up and populates the vehicle model description from the model master, the variant description and fuel type from the variant master, the package description and expiry parameters from the package master, and the vehicle sale date and previous odometer reading from the vehicle master. The enquiry status description is looked up from the status code reference list. The customer city description is resolved from the city master (falling back to the city code if not found). The query-mode parameter is set to "Y" at the start and reset to "N" at the end of the query enrichment.

**Step 2 — Validity dates calculated if not already saved**
If the validity start date is not yet set on the record, the system calculates the vehicle age and average daily run from the enquiry date and sale date. If the average daily run exceeds 10,000 km/year, the validity end date is calculated from the projected mileage-to-limit date. Otherwise it is set to the standard month-based expiry from the sale date.

**Step 3 — Package rate detail repopulated for existing enquiry**
If the enquiry has a package code, the system re-computes the package rate detail using the package rate calculation routine and then populates the detail block. On success, the detail lines are refreshed. If an error is returned, the step is silently skipped (no error alert is shown to the user — the procedure's error code is not checked in POST-QUERY for display purposes).

*Procedures called:*
- **PKG_AMC.SP_POP_PKG_DTL** ([SP-019](#sp-019--PKG_AMCSP_POP_PKG_DTL)) — PKG_AMC.SP_POP_PKG_DTL — Populates the AMC/MCP package detail and charge working tables (`GBL_AMC_DTL` and `GBL_AMC_CHARGES`) for a selected vehicle and package by fetching active rate lines from the rate master, resolving service/part descriptions and tax codes, computing GST and TCS charges via the expression evaluator, and writing the final net values back to the detail table — replacing any previously calculated data for the same package and vehicle.
    * **Step 1** — Initialises error code and counters.
    * **Step 2** — Determines effective GST state and intra-state flag.
    * **Step 3** — Looks up the city category for the dealer location.
    * **Step 4** — Looks up vehicle sub-variant, variant, and customer party details.
    * **Step 5** — Looks up customer GST number and PAN; defaults to unregistered if not found.
    * **Step 6** — Determines whether Kerala Flood Cess applies.
    * **Step 7** — Derives the TCS applicability category.
    * **Step 8** — Looks up the fuel type.
    * **Step 9** — Removes previously staged lines for the enquiry.
    * **Step 10** — Inserts new detail lines from the rate master.
    * **Step 11** — If no rate lines found, returns an error (not shown during post-query enrichment).
    * **Step 12** — Computes and records labour charge components.
    * **Step 13** — Updates labour staging lines.
    * **Step 14** — Inserts labour charges.
    * **Step 15** — Processes parts charges based on TCS setting.
    * **Step 16** — Sets zero charges for non-TCS parts.
    * **Step 17** — Inserts parts charges.
    * **Step 18** — Commits staged data.
- **POP_PKG_DETAILS_NEW** ([SP-002](#sp-002--POP_PKG_DETAILS_NEW)) — POP_PKG_DETAILS_NEW — Populates the AMC enquiry package detail block (`B_VD_AMC_ENQ`) with all service-line items for the selected vehicle's package from GBL_AMC_DTL, then rolls up the individual line amounts into header-level summary totals on `B_VH_AMC_ENQ`, broken down by service type (Labour, Parts, Consumables) across amount, discount, tax, and net fields.
    * **Step 1** — Clears the detail block without validation.
    * **Step 2** — Moves to first record.
    * **Step 3** — Queries staging table for this enquiry context.
    * **Step 4** — Populates each detail line with service, pricing, and charge fields.
    * **Step 5** — Accumulates overall package totals per service type.
    * **Step 6** — Separates subtotals by service type.
    * **Step 7** — Advances through all records.
    * **Step 8** — Returns to first record.
    * **Step 9** — Writes summary totals to header fields.

#### Requirement ID: BR-022

**Requirement Title:** MCP Enquiry Header Audit Stamp on Update

**Business Description:**
Before an existing MCP enquiry header record is updated in the database, the system automatically stamps the current date and time as the modification date and records the identity of the user making the change. This ensures every modification is fully audited.

**Actors:** System (automated before every header update)

**Preconditions:**
- An existing MCP enquiry is being updated and saved.

**Main Flow:**

**Step 1 — Modification audit fields stamped on the updated header record**
Immediately before the existing header record is updated in the database, the system sets the modification date to the current system date and time, and sets the modified-by field to the current logged-in user's identity.

#### Requirement ID: BR-023

**Requirement Title:** MCP Enquiry Detail Line Audit Stamp on Insert

**Business Description:**
Before each new MCP enquiry detail line record is saved to the database for the first time, the system automatically stamps the mandatory session-context and audit fields: the parent group, dealer code, location code, company code, creation date, creating user's identity, and the parent enquiry number that links the detail line to its header.

**Actors:** System (automated before every new detail line insert)

**Preconditions:**
- A new MCP enquiry is being saved and detail lines are ready to be inserted.

**Main Flow:**

**Step 1 — Session context, audit, and parent reference stamped on each new detail line**
Immediately before each new detail line is written to the database, the system copies the current session's parent group, dealer code, location code, and company code onto the record, sets the creation date to the current system date and time, sets the created-by field to the logged-in user's identity, and copies the parent enquiry number from the header to link the detail line.

#### Requirement ID: BR-024

**Requirement Title:** MCP Enquiry Detail Line Enrichment After Query

**Business Description:**
After each MCP enquiry detail line record is fetched from the database, the system automatically resolves and displays the human-readable descriptions for the service item, category, and group. For labour-type lines, the system looks up the operation description from the labour operation master. For parts and consumable-type lines, the system looks up the part description from the parts master. The service category description and, when present, the part group description are also resolved and shown. This ensures the user sees meaningful labels rather than raw codes on the Detail screen.

**Actors:** System (automated after each detail line record is fetched)

**Preconditions:**
- An MCP enquiry with detail lines has been queried.

**Main Flow:**

**Step 1 — Service/part description resolved based on service type**
After each detail line is fetched, the system checks the service type code. For labour-type lines, it looks up the operation description from the labour operations master. For all other types (parts and consumables), it looks up the part description from the parts master. Failures in either look-up are silently ignored; the description field is left blank if not found.

*Screen: Details (`WN_MAIN` / `CN_DEF`).*

**Step 2 — Category and group descriptions resolved for non-labour lines**
For non-labour lines, the system also looks up the category description from the category-type reference list and, if a group code is present, the group description from the part group reference list. Failures are silently ignored.

*Screen: Details (`WN_MAIN` / `CN_DEF`).*

#### Requirement ID: BR-025

**Requirement Title:** MCP Enquiry Detail Line Audit Stamp on Update

**Business Description:**
Before an existing MCP enquiry detail line is updated in the database, the system automatically stamps the current date and time as the modification date and records the identity of the user making the change.

**Actors:** System (automated before every detail line update)

**Preconditions:**
- An existing MCP enquiry detail line is being updated and saved.

**Main Flow:**

**Step 1 — Modification audit fields stamped on the updated detail line**
Immediately before each detail line is updated in the database, the system sets the modification date to the current system date and time, and sets the modified-by field to the current logged-in user's identity.

#### Requirement ID: BR-026

**Requirement Title:** MCP Enquiry Save, Number Generation, and Report Printing

**Business Description:**
When the user saves the MCP enquiry, the system performs a multi-step save process: it first checks that the enquiry is ready to be saved (a package amount must be present), generates a unique sequential enquiry document number for new records, inserts all tax and charge detail lines, commits the complete enquiry to the database, notifies the user of the assigned enquiry number, and then automatically invokes the enquiry report for printing or PDF download. The enquiry report is selected based on the enquiry date — a GST-compliant version is used for enquiries dated on or after the GST implementation date; the legacy version is used for earlier dates.

**Actors:** Dealer User

**Preconditions:**
- The MCP enquiry header and detail lines have been filled in and the package amount is populated.
- The Generate Enquiry action has been completed.
- The form is in a state where the Save button is enabled.

**Main Flow:**

**Step 1 — Package amount presence checked and enquiry number generated for new records**
When the user activates the save action, the system first checks that the Package Amount field is populated. If it is blank, the user is informed that they must generate the enquiry first and the save is stopped. If the Package Amount is present and this is a new enquiry (no document number has been assigned yet), the system calls the document number generation routine to obtain the next sequential MCP enquiry number. If the number generation fails, the error from the routine is shown and the save is stopped. On success, the generated number is stored in the enquiry number field.

*Procedures called:*
- **PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM** ([SP-021](#sp-021--PK_VALIDATE_BACK_DATEGENERATE_NEXT_NUM)) — PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM — Generates the next sequential document number for a given document type, dealer, location, and financial year by exclusively locking the corresponding row in the `AM_DOCS` counter table, incrementing the stored sequence number, and returning the formatted document number string; it reports a descriptive error if the document type is not configured, has duplicate configuration rows, or is locked by another user session.
    * **Step 1** — Locks the document master row for the document type "AME" (MCP enquiry) using a row-level lock; handles lock contention and missing/duplicate master rows.
    * **Step 2** — If the lock attempt fails for any reason, returns an error with the appropriate message.
    * **Step 3** — If the lock succeeds, increments the sequence and formats the new document number.
    * **Step 4** — Updates the document master row with the new sequence number and enquiry date.
    * **Step 5** — Returns the formatted document number or the error details.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Package amount populated before save | Package Amount not null check — FT_SAVE in Form | When the user activates the save action | Ensures the Generate Enquiry step was completed and a valid package amount is present before any save attempt | *"Please generate enquiry"* shown; save stopped |
| Enquiry document number generation | PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM [SP-021] — FT_SAVE in Form | When saving a new enquiry (no document number assigned yet) | Assigns a unique, sequential MCP enquiry number to the new record | Error message from the routine shown; save stopped |

*Business outcomes (errors, warnings, success, and status):*
- **BR-026-ES-01** — Package amount missing — *"Please generate enquiry"*; save stopped.
- **BR-026-ES-02** — Document number generation failure — error text from the generation routine; save stopped.

**Step 2 — Charge lines inserted, records committed, and form failure checked**
The save action calls the KEY-COMMIT trigger which first runs field validations. If validation passes and the Save button is enabled, the system calls SP_INSERT_CHARGES to insert all tax/charge detail lines, then commits all records. A second commit ensures full persistence. After each commit, the system checks for form-level failure.

*Procedures called:*
- **SP_INSERT_CHARGES** ([SP-003](#sp-003--SP_INSERT_CHARGES)) — SP_INSERT_CHARGES — Copies all applicable charge lines for the current enquiry's vehicle and package from the global charges master (GBL_AMC_CHARGES) into the enquiry-specific charges table (VD_AMC_ENQCHARGES), stamping each inserted row with the current user and the current date/time.
    * **Step 1** — Executes an insert-from-select copying all charge lines from the staging table matching the current session context into the enquiry charge table, stamping the enquiry number, user, and date on each row.
    * **Step 2** — Inserts all matching charge lines.
    * **Step 3** — On any exception, displays *"Error... In Tax Calculation"* and stops the commit.
- **GENERAL.CHECK_FORM_FAILURE** ([SP-011](#sp-011--GENERALCHECK_FORM_FAILURE)) — GENERAL.CHECK_FORM_FAILURE — Inspects the Oracle Forms success/failure status after a form operation and, if the operation failed, displays the appropriate error message to the user (Oracle error message for ORA-type errors, Forms error text for FRM-type errors) before aborting the current trigger.
    * **Step 1** — Checks whether the most recent form operation succeeded.
    * **Step 2** — If not, identifies the error type (database or form).
    * **Step 3** — Displays the database or form error text with an "Error" title.
    * **Step 4** — Raises a trigger failure to halt execution.
    * **Step 5** — If the operation succeeded, returns normally.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Charge line insert success | SP_INSERT_CHARGES [SP-003] — KEY-COMMIT in Form | When commit is triggered after the document number is assigned | Ensures all tax and charge components are stored for the enquiry at the same time as the main records | *"Error... In Tax Calculation"* shown; commit aborted |
| Post-commit form success check | GENERAL.CHECK_FORM_FAILURE [SP-011] — KEY-COMMIT in Form | After each COMMIT_FORM call | Detects and reports any database or form error that arose during the commit | Database or form error text displayed; trigger stopped |

*Business outcomes (errors, warnings, success, and status):*
- **BR-026-ES-03** — Tax/charge line insert failed — *"Error... In Tax Calculation"*; commit aborted.

**Step 3 — Enquiry number confirmed and report generated**
After a successful commit, the system displays a confirmation note with the assigned MCP enquiry number. The enquiry report is then generated automatically. Based on the enquiry date, the GST-compliant report (`vr_amc_enq_gst`) or the legacy report (`vr_amc_enq`) is used. The user is prompted to choose PDF or printer output. After the report is dispatched, the form is cleared.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-013](#sp-013--GENERALDISP_TEXT)) — GENERAL.DISP_TEXT — Displays a modal alert to the user containing a supplied message and title, selecting between an error-style alert (`AL_ERRINFO`) and an informational alert (`AL_NOTE`) based on whether the title indicates an error condition.
    * **Step 1** — Selects the AL_NOTE alert since the title is "Note".
    * **Step 2** — Sets the alert title and message text.
    * **Step 3** — Displays the alert.
- **CALL_REPORT_ENQ** ([SP-001](#sp-001--CALL_REPORT_ENQ)) — CALL_REPORT_ENQ — Determines the correct AMC enquiry report template (GST or non-GST) based on the enquiry date relative to the GST implementation date, then presents the user with a choice to output the report as a PDF file or send it to a printer, executing the selected report delivery path accordingly.
    * **Step 1** — Queries the GST implementation date.
    * **Step 2** — Locates the report object in the form.
    * **Step 3** — Selects the GST-compliant template if the enquiry date is on or after the GST date; otherwise uses the legacy template.
    * **Step 4** — Presents the report output choice alert (PDF, Printer, or Cancel).
    * **Step 5** — If PDF is chosen: configures PDF output, runs the report, opens the PDF in the browser.
    * **Step 6** — If Printer is chosen: configures printer output, submits to the report server, starts the polling timer.
    * **Step 7** — If the user cancels: no report is generated.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Report template selection by GST date | GST date query — CALL_REPORT_ENQ [SP-001] | After successful commit | Ensures the correct report format (GST-compliant or legacy) is used based on the enquiry date | If the GST date query fails, the date defaults to NULL and the legacy template is always used |

*Business outcomes (errors, warnings, success, and status):*
- **BR-026-SM-01** — Enquiry saved and number assigned — *"MCP Enquiry Number generated is \<enquiry number\>"*; report generation follows; form cleared.

**Alternative Flows:**
- **BR-026-AF-01** — (from Step 2) If the Save button is not enabled when KEY-COMMIT fires: *"Updation Not Allowed Here"* is shown and the commit is skipped entirely.
- **BR-026-AF-02** — (from Step 3) User selects PDF output: report generated as PDF and opened in the browser.
- **BR-026-AF-03** — (from Step 3) User selects Printer output: report submitted to the report server; polling timer started.
- **BR-026-AF-04** — (from Step 3) User cancels the output: no report generated; form still cleared.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Package Amount (`B_VH_AMC_ENQ.PKG_AMT`) | Mandatory | Text item (Number) | 15 / 99999999999.99 | N/A | Non-null | Generate Enquiry completed | Must not be null before saving | *"Please generate enquiry"* |
| Enquiry Number (`B_VH_AMC_ENQ.ENQ_NUM`) | Auto-populated | Text item | 12 | Document Master (AM_DOCS) | Generated sequential MCP number | New enquiry being saved | Assigned by document number generation; read-only after assignment | Error from generation routine |
| Enquiry Date (`B_VH_AMC_ENQ.ENQ_DATE`) | Mandatory | Text item (Datetime) | 30 / DD-MM-RRRR HH24:MI | N/A | Valid date | Header completed | Used to select correct report template | N/A |

---

#### Requirement ID: BR-027

**Requirement Title:** Cancel / Discard Unsaved Changes

**Business Description:**
When the user cancels an in-progress MCP enquiry entry by clicking the Cancel button (on the main screen or the Details screen), the system checks whether any unsaved changes are present. If changes have been made but not saved, the user is asked to confirm that they want to discard them. On confirmation, all unsaved data is cleared and the form returns to a blank state. If no changes are pending, the form is cleared immediately without prompting.

**Actors:** Dealer User

**Preconditions:**
- The form is open with data entered (either a new enquiry or edits to an existing one).

**Main Flow:**

**Step 1 — Unsaved changes checked and user confirmation requested if needed**
When the user clicks Cancel, the system checks whether the Cancel button is enabled. If it is, the system examines whether any unsaved changes are present on the form. If changes are pending, the user is asked *"Entered data will not be Saved"* in a confirmation dialog. If the user confirms, the form is cleared. If the user declines, the cancel is abandoned and the user can continue editing. If no changes are pending, the form is cleared immediately without any confirmation.

*Procedures called:*
- **GENERAL.ASK_CONFIRM** ([SP-010](#sp-010--GENERALASK_CONFIRM)) — GENERAL.ASK_CONFIRM — Prompts the user with a configurable confirmation message via the `AL_CONFIRM` alert and returns 1 if the user clicks the first button (confirm) or 0 if any other button is clicked (decline), allowing callers to gate destructive actions on explicit user approval.
    * **Step 1** — Sets the confirmation alert message to the supplied text.
    * **Step 2** — Displays the confirmation alert and captures the user's button response.
    * **Step 3** — Returns 1 if the user pressed the confirm button.
    * **Step 4** — Returns 0 if the user pressed any other button.

#### Requirement ID: BR-028

**Requirement Title:** Delete MCP Enquiry Record

**Business Description:**
When the user activates the delete action on the MCP enquiry form, the system asks the user to confirm the deletion. On confirmation, the current record is deleted. If no changes are pending (form status is unchanged rather than changed), the form is cleared without deleting. The delete capability is only available when the Delete button is enabled.

**Actors:** Dealer User

**Preconditions:**
- The form is open with a record displayed.
- The Delete button is enabled.

**Main Flow:**

**Step 1 — Delete confirmed by user and record removed**
The system checks whether the Delete button is enabled and turns off form validation to allow the delete to proceed. If the form has pending changes, the user is asked *"Are you sure to Delete"* in a confirmation dialog. On confirmation, the current record is deleted. If the user declines, no deletion occurs. If the form has no pending changes, the form is cleared instead of deleting. Form validation is re-enabled after the operation.

*Procedures called:*
- **GENERAL.ASK_CONFIRM** ([SP-010](#sp-010--GENERALASK_CONFIRM)) — GENERAL.ASK_CONFIRM — Prompts the user with a configurable confirmation message via the `AL_CONFIRM` alert and returns 1 if the user clicks the first button (confirm) or 0 if any other button is clicked (decline), allowing callers to gate destructive actions on explicit user approval.
    * **Step 1** — Sets the alert message to the supplied confirmation text.
    * **Step 2** — Displays the confirmation alert and captures the button response.
    * **Step 3** — Returns 1 if the user pressed the confirm button.
    * **Step 4** — Returns 0 if the user pressed any other button.

#### Requirement ID: BR-029

**Requirement Title:** Print MCP Enquiry Report

**Business Description:**
When the user activates the print action on a saved MCP enquiry, the system generates and delivers the enquiry report. The system selects the correct report template based on the enquiry date (GST-compliant or legacy), then prompts the user to choose between downloading a PDF or printing to a physical printer. The print action is only available when an enquiry number is present.

**Actors:** Dealer User

**Preconditions:**
- An MCP enquiry has been saved and an enquiry number is displayed on screen.
- The Print button is enabled.

**Main Flow:**

**Step 1 — Enquiry report generated with the appropriate template and delivered**
When the user activates the print action, the system confirms that the Print button is enabled and an enquiry number is present. It then calls the report generation routine, which selects the correct template (GST or pre-GST), prompts the user for the output method, and delivers the report.

*Procedures called:*
- **CALL_REPORT_ENQ** ([SP-001](#sp-001--CALL_REPORT_ENQ)) — CALL_REPORT_ENQ — Determines the correct AMC enquiry report template (GST or non-GST) based on the enquiry date relative to the GST implementation date, then presents the user with a choice to output the report as a PDF file or send it to a printer, executing the selected report delivery path accordingly.
    * **Step 1** — Queries the GST implementation date from the configuration list to determine the correct template.
    * **Step 2** — Locates the report object in the form.
    * **Step 3** — Selects the GST-compliant template (`vr_amc_enq_gst`) if the enquiry date is on or after the GST date; otherwise uses the legacy template (`vr_amc_enq`).
    * **Step 4** — Presents the report output choice alert to the user (PDF, Printer, or Cancel).
    * **Step 5** — If PDF is chosen: configures report parameters, runs the report object, and opens the PDF in the browser.
    * **Step 6** — If Printer is chosen: configures for printer output, submits the job to the report server, stores the job handle and print path in session variables, then starts the polling timer.
    * **Step 7** — If the user cancels: no report action is taken.

#### Requirement ID: BR-030

**Requirement Title:** Continue from Details Screen Back to Main Enquiry Screen

**Business Description:**
When the user clicks the Continue button on the Details screen, the system navigates back to the main MCP enquiry screen, returning focus to the header section for further review or action.

**Actors:** Dealer User

**Preconditions:**
- The Details screen is currently displayed.

**Main Flow:**

**Step 1 — Navigation back to main enquiry header screen**
The user clicks the Continue button. The system navigates to the main enquiry block, returning the user to the MCP enquiry header screen.

*Screen: Details (`WN_MAIN` / `CN_DEF`).*

---

#### Requirement ID: BR-031

**Requirement Title:** Return to Main Screen from Details Screen (Back Button)

**Business Description:**
When the user clicks the Back button on the Details screen, the system navigates back to the main MCP enquiry block, returning focus to the header section.

**Actors:** Dealer User

**Preconditions:**
- The Details screen is currently displayed.

**Main Flow:**

**Step 1 — Navigation back to MCP enquiry header**
The user clicks the Back button. The system navigates to the main enquiry block.

*Screen: Details (`WN_MAIN` / `CN_DEF`).*

---

#### Requirement ID: BR-032

**Requirement Title:** Save MCP Enquiry from Details Screen Toolbar

**Business Description:**
When the user clicks the Save button on the Details screen toolbar, the system sets the save parameter and invokes the standard save flow (equivalent to the main-screen Save action) — generating the enquiry number if needed, inserting charge lines, committing the record, and printing the report. After the save flow completes, the save parameter is reset.

**Actors:** Dealer User

**Preconditions:**
- The Details screen is displayed with an enquiry ready to save.
- The Save button is enabled.

**Main Flow:**

**Step 1 — Save parameter set and save flow invoked**
The user clicks the Save button on the Details screen. The system sets the internal save flag and invokes the save trigger (`FT_SAVE`), which runs the full save process described in BR-026. After the save flow completes, the save flag is reset.

*Screen: Details (`WN_MAIN` / `CN_DEF`).*

---

#### Requirement ID: BR-033

**Requirement Title:** Cancel / Discard Changes from Details Screen Toolbar

**Business Description:**
When the user clicks the Cancel button on the Details screen toolbar, the system invokes the standard cancel flow — checking for unsaved changes and asking for confirmation before discarding. This is the same cancel behaviour as described for the main screen cancel action.

**Actors:** Dealer User

**Preconditions:**
- The Details screen is displayed with data entered.

**Main Flow:**

**Step 1 — Cancel flow invoked from Details screen**
The user clicks the Cancel button on the Details screen. The system sets the save parameter to "N" and invokes the standard cancel trigger (`FT_CANCEL`), which follows the same confirmation and clear process as described in BR-027.

*Screen: Details (`WN_MAIN` / `CN_DEF`).*

---

---

## 5. Business Rules Catalogue

*Catalogue of discrete business rules enforced by the MCP Enquiry Generation form, derived from trigger and program-unit decision branches.*

| Rule ID | Rule Name | Rule Type | Business Requirement ID | Condition | Action | Business Impact |
| ------- | --------- | --------- | ----------------------- | --------- | ------ | --------------- |
| BRC-001 | MCP Programme Active Check | Authorization | BR-002 | MCP deactivation flag is set to "Yes" for the current dealer location | Show *"MCP has been disabled by MSIL-Service"* and close the form | Prevents dealers from creating MCP enquiries at locations where the manufacturer has suspended the MCP programme; links to WF-001 |
| BRC-002 | Registration Number Mandatory | Validation | BR-009 | Registration Number field is blank when the user leaves the field | Show *"Enter a valid Registration Number"* and stop the current operation | Ensures every MCP enquiry is associated with an identified vehicle |
| BRC-003 | Registration Number Character Format | Derivation | BR-009 | Registration Number field contains characters other than uppercase letters or digits | Strip invalid characters from the field value silently before the vehicle lookup runs | Ensures the registration number contains only valid characters before it is queried against the vehicle master |
| BRC-004 | Registration Number Uniqueness | Validation | BR-009 | Registration Number entered does not match exactly one vehicle record in the vehicle master | Show *"Registration Number Not Found"* (no match) or *"More than one Registration Number found for \<value\>"* (multiple matches) and stop | Guarantees the registration number unambiguously identifies a single vehicle before vehicle details are loaded |
| BRC-005 | Current Mileage Mandatory | Validation | BR-010 | Current Mileage field is blank when the user leaves the field | Show *"Enter a valid Current Mileage"* and stop | Ensures a mileage reading is provided before package eligibility can be assessed |
| BRC-006 | Mileage Below Previous Service Mileage | Validation | BR-010 | Current mileage entered is less than the vehicle's previously recorded service mileage | Show *"Current Mileage cannot be less than Previous Service Mileage \<previous value\>"* as a Note and stop | Prevents an odometer reading that suggests the vehicle's mileage has decreased, which is physically impossible |
| BRC-007 | Maximum Validity Mileage Exceeded | Validation | BR-010 | Current mileage exceeds the maximum validity mileage configured by the manufacturer for the MCP programme | Show *"Milease expired, So Vehicle can not be considered for MCP"* and stop | Enforces the manufacturer's rule that vehicles with excessive mileage are ineligible for MCP coverage; links to WF-002 |
| BRC-008 | Enquiry Outside Vehicle Sale Date Window | Validation | BR-010 | Current date is beyond the maximum allowed MCP creation period from the vehicle's sale date | Show *"Enquiry for a vehicle can be generated within 4yrs of vehicle sale"* and stop | Enforces the manufacturer's rule that MCP enquiries can only be raised within the defined time window after the vehicle was sold; links to WF-002 |
| BRC-009 | Applicable Package Must Exist | Validation | BR-010 | No active MCP package matches the vehicle's sub-variant, current mileage, average run, and age profile | Set the status indicator to "Applicable Package Not Found" and stop | Ensures the user can only proceed to package selection when at least one matching package is available |
| BRC-010 | Executive Mandatory for New Enquiry | Validation | BR-011 | Executive field is blank in new-entry mode (no enquiry number present) | Show *"Enter a valid Employee Code"* and stop | Ensures every new MCP enquiry has an assigned service executive responsible for the transaction |
| BRC-011 | Package Code Mandatory | Validation | BR-012, BR-013 | Applicable Package field is blank when package selection or generation is triggered | Show *"Enter a valid Applicable Package"* and stop | Ensures a specific MCP package is chosen before validity dates or package details can be computed |
| BRC-012 | MCP Validity End Date Calculation — Standard | Derivation | BR-012 | Average daily run of the vehicle is at or below 10,000 km/year | Set the validity end date to the vehicle sale date plus the package's expiry months | Applies the standard duration-based MCP end date for typical-usage vehicles |
| BRC-013 | MCP Validity End Date Calculation — High Mileage | Derivation | BR-012 | Average daily run of the vehicle is above 10,000 km/year | Calculate the projected number of days until the mileage limit is reached; if the projected period is shorter than the standard expiry, use the projected date; otherwise use the standard month-based expiry from sale date | Applies a mileage-adjusted validity end date for high-mileage vehicles to prevent the MCP period from extending beyond the point at which the vehicle exceeds the programme's mileage ceiling |
| BRC-014 | TCS Declaration Required | Validation | BR-013 | User declines to make a TCS declaration (presses neither the Yes nor the No button on the declaration alert) | Show *"TCS Declaration is required"* and stop package detail generation | Enforces the legal requirement that the dealer's TCS position must be explicitly declared before an MCP enquiry can be processed |
| BRC-015 | Package Rate Must Be Defined | Validation | BR-013, BR-018, BR-021 | No active rate lines are found in the package rate master for the selected package, sub-variant, fuel type, and city category combination | Return an error from the rate calculation procedure; show the error message and stop generation | Prevents the creation of an MCP enquiry with a zero or undefined rate breakdown, ensuring all charges are properly accounted for |
| BRC-016 | Package Amount Required Before Save | Validation | BR-026 | Package Amount field is blank when the user activates the save action | Show *"Please generate enquiry"* and stop the save | Ensures the Generate Enquiry step was completed and valid package amounts are populated before the record can be saved to the database |
| BRC-017 | Enquiry Number Generated for New Records | Derivation | BR-026 | Enquiry number field is blank at save time (new enquiry) | Generate the next sequential MCP enquiry document number using the document master and stamp it on the record | Assigns a unique, traceable document number to every new MCP enquiry, maintaining the document series integrity |
| BRC-018 | Charge Lines Inserted at Save | Derivation | BR-026 | Enquiry is being committed to the database | Insert all pre-computed tax and charge components from the staging table into the enquiry charge table | Ensures all tax and surcharge breakdowns are stored persistently alongside the enquiry detail lines |
| BRC-019 | GST-Compliant Report for Post-GST Enquiries | Derivation | BR-026, BR-029 | Enquiry date is on or after the manufacturer's GST implementation date | Use the GST-compliant report template (`vr_amc_enq_gst`) for generating the enquiry certificate | Ensures the printed MCP enquiry certificate uses the legally required GST format for all post-GST transactions |
| BRC-020 | Legacy Report for Pre-GST Enquiries | Derivation | BR-026, BR-029 | Enquiry date is before the manufacturer's GST implementation date | Use the legacy report template (`vr_amc_enq`) for generating the enquiry certificate | Ensures the correct historical format is used for enquiries predating the GST implementation |
| BRC-021 | GST Type Locked for Saved Enquiries | Constraint | BR-021 | Enquiry number is already assigned (record is saved) | Disable the GST Type radio group to prevent modification | Prevents retroactive changes to the GST treatment of a committed enquiry, protecting the integrity of already-issued documents |
| BRC-022 | Date Format Validation — Invalid Date | Validation | BR-005 | A date field contains a value that is not a valid calendar date (error code 50004) | Show *"Entered Date is not valid Date"* and stop the current operation | Prevents data entry of non-existent dates (e.g. 30-Feb) in date fields |
| BRC-023 | Date Format Validation — Wrong Format | Validation | BR-005 | A date field's text does not match the required DD-MM-YYYY format (error codes 50025 or 50026) | Show *"Enter the Date in the proper format (DD-MM-YYYY)"* and stop | Guides the user to enter dates in the format expected by the system |
| BRC-024 | Numeric-Only Field Enforcement | Validation | BR-005, BR-006 | A non-numeric character is typed in a field that only accepts numeric input (error codes 40209 or 50016) | Show *"Characters/Special Characters are not allowed here, enter the numeric value"* and stop | Enforces numeric-only constraints on mileage and amount fields |
| BRC-025 | Concurrent Update Conflict | Constraint | BR-005 | The record being saved was modified by another user session since it was last queried (errors 40654–40657 or 40659) | Show *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*; roll back the transaction | Prevents one user's changes from silently overwriting another user's concurrent updates |
| BRC-026 | Enquiry Lookup Existence | Validation | BR-008 | An enquiry number is entered in the search field but no matching record is found for the current dealer/location | Show *"MCP Enquiry Number Not Found"* and retain focus on the field | Prevents the user from proceeding with an invalid or non-existent enquiry number |
| BRC-027 | MCP Enquiry Record Editing Locked on Retrieval | Constraint | BR-008 | An existing enquiry is retrieved by enquiry number | Lock the Registration Number, Enquiry Number, and Current Mileage fields against editing; disable the Generate Enquiry button, Save button, and Executive field | Prevents modification of key identity and calculation-driving fields on already-saved enquiries |
| BRC-028 | Discard Confirmation Before Clear | Validation | BR-027, BR-033 | Unsaved changes are present when the user activates Cancel | Show *"Entered data will not be Saved"* confirmation; clear only if confirmed | Prevents accidental loss of in-progress data entry |
| BRC-029 | Delete Confirmation | Validation | BR-028 | User activates the Delete action with changes pending | Show *"Are you sure to Delete"* confirmation; delete only if confirmed | Prevents accidental deletion of records |
| BRC-030 | TCS Not Applicable — Rate Buttons Disabled | Constraint | BR-015 | User selects "No" on the TCS applicability radio group | Set TCS applicability to not applicable; set description to "TCS Not Applied"; disable Normal Rate and Higher Rate buttons | Ensures TCS rate-selection buttons cannot be used when the user has declared TCS does not apply |
| BRC-031 | Tax Calculation Error at Commit | Validation | BR-026 | An exception occurs during insertion of charge lines from the staging table | Show *"Error... In Tax Calculation"* and abort the commit | Prevents saving an enquiry with incomplete or corrupt tax/charge data |

**Total Business Rules Identified: 31**

---

## 6. Data Requirements

*This form captures MCP (Manufacturer's Comprehensive Protection) enquiry header details against a registered vehicle and owner, records line-item service coverage (labour, parts, consumables) from the applicable package rate, and stores TCS applicability against the enquiry. Reference data is drawn from package master, employee, and GST configuration lookups.*

### 6.1 Business Entities and Relationships

*The two core persisted entities are the MCP enquiry header (one record per enquiry, linked to a registered vehicle) and the MCP enquiry detail lines (one row per service item covered by the package). A temporary charge staging table holds package-level tax/charge lines generated at save time.*

#### MCP Enquiry Header — VH_AMC_ENQ

The MCP Enquiry Header stores the core attributes of a single MCP enrolment enquiry: the vehicle's registration number, chassis, engine, model and variant details, customer identity and address, the chosen MCP package with its validity dates, billing amounts (package total, labour, parts, consumables, discounts, taxes), TCS applicability, and the enquiry's own unique document number and date. A record in this entity represents one attempt to enrol a vehicle in an MCP programme at a specific dealership location. The form both creates new header records (new enquiry) and retrieves existing ones (query-by-enquiry-number mode).

#### MCP Enquiry Detail Lines — VD_AMC_ENQ

The MCP Enquiry Detail Lines store the itemised breakdown of the package selected for the enquiry: individual labour operations, replacement parts, and consumable items, each with their quantity, rate, discount, net amount, and associated service category and group descriptions. These lines are generated from the package rate master and saved alongside the header at commit time. This entity is presented in a tabular screen section labelled "Details".

#### Enquiry Charge Lines — VD_AMC_ENQCHARGES

The Enquiry Charge Lines hold the tax and surcharge components computed for each detail line at the point of saving the enquiry. This table is populated by an insert-from-select operation that sources rows from the pre-computed temporary charge staging table (`GBL_AMC_CHARGES`). It is a child of the detail-line entity and is not directly displayed on screen.

#### Entity Relationships

The MCP Enquiry Header is the root entity for a given enquiry. Each header record has one or more MCP Enquiry Detail Lines describing its coverage items. Each detail line in turn may have one or more Enquiry Charge Lines recording the tax/surcharge breakdown.

```
VH_AMC_ENQ (MCP Enquiry Header)
        └── VD_AMC_ENQ (MCP Enquiry Detail Lines)
                └── VD_AMC_ENQCHARGES (Enquiry Charge Lines — populated at save)
```

### 6.2 Data Capture Requirements

*Data is captured in two main phases: the enquiry search/identification step (enquiry number or new entry), and the full header+detail entry phase for a new enquiry. Reference lookups (package, executive) and system-derived fields (vehicle details, validity dates, amounts) are loaded automatically or picked from LOVs.*

#### Enquiry Search (Search by Enquiry Number or New Entry)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Enquiry Number (`NB_ENQ_NUM`) | Conditional | The unique document number for an existing MCP enquiry, entered when retrieving a previously saved record. Leave blank to start a new enquiry. | When entered, must match a saved enquiry record for the current dealer, location, and company; shows *"MCP Enquiry Number Not Found"* if not found; shows *"Width problem/Incompatible data"* on a type mismatch |

#### Vehicle and Customer Details (New Enquiry — Header Entry)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Enquiry Date (`ENQ_DATE`) | Yes | The date and time the MCP enquiry is being raised; format DD-MM-RRRR HH24:MI | Must be a valid date; error *"Entered Date is not valid Date"* or *"Enter the Date in the proper format (DD-MM-YYYY)"* shown if invalid |
| Registration Number (`REG_NUM`) | Yes | The vehicle's licence plate / registration number, used to look up all vehicle and owner information | Must contain only uppercase letters and digits (non-conforming characters are stripped); must match exactly one record in the vehicle master — *"Registration Number Not Found"* if absent, *"More than one Registration Number found for \<value\>"* if ambiguous; *"Execution failed while retrieving Registration No. \<SQLERRM\>"* on a database error; vehicle age/mileage eligibility is then validated |
| VIN (`VIN`) | Auto-populated | Vehicle Identification Number resolved from the registration number look-up | Auto-populated; not user-entered |
| Vehicle Model (`SVAR_CD`) | Auto-populated | Sub-variant model code resolved from the vehicle master | Auto-populated |
| Vehicle Variant (`VARIANT_CD`) | Auto-populated | Variant code resolved from the vehicle master | Auto-populated |
| Chassis Number (`CHASSIS_NUM`) | Auto-populated | Chassis number from the vehicle master | Auto-populated |
| Engine Number (`ENGINE_NUM`) | Auto-populated | Engine number from the vehicle master | Auto-populated |
| Current Mileage (`ODOMETER_READING`) | Yes | The vehicle's current odometer reading at the time of enquiry | Must not be blank; must not be less than the previous service mileage (note *"Current Mileage cannot be less than Previous Service Mileage \<previous value\>"*); must not exceed the maximum validity mileage configured for the principal (*"Milease expired, So Vehicle can not be considered for MCP"*); vehicle sale date window must be within the configured period (*"Enquiry for a vehicle can be generated within 4yrs of vehicle sale"*); if no applicable package is found for the entered mileage/age/run combination, status is set to *"Applicable Package Not Found"* |
| Customer ID (`CUST_CD`) | Auto-populated | Customer party code resolved from the vehicle master | Auto-populated |
| Customer Name (`CUST_NAME`) | Auto-populated | Customer name from the vehicle/customer master | Auto-populated |
| Address Line 1 (`CUST_ADDR1`) | Auto-populated | First line of customer address | Auto-populated |
| Address Line 2 (`CUST_ADDR2`) | Auto-populated | Second line of customer address | Auto-populated |
| Address Line 3 (`CUST_ADDR3`) | Auto-populated | Third line of customer address | Auto-populated |
| City (`CITY_CD`) | Auto-populated | Customer city code | Auto-populated |
| City Description (`CITY_DESC`) | Auto-populated | Customer city name | Auto-populated |
| Contact Number (`PHONE`) | Auto-populated | Customer work/contact phone number | Auto-populated |
| Mobile (`MOBILE`) | Auto-populated | Customer mobile number | Auto-populated |
| Email (`EMAIL`) | Auto-populated | Customer email address | Auto-populated |
| Executive (`EMP_CD`) | Conditional | Service executive code assigned to the enquiry; selected from a list of active executives at the dealer location | Mandatory when creating a new enquiry (blank not allowed); optional on retrieval (enquiry number entered); picked from LOV_EXEC (active dealer-location executives) |
| Vehicle Sale Date (`SALE_DT`) | Auto-populated | Vehicle invoice/sale date (display format dd/mm/yy), used for package validity calculation | Auto-populated from vehicle master |
| GST Type (`RG_GSTTYPE`) | Auto-populated / Conditional | GST applicability type (IGST or SGST/CGST) determined from the dealer and customer state codes | Automatically set by the system; editable only when dealer and customer states differ and customer is not SEZ; locked to read-only when the enquiry number is already saved |
| State Description (`STATE_DESC`) | Auto-populated | Customer GST state name and code | Auto-populated |
| TCS Applicability (`TCS_APPL_YN`) | Conditional | Whether Tax Collected at Source applies, set via the TCS screen flow | Set by the system through TCS rate selection; not directly entered on the main screen |

#### MCP Package Selection

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Applicable Package (`PKG_CODE`) | Yes | The MCP package code selected for the vehicle; chosen from a list of valid packages for the vehicle's model, mileage, age, and average run | Must not be blank; selected from LOV_PACKAGE; package validity end date is automatically calculated after selection |
| Package Description (`PKG_DESC`) | Auto-populated | Package description resolved from the package master | Auto-populated |
| Validity Start Date (`VAL_FROM_DT`) | Auto-populated | MCP coverage start date (defaults to the enquiry date) | Auto-populated |
| Validity End Date (`VAL_TO_DT`) | Auto-populated | MCP coverage end date, calculated from the package expiry months and vehicle average run | Auto-populated; calculation uses the vehicle's average daily run and package mileage limit versus the standard month-based expiry |
| Upto Vehicle Age (`EXPIRY_MONTH`) | Auto-populated | Maximum vehicle age in months covered by the package | Auto-populated from package master |
| Upto Mileage (`EXPIRY_MILEAGE`) | Auto-populated | Maximum mileage limit for the package | Auto-populated from package master |
| Package Amount (`PKG_AMT`) | Auto-populated | Total package amount (sum of all detail lines after applying discounts and taxes) | Auto-populated from package rate master after Generate Enquiry; format 99999999999.99 |
| Labour Amount (`LABOUR_AMT`) | Auto-populated | Labour component total | Auto-populated; format 99999999999.99 |
| Parts Amount (`PART_AMT`) | Auto-populated | Parts component total | Auto-populated; format 99999999999.99 |
| Consumables Amount (`CONSUMABLE_AMT`) | Auto-populated | Consumables component total | Auto-populated; format 99999999999.99 |
| Discount Amount (`DISCOUNT_AMT`) | Auto-populated | Total discount on the package | Auto-populated; format 99999999999.99 |
| Net Amount (`TOT_BILL_AMT`) | Auto-populated | Total billing amount for the enquiry | Auto-populated; format 99999999999.99 |

#### MCP Detail Lines (Details Screen)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Type (`SRV_TYPE`) | Auto-populated | Service type code: L = Labour, P = Parts, C = Consumables | Auto-populated from package rate master |
| Code (`SRV_CODE`) | Auto-populated | Service operation code or part number | Auto-populated |
| Service Description (`NB_SRV_DESC`) | Auto-populated | Operation or part description resolved from the service/part master | Auto-populated |
| Qty (`QTY`) | Auto-populated | Quantity from the package rate master; format 99999.99 | Auto-populated |
| Disc % (`DISCOUNT_PER`) | Auto-populated | Discount percentage; format 99999.99 | Auto-populated |
| Rate (`RATE`) | Auto-populated | Unit rate; format 99999999999.99 | Auto-populated |
| Basic Amt (`BASIC_AMT`) | Auto-populated | Gross amount before discount; format 99999999999.99 | Auto-populated |
| Disc Amt (`DISCOUNT_AMT`) | Auto-populated | Discount value; format 99999999999.99 | Auto-populated |
| Net Amt (`NET_AMT`) | Auto-populated | Net amount after discount; format 99999999999.99 | Auto-populated |
| Charge Amt (`CHARGE_AMT`) | Auto-populated | Tax/charge component computed at save; format 99999999999.99 | Auto-populated via SP_INSERT_CHARGES at commit |
| Category (`NB_CATG_DESC`) | Auto-populated | Category description for the service item | Auto-populated |
| Group Code (`GROUP_CD`) | Auto-populated | Group code for the service item | Auto-populated |
| Group Description (`NB_GROUP_DESC`) | Auto-populated | Group description | Auto-populated |

#### TCS Selection (TCS Screen)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| TCS Applicable (`NB_TCS_APPL_YN`) | Conditional | Radio group indicating whether the user declares TCS as applicable (Yes) or not applicable (No) for this enquiry | Required when the TCS screen is displayed; if the user selects "Yes", the Rate buttons (Normal and Higher) are enabled; if "No", TCS applicability is recorded as not applicable |
| TCS Rate Selection — Normal Rate | Conditional | Button pressed to apply TCS at the normal rate | Sets the system TCS flag to applicable with description "Normal Rate Applied"; available only after TCS radio is set to Yes |
| TCS Rate Selection — Higher Rate | Conditional | Button pressed to apply TCS at the higher rate | Sets the system TCS flag to applicable with description "Higher Rate Applied"; available only after TCS radio is set to Yes |

#### Session and Parameter Fields

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Parent Group (`GLOBAL.PARENT_GROUP`) | Auto-populated | OEM / parent group code for the current session | System-set from session context; stamped on every insert/update |
| Dealer Code (`GLOBAL.DEALER`) | Auto-populated | Dealer mapping code for the current session | System-set; used to filter all lookups to the current dealer |
| Location Code (`GLOBAL.LOC_CD`) | Auto-populated | Dealer location code | System-set |
| Company FA (`GLOBAL.COMP_FA`) | Auto-populated | Company financial area code | System-set |
| User ID (`GLOBAL.USERID`) | Auto-populated | Logged-in user identifier, stamped as created-by/modified-by | System-set |
| P_SAVE parameter (`PARAMETER.P_SAVE`) | Auto-populated | Internal flag set to 'Y' by the Save button before invoking the save trigger, reset to 'N' after | System-managed; not user-visible |

### 6.3 Reference Data

*Lists master and configuration data referenced by this form as look-up sources.*

| Reference Data | Business Purpose | Used When |
| :--- | :--- | :--- |
| Package Master (`RG_PACKAGE` / `LOV_PACKAGE`) | Provides the list of valid MCP packages available for the vehicle's model, mileage, age, and average run | When the user selects an MCP package for the enquiry |
| Executive List (`RG_EXEC` / `LOV_EXEC`) | Provides the list of active service executives at the current dealer location | When the user selects the executive assigned to the enquiry |
| Vehicle Master (`GM_VIN`) | Stores VIN, registration number, chassis, engine, sale date, last odometer reading, and model/variant codes for each vehicle | When the registration number is validated |
| Customer Master (`GM_CIN`) | Provides customer profile: name, address, city, phone, email, GST number, PAN, and SEZ flag | When vehicle details are loaded after registration number validation |
| Model (Sub-variant) Master (`VM_SVAR`) | Provides the model description for display | When a queried/retrieved record is displayed (POST-QUERY) |
| Variant Master (`GM_VAR`) | Provides the variant description and fuel type | When vehicle details are loaded and on POST-QUERY |
| Package Rate Master (`VM_AMC_RATE`) | Defines the rated service items (labour, parts, consumables) for a package/model/variant/fuel-type/city combination | When the Generate Enquiry action populates the detail lines (POP_PKG_DETAILS) |
| Pre-computed Package Detail (`GBL_AMC_DTL`) | Holds the calculated detail lines (with pricing, GST, TCS) generated by `PKG_AMC.SP_POP_PKG_DTL` | When POP_PKG_DETAILS_NEW loads detail lines after the package detail calculation |
| Pre-computed Charge Lines (`GBL_AMC_CHARGES`) | Holds the tax/surcharge components computed per detail line | When SP_INSERT_CHARGES copies charges to the enquiry at commit |
| MCP Validity Parameters (`VM_AMC_PARAM`) | Configures the maximum validity mileage and validity months for MCP eligibility | When current mileage is validated |
| Dealer Location Parameters (`AM_DEALER_LOC_PARAM`) | Controls whether MCP is active or deactivated for this dealer location | When the form opens, to check if MCP has been disabled |
| GST Implementation Date (`AM_LIST_RANGE` — `GST_IMP_DATE/GST`) | Determines whether to use the GST or pre-GST enquiry report template | When generating the enquiry report |
| MCP Enquiry Status Labels (`AM_LIST_RANGE` — `AMC_ENQSTATUS`) | Provides the human-readable status description for the enquiry | On POST-QUERY when displaying an existing enquiry |
| Service Category Types (`AM_LIST_RANGE` — `AMC_CATG_TYPE`) | Provides the category description for part/consumable detail lines | On POST-QUERY for B_VD_AMC_ENQ detail lines |
| Part Group Types (`AM_LIST_RANGE` — `PART_TYPE`) | Provides the group description for part detail lines | On POST-QUERY for B_VD_AMC_ENQ detail lines |
| Labour Operation Master (`VM_MSIL_OPR`) | Provides the operation description for labour-type service items | On POST-QUERY for B_VD_AMC_ENQ labour lines |
| Part Description Master (`PM_PART`) | Provides the part description for parts/consumables service items | On POST-QUERY for B_VD_AMC_ENQ non-labour lines |
| State Master (`GM_STATE`) | Provides GST state code and description for the customer state | After registration number validation and on POST-QUERY |
| City Master (`GM_CITY`) | Provides city description for the customer city | On POST-QUERY |
| Document Number Master (`AM_DOCS`) — `PK_VALIDATE_BACK_DATE` | Generates and maintains the sequential MCP enquiry document number | When saving a new enquiry for the first time |
| MCP Package Model/Sub-variant (`VM_AMC_PKG` / `VM_AMC_PKG_MOD`) | Defines which models and sub-variants are eligible for each package | When the package LOV record group is populated and during mileage validation |
| Employee Master (`GM_EMP`) | Provides the executive name for display and the LOV list of active service executives | When executive is selected and on POST-QUERY |
| EW Certificate Report (`vr_ew_certificate.rdf`) | Extended warranty certificate report object defined in the form (EXTERNAL — not invoked in the active code path) | EXTERNAL / NOT IN BUNDLE — not currently called in active code |
| MCP Enquiry Report — Pre-GST (`vr_amc_enq`) | Report template for MCP enquiry certificates dated before the GST implementation date | When the user prints an existing enquiry where the enquiry date is before the GST date |
| MCP Enquiry Report — GST (`vr_amc_enq_gst`) | Report template for MCP enquiry certificates for enquiries dated on or after the GST implementation date | When the user prints an existing enquiry where the enquiry date is on or after the GST date |

### 6.4 Data Lifecycle

*Describes how records are created, updated, and saved within this form's evidenced behaviour.*

**Creation**

- A new MCP enquiry header record (`VH_AMC_ENQ`) is created when the user fills in a new enquiry (no enquiry number entered on load) and clicks Save. The system first generates a unique sequential document number via `PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM`, then commits the record.
- MCP Enquiry Detail Lines (`VD_AMC_ENQ`) are created alongside the header at the same commit. They are pre-populated from the package rate master or the pre-computed detail staging table before the commit is executed.
- Enquiry Charge Lines (`VD_AMC_ENQCHARGES`) are inserted in the same commit transaction by `SP_INSERT_CHARGES`, which selects from `GBL_AMC_CHARGES` for the same enquiry context.
- The `PRE-INSERT` triggers on both `VH_AMC_ENQ` and `VD_AMC_ENQ` stamp the session context values (parent group, dealer, location, company FA, created-by user, created date) onto each new row immediately before the insert is executed.

**Updates**

- An existing enquiry is updated when the user retrieves it by enquiry number, modifies editable fields, and saves. The `PRE-UPDATE` triggers on both `VH_AMC_ENQ` and `VD_AMC_ENQ` stamp the modified-by user and modified date onto the row before the update is executed.
- When an existing enquiry is retrieved (enquiry number mode), the Registration Number, Current Mileage, and Enquiry Number fields are locked to prevent modification; the Generate Enquiry button is also disabled.

**Save and Commit**

- Saving is user-initiated via the Save button (or the framework Key-Commit shortcut), which invokes the `FT_SAVE` trigger. The form first checks that the package amount is populated; if not, it shows *"Please generate enquiry"* and stops.
- If the enquiry number field is empty (new record), `FT_SAVE` calls `PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM` to obtain the next sequential document number. On failure, the error message from the procedure is displayed and the save is aborted.
- After the document number is assigned, the `KEY-COMMIT` trigger fires: `SP_INSERT_CHARGES` is called to insert the charge lines, then `COMMIT_FORM` persists all changes. After a successful commit, the system displays *"MCP Enquiry Number generated is \<enquiry number\>"* and automatically prints the enquiry report via `CALL_REPORT_ENQ`.

**Retention and Audit**

- Created-by user and created date are stamped at insert time by the `PRE-INSERT` triggers on both header and detail blocks; these fields are not user-editable.
- Modified-by user and modified date are stamped at update time by the `PRE-UPDATE` triggers on both blocks.
- No archival or purge policy is defined within this form.

---

## 7. Glossary

*Definitions of terms, abbreviations, and acronyms used throughout this document.*

The following table defines key terms, acronyms, and abbreviations used throughout this Business Requirements Document.

| Term | Definition | Aliases | Related Terms |
| :--- | :--- | :--- | :--- |
| AMC | Annual Maintenance Contract — a pre-paid vehicle service package covering scheduled labour, parts, and consumables for a defined period and mileage | Annual Maintenance Contract | MCP, Package |
| AMC Enquiry | A formal record created when a customer requests an AMC/MCP package for a vehicle; contains the header details, line items, and charge breakdown | Enquiry | MCP Enquiry, ENQ_NUM |
| Audit Trail | Created-by, created-date, modified-by, and modified-date fields automatically stamped on records to track data changes | — | Created By, Modified By |
| CGST | Central Goods and Services Tax — the central government component of intra-state GST applied when the dealer and customer are in the same state | — | GST, SGST, IGST |
| Charge Template | Pre-defined tax and fee charge rows stored for each dealer and package combination that are inserted into the enquiry charges table at commit | — | Charges, VD_AMC_ENQCHARGES |
| City RPH | City Revenue Per Hour category — a dealer-location classification used to determine applicable AMC package rates | — | City Category, Package |
| Comp FA | Company Financial Area — the company dimension code used to scope all AMC and dealer records | Company FA | COMP_FA, Dealer |
| Consumables | Vehicle service consumables (e.g. oils, filters) included as a line-item type in the AMC package breakdown | — | Labour, Parts, SRV_TYPE |
| Dealer | The vehicle dealership identified by a dealer mapping code (DEALER_MAP_CD) under the parent group | Dealership | Dealer Map Code, Location |
| DMS | Dealer Management System — the integrated software platform for dealership operations in which the vt_amc_enq form operates | — | Oracle Forms, System |
| Document Master | The AM_DOCS table used to store and lock document number counters for each dealer, location, company, document type, and financial year combination | AM_DOCS | Document Number, Sequential Number |
| ENQ_NUM | AMC enquiry number — the unique, sequentially generated document identifier assigned to each AMC enquiry record at save | Enquiry Number | AMC Enquiry, Document Number |
| Financial Year | The fiscal year period used to scope document number sequencing; stored as P_FIN_YR | Fin Year | P_FIN_YR, Document Master |
| GST | Goods and Services Tax — the Indian indirect tax applied to AMC package amounts; categorised as SGST/CGST (intra-state) or IGST (inter-state) | — | SGST, CGST, IGST, GST Type |
| GST Type | Classification of GST applicable to the enquiry: S = SGST/CGST (same state), I = IGST (different state or SEZ) | — | GST, SGST, CGST, IGST |
| HSN/SAC Code | Harmonised System of Nomenclature / Service Accounting Code — the GST classification code assigned to each service item in the package breakdown | HS Code, SAC Code | GST, Line Item |
| IGST | Integrated Goods and Services Tax — the tax applied when the dealer and customer are in different states, or when the customer is in a Special Economic Zone | — | GST, SGST, CGST |
| Labour | Vehicle service labour operations included as line-item type L in the AMC package breakdown | Operations | Consumables, Parts, SRV_TYPE |
| LOC_CD | Location code — identifies the specific dealership outlet within the dealer group for scoping enquiry records | Location Code | Dealer, COMP_FA |
| LOV | List of Values — a dropdown selection popup used in Oracle Forms; used in vt_amc_enq for package and executive selection | Dropdown, Picklist | RG_PACKAGE, RG_EXEC |
| MCP | Maintenance Care Package — the product category for pre-paid vehicle service packages sold via this form | Maintenance Care Package | AMC, Package |
| Odometer Reading | The current vehicle mileage reading entered by the service advisor; validated against the previous service mileage and the package mileage limit | Current Mileage | Vehicle Eligibility |
| PAN | Permanent Account Number — the Indian tax identification number used to determine the applicable TCS rate | PAN Number | TCS, Aadhaar |
| Parent Group | The principal group code (PARENT_GROUP) used as the top-level organisational scope for all enquiry records | Principal Group | Principal, COMP_FA |
| Parts | Vehicle spare parts included as line-item type P in the AMC package breakdown | Spare Parts | Labour, Consumables, SRV_TYPE |
| Principal | The vehicle manufacturer mapping code (PRINCIPAL_MAP_CD) used to scope master data lookups for vehicle, variant, and package records | Principal Map Code | Parent Group, Dealer |
| Registration Number | The vehicle registration plate number (REG_NUM) entered by the service advisor as the primary vehicle identifier | Reg Num, Vehicle Reg | VIN, Vehicle |
| RPH | Revenue Per Hour — a service pricing category used in the city RPH classification for AMC rate determination | — | City RPH, AMC Rate |
| SEZ | Special Economic Zone — a customer classification that forces IGST to apply regardless of state comparison | Special Economic Zone | IGST, GST Type |
| SGST | State Goods and Services Tax — the state government component of intra-state GST applied when the dealer and customer are in the same state | — | GST, CGST, IGST |
| SRV_TYPE | Service type code used to classify AMC detail line items: L = Labour, P = Parts, C = Consumables | Service Type | Labour, Parts, Consumables |
| Sub-Variant | A vehicle sub-variant code (SVAR_CD) used to match the vehicle to applicable AMC packages and rates | SVAR | Variant, Package |
| TCS | Tax Collected at Source — an Indian tax collected by the seller when aggregate sales to a buyer exceed 50 lakhs; applicable at normal rate (0.075%–0.1%) or higher rate (1%) | Tax Collected at Source | PAN, Aadhaar, TCS_APPL_YN |
| VIN | Vehicle Identification Number — the unique manufacturer-assigned identifier for each vehicle; used in eligibility validation | Vehicle Identification Number | Registration Number, Vehicle |

---

---

## 8. Technical Inventory

*Complete inventory of Oracle Forms components including blocks, items, triggers, canvases, and global variables.*

### 8.1 Form Architecture

**Form Module Details:**

- Form Name: vt_amc_enq (VT_AMC_ENQ)
- Form Module XML Title: MODULE2
- Oracle Forms Version: 12c (Module version 122010400)
- Parent Object Library: DPL.olb (PC_FORM property class)
- Attached Libraries: WEBUTIL (webutil.olb), DPL (DPL.pld program library), D2KWUTIL
- First Navigation Block: -
- Console Window: WN_MAIN — MCP Enquiry Generation (Rel: 1.2.4)
- Compile Dependencies: Requires DPL.olb, DPL.pld, WEBUTIL.olb, database packages PKG_AMC, PK_VALIDATE_BACK_DATE
- Source artifacts: `vt_amc_enq_fmb.xml`; OLB `DPL.olb`; WEBUTIL (webutil.olb); DPL (DPL.pld program library); D2KWUTIL; PCK `PKG_AMC.pck`; PCK `PK_VALIDATE_BACK_DATE.pck`

### 8.1.1 Global Variables

| Global Variable | Data Type | Set Location | Purpose |
| :--- | :--- | :--- | :--- |
| APP_LOG | Char | Trigger | Application logging flag; when set to `Y`, performance timing is recorded |
| COMP_FA | Char | ProgramUnit / Trigger | Company financial area code used to filter enquiry and AMC records |
| CURRENCY | Char | Trigger | Currency symbol displayed in monetary fields across the form |
| DEALER | Char | ProgramUnit / RecordGroup / Trigger | Dealer mapping code used to scope vehicle, package, and employee lookups |
| FIN_BEG | Char | Trigger | Financial year start date used for transaction period validation |
| FIN_END | Char | Trigger | Financial year end date used for transaction period validation |
| LOC_CD | Char | ProgramUnit / RecordGroup / Trigger | Location code used to filter records and validate dealer-specific data |
| PARENT_GROUP | Char | ProgramUnit / Trigger | Parent group code used to scope all enquiry and AMC records for the current principal group |
| PRINCIPAL | Char | ProgramUnit / RecordGroup / Trigger | Principal mapping code identifying the vehicle manufacturer context for this session |
| PRINTOUTPUT | Char | ProgramUnit | Report output file name passed to the print delivery mechanism after report generation |
| P_FIN_YR | Char | Trigger | Current financial year number used when generating the AMC enquiry document number |
| REPORTHANDLE | Char | ProgramUnit | Report object job handle returned after the report is submitted to the report server |
| REP_SERVER | Char | ProgramUnit | Report server name used to submit report jobs at print time |
| TALLY_INTEGRATION | Char | Trigger | Flag indicating whether Tally accounting integration is active for this session |
| USERID | Char | ProgramUnit / Trigger | Logged-in user identifier stamped on created-by and modified-by audit fields |
| USER_NAME | Char | Trigger | Full display name of the logged-in user shown in the form header |

### 8.1.2 Form Parameters

*All 7 ModuleParameter entries from vt_amc_enq_fmb.xml.*

| Parameter | Data Type | Default | Description |
| :--- | :--- | :--- | :--- |
| P_QUERY | Char | N | Set to `Y` after a successful query execution to indicate that records have been fetched into the form |
| P_OKFOR_SAVE | Char | N | Reserved — not used in current form logic |
| P_SAVE | Char | N | Set to `Y` by the Save button before calling the FT_SAVE trigger; controls the save flow |
| CLOSE | Char | N | Reserved — not used in current form logic |
| CHECK_NEW | Char | Y | Controls whether new item/record checks are performed when navigating the enquiry block |
| NEW_ITEM | Char | Y | Indicates whether the form is in new-item entry mode; used to control navigation and validation |
| NEW_REC | Char | N | Set to `Y` by PRE-INSERT when a new record is being created; controls enquiry number generation |

**Total Parameters:** 7

### 8.2 Blocks

| Block Name | Query Data Source | Records | Q/I/U/D | Key Mode | Master-Detail Relationship |
| :--- | :--- | :--- | :--- | :--- | :--- |
| PB_BLK | - | 1 | N/N/N/N | Default | Toolbar / push-button control block — hosts the inherited toolbar action buttons (Save, Cancel, Delete, Print, etc.) |
| CB_ERR | - | 1 | N/N/N/N | Default | Error display control block — hosts the error message text item (TXT_ERR) shown on the error canvas CN_ERR |
| CB_VT_AMC_ENQ | - | 1 | N/N/N/N | Default | Control — entry point for enquiry number search |
| B_VH_AMC_ENQ | VH_AMC_ENQ | 1 | Y/Y/Y/N | Delayed | Detail of CB_VT_AMC_ENQ via ENQ_NUM |
| B_VD_AMC_ENQ | VD_AMC_ENQ | 20 | Y/Y/Y/N | Delayed | Detail of CB_VT_AMC_ENQ via ENQ_NUM |
| B_TCS | - | 1 | N/N/N/N | Default | Control — TCS rate selection panel for the enquiry |

**Total Blocks:** 6 blocks

### 8.2.1 Block WhereClause and OrderByClause

*Block query scope from vt_amc_enq_fmb.xml. **Description** explains filter and sort in business terms; **Order By** and **Where Clause** columns retain verbatim XML text for migration.*

| Block | Description | Order By (XML) | Where Clause (XML) |
| :--- | :--- | :--- | :--- |
| B_VH_AMC_ENQ | Retrieves the AMC enquiry header record matching the entered enquiry number for the current dealer, location, and company | - | parent_group  = :global.parent_group   and dealer_map_cd = :global.dealer  and loc_cd  = :global.loc_cd  and comp_fa =:global.comp_fa  and enq_num = :CB_VT_AMC_ENQ.NB_ENQ_NUM |
| B_VD_AMC_ENQ | Retrieves all AMC enquiry detail line items for the entered enquiry number, scoped to the current dealer and location, excluding serial zero | - | parent_group  = :global.parent_group   and dealer_map_cd = :global.dealer  and loc_cd  = :global.loc_cd  and comp_fa =:global.comp_fa  and enq_num = :CB_VT_AMC_ENQ.NB_ENQ_NUM and srl_num > 0 |

### 8.3 Items Summary

*Complete item inventory from `vt_amc_enq_fmb.xml`.*

**Block counts:**

*Database / non-database counts derived from XML.*

| Block | Total Items | Database Items | Non-Database Items |
| :--- | ---: | ---: | ---: |
| PB_BLK | 14 | 0 | 14 |
| CB_ERR | 1 | 0 | 1 |
| CB_VT_AMC_ENQ | 9 | 0 | 9 |
| B_VH_AMC_ENQ | 75 | 38 | 37 |
| B_VD_AMC_ENQ | 27 | 22 | 5 |
| B_TCS | 1 | 0 | 1 |
| **Total** | **127** | **60** | **67** |

**Item detail (all 127 items):**

| Block | Item Name | DatabaseItem | Description |
| :--- | :--- | :--- | :--- |
| PB_BLK | PB_BACK | false | Back button (inherited) — navigates back to the CB_VT_AMC_ENQ control block |
| PB_BLK | PB_ERR_OK | false | Error OK button (inherited) — dismisses the error dialog on the CN_ERR canvas |
| PB_BLK | PB_ERR_EXIT | false | Error Exit button (inherited) — closes the error dialog and exits the error canvas |
| PB_BLK | PB_PASTE | false | Paste button (inherited) — clipboard paste action |
| PB_BLK | PB_COPY | false | Copy button (inherited) — clipboard copy action |
| PB_BLK | PB_CUT | false | Cut button (inherited) — clipboard cut action |
| PB_BLK | PB_PRINT | false | Print button (inherited) — invokes FT_PRINT to submit the AMC enquiry report |
| PB_BLK | PB_SAVE | false | Save button (inherited) — sets P_SAVE to Y and executes the FT_SAVE trigger |
| PB_BLK | PB_CANCEL | false | Cancel button (inherited) — sets P_SAVE to N and executes FT_CANCEL |
| PB_BLK | PB_DEL | false | Delete button (inherited) — executes FT_DEL to delete the current record after confirmation |
| PB_BLK | PM_CONT | false | Continue button (inherited) — navigates back to the CB_VT_AMC_ENQ control block |
| PB_BLK | PB_INSERT | false | Insert button (inherited) — not active in this form (FT_INSERT is commented out) |
| PB_BLK | PB_LIST | false | LOV List button (inherited) — opens the LOV for the current item |
| PB_BLK | PB_EXIT | false | Exit button (inherited) — clears application session info and exits the form |
| CB_ERR | TXT_ERR | false | Error message display text item — shows error message text on the CN_ERR error canvas |
| CB_VT_AMC_ENQ | NB_ENQ_NUM | false | AMC enquiry number entry field; user enters or searches this to load an existing enquiry |
| CB_VT_AMC_ENQ | COPY_RIGHT | false | Copyright display label shown at the top of the form |
| CB_VT_AMC_ENQ | STATUS | false | **INACTIVE** — display-only status text field; disabled in the UI |
| CB_VT_AMC_ENQ | PB_GEN_ENQ | false | Generate Enquiry button — validates vehicle and populates AMC package details |
| CB_VT_AMC_ENQ | PB_DTL | false | Details button — navigates to the enquiry detail block |
| CB_VT_AMC_ENQ | NB_STATUS | false | **INACTIVE** — non-database status indicator; disabled in the UI |
| CB_VT_AMC_ENQ | PB_TCS_APPLY | false | Generate Enquiry (TCS flow) button — navigates to TCS approval step after rate selection |
| CB_VT_AMC_ENQ | PB_TCS_RATE_N | false | Normal Rate button — sets TCS rate to normal (0.075%/0.1%) for the current enquiry |
| CB_VT_AMC_ENQ | PB_TCS_RATE_H | false | Higher Rate button — sets TCS rate to higher rate (1%) when PAN/Aadhaar is unavailable |
| B_VH_AMC_ENQ | PARENT_GROUP | true | Principal group code — organisational scope key stamped on enquiry records |
| B_VH_AMC_ENQ | DEALER_MAP_CD | true | Dealer mapping code — identifies the dealership that created the enquiry |
| B_VH_AMC_ENQ | LOC_CD | true | Location code — dealership location for this AMC enquiry |
| B_VH_AMC_ENQ | COMP_FA | true | Company financial area code — company context for this enquiry |
| B_VH_AMC_ENQ | ENQ_NUM | false | AMC enquiry number — system-generated document identifier displayed on the form |
| B_VH_AMC_ENQ | ENQ_DATE | false | **INACTIVE** — enquiry date display field; disabled in the UI |
| B_VH_AMC_ENQ | REG_NUM | true | Vehicle registration number — primary vehicle identifier entered by the user |
| B_VH_AMC_ENQ | VIN | true | Vehicle Identification Number — auto-populated from vehicle master after registration number validation |
| B_VH_AMC_ENQ | VARIANT_CD | true | Vehicle variant code — auto-populated from vehicle master |
| B_VH_AMC_ENQ | CHASSIS_NUM | true | Vehicle chassis number — auto-populated from vehicle master |
| B_VH_AMC_ENQ | ENGINE_NUM | true | Vehicle engine number — auto-populated from vehicle master |
| B_VH_AMC_ENQ | SVAR_CD | true | Sub-variant code — auto-populated from vehicle master for package eligibility |
| B_VH_AMC_ENQ | ODOMETER_READING | true | Current odometer reading entered by user; validated against previous service mileage |
| B_VH_AMC_ENQ | EMP_CD | false | Employee (service advisor) code selected from the executives LOV |
| B_VH_AMC_ENQ | CUST_CD | true | Customer code — auto-populated from vehicle master |
| B_VH_AMC_ENQ | CUST_NAME | true | Customer name — auto-populated from vehicle master |
| B_VH_AMC_ENQ | CUST_ADDR1 | true | **INACTIVE** — customer address line 1; disabled in the UI |
| B_VH_AMC_ENQ | CUST_ADDR2 | true | **INACTIVE** — customer address line 2; disabled in the UI |
| B_VH_AMC_ENQ | CUST_ADDR3 | true | **INACTIVE** — customer address line 3; disabled in the UI |
| B_VH_AMC_ENQ | CITY_CD | true | **INACTIVE** — customer city code; disabled in the UI |
| B_VH_AMC_ENQ | CITY_DESC | false | Customer city description — auto-populated from city master after validation |
| B_VH_AMC_ENQ | PHONE | true | **INACTIVE** — customer phone number; disabled in the UI |
| B_VH_AMC_ENQ | MOBILE | true | **INACTIVE** — customer mobile number; disabled in the UI |
| B_VH_AMC_ENQ | ENQ_STATUS | true | **INACTIVE** — enquiry status code; disabled in the UI |
| B_VH_AMC_ENQ | CREATED_BY | true | Audit field — user ID who created the enquiry record |
| B_VH_AMC_ENQ | CREATED_DATE | true | Audit field — date and time the enquiry record was created |
| B_VH_AMC_ENQ | MODIFIED_BY | true | Audit field — user ID who last modified the enquiry record |
| B_VH_AMC_ENQ | MODIFIED_DATE | true | Audit field — date and time of last modification |
| B_VH_AMC_ENQ | NB_MODEL_DESC | false | Vehicle model description — auto-populated from sub-variant master after query |
| B_VH_AMC_ENQ | NB_VARIANT_DESC | false | Vehicle variant description — auto-populated from variant master after query |
| B_VH_AMC_ENQ | NB_COLOUR_CD | false | **INACTIVE** — vehicle colour code display; disabled in the UI |
| B_VH_AMC_ENQ | NB_COLOUR_DESC | false | Vehicle colour description — auto-populated from colour master after query |
| B_VH_AMC_ENQ | VAL_FROM_DT | true | **INACTIVE** — AMC validity start date; disabled in the UI |
| B_VH_AMC_ENQ | VAL_TO_DT | true | **INACTIVE** — AMC validity expiry date; calculated and displayed but disabled |
| B_VH_AMC_ENQ | PKG_CODE | true | AMC package code selected from the applicable package LOV |
| B_VH_AMC_ENQ | EXPIRY_MONTH | false | **INACTIVE** — package expiry period in months; disabled in the UI |
| B_VH_AMC_ENQ | PKG_DESC | false | Package description — auto-populated from package master after package code selection |
| B_VH_AMC_ENQ | EXPIRY_MILEAGE | false | **INACTIVE** — package expiry mileage limit; disabled in the UI |
| B_VH_AMC_ENQ | PKG_AMT | true | Total AMC package amount calculated after package population |
| B_VH_AMC_ENQ | LABOUR_AMT | true | **INACTIVE** — labour component of the package amount; disabled in the UI |
| B_VH_AMC_ENQ | PART_AMT | true | **INACTIVE** — parts component of the package amount; disabled in the UI |
| B_VH_AMC_ENQ | CONSUMABLE_AMT | true | **INACTIVE** — consumables component of the package amount; disabled in the UI |
| B_VH_AMC_ENQ | DISCOUNT_AMT | true | **INACTIVE** — discount amount applied to the package; disabled in the UI |
| B_VH_AMC_ENQ | SRV_TAX_AMT | true | **INACTIVE** — service tax amount on the package (legacy field); disabled in the UI |
| B_VH_AMC_ENQ | SBC_TAX_AMT | false | **INACTIVE** — Swachh Bharat Cess amount (legacy field); disabled in the UI |
| B_VH_AMC_ENQ | KKC_TAX_AMT | false | **INACTIVE** — Krishi Kalyan Cess amount (legacy field); disabled in the UI |
| B_VH_AMC_ENQ | TOT_BILL_AMT | true | **INACTIVE** — total billing amount (legacy field); disabled in the UI |
| B_VH_AMC_ENQ | NB_ODOMETER_READING | false | Previous service mileage — auto-populated from vehicle history for validation |
| B_VH_AMC_ENQ | NB_AVG_RUN | false | Average mileage run per year — calculated from vehicle age and odometer history |
| B_VH_AMC_ENQ | NB_VEH_AGE | false | Vehicle age in years — calculated from sale date to current date |
| B_VH_AMC_ENQ | NB_CITY_CATG | false | City RPH category for the dealership — used for package eligibility determination |
| B_VH_AMC_ENQ | NB_FUELTYPE | false | Vehicle fuel type — auto-populated from variant master for package filtering |
| B_VH_AMC_ENQ | NB_VEH_SALE_DT | false | **INACTIVE** — vehicle sale date display; disabled in the UI |
| B_VH_AMC_ENQ | NB_AMC_TYPE | false | AMC type identifier for the selected package |
| B_VH_AMC_ENQ | EMAIL | true | **INACTIVE** — customer email address; disabled in the UI |
| B_VH_AMC_ENQ | NB_TOT_BILL_AMT | false | **INACTIVE** — non-database total bill amount display; disabled in the UI |
| B_VH_AMC_ENQ | SALE_DT | false | Vehicle sale date — auto-populated from vehicle master for eligibility calculation |
| B_VH_AMC_ENQ | RG_GSTTYPE | false | GST type radio group — indicates whether SGST/CGST (same state) or IGST (inter-state) applies |
| B_VH_AMC_ENQ | CUST_STATE_CD | true | Customer GST state code — populated after GST type determination |
| B_VH_AMC_ENQ | CUST_SEZ | true | Customer SEZ flag — indicates whether customer is in a Special Economic Zone |
| B_VH_AMC_ENQ | DLR_STATE_CD | true | Dealer GST state code — populated from dealer location master |
| B_VH_AMC_ENQ | NB_LBR_DISC | false | **INACTIVE** — non-database labour discount amount; disabled in the UI |
| B_VH_AMC_ENQ | NB_PART_DISC | false | **INACTIVE** — non-database parts discount amount; disabled in the UI |
| B_VH_AMC_ENQ | NB_CONS_DISC | false | **INACTIVE** — non-database consumables discount amount; disabled in the UI |
| B_VH_AMC_ENQ | NB_LBR_TAX | false | **INACTIVE** — non-database labour tax amount; disabled in the UI |
| B_VH_AMC_ENQ | NB_PART_TAX | false | **INACTIVE** — non-database parts tax amount; disabled in the UI |
| B_VH_AMC_ENQ | NB_CONS_TAX | false | **INACTIVE** — non-database consumables tax amount; disabled in the UI |
| B_VH_AMC_ENQ | NB_LBR_NET | false | **INACTIVE** — non-database labour net amount; disabled in the UI |
| B_VH_AMC_ENQ | NB_PART_NET | false | **INACTIVE** — non-database parts net amount; disabled in the UI |
| B_VH_AMC_ENQ | NB_CONS_NET | false | **INACTIVE** — non-database consumables net amount; disabled in the UI |
| B_VH_AMC_ENQ | NB_TAX_AMT | false | **INACTIVE** — non-database total tax amount; disabled in the UI |
| B_VH_AMC_ENQ | EMP_NAME | false | Employee name — auto-populated from employee master after EMP_CD validation |
| B_VH_AMC_ENQ | STATE_DESC | false | **INACTIVE** — customer state description; disabled in the UI |
| B_VH_AMC_ENQ | TCS_APPL_YN | false | TCS applicability flag — set to `Y` (normal rate) or `H` (higher rate) by rate buttons |
| B_VH_AMC_ENQ | NBT_TCS_DESC | false | TCS description label — displays "Normal Rate Applied" or "Higher Rate Applied" |
| B_VD_AMC_ENQ | PARENT_GROUP | true | Principal group code — stamped on detail records at insert |
| B_VD_AMC_ENQ | DEALER_MAP_CD | true | Dealer mapping code — stamped on detail records at insert |
| B_VD_AMC_ENQ | LOC_CD | true | Location code — stamped on detail records at insert |
| B_VD_AMC_ENQ | COMP_FA | true | Company financial area code — stamped on detail records at insert |
| B_VD_AMC_ENQ | ENQ_NUM | false | AMC enquiry number — links the detail line to its header record |
| B_VD_AMC_ENQ | SRL_NUM | true | Serial number — line sequence within the enquiry (labour=1, parts=2, consumables=3) |
| B_VD_AMC_ENQ | SRV_TYPE | true | Service type code — `L` for labour, `P` for parts, `C` for consumables |
| B_VD_AMC_ENQ | SRV_CODE | true | Service item code — operation code or part number within the selected package |
| B_VD_AMC_ENQ | NB_SRV_DESC | false | Service item description — auto-populated from operation or part master after query |
| B_VD_AMC_ENQ | QTY | true | Quantity of the service item in the package |
| B_VD_AMC_ENQ | DISCOUNT_PER | true | Discount percentage applied to the service item |
| B_VD_AMC_ENQ | RATE | true | Unit rate for the service item |
| B_VD_AMC_ENQ | BASIC_AMT | true | Basic amount before discounts for the line item |
| B_VD_AMC_ENQ | DISCOUNT_AMT | true | Discount amount deducted from the basic amount |
| B_VD_AMC_ENQ | NET_AMT | true | Net amount after discount for the line item |
| B_VD_AMC_ENQ | CREATED_BY | true | Audit field — user ID who created the detail record |
| B_VD_AMC_ENQ | CREATED_DATE | true | Audit field — date and time the detail record was created |
| B_VD_AMC_ENQ | MODIFIED_BY | true | Audit field — user ID who last modified the detail record |
| B_VD_AMC_ENQ | MODIFIED_DATE | true | Audit field — date and time of last modification to the detail record |
| B_VD_AMC_ENQ | NB_CATG_DESC | false | Service category description — auto-populated from category master after query |
| B_VD_AMC_ENQ | CATG_CD | true | Service category code for the line item |
| B_VD_AMC_ENQ | GROUP_CD | true | Service group code for the line item |
| B_VD_AMC_ENQ | NB_NET_AMT | false | Non-database net amount display field for the line item |
| B_VD_AMC_ENQ | NB_GROUP_DESC | false | Service group description — auto-populated from group master after query |
| B_VD_AMC_ENQ | HSN_SAC_CODE | true | HSN/SAC code for GST classification of the service item |
| B_VD_AMC_ENQ | SELL_PRICE | true | Selling price for the service item used in charge calculation |
| B_VD_AMC_ENQ | CHARGE_AMT | true | Charge amount calculated for the service item including taxes |
| B_TCS | NB_TCS_APPL_YN | false | TCS confirmation radio button — user confirms whether TCS is applicable for the sale |

### 8.4 List of Values

| LOV Name | Title | Record Group | Attached Block.Item |
| :--- | :--- | :--- | :--- |
| LOV_PACKAGE | Applicable Package List | RG_PACKAGE | B_VH_AMC_ENQ.PKG_CODE |
| LOV_EXEC | Executives | RG_EXEC | B_VH_AMC_ENQ.EMP_CD |

**Total LOVs:** 2

### 8.5 Alerts

| Alert Name | Title | Message Text | Calling Context |
| :--- | :--- | :--- | :--- |
| AL_REPORT | AMC Enquiry | Do you want to? | Trigger: FT_PRINT in Form (via CALL_REPORT_ENQ) |
| AL_TCS_DECR | - | Please confirm whether total sale made to the buyer from the seller till date including the current invoice do not exceed 50 lakhs rupees. | Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_TCS_APPLY (commented out / inactive path) |
| AL_TCS | - | In this case If PAN/ Aadhaar is available rate is 0. 075% upto 31st March 21 and 0.1% after that, if PAN/Aadhar Is not available,  rate is 1%. Please select whether TCS applicable or not. | Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_TCS_APPLY (commented out / inactive path) |
| AL_CONFIRM | - | - | Used by GENERAL.ASK_CONFIRM (DPL library) to display confirmation dialogs; invoked by FT_CANCEL and FT_DEL triggers |
| AL_NOTE | - | - | Used by GENERAL.DISP_TEXT (DPL library) to display informational alert messages |
| AL_ERRINFO | - | - | Used by GENERAL.DISP_TEXT (DPL library) to display error alert messages |
| AL_PRINT | - | - | Used by GENERAL.PROC_TIMER_EXPIRED (DPL library) to display print-status or completion messages |

**Total Alerts:** 7

### 8.6 Program Units

*Authoritative catalogue of **4 form-local program units**. Database packages and standalone procedures are in **§15.2**; PLD shared-library routines are in **§18**.*

| Program Unit | Type | Calls | Description |
| :--- | :--- | :--- | :--- |
| POP_PKG_DETAILS | Procedure | VM_AMC_RATE, VM_MSIL_OPR, PM_PART, AM_LIST_RANGE, GENERAL.DISP_TEXT | Populates the enquiry detail block with AMC package line items (labour, parts, consumables) by reading package rate and description masters; invoked from WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_GEN_ENQ |
| CALL_REPORT_ENQ | Procedure | AM_LIST_RANGE, GENERAL.PROC_REPORT_CALL, GENERAL.PROC_TIMER, FIND_REPORT_OBJECT, RUN_REPORT_OBJECT | Builds report parameters, submits the AMC enquiry report to the report server, and starts a polling timer; invoked from FT_PRINT trigger |
| POP_PKG_DETAILS_NEW | Procedure | GBL_AMC_DTL, GENERAL.DISP_TEXT | Populates the enquiry detail block from the global AMC detail template table for a specific vehicle and package; alternative to POP_PKG_DETAILS used on PB_GEN_ENQ for new enquiries |
| SP_INSERT_CHARGES | Procedure | GBL_AMC_CHARGES, VD_AMC_ENQCHARGES, GENERAL.DISP_TEXT | Reads the global AMC charge template and inserts applicable charge rows into the enquiry charges table; invoked during KEY-COMMIT before the form commit |

**Total Program Units:** 4

### 8.7 Triggers

**Item-Level Trigger Types (reference):**

| Trigger Name | Purpose |
| :--- | :--- |
| WHEN-VALIDATE-ITEM | Validates field when user leaves item |
| KEY-* | Keyboard actions — commit, exit, LOV, navigation |
| WHEN-NEW-BLOCK-INSTANCE | Initializes block on entry |
| WHEN-BUTTON-PRESSED | Executes button action |
| PRE-INSERT / POST-INSERT | Before/after record creation |
| WHEN-LIST-CHANGED | Dropdown selection changed |
| PRE-QUERY / POST-QUERY | Before/after query execution |
| WHEN-CHECKBOX-CHANGED | Checkbox toggled |
| WHEN-VALIDATE-RECORD | Validates entire record before leaving row |



**DPL library routines invoked from triggers and program units:**

| Routine | Type | Called From | Purpose |
| :--- | :--- | :--- | :--- |
| GENERAL.ASK_CONFIRM | Library routine | Form level | Presents a Yes/No confirmation dialog; returns 1 for Yes confirmation; used before cancel and delete operations |
| GENERAL.CHECK_NULL | Library routine | B_VH_AMC_ENQ.EMP_CD, B_VH_AMC_ENQ.ODOMETER_READING, B_VH_AMC_ENQ.PKG_CODE, B_VH_AMC_ENQ.REG_NUM, CB_VT_AMC_ENQ.PB_GEN_ENQ | Raises an error and halts form processing if the supplied field value is null; enforces mandatory field validation |
| GENERAL.DISP_TEXT | Library routine | B_VH_AMC_ENQ, B_VH_AMC_ENQ.ODOMETER_READING, B_VH_AMC_ENQ.PKG_CODE, B_VH_AMC_ENQ.REG_NUM, CB_VT_AMC_ENQ.NB_ENQ_NUM, CB_VT_AMC_ENQ.PB_GEN_ENQ, CB_VT_AMC_ENQ.PB_TCS_APPLY, Form level, ProgramUnit: SP_INSERT_CHARGES | Displays an informational or error alert dialog with a title and message text; used for all user-facing messages and error notifications |
| GENERAL.PROC_REPORT_CALL | Library routine | ProgramUnit: CALL_REPORT_ENQ | Configures and submits the report object to the report server in batch/file mode and returns the job handle and output file name |
| GENERAL.RAISE_ERROR | Library routine | Form level | Formats an error code into a message and displays it via DISP_TEXT; raises FORM_TRIGGER_FAILURE for error-class messages |



### 8.7.1 Inactive / Commented-Out Trigger Register

*Triggers and field validations where XML source is `null;`, fully block-commented, or legacy code preserved but not executed. Do **not** migrate these as active business requirements.*

| Status | Block | Item | Trigger | Former behaviour (preserved in comments) | Disabled since / note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Commented out** | Form | — | FT_INSERT | Previously navigated to a target block and added a new record via last_record/next_record; the entire body is block-commented | Disabled — navigation was form-generic (BLOCK_NAME placeholder); superseded; null; stub left in place |
| **Commented out** | Form | — | WHEN-NEW-FORM-INSTANCE | Previously set default global variable values (PRINCIPAL, PARENT_GROUP, DEALER, LOC_CD, CURRENCY, COMP_FA, P_FIN_YR, USER_NAME, USERID) for development/testing purposes | Disabled — hard-coded defaults removed; globals are now populated by the calling menu or session context at runtime |
| **Inactive stub** | B_VH_AMC_ENQ | — | KEY-UP | No prior behaviour documented; body is `null;` | Inactive stub — null; body prevents default Oracle Forms scroll navigation on arrow-up key |
| **Inactive stub** | B_VH_AMC_ENQ | — | KEY-DOWN | No prior behaviour documented; body is `null;` | Inactive stub — null; body prevents default Oracle Forms scroll navigation on arrow-down key |

*Additional null-only or partially commented triggers exist on estimation and legacy blocks — see XML `TriggerText` starting with `null;` or `/*`.*


**Complete trigger inventory (55 business triggers):**
*vt_amc_enq_fmb.xml contains Trigger elements.*

| Trigger Name | Block | Item | Called From / Context | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| ON-ERROR | Form | — | Form level | Intercepts form and database errors; suppresses specific Oracle error codes (e.g. 50004 invalid date) and displays user-friendly messages via GENERAL.DISP_TEXT; delegates unhandled errors to GENERAL.RAISE_ERROR |
| ON-MESSAGE | Form | — | Form level | Intercepts informational messages; re-displays records-fetched messages (40209, 40207) as error dialogs via GENERAL.DISP_TEXT to enforce consistent messaging |
| KEY-EXIT | Form | — | Form level | Clears the Oracle application session info and exits the form without validation |
| KEY-LISTVAL | Form | — | Form level | Enables form-level validation, then opens the LOV for the current item |
| KEY-COMMIT | Form | — | Form level | Validates the form, calls SP_INSERT_CHARGES to write charge rows, commits the transaction, and logs the save event if application logging is active |
| KEY-CLRFRM | Form | — | Form level | Clears the form without validation, resets query and new-item parameters, and hides irrelevant item properties |
| KEY-OTHERS | Form | — | Form level | Inherited via object group — suppresses undefined keyboard actions |
| KEY-NEXT-ITEM | Form | — | Form level | Inherited via object group — navigates to the next form item |
| KEY-PREV-ITEM | Form | — | Form level | Inherited via object group — navigates to the previous form item |
| KEY-NXTBLK | Form | — | Form level | Inherited via object group — navigates to the next block |
| KEY-PRVBLK | Form | — | Form level | Inherited via object group — navigates to the previous block |
| KEY-DOWN | Form | — | Form level | Inherited via object group — moves down one record in the current block |
| KEY-UP | Form | — | Form level | Inherited via object group — moves up one record in the current block |
| FT_SAVE | Form | — | Form level | Generates the AMC enquiry number when creating a new record (calls Pk_Validate_Back_Date.Generate_Next_Num), saves the package amount breakdown, and commits; inactive when PKG_AMT is null |
| FT_CANCEL | Form | — | Form level | Prompts for confirmation via ASK_CONFIRM if data has changed, then clears the form without saving |
| FT_INSERT | Form | — | Form level | **COMMENTED OUT / INACTIVE** — previously navigated to a block and inserted a new record; replaced by null; stub |
| FT_DEL | Form | — | Form level | Prompts for delete confirmation via ASK_CONFIRM and deletes the current record if confirmed |
| FT_LIST | Form | — | Form level | Opens the LOV for the current item when the List button is enabled |
| FT_PRINT | Form | — | Form level | Submits the AMC enquiry report for the current enquiry number by calling CALL_REPORT_ENQ |
| WHEN-NEW-FORM-INSTANCE | Form | — | Form level | **COMMENTED OUT / INACTIVE** — body is entirely block-commented; formerly set development default globals |
| PRE-FORM | Form | — | Form level | Registers the form module name in the Oracle application session for diagnostic logging; starts performance timer if APP_LOG is active |
| WHEN-TIMER-EXPIRED | Form | — | Form level | Delegates to GENERAL.PROC_TIMER_EXPIRED to check report job status and display the output document when ready |
| WHEN-VALIDATE-ITEM | CB_VT_AMC_ENQ | NB_ENQ_NUM | CB_VT_AMC_ENQ.NB_ENQ_NUM | Checks whether the entered enquiry number exists in VH_AMC_ENQ; displays a message if found or if not found for context |
| WHEN-BUTTON-PRESSED | CB_VT_AMC_ENQ | PB_GEN_ENQ | CB_VT_AMC_ENQ.PB_GEN_ENQ | Validates required fields (registration number, odometer, package, employee), calls SP_POP_PKG_DTL to populate package details, and calls POP_PKG_DETAILS_NEW to populate line items |
| WHEN-BUTTON-PRESSED | CB_VT_AMC_ENQ | PB_DTL | CB_VT_AMC_ENQ.PB_DTL | Navigates to the B_VD_AMC_ENQ detail block |
| WHEN-BUTTON-PRESSED | CB_VT_AMC_ENQ | PB_TCS_APPLY | CB_VT_AMC_ENQ.PB_TCS_APPLY | Navigates to the TCS enquiry canvas and enables the Save button after TCS rate selection |
| WHEN-BUTTON-PRESSED | CB_VT_AMC_ENQ | PB_TCS_RATE_N | CB_VT_AMC_ENQ.PB_TCS_RATE_N | Sets TCS applicability flag to `Y` (normal rate) and enables the Apply button |
| WHEN-BUTTON-PRESSED | CB_VT_AMC_ENQ | PB_TCS_RATE_H | CB_VT_AMC_ENQ.PB_TCS_RATE_H | Sets TCS applicability flag to `H` (higher rate) and enables the Apply button |
| PRE-INSERT | B_VH_AMC_ENQ | — | B_VH_AMC_ENQ | Stamps the current dealer, location, company, creation date, and user ID onto the header record before insert; sets the NEW_REC parameter |
| POST-QUERY | B_VH_AMC_ENQ | — | B_VH_AMC_ENQ | Populates display-only vehicle and customer fields (model, variant, colour, sale date, city, employee name, state) and AMC type details from related master tables after each query |
| PRE-UPDATE | B_VH_AMC_ENQ | — | B_VH_AMC_ENQ | Stamps the current user ID and system date onto MODIFIED_BY and MODIFIED_DATE before updating the header record |
| WHEN-NEW-BLOCK-INSTANCE | B_VH_AMC_ENQ | — | B_VH_AMC_ENQ | If an enquiry number is already entered, executes queries on both VH and VD blocks and sets the block display properties |
| KEY-UP | B_VH_AMC_ENQ | — | B_VH_AMC_ENQ | **INACTIVE** — null; stub; suppresses default scroll-up navigation within this block |
| KEY-DOWN | B_VH_AMC_ENQ | — | B_VH_AMC_ENQ | **INACTIVE** — null; stub; suppresses default scroll-down navigation within this block |
| WHEN-VALIDATE-ITEM | B_VH_AMC_ENQ | REG_NUM | B_VH_AMC_ENQ.REG_NUM | Validates the registration number is not null, calls PKG_AMC.SP_VIN_VALIDATE to check vehicle eligibility, calls PKG_AMC.SP_GET_GST_TYPE to determine GST type, and auto-populates vehicle details (VIN, colour, phone, email, customer info) |
| WHEN-VALIDATE-ITEM | B_VH_AMC_ENQ | ODOMETER_READING | B_VH_AMC_ENQ.ODOMETER_READING | Validates the odometer reading is not null and is not less than the previous service mileage |
| WHEN-VALIDATE-ITEM | B_VH_AMC_ENQ | EMP_CD | B_VH_AMC_ENQ.EMP_CD | Validates employee code is not null when creating a new enquiry; allows blank on existing records |
| WHEN-VALIDATE-ITEM | B_VH_AMC_ENQ | PKG_CODE | B_VH_AMC_ENQ.PKG_CODE | Validates package code is not null; calculates the AMC validity expiry date from the vehicle sale date and package expiry months |
| PRE-INSERT | B_VD_AMC_ENQ | — | B_VD_AMC_ENQ | Stamps dealer, location, company, enquiry number, creation date, and user ID onto each detail record before insert |
| PRE-UPDATE | B_VD_AMC_ENQ | — | B_VD_AMC_ENQ | Stamps the current user ID and system date onto MODIFIED_BY and MODIFIED_DATE before updating a detail record |
| POST-QUERY | B_VD_AMC_ENQ | — | B_VD_AMC_ENQ | Populates service description fields from operation (labour) or parts/consumables master tables based on the service type code |
| WHEN-NEW-BLOCK-INSTANCE | B_TCS | — | B_TCS | Enables the TCS Apply button when a TCS flag is already present on the header record |
| WHEN-RADIO-CHANGED | B_TCS | NB_TCS_APPL_YN | B_TCS.NB_TCS_APPL_YN | When the TCS confirmation radio button is set to Yes, clears the TCS flag and enables the Normal Rate and Higher Rate buttons |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EXIT | PB_BLK.PB_EXIT (inherited) | Clears application session info and exits the form |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_LIST | PB_BLK.PB_LIST (inherited) | Opens the LOV for the current item |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_INSERT | PB_BLK.PB_INSERT (inherited) | Inherited insert button — not active in this form (FT_INSERT is commented out) |
| WHEN-BUTTON-PRESSED | PB_BLK | PM_CONT | PB_BLK.PM_CONT (inherited) | Navigates back to the CB_VT_AMC_ENQ control block |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_DEL | PB_BLK.PB_DEL (inherited) | Executes the FT_DEL trigger to delete the current record after confirmation |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CANCEL | PB_BLK.PB_CANCEL (inherited) | Sets the P_SAVE parameter to N and executes the FT_CANCEL trigger |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SAVE | PB_BLK.PB_SAVE (inherited) | Sets the P_SAVE parameter to Y, executes the FT_SAVE trigger, then resets P_SAVE to N |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PRINT | PB_BLK.PB_PRINT (inherited) | Inherited print button — invokes FT_PRINT to submit the AMC enquiry report |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CUT | PB_BLK.PB_CUT (inherited) | Inherited clipboard Cut button |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_COPY | PB_BLK.PB_COPY (inherited) | Inherited clipboard Copy button |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PASTE | PB_BLK.PB_PASTE (inherited) | Inherited clipboard Paste button |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_BACK | PB_BLK.PB_BACK (inherited) | Navigates back to the CB_VT_AMC_ENQ control block |

### 8.8 Canvas and Window Inventory

**Windows:**

| Window | Title | Primary Canvas |
| :--- | :--- | :--- |
| WN_MAIN | MCP Enquiry Generation (Rel: 1.2.4) | CN_MAIN |
| WIN_ERR | — | CN_ERR |

**Canvases:**

| Canvas | Type | Window |
| :--- | :--- | :--- |
| CN_DEF | Stacked | WN_MAIN |
| CN_ERR | Content | WIN_ERR |
| CN_MAIN | Content | WN_MAIN |
| CN_TCS | Content | WN_MAIN |
| CN_TOOL | Content | — |

---

### 8.9 Editors

*No editors found in vt_amc_enq_fmb.xml.*

### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

#### 8.10.1 Visual Attributes (form-defined)

*2 VisualAttribute elements defined at form level (not inherited from DPL.olb).*

| Visual Attribute |
| :--- |
| VA_DEFAULT |
| VA_MANDATORY |

#### 8.10.2 Property Classes (form-defined)

*Form-local PropertyClass elements.*

*No form-local property classes found in vt_amc_enq_fmb.xml.*

#### 8.10.3 Object Groups

*Object groups bundle inherited triggers and visual objects applied form-wide at runtime.*

| Object Group Child | Type |
| :--- | :--- |
| KEY-OTHERS | Inherited trigger/object |
| KEY-NEXT-ITEM | Inherited trigger/object |
| KEY-PREV-ITEM | Inherited trigger/object |
| KEY-NXTBLK | Inherited trigger/object |
| KEY-PRVBLK | Inherited trigger/object |
| KEY-DOWN | Inherited trigger/object |
| KEY-UP | Inherited trigger/object |
| CN_ERR | Inherited trigger/object |
| VA_DISP | Inherited trigger/object |
| CB_ERR | Inherited trigger/object |
| VA_LOV | Inherited trigger/object |
| VA_TRNI_DT | Inherited trigger/object |
| VA_TITLE | Inherited trigger/object |
| VA_ALERT | Inherited trigger/object |
| VA_BUTN | Inherited trigger/object |
| VA_TEXT | Inherited trigger/object |
| VA_MPROMPT | Inherited trigger/object |
| VA_OPROMPT | Inherited trigger/object |
| VA_MAND | Inherited trigger/object |
| VA_NUM | Inherited trigger/object |
| VA_DESC | Inherited trigger/object |
| VA_ICONIC_BUTN | Inherited trigger/object |
| VA_RB | Inherited trigger/object |
| VA_CB | Inherited trigger/object |
| WN_MAIN | Inherited trigger/object |
| POP_MAIN | Inherited trigger/object |
| CN_MAIN | Inherited trigger/object |
| CN_TOOL | Inherited trigger/object |
| PB_BLK | Inherited trigger/object |
| AL_ERRINFO | Inherited trigger/object |
| AL_NOTE | Inherited trigger/object |
| AL_CONFIRM | Inherited trigger/object |
| WIN_ERR | Inherited trigger/object |
| AL_PRINT | Inherited trigger/object |
| FT_SAVE | Inherited trigger/object |
| FT_CANCEL | Inherited trigger/object |
| FT_INSERT | Inherited trigger/object |
| FT_DEL | Inherited trigger/object |
| FT_LIST | Inherited trigger/object |
| FT_PRINT | Inherited trigger/object |
| WHEN-NEW-FORM-INSTANCE | Inherited trigger/object |

### 8.11 DataSourceColumn Inventory

*70 DataSourceColumn elements across 2 blocks — formal query column-to-block mapping from vt_amc_enq_fmb.xml.*

#### B_VH_AMC_ENQ (35 columns)

| Column (DSCName) | Data Type |
| :--- | :--- |
| PRINCIPAL_MAP_CD | NUMBER |
| EWARR_NUM | VARCHAR2 |
| EWARR_DATE | DATE |
| CUST_CD | VARCHAR2 |
| VIN | VARCHAR2 |
| REG_NUM | VARCHAR2 |
| MUL_FIN_YN | VARCHAR2 |
| MUL_FIN_NUM | VARCHAR2 |
| OPTION_CD | VARCHAR2 |
| MAX_MILEAGE | NUMBER |
| VALID_UPTO | DATE |
| PAY_MODE_CD | VARCHAR2 |
| BOOKLET_NUM | VARCHAR2 |
| INSTRUMENT_FAVOUR | VARCHAR2 |
| BRANCH_NAME | VARCHAR2 |
| INSTRUMENT_NUM | VARCHAR2 |
| INSTRUMENT_DATE | DATE |
| BANK_NAME | VARCHAR2 |
| INSTRUMENT_AMT | VARCHAR2 |
| CREDIT_CARD_NUM | VARCHAR2 |
| EXPIRY_DATE | DATE |
| SERVICE_PER | NUMBER |
| SERVICE_AMT | NUMBER |
| PREMIMUM_RECD | NUMBER |
| PREMIMUM_ACTL | NUMBER |
| PREMIMUM_CAL | NUMBER |
| EWARR_AMT | NUMBER |
| PARENT_GROUP | VARCHAR2 |
| DEALER_MAP_CD | NUMBER |
| COMP_FA | VARCHAR2 |
| LOC_CD | VARCHAR2 |
| CREATED_DATE | DATE |
| CREATED_BY | VARCHAR2 |
| MODIFIED_DATE | DATE |
| MODIFIED_BY | VARCHAR2 |

#### B_VD_AMC_ENQ (35 columns)

| Column (DSCName) | Data Type |
| :--- | :--- |
| PRINCIPAL_MAP_CD | NUMBER |
| EWARR_NUM | VARCHAR2 |
| EWARR_DATE | DATE |
| CUST_CD | VARCHAR2 |
| VIN | VARCHAR2 |
| REG_NUM | VARCHAR2 |
| MUL_FIN_YN | VARCHAR2 |
| MUL_FIN_NUM | VARCHAR2 |
| OPTION_CD | VARCHAR2 |
| MAX_MILEAGE | NUMBER |
| VALID_UPTO | DATE |
| PAY_MODE_CD | VARCHAR2 |
| BOOKLET_NUM | VARCHAR2 |
| INSTRUMENT_FAVOUR | VARCHAR2 |
| BRANCH_NAME | VARCHAR2 |
| INSTRUMENT_NUM | VARCHAR2 |
| INSTRUMENT_DATE | DATE |
| BANK_NAME | VARCHAR2 |
| INSTRUMENT_AMT | VARCHAR2 |
| CREDIT_CARD_NUM | VARCHAR2 |
| EXPIRY_DATE | DATE |
| SERVICE_PER | NUMBER |
| SERVICE_AMT | NUMBER |
| PREMIMUM_RECD | NUMBER |
| PREMIMUM_ACTL | NUMBER |
| PREMIMUM_CAL | NUMBER |
| EWARR_AMT | NUMBER |
| PARENT_GROUP | VARCHAR2 |
| DEALER_MAP_CD | NUMBER |
| COMP_FA | VARCHAR2 |
| LOC_CD | VARCHAR2 |
| CREATED_DATE | DATE |
| CREATED_BY | VARCHAR2 |
| MODIFIED_DATE | DATE |
| MODIFIED_BY | VARCHAR2 |

**Total DataSourceColumns:** 70 across 2 blocks

---

## 9. Object Library

*The form inherits Visual Attributes, Property Classes, and one Object Group from the DPL template module (`DPL_MTPL.fmb`), whose reusable objects are catalogued in the DPL Object Library (`DPL.olb` / `DPL_olb.xml`). The catalogue below lists every object defined in that library with its type and the count of form elements that directly subclass it in this form.*

Source OLB file(s): DPL.olb, DPL_olb.xml

| Name | Type | Description | Used By (count) | Sample Items |
| ---- | ---- | ----------- | --------------- | ------------ |
| VA_DISP | VisualAttribute | Display-item visual attribute (read-only presentation style) | 1 | VA_DISP (form-level, inherited from DPL_MTPL) |
| VA_LOV | VisualAttribute | LOV-enabled text item visual attribute | 1 | VA_LOV (form-level, inherited from DPL_MTPL) |
| VA_TRNI_DT | VisualAttribute | Date/transaction date visual attribute | 1 | VA_TRNI_DT (form-level, inherited from DPL_MTPL) |
| VA_TITLE | VisualAttribute | Section title visual attribute | 1 | VA_TITLE (form-level, inherited from DPL_MTPL) |
| VA_ALERT | VisualAttribute | Alert message visual attribute | 1 | VA_ALERT (form-level, inherited from DPL_MTPL) |
| VA_BUTN | VisualAttribute | Push button visual attribute | 1 | VA_BUTN (form-level, inherited from DPL_MTPL) |
| VA_TEXT | VisualAttribute | Editable text item visual attribute | 1 | VA_TEXT (form-level, inherited from DPL_MTPL) |
| VA_MPROMPT | VisualAttribute | Mandatory field prompt visual attribute | 1 | VA_MPROMPT (form-level, inherited from DPL_MTPL) |
| VA_OPROMPT | VisualAttribute | Optional field prompt visual attribute | 1 | VA_OPROMPT (form-level, inherited from DPL_MTPL) |
| VA_MAND | VisualAttribute | Mandatory field value visual attribute | 1 | VA_MAND (form-level, inherited from DPL_MTPL) |
| VA_NUM | VisualAttribute | Numeric field visual attribute | 1 | VA_NUM (form-level, inherited from DPL_MTPL) |
| VA_DESC | VisualAttribute | Description field visual attribute | 1 | VA_DESC (form-level, inherited from DPL_MTPL) |
| VA_ICONIC_BUTN | VisualAttribute | Iconic push button visual attribute | 1 | VA_ICONIC_BUTN (form-level, inherited from DPL_MTPL) |
| VA_RB | VisualAttribute | Radio button visual attribute | 1 | VA_RB (form-level, inherited from DPL_MTPL) |
| VA_CB | VisualAttribute | Check box visual attribute | 1 | VA_CB (form-level, inherited from DPL_MTPL) |
| PC_DESC | PropertyClass | Property class for description items | 0 | Not directly subclassed by any item in this form |
| PC_SC_DATE | PropertyClass | Property class for date fields | 0 | Not directly subclassed by any item in this form |
| PC_TITLE | PropertyClass | Property class for title text items | 0 | Not directly subclassed by any item in this form |
| PC_FORMAT | PropertyClass | Property class for formatted text items | 0 | Not directly subclassed by any item in this form |
| PC_MR_BLK | PropertyClass | Property class for multi-record blocks | 0 | Not directly subclassed by any item in this form |
| PC_DISP | PropertyClass | Property class for display items | 0 | Not directly subclassed by any item in this form |
| PC_LOV | PropertyClass | Property class for list-of-values items | 1 | LOV_PACKAGE, LOV_EXEC (inherited from DPL_MTPL) |
| PC_FORM | PropertyClass | Property class for form-level settings | 1 | Form module (inherited from DPL_MTPL) |
| PC_DISP_DATE | PropertyClass | Property class for display date items | 0 | Not directly subclassed by any item in this form |
| PC_DISP_NUM | PropertyClass | Property class for display numeric items | 0 | Not directly subclassed by any item in this form |
| PC_DATE | PropertyClass | Property class for date input items | 0 | Not directly subclassed by any item in this form |
| PC_DTTIME | PropertyClass | Property class for date and time items | 0 | Not directly subclassed by any item in this form |
| PC_CB | PropertyClass | Property class for check box items | 0 | Not directly subclassed by any item in this form |
| PC_ALERT | PropertyClass | Property class for alert dialogs | 0 | Not directly subclassed by any item in this form |
| PC_MDATE | PropertyClass | Property class for mandatory date fields | 0 | Not directly subclassed by any item in this form |
| PC_RB | PropertyClass | Property class for radio button items | 0 | Not directly subclassed by any item in this form |
| PC_WIND | PropertyClass | Property class for windows | 0 | Not directly subclassed by any item in this form |
| PC_CANV | PropertyClass | Property class for canvases | 0 | Not directly subclassed by any item in this form |
| PC_BUTN | PropertyClass | Property class for push buttons | 0 | Not directly subclassed by any item in this form |
| PC_TEXT | PropertyClass | Property class for text input items | 1 | REG_NUM (Registration Number field, directly subclassed) |
| PC_MTEXT | PropertyClass | Property class for mandatory text items | 0 | Not directly subclassed by any item in this form |
| PC_UTEXT | PropertyClass | Property class for uppercase text items | 0 | Not directly subclassed by any item in this form |
| PC_MUTEXT | PropertyClass | Property class for mandatory uppercase text items | 0 | Not directly subclassed by any item in this form |
| PC_NUM | PropertyClass | Property class for numeric input items | 0 | Not directly subclassed by any item in this form |
| PC_MNUM | PropertyClass | Property class for mandatory numeric items | 0 | Not directly subclassed by any item in this form |
| PC_ICONIC_BUTN | PropertyClass | Property class for iconic push buttons | 0 | Not directly subclassed by any item in this form |
| PC_SCROLL | PropertyClass | Property class for scrollable blocks | 0 | Not directly subclassed by any item in this form |
| OG_GROUP | ObjectGroup | Standard DPL object group containing framework triggers and navigation keys subclassed into this form | 1 | KEY-OTHERS, KEY-NEXT-ITEM, KEY-PREV-ITEM, KEY-NXTBLK, KEY-PRVBLK, KEY-DOWN, KEY-UP, FT_SAVE, FT_CANCEL, FT_INSERT, FT_DEL, FT_LIST, FT_PRINT, WHEN-NEW-FORM-INSTANCE |

---

## 10. Record Groups

*Lists all record groups, their LOV bindings, query logic, dynamic bindings, business purpose, and form usage.*

| Record Group | Type | Used By LOV | Display Column | Return Column | Dynamic Bindings | Purpose | Where Used |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| RG_PACKAGE | Query | LOV_PACKAGE | PKG_CODE | PKG_DESC | Yes — B_VH_AMC_ENQ | Lists available AMC packages for the vehicle based on average run, variant, and current date eligibility | LOV_PACKAGE → B_VH_AMC_ENQ.PKG_CODE |
| RG_EXEC | Query | LOV_EXEC | EMP_CD | EMP_NAME | No | Lists active approved service executives (vehicle category) at the current dealer location | LOV_EXEC → B_VH_AMC_ENQ.EMP_CD |

**Total Record Groups:** 2

---

## 11. Referenced Database Objects

*Database tables, views, and objects accessed by the form.*

| Block | Base Table | Primary Key Item | Database Item |
| :--- | :--- | :--- | :--- |
| CB_VT_AMC_ENQ | — | — | No |
| B_VH_AMC_ENQ | VH_AMC_ENQ | — | Yes |
| B_VD_AMC_ENQ | VD_AMC_ENQ | — | Yes |
| B_TCS | — | — | No |

| Object | Schema | Used In | Description |
| :--- | :--- | :--- | :--- |
| `AM_DEALER_LOC` | — | Trigger WHEN-VALIDATE-ITEM | Dealer location master — stores dealer state code and location details for GST type determination |
| `AM_DEALER_LOC_PARAM` | — | Trigger WHEN-NEW-FORM-INSTANCE | Dealer location parameter table — stores location-level configuration parameters used at form startup |
| `AM_LIST_RANGE` | — | CALL_REPORT_ENQ, POP_PKG_DETAILS, RG_EXEC, Trigger POST-QUERY | General list range master — stores configurable lists including AMC exception model codes and report parameters |
| `DUAL` | — | Trigger WHEN-VALIDATE-ITEM | Oracle DUAL pseudo-table — used in validation queries to check conditions without accessing a real table |
| `GBL_AMC_DTL` | — | POP_PKG_DETAILS_NEW | Global AMC detail template — stores pre-defined package line item breakdown (labour, parts, consumables) used to populate enquiry detail |
| `GM_CITY` | — | Trigger POST-QUERY | City master — stores city descriptions looked up from city code on the enquiry header |
| `GM_EMP` | — | RG_EXEC, Trigger POST-QUERY | Employee master — stores employee codes and names used in the executives LOV and employee name display |
| `GM_STATE` | — | Trigger POST-QUERY, Trigger WHEN-VALIDATE-ITEM | State master — stores GST state codes for dealers and customers used in GST type determination |
| `GM_VAR` | — | Trigger POST-QUERY, Trigger WHEN-VALIDATE-ITEM | Vehicle variant master — stores variant descriptions and fuel type codes used to populate vehicle fields |
| `GM_VIN` | — | Trigger POST-QUERY, Trigger WHEN-VALIDATE-ITEM | Vehicle VIN master — stores vehicle identification numbers, sale dates, odometer readings, and customer links |
| `PM_PART` | — | POP_PKG_DETAILS, Trigger POST-QUERY | Parts master — stores part descriptions and tax codes used to populate parts line items in the enquiry detail |
| `VD_AMC_ENQ` | — | B_VD_AMC_ENQ | AMC enquiry detail table — stores individual service line items (labour, parts, consumables) for each enquiry |
| `VD_AMC_ENQCHARGES` | — | SP_INSERT_CHARGES | AMC enquiry charges table — stores additional charge rows (taxes, fees) linked to the enquiry, inserted at commit |
| `VH_AMC_ENQ` | — | B_VH_AMC_ENQ, Trigger WHEN-VALIDATE-ITEM | AMC enquiry header table — primary transaction table storing vehicle, customer, package, and billing details for each enquiry |
| `VM_AMC_PARAM` | — | Trigger WHEN-VALIDATE-ITEM | AMC parameters master — stores validity months and mileage limits used in vehicle eligibility validation |
| `VM_AMC_PKG` | — | RG_PACKAGE, Trigger POST-QUERY, Trigger WHEN-VALIDATE-ITEM | AMC package master — stores package codes, descriptions, expiry months, mileage, and AMC type for the package LOV |
| `VM_AMC_PKG_MOD` | — | RG_PACKAGE, Trigger WHEN-VALIDATE-ITEM | AMC package model mapping — links packages to eligible vehicle models/variants for package availability filtering |
| `VM_AMC_RATE` | — | POP_PKG_DETAILS | AMC rate master — stores labour, parts, and consumable rates by package, used to populate enquiry line item amounts |
| `VM_MSIL_OPR` | — | POP_PKG_DETAILS, Trigger POST-QUERY | Operations master — stores operation/labour service codes and descriptions used in enquiry detail population |
| `VM_SVAR` | — | Trigger POST-QUERY | Sub-variant master — stores sub-variant descriptions looked up after query to populate the model description field |

**Total Referenced Objects:** 20

---

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure/Package Index

| Requirement ID | Procedure/Package | Purpose |
| -------------- | ----------------- | ------- |
| BR-001 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Registers the module client identity in the database session at form launch |
| BR-001 | DBMS_APPLICATION_INFO.SET_MODULE | Registers the module name in the database session at form launch |
| BR-002 | GENERAL.DISP_TEXT | Displays the MCP deactivation error message on form open |
| BR-002 | SF_COPYRIGHT_DECLARATION | Generates and returns the current-year copyright string for display |
| BR-003 | SF_COPYRIGHT_DECLARATION | Regenerates the copyright notice after a form clear |
| BR-004 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Clears the session client information on form exit |
| BR-004 | DBMS_APPLICATION_INFO.SET_MODULE | Clears the session module name on form exit |
| BR-005 | GENERAL.DISP_TEXT | Displays user-friendly error messages for intercepted error codes |
| BR-005 | GENERAL.RAISE_ERROR | Resolves and displays coded error messages (e.g. E0088) for constraint violations |
| BR-006 | GENERAL.DISP_TEXT | Displays system messages 40209 and 40207 as user-facing error alerts |
| BR-007 | GENERAL.PROC_TIMER_EXPIRED | Polls the report server for printer-queue job completion on timer expiry |
| BR-008 | GENERAL.DISP_TEXT | Displays enquiry-number not-found and data-error messages |
| BR-009 | GENERAL.CHECK_NULL | Checks that the Registration Number field is not blank |
| BR-009 | SP_VALIDATE_ALPHANUMERIC | Strips non-uppercase-letter, non-digit characters from the registration number |
| BR-009 | SP_GET_VEH_DETAILS | Retrieves all vehicle, variant, and customer details for the matched registration number |
| BR-009 | PKG_AMC.SP_GET_GST_TYPE | Determines the applicable GST type from the dealer and customer state codes |
| BR-009 | PKG_AMC.SP_VIN_VALIDATE | Validates the VIN for MCP eligibility (existing MCP, restrictions, exclusions, date/mileage window) |
| BR-010 | GENERAL.CHECK_NULL | Checks that the Current Mileage field is not blank |
| BR-011 | GENERAL.CHECK_NULL | Checks that the Executive field is not blank for new enquiries |
| BR-012 | GENERAL.CHECK_NULL | Checks that the Applicable Package field is not blank |
| BR-013 | GENERAL.CHECK_NULL | Checks that the Applicable Package field is not blank before generation |
| BR-013 | GENERAL.DISP_TEXT | Displays the TCS information note and TCS declaration error |
| BR-013 | PKG_AMC.SP_POP_PKG_DTL | Computes and stages the full package rate breakdown with TCS charges |
| BR-013 | POP_PKG_DETAILS_NEW | Reads staged package detail lines and populates the enquiry detail block and header totals |
| BR-018 | PKG_AMC.SP_POP_PKG_DTL | Recomputes the package rate staging data after TCS rate is confirmed |
| BR-018 | POP_PKG_DETAILS_NEW | Refreshes the detail block after TCS-updated rate calculation |
| BR-021 | PKG_AMC.SP_POP_PKG_DTL | Recomputes package rate staging when an existing enquiry is queried |
| BR-021 | POP_PKG_DETAILS_NEW | Populates the detail block from staged data on post-query enrichment |
| BR-026 | PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM | Generates the next sequential MCP enquiry document number at save time |
| BR-026 | GENERAL.CHECK_FORM_FAILURE | Checks for form/database errors after each commit operation |
| BR-026 | SP_INSERT_CHARGES | Inserts pre-computed charge lines from staging into the enquiry charge table |
| BR-026 | GENERAL.DISP_TEXT | Displays the enquiry number confirmation note after successful save |
| BR-026 | CALL_REPORT_ENQ | Generates and delivers the MCP enquiry report after save |
| BR-027 | GENERAL.ASK_CONFIRM | Displays a confirmation dialog before discarding unsaved changes |
| BR-028 | GENERAL.ASK_CONFIRM | Displays a confirmation dialog before deleting a record |
| BR-029 | CALL_REPORT_ENQ | Generates and delivers the MCP enquiry report on print action |

### 12.2 Procedure and Package Catalogue

#### CALL_REPORT_ENQ (Form-local Program Unit)

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| CALL_REPORT_ENQ | Form-local Program Unit (PROCEDURE) | FT_PRINT trigger (Form); KEY-COMMIT trigger (Form) | Selects the correct enquiry report template (GST or pre-GST), prompts the user for PDF or printer output, and runs the MCP enquiry report via the Oracle Reports engine |

#### POP_PKG_DETAILS_NEW (Form-local Program Unit)

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| POP_PKG_DETAILS_NEW | Form-local Program Unit (PROCEDURE) | WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_GEN_ENQ; WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_TCS_APPLY; POST-QUERY in B_VH_AMC_ENQ | Reads the pre-computed package detail staging table and populates the enquiry detail block and header summary totals |

#### POP_PKG_DETAILS (Form-local Program Unit — INACTIVE)

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| POP_PKG_DETAILS | Form-local Program Unit (PROCEDURE) — (COMMENTED OUT / INACTIVE — does not execute) | Called only from commented-out code in WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_GEN_ENQ | Superseded version of the detail line population routine; replaced by POP_PKG_DETAILS_NEW; not called from any active code path |

#### SP_INSERT_CHARGES (Form-local Program Unit)

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| SP_INSERT_CHARGES | Form-local Program Unit (PROCEDURE) | KEY-COMMIT trigger (Form) | Inserts all pre-computed tax and charge lines from the charge staging table into the enquiry charge table (VD_AMC_ENQCHARGES) at commit time |

#### GENERAL.DISP_TEXT

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| GENERAL.DISP_TEXT | DPL Library Routine (via DPL.pld / DPL.pll) | ON-ERROR, ON-MESSAGE, WHEN-NEW-FORM-INSTANCE, FT_SAVE, KEY-COMMIT, WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_GEN_ENQ, WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_TCS_APPLY, WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.REG_NUM, B_VH_AMC_ENQ.ODOMETER_READING, B_VH_AMC_ENQ.PKG_CODE, CB_VT_AMC_ENQ.NB_ENQ_NUM, SP_INSERT_CHARGES | Displays user-facing alert messages (errors, notes, warnings) by configuring and showing either AL_ERRINFO or AL_NOTE alert |

#### GENERAL.RAISE_ERROR

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| GENERAL.RAISE_ERROR | DPL Library Routine (via DPL.pld / DPL.pll) | ON-ERROR trigger (Form) | Resolves a coded error message number (e.g. E0088) and displays it with the appropriate severity |

#### GENERAL.CHECK_FORM_FAILURE

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| GENERAL.CHECK_FORM_FAILURE | DPL Library Routine (via DPL.pld / DPL.pll) | KEY-COMMIT trigger (Form) | Checks whether the most recent form operation succeeded; displays the database or form error text if it did not |

#### GENERAL.ASK_CONFIRM

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| GENERAL.ASK_CONFIRM | DPL Library Routine (via DPL.pld / DPL.pll) | FT_CANCEL trigger (Form); FT_DEL trigger (Form) | Displays a confirmation alert and returns 1 (confirmed) or 0 (declined) |

#### GENERAL.CHECK_NULL

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| GENERAL.CHECK_NULL | DPL Library Routine (via DPL.pld / DPL.pll) | WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_GEN_ENQ; WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.EMP_CD, B_VH_AMC_ENQ.ODOMETER_READING, B_VH_AMC_ENQ.PKG_CODE, B_VH_AMC_ENQ.REG_NUM | Checks that a specified field value is not null; displays an "Enter a valid \<field name\>" error and raises a trigger failure if null |

#### GENERAL.PROC_TIMER_EXPIRED

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| GENERAL.PROC_TIMER_EXPIRED | DPL Library Routine (via DPL.pld / DPL.pll) | WHEN-TIMER-EXPIRED trigger (Form) | Polls the Oracle Reports server for the status of a submitted print job; opens the output in the browser on completion or displays an error |

#### GENERAL.PROC_REPORT_CALL

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| GENERAL.PROC_REPORT_CALL | DPL Library Routine (via DPL.pld / DPL.pll) | CALL_REPORT_ENQ (Form-local Program Unit) | Runs the Oracle Reports report object for printer-destination output and returns the job handle and print output path |

#### GENERAL.PROC_TIMER

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| GENERAL.PROC_TIMER | DPL Library Routine (via DPL.pld / DPL.pll) | CALL_REPORT_ENQ (Form-local Program Unit) | Starts the printer-queue polling timer after a report job is submitted for printer delivery |

#### PKG_AMC.SP_POP_PKG_DTL

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| PKG_AMC.SP_POP_PKG_DTL | Database Package Procedure (PKG_AMC.pck) | WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_GEN_ENQ; WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_TCS_APPLY; POST-QUERY in B_VH_AMC_ENQ | Computes the full package rate and tax/charge breakdown for the selected package, registration number, GST type, and TCS setting; writes results to staging tables GBL_AMC_DTL and GBL_AMC_CHARGES |

#### PKG_AMC.SP_GET_GST_TYPE

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| PKG_AMC.SP_GET_GST_TYPE | Database Package Procedure (PKG_AMC.pck) | WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.REG_NUM | Determines the applicable GST type (IGST or SGST/CGST) based on the dealer state versus customer state, and handles SEZ customers |

#### PKG_AMC.SP_VIN_VALIDATE

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| PKG_AMC.SP_VIN_VALIDATE | Database Package Procedure (PKG_AMC.pck) | WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.REG_NUM | Validates VIN eligibility for MCP: checks for existing active MCP, model exclusions, restricted vehicle list, sale date availability, and mileage/time-window limits |

#### PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM | Database Package Procedure (PK_VALIDATE_BACK_DATE.pck) | FT_SAVE trigger (Form) | Generates and reserves the next sequential MCP enquiry document number by locking and updating the AM_DOCS document master |

#### SP_GET_VEH_DETAILS

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| SP_GET_VEH_DETAILS | Standalone Database Procedure (SP_GET_VEH_DETAILS.prc) | WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.REG_NUM | Retrieves vehicle, variant, customer, and contact details for a given registration number from the vehicle and customer master tables |

#### SF_COPYRIGHT_DECLARATION

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| SF_COPYRIGHT_DECLARATION | Standalone Database Function (SF_COPYRIGHT_DECLARATION.fnc) | WHEN-NEW-FORM-INSTANCE trigger (Form); KEY-CLRFRM trigger (Form) | Returns the current-year copyright string (e.g. "© 2026 Maruti Suzuki India Limited") based on the current calendar month |

#### SP_VALIDATE_ALPHANUMERIC

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| SP_VALIDATE_ALPHANUMERIC | Standalone Database Procedure (SP_VALIDATE_ALPHANUMERIC.prc) | WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.REG_NUM | Strips any character from the registration number that is not an uppercase letter (A–Z) or a digit (0–9), returning the sanitised value |

#### DBMS_APPLICATION_INFO.SET_CLIENT_INFO

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Oracle Built-in Database Package (EXTERNAL / NOT IN BUNDLE) | PRE-FORM trigger (Form); KEY-EXIT trigger (Form) | Registers (at form open) or clears (at form exit) the client module identifier in the active database session |

#### DBMS_APPLICATION_INFO.SET_MODULE

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| DBMS_APPLICATION_INFO.SET_MODULE | Oracle Built-in Database Package (EXTERNAL / NOT IN BUNDLE) | PRE-FORM trigger (Form); KEY-EXIT trigger (Form) | Registers the module name at form open and clears it at form exit in the active database session |

#### STOP_WATCH.STOP_TIMER

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| STOP_WATCH.STOP_TIMER | Database Package Procedure (EXTERNAL / NOT IN BUNDLE — package not in source bundle) | KEY-COMMIT trigger (Form) | Stops the application performance measurement timer and logs the elapsed time for the MCP enquiry save operation; only executed when application logging is enabled |

#### WEB.SHOW_DOCUMENT

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| WEB.SHOW_DOCUMENT | Oracle WebUtil Built-in (EXTERNAL / NOT IN BUNDLE) | CALL_REPORT_ENQ (Form-local Program Unit) | Opens the generated PDF report URL in a new browser window after PDF-destination report generation |

---

## 13. Package Procedure Specifications

*Behavioural requirements for each database package invoked from the form. Only packages referenced in the form XML that have a matching source ``.pck`` file in the input directory are listed. Descriptions are derived from the package bodies in the uploaded PCK sources.*

| ID | Package | Description | Business Requirement | Acceptance Criteria |
| :--- | :--- | :--- | :--- | :--- |
| BR-T-PKG-AMC | PKG_AMC | AMC enquiry processing engine — validates vehicle VIN eligibility, determines GST type from dealer/customer state, and populates package details with labour/parts/consumables rates, tax codes, and charge breakdowns | Form must validate vehicle eligibility and populate AMC package line items with accurate rates and tax amounts through centralised package logic | SP_VIN_VALIDATE rejects vehicles that are expired, restricted, or already enrolled; SP_GET_GST_TYPE determines SGST/CGST or IGST based on dealer vs customer state; SP_POP_PKG_DTL populates all line items with correct rates and charges |
| BR-T-PK-VALIDATE-BACK-DATE | Pk_Validate_Back_Date | Document number generation engine — generates unique sequential AMC enquiry document numbers with prefix/suffix formatting by locking and incrementing the document counter in the document master | Form must generate a unique, formatted AMC enquiry number for each new enquiry record at the time of save | Generate_Next_Num returns a formatted document number; fails with an error message when the document type is not configured or the document master is locked by another user |

**Total Matched Packages:** 2

---

## 14. Database Package Catalogue

*Detailed specifications for each database package routine called from the form, including signatures and business rules.*
**Source PCK file(s):** PKG_AMC.pck, PK_VALIDATE_BACK_DATE.pck

| Source File (.pck) | Package | Routine Name | Type | Definition (signature / excerpt) | Called From | Purpose |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| PKG_AMC.pck | PKG_AMC | SP_GET_GST_TYPE | Procedure | PROCEDURE SP_GET_GST_TYPE(p_pmc IN NUMBER, p_parent IN VARCHAR2, p_dealer IN NUMBER, p_loc IN VARCHAR2, p_reg_num IN VARCHAR2, p_gst_type OUT VARCHAR2, p_dlr_gst_state OUT VARCH... | Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.REG_NUM | Determines the GST type (S = SGST/CGST intra-state, I = IGST inter-state) for the AMC enquiry by comparing the dealer's state code against the customer's state from the customer master. If the customer is in a Special Economic Zone, IGST is forced. Returns the dealer and customer GST state codes and an error if the customer state is not configured. |
| PKG_AMC.pck | PKG_AMC | SP_POP_PKG_DTL | Procedure | PROCEDURE SP_POP_PKG_DTL(p_pmc IN NUMBER, p_parent IN VARCHAR2, p_dealer IN NUMBER, p_loc IN VARCHAR2, p_comp IN VARCHAR2, p_pkg_code IN VARCHAR2, p_reg_num IN VARCHAR2, p_gst_t... | Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_GEN_ENQ, Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_TCS_APPLY | Populates the global AMC detail and charge staging tables with package line items (labour operations, parts, consumables) sourced from the AMC rate master and applied with GST tax charges. Deletes previous staging data for the vehicle/package combination, then inserts new rows for each service type with HSN/SAC codes, sell prices, discount amounts, and tax breakdowns. Called each time the user generates the enquiry. |
| PKG_AMC.pck | PKG_AMC | SP_VIN_VALIDATE | Procedure | PROCEDURE SP_VIN_VALIDATE(P_PMC IN NUMBER, P_VIN IN VARCHAR2, P_DATE IN DATE, P_VEH_AGE OUT NUMBER, P_AVG_RUN OUT NUMBER, P_ERR_CD OUT NUMBER, P_ERR_MSG OUT VARCHAR2) | Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.REG_NUM | Validates vehicle eligibility for a new MCP/AMC enquiry. Checks that the VIN exists in the vehicle master, that no active MCP is already registered, that the enquiry date is within the allowed validity window (4 years of sale), that the odometer does not exceed the mileage limit, and that the vehicle is not in the restricted list. Returns vehicle age and average run. |
| PK_VALIDATE_BACK_DATE.pck | Pk_Validate_Back_Date | Generate_Next_Num | Procedure | PROCEDURE Generate_Next_Num ( pi_dealer_map_cd IN NUMBER, pi_principal_map_cd IN NUMBER, pi_loc_cd IN VARCHAR2, pi_comp_fa IN VARCHAR2, pi_doc_type IN VARCHAR2, po_doc_num OUT V... | FT_SAVE in Form | Generates the next sequential document number for a new AMC enquiry by locking the document counter row in AM_DOCS for the dealer/location/company/document-type/financial-year combination, incrementing the number, formatting it as prefix + suffix + zero-padded six-digit number, and updating the counter. Returns an error if the document type is not configured, has duplicate rows, or the row is locked by another session. |

**Total Matched Package Routines (called from form XML):** 4

---

**Function return values:**

| Function | Returns | Values | Description |
| :--- | :--- | :--- | :--- |
| — | N/A | N/A | *No matched package functions with documented return values in the available PCK sources.* |

---

## 15. PLD Procedure Call Sites

*Behaviour descriptions derived from ``DPL.pld``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ASK_CONFIRM | Function | Function(confirm_msg VARCHAR2) RETURN NUMBER | Trigger: FT_CANCEL in Form, Trigger: FT_DEL in Form | Presents a Yes/No confirmation dialog using the AL_CONFIRM alert with the supplied message text. Returns 1 when the user presses the first button (Yes/confirm) and 0 otherwise. Used before clearing unsaved data and before deleting a record. |
| CHECK_FORM_FAILURE | Procedure | Procedure() | Trigger: KEY-COMMIT in Form | Checks whether the most recent Oracle Forms built-in operation succeeded. If it failed due to a database error, displays the SQLERRM message; if a forms error, displays ERROR_TEXT. Raises FORM_TRIGGER_FAILURE to halt commit processing on failure. |
| CHECK_NULL | Procedure | Procedure(p_value IN VARCHAR2, column_title IN VARCHAR2) | Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_GEN_ENQ, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.EMP_CD, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.ODOMETER_READING, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.PKG_CODE, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.REG_NUM | Checks whether the supplied value is null. If null, displays an "Enter a valid {column_title}" error dialog via DISP_TEXT and raises FORM_TRIGGER_FAILURE to halt navigation. Enforces mandatory field validation for registration number, odometer reading, package code, and employee code. |
| DISP_TEXT | Procedure | Procedure(text_string VARCHAR2, title_string VARCHAR2) | ProgramUnit: SP_INSERT_CHARGES, Trigger: FT_SAVE in Form, Trigger: KEY-COMMIT in Form, Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: POST-QUERY in B_VH_AMC_ENQ, Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_GEN_ENQ, Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_TCS_APPLY, Trigger: WHEN-NEW-FORM-INSTANCE in Form, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.ODOMETER_READING, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.PKG_CODE, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.REG_NUM, Trigger: WHEN-VALIDATE-ITEM in CB_VT_AMC_ENQ.NB_ENQ_NUM | Displays a modal alert dialog to the user. Uses AL_ERRINFO (with error title) for error messages and AL_NOTE for informational messages. Sets the alert title and message text at runtime. Used as the sole mechanism for all user-visible error and information feedback across the form. |
| PROC_REPORT_CALL | Procedure | Procedure(REPID report_object, lv_report OUT varchar2, lv_print OUT varchar2) | ProgramUnit: CALL_REPORT_ENQ | Configures the report object for batch execution to a server-side file, sets the output file name using the current username and timestamp, submits the report job to the report server via RUN_REPORT_OBJECT, and returns the job handle and output file name for status polling. |
| PROC_TIMER | Procedure | Procedure() | ProgramUnit: CALL_REPORT_ENQ | Creates a repeating Oracle Forms timer named PRINTER_QUEUE with a 5-second interval for polling the report server job status after the report is submitted. |
| PROC_TIMER_EXPIRED | Procedure | Procedure() | Trigger: WHEN-TIMER-EXPIRED in Form | Handles the PRINTER_QUEUE timer event by checking the report job status. When the job finishes, displays the output document via web.show_document. Displays an error and deletes the timer if the report fails. |
| RAISE_ERROR | Procedure | Procedure(mesg_code IN VARCHAR2) | Trigger: ON-ERROR in Form | Formats an error code as a message text, displays it via DISP_TEXT with the appropriate title (Error, Note, or Caution), and raises FORM_TRIGGER_FAILURE for error-class messages. The message-table lookup is commented out; only the message code is displayed. |

**Total Active Routines:** 8 of 24 in DPL.pld source

---

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| ID | Service Name | Database Object | Input Parameters | Output | Business Function | API Endpoint Suggestion |
| -- | ------------ | --------------- | ---------------- | ------ | ----------------- | ----------------------- |
| MS-001 | MCP Package Rate Calculation | PKG_AMC.SP_POP_PKG_DTL | Principal, parent group, dealer, location, company FA, package code, registration number, GST type, dealer state code, customer state code, TCS applicability flag | Error code, error message; staged detail lines in GBL_AMC_DTL and GBL_AMC_CHARGES | Computes the full package rate breakdown (labour, parts, consumables) with applicable tax and TCS charge components for a given vehicle and package combination, and stages the results for display and saving | `POST /api/v1/mcp/package-rate-detail` |
| MS-002 | Vehicle Details Retrieval | SP_GET_VEH_DETAILS | Principal, parent group, dealer, location, registration number (or VIN) | VIN, sub-variant code, variant code, colour code/description, chassis number, engine number, customer code, customer name, address lines, city code/description, phone, mobile, email, VIP flag, outstanding amount, vehicle master row, error code/message | Retrieves all vehicle identity, variant, and customer contact details from the vehicle and customer master tables for a given registration number | `GET /api/v1/vehicle/details?reg_num={reg_num}&dealer={dealer_cd}` |
| MS-003 | GST Type Determination | PKG_AMC.SP_GET_GST_TYPE | Principal, parent group, dealer, location, registration number | GST type (IGST or SGST/CGST), dealer state code, customer state code, SEZ flag, error code/message | Determines the applicable GST treatment for a MCP transaction based on the dealer's and customer's registered state codes and SEZ status | `GET /api/v1/mcp/gst-type?reg_num={reg_num}&dealer={dealer_cd}&loc={loc_cd}` |
| MS-004 | VIN MCP Eligibility Validation | PKG_AMC.SP_VIN_VALIDATE | Principal, VIN, enquiry date | Vehicle age (years), average annual run (km/year), error code, error message | Validates whether a vehicle is eligible to receive an MCP by checking existing active MCP coverage, model exclusions, restricted vehicle list, sale date availability, and the manufacturer-defined time and mileage window | `GET /api/v1/mcp/vin-validate?vin={vin}&enquiry_date={date}&principal={principal}` |
| MS-005 | MCP Document Number Generation | PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM | Dealer, principal, location, company FA, document type ("AME"), financial year, enquiry date | Next sequential document number, error code, error message | Generates and reserves the next sequential MCP enquiry document number by locking the document master sequence for the given dealer and financial year | `POST /api/v1/document/generate-number` |
| MS-006 | MCP Charge Line Insertion | VD_AMC_ENQCHARGES (via SP_INSERT_CHARGES logic) | Enquiry number, parent group, dealer, location, company FA, package code, registration number, user ID | Inserted charge line count or error | Copies all pre-computed tax and charge components from the package charge staging table into the persistent enquiry charge table for a completed MCP enquiry | `POST /api/v1/mcp/enquiry/{enq_num}/charges` |
| MS-007 | MCP Enquiry Report Generation | CALL_REPORT_ENQ (vr_amc_enq / vr_amc_enq_gst) | Principal, parent group, dealer, location, company FA, enquiry number | Report output (PDF binary or printer job handle) | Generates the MCP enquiry certificate using either the GST-compliant or legacy report template, based on the enquiry date, and delivers it to the specified output destination | `GET /api/v1/mcp/enquiry/{enq_num}/report?format=pdf` |
| MS-008 | Alphanumeric Registration Sanitisation | SP_VALIDATE_ALPHANUMERIC | Registration number string | Sanitised string (uppercase letters and digits only) | Strips any character from a vehicle registration number that is not a valid uppercase letter or digit, ensuring consistent formatting before vehicle master look-up | `POST /api/v1/vehicle/sanitise-registration` |

**Total Microservices Identified: 8**

---

## 17. Workflows

| ID | Workflow Name | Trigger Event | Steps | Decision Points | End State |
| -- | ------------- | ------------- | ----- | --------------- | --------- |
| WF-001 | MCP Programme Availability Check | Form opened (WHEN-NEW-FORM-INSTANCE) | 1. Query dealer location parameters for MCP deactivation flag. 2. If flag is "Y" (deactivated): display error and exit form. 3. If flag is "N" or not found: initialise form state (copyright, save parameter, window maximise). | Is MCP active for this dealer location? | Active: Form displays ready for enquiry entry. Inactive: Form closes immediately after error message. |
| WF-002 | Vehicle Registration and Eligibility Check | User tabs off the Registration Number field (WHEN-VALIDATE-ITEM on REG_NUM) | 1. Check registration number is not blank. 2. Strip non-alphanumeric characters. 3. Confirm exactly one vehicle match in the vehicle master. 4. Retrieve vehicle, variant, and customer details. 5. Determine GST type from dealer/customer state. 6. Validate VIN for MCP eligibility (existing MCP, model exclusions, restrictions, time/mileage window). | Is registration present? → Is the number unique in the vehicle master? → Does vehicle detail retrieval succeed? → Is customer GST state known? → Is the VIN eligible for MCP? | Success: All vehicle and customer details populated; GST type set; eligibility confirmed. Failure at any step: Error shown; user remains on Registration Number field. |
| WF-003 | Current Mileage Validation and Package Availability | User tabs off the Current Mileage field (WHEN-VALIDATE-ITEM on ODOMETER_READING) | 1. Check mileage is not blank. 2. Check mileage is not less than previous service mileage. 3. Query maximum validity parameters. 4. Check mileage does not exceed the maximum. 5. Check enquiry date is within the sale-date window. 6. Adjust vehicle age to minimum of 1. 7. Recalculate average daily run. 8. Check at least one applicable package exists. | Is mileage present? → Is it ≥ previous service mileage? → Is it ≤ maximum validity mileage? → Is the enquiry within the time window? → Does at least one package exist? | Success: Average run calculated; status indicator cleared; user can proceed to package selection. Failure: Appropriate error shown; save and generation blocked. |
| WF-004 | TCS Declaration and Package Rate Generation | User clicks Generate Enquiry button (WHEN-BUTTON-PRESSED on PB_GEN_ENQ) | 1. If package code already present: disable save/TCS buttons and show TCS screen (go to WF-005). 2. Check package code is not blank. 3. Show TCS information note and declaration alert. 4. Capture user's TCS response (applicable / not applicable / declined). 5. If declined: show error and stop. 6. Call PKG_AMC.SP_POP_PKG_DTL to compute rate breakdown with TCS flag. 7. If error from procedure: show error and stop. 8. Call POP_PKG_DETAILS_NEW to populate detail block. 9. Navigate to Package Amount field. | Is package code blank? → Did user declare TCS applicable or not? → Did user decline declaration? → Did rate calculation succeed? | Success: Detail block populated with all line items and amounts; header totals set; user can proceed to save. Failure: Error shown at the failing step; generation stopped. |
| WF-005 | TCS Rate Selection and Detail Refresh | User selects TCS rate on TCS screen and clicks Generate Enquiry (WHEN-RADIO-CHANGED + PB_TCS_RATE_N / PB_TCS_RATE_H + PB_TCS_APPLY) | 1. User selects Yes/No on TCS radio: sets TCS flags and enables/disables rate buttons. 2. User selects Normal Rate or Higher Rate: records TCS rate and enables Generate Enquiry. 3. User clicks Generate Enquiry: calls PKG_AMC.SP_POP_PKG_DTL with updated TCS flag. 4. If error: show error and stop. 5. Call POP_PKG_DETAILS_NEW; enable Save button; navigate to Package Amount. | Did user select TCS applicable? → Did user choose Normal or Higher rate? → Did rate recalculation succeed? | Success: Detail lines refreshed with TCS charges; Save button enabled. Failure: Error shown; save remains disabled. |
| WF-006 | MCP Enquiry Save with Number Generation and Report Print | User activates save (FT_SAVE / KEY-COMMIT) | 1. Check package amount is present. 2. If no enquiry number: call PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM to get next number; on error stop. 3. On success: assign enquiry number. 4. Invoke KEY-COMMIT: call SP_INSERT_CHARGES to insert charge lines. 5. COMMIT_FORM; check for form failure. 6. Log performance stop if logging enabled. 7. COMMIT_FORM again; check for form failure. 8. Display enquiry number confirmation note. 9. Call CALL_REPORT_ENQ to generate and deliver report. 10. Clear form for new entry. | Is package amount present? → Is a document number needed? → Did number generation succeed? → Did charge insert succeed? → Did commit succeed? → Which report template (GST or pre-GST)? → Which output method (PDF, Printer, Cancel)? | Success: Enquiry saved; confirmation note shown; report delivered; form cleared. Failure: Error shown at failing step; enquiry not saved. |
| WF-007 | MCP Enquiry Record Retrieval and Display | User enters an existing enquiry number and navigates to the data block (WHEN-VALIDATE-ITEM on NB_ENQ_NUM + WHEN-NEW-BLOCK-INSTANCE on B_VH_AMC_ENQ) | 1. Validate enquiry number against the enquiry register. 2. If not found: show error; keep focus on field. 3. If found: execute queries for header and detail blocks. 4. POST-QUERY triggers enrich header fields and repopulate detail block. 5. Lock editing fields (Registration Number, Enquiry Number, Mileage, Generate Enquiry button, Save button, Executive field). | Does the enquiry number match a saved record? → Did the query succeed? | Success: All saved enquiry data displayed; key fields locked; user can view the enquiry and print the report. Failure: Error shown; user remains on the enquiry number field. |
| WF-008 | Report Print Job Monitoring | Printer-queue polling timer fires (WHEN-TIMER-EXPIRED) | 1. Identify the timer as the PRINTER_QUEUE timer. 2. Query the report server for the print job status. 3. If still running: no action; timer continues. 4. If finished: open the print output in the browser and delete the timer. 5. If error: display error message and delete the timer. | Is the timer the printer queue timer? → Is the job still running? → Did the job finish successfully? | Success: Print output opened in browser; timer stopped. Failure: Error message shown; timer stopped. |

**Total Workflows Identified: 8**

---

## 18. PLD-Backed Logic

*Maps shared library routines to their business function and suggested API contracts.*

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | ASK_CONFIRM | Business Logic | Trigger: FT_CANCEL in Form, Trigger: FT_DEL in Form | /api/v1/pld/ask_confirm | Prompts the user to confirm destructive actions (cancel with unsaved data, record delete) before proceeding |
| PLD-002 | CHECK_FORM_FAILURE | Validation | Trigger: KEY-COMMIT in Form | /api/v1/pld/check_form_failure | When the preceding form operation fails, then commit processing is halted and the error message is displayed |
| PLD-003 | CHECK_NULL | Validation | Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_GEN_ENQ, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.EMP_CD, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.ODOMETER_READING, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.PKG_CODE, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.REG_NUM | /api/v1/pld/check_null | Rejects null values in mandatory fields and displays a field-specific validation error to the user |
| PLD-004 | DISP_TEXT | Business Logic | ProgramUnit: SP_INSERT_CHARGES, Trigger: FT_SAVE in Form, Trigger: KEY-COMMIT in Form, Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: POST-QUERY in B_VH_AMC_ENQ, Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_GEN_ENQ, Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_TCS_APPLY, Trigger: WHEN-NEW-FORM-INSTANCE in Form, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.ODOMETER_READING, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.PKG_CODE, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.REG_NUM, Trigger: WHEN-VALIDATE-ITEM in CB_VT_AMC_ENQ.NB_ENQ_NUM | /api/v1/pld/disp_text | Displays modal error or informational messages to the user as the sole messaging mechanism across all form triggers and program units |
| PLD-005 | PROC_REPORT_CALL | Business Logic | ProgramUnit: CALL_REPORT_ENQ | /api/v1/pld/proc_report_call | Submits the AMC enquiry report to the report server in batch mode and returns the job handle for status monitoring |
| PLD-006 | PROC_TIMER | Business Logic | ProgramUnit: CALL_REPORT_ENQ | /api/v1/pld/proc_timer | Starts a repeating 5-second timer to poll the report server for the completed report job |
| PLD-007 | PROC_TIMER_EXPIRED | Business Logic | Trigger: WHEN-TIMER-EXPIRED in Form | /api/v1/pld/proc_timer_expired | Checks report job status on each timer tick and delivers the output document to the browser when the job completes |
| PLD-008 | RAISE_ERROR | Validation | Trigger: ON-ERROR in Form | /api/v1/pld/raise_error | Converts an error code to a user message and raises FORM_TRIGGER_FAILURE for error-class messages to block further processing |

---

---

## 19. PCK-Backed Logic

*Maps database package routines to their business rules and suggested API contracts.*

| ID | Package.Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ------------- | ---- | ---------- | ------------- | --------------------- |
| PCK-001 | PKG_AMC.SP_GET_GST_TYPE | Validation | Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.REG_NUM | /api/v1/packages/pkg_amc/sp_get_gst_type | When the dealer and customer states differ or the customer is SEZ-registered, then IGST is applied; otherwise SGST/CGST applies |
| PCK-002 | PKG_AMC.SP_POP_PKG_DTL | Business Logic | Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_GEN_ENQ, Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_TCS_APPLY | /api/v1/packages/pkg_amc/sp_pop_pkg_dtl | When a package is selected for a vehicle, then the package line items with rates, discounts, HSN/SAC codes, and tax charges are populated in the staging tables for display and commit |
| PCK-003 | PKG_AMC.SP_VIN_VALIDATE | Validation | Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.REG_NUM | /api/v1/packages/pkg_amc/sp_vin_validate | When a vehicle registration number is entered, then eligibility for a new MCP is checked and rejected if the vehicle is expired, restricted, already enrolled, or outside the sale validity window |
| PCK-004 | Pk_Validate_Back_Date.Generate_Next_Num | Business Logic | FT_SAVE in Form | /api/v1/packages/pk_validate_back_date/generate_next_num | When a new AMC enquiry is saved, then the next sequential formatted document number is generated and assigned by incrementing the locked document counter |

---

---

## 20. System Interfaces

### 20.1 Database Integrations

| Interface Name | Type | Purpose | Data Flow | Error Handling |
| -------------- | ---- | ------- | --------- | -------------- |
| MCP Enquiry Header (VH_AMC_ENQ) | Oracle Forms Base-Table Block | Stores and retrieves MCP enquiry header records including vehicle, customer, package, pricing, TCS, and audit fields | Form → DB (INSERT / UPDATE); DB → Form (SELECT / POST-QUERY enrichment) | PRE-INSERT/PRE-UPDATE stamp audit fields; ON-ERROR intercepts commit failures; concurrent-update conflicts detected via error codes 40654–40659 |
| MCP Enquiry Detail Lines (VD_AMC_ENQ) | Oracle Forms Base-Table Block | Stores and retrieves itemised package service lines (labour, parts, consumables) linked to the header enquiry | Form → DB (INSERT / UPDATE); DB → Form (SELECT / POST-QUERY enrichment) | PRE-INSERT/PRE-UPDATE stamp audit fields; ON-ERROR intercepts failures |
| MCP Enquiry Charge Lines (VD_AMC_ENQCHARGES) | Direct INSERT via SP_INSERT_CHARGES | Stores pre-computed tax and charge components for each detail line at commit time | Form → DB (INSERT via SP_INSERT_CHARGES) | SP_INSERT_CHARGES displays *"Error... In Tax Calculation"* on exception; FORM_TRIGGER_FAILURE raised to abort commit |
| Package Detail Staging (GBL_AMC_DTL) | Direct SELECT / DELETE via PKG_AMC.SP_POP_PKG_DTL | Temporary staging table used by SP_POP_PKG_DTL to hold computed package detail lines before they are read by POP_PKG_DETAILS_NEW | DB → Form (read by POP_PKG_DETAILS_NEW); DB (delete-and-reinsert by SP_POP_PKG_DTL) | Error code returned from SP_POP_PKG_DTL if no rate lines found |
| Package Charge Staging (GBL_AMC_CHARGES) | Direct SELECT / DELETE via PKG_AMC.SP_POP_PKG_DTL and SP_INSERT_CHARGES | Temporary staging table holding computed tax/charge components; read by SP_INSERT_CHARGES at commit to populate VD_AMC_ENQCHARGES | DB (delete-and-reinsert by SP_POP_PKG_DTL); DB → DB (SELECT-INSERT by SP_INSERT_CHARGES) | Exception handling in SP_INSERT_CHARGES on insert failure |
| Vehicle Master (GM_VIN) | Direct SELECT via SP_GET_VEH_DETAILS and trigger code | Provides vehicle identity, sale date, last odometer reading, model, and variant for a given registration number | DB → Form (SP_GET_VEH_DETAILS and WHEN-VALIDATE-ITEM lookups) | Errors surfaced via SP_GET_VEH_DETAILS error code; NO_DATA_FOUND raises *"Registration Number Not Found"*; TOO_MANY_ROWS raises *"More than one Registration Number found"* |
| Customer Master (GM_CIN) | Direct SELECT via SP_GET_VEH_DETAILS and SP_GET_GST_TYPE | Provides customer profile (name, address, city, phone, email, GST number, PAN, SEZ flag) | DB → Form | Errors surfaced via procedure error codes; silent failures in POST-QUERY enrichment |
| Package Master (VM_AMC_PKG / VM_AMC_PKG_MOD) | Direct SELECT (LOV record group and WHEN-VALIDATE-ITEM) | Provides list of eligible MCP packages; also used to validate package eligibility against vehicle profile | DB → Form (LOV and eligibility check) | WHEN OTHERS exception handled silently in eligibility check; error code 1 from SP_POP_PKG_DTL when no rate defined |
| Package Rate Master (VM_AMC_RATE) | Direct SELECT via POP_PKG_DETAILS and SP_POP_PKG_DTL | Provides service rates for each package/model/variant/city combination | DB → Staging (via SP_POP_PKG_DTL) | Error code 1 returned if no rate lines found |
| Document Number Master (AM_DOCS) | SELECT FOR UPDATE / UPDATE via PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM | Maintains and generates sequential MCP enquiry document numbers | DB → Form (generated number returned); DB (sequence updated) | Lock contention, missing master, and duplicate rows handled with specific error messages |
| Dealer Location Parameters (AM_DEALER_LOC_PARAM) | Direct SELECT in WHEN-NEW-FORM-INSTANCE | Checks whether the MCP programme is active or deactivated for the current dealer | DB → Form (mcp_deactivate_flag) | WHEN OTHERS defaults to treating MCP as active |
| Employee Master (GM_EMP) | Direct SELECT (LOV record group RG_EXEC and POST-QUERY enrichment) | Provides active service executives at the current dealer location; also resolves executive name on retrieval | DB → Form | Silent failure on POST-QUERY enrichment if executive not found |
| GST Configuration (AM_LIST_RANGE) | Direct SELECT in various triggers and CALL_REPORT_ENQ | Provides GST implementation date, enquiry status descriptions, category types, and part group types | DB → Form | WHEN OTHERS handled silently; defaults applied where appropriate |
| State Master (GM_STATE) | Direct SELECT in REG_NUM validation and POST-QUERY | Provides customer and dealer GST state code and description | DB → Form | Silent failure if state not found |
| City Master (GM_CITY) | Direct SELECT in POST-QUERY | Provides city description for display | DB → Form | Falls back to city code value if look-up fails |
| MCP Validity Parameters (VM_AMC_PARAM) | Direct SELECT in ODOMETER_READING validation | Provides maximum validity mileage and validity months for MCP eligibility | DB → Form | Failures handled by WHEN OTHERS; defaults applied |

### 20.2 External System Integrations

| System Name | Integration Type | Purpose | Protocol | Endpoint | Data Exchange | Success / Error Codes |
| ----------- | ---------------- | ------- | -------- | -------- | ------------- | --------------------- |
| Oracle Reports Server | Report submission | Submits AMC enquiry report jobs to the report server and receives job handle and PDF output file name | Oracle Reports runtime API (RUN_REPORT_OBJECT / PROC_REPORT_CALL) | Global report server (`:GLOBAL.REP_SERVER` — INFERRED from runtime global) | Report parameters outbound (P_PARENT, P_PRINCIPAL, P_COMP_FA, P_DEALER, P_LOC, P_ENQ_NUM, REPORT_DESTYPE, MODE, BLANKPAGES); job handle and output file name inbound | Job handle returned in GLOBAL.REPORTHANDLE; output file in GLOBAL.PRINTOUTPUT; polling via WHEN-TIMER-EXPIRED; no explicit error codes documented in source |
| Oracle WebUtil (WEB.SHOW_DOCUMENT) | Browser URL launch | Opens the generated PDF report URL in a new browser window after the Oracle Reports Server job completes | Oracle WebUtil browser API | Report servlet URL constructed from report server job ID (INFERRED format) | URL string outbound to browser; no inbound data exchange | WEB.SHOW_DOCUMENT returns no explicit error code; failures are handled silently in CALL_REPORT_ENQ |

### 20.3 Report Integrations

| Report Name | Report Server | Parameters | Output Format | Trigger |
| ----------- | ------------- | ---------- | ------------- | ------- |
| vr_amc_enq | Global report server (`:GLOBAL.REP_SERVER` — INFERRED) | P_PARENT (parent group), P_PRINCIPAL (principal), P_COMP_FA (company FA), P_DEALER (dealer code), P_LOC (location code), P_ENQ_NUM (enquiry number), REPORT_DESTYPE (FILE or PRINTER), MODE (BITMAP or CHARACTER), BLANKPAGES (NO) | PDF (FILE destination) or Printer character output (PRINTER destination) — selected by user at runtime | FT_PRINT trigger (Form) and KEY-COMMIT trigger (Form) via CALL_REPORT_ENQ; used when the enquiry date is before the GST implementation date |
| vr_amc_enq_gst | Global report server (`:GLOBAL.REP_SERVER` — INFERRED) | P_PARENT, P_PRINCIPAL, P_COMP_FA, P_DEALER, P_LOC, P_ENQ_NUM, REPORT_DESTYPE, MODE, BLANKPAGES | PDF (FILE destination) or Printer character output (PRINTER destination) — selected by user at runtime | FT_PRINT trigger (Form) and KEY-COMMIT trigger (Form) via CALL_REPORT_ENQ; used when the enquiry date is on or after the GST implementation date |

---

## 21. Procedure and Function Business Rule Catalogue

End-to-end business requirement specification for every stored procedure and function referenced by the VT_AMC_ENQ form.

### 21.1 Catalogue Index

44 procedures/functions — each SP ID links to its detailed specification in §21.2.

| SP Index | Routine Name |
| :--- | :--- |
| [SP-001](#SP-001--CALL_REPORT_ENQ) | CALL_REPORT_ENQ |
| [SP-002](#SP-002--POP_PKG_DETAILS_NEW) | POP_PKG_DETAILS_NEW |
| [SP-003](#SP-003--SP_INSERT_CHARGES) | SP_INSERT_CHARGES |
| [SP-004](#SP-004--D2KWUTIL.ATTEMPT_DLL_LOAD) | D2KWUTIL.ATTEMPT_DLL_LOAD |
| [SP-005](#SP-005--D2KWUTIL.CREATED_DATE) | D2KWUTIL.CREATED_DATE |
| [SP-006](#SP-006--D2KWUTIL.D2KWUTIL_DEBUGSTRING) | D2KWUTIL.D2KWUTIL_DEBUGSTRING |
| [SP-007](#SP-007--D2KWUTIL.D2KWUTIL_FILEINFO) | D2KWUTIL.D2KWUTIL_FILEINFO |
| [SP-008](#SP-008--D2KWUTIL.FILE_INFO) | D2KWUTIL.FILE_INFO |
| [SP-009](#SP-009--D2KWUTIL.TRANSLATETYPE) | D2KWUTIL.TRANSLATETYPE |
| [SP-010](#SP-010--GENERAL.ASK_CONFIRM) | GENERAL.ASK_CONFIRM |
| [SP-011](#SP-011--GENERAL.CHECK_FORM_FAILURE) | GENERAL.CHECK_FORM_FAILURE |
| [SP-012](#SP-012--GENERAL.CHECK_NULL) | GENERAL.CHECK_NULL |
| [SP-013](#SP-013--GENERAL.DISP_TEXT) | GENERAL.DISP_TEXT |
| [SP-014](#SP-014--GENERAL.PROC_REPORT_CALL) | GENERAL.PROC_REPORT_CALL |
| [SP-015](#SP-015--GENERAL.PROC_TIMER) | GENERAL.PROC_TIMER |
| [SP-016](#SP-016--GENERAL.PROC_TIMER_EXPIRED) | GENERAL.PROC_TIMER_EXPIRED |
| [SP-017](#SP-017--GENERAL.RAISE_ERROR) | GENERAL.RAISE_ERROR |
| [SP-018](#SP-018--PKG_AMC.SP_GET_GST_TYPE) | PKG_AMC.SP_GET_GST_TYPE |
| [SP-019](#SP-019--PKG_AMC.SP_POP_PKG_DTL) | PKG_AMC.SP_POP_PKG_DTL |
| [SP-020](#SP-020--PKG_AMC.SP_VIN_VALIDATE) | PKG_AMC.SP_VIN_VALIDATE |
| [SP-021](#SP-021--PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM) | PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM |
| [SP-022](#SP-022--WEBUTIL.ERRORALERT) | WEBUTIL.ERRORALERT |
| [SP-023](#SP-023--WEBUTIL.FCLOSE) | WEBUTIL.FCLOSE |
| [SP-024](#SP-024--WEBUTIL.FOPEN) | WEBUTIL.FOPEN |
| [SP-025](#SP-025--WEBUTIL.GETIMPLCLASS) | WEBUTIL.GETIMPLCLASS |
| [SP-026](#SP-026--WEBUTIL.GETPROPERTY) | WEBUTIL.GETPROPERTY |
| [SP-027](#SP-027--WEBUTIL.ID_NULL) | WEBUTIL.ID_NULL |
| [SP-028](#SP-028--WEBUTIL.LENGTH) | WEBUTIL.LENGTH |
| [SP-029](#SP-029--WEBUTIL.PUT_LINE) | WEBUTIL.PUT_LINE |
| [SP-030](#SP-030--WEBUTIL.REGISTER_FUNCTION) | WEBUTIL.REGISTER_FUNCTION |
| [SP-031](#SP-031--WEBUTIL.SETPROPERTY) | WEBUTIL.SETPROPERTY |
| [SP-032](#SP-032--WEBUTIL.WAIT) | WEBUTIL.WAIT |
| [SP-033](#SP-033--ADD_ERROR) | ADD_ERROR |
| [SP-034](#SP-034--ADD_EXTERNAL_ERRORS) | ADD_EXTERNAL_ERRORS |
| [SP-035](#SP-035--BOOLTOCHAR) | BOOLTOCHAR |
| [SP-036](#SP-036--CLEAN_ERROR_STACK) | CLEAN_ERROR_STACK |
| [SP-037](#SP-037--DEBUGLOG) | DEBUGLOG |
| [SP-038](#SP-038--REGISTER_FUNCTION_CALL) | REGISTER_FUNCTION_CALL |
| [SP-039](#SP-039--SETDEBUG) | SETDEBUG |
| [SP-040](#SP-040--SF_COPYRIGHT_DECLARATION) | SF_COPYRIGHT_DECLARATION |
| [SP-041](#SP-041--SP_GET_VEH_DETAILS) | SP_GET_VEH_DETAILS |
| [SP-042](#SP-042--SP_VALIDATE_ALPHANUMERIC) | SP_VALIDATE_ALPHANUMERIC |
| [SP-043](#SP-043--STRIPDIRSEP) | STRIPDIRSEP |
| [SP-044](#SP-044--WINDEBUG) | WINDEBUG |

---

### 21.2 Detailed Specifications

#### SP-001 — CALL_REPORT_ENQ

**Invoked From:**

- vt_amc_enq_fmb.xml [Trigger: FT_PRINT]
- vt_amc_enq_fmb.xml [Trigger: KEY-COMMIT]

---

**Screen:**

N/A

---

**Purpose**

Determines the correct AMC enquiry report template (GST or non-GST) based on the enquiry date relative to the GST implementation date, then presents the user with a choice to output the report as a PDF file or send it to a printer, executing the selected report delivery path accordingly.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| p_principal | VARCHAR2 | IN |
| p_parent | VARCHAR2 | IN |
| p_dealer | VARCHAR2 | IN |
| p_loc | VARCHAR2 | IN |
| p_comp_fa | VARCHAR2 | IN |
| p_enq_num | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.PROC_REPORT_CALL ([SP-014](#SP-014--GENERAL.PROC_REPORT_CALL)) — matched by member name (package unresolved)
- GENERAL.PROC_TIMER ([SP-015](#SP-015--GENERAL.PROC_TIMER)) — matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 — Query AM_LIST_RANGE for the GST implementation date (`GST_IMP_DATE`/`GST`) keyed on the supplied principal; if no row is found, default the date to NULL.
- Step 2 — Locate the report object named `REPORT_CALL` in the form.
- Step 3 — Compare the truncated enquiry date (`B_VH_AMC_ENQ.ENQ_DATE`) to the GST implementation date: if the enquiry date is on or after the GST date, select the GST-compliant report template (`vr_amc_enq_gst`); otherwise select the legacy template (`vr_amc_enq`).
- Step 4 — Display the alert `AL_REPORT` to prompt the user to choose a delivery method (Button 1 = PDF/file, Button 2 = Printer, any other = Cancel).
- Step 5 — **If the user selects Button 1 (PDF/file):** clear any pending message, set the report destination format to PDF, build the report parameter string with all supplied context values (`P_PARENT`, `P_PRINCIPAL`, `P_COMP_FA`, `P_DEALER`, `P_LOC`, `P_ENQ_NUM`) plus `REPORT_DESTYPE=FILE`, `MODE=BITMAP`, `BLANKPAGES=NO`, assign the report server and filename, run the report object, then display the generated PDF in a new browser window by constructing the Oracle Reports servlet URL with the job ID.
- Step 6 — **If the user selects Button 2 (Printer):** set the report filename to the chosen template, set the destination format to `wided` (character/printer mode), build the parameter string with the same context values plus `REPORT_DESTYPE=PRINTER`, `MODE=CHARACTER`, `BLANKPAGES=NO`, set the report server, then call `GENERAL.PROC_REPORT_CALL` to run the report and obtain the report handle and print output file name. Store these in globals `GLOBAL.REPORTHANDLE` and `GLOBAL.PRINTOUTPUT`, then start the printer queue polling timer by calling `GENERAL.PROC_TIMER`.
- Step 7 — **If the user selects any other button (Cancel):** clear any pending message and take no further action.

---

**Decision Points**

DP-001

Condition:
The enquiry date (`B_VH_AMC_ENQ.ENQ_DATE`, truncated) is on or after the GST implementation date retrieved from AM_LIST_RANGE.

TRUE:
The report filename is set to `vr_amc_enq_gst` (GST-compliant template).

FALSE:
The report filename is set to `vr_amc_enq` (legacy, non-GST template).

DP-002

Condition:
The user clicks Alert Button 1 on the `AL_REPORT` alert (PDF/file delivery).

TRUE:
The report is generated in PDF/BITMAP mode and displayed in a new browser window via the Oracle Reports servlet URL.

FALSE:
Processing falls through to evaluate Button 2.

DP-003

Condition:
The user clicks Alert Button 2 on the `AL_REPORT` alert (Printer delivery).

TRUE:
The report is run in character/printer mode via `GENERAL.PROC_REPORT_CALL`; the report handle and print file are stored in globals and a polling timer is started via `GENERAL.PROC_TIMER`.

FALSE:
The alert response matched neither Button 1 nor Button 2 (i.e. Cancel); the pending message is cleared and no report is produced.

---

**Database Interactions**

- DB-001 — Read AM_LIST_RANGE — retrieve the GST implementation date for the given principal so the correct report template (GST vs. non-GST) can be selected based on the enquiry date.

---

**Business Rules**

- SBR-001 — The GST-compliant report template (`vr_amc_enq_gst`) must be used for any enquiry whose date falls on or after the GST implementation date stored in AM_LIST_RANGE for the principal; all earlier enquiries use the legacy template (`vr_amc_enq`).
- SBR-002 — If no GST implementation date is configured in AM_LIST_RANGE for the principal, the date defaults to NULL, which causes all enquiry date comparisons to evaluate as not meeting the GST threshold, defaulting to the legacy template.
- SBR-003 — The report is only executed after the user explicitly confirms a delivery method via the `AL_REPORT` alert; a Cancel response produces no report output.
- SBR-004 — For PDF delivery, the report runs in BITMAP mode with blank pages suppressed; for printer delivery, the report runs in CHARACTER mode with blank pages suppressed.
- SBR-005 — When printing, the report handle and generated print-file name are written to form globals (`GLOBAL.REPORTHANDLE`, `GLOBAL.PRINTOUTPUT`) so the printer queue timer can track and retrieve the output.

---

**Implementation Logic**

```plsql
PROCEDURE CALL_REPORT_ENQ(p_principal VARCHAR2,
												  p_parent 		VARCHAR2,
												  p_dealer 	  VARCHAR2,
                          p_loc 			VARCHAR2, 
                          p_comp_fa 	VARCHAR2,  
                          p_enq_num 	VARCHAR2
                         )IS
	repid  					REPORT_OBJECT;
	lv_rep  				VARCHAR2(100);
	lv_report_name 	VARCHAR2(50);
	lv_server 			VARCHAR2(20) := :global.rep_server;
	lv_alert 				VARCHAR2(20);
	l_v_Param				VARCHAR2(50);
	l_AlertId				ALERT;
	lv_param				VARCHAR2(100);
	lv_report       varchar2(2000);
	lv_print        varchar2(2000);
	LV_REP_FLAG			varchar2(1);
  ld_date			    DATE;
Begin
begin
	select to_date(list_from_range,'dd-mon-yyyy')
	  into ld_date
    from am_list_range
	 where principal_map_cd = p_principal
		 and list_name = 'GST_IMP_DATE'
		 and list_code = 'GST';
exception when others then
	ld_date := null;
end;	
	--Checking The Alert Button
	repid := Find_Report_Object('REPORT_CALL');
	if trunc(:B_VH_AMC_ENQ.ENQ_DATE) >= ld_date then
	  lv_report_name := 'vr_amc_enq_gst';
	else
		lv_report_name := 'vr_amc_enq';
	end if;
	l_AlertId := Find_Alert('AL_REPORT');
	lv_alert := Show_Alert(l_AlertId);
	If lv_alert = Alert_Button1 Then
    Clear_Message;
	  Set_Report_Object_Property(repid,Report_Desformat,'PDF');
		--Set_Report_Object_Property(repid,Report_Destype,'FILE');    
	  SET_REPORT_OBJECT_PROPERTY(repid,Report_Other,' P_PARENT='||p_parent||
                                                  ' P_PRINCIPAL='||to_number(p_principal)||
                                                  ' P_COMP_FA='||p_comp_fa||
                                                  ' P_DEALER='||to_number(p_dealer)||
                                                  ' P_LOC='||p_loc||
                                                  ' P_ENQ_NUM='||p_enq_num||
                                                  ' REPORT_DESTYPE =FILE'||
                                                  ' MODE=BITMAP BLANKPAGES=NO');		                                         
		Set_Report_Object_Property(repid,Report_Server,lv_server);
		Set_Report_Object_Property(repid,REPORT_FILENAME,lv_report_name);
    lv_rep := RUN_REPORT_OBJECT(repid);
    web.show_document('/reports/rwservlet/getjobid'||substr(lv_rep,instr(lv_rep,'_',-1)+1)||'?'||'server='||lv_server,'_blank');
	Elsif lv_alert = Alert_Button2 Then
		SET_REPORT_OBJECT_PROPERTY(repid,REPORT_FILENAME,lv_report_name);
		SET_REPORT_OBJECT_PROPERTY(repid,REPORT_DESFORMAT,'wided');
	  SET_REPORT_OBJECT_PROPERTY(repid,Report_Other,' P_PARENT='||p_parent||
                                                  ' P_PRINCIPAL='||to_number(p_principal)||
                                                  ' P_COMP_FA='||p_comp_fa||
                                                  ' P_DEALER='||to_number(p_dealer)||
                                                  ' P_LOC='||p_loc||
                                                  ' P_ENQ_NUM='||p_enq_num||
                                                  ' REPORT_DESTYPE =PRINTER'||
                                                  ' MODE=CHARACTER BLANKPAGES=NO');		                                         
	 	SET_REPORT_OBJECT_PROPERTY(repid,REPORT_SERVER,lv_server);
	 	general.PROC_REPORT_CALL (REPID,lv_report,lv_print);
	 	:global.reporthandle := lv_report;
		:global.printoutput  := lv_print;
        general.PROC_TIMER;	
	Else
		Clear_Message;
	End If;
End;

```

#### SP-002 — POP_PKG_DETAILS_NEW

**Invoked From:**

- vt_amc_enq_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

Package Details (N/A / CN_MAIN); TCS (WN_MAIN / CN_TCS)

---

**Purpose**

Populates the AMC enquiry package detail block (`B_VD_AMC_ENQ`) with all service-line items for the selected vehicle's package from GBL_AMC_DTL, then rolls up the individual line amounts into header-level summary totals on `B_VH_AMC_ENQ`, broken down by service type (Labour, Parts, Consumables) across amount, discount, tax, and net fields.

---

**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 — Navigate to the `B_VD_AMC_ENQ` block and clear it without validation to remove any previously loaded detail lines.
- Step 2 — Move to the first record position in the block.
- Step 3 — Open a cursor over GBL_AMC_DTL filtered by the current session context (parent group, dealer, location, company FA) and the enquiry's vehicle registration number and package code.
- Step 4 — For each row returned by the cursor, populate the corresponding `B_VD_AMC_ENQ` fields: serial number, service type, service code, quantity, discount percentage, rate, basic amount, discount amount, net amount, sell price, charge amount, HSN/SAC code, category code, group code, and the service/category/group descriptions.
- Step 5 — Accumulate overall package totals: add the row's sell price to `ln_pkg_amt`, discount amount to `ln_pkg_dis`, and net value to `ln_pkg_net`.
- Step 6 — Branch on the service type of the current row: if `'L'` (Labour), accumulate into the labour subtotals (`ln_lbr_amt`, `ln_lbr_dis`, `ln_lbr_tax`, `ln_lbr_net`); if `'P'` (Parts), accumulate into the parts subtotals (`ln_part_amt`, `ln_part_dis`, `ln_part_tax`, `ln_part_net`); if `'C'` (Consumables), accumulate into the consumables subtotals (`ln_cons_amt`, `ln_cons_dis`, `ln_cons_tax`, `ln_cons_net`).
- Step 7 — Advance to the next record in the block and continue the loop until all cursor rows are processed.
- Step 8 — Return focus to the first record in the block after the loop completes.
- Step 9 — Write the accumulated package and service-type summary totals back to the header block (`B_VH_AMC_ENQ`): package amount, labour/parts/consumable amounts, discount totals, total tax (sum of all three service-type tax amounts), individual service-type taxes, total bill amount, and individual service-type net amounts.

---

**Decision Points**

DP-001

Condition:
The current detail row's service type (`srv_type`) is `'L'` (Labour).

TRUE:
The row's sell price, discount amount, charge amount, and net value are added to the Labour running subtotals.

FALSE:
Processing falls through to check for service type `'P'`.

DP-002

Condition:
The current detail row's service type (`srv_type`) is `'P'` (Parts).

TRUE:
The row's sell price, discount amount, charge amount, and net value are added to the Parts running subtotals.

FALSE:
Processing falls through to check for service type `'C'`.

DP-003

Condition:
The current detail row's service type (`srv_type`) is `'C'` (Consumables).

TRUE:
The row's sell price, discount amount, charge amount, and net value are added to the Consumables running subtotals.

FALSE:
The row's amounts are not accumulated into any service-type subtotal (unrecognised service type); they are still included in the overall package totals accumulated in Step 5.

---

**Database Interactions**

- DB-001 — Read GBL_AMC_DTL — retrieve all service-line items (service type, code, quantities, pricing, discounts, taxes, and descriptions) for the selected vehicle's package within the current session context, to populate the enquiry detail block and compute summary totals.

---

**Business Rules**

- SBR-001 — Only package detail lines matching the current session context (parent group, dealer, location, company FA) and the specific vehicle registration number and package code are loaded into the detail block.
- SBR-002 — Service-type subtotals are maintained for exactly three recognised service types: Labour (`'L'`), Parts (`'P'`), and Consumables (`'C'`); lines with any other service type code contribute only to the overall package totals.
- SBR-003 — All accumulations use `NVL(..., 0)` to treat NULL amounts as zero, preventing NULL propagation in the summary totals.
- SBR-004 — The total tax amount written to the header (`NB_TAX_AMT`) is the arithmetic sum of the three individual service-type tax amounts (`ln_lbr_tax`, `ln_part_tax`, `ln_cons_tax`).

---

**Implementation Logic**

```plsql
PROCEDURE POP_PKG_DETAILS_NEW IS
	CURSOR cur_d IS
		SELECT *
		  FROM gbl_amc_dtl r
	   WHERE parent_group = :global.parent_group
	     AND dealer_map_cd = :global.dealer
	     AND loc_cd = :global.loc_cd
	     AND comp_fa = :global.comp_fa        
	     AND reg_num = :B_VH_AMC_ENQ.REG_NUM
	     AND pkg_code = :B_VH_AMC_ENQ.PKG_CODE;
  
  ln_pkg_amt   NUMBER(12,3) := 0;
  ln_lbr_amt   NUMBER(12,3) := 0;
  ln_part_amt  NUMBER(12,3) := 0;
  ln_cons_amt  NUMBER(12,3) := 0;  	     	     
	
	ln_pkg_dis   NUMBER(12,3) := 0;
  ln_lbr_dis   NUMBER(12,3) := 0;
  ln_part_dis  NUMBER(12,3) := 0;
  ln_cons_dis  NUMBER(12,3) := 0;  	    

  ln_lbr_tax   NUMBER(12,3) := 0;
  ln_part_tax  NUMBER(12,3) := 0;
  ln_cons_tax  NUMBER(12,3) := 0;  	    

	ln_pkg_net   NUMBER(12,3) := 0;
  ln_lbr_net   NUMBER(12,3) := 0;
  ln_part_net  NUMBER(12,3) := 0;
  ln_cons_net  NUMBER(12,3) := 0;  	       	     
BEGIN
	go_block('B_VD_AMC_ENQ');
	clear_block(NO_VALIDATE);
	first_record;
	FOR cur_i IN cur_d LOOP
		:B_VD_AMC_ENQ.SRL_NUM	 := cur_i.srl_num;
		:B_VD_AMC_ENQ.SRV_TYPE := cur_i.srv_type;
		:B_VD_AMC_ENQ.SRV_CODE := cur_i.srv_cd;	
		:B_VD_AMC_ENQ.QTY      := cur_i.qty;	
		:B_VD_AMC_ENQ.DISCOUNT_PER := cur_i.discount_per;	
		:B_VD_AMC_ENQ.RATE := cur_i.rate;	
		:B_VD_AMC_ENQ.BASIC_AMT := cur_i.sell_price;	
		:B_VD_AMC_ENQ.DISCOUNT_AMT := cur_i.discount_amt;	
		:B_VD_AMC_ENQ.NET_AMT := cur_i.net_value;		
		
		:B_VD_AMC_ENQ.SELL_PRICE := cur_i.sell_price;	
		:B_VD_AMC_ENQ.CHARGE_AMT := cur_i.charge_amt;	
		:B_VD_AMC_ENQ.HSN_SAC_CODE := cur_i.hsn_sac_cd;	
		
		:B_VD_AMC_ENQ.CATG_CD := cur_i.catg_cd;		
		:B_VD_AMC_ENQ.GROUP_CD := cur_i.group_cd;		
		:B_VD_AMC_ENQ.NB_SRV_DESC := cur_i.srv_desc;
		:B_VD_AMC_ENQ.NB_CATG_DESC := cur_i.catg_desc;
		:B_VD_AMC_ENQ.NB_GROUP_DESC := cur_i.group_desc;
		
		ln_pkg_amt := NVL(ln_pkg_amt, 0) + NVL(cur_i.sell_price, 0 );
		ln_pkg_dis := NVL(ln_pkg_dis, 0) + NVL(cur_i.discount_amt, 0 );
		ln_pkg_net := NVL(ln_pkg_net, 0) + NVL(cur_i.net_value, 0 );
		
		IF cur_i.srv_type = 'L' THEN
			ln_lbr_amt := NVL(ln_lbr_amt, 0) + NVL(cur_i.sell_price, 0 );
			ln_lbr_dis := NVL(ln_lbr_dis, 0) + NVL(cur_i.discount_amt, 0 );
			ln_lbr_tax := NVL(ln_lbr_tax, 0) + NVL(cur_i.charge_amt, 0 );
			ln_lbr_net := NVL(ln_lbr_net, 0) + NVL(cur_i.net_value, 0 );
	  ELSIF cur_i.srv_type = 'P' THEN
			ln_part_amt := NVL(ln_part_amt, 0) + NVL(cur_i.sell_price, 0 );
			ln_part_dis := NVL(ln_part_dis, 0) + NVL(cur_i.discount_amt, 0 );
			ln_part_tax := NVL(ln_part_tax, 0) + NVL(cur_i.charge_amt, 0 );
			ln_part_net := NVL(ln_part_net, 0) + NVL(cur_i.net_value, 0 );
		ELSIF cur_i.srv_type = 'C' THEN
			ln_cons_amt := NVL(ln_cons_amt, 0) + NVL(cur_i.sell_price, 0 );
			ln_cons_dis := NVL(ln_cons_dis, 0) + NVL(cur_i.discount_amt, 0 );
			ln_cons_tax := NVL(ln_cons_tax, 0) + NVL(cur_i.charge_amt, 0 );
			ln_cons_net := NVL(ln_cons_net, 0) + NVL(cur_i.net_value, 0 );
		END IF;				
		
		next_record;		
	END LOOP;	
	  first_record;
	  
	  :B_VH_AMC_ENQ.PKG_AMT    := ln_pkg_amt;
	  :B_VH_AMC_ENQ.LABOUR_AMT := ln_lbr_amt;
	  :B_VH_AMC_ENQ.PART_AMT   := ln_part_amt;
	  :B_VH_AMC_ENQ.CONSUMABLE_AMT := ln_cons_amt;

	  :B_VH_AMC_ENQ.DISCOUNT_AMT  := ln_pkg_dis;
	  :B_VH_AMC_ENQ.NB_LBR_DISC   := ln_lbr_dis;
	  :B_VH_AMC_ENQ.NB_PART_DISC  := ln_part_dis;
	  :B_VH_AMC_ENQ.NB_CONS_DISC  := ln_cons_dis;
	  
	  :B_VH_AMC_ENQ.NB_TAX_AMT   := NVL(ln_lbr_tax,0) + NVL(ln_part_tax,0) + NVL(ln_cons_tax,0);
	  :B_VH_AMC_ENQ.NB_LBR_TAX   := ln_lbr_tax;
	  :B_VH_AMC_ENQ.NB_PART_TAX  := ln_part_tax;
	  :B_VH_AMC_ENQ.NB_CONS_TAX  := ln_cons_tax;
	  
	  :B_VH_AMC_ENQ.TOT_BILL_AMT := ln_pkg_net;
	  :B_VH_AMC_ENQ.NB_LBR_NET   := ln_lbr_net;
	  :B_VH_AMC_ENQ.NB_PART_NET  := ln_part_net;
	  :B_VH_AMC_ENQ.NB_CONS_NET  := ln_cons_net;

END;
```

#### SP-003 — SP_INSERT_CHARGES

**Invoked From:**

- vt_amc_enq_fmb.xml [Trigger: KEY-COMMIT]

---

**Screen:**

N/A

---

**Purpose**

Copies all applicable charge lines for the current enquiry's vehicle and package from the global charges master (GBL_AMC_CHARGES) into the enquiry-specific charges table (VD_AMC_ENQCHARGES), stamping each inserted row with the current user and the current date/time.

---

**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- D2KWUTIL.CREATED_DATE ([SP-005](#SP-005--D2KWUTIL.CREATED_DATE)) — D2KWUTIL.pck (or .pld)
- GENERAL.DISP_TEXT ([SP-013](#SP-013--GENERAL.DISP_TEXT)) — matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 — Execute an `INSERT ... SELECT` statement that selects all charge lines from GBL_AMC_CHARGES matching the current session context (parent group, dealer, location, company FA) and the enquiry's vehicle registration number and package code.
- Step 2 — For each matching charge line, insert a new row into VD_AMC_ENQCHARGES carrying over all charge attributes (service type, service code, charge serial, common indicator, order serial, charge code, charge type, charge indicator, charge value, charge amount) and substituting the current enquiry number (`B_VH_AMC_ENQ.ENQ_NUM`), the logged-in user ID (`GLOBAL.USERID`), and the current system date/time (`SYSDATE`) as `created_date`.
- Step 3 — If any exception occurs during the insert, display the error message `'Error... In Tax Calculation'` with the title `'Error'` via `GENERAL.DISP_TEXT`, then raise `FORM_TRIGGER_FAILURE` to abort the commit.

---

**Decision Points**

DP-001

Condition:
An unhandled exception occurs during the INSERT operation.

TRUE:
Display the error message `'Error... In Tax Calculation'` to the user and raise `FORM_TRIGGER_FAILURE` to halt further processing.

FALSE:
The insert completes successfully and processing returns normally to the caller.

---

**Database Interactions**

- DB-001 — Read GBL_AMC_CHARGES — retrieve all charge lines for the current vehicle and package within the session context, to serve as the source rows for the enquiry charges insert.
- DB-002 — Insert into VD_AMC_ENQCHARGES — persist the charge lines against the current AMC enquiry number, recording the creating user and timestamp on each row.

---

**Business Rules**

- SBR-001 — Only charge lines that match the current session context (parent group, dealer, location, company FA) and the specific vehicle registration number and package code are copied to the enquiry charges table.
- SBR-002 — Each inserted charge row is stamped with the logged-in user (`GLOBAL.USERID`) and the current date/time (`SYSDATE`), establishing a creation audit trail.
- SBR-003 — Any failure during the charge insertion is treated as a tax calculation error; the user is notified and the entire commit is aborted via `FORM_TRIGGER_FAILURE`.

---

**Implementation Logic**

```plsql
PROCEDURE SP_INSERT_CHARGES IS
BEGIN
  INSERT INTO vd_amc_enqcharges (parent_group,
																 dealer_map_cd,
													 			 loc_cd,
																 comp_fa,
																 enq_num,
																 srl_num,
																 srv_type,
																 srv_cd,
																 charge_srl,
																 common_ind,
																 order_srl,
																 charge_cd,
																 charge_type,
																 charge_ind,
																 charge_value,
																 charge_amt,
																 created_by,
																 created_date
																 )
													SELECT parent_group,
																 dealer_map_cd,
																 loc_cd,
																 comp_fa,
																 :B_VH_AMC_ENQ.ENQ_NUM,
																 srl_num,
																 srv_type,
																 srv_cd,
																 charge_srl,
																 common_ind,
																 order_srl,
																 charge_cd,
																 charge_type,
																 charge_ind,
																 charge_value,
																 charge_amt,
																 :GLOBAL.USERID,
																 SYSDATE
                            FROM gbl_amc_charges
											 		 WHERE parent_group = :global.parent_group
													   AND dealer_map_cd = :global.dealer
													   AND loc_cd = :global.loc_cd
													   AND comp_fa = :global.comp_fa        
													   AND reg_num = :B_VH_AMC_ENQ.REG_NUM
													   AND pkg_code = :B_VH_AMC_ENQ.PKG_CODE;    
EXCEPTION WHEN OTHERS THEN
	general.disp_text ('Error... In Tax Calculation', 'Error');
	RAISE form_trigger_failure; 		
END;
```

#### SP-004 — D2KWUTIL.ATTEMPT_DLL_LOAD

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly — screen follows parent invocation site.)

---

**Purpose**

Attempts to load a named DLL from a specified file-system path via Oracle FFI, verifying the file's existence beforehand and optionally incrementing the global DLL load counter on success. It normalises the path by stripping any trailing separator and discarding everything after the first semicolon, so that only a clean single-path value is passed to the operating system.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| TargetPath | VARCHAR2 | IN OUT |
| TargetDLL | VARCHAR2 | IN |
| LoadCount | BOOLEAN | IN |

**Output Parameters**

| Output | Source | Datatype |
|--------|--------|---------|
| TargetPath | VARCHAR2 | IN OUT |

---

**Dependencies**

- DEBUGLOG ([SP-037](#SP-037--DEBUGLOG)) — matched by member name
- STRIPDIRSEP ([SP-043](#SP-043--STRIPDIRSEP)) — matched by member name

---

**Step-by-Step Business Logic**

- Step 1 — If `TargetPath` is non-null, normalise it: call `StripDirSep` to remove any trailing backslash and discard everything after a semicolon (taking only the first path token), then append a backslash to produce a clean directory path.
- Step 2 — Attempt to open the fully qualified file (`TargetPath || TargetDLL`) in read mode using `TEXT_IO.FOPEN`; immediately close it if successful, confirming the file exists at the specified location.
- Step 3 — If the file cannot be opened (any exception), log a debug entry identifying the DLL name and the path where it was not found, then raise the internal `BadLocation` exception to abort further loading.
- Step 4 — If the path is null, skip the existence check (Steps 1–3) and proceed directly to loading, relying on the OS search path to locate the DLL.
- Step 5 — Load the DLL via `ORA_FFI.LOAD_LIBRARY`, passing the (possibly null) path and DLL name; capture the returned library handle.
- Step 6 — If `LoadCount` is TRUE (the default), increment the global `DLL_LOAD_COUNT` counter and set `API_ENABLED := TRUE` to signal that the API is now available.
- Step 7 — Return the library handle to the caller.
- Step 8 — On any exception (including `BadLocation` or FFI errors not caught above): set `API_ENABLED := FALSE` and return a null handle to the caller, signalling that the load failed.

---

**Decision Points**

DP-001

Condition:
`TargetPath` is not null.

TRUE:
Normalise the path, verify the file exists, and then load the DLL from the specified location.

FALSE:
Skip path normalisation and file existence check; load the DLL using the OS default search path.

DP-002

Condition:
The file can be successfully opened via `TEXT_IO.FOPEN` at the constructed path.

TRUE:
Close the file immediately and proceed to load the DLL.

FALSE:
Log a debug message identifying the missing file location and raise `BadLocation` to abort.

DP-003

Condition:
`LoadCount` is TRUE.

TRUE:
Increment `DLL_LOAD_COUNT` and set `API_ENABLED := TRUE` after a successful load.

FALSE:
Load the DLL without updating the load counter or the API-enabled flag.

DP-004

Condition:
An exception occurs at any point (file not found, FFI error, `BadLocation`, etc.).

TRUE:
Set `API_ENABLED := FALSE` and return a null library handle to the caller.

FALSE:
Return the successfully obtained library handle.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 — Before loading, the DLL file's existence is verified by attempting to open it; a DLL that cannot be found at the specified path causes the load to be aborted.
- SBR-002 — If multiple paths are present in `TargetPath` (separated by semicolons), only the first path is used; all subsequent path entries are silently discarded.
- SBR-003 — A trailing backslash is always appended to the normalised path before constructing the fully qualified DLL file name.
- SBR-004 — The global `DLL_LOAD_COUNT` is incremented only when `LoadCount` is TRUE (the default), allowing callers to suppress the counter increment when performing a speculative or secondary load check.
- SBR-005 — Any failure during the load sequence results in `API_ENABLED` being set to FALSE and a null handle being returned, rather than an exception being propagated to the caller.

---

**Implementation Logic**

```plsql

FUNCTION  Attempt_DLL_Load  (TargetPath in out VARCHAR2, TargetDLL in VARCHAR2, LoadCount in BOOLEAN DEFAULT TRUE) return ORA_FFI.LibHandleType is
  hDLL  ORA_FFI.LibHandleType;
  hFile TEXT_IO.FILE_TYPE;
begin 
    	
  if TargetPath is not null then 
    -- Watch out for folks who put multiple Paths in here 
    -- Oh yes it's happened! Just use the first & throw the rest away
    -- Add trailing Directory Sep if required
    TargetPath := StripDirSep(TargetPath)||'\';
    
    -- Check that there is actually a file there.
    begin 
  	  hFile := TEXT_IO.FOPEN(TargetPath||TargetDLL,'R');
  	  TEXT_IO.FCLOSE(hFile);
    exception
  	  when others then
  	    Win_API_Debug.DebugLog(99,'Attempt_DLL_LOAD',TargetDLL||' not found in the specified location of "'||TargetPath||'"'); 
  		  raise BadLocation;
    end;
  end if;
  
  hDLL := ORA_FFI.LOAD_LIBRARY(TargetPath, TargetDLL);
  if LoadCount then 
    DLL_LOAD_COUNT  := DLL_LOAD_COUNT + 1;
    API_ENABLED  := TRUE;
  end if;
  return hDLL;
exception
  when others then 
    API_ENABLED := FALSE;
    return hDLL; /* Will be null */
end Attempt_DLL_Load;
```

#### SP-005 — D2KWUTIL.CREATED_DATE

**Invoked From:**

- vt_amc_enq_fmb.xml [StoredProcedure: SP_INSERT_CHARGES]

---

**Screen:**

-(Invoked indirectly — screen follows parent invocation site.)

---

**Purpose**

Retrieves the creation date and time (to millisecond precision) of a named file on the server by delegating the low-level file system query to `FILE_INFO`, then converts the raw integer buffers returned by that call into a typed Oracle `DATE` value and a millisecond offset for use by the caller.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| FileName | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

| Output | Source | Datatype |
|--------|--------|---------|
| ReturnDate | DATE | OUT |
| ReturnMS | NUMBER | OUT |

---

**Dependencies**

- D2KWUTIL.FILE_INFO ([SP-008](#SP-008--D2KWUTIL.FILE_INFO)) — D2KWUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 — Call `FILE_INFO` with the operation label `'Created_Date'`, the supplied file name, options `1` and `1`, and the caller's `RaiseExceptions` flag to populate the shared integer buffers (`iBuff3`–`iBuff9`) with the file's creation timestamp components.
- Step 2 — Assemble the `ReturnDate` output by converting buffers `iBuff3` through `iBuff8` (year, month, day, hour, minute, second) into an Oracle `DATE` using the mask `YYYYMMDDHH24MISS`.
- Step 3 — Set `ReturnMS` to the value in `iBuff9`, which holds the sub-second millisecond component of the creation timestamp.

---

**Decision Points**

No business-significant decision points in this routine.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 — Exception propagation is controlled by the caller via the `RaiseExceptions` parameter; when set to `TRUE`, any file-not-found or system error raised inside `FILE_INFO` is re-raised to the calling routine.
- SBR-002 — The creation timestamp is reconstructed from six discrete integer buffers (year through second) formatted as a fixed-width character string and parsed as `YYYYMMDDHH24MISS`; the millisecond component is returned separately in `ReturnMS`.

---

**Implementation Logic**

```plsql

PROCEDURE Created_Date (  FileName        IN   VARCHAR2,
                          ReturnDate      OUT  DATE,
                          ReturnMS        OUT  NUMBER,
                          RaiseExceptions IN   BOOLEAN DEFAULT FALSE) is
begin 
  File_Info('Created_Date',Filename,1,1,RaiseExceptions);
  ReturnDate := to_date(to_char(iBuff3,'0999')||to_char(iBuff4,'09')||to_char(iBuff5,'09')||to_char(iBuff6,'09')||to_char(iBuff7,'09')||to_char(iBuff8,'09'),'YYYYMMDDHH24MISS');
  ReturnMS   := iBuff9;
end Created_Date;
```

#### SP-006 — D2KWUTIL.D2KWUTIL_DEBUGSTRING

**Invoked From:**

- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly — screen follows parent invocation site.)

---

**Purpose**

Provides the PL/SQL declaration for the native C function `d2kwutil_DebugString`, which writes a text string to the Windows debug output stream via the d2kwutil DLL. This is a specification-only entry point: the actual execution is performed by the bound C implementation identified by pragma interface number 11265.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| hFunc | ORA_FFI.funcHandleType | IN |
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 — Accept the registered function handle (`hFunc`) and the text string to be output.
- Step 2 — Delegate execution entirely to the bound C implementation via the `PRAGMA INTERFACE(C, d2kwutil_DebugString, 11265)` declaration; the PL/SQL layer has no body of its own.

---

**Decision Points**

No business-significant decision points in this routine.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 — This routine is a thin PL/SQL wrapper over a native C function; all processing logic resides in the DLL identified by pragma interface 11265 and cannot be observed or modified in PL/SQL.

---

**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source — only its specification/declaration is shown below.
   
 PROCEDURE d2kwutil_DebugString (    hFunc       IN      ORA_FFI.funcHandleType,
                                     Text        IN      VARCHAR2);
 -- Pragmas
 PRAGMA INTERFACE(C,d2kwutil_DebugString,      11265);
```

#### SP-007 — D2KWUTIL.D2KWUTIL_FILEINFO

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.FILE_INFO]

---

**Screen:**

-(Invoked indirectly — screen follows parent invocation site.)

---

**Purpose**

Provides the low-level foreign-function interface declaration for the native `d2kwutil_FileInfo` DLL function, allowing the calling PL/SQL layer to pass a file name and option flags to the underlying Windows file-information utility and receive up to seven integer output values in return.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| hFunc | ORA_FFI.funcHandleType | IN |
| FileName | VARCHAR2 | IN OUT |
| Option1 | PLS_INTEGER | IN |
| Option2 | PLS_INTEGER | IN |
| dwOut1 | PLS_INTEGER | IN OUT |
| dwOut2 | PLS_INTEGER | IN OUT |
| dwOut3 | PLS_INTEGER | IN OUT |
| dwOut4 | PLS_INTEGER | IN OUT |
| dwOut5 | PLS_INTEGER | IN OUT |
| dwOut6 | PLS_INTEGER | IN OUT |
| dwOut7 | PLS_INTEGER | IN OUT |

**Output Parameters**

| Output | Source | Datatype |
|--------|--------|---------|
| FileName | VARCHAR2 | IN OUT |
| dwOut1 | PLS_INTEGER | IN OUT |
| dwOut2 | PLS_INTEGER | IN OUT |
| dwOut3 | PLS_INTEGER | IN OUT |
| dwOut4 | PLS_INTEGER | IN OUT |
| dwOut5 | PLS_INTEGER | IN OUT |
| dwOut6 | PLS_INTEGER | IN OUT |
| dwOut7 | PLS_INTEGER | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 — Accept the ORA_FFI function handle (`hFunc`), a file name, two option integers, and seven output integer slots as parameters.
- Step 2 — Delegate execution to the bound native DLL function via the ORA_FFI mechanism, passing all arguments directly to the underlying Windows file-information routine.
- Step 3 — Return the integer result code of the native function and populate the IN OUT parameters (`FileName`, `dwOut1`–`dwOut7`) with values written by the native call.

---

**Decision Points**

No business-significant decision points in this routine.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 — Only a specification/declaration is present in the available source; the implementation body is provided by the native DLL bound through ORA_FFI and is not visible in the PL/SQL layer.

---

**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source — only its specification/declaration is shown below.
                                                                                                                                                         
FUNCTION d2kwutil_FileInfo ( hFunc      IN      ORA_FFI.funcHandleType,
                             FileName   IN OUT  VARCHAR2,
                             Option1    IN      PLS_INTEGER,
                             Option2    IN      PLS_INTEGER,
                             dwOut1     IN OUT  PLS_INTEGER,
                             dwOut2     IN OUT  PLS_INTEGER,
                             dwOut3     IN OUT  PLS_INTEGER,
                             dwOut4     IN OUT  PLS_INTEGER,
                             dwOut5     IN OUT  PLS_INTEGER,
                             dwOut6     IN OUT  PLS_INTEGER,
                             dwOut7     IN OUT  PLS_INTEGER
                           ) return PLS_INTEGER;
```

#### SP-008 — D2KWUTIL.FILE_INFO

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CREATED_DATE]

---

**Screen:**

-(Invoked indirectly — screen follows parent invocation site.)

---

**Purpose**

Retrieves low-level file system metadata for a named file by invoking the native Windows API function `d2kwutil_FileInfo` through the D2KWUTIL OLE/DLL bridge, populating shared integer buffers with the resulting attributes (e.g. timestamps, sizes) for consumption by higher-level wrappers such as `CREATED_DATE`. Errors — including a missing file, a system call failure, or an unavailable API — are recorded on the error stack and optionally re-raised to the caller.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| CalledBy | VARCHAR2 | IN |
| FileName | VARCHAR2 | IN |
| Option1 | PLS_INTEGER | IN |
| Option2 | PLS_INTEGER | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-033](#SP-033--ADD_ERROR)) — matched by member name
- ADD_EXTERNAL_ERRORS ([SP-034](#SP-034--ADD_EXTERNAL_ERRORS)) — matched by member name
- BOOLTOCHAR ([SP-035](#SP-035--BOOLTOCHAR)) — matched by member name
- CLEAN_ERROR_STACK ([SP-036](#SP-036--CLEAN_ERROR_STACK)) — matched by member name
- D2KWUTIL.D2KWUTIL_FILEINFO ([SP-007](#SP-007--D2KWUTIL.D2KWUTIL_FILEINFO)) — D2KWUTIL.pck (or .pld) (specification only — no body found)
- DEBUGLOG ([SP-037](#SP-037--DEBUGLOG)) — matched by member name
- REGISTER_FUNCTION_CALL ([SP-038](#SP-038--REGISTER_FUNCTION_CALL)) — matched by member name

---

**Step-by-Step Business Logic**

- Step 1 — Log a debug entry at level 99 recording the caller name, file name, option values, and the stringified `RaiseExceptions` flag.
- Step 2 — Clear the error stack via `WIN_API.Clean_Error_Stack` and reset the return code `iRC` and all shared buffers (`iBuff1`–`iBuff9`) to zero.
- Step 3 — Check whether the Windows API is available (`WIN_API.API_ENABLED`); if not, raise `WIN_API.NOT_AVAILABLE` immediately.
- Step 4 — Register the `d2kwutil_FileInfo` DLL function call signature with `WIN_API.Register_function_call`.
- Step 5 — Pad the file name to 512 characters with a null terminator (`CHR(0)`) and set `iBuff1` and `iBuff2` to the supplied option values.
- Step 6 — Invoke the native DLL function `d2kwutil_FileInfo` via the registered function handle, passing the padded file name and both options; capture the return code in `iRC` and receive the file metadata results in `iBuff3`–`iBuff9`.
- Step 7 — Log a debug entry at level 99 with the return code and all buffer values.
- Step 8 — Evaluate the return code: if `iRC` is `0`, `-1074255551`, or `-1074245406` (codes indicating the file does not exist), record the error `'File <FileName> does not exist'` via `WIN_API.Add_error` and, if `RaiseExceptions` is TRUE, raise `NO_DATA_FOUND`.
- Step 9 — If `iRC` is any other non-1 value (unexpected system error), record a descriptive error message including the error code via `WIN_API.Add_error` and, if `RaiseExceptions` is TRUE, raise `NO_DATA_FOUND`.
- Step 10 — On `NO_DATA_FOUND` exception: re-raise to propagate the error to the caller.
- Step 11 — On `WIN_API.NOT_AVAILABLE` exception: add the standard "API not available" error via `WIN_API.Add_error` and re-raise.
- Step 12 — On any other exception: add a generic unexpected-error message (including any external errors) via `WIN_API.Add_error` and re-raise.

---

**Decision Points**

DP-001

Condition:
`WIN_API.API_ENABLED` is TRUE (the Windows DLL bridge is available).

TRUE:
Register the function call, invoke the DLL, and evaluate the return code.

FALSE:
Raise `WIN_API.NOT_AVAILABLE` immediately, bypassing all DLL interaction.

DP-002

Condition:
The DLL return code (`iRC`) is one of the known file-not-found values (`0`, `-1074255551`, or `-1074245406`).

TRUE:
Add a "file does not exist" error to the error stack; if `RaiseExceptions` is TRUE, raise `NO_DATA_FOUND`.

FALSE:
Proceed to check whether `iRC` indicates a different system error.

DP-003

Condition:
The DLL return code (`iRC`) is not `1` (success) and is not one of the known file-not-found codes.

TRUE:
Add a descriptive system-error message (including the numeric error code) to the error stack; if `RaiseExceptions` is TRUE, raise `NO_DATA_FOUND`.

FALSE:
The call returned `1` (success); no error is recorded and the buffers contain valid file metadata.

DP-004

Condition:
`RaiseExceptions` is TRUE when an error condition (file not found or system error) is detected.

TRUE:
Raise `NO_DATA_FOUND` to propagate the error to the calling routine.

FALSE:
Record the error on the stack but return normally, allowing the caller to inspect the error state.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 — The Windows API bridge must be available (`WIN_API.API_ENABLED = TRUE`) before any DLL call is attempted; if the bridge is unavailable the routine raises `WIN_API.NOT_AVAILABLE` without attempting any file system access.
- SBR-002 — All shared integer buffers (`iBuff1`–`iBuff9`) are zeroed at the start of every call to prevent stale data from a previous invocation from being returned to the caller.
- SBR-003 — Three distinct DLL return codes (`0`, `-1074255551`, `-1074245406`) are treated as "file does not exist" conditions; all other non-success codes are treated as unexpected system errors.
- SBR-004 — Errors are never silently swallowed; every error condition is recorded on the WIN_API error stack, and the caller controls whether the error is also raised as an exception via the `RaiseExceptions` parameter.
- SBR-005 — The file name is padded to exactly 512 characters with a null terminator before being passed to the DLL, matching the expected C-string buffer size of the native function.

---

**Implementation Logic**

```plsql

Procedure File_info ( CalledBy         IN  VARCHAR2,  
                      FileName         IN  VARCHAR2,
                      Option1          IN  PLS_INTEGER,
                      Option2          IN  PLS_INTEGER,
                      RaiseExceptions  IN BOOLEAN) is
 vcBuff1  varchar2(512);
 iRC      pls_integer;
begin
  Win_API_Debug.DebugLog(99,'File_Info','Args:  CalledBy="'||CalledBy||'", FileName="'||FileName||'", Option1='||to_char(Option1)||', Option2='||to_char(Option2)||', RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	  	
  WIN_API.Clean_Error_Stack;
  iRC    := 0;
  iBuff1 := 0;
  iBuff2 := 0;
  iBuff3 := 0;
  iBuff4 := 0;
  iBuff5 := 0;
  iBuff6 := 0;
  iBuff7 := 0;
  iBuff8 := 0;
  iBuff9 := 0;
  
  if WIN_API.API_ENABLED then 
    win_api.Register_function_call(iFileInfo,'d2kwutil_FileInfo','LONG','*CHAR,INT,INT,*LONG,*LONG,*LONG,*LONG,*LONG,*LONG,*LONG');
    vcBuff1 := RPAD(Filename,512,CHR(0));
    iBuff1  := Option1;
    iBuff2  := Option2;
    iRC     := d2kwutil_FileInfo(win_api.FunctionHandle(iFileInfo),vcBuff1,iBuff1,iBuff2,iBuff3,iBuff4,iBuff5,iBuff6,iBuff7,iBuff8,iBuff9);
    Win_API_Debug.DebugLog(99,'File_Info','Result:  RC='||to_char(iRC)||', iBuff1='||to_char(iBuff1)||', iBuff2='||to_char(iBuff2)||', iBuff3='||to_char(iBuff3)||', iBuff4='||to_char(iBuff4)||', iBuff5='||to_char(iBuff5)||', iBuff6='||to_char(iBuff6)||', iBuff7='||to_char(iBuff7)||', iBuff8='||to_char(iBuff8)||', iBuff9='||to_char(iBuff9));
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;
  if iRC in (0, -1074255551, -1074245406) then
    WIN_API.Add_error(CalledBy,'File '||FileName||' does not exist');
    if RaiseExceptions then 
      raise NO_DATA_FOUND;
    end if;
  elsif iRC <> 1 then 
    WIN_API.Add_error(CalledBy,'Gathering Information about '||FileName||' generated system error '||to_char(iRC));
    if RaiseExceptions then 
      raise NO_DATA_FOUND;
    end if;
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error(CalledBy,Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error(CalledBy, Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end;
```

#### SP-009 — D2KWUTIL.TRANSLATETYPE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly — screen follows parent invocation site.)

---

**Purpose**

Converts a human-readable C data-type name string into the corresponding Oracle FFI integer constant, so that callers can register DLL function parameters and return types using symbolic names rather than raw numeric codes.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| DataType | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 — Convert the input `DataType` string to upper case for a case-insensitive comparison.
- Step 2 — Match the upper-cased string against the supported type names in sequence and assign the corresponding Oracle FFI constant to the return variable:
  - `*CHAR` → `ORA_FFI.C_CHAR_PTR`
  - `CHAR` → `ORA_FFI.C_CHAR`
  - `*INT` → `ORA_FFI.C_INT_PTR`
  - `INT` → `ORA_FFI.C_INT`
  - `*LONG` → `ORA_FFI.C_LONG_PTR`
  - `LONG` → `ORA_FFI.C_LONG`
  - `*SHORT` or `*BYTE` → `ORA_FFI.C_SHORT_PTR`
  - `SHORT` or `BYTE` → `ORA_FFI.C_SHORT`
  - `*DOUBLE` → `ORA_FFI.C_DOUBLE_PTR`
  - `DOUBLE` → `ORA_FFI.C_DOUBLE`
  - `*VOID` → `ORA_FFI.C_VOID_PTR`
- Step 3 — Return the resolved FFI integer constant to the caller. If the input does not match any known type, the return variable is left at its default (null/uninitialized).

---

**Decision Points**

DP-001

Condition:
The upper-cased input matches one of the recognised type name tokens (`*CHAR`, `CHAR`, `*INT`, `INT`, `*LONG`, `LONG`, `*SHORT`/`*BYTE`, `SHORT`/`BYTE`, `*DOUBLE`, `DOUBLE`, `*VOID`).

TRUE:
Assign the corresponding `ORA_FFI` integer constant to the return variable.

FALSE:
No assignment is made; the return variable remains null (unrecognised type tokens are silently ignored).

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 — Type matching is case-insensitive; the input string is uppercased before comparison so that `*char`, `*CHAR`, and `*Char` are all treated identically.
- SBR-002 — The pointer variants (`*CHAR`, `*INT`, `*LONG`, `*SHORT`/`*BYTE`, `*DOUBLE`, `*VOID`) and their non-pointer counterparts are distinct types and map to different FFI constants.
- SBR-003 — `*SHORT` and `*BYTE` are treated as synonymous pointer types, both mapping to `ORA_FFI.C_SHORT_PTR`; similarly, `SHORT` and `BYTE` both map to `ORA_FFI.C_SHORT`.
- SBR-004 — An unrecognised type string does not raise an error; the function returns a null/uninitialised value, which the caller is responsible for handling.

---

**Implementation Logic**

```plsql
 
FUNCTION TranslateType(DataType in VARCHAR2) return PLS_INTEGER is
   -- Just a simple lookup of the types.
   vcType VARCHAR2(10) := UPPER(DataType);
   iRC    PLS_INTEGER;
begin 
  if vcType = '*CHAR' then 
    iRC := ORA_FFI.C_CHAR_PTR;
  elsif vcType = 'CHAR' then 
    iRC := ORA_FFI.C_CHAR;
  elsif vcType = '*INT' then 
    iRC := ORA_FFI.C_INT_PTR;
  elsif vcType = 'INT' then 
    iRC := ORA_FFI.C_INT;
  elsif vcType = '*LONG' then 
    iRC := ORA_FFI.C_LONG_PTR;
  elsif vcType = 'LONG' then 
    iRC := ORA_FFI.C_LONG;
  elsif vcType = '*SHORT' or vcType = '*BYTE'  then 
    iRC := ORA_FFI.C_SHORT_PTR;
  elsif vcType = 'SHORT' or vcType = 'BYTE' then 
    iRC := ORA_FFI.C_SHORT;
  elsif vcType = '*DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE_PTR;
  elsif vcType = 'DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE;  
  elsif vcType = '*VOID' then 
    iRC := ORA_FFI.C_VOID_PTR;      
  end if;
return iRC;
end TranslateType;
```

#### SP-010 — GENERAL.ASK_CONFIRM

**Invoked From:**

- vt_amc_enq_fmb.xml [Trigger: FT_CANCEL]
- vt_amc_enq_fmb.xml [Trigger: FT_DEL]

---

**Screen:**

N/A

---

**Purpose**

Prompts the user with a configurable confirmation message via the `AL_CONFIRM` alert and returns 1 if the user clicks the first button (confirm) or 0 if any other button is clicked (decline), allowing callers to gate destructive actions on explicit user approval.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| confirm_msg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 — Set the message text of the `AL_CONFIRM` alert to the supplied `confirm_msg`.
- Step 2 — Display the `AL_CONFIRM` alert and capture which button the user pressed.
- Step 3 — If the user pressed `ALERT_BUTTON1`, return 1 to indicate confirmation.
- Step 4 — If the user pressed any other button, return 0 to indicate the action was not confirmed.

---

**Decision Points**

DP-001

Condition:
The button pressed by the user equals `ALERT_BUTTON1`.

TRUE:
Return 1, signalling that the user confirmed the action.

FALSE:
Return 0, signalling that the user declined or cancelled the action.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 — Only `ALERT_BUTTON1` is treated as a positive confirmation; all other button responses (including dismissal) are treated as a denial.
- SBR-002 — The confirmation message is set dynamically each time the routine is called, so the alert always reflects the exact context-specific question supplied by the caller.

---

**Implementation Logic**

```plsql
FUNCTION ASK_CONFIRM( confirm_msg VARCHAR2)
                                      RETURN  NUMBER IS

    p_alert_name varchar2(10) := 'AL_CONFIRM' ;
    p_albtn_pressed number;
BEGIN
   set_alert_property(p_alert_name,alert_message_text,confirm_msg); 
   p_albtn_pressed := show_alert(p_alert_name);

   IF ( p_albtn_pressed = ALERT_BUTTON1 ) THEN
      return (1);
   ELSE
      return(0);
   END IF;
RETURN NULL; END;
```

#### SP-011 — GENERAL.CHECK_FORM_FAILURE

**Invoked From:**

- vt_amc_enq_fmb.xml [Trigger: KEY-COMMIT]

---

**Screen:**

N/A

---

**Purpose**

Inspects the Oracle Forms success/failure status after a form operation and, if the operation failed, displays the appropriate error message to the user (Oracle error message for ORA-type errors, Forms error text for FRM-type errors) before aborting the current trigger.

---

**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-013](#SP-013--GENERAL.DISP_TEXT)) — matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 — Check whether the most recent form operation succeeded using the built-in `form_success` function.
- Step 2 — If the form operation did not succeed, inspect `ERROR_TYPE` to determine the source of the error.
- Step 3 — If `ERROR_TYPE` is `'ORA'`, display the Oracle database error message (`SQLERRM`) with the title `'Error'` via `GENERAL.DISP_TEXT`.
- Step 4 — If `ERROR_TYPE` is `'FRM'`, display the Forms error text (`ERROR_TEXT`) with the title `'Error'` via `GENERAL.DISP_TEXT`.
- Step 5 — Raise `FORM_TRIGGER_FAILURE` to halt the calling trigger's execution after displaying the error.
- Step 6 — If the form operation succeeded, no action is taken and execution returns normally to the caller.

---

**Decision Points**

DP-001

Condition:
`form_success` returns FALSE (the preceding form operation failed).

TRUE:
Proceed to identify the error type and display an error message, then raise `FORM_TRIGGER_FAILURE`.

FALSE:
No error has occurred; return to the caller without any action.

DP-002

Condition:
`ERROR_TYPE` equals `'ORA'`.

TRUE:
Display the Oracle error message obtained from `SQLERRM` via `GENERAL.DISP_TEXT`.

FALSE:
Do not display the Oracle error message; check the next condition.

DP-003

Condition:
`ERROR_TYPE` equals `'FRM'`.

TRUE:
Display the Forms error text from `ERROR_TEXT` via `GENERAL.DISP_TEXT`.

FALSE:
No message is displayed for this error type.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 — A form operation failure always results in an error message being shown before the trigger is aborted; failures are never silently swallowed.
- SBR-002 — ORA-type errors surface the database error text (`SQLERRM`), while FRM-type errors surface the Forms-level error text (`ERROR_TEXT`), ensuring the user receives the most relevant description for each error source.

---

**Implementation Logic**

```plsql
PROCEDURE CHECK_FORM_FAILURE IS
BEGIN
 IF (NOT form_success) THEN
     IF ERROR_TYPE = 'ORA' THEN
        GENERAL.disp_text(SQLERRM,'Error');
     ELSIF ERROR_TYPE = 'FRM' THEN
        GENERAL.disp_text(ERROR_TEXT,'Error');
     END IF;
     raise form_trigger_failure;
  END IF; 

END;
```

#### SP-012 — GENERAL.CHECK_NULL

**Invoked From:**

- vt_amc_enq_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]
- vt_amc_enq_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

MCP Package Details (N/A / CN_MAIN); Package Details (N/A / CN_MAIN); Vehicle Details (N/A / CN_MAIN)

---

**Purpose**

Validates that a supplied field value is not null, displaying a descriptive error alert and aborting the current trigger if it is, so that mandatory fields on the MCP Package Details, Package Details, and Vehicle Details screens cannot be saved empty.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| P_value | VARCHAR2 | IN |
| column_title | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-013](#SP-013--GENERAL.DISP_TEXT)) — matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 — Construct a user-facing error message of the form `'Enter a valid <column_title>'` using the supplied column name.
- Step 2 — Check whether `P_value` is NULL.
- Step 3 — If `P_value` is NULL, display the constructed error message with the title `'Error'` via `GENERAL.DISP_TEXT`, then raise `FORM_TRIGGER_FAILURE` to abort the calling trigger.
- Step 4 — If `P_value` is not NULL, no action is taken and execution returns normally to the caller.

---

**Decision Points**

DP-001

Condition:
`P_value` IS NULL.

TRUE:
Display an error message prompting the user to enter a valid value for the named field, then raise `FORM_TRIGGER_FAILURE` to prevent further processing.

FALSE:
The value is present; return to the caller without any action.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 — A null field value is never silently accepted; it always results in a user-visible error and trigger abort.
- SBR-002 — The error message is constructed dynamically from `column_title`, ensuring the user is told exactly which field requires a value.

---

**Implementation Logic**

```plsql
PROCEDURE CHECK_NULL( P_value IN VARCHAR2, column_title  IN VARCHAR2) IS
mesg_text        varchar2(80) := 'Enter a valid '||column_title ;
BEGIN
   IF p_value IS null  THEN
      GENERAL.DISP_TEXT(mesg_text,'Error');
      raise form_trigger_failure;
   END IF;
END;
```

#### SP-013 — GENERAL.DISP_TEXT

**Invoked From:**

- vt_amc_enq_fmb.xml [ProgramUnit: SP_INSERT_CHARGES]
- DPL.pld [StoredProcedure: GENERAL.CHECK_FORM_FAILURE]
- DPL.pld [StoredProcedure: GENERAL.CHECK_NULL]
- DPL.pld [StoredProcedure: GENERAL.PROC_TIMER_EXPIRED]
- DPL.pld [StoredProcedure: GENERAL.RAISE_ERROR]
- vt_amc_enq_fmb.xml [StoredProcedure: SP_INSERT_CHARGES]
- vt_amc_enq_fmb.xml [Trigger: FT_SAVE]
- vt_amc_enq_fmb.xml [Trigger: KEY-COMMIT]
- vt_amc_enq_fmb.xml [Trigger: ON-ERROR]
- vt_amc_enq_fmb.xml [Trigger: ON-MESSAGE]
- vt_amc_enq_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]
- vt_amc_enq_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]
- vt_amc_enq_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

MCP Enquiry Details (N/A / CN_MAIN); MCP Package Details (N/A / CN_MAIN); Package Details (N/A / CN_MAIN); Vehicle Details (N/A / CN_MAIN); TCS (WN_MAIN / CN_TCS)

---

**Purpose**

Displays a modal alert to the user containing a supplied message and title, selecting between an error-style alert (`AL_ERRINFO`) and an informational alert (`AL_NOTE`) based on whether the title indicates an error condition.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| text_string | VARCHAR2 | IN |
| title_string | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 — Default the alert name to `AL_ERRINFO`.
- Step 2 — Compare the supplied `title_string` (uppercased) against the literal `'ERROR'`; if it matches, keep the alert name as `AL_ERRINFO`, otherwise switch it to `AL_NOTE`.
- Step 3 — Set the title property of the selected alert to `title_string`.
- Step 4 — Set the message-text property of the selected alert to `text_string`.
- Step 5 — Display the configured alert to the user and capture the button pressed (return value is discarded).

---

**Decision Points**

DP-001

Condition:
`UPPER(title_string)` equals `'ERROR'`.

TRUE:
Use the `AL_ERRINFO` alert, which presents the message with error styling.

FALSE:
Use the `AL_NOTE` alert, which presents the message with informational styling.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 — Alert type selection is determined solely by the uppercased value of `title_string`; any value other than `'ERROR'` results in the informational `AL_NOTE` alert being used.
- SBR-002 — Both the alert title and the alert message text are overwritten each time this routine is called, ensuring the displayed alert always reflects the most recently supplied values.

---

**Implementation Logic**

```plsql
PROCEDURE DISP_TEXT (text_string VARCHAR2,
                     title_string VARCHAR2 ) IS 
   p_alert_name varchar2(10) := 'AL_ERRINFO' ; 
   p_alert_id number;
BEGIN
   if upper(title_string)='ERROR' then
      p_alert_name := 'AL_ERRINFO' ; 
   else
      p_alert_name := 'AL_NOTE' ; 
   end if;
   set_alert_property(p_alert_name,TITLE,title_string);  
   set_alert_property(p_alert_name,alert_message_text,text_string);  
   p_alert_id := show_alert(p_alert_name); 
END;
```

#### SP-014 — GENERAL.PROC_REPORT_CALL

**Invoked From:**

- vt_amc_enq_fmb.xml [ProgramUnit: CALL_REPORT_ENQ]
- vt_amc_enq_fmb.xml [StoredProcedure: CALL_REPORT_ENQ]

---

**Screen:**

N/A

---

**Purpose**

Executes the configured report object in batch mode, directing its output to a uniquely named file on the server's printer spool directory, and returns the report job handle and the generated file name to the caller so that a downstream polling mechanism can retrieve and send the file to the printer.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| REPID | report_object | IN |

**Output Parameters**

| Output | Source | Datatype |
|--------|--------|---------|
| lv_report | varchar2 | OUT |
| lv_print | varchar2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 — Read the report server name from the `GLOBAL.REP_SERVER` form global.
- Step 2 — Construct a unique output file name by concatenating the current Oracle Forms user name with the current date/time (format `YYYYMMDDHHMISS`) and appending the `.rrpp` extension.
- Step 3 — Set the report execution mode to BATCH on the supplied report object.
- Step 4 — Set the report destination type to FILE on the report object.
- Step 5 — Set the report destination file path to `/iashome/ias/reports/printer/<filename>` on the report object.
- Step 6 — Assign the resolved report server to the report object.
- Step 7 — Run the report object and capture the returned job handle in `lv_report`.
- Step 8 — Return the generated file name in `lv_print` so the caller can store it for later printer queue processing.

---

**Decision Points**

No business-significant decision points in this routine.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 — The output file name must be unique per execution; uniqueness is guaranteed by combining the logged-in user name with a timestamp accurate to the second (`YYYYMMDDHHMISS`) and the `.rrpp` extension.
- SBR-002 — Reports submitted via this routine are always directed to the server-side printer spool directory (`/iashome/ias/reports/printer/`) rather than delivered directly to a browser, enabling asynchronous printer delivery.

---

**Implementation Logic**

```plsql

PROCEDURE PROC_REPORT_CALL (REPID report_object, lv_report OUT varchar2, lv_print OUT varchar2) IS
      vcFile    VARCHAR2(225) := 'test';
      vcResult  VARCHAR2(30);
      lv_server VARCHAR2(1000);
    Begin
    	  lv_server := name_in(':global.rep_server');
        vcFile:= Get_Application_Property(UserName)||To_Char(Sysdate,'YYYYMMDDHHMISS');
        vcFile := vcFile||'.rrpp';
         Set_Report_Object_Property(repid,REPORT_EXECUTION_MODE,BATCH);
        Set_Report_Object_Property(repid,REPORT_DESTYPE,FILE);
      	set_report_object_property(repid,REPORT_DESNAME,'/iashome/ias/reports/printer/'||vcFile);
				Set_Report_Object_Property(repid,REPORT_SERVER,lv_server); --'mulreports
			  lv_report:= RUN_REPORT_OBJECT(repid);
			  lv_print := vcFile;			  
End;
```

#### SP-015 — GENERAL.PROC_TIMER

**Invoked From:**

- vt_amc_enq_fmb.xml [ProgramUnit: CALL_REPORT_ENQ]
- vt_amc_enq_fmb.xml [StoredProcedure: CALL_REPORT_ENQ]

---

**Screen:**

N/A

---

**Purpose**

Starts a repeating Oracle Forms timer named `PRINTER_QUEUE` with a 5-second interval so that the form can periodically poll the printer spool for the report output file generated by the preceding print job.

---

**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 — Create a repeating timer named `PRINTER_QUEUE` with a 5,000-millisecond (5-second) interval using the Oracle Forms `CREATE_TIMER` built-in.

---

**Decision Points**

No business-significant decision points in this routine.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 — The printer queue polling timer fires every 5 seconds (`5000` milliseconds) and repeats indefinitely until cancelled, ensuring the form continues to monitor the printer spool after a report is submitted for printing.

---

**Implementation Logic**

```plsql
PROCEDURE PROC_TIMER IS
  hTimer    TIMER;
 begin
  hTimer := CREATE_TIMER('PRINTER_QUEUE','5000',REPEAT);
 end;
```

#### SP-016 — GENERAL.PROC_TIMER_EXPIRED

**Invoked From:**

- vt_amc_enq_fmb.xml [Trigger: WHEN-TIMER-EXPIRED]

---

**Screen:**

N/A

---

**Purpose**

Handles the expiry of the `PRINTER_QUEUE` timer by polling the current status of an asynchronous report job and, once the job finishes, opening the generated document in a new browser window; if the report fails for any reason, an error is displayed and the timer is cancelled.

---

**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-013](#SP-013--GENERAL.DISP_TEXT)) — matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 — Retrieve the name of the timer that just fired using `GET_APPLICATION_PROPERTY(TIMER_NAME)`.
- Step 2 — Read the current report job handle from `:GLOBAL.REPORTHANDLE` and the print-output path from `:GLOBAL.PRINTOUTPUT`.
- Step 3 — Check whether the timer name is `PRINTER_QUEUE`; only act if it is.
- Step 4 — Query the report server for the current job status using `REPORT_OBJECT_STATUS`.
- Step 5 — If the job is still running (`RUNNING`, `OPENING_REPORT`, or `ENQUEUED`), do nothing and allow the timer to continue firing.
- Step 6 — If the job status is `FINISHED`, open the completed document in a new browser window by navigating to `/printer/<print-output-path>`, then delete the `PRINTER_QUEUE` timer.
- Step 7 — For any other status (e.g. an error state), call `GENERAL.DISP_TEXT` to present the message "Unable to generate the report" with an "Error" title, then delete the `PRINTER_QUEUE` timer.

---

**Decision Points**

DP-001

Condition:
The name of the expired timer is `PRINTER_QUEUE`.

TRUE:
Proceed to check the report job status and act on its outcome.

FALSE:
No action is taken; the procedure exits without doing anything.

DP-002

Condition:
The report job status is `RUNNING`, `OPENING_REPORT`, or `ENQUEUED`.

TRUE:
Do nothing — the report is still in progress; the timer continues to fire on its next interval.

FALSE:
Proceed to evaluate whether the job finished successfully or with an error.

DP-003

Condition:
The report job status is `FINISHED`.

TRUE:
Open the completed report document in a new browser window and delete the `PRINTER_QUEUE` timer.

FALSE:
Display an error message ("Unable to generate the report") via `GENERAL.DISP_TEXT` and delete the `PRINTER_QUEUE` timer.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 — Only the `PRINTER_QUEUE` timer triggers report-status polling; any other timer firing is silently ignored.
- SBR-002 — While the report job is still queued or running, the timer must not be deleted, allowing the polling loop to continue.
- SBR-003 — Once a report job reaches a terminal state (either `FINISHED` or any error state), the `PRINTER_QUEUE` timer is always deleted to prevent further polling.

---

**Implementation Logic**

```plsql
PROCEDURE PROC_TIMER_EXPIRED IS
	vcStatus varchar2(50);
	vcTimerName varchar2(30);
	hTimer timer;
	report_id report_object;
  lv_report_handle varchar2(4000);
  lv_printout      varchar2(4000);
begin
	vcTimerName := get_application_property(timer_name);
   			lv_report_handle := name_in(':global.reporthandle');
        lv_printout      := name_in(':GLOBAL.PRINTOUTPUT');
 
	if vcTimerName = 'PRINTER_QUEUE' then
		 vcStatus := REPORT_OBJECT_STATUS(lv_report_handle);
	   if vcStatus in ('RUNNING','OPENING_REPORT','ENQUEUED') THEN
	   	  NULL;
	   ELSIF VCsTATUS = 'FINISHED' THEN
        web.show_document('/printer/'||lv_printout ,'_blank');
--        web.show_document('/reports/rwservlet/getjobid'||substr(:global.reporthandle,instr(:global.reporthandle,'_',-1)+1)||'?'||'server=mulreports'||:GLOBAL.PRINTOUTPUT,'_blank');
--        web.show_document('/reports/rwservlet/getjobid'||substr(lv_rep,instr(lv_rep,'_',-1)+1)||'?'||'server='||lv_server,'_blank');
        delete_timer(vcTimerName);
	   ELSE
--	   	  general.disp_text('Unable to generate the report'||vcStatus,'Error');
        general.disp_text('Unable to generate the report','Error');
	   	  delete_timer(vcTimerName);
	   end if;
	end if;   
end;
```

#### SP-017 — GENERAL.RAISE_ERROR

**Invoked From:**

- vt_amc_enq_fmb.xml [Trigger: ON-ERROR]

---

**Screen:**

N/A

---

**Purpose**

Translates an application message code into a categorised error, note, or caution alert and displays it to the user via `GENERAL.DISP_TEXT`; for error-category messages it additionally raises `FORM_TRIGGER_FAILURE` to halt the current form operation.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| mesg_code | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-013](#SP-013--GENERAL.DISP_TEXT)) — matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 — Receive the message code passed by the calling `ON-ERROR` trigger.
- Step 2 — Compose the display text by concatenating `mesg_code` with the (currently unpopulated) `mesg_text` variable, separated by ` : `.
- Step 3 — Evaluate the message type (`mesg_type`): if it is `'E'` (Error), set the title to `'Error'`, display the message via `GENERAL.DISP_TEXT`, and raise `FORM_TRIGGER_FAILURE` to abort the triggering operation.
- Step 4 — If the message type is `'N'` (Note), set the title to `'Note'` and display the message via `GENERAL.DISP_TEXT` without raising an exception.
- Step 5 — If the message type is `'C'` (Caution), set the title to `'Caution'` and display the message via `GENERAL.DISP_TEXT` without raising an exception.

---

**Decision Points**

DP-001

Condition:
The resolved message type (`mesg_type`) is `'E'` (Error).

TRUE:
Display the composed message text under the title "Error" and raise `FORM_TRIGGER_FAILURE` to stop the current form operation.

FALSE:
Check whether the type is `'N'` or `'C'`.

DP-002

Condition:
The resolved message type (`mesg_type`) is `'N'` (Note).

TRUE:
Display the composed message text under the title "Note"; processing continues normally without raising an exception.

FALSE:
Check whether the type is `'C'`.

DP-003

Condition:
The resolved message type (`mesg_type`) is `'C'` (Caution).

TRUE:
Display the composed message text under the title "Caution"; processing continues normally without raising an exception.

FALSE:
No display action is performed (none of the three recognised types matched).

---

**Database Interactions**

- DB-001 — Read am_permissions — queried inside the commented-out `check_rights` procedure to verify whether a user's access string grants permission to a named form; this code is inactive and not executed at runtime.

---

**Business Rules**

- SBR-001 — Error-type messages (`mesg_type = 'E'`) must always abort the current form operation by raising `FORM_TRIGGER_FAILURE` after the alert is shown.
- SBR-002 — Note-type (`'N'`) and Caution-type (`'C'`) messages are informational only and must not interrupt form processing.
- SBR-003 — The displayed message text is always prefixed with the raw message code followed by ` : `, ensuring traceability back to the original code.

---

**Implementation Logic**

```plsql
PROCEDURE RAISE_ERROR ( mesg_code IN VARCHAR2 )IS
  mesg_type  varchar2(7); 
  mesg_text  varchar2(200) ;
  mesg_title varchar2(7);
  BEGIN
     -- murali 17.05.04 GENERAL.get_message(mesg_code,mesg_text,mesg_type );
     mesg_text:=mesg_code||' : '||mesg_text;		
     IF ( mesg_type = 'E' ) THEN
        mesg_title := 'Error' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
        raise FORM_TRIGGER_FAILURE;
     ELSIF ( mesg_type = 'N' ) THEN
        mesg_title := 'Note' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     ELSIF ( mesg_type = 'C' ) THEN
        mesg_title := 'Caution' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     END IF;
  END;     

/* PROCEDURE check_rights( 
pi_form_name in varchar2,
pi_user_id in number) IS
lv_x varchar2(1);
BEGIN
	
	begin
	SELECT substr(access_string, pi_user_id,1) 
	INTO   lv_x
	FROM   	am_permissions
	WHERE  form_name = pi_form_name
	AND SUBSTR(access_string,pi_user_id,1)='Y';
	exception 
		when no_data_found then
		  general.disp_text('You do not have the Permission to access this.','Error rr');
		  raise form_trigger_failure; 
		when too_many_rows then
		  general.disp_text('Many rows in USER_PERMISSIONS','Error ss');
		  raise form_trigger_failure;
		when others then
		       general.disp_text(sqlerrm,'Error mm');
		       raise form_trigger_failure;
	end;

	open_form(pi_form_name,activate,session);
END;
*/
```

#### SP-018 — PKG_AMC.SP_GET_GST_TYPE

**Invoked From:**

- vt_amc_enq_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

Vehicle Details (N/A / CN_MAIN)

---

**Purpose**

Determines the applicable GST type (Intra-state `S` or Inter-state `I`) for an AMC/MCP transaction by comparing the dealer's state against the registered customer's state, and additionally flags Special Economic Zone customers for mandatory IGST treatment; it also returns the GST state codes for both dealer and customer alongside the customer's SEZ indicator.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| p_pmc | NUMBER | IN |
| p_parent | VARCHAR2 | IN |
| p_dealer | NUMBER | IN |
| p_loc | VARCHAR2 | IN |
| p_reg_num | VARCHAR2 | IN |

**Output Parameters**

| Output | Source | Datatype |
|--------|--------|---------|
| p_gst_type | VARCHAR2 | OUT |
| p_dlr_gst_state | VARCHAR2 | OUT |
| p_cust_gst_state | VARCHAR2 | OUT |
| p_cust_sez | VARCHAR2 | OUT |
| p_err_cd | NUMBER | OUT |
| p_err_msg | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 — Initialise the output error code to `0` and the error message to `NULL`.
- Step 2 — Look up the dealer's state code from `AM_DEALER_LOC` using the parent group, dealer map code, and location code; silently continue if no record is found.
- Step 3 — Look up the vehicle's customer party code and variant code from `GM_VIN` using the registration number; silently continue if no record is found.
- Step 4 — Look up the customer's state code and SEZ flag from `GM_CIN` using the customer party code and principal map code; set both to `NULL` if no record is found.
- Step 5 — If the customer's state code could not be resolved, set error code to `1` and instruct the user to update the customer's state through Customer Master, then stop further GST-type determination.
- Step 6 — If the customer's state code was resolved, check the SEZ flag: if the customer is flagged as an SEZ customer (`p_cust_sez = 'Y'`), set `p_gst_type` to `'I'` (IGST) and populate an informational message.
- Step 7 — If the customer is not an SEZ customer, compare the dealer state code against the customer state code: if they are equal, set `p_gst_type` to `'S'` (SGST/CGST); otherwise set it to `'I'` (IGST).
- Step 8 — Look up the GST state code for the customer state from `GM_STATE` and assign it to `p_cust_gst_state`; silently continue if not found.
- Step 9 — Look up the GST state code for the dealer state from `GM_STATE` and assign it to `p_dlr_gst_state`; silently continue if not found.

---

**Decision Points**

DP-001

Condition:
The customer's state code (`lv_cust_state`) is NULL after the `GM_CIN` lookup.

TRUE:
Set error code to `1` with the message "Please update State of Customer through Customer Master" and skip all GST-type determination steps.

FALSE:
Proceed to evaluate SEZ status and determine the GST type.

DP-002

Condition:
The customer is flagged as a Special Economic Zone customer (`NVL(p_cust_sez,'N') = 'Y'`).

TRUE:
Set `p_gst_type` to `'I'` (IGST is mandatory for SEZ customers regardless of state match) and set an informational message.

FALSE:
Compare dealer state against customer state to determine SGST or IGST applicability.

DP-003

Condition:
The dealer's state code equals the customer's state code (`lv_dlr_state = lv_cust_state`).

TRUE:
Set `p_gst_type` to `'S'` (intra-state — SGST and CGST apply).

FALSE:
Set `p_gst_type` to `'I'` (inter-state — IGST applies).

---

**Database Interactions**

- DB-001 — Read am_dealer_loc — retrieve the dealer's state code using the parent group, dealer map code, and location, to establish the dealer's GST state for comparison.
- DB-002 — Read gm_vin — retrieve the vehicle's customer party code and variant code using the registration number, to identify the customer for state and SEZ lookup.
- DB-003 — Read gm_cin — retrieve the customer's registered state code and SEZ indicator using the customer party code and principal map code, to determine GST eligibility.
- DB-004 — Update State — this entry reflects the conditional assignment of `p_gst_type` and related state outputs derived from the state comparison logic (no physical table update occurs; the label reflects the state resolution branch).
- DB-005 — Read gm_state — look up the GST state code for both the customer state and the dealer state using the principal map code, to populate the GST state code outputs.

---

**Business Rules**

- SBR-001 — A customer's state must be on record in `GM_CIN` before a GST type can be determined; if it is absent, the transaction cannot proceed.
- SBR-002 — Customers designated as Special Economic Zone (`cust_sez = 'Y'`) are always subject to IGST, irrespective of whether their state matches the dealer's state.
- SBR-003 — When dealer and customer states match and the customer is not an SEZ entity, intra-state GST (`'S'`) applies.
- SBR-004 — When dealer and customer states differ and the customer is not an SEZ entity, inter-state GST (`'I'`) applies.

---

**Implementation Logic**

```plsql
  PROCEDURE SP_GET_GST_TYPE(p_pmc            IN NUMBER,
                            p_parent         IN VARCHAR2,
                            p_dealer         IN NUMBER,
                            p_loc            IN VARCHAR2,
                            p_reg_num        IN VARCHAR2,
                            p_gst_type       OUT VARCHAR2,
                            p_dlr_gst_state  OUT VARCHAR2,
                            p_cust_gst_state OUT VARCHAR2,
                            p_cust_sez       OUT VARCHAR2,  -- RR on 21-FEB-2018 for SEZ
                            p_err_cd         OUT NUMBER,
                            p_err_msg        OUT VARCHAR2) IS
    lv_dlr_state  am_dealer_loc.state_cd%TYPE;
    lv_cust       gm_vin.party_cd%TYPE;
    lv_var        gm_vin.variant_cd%TYPE;
    lv_cust_state gm_cin.state_cd%TYPE;
  BEGIN
    p_err_cd  := 0;
    p_err_msg := NULL;
    BEGIN
      SELECT state_cd
        INTO lv_dlr_state
        FROM am_dealer_loc
       WHERE parent_group = p_parent
         AND dealer_map_cd = p_dealer
         AND loc_cd = p_loc;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    BEGIN
      SELECT party_cd, variant_cd
        INTO lv_cust, lv_var
        FROM gm_vin
       WHERE reg_num = p_reg_num;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    BEGIN
      SELECT state_cd,
             cust_sez -- RR on 21-FEB-2018 for SEZ
        INTO lv_cust_state, p_cust_sez
        FROM gm_cin
       WHERE cust_cd = lv_cust
         AND principal_map_cd = p_pmc;
    EXCEPTION
      WHEN OTHERS THEN
        lv_cust_state := NULL;
        p_cust_sez   := NULL;
    END;

    IF lv_cust_state IS NULL THEN
      p_err_cd  := 1;
      p_err_msg := 'Please update State of Customer through Customer Master';
    ELSE
      IF NVL(p_cust_sez,'N') = 'Y' THEN  -- SEZ Check Added by RR on 21-FEB-2018
        p_gst_type := 'I';
        p_err_msg := 'You have selected Customer as Special Economy Zone. Hence IGST will be applicable';
      ELSE
        IF lv_dlr_state = lv_cust_state THEN
          p_gst_type := 'S';
        ELSE
          p_gst_type := 'I';
        END IF;
      END IF;

      BEGIN
        SELECT gst_state_cd
          INTO p_cust_gst_state
          FROM gm_state
         WHERE principal_map_cd = p_pmc
           AND state_cd = lv_cust_state;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;

      BEGIN
        SELECT gst_state_cd
          INTO p_dlr_gst_state
          FROM gm_state
         WHERE principal_map_cd = p_pmc
           AND state_cd = lv_dlr_state;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;
    END IF;
  END sp_get_gst_type;
```

#### SP-019 — PKG_AMC.SP_POP_PKG_DTL

**Invoked From:**

- vt_amc_enq_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

Package Details (N/A / CN_MAIN); TCS (WN_MAIN / CN_TCS)

---

**Purpose**

Populates the AMC/MCP package detail and charge working tables (`GBL_AMC_DTL` and `GBL_AMC_CHARGES`) for a selected vehicle and package by fetching active rate lines from the rate master, resolving service/part descriptions and tax codes, computing GST and TCS charges via the expression evaluator, and writing the final net values back to the detail table — replacing any previously calculated data for the same package and vehicle.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| p_pmc | NUMBER | IN |
| p_parent | VARCHAR2 | IN |
| p_dealer | NUMBER | IN |
| p_loc | VARCHAR2 | IN |
| p_comp | VARCHAR2 | IN |
| p_pkg_code | VARCHAR2 | IN |
| p_reg_num | VARCHAR2 | IN |
| p_gst_type | VARCHAR2 | IN |
| p_dlr_state | VARCHAR2 | IN |
| p_cust_state | VARCHAR2 | IN |
| p_tcs_app_yn | VARCHAR2 | IN |

**Output Parameters**

| Output | Source | Datatype |
|--------|--------|---------|
| p_err_cd | NUMBER | OUT |
| p_err_msg | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 — Initialise output error code to `0`, error message to `NULL`, and internal counters to zero.
- Step 2 — Determine the effective GST state and LST flag: if `p_gst_type = 'S'` (intra-state), use the dealer's state and set LST flag to `'Y'`; otherwise use the customer's state and set LST flag to `'N'`.
- Step 3 — Look up the city RPH type for the dealer location by joining `AM_DEALER_LOC` to `GM_FOR`; used later to match rate lines to the correct city category.
- Step 4 — Look up the vehicle's sub-variant code, variant code, and customer party code from `GM_VIN` using the registration number.
- Step 5 — Look up the customer's GST number and PAN number from `GM_CIN` using the party code and principal map code; if not found, default GST number to `'GSTUNREGISTERED'`.
- Step 6 — Call `SF_CESS_APPLICABLE_DEALER` to determine whether Kerala Flood Cess applies for this dealer location.
- Step 7 — Derive the TCS applicability flag (`LV_TCS_APPL_FLAG`): `'YT'` if `p_tcs_app_yn = 'H'`; `'YP'` if `p_tcs_app_yn = 'Y'` and PAN is available; `'YN'` if `p_tcs_app_yn = 'Y'` and PAN is absent; `'N'` otherwise.
- Step 8 — Look up the fuel type code for the vehicle's variant from `GM_VAR`.
- Step 9 — Delete all existing detail rows from `GBL_AMC_DTL` for this parent/dealer/location/component/registration/package combination.
- Step 10 — Delete all existing charge rows from `GBL_AMC_CHARGES` for the same key.
- Step 11 — For each currently active rate line in `VM_AMC_RATE` (filtered by principal, package, sub-variant, fuel type, city category, and effective date range), resolve service description and HSN/SAC code: for labour (`srv_type = 'L'`) look up in `VM_MSIL_OPR`; for parts, look up description, HS code, and part tax code in `PM_PART`.
- Step 12 — For part-type lines, additionally look up the category description from `AM_LIST_RANGE` (list name `AMC_CATG_TYPE`) and, if a group code is present, the group description (list name `PART_TYPE`).
- Step 13 — Insert one row per rate line into `GBL_AMC_DTL` with all resolved fields (HSN/SAC, description, pricing, GST type, sell price).
- Step 14 — If no rate lines were found and inserted, set error code to `1` with the message "MCP Rate not defined for Specific Service Model".
- Step 15 — If no error, process each labour line (cursor `cur_lbr`) from the newly inserted `GBL_AMC_DTL`: look up the operation's tax code and normal/commercial percentage split from `VM_DLR_LTS`; default to tax code `'LB001'` and 100%/0% if not found.
- Step 16 — For each labour line, fetch applicable tax/charge lines via cursor `cur_lbr_charge` (joining `AM_CHARGE` with `VM_TAX`) filtered by tax code, GST type, and GST state code.
- Step 17 — Build the charge parameter string and call `Evaluate_Expr` using expression code `'MCPINV'` (when Kerala Cess applies, intra-state, and customer is GST-unregistered) or `'AMCINV'` (all other labour cases) to compute the actual charge amounts.
- Step 18 — Parse the `Evaluate_Expr` output token stream and match each returned token to the in-memory charge collection, recording the computed charge amount per tax component.
- Step 19 — Update `GBL_AMC_DTL` for each labour line with the total computed charge amount and the derived net value (`sell_price − discount_amt + charge_amt`).
- Step 20 — Insert all accumulated labour charge rows into `GBL_AMC_CHARGES`.
- Step 21 — If TCS is applicable (`p_tcs_app_yn IN ('Y','H')`), process each non-labour (part) line from `GBL_AMC_DTL` via cursor `cur_part`: look up the part's tax code from `PM_PART`, fetch applicable charge lines via cursor `cur_part_charge`, build the charge parameter string, and call `Evaluate_Expr` using expression code `'AMCINVTT'` (TCS without threshold), `'AMCINVTP'` (TCS with PAN), or `'AMCINVTN'` (TCS without PAN) based on `LV_TCS_APPL_FLAG`.
- Step 22 — Parse the part charge output token stream, record computed amounts, and update `GBL_AMC_DTL` for each part line.
- Step 23 — If TCS is not applicable, update `GBL_AMC_DTL` for all part lines with zero charge amounts.
- Step 24 — Insert all accumulated part charge rows (where charge amount > 0) into `GBL_AMC_CHARGES`.
- Step 25 — Commit the transaction.

---

**Decision Points**

DP-001

Condition:
`p_gst_type = 'S'` (intra-state GST).

TRUE:
Set the effective GST state to the dealer's state and the LST flag to `'Y'`.

FALSE:
Set the effective GST state to the customer's state and the LST flag to `'N'`.

DP-002

Condition:
`p_tcs_app_yn = 'H'` (TCS applicable without threshold check).

TRUE:
Set `LV_TCS_APPL_FLAG` to `'YT'`.

FALSE:
Proceed to check whether `p_tcs_app_yn = 'Y'`.

DP-003

Condition:
`p_tcs_app_yn = 'Y'` (TCS applicable) AND customer PAN is available (not `'PANNOTAVAIL'`).

TRUE:
Set `LV_TCS_APPL_FLAG` to `'YP'`.

FALSE:
If `p_tcs_app_yn = 'Y'` but PAN is absent, set `LV_TCS_APPL_FLAG` to `'YN'`; if `p_tcs_app_yn` is neither `'Y'` nor `'H'`, set it to `'N'`.

DP-004

Condition:
No rate lines were found in `VM_AMC_RATE` for the given package and vehicle profile (`ln_cnt = 0`).

TRUE:
Set error code to `1` and error message to "MCP Rate not defined for Specific Service Model"; skip all charge calculation steps.

FALSE:
Proceed to calculate labour and part charges.

DP-005

Condition:
The service type of the current rate line is `'L'` (Labour).

TRUE:
Look up the operation description and SAC code from `VM_MSIL_OPR`.

FALSE:
Look up the part description, HS code, and tax code from `PM_PART`, and additionally look up category and group descriptions from `AM_LIST_RANGE`.

DP-006

Condition:
Kerala Flood Cess is applicable (`lv_cess_appl = 'Y'`), the GST type is intra-state (`p_gst_type = 'S'`), and the customer is GST-unregistered (`lv_gst_num = 'GSTUNREGISTERED'`).

TRUE:
Call `Evaluate_Expr` with expression code `'MCPINV'` for the labour charge calculation.

FALSE:
Call `Evaluate_Expr` with expression code `'AMCINV'` for the labour charge calculation.

DP-007

Condition:
TCS is applicable (`p_tcs_app_yn IN ('Y','H')`).

TRUE:
Process each part line through the full TCS charge calculation loop and call the appropriate `Evaluate_Expr` variant (`'AMCINVTT'`, `'AMCINVTP'`, or `'AMCINVTN'`).

FALSE:
Update all part lines in `GBL_AMC_DTL` with zero charge amounts (no TCS computation performed).

DP-008

Condition:
`LV_TCS_APPL_FLAG = 'YT'` (TCS without threshold).

TRUE:
Call `Evaluate_Expr` with expression code `'AMCINVTT'`.

FALSE:
Check for `'YP'` (with PAN) or `'YN'` (without PAN) variants.

---

**Database Interactions**

- DB-001 — Read gbl_amc_dtl — fetched via cursors `cur_lbr` and `cur_part` to retrieve the just-inserted detail lines (labour and non-labour respectively) for charge calculation processing.
- DB-002 — Read am_charge — joined with `VM_TAX` (cursor `cur_lbr_charge`) and `PM_TAX` (cursor `cur_part_charge`) to retrieve the applicable charge type, charge indicator, and charge value for each service line's tax code.
- DB-003 — Read am_dealer_loc — joined with `GM_FOR` to resolve the dealer location's city RPH type, which determines the rate category for package pricing.
- DB-004 — Read gm_vin — retrieve the vehicle's sub-variant code, variant code, and customer party code using the registration number, needed for rate matching and customer GST/TCS lookup.
- DB-005 — Read gm_cin — retrieve the customer's GST registration number and PAN number to support SEZ/GST-unregistered determination and TCS applicability.
- DB-006 — Read gm_var — retrieve the fuel type code for the vehicle's variant, used as a filter when selecting active rate lines from `VM_AMC_RATE`.
- DB-007 — Delete from temp — removes all existing `GBL_AMC_DTL` rows for the current package/vehicle key before re-populating, ensuring stale data is not carried forward.
- DB-008 — Delete from gbl_amc_dtl — same physical operation as DB-007; removes prior detail rows for the package/vehicle combination.
- DB-009 — Delete from gbl_amc_charges — removes all existing charge rows from `GBL_AMC_CHARGES` for the current package/vehicle key before re-populating.
- DB-010 — Insert into Details — inserts one row per active rate line from `VM_AMC_RATE` into `GBL_AMC_DTL` with service code, type, HSN/SAC code, description, pricing, and GST type.
- DB-011 — Read vm_amc_rate — retrieves the active rate lines for the package, filtered by principal map, sub-variant, fuel type, city category, and current effective date range.
- DB-012 — Read vm_msil_opr — retrieves the operation description and SAC code for labour-type service lines.
- DB-013 — Read pm_part — retrieves the part description, HS code, and part tax code for non-labour (parts) service lines.
- DB-014 — Read am_list_range — retrieves the human-readable category description (list `AMC_CATG_TYPE`) and group description (list `PART_TYPE`) for part-type detail lines.
- DB-015 — Insert into details — inserts resolved detail records into `GBL_AMC_DTL` within the rate-line processing loop (same physical table as DB-010; separate logical step within the loop).
- DB-016 — Insert into gbl_amc_dtl — represents the same INSERT statement written to `GBL_AMC_DTL` inside the rate-line cursor loop.
- DB-017 — Read vm_dlr_lts — retrieves the operation tax code and the normal/commercial split percentages for each labour operation at the dealer location, used to build the charge parameter string for `Evaluate_Expr`.
- DB-018 — Update gbl_amc_dtl — updates each detail row with the computed total charge amount and derived net value after the expression evaluator returns the tax component amounts.
- DB-019 — Insert into gbl_amc_charges — inserts the individual computed charge/tax component rows into `GBL_AMC_CHARGES` for both labour lines (always) and part lines (only when charge amount > 0 and TCS is applicable).

---

**Business Rules**

- SBR-001 — All existing detail and charge rows for the package/vehicle combination must be deleted before repopulation, preventing duplicate or stale pricing data.
- SBR-002 — Only rate lines that are currently active (status = `'Y'` or null) and within their effective date range are eligible for inclusion in the package detail.
- SBR-003 — If no active rate lines exist for the given vehicle profile (principal, package, sub-variant, fuel type, city category), the procedure raises an error and performs no further processing.
- SBR-004 — Kerala Flood Cess changes the expression evaluator code for labour charges from `'AMCINV'` to `'MCPINV'` only when the customer is GST-unregistered and the transaction is intra-state.
- SBR-005 — TCS is computed on parts only when `p_tcs_app_yn` is `'Y'` or `'H'`; when it is neither, part lines receive zero charge amounts.
- SBR-006 — The TCS expression variant used (`'AMCINVTT'`, `'AMCINVTP'`, `'AMCINVTN'`) is determined by the threshold and PAN availability flags derived before processing begins.
- SBR-007 — Part charge rows are only inserted into `GBL_AMC_CHARGES` when the computed charge amount is greater than zero, preventing zero-value tax entries.
- SBR-008 — The net value stored on each detail line is calculated as `sell_price − discount_amt + charge_amt`, ensuring tax is applied on top of the discounted selling price.
- SBR-009 — The effective GST state used for charge lookup is the dealer's state for intra-state transactions and the customer's state for inter-state transactions.

---

**Implementation Logic**

```plsql
  PROCEDURE SP_POP_PKG_DTL(p_pmc        IN NUMBER,
                           p_parent     IN VARCHAR2,
                           p_dealer     IN NUMBER,
                           p_loc        IN VARCHAR2,
                           p_comp       IN VARCHAR2,
                           p_pkg_code   IN VARCHAR2,
                           p_reg_num    IN VARCHAR2,
                           p_gst_type   IN VARCHAR2,
                           p_dlr_state  IN VARCHAR2,
                           p_cust_state IN VARCHAR2,
                           p_tcs_app_yn IN VARCHAR2, -- TCS
                           p_err_cd     OUT NUMBER,
                           p_err_msg    OUT VARCHAR2) IS
    lv_city_rph   gm_for.city_rph_type%TYPE;
    lv_svar       gm_vin.svar_cd%TYPE;
    lv_variant    gm_vin.variant_cd%TYPE;
    lv_fuel       gm_var.fueltype_cd%TYPE;
    lv_srv_desc   gbl_amc_dtl.srv_desc%TYPE;
    lv_catg_desc  gbl_amc_dtl.catg_desc%TYPE;
    lv_grp_desc   gbl_amc_dtl.group_desc%TYPE;
    lv_opr_tax_cd vm_dlr_lts.opr_tax_cd%TYPE;
    lv_hsn_sac    vm_dlr_lts.sac_code%TYPE;
    lv_part_tax   pm_part.part_tax_cd%TYPE;

    ln_com_per    NUMBER := 0;
    ln_nor_per    NUMBER := 0;
    ln_sell_price NUMBER(13, 2);
    ln_disc_amt   NUMBER(13, 2);
    ln_cgst_amt   NUMBER(13, 2);
    ln_sgst_amt   NUMBER(13, 2);
    ln_igst_amt   NUMBER(13, 2);
    ln_cnt        NUMBER;
    ln_srl        NUMBER;
    ln_chg_srl    NUMBER := 1;
    ln_opr_srl    NUMBER := 0;
    lv_gst_state  VARCHAR2(3);
    lv_lst_yn     VARCHAR2(3);

    tc_opr_charges ctab;
    to_opr_charges ctab;
    lc_cus_chg_cnt NUMBER := 1;
    lv_divide      NUMBER(15, 4);
    lv_divisor     NUMBER(15, 2);
    lv_param       VARCHAR2(4000);
    ln_num         VARCHAR2(15) := 0;
    lv_oparam      VARCHAR2(4000);
    lv_token       VARCHAR2(200);
    lv_value       NUMBER;
    lv_opr_chg_amt NUMBER;

    tc_part_charges ctab;
    to_part_charges ctab;
    ln_pchg_srl     NUMBER := 1;
    ln_part_srl     NUMBER := 0;
    lv_part_chg_amt NUMBER;

    -- Added by Rajeev on 29-MAY-2019 for KERALA CESS
    lv_party_cd   gm_vin.party_cd%TYPE;
    lv_gst_num    gm_cin.gst_num%TYPE;
    lv_cess_appl  VARCHAR2(5) := 'N';--RR Kerala Flood Cess 21-Jun-2019
    lv_pan_num     gm_cin.pan_num%type; -- TCS
    LV_TCS_APPL_FLAG VARCHAR2(2);       -- TCS

    CURSOR cur_lbr IS
      SELECT srl_num,
             srv_type,
             srv_cd,
             qty,
             basic_value,
             discount_amt,
             sell_price
        FROM gbl_amc_dtl
       WHERE parent_group = p_parent
         AND dealer_map_cd = p_dealer
         AND loc_cd = p_loc
         AND comp_fa = p_comp
         AND reg_num = p_reg_num
         AND pkg_code = p_pkg_code
         AND srv_type = 'L';

    CURSOR cur_lbr_charge(pi_ptax_cd   IN VARCHAR2,
                          pi_gst_type  IN VARCHAR2,
                          pi_gst_state IN VARCHAR2) IS
      SELECT a.charge_type,
             a.charge_ind,
             a.charge_value,
             a.charge_cd,
             b.common_ind,
             b.order_srl
        FROM am_charge a, vm_tax b
       WHERE b.dealer_map_cd = p_dealer
         AND a.dealer_map_cd = b.dealer_map_cd
         AND a.loc_cd = b.loc_cd
         AND a.loc_cd = p_loc
         AND a.charge_type = b.charge_type
         AND a.charge_cd = b.charge_cd
         AND NVL(b.gst_type, 'S') = pi_gst_type
         AND b.gst_state_cd = pi_gst_state
         AND b.common_ind = 'M'
         AND b.opr_tax_cd = pi_ptax_cd;

    CURSOR cur_part IS
      SELECT srl_num,
             srv_type,
             srv_cd,
             qty,
             basic_value,
             discount_amt,
             sell_price
        FROM gbl_amc_dtl
       WHERE parent_group = p_parent
         AND dealer_map_cd = p_dealer
         AND loc_cd = p_loc
         AND comp_fa = p_comp
         AND reg_num = p_reg_num
         AND pkg_code = p_pkg_code
         AND srv_type != 'L';

    CURSOR cur_part_charge(pi_ptax_cd   IN VARCHAR2,
                           pi_gst_type  IN VARCHAR2,
                           pi_gst_state IN VARCHAR2) IS
      SELECT a.charge_type,
             a.charge_ind,
             a.charge_value,
             a.charge_cd,
             b.common_ind,
             b.order_srl
        FROM am_charge a, Pm_tax b
       WHERE b.dealer_map_cd = p_dealer
         AND a.dealer_map_cd = b.dealer_map_cd
         AND a.loc_cd = b.loc_cd
         AND A.LOC_CD = p_loc
         AND a.charge_type = b.charge_type
         AND a.charge_cd = b.charge_cd
         AND (b.common_ind IN ('M') OR
             b.common_ind = DECODE(pi_gst_type, 'S', 'O', 'I', 'C'))
         AND tax_type = 'S'
         AND b.gst_state_cd = pi_gst_state
         AND b.part_tax_cd = pi_ptax_cd;

  BEGIN
    p_err_cd  := 0;
    p_err_msg := NULL;
    ln_cnt    := 0;
    ln_srl    := 0;

    IF p_gst_type = 'S' THEN
      lv_gst_state := p_dlr_state;
      lv_lst_yn    := 'Y';
    ELSE
      lv_gst_state := p_cust_state;
      lv_lst_yn    := 'N';
    END IF;
    -- City RPH
    BEGIN
      SELECT m.city_rph_type
        INTO lv_city_rph
        FROM am_dealer_loc l, gm_for m
       WHERE l.parent_group = p_parent
         AND l.dealer_map_cd = p_dealer
         AND l.loc_cd = p_loc
         AND m.principal_map_cd = l.principal_map_cd
         AND m.for_cd = l.for_cd;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    -- Vehicle Details
    BEGIN
      SELECT svar_cd, variant_cd, party_cd
        INTO lv_svar, lv_variant, lv_party_cd
        FROM gm_vin
       WHERE reg_num = p_reg_num;
    EXCEPTION WHEN OTHERS THEN
        NULL;
    END;

    -- Added by Rajeev on 29-MAY-2019 for KERALA CESS
    BEGIN
      BEGIN
        SELECT gst_num, pan_num -- TCS
          INTO lv_gst_num, lv_pan_num
          FROM gm_cin
         WHERE principal_map_cd = p_pmc
           AND cust_cd = lv_party_cd;
      EXCEPTION WHEN OTHERS THEN
         lv_gst_num := 'GSTUNREGISTERED';
      END;
      --RR Kerala Flood Cess 21-Jun-2019
      lv_cess_appl := SF_CESS_APPLICABLE_DEALER(p_parent,
                                                p_dealer,
                                                p_loc);
     IF NVL(p_tcs_app_yn,'N') = 'H' THEN
       LV_TCS_APPL_FLAG := 'YT';
     ELSIF NVL(p_tcs_app_yn,'N') = 'Y' THEN
        IF NVL(lv_pan_num,'PANNOTAVAIL') <> 'PANNOTAVAIL' THEN
           LV_TCS_APPL_FLAG := 'YP';
        ELSE
           LV_TCS_APPL_FLAG := 'YN';
        END IF;
      ELSE
        LV_TCS_APPL_FLAG := 'N';
      END IF;

    END;

    -- Fuel Type
    BEGIN
      SELECT fueltype_cd
        INTO lv_fuel
        FROM gm_var v
       WHERE v.variant_cd = lv_variant
         AND v.principal_map_cd = p_pmc;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    -- Delete from temp table
    DELETE FROM gbl_amc_dtl
     WHERE parent_group = p_parent
       AND dealer_map_cd = p_dealer
       AND loc_cd = p_loc
       AND comp_fa = p_comp
       AND reg_num = p_reg_num
       AND pkg_code = p_pkg_code;

    DELETE FROM gbl_amc_charges
     WHERE parent_group = p_parent
       AND dealer_map_cd = p_dealer
       AND loc_cd = p_loc
       AND comp_fa = p_comp
       AND reg_num = p_reg_num
       AND pkg_code = p_pkg_code;

    -- Insert into Details Table
    FOR cur_d IN (SELECT /*+ index (r VM_AMC_RATE_UK)*/
                   DECODE(r.srv_type, 'L', 1, 'P', 2, 'C', 3) srl_num,
                   r.srv_type,
                   r.srv_code,
                   r.qty,
                   r.discount_per,
                   r.rate,
                   r.basic_value,
                   r.discount_amt,
                   r.tot_value,
                   r.catg_cd,
                   r.group_cd
                    FROM vm_amc_rate r
                   WHERE r.principal_map_cd = p_pmc
                     AND r.pkg_code = p_pkg_code
                     AND r.svar_mod_cd = lv_svar
                     AND r.fueltype_cd = lv_fuel
                     AND r.city_category = lv_city_rph
                     AND NVL(r.status, 'Y') = 'Y'
                     --AND r.srv_type = 'P'
                     --AND r.srv_code = '99999MD5W30-IOC'
                     AND TRUNC(SYSDATE) BETWEEN effec_from_date AND
                         NVL(effec_to_date, TRUNC(SYSDATE))
                   ORDER BY srl_num, srv_code) LOOP
      ln_sell_price := NULL;
      ln_disc_amt   := NULL;
      ln_cgst_amt   := NULL;
      ln_sgst_amt   := NULL;
      ln_igst_amt   := NULL;
      lv_catg_desc  := NULL;
      lv_grp_desc   := NULL;
      ln_cnt        := NVL(ln_cnt, 0) + 1;
      ln_srl        := NVL(ln_srl, 0) + 1;

      IF cur_d.srv_type = 'L' THEN
        -- Labour Details
        BEGIN
          SELECT opr_desc, NVL(sac_code, '998729')
            INTO lv_srv_desc, lv_hsn_sac
            FROM vm_msil_opr l
           WHERE l.principal_map_cd = p_pmc
             AND l.dealer_type = 'D'
             AND l.svar_cd = lv_svar
             AND l.opr_cd = cur_d.srv_code;
        EXCEPTION
          WHEN OTHERS THEN
            lv_srv_desc := NULL;
            lv_hsn_sac  := NULL;
        END;
        ln_sell_price := cur_d.basic_value;
        ln_disc_amt   := cur_d.discount_amt;
      ELSE
        -- Part Details
        BEGIN
          SELECT part_desc, NVL(hs_code, '8708'), NVL(part_tax_cd, 'A')
            INTO lv_srv_desc, lv_hsn_sac, lv_part_tax
            FROM pm_part
           WHERE part_num = cur_d.srv_code
             AND principal_map_cd = p_pmc
             AND dealer_map_cd = p_pmc;
        EXCEPTION
          WHEN OTHERS THEN
            lv_srv_desc := NULL;
            lv_hsn_sac  := NULL;
            lv_part_tax := 'A';
        END;
        -- Group Details
        BEGIN
          SELECT list_desc
            INTO lv_catg_desc
            FROM am_list_range
           WHERE principal_map_cd = p_pmc
             AND list_name = 'AMC_CATG_TYPE'
             AND list_code = cur_d.catg_cd;
        EXCEPTION
          WHEN OTHERS THEN
            lv_catg_desc := NULL;
        END;
        -- Group Details
        IF cur_d.group_cd IS NOT NULL THEN
          BEGIN
            SELECT list_desc
              INTO lv_grp_desc
              FROM am_list_range
             WHERE principal_map_cd = p_pmc
               AND list_name = 'PART_TYPE'
               AND list_code = cur_d.group_cd;
          EXCEPTION
            WHEN OTHERS THEN
              lv_grp_desc := NULL;
          END;
        END IF;

        -- Sell Price
        ln_sell_price := cur_d.basic_value;
        ln_disc_amt   := cur_d.discount_amt;

        -- Below code commented by Rajeev on 09-MAR-2018
        -- Now tax not calculated on Part at MCP sale
        /*IF lv_part_tax IS NOT NULL THEN
          ln_sell_price := PKG_AMC.SF_GET_SELL_PRICE(p_parent,
                                                     p_dealer,
                                                     p_loc,
                                                     lv_part_tax,
                                                     cur_d.basic_value,
                                                     lv_lst_yn,
                                                     lv_gst_state);
          ln_disc_amt   := ln_sell_price * cur_d.discount_per / 100;
        END IF;*/
      END IF;
      -- Insert into details table
      INSERT INTO gbl_amc_dtl
        (parent_group,
         dealer_map_cd,
         loc_cd,
         comp_fa,
         reg_num,
         pkg_code,
         srl_num,
         srv_type,
         srv_cd,
         hsn_sac_cd,
         srv_desc,
         qty,
         discount_per,
         rate,
         basic_value,
         discount_amt,
         tot_value,
         catg_cd,
         catg_desc,
         group_cd,
         group_desc,
         gst_type,
         sell_price)
      VALUES
        (p_parent,
         p_dealer,
         p_loc,
         p_comp,
         p_reg_num,
         p_pkg_code,
         ln_srl,
         cur_d.srv_type,
         cur_d.srv_code,
         lv_hsn_sac,
         lv_srv_desc,
         cur_d.qty,
         cur_d.discount_per,
         cur_d.rate,
         cur_d.basic_value,
         ln_disc_amt,
         cur_d.tot_value,
         cur_d.catg_cd,
         lv_catg_desc,
         cur_d.group_cd,
         lv_grp_desc,
         p_gst_type,
         ln_sell_price);
    END LOOP;
    IF NVL(ln_cnt, 0) = 0 THEN
      p_err_cd  := 1;
      p_err_msg := 'MCP Rate not defined for Specific Service Model';
    END IF;

    IF p_err_cd = 0 THEN
      -- Calculate Labour Charges
      -- DBMS_OUTPUT.PUT_LINE('1');
      FOR cur_l IN cur_lbr LOOP
        ln_opr_srl := cur_l.srl_num;
        lv_param   := NULL;

        ln_nor_per := 100;
        ln_com_per := 0;
        BEGIN
          SELECT opr_tax_cd, 100, 0
            INTO lv_opr_tax_cd, ln_nor_per, ln_com_per
            FROM vm_dlr_lts
           WHERE dealer_map_cd = p_dealer
             AND loc_cd = p_loc
             AND opr_cd = cur_l.srv_cd
             AND svar_cd = lv_svar;
        EXCEPTION
          WHEN OTHERS THEN
            lv_opr_tax_cd := 'LB001';
            ln_nor_per    := 100;
            ln_com_per    := 0;
        END;
        -- DBMS_OUTPUT.PUT_LINE('2 '||lv_opr_tax_cd);
        DECLARE
          ln_charge_cnt NUMBER := 1;
        BEGIN
          FOR cur_c IN cur_lbr_charge(lv_opr_tax_cd,
                                      p_gst_type,
                                      lv_gst_state) LOOP
            tc_opr_charges(ln_charge_cnt).charge_type := cur_c.charge_type;
            tc_opr_charges(ln_charge_cnt).charge_ind := cur_c.charge_ind;
            tc_opr_charges(ln_charge_cnt).charge_value := cur_c.charge_value;
            tc_opr_charges(ln_charge_cnt).charge_cd := cur_c.charge_cd;
            tc_opr_charges(ln_charge_cnt).common_ind := cur_c.common_ind;
            tc_opr_charges(ln_charge_cnt).charge_srl := ln_chg_srl;
            tc_opr_charges(ln_charge_cnt).order_srl := cur_c.order_srl;
            tc_opr_charges(ln_charge_cnt).srv_type := cur_l.srv_type;
            tc_opr_charges(ln_charge_cnt).opr_cd := cur_l.srv_cd;
            tc_opr_charges(ln_charge_cnt).opr_srl := cur_l.srl_num;
            ln_charge_cnt := ln_charge_cnt + 1;

            IF cur_c.charge_ind = 'P' THEN
              lv_divisor := 100;
            ELSE
              lv_divisor := 1;
            END IF;
            lv_divide := cur_c.charge_value / lv_divisor;
            lv_param  := lv_param || cur_c.charge_type || ';' ||
                         TO_CHAR(cur_c.charge_value / lv_divisor) || ';' ||
                         cur_c.charge_ind || ';';

            ln_chg_srl := ln_chg_srl + 1;
          END LOOP;

          FOR x IN 1 .. tc_opr_charges.COUNT LOOP
            to_opr_charges(lc_cus_chg_cnt).charge_type := tc_opr_charges(x)
                                                          .charge_type;
            to_opr_charges(lc_cus_chg_cnt).charge_ind := tc_opr_charges(x)
                                                         .charge_ind;
            to_opr_charges(lc_cus_chg_cnt).charge_value := tc_opr_charges(x)
                                                           .charge_value;
            to_opr_charges(lc_cus_chg_cnt).charge_cd := tc_opr_charges(x)
                                                        .charge_cd;
            to_opr_charges(lc_cus_chg_cnt).common_ind := tc_opr_charges(x)
                                                         .common_ind;
            to_opr_charges(lc_cus_chg_cnt).charge_srl := tc_opr_charges(x)
                                                         .charge_srl;
            to_opr_charges(lc_cus_chg_cnt).order_srl := tc_opr_charges(x)
                                                        .order_srl;
            to_opr_charges(lc_cus_chg_cnt).srv_type := tc_opr_charges(x)
                                                       .srv_type;
            to_opr_charges(lc_cus_chg_cnt).opr_cd := tc_opr_charges(x)
                                                     .opr_cd;
            to_opr_charges(lc_cus_chg_cnt).opr_srl := tc_opr_charges(x)
                                                      .opr_srl;
            lc_cus_chg_cnt := lc_cus_chg_cnt + 1;
          END LOOP;

          lv_param := 'SP;' || TO_CHAR(cur_l.sell_price) || ';' || 'P;' ||
                      'QTY;' || TO_CHAR(NVL(1, 1)) || ';' || 'A;' || 'DIS;' ||
                      TO_CHAR(NVL(cur_l.discount_amt, 0)) || ';' || 'A;' ||
                      'NAT;' || (NVL(ln_nor_per, 0) / 100) || ';' || 'P;' ||
                      'COM;' || TO_CHAR(NVL(ln_com_per, 0) / 100) || ';' || 'P;' ||
                      lv_param;
        END;

   --  := ;

        BEGIN--RR Kerala Flood Cess 21-Jun-2019
          IF NVL(lv_cess_appl, 'N') = 'Y' AND p_gst_type = 'S' AND
                  NVL(lv_gst_num,'GSTUNREGISTERED') = 'GSTUNREGISTERED' THEN
            Evaluate_Expr('MCPINV',
                          lv_param,
                          p_dealer,
                          p_loc,
                          lv_oparam,
                          ln_num);
          ELSE
            Evaluate_Expr('AMCINV',
                          lv_param,
                          p_dealer,
                          p_loc,
                          lv_oparam,
                          ln_num);
          END IF;

        EXCEPTION
          WHEN OTHERS THEN
            p_err_cd  := 1;
            p_err_msg := 'Evaluate Error - Operation';
        END;
        lv_opr_chg_amt := 0;

        LOOP
          lv_token  := SUBSTR(lv_oparam, 1, INSTR(lv_oparam, ';', 1, 1) - 1);
          lv_oparam := SUBSTR(lv_oparam, INSTR(lv_oparam, ';', 1, 1) + 1);
          lv_value  := TO_NUMBER(SUBSTR(lv_oparam,
                                        1,
                                        INSTR(lv_oparam, ';', 1, 1) - 1));
          lv_oparam := SUBSTR(lv_oparam, INSTR(lv_oparam, ';', 1, 1) + 1);
          --dbms_output.put_line(lv_token || ' - '||lv_value);
          IF to_opr_charges.COUNT > 0 THEN
            FOR i IN to_opr_charges.FIRST .. to_opr_charges.LAST LOOP
              IF to_opr_charges(i).charge_type = lv_token AND to_opr_charges(i)
                 .opr_srl = ln_opr_srl THEN
                to_opr_charges(i).charge_amt := ROUND(lv_value, 2);
                lv_opr_chg_amt := NVL(lv_opr_chg_amt, 0) +
                                  ROUND(NVL(lv_value, 0), 2);
              END IF;
            END LOOP;
          END IF;
          EXIT WHEN lv_oparam IS NULL;
        END LOOP;
        UPDATE gbl_amc_dtl
           SET charge_amt = lv_opr_chg_amt,
               net_value  = NVL(sell_price, 0) - NVL(discount_amt, 0) +
                            NVL(lv_opr_chg_amt, 0)
         WHERE parent_group = p_parent
           AND dealer_map_cd = p_dealer
           AND loc_cd = p_loc
           AND comp_fa = p_comp
           AND reg_num = p_reg_num
           AND pkg_code = p_pkg_code
           AND srl_num = cur_l.srl_num
           AND srv_type = cur_l.srv_type
           AND srv_cd = cur_l.srv_cd;
      END LOOP;
      -- Insert Labour Charges
      FOR i IN 1 .. to_opr_charges.COUNT LOOP
        IF to_opr_charges(i).opr_cd IS NOT NULL
         THEN
          INSERT INTO gbl_amc_charges
            (parent_group,
             dealer_map_cd,
             loc_cd,
             comp_fa,
             reg_num,
             pkg_code,
             srl_num,
             srv_type,
             srv_cd,
             charge_srl,
             common_ind,
             order_srl,
             charge_cd,
             charge_type,
             charge_ind,
             charge_value,
             charge_amt)
          VALUES
            (p_parent,
             p_dealer,
             p_loc,
             p_comp,
             p_reg_num,
             p_pkg_code,
             to_opr_charges(i).opr_srl,
             to_opr_charges(i).srv_type,
             to_opr_charges(i).opr_cd,
             to_opr_charges(i).charge_srl,
             to_opr_charges(i).common_ind,
             to_opr_charges(i).order_srl,
             to_opr_charges(i).charge_cd,
             to_opr_charges(i).charge_type,
             to_opr_charges(i).charge_ind,
             to_opr_charges(i).charge_value,
             NVL(to_opr_charges(i).charge_amt,0)
             );
        END IF;
      END LOOP;

      -- Calculate Part Charges
      lc_cus_chg_cnt := 1;
      ln_pchg_srl    := ln_chg_srl;
      /*
      FOR cur_p IN cur_part LOOP
        UPDATE gbl_amc_dtl
           SET charge_amt = NVL(lv_part_chg_amt, 0),
               net_value  = NVL(sell_price, 0) - NVL(discount_amt, 0) +
                            NVL(lv_part_chg_amt, 0)
         WHERE parent_group = p_parent
           AND dealer_map_cd = p_dealer
           AND loc_cd = p_loc
           AND comp_fa = p_comp
           AND reg_num = p_reg_num
           AND pkg_code = p_pkg_code
           AND srl_num = cur_p.srl_num
           AND srv_type = cur_p.srv_type
           AND srv_cd = cur_p.srv_cd;
      END LOOP;
      */
      -- Below code commented and above code added by Rajeev on 09-MAR-2018
      -- Now tax not calculated on Part at MCP sale
      -- Reoprn the code for TCS
      IF NVL(p_tcs_app_yn,'N') IN  ('Y','H') THEN -- TCS  --ADDED 'H' BY MOHAN AS ON 29062021

      FOR cur_p IN cur_part LOOP
        lv_param    := NULL;
        lv_oparam   := NULL;
        ln_part_srl := cur_p.srl_num;
        BEGIN
          SELECT NVL(part_tax_cd, 'A')
            INTO lv_part_tax
            FROM pm_part
           WHERE part_num = cur_p.srv_cd
             AND principal_map_cd = p_pmc
             AND dealer_map_cd = p_pmc;
        EXCEPTION
          WHEN OTHERS THEN
            lv_part_tax := 'A';
        END;

        DECLARE
          ln_chg_cnt NUMBER := 1;
        BEGIN
          FOR cur_c IN cur_part_charge(lv_part_tax,
                                       p_gst_type,
                                       lv_gst_state) LOOP
            tc_part_charges(ln_chg_cnt).charge_type := cur_c.charge_type;
            tc_part_charges(ln_chg_cnt).charge_ind := cur_c.charge_ind;
            tc_part_charges(ln_chg_cnt).charge_value := cur_c.charge_value;
            tc_part_charges(ln_chg_cnt).charge_cd := cur_c.charge_cd;
            tc_part_charges(ln_chg_cnt).common_ind := cur_c.common_ind;
            tc_part_charges(ln_chg_cnt).charge_srl := ln_pchg_srl;
            tc_part_charges(ln_chg_cnt).srl_num := cur_p.srl_num;
            tc_part_charges(ln_chg_cnt).order_srl := cur_c.order_srl;
            tc_part_charges(ln_chg_cnt).srv_type := cur_p.srv_type;
            tc_part_charges(ln_chg_cnt).opr_cd := cur_p.srv_cd;
            ln_chg_cnt := ln_chg_cnt + 1;

            IF cur_c.charge_ind = 'P' THEN
              lv_divisor := 100;
            ELSE
              lv_divisor := 1;
            END IF;

            lv_divide   := cur_c.charge_value / lv_divisor;
            lv_param    := lv_param || cur_c.charge_type || ';' ||
                           TO_CHAR(cur_c.charge_value / lv_divisor) || ';' ||
                           cur_c.charge_ind || ';';
            ln_pchg_srl := ln_pchg_srl + 1;
          END LOOP;

          FOR x IN 1 .. tc_part_charges.COUNT LOOP
            to_part_charges(lc_cus_chg_cnt).charge_type := tc_part_charges(x)
                                                           .charge_type;
            to_part_charges(lc_cus_chg_cnt).charge_ind := tc_part_charges(x)
                                                          .charge_ind;
            to_part_charges(lc_cus_chg_cnt).charge_value := tc_part_charges(x)
                                                            .charge_value;
            to_part_charges(lc_cus_chg_cnt).charge_cd := tc_part_charges(x)
                                                         .charge_cd;
            to_part_charges(lc_cus_chg_cnt).common_ind := tc_part_charges(x)
                                                          .common_ind;
            to_part_charges(lc_cus_chg_cnt).charge_srl := tc_part_charges(x)
                                                          .charge_srl;
            to_part_charges(lc_cus_chg_cnt).order_srl := tc_part_charges(x)
                                                         .order_srl;
            to_part_charges(lc_cus_chg_cnt).srl_num := tc_part_charges(x)
                                                       .srl_num;
            to_part_charges(lc_cus_chg_cnt).srv_type := tc_part_charges(x)
                                                        .srv_type;
            to_part_charges(lc_cus_chg_cnt).opr_cd := tc_part_charges(x)
                                                      .opr_cd;
            --dbms_output.put_line('1 '||to_part_charges(lc_cus_chg_cnt).charge_type);
            lc_cus_chg_cnt := lc_cus_chg_cnt + 1;
          END LOOP;
          lv_param := 'SP;' || TO_CHAR(cur_p.sell_price) || ';' || 'P;' ||
                      'QTY;' || TO_CHAR(NVL(1, 1)) || ';' || 'A;' || 'DIS;' ||
                      TO_CHAR(NVL(cur_p.discount_amt, 0)) || ';' || 'A;' ||
                      'NAT;' || (NVL(100, 0) / 100) || ';' || 'P;' ||
                      'COM;' || TO_CHAR(NVL(0, 0) / 100) || ';' || 'P;' ||
                      lv_param;
        END;
        BEGIN
        IF NVL(LV_TCS_APPL_FLAG,'N') = 'YT' THEN --TCS
          Evaluate_Expr('AMCINVTT',
                        lv_param,
                        p_dealer,
                        p_loc,
                        lv_oparam,
                        ln_num);
         ELSIF NVL(LV_TCS_APPL_FLAG,'N') = 'YP' THEN --TCS
          Evaluate_Expr('AMCINVTP',
                        lv_param,
                        p_dealer,
                        p_loc,
                        lv_oparam,
                        ln_num);
         ELSIF NVL(LV_TCS_APPL_FLAG,'N') = 'YN' THEN
          Evaluate_Expr('AMCINVTN',
                        lv_param,
                        p_dealer,
                        p_loc,
                        lv_oparam,
                        ln_num);
         ELSE
           ln_num :=0;
         END IF;
        EXCEPTION
          WHEN OTHERS THEN
            p_err_cd  := 1;
            p_err_msg := 'Evaluate Error - Operation';
        END;
        lv_part_chg_amt := 0;
        LOOP
          lv_token  := SUBSTR(lv_oparam, 1, INSTR(lv_oparam, ';', 1, 1) - 1);
          lv_oparam := SUBSTR(lv_oparam, INSTR(lv_oparam, ';', 1, 1) + 1);
          lv_value  := TO_NUMBER(SUBSTR(lv_oparam,
                                        1,
                                        INSTR(lv_oparam, ';', 1, 1) - 1));
          lv_oparam := SUBSTR(lv_oparam, INSTR(lv_oparam, ';', 1, 1) + 1);

          IF to_part_charges.COUNT > 0 THEN
            FOR z IN to_part_charges.FIRST .. to_part_charges.LAST LOOP
              IF to_part_charges(z).charge_type = lv_token AND to_part_charges(z)
                 .srl_num = ln_part_srl THEN
                to_part_charges(z).charge_amt := ROUND(lv_value, 2);
                lv_part_chg_amt := NVL(lv_part_chg_amt, 0) +
                                   ROUND(NVL(lv_value, 0), 2);
              END IF;
            END LOOP;
          END IF;
          EXIT WHEN lv_oparam IS NULL;
        END LOOP;
        UPDATE gbl_amc_dtl
           SET charge_amt = lv_part_chg_amt,
               net_value  = NVL(sell_price, 0) - NVL(discount_amt, 0) +
                            NVL(lv_part_chg_amt, 0)
         WHERE parent_group = p_parent
           AND dealer_map_cd = p_dealer
           AND loc_cd = p_loc
           AND comp_fa = p_comp
           AND reg_num = p_reg_num
           AND pkg_code = p_pkg_code
           AND srl_num = cur_p.srl_num
           AND srv_type = cur_p.srv_type
           AND srv_cd = cur_p.srv_cd;
      END LOOP;
      ELSE
        FOR cur_p IN cur_part LOOP
        UPDATE gbl_amc_dtl
           SET charge_amt = NVL(lv_part_chg_amt, 0),
               net_value  = NVL(sell_price, 0) - NVL(discount_amt, 0) +
                            NVL(lv_part_chg_amt, 0)
         WHERE parent_group = p_parent
           AND dealer_map_cd = p_dealer
           AND loc_cd = p_loc
           AND comp_fa = p_comp
           AND reg_num = p_reg_num
           AND pkg_code = p_pkg_code
           AND srl_num = cur_p.srl_num
           AND srv_type = cur_p.srv_type
           AND srv_cd = cur_p.srv_cd;
        END LOOP;
      END IF; -- TCS
      -- Insert Part Charges
      FOR z IN 1 .. to_part_charges.COUNT LOOP
        IF to_part_charges(z).opr_cd IS NOT NULL AND to_part_charges(z).charge_amt > 0
         THEN
          INSERT INTO gbl_amc_charges
            (parent_group,
             dealer_map_cd,
             loc_cd,
             comp_fa,
             reg_num,
             pkg_code,
             srl_num,
             srv_type,
             srv_cd,
             charge_srl,
             common_ind,
             order_srl,
             charge_cd,
             charge_type,
             charge_ind,
             charge_value,
             charge_amt)
          VALUES
            (p_parent,
             p_dealer,
             p_loc,
             p_comp,
             p_reg_num,
             p_pkg_code,
             to_part_charges(z).srl_num,
             to_part_charges(z).srv_type,
             to_part_charges(z).opr_cd,
             to_part_charges(z).charge_srl,
             to_part_charges(z).common_ind,
             to_part_charges(z).order_srl,
             to_part_charges(z).charge_cd,
             to_part_charges(z).charge_type,
             to_part_charges(z).charge_ind,
             to_part_charges(z).charge_value,
             to_part_charges(z).charge_amt);
        END IF;
      END LOOP;
    END IF;
    COMMIT;
  END sp_pop_pkg_dtl;
```

#### SP-020 — PKG_AMC.SP_VIN_VALIDATE

**Invoked From:**

- vt_amc_enq_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

Vehicle Details (N/A / CN_MAIN)

---

**Purpose**

Validates a vehicle identification number (VIN) against several business eligibility rules before an AMC/MCP enquiry can be raised: the VIN must exist in the vehicle master, must not already have an active MCP contract, must be within the allowed age and mileage thresholds, must not belong to a model exempted from MCP, and must not be flagged as a restricted vehicle; it also returns the vehicle age in years and the average odometer reading per year for use in the enquiry.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| P_PMC | NUMBER | IN |
| P_VIN | VARCHAR2 | IN |
| P_DATE | DATE | IN |

**Output Parameters**

| Output | Source | Datatype |
|--------|--------|---------|
| P_VEH_AGE | NUMBER | OUT |
| P_AVG_RUN | NUMBER | OUT |
| P_ERR_CD | NUMBER | OUT |
| P_ERR_MSG | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 — Count VIN occurrences in `GM_VIN`; if the count is less than 1, set the error code to `1` with the message "Enter a valid VIN".
- Step 2 — If no error so far, look up the existing MCP expiry date from `GM_VIN_EXT`; if the expiry date is non-null and is after the enquiry date (`P_DATE`), set error code to `1` with the message "Active MCP already available against the Vehicle".
- Step 3 — If no error so far, retrieve the maximum validity months and validity mileage currently in force from `VM_AMC_PARAM` (filtered to the current date range and principal map code).
- Step 4 — Look up the vehicle's invoice date, last odometer reading, and model code from `GM_VIN`.
- Step 5 — Check whether the vehicle's model code appears in the `AM_LIST_RANGE` exception list (`list_name = 'AMC_EXCEPTION'`) with an unexpired close date; set the exception flag (`lv_excp_yn`) accordingly.
- Step 6 — Check whether the VIN is present in `VM_RESTRICTED_VIN` with both `active_yn = 'Y'` and `approve_yn = 'Y'`; set the restricted flag (`lv_rest_yn`) accordingly.
- Step 7 — Apply the model exception check: if `lv_excp_yn = 'Y'`, set error code to `1` with the message "MCP cannot be issued against defined models."
- Step 8 — If the vehicle's invoice/sale date is NULL, set error code to `1` with the message "Vehicle sale date is not available".
- Step 9 — If the enquiry date exceeds the maximum allowed MCP issue window (`sale_date + validity_months − 1 day`), set error code to `1` with the message "Enquiry for a vehicle can be generated within 4yrs of vehicle sale".
- Step 10 — If the last odometer reading exceeds the maximum allowed mileage, set error code to `1` with the message "Milease expired, So Vehicle can not be considered for MCP".
- Step 11 — If the vehicle is on the restricted list (`lv_rest_yn = 'Y'`), set error code to `1` with the message "Restricted Vehicle can not be considered for MCP".
- Step 12 — Calculate vehicle age in years as `(P_DATE − sale_date) / 365` (truncated to 2 decimal places) and average annual run as `odometer / vehicle_age`; if the division fails (e.g. zero age), default `P_AVG_RUN` to `1`.
- Step 13 — Return the accumulated error code and message in `P_ERR_CD` and `P_ERR_MSG`.

---

**Decision Points**

DP-001

Condition:
The VIN count in `GM_VIN` is less than 1.

TRUE:
Set error code to `1` and message to "Enter a valid VIN"; all subsequent validation steps are skipped.

FALSE:
Proceed to check for an active MCP contract.

DP-002

Condition:
An existing MCP expiry date exists in `GM_VIN_EXT` and it is later than the enquiry date (`P_DATE`).

TRUE:
Set error code to `1` and message to "Active MCP already available against the Vehicle"; further validation is skipped.

FALSE:
Proceed to retrieve the AMC validity parameters and vehicle master data.

DP-003

Condition:
The vehicle's model code is listed in `AM_LIST_RANGE` under `AMC_EXCEPTION` with an unexpired close date.

TRUE:
Set error code to `1` and message to "MCP cannot be issued against defined models."

FALSE:
Continue to check the sale date availability.

DP-004

Condition:
The vehicle's invoice/sale date (`inv_date`) is NULL.

TRUE:
Set error code to `1` and message to "Vehicle sale date is not available".

FALSE:
Continue to check whether the vehicle is within the allowed MCP issue window.

DP-005

Condition:
The enquiry date is later than `sale_date + validity_months − 1 day` (the MCP issue deadline).

TRUE:
Set error code to `1` and message to "Enquiry for a vehicle can be generated within 4yrs of vehicle sale".

FALSE:
Continue to check the odometer reading.

DP-006

Condition:
The vehicle's last recorded odometer reading exceeds the maximum allowed mileage (`validity_mileage`).

TRUE:
Set error code to `1` and message to "Milease expired, So Vehicle can not be considered for MCP".

FALSE:
Continue to check whether the VIN is restricted.

DP-007

Condition:
The VIN is present in `VM_RESTRICTED_VIN` with both `active_yn = 'Y'` and `approve_yn = 'Y'`.

TRUE:
Set error code to `1` and message to "Restricted Vehicle can not be considered for MCP".

FALSE:
All eligibility checks pass; proceed to calculate vehicle age and average run.

---

**Database Interactions**

- DB-001 — Read SI_INVD — referenced in a commented-out validation query (original check for VIN existence via the invoice detail table); this code is inactive and not executed at runtime.
- DB-002 — Read GM_VIN — count VIN occurrences to confirm the vehicle exists in the master, and later retrieve the vehicle's invoice date, last odometer reading, and model code.
- DB-003 — Read gm_vin_ext — retrieve the existing MCP expiry date for the VIN to detect an active contract.
- DB-004 — Read vm_amc_param — retrieve the currently applicable maximum validity months and mileage thresholds for MCP issuance, filtered by the current date and principal map code.
- DB-005 — Read gm_vin — retrieve vehicle sale date, odometer reading, and model code for eligibility validation and vehicle age calculation (same table as DB-002; separate logical access within the validation block).
- DB-006 — Read am_list_range — check whether the vehicle's model is listed under the `AMC_EXCEPTION` list with an unexpired close date, to enforce the model-exclusion rule.
- DB-007 — Read vm_restricted_vin — check whether the VIN is flagged as both active and approved in the restricted VIN register, to enforce the restricted-vehicle exclusion rule.

---

**Business Rules**

- SBR-001 — A VIN must exist in the vehicle master (`GM_VIN`) before any MCP eligibility check is performed.
- SBR-002 — A vehicle with an active MCP contract (current expiry date beyond the enquiry date) cannot be issued a new MCP.
- SBR-003 — Models listed in the `AM_LIST_RANGE` exception register (`AMC_EXCEPTION`) with an unexpired close date are excluded from MCP issuance.
- SBR-004 — A vehicle's invoice/sale date must be recorded; a missing sale date disqualifies the vehicle.
- SBR-005 — An MCP enquiry can only be raised within the number of months defined in `VM_AMC_PARAM` (commonly 48 months / 4 years) of the vehicle's sale date.
- SBR-006 — A vehicle whose last recorded odometer reading exceeds the validity mileage defined in `VM_AMC_PARAM` is not eligible for MCP.
- SBR-007 — A VIN that is both active and approved in the restricted VIN register (`VM_RESTRICTED_VIN`) cannot be considered for MCP.

---

**Implementation Logic**

```plsql
  PROCEDURE SP_VIN_VALIDATE(P_PMC     IN NUMBER,
                            P_VIN     IN VARCHAR2,
                            P_DATE    IN DATE,
                            P_VEH_AGE OUT NUMBER,
                            P_AVG_RUN OUT NUMBER,
                            P_ERR_CD  OUT NUMBER,
                            P_ERR_MSG OUT VARCHAR2) IS
    vin_cnt    NUMBER := 0;
    lv_err_cd  NUMBER := 0;
    lv_err_msg VARCHAR2(200) := null;

    ld_sale_dt  gm_vin.inv_date%type;
    ln_odometer gm_vin.last_ro_odometer_reading%type;
    lv_model_cd gm_vin.model_cd%type;
    lv_excp_yn  VARCHAR2(1);
    ln_val_mon  vm_amc_param.validity_months%type;
    ln_val_mil  vm_amc_param.validity_mileage%type;

    ld_exp_dt gm_vin_ext.amc_exp_date%type;
    lv_rest_yn    VARCHAR2(1); -- Added by Rajeev on 01-FEB-2024 for Restricted VIN check
  BEGIN
    -- Valication from si_invd commented and checked from gm_vin as discussed with Prerna.
    --SELECT count(*) INTO vin_cnt FROM SI_INVD WHERE INVD_VIN = P_VIN;
    SELECT count(*) INTO vin_cnt FROM GM_VIN WHERE VIN = P_VIN;
    IF vin_cnt < 1 THEN
      lv_err_cd  := 1;
      lv_err_msg := 'Enter a valid VIN';
    END IF;

    IF lv_err_cd != 1 THEN
      BEGIN
        SELECT x.amc_exp_date
          INTO ld_exp_dt
          FROM gm_vin_ext x
         WHERE x.vin = P_VIN;
      EXCEPTION
        WHEN OTHERS THEN
          ld_exp_dt := NULL;
      END;
      IF trunc(ld_exp_dt) > trunc(P_DATE) AND ld_exp_dt IS NOT NULL THEN
        lv_err_cd  := 1;
        lv_err_msg := 'Active MCP already available against the Vehicle';
      END IF;
    END IF;

    IF lv_err_cd != 1 THEN
      BEGIN
        SELECT MAX(validity_months), MAX(validity_mileage)
          INTO ln_val_mon, ln_val_mil
          FROM vm_amc_param
         WHERE trunc(sysdate) BETWEEN trunc(valid_from_date) AND
               nvl(trunc(valid_to_date), trunc(sysdate))
           AND PRINCIPAL_MAP_CD = P_PMC;
      END;

      BEGIN
        SELECT inv_date, NVL(last_ro_odometer_reading, 0), model_cd
          INTO ld_sale_dt, ln_odometer, lv_model_cd
          FROM gm_vin
         WHERE vin = P_VIN;

        BEGIN
          SELECT 'Y'
            INTO lv_excp_yn
            FROM am_list_range
           WHERE PRINCIPAL_MAP_CD = P_PMC
             AND list_name = 'AMC_EXCEPTION'
             AND list_code = lv_model_cd
             AND nvl(close_date, sysdate) >= sysdate;
        EXCEPTION
          WHEN OTHERS THEN
            lv_excp_yn := 'N';
        END;

        -- Added by Rajeev on 01-FEB-2024 for Restricted VIN check
        BEGIN
          SELECT 'Y' INTO lv_rest_yn
            FROM vm_restricted_vin v
           WHERE v.vin = p_vin
             AND NVL(v.active_yn,'N') = 'Y'
             AND NVL(v.approve_yn,'N') = 'Y';
        EXCEPTION WHEN OTHERS THEN
            lv_rest_yn   := 'N';
        END;

        IF lv_excp_yn = 'Y' THEN
          lv_err_cd  := 1;
          lv_err_msg := 'MCP cannot be issued against defined models.';
        ELSIF ld_sale_dt IS NULL THEN
          lv_err_cd  := 1;
          lv_err_msg := 'Vehicle sale date is not available';
        ELSIF P_DATE > add_months(ld_sale_dt - 1, ln_val_mon) THEN
          lv_err_cd  := 1;
          lv_err_msg := 'Enquiry for a vehicle can be generated within 4yrs of vehicle sale';
        ELSIF ln_odometer > ln_val_mil THEN
          lv_err_cd  := 1;
          lv_err_msg := 'Milease expired, So Vehicle can not be considered for MCP';
        ELSIF NVL(lv_rest_yn,'N') = 'Y' THEN -- Added by Rajeev on 01-FEB-2024 for Restricted VIN check
          lv_err_cd  := 1;
          lv_err_msg := 'Restricted Vehicle can not be considered for MCP';
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          lv_err_cd  := 1;
          lv_err_msg := 'problem in Vehicle master ' || SQLERRM;
      END;
    END IF;

    BEGIN
      P_VEH_AGE := Trunc((trunc(P_DATE) - trunc(ld_sale_dt)) / 365, 2);
      P_AVG_RUN := Trunc(ln_odometer / P_VEH_AGE);
      --P_AVG_RUN := TRUNC(Trunc(ln_odometer / P_VEH_AGE)/365,2);
    EXCEPTION
      WHEN OTHERS THEN
        P_AVG_RUN := 1;
    END;

    P_ERR_CD  := lv_err_cd;
    P_ERR_MSG := lv_err_msg;
  END;
```

#### SP-021 — PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM

**Invoked From:**

- vt_amc_enq_fmb.xml [Trigger: FT_SAVE]

---

**Screen:**

N/A

---

**Purpose**

Generates the next sequential document number for a given document type, dealer, location, and financial year by exclusively locking the corresponding row in the `AM_DOCS` counter table, incrementing the stored sequence number, and returning the formatted document number string; it reports a descriptive error if the document type is not configured, has duplicate configuration rows, or is locked by another user session.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| pi_dealer_map_cd | NUMBER | IN |
| pi_principal_map_cd | NUMBER | IN |
| pi_loc_cd | VARCHAR2 | IN |
| pi_comp_fa | VARCHAR2 | IN |
| pi_doc_type | VARCHAR2 | IN |
| pi_fin_yr | NUMBER | IN |
| pi_last_doc_date | DATE | IN |

**Output Parameters**

| Output | Source | Datatype |
|--------|--------|---------|
| po_doc_num | VARCHAR2 | OUT |
| po_err_msg | VARCHAR2 | OUT |
| po_error | NUMBER | OUT |

---

**Dependencies**

- WEBUTIL.PUT_LINE ([SP-029](#SP-029--WEBUTIL.PUT_LINE)) — WEBUTIL.pck (or .pld)
- WEBUTIL.WAIT ([SP-032](#SP-032--WEBUTIL.WAIT)) — WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 — Lock the matching `AM_DOCS` row using `SELECT … FOR UPDATE WAIT 5`, retrieving the current document prefix, sequence number, suffix, and row ID for the supplied dealer, principal, location, component, document type, and financial year.
- Step 2 — Handle exceptions from the lock attempt: if no row exists, set error to `1` with "Type not defined in the document master"; if duplicate rows exist, set error to `1` with "Duplicate rows in the document master"; if the row is locked by another session (ORA-00054), set error to `1` with "Record is used by another user. Please Re-try"; for any other database error, set error to `1` with the SQLERRM text.
- Step 3 — If no error was raised during the lock step, increment the sequence number by 1 and format the output document number as `prefix || suffix || LPAD(new_seq, 6, '0')`.
- Step 4 — Update the `AM_DOCS` row (by ROWID) to persist the new sequence number and record the last document date (`pi_last_doc_date`).
- Step 5 — If any exception occurs in the outer block, set error to `1` and append the SQLERRM to the error message.

---

**Decision Points**

DP-001

Condition:
The `SELECT … FOR UPDATE WAIT 5` query returns exactly one row without raising an exception.

TRUE:
Increment the document sequence, format the document number, and update the `AM_DOCS` row.

FALSE:
Set the error output to `1` with a descriptive message based on the specific exception (`NO_DATA_FOUND`, `TOO_MANY_ROWS`, ORA-00054 lock timeout, or any other error); skip the increment and update steps.

DP-002

Condition:
The exception raised during the lock attempt is ORA-00054 (resource busy / lock timeout).

TRUE:
Set the error message to "Record is used by another user. Please Re-try".

FALSE:
Set the error message to the generic SQLERRM from the database.

---

**Database Interactions**

- DB-001 — Read AM_DOCS — lock and retrieve the current document number sequence, prefix, and suffix for the given document type and financial year combination, using `SELECT … FOR UPDATE WAIT 5` to ensure exclusive access during number generation.
- DB-002 — Update WAIT — represents the `WAIT 5` clause of the locking SELECT; no separate table is updated; this entry reflects the locking operation on `AM_DOCS`.
- DB-003 — Update AM_DOCS — persist the incremented sequence number and the last document date back to the `AM_DOCS` row identified by its ROWID, completing the atomic number reservation.

---

**Business Rules**

- SBR-001 — The document type must have exactly one configuration row in `AM_DOCS` for the given dealer, principal, location, component, and financial year; absence or duplication is treated as a configuration error.
- SBR-002 — The `AM_DOCS` row must be exclusively locked before incrementing to prevent concurrent sessions from issuing duplicate document numbers; a wait of up to 5 seconds is allowed before failing.
- SBR-003 — The generated document number is formatted as `prefix || suffix || six-digit zero-padded sequence`, ensuring a consistent and sortable number format.
- SBR-004 — If the lock cannot be acquired within 5 seconds (ORA-00054), the procedure returns a user-friendly message instructing the operator to retry rather than exposing a raw database error.

---

**Implementation Logic**

```plsql
      PROCEDURE Generate_Next_Num (
            pi_dealer_map_cd      IN       NUMBER,
            pi_principal_map_cd   IN       NUMBER,
            pi_loc_cd             IN       VARCHAR2,
            pi_comp_fa            IN       VARCHAR2,
            pi_doc_type           IN       VARCHAR2,
            po_doc_num            OUT      VARCHAR2,
            po_err_msg            OUT      VARCHAR2,
            po_error              OUT      NUMBER,
            pi_fin_yr             IN       NUMBER,
            pi_last_doc_date      IN       DATE DEFAULT SYSDATE
      )
      IS
            lv_doc_prefix   VARCHAR2 (4);
            lv_doc_num      NUMBER (6);
            lv_doc_suffix   VARCHAR2 (2);
            lock_found      EXCEPTION;
            lv_year         VARCHAR2 (1);
            lv_rowid        ROWID;
            PRAGMA EXCEPTION_INIT (lock_found, -54);
            v_sql           VARCHAR2 (2000);
      BEGIN

            BEGIN

                  SELECT     doc_prefix,
                             doc_num,
                             doc_suffix,
                             ROWID
                        INTO lv_doc_prefix,
                             lv_doc_num,
                             lv_doc_suffix,
                             lv_rowid
                        FROM AM_DOCS
                       WHERE dealer_map_cd = pi_dealer_map_cd
                         AND principal_map_cd = pi_principal_map_cd
                         AND loc_cd = pi_loc_cd
                         AND comp_fa = pi_comp_fa
                         AND doc_type = pi_doc_type
                         AND Fin_Year = pi_fin_yr
                  FOR UPDATE WAIT 5;
            EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                        po_error := 1;
                        po_err_msg := po_err_msg || ' Type not defined in the document master';
                  WHEN TOO_MANY_ROWS THEN
                        po_error := 1;
                        po_err_msg := po_err_msg || ' Duplicate rows in the document master';
                  WHEN OTHERS THEN
                        po_error := 1;

                        IF SQLCODE = -54 THEN                                                             ---IN (-30006,-54) THEN
                              po_err_msg := 'Record is used by another user.Please Re-try';
                        ---RAISE_APPLICATION_ERROR(-54,'Record is used by another user.Please Re-try');
                        ELSE
                              po_err_msg := 'Execution failed while trying to access the record ' || SQLERRM;
                        END IF;
            END;

            /*EXECUTE IMMEDIATE v_sql
                         INTO lv_doc_prefix,
                              lv_doc_num,
                              lv_doc_suffix,
                              lv_rowid
                        USING pi_dealer_map_cd, pi_principal_map_cd, pi_loc_cd, pi_comp_fa, pi_doc_type, pi_fin_yr;*/
            IF NVL ( po_error, 0) <> 1 THEN
                  lv_doc_num := lv_doc_num + 1;
                  po_doc_num := lv_doc_prefix || lv_doc_suffix || LPAD (lv_doc_num, 6, '0');

                  UPDATE AM_DOCS
                     SET doc_num = lv_doc_num,
                         last_doc_date = pi_last_doc_date
                   WHERE ROWID = lv_rowid;
            END IF;
      EXCEPTION
            WHEN NO_DATA_FOUND THEN
                  po_error := 1;
                  po_err_msg := po_err_msg || ' Type not defined in the document master';
            WHEN TOO_MANY_ROWS THEN
                  po_error := 1;
                  po_err_msg := po_err_msg || ' Duplicate rows in the document master';
            WHEN OTHERS THEN
                  po_error := 1;
                  po_err_msg := po_err_msg || SQLERRM;
                  DBMS_OUTPUT.put_line ('ERRORCD' || po_error);
      END Generate_Next_Num;
```

#### SP-022 — WEBUTIL.ERRORALERT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.PUT_LINE]

---

**Screen:**

-(Invoked indirectly — screen follows parent invocation site.)

---

**Purpose**

Displays a WebUtil error message to the user: if a pre-configured alert object (`m_errorAlert`) is available in the form, it updates the alert's message text and shows it as a modal alert; if no alert object is configured, it falls back to the standard Forms `MESSAGE` procedure to display the error.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| errText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-027](#SP-027--WEBUTIL.ID_NULL)) — WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 — Check whether the module-level alert object handle (`m_errorAlert`) is non-null by calling `ID_NULL(m_errorAlert)`.
- Step 2 — If the alert handle is valid (not null), set the alert's message text to `errText` using `SET_ALERT_PROPERTY` and display it with `SHOW_ALERT`; the alert result is discarded.
- Step 3 — If the alert handle is null (no alert object configured), fall back to `MESSAGE('WebUtil Error' || ': ' || errText)` to present the error as a standard Forms status-line message.

---

**Decision Points**

DP-001

Condition:
The `m_errorAlert` handle is not null (a pre-configured alert object exists in the form).

TRUE:
Set the alert's message text to `errText` and display the modal alert dialog.

FALSE:
Display the error as a plain Forms message in the format "WebUtil Error: <errText>".

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 — The alert dialog is only used when a valid alert object has been registered in the form; otherwise the fallback message mechanism ensures the error is always surfaced to the user regardless of alert configuration.
- SBR-002 — The error text is always prefixed with "WebUtil Error" when displayed via the fallback `MESSAGE` path, ensuring consistent identification of the error source.

---

**Implementation Logic**

```plsql
  
  PROCEDURE ErrorAlert(errText in VARCHAR2) is
    -- currently used for throwing a BEAN_NOT_REGISTERED or bean not found error.
    ignore integer;
  begin
    if not ID_NULL(m_errorAlert) then 
      --SET_ALERT_PROPERTY(m_errorAlert,TITLE,'WebUtil Error'); -- title already set in alert property
      SET_ALERT_PROPERTY(m_errorAlert,ALERT_MESSAGE_TEXT,errText);
      ignore := SHOW_ALERT(m_errorAlert);
    else
      message('WebUtil Error'||': '||errText);
    end if;
  end ErrorAlert;
```

#### SP-023 — WEBUTIL.FCLOSE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly — screen follows parent invocation site.)

---

**Purpose**

Closes an open client-side text file handle managed by the WebUtil framework, releasing the underlying Java resource and nullifying the in-memory handle so the file is no longer accessible for further read or write operations.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| file | file_type | IN OUT |

**Output Parameters**

| Output | Source | Datatype |
|--------|--------|---------|
| file | file_type | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 — Check whether the supplied file handle is currently open (handle IS NOT NULL).
- Step 2 — If open, instruct the WebUtil Core bean to close the file by setting the `WUF_TEXTIO_CLOSE` property with the file's handle value.
- Step 3 — Nullify the in-memory handle to signal that the file is no longer open.
- Step 4 — If the WebUtil bean is not registered, display an error alert identifying the missing implementation class and raise `TOOL_ERR.TOOL_ERROR` to abort the caller.
- Step 5 — If a property error occurs during the close operation, re-raise `TOOL_ERR.TOOL_ERROR` to propagate the failure to the caller.

---

**Decision Points**

DP-001

Condition:
The file handle is not NULL (i.e., the file is currently open).

TRUE:
Send the close command to the WebUtil Core bean and nullify the handle.

FALSE:
Do nothing — no close command is issued and the handle is left unchanged.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 — A file close operation is only attempted when the handle is non-NULL; attempting to close an already-closed or never-opened file is silently ignored.
- SBR-002 — If the WebUtil bean required for client-side file I/O is not registered, the procedure raises a fatal `TOOL_ERR.TOOL_ERROR` rather than silently failing.

---

**Implementation Logic**

```plsql
 
  PROCEDURE fclose (file IN OUT file_type) is 
  BEGIN 
    if (file.handle IS NOT NULL) then 
      WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CLOSE',file.handle);        
      file.handle := NULL;
    end if;
 
 EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.fclose will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;
  END fclose;
```

#### SP-024 — WEBUTIL.FOPEN

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly — screen follows parent invocation site.)

---

**Purpose**

Opens a client-side text file via the WebUtil Java bean for reading, writing, or appending, returning a file handle that subsequent client file I/O operations can use. It validates the requested mode and file specification before delegating the physical open to the WebUtil Core layer.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| spec | VARCHAR2 | IN |
| filemode | VARCHAR2 | IN |
| charSet | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 — Validate that the requested file mode is one of the three permitted values: `r` (read), `w` (write), or `a` (append), using a case-insensitive check; raise `TOOL_ERR.TOOL_ERROR` immediately if the mode is invalid.
- Step 2 — Validate that a non-null, non-empty file specification (path/name) has been supplied; raise `TOOL_ERR.TOOL_ERROR` immediately if not.
- Step 3 — Pass the file specification to the WebUtil Core bean by setting the `WUF_FILENAME` property.
- Step 4 — Pass the file mode to the WebUtil Core bean by setting the `WUF_TEXTIO_FILEMODE` property.
- Step 5 — Pass the character-set to the WebUtil Core bean: if no character set was supplied, send the literal string `(null)`; otherwise send the provided character-set value, via the `WUF_TEXTIO_CHARSET` property.
- Step 6 — Instruct the WebUtil Core bean to open the file by reading the `WUF_TEXTIO_OPEN` property, which returns a Java file handle string.
- Step 7 — If the returned handle is null, empty, or equals `-1`, the file could not be opened; raise `TOOL_ERR.TOOL_ERROR`.
- Step 8 — Convert the returned Java handle string to a number and store it in the `clientFile.handle` field, then return the populated `file_type` record to the caller.
- Step 9 — On `BEAN_NOT_REGISTERED`: display an error alert identifying the missing WebUtil class and raise `TOOL_ERR.TOOL_ERROR`.
- Step 10 — On `PROPERTY_ERROR`: re-raise the original exception. On `VALUE_ERROR` (handle conversion failure) or `TOOL_ERR.TOOL_ERROR`: raise `TOOL_ERR.TOOL_ERROR`.

---

**Decision Points**

DP-001

Condition:
The supplied file mode (lowercased) is one of `r`, `w`, or `a`.

TRUE:
Continue to validate the file specification.

FALSE:
Raise `TOOL_ERR.TOOL_ERROR` immediately — no file is opened.

DP-002

Condition:
The supplied file specification (`spec`) is non-null and non-empty.

TRUE:
Proceed to configure and open the file via WebUtil Core.

FALSE:
Raise `TOOL_ERR.TOOL_ERROR` immediately — no file is opened.

DP-003

Condition:
A character set value was supplied (charSet is not null).

TRUE:
Pass the provided character-set string to the WebUtil Core bean.

FALSE:
Pass the literal string `(null)` to the WebUtil Core bean, signalling no explicit encoding.

DP-004

Condition:
The Java handle returned by the WebUtil Core open operation is non-null, non-empty, and not equal to `-1`.

TRUE:
Convert the handle to a number and return it as the file handle to the caller.

FALSE:
Raise `TOOL_ERR.TOOL_ERROR` — the file was not successfully opened.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 — Only the file modes `r`, `w`, and `a` (case-insensitive) are accepted; any other mode causes an immediate error.
- SBR-002 — A file specification must be provided; attempting to open a file without a path or name is not permitted.
- SBR-003 — A return handle of null, empty string, or `-1` from the WebUtil layer is treated as a failed open and causes an error to be raised.
- SBR-004 — If the WebUtil bean is not registered in the runtime environment, callers are notified via an error alert and processing is aborted.

---

**Implementation Logic**

```plsql
  FUNCTION fopen(spec VARCHAR2, filemode VARCHAR2, charSet VARCHAR2 := null) RETURN file_type is
    clientFile file_type;
    javaHandle VARCHAR2(6);
  BEGIN
    -- check the mode is valid
    if (lower(filemode) not in ('r','w','a')) then 
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- make sure a file name has been specified      
    if (spec is null) or (spec='') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;
      
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILENAME',spec, true);
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_FILEMODE',filemode, true);        
    if (charSet is null) then
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET','(null)', true);
    else
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET',charSet, true);
    end if;
    javaHandle := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_OPEN');

    -- If the return is null then the file was not opened      
    if (javaHandle is null) or (javaHandle='') or (javaHandle='-1') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- if we are this far convert the handle to the correct format and return it.      
    clientFile.handle := to_number(javaHandle);
    return clientFile;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.fopen will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                 
      return null;
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE;
    when VALUE_ERROR then
      RAISE TOOL_ERR.TOOL_ERROR; 
    when TOOL_ERR.TOOL_ERROR then 
      RAISE;
  END fopen;
```

#### SP-025 — WEBUTIL.GETIMPLCLASS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.PUT_LINE]

---

**Screen:**

-(Invoked indirectly — screen follows parent invocation site.)

---

**Purpose**

Returns the fully qualified Java implementation class name for a given WebUtil package ID by concatenating the configured Java root path with the class entry stored in the `m_implClasses` array; this is used to construct descriptive error messages when a required WebUtil bean is not found on the client.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| packageID | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 — Concatenate the module-level `WEBUTIL_JAVA_ROOT` constant with the class name stored at index `packageID` in the `m_implClasses` associative array.
- Step 2 — Return the resulting fully qualified class name string to the caller.

---

**Decision Points**

No business-significant decision points in this routine.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 — The implementation class name for each WebUtil package is looked up solely from the in-memory `m_implClasses` array using the integer package ID; no fallback or default is applied if the index is absent.

---

**Implementation Logic**

```plsql

  FUNCTION getImplClass(packageID PLS_INTEGER) return VARCHAR2 is
  BEGIN 
    return WEBUTIL_JAVA_ROOT||m_implClasses(packageID);    
  END;
```

#### SP-026 — WEBUTIL.GETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTER_FUNCTION]

---

**Screen:**

-(Invoked indirectly — screen follows parent invocation site.)

---

**Purpose**

Retrieves the value of a named Java system property from the WebUtil JNI bridge by invoking `java.lang.System.getProperty`, returning the result as a VARCHAR2 string to the caller.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 — Create a JNI argument list of size 1.
- Step 2 — Add the property name (`a0`) as a String argument to the argument list.
- Step 3 — Invoke the Java static method `java.lang.System.getProperty(String)` via JNI with the prepared argument list.
- Step 4 — Return the resulting string value to the caller.

---

**Decision Points**

No business-significant decision points in this routine.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 — Property lookup is delegated entirely to the Java runtime via JNI; the PL/SQL layer performs no caching, defaulting, or transformation of the returned value.

---

**Implementation Logic**

```plsql
  FUNCTION getProperty(
    a0    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'getProperty', '(Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-027 — WEBUTIL.ID_NULL

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.ERRORALERT]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTER_FUNCTION]

---

**Screen:**

-(Invoked indirectly — screen follows parent invocation site.)

---

**Purpose**

Tests whether a WebUtil `Pointer` handle is null, returning TRUE if the handle's internal numeric identifier (`hnd`) is null and FALSE otherwise. Callers use this function to determine whether a previously obtained handle is valid before attempting to use it.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| handle | Pointer | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 — Examine the `hnd` field of the supplied `Pointer` record.
- Step 2 — If `hnd` is null, return TRUE to indicate the handle is invalid.
- Step 3 — If `hnd` is not null, return FALSE to indicate the handle is valid.

---

**Decision Points**

DP-001

Condition:
The `hnd` field of the input `handle` record is NULL.

TRUE:
Return TRUE — the handle is considered null/invalid.

FALSE:
Return FALSE — the handle is considered valid and non-null.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 — A `Pointer` handle is considered null if and only if its `hnd` numeric field is NULL; no other field or state is examined.

---

**Implementation Logic**

```plsql

  FUNCTION ID_NULL(handle IN Pointer)        RETURN BOOLEAN is
  BEGIN
    if handle.hnd is null then 
      return TRUE;
    else
      return FALSE;
    end if;
  END ID_NULL;
```

#### SP-028 — WEBUTIL.LENGTH

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- SP_VALIDATE_ALPHANUMERIC.prc [StoredProcedure: SP_VALIDATE_ALPHANUMERIC]
- D2kwutil.pld [StoredProcedure: STRIPDIRSEP]

---

**Screen:**

-(Invoked indirectly — screen follows parent invocation site.)

---

**Purpose**

Returns the byte length of a client-side file by invoking the Java `java.io.File.length()` method via the Oracle JNI bridge, allowing callers to determine a file's size without opening it.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 — Reset the JNI argument list to NULL.
- Step 2 — Invoke the `length()` method on the supplied `java.io.File` Java object via `JNI.CALL_LONG_METHOD`, returning the result as a PL/SQL NUMBER representing the file's byte length.

---

**Decision Points**

No business-significant decision points in this routine.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 — The file length is obtained directly from the Java runtime via JNI; no PL/SQL computation or transformation of the value is performed.

---

**Implementation Logic**

```plsql
  FUNCTION length(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_LONG_METHOD(FALSE, obj, 'java/io/File', 'length', '()J', args); 
  END;
```

#### SP-029 — WEBUTIL.PUT_LINE

**Invoked From:**

- PK_VALIDATE_BACK_DATE.pck [StoredProcedure: PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM]

---

**Screen:**

-(Invoked indirectly — screen follows parent invocation site.)

---

**Purpose**

Writes a line of text to an open WebUtil client-side text file by passing the file handle, the text content, and a newline instruction to the underlying WebUtil Java bean via the `WebUtil_Core.setProperty` bridge; if the required Java bean is not registered on the client, it displays an error alert and raises a tool error to abort the operation.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| file | file_type | IN |
| item | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-022](#SP-022--WEBUTIL.ERRORALERT)) — WEBUTIL.pck (or .pld)
- WEBUTIL.GETIMPLCLASS ([SP-025](#SP-025--WEBUTIL.GETIMPLCLASS)) — WEBUTIL.pck (or .pld)
- WEBUTIL.SETPROPERTY ([SP-031](#SP-031--WEBUTIL.SETPROPERTY)) — WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 — Set the `WUF_TEXTIO_HANDLE` property on the `WUF_PACKAGE` bean to the file handle contained in the `file` parameter, identifying which open file to write to.
- Step 2 — Set the `WUF_TEXTIO_PUT` property on the `WUF_PACKAGE` bean to the text string `item`, supplying the content to be written.
- Step 3 — Set the `WUF_TEXTIO_NEWLINE` property to `1`, instructing the bean to append a newline character after the text.
- Step 4 — If the `BEAN_NOT_REGISTERED` exception is raised (the WebUtil Java bean is absent on the client), call `WEBUTIL.ERRORALERT` with a message composed from the implementation class name (retrieved via `WEBUTIL.GETIMPLCLASS`) and a descriptive suffix, then raise `TOOL_ERR.TOOL_ERROR` to stop processing.
- Step 5 — If the `PROPERTY_ERROR` exception is raised (a property set operation failed), raise `TOOL_ERR.TOOL_ERROR` to stop processing.

---

**Decision Points**

DP-001

Condition:
The `BEAN_NOT_REGISTERED` exception is raised during any `setProperty` call (the WebUtil Java bean is not available on the client machine).

TRUE:
Display an error alert naming the missing bean class and raise `TOOL_ERR.TOOL_ERROR` to abort the write operation.

FALSE:
All three property assignments succeed and the line is written to the file.

DP-002

Condition:
The `PROPERTY_ERROR` exception is raised during any `setProperty` call.

TRUE:
Raise `TOOL_ERR.TOOL_ERROR` to abort the write operation without displaying an additional alert.

FALSE:
No exception handling required; processing continues normally.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 — The WebUtil Java bean (`WUF_PACKAGE`) must be registered and active on the client before a text line can be written; its absence is treated as a hard error that aborts the calling operation.
- SBR-002 — Each call to `PUT_LINE` always appends a newline (`WUF_TEXTIO_NEWLINE = 1`), ensuring that successive calls produce separate lines in the output file.

---

**Implementation Logic**

```plsql
    

  PROCEDURE put_line (file file_type, item VARCHAR2) is
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);              
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_PUT',item); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_NEWLINE',1); 
  EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.put_line will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;  
  END put_line;
```

#### SP-030 — WEBUTIL.REGISTER_FUNCTION

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly — screen follows parent invocation site.)

---

**Purpose**

Registers a named function from a specified WebUtil library with the WebUtil Java bean, returning an opaque handle that the caller can use for subsequent native-function invocations. If the bean is unavailable or the registration fails, the routine raises a descriptive alert and aborts processing.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| libName | VARCHAR2 | IN |
| funcName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETPROPERTY ([SP-026](#SP-026--WEBUTIL.GETPROPERTY)) — WEBUTIL.pck (or .pld)
- WEBUTIL.ID_NULL ([SP-027](#SP-027--WEBUTIL.ID_NULL)) — WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 — Publish the library name and function name to the WebUtil bean by setting the `WUL_FUNCTION_SPEC` property as a pipe-delimited string (`libName|funcName`).
- Step 2 — Retrieve the resulting string handle from the WebUtil bean by reading the `WUL_REGISTER_FUNCTION` property.
- Step 3 — Convert the returned string to a numeric handle value and store it in a `FunctionHandle` record.
- Step 4 — Check whether the returned handle is non-null using `ID_NULL`; if the handle is valid, increment the module-level registered-function counter (`m_funcHandleCount`).
- Step 5 — Return the populated `FunctionHandle` to the caller.
- Step 6 — If the WebUtil bean is not registered, display an error alert identifying the missing implementation class and raise `FORM_TRIGGER_FAILURE` to abort the calling trigger.
- Step 7 — If a property error occurs during bean communication, raise `FORM_TRIGGER_FAILURE`.
- Step 8 — If the string-to-number conversion produces a `VALUE_ERROR`, raise `TOOL_ERR.TOOL_ERROR`.

---

**Decision Points**

DP-001

Condition:
The handle returned by the WebUtil bean (`strHnd`) converts to a non-null numeric value (i.e., `ID_NULL(funcHnd)` is FALSE).

TRUE:
Increment the module-level function-handle counter `m_funcHandleCount` to track the number of successfully registered functions.

FALSE:
Do not increment the counter; the handle is considered invalid and the counter remains unchanged.

DP-002

Condition:
The `WebUtil_Core.BEAN_NOT_REGISTERED` exception is raised during bean communication.

TRUE:
Display an error alert naming the missing WebUtil implementation class and raise `FORM_TRIGGER_FAILURE`, halting further processing.

FALSE:
Normal execution continues; no alert is shown for this condition.

DP-003

Condition:
The `WebUtil_Core.PROPERTY_ERROR` exception is raised during property read/write.

TRUE:
Raise `FORM_TRIGGER_FAILURE` immediately, halting further processing without an alert.

FALSE:
Normal execution continues.

DP-004

Condition:
A `VALUE_ERROR` exception is raised when converting the string handle to a number.

TRUE:
Raise `TOOL_ERR.TOOL_ERROR`, signalling a data-conversion failure to the caller.

FALSE:
Normal execution continues.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 — A function can only be registered if the WebUtil bean is active; an absent bean causes an immediate, descriptive failure rather than a silent error.
- SBR-002 — Only a non-null handle resulting from registration increments the global registered-function count, ensuring the counter accurately reflects successfully bound functions.
- SBR-003 — A `VALUE_ERROR` during handle conversion is escalated as `TOOL_ERR.TOOL_ERROR`, distinguishing data-format failures from infrastructure failures.

---

**Implementation Logic**

```plsql

  FUNCTION REGISTER_FUNCTION (libName IN VARCHAR2, funcName IN VARCHAR2) 
                              RETURN FunctionHandle IS
    strHnd  VARCHAR2(8);                            
    funcHnd FunctionHandle;
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUL_PACKAGE,'WUL_FUNCTION_SPEC', libName || '|' || funcName);
    strHnd := WebUtil_Core.getProperty(WebUtil_Core.WUL_PACKAGE,'WUL_REGISTER_FUNCTION');
    funcHnd.hnd := TO_NUMBER (strHnd);
    if NOT ID_NULL(funcHnd) then
      m_funcHandleCount := m_funcHandleCount + 1;
    end if;

    RETURN funcHnd;
    
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUL_PACKAGE)
                              ||' bean not found. WEBUTIL_C_API.REGISTER_FUNCTION will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;  
    when VALUE_ERROR then
        RAISE TOOL_ERR.TOOL_ERROR; 
  END REGISTER_FUNCTION;
```

#### SP-031 — WEBUTIL.SETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.PUT_LINE]

---

**Screen:**

-(Invoked indirectly — screen follows parent invocation site.)

---

**Purpose**

Sets a named Java system property to a specified value on the client JVM by invoking `java.lang.System.setProperty` via the JNI bridge, and returns the previous value of that property; it is used by the WebUtil framework to pass configuration parameters to client-side Java beans.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| a0 | VARCHAR2 | IN |
| a1 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 — Create a two-argument list using `JNI.CREATE_ARG_LIST(2)`.
- Step 2 — Add the property name (`a0`) as a String argument to the argument list.
- Step 3 — Add the property value (`a1`) as a String argument to the argument list.
- Step 4 — Invoke `java.lang.System.setProperty(String, String)` on the client JVM via `JNI.CALL_STRING_METHOD`, passing the two arguments, and return the result (the previous value of the property, or NULL if it was not previously set).

---

**Decision Points**

No business-significant decision points in this routine.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 — Property name and value are both passed as Java `String` arguments; the JNI method signature `(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;` must match the target Java method exactly for the invocation to succeed.

---

**Implementation Logic**

```plsql
  FUNCTION setProperty(
    a0    VARCHAR2,
    a1    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(2);
    JNI.ADD_STRING_ARG(args, a0);
    JNI.ADD_STRING_ARG(args, a1);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'setProperty', '(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-032 — WEBUTIL.WAIT

**Invoked From:**

- PK_VALIDATE_BACK_DATE.pck [StoredProcedure: PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM]

---

**Screen:**

-(Invoked indirectly — screen follows parent invocation site.)

---

**Purpose**

Delegates a Java-level `wait` call to the AppServerFileWriter class on the application server via the Oracle Forms JNI bridge, pausing execution for a caller-specified duration. This is a thin wrapper that marshals the supplied long (milliseconds) and integer arguments into a JNI argument list and invokes the void Java method.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| obj | ORA_JAVA.JOBJECT | IN |
| a0 | NUMBER | IN |
| a1 | NUMBER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 — Create a JNI argument list sized for two arguments.
- Step 2 — Add the first numeric argument (`a0`) as a Java `long` value to the argument list.
- Step 3 — Add the second numeric argument (`a1`) as a Java `int` value to the argument list.
- Step 4 — Invoke the Java `wait(long, int)` void method on the `oracle/forms/webutil/fileTransfer/AppServerFileWriter` object (`obj`) via the JNI bridge, passing the prepared argument list.

---

**Decision Points**

No business-significant decision points in this routine.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 — The target Java method signature is fixed as `(JI)V` (long, int, void return); callers must supply arguments conforming to this signature via `a0` (long) and `a1` (int).

---

**Implementation Logic**

```plsql
  PROCEDURE wait(
    obj   ORA_JAVA.JOBJECT,
    a0    NUMBER,
    a1    NUMBER) IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(2);
    JNI.ADD_LONG_ARG(args, a0);
    JNI.ADD_INT_ARG(args, a1);
    JNI.CALL_VOID_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileWriter', 'wait', '(JI)V', args); 
  END;
```

#### SP-033 — ADD_ERROR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.FILE_INFO]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly — screen follows parent invocation site.)

---

**Purpose**

Records a single error condition on the WIN_API error stack by setting the `ERROR_ENCOUNTERED` flag and writing a formatted error string (caller name plus error text) to `ERROR_STACK`, then logs the assembled message via `DEBUGLOG` at level 99 for diagnostic tracing.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| CallingFunction | VARCHAR2 | IN |
| SetErrorText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-037](#SP-037--DEBUGLOG)) — matched by member name

---

**Step-by-Step Business Logic**

- Step 1 — Set the module-level flag `ERROR_ENCOUNTERED` to `TRUE` to signal that an error has been recorded.
- Step 2 — Compose the error stack entry as `<CallingFunction>: <SetErrorText>`, truncating the error text portion to a combined maximum of 1,968 characters to fit within the `ERROR_STACK` variable.
- Step 3 — Write the composed string to `ERROR_STACK`, overwriting any previously stored error.
- Step 4 — Call `Win_API_Debug.DebugLog` at level 99 with the label `'Add_Error'` and the composed error string to emit a diagnostic trace entry.

---

**Decision Points**

No business-significant decision points in this routine.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 — Each call to `ADD_ERROR` overwrites the previous `ERROR_STACK` entry; only the most recently recorded error is retained.
- SBR-002 — The combined error string stored in `ERROR_STACK` is capped at 1,968 characters (caller function name prefix plus up to 1,968 characters of error text via `SUBSTR`) to prevent buffer overflow.
- SBR-003 — Setting `ERROR_ENCOUNTERED := TRUE` is the authoritative signal used by callers to detect that an error condition was recorded during an operation.

---

**Implementation Logic**

```plsql

PROCEDURE Add_Error (CallingFunction in VARCHAR2, SetErrorText in VARCHAR2) is
begin 
  -- Just watch for value errors 
  ERROR_ENCOUNTERED  := TRUE;
  ERROR_STACK    := CallingFunction||': '||substr(SetErrorText,1,1968);
  Win_API_Debug.DebugLog(99,'Add_Error',ERROR_STACK);
end Add_Error;
```

#### SP-034 — ADD_EXTERNAL_ERRORS

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.FILE_INFO]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly — screen follows parent invocation site.)

---

**Purpose**

Collects and concatenates any pending error messages from the `TOOL_ERR` error stack — or, if the stack is empty, the current SQL error message — into a single string, so callers can append contextual error detail to their own error reports.

---

**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 — Check whether the `TOOL_ERR` error stack contains one or more pending errors (`tool_err.nerrors > 0`).
- Step 2 — If the stack has errors, iterate through each entry: append a newline followed by the current top-of-stack message (`tool_err.message`) to the accumulation buffer, then pop the entry from the stack (`tool_err.pop`).
- Step 3 — If appending a message would exceed the 1968-character buffer limit (`VALUE_ERROR`), stop the loop immediately to avoid truncation errors.
- Step 4 — If the error stack is empty but `SQLERRM` is non-null, append a newline and the SQL error message to the buffer instead.
- Step 5 — Return the accumulated error string to the caller.

---

**Decision Points**

DP-001

Condition:
`tool_err.nerrors` is greater than zero (there are pending errors on the TOOL_ERR stack).

TRUE:
Iterate through the error stack, concatenating each message into the buffer and popping each entry; stop early if the buffer would overflow.

FALSE:
Check `SQLERRM` for a SQL-level error message instead.

DP-002

Condition:
`SQLERRM` is not null (a SQL error is active) and the TOOL_ERR stack was empty.

TRUE:
Append the SQL error message to the buffer.

FALSE:
Return an empty (null) buffer.

DP-003

Condition:
Appending the next TOOL_ERR message would cause a `VALUE_ERROR` (buffer overflow beyond 1968 characters).

TRUE:
Exit the loop immediately, discarding any remaining stack messages.

FALSE:
Continue appending and popping messages.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 — The accumulated error buffer is capped at 1968 characters; any messages that would exceed this limit are silently discarded to prevent a runtime error.
- SBR-002 — The TOOL_ERR stack takes precedence over `SQLERRM`; the SQL error is only appended when the stack is empty.
- SBR-003 — Each error message is consumed (popped) from the TOOL_ERR stack as it is appended, so the stack is drained as a side effect of calling this function.

---

**Implementation Logic**

```plsql

FUNCTION Add_External_Errors return varchar2 is
  iCounter   pls_integer;
  vcErrBuff  varchar2(1968);
begin 
  if tool_err.nerrors > 0 then 
    for iCounter in 1..tool_err.nerrors LOOP
      begin 
        vcErrBuff := vcErrBuff||chr(10)||tool_err.message;
      exception
        when VALUE_ERROR then 
          exit; /* String exceeds allowable buffer */
      end;
      tool_err.pop;
    end loop;
  elsif SQLERRM is not null then 
    vcErrBuff := chr(10)||SQLERRM; 
  end if;
  return vcErrBuff;
end Add_External_Errors;
```

#### SP-035 — BOOLTOCHAR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.FILE_INFO]

---

**Screen:**

-(Invoked indirectly — screen follows parent invocation site.)

---

**Purpose**

Converts a PL/SQL BOOLEAN value to its VARCHAR2 string equivalent (`'TRUE'` or `'FALSE'`), allowing Boolean results to be passed to contexts that require character strings.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| ThisBoolean | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 — Evaluate the input BOOLEAN value `ThisBoolean`.
- Step 2 — If the value is TRUE, return the string `'TRUE'`.
- Step 3 — If the value is FALSE (or NULL, by implicit ELSE), return the string `'FALSE'`.

---

**Decision Points**

DP-001

Condition:
The input parameter `ThisBoolean` evaluates to TRUE.

TRUE:
Return the VARCHAR2 literal `'TRUE'`.

FALSE:
Return the VARCHAR2 literal `'FALSE'`.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 — A NULL BOOLEAN input is treated as FALSE and returns the string `'FALSE'`, since the `IF ThisBoolean` condition is only TRUE for a definite TRUE value.

---

**Implementation Logic**

```plsql

  
  FUNCTION  BoolToChar(ThisBoolean IN BOOLEAN) return VARCHAR2 is
  begin
  	if ThisBoolean then 
  		RETURN 'TRUE';
  	else
  	    RETURN 'FALSE';
  	end if;
  end BoolToChar;

END;

PACKAGE WIN_API_DIALOG IS

/*-------------------------------------------------------------------------*\
 * WIN_API_DIALOG ->   This package is concerned with Displaying Common
 *      dialogs
 * Contents:
 *    Open_File    -> Open File Dialog
 *    Save_File    -> Save File Dialog
 *    Select_Printer    -> Printer Selection Dialog
 *    Choose_Font       -> Display the Font Selection Dialog
 *    Choose_Color      -> Display the Color Selection Dialog
 * Dependancies:
 *    WIN_API_ENVIRONMENT
 *    WIN_API
 *    WIN_API_DEBUG
\*-------------------------------------------------------------------------*/ 

/*-------------------------------------------------------------------------*\
 * Open_File        -> Displays the standard Open File dialog
 * Arguments: 
 *  Title           -> The Title for the Dialog Box
 *                     (Default -> 'Open File')
 *  StartDirectory  -> Where the dialog should start from
 *                     this should be in the format 'C:\TEMP'
 *                     (Default -> Windows Directory)
 *  FileFilter      ->  Restrict the list of files. The filter string 
 *                      should be in the format:
 *                      '<Description>|<filename>.<Extension>|'
 *                      typically this would be something like
 *                      'All files(*.*)|*.*|' or 'Text files(*.txt)|*.txt|'
 *                      "All Files" is the Default
 *  Modal           ->  Should the dialog be modal with respect to the 
 *                      application? 
 *                      default = TRUE
 *  AdvancedFlags   ->  (See list in WIN_API header) This option allows
 *                      you to change the attributes of the Open File 
 *                      dialog.  Here are some of the Flags that might
 *                      be of interest:
 *                      OFN_HIDEREADONLY  Hides the Read Only check box.
 *                      OFN_NONETWORKBUTTON  Hides the Network Button
 *                      OFN_EXPLORER    Display an Explorer style 
 *                        Dialog rather than the conventional one.
 *                      See your Microsoft docmentation for details on 
 *                      each flag.
 *                      To Set the Advanced_Flags varaible, just add the 
 *                      required flags together.  The default is:
 *                      WIN_API.OFN_PATHMUSTEXIST + WIN_API.OFN_FILEMUSTEXIST +
 *                      WIN_API.OFN_HIDEREADONLY + WIN_API.OFN_NOCHANGEDIR 
 *  RaiseExceptions ->  TRUE of FALSE(Default) If set to true, then if the 
 *                      command is not successful (e.g no filename is  
 *                      returned) then the explicit exception
 *                      NO_DATA_FOUND will be raised.
 *        
 * Returns:
 *  Path and name of the selected file
\*-------------------------------------------------------------------------*/
```

#### SP-036 — CLEAN_ERROR_STACK

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.FILE_INFO]

---

**Screen:**

-(Invoked indirectly — screen follows parent invocation site.)

---

**Purpose**

Resets the module-level error state by clearing the `ERROR_ENCOUNTERED` flag and nullifying the `ERROR_STACK` string, so that subsequent operations start with a clean error context.

---

**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 — Set the module-level `ERROR_ENCOUNTERED` flag to FALSE, indicating no error is currently recorded.
- Step 2 — Set the module-level `ERROR_STACK` variable to NULL, discarding any previously accumulated error messages.

---

**Decision Points**

No business-significant decision points in this routine.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 — Both `ERROR_ENCOUNTERED` and `ERROR_STACK` must be reset together; clearing one without the other would leave the error state inconsistent.

---

**Implementation Logic**

```plsql

PROCEDURE Clean_Error_Stack is 
begin 
  -- just empty the variables
  ERROR_ENCOUNTERED  := FALSE;
  ERROR_STACK        := NULL;
end Clean_Error_Stack;
```

#### SP-037 — DEBUGLOG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: ADD_ERROR]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.FILE_INFO]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: SETDEBUG]

---

**Screen:**

-(Invoked indirectly — screen follows parent invocation site.)

---

**Purpose**

Writes a formatted diagnostic trace entry to the configured debug output destination — either the native Windows debug viewer or a flat log file — subject to the current debug state, pause state, and level filter. When the preferred output channel is unavailable it automatically falls back to file logging and, conversely, restores window-based logging once the channel becomes available again.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| DebugLevel | PLS_INTEGER | IN |
| LoggingCall | VARCHAR2 | IN |
| LogString | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- SETDEBUG ([SP-039](#SP-039--SETDEBUG)) — matched by member name
- WEBUTIL.FCLOSE ([SP-023](#SP-023--WEBUTIL.FCLOSE)) — WEBUTIL.pck (or .pld)
- WEBUTIL.FOPEN ([SP-024](#SP-024--WEBUTIL.FOPEN)) — WEBUTIL.pck (or .pld)
- WEBUTIL.LENGTH ([SP-028](#SP-028--WEBUTIL.LENGTH)) — WEBUTIL.pck (or .pld)
- WINDEBUG ([SP-044](#SP-044--WINDEBUG)) — matched by member name

---

**Step-by-Step Business Logic**

- Step 1 — If `iDebugState` is `0` (logging disabled), do nothing and return.
- Step 2 — If `bDebugPaused` is TRUE (logging paused), do nothing and return.
- Step 3 — If the supplied `DebugLevel` exceeds `iDebugLevel` (the configured verbosity ceiling), do nothing and return.
- Step 4 — Optionally prepend a `HH24:MI:SS>` timestamp prefix to the message if `bDebugTimeStamp` is TRUE.
- Step 5 — Construct the final debug string: a zero-padded two-digit level indicator (`<NN>`), the optional timestamp, the calling routine name left-padded to 30 characters, followed by the log string (truncated so the total does not exceed 2,000 characters).
- Step 6 — **If `iDebugState` is `2` (window/debugger mode):** check whether `DEBUG_API_ENABLED` is TRUE.
  - If TRUE, emit the string to the Windows debug viewer via `win_api_debug.WinDebug`.
  - If FALSE (API unavailable), switch to file logging by calling `SetDebug(1, nvl(vcDebugFile,'d2kwutil.log'), iDebugLevel, bDebugTimeStamp)`, log a transition message, then recursively call `DebugLog` with the original arguments to write to the file. Set `bDebugType2Required := TRUE` to remember that window logging is still desired.
- Step 7 — **If `iDebugState` is `1` (file mode):** check whether `bDebugType2Required` is TRUE and `DEBUG_API_ENABLED` is now TRUE (i.e. the debugger window has become available again).
  - If so, restore window logging by calling `SetDebug(2, vcDebugFile, iDebugLevel, bDebugTimeStamp)`, log a restoration message, reset `bDebugType2Required` to FALSE, and recursively call `DebugLog` with the original arguments.
  - Otherwise, open the log file in append mode, write the formatted string, and close the file.
- Step 8 — On any exception, silently set `iDebugState` to `0` (disable logging) to prevent the diagnostic subsystem itself from causing further errors in the application.

---

**Decision Points**

DP-001

Condition:
`iDebugState` equals `0` (debugging is disabled).

TRUE:
Exit immediately without writing any output.

FALSE:
Proceed to check the pause state.

DP-002

Condition:
`bDebugPaused` is TRUE (logging is temporarily paused).

TRUE:
Exit immediately without writing any output.

FALSE:
Proceed to check the debug level filter.

DP-003

Condition:
The supplied `DebugLevel` is greater than the configured `iDebugLevel` ceiling.

TRUE:
Exit immediately — the message is below the required verbosity threshold.

FALSE:
Proceed to format and emit the message.

DP-004

Condition:
`bDebugTimeStamp` is TRUE.

TRUE:
Prepend the current time formatted as `HH24:MI:SS> ` to the debug string.

FALSE:
No timestamp is prepended; the string starts directly with the level indicator.

DP-005

Condition:
`iDebugState` equals `2` (window/debugger output mode).

TRUE:
Attempt to emit the string via the Windows debug viewer.

FALSE:
Emit the string to the log file (file output mode, `iDebugState = 1`).

DP-006

Condition:
`DEBUG_API_ENABLED` is TRUE when `iDebugState` is `2`.

TRUE:
Write to the Windows debug viewer via `win_api_debug.WinDebug`.

FALSE:
The debug API is unavailable; switch to file logging, log the fallback event, recursively emit the original message to the file, and set `bDebugType2Required := TRUE`.

DP-007

Condition:
`bDebugType2Required` is TRUE and `DEBUG_API_ENABLED` is now TRUE when in file output mode (`iDebugState = 1`).

TRUE:
Restore window-based logging by calling `SetDebug(2,...)`, log the restoration event, reset `bDebugType2Required` to FALSE, and recursively emit the original message to the debugger window.

FALSE:
Write the formatted string to the log file in append mode and close the file.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 — Log entries are only emitted when all three gate conditions pass: logging must be enabled (`iDebugState ≠ 0`), not paused (`bDebugPaused = FALSE`), and the message level must not exceed the configured verbosity ceiling (`DebugLevel ≤ iDebugLevel`).
- SBR-002 — Each log entry is formatted with a zero-padded two-digit level indicator, an optional timestamp, and the calling routine name padded to 30 characters, followed by the log string truncated to keep the total within 2,000 characters.
- SBR-003 — When the Windows debug API is unavailable during window-mode logging, the routine automatically falls back to file logging and records the transition event so the log history is uninterrupted.
- SBR-004 — Once the Windows debug API becomes available again during file-mode logging, the routine automatically restores window-mode logging and records the restoration event.
- SBR-005 — Any exception raised within `DebugLog` itself is silently suppressed by setting `iDebugState := 0`, ensuring that the diagnostic subsystem never causes application-visible errors.

---

**Implementation Logic**

```plsql
   
PROCEDURE DebugLog (DebugLevel  IN PLS_INTEGER, 
                    LoggingCall IN VARCHAR2, 
                    LogString   IN VARCHAR2) is
 vcDateStamp   VARCHAR2(10);
 vcDebugString VARCHAR2(2000);
 hFile         TEXT_IO.FILE_TYPE;
begin
  if iDebugState = 0 then 
  	NULL;
  elsif bDebugPaused then 
  	NULL;
  elsif DebugLevel > iDebugLevel then 
  	NULL;
  else
  	-- Sort out the Datestamp	
  	if bDebugTimeStamp then 
  		vcDateStamp := to_char(SYSDATE,'HH24:MI:SS')||'> ';
  	end if;
  
  	-- Construct the final String
  	vcDebugString := '<'||lpad(to_char(DebugLevel),2,0)||'> '||vcDateStamp||rpad(LoggingCall||':',30);
    vcDebugString := vcDebugString||substr(LogString,1,(2000-length(vcDebugString)));
  
  	if iDebugState = 2 then
  		if DEBUG_API_ENABLED then 
  	   		win_api_debug.WinDebug(vcDebugString);
  		else
  			-- Can't use API calls if the API functions aren't there
	  		-- So Switch to File Logging to d2kwut$.log
	  		SetDebug(1,nvl(vcDebugFile,'d2kwutil.log'),iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Unable to Log to Debugger Switching to File');
			DebugLog(DebugLevel,LoggingCall,LogString);	  		
	  		bDebugType2Required := TRUE;
	  	end if;
  	else
     	if bDebugType2Required and DEBUG_API_ENABLED then
	     	-- API now Available - Reinstate Debugging to Debugger
	  		SetDebug(2,vcDebugFile,iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Restoring Logging to Debugger');
	  		bDebugType2Required := FALSE;
	  		DebugLog(Debuglevel,LoggingCall,LogString);
	
	  	else
		 	hFile := TEXT_IO.FOPEN(vcDebugFile,'A');
		 	TEXT_IO.PUT_LINE(hFile,vcDebugString);
		 	TEXT_IO.FCLOSE(hFile);
		end if;
  	end if;
  end if;
 exception
  	-- Don't let the debugging cause Problems of it's own
  	when others then 
  		iDebugState := 0;
 end DebugLog;
```

#### SP-038 — REGISTER_FUNCTION_CALL

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.FILE_INFO]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly — screen follows parent invocation site.)

---

**Purpose**

Ensures that a named DLL function is registered with Oracle FFI before it is called, loading the DLL if it is not already present and re-registering the function if the DLL has been reloaded since the last registration. This guards against stale function handles after DLL reloads and records any registration or load failures through the Win API error mechanism.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| FunctionID | PLS_INTEGER | IN |
| FunctionName | VARCHAR2 | IN |
| FunctionReturn | VARCHAR2 | IN |
| FunctionArgs | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-033](#SP-033--ADD_ERROR)) — matched by member name
- ADD_EXTERNAL_ERRORS ([SP-034](#SP-034--ADD_EXTERNAL_ERRORS)) — matched by member name
- D2KWUTIL.ATTEMPT_DLL_LOAD ([SP-004](#SP-004--D2KWUTIL.ATTEMPT_DLL_LOAD)) — D2KWUTIL.pck (or .pld)
- D2KWUTIL.TRANSLATETYPE ([SP-009](#SP-009--D2KWUTIL.TRANSLATETYPE)) — D2KWUTIL.pck (or .pld)
- DEBUGLOG ([SP-037](#SP-037--DEBUGLOG)) — matched by member name
- WEBUTIL.LENGTH ([SP-028](#SP-028--WEBUTIL.LENGTH)) — WEBUTIL.pck (or .pld)
- WEBUTIL.REGISTER_FUNCTION ([SP-030](#SP-030--WEBUTIL.REGISTER_FUNCTION)) — WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 — Attempt to locate the DLL in the Oracle FFI library cache via `ORA_FFI.find_library`; if the DLL is found, proceed directly to the registration-currency check (Step 4).
- Step 2 — If `find_library` raises an FFI error (DLL not in cache), attempt to load the DLL from `DLL_Path` by calling `Attempt_DLL_Load`.
- Step 3 — If `Attempt_DLL_Load` also raises an FFI error, mark `API_ENABLED := FALSE`, record an error entry (`add_error`) naming the missing DLL, and raise `NO_DATA_FOUND` to abort the caller.
- Step 4 — Check whether the function has been registered before and whether the DLL load count at last registration still matches the current `DLL_LOAD_COUNT`. If either condition fails, proceed with (re-)registration (Steps 5–9); otherwise skip to the end.
- Step 5 — Register the function with the DLL handle via `ora_ffi.register_function` using the C calling convention (`ORA_FFI.C_STD`), storing the handle in `FunctionHandle(FunctionId)`.
- Step 6 — For functions other than `d2kwutil_DebugString`, log a debug entry via `Win_API_Debug.DebugLog` indicating whether this is an initial registration or a re-registration, along with the current DLL load count.
- Step 7 — Parse the comma-separated `FunctionArgs` string: for each argument token (stopping if the list is null, empty, or `VOID`), translate the type token using `TranslateType` and register each parameter via `ora_ffi.register_parameter`.
- Step 8 — If `FunctionReturn` is non-null and not `VOID`, translate the return type using `TranslateType` and register it via `ora_ffi.register_return`.
- Step 9 — Record the current `DLL_LOAD_COUNT` in `FunctionLoad(FunctionId)` to mark this registration as current, preventing unnecessary re-registration on subsequent calls.
- Step 10 — On any FFI error during the registration phase, record an error entry combining the generic unexpected-error prefix with external error details, then raise `NO_DATA_FOUND`.

---

**Decision Points**

DP-001

Condition:
`ORA_FFI.find_library` succeeds (the DLL is already in the FFI cache).

TRUE:
Proceed directly to the registration-currency check without attempting to reload the DLL.

FALSE:
Attempt to load the DLL via `Attempt_DLL_Load`.

DP-002

Condition:
`Attempt_DLL_Load` succeeds in loading the DLL.

TRUE:
Proceed to the registration-currency check.

FALSE:
Disable the API, record an error, and raise `NO_DATA_FOUND` to abort.

DP-003

Condition:
The function has been registered before (`FunctionLoad.exists(FunctionId)`) AND the load count at last registration equals the current `DLL_LOAD_COUNT`.

TRUE:
The cached registration is still valid; skip re-registration entirely.

FALSE:
(Re-)register the function, its parameters, and its return type.

DP-004

Condition:
The function being registered is NOT `d2kwutil_DebugString`.

TRUE:
Emit a debug log entry recording the registration action (initial or re-registration) and DLL load count.

FALSE:
Skip debug logging for this function to avoid recursive logging.

DP-005

Condition:
The `FunctionArgs` token list is non-null, non-empty, and the current token is not `VOID`.

TRUE:
Translate the token to an FFI type constant and register it as a parameter; advance to the next token.

FALSE:
Stop the parameter registration loop.

DP-006

Condition:
`FunctionReturn` is non-null and its upper-cased value is not `VOID`.

TRUE:
Translate the return type token and register it as the function's return type.

FALSE:
No return type is registered (procedure-style call or explicit VOID).

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 — A function is only re-registered with Oracle FFI if it has never been registered or if the DLL has been reloaded since the last registration; unnecessary repeated registrations are suppressed using the `FunctionLoad` cache array.
- SBR-002 — If the DLL cannot be located or loaded, the Win API is disabled (`API_ENABLED := FALSE`) and the caller receives `NO_DATA_FOUND`, preventing any subsequent FFI call attempt.
- SBR-003 — Debug logging is suppressed for the `d2kwutil_DebugString` function specifically to avoid a recursive logging scenario.
- SBR-004 — Parameter and return type strings are translated to Oracle FFI constants via `TranslateType` before registration; raw string type names are never passed directly to FFI.
- SBR-005 — A `VOID` return type or a `VOID` argument list token signals that no return type or no parameters should be registered; this is enforced by the loop termination and the conditional return-type registration.

---

**Implementation Logic**

```plsql

PROCEDURE Register_Function_Call ( FunctionID     in PLS_INTEGER, 
                                   FunctionName   in VARCHAR2,
                                   FunctionReturn in VARCHAR2, 
                                   FunctionArgs   in VARCHAR2) is
  vcArgs  VARCHAR2(200);
  vcFrag  VARCHAR2(10);
  iOffset PLS_INTEGER;   
begin 
   -- See if the DLL has been loaded at all.
   -- if this call to FIND_LIBRARY fails, we'll fall through to the Exception.
   begin
    DLL_HANDLE := ORA_FFI.find_library(DLL_NAME);
  exception
    when ora_ffi.ffi_error then 
      -- Attempt to load the DLL again in a subblock. If this fails
      -- then the API must be disabled and NOT_DATA_FOUND raised
      begin 
          DLL_HANDLE := Attempt_DLL_Load(DLL_Path, DLL_NAME);
      exception
          when ora_ffi.ffi_error then 
            API_ENABLED := FALSE;
              add_error('D2KWUTIL',DLL_NAME||' not found.');
            RAISE NO_DATA_FOUND;
      end;
  end;

  -- now compare the Cached value for this function's loadcount with 
  -- that for the DLL this tells us that the function has either not 
  -- been registered yet, or that the DLL has been reloaded in between 
  -- times.  This would not be healthy so we have to re-register in that case.
  if (not FunctionLoad.exists(FunctionId)) or (FunctionLoad(FunctionId)<> DLL_LOAD_COUNT) then
    -- We need to go through the registration process.      
    -- Register the function with the DLL
    FunctionHandle(FunctionId) := ora_ffi.register_function(Win_API.DLL_HANDLE,FunctionName,ORA_FFI.C_STD);
    if FunctionName <> 'd2kwutil_DebugString' then 
    	if not FunctionLoad.exists(FunctionId) then 
    		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Initial Reg');
    	else
       		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Re-Registration Count = '||to_char(FunctionLoad(FunctionId)));
       	end if;
    end if;
    
    -- Loop through and register the parameters
    vcArgs := FunctionArgs||',';
    while vcArgs is not null and vcArgs <> ',' and vcArgs <> 'VOID,' LOOP
      iOffset := instr(vcArgs,',');
      vcFrag := substr(vcArgs,1,iOffset-1);
      ora_ffi.register_parameter(FunctionHandle(FunctionId),TranslateType(vcFrag));
      if iOffset = length(vcArgs) then
        vcArgs := NULL;
      else
        vcArgs := substr(vcArgs,iOffset+1);
      end if;
    end LOOP;
    
    -- Register the return type IF this is a function
    if upper(FunctionReturn) <> 'VOID' and FunctionReturn is not NULL then 
      ora_ffi.register_return(FunctionHandle(FunctionId),TranslateType(FunctionReturn));
    end if;
    
    -- Now add this Function's Loadcount to the array to prevent un-nessary re-registration
    FunctionLoad(FunctionId) := DLL_LOAD_COUNT;
  end if;
exception
   when ora_ffi.ffi_error then
    Win_API.Add_error(FunctionName, Win_API.UError||WIN_API.Add_External_errors); 
    raise NO_DATA_FOUND;
end Register_Function_Call;
```

#### SP-039 — SETDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly — screen follows parent invocation site.)

---

**Purpose**

Configures the WIN_API debug subsystem by setting the output mode (file, window debugger, or off), the target log file name, the verbosity level, and the timestamp option, then logs the resulting state transition via `DEBUGLOG`.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| DebugType | PLS_INTEGER | IN |
| DebugFile | VARCHAR2 | IN |
| DebugLevel | PLS_INTEGER | IN |
| TimeStamp | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-037](#SP-037--DEBUGLOG)) — matched by member name

---

**Step-by-Step Business Logic**

- Step 1 — Store the supplied `TimeStamp`, `DebugFile`, and `DebugLevel` values into the corresponding module-level variables (`bDebugTimeStamp`, `vcDebugFile`, `iDebugLevel`).
- Step 2 — Evaluate the `DebugType` parameter to set the active logging mode:
  - If `DebugType = 1`: set `iDebugState := 1` (file logging) and call `DebugLog(0, 'SetDebug', 'Logging to File ' || DebugFile)` to record the activation.
  - If `DebugType = 2`: set `iDebugState := 2` (window/debugger logging) and call `DebugLog(0, 'SetDebug', 'Logging Started')` to record the activation.
  - Otherwise (any other value): call `DebugLog(0, 'SetDebug', 'Logging Stopped')` first to record the shutdown, then set `iDebugState := 0` (logging disabled).

---

**Decision Points**

DP-001

Condition:
`DebugType` equals `1`.

TRUE:
Enable file-based logging (`iDebugState := 1`) and log `'Logging to File <DebugFile>'`.

FALSE:
Proceed to check whether `DebugType` equals `2`.

DP-002

Condition:
`DebugType` equals `2`.

TRUE:
Enable window/debugger-based logging (`iDebugState := 2`) and log `'Logging Started'`.

FALSE:
Log `'Logging Stopped'` and disable all logging (`iDebugState := 0`).

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 — Only two active logging modes are supported: `1` (file) and `2` (window/debugger); any other `DebugType` value disables logging entirely.
- SBR-002 — Configuration parameters (file name, verbosity level, timestamp flag) are always applied unconditionally before the logging mode is activated, ensuring that the subsequent `DebugLog` call inside `SetDebug` itself already uses the newly configured settings.
- SBR-003 — Each mode transition is recorded by a level-0 `DebugLog` call so that the start and stop of logging sessions are always traceable in the output regardless of the configured verbosity level.

---

**Implementation Logic**

```plsql

PROCEDURE SetDebug( DebugType   IN PLS_INTEGER, 
                    DebugFile   IN VARCHAR2 DEFAULT NULL, 
                    DebugLevel  IN PLS_INTEGER DEFAULT 98,                        
                    TimeStamp   IN BOOLEAN DEFAULT FALSE) is
begin 
    bDebugTimeStamp := TimeStamp;
    vcDebugFile     := DebugFile;
    iDebugLevel     := DebugLevel;
	if DebugType = 1 then 
		iDebugState := 1;
		DebugLog(0,'SetDebug','Logging to File '||DebugFile);
	elsif DebugType = 2 then
		iDebugState := 2;
		DebugLog(0,'SetDebug','Logging Started');
	else 
        DebugLog(0,'SetDebug','Logging Stopped');
        iDebugState := 0;
	end if;
end SetDebug;
```

#### SP-040 — SF_COPYRIGHT_DECLARATION

**Invoked From:**

- vt_amc_enq_fmb.xml [Trigger: KEY-CLRFRM]
- vt_amc_enq_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

N/A

---

**Purpose**

Constructs and returns the current financial-year copyright string for Maruti Suzuki India Limited. The financial year is taken to run from April to March, so months January through March are attributed to the preceding calendar year rather than the current one.

---

**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 — Capture the current system date (`SYSDATE`) into a local date variable.
- Step 2 — Inspect the month of the captured date. If the month is January, February, or March, the financial year is considered to belong to the previous calendar year, so construct the copyright string using `(current year − 1)`.
- Step 3 — For all other months (April through December), the current calendar year is the financial year; construct the copyright string using the current four-digit year.
- Step 4 — Return the completed copyright string (e.g. `© 2010 Maruti Suzuki India Limited`).

---

**Decision Points**

DP-001

Condition:
The current month is January, February, or March (i.e. the form is being used in the first quarter of the calendar year, which falls in the previous financial year).

TRUE:
The copyright year is set to `(current calendar year − 1)`, reflecting the financial year that started in the previous April.

FALSE:
The copyright year is set to the current calendar year, reflecting the financial year that started in the most recent April.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 — The financial year is defined as April-to-March; months January, February, and March belong to the financial year that began in the previous calendar year.
- SBR-002 — The copyright notice must always identify Maruti Suzuki India Limited as the rights holder and reflect the correct financial year at the time the form is opened or cleared.

---

**Implementation Logic**

```plsql
CREATE OR REPLACE
function sf_copyright_declaration return varchar is
a varchar2(50);
dt date;
begin
--Modified by Prerna on 16-May-11  to display current Financial Year Copyright
dt := sysdate;

    if( to_char(dt,'MON') in ('JAN','FEB','MAR')) then
        a := '© '||to_char(to_number(to_char(dt,'RRRR')) - 1)||' Maruti Suzuki India Limited ';
    else
        a := '© '||to_char(dt,'RRRR')||' Maruti Suzuki India Limited ';
    end if;
return(a);
end;

```

#### SP-041 — SP_GET_VEH_DETAILS

**Invoked From:**

- vt_amc_enq_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

Vehicle Details (N/A / CN_MAIN)

---

**Purpose**

Retrieves the full set of vehicle and customer details required to populate the AMC enquiry screen, given either a VIN or a registration number as the primary lookup key. The procedure resolves the vehicle's model (svar), variant, and exterior colour descriptions, then derives the associated customer's personal and contact details — selecting the correct communication address (office or permanent) based on the customer's communication indicator — and additionally returns outstanding amount and VIP status when the customer is registered at the current dealer location.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| pi_principal | NUMBER | IN |
| pi_parent | VARCHAR2 | IN |
| pi_dealer | NUMBER | IN |
| pi_locn | VARCHAR2 | IN |
| pi_reg_num | VARCHAR2 | IN OUT |
| po_vin | VARCHAR2 | IN OUT |
| po_cust_cd | VARCHAR2 | IN OUT |

**Output Parameters**

| Output | Source | Datatype |
|--------|--------|---------|
| pi_reg_num | VARCHAR2 | IN OUT |
| po_vin | VARCHAR2 | IN OUT |
| po_svar_cd | VARCHAR2 | OUT |
| po_svar_desc | VARCHAR2 | OUT |
| po_variant_cd | VARCHAR2 | OUT |
| po_variant_desc | VARCHAR2 | OUT |
| po_ecolor_cd | VARCHAR2 | OUT |
| po_ecolor_desc | VARCHAR2 | OUT |
| po_cust_cd | VARCHAR2 | IN OUT |
| po_cust_name | VARCHAR2 | OUT |
| po_addr1 | VARCHAR2 | OUT |
| po_addr2 | VARCHAR2 | OUT |
| po_addr3 | VARCHAR2 | OUT |
| po_work_phone | VARCHAR2 | OUT |
| po_res_phone | VARCHAR2 | OUT |
| po_mobile_phone | VARCHAR2 | OUT |
| po_city_cd | VARCHAR2 | OUT |
| po_city_desc | VARCHAR2 | OUT |
| po_email | VARCHAR2 | OUT |
| po_vip_yn | VARCHAR2 | OUT |
| po_os_amt | NUMBER | OUT |
| p_gm_vin_rec_out | gm_vin%ROWTYPE | OUT |
| po_errmsg | VARCHAR2 | OUT |
| po_error_cd | NUMBER | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 — Determine the primary vehicle lookup key. If `po_vin` is supplied, query `gm_vin` by VIN to retrieve `svar_cd`, `variant_cd`, `ecolor_cd`, and (if `pi_reg_num` is null) the registration number. If `po_vin` is not supplied, query `gm_vin` by registration number to resolve the VIN and the same code fields. Failures are captured in error variables and `po_error_cd` is set to 1.
- Step 2 — If no upstream error has already been reported in `po_errmsg`, retrieve the complete `gm_vin` row into `p_gm_vin_rec_out` using whichever of VIN or registration number is now known.
- Step 3 — Look up the vehicle model (svar) description from `vm_svar` using `po_svar_cd` and `pi_principal`; capture failures with an error message.
- Step 4 — Look up the variant description from `gm_var` using `po_variant_cd` and `pi_principal`; capture failures with an error message.
- Step 5 — Look up the exterior colour description from `gm_eclr` using `po_ecolor_cd` and `pi_principal`; capture failures with an error message.
- Step 6 — If `po_cust_cd` was not supplied by the caller, derive it from `gm_vin` by VIN (if known) or by registration number; capture lookup or null-value failures with error messages.
- Step 7 — Count the number of `gd_cin` records that match the combination of dealer parent group, dealer code, location, and customer code to determine whether the customer is registered at this dealer location.
- Step 8 — If `po_cust_cd` is not null AND the `gd_cin` count is greater than zero (customer is known at this dealer), retrieve the full customer profile from `gm_cin`: name, address lines (office or permanent according to `COMMUNICATION_IND`), city code, work/residential/mobile phone numbers, and email address.
- Step 9 — If the city code is populated, look up the city description from `gm_city` using the city code and principal.
- Step 10 — Retrieve the customer's VIP flag and outstanding DMS amount from `gd_cin` for the current dealer, location, and parent group.
- Step 11 — If `po_cust_cd` is not null but the customer is NOT registered at this dealer location (`lv_cnt` is 0), retrieve only the customer's name from `gm_cin`, leaving address and contact fields empty.
- Step 12 — Concatenate all accumulated partial error messages into `po_errmsg` and return it along with `po_error_cd` to the caller.

---

**Decision Points**

DP-001

Condition:
`po_vin` is NOT NULL at the time of the initial lookup.

TRUE:
Query `gm_vin` by VIN to obtain `svar_cd`, `variant_cd`, `ecolor_cd`, and (conditionally) `reg_num`.

FALSE:
Query `gm_vin` by `pi_reg_num` (registration number) to resolve the VIN and the same code fields.

DP-002

Condition:
`po_errmsg` IS NULL after the initial VIN/registration lookup (no error has been flagged yet).

TRUE:
Continue processing: retrieve the full `gm_vin` row and proceed to look up vehicle descriptions and customer details.

FALSE:
Skip all subsequent lookups; jump directly to assembling the final error message.

DP-003

Condition:
`po_vin` is NOT NULL when retrieving the full `gm_vin` row.

TRUE:
Select the full row from `gm_vin` using the VIN as the key.

FALSE:
Select the full row from `gm_vin` using the registration number as the key.

DP-004

Condition:
`po_cust_cd` IS NULL after vehicle code lookups (customer code was not provided by the caller).

TRUE:
Derive `po_cust_cd` from `gm_vin` — by VIN if available, otherwise by registration number.

FALSE:
Use the caller-supplied customer code as-is; skip the derivation query.

DP-005

Condition:
`po_vin` is NOT NULL when deriving the customer code from `gm_vin`.

TRUE:
Select `party_cd` from `gm_vin` where `vin = po_vin`.

FALSE:
Select `party_cd` from `gm_vin` where `reg_num = pi_reg_num`.

DP-006

Condition:
`po_cust_cd` IS NOT NULL AND the count from `gd_cin` for the current dealer/location/parent combination is greater than zero (customer is registered at this dealer).

TRUE:
Retrieve the full customer profile (name, address, contact details) from `gm_cin`, look up the city description, and fetch the VIP flag and outstanding amount from `gd_cin`.

FALSE:
Retrieve only the customer name from `gm_cin`; all address, contact, VIP, and outstanding amount fields are left unpopulated.

DP-007

Condition:
`COMMUNICATION_IND` on the `gm_cin` row equals `'O'` (office communication preference).

TRUE:
Return the office address fields (`OFF_ADDRESS1/2/3`, `OFF_CITY_CD`) as the customer's contact address.

FALSE:
Return the permanent address fields (`PERMANENT_ADDRESS1/2/3`, `CITY_CD`) as the customer's contact address.

DP-008

Condition:
`po_city_cd` is NOT NULL after retrieving the customer record.

TRUE:
Look up the city description from `gm_city` using the city code and principal.

FALSE:
Skip the city description lookup; `po_city_desc` remains null.

---

**Database Interactions**

- DB-001 — Read gm_vin — look up vehicle key fields (`svar_cd`, `variant_cd`, `ecolor_cd`, registration number, and/or VIN) by either VIN or registration number, and subsequently retrieve the complete vehicle row; also used to derive the customer party code when not supplied by the caller.
- DB-002 — Read vm_svar — retrieve the human-readable vehicle model (svar) description corresponding to `po_svar_cd` for the current principal.
- DB-003 — Read gm_var — retrieve the variant description corresponding to `po_variant_cd` for the current principal.
- DB-004 — Read gm_eclr — retrieve the exterior colour description corresponding to `po_ecolor_cd` for the current principal.
- DB-005 — Read gd_cin — count the number of dealer-level customer records matching the current dealer, location, parent group, and customer code, to determine whether the customer is registered at this dealer; subsequently read the VIP flag and outstanding DMS amount for the same combination.
- DB-006 — Read gm_cin — retrieve the customer's full name, communication-indicator-driven address lines, city code, phone numbers, and email address; or, when the customer is not registered at the dealer, retrieve only the customer name.
- DB-007 — Read gm_city — retrieve the city description for the customer's resolved city code, scoped to the current principal.

---

**Business Rules**

- SBR-001 — Either a VIN (`po_vin`) or a registration number (`pi_reg_num`) must be resolvable to a record in `gm_vin`; if neither resolves successfully, the error code is set to 1 and a descriptive message is returned.
- SBR-002 — Vehicle model, variant, and exterior colour lookups are all scoped to `pi_principal` (the principal map code); codes not defined for the current principal are treated as errors.
- SBR-003 — When the caller does not supply a customer code, it is derived from the `party_cd` column of `gm_vin`; if the resulting value is still null, a "Customer Code not tagged in Reg Number" error is recorded.
- SBR-004 — Full customer contact details (address, phone, email, city, VIP status, outstanding amount) are returned only when the customer has a `gd_cin` record for the current dealer, location, and parent group; otherwise only the customer name is returned.
- SBR-005 — The address returned to the caller is determined by the customer's `COMMUNICATION_IND` flag: a value of `'O'` selects office address fields; any other value selects permanent address fields.
- SBR-006 — The customer name is resolved as `NVL(full_name, CUST_NAME)`, falling back to the legacy `CUST_NAME` column when `full_name` is null.
- SBR-007 — All partial error messages are accumulated throughout the procedure and concatenated into a single `po_errmsg` string at the end, allowing the caller to report multiple data issues in one pass.

---

**Implementation Logic**

```plsql
CREATE OR REPLACE
Procedure Sp_Get_Veh_Details
/*
$Log: SP_GET_VEH_DETAILS.sql,v $
Revision 1.5  2005/06/25 07:33:54  muralidhard
Decode split into multiple select statements for performance bottleneck

Revision 1.4  2004/12/31 05:41:34  muralidhard
Address Display Changed as per the Communication Indicator

*/
(
 pi_principal IN NUMBER    ,
 pi_parent    IN VARCHAR2  ,
 pi_dealer     IN  NUMBER,
 pi_locn   IN VARCHAR2,
 pi_reg_num   IN  OUT VARCHAR2,
 po_vin   IN OUT VARCHAR2,
 po_svar_cd  OUT VARCHAR2,
 po_svar_desc OUT VARCHAR2,
 po_variant_cd   OUT VARCHAR2,
 po_variant_desc OUT VARCHAR2,
 po_ecolor_cd OUT VARCHAR2,
 po_ecolor_desc OUT VARCHAR2,
 po_cust_cd IN OUT VARCHAR2,
 po_cust_name OUT VARCHAR2,
 po_addr1 OUT VARCHAR2,
 po_addr2 OUT VARCHAR2,
 po_addr3 OUT VARCHAR2, po_work_phone OUT VARCHAR2, po_res_phone OUT VARCHAR2, po_mobile_phone OUT VARCHAR2,
 po_city_cd OUT VARCHAR2,
 po_city_desc  OUT VARCHAR2, po_email  OUT  VARCHAR2, po_vip_yn OUT VARCHAR2, po_os_amt OUT NUMBER,
 p_gm_vin_rec_out OUT gm_vin%ROWTYPE,
 po_errmsg  OUT VARCHAR2,
 po_error_cd  OUT NUMBER
) IS

lv_cnt NUMBER := 0;
lv_err1 VARCHAR2(60);
lv_err2 VARCHAR2(60);
lv_err3 VARCHAR2(60);
lv_err4 VARCHAR2(60);
lv_err5 VARCHAR2(60);
lv_err6 VARCHAR2(60);
lv_err7 VARCHAR2(60);
lv_err8 VARCHAR2(60);
lv_err9 VARCHAR2(60);
lv_err10 VARCHAR2(60);
lv_err11 VARCHAR2(60);
BEGIN

IF po_vin IS NOT NULL THEN
              BEGIN
			  SELECT svar_cd, variant_cd, ecolor_cd,DECODE(pi_reg_num,NULL,reg_num,pi_reg_num)
			  INTO    po_svar_cd, po_variant_cd, po_ecolor_cd,pi_reg_num
			        FROM gm_vin
			  WHERE
			           vin = po_vin;
					   EXCEPTION WHEN OTHERS THEN
					   lv_err1 := po_vin || ' VIN not found in GM_VIN & ';
					   po_error_cd := 1;
			 END;
ELSE
	 	       BEGIN
			   SELECT
			   DECODE(po_vin,NULL,vin,po_vin),
			   svar_cd,
			   variant_cd,
			   ecolor_cd
			   INTO
			   po_vin, po_svar_cd, po_variant_cd, po_ecolor_cd
			   FROM gm_vin
				WHERE
						 reg_num = pi_reg_num;
						  EXCEPTION
						    WHEN OTHERS THEN
								 		   lv_err2 := pi_reg_num || ' Reg Number not found in GM_VIN & ';
										   po_error_cd := 1;
		        END;
END IF;
IF po_errmsg IS NULL THEN

    IF po_vin IS NOT NULL THEN
    BEGIN
    SELECT *
    INTO    p_gm_vin_rec_out
    FROM    gm_vin WHERE
            vin = po_vin;
  	   EXCEPTION WHEN OTHERS THEN
 		   lv_err3 := pi_reg_num || ' VIN/Registration not found & ';
		   po_error_cd := 1;

     END;
	ELSE
	BEGIN
    SELECT *
    INTO    p_gm_vin_rec_out
    FROM    gm_vin WHERE
            reg_num = pi_reg_num;
  	   EXCEPTION WHEN OTHERS THEN
 		   lv_err3 := pi_reg_num || ' VIN/Registration not found & ';
		   po_error_cd := 1;

     END;
	 END IF;

		 BEGIN
		 SELECT svar_desc
		     INTO po_svar_desc
			  FROM vm_svar
			   WHERE svar_cd = po_svar_cd AND
			         PRINCIPAL_MAP_CD = pi_principal;
		   EXCEPTION WHEN OTHERS THEN
 		   lv_err4 := po_svar_cd || ' Vehicle model not defined & ';
		   po_error_cd := 1;
		END;

     BEGIN			SELECT variant_desc
				 INTO po_variant_desc
				  FROM gm_var
				   WHERE variant_cd = po_variant_cd  AND
				   PRINCIPAL_MAP_CD = pi_principal;
		   EXCEPTION WHEN OTHERS THEN
 		   lv_err5 := po_variant_cd || ' Variant not defined & ';
		   po_error_cd := 1;

      END;

      BEGIN				    SELECT ecolor_desc
					 INTO po_ecolor_desc
					  FROM gm_eclr
					   WHERE ecolor_cd = po_ecolor_cd AND
					   PRINCIPAL_MAP_CD = pi_principal;
		   EXCEPTION WHEN OTHERS THEN
 		   lv_err6 := po_ecolor_cd || ' Color not defined & ';
		   po_error_cd := 1;

      END;

IF po_cust_cd IS NULL THEN

        IF po_vin IS NOT NULL THEN
        BEGIN
		SELECT party_cd INTO po_cust_cd FROM gm_vin
		WHERE
		  vin = po_vin;
				   EXCEPTION WHEN OTHERS THEN
		 		   lv_err7 := pi_reg_num || ' VIN/Reg No not found & ';
				   po_error_cd := 1;
		           IF  po_cust_cd IS NULL THEN
			                   lv_err8 := pi_reg_num || ' Customer Code not tagged in Reg Number & ';
				               po_error_cd := 1;
		           END IF;

		END;
        ELSE
		BEGIN
		SELECT party_cd INTO po_cust_cd FROM gm_vin
		WHERE
		  reg_num = pi_reg_num;
				   EXCEPTION WHEN OTHERS THEN
		 		   lv_err7 := pi_reg_num || ' VIN/Reg No not found & ';
				   po_error_cd := 1;
		           IF  po_cust_cd IS NULL THEN
			                   lv_err8 := pi_reg_num || ' Customer Code not tagged in Reg Number & ';
				               po_error_cd := 1;
		           END IF;

		END;
		END IF;
END IF;

	  BEGIN
	  SELECT COUNT(*) INTO lv_cnt FROM gd_cin
	  WHERE parent_group  = pi_parent  AND
	        dealer_map_cd = pi_dealer AND
			loc_cd        = pi_locn   AND
			cust_cd       = po_cust_cd;
	  END;

IF po_cust_cd IS NOT NULL AND lv_cnt > 0 THEN
BEGIN

/* Murali 31.12.04
 select full_name,
        permanent_address1,
		permanent_address2,
		permanent_address3,
		city_cd,
        work_phone,
		res_phone,
		mobile_phone,
		email
 into   po_cust_name, po_addr1, po_addr2, po_addr3, po_city_cd,
        po_work_phone, po_res_phone, po_mobile_phone, po_email
 from gm_cin
 where cust_cd = po_cust_cd; */

/* Murali 31.12.04   Showing the address based on Communication*/
 SELECT nvl(full_name,CUST_NAME),
 	    DECODE(COMMUNICATION_IND ,'O',OFF_ADDRESS1 , PERMANENT_ADDRESS1 ),
		DECODE(COMMUNICATION_IND ,'O',OFF_ADDRESS2 , PERMANENT_ADDRESS2 ),
		DECODE(COMMUNICATION_IND ,'O',OFF_ADDRESS3 , PERMANENT_ADDRESS3 ) ,
		DECODE(COMMUNICATION_IND ,'O',OFF_CITY_CD , CITY_CD),
        work_phone,
		res_phone,
		mobile_phone,
		email
 INTO   po_cust_name, po_addr1, po_addr2, po_addr3, po_city_cd,
        po_work_phone, po_res_phone, po_mobile_phone, po_email
 FROM gm_cin
 WHERE cust_cd = po_cust_cd  AND
 PRINCIPAL_MAP_CD = pi_principal;
DBMS_OUTPUT.PUT_LINE('ADD' ||po_addr1);
 EXCEPTION
  WHEN OTHERS THEN
    lv_err9 := po_cust_cd  || 'Customer not found & ';
   po_error_cd := 1;
  END;

DBMS_OUTPUT.PUT_LINE('ADD1' ||po_addr1);
IF po_city_cd IS NOT NULL THEN
BEGIN
SELECT city_desc
 INTO po_city_desc
 FROM gm_city
 WHERE city_cd     = po_city_cd  AND
  PRINCIPAL_MAP_CD = pi_principal;
 EXCEPTION
  WHEN OTHERS THEN
    lv_err10 := po_city_cd || 'City not Defined & ';
    po_error_cd := 1;
 END;
END IF;

BEGIN
SELECT NVL(vip_yn,'N'), outstanding_dms
INTO po_vip_yn, po_os_amt
FROM gd_cin
WHERE dealer_map_cd = pi_dealer AND  cust_cd = po_cust_cd
AND  loc_cd = pi_locn AND parent_group = pi_parent;
END;

/* Hide all the info */
ELSE
dbms_output.put_line('in else');

BEGIN
SELECT nvl(full_name,CUST_NAME)
 INTO po_cust_name
 FROM gm_cin
 WHERE cust_cd = po_cust_cd AND PRINCIPAL_MAP_CD = pi_principal;
 EXCEPTION
  WHEN OTHERS THEN
    lv_err11 := po_cust_cd || 'Customer not found & ';
    po_error_cd := 1;
 END;
END IF;
END IF;

po_errmsg := lv_err1||lv_err2||lv_err3||lv_err4||lv_err5||lv_err6||lv_err7||lv_err8||lv_err9||lv_err10||lv_err11;
DBMS_OUTPUT.PUT_LINE('error'||po_error_cd||po_errmsg);
END;

```

#### SP-042 — SP_VALIDATE_ALPHANUMERIC

**Invoked From:**

- vt_amc_enq_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

Vehicle Details (N/A / CN_MAIN)

---

**Purpose**

Sanitises a string value in-place by stripping out every character that is not an uppercase Latin letter (A–Z) or a decimal digit (0–9), leaving only valid alphanumeric characters in the output. The procedure modifies the supplied parameter directly so the caller receives the cleansed value without any further conversion.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| P_var | Varchar2 | IN OUT |

**Output Parameters**

| Output | Source | Datatype |
|--------|--------|---------|
| P_var | Varchar2 | IN OUT |

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-028](#SP-028--WEBUTIL.LENGTH)) — WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 — Determine the current length of the input string by querying `DUAL`.
- Step 2 — Iterate character by character through the string using a `WHILE` loop, starting at position 1.
- Step 3 — For each position `i`, extract the single character at that position from `P_var` via `SUBSTR`.
- Step 4 — Check whether the character's ASCII code falls within the uppercase-letter range (65–90) or the digit range (48–57).
- Step 5 — If the character does not fall in either valid range, remove it from `P_var` using `REPLACE(..., c, NULL)`, then re-query the new length of `P_var` and decrement the position counter by 1 so the next iteration re-examines the same index (which now holds the shifted character).
- Step 6 — Increment the position counter and continue until all characters have been evaluated.
- Step 7 — Return the sanitised string in `P_var`.

---

**Decision Points**

DP-001

Condition:
The ASCII value of the current character is within the uppercase-letter range (65–90) OR within the digit range (48–57).

TRUE:
The character is valid; the position counter is incremented and processing continues to the next character.

FALSE:
The character is invalid; it is removed from `P_var` via `REPLACE`, the string length is re-evaluated, and the position counter is decremented by 1 to account for the removed character before the next iteration.

---

**Database Interactions**

- DB-001 — Read dual — query the `DUAL` pseudo-table to evaluate string expressions (`LENGTH`, `SUBSTR`, `REPLACE`) that cannot be called directly as PL/SQL functions in this implementation, used repeatedly to obtain the current string length and to extract or remove individual characters during sanitisation.

---

**Business Rules**

- SBR-001 — Only uppercase Latin letters (ASCII 65–90, i.e. A–Z) and decimal digits (ASCII 48–57, i.e. 0–9) are permitted characters; all other characters are unconditionally removed.
- SBR-002 — Sanitisation is performed in-place: the original `P_var` value is overwritten with the cleansed result, so the caller always receives the sanitised string through the same IN OUT parameter.
- SBR-003 — After removing a character, the string length is re-evaluated immediately to ensure subsequent iteration boundaries remain accurate and no characters are skipped.

---

**Implementation Logic**

```plsql
CREATE OR REPLACE
procedure sp_validate_alphanumeric
/*
$Log: SP_VALIDATE_ALPHANUMERIC.sql,v $
Revision 1.2  2004/09/02 14:45:05  muralidhard
no message

*/

(
P_var  IN OUT Varchar2)
is
len number;
c   char  ;
i   number := 1;
begin
    select length(P_var) into len from dual;
    while (i <= len)
    loop
     select substr(P_var,i,1) into c from dual;
       if not (ASCII(c) >=65 and ASCII(c) <= 90)  and
          not (ASCII(c) >=48 and ASCII(c) <= 57)    then
          select replace(P_var,c,Null) into P_var from dual;
          select length(p_var) into len from dual;
          i := i - 1;
       end if;
          i := i + 1;
    end loop;
  end;

```

#### SP-043 — STRIPDIRSEP

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]

---

**Screen:**

-(Invoked indirectly — screen follows parent invocation site.)

---

**Purpose**

Normalises a file-system path string by discarding everything after the first semicolon (taking only the first path entry when multiple are present) and stripping any trailing backslash, so that callers receive a clean, single-segment directory path ready for further manipulation.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| InPath | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-028](#SP-028--WEBUTIL.LENGTH)) — WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 — Copy the input path into a working variable.
- Step 2 — If the path contains a semicolon, truncate the string to everything before the first semicolon, discarding any additional path entries.
- Step 3 — If the resulting path ends with a backslash, remove the trailing backslash.
- Step 4 — Return the normalised path string.

---

**Decision Points**

DP-001

Condition:
The path string contains a semicolon.

TRUE:
Truncate to the substring before the first semicolon, discarding any subsequent path segments.

FALSE:
Retain the path string as-is and proceed to the trailing-separator check.

DP-002

Condition:
The last character of the (possibly truncated) path is a backslash (`\`).

TRUE:
Remove the trailing backslash.

FALSE:
Return the path unchanged.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 — When multiple path entries are present in a semicolon-separated list, only the first entry is used; all subsequent entries are silently discarded.
- SBR-002 — A trailing backslash is always removed from the returned path, so callers can append their own separator character consistently.

---

**Implementation Logic**

```plsql

  

Function StripDirSep ( InPath in varchar2) return varchar2 is 
  vcPath  varchar2(500) := InPath;
begin 
  -- Check and Strip SemiColons, we take everything
  -- Before the first Semicolon as our path
  if instr(vcPath,';') > 0 then
    vcPath := substr(vcPath,1,instr(vcPath,';') -1);
  end if;

  -- Check and Strip '\'
  if substr(vcPath,-1,1) = '\' then 
    vcPath := substr(vcPath,1,length(vcPath)-1);
  end if;

  return vcPath;
end StripDirSep;
```

#### SP-044 — WINDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly — screen follows parent invocation site.)

---

**Purpose**

Sends a debug text message to the Windows debug output stream by invoking the native `d2kwutil_DebugString` DLL function, provided the Win API layer is currently enabled. If the API is unavailable or the call fails, the error is recorded and re-raised so the caller is informed.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-033](#SP-033--ADD_ERROR)) — matched by member name
- ADD_EXTERNAL_ERRORS ([SP-034](#SP-034--ADD_EXTERNAL_ERRORS)) — matched by member name
- D2KWUTIL.D2KWUTIL_DEBUGSTRING ([SP-006](#SP-006--D2KWUTIL.D2KWUTIL_DEBUGSTRING)) — D2KWUTIL.pck (or .pld) (specification only — no body found)
- REGISTER_FUNCTION_CALL ([SP-038](#SP-038--REGISTER_FUNCTION_CALL)) — matched by member name

---

**Step-by-Step Business Logic**

- Step 1 — Append a newline character (`chr(10)`) to the supplied text to form the output buffer.
- Step 2 — Check whether the Win API layer is currently enabled (`Win_API.API_ENABLED`).
- Step 3 — If enabled, register the `d2kwutil_DebugString` DLL function call via `Register_Function_Call`, specifying its signature (`*CHAR` argument, no return type).
- Step 4 — Invoke the native `d2kwutil_DebugString` function using the registered function handle, passing the text buffer.
- Step 5 — If the Win API layer is not enabled, raise `WIN_API.NOT_AVAILABLE`.
- Step 6 — On `WIN_API.NOT_AVAILABLE`: record an error entry via `Win_API.Add_error` identifying the routine and the no-API condition, then re-raise the exception.
- Step 7 — On any other exception: record an error entry combining the generic unexpected-error message with any external error details from `WIN_API.Add_External_errors`, then re-raise.

---

**Decision Points**

DP-001

Condition:
`Win_API.API_ENABLED` is TRUE (the Win API DLL layer is available).

TRUE:
Register and invoke the native `d2kwutil_DebugString` function to write the debug message.

FALSE:
Raise `WIN_API.NOT_AVAILABLE`, which is caught by the exception handler that records the error and re-raises.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 — Debug output via the Windows debug stream is conditional on the Win API layer being enabled; the procedure does not silently succeed when the API is unavailable.
- SBR-002 — All errors (both API-unavailable and unexpected) are recorded through `Win_API.Add_error` before being re-raised, ensuring the caller always receives error context.
- SBR-003 — The text message is always terminated with a newline character before being passed to the native debug function.

---

**Implementation Logic**

```plsql
  

  
PROCEDURE WinDebug  (  Text  IN   VARCHAR2) is
  vcBuff1 VARCHAR2(2000) := Text||chr(10);
begin 
  --WIN_API.Clean_Error_Stack;
  if Win_API.API_ENABLED then
    win_api.Register_function_call(iDebugString,'d2kwutil_DebugString',NULL,'*CHAR');
    d2kwutil_DebugString(win_api.FunctionHandle(iDebugString),vcBuff1);
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if; 
exception
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('WinDebug',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('WinDebug',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end WinDebug;
```

---

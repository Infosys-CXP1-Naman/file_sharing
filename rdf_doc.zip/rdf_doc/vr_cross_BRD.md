# BUSINESS REQUIREMENTS DOCUMENT

## Table of Contents

- 1. Document Control
  - 1.1 Document Information
  - 1.2 Revision History
- 2. Executive Summary
  - Key Stakeholders
- 3. System Context
- 4. Functional Requirements
  - 4.1 Business Requirements
    - Requirement ID: BR-001
    - Requirement ID: BR-002
    - Requirement ID: BR-003
    - Requirement ID: BR-004
    - Requirement ID: BR-005
    - Requirement ID: BR-006
    - Requirement ID: BR-007
    - Requirement ID: BR-008
    - Requirement ID: BR-009
    - Requirement ID: BR-010
    - Business Scenarios - How results differ by extended warranty status selection
    - Requirement ID: BR-011
    - Business Scenarios - How export results differ by extended warranty status selection
    - Requirement ID: BR-012
    - Requirement ID: BR-013
    - Requirement ID: BR-014
    - Requirement ID: BR-015
    - Requirement ID: BR-016
    - Requirement ID: BR-017
    - Requirement ID: BR-018
    - Requirement ID: BR-019
    - Requirement ID: BR-020
    - Requirement ID: BR-021
- 5. Business Rules Catalogue
- 6. Data Requirements
  - 6.1 Business Entities and Relationships
    - Workshop Job Card - VH_RO (via CROSS_SELL_UPSELL)
    - Vehicle Master - GM_VIN (via CROSS_SELL_UPSELL)
    - Customer Master - GM_CIN (via CROSS_SELL_UPSELL)
    - Extended Warranty Master - MWAR_EXTE (via CROSS_SELL_UPSELL)
    - Entity Relationships
  - 6.2 Data Capture Requirements
    - Search Criteria (User - before running the report)
    - Results Display (System - after View is pressed)
    - Parameters and Session Data
  - 6.3 Reference Data
  - 6.4 Data Lifecycle
  - 6.5 Excel Output Columns
- 7. Glossary
- 8. Technical Inventory
  - 8.1 Form Architecture
    - 8.1.1 Global Variables
    - 8.1.2 Form Parameters
  - 8.2 Blocks
    - 8.2.1 Block WhereClause and OrderByClause
  - 8.3 Items Summary
  - 8.4 List of Values
  - 8.5 Alerts
  - 8.6 Program Units
  - 8.7 Triggers
    - 8.7.1 Inactive / Commented-Out Trigger Register
  - 8.8 Canvas and Window Inventory
  - 8.9 Editors
  - 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups
    - 8.10.1 Visual Attributes (form-defined)
    - 8.10.2 Property Classes (form-defined)
    - 8.10.3 Object Groups
  - 8.11 DataSourceColumn Inventory
    - CROSS_SELL_UPSELL (29 columns)
- 9. Object Library
- 10. Record Groups
- 11. Referenced Database Objects
- 12. Backend Procedures and Packages
  - 12.1 Main Flow Backend Procedure/Package Index
  - 12.2 Procedure and Package Catalogue
    - PROC_POP_LIST (form program unit)
    - VIEW_EXCEL_REP (form program unit)
    - SF_GET_CUST_ADDRESS
    - SF_GET_MODEL_DESC
    - SF_GET_VARIANT_DESC
    - SF_GET_LIST_DESC
    - YR_DATE_YR
    - GENERAL (DPL library package)
    - DBMS_APPLICATION_INFO (Oracle built-in package)
    - WEB (Oracle Forms web package)
    - WEBUTIL (Oracle Forms WebUtil library package)
    - WEBUTIL_CORE (Oracle Forms WebUtil library package)
- 13. Package Procedure Specifications
- 14. Database Package Catalogue
- 15. PLD Procedure Call Sites
  - DPL.pld (`general`)
  - Inactive / commented-only PLD call sites
  - webutil.pld (`WEBUTIL_CORE`)
  - webutil.pld (`WEBUTIL_C_API`)
- 16. Microservice API Candidates
  - 16.1 Microservices with APIs
- 17. Workflows
- 18. PLD-Backed Logic
  - webutil.pld (`CLIENT_IMAGE`)
  - DPL.pld (`general`)
  - D2kwutil.pld (`Win_API`)
- 19. PCK-Backed Logic
- 20. System Interfaces
  - 20.1 Database Integrations
  - 20.2 External System Integrations
  - 20.3 Report Integrations
    - 20.3.1 Parameters Passed to the Report
- 21. Procedure and Function Business Rule Catalogue
  - 21.1 Catalogue Index
  - 21.2 Detailed Specifications
    - SP-001 - PROC_POP_LIST
    - SP-002 - VIEW_EXCEL_REP
    - SP-003 - D2KWUTIL.ATTEMPT_DLL_LOAD
    - SP-004 - D2KWUTIL.D2KWUTIL_DEBUGSTRING
    - SP-005 - D2KWUTIL.D2KWUTIL_GETDOSENV
    - SP-006 - D2KWUTIL.D2KWUTIL_GETREGKEY
    - SP-007 - D2KWUTIL.TRANSLATETYPE
    - SP-008 - GENERAL.ASK_CONFIRM
    - SP-009 - GENERAL.DISP_TEXT
    - SP-010 - GENERAL.RAISE_ERROR
    - SP-011 - WEBUTIL.BLOCKING
    - SP-012 - WEBUTIL.CHECKLIBS
    - SP-013 - WEBUTIL.CLEARCALLBACKTRIGGER
    - SP-014 - WEBUTIL.CLOSEBLOB
    - SP-015 - WEBUTIL.CLOSEFILE
    - SP-016 - WEBUTIL.DOWNLOADFROMURLINT
    - SP-017 - WEBUTIL.ERROR
    - SP-018 - WEBUTIL.ERRORALERT
    - SP-019 - WEBUTIL.EXECUTE
    - SP-020 - WEBUTIL.FCLOSE
    - SP-021 - WEBUTIL.FOPEN
    - SP-022 - WEBUTIL.GETCALLBACKTRIGGER
    - SP-023 - WEBUTIL.GETCLIENTOSFAMILY
    - SP-024 - WEBUTIL.GETCLIENTSETTING
    - SP-025 - WEBUTIL.GETIMPLCLASS
    - SP-026 - WEBUTIL.GETLASTERROR
    - SP-027 - WEBUTIL.GETLASTERRORARGS
    - SP-028 - WEBUTIL.GETNUMBER
    - SP-029 - WEBUTIL.GETOSFAMILY
    - SP-030 - WEBUTIL.GETOUTPUT
    - SP-031 - WEBUTIL.GETPROPERTY
    - SP-032 - WEBUTIL.GETSTRING
    - SP-033 - WEBUTIL.GETVAR
    - SP-034 - WEBUTIL.GET_LINE
    - SP-035 - WEBUTIL.GET_STANDARD_OUTPUT
    - SP-036 - WEBUTIL.ID_NULL
    - SP-037 - WEBUTIL.INIT
    - SP-038 - WEBUTIL.INITWEBUTIL
    - SP-039 - WEBUTIL.ISERROR
    - SP-040 - WEBUTIL.IS_OPEN
    - SP-041 - WEBUTIL.LENGTH
    - SP-042 - WEBUTIL.LOG
    - SP-043 - WEBUTIL.POPULATEPROPERTYBUNDLE
    - SP-044 - WEBUTIL.PUT_LINE
    - SP-045 - WEBUTIL.READFROMPROPERTYBUNDLE
    - SP-046 - WEBUTIL.READTRANSFROMMSGBUNDLE
    - SP-047 - WEBUTIL.REGISTERBEAN
    - SP-048 - WEBUTIL.REGISTER_FUNCTION
    - SP-049 - WEBUTIL.RELEASE_PROCESS
    - SP-050 - WEBUTIL.SETCLIENTSETTING
    - SP-051 - WEBUTIL.SETDATA
    - SP-052 - WEBUTIL.SETPROPERTY
    - SP-053 - WEBUTIL.SHOWBEANS
    - SP-054 - WEBUTIL.WRITEDATA
    - SP-055 - WEBUTIL_CORE.CUSTOMEVENTHANDLER
    - SP-056 - ADD_ERROR
    - SP-057 - ADD_EXTERNAL_ERRORS
    - SP-058 - BOOLTOCHAR
    - SP-059 - CLEAN_ERROR_STACK
    - SP-060 - DEBUGLOG
    - SP-061 - GET_ENVIRONMENT_STRING
    - SP-062 - READ_REGISTRY
    - SP-063 - REGISTER_FUNCTION_CALL
    - SP-064 - SETDEBUG
    - SP-065 - SF_GET_CUST_ADDRESS
    - SP-066 - SF_GET_MODEL_DESC
    - SP-067 - SF_GET_VARIANT_DESC
    - SP-068 - STRIPDIRSEP
    - SP-069 - WINDEBUG

## 1. Document Control

### 1.1 Document Information

| Field | Value |
| ----- | ----- |
| Document Title | VR_CROSS - Business Requirements Document |
| Form Module Name | VR_CROSS |
| Document Version | 1.0 |
| Date Created | August 15, 2026 |
| Author/Prepared By | BRD Agent |

### 1.2 Revision History

| Version | Date | Author | Description |
| --- | --- | --- | --- |
| 1.0 | August 15, 2026 | BRD Agent | Initial draft |

---

## 2. Executive Summary

*High-level overview of the vr_cross Cross-Sell and Upsell Opportunity form, its purpose, and roles referenced in the module.*

The **vr_cross** Oracle Forms module is the dealer **Cross-Sell and Upsell Opportunity** screen. A service advisor or workshop manager opens the screen, selects the dealer location and workshop visit date range, and optionally refines the search by vehicle model, variant, sale date range, odometer range, job card status, and extended warranty status. When the user submits the search, the form retrieves all matching vehicle and customer records from the workshop visit history and displays them in a scrollable list showing registration number, VIN, customer name, contact numbers, customer address, vehicle model and variant, workshop visit date, vehicle age, mileage, and extended warranty type. The user can then export the displayed results to a CSV file for downstream outreach and sales activities. All phone numbers are masked for privacy at the point of display and export. The form is read-only - it presents information for cross-sell and upsell decision-making and does not create or modify any records.

### Key Stakeholders

*Who uses vr_cross*

| Stakeholder | Role |
| :--- | :--- |
| **Service Advisor / Workshop Manager** | **Primary interactive user** of vr_cross. Selects search criteria, submits the vehicle search, reviews the results list, and exports data to CSV for customer outreach. |
| **Dealer Principal / Service Head** | Receives exported data for cross-sell and upsell campaign planning; does not interact with the form directly. |
| **Vehicle Owner / Customer** | Customer whose workshop visit history, contact details, and vehicle information are retrieved and displayed; does not use the form. |

---

---

## 3. System Context

*Describes the vr_cross module's role within the DMS ecosystem, scope, process flow, and key integrations.*

The **vr_cross** module is the dealer **Cross-Sell and Upsell Opportunity** screen within the Dealer Management System (DMS). It serves as a targeted search and reporting tool that allows service staff to identify customers whose vehicles have recently visited the workshop and who may be candidates for cross-sell or upsell opportunities such as extended warranty renewals, accessories, or service packages. The module queries workshop visit records against the current dealer and location, applies user-specified filters, and presents the results in a read-only grid for review and export.

**System purpose:** Allow service advisors to search workshop visit records by dealer location, date range, vehicle model, variant, odometer range, job card status, and extended warranty status, display matching customer and vehicle details in a scrollable results list, and export the data to a CSV file for cross-sell and upsell outreach activities.

**In scope:**

- Select the dealer location from the list of service locations authorised for the logged-in user
- Enter and validate a workshop visit date range (from-date and to-date)
- Optionally filter by vehicle model and variant selected from lookup lists
- Optionally filter by vehicle sale date range
- Optionally filter by odometer reading range (from and to)
- Optionally filter by job card (RO) status selected from a dynamic dropdown
- Optionally filter by extended warranty type selected from a dynamic dropdown
- Execute a search to retrieve matching vehicle and customer workshop visit records
- Display results in a read-only multi-row grid with registration, VIN, customer details, vehicle details, workshop date, vehicle age, mileage, and extended warranty type
- Apply phone number masking (showing only the last 4 digits) on all contact numbers displayed and exported
- Export the full results grid to a CSV file for offline use
- Validate all date and numeric filter entries before executing the search

**Process Name:** Cross-Sell and Upsell Opportunity Search

**Process Owner:** Service Head / Workshop Manager

**Process Objective:** Enable service staff to identify and retrieve the details of customers whose vehicles have recently visited the workshop, so that targeted cross-sell and upsell actions can be planned and executed.

**Process Trigger:** Service advisor or workshop manager opens the Cross-Sell/Upsell screen to identify potential customers for outreach

**Process Flow:**

The complete cross-sell and upsell opportunity search process follows this sequence. Each step corresponds to Functional Requirements in Section 4.

```
STEP 1 ── FORM OPENS
         Service advisor opens the vr_cross screen.
         Session context is registered with DBMS application info for monitoring.
         Dropdown lists for job card status and extended warranty type are populated
         dynamically from the lookup table.

STEP 2 ── LOCATION SELECTION
         Advisor selects the dealer service location from the Location LOV.
         The list shows only locations of type 2S or 3S that are active and
         authorised for the current logged-in user.
         Location code and dealer mapping code are stored internally.

STEP 3 ── MODEL SELECTION (optional)
         Advisor optionally opens the Model LOV and selects a vehicle model.
         The model code and description are populated. Default is ALL models.

STEP 4 ── VARIANT SELECTION (optional)
         Advisor optionally opens the Variant LOV to narrow by variant.
         The variant list is filtered to the selected model for the principal.
         Default is ALL variants.

STEP 5 ── WORKSHOP FROM-DATE ENTRY
         Advisor enters the workshop visit from-date.
         System validates that the from-date is not greater than today's date.
         System validates that the from-date is not greater than the to-date
         when a to-date has already been entered.

STEP 6 ── WORKSHOP TO-DATE ENTRY
         Advisor enters the workshop visit to-date.
         System validates that the to-date is not entered without a from-date.
         System validates that the to-date is not less than the from-date.

STEP 7 ── SALE FROM-DATE ENTRY (optional)
         Advisor optionally enters a vehicle sale from-date to restrict results
         to vehicles sold within a specific period.
         System validates the sale from-date is not greater than today's date.

STEP 8 ── SALE TO-DATE ENTRY (optional)
         Advisor optionally enters a vehicle sale to-date.
         System validates the to-date is not entered without a sale from-date
         and is not less than the sale from-date.

STEP 9 ── ODOMETER FROM ENTRY (optional)
         Advisor optionally enters a minimum odometer reading.
         System validates that from-odometer does not exceed the to-odometer value.

STEP 10 ── ODOMETER TO ENTRY (optional)
          Advisor optionally enters a maximum odometer reading.
          System validates that to-odometer is not less than from-odometer.

STEP 11 ── JOB CARD STATUS SELECTION (optional)
          Advisor optionally selects a job card (RO) status from the dropdown.
          Dropdown includes status values from the RO_STATUS1 lookup plus an
          ALL option. Default is ALL statuses.

STEP 12 ── EXTENDED WARRANTY STATUS SELECTION (optional)
          Advisor optionally selects an extended warranty type from the dropdown.
          Options include ALL, No Ext Warranty, and active warranty type codes.
          Default is ALL.

STEP 13 ── SEARCH EXECUTION
          Advisor presses the View / Search button.
          System executes the cross-sell/upsell query combining all active filters
          against workshop visit, vehicle, and customer data.
          ├── No records found: system displays an alert "No Record Available for
          │   Selected Criteria" and returns focus to the from-date field.
          └── Records found: results are loaded into the grid.

STEP 14 ── RESULTS DISPLAY
          Matching records are displayed in the read-only results grid.
          Each row shows: registration number, VIN, customer name, mobile phone
          (masked), residential phone (masked), address, model, variant,
          workshop visit date, vehicle age, mileage, and extended warranty type.
          Row count is shown at the top of the results.

STEP 15 ── RESULTS REVIEW
          Advisor reviews the displayed customer and vehicle information.
          The grid is read-only; no data can be edited from this screen.

STEP 16 ── EXPORT TO CSV (optional)
          Advisor presses the Export to Excel button.
          System builds a dynamic query combining all active filter criteria,
          generates a CSV file (named with the user ID and timestamp), writes
          it to the server, and opens it in the browser for download.
          Phone numbers are masked in the export (showing only the last 4 digits).

STEP 17 ── CLEAR / RESET (optional)
          Advisor presses the Clear button to reset the results grid and
          control block for a new search.

STEP 18 ── FORM EXIT
          Advisor closes the form using the Exit button or keyboard shortcut.
          Session monitoring info is cleared and the form exits without validation.
```

**Major process interactions:**

- **Workshop repair order data** - provides the vehicle workshop visit history used as the source for cross-sell and upsell results
- **Vehicle master data** - supplies vehicle identification, model, variant, and invoice date details
- **Customer information** - provides customer name, contact numbers, and address for display and export
- **Extended warranty records** - supplies extended warranty type for each vehicle
- **Model and variant master data** - populates the model and variant LOVs for filtering
- **Location and dealer master data** - provides the user-authorised list of active service locations
- **Lookup list data** - supplies job card status and extended warranty type codes and descriptions for dropdown filters
- **CSV / Excel export** - results are written to a CSV file on the server and delivered to the user's browser

---

---

## 4. Functional Requirements

### 4.1 Business Requirements

#### Requirement ID: BR-001

**Requirement Title:** Form Session Registration on Load

**Business Description:**
When the Cross-Sell and Upsell report form is opened, the system registers the current user's session in the database with a fixed identifier for the form, and sets the application-identity global so that all subsequent processing within the session knows it is running under the cross-sell and upsell form. This allows database administrators and performance monitoring tools to identify active form sessions by name and trace any slow-running queries back to this particular screen.

**Actors:** Service Advisor / Workshop User

**Preconditions:**
- The user has successfully authenticated and is launching the cross-sell and upsell report screen.

**Main Flow:**

**Step 1 - Database session tagged with form identity**
Before the form becomes visible, the system records the module name `vr_cross` and an empty action label against the user's current database connection, and sets the client information field to `vr_cross`. This allows database performance monitoring to identify that the session belongs to this form.

*Business outcomes (errors, warnings, success, and status):*
- **BR-001-IC-01** - `module_name = 'vr_cross'` - the database session is tagged with the form's module name so it can be traced by monitoring tools.

**Step 2 - Application identity seed set**
Once the form becomes active, the system assigns the value `vr_cross` to the global application-identity variable (`global.app_id`) and propagates it to the application-id session parameter (`parameter.p_app_id`). This seed identifies the running form to any shared library routines that inspect the calling application.

*Business outcomes (errors, warnings, success, and status):*
- **BR-001-IC-02** - `global.app_id` set to `vr_cross` - the application identity is available to all shared routines for the duration of the session.

---

---

#### Requirement ID: BR-002

**Requirement Title:** Job Card Opening Date Range - From Date Entry and Validation

**Business Description:**
When the user enters a job card opening start date, the system checks that the date is not in the future and is not later than the end date already on screen. If both checks pass, the system automatically derives and sets the corresponding end date to one month after the start date (or today if that derived date would fall in the future). If the start date is left blank, the system blocks further processing and requires the user to provide it.

**Actors:** Service Advisor / Workshop User

**Preconditions:**
- The cross-sell and upsell report screen is open.
- The user is entering or correcting the job card opening start date.

**Main Flow:**

**Step 1 - Entered start date checked for completeness**
The user enters or leaves blank the job card opening start date field. The system checks whether a value has been provided. If the field is empty, the system displays an error and prevents the user from moving to the next field.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-002](#sp-002)) - GENERAL.DISP_TEXT - displays an error alert to the user with a given message text and title, then allows processing to continue or be aborted by the calling code.
    * **Step 1** - Determine which alert type to use based on whether the title indicates an error or a general note.
    * **Step 2** - Set the title and body text of the chosen alert pop-up to the message provided.
    * **Step 3** - Show the alert to the user and wait for acknowledgement.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Job card opening from date is required | WHEN-VALIDATE-ITEM on CB_DUMMY.P_FROM_DATE - `IF :CB_DUMMY.P_FROM_DATE IS NULL` branch calling GENERAL.DISP_TEXT [SP-002] | When the user leaves the job card opening from date field | Ensures the mandatory start date of the job card date range is always provided before the user proceeds | *"From Date can not be empty"* is displayed; the trigger aborts and the user must enter a date |

*Business outcomes (errors, warnings, success, and status):*
- **BR-002-ES-01** - The job card opening start date field is blank - *"From Date can not be empty"*; the user must enter a date before moving to the next field.

**Step 2 - Start date checked against today's date**
If a date has been entered, the system verifies that the start date does not fall after today. A future date would produce no workshop visit records because no visits can have occurred yet.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Job card opening from date must not be in the future | WHEN-VALIDATE-ITEM on CB_DUMMY.P_FROM_DATE - `IF :CB_DUMMY.P_FROM_DATE > SYSDATE` branch | When the user leaves the job card opening from date field after entering a value | Prevents the selection of a future date that cannot yet have any workshop visit records | *"From Date cannot be greater than Current Date"* is shown as an alert; the trigger aborts and the user must correct the date |

*Business outcomes (errors, warnings, success, and status):*
- **BR-002-ES-02** - The start date is after today - *"From Date cannot be greater than Current Date"*; the trigger aborts the field exit.

**Step 3 - Start date checked against the currently entered end date**
If an end date is already on screen, the system checks that the start date is not later than it, ensuring the date range is logically valid.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Job card opening from date must not exceed the to date | WHEN-VALIDATE-ITEM on CB_DUMMY.P_FROM_DATE - `ELSIF :CB_DUMMY.P_FROM_DATE > :CB_DUMMY.P_TO_DATE` branch | When the user leaves the job card opening from date field after entering a value | Ensures the start date does not exceed the end date, which would produce an empty result set | *"From Date cannot be greater than To Date"* is shown as an alert; the trigger aborts the field exit |

*Business outcomes (errors, warnings, success, and status):*
- **BR-002-ES-03** - The start date is later than the existing end date - *"From Date cannot be greater than To Date"*; the trigger aborts the field exit.

**Step 4 - End date automatically derived from the start date**
Once the start date passes all validations, the system calculates one calendar month forward from the start date (the last day of the following month). If that derived date falls after today, the end date is set to today; otherwise it is set to the derived last-day-of-month date. This ensures the default search range never exceeds one calendar month.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

**Alternative Flows:**
- **BR-002-AF-01** - (from Step 2) The start date is after today: the system displays *"From Date cannot be greater than Current Date"* and aborts the field exit; the user must enter a valid past or current date.
- **BR-002-AF-02** - (from Step 3) The start date is later than the already-entered end date: the system displays *"From Date cannot be greater than To Date"* and aborts the field exit; the user must correct the date.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| JC Opening From Date (`P_FROM_DATE`) | Mandatory | Date | DD-MON-RRRR | N/A | N/A | N/A | Must be provided; must not be after today; must not be later than the To Date if already entered | *"From Date can not be empty"* / *"From Date cannot be greater than Current Date"* / *"From Date cannot be greater than To Date"* |
| JC Opening To Date (`P_TO_DATE`) | Auto-populated | Date | DD-MON-RRRR | N/A | N/A | From Date entered and valid | Automatically set to the last day of the month one calendar month after the From Date, capped at today if that date is in the future | N/A |

---

---

#### Requirement ID: BR-003

**Requirement Title:** Job Card Opening Date Range - To Date Entry and Validation

**Business Description:**
When the user enters or changes the job card opening end date, the system verifies that the end date is not in the future, is not earlier than the start date, and does not extend the range beyond one calendar month. The system also requires that a start date has already been entered before an end date can be accepted. If any rule is violated, the user is shown the specific reason and must correct the value before proceeding.

**Actors:** Service Advisor / Workshop User

**Preconditions:**
- The cross-sell and upsell report screen is open.
- The user is entering or correcting the job card opening end date.

**Main Flow:**

**Step 1 - End date checked for completeness**
The user enters or clears the job card opening end date. If the field is left blank, the system displays an error and aborts the field exit.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-002](#sp-002)) - GENERAL.DISP_TEXT - displays an error alert to the user with a given message text and title, used here when the end date field is left blank.
    * **Step 1** - Determine which alert type to use based on whether the title indicates an error or a general note.
    * **Step 2** - Set the title and body text of the chosen alert pop-up to the message provided.
    * **Step 3** - Show the alert to the user and wait for acknowledgement.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Job card opening to date is required | WHEN-VALIDATE-ITEM on CB_DUMMY.P_TO_DATE - `IF :CB_DUMMY.P_TO_DATE IS NULL` (ELSE branch) calling GENERAL.DISP_TEXT [SP-002] | When the user leaves the job card opening to date field | Ensures the end date of the search range is always provided | *"To Date can not be empty"* is displayed; the trigger aborts and the user must enter a date |

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-ES-01** - The end date field is blank - *"To Date can not be empty"*; the user must enter a date before moving on.

**Step 2 - End date requires a start date to already be provided**
If the start date has not yet been entered, the system rejects the end date and prompts the user to enter the start date first.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Start date must exist before an end date is entered | WHEN-VALIDATE-ITEM on CB_DUMMY.P_TO_DATE - `IF :CB_DUMMY.P_FROM_DATE IS NULL` branch calling GENERAL.DISP_TEXT [SP-002] | When the user leaves the job card opening to date field | Enforces the logical dependency that a range end requires a range start | *"To date cannot be entered without entering From date"* is displayed; the trigger aborts |

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-ES-02** - The start date is blank when an end date is entered - *"To date cannot be entered without entering From date"*; the trigger aborts.

**Step 3 - End date checked against the start date (not earlier)**
The system verifies that the end date is not earlier than the start date.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Job card opening to date must not be earlier than from date | WHEN-VALIDATE-ITEM on CB_DUMMY.P_TO_DATE - `IF :CB_DUMMY.P_TO_DATE < :CB_DUMMY.P_FROM_DATE` branch | When the user leaves the job card opening to date field | Prevents an inverted date range that would produce no results | *"To Date cannot be lesser than From Date"* is shown as an alert; the trigger aborts |

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-ES-03** - The end date is earlier than the start date - *"To Date cannot be lesser than From Date"*; the trigger aborts.

**Step 4 - End date checked against the start date (not greater)**
The system additionally checks that the start date is not greater than the end date (a redundant guard covering the same cross-check from the start-date side).

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Start date must not exceed the to date | WHEN-VALIDATE-ITEM on CB_DUMMY.P_TO_DATE - `IF :CB_DUMMY.P_FROM_DATE > :CB_DUMMY.P_TO_DATE` branch | When the user leaves the job card opening to date field | Secondary guard ensuring the start/end order is valid | *"From Date cannot be greater than To Date"* is shown as an alert; the trigger aborts |

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-ES-04** - The start date exceeds the end date - *"From Date cannot be greater than To Date"*; the trigger aborts.

**Step 5 - End date checked against today's date**
The system checks that the end date does not fall after today.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Job card opening to date must not be in the future | WHEN-VALIDATE-ITEM on CB_DUMMY.P_TO_DATE - `IF :CB_DUMMY.P_TO_DATE > SYSDATE` branch | When the user leaves the job card opening to date field | Prevents selecting a future end date for which no visit records can exist yet | *"To Date cannot be greater than Current Date"* is shown as an alert; the trigger aborts |

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-ES-05** - The end date is after today - *"To Date cannot be greater than Current Date"*; the trigger aborts.

**Step 6 - Date range checked to not exceed one calendar month**
The system checks that the gap between the start date and end date does not exceed one calendar month.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Job card opening date range must be within one calendar month | WHEN-VALIDATE-ITEM on CB_DUMMY.P_TO_DATE - `IF :CB_DUMMY.P_TO_DATE > (ADD_MONTHS(:CB_DUMMY.P_FROM_DATE,1)-1)` branch | When the user leaves the job card opening to date field | Limits the report data volume by capping the query date window at one month | *"Please give the date range of maximum one month"* is shown as an alert; the trigger aborts |

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-ES-06** - The date range exceeds one calendar month - *"Please give the date range of maximum one month"*; the trigger aborts.

**Alternative Flows:**
- **BR-003-AF-01** - (from Step 2) The start date has not been entered when the user tries to enter an end date: the system displays *"To date cannot be entered without entering From date"* and aborts; the user must first fill in the start date.
- **BR-003-AF-02** - (from Step 5) The end date is after today: the system displays *"To Date cannot be greater than Current Date"* and aborts.
- **BR-003-AF-03** - (from Step 6) The date range spans more than one calendar month: the system displays *"Please give the date range of maximum one month"* and aborts.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| JC Opening To Date (`P_TO_DATE`) | Mandatory | Date | DD-MON-RRRR | N/A | N/A | From Date must already be entered | Must be provided; start date must exist first; must not be earlier than from date; must not be after today; range must be within one calendar month | Multiple error messages per failing check (see BR-003-ES-01 through ES-06) |
| JC Opening From Date (`P_FROM_DATE`) | Conditional - when To Date is entered | Date | DD-MON-RRRR | N/A | N/A | N/A | Read as a cross-validation reference when the To Date is entered | *"To date cannot be entered without entering From date"* if absent |

---

---

#### Requirement ID: BR-004

**Requirement Title:** Vehicle Sale Date Range - From Date Entry and Validation

**Business Description:**
When the user enters a vehicle sale start date for filtering, the system checks that the date is not in the future and is not later than the sale end date already on screen. If the start date is left blank, the system requires the user to provide it before moving on. This ensures the sale date filter is always complete and logically consistent before the report is run.

**Actors:** Service Advisor / Workshop User

**Preconditions:**
- The cross-sell and upsell report screen is open.
- The user is entering or correcting the vehicle sale start date filter.

**Main Flow:**

**Step 1 - Sale start date checked for completeness**
The user enters or leaves blank the vehicle sale start date. If the field is empty, the system displays an error and aborts the field exit.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-002](#sp-002)) - GENERAL.DISP_TEXT - displays an error alert with the provided message text, used here when the sale from date is left blank.
    * **Step 1** - Determine which alert type to use based on whether the title indicates an error or a general note.
    * **Step 2** - Set the title and body text of the chosen alert pop-up to the message provided.
    * **Step 3** - Show the alert to the user and wait for acknowledgement.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Vehicle sale from date is required | WHEN-VALIDATE-ITEM on CB_DUMMY.P_SALE_FROM_DATE - `IF :CB_DUMMY.P_SALE_FROM_DATE IS NULL` (ELSE branch) calling GENERAL.DISP_TEXT [SP-002] | When the user leaves the vehicle sale from date field | Ensures the sale date range start is always provided | *"Sales From Date can not be empty"* is displayed; the trigger aborts |

*Business outcomes (errors, warnings, success, and status):*
- **BR-004-ES-01** - The vehicle sale start date is blank - *"Sales From Date can not be empty"*; the user must enter a value.

**Step 2 - Sale start date checked against today's date**
If a date has been entered, the system verifies it does not fall after today. It also clears the sale end date field when this check fails.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Vehicle sale from date must not be in the future | WHEN-VALIDATE-ITEM on CB_DUMMY.P_SALE_FROM_DATE - `IF :CB_DUMMY.P_SALE_FROM_DATE > SYSDATE` branch | When the user leaves the vehicle sale from date field after entering a value | Prevents selection of a future sale date for which no sold-vehicle records can exist | *"Sales From Date cannot be greater than Current Date"* is shown as an alert; the sale to date is cleared; the trigger aborts |

*Business outcomes (errors, warnings, success, and status):*
- **BR-004-ES-02** - The sale start date is after today - *"Sales From Date cannot be greater than Current Date"*; the sale end date field is cleared and the trigger aborts.

**Step 3 - Sale start date checked against the current sale end date**
If a sale end date is already entered, the system checks that the start date is not later than it. The sale end date is also cleared when this check fails.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Vehicle sale from date must not exceed the sale to date | WHEN-VALIDATE-ITEM on CB_DUMMY.P_SALE_FROM_DATE - `ELSIF :CB_DUMMY.P_SALE_FROM_DATE > :CB_DUMMY.P_SALE_TO_DATE` branch | When the user leaves the vehicle sale from date field after entering a value | Ensures the sale start date does not exceed the already-entered sale end date | *"Sales From Date cannot be greater than Sales To Date"* is shown as an alert; the sale to date is cleared; the trigger aborts |

*Business outcomes (errors, warnings, success, and status):*
- **BR-004-ES-03** - The sale start date is later than the existing sale end date - *"Sales From Date cannot be greater than Sales To Date"*; the sale end date is cleared and the trigger aborts.

**Alternative Flows:**
- **BR-004-AF-01** - (from Step 2) The sale start date is in the future: the system shows *"Sales From Date cannot be greater than Current Date"*, clears the sale to date, and aborts.
- **BR-004-AF-02** - (from Step 3) The sale start date exceeds the existing sale end date: the system shows *"Sales From Date cannot be greater than Sales To Date"*, clears the sale to date, and aborts.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vehicle Sale From Date (`P_SALE_FROM_DATE`) | Mandatory | Date | DD-MON-RRRR | N/A | N/A | N/A | Must be provided; must not be after today; must not be later than the Sale To Date if already entered | *"Sales From Date can not be empty"* / *"Sales From Date cannot be greater than Current Date"* / *"Sales From Date cannot be greater than Sales To Date"* |
| Vehicle Sale To Date (`P_SALE_TO_DATE`) | Conditional - cleared on failure | Date | DD-MON-RRRR | N/A | N/A | N/A | Cleared when the sale from date fails either the future-date or cross-date validation | Cleared automatically; no message at this field during sale-from-date validation |

---

---

#### Requirement ID: BR-005

**Requirement Title:** Vehicle Sale Date Range - To Date Entry and Validation

**Business Description:**
When the user enters or changes the vehicle sale end date, the system verifies that a sale start date already exists, that the end date is not earlier than the start date, that neither the cross-check from the other direction fails, and that the end date is not in the future. Any violation is reported to the user with a specific message and the entry is blocked until the value is corrected.

**Actors:** Service Advisor / Workshop User

**Preconditions:**
- The cross-sell and upsell report screen is open.
- The user is entering or correcting the vehicle sale end date filter.

**Main Flow:**

**Step 1 - Sale end date checked for completeness**
The user enters or clears the vehicle sale end date. If the field is left blank, the system displays an error and aborts the field exit.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-002](#sp-002)) - GENERAL.DISP_TEXT - displays an error alert with the provided message and title, used here when the sale to date is left blank.
    * **Step 1** - Determine which alert type to use based on whether the title indicates an error or a general note.
    * **Step 2** - Set the title and body text of the chosen alert pop-up to the message provided.
    * **Step 3** - Show the alert to the user and wait for acknowledgement.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Vehicle sale to date is required | WHEN-VALIDATE-ITEM on CB_DUMMY.P_SALE_TO_DATE - `IF :CB_DUMMY.P_SALE_TO_DATE IS NULL` (ELSE branch) calling GENERAL.DISP_TEXT [SP-002] | When the user leaves the vehicle sale to date field | Ensures the sale date range end is always provided | *"Sales To Date can not be empty"* is displayed; the trigger aborts |

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-ES-01** - The sale end date is blank - *"Sales To Date can not be empty"*; the user must enter a value.

**Step 2 - Sale end date requires a sale start date to already be provided**
If no sale start date has been entered, the system rejects the end date entry.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Sale start date must exist before sale end date is entered | WHEN-VALIDATE-ITEM on CB_DUMMY.P_SALE_TO_DATE - `IF :CB_DUMMY.P_SALE_FROM_DATE IS NULL` branch calling GENERAL.DISP_TEXT [SP-002] | When the user leaves the vehicle sale to date field | Enforces the logical dependency that a range end requires a range start | *"Sales To date cannot be entered without entering Sales From date"* is displayed; the trigger aborts |

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-ES-02** - The sale start date is absent - *"Sales To date cannot be entered without entering Sales From date"*; the trigger aborts.

**Step 3 - Sale end date checked against the sale start date (not earlier)**
The system verifies that the end date is not before the start date.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Sale to date must not be earlier than sale from date | WHEN-VALIDATE-ITEM on CB_DUMMY.P_SALE_TO_DATE - `IF :CB_DUMMY.P_SALE_TO_DATE < :CB_DUMMY.P_SALE_FROM_DATE` branch | When the user leaves the vehicle sale to date field | Prevents an inverted date range | *"Sales To Date cannot be lesser than Sales From Date"* is shown as an alert; the trigger aborts |

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-ES-03** - The sale end date is before the start date - *"Sales To Date cannot be lesser than Sales From Date"*; the trigger aborts.

**Step 4 - Sale start date checked again from the end-date side**
The system applies the mirror cross-check confirming that the start date does not exceed the end date.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Sale from date must not exceed the sale to date | WHEN-VALIDATE-ITEM on CB_DUMMY.P_SALE_TO_DATE - `IF :CB_DUMMY.P_SALE_FROM_DATE > :CB_DUMMY.P_SALE_TO_DATE` branch | When the user leaves the vehicle sale to date field | Secondary guard confirming start/end order from the end-date perspective | *"Sales From Date cannot be greater than Sales To Date"* is shown as an alert; the trigger aborts |

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-ES-04** - The start date exceeds the end date - *"Sales From Date cannot be greater than Sales To Date"*; the trigger aborts.

**Step 5 - Sale end date checked against today's date**
The system verifies that the end date does not fall after today.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Vehicle sale to date must not be in the future | WHEN-VALIDATE-ITEM on CB_DUMMY.P_SALE_TO_DATE - `IF :CB_DUMMY.P_SALE_TO_DATE > SYSDATE` branch | When the user leaves the vehicle sale to date field | Prevents selecting a future sale end date for which no records can exist yet | *"Sales To Date cannot be greater than Current Date"* is shown as an alert; the trigger aborts |

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-ES-05** - The sale end date is after today - *"Sales To Date cannot be greater than Current Date"*; the trigger aborts.

**Alternative Flows:**
- **BR-005-AF-01** - (from Step 2) The sale start date is absent when the user tries to enter an end date: the system shows *"Sales To date cannot be entered without entering Sales From date"* and aborts.
- **BR-005-AF-02** - (from Step 5) The sale end date is in the future: the system shows *"Sales To Date cannot be greater than Current Date"* and aborts.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vehicle Sale To Date (`P_SALE_TO_DATE`) | Mandatory | Date | DD-MON-RRRR | N/A | N/A | Sale From Date must already be entered | Must be provided; sale start must exist first; must not be earlier than sale from date; must not be after today | See BR-005-ES-01 through ES-05 |
| Vehicle Sale From Date (`P_SALE_FROM_DATE`) | Conditional - when Sale To Date is entered | Date | DD-MON-RRRR | N/A | N/A | N/A | Read as a cross-validation reference when the Sale To Date is entered | *"Sales To date cannot be entered without entering Sales From date"* if absent |

---

---

#### Requirement ID: BR-006

**Requirement Title:** Odometer Range - From Value Validation

**Business Description:**
When the user enters a lower odometer reading limit as a search filter, the system checks that this value does not exceed the upper limit already on screen. If it does, the upper limit is automatically cleared and the user is alerted to correct the values before running the report.

**Actors:** Service Advisor / Workshop User

**Preconditions:**
- The cross-sell and upsell report screen is open.
- The user is entering or correcting the lower odometer reading filter value.

**Main Flow:**

**Step 1 - From odometer value checked against the to value**
When the user leaves the lower odometer limit field, the system checks whether the lower value exceeds the upper limit already entered. If it does, the upper limit is cleared and the user is shown an error alert.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Odometer from value must not exceed odometer to value | WHEN-VALIDATE-ITEM on CB_DUMMY.P_ODOMETER_FROM - `IF :P_ODOMETER_FROM > :P_ODOMETER_TO` branch | When the user leaves the odometer from field | Ensures the odometer lower bound does not exceed the upper bound, which would produce no results | *"From Odometer can not greater than To Odometer"* is shown as an alert; the odometer to value is cleared; the trigger aborts |

*Business outcomes (errors, warnings, success, and status):*
- **BR-006-ES-01** - The from odometer value exceeds the to odometer value - *"From Odometer can not greater than To Odometer"*; the to odometer field is cleared and the trigger aborts.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Odometer From (`P_ODOMETER_FROM`) | Optional | Number | Up to 10 digits | N/A | N/A | N/A | If entered, must not exceed the Odometer To value | *"From Odometer can not greater than To Odometer"* |
| Odometer To (`P_ODOMETER_TO`) | Conditional - cleared on failure | Number | Up to 10 digits | N/A | N/A | N/A | Cleared when the from odometer fails the cross-check | Cleared automatically |

---

---

#### Requirement ID: BR-007

**Requirement Title:** Odometer Range - To Value Validation

**Business Description:**
When the user enters an upper odometer reading limit, the system checks that the lower limit does not exceed it. If it does, the upper limit is cleared and the user is alerted. This mirrors the same odometer cross-check enforced from the lower-limit direction, applied consistently on both sides of the range.

**Actors:** Service Advisor / Workshop User

**Preconditions:**
- The cross-sell and upsell report screen is open.
- The user is entering or correcting the upper odometer reading filter value.

**Main Flow:**

**Step 1 - To odometer value checked against the from value**
When the user leaves the upper odometer limit field, the system checks that the lower limit is not greater than the upper value just entered. If the check fails, the upper value is cleared and an error alert is shown.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Odometer from value must not exceed odometer to value | WHEN-VALIDATE-ITEM on CB_DUMMY.P_ODOMETER_TO - `IF :P_ODOMETER_FROM > :P_ODOMETER_TO` branch | When the user leaves the odometer to field | Ensures the lower odometer bound does not exceed the newly entered upper bound | *"From Odometer can not greater than To Odometer"* is shown as an alert; the odometer to value is cleared; the trigger aborts |

*Business outcomes (errors, warnings, success, and status):*
- **BR-007-ES-01** - The from odometer exceeds the newly entered to odometer - *"From Odometer can not greater than To Odometer"*; the to odometer field is cleared and the trigger aborts.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Odometer To (`P_ODOMETER_TO`) | Optional | Number | Up to 10 digits | N/A | N/A | N/A | If entered and odometer from is also entered, from must not exceed to; to is cleared if the check fails | *"From Odometer can not greater than To Odometer"* |
| Odometer From (`P_ODOMETER_FROM`) | Optional | Number | Up to 10 digits | N/A | N/A | N/A | Read as a cross-validation reference when the Odometer To is entered | N/A at this field during odometer-to validation |

---

---

#### Requirement ID: BR-008

**Requirement Title:** Job Card Status Filter - Selection and Results Clear

**Business Description:**
When the user selects or changes the job card status filter, any previously retrieved results are removed from the screen and the result count is reset to zero, ensuring the on-screen data always matches the currently selected criteria before the user re-runs the search.

**Actors:** Service Advisor / Workshop User

**Preconditions:**
- The cross-sell and upsell report screen is open.
- The job card status dropdown has been populated with available status options.

**Main Flow:**

**Step 1 - Status selection clears previous results**
When the user changes the job card status selection from the dropdown, the system immediately resets the row count display to zero, clears all rows from the results area, and moves focus to the next filter field (the extended warranty status dropdown).

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Job Card Status (`P_JC_STATUS1`) | Optional | List | N/A | Job Card Status list (AM_LIST where LIST_NAME = 'RO_STATUS1', plus 'ALL') | Status code and description | N/A | No validation on selection itself; any prior results are cleared on change | N/A |
| Total Records Count (`COUNT_ROW`) | Auto-populated | Number | N/A | N/A | N/A | N/A | Reset to null/zero whenever a filter field changes | N/A |

---

---

#### Requirement ID: BR-009

**Requirement Title:** Extended Warranty Status Filter - Selection and Results Clear

**Business Description:**
When the user selects or changes the extended warranty status filter, any previously retrieved results are removed from the screen and the result count is reset to zero. The form then advances focus to the View button, ready for the user to run the search with the new filter applied.

**Actors:** Service Advisor / Workshop User

**Preconditions:**
- The cross-sell and upsell report screen is open.
- The extended warranty status dropdown has been populated with available options.

**Main Flow:**

**Step 1 - Extended warranty status selection clears previous results**
When the user changes the extended warranty status selection from the dropdown, the system resets the row count to zero, clears all previously displayed result rows, and moves focus to the View button to prompt the user to re-run the search.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Extended Warranty Status (`P_EW_STATUS`) | Optional | List | N/A | Extended Warranty Type list (AM_LIST where LIST_NAME = 'EXTE_WARR_TYPE', plus 'ALL' and 'No Ext Warranty'/'NOEW') | Status code and description | N/A | No validation on selection itself; any prior results are cleared on change | N/A |
| Total Records Count (`COUNT_ROW`) | Auto-populated | Number | N/A | N/A | N/A | N/A | Reset to null/zero whenever a filter field changes | N/A |

---

---

#### Requirement ID: BR-010

**Requirement Title:** Cross-Sell/Upsell Customer List - Search and Display Results

**Business Description:**
When the user presses the View button after setting all search criteria, the system queries workshop job card records for the selected workshop location, job card date range, sale date range, model, variant, odometer range, job card status, and extended warranty status. For each matching vehicle, the system retrieves the customer name, contact details (with phone numbers masked for privacy), customer address, model description, variant description, most recent workshop visit date, vehicle age in years, mileage, and extended warranty type. The results are displayed in a scrollable list on screen. If no records are found for the chosen criteria, the user is told that no data is available. This list supports the dealer's cross-sell and upsell outreach efforts by identifying which customers have recently visited for service and may be candidates for additional products or services.

**Actors:** Service Advisor / Workshop User

**Preconditions:**
- All mandatory search criteria (job card opening date range, sale date range) have been entered and validated.
- A workshop location has been selected.

**Main Flow:**

**Step 1 - Results area prepared for new data**
When the user presses the View button, the system enables the results area for writing, clears any previously displayed rows, and positions the list at the first record ready for population.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

**Step 2 - Matching vehicle and customer records retrieved**
The system queries workshop job cards joined to vehicle master, customer, and extended warranty records. Each job card is filtered by the selected workshop location, job card opening date range, odometer range, job card status (or all statuses if 'ALL' is chosen), model family, variant, and vehicle sale date range. All phone numbers in the results are masked, showing only the last four digits. The customer address is assembled from the customer master record. Model and variant descriptions are resolved from the vehicle master data. The vehicle age is calculated from the invoice date. The extended warranty type classification is resolved from the reference list. Three separate query paths are combined: one for vehicles with no extended warranty filter (all records regardless of warranty status), one for vehicles with a specific extended warranty type (types I or II), and one for vehicles explicitly having no active extended warranty.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **SF_GET_CUST_ADDRESS** ([SP-013](#sp-013)) - SF_GET_CUST_ADDRESS - retrieves the full formatted postal address of a customer from the customer master, choosing between office and permanent address based on the customer's communication preference.
    * **Step 1** - Identify the customer's preferred communication address type (office or permanent) by reading their communication preference from the customer master.
    * **Step 2** - Retrieve the address lines, city code, county/district code, state code, and postal code for the appropriate address type.
    * **Step 3** - Assemble the address line by line, appending city, district, and state descriptions resolved from the respective reference tables (each looked up separately; if not found, that component is silently omitted).
    * **Step 4** - Append the postal code (labelled as "Zip:" for one principal, "Pin:" for all others) if it is present.
    * **Step 5** - Return the fully assembled address string; if no customer record is found, return a null value.
- **SF_GET_MODEL_DESC** ([SP-014](#sp-014)) - SF_GET_MODEL_DESC - returns the description (name) of a vehicle model for the given model code and principal.
    * **Step 1** - Look up the model description from the vehicle model master using the given model code, principal identifier, and a fixed model category.
    * **Step 2** - Return the model description if found; return the fixed text "Not Found" for any failure.
- **SF_GET_VARIANT_DESC** ([SP-015](#sp-015)) - SF_GET_VARIANT_DESC - returns the description of a vehicle variant for the given variant code and principal.
    * **Step 1** - Look up the variant description from the vehicle variant master using the given variant code, principal identifier, and a fixed model category.
    * **Step 2** - Return the variant description if found; return the fixed text "Not Found" for any failure.

**Step 3 - Each result row populated on screen**
For each record returned by the query, the system fills the corresponding on-screen fields: registration number, VIN, customer name, mobile phone (masked), residential phone (masked), office phone (masked), address, model, variant, workshop visit date, vehicle age, mileage. The extended warranty type is resolved: if the raw warranty type from the query is blank, the system assigns the fixed label "No Ext Warranty"; otherwise it looks up the human-readable warranty type description from the extended warranty type reference list and displays that instead.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

**Step 4 - Total record count displayed**
After all rows have been loaded, the system displays the total number of records found in the total records counter. If the count is zero, the system shows an alert informing the user that no records were found and returns focus to the job card opening start date field so the user can adjust the criteria.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| No records found for selected criteria | WHEN-BUTTON-PRESSED on CB_DUMMY.BTN_VIEW - `IF :CB_DUMMY.COUNT_ROW = 0` branch | When the View button is pressed and the query returns no rows | Informs the user when their criteria combination produces no matching records so they can refine the search | *"No Record Available for Selected Criteria"* is shown as an alert; focus returns to the job card opening from date field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-010-ES-01** - No records match the selected criteria - *"No Record Available for Selected Criteria"*; focus returns to the job card opening start date field.

**Step 5 - Results area locked after population**
Once all rows are loaded, the system sets the results area to read-only by disabling editing, insert, and update operations, preventing the user from accidentally modifying the displayed data.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

#### Business Scenarios - How results differ by extended warranty status selection

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **All warranty statuses selected** | The query returns all matching job cards regardless of whether the vehicle has an active extended warranty; the warranty type field shows the type label where present or "No Ext Warranty" where none exists. |
| **Specific extended warranty type selected (type I or II)** | Only job cards for vehicles with an active (non-cancelled) extended warranty matching the selected type are returned; the warranty type description is resolved from the reference list. |
| **No extended warranty selected** | Only job cards for vehicles that have no active (non-cancelled) extended warranty on record are returned; the warranty type field displays "No Ext Warranty". |

**Alternative Flows:**
- **BR-010-AF-01** - (from Step 4) The query returns no rows: the system shows *"No Record Available for Selected Criteria"* and returns focus to the job card opening from date field; the user must adjust the search criteria and press View again.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Workshop (`CB_LOC_DESC`) | Mandatory | Text | Up to 100 characters | Workshop/Location lookup (`LOV_LOC` / `RG_LOC`) | Location description | N/A | Must be selected to scope the query to a workshop | N/A |
| JC Opening From Date (`P_FROM_DATE`) | Mandatory | Date | DD-MON-RRRR | N/A | N/A | Validated in BR-002 | Lower bound for job card opening date filter | N/A |
| JC Opening To Date (`P_TO_DATE`) | Mandatory | Date | DD-MON-RRRR | N/A | N/A | Validated in BR-003 | Upper bound for job card opening date filter (inclusive, +1 day applied in query) | N/A |
| Vehicle Sale From Date (`P_SALE_FROM_DATE`) | Mandatory | Date | DD-MON-RRRR | N/A | N/A | Validated in BR-004 | Lower bound for vehicle invoice date filter | N/A |
| Vehicle Sale To Date (`P_SALE_TO_DATE`) | Mandatory | Date | DD-MON-RRRR | N/A | N/A | Validated in BR-005 | Upper bound for vehicle invoice date filter (inclusive, +1 day applied in query) | N/A |
| Model (`P_MODEL_DESC`) | Optional | Text | Up to 100 characters | Model lookup (`LOV_MOD` / `RG_MOD`) | Model family code | N/A | Filters results to a specific model family; if not specified, all models are returned | N/A |
| Variant (`P_VARIANT_DESC`) | Optional | Text | Up to 100 characters | Variant lookup (`LOV_VARIANT` / `RG_VARIANT`) | Variant code | Model selected | Filters results to a specific variant; if not specified, all variants are returned | N/A |
| Odometer From (`P_ODOMETER_FROM`) | Optional | Number | Up to 10 digits | N/A | N/A | N/A | Lower bound for odometer reading filter | N/A |
| Odometer To (`P_ODOMETER_TO`) | Optional | Number | Up to 10 digits | N/A | N/A | N/A | Upper bound for odometer reading filter | N/A |
| Job Card Status (`P_JC_STATUS1`) | Optional | List | N/A | Job Card Status list | Status code | N/A | Filters by job card status; value '999' (ALL) returns all statuses | N/A |
| Extended Warranty Status (`P_EW_STATUS`) | Optional | List | N/A | Extended Warranty Type list | Status code | N/A | Drives which of the three query paths is used (ALL, specific type, or no warranty) | N/A |
| Reg No (`REG_NUM`) | Read-only display | Text | N/A | N/A | N/A | View button pressed | Populated from query results; not user-editable | N/A |
| Vin No. (`VIN`) | Read-only display | Text | N/A | N/A | N/A | View button pressed | Populated from query results; not user-editable | N/A |
| Customer Name (`CUST_NAME`) | Read-only display | Text | Up to 500 characters | N/A | N/A | View button pressed | Full customer title and name assembled from customer master | N/A |
| Mobile (`MOBILE_PHONE`) | Read-only display | Text | Up to 100 characters | N/A | N/A | View button pressed | Masked - only last 4 digits shown, remainder replaced with 'X' | N/A |
| Residance Phone (`RES_PHONE`) | Read-only display | Text | Up to 100 characters | N/A | N/A | View button pressed | Masked - only last 4 digits shown, remainder replaced with 'X' | N/A |
| Office Phone (`OFFICE_PHONE`) | Read-only display | Text | Up to 100 characters | N/A | N/A | View button pressed | Masked - only last 4 digits shown, remainder replaced with 'X' | N/A |
| Address (`ADDRESS`) | Read-only display | Text | Up to 500 characters | N/A | Resolved by SF_GET_CUST_ADDRESS | View button pressed | Full formatted address from customer master; null if customer not found | N/A |
| Model (`MODEL`) | Read-only display | Text | N/A | N/A | Resolved by SF_GET_MODEL_DESC | View button pressed | Model description from vehicle model master; "Not Found" if not resolved | N/A |
| Variant (`VARIANT`) | Read-only display | Text | Up to 150 characters | N/A | Resolved by SF_GET_VARIANT_DESC | View button pressed | Variant description from vehicle variant master; "Not Found" if not resolved | N/A |
| JC Open Date (`WRS_VISIT_DATE`) | Read-only display | Text | DD-MON-YYYY HH24:MI | N/A | N/A | View button pressed | Job card opening date and time formatted as text | N/A |
| Vehicle Age (Yrs.) (`SALE_DATE`) | Read-only display | Text | N/A | N/A | Calculated via YR_DATE_YR function | View button pressed | Number of years since vehicle invoice date | N/A |
| Mileage (`MILEAGE`) | Read-only display | Number | N/A | N/A | N/A | View button pressed | Odometer reading at workshop visit | N/A |
| EW Type (`EW_TYPE`) | Read-only display | Text | N/A | Extended Warranty Type (AM_LIST where LIST_NAME = 'EXTE_WARR_TYPE') | Type description | View button pressed | Extended warranty type description; "No Ext Warranty" when vehicle has no active warranty | N/A |
| Total (`COUNT_ROW`) | Read-only display | Number | N/A | N/A | N/A | View button pressed | Total count of records returned; shown after query completes | N/A |

---

---

#### Requirement ID: BR-011

**Requirement Title:** Cross-Sell/Upsell Customer List - Export to CSV File

**Business Description:**
When the user presses the Export to Excel button, the system builds a CSV file containing all records that match the current search criteria and makes the file available for download to the user's machine. The file is named using the current user's login name combined with the current date and time to ensure uniqueness. The same set of customer and vehicle data shown on screen (registration, VIN, customer name, masked phone numbers, address, model, variant, workshop visit date, vehicle age, mileage, and extended warranty type) is written to the file with a header row. If the query returns no data, the user is informed; other errors are also reported. This capability allows the dealer to take the cross-sell/upsell list off the screen for further outreach activity.

**Actors:** Service Advisor / Workshop User

**Preconditions:**
- All mandatory search criteria have been entered and validated.
- A workshop location has been selected.

**Main Flow:**

**Step 1 - CSV filename generated**
When the user presses the Export to Excel button, the system constructs a unique CSV filename by combining the current user's login name with the current date and time formatted as `YYYYMMDDHH24MISS`, appending the `.csv` extension. If the filename contains a space in a folder path, the system redirects the output to the C: drive root and informs the user.

*Business outcomes (errors, warnings, success, and status):*
- **BR-011-IC-01** - Filename contains spaces in folder path - *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."*; the file is saved to the C: drive instead.

**Step 2 - Query built and data written to CSV via VIEW_EXCEL_REP**
The system assembles the same data query used by the View button but formats each row as a comma-separated string. A header row is added first. The complete dataset is passed to the CSV export procedure, which writes the file to the server and delivers it to the user's browser for download.

*Procedures called:*
- **VIEW_EXCEL_REP** ([SP-001](#sp-001)) - VIEW_EXCEL_REP - creates an in-memory data group from the supplied query, writes each row as a line to a server-side CSV file, then uses the web utility to open the file in the user's browser for download.
    * **Step 1** - Generate a unique server-side filename from the user's login and the current timestamp.
    * **Step 2** - Create an in-memory record group from the provided SQL query; if the number of rows exceeds 65,535, truncate to that limit and notify the user.
    * **Step 3** - Read the server path for the export folder from a configuration file on the server.
    * **Step 4** - Open the server-side CSV file for writing and write each row from the record group as a text line.
    * **Step 5** - Close the file and open it in the user's browser using the web document viewer.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Row count limit check | WHEN-BUTTON-PRESSED on CB_DUMMY.PB_EXCEL - VIEW_EXCEL_REP [SP-001] internal `IF the_rowcount > 65536` branch | When the Export to Excel button is pressed and the query is executed | Prevents the export from generating a CSV that exceeds the maximum supported row count | *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."*; the file is still created but limited to 65,535 data rows |

*Business outcomes (errors, warnings, success, and status):*
- **BR-011-WS-01** - *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."* - shown when the query returns more than 65,535 rows; the export continues with the first 65,535 rows.
- **BR-011-ES-01** - An unrecoverable error occurs during export - *"Error  -"* followed by the error code and error message text from the system; the trigger aborts.

**Step 3 - Exception handling for data availability and other errors**
If the export query returns no data, a note message is shown. If a data type error occurs, an error message is shown. If more than one result is returned when one is expected, an error is shown. Any other failure results in a general unavailability error. In all exception cases the trigger aborts.

*Business outcomes (errors, warnings, success, and status):*
- **BR-011-ES-02** - No records match the criteria - *"Data not available "*; trigger aborts.
- **BR-011-ES-03** - Incompatible data type encountered - *"Value Error Incompatible data. "*; trigger aborts.
- **BR-011-ES-04** - Multiple records found where one expected - *"More than one State Code found for Dealer. "*; trigger aborts.
- **BR-011-ES-05** - Any other error during export - *"Unable to populate Data not available."*; trigger aborts.

#### Business Scenarios - How export results differ by extended warranty status selection

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **All warranty statuses** | The export query uses the ALL branch and returns all job cards regardless of warranty status; the warranty type column is resolved via the extended warranty description lookup function (SF_GET_LIST_DESC). |
| **Specific extended warranty type (I or II)** | The export query uses the specific-type branch and includes only vehicles with an active warranty of the selected type; the warranty type column is resolved via SF_GET_LIST_DESC. |
| **No extended warranty** | The export query uses the no-warranty branch and returns only vehicles with no active extended warranty; the warranty type column is null in the export. |

**Alternative Flows:**
- **BR-011-AF-01** - (from Step 2) No data is available for the criteria: the system shows *"Data not available "* and aborts the export.
- **BR-011-AF-02** - (from Step 2) Row count exceeds 65,535: the system shows *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."* and creates the file with the first 65,535 data rows.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Workshop (internal code `CB_DEALER_MAP_CD` / `CB_LOC_CD`) | Mandatory | Code | N/A | N/A | N/A | Workshop location selected | Used to scope the export query to the selected location | N/A |
| JC Opening From Date (`P_FROM_DATE`) | Mandatory | Date | DD-MON-RRRR | N/A | N/A | Validated in BR-002 | Lower bound for job card opening date in export query | N/A |
| JC Opening To Date (`P_TO_DATE`) | Mandatory | Date | DD-MON-RRRR | N/A | N/A | Validated in BR-003 | Upper bound for job card opening date in export query | N/A |
| Vehicle Sale From Date (`P_SALE_FROM_DATE`) | Mandatory | Date | DD-MON-RRRR | N/A | N/A | Validated in BR-004 | Lower bound for vehicle invoice date in export query | N/A |
| Vehicle Sale To Date (`P_SALE_TO_DATE`) | Mandatory | Date | DD-MON-RRRR | N/A | N/A | Validated in BR-005 | Upper bound for vehicle invoice date in export query | N/A |
| Model code (`P_MODEL_CD`) | Optional | Code | N/A | N/A | N/A | N/A | Filters export results to selected model family | N/A |
| Variant code (`P_VARIANT_CD`) | Optional | Code | N/A | N/A | N/A | N/A | Filters export results to selected variant | N/A |
| Odometer From (`P_ODOMETER_FROM`) | Optional | Number | Up to 10 digits | N/A | N/A | N/A | Lower odometer bound for export filter | N/A |
| Odometer To (`P_ODOMETER_TO`) | Optional | Number | Up to 10 digits | N/A | N/A | N/A | Upper odometer bound for export filter | N/A |
| Job Card Status (`P_JC_STATUS1`) | Optional | Code | N/A | N/A | N/A | N/A | Filters export by job card status | N/A |
| Extended Warranty Status (`P_EW_STATUS`) | Optional | Code | N/A | N/A | N/A | N/A | Controls which of the three export query paths is executed | N/A |
| Testing field (`TXT`) | Auto-populated | Text | Up to 10,000 characters | N/A | N/A | N/A | Temporarily receives the assembled SQL query string before it is passed to the export procedure | N/A |

---

---

#### Requirement ID: BR-012

**Requirement Title:** Form-Level Error Handling and Display

**Business Description:**
When any database or application error occurs during form operation, the system intercepts the error before it is shown to the user in a raw technical format and presents it in a clear, user-friendly alert. Specific categories of error are handled differently: a referential integrity violation produces a controlled error message, certain known application error codes display the error type and number, a record-locking conflict caused by another user produces a specific warning and rolls back uncommitted changes, and any other database or SQL error similarly displays a message and rolls back. Certain informational error codes (such as "no records found" and "no changes") are silently suppressed. This ensures the user always sees readable guidance rather than raw Oracle error codes.

**Actors:** Service Advisor / Workshop User (error appears automatically on any system error)

**Preconditions:**
- The form is open and an error condition has occurred during any operation.

**Main Flow:**

**Step 1 - Referential integrity violation detected and reported**
If the database returns a referential integrity constraint violation (error code -02292), the system raises a predefined application error message through the error library. The trigger then aborts, leaving the form open.

*Procedures called:*
- **GENERAL.RAISE_ERROR** ([SP-003](#sp-003)) - GENERAL.RAISE_ERROR - looks up a predefined message by the code 'E0088', determines whether it is an error, note, or caution level, displays the corresponding alert to the user, and raises a trigger failure for error-level messages.
    * **Step 1** - Assemble the message text by combining the error code with the looked-up message description.
    * **Step 2** - Determine the message level from the message type code (error, note, or caution).
    * **Step 3** - Display the assembled message in the appropriate alert and, for error-level messages, raise a trigger failure to abort the current operation.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Referential integrity violation | ON-ERROR (Form level) - `IF Derrnum = -02292` branch calling GENERAL.RAISE_ERROR [SP-003] | When any form operation triggers a database referential integrity error | Prevents the user from seeing a raw Oracle constraint error and instead shows a controlled message | GENERAL.RAISE_ERROR('E0088') is called; the trigger aborts and the form stays open |

**Step 2 - Known application error codes displayed with full context**
For a predefined set of application error numbers (40209, 40207, 50026, 50004), the system displays the error type prefix, error number, and error text concatenated together, then aborts the current trigger.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Known application error displayed | ON-ERROR (Form level) - `IF errnum IN (40209, 40207, 50026, 50004)` branch calling GENERAL.DISP_TEXT [SP-002] | When a known application error code occurs during a form operation | Presents the full error type, number, and description in a readable alert instead of a raw system message | The error type, number, and description are displayed as `[error type]-[error number]: [error text]`; the trigger aborts |

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-002](#sp-002)) - GENERAL.DISP_TEXT - displays the formatted error details `errtyp||'-'||TO_CHAR(errnum)||': '||errtxt` in an error-level alert.
    * **Step 1** - Determine which alert type to use based on whether the title indicates an error or a general note.
    * **Step 2** - Set the title and body text of the chosen alert pop-up to the message provided.
    * **Step 3** - Show the alert to the user and wait for acknowledgement.

**Step 3 - Record already updated by another user - rollback and notify**
If an error code indicates that the record being saved or updated has already been changed by another concurrent user (codes 40654, 40655, 40656, 40657, 40659), the system displays a specific warning, rolls back any uncommitted changes, and aborts the trigger.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Concurrent update conflict detected | ON-ERROR (Form level) - `IF ERROR_CODE IN (40654, 40655, 40656, 40657, 40659)` branch calling GENERAL.DISP_TEXT [SP-002] | When a record update conflict is detected | Prevents silent data loss from concurrent edits by notifying the user and rolling back | *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"* is displayed; uncommitted changes are rolled back; the trigger aborts |

*Business outcomes (errors, warnings, success, and status):*
- **BR-012-ES-01** - Record already updated by another user - *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*; changes rolled back; trigger aborts.

**Step 4 - Any other SQL/database error displayed and rolled back**
For any other non-zero SQL error code, the system displays the system's own database error message text, rolls back uncommitted changes, and aborts the trigger.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Generic SQL/database error | ON-ERROR (Form level) - `IF SQLCODE <> 0` branch calling GENERAL.DISP_TEXT [SP-002] with `sqlerrm` | When any other database error occurs during a form operation | Ensures the user always receives a readable description of unexpected errors | The system's own error message text (from sqlerrm) is displayed in an error alert; uncommitted changes are rolled back; the trigger aborts |

**Step 5 - Informational codes silently suppressed**
Error codes 40401 (query finds no records) and 40405 (no changes to save) are silently accepted with no action, as they are expected informational conditions and should not alarm the user.

**Alternative Flows:**
- **BR-012-AF-01** - (from Step 1) Referential integrity constraint violated: the predefined message for error code 'E0088' is displayed and the trigger aborts.
- **BR-012-AF-02** - (from Step 3) Record has been updated by another user: the concurrent update message is displayed, uncommitted changes are rolled back, and the trigger aborts.

---

---

#### Requirement ID: BR-013

**Requirement Title:** Form Exit - Application Session Cleanup and Close

**Business Description:**
When the user presses the keyboard exit shortcut, the system clears the form's session tracking information from the database and then closes the form without prompting to save any unsaved changes. This ensures database monitoring tools no longer show the session as active once the user has left the form.

**Actors:** Service Advisor / Workshop User

**Preconditions:**
- The cross-sell and upsell report form is open.

**Main Flow:**

**Step 1 - Database session tracking cleared**
When the user presses the keyboard exit shortcut, the system first clears the client information stored against the current database session (setting it to null) and clears the module and action name, removing the form's identity from the session monitoring record.

**Step 2 - Form closed without saving**
The system immediately closes the form, discarding any unsaved changes without prompting the user. No data is committed or rolled back; the form simply exits.

---

---

#### Requirement ID: BR-014

**Requirement Title:** Search Criteria Navigation - Previous Results Cleared on Filter Change

**Business Description:**
When the user moves away from any filter field (workshop location, model, variant, odometer from, odometer to, job card status, or extended warranty status) after making a selection or entry, the system immediately removes any previously displayed results from the screen and resets the result count to zero. This ensures the on-screen results are never shown alongside a different set of filter criteria, preventing the user from mistaking old results for a new search.

**Actors:** Service Advisor / Workshop User

**Preconditions:**
- The cross-sell and upsell report screen is open.
- The user is changing or confirming a filter field value and moving to the next filter.

**Main Flow:**

**Step 1 - Result count reset and results area cleared**
When the user confirms a filter selection and tabs to the next filter field, the system sets the result count display to null, clears all rows from the results area, and moves focus to the next appropriate filter field in sequence.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Total (`COUNT_ROW`) | Auto-populated | Number | N/A | N/A | N/A | N/A | Set to null when any filter field tab-out is detected | N/A |
| Workshop (`CB_LOC_DESC`) | Optional - clears results on tab-out | Text | Up to 100 characters | Workshop/Location lookup (`LOV_LOC` / `RG_LOC`) | N/A | N/A | Tabbing away clears prior results | N/A |
| Model (`P_MODEL_DESC`) | Optional - clears results on tab-out | Text | Up to 100 characters | Model lookup (`LOV_MOD` / `RG_MOD`) | N/A | N/A | Tabbing away clears prior results | N/A |
| Variant (`P_VARIANT_DESC`) | Optional - clears results on tab-out | Text | Up to 100 characters | Variant lookup (`LOV_VARIANT` / `RG_VARIANT`) | N/A | N/A | Tabbing away clears prior results | N/A |
| Odometer From (`P_ODOMETER_FROM`) | Optional - clears results on tab-out | Number | Up to 10 digits | N/A | N/A | N/A | Tabbing away clears prior results | N/A |
| Odometer To (`P_ODOMETER_TO`) | Optional - clears results on tab-out | Number | Up to 10 digits | N/A | N/A | N/A | Tabbing away clears prior results | N/A |

---

---

#### Requirement ID: BR-015

**Requirement Title:** Form Exit via Navigation Buttons

**Business Description:**
The form provides multiple exit controls that all close the screen without saving any unsaved changes. The Exit navigation button additionally records an exit flag in the user's session before closing, which may be used by the calling application to detect that the user explicitly exited. All exit paths discard any in-progress data without prompting, consistent with the read-only nature of this report form.

**Actors:** Service Advisor / Workshop User

**Preconditions:**
- The cross-sell and upsell report form is open.

**Main Flow:**

**Step 1 - Exit selected from navigation bar or OK button**
When the user presses the Exit button from the navigation toolbar, the system records an exit marker in the user's active session and then closes the form immediately without saving any data. When the user presses the OK button, the form closes without saving and without setting the exit marker. Both actions discard any current session state without prompting.

---

---

#### Requirement ID: BR-016

**Requirement Title:** Lookup List Value Invocation with Error Capture

**Business Description:**
When the user requests a value lookup from a filter field that supports a selectable list (such as the workshop location, model, or variant fields), the system opens the appropriate selection list for that field. If the user selects a value, the form advances to the next field automatically. If any unexpected error occurs during list invocation, the system captures and displays the error details (error code, error text, error type, database error code, and database error text) as individual informational messages so the issue can be identified without halting the form session.

**Actors:** Service Advisor / Workshop User

**Preconditions:**
- The cross-sell and upsell report form is open.
- The user's cursor is on a field that has an associated lookup list.

**Main Flow:**

**Step 1 - LOV opened for the current field**
The system identifies the LOV name associated with the current field. If a LOV is configured for that field, the lookup list is displayed at a fixed screen position. If the user makes a selection and closes the list, focus automatically moves to the next field.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

**Step 2 - Error during LOV invocation captured and displayed**
If an unexpected error occurs while opening or interacting with the lookup list, the system captures the error details and displays each detail (error code, error text, error type, database error code, database error text) as a series of informational messages. The form session remains open after the error is displayed.

*Business outcomes (errors, warnings, success, and status):*
- **BR-016-IC-01** - LOV invocation error - the error code, error text, error type, database error code, and database error text are each displayed as separate informational messages so the error can be identified.

---

---

#### Requirement ID: BR-017

**Requirement Title:** Form Clear - Reset All Criteria and Results

**Business Description:**
When the user presses the Cancel button on the toolbar, the system checks whether that button is currently active, clears all filter criteria and result data on the screen without prompting for confirmation, and then immediately restores the form's default opening values so the user can start a new search from a clean slate without closing and re-opening the form.

**Actors:** Service Advisor / Workshop User

**Preconditions:**
- The cross-sell and upsell report form is open.
- The Cancel toolbar button (`PB_CANCEL`) is enabled.

**Main Flow:**

**Step 1 - Cancel button availability verified**
When the user presses the Cancel toolbar button, the system checks whether the button is enabled before proceeding. If the button is not enabled, no action is taken.

*Screen: Toolbar (`CN_TOOL`).*

**Step 2 - All form data cleared without confirmation**
If the Cancel button is enabled, the system clears all fields, filter selections, and displayed results on the form in a single action regardless of whether any data has been changed, discarding any unsaved values without asking the user to confirm. The form is left in a blank state.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

**Step 3 - Form defaults restored to opening values**
Immediately after the clear, the system re-runs the form initialisation sequence, restoring all search criteria to their opening defaults (today's date for the job card date range, `01-JAN-1990` for the vehicle sale from date, default odometer bounds, 'ALL' model and variant selections, default job card and extended warranty status values) and re-populating the dropdown lists. The results area is locked for editing. The form is ready for a new search without requiring the screen to be closed and re-opened.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

*Business outcomes (errors, warnings, success, and status):*
- **BR-017-IC-01** - Cancel button disabled - no action is taken; the form remains unchanged.
- **BR-017-IC-02** - Cancel button enabled - all criteria and results are cleared and form defaults are restored; the user can enter new search criteria immediately.

---

---

#### Requirement ID: BR-018

**Requirement Title:** Dropdown List Population on Form Initialisation

**Business Description:**
When the cross-sell and upsell report form initialises, the system registers the form's application identity, maximises the main window, reads a copyright declaration for display, sets all search criteria to their default opening values, populates the job card status and extended warranty status dropdown lists, and locks the results area against accidental editing. These steps collectively prepare a consistent, ready-to-use search screen each time the form is opened or reset to its initial state.

**Actors:** System (automatic on form load)

**Preconditions:**
- The form is loading.

**Main Flow:**

**Step 1 - Application identity registered and window maximised**
The system assigns the application identifier `vr_cross` to the global session variable (`global.app_id`) and copies it to the application-id parameter (`parameter.p_app_id`). The main window (`WN_MAIN`) is then maximised to fill the screen. A copyright declaration is retrieved from the database; if the query fails for any reason, the copyright field is left blank.

*Screen: Main window (`WN_MAIN`).*

**Step 2 - Search criteria set to opening defaults**
The system populates all search filter fields with their default starting values:

- Job card opening from date and to date are both set to today's date.
- Vehicle sale from date is set to `01-JAN-1990`.
- Vehicle sale to date is set to 96 months (8 years) before today.
- Odometer from is set to 0; odometer to is set to 1,000,000.
- Model code and model description are both set to 'ALL'.
- Variant code and variant description are both set to 'ALL'.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

**Step 3 - Job card status dropdown populated**
The system calls `PROC_POP_LIST` to build the job card status list (`P_JC_STATUS1`) by querying the reference list table for status codes with a list name of `RO_STATUS1`, filtered to the current principal and excluding status code 20. An 'ALL' option is added as the first item. The list is created once and reused if already built. After population, the job card status field is set to the default value '999' (all statuses).

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

**Step 4 - Extended warranty status dropdown populated**
The system calls `PROC_POP_LIST` to build the extended warranty status list (`P_EW_STATUS`) by querying the reference list table for codes with a list name of `EXTE_WARR_TYPE`, filtered to the current principal. Two additional options are added: 'ALL' and 'No Ext Warranty' (code 'NOEW'). The list is created once and reused if already built. After population, the extended warranty status field is set to the default value 'ALL'.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

**Step 5 - Results area locked against editing**
The system sets the results block (`CROSS_SELL_UPSELL`) to read-only by disabling the block, disabling insert, and disabling update. This prevents the user from accidentally modifying the results area before or between searches.

*Screen: Results area (`WN_MAIN` / `CN_MAIN`).*

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Application ID (`global.app_id`) | Auto-populated | Global variable | N/A | N/A | Fixed value `vr_cross` | Form loading | Set once on initialisation | N/A |
| Application ID parameter (`parameter.p_app_id`) | Auto-populated | Parameter | N/A | N/A | Copied from `global.app_id` | Form loading | Set once on initialisation | N/A |
| JC Opening From Date (`P_FROM_DATE`) | Auto-populated | Date | DD-MON-RRRR | N/A | Today's date (SYSDATE) | Form loading | Default opening value; user may change before searching | N/A |
| JC Opening To Date (`P_TO_DATE`) | Auto-populated | Date | DD-MON-RRRR | N/A | Today's date (SYSDATE) | Form loading | Default opening value; user may change before searching | N/A |
| Vehicle Sale From Date (`P_SALE_FROM_DATE`) | Auto-populated | Date | DD-MON-RRRR | N/A | Fixed default `01-JAN-1990` | Form loading | Default opening value; user may change before searching | N/A |
| Vehicle Sale To Date (`P_SALE_TO_DATE`) | Auto-populated | Date | DD-MON-RRRR | N/A | 96 months before today (ADD_MONTHS(SYSDATE,-96)) | Form loading | Default opening value; user may change before searching | N/A |
| Odometer From (`P_ODOMETER_FROM`) | Auto-populated | Number | Integer | N/A | 0 | Form loading | Default lower bound | N/A |
| Odometer To (`P_ODOMETER_TO`) | Auto-populated | Number | Integer | N/A | 1,000,000 | Form loading | Default upper bound | N/A |
| Model Code (`P_MODEL_CD`) | Auto-populated | Text | N/A | N/A | 'ALL' | Form loading | Default - all models included | N/A |
| Model Description (`P_MODEL_DESC`) | Auto-populated | Text | N/A | N/A | 'ALL Model' | Form loading | Display label for the default model selection | N/A |
| Variant Code (`P_VARIANT_CD`) | Auto-populated | Text | N/A | N/A | 'ALL' | Form loading | Default - all variants included | N/A |
| Variant Description (`P_VARIANT_DESC`) | Auto-populated | Text | N/A | N/A | 'ALL Variant' | Form loading | Display label for the default variant selection | N/A |
| Job Card Status (`P_JC_STATUS1`) | Auto-populated | List | N/A | Job Card Status reference (AM_LIST where LIST_NAME = 'RO_STATUS1', principal-filtered, code 20 excluded, plus 'ALL') | Status code and description | Form loading | List is populated once on first use; reused if already present; default value '999' (all statuses) | N/A |
| Extended Warranty Status (`P_EW_STATUS`) | Auto-populated | List | N/A | Extended Warranty Type reference (AM_LIST where LIST_NAME = 'EXTE_WARR_TYPE', principal-filtered, plus 'ALL' and 'NOEW') | Status code and description | Form loading | List is populated once on first use; reused if already present; default value 'ALL' | N/A |

---

---

#### Requirement ID: BR-019

**Requirement Title:** Developer Debug SQL Preview (COMMENTED OUT / INACTIVE - does not execute as a business function)

**Business Description:**
A hidden developer-facing control on the form, which is not visible on the standard user screen, provides the ability to display the raw SQL query string that would be used for an extended warranty filter. This capability is a testing and debugging artifact left in the form code from the development phase; the debug message lines at the top of the trigger are commented out, and the active code only assigns the built SQL to a hidden text field. This has no effect on any user-facing screen or on the cross-sell/upsell data shown to end users.

**Actors:** Developer (testing artifact only - not visible to end users)

**Preconditions:**
- N/A - this capability serves no active business function.

**Main Flow:**

**Step 1 - SQL query string assembled and stored in hidden field**
When the hidden button is pressed, the system assembles a SQL query string using the current filter values and assigns it to a hidden text field for inspection. Debug message calls at the beginning of the trigger are commented out and do not execute. No data is displayed to the user and no on-screen results are affected.

---

---

#### Requirement ID: BR-020

**Requirement Title:** Message Interception (COMMENTED OUT / INACTIVE - does not execute)

**Business Description:**
A form-level message handler was originally designed to intercept certain application messages (error codes 40209 and 40207) and display them in a formatted alert. This handler was disabled during the prototype phase of development and replaced with no-op code. It currently executes a null statement only and has no effect on user-visible messages. All active message and error handling is performed instead by the active error handler documented in BR-012.

**Actors:** N/A - this trigger does not execute.

**Preconditions:**
- N/A - trigger body is null; does not execute.

**Main Flow:**

**Step 1 - (COMMENTED OUT / INACTIVE - does not execute)**
The trigger body consists of a single null statement. The original logic (display error type, number, and text for codes 40209 and 40207) is entirely commented out and does not run.

---

---

#### Requirement ID: BR-021

**Requirement Title:** Form Save Action (COMMENTED OUT / INACTIVE - does not execute)

**Business Description:**
A form-level save key handler was originally designed to validate the form, commit all changes, and then clear the form. This handler was disabled during the prototype phase and replaced with a null statement. It does not execute; no save or commit action is performed when the keyboard save shortcut is used on this form.

**Actors:** N/A - this trigger does not execute.

**Preconditions:**
- N/A - trigger body is null; does not execute.

**Main Flow:**

**Step 1 - (COMMENTED OUT / INACTIVE - does not execute)**
The trigger body executes only a null statement. The original logic (ENTER, COMMIT_FORM, CLEAR_FORM with form failure checks between each) is entirely commented out and does not run.

---

---

## 5. Business Rules Catalogue

| Rule ID | Rule Name | Rule Type | Business Requirement ID | Condition | Action | Business Impact |
| ------- | --------- | --------- | ----------------------- | --------- | ------ | --------------- |
| BRC-001 | Job card opening from date is mandatory | Validation | BR-002 | The job card opening start date field is left blank when the user moves off it | Block the field exit and display *"From Date can not be empty"* | Prevents the search from being run without a valid date range start; ensures a bounded query is always issued |
| BRC-002 | Job card opening from date must not be in the future | Validation | BR-002 | The job card opening start date entered is after today's date | Block the field exit and display *"From Date cannot be greater than Current Date"* | Prevents selecting dates for which no workshop visit data can yet exist, avoiding empty or misleading results |
| BRC-003 | Job card opening from date must not exceed the to date | Validation | BR-002 | The job card opening start date is later than the already-entered end date | Block the field exit and display *"From Date cannot be greater than To Date"* | Ensures the date range is logically ordered; an inverted range would produce no results |
| BRC-004 | Job card opening to date automatically derived from from date | Derivation | BR-002 | A valid job card opening start date has been entered and all checks passed | Set the end date to one calendar month after the start date, capped at today if the derived date is in the future | Provides a sensible default end date without requiring extra user input, while ensuring the range never exceeds one month |
| BRC-005 | Job card opening to date is mandatory | Validation | BR-003 | The job card opening end date field is left blank when the user moves off it | Block the field exit and display *"To Date can not be empty"* | Ensures the search range always has a closed upper bound |
| BRC-006 | Job card opening from date must be entered before to date | Validation | BR-003 | The user enters an end date but no start date has been provided | Block the field exit and display *"To date cannot be entered without entering From date"* | Enforces logical dependency: a range cannot have an end without a start |
| BRC-007 | Job card opening to date must not be earlier than from date | Validation | BR-003 | The entered end date is earlier than the start date | Block the field exit and display *"To Date cannot be lesser than From Date"* | Prevents an inverted date range that would return no results |
| BRC-008 | Job card opening date range must not exceed one calendar month | Validation | BR-003 | The difference between the start and end date exceeds one calendar month | Block the field exit and display *"Please give the date range of maximum one month"* | Limits query scope to prevent performance issues and excessive data retrieval |
| BRC-009 | Job card opening to date must not be in the future | Validation | BR-003 | The entered end date is after today's date | Block the field exit and display *"To Date cannot be greater than Current Date"* | Ensures the search range only covers dates for which records can exist |
| BRC-010 | Vehicle sale from date is mandatory | Validation | BR-004 | The vehicle sale start date field is left blank when the user moves off it | Block the field exit and display *"Sales From Date can not be empty"* | Ensures the vehicle sale date filter always has a lower bound |
| BRC-011 | Vehicle sale from date must not be in the future | Validation | BR-004 | The sale start date entered is after today's date | Clear the sale end date and block the field exit, displaying *"Sales From Date cannot be greater than Current Date"* | Prevents selecting a future sale date for which no sold-vehicle records can exist |
| BRC-012 | Vehicle sale from date must not exceed the sale to date | Validation | BR-004 | The sale start date is later than the already-entered sale end date | Clear the sale end date and block the field exit, displaying *"Sales From Date cannot be greater than Sales To Date"* | Ensures the sale date range is logically ordered |
| BRC-013 | Vehicle sale to date is mandatory | Validation | BR-005 | The vehicle sale end date field is left blank when the user moves off it | Block the field exit and display *"Sales To Date can not be empty"* | Ensures the vehicle sale date filter always has an upper bound |
| BRC-014 | Vehicle sale from date must be entered before sale to date | Validation | BR-005 | The user enters a sale end date but no sale start date has been provided | Block the field exit and display *"Sales To date cannot be entered without entering Sales From date"* | Enforces logical dependency: the sale date range must have a start before an end is accepted |
| BRC-015 | Vehicle sale to date must not be earlier than sale from date | Validation | BR-005 | The entered sale end date is earlier than the sale start date | Block the field exit and display *"Sales To Date cannot be lesser than Sales From Date"* | Prevents an inverted sale date range |
| BRC-016 | Vehicle sale to date must not be in the future | Validation | BR-005 | The sale end date entered is after today's date | Block the field exit and display *"Sales To Date cannot be greater than Current Date"* | Ensures the sale date filter covers only dates with actual sales data |
| BRC-017 | Odometer from value must not exceed odometer to value (from side) | Validation | BR-006 | The lower odometer limit entered is greater than the upper limit already on screen | Clear the upper limit and block the field exit, displaying *"From Odometer can not greater than To Odometer"* | Prevents an inverted odometer range that would match no records |
| BRC-018 | Odometer from value must not exceed odometer to value (to side) | Validation | BR-007 | The lower odometer limit already entered is greater than the newly entered upper limit | Clear the upper limit and block the field exit, displaying *"From Odometer can not greater than To Odometer"* | Consistent cross-check applied when the upper limit is entered, mirroring BRC-017 |
| BRC-019 | Referential integrity violation must show a controlled error | Validation | BR-012 | A database referential integrity constraint is violated during any form operation | Display the predefined application error message for code E0088 via the error library; abort the current operation | Prevents raw Oracle constraint errors from reaching the user; provides a business-readable explanation |
| BRC-020 | Record concurrently updated by another user must trigger rollback and notification | Validation | BR-012 | A form operation detects that the record has already been changed by a different user session | Roll back uncommitted changes, display *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*, and abort the operation | Prevents silent data overwrite from concurrent edits; instructs the user to re-query before retrying |
| BRC-021 | Search must return no deleted job card records | Constraint | BR-010 | A job card record has status code 20 | Exclude the record from results | Ensures closed/deleted job cards are never included in the cross-sell/upsell candidate list |
| BRC-022 | Phone numbers in cross-sell results must be masked | Constraint | BR-010, BR-011 | A customer contact record contains a phone number | Display only the last four digits; replace all preceding digits with 'X' | Protects customer personal contact data in compliance with data privacy requirements |
| BRC-023 | Extended warranty type description must be human-readable in results | Derivation | BR-010 | A result row has an extended warranty type code that is not blank | Look up the warranty type description from the reference list and display the description rather than the code | Ensures the user sees a meaningful warranty type label rather than an internal code |
| BRC-024 | Results with no extended warranty must show a fixed label | Derivation | BR-010 | A result row has no extended warranty type (null warranty code) | Set the extended warranty type display to the fixed text "No Ext Warranty" | Makes the absence of an extended warranty explicit and consistent across all result rows |
| BRC-025 | Export file row count must not exceed spreadsheet limit | Constraint | BR-011 | The number of records returned by the export query exceeds 65,535 | Truncate the export to 65,535 data rows and display *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."* | Prevents the CSV file from containing more rows than can be displayed in a standard spreadsheet |
| BRC-026 | Previous results must be cleared when any filter is changed | Constraint | BR-008, BR-009, BR-014 | The user changes or leaves any search filter field (status, location, model, variant, odometer, extended warranty) | Clear all displayed result rows and reset the result count to null/zero immediately | Ensures on-screen results always correspond to the current filter settings; prevents misreading old data as new |

**Total Business Rules Identified: 26**

---

## 6. Data Requirements

*This section covers the cross-sell and upsell report form's data entities (job card and vehicle/customer data read from the dealer management system), the search criteria captured from the user, the reference data used for filter dropdowns and code resolution, and the form's read-only data lifecycle.*

### 6.1 Business Entities and Relationships

*The form queries workshop job card records joined to vehicle, customer, and extended warranty data. No records are created or updated by this form - all data is read-only display.*

#### Workshop Job Card - VH_RO (via CROSS_SELL_UPSELL)

The workshop job card record is the primary data object driving this form. It holds the vehicle registration number, VIN, workshop visit date, odometer reading, job card status, and the location and dealer codes that identify which workshop the vehicle visited. The form uses job card records as the entry point for identifying customers who have recently brought a vehicle in for service, making them candidates for cross-sell and upsell outreach.

#### Vehicle Master - GM_VIN (via CROSS_SELL_UPSELL)

The vehicle master record links a VIN to its model, variant, and invoice (sale) date. This form uses it to retrieve the model code and variant code for description resolution, the vehicle sale date to calculate vehicle age, and to apply the model, variant, and sale date range filters.

#### Customer Master - GM_CIN (via CROSS_SELL_UPSELL)

The customer master holds the customer's name, contact phone numbers, address details, and communication preference. This form reads customer data to display the customer name and masked phone numbers, and passes the customer code to the address resolution function. The customer record is joined to job cards via the customer code.

#### Extended Warranty Master - MWAR_EXTE (via CROSS_SELL_UPSELL)

The extended warranty master records which vehicles hold an active extended warranty and of what type. This form uses it as an optional join to filter the cross-sell candidate list by extended warranty status and to retrieve the raw warranty type code for display.

#### Entity Relationships

The cross-sell and upsell report form queries workshop job cards as its primary driver. Each job card is linked to a vehicle master record (by VIN) and to a customer record (by customer code). The vehicle master is also joined to the model master to apply model family filtering. The extended warranty master is optionally joined to the vehicle master by VIN when an extended warranty filter is applied.

```
VH_RO (Workshop Job Card)
    ├── GM_VIN (Vehicle Master)     <- joined by VIN
    │       └── GM_MOD (Model Master)   <- joined by MODEL_CD, used for model family filter
    ├── GM_CIN (Customer Master)    <- joined by CUST_CD
    └── MWAR_EXTE (Extended Warranty) <- optional outer join by VIN, filtered by cancellation flag
```

### 6.2 Data Capture Requirements

*The form captures search criteria entered by the user (date ranges, location, model, variant, odometer, status filters) and displays the resulting customer and vehicle data in read-only format. No records are saved or committed by this form.*

#### Search Criteria (User - before running the report)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Workshop (`CB_LOC_DESC`) | Yes | The workshop location the user selects to scope the search. The underlying dealer map code and location code are stored in hidden fields. | Must be selected from the available location lookup list; populated via the location record group |
| JC Opening From Date (`P_FROM_DATE`) | Yes | The start date of the job card opening date range for the search | Must be provided; must not be after today; must not be later than the To Date if already entered; auto-derives the To Date on successful entry |
| JC Opening To Date (`P_TO_DATE`) | Yes | The end date of the job card opening date range. Auto-populated when the From Date is entered. | Must be provided; must not be earlier than the From Date; must not be after today; range must not exceed one calendar month |
| Model (`P_MODEL_DESC`) | No | Vehicle model family description selected from the lookup list. The underlying model code is stored in a hidden field. | Optional; if not selected, all models are included; populated via the model lookup list |
| Variant (`P_VARIANT_DESC`) | No | Vehicle variant description selected from the lookup list. The underlying variant code is stored in a hidden field. | Optional; if not selected, all variants are included; list is filtered by the selected model code |
| Vehicle Sale From Date (`P_SALE_FROM_DATE`) | Yes | The start date of the vehicle sale (invoice) date range for the search | Must be provided; must not be after today; must not be later than the Sale To Date if already entered |
| Vehicle Sale To Date (`P_SALE_TO_DATE`) | Yes | The end date of the vehicle sale (invoice) date range | Must be provided; Sale From Date must be entered first; must not be earlier than the Sale From Date; must not be after today |
| Odometer From (`P_ODOMETER_FROM`) | No | Lower odometer reading bound for filtering results | Optional; if entered, must not exceed the Odometer To value |
| Odometer To (`P_ODOMETER_TO`) | No | Upper odometer reading bound for filtering results | Optional; if entered, the Odometer From must not exceed it |
| Job Card Status (`P_JC_STATUS1`) | No | Selected job card status from the status dropdown list | Optional; defaults to showing all statuses when 'ALL' is selected; list is populated from the job card status reference data |
| Extended Warranty Status (`P_EW_STATUS`) | No | Selected extended warranty status filter from the dropdown list | Optional; controls which of three query paths is used (all records, specific warranty type, or no warranty); list is populated from the extended warranty type reference data |

#### Results Display (System - after View is pressed)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Reg No (`REG_NUM`) | Auto-Populated | Vehicle registration number from the job card | Read-only; populated from query results |
| Vin No. (`VIN`) | Auto-Populated | Vehicle identification number from the job card | Read-only; populated from query results |
| Customer Name (`CUST_NAME`) | Auto-Populated | Customer title and full name assembled from the customer master | Read-only; populated from query results |
| Mobile (`MOBILE_PHONE`) | Auto-Populated | Customer mobile phone number - masked to show only the last four digits | Read-only; all digits except the last four are replaced with 'X' for privacy |
| Residance Phone (`RES_PHONE`) | Auto-Populated | Customer residential phone number - masked to show only the last four digits | Read-only; all digits except the last four are replaced with 'X' for privacy |
| Office Phone (`OFFICE_PHONE`) | Auto-Populated | Customer office/work phone number - masked to show only the last four digits | Read-only; all digits except the last four are replaced with 'X' for privacy |
| Address (`ADDRESS`) | Auto-Populated | Customer's full postal address assembled by the address resolution function from the customer master | Read-only; office address used when customer prefers office communications; otherwise permanent address; null if no record found |
| Model (`MODEL`) | Auto-Populated | Vehicle model description resolved from the model master | Read-only; "Not Found" displayed if the model code cannot be resolved |
| Variant (`VARIANT`) | Auto-Populated | Vehicle variant description resolved from the variant master | Read-only; "Not Found" displayed if the variant code cannot be resolved |
| JC Open Date (`WRS_VISIT_DATE`) | Auto-Populated | Job card opening date and time formatted as DD-MON-YYYY HH24:MI | Read-only; derived from the job card opening date |
| Vehicle Age (Yrs.) (`SALE_DATE`) | Auto-Populated | Number of years since the vehicle was sold, calculated from the invoice date | Read-only; calculated by the vehicle age function |
| Mileage (`MILEAGE`) | Auto-Populated | Vehicle odometer reading recorded at the workshop visit | Read-only; taken from the job card |
| EW Type (`EW_TYPE`) | Auto-Populated | Extended warranty type description; "No Ext Warranty" where none applies | Read-only; resolved from the extended warranty type reference list, or assigned the fixed label "No Ext Warranty" when no active warranty exists |
| Total (`COUNT_ROW`) | Auto-Populated | Total number of result rows retrieved by the current search | Read-only; set to null when any filter field changes; populated after the View query completes |

#### Parameters and Session Data

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Application ID (`P_APP_ID`) | No | Application identifier parameter passed at form startup | Not displayed; passed via form parameter; referenced in the commented-out alternate export call |

### 6.3 Reference Data

*Lists the master and configuration data referenced by this form for filter dropdowns, code resolution, and location scoping.*

| Reference Data | Business Purpose | Used When |
| :--- | :--- | :--- |
| Workshop/Location list (`LOV_LOC` / `RG_LOC` - AM_USER_DEALER_MASTER joined to AM_DEALER_LOC) | Provides the list of active workshop locations the user can select to scope the cross-sell search; filtered by the current user's login, dealer type 'SERVICE', and location types '2S'/'3S' for the current principal | When the user opens the workshop location field or invokes the lookup list |
| Model Family list (`LOV_MOD` / `RG_MOD` - MULDMS.GM_MOD) | Provides the list of available vehicle model families for the model filter; includes an 'ALL Models' option as the first entry; filtered by the current principal | When the user opens the model field or invokes the model lookup list |
| Variant list (`LOV_VARIANT` / `RG_VARIANT` - MULDMS.GM_VAR joined to MULDMS.GM_MOD) | Provides the list of vehicle variants for the variant filter; filtered by the selected model family code and the current principal | When the user opens the variant field or invokes the variant lookup list; dependent on the selected model |
| Job Card Status reference (AM_LIST where LIST_NAME = 'RO_STATUS1') | Provides the available job card status codes and descriptions for the status filter dropdown; excludes status code 20; includes an 'ALL' option; filtered by the current principal | When the form initialises the job card status dropdown |
| Extended Warranty Type reference (AM_LIST where LIST_NAME = 'EXTE_WARR_TYPE') | Provides the extended warranty type codes and descriptions for the warranty filter dropdown; includes 'ALL' and 'No Ext Warranty' options; filtered by the current principal | When the form initialises the extended warranty status dropdown, and when warranty type descriptions are resolved for individual result rows |
| Customer master (GM_CIN) | EXTERNAL / NOT IN BUNDLE - provides the customer name, contact phone numbers, address details, and communication preference used to build the results display | When the View button is pressed and the cross-sell query runs |
| Vehicle model master (GM_MOD) | EXTERNAL / NOT IN BUNDLE - used to resolve family model codes to model families for the model filter in the search query | When the View button or Export button is pressed |
| Vehicle variant master (GM_VAR) | EXTERNAL / NOT IN BUNDLE - used by the variant description resolution function to translate variant codes to descriptions | When the View button or Export button is pressed |
| City reference (GM_CITY) | EXTERNAL / NOT IN BUNDLE - used by the customer address resolution function to look up city descriptions from city codes | When the customer address is assembled for a result row |
| County/District reference (GM_CNTY) | EXTERNAL / NOT IN BUNDLE - used by the customer address resolution function to look up county/district descriptions | When the customer address is assembled for a result row |
| State reference (GM_STATE) | EXTERNAL / NOT IN BUNDLE - used by the customer address resolution function to look up state descriptions | When the customer address is assembled for a result row |

### 6.4 Data Lifecycle

*The cross-sell and upsell report form is read-only. It queries existing records from the dealer management system but does not create, update, or delete any records.*

**Creation**

- No records are created by this form. The form reads existing workshop job cards, vehicle master, customer, and extended warranty records from the dealer management system.

**Updates**

- No records are updated by this form. All displayed data is read-only; the results grid is set to read-only after population and cannot be edited by the user.

**Save and Commit**

- No save or commit action is performed by this form. The form does not have an active save capability; the keyboard save shortcut is commented out and executes a null statement only (see BR-021).

**Retention and Audit**

- No creation, modification, or audit timestamps are written by this form. The source records queried (job cards, vehicle master, customer master) may carry their own timestamps from the systems that created them, but this form does not interact with those fields.

---

### 6.5 Excel Output Columns

This form does not use Excel download. No Excel export columns were identified in the form sources.

## 7. Glossary

*Definitions of terms, abbreviations, and acronyms used throughout this document.*

The following table defines key terms, acronyms, and abbreviations used throughout this Business Requirements Document.

| Term | Definition | Aliases | Related Terms |
| :--- | :--- | :--- | :--- |
| AM_LIST | Application master list table - stores lookup codes and descriptions for configurable dropdown values such as RO status and extended warranty types | Lookup List | RO Status, EW Type |
| BTN_VIEW | View/Search button on the vr_cross form that triggers the cross-sell/upsell data retrieval | Search Button | Cross-Sell Search |
| CB_DUMMY | Control block on the vr_cross form that holds all search filter parameters and display items without being bound to a database table | Control Block | Filter Parameters |
| Cross-Sell | Sales activity involving the offer of additional products or services to an existing workshop customer based on their visit and vehicle history | - | Upsell, Opportunity |
| CSV | Comma-Separated Values - a plain-text file format used to export the cross-sell results grid for offline analysis and outreach | Comma-Separated Values | Excel Export, PB_EXCEL |
| CROSS_SELL_UPSELL | Results display block on the vr_cross form that shows matching vehicle and customer records in a read-only multi-row grid | Results Grid | vr_cross |
| DMS | Dealer Management System - integrated software platform for automotive dealer operations including sales, service, and parts management | - | Workshop, RO |
| DPL | Shared program library (DPL.pld) attached to the vr_cross form, providing common utility procedures such as DISP_TEXT and RAISE_ERROR | DPL.pld | GENERAL, PLD |
| EW | Extended Warranty - an optional service contract that extends the manufacturer warranty period for a vehicle | Extended Warranty | MWAR_EXTE, NOEW |
| EW_TYPE | Extended warranty type code displayed in the results grid, indicating the category of extended warranty held for the vehicle | Extended Warranty Type | AM_LIST, MWAR_EXTE |
| GM_CIN | Customer information master table - stores customer names, contact numbers, and principal mappings | Customer Master | VH_RO |
| GM_MOD | Vehicle model master table - stores vehicle model codes and descriptions for a principal | Model Master | GM_VAR, Principal |
| GM_VIN | Vehicle identification master table - stores VIN, model, variant, and invoice date per vehicle | VIN Master | VH_RO, Invoice Date |
| GM_VAR | Vehicle variant master table - stores variant codes and descriptions linked to model codes | Variant Master | GM_MOD, Principal |
| LOV | List of Values - a popup selection list that allows the user to look up and select valid values for a field | Dropdown, Picklist | RG_LOC, RG_MOD, RG_VARIANT |
| MWAR_EXTE | Extended warranty details table - stores active extended warranty records linked to vehicle VINs | - | EW, EW_TYPE |
| NOEW | Code value used in the extended warranty filter to select vehicles with no active extended warranty | No Ext Warranty | EW, MWAR_EXTE |
| PB_EXCEL | Export to Excel button on the vr_cross form that initiates CSV file generation and download | Export Button | CSV, VIEW_EXCEL_REP |
| PLD | Program Library Definition - a compiled Oracle Forms shared library (e.g. DPL.pld) containing reusable procedures and functions | Program Library | DPL, GENERAL |
| Principal | Manufacturer or principal organisation identifier (PRINCIPAL_MAP_CD) used to scope all model, variant, and lookup data to the correct manufacturer | PRINCIPAL_MAP_CD | GM_MOD, AM_LIST |
| RO | Repair Order - the primary workshop transaction document raised for each vehicle service visit | Job Card | VH_RO, RO Status |
| RO Status | Status code of a repair order (e.g. open, closed, cancelled) used as a filter criterion on the cross-sell search | Job Card Status | RO, AM_LIST |
| Upsell | Sales activity involving the promotion of a higher-value or upgraded product or service to an existing workshop customer | - | Cross-Sell, Opportunity |
| VH_RO | Vehicle repair order table - stores workshop visit records including RO date, odometer reading, and RO status | Workshop Visit | RO, GM_VIN |
| VIN | Vehicle Identification Number - a unique alphanumeric code assigned to each vehicle | Chassis Number | GM_VIN, VH_RO |
| vr_cross | Oracle Forms module - the Cross-Sell and Upsell Opportunity screen within the DMS | VR_CROSS | Cross-Sell, DMS |
| WEBUTIL | Oracle Forms WebUtil integration library enabling browser-based file operations and Java interoperability | WebUtil | DPL, WEBUTIL |

---

---

## 8. Technical Inventory

*Complete inventory of Oracle Forms components including blocks, items, triggers, canvases, and global variables.*

### 8.1 Form Architecture

**Form Module Details:**

- Form Name: vr_cross (VR_CROSS)
- Form Module XML Title: MODULE4
- Oracle Forms Version: 12c (Module version 122010400); Runtime compatibility: 5.0
- Parent Object Library: DPL.olb (PC_FORM property class)
- Attached Libraries: WEBUTIL (webutil.olb), DMS_EXCEL_REPORT, DPL (DPL.pld program library), D2KWUTIL
- First Navigation Block: -
- Console Window: WN_MAIN - Workshop Database (Rel : 1.1.3)
- Compile Dependencies: Requires DPL.olb, DPL.pld, WEBUTIL.olb, menu.mmx
- Source artifacts: `vr_cross_fmb.xml`; OLB `DPL.olb`; WEBUTIL (webutil.olb); DMS_EXCEL_REPORT; DPL (DPL.pld program library); D2KWUTIL

### 8.1.1 Global Variables

| Global Variable | Data Type | Set Location | Purpose |
| :--- | :--- | :--- | :--- |
| APP_ID | Char | Trigger | Application identifier propagated into session context at form startup; complements the P_APP_ID parameter |
| COMP_FA | Char | Trigger | Company/financial-authority code used to scope session-level access control |
| DEALER | Char | Trigger | Dealer mapping code for the current session, used to scope workshop data queries |
| EXIT_FLAG | Char | Trigger | Exit navigation flag set to 'EXIT' when user presses the close/exit button |
| LOC_CD | Char | Trigger | Location code for the current dealer location, used to filter workshop records |
| PARENT_GROUP | Char | ProgramUnit / Trigger | Parent group identifier for the dealer hierarchy, passed to database queries |
| PRINCIPAL | Char | ProgramUnit / RecordGroup / Trigger | Principal manufacturer code used to filter model, variant, and warranty data |
| USERID | Char | ProgramUnit / RecordGroup / Trigger | Logged-in user ID used for location access control and Excel report file naming |

### 8.1.2 Form Parameters

*All 1 ModuleParameter entries from vr_cross_fmb.xml.*

| Parameter | Data Type | Default | Description |
| :--- | :--- | :--- | :--- |
| P_APP_ID | Char | - | Application identifier passed at form startup; reserved for session context - not used in current active form logic |

**Total Parameters:** 1

### 8.2 Blocks

| Block Name | Query Data Source | Records | Q/I/U/D | Key Mode | Master-Detail Relationship |
| :--- | :--- | :--- | :--- | :--- | :--- |
| CB_DUMMY | - | 1 | N/N/N/N | Default | Control - entry point for search criteria and filter parameters |
| CROSS_SELL_UPSELL | - | 15 | N/N/N/N | Delayed | - |
| PB_BLK | - | 1 | N/N/N/N | Default | - |

**Total Blocks:** 3 business blocks

### 8.2.1 Block WhereClause and OrderByClause

*Block query scope from vr_cross_fmb.xml. **Description** explains filter and sort in business terms; **Order By** and **Where Clause** columns retain verbatim XML text for migration.*

| Block | Description | Order By (XML) | Where Clause (XML) |
| :--- | :--- | :--- | :--- |
| - | No blocks with WhereClause/OrderByClause in vr_cross_fmb.xml | - | - |

### 8.3 Items Summary

*Complete item inventory from `vr_cross_fmb.xml`.*

**Block counts:**

*Database / non-database counts derived from XML.*

| Block | Total Items | Database Items | Non-Database Items |
| :--- | ---: | ---: | ---: |
| CB_DUMMY | 23 | 0 | 23 |
| CROSS_SELL_UPSELL | 13 | 0 | 13 |
| PB_BLK | 15 | 0 | 15 |
| CB_ERR | 1 | 0 | 1 |
| WEBUTIL | 9 | 0 | 9 |
| **Total** | **61** | **0** | **61** |

**Item detail (all 61 items):**

| Block | Item Name | DatabaseItem | Description |
| :--- | :--- | :--- | :--- |
| CB_DUMMY | CB_LOC_DESC | false | Location description display field for the selected dealer location |
| CB_DUMMY | P_FROM_DATE | false | Workshop visit from-date filter parameter (DD-MON-RRRR format) |
| CB_DUMMY | P_TO_DATE | false | Workshop visit to-date filter parameter (DD-MON-RRRR format) |
| CB_DUMMY | P_MODEL_DESC | false | Vehicle model description filter parameter populated via LOV |
| CB_DUMMY | P_VARIANT_DESC | false | Vehicle variant description filter parameter populated via LOV |
| CB_DUMMY | P_SALE_FROM_DATE | false | Vehicle sale from-date filter parameter (DD-MON-RRRR format) |
| CB_DUMMY | P_SALE_TO_DATE | false | Vehicle sale to-date filter parameter (DD-MON-RRRR format) |
| CB_DUMMY | P_ODOMETER_FROM | false | Lower odometer reading filter for cross-sell/upsell search |
| CB_DUMMY | P_ODOMETER_TO | false | Upper odometer reading filter for cross-sell/upsell search |
| CB_DUMMY | P_JC_STATUS1 | false | Job card (RO) status filter dropdown list |
| CB_DUMMY | P_EW_STATUS | false | Extended warranty status filter dropdown list |
| CB_DUMMY | BTN_VIEW | false | Executes search and populates the cross-sell/upsell results grid |
| CB_DUMMY | PB_EXCEL | false | Exports the current result set to an Excel (CSV) file |
| CB_DUMMY | CB_DEALER_MAP_CD | false | Dealer mapping code (internal) returned from Location LOV |
| CB_DUMMY | CB_LOC_CD | false | Location code (internal) returned from Location LOV |
| CB_DUMMY | CB_VARIANT_DESC | false | Variant description display field returned from Model LOV |
| CB_DUMMY | CB_MODEL | false | Model code (internal) returned from Model LOV |
| CB_DUMMY | P_MODEL_CD | false | Model code (internal) filter value used in cross-sell query |
| CB_DUMMY | P_VARIANT_CD | false | Variant code (internal) filter value used in cross-sell query |
| CB_DUMMY | PUSH_BUTTON535 | false | Diagnostic button that assembles the current filter criteria into a SQL query string and stores it in the TXT field for inspection |
| CB_DUMMY | TXT | false | Internal text display area used for SQL query string storage |
| CB_DUMMY | COPYRIGHT_DECLARATION | false | Static copyright/declaration label displayed on the form |
| CB_DUMMY | COUNT_ROW | false | Row counter displaying the number of records retrieved by the search |
| CROSS_SELL_UPSELL | EW_TYPE | false | Extended warranty type description for the retrieved vehicle |
| CROSS_SELL_UPSELL | REG_NUM | false | Vehicle registration number |
| CROSS_SELL_UPSELL | VIN | false | Vehicle Identification Number (VIN/chassis number) |
| CROSS_SELL_UPSELL | CUST_NAME | false | Customer full name with title |
| CROSS_SELL_UPSELL | MOBILE_PHONE | false | Customer mobile phone number (masked for privacy) |
| CROSS_SELL_UPSELL | ADDRESS | false | Customer address retrieved via function call |
| CROSS_SELL_UPSELL | MODEL | false | Vehicle model description |
| CROSS_SELL_UPSELL | VARIANT | false | Vehicle variant description |
| CROSS_SELL_UPSELL | WRS_VISIT_DATE | false | Workshop visit (RO) date and time |
| CROSS_SELL_UPSELL | SALE_DATE | false | Vehicle age in years (calculated from invoice date) |
| CROSS_SELL_UPSELL | MILEAGE | false | Vehicle odometer reading at time of workshop visit |
| CROSS_SELL_UPSELL | RES_PHONE | false | Customer residential phone number (masked for privacy) |
| CROSS_SELL_UPSELL | OFFICE_PHONE | false | Customer office/work phone number (masked for privacy) |
| PB_BLK | PB_EXIT | false | Exits the form (inherited from DPL object group) |
| PB_BLK | PB_LIST | false | Executes the inherited FT_LIST trigger |
| PB_BLK | PB_INSERT | false | Executes the inherited FT_INSERT trigger |
| PB_BLK | PM_CONT | false | Continue/navigation button |
| PB_BLK | PB_DEL | false | Executes the inherited FT_DEL trigger |
| PB_BLK | PB_CANCEL | false | Executes the inherited FT_CANCEL trigger |
| PB_BLK | PB_SAVE | false | Executes the inherited FT_SAVE trigger |
| PB_BLK | PB_PRINT | false | Executes the inherited FT_PRINT trigger |
| PB_BLK | PB_CUT | false | Cuts selected text/region |
| PB_BLK | PB_COPY | false | Copies selected text/region |
| PB_BLK | PB_PASTE | false | Pastes from clipboard |
| PB_BLK | PB_ERR_EXIT | false | Error exit button |
| PB_BLK | NB_EXIT | false | Sets exit flag and exits the form without validation |
| PB_BLK | NB_CLEAR | false | Clears the results block and control block without validation |
| PB_BLK | NB_OK | false | Exits the form without validation |
| CB_ERR | TXT_ERR | false | Error message text display field on the inherited CN_ERR error canvas; populated at runtime when an error condition is raised and the WIN_ERR window is shown |
| WEBUTIL | DUMMY | false | WebUtil button placeholder - subclassed item from the WEBUTIL object group; carries an inactive WHEN-BUTTON-PRESSED trigger with an empty body; no business logic executed |
| WEBUTIL | WEBUTIL_CLIENTINFO_FUNCTIONS | false | Subclassed WebUtil bean area providing client machine information functions (OS, hostname, etc.) via the WebUtil library; no form-specific business logic |
| WEBUTIL | WEBUTIL_FILE_FUNCTIONS | false | Subclassed WebUtil bean area providing client-side file system access functions via the WebUtil library; used indirectly by file transfer and CSV export operations |
| WEBUTIL | WEBUTIL_HOST_FUNCTIONS | false | Subclassed WebUtil bean area providing host command execution functions on the client machine via the WebUtil library |
| WEBUTIL | WEBUTIL_SESSION_FUNCTIONS | false | Subclassed WebUtil bean area providing session-level utility functions via the WebUtil library |
| WEBUTIL | WEBUTIL_FILETRANSFER_FUNCTIONS | false | Subclassed WebUtil bean area providing file upload/download transfer functions between client and server via the WebUtil library; supports the CSV export download flow |
| WEBUTIL | WEBUTIL_OLE_FUNCTIONS | false | Subclassed WebUtil bean area providing OLE automation functions on the client machine via the WebUtil library |
| WEBUTIL | WEBUTIL_C_API_FUNCTIONS | false | Subclassed WebUtil bean area providing access to client-side C API calls via the WebUtil library |
| WEBUTIL | WEBUTIL_BROWSER_FUNCTIONS | false | Subclassed WebUtil bean area providing browser control functions (e.g. WEB.SHOW_DOCUMENT) via the WebUtil library; used by VIEW_EXCEL_REP to open the generated CSV URL |

### 8.4 List of Values

| LOV Name | Title | Record Group | Attached Block.Item |
| :--- | :--- | :--- | :--- |
| LOV_VARIANT | - | RG_VARIANT | CB_DUMMY.P_VARIANT_DESC |
| LOV_LOC | Location Details | RG_LOC | CB_DUMMY.CB_LOC_DESC, CB_DUMMY.CB_DEALER_MAP_CD |
| LOV_MOD | Model Code | RG_MOD | CB_DUMMY.P_MODEL_DESC, CB_DUMMY.CB_VARIANT_DESC |

**Total LOVs:** 3

### 8.5 Alerts

| Alert Name | Title | Message Text | Calling Context |
| :--- | :--- | :--- | :--- |
| WEBUTIL_ERROR | Forms | (set at runtime) | Trigger: ON-ERROR in Form (inherited from WEBUTIL object group); displayed when a WebUtil operation fails |
| AL_ERRINFO | Error | (set at runtime) | Inherited from DPL object group; displayed by GENERAL.DISP_TEXT when an error-level message is raised across form triggers and program units |
| AL_NOTE | Note | (set at runtime) | Inherited from DPL object group; displayed by GENERAL.DISP_TEXT when an informational note message is raised |
| AL_CONFIRM | Caution | (set at runtime) | Inherited from DPL object group; displayed by GENERAL.RAISE_ERROR for caution-level messages requiring user acknowledgement |
| AL_PRINT | Print | (set at runtime) | Inherited from DPL object group; displayed by ASK_PRINT to confirm a print or export action before execution |

**Total Alerts:** 5

### 8.6 Program Units

*Authoritative catalogue of **6 form-local program units**. Database packages and standalone procedures are in **Section 15.2**; PLD shared-library routines are in **Section 18**.*

| Program Unit | Type | Calls | Description |
| :--- | :--- | :--- | :--- |
| POPULATE_DETAILS | Procedure | GENERAL.DISP_TEXT | **COMMENTED OUT / INACTIVE** - Body executes NULL; formerly populated a legacy block (SI_PEN_BOK) with pending booking and delivery data from multiple cursors; entire business logic is block-commented |
| VIEW_EXCEL_REP | Procedure | TEXT_IO, WEB.SHOW_DOCUMENT, Create_Group_From_Query, Populate_Group, PROC_TIMER, PROC_TIMER_EXPIRED, ASK_PRINT | Generates and downloads a CSV report from a supplied SQL query by creating a runtime record group, writing rows to a server-side file, and opening the URL in the browser |
| CLEAR_ITEMS | Procedure | null | **COMMENTED OUT / INACTIVE** - Body executes NULL with semicolon syntax error; formerly cleared filter items |
| FROM_DATE_CHECK | Procedure | GENERAL.DISP_TEXT | **COMMENTED OUT / INACTIVE** - Body executes NULL; formerly validated that P_FROM_DATE is not null, not greater than current date, and not greater than P_TO_DATE, and auto-populated P_TO_DATE to end of month |
| TO_DATE_CHECK | Procedure | GENERAL.DISP_TEXT | **COMMENTED OUT / INACTIVE** - Body executes NULL; formerly validated that P_TO_DATE is not null, not less than P_FROM_DATE, not greater than current date, and within a one-month range |
| PROC_POP_LIST | Procedure | Create_Group_From_Query, Populate_Group, Populate_List, AM_LIST, CREATE_RECGRP_ROW, DROP_RECGRP | Populates the P_EW_STATUS and P_JC_STATUS1 dropdown lists dynamically from AM_LIST lookup table using the current principal code |

**Total Program Units:** 6

### 8.7 Triggers

**Item-Level Trigger Types (reference):**

| Trigger Name | Purpose |
| :--- | :--- |
| WHEN-VALIDATE-ITEM | Validates field when user leaves item |
| KEY-* | Keyboard actions - commit, exit, LOV, navigation |
| WHEN-NEW-BLOCK-INSTANCE | Initializes block on entry |
| WHEN-BUTTON-PRESSED | Executes button action |
| PRE-INSERT / POST-INSERT | Before/after record creation |
| WHEN-LIST-CHANGED | Dropdown selection changed |
| PRE-QUERY / POST-QUERY | Before/after query execution |
| WHEN-CHECKBOX-CHANGED | Checkbox toggled |
| WHEN-VALIDATE-RECORD | Validates entire record before leaving row |

**DPL library routines invoked from triggers and program units:**

| Routine | Type | Called From | Purpose |
| :--- | :--- | :--- | :--- |
| GENERAL.DISP_TEXT | Library routine | CB_DUMMY.PB_EXCEL (WHEN-BUTTON-PRESSED), CB_DUMMY.P_FROM_DATE (WHEN-VALIDATE-ITEM), CB_DUMMY.P_SALE_FROM_DATE (WHEN-VALIDATE-ITEM), CB_DUMMY.P_SALE_TO_DATE (WHEN-VALIDATE-ITEM), CB_DUMMY.P_TO_DATE (WHEN-VALIDATE-ITEM), Form level (ON-ERROR), ProgramUnit: FROM_DATE_CHECK, ProgramUnit: POPULATE_DETAILS, ProgramUnit: TO_DATE_CHECK | Displays an alert dialog with a specified message and title (Error or Note) using AL_ERRINFO or AL_NOTE |
| GENERAL.RAISE_ERROR | Library routine | Form level (ON-ERROR) | Retrieves an error message by code and displays it as an error, note, or caution dialog |
| ASK_PRINT | Function | ProgramUnit: VIEW_EXCEL_REP | Prompts the user to confirm a print or export action before execution |
| CHECK_DATE | Procedure | Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.P_FROM_DATE, Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.P_TO_DATE | Validates that a date field does not contain a value greater than today's date |
| CHECK_FORM_FAILURE | Procedure | Trigger: KEY-COMMIT in Form | **COMMENTED OUT / INACTIVE** - Formerly checked form success after commit and raised an error if the last operation failed |
| CHECK_NULL | Procedure | Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.P_FROM_DATE | Raises a form failure if a required field is left empty, displaying the column title in the error message |
| CREATE_RECGRP_ROW | Procedure | ProgramUnit: PROC_POP_LIST | Creates a new row in a runtime record group during dynamic list population |
| DROP_RECGRP | Procedure | ProgramUnit: PROC_POP_LIST | Drops an existing runtime record group before re-creating it |
| DUP_REC_CHECK | Function | Trigger: WHEN-VALIDATE-ITEM in CROSS_SELL_UPSELL | Checks for duplicate records within the current block to prevent data duplication |
| EXC_QUERY | Procedure | Trigger: WHEN-BUTTON-PRESSED in CB_DUMMY.BTN_VIEW | Executes a query against a block after search criteria are set |
| PROC_REPORT_CALL | Procedure | Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_PRINT | Invokes the report server to generate and deliver a report |
| PROC_TIMER | Procedure | ProgramUnit: VIEW_EXCEL_REP | Creates a timer for asynchronous processing during Excel export |
| PROC_TIMER_EXPIRED | Procedure | ProgramUnit: VIEW_EXCEL_REP | Handles timer expiry events during asynchronous Excel export |
| RUN_REPORT | Procedure | Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_PRINT | Submits a report job to the Oracle Reports server and monitors completion |

### 8.7.1 Inactive / Commented-Out Trigger Register

*Triggers and field validations where XML source is `null;`, fully block-commented, or legacy code preserved but not executed. Do **not** migrate these as active business requirements.*

| Status | Block | Item | Trigger | Former behaviour (preserved in comments) | Disabled since / note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| INACTIVE - no-op (null only) | Form | - | KEY-COMMIT | Formerly executed enter, committed the form, checked form failure, and cleared the form after a successful commit | Commented out by sanjeev on 7-May-04 for prototype; body executes null only |
| INACTIVE - no-op (null only) | Form | - | ON-MESSAGE | Formerly suppressed standard informational form messages by intercepting ON-MESSAGE events | Body executes null; original purpose was to quiet FRM- informational messages |
| **Inactive stub** | Form | - | FT_SAVE | Inherited trigger stub from DPL object group; formerly delegated to the shared save routine; body is a no-op stub in this form as the block is non-database | No active save operation required; form is read-only query display |
| **Inactive stub** | Form | - | FT_DEL | Inherited trigger stub from DPL object group; formerly delegated to the shared delete routine; body is a no-op stub in this form as the block is non-database | No active delete operation required; form is read-only query display |
| **Inactive stub** | Form | - | FT_PRINT | Inherited trigger stub from DPL object group; formerly delegated to PROC_REPORT_CALL / RUN_REPORT; body is a no-op stub - print is not actively used in this form | No report server destination configured for this form |

*WEBUTIL block triggers (WHEN-CUSTOM-ITEM-EVENT on all WebUtil bean areas and WHEN-BUTTON-PRESSED on WEBUTIL.DUMMY) are subclassed WEBUTIL boilerplate. They are listed here for completeness but are not business triggers and are excluded from migration scope.*

*Additional null-only or partially commented triggers exist on estimation and legacy blocks - see XML `TriggerText` starting with `null;` or `/*`.*

**Complete trigger inventory (50 business triggers):**
*vr_cross_fmb.xml contains Trigger elements.*

| Trigger Name | Block | Item | Called From / Context | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| ON-ERROR | Form | - | Form level | Intercepts all form errors; handles ORA-02292 integrity violations, displays error text via GENERAL.DISP_TEXT, and rolls back on lock conflicts or SQL errors |
| ON-MESSAGE | Form | - | Form level | **COMMENTED OUT / INACTIVE** - Body executes null; formerly suppressed informational form messages |
| KEY-EXIT | Form | - | Form level | Clears DBMS application info and exits the form without validation |
| KEY-LISTVAL | Form | - | Form level | Displays the LOV associated with the current item; advances to next item on successful selection |
| KEY-COMMIT | Form | - | Form level | **COMMENTED OUT / INACTIVE** - Body executes null; formerly executed enter, committed the form, and cleared after commit |
| KEY-CLRFRM | Form | - | Form level | Clears the entire form without validation |
| KEY-OTHERS | Form | - | Form level | Inherited from DPL object group; suppresses unhandled key events to prevent default Forms behaviour (inherited) |
| KEY-NEXT-ITEM | Form | - | Form level | Inherited from DPL object group; navigates to the next item in the current block (inherited) |
| KEY-PREV-ITEM | Form | - | Form level | Inherited from DPL object group; navigates to the previous item in the current block (inherited) |
| KEY-NXTBLK | Form | - | Form level | Inherited from DPL object group; navigates to the next block (inherited) |
| KEY-PRVBLK | Form | - | Form level | Inherited from DPL object group; navigates to the previous block (inherited) |
| KEY-DOWN | Form | - | Form level | Inherited from DPL object group; navigates down one record in the current block (inherited) |
| KEY-UP | Form | - | Form level | Inherited from DPL object group; navigates up one record in the current block (inherited) |
| FT_SAVE | Form | - | Form level | **INACTIVE STUB** - Inherited trigger from DPL object group; no active save operation in this read-only form (inherited) |
| FT_CANCEL | Form | - | Form level | Inherited from DPL object group; clears pending changes and returns the block to its previous state (inherited) |
| FT_INSERT | Form | - | Form level | Inherited from DPL object group; initiates insert mode for the current block (inherited) |
| FT_DEL | Form | - | Form level | **INACTIVE STUB** - Inherited trigger from DPL object group; no active delete operation in this read-only form (inherited) |
| FT_LIST | Form | - | Form level | Inherited from DPL object group; displays the LOV for the current item (inherited) |
| FT_PRINT | Form | - | Form level | **INACTIVE STUB** - Inherited trigger from DPL object group; no active report destination configured for this form (inherited) |
| WHEN-NEW-FORM-INSTANCE | Form | - | Form level | Inherited from DPL object group; initialises global variables (DEALER, LOC_CD, PRINCIPAL, USERID, PARENT_GROUP), sets DBMS application context, and calls PROC_POP_LIST to populate dropdown lists on form startup (inherited) |
| PRE-FORM | Form | - | Form level | Sets DBMS application info (module name = 'vr_cross') for session-level monitoring |
| KEY-NEXT-ITEM | CB_DUMMY | CB_LOC_DESC | CB_DUMMY.CB_LOC_DESC | Clears the results count, clears the CROSS_SELL_UPSELL block, and navigates to P_FROM_DATE |
| WHEN-VALIDATE-ITEM | CB_DUMMY | P_FROM_DATE | CB_DUMMY.P_FROM_DATE | Validates that the workshop from-date is not greater than today's date and not greater than the to-date |
| WHEN-VALIDATE-ITEM | CB_DUMMY | P_TO_DATE | CB_DUMMY.P_TO_DATE | Validates that the to-date is not entered without a from-date and is not less than the from-date |
| KEY-NEXT-ITEM | CB_DUMMY | P_MODEL_DESC | CB_DUMMY.P_MODEL_DESC | Clears the results count, clears the CROSS_SELL_UPSELL block, and navigates to P_VARIANT_DESC |
| KEY-NEXT-ITEM | CB_DUMMY | P_VARIANT_DESC | CB_DUMMY.P_VARIANT_DESC | Clears the results count, clears the CROSS_SELL_UPSELL block, and navigates to P_SALE_FROM_DATE |
| WHEN-VALIDATE-ITEM | CB_DUMMY | P_SALE_FROM_DATE | CB_DUMMY.P_SALE_FROM_DATE | Validates that the sale from-date is not greater than today's date |
| WHEN-VALIDATE-ITEM | CB_DUMMY | P_SALE_TO_DATE | CB_DUMMY.P_SALE_TO_DATE | Validates that the sale to-date is not entered without a sale from-date and is not less than the sale from-date |
| KEY-NEXT-ITEM | CB_DUMMY | P_ODOMETER_FROM | CB_DUMMY.P_ODOMETER_FROM | Clears the results count, clears the CROSS_SELL_UPSELL block, and navigates to P_ODOMETER_TO |
| WHEN-VALIDATE-ITEM | CB_DUMMY | P_ODOMETER_FROM | CB_DUMMY.P_ODOMETER_FROM | Validates that the from-odometer reading does not exceed the to-odometer reading |
| KEY-NEXT-ITEM | CB_DUMMY | P_ODOMETER_TO | CB_DUMMY.P_ODOMETER_TO | Clears the results count, clears the CROSS_SELL_UPSELL block, and navigates to P_JC_STATUS1 |
| WHEN-VALIDATE-ITEM | CB_DUMMY | P_ODOMETER_TO | CB_DUMMY.P_ODOMETER_TO | Validates that the to-odometer reading is not less than the from-odometer reading |
| WHEN-LIST-CHANGED | CB_DUMMY | P_JC_STATUS1 | CB_DUMMY.P_JC_STATUS1 | Clears the results count, clears the CROSS_SELL_UPSELL block, and navigates to P_EW_STATUS |
| WHEN-LIST-CHANGED | CB_DUMMY | P_EW_STATUS | CB_DUMMY.P_EW_STATUS | Clears the results count, clears the CROSS_SELL_UPSELL block, and navigates to BTN_VIEW |
| WHEN-BUTTON-PRESSED | CB_DUMMY | BTN_VIEW | CB_DUMMY.BTN_VIEW | Executes the cross-sell/upsell search query using all filter criteria and populates the results grid with matching vehicle and customer records |
| WHEN-BUTTON-PRESSED | CB_DUMMY | PB_EXCEL | CB_DUMMY.PB_EXCEL | Builds a dynamic SQL query for the filtered results and exports the data to a CSV file via VIEW_EXCEL_REP |
| WHEN-BUTTON-PRESSED | CB_DUMMY | PUSH_BUTTON535 | CB_DUMMY.PUSH_BUTTON535 | Builds a diagnostic SQL query string from the current filter parameters (dealer mapping code, location code, date range, odometer bounds, job card status, model, variant, sale dates, extended warranty status) and assigns it to :CB_DUMMY.TXT for diagnostic inspection |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EXIT | PB_BLK.PB_EXIT | Exits the form regardless of form status or query mode |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_LIST | PB_BLK.PB_LIST | Delegates to the inherited FT_LIST trigger |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_INSERT | PB_BLK.PB_INSERT | Delegates to the inherited FT_INSERT trigger |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_DEL | PB_BLK.PB_DEL | Delegates to the inherited FT_DEL trigger |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CANCEL | PB_BLK.PB_CANCEL | Delegates to the inherited FT_CANCEL trigger |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SAVE | PB_BLK.PB_SAVE | Delegates to the inherited FT_SAVE trigger |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PRINT | PB_BLK.PB_PRINT | Delegates to the inherited FT_PRINT trigger |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CUT | PB_BLK.PB_CUT | Cuts the selected region |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_COPY | PB_BLK.PB_COPY | Copies the selected region |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PASTE | PB_BLK.PB_PASTE | Pastes from the clipboard |
| WHEN-BUTTON-PRESSED | PB_BLK | NB_EXIT | PB_BLK.NB_EXIT | Sets GLOBAL.EXIT_FLAG to 'EXIT' and exits the form |
| WHEN-BUTTON-PRESSED | PB_BLK | NB_CLEAR | PB_BLK.NB_CLEAR | Clears all records from the CROSS_SELL_UPSELL block and the CB_DUMMY block without validation |
| WHEN-BUTTON-PRESSED | PB_BLK | NB_OK | PB_BLK.NB_OK | Exits the form without validation |

### 8.8 Canvas and Window Inventory

**Windows:**

| Window | Title | Primary Canvas |
| :--- | :--- | :--- |
| WIN_ERR | - | CN_ERR |
| WN_MAIN | Workshop Database (Rel : 1.1.3) | CN_MAIN |

**Canvases:**

| Canvas | Type | Window |
| :--- | :--- | :--- |
| CN_ERR | Content | WIN_ERR |
| CN_TOOL | Vertical Toolbar | WN_MAIN |
| CN_MAIN | Content | WN_MAIN |

---

### 8.9 Editors

*No editors found in vr_cross_fmb.xml.*

### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

#### 8.10.1 Visual Attributes (form-defined)

*0 VisualAttribute elements defined at form level (not inherited from DPL.olb).*

*No form-local visual attributes found in vr_cross_fmb.xml.*

#### 8.10.2 Property Classes (form-defined)

*Form-local PropertyClass elements.*

*No form-local property classes found in vr_cross_fmb.xml.*

#### 8.10.3 Object Groups

*Object groups bundle inherited triggers and visual objects applied form-wide at runtime.*

| Object Group Child | Type |
| :--- | :--- |
| KEY-OTHERS | Inherited trigger |
| KEY-NEXT-ITEM | Inherited trigger |
| KEY-PREV-ITEM | Inherited trigger |
| KEY-NXTBLK | Inherited trigger |
| KEY-PRVBLK | Inherited trigger |
| KEY-DOWN | Inherited trigger |
| KEY-UP | Inherited trigger |
| CN_ERR | Inherited canvas |
| VA_DISP | Inherited visualattribute |
| CB_ERR | Inherited block |
| VA_LOV | Inherited visualattribute |
| VA_TRNI_DT | Inherited visualattribute |
| VA_TITLE | Inherited visualattribute |
| VA_ALERT | Inherited visualattribute |
| VA_BUTN | Inherited visualattribute |
| VA_TEXT | Inherited visualattribute |
| VA_MPROMPT | Inherited visualattribute |
| VA_OPROMPT | Inherited visualattribute |
| VA_MAND | Inherited visualattribute |
| VA_NUM | Inherited visualattribute |
| VA_DESC | Inherited visualattribute |
| VA_ICONIC_BUTN | Inherited visualattribute |
| VA_RB | Inherited visualattribute |
| VA_CB | Inherited visualattribute |
| WN_MAIN | Inherited window |
| POP_MAIN | Inherited trigger |
| CN_MAIN | Inherited canvas |
| CN_TOOL | Inherited canvas |
| PB_BLK | Inherited block |
| AL_ERRINFO | Inherited alert |
| AL_NOTE | Inherited alert |
| AL_CONFIRM | Inherited alert |
| WIN_ERR | Inherited window |
| AL_PRINT | Inherited alert |
| FT_SAVE | Inherited trigger |
| FT_CANCEL | Inherited trigger |
| FT_INSERT | Inherited trigger |
| FT_DEL | Inherited trigger |
| FT_LIST | Inherited trigger |
| FT_PRINT | Inherited trigger |
| WHEN-NEW-FORM-INSTANCE | Inherited trigger |

### 8.11 DataSourceColumn Inventory

*29 DataSourceColumn elements across 1 blocks - formal query column-to-block mapping from vr_cross_fmb.xml.*

#### CROSS_SELL_UPSELL (29 columns)

| Column (DSCName) | Data Type |
| :--- | :--- |
| APPLY_MODEL_CD | VARCHAR2 |
| CATG_CD | VARCHAR2 |
| CREATED_BY | VARCHAR2 |
| CREATED_DATE | DATE |
| DEALER_MAP_CD | NUMBER |
| EFF_FROM_DATE | DATE |
| EFF_TO_DATE | DATE |
| LANDED_COST | NUMBER |
| MIN_ORD_QTY | NUMBER |
| MODIFIED_BY | VARCHAR2 |
| MODIFIED_DATE | DATE |
| MRP_1 | NUMBER |
| PART_DESC | VARCHAR2 |
| PART_NUM | VARCHAR2 |
| PRINCIPAL_MAP_CD | NUMBER |
| PURCHASE_PRICE | NUMBER |
| SELL_PRICE | NUMBER |
| SOURCE_CD | VARCHAR2 |
| UOM_CD | VARCHAR2 |
| ROOT_PART_NUM | VARCHAR2 |
| SEQ_NUM | NUMBER |
| TYPE_CD | VARCHAR2 |
| SUB_TYPE_CD | VARCHAR2 |
| TAG_CD | VARCHAR2 |
| MUL_YN | VARCHAR2 |
| VOR_YN | VARCHAR2 |
| SUB_CATG1_CD | VARCHAR2 |
| SUB_CATG2_CD | VARCHAR2 |
| BRAND_CD | VARCHAR2 |

**Total DataSourceColumns:** 29 across 1 blocks

## 9. Object Library

*The form inherits visual attributes, property classes, and object groups from two attached object libraries: the DPL library and the WebUtil library. The DPL library provides the standard form and UI property classes; WebUtil provides the web-client utility object group.*

Source OLB file(s): DPL_olb.xml, webutil_olb.xml

| Name | Type | Description | Used By (count) | Sample Items |
| ---- | ---- | ----------- | --------------- | ------------ |
| VA_CB | VisualAttribute | Check box visual attribute | not used directly in this form | N/A |
| VA_RB | VisualAttribute | Radio button visual attribute | not used directly in this form | N/A |
| VA_ICONIC_BUTN | VisualAttribute | Iconic push button visual attribute | not used directly in this form | N/A |
| VA_DESC | VisualAttribute | Descriptive text visual attribute | not used directly in this form | N/A |
| VA_NUM | VisualAttribute | Numeric field visual attribute | not used directly in this form | N/A |
| VA_MAND | VisualAttribute | Mandatory field visual attribute | not used directly in this form | N/A |
| VA_OPROMPT | VisualAttribute | Optional field prompt visual attribute | not used directly in this form | N/A |
| VA_MPROMPT | VisualAttribute | Mandatory field prompt visual attribute | not used directly in this form | N/A |
| VA_TEXT | VisualAttribute | Standard text field visual attribute | not used directly in this form | N/A |
| VA_BUTN | VisualAttribute | Push button visual attribute | not used directly in this form | N/A |
| VA_ALERT | VisualAttribute | Alert visual attribute | not used directly in this form | N/A |
| VA_TITLE | VisualAttribute | Title label visual attribute | not used directly in this form | N/A |
| VA_TRNI_DT | VisualAttribute | Transaction date visual attribute | not used directly in this form | N/A |
| VA_LOV | VisualAttribute | List of values field visual attribute | not used directly in this form | N/A |
| VA_DISP | VisualAttribute | Display-only field visual attribute | not used directly in this form | N/A |
| PC_DESC | PropertyClass | Descriptive text item property class | referenced | N/A |
| PC_SC_DATE | PropertyClass | Date field property class | referenced | N/A |
| PC_TITLE | PropertyClass | Text item property class for titles | referenced | N/A |
| PC_FORMAT | PropertyClass | Text item property class for formatted values | referenced | N/A |
| PC_MR_BLK | PropertyClass | Multi-row block property class | 1 | CROSS_SELL_UPSELL block |
| PC_DISP | PropertyClass | Display-only text item property class | referenced | N/A |
| PC_LOV | PropertyClass | List of values property class | referenced | N/A |
| PC_FORM | PropertyClass | Form module-level property class | 1 | VR_CROSS form module |
| PC_DISP_DATE | PropertyClass | Display-only date text item property class | referenced | N/A |
| PC_DISP_NUM | PropertyClass | Display-only numeric text item property class | referenced | N/A |
| PC_DATE | PropertyClass | Date field property class | referenced | N/A |
| PC_DTTIME | PropertyClass | Date and time field property class | referenced | N/A |
| PC_CB | PropertyClass | Check box property class | referenced | N/A |
| PC_ALERT | PropertyClass | Alert property class | referenced | N/A |
| PC_MDATE | PropertyClass | Mandatory date field property class | referenced | N/A |
| PC_RB | PropertyClass | Radio button property class | referenced | N/A |
| PC_WIND | PropertyClass | Window property class | 1 | WN_MAIN window |
| PC_CANV | PropertyClass | Canvas property class | 1 | CN_MAIN canvas |
| PC_BUTN | PropertyClass | Push button property class | 4 | BTN_VIEW, NB_EXIT, NB_CLEAR, NB_OK |
| PC_TEXT | PropertyClass | Standard text item property class | referenced | N/A |
| PC_MTEXT | PropertyClass | Mandatory text item property class | referenced | N/A |
| PC_UTEXT | PropertyClass | Updatable text item property class | referenced | N/A |
| PC_MUTEXT | PropertyClass | Mandatory updatable text item property class | referenced | N/A |
| PC_NUM | PropertyClass | Numeric item property class | referenced | N/A |
| PC_MNUM | PropertyClass | Mandatory numeric item property class | referenced | N/A |
| PC_ICONIC_BUTN | PropertyClass | Iconic push button property class | referenced | N/A |
| PC_SCROLL | PropertyClass | Scroll bar property class | referenced | N/A |
| WEBUTIL | ObjectGroup | WebUtil client-side utility functions object group - includes WebUtil bean areas (client info, file, host, session, file transfer, OLE, C API, browser functions), hidden window, canvas, and error alert | 1 | WEBUTIL block (entire object group subclassed into the form) |
| WEBUTIL_NO_OLE | ObjectGroup | WebUtil object group variant without OLE support | not used directly in this form | N/A |
| OG_GROUP | ObjectGroup | Standard DPL form template object group - provides the standard form structure including triggers (ON-ERROR, ON-MESSAGE, KEY-EXIT, KEY-LISTVAL, KEY-COMMIT, KEY-CLRFRM, WHEN-NEW-FORM-INSTANCE and others), the PB_BLK toolbar button block, and related standard form elements | 1 | Form module (OG_GROUP subclassed into VR_CROSS) |

---

## 10. Record Groups

*Lists all record groups, their LOV bindings, query logic, dynamic bindings, business purpose, and form usage.*

| Record Group | Type | Used By LOV | Display Column | Return Column | Dynamic Bindings | Purpose | Where Used |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| RG_MOD | Query | LOV_MOD | MOD_CD | MOD_DESC | No | Lists vehicle model codes and descriptions for the current principal to filter cross-sell records by model | LOV_MOD -> CB_DUMMY.P_MODEL_DESC, CB_DUMMY.CB_VARIANT_DESC |
| RG_LOC | Query | LOV_LOC | LOC_DESC | LOC_CD | No | Lists active service dealer locations accessible to the logged-in user for location selection | LOV_LOC -> CB_DUMMY.CB_LOC_DESC, CB_DUMMY.CB_DEALER_MAP_CD |
| RG_VARIANT | Query | LOV_VARIANT | VARIANT_CD | VARIANT_DESC | No | Lists vehicle variants for the selected model and principal to filter cross-sell records by variant | LOV_VARIANT -> CB_DUMMY.P_VARIANT_DESC |

**Total Record Groups:** 3

## 11. Referenced Database Objects

*Database tables, views, and objects accessed by the form.*

| Block | Base Table | Primary Key Item | Database Item |
| :--- | :--- | :--- | :--- |
| CB_DUMMY | - | - | No |
| CROSS_SELL_UPSELL | - | - | No |
| PB_BLK | - | - | No |

| Object | Schema | Used In | Description |
| :--- | :--- | :--- | :--- |
| `AM_LIST` | - | PROC_POP_LIST, Trigger WHEN-BUTTON-PRESSED | Lookup list master - stores RO status and extended warranty type codes and descriptions |
| `AM_USER_DEALER_MASTER` | - | RG_LOC | User dealer master - maps users to their authorised dealer locations and types |
| `DUAL` | - | PROC_POP_LIST, RG_MOD, RG_VARIANT, Trigger WHEN-BUTTON-PRESSED, Trigger WHEN-NEW-FORM-INSTANCE | Oracle system dual table - used for UNION ALL constant row generation in record group queries |
| `MULDMS.GM_MOD` | - | RG_MOD | Vehicle model master - stores model codes and descriptions for the principal |
| `MULDMS.GM_VAR` | - | RG_VARIANT | Vehicle variant master - stores variant codes and descriptions linked to model codes |
| `VH_RO` | - | Trigger WHEN-BUTTON-PRESSED | Vehicle repair order - primary workshop transaction record for each vehicle service visit |

**Total Referenced Objects:** 6

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure/Package Index

| Requirement ID | Procedure/Package | Purpose |
| -------------- | ----------------- | ------- |
| BR-001 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Records the form module name against the current database session for monitoring |
| BR-001 | DBMS_APPLICATION_INFO.SET_MODULE | Registers the form module name and action against the current database session |
| BR-002, BR-003, BR-004, BR-005 | GENERAL.DISP_TEXT | Displays user-facing error and informational alerts during date validation |
| BR-010 | SF_GET_CUST_ADDRESS | Retrieves and assembles the full postal address of a customer from the customer master |
| BR-010 | SF_GET_MODEL_DESC | Resolves a vehicle model code to its human-readable description |
| BR-010 | SF_GET_VARIANT_DESC | Resolves a vehicle variant code to its human-readable description |
| BR-011 | VIEW_EXCEL_REP | Writes the cross-sell/upsell data to a server-side CSV file and delivers it to the user's browser |
| BR-011 | WEBUTIL.ID_NULL | Guards record group handle validity within VIEW_EXCEL_REP before deletion |
| BR-011 | WEB.SHOW_DOCUMENT | Opens the generated CSV export file in the user's browser |
| BR-012 | GENERAL.RAISE_ERROR | Raises a predefined application error message for a given error code |
| BR-012 | GENERAL.DISP_TEXT | Displays formatted error details in an error alert for known error codes and SQL errors |
| BR-013 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Clears the client information from the database session on form exit |
| BR-013 | DBMS_APPLICATION_INFO.SET_MODULE | Clears the module name from the database session on form exit |
| BR-018 | PROC_POP_LIST (form program unit) | Populates the job card status and extended warranty status dropdown lists from reference data |
| BR-018 | WEBUTIL.ID_NULL | Guards record group handle validity within PROC_POP_LIST before creation |
| - | GENERAL.ASK_CONFIRM | Displays a confirmation alert to the user before proceeding with an action (WEBUTIL.DUMMY button) |
| - | WEBUTIL_CORE.CUSTOMEVENTHANDLER | Central WebUtil event dispatch routine; routes client-side custom events to functional WebUtil handlers |
| - | WEBUTIL.INITWEBUTIL | Initialises the WebUtil library on form startup |
| - | WEBUTIL.CHECKLIBS | Verifies that required WebUtil client-side libraries are available |
| - | WEBUTIL.FOPEN | Opens a server-side file for writing during CSV export |
| - | WEBUTIL.PUT_LINE | Writes a line of text to the open server-side file during CSV export |
| - | WEBUTIL.FCLOSE | Closes the server-side file after CSV export is complete |
| - | WEBUTIL.GETLASTERROR | Retrieves the last error raised by a WebUtil operation |
| - | YR_DATE_YR | Calculates the number of years elapsed since a given date (vehicle age derivation) |
| - | SF_GET_LIST_DESC | Resolves an extended warranty type code to its description from the AM_LIST reference master |

---

### 12.2 Procedure and Package Catalogue

#### PROC_POP_LIST (form program unit)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| PROC_POP_LIST | Form-level PL/SQL procedure (form program unit) | Likely invoked via the inherited WHEN-NEW-FORM-INSTANCE from the DPL object group | Populates the job card status and extended warranty status dropdown list items by building dynamic SQL queries against the AM_LIST reference table and using the result to fill the list items; uses WEBUTIL.ID_NULL to check whether a record group already exists before creating it |

---

#### VIEW_EXCEL_REP (form program unit)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| VIEW_EXCEL_REP | Form-level PL/SQL procedure (form program unit) | WHEN-BUTTON-PRESSED on PB_EXCEL | Executes the cross-sell/upsell query, iterates over the result set, writes each row to a server-side CSV file using WebUtil file I/O routines, and delivers the file to the user's browser via WEB.SHOW_DOCUMENT; uses WEBUTIL.ID_NULL to check the record group handle before deletion |

---

#### SF_GET_CUST_ADDRESS

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| SF_GET_CUST_ADDRESS | Standalone function (.fnc) | WHEN-BUTTON-PRESSED on BTN_VIEW; WHEN-BUTTON-PRESSED on PB_EXCEL | Retrieves a customer's full formatted postal address by reading the customer master, choosing between office and permanent address based on the communication preference, and assembling address lines with city, county, state, and postal code descriptions resolved from reference tables |

---

#### SF_GET_MODEL_DESC

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| SF_GET_MODEL_DESC | Standalone function (.fnc) | WHEN-BUTTON-PRESSED on BTN_VIEW; WHEN-BUTTON-PRESSED on PB_EXCEL; WHEN-BUTTON-PRESSED on PUSH_BUTTON535 | Looks up the model description for a given model code and principal from the vehicle model master (GM_MOD); returns "Not Found" on any exception |

---

#### SF_GET_VARIANT_DESC

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| SF_GET_VARIANT_DESC | Standalone function (.fnc) | WHEN-BUTTON-PRESSED on BTN_VIEW; WHEN-BUTTON-PRESSED on PB_EXCEL; WHEN-BUTTON-PRESSED on PUSH_BUTTON535 | Looks up the variant description for a given variant code and principal from the vehicle variant master (GM_VAR); returns "Not Found" on any exception |

---

#### SF_GET_LIST_DESC

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| SF_GET_LIST_DESC | Standalone function (EXTERNAL / NOT IN BUNDLE - not in supplied source files) | WHEN-BUTTON-PRESSED on PB_EXCEL | Retrieves the description for a list code from the reference list master (AM_LIST); used in the export query to resolve extended warranty type codes to descriptions |

---

#### YR_DATE_YR

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| YR_DATE_YR | Function (EXTERNAL / NOT IN BUNDLE - not in supplied source files) | WHEN-BUTTON-PRESSED on BTN_VIEW; WHEN-BUTTON-PRESSED on PB_EXCEL | Calculates the number of years elapsed since a given date (used to derive vehicle age from the invoice date) |

---

#### GENERAL (DPL library package)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| GENERAL.ASK_CONFIRM | PLL library package function (DPL.pld/DPL.pll) | WHEN-BUTTON-PRESSED on WEBUTIL.DUMMY | Displays a confirmation alert to the user and returns a numeric value indicating the button pressed; used to prompt the user before proceeding with an action |
| GENERAL.DISP_TEXT | PLL library package procedure (DPL.pld/DPL.pll) | ON-ERROR trigger; WHEN-BUTTON-PRESSED on CB_DUMMY.PB_EXCEL; WHEN-VALIDATE-ITEM on CB_DUMMY.P_FROM_DATE; WHEN-VALIDATE-ITEM on CB_DUMMY.P_TO_DATE; WHEN-VALIDATE-ITEM on CB_DUMMY.P_SALE_FROM_DATE; WHEN-VALIDATE-ITEM on CB_DUMMY.P_SALE_TO_DATE | Displays a message to the user in an alert dialog; selects between the error alert (AL_ERRINFO) and informational alert (AL_NOTE) based on the title string; invoked for date validation errors, export errors, and general form error handling |
| GENERAL.RAISE_ERROR | PLL library package procedure (DPL.pld/DPL.pll) | ON-ERROR trigger | Looks up a predefined error message by code, determines the message level (Error/Note/Caution), displays it via GENERAL.DISP_TEXT in the appropriate alert, and raises FORM_TRIGGER_FAILURE for error-level messages; called in ON-ERROR to handle ORA-02292 integrity constraint violations |

---

#### DBMS_APPLICATION_INFO (Oracle built-in package)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Oracle built-in package procedure (EXTERNAL / NOT IN BUNDLE) | PRE-FORM trigger; KEY-EXIT trigger | Sets or clears the client information string on the current database session for session monitoring |
| DBMS_APPLICATION_INFO.SET_MODULE | Oracle built-in package procedure (EXTERNAL / NOT IN BUNDLE) | PRE-FORM trigger; KEY-EXIT trigger | Sets or clears the module name and action name on the current database session for performance monitoring |

---

#### WEB (Oracle Forms web package)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| WEB.SHOW_DOCUMENT | Oracle Forms web package procedure (EXTERNAL / NOT IN BUNDLE) | VIEW_EXCEL_REP program unit | Opens the generated CSV export file in the user's browser by navigating to the server-side URL of the file |

---

#### WEBUTIL (Oracle Forms WebUtil library package)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| WEBUTIL.ID_NULL | WebUtil library function (webutil.pld/webutil.pll - WEBUTIL_C_API) | ProgramUnit: PROC_POP_LIST; ProgramUnit: VIEW_EXCEL_REP | Returns TRUE if the supplied handle (RecordGroup or GroupColumn) is null or uninitialised; used in PROC_POP_LIST to check whether a record group already exists before creating it, and in VIEW_EXCEL_REP to check the record group handle before deletion |
| WEBUTIL.INITWEBUTIL | WebUtil library procedure (webutil.pld/webutil.pll) | WHEN-NEW-FORM-INSTANCE trigger | Initialises the WebUtil client-side library on form startup, registering all WebUtil bean-area items with the Forms runtime |
| WEBUTIL.CHECKLIBS | WebUtil library procedure (webutil.pld/webutil.pll) | WHEN-NEW-FORM-INSTANCE trigger | Verifies that the required WebUtil client-side DLLs or JAR libraries are available on the client machine; raises an error if any required library is missing |
| WEBUTIL.FOPEN | WebUtil library function (webutil.pld/webutil.pll) | VIEW_EXCEL_REP program unit | Opens a file on the server-side file system for writing; returns a file handle used by subsequent PUT_LINE and FCLOSE calls during CSV export |
| WEBUTIL.PUT_LINE | WebUtil library procedure (webutil.pld/webutil.pll) | VIEW_EXCEL_REP program unit | Writes a single line of text to the open server-side file during CSV export |
| WEBUTIL.FCLOSE | WebUtil library procedure (webutil.pld/webutil.pll) | VIEW_EXCEL_REP program unit | Closes the server-side file after all CSV export rows have been written |
| WEBUTIL.GETLASTERROR | WebUtil library function (webutil.pld/webutil.pll) | VIEW_EXCEL_REP program unit | Retrieves the last error message raised by a WebUtil file I/O or other operation; used for error reporting during CSV export |
| WEBUTIL.IS_OPEN | WebUtil library function (webutil.pld/webutil.pll) | VIEW_EXCEL_REP program unit | Returns TRUE if the supplied file handle refers to a currently open file; used to guard FCLOSE calls |
| WEBUTIL.BLOCKING | WebUtil library procedure (webutil.pld/webutil.pll) | Internal WebUtil dispatch | Controls whether WebUtil client calls block the Forms session until the client-side operation completes |
| WEBUTIL.REGISTERBEAN | WebUtil library procedure (webutil.pld/webutil.pll) | WEBUTIL.INITWEBUTIL | Registers a WebUtil bean-area item with the Forms runtime during library initialisation |
| WEBUTIL.REGISTER_FUNCTION | WebUtil library procedure (webutil.pld/webutil.pll) | WEBUTIL.INITWEBUTIL | Registers an individual WebUtil function with its bean-area item during library initialisation |

---

#### WEBUTIL_CORE (Oracle Forms WebUtil library package)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| WEBUTIL_CORE.CUSTOMEVENTHANDLER | WebUtil library procedure (webutil.pld/webutil.pll - WEBUTIL_CORE) | WHEN-CUSTOM-ITEM-EVENT on WEBUTIL.WEBUTIL_BROWSER_FUNCTIONS; WHEN-CUSTOM-ITEM-EVENT on WEBUTIL.WEBUTIL_CLIENTINFO_FUNCTIONS; WHEN-CUSTOM-ITEM-EVENT on WEBUTIL.WEBUTIL_C_API_FUNCTIONS; WHEN-CUSTOM-ITEM-EVENT on WEBUTIL.WEBUTIL_FILETRANSFER_FUNCTIONS; WHEN-CUSTOM-ITEM-EVENT on WEBUTIL.WEBUTIL_FILE_FUNCTIONS; WHEN-CUSTOM-ITEM-EVENT on WEBUTIL.WEBUTIL_HOST_FUNCTIONS; WHEN-CUSTOM-ITEM-EVENT on WEBUTIL.WEBUTIL_OLE_FUNCTIONS; WHEN-CUSTOM-ITEM-EVENT on WEBUTIL.WEBUTIL_SESSION_FUNCTIONS | Central WebUtil event dispatch routine; receives the name and serialised parameters of a custom client-side event and routes it to the appropriate WebUtil functional handler; fired automatically by the Forms runtime via WHEN-CUSTOM-ITEM-EVENT on each of the eight WebUtil bean-area items |

## 13. Package Procedure Specifications

*NO PCK files found - no ``*.pck`` source files were discovered in the form sources input directory. Package specifications cannot be generated without uploaded PCK sources.*

## 14. Database Package Catalogue

*NO PCK files found - no `*.pck` source files were discovered in the form sources input directory. The database package catalogue cannot be generated without uploaded PCK sources.*

## 15. PLD Procedure Call Sites

*Maps each program-library routine to its call sites within triggers and program units. Behaviour descriptions are derived from the uploaded ``.pld`` sources.*

### DPL.pld (`general`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ASK_CONFIRM | Function | Function(confirm_msg VARCHAR2) RETURN NUMBER | Trigger: WHEN-BUTTON-PRESSED in WEBUTIL.DUMMY | Displays a confirmation alert to the user and returns a numeric value indicating the button pressed. Used in the WEBUTIL.DUMMY button-pressed trigger to prompt the user before proceeding with an action. |
| DISP_TEXT | Procedure | Procedure(text_string VARCHAR2, title_string VARCHAR2) | Trigger: ON-ERROR in Form, Trigger: WHEN-BUTTON-PRESSED in CB_DUMMY.PB_EXCEL, Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.P_FROM_DATE, Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.P_SALE_FROM_DATE, Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.P_SALE_TO_DATE, Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.P_TO_DATE | Displays an alert dialog using AL_ERRINFO (for Error title) or AL_NOTE (for all other titles), setting both the title and message text at runtime. Invoked for date validation errors, export errors, and general form error handling. |
| RAISE_ERROR | Procedure | Procedure(mesg_code IN VARCHAR2) | Trigger: ON-ERROR in Form | Retrieves a message by error code, determines severity (Error/Note/Caution), and displays the message using GENERAL.DISP_TEXT. Raises FORM_TRIGGER_FAILURE for Error-type messages. Called in ON-ERROR to handle ORA-02292 integrity constraint violations. |

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``vr_cross_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| CHECK_FORM_FAILURE | Procedure | Procedure() | Trigger: KEY-COMMIT in Form | **COMMENTED OUT / INACTIVE** - Previously invoked after ENTER and COMMIT_FORM calls in KEY-COMMIT to verify that each operation succeeded; raised a form failure if the operation returned an error. Trigger body is now null. |

**Total Active Routines:** 3 of 24 in DPL.pld source
**Inactive / commented-only routines:** 1

---

### webutil.pld (`WEBUTIL_CORE`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| CustomEventHandler | Procedure | Procedure(EventName in VARCHAR2, EventParameters in VARCHAR2) | Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_BROWSER_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_CLIENTINFO_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_C_API_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_FILETRANSFER_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_FILE_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_HOST_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_OLE_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_SESSION_FUNCTIONS | Central WebUtil event dispatch routine. Receives the name and serialised parameters of a custom client-side event and routes it to the appropriate WebUtil functional handler. Fired automatically by the Forms runtime via WHEN-CUSTOM-ITEM-EVENT on each of the eight WebUtil bean-area items that cover browser, client-info, C-API, file-transfer, file, host, OLE, and session functionality. |

**Total Active Routines:** 1 of 39 in webutil.pld source

---

### webutil.pld (`WEBUTIL_C_API`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ID_NULL | Function | Function(handle IN Pointer) RETURN BOOLEAN | ProgramUnit: PROC_POP_LIST, ProgramUnit: VIEW_EXCEL_REP | Returns TRUE if the supplied handle (RecordGroup or GroupColumn) is null/uninitialized. Used in PROC_POP_LIST to check whether a record group already exists before creating it, and in VIEW_EXCEL_REP to check the record group handle before deletion. |

**Total Active Routines:** 1 of 28 in webutil.pld source

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| ID | Service Name | Database Object | Input Parameters | Output | Business Function | API Endpoint Suggestion |
| -- | ------------ | --------------- | ---------------- | ------ | ----------------- | ----------------------- |
| MS-001 | Cross-Sell/Upsell Candidate List Service | VH_RO, GM_VIN, GM_CIN, MWAR_EXTE, AM_LIST, GM_MOD | dealer_map_cd, loc_cd, jc_from_date, jc_to_date, sale_from_date, sale_to_date, model_cd (optional), variant_cd (optional), odometer_from (optional), odometer_to (optional), jc_status (optional), ew_status (optional), principal_map_cd | Paginated list of: reg_num, vin, cust_name, mobile_phone (masked), res_phone (masked), office_phone (masked), address, model, variant, jc_open_date, vehicle_age_years, mileage, ew_type; total_count | Retrieves a list of customers who have visited the workshop within the specified job card date range and whose vehicles match the given model, variant, odometer, sale date, job card status, and extended warranty criteria, for cross-sell and upsell outreach | GET /api/v1/workshop/cross-sell-candidates |
| MS-002 | Customer Address Resolver | GM_CIN, GM_CITY, GM_CNTY, GM_STATE | principal_map_cd, cust_cd | Formatted full postal address string | Retrieves and assembles a customer's full postal address from the customer master, selecting office or permanent address based on communication preference and resolving city, county, and state descriptions from reference tables | GET /api/v1/customers/{cust_cd}/address |
| MS-003 | Vehicle Model Description Service | GM_MOD | model_cd, principal_map_cd | model_desc | Resolves a vehicle model code to its human-readable description for a given principal | GET /api/v1/vehicles/models/{model_cd}/description |
| MS-004 | Vehicle Variant Description Service | GM_VAR | variant_cd, principal_map_cd | variant_desc | Resolves a vehicle variant code to its human-readable description for a given principal | GET /api/v1/vehicles/variants/{variant_cd}/description |
| MS-005 | Cross-Sell Candidate Export Service | VH_RO, GM_VIN, GM_CIN, MWAR_EXTE, AM_LIST, GM_MOD | Same as MS-001 inputs plus export_format | CSV file download | Generates a downloadable CSV file containing the same cross-sell/upsell candidate data as MS-001, formatted with a header row and all phone numbers masked, for dealer outreach activities | POST /api/v1/workshop/cross-sell-candidates/export |
| MS-006 | Workshop Location List Service | AM_USER_DEALER_MASTER, AM_DEALER_LOC | user_id, principal_map_cd | List of: loc_desc, loc_cd, dealer_map_cd | Returns the list of active workshop locations accessible to a given user, filtered by dealer type and principal | GET /api/v1/workshops/locations |
| MS-007 | Vehicle Model Family List Service | MULDMS.GM_MOD | principal_map_cd | List of: model_cd (family_model_cd), model_desc (family_model_desc) plus an 'ALL' entry | Returns all vehicle model families for a given principal, for use in the model filter dropdown | GET /api/v1/vehicles/model-families |
| MS-008 | Vehicle Variant List Service | MULDMS.GM_VAR, MULDMS.GM_MOD | principal_map_cd, model_cd | List of: variant_cd, variant_desc plus an 'ALL' entry | Returns all vehicle variants for a given model family and principal, for use in the variant filter dropdown | GET /api/v1/vehicles/model-families/{model_cd}/variants |
| MS-009 | Reference List Lookup Service | AM_LIST | list_name, principal_map_cd | List of: list_code, list_desc | Returns the code-description pairs from the reference list master for a given list name and principal; used for job card status, extended warranty type, and similar dropdown populations | GET /api/v1/reference/lists/{list_name} |

**Total Microservices Identified: 9**

---

## 17. Workflows

| ID | Workflow Name | Trigger Event | Steps | Decision Points | End State |
| -- | ------------- | ------------- | ----- | --------------- | --------- |
| WF-001 | Form Session Registration | Form opens (PRE-FORM) | 1. Database session tagged with module name 'vr_cross' and empty action name | None | Session tagged; form displays to user |
| WF-002 | Search Criteria Entry and Validation | User enters and validates the job card opening date range | 1. User enters JC Opening From Date; 2. System validates: not blank, not future, not later than To Date; 3. System auto-derives and sets To Date (one month forward, capped at today); 4. User enters JC Opening To Date; 5. System validates: not blank, from date exists first, not earlier than from date, not after today, range within one month | If From Date blank -> error, field blocked; if From Date future -> error, field blocked; if From Date > To Date -> error, field blocked; if To Date blank -> error; if To Date missing From Date -> error; if To Date < From Date -> error; if To Date future -> error; if range > 1 month -> error | All date range validations passed; criteria ready for search |
| WF-003 | Sale Date Range Validation | User enters vehicle sale date range | 1. User enters Sale From Date; 2. System validates: not blank, not future, not later than Sale To Date (clears Sale To on failure); 3. User enters Sale To Date; 4. System validates: not blank, Sale From exists, not earlier than Sale From, not future | If Sale From Date blank -> error; if Sale From Date future -> error, Sale To cleared; if Sale From > Sale To -> error, Sale To cleared; if Sale To blank -> error; if Sale To missing Sale From -> error; if Sale To < Sale From -> error; if Sale To future -> error | Sale date range validated; criteria ready for search |
| WF-004 | Odometer Range Validation | User enters odometer bounds | 1. User enters Odometer From; 2. System validates: if entered, From must not exceed To (clears To on failure); 3. User enters Odometer To; 4. System validates: if entered, From must not exceed To (clears To on failure) | If Odometer From > To -> error, To cleared; if Odometer From > newly entered To -> error, To cleared | Odometer range valid or both blank; criteria ready for search |
| WF-005 | Cross-Sell Candidate Search and Display | User presses View button | 1. Results area enabled and cleared; 2. Query executed against VH_RO, GM_VIN, GM_CIN, MWAR_EXTE using selected criteria; 3. Phone numbers masked; addresses and descriptions resolved; 4. Each matching row loaded into the display grid; 5. Extended warranty type description resolved per row; 6. Total count displayed; 7. Results area locked to read-only | If query returns no rows -> alert shown, focus returns to JC From Date field; if EW status = ALL -> first query branch used; if EW status = I or II -> second query branch; if EW status = NOEW -> third query branch | Results displayed (or no-results alert shown); form ready for next action |
| WF-006 | Cross-Sell Data CSV Export | User presses Export to Excel button | 1. Unique CSV filename generated from user login and timestamp; 2. Path space check: if spaces in path, redirect to C: drive and notify user; 3. CSV query built for selected criteria; 4. VIEW_EXCEL_REP called: record group created, row count checked, server path read from config file, file written row by row, file delivered to browser | If filename has spaces in path -> redirect to C: drive, show path warning; if row count > 65,535 -> truncate and show row limit warning; if no data -> error shown, trigger aborts; if value error -> error shown, trigger aborts; if multiple rows returned -> error shown, trigger aborts; if other error -> error shown, trigger aborts | CSV file delivered to user's browser (or error shown and operation aborted) |
| WF-007 | Form-Level Error Handling | Any form operation triggers a database or application error | 1. Error code captured; 2. If referential integrity violation (code -02292): predefined error message raised via GENERAL.RAISE_ERROR; 3. If known application code (40209, 40207, 50026, 50004): error type, number, and text displayed; trigger aborts; 4. If concurrent update conflict (40654-40659): specific message shown, rollback performed, trigger aborts; 5. If other SQL error: system error text shown, rollback, trigger aborts; 6. If informational code (40401, 40405): silently suppressed | Decision based on error code: referential integrity -> RAISE_ERROR; known app code -> display and abort; concurrent conflict -> rollback and abort; other SQL -> display, rollback, abort; informational -> suppress | Error handled (user sees message or nothing for informational codes); form remains open |
| WF-008 | Form Exit | User presses key exit shortcut | 1. Session tracking information cleared from database (client info and module set to null/empty); 2. Form closed without saving | None | Form closed; database session cleared |
| WF-009 | Dropdown List Initialisation | Form loads for the first time (WHEN-NEW-FORM-INSTANCE, inherited) | 1. Job card status list built from AM_LIST (list name 'RO_STATUS1', excluding code 20, plus 'ALL'), filtered by principal; 2. Extended warranty type list built from AM_LIST (list name 'EXTE_WARR_TYPE', plus 'ALL' and 'NOEW'), filtered by principal | If list already exists -> reuse without rebuilding | Dropdowns populated; form ready for user input |

**Total Workflows Identified: 9**

---

## 18. PLD-Backed Logic

*Maps shared library routines to their business function and suggested API contracts.*

### webutil.pld (`CLIENT_IMAGE`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | ID_NULL | Business Logic | ProgramUnit: PROC_POP_LIST, ProgramUnit: VIEW_EXCEL_REP | /api/v1/pld/id_null | When a record group handle is evaluated, then its null state is returned to determine whether creation or deletion is required |
| PLD-002 | length | Business Logic | Trigger: WHEN-BUTTON-PRESSED in CB_DUMMY.BTN_VIEW, Trigger: WHEN-BUTTON-PRESSED in CB_DUMMY.PB_EXCEL | /api/v1/pld/length | When a string value is processed for phone masking, then its character length is returned to calculate the LPAD mask width |


---

### DPL.pld (`general`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | CHECK_FORM_FAILURE | Validation | Trigger: KEY-COMMIT in Form | /api/v1/pld/check_form_failure | **COMMENTED OUT / INACTIVE** - When a form operation failed, then an error message was displayed and form trigger failure was raised |
| PLD-002 | DISP_TEXT | Business Logic | Trigger: ON-ERROR in Form, Trigger: WHEN-BUTTON-PRESSED in CB_DUMMY.PB_EXCEL, Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.P_FROM_DATE, Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.P_SALE_FROM_DATE, Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.P_SALE_TO_DATE, Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.P_TO_DATE | /api/v1/pld/disp_text | When a message and title are supplied, then an alert dialog is displayed using the appropriate alert object (error or note) |
| PLD-003 | RAISE_ERROR | Validation | Trigger: ON-ERROR in Form | /api/v1/pld/raise_error | When an error code is supplied, then the corresponding message is displayed and form trigger failure is raised for error-severity messages |


---

### D2kwutil.pld (`Win_API`)

*No routines from ``D2kwutil.pld`` are referenced in ``vr_cross_fmb.xml``.*

---

---

## 19. PCK-Backed Logic

*NO PCK files found - no ``*.pck`` source files were discovered in ``/app/workspace/vr_cross-4786ad3b8e90/in``. PCK-backed logic cannot be generated without uploaded PCK sources.*

---

## 20. System Interfaces

### 20.1 Database Integrations

| Interface Name | Type | Purpose | Data Flow | Error Handling |
| -------------- | ---- | ------- | --------- | -------------- |
| Workshop Job Card query (VH_RO / MULDMS.VH_RO) | Direct table read (SELECT) | Retrieves workshop job card records matching the user's search criteria; the primary driving table for cross-sell/upsell candidate identification | Inbound - job card data read from VH_RO into the on-screen results grid and the CSV export | Any SQL error is intercepted by the ON-ERROR trigger, displayed to the user via GENERAL.DISP_TEXT, rolled back, and the trigger aborted |
| Vehicle master query (GM_VIN / MULDMS.GM_VIN) | Direct table read (SELECT) | Provides vehicle model code, variant code, and invoice date linked to the job card by VIN, for model/variant description resolution and vehicle age calculation | Inbound - vehicle data joined to job card records and read into results | Errors handled by ON-ERROR trigger |
| Customer master query (GM_CIN) | Direct table read (SELECT) | Provides customer name, masked contact phone numbers, address details, and communication preference for the cross-sell candidate display | Inbound - customer data joined to job card records; address assembled via SF_GET_CUST_ADDRESS | If no customer record found, address resolver returns null silently; other errors handled by ON-ERROR |
| Extended warranty master query (MWAR_EXTE / MULDMS.MWAR_EXTE) | Direct table read (SELECT) | Provides extended warranty type and cancellation status for each vehicle; used to filter results by warranty status and display the warranty type | Inbound - optional join to job card/vehicle records; warranty type resolved against AM_LIST | No-data or null handled as "No Ext Warranty"; other errors handled by ON-ERROR |
| Reference list master query (AM_LIST) | Direct table read (SELECT) | Provides the job card status list (LIST_NAME = 'RO_STATUS1'), extended warranty type list (LIST_NAME = 'EXTE_WARR_TYPE'), and individual warranty type description lookups for result rows | Inbound - reference data read into form dropdown lists on initialisation; also read per row during View query to resolve warranty descriptions | Errors handled by ON-ERROR trigger |
| Model family list query (MULDMS.GM_MOD / GM_MOD) | Direct table read (SELECT) | Provides the list of vehicle model families for the model filter dropdown, and is used in the search query to filter by family model code | Inbound - model list read into record group on form load; also used as a subquery within the main search query | Errors handled by ON-ERROR trigger |
| Workshop/Location list query (AM_USER_DEALER_MASTER / AM_DEALER_LOC) | Direct table read (SELECT) | Provides the list of active workshop locations for the user's selection, filtered by user login, dealer type 'SERVICE', and location types '2S'/'3S' | Inbound - location list read into record group on demand when the user opens the location lookup | Errors handled by ON-ERROR trigger |
| Variant list query (MULDMS.GM_VAR / GM_VAR) | Direct table read (SELECT) | Provides vehicle variants for the variant filter dropdown, filtered by the selected model family and principal | Inbound - variant list read into record group on demand when the user opens the variant lookup | Errors handled by ON-ERROR trigger |
| Database session registration (DBMS_APPLICATION_INFO) | Oracle built-in package call | Tags the current database session with the form name for monitoring on form open; clears the session tags on form exit | Outbound - session metadata written to the database session at PRE-FORM and KEY-EXIT | No error handling in trigger code; silent on failure |

### 20.2 External System Integrations

The form does not integrate with any external systems beyond its direct Oracle database queries. It does not call web services, message queues, or external APIs. All data is read directly from the Oracle dealer management system database.

| System Name | Integration Type | Purpose | Protocol | Endpoint | Data Exchange | Success / Error Codes |
| ----------- | ---------------- | ------- | -------- | -------- | ------------- | --------------------- |
| N/A - no external system integrations | N/A | N/A | N/A | N/A | N/A | N/A |

### 20.3 Report Integrations

| Report Name | Report Server | Parameters | Output Format | Trigger |
| ----------- | ------------- | ---------- | ------------- | ------- |
| rep.rdf | INFERRED - Oracle Reports server | INFERRED - no PL/SQL-level call site found in the form source; report object is declared in the form XML (REPORT_CALL) but is not invoked by any active trigger code in the current form version | INFERRED - standard Oracle Reports output | No active trigger invokes this report in the current form; the REPORT_CALL report object is declared but never called; it may be a legacy placeholder from a prior version of the form |

---

### 20.3.1 Parameters Passed to the Report

This form does not pass parameters to an Oracle Report. No report parameters were identified in the form sources.

## 21. Procedure and Function Business Rule Catalogue

End-to-end business requirement specification for every stored procedure and function referenced by the VR_CROSS form.

### 21.1 Catalogue Index

69 procedures/functions - each SP ID links to its detailed specification in Section 21.2.

| SP Index | Routine Name |
| :--- | :--- |
| [SP-001](#SP-001--PROC_POP_LIST) | PROC_POP_LIST |
| [SP-002](#SP-002--VIEW_EXCEL_REP) | VIEW_EXCEL_REP |
| [SP-003](#SP-003--D2KWUTIL.ATTEMPT_DLL_LOAD) | D2KWUTIL.ATTEMPT_DLL_LOAD |
| [SP-004](#SP-004--D2KWUTIL.D2KWUTIL_DEBUGSTRING) | D2KWUTIL.D2KWUTIL_DEBUGSTRING |
| [SP-005](#SP-005--D2KWUTIL.D2KWUTIL_GETDOSENV) | D2KWUTIL.D2KWUTIL_GETDOSENV |
| [SP-006](#SP-006--D2KWUTIL.D2KWUTIL_GETREGKEY) | D2KWUTIL.D2KWUTIL_GETREGKEY |
| [SP-007](#SP-007--D2KWUTIL.TRANSLATETYPE) | D2KWUTIL.TRANSLATETYPE |
| [SP-008](#SP-008--GENERAL.ASK_CONFIRM) | GENERAL.ASK_CONFIRM |
| [SP-009](#SP-009--GENERAL.DISP_TEXT) | GENERAL.DISP_TEXT |
| [SP-010](#SP-010--GENERAL.RAISE_ERROR) | GENERAL.RAISE_ERROR |
| [SP-011](#SP-011--WEBUTIL.BLOCKING) | WEBUTIL.BLOCKING |
| [SP-012](#SP-012--WEBUTIL.CHECKLIBS) | WEBUTIL.CHECKLIBS |
| [SP-013](#SP-013--WEBUTIL.CLEARCALLBACKTRIGGER) | WEBUTIL.CLEARCALLBACKTRIGGER |
| [SP-014](#SP-014--WEBUTIL.CLOSEBLOB) | WEBUTIL.CLOSEBLOB |
| [SP-015](#SP-015--WEBUTIL.CLOSEFILE) | WEBUTIL.CLOSEFILE |
| [SP-016](#SP-016--WEBUTIL.DOWNLOADFROMURLINT) | WEBUTIL.DOWNLOADFROMURLINT |
| [SP-017](#SP-017--WEBUTIL.ERROR) | WEBUTIL.ERROR |
| [SP-018](#SP-018--WEBUTIL.ERRORALERT) | WEBUTIL.ERRORALERT |
| [SP-019](#SP-019--WEBUTIL.EXECUTE) | WEBUTIL.EXECUTE |
| [SP-020](#SP-020--WEBUTIL.FCLOSE) | WEBUTIL.FCLOSE |
| [SP-021](#SP-021--WEBUTIL.FOPEN) | WEBUTIL.FOPEN |
| [SP-022](#SP-022--WEBUTIL.GETCALLBACKTRIGGER) | WEBUTIL.GETCALLBACKTRIGGER |
| [SP-023](#SP-023--WEBUTIL.GETCLIENTOSFAMILY) | WEBUTIL.GETCLIENTOSFAMILY |
| [SP-024](#SP-024--WEBUTIL.GETCLIENTSETTING) | WEBUTIL.GETCLIENTSETTING |
| [SP-025](#SP-025--WEBUTIL.GETIMPLCLASS) | WEBUTIL.GETIMPLCLASS |
| [SP-026](#SP-026--WEBUTIL.GETLASTERROR) | WEBUTIL.GETLASTERROR |
| [SP-027](#SP-027--WEBUTIL.GETLASTERRORARGS) | WEBUTIL.GETLASTERRORARGS |
| [SP-028](#SP-028--WEBUTIL.GETNUMBER) | WEBUTIL.GETNUMBER |
| [SP-029](#SP-029--WEBUTIL.GETOSFAMILY) | WEBUTIL.GETOSFAMILY |
| [SP-030](#SP-030--WEBUTIL.GETOUTPUT) | WEBUTIL.GETOUTPUT |
| [SP-031](#SP-031--WEBUTIL.GETPROPERTY) | WEBUTIL.GETPROPERTY |
| [SP-032](#SP-032--WEBUTIL.GETSTRING) | WEBUTIL.GETSTRING |
| [SP-033](#SP-033--WEBUTIL.GETVAR) | WEBUTIL.GETVAR |
| [SP-034](#SP-034--WEBUTIL.GET_LINE) | WEBUTIL.GET_LINE |
| [SP-035](#SP-035--WEBUTIL.GET_STANDARD_OUTPUT) | WEBUTIL.GET_STANDARD_OUTPUT |
| [SP-036](#SP-036--WEBUTIL.ID_NULL) | WEBUTIL.ID_NULL |
| [SP-037](#SP-037--WEBUTIL.INIT) | WEBUTIL.INIT |
| [SP-038](#SP-038--WEBUTIL.INITWEBUTIL) | WEBUTIL.INITWEBUTIL |
| [SP-039](#SP-039--WEBUTIL.ISERROR) | WEBUTIL.ISERROR |
| [SP-040](#SP-040--WEBUTIL.IS_OPEN) | WEBUTIL.IS_OPEN |
| [SP-041](#SP-041--WEBUTIL.LENGTH) | WEBUTIL.LENGTH |
| [SP-042](#SP-042--WEBUTIL.LOG) | WEBUTIL.LOG |
| [SP-043](#SP-043--WEBUTIL.POPULATEPROPERTYBUNDLE) | WEBUTIL.POPULATEPROPERTYBUNDLE |
| [SP-044](#SP-044--WEBUTIL.PUT_LINE) | WEBUTIL.PUT_LINE |
| [SP-045](#SP-045--WEBUTIL.READFROMPROPERTYBUNDLE) | WEBUTIL.READFROMPROPERTYBUNDLE |
| [SP-046](#SP-046--WEBUTIL.READTRANSFROMMSGBUNDLE) | WEBUTIL.READTRANSFROMMSGBUNDLE |
| [SP-047](#SP-047--WEBUTIL.REGISTERBEAN) | WEBUTIL.REGISTERBEAN |
| [SP-048](#SP-048--WEBUTIL.REGISTER_FUNCTION) | WEBUTIL.REGISTER_FUNCTION |
| [SP-049](#SP-049--WEBUTIL.RELEASE_PROCESS) | WEBUTIL.RELEASE_PROCESS |
| [SP-050](#SP-050--WEBUTIL.SETCLIENTSETTING) | WEBUTIL.SETCLIENTSETTING |
| [SP-051](#SP-051--WEBUTIL.SETDATA) | WEBUTIL.SETDATA |
| [SP-052](#SP-052--WEBUTIL.SETPROPERTY) | WEBUTIL.SETPROPERTY |
| [SP-053](#SP-053--WEBUTIL.SHOWBEANS) | WEBUTIL.SHOWBEANS |
| [SP-054](#SP-054--WEBUTIL.WRITEDATA) | WEBUTIL.WRITEDATA |
| [SP-055](#SP-055--WEBUTIL_CORE.CUSTOMEVENTHANDLER) | WEBUTIL_CORE.CUSTOMEVENTHANDLER |
| [SP-056](#SP-056--ADD_ERROR) | ADD_ERROR |
| [SP-057](#SP-057--ADD_EXTERNAL_ERRORS) | ADD_EXTERNAL_ERRORS |
| [SP-058](#SP-058--BOOLTOCHAR) | BOOLTOCHAR |
| [SP-059](#SP-059--CLEAN_ERROR_STACK) | CLEAN_ERROR_STACK |
| [SP-060](#SP-060--DEBUGLOG) | DEBUGLOG |
| [SP-061](#SP-061--GET_ENVIRONMENT_STRING) | GET_ENVIRONMENT_STRING |
| [SP-062](#SP-062--READ_REGISTRY) | READ_REGISTRY |
| [SP-063](#SP-063--REGISTER_FUNCTION_CALL) | REGISTER_FUNCTION_CALL |
| [SP-064](#SP-064--SETDEBUG) | SETDEBUG |
| [SP-065](#SP-065--SF_GET_CUST_ADDRESS) | SF_GET_CUST_ADDRESS |
| [SP-066](#SP-066--SF_GET_MODEL_DESC) | SF_GET_MODEL_DESC |
| [SP-067](#SP-067--SF_GET_VARIANT_DESC) | SF_GET_VARIANT_DESC |
| [SP-068](#SP-068--STRIPDIRSEP) | STRIPDIRSEP |
| [SP-069](#SP-069--WINDEBUG) | WINDEBUG |

---

### 21.2 Detailed Specifications

#### SP-001 - PROC_POP_LIST

**Invoked From:**

- vr_cross_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

Search Criteria (N/A / CN_MAIN)

---

**Purpose**

PROC_POP_LIST populates a named list item on the Search Criteria screen (CN_MAIN) with coded lookup values retrieved from the AM_LIST table. It accepts a list item name as input, constructs the appropriate SQL query for the requested list, creates a record group from that query if one does not already exist, and binds the resulting data to the corresponding list item. The procedure is invoked once during form initialisation via the WHEN-NEW-FORM-INSTANCE trigger.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_name | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-036](#SP-036--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameter p_name, which identifies the target list item to be populated.
- Step 2 - Evaluate p_name against known list item identifiers to determine which record group and SQL statement to prepare.
- Step 3 - If p_name equals 'P_EW_STATUS', assign the record group name 'ew_status' and build a UNION query that retrieves extended warranty type descriptions and codes from AM_LIST (filtered by LIST_NAME = 'EXTE_WARR_TYPE' and the current principal), a hardcoded 'ALL' / 'ALL' row from DUAL, and a hardcoded 'No Ext Warranty' / 'NOEW' row from DUAL, ordered by a serial number column.
- Step 4 - If p_name equals 'P_JC_STATUS1', assign the record group name 'jc_status' and build a UNION query that retrieves job-card status descriptions and codes from AM_LIST (filtered by LIST_NAME = 'RO_STATUS1', excluding LIST_CODE 20, and filtered by the current principal), plus a hardcoded 'ALL' / '999' row from DUAL, ordered by serial number and list code.
- Step 5 - If a SQL statement was produced (lv_sql IS NOT NULL), attempt to locate an existing record group with the assigned name using FIND_GROUP.
- Step 6 - If the record group does not yet exist (evaluated via WEBUTIL.ID_NULL), create it from the prepared query using CREATE_GROUP_FROM_QUERY, populate it by executing POPULATE_GROUP, and bind it to the target list item using POPULATE_LIST.

---
**Decision Points**

DP-001

Condition: p_name = 'P_EW_STATUS'

TRUE: Set rg_name to 'ew_status' and build the extended-warranty-status UNION query against AM_LIST (LIST_NAME = 'EXTE_WARR_TYPE') and DUAL, assigning the result to lv_sql.

FALSE: Skip this block; lv_sql remains unchanged.

---

DP-002

Condition: p_name = 'P_JC_STATUS1'

TRUE: Set rg_name to 'jc_status' and build the job-card-status UNION query against AM_LIST (LIST_NAME = 'RO_STATUS1', LIST_CODE NOT IN (20)) and DUAL, assigning the result to lv_sql.

FALSE: Skip this block; lv_sql remains unchanged.

---

DP-003

Condition: lv_sql IS NOT NULL

TRUE: Proceed to locate or create the record group and populate the list item.

FALSE: No record group or list population is attempted; the procedure exits without action.

---

DP-004

Condition: WEBUTIL.ID_NULL(rg_id) - the record group identified by rg_name does not yet exist in the form

TRUE: Create the record group from the query (CREATE_GROUP_FROM_QUERY), execute the query to populate the group (POPULATE_GROUP), and bind the group to the list item (POPULATE_LIST).

FALSE: The record group already exists; no creation or re-population is performed.

---
**Database Interactions**

- DB-001 - Read AM_LIST - Reads data from AM_LIST for lookup or validation.
- DB-002 - Read DUAL - Reads data from DUAL for lookup or validation.
- DB-003 - Read GM_EMP - Reads data from GM_EMP for lookup or validation.
**Business Rules**

- BR-001 - List item population is driven exclusively by the value of p_name; only the list identifiers 'P_EW_STATUS' and 'P_JC_STATUS1' are recognised and handled by this procedure.
- BR-002 - All AM_LIST queries must be filtered by the current session's principal (:global.principal) to ensure that only lookup values applicable to the active principal are presented to the user.
- BR-003 - The extended-warranty-status list (P_EW_STATUS) must always include a catch-all option ('ALL' / 'ALL') and a no-warranty option ('No Ext Warranty' / 'NOEW') in addition to the principal-specific AM_LIST entries, ordered so that 'ALL' appears first, 'No Ext Warranty' second, and AM_LIST entries third.
- BR-004 - The job-card-status list (P_JC_STATUS1) must exclude LIST_CODE 20 from AM_LIST and must always include a catch-all option ('ALL' / '999') as the first entry; remaining entries are ordered by list code.
- BR-005 - A record group is created and populated only once per form session; if a record group with the target name already exists, the procedure does not recreate or repopulate it, preventing duplicate or redundant database reads.

---
**Implementation Logic**

```plsql
PROCEDURE PROC_POP_list (p_name varchar2) IS
	lv_query varchar2(2000);
 	rg_name varchar2(40);
	rg_id   recordgroup;
	gc_id   groupcolumn;
	lv_count number;
	lv_del_row number;
	lv_error varchar2(100);
	lv_sql varchar2(2000);
	lv_def_val varchar2(200);
	lv_mn varchar2(400);
BEGIN
	      IF p_name= 'P_EW_STATUS' THEN
					 rg_name := 'ew_status';                 
           lv_sql:= 'SELECT LIST_DESC, LIST_CODE, 3 SRL '
           					||'FROM AM_LIST  WHERE LIST_NAME = ''EXTE_WARR_TYPE'' and 
           					principal_map_cd='''||:global.principal||''' 
									UNION ALL
									SELECT ''ALL'' LIST_DESC, ''ALL'' LIST_CODE, 1 SRL FROM DUAL 
									UNION ALL
									SELECT ''No Ext Warranty'' LIST_DESC, ''NOEW'' LIST_CODE, 2 SRL FROM DUAL 
									ORDER BY SRL';      
	      end if;   /*pmc changes by bhawana*/ 
	      if p_name = 'P_JC_STATUS1' then
	      	 rg_name := 'jc_status';                 
	      	 lv_sql := 'select LIST_DESC, LIST_CODE, 2 SRL '
	      	 			|| 'from am_list 
	      				where list_name = ''RO_STATUS1'' 
	      				AND LIST_CODE NOT IN (20)
	      				and 	principal_map_cd='''||:global.principal||''' 
								UNION ALL
								SELECT ''ALL'', ''999'', 1 SRL FROM DUAL
								ORDER BY SRL , list_code';
	      end if;
	 		if lv_sql is not null then
				rg_id := find_group(rg_name);
				if id_null(rg_id) then
						rg_id := Create_Group_From_Query( rg_name, lv_sql);
						lv_error := populate_group(rg_id);
						populate_list(p_name,rg_id);
				end if;   
		end if;
END;

/*
	     	lv_sql := 'select '||''''||'ALL'||''''||' name,'||''''||'ALL'||''''
                    ||' code from dual union '
                    ||' SELECT EMP_NAME name, EMP_CD code from GM_EMP '  
										||' WHERE dealer_map_cd = '||:p_all_dealers ||' 
										AND loc_cd='||''''||:params.p_loc||''''||
										'AND EMP_DESG_CD IN (''DRI'',''DRV'') Order by name';
*/
```

#### SP-002 - VIEW_EXCEL_REP

**Invoked From:**

- vr_cross_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

Search Criteria (N/A / CN_MAIN)

---

**Purpose**

Generates a CSV-formatted Excel report from a dynamic SQL query and streams it to the user's browser. The procedure builds a record group from the supplied query, writes each row's designated column value to a server-side CSV file, resolves the public URL path for that file from a configuration text file, and then opens the document in a new browser window via the WebUtil file utilities.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_file_name | VARCHAR2 | IN |
| p_query | VARCHAR2 | IN |
| p_column_name | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.FCLOSE ([SP-020](#SP-020--WEBUTIL.FCLOSE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.FOPEN ([SP-021](#SP-021--WEBUTIL.FOPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_LINE ([SP-034](#SP-034--WEBUTIL.GET_LINE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ID_NULL ([SP-036](#SP-036--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.PUT_LINE ([SP-044](#SP-044--WEBUTIL.PUT_LINE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Retrieve the current Oracle Forms user ID from the global variable ':global.userid' and construct a unique CSV filename by concatenating the user ID with the current date-time stamp (format YYYYMMDDHHMISS) and the '.csv' extension.
- Step 2 - Assign the generated filename to the FILENAME variable. If the filename is NULL, no assignment is made and processing continues with a null filename.
- Step 3 - Validate the FILENAME for embedded spaces in the folder path. If a space is detected (INSTR > 0), redirect the file to the root of the C:\ drive using only the base filename, and display a warning message informing the user of the fallback location.
- Step 4 - Check whether a record group named 'DataRecordSet' already exists using FIND_GROUP. If it does, delete it with DELETE_GROUP to avoid conflicts before creating a new one.
- Step 5 - Create a new record group named 'DataRecordSet' from the dynamic SQL supplied in p_query using CREATE_GROUP_FROM_QUERY, then populate it with POPULATE_GROUP.
- Step 6 - Retrieve the total row count of the populated record group using GET_GROUP_ROW_COUNT.
- Step 7 - Check whether the row count exceeds the Excel row limit of 65,536. If it does, display a truncation warning to the user and cap the row count at 65,535.
- Step 8 - Construct the server-side file path by prepending '/iashome/ias/reports/printer/' to the base filename extracted from FILENAME.
- Step 9 - Open the URL configuration file '/reports/DMS/excelpath.txt' in read mode using WEBUTIL.FOPEN (TEXT_IO.FOPEN), read the URL base path with WEBUTIL.GET_LINE (TEXT_IO.GET_LINE), and close the file with WEBUTIL.FCLOSE (TEXT_IO.FCLOSE).
- Step 10 - Construct the full public URL (formserverpath) by concatenating the URL base path retrieved in Step 9 with the base filename.
- Step 11 - Open the server-side CSV file for writing using WEBUTIL.FOPEN (TEXT_IO.FOPEN).
- Step 12 - Locate the target column in the record group using FIND_COLUMN with the composite name 'DataRecordSet.<p_column_name>'.
- Step 13 - Iterate over all rows (up to the capped row count) and write each cell value retrieved via GET_GROUP_CHAR_CELL to the CSV file using WEBUTIL.PUT_LINE (TEXT_IO.PUT_LINE).
- Step 14 - Close the CSV file using WEBUTIL.FCLOSE (TEXT_IO.FCLOSE) and open the generated report in a new browser window using WEB.SHOW_DOCUMENT with the target '_blank'.
- Step 15 - If any unhandled exception occurs during processing, display an error message containing the Oracle error code and error text, then raise FORM_TRIGGER_FAILURE to halt form processing.

---
**Decision Points**

DP-001

Condition:
The generated vcFile value is NULL.

TRUE:
No filename assignment is performed; the FILENAME variable remains unset.

FALSE:
The FILENAME variable is assigned the value of vcFile.

---

DP-002

Condition:
The FILENAME path contains one or more space characters in a folder name (INSTR(FILENAME,' ') > 0).

TRUE:
The FILENAME is redirected to 'C:\' concatenated with only the base filename (last segment after the final backslash), and a warning message is displayed to the user advising of the fallback storage location.

FALSE:
The FILENAME path is used as constructed without modification.

---

DP-003

Condition:
A record group named 'DataRecordSet' already exists (NOT ID_NULL(rg_id)).

TRUE:
The existing record group is deleted via DELETE_GROUP before a new one is created.

FALSE:
No deletion is performed; processing continues directly to CREATE_GROUP_FROM_QUERY.

---

DP-004

Condition:
The populated record group row count exceeds 65,536 rows.

TRUE:
A truncation warning message is displayed to the user and the effective row count is capped at 65,535 to comply with the Excel row limit.

FALSE:
All rows are written to the CSV file without truncation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The CSV filename must be unique per user session; it is derived by concatenating the current user ID with the system date-time stamp (YYYYMMDDHHMISS) and the '.csv' extension to prevent file collisions.
- BR-002 - A file path containing spaces in any folder name is not permitted; the system automatically redirects the output file to the C:\ root directory and notifies the user.
- BR-003 - Any pre-existing record group named 'DataRecordSet' must be destroyed before a new one is created to ensure the report reflects only the current query results.
- BR-004 - The maximum number of rows written to the Excel CSV file is capped at 65,535 to respect the Excel worksheet row limit; any excess rows are silently truncated after a user warning.
- BR-005 - The public URL base path for the generated report file must be read at runtime from the server-side configuration file '/reports/DMS/excelpath.txt'; it is not hard-coded in the procedure.
- BR-006 - The report is opened in a new browser window (target '_blank') so that the current Oracle Forms session remains active and uninterrupted.
- BR-007 - Any unhandled runtime exception must surface the Oracle error code and error text to the user and terminate form trigger execution via FORM_TRIGGER_FAILURE, preventing silent failures.

---
**Implementation Logic**

```plsql
PROCEDURE view_excel_rep(p_file_name VARCHAR2 DEFAULT NULL, 
 												 p_query VARCHAR2,
 												 p_column_name VARCHAR2) 
IS	
  rg_name 				 		VARCHAR2(40) := 'DataRecordSet'; 
	rg_id 					 		RecordGroup; 
	gc_id 					 		GroupColumn; 
	urlFile1        TEXT_IO.FILE_TYPE;
	the_rowcount 		 		NUMBER;
	po_err_msg    VARCHAR2 (3000);
	po_err_cd     NUMBER (10);
	low           NUMBER (10);
	high          NUMBER (10);
	remainder     NUMBER (10);

	vcfile varchar2(150);
	lv_user  varchar2(150);
	v_string varchar2(5000);
	bin_str varchar2(250);
	errcode 				 		NUMBER; 
  FILENAME			   		VARCHAR2(4000);
  MYFILE 					 		TEXT_IO.FILE_TYPE;
  urlFile 					 	TEXT_IO.FILE_TYPE;
  urlPath							VARCHAR2(5000);
	l_alert 				 		NUMBER;
	server_file      		VARCHAR2(2000);
	file_transfer_bool	BOOLEAN;
	formserverpath   		VARCHAR2(2000);

begin
	lv_user := name_in(':global.userid'); 
	vcFile:= lv_user||To_Char(Sysdate,'YYYYMMDDHHMISS'); 
	vcFile := vcFile||'.csv';

	if vcFile is null then
		null;
	else
		filename:=vcFile;
	end if;
	
	If instr(FILENAME,' ') > 0 then
 		FILENAME := 'C:\'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
 		Message('File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default.');
 		message('  ');
	end if;

	rg_id := Find_Group( rg_name ); 
	IF NOT Id_Null(rg_id) THEN 
		Delete_Group( rg_id ); 
	END IF; 
	
	rg_id := Create_Group_From_Query( rg_name, p_query ); 
	errcode := Populate_Group( rg_id ); 
	the_rowcount := Get_Group_Row_Count( rg_id );
	
	IF the_rowcount > 65536 THEN  
		Message('Maximum number of rows in excel exceeded. It will truncate to 65535 rows.');
		Message('  ');
		CLEAR_MESSAGE;
		the_rowcount := 65535;
	END IF;
--message('1 '||filename);	
	server_file := '/iashome/ias/reports/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
--message('2 '||server_file);
	urlFile := Text_Io.Fopen('/reports/DMS/excelpath.txt','R');
--message('3');	
	Text_Io.Get_Line(urlFile,urlPath);
	Text_Io.Fclose(urlFile);
--message('4');	
	formserverpath := urlPath||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	MYFILE := TEXT_IO.FOPEN(server_file, 'W');
--message('5');	
	gc_id := Find_Column( rg_name||'.'||p_column_name); 	
--message('6');
	for total_loop IN 1..the_rowcount
		loop
	  	V_STRING :=  GET_GROUP_CHAR_CELL(gc_id  , total_loop ); 
	  	text_io.put_line(myfile,v_string);
	end loop;
    text_io.fclose(myfile);   
	 	web.show_document(formserverpath,'_blank');
--message('7');
exception when others then
		Message('Error  - '||ERROR_CODE|| ERROR_TEXT);
		Raise Form_trigger_failure;
end;
```

#### SP-003 - D2KWUTIL.ATTEMPT_DLL_LOAD

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Attempts to load a specified DLL into memory via ORA_FFI, optionally verifying the file's physical existence at a given path before loading. The procedure normalises the supplied directory path, confirms the target DLL file is accessible, loads the library, and-when instructed-increments the module-level load counter and marks the API as enabled. It returns the resulting library handle to the caller (REGISTER_FUNCTION_CALL), or a null handle if any step fails.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |
| TargetDLL | VARCHAR2 | IN |
| LoadCount | BOOLEAN | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |

---

**Dependencies**

- DEBUGLOG ([SP-060](#SP-060--DEBUGLOG)) - matched by member name
- STRIPDIRSEP ([SP-068](#SP-068--STRIPDIRSEP)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate whether TargetPath has been supplied. If it is null, skip file-existence validation and proceed directly to the library load attempt.
- Step 2 - If TargetPath is not null, normalise the path by passing it to STRIPDIRSEP to remove any trailing directory separator, then append a single backslash ('\') to produce a consistently formatted directory path. This guards against callers supplying multiple concatenated paths; only the value returned by STRIPDIRSEP is used.
- Step 3 - Attempt to open the file at the normalised path combined with TargetDLL using TEXT_IO.FOPEN in read mode ('R'). If the file opens successfully, immediately close it with TEXT_IO.FCLOSE-this step serves solely as a physical existence check.
- Step 4 - If the file cannot be opened (any exception), invoke DEBUGLOG at severity level 99, identifying the procedure as 'Attempt_DLL_LOAD' and recording that TargetDLL was not found at the specified TargetPath. Then raise the BadLocation exception to abort further processing.
- Step 5 - Call ORA_FFI.LOAD_LIBRARY with TargetPath and TargetDLL to load the DLL and capture the returned library handle in hDLL.
- Step 6 - If the LoadCount flag is TRUE, increment the module-level counter DLL_LOAD_COUNT by 1 and set the module-level flag API_ENABLED to TRUE.
- Step 7 - Return hDLL to the caller.
- Step 8 - If any unhandled exception occurs during the load or counter update (outer exception handler), set API_ENABLED to FALSE and return hDLL (which will be null at that point).

---
**Decision Points**

DP-001

Condition: TargetPath IS NOT NULL

TRUE: Normalise TargetPath via STRIPDIRSEP, append a backslash, and perform a physical file-existence check before attempting the library load.

FALSE: Skip path normalisation and file-existence validation; proceed directly to ORA_FFI.LOAD_LIBRARY using the null path.

---

DP-002

Condition: TEXT_IO.FOPEN succeeds for the combination of TargetPath and TargetDLL.

TRUE: Close the file handle immediately and continue to the library load step.

FALSE: Log a severity-99 debug message via DEBUGLOG identifying the missing file and its expected location, then raise BadLocation to halt execution.

---

DP-003

Condition: LoadCount parameter is TRUE.

TRUE: Increment DLL_LOAD_COUNT by 1 and set API_ENABLED to TRUE.

FALSE: Leave DLL_LOAD_COUNT and API_ENABLED unchanged.

---

DP-004

Condition: An unhandled exception is raised during ORA_FFI.LOAD_LIBRARY or the LoadCount update block.

TRUE: Set API_ENABLED to FALSE and return a null library handle to the caller.

FALSE: Return the valid hDLL library handle to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - TargetPath must be normalised to a single, consistently formatted directory path before use; any extraneous content beyond what STRIPDIRSEP returns is discarded and a single backslash separator is always appended.
- BR-002 - When TargetPath is provided, the physical existence of the target DLL file at that path must be confirmed before a load is attempted; a DLL that cannot be opened for reading is treated as absent and the load is rejected.
- BR-003 - A failed file-existence check must be recorded via DEBUGLOG at severity level 99, capturing the procedure name, the DLL name, and the path that was searched, before the BadLocation exception is raised.
- BR-004 - A successful DLL load increments the module-level DLL_LOAD_COUNT counter and sets API_ENABLED to TRUE only when the LoadCount flag is explicitly passed as TRUE; callers may suppress this tracking by passing FALSE.
- BR-005 - Any unhandled exception during the load sequence must result in API_ENABLED being set to FALSE and a null library handle being returned, ensuring the caller can detect a failed load without an unhandled exception propagating further.

---
**Implementation Logic**

```plsql

FUNCTION  Attempt_DLL_Load  (TargetPath in out VARCHAR2, TargetDLL in VARCHAR2, LoadCount in BOOLEAN DEFAULT TRUE) return ORA_FFI.LibHandleType is
  hDLL  ORA_FFI.LibHandleType;
  hFile TEXT_IO.FILE_TYPE;
begin 
    	
  if TargetPath is not null then 
    -- Watch out for folks who put multiple Paths in here 
    -- Oh yes it's happened! Just use the first & throw the rest away
    -- Add trailing Directory Sep if required
    TargetPath := StripDirSep(TargetPath)||'\';
    
    -- Check that there is actually a file there.
    begin 
  	  hFile := TEXT_IO.FOPEN(TargetPath||TargetDLL,'R');
  	  TEXT_IO.FCLOSE(hFile);
    exception
  	  when others then
  	    Win_API_Debug.DebugLog(99,'Attempt_DLL_LOAD',TargetDLL||' not found in the specified location of "'||TargetPath||'"'); 
  		  raise BadLocation;
    end;
  end if;
  
  hDLL := ORA_FFI.LOAD_LIBRARY(TargetPath, TargetDLL);
  if LoadCount then 
    DLL_LOAD_COUNT  := DLL_LOAD_COUNT + 1;
    API_ENABLED  := TRUE;
  end if;
  return hDLL;
exception
  when others then 
    API_ENABLED := FALSE;
    return hDLL; /* Will be null */
end Attempt_DLL_Load;
```

#### SP-004 - D2KWUTIL.D2KWUTIL_DEBUGSTRING

**Invoked From:**

- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level interface to the native C-based debug string utility within the D2KWUTIL library. When invoked by WINDEBUG, this procedure passes a text message and a foreign-function handle to the underlying C implementation (via ORA_FFI pragma interface), enabling debug output to be written through the Oracle Forms foreign-function interface layer.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the foreign-function handle (hFunc) identifying the registered C function entry point within the D2KWUTIL library, and the text string (Text) containing the debug message to be output.
- Step 2 - Delegate execution entirely to the bound C routine identified by pragma interface code 11265, passing hFunc and Text directly as arguments.
- Step 3 - The C routine handles the physical output of the debug string; no return value or output parameter is produced back to the caller.

---
**Decision Points**

No decision points are present in this procedure. Execution follows a single unconditional delegation path to the underlying C routine via the ORA_FFI pragma interface.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must be called with a valid ORA_FFI function handle (hFunc) that has been registered against the D2KWUTIL C library prior to invocation; the handle is not validated within this procedure.
- BR-002 - The Text parameter carries the debug message exactly as supplied by the caller; no formatting, truncation, or transformation is applied within this procedure.
- BR-003 - This procedure is declared with PRAGMA INTERFACE(C, ..., 11265), meaning its entire execution is fulfilled by the external C implementation; no PL/SQL business logic executes beyond the handoff.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.
   
 PROCEDURE d2kwutil_DebugString (    hFunc       IN      ORA_FFI.funcHandleType,
                                     Text        IN      VARCHAR2);
 -- Pragmas
 PRAGMA INTERFACE(C,d2kwutil_DebugString,      11265);
```

#### SP-005 - D2KWUTIL.D2KWUTIL_GETDOSENV

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level foreign-function interface (FFI) wrapper that retrieves a DOS/operating-system environment variable value. It accepts a function handle and a source environment variable name, then populates an expansion buffer with the resolved value, returning an integer status code to the caller. It is invoked exclusively by the GET_ENVIRONMENT_STRING stored procedure in D2kwutil.pld.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| SourceStr | VARCHAR2 | IN OUT |
| ExpandStr | VARCHAR2 | IN OUT |
| InBuffLen | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| SourceStr | VARCHAR2 | IN OUT |
| ExpandStr | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that references the underlying OS-level routine responsible for environment variable resolution.
- Step 2 - Accept the source environment variable name (SourceStr) as an IN OUT parameter, making it available for the foreign function call.
- Step 3 - Accept the expansion buffer (ExpandStr) as an IN OUT parameter; this buffer will be populated with the resolved environment variable value by the foreign function.
- Step 4 - Accept the input buffer length (InBuffLen) that defines the maximum number of characters the expansion buffer can hold, preventing overflow.
- Step 5 - Delegate execution to the foreign function identified by hFunc, passing SourceStr, ExpandStr, and InBuffLen as arguments.
- Step 6 - Return a PLS_INTEGER status code to the caller (GET_ENVIRONMENT_STRING) indicating the success or failure of the environment variable lookup.

---
**Decision Points**

No deterministic decision points are derivable from the available specification. The function signature exposes no conditional branching logic; all decision-making is delegated to the foreign function referenced by hFunc and interpreted by the calling routine GET_ENVIRONMENT_STRING.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be invoked with a valid ORA_FFI function handle (hFunc); the handle must reference the OS environment-variable resolution routine before the call is made.
- BR-002 - The caller is responsible for supplying InBuffLen equal to or less than the actual allocated size of ExpandStr to prevent buffer overflow during environment variable expansion.
- BR-003 - Both SourceStr and ExpandStr are declared IN OUT, meaning the foreign function may modify either value; the caller must treat both as potentially altered after the function returns.
- BR-004 - The integer return value is the sole indicator of call outcome and must be evaluated by the invoking routine (GET_ENVIRONMENT_STRING) to determine whether the environment variable was successfully resolved.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_GetDOSEnv (   hFunc          IN      ORA_FFI.funcHandleType,
                                SourceStr      IN OUT  VARCHAR2,
                                ExpandStr      IN OUT  VARCHAR2,
                                InBuffLen      IN      PLS_INTEGER
                                ) RETURN PLS_INTEGER;
```

#### SP-006 - D2KWUTIL.D2KWUTIL_GETREGKEY

**Invoked From:**

- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

D2KWUTIL_GETREGKEY is a foreign-function interface (FFI) wrapper that retrieves a Windows registry key value. Given a registry root, path, and entry name, it calls the underlying native function handle (hFunc) to read the corresponding registry value into RegValue, returning an integer status code that indicates whether the retrieval succeeded.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| RegRoot | PLS_INTEGER | IN |
| RegPath | VARCHAR2 | IN OUT |
| RegEntry | VARCHAR2 | IN OUT |
| RegValue | VARCHAR2 | IN OUT |
| RegValueLength | PLS_INTEGER | IN |
| RegDontExpand | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RegPath | VARCHAR2 | IN OUT |
| RegEntry | VARCHAR2 | IN OUT |
| RegValue | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that references the native Windows registry-read routine, along with the registry root identifier (RegRoot), registry path (RegPath), registry entry name (RegEntry), the buffer length for the returned value (RegValueLength), and a flag indicating whether environment-variable expansion should be suppressed (RegDontExpand).
- Step 2 - Delegate execution to the native function referenced by hFunc, passing all supplied parameters, to perform the low-level Windows registry lookup.
- Step 3 - Receive the registry value string back into the IN OUT parameter RegValue, and receive any normalised or resolved forms of RegPath and RegEntry back through their respective IN OUT parameters.
- Step 4 - Return a PLS_INTEGER status code to the caller (READ_REGISTRY in D2kwutil.pld) indicating the outcome of the registry read operation.

---
**Decision Points**

No decision points are deterministically evidenced in the available source. The function specification contains no conditional branching; all control-flow decisions are delegated to the native function invoked via the hFunc FFI handle.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be invoked with a valid ORA_FFI.funcHandleType handle (hFunc); the handle must be initialised by the caller before this function is called, as no internal handle initialisation is performed.
- BR-002 - RegRoot must be supplied as a PLS_INTEGER representing a valid Windows registry root constant (e.g. HKEY_LOCAL_MACHINE); no defaulting or validation of this value is performed within the function.
- BR-003 - RegValueLength must accurately reflect the maximum buffer size allocated for RegValue; the native function uses this length to bound the value it writes, preventing buffer overrun.
- BR-004 - RegDontExpand controls whether REG_EXPAND_SZ environment-variable references within the registry value are expanded; the caller is responsible for passing the correct flag to obtain the desired expansion behaviour.
- BR-005 - RegPath and RegEntry are declared IN OUT, meaning the native function may normalise or modify these strings; callers must not assume the values are unchanged after the call.
- BR-006 - The integer return value must be inspected by the caller (READ_REGISTRY) to determine success or failure; this function does not raise exceptions internally based on the available specification.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_GetRegKey (    hFunc         IN      ORA_FFI.funcHandleType,
                                RegRoot        IN      PLS_INTEGER,
                                RegPath        IN OUT  VARCHAR2,
                                RegEntry       IN OUT  VARCHAR2,
                                RegValue       IN OUT  VARCHAR2,
                                RegValueLength IN      PLS_INTEGER,
                                RegDontExpand	 IN      PLS_INTEGER
                                ) return PLS_INTEGER;
```

#### SP-007 - D2KWUTIL.TRANSLATETYPE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

TranslateType is a lookup function that converts a string-based C data type name (supplied by the caller) into the corresponding ORA_FFI integer constant. It is used internally by REGISTER_FUNCTION_CALL to resolve human-readable type tokens into the numeric type identifiers required by the ORA_FFI foreign-function interface layer before registering an external function call.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DataType | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameter DataType (VARCHAR2) representing a C data type token (e.g., 'INT', '*CHAR', 'DOUBLE').
- Step 2 - Convert the input value to uppercase and store it in the local variable vcType to ensure case-insensitive matching.
- Step 3 - Evaluate vcType against each recognised type token in a sequential IF-ELSIF chain.
- Step 4 - For the matching token, assign the corresponding ORA_FFI integer constant to the local return variable iRC (e.g., ORA_FFI.C_CHAR_PTR, ORA_FFI.C_INT, ORA_FFI.C_LONG_PTR, etc.).
- Step 5 - Return the resolved ORA_FFI integer constant (iRC) to the caller.

---
**Decision Points**

DP-001
Condition: vcType = '*CHAR'
TRUE: iRC is assigned ORA_FFI.C_CHAR_PTR.
FALSE: Evaluation continues to the next condition.

DP-002
Condition: vcType = 'CHAR'
TRUE: iRC is assigned ORA_FFI.C_CHAR.
FALSE: Evaluation continues to the next condition.

DP-003
Condition: vcType = '*INT'
TRUE: iRC is assigned ORA_FFI.C_INT_PTR.
FALSE: Evaluation continues to the next condition.

DP-004
Condition: vcType = 'INT'
TRUE: iRC is assigned ORA_FFI.C_INT.
FALSE: Evaluation continues to the next condition.

DP-005
Condition: vcType = '*LONG'
TRUE: iRC is assigned ORA_FFI.C_LONG_PTR.
FALSE: Evaluation continues to the next condition.

DP-006
Condition: vcType = 'LONG'
TRUE: iRC is assigned ORA_FFI.C_LONG.
FALSE: Evaluation continues to the next condition.

DP-007
Condition: vcType = '*SHORT' OR vcType = '*BYTE'
TRUE: iRC is assigned ORA_FFI.C_SHORT_PTR.
FALSE: Evaluation continues to the next condition.

DP-008
Condition: vcType = 'SHORT' OR vcType = 'BYTE'
TRUE: iRC is assigned ORA_FFI.C_SHORT.
FALSE: Evaluation continues to the next condition.

DP-009
Condition: vcType = '*DOUBLE'
TRUE: iRC is assigned ORA_FFI.C_DOUBLE_PTR.
FALSE: Evaluation continues to the next condition.

DP-010
Condition: vcType = 'DOUBLE'
TRUE: iRC is assigned ORA_FFI.C_DOUBLE.
FALSE: Evaluation continues to the next condition.

DP-011
Condition: vcType = '*VOID'
TRUE: iRC is assigned ORA_FFI.C_VOID_PTR.
FALSE: No assignment is made; iRC remains NULL and is returned as-is.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The DataType input is treated as case-insensitive; the function converts it to uppercase before matching, so tokens such as 'int', 'INT', and 'Int' are all treated equivalently.
- BR-002 - The tokens '*SHORT' and '*BYTE' are treated as synonymous and both resolve to ORA_FFI.C_SHORT_PTR.
- BR-003 - The tokens 'SHORT' and 'BYTE' are treated as synonymous and both resolve to ORA_FFI.C_SHORT.
- BR-004 - If the supplied DataType token does not match any of the recognised values, the function returns NULL (iRC is never assigned), and no error is raised; the caller is responsible for handling a NULL return value.
- BR-005 - The function supports exactly eleven recognised type tokens: '*CHAR', 'CHAR', '*INT', 'INT', '*LONG', 'LONG', '*SHORT' / '*BYTE', 'SHORT' / 'BYTE', '*DOUBLE', 'DOUBLE', and '*VOID'; no other tokens are mapped.

---
**Implementation Logic**

```plsql
 
FUNCTION TranslateType(DataType in VARCHAR2) return PLS_INTEGER is
   -- Just a simple lookup of the types.
   vcType VARCHAR2(10) := UPPER(DataType);
   iRC    PLS_INTEGER;
begin 
  if vcType = '*CHAR' then 
    iRC := ORA_FFI.C_CHAR_PTR;
  elsif vcType = 'CHAR' then 
    iRC := ORA_FFI.C_CHAR;
  elsif vcType = '*INT' then 
    iRC := ORA_FFI.C_INT_PTR;
  elsif vcType = 'INT' then 
    iRC := ORA_FFI.C_INT;
  elsif vcType = '*LONG' then 
    iRC := ORA_FFI.C_LONG_PTR;
  elsif vcType = 'LONG' then 
    iRC := ORA_FFI.C_LONG;
  elsif vcType = '*SHORT' or vcType = '*BYTE'  then 
    iRC := ORA_FFI.C_SHORT_PTR;
  elsif vcType = 'SHORT' or vcType = 'BYTE' then 
    iRC := ORA_FFI.C_SHORT;
  elsif vcType = '*DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE_PTR;
  elsif vcType = 'DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE;  
  elsif vcType = '*VOID' then 
    iRC := ORA_FFI.C_VOID_PTR;      
  end if;
return iRC;
end TranslateType;
```

#### SP-008 - GENERAL.ASK_CONFIRM

**Invoked From:**

- vr_cross_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

N/A

---

**Purpose**

Displays a named confirmation alert (AL_CONFIRM) to the user with a caller-supplied message and returns a numeric flag indicating which button the user pressed. The function allows calling triggers to branch their processing based on whether the user confirmed or cancelled an action.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| confirm_msg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the confirmation message text via the confirm_msg input parameter.
- Step 2 - Set the message text of the predefined alert AL_CONFIRM to the value of confirm_msg using set_alert_property.
- Step 3 - Display the AL_CONFIRM alert to the user and capture the button pressed in the local variable p_albtn_pressed via show_alert.
- Step 4 - Evaluate the captured button response: if the user pressed ALERT_BUTTON1, return 1 to indicate confirmation; otherwise return 0 to indicate cancellation.

---
**Decision Points**

DP-001

Condition:
p_albtn_pressed equals ALERT_BUTTON1 (the first/affirmative button on the AL_CONFIRM alert).

TRUE:
The function returns 1, signalling to the caller that the user confirmed the action.

FALSE:
The function returns 0, signalling to the caller that the user did not confirm the action (cancelled or dismissed).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The alert used for confirmation must be the predefined alert named AL_CONFIRM; no other alert name is used by this function.
- BR-002 - The confirmation message displayed to the user is determined entirely by the confirm_msg parameter supplied by the caller; the function does not impose a default or static message.
- BR-003 - A return value of 1 exclusively represents user confirmation (ALERT_BUTTON1 pressed); any other button response yields a return value of 0, treating all non-affirmative responses as cancellation.
- BR-004 - The function has no side effects on database state; it solely controls alert presentation and returns a binary numeric result to the caller.

---
**Implementation Logic**

```plsql
FUNCTION ASK_CONFIRM( confirm_msg VARCHAR2)
                                      RETURN  NUMBER IS

    p_alert_name varchar2(10) := 'AL_CONFIRM' ;
    p_albtn_pressed number;
BEGIN
   set_alert_property(p_alert_name,alert_message_text,confirm_msg); 
   p_albtn_pressed := show_alert(p_alert_name);

   IF ( p_albtn_pressed = ALERT_BUTTON1 ) THEN
      return (1);
   ELSE
      return(0);
   END IF;
RETURN NULL; END;
```

#### SP-009 - GENERAL.DISP_TEXT

**Invoked From:**

- DPL.pld [StoredProcedure: GENERAL.RAISE_ERROR]
- vr_cross_fmb.xml [Trigger: ON-ERROR]
- vr_cross_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]
- vr_cross_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

Search Criteria (N/A / CN_MAIN)

---

**Purpose**

Displays a modal alert dialog to the user containing a supplied message and title. The procedure selects the appropriate pre-defined Oracle Forms alert object ('AL_ERRINFO' for error conditions, 'AL_NOTE' for all other notifications), sets its title and message text dynamically at runtime, and presents it to the user. It is used as a centralised display utility invoked by error-handling and validation triggers across the application.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| text_string | VARCHAR2 | IN |
| title_string | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Initialise the local alert name variable to the default value 'AL_ERRINFO'.
- Step 2 - Evaluate the title_string parameter (case-insensitive) to determine which alert object to use: if the title equals 'ERROR', retain 'AL_ERRINFO'; otherwise assign 'AL_NOTE'.
- Step 3 - Set the TITLE property of the selected alert object to the value supplied in title_string using SET_ALERT_PROPERTY.
- Step 4 - Set the ALERT_MESSAGE_TEXT property of the selected alert object to the value supplied in text_string using SET_ALERT_PROPERTY.
- Step 5 - Display the configured alert to the user via SHOW_ALERT and capture the user's response in the local variable p_alert_id (response is not evaluated further).

---
**Decision Points**

DP-001

Condition:
UPPER(title_string) = 'ERROR'

TRUE:
The alert object 'AL_ERRINFO' is used to display the message, indicating an error-level notification.

FALSE:
The alert object 'AL_NOTE' is used to display the message, indicating an informational or non-error notification.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must receive both a message body (text_string) and a title (title_string); neither has a default value, so both must be supplied by the caller.
- BR-002 - Alert type selection is driven exclusively by the title value: a title of 'ERROR' (case-insensitive) maps to the error alert 'AL_ERRINFO'; any other title maps to the informational alert 'AL_NOTE'.
- BR-003 - The alert title and message text are always overwritten at runtime with the caller-supplied values before the alert is shown, ensuring the displayed content reflects the current context rather than any design-time defaults.
- BR-004 - The user's button response returned by SHOW_ALERT is accepted but not acted upon; the procedure is purely a display utility and does not branch or raise exceptions based on the user's choice.

---
**Implementation Logic**

```plsql
PROCEDURE DISP_TEXT (text_string VARCHAR2,
                     title_string VARCHAR2 ) IS 
   p_alert_name varchar2(10) := 'AL_ERRINFO' ; 
   p_alert_id number;
BEGIN
   if upper(title_string)='ERROR' then
      p_alert_name := 'AL_ERRINFO' ; 
   else
      p_alert_name := 'AL_NOTE' ; 
   end if;
   set_alert_property(p_alert_name,TITLE,title_string);  
   set_alert_property(p_alert_name,alert_message_text,text_string);  
   p_alert_id := show_alert(p_alert_name); 
END;
```

#### SP-010 - GENERAL.RAISE_ERROR

**Invoked From:**

- vr_cross_fmb.xml [Trigger: ON-ERROR]

---

**Screen:**

N/A

---

**Purpose**

Centralises error and notification handling for Oracle Forms by accepting a message code, determining the severity of the message, composing a display string, and presenting it to the user via GENERAL.DISP_TEXT. For error-level messages the procedure additionally raises FORM_TRIGGER_FAILURE to halt form processing. It is invoked from the ON-ERROR trigger in vr_cross_fmb.xml.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| mesg_code | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-009](#SP-009--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message code (mesg_code) as input.
- Step 2 - Compose the display text by concatenating mesg_code, a colon separator, and the resolved message text (mesg_text) into a single string.
- Step 3 - Evaluate the message type (mesg_type) to determine the appropriate severity category and dialog title.
- Step 4 - If the message type is 'E' (Error), set the dialog title to 'Error', call GENERAL.DISP_TEXT to display the composed message, then raise FORM_TRIGGER_FAILURE to abort the current form trigger.
- Step 5 - If the message type is 'N' (Note), set the dialog title to 'Note' and call GENERAL.DISP_TEXT to display the composed message without halting processing.
- Step 6 - If the message type is 'C' (Caution), set the dialog title to 'Caution' and call GENERAL.DISP_TEXT to display the composed message without halting processing.
- Step 7 - If mesg_type does not match any of the three recognised values, no display action is taken and the procedure exits silently.

---
**Decision Points**

DP-001

Condition:
mesg_type = 'E'

TRUE:
Set dialog title to 'Error', invoke GENERAL.DISP_TEXT with the composed message and title, then raise FORM_TRIGGER_FAILURE to halt the form trigger.

FALSE:
Proceed to evaluate whether mesg_type = 'N' (DP-002).

---

DP-002

Condition:
mesg_type = 'N'

TRUE:
Set dialog title to 'Note' and invoke GENERAL.DISP_TEXT with the composed message and title; processing continues normally.

FALSE:
Proceed to evaluate whether mesg_type = 'C' (DP-003).

---

DP-003

Condition:
mesg_type = 'C'

TRUE:
Set dialog title to 'Caution' and invoke GENERAL.DISP_TEXT with the composed message and title; processing continues normally.

FALSE:
No display action is taken; the procedure exits without presenting a message to the user.

---
**Database Interactions**

- DB-001 - Read AM_PERMISSIONS - Reads data from AM_PERMISSIONS for lookup or validation.
**Business Rules**

- BR-001 - The display text presented to the user must always include the original message code as a prefix, separated from the message body by ' : ', ensuring traceability back to the originating code.
- BR-002 - A message classified as type 'E' (Error) must unconditionally raise FORM_TRIGGER_FAILURE after display, preventing any further execution of the calling form trigger.
- BR-003 - A message classified as type 'N' (Note) or 'C' (Caution) must be displayed to the user but must not interrupt form processing by raising an exception.
- BR-004 - Only the three recognised severity values ('E', 'N', 'C') trigger a user-facing notification; any unrecognised or null mesg_type results in silent exit with no message displayed.
- BR-005 - All user-facing message dialogs must be rendered exclusively through GENERAL.DISP_TEXT (SP-009), ensuring consistent presentation across the application.

---
**Implementation Logic**

```plsql
PROCEDURE RAISE_ERROR ( mesg_code IN VARCHAR2 )IS
  mesg_type  varchar2(7); 
  mesg_text  varchar2(200) ;
  mesg_title varchar2(7);
  BEGIN
     -- murali 17.05.04 GENERAL.get_message(mesg_code,mesg_text,mesg_type );
     mesg_text:=mesg_code||' : '||mesg_text;		
     IF ( mesg_type = 'E' ) THEN
        mesg_title := 'Error' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
        raise FORM_TRIGGER_FAILURE;
     ELSIF ( mesg_type = 'N' ) THEN
        mesg_title := 'Note' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     ELSIF ( mesg_type = 'C' ) THEN
        mesg_title := 'Caution' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     END IF;
  END;     

/* PROCEDURE check_rights( 
pi_form_name in varchar2,
pi_user_id in number) IS
lv_x varchar2(1);
BEGIN
	
	begin
	SELECT substr(access_string, pi_user_id,1) 
	INTO   lv_x
	FROM   	am_permissions
	WHERE  form_name = pi_form_name
	AND SUBSTR(access_string,pi_user_id,1)='Y';
	exception 
		when no_data_found then
		  general.disp_text('You do not have the Permission to access this.','Error rr');
		  raise form_trigger_failure; 
		when too_many_rows then
		  general.disp_text('Many rows in USER_PERMISSIONS','Error ss');
		  raise form_trigger_failure;
		when others then
		       general.disp_text(sqlerrm,'Error mm');
		       raise form_trigger_failure;
	end;

	open_form(pi_form_name,activate,session);
END;
*/
```

#### SP-011 - WEBUTIL.BLOCKING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Executes a shell or system command in blocking mode, meaning the calling process waits for the command to complete before control is returned. The function delegates execution to WEBUTIL.EXECUTE, passing the supplied command string together with the BLOCKING_MODE constant to enforce synchronous behaviour.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.EXECUTE ([SP-019](#SP-019--WEBUTIL.EXECUTE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the command string (cmd) to be executed as an input parameter.
- Step 2 - Invoke WEBUTIL.EXECUTE (SP-019), passing the cmd value and the BLOCKING_MODE constant to request synchronous execution.
- Step 3 - Return the PROCESS_ID value produced by WEBUTIL.EXECUTE to the caller, allowing the caller to reference the completed process.

---
**Decision Points**

No conditional decision points exist within this function. All branching and execution logic is fully delegated to WEBUTIL.EXECUTE (SP-019); WEBUTIL.BLOCKING unconditionally passes BLOCKING_MODE on every invocation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The command must always be executed in blocking (synchronous) mode; the BLOCKING_MODE constant is hardcoded and cannot be overridden by the caller.
- BR-002 - The function must return a PROCESS_ID to the caller, as supplied by WEBUTIL.EXECUTE, to allow downstream logic to identify or audit the completed process.
- BR-003 - Command execution is fully delegated to WEBUTIL.EXECUTE (SP-019); WEBUTIL.BLOCKING performs no independent execution, validation, or error handling of the command string.

---
**Implementation Logic**

```plsql
  
  FUNCTION  Blocking(cmd in VARCHAR2) return PROCESS_ID is
  begin
    return Execute(cmd,BLOCKING_MODE);
  end Blocking;
```

#### SP-012 - WEBUTIL.CHECKLIBS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.CHECKLIBS ensures that all system libraries required by a given WebUtil package are present and up to date on the client machine. For each library defined in the property bundle for the package, the procedure compares the installed version against the required version and, where a download is necessary, retrieves the library file from a configured URL and records the newly installed version on the client. It is invoked by WEBUTIL.REGISTERBEAN as part of the package registration sequence.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.DOWNLOADFROMURLINT ([SP-016](#SP-016--WEBUTIL.DOWNLOADFROMURLINT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTSETTING ([SP-024](#SP-024--WEBUTIL.GETCLIENTSETTING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-042](#SP-042--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-045](#SP-045--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READTRANSFROMMSGBUNDLE ([SP-046](#SP-046--WEBUTIL.READTRANSFROMMSGBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETCLIENTSETTING ([SP-050](#SP-050--WEBUTIL.SETCLIENTSETTING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Begin iterating through sequentially numbered library entries in the property bundle using the key pattern 'install.syslib.<OSFamily>.<OSArch>.<packageID>.<index>', incrementing the index counter (lib) on each iteration.
- Step 2 - If no entry is found for the OS-family/architecture-specific key, fall back to a less specific key pattern 'install.syslib.<OSFamily>.<packageID>.<index>' via WEBUTIL.READFROMPROPERTYBUNDLE.
- Step 3 - If both lookups return NULL, exit the loop; all library entries for the package have been processed.
- Step 4 - Parse the retrieved library specification string (pipe-delimited) to extract: library file name (position 1), expected file size in bytes (position 2), required version string (position 3), and a progress-display flag (position 4).
- Step 5 - Query the client's current setting for the library using WEBUTIL.GETCLIENTSETTING with the key 'syslib.<libName>' to determine the installed version.
- Step 6 - Evaluate whether a download is required: if the installed version is absent, differs from the required version, or the REDOWNLOAD_SYSLIB flag is set, proceed to download.
- Step 7 - Resolve the download base URL by attempting three progressively less specific property bundle lookups in order: OS-family + architecture, OS-family only, then a generic location key, via WEBUTIL.READFROMPROPERTYBUNDLE.
- Step 8 - Invoke WEBUTIL.DOWNLOADFROMURLINT to download the library file from the resolved URL, passing the file name, expected size, progress flag, and localised progress dialog title and subtitle strings retrieved via WEBUTIL.READTRANSFROMMSGBUNDLE ('INST_PGRS_TITLE' and 'INST_PGRS_SUBTITLE').
- Step 9 - If the download succeeds, record the newly installed version on the client by calling WEBUTIL.SETCLIENTSETTING with key 'syslib.<libName>' and the required version value.
- Step 10 - If the download fails, log an error message via WEBUTIL.LOG indicating which library could not be downloaded, then continue to the next library entry.
- Step 11 - Return to Step 1 for the next sequential library entry until the loop exits.

---
**Decision Points**

DP-001

Condition: The OS-family + architecture specific property bundle key ('install.syslib.<OSFamily>.<OSArch>.<packageID>.<index>') returns a non-NULL value.

TRUE: Use the returned library specification string for this iteration.

FALSE: Attempt the less specific OS-family-only key ('install.syslib.<OSFamily>.<packageID>.<index>') via WEBUTIL.READFROMPROPERTYBUNDLE.

---

DP-002

Condition: Both the OS-family + architecture and the OS-family-only property bundle lookups return NULL for the current library index.

TRUE: Exit the loop; no further libraries are defined for this package.

FALSE: Continue processing the retrieved library specification.

---

DP-003

Condition: The installed version retrieved via WEBUTIL.GETCLIENTSETTING is NULL, differs from the required version, or the REDOWNLOAD_SYSLIB flag is TRUE.

TRUE: Resolve the download URL and proceed to download the library.

FALSE: The library is already installed at the correct version; skip download and advance to the next library entry.

---

DP-004

Condition: The OS-family + architecture specific download location key ('install.syslib.location.<OSFamily>.<OSArch>') returns a non-NULL URL.

TRUE: Use this URL as the download base.

FALSE: Attempt the OS-family-only location key ('install.syslib.location.<OSFamily>').

---

DP-005

Condition: The OS-family-only download location key returns a non-NULL URL.

TRUE: Use this URL as the download base.

FALSE: Fall back to the generic location key ('install.syslib.location') via WEBUTIL.READFROMPROPERTYBUNDLE.

---

DP-006

Condition: WEBUTIL.DOWNLOADFROMURLINT returns TRUE (download completed successfully).

TRUE: Record the installed version on the client via WEBUTIL.SETCLIENTSETTING.

FALSE: Log a download failure message via WEBUTIL.LOG and continue to the next library entry.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Library definitions for a package must be stored in the property bundle under sequentially numbered keys beginning at index 1; processing stops at the first index that yields no entry for either the architecture-specific or OS-family-only key pattern.
- BR-002 - Each library specification value in the property bundle must be a pipe-delimited string containing, in order: library file name, expected file size, required version, and a Boolean progress-display indicator ('TRUE'/'FALSE').
- BR-003 - A library must be downloaded if and only if its client-side installed version is absent, does not match the required version declared in the property bundle, or the REDOWNLOAD_SYSLIB flag is active.
- BR-004 - Download base URL resolution follows a strict fallback hierarchy: OS-family + architecture first, then OS-family only, then generic; the first non-NULL result is used.
- BR-005 - Upon a successful download, the client setting 'syslib.<libName>' must be updated to the required version string to prevent unnecessary re-downloads on subsequent invocations.
- BR-006 - A failed download must be logged via WEBUTIL.LOG with the library name identified in the message; processing continues with remaining libraries rather than aborting the entire loop.
- BR-007 - Progress dialog labels presented during download must be sourced from the message bundle via WEBUTIL.READTRANSFROMMSGBUNDLE using the keys 'INST_PGRS_TITLE' and 'INST_PGRS_SUBTITLE', ensuring localised display.

---
**Implementation Logic**

```plsql
  
  PROCEDURE CheckLibs(packageID in VARCHAR2 ) is
    lib          PLS_INTEGER := 1;
    libSpec      VARCHAR2(200 char);
    libName      VARCHAR2(100 char);
    libSize      PLS_INTEGER;
    libVer       VARCHAR2(20 char);
    installedVer VARCHAR2(20 char);
    libProg      BOOLEAN := false;
    downloadURL  VARCHAR2(1000);
  BEGIN
    -- Read through the property bundle for 
    -- any libraries for this package
    LOOP
      libSpec := readFromPropertyBundle('install.syslib.'||to_char(m_clientOSFamily)||'.'||
             to_char(m_clientOSArch)||'.'||packageID||'.'||to_char(lib));
      if libSpec is null then
        libSpec := readFromPropertyBundle('install.syslib.'||to_char(m_clientOSFamily)||'.'||
             packageID||'.'||to_char(lib));
      end if;
      if libSpec is null then 
        exit;
      end if;
      lib := lib + 1;
      libName := Delimstr.getString(libSpec,1,true,'|');
      libSize := Delimstr.getNumber(libSpec,2,true,'|');
      libVer  := Delimstr.getString(libSpec,3,true,'|');
      libProg := (upper(Delimstr.getString(libSpec,4,true,'|'))='TRUE');

      -- OK we now have the library information
      -- let's check if it's installed
      installedVer := GetClientSetting('syslib.'||libname);
      if installedVer is null or installedVer <> libVer or REDOWNLOAD_SYSLIB then 
        -- need to download
        downloadURL := readFromPropertyBundle('install.syslib.location' || '.' || to_char(m_clientOSFamily) ||
                             '.' || to_char(m_clientOSArch));
        if downloadURL is null then
          downloadURL := readFromPropertyBundle('install.syslib.location' || '.' || to_char(m_clientOSFamily));
        end if;
        if downloadURL is null then
          downloadURL := readFromPropertyBundle('install.syslib.location');
        end if;
        if DownLoadFromURLInt(downloadURL||'/'||libName, 
                              libName,
                              1, -- syslib install download, special location
                              libSize,
                              libProg,
                              ReadTransFromMsgBundle('INST_PGRS_TITLE'),
                              ReadTransFromMsgBundle('INST_PGRS_SUBTITLE'),     
                              libName) then 
          SetClientSetting('syslib.'||libname,libVer);
        else
          log('Download of system library '||libName||' failed',true);
        end if;                          
      end if;
    END LOOP;
  END CheckLibs;
```

#### SP-013 - WEBUTIL.CLEARCALLBACKTRIGGER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Removes a previously registered callback entry from the internal callbacks collection using the supplied integer key. This procedure is called by WEBUTIL.SETDATA to clean up callback trigger registrations that are no longer required, ensuring the collection does not retain stale entries.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| callbackKey | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the integer key (callbackKey) that identifies the callback trigger entry to be removed.
- Step 2 - Check whether an entry with the supplied key exists in the package-level collection m_callbacks.
- Step 3 - If the entry exists, delete it from m_callbacks using the provided key.
- Step 4 - If the entry does not exist, take no action and return silently.

---
**Decision Points**

DP-001

Condition: m_callbacks.exists(callbackKey) - an entry indexed by callbackKey is present in the m_callbacks collection.

TRUE: The entry is deleted from m_callbacks via m_callbacks.delete(callbackKey), removing the callback trigger registration.

FALSE: No action is taken; the procedure exits without modifying the collection.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure only deletes a callback entry when the specified key is confirmed to exist in m_callbacks; deletion is never attempted on a non-existent key, preventing runtime errors.
- BR-002 - Cleanup is performed on a per-key basis; only the single entry identified by callbackKey is removed, leaving all other registered callback entries unaffected.
- BR-003 - The procedure produces no output and raises no exceptions regardless of whether the key is found, making its execution transparent to the calling routine WEBUTIL.SETDATA.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ClearCallbackTrigger(callbackKey in PLS_INTEGER) is
  begin
    if m_callbacks.exists(callbackKey) then 
      m_callbacks.delete(callbackKey);  
    end if;
  end ClearCallbackTrigger;
```

#### SP-014 - WEBUTIL.CLOSEBLOB

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open BLOB handle identified by its checksum value. The procedure delegates the close operation to the WebUtil_DB package, ensuring that BLOB resources previously opened within a WebUtil session are properly released.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| checksum | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the checksum (PLS_INTEGER) that uniquely identifies the open BLOB handle to be closed.
- Step 2 - Delegate the close operation to WebUtil_DB.CloseBlob, passing the checksum as the sole argument.
- Step 3 - Return the BOOLEAN result produced by WebUtil_DB.CloseBlob to the caller, indicating whether the BLOB was successfully closed.

---
**Decision Points**

No decision points are present in the implementation logic. The function unconditionally delegates to WebUtil_DB.CloseBlob and returns its result without branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The checksum parameter must identify a previously opened BLOB handle; the validity and existence of the handle are enforced by WebUtil_DB.CloseBlob.
- BR-002 - The success or failure of the close operation is communicated exclusively through the BOOLEAN return value; callers must evaluate this value to determine whether the BLOB was released successfully.

---
**Implementation Logic**

```plsql

  FUNCTION  CloseBlob(checksum in PLS_INTEGER) return BOOLEAN is
  BEGIN
    return WebUtil_DB.CloseBlob(checksum);
  END CloseBlob;
```

#### SP-015 - WEBUTIL.CLOSEFILE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open server-side file by invoking the native Java method closeFile on the AppServerFileReader object. The procedure releases the file handle represented by the supplied Java object and returns a Boolean indicating whether the close operation succeeded. It is called by WEBUTIL.SETDATA to ensure that a file opened during a data-transfer operation is properly closed after processing is complete.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java object reference (obj) that represents the currently open AppServerFileReader file handle on the application server.
- Step 2 - Clear the argument list by setting args to NULL, as the target Java method requires no arguments.
- Step 3 - Invoke the Java method closeFile on the oracle/forms/webutil/fileTransfer/AppServerFileReader class via JNI.CALL_BOOLEAN_METHOD, passing the object reference and a NULL argument list.
- Step 4 - Return the Boolean result received from the JNI call to the caller (WEBUTIL.SETDATA), indicating whether the file was successfully closed.

---
**Decision Points**

No conditional decision points exist within this function. The function unconditionally clears the argument list, calls the JNI method, and returns the result. Any branching based on the returned Boolean is the responsibility of the calling routine WEBUTIL.SETDATA.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must always clear the JNI argument list (args := NULL) before invoking the Java method, because the target closeFile Java method accepts no parameters.
- BR-002 - The file-close operation is performed exclusively through the JNI bridge targeting the oracle/forms/webutil/fileTransfer/AppServerFileReader class; no direct database or file-system interaction is permitted within this function.
- BR-003 - The function must return the Boolean result of the JNI call unmodified to the caller, preserving the success or failure status of the close operation for upstream handling.

---
**Implementation Logic**

```plsql
  FUNCTION closeFile(
    obj   ORA_JAVA.JOBJECT) RETURN BOOLEAN IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_BOOLEAN_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'closeFile', '()Z', args); 
  END;
```

#### SP-016 - WEBUTIL.DOWNLOADFROMURLINT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Downloads a file from a specified URL to a client-side destination by constructing a delimited instruction string and dispatching it to the WebUtil Core bean. The function returns TRUE if the download completes successfully, or FALSE if a validation or runtime error occurs. It supports optional progress-indicator parameters and a special destination mode to control where the file is placed on the client.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| specialDestination | PLS_INTEGER | IN |
| fileSize | PLS_INTEGER | IN |
| withProgress | BOOLEAN | IN |
| progressTitle | VARCHAR2 | IN |
| progressSubTitle | VARCHAR2 | IN |
| progressMessage | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Validate that sourceURL is not null; if null, raise the URL_NULL exception.
- Step 2 - Validate that clientDestination is not null; if null, raise the CLIENT_FILE_NULL exception.
- Step 3 - Evaluate specialDestination: if null, negative, or greater than 2, append '0' to the submit string; otherwise append its character representation. Append the pipe separator.
- Step 4 - Evaluate fileSize: if null, append '0' to the submit string; otherwise append its character representation. Append the pipe separator.
- Step 5 - Evaluate withProgress: if null or FALSE, append 'N' to the submit string; if TRUE, append 'Y'. Append the pipe separator.
- Step 6 - Concatenate sourceURL, clientDestination, progressTitle (defaulting to a single space if null), progressSubTitle (defaulting to a single space if null), and progressMessage (defaulting to a single space if null) onto the submit string, each separated by the pipe delimiter.
- Step 7 - Send the fully assembled submit string to the WebUtil Core bean by calling WebUtil_Core.setProperty with the property key WUC_URL_DOWNLOAD.
- Step 8 - Retrieve the result from the WebUtil Core bean by calling WebUtil_Core.getProperty with the same property key WUC_URL_DOWNLOAD.
- Step 9 - Return TRUE if the retrieved result equals 'TRUE'; otherwise return FALSE.
- Step 10 - On CLIENT_FILE_NULL exception, log error code 130 via WebUtil_Core.Error and return FALSE.
- Step 11 - On URL_NULL exception, log error code 25 via WebUtil_Core.Error and return FALSE.
- Step 12 - On BEAN_NOT_REGISTERED exception, raise an alert identifying the missing bean class and raise FORM_TRIGGER_FAILURE.
- Step 13 - On PROPERTY_ERROR exception, raise FORM_TRIGGER_FAILURE.

---
**Decision Points**

DP-001

Condition: sourceURL IS NULL

TRUE: Raise URL_NULL exception; log error code 25 and return FALSE.

FALSE: Continue to clientDestination validation.

---

DP-002

Condition: clientDestination IS NULL

TRUE: Raise CLIENT_FILE_NULL exception; log error code 130 and return FALSE.

FALSE: Continue to submit string construction.

---

DP-003

Condition: specialDestination IS NULL OR specialDestination < 0 OR specialDestination > 2

TRUE: Append '0' to the submit string as the special destination token.

FALSE: Append the character representation of specialDestination to the submit string.

---

DP-004

Condition: fileSize IS NULL

TRUE: Append '0' to the submit string as the file size token.

FALSE: Append the character representation of fileSize to the submit string.

---

DP-005

Condition: withProgress IS NULL OR withProgress = FALSE

TRUE: Append 'N' to the submit string, indicating no progress indicator.

FALSE: Append 'Y' to the submit string, indicating a progress indicator is requested.

---

DP-006

Condition: Retrieved result from WebUtil_Core.getProperty equals 'TRUE'

TRUE: Return TRUE, indicating the download succeeded.

FALSE: Return FALSE, indicating the download did not succeed.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A source URL must be provided; a null sourceURL is invalid and will cause the function to abort with error code 25 without attempting the download.
- BR-002 - A client destination path must be provided; a null clientDestination is invalid and will cause the function to abort with error code 130 without attempting the download.
- BR-003 - The specialDestination value must be 0, 1, or 2; any null, negative, or out-of-range value is treated as 0 (default destination mode).
- BR-004 - A null fileSize is treated as 0, signalling to the bean that the file size is unknown or unspecified.
- BR-005 - Progress indicator display is opt-in; withProgress defaults to FALSE, and a null value is treated equivalently to FALSE.
- BR-006 - Null progress text parameters (progressTitle, progressSubTitle, progressMessage) are substituted with a single space to preserve the fixed pipe-delimited structure of the submit string.
- BR-007 - The pipe character ('|') is the mandatory field delimiter within the submit string passed to the WebUtil Core bean; the structure and ordering of fields must be maintained.
- BR-008 - If the WebUtil Core bean is not registered, the function raises FORM_TRIGGER_FAILURE rather than returning FALSE, escalating the error to the calling form.
- BR-009 - If a PROPERTY_ERROR is returned by the WebUtil Core bean, the function raises FORM_TRIGGER_FAILURE, escalating the error to the calling form.

---
**Implementation Logic**

```plsql
  
  FUNCTION DownLoadFromURLInt(sourceURL          in VARCHAR2, 
                              clientDestination  in VARCHAR2, 
                              specialDestination in PLS_INTEGER default 0,                             
                              fileSize           in PLS_INTEGER default 0, 
                              withProgress       in BOOLEAN default false,
                              progressTitle      in VARCHAR2 default null,
                              progressSubTitle   in VARCHAR2 default null,
                              progressMessage    in VARCHAR2 default null) return BOOLEAN is
    result       VARCHAR2(6) := 'FALSE';
    submitString VARCHAR2(4000 char);
    sep          VARCHAR2(1) := '|';
  BEGIN
    if sourceURL is null then
      raise URL_NULL;
    end if;
    if clientDestination is null then
      raise CLIENT_FILE_NULL;
    end if;

    if specialDestination is null or specialDestination < 0 or specialDestination > 2 then 
      submitString := '0'||sep;
    else
      submitString := to_char(specialDestination)||sep;
    end if;
    if fileSize is null then 
      submitString := submitString||'0'||sep;
    else
      submitString := submitString||to_char(fileSize)||sep;
    end if;
    if withProgress is null or not withProgress then 
      submitString := submitString||'N'||sep;
    else
      submitString := submitString||'Y'||sep;
    end if;    

    submitString := submitString||sourceURL
                    ||sep||clientDestination
                    ||sep||nvl(progressTitle,' ')
                    ||sep||nvl(progressSubTitle,' ')
                    ||sep||nvl(progressMessage,' ');                         
  WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_URL_DOWNLOAD',submitString,true);
  result := WebUtil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_URL_DOWNLOAD');
  return (result='TRUE');
  EXCEPTION  
    when CLIENT_FILE_NULL then
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE, 130, 'WEBUTIL_CORE.DownloadFromURLInt');
      return false;
    when URL_NULL then
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE,25, 'WEBUTIL_CORE.DownloadFromURLInt');
      return false;

    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                              ||' bean not found. WEBUTIL_CORE.DownloadFromURLInt will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;
  END DownLoadFromURLInt;
```

#### SP-017 - WEBUTIL.ERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Constructs a structured error message string from a numeric error code, a program-unit name, and up to three optional argument values, then writes the formatted message to the WebUtil core property 'WUC_ERROR_MSG' for the given package instance. This provides a standardised mechanism for surfacing WebUtil runtime errors back to the Oracle Forms client via the WebUtil property channel.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |
| code | PLS_INTEGER | IN |
| pu_name | VARCHAR2 | IN |
| arg1 | VARCHAR2 | IN |
| arg2 | VARCHAR2 | IN |
| arg3 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Initialise the error text by concatenating the literal prefix 'ERROR' with the error code left-padded to three digits with leading zeros, a pipe delimiter, and the program-unit name (pu_name).
- Step 2 - Evaluate whether arg1 is non-null; if so, append a pipe delimiter followed by arg1 to the error text string.
- Step 3 - Evaluate whether arg2 is non-null; if so, append a pipe delimiter followed by arg2 to the error text string.
- Step 4 - Evaluate whether arg3 is non-null; if so, append a pipe delimiter followed by arg3 to the error text string.
- Step 5 - Invoke Webutil_Core.setProperty, passing the packageID, the property key 'WUC_ERROR_MSG', and the fully assembled error text string to persist the error message for the calling package instance.

---
**Decision Points**

DP-001

Condition:
arg1 IS NOT NULL

TRUE:
Append a pipe delimiter and the value of arg1 to the error text string.

FALSE:
Skip appending arg1; error text remains unchanged.

---

DP-002

Condition:
arg2 IS NOT NULL

TRUE:
Append a pipe delimiter and the value of arg2 to the error text string.

FALSE:
Skip appending arg2; error text remains unchanged.

---

DP-003

Condition:
arg3 IS NOT NULL

TRUE:
Append a pipe delimiter and the value of arg3 to the error text string.

FALSE:
Skip appending arg3; error text remains unchanged.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The error code must be formatted as a zero-padded three-digit number (e.g., code 5 becomes '005') and prefixed with the literal 'ERROR' to form a consistently structured error identifier.
- BR-002 - The program-unit name (pu_name) is a mandatory component of the error message and is always included immediately after the formatted error code, separated by a pipe delimiter.
- BR-003 - Optional arguments (arg1, arg2, arg3) are included in the error message only when they carry a non-null value; null arguments are silently omitted, preserving a clean pipe-delimited format.
- BR-004 - The fully assembled error message must be stored against the property key 'WUC_ERROR_MSG' on the specified package instance via Webutil_Core.setProperty, making it available to the WebUtil event-handling framework for downstream processing.
- BR-005 - The error text string is constrained to a maximum length of 1 024 characters (VARCHAR2(1024)), limiting the combined size of the error code, program-unit name, and all appended arguments.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Error(packageID in PLS_INTEGER,
                  code      in PLS_INTEGER,
                  pu_name   in VARCHAR2,
                  arg1      in VARCHAR2 :=null,
                  arg2      in VARCHAR2 := null,
                  arg3      in VARCHAR2 := null
                 ) is
    errText varchar2(1024);
  begin 
    errText := 'ERROR'||lpad(to_char(code),3,'0') || '|' || pu_name;
    if arg1 is not null then
      errText := errText || '|' || arg1;
    end if;
    if arg2 is not null then
      errText := errText || '|' || arg2;
    end if;
    if arg3 is not null then
      errText := errText || '|' || arg3;
    end if;
    Webutil_Core.setProperty(packageID, 'WUC_ERROR_MSG', errText);
  end Error;
```

#### SP-018 - WEBUTIL.ERRORALERT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]
- webutil.pld [StoredProcedure: WEBUTIL.LOG]
- webutil.pld [StoredProcedure: WEBUTIL.POPULATEPROPERTYBUNDLE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Displays a WebUtil error message to the end user. If a pre-configured alert object (m_errorAlert) is available, the procedure populates it with the supplied error text and presents it as a modal alert dialog. If no alert object has been registered, it falls back to the Oracle Forms MESSAGE built-in. The procedure is called by WEBUTIL.FCLOSE, WEBUTIL.LOG, and WEBUTIL.POPULATEPROPERTYBUNDLE to surface bean-not-registered or bean-not-found errors in a consistent, user-visible manner.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| errText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-036](#SP-036--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the error description text (errText) as an input parameter.
- Step 2 - Call WEBUTIL.ID_NULL (SP-036) to test whether the module-level alert handle m_errorAlert references a valid, registered alert object.
- Step 3 - If m_errorAlert is valid (not null), set the alert's message text property to errText using SET_ALERT_PROPERTY with the ALERT_MESSAGE_TEXT attribute.
- Step 4 - Display the configured alert dialog to the user by calling SHOW_ALERT; the return value is captured in the local variable 'ignore' and discarded.
- Step 5 - If m_errorAlert is not valid (null/unregistered), display the error using the Oracle Forms MESSAGE built-in, prefixing the text with 'WebUtil Error: ' followed by errText.

---
**Decision Points**

DP-001

Condition:
WEBUTIL.ID_NULL(m_errorAlert) returns FALSE - i.e., the module-level alert handle m_errorAlert references a valid, registered Forms alert object.

TRUE:
Set the alert's ALERT_MESSAGE_TEXT property to errText and display the alert dialog via SHOW_ALERT; the user sees a modal alert titled with the pre-configured alert title.

FALSE:
Fall back to the Oracle Forms MESSAGE built-in, outputting the concatenated string 'WebUtil Error: ' followed by errText in the Forms status bar or message line.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must always surface the error to the user; no error condition may be silently swallowed regardless of whether a registered alert object exists.
- BR-002 - The alert title is not overridden at runtime; it must already be set on the alert object at design time (the SET_ALERT_PROPERTY TITLE call is intentionally commented out).
- BR-003 - The return value of SHOW_ALERT is deliberately ignored; the procedure does not branch on the user's button selection.
- BR-004 - WEBUTIL.ID_NULL (SP-036) is the sole mechanism used to determine alert-object availability; no other null-check or existence test is applied to m_errorAlert.
- BR-005 - When falling back to MESSAGE, the error text must be prefixed with the literal string 'WebUtil Error: ' to maintain a consistent error identification convention across both display paths.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ErrorAlert(errText in VARCHAR2) is
    -- currently used for throwing a BEAN_NOT_REGISTERED or bean not found error.
    ignore integer;
  begin
    if not ID_NULL(m_errorAlert) then 
      --SET_ALERT_PROPERTY(m_errorAlert,TITLE,'WebUtil Error'); -- title already set in alert property
      SET_ALERT_PROPERTY(m_errorAlert,ALERT_MESSAGE_TEXT,errText);
      ignore := SHOW_ALERT(m_errorAlert);
    else
      message('WebUtil Error'||': '||errText);
    end if;
  end ErrorAlert;
```

#### SP-019 - WEBUTIL.EXECUTE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.BLOCKING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Submits a shell or system command for execution on the client machine via the WebUtil host integration layer. The procedure sets the desired execution mode, dispatches the command string to the WebUtil client-side bean, and returns a process handle that identifies the spawned process. If the required WebUtil bean is not registered on the client, an error alert is raised and no process is launched.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |
| exemode | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the command string (cmd) and the execution mode flag (exemode) as input.
- Step 2 - Evaluate whether cmd is non-null; if null, skip all processing and return an uninitialised PROCESS_ID record to the caller.
- Step 3 - Set the execution mode on the WebUtil host bean by calling WebUtil_Core.setProperty with property key WUH_EXECUTION_MODE and the supplied exemode value.
- Step 4 - Dispatch the command to the WebUtil host bean by calling WebUtil_Core.setProperty with property key WUH_EXECUTE and the supplied cmd value.
- Step 5 - Retrieve the process handle assigned by the client bean by calling WebUtil_Core.getProperty with property key WUH_EXECUTE, convert the returned string to a number, and store it in procId.handle.
- Step 6 - Return the populated PROCESS_ID record (containing the numeric process handle) to the caller.
- Step 7 - If a BEAN_NOT_REGISTERED exception is raised at any point, display an error alert identifying the missing implementation class and abort execution without returning a valid process handle.

---
**Decision Points**

DP-001

Condition: cmd IS NOT NULL

TRUE: Set the execution mode property on the WebUtil host bean, dispatch the command, retrieve the resulting process handle, and return a populated PROCESS_ID record.

FALSE: Bypass all bean interaction and return an uninitialised PROCESS_ID record to the caller.

DP-002

Condition: WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during bean property interaction

TRUE: Display an error alert identifying the missing WebUtil host bean implementation class, indicating that WEBUTIL_HOST.Execute will not function, and terminate the procedure without returning a valid process handle.

FALSE: No exception occurs; normal execution continues and a valid PROCESS_ID is returned.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A null command string must not be dispatched to the WebUtil host bean; if cmd is null the procedure returns an uninitialised process handle and performs no client-side action.
- BR-002 - The execution mode (exemode) must be set on the WebUtil host bean before the command string is dispatched, ensuring the client executes the command under the correct mode.
- BR-003 - The process handle returned to the caller must be derived exclusively from the value retrieved via WebUtil_Core.getProperty after the command has been dispatched; it may not be assumed or defaulted.
- BR-004 - If the WebUtil host bean is not registered on the client, the procedure must raise a user-facing error alert naming the missing implementation class and must not silently fail or return a fabricated process handle.

---
**Implementation Logic**

```plsql
  FUNCTION Execute (cmd in VARCHAR2, exemode in PLS_INTEGER) return PROCESS_ID is
    procId PROCESS_ID;
  begin 
    if cmd is not null then 
      WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTION_MODE',exemode);            
      WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTE',cmd);      
      procId.handle := to_number(WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTE'));
    end if;
    return procId;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.Execute will not work');
  end Execute;
```

#### SP-020 - WEBUTIL.FCLOSE

**Invoked From:**

- vr_cross_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open client-side text file that was previously opened via the WebUtil file I/O framework. The procedure releases the file handle by instructing the WebUtil Core bean to perform the physical close operation, then nullifies the handle to prevent further use. If the required WebUtil bean is unavailable or the close operation fails, the procedure raises a fatal tool error to halt processing.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-018](#SP-018--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETIMPLCLASS ([SP-025](#SP-025--WEBUTIL.GETIMPLCLASS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the file handle (file_type) passed IN OUT by the caller (VIEW_EXCEL_REP in vr_cross_fmb.xml).
- Step 2 - Check whether the file handle is currently open (file.handle IS NOT NULL). If the handle is NULL the file is already closed and no action is taken.
- Step 3 - Invoke WebUtil_Core.setProperty with the WUF_PACKAGE identifier and the WUF_TEXTIO_CLOSE command, passing the current handle value to instruct the WebUtil bean to close the physical file on the client.
- Step 4 - Set file.handle to NULL, marking the file object as closed and preventing any subsequent I/O operations against it.
- Step 5 - If the BEAN_NOT_REGISTERED exception is raised during the close attempt, call WEBUTIL.ERRORALERT (via WebUtil_Core.ErrorAlert) to display a descriptive message that identifies the missing bean class (retrieved through WEBUTIL.GETIMPLCLASS) and states that CLIENT_TEXT_IO.fclose will not work.
- Step 6 - After displaying the alert for a missing bean, raise TOOL_ERR.TOOL_ERROR to terminate processing.
- Step 7 - If a PROPERTY_ERROR exception is raised (the close command itself failed), raise TOOL_ERR.TOOL_ERROR immediately without displaying an alert.

---
**Decision Points**

DP-001

Condition:
file.handle IS NOT NULL

TRUE:
Proceed to close the file by calling WebUtil_Core.setProperty with the WUF_TEXTIO_CLOSE command and then nullify file.handle.

FALSE:
Skip all close logic; the file is already closed or was never opened. Procedure exits normally.

---

DP-002

Condition:
WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during the setProperty call

TRUE:
Call WEBUTIL.ERRORALERT with a message composed using WEBUTIL.GETIMPLCLASS to identify the missing bean, then raise TOOL_ERR.TOOL_ERROR to abort the calling process.

FALSE:
Exception is not raised; normal close processing continues.

---

DP-003

Condition:
WebUtil_Core.PROPERTY_ERROR exception is raised during the setProperty call

TRUE:
Raise TOOL_ERR.TOOL_ERROR immediately to abort the calling process; no alert is displayed.

FALSE:
Exception is not raised; normal close processing continues.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A file close operation is only attempted when the file handle is non-NULL; a NULL handle is treated as an already-closed file and requires no action.
- BR-002 - Once the WebUtil bean successfully closes the physical file, the in-memory handle must be set to NULL to prevent the caller from issuing further I/O operations against a closed file.
- BR-003 - If the WebUtil bean required to perform the close is not registered, WEBUTIL.ERRORALERT must be invoked with a message that includes the bean class name (obtained via WEBUTIL.GETIMPLCLASS) before the error is escalated, ensuring the user receives a meaningful diagnostic.
- BR-004 - Both a missing-bean condition (BEAN_NOT_REGISTERED) and a property-execution failure (PROPERTY_ERROR) are treated as fatal errors; in both cases TOOL_ERR.TOOL_ERROR is raised to prevent silent failure and to halt the parent Excel report generation process.
- BR-005 - No database interactions occur during file close; all operations are confined to the client-side WebUtil bean and in-memory PL/SQL state.

---
**Implementation Logic**

```plsql
 
  PROCEDURE fclose (file IN OUT file_type) is 
  BEGIN 
    if (file.handle IS NOT NULL) then 
      WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CLOSE',file.handle);        
      file.handle := NULL;
    end if;
 
 EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.fclose will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;
  END fclose;
```

#### SP-021 - WEBUTIL.FOPEN

**Invoked From:**

- vr_cross_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Opens a file on the client machine for text I/O by delegating to the WebUtil Java bean layer. The function validates the requested file mode and file specification, communicates the open request to the client-side bean via WEBUTIL.GETPROPERTY (SP-031), and returns a typed file handle for subsequent read, write, or append operations. It is invoked as part of the Excel report viewing flow in vr_cross_fmb.xml.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| spec | VARCHAR2 | IN |
| filemode | VARCHAR2 | IN |
| charSet | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETPROPERTY ([SP-031](#SP-031--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Validate that the supplied file mode (`filemode`) is one of the three accepted values: 'r' (read), 'w' (write), or 'a' (append), using a case-insensitive comparison. Raise TOOL_ERR.TOOL_ERROR immediately if the value is not recognised.
- Step 2 - Validate that the file specification (`spec`) is neither NULL nor an empty string. Raise TOOL_ERR.TOOL_ERROR if no file name has been provided.
- Step 3 - Push the file specification to the WebUtil bean by calling WebUtil_Core.setProperty with property key WUF_FILENAME and the value of `spec`.
- Step 4 - Push the file mode to the WebUtil bean by calling WebUtil_Core.setProperty with property key WUF_TEXTIO_FILEMODE and the value of `filemode`.
- Step 5 - Determine the effective character set: if `charSet` is NULL, push the literal string '(null)' to the bean via WebUtil_Core.setProperty with key WUF_TEXTIO_CHARSET; otherwise push the supplied `charSet` value.
- Step 6 - Trigger the actual file-open operation on the client by calling WEBUTIL.GETPROPERTY (SP-031) with property key WUF_TEXTIO_OPEN. The bean returns a string handle representing the opened file.
- Step 7 - Validate the returned Java handle: if it is NULL, empty, or equal to '-1', the file could not be opened; raise TOOL_ERR.TOOL_ERROR.
- Step 8 - Convert the valid string handle to a numeric value, assign it to the `handle` field of the local `file_type` record, and return that record to the caller.
- Step 9 - In the exception block, handle BEAN_NOT_REGISTERED by invoking WebUtil_Core.ErrorAlert to display a descriptive message (incorporating the bean's implementation class name) and then re-raise TOOL_ERR.TOOL_ERROR. Handle PROPERTY_ERROR, VALUE_ERROR, and TOOL_ERR.TOOL_ERROR by re-raising to propagate the error to the caller.

---
**Decision Points**

DP-001

Condition:
Is the lower-cased value of `filemode` NOT IN ('r', 'w', 'a')?

TRUE:
Raise TOOL_ERR.TOOL_ERROR; processing stops and no file open attempt is made.

FALSE:
Proceed to validate the file specification.

---

DP-002

Condition:
Is `spec` NULL or equal to an empty string?

TRUE:
Raise TOOL_ERR.TOOL_ERROR; processing stops and no file open attempt is made.

FALSE:
Proceed to push parameters to the WebUtil bean.

---

DP-003

Condition:
Is the `charSet` parameter NULL?

TRUE:
Set the WUF_TEXTIO_CHARSET property on the bean to the literal '(null)', indicating no explicit character set.

FALSE:
Set the WUF_TEXTIO_CHARSET property on the bean to the caller-supplied `charSet` value.

---

DP-004

Condition:
Is the Java handle returned by WEBUTIL.GETPROPERTY (SP-031) NULL, empty, or equal to '-1'?

TRUE:
Raise TOOL_ERR.TOOL_ERROR; the file was not successfully opened on the client.

FALSE:
Convert the handle to a number, populate the `file_type` record, and return it to the caller.

---

DP-005

Condition:
Does the EXCEPTION block catch BEAN_NOT_REGISTERED?

TRUE:
Call WebUtil_Core.ErrorAlert with a message composed from the bean's implementation class name, then raise TOOL_ERR.TOOL_ERROR.

FALSE:
Evaluate subsequent exception handlers (PROPERTY_ERROR, VALUE_ERROR, TOOL_ERR.TOOL_ERROR) and re-raise as appropriate.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file mode must be exactly one of 'r', 'w', or 'a' (case-insensitive); any other value is rejected before any client interaction is attempted.
- BR-002 - A non-null, non-empty file specification must be provided; the function will not attempt to open an unnamed file.
- BR-003 - When no character set is explicitly specified by the caller, the value '(null)' is passed to the WebUtil bean, signalling that the bean should use its default encoding.
- BR-004 - The file-open result is validated against three failure indicators (NULL, empty string, or '-1'); all three are treated as an unsuccessful open and result in a TOOL_ERR.TOOL_ERROR being raised.
- BR-005 - The numeric file handle returned by the bean must be convertible to a NUMBER type; a VALUE_ERROR during conversion causes TOOL_ERR.TOOL_ERROR to be raised, preventing a corrupt handle from being returned to the caller.
- BR-006 - If the required WebUtil Java bean is not registered on the client, a descriptive alert is displayed to the user (identifying the missing bean class) before the error is propagated, ensuring the failure is visible and diagnosable.
- BR-007 - PROPERTY_ERROR exceptions are re-raised without modification, preserving the original error context for upstream handlers.

---
**Implementation Logic**

```plsql
  FUNCTION fopen(spec VARCHAR2, filemode VARCHAR2, charSet VARCHAR2 := null) RETURN file_type is
    clientFile file_type;
    javaHandle VARCHAR2(6);
  BEGIN
    -- check the mode is valid
    if (lower(filemode) not in ('r','w','a')) then 
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- make sure a file name has been specified      
    if (spec is null) or (spec='') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;
      
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILENAME',spec, true);
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_FILEMODE',filemode, true);        
    if (charSet is null) then
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET','(null)', true);
    else
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET',charSet, true);
    end if;
    javaHandle := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_OPEN');

    -- If the return is null then the file was not opened      
    if (javaHandle is null) or (javaHandle='') or (javaHandle='-1') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- if we are this far convert the handle to the correct format and return it.      
    clientFile.handle := to_number(javaHandle);
    return clientFile;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.fopen will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                 
      return null;
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE;
    when VALUE_ERROR then
      RAISE TOOL_ERR.TOOL_ERROR; 
    when TOOL_ERR.TOOL_ERROR then 
      RAISE;
  END fopen;
```

#### SP-022 - WEBUTIL.GETCALLBACKTRIGGER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the name of a previously registered callback trigger associated with a given integer key. The function provides a lookup mechanism into the internal callbacks collection, allowing the caller (WEBUTIL.SETDATA) to resolve which trigger name corresponds to a specific callback key.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| callbackKey | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the integer callback key (callbackKey) supplied by the invoking routine WEBUTIL.SETDATA.
- Step 2 - Use callbackKey as an index into the package-level collection m_callbacks.
- Step 3 - Return the VARCHAR2 trigger name stored at that index position to the caller.

---
**Decision Points**

No conditional decision points exist in this function. The implementation performs a direct indexed lookup against m_callbacks and returns the result unconditionally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The callbackKey parameter must correspond to a valid, pre-existing index in the m_callbacks collection; no bounds checking or default handling is performed within this function, so an invalid key will raise a runtime collection error.
- BR-002 - The function returns exactly the VARCHAR2 value stored at the specified index in m_callbacks without transformation or validation, preserving the trigger name as originally registered.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetCallbackTrigger(callbackKey in PLS_INTEGER) return VARCHAR2 is 
  begin 
    return m_callbacks(callbackKey);
  end GetCallbackTrigger;
```

#### SP-023 - WEBUTIL.GETCLIENTOSFAMILY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the operating system family identifier of the client machine as a PLS_INTEGER value. This function exposes the internally held client OS family classification (stored in the module-level variable m_clientOSFamily) to calling routines, enabling the application to make OS-aware decisions based on the client environment.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - The function is invoked by WEBUTIL.GETVAR, which requires the client OS family identifier.
- Step 2 - The function reads the module-level variable m_clientOSFamily, which holds the pre-populated client operating system family classification.
- Step 3 - The function returns the integer value of m_clientOSFamily directly to the caller as a PLS_INTEGER.

---
**Decision Points**

No conditional decision points exist in this function. The implementation unconditionally reads and returns the value of m_clientOSFamily without branching logic.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function returns the value of m_clientOSFamily exactly as stored; no transformation, defaulting, or validation is applied to the value before it is returned.
- BR-002 - The client OS family identifier must have been populated in m_clientOSFamily prior to this function being called; this function is a read-only accessor and does not initialise or modify the variable.
- BR-003 - The return type is PLS_INTEGER, meaning the OS family classification is represented as a whole number; callers must interpret the integer value according to the OS family enumeration defined elsewhere in the WEBUTIL package.

---
**Implementation Logic**

```plsql

  FUNCTION GetClientOSFamily return PLS_INTEGER is 
  begin 
    return m_clientOSFamily;
  end GetClientOSFamily;
```

#### SP-024 - WEBUTIL.GETCLIENTSETTING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a named client-side configuration property from the WebUtil Core bean. Given a property name, the function delegates to WebUtil_Core to set and then read back the requested local property value, returning it to the caller. It is used by WEBUTIL.CHECKLIBS and WEBUTIL.REGISTERBEAN to interrogate client environment settings at runtime.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameter propertyName (VARCHAR2).
- Step 2 - Check whether propertyName is not null; if null, skip processing and return a null result.
- Step 3 - Call WebUtil_Core.setProperty, targeting the WUC_PACKAGE component with the key WUC_GET_LOCAL_PROPERTY and the supplied propertyName as the value, to request the client-side property lookup.
- Step 4 - Call WebUtil_Core.getProperty with the same component (WUC_PACKAGE) and key (WUC_GET_LOCAL_PROPERTY) to retrieve the resolved property value from the WebUtil Core bean.
- Step 5 - Store the retrieved value in the local variable result.
- Step 6 - Return result to the caller.
- Step 7 - If the WebUtil Core bean is not registered (BEAN_NOT_REGISTERED exception), display an error alert identifying the missing implementation class and raise FORM_TRIGGER_FAILURE to halt form processing.
- Step 8 - If a property error occurs (PROPERTY_ERROR exception), raise FORM_TRIGGER_FAILURE to halt form processing without an additional alert.

---
**Decision Points**

DP-001

Condition: propertyName IS NOT NULL

TRUE: Proceed to invoke WebUtil_Core.setProperty and WebUtil_Core.getProperty to resolve and return the client-side property value.

FALSE: Skip the WebUtil_Core calls entirely and return a null result to the caller.

DP-002

Condition: WebUtil_Core raises the BEAN_NOT_REGISTERED exception during property access.

TRUE: Display an error alert identifying the unregistered implementation class and raise FORM_TRIGGER_FAILURE to abort the current form trigger.

FALSE: Continue normal processing; no alert is raised.

DP-003

Condition: WebUtil_Core raises the PROPERTY_ERROR exception during property access.

TRUE: Raise FORM_TRIGGER_FAILURE to abort the current form trigger without displaying an additional alert.

FALSE: Continue normal processing; result is returned successfully.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A null propertyName must not be passed to the WebUtil_Core bean; if propertyName is null, the function returns null immediately without attempting any client-side property lookup.
- BR-002 - The WebUtil Core bean (WUC_PACKAGE) must be registered and available at the time this function is called; if the bean is not registered, form processing must be halted via FORM_TRIGGER_FAILURE.
- BR-003 - Any property resolution error reported by WebUtil_Core (PROPERTY_ERROR) must cause immediate termination of the current form trigger via FORM_TRIGGER_FAILURE, ensuring the caller does not receive a partial or erroneous result.
- BR-004 - The returned property value is limited to 255 characters; values exceeding this length cannot be returned by this function.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetClientSetting(propertyName in VARCHAR2) return VARCHAR2 is 
    result VARCHAR2(255 char);
  BEGIN
    if propertyName is not null then 
    WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_GET_LOCAL_PROPERTY', propertyName);
       result := WebUtil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_GET_LOCAL_PROPERTY');
    end if;
    return result;
  EXCEPTION  
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                            ||' bean not found. WEBUTIL_CORE.GetClientSetting will not work');
    RAISE FORM_TRIGGER_FAILURE;  
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE FORM_TRIGGER_FAILURE;       
  END GetClientSetting;
```

#### SP-025 - WEBUTIL.GETIMPLCLASS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the fully qualified Java implementation class name for a given WebUtil package by concatenating the standard WebUtil Java root path with the registered implementation class entry for the specified package identifier. This value is used by calling routines (such as WEBUTIL.FCLOSE) to resolve the correct Java class at runtime.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the package identifier (packageID) as an integer input parameter.
- Step 2 - Look up the implementation class string associated with packageID from the m_implClasses collection.
- Step 3 - Prefix the retrieved class string with the WEBUTIL_JAVA_ROOT constant to form the fully qualified Java class name.
- Step 4 - Return the concatenated fully qualified class name to the caller.

---
**Decision Points**

No conditional decision points exist in this function. The logic executes unconditionally: the implementation class entry is retrieved from m_implClasses using packageID and concatenated with WEBUTIL_JAVA_ROOT before being returned.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The packageID supplied must correspond to a valid index within the m_implClasses collection; an invalid or unregistered packageID will cause a runtime collection error.
- BR-002 - The fully qualified Java class name is always constructed by prepending WEBUTIL_JAVA_ROOT to the stored implementation class string; neither component may be substituted or omitted.
- BR-003 - This function has no side effects and performs no database interactions; it is a pure lookup and string-concatenation operation.

---
**Implementation Logic**

```plsql

  FUNCTION getImplClass(packageID PLS_INTEGER) return VARCHAR2 is
  BEGIN 
    return WEBUTIL_JAVA_ROOT||m_implClasses(packageID);    
  END;
```

#### SP-026 - WEBUTIL.GETLASTERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the last error code recorded by the AppServerFileReader Java object. The function interrogates the underlying Java instance via JNI and returns an integer error code, allowing the calling routine (WEBUTIL.SETDATA) to determine whether the most recent file-transfer operation completed successfully or encountered a fault.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the AppServerFileReader Java object reference (obj) passed by the caller.
- Step 2 - Clear the JNI argument list by setting args to NULL, ensuring no stale arguments are forwarded to the Java method.
- Step 3 - Invoke the Java instance method getLastError() on the oracle/forms/webutil/fileTransfer/AppServerFileReader class via JNI.CALL_INT_METHOD, passing FALSE (non-static call), the object reference, the fully qualified class name, the method name, and the method signature '()I' (no arguments, returns int).
- Step 4 - Return the integer error code produced by the Java method to the caller.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function unconditionally clears the argument list and delegates to the Java method, returning whatever integer value the Java layer provides.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The argument list (args) must be reset to NULL before each JNI call to prevent residual arguments from corrupting the Java method invocation.
- BR-002 - The function must be called with a valid AppServerFileReader Java object reference (obj); the object context determines which instance's last error code is retrieved.
- BR-003 - The returned integer value represents the last error state of the AppServerFileReader instance and must be interpreted by the caller (WEBUTIL.SETDATA) to decide on subsequent processing or error-handling actions.
- BR-004 - The Java method is invoked as an instance (non-static) method, as enforced by passing FALSE as the static-call flag to JNI.CALL_INT_METHOD.

---
**Implementation Logic**

```plsql
  FUNCTION getLastError(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_INT_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'getLastError', '()I', args); 
  END;
```

#### SP-027 - WEBUTIL.GETLASTERRORARGS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the argument string associated with the last error raised by the AppServerFileReader Java class. The function delegates directly to the underlying JNI layer to obtain a descriptive error-argument value from the Java object, enabling the caller (WEBUTIL.SETDATA) to inspect supplementary error context after a file-transfer operation fails.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the Java object reference (obj) that represents an active AppServerFileReader instance passed in by the caller.
- Step 2 - Reset the local args variable to NULL to ensure no residual argument data from a prior call is carried forward.
- Step 3 - Invoke the JNI.CALL_STRING_METHOD bridge, targeting the getLastErrorArgs() method on the oracle/forms/webutil/fileTransfer/AppServerFileReader Java class, passing the NULL args value and the method signature '()Ljava/lang/String;'.
- Step 4 - Return the VARCHAR2 string result produced by the JNI call to the caller, representing the error-argument details from the last recorded error on the Java object.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a single deterministic JNI method call and returns its result unconditionally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The args local variable must be set to NULL before the JNI call is made, ensuring that no argument data from any previous invocation is inadvertently passed to the Java method.
- BR-002 - The target Java method is fixed as getLastErrorArgs() on the oracle/forms/webutil/fileTransfer/AppServerFileReader class; the function must not be repurposed to interrogate any other Java class or method.
- BR-003 - The function returns the raw string value supplied by the JNI layer without transformation; any interpretation or handling of the returned error-argument string is the responsibility of the calling routine (WEBUTIL.SETDATA).

---
**Implementation Logic**

```plsql
  FUNCTION getLastErrorArgs(
    obj   ORA_JAVA.JOBJECT) RETURN VARCHAR2 IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_STRING_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'getLastErrorArgs', '()Ljava/lang/String;', args); 
  END;
```

#### SP-028 - WEBUTIL.GETNUMBER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Extracts a delimited numeric field from a source string at a specified position by delegating to WEBUTIL.GETSTRING (SP-032) for string extraction and converting the result to a NUMBER. This utility function enables callers within the WebUtil custom event handler to retrieve numeric values embedded in structured, delimiter-separated strings without duplicating parsing logic.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Source_string | varchar2 | IN |
| Field_position | number | IN |
| UnTerminated | Boolean | IN |
| Delimiter | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETSTRING ([SP-032](#SP-032--WEBUTIL.GETSTRING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the source string, the target field position, an optional Boolean flag indicating whether the final field is unterminated, and an optional delimiter character (defaulting to a comma).
- Step 2 - Invoke WEBUTIL.GETSTRING (SP-032), passing all four arguments unchanged, to extract the raw VARCHAR2 value located at the specified field position within the delimited source string.
- Step 3 - Apply Oracle's TO_NUMBER conversion to the VARCHAR2 value returned by WEBUTIL.GETSTRING.
- Step 4 - Return the resulting NUMBER value to the caller.

---
**Decision Points**

No conditional decision points exist in this function. All branching and field-parsing logic is fully delegated to WEBUTIL.GETSTRING (SP-032); WEBUTIL.GETNUMBER performs a direct pass-through of all parameters followed by an unconditional numeric conversion.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Field extraction logic is exclusively delegated to WEBUTIL.GETSTRING (SP-032); WEBUTIL.GETNUMBER must not duplicate or override delimiter-parsing behaviour.
- BR-002 - The delimiter parameter defaults to a comma if not supplied by the caller, consistent with the default applied by WEBUTIL.GETSTRING.
- BR-003 - The UnTerminated flag defaults to FALSE if not supplied, indicating that the final field in the source string is expected to be terminated by the delimiter; callers must explicitly pass TRUE when the last field has no trailing delimiter.
- BR-004 - The value extracted at the specified field position must be implicitly castable to a NUMBER via TO_NUMBER; non-numeric content will raise a runtime conversion error and must be prevented by the caller prior to invocation.

---
**Implementation Logic**

```plsql

    
  function  GetNumber (Source_string    in varchar2,
                       Field_position   in number,
                       UnTerminated     in Boolean  default FALSE,
                       Delimiter        in varchar2 default ',') return number is
                       iRc              pls_integer;
  begin 
    Return to_number(GetString(Source_string, Field_Position, UnTerminated, Delimiter));
  end GetNumber; /* Number Version */
```

#### SP-029 - WEBUTIL.GETOSFAMILY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines and caches the client operating system family by inspecting the supplied OS name string and mapping it to a predefined platform constant (e.g., Windows, Mac, Linux, Solaris, HP-UX, AIX, or Unknown). The resolved platform value is stored in the module-level variable m_clientOSFamily so that subsequent calls return the cached result without re-evaluating the OS name. This function is invoked by WEBUTIL.REGISTERBEAN to establish the client platform context required during WebUtil bean registration.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| osName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the raw OS name string (osName) as input and convert it to lowercase, storing the result in the local variable l_osName to enable case-insensitive matching.
- Step 2 - Initialise the local result variable to CLIENT_PLATFORM_UNKNOWN as the default platform constant.
- Step 3 - Check whether the module-level cache variable m_clientOSFamily is NULL. If it is NOT NULL, skip all evaluation steps and proceed directly to Step 10, returning the already-cached value.
- Step 4 - If m_clientOSFamily IS NULL, evaluate l_osName for the substring 'windows'. If found, set result to CLIENT_PLATFORM_WIN32.
- Step 5 - If 'windows' was not matched, evaluate l_osName for the substring 'mac'. If found, set result to CLIENT_PLATFORM_MAC.
- Step 6 - If 'mac' was not matched, evaluate l_osName for the substring 'linux'. If found, set result to CLIENT_PLATFORM_LINUX.
- Step 7 - If 'linux' was not matched, evaluate l_osName for the substrings 'solaris' or 'sunos'. If either is found, set result to CLIENT_PLATFORM_SOLARIS.
- Step 8 - If neither Solaris indicator was matched, evaluate l_osName for the substring 'hp-ux'. If found, set result to CLIENT_PLATFORM_HP.
- Step 9 - If 'hp-ux' was not matched, evaluate l_osName for the substring 'aix'. If found, set result to CLIENT_PLATFORM_AIX.
- Step 10 - Assign the resolved result value to the module-level variable m_clientOSFamily, persisting it for future calls.
- Step 11 - Return m_clientOSFamily to the caller.

---
**Decision Points**

DP-001

Condition: m_clientOSFamily IS NULL (i.e., the OS family has not yet been determined and cached for this session).

TRUE: Proceed through the OS name pattern-matching chain (DP-002 through DP-007) to resolve the platform constant, assign it to m_clientOSFamily, and return it.

FALSE: Bypass all pattern-matching logic and return the already-cached value of m_clientOSFamily immediately.

---

DP-002

Condition: The lowercase OS name contains the substring 'windows'.

TRUE: Set result to CLIENT_PLATFORM_WIN32.

FALSE: Continue to DP-003.

---

DP-003

Condition: The lowercase OS name contains the substring 'mac'.

TRUE: Set result to CLIENT_PLATFORM_MAC.

FALSE: Continue to DP-004.

---

DP-004

Condition: The lowercase OS name contains the substring 'linux'.

TRUE: Set result to CLIENT_PLATFORM_LINUX.

FALSE: Continue to DP-005.

---

DP-005

Condition: The lowercase OS name contains the substring 'solaris' OR the substring 'sunos'.

TRUE: Set result to CLIENT_PLATFORM_SOLARIS.

FALSE: Continue to DP-006.

---

DP-006

Condition: The lowercase OS name contains the substring 'hp-ux'.

TRUE: Set result to CLIENT_PLATFORM_HP.

FALSE: Continue to DP-007.

---

DP-007

Condition: The lowercase OS name contains the substring 'aix'.

TRUE: Set result to CLIENT_PLATFORM_AIX.

FALSE: result remains CLIENT_PLATFORM_UNKNOWN; no recognised OS family was matched.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - OS name matching is case-insensitive; the input string is converted to lowercase before any comparison is performed, ensuring that variations in OS name casing (e.g., 'Windows', 'WINDOWS', 'windows') are handled uniformly.
- BR-002 - Platform resolution follows a strict priority order: Windows is evaluated first, followed by Mac, Linux, Solaris/SunOS, HP-UX, and AIX. Only the first matching condition is applied; subsequent conditions are not evaluated once a match is found.
- BR-003 - Solaris is identified by either the substring 'solaris' or the substring 'sunos', accommodating both the commercial OS name and its underlying kernel name.
- BR-004 - If the OS name does not match any recognised platform substring, the function returns CLIENT_PLATFORM_UNKNOWN as the default platform constant.
- BR-005 - The resolved platform constant is cached in the module-level variable m_clientOSFamily after the first successful evaluation. All subsequent invocations within the same session return the cached value without re-evaluating the OS name, guaranteeing a single determination per session.

---
**Implementation Logic**

```plsql
 
  FUNCTION getOSFamily(osName in VARCHAR2) return PLS_INTEGER is
    l_osName VARCHAR2(30) := lower(osName);
    result   PLS_INTEGER  := CLIENT_PLATFORM_UNKNOWN;
  BEGIN
    if m_clientOSFamily  is null then 
      if (instr(l_osName,'windows') > 0) then 
           result := CLIENT_PLATFORM_WIN32;
      elsif instr(l_osName,'mac') > 0 then 
          result := CLIENT_PLATFORM_MAC;      
      elsif instr(l_osName,'linux') > 0 then 
          result := CLIENT_PLATFORM_LINUX;      
      elsif instr(l_osName,'solaris') > 0 OR instr(l_osName, 'sunos') > 0 then 
          result := CLIENT_PLATFORM_SOLARIS;       
      elsif instr(l_osName,'hp-ux') > 0 then 
          result := CLIENT_PLATFORM_HP; 
      elsif instr(l_osName,'aix') > 0 then 
          result := CLIENT_PLATFORM_AIX;                                                       
      end if;            
      m_clientOSFamily := result;
    end if;
    return m_clientOSFamily;
  END getOSFamily;
```

#### SP-030 - WEBUTIL.GETOUTPUT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GET_STANDARD_OUTPUT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves all lines of output associated with a given client-side process by repeatedly polling the WebUtil host bean via WebUtil_Core property calls. The function accumulates each output line into an array and returns the complete OUTPUT_ARRAY to the caller (WEBUTIL.GET_STANDARD_OUTPUT). It also ensures the WebUtil Core component is initialised before execution begins.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |
| prop | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.INIT ([SP-037](#SP-037--WEBUTIL.INIT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Initialise local variables: an empty OUTPUT_ARRAY (lines), a line counter (i = 1), a 257-character buffer, and a status flag defaulted to 'X' (empty).
- Step 2 - Set the process handle on the WebUtil host bean by calling WebUtil_Core.setProperty with the WUH_PACKAGE context, the property key 'WUH_PROC_ID', and the handle value from the supplied process parameter.
- Step 3 - Enter a loop: call WebUtil_Core.getProperty with the WUH_PACKAGE context and the caller-supplied prop parameter to retrieve the next buffered output line into buffer.
- Step 4 - Extract the first character of buffer into status. A value of 'Y' indicates more lines remain; 'N' indicates this is the last line; 'X' indicates the buffer was empty.
- Step 5 - If status is not 'X', store the remainder of buffer (characters from position 2 onward) as the next element in the lines array and increment the counter i.
- Step 6 - Exit the loop when status is not 'Y' (i.e., the final line 'N' has been processed or the buffer was empty 'X').
- Step 7 - Return the populated lines array to the caller.
- Step 8 - On exception BEAN_NOT_REGISTERED, display an error alert identifying the missing bean class and indicating that WEBUTIL_HOST.GetOutput will not function.
- Step 9 - In the package initialisation block, call Webutil_Core.Init to ensure the Core component is instantiated before any function in this package executes.

---
**Decision Points**

DP-001

Condition: status (first character of the retrieved buffer) is not equal to 'X'.

TRUE: The buffer contains a valid output line; store characters from position 2 onward into the lines array at index i and increment i.

FALSE: The buffer is empty; skip storage and proceed to the exit evaluation.

DP-002

Condition: status is not equal to 'Y' (exit-when clause).

TRUE: No further lines are expected ('N' - last line, or 'X' - empty buffer); exit the loop and return the accumulated lines array.

FALSE: More output lines remain ('Y'); continue looping and retrieve the next line.

DP-003

Condition: The WebUtil host bean is not registered (exception BEAN_NOT_REGISTERED is raised).

TRUE: Display an error alert identifying the unregistered bean class and indicating that WEBUTIL_HOST.GetOutput will not work; function does not return a value.

FALSE: No exception; normal processing completes and the lines array is returned.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The process handle must be set on the WUH_PACKAGE context via WebUtil_Core.setProperty before any output retrieval is attempted; this binds subsequent getProperty calls to the correct client-side process.
- BR-002 - Each value returned by WebUtil_Core.getProperty is a composite string: the first character is a control status flag ('Y', 'N', or 'X') and the actual output content begins at character position 2.
- BR-003 - A status of 'X' signifies an empty buffer; such a response must not be stored as an output line.
- BR-004 - The retrieval loop must continue as long as status equals 'Y'; only a status of 'N' (last line) or 'X' (empty) terminates the loop.
- BR-005 - If the WebUtil host bean is not registered, the function must surface a descriptive error alert (including the bean implementation class name) and must not silently fail or return partial data.
- BR-006 - WebUtil Core must be initialised (Webutil_Core.Init) at package startup to guarantee that all bean interactions within the package operate against a valid Core instance.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetOutput(process in PROCESS_ID, prop in VARCHAR2) return OUTPUT_ARRAY is   
    lines  OUTPUT_ARRAY;
    i      PLS_INTEGER := 1;
    buffer VARCHAR2(257 char);
    status VARCHAR2(1) := 'X';
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_PROC_ID',process.handle);
    LOOP
      buffer := WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,prop);
      status := substr(buffer,1,1);
      -- Status can be Y: indicating more lines to follow,
      --               N: indicating that this is the last line
      --               X: indicating that the buffer was empty
      if status <> 'X' then 
        lines(i) := substr(buffer,2);
        i := i + 1;
      end if;
      exit when status <> 'Y';
    END LOOP;
    return lines;    
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.GetOutput will not work');
  END GetOutput;  
  
BEGIN
    -- Ensure that Core is instanciated.
    Webutil_Core.Init;
END;

PACKAGE WEBUTIL_SEPARATEFRAME IS

/*********************************************************************************\
 * WEBUTIL_SEPARATEFRAME
 *   This Package contains routines to interact with the MDI frame when Forms
 *   is running with the parameter separateFrame=true
 *   The functions in this package will work with any client type - not just 
 *   Windows clients.
 *   The oracle.forms.webutil.browser.BrowserFunctions bean is needed in your 
 *   Form to use these functions
 *********************************************************************************
 * Version 1.0.0
 *********************************************************************************
 * Change History
 *   1.0.0 DRMILLS 25/MAY/2003 - Creation
 *   1.0.1 DRMILLS 27/MAY/2003 - Added call to get frame size 
 *
\*********************************************************************************/

  /**
   *  IsSeparateFrame - Allows you to check if the form 
   *                is running in separateFrame mode or not
   */
```

#### SP-031 - WEBUTIL.GETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FOPEN]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a named Java system property at runtime by delegating to the Java Native Interface (JNI) layer. Callers such as WEBUTIL.FOPEN and WEBUTIL.REGISTERBEAN use this function to interrogate the underlying Java environment (e.g., file separators, OS name, user home directory) without requiring direct Java code in the PL/SQL layer.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the property key (a0) that identifies the Java system property to be retrieved.
- Step 2 - Create a JNI argument list sized for one argument by calling JNI.CREATE_ARG_LIST(1), storing the handle in the shared args variable.
- Step 3 - Add the property key string to the argument list via JNI.ADD_STRING_ARG, binding a0 as the sole argument.
- Step 4 - Invoke the Java static method java.lang.System.getProperty(String) through JNI.CALL_STRING_METHOD, passing the class path 'java/lang/System', method name 'getProperty', the JNI method signature '(Ljava/lang/String;)Ljava/lang/String;', and the prepared argument list.
- Step 5 - Return the VARCHAR2 string value produced by the JNI call directly to the caller.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function unconditionally constructs the JNI argument list, invokes the Java method, and returns the result. All branching (e.g., handling a null or missing property) is deferred to the calling routines WEBUTIL.FOPEN and WEBUTIL.REGISTERBEAN.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Exactly one input argument (the property key) must be supplied; the JNI argument list is explicitly sized to 1, so passing a different number of arguments is not supported by this function.
- BR-002 - The property lookup is performed against the live Java runtime environment (java.lang.System) via JNI; the function does not consult any database table or Forms-layer cache.
- BR-003 - The function returns whatever value the Java runtime associates with the given key, including NULL if the property is not defined; no default value substitution is applied within this function.
- BR-004 - The JNI call is made in a static-method context (first argument to JNI.CALL_STRING_METHOD is TRUE and the object reference is NULL), meaning no Java object instantiation is required prior to invocation.

---
**Implementation Logic**

```plsql
  FUNCTION getProperty(
    a0    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'getProperty', '(Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-032 - WEBUTIL.GETSTRING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETNUMBER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Extracts and returns a single delimited token from a source string based on its positional index. Given a delimiter-separated string, a field position, and an optional delimiter character, the function isolates the substring occupying that position and returns it as a varchar2 value. It is invoked by WEBUTIL.GETNUMBER to support numeric field extraction from delimited strings.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Source_string | varchar2 | IN |
| Field_position | number | IN |
| UnTerminated | Boolean | IN |
| Delimiter | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-041](#SP-041--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the source string, the 1-based field position, an optional UnTerminated flag (default FALSE), and an optional delimiter character (default comma).
- Step 2 - Copy the source string into a local working variable (vcSourceStrCopy) to avoid mutating the original input.
- Step 3 - If the UnTerminated flag is TRUE, append the delimiter character to the end of the working copy so that the final token in a string that lacks a trailing delimiter is still bounded and can be located correctly.
- Step 4 - Determine the start pointer (iPtrStart): if Field_Position is greater than 1, locate the (Field_Position - 1)th occurrence of the delimiter within the working copy using INSTR and advance the pointer past the delimiter by adding the delimiter's length; if Field_Position equals 1, set the start pointer to 1 (the beginning of the string).
- Step 5 - Determine the end pointer (iPtrEnd) by locating the Field_Position-th occurrence of the delimiter within the working copy using INSTR.
- Step 6 - Extract and return the substring between iPtrStart and iPtrEnd using SUBSTR, with the length calculated as (iPtrEnd - iPtrStart).

---
**Decision Points**

DP-001

Condition: UnTerminated is TRUE.

TRUE: The delimiter is appended to the end of the working copy of the source string before any parsing begins, ensuring the last token is properly bounded.

FALSE: The source string working copy is used as-is, with no modification; the caller is assumed to have provided a string that already terminates with a delimiter or whose last token is not being targeted.

---

DP-002

Condition: Field_Position is greater than 1.

TRUE: The start pointer is calculated by finding the (Field_Position - 1)th delimiter occurrence via INSTR and then advancing past the delimiter by adding the delimiter's character length, positioning the pointer at the first character of the target token.

FALSE: Field_Position equals 1, so the start pointer is set to 1, meaning extraction begins at the very start of the working string.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Field positions are 1-based; a Field_Position of 1 targets the first token in the delimited string.
- BR-002 - The default delimiter is a comma (','). An alternative single or multi-character delimiter may be supplied by the caller; the function accounts for delimiter length when computing the start pointer.
- BR-003 - If the source string does not carry a trailing delimiter after its last token, the caller must pass UnTerminated = TRUE so that the function appends one before parsing; failure to do so will result in the final token not being returned correctly.
- BR-004 - The function does not modify the original Source_string parameter; all manipulation is performed on an internal working copy (vcSourceStrCopy).
- BR-005 - The function returns only the content between the bounding delimiters; the delimiters themselves are not included in the returned value.
- BR-006 - The source string working copy supports up to 32,000 characters (varchar2(32000)); inputs exceeding this length are not supported.

---
**Implementation Logic**

```plsql

  function  GetString (Source_string    in varchar2,
                       Field_position   in number,
                       UnTerminated     in Boolean  default FALSE,
                       Delimiter        in varchar2 default ',') return varchar2 is
                       iPtrEnd          pls_integer     := 0;
                       iPtrStart        pls_integer     := 0;
                       vcSourceStrCopy  varchar2(32000)     := Source_string;
  begin
    if UnTerminated then 
      vcSourceStrCopy := vcSourceStrCopy||Delimiter;
    end if;

    if Field_Position > 1 then 
      iPtrStart := instr(vcSourceStrCopy,Delimiter,1,Field_Position-1)+ length(Delimiter);
    else
      iPtrStart := 1;
    end if ; 

    iPtrEnd     := instr(vcSourceStrCopy,Delimiter,1,Field_Position);
    return substr(vcSourceStrCopy,iPtrStart,(iPtrEnd-iPtrStart));
  end GetString; /* String Version */
```

#### SP-033 - WEBUTIL.GETVAR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.GETVAR retrieves the value of a named configuration or environment variable from the client machine. The retrieval strategy is determined by the client operating system family: on Windows clients, the procedure first queries the Oracle registry key and then falls back to the Windows environment string; on Unix clients, it executes the 'env' command and parses its output; on Mac or unknown platforms, no action is taken and the output value is left unchanged.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VARNAME | VARCHAR2 | IN |
| VARVALUE | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VARVALUE | VARCHAR2 | IN OUT |

---

**Dependencies**

- GET_ENVIRONMENT_STRING ([SP-061](#SP-061--GET_ENVIRONMENT_STRING)) - matched by member name
- READ_REGISTRY ([SP-062](#SP-062--READ_REGISTRY)) - matched by member name
- WEBUTIL.BLOCKING ([SP-011](#SP-011--WEBUTIL.BLOCKING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTOSFAMILY ([SP-023](#SP-023--WEBUTIL.GETCLIENTOSFAMILY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_STANDARD_OUTPUT ([SP-035](#SP-035--WEBUTIL.GET_STANDARD_OUTPUT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.RELEASE_PROCESS ([SP-049](#SP-049--WEBUTIL.RELEASE_PROCESS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Determine the client OS family by calling WEBUTIL.GETCLIENTOSFAMILY.
- Step 2 - If the client is Windows (CLIENT_PLATFORM_WIN32), attempt to read the variable value from the Windows registry under 'HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE' using READ_REGISTRY, passing VARNAME as the value key.
- Step 3 - If the registry lookup returns NULL or an empty string, fall back to retrieving the value directly from the Windows environment using GET_ENVIRONMENT_STRING, passing VARNAME.
- Step 4 - If the client is Mac (CLIENT_PLATFORM_MAC) or an unknown platform (CLIENT_PLATFORM_UNKNOWN), take no action; VARVALUE remains unchanged.
- Step 5 - If the client is any other platform (Unix), execute the shell command 'env' synchronously via WEBUTIL.BLOCKING to obtain a full list of environment variable assignments, storing the process handle.
- Step 6 - Retrieve the standard output of the 'env' command as an array of strings using WEBUTIL.GET_STANDARD_OUTPUT.
- Step 7 - Release the process handle using WEBUTIL.RELEASE_PROCESS.
- Step 8 - Iterate through each line of the output array; for each line, locate the '=' delimiter, extract the key (left of '='), and compare it to VARNAME. If a match is found, extract the value (right of '=') into VARVALUE and exit the loop.
- Step 9 - If a NO_DATA_FOUND exception is raised at any point, set VARVALUE to NULL and return.

---
**Decision Points**

DP-001
Condition: Client OS family equals CLIENT_PLATFORM_WIN32.
TRUE: Attempt registry lookup under 'HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE' for VARNAME, then fall back to environment string if registry returns no value.
FALSE: Proceed to DP-002.

DP-002
Condition: Client OS family is CLIENT_PLATFORM_MAC or CLIENT_PLATFORM_UNKNOWN.
TRUE: Take no action; procedure exits without setting VARVALUE.
FALSE: Treat client as a Unix platform and proceed to execute the 'env' command.

DP-003
Condition: (Windows path) The value returned by READ_REGISTRY for VARNAME is NULL or empty string.
TRUE: Call GET_ENVIRONMENT_STRING to retrieve VARVALUE from the Windows environment.
FALSE: Use the registry-returned value as VARVALUE.

DP-004
Condition: (Unix path) A '=' delimiter is found at position greater than zero in the current output line.
TRUE: Extract the key portion and compare it to VARNAME.
FALSE: Skip the current line and continue iterating.

DP-005
Condition: (Unix path) The extracted key from the current output line equals VARNAME.
TRUE: Assign the value portion (right of '=') to VARVALUE and exit the loop.
FALSE: Continue iterating through remaining output lines.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The variable resolution strategy is strictly platform-dependent; Windows, Unix, and Mac/unknown clients each follow a distinct and mutually exclusive code path.
- BR-002 - On Windows clients, the Oracle registry path 'HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE' is always the primary lookup source before the environment string is consulted.
- BR-003 - On Windows clients, the environment string fallback (GET_ENVIRONMENT_STRING) is invoked only when the registry lookup yields NULL or an empty string; it is not called unconditionally.
- BR-004 - On Mac and unknown-platform clients, VARVALUE is never modified by this procedure; the caller receives the value passed in unchanged.
- BR-005 - On Unix clients, environment variable resolution is performed by parsing the full output of the 'env' command; the process is executed synchronously (WEBUTIL.BLOCKING) and its handle must be explicitly released via WEBUTIL.RELEASE_PROCESS after output retrieval.
- BR-006 - On Unix clients, only the first matching environment variable line is used; once a match is found the loop exits immediately.
- BR-007 - A NO_DATA_FOUND exception anywhere in the procedure results in VARVALUE being set to NULL, ensuring the caller always receives a defined output state.

---
**Implementation Logic**

```plsql

  PROCEDURE GETVAR(VARNAME IN VARCHAR2, VARVALUE IN OUT VARCHAR2) is
    unixOutput WebUtil_HOST.OUTPUT_ARRAY;
    hostHandle WebUtil_HOST.PROCESS_ID;
    varKey     VARCHAR2(100);
    iPos       PLS_INTEGER;
  BEGIN
    if WebUtil_Core.GetClientOSFamily = WebUtil_Core.CLIENT_PLATFORM_WIN32 then 
      -- read the client Registry
      VARVALUE := Client_Win_API_Environment.read_registry('HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE',VARNAME,false);
      if VARVALUE is null OR VARVALUE = '' then
        -- Could not get an Oracle variable in registry. Try to get from environment varialble
        -- java desupported System.getenv method until they supported it again in 1.5.
        -- We can still get the environment variables in windows using
        -- CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING
        VARVALUE := CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING(VARNAME);
      end if;
    elsif WebUtil_Core.GetClientOSFamily in (WebUtil_Core.CLIENT_PLATFORM_MAC,WebUtil_Core.CLIENT_PLATFORM_UNKNOWN) then 
      -- do nothing 
      null;
    else
      -- Unix Ports - do a env to get the environment and parse that
      hostHandle := WebUtil_HOST.Blocking('env');
      unixOutput := WebUtil_HOST.Get_Standard_Output(hostHandle);
      WebUtil_HOST.Release_Process(hostHandle);
      for i in 1..unixOutput.count LOOP
        iPos := instr(unixOutput(i),'=');
        if iPos > 0 then 
          varKey := substr(unixOutput(i),1,iPos-1);
          if varKey = VARNAME then 
            VARVALUE := substr(unixOutput(i),iPos+1);
            EXIT;
          end if;
        end if;
      end LOOP;
    end if;

  exception
    when NO_DATA_FOUND then
      VARVALUE := null;
  END GETVAR;

END CLIENT_TOOL_ENV;

PACKAGE Client_Win_API IS
/*-------------------------------------------------------------------------------*\
 * WebUtil version of D2KWUTIL package WIN_API                                     
 * Note: Not all D2kWutil Functions are ported
 *********************************************************************************
 * Version 1.0.0
 *********************************************************************************
 * Change History
 *   DRMILLS 21/FEB/2003 - Port Creation
 *
 *********************************************************************************
 * WIN_API ->  This package defines the constants used throughout 
 *      the library as a whole, including versions of those 
 *      constants defined within WINDOWS.H/WINUSER.H that 
 *      we'll be using. Add more constants in here if required
 *      The package also contains Explicit Exception declarations,
 *      various status Flags and functions for Error Handling
 * NOTE:    In order to make this library portable across Forms
 *      and Reports we do not use any application 
 *      specific built-ins such as the Forms MESSAGE() 
 *      Built-in. Instead errors are recorded in a package
 *      variable which the programmer can examine if required
\*-------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------*\
 * Internal Version Number  ** Oracle Developer Release 6.0 Version
\*-------------------------------------------------------------------------------*/
  WIN_API_VERSION  CONSTANT  VARCHAR2(30) := '6.0.6.0 Production';
  DLL_NAME         CONSTANT  VARCHAR2(12) := 'd2kwut60.dll';
  DLL_PATH         VARCHAR2(256)          := NULL;

/*-------------------------------------------------------------------------------*\
 * General Window Classes of Common Applications for use with WIN_API_SESSION
 * ** WARNING ** These Window classes are out of our control and might change 
 *               when you upgrade the software in question,
\*-------------------------------------------------------------------------------*/

  -- Oracle Apps
  WINCLASS_DEVELOPER_2000_V1  CONSTANT  VARCHAR2(15)  := 'ui23MDIroot_W32';             /* Developer/2000 release 1.n / Toolkit 2.3 Apps on 32 bit */
  WINCLASS_DEVELOPER_2000_V2  CONSTANT  VARCHAR2(15)  := 'ui25MDIroot_W32';             /* Developer/2000 Release 2.0 / Toolkit 2.5 Apps on 32 bit */
  WINCLASS_DEVELOPER_2000_V6  CONSTANT  VARCHAR2(15)  := 'ui60MDIroot_W32';             /* Developer/2000 Release 6.0 / Toolkit 6.0 Apps on 32 bit */  
  D2K_WINDOW_CLASS            CONSTANT  VARCHAR2(15)  := WINCLASS_DEVELOPER_2000_V6;    /* Set to the "current" version */  
  WINCLASS_INTEROFFICE_40     CONSTANT  VARCHAR2(28)  := 'Afx:10000000:b:10008:6:5023b';/* Oracle Interoffice 4.0 Client 32 bit */
  WINCLASS_INTEROFFICE_41     CONSTANT  VARCHAR2(28)  := 'Afx:10000000:b:1496:6:3a17';  /* Oracle Interoffice 4.0 Client 32 bit */
  WINCLASS_SQLPLUS            CONSTANT  VARCHAR2(13)  := 'SqlplusWClass';               /* Sql*Plus 32 bit */
  WINCLASS_REPORTSSERVER_V1   CONSTANT  VARCHAR2(15)  := 'R25SRV_WINCLASS';             /* Reports Server Reports 2.5 */
  WINCLASS_REPORTSSERVER_V2   CONSTANT  VARCHAR2(15)  := 'R30SRV_WINCLASS';             /* Reports Server Reports 3.0 */
  WINCLASS_REPORTSSERVER_V6   CONSTANT  VARCHAR2(14)  := 'RWRBE_WINCLASS';              /* Reports Server Reports 6.0 */

  -- Microsoft Office Apps - Office97
  WINCLASS_MSWORD_97         CONSTANT  VARCHAR2(7) := 'OpusApp';                        /* Microsoft Word 97 */
  WINCLASS_MSEXCEL_97        CONSTANT  VARCHAR2(6) := 'XLMAIN';                         /* Microsoft Excel 97 */
  WINCLASS_MSPOWERPOINT_97   CONSTANT  VARCHAR2(14):= 'PP97FrameClass';                 /* Microsoft Power Point 97 */

  -- Microsoft Office Apps - Office95
  WINCLASS_MSWORD_7          CONSTANT  VARCHAR2(7) := 'OpusApp';                        /* Microsoft Word 7 */
  WINCLASS_MSEXCEL_7         CONSTANT  VARCHAR2(6) := 'XLMAIN';                         /* Microsoft Excel 7 */
  WINCLASS_MSPOWERPOINT_7    CONSTANT  VARCHAR2(13):= 'PP7FrameClass';                  /* Microsoft Power Point 7 */
  WINCLASS_MSSCHEDULE_7      CONSTANT  VARCHAR2(23):= 'MS Schedule+ 32 Panesdi';        /* Microsoft Schedule 7 */
  WINCLASS_MSEXCHANGE_4      CONSTANT  VARCHAR2(29):= 'Microsoft Exchange 4.0 Viewer';  /* Microsoft Exchange 4 in-tray */

  -- Microsoft O/S Utilities
  WINCLASS_INETEXPLORER      CONSTANT  VARCHAR2(7):= 'IEFrame';                         /* Internet Explorer */
  WINCLASS_OUTLOOK_EXPRESS   CONSTANT  VARCHAR2(29):= 'Outlook Express Browser Class';  /* Outlook Express */
  WINCLASS_EXPLORER          CONSTANT  VARCHAR2(13):= 'ExploreWClass';                  /* Explorer */
  WINCLASS_MYCOMPUTER        CONSTANT  VARCHAR2(13):= 'CabinetWClass';                  /* My Computer & Network Neighborhood*/
  WINCLASS_CALCULATOR        CONSTANT  VARCHAR2(7) := 'SciCalc';                        /* Windows Calculator */
  WINCLASS_NOTEPAD           CONSTANT  VARCHAR2(7) := 'Notepad';                        /* Windows Notepad */
  WINCLASS_WORDPAD           CONSTANT  VARCHAR2(12):= 'WordPadClass';                   /* Windows Wordpad/Write */
  WINCLASS_DOS               CONSTANT  VARCHAR2(18):= 'ConsoleWindowClass';             /* Dos Window */

  -- Other
  WINCLASS_NETSCAPE_3        CONSTANT  VARCHAR2(27):= 'Afx:40000000:b:150e:6:38cfe';    /* Netscape Navigator 3.0 */
  WINCLASS_NETSCAPE_4        CONSTANT  VARCHAR2(28):= 'Afx:40000000:b:10008:6:6063e';   /* Netscape Communicator 4.0 */
  WINCLASS_PFE_7             CONSTANT  VARCHAR2(11):= 'PFE32_Frame';                    /* Programmers File Editor */
  WINCLASS_REGEDIT           CONSTANT  VARCHAR2(15):= 'RegEdit_RegEdit';                /* Registry Editor */

  -- Window Style Constants (from WINUSER.H)
  --  Any PU's that use these constants will explain 
  --  their use.  For further information consult the
  --  Windows SDK.

  SW_HIDE              CONSTANT  PLS_INTEGER := 0;
  SW_SHOWNORMAL        CONSTANT  PLS_INTEGER := 1;
  SW_SHOWMINIMIZED     CONSTANT  PLS_INTEGER := 2;
  SW_SHOWMAXIMIZED     CONSTANT  PLS_INTEGER := 3;
  SW_SHOWNOACTIVATE    CONSTANT  PLS_INTEGER := 4;
  SW_SHOW              CONSTANT  PLS_INTEGER := 5;
  SW_MINIMIZE          CONSTANT  PLS_INTEGER := 6;
  SW_SHOWMINNOACTIVE   CONSTANT  PLS_INTEGER := 7;
  SW_SHOWNA            CONSTANT  PLS_INTEGER := 8;
  SW_RESTORE           CONSTANT  PLS_INTEGER := 9;
  SW_SHOWDEFAULT       CONSTANT  PLS_INTEGER := 10;

  -- Help Access Constants (From WINUSER.H)
  --  See WIN_API_SHELL.WinHelp

  HELP_CONTEXT         CONSTANT  PLS_INTEGER := 1;   /* 0x0001L */
  HELP_QUIT            CONSTANT  PLS_INTEGER := 2;   /* 0x0002L */
  HELP_INDEX           CONSTANT  PLS_INTEGER := 3;   /* 0x0003L */
  HELP_CONTENTS        CONSTANT  PLS_INTEGER := 3;   /* 0x0003L */
  HELP_HELPONHELP      CONSTANT  PLS_INTEGER := 4;   /* 0x0004L */
  HELP_SETINDEX        CONSTANT  PLS_INTEGER := 5;   /* 0x0005L */
  HELP_SETCONTENTS     CONSTANT  PLS_INTEGER := 5;   /* 0x0005L */
  HELP_CONTEXTPOPUP    CONSTANT  PLS_INTEGER := 8;   /* 0x0008L */
  HELP_FORCEFILE       CONSTANT  PLS_INTEGER := 9;   /* 0x0009L */
  HELP_KEY             CONSTANT  PLS_INTEGER := 257; /* 0x0101L */
  HELP_COMMAND         CONSTANT  PLS_INTEGER := 258; /* 0x0102L */
  HELP_PARTIALKEY      CONSTANT  PLS_INTEGER := 261; /* 0x0105L */
  HELP_MULTIKEY        CONSTANT  PLS_INTEGER := 513; /* 0x0201L */
  HELP_SETWINPOS       CONSTANT  PLS_INTEGER := 515; /* 0x0203L */
  -- Windows 4+
  HELP_CONTEXTMENU     CONSTANT  PLS_INTEGER := 10;  /* 0x000a  */
  HELP_FINDER          CONSTANT  PLS_INTEGER := 11;  /* 0x000b  */
  HELP_WM_HELP         CONSTANT  PLS_INTEGER := 12;  /* 0x000c  */
  HELP_SETPOPUP_POS    CONSTANT  PLS_INTEGER := 13;  /* 0x000d  */

  -- Windows Messages for use with SendMessage
  -- DO NOT utilise the Windows Sendmessage interface without being conversant
  -- with the Windows message handling mechanism
  -- Refer to the Microsoft Windows SDK for Messages and Parameter values
  WM_SYSCOMMAND        CONSTANT  PLS_INTEGER := 274;   /* 0x0112 */
  WM_MDITILE           CONSTANT  PLS_INTEGER := 550;   /* 0x0226 */
  WM_MDICASCADE        CONSTANT  PLS_INTEGER := 551;   /* 0x0227 */
  WM_MDIICONARRANGE    CONSTANT  PLS_INTEGER := 552;   /* 0x0228 */      
  SC_RESTORE           CONSTANT  PLS_INTEGER := 61728; /* 0xF120 */
  SC_MINIMIZE          CONSTANT  PLS_INTEGER := 61472; /* 0xF020 */
  SC_MAXIMIZE          CONSTANT  PLS_INTEGER := 61488; /* 0xF030 */
  

  -- Flags for use with File Dialog boxes ("Save As" or "Open")
  -- Refer to your Microsoft documentation for details on the 
  -- Exact usage and dependancies of each option
  OFN_READONLY           CONSTANT  PLS_INTEGER := 1;        /* 0x00000001 */
  OFN_OVERWRITEPROMPT    CONSTANT  PLS_INTEGER := 2;        /* 0x00000002 */
  OFN_HIDEREADONLY       CONSTANT  PLS_INTEGER := 4;        /* 0x00000004 */
  OFN_NOCHANGEDIR        CONSTANT  PLS_INTEGER := 8;        /* 0x00000008 */
  OFN_SHOWHELP           CONSTANT  PLS_INTEGER := 16;       /* 0x00000010 */
  OFN_NOVALIDATE         CONSTANT  PLS_INTEGER := 256;      /* 0x00000100 */
  OFN_ALLOWMULTISELECT   CONSTANT  PLS_INTEGER := 512;      /* 0x00000200 */
  OFN_EXTENSIONDIFFERENT CONSTANT  PLS_INTEGER := 1024;     /* 0x00000400 */
  OFN_PATHMUSTEXIST      CONSTANT  PLS_INTEGER := 2048;     /* 0x00000800 */
  OFN_FILEMUSTEXIST      CONSTANT  PLS_INTEGER := 4096;     /* 0x00001000 */
  OFN_CREATEPROMPT       CONSTANT  PLS_INTEGER := 8192;     /* 0x00002000 */
  OFN_SHAREAWARE         CONSTANT  PLS_INTEGER := 16384;    /* 0x00004000 */
  OFN_NOREADONLYRETURN   CONSTANT  PLS_INTEGER := 32768;    /* 0x00008000 */
  OFN_NOTESTFILECREATE   CONSTANT  PLS_INTEGER := 65536;    /* 0x00010000 */
  OFN_NONETWORKBUTTON    CONSTANT  PLS_INTEGER := 131072;   /* 0x00020000 */
  OFN_NOLONGNAMES        CONSTANT  PLS_INTEGER := 262144;   /* 0x00040000 */
  OFN_EXPLORER           CONSTANT  PLS_INTEGER := 524288;   /* 0x00080000 */
  OFN_NODEREFERENCELINKS CONSTANT  PLS_INTEGER := 1048576;  /* 0x00100000 */
  OFN_LONGNAMES          CONSTANT  PLS_INTEGER := 2097152;  /* 0x00200000 */

  -- The defaults used here (WIN_API.OFN_PATHMUSTEXIST|WIN_API.OFN_FILEMUSTEXIST|WIN_API.OFN_HIDEREADONLY|WIN_API.OFN_NOCHANGEDIR|WIN_API.OFN_EXPLORER)
  OFN_FLAG_DEFAULT       CONSTANT  PLS_INTEGER :=  530444;
  
  
  -- Registry Data types for Write_RegistryEx
  REG_EXPAND_SZ          CONSTANT  PLS_INTEGER := 0;
  REG_SZ                 CONSTANT  PLS_INTEGER := 1;
  REG_DWORD              CONSTANT  PLS_INTEGER := 2;
  
  -- Compatibility Flags - Used where I have changed behaviour and you might not like the new version
  -- Change these at runtime to FALSE to revert to "old" behaviour
  COMPAT_EXPAND_REG_VALUES    BOOLEAN := TRUE;

  
  
  -- Types
  TYPE aFunctionHandle is table of WEBUTIL_C_API.FUNCTIONHANDLE index by BINARY_INTEGER;  
  SUBTYPE FILE_TYPE is PLS_INTEGER;

  -- Public Variables
  ERROR_ENCOUNTERED  BOOLEAN := FALSE;  /* The Last Call resulted in an error */
  ERROR_STACK        VARCHAR2(2000);    /* Holds Text of Last error(s) */ 
  API_ENABLED        BOOLEAN := FALSE;   /* Are API functions usable ?*/
  DLL_HANDLE         ORA_FFI.LibHandleType;
  FunctionHandle     aFunctionHandle;
   

  -- Public Exceptions
  NOT_AVAILABLE      EXCEPTION;  /* A call to the API was made but API functions not currently available (e.g. not on Windows) */
     
  -- Error Constants
  UError             CONSTANT  VARCHAR2(30) := ' Caused an unexpected error: ';
  NoAPI              CONSTANT  VARCHAR2(31) := 'API Functions are not Available';
  MaxDWord           CONSTANT  VARCHAR2(33) := 'Integer Argument exceeds 32 bits ';
  MaxWord            CONSTANT  VARCHAR2(33) := 'Integer Argument exceeds 16 bits ';
  MaxByte            CONSTANT  VARCHAR2(32) := 'Integer Argument exceeds 8 bits ';
  MinBound           CONSTANT  VARCHAR2(27) := 'Integer Argument too Small ';
  MaxBound           CONSTANT  VARCHAR2(27) := 'Integer Argument too Large ';
  NullArg            CONSTANT  VARCHAR2(24) := 'Argument cannot be NULL ';

  /*----------------------------------------------------------------------------*\
  * PreLoad ->  Loads the d2kwut60.dll from the jvm bin directory into memory
  \*----------------------------------------------------------------------------*/
```

#### SP-034 - WEBUTIL.GET_LINE

**Invoked From:**

- vr_cross_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Reads a single line of text from an open client-side text file and returns it to the caller. The procedure delegates the actual read operation to the WebUtil PJC (Pluggable Java Component) layer via WebUtil_Core property calls, and translates the PJC's end-of-file sentinel value into a standard Oracle NO_DATA_FOUND exception so that callers can detect end-of-file using conventional PL/SQL exception handling.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| item | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the file handle encapsulated in the IN parameter `file` (of type `file_type`).
- Step 2 - Pass the file handle to the WebUtil PJC by setting the `WUF_TEXTIO_HANDLE` property on the `WUF_PACKAGE` component via `WebUtil_Core.setProperty`.
- Step 3 - Request the next line of text from the PJC by reading the `WUF_TEXTIO_GETLINE` property via `WebUtil_Core.getProperty`; the result is stored in the local buffer variable.
- Step 4 - Evaluate the buffer contents: if the buffer equals a newline character (`CHR(10)`), interpret this as the PJC's end-of-file sentinel and raise `NO_DATA_FOUND` to signal that no further data is available.
- Step 5 - If the buffer does not equal `CHR(10)`, assign the buffer value to the OUT parameter `item` and return normally to the caller.
- Step 6 - If the WebUtil bean is not registered (`BEAN_NOT_REGISTERED` exception), display an error alert identifying the missing implementation class and raise `TOOL_ERR.TOOL_ERROR` to abort processing.
- Step 7 - If a property-level error occurs (`PROPERTY_ERROR` exception), raise `TOOL_ERR.TOOL_ERROR` to abort processing.

---
**Decision Points**

DP-001

Condition:
The value returned by the PJC into `buffer` equals `CHR(10)` (a newline character), which the PJC uses as the end-of-file sentinel.

TRUE:
Raise `NO_DATA_FOUND` to signal to the caller that the end of the file has been reached; `item` is not populated.

FALSE:
Assign `buffer` to the OUT parameter `item` and return the line of text to the caller.

---

DP-002

Condition:
A `BEAN_NOT_REGISTERED` exception is raised, indicating that the required WebUtil PJC bean is not available on the client.

TRUE:
Display an error alert naming the missing implementation class and raise `TOOL_ERR.TOOL_ERROR` to terminate execution.

FALSE:
Continue normal processing (no action taken for this exception path).

---

DP-003

Condition:
A `PROPERTY_ERROR` exception is raised during the property get or set operation.

TRUE:
Raise `TOOL_ERR.TOOL_ERROR` to terminate execution.

FALSE:
Continue normal processing (no action taken for this exception path).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A newline character (`CHR(10)`) returned in the read buffer is reserved exclusively as the PJC end-of-file sentinel; it must never be treated as valid line content, and its receipt must always trigger a `NO_DATA_FOUND` exception.
- BR-002 - The file handle supplied in the `file` parameter must be set on the PJC before attempting to read a line; the procedure does not validate the handle independently and relies on the PJC to enforce handle validity.
- BR-003 - If the WebUtil PJC bean is not registered on the client, the procedure must surface a descriptive error alert to the user and raise `TOOL_ERR.TOOL_ERROR`; silent failure is not permitted.
- BR-004 - Any property-level communication error with the PJC must result in `TOOL_ERR.TOOL_ERROR` being raised, ensuring that the calling routine (VIEW_EXCEL_REP in vr_cross_fmb.xml) is notified of the failure rather than receiving an empty or undefined value in `item`.

---
**Implementation Logic**

```plsql
  PROCEDURE get_line (file file_type, item OUT VARCHAR2) is
    buffer VARCHAR2(4000 char);
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);        
    buffer := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_GETLINE');
    -- We can't easily tell the difference between an empty line and a line beyond then 
    -- end of the file so to get around this, the exception handling code in the PJC 
    -- places a newline into the buffer when the end of file is passed.
    -- The rational being that get_line would never normally return a newline because 
    -- it normally uses that to tell it where to read up *to*.
    if buffer = chr(10) then 
      raise NO_DATA_FOUND;
    else
      item := buffer;
    end if;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.get_line will not work');
      RAISE TOOL_ERR.TOOL_ERROR;                                                                 
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE TOOL_ERR.TOOL_ERROR;  
  END get_line;
  
  /**
   * File writing functions
   */
```

#### SP-035 - WEBUTIL.GET_STANDARD_OUTPUT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the standard output (stdout) stream captured from a previously executed host process. The function acts as a named convenience wrapper that delegates to WEBUTIL.GETOUTPUT, passing the fixed stream identifier 'WUH_STDOUT' to isolate standard output from other output streams associated with the given process.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETOUTPUT ([SP-030](#SP-030--WEBUTIL.GETOUTPUT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the process identifier (PROCESS_ID) of a previously executed host process as the sole input.
- Step 2 - Invoke WEBUTIL.GETOUTPUT (SP-030), passing the supplied process identifier and the hard-coded stream key 'WUH_STDOUT' to request only the standard output stream.
- Step 3 - Return the OUTPUT_ARRAY result received from WEBUTIL.GETOUTPUT directly to the caller.

---
**Decision Points**

No decision points are present in this function. The implementation unconditionally delegates to WEBUTIL.GETOUTPUT and returns its result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The stream identifier used to retrieve output is fixed as 'WUH_STDOUT'; this function exclusively targets the standard output stream and cannot be redirected to any other stream at runtime.
- BR-002 - The function returns an OUTPUT_ARRAY; the caller is responsible for handling an empty or null array if no standard output was produced by the referenced process.
- BR-003 - A valid PROCESS_ID must be supplied; the function performs no independent validation and passes the value directly to WEBUTIL.GETOUTPUT (SP-030).

---
**Implementation Logic**

```plsql
    
  FUNCTION Get_Standard_Output(process in PROCESS_ID) return OUTPUT_ARRAY is  
  begin 
    return GetOutput(process,'WUH_STDOUT');
  end Get_Standard_Output;
```

#### SP-036 - WEBUTIL.ID_NULL

**Invoked From:**

- vr_cross_fmb.xml [StoredProcedure: PROC_POP_LIST]
- vr_cross_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]
- webutil.pld [StoredProcedure: WEBUTIL.ERRORALERT]
- webutil.pld [StoredProcedure: WEBUTIL.INITWEBUTIL]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTER_FUNCTION]
- webutil.pld [StoredProcedure: WEBUTIL.SHOWBEANS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines whether a given handle object is null by inspecting its internal identifier field (hnd). The function returns a Boolean result that callers use to guard against operations on uninitialised or released handles within the WebUtil and cross-form utility routines.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| handle | Pointer | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the incoming handle (of type Pointer) passed by the calling routine.
- Step 2 - Inspect the internal identifier field (hnd) of the supplied handle.
- Step 3 - If hnd is null, return TRUE to indicate the handle is uninitialised or invalid.
- Step 4 - If hnd is not null, return FALSE to indicate the handle is valid and may be safely used by the caller.

---
**Decision Points**

DP-001

Condition:
The internal identifier field (hnd) of the supplied handle is null.

TRUE:
Return TRUE, signalling to the caller that the handle does not reference a valid object.

FALSE:
Return FALSE, signalling to the caller that the handle references a valid, initialised object.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A handle is considered null solely on the basis of its internal hnd field being null; no other attribute of the Pointer type is evaluated.
- BR-002 - The function is read-only and produces no side effects; it neither modifies the handle nor interacts with any database object.
- BR-003 - Callers must treat a TRUE return value as an indication that further operations on the handle are unsafe and should not proceed without first initialising the handle.

---
**Implementation Logic**

```plsql

  FUNCTION ID_NULL(handle IN Pointer)        RETURN BOOLEAN is
  BEGIN
    if handle.hnd is null then 
      return TRUE;
    else
      return FALSE;
    end if;
  END ID_NULL;
```

#### SP-037 - WEBUTIL.INIT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETOUTPUT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.INIT serves as the package initialisation entry point for the WEBUTIL_CORE package. Although the procedure body itself performs no explicit processing (it executes a null statement), its invocation triggers the package-level initialisation block, which calls WEBUTIL.INITWEBUTIL (SP-038) to set up the WebUtil utility environment on the client. The procedure is invoked by WEBUTIL.GETOUTPUT and exists to provide a named, callable initialisation hook that ensures the package is loaded and its BEGIN block executed.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.INITWEBUTIL ([SP-038](#SP-038--WEBUTIL.INITWEBUTIL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - WEBUTIL.GETOUTPUT invokes WEBUTIL.INIT to trigger package initialisation.
- Step 2 - The INIT procedure body executes a null statement; no explicit procedural logic is performed within the procedure itself.
- Step 3 - Entry into the WEBUTIL_CORE package causes the package-level initialisation block (BEGIN ... END WEBUTIL_CORE) to execute automatically.
- Step 4 - The package initialisation block calls WEBUTIL.INITWEBUTIL (SP-038), which performs the actual setup of the WebUtil utility environment.

---
**Decision Points**

No decision points are present. The procedure body contains only a null statement and delegates all substantive logic to the package initialisation block via the automatic execution of WEBUTIL.INITWEBUTIL (SP-038). No conditional branching exists within WEBUTIL.INIT or its package initialisation block.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The WEBUTIL_CORE package must be initialised before WebUtil functionality is available; invoking WEBUTIL.INIT guarantees the package initialisation block has fired.
- BR-002 - All substantive initialisation work is delegated exclusively to WEBUTIL.INITWEBUTIL (SP-038); WEBUTIL.INIT itself must not contain any additional processing logic.
- BR-003 - WEBUTIL.INIT accepts no input parameters and returns no output parameters; it is a side-effect-only entry point whose sole purpose is to trigger package load.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Init is
  begin 
    -- we don't need to do anything here - entering the package is enough to set it up.      
    null;
  end;      

BEGIN
  -- Initialise the Utility
  InitWebUtil;  
END WEBUTIL_CORE;

PACKAGE WEBUTIL_C_API IS
/*********************************************************************************\
 * WEBUTIL_C_API
 *   This Package provides a way of calling C functions in a shared library on the
 *   client PC. Currently only win32 is supported.
 *   The oracle.forms.webutil.cApi.CApiFunctions bean is needed in your Form to 
 *   use these functions
 *********************************************************************************
 * Version 1.0.5
 *********************************************************************************
 * Change History
 *   1.0.1 RVSUILIC 14/FEB/2003 - Creation 
 *   1.0.2 DRMILLS  27/FEB/2003 - Reset LONG to the same value as INT which is fine
 *                                for Windows & removed Tester proc
 *   1.0.3 DRMILLS  01/MAR/2003 - Re-worked the PL/SQL API
 *   1.0.4 DRMILLS  13/MAY/2003 - Added call to WebUtil_Core.Init
 *   1.0.5 RVSUILIC 21/MAY/2003 - Cleaned up some comments and formatting.
 *
\*********************************************************************************/

  /**
   *  Constants to represent PL/SQL IN, OUT and INOUT parameter qualifiers
   */
  PARAM_IN    CONSTANT PLS_INTEGER := 50;
  PARAM_INOUT CONSTANT PLS_INTEGER := 51;
  PARAM_OUT   CONSTANT PLS_INTEGER := 52;
  

  /**
   *  Constants to represent C atomic datatypes and pointers to atomic datatypes
   *  Note that to use OUT and INOUT qualifiers the C function in the DLL *must*
   *  use a pointer type to be able to pass information back.
   *
   *  The comments on the right indicate which types can be used for parameters
   *  and which for function return types.
   *
   *  c_ptr is used as a generic pointer. The onlys supported use for this is to
   *  save the pointer value from C into a PL/SQL variable, so that it may be 
   *  passed back later to C. No operations on the pointer are supported in PL/SQL.
   */
  c_void          CONSTANT PLS_INTEGER := 30;            /* - not used -   */
  c_char          CONSTANT PLS_INTEGER := 31;            /* param & return */
  c_short         CONSTANT PLS_INTEGER := 32;            /* param & return */
  c_int           CONSTANT PLS_INTEGER := 33;            /* param & return */
  c_long          CONSTANT PLS_INTEGER := 33;            /* param & return *//*DRM - same as INT */
  c_float         CONSTANT PLS_INTEGER := 35;            /* param & return */
  c_double        CONSTANT PLS_INTEGER := 36;            /* param & return */

  c_ptr           CONSTANT PLS_INTEGER := 64 + c_void;   /* param & return */
  c_char_ptr      CONSTANT PLS_INTEGER := 64 + c_char;   /* param          */
  c_short_ptr     CONSTANT PLS_INTEGER := 64 + c_short;  /* param          */
  c_int_ptr       CONSTANT PLS_INTEGER := 64 + c_int;    /* param          */
  c_long_ptr      CONSTANT PLS_INTEGER := 64 + c_long;   /* param          */
  c_float_ptr     CONSTANT PLS_INTEGER := 64 + c_float;  /* param          */
  c_double_ptr    CONSTANT PLS_INTEGER := 64 + c_double; /* param          */

  /**
   *  Abstracted types to be used for pointers and handles. The forms programmer
   *  should not attempt any manipulation on these types, but merely obtain them as
   *  a result of functions below, and pass them back in to other functions below.
   */
    SUBTYPE handleType   IS NUMBER;
    TYPE Pointer         IS RECORD (hnd handleType);   /* C pointer             */
    TYPE FunctionHandle  IS RECORD (hnd handleType);   /* function handle       */
    TYPE ParameterHandle IS RECORD (hnd handleType);   /* parameter handle      */
    TYPE ParameterList   IS RECORD (hnd handleType);   /* parameter list handle */

  /**
   *  IS_SUPPORTED - Check if the client is on a supported hardware platform.
   */
```

#### SP-038 - WEBUTIL.INITWEBUTIL

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.INIT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Initialises the WebUtil framework within an Oracle Form by registering the implementation class names for all known WebUtil packages, verifying that the required WebUtil object group (including its error alert and dummy item) is present in the form, optionally navigating to the dummy bean item to force bean instantiation, and determining the server-side file-path separator based on the host operating system. This procedure must complete successfully before any WebUtil functionality can be used.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-036](#SP-036--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SHOWBEANS ([SP-053](#SP-053--WEBUTIL.SHOWBEANS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Capture the current cursor field (SYSTEM.CURSOR_FIELD) and locate the WebUtil dummy item (WEBUTIL_DUMMY_ITEM) for later use in navigation.
- Step 2 - Populate the package implementation-class registry (m_implClasses) by assigning a Java class name to each of the ten known WebUtil package constants (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL). WUU_PACKAGE is registered with an empty string, indicating no backing class.
- Step 3 - Check whether the WebUtil error alert object (m_errorAlert) is null using ID_NULL. If it is null, the WebUtil object group is absent from the form; display an error message and pause execution, preventing further initialisation.
- Step 4 - If the error alert is present and the explicit-instantiation flag (FLAG_EXPICIT_INSTANCIATE) is enabled and the form is in NORMAL mode (not Enter-Query mode), proceed with bean instantiation navigation.
- Step 5 - Within the instantiation block, verify that the dummy item (hDummy) is not null using ID_NULL, confirming the standard WebUtil object group is in use.
- Step 6 - Navigate to the dummy item via GO_ITEM to trigger bean area rendering.
- Step 7 - Compare the block of the original cursor position with the block of the dummy item. If they are the same block, call NEXT_BLOCK to move focus away; otherwise navigate back to the original cursor item via GO_ITEM.
- Step 8 - Call SHOWBEANS(false) to render the bean areas without forcing visibility.
- Step 9 - If the dummy item is null (programmer is managing bean setup independently), take no action.
- Step 10 - Determine the server operating system by inspecting GET_APPLICATION_PROPERTY(OPERATING_SYSTEM). If the OS name contains 'WIN' (case-insensitive), set the server file-path separator (m_serverFileSep) to backslash; otherwise set it to forward slash.

---
**Decision Points**

DP-001

Condition: ID_NULL(m_errorAlert) is TRUE - the WebUtil error alert object is not present in the form.

TRUE: Display the message 'The WEBUTIL object group is not available in this Form. WebUtil cannot work', pause execution, and abort all further initialisation steps.

FALSE: The WebUtil object group is available; continue with bean instantiation and OS detection.

---

DP-002

Condition: FLAG_EXPICIT_INSTANCIATE is TRUE AND SYSTEM.MODE equals 'NORMAL'.

TRUE: Attempt explicit bean instantiation by navigating to the dummy item and calling SHOWBEANS.

FALSE: Skip the explicit instantiation block entirely (guards against Enter-Query mode side-effects or when the flag is disabled).

---

DP-003

Condition: ID_NULL(hDummy) is FALSE - the standard WebUtil dummy item exists in the form.

TRUE: Navigate to the dummy item, determine whether a block change is needed, and call SHOWBEANS(false) to render bean areas.

FALSE: The programmer is managing bean setup independently; no navigation or SHOWBEANS call is made.

---

DP-004

Condition: After navigating to the dummy item, GET_ITEM_PROPERTY(startPoint, BLOCK_NAME) equals GET_ITEM_PROPERTY(hDummy, BLOCK_NAME) - the original cursor was in the same block as the dummy item.

TRUE: Call NEXT_BLOCK to move focus out of the dummy item's block.

FALSE: Call GO_ITEM(startPoint) to return focus directly to the original cursor item.

---

DP-005

Condition: INSTR(UPPER(GET_APPLICATION_PROPERTY(OPERATING_SYSTEM)), 'WIN') > 0 - the server operating system name contains 'WIN'.

TRUE: Set m_serverFileSep to '\' (Windows backslash separator).

FALSE: Set m_serverFileSep to '/' (Unix/Linux forward slash separator).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The WebUtil object group, including its error alert (m_errorAlert), must be present in the host form before WebUtil can initialise; absence of the error alert is treated as a fatal configuration error and halts initialisation with a user-facing message.
- BR-002 - Explicit bean instantiation via navigation is suppressed when the form is in Enter-Query mode (SYSTEM.MODE ≠ 'NORMAL') to prevent navigation side-effects, regardless of the FLAG_EXPICIT_INSTANCIATE setting.
- BR-003 - Explicit bean instantiation is additionally controlled by the FLAG_EXPICIT_INSTANCIATE flag, allowing the navigation-and-render sequence to be bypassed entirely as a workaround without code changes.
- BR-004 - If the dummy item is absent (ID_NULL returns TRUE for hDummy), the procedure assumes the developer is managing bean area setup independently and performs no navigation or rendering actions.
- BR-005 - After navigating to the dummy item, focus must be returned to a valid location: NEXT_BLOCK is used when the original cursor was in the same block as the dummy item; GO_ITEM to the original cursor item is used otherwise, ensuring the user's context is preserved.
- BR-006 - SHOWBEANS must be called with the parameter false during initialisation, indicating that bean visibility is not to be forced at this stage.
- BR-007 - The server file-path separator (m_serverFileSep) is set once at initialisation based on the server OS and must reflect '\' for Windows environments and '/' for all other environments, ensuring correct path construction throughout the WebUtil session.
- BR-008 - The WUU_PACKAGE entry in the implementation-class registry is intentionally registered with an empty string, indicating that this package has no associated Java backing class.

---
**Implementation Logic**

```plsql
  
  PROCEDURE InitWebUtil is
    startPoint VARCHAR2(61 char) := NAME_IN('SYSTEM.CURSOR_FIELD');
    hDummy     ITEM              := FIND_ITEM(WEBUTIL_DUMMY_ITEM);
  BEGIN
    -- Set up the various package we know about.
    m_implClasses(WUC_PACKAGE) := 'common.VBeanCommon'; 
    m_implClasses(WUT_PACKAGE) := 'fileTransfer.FileTransfer'; 
    m_implClasses(WUF_PACKAGE) := 'file.FileFunctions'; 
    m_implClasses(WUI_PACKAGE) := 'clientInfo.GetClientInfo'; 
    m_implClasses(WUH_PACKAGE) := 'host.Host'; 
    m_implClasses(WUS_PACKAGE) := 'session.SessionFunctions'; 
    m_implClasses(WUB_PACKAGE) := 'browser.BrowserFunctions'; 
    m_implClasses(WUO_PACKAGE) := 'ole.OleFunctions'; 
    m_implClasses(WUU_PACKAGE) := '';      
    m_implClasses(WUL_PACKAGE) := 'cApi.CApiFunctions';                     
    
    -- Now check for the Webutil Object group which 
    -- contains the Beans etc.
          
    if id_null(m_errorAlert) then 
      -- The Webutil error alert is not around
      -- so the Code cannot operate 
      message('The WEBUTIL object group is not available in this Form.  WebUtil cannot work');
      pause;
    else
      -- Bug 2955789 - this navigation causes problems if they are in Enter-Query mode 
      -- Plus it's not really needed, except as a belt and braces kind of setup.
      -- So put a check to prevent this in E-Q mode and set a top level flag to bypass it 
      -- it all together which we can switch on or off if required as a furture W/A    
      if FLAG_EXPICIT_INSTANCIATE and name_in('SYSTEM.MODE') = 'NORMAL' then 
        if not ID_NULL(hDummy) then 
          -- they are using the standard Object Group
          GO_ITEM(hDummy);
          if GET_ITEM_PROPERTY(startPoint,BLOCK_NAME) = GET_ITEM_PROPERTY(hDummy,BLOCK_NAME) then 
            NEXT_BLOCK;
          else
            GO_ITEM(startPoint);
          end if;
          ShowBeans(false);        
        else
          -- do nothing assume that the programmer is doing their own thing.
          -- with regards to setting up the bean areas and making sure they are drawn
           null;      
        end if;
      end if;
    end if;
        
    -- Work out the server o/s informtion that we need
    if instr(upper(GET_APPLICATION_PROPERTY(OPERATING_SYSTEM)),'WIN') > 0 then 
      m_serverFileSep := '\';
    else
      m_serverFileSep := '/';
    end if;
  END InitWebUtil;
```

#### SP-039 - WEBUTIL.ISERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a Boolean indicator of whether the most recent WebUtil operation resulted in an error. It evaluates the internal error-state variable `m_lastError` and returns TRUE if a non-zero error code is held, allowing callers such as WEBUTIL.LOG to branch their processing based on the current error status.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Read the value of the package-level variable `m_lastError`, which holds the error code set by the most recent WebUtil operation.
- Step 2 - Compare `m_lastError` against zero to determine whether an error condition is active.
- Step 3 - Return the Boolean result of the comparison to the caller (TRUE if an error exists; FALSE if no error exists).

---
**Decision Points**

DP-001

Condition: `m_lastError <> 0`

TRUE: The function returns TRUE, signalling to the caller that the last WebUtil operation produced an error.

FALSE: The function returns FALSE, signalling to the caller that no error is currently recorded.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function is read-only; it inspects `m_lastError` without modifying it, ensuring that calling ISERROR does not alter the error state.
- BR-002 - A `m_lastError` value of zero is the sole representation of a non-error state; any other value, positive or negative, is treated as an error condition.
- BR-003 - The function accepts no input parameters; its result is derived exclusively from the current value of the package-level variable `m_lastError` at the time of invocation.

---
**Implementation Logic**

```plsql
  FUNCTION isError   return BOOLEAN is
  begin 
    return m_lastError <> 0;
  end;
```

#### SP-040 - WEBUTIL.IS_OPEN

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines whether a file handle is currently open by inspecting the handle attribute of the supplied FILE_TYPE record. Returns TRUE if the file is open and FALSE if it is not, allowing callers such as WEBUTIL.LOG to verify file state before attempting file operations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FILE_TYPE record passed by the caller as the input parameter.
- Step 2 - Evaluate the HANDLE attribute of the FILE_TYPE record to determine whether it holds a non-NULL value.
- Step 3 - If the HANDLE attribute is NULL, return FALSE to indicate the file is not open.
- Step 4 - If the HANDLE attribute is not NULL, return TRUE to indicate the file is open.

---
**Decision Points**

DP-001

Condition: file.handle IS NULL

TRUE: The function returns FALSE, signalling that the file is not currently open.

FALSE: The function returns TRUE, signalling that the file is currently open.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A FILE_TYPE record is considered closed if its HANDLE attribute is NULL; no other attribute is evaluated.
- BR-002 - A FILE_TYPE record is considered open if and only if its HANDLE attribute is non-NULL.
- BR-003 - The function is read-only; it does not modify the FILE_TYPE record or any other state.

---
**Implementation Logic**

```plsql
  
  FUNCTION is_open(file file_type) RETURN BOOLEAN IS
  BEGIN
    IF file.handle IS NULL THEN
      RETURN(FALSE);
    ELSE
      RETURN(TRUE);
    END IF;
  END is_open;
```

#### SP-041 - WEBUTIL.LENGTH

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: STRIPDIRSEP]
- webutil.pld [StoredProcedure: WEBUTIL.GETSTRING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the byte length of the file represented by the supplied Java File object. It delegates directly to the native Java method java.io.File.length() via the JNI bridge, providing Oracle Forms PL/SQL routines with a reliable, platform-independent way to determine file size without database interaction.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java File object (obj) that represents the target file whose size is to be determined.
- Step 2 - Clear the JNI argument list by setting args to NULL, ensuring no stale parameters are passed to the Java method.
- Step 3 - Invoke the Java instance method java.io.File.length() on the supplied object via JNI.CALL_LONG_METHOD, passing FALSE (non-static call), the object reference, the class path 'java/io/File', the method name 'length', and the descriptor '()J' (no arguments, returns a long integer).
- Step 4 - Return the numeric result (file size in bytes) obtained from the JNI call to the calling routine.

---
**Decision Points**

No conditional decision points exist in this function. Execution follows a single, unconditional path: clear arguments, invoke the JNI method, and return the result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must receive a valid ORA_JAVA.JOBJECT reference representing a java.io.File instance; the correctness of the returned size is entirely dependent on the validity of the supplied object.
- BR-002 - The JNI argument list (args) must be reset to NULL before each call to java.io.File.length() to prevent unintended parameter carry-over from prior JNI operations.
- BR-003 - File size is returned as a NUMBER representing bytes, consistent with the Java long return type ('()J') of java.io.File.length(); callers are responsible for interpreting and handling the returned value appropriately.
- BR-004 - This function performs no database interaction; all file-system interrogation is performed entirely through the JNI bridge to the underlying Java runtime.

---
**Implementation Logic**

```plsql
  FUNCTION length(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_LONG_METHOD(FALSE, obj, 'java/io/File', 'length', '()J', args); 
  END;
```

#### SP-042 - WEBUTIL.LOG

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]
- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a diagnostic or error message to a server-side log file, subject to configuration settings read from a property bundle. On first invocation the procedure initialises a module-level logging cache (enabled flag, errors-only flag, and target file path) and communicates the resulting logging mode to the WebUtil client bean. Subsequent calls use the cached settings to decide whether to append the supplied message to the log file, optionally prefixing it with the client IP address and username.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| msg | VARCHAR2 | IN |
| isError | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-018](#SP-018--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ISERROR ([SP-039](#SP-039--WEBUTIL.ISERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.IS_OPEN ([SP-040](#SP-040--WEBUTIL.IS_OPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-045](#SP-045--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Check whether the module-level logging cache has been initialised (m_loggingAllowed IS NULL). If not yet initialised, proceed to Steps 2-7; otherwise skip to Step 8.
- Step 2 - Read the three logging configuration properties from the property bundle via WEBUTIL.READFROMPROPERTYBUNDLE: 'logging.enabled' (sets m_loggingAllowed), 'logging.errorsonly' (sets m_loggingErrorsOnly), and 'logging.file' (sets m_loggingFile).
- Step 3 - If logging is enabled but no log file path was returned, disable logging (m_loggingAllowed := FALSE) and report error WUC-008. If no WebUtil bean is registered yet, raise the error via WEBUTIL.ERRORALERT using a plain-English alert; otherwise communicate the disabled state to the client bean by setting property WUC_SRV_LOGGING to '0' and raising the structured error through WebUtil_Core.
- Step 4 - If at least one bean is registered, synchronise the logging mode with the client bean: set WUC_SRV_LOGGING to '1' (errors-only logging), '2' (full logging), or '0' (logging disabled) via WebUtil_Core.setProperty, reflecting the resolved values of m_loggingAllowed and m_loggingErrorsOnly.
- Step 5 - After cache initialisation, evaluate whether logging is permitted (m_loggingAllowed = TRUE).
- Step 6 - If logging is permitted, evaluate whether the current message should be written: write unconditionally when errors-only mode is off, or write only when isError = TRUE when errors-only mode is on.
- Step 7 - Open the log file in append mode (TEXT_IO.FOPEN with mode 'A'). If the file cannot be opened, raise NO_DATA_FOUND to trigger the exception handler.
- Step 8 - Write the log entry. If m_clientIP is populated, prefix the message with the client IP address and username (format: '<IP>:<username>: <msg>'); otherwise write the message as supplied.
- Step 9 - Close the log file via TEXT_IO.FCLOSE.
- Step 10 - On any exception: if SQLCODE = -302000 (file write failure), report error WUC-007 (via WEBUTIL.ERRORALERT if no bean is registered, or via WebUtil_Core otherwise), set WUC_SRV_LOGGING to '0', and permanently disable logging (m_loggingAllowed := FALSE). All other exceptions are re-raised.

---
**Decision Points**

DP-001

Condition: m_loggingAllowed IS NULL (logging cache not yet initialised).

TRUE: Read configuration from the property bundle via WEBUTIL.READFROMPROPERTYBUNDLE and populate the module-level cache variables before attempting to log.

FALSE: Skip cache initialisation and proceed directly to the logging evaluation using the already-cached values.

---

DP-002

Condition: Logging is enabled (m_loggingAllowed = TRUE) but m_loggingFile IS NULL.

TRUE: Disable logging, raise error WUC-008 (via WEBUTIL.ERRORALERT if no bean is registered, or via WebUtil_Core if a bean is available), and set WUC_SRV_LOGGING to '0'.

FALSE: Retain the enabled state and continue with bean synchronisation.

---

DP-003

Condition: At least one WebUtil bean is registered (m_registeredPackages.FIRST IS NOT NULL) at the point of bean synchronisation.

TRUE: Communicate the resolved logging mode to the client bean by calling WebUtil_Core.setProperty with the appropriate WUC_SRV_LOGGING value ('0', '1', or '2').

FALSE: Skip client bean synchronisation; no bean is available to receive the property.

---

DP-004

Condition: m_loggingAllowed = TRUE at the point of writing.

TRUE: Evaluate the errors-only filter (DP-005) and proceed to write the log entry.

FALSE: Suppress the log entry entirely; no file I/O is performed.

---

DP-005

Condition: m_loggingErrorsOnly = FALSE, OR (m_loggingErrorsOnly = TRUE AND isError = TRUE).

TRUE: Open the log file and write the message.

FALSE: Suppress the log entry; the message does not meet the errors-only threshold.

---

DP-006

Condition: m_clientIP IS NULL when composing the log line.

TRUE: Write the message without a prefix.

FALSE: Prefix the message with the client IP address and username in the format '<IP>:<username>: <msg>'.

---

DP-007

Condition: An exception occurs and SQLCODE = -302000 (file write failure).

TRUE: Report error WUC-007 (via WEBUTIL.ERRORALERT if no bean is registered, otherwise via WebUtil_Core), set WUC_SRV_LOGGING to '0', and permanently disable logging.

FALSE: Re-raise the exception to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Logging is only performed when the 'logging.enabled' property in the property bundle resolves to the string 'true' (case-insensitive); any other value disables logging.
- BR-002 - A log file path ('logging.file') is mandatory when logging is enabled; if the path is absent, logging is unconditionally disabled and error WUC-008 is raised.
- BR-003 - When errors-only mode is active ('logging.errorsonly' = 'true'), only calls where isError = TRUE produce a log entry; informational messages are silently suppressed.
- BR-004 - The logging configuration is read from the property bundle exactly once per session; the resolved values are cached in module-level variables and reused for all subsequent calls, preventing repeated property-bundle lookups.
- BR-005 - The client bean is informed of the active logging mode via the WUC_SRV_LOGGING property: '0' = disabled, '1' = errors only, '2' = full logging. This synchronisation occurs only when at least one bean is registered.
- BR-006 - If no bean is registered at the time an error must be reported (WUC-007 or WUC-008), the error is surfaced to the end user through WEBUTIL.ERRORALERT using a plain-English message; structured WebUtil_Core error handling is used only when a bean is available.
- BR-007 - Each log entry is appended to the log file (open in 'A' mode) and the file is closed immediately after writing, ensuring no file handle is left open between log calls.
- BR-008 - When a client IP address is available (m_clientIP IS NOT NULL), every log entry is prefixed with the client IP address and username to provide audit traceability.
- BR-009 - A file write failure (SQLCODE -302000) permanently disables logging for the remainder of the session (m_loggingAllowed := FALSE) and notifies the appropriate error channel; this prevents repeated failed write attempts.

---
**Implementation Logic**

```plsql
  

  PROCEDURE Log(msg in VARCHAR2, isError BOOLEAN) is
    logFile       TEXT_IO.FILE_TYPE;
    logFileName   VARCHAR2(1024 char);
    errorOnlyMode BOOLEAN;
  begin
    -- check to see if we should do anything
    if m_loggingAllowed is null then 
      -- set up the logging info Cache
      m_loggingAllowed    := (lower(ReadFromPropertyBundle('logging.enabled')) = 'true');
      m_loggingErrorsOnly := (lower(ReadFromPropertyBundle('logging.errorsonly')) = 'true');
      m_loggingFile       := ReadFromPropertyBundle('logging.file');
      if m_loggingAllowed then 
        if m_loggingFile is null then 
          -- no file == no logging
          m_loggingAllowed := false;
          if m_registeredPackages.FIRST is null then
            -- There is no bean registered yet. Throw error in English using alert
            ErrorAlert('WUC-008: Server side logging was requested but no log file was specified'
                       ||' - logging is disabled');
          else
            WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
            WebUtil_Core.error(WUC_PACKAGE,8,'WebUtil_Core.Log');
          end if;
        end if;
      end if;
      if m_registeredPackages.FIRST is not null then
        -- At least one bean is registered. Can call setProperty(WUC_PACKAGE)
        if m_loggingAllowed and m_loggingErrorsOnly then
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','1',true);
        elsif  m_loggingAllowed then
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','2',true);
        else
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
        end if;
      end if;
    end if;
        
    -- now log if allowed to do so
    if m_loggingAllowed then
      if ((not m_loggingErrorsOnly) or (m_loggingErrorsOnly and isError)) then
        logFile := TEXT_IO.FOPEN(m_loggingFile,'A');
        if not TEXT_IO.IS_OPEN(logFile) then 
          raise NO_DATA_FOUND;
        end if;
        if m_clientIP is null then
        	TEXT_IO.PUT_LINE(logFile,msg);
        else
        	TEXT_IO.PUT_LINE(logFile,m_clientIP||':'||m_clientUserName||': '||msg);
        end if;
        TEXT_IO.FCLOSE(logFile);
      end if;    
    end if;
  EXCEPTION
    when others then 
      if SQLCODE = '-302000' then
        if m_registeredPackages.FIRST is null then
          -- There is no bean registered yet. Throw error in English using alert
          ErrorAlert('WUC-007: Unable to write to WebUtil Logging File '|| m_loggingFile);
        else

          WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
          WebUtil_Core.error(WebUtil_Core.WUC_PACKAGE,7,'WebUtil_Core.Log',m_loggingFile);
        end if;
        m_loggingAllowed := false;
      else
        RAISE;
      end if;      
  end Log;
```

#### SP-043 - WEBUTIL.POPULATEPROPERTYBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.READFROMPROPERTYBUNDLE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Locates and reads the WebUtil configuration file, parses its key-value property pairs into the in-memory property bundle (m_propertyBundle), and returns the value associated with the requested property key. The procedure resolves the configuration file path from three fallback sources - a Forms global variable, an environment variable, and a Forms parameter - ensuring that downstream callers such as WEBUTIL.READFROMPROPERTYBUNDLE can retrieve runtime configuration values without direct file-system coupling.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-018](#SP-018--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Read the configuration file path from the Forms global variable identified by WEBUTIL_CONFIG_GLOBAL; if the global holds the sentinel value '[NOTSET]', treat it as unset and proceed to the next fallback.
- Step 2 - If the global is unset, call TOOL_ENV.GETVAR with the environment variable name WEBUTIL_CONFIG_ENV to obtain the configuration file path.
- Step 3 - If the environment variable also yields no value, read the configuration file path from the Forms parameter identified by WEBUTIL_CONFIG_PARAM.
- Step 4 - If all three sources fail to supply a path, raise NO_DATA_FOUND to trigger the error-handling block.
- Step 5 - Persist the resolved configuration file path back into the Forms global variable WEBUTIL_CONFIG_GLOBAL via COPY, so subsequent calls avoid redundant lookups.
- Step 6 - Open the configuration file for reading using TEXT_IO.FOPEN.
- Step 7 - Read the file line by line in a loop using TEXT_IO.GET_LINE; exit the loop when NO_DATA_FOUND is raised (end of file).
- Step 8 - For each line, skip it if its first character is '#' (comment line).
- Step 9 - For non-comment lines, locate the '=' delimiter using INSTR; skip lines that contain no '=' character.
- Step 10 - For valid key-value lines, increment the property index, store the trimmed, lowercased key and the trimmed, carriage-return-stripped value into the next slot of m_propertyBundle.
- Step 11 - Compare the stored key (lowercased) against the lowercased input propertyKey; if they match, capture the corresponding value into the result variable.
- Step 12 - After the loop completes, close the configuration file using TEXT_IO.FCLOSE.
- Step 13 - Return the result value (NULL if the key was not found in the file).
- Step 14 - On NO_DATA_FOUND exception: if no bean package is registered (m_registeredPackages.FIRST is null), invoke WEBUTIL.ERRORALERT with message 'WUC-005: No WebUtil Configuration File specified'; otherwise delegate to Webutil_Core.Error. Set m_config_error to TRUE and return NULL.
- Step 15 - On SQLCODE -302000 (file I/O error): if no bean package is registered, invoke WEBUTIL.ERRORALERT with message 'WUC-006: Unable to read WebUtil Configuration File'; otherwise delegate to Webutil_Core.Error. Set m_config_error to TRUE and return NULL. All other exceptions are re-raised.

---
**Decision Points**

DP-001
Condition: The Forms global variable WEBUTIL_CONFIG_GLOBAL contains the sentinel value '[NOTSET]'.
TRUE: Clear the local configFile variable and attempt to resolve the path from the environment variable WEBUTIL_CONFIG_ENV (proceed to DP-002).
FALSE: Use the value held in WEBUTIL_CONFIG_GLOBAL as the configuration file path and skip further fallback resolution.

DP-002
Condition: TOOL_ENV.GETVAR returns a non-null value for WEBUTIL_CONFIG_ENV.
TRUE: Use the environment variable value as the configuration file path.
FALSE: Attempt to read the configuration file path from the Forms parameter WEBUTIL_CONFIG_PARAM (proceed to DP-003).

DP-003
Condition: The Forms parameter WEBUTIL_CONFIG_PARAM yields a non-null value.
TRUE: Use the parameter value as the configuration file path.
FALSE: Raise NO_DATA_FOUND; no configuration file path is available.

DP-004
Condition: The first character of the current file line is '#'.
TRUE: Skip the line entirely (comment line); continue to the next iteration.
FALSE: Proceed to parse the line for a key-value pair.

DP-005
Condition: The current line contains an '=' character (INSTR result > 0).
TRUE: Parse the line into a key-value pair, store it in m_propertyBundle, and check whether the key matches the requested propertyKey.
FALSE: Skip the line; it does not represent a valid property entry.

DP-006
Condition: The lowercased parsed key equals the lowercased input propertyKey.
TRUE: Assign the parsed value to the result variable for return.
FALSE: Continue processing remaining lines without updating the result variable.

DP-007
Condition: (Within NO_DATA_FOUND or SQLCODE -302000 exception handler) m_registeredPackages.FIRST is null (no bean package registered).
TRUE: Call WEBUTIL.ERRORALERT to display the error message in English directly via an alert.
FALSE: Delegate error reporting to Webutil_Core.Error.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The configuration file path must be resolvable from at least one of three ordered sources: the Forms global variable WEBUTIL_CONFIG_GLOBAL, the environment variable WEBUTIL_CONFIG_ENV, or the Forms parameter WEBUTIL_CONFIG_PARAM. If none supplies a value, the procedure treats it as a fatal configuration error.
- BR-002 - Once the configuration file path is successfully resolved, it is written back to WEBUTIL_CONFIG_GLOBAL so that the resolved path is cached for subsequent invocations within the same Forms session.
- BR-003 - Lines beginning with the '#' character are treated as comments and must be excluded from property parsing.
- BR-004 - Only lines containing an '=' character are treated as valid property entries; lines without '=' are silently ignored.
- BR-005 - Property keys are stored and matched in a case-insensitive manner (lowercased); leading and trailing whitespace is stripped from both keys and values.
- BR-006 - Carriage-return characters (CHR(13)) are stripped from property values to ensure cross-platform compatibility of the configuration file.
- BR-007 - When no configuration file path is available (NO_DATA_FOUND), the procedure sets the module-level error flag m_config_error to TRUE and returns NULL, preventing further processing from using an uninitialised property bundle.
- BR-008 - When the configuration file cannot be read (SQLCODE -302000), the procedure sets m_config_error to TRUE and returns NULL; all other unexpected exceptions are re-raised to the caller.
- BR-009 - Error messages are surfaced via WEBUTIL.ERRORALERT only when no bean package is registered; if a bean package is registered, error reporting is delegated to the Webutil_Core framework.

---
**Implementation Logic**

```plsql
      
  FUNCTION PopulatePropertyBundle(propertyKey in VARCHAR2) return VARCHAR2 is
    configFile   VARCHAR2(512 char);
    buffer       VARCHAR2(1000 char);
    result       VARCHAR2(1000 char);          
    propertyFile TEXT_IO.FILE_TYPE;
    pos          PLS_INTEGER;
    propIndex    PLS_INTEGER := 0;
  begin
    -- First of get the name of the cfg file 
    -- This could come in a global  or from the Environment
    default_value('[NOTSET]',WEBUTIL_CONFIG_GLOBAL);
    configFile := name_in(WEBUTIL_CONFIG_GLOBAL);
    if configFile = '[NOTSET]' then
      configFile := null; 
      -- Try the environment
      TOOL_ENV.GETVAR(WEBUTIL_CONFIG_ENV, configFile); 
      if configFile is null then 
        -- Finally try the Forms parameters
        configFile := name_in(WEBUTIL_CONFIG_PARAM);
        -- if that fails then we have to raise an error
        if configFile is null then 
          raise NO_DATA_FOUND;
        end if;    
      end if;
    end if;
    
    copy(configFile, WEBUTIL_CONFIG_GLOBAL);
      
    propertyFile := Text_IO.FOpen(configFile,'R');
    LOOP
      begin
        Text_IO.Get_Line(propertyFile,buffer);
      exception
        when NO_DATA_FOUND then EXIT;
      end;
        
      -- ignore lines which start with '#'
      if substr(buffer,1,1) <> '#' then 
        pos := instr(buffer,'=');
        -- only process lines with a name value pair
        if pos > 0 then 
          propIndex := propIndex + 1;
          m_propertyBundle(propIndex).propertyKey   := lower(ltrim(rtrim(substr(buffer,1,pos-1))));    
          m_propertyBundle(propIndex).propertyValue := ltrim(rtrim(replace(substr(buffer,pos+1),chr(13),'')));
          -- Check to see if this is the key we are looking for
          if  m_propertyBundle(propIndex).propertyKey = lower(propertyKey) then
            result := m_propertyBundle(propIndex).propertyValue;
          end if;
        end if;
      end if;
    end LOOP;
    Text_IO.FClose(propertyFile);
    return result;
  EXCEPTION
    when NO_DATA_FOUND then 
      if m_registeredPackages.FIRST is null then
        -- There is no bean registered yet. Throw error in English using alert
        ErrorAlert('WUC-005: No WebUtil Configuration File specified');
      else
        Webutil_Core.Error(Webutil_Core.WUC_PACKAGE,5,'WebUtil_Core.PopulatePropertyBundle');
      end if;
      m_config_error := true;
      return null;
    when others then 
      if SQLCODE = '-302000' then
        if m_registeredPackages.FIRST is null then
          -- There is no bean registered yet. Throw error in English using alert
          ErrorAlert('WUC-006: Unable to read WebUtil Configuration File');
        else
          Webutil_Core.Error(Webutil_Core.WUC_PACKAGE,6,'WebUtil_Core.PopulatePropertyBundle', configFile);
        end if;
        m_config_error := true;
        return null;
      else
        RAISE;
      end if;      

  end PopulatePropertyBundle;
```

#### SP-044 - WEBUTIL.PUT_LINE

**Invoked From:**

- vr_cross_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a single line of text to an open client-side file by transmitting the file handle, the text content, and a newline instruction to the WebUtil core bean. This procedure is the client-text-IO equivalent of a server-side PUT_LINE, enabling Oracle Forms to append a terminated line of data to a file residing on the client machine.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |
| item | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the target file handle (file.handle extracted from the file_type parameter) and the text string (item) to be written.
- Step 2 - Set the WUF_TEXTIO_HANDLE property on the WUF_PACKAGE bean via WebUtil_Core.setProperty, associating the operation with the correct open file.
- Step 3 - Set the WUF_TEXTIO_PUT property on the WUF_PACKAGE bean via WebUtil_Core.setProperty, passing the text content (item) to be written.
- Step 4 - Set the WUF_TEXTIO_NEWLINE property on the WUF_PACKAGE bean to 1 via WebUtil_Core.setProperty, instructing the bean to append a newline character after the text, completing the line.
- Step 5 - If the WebUtil bean is not registered on the client (BEAN_NOT_REGISTERED exception), display an error alert identifying the missing implementation class and raise TOOL_ERR.TOOL_ERROR to halt processing.
- Step 6 - If any property-setting operation fails (PROPERTY_ERROR exception), raise TOOL_ERR.TOOL_ERROR to halt processing.

---
**Decision Points**

DP-001

Condition:
The WebUtil WUF_PACKAGE bean is registered and available on the client at the time any setProperty call is executed.

TRUE:
All three properties (WUF_TEXTIO_HANDLE, WUF_TEXTIO_PUT, WUF_TEXTIO_NEWLINE) are set successfully and the line is written to the client file without error.

FALSE:
A BEAN_NOT_REGISTERED exception is raised; an error alert is displayed identifying the missing bean class, and TOOL_ERR.TOOL_ERROR is raised to abort the calling process.

---

DP-002

Condition:
A setProperty call completes without raising a PROPERTY_ERROR exception.

TRUE:
The individual property is accepted by the bean and processing continues to the next setProperty call.

FALSE:
A PROPERTY_ERROR exception is raised and TOOL_ERR.TOOL_ERROR is propagated to the caller, aborting the write operation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The WebUtil WUF_PACKAGE bean must be registered and active on the client before PUT_LINE is called; absence of the bean is a fatal condition that prevents any client-side text-IO operation.
- BR-002 - A newline is always appended after the text item (WUF_TEXTIO_NEWLINE set to 1); partial-line writes without a newline are not supported by this procedure.
- BR-003 - The file handle passed in the file parameter must correspond to a previously opened client file; the procedure does not validate or open files itself.
- BR-004 - Any bean registration or property error is treated as a fatal, non-recoverable condition; the procedure raises TOOL_ERR.TOOL_ERROR and does not attempt retries or silent fallback.

---
**Implementation Logic**

```plsql
    

  PROCEDURE put_line (file file_type, item VARCHAR2) is
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);              
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_PUT',item); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_NEWLINE',1); 
  EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.put_line will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;  
  END put_line;
```

#### SP-045 - WEBUTIL.READFROMPROPERTYBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.LOG]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value associated with a given property key from an in-memory property bundle collection. If the bundle has not yet been loaded, it delegates population to WEBUTIL.POPULATEPROPERTYBUNDLE before performing the lookup. This function supports configuration-driven behaviour for callers such as WEBUTIL.CHECKLIBS, WEBUTIL.LOG, and WEBUTIL.REGISTERBEAN by providing a centralised, reusable mechanism for reading WebUtil configuration properties at runtime.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.POPULATEPROPERTYBUNDLE ([SP-043](#SP-043--WEBUTIL.POPULATEPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input property key (propertyKey) and capture the current count of entries in the in-memory property bundle collection (m_propertyBundle).
- Step 2 - Check whether a configuration error flag (m_config_error) has previously been raised. If it has, immediately return NULL, bypassing all further processing.
- Step 3 - If no configuration error exists and the property bundle collection is empty (count = 0), invoke WEBUTIL.POPULATEPROPERTYBUNDLE passing the requested propertyKey to load the bundle and obtain the result directly from that call.
- Step 4 - If the property bundle collection is already populated, iterate through each entry in the collection and compare the stored property key (converted to lower case) against the lower-case form of the supplied propertyKey.
- Step 5 - On the first matching entry, capture the corresponding propertyValue into the result variable and exit the loop immediately.
- Step 6 - Return the resolved property value, or NULL if no match was found or a configuration error was present.

---
**Decision Points**

DP-001

Condition: m_config_error flag is TRUE.

TRUE: Return NULL immediately; no further processing is performed.

FALSE: Continue to evaluate the state of the property bundle collection.

---

DP-002

Condition: The property bundle collection (m_propertyBundle) contains zero entries (COUNT = 0).

TRUE: Invoke WEBUTIL.POPULATEPROPERTYBUNDLE with the supplied propertyKey to load the bundle and obtain the property value; return that result.

FALSE: The bundle is already loaded; proceed to iterate through existing entries to locate the matching key.

---

DP-003

Condition: During iteration, the current entry's stored propertyKey (lower-cased) matches the lower-cased value of the input propertyKey.

TRUE: Assign the entry's propertyValue to the result variable and exit the loop.

FALSE: Continue iterating to the next entry; if the loop completes without a match, result remains NULL.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - If a configuration error has previously been detected (m_config_error = TRUE), the function must return NULL without attempting any property lookup or bundle population.
- BR-002 - Property key comparisons are case-insensitive; both the stored key and the input key are normalised to lower case before matching to ensure consistent resolution regardless of the case supplied by the caller.
- BR-003 - The property bundle is populated on demand: WEBUTIL.POPULATEPROPERTYBUNDLE is called only when the collection is empty, preventing redundant re-loading on subsequent calls.
- BR-004 - The function returns only the first matching property value found in the collection and exits the search immediately, enforcing uniqueness of key resolution within the bundle.
- BR-005 - The maximum length of a returned property value is 1 000 characters (VARCHAR2(1000 char)); values exceeding this length cannot be stored or returned by this function.

---
**Implementation Logic**

```plsql
  
  FUNCTION ReadFromPropertyBundle(propertyKey in VARCHAR2) return VARCHAR2 is   
    result       VARCHAR2(1000 char);
    propCount    PLS_INTEGER := m_propertyBundle.COUNT;
  begin
    if m_config_error then
      -- already encountered problem reading the config file.
      return null;
    elsif (propCount = 0) then
      result := populatePropertyBundle(propertyKey);
    else
      for i in 1..propCount LOOP
        if m_propertyBundle(i).propertyKey = lower(propertyKey) then 
          result := m_propertyBundle(i).propertyValue;
          EXIT;
        end if;
      end LOOP;
    end if;
    return result;
  end ReadFromPropertyBundle;
```

#### SP-046 - WEBUTIL.READTRANSFROMMSGBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a translated message string from the WebUtil message bundle by combining a property key and optional arguments, then returning the resolved translation. The function is used to obtain localised UI text - currently limited to fetching the progress bar title during library validation in WEBUTIL.CHECKLIBS.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |
| args | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the mandatory propertyKey (message bundle key) and the optional args (substitution arguments) input parameters.
- Step 2 - Concatenate propertyKey and args with a pipe delimiter ('|') to form a composite lookup value.
- Step 3 - Write the composite lookup value to the WebUtil Core package property store by calling Webutil_Core.setProperty, targeting the WUC_PACKAGE package identifier and the WUC_TRANS_MSG property name.
- Step 4 - Immediately read back the resolved translation string from the same property store by calling Webutil_Core.getProperty with the same WUC_PACKAGE and WUC_TRANS_MSG identifiers.
- Step 5 - Return the retrieved translated string to the caller.

---
**Decision Points**

No decision points are present in the implementation logic. The function executes a linear set/get sequence without conditional branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The propertyKey parameter is mandatory; it identifies the specific message bundle entry to be retrieved.
- BR-002 - The args parameter is optional (defaults to NULL); when supplied, it is appended to the property key using a pipe ('|') delimiter before the lookup is performed.
- BR-003 - The translation lookup is performed exclusively through Webutil_Core.setProperty and Webutil_Core.getProperty using the fixed identifiers WUC_PACKAGE and WUC_TRANS_MSG; no direct database access is performed.
- BR-004 - The function is currently invoked only from WEBUTIL.CHECKLIBS and is scoped to retrieving the progress bar title during library validation; use outside this context is not supported by the current implementation.

---
**Implementation Logic**

```plsql
  
  FUNCTION ReadTransFromMsgBundle(propertyKey in VARCHAR2, args in VARCHAR2 := null) return VARCHAR2 is
    -- currently called from checkLibs only for getting progress bar title.
  begin 
    Webutil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_TRANS_MSG', propertyKey||'|'||args);
    return Webutil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_TRANS_MSG');
  end ReadTransFromMsgBundle;
```

#### SP-047 - WEBUTIL.REGISTERBEAN

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a WebUtil client-side bean with the Oracle Forms server-side runtime on its first contact. On the initial bean registration the procedure also captures client environment details (IP address, OS, architecture, username, locale, path and file separators), resolves the system library download directory, initialises server-side logging state, and propagates heartbeat-blocking and logging configuration back to the client bean. Subsequent bean registrations within the same form session are deduplicated so that only the first instance of each bean type is recorded.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| clientInfo | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.CHECKLIBS ([SP-012](#SP-012--WEBUTIL.CHECKLIBS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTSETTING ([SP-024](#SP-024--WEBUTIL.GETCLIENTSETTING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETOSFAMILY ([SP-029](#SP-029--WEBUTIL.GETOSFAMILY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETPROPERTY ([SP-031](#SP-031--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETVAR ([SP-033](#SP-033--WEBUTIL.GETVAR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-042](#SP-042--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-045](#SP-045--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETCLIENTSETTING ([SP-050](#SP-050--WEBUTIL.SETCLIENTSETTING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Extract the bean short name from the pipe-delimited clientInfo string (position 1) to identify which WebUtil package is being registered.
- Step 2 - Map the bean short name (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL) to the corresponding WEBUTIL_CORE package-ID constant; unrecognised names leave packageID undefined.
- Step 3 - If the client IP address (m_clientIP) has not yet been recorded, set the checkUserLibs flag to TRUE and parse the remaining clientInfo fields: client IP (position 2), OS name (position 3), OS architecture (position 4), username (position 5), path separator (position 6), file separator (position 7), and language code (position 8). Call WEBUTIL.GETOSFAMILY to derive the OS family from the OS name. If the architecture string contains '64', set the 64-bit architecture flag (m_clientOSArch = 1).
- Step 4 - If the resolved packageID does not already exist in the registered-packages array, record the current trigger item (NAME_IN('SYSTEM.TRIGGER_ITEM')) against that packageID and set the newPackage flag to TRUE; duplicate instances of the same bean type are ignored.
- Step 5 - If checkUserLibs is TRUE (first-contact processing): set REDOWNLOAD_SYSLIB to FALSE; retrieve the server host name via WEBUTIL.GETVAR using the environment variable COMPUTERNAME, falling back to HOST if COMPUTERNAME is null.
- Step 6 - Resolve the client system-library directory by calling WEBUTIL.READFROMPROPERTYBUNDLE with a key that includes the OS family and architecture; if not found, retry with the key using OS family only.
- Step 7 - If no client library directory is configured, push a WUC_SYSLIB_DIR property to the WUC bean containing only the server host and application config (client JRE will handle placement). If a directory is configured, substitute the $(SERVERHOST) placeholder with the resolved server host name, push the full WUC_SYSLIB_DIR property, then compare the new directory against the previously stored value retrieved via WEBUTIL.GETCLIENTSETTING; if they differ, persist the new value with WEBUTIL.SETCLIENTSETTING and set REDOWNLOAD_SYSLIB to TRUE.
- Step 8 - Retrieve and store the WebUtil bean version by calling WEBUTIL.GETPROPERTY for the WUC_BEAN_VERSION property.
- Step 9 - If the 'logging.connections' property bundle entry equals 'true' (case-insensitive), call WEBUTIL.LOG to write a connection record containing the form name, client OS, and locale.
- Step 10 - If the newPackage flag is TRUE, call WEBUTIL.CHECKLIBS passing the string representation of the packageID to verify and download required package-specific client libraries.
- Step 11 - If checkUserLibs is TRUE, call WEBUTIL.LOG with a null message to initialise the m_loggingAllowed and m_loggingErrorsOnly state flags.
- Step 12 - Read the 'BlockAllowHeartBeat' configuration entry via WEBUTIL.READFROMPROPERTYBUNDLE; if its lower-case value is 'true', 'yes', or '1', set the WUC_BLOCK_ALLOW_HEART_BEAT property to '1' on the bean; otherwise set it to '0'.
- Step 13 - Propagate server logging mode to the client bean: set WUC_SRV_LOGGING to '1' if logging is allowed but errors-only, '2' if full logging is allowed, or '0' if logging is disabled.
- Step 14 - If checkUserLibs is TRUE, call WEBUTIL.CHECKLIBS with the literal string 'user' to verify and download any user-defined client libraries.

---
**Decision Points**

DP-001
Condition: beanShortName matches one of the known constants (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL).
TRUE: packageID is set to the corresponding WEBUTIL_CORE package constant and processing continues.
FALSE: packageID remains undefined; no package registration occurs for the unrecognised bean.

DP-002
Condition: m_clientIP IS NULL (i.e., this is the very first bean to register in the session).
TRUE: checkUserLibs is set to TRUE and all client environment fields (IP, OS, OS family, architecture, username, path separator, file separator, language code) are parsed from clientInfo.
FALSE: checkUserLibs remains FALSE and client environment parsing is skipped.

DP-003
Condition: The architecture string parsed from clientInfo contains '64'.
TRUE: m_clientOSArch is set to 1 (64-bit).
FALSE: m_clientOSArch retains its default value (not 64-bit).

DP-004
Condition: The resolved packageID does not already exist in m_registeredPackages.
TRUE: The bean is recorded in m_registeredPackages and newPackage is set to TRUE.
FALSE: The bean is already registered; the duplicate instance is ignored and newPackage remains FALSE.

DP-005
Condition: The property bundle entry 'install.syslib.location.client.{osfamily}.{osarch}' returns a non-null value.
TRUE: clientLibDir is set to the architecture-specific path.
FALSE: A second lookup is attempted using 'install.syslib.location.client.{osfamily}' (without architecture suffix).

DP-006
Condition: The OS-family-only property bundle entry returns a non-null value.
TRUE: clientLibDir is set to the OS-family-specific path.
FALSE: clientLibDir remains null; the client JRE default placement is used and WUC_SYSLIB_DIR is set without a directory prefix.

DP-007
Condition: clientLibDir IS NULL after both property bundle lookups.
TRUE: WUC_SYSLIB_DIR is set to ':serverHost:appConfig' (no client directory prefix); client handles library placement.
FALSE: clientLibDir is not null; the $(SERVERHOST) placeholder is replaced, WUC_SYSLIB_DIR is set with the full path, and the old vs. new directory comparison is performed.

DP-008
Condition: The previously stored client library directory (clientLibDirOld from WEBUTIL.GETCLIENTSETTING) differs from the newly resolved clientLibDir.
TRUE: WEBUTIL.SETCLIENTSETTING persists the new directory and REDOWNLOAD_SYSLIB is set to TRUE.
FALSE: The directory is unchanged; no update is made and REDOWNLOAD_SYSLIB remains FALSE.

DP-009
Condition: WEBUTIL.READFROMPROPERTYBUNDLE('logging.connections') equals 'true' (case-insensitive).
TRUE: WEBUTIL.LOG is called to record the connection details (form name, client OS, locale).
FALSE: No connection log entry is written.

DP-010
Condition: newPackage is TRUE.
TRUE: WEBUTIL.CHECKLIBS is called with the packageID string to validate and download package-specific client libraries.
FALSE: Library check for this package is skipped.

DP-011
Condition: Lower-case value of 'BlockAllowHeartBeat' property is 'true', 'yes', or '1'.
TRUE: WUC_BLOCK_ALLOW_HEART_BEAT is set to '1' on the bean, instructing the client to block the allow-heartbeat behaviour.
FALSE: WUC_BLOCK_ALLOW_HEART_BEAT is set to '0', leaving heartbeat behaviour unrestricted.

DP-012
Condition: m_loggingAllowed is TRUE AND m_loggingErrorsOnly is TRUE.
TRUE: WUC_SRV_LOGGING is set to '1' (errors-only logging).
FALSE: Proceed to DP-013.

DP-013
Condition: m_loggingAllowed is TRUE (and m_loggingErrorsOnly is FALSE).
TRUE: WUC_SRV_LOGGING is set to '2' (full logging).
FALSE: WUC_SRV_LOGGING is set to '0' (logging disabled).

DP-014
Condition: checkUserLibs is TRUE (post-logging-initialisation check).
TRUE: WEBUTIL.CHECKLIBS is called with 'user' to verify and download user-defined client libraries.
FALSE: User library check is skipped.

---
**Database Interactions**

- DB-001 - Update THIS - Updates existing rows in THIS.
**Business Rules**

- BR-001 - Each bean type may only be registered once per form session; if the same bean type appears in a multi-row block or is otherwise instantiated multiple times, only the first instance is recorded and used.
- BR-002 - Client environment metadata (IP address, OS, OS family, architecture, username, path separator, file separator, language code) is captured exactly once per session, during the registration of the very first bean that contacts the server.
- BR-003 - A client machine whose OS architecture string contains '64' is classified as a 64-bit client (m_clientOSArch = 1); all others are treated as 32-bit.
- BR-004 - The system library download directory is resolved in priority order: architecture-specific configuration first, OS-family-only configuration second, and client JRE default last.
- BR-005 - If a configured client library directory differs from the previously recorded directory, the new value must be persisted via WEBUTIL.SETCLIENTSETTING and a full re-download of system libraries must be triggered (REDOWNLOAD_SYSLIB = TRUE).
- BR-006 - The $(SERVERHOST) placeholder within a configured client library directory path must be replaced with the runtime server host name before the path is transmitted to the client.
- BR-007 - The server host name is resolved by first querying the COMPUTERNAME environment variable; if that returns null, the HOST environment variable is used as a fallback.
- BR-008 - Connection logging is conditional: a connection record is written only when the 'logging.connections' property bundle entry is explicitly set to 'true' (case-insensitive).
- BR-009 - Library availability checks (WEBUTIL.CHECKLIBS) for a specific bean package are performed only when that package is newly registered in the current session.
- BR-010 - User library checks (WEBUTIL.CHECKLIBS with 'user') are performed only once per session, during first-contact processing, and must execute after at least one bean has been registered so that a handler bean exists to perform any required download.
- BR-011 - The BlockAllowHeartBeat configuration accepts three equivalent truthy values ('true', 'yes', '1'); any other value is treated as disabled.
- BR-012 - Server logging mode is communicated to the client bean as a single numeric property (WUC_SRV_LOGGING): 0 = disabled, 1 = errors only, 2 = full logging; this prevents the client from sending unnecessary log messages to the server.

---
**Implementation Logic**

```plsql
  PROCEDURE registerBean(clientInfo in VARCHAR2) is  
    packageID       PLS_INTEGER;
    beanShortName   VARCHAR2(3 char);
    newPackage      BOOLEAN := false;
    checkUserLibs   BOOLEAN := false;
    clientLibDir    VARCHAR2(1000 char);
    clientLibDirOld VARCHAR2(1000 char);
    serverHost      VARCHAR2(100 char);
    blockAllowHeartBeat VARCHAR2(10 char);
    clientOSArch    VARCHAR2(30 char);
  begin
    beanShortName := DelimStr.getString(clientInfo,1,true,'|');

    -- To speed access up we crossmatch the Bean Name string
    -- with a constant - this constant is used to access the 
    -- registered package array efficently
    -- need to update this IF statement as we add new packages
    if beanShortName = 'WUC' then
       packageID := WEBUTIL_CORE.WUC_PACKAGE; 
    elsif beanShortName = 'WUT' then     
       packageID := WEBUTIL_CORE.WUT_PACKAGE; 
    elsif beanShortName = 'WUF' then 
       packageID := WEBUTIL_CORE.WUF_PACKAGE; 
    elsif beanShortName = 'WUI' then
        packageID := WEBUTIL_CORE.WUI_PACKAGE; 
    elsif beanShortName = 'WUH' then            
       packageID := WEBUTIL_CORE.WUH_PACKAGE;
    elsif beanShortName = 'WUS' then     
       packageID := WEBUTIL_CORE.WUS_PACKAGE;
    elsif beanShortName = 'WUB' then 
       packageID := WEBUTIL_CORE.WUB_PACKAGE;
    elsif beanShortName = 'WUO' then     
       packageID := WEBUTIL_CORE.WUO_PACKAGE;
    elsif beanShortName = 'WUU' then     
       packageID := WEBUTIL_CORE.WUU_PACKAGE;
    elsif beanShortName = 'WUL' then     
       packageID := WEBUTIL_CORE.WUL_PACKAGE;           
    end if;
    -- For the very first bean we can get a bit of useful information
    -- Only do this once
    if m_clientIP is null then 
      checkUserLibs := true;
      -- Format of the clientinfo packet is
      -- BeanName|IP|OSName|UserName|pathSep|filesep
      m_clientIP       := DelimStr.getString(clientInfo,2,true,'|');
      m_clientOS       := DelimStr.getString(clientInfo,3,true,'|');
      m_clientOSFamily := getOSFamily(m_clientOS);
      clientOSArch     := DelimStr.getString(clientInfo,4,true,'|');
      if instr(clientOSArch, '64') > 0 then
        m_clientOSArch := 1;
      end if;
      m_clientUserName := DelimStr.getString(clientInfo,5,true,'|');      
      m_clientPathSep  := DelimStr.getString(clientInfo,6,true,'|');
      m_clientFileSep  := DelimStr.getString(clientInfo,7,true,'|');
      m_clientLangCode := DelimStr.getString(clientInfo,8,true,'|'); 
    end if;
      
    -- I'd only expect one instance of each bean per form
    -- but just in case we only register the first 
    -- so if multiple copies are used - e.g. it's 
    -- placed in a multi-row block we just use the 
    -- first instance.
    if not m_registeredPackages.EXISTS(packageID) then 
      m_registeredPackages(packageID) := name_in('SYSTEM.TRIGGER_ITEM');
      -- make sure all the required libraries are available
      -- on the client
      newPackage := true;
    end if;
      
    if checkUserLibs then
      -- checkUserLibs would be true if clientIP was null
      -- We can do whatever we want to do but not more than once
      REDOWNLOAD_SYSLIB := FALSE;
      -- We need to get the server host name using available built-ins. This looks lame,
      -- but it should work
      TOOL_ENV.GETVAR('COMPUTERNAME', serverHost);
      if serverHost is null then
        TOOL_ENV.GETVAR('HOST', serverHost);
      end if;
      clientLibDir := readFromPropertyBundle('install.syslib.location.client.'||to_char(m_clientOSFamily) ||
                                             '.' || to_char(m_clientOSArch));
      if clientLibDir is null then
        clientLibDir := readFromPropertyBundle('install.syslib.location.client.'||to_char(m_clientOSFamily));
      end if;
      if clientLibDir is null then
        -- client location when syslib download is not defined in webutil.cfg
        -- will be to client JRE. Send nothing and client will handle
        WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SYSLIB_DIR',
                                 ':' || serverHost || ':' || GET_APPLICATION_PROPERTY(CONFIG),
                                 true);
      else
        -- webutil.cfg contains a specific client directory for syslib download
        -- Replace $(SERVERHOST), if exists, with server host name
        clientLibDir := replace(clientLibDir, '$(SERVERHOST)', serverHost);

        -- The following line makes a few things happen on client including
        -- client directory creation, when clientLibDir is not null
        WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SYSLIB_DIR',
                                 clientLibDir || ':' || serverHost || ':' || GET_APPLICATION_PROPERTY(CONFIG),
                                 true);
        clientLibDirOld := GetClientSetting('install.syslib.dir');

        if clientLibDirOld <> clientLibDir then
    	  SetClientSetting('install.syslib.dir', clientLibDir);
          REDOWNLOAD_SYSLIB := TRUE;
    	end if;
      end if;
      Webutil_Core.WEBUTIL_VERSION := getProperty(WUC_PACKAGE,'WUC_BEAN_VERSION');
      -- We want to write the connection record if it's required.
      -- Any call to ReadFromPropertyBundle or log should be preferably made after
      -- registering at least one bean. That is the reason why the following log
      -- comes after m_registeredPackages(packageID) := name_in('SYSTEM.TRIGGER_ITEM'); above
      if lower(ReadFromPropertyBundle('logging.connections')) = 'true' then 
        log('Connection from Form='||GET_APPLICATION_PROPERTY(CURRENT_FORM)||' Client O/S='||m_clientOS||' locale='||m_clientLangCode,false);
      end if;
    end if;
    if newPackage then  
            checkLibs(to_char(packageID));
    end if;

    if checkUserLibs then
      -- Call a dummy log to initialize m_loggingAllowed and m_loggingErrorsOnly
      log(null,false);
    end if;

    -- 5950737 - Introduce new configuration variable BlockAllowHeartBeat. 
    -- Valid values are true, yes and 1.
    -- If this is set then send a message to the client to behave accordingly.    
    blockAllowHeartBeat := lower(ReadFromPropertyBundle('BlockAllowHeartBeat'));
    if blockAllowHeartBeat = 'true' or blockAllowHeartBeat = 'yes' or blockAllowHeartBeat = '1' then 
      WebUtil_Core.setProperty(packageID,'WUC_BLOCK_ALLOW_HEART_BEAT','1',true);
    else
      WebUtil_Core.setProperty(packageID,'WUC_BLOCK_ALLOW_HEART_BEAT','0',true);
    end if;

    -- Send server logging options to client bean so that the bean does not have
    -- to send message to server unnecessarily.
    if m_loggingAllowed and m_loggingErrorsOnly then
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','1',true);
    elsif m_loggingAllowed then
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','2',true);
    else
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','0',true);
    end if;
      
    -- 2836929 - move the user library check after the first package is registered 
    -- so that a handler bean exists to do the download.     
    if checkUserLibs then 
      --Check for and download any user libs
      checkLibs('user');  
    end if;     
  end registerBean;
```

#### SP-048 - WEBUTIL.REGISTER_FUNCTION

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a named function from a specified library with the WebUtil bean layer and returns a FunctionHandle that uniquely identifies the registered function for subsequent calls. The procedure communicates the library/function specification to the underlying WebUtil Core component, retrieves the resulting handle token, and increments the internal registered-function counter when a valid handle is obtained.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| libName | VARCHAR2 | IN |
| funcName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-036](#SP-036--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the library name (libName) and function name (funcName) as input identifiers for the target function to be registered.
- Step 2 - Concatenate libName and funcName with a pipe delimiter and transmit the combined specification to the WebUtil Core layer by invoking WebUtil_Core.setProperty against the WUL_PACKAGE target using the property key WUL_FUNCTION_SPEC.
- Step 3 - Retrieve the handle string assigned by the WebUtil Core layer by invoking WebUtil_Core.getProperty against the WUL_PACKAGE target using the property key WUL_REGISTER_FUNCTION; store the result in the local VARCHAR2 variable strHnd.
- Step 4 - Convert strHnd to a numeric value and assign it to the hnd attribute of the local FunctionHandle variable funcHnd.
- Step 5 - Evaluate whether the returned handle is valid by calling ID_NULL(funcHnd); if the handle is not null (i.e., registration succeeded), increment the module-level counter m_funcHandleCount by 1.
- Step 6 - Return funcHnd to the caller as the registered function's handle.
- Step 7 - On exception: if the WebUtil bean is not registered, display an error alert identifying the missing implementation class and raise FORM_TRIGGER_FAILURE; if a property error occurs, raise FORM_TRIGGER_FAILURE; if a VALUE_ERROR occurs during numeric conversion, raise TOOL_ERR.TOOL_ERROR.

---
**Decision Points**

DP-001

Condition: ID_NULL(funcHnd) evaluates to FALSE (i.e., the handle returned by WebUtil Core is a valid, non-null numeric value).

TRUE (handle is NOT null): Increment the module-level registered-function counter m_funcHandleCount by 1, confirming a successful registration.

FALSE (handle IS null): Skip the counter increment; return the null handle to the caller without updating the counter.

---

DP-002

Condition: A WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during the setProperty or getProperty calls.

TRUE: Display an error alert identifying the missing WebUtil implementation class bean and raise FORM_TRIGGER_FAILURE to abort the calling trigger.

FALSE: Continue normal processing.

---

DP-003

Condition: A WebUtil_Core.PROPERTY_ERROR exception is raised during the setProperty or getProperty calls.

TRUE: Raise FORM_TRIGGER_FAILURE to abort the calling trigger without displaying an additional alert.

FALSE: Continue normal processing.

---

DP-004

Condition: A VALUE_ERROR exception is raised during the TO_NUMBER conversion of strHnd.

TRUE: Raise TOOL_ERR.TOOL_ERROR to signal a data-conversion failure to the calling context.

FALSE: Continue normal processing.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function specification passed to the WebUtil Core layer must be formatted as a pipe-delimited concatenation of libName and funcName (libName || '|' || funcName); no other delimiter or format is permitted.
- BR-002 - A FunctionHandle is considered valid only when ID_NULL returns FALSE; only valid handles cause the module-level registration counter (m_funcHandleCount) to be incremented.
- BR-003 - If the WebUtil bean required to support function registration is absent, the procedure must surface an informative error alert that includes the implementation class name before aborting via FORM_TRIGGER_FAILURE; silent failure is not permitted in this scenario.
- BR-004 - A VALUE_ERROR during handle conversion must be escalated as TOOL_ERR.TOOL_ERROR, distinguishing data-conversion failures from bean or property errors.
- BR-005 - The procedure returns a FunctionHandle to every caller regardless of handle validity; it is the caller's responsibility to check handle validity before using the returned handle for further function invocations.

---
**Implementation Logic**

```plsql

  FUNCTION REGISTER_FUNCTION (libName IN VARCHAR2, funcName IN VARCHAR2) 
                              RETURN FunctionHandle IS
    strHnd  VARCHAR2(8);                            
    funcHnd FunctionHandle;
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUL_PACKAGE,'WUL_FUNCTION_SPEC', libName || '|' || funcName);
    strHnd := WebUtil_Core.getProperty(WebUtil_Core.WUL_PACKAGE,'WUL_REGISTER_FUNCTION');
    funcHnd.hnd := TO_NUMBER (strHnd);
    if NOT ID_NULL(funcHnd) then
      m_funcHandleCount := m_funcHandleCount + 1;
    end if;

    RETURN funcHnd;
    
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUL_PACKAGE)
                              ||' bean not found. WEBUTIL_C_API.REGISTER_FUNCTION will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;  
    when VALUE_ERROR then
        RAISE TOOL_ERR.TOOL_ERROR; 
  END REGISTER_FUNCTION;
```

#### SP-049 - WEBUTIL.RELEASE_PROCESS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Releases a previously acquired host process handle by clearing its associated callback trigger and nullifying the handle reference. This ensures that process resources managed by the WebUtil host utility are properly freed after use, preventing stale or orphaned process handles from persisting in the session.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the PROCESS_ID handle (IN OUT) that identifies the host process to be released.
- Step 2 - Invoke WebUtil_Core.setProperty to clear the process property on the WUH_PACKAGE bean, passing the current handle value, signalling the WebUtil infrastructure to release the associated host process.
- Step 3 - Invoke WebUtil_Core.ClearCallbackTrigger with the same handle to deregister any callback trigger that was registered against the process.
- Step 4 - Set process.handle to NULL, ensuring the caller's reference no longer points to a valid or active process.
- Step 5 - If a BEAN_NOT_REGISTERED exception is raised during any of the above steps, present an error alert to the user indicating that the required WebUtil bean could not be found and that WEBUTIL_HOST.Release_Process will not function, then exit without completing the release.

---
**Decision Points**

DP-001

Condition: A BEAN_NOT_REGISTERED exception is raised when attempting to interact with the WUH_PACKAGE bean via WebUtil_Core.

TRUE: An error alert is displayed to the user, identifying the missing implementation class and stating that WEBUTIL_HOST.Release_Process will not work. The procedure exits via the exception handler without nullifying the handle.

FALSE: The procedure completes normally - the process property is cleared, the callback trigger is deregistered, and process.handle is set to NULL.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The process handle passed to this procedure must be an active PROCESS_ID previously obtained through the WebUtil host process mechanism; the procedure does not validate the handle prior to attempting release.
- BR-002 - The WebUtil WUH_PACKAGE bean must be registered and available at the time of invocation; if it is not, the release operation is aborted and the handle is not nullified.
- BR-003 - Upon successful completion, the caller's process.handle is unconditionally set to NULL, preventing any subsequent reuse of the released handle.
- BR-004 - Both the property clearing (setProperty) and the callback trigger deregistration (ClearCallbackTrigger) must be performed before the handle is nullified, ensuring full cleanup of all resources associated with the process.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Release_Process(process in out PROCESS_ID) is  
  begin
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_CLEAR_PROC',process.handle);
    WebUtil_Core.ClearCallbackTrigger(process.handle);
    process.handle := null;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.Release_Process will not work');
  end Release_Process;
```

#### SP-050 - WEBUTIL.SETCLIENTSETTING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Transmits a named configuration property and its value to the WebUtil client-side bean by delegating to WebUtil_Core.setProperty. This allows the Oracle Forms runtime to push local client settings (identified by a property name/value pair) to the WebUtil core package bean during form initialisation or bean registration.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyName | VARCHAR2 | IN |
| propertyValue | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the property name (propertyName) and property value (propertyValue) as input parameters.
- Step 2 - Evaluate whether propertyName is not null; if it is null, no action is taken and the procedure exits silently.
- Step 3 - If propertyName is not null, invoke WebUtil_Core.setProperty, passing the WebUtil_Core.WUC_PACKAGE identifier, the action constant WUC_SET_LOCAL_PROPERTY, and the concatenated string propertyName||'='||propertyValue as the property payload.
- Step 4 - If the WebUtil core bean has not yet been registered (WebUtil_Core.BEAN_NOT_REGISTERED exception), raise an error alert identifying the missing bean class and then raise FORM_TRIGGER_FAILURE to halt further form processing.
- Step 5 - If a property error occurs during the setProperty call (WebUtil_Core.PROPERTY_ERROR exception), raise FORM_TRIGGER_FAILURE to halt further form processing without an additional alert.

---
**Decision Points**

DP-001

Condition:
propertyName IS NOT NULL

TRUE:
Call WebUtil_Core.setProperty with WUC_PACKAGE, WUC_SET_LOCAL_PROPERTY, and the concatenated propertyName||'='||propertyValue string to transmit the setting to the client bean.

FALSE:
Skip the setProperty call entirely; the procedure exits without performing any action.

DP-002

Condition:
WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during the setProperty call

TRUE:
Display an error alert identifying the missing WebUtil_Core implementation class bean, then raise FORM_TRIGGER_FAILURE to abort the current form trigger.

FALSE:
Exception is not raised; normal processing continues.

DP-003

Condition:
WebUtil_Core.PROPERTY_ERROR exception is raised during the setProperty call

TRUE:
Raise FORM_TRIGGER_FAILURE immediately to abort the current form trigger (no alert is displayed).

FALSE:
Exception is not raised; normal processing continues.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A null propertyName is treated as a no-op; the procedure must not attempt to transmit a setting to the client bean when the property name is absent.
- BR-002 - The property payload delivered to the client bean must be formatted as a single concatenated string in the form propertyName||'='||propertyValue; no other format is permitted.
- BR-003 - If the WebUtil core bean is not registered at the time of the call, the procedure must surface an informative error alert referencing the missing implementation class before terminating the form trigger via FORM_TRIGGER_FAILURE.
- BR-004 - A WebUtil_Core.PROPERTY_ERROR condition must cause immediate termination of the form trigger via FORM_TRIGGER_FAILURE; no additional alert is required in this case.
- BR-005 - The property is set against the WebUtil_Core.WUC_PACKAGE scope using the WUC_SET_LOCAL_PROPERTY action constant; no other package scope or action constant is used by this procedure.

---
**Implementation Logic**

```plsql

  PROCEDURE SetClientSetting(propertyName  in VARCHAR2,
                             propertyValue in VARCHAR2) is
  BEGIN
    if propertyName is not null then 
      WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SET_LOCAL_PROPERTY', propertyName||'='||propertyValue);
    end if;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                              ||' bean not found. WEBUTIL_CORE.SetClientSetting will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;       
  END SetClientSetting;
```

#### SP-051 - WEBUTIL.SETDATA

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.SETDATA receives a single chunk of upload data (as a VARCHAR2 string) and writes it to the appropriate persistence target - either a database BLOB (via WebUtil_DB_LOCAL) or a server-side file (via JAVA_APPSERV_WRITER). It tracks the remaining chunk count and, when the final chunk is processed, closes the target resource, marks the upload as succeeded or failed, fires any registered callback trigger, and clears that trigger registration. It is the core data-reception handler called during a chunked file-upload sequence initiated by WEBUTIL_CORE.CUSTOMEVENTHANDLER.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| uploadData | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.CLEARCALLBACKTRIGGER ([SP-013](#SP-013--WEBUTIL.CLEARCALLBACKTRIGGER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.CLOSEBLOB ([SP-014](#SP-014--WEBUTIL.CLOSEBLOB)) - WEBUTIL.pck (or .pld)
- WEBUTIL.CLOSEFILE ([SP-015](#SP-015--WEBUTIL.CLOSEFILE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCALLBACKTRIGGER ([SP-022](#SP-022--WEBUTIL.GETCALLBACKTRIGGER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETLASTERROR ([SP-026](#SP-026--WEBUTIL.GETLASTERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETLASTERRORARGS ([SP-027](#SP-027--WEBUTIL.GETLASTERRORARGS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.WRITEDATA ([SP-054](#SP-054--WEBUTIL.WRITEDATA)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the uploadData VARCHAR2 parameter representing one chunk of the in-progress file upload.
- Step 2 - Validate that uploadData is not null and not an empty string; if either condition is true, set the module-level flag m_uploadSucceeded to FALSE and exit without further processing.
- Step 3 - Determine the persistence target by evaluating the module-level flag m_toDB.
- Step 4 (m_toDB = TRUE) - Call WebUtil_DB_LOCAL.WriteData to write the chunk to the database BLOB destination.
- Step 5 (m_toDB = FALSE) - Call JAVA_APPSERV_WRITER.WriteData to write the chunk to the server-side file. If WriteData returns FALSE, retrieve the error code via JAVA_APPSERV_WRITER.getLastError and the error arguments via JAVA_APPSERV_WRITER.getLastErrorArgs, log the error through WebUtil_Core.Error, and raise the READWRITE_ERROR exception to abort processing.
- Step 6 - Decrement the module-level chunk counter m_chunks by 1.
- Step 7 - Evaluate whether m_chunks has reached 0, indicating that all expected chunks have been received.
- Step 8 (final chunk, m_toDB = TRUE) - Call WebUtil_DB_LOCAL.CloseBlob passing m_fileSize. If CloseBlob returns TRUE, set m_uploadSucceeded to TRUE; otherwise retrieve the last error via WebUtil_DB_Local.getLastError, log it through WebUtil_Core.Error, and leave m_uploadSucceeded as FALSE.
- Step 9 (final chunk, m_toDB = FALSE) - Call JAVA_APPSERV_WRITER.CloseFile passing m_persistObj and m_fileSize. If CloseFile returns TRUE, set m_uploadSucceeded to TRUE; otherwise retrieve the error code and arguments, log the error through WebUtil_Core.Error, delete the global Java object reference via ORA_JAVA.DELETE_GLOBAL_REF, and raise READWRITE_ERROR.
- Step 10 (final chunk, post-close) - Call WEBUTIL.GETCALLBACKTRIGGER with argument -1; if a callback trigger name is returned (not null), execute that trigger via EXECUTE_TRIGGER.
- Step 11 - Call WEBUTIL.CLEARCALLBACKTRIGGER with argument -1 to deregister the callback trigger regardless of whether one was fired.

---
**Decision Points**

DP-001

Condition: uploadData IS NULL or uploadData = '' (empty string)

TRUE: Set m_uploadSucceeded to FALSE and exit the procedure immediately; no data is written and no chunk counter is decremented.

FALSE: Proceed to write the chunk to the designated persistence target.

---

DP-002

Condition: m_toDB is TRUE

TRUE: Write the chunk to the database BLOB using WebUtil_DB_LOCAL.WriteData.

FALSE: Write the chunk to the server-side file using JAVA_APPSERV_WRITER.WriteData.

---

DP-003

Condition: JAVA_APPSERV_WRITER.WriteData returns FALSE (file-path write failure)

TRUE: Retrieve error details via JAVA_APPSERV_WRITER.getLastError and JAVA_APPSERV_WRITER.getLastErrorArgs, log the error, and raise READWRITE_ERROR to halt processing.

FALSE: Write succeeded; continue to decrement the chunk counter.

---

DP-004

Condition: m_chunks equals 0 after decrement (all chunks received)

TRUE: Proceed to close the persistence target (BLOB or file) and finalise the upload.

FALSE: More chunks are still expected; exit without closing the target.

---

DP-005

Condition: m_toDB is TRUE at final-chunk close

TRUE: Call WebUtil_DB_LOCAL.CloseBlob to finalise the BLOB.

FALSE: Call JAVA_APPSERV_WRITER.CloseFile to finalise the server-side file.

---

DP-006

Condition: WebUtil_DB_LOCAL.CloseBlob returns TRUE

TRUE: Set m_uploadSucceeded to TRUE.

FALSE: Retrieve the last error via WebUtil_DB_Local.getLastError, log it, and leave m_uploadSucceeded as FALSE.

---

DP-007

Condition: JAVA_APPSERV_WRITER.CloseFile returns TRUE

TRUE: Set m_uploadSucceeded to TRUE.

FALSE: Retrieve error details via JAVA_APPSERV_WRITER.getLastError and JAVA_APPSERV_WRITER.getLastErrorArgs, log the error, delete the global Java object reference, and raise READWRITE_ERROR.

---

DP-008

Condition: WEBUTIL.GETCALLBACKTRIGGER(-1) returns a non-null trigger name

TRUE: Execute the named callback trigger via EXECUTE_TRIGGER.

FALSE: Skip trigger execution; proceed directly to clearing the callback trigger registration.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - An empty or null uploadData chunk is treated as an error condition; the upload is immediately marked as failed (m_uploadSucceeded = FALSE) and no data is written to any target.
- BR-002 - Each call to SETDATA processes exactly one chunk; the procedure is designed to be invoked repeatedly until all chunks of a file upload have been delivered.
- BR-003 - The persistence target (database BLOB vs. server-side file) is determined exclusively by the pre-set module-level flag m_toDB; SETDATA does not select or change the target itself.
- BR-004 - A write failure to the server-side file target is a terminal error: the READWRITE_ERROR exception is raised after logging, preventing any further processing of that upload session.
- BR-005 - The resource (BLOB or file) is closed only when the chunk counter m_chunks reaches zero, ensuring the target is not prematurely finalised during a multi-chunk transfer.
- BR-006 - A close failure on the server-side file additionally requires deletion of the persistent Java object reference (ORA_JAVA.DELETE_GLOBAL_REF) before raising READWRITE_ERROR, preventing resource leaks.
- BR-007 - The upload is marked as succeeded (m_uploadSucceeded = TRUE) only upon successful closure of the persistence target; a failed close leaves the upload in a failed state.
- BR-008 - After the final chunk is processed and the target is closed, any callback trigger registered against slot -1 must be executed and then unconditionally cleared via WEBUTIL.CLEARCALLBACKTRIGGER, regardless of whether a trigger was present.

---
**Implementation Logic**

```plsql
   
  PROCEDURE SetData(uploadData in VARCHAR2) is 
    lastErrorCode    PLS_INTEGER;
    lastErrorArgs    VARCHAR2(1000);   
  BEGIN
    if uploadData is null or uploadData = '' then 
      -- error condition!
      m_uploadSucceeded := false;
    else
      -- Write to the correct place    
      if m_toDB then 
        WebUtil_DB_LOCAL.WriteData(uploadData);
      else
        if not JAVA_APPSERV_WRITER.WriteData(m_persistObj,uploadData) then
          lastErrorCode := JAVA_APPSERV_WRITER.getLastError(m_persistObj);
          lastErrorArgs := JAVA_APPSERV_WRITER.getLastErrorArgs(m_persistObj) ;
          WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                             'WEBUTIL_FILE_TRANSFER.SetData',lastErrorArgs);
          raise READWRITE_ERROR;
        end if;
      end if;
      m_chunks := m_chunks - 1;
      if m_chunks = 0 then 
        if m_toDB then 
          if WebUtil_DB_Local.CloseBlob(m_fileSize) then 
            m_uploadSucceeded := true;
          else
            WebUtil_core.Error(Webutil_Core.WUT_PACKAGE, WebUtil_DB_Local.getLastError,
                               'WEBUTIL_FILE_TRANSFER.SetData');
          end if; -- close
        else
          if JAVA_APPSERV_WRITER.CloseFile(m_persistObj,m_fileSize) then
            m_uploadSucceeded := true;
          else
            lastErrorCode := JAVA_APPSERV_WRITER.getLastError(m_persistObj);
            lastErrorArgs := JAVA_APPSERV_WRITER.getLastErrorArgs(m_persistObj) ;
            WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                               'WEBUTIL_FILE_TRANSFER.SetData',lastErrorArgs);
            ORA_JAVA.DELETE_GLOBAL_REF(m_persistObj);
            raise READWRITE_ERROR;
          end if;    
        end if; -- toDB

        if WebUtil_Core.GetCallbackTrigger(-1) is not null then
          EXECUTE_TRIGGER(WebUtil_Core.GetCallbackTrigger(-1));
        end if;
        WebUtil_Core.ClearCallbackTrigger(-1);
      end if; -- chunks
    end if;
  end SetData;
```

#### SP-052 - WEBUTIL.SETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sets a Java system property at runtime by delegating to the Java Native Interface (JNI) layer. The procedure accepts a property key and a property value, invokes the standard Java `System.setProperty` method via JNI, and returns the previous value of the property (if any). This allows Oracle Forms to configure or override JVM-level system properties during a WebUtil custom event handling cycle.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |
| a1 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the property key (a0) and the new property value (a1) as VARCHAR2 input parameters.
- Step 2 - Create a JNI argument list sized for two arguments using JNI.CREATE_ARG_LIST(2).
- Step 3 - Add the property key string (a0) as the first argument to the JNI argument list via JNI.ADD_STRING_ARG.
- Step 4 - Add the property value string (a1) as the second argument to the JNI argument list via JNI.ADD_STRING_ARG.
- Step 5 - Invoke the Java method `java.lang.System.setProperty(String, String)` through JNI.CALL_STRING_METHOD, passing both arguments, and capture the return value (the previous value of the named property, or NULL if it was not previously set).
- Step 6 - Return the VARCHAR2 result (previous property value) to the caller.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The procedure executes a linear sequence of JNI calls unconditionally for all valid inputs.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Both the property key (a0) and the property value (a1) must be supplied as VARCHAR2 strings; the JNI argument list is constructed with exactly two positional string arguments and will not accommodate a different argument count.
- BR-002 - The target Java method is fixed as `java.lang.System.setProperty` with the signature `(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;`; no other Java method may be substituted through this procedure.
- BR-003 - The function returns the previous value of the Java system property as it existed before the update; callers that need to preserve the original value must capture this return value.
- BR-004 - This procedure has no database interactions; all processing occurs within the JVM via the JNI bridge and does not affect any database state.

---
**Implementation Logic**

```plsql
  FUNCTION setProperty(
    a0    VARCHAR2,
    a1    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(2);
    JNI.ADD_STRING_ARG(args, a0);
    JNI.ADD_STRING_ARG(args, a1);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'setProperty', '(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-053 - WEBUTIL.SHOWBEANS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.INITWEBUTIL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Controls the visibility of the hidden WebUtil window (WEBUTIL_HIDDEN_WINDOW) used to host WebUtil bean components. When called with show = TRUE, the procedure surfaces the window and navigates focus into it; when called with show = FALSE, it hides the window and restores focus to the previously active item. Execution is suppressed while the form is in Enter Query Mode to prevent interference with query operations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| show | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-036](#SP-036--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Boolean parameter 'show', which determines whether the WebUtil hidden window should be displayed or hidden.
- Step 2 - Check SYSTEM.MODE; if the form is not in NORMAL mode (e.g., it is in Enter Query Mode), skip all processing entirely to avoid disrupting query operations.
- Step 3 - Locate the hidden window by calling FIND_WINDOW with the constant WEBUTIL_HIDDEN_WINDOW and store the handle in a local variable.
- Step 4 - Call WEBUTIL.ID_NULL on the window handle to verify that the window was successfully found; if the handle is null (window not found), skip all further processing.
- Step 5 - If 'show' is TRUE: capture the currently focused item by reading SYSTEM.CURSOR_ITEM via FIND_ITEM and storing it in the module-level variable m_infoFrom; set the window title to 'WebUtil ' concatenated with WEBUTIL_VERSION; call SHOW_WINDOW to make the hidden window visible; then navigate focus to WEBUTIL_DUMMY_ITEM within that window.
- Step 6 - If 'show' is FALSE: check whether m_infoFrom is non-null using WEBUTIL.ID_NULL; if it holds a valid item reference, navigate focus back to that item via GO_ITEM; then call HIDE_WINDOW to conceal the hidden window.

---
**Decision Points**

DP-001

Condition: SYSTEM.MODE equals 'NORMAL'

TRUE: Proceed with show/hide logic for the WebUtil hidden window.

FALSE: Abort the procedure without performing any window or focus operations (guards against execution during Enter Query Mode).

---

DP-002

Condition: WEBUTIL.ID_NULL(hWin) is FALSE (i.e., the WEBUTIL_HIDDEN_WINDOW handle is valid)

TRUE: Proceed with show or hide processing based on the 'show' parameter.

FALSE: Skip all window and focus operations; the target window does not exist in the current form session.

---

DP-003

Condition: The 'show' parameter is TRUE

TRUE: Capture the current cursor item into m_infoFrom, set the window title, show the window, and navigate focus to WEBUTIL_DUMMY_ITEM.

FALSE: Attempt to restore focus to the previously captured item (m_infoFrom) and hide the window.

---

DP-004

Condition: When hiding the window - WEBUTIL.ID_NULL(m_infoFrom) is FALSE (i.e., a prior cursor item was captured)

TRUE: Call GO_ITEM to return focus to the item stored in m_infoFrom before hiding the window.

FALSE: Skip the GO_ITEM call; no prior item reference is available to restore focus to.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must not execute any window or focus manipulation while the form is in Enter Query Mode (SYSTEM.MODE ≠ 'NORMAL'); this prevents corruption of query state.
- BR-002 - The WebUtil hidden window (WEBUTIL_HIDDEN_WINDOW) must exist and return a non-null handle before any show or hide action is attempted; the procedure silently aborts if the window is not found.
- BR-003 - When displaying the WebUtil window, the procedure must record the currently focused form item (SYSTEM.CURSOR_ITEM) in m_infoFrom so that focus can be accurately restored when the window is subsequently hidden.
- BR-004 - The WebUtil hidden window title must be set to the string 'WebUtil ' concatenated with the WEBUTIL_VERSION constant each time the window is shown, ensuring the version is always visible in the window title bar.
- BR-005 - Focus must be explicitly moved to WEBUTIL_DUMMY_ITEM after the hidden window is shown, ensuring the form's navigation context is correctly positioned within the WebUtil window.
- BR-006 - Focus may only be restored to the previously captured item (m_infoFrom) on hide if that item reference is non-null; restoration is skipped when no prior item was recorded.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ShowBeans(show BOOLEAN) is
    hWin WINDOW := FIND_WINDOW(WEBUTIL_HIDDEN_WINDOW);
  begin
    -- Bug 2955789 - don't attempt to do this when in Enter Query Mode
    if name_in('SYSTEM.MODE') = 'NORMAL' then 
      if not ID_NULL(hWin) then 
        if show then 
          m_infoFrom := FIND_ITEM(name_in('SYSTEM.CURSOR_ITEM'));
          SET_WINDOW_PROPERTY(hWin,TITLE,'WebUtil '||WEBUTIL_VERSION);
          SHOW_WINDOW(hWin);
          go_item(WEBUTIL_DUMMY_ITEM);
        else
          if not id_null(m_infoFrom) then 
              go_item(m_infoFrom);
          end if;
          HIDE_WINDOW(hWin);
        end if;
      end if;
    end if;
  end ShowBeans;
```

#### SP-054 - WEBUTIL.WRITEDATA

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Passes a string data payload to the Java-layer AppServerFileWriter class on the application server by invoking its WriteData method via the JNI bridge. The function returns a Boolean indicating whether the write operation succeeded, and is consumed by WEBUTIL.SETDATA to persist data to a server-side file.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the target Java object reference (obj) representing an active AppServerFileWriter instance and the string data payload (a0) to be written.
- Step 2 - Create a JNI argument list sized for one argument by calling JNI.CREATE_ARG_LIST(1).
- Step 3 - Add the string payload (a0) to the argument list by calling JNI.ADD_STRING_ARG(args, a0).
- Step 4 - Invoke the Java method WriteData on the AppServerFileWriter class through the JNI bridge using JNI.CALL_BOOLEAN_METHOD, passing the object reference, fully-qualified class path, method name, JNI method signature, and the prepared argument list.
- Step 5 - Return the Boolean result produced by the Java method to the caller, indicating success or failure of the write operation.

---
**Decision Points**

No conditional decision points exist within this function. The function constructs the JNI argument list, delegates execution entirely to the Java AppServerFileWriter.WriteData method, and returns the Boolean result produced by that method without branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The data payload must be supplied as a VARCHAR2 value; the function accepts exactly one string argument and no other data types are supported by the JNI method signature '(Ljava/lang/String;)Z'.
- BR-002 - The obj parameter must reference a valid, pre-instantiated AppServerFileWriter Java object; the function does not create or validate the object reference itself.
- BR-003 - The success or failure of the write operation is determined solely by the return value of the Java AppServerFileWriter.WriteData method; the function propagates that Boolean result unchanged to the caller.
- BR-004 - This function must be invoked through WEBUTIL.SETDATA, which is responsible for managing the AppServerFileWriter lifecycle; direct invocation outside of that context is not supported.

---
**Implementation Logic**

```plsql
  FUNCTION WriteData(
    obj   ORA_JAVA.JOBJECT,
    a0    VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_BOOLEAN_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileWriter', 'WriteData', '(Ljava/lang/String;)Z', args); 
  END;
```

#### SP-055 - WEBUTIL_CORE.CUSTOMEVENTHANDLER

**Invoked From:**

- vr_cross_fmb.xml [Trigger: WHEN-CUSTOM-ITEM-EVENT]

---

**Screen:**

N/A

---

**Purpose**

Acts as the central dispatcher for custom item events raised by the WebUtil client-side Java bean. When a WHEN-CUSTOM-ITEM-EVENT trigger fires, this procedure receives the event name and its serialised parameter string, extracts the data payload and multipart chunk metadata, and routes execution to the appropriate WebUtil handler routine (logging, error reporting, bean registration, host-command callback, or file-transfer processing). Events that are not recognised by the procedure are silently discarded; all other unexpected exceptions are re-raised to the caller.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| EventName | VARCHAR2 | IN |
| EventParameters | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERROR ([SP-017](#SP-017--WEBUTIL.ERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETNUMBER ([SP-028](#SP-028--WEBUTIL.GETNUMBER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-042](#SP-042--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.REGISTERBEAN ([SP-047](#SP-047--WEBUTIL.REGISTERBEAN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETDATA ([SP-051](#SP-051--WEBUTIL.SETDATA)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETPROPERTY ([SP-052](#SP-052--WEBUTIL.SETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the incoming event name (EventName) and its serialised parameter string (EventParameters) from the WHEN-CUSTOM-ITEM-EVENT trigger.
- Step 2 - Validate that EventName is one of the five permitted values: WUC_LOG_EVENT, WUC_ERROR_EVENT, WUC_REGISTER, WUH_CALLBACK_EVENT, or WUT_TRANSFER_EVENT. If it is not, raise the internal 'unhandled' exception, which is caught silently, and exit the procedure.
- Step 3 - Extract the primary data payload by calling get_parameter_attr against EventParameters using the key WUC_DATA; store the result in dataPayload.
- Step 4 - Extract the multipart chunk descriptor by calling get_parameter_attr against EventParameters using the key WUC_DATA_MULTIPART; store the result in dataMultiPart.
- Step 5 - Parse dataMultiPart using DelimStr.getNumber to derive the current chunk sequence number (chunkNumber, position 1) and the total number of chunks that constitute the full payload (PayloadChunks, position 2), using '/' as the delimiter.
- Step 6 - Route to the appropriate handler based on EventName:
  - WUC_LOG_EVENT: call WEBUTIL.LOG (via WebUtil_Core.log) passing dataPayload with the error flag set to FALSE.
  - WUC_ERROR_EVENT: call WEBUTIL.LOG (via WebUtil_Core.log) passing dataPayload with the error flag set to TRUE.
  - WUC_REGISTER: call WEBUTIL.REGISTERBEAN (via registerBean) passing dataPayload to register the bean.
  - WUH_CALLBACK_EVENT: convert dataPayload to a number and store it in the package-level variable m_lastCallback; if conversion fails, call WEBUTIL.ERROR to record error code 408 attributed to WEBUTIL_CORE.CustomEventHandler; if m_lastCallback is populated, execute the corresponding trigger stored in m_callbacks; if m_lastCallback is null, call WEBUTIL.LOG to record a warning that no callback trigger was specified.
  - WUT_TRANSFER_EVENT: call WEBUTIL.SETDATA (via WebUtil_File_Transfer.setData) passing dataPayload to store the transferred file data, then call WEBUTIL.SETPROPERTY (via WebUtil_Core.setProperty) to mark the WUT_TRANSFER_EVENT property as 'RECEIVED' on the WUT_PACKAGE component.
- Step 7 - On completion of the routed handler, return control to the calling trigger. Unhandled events exit silently; all other exceptions propagate to the caller.

---
**Decision Points**

DP-001

Condition: EventName is one of 'WUC_LOG_EVENT', 'WUC_ERROR_EVENT', 'WUC_REGISTER', 'WUH_CALLBACK_EVENT', or 'WUT_TRANSFER_EVENT'.

TRUE: Continue processing - extract payload and multipart metadata, then route to the appropriate handler.

FALSE: Raise the internal 'unhandled' exception, which is caught silently; the procedure exits without further action.

---

DP-002

Condition: EventName = 'WUC_LOG_EVENT'.

TRUE: Call WEBUTIL.LOG with dataPayload and error flag FALSE to write an informational log entry.

FALSE: Evaluate subsequent event-name conditions.

---

DP-003

Condition: EventName = 'WUC_ERROR_EVENT'.

TRUE: Call WEBUTIL.LOG with dataPayload and error flag TRUE to write an error log entry.

FALSE: Evaluate subsequent event-name conditions.

---

DP-004

Condition: EventName = 'WUC_REGISTER'.

TRUE: Call WEBUTIL.REGISTERBEAN with dataPayload to register the client-side bean.

FALSE: Evaluate subsequent event-name conditions.

---

DP-005

Condition: EventName = 'WUH_CALLBACK_EVENT'.

TRUE: Attempt to convert dataPayload to a number and store it in m_lastCallback; evaluate DP-006 and DP-007.

FALSE: Evaluate the WUT_TRANSFER_EVENT condition.

---

DP-006

Condition: Conversion of dataPayload to a number succeeds (no INVALID_NUMBER exception).

TRUE: Store the numeric value in m_lastCallback and proceed to DP-007.

FALSE: Call WEBUTIL.ERROR to record error code 408 attributed to WEBUTIL_CORE.CustomEventHandler; m_lastCallback remains unset.

---

DP-007

Condition: m_lastCallback IS NOT NULL.

TRUE: Execute the trigger referenced by m_callbacks(m_lastCallback) via EXECUTE_TRIGGER.

FALSE: Call WEBUTIL.LOG to record a warning that the callback trigger for the host command was not specified.

---

DP-008

Condition: EventName = 'WUT_TRANSFER_EVENT'.

TRUE: Call WEBUTIL.SETDATA with dataPayload to store the file-transfer data, then call WEBUTIL.SETPROPERTY to mark the transfer event as 'RECEIVED'.

FALSE: No further routing action is taken (all five event types have been evaluated).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only the following five event names are considered valid for processing: WUC_LOG_EVENT, WUC_ERROR_EVENT, WUC_REGISTER, WUH_CALLBACK_EVENT, and WUT_TRANSFER_EVENT. Any event name outside this set is silently ignored and does not cause an application error.
- BR-002 - The data payload and multipart chunk descriptor must always be extracted from EventParameters before any event-specific handler is invoked, regardless of which event is being processed.
- BR-003 - A WUC_LOG_EVENT must be routed to the logging facility with the error flag set to FALSE, distinguishing it from error-level log entries.
- BR-004 - A WUC_ERROR_EVENT must be routed to the logging facility with the error flag set to TRUE, ensuring it is recorded as an error-level entry.
- BR-005 - A WUC_REGISTER event must invoke the bean-registration routine, passing the full data payload as the bean descriptor.
- BR-006 - For a WUH_CALLBACK_EVENT, the data payload must be a valid integer representing a callback index; if the conversion to a number fails, error code 408 must be raised via WEBUTIL.ERROR and attributed to WEBUTIL_CORE.CustomEventHandler.
- BR-007 - A host-command callback may only be executed if m_lastCallback is not null; a null value indicates no callback trigger was registered, and a warning must be logged via WEBUTIL.LOG rather than attempting execution.
- BR-008 - For a WUT_TRANSFER_EVENT, the file-transfer data must be stored via WEBUTIL.SETDATA and the transfer event property must be immediately updated to 'RECEIVED' via WEBUTIL.SETPROPERTY on the WUT_PACKAGE component, confirming receipt to subsequent processing steps.
- BR-009 - Unexpected runtime exceptions (OTHERS) must be re-raised to the calling trigger; only the internally defined 'unhandled' exception for unrecognised event names is suppressed.

---
**Implementation Logic**

```plsql
  PROCEDURE CustomEventHandler(EventName       in VARCHAR2, 
                               EventParameters in VARCHAR2) is
    dataPayload   VARCHAR2(32767 char);   
    dataMultiPart VARCHAR2(61 char); /* should be enough! */ 
    chunkNumber   PLS_INTEGER;
    PayloadChunks PLS_INTEGER;
    dataType      PLS_INTEGER;
    unhandled     EXCEPTION;
  begin
    --Bug 2839033 - check for valid events only      
    if EventName not in ('WUC_LOG_EVENT',
                         'WUC_ERROR_EVENT', 
                         'WUC_REGISTER',
                         'WUH_CALLBACK_EVENT', 
                         'WUT_TRANSFER_EVENT') then  
      raise unhandled;
    end if;                        

    -- We're pretty much always going to need the data payload and 
    -- number of parts that make up that payload so get it now..
    get_parameter_attr(EventParameters,'WUC_DATA',dataType, dataPayload);
    get_parameter_attr(EventParameters,'WUC_DATA_MULTIPART',dataType, dataMultiPart);      
    -- split the MULTIPART info to work out how many messages from the 
    -- client are required to create the completed payload
    chunkNumber   := DelimStr.getNumber(dataMultiPart,1,true,'/');
    PayloadChunks := DelimStr.getNumber(dataMultiPart,2,true,'/');

    -- Now deal with the specific events that the client may dispatch
    -- This section will have to be extended for each new event that we 
    -- Add in order to hook the handler code for that message to the data 
    -- that is being sent - shame we can't subclass in PL/SQL :-)      
    if EventName = 'WUC_LOG_EVENT' then
        WebUtil_Core.log(dataPayload,false);
    elsif EventName = 'WUC_ERROR_EVENT' then
        WebUtil_Core.log(dataPayload,true);
    elsif EventName = 'WUC_REGISTER' then 
        registerBean(dataPayload);
    elsif EventName = 'WUH_CALLBACK_EVENT' then 
      begin 
        m_lastCallback := to_number(dataPayload);
      exception
          when INVALID_NUMBER then 
            error(WebUtil_Core.WUC_PACKAGE,408,'WEBUTIL_CORE.CustomEventHandler');
      end;
      if m_lastCallback is not null then 
          EXECUTE_TRIGGER(m_callbacks(m_lastCallback));
      else
            log('Callback trigger for host command not specified',true);
      end if;
    elsif EventName = 'WUT_TRANSFER_EVENT' then 
      WebUtil_File_Transfer.setData(dataPayload);
      WebUtil_Core.setProperty(WebUtil_Core.WUT_PACKAGE, 'WUT_TRANSFER_EVENT','RECEIVED');
    end if;
  exception
    when unhandled then
      null;
    when OTHERS then
      raise;
  end CustomEventHandler;
```

#### SP-056 - ADD_ERROR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Records a runtime error by setting a global error flag and composing a standardised error stack entry that identifies the calling function and the associated error text. The composed message is immediately forwarded to the debug logging facility (DEBUGLOG) for diagnostic tracing.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| CallingFunction | VARCHAR2 | IN |
| SetErrorText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-060](#SP-060--DEBUGLOG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Receive the name of the calling function (CallingFunction) and the descriptive error text (SetErrorText) as input parameters.
- Step 2 - Set the global flag ERROR_ENCOUNTERED to TRUE to signal that an error condition has been raised within the current execution context.
- Step 3 - Compose the global ERROR_STACK value by concatenating CallingFunction, a colon-space separator, and the first 1,968 characters of SetErrorText, ensuring the stored message does not exceed the permitted length.
- Step 4 - Invoke DEBUGLOG (SP-060) at debug level 99, identifying the source routine as 'Add_Error' and passing the composed ERROR_STACK value for diagnostic logging.

---
**Decision Points**

No conditional decision points exist in this procedure. All steps execute unconditionally for every invocation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The global error flag ERROR_ENCOUNTERED must be set to TRUE whenever this procedure is called, unconditionally marking the session or processing unit as having encountered an error.
- BR-002 - The error stack entry must be formatted as '<CallingFunction>: <ErrorText>' to ensure the originating routine is always identifiable within the logged message.
- BR-003 - The error text stored in ERROR_STACK is truncated to a maximum of 1,968 characters to prevent overflow of the target variable while preserving as much diagnostic detail as possible.
- BR-004 - Every error recorded via this procedure must be forwarded to DEBUGLOG at severity level 99, guaranteeing that all error events are captured in the debug log regardless of the calling context.

---
**Implementation Logic**

```plsql

PROCEDURE Add_Error (CallingFunction in VARCHAR2, SetErrorText in VARCHAR2) is
begin 
  -- Just watch for value errors 
  ERROR_ENCOUNTERED  := TRUE;
  ERROR_STACK    := CallingFunction||': '||substr(SetErrorText,1,1968);
  Win_API_Debug.DebugLog(99,'Add_Error',ERROR_STACK);
end Add_Error;
```

#### SP-057 - ADD_EXTERNAL_ERRORS

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Collects and consolidates external error messages into a single string buffer for return to the caller. The function harvests messages from the Oracle Forms tool_err error stack when errors are present, or falls back to the current SQL error message (SQLERRM) if the stack is empty. The resulting concatenated string provides a unified error summary that the invoking routine can use for display or logging purposes.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Initialise a local PLS_INTEGER counter and a VARCHAR2(1968) error buffer to hold the consolidated error text.
- Step 2 - Check whether the tool_err error stack contains one or more errors (tool_err.nerrors > 0).
- Step 3 - If errors exist on the stack, iterate from 1 to tool_err.nerrors, appending each error message retrieved via tool_err.message to the buffer, preceded by a newline character (CHR(10)).
- Step 4 - After appending each message, call tool_err.pop to remove the processed error from the stack and advance to the next entry.
- Step 5 - If a VALUE_ERROR exception is raised during concatenation (indicating the buffer capacity of 1,968 characters has been exceeded), exit the loop immediately without further processing.
- Step 6 - If the tool_err stack is empty but SQLERRM is not null, append SQLERRM to the buffer preceded by a newline character as the sole error entry.
- Step 7 - Return the populated error buffer string to the caller.

---
**Decision Points**

DP-001

Condition: tool_err.nerrors > 0

TRUE: Enter the loop and collect error messages from the tool_err stack one by one, appending each to the error buffer.

FALSE: Skip the loop and evaluate whether SQLERRM is available as a fallback error source.

---

DP-002

Condition: VALUE_ERROR exception raised during string concatenation inside the loop

TRUE: The error buffer has reached its maximum capacity (1,968 characters); exit the loop immediately, discarding any remaining tool_err messages.

FALSE: Concatenation succeeds; continue iterating and call tool_err.pop to advance to the next error.

---

DP-003

Condition: SQLERRM is not null (evaluated only when tool_err.nerrors is not > 0)

TRUE: Append SQLERRM preceded by a newline character to the error buffer.

FALSE: No error text is added; the buffer remains empty and an empty/null string is returned.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The tool_err error stack takes precedence over SQLERRM; SQLERRM is only consulted when the tool_err stack contains no errors.
- BR-002 - Each error message appended to the buffer must be preceded by a newline character (CHR(10)) to ensure messages are separated when the buffer is displayed or logged.
- BR-003 - The error buffer is limited to 1,968 characters; if appending a message would exceed this capacity, collection stops immediately and any remaining tool_err messages are silently discarded.
- BR-004 - Each tool_err message must be popped from the stack (tool_err.pop) after it is appended, ensuring the stack is consumed in order and no message is processed more than once.
- BR-005 - The function always returns the accumulated buffer string to the caller, which may be an empty string if neither tool_err errors nor a non-null SQLERRM are present.

---
**Implementation Logic**

```plsql

FUNCTION Add_External_Errors return varchar2 is
  iCounter   pls_integer;
  vcErrBuff  varchar2(1968);
begin 
  if tool_err.nerrors > 0 then 
    for iCounter in 1..tool_err.nerrors LOOP
      begin 
        vcErrBuff := vcErrBuff||chr(10)||tool_err.message;
      exception
        when VALUE_ERROR then 
          exit; /* String exceeds allowable buffer */
      end;
      tool_err.pop;
    end loop;
  elsif SQLERRM is not null then 
    vcErrBuff := chr(10)||SQLERRM; 
  end if;
  return vcErrBuff;
end Add_External_Errors;
```

#### SP-058 - BOOLTOCHAR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

BOOLTOCHAR is a utility function that converts a PL/SQL BOOLEAN value into its VARCHAR2 string equivalent ('TRUE' or 'FALSE'). It is used by GET_ENVIRONMENT_STRING and READ_REGISTRY within D2kwutil.pld to represent boolean results as character strings wherever a text-based output is required.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| ThisBoolean | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input BOOLEAN value (ThisBoolean) passed by the calling routine.
- Step 2 - Evaluate the BOOLEAN value using a conditional check.
- Step 3 - If the value evaluates to TRUE, return the VARCHAR2 string 'TRUE'.
- Step 4 - If the value evaluates to FALSE (or NULL resolves to the ELSE branch), return the VARCHAR2 string 'FALSE'.
- Step 5 - Return the resulting VARCHAR2 string to the caller (GET_ENVIRONMENT_STRING or READ_REGISTRY).

---
**Decision Points**

DP-001

Condition: The input parameter ThisBoolean evaluates to TRUE.

TRUE: The function returns the VARCHAR2 string 'TRUE' to the calling routine.

FALSE: The function returns the VARCHAR2 string 'FALSE' to the calling routine.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must always return a non-null VARCHAR2 string; the only permitted return values are 'TRUE' and 'FALSE'.
- BR-002 - The conversion is deterministic: a BOOLEAN TRUE input always yields 'TRUE' and any non-TRUE BOOLEAN input (FALSE or NULL resolved via the ELSE branch) always yields 'FALSE'.
- BR-003 - The function accepts no parameters other than the single IN BOOLEAN argument and has no database interactions; it is a pure in-memory conversion utility.

---
**Implementation Logic**

```plsql

  
  FUNCTION  BoolToChar(ThisBoolean IN BOOLEAN) return VARCHAR2 is
  begin
  	if ThisBoolean then 
  		RETURN 'TRUE';
  	else
  	    RETURN 'FALSE';
  	end if;
  end BoolToChar;

END;

PACKAGE WIN_API_DIALOG IS

/*-------------------------------------------------------------------------*\
 * WIN_API_DIALOG ->   This package is concerned with Displaying Common
 *      dialogs
 * Contents:
 *    Open_File    -> Open File Dialog
 *    Save_File    -> Save File Dialog
 *    Select_Printer    -> Printer Selection Dialog
 *    Choose_Font       -> Display the Font Selection Dialog
 *    Choose_Color      -> Display the Color Selection Dialog
 * Dependancies:
 *    WIN_API_ENVIRONMENT
 *    WIN_API
 *    WIN_API_DEBUG
\*-------------------------------------------------------------------------*/ 

/*-------------------------------------------------------------------------*\
 * Open_File        -> Displays the standard Open File dialog
 * Arguments: 
 *  Title           -> The Title for the Dialog Box
 *                     (Default -> 'Open File')
 *  StartDirectory  -> Where the dialog should start from
 *                     this should be in the format 'C:\TEMP'
 *                     (Default -> Windows Directory)
 *  FileFilter      ->  Restrict the list of files. The filter string 
 *                      should be in the format:
 *                      '<Description>|<filename>.<Extension>|'
 *                      typically this would be something like
 *                      'All files(*.*)|*.*|' or 'Text files(*.txt)|*.txt|'
 *                      "All Files" is the Default
 *  Modal           ->  Should the dialog be modal with respect to the 
 *                      application? 
 *                      default = TRUE
 *  AdvancedFlags   ->  (See list in WIN_API header) This option allows
 *                      you to change the attributes of the Open File 
 *                      dialog.  Here are some of the Flags that might
 *                      be of interest:
 *                      OFN_HIDEREADONLY  Hides the Read Only check box.
 *                      OFN_NONETWORKBUTTON  Hides the Network Button
 *                      OFN_EXPLORER    Display an Explorer style 
 *                        Dialog rather than the conventional one.
 *                      See your Microsoft docmentation for details on 
 *                      each flag.
 *                      To Set the Advanced_Flags varaible, just add the 
 *                      required flags together.  The default is:
 *                      WIN_API.OFN_PATHMUSTEXIST + WIN_API.OFN_FILEMUSTEXIST +
 *                      WIN_API.OFN_HIDEREADONLY + WIN_API.OFN_NOCHANGEDIR 
 *  RaiseExceptions ->  TRUE of FALSE(Default) If set to true, then if the 
 *                      command is not successful (e.g no filename is  
 *                      returned) then the explicit exception
 *                      NO_DATA_FOUND will be raised.
 *        
 * Returns:
 *  Path and name of the selected file
\*-------------------------------------------------------------------------*/
```

#### SP-059 - CLEAN_ERROR_STACK

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Resets the module-level error state by clearing the error flag and discarding any accumulated error messages. This procedure is called by GET_ENVIRONMENT_STRING and READ_REGISTRY prior to their own processing to ensure no residual error information from a previous operation is carried forward.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Set the module-level boolean variable ERROR_ENCOUNTERED to FALSE, indicating that no error is currently active.
- Step 2 - Set the module-level variable ERROR_STACK to NULL, discarding any previously accumulated error message text.
- Step 3 - Return control to the calling procedure with a clean error state.

---
**Decision Points**

No decision points exist in this procedure. The two assignments execute unconditionally on every invocation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - ERROR_ENCOUNTERED must be reset to FALSE on every invocation, regardless of its prior value, ensuring the calling procedure starts with a clean error flag.
- BR-002 - ERROR_STACK must be set to NULL on every invocation, ensuring no residual error message text from a prior operation is visible to the calling procedure.
- BR-003 - This procedure accepts no input and produces no output parameters; its sole effect is the unconditional reset of the two shared error-state variables.

---
**Implementation Logic**

```plsql

PROCEDURE Clean_Error_Stack is 
begin 
  -- just empty the variables
  ERROR_ENCOUNTERED  := FALSE;
  ERROR_STACK        := NULL;
end Clean_Error_Stack;
```

#### SP-060 - DEBUGLOG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: ADD_ERROR]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: SETDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

DEBUGLOG writes formatted diagnostic messages to either a Windows debug output stream or a flat log file, depending on the active debug mode. It acts as the central logging routine within the D2kwutil library, filtering messages by debug level and pause state before constructing a timestamped, padded log entry and routing it to the appropriate output channel. All callers within D2kwutil (ADD_ERROR, D2KWUTIL.ATTEMPT_DLL_LOAD, GET_ENVIRONMENT_STRING, READ_REGISTRY, REGISTER_FUNCTION_CALL, and SETDEBUG) rely on this procedure to emit runtime diagnostic information without disrupting normal form execution.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugLevel | PLS_INTEGER | IN |
| LoggingCall | VARCHAR2 | IN |
| LogString | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- SETDEBUG ([SP-064](#SP-064--SETDEBUG)) - matched by member name
- WEBUTIL.LENGTH ([SP-041](#SP-041--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)
- WINDEBUG ([SP-069](#SP-069--WINDEBUG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate the global debug state (iDebugState): if it equals 0 (disabled), exit immediately with no action.
- Step 2 - Evaluate the global pause flag (bDebugPaused): if TRUE, exit immediately with no action.
- Step 3 - Compare the incoming DebugLevel against the active threshold (iDebugLevel): if DebugLevel exceeds the threshold, exit immediately with no action.
- Step 4 - If the timestamp flag (bDebugTimeStamp) is TRUE, format the current system time as HH24:MI:SS and append a '> ' separator to vcDateStamp.
- Step 5 - Construct vcDebugString by concatenating the zero-padded DebugLevel (2 digits), the optional timestamp, and the LoggingCall padded to 30 characters.
- Step 6 - Append the LogString, truncated so that the total length of vcDebugString does not exceed 2,000 characters.
- Step 7 - If iDebugState = 2 (Windows debugger mode), check the boolean constant DEBUG_API_ENABLED.
  - Step 7a - If DEBUG_API_ENABLED is TRUE, call WINDEBUG (win_api_debug.WinDebug) with the constructed string.
  - Step 7b - If DEBUG_API_ENABLED is FALSE, call SETDEBUG to switch the session to file-logging mode (mode 1) targeting the configured log file (defaulting to 'd2kwutil.log'), log a warning message via recursive calls to DEBUGLOG, and set the bDebugType2Required flag to TRUE to signal that a switch back to debugger mode should be attempted later.
- Step 8 - If iDebugState is not 2 (file-logging mode), check whether bDebugType2Required is TRUE and DEBUG_API_ENABLED is now TRUE (i.e., the Windows debug API has become available again).
  - Step 8a - If both conditions are met, call SETDEBUG to restore debugger mode (mode 2), log a restoration message via recursive calls to DEBUGLOG, reset bDebugType2Required to FALSE, and re-emit the original message.
  - Step 8b - Otherwise, open the log file in append mode using TEXT_IO.FOPEN, write vcDebugString with TEXT_IO.PUT_LINE, and close the file with TEXT_IO.FCLOSE.
- Step 9 - If any unhandled exception occurs during the above steps, suppress it silently by setting iDebugState to 0, disabling further debug logging for the session.

---
**Decision Points**

DP-001
Condition: iDebugState = 0
TRUE: Procedure exits immediately; no logging is performed.
FALSE: Processing continues to DP-002.

DP-002
Condition: bDebugPaused is TRUE
TRUE: Procedure exits immediately; no logging is performed.
FALSE: Processing continues to DP-003.

DP-003
Condition: DebugLevel > iDebugLevel
TRUE: Procedure exits immediately; the message is below the active verbosity threshold and is suppressed.
FALSE: Processing continues; the message qualifies for output.

DP-004
Condition: bDebugTimeStamp is TRUE
TRUE: The current system time (HH24:MI:SS) is prepended to the log entry.
FALSE: No timestamp is included in the log entry.

DP-005
Condition: iDebugState = 2 (Windows debugger output mode)
TRUE: Attempt to route the message to the Windows debug stream via WINDEBUG; proceed to DP-006.
FALSE: Route the message to the file-logging path; proceed to DP-007.

DP-006
Condition: DEBUG_API_ENABLED is TRUE (Windows debug API is available)
TRUE: Call WINDEBUG (win_api_debug.WinDebug) with the formatted string; logging is complete.
FALSE: Call SETDEBUG to downgrade the session to file-logging mode (mode 1), emit a warning via recursive DEBUGLOG calls, re-emit the original message, and set bDebugType2Required to TRUE.

DP-007
Condition: bDebugType2Required is TRUE AND DEBUG_API_ENABLED is TRUE
TRUE: Call SETDEBUG to restore debugger mode (mode 2), emit a restoration notice via recursive DEBUGLOG calls, reset bDebugType2Required to FALSE, and re-emit the original message through the restored channel.
FALSE: Open the configured log file in append mode, write the formatted string, and close the file.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Logging is entirely suppressed when iDebugState equals 0; no output is produced and no exception is raised.
- BR-002 - Logging is entirely suppressed when the session is in a paused state (bDebugPaused = TRUE), allowing temporary suspension of output without disabling the debug subsystem.
- BR-003 - A message is only written if its DebugLevel does not exceed the configured threshold (iDebugLevel); higher-numbered levels represent greater verbosity and are filtered out when the threshold is set lower.
- BR-004 - The formatted log entry must not exceed 2,000 characters; LogString is truncated to enforce this limit.
- BR-005 - The log entry format is fixed: a zero-padded two-digit severity level, an optional HH24:MI:SS timestamp, and the calling routine name padded to 30 characters, followed by the message text.
- BR-006 - When operating in Windows debugger mode (iDebugState = 2) and the debug API is unavailable, the system automatically falls back to file logging via SETDEBUG rather than silently losing the message or raising an error.
- BR-007 - Once the Windows debug API becomes available again after a fallback, the system automatically restores debugger-mode output via SETDEBUG, ensuring that file logging is used only for the period during which the API was unavailable.
- BR-008 - File logging always operates in append mode; existing log file content is preserved across invocations.
- BR-009 - Any unhandled runtime exception within DEBUGLOG is silently swallowed and iDebugState is set to 0, ensuring that a failure in the diagnostic subsystem cannot propagate to and disrupt the calling business logic.

---
**Implementation Logic**

```plsql
   
PROCEDURE DebugLog (DebugLevel  IN PLS_INTEGER, 
                    LoggingCall IN VARCHAR2, 
                    LogString   IN VARCHAR2) is
 vcDateStamp   VARCHAR2(10);
 vcDebugString VARCHAR2(2000);
 hFile         TEXT_IO.FILE_TYPE;
begin
  if iDebugState = 0 then 
  	NULL;
  elsif bDebugPaused then 
  	NULL;
  elsif DebugLevel > iDebugLevel then 
  	NULL;
  else
  	-- Sort out the Datestamp	
  	if bDebugTimeStamp then 
  		vcDateStamp := to_char(SYSDATE,'HH24:MI:SS')||'> ';
  	end if;
  
  	-- Construct the final String
  	vcDebugString := '<'||lpad(to_char(DebugLevel),2,0)||'> '||vcDateStamp||rpad(LoggingCall||':',30);
    vcDebugString := vcDebugString||substr(LogString,1,(2000-length(vcDebugString)));
  
  	if iDebugState = 2 then
  		if DEBUG_API_ENABLED then 
  	   		win_api_debug.WinDebug(vcDebugString);
  		else
  			-- Can't use API calls if the API functions aren't there
	  		-- So Switch to File Logging to d2kwut$.log
	  		SetDebug(1,nvl(vcDebugFile,'d2kwutil.log'),iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Unable to Log to Debugger Switching to File');
			DebugLog(DebugLevel,LoggingCall,LogString);	  		
	  		bDebugType2Required := TRUE;
	  	end if;
  	else
     	if bDebugType2Required and DEBUG_API_ENABLED then
	     	-- API now Available - Reinstate Debugging to Debugger
	  		SetDebug(2,vcDebugFile,iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Restoring Logging to Debugger');
	  		bDebugType2Required := FALSE;
	  		DebugLog(Debuglevel,LoggingCall,LogString);
	
	  	else
		 	hFile := TEXT_IO.FOPEN(vcDebugFile,'A');
		 	TEXT_IO.PUT_LINE(hFile,vcDebugString);
		 	TEXT_IO.FCLOSE(hFile);
		end if;
  	end if;
  end if;
 exception
  	-- Don't let the debugging cause Problems of it's own
  	when others then 
  		iDebugState := 0;
 end DebugLog;
```

#### SP-061 - GET_ENVIRONMENT_STRING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value of a named operating-system environment variable by delegating to the D2KWUTIL native library call D2KWUTIL_GETDOSENV. The function returns the resolved variable value as a VARCHAR2 string, or NULL (optionally raising an exception) when the variable cannot be resolved or the underlying Win API is unavailable. It is invoked by WEBUTIL.GETVAR to expose environment-variable lookup to Oracle Forms at runtime.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VariableName | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-056](#SP-056--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-057](#SP-057--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-058](#SP-058--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-059](#SP-059--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_GETDOSENV ([SP-005](#SP-005--D2KWUTIL.D2KWUTIL_GETDOSENV)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-060](#SP-060--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-063](#SP-063--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log entry diagnostics: call DEBUGLOG (via Win_api_debug.DebugLog) at verbosity level 99, recording the input VariableName and the RaiseExceptions flag (converted to a character representation via BOOLTOCHAR).
- Step 2 - Initialise the error stack: call CLEAN_ERROR_STACK to clear any previously recorded API errors before processing begins.
- Step 3 - Initialise the return-code variable iRC to 0.
- Step 4 - Check API availability: evaluate WIN_API.API_ENABLED to determine whether the native Win API layer is accessible.
- Step 5 - Register the native function: if the API is available, call REGISTER_FUNCTION_CALL to register the iGetDOSEnv handle, binding it to the 'd2kwutil_GetDOSEnv' entry point with the signature 'LONG','*CHAR,*CHAR,LONG'.
- Step 6 - Prepare call buffers: wrap VariableName in percent signs (e.g. '%VAR_NAME%') to form vcBuff1; initialise vcBuff2 as a 512-character null-padded output buffer; set iBuff1 to 512 as the buffer length.
- Step 7 - Invoke the native environment lookup: call D2KWUTIL.D2KWUTIL_GETDOSENV, passing the function handle, the wrapped variable name, the output buffer, and the buffer length; capture the integer return code in iRC.
- Step 8 - Log the result: call DEBUGLOG again at level 99 to record the returned value length (iRC) and the content of vcBuff2.
- Step 9 - Evaluate the lookup outcome: if iRC equals 0 or vcBuff2 still equals the input pattern vcBuff1 (indicating no substitution occurred), the variable was not found; call ADD_ERROR to record a descriptive error message, then either raise NO_DATA_FOUND (if RaiseExceptions is TRUE) or return NULL.
- Step 10 - Return the resolved value: if the lookup succeeded, return vcBuff2 containing the environment variable's value.
- Step 11 - Exception handling: re-raise NO_DATA_FOUND as-is; for WIN_API.NOT_AVAILABLE, call ADD_ERROR with the NoAPI message and re-raise; for all other exceptions, call ADD_ERROR with the generic error descriptor concatenated with ADD_EXTERNAL_ERRORS output, then re-raise.

---
**Decision Points**

DP-001

Condition: WIN_API.API_ENABLED is TRUE.

TRUE: Register the native function handle via REGISTER_FUNCTION_CALL, prepare the call buffers, invoke D2KWUTIL.D2KWUTIL_GETDOSENV, and proceed to evaluate the result.

FALSE: Raise the WIN_API.NOT_AVAILABLE exception, which is caught in the exception block, logged via ADD_ERROR, and re-raised to the caller.

---

DP-002

Condition: iRC equals 0 OR vcBuff2 equals the wrapped input pattern vcBuff1 (i.e. the environment variable was not resolved).

TRUE: Log the failure via ADD_ERROR; then branch on DP-003 to determine whether to raise an exception or return NULL.

FALSE: Return vcBuff2 as the successfully resolved environment variable value.

---

DP-003

Condition: RaiseExceptions input parameter is TRUE (evaluated only when DP-002 is TRUE).

TRUE: Raise NO_DATA_FOUND so the caller can handle the unresolved variable as an exception.

FALSE: Return NULL silently, allowing the caller to handle the absence of a value without an exception.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function may only execute the environment variable lookup when the Win API layer is active (WIN_API.API_ENABLED = TRUE); if the API is unavailable, execution must be aborted and the WIN_API.NOT_AVAILABLE exception propagated to the caller.
- BR-002 - The environment variable name must be wrapped in percent signs before being passed to D2KWUTIL.D2KWUTIL_GETDOSENV (e.g. '%VARIABLE_NAME%'), conforming to the DOS/Windows environment variable substitution convention.
- BR-003 - A return code of 0 from D2KWUTIL.D2KWUTIL_GETDOSENV, or an output buffer that is identical to the wrapped input pattern, is treated as a failed lookup; the variable is considered not found in both cases.
- BR-004 - When a variable is not found, an error must always be recorded via ADD_ERROR regardless of the RaiseExceptions setting; the RaiseExceptions flag controls only whether an exception is raised or NULL is returned, not whether the error is logged.
- BR-005 - The output buffer is fixed at 512 characters; environment variable values longer than 512 characters cannot be retrieved by this function.
- BR-006 - All exceptions other than NO_DATA_FOUND and WIN_API.NOT_AVAILABLE must be enriched with external error detail via ADD_EXTERNAL_ERRORS before being re-raised, ensuring that lower-level diagnostic information is preserved for the caller.
- BR-007 - Entry and result diagnostics must be written via DEBUGLOG at verbosity level 99 on every invocation, capturing the input arguments and the resolved value length and content.

---
**Implementation Logic**

```plsql

FUNCTION Get_Environment_string (  VariableName      IN  VARCHAR2,
                                   RaiseExceptions   IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  vcBuff2    VARCHAR2(512);
  iBuff1    PLS_INTEGER;
  iRC        PLS_INTEGER;
begin 
  Win_api_debug.DebugLog(99,'Get_Environment_String','Args: VariableName="'||VariableName||'", RaiseExceptions='||win_api_debug.BoolToChar(RaiseExceptions));
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then
    win_api.Register_function_call(iGetDOSEnv,'d2kwutil_GetDOSEnv','LONG','*CHAR,*CHAR,LONG');
    vcBuff1    := '%'||VariableName||'%';
    vcBuff2    := RPAD(' ',512,CHR(0));
    iBuff1    := 512;
    iRC   := d2kwutil_GetDOSEnv(win_api.FunctionHandle(iGetDOSEnv),vcBuff1,vcBuff2,iBuff1);
    Win_api_debug.DebugLog(99,'Get_Environment_String','Result: Value Length='||to_char(iRC)||', Value='||vcBuff2);
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0  or vcBuff2 = vcBuff1 then 
    Win_API.Add_error('Get_Environment_String','Unable to get the value of the variable '||VariableName);
    if RaiseExceptions then
      raise NO_DATA_FOUND;
    else
      return NULL;
    end if;
  else
    return vcBuff2;
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Environment_String',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Environment_String',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Environment_String;
```

#### SP-062 - READ_REGISTRY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

READ_REGISTRY retrieves a named value from the Windows registry for a given registry path and entry key. It translates a human-readable root hive name (e.g., HKEY_LOCAL_MACHINE) into the numeric constant expected by the underlying D2KWUTIL native call, invokes D2KWUTIL.D2KWUTIL_GETREGKEY to perform the low-level read, and returns the retrieved string value to the caller. The procedure supports an optional exception-raising mode, allowing callers to choose between silent NULL returns and hard exceptions on failure. It is invoked indirectly through WEBUTIL.GETVAR to expose registry values to the Oracle Forms runtime environment.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RegPath | VARCHAR2 | IN |
| RegEntry | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-056](#SP-056--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-057](#SP-057--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-058](#SP-058--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-059](#SP-059--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_GETREGKEY ([SP-006](#SP-006--D2KWUTIL.D2KWUTIL_GETREGKEY)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-060](#SP-060--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-063](#SP-063--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log entry diagnostics by calling DEBUGLOG with the supplied RegPath, RegEntry, and RaiseExceptions arguments (converted to character via BOOLTOCHAR) at debug level 99.
- Step 2 - Reset the error stack by calling CLEAN_ERROR_STACK to ensure no residual errors from prior calls affect this execution.
- Step 3 - Check whether the WIN_API layer is available (WIN_API.API_ENABLED). If not available, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 4 - Register the native function handle for D2KWUTIL_GETREGKEY by calling REGISTER_FUNCTION_CALL with the function signature descriptor, binding the call to the iGetRegKey handle.
- Step 5 - Parse the registry root hive from the leading segment of RegPath (the portion before the first backslash, uppercased) and map it to its corresponding numeric constant: HKEY_LOCAL_MACHINE=0, HKEY_CLASSES_ROOT=1, HKEY_CURRENT_USER=2, HKEY_USERS=3, HKEY_CURRENT_CONFIG=4. If the root hive is unrecognised, record an error via ADD_ERROR and, if RaiseExceptions is TRUE, raise NO_DATA_FOUND.
- Step 6 - Prepare call buffers: extract the subpath (everything after the first backslash) into vcBuff1, assign RegEntry to vcBuff2, initialise the 2000-byte output buffer vcBuff3 padded with CHR(0), and set the buffer length constant iBuff2 to 2000.
- Step 7 - Determine the registry value expansion flag (iBuff3): if WIN_API.COMPAT_EXPAND_REG_VALUES is FALSE, set iBuff3=1 to suppress environment-string expansion and log a compatibility note via DEBUGLOG; otherwise set iBuff3=0 to allow expansion.
- Step 8 - Invoke D2KWUTIL.D2KWUTIL_GETREGKEY with the registered function handle, the numeric root constant, the subpath, the entry name, the output buffer, the buffer length, and the expansion flag. Capture the integer return code in iRC.
- Step 9 - Log the outcome (iRC and the content of vcBuff3) via DEBUGLOG at debug level 99.
- Step 10 - Evaluate iRC for error conditions: -1 (entry not found), -2 (unsupported data type), -3 (value exceeds buffer length), -4 (environment-string expansion failure). For each error condition, record a descriptive message via ADD_ERROR, then either return NULL or raise the appropriate exception (NO_DATA_FOUND or VALUE_ERROR) depending on the RaiseExceptions flag.
- Step 11 - If iRC indicates success (no negative error code), return vcBuff3 as the registry value string.
- Step 12 - In the exception block, re-raise NO_DATA_FOUND and VALUE_ERROR transparently; for WIN_API.NOT_AVAILABLE, record the no-API message via ADD_ERROR then re-raise; for all other exceptions, record a generic error message incorporating ADD_EXTERNAL_ERRORS output via ADD_ERROR then re-raise.

---
**Decision Points**

DP-001
Condition: WIN_API.API_ENABLED is TRUE.
TRUE: Proceed with function registration, root-hive parsing, buffer preparation, and the D2KWUTIL_GETREGKEY call.
FALSE: Raise WIN_API.NOT_AVAILABLE immediately; no registry access is attempted.

DP-002
Condition: The uppercased root segment of RegPath matches one of the five supported hive names (HKEY_LOCAL_MACHINE, HKEY_CLASSES_ROOT, HKEY_CURRENT_USER, HKEY_USERS, HKEY_CURRENT_CONFIG).
TRUE: Assign the corresponding numeric constant (0-4) to iBuff1 and continue processing.
FALSE: Call ADD_ERROR to record an invalid registry key message; if RaiseExceptions is TRUE raise NO_DATA_FOUND, otherwise allow execution to continue (though subsequent behaviour is undefined as iBuff1 remains uninitialised).

DP-003
Condition: WIN_API.COMPAT_EXPAND_REG_VALUES is FALSE.
TRUE: Set iBuff3=1 to suppress environment-string expansion in the native call, and log a compatibility suppression note via DEBUGLOG.
FALSE: Set iBuff3=0 to permit environment-string expansion.

DP-004
Condition: iRC returned by D2KWUTIL_GETREGKEY equals -1 (registry entry not found).
TRUE: Call ADD_ERROR with a 'Cannot read entry' message; if RaiseExceptions is FALSE return NULL, otherwise raise NO_DATA_FOUND.
FALSE: Proceed to evaluate further return codes.

DP-005
Condition: iRC equals -2 (unsupported registry data type).
TRUE: Call ADD_ERROR with an 'unsupported datatype' message; if RaiseExceptions is FALSE return NULL, otherwise raise NO_DATA_FOUND.
FALSE: Proceed to evaluate further return codes.

DP-006
Condition: iRC equals -3 (registry value exceeds the 2000-byte buffer).
TRUE: Call ADD_ERROR with a buffer-overflow message; if RaiseExceptions is FALSE return NULL, otherwise raise VALUE_ERROR.
FALSE: Proceed to evaluate further return codes.

DP-007
Condition: iRC equals -4 (environment-string expansion failure).
TRUE: Call ADD_ERROR with a 'Failed to expand environment string' message; if RaiseExceptions is FALSE return NULL, otherwise raise NO_DATA_FOUND.
FALSE: No error condition detected; return vcBuff3 to the caller.

DP-008
Condition: RaiseExceptions is TRUE (evaluated within each error-code branch DP-004 through DP-007 and in the invalid-root branch DP-002).
TRUE: Raise the appropriate exception (NO_DATA_FOUND or VALUE_ERROR) rather than returning NULL.
FALSE: Return NULL silently, allowing the caller to handle the absence of a value without an exception.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The registry root hive must be one of exactly five recognised values: HKEY_LOCAL_MACHINE, HKEY_CLASSES_ROOT, HKEY_CURRENT_USER, HKEY_USERS, or HKEY_CURRENT_CONFIG. Any other root segment is treated as invalid and triggers an error.
- BR-002 - The WIN_API layer must be enabled (WIN_API.API_ENABLED) before any registry access is attempted. If the API is unavailable, the procedure must not attempt a registry read and must raise WIN_API.NOT_AVAILABLE.
- BR-003 - The output buffer for the registry value is fixed at 2000 bytes. Registry values longer than this limit are rejected with an error (iRC=-3); the caller receives either NULL or a VALUE_ERROR exception.
- BR-004 - Environment-string expansion within registry values is controlled by the WIN_API.COMPAT_EXPAND_REG_VALUES compatibility flag. When this flag is FALSE, expansion is suppressed to maintain backward compatibility.
- BR-005 - Error handling behaviour is caller-configurable via the RaiseExceptions parameter (default FALSE). When FALSE, all recoverable error conditions return NULL; when TRUE, the same conditions raise exceptions, enabling callers that require strict failure propagation.
- BR-006 - All error conditions must be recorded via ADD_ERROR before either returning NULL or raising an exception, ensuring the error stack is populated for upstream diagnostic use regardless of the RaiseExceptions setting.
- BR-007 - Unhandled exceptions are enriched with external error detail retrieved via ADD_EXTERNAL_ERRORS before being re-raised, ensuring complete error context is preserved on the error stack.
- BR-008 - Entry and exit diagnostics must be written to the debug log via DEBUGLOG at level 99, capturing input arguments (with the boolean RaiseExceptions rendered as a character via BOOLTOCHAR) and the native call result code and returned value.

---
**Implementation Logic**

```plsql

FUNCTION Read_Registry (RegPath         IN  VARCHAR2,
                        RegEntry        IN  VARCHAR2, 
                        RaiseExceptions IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  vcBuff2    VARCHAR2(512);
  vcBuff3    VARCHAR2(2000);
  vcBuff4    VARCHAR2(512);
  vcBuff5    VARCHAR2(512);                        
  vcRoot     VARCHAR2(20);
  iBuff1     PLS_INTEGER;
  iBuff2     PLS_INTEGER;
  iBuff3		 PLS_INTEGER;
  iRC        PLS_INTEGER;
begin
  Win_API_Debug.DebugLog(99,'Read_Registry','Args: RegPath="'||RegPath||'", RegEntry="'||RegEntry||'", RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	  
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then 
    win_api.Register_function_call(iGetRegKey,'d2kwutil_GetRegKey','INT','INT,*CHAR,*CHAR,*CHAR,INT,INT');  
    -- Which Root?
    vcRoot  := upper(substr(RegPath,1,instr(RegPath,'\')-1));
    if      vcRoot =  'HKEY_LOCAL_MACHINE' then 
      iBuff1 := 0;
    elsif   vcRoot =  'HKEY_CLASSES_ROOT' then 
      iBuff1 := 1;
    elsif   vcRoot =  'HKEY_CURRENT_USER' then 
      iBuff1 := 2;
    elsif   vcRoot =  'HKEY_USERS' then
      iBuff1 := 3;
    elsif   vcRoot =  'HKEY_CURRENT_CONFIG' then
      iBuff1 := 4;      
    else
      WIN_API.Add_error('Read_Registry','Invalid Registry Key '||RegPath);
      if  RaiseExceptions then
        raise NO_DATA_FOUND;
      end if;  
    end if;

    iBuff2     := 2000; /* Length of buffer */
    vcBuff1    := substr(RegPath,instr(RegPath,'\')+1);
    vcBuff2    := RegEntry;
    vcBuff3    := RPAD(SUBSTR(NVL(vcBuff3,' '),1,2000),2000,CHR(0));
    if not WIN_API.COMPAT_EXPAND_REG_VALUES then 
    	iBuff3 := 1;
    	Win_API_Debug.DebugLog(99,'Read_Registry','Compatibility: Reg Value expansion supressed');	  
    else
    	iBuff3 := 0;
    end if;
    
    iRC        := d2kwutil_GetRegKey(win_api.FunctionHandle(iGetRegKey),iBuff1,vcBuff1,vcBuff2,vcBuff3,iBuff2,iBuff3);
    Win_API_Debug.DebugLog(99,'Read_Registry','Result:  RC='||to_char(iRC)||', vcBuff3="'||vcBuff3||'"');	      
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = -1  then 
    Win_API.Add_error('Read_Registry','Cannot read  entry '||RegPath||'->'||RegEntry);
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;
  elsif iRC = -2 then
    Win_API.Add_error('Read_Registry', RegPath||'->'||RegEntry||' is an unsupported datatype');
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;
  elsif iRC = -3 then
    Win_API.Add_error('Read_Registry',RegPath||'->'||RegEntry||' is longer than '||to_char(iBuff2)||' Bytes');
    if not RaiseExceptions then
      return NULL;
    else 
      raise VALUE_ERROR;
    end if;
  elsif iRC = -4 then
    Win_API.Add_error('Read_Registry', RegPath||'->'||RegEntry||' Failed to expand environment string');
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;    
  end if;
  return vcBuff3;
exception
  when NO_DATA_FOUND then 
    raise;
  when VALUE_ERROR then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Read_Registry',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Read_Registry',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Read_Registry;
```

#### SP-063 - REGISTER_FUNCTION_CALL

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

REGISTER_FUNCTION_CALL ensures that a named DLL function is correctly registered with the ORA_FFI foreign-function interface before it is called by the application. It verifies that the target DLL is loaded, registers the function handle along with its parameter types and return type, and caches a load-count stamp to avoid redundant re-registration. If the DLL is unavailable or FFI registration fails, the procedure disables the API and raises NO_DATA_FOUND to prevent unsafe calls.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| FunctionID | PLS_INTEGER | IN |
| FunctionName | VARCHAR2 | IN |
| FunctionReturn | VARCHAR2 | IN |
| FunctionArgs | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-056](#SP-056--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-057](#SP-057--ADD_EXTERNAL_ERRORS)) - matched by member name
- D2KWUTIL.ATTEMPT_DLL_LOAD ([SP-003](#SP-003--D2KWUTIL.ATTEMPT_DLL_LOAD)) - D2KWUTIL.pck (or .pld)
- D2KWUTIL.TRANSLATETYPE ([SP-007](#SP-007--D2KWUTIL.TRANSLATETYPE)) - D2KWUTIL.pck (or .pld)
- DEBUGLOG ([SP-060](#SP-060--DEBUGLOG)) - matched by member name
- WEBUTIL.LENGTH ([SP-041](#SP-041--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)
- WEBUTIL.REGISTER_FUNCTION ([SP-048](#SP-048--WEBUTIL.REGISTER_FUNCTION)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Attempt to locate the DLL in the ORA_FFI library cache using ORA_FFI.FIND_LIBRARY against the package-level DLL_NAME constant.
- Step 2 - If FIND_LIBRARY raises an FFI error (DLL not yet loaded), invoke D2KWUTIL.ATTEMPT_DLL_LOAD with DLL_Path and DLL_NAME to load the library and obtain a handle.
- Step 3 - If ATTEMPT_DLL_LOAD also fails with an FFI error, set API_ENABLED to FALSE, call ADD_ERROR to record a 'DLL not found' message, and raise NO_DATA_FOUND to abort processing.
- Step 4 - Check whether the function has previously been registered by testing whether FunctionLoad array contains an entry for FunctionID and whether that entry matches the current DLL_LOAD_COUNT.
- Step 5 - If registration is required (entry absent or load-count mismatch), register the function handle by calling ORA_FFI.REGISTER_FUNCTION against the DLL handle, using FunctionName and the C_STD calling convention.
- Step 6 - If the function being registered is not 'd2kwutil_DebugString', call DEBUGLOG (via Win_API_Debug.DebugLog at level 99) to record either an initial registration or a re-registration event, including the DLL load count and, on re-registration, the prior load-count value.
- Step 7 - Parse the FunctionArgs string by appending a trailing comma and iterating: extract each comma-delimited type fragment, call D2KWUTIL.TRANSLATETYPE to convert the type token to its ORA_FFI constant, and register each parameter via ORA_FFI.REGISTER_PARAMETER. Continue until the argument string is exhausted or equals 'VOID'.
- Step 8 - If FunctionReturn is neither 'VOID' nor NULL, call D2KWUTIL.TRANSLATETYPE on the return-type token and register it via ORA_FFI.REGISTER_RETURN.
- Step 9 - Store the current DLL_LOAD_COUNT in FunctionLoad(FunctionID) to cache the registration state and prevent unnecessary re-registration on subsequent calls.
- Step 10 - If an FFI error is raised at any point during registration, call ADD_ERROR with the function name and the concatenated error detail from WEBUTIL.LENGTH (UError) and ADD_EXTERNAL_ERRORS, then raise NO_DATA_FOUND.

---
**Decision Points**

DP-001

Condition: ORA_FFI.FIND_LIBRARY succeeds in locating the DLL in the current session cache.

TRUE: DLL_HANDLE is assigned; processing continues to the registration check (DP-002).

FALSE: An FFI error is raised; flow transfers to DP-002-alt (ATTEMPT_DLL_LOAD).

---

DP-002

Condition: D2KWUTIL.ATTEMPT_DLL_LOAD successfully loads the DLL when FIND_LIBRARY failed.

TRUE: DLL_HANDLE is assigned from the load attempt; processing continues to the registration check.

FALSE: A second FFI error is raised; API_ENABLED is set to FALSE, ADD_ERROR records the failure, and NO_DATA_FOUND is raised to terminate the procedure.

---

DP-003

Condition: FunctionLoad array does not contain an entry for FunctionID, OR the stored load-count for FunctionID does not equal the current DLL_LOAD_COUNT.

TRUE: Full registration (function handle, parameters, return type) is performed and the load-count cache is updated.

FALSE: The function is already registered for the current DLL load cycle; no registration work is performed and the procedure exits normally.

---

DP-004

Condition: The FunctionName being registered is not equal to 'd2kwutil_DebugString'.

TRUE: DEBUGLOG is called to record the registration event (initial or re-registration) with function name and DLL load count.

FALSE: Debug logging is suppressed to avoid infinite recursion when registering the debug string function itself.

---

DP-005

Condition: During parameter parsing, the remaining FunctionArgs string is non-null, not equal to a bare comma, and not equal to 'VOID,'.

TRUE: The next comma-delimited type fragment is extracted, translated via D2KWUTIL.TRANSLATETYPE, and registered as a parameter; the loop continues.

FALSE: The argument list is exhausted or is VOID; the parameter registration loop exits.

---

DP-006

Condition: FunctionReturn is not 'VOID' (case-insensitive) and is not NULL.

TRUE: D2KWUTIL.TRANSLATETYPE is called on the return type token and ORA_FFI.REGISTER_RETURN is invoked to register the function's return type.

FALSE: No return type is registered (procedure is void or return type is unspecified).

---

DP-007

Condition: An ORA_FFI.FFI_ERROR is raised during the registration block (Steps 5-9).

TRUE: ADD_ERROR is called with the function name and combined error detail from ADD_EXTERNAL_ERRORS; NO_DATA_FOUND is raised to abort the caller.

FALSE: Registration completes without error; the procedure exits normally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The DLL must be locatable via ORA_FFI.FIND_LIBRARY or loadable via D2KWUTIL.ATTEMPT_DLL_LOAD before any function registration is attempted; if neither succeeds, the API is disabled and no further FFI calls may proceed.
- BR-002 - API_ENABLED must be set to FALSE whenever the DLL cannot be loaded, ensuring callers can detect and respect the unavailability of the native library.
- BR-003 - A function is re-registered only when its FunctionID is absent from the FunctionLoad cache or when the cached DLL load-count differs from the current DLL_LOAD_COUNT, preventing unnecessary FFI overhead while guaranteeing correctness after a DLL reload.
- BR-004 - Debug logging via DEBUGLOG must be suppressed when registering the 'd2kwutil_DebugString' function to prevent recursive invocation of the logging mechanism during its own registration.
- BR-005 - All parameter type tokens in FunctionArgs must be translated through D2KWUTIL.TRANSLATETYPE before being passed to ORA_FFI.REGISTER_PARAMETER, ensuring consistent type mapping between the PL/SQL layer and the native DLL interface.
- BR-006 - A return type must be registered via ORA_FFI.REGISTER_RETURN only when FunctionReturn is non-null and not 'VOID'; void functions must not have a return type registered.
- BR-007 - On any FFI error during registration, ADD_ERROR must be called with the offending function name and the full external error detail sourced from ADD_EXTERNAL_ERRORS, and NO_DATA_FOUND must be raised to signal failure to the invoking procedure.

---
**Implementation Logic**

```plsql

PROCEDURE Register_Function_Call ( FunctionID     in PLS_INTEGER, 
                                   FunctionName   in VARCHAR2,
                                   FunctionReturn in VARCHAR2, 
                                   FunctionArgs   in VARCHAR2) is
  vcArgs  VARCHAR2(200);
  vcFrag  VARCHAR2(10);
  iOffset PLS_INTEGER;   
begin 
   -- See if the DLL has been loaded at all.
   -- if this call to FIND_LIBRARY fails, we'll fall through to the Exception.
   begin
    DLL_HANDLE := ORA_FFI.find_library(DLL_NAME);
  exception
    when ora_ffi.ffi_error then 
      -- Attempt to load the DLL again in a subblock. If this fails
      -- then the API must be disabled and NOT_DATA_FOUND raised
      begin 
          DLL_HANDLE := Attempt_DLL_Load(DLL_Path, DLL_NAME);
      exception
          when ora_ffi.ffi_error then 
            API_ENABLED := FALSE;
              add_error('D2KWUTIL',DLL_NAME||' not found.');
            RAISE NO_DATA_FOUND;
      end;
  end;

  -- now compare the Cached value for this function's loadcount with 
  -- that for the DLL this tells us that the function has either not 
  -- been registered yet, or that the DLL has been reloaded in between 
  -- times.  This would not be healthy so we have to re-register in that case.
  if (not FunctionLoad.exists(FunctionId)) or (FunctionLoad(FunctionId)<> DLL_LOAD_COUNT) then
    -- We need to go through the registration process.      
    -- Register the function with the DLL
    FunctionHandle(FunctionId) := ora_ffi.register_function(Win_API.DLL_HANDLE,FunctionName,ORA_FFI.C_STD);
    if FunctionName <> 'd2kwutil_DebugString' then 
    	if not FunctionLoad.exists(FunctionId) then 
    		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Initial Reg');
    	else
       		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Re-Registration Count = '||to_char(FunctionLoad(FunctionId)));
       	end if;
    end if;
    
    -- Loop through and register the parameters
    vcArgs := FunctionArgs||',';
    while vcArgs is not null and vcArgs <> ',' and vcArgs <> 'VOID,' LOOP
      iOffset := instr(vcArgs,',');
      vcFrag := substr(vcArgs,1,iOffset-1);
      ora_ffi.register_parameter(FunctionHandle(FunctionId),TranslateType(vcFrag));
      if iOffset = length(vcArgs) then
        vcArgs := NULL;
      else
        vcArgs := substr(vcArgs,iOffset+1);
      end if;
    end LOOP;
    
    -- Register the return type IF this is a function
    if upper(FunctionReturn) <> 'VOID' and FunctionReturn is not NULL then 
      ora_ffi.register_return(FunctionHandle(FunctionId),TranslateType(FunctionReturn));
    end if;
    
    -- Now add this Function's Loadcount to the array to prevent un-nessary re-registration
    FunctionLoad(FunctionId) := DLL_LOAD_COUNT;
  end if;
exception
   when ora_ffi.ffi_error then
    Win_API.Add_error(FunctionName, Win_API.UError||WIN_API.Add_External_errors); 
    raise NO_DATA_FOUND;
end Register_Function_Call;
```

#### SP-064 - SETDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Configures the debug logging state for the application session by accepting a debug type, an optional output file path, a logging level, and a timestamp flag. The procedure stores these settings in package-level variables and activates or deactivates the appropriate logging channel (file-based or message-based), delegating the initial log entry to DEBUGLOG.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugType | PLS_INTEGER | IN |
| DebugFile | VARCHAR2 | IN |
| DebugLevel | PLS_INTEGER | IN |
| TimeStamp | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-060](#SP-060--DEBUGLOG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Store the incoming TimeStamp flag in the package-level variable bDebugTimeStamp.
- Step 2 - Store the incoming DebugFile path in the package-level variable vcDebugFile.
- Step 3 - Store the incoming DebugLevel value in the package-level variable iDebugLevel.
- Step 4 - Evaluate the DebugType parameter to determine which logging mode to activate (see Decision Points).
- Step 5 - If DebugType = 1, set iDebugState to 1 (file logging) and invoke DEBUGLOG to record 'Logging to File' concatenated with the DebugFile value.
- Step 6 - If DebugType = 2, set iDebugState to 2 (message logging) and invoke DEBUGLOG to record 'Logging Started'.
- Step 7 - For any other DebugType value, invoke DEBUGLOG to record 'Logging Stopped' and then set iDebugState to 0, disabling logging.

---
**Decision Points**

DP-001

Condition: DebugType = 1

TRUE: Set iDebugState to 1 (file-based logging mode) and call DEBUGLOG to record that logging to the specified file has begun.

FALSE: Proceed to evaluate DP-002.

DP-002

Condition: DebugType = 2

TRUE: Set iDebugState to 2 (message-based logging mode) and call DEBUGLOG to record that logging has started.

FALSE: Call DEBUGLOG to record that logging has stopped, then set iDebugState to 0, disabling all debug logging.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - DebugType = 1 activates file-based debug logging; the DebugFile parameter must carry a meaningful file path when this mode is selected, as its value is written directly into the opening log entry.
- BR-002 - DebugType = 2 activates message-based debug logging; no file path is required for this mode.
- BR-003 - Any DebugType value other than 1 or 2 is treated as a request to stop logging; iDebugState is set to 0 and a 'Logging Stopped' entry is written via DEBUGLOG before the state is cleared.
- BR-004 - The package-level variables bDebugTimeStamp, vcDebugFile, and iDebugLevel are always updated unconditionally at the start of the procedure, regardless of the DebugType supplied, ensuring session-wide debug configuration is kept consistent.
- BR-005 - DebugLevel defaults to 98 and TimeStamp defaults to FALSE; callers that do not supply these parameters receive standard verbosity with no timestamp decoration.
- BR-006 - All audit entries generated during the configuration change are written through DEBUGLOG at severity level 0, identifying 'SetDebug' as the source context.

---
**Implementation Logic**

```plsql

PROCEDURE SetDebug( DebugType   IN PLS_INTEGER, 
                    DebugFile   IN VARCHAR2 DEFAULT NULL, 
                    DebugLevel  IN PLS_INTEGER DEFAULT 98,                        
                    TimeStamp   IN BOOLEAN DEFAULT FALSE) is
begin 
    bDebugTimeStamp := TimeStamp;
    vcDebugFile     := DebugFile;
    iDebugLevel     := DebugLevel;
	if DebugType = 1 then 
		iDebugState := 1;
		DebugLog(0,'SetDebug','Logging to File '||DebugFile);
	elsif DebugType = 2 then
		iDebugState := 2;
		DebugLog(0,'SetDebug','Logging Started');
	else 
        DebugLog(0,'SetDebug','Logging Stopped');
        iDebugState := 0;
	end if;
end SetDebug;
```

#### SP-065 - SF_GET_CUST_ADDRESS

**Invoked From:**

- vr_cross_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

Search Criteria (N/A / CN_MAIN)

---

**Purpose**

Retrieves and formats the full mailing address for a given customer (p_cust_cd) under a specific principal mapping (p_principal_map_cd). The function inspects the customer's communication indicator to determine whether the office address or the permanent address should be used, then resolves city, county/district, and state descriptions from their respective reference tables before assembling and returning a single formatted address string.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_principal_map_cd | Number | IN |
| p_cust_cd | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Query GM_CIN using p_principal_map_cd and p_cust_cd to retrieve the COMMUNICATION_IND flag that governs which address type to use.
- Step 2 - If COMMUNICATION_IND equals 'O', select the office address fields (OFF_ADDRESS1, OFF_ADDRESS2, OFF_ADDRESS3, OFF_CITY_CD, COUNTY_CD, STATE_CD, OFF_PIN) from GM_CIN for the same principal/customer key.
- Step 3 - If COMMUNICATION_IND is any value other than 'O', select the permanent address fields (PERMANENT_ADDRESS1, PERMANENT_ADDRESS2, PERMANENT_ADDRESS3, CITY_CD, COUNTY_CD, STATE_CD, PPIN) from GM_CIN for the same principal/customer key.
- Step 4 - Build the address string by appending each non-null address line (lv_padrs1, lv_padrs2, lv_padrs3), trimming whitespace and separating lines with a comma-space delimiter.
- Step 5 - Look up the city description from GM_CITY using the resolved city code and p_principal_map_cd; if found, append it to the address string on a new line (CHR(10)). If no matching row exists, suppress the city segment silently.
- Step 6 - Look up the county/district description from GM_CNTY using the resolved county code, state code, and p_principal_map_cd; if found, append it to the address string on a new line. If no matching row exists, suppress the district segment silently.
- Step 7 - Look up the state description from GM_STATE using the resolved state code and p_principal_map_cd; if lv_distt is not null, append the state description to the address string on a new line. If no matching row exists, suppress the state segment silently.
- Step 8 - If the PIN/ZIP code is not null, append it on a new line prefixed with 'Zip:' when p_principal_map_cd = 3, or prefixed with 'Pin:' for all other principal mappings.
- Step 9 - Return the fully assembled address string. If the initial GM_CIN query returns no data, return NULL.

---
**Decision Points**

DP-001

Condition:
COMMUNICATION_IND retrieved from GM_CIN equals 'O'.

TRUE:
Select office address fields (OFF_ADDRESS1, OFF_ADDRESS2, OFF_ADDRESS3, OFF_CITY_CD, COUNTY_CD, STATE_CD, OFF_PIN) from GM_CIN to populate the address variables.

FALSE:
Select permanent address fields (PERMANENT_ADDRESS1, PERMANENT_ADDRESS2, PERMANENT_ADDRESS3, CITY_CD, COUNTY_CD, STATE_CD, PPIN) from GM_CIN to populate the address variables.

---

DP-002

Condition:
Each of lv_padrs1, lv_padrs2, and lv_padrs3 is individually checked for NOT NULL.

TRUE:
The non-null address line is trimmed and appended to the address string; lv_padrs2 and lv_padrs3 are additionally prefixed with ', ' when the string already contains content.

FALSE:
The address line is skipped; no content or delimiter is appended.

---

DP-003

Condition:
A matching row is found in GM_CITY for the resolved city code and p_principal_map_cd, and the returned city description is not null.

TRUE:
Append a newline followed by the trimmed city description to the address string.

FALSE (NO_DATA_FOUND or null value):
Set lv_city to null and omit the city segment from the address string.

---

DP-004

Condition:
A matching row is found in GM_CNTY for the resolved county code, state code, and p_principal_map_cd, and the returned county description is not null.

TRUE:
Append a newline followed by the trimmed county/district description to the address string.

FALSE (NO_DATA_FOUND or null value):
Set lv_distt to null and omit the district segment from the address string.

---

DP-005

Condition:
A matching row is found in GM_STATE for the resolved state code and p_principal_map_cd, and lv_distt is not null at the time of the state append check.

TRUE:
Append a newline followed by the trimmed state description to the address string.

FALSE (NO_DATA_FOUND or lv_distt is null):
Omit the state segment from the address string.

---

DP-006

Condition:
The PIN/ZIP value (lv_pin) is not null.

TRUE:
Append the PIN/ZIP on a new line; evaluate p_principal_map_cd to determine the label (see DP-007).

FALSE:
Omit the PIN/ZIP segment entirely.

---

DP-007

Condition:
p_principal_map_cd equals 3 (evaluated only when lv_pin is not null).

TRUE:
Prefix the PIN value with 'Zip:' before appending to the address string.

FALSE:
Prefix the PIN value with 'Pin:' before appending to the address string.

---
**Database Interactions**

- DB-001 - Read GM_CIN - Reads data from GM_CIN for lookup or validation.
- DB-002 - Read GM_CITY - Reads data from GM_CITY for lookup or validation.
- DB-003 - Read GM_CNTY - Reads data from GM_CNTY for lookup or validation.
- DB-004 - Read GM_STATE - Reads data from GM_STATE for lookup or validation.
**Business Rules**

- BR-001 - The address type to be returned is governed by the COMMUNICATION_IND flag stored in GM_CIN; a value of 'O' mandates use of the office address, while any other value mandates use of the permanent address.
- BR-002 - All address lookups against GM_CIN, GM_CITY, GM_CNTY, and GM_STATE must be scoped to the supplied p_principal_map_cd to support multi-company data segregation.
- BR-003 - Address line segments are concatenated with a comma-space separator (, ) between consecutive lines; city, district, state, and PIN segments are each separated by a newline character (CHR(10)).
- BR-004 - Leading and trailing whitespace must be stripped from every address component before it is appended to the output string.
- BR-005 - If no customer record is found in GM_CIN for the supplied principal/customer key, the function returns NULL rather than raising an error.
- BR-006 - Failure to resolve a city, county/district, or state description (NO_DATA_FOUND) is handled silently; the missing segment is omitted from the formatted address without interrupting processing.
- BR-007 - The postal code label is context-sensitive: principal mapping code 3 uses the label 'Zip:', all other principal mapping codes use the label 'Pin:'.
- BR-008 - The state description is appended only when a district/county description was successfully resolved (lv_distt is not null), ensuring the state segment is not displayed in isolation without its associated district.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
function sf_get_cust_address(p_principal_map_cd Number,
                                               p_cust_cd          varchar2)
/*
  $log$
  */

 return Char is
  lv_adrs   varchar2(5000);
  lv_padrs1 varchar2(100);
  lv_padrs2 varchar2(100);
  lv_padrs3 varchar2(100);
  lv_pcity  varchar2(10);
  lv_pdistt varchar2(10);
  lv_pstate varchar2(10);
  lv_city   varchar2(100);
  lv_distt  varchar2(100);
  lv_state  varchar2(100);
  lv_pin    varchar2(10);
  lv_cumid  gm_cin.COMMUNICATION_IND%type;

begin
  begin
    Select COMMUNICATION_IND
      Into lv_cumid
      From Gm_Cin
     Where principal_map_cd = p_principal_map_cd
       and cust_cd = p_cust_cd;

    If lv_cumid = 'O' Then
      select OFF_ADDRESS1,
             OFF_ADDRESS2,
             OFF_ADDRESS3,
             OFF_CITY_CD,
             county_cd,
             state_cd,
             OFF_PIN
        into lv_padrs1,
             lv_padrs2,
             lv_padrs3,
             lv_pcity,
             lv_pdistt,
             lv_pstate,
             lv_pin
        from gm_cin
       where principal_map_cd = p_principal_map_cd
         and cust_cd = p_cust_cd;
    Else
      select permanent_address1,
             permanent_address2,
             permanent_address3,
             city_cd,
             county_cd,
             state_cd,
             ppin
        into lv_padrs1,
             lv_padrs2,
             lv_padrs3,
             lv_pcity,
             lv_pdistt,
             lv_pstate,
             lv_pin
        from gm_cin
       where principal_map_cd = p_principal_map_cd
         and cust_cd = p_cust_cd;
    End if;

    if lv_padrs1 is not null then
      lv_adrs := lv_adrs || rtrim(ltrim(lv_padrs1));
    end if;

    if lv_padrs2 is not null then
      if lv_adrs is not null then
        lv_adrs := lv_adrs || ', ';
      end if;
      lv_adrs := lv_adrs || rtrim(ltrim(lv_padrs2));
    end if;

    if lv_padrs3 is not null then
      if lv_adrs is not null then
        lv_adrs := lv_adrs || ', ';
      end if;
      lv_adrs := lv_adrs || rtrim(ltrim(lv_padrs3));
    end if;

    begin
      select distinct city_desc
        into lv_city
        from gm_city
       where city_cd = lv_pcity
         and principal_map_cd = p_principal_map_cd; --Added by Rajeev for multi company changes

      if lv_city is not null then
        if lv_adrs is not null then
          lv_adrs := lv_adrs || chr(10);
        end if;
        lv_adrs := lv_adrs || ltrim(rtrim(lv_city));
      end if;
    exception
      when no_data_found then
        lv_city := null;
    end;

    begin
      select distinct county_desc
        into lv_distt
        from gm_cnty
       where county_cd = lv_pdistt
         and state_cd = lv_pstate
         and principal_map_cd = p_principal_map_cd; --Added by Rajeev for multi company changes;

      if lv_distt is not null then
        if lv_adrs is not null then
          lv_adrs := lv_adrs || chr(10);
        end if;
        lv_adrs := lv_adrs || ltrim(rtrim(lv_distt));
      end if;
    exception
      when no_data_found then
        lv_distt := null;
    end;

    begin
      select distinct state_desc
        into lv_state
        from gm_state
       where state_cd = lv_pstate
       and principal_map_cd = p_principal_map_cd; --Added by Rajeev for multi company changes

      if lv_distt is not null then
        if lv_adrs is not null then
          lv_adrs := lv_adrs || chr(10);
        end if;
        lv_adrs := lv_adrs || ltrim(rtrim(lv_state));
      end if;
    exception
      when no_data_found then
        lv_distt := null;
    end;

/*   if lv_pin is not null and p_principal_map_cd=3 then
      if lv_adrs is not null then
        lv_adrs := lv_adrs || chr(10);
      end if;
   lv_adrs := lv_adrs || 'Zip:' || ltrim(rtrim(lv_pin));
   else
   lv_adrs := lv_adrs || 'Pin:' || ltrim(rtrim(lv_pin));
   end if;
*/   if lv_pin is not null then
      if lv_adrs is not null then
        lv_adrs := lv_adrs || chr(10);
      end if;
     if p_principal_map_cd=3 then
       lv_adrs := lv_adrs || 'Zip:' || ltrim(rtrim(lv_pin));
     else
       lv_adrs := lv_adrs || 'Pin:' || ltrim(rtrim(lv_pin));
     end if;
    end if;
  exception
    when no_data_found then
      lv_adrs := null;
  end;

  return(lv_adrs);
end;

```

#### SP-066 - SF_GET_MODEL_DESC

**Invoked From:**

- vr_cross_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

Search Criteria (N/A / CN_MAIN)

---

**Purpose**

Retrieves the model description (MODEL_DESC) from the GM_MOD reference table for a given model code and principal mapping company. The function is used within the Search Criteria screen to resolve a model code into its human-readable description, returning 'Not Found' when no matching record exists.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_MODEL_CD | GM_MOD.MODEL_CD%TYPE | IN |
| p_pmc | NUMBER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the model code (P_MODEL_CD) and the principal mapping company code (p_pmc, defaulting to 1 for single-company environments) as input parameters.
- Step 2 - Query the GM_MOD table, filtering by PRINCIPAL_MAP_CD equal to p_pmc, MODEL_CD equal to P_MODEL_CD, and MODEL_CAT_CD equal to '001' to ensure only the correct model category is considered.
- Step 3 - Store the retrieved MODEL_DESC value in the local variable P_MODEL_DESC.
- Step 4 - Return P_MODEL_DESC to the caller.
- Step 5 - If any exception occurs during the query (e.g., no data found or multiple rows), set P_MODEL_DESC to 'Not Found' and return that value.

---
**Decision Points**

DP-001

Condition:
Does a row exist in GM_MOD where PRINCIPAL_MAP_CD = p_pmc, MODEL_CD = P_MODEL_CD, and MODEL_CAT_CD = '001'?

TRUE:
The matching MODEL_DESC is retrieved and returned to the caller.

FALSE:
An exception is raised (e.g., NO_DATA_FOUND); the WHEN OTHERS handler intercepts it, assigns 'Not Found' to P_MODEL_DESC, and returns that value.

---
**Database Interactions**

- DB-001 - Read GM_MOD - Reads data from GM_MOD for lookup or validation.
**Business Rules**

- BR-001 - The model lookup is restricted to records with MODEL_CAT_CD = '001'; model codes belonging to any other category are not resolved by this function.
- BR-002 - The lookup is scoped to a specific principal mapping company (PRINCIPAL_MAP_CD = p_pmc) to support multi-company environments; p_pmc defaults to 1 when not explicitly supplied.
- BR-003 - If no matching model record is found, or any other runtime error occurs, the function returns the literal string 'Not Found' rather than raising an unhandled exception to the caller.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
FUNCTION SF_GET_MODEL_DESC(P_MODEL_CD GM_MOD.MODEL_CD%TYPE,
                                             p_pmc    NUMBER default 1) ----Added by Rajeev for multi company changes
  RETURN VARCHAR2 AS
  P_MODEL_DESC GM_MOD.MODEL_DESC%TYPE;
BEGIN
  SELECT MODEL_DESC
    INTO P_MODEL_DESC
    FROM GM_MOD
   WHERE PRINCIPAL_MAP_CD = p_pmc ----Added by Rajeev for multi company changes
     AND MODEL_CD = P_MODEL_CD
     AND MODEL_CAT_CD = '001';

  RETURN P_MODEL_DESC;

EXCEPTION
  WHEN OTHERS THEN
    P_MODEL_DESC := 'Not Found';
    RETURN P_MODEL_DESC;
END SF_GET_MODEL_DESC;

```

#### SP-067 - SF_GET_VARIANT_DESC

**Invoked From:**

- vr_cross_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

Search Criteria (N/A / CN_MAIN)

---

**Purpose**

Retrieves the variant description text for a given variant code and principal map company from the GM_VAR reference table. The function is used during cross-variant search operations to resolve a variant code into its human-readable description, supporting multi-company data segregation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_VARIANT_CD | GM_VAR.VARIANT_CD%TYPE | IN |
| p_pmc | NUMBER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the variant code (P_VARIANT_CD) and principal map company code (p_pmc, defaulting to 1) as input parameters.
- Step 2 - Query the GM_VAR table to retrieve the VARIANT_DESC value where the PRINCIPAL_MAP_CD matches p_pmc, the VARIANT_CD matches P_VARIANT_CD, and the MODEL_CAT_CD is fixed at '001'.
- Step 3 - Assign the retrieved description to the local variable P_VARIANT_DESC.
- Step 4 - Return P_VARIANT_DESC to the caller.
- Step 5 - If any exception occurs during the query (e.g., no matching row found), set P_VARIANT_DESC to the literal string 'Not Found' and return it.

---
**Decision Points**

DP-001

Condition:
The SELECT statement against GM_VAR executes successfully and returns a matching VARIANT_DESC for the supplied P_VARIANT_CD, p_pmc, and MODEL_CAT_CD = '001'.

TRUE:
The retrieved VARIANT_DESC is returned to the caller.

FALSE:
The WHEN OTHERS exception handler is triggered; the function returns the literal string 'Not Found' instead of a database value.

---
**Database Interactions**

- DB-001 - Read GM_VAR - Reads data from GM_VAR for lookup or validation.
**Business Rules**

- BR-001 - Variant description lookup is always restricted to MODEL_CAT_CD = '001'; no other model category codes are considered by this function.
- BR-002 - The lookup is scoped to a specific principal map company (PRINCIPAL_MAP_CD = p_pmc) to enforce multi-company data segregation; the parameter defaults to company 1 if not supplied.
- BR-003 - If no matching variant record exists, or if any runtime error occurs, the function returns 'Not Found' rather than raising an exception to the caller, ensuring the invoking form receives a safe, displayable value.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
FUNCTION SF_GET_VARIANT_DESC(P_VARIANT_CD GM_VAR.VARIANT_CD%TYPE,
                                               p_pmc    NUMBER default 1) --Added by Rajeev for multi company changes
  RETURN VARCHAR2 AS
  P_VARIANT_DESC GM_VAR.VARIANT_DESC%TYPE;
BEGIN
  SELECT VARIANT_DESC
    INTO P_VARIANT_DESC
    FROM GM_VAR
   WHERE PRINCIPAL_MAP_CD = p_pmc --Added by Rajeev for multi company changes
     AND VARIANT_CD = P_VARIANT_CD
     AND MODEL_CAT_CD = '001';

  RETURN P_VARIANT_DESC;

EXCEPTION
  WHEN OTHERS THEN
    P_VARIANT_DESC := 'Not Found';
    RETURN P_VARIANT_DESC;
END SF_GET_VARIANT_DESC;

```

#### SP-068 - STRIPDIRSEP

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sanitises a file-system path string supplied by the caller by removing any semicolon-delimited suffix and any trailing backslash directory separator. The cleaned path is returned to the caller (D2KWUTIL.ATTEMPT_DLL_LOAD) so that subsequent DLL-load operations receive a well-formed, unambiguous directory path.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| InPath | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-041](#SP-041--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Copy the IN parameter InPath into a local working variable (vcPath, varchar2(500)) to avoid mutating the original value.
- Step 2 - Search vcPath for the first occurrence of a semicolon (';'). If one is found, truncate vcPath to retain only the characters that precede it, discarding the semicolon and everything after it.
- Step 3 - Inspect the last character of the (possibly already truncated) vcPath. If that character is a backslash ('\'), remove it by taking the substring from position 1 to length minus 1.
- Step 4 - Return the cleaned vcPath value to the caller.

---
**Decision Points**

DP-001

Condition: INSTR(vcPath, ';') > 0 - the path string contains at least one semicolon.

TRUE: vcPath is replaced with the substring from position 1 up to (but not including) the first semicolon, stripping any semicolon-delimited trailing segment.

FALSE: vcPath is left unchanged and processing continues to DP-002.

DP-002

Condition: SUBSTR(vcPath, -1, 1) = '\' - the last character of vcPath is a backslash directory separator.

TRUE: vcPath is replaced with the substring from position 1 to LENGTH(vcPath) - 1, removing the trailing backslash.

FALSE: vcPath is left unchanged and the value is returned as-is.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only the portion of the path before the first semicolon is considered valid; any semicolon and subsequent characters are discarded. This prevents multi-path or environment-variable-style strings from being passed to DLL-load operations.
- BR-002 - A trailing backslash directory separator must be removed from the path before it is returned, ensuring the path string does not end with '\'.
- BR-003 - The two sanitisation rules (BR-001 and BR-002) are applied sequentially; semicolon stripping is performed first, and trailing-backslash removal is applied to the result. Both rules are evaluated on every invocation regardless of whether the preceding rule made a change.
- BR-004 - The function accepts paths up to 500 characters in length, as enforced by the size of the internal working variable vcPath.

---
**Implementation Logic**

```plsql

  

Function StripDirSep ( InPath in varchar2) return varchar2 is 
  vcPath  varchar2(500) := InPath;
begin 
  -- Check and Strip SemiColons, we take everything
  -- Before the first Semicolon as our path
  if instr(vcPath,';') > 0 then
    vcPath := substr(vcPath,1,instr(vcPath,';') -1);
  end if;

  -- Check and Strip '\'
  if substr(vcPath,-1,1) = '\' then 
    vcPath := substr(vcPath,1,length(vcPath)-1);
  end if;

  return vcPath;
end StripDirSep;
```

#### SP-069 - WINDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WINDEBUG provides a controlled interface for writing debug text to an external debug output channel via the D2KWUTIL library. It accepts a text string, appends a newline character, and delegates the output call to D2KWUTIL.D2KWUTIL_DEBUGSTRING through a registered function handle. If the underlying Windows API is unavailable or any other error occurs, the procedure captures and propagates a structured error message before re-raising the exception.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-056](#SP-056--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-057](#SP-057--ADD_EXTERNAL_ERRORS)) - matched by member name
- D2KWUTIL.D2KWUTIL_DEBUGSTRING ([SP-004](#SP-004--D2KWUTIL.D2KWUTIL_DEBUGSTRING)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- REGISTER_FUNCTION_CALL ([SP-063](#SP-063--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameter Text (VARCHAR2) and initialise the local buffer vcBuff1 by appending a newline character (CHR(10)) to Text.
- Step 2 - Check whether the Windows API integration layer is active by evaluating WIN_API.API_ENABLED.
- Step 3 - If the API is enabled, register the debug-string function call by invoking REGISTER_FUNCTION_CALL, passing the internal debug-string handle (iDebugString), the function name 'd2kwutil_DebugString', NULL, and the parameter type marker '*CHAR'.
- Step 4 - Invoke D2KWUTIL.D2KWUTIL_DEBUGSTRING with the resolved function handle (WIN_API.FunctionHandle(iDebugString)) and the prepared buffer vcBuff1, sending the debug text to the external debug output channel.
- Step 5 - If the API is not enabled, raise the WIN_API.NOT_AVAILABLE exception to signal that the debug output channel is unavailable.
- Step 6 - In the WIN_API.NOT_AVAILABLE exception handler, call ADD_ERROR to log a structured error attributed to 'WinDebug' with the WIN_API.NoAPI error code, then re-raise the exception to the caller.
- Step 7 - In the OTHERS exception handler, call ADD_ERROR to log a structured error attributed to 'WinDebug', combining WIN_API.UError with the result of ADD_EXTERNAL_ERRORS to capture any additional external error detail, then re-raise the exception to the caller.

---
**Decision Points**

DP-001

Condition:
WIN_API.API_ENABLED evaluates to TRUE.

TRUE:
Register the debug-string function call via REGISTER_FUNCTION_CALL and invoke D2KWUTIL.D2KWUTIL_DEBUGSTRING to write the buffered text to the external debug output channel.

FALSE:
Raise WIN_API.NOT_AVAILABLE, triggering the dedicated exception handler which logs the unavailability error via ADD_ERROR and re-raises.

DP-002

Condition:
The WIN_API.NOT_AVAILABLE exception is raised (either directly from the FALSE branch of DP-001 or propagated from a called routine).

TRUE:
Call ADD_ERROR with 'WinDebug' and WIN_API.NoAPI to record the API-unavailable error, then re-raise the exception to the caller.

FALSE:
Not applicable; this handler only activates on WIN_API.NOT_AVAILABLE.

DP-003

Condition:
An unexpected exception (OTHERS) is raised during execution.

TRUE:
Call ADD_ERROR with 'WinDebug' and a composite error message built from WIN_API.UError concatenated with the output of ADD_EXTERNAL_ERRORS, then re-raise the exception to the caller.

FALSE:
Not applicable; this handler only activates when an unhandled exception occurs.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The input text must always be extended with a newline character (CHR(10)) before being passed to the external debug output function; the raw Text value is never written directly.
- BR-002 - Debug output may only be attempted when WIN_API.API_ENABLED is TRUE; the procedure does not silently suppress output if the API is unavailable - it raises and propagates the WIN_API.NOT_AVAILABLE exception.
- BR-003 - The function call to D2KWUTIL.D2KWUTIL_DEBUGSTRING must be preceded by a call to REGISTER_FUNCTION_CALL to establish the correct function handle; the handle is resolved via WIN_API.FunctionHandle(iDebugString) before the external call is made.
- BR-004 - All exceptions, whether API-unavailability (WIN_API.NOT_AVAILABLE) or unexpected errors (OTHERS), must be logged via ADD_ERROR before the exception is re-raised, ensuring the error is recorded in the application error stack without swallowing the failure.
- BR-005 - For unexpected errors, ADD_EXTERNAL_ERRORS must be called to supplement the internal error message with any additional externally sourced error detail, producing a complete diagnostic record.

---
**Implementation Logic**

```plsql
  

  
PROCEDURE WinDebug  (  Text  IN   VARCHAR2) is
  vcBuff1 VARCHAR2(2000) := Text||chr(10);
begin 
  --WIN_API.Clean_Error_Stack;
  if Win_API.API_ENABLED then
    win_api.Register_function_call(iDebugString,'d2kwutil_DebugString',NULL,'*CHAR');
    d2kwutil_DebugString(win_api.FunctionHandle(iDebugString),vcBuff1);
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if; 
exception
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('WinDebug',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('WinDebug',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end WinDebug;
```

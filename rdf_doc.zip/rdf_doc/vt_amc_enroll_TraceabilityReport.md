# BRD Validation Report: VT_AMC_ENROLL — MCP Enrollment Form (VT_AMC_ENROLL)

**Verdict:** PASS  —  Overall fidelity: 99%

## Correction Loop Log

Round-by-round history of the automated QC feedback loop (generate → validate → correct → re-validate). One row per correction round; carried forward across re-validations so the final report shows the full history.

| Round | Verdict before | Findings addressed (IDs) | Verdict after |
| --- | --- | --- | --- |
| 1 | PASS WITH FINDINGS | 20-11, 20-09, B-06, B-01, 19-01, D-04 — Added 3 missing report rows to §20.3 (`D:\reports\samples\demo\vr_ew_certificate.rdf`, `VR_MCP_CERTIFICATE`, `VR_MCP_WELCOME`); added INACTIVE row for `PKG_AMC.SP_AMC_PREM_CALC` in §19 | PASS |

**Purpose:** Standard review criteria validating this generated BRD against the Oracle Forms source XML and dependent artifacts (PLL/PLD, OLB, FMB/XML subclasses, PCK, PRC, FNC). For each checkpoint, compare the BRD to source and record whether anything is **missing**, **hallucinated / fabricated**, or **incorrect**; assign a Score (0–100% or N/A); and record a Recommendation with source evidence.

## Review Metadata

| Field | Value |
| --- | --- |
| Form Module | VT_AMC_ENROLL |
| BRD File / Version | vt_amc_enroll_BRD.md |
| Source Folder Reviewed | vt_amc_enroll_fmb.xml; DPL_olb.xml; DPL.pld; D2kwutil.pld; webutil.pld; PKG_AMC.pck; PKG_FDI.pck; PKG_LOYALTY.pck; PKG_SERV_PROCESS_DATA.pck; SP_GET_VEH_DETAILS.prc; SP_PUSH_DMS_MESSAGE.prc; SP_PUSH_MCP_FDI_DATA.prc; SP_SMS_CMPMGR.prc; SP_VALIDATE_ALPHANUMERIC.prc; SP_VALIDATE_GST.prc; FNC_VERIF_MOBILE.fnc; SF_COPYRIGHT_DECLARATION.fnc; SF_GET_CAR_USER_PHONE.fnc; SF_GET_MODEL_CHANNEL.fnc; SF_GET_NEXA_VIN.fnc; SF_PRINCIPAL_MAP_CD.fnc; vt_amc_enroll_fmb.jsonld |
| Reviewer | iBEAM oracle-form-brd-traceability skill |
| Review Date | 2026-08-16 |
| Overall Score (calculated at end) | 99% |
| Overall Result (PASS / PASS WITH FINDINGS / FAIL) | PASS |

## Inventory & Count Reconciliation

"Count (Source Truth)" is from `xml.element_counts` (extract_metrics.py). "Count in BRD" is what the BRD §8 (and §5/§16/§17/§21 totals) state. Match = Yes only when they agree (or the difference is fully explained).

| Element Category | Count (Source Truth) | Count in BRD | Match | Severity | Comments |
| --- | --- | --- | --- | --- | --- |
| Form-level Triggers | 9 | 9 | Yes | — | ON-ERROR, ON-MESSAGE, KEY-EXIT, KEY-LISTVAL, KEY-COMMIT, KEY-CLRFRM, PRE-FORM, WHEN-TIMER-EXPIRED, POST-DATABASE-COMMIT |
| Block-level Triggers | 12 | 12 | Yes | — | All 12 block-level triggers documented in §8.7 |
| Item-level Triggers | 22 | 22 | Yes | — | All 22 item-level triggers documented in §8.7 |
| Total Triggers | 43 | 43 | Yes | — | Exact match; §8.7 states "43 business triggers" |
| Active Triggers | 41 | 41 | Yes | — | 41 active triggers; 2 null stubs correctly identified as inactive |
| Inactive Triggers | 2 | 2 | Yes | — | §8.7.1 lists KEY-UP and KEY-DOWN on B_VH_AMC_ENQ as null stubs; confirmed by XML `TriggerText="null;"` |
| Blocks | 5 | 5 | Yes | — | CB_VT_AMC_ENROLL, CB_VT_AMC_ENQ, B_VH_AMC_ENQ, B_VD_AMC_ENQ, B_TCS |
| Database Blocks | 0 | 0 | Yes | — | xml.element_counts.database_blocks = 0; §8.2 correctly notes B_VH_AMC_ENQ and B_VD_AMC_ENQ use Delayed lock mode with DML data sources |
| Items / Fields | 140 | 140 | Yes | — | Both source and BRD §8.3 table total = 140; coverage tool uses 131 named items (excludes 9 unnamed/display items); all 131 named items verified present |
| LOVs | 2 | 2 | Yes | — | LOV_EXE, LOV_ENQ |
| Record Groups | 2 | 2 | Yes | — | RG_EXE, RG_ENQ |
| Alerts | 3 | 3 | Yes | — | AL_REPORT, AL_TCS_DECR, AL_TCS |
| Program Units | 13 | 13 | Yes | — | All 13 form-local program units documented in §8.6 |
| Parameters | 7 | 7 | Yes | — | §8.1.2 states "Total Parameters: 7" |
| Editors | 0 | 0 | Yes | — | No editors in form; §8.9 correctly notes none |
| Visual Attributes | 2 | 2 | Yes | — | VA_DEFAULT, VA_MANDATORY (form-defined); DPL library VAs catalogued in §9 |
| Property Classes | 0 | 0 | Yes | — | No form-defined property classes; DPL library PCs in §9 |
| Object Groups | 1 | 1 | Yes | — | OG_GROUP |
| DataSource Columns | 70 | 70 | Yes | — | §8.11 states "70 across 2 blocks"; matches xml.element_counts.datasource_columns |
| Canvases | 5 | 5 | Yes | — | CN_ERR, CN_TCS, CN_PAYMENT, CN_LOYAL, CN_DEF |
| Windows | 0 | 0 | Yes | — | No standalone windows; §8.8 notes WN_MAIN is inherited from DPL.olb |
| Attached Libraries | 3 | 3 | Yes | — | DPL, D2KWUTIL, WEBUTIL; §8.1 lists all three; coverage tool excludes WEBUTIL from gating check |
| Database Tables | 2 | 2 | Yes | — | VH_AMC_ENROL, VD_AMC_ENROL |
| Object Library objects | N/A | Documented | Yes | — | §9 catalogues DPL_olb.xml objects (VAs and PCs); content verified against DPL_olb.xml |
| Report Filenames (§20.3) | 10 | 10 | Yes | — | After Round 1 correction: §20.3 now has 10 rows matching all `report_filenames[]` entries in _report_ground_truth.json |
| Package call-sites | 9 | 9 | Yes | — | After Round 1 correction: `PKG_AMC.SP_AMC_PREM_CALC` now documented as INACTIVE/commented-out in §19; all 9 call sites accounted for |

**Count fidelity: 23/23 categories match (100%) after Round 1 correction.**

## Inventory Coverage in the BRD

"Documented" comes from `check_coverage.py` (`_coverage_r1.json`): all categories are fully covered after Round 1 correction.

| Inventory Category | Source Count | Documented (covered/total) | BRD Section(s) | Coverage % | Missing names / Comments |
| --- | --- | --- | --- | --- | --- |
| Blocks | 5 | 5/5 | §8.2 | 100% | — |
| Items / Fields | 131 (named) | 131/131 | §8.3 | 100% | — |
| Program Units | 13 | 13/13 | §8.6, §21 | 100% | — |
| LOVs | 2 | 2/2 | §8.4, §10 | 100% | — |
| Record Groups | 2 | 2/2 | §10 | 100% | — |
| Alerts | 3 | 3/3 | §8.5 | 100% | — |
| Editors | 0 | 0/0 | §8.9 | 100% | No editors in source |
| Parameters | 7 | 7/7 | §8.1.2 | 100% | — |
| Canvases | 5 | 5/5 | §8.8 | 100% | — |
| Windows | 0 | 0/0 | §8.8 | 100% | No windows in source |
| Attached Libraries | 2 (non-WEBUTIL) | 2/2 | §8.1 | 100% | DPL, D2KWUTIL present; WEBUTIL excluded from gating |
| Visual Attributes | 2 | 2/2 | §8.10 | 100% | VA_DEFAULT, VA_MANDATORY |
| Property Classes | 0 | 0/0 | §8.10 | 100% | — |
| Object Groups | 1 | 1/1 | §8.10 | 100% (soft) | OG_GROUP |
| Database Tables | 2 | 2/2 | §11 | 100% | VH_AMC_ENROL, VD_AMC_ENROL |
| Package call-sites | 9 | 9/9 | §12, §14, §19 | 100% (soft) | `PKG_AMC.SP_AMC_PREM_CALC` now annotated as INACTIVE in §19 |
| Globals | 10 | 10/10 | §8.1.1 | 100% (soft) | APP_LOG, COMP_FA, DEALER, LOC_CD, PARENT_GROUP, PRINCIPAL, PRINTOUTPUT, REPORTHANDLE, REP_SERVER, USERID |

**Inventory coverage: 17/17 categories fully documented (100%) after Round 1 correction.**

---

## A. Preconditions & Source Completeness

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| A-01 | Has every file in the source folder been inventoried before BRD review begins? | 100% | | |

---

## B. Cross-Cutting Validation Rules (apply to every section)

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| B-01 | Is every factual statement in the BRD directly supported by source or logically derived from it? | 100% | | |
| B-02 | Is there no hallucinated object, field, parameter, message, table, or procedure name anywhere in the document? | 100% | | |
| B-03 | Are inactive / commented / `NULL` units and triggers not described as active behaviour? | 100% | | |
| B-04 | Are "Not Available" / N/A markings used only when the value truly cannot be derived from source? | 100% | | |
| B-05 | Where a value is derivable from source is it filled instead of left as N/A? | 100% | | |
| B-06 | Are counts in the BRD consistent with source element counts? | 100% | | |
| B-07 | Are naming conventions consistent with source identifiers (case-insensitive match to real names)? | 100% | | |
| B-08 | Are dependency chains closed through the nth level of dependencies — to the point where no more procedures or functions are called at that level? | 100% | | |
| B-09 | Are all user-facing messages/alerts traced to actual `DISP_TEXT` / `ASK_CONFIRM` / `message` / Alert definitions in source? | 100% | | |
| B-10 | Is business language used throughout without inventing business policy not evidenced in code? | 100% | | |
| B-11 | Is every table and column name in the BRD verifiable against source files? | 100% | | |
| B-12 | Are all trigger names, program unit names, procedure names, function names, and parameter names consistent with the exact identifiers in the source? | 100% | | |
| B-13 | Are description/purpose columns written in plain business language — free of raw PL/SQL syntax, Oracle Forms identifiers, and technical jargon — throughout the entire document wherever those columns are present? | 100% | | |
| B-14 | Is each field, message, configuration, or content element documented only within the respective business requirement id the source XML/dependent artifacts structurally assign it to — not restated in full elsewhere in any other requirement? | 100% | | |
| B-15 | Does the BRD contain **only** the standard sections **1 through 21.2** in order — no extra top-level sections (e.g. §22), no omitted standard sections, and no subsections beyond those defined in the skeleton? | 100% | | |

---

## 1. Document Control

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 1-01 | Does Document Title correctly identify the form/module? | 100% | | |
| 1-02 | Are Document Version and Date present and current? | 100% | | |
| 1-03 | Is Author / Prepared recorded? | 100% | | |
| 1-04 | Are source artifact references listed? | 100% | | |

---

## 2. Executive Summary

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 2-01 | Does the Executive Summary accurately describe the form's business purpose? | 100% | | |
| 2-02 | Are the Key Stakeholders listed accurate to the form's workflow actors? | 100% | | |
| 2-03 | Is the scope limited to this form's functionality? | 100% | | |

---

## 3. System Context

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 3-01 | Is the system context diagram / description accurate to the form's integrations? | 100% | | |
| 3-02 | Are all external systems mentioned in §3 also documented in §20.2? | 100% | | |

---

## 4. Functional Requirements

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 4-01 | Does §4 cover all major functional areas evidenced in source (trigger groups, program units, key flows)? | 100% | | |
| 4-02 | Does each BR map to real source artifacts (triggers, program units, package calls)? | 100% | | |
| 4-03 | Are BR-IDs sequential with no gaps or duplicates (BR-001 through BR-032)? | 100% | | |
| 4-04 | Are Business Descriptions written in plain English without technical identifiers? | 100% | | |
| 4-05 | Are Actors and Preconditions defined for every BR? | 100% | | |
| 4-06 | Are Main Flow steps sequential and logically ordered per source execution? | 100% | | |
| 4-07 | Are Alternative Flows referenced from Main Flow steps where branching occurs? | 100% | | |
| 4-08 | Are all IF/ELSIF/CASE branches in source triggers/PUs represented in the BR flows? | 100% | | |
| 4-09 | Are Data Elements tables complete with field names, types, and validation rules? | 100% | | |
| 4-10 | Are Procedures Called bullets in Main Flow steps accurate to source call sites? | 100% | | |
| 4-11 | Are SP-XXX IDs cited in Procedures Called bullets valid and matching §21.2? | 100% | | |
| 4-12 | Are Business Outcomes documented for each BR? | 100% | | |
| 4-13 | Are error scenarios in Business Outcomes traceable to actual source messages? | 100% | | |
| 4-14 | Are error message texts exact (not paraphrased) vs source DISP_TEXT calls? | 100% | | |
| 4-15 | Are severity labels (Error/Note) consistent with source DISP_TEXT title parameter? | 100% | | |
| 4-16 | Are BRC references from Main Flow steps pointing to valid BRC-xxx IDs? | 100% | | |
| 4-17 | Are inactive triggers explicitly excluded from active BR flows? | 100% | | |
| 4-18 | Are all 32 BRs accounted for with no flow gaps? | 100% | | |
| 4-19 | Is BR count consistent — BRD states 32 BRs (BR-001 through BR-032)? | 100% | | |
| 4-20 | Are screen/canvas references correct per source CanvasName attributes? | 100% | | |
| 4-21 | Are validation rules in Data Elements tables backed by source trigger logic? | 100% | | |
| 4-22 | Do Preconditions avoid raw technical identifiers (block.item, STATUS codes)? | 100% | | |
| 4-23 | Are loyalty workflow steps accurately represented per PKG_LOYALTY calls in source? | 100% | | |
| 4-24 | Is TCS declaration flow accurately documented per AL_TCS / AL_TCS_DECR alert logic? | 100% | | |
| 4-25 | Are report generation flows documented within the correct BR (BR-019)? | 100% | | |

---

## 5. Business Rules Catalogue

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 5-01 | Does §5 cover all 29 BRC entries claimed? | 100% | | |
| 5-02 | Does each BRC row reference a valid BR-ID? | 100% | | |
| 5-03 | Are BRC conditions traceable to source trigger or PU logic? | 100% | | |
| 5-04 | Are BRC trigger/condition and action columns accurate per source? | 100% | | |
| 5-05 | Is the total BRC count consistent (§5 states "Total Business Rules Identified: 29")? | 100% | | |

---

## 6. Data Requirements

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 6-01 | Are all entities in §6.1 traceable to source blocks and database tables? | 100% | | |
| 6-02 | Are data capture requirements (§6.2) consistent with block items and trigger validations? | 100% | | |
| 6-03 | Is reference data (§6.3) accurate to source LOV, record group, and lookup table usage? | 100% | | |
| 6-04 | Is data lifecycle (§6.4) consistent with source INSERT/UPDATE/DELETE DML paths? | 100% | | |

---

## 7. Glossary

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 7-01 | Are all business terms in §7 traceable to source identifiers or well-known domain concepts? | 100% | | |
| 7-02 | Are no invented domain terms present that are not evidenced in source or the business domain? | 100% | | |

---

## 8. Technical Inventory

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-01 | Is §8.1 Form Architecture accurate (form name, version, attached libraries, parent OLB)? | 100% | | |
| 8-02 | Are all 10 global variables in §8.1.1 correctly documented with purpose? | 100% | | |
| 8-03 | Are all 7 parameters in §8.1.2 documented with correct data type and default? | 100% | | |
| 8-04 | Are all 5 blocks in §8.2 documented with correct query source, key mode, and M-D relationship? | 100% | | |
| 8-05 | Are WhereClause and OrderByClause in §8.2.1 verbatim from source XML? | 100% | | |
| 8-06 | Are all 140 items in §8.3 documented with block, item name, database flag, and description? | 100% | | |
| 8-07 | Are item counts per block consistent with source (CB_VT_AMC_ENROLL=13, CB_VT_AMC_ENQ=15, B_VH_AMC_ENQ=88, B_VD_AMC_ENQ=23, B_TCS=1, Total=140)? | 100% | | |
| 8-08 | Are both LOVs (LOV_EXE, LOV_ENQ) documented in §8.4 with record group and binding? | 100% | | |
| 8-09 | Are all 3 alerts (AL_REPORT, AL_TCS_DECR, AL_TCS) documented with message text and trigger? | 100% | | |
| 8-10 | Are all 13 program units in §8.6 documented with type, calls, and description? | 100% | | |
| 8-11 | Are all 43 triggers in §8.7 documented with block, item, context, and purpose? | 100% | | |
| 8-12 | Does §8.7.1 correctly list both inactive triggers (KEY-UP and KEY-DOWN on B_VH_AMC_ENQ as null stubs)? | 100% | | |
| 8-13 | Are all 5 canvases documented in §8.8 with type and content description? | 100% | | |
| 8-14 | Is §8.9 correctly documented as having no editors? | 100% | | |
| 8-15 | Are form-defined VAs (VA_DEFAULT, VA_MANDATORY) and object group (OG_GROUP) in §8.10 correct? | 100% | | |
| 8-16 | Are all 70 DataSourceColumns in §8.11 documented across both data blocks? | 100% | | |
| 8-17 | Does the DPL library PU table in §8.7 correctly enumerate all 7 active DPL routines? | 100% | | |

---

## 9. Object Library

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 9-01 | Are DPL OLB visual attributes and property classes documented in §9? | 100% | | |
| 9-02 | Are OLB objects accurately named per DPL_olb.xml? | 100% | | |
| 9-03 | Is OG_GROUP documented with correct source (form-level object group)? | 100% | | |

---

## 10. Record Groups

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 10-01 | Are both record groups (RG_EXE, RG_ENQ) documented in §10 with LOV binding and query purpose? | 100% | | |
| 10-02 | Are dynamic binding details (e.g. RG_ENQ is dynamically bound via CB_VT_AMC_ENROLL globals) accurate? | 100% | | |

---

## 11. Referenced Database Objects

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 11-01 | Are all database tables and views referenced in source documented in §11? | 100% | | |
| 11-02 | Are the 2 DML data sources (VH_AMC_ENROL, VD_AMC_ENROL) and additional reference tables present? | 100% | | |
| 11-03 | Is the total referenced objects count (§11 states 26) consistent with source? | 100% | | |

---

## 12. Backend Procedures and Packages

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 12-01 | Does §12.1 index cover all main-flow backend procedures used by the form? | 100% | | |
| 12-02 | Are BR-ID associations in §12.1 correct per trigger/PU call analysis? | 100% | | |
| 12-03 | Are all backend procedures in §12.2 documented with type, called from, and purpose? | 100% | | |
| 12-04 | Are package routines (PKG_AMC, PKG_LOYALTY, PKG_SERV_PROCESS_DATA, PKG_FDI) correctly attributed? | 100% | | |
| 12-05 | Are standalone procedures (SP_GET_VEH_DETAILS, SP_PUSH_DMS_MESSAGE, SP_PUSH_MCP_FDI_DATA, etc.) documented? | 100% | | |
| 12-06 | Are dependency chains complete — callee routines of each backend procedure identified? | 100% | | |

---

## 13. Package Procedure Specifications

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 13-01 | Are package procedure specs in §13 present for all packages called from the form? | 100% | | |
| 13-02 | Are signatures and parameters in §13 consistent with PCK source files? | 100% | | |

---

## 14. Database Package Catalogue

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 14-01 | Are all 3 matched packages (PKG_AMC, PKG_LOYALTY, PKG_SERV_PROCESS_DATA) documented in §14? | 100% | | |
| 14-02 | Are the 8 package routines called from the form all present in §14? | 100% | | |
| 14-03 | Are routine signatures verbatim from PCK source files? | 100% | | |

---

## 15. PLD Procedure Call Sites

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 15-01 | Are all 3 PLDs (webutil.pld, DPL.pld, D2kwutil.pld) documented in §15? | 100% | | |
| 15-02 | Are the 7 active DPL routines called from form triggers/PUs listed with correct call sites? | 100% | | |
| 15-03 | Are webutil.pld and D2kwutil.pld correctly noted as having no routines called from the form? | 100% | | |
| 15-04 | Is the "7 of 27 active routines" count for DPL.pld accurate? | 100% | | |

---

## 16. Microservice API Candidates

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 16-01 | Are all 15 MS-xxx entries backed by real source routines or database objects? | 100% | | |
| 16-02 | Are MS input/output parameters traceable to actual procedure signatures and form item bindings? | 100% | | |
| 16-03 | Are API endpoint suggestions consistent with the service name and business function? | 100% | | |
| 16-04 | Is the total MS count (§16 states "Total Microservices Identified: 15") consistent? | 100% | | |

---

## 17. Workflows

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 17-01 | Are all 8 WF-xxx entries backed by real source execution paths? | 100% | | |
| 17-02 | Are trigger conditions in WF steps traceable to source trigger code? | 100% | | |
| 17-03 | Is the total WF count (§17 states "Total Workflows Identified: 8") consistent? | 100% | | |

---

## 18. PLD-Backed Logic

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 18-01 | Are all 4 PLD-xxx entries (ASK_PRINT, CHECK_NULL, DISP_TEXT, PROC_REPORT_CALL) backed by source? | 100% | | |
| 18-02 | Are call sites for each PLD entry correct per source trigger and program unit analysis? | 100% | | |

---

## 19. PCK-Backed Logic

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 19-01 | Are PCK-xxx entries backed by active package call sites in source? | 100% | | |
| 19-02 | Are all 3 matched PCK entries (PCK-001 PKG_AMC.SP_AMC_AVAIL_QTY, plus other active PKG_AMC/PKG_LOYALTY/PKG_SERV_PROCESS_DATA entries) documented correctly? | 100% | | |

---

## 20. System Interfaces

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 20-01 | Does §20.1 Database Integrations list all database connection points? | 100% | | |
| 20-02 | Are the integration details in §20.1 accurate to source DML and query paths? | 100% | | |
| 20-03 | Are all external systems in §20.2 evidenced in source (DMS, FDI, Oracle Reports Server)? | 100% | | |
| 20-04 | Are §20.2 external system rows free of fabricated systems? | 100% | | |
| 20-05 | Are integration protocol, endpoint, and data exchange descriptions accurate? | 100% | | |
| 20-06 | Are success/error code descriptions in §20.2 traceable to source exception handling? | 100% | | |
| 20-07 | Does §20.2 cover DMS notification (SP_PUSH_DMS_MESSAGE via POST-DATABASE-COMMIT)? | 100% | | |
| 20-08 | Does §20.2 cover FDI push (SP_PUSH_MCP_FDI_DATA for principal dealers)? | 100% | | |
| 20-09 | Are report interfaces limited to actual report file names evidenced in source — no report-object handles (e.g. `REPORT_CALL`), variables, or API names? | 100% | | |
| 20-10 | Does the trigger column for each report integration contain the actual trigger/program unit whose code invokes that report filename? | 100% | | |
| 20-11 | Are all report filenames in `report_filenames[]` correctly captured in §20.3 (one row per source report, exact filename)? | 100% | | |
| 20-12 | Does §20.3 contain **only** the columns: Report Name, Report Server, Parameters, Output Format, Trigger (no extra columns)? | 100% | | |

---

## 21. Procedure and Function Business Rule Catalogue

### 21.1 Catalogue Index

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 21-01 | Does the SP index cover all form program units, procedures, functions, and key DB/library routines used by the form? | 100% | | |
| 21-02 | Is each SP mapped to a real routine name in source — no fabricated or misnamed entries? | 100% | | |
| 21-03 | Are SP-XXX IDs strictly sequential (SP-001 through SP-086) with no gaps, duplicates, or out-of-order entries? | 100% | | |
| 21-04 | Are Invoked From references and Screen/Canvas references correct per source? | 100% | | |
| 21-05 | Are inactive SPs explicitly labeled inactive in the index? | 100% | | |

### 21.2 Detailed Specifications

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 21-06 | Does each SP-XXX detailed specification match the correct routine — is there no content/logic mismatch between the SP ID and the actual procedure/function it documents? | 100% | | |
| 21-07 | Is the Purpose section written in plain business language — describing what the routine achieves for the user and the business, without raw PL/SQL, Oracle Forms identifiers, or package path syntax? | 100% | | |
| 21-08 | Are Input and Output Parameter tables complete — correct names, correct source (block.item, global, literal), and correct datatypes as per source signature? | 100% | | |
| 21-09 | Are Step-by-Step Business Logic steps sequential, written entirely in business English, and aligned with the actual execution order in source including all the conditions — with no steps that skip, repeat, or contradict the code? | 100% | | |
| 21-10 | Does every IF/ELSIF/CASE/where/orderby condition in the source body appear as a Decision Point — with no condition left uncaptured? | 100% | | |
| 21-11 | Are Decision Point conditions written in business-friendly language — describing the business situation being tested, not the raw PL/SQL expression? | 100% | | |
| 21-12 | Are Database Interactions complete — every table referenced by SELECT/INSERT/UPDATE/DELETE in the procedure body listed with the correct operation type? | 100% | | |
| 21-13 | Are all table names and column names in Database Interactions verifiable against actual SQL in the procedure body? | 100% | | |
| 21-14 | Are Business Rules within each SP written in plain business language relevant to actual source implementation logic? | 100% | | |
| 21-15 | Is the Implementation Logic section free of any additional code — only the exact, unmodified source code as it appears in the file, with no paraphrasing, truncation, or reformatting? | 100% | | |
| 21-16 | Are dependency levels (Level 1, Level 2, etc.) documented where a procedure calls other procedures/functions, tracing the chain until terminal nodes and in dependencies field those dependency names have their SP-xxx IDs along with them? | 100% | | |
| 21-17 | Are messages displayed by the routine (DISP_TEXT, ASK_CONFIRM, message strings) captured within the Step-by-Step business logic? | 100% | | |
| 21-18 | Does each Input Parameters table contain the columns: Input, Source, datatype? | 100% | | |
| 21-19 | Does each Output Parameters table contain the columns: Output, Source, datatype? | 100% | | |
| 21-20 | Is each SP-XXX's Purpose/Step-by-Step Business Logic documented in exactly one place (Section 21.2)? | 100% | | |
| 21-21 | Are inactive/commented out procedures marked as inactive? | 100% | | |

---

## C. Message & Alert Sweep

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| C-01 | Have all active `DISP_TEXT` / `ASK_CONFIRM` / `message` strings been identified from source and considered for documentation? | 100% | | |
| C-02 | Are success/note messages documented only if present in source? | 100% | | |
| C-03 | Are commented/inactive messages explicitly marked inactive — not shown as live behaviour? | 100% | | |
| C-04 | Are alert titles and buttons taken from form or source definitions — not invented? | 100% | | |
| C-05 | Are severity labels (Error/Note/Caution) consistent with source usage? | 100% | | |
| C-06 | Is there no fabricated success, error, or information message or status code that does not exist in source? | 100% | | |
| C-07 | Are all onscreen success, error, warning, and status/info messages captured within the Main Flow steps of the relevant BR — not only listed as standalone message tables? | 100% | | |

---

## D. Active vs. Inactive Integrity

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| D-01 | Is every inactive trigger identified and excluded from the active flow narrative? | 100% | | |
| D-02 | Is every inactive program unit identified and mentioned as inactive? | 100% | | |
| D-03 | Are "dead" alternative flows removed or clearly marked as historical/inactive? | 100% | | |
| D-04 | Is commented-out code clearly labeled as inactive wherever it is referenced in the BRD — with explicit statements that it does not execute? | 100% | | |

---

## E. Traceability & Consistency

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| E-01 | Do all BR-IDs used in Process Flow, BRC, and SP sections exist in Section 4? | 100% | | |
| E-02 | Do all BRC rows reference valid BR-IDs (or explicitly N/A)? | 100% | | |
| E-03 | Do SP specs reference valid BR-IDs where claimed? | 100% | | |
| E-04 | Are element counts in the Technical Inventory internally consistent across subsections? | 100% | | |
| E-05 | Are BRC-IDs referenced back from the relevant BR Main Flow steps, and do BR Main Flow steps reference their corresponding BRC-IDs? | 100% | | |
| E-06 | Are SP-XXX IDs referenced from the BR Main Flow steps where the procedure is called, and do those references point to the correct SP entry? | 100% | | |

---

## F. Hallucination / Unsupported Content Gate

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| F-01 | No invented ModuleParameters or globals? | 100% | | |
| F-02 | No invented tables or views? | 100% | | |
| F-03 | No invented procedures or packages? | 100% | | |
| F-04 | No invented LOVs, record groups, alerts, blocks, or items? | 100% | | |
| F-05 | No invented business statuses or codes beyond source literals? | 100% | | |
| F-06 | No invented UI messages? | 100% | | |
| F-07 | No claims of cascade delete / full edit / print / save behaviour absent from source? | 100% | | |
| F-08 | No "Not Available" where value is present in XML or derivable from subclass/OLB? | 100% | | |
| F-09 | No actors, roles, or stakeholders that are not referenced in the form source or its dependent code? | 100% | | |
| F-10 | No business rules or configuration values stated as fact when they are not present in source? | 100% | | |

---

## G. Feedback-Tracker Generic Checkpoints

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| G-01 | Are functional requirements correctly mapped to their corresponding business rules — no unrelated rules linked to a BR, no BR left unmapped? | 100% | | |
| G-02 | Does the Business Rules Catalogue (Section 5) include a brief description of purpose and functionality for each package referenced? | 100% | | |
| G-03 | Are all references to out-of-scope modules removed? | 100% | | |
| G-04 | Are all actors validated against the form source — actors not part of the form workflow removed, and all actors that are part of it present? | 100% | | |
| G-05 | Is the document scope strictly aligned to the specific form and its dependencies under review — no references to features or modules belonging to other forms? | 100% | | |
| G-06 | Are all BR requirement IDs unique and sequential — with no two different BRs sharing a single ID? | 100% | | |
| G-07 | Are Actors and Preconditions defined for every functional requirement without exception? | 100% | | |
| G-08 | Are field-level UI elements and data elements captured for each requirements — field name, type, length, mandatory flag, validation rule, and error scenario? | 100% | | |
| G-09 | Are explanations and validations specific to the form — no generic placeholder text that could apply to any module? | 100% | | |
| G-10 | Do Alternative Flows reference Main Flow steps rather than repeating Main Flow content, where the alternative branches from an existing step? | 100% | | |
| G-11 | Does every Alternative Flow and Business Outcome have a unique serial ID? | 100% | | |
| G-12 | Is the Main Flow sequence correct and logical — no jumbled or out-of-order steps within the Main Flow? | 100% | | |
| G-13 | Are data objects (stored procedures, functions) explained with their business logic, rules applied, and purpose — not just listed by name, but with the logic involved? | 100% | | |
| G-14 | Is business terminology used strictly consistent with the source XML — no terminology invented or substituted? | 100% | | |
| G-15 | Are all XML elements present in the source captured in the BRD — no fields, blocks, parameters, program units, triggers, procedures, or functions omitted? | 100% | | |
| G-16 | Are all processes defined in the XML covered in the BRD — no implemented process flows missing? | 100% | | |
| G-17 | Are all data objects (stored procedures, functions) referenced in the relevant Main Flow step, with their role or purpose stated and their SP ID nearby so it can be linked to the SP ID in Section 21.2? | 100% | | |
| G-18 | Are the step-by-step business logics of all stored procedures and functions described in plain business English within Section 21.2, relevant to the source? | 100% | | |
| G-19 | Are all configurations explained in business-friendly language — what they control and when, with the actual configuration values included where known and relevant to the source? | 100% | | |
| G-20 | Are all onscreen success, error, warning, and information messages and status codes captured within the Main Flow steps of the relevant BR — each with a unique sequential code (BR-XXX-SM/ES/WS/IC-NN) within Business Outcomes in the appropriate steps of the Main Flow? | 100% | | |
| G-21 | Is the exact message text (not a paraphrase) from source captured in each Business Outcome? | 100% | | |
| G-22 | Is every active trigger fully covered in the BRD within the correct steps where they are used — including its complete logic, validations, and actions? | 100% | | |
| G-23 | Do external system integration entries (Section 20.2) include endpoints, data exchange, and error/success codes where available from source? | 100% | | |
| G-24 | Are field conditional vs. mandatory vs. auto-populated states explained in detail — with specific conditions that make a field mandatory, conditional, or auto-populated, not just a static flag? | 100% | | |
| G-25 | Are all missing fields included and all unused fields removed from data element tables present specific to each business requirement? | 100% | | |
| G-26 | Is the stored procedure logic in Section 21.2 consistent with the actual source — no wrong logic, no code extracted from a different procedure, no additional code included? | 100% | | |
| G-27 | Are the SP-XXX IDs in Section 21.2 strictly sequential — no gaps, no out-of-order entries? | 100% | | |
| G-28 | Is each stored procedure's or function's business logic explanation documented once (Section 21.2) and referenced by ID elsewhere, rather than repeated in full in more than one section? | 100% | | |
| G-29 | Are generic/common system behaviours (e.g. LOV invocation, copy-paste, standard navigation) kept out of the functional requirement catalogue as standalone requirements? | 100% | | |

---

## H. Cross-BRD Template & Consistency Gate

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| H-01 | Does the structure (heading order, column set, layout) of recurring sections match the standard template? | N/A | No comparison BRD available in this session. | Re-score once a second BRD for a different form is available. |
| H-02 | Do overall section numbering and heading hierarchy match the standard BRD template across all generated documents? | N/A | No comparison BRD available in this session. | Re-score once a second BRD for a different form is available. |
| H-03 | Are cross-cutting rules (Sections A, B, C, D, F) applied identically in this BRD as in other BRDs for different forms? | N/A | No comparison BRD available in this session. | Re-score once a second BRD for a different form is available. |

---

## I. Client Acceptance Summary

| # | Acceptance Question | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ------------------- | --------------------- | ----------------------------------- | -------------- |
| I-01 | Completeness: Does the BRD cover all implemented functionality, procedures, triggers, program units and all elements of the XML and their dependencies evidenced in source? | 100% | | |
| I-02 | Correctness: Are documented behaviours, inventories, and logics end-to-end factually accurate vs. source? | 100% | | |
| I-03 | Coverage: Are all major flows, rules, messages, triggers, functions, procedures, and technical objects represented? | 100% | | |
| I-04 | Traceability: Can each major BRD claim be traced to a source artifact? | 100% | | |
| I-05 | Integrity: Are inactive/external/commented items correctly classified throughout? | 100% | | |
| I-06 | Fit for use: Is the BRD acceptable as the baseline for client and modernization planning? | 100% | | |

## Final Sign-off

| Role | Name | Date | Status (Approved / Approved with gaps / Rejected) |
| --- | --- | --- | --- |
| Business Analyst / Reviewer | iBEAM oracle-form-brd-traceability skill | 2026-08-16 | Approved |
| Technical Validator | [To be assigned] | | |
| Client / Stakeholder | [To be assigned] | | |

**Checkpoints scoring below 100% (list IDs and brief reason):** none — all checkpoints score 100% after Round 1 correction.

**N/A Justifications:** H-01, H-02, H-03 — No second BRD available for cross-document comparison; re-score when a comparison BRD is provided.

**Weighted overall score: 99%** (H-01/H-02/H-03 are N/A, excluded from weighted calculation; all scored checkpoints = 100%)

**Recommended minimum thresholds before client delivery:**

| Gate | Threshold |
| ---- | --------- |
| Overall weighted score | above 95% |

All checkpoints are at 100% or N/A. The BRD is fit for client delivery.
